# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.system.clinical_conductor import (
    study_config_update_params,
    study_config_study_configs_params,
    study_config_retrieve_study_configs_params,
)
from ....types.system.clinical_conductor.study_config_update_response import StudyConfigUpdateResponse
from ....types.system.clinical_conductor.study_config_retrieve_response import StudyConfigRetrieveResponse
from ....types.system.clinical_conductor.study_config_study_configs_response import StudyConfigStudyConfigsResponse
from ....types.system.clinical_conductor.study_config_retrieve_visits_response import StudyConfigRetrieveVisitsResponse
from ....types.system.clinical_conductor.study_config_retrieve_study_configs_response import (
    StudyConfigRetrieveStudyConfigsResponse,
)

__all__ = ["StudyConfigsResource", "AsyncStudyConfigsResource"]


class StudyConfigsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> StudyConfigsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return StudyConfigsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> StudyConfigsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return StudyConfigsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        study_config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigRetrieveResponse:
        """
        Get a study config by ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}",
                tenant_db_name=tenant_db_name,
                study_config_id=study_config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StudyConfigRetrieveResponse,
        )

    def update(
        self,
        study_config_id: int,
        *,
        tenant_db_name: str,
        clinical_conductor_instance_id: Optional[int] | Omit = omit,
        clinical_conductor_site_id: Optional[int] | Omit = omit,
        clinical_conductor_study_id: Optional[int] | Omit = omit,
        is_active: Optional[bool] | Omit = omit,
        target_visit_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigUpdateResponse:
        """
        Update a study config.

        Args:
          clinical_conductor_instance_id: ID of the Clinical Conductor instance

          clinical_conductor_site_id: Site ID in Clinical Conductor

          clinical_conductor_study_id: Study ID in Clinical Conductor

          is_active: Whether the config is active

          target_visit_id: Target visit ID for scheduling appointments

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._patch(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}",
                tenant_db_name=tenant_db_name,
                study_config_id=study_config_id,
            ),
            body=maybe_transform(
                {
                    "clinical_conductor_instance_id": clinical_conductor_instance_id,
                    "clinical_conductor_site_id": clinical_conductor_site_id,
                    "clinical_conductor_study_id": clinical_conductor_study_id,
                    "is_active": is_active,
                    "target_visit_id": target_visit_id,
                },
                study_config_update_params.StudyConfigUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StudyConfigUpdateResponse,
        )

    def delete(
        self,
        study_config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a study config.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}",
                tenant_db_name=tenant_db_name,
                study_config_id=study_config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve_study_configs(
        self,
        tenant_db_name: str,
        *,
        instance_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigRetrieveStudyConfigsResponse:
        """
        List study configs, optionally filtered by instance ID.

        Args:
          instance_id: Optional instance ID to filter by

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/clinical-conductor/study-configs", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"instance_id": instance_id},
                    study_config_retrieve_study_configs_params.StudyConfigRetrieveStudyConfigsParams,
                ),
            ),
            cast_to=StudyConfigRetrieveStudyConfigsResponse,
        )

    def retrieve_visits(
        self,
        study_config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigRetrieveVisitsResponse:
        """
        Get available visits for a study config.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}/visits",
                tenant_db_name=tenant_db_name,
                study_config_id=study_config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StudyConfigRetrieveVisitsResponse,
        )

    def study_configs(
        self,
        tenant_db_name: str,
        *,
        clinical_conductor_instance_id: int,
        clinical_conductor_site_id: int,
        clinical_conductor_study_id: int,
        target_visit_id: int,
        is_active: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigStudyConfigsResponse:
        """
        Create a new study config.

        Args:
          clinical_conductor_instance_id: ID of the Clinical Conductor instance

          clinical_conductor_site_id: Site ID in Clinical Conductor

          clinical_conductor_study_id: Study ID in Clinical Conductor

          target_visit_id: Target visit ID for scheduling appointments

          is_active: Whether the config is active

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/clinical-conductor/study-configs", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "clinical_conductor_instance_id": clinical_conductor_instance_id,
                    "clinical_conductor_site_id": clinical_conductor_site_id,
                    "clinical_conductor_study_id": clinical_conductor_study_id,
                    "target_visit_id": target_visit_id,
                    "is_active": is_active,
                },
                study_config_study_configs_params.StudyConfigStudyConfigsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StudyConfigStudyConfigsResponse,
        )


class AsyncStudyConfigsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncStudyConfigsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncStudyConfigsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncStudyConfigsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncStudyConfigsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        study_config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigRetrieveResponse:
        """
        Get a study config by ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}",
                tenant_db_name=tenant_db_name,
                study_config_id=study_config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StudyConfigRetrieveResponse,
        )

    async def update(
        self,
        study_config_id: int,
        *,
        tenant_db_name: str,
        clinical_conductor_instance_id: Optional[int] | Omit = omit,
        clinical_conductor_site_id: Optional[int] | Omit = omit,
        clinical_conductor_study_id: Optional[int] | Omit = omit,
        is_active: Optional[bool] | Omit = omit,
        target_visit_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigUpdateResponse:
        """
        Update a study config.

        Args:
          clinical_conductor_instance_id: ID of the Clinical Conductor instance

          clinical_conductor_site_id: Site ID in Clinical Conductor

          clinical_conductor_study_id: Study ID in Clinical Conductor

          is_active: Whether the config is active

          target_visit_id: Target visit ID for scheduling appointments

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._patch(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}",
                tenant_db_name=tenant_db_name,
                study_config_id=study_config_id,
            ),
            body=await async_maybe_transform(
                {
                    "clinical_conductor_instance_id": clinical_conductor_instance_id,
                    "clinical_conductor_site_id": clinical_conductor_site_id,
                    "clinical_conductor_study_id": clinical_conductor_study_id,
                    "is_active": is_active,
                    "target_visit_id": target_visit_id,
                },
                study_config_update_params.StudyConfigUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StudyConfigUpdateResponse,
        )

    async def delete(
        self,
        study_config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a study config.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}",
                tenant_db_name=tenant_db_name,
                study_config_id=study_config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve_study_configs(
        self,
        tenant_db_name: str,
        *,
        instance_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigRetrieveStudyConfigsResponse:
        """
        List study configs, optionally filtered by instance ID.

        Args:
          instance_id: Optional instance ID to filter by

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/clinical-conductor/study-configs", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"instance_id": instance_id},
                    study_config_retrieve_study_configs_params.StudyConfigRetrieveStudyConfigsParams,
                ),
            ),
            cast_to=StudyConfigRetrieveStudyConfigsResponse,
        )

    async def retrieve_visits(
        self,
        study_config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigRetrieveVisitsResponse:
        """
        Get available visits for a study config.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}/visits",
                tenant_db_name=tenant_db_name,
                study_config_id=study_config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StudyConfigRetrieveVisitsResponse,
        )

    async def study_configs(
        self,
        tenant_db_name: str,
        *,
        clinical_conductor_instance_id: int,
        clinical_conductor_site_id: int,
        clinical_conductor_study_id: int,
        target_visit_id: int,
        is_active: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StudyConfigStudyConfigsResponse:
        """
        Create a new study config.

        Args:
          clinical_conductor_instance_id: ID of the Clinical Conductor instance

          clinical_conductor_site_id: Site ID in Clinical Conductor

          clinical_conductor_study_id: Study ID in Clinical Conductor

          target_visit_id: Target visit ID for scheduling appointments

          is_active: Whether the config is active

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/clinical-conductor/study-configs", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "clinical_conductor_instance_id": clinical_conductor_instance_id,
                    "clinical_conductor_site_id": clinical_conductor_site_id,
                    "clinical_conductor_study_id": clinical_conductor_study_id,
                    "target_visit_id": target_visit_id,
                    "is_active": is_active,
                },
                study_config_study_configs_params.StudyConfigStudyConfigsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StudyConfigStudyConfigsResponse,
        )


class StudyConfigsResourceWithRawResponse:
    def __init__(self, study_configs: StudyConfigsResource) -> None:
        self._study_configs = study_configs

        self.retrieve = to_raw_response_wrapper(
            study_configs.retrieve,
        )
        self.update = to_raw_response_wrapper(
            study_configs.update,
        )
        self.delete = to_raw_response_wrapper(
            study_configs.delete,
        )
        self.retrieve_study_configs = to_raw_response_wrapper(
            study_configs.retrieve_study_configs,
        )
        self.retrieve_visits = to_raw_response_wrapper(
            study_configs.retrieve_visits,
        )
        self.study_configs = to_raw_response_wrapper(
            study_configs.study_configs,
        )


class AsyncStudyConfigsResourceWithRawResponse:
    def __init__(self, study_configs: AsyncStudyConfigsResource) -> None:
        self._study_configs = study_configs

        self.retrieve = async_to_raw_response_wrapper(
            study_configs.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            study_configs.update,
        )
        self.delete = async_to_raw_response_wrapper(
            study_configs.delete,
        )
        self.retrieve_study_configs = async_to_raw_response_wrapper(
            study_configs.retrieve_study_configs,
        )
        self.retrieve_visits = async_to_raw_response_wrapper(
            study_configs.retrieve_visits,
        )
        self.study_configs = async_to_raw_response_wrapper(
            study_configs.study_configs,
        )


class StudyConfigsResourceWithStreamingResponse:
    def __init__(self, study_configs: StudyConfigsResource) -> None:
        self._study_configs = study_configs

        self.retrieve = to_streamed_response_wrapper(
            study_configs.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            study_configs.update,
        )
        self.delete = to_streamed_response_wrapper(
            study_configs.delete,
        )
        self.retrieve_study_configs = to_streamed_response_wrapper(
            study_configs.retrieve_study_configs,
        )
        self.retrieve_visits = to_streamed_response_wrapper(
            study_configs.retrieve_visits,
        )
        self.study_configs = to_streamed_response_wrapper(
            study_configs.study_configs,
        )


class AsyncStudyConfigsResourceWithStreamingResponse:
    def __init__(self, study_configs: AsyncStudyConfigsResource) -> None:
        self._study_configs = study_configs

        self.retrieve = async_to_streamed_response_wrapper(
            study_configs.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            study_configs.update,
        )
        self.delete = async_to_streamed_response_wrapper(
            study_configs.delete,
        )
        self.retrieve_study_configs = async_to_streamed_response_wrapper(
            study_configs.retrieve_study_configs,
        )
        self.retrieve_visits = async_to_streamed_response_wrapper(
            study_configs.retrieve_visits,
        )
        self.study_configs = async_to_streamed_response_wrapper(
            study_configs.study_configs,
        )
