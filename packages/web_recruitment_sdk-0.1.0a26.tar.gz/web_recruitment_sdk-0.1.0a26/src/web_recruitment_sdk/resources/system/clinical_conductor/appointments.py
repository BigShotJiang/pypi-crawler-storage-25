# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.system.clinical_conductor import appointment_availability_params
from ....types.system.clinical_conductor.appointment_cancel_response import AppointmentCancelResponse
from ....types.system.clinical_conductor.appointment_retrieve_response import AppointmentRetrieveResponse
from ....types.system.clinical_conductor.appointment_availability_response import AppointmentAvailabilityResponse

__all__ = ["AppointmentsResource", "AsyncAppointmentsResource"]


class AppointmentsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AppointmentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AppointmentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AppointmentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AppointmentsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        appointment_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AppointmentRetrieveResponse:
        """
        Get an appointment by ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/appointments/{appointment_id}",
                tenant_db_name=tenant_db_name,
                appointment_id=appointment_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AppointmentRetrieveResponse,
        )

    def availability(
        self,
        tenant_db_name: str,
        *,
        candidate_id: int,
        end_date: Union[str, datetime],
        start_date: Union[str, datetime],
        study_config_id: int,
        days_of_week: SequenceNotStr[str] | Omit = omit,
        interval: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AppointmentAvailabilityResponse:
        """
        Get available appointment times for a study config.

        Args:
          candidate_id: The candidate ID used to resolve enrollment

          end_date: End of date range to query

          start_date: Start of date range to query

          study_config_id: The study config ID

          days_of_week: Days of the week to query availability for (e.g., Monday, Tuesday, Wednesday,
              Thursday, Friday, Saturday, Sunday)

          interval: Time slot interval (e.g., Minutes15, Minutes30)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/appointments/availability", tenant_db_name=tenant_db_name
            ),
            body=maybe_transform(
                {
                    "candidate_id": candidate_id,
                    "end_date": end_date,
                    "start_date": start_date,
                    "study_config_id": study_config_id,
                    "days_of_week": days_of_week,
                    "interval": interval,
                },
                appointment_availability_params.AppointmentAvailabilityParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AppointmentAvailabilityResponse,
        )

    def cancel(
        self,
        appointment_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AppointmentCancelResponse:
        """
        Cancel an appointment.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/appointments/{appointment_id}/cancel",
                tenant_db_name=tenant_db_name,
                appointment_id=appointment_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AppointmentCancelResponse,
        )


class AsyncAppointmentsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncAppointmentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncAppointmentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAppointmentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncAppointmentsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        appointment_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AppointmentRetrieveResponse:
        """
        Get an appointment by ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/appointments/{appointment_id}",
                tenant_db_name=tenant_db_name,
                appointment_id=appointment_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AppointmentRetrieveResponse,
        )

    async def availability(
        self,
        tenant_db_name: str,
        *,
        candidate_id: int,
        end_date: Union[str, datetime],
        start_date: Union[str, datetime],
        study_config_id: int,
        days_of_week: SequenceNotStr[str] | Omit = omit,
        interval: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AppointmentAvailabilityResponse:
        """
        Get available appointment times for a study config.

        Args:
          candidate_id: The candidate ID used to resolve enrollment

          end_date: End of date range to query

          start_date: Start of date range to query

          study_config_id: The study config ID

          days_of_week: Days of the week to query availability for (e.g., Monday, Tuesday, Wednesday,
              Thursday, Friday, Saturday, Sunday)

          interval: Time slot interval (e.g., Minutes15, Minutes30)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/appointments/availability", tenant_db_name=tenant_db_name
            ),
            body=await async_maybe_transform(
                {
                    "candidate_id": candidate_id,
                    "end_date": end_date,
                    "start_date": start_date,
                    "study_config_id": study_config_id,
                    "days_of_week": days_of_week,
                    "interval": interval,
                },
                appointment_availability_params.AppointmentAvailabilityParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AppointmentAvailabilityResponse,
        )

    async def cancel(
        self,
        appointment_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AppointmentCancelResponse:
        """
        Cancel an appointment.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/appointments/{appointment_id}/cancel",
                tenant_db_name=tenant_db_name,
                appointment_id=appointment_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AppointmentCancelResponse,
        )


class AppointmentsResourceWithRawResponse:
    def __init__(self, appointments: AppointmentsResource) -> None:
        self._appointments = appointments

        self.retrieve = to_raw_response_wrapper(
            appointments.retrieve,
        )
        self.availability = to_raw_response_wrapper(
            appointments.availability,
        )
        self.cancel = to_raw_response_wrapper(
            appointments.cancel,
        )


class AsyncAppointmentsResourceWithRawResponse:
    def __init__(self, appointments: AsyncAppointmentsResource) -> None:
        self._appointments = appointments

        self.retrieve = async_to_raw_response_wrapper(
            appointments.retrieve,
        )
        self.availability = async_to_raw_response_wrapper(
            appointments.availability,
        )
        self.cancel = async_to_raw_response_wrapper(
            appointments.cancel,
        )


class AppointmentsResourceWithStreamingResponse:
    def __init__(self, appointments: AppointmentsResource) -> None:
        self._appointments = appointments

        self.retrieve = to_streamed_response_wrapper(
            appointments.retrieve,
        )
        self.availability = to_streamed_response_wrapper(
            appointments.availability,
        )
        self.cancel = to_streamed_response_wrapper(
            appointments.cancel,
        )


class AsyncAppointmentsResourceWithStreamingResponse:
    def __init__(self, appointments: AsyncAppointmentsResource) -> None:
        self._appointments = appointments

        self.retrieve = async_to_streamed_response_wrapper(
            appointments.retrieve,
        )
        self.availability = async_to_streamed_response_wrapper(
            appointments.availability,
        )
        self.cancel = async_to_streamed_response_wrapper(
            appointments.cancel,
        )
