# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .grants import (
    GrantsResource,
    AsyncGrantsResource,
    GrantsResourceWithRawResponse,
    AsyncGrantsResourceWithRawResponse,
    GrantsResourceWithStreamingResponse,
    AsyncGrantsResourceWithStreamingResponse,
)
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from .calendar_configs import (
    CalendarConfigsResource,
    AsyncCalendarConfigsResource,
    CalendarConfigsResourceWithRawResponse,
    AsyncCalendarConfigsResourceWithRawResponse,
    CalendarConfigsResourceWithStreamingResponse,
    AsyncCalendarConfigsResourceWithStreamingResponse,
)

__all__ = ["NylasResource", "AsyncNylasResource"]


class NylasResource(SyncAPIResource):
    @cached_property
    def grants(self) -> GrantsResource:
        return GrantsResource(self._client)

    @cached_property
    def calendar_configs(self) -> CalendarConfigsResource:
        return CalendarConfigsResource(self._client)

    @cached_property
    def with_raw_response(self) -> NylasResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return NylasResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> NylasResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return NylasResourceWithStreamingResponse(self)


class AsyncNylasResource(AsyncAPIResource):
    @cached_property
    def grants(self) -> AsyncGrantsResource:
        return AsyncGrantsResource(self._client)

    @cached_property
    def calendar_configs(self) -> AsyncCalendarConfigsResource:
        return AsyncCalendarConfigsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncNylasResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncNylasResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncNylasResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncNylasResourceWithStreamingResponse(self)


class NylasResourceWithRawResponse:
    def __init__(self, nylas: NylasResource) -> None:
        self._nylas = nylas

    @cached_property
    def grants(self) -> GrantsResourceWithRawResponse:
        return GrantsResourceWithRawResponse(self._nylas.grants)

    @cached_property
    def calendar_configs(self) -> CalendarConfigsResourceWithRawResponse:
        return CalendarConfigsResourceWithRawResponse(self._nylas.calendar_configs)


class AsyncNylasResourceWithRawResponse:
    def __init__(self, nylas: AsyncNylasResource) -> None:
        self._nylas = nylas

    @cached_property
    def grants(self) -> AsyncGrantsResourceWithRawResponse:
        return AsyncGrantsResourceWithRawResponse(self._nylas.grants)

    @cached_property
    def calendar_configs(self) -> AsyncCalendarConfigsResourceWithRawResponse:
        return AsyncCalendarConfigsResourceWithRawResponse(self._nylas.calendar_configs)


class NylasResourceWithStreamingResponse:
    def __init__(self, nylas: NylasResource) -> None:
        self._nylas = nylas

    @cached_property
    def grants(self) -> GrantsResourceWithStreamingResponse:
        return GrantsResourceWithStreamingResponse(self._nylas.grants)

    @cached_property
    def calendar_configs(self) -> CalendarConfigsResourceWithStreamingResponse:
        return CalendarConfigsResourceWithStreamingResponse(self._nylas.calendar_configs)


class AsyncNylasResourceWithStreamingResponse:
    def __init__(self, nylas: AsyncNylasResource) -> None:
        self._nylas = nylas

    @cached_property
    def grants(self) -> AsyncGrantsResourceWithStreamingResponse:
        return AsyncGrantsResourceWithStreamingResponse(self._nylas.grants)

    @cached_property
    def calendar_configs(self) -> AsyncCalendarConfigsResourceWithStreamingResponse:
        return AsyncCalendarConfigsResourceWithStreamingResponse(self._nylas.calendar_configs)
