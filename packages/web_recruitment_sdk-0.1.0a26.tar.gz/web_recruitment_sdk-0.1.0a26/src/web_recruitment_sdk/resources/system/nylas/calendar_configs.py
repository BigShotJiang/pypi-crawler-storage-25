# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional

import httpx

from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.system.nylas import (
    calendar_config_list_calendar_configs_params,
    calendar_config_create_calendar_config_params,
    calendar_config_update_calendar_config_params,
)
from ....types.system.nylas.calendar_config_get_calendar_config_response import CalendarConfigGetCalendarConfigResponse
from ....types.system.nylas.calendar_config_list_calendar_configs_response import (
    CalendarConfigListCalendarConfigsResponse,
)
from ....types.system.nylas.calendar_config_create_calendar_config_response import (
    CalendarConfigCreateCalendarConfigResponse,
)
from ....types.system.nylas.calendar_config_update_calendar_config_response import (
    CalendarConfigUpdateCalendarConfigResponse,
)

__all__ = ["CalendarConfigsResource", "AsyncCalendarConfigsResource"]


class CalendarConfigsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CalendarConfigsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return CalendarConfigsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CalendarConfigsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return CalendarConfigsResourceWithStreamingResponse(self)

    def create_calendar_config(
        self,
        tenant_db_name: str,
        *,
        duration_minutes: int,
        grant_id: int,
        interval_minutes: int,
        name: str,
        timezone: str,
        buffer_minutes: int | Omit = omit,
        open_hours: Iterable[object] | Omit = omit,
        specific_availability: Optional[Iterable[calendar_config_create_calendar_config_params.SpecificAvailability]]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CalendarConfigCreateCalendarConfigResponse:
        """
        Create a calendar on an existing grant and persist its config.

        Args:
          duration_minutes: Slot duration in minutes

          grant_id: Internal ID of the NylasGrant to use

          interval_minutes: Gap between slot start times in minutes

          name: Display name for the calendar

          timezone: IANA timezone (e.g. America/New_York)

          buffer_minutes: Buffer around meetings in minutes

          open_hours: Weekly open_hours rules [{days, start, end, timezone, exdates}]

          specific_availability: Date-specific availability windows. When set, overrides open_hours.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/nylas/calendar-configs", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "duration_minutes": duration_minutes,
                    "grant_id": grant_id,
                    "interval_minutes": interval_minutes,
                    "name": name,
                    "timezone": timezone,
                    "buffer_minutes": buffer_minutes,
                    "open_hours": open_hours,
                    "specific_availability": specific_availability,
                },
                calendar_config_create_calendar_config_params.CalendarConfigCreateCalendarConfigParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CalendarConfigCreateCalendarConfigResponse,
        )

    def delete_calendar_config(
        self,
        config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a Nylas calendar config.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template(
                "/system/{tenant_db_name}/nylas/calendar-configs/{config_id}",
                tenant_db_name=tenant_db_name,
                config_id=config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get_calendar_config(
        self,
        config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CalendarConfigGetCalendarConfigResponse:
        """
        Get a Nylas calendar config by ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template(
                "/system/{tenant_db_name}/nylas/calendar-configs/{config_id}",
                tenant_db_name=tenant_db_name,
                config_id=config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CalendarConfigGetCalendarConfigResponse,
        )

    def list_calendar_configs(
        self,
        tenant_db_name: str,
        *,
        is_active: Optional[bool] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CalendarConfigListCalendarConfigsResponse:
        """
        List Nylas calendar configs, optionally filtered by active status.

        Args:
          is_active: Filter by active status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/nylas/calendar-configs", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"is_active": is_active},
                    calendar_config_list_calendar_configs_params.CalendarConfigListCalendarConfigsParams,
                ),
            ),
            cast_to=CalendarConfigListCalendarConfigsResponse,
        )

    def update_calendar_config(
        self,
        config_id: int,
        *,
        tenant_db_name: str,
        buffer_minutes: Optional[int] | Omit = omit,
        duration_minutes: Optional[int] | Omit = omit,
        interval_minutes: Optional[int] | Omit = omit,
        is_active: Optional[bool] | Omit = omit,
        name: Optional[str] | Omit = omit,
        open_hours: Optional[Iterable[object]] | Omit = omit,
        specific_availability: Optional[Iterable[calendar_config_update_calendar_config_params.SpecificAvailability]]
        | Omit = omit,
        timezone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CalendarConfigUpdateCalendarConfigResponse:
        """
        Update a Nylas calendar config (partial update).

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._patch(
            path_template(
                "/system/{tenant_db_name}/nylas/calendar-configs/{config_id}",
                tenant_db_name=tenant_db_name,
                config_id=config_id,
            ),
            body=maybe_transform(
                {
                    "buffer_minutes": buffer_minutes,
                    "duration_minutes": duration_minutes,
                    "interval_minutes": interval_minutes,
                    "is_active": is_active,
                    "name": name,
                    "open_hours": open_hours,
                    "specific_availability": specific_availability,
                    "timezone": timezone,
                },
                calendar_config_update_calendar_config_params.CalendarConfigUpdateCalendarConfigParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CalendarConfigUpdateCalendarConfigResponse,
        )


class AsyncCalendarConfigsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCalendarConfigsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCalendarConfigsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCalendarConfigsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncCalendarConfigsResourceWithStreamingResponse(self)

    async def create_calendar_config(
        self,
        tenant_db_name: str,
        *,
        duration_minutes: int,
        grant_id: int,
        interval_minutes: int,
        name: str,
        timezone: str,
        buffer_minutes: int | Omit = omit,
        open_hours: Iterable[object] | Omit = omit,
        specific_availability: Optional[Iterable[calendar_config_create_calendar_config_params.SpecificAvailability]]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CalendarConfigCreateCalendarConfigResponse:
        """
        Create a calendar on an existing grant and persist its config.

        Args:
          duration_minutes: Slot duration in minutes

          grant_id: Internal ID of the NylasGrant to use

          interval_minutes: Gap between slot start times in minutes

          name: Display name for the calendar

          timezone: IANA timezone (e.g. America/New_York)

          buffer_minutes: Buffer around meetings in minutes

          open_hours: Weekly open_hours rules [{days, start, end, timezone, exdates}]

          specific_availability: Date-specific availability windows. When set, overrides open_hours.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/nylas/calendar-configs", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "duration_minutes": duration_minutes,
                    "grant_id": grant_id,
                    "interval_minutes": interval_minutes,
                    "name": name,
                    "timezone": timezone,
                    "buffer_minutes": buffer_minutes,
                    "open_hours": open_hours,
                    "specific_availability": specific_availability,
                },
                calendar_config_create_calendar_config_params.CalendarConfigCreateCalendarConfigParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CalendarConfigCreateCalendarConfigResponse,
        )

    async def delete_calendar_config(
        self,
        config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a Nylas calendar config.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template(
                "/system/{tenant_db_name}/nylas/calendar-configs/{config_id}",
                tenant_db_name=tenant_db_name,
                config_id=config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get_calendar_config(
        self,
        config_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CalendarConfigGetCalendarConfigResponse:
        """
        Get a Nylas calendar config by ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template(
                "/system/{tenant_db_name}/nylas/calendar-configs/{config_id}",
                tenant_db_name=tenant_db_name,
                config_id=config_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CalendarConfigGetCalendarConfigResponse,
        )

    async def list_calendar_configs(
        self,
        tenant_db_name: str,
        *,
        is_active: Optional[bool] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CalendarConfigListCalendarConfigsResponse:
        """
        List Nylas calendar configs, optionally filtered by active status.

        Args:
          is_active: Filter by active status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/nylas/calendar-configs", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"is_active": is_active},
                    calendar_config_list_calendar_configs_params.CalendarConfigListCalendarConfigsParams,
                ),
            ),
            cast_to=CalendarConfigListCalendarConfigsResponse,
        )

    async def update_calendar_config(
        self,
        config_id: int,
        *,
        tenant_db_name: str,
        buffer_minutes: Optional[int] | Omit = omit,
        duration_minutes: Optional[int] | Omit = omit,
        interval_minutes: Optional[int] | Omit = omit,
        is_active: Optional[bool] | Omit = omit,
        name: Optional[str] | Omit = omit,
        open_hours: Optional[Iterable[object]] | Omit = omit,
        specific_availability: Optional[Iterable[calendar_config_update_calendar_config_params.SpecificAvailability]]
        | Omit = omit,
        timezone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CalendarConfigUpdateCalendarConfigResponse:
        """
        Update a Nylas calendar config (partial update).

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._patch(
            path_template(
                "/system/{tenant_db_name}/nylas/calendar-configs/{config_id}",
                tenant_db_name=tenant_db_name,
                config_id=config_id,
            ),
            body=await async_maybe_transform(
                {
                    "buffer_minutes": buffer_minutes,
                    "duration_minutes": duration_minutes,
                    "interval_minutes": interval_minutes,
                    "is_active": is_active,
                    "name": name,
                    "open_hours": open_hours,
                    "specific_availability": specific_availability,
                    "timezone": timezone,
                },
                calendar_config_update_calendar_config_params.CalendarConfigUpdateCalendarConfigParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CalendarConfigUpdateCalendarConfigResponse,
        )


class CalendarConfigsResourceWithRawResponse:
    def __init__(self, calendar_configs: CalendarConfigsResource) -> None:
        self._calendar_configs = calendar_configs

        self.create_calendar_config = to_raw_response_wrapper(
            calendar_configs.create_calendar_config,
        )
        self.delete_calendar_config = to_raw_response_wrapper(
            calendar_configs.delete_calendar_config,
        )
        self.get_calendar_config = to_raw_response_wrapper(
            calendar_configs.get_calendar_config,
        )
        self.list_calendar_configs = to_raw_response_wrapper(
            calendar_configs.list_calendar_configs,
        )
        self.update_calendar_config = to_raw_response_wrapper(
            calendar_configs.update_calendar_config,
        )


class AsyncCalendarConfigsResourceWithRawResponse:
    def __init__(self, calendar_configs: AsyncCalendarConfigsResource) -> None:
        self._calendar_configs = calendar_configs

        self.create_calendar_config = async_to_raw_response_wrapper(
            calendar_configs.create_calendar_config,
        )
        self.delete_calendar_config = async_to_raw_response_wrapper(
            calendar_configs.delete_calendar_config,
        )
        self.get_calendar_config = async_to_raw_response_wrapper(
            calendar_configs.get_calendar_config,
        )
        self.list_calendar_configs = async_to_raw_response_wrapper(
            calendar_configs.list_calendar_configs,
        )
        self.update_calendar_config = async_to_raw_response_wrapper(
            calendar_configs.update_calendar_config,
        )


class CalendarConfigsResourceWithStreamingResponse:
    def __init__(self, calendar_configs: CalendarConfigsResource) -> None:
        self._calendar_configs = calendar_configs

        self.create_calendar_config = to_streamed_response_wrapper(
            calendar_configs.create_calendar_config,
        )
        self.delete_calendar_config = to_streamed_response_wrapper(
            calendar_configs.delete_calendar_config,
        )
        self.get_calendar_config = to_streamed_response_wrapper(
            calendar_configs.get_calendar_config,
        )
        self.list_calendar_configs = to_streamed_response_wrapper(
            calendar_configs.list_calendar_configs,
        )
        self.update_calendar_config = to_streamed_response_wrapper(
            calendar_configs.update_calendar_config,
        )


class AsyncCalendarConfigsResourceWithStreamingResponse:
    def __init__(self, calendar_configs: AsyncCalendarConfigsResource) -> None:
        self._calendar_configs = calendar_configs

        self.create_calendar_config = async_to_streamed_response_wrapper(
            calendar_configs.create_calendar_config,
        )
        self.delete_calendar_config = async_to_streamed_response_wrapper(
            calendar_configs.delete_calendar_config,
        )
        self.get_calendar_config = async_to_streamed_response_wrapper(
            calendar_configs.get_calendar_config,
        )
        self.list_calendar_configs = async_to_streamed_response_wrapper(
            calendar_configs.list_calendar_configs,
        )
        self.update_calendar_config = async_to_streamed_response_wrapper(
            calendar_configs.update_calendar_config,
        )
