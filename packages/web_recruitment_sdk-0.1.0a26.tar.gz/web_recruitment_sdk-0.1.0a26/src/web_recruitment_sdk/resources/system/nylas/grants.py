# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.system.nylas import grant_list_grants_params, grant_create_grant_params
from ....types.system.nylas.grant_get_grant_response import GrantGetGrantResponse
from ....types.system.nylas.grant_list_grants_response import GrantListGrantsResponse
from ....types.system.nylas.grant_create_grant_response import GrantCreateGrantResponse

__all__ = ["GrantsResource", "AsyncGrantsResource"]


class GrantsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> GrantsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return GrantsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> GrantsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return GrantsResourceWithStreamingResponse(self)

    def create_grant(
        self,
        tenant_db_name: str,
        *,
        email: str,
        name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GrantCreateGrantResponse:
        """
        Create a virtual grant for the tenant (one-time per tenant for MVP).

        Args:
          email: Synthetic email for the virtual grant (e.g. ppcp@trially.scheduling)

          name: Optional display name for the grant

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/nylas/grants", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "email": email,
                    "name": name,
                },
                grant_create_grant_params.GrantCreateGrantParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=GrantCreateGrantResponse,
        )

    def delete_grant(
        self,
        grant_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a Nylas grant.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template(
                "/system/{tenant_db_name}/nylas/grants/{grant_id}", tenant_db_name=tenant_db_name, grant_id=grant_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get_grant(
        self,
        grant_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GrantGetGrantResponse:
        """
        Get a Nylas grant by ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template(
                "/system/{tenant_db_name}/nylas/grants/{grant_id}", tenant_db_name=tenant_db_name, grant_id=grant_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=GrantGetGrantResponse,
        )

    def list_grants(
        self,
        tenant_db_name: str,
        *,
        is_active: Optional[bool] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GrantListGrantsResponse:
        """
        List all Nylas grants for the tenant.

        Args:
          is_active: Filter by active status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/nylas/grants", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"is_active": is_active}, grant_list_grants_params.GrantListGrantsParams),
            ),
            cast_to=GrantListGrantsResponse,
        )


class AsyncGrantsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncGrantsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncGrantsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncGrantsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncGrantsResourceWithStreamingResponse(self)

    async def create_grant(
        self,
        tenant_db_name: str,
        *,
        email: str,
        name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GrantCreateGrantResponse:
        """
        Create a virtual grant for the tenant (one-time per tenant for MVP).

        Args:
          email: Synthetic email for the virtual grant (e.g. ppcp@trially.scheduling)

          name: Optional display name for the grant

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/nylas/grants", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "email": email,
                    "name": name,
                },
                grant_create_grant_params.GrantCreateGrantParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=GrantCreateGrantResponse,
        )

    async def delete_grant(
        self,
        grant_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a Nylas grant.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template(
                "/system/{tenant_db_name}/nylas/grants/{grant_id}", tenant_db_name=tenant_db_name, grant_id=grant_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get_grant(
        self,
        grant_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GrantGetGrantResponse:
        """
        Get a Nylas grant by ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template(
                "/system/{tenant_db_name}/nylas/grants/{grant_id}", tenant_db_name=tenant_db_name, grant_id=grant_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=GrantGetGrantResponse,
        )

    async def list_grants(
        self,
        tenant_db_name: str,
        *,
        is_active: Optional[bool] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GrantListGrantsResponse:
        """
        List all Nylas grants for the tenant.

        Args:
          is_active: Filter by active status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/nylas/grants", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"is_active": is_active}, grant_list_grants_params.GrantListGrantsParams
                ),
            ),
            cast_to=GrantListGrantsResponse,
        )


class GrantsResourceWithRawResponse:
    def __init__(self, grants: GrantsResource) -> None:
        self._grants = grants

        self.create_grant = to_raw_response_wrapper(
            grants.create_grant,
        )
        self.delete_grant = to_raw_response_wrapper(
            grants.delete_grant,
        )
        self.get_grant = to_raw_response_wrapper(
            grants.get_grant,
        )
        self.list_grants = to_raw_response_wrapper(
            grants.list_grants,
        )


class AsyncGrantsResourceWithRawResponse:
    def __init__(self, grants: AsyncGrantsResource) -> None:
        self._grants = grants

        self.create_grant = async_to_raw_response_wrapper(
            grants.create_grant,
        )
        self.delete_grant = async_to_raw_response_wrapper(
            grants.delete_grant,
        )
        self.get_grant = async_to_raw_response_wrapper(
            grants.get_grant,
        )
        self.list_grants = async_to_raw_response_wrapper(
            grants.list_grants,
        )


class GrantsResourceWithStreamingResponse:
    def __init__(self, grants: GrantsResource) -> None:
        self._grants = grants

        self.create_grant = to_streamed_response_wrapper(
            grants.create_grant,
        )
        self.delete_grant = to_streamed_response_wrapper(
            grants.delete_grant,
        )
        self.get_grant = to_streamed_response_wrapper(
            grants.get_grant,
        )
        self.list_grants = to_streamed_response_wrapper(
            grants.list_grants,
        )


class AsyncGrantsResourceWithStreamingResponse:
    def __init__(self, grants: AsyncGrantsResource) -> None:
        self._grants = grants

        self.create_grant = async_to_streamed_response_wrapper(
            grants.create_grant,
        )
        self.delete_grant = async_to_streamed_response_wrapper(
            grants.delete_grant,
        )
        self.get_grant = async_to_streamed_response_wrapper(
            grants.get_grant,
        )
        self.list_grants = async_to_streamed_response_wrapper(
            grants.list_grants,
        )
