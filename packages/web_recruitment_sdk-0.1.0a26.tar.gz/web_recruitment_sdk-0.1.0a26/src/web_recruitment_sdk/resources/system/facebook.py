# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.system import facebook_process_lead_params
from ...types.system.facebook_process_lead_response import FacebookProcessLeadResponse

__all__ = ["FacebookResource", "AsyncFacebookResource"]


class FacebookResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> FacebookResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return FacebookResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FacebookResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return FacebookResourceWithStreamingResponse(self)

    def process_lead(
        self,
        page_id: str,
        *,
        webhook_data: object,
        webhook_type: Literal["booking_link_clicked", "facebook_lead_received", "twilio_inbound_sms"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FacebookProcessLeadResponse:
        """
        Process a Facebook lead from Cloud Tasks.

        This endpoint receives lead processing requests from Cloud Tasks and:

        1. Discovers tenant by page_id (via dependency)
        2. Validates the webhook type
        3. Processes the lead via FacebookLeadService

        Note: This endpoint does NOT use tenant_db_name in the path - it discovers the
        tenant from the page_id via FacebookAccountConfig lookup and loads the page
        token from the tenant database.

        Args: page_id: Facebook Page ID from the URL path webhook_payload: Webhook task
        payload containing lead data facebook_lead_service: FacebookLeadService from
        dependency

        Returns: LeadIntakeResponse: Response with created record IDs

        Raises: 400: Invalid webhook type or invalid lead data 404: Page not configured
        or form not mapped 502: Facebook API error (allows Cloud Tasks retry)

        Args:
          page_id: Facebook Page ID

          webhook_type: Types of webhooks.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not page_id:
            raise ValueError(f"Expected a non-empty value for `page_id` but received {page_id!r}")
        return self._post(
            path_template("/system/facebook/leads/{page_id}", page_id=page_id),
            body=maybe_transform(
                {
                    "webhook_data": webhook_data,
                    "webhook_type": webhook_type,
                },
                facebook_process_lead_params.FacebookProcessLeadParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FacebookProcessLeadResponse,
        )


class AsyncFacebookResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncFacebookResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncFacebookResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFacebookResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncFacebookResourceWithStreamingResponse(self)

    async def process_lead(
        self,
        page_id: str,
        *,
        webhook_data: object,
        webhook_type: Literal["booking_link_clicked", "facebook_lead_received", "twilio_inbound_sms"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FacebookProcessLeadResponse:
        """
        Process a Facebook lead from Cloud Tasks.

        This endpoint receives lead processing requests from Cloud Tasks and:

        1. Discovers tenant by page_id (via dependency)
        2. Validates the webhook type
        3. Processes the lead via FacebookLeadService

        Note: This endpoint does NOT use tenant_db_name in the path - it discovers the
        tenant from the page_id via FacebookAccountConfig lookup and loads the page
        token from the tenant database.

        Args: page_id: Facebook Page ID from the URL path webhook_payload: Webhook task
        payload containing lead data facebook_lead_service: FacebookLeadService from
        dependency

        Returns: LeadIntakeResponse: Response with created record IDs

        Raises: 400: Invalid webhook type or invalid lead data 404: Page not configured
        or form not mapped 502: Facebook API error (allows Cloud Tasks retry)

        Args:
          page_id: Facebook Page ID

          webhook_type: Types of webhooks.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not page_id:
            raise ValueError(f"Expected a non-empty value for `page_id` but received {page_id!r}")
        return await self._post(
            path_template("/system/facebook/leads/{page_id}", page_id=page_id),
            body=await async_maybe_transform(
                {
                    "webhook_data": webhook_data,
                    "webhook_type": webhook_type,
                },
                facebook_process_lead_params.FacebookProcessLeadParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FacebookProcessLeadResponse,
        )


class FacebookResourceWithRawResponse:
    def __init__(self, facebook: FacebookResource) -> None:
        self._facebook = facebook

        self.process_lead = to_raw_response_wrapper(
            facebook.process_lead,
        )


class AsyncFacebookResourceWithRawResponse:
    def __init__(self, facebook: AsyncFacebookResource) -> None:
        self._facebook = facebook

        self.process_lead = async_to_raw_response_wrapper(
            facebook.process_lead,
        )


class FacebookResourceWithStreamingResponse:
    def __init__(self, facebook: FacebookResource) -> None:
        self._facebook = facebook

        self.process_lead = to_streamed_response_wrapper(
            facebook.process_lead,
        )


class AsyncFacebookResourceWithStreamingResponse:
    def __init__(self, facebook: AsyncFacebookResource) -> None:
        self._facebook = facebook

        self.process_lead = async_to_streamed_response_wrapper(
            facebook.process_lead,
        )
