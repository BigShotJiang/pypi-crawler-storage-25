# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..types import clinical_conductor_list_study_configs_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.clinical_conductor_list_study_configs_response import ClinicalConductorListStudyConfigsResponse

__all__ = ["ClinicalConductorResource", "AsyncClinicalConductorResource"]


class ClinicalConductorResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ClinicalConductorResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return ClinicalConductorResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ClinicalConductorResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return ClinicalConductorResourceWithStreamingResponse(self)

    def list_study_configs(
        self,
        *,
        instance_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ClinicalConductorListStudyConfigsResponse:
        """
        List Clinical Conductor study configs for admin appointment configuration.

        Args:
          instance_id: Optional instance ID to filter by

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/clinical-conductor/study-configs",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"instance_id": instance_id},
                    clinical_conductor_list_study_configs_params.ClinicalConductorListStudyConfigsParams,
                ),
            ),
            cast_to=ClinicalConductorListStudyConfigsResponse,
        )


class AsyncClinicalConductorResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncClinicalConductorResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncClinicalConductorResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncClinicalConductorResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncClinicalConductorResourceWithStreamingResponse(self)

    async def list_study_configs(
        self,
        *,
        instance_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ClinicalConductorListStudyConfigsResponse:
        """
        List Clinical Conductor study configs for admin appointment configuration.

        Args:
          instance_id: Optional instance ID to filter by

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/clinical-conductor/study-configs",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"instance_id": instance_id},
                    clinical_conductor_list_study_configs_params.ClinicalConductorListStudyConfigsParams,
                ),
            ),
            cast_to=ClinicalConductorListStudyConfigsResponse,
        )


class ClinicalConductorResourceWithRawResponse:
    def __init__(self, clinical_conductor: ClinicalConductorResource) -> None:
        self._clinical_conductor = clinical_conductor

        self.list_study_configs = to_raw_response_wrapper(
            clinical_conductor.list_study_configs,
        )


class AsyncClinicalConductorResourceWithRawResponse:
    def __init__(self, clinical_conductor: AsyncClinicalConductorResource) -> None:
        self._clinical_conductor = clinical_conductor

        self.list_study_configs = async_to_raw_response_wrapper(
            clinical_conductor.list_study_configs,
        )


class ClinicalConductorResourceWithStreamingResponse:
    def __init__(self, clinical_conductor: ClinicalConductorResource) -> None:
        self._clinical_conductor = clinical_conductor

        self.list_study_configs = to_streamed_response_wrapper(
            clinical_conductor.list_study_configs,
        )


class AsyncClinicalConductorResourceWithStreamingResponse:
    def __init__(self, clinical_conductor: AsyncClinicalConductorResource) -> None:
        self._clinical_conductor = clinical_conductor

        self.list_study_configs = async_to_streamed_response_wrapper(
            clinical_conductor.list_study_configs,
        )
