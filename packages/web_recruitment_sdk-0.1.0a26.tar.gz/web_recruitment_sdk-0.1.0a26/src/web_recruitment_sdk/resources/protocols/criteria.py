# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ...types import CriteriaType
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.protocols import (
    criterion_create_params,
    criterion_update_params,
    criterion_set_priority_params,
    criterion_get_matching_progress_params,
)
from ...types.criteria_type import CriteriaType
from ...types.custom_searches import CriteriaStatus
from ...types.custom_searches.criteria_read import CriteriaRead
from ...types.custom_searches.criteria_status import CriteriaStatus
from ...types.protocols.criterion_list_response import CriterionListResponse
from ...types.protocols.criterion_get_matching_progress_response import CriterionGetMatchingProgressResponse

__all__ = ["CriteriaResource", "AsyncCriteriaResource"]


class CriteriaResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CriteriaResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return CriteriaResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CriteriaResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return CriteriaResourceWithStreamingResponse(self)

    def create(
        self,
        path_protocol_id: int,
        *,
        summary: str,
        type: CriteriaType,
        criteria_protocol_metadata_id: Optional[int] | Omit = omit,
        custom_search_id: Optional[int] | Omit = omit,
        description: Optional[str] | Omit = omit,
        is_priority: bool | Omit = omit,
        matching_payload: Optional[criterion_create_params.MatchingPayload] | Omit = omit,
        priority_order: Optional[int] | Omit = omit,
        body_protocol_id: Optional[int] | Omit = omit,
        status: CriteriaStatus | Omit = omit,
        user_raw_input: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriteriaRead:
        """
        Create Protocol Criterion

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            path_template("/protocols/{path_protocol_id}/criteria", path_protocol_id=path_protocol_id),
            body=maybe_transform(
                {
                    "summary": summary,
                    "type": type,
                    "criteria_protocol_metadata_id": criteria_protocol_metadata_id,
                    "custom_search_id": custom_search_id,
                    "description": description,
                    "is_priority": is_priority,
                    "matching_payload": matching_payload,
                    "priority_order": priority_order,
                    "body_protocol_id": body_protocol_id,
                    "status": status,
                    "user_raw_input": user_raw_input,
                },
                criterion_create_params.CriterionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CriteriaRead,
        )

    def update(
        self,
        criterion_id: int,
        *,
        path_protocol_id: int,
        summary: str,
        type: CriteriaType,
        criteria_protocol_metadata_id: Optional[int] | Omit = omit,
        custom_search_id: Optional[int] | Omit = omit,
        description: Optional[str] | Omit = omit,
        is_priority: bool | Omit = omit,
        matching_payload: Optional[criterion_update_params.MatchingPayload] | Omit = omit,
        priority_order: Optional[int] | Omit = omit,
        body_protocol_id: Optional[int] | Omit = omit,
        status: CriteriaStatus | Omit = omit,
        user_raw_input: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriteriaRead:
        """
        Update Protocol Criterion

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._put(
            path_template(
                "/protocols/{path_protocol_id}/criteria/{criterion_id}",
                path_protocol_id=path_protocol_id,
                criterion_id=criterion_id,
            ),
            body=maybe_transform(
                {
                    "summary": summary,
                    "type": type,
                    "criteria_protocol_metadata_id": criteria_protocol_metadata_id,
                    "custom_search_id": custom_search_id,
                    "description": description,
                    "is_priority": is_priority,
                    "matching_payload": matching_payload,
                    "priority_order": priority_order,
                    "body_protocol_id": body_protocol_id,
                    "status": status,
                    "user_raw_input": user_raw_input,
                },
                criterion_update_params.CriterionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CriteriaRead,
        )

    def list(
        self,
        protocol_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriterionListResponse:
        """
        Get Protocol Criteria

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            path_template("/protocols/{protocol_id}/criteria", protocol_id=protocol_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CriterionListResponse,
        )

    def delete(
        self,
        criterion_id: int,
        *,
        protocol_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete Protocol Criterion

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template(
                "/protocols/{protocol_id}/criteria/{criterion_id}", protocol_id=protocol_id, criterion_id=criterion_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get_matching_progress(
        self,
        protocol_id: int,
        *,
        enable_sites_breakdown: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriterionGetMatchingProgressResponse:
        """
        Get matching progress information for a protocol's criteria.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            path_template("/protocols/{protocol_id}/criteria/matching-progress", protocol_id=protocol_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"enable_sites_breakdown": enable_sites_breakdown},
                    criterion_get_matching_progress_params.CriterionGetMatchingProgressParams,
                ),
            ),
            cast_to=CriterionGetMatchingProgressResponse,
        )

    def set_priority(
        self,
        criterion_id: int,
        *,
        protocol_id: int,
        is_priority: bool,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriteriaRead:
        """
        Set or remove priority status for a protocol criterion.

        Max 3 priority criteria allowed per protocol. Priority can only be changed when
        protocol is in IN_REVIEW status.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._put(
            path_template(
                "/protocols/{protocol_id}/criteria/{criterion_id}/priority",
                protocol_id=protocol_id,
                criterion_id=criterion_id,
            ),
            body=maybe_transform(
                {"is_priority": is_priority}, criterion_set_priority_params.CriterionSetPriorityParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CriteriaRead,
        )


class AsyncCriteriaResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCriteriaResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCriteriaResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCriteriaResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncCriteriaResourceWithStreamingResponse(self)

    async def create(
        self,
        path_protocol_id: int,
        *,
        summary: str,
        type: CriteriaType,
        criteria_protocol_metadata_id: Optional[int] | Omit = omit,
        custom_search_id: Optional[int] | Omit = omit,
        description: Optional[str] | Omit = omit,
        is_priority: bool | Omit = omit,
        matching_payload: Optional[criterion_create_params.MatchingPayload] | Omit = omit,
        priority_order: Optional[int] | Omit = omit,
        body_protocol_id: Optional[int] | Omit = omit,
        status: CriteriaStatus | Omit = omit,
        user_raw_input: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriteriaRead:
        """
        Create Protocol Criterion

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            path_template("/protocols/{path_protocol_id}/criteria", path_protocol_id=path_protocol_id),
            body=await async_maybe_transform(
                {
                    "summary": summary,
                    "type": type,
                    "criteria_protocol_metadata_id": criteria_protocol_metadata_id,
                    "custom_search_id": custom_search_id,
                    "description": description,
                    "is_priority": is_priority,
                    "matching_payload": matching_payload,
                    "priority_order": priority_order,
                    "body_protocol_id": body_protocol_id,
                    "status": status,
                    "user_raw_input": user_raw_input,
                },
                criterion_create_params.CriterionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CriteriaRead,
        )

    async def update(
        self,
        criterion_id: int,
        *,
        path_protocol_id: int,
        summary: str,
        type: CriteriaType,
        criteria_protocol_metadata_id: Optional[int] | Omit = omit,
        custom_search_id: Optional[int] | Omit = omit,
        description: Optional[str] | Omit = omit,
        is_priority: bool | Omit = omit,
        matching_payload: Optional[criterion_update_params.MatchingPayload] | Omit = omit,
        priority_order: Optional[int] | Omit = omit,
        body_protocol_id: Optional[int] | Omit = omit,
        status: CriteriaStatus | Omit = omit,
        user_raw_input: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriteriaRead:
        """
        Update Protocol Criterion

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._put(
            path_template(
                "/protocols/{path_protocol_id}/criteria/{criterion_id}",
                path_protocol_id=path_protocol_id,
                criterion_id=criterion_id,
            ),
            body=await async_maybe_transform(
                {
                    "summary": summary,
                    "type": type,
                    "criteria_protocol_metadata_id": criteria_protocol_metadata_id,
                    "custom_search_id": custom_search_id,
                    "description": description,
                    "is_priority": is_priority,
                    "matching_payload": matching_payload,
                    "priority_order": priority_order,
                    "body_protocol_id": body_protocol_id,
                    "status": status,
                    "user_raw_input": user_raw_input,
                },
                criterion_update_params.CriterionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CriteriaRead,
        )

    async def list(
        self,
        protocol_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriterionListResponse:
        """
        Get Protocol Criteria

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            path_template("/protocols/{protocol_id}/criteria", protocol_id=protocol_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CriterionListResponse,
        )

    async def delete(
        self,
        criterion_id: int,
        *,
        protocol_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete Protocol Criterion

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template(
                "/protocols/{protocol_id}/criteria/{criterion_id}", protocol_id=protocol_id, criterion_id=criterion_id
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get_matching_progress(
        self,
        protocol_id: int,
        *,
        enable_sites_breakdown: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriterionGetMatchingProgressResponse:
        """
        Get matching progress information for a protocol's criteria.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            path_template("/protocols/{protocol_id}/criteria/matching-progress", protocol_id=protocol_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"enable_sites_breakdown": enable_sites_breakdown},
                    criterion_get_matching_progress_params.CriterionGetMatchingProgressParams,
                ),
            ),
            cast_to=CriterionGetMatchingProgressResponse,
        )

    async def set_priority(
        self,
        criterion_id: int,
        *,
        protocol_id: int,
        is_priority: bool,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CriteriaRead:
        """
        Set or remove priority status for a protocol criterion.

        Max 3 priority criteria allowed per protocol. Priority can only be changed when
        protocol is in IN_REVIEW status.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._put(
            path_template(
                "/protocols/{protocol_id}/criteria/{criterion_id}/priority",
                protocol_id=protocol_id,
                criterion_id=criterion_id,
            ),
            body=await async_maybe_transform(
                {"is_priority": is_priority}, criterion_set_priority_params.CriterionSetPriorityParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CriteriaRead,
        )


class CriteriaResourceWithRawResponse:
    def __init__(self, criteria: CriteriaResource) -> None:
        self._criteria = criteria

        self.create = to_raw_response_wrapper(
            criteria.create,
        )
        self.update = to_raw_response_wrapper(
            criteria.update,
        )
        self.list = to_raw_response_wrapper(
            criteria.list,
        )
        self.delete = to_raw_response_wrapper(
            criteria.delete,
        )
        self.get_matching_progress = to_raw_response_wrapper(
            criteria.get_matching_progress,
        )
        self.set_priority = to_raw_response_wrapper(
            criteria.set_priority,
        )


class AsyncCriteriaResourceWithRawResponse:
    def __init__(self, criteria: AsyncCriteriaResource) -> None:
        self._criteria = criteria

        self.create = async_to_raw_response_wrapper(
            criteria.create,
        )
        self.update = async_to_raw_response_wrapper(
            criteria.update,
        )
        self.list = async_to_raw_response_wrapper(
            criteria.list,
        )
        self.delete = async_to_raw_response_wrapper(
            criteria.delete,
        )
        self.get_matching_progress = async_to_raw_response_wrapper(
            criteria.get_matching_progress,
        )
        self.set_priority = async_to_raw_response_wrapper(
            criteria.set_priority,
        )


class CriteriaResourceWithStreamingResponse:
    def __init__(self, criteria: CriteriaResource) -> None:
        self._criteria = criteria

        self.create = to_streamed_response_wrapper(
            criteria.create,
        )
        self.update = to_streamed_response_wrapper(
            criteria.update,
        )
        self.list = to_streamed_response_wrapper(
            criteria.list,
        )
        self.delete = to_streamed_response_wrapper(
            criteria.delete,
        )
        self.get_matching_progress = to_streamed_response_wrapper(
            criteria.get_matching_progress,
        )
        self.set_priority = to_streamed_response_wrapper(
            criteria.set_priority,
        )


class AsyncCriteriaResourceWithStreamingResponse:
    def __init__(self, criteria: AsyncCriteriaResource) -> None:
        self._criteria = criteria

        self.create = async_to_streamed_response_wrapper(
            criteria.create,
        )
        self.update = async_to_streamed_response_wrapper(
            criteria.update,
        )
        self.list = async_to_streamed_response_wrapper(
            criteria.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            criteria.delete,
        )
        self.get_matching_progress = async_to_streamed_response_wrapper(
            criteria.get_matching_progress,
        )
        self.set_priority = async_to_streamed_response_wrapper(
            criteria.set_priority,
        )
