# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ...types import landing_page_create_params, landing_page_update_params
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from .email_templates import (
    EmailTemplatesResource,
    AsyncEmailTemplatesResource,
    EmailTemplatesResourceWithRawResponse,
    AsyncEmailTemplatesResourceWithRawResponse,
    EmailTemplatesResourceWithStreamingResponse,
    AsyncEmailTemplatesResourceWithStreamingResponse,
)
from ...types.landing_page_list_response import LandingPageListResponse
from ...types.landing_page_create_response import LandingPageCreateResponse
from ...types.landing_page_update_response import LandingPageUpdateResponse
from ...types.landing_page_retrieve_response import LandingPageRetrieveResponse

__all__ = ["LandingPagesResource", "AsyncLandingPagesResource"]


class LandingPagesResource(SyncAPIResource):
    @cached_property
    def email_templates(self) -> EmailTemplatesResource:
        return EmailTemplatesResource(self._client)

    @cached_property
    def with_raw_response(self) -> LandingPagesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return LandingPagesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> LandingPagesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return LandingPagesResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        name: str,
        slug: str,
        study_name: str,
        appointment_config: Optional[landing_page_create_params.AppointmentConfig] | Omit = omit,
        contact_phone: Optional[str] | Omit = omit,
        hero_config: Optional[landing_page_create_params.HeroConfig] | Omit = omit,
        intake_form_config: Optional[landing_page_create_params.IntakeFormConfig] | Omit = omit,
        location: Optional[str] | Omit = omit,
        not_a_match_config: Optional[landing_page_create_params.NotAMatchConfig] | Omit = omit,
        screening_config: Optional[landing_page_create_params.ScreeningConfig] | Omit = omit,
        screening_passed_config: Optional[landing_page_create_params.ScreeningPassedConfig] | Omit = omit,
        timezone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LandingPageCreateResponse:
        """
        Create a new landing page

        Args:
          appointment_config: Per-landing-page appointment configuration stored as JSONB.

              `appointment_type` drives UI content (labels, calendar events, emails).
              `scheduling_provider` determines which external system handles availability and
              booking (e.g. Clinical Conductor, Trially Scheduling).
              `duration_override_minutes` overrides the provider's visit duration for customer
              logistics; applied regardless of active provider.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/landing-pages",
            body=maybe_transform(
                {
                    "name": name,
                    "slug": slug,
                    "study_name": study_name,
                    "appointment_config": appointment_config,
                    "contact_phone": contact_phone,
                    "hero_config": hero_config,
                    "intake_form_config": intake_form_config,
                    "location": location,
                    "not_a_match_config": not_a_match_config,
                    "screening_config": screening_config,
                    "screening_passed_config": screening_passed_config,
                    "timezone": timezone,
                },
                landing_page_create_params.LandingPageCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LandingPageCreateResponse,
        )

    def retrieve(
        self,
        landing_page_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LandingPageRetrieveResponse:
        """
        Get a landing page by ID

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            path_template("/landing-pages/{landing_page_id}", landing_page_id=landing_page_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LandingPageRetrieveResponse,
        )

    def update(
        self,
        landing_page_id: int,
        *,
        appointment_config: Optional[landing_page_update_params.AppointmentConfig] | Omit = omit,
        contact_phone: Optional[str] | Omit = omit,
        hero_config: Optional[landing_page_update_params.HeroConfig] | Omit = omit,
        intake_form_config: Optional[landing_page_update_params.IntakeFormConfig] | Omit = omit,
        location: Optional[str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        not_a_match_config: Optional[landing_page_update_params.NotAMatchConfig] | Omit = omit,
        screening_config: Optional[landing_page_update_params.ScreeningConfig] | Omit = omit,
        screening_passed_config: Optional[landing_page_update_params.ScreeningPassedConfig] | Omit = omit,
        slug: Optional[str] | Omit = omit,
        study_name: Optional[str] | Omit = omit,
        timezone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LandingPageUpdateResponse:
        """
        Update a landing page

        Args:
          appointment_config: Per-landing-page appointment configuration stored as JSONB.

              `appointment_type` drives UI content (labels, calendar events, emails).
              `scheduling_provider` determines which external system handles availability and
              booking (e.g. Clinical Conductor, Trially Scheduling).
              `duration_override_minutes` overrides the provider's visit duration for customer
              logistics; applied regardless of active provider.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._patch(
            path_template("/landing-pages/{landing_page_id}", landing_page_id=landing_page_id),
            body=maybe_transform(
                {
                    "appointment_config": appointment_config,
                    "contact_phone": contact_phone,
                    "hero_config": hero_config,
                    "intake_form_config": intake_form_config,
                    "location": location,
                    "name": name,
                    "not_a_match_config": not_a_match_config,
                    "screening_config": screening_config,
                    "screening_passed_config": screening_passed_config,
                    "slug": slug,
                    "study_name": study_name,
                    "timezone": timezone,
                },
                landing_page_update_params.LandingPageUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LandingPageUpdateResponse,
        )

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LandingPageListResponse:
        """Get all landing pages"""
        return self._get(
            "/landing-pages",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LandingPageListResponse,
        )

    def delete(
        self,
        landing_page_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a landing page (validates no campaigns reference it)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/landing-pages/{landing_page_id}", landing_page_id=landing_page_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncLandingPagesResource(AsyncAPIResource):
    @cached_property
    def email_templates(self) -> AsyncEmailTemplatesResource:
        return AsyncEmailTemplatesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncLandingPagesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncLandingPagesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncLandingPagesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncLandingPagesResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        name: str,
        slug: str,
        study_name: str,
        appointment_config: Optional[landing_page_create_params.AppointmentConfig] | Omit = omit,
        contact_phone: Optional[str] | Omit = omit,
        hero_config: Optional[landing_page_create_params.HeroConfig] | Omit = omit,
        intake_form_config: Optional[landing_page_create_params.IntakeFormConfig] | Omit = omit,
        location: Optional[str] | Omit = omit,
        not_a_match_config: Optional[landing_page_create_params.NotAMatchConfig] | Omit = omit,
        screening_config: Optional[landing_page_create_params.ScreeningConfig] | Omit = omit,
        screening_passed_config: Optional[landing_page_create_params.ScreeningPassedConfig] | Omit = omit,
        timezone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LandingPageCreateResponse:
        """
        Create a new landing page

        Args:
          appointment_config: Per-landing-page appointment configuration stored as JSONB.

              `appointment_type` drives UI content (labels, calendar events, emails).
              `scheduling_provider` determines which external system handles availability and
              booking (e.g. Clinical Conductor, Trially Scheduling).
              `duration_override_minutes` overrides the provider's visit duration for customer
              logistics; applied regardless of active provider.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/landing-pages",
            body=await async_maybe_transform(
                {
                    "name": name,
                    "slug": slug,
                    "study_name": study_name,
                    "appointment_config": appointment_config,
                    "contact_phone": contact_phone,
                    "hero_config": hero_config,
                    "intake_form_config": intake_form_config,
                    "location": location,
                    "not_a_match_config": not_a_match_config,
                    "screening_config": screening_config,
                    "screening_passed_config": screening_passed_config,
                    "timezone": timezone,
                },
                landing_page_create_params.LandingPageCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LandingPageCreateResponse,
        )

    async def retrieve(
        self,
        landing_page_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LandingPageRetrieveResponse:
        """
        Get a landing page by ID

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            path_template("/landing-pages/{landing_page_id}", landing_page_id=landing_page_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LandingPageRetrieveResponse,
        )

    async def update(
        self,
        landing_page_id: int,
        *,
        appointment_config: Optional[landing_page_update_params.AppointmentConfig] | Omit = omit,
        contact_phone: Optional[str] | Omit = omit,
        hero_config: Optional[landing_page_update_params.HeroConfig] | Omit = omit,
        intake_form_config: Optional[landing_page_update_params.IntakeFormConfig] | Omit = omit,
        location: Optional[str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        not_a_match_config: Optional[landing_page_update_params.NotAMatchConfig] | Omit = omit,
        screening_config: Optional[landing_page_update_params.ScreeningConfig] | Omit = omit,
        screening_passed_config: Optional[landing_page_update_params.ScreeningPassedConfig] | Omit = omit,
        slug: Optional[str] | Omit = omit,
        study_name: Optional[str] | Omit = omit,
        timezone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LandingPageUpdateResponse:
        """
        Update a landing page

        Args:
          appointment_config: Per-landing-page appointment configuration stored as JSONB.

              `appointment_type` drives UI content (labels, calendar events, emails).
              `scheduling_provider` determines which external system handles availability and
              booking (e.g. Clinical Conductor, Trially Scheduling).
              `duration_override_minutes` overrides the provider's visit duration for customer
              logistics; applied regardless of active provider.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._patch(
            path_template("/landing-pages/{landing_page_id}", landing_page_id=landing_page_id),
            body=await async_maybe_transform(
                {
                    "appointment_config": appointment_config,
                    "contact_phone": contact_phone,
                    "hero_config": hero_config,
                    "intake_form_config": intake_form_config,
                    "location": location,
                    "name": name,
                    "not_a_match_config": not_a_match_config,
                    "screening_config": screening_config,
                    "screening_passed_config": screening_passed_config,
                    "slug": slug,
                    "study_name": study_name,
                    "timezone": timezone,
                },
                landing_page_update_params.LandingPageUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LandingPageUpdateResponse,
        )

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LandingPageListResponse:
        """Get all landing pages"""
        return await self._get(
            "/landing-pages",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LandingPageListResponse,
        )

    async def delete(
        self,
        landing_page_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a landing page (validates no campaigns reference it)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/landing-pages/{landing_page_id}", landing_page_id=landing_page_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class LandingPagesResourceWithRawResponse:
    def __init__(self, landing_pages: LandingPagesResource) -> None:
        self._landing_pages = landing_pages

        self.create = to_raw_response_wrapper(
            landing_pages.create,
        )
        self.retrieve = to_raw_response_wrapper(
            landing_pages.retrieve,
        )
        self.update = to_raw_response_wrapper(
            landing_pages.update,
        )
        self.list = to_raw_response_wrapper(
            landing_pages.list,
        )
        self.delete = to_raw_response_wrapper(
            landing_pages.delete,
        )

    @cached_property
    def email_templates(self) -> EmailTemplatesResourceWithRawResponse:
        return EmailTemplatesResourceWithRawResponse(self._landing_pages.email_templates)


class AsyncLandingPagesResourceWithRawResponse:
    def __init__(self, landing_pages: AsyncLandingPagesResource) -> None:
        self._landing_pages = landing_pages

        self.create = async_to_raw_response_wrapper(
            landing_pages.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            landing_pages.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            landing_pages.update,
        )
        self.list = async_to_raw_response_wrapper(
            landing_pages.list,
        )
        self.delete = async_to_raw_response_wrapper(
            landing_pages.delete,
        )

    @cached_property
    def email_templates(self) -> AsyncEmailTemplatesResourceWithRawResponse:
        return AsyncEmailTemplatesResourceWithRawResponse(self._landing_pages.email_templates)


class LandingPagesResourceWithStreamingResponse:
    def __init__(self, landing_pages: LandingPagesResource) -> None:
        self._landing_pages = landing_pages

        self.create = to_streamed_response_wrapper(
            landing_pages.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            landing_pages.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            landing_pages.update,
        )
        self.list = to_streamed_response_wrapper(
            landing_pages.list,
        )
        self.delete = to_streamed_response_wrapper(
            landing_pages.delete,
        )

    @cached_property
    def email_templates(self) -> EmailTemplatesResourceWithStreamingResponse:
        return EmailTemplatesResourceWithStreamingResponse(self._landing_pages.email_templates)


class AsyncLandingPagesResourceWithStreamingResponse:
    def __init__(self, landing_pages: AsyncLandingPagesResource) -> None:
        self._landing_pages = landing_pages

        self.create = async_to_streamed_response_wrapper(
            landing_pages.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            landing_pages.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            landing_pages.update,
        )
        self.list = async_to_streamed_response_wrapper(
            landing_pages.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            landing_pages.delete,
        )

    @cached_property
    def email_templates(self) -> AsyncEmailTemplatesResourceWithStreamingResponse:
        return AsyncEmailTemplatesResourceWithStreamingResponse(self._landing_pages.email_templates)
