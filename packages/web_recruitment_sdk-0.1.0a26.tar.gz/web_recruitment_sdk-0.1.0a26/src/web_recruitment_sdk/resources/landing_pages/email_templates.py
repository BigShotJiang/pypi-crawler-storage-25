# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.landing_pages import email_template_update_params
from ...types.landing_pages.email_template_delete_response import EmailTemplateDeleteResponse
from ...types.landing_pages.email_template_update_response import EmailTemplateUpdateResponse

__all__ = ["EmailTemplatesResource", "AsyncEmailTemplatesResource"]


class EmailTemplatesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> EmailTemplatesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return EmailTemplatesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EmailTemplatesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return EmailTemplatesResourceWithStreamingResponse(self)

    def update(
        self,
        template_key: Literal["booking_confirmation", "site_notification"],
        *,
        landing_page_id: int,
        html: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailTemplateUpdateResponse:
        """
        Update a custom email template override for a landing page.

        Args:
          template_key: Identifies which file-based email template can be overridden.

              To add a new overridable template:

              1. Add a member here (value must match the file-based template name prefix)
              2. Add a corresponding `{value}_html` field to EmailConfig
              3. Add the DB-override check in the email sender that loads that template

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not template_key:
            raise ValueError(f"Expected a non-empty value for `template_key` but received {template_key!r}")
        return self._put(
            path_template(
                "/landing-pages/{landing_page_id}/email-templates/{template_key}",
                landing_page_id=landing_page_id,
                template_key=template_key,
            ),
            body=maybe_transform({"html": html}, email_template_update_params.EmailTemplateUpdateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailTemplateUpdateResponse,
        )

    def delete(
        self,
        template_key: Literal["booking_confirmation", "site_notification"],
        *,
        landing_page_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailTemplateDeleteResponse:
        """
        Delete a custom email template override, reverting to the file-based default.

        Args:
          template_key: Identifies which file-based email template can be overridden.

              To add a new overridable template:

              1. Add a member here (value must match the file-based template name prefix)
              2. Add a corresponding `{value}_html` field to EmailConfig
              3. Add the DB-override check in the email sender that loads that template

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not template_key:
            raise ValueError(f"Expected a non-empty value for `template_key` but received {template_key!r}")
        return self._delete(
            path_template(
                "/landing-pages/{landing_page_id}/email-templates/{template_key}",
                landing_page_id=landing_page_id,
                template_key=template_key,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailTemplateDeleteResponse,
        )


class AsyncEmailTemplatesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncEmailTemplatesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncEmailTemplatesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEmailTemplatesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncEmailTemplatesResourceWithStreamingResponse(self)

    async def update(
        self,
        template_key: Literal["booking_confirmation", "site_notification"],
        *,
        landing_page_id: int,
        html: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailTemplateUpdateResponse:
        """
        Update a custom email template override for a landing page.

        Args:
          template_key: Identifies which file-based email template can be overridden.

              To add a new overridable template:

              1. Add a member here (value must match the file-based template name prefix)
              2. Add a corresponding `{value}_html` field to EmailConfig
              3. Add the DB-override check in the email sender that loads that template

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not template_key:
            raise ValueError(f"Expected a non-empty value for `template_key` but received {template_key!r}")
        return await self._put(
            path_template(
                "/landing-pages/{landing_page_id}/email-templates/{template_key}",
                landing_page_id=landing_page_id,
                template_key=template_key,
            ),
            body=await async_maybe_transform({"html": html}, email_template_update_params.EmailTemplateUpdateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailTemplateUpdateResponse,
        )

    async def delete(
        self,
        template_key: Literal["booking_confirmation", "site_notification"],
        *,
        landing_page_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailTemplateDeleteResponse:
        """
        Delete a custom email template override, reverting to the file-based default.

        Args:
          template_key: Identifies which file-based email template can be overridden.

              To add a new overridable template:

              1. Add a member here (value must match the file-based template name prefix)
              2. Add a corresponding `{value}_html` field to EmailConfig
              3. Add the DB-override check in the email sender that loads that template

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not template_key:
            raise ValueError(f"Expected a non-empty value for `template_key` but received {template_key!r}")
        return await self._delete(
            path_template(
                "/landing-pages/{landing_page_id}/email-templates/{template_key}",
                landing_page_id=landing_page_id,
                template_key=template_key,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailTemplateDeleteResponse,
        )


class EmailTemplatesResourceWithRawResponse:
    def __init__(self, email_templates: EmailTemplatesResource) -> None:
        self._email_templates = email_templates

        self.update = to_raw_response_wrapper(
            email_templates.update,
        )
        self.delete = to_raw_response_wrapper(
            email_templates.delete,
        )


class AsyncEmailTemplatesResourceWithRawResponse:
    def __init__(self, email_templates: AsyncEmailTemplatesResource) -> None:
        self._email_templates = email_templates

        self.update = async_to_raw_response_wrapper(
            email_templates.update,
        )
        self.delete = async_to_raw_response_wrapper(
            email_templates.delete,
        )


class EmailTemplatesResourceWithStreamingResponse:
    def __init__(self, email_templates: EmailTemplatesResource) -> None:
        self._email_templates = email_templates

        self.update = to_streamed_response_wrapper(
            email_templates.update,
        )
        self.delete = to_streamed_response_wrapper(
            email_templates.delete,
        )


class AsyncEmailTemplatesResourceWithStreamingResponse:
    def __init__(self, email_templates: AsyncEmailTemplatesResource) -> None:
        self._email_templates = email_templates

        self.update = async_to_streamed_response_wrapper(
            email_templates.update,
        )
        self.delete = async_to_streamed_response_wrapper(
            email_templates.delete,
        )
