# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date
from typing_extensions import Literal

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.external.leads import campaign_add_candidate_params
from ....types.external.leads.campaign_add_candidate_response import CampaignAddCandidateResponse

__all__ = ["CampaignsResource", "AsyncCampaignsResource"]


class CampaignsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return CampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return CampaignsResourceWithStreamingResponse(self)

    def add_candidate(
        self,
        campaign_id: int,
        *,
        tenant_db_name: str,
        cell_phone: str,
        family_name: str,
        given_name: str,
        person_source_id: int,
        city: Optional[str] | Omit = omit,
        dob: Union[str, date, None] | Omit = omit,
        email: Optional[str] | Omit = omit,
        home_phone: Optional[str] | Omit = omit,
        middle_name: Optional[str] | Omit = omit,
        preferred_language: Literal["ENGLISH", "SPANISH"] | Omit = omit,
        site_id: Optional[int] | Omit = omit,
        state: Optional[
            Literal[
                "AL",
                "AK",
                "AS",
                "AZ",
                "AR",
                "CA",
                "CO",
                "CT",
                "DE",
                "DC",
                "FL",
                "FM",
                "GA",
                "GU",
                "HI",
                "ID",
                "IL",
                "IN",
                "IA",
                "KS",
                "KY",
                "LA",
                "ME",
                "MD",
                "MA",
                "MH",
                "MI",
                "MN",
                "MS",
                "MO",
                "MT",
                "NE",
                "NV",
                "NH",
                "NJ",
                "NM",
                "NY",
                "NC",
                "ND",
                "MP",
                "OH",
                "OK",
                "OR",
                "PW",
                "PA",
                "PR",
                "RI",
                "SC",
                "SD",
                "TN",
                "TX",
                "TT",
                "UT",
                "VT",
                "VA",
                "VI",
                "WA",
                "WV",
                "WI",
                "WY",
            ]
        ]
        | Omit = omit,
        street_address: Optional[str] | Omit = omit,
        zip_code: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignAddCandidateResponse:
        """Add a new candidate to an existing outreach campaign.

        Creates Person and
        Candidate records if they don't exist.

        Args:
          state: US state codes and territories.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template(
                "/external/leads/{tenant_db_name}/campaigns/{campaign_id}/add-to-campaign",
                tenant_db_name=tenant_db_name,
                campaign_id=campaign_id,
            ),
            body=maybe_transform(
                {
                    "cell_phone": cell_phone,
                    "family_name": family_name,
                    "given_name": given_name,
                    "person_source_id": person_source_id,
                    "city": city,
                    "dob": dob,
                    "email": email,
                    "home_phone": home_phone,
                    "middle_name": middle_name,
                    "preferred_language": preferred_language,
                    "site_id": site_id,
                    "state": state,
                    "street_address": street_address,
                    "zip_code": zip_code,
                },
                campaign_add_candidate_params.CampaignAddCandidateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignAddCandidateResponse,
        )


class AsyncCampaignsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncCampaignsResourceWithStreamingResponse(self)

    async def add_candidate(
        self,
        campaign_id: int,
        *,
        tenant_db_name: str,
        cell_phone: str,
        family_name: str,
        given_name: str,
        person_source_id: int,
        city: Optional[str] | Omit = omit,
        dob: Union[str, date, None] | Omit = omit,
        email: Optional[str] | Omit = omit,
        home_phone: Optional[str] | Omit = omit,
        middle_name: Optional[str] | Omit = omit,
        preferred_language: Literal["ENGLISH", "SPANISH"] | Omit = omit,
        site_id: Optional[int] | Omit = omit,
        state: Optional[
            Literal[
                "AL",
                "AK",
                "AS",
                "AZ",
                "AR",
                "CA",
                "CO",
                "CT",
                "DE",
                "DC",
                "FL",
                "FM",
                "GA",
                "GU",
                "HI",
                "ID",
                "IL",
                "IN",
                "IA",
                "KS",
                "KY",
                "LA",
                "ME",
                "MD",
                "MA",
                "MH",
                "MI",
                "MN",
                "MS",
                "MO",
                "MT",
                "NE",
                "NV",
                "NH",
                "NJ",
                "NM",
                "NY",
                "NC",
                "ND",
                "MP",
                "OH",
                "OK",
                "OR",
                "PW",
                "PA",
                "PR",
                "RI",
                "SC",
                "SD",
                "TN",
                "TX",
                "TT",
                "UT",
                "VT",
                "VA",
                "VI",
                "WA",
                "WV",
                "WI",
                "WY",
            ]
        ]
        | Omit = omit,
        street_address: Optional[str] | Omit = omit,
        zip_code: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignAddCandidateResponse:
        """Add a new candidate to an existing outreach campaign.

        Creates Person and
        Candidate records if they don't exist.

        Args:
          state: US state codes and territories.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template(
                "/external/leads/{tenant_db_name}/campaigns/{campaign_id}/add-to-campaign",
                tenant_db_name=tenant_db_name,
                campaign_id=campaign_id,
            ),
            body=await async_maybe_transform(
                {
                    "cell_phone": cell_phone,
                    "family_name": family_name,
                    "given_name": given_name,
                    "person_source_id": person_source_id,
                    "city": city,
                    "dob": dob,
                    "email": email,
                    "home_phone": home_phone,
                    "middle_name": middle_name,
                    "preferred_language": preferred_language,
                    "site_id": site_id,
                    "state": state,
                    "street_address": street_address,
                    "zip_code": zip_code,
                },
                campaign_add_candidate_params.CampaignAddCandidateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignAddCandidateResponse,
        )


class CampaignsResourceWithRawResponse:
    def __init__(self, campaigns: CampaignsResource) -> None:
        self._campaigns = campaigns

        self.add_candidate = to_raw_response_wrapper(
            campaigns.add_candidate,
        )


class AsyncCampaignsResourceWithRawResponse:
    def __init__(self, campaigns: AsyncCampaignsResource) -> None:
        self._campaigns = campaigns

        self.add_candidate = async_to_raw_response_wrapper(
            campaigns.add_candidate,
        )


class CampaignsResourceWithStreamingResponse:
    def __init__(self, campaigns: CampaignsResource) -> None:
        self._campaigns = campaigns

        self.add_candidate = to_streamed_response_wrapper(
            campaigns.add_candidate,
        )


class AsyncCampaignsResourceWithStreamingResponse:
    def __init__(self, campaigns: AsyncCampaignsResource) -> None:
        self._campaigns = campaigns

        self.add_candidate = async_to_streamed_response_wrapper(
            campaigns.add_candidate,
        )
