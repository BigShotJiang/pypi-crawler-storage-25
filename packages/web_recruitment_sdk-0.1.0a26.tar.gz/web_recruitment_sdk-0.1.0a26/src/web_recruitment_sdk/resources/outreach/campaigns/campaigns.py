# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, Union, Iterable, Optional, cast
from datetime import date
from typing_extensions import Literal

import httpx

from .persons import (
    PersonsResource,
    AsyncPersonsResource,
    PersonsResourceWithRawResponse,
    AsyncPersonsResourceWithRawResponse,
    PersonsResourceWithStreamingResponse,
    AsyncPersonsResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.outreach import (
    campaign_list_params,
    campaign_create_params,
    campaign_get_analytics_params,
    campaign_set_landing_page_params,
)
from ....types.outreach.campaign_list_response import CampaignListResponse
from ....types.outreach.campaign_pause_response import CampaignPauseResponse
from ....types.outreach.campaign_start_response import CampaignStartResponse
from ....types.outreach.campaign_create_response import CampaignCreateResponse
from ....types.outreach.campaign_get_analytics_response import CampaignGetAnalyticsResponse
from ....types.outreach.campaign_get_candidates_response import CampaignGetCandidatesResponse
from ....types.outreach.campaign_set_landing_page_response import CampaignSetLandingPageResponse

__all__ = ["CampaignsResource", "AsyncCampaignsResource"]


class CampaignsResource(SyncAPIResource):
    @cached_property
    def persons(self) -> PersonsResource:
        return PersonsResource(self._client)

    @cached_property
    def with_raw_response(self) -> CampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return CampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return CampaignsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        booking_url: str,
        candidate_ids: Iterable[int],
        name: str,
        start_date: Union[str, date],
        workflow_id: int,
        concurrency_limit: int | Omit = omit,
        context: Optional[str] | Omit = omit,
        end_date: Union[str, date, None] | Omit = omit,
        fallback_timezone: Optional[
            Literal[
                "US/Eastern",
                "US/Central",
                "US/Mountain",
                "US/Pacific",
                "US/Alaska",
                "US/Hawaii",
                "US/Arizona",
                "America/New_York",
                "America/Chicago",
                "America/Denver",
                "America/Los_Angeles",
                "America/Phoenix",
                "America/Anchorage",
                "America/Honolulu",
                "America/Toronto",
                "America/Mexico_City",
                "America/Sao_Paulo",
                "America/Buenos_Aires",
                "Europe/London",
                "Europe/Paris",
                "Europe/Berlin",
                "Europe/Madrid",
                "Europe/Rome",
                "Europe/Amsterdam",
                "Europe/Brussels",
                "Europe/Vienna",
                "Europe/Zurich",
                "Europe/Stockholm",
                "Europe/Moscow",
                "Europe/Istanbul",
                "Asia/Tokyo",
                "Asia/Shanghai",
                "Asia/Hong_Kong",
                "Asia/Singapore",
                "Asia/Seoul",
                "Asia/Kolkata",
                "Asia/Dubai",
                "Asia/Bangkok",
                "Asia/Jakarta",
                "Asia/Manila",
                "Australia/Sydney",
                "Australia/Melbourne",
                "Australia/Perth",
                "Pacific/Auckland",
                "UTC",
            ]
        ]
        | Omit = omit,
        landing_page_id: Optional[int] | Omit = omit,
        minimum_appointment_lead_time_hours: float | Omit = omit,
        outreach_hours_end: Optional[int] | Omit = omit,
        outreach_hours_start: Optional[int] | Omit = omit,
        principal_investigator: Optional[str] | Omit = omit,
        reminder_delay_hours: float | Omit = omit,
        reminder_enabled: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignCreateResponse:
        """
        Create a new outreach campaign with candidate validation.

        Campaign dates (start_date, end_date) specify day boundaries - the first and
        last days when outreach can occur. Actual outreach times are determined by
        outreach_hours_start/end in each candidate's local timezone.

        Args:
          candidate_ids: List of candidate IDs to include in campaign

          start_date: First day of the campaign (YYYY-MM-DD)

          workflow_id: Config-driven workflow definition ID

          concurrency_limit: Maximum concurrent outreach calls allowed for this campaign

          context: Additional context included in all outreach calls for this campaign

          end_date: Last day of the campaign (YYYY-MM-DD)

          fallback_timezone: IANA timezone names (commonly used US and global timezones).

              These are standard timezone identifiers used for scheduling and time-based
              operations. For a complete list, see:
              https://en.wikipedia.org/wiki/List_of_tz_database_time_zones

          landing_page_id: Landing page to associate with this campaign

          minimum_appointment_lead_time_hours: Minimum hours between now and an appointment slot for it to be bookable

          outreach_hours_end: End hour for outreach in candidate's local timezone (0-23)

          outreach_hours_start: Start hour for outreach in candidate's local timezone (0-23)

          reminder_delay_hours: Hours to wait before sending reminder (supports fractional hours for testing,
              e.g., 0.01 = 36 seconds)

          reminder_enabled: Whether to send booking link reminders

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/outreach/campaigns",
            body=maybe_transform(
                {
                    "booking_url": booking_url,
                    "candidate_ids": candidate_ids,
                    "name": name,
                    "start_date": start_date,
                    "workflow_id": workflow_id,
                    "concurrency_limit": concurrency_limit,
                    "context": context,
                    "end_date": end_date,
                    "fallback_timezone": fallback_timezone,
                    "landing_page_id": landing_page_id,
                    "minimum_appointment_lead_time_hours": minimum_appointment_lead_time_hours,
                    "outreach_hours_end": outreach_hours_end,
                    "outreach_hours_start": outreach_hours_start,
                    "principal_investigator": principal_investigator,
                    "reminder_delay_hours": reminder_delay_hours,
                    "reminder_enabled": reminder_enabled,
                },
                campaign_create_params.CampaignCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignCreateResponse,
        )

    def list(
        self,
        *,
        include_metrics: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignListResponse:
        """
        Get all outreach campaigns.

        Optionally include candidate metrics by passing includeMetrics=true.

        Args:
          include_metrics: Include aggregated metrics (total candidates, calls made, interested,
              successful) for each campaign

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            CampaignListResponse,
            self._get(
                "/outreach/campaigns",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=maybe_transform(
                        {"include_metrics": include_metrics}, campaign_list_params.CampaignListParams
                    ),
                ),
                cast_to=cast(
                    Any, CampaignListResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    def delete(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete an outreach campaign, cancelling all in-progress candidate workflows

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/outreach/campaigns/{campaign_id}", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get_analytics(
        self,
        campaign_id: int,
        *,
        time_range: Literal["7d", "30d", "all"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignGetAnalyticsResponse:
        """
        Get analytics data for a campaign.

        Returns funnel stages and KPIs for the specified time range. Currently supports
        dormant-lead campaign workflow only.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            path_template("/outreach/campaigns/{campaign_id}/analytics", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"time_range": time_range}, campaign_get_analytics_params.CampaignGetAnalyticsParams
                ),
            ),
            cast_to=CampaignGetAnalyticsResponse,
        )

    def get_candidates(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignGetCandidatesResponse:
        """
        Get all candidate campaigns for a campaign with candidate info and outreach
        attempts

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            path_template("/outreach/campaigns/{campaign_id}/candidates", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignGetCandidatesResponse,
        )

    def pause(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignPauseResponse:
        """
        Pause an outreach campaign

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            path_template("/outreach/campaigns/{campaign_id}/pause", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignPauseResponse,
        )

    def set_landing_page(
        self,
        campaign_id: int,
        *,
        landing_page_id: Optional[int],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignSetLandingPageResponse:
        """
        Link or unlink a landing page from a campaign (only when NOT_STARTED)

        Args:
          landing_page_id: Landing page ID to link, or null to unlink

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._patch(
            path_template("/outreach/campaigns/{campaign_id}/landing-page", campaign_id=campaign_id),
            body=maybe_transform(
                {"landing_page_id": landing_page_id}, campaign_set_landing_page_params.CampaignSetLandingPageParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignSetLandingPageResponse,
        )

    def start(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignStartResponse:
        """
        Start or resume an outreach campaign with NOT_STARTED or PAUSED status.

        For Temporal campaigns with NOT_STARTED or PAUSED status, this will start the
        workflow for all NOT_STARTED candidates, calculating remaining attempts
        dynamically.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            path_template("/outreach/campaigns/{campaign_id}/start", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignStartResponse,
        )


class AsyncCampaignsResource(AsyncAPIResource):
    @cached_property
    def persons(self) -> AsyncPersonsResource:
        return AsyncPersonsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncCampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncCampaignsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        booking_url: str,
        candidate_ids: Iterable[int],
        name: str,
        start_date: Union[str, date],
        workflow_id: int,
        concurrency_limit: int | Omit = omit,
        context: Optional[str] | Omit = omit,
        end_date: Union[str, date, None] | Omit = omit,
        fallback_timezone: Optional[
            Literal[
                "US/Eastern",
                "US/Central",
                "US/Mountain",
                "US/Pacific",
                "US/Alaska",
                "US/Hawaii",
                "US/Arizona",
                "America/New_York",
                "America/Chicago",
                "America/Denver",
                "America/Los_Angeles",
                "America/Phoenix",
                "America/Anchorage",
                "America/Honolulu",
                "America/Toronto",
                "America/Mexico_City",
                "America/Sao_Paulo",
                "America/Buenos_Aires",
                "Europe/London",
                "Europe/Paris",
                "Europe/Berlin",
                "Europe/Madrid",
                "Europe/Rome",
                "Europe/Amsterdam",
                "Europe/Brussels",
                "Europe/Vienna",
                "Europe/Zurich",
                "Europe/Stockholm",
                "Europe/Moscow",
                "Europe/Istanbul",
                "Asia/Tokyo",
                "Asia/Shanghai",
                "Asia/Hong_Kong",
                "Asia/Singapore",
                "Asia/Seoul",
                "Asia/Kolkata",
                "Asia/Dubai",
                "Asia/Bangkok",
                "Asia/Jakarta",
                "Asia/Manila",
                "Australia/Sydney",
                "Australia/Melbourne",
                "Australia/Perth",
                "Pacific/Auckland",
                "UTC",
            ]
        ]
        | Omit = omit,
        landing_page_id: Optional[int] | Omit = omit,
        minimum_appointment_lead_time_hours: float | Omit = omit,
        outreach_hours_end: Optional[int] | Omit = omit,
        outreach_hours_start: Optional[int] | Omit = omit,
        principal_investigator: Optional[str] | Omit = omit,
        reminder_delay_hours: float | Omit = omit,
        reminder_enabled: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignCreateResponse:
        """
        Create a new outreach campaign with candidate validation.

        Campaign dates (start_date, end_date) specify day boundaries - the first and
        last days when outreach can occur. Actual outreach times are determined by
        outreach_hours_start/end in each candidate's local timezone.

        Args:
          candidate_ids: List of candidate IDs to include in campaign

          start_date: First day of the campaign (YYYY-MM-DD)

          workflow_id: Config-driven workflow definition ID

          concurrency_limit: Maximum concurrent outreach calls allowed for this campaign

          context: Additional context included in all outreach calls for this campaign

          end_date: Last day of the campaign (YYYY-MM-DD)

          fallback_timezone: IANA timezone names (commonly used US and global timezones).

              These are standard timezone identifiers used for scheduling and time-based
              operations. For a complete list, see:
              https://en.wikipedia.org/wiki/List_of_tz_database_time_zones

          landing_page_id: Landing page to associate with this campaign

          minimum_appointment_lead_time_hours: Minimum hours between now and an appointment slot for it to be bookable

          outreach_hours_end: End hour for outreach in candidate's local timezone (0-23)

          outreach_hours_start: Start hour for outreach in candidate's local timezone (0-23)

          reminder_delay_hours: Hours to wait before sending reminder (supports fractional hours for testing,
              e.g., 0.01 = 36 seconds)

          reminder_enabled: Whether to send booking link reminders

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/outreach/campaigns",
            body=await async_maybe_transform(
                {
                    "booking_url": booking_url,
                    "candidate_ids": candidate_ids,
                    "name": name,
                    "start_date": start_date,
                    "workflow_id": workflow_id,
                    "concurrency_limit": concurrency_limit,
                    "context": context,
                    "end_date": end_date,
                    "fallback_timezone": fallback_timezone,
                    "landing_page_id": landing_page_id,
                    "minimum_appointment_lead_time_hours": minimum_appointment_lead_time_hours,
                    "outreach_hours_end": outreach_hours_end,
                    "outreach_hours_start": outreach_hours_start,
                    "principal_investigator": principal_investigator,
                    "reminder_delay_hours": reminder_delay_hours,
                    "reminder_enabled": reminder_enabled,
                },
                campaign_create_params.CampaignCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignCreateResponse,
        )

    async def list(
        self,
        *,
        include_metrics: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignListResponse:
        """
        Get all outreach campaigns.

        Optionally include candidate metrics by passing includeMetrics=true.

        Args:
          include_metrics: Include aggregated metrics (total candidates, calls made, interested,
              successful) for each campaign

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            CampaignListResponse,
            await self._get(
                "/outreach/campaigns",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=await async_maybe_transform(
                        {"include_metrics": include_metrics}, campaign_list_params.CampaignListParams
                    ),
                ),
                cast_to=cast(
                    Any, CampaignListResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )

    async def delete(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete an outreach campaign, cancelling all in-progress candidate workflows

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/outreach/campaigns/{campaign_id}", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get_analytics(
        self,
        campaign_id: int,
        *,
        time_range: Literal["7d", "30d", "all"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignGetAnalyticsResponse:
        """
        Get analytics data for a campaign.

        Returns funnel stages and KPIs for the specified time range. Currently supports
        dormant-lead campaign workflow only.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            path_template("/outreach/campaigns/{campaign_id}/analytics", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"time_range": time_range}, campaign_get_analytics_params.CampaignGetAnalyticsParams
                ),
            ),
            cast_to=CampaignGetAnalyticsResponse,
        )

    async def get_candidates(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignGetCandidatesResponse:
        """
        Get all candidate campaigns for a campaign with candidate info and outreach
        attempts

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            path_template("/outreach/campaigns/{campaign_id}/candidates", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignGetCandidatesResponse,
        )

    async def pause(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignPauseResponse:
        """
        Pause an outreach campaign

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            path_template("/outreach/campaigns/{campaign_id}/pause", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignPauseResponse,
        )

    async def set_landing_page(
        self,
        campaign_id: int,
        *,
        landing_page_id: Optional[int],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignSetLandingPageResponse:
        """
        Link or unlink a landing page from a campaign (only when NOT_STARTED)

        Args:
          landing_page_id: Landing page ID to link, or null to unlink

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._patch(
            path_template("/outreach/campaigns/{campaign_id}/landing-page", campaign_id=campaign_id),
            body=await async_maybe_transform(
                {"landing_page_id": landing_page_id}, campaign_set_landing_page_params.CampaignSetLandingPageParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignSetLandingPageResponse,
        )

    async def start(
        self,
        campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CampaignStartResponse:
        """
        Start or resume an outreach campaign with NOT_STARTED or PAUSED status.

        For Temporal campaigns with NOT_STARTED or PAUSED status, this will start the
        workflow for all NOT_STARTED candidates, calculating remaining attempts
        dynamically.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            path_template("/outreach/campaigns/{campaign_id}/start", campaign_id=campaign_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CampaignStartResponse,
        )


class CampaignsResourceWithRawResponse:
    def __init__(self, campaigns: CampaignsResource) -> None:
        self._campaigns = campaigns

        self.create = to_raw_response_wrapper(
            campaigns.create,
        )
        self.list = to_raw_response_wrapper(
            campaigns.list,
        )
        self.delete = to_raw_response_wrapper(
            campaigns.delete,
        )
        self.get_analytics = to_raw_response_wrapper(
            campaigns.get_analytics,
        )
        self.get_candidates = to_raw_response_wrapper(
            campaigns.get_candidates,
        )
        self.pause = to_raw_response_wrapper(
            campaigns.pause,
        )
        self.set_landing_page = to_raw_response_wrapper(
            campaigns.set_landing_page,
        )
        self.start = to_raw_response_wrapper(
            campaigns.start,
        )

    @cached_property
    def persons(self) -> PersonsResourceWithRawResponse:
        return PersonsResourceWithRawResponse(self._campaigns.persons)


class AsyncCampaignsResourceWithRawResponse:
    def __init__(self, campaigns: AsyncCampaignsResource) -> None:
        self._campaigns = campaigns

        self.create = async_to_raw_response_wrapper(
            campaigns.create,
        )
        self.list = async_to_raw_response_wrapper(
            campaigns.list,
        )
        self.delete = async_to_raw_response_wrapper(
            campaigns.delete,
        )
        self.get_analytics = async_to_raw_response_wrapper(
            campaigns.get_analytics,
        )
        self.get_candidates = async_to_raw_response_wrapper(
            campaigns.get_candidates,
        )
        self.pause = async_to_raw_response_wrapper(
            campaigns.pause,
        )
        self.set_landing_page = async_to_raw_response_wrapper(
            campaigns.set_landing_page,
        )
        self.start = async_to_raw_response_wrapper(
            campaigns.start,
        )

    @cached_property
    def persons(self) -> AsyncPersonsResourceWithRawResponse:
        return AsyncPersonsResourceWithRawResponse(self._campaigns.persons)


class CampaignsResourceWithStreamingResponse:
    def __init__(self, campaigns: CampaignsResource) -> None:
        self._campaigns = campaigns

        self.create = to_streamed_response_wrapper(
            campaigns.create,
        )
        self.list = to_streamed_response_wrapper(
            campaigns.list,
        )
        self.delete = to_streamed_response_wrapper(
            campaigns.delete,
        )
        self.get_analytics = to_streamed_response_wrapper(
            campaigns.get_analytics,
        )
        self.get_candidates = to_streamed_response_wrapper(
            campaigns.get_candidates,
        )
        self.pause = to_streamed_response_wrapper(
            campaigns.pause,
        )
        self.set_landing_page = to_streamed_response_wrapper(
            campaigns.set_landing_page,
        )
        self.start = to_streamed_response_wrapper(
            campaigns.start,
        )

    @cached_property
    def persons(self) -> PersonsResourceWithStreamingResponse:
        return PersonsResourceWithStreamingResponse(self._campaigns.persons)


class AsyncCampaignsResourceWithStreamingResponse:
    def __init__(self, campaigns: AsyncCampaignsResource) -> None:
        self._campaigns = campaigns

        self.create = async_to_streamed_response_wrapper(
            campaigns.create,
        )
        self.list = async_to_streamed_response_wrapper(
            campaigns.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            campaigns.delete,
        )
        self.get_analytics = async_to_streamed_response_wrapper(
            campaigns.get_analytics,
        )
        self.get_candidates = async_to_streamed_response_wrapper(
            campaigns.get_candidates,
        )
        self.pause = async_to_streamed_response_wrapper(
            campaigns.pause,
        )
        self.set_landing_page = async_to_streamed_response_wrapper(
            campaigns.set_landing_page,
        )
        self.start = async_to_streamed_response_wrapper(
            campaigns.start,
        )

    @cached_property
    def persons(self) -> AsyncPersonsResourceWithStreamingResponse:
        return AsyncPersonsResourceWithStreamingResponse(self._campaigns.persons)
