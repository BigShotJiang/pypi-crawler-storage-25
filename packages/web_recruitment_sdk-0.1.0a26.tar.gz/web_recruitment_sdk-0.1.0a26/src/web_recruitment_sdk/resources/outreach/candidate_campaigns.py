# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import path_template
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.outreach.candidate_campaign_cancel_response import CandidateCampaignCancelResponse

__all__ = ["CandidateCampaignsResource", "AsyncCandidateCampaignsResource"]


class CandidateCampaignsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CandidateCampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return CandidateCampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CandidateCampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return CandidateCampaignsResourceWithStreamingResponse(self)

    def cancel(
        self,
        candidate_campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CandidateCampaignCancelResponse:
        """
        Cancel a specific candidate campaign, marking it as UNSUCCESSFUL and cancelling
        the workflow

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            path_template(
                "/outreach/candidate-campaigns/{candidate_campaign_id}/cancel",
                candidate_campaign_id=candidate_campaign_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CandidateCampaignCancelResponse,
        )


class AsyncCandidateCampaignsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCandidateCampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCandidateCampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCandidateCampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncCandidateCampaignsResourceWithStreamingResponse(self)

    async def cancel(
        self,
        candidate_campaign_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CandidateCampaignCancelResponse:
        """
        Cancel a specific candidate campaign, marking it as UNSUCCESSFUL and cancelling
        the workflow

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            path_template(
                "/outreach/candidate-campaigns/{candidate_campaign_id}/cancel",
                candidate_campaign_id=candidate_campaign_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CandidateCampaignCancelResponse,
        )


class CandidateCampaignsResourceWithRawResponse:
    def __init__(self, candidate_campaigns: CandidateCampaignsResource) -> None:
        self._candidate_campaigns = candidate_campaigns

        self.cancel = to_raw_response_wrapper(
            candidate_campaigns.cancel,
        )


class AsyncCandidateCampaignsResourceWithRawResponse:
    def __init__(self, candidate_campaigns: AsyncCandidateCampaignsResource) -> None:
        self._candidate_campaigns = candidate_campaigns

        self.cancel = async_to_raw_response_wrapper(
            candidate_campaigns.cancel,
        )


class CandidateCampaignsResourceWithStreamingResponse:
    def __init__(self, candidate_campaigns: CandidateCampaignsResource) -> None:
        self._candidate_campaigns = candidate_campaigns

        self.cancel = to_streamed_response_wrapper(
            candidate_campaigns.cancel,
        )


class AsyncCandidateCampaignsResourceWithStreamingResponse:
    def __init__(self, candidate_campaigns: AsyncCandidateCampaignsResource) -> None:
        self._candidate_campaigns = candidate_campaigns

        self.cancel = async_to_streamed_response_wrapper(
            candidate_campaigns.cancel,
        )
