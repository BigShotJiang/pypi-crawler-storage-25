# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.outreach import person_source_create_params, person_source_update_params
from ...types.outreach.person_source_list_response import PersonSourceListResponse
from ...types.outreach.person_source_create_response import PersonSourceCreateResponse
from ...types.outreach.person_source_update_response import PersonSourceUpdateResponse
from ...types.outreach.person_source_retrieve_response import PersonSourceRetrieveResponse

__all__ = ["PersonSourcesResource", "AsyncPersonSourcesResource"]


class PersonSourcesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PersonSourcesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return PersonSourcesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PersonSourcesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return PersonSourcesResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        name: str,
        type: Literal["CSV", "EHR", "API", "FACEBOOK_LEADS", "TRIALLY_LEADS"],
        description: Optional[str] | Omit = omit,
        source_metadata: Optional[object] | Omit = omit,
        sync_frequency: Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonSourceCreateResponse:
        """
        Create a new person source

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/outreach/person-sources",
            body=maybe_transform(
                {
                    "name": name,
                    "type": type,
                    "description": description,
                    "source_metadata": source_metadata,
                    "sync_frequency": sync_frequency,
                },
                person_source_create_params.PersonSourceCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonSourceCreateResponse,
        )

    def retrieve(
        self,
        source_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonSourceRetrieveResponse:
        """
        Get a person source by ID

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            path_template("/outreach/person-sources/{source_id}", source_id=source_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonSourceRetrieveResponse,
        )

    def update(
        self,
        source_id: int,
        *,
        description: Optional[str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        source_metadata: Optional[object] | Omit = omit,
        sync_frequency: Optional[Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonSourceUpdateResponse:
        """
        Update a person source

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._put(
            path_template("/outreach/person-sources/{source_id}", source_id=source_id),
            body=maybe_transform(
                {
                    "description": description,
                    "name": name,
                    "source_metadata": source_metadata,
                    "sync_frequency": sync_frequency,
                },
                person_source_update_params.PersonSourceUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonSourceUpdateResponse,
        )

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonSourceListResponse:
        """Get all person sources"""
        return self._get(
            "/outreach/person-sources",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonSourceListResponse,
        )

    def delete(
        self,
        source_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a person source (validates no persons reference it)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/outreach/person-sources/{source_id}", source_id=source_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncPersonSourcesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPersonSourcesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncPersonSourcesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPersonSourcesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncPersonSourcesResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        name: str,
        type: Literal["CSV", "EHR", "API", "FACEBOOK_LEADS", "TRIALLY_LEADS"],
        description: Optional[str] | Omit = omit,
        source_metadata: Optional[object] | Omit = omit,
        sync_frequency: Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonSourceCreateResponse:
        """
        Create a new person source

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/outreach/person-sources",
            body=await async_maybe_transform(
                {
                    "name": name,
                    "type": type,
                    "description": description,
                    "source_metadata": source_metadata,
                    "sync_frequency": sync_frequency,
                },
                person_source_create_params.PersonSourceCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonSourceCreateResponse,
        )

    async def retrieve(
        self,
        source_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonSourceRetrieveResponse:
        """
        Get a person source by ID

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            path_template("/outreach/person-sources/{source_id}", source_id=source_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonSourceRetrieveResponse,
        )

    async def update(
        self,
        source_id: int,
        *,
        description: Optional[str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        source_metadata: Optional[object] | Omit = omit,
        sync_frequency: Optional[Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonSourceUpdateResponse:
        """
        Update a person source

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._put(
            path_template("/outreach/person-sources/{source_id}", source_id=source_id),
            body=await async_maybe_transform(
                {
                    "description": description,
                    "name": name,
                    "source_metadata": source_metadata,
                    "sync_frequency": sync_frequency,
                },
                person_source_update_params.PersonSourceUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonSourceUpdateResponse,
        )

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PersonSourceListResponse:
        """Get all person sources"""
        return await self._get(
            "/outreach/person-sources",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PersonSourceListResponse,
        )

    async def delete(
        self,
        source_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a person source (validates no persons reference it)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/outreach/person-sources/{source_id}", source_id=source_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class PersonSourcesResourceWithRawResponse:
    def __init__(self, person_sources: PersonSourcesResource) -> None:
        self._person_sources = person_sources

        self.create = to_raw_response_wrapper(
            person_sources.create,
        )
        self.retrieve = to_raw_response_wrapper(
            person_sources.retrieve,
        )
        self.update = to_raw_response_wrapper(
            person_sources.update,
        )
        self.list = to_raw_response_wrapper(
            person_sources.list,
        )
        self.delete = to_raw_response_wrapper(
            person_sources.delete,
        )


class AsyncPersonSourcesResourceWithRawResponse:
    def __init__(self, person_sources: AsyncPersonSourcesResource) -> None:
        self._person_sources = person_sources

        self.create = async_to_raw_response_wrapper(
            person_sources.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            person_sources.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            person_sources.update,
        )
        self.list = async_to_raw_response_wrapper(
            person_sources.list,
        )
        self.delete = async_to_raw_response_wrapper(
            person_sources.delete,
        )


class PersonSourcesResourceWithStreamingResponse:
    def __init__(self, person_sources: PersonSourcesResource) -> None:
        self._person_sources = person_sources

        self.create = to_streamed_response_wrapper(
            person_sources.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            person_sources.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            person_sources.update,
        )
        self.list = to_streamed_response_wrapper(
            person_sources.list,
        )
        self.delete = to_streamed_response_wrapper(
            person_sources.delete,
        )


class AsyncPersonSourcesResourceWithStreamingResponse:
    def __init__(self, person_sources: AsyncPersonSourcesResource) -> None:
        self._person_sources = person_sources

        self.create = async_to_streamed_response_wrapper(
            person_sources.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            person_sources.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            person_sources.update,
        )
        self.list = async_to_streamed_response_wrapper(
            person_sources.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            person_sources.delete,
        )
