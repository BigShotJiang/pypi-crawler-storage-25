# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from .tenant import (
    TenantResource,
    AsyncTenantResource,
    TenantResourceWithRawResponse,
    AsyncTenantResourceWithRawResponse,
    TenantResourceWithStreamingResponse,
    AsyncTenantResourceWithStreamingResponse,
)
from ...types import outreach_trigger_call_params
from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from .workflows import (
    WorkflowsResource,
    AsyncWorkflowsResource,
    WorkflowsResourceWithRawResponse,
    AsyncWorkflowsResourceWithRawResponse,
    WorkflowsResourceWithStreamingResponse,
    AsyncWorkflowsResourceWithStreamingResponse,
)
from .candidates import (
    CandidatesResource,
    AsyncCandidatesResource,
    CandidatesResourceWithRawResponse,
    AsyncCandidatesResourceWithRawResponse,
    CandidatesResourceWithStreamingResponse,
    AsyncCandidatesResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .sites.sites import (
    SitesResource,
    AsyncSitesResource,
    SitesResourceWithRawResponse,
    AsyncSitesResourceWithRawResponse,
    SitesResourceWithStreamingResponse,
    AsyncSitesResourceWithStreamingResponse,
)
from ..._base_client import make_request_options
from .person_sources import (
    PersonSourcesResource,
    AsyncPersonSourcesResource,
    PersonSourcesResourceWithRawResponse,
    AsyncPersonSourcesResourceWithRawResponse,
    PersonSourcesResourceWithStreamingResponse,
    AsyncPersonSourcesResourceWithStreamingResponse,
)
from .campaigns.campaigns import (
    CampaignsResource,
    AsyncCampaignsResource,
    CampaignsResourceWithRawResponse,
    AsyncCampaignsResourceWithRawResponse,
    CampaignsResourceWithStreamingResponse,
    AsyncCampaignsResourceWithStreamingResponse,
)
from .candidate_campaigns import (
    CandidateCampaignsResource,
    AsyncCandidateCampaignsResource,
    CandidateCampaignsResourceWithRawResponse,
    AsyncCandidateCampaignsResourceWithRawResponse,
    CandidateCampaignsResourceWithStreamingResponse,
    AsyncCandidateCampaignsResourceWithStreamingResponse,
)
from ...types.outreach_trigger_call_response import OutreachTriggerCallResponse
from ...types.outreach_get_candidate_appointments_response import OutreachGetCandidateAppointmentsResponse

__all__ = ["OutreachResource", "AsyncOutreachResource"]


class OutreachResource(SyncAPIResource):
    @cached_property
    def campaigns(self) -> CampaignsResource:
        return CampaignsResource(self._client)

    @cached_property
    def sites(self) -> SitesResource:
        return SitesResource(self._client)

    @cached_property
    def candidate_campaigns(self) -> CandidateCampaignsResource:
        return CandidateCampaignsResource(self._client)

    @cached_property
    def candidates(self) -> CandidatesResource:
        return CandidatesResource(self._client)

    @cached_property
    def workflows(self) -> WorkflowsResource:
        return WorkflowsResource(self._client)

    @cached_property
    def tenant(self) -> TenantResource:
        return TenantResource(self._client)

    @cached_property
    def person_sources(self) -> PersonSourcesResource:
        return PersonSourcesResource(self._client)

    @cached_property
    def with_raw_response(self) -> OutreachResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return OutreachResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> OutreachResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return OutreachResourceWithStreamingResponse(self)

    def get_candidate_appointments(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OutreachGetCandidateAppointmentsResponse:
        """Get candidate appointments with candidate contact and campaign context."""
        return self._get(
            "/outreach/candidate-appointments",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OutreachGetCandidateAppointmentsResponse,
        )

    def trigger_call(
        self,
        *,
        call_data: outreach_trigger_call_params.CallData,
        conversation_flow: Literal[
            "lead_warmer", "lead_warmer_with_clinical_screening", "interested_lead_with_screening_link"
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OutreachTriggerCallResponse:
        """
        Trigger a phone call to a patient using LiveKit

        Args:
          call_data: Class to store call data from client requests (without tenant_db_name).

          conversation_flow: Represents the flow of a conversation.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/outreach/make-call",
            body=maybe_transform(
                {
                    "call_data": call_data,
                    "conversation_flow": conversation_flow,
                },
                outreach_trigger_call_params.OutreachTriggerCallParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OutreachTriggerCallResponse,
        )


class AsyncOutreachResource(AsyncAPIResource):
    @cached_property
    def campaigns(self) -> AsyncCampaignsResource:
        return AsyncCampaignsResource(self._client)

    @cached_property
    def sites(self) -> AsyncSitesResource:
        return AsyncSitesResource(self._client)

    @cached_property
    def candidate_campaigns(self) -> AsyncCandidateCampaignsResource:
        return AsyncCandidateCampaignsResource(self._client)

    @cached_property
    def candidates(self) -> AsyncCandidatesResource:
        return AsyncCandidatesResource(self._client)

    @cached_property
    def workflows(self) -> AsyncWorkflowsResource:
        return AsyncWorkflowsResource(self._client)

    @cached_property
    def tenant(self) -> AsyncTenantResource:
        return AsyncTenantResource(self._client)

    @cached_property
    def person_sources(self) -> AsyncPersonSourcesResource:
        return AsyncPersonSourcesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncOutreachResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncOutreachResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncOutreachResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncOutreachResourceWithStreamingResponse(self)

    async def get_candidate_appointments(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OutreachGetCandidateAppointmentsResponse:
        """Get candidate appointments with candidate contact and campaign context."""
        return await self._get(
            "/outreach/candidate-appointments",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OutreachGetCandidateAppointmentsResponse,
        )

    async def trigger_call(
        self,
        *,
        call_data: outreach_trigger_call_params.CallData,
        conversation_flow: Literal[
            "lead_warmer", "lead_warmer_with_clinical_screening", "interested_lead_with_screening_link"
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OutreachTriggerCallResponse:
        """
        Trigger a phone call to a patient using LiveKit

        Args:
          call_data: Class to store call data from client requests (without tenant_db_name).

          conversation_flow: Represents the flow of a conversation.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/outreach/make-call",
            body=await async_maybe_transform(
                {
                    "call_data": call_data,
                    "conversation_flow": conversation_flow,
                },
                outreach_trigger_call_params.OutreachTriggerCallParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OutreachTriggerCallResponse,
        )


class OutreachResourceWithRawResponse:
    def __init__(self, outreach: OutreachResource) -> None:
        self._outreach = outreach

        self.get_candidate_appointments = to_raw_response_wrapper(
            outreach.get_candidate_appointments,
        )
        self.trigger_call = to_raw_response_wrapper(
            outreach.trigger_call,
        )

    @cached_property
    def campaigns(self) -> CampaignsResourceWithRawResponse:
        return CampaignsResourceWithRawResponse(self._outreach.campaigns)

    @cached_property
    def sites(self) -> SitesResourceWithRawResponse:
        return SitesResourceWithRawResponse(self._outreach.sites)

    @cached_property
    def candidate_campaigns(self) -> CandidateCampaignsResourceWithRawResponse:
        return CandidateCampaignsResourceWithRawResponse(self._outreach.candidate_campaigns)

    @cached_property
    def candidates(self) -> CandidatesResourceWithRawResponse:
        return CandidatesResourceWithRawResponse(self._outreach.candidates)

    @cached_property
    def workflows(self) -> WorkflowsResourceWithRawResponse:
        return WorkflowsResourceWithRawResponse(self._outreach.workflows)

    @cached_property
    def tenant(self) -> TenantResourceWithRawResponse:
        return TenantResourceWithRawResponse(self._outreach.tenant)

    @cached_property
    def person_sources(self) -> PersonSourcesResourceWithRawResponse:
        return PersonSourcesResourceWithRawResponse(self._outreach.person_sources)


class AsyncOutreachResourceWithRawResponse:
    def __init__(self, outreach: AsyncOutreachResource) -> None:
        self._outreach = outreach

        self.get_candidate_appointments = async_to_raw_response_wrapper(
            outreach.get_candidate_appointments,
        )
        self.trigger_call = async_to_raw_response_wrapper(
            outreach.trigger_call,
        )

    @cached_property
    def campaigns(self) -> AsyncCampaignsResourceWithRawResponse:
        return AsyncCampaignsResourceWithRawResponse(self._outreach.campaigns)

    @cached_property
    def sites(self) -> AsyncSitesResourceWithRawResponse:
        return AsyncSitesResourceWithRawResponse(self._outreach.sites)

    @cached_property
    def candidate_campaigns(self) -> AsyncCandidateCampaignsResourceWithRawResponse:
        return AsyncCandidateCampaignsResourceWithRawResponse(self._outreach.candidate_campaigns)

    @cached_property
    def candidates(self) -> AsyncCandidatesResourceWithRawResponse:
        return AsyncCandidatesResourceWithRawResponse(self._outreach.candidates)

    @cached_property
    def workflows(self) -> AsyncWorkflowsResourceWithRawResponse:
        return AsyncWorkflowsResourceWithRawResponse(self._outreach.workflows)

    @cached_property
    def tenant(self) -> AsyncTenantResourceWithRawResponse:
        return AsyncTenantResourceWithRawResponse(self._outreach.tenant)

    @cached_property
    def person_sources(self) -> AsyncPersonSourcesResourceWithRawResponse:
        return AsyncPersonSourcesResourceWithRawResponse(self._outreach.person_sources)


class OutreachResourceWithStreamingResponse:
    def __init__(self, outreach: OutreachResource) -> None:
        self._outreach = outreach

        self.get_candidate_appointments = to_streamed_response_wrapper(
            outreach.get_candidate_appointments,
        )
        self.trigger_call = to_streamed_response_wrapper(
            outreach.trigger_call,
        )

    @cached_property
    def campaigns(self) -> CampaignsResourceWithStreamingResponse:
        return CampaignsResourceWithStreamingResponse(self._outreach.campaigns)

    @cached_property
    def sites(self) -> SitesResourceWithStreamingResponse:
        return SitesResourceWithStreamingResponse(self._outreach.sites)

    @cached_property
    def candidate_campaigns(self) -> CandidateCampaignsResourceWithStreamingResponse:
        return CandidateCampaignsResourceWithStreamingResponse(self._outreach.candidate_campaigns)

    @cached_property
    def candidates(self) -> CandidatesResourceWithStreamingResponse:
        return CandidatesResourceWithStreamingResponse(self._outreach.candidates)

    @cached_property
    def workflows(self) -> WorkflowsResourceWithStreamingResponse:
        return WorkflowsResourceWithStreamingResponse(self._outreach.workflows)

    @cached_property
    def tenant(self) -> TenantResourceWithStreamingResponse:
        return TenantResourceWithStreamingResponse(self._outreach.tenant)

    @cached_property
    def person_sources(self) -> PersonSourcesResourceWithStreamingResponse:
        return PersonSourcesResourceWithStreamingResponse(self._outreach.person_sources)


class AsyncOutreachResourceWithStreamingResponse:
    def __init__(self, outreach: AsyncOutreachResource) -> None:
        self._outreach = outreach

        self.get_candidate_appointments = async_to_streamed_response_wrapper(
            outreach.get_candidate_appointments,
        )
        self.trigger_call = async_to_streamed_response_wrapper(
            outreach.trigger_call,
        )

    @cached_property
    def campaigns(self) -> AsyncCampaignsResourceWithStreamingResponse:
        return AsyncCampaignsResourceWithStreamingResponse(self._outreach.campaigns)

    @cached_property
    def sites(self) -> AsyncSitesResourceWithStreamingResponse:
        return AsyncSitesResourceWithStreamingResponse(self._outreach.sites)

    @cached_property
    def candidate_campaigns(self) -> AsyncCandidateCampaignsResourceWithStreamingResponse:
        return AsyncCandidateCampaignsResourceWithStreamingResponse(self._outreach.candidate_campaigns)

    @cached_property
    def candidates(self) -> AsyncCandidatesResourceWithStreamingResponse:
        return AsyncCandidatesResourceWithStreamingResponse(self._outreach.candidates)

    @cached_property
    def workflows(self) -> AsyncWorkflowsResourceWithStreamingResponse:
        return AsyncWorkflowsResourceWithStreamingResponse(self._outreach.workflows)

    @cached_property
    def tenant(self) -> AsyncTenantResourceWithStreamingResponse:
        return AsyncTenantResourceWithStreamingResponse(self._outreach.tenant)

    @cached_property
    def person_sources(self) -> AsyncPersonSourcesResourceWithStreamingResponse:
        return AsyncPersonSourcesResourceWithStreamingResponse(self._outreach.person_sources)
