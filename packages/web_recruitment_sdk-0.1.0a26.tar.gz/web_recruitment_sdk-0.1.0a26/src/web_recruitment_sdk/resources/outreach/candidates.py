# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import path_template
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.outreach.candidate_list_response import CandidateListResponse
from ...types.outreach.candidate_retrieve_journey_response import CandidateRetrieveJourneyResponse

__all__ = ["CandidatesResource", "AsyncCandidatesResource"]


class CandidatesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CandidatesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return CandidatesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CandidatesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return CandidatesResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CandidateListResponse:
        """Get all candidates with their person data."""
        return self._get(
            "/outreach/candidates",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CandidateListResponse,
        )

    def retrieve_journey(
        self,
        candidate_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CandidateRetrieveJourneyResponse:
        """
        Return a candidate's multi-campaign outreach journey.

        Currently a stub returning a hardcoded fixture so the frontend can be validated
        end-to-end before the real reducer and repository land. Client access is gated
        by the `is_candidate_journey_panel_enabled` PostHog flag in the Connect UI; the
        endpoint itself is open to any authenticated user and returns only synthetic
        data. When the real reducer lands, replace the fixture call with a service call
        and drop the `_candidate_journey_fixture` module.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            path_template("/outreach/candidates/{candidate_id}/journey", candidate_id=candidate_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CandidateRetrieveJourneyResponse,
        )


class AsyncCandidatesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCandidatesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCandidatesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCandidatesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncCandidatesResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CandidateListResponse:
        """Get all candidates with their person data."""
        return await self._get(
            "/outreach/candidates",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CandidateListResponse,
        )

    async def retrieve_journey(
        self,
        candidate_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CandidateRetrieveJourneyResponse:
        """
        Return a candidate's multi-campaign outreach journey.

        Currently a stub returning a hardcoded fixture so the frontend can be validated
        end-to-end before the real reducer and repository land. Client access is gated
        by the `is_candidate_journey_panel_enabled` PostHog flag in the Connect UI; the
        endpoint itself is open to any authenticated user and returns only synthetic
        data. When the real reducer lands, replace the fixture call with a service call
        and drop the `_candidate_journey_fixture` module.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            path_template("/outreach/candidates/{candidate_id}/journey", candidate_id=candidate_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CandidateRetrieveJourneyResponse,
        )


class CandidatesResourceWithRawResponse:
    def __init__(self, candidates: CandidatesResource) -> None:
        self._candidates = candidates

        self.list = to_raw_response_wrapper(
            candidates.list,
        )
        self.retrieve_journey = to_raw_response_wrapper(
            candidates.retrieve_journey,
        )


class AsyncCandidatesResourceWithRawResponse:
    def __init__(self, candidates: AsyncCandidatesResource) -> None:
        self._candidates = candidates

        self.list = async_to_raw_response_wrapper(
            candidates.list,
        )
        self.retrieve_journey = async_to_raw_response_wrapper(
            candidates.retrieve_journey,
        )


class CandidatesResourceWithStreamingResponse:
    def __init__(self, candidates: CandidatesResource) -> None:
        self._candidates = candidates

        self.list = to_streamed_response_wrapper(
            candidates.list,
        )
        self.retrieve_journey = to_streamed_response_wrapper(
            candidates.retrieve_journey,
        )


class AsyncCandidatesResourceWithStreamingResponse:
    def __init__(self, candidates: AsyncCandidatesResource) -> None:
        self._candidates = candidates

        self.list = async_to_streamed_response_wrapper(
            candidates.list,
        )
        self.retrieve_journey = async_to_streamed_response_wrapper(
            candidates.retrieve_journey,
        )
