# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.outreach import tenant_create_params, tenant_update_params
from ...types.outreach.tenant_create_response import TenantCreateResponse
from ...types.outreach.tenant_update_response import TenantUpdateResponse
from ...types.outreach.tenant_retrieve_response import TenantRetrieveResponse

__all__ = ["TenantResource", "AsyncTenantResource"]


class TenantResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> TenantResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return TenantResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TenantResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return TenantResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        customer_facing_name: str,
        outbound_phone_number: str,
        instructions: Optional[str] | Omit = omit,
        knowledge: Optional[str] | Omit = omit,
        logo_url: Optional[str] | Omit = omit,
        notification_emails: SequenceNotStr[str] | Omit = omit,
        office_hours: Optional[str] | Omit = omit,
        office_phone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TenantCreateResponse:
        """
        Create tenant outreach configuration

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/outreach/tenant",
            body=maybe_transform(
                {
                    "customer_facing_name": customer_facing_name,
                    "outbound_phone_number": outbound_phone_number,
                    "instructions": instructions,
                    "knowledge": knowledge,
                    "logo_url": logo_url,
                    "notification_emails": notification_emails,
                    "office_hours": office_hours,
                    "office_phone": office_phone,
                },
                tenant_create_params.TenantCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TenantCreateResponse,
        )

    def retrieve(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Optional[TenantRetrieveResponse]:
        """Get tenant outreach configuration"""
        return self._get(
            "/outreach/tenant",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TenantRetrieveResponse,
        )

    def update(
        self,
        *,
        customer_facing_name: Optional[str] | Omit = omit,
        instructions: Optional[str] | Omit = omit,
        knowledge: Optional[str] | Omit = omit,
        logo_url: Optional[str] | Omit = omit,
        notification_emails: Optional[SequenceNotStr[str]] | Omit = omit,
        office_hours: Optional[str] | Omit = omit,
        office_phone: Optional[str] | Omit = omit,
        outbound_phone_number: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TenantUpdateResponse:
        """
        Update tenant outreach configuration

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._patch(
            "/outreach/tenant",
            body=maybe_transform(
                {
                    "customer_facing_name": customer_facing_name,
                    "instructions": instructions,
                    "knowledge": knowledge,
                    "logo_url": logo_url,
                    "notification_emails": notification_emails,
                    "office_hours": office_hours,
                    "office_phone": office_phone,
                    "outbound_phone_number": outbound_phone_number,
                },
                tenant_update_params.TenantUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TenantUpdateResponse,
        )

    def delete(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Delete tenant outreach configuration"""
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            "/outreach/tenant",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncTenantResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncTenantResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncTenantResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTenantResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncTenantResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        customer_facing_name: str,
        outbound_phone_number: str,
        instructions: Optional[str] | Omit = omit,
        knowledge: Optional[str] | Omit = omit,
        logo_url: Optional[str] | Omit = omit,
        notification_emails: SequenceNotStr[str] | Omit = omit,
        office_hours: Optional[str] | Omit = omit,
        office_phone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TenantCreateResponse:
        """
        Create tenant outreach configuration

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/outreach/tenant",
            body=await async_maybe_transform(
                {
                    "customer_facing_name": customer_facing_name,
                    "outbound_phone_number": outbound_phone_number,
                    "instructions": instructions,
                    "knowledge": knowledge,
                    "logo_url": logo_url,
                    "notification_emails": notification_emails,
                    "office_hours": office_hours,
                    "office_phone": office_phone,
                },
                tenant_create_params.TenantCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TenantCreateResponse,
        )

    async def retrieve(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Optional[TenantRetrieveResponse]:
        """Get tenant outreach configuration"""
        return await self._get(
            "/outreach/tenant",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TenantRetrieveResponse,
        )

    async def update(
        self,
        *,
        customer_facing_name: Optional[str] | Omit = omit,
        instructions: Optional[str] | Omit = omit,
        knowledge: Optional[str] | Omit = omit,
        logo_url: Optional[str] | Omit = omit,
        notification_emails: Optional[SequenceNotStr[str]] | Omit = omit,
        office_hours: Optional[str] | Omit = omit,
        office_phone: Optional[str] | Omit = omit,
        outbound_phone_number: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TenantUpdateResponse:
        """
        Update tenant outreach configuration

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._patch(
            "/outreach/tenant",
            body=await async_maybe_transform(
                {
                    "customer_facing_name": customer_facing_name,
                    "instructions": instructions,
                    "knowledge": knowledge,
                    "logo_url": logo_url,
                    "notification_emails": notification_emails,
                    "office_hours": office_hours,
                    "office_phone": office_phone,
                    "outbound_phone_number": outbound_phone_number,
                },
                tenant_update_params.TenantUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TenantUpdateResponse,
        )

    async def delete(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Delete tenant outreach configuration"""
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            "/outreach/tenant",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class TenantResourceWithRawResponse:
    def __init__(self, tenant: TenantResource) -> None:
        self._tenant = tenant

        self.create = to_raw_response_wrapper(
            tenant.create,
        )
        self.retrieve = to_raw_response_wrapper(
            tenant.retrieve,
        )
        self.update = to_raw_response_wrapper(
            tenant.update,
        )
        self.delete = to_raw_response_wrapper(
            tenant.delete,
        )


class AsyncTenantResourceWithRawResponse:
    def __init__(self, tenant: AsyncTenantResource) -> None:
        self._tenant = tenant

        self.create = async_to_raw_response_wrapper(
            tenant.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            tenant.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            tenant.update,
        )
        self.delete = async_to_raw_response_wrapper(
            tenant.delete,
        )


class TenantResourceWithStreamingResponse:
    def __init__(self, tenant: TenantResource) -> None:
        self._tenant = tenant

        self.create = to_streamed_response_wrapper(
            tenant.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            tenant.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            tenant.update,
        )
        self.delete = to_streamed_response_wrapper(
            tenant.delete,
        )


class AsyncTenantResourceWithStreamingResponse:
    def __init__(self, tenant: AsyncTenantResource) -> None:
        self._tenant = tenant

        self.create = async_to_streamed_response_wrapper(
            tenant.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            tenant.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            tenant.update,
        )
        self.delete = async_to_streamed_response_wrapper(
            tenant.delete,
        )
