# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from ..._utils import PropertyInfo
from ..._models import BaseModel

__all__ = [
    "EmailTemplateDeleteResponse",
    "AppointmentConfig",
    "AppointmentConfigSchedulingProvider",
    "AppointmentConfigSchedulingProviderClinicalConductorProvider",
    "AppointmentConfigSchedulingProviderTriallyCalendarProvider",
    "AppointmentConfigSchedulingProviderTriallyCalendarProviderCalendar",
    "EmailConfig",
    "HeroConfig",
    "HeroConfigQuickFact",
    "IntakeFormConfig",
    "IntakeFormConfigFieldHelpers",
    "NotAMatchConfig",
    "ScreeningConfig",
    "ScreeningConfigQuestion",
    "ScreeningConfigQuestionOption",
    "ScreeningPassedConfig",
]


class AppointmentConfigSchedulingProviderClinicalConductorProvider(BaseModel):
    """Clinical Conductor CTMS scheduling provider."""

    study_config_id: int = FieldInfo(alias="studyConfigId")

    type: Optional[Literal["clinical_conductor"]] = None


class AppointmentConfigSchedulingProviderTriallyCalendarProviderCalendar(BaseModel):
    """A bookable calendar within a Trially-powered landing page.

    Each entry maps to a NylasCalendarConfig and carries its own
    candidate-facing display data and CRC notification list.
    Multi-site LPs have one entry per physical location.
    """

    calendar_config_id: int = FieldInfo(alias="calendarConfigId")

    contact_phone: Optional[str] = FieldInfo(alias="contactPhone", default=None)

    label: Optional[str] = None

    location: Optional[str] = None

    notification_emails: Optional[List[str]] = FieldInfo(alias="notificationEmails", default=None)


class AppointmentConfigSchedulingProviderTriallyCalendarProvider(BaseModel):
    """Trially managed calendar scheduling provider.

    ``calendars`` holds one or more BookingCalendar entries.
    Single-site LPs use one entry (label/location optional — LP-level
    fields provide fallback).  Multi-site LPs use N entries, each
    with its own display data and notification routing.

    **Duration invariant:** all calendars on a landing page must share
    the same ``NylasCalendarConfig.duration_minutes``.  The booking
    flow resolves a single display duration per LP via
    ``AppointmentConfig.duration_override_minutes`` (platform-level)
    or the provider's duration (fetched from the first calendar).
    Heterogeneous durations would break both the override semantics
    and the candidate-facing display.
    """

    calendars: List[AppointmentConfigSchedulingProviderTriallyCalendarProviderCalendar]

    type: Optional[Literal["trially"]] = None


AppointmentConfigSchedulingProvider: TypeAlias = Annotated[
    Union[
        AppointmentConfigSchedulingProviderClinicalConductorProvider,
        AppointmentConfigSchedulingProviderTriallyCalendarProvider,
    ],
    PropertyInfo(discriminator="type"),
]


class AppointmentConfig(BaseModel):
    """Per-landing-page appointment configuration stored as JSONB.

    `appointment_type` drives UI content (labels, calendar events, emails).
    `scheduling_provider` determines which external system handles
    availability and booking (e.g. Clinical Conductor, Trially Scheduling).
    `duration_override_minutes` overrides the provider's visit duration
    for customer logistics; applied regardless of active provider.
    """

    appointment_type: Literal["in_person", "phone_call"] = FieldInfo(alias="appointmentType")

    scheduling_provider: AppointmentConfigSchedulingProvider = FieldInfo(alias="schedulingProvider")
    """Clinical Conductor CTMS scheduling provider."""

    duration_override_minutes: Optional[int] = FieldInfo(alias="durationOverrideMinutes", default=None)
    """Override the scheduling provider's visit duration.

    Applied platform-wide regardless of which provider is active.
    """


class EmailConfig(BaseModel):
    """Per-landing-page custom email template overrides stored as JSONB.

    Each optional field corresponds to a file-based template that can be
    overridden with custom HTML. Field names follow the pattern:
    ``{EmailTemplateKey.value}_html``.
    """

    booking_confirmation_html: Optional[str] = FieldInfo(alias="bookingConfirmationHtml", default=None)

    site_notification_html: Optional[str] = FieldInfo(alias="siteNotificationHtml", default=None)


class HeroConfigQuickFact(BaseModel):
    label: str

    value: str

    icon: Optional[str] = None


class HeroConfig(BaseModel):
    cta_text: str = FieldInfo(alias="ctaText")

    headline: str

    quick_facts: Optional[List[HeroConfigQuickFact]] = FieldInfo(alias="quickFacts", default=None)

    subheadline: Optional[str] = None


class IntakeFormConfigFieldHelpers(BaseModel):
    bmi: Optional[str] = None

    dob: Optional[str] = None

    family_name: Optional[str] = None

    given_name: Optional[str] = None


class IntakeFormConfig(BaseModel):
    description: str

    fields: List[Literal["given_name", "family_name", "dob", "bmi"]]

    title: str

    field_helpers: Optional[IntakeFormConfigFieldHelpers] = FieldInfo(alias="fieldHelpers", default=None)

    maximum_age: Optional[int] = FieldInfo(alias="maximumAge", default=None)

    maximum_bmi: Optional[float] = FieldInfo(alias="maximumBmi", default=None)

    minimum_age: Optional[int] = FieldInfo(alias="minimumAge", default=None)

    minimum_bmi: Optional[float] = FieldInfo(alias="minimumBmi", default=None)


class NotAMatchConfig(BaseModel):
    message: str

    title: str

    show_contact: Optional[bool] = FieldInfo(alias="showContact", default=None)


class ScreeningConfigQuestionOption(BaseModel):
    id: str

    text: str

    is_disqualifying: Optional[bool] = FieldInfo(alias="isDisqualifying", default=None)


class ScreeningConfigQuestion(BaseModel):
    id: str

    options: List[ScreeningConfigQuestionOption]

    prompt: str

    helper: Optional[str] = None


class ScreeningConfig(BaseModel):
    description: str

    questions: List[ScreeningConfigQuestion]

    title: str


class ScreeningPassedConfig(BaseModel):
    message: str

    title: str


class EmailTemplateDeleteResponse(BaseModel):
    id: int

    name: str

    slug: str

    study_name: str = FieldInfo(alias="studyName")

    appointment_config: Optional[AppointmentConfig] = FieldInfo(alias="appointmentConfig", default=None)
    """Per-landing-page appointment configuration stored as JSONB.

    `appointment_type` drives UI content (labels, calendar events, emails).
    `scheduling_provider` determines which external system handles availability and
    booking (e.g. Clinical Conductor, Trially Scheduling).
    `duration_override_minutes` overrides the provider's visit duration for customer
    logistics; applied regardless of active provider.
    """

    contact_phone: Optional[str] = FieldInfo(alias="contactPhone", default=None)

    email_config: Optional[EmailConfig] = FieldInfo(alias="emailConfig", default=None)
    """Per-landing-page custom email template overrides stored as JSONB.

    Each optional field corresponds to a file-based template that can be overridden
    with custom HTML. Field names follow the pattern:
    `{EmailTemplateKey.value}_html`.
    """

    hero_config: Optional[HeroConfig] = FieldInfo(alias="heroConfig", default=None)

    intake_form_config: Optional[IntakeFormConfig] = FieldInfo(alias="intakeFormConfig", default=None)

    location: Optional[str] = None

    not_a_match_config: Optional[NotAMatchConfig] = FieldInfo(alias="notAMatchConfig", default=None)

    screening_config: Optional[ScreeningConfig] = FieldInfo(alias="screeningConfig", default=None)

    screening_passed_config: Optional[ScreeningPassedConfig] = FieldInfo(alias="screeningPassedConfig", default=None)

    timezone: Optional[str] = None
