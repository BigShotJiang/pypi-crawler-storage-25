# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["EmailTemplateUpdateParams"]


class EmailTemplateUpdateParams(TypedDict, total=False):
    landing_page_id: Required[int]

    html: Required[str]
