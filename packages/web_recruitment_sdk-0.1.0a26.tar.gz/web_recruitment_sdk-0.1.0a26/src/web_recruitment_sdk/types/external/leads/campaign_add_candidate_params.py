# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date
from typing_extensions import Literal, Required, Annotated, TypedDict

from ...._utils import PropertyInfo

__all__ = ["CampaignAddCandidateParams"]


class CampaignAddCandidateParams(TypedDict, total=False):
    tenant_db_name: Required[str]

    cell_phone: Required[Annotated[str, PropertyInfo(alias="cellPhone")]]

    family_name: Required[Annotated[str, PropertyInfo(alias="familyName")]]

    given_name: Required[Annotated[str, PropertyInfo(alias="givenName")]]

    person_source_id: Required[Annotated[int, PropertyInfo(alias="personSourceId")]]

    city: Optional[str]

    dob: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]

    email: Optional[str]

    home_phone: Annotated[Optional[str], PropertyInfo(alias="homePhone")]

    middle_name: Annotated[Optional[str], PropertyInfo(alias="middleName")]

    preferred_language: Annotated[Literal["ENGLISH", "SPANISH"], PropertyInfo(alias="preferredLanguage")]

    site_id: Annotated[Optional[int], PropertyInfo(alias="siteId")]

    state: Optional[
        Literal[
            "AL",
            "AK",
            "AS",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "DC",
            "FL",
            "FM",
            "GA",
            "GU",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MH",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "MP",
            "OH",
            "OK",
            "OR",
            "PW",
            "PA",
            "PR",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "TT",
            "UT",
            "VT",
            "VA",
            "VI",
            "WA",
            "WV",
            "WI",
            "WY",
        ]
    ]
    """US state codes and territories."""

    street_address: Annotated[Optional[str], PropertyInfo(alias="streetAddress")]

    zip_code: Annotated[Optional[str], PropertyInfo(alias="zipCode")]
