# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .campaign_add_candidate_params import CampaignAddCandidateParams as CampaignAddCandidateParams
from .campaign_add_candidate_response import CampaignAddCandidateResponse as CampaignAddCandidateResponse
