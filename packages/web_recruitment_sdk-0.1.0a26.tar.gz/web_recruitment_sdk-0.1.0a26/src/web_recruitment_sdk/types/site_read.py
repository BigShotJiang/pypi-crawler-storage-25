# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["SiteRead"]


class SiteRead(BaseModel):
    id: int

    name: str

    city: Optional[str] = None

    latitude: Optional[float] = None

    longitude: Optional[float] = None

    state: Optional[str] = None

    street_address: Optional[str] = FieldInfo(alias="streetAddress", default=None)

    trially_site_id: Optional[str] = FieldInfo(alias="triallySiteId", default=None)

    zip_code: Optional[str] = FieldInfo(alias="zipCode", default=None)
