# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel

__all__ = ["ChartResponse", "Data", "DataBreakdown"]


class DataBreakdown(BaseModel):
    """Generic chart data breakdown"""

    count: int

    label: str

    metadata: Optional[object] = None


class Data(BaseModel):
    """Generic data point for any chart type"""

    label: str

    total: int

    breakdown: Optional[List[DataBreakdown]] = None

    key: Optional[str] = None


class ChartResponse(BaseModel):
    """Generic chart response"""

    data: List[Data]

    total: int

    metadata: Optional[object] = None
