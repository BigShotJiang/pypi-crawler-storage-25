# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["ConnectHandleCallbackParams"]


class ConnectHandleCallbackParams(TypedDict, total=False):
    code: Optional[str]

    error: Optional[str]

    error_description: Optional[str]

    error_reason: Optional[str]

    state: Optional[str]
