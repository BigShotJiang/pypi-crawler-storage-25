# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["FormMappingListMappingsResponse", "FormMappingListMappingsResponseItem"]


class FormMappingListMappingsResponseItem(BaseModel):
    """Model for reading a form-campaign mapping."""

    id: int

    campaign_id: int = FieldInfo(alias="campaignId")
    """Internal outreach campaign ID"""

    created_at: datetime = FieldInfo(alias="createdAt")

    fb_form_id: str = FieldInfo(alias="fbFormId")
    """Facebook Lead Form ID"""

    fb_page_id: str = FieldInfo(alias="fbPageId")
    """Facebook Page ID"""

    updated_at: datetime = FieldInfo(alias="updatedAt")

    is_active: Optional[bool] = FieldInfo(alias="isActive", default=None)

    person_source_id: Optional[int] = FieldInfo(alias="personSourceId", default=None)
    """PersonSource ID for lead attribution"""


FormMappingListMappingsResponse: TypeAlias = List[FormMappingListMappingsResponseItem]
