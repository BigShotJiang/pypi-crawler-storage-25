# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["ConnectStartOAuthResponse"]


class ConnectStartOAuthResponse(BaseModel):
    auth_url: str = FieldInfo(alias="authUrl")

    expires_in_seconds: int = FieldInfo(alias="expiresInSeconds")

    state: str
