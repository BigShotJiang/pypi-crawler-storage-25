# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["PageUpdateConfigParams"]


class PageUpdateConfigParams(TypedDict, total=False):
    is_active: Annotated[Optional[bool], PropertyInfo(alias="isActive")]

    page_access_token: Annotated[Optional[str], PropertyInfo(alias="pageAccessToken")]

    page_name: Annotated[Optional[str], PropertyInfo(alias="pageName")]
