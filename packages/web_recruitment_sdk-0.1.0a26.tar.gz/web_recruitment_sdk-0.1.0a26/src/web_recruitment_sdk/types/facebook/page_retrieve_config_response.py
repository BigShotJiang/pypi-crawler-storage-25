# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["PageRetrieveConfigResponse"]


class PageRetrieveConfigResponse(BaseModel):
    """Model for reading a tenant Facebook page config (excludes encrypted token)."""

    id: int

    created_at: datetime = FieldInfo(alias="createdAt")

    fb_page_id: str = FieldInfo(alias="fbPageId")

    is_active: bool = FieldInfo(alias="isActive")

    updated_at: datetime = FieldInfo(alias="updatedAt")

    page_name: Optional[str] = FieldInfo(alias="pageName", default=None)
