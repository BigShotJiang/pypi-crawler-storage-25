# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["PageListFormsResponse", "Form"]


class Form(BaseModel):
    """A Facebook lead form attached to a page."""

    id: str

    name: str

    status: str

    created_time: Optional[str] = FieldInfo(alias="createdTime", default=None)


class PageListFormsResponse(BaseModel):
    """Response containing list of lead forms for a page."""

    forms: List[Form]
