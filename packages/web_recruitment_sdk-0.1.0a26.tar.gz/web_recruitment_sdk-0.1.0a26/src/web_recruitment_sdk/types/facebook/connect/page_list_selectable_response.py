# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["PageListSelectableResponse", "Page"]


class Page(BaseModel):
    id: str

    name: str

    already_connected: Optional[bool] = FieldInfo(alias="alreadyConnected", default=None)


class PageListSelectableResponse(BaseModel):
    expires_in_seconds: int = FieldInfo(alias="expiresInSeconds")

    pages: List[Page]

    state: str
