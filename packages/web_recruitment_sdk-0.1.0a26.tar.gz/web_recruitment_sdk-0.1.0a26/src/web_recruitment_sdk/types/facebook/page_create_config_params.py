# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["PageCreateConfigParams"]


class PageCreateConfigParams(TypedDict, total=False):
    fb_page_id: Required[Annotated[str, PropertyInfo(alias="fbPageId")]]

    page_access_token: Required[Annotated[str, PropertyInfo(alias="pageAccessToken")]]

    is_active: Annotated[bool, PropertyInfo(alias="isActive")]

    page_name: Annotated[Optional[str], PropertyInfo(alias="pageName")]
