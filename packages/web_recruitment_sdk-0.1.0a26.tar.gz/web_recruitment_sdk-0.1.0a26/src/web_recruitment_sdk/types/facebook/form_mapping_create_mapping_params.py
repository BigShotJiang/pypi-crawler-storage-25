# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["FormMappingCreateMappingParams"]


class FormMappingCreateMappingParams(TypedDict, total=False):
    campaign_id: Required[Annotated[int, PropertyInfo(alias="campaignId")]]

    fb_form_id: Required[Annotated[str, PropertyInfo(alias="fbFormId")]]

    fb_page_id: Required[Annotated[str, PropertyInfo(alias="fbPageId")]]

    is_active: Annotated[bool, PropertyInfo(alias="isActive")]
