# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["ConnectFinalizeOAuthResponse", "Result"]


class Result(BaseModel):
    page_id: str = FieldInfo(alias="pageId")

    success: bool

    error: Optional[str] = None


class ConnectFinalizeOAuthResponse(BaseModel):
    results: List[Result]
