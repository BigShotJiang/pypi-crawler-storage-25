# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime
from typing_extensions import TypeAlias

from .._models import BaseModel

__all__ = ["ClinicalConductorListStudyConfigsResponse", "ClinicalConductorListStudyConfigsResponseItem"]


class ClinicalConductorListStudyConfigsResponseItem(BaseModel):
    """Response body for a study config."""

    id: int

    clinical_conductor_instance_id: int

    clinical_conductor_site_id: int

    clinical_conductor_study_id: int

    created_at: datetime

    is_active: bool

    target_visit_id: int

    updated_at: datetime


ClinicalConductorListStudyConfigsResponse: TypeAlias = List[ClinicalConductorListStudyConfigsResponseItem]
