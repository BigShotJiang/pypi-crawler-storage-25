# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["CriterionSetPriorityParams"]


class CriterionSetPriorityParams(TypedDict, total=False):
    protocol_id: Required[int]

    is_priority: Required[Annotated[bool, PropertyInfo(alias="isPriority")]]
