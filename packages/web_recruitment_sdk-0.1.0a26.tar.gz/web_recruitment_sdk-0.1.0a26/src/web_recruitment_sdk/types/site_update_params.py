# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["SiteUpdateParams"]


class SiteUpdateParams(TypedDict, total=False):
    city: Optional[str]

    name: Optional[str]

    state: Optional[str]

    street_address: Annotated[Optional[str], PropertyInfo(alias="streetAddress")]

    trially_site_id: Annotated[Optional[str], PropertyInfo(alias="triallySiteId")]

    zip_code: Annotated[Optional[str], PropertyInfo(alias="zipCode")]
