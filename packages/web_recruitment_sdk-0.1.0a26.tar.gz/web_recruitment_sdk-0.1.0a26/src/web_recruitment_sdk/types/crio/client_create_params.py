# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ClientCreateParams"]


class ClientCreateParams(TypedDict, total=False):
    external_client_id: Required[Annotated[str, PropertyInfo(alias="externalClientId")]]

    name: Required[str]
