# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["PatientUpdateWorkflowTagParams"]


class PatientUpdateWorkflowTagParams(TypedDict, total=False):
    custom_search_id: Required[int]

    workflow_tag: Annotated[
        Optional[Literal["disqualified", "enrolled", "follow_up", "reviewed"]], PropertyInfo(alias="workflowTag")
    ]
