# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["PatientUpdateWorkflowTagResponse", "WorkflowTag"]


class WorkflowTag(BaseModel):
    set_by_user_id: int = FieldInfo(alias="setByUserId")

    updated_at: datetime = FieldInfo(alias="updatedAt")

    value: Literal["disqualified", "enrolled", "follow_up", "reviewed"]

    set_by_user_email: Optional[str] = FieldInfo(alias="setByUserEmail", default=None)


class PatientUpdateWorkflowTagResponse(BaseModel):
    workflow_tag: Optional[WorkflowTag] = FieldInfo(alias="workflowTag", default=None)
