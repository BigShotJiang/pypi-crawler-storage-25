# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["DocumentRetrieveDownloadURLParams"]


class DocumentRetrieveDownloadURLParams(TypedDict, total=False):
    custom_search_id: Required[int]

    trially_patient_id: Required[str]
