# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from ..._models import BaseModel

__all__ = ["WorkflowListResponse", "WorkflowListResponseItem"]


class WorkflowListResponseItem(BaseModel):
    id: int

    config: object

    name: str


WorkflowListResponse: TypeAlias = List[WorkflowListResponseItem]
