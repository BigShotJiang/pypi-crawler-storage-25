# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["PersonSourceUpdateParams"]


class PersonSourceUpdateParams(TypedDict, total=False):
    description: Optional[str]

    name: Optional[str]

    source_metadata: Annotated[Optional[object], PropertyInfo(alias="sourceMetadata")]

    sync_frequency: Annotated[
        Optional[Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"]], PropertyInfo(alias="syncFrequency")
    ]
