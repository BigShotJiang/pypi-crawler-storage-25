# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["PersonSourceListResponse", "PersonSourceListResponseItem"]


class PersonSourceListResponseItem(BaseModel):
    id: int

    name: str

    type: Literal["CSV", "EHR", "API", "FACEBOOK_LEADS", "TRIALLY_LEADS"]

    description: Optional[str] = None

    last_sync_at: Optional[datetime] = FieldInfo(alias="lastSyncAt", default=None)

    source_metadata: Optional[object] = FieldInfo(alias="sourceMetadata", default=None)

    sync_frequency: Optional[Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"]] = FieldInfo(
        alias="syncFrequency", default=None
    )


PersonSourceListResponse: TypeAlias = List[PersonSourceListResponseItem]
