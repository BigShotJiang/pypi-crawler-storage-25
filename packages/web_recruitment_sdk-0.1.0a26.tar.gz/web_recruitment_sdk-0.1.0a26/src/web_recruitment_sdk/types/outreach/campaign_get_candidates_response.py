# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import date, datetime
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from ..._utils import PropertyInfo
from ..._models import BaseModel
from ..site_read import SiteRead

__all__ = [
    "CampaignGetCandidatesResponse",
    "CampaignGetCandidatesResponseItem",
    "CampaignGetCandidatesResponseItemCandidate",
    "CampaignGetCandidatesResponseItemCandidatePerson",
    "CampaignGetCandidatesResponseItemCandidatePersonSource",
    "CampaignGetCandidatesResponseItemOutreachAttempt",
    "CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachAction",
    "CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionPhoneCallActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionSMSActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionEmailActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionBookingPageActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachAction",
    "CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionPhoneCallActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionSMSActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionEmailActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionBookingPageActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachAction",
    "CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionPhoneCallActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionSMSActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionEmailActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionBookingPageActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachAction",
    "CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionPhoneCallActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionSMSActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionEmailActionRead",
    "CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionBookingPageActionRead",
]


class CampaignGetCandidatesResponseItemCandidatePersonSource(BaseModel):
    id: int

    name: str

    type: Literal["CSV", "EHR", "API", "FACEBOOK_LEADS", "TRIALLY_LEADS"]

    description: Optional[str] = None

    last_sync_at: Optional[datetime] = FieldInfo(alias="lastSyncAt", default=None)

    source_metadata: Optional[object] = FieldInfo(alias="sourceMetadata", default=None)

    sync_frequency: Optional[Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"]] = FieldInfo(
        alias="syncFrequency", default=None
    )


class CampaignGetCandidatesResponseItemCandidatePerson(BaseModel):
    id: int

    dob: Optional[date] = None

    email: Optional[str] = None

    family_name: str = FieldInfo(alias="familyName")

    given_name: str = FieldInfo(alias="givenName")

    cell_phone: Optional[str] = FieldInfo(alias="cellPhone", default=None)

    city: Optional[str] = None

    do_not_call: Optional[bool] = FieldInfo(alias="doNotCall", default=None)

    height_ft: Optional[int] = FieldInfo(alias="heightFt", default=None)

    height_in: Optional[int] = FieldInfo(alias="heightIn", default=None)

    home_phone: Optional[str] = FieldInfo(alias="homePhone", default=None)

    middle_name: Optional[str] = FieldInfo(alias="middleName", default=None)

    preferred_language: Optional[Literal["ENGLISH", "SPANISH"]] = FieldInfo(alias="preferredLanguage", default=None)

    sms_opted_out: Optional[bool] = FieldInfo(alias="smsOptedOut", default=None)

    sms_opted_out_at: Optional[datetime] = FieldInfo(alias="smsOptedOutAt", default=None)

    source: Optional[CampaignGetCandidatesResponseItemCandidatePersonSource] = None

    source_id: Optional[int] = FieldInfo(alias="sourceId", default=None)

    state: Optional[
        Literal[
            "AL",
            "AK",
            "AS",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "DC",
            "FL",
            "FM",
            "GA",
            "GU",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MH",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "MP",
            "OH",
            "OK",
            "OR",
            "PW",
            "PA",
            "PR",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "TT",
            "UT",
            "VT",
            "VA",
            "VI",
            "WA",
            "WV",
            "WI",
            "WY",
        ]
    ] = None
    """US state codes and territories."""

    street_address: Optional[str] = FieldInfo(alias="streetAddress", default=None)

    weight_lbs: Optional[float] = FieldInfo(alias="weightLbs", default=None)

    zip_code: Optional[str] = FieldInfo(alias="zipCode", default=None)


class CampaignGetCandidatesResponseItemCandidate(BaseModel):
    id: int

    person_id: int = FieldInfo(alias="personId")

    person: Optional[CampaignGetCandidatesResponseItemCandidatePerson] = None

    site: Optional[SiteRead] = None

    site_id: Optional[int] = FieldInfo(alias="siteId", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionBookingPageActionRead(
    BaseModel
):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionPhoneCallActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionSMSActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionEmailActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachActionBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["PHONE_CALL"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    caller_phone_number: Optional[str] = FieldInfo(alias="callerPhoneNumber", default=None)

    config_step_id: Optional[str] = FieldInfo(alias="configStepId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    duration_seconds: Optional[int] = FieldInfo(alias="durationSeconds", default=None)

    outreach_actions: Optional[
        List[CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptReadOutreachAction]
    ] = FieldInfo(alias="outreachActions", default=None)

    recipient_phone_number: Optional[str] = FieldInfo(alias="recipientPhoneNumber", default=None)

    transcript_url: Optional[str] = FieldInfo(alias="transcriptUrl", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionBookingPageActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionPhoneCallActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionSMSActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionEmailActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachActionBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["SMS"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    config_step_id: Optional[str] = FieldInfo(alias="configStepId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    outreach_actions: Optional[List[CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptReadOutreachAction]] = (
        FieldInfo(alias="outreachActions", default=None)
    )

    recipient_phone_number: Optional[str] = FieldInfo(alias="recipientPhoneNumber", default=None)

    sender_phone_number: Optional[str] = FieldInfo(alias="senderPhoneNumber", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionBookingPageActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionPhoneCallActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionSMSActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionEmailActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachActionBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["EMAIL"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    config_step_id: Optional[str] = FieldInfo(alias="configStepId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    outreach_actions: Optional[List[CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptReadOutreachAction]] = (
        FieldInfo(alias="outreachActions", default=None)
    )

    recipient_email: Optional[str] = FieldInfo(alias="recipientEmail", default=None)

    sender_email: Optional[str] = FieldInfo(alias="senderEmail", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionPhoneCallActionRead(
    BaseModel
):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionBookingPageActionRead(
    BaseModel
):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionPhoneCallActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionSMSActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionEmailActionRead,
        CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachActionBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["BOOKING_PAGE"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    config_step_id: Optional[str] = FieldInfo(alias="configStepId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    outreach_actions: Optional[
        List[CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptReadOutreachAction]
    ] = FieldInfo(alias="outreachActions", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


CampaignGetCandidatesResponseItemOutreachAttempt: TypeAlias = Annotated[
    Union[
        CampaignGetCandidatesResponseItemOutreachAttemptPhoneCallAttemptRead,
        CampaignGetCandidatesResponseItemOutreachAttemptSMSAttemptRead,
        CampaignGetCandidatesResponseItemOutreachAttemptEmailAttemptRead,
        CampaignGetCandidatesResponseItemOutreachAttemptBookingPageAttemptRead,
    ],
    PropertyInfo(discriminator="attempt_type"),
]


class CampaignGetCandidatesResponseItem(BaseModel):
    id: int

    campaign_id: int = FieldInfo(alias="campaignId")

    candidate_id: int = FieldInfo(alias="candidateId")

    candidate: Optional[CampaignGetCandidatesResponseItemCandidate] = None

    outreach_attempts: Optional[List[CampaignGetCandidatesResponseItemOutreachAttempt]] = FieldInfo(
        alias="outreachAttempts", default=None
    )

    status: Optional[Literal["NOT_STARTED", "IN_PROGRESS", "SUCCESSFUL", "UNSUCCESSFUL"]] = None
    """Candidate's journey state within a campaign"""

    workflow_id: Optional[str] = FieldInfo(alias="workflowId", default=None)


CampaignGetCandidatesResponse: TypeAlias = List[CampaignGetCandidatesResponseItem]
