# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["CampaignSetLandingPageParams"]


class CampaignSetLandingPageParams(TypedDict, total=False):
    landing_page_id: Required[Annotated[Optional[int], PropertyInfo(alias="landingPageId")]]
    """Landing page ID to link, or null to unlink"""
