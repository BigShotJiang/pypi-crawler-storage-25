# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date
from typing_extensions import Literal, Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["CampaignCreateParams"]


class CampaignCreateParams(TypedDict, total=False):
    booking_url: Required[Annotated[str, PropertyInfo(alias="bookingUrl")]]

    candidate_ids: Required[Annotated[Iterable[int], PropertyInfo(alias="candidateIds")]]
    """List of candidate IDs to include in campaign"""

    name: Required[str]

    start_date: Required[Annotated[Union[str, date], PropertyInfo(alias="startDate", format="iso8601")]]
    """First day of the campaign (YYYY-MM-DD)"""

    workflow_id: Required[Annotated[int, PropertyInfo(alias="workflowId")]]
    """Config-driven workflow definition ID"""

    concurrency_limit: Annotated[int, PropertyInfo(alias="concurrencyLimit")]
    """Maximum concurrent outreach calls allowed for this campaign"""

    context: Optional[str]
    """Additional context included in all outreach calls for this campaign"""

    end_date: Annotated[Union[str, date, None], PropertyInfo(alias="endDate", format="iso8601")]
    """Last day of the campaign (YYYY-MM-DD)"""

    fallback_timezone: Annotated[
        Optional[
            Literal[
                "US/Eastern",
                "US/Central",
                "US/Mountain",
                "US/Pacific",
                "US/Alaska",
                "US/Hawaii",
                "US/Arizona",
                "America/New_York",
                "America/Chicago",
                "America/Denver",
                "America/Los_Angeles",
                "America/Phoenix",
                "America/Anchorage",
                "America/Honolulu",
                "America/Toronto",
                "America/Mexico_City",
                "America/Sao_Paulo",
                "America/Buenos_Aires",
                "Europe/London",
                "Europe/Paris",
                "Europe/Berlin",
                "Europe/Madrid",
                "Europe/Rome",
                "Europe/Amsterdam",
                "Europe/Brussels",
                "Europe/Vienna",
                "Europe/Zurich",
                "Europe/Stockholm",
                "Europe/Moscow",
                "Europe/Istanbul",
                "Asia/Tokyo",
                "Asia/Shanghai",
                "Asia/Hong_Kong",
                "Asia/Singapore",
                "Asia/Seoul",
                "Asia/Kolkata",
                "Asia/Dubai",
                "Asia/Bangkok",
                "Asia/Jakarta",
                "Asia/Manila",
                "Australia/Sydney",
                "Australia/Melbourne",
                "Australia/Perth",
                "Pacific/Auckland",
                "UTC",
            ]
        ],
        PropertyInfo(alias="fallbackTimezone"),
    ]
    """IANA timezone names (commonly used US and global timezones).

    These are standard timezone identifiers used for scheduling and time-based
    operations. For a complete list, see:
    https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
    """

    landing_page_id: Annotated[Optional[int], PropertyInfo(alias="landingPageId")]
    """Landing page to associate with this campaign"""

    minimum_appointment_lead_time_hours: Annotated[float, PropertyInfo(alias="minimumAppointmentLeadTimeHours")]
    """Minimum hours between now and an appointment slot for it to be bookable"""

    outreach_hours_end: Annotated[Optional[int], PropertyInfo(alias="outreachHoursEnd")]
    """End hour for outreach in candidate's local timezone (0-23)"""

    outreach_hours_start: Annotated[Optional[int], PropertyInfo(alias="outreachHoursStart")]
    """Start hour for outreach in candidate's local timezone (0-23)"""

    principal_investigator: Annotated[Optional[str], PropertyInfo(alias="principalInvestigator")]

    reminder_delay_hours: Annotated[float, PropertyInfo(alias="reminderDelayHours")]
    """
    Hours to wait before sending reminder (supports fractional hours for testing,
    e.g., 0.01 = 36 seconds)
    """

    reminder_enabled: Annotated[bool, PropertyInfo(alias="reminderEnabled")]
    """Whether to send booking link reminders"""
