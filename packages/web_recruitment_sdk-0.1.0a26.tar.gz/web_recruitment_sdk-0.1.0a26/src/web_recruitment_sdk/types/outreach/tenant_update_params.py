# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Annotated, TypedDict

from ..._types import SequenceNotStr
from ..._utils import PropertyInfo

__all__ = ["TenantUpdateParams"]


class TenantUpdateParams(TypedDict, total=False):
    customer_facing_name: Annotated[Optional[str], PropertyInfo(alias="customerFacingName")]

    instructions: Optional[str]

    knowledge: Optional[str]

    logo_url: Annotated[Optional[str], PropertyInfo(alias="logoUrl")]

    notification_emails: Annotated[Optional[SequenceNotStr[str]], PropertyInfo(alias="notificationEmails")]

    office_hours: Annotated[Optional[str], PropertyInfo(alias="officeHours")]

    office_phone: Annotated[Optional[str], PropertyInfo(alias="officePhone")]

    outbound_phone_number: Annotated[Optional[str], PropertyInfo(alias="outboundPhoneNumber")]
