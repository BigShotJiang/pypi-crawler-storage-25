# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import date, datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from ..site_read import SiteRead

__all__ = [
    "CandidateListResponse",
    "CandidateListResponseItem",
    "CandidateListResponseItemPerson",
    "CandidateListResponseItemPersonSource",
]


class CandidateListResponseItemPersonSource(BaseModel):
    id: int

    name: str

    type: Literal["CSV", "EHR", "API", "FACEBOOK_LEADS", "TRIALLY_LEADS"]

    description: Optional[str] = None

    last_sync_at: Optional[datetime] = FieldInfo(alias="lastSyncAt", default=None)

    source_metadata: Optional[object] = FieldInfo(alias="sourceMetadata", default=None)

    sync_frequency: Optional[Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"]] = FieldInfo(
        alias="syncFrequency", default=None
    )


class CandidateListResponseItemPerson(BaseModel):
    id: int

    dob: Optional[date] = None

    email: Optional[str] = None

    family_name: str = FieldInfo(alias="familyName")

    given_name: str = FieldInfo(alias="givenName")

    cell_phone: Optional[str] = FieldInfo(alias="cellPhone", default=None)

    city: Optional[str] = None

    do_not_call: Optional[bool] = FieldInfo(alias="doNotCall", default=None)

    height_ft: Optional[int] = FieldInfo(alias="heightFt", default=None)

    height_in: Optional[int] = FieldInfo(alias="heightIn", default=None)

    home_phone: Optional[str] = FieldInfo(alias="homePhone", default=None)

    middle_name: Optional[str] = FieldInfo(alias="middleName", default=None)

    preferred_language: Optional[Literal["ENGLISH", "SPANISH"]] = FieldInfo(alias="preferredLanguage", default=None)

    sms_opted_out: Optional[bool] = FieldInfo(alias="smsOptedOut", default=None)

    sms_opted_out_at: Optional[datetime] = FieldInfo(alias="smsOptedOutAt", default=None)

    source: Optional[CandidateListResponseItemPersonSource] = None

    source_id: Optional[int] = FieldInfo(alias="sourceId", default=None)

    state: Optional[
        Literal[
            "AL",
            "AK",
            "AS",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "DC",
            "FL",
            "FM",
            "GA",
            "GU",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MH",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "MP",
            "OH",
            "OK",
            "OR",
            "PW",
            "PA",
            "PR",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "TT",
            "UT",
            "VT",
            "VA",
            "VI",
            "WA",
            "WV",
            "WI",
            "WY",
        ]
    ] = None
    """US state codes and territories."""

    street_address: Optional[str] = FieldInfo(alias="streetAddress", default=None)

    weight_lbs: Optional[float] = FieldInfo(alias="weightLbs", default=None)

    zip_code: Optional[str] = FieldInfo(alias="zipCode", default=None)


class CandidateListResponseItem(BaseModel):
    id: int

    person_id: int = FieldInfo(alias="personId")

    person: Optional[CandidateListResponseItemPerson] = None

    site: Optional[SiteRead] = None

    site_id: Optional[int] = FieldInfo(alias="siteId", default=None)


CandidateListResponse: TypeAlias = List[CandidateListResponseItem]
