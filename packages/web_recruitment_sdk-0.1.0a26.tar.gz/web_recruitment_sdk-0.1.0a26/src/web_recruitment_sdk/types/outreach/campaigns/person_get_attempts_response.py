# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from ...._utils import PropertyInfo
from ...._models import BaseModel

__all__ = [
    "PersonGetAttemptsResponse",
    "PersonGetAttemptsResponseItem",
    "PersonGetAttemptsResponseItemPhoneCallAttemptRead",
    "PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachAction",
    "PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionPhoneCallActionRead",
    "PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionSMSActionRead",
    "PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionEmailActionRead",
    "PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionBookingPageActionRead",
    "PersonGetAttemptsResponseItemSMSAttemptRead",
    "PersonGetAttemptsResponseItemSMSAttemptReadOutreachAction",
    "PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionPhoneCallActionRead",
    "PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionSMSActionRead",
    "PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionEmailActionRead",
    "PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionBookingPageActionRead",
    "PersonGetAttemptsResponseItemEmailAttemptRead",
    "PersonGetAttemptsResponseItemEmailAttemptReadOutreachAction",
    "PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionPhoneCallActionRead",
    "PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionSMSActionRead",
    "PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionEmailActionRead",
    "PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionBookingPageActionRead",
    "PersonGetAttemptsResponseItemBookingPageAttemptRead",
    "PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachAction",
    "PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionPhoneCallActionRead",
    "PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionSMSActionRead",
    "PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionEmailActionRead",
    "PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionBookingPageActionRead",
]


class PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionBookingPageActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionPhoneCallActionRead,
        PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionSMSActionRead,
        PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionEmailActionRead,
        PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachActionBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class PersonGetAttemptsResponseItemPhoneCallAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["PHONE_CALL"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    caller_phone_number: Optional[str] = FieldInfo(alias="callerPhoneNumber", default=None)

    config_step_id: Optional[str] = FieldInfo(alias="configStepId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    duration_seconds: Optional[int] = FieldInfo(alias="durationSeconds", default=None)

    outreach_actions: Optional[List[PersonGetAttemptsResponseItemPhoneCallAttemptReadOutreachAction]] = FieldInfo(
        alias="outreachActions", default=None
    )

    recipient_phone_number: Optional[str] = FieldInfo(alias="recipientPhoneNumber", default=None)

    transcript_url: Optional[str] = FieldInfo(alias="transcriptUrl", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionBookingPageActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


PersonGetAttemptsResponseItemSMSAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionPhoneCallActionRead,
        PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionSMSActionRead,
        PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionEmailActionRead,
        PersonGetAttemptsResponseItemSMSAttemptReadOutreachActionBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class PersonGetAttemptsResponseItemSMSAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["SMS"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    config_step_id: Optional[str] = FieldInfo(alias="configStepId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    outreach_actions: Optional[List[PersonGetAttemptsResponseItemSMSAttemptReadOutreachAction]] = FieldInfo(
        alias="outreachActions", default=None
    )

    recipient_phone_number: Optional[str] = FieldInfo(alias="recipientPhoneNumber", default=None)

    sender_phone_number: Optional[str] = FieldInfo(alias="senderPhoneNumber", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionBookingPageActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


PersonGetAttemptsResponseItemEmailAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionPhoneCallActionRead,
        PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionSMSActionRead,
        PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionEmailActionRead,
        PersonGetAttemptsResponseItemEmailAttemptReadOutreachActionBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class PersonGetAttemptsResponseItemEmailAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["EMAIL"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    config_step_id: Optional[str] = FieldInfo(alias="configStepId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    outreach_actions: Optional[List[PersonGetAttemptsResponseItemEmailAttemptReadOutreachAction]] = FieldInfo(
        alias="outreachActions", default=None
    )

    recipient_email: Optional[str] = FieldInfo(alias="recipientEmail", default=None)

    sender_email: Optional[str] = FieldInfo(alias="senderEmail", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionBookingPageActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachAction: TypeAlias = Annotated[
    Union[
        PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionPhoneCallActionRead,
        PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionSMSActionRead,
        PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionEmailActionRead,
        PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachActionBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]


class PersonGetAttemptsResponseItemBookingPageAttemptRead(BaseModel):
    id: int

    attempt_type: Literal["BOOKING_PAGE"] = FieldInfo(alias="attemptType")

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    task_id: Optional[int] = FieldInfo(alias="taskId", default=None)

    config_step_id: Optional[str] = FieldInfo(alias="configStepId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    outreach_actions: Optional[List[PersonGetAttemptsResponseItemBookingPageAttemptReadOutreachAction]] = FieldInfo(
        alias="outreachActions", default=None
    )

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


PersonGetAttemptsResponseItem: TypeAlias = Annotated[
    Union[
        PersonGetAttemptsResponseItemPhoneCallAttemptRead,
        PersonGetAttemptsResponseItemSMSAttemptRead,
        PersonGetAttemptsResponseItemEmailAttemptRead,
        PersonGetAttemptsResponseItemBookingPageAttemptRead,
    ],
    PropertyInfo(discriminator="attempt_type"),
]

PersonGetAttemptsResponse: TypeAlias = List[PersonGetAttemptsResponseItem]
