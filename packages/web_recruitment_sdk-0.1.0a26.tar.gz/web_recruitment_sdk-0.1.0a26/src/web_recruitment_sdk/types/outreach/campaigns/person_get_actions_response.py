# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from ...._utils import PropertyInfo
from ...._models import BaseModel

__all__ = [
    "PersonGetActionsResponse",
    "PersonGetActionsResponseItem",
    "PersonGetActionsResponseItemPhoneCallActionRead",
    "PersonGetActionsResponseItemSMSActionRead",
    "PersonGetActionsResponseItemEmailActionRead",
    "PersonGetActionsResponseItemBookingPageActionRead",
]


class PersonGetActionsResponseItemPhoneCallActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["PHONE_CALL"]

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "STARTED",
            "CALL_INITIATION_ERROR",
            "ANSWERED",
            "CANDIDATE_IDENTITY_VERIFIED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "BOOKING_LINK_SENT",
            "DO_NOT_CALL",
            "ENDED",
        ]
    ] = None
    """Status values specific to phone call actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetActionsResponseItemSMSActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["SMS"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[
        Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "BOOKING_LINK_CLICKED",
            "BOOKING_LINK_REMINDER_SENT",
            "ABANDONMENT_REMINDER_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ]
    ] = None
    """Status values specific to SMS actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetActionsResponseItemEmailActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["EMAIL"]

    booking_url: Optional[str] = FieldInfo(alias="bookingUrl", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    message: Optional[str] = None

    status: Optional[Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]] = None
    """Status values specific to email actions"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class PersonGetActionsResponseItemBookingPageActionRead(BaseModel):
    id: int

    outreach_attempt_id: int = FieldInfo(alias="outreachAttemptId")

    type: Literal["BOOKING_PAGE"]

    action_metadata: Optional[object] = FieldInfo(alias="actionMetadata", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    status: Optional[
        Literal[
            "OPENED",
            "INTAKE_PASSED",
            "INTAKE_FAILED",
            "SCREENING_PASSED",
            "SCREENING_FAILED",
            "APPOINTMENT_BOOKING_ATTEMPTED",
            "APPOINTMENT_BOOKING_FAILED",
            "APPOINTMENT_BOOKED",
        ]
    ] = None
    """Status values for booking page funnel actions."""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


PersonGetActionsResponseItem: TypeAlias = Annotated[
    Union[
        PersonGetActionsResponseItemPhoneCallActionRead,
        PersonGetActionsResponseItemSMSActionRead,
        PersonGetActionsResponseItemEmailActionRead,
        PersonGetActionsResponseItemBookingPageActionRead,
    ],
    PropertyInfo(discriminator="type"),
]

PersonGetActionsResponse: TypeAlias = List[PersonGetActionsResponseItem]
