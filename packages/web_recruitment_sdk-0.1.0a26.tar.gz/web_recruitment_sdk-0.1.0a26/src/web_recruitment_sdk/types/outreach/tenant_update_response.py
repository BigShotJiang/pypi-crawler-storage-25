# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["TenantUpdateResponse"]


class TenantUpdateResponse(BaseModel):
    id: int

    customer_facing_name: str = FieldInfo(alias="customerFacingName")

    outbound_phone_number: str = FieldInfo(alias="outboundPhoneNumber")

    instructions: Optional[str] = None

    knowledge: Optional[str] = None

    logo_url: Optional[str] = FieldInfo(alias="logoUrl", default=None)

    notification_emails: Optional[List[str]] = FieldInfo(alias="notificationEmails", default=None)

    office_hours: Optional[str] = FieldInfo(alias="officeHours", default=None)

    office_phone: Optional[str] = FieldInfo(alias="officePhone", default=None)
