# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["PersonSourceCreateParams"]


class PersonSourceCreateParams(TypedDict, total=False):
    name: Required[str]

    type: Required[Literal["CSV", "EHR", "API", "FACEBOOK_LEADS", "TRIALLY_LEADS"]]

    description: Optional[str]

    source_metadata: Annotated[Optional[object], PropertyInfo(alias="sourceMetadata")]

    sync_frequency: Annotated[Literal["MANUAL", "DAILY", "WEEKLY", "CONTINUOUS"], PropertyInfo(alias="syncFrequency")]
