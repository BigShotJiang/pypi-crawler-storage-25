# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import date, datetime
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from ..._utils import PropertyInfo
from ..._models import BaseModel

__all__ = [
    "CandidateRetrieveJourneyResponse",
    "Campaign",
    "CampaignCampaign",
    "CampaignEvent",
    "CampaignEventJourneyPhoneCallEvent",
    "CampaignEventJourneySMSEvent",
    "CampaignEventJourneyEmailEvent",
    "CampaignEventJourneyBookingPageEvent",
    "CampaignEventJourneyAppointmentEvent",
    "CampaignEventJourneyAddedToCampaignEvent",
    "Candidate",
    "CandidateSource",
]


class CampaignCampaign(BaseModel):
    id: int

    name: str


class CampaignEventJourneyPhoneCallEvent(BaseModel):
    occurred_at: datetime = FieldInfo(alias="occurredAt")

    outcome: Literal[
        "STARTED",
        "CALL_INITIATION_ERROR",
        "ANSWERED",
        "CANDIDATE_IDENTITY_VERIFIED",
        "NO_ANSWER",
        "VOICEMAIL_LEFT",
        "WRONG_NUMBER",
        "HANGUP",
        "INTERESTED",
        "NOT_INTERESTED",
        "SCHEDULED",
        "BOOKING_LINK_SENT",
        "DO_NOT_CALL",
        "ENDED",
    ]
    """Status values specific to phone call actions"""

    duration_seconds: Optional[int] = FieldInfo(alias="durationSeconds", default=None)

    transcript_url: Optional[str] = FieldInfo(alias="transcriptUrl", default=None)

    type: Optional[Literal["phone_call"]] = None


class CampaignEventJourneySMSEvent(BaseModel):
    occurred_at: datetime = FieldInfo(alias="occurredAt")

    outcome: Literal[
        "SENT",
        "FAILED_TO_SEND",
        "REPLIED",
        "INTERESTED",
        "NOT_INTERESTED",
        "BOOKING_LINK_SENT",
        "BOOKING_LINK_CLICKED",
        "BOOKING_LINK_REMINDER_SENT",
        "ABANDONMENT_REMINDER_SENT",
        "SCHEDULED",
        "DO_NOT_CALL",
    ]
    """Status values specific to SMS actions"""

    type: Optional[Literal["sms"]] = None


class CampaignEventJourneyEmailEvent(BaseModel):
    occurred_at: datetime = FieldInfo(alias="occurredAt")

    outcome: Literal["SENT", "FAILED_TO_SEND", "BOOKING_LINK_SENT", "APPOINTMENT_CONFIRMATION_SENT"]
    """Status values specific to email actions"""

    type: Optional[Literal["email"]] = None


class CampaignEventJourneyBookingPageEvent(BaseModel):
    occurred_at: datetime = FieldInfo(alias="occurredAt")

    outcome: Literal[
        "OPENED",
        "INTAKE_PASSED",
        "INTAKE_FAILED",
        "SCREENING_PASSED",
        "SCREENING_FAILED",
        "APPOINTMENT_BOOKING_ATTEMPTED",
        "APPOINTMENT_BOOKING_FAILED",
        "APPOINTMENT_BOOKED",
    ]
    """Status values for booking page funnel actions."""

    type: Optional[Literal["booking_page"]] = None


class CampaignEventJourneyAppointmentEvent(BaseModel):
    appointment_id: int = FieldInfo(alias="appointmentId")

    appointment_type: Literal["in_person", "phone_call"] = FieldInfo(alias="appointmentType")

    occurred_at: datetime = FieldInfo(alias="occurredAt")

    scheduled_datetime: datetime = FieldInfo(alias="scheduledDatetime")

    status: Literal["booked", "cancelled"]

    location: Optional[str] = None

    type: Optional[Literal["appointment"]] = None


class CampaignEventJourneyAddedToCampaignEvent(BaseModel):
    occurred_at: datetime = FieldInfo(alias="occurredAt")

    type: Optional[Literal["added_to_campaign"]] = None


CampaignEvent: TypeAlias = Annotated[
    Union[
        CampaignEventJourneyPhoneCallEvent,
        CampaignEventJourneySMSEvent,
        CampaignEventJourneyEmailEvent,
        CampaignEventJourneyBookingPageEvent,
        CampaignEventJourneyAppointmentEvent,
        CampaignEventJourneyAddedToCampaignEvent,
    ],
    PropertyInfo(discriminator="type"),
]


class Campaign(BaseModel):
    added_at: datetime = FieldInfo(alias="addedAt")

    campaign: CampaignCampaign

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    events: List[CampaignEvent]

    status: Literal["NOT_STARTED", "IN_PROGRESS", "SUCCESSFUL", "UNSUCCESSFUL"]
    """Candidate's journey state within a campaign"""

    halt_reason: Optional[
        Literal[
            "APPOINTMENT_BOOKED",
            "CANDIDATE_NOT_INTERESTED",
            "CANDIDATE_OPTED_OUT",
            "CANDIDATE_UNREACHABLE",
            "SCREENING_FAILED",
            "INTAKE_FAILED",
            "NO_FURTHER_STEPS",
        ]
    ] = FieldInfo(alias="haltReason", default=None)
    """Machine code for why a candidate's campaign journey ended.

    Set on `CampaignJourneyRead.halt_reason` when the campaign status is terminal
    (SUCCESSFUL or UNSUCCESSFUL). Exactly one code per terminal journey — the
    reducer picks the most specific applicable value and falls back to
    NO_FURTHER_STEPS when nothing else fits. The UI maps each code to a
    user-friendly sentence in a single dictionary; it never invents a halt reason
    from the event stream.
    """

    next_scheduled_at: Optional[datetime] = FieldInfo(alias="nextScheduledAt", default=None)


class CandidateSource(BaseModel):
    id: int

    name: str

    type: Literal["CSV", "EHR", "API", "FACEBOOK_LEADS", "TRIALLY_LEADS"]


class Candidate(BaseModel):
    id: int

    cell_phone: Optional[str] = FieldInfo(alias="cellPhone", default=None)

    dob: Optional[date] = None

    email: Optional[str] = None

    family_name: Optional[str] = FieldInfo(alias="familyName", default=None)

    given_name: Optional[str] = FieldInfo(alias="givenName", default=None)

    home_phone: Optional[str] = FieldInfo(alias="homePhone", default=None)

    middle_name: Optional[str] = FieldInfo(alias="middleName", default=None)

    sources: Optional[List[CandidateSource]] = None

    trially_patient_id: Optional[str] = FieldInfo(alias="triallyPatientId", default=None)


class CandidateRetrieveJourneyResponse(BaseModel):
    campaigns: List[Campaign]

    candidate: Candidate
