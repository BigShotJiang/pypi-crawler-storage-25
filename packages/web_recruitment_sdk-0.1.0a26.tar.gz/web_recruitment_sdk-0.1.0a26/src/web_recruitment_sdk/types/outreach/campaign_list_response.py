# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import date, datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = [
    "CampaignListResponse",
    "UnionMember0",
    "UnionMember0LandingPage",
    "UnionMember1",
    "UnionMember1LandingPage",
    "UnionMember1Metrics",
]


class UnionMember0LandingPage(BaseModel):
    """Lightweight summary for embedding in campaign responses."""

    id: int

    name: str

    slug: str

    study_name: str = FieldInfo(alias="studyName")

    has_appointment_config: Optional[bool] = FieldInfo(alias="hasAppointmentConfig", default=None)

    has_hero: Optional[bool] = FieldInfo(alias="hasHero", default=None)

    has_intake_form: Optional[bool] = FieldInfo(alias="hasIntakeForm", default=None)

    has_not_a_match: Optional[bool] = FieldInfo(alias="hasNotAMatch", default=None)

    has_screening_passed: Optional[bool] = FieldInfo(alias="hasScreeningPassed", default=None)

    question_count: Optional[int] = FieldInfo(alias="questionCount", default=None)


class UnionMember0(BaseModel):
    id: int

    booking_url: str = FieldInfo(alias="bookingUrl")

    concurrency_limit: int = FieldInfo(alias="concurrencyLimit")

    created_at: datetime = FieldInfo(alias="createdAt")

    name: str

    start_date: date = FieldInfo(alias="startDate")

    status: Literal["NOT_STARTED", "IN_PROGRESS", "COMPLETED", "PAUSED"]
    """Campaign states"""

    total_candidates: int = FieldInfo(alias="totalCandidates")

    updated_at: datetime = FieldInfo(alias="updatedAt")

    action_type: Optional[Literal["PHONE_CALL", "SMS", "EMAIL", "BOOKING_PAGE"]] = FieldInfo(
        alias="actionType", default=None
    )

    context: Optional[str] = None

    end_date: Optional[date] = FieldInfo(alias="endDate", default=None)

    fallback_timezone: Optional[
        Literal[
            "US/Eastern",
            "US/Central",
            "US/Mountain",
            "US/Pacific",
            "US/Alaska",
            "US/Hawaii",
            "US/Arizona",
            "America/New_York",
            "America/Chicago",
            "America/Denver",
            "America/Los_Angeles",
            "America/Phoenix",
            "America/Anchorage",
            "America/Honolulu",
            "America/Toronto",
            "America/Mexico_City",
            "America/Sao_Paulo",
            "America/Buenos_Aires",
            "Europe/London",
            "Europe/Paris",
            "Europe/Berlin",
            "Europe/Madrid",
            "Europe/Rome",
            "Europe/Amsterdam",
            "Europe/Brussels",
            "Europe/Vienna",
            "Europe/Zurich",
            "Europe/Stockholm",
            "Europe/Moscow",
            "Europe/Istanbul",
            "Asia/Tokyo",
            "Asia/Shanghai",
            "Asia/Hong_Kong",
            "Asia/Singapore",
            "Asia/Seoul",
            "Asia/Kolkata",
            "Asia/Dubai",
            "Asia/Bangkok",
            "Asia/Jakarta",
            "Asia/Manila",
            "Australia/Sydney",
            "Australia/Melbourne",
            "Australia/Perth",
            "Pacific/Auckland",
            "UTC",
        ]
    ] = FieldInfo(alias="fallbackTimezone", default=None)
    """IANA timezone names (commonly used US and global timezones).

    These are standard timezone identifiers used for scheduling and time-based
    operations. For a complete list, see:
    https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
    """

    landing_page: Optional[UnionMember0LandingPage] = FieldInfo(alias="landingPage", default=None)
    """Lightweight summary for embedding in campaign responses."""

    landing_page_id: Optional[int] = FieldInfo(alias="landingPageId", default=None)

    max_phone_calls_per_candidate: Optional[int] = FieldInfo(alias="maxPhoneCallsPerCandidate", default=None)

    minimum_appointment_lead_time_hours: Optional[float] = FieldInfo(
        alias="minimumAppointmentLeadTimeHours", default=None
    )

    outreach_hours_end: Optional[int] = FieldInfo(alias="outreachHoursEnd", default=None)

    outreach_hours_start: Optional[int] = FieldInfo(alias="outreachHoursStart", default=None)

    principal_investigator: Optional[str] = FieldInfo(alias="principalInvestigator", default=None)

    reminder_delay_hours: Optional[float] = FieldInfo(alias="reminderDelayHours", default=None)

    reminder_enabled: Optional[bool] = FieldInfo(alias="reminderEnabled", default=None)

    workflow_id: Optional[int] = FieldInfo(alias="workflowId", default=None)

    workflow_name: Optional[str] = FieldInfo(alias="workflowName", default=None)


class UnionMember1LandingPage(BaseModel):
    """Lightweight summary for embedding in campaign responses."""

    id: int

    name: str

    slug: str

    study_name: str = FieldInfo(alias="studyName")

    has_appointment_config: Optional[bool] = FieldInfo(alias="hasAppointmentConfig", default=None)

    has_hero: Optional[bool] = FieldInfo(alias="hasHero", default=None)

    has_intake_form: Optional[bool] = FieldInfo(alias="hasIntakeForm", default=None)

    has_not_a_match: Optional[bool] = FieldInfo(alias="hasNotAMatch", default=None)

    has_screening_passed: Optional[bool] = FieldInfo(alias="hasScreeningPassed", default=None)

    question_count: Optional[int] = FieldInfo(alias="questionCount", default=None)


class UnionMember1Metrics(BaseModel):
    """Aggregated outreach metrics for candidates in a campaign."""

    calls_made: int = FieldInfo(alias="callsMade")
    """Candidates contacted"""

    interested: int
    """Candidates who expressed interest"""

    successful: int
    """Candidates with successful outcome"""

    total: int
    """Total candidates in campaign"""

    unsuccessful: int
    """Candidates with unsuccessful outcome"""


class UnionMember1(BaseModel):
    """Campaign with aggregated candidate metrics."""

    id: int

    booking_url: str = FieldInfo(alias="bookingUrl")

    concurrency_limit: int = FieldInfo(alias="concurrencyLimit")

    created_at: datetime = FieldInfo(alias="createdAt")

    name: str

    start_date: date = FieldInfo(alias="startDate")

    status: Literal["NOT_STARTED", "IN_PROGRESS", "COMPLETED", "PAUSED"]
    """Campaign states"""

    total_candidates: int = FieldInfo(alias="totalCandidates")

    updated_at: datetime = FieldInfo(alias="updatedAt")

    action_type: Optional[Literal["PHONE_CALL", "SMS", "EMAIL", "BOOKING_PAGE"]] = FieldInfo(
        alias="actionType", default=None
    )

    context: Optional[str] = None

    end_date: Optional[date] = FieldInfo(alias="endDate", default=None)

    fallback_timezone: Optional[
        Literal[
            "US/Eastern",
            "US/Central",
            "US/Mountain",
            "US/Pacific",
            "US/Alaska",
            "US/Hawaii",
            "US/Arizona",
            "America/New_York",
            "America/Chicago",
            "America/Denver",
            "America/Los_Angeles",
            "America/Phoenix",
            "America/Anchorage",
            "America/Honolulu",
            "America/Toronto",
            "America/Mexico_City",
            "America/Sao_Paulo",
            "America/Buenos_Aires",
            "Europe/London",
            "Europe/Paris",
            "Europe/Berlin",
            "Europe/Madrid",
            "Europe/Rome",
            "Europe/Amsterdam",
            "Europe/Brussels",
            "Europe/Vienna",
            "Europe/Zurich",
            "Europe/Stockholm",
            "Europe/Moscow",
            "Europe/Istanbul",
            "Asia/Tokyo",
            "Asia/Shanghai",
            "Asia/Hong_Kong",
            "Asia/Singapore",
            "Asia/Seoul",
            "Asia/Kolkata",
            "Asia/Dubai",
            "Asia/Bangkok",
            "Asia/Jakarta",
            "Asia/Manila",
            "Australia/Sydney",
            "Australia/Melbourne",
            "Australia/Perth",
            "Pacific/Auckland",
            "UTC",
        ]
    ] = FieldInfo(alias="fallbackTimezone", default=None)
    """IANA timezone names (commonly used US and global timezones).

    These are standard timezone identifiers used for scheduling and time-based
    operations. For a complete list, see:
    https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
    """

    landing_page: Optional[UnionMember1LandingPage] = FieldInfo(alias="landingPage", default=None)
    """Lightweight summary for embedding in campaign responses."""

    landing_page_id: Optional[int] = FieldInfo(alias="landingPageId", default=None)

    max_phone_calls_per_candidate: Optional[int] = FieldInfo(alias="maxPhoneCallsPerCandidate", default=None)

    metrics: Optional[UnionMember1Metrics] = None
    """Aggregated outreach metrics for candidates in a campaign."""

    minimum_appointment_lead_time_hours: Optional[float] = FieldInfo(
        alias="minimumAppointmentLeadTimeHours", default=None
    )

    outreach_hours_end: Optional[int] = FieldInfo(alias="outreachHoursEnd", default=None)

    outreach_hours_start: Optional[int] = FieldInfo(alias="outreachHoursStart", default=None)

    principal_investigator: Optional[str] = FieldInfo(alias="principalInvestigator", default=None)

    reminder_delay_hours: Optional[float] = FieldInfo(alias="reminderDelayHours", default=None)

    reminder_enabled: Optional[bool] = FieldInfo(alias="reminderEnabled", default=None)

    workflow_id: Optional[int] = FieldInfo(alias="workflowId", default=None)

    workflow_name: Optional[str] = FieldInfo(alias="workflowName", default=None)


CampaignListResponse: TypeAlias = Union[List[UnionMember0], List[UnionMember1]]
