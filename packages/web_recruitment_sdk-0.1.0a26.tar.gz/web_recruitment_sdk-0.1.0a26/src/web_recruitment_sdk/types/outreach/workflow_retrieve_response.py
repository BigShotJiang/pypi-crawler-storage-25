# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["WorkflowRetrieveResponse"]


class WorkflowRetrieveResponse(BaseModel):
    id: int

    config: object

    name: str
