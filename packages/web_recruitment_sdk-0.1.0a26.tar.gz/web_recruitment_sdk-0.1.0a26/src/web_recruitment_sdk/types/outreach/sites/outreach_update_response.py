# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["OutreachUpdateResponse"]


class OutreachUpdateResponse(BaseModel):
    id: int

    outbound_phone_number: str = FieldInfo(alias="outboundPhoneNumber")

    site_id: int = FieldInfo(alias="siteId")

    office_hours: Optional[str] = FieldInfo(alias="officeHours", default=None)

    office_phone: Optional[str] = FieldInfo(alias="officePhone", default=None)
