# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["AccountUpdateResponse"]


class AccountUpdateResponse(BaseModel):
    id: int

    name: str

    tenant: str

    tenant_id: str = FieldInfo(alias="tenantId")
    """An external identifier for the tenant, e.g. the Authress tenant ID"""

    has_connect_product_enabled: Optional[bool] = FieldInfo(alias="hasConnectProductEnabled", default=None)

    has_match_product_enabled: Optional[bool] = FieldInfo(alias="hasMatchProductEnabled", default=None)

    outreach_active_campaign_limit: Optional[int] = FieldInfo(alias="outreachActiveCampaignLimit", default=None)
    """Maximum concurrent outreach campaigns allowed for this tenant"""
