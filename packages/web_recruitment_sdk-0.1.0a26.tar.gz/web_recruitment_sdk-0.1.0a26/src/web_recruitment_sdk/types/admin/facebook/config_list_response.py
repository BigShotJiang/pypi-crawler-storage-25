# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import TypeAlias

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["ConfigListResponse", "ConfigListResponseItem"]


class ConfigListResponseItem(BaseModel):
    """Model for reading a Facebook account config (excludes encrypted token)."""

    id: int

    account_id: int = FieldInfo(alias="accountId")

    created_at: datetime = FieldInfo(alias="createdAt")

    fb_page_id: str = FieldInfo(alias="fbPageId")

    is_active: bool = FieldInfo(alias="isActive")

    updated_at: datetime = FieldInfo(alias="updatedAt")

    authorized_by_user_id: Optional[int] = FieldInfo(alias="authorizedByUserId", default=None)


ConfigListResponse: TypeAlias = List[ConfigListResponseItem]
