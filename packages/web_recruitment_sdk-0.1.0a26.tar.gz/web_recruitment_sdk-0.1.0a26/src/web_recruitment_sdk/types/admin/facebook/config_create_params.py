# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, Annotated, TypedDict

from ...._utils import PropertyInfo

__all__ = ["ConfigCreateParams"]


class ConfigCreateParams(TypedDict, total=False):
    account_id: Required[Annotated[int, PropertyInfo(alias="accountId")]]

    fb_page_id: Required[Annotated[str, PropertyInfo(alias="fbPageId")]]

    authorized_by_user_id: Annotated[Optional[int], PropertyInfo(alias="authorizedByUserId")]

    is_active: Annotated[bool, PropertyInfo(alias="isActive")]
