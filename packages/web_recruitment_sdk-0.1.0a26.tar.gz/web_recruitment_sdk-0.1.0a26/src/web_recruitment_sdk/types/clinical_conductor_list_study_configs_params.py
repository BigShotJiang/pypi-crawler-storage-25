# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["ClinicalConductorListStudyConfigsParams"]


class ClinicalConductorListStudyConfigsParams(TypedDict, total=False):
    instance_id: Optional[int]
    """Optional instance ID to filter by"""
