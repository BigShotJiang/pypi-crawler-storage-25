# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel
from .patient_match import PatientMatch

__all__ = ["CustomSearchRetrieveMatchesResponse"]


class CustomSearchRetrieveMatchesResponse(BaseModel):
    """Paginated response for patient matches.

    - items: List of patient matches returned for this page
    - total: Total number of matches available
    - offset: Starting offset of this page
    - limit: Maximum number of items per page
    """

    items: List[PatientMatch]

    limit: int

    offset: int

    total: int
