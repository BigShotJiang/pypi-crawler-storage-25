# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel

__all__ = ["OutreachTriggerCallResponse"]


class OutreachTriggerCallResponse(BaseModel):
    """Response after triggering a phone call."""

    message: str

    success: bool

    attempt_id: Optional[int] = None
