# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["SystemGetConnectionPoolStatusResponse"]


class SystemGetConnectionPoolStatusResponse(BaseModel):
    """Response for connection pool status."""

    database: str

    pool_type: Literal["primary", "replica"] = FieldInfo(alias="poolType")

    status: str
