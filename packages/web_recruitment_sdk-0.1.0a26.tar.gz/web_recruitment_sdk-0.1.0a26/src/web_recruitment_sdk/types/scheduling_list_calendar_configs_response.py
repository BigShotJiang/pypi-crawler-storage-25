# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import TypeAlias

from .._models import BaseModel

__all__ = ["SchedulingListCalendarConfigsResponse", "SchedulingListCalendarConfigsResponseItem"]


class SchedulingListCalendarConfigsResponseItem(BaseModel):
    """Calendar config for the admin appointment-config editor.

    Exposes scheduling parameters the editor needs to display availability
    rules alongside each calendar.  Internal provider identifiers (grant
    IDs, external calendar IDs) are omitted.
    """

    id: int

    buffer_minutes: int

    duration_minutes: int

    interval_minutes: int

    is_active: bool

    name: str

    open_hours: List[object]

    timezone: str

    specific_availability: Optional[List[object]] = None


SchedulingListCalendarConfigsResponse: TypeAlias = List[SchedulingListCalendarConfigsResponseItem]
