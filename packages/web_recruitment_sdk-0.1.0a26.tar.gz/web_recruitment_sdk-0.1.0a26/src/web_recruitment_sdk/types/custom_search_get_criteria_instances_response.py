# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import date
from typing_extensions import TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .criteria_type import CriteriaType
from .criteria_instance_answer import CriteriaInstanceAnswer

__all__ = [
    "CustomSearchGetCriteriaInstancesResponse",
    "CustomSearchGetCriteriaInstancesResponseItem",
    "CustomSearchGetCriteriaInstancesResponseItemEvidence",
]


class CustomSearchGetCriteriaInstancesResponseItemEvidence(BaseModel):
    patient_entity_id: int = FieldInfo(alias="patientEntityId")

    document_metadata_id: Optional[str] = FieldInfo(alias="documentMetadataId", default=None)

    ehr_document_name: Optional[str] = FieldInfo(alias="ehrDocumentName", default=None)

    entity_name: Optional[str] = FieldInfo(alias="entityName", default=None)

    entity_type: Optional[str] = FieldInfo(alias="entityType", default=None)

    lab_result_unit: Optional[str] = FieldInfo(alias="labResultUnit", default=None)

    lab_result_value: Optional[str] = FieldInfo(alias="labResultValue", default=None)

    last_seen_on: Optional[date] = FieldInfo(alias="lastSeenOn", default=None)

    source_id: Optional[str] = FieldInfo(alias="sourceId", default=None)

    source_raw_entity: Optional[str] = FieldInfo(alias="sourceRawEntity", default=None)

    source_table: Optional[str] = FieldInfo(alias="sourceTable", default=None)


class CustomSearchGetCriteriaInstancesResponseItem(BaseModel):
    id: int

    answer: CriteriaInstanceAnswer

    criteria_id: int = FieldInfo(alias="criteriaId")

    criteria_summary: str = FieldInfo(alias="criteriaSummary")

    criteria_type: CriteriaType = FieldInfo(alias="criteriaType")

    trially_patient_id: str = FieldInfo(alias="triallyPatientId")

    evidence: Optional[List[CustomSearchGetCriteriaInstancesResponseItemEvidence]] = None

    explanation: Optional[str] = None

    match: Optional[bool] = None


CustomSearchGetCriteriaInstancesResponse: TypeAlias = List[CustomSearchGetCriteriaInstancesResponseItem]
