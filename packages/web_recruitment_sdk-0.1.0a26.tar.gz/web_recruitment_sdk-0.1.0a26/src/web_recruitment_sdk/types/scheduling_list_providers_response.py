# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import Literal, TypeAlias

from .._models import BaseModel

__all__ = ["SchedulingListProvidersResponse", "SchedulingListProvidersResponseItem"]


class SchedulingListProvidersResponseItem(BaseModel):
    """Provider metadata returned by the discovery endpoint for the admin UI."""

    configured: bool

    key: Literal["clinical_conductor", "trially"]
    """Identifies a scheduling provider integration.

    Referenced by the SchedulingProvider ABC, landing page appointment config,
    CandidateAppointment.source, and the provider discovery endpoint.
    """

    label: str


SchedulingListProvidersResponse: TypeAlias = List[SchedulingListProvidersResponseItem]
