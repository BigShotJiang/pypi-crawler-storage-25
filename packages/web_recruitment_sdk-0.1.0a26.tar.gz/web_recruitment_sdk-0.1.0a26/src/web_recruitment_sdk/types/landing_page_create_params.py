# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Union, Iterable, Optional
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "LandingPageCreateParams",
    "AppointmentConfig",
    "AppointmentConfigSchedulingProvider",
    "AppointmentConfigSchedulingProviderClinicalConductorProvider",
    "AppointmentConfigSchedulingProviderTriallyCalendarProvider",
    "AppointmentConfigSchedulingProviderTriallyCalendarProviderCalendar",
    "HeroConfig",
    "HeroConfigQuickFact",
    "IntakeFormConfig",
    "IntakeFormConfigFieldHelpers",
    "NotAMatchConfig",
    "ScreeningConfig",
    "ScreeningConfigQuestion",
    "ScreeningConfigQuestionOption",
    "ScreeningPassedConfig",
]


class LandingPageCreateParams(TypedDict, total=False):
    name: Required[str]

    slug: Required[str]

    study_name: Required[Annotated[str, PropertyInfo(alias="studyName")]]

    appointment_config: Annotated[Optional[AppointmentConfig], PropertyInfo(alias="appointmentConfig")]
    """Per-landing-page appointment configuration stored as JSONB.

    `appointment_type` drives UI content (labels, calendar events, emails).
    `scheduling_provider` determines which external system handles availability and
    booking (e.g. Clinical Conductor, Trially Scheduling).
    `duration_override_minutes` overrides the provider's visit duration for customer
    logistics; applied regardless of active provider.
    """

    contact_phone: Annotated[Optional[str], PropertyInfo(alias="contactPhone")]

    hero_config: Annotated[Optional[HeroConfig], PropertyInfo(alias="heroConfig")]

    intake_form_config: Annotated[Optional[IntakeFormConfig], PropertyInfo(alias="intakeFormConfig")]

    location: Optional[str]

    not_a_match_config: Annotated[Optional[NotAMatchConfig], PropertyInfo(alias="notAMatchConfig")]

    screening_config: Annotated[Optional[ScreeningConfig], PropertyInfo(alias="screeningConfig")]

    screening_passed_config: Annotated[Optional[ScreeningPassedConfig], PropertyInfo(alias="screeningPassedConfig")]

    timezone: Optional[str]


class AppointmentConfigSchedulingProviderClinicalConductorProvider(TypedDict, total=False):
    """Clinical Conductor CTMS scheduling provider."""

    study_config_id: Required[Annotated[int, PropertyInfo(alias="studyConfigId")]]

    type: Literal["clinical_conductor"]


class AppointmentConfigSchedulingProviderTriallyCalendarProviderCalendar(TypedDict, total=False):
    """A bookable calendar within a Trially-powered landing page.

    Each entry maps to a NylasCalendarConfig and carries its own
    candidate-facing display data and CRC notification list.
    Multi-site LPs have one entry per physical location.
    """

    calendar_config_id: Required[Annotated[int, PropertyInfo(alias="calendarConfigId")]]

    contact_phone: Annotated[Optional[str], PropertyInfo(alias="contactPhone")]

    label: Optional[str]

    location: Optional[str]

    notification_emails: Annotated[SequenceNotStr[str], PropertyInfo(alias="notificationEmails")]


class AppointmentConfigSchedulingProviderTriallyCalendarProvider(TypedDict, total=False):
    """Trially managed calendar scheduling provider.

    ``calendars`` holds one or more BookingCalendar entries.
    Single-site LPs use one entry (label/location optional — LP-level
    fields provide fallback).  Multi-site LPs use N entries, each
    with its own display data and notification routing.

    **Duration invariant:** all calendars on a landing page must share
    the same ``NylasCalendarConfig.duration_minutes``.  The booking
    flow resolves a single display duration per LP via
    ``AppointmentConfig.duration_override_minutes`` (platform-level)
    or the provider's duration (fetched from the first calendar).
    Heterogeneous durations would break both the override semantics
    and the candidate-facing display.
    """

    calendars: Required[Iterable[AppointmentConfigSchedulingProviderTriallyCalendarProviderCalendar]]

    type: Literal["trially"]


AppointmentConfigSchedulingProvider: TypeAlias = Union[
    AppointmentConfigSchedulingProviderClinicalConductorProvider,
    AppointmentConfigSchedulingProviderTriallyCalendarProvider,
]


class AppointmentConfig(TypedDict, total=False):
    """Per-landing-page appointment configuration stored as JSONB.

    `appointment_type` drives UI content (labels, calendar events, emails).
    `scheduling_provider` determines which external system handles
    availability and booking (e.g. Clinical Conductor, Trially Scheduling).
    `duration_override_minutes` overrides the provider's visit duration
    for customer logistics; applied regardless of active provider.
    """

    appointment_type: Required[Annotated[Literal["in_person", "phone_call"], PropertyInfo(alias="appointmentType")]]

    scheduling_provider: Required[
        Annotated[AppointmentConfigSchedulingProvider, PropertyInfo(alias="schedulingProvider")]
    ]
    """Clinical Conductor CTMS scheduling provider."""

    duration_override_minutes: Annotated[Optional[int], PropertyInfo(alias="durationOverrideMinutes")]
    """Override the scheduling provider's visit duration.

    Applied platform-wide regardless of which provider is active.
    """


class HeroConfigQuickFact(TypedDict, total=False):
    label: Required[str]

    value: Required[str]

    icon: Optional[str]


class HeroConfig(TypedDict, total=False):
    cta_text: Required[Annotated[str, PropertyInfo(alias="ctaText")]]

    headline: Required[str]

    quick_facts: Annotated[Iterable[HeroConfigQuickFact], PropertyInfo(alias="quickFacts")]

    subheadline: Optional[str]


class IntakeFormConfigFieldHelpers(TypedDict, total=False):
    bmi: Optional[str]

    dob: Optional[str]

    family_name: Optional[str]

    given_name: Optional[str]


class IntakeFormConfig(TypedDict, total=False):
    description: Required[str]

    fields: Required[List[Literal["given_name", "family_name", "dob", "bmi"]]]

    title: Required[str]

    field_helpers: Annotated[Optional[IntakeFormConfigFieldHelpers], PropertyInfo(alias="fieldHelpers")]

    maximum_age: Annotated[Optional[int], PropertyInfo(alias="maximumAge")]

    maximum_bmi: Annotated[Optional[float], PropertyInfo(alias="maximumBmi")]

    minimum_age: Annotated[Optional[int], PropertyInfo(alias="minimumAge")]

    minimum_bmi: Annotated[Optional[float], PropertyInfo(alias="minimumBmi")]


class NotAMatchConfig(TypedDict, total=False):
    message: Required[str]

    title: Required[str]

    show_contact: Annotated[bool, PropertyInfo(alias="showContact")]


class ScreeningConfigQuestionOption(TypedDict, total=False):
    id: Required[str]

    text: Required[str]

    is_disqualifying: Annotated[bool, PropertyInfo(alias="isDisqualifying")]


class ScreeningConfigQuestion(TypedDict, total=False):
    id: Required[str]

    options: Required[Iterable[ScreeningConfigQuestionOption]]

    prompt: Required[str]

    helper: Optional[str]


class ScreeningConfig(TypedDict, total=False):
    description: Required[str]

    questions: Required[Iterable[ScreeningConfigQuestion]]

    title: Required[str]


class ScreeningPassedConfig(TypedDict, total=False):
    message: Required[str]

    title: Required[str]
