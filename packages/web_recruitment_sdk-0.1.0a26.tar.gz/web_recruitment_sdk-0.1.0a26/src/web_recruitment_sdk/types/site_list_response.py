# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .site_read import SiteRead

__all__ = ["SiteListResponse", "UnionMember0", "UnionMember0Outreach"]


class UnionMember0Outreach(BaseModel):
    """Outreach information for a site (optional, may not exist for all sites)."""

    office_hours: Optional[str] = FieldInfo(alias="officeHours", default=None)

    office_phone: Optional[str] = FieldInfo(alias="officePhone", default=None)

    outbound_phone_number: Optional[str] = FieldInfo(alias="outboundPhoneNumber", default=None)


class UnionMember0(BaseModel):
    """Site with optional outreach information included."""

    id: int

    name: str

    city: Optional[str] = None

    latitude: Optional[float] = None

    longitude: Optional[float] = None

    outreach: Optional[UnionMember0Outreach] = None
    """Outreach information for a site (optional, may not exist for all sites)."""

    state: Optional[str] = None

    street_address: Optional[str] = FieldInfo(alias="streetAddress", default=None)

    trially_site_id: Optional[str] = FieldInfo(alias="triallySiteId", default=None)

    zip_code: Optional[str] = FieldInfo(alias="zipCode", default=None)


SiteListResponse: TypeAlias = Union[List[UnionMember0], List[SiteRead]]
