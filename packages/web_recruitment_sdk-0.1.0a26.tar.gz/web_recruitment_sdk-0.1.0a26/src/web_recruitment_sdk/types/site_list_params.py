# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["SiteListParams"]


class SiteListParams(TypedDict, total=False):
    include_outreach: bool
    """Include outreach information for each site"""
