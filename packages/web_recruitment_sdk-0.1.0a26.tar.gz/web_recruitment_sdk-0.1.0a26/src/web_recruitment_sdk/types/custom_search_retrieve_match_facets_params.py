# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["CustomSearchRetrieveMatchFacetsParams"]


class CustomSearchRetrieveMatchFacetsParams(TypedDict, total=False):
    field: Required[Literal["state", "zip_code", "last_encounter_provider", "primary_provider"]]

    dob_from: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]

    dob_to: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]

    last_encounter_date_from: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]

    last_encounter_date_to: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]

    last_encounter_provider: Optional[SequenceNotStr[str]]

    limit: int

    matching_criteria_ids: Optional[Iterable[int]]

    primary_provider: Optional[SequenceNotStr[str]]

    query: Optional[str]

    search: Optional[str]

    site_ids: Optional[Iterable[int]]

    state: Optional[SequenceNotStr[str]]

    workflow_tag: Optional[Literal["unreviewed", "disqualified", "enrolled", "follow_up", "reviewed"]]

    zip_code: Optional[SequenceNotStr[str]]
