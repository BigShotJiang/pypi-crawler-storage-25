# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import datetime
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["OutreachTriggerCallParams", "CallData", "CallDataSite", "CallDataStudy", "CallDataToPerson"]


class OutreachTriggerCallParams(TypedDict, total=False):
    call_data: Required[CallData]
    """Class to store call data from client requests (without tenant_db_name)."""

    conversation_flow: Literal[
        "lead_warmer", "lead_warmer_with_clinical_screening", "interested_lead_with_screening_link"
    ]
    """Represents the flow of a conversation."""


class CallDataSite(TypedDict, total=False):
    """Information about a clinical research site."""

    name: Required[str]

    provider_name: Required[str]

    instructions: Optional[str]

    office_hours: Optional[str]

    office_phone: Optional[str]


class CallDataStudy(TypedDict, total=False):
    """Contains information about a clinical study."""

    name: Required[str]

    summary: Optional[str]


class CallDataToPerson(TypedDict, total=False):
    """Represents a person with contact information and preferences."""

    first_name: Required[str]

    last_name: Required[str]

    phone_number: Required[str]

    email: Optional[str]

    person_id: Optional[int]


class CallData(TypedDict, total=False):
    """Class to store call data from client requests (without tenant_db_name)."""

    from_phone_number: Required[str]

    site: Required[CallDataSite]
    """Information about a clinical research site."""

    study: Required[CallDataStudy]
    """Contains information about a clinical study."""

    to_person: Required[CallDataToPerson]
    """Represents a person with contact information and preferences."""

    appointment_type: Optional[Literal["in_person", "phone_call"]]
    """
    Passed from the landing page's appointment config to agents so they can tailor
    conversation language (e.g. 'visit' vs 'call').
    """

    booking_url: Optional[str]

    call_initiated_date: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]

    context: Optional[str]
