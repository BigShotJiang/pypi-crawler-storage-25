# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import date, datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .site_read import SiteRead

__all__ = ["PatientMatch", "NextAppointment", "WorkflowTag"]


class NextAppointment(BaseModel):
    date: str


class WorkflowTag(BaseModel):
    set_by_user_id: int = FieldInfo(alias="setByUserId")

    updated_at: datetime = FieldInfo(alias="updatedAt")

    value: Literal["disqualified", "enrolled", "follow_up", "reviewed"]

    set_by_user_email: Optional[str] = FieldInfo(alias="setByUserEmail", default=None)


class PatientMatch(BaseModel):
    id: int

    dob: Optional[date] = None

    email: Optional[str] = None

    family_name: str = FieldInfo(alias="familyName")

    given_name: str = FieldInfo(alias="givenName")

    match_last_updated: Optional[str] = FieldInfo(alias="matchLastUpdated", default=None)

    match_percentage: float = FieldInfo(alias="matchPercentage")

    next_appointment: Optional[NextAppointment] = FieldInfo(alias="nextAppointment", default=None)

    site_id: int = FieldInfo(alias="siteId")

    trially_patient_id: str = FieldInfo(alias="triallyPatientId")

    cell_phone: Optional[str] = FieldInfo(alias="cellPhone", default=None)

    city: Optional[str] = None

    do_not_call: Optional[bool] = FieldInfo(alias="doNotCall", default=None)

    home_phone: Optional[str] = FieldInfo(alias="homePhone", default=None)

    is_interested_in_research: Optional[bool] = FieldInfo(alias="isInterestedInResearch", default=None)

    last_encounter_date: Optional[date] = FieldInfo(alias="lastEncounterDate", default=None)

    last_patient_activity: Optional[date] = FieldInfo(alias="lastPatientActivity", default=None)

    locations: Optional[str] = None

    middle_name: Optional[str] = FieldInfo(alias="middleName", default=None)

    patient_medical_record_numbers: Optional[List[str]] = FieldInfo(alias="patientMedicalRecordNumbers", default=None)

    phone: Optional[str] = None

    preferred_language: Optional[Literal["ENGLISH", "SPANISH"]] = FieldInfo(alias="preferredLanguage", default=None)

    primary_provider: Optional[str] = FieldInfo(alias="primaryProvider", default=None)

    primary_provider_department: Optional[str] = FieldInfo(alias="primaryProviderDepartment", default=None)

    primary_provider_group: Optional[str] = FieldInfo(alias="primaryProviderGroup", default=None)

    primary_provider_id: Optional[str] = FieldInfo(alias="primaryProviderId", default=None)

    provider_first_name: Optional[str] = FieldInfo(alias="providerFirstName", default=None)

    provider_last_name: Optional[str] = FieldInfo(alias="providerLastName", default=None)

    site: Optional[SiteRead] = None

    source: Optional[Literal["EHR", "CSV"]] = None

    state: Optional[
        Literal[
            "AL",
            "AK",
            "AS",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "DC",
            "FL",
            "FM",
            "GA",
            "GU",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MH",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "MP",
            "OH",
            "OK",
            "OR",
            "PW",
            "PA",
            "PR",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "TT",
            "UT",
            "VT",
            "VA",
            "VI",
            "WA",
            "WV",
            "WI",
            "WY",
        ]
    ] = None
    """US state codes and territories."""

    street_address: Optional[str] = FieldInfo(alias="streetAddress", default=None)

    workflow_tag: Optional[WorkflowTag] = FieldInfo(alias="workflowTag", default=None)

    zip_code: Optional[str] = FieldInfo(alias="zipCode", default=None)
