# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import date
from typing_extensions import TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "SystemGetPatientMatchDataResponse",
    "SystemGetPatientMatchDataResponseItem",
    "SystemGetPatientMatchDataResponseItemPatientLabResult",
    "SystemGetPatientMatchDataResponseItemPatientVital",
]


class SystemGetPatientMatchDataResponseItemPatientLabResult(BaseModel):
    name: str

    observed_date: Optional[date] = FieldInfo(alias="observedDate", default=None)

    unit: Optional[str] = None

    value: Optional[str] = None


class SystemGetPatientMatchDataResponseItemPatientVital(BaseModel):
    unit: str

    value: float

    vital_kind: str = FieldInfo(alias="vitalKind")

    observed_at: Optional[date] = FieldInfo(alias="observedAt", default=None)


class SystemGetPatientMatchDataResponseItem(BaseModel):
    trially_patient_id: str = FieldInfo(alias="triallyPatientId")

    last_encounter_date: Optional[date] = FieldInfo(alias="lastEncounterDate", default=None)

    patient_age: Optional[int] = FieldInfo(alias="patientAge", default=None)

    patient_ethnicity: Optional[str] = FieldInfo(alias="patientEthnicity", default=None)

    patient_gender: Optional[str] = FieldInfo(alias="patientGender", default=None)

    patient_history: Optional[List[object]] = FieldInfo(alias="patientHistory", default=None)

    patient_lab_results: Optional[List[SystemGetPatientMatchDataResponseItemPatientLabResult]] = FieldInfo(
        alias="patientLabResults", default=None
    )

    patient_race: Optional[str] = FieldInfo(alias="patientRace", default=None)

    patient_vitals: Optional[List[SystemGetPatientMatchDataResponseItemPatientVital]] = FieldInfo(
        alias="patientVitals", default=None
    )


SystemGetPatientMatchDataResponse: TypeAlias = List[SystemGetPatientMatchDataResponseItem]
