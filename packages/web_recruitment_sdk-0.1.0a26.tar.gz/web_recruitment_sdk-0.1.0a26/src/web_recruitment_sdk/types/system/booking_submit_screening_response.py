# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["BookingSubmitScreeningResponse"]


class BookingSubmitScreeningResponse(BaseModel):
    """Response for POST /system/{tenant_db_name}/booking/screening endpoint."""

    screening_passed: bool = FieldInfo(alias="screeningPassed")

    tenant_calendar_url: Optional[str] = FieldInfo(alias="tenantCalendarUrl", default=None)
