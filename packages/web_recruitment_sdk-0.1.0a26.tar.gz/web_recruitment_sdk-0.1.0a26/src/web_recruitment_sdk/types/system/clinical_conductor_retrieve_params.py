# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ClinicalConductorRetrieveParams"]


class ClinicalConductorRetrieveParams(TypedDict, total=False):
    tenant_db_name: Required[str]

    study_config_id: Required[int]
    """Study config ID for CC instance"""
