# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["AppointmentGetAppointmentParams"]


class AppointmentGetAppointmentParams(TypedDict, total=False):
    calendar_config_id: Optional[int]
    """Scope availability to a specific booking calendar (site).

    Omit to include all configured calendars.
    """
