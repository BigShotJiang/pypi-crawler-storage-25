# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import datetime
from typing import Union, Optional
from typing_extensions import Required, Annotated, TypedDict

from ...._utils import PropertyInfo

__all__ = ["AvailabilityGetTimeSlotsParams"]


class AvailabilityGetTimeSlotsParams(TypedDict, total=False):
    date: Required[Annotated[Union[str, datetime.date], PropertyInfo(format="iso8601")]]
    """Date to get slots for"""

    calendar_config_id: Optional[int]
    """Scope availability to a specific booking calendar (site).

    Omit to include all configured calendars.
    """
