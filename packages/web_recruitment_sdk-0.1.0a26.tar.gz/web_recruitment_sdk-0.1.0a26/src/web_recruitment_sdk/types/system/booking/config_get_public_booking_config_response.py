# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = [
    "ConfigGetPublicBookingConfigResponse",
    "AppointmentConfig",
    "AppointmentConfigSchedulingProvider",
    "AppointmentConfigSite",
    "HeroConfig",
    "HeroConfigQuickFact",
    "IntakeFormConfig",
    "IntakeFormConfigFieldHelpers",
    "NotAMatchConfig",
    "ScreeningConfig",
    "ScreeningConfigQuestion",
    "ScreeningConfigQuestionOption",
    "ScreeningPassedConfig",
]


class AppointmentConfigSchedulingProvider(BaseModel):
    """Public-safe scheduling provider info — excludes internal IDs."""

    type: Literal["clinical_conductor", "trially"]
    """Identifies a scheduling provider integration.

    Referenced by the SchedulingProvider ABC, landing page appointment config,
    CandidateAppointment.source, and the provider discovery endpoint.
    """


class AppointmentConfigSite(BaseModel):
    """Candidate-facing site info for the booking page site selector.

    Derived from BookingCalendar entries.  Nylas grant/calendar strings
    are not exposed; ``calendar_config_id`` is an opaque integer the
    client uses only to filter slots by selected site.
    """

    calendar_config_id: int = FieldInfo(alias="calendarConfigId")

    contact_phone: Optional[str] = FieldInfo(alias="contactPhone", default=None)

    label: Optional[str] = None

    location: Optional[str] = None


class AppointmentConfig(BaseModel):
    """Public-safe appointment config — no provider internals."""

    appointment_type: Literal["in_person", "phone_call"] = FieldInfo(alias="appointmentType")

    scheduling_provider: AppointmentConfigSchedulingProvider = FieldInfo(alias="schedulingProvider")
    """Public-safe scheduling provider info — excludes internal IDs."""

    duration_override_minutes: Optional[int] = FieldInfo(alias="durationOverrideMinutes", default=None)

    sites: Optional[List[AppointmentConfigSite]] = None


class HeroConfigQuickFact(BaseModel):
    label: str

    value: str

    icon: Optional[str] = None


class HeroConfig(BaseModel):
    cta_text: str = FieldInfo(alias="ctaText")

    headline: str

    quick_facts: Optional[List[HeroConfigQuickFact]] = FieldInfo(alias="quickFacts", default=None)

    subheadline: Optional[str] = None


class IntakeFormConfigFieldHelpers(BaseModel):
    bmi: Optional[str] = None

    dob: Optional[str] = None

    family_name: Optional[str] = None

    given_name: Optional[str] = None


class IntakeFormConfig(BaseModel):
    description: str

    fields: List[Literal["given_name", "family_name", "dob", "bmi"]]

    title: str

    field_helpers: Optional[IntakeFormConfigFieldHelpers] = FieldInfo(alias="fieldHelpers", default=None)

    maximum_age: Optional[int] = FieldInfo(alias="maximumAge", default=None)

    maximum_bmi: Optional[float] = FieldInfo(alias="maximumBmi", default=None)

    minimum_age: Optional[int] = FieldInfo(alias="minimumAge", default=None)

    minimum_bmi: Optional[float] = FieldInfo(alias="minimumBmi", default=None)


class NotAMatchConfig(BaseModel):
    message: str

    title: str

    show_contact: Optional[bool] = FieldInfo(alias="showContact", default=None)


class ScreeningConfigQuestionOption(BaseModel):
    id: str

    text: str

    is_disqualifying: Optional[bool] = FieldInfo(alias="isDisqualifying", default=None)


class ScreeningConfigQuestion(BaseModel):
    id: str

    options: List[ScreeningConfigQuestionOption]

    prompt: str

    helper: Optional[str] = None


class ScreeningConfig(BaseModel):
    description: str

    questions: List[ScreeningConfigQuestion]

    title: str


class ScreeningPassedConfig(BaseModel):
    message: str

    title: str


class ConfigGetPublicBookingConfigResponse(BaseModel):
    """Public-safe landing page config for the booking UI.

    Excludes internal/sensitive fields: id, name, email_config,
    notification_emails, and provider-internal IDs (e.g. study_config_id,
    Nylas grant/calendar strings).  Trially sites expose only opaque
    ``calendar_config_id`` integers for slot filtering.
    """

    slug: str

    study_name: str = FieldInfo(alias="studyName")

    appointment_config: Optional[AppointmentConfig] = FieldInfo(alias="appointmentConfig", default=None)
    """Public-safe appointment config — no provider internals."""

    contact_phone: Optional[str] = FieldInfo(alias="contactPhone", default=None)

    hero_config: Optional[HeroConfig] = FieldInfo(alias="heroConfig", default=None)

    intake_form_config: Optional[IntakeFormConfig] = FieldInfo(alias="intakeFormConfig", default=None)

    location: Optional[str] = None

    not_a_match_config: Optional[NotAMatchConfig] = FieldInfo(alias="notAMatchConfig", default=None)

    screening_config: Optional[ScreeningConfig] = FieldInfo(alias="screeningConfig", default=None)

    screening_passed_config: Optional[ScreeningPassedConfig] = FieldInfo(alias="screeningPassedConfig", default=None)

    timezone: Optional[str] = None
