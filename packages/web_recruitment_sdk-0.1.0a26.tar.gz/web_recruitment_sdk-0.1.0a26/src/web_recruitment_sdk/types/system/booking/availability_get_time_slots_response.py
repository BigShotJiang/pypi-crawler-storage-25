# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import datetime
from typing import List

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["AvailabilityGetTimeSlotsResponse", "Slot"]


class Slot(BaseModel):
    """A single available time slot."""

    id: str

    duration_minutes: int = FieldInfo(alias="durationMinutes")

    end_time: datetime.datetime = FieldInfo(alias="endTime")

    start_time: datetime.datetime = FieldInfo(alias="startTime")


class AvailabilityGetTimeSlotsResponse(BaseModel):
    """Response for GET /booking/availability/slots endpoint."""

    date: datetime.date

    slots: List[Slot]

    timezone: str
