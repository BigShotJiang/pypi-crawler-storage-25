# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import date

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["AvailabilityGetAvailableDatesResponse"]


class AvailabilityGetAvailableDatesResponse(BaseModel):
    """Response for GET /booking/availability/dates endpoint."""

    available_dates: List[date] = FieldInfo(alias="availableDates")

    timezone: str
