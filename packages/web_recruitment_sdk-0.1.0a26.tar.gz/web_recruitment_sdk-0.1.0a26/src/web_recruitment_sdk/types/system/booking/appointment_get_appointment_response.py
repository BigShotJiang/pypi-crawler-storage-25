# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["AppointmentGetAppointmentResponse", "CalendarLinks"]


class CalendarLinks(BaseModel):
    """Calendar links for adding appointment to external calendars"""

    google_url: str = FieldInfo(alias="googleUrl")

    outlook_url: str = FieldInfo(alias="outlookUrl")


class AppointmentGetAppointmentResponse(BaseModel):
    """Summary of an existing appointment for display."""

    id: int

    duration_minutes: int = FieldInfo(alias="durationMinutes")

    scheduled_datetime: datetime = FieldInfo(alias="scheduledDatetime")

    status: Literal["booked", "cancelled"]

    calendar_links: Optional[CalendarLinks] = FieldInfo(alias="calendarLinks", default=None)
    """Calendar links for adding appointment to external calendars"""

    contact_phone: Optional[str] = FieldInfo(alias="contactPhone", default=None)

    location: Optional[str] = None
