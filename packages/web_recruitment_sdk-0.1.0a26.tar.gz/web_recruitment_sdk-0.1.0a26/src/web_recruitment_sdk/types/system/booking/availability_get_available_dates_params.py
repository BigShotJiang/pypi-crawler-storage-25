# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date
from typing_extensions import Required, Annotated, TypedDict

from ...._utils import PropertyInfo

__all__ = ["AvailabilityGetAvailableDatesParams"]


class AvailabilityGetAvailableDatesParams(TypedDict, total=False):
    end_date: Required[Annotated[Union[str, date], PropertyInfo(format="iso8601")]]
    """End of date range (max 60 days)"""

    start_date: Required[Annotated[Union[str, date], PropertyInfo(format="iso8601")]]
    """Start of date range"""

    calendar_config_id: Optional[int]
    """Scope availability to a specific booking calendar (site).

    Omit to include all configured calendars.
    """
