# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from ...._utils import PropertyInfo

__all__ = ["AppointmentBookAppointmentParams"]


class AppointmentBookAppointmentParams(TypedDict, total=False):
    selected_time: Required[Annotated[Union[str, datetime], PropertyInfo(alias="selectedTime", format="iso8601")]]

    slot_id: Required[Annotated[str, PropertyInfo(alias="slotId")]]

    calendar_config_id: Optional[int]
    """Scope availability to a specific booking calendar (site).

    Omit to include all configured calendars.
    """
