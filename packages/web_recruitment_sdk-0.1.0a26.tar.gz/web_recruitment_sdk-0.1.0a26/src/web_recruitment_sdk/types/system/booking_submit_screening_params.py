# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["BookingSubmitScreeningParams"]


class BookingSubmitScreeningParams(TypedDict, total=False):
    answers: Required[Dict[str, str]]

    screening_passed: Required[Annotated[bool, PropertyInfo(alias="screeningPassed")]]

    calendar_config_id: Optional[int]
    """Scope availability to a specific booking calendar (site).

    Omit to include all configured calendars.
    """

    candidate_email: Annotated[Optional[str], PropertyInfo(alias="candidateEmail")]

    candidate_name: Annotated[Optional[str], PropertyInfo(alias="candidateName")]

    candidate_phone: Annotated[Optional[str], PropertyInfo(alias="candidatePhone")]
