# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["FacebookProcessLeadParams"]


class FacebookProcessLeadParams(TypedDict, total=False):
    webhook_data: Required[Annotated[object, PropertyInfo(alias="webhookData")]]

    webhook_type: Required[
        Annotated[
            Literal["booking_link_clicked", "facebook_lead_received", "twilio_inbound_sms"],
            PropertyInfo(alias="webhookType"),
        ]
    ]
    """Types of webhooks."""
