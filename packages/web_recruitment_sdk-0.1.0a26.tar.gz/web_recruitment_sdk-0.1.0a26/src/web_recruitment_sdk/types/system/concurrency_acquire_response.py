# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["ConcurrencyAcquireResponse"]


class ConcurrencyAcquireResponse(BaseModel):
    """Response model for acquiring a concurrency slot."""

    current_count: int
    """Current number of concurrent operations"""

    limit: int
    """Maximum concurrency limit"""

    success: bool
    """Whether the slot was acquired"""

    tenant_db_name: str
    """The tenant database name"""

    campaign_id: Optional[int] = None
    """Optional campaign ID for scoped concurrency"""
