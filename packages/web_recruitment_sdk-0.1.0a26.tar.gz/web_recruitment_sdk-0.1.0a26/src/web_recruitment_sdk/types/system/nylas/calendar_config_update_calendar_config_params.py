# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import Required, TypedDict

__all__ = ["CalendarConfigUpdateCalendarConfigParams", "SpecificAvailability"]


class CalendarConfigUpdateCalendarConfigParams(TypedDict, total=False):
    tenant_db_name: Required[str]

    buffer_minutes: Optional[int]

    duration_minutes: Optional[int]

    interval_minutes: Optional[int]

    is_active: Optional[bool]

    name: Optional[str]

    open_hours: Optional[Iterable[object]]

    specific_availability: Optional[Iterable[SpecificAvailability]]

    timezone: Optional[str]


class SpecificAvailability(TypedDict, total=False):
    """A date-specific availability window (Trially concept, not Nylas).

    Times are in the **calendar config timezone**
    (``NylasCalendarConfig.timezone``), NOT the landing page display
    timezone.  When these differ the candidate sees slots shifted by
    the UTC offset between the two — this is by design.  The CRC's
    calendar event is always booked in the config timezone.
    """

    date: Required[str]
    """Calendar date in YYYY-MM-DD format"""

    end: Required[str]
    """End time in HH:MM format"""

    start: Required[str]
    """Start time in HH:MM format"""
