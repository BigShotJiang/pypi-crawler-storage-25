# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import Required, TypedDict

__all__ = ["CalendarConfigCreateCalendarConfigParams", "SpecificAvailability"]


class CalendarConfigCreateCalendarConfigParams(TypedDict, total=False):
    duration_minutes: Required[int]
    """Slot duration in minutes"""

    grant_id: Required[int]
    """Internal ID of the NylasGrant to use"""

    interval_minutes: Required[int]
    """Gap between slot start times in minutes"""

    name: Required[str]
    """Display name for the calendar"""

    timezone: Required[str]
    """IANA timezone (e.g. America/New_York)"""

    buffer_minutes: int
    """Buffer around meetings in minutes"""

    open_hours: Iterable[object]
    """Weekly open_hours rules [{days, start, end, timezone, exdates}]"""

    specific_availability: Optional[Iterable[SpecificAvailability]]
    """Date-specific availability windows. When set, overrides open_hours."""


class SpecificAvailability(TypedDict, total=False):
    """A date-specific availability window (Trially concept, not Nylas).

    Times are in the **calendar config timezone**
    (``NylasCalendarConfig.timezone``), NOT the landing page display
    timezone.  When these differ the candidate sees slots shifted by
    the UTC offset between the two — this is by design.  The CRC's
    calendar event is always booked in the config timezone.
    """

    date: Required[str]
    """Calendar date in YYYY-MM-DD format"""

    end: Required[str]
    """End time in HH:MM format"""

    start: Required[str]
    """Start time in HH:MM format"""
