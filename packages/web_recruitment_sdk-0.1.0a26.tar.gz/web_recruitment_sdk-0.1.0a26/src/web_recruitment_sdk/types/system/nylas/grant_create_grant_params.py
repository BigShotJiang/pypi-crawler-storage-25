# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["GrantCreateGrantParams"]


class GrantCreateGrantParams(TypedDict, total=False):
    email: Required[str]
    """Synthetic email for the virtual grant (e.g. ppcp@trially.scheduling)"""

    name: Optional[str]
    """Optional display name for the grant"""
