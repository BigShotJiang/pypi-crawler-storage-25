# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ...._models import BaseModel

__all__ = ["CalendarConfigCreateCalendarConfigResponse"]


class CalendarConfigCreateCalendarConfigResponse(BaseModel):
    """Response body for a Nylas calendar config."""

    id: int

    buffer_minutes: int

    created_at: datetime

    duration_minutes: int

    grant_id: int

    interval_minutes: int

    is_active: bool

    name: str

    nylas_calendar_id: str

    open_hours: List[object]

    timezone: str

    updated_at: datetime

    specific_availability: Optional[List[object]] = None
