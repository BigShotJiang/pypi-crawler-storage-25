# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["FacebookProcessLeadResponse"]


class FacebookProcessLeadResponse(BaseModel):
    """Response model for lead intake API."""

    candidate_campaign_id: int = FieldInfo(alias="candidateCampaignId")

    candidate_id: int = FieldInfo(alias="candidateId")

    person_id: int = FieldInfo(alias="personId")

    message: Optional[str] = None
