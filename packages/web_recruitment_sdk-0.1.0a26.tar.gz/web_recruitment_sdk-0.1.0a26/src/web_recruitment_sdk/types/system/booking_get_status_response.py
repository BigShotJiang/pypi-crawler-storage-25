# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["BookingGetStatusResponse"]


class BookingGetStatusResponse(BaseModel):
    """Response for GET /system/{tenant_db_name}/booking/status endpoint."""

    status: Literal["new", "intake_passed", "intake_failed", "screening_passed", "screening_failed", "booked"]

    tenant_calendar_url: Optional[str] = FieldInfo(alias="tenantCalendarUrl", default=None)
