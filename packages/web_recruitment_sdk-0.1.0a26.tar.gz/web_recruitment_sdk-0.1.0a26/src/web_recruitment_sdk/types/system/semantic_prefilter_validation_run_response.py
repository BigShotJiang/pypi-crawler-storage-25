# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["SemanticPrefilterValidationRunResponse"]


class SemanticPrefilterValidationRunResponse(BaseModel):
    fanout_key: str = FieldInfo(alias="fanoutKey")

    skipped_count: int = FieldInfo(alias="skippedCount")

    status: str

    submitted_count: int = FieldInfo(alias="submittedCount")

    tenant_count: int = FieldInfo(alias="tenantCount")
