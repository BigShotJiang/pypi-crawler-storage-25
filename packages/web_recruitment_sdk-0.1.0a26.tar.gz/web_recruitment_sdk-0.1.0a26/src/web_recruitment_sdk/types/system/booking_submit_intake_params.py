# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["BookingSubmitIntakeParams", "Bmi"]


class BookingSubmitIntakeParams(TypedDict, total=False):
    calendar_config_id: Optional[int]
    """Scope availability to a specific booking calendar (site).

    Omit to include all configured calendars.
    """

    bmi: Optional[Bmi]
    """Height/weight data submitted for BMI intake field."""

    dob: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]

    family_name: Annotated[Optional[str], PropertyInfo(alias="familyName")]

    given_name: Annotated[Optional[str], PropertyInfo(alias="givenName")]


class Bmi(TypedDict, total=False):
    """Height/weight data submitted for BMI intake field."""

    height_ft: Required[Annotated[int, PropertyInfo(alias="heightFt")]]

    height_in: Required[Annotated[int, PropertyInfo(alias="heightIn")]]

    weight_lbs: Required[Annotated[float, PropertyInfo(alias="weightLbs")]]
