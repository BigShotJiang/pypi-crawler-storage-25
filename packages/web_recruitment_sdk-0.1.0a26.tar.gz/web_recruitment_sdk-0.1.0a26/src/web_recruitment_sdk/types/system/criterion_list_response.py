# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from ..criteria_type import CriteriaType
from ..custom_searches.criteria_status import CriteriaStatus

__all__ = [
    "CriterionListResponse",
    "CriterionListResponseItem",
    "CriterionListResponseItemHydrationError",
    "CriterionListResponseItemMatchingPayload",
    "CriterionListResponseItemMatchingPayloadRoutingMetadata",
    "CriterionListResponseItemMatchingPayloadRoutingMetadataHandlerPayload",
    "CriterionListResponseItemMatchingPayloadSignalEntity",
]


class CriterionListResponseItemHydrationError(BaseModel):
    error_message: str = FieldInfo(alias="errorMessage")

    retryable: bool

    error_code: Optional[str] = FieldInfo(alias="errorCode", default=None)

    failed_stage: Optional[str] = FieldInfo(alias="failedStage", default=None)


class CriterionListResponseItemMatchingPayloadRoutingMetadataHandlerPayload(BaseModel):
    payload: object

    payload_model: str = FieldInfo(alias="payloadModel")
    """The string representation of the pydantic model of the payload."""


class CriterionListResponseItemMatchingPayloadRoutingMetadata(BaseModel):
    agent_signature: Literal["SEMANTIC_RETRIEVAL", "QUANTITATIVE_LOGIC", "ADVANCED_LOGIC", "PROCEDURAL_INTENT"] = (
        FieldInfo(alias="agentSignature")
    )

    handler_payload: Optional[CriterionListResponseItemMatchingPayloadRoutingMetadataHandlerPayload] = FieldInfo(
        alias="handlerPayload", default=None
    )

    handler_signature: Optional[
        Literal["AGE_QUESTION", "SIMPLE_MEDICAL_HISTORY_QUESTION", "VITALS_QUESTION", "LAB_RESULTS_QUESTION"]
    ] = FieldInfo(alias="handlerSignature", default=None)


class CriterionListResponseItemMatchingPayloadSignalEntity(BaseModel):
    entity: str

    entity_id: str = FieldInfo(alias="entityId")

    entity_type: str = FieldInfo(alias="entityType")

    reasoning: Optional[str] = None


class CriterionListResponseItemMatchingPayload(BaseModel):
    data_type: List[Literal["LAB", "MEDICATION", "DIAGNOSIS", "PROCEDURE", "VITALS", "DEMOGRAPHICS", "ALLERGY"]] = (
        FieldInfo(alias="dataType")
    )

    routing_metadata: Optional[CriterionListResponseItemMatchingPayloadRoutingMetadata] = FieldInfo(
        alias="routingMetadata", default=None
    )

    schema_version: Optional[Literal["v1"]] = FieldInfo(alias="schemaVersion", default=None)

    signal_entities: Optional[List[CriterionListResponseItemMatchingPayloadSignalEntity]] = FieldInfo(
        alias="signalEntities", default=None
    )


class CriterionListResponseItem(BaseModel):
    parent_type: Literal["PROTOCOL", "CUSTOM_SEARCH"] = FieldInfo(alias="parentType")

    summary: str

    type: CriteriaType

    id: Optional[int] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    created_by: Optional[int] = FieldInfo(alias="createdBy", default=None)

    created_from_id: Optional[int] = FieldInfo(alias="createdFromId", default=None)

    criteria_protocol_metadata_id: Optional[int] = FieldInfo(alias="criteriaProtocolMetadataId", default=None)

    custom_search_id: Optional[int] = FieldInfo(alias="customSearchId", default=None)

    deleted_at: Optional[datetime] = FieldInfo(alias="deletedAt", default=None)

    description: Optional[str] = None

    hydrated_at: Optional[datetime] = FieldInfo(alias="hydratedAt", default=None)

    hydration_error: Optional[CriterionListResponseItemHydrationError] = FieldInfo(alias="hydrationError", default=None)

    hydration_status: Optional[Literal["PENDING", "SUCCESS", "ERROR"]] = FieldInfo(
        alias="hydrationStatus", default=None
    )

    is_priority: Optional[bool] = FieldInfo(alias="isPriority", default=None)

    matching_payload: Optional[CriterionListResponseItemMatchingPayload] = FieldInfo(
        alias="matchingPayload", default=None
    )

    priority_order: Optional[int] = FieldInfo(alias="priorityOrder", default=None)

    protocol_id: Optional[int] = FieldInfo(alias="protocolId", default=None)

    status: Optional[CriteriaStatus] = None

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)

    user_raw_input: Optional[str] = FieldInfo(alias="userRawInput", default=None)


CriterionListResponse: TypeAlias = List[CriterionListResponseItem]
