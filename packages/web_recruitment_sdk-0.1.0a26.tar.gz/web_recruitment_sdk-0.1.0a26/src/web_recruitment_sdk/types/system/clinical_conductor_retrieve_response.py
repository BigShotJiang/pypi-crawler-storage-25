# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["ClinicalConductorRetrieveResponse"]


class ClinicalConductorRetrieveResponse(BaseModel):
    """Information about a visit."""

    id: int

    name: str

    visit_id: int

    is_active: Optional[bool] = None

    standard_minutes: Optional[int] = None
    """Configured appointment duration in minutes"""
