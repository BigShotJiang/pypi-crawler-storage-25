# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["ConcurrencyRetrieveStatusResponse"]


class ConcurrencyRetrieveStatusResponse(BaseModel):
    """Response model for concurrency status."""

    available_slots: int
    """Number of available slots"""

    current_count: int
    """Current number of concurrent operations"""

    limit: int
    """Maximum concurrency limit"""

    tenant_db_name: str
    """The tenant database name"""

    campaign_id: Optional[int] = None
    """Optional campaign ID for scoped concurrency"""
