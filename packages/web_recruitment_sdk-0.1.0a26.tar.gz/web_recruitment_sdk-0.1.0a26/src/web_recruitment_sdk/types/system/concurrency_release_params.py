# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["ConcurrencyReleaseParams"]


class ConcurrencyReleaseParams(TypedDict, total=False):
    workflow_id: Required[str]
    """Workflow ID that acquired the slot"""

    concurrency_limit: int

    campaign_id: Optional[int]
    """Optional campaign ID for scoped concurrency"""
