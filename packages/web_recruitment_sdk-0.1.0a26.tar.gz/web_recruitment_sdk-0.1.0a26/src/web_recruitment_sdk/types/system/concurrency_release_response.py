# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["ConcurrencyReleaseResponse"]


class ConcurrencyReleaseResponse(BaseModel):
    """Response model for releasing a concurrency slot."""

    current_count: int
    """Current number of concurrent operations after release"""

    success: bool
    """Whether the slot was released"""

    tenant_db_name: str
    """The tenant database name"""

    campaign_id: Optional[int] = None
    """Optional campaign ID for scoped concurrency"""
