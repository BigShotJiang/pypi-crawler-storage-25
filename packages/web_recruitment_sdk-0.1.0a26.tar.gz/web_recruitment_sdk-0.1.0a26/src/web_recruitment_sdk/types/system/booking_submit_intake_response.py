# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["BookingSubmitIntakeResponse", "GateEvaluation"]


class GateEvaluation(BaseModel):
    """Result of a single intake eligibility gate evaluation.

    Captures the full decision context so the journey can be reconstructed:
    the gate type, whether it passed, the candidate's computed value, and
    the configured thresholds at the time of evaluation.
    """

    gate: Literal["age", "bmi"]

    passed: bool

    value: float

    maximum: Optional[float] = None

    minimum: Optional[float] = None


class BookingSubmitIntakeResponse(BaseModel):
    """Response for POST /system/{tenant_db_name}/booking/intake endpoint."""

    passed: bool

    gate_evaluations: Optional[List[GateEvaluation]] = FieldInfo(alias="gateEvaluations", default=None)
