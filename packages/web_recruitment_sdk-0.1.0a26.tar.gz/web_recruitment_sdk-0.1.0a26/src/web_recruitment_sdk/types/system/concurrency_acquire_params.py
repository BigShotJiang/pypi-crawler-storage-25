# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["ConcurrencyAcquireParams"]


class ConcurrencyAcquireParams(TypedDict, total=False):
    workflow_id: Required[str]
    """Unique workflow ID for slot tracking"""

    concurrency_limit: int

    campaign_id: Optional[int]
    """Optional campaign ID for scoped concurrency"""
