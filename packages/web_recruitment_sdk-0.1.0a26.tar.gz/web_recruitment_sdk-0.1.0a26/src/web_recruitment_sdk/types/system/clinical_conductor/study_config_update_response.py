# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from datetime import datetime

from ...._models import BaseModel

__all__ = ["StudyConfigUpdateResponse"]


class StudyConfigUpdateResponse(BaseModel):
    """Response body for a study config."""

    id: int

    clinical_conductor_instance_id: int

    clinical_conductor_site_id: int

    clinical_conductor_study_id: int

    created_at: datetime

    is_active: bool

    target_visit_id: int

    updated_at: datetime
