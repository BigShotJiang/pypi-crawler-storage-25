# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ...._models import BaseModel

__all__ = ["InstanceTestConnectionResponse"]


class InstanceTestConnectionResponse(BaseModel):
    """Response body for connection test."""

    message: str

    success: bool
