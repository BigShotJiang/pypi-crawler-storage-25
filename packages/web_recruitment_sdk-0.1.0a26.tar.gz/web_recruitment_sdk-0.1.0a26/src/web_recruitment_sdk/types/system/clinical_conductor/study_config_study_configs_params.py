# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["StudyConfigStudyConfigsParams"]


class StudyConfigStudyConfigsParams(TypedDict, total=False):
    clinical_conductor_instance_id: Required[int]
    """ID of the Clinical Conductor instance"""

    clinical_conductor_site_id: Required[int]
    """Site ID in Clinical Conductor"""

    clinical_conductor_study_id: Required[int]
    """Study ID in Clinical Conductor"""

    target_visit_id: Required[int]
    """Target visit ID for scheduling appointments"""

    is_active: bool
    """Whether the config is active"""
