# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from datetime import datetime

from ...._models import BaseModel

__all__ = ["InstanceRetrieveResponse"]


class InstanceRetrieveResponse(BaseModel):
    """Response body for a Clinical Conductor instance."""

    id: int

    base_url: str

    created_at: datetime

    instance_name: str

    updated_at: datetime
