# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["StudyConfigUpdateParams"]


class StudyConfigUpdateParams(TypedDict, total=False):
    tenant_db_name: Required[str]

    clinical_conductor_instance_id: Optional[int]
    """ID of the Clinical Conductor instance"""

    clinical_conductor_site_id: Optional[int]
    """Site ID in Clinical Conductor"""

    clinical_conductor_study_id: Optional[int]
    """Study ID in Clinical Conductor"""

    is_active: Optional[bool]
    """Whether the config is active"""

    target_visit_id: Optional[int]
    """Target visit ID for scheduling appointments"""
