# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from ...._models import BaseModel

__all__ = ["StudyConfigRetrieveVisitsResponse", "Visit"]


class Visit(BaseModel):
    """Information about a visit."""

    id: int

    name: str

    visit_id: int

    is_active: Optional[bool] = None

    standard_minutes: Optional[int] = None
    """Configured appointment duration in minutes"""


class StudyConfigRetrieveVisitsResponse(BaseModel):
    """Response body for listing visits."""

    visits: List[Visit]
