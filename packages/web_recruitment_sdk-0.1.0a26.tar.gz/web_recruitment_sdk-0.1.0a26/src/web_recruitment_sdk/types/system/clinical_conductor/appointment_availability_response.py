# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime

from ...._models import BaseModel

__all__ = ["AppointmentAvailabilityResponse", "Slot"]


class Slot(BaseModel):
    """Response body for a time slot."""

    id: str

    available: bool

    end_time: datetime

    start_time: datetime


class AppointmentAvailabilityResponse(BaseModel):
    """Response body for availability query."""

    slots: List[Slot]
