# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ...._models import BaseModel

__all__ = ["AppointmentRetrieveResponse"]


class AppointmentRetrieveResponse(BaseModel):
    """Response body for an appointment."""

    id: int

    candidate_id: int

    created_at: datetime

    scheduled_datetime: datetime

    source: str

    status: str

    updated_at: datetime

    source_metadata: Optional[object] = None
