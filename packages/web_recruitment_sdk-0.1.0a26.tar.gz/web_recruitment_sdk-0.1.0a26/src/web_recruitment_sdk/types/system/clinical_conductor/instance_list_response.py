# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime
from typing_extensions import TypeAlias

from ...._models import BaseModel

__all__ = ["InstanceListResponse", "InstanceListResponseItem"]


class InstanceListResponseItem(BaseModel):
    """Response body for a Clinical Conductor instance."""

    id: int

    base_url: str

    created_at: datetime

    instance_name: str

    updated_at: datetime


InstanceListResponse: TypeAlias = List[InstanceListResponseItem]
