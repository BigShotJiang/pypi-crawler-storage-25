# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from ...._types import SequenceNotStr
from ...._utils import PropertyInfo

__all__ = ["AppointmentAvailabilityParams"]


class AppointmentAvailabilityParams(TypedDict, total=False):
    candidate_id: Required[int]
    """The candidate ID used to resolve enrollment"""

    end_date: Required[Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]]
    """End of date range to query"""

    start_date: Required[Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]]
    """Start of date range to query"""

    study_config_id: Required[int]
    """The study config ID"""

    days_of_week: SequenceNotStr[str]
    """
    Days of the week to query availability for (e.g., Monday, Tuesday, Wednesday,
    Thursday, Friday, Saturday, Sunday)
    """

    interval: str
    """Time slot interval (e.g., Minutes15, Minutes30)"""
