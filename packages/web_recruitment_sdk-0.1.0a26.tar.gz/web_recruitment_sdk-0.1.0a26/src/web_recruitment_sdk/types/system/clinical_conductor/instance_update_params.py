# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["InstanceUpdateParams"]


class InstanceUpdateParams(TypedDict, total=False):
    tenant_db_name: Required[str]

    api_key: Optional[str]
    """New API key (plain text, will be encrypted)"""

    base_url: Optional[str]
    """New base URL for the Clinical Conductor API"""

    instance_name: Optional[str]
    """New display name for the instance"""
