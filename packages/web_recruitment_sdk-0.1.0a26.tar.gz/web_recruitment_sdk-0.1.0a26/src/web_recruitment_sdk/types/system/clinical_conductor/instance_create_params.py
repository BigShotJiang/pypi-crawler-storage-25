# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["InstanceCreateParams"]


class InstanceCreateParams(TypedDict, total=False):
    api_key: Required[str]
    """API key (plain text, will be encrypted)"""

    base_url: Required[str]
    """Base URL for the Clinical Conductor API"""

    instance_name: Required[str]
    """Display name for the instance"""
