# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["ConcurrencyRetrieveStatusParams"]


class ConcurrencyRetrieveStatusParams(TypedDict, total=False):
    campaign_id: Optional[int]
    """Optional campaign ID to scope concurrency status"""

    concurrency_limit: int
