# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["BookingGetVisitInfoResponse"]


class BookingGetVisitInfoResponse(BaseModel):
    """Response for GET /booking/visit-info endpoint."""

    duration_minutes: int = FieldInfo(alias="durationMinutes")

    visit_id: int = FieldInfo(alias="visitId")

    visit_name: str = FieldInfo(alias="visitName")
