# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from ..criteria_type import CriteriaType
from ..custom_searches.criteria_status import CriteriaStatus

__all__ = [
    "CriterionGetMatchingProgressResponse",
    "MatchingProgress",
    "MatchingProgressSiteBreakdown",
    "HydrationError",
    "MatchingPayload",
    "MatchingPayloadRoutingMetadata",
    "MatchingPayloadRoutingMetadataHandlerPayload",
    "MatchingPayloadSignalEntity",
]


class MatchingProgressSiteBreakdown(BaseModel):
    """Progress for a specific site"""

    patients_matched: int = FieldInfo(alias="patientsMatched")

    site_id: int = FieldInfo(alias="siteId")

    site_name: str = FieldInfo(alias="siteName")

    total_patients: int = FieldInfo(alias="totalPatients")


class MatchingProgress(BaseModel):
    """Progress information for a single criterion"""

    criterion_id: int = FieldInfo(alias="criterionId")

    patients_matched: int = FieldInfo(alias="patientsMatched")

    total_patients: int = FieldInfo(alias="totalPatients")

    site_breakdown: Optional[List[MatchingProgressSiteBreakdown]] = FieldInfo(alias="siteBreakdown", default=None)


class HydrationError(BaseModel):
    error_message: str = FieldInfo(alias="errorMessage")

    retryable: bool

    error_code: Optional[str] = FieldInfo(alias="errorCode", default=None)

    failed_stage: Optional[str] = FieldInfo(alias="failedStage", default=None)


class MatchingPayloadRoutingMetadataHandlerPayload(BaseModel):
    payload: object

    payload_model: str = FieldInfo(alias="payloadModel")
    """The string representation of the pydantic model of the payload."""


class MatchingPayloadRoutingMetadata(BaseModel):
    agent_signature: Literal["SEMANTIC_RETRIEVAL", "QUANTITATIVE_LOGIC", "ADVANCED_LOGIC", "PROCEDURAL_INTENT"] = (
        FieldInfo(alias="agentSignature")
    )

    handler_payload: Optional[MatchingPayloadRoutingMetadataHandlerPayload] = FieldInfo(
        alias="handlerPayload", default=None
    )

    handler_signature: Optional[
        Literal["AGE_QUESTION", "SIMPLE_MEDICAL_HISTORY_QUESTION", "VITALS_QUESTION", "LAB_RESULTS_QUESTION"]
    ] = FieldInfo(alias="handlerSignature", default=None)


class MatchingPayloadSignalEntity(BaseModel):
    entity: str

    entity_id: str = FieldInfo(alias="entityId")

    entity_type: str = FieldInfo(alias="entityType")

    reasoning: Optional[str] = None


class MatchingPayload(BaseModel):
    data_type: List[Literal["LAB", "MEDICATION", "DIAGNOSIS", "PROCEDURE", "VITALS", "DEMOGRAPHICS", "ALLERGY"]] = (
        FieldInfo(alias="dataType")
    )

    routing_metadata: Optional[MatchingPayloadRoutingMetadata] = FieldInfo(alias="routingMetadata", default=None)

    schema_version: Optional[Literal["v1"]] = FieldInfo(alias="schemaVersion", default=None)

    signal_entities: Optional[List[MatchingPayloadSignalEntity]] = FieldInfo(alias="signalEntities", default=None)


class CriterionGetMatchingProgressResponse(BaseModel):
    """Criterion details with matching progress for monitoring/notifications.

    Extends CriteriaRead with nested matching progress data to enable quick
    lookups for stuck or pending criteria. Optimized for internal monitoring.
    """

    id: int

    matching_progress: MatchingProgress = FieldInfo(alias="matchingProgress")
    """Progress information for a single criterion"""

    summary: str

    type: CriteriaType

    criteria_protocol_metadata_id: Optional[int] = FieldInfo(alias="criteriaProtocolMetadataId", default=None)

    custom_search_id: Optional[int] = FieldInfo(alias="customSearchId", default=None)

    description: Optional[str] = None

    hydrated_at: Optional[datetime] = FieldInfo(alias="hydratedAt", default=None)

    hydration_error: Optional[HydrationError] = FieldInfo(alias="hydrationError", default=None)

    hydration_status: Optional[Literal["PENDING", "SUCCESS", "ERROR"]] = FieldInfo(
        alias="hydrationStatus", default=None
    )

    is_priority: Optional[bool] = FieldInfo(alias="isPriority", default=None)

    matching_payload: Optional[MatchingPayload] = FieldInfo(alias="matchingPayload", default=None)

    priority_order: Optional[int] = FieldInfo(alias="priorityOrder", default=None)

    protocol_id: Optional[int] = FieldInfo(alias="protocolId", default=None)

    status: Optional[CriteriaStatus] = None

    user_raw_input: Optional[str] = FieldInfo(alias="userRawInput", default=None)
