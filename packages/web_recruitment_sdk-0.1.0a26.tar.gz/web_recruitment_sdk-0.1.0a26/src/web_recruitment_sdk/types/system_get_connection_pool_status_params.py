# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["SystemGetConnectionPoolStatusParams"]


class SystemGetConnectionPoolStatusParams(TypedDict, total=False):
    pool: str
    """Pool to check: 'primary' or 'replica'"""
