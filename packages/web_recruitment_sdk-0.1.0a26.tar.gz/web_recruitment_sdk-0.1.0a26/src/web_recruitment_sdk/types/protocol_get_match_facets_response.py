# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ProtocolGetMatchFacetsResponse", "Option"]


class Option(BaseModel):
    count: int

    label: str

    value: str


class ProtocolGetMatchFacetsResponse(BaseModel):
    field: Literal["state", "zip_code", "last_encounter_provider", "primary_provider"]

    options: List[Option]

    has_more: Optional[bool] = FieldInfo(alias="hasMore", default=None)
