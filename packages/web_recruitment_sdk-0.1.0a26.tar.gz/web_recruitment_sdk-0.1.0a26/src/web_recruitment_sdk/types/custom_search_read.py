# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["CustomSearchRead", "Site"]


class Site(BaseModel):
    id: int

    name: str

    city: Optional[str] = None

    latitude: Optional[float] = None

    longitude: Optional[float] = None

    state: Optional[str] = None

    street_address: Optional[str] = FieldInfo(alias="streetAddress", default=None)

    trially_site_id: Optional[str] = FieldInfo(alias="triallySiteId", default=None)

    zip_code: Optional[str] = FieldInfo(alias="zipCode", default=None)


class CustomSearchRead(BaseModel):
    id: int

    status: Literal["in_review", "ready"]

    title: str

    sites: Optional[List[Site]] = None
