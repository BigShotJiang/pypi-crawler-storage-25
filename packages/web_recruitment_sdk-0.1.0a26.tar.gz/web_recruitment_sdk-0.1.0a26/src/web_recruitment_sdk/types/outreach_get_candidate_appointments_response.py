# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["OutreachGetCandidateAppointmentsResponse", "OutreachGetCandidateAppointmentsResponseItem"]


class OutreachGetCandidateAppointmentsResponseItem(BaseModel):
    id: int

    candidate_id: int = FieldInfo(alias="candidateId")

    candidate_name: str = FieldInfo(alias="candidateName")

    created_at: datetime = FieldInfo(alias="createdAt")

    scheduled_datetime: datetime = FieldInfo(alias="scheduledDatetime")

    status: Literal["booked", "cancelled"]

    updated_at: datetime = FieldInfo(alias="updatedAt")

    appointment_type: Optional[Literal["in_person", "phone_call"]] = FieldInfo(alias="appointmentType", default=None)

    campaign_id: Optional[int] = FieldInfo(alias="campaignId", default=None)

    campaign_name: Optional[str] = FieldInfo(alias="campaignName", default=None)

    candidate_email: Optional[str] = FieldInfo(alias="candidateEmail", default=None)

    candidate_phone: Optional[str] = FieldInfo(alias="candidatePhone", default=None)


OutreachGetCandidateAppointmentsResponse: TypeAlias = List[OutreachGetCandidateAppointmentsResponseItem]
