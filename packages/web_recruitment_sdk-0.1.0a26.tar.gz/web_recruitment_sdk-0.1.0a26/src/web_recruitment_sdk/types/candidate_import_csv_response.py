# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["CandidateImportCsvResponse", "ImportResult", "ImportResultFailedImport"]


class ImportResultFailedImport(BaseModel):
    """Error details for a failed CSV patient import row."""

    patient_data: Dict[str, str] = FieldInfo(alias="patientData")

    reason: str

    row_number: int = FieldInfo(alias="rowNumber")


class ImportResult(BaseModel):
    """Result of a CSV candidate import operation."""

    failed_imports: List[ImportResultFailedImport] = FieldInfo(alias="failedImports")

    successful_imports: int = FieldInfo(alias="successfulImports")

    total_rows: int = FieldInfo(alias="totalRows")

    skipped_duplicates: Optional[int] = FieldInfo(alias="skippedDuplicates", default=None)

    successful_candidate_ids: Optional[List[int]] = FieldInfo(alias="successfulCandidateIds", default=None)


class CandidateImportCsvResponse(BaseModel):
    """Response model for candidate CSV upload and import."""

    import_result: ImportResult = FieldInfo(alias="importResult")
    """Result of a CSV candidate import operation."""

    message: str

    storage_url: str = FieldInfo(alias="storageUrl")
