# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Dict, Mapping, cast
from typing_extensions import Self, Literal, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import (
    is_given,
    is_mapping_t,
    get_async_library,
)
from ._compat import cached_property
from ._version import __version__
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import APIStatusError, WebRecruitmentSDKError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)

if TYPE_CHECKING:
    from .resources import (
        auth,
        crio,
        admin,
        sites,
        health,
        system,
        criteria,
        external,
        facebook,
        outreach,
        patients,
        webhooks,
        protocols,
        readiness,
        workflows,
        candidates,
        dashboards,
        scheduling,
        export_jobs,
        appointments,
        landing_pages,
        matching_jobs,
        custom_criteria,
        custom_searches,
        protocol_parsing,
        clinical_conductor,
        patients_by_external_id,
    )
    from .resources.auth import AuthResource, AsyncAuthResource
    from .resources.sites import SitesResource, AsyncSitesResource
    from .resources.health import HealthResource, AsyncHealthResource
    from .resources.criteria import CriteriaResource, AsyncCriteriaResource
    from .resources.crio.crio import CrioResource, AsyncCrioResource
    from .resources.readiness import ReadinessResource, AsyncReadinessResource
    from .resources.candidates import CandidatesResource, AsyncCandidatesResource
    from .resources.dashboards import DashboardsResource, AsyncDashboardsResource
    from .resources.scheduling import SchedulingResource, AsyncSchedulingResource
    from .resources.admin.admin import AdminResource, AsyncAdminResource
    from .resources.export_jobs import ExportJobsResource, AsyncExportJobsResource
    from .resources.appointments import AppointmentsResource, AsyncAppointmentsResource
    from .resources.matching_jobs import MatchingJobsResource, AsyncMatchingJobsResource
    from .resources.system.system import SystemResource, AsyncSystemResource
    from .resources.custom_criteria import CustomCriteriaResource, AsyncCustomCriteriaResource
    from .resources.external.external import ExternalResource, AsyncExternalResource
    from .resources.facebook.facebook import FacebookResource, AsyncFacebookResource
    from .resources.outreach.outreach import OutreachResource, AsyncOutreachResource
    from .resources.patients.patients import PatientsResource, AsyncPatientsResource
    from .resources.webhooks.webhooks import WebhooksResource, AsyncWebhooksResource
    from .resources.clinical_conductor import ClinicalConductorResource, AsyncClinicalConductorResource
    from .resources.protocols.protocols import ProtocolsResource, AsyncProtocolsResource
    from .resources.workflows.workflows import WorkflowsResource, AsyncWorkflowsResource
    from .resources.patients_by_external_id import PatientsByExternalIDResource, AsyncPatientsByExternalIDResource
    from .resources.landing_pages.landing_pages import LandingPagesResource, AsyncLandingPagesResource
    from .resources.custom_searches.custom_searches import CustomSearchesResource, AsyncCustomSearchesResource
    from .resources.protocol_parsing.protocol_parsing import ProtocolParsingResource, AsyncProtocolParsingResource

__all__ = [
    "ENVIRONMENTS",
    "Timeout",
    "Transport",
    "ProxiesTypes",
    "RequestOptions",
    "WebRecruitmentSDK",
    "AsyncWebRecruitmentSDK",
    "Client",
    "AsyncClient",
]

ENVIRONMENTS: Dict[str, str] = {
    "development": "http://localhost:8080",
    "production": "https://trially-backend-production-861990824910.us-central1.run.app",
    "staging": "https://trially-backend-staging-965051512294.us-central1.run.app",
}


class WebRecruitmentSDK(SyncAPIClient):
    # client options
    bearer_token: str

    _environment: Literal["development", "production", "staging"] | NotGiven

    def __init__(
        self,
        *,
        bearer_token: str | None = None,
        environment: Literal["development", "production", "staging"] | NotGiven = not_given,
        base_url: str | httpx.URL | None | NotGiven = not_given,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous WebRecruitmentSDK client instance.

        This automatically infers the `bearer_token` argument from the `WEB_RECRUITMENT_SDK_BEARER_TOKEN` environment variable if it is not provided.
        """
        if bearer_token is None:
            bearer_token = os.environ.get("WEB_RECRUITMENT_SDK_BEARER_TOKEN")
        if bearer_token is None:
            raise WebRecruitmentSDKError(
                "The bearer_token client option must be set either by passing bearer_token to the client or by setting the WEB_RECRUITMENT_SDK_BEARER_TOKEN environment variable"
            )
        self.bearer_token = bearer_token

        self._environment = environment

        base_url_env = os.environ.get("WEB_RECRUITMENT_SDK_BASE_URL")
        if is_given(base_url) and base_url is not None:
            # cast required because mypy doesn't understand the type narrowing
            base_url = cast("str | httpx.URL", base_url)  # pyright: ignore[reportUnnecessaryCast]
        elif is_given(environment):
            if base_url_env and base_url is not None:
                raise ValueError(
                    "Ambiguous URL; The `WEB_RECRUITMENT_SDK_BASE_URL` env var and the `environment` argument are given. If you want to use the environment, you must pass base_url=None",
                )

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc
        elif base_url_env is not None:
            base_url = base_url_env
        else:
            self._environment = environment = "development"

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc

        custom_headers_env = os.environ.get("WEB_RECRUITMENT_SDK_CUSTOM_HEADERS")
        if custom_headers_env is not None:
            parsed: dict[str, str] = {}
            for line in custom_headers_env.split("\n"):
                colon = line.find(":")
                if colon >= 0:
                    parsed[line[:colon].strip()] = line[colon + 1 :].strip()
            default_headers = {**parsed, **(default_headers if is_mapping_t(default_headers) else {})}

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def auth(self) -> AuthResource:
        from .resources.auth import AuthResource

        return AuthResource(self)

    @cached_property
    def admin(self) -> AdminResource:
        from .resources.admin import AdminResource

        return AdminResource(self)

    @cached_property
    def patients(self) -> PatientsResource:
        from .resources.patients import PatientsResource

        return PatientsResource(self)

    @cached_property
    def patients_by_external_id(self) -> PatientsByExternalIDResource:
        from .resources.patients_by_external_id import PatientsByExternalIDResource

        return PatientsByExternalIDResource(self)

    @cached_property
    def protocol_parsing(self) -> ProtocolParsingResource:
        from .resources.protocol_parsing import ProtocolParsingResource

        return ProtocolParsingResource(self)

    @cached_property
    def matching_jobs(self) -> MatchingJobsResource:
        from .resources.matching_jobs import MatchingJobsResource

        return MatchingJobsResource(self)

    @cached_property
    def custom_searches(self) -> CustomSearchesResource:
        from .resources.custom_searches import CustomSearchesResource

        return CustomSearchesResource(self)

    @cached_property
    def custom_criteria(self) -> CustomCriteriaResource:
        from .resources.custom_criteria import CustomCriteriaResource

        return CustomCriteriaResource(self)

    @cached_property
    def criteria(self) -> CriteriaResource:
        from .resources.criteria import CriteriaResource

        return CriteriaResource(self)

    @cached_property
    def appointments(self) -> AppointmentsResource:
        from .resources.appointments import AppointmentsResource

        return AppointmentsResource(self)

    @cached_property
    def sites(self) -> SitesResource:
        from .resources.sites import SitesResource

        return SitesResource(self)

    @cached_property
    def crio(self) -> CrioResource:
        from .resources.crio import CrioResource

        return CrioResource(self)

    @cached_property
    def health(self) -> HealthResource:
        from .resources.health import HealthResource

        return HealthResource(self)

    @cached_property
    def system(self) -> SystemResource:
        from .resources.system import SystemResource

        return SystemResource(self)

    @cached_property
    def dashboards(self) -> DashboardsResource:
        from .resources.dashboards import DashboardsResource

        return DashboardsResource(self)

    @cached_property
    def protocols(self) -> ProtocolsResource:
        from .resources.protocols import ProtocolsResource

        return ProtocolsResource(self)

    @cached_property
    def export_jobs(self) -> ExportJobsResource:
        from .resources.export_jobs import ExportJobsResource

        return ExportJobsResource(self)

    @cached_property
    def external(self) -> ExternalResource:
        from .resources.external import ExternalResource

        return ExternalResource(self)

    @cached_property
    def outreach(self) -> OutreachResource:
        from .resources.outreach import OutreachResource

        return OutreachResource(self)

    @cached_property
    def webhooks(self) -> WebhooksResource:
        from .resources.webhooks import WebhooksResource

        return WebhooksResource(self)

    @cached_property
    def candidates(self) -> CandidatesResource:
        from .resources.candidates import CandidatesResource

        return CandidatesResource(self)

    @cached_property
    def workflows(self) -> WorkflowsResource:
        from .resources.workflows import WorkflowsResource

        return WorkflowsResource(self)

    @cached_property
    def clinical_conductor(self) -> ClinicalConductorResource:
        from .resources.clinical_conductor import ClinicalConductorResource

        return ClinicalConductorResource(self)

    @cached_property
    def facebook(self) -> FacebookResource:
        from .resources.facebook import FacebookResource

        return FacebookResource(self)

    @cached_property
    def readiness(self) -> ReadinessResource:
        from .resources.readiness import ReadinessResource

        return ReadinessResource(self)

    @cached_property
    def landing_pages(self) -> LandingPagesResource:
        from .resources.landing_pages import LandingPagesResource

        return LandingPagesResource(self)

    @cached_property
    def scheduling(self) -> SchedulingResource:
        from .resources.scheduling import SchedulingResource

        return SchedulingResource(self)

    @cached_property
    def with_raw_response(self) -> WebRecruitmentSDKWithRawResponse:
        return WebRecruitmentSDKWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WebRecruitmentSDKWithStreamedResponse:
        return WebRecruitmentSDKWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        bearer_token = self.bearer_token
        return {"Authorization": f"Bearer {bearer_token}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        bearer_token: str | None = None,
        environment: Literal["development", "production", "staging"] | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            bearer_token=bearer_token or self.bearer_token,
            base_url=base_url or self.base_url,
            environment=environment or self._environment,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncWebRecruitmentSDK(AsyncAPIClient):
    # client options
    bearer_token: str

    _environment: Literal["development", "production", "staging"] | NotGiven

    def __init__(
        self,
        *,
        bearer_token: str | None = None,
        environment: Literal["development", "production", "staging"] | NotGiven = not_given,
        base_url: str | httpx.URL | None | NotGiven = not_given,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncWebRecruitmentSDK client instance.

        This automatically infers the `bearer_token` argument from the `WEB_RECRUITMENT_SDK_BEARER_TOKEN` environment variable if it is not provided.
        """
        if bearer_token is None:
            bearer_token = os.environ.get("WEB_RECRUITMENT_SDK_BEARER_TOKEN")
        if bearer_token is None:
            raise WebRecruitmentSDKError(
                "The bearer_token client option must be set either by passing bearer_token to the client or by setting the WEB_RECRUITMENT_SDK_BEARER_TOKEN environment variable"
            )
        self.bearer_token = bearer_token

        self._environment = environment

        base_url_env = os.environ.get("WEB_RECRUITMENT_SDK_BASE_URL")
        if is_given(base_url) and base_url is not None:
            # cast required because mypy doesn't understand the type narrowing
            base_url = cast("str | httpx.URL", base_url)  # pyright: ignore[reportUnnecessaryCast]
        elif is_given(environment):
            if base_url_env and base_url is not None:
                raise ValueError(
                    "Ambiguous URL; The `WEB_RECRUITMENT_SDK_BASE_URL` env var and the `environment` argument are given. If you want to use the environment, you must pass base_url=None",
                )

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc
        elif base_url_env is not None:
            base_url = base_url_env
        else:
            self._environment = environment = "development"

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc

        custom_headers_env = os.environ.get("WEB_RECRUITMENT_SDK_CUSTOM_HEADERS")
        if custom_headers_env is not None:
            parsed: dict[str, str] = {}
            for line in custom_headers_env.split("\n"):
                colon = line.find(":")
                if colon >= 0:
                    parsed[line[:colon].strip()] = line[colon + 1 :].strip()
            default_headers = {**parsed, **(default_headers if is_mapping_t(default_headers) else {})}

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def auth(self) -> AsyncAuthResource:
        from .resources.auth import AsyncAuthResource

        return AsyncAuthResource(self)

    @cached_property
    def admin(self) -> AsyncAdminResource:
        from .resources.admin import AsyncAdminResource

        return AsyncAdminResource(self)

    @cached_property
    def patients(self) -> AsyncPatientsResource:
        from .resources.patients import AsyncPatientsResource

        return AsyncPatientsResource(self)

    @cached_property
    def patients_by_external_id(self) -> AsyncPatientsByExternalIDResource:
        from .resources.patients_by_external_id import AsyncPatientsByExternalIDResource

        return AsyncPatientsByExternalIDResource(self)

    @cached_property
    def protocol_parsing(self) -> AsyncProtocolParsingResource:
        from .resources.protocol_parsing import AsyncProtocolParsingResource

        return AsyncProtocolParsingResource(self)

    @cached_property
    def matching_jobs(self) -> AsyncMatchingJobsResource:
        from .resources.matching_jobs import AsyncMatchingJobsResource

        return AsyncMatchingJobsResource(self)

    @cached_property
    def custom_searches(self) -> AsyncCustomSearchesResource:
        from .resources.custom_searches import AsyncCustomSearchesResource

        return AsyncCustomSearchesResource(self)

    @cached_property
    def custom_criteria(self) -> AsyncCustomCriteriaResource:
        from .resources.custom_criteria import AsyncCustomCriteriaResource

        return AsyncCustomCriteriaResource(self)

    @cached_property
    def criteria(self) -> AsyncCriteriaResource:
        from .resources.criteria import AsyncCriteriaResource

        return AsyncCriteriaResource(self)

    @cached_property
    def appointments(self) -> AsyncAppointmentsResource:
        from .resources.appointments import AsyncAppointmentsResource

        return AsyncAppointmentsResource(self)

    @cached_property
    def sites(self) -> AsyncSitesResource:
        from .resources.sites import AsyncSitesResource

        return AsyncSitesResource(self)

    @cached_property
    def crio(self) -> AsyncCrioResource:
        from .resources.crio import AsyncCrioResource

        return AsyncCrioResource(self)

    @cached_property
    def health(self) -> AsyncHealthResource:
        from .resources.health import AsyncHealthResource

        return AsyncHealthResource(self)

    @cached_property
    def system(self) -> AsyncSystemResource:
        from .resources.system import AsyncSystemResource

        return AsyncSystemResource(self)

    @cached_property
    def dashboards(self) -> AsyncDashboardsResource:
        from .resources.dashboards import AsyncDashboardsResource

        return AsyncDashboardsResource(self)

    @cached_property
    def protocols(self) -> AsyncProtocolsResource:
        from .resources.protocols import AsyncProtocolsResource

        return AsyncProtocolsResource(self)

    @cached_property
    def export_jobs(self) -> AsyncExportJobsResource:
        from .resources.export_jobs import AsyncExportJobsResource

        return AsyncExportJobsResource(self)

    @cached_property
    def external(self) -> AsyncExternalResource:
        from .resources.external import AsyncExternalResource

        return AsyncExternalResource(self)

    @cached_property
    def outreach(self) -> AsyncOutreachResource:
        from .resources.outreach import AsyncOutreachResource

        return AsyncOutreachResource(self)

    @cached_property
    def webhooks(self) -> AsyncWebhooksResource:
        from .resources.webhooks import AsyncWebhooksResource

        return AsyncWebhooksResource(self)

    @cached_property
    def candidates(self) -> AsyncCandidatesResource:
        from .resources.candidates import AsyncCandidatesResource

        return AsyncCandidatesResource(self)

    @cached_property
    def workflows(self) -> AsyncWorkflowsResource:
        from .resources.workflows import AsyncWorkflowsResource

        return AsyncWorkflowsResource(self)

    @cached_property
    def clinical_conductor(self) -> AsyncClinicalConductorResource:
        from .resources.clinical_conductor import AsyncClinicalConductorResource

        return AsyncClinicalConductorResource(self)

    @cached_property
    def facebook(self) -> AsyncFacebookResource:
        from .resources.facebook import AsyncFacebookResource

        return AsyncFacebookResource(self)

    @cached_property
    def readiness(self) -> AsyncReadinessResource:
        from .resources.readiness import AsyncReadinessResource

        return AsyncReadinessResource(self)

    @cached_property
    def landing_pages(self) -> AsyncLandingPagesResource:
        from .resources.landing_pages import AsyncLandingPagesResource

        return AsyncLandingPagesResource(self)

    @cached_property
    def scheduling(self) -> AsyncSchedulingResource:
        from .resources.scheduling import AsyncSchedulingResource

        return AsyncSchedulingResource(self)

    @cached_property
    def with_raw_response(self) -> AsyncWebRecruitmentSDKWithRawResponse:
        return AsyncWebRecruitmentSDKWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWebRecruitmentSDKWithStreamedResponse:
        return AsyncWebRecruitmentSDKWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        bearer_token = self.bearer_token
        return {"Authorization": f"Bearer {bearer_token}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        bearer_token: str | None = None,
        environment: Literal["development", "production", "staging"] | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            bearer_token=bearer_token or self.bearer_token,
            base_url=base_url or self.base_url,
            environment=environment or self._environment,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class WebRecruitmentSDKWithRawResponse:
    _client: WebRecruitmentSDK

    def __init__(self, client: WebRecruitmentSDK) -> None:
        self._client = client

    @cached_property
    def auth(self) -> auth.AuthResourceWithRawResponse:
        from .resources.auth import AuthResourceWithRawResponse

        return AuthResourceWithRawResponse(self._client.auth)

    @cached_property
    def admin(self) -> admin.AdminResourceWithRawResponse:
        from .resources.admin import AdminResourceWithRawResponse

        return AdminResourceWithRawResponse(self._client.admin)

    @cached_property
    def patients(self) -> patients.PatientsResourceWithRawResponse:
        from .resources.patients import PatientsResourceWithRawResponse

        return PatientsResourceWithRawResponse(self._client.patients)

    @cached_property
    def patients_by_external_id(self) -> patients_by_external_id.PatientsByExternalIDResourceWithRawResponse:
        from .resources.patients_by_external_id import PatientsByExternalIDResourceWithRawResponse

        return PatientsByExternalIDResourceWithRawResponse(self._client.patients_by_external_id)

    @cached_property
    def protocol_parsing(self) -> protocol_parsing.ProtocolParsingResourceWithRawResponse:
        from .resources.protocol_parsing import ProtocolParsingResourceWithRawResponse

        return ProtocolParsingResourceWithRawResponse(self._client.protocol_parsing)

    @cached_property
    def matching_jobs(self) -> matching_jobs.MatchingJobsResourceWithRawResponse:
        from .resources.matching_jobs import MatchingJobsResourceWithRawResponse

        return MatchingJobsResourceWithRawResponse(self._client.matching_jobs)

    @cached_property
    def custom_searches(self) -> custom_searches.CustomSearchesResourceWithRawResponse:
        from .resources.custom_searches import CustomSearchesResourceWithRawResponse

        return CustomSearchesResourceWithRawResponse(self._client.custom_searches)

    @cached_property
    def custom_criteria(self) -> custom_criteria.CustomCriteriaResourceWithRawResponse:
        from .resources.custom_criteria import CustomCriteriaResourceWithRawResponse

        return CustomCriteriaResourceWithRawResponse(self._client.custom_criteria)

    @cached_property
    def criteria(self) -> criteria.CriteriaResourceWithRawResponse:
        from .resources.criteria import CriteriaResourceWithRawResponse

        return CriteriaResourceWithRawResponse(self._client.criteria)

    @cached_property
    def appointments(self) -> appointments.AppointmentsResourceWithRawResponse:
        from .resources.appointments import AppointmentsResourceWithRawResponse

        return AppointmentsResourceWithRawResponse(self._client.appointments)

    @cached_property
    def sites(self) -> sites.SitesResourceWithRawResponse:
        from .resources.sites import SitesResourceWithRawResponse

        return SitesResourceWithRawResponse(self._client.sites)

    @cached_property
    def crio(self) -> crio.CrioResourceWithRawResponse:
        from .resources.crio import CrioResourceWithRawResponse

        return CrioResourceWithRawResponse(self._client.crio)

    @cached_property
    def health(self) -> health.HealthResourceWithRawResponse:
        from .resources.health import HealthResourceWithRawResponse

        return HealthResourceWithRawResponse(self._client.health)

    @cached_property
    def system(self) -> system.SystemResourceWithRawResponse:
        from .resources.system import SystemResourceWithRawResponse

        return SystemResourceWithRawResponse(self._client.system)

    @cached_property
    def dashboards(self) -> dashboards.DashboardsResourceWithRawResponse:
        from .resources.dashboards import DashboardsResourceWithRawResponse

        return DashboardsResourceWithRawResponse(self._client.dashboards)

    @cached_property
    def protocols(self) -> protocols.ProtocolsResourceWithRawResponse:
        from .resources.protocols import ProtocolsResourceWithRawResponse

        return ProtocolsResourceWithRawResponse(self._client.protocols)

    @cached_property
    def export_jobs(self) -> export_jobs.ExportJobsResourceWithRawResponse:
        from .resources.export_jobs import ExportJobsResourceWithRawResponse

        return ExportJobsResourceWithRawResponse(self._client.export_jobs)

    @cached_property
    def external(self) -> external.ExternalResourceWithRawResponse:
        from .resources.external import ExternalResourceWithRawResponse

        return ExternalResourceWithRawResponse(self._client.external)

    @cached_property
    def outreach(self) -> outreach.OutreachResourceWithRawResponse:
        from .resources.outreach import OutreachResourceWithRawResponse

        return OutreachResourceWithRawResponse(self._client.outreach)

    @cached_property
    def webhooks(self) -> webhooks.WebhooksResourceWithRawResponse:
        from .resources.webhooks import WebhooksResourceWithRawResponse

        return WebhooksResourceWithRawResponse(self._client.webhooks)

    @cached_property
    def candidates(self) -> candidates.CandidatesResourceWithRawResponse:
        from .resources.candidates import CandidatesResourceWithRawResponse

        return CandidatesResourceWithRawResponse(self._client.candidates)

    @cached_property
    def workflows(self) -> workflows.WorkflowsResourceWithRawResponse:
        from .resources.workflows import WorkflowsResourceWithRawResponse

        return WorkflowsResourceWithRawResponse(self._client.workflows)

    @cached_property
    def clinical_conductor(self) -> clinical_conductor.ClinicalConductorResourceWithRawResponse:
        from .resources.clinical_conductor import ClinicalConductorResourceWithRawResponse

        return ClinicalConductorResourceWithRawResponse(self._client.clinical_conductor)

    @cached_property
    def facebook(self) -> facebook.FacebookResourceWithRawResponse:
        from .resources.facebook import FacebookResourceWithRawResponse

        return FacebookResourceWithRawResponse(self._client.facebook)

    @cached_property
    def readiness(self) -> readiness.ReadinessResourceWithRawResponse:
        from .resources.readiness import ReadinessResourceWithRawResponse

        return ReadinessResourceWithRawResponse(self._client.readiness)

    @cached_property
    def landing_pages(self) -> landing_pages.LandingPagesResourceWithRawResponse:
        from .resources.landing_pages import LandingPagesResourceWithRawResponse

        return LandingPagesResourceWithRawResponse(self._client.landing_pages)

    @cached_property
    def scheduling(self) -> scheduling.SchedulingResourceWithRawResponse:
        from .resources.scheduling import SchedulingResourceWithRawResponse

        return SchedulingResourceWithRawResponse(self._client.scheduling)


class AsyncWebRecruitmentSDKWithRawResponse:
    _client: AsyncWebRecruitmentSDK

    def __init__(self, client: AsyncWebRecruitmentSDK) -> None:
        self._client = client

    @cached_property
    def auth(self) -> auth.AsyncAuthResourceWithRawResponse:
        from .resources.auth import AsyncAuthResourceWithRawResponse

        return AsyncAuthResourceWithRawResponse(self._client.auth)

    @cached_property
    def admin(self) -> admin.AsyncAdminResourceWithRawResponse:
        from .resources.admin import AsyncAdminResourceWithRawResponse

        return AsyncAdminResourceWithRawResponse(self._client.admin)

    @cached_property
    def patients(self) -> patients.AsyncPatientsResourceWithRawResponse:
        from .resources.patients import AsyncPatientsResourceWithRawResponse

        return AsyncPatientsResourceWithRawResponse(self._client.patients)

    @cached_property
    def patients_by_external_id(self) -> patients_by_external_id.AsyncPatientsByExternalIDResourceWithRawResponse:
        from .resources.patients_by_external_id import AsyncPatientsByExternalIDResourceWithRawResponse

        return AsyncPatientsByExternalIDResourceWithRawResponse(self._client.patients_by_external_id)

    @cached_property
    def protocol_parsing(self) -> protocol_parsing.AsyncProtocolParsingResourceWithRawResponse:
        from .resources.protocol_parsing import AsyncProtocolParsingResourceWithRawResponse

        return AsyncProtocolParsingResourceWithRawResponse(self._client.protocol_parsing)

    @cached_property
    def matching_jobs(self) -> matching_jobs.AsyncMatchingJobsResourceWithRawResponse:
        from .resources.matching_jobs import AsyncMatchingJobsResourceWithRawResponse

        return AsyncMatchingJobsResourceWithRawResponse(self._client.matching_jobs)

    @cached_property
    def custom_searches(self) -> custom_searches.AsyncCustomSearchesResourceWithRawResponse:
        from .resources.custom_searches import AsyncCustomSearchesResourceWithRawResponse

        return AsyncCustomSearchesResourceWithRawResponse(self._client.custom_searches)

    @cached_property
    def custom_criteria(self) -> custom_criteria.AsyncCustomCriteriaResourceWithRawResponse:
        from .resources.custom_criteria import AsyncCustomCriteriaResourceWithRawResponse

        return AsyncCustomCriteriaResourceWithRawResponse(self._client.custom_criteria)

    @cached_property
    def criteria(self) -> criteria.AsyncCriteriaResourceWithRawResponse:
        from .resources.criteria import AsyncCriteriaResourceWithRawResponse

        return AsyncCriteriaResourceWithRawResponse(self._client.criteria)

    @cached_property
    def appointments(self) -> appointments.AsyncAppointmentsResourceWithRawResponse:
        from .resources.appointments import AsyncAppointmentsResourceWithRawResponse

        return AsyncAppointmentsResourceWithRawResponse(self._client.appointments)

    @cached_property
    def sites(self) -> sites.AsyncSitesResourceWithRawResponse:
        from .resources.sites import AsyncSitesResourceWithRawResponse

        return AsyncSitesResourceWithRawResponse(self._client.sites)

    @cached_property
    def crio(self) -> crio.AsyncCrioResourceWithRawResponse:
        from .resources.crio import AsyncCrioResourceWithRawResponse

        return AsyncCrioResourceWithRawResponse(self._client.crio)

    @cached_property
    def health(self) -> health.AsyncHealthResourceWithRawResponse:
        from .resources.health import AsyncHealthResourceWithRawResponse

        return AsyncHealthResourceWithRawResponse(self._client.health)

    @cached_property
    def system(self) -> system.AsyncSystemResourceWithRawResponse:
        from .resources.system import AsyncSystemResourceWithRawResponse

        return AsyncSystemResourceWithRawResponse(self._client.system)

    @cached_property
    def dashboards(self) -> dashboards.AsyncDashboardsResourceWithRawResponse:
        from .resources.dashboards import AsyncDashboardsResourceWithRawResponse

        return AsyncDashboardsResourceWithRawResponse(self._client.dashboards)

    @cached_property
    def protocols(self) -> protocols.AsyncProtocolsResourceWithRawResponse:
        from .resources.protocols import AsyncProtocolsResourceWithRawResponse

        return AsyncProtocolsResourceWithRawResponse(self._client.protocols)

    @cached_property
    def export_jobs(self) -> export_jobs.AsyncExportJobsResourceWithRawResponse:
        from .resources.export_jobs import AsyncExportJobsResourceWithRawResponse

        return AsyncExportJobsResourceWithRawResponse(self._client.export_jobs)

    @cached_property
    def external(self) -> external.AsyncExternalResourceWithRawResponse:
        from .resources.external import AsyncExternalResourceWithRawResponse

        return AsyncExternalResourceWithRawResponse(self._client.external)

    @cached_property
    def outreach(self) -> outreach.AsyncOutreachResourceWithRawResponse:
        from .resources.outreach import AsyncOutreachResourceWithRawResponse

        return AsyncOutreachResourceWithRawResponse(self._client.outreach)

    @cached_property
    def webhooks(self) -> webhooks.AsyncWebhooksResourceWithRawResponse:
        from .resources.webhooks import AsyncWebhooksResourceWithRawResponse

        return AsyncWebhooksResourceWithRawResponse(self._client.webhooks)

    @cached_property
    def candidates(self) -> candidates.AsyncCandidatesResourceWithRawResponse:
        from .resources.candidates import AsyncCandidatesResourceWithRawResponse

        return AsyncCandidatesResourceWithRawResponse(self._client.candidates)

    @cached_property
    def workflows(self) -> workflows.AsyncWorkflowsResourceWithRawResponse:
        from .resources.workflows import AsyncWorkflowsResourceWithRawResponse

        return AsyncWorkflowsResourceWithRawResponse(self._client.workflows)

    @cached_property
    def clinical_conductor(self) -> clinical_conductor.AsyncClinicalConductorResourceWithRawResponse:
        from .resources.clinical_conductor import AsyncClinicalConductorResourceWithRawResponse

        return AsyncClinicalConductorResourceWithRawResponse(self._client.clinical_conductor)

    @cached_property
    def facebook(self) -> facebook.AsyncFacebookResourceWithRawResponse:
        from .resources.facebook import AsyncFacebookResourceWithRawResponse

        return AsyncFacebookResourceWithRawResponse(self._client.facebook)

    @cached_property
    def readiness(self) -> readiness.AsyncReadinessResourceWithRawResponse:
        from .resources.readiness import AsyncReadinessResourceWithRawResponse

        return AsyncReadinessResourceWithRawResponse(self._client.readiness)

    @cached_property
    def landing_pages(self) -> landing_pages.AsyncLandingPagesResourceWithRawResponse:
        from .resources.landing_pages import AsyncLandingPagesResourceWithRawResponse

        return AsyncLandingPagesResourceWithRawResponse(self._client.landing_pages)

    @cached_property
    def scheduling(self) -> scheduling.AsyncSchedulingResourceWithRawResponse:
        from .resources.scheduling import AsyncSchedulingResourceWithRawResponse

        return AsyncSchedulingResourceWithRawResponse(self._client.scheduling)


class WebRecruitmentSDKWithStreamedResponse:
    _client: WebRecruitmentSDK

    def __init__(self, client: WebRecruitmentSDK) -> None:
        self._client = client

    @cached_property
    def auth(self) -> auth.AuthResourceWithStreamingResponse:
        from .resources.auth import AuthResourceWithStreamingResponse

        return AuthResourceWithStreamingResponse(self._client.auth)

    @cached_property
    def admin(self) -> admin.AdminResourceWithStreamingResponse:
        from .resources.admin import AdminResourceWithStreamingResponse

        return AdminResourceWithStreamingResponse(self._client.admin)

    @cached_property
    def patients(self) -> patients.PatientsResourceWithStreamingResponse:
        from .resources.patients import PatientsResourceWithStreamingResponse

        return PatientsResourceWithStreamingResponse(self._client.patients)

    @cached_property
    def patients_by_external_id(self) -> patients_by_external_id.PatientsByExternalIDResourceWithStreamingResponse:
        from .resources.patients_by_external_id import PatientsByExternalIDResourceWithStreamingResponse

        return PatientsByExternalIDResourceWithStreamingResponse(self._client.patients_by_external_id)

    @cached_property
    def protocol_parsing(self) -> protocol_parsing.ProtocolParsingResourceWithStreamingResponse:
        from .resources.protocol_parsing import ProtocolParsingResourceWithStreamingResponse

        return ProtocolParsingResourceWithStreamingResponse(self._client.protocol_parsing)

    @cached_property
    def matching_jobs(self) -> matching_jobs.MatchingJobsResourceWithStreamingResponse:
        from .resources.matching_jobs import MatchingJobsResourceWithStreamingResponse

        return MatchingJobsResourceWithStreamingResponse(self._client.matching_jobs)

    @cached_property
    def custom_searches(self) -> custom_searches.CustomSearchesResourceWithStreamingResponse:
        from .resources.custom_searches import CustomSearchesResourceWithStreamingResponse

        return CustomSearchesResourceWithStreamingResponse(self._client.custom_searches)

    @cached_property
    def custom_criteria(self) -> custom_criteria.CustomCriteriaResourceWithStreamingResponse:
        from .resources.custom_criteria import CustomCriteriaResourceWithStreamingResponse

        return CustomCriteriaResourceWithStreamingResponse(self._client.custom_criteria)

    @cached_property
    def criteria(self) -> criteria.CriteriaResourceWithStreamingResponse:
        from .resources.criteria import CriteriaResourceWithStreamingResponse

        return CriteriaResourceWithStreamingResponse(self._client.criteria)

    @cached_property
    def appointments(self) -> appointments.AppointmentsResourceWithStreamingResponse:
        from .resources.appointments import AppointmentsResourceWithStreamingResponse

        return AppointmentsResourceWithStreamingResponse(self._client.appointments)

    @cached_property
    def sites(self) -> sites.SitesResourceWithStreamingResponse:
        from .resources.sites import SitesResourceWithStreamingResponse

        return SitesResourceWithStreamingResponse(self._client.sites)

    @cached_property
    def crio(self) -> crio.CrioResourceWithStreamingResponse:
        from .resources.crio import CrioResourceWithStreamingResponse

        return CrioResourceWithStreamingResponse(self._client.crio)

    @cached_property
    def health(self) -> health.HealthResourceWithStreamingResponse:
        from .resources.health import HealthResourceWithStreamingResponse

        return HealthResourceWithStreamingResponse(self._client.health)

    @cached_property
    def system(self) -> system.SystemResourceWithStreamingResponse:
        from .resources.system import SystemResourceWithStreamingResponse

        return SystemResourceWithStreamingResponse(self._client.system)

    @cached_property
    def dashboards(self) -> dashboards.DashboardsResourceWithStreamingResponse:
        from .resources.dashboards import DashboardsResourceWithStreamingResponse

        return DashboardsResourceWithStreamingResponse(self._client.dashboards)

    @cached_property
    def protocols(self) -> protocols.ProtocolsResourceWithStreamingResponse:
        from .resources.protocols import ProtocolsResourceWithStreamingResponse

        return ProtocolsResourceWithStreamingResponse(self._client.protocols)

    @cached_property
    def export_jobs(self) -> export_jobs.ExportJobsResourceWithStreamingResponse:
        from .resources.export_jobs import ExportJobsResourceWithStreamingResponse

        return ExportJobsResourceWithStreamingResponse(self._client.export_jobs)

    @cached_property
    def external(self) -> external.ExternalResourceWithStreamingResponse:
        from .resources.external import ExternalResourceWithStreamingResponse

        return ExternalResourceWithStreamingResponse(self._client.external)

    @cached_property
    def outreach(self) -> outreach.OutreachResourceWithStreamingResponse:
        from .resources.outreach import OutreachResourceWithStreamingResponse

        return OutreachResourceWithStreamingResponse(self._client.outreach)

    @cached_property
    def webhooks(self) -> webhooks.WebhooksResourceWithStreamingResponse:
        from .resources.webhooks import WebhooksResourceWithStreamingResponse

        return WebhooksResourceWithStreamingResponse(self._client.webhooks)

    @cached_property
    def candidates(self) -> candidates.CandidatesResourceWithStreamingResponse:
        from .resources.candidates import CandidatesResourceWithStreamingResponse

        return CandidatesResourceWithStreamingResponse(self._client.candidates)

    @cached_property
    def workflows(self) -> workflows.WorkflowsResourceWithStreamingResponse:
        from .resources.workflows import WorkflowsResourceWithStreamingResponse

        return WorkflowsResourceWithStreamingResponse(self._client.workflows)

    @cached_property
    def clinical_conductor(self) -> clinical_conductor.ClinicalConductorResourceWithStreamingResponse:
        from .resources.clinical_conductor import ClinicalConductorResourceWithStreamingResponse

        return ClinicalConductorResourceWithStreamingResponse(self._client.clinical_conductor)

    @cached_property
    def facebook(self) -> facebook.FacebookResourceWithStreamingResponse:
        from .resources.facebook import FacebookResourceWithStreamingResponse

        return FacebookResourceWithStreamingResponse(self._client.facebook)

    @cached_property
    def readiness(self) -> readiness.ReadinessResourceWithStreamingResponse:
        from .resources.readiness import ReadinessResourceWithStreamingResponse

        return ReadinessResourceWithStreamingResponse(self._client.readiness)

    @cached_property
    def landing_pages(self) -> landing_pages.LandingPagesResourceWithStreamingResponse:
        from .resources.landing_pages import LandingPagesResourceWithStreamingResponse

        return LandingPagesResourceWithStreamingResponse(self._client.landing_pages)

    @cached_property
    def scheduling(self) -> scheduling.SchedulingResourceWithStreamingResponse:
        from .resources.scheduling import SchedulingResourceWithStreamingResponse

        return SchedulingResourceWithStreamingResponse(self._client.scheduling)


class AsyncWebRecruitmentSDKWithStreamedResponse:
    _client: AsyncWebRecruitmentSDK

    def __init__(self, client: AsyncWebRecruitmentSDK) -> None:
        self._client = client

    @cached_property
    def auth(self) -> auth.AsyncAuthResourceWithStreamingResponse:
        from .resources.auth import AsyncAuthResourceWithStreamingResponse

        return AsyncAuthResourceWithStreamingResponse(self._client.auth)

    @cached_property
    def admin(self) -> admin.AsyncAdminResourceWithStreamingResponse:
        from .resources.admin import AsyncAdminResourceWithStreamingResponse

        return AsyncAdminResourceWithStreamingResponse(self._client.admin)

    @cached_property
    def patients(self) -> patients.AsyncPatientsResourceWithStreamingResponse:
        from .resources.patients import AsyncPatientsResourceWithStreamingResponse

        return AsyncPatientsResourceWithStreamingResponse(self._client.patients)

    @cached_property
    def patients_by_external_id(self) -> patients_by_external_id.AsyncPatientsByExternalIDResourceWithStreamingResponse:
        from .resources.patients_by_external_id import AsyncPatientsByExternalIDResourceWithStreamingResponse

        return AsyncPatientsByExternalIDResourceWithStreamingResponse(self._client.patients_by_external_id)

    @cached_property
    def protocol_parsing(self) -> protocol_parsing.AsyncProtocolParsingResourceWithStreamingResponse:
        from .resources.protocol_parsing import AsyncProtocolParsingResourceWithStreamingResponse

        return AsyncProtocolParsingResourceWithStreamingResponse(self._client.protocol_parsing)

    @cached_property
    def matching_jobs(self) -> matching_jobs.AsyncMatchingJobsResourceWithStreamingResponse:
        from .resources.matching_jobs import AsyncMatchingJobsResourceWithStreamingResponse

        return AsyncMatchingJobsResourceWithStreamingResponse(self._client.matching_jobs)

    @cached_property
    def custom_searches(self) -> custom_searches.AsyncCustomSearchesResourceWithStreamingResponse:
        from .resources.custom_searches import AsyncCustomSearchesResourceWithStreamingResponse

        return AsyncCustomSearchesResourceWithStreamingResponse(self._client.custom_searches)

    @cached_property
    def custom_criteria(self) -> custom_criteria.AsyncCustomCriteriaResourceWithStreamingResponse:
        from .resources.custom_criteria import AsyncCustomCriteriaResourceWithStreamingResponse

        return AsyncCustomCriteriaResourceWithStreamingResponse(self._client.custom_criteria)

    @cached_property
    def criteria(self) -> criteria.AsyncCriteriaResourceWithStreamingResponse:
        from .resources.criteria import AsyncCriteriaResourceWithStreamingResponse

        return AsyncCriteriaResourceWithStreamingResponse(self._client.criteria)

    @cached_property
    def appointments(self) -> appointments.AsyncAppointmentsResourceWithStreamingResponse:
        from .resources.appointments import AsyncAppointmentsResourceWithStreamingResponse

        return AsyncAppointmentsResourceWithStreamingResponse(self._client.appointments)

    @cached_property
    def sites(self) -> sites.AsyncSitesResourceWithStreamingResponse:
        from .resources.sites import AsyncSitesResourceWithStreamingResponse

        return AsyncSitesResourceWithStreamingResponse(self._client.sites)

    @cached_property
    def crio(self) -> crio.AsyncCrioResourceWithStreamingResponse:
        from .resources.crio import AsyncCrioResourceWithStreamingResponse

        return AsyncCrioResourceWithStreamingResponse(self._client.crio)

    @cached_property
    def health(self) -> health.AsyncHealthResourceWithStreamingResponse:
        from .resources.health import AsyncHealthResourceWithStreamingResponse

        return AsyncHealthResourceWithStreamingResponse(self._client.health)

    @cached_property
    def system(self) -> system.AsyncSystemResourceWithStreamingResponse:
        from .resources.system import AsyncSystemResourceWithStreamingResponse

        return AsyncSystemResourceWithStreamingResponse(self._client.system)

    @cached_property
    def dashboards(self) -> dashboards.AsyncDashboardsResourceWithStreamingResponse:
        from .resources.dashboards import AsyncDashboardsResourceWithStreamingResponse

        return AsyncDashboardsResourceWithStreamingResponse(self._client.dashboards)

    @cached_property
    def protocols(self) -> protocols.AsyncProtocolsResourceWithStreamingResponse:
        from .resources.protocols import AsyncProtocolsResourceWithStreamingResponse

        return AsyncProtocolsResourceWithStreamingResponse(self._client.protocols)

    @cached_property
    def export_jobs(self) -> export_jobs.AsyncExportJobsResourceWithStreamingResponse:
        from .resources.export_jobs import AsyncExportJobsResourceWithStreamingResponse

        return AsyncExportJobsResourceWithStreamingResponse(self._client.export_jobs)

    @cached_property
    def external(self) -> external.AsyncExternalResourceWithStreamingResponse:
        from .resources.external import AsyncExternalResourceWithStreamingResponse

        return AsyncExternalResourceWithStreamingResponse(self._client.external)

    @cached_property
    def outreach(self) -> outreach.AsyncOutreachResourceWithStreamingResponse:
        from .resources.outreach import AsyncOutreachResourceWithStreamingResponse

        return AsyncOutreachResourceWithStreamingResponse(self._client.outreach)

    @cached_property
    def webhooks(self) -> webhooks.AsyncWebhooksResourceWithStreamingResponse:
        from .resources.webhooks import AsyncWebhooksResourceWithStreamingResponse

        return AsyncWebhooksResourceWithStreamingResponse(self._client.webhooks)

    @cached_property
    def candidates(self) -> candidates.AsyncCandidatesResourceWithStreamingResponse:
        from .resources.candidates import AsyncCandidatesResourceWithStreamingResponse

        return AsyncCandidatesResourceWithStreamingResponse(self._client.candidates)

    @cached_property
    def workflows(self) -> workflows.AsyncWorkflowsResourceWithStreamingResponse:
        from .resources.workflows import AsyncWorkflowsResourceWithStreamingResponse

        return AsyncWorkflowsResourceWithStreamingResponse(self._client.workflows)

    @cached_property
    def clinical_conductor(self) -> clinical_conductor.AsyncClinicalConductorResourceWithStreamingResponse:
        from .resources.clinical_conductor import AsyncClinicalConductorResourceWithStreamingResponse

        return AsyncClinicalConductorResourceWithStreamingResponse(self._client.clinical_conductor)

    @cached_property
    def facebook(self) -> facebook.AsyncFacebookResourceWithStreamingResponse:
        from .resources.facebook import AsyncFacebookResourceWithStreamingResponse

        return AsyncFacebookResourceWithStreamingResponse(self._client.facebook)

    @cached_property
    def readiness(self) -> readiness.AsyncReadinessResourceWithStreamingResponse:
        from .resources.readiness import AsyncReadinessResourceWithStreamingResponse

        return AsyncReadinessResourceWithStreamingResponse(self._client.readiness)

    @cached_property
    def landing_pages(self) -> landing_pages.AsyncLandingPagesResourceWithStreamingResponse:
        from .resources.landing_pages import AsyncLandingPagesResourceWithStreamingResponse

        return AsyncLandingPagesResourceWithStreamingResponse(self._client.landing_pages)

    @cached_property
    def scheduling(self) -> scheduling.AsyncSchedulingResourceWithStreamingResponse:
        from .resources.scheduling import AsyncSchedulingResourceWithStreamingResponse

        return AsyncSchedulingResourceWithStreamingResponse(self._client.scheduling)


Client = WebRecruitmentSDK

AsyncClient = AsyncWebRecruitmentSDK
