# Auth

Types:

```python
from web_recruitment_sdk.types import Authorization, Role, AuthListRolesResponse
```

Methods:

- <code title="get /auth/roles">client.auth.<a href="./src/web_recruitment_sdk/resources/auth.py">list_roles</a>() -> <a href="./src/web_recruitment_sdk/types/auth_list_roles_response.py">AuthListRolesResponse</a></code>
- <code title="patch /auth/users/{user_id}">client.auth.<a href="./src/web_recruitment_sdk/resources/auth.py">update_user_authorization</a>(user_id, \*\*<a href="src/web_recruitment_sdk/types/auth_update_user_authorization_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/authorization.py">Authorization</a></code>

# Admin

Types:

```python
from web_recruitment_sdk.types import AdminListAccountsResponse
```

Methods:

- <code title="get /admin/accounts">client.admin.<a href="./src/web_recruitment_sdk/resources/admin/admin.py">list_accounts</a>() -> <a href="./src/web_recruitment_sdk/types/admin_list_accounts_response.py">AdminListAccountsResponse</a></code>

## Users

Types:

```python
from web_recruitment_sdk.types.admin import UserWithAccount, UserListResponse
```

Methods:

- <code title="get /admin/users/{user_id}">client.admin.users.<a href="./src/web_recruitment_sdk/resources/admin/users.py">retrieve</a>(user_id) -> <a href="./src/web_recruitment_sdk/types/admin/user_with_account.py">UserWithAccount</a></code>
- <code title="get /admin/users">client.admin.users.<a href="./src/web_recruitment_sdk/resources/admin/users.py">list</a>(\*\*<a href="src/web_recruitment_sdk/types/admin/user_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/admin/user_list_response.py">UserListResponse</a></code>
- <code title="delete /admin/users/{user_id}">client.admin.users.<a href="./src/web_recruitment_sdk/resources/admin/users.py">delete</a>(user_id) -> None</code>
- <code title="post /admin/users">client.admin.users.<a href="./src/web_recruitment_sdk/resources/admin/users.py">invite</a>(\*\*<a href="src/web_recruitment_sdk/types/admin/user_invite_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/admin/user_with_account.py">UserWithAccount</a></code>
- <code title="get /admin/users/me">client.admin.users.<a href="./src/web_recruitment_sdk/resources/admin/users.py">retrieve_current</a>() -> <a href="./src/web_recruitment_sdk/types/admin/user_with_account.py">UserWithAccount</a></code>
- <code title="patch /admin/users/me/tenant">client.admin.users.<a href="./src/web_recruitment_sdk/resources/admin/users.py">update_tenant</a>(\*\*<a href="src/web_recruitment_sdk/types/admin/user_update_tenant_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/admin/user_with_account.py">UserWithAccount</a></code>

## Account

Types:

```python
from web_recruitment_sdk.types.admin import AccountRetrieveResponse, AccountUpdateResponse
```

Methods:

- <code title="get /admin/account/{account_id}">client.admin.account.<a href="./src/web_recruitment_sdk/resources/admin/account.py">retrieve</a>(account_id) -> <a href="./src/web_recruitment_sdk/types/admin/account_retrieve_response.py">AccountRetrieveResponse</a></code>
- <code title="patch /admin/account/{account_id}">client.admin.account.<a href="./src/web_recruitment_sdk/resources/admin/account.py">update</a>(account_id, \*\*<a href="src/web_recruitment_sdk/types/admin/account_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/admin/account_update_response.py">AccountUpdateResponse</a></code>

## Facebook

### Configs

Types:

```python
from web_recruitment_sdk.types.admin.facebook import (
    ConfigCreateResponse,
    ConfigRetrieveResponse,
    ConfigUpdateResponse,
    ConfigListResponse,
)
```

Methods:

- <code title="post /admin/facebook/configs">client.admin.facebook.configs.<a href="./src/web_recruitment_sdk/resources/admin/facebook/configs.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/admin/facebook/config_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/admin/facebook/config_create_response.py">ConfigCreateResponse</a></code>
- <code title="get /admin/facebook/configs/{config_id}">client.admin.facebook.configs.<a href="./src/web_recruitment_sdk/resources/admin/facebook/configs.py">retrieve</a>(config_id) -> <a href="./src/web_recruitment_sdk/types/admin/facebook/config_retrieve_response.py">ConfigRetrieveResponse</a></code>
- <code title="patch /admin/facebook/configs/{config_id}">client.admin.facebook.configs.<a href="./src/web_recruitment_sdk/resources/admin/facebook/configs.py">update</a>(config_id, \*\*<a href="src/web_recruitment_sdk/types/admin/facebook/config_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/admin/facebook/config_update_response.py">ConfigUpdateResponse</a></code>
- <code title="get /admin/facebook/configs">client.admin.facebook.configs.<a href="./src/web_recruitment_sdk/resources/admin/facebook/configs.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/admin/facebook/config_list_response.py">ConfigListResponse</a></code>
- <code title="delete /admin/facebook/configs/{config_id}">client.admin.facebook.configs.<a href="./src/web_recruitment_sdk/resources/admin/facebook/configs.py">delete</a>(config_id) -> None</code>

# Patients

Types:

```python
from web_recruitment_sdk.types import (
    PatientRead,
    PatientUpdate,
    PatientListResponse,
    PatientGetByProtocolResponse,
    PatientGetExportsResponse,
    PatientGetProtocolMatchesResponse,
)
```

Methods:

- <code title="get /patients/{patient_id}">client.patients.<a href="./src/web_recruitment_sdk/resources/patients/patients.py">retrieve</a>(patient_id) -> <a href="./src/web_recruitment_sdk/types/patient_read.py">PatientRead</a></code>
- <code title="patch /patients/{patient_id}">client.patients.<a href="./src/web_recruitment_sdk/resources/patients/patients.py">update</a>(patient_id, \*\*<a href="src/web_recruitment_sdk/types/patient_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/patient_read.py">PatientRead</a></code>
- <code title="get /patients">client.patients.<a href="./src/web_recruitment_sdk/resources/patients/patients.py">list</a>(\*\*<a href="src/web_recruitment_sdk/types/patient_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/patient_list_response.py">PatientListResponse</a></code>
- <code title="get /patients/protocol/{protocol_id}">client.patients.<a href="./src/web_recruitment_sdk/resources/patients/patients.py">get_by_protocol</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/patient_get_by_protocol_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/patient_get_by_protocol_response.py">PatientGetByProtocolResponse</a></code>
- <code title="get /patients/{patient_id}/exports">client.patients.<a href="./src/web_recruitment_sdk/resources/patients/patients.py">get_exports</a>(patient_id) -> <a href="./src/web_recruitment_sdk/types/patient_get_exports_response.py">PatientGetExportsResponse</a></code>
- <code title="get /patients/{patient_id}/protocol-matches">client.patients.<a href="./src/web_recruitment_sdk/resources/patients/patients.py">get_protocol_matches</a>(patient_id) -> <a href="./src/web_recruitment_sdk/types/patient_get_protocol_matches_response.py">PatientGetProtocolMatchesResponse</a></code>

## Notes

Types:

```python
from web_recruitment_sdk.types.patients import NoteRead, NoteListResponse
```

Methods:

- <code title="post /patients/{patient_id}/notes">client.patients.notes.<a href="./src/web_recruitment_sdk/resources/patients/notes.py">create</a>(path_patient_id, \*\*<a href="src/web_recruitment_sdk/types/patients/note_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/patients/note_read.py">NoteRead</a></code>
- <code title="get /patients/{patient_id}/notes">client.patients.notes.<a href="./src/web_recruitment_sdk/resources/patients/notes.py">list</a>(patient_id) -> <a href="./src/web_recruitment_sdk/types/patients/note_list_response.py">NoteListResponse</a></code>
- <code title="delete /patients/{patient_id}/notes/{note_id}">client.patients.notes.<a href="./src/web_recruitment_sdk/resources/patients/notes.py">delete</a>(note_id, \*, patient_id) -> None</code>

# PatientsByExternalID

Methods:

- <code title="get /patients_by_external_id/{external_id}">client.patients_by_external_id.<a href="./src/web_recruitment_sdk/resources/patients_by_external_id.py">retrieve</a>(external_id) -> <a href="./src/web_recruitment_sdk/types/patient_read.py">PatientRead</a></code>

# ProtocolParsing

Types:

```python
from web_recruitment_sdk.types import (
    ProtocolRead,
    ProtocolStatus,
    ProtocolParsingGetStatusesResponse,
)
```

Methods:

- <code title="get /protocol-parsing">client.protocol_parsing.<a href="./src/web_recruitment_sdk/resources/protocol_parsing/protocol_parsing.py">get_statuses</a>(\*\*<a href="src/web_recruitment_sdk/types/protocol_parsing_get_statuses_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocol_parsing_get_statuses_response.py">ProtocolParsingGetStatusesResponse</a></code>

## V2

Methods:

- <code title="post /protocol-parsing-v2">client.protocol_parsing.v2.<a href="./src/web_recruitment_sdk/resources/protocol_parsing/v2.py">upload</a>(\*\*<a href="src/web_recruitment_sdk/types/protocol_parsing/v2_upload_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocol_read.py">ProtocolRead</a></code>

# MatchingJobs

Methods:

- <code title="post /matching_jobs/protocols/{protocol_id}">client.matching_jobs.<a href="./src/web_recruitment_sdk/resources/matching_jobs.py">start_protocol_matching_job</a>(protocol_id) -> <a href="./src/web_recruitment_sdk/types/protocol_read.py">ProtocolRead</a></code>

# CustomSearches

Types:

```python
from web_recruitment_sdk.types import (
    CustomSearchRead,
    FunnelStats,
    PatientMatch,
    CustomSearchListResponse,
    CustomSearchGetCriteriaInstancesResponse,
    CustomSearchRetrieveMatchFacetsResponse,
    CustomSearchRetrieveMatchesResponse,
    CustomSearchRetrieveSitesResponse,
)
```

Methods:

- <code title="post /custom-searches">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/custom_search_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_search_read.py">CustomSearchRead</a></code>
- <code title="get /custom-searches/{custom_search_id}">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">retrieve</a>(custom_search_id) -> <a href="./src/web_recruitment_sdk/types/custom_search_read.py">CustomSearchRead</a></code>
- <code title="patch /custom-searches/{custom_search_id}">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">update</a>(custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_search_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_search_read.py">CustomSearchRead</a></code>
- <code title="get /custom-searches">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/custom_search_list_response.py">CustomSearchListResponse</a></code>
- <code title="delete /custom-searches/{custom_search_id}">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">delete</a>(custom_search_id) -> None</code>
- <code title="get /custom-searches/{custom_search_id}/criteria_instances">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">get_criteria_instances</a>(custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_search_get_criteria_instances_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_search_get_criteria_instances_response.py">CustomSearchGetCriteriaInstancesResponse</a></code>
- <code title="get /custom-searches/{custom_search_id}/funnel">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">retrieve_funnel</a>(custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_search_retrieve_funnel_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/funnel_stats.py">FunnelStats</a></code>
- <code title="get /custom-searches/{custom_search_id}/matches/facets">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">retrieve_match_facets</a>(custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_search_retrieve_match_facets_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_search_retrieve_match_facets_response.py">CustomSearchRetrieveMatchFacetsResponse</a></code>
- <code title="get /custom-searches/{custom_search_id}/matches">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">retrieve_matches</a>(custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_search_retrieve_matches_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_search_retrieve_matches_response.py">CustomSearchRetrieveMatchesResponse</a></code>
- <code title="get /custom-searches/{custom_search_id}/sites">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">retrieve_sites</a>(custom_search_id) -> <a href="./src/web_recruitment_sdk/types/custom_search_retrieve_sites_response.py">CustomSearchRetrieveSitesResponse</a></code>
- <code title="post /custom-searches/{custom_search_id}/ready">client.custom_searches.<a href="./src/web_recruitment_sdk/resources/custom_searches/custom_searches.py">set_ready</a>(custom_search_id) -> <a href="./src/web_recruitment_sdk/types/custom_search_read.py">CustomSearchRead</a></code>

## Criteria

Types:

```python
from web_recruitment_sdk.types.custom_searches import (
    CriteriaCreate,
    CriteriaRead,
    CriteriaStatus,
    CriterionRetrieveResponse,
    CriterionGetMatchingProgressResponse,
)
```

Methods:

- <code title="post /custom-searches/{custom_search_id}/criteria">client.custom_searches.criteria.<a href="./src/web_recruitment_sdk/resources/custom_searches/criteria.py">create</a>(path_custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_searches/criterion_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>
- <code title="get /custom-searches/{custom_search_id}/criteria">client.custom_searches.criteria.<a href="./src/web_recruitment_sdk/resources/custom_searches/criteria.py">retrieve</a>(custom_search_id) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criterion_retrieve_response.py">CriterionRetrieveResponse</a></code>
- <code title="put /custom-searches/{custom_search_id}/criteria/{criterion_id}">client.custom_searches.criteria.<a href="./src/web_recruitment_sdk/resources/custom_searches/criteria.py">update</a>(criterion_id, \*, path_custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_searches/criterion_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>
- <code title="delete /custom-searches/{custom_search_id}/criteria/{criterion_id}">client.custom_searches.criteria.<a href="./src/web_recruitment_sdk/resources/custom_searches/criteria.py">delete</a>(criterion_id, \*, custom_search_id) -> None</code>
- <code title="get /custom-searches/{custom_search_id}/criteria/matching-progress">client.custom_searches.criteria.<a href="./src/web_recruitment_sdk/resources/custom_searches/criteria.py">get_matching_progress</a>(custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_searches/criterion_get_matching_progress_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criterion_get_matching_progress_response.py">CriterionGetMatchingProgressResponse</a></code>
- <code title="put /custom-searches/{custom_search_id}/criteria/{criterion_id}/priority">client.custom_searches.criteria.<a href="./src/web_recruitment_sdk/resources/custom_searches/criteria.py">set_priority</a>(criterion_id, \*, custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_searches/criterion_set_priority_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>

## UserCriteria

Types:

```python
from web_recruitment_sdk.types.custom_searches import (
    UserProtocolCriteriaFilterUpdate,
    UserCriterionRetrieveResponse,
    UserCriterionUpdateResponse,
)
```

Methods:

- <code title="get /custom-searches/{custom_search_id}/user-criteria">client.custom_searches.user_criteria.<a href="./src/web_recruitment_sdk/resources/custom_searches/user_criteria.py">retrieve</a>(custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_searches/user_criterion_retrieve_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/user_criterion_retrieve_response.py">UserCriterionRetrieveResponse</a></code>
- <code title="put /custom-searches/{custom_search_id}/user-criteria">client.custom_searches.user_criteria.<a href="./src/web_recruitment_sdk/resources/custom_searches/user_criteria.py">update</a>(custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_searches/user_criterion_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/user_criterion_update_response.py">UserCriterionUpdateResponse</a></code>

## Patients

Types:

```python
from web_recruitment_sdk.types.custom_searches import PatientUpdateWorkflowTagResponse
```

Methods:

- <code title="put /custom-searches/{custom_search_id}/patients/{patient_id}/workflow-tag">client.custom_searches.patients.<a href="./src/web_recruitment_sdk/resources/custom_searches/patients.py">update_workflow_tag</a>(patient_id, \*, custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_searches/patient_update_workflow_tag_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/patient_update_workflow_tag_response.py">PatientUpdateWorkflowTagResponse</a></code>

## Documents

Types:

```python
from web_recruitment_sdk.types.custom_searches import DocumentRetrieveDownloadURLResponse
```

Methods:

- <code title="get /custom-searches/{custom_search_id}/documents/{document_metadata_id}/download-url">client.custom_searches.documents.<a href="./src/web_recruitment_sdk/resources/custom_searches/documents.py">retrieve_download_url</a>(document_metadata_id, \*, custom_search_id, \*\*<a href="src/web_recruitment_sdk/types/custom_searches/document_retrieve_download_url_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/document_retrieve_download_url_response.py">DocumentRetrieveDownloadURLResponse</a></code>

# CustomCriteria

Types:

```python
from web_recruitment_sdk.types import CriteriaType, CustomCriterionListResponse
```

Methods:

- <code title="get /custom-criteria">client.custom_criteria.<a href="./src/web_recruitment_sdk/resources/custom_criteria.py">list</a>(\*\*<a href="src/web_recruitment_sdk/types/custom_criterion_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_criterion_list_response.py">CustomCriterionListResponse</a></code>

# Criteria

Methods:

- <code title="post /criteria">client.criteria.<a href="./src/web_recruitment_sdk/resources/criteria.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/criterion_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>
- <code title="get /criteria/{criteria_id}">client.criteria.<a href="./src/web_recruitment_sdk/resources/criteria.py">retrieve</a>(criteria_id) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>
- <code title="put /criteria/{criterion_id}">client.criteria.<a href="./src/web_recruitment_sdk/resources/criteria.py">update</a>(criterion_id, \*\*<a href="src/web_recruitment_sdk/types/criterion_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>

# Appointments

Types:

```python
from web_recruitment_sdk.types import Appointment, AppointmentListResponse
```

Methods:

- <code title="get /appointments/{trially_appointment_id}">client.appointments.<a href="./src/web_recruitment_sdk/resources/appointments.py">retrieve</a>(trially_appointment_id) -> <a href="./src/web_recruitment_sdk/types/appointment.py">Appointment</a></code>
- <code title="get /appointments">client.appointments.<a href="./src/web_recruitment_sdk/resources/appointments.py">list</a>(\*\*<a href="src/web_recruitment_sdk/types/appointment_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/appointment_list_response.py">AppointmentListResponse</a></code>

# Sites

Types:

```python
from web_recruitment_sdk.types import SiteRead, SiteListResponse, SiteRetrieveContextResponse
```

Methods:

- <code title="post /sites">client.sites.<a href="./src/web_recruitment_sdk/resources/sites.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/site_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/site_read.py">SiteRead</a></code>
- <code title="get /sites/{site_id}">client.sites.<a href="./src/web_recruitment_sdk/resources/sites.py">retrieve</a>(site_id) -> <a href="./src/web_recruitment_sdk/types/site_read.py">SiteRead</a></code>
- <code title="patch /sites/{site_id}">client.sites.<a href="./src/web_recruitment_sdk/resources/sites.py">update</a>(site_id, \*\*<a href="src/web_recruitment_sdk/types/site_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/site_read.py">SiteRead</a></code>
- <code title="get /sites">client.sites.<a href="./src/web_recruitment_sdk/resources/sites.py">list</a>(\*\*<a href="src/web_recruitment_sdk/types/site_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/site_list_response.py">SiteListResponse</a></code>
- <code title="get /sites/{site_id}/context">client.sites.<a href="./src/web_recruitment_sdk/resources/sites.py">retrieve_context</a>(site_id) -> <a href="./src/web_recruitment_sdk/types/site_retrieve_context_response.py">Optional[SiteRetrieveContextResponse]</a></code>

# Crio

Types:

```python
from web_recruitment_sdk.types import CrioListSitesResponse
```

Methods:

- <code title="get /crio/sites">client.crio.<a href="./src/web_recruitment_sdk/resources/crio/crio.py">list_sites</a>(\*\*<a href="src/web_recruitment_sdk/types/crio_list_sites_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/crio_list_sites_response.py">CrioListSitesResponse</a></code>

## Clients

Types:

```python
from web_recruitment_sdk.types.crio import (
    ClientCreateResponse,
    ClientUpdateResponse,
    ClientListResponse,
)
```

Methods:

- <code title="post /crio/clients">client.crio.clients.<a href="./src/web_recruitment_sdk/resources/crio/clients.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/crio/client_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/crio/client_create_response.py">ClientCreateResponse</a></code>
- <code title="put /crio/clients/{client_id}">client.crio.clients.<a href="./src/web_recruitment_sdk/resources/crio/clients.py">update</a>(client_id, \*\*<a href="src/web_recruitment_sdk/types/crio/client_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/crio/client_update_response.py">ClientUpdateResponse</a></code>
- <code title="get /crio/clients">client.crio.clients.<a href="./src/web_recruitment_sdk/resources/crio/clients.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/crio/client_list_response.py">ClientListResponse</a></code>
- <code title="delete /crio/clients/{client_id}">client.crio.clients.<a href="./src/web_recruitment_sdk/resources/crio/clients.py">delete</a>(client_id) -> None</code>

# Health

Methods:

- <code title="get /health">client.health.<a href="./src/web_recruitment_sdk/resources/health.py">check</a>() -> object</code>

# System

Types:

```python
from web_recruitment_sdk.types import (
    CriteriaInstanceAnswer,
    CriteriaInstanceCreate,
    ExportStatus,
    SystemCreateCriteriaInstanceResponse,
    SystemCreateEntitySearchIndexResponse,
    SystemGetConnectionPoolStatusResponse,
    SystemGetPatientMatchDataResponse,
    SystemGetPatientMatchDataLabResultsResponse,
    SystemGetPatientMatchDataVitalsResponse,
    SystemPatchPatientExportResponse,
    SystemSearchEntitiesResponse,
)
```

Methods:

- <code title="post /system/{tenant_db_name}/patient-match-data/bulk-search">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">bulk_search_patient_match_data</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system_bulk_search_patient_match_data_params.py">params</a>) -> object</code>
- <code title="post /system/{tenant_db_name}/criteria_instances">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">create_criteria_instance</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system_create_criteria_instance_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system_create_criteria_instance_response.py">SystemCreateCriteriaInstanceResponse</a></code>
- <code title="post /system/{tenant_db_name}/entity-search/index">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">create_entity_search_index</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system_create_entity_search_index_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system_create_entity_search_index_response.py">SystemCreateEntitySearchIndexResponse</a></code>
- <code title="get /system/{db_name}/connection-pool-status">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">get_connection_pool_status</a>(db_name, \*\*<a href="src/web_recruitment_sdk/types/system_get_connection_pool_status_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system_get_connection_pool_status_response.py">SystemGetConnectionPoolStatusResponse</a></code>
- <code title="post /system/{tenant_db_name}/patient-match-data">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">get_patient_match_data</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system_get_patient_match_data_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system_get_patient_match_data_response.py">SystemGetPatientMatchDataResponse</a></code>
- <code title="post /system/{tenant_db_name}/patient-match-data/lab-results">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">get_patient_match_data_lab_results</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system_get_patient_match_data_lab_results_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system_get_patient_match_data_lab_results_response.py">SystemGetPatientMatchDataLabResultsResponse</a></code>
- <code title="post /system/{tenant_db_name}/patient-match-data/vitals">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">get_patient_match_data_vitals</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system_get_patient_match_data_vitals_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system_get_patient_match_data_vitals_response.py">SystemGetPatientMatchDataVitalsResponse</a></code>
- <code title="patch /system/{tenant_db_name}/patient-ctms-exports/{patient_ctms_export_id}">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">patch_patient_export</a>(patient_ctms_export_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system_patch_patient_export_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system_patch_patient_export_response.py">SystemPatchPatientExportResponse</a></code>
- <code title="post /system/{tenant_db_name}/entity-search">client.system.<a href="./src/web_recruitment_sdk/resources/system/system.py">search_entities</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system_search_entities_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system_search_entities_response.py">SystemSearchEntitiesResponse</a></code>

## Protocols

Types:

```python
from web_recruitment_sdk.types.system import ProtocolListResponse, ProtocolGetCriteriaResponse
```

Methods:

- <code title="get /system/{tenant_db_name}/protocols/{protocol_id}">client.system.protocols.<a href="./src/web_recruitment_sdk/resources/system/protocols/protocols.py">retrieve</a>(protocol_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/protocol_read.py">ProtocolRead</a></code>
- <code title="get /system/{tenant_db_name}/protocols">client.system.protocols.<a href="./src/web_recruitment_sdk/resources/system/protocols/protocols.py">list</a>(tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/protocol_list_response.py">ProtocolListResponse</a></code>
- <code title="get /system/{tenant_db_name}/protocols/{protocol_id}/criteria">client.system.protocols.<a href="./src/web_recruitment_sdk/resources/system/protocols/protocols.py">get_criteria</a>(protocol_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/protocol_get_criteria_response.py">ProtocolGetCriteriaResponse</a></code>
- <code title="post /system/{tenant_db_name}/protocols/refresh-patient-matches">client.system.protocols.<a href="./src/web_recruitment_sdk/resources/system/protocols/protocols.py">refresh_patient_matches</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/protocol_refresh_patient_matches_params.py">params</a>) -> object</code>

### MatchingJobs

Methods:

- <code title="post /system/{tenant_db_name}/protocols/{protocol_id}/matching_jobs">client.system.protocols.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/protocols/matching_jobs.py">create</a>(protocol_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/protocol_read.py">ProtocolRead</a></code>
- <code title="delete /system/{tenant_db_name}/protocols/{protocol_id}/matching_jobs">client.system.protocols.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/protocols/matching_jobs.py">delete</a>(protocol_id, \*, tenant_db_name) -> object</code>

## Criteria

Types:

```python
from web_recruitment_sdk.types.system import (
    CriterionListResponse,
    CriterionGetMatchingProgressResponse,
    CriterionGetPatientsToMatchResponse,
)
```

Methods:

- <code title="get /system/{tenant_db_name}/criteria">client.system.criteria.<a href="./src/web_recruitment_sdk/resources/system/criteria/criteria.py">list</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/criterion_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/criterion_list_response.py">CriterionListResponse</a></code>
- <code title="get /system/{tenant_db_name}/criteria/{criterion_id}/matching-progress">client.system.criteria.<a href="./src/web_recruitment_sdk/resources/system/criteria/criteria.py">get_matching_progress</a>(criterion_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/criterion_get_matching_progress_response.py">CriterionGetMatchingProgressResponse</a></code>
- <code title="get /system/{tenant_db_name}/criteria/{criteria_id}/patients-to-match">client.system.criteria.<a href="./src/web_recruitment_sdk/resources/system/criteria/criteria.py">get_patients_to_match</a>(criteria_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/criterion_get_patients_to_match_response.py">CriterionGetPatientsToMatchResponse</a></code>

### MatchingJobs

Methods:

- <code title="post /system/{tenant_db_name}/criteria/{criterion_id}/matching_jobs">client.system.criteria.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/criteria/matching_jobs.py">create</a>(criterion_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/criteria/matching_job_create_params.py">params</a>) -> object</code>
- <code title="delete /system/{tenant_db_name}/criteria/{criterion_id}/matching_jobs">client.system.criteria.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/criteria/matching_jobs.py">delete</a>(criterion_id, \*, tenant_db_name) -> object</code>

## Sites

Types:

```python
from web_recruitment_sdk.types.system import SiteCreate, SiteListResponse
```

Methods:

- <code title="post /system/{tenant_db_name}/sites">client.system.sites.<a href="./src/web_recruitment_sdk/resources/system/sites/sites.py">create</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/site_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/site_read.py">SiteRead</a></code>
- <code title="get /system/{tenant_db_name}/sites/{site_id}">client.system.sites.<a href="./src/web_recruitment_sdk/resources/system/sites/sites.py">retrieve</a>(site_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/site_read.py">SiteRead</a></code>
- <code title="patch /system/{tenant_db_name}/sites/{site_id}">client.system.sites.<a href="./src/web_recruitment_sdk/resources/system/sites/sites.py">update</a>(site_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/site_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/site_read.py">SiteRead</a></code>
- <code title="get /system/{tenant_db_name}/sites">client.system.sites.<a href="./src/web_recruitment_sdk/resources/system/sites/sites.py">list</a>(tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/site_list_response.py">SiteListResponse</a></code>
- <code title="delete /system/{tenant_db_name}/sites/{site_id}">client.system.sites.<a href="./src/web_recruitment_sdk/resources/system/sites/sites.py">delete</a>(site_id, \*, tenant_db_name) -> object</code>

### Trially

Types:

```python
from web_recruitment_sdk.types.system.sites import (
    TriallyGetActiveCustomSearchesResponse,
    TriallyGetActiveProtocolsResponse,
)
```

Methods:

- <code title="get /system/{tenant_db_name}/sites/trially/{trially_site_id}/custom-searches">client.system.sites.trially.<a href="./src/web_recruitment_sdk/resources/system/sites/trially.py">get_active_custom_searches</a>(trially_site_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/sites/trially_get_active_custom_searches_response.py">TriallyGetActiveCustomSearchesResponse</a></code>
- <code title="get /system/{tenant_db_name}/sites/trially/{trially_site_id}/protocols">client.system.sites.trially.<a href="./src/web_recruitment_sdk/resources/system/sites/trially.py">get_active_protocols</a>(trially_site_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/sites/trially_get_active_protocols_response.py">TriallyGetActiveProtocolsResponse</a></code>

### Context

Types:

```python
from web_recruitment_sdk.types.system.sites import (
    ContextCreateResponse,
    ContextRetrieveResponse,
    ContextUpdateResponse,
)
```

Methods:

- <code title="post /system/{tenant_db_name}/sites/{site_id}/context">client.system.sites.context.<a href="./src/web_recruitment_sdk/resources/system/sites/context.py">create</a>(site_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/sites/context_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/sites/context_create_response.py">ContextCreateResponse</a></code>
- <code title="get /system/{tenant_db_name}/sites/{site_id}/context">client.system.sites.context.<a href="./src/web_recruitment_sdk/resources/system/sites/context.py">retrieve</a>(site_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/sites/context_retrieve_response.py">ContextRetrieveResponse</a></code>
- <code title="put /system/{tenant_db_name}/sites/{site_id}/context">client.system.sites.context.<a href="./src/web_recruitment_sdk/resources/system/sites/context.py">update</a>(site_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/sites/context_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/sites/context_update_response.py">ContextUpdateResponse</a></code>
- <code title="delete /system/{tenant_db_name}/sites/{site_id}/context">client.system.sites.context.<a href="./src/web_recruitment_sdk/resources/system/sites/context.py">delete</a>(site_id, \*, tenant_db_name) -> None</code>

## Patients

Types:

```python
from web_recruitment_sdk.types.system import PatientCreate
```

Methods:

- <code title="post /system/{tenant_db_name}/patients">client.system.patients.<a href="./src/web_recruitment_sdk/resources/system/patients/patients.py">create</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patient_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/patient_read.py">PatientRead</a></code>
- <code title="patch /system/{tenant_db_name}/patients/{patient_id}">client.system.patients.<a href="./src/web_recruitment_sdk/resources/system/patients/patients.py">update</a>(patient_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patient_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/patient_read.py">PatientRead</a></code>

### Bulk

Types:

```python
from web_recruitment_sdk.types.system.patients import BulkInsertResult, BulkDeleteResponse
```

Methods:

- <code title="delete /system/{tenant_db_name}/patients/bulk">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">delete</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_delete_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_delete_response.py">BulkDeleteResponse</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/appointments">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">create_appointments</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_create_appointments_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/allergies">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_allergies</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_allergies_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/conditions">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_conditions</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_conditions_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/patient_demographics">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_demographics</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_demographics_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/ehr_document_metadata">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_ehr_document_metadata</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_ehr_document_metadata_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/patient_entity">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_entity</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_entity_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/entity_search">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_entity_search</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_entity_search_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/patient_history">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_history</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_history_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/lab_results">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_lab_results</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_lab_results_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/medications">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_medications</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_medications_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/procedures">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_procedures</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_procedures_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/providers">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_providers</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_providers_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk/patient_vitals">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">update_vitals</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_update_vitals_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>
- <code title="put /system/{tenant_db_name}/patients/bulk">client.system.patients.bulk.<a href="./src/web_recruitment_sdk/resources/system/patients/bulk.py">upsert</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/patients/bulk_upsert_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>

## Appointments

Types:

```python
from web_recruitment_sdk.types.system import AppointmentListResponse
```

Methods:

- <code title="get /system/{tenant_db_name}/appointments">client.system.appointments.<a href="./src/web_recruitment_sdk/resources/system/appointments.py">list</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/appointment_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/appointment_list_response.py">AppointmentListResponse</a></code>
- <code title="delete /system/{tenant_db_name}/appointments/{trially_appointment_id}">client.system.appointments.<a href="./src/web_recruitment_sdk/resources/system/appointments.py">delete</a>(trially_appointment_id, \*, tenant_db_name) -> None</code>

## Bulk

Methods:

- <code title="put /system/{tenant_db_name}/bulk/criteria_instances">client.system.bulk.<a href="./src/web_recruitment_sdk/resources/system/bulk.py">update_criteria_instances</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/bulk_update_criteria_instances_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/patients/bulk_insert_result.py">BulkInsertResult</a></code>

## MatchingJobs

Types:

```python
from web_recruitment_sdk.types.system import ExternalJobStatus, MatchingJobRead, MatchingTaskRead
```

Methods:

- <code title="get /system/{tenant_db_name}/matching_jobs/{matching_job_id}">client.system.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/matching_jobs.py">retrieve</a>(matching_job_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/matching_job_read.py">MatchingJobRead</a></code>
- <code title="post /system/{tenant_db_name}/matching_jobs/{matching_job_id}/cancel">client.system.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/matching_jobs.py">cancel</a>(matching_job_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/matching_job_read.py">MatchingJobRead</a></code>
- <code title="post /system/{tenant_db_name}/matching_jobs/start_all">client.system.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/matching_jobs.py">start_all</a>(tenant_db_name) -> object</code>

## Cache

Methods:

- <code title="get /system/{tenant_db_name}/cache/clear">client.system.cache.<a href="./src/web_recruitment_sdk/resources/system/cache.py">clear</a>(tenant_db_name) -> object</code>

## CustomSearches

Types:

```python
from web_recruitment_sdk.types.system import (
    CustomSearchListResponse,
    CustomSearchRetrieveCriteriaResponse,
)
```

Methods:

- <code title="get /system/{tenant_db_name}/custom-searches">client.system.custom_searches.<a href="./src/web_recruitment_sdk/resources/system/custom_searches/custom_searches.py">list</a>(tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/custom_search_list_response.py">CustomSearchListResponse</a></code>
- <code title="post /system/{tenant_db_name}/custom-searches/refresh-patient-matches">client.system.custom_searches.<a href="./src/web_recruitment_sdk/resources/system/custom_searches/custom_searches.py">refresh_patient_matches</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/custom_search_refresh_patient_matches_params.py">params</a>) -> object</code>
- <code title="get /system/{tenant_db_name}/custom-searches/{custom_search_id}/criteria">client.system.custom_searches.<a href="./src/web_recruitment_sdk/resources/system/custom_searches/custom_searches.py">retrieve_criteria</a>(custom_search_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/custom_search_retrieve_criteria_response.py">CustomSearchRetrieveCriteriaResponse</a></code>

### MatchingJobs

Methods:

- <code title="post /system/{tenant_db_name}/custom-searches/{custom_search_id}/matching_jobs">client.system.custom_searches.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/custom_searches/matching_jobs.py">create</a>(custom_search_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/custom_search_read.py">CustomSearchRead</a></code>
- <code title="delete /system/{tenant_db_name}/custom-searches/{custom_search_id}/matching_jobs">client.system.custom_searches.matching_jobs.<a href="./src/web_recruitment_sdk/resources/system/custom_searches/matching_jobs.py">delete</a>(custom_search_id, \*, tenant_db_name) -> object</code>

## Outreach

### Attempts

Types:

```python
from web_recruitment_sdk.types.system.outreach import AttemptCreateOutreachActionResponse
```

Methods:

- <code title="post /system/{tenant_db_name}/outreach/attempts/{attempt_id}/actions">client.system.outreach.attempts.<a href="./src/web_recruitment_sdk/resources/system/outreach/attempts.py">create_outreach_action</a>(path_attempt_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/outreach/attempt_create_outreach_action_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/outreach/attempt_create_outreach_action_response.py">AttemptCreateOutreachActionResponse</a></code>

### Attempt

Types:

```python
from web_recruitment_sdk.types.system.outreach import AttemptCompleteOutreachAttemptResponse
```

Methods:

- <code title="post /system/{tenant_db_name}/outreach/attempt/{attempt_id}/complete">client.system.outreach.attempt.<a href="./src/web_recruitment_sdk/resources/system/outreach/attempt.py">complete_outreach_attempt</a>(attempt_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/outreach/attempt_complete_outreach_attempt_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/outreach/attempt_complete_outreach_attempt_response.py">AttemptCompleteOutreachAttemptResponse</a></code>

### BookingLink

Types:

```python
from web_recruitment_sdk.types.system.outreach import BookingLinkClickedResponse
```

Methods:

- <code title="post /system/{tenant_db_name}/outreach/booking_link/clicked">client.system.outreach.booking_link.<a href="./src/web_recruitment_sdk/resources/system/outreach/booking_link.py">clicked</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/outreach/booking_link_clicked_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/outreach/booking_link_clicked_response.py">BookingLinkClickedResponse</a></code>

## LabResults

Types:

```python
from web_recruitment_sdk.types.system import LabResultSearchResponse
```

Methods:

- <code title="post /system/{tenant_db_name}/lab-results/search">client.system.lab_results.<a href="./src/web_recruitment_sdk/resources/system/lab_results.py">search</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/lab_result_search_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/lab_result_search_response.py">LabResultSearchResponse</a></code>

## Concurrency

Types:

```python
from web_recruitment_sdk.types.system import (
    ConcurrencyAcquireResponse,
    ConcurrencyReleaseResponse,
    ConcurrencyRetrieveStatusResponse,
)
```

Methods:

- <code title="post /system/{tenant_db_name}/concurrency/acquire">client.system.concurrency.<a href="./src/web_recruitment_sdk/resources/system/concurrency.py">acquire</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/concurrency_acquire_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/concurrency_acquire_response.py">ConcurrencyAcquireResponse</a></code>
- <code title="post /system/{tenant_db_name}/concurrency/release">client.system.concurrency.<a href="./src/web_recruitment_sdk/resources/system/concurrency.py">release</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/concurrency_release_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/concurrency_release_response.py">ConcurrencyReleaseResponse</a></code>
- <code title="get /system/{tenant_db_name}/concurrency/status">client.system.concurrency.<a href="./src/web_recruitment_sdk/resources/system/concurrency.py">retrieve_status</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/concurrency_retrieve_status_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/concurrency_retrieve_status_response.py">ConcurrencyRetrieveStatusResponse</a></code>

## ClinicalConductor

Types:

```python
from web_recruitment_sdk.types.system import ClinicalConductorRetrieveResponse
```

Methods:

- <code title="get /system/{tenant_db_name}/clinical-conductor/visits/{visit_id}">client.system.clinical_conductor.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/clinical_conductor.py">retrieve</a>(visit_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/clinical_conductor_retrieve_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor_retrieve_response.py">ClinicalConductorRetrieveResponse</a></code>

### Instances

Types:

```python
from web_recruitment_sdk.types.system.clinical_conductor import (
    InstanceCreateResponse,
    InstanceRetrieveResponse,
    InstanceUpdateResponse,
    InstanceListResponse,
    InstanceTestConnectionResponse,
)
```

Methods:

- <code title="post /system/{tenant_db_name}/clinical-conductor/instances">client.system.clinical_conductor.instances.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/instances.py">create</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/clinical_conductor/instance_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/instance_create_response.py">InstanceCreateResponse</a></code>
- <code title="get /system/{tenant_db_name}/clinical-conductor/instances/{instance_id}">client.system.clinical_conductor.instances.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/instances.py">retrieve</a>(instance_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/instance_retrieve_response.py">InstanceRetrieveResponse</a></code>
- <code title="patch /system/{tenant_db_name}/clinical-conductor/instances/{instance_id}">client.system.clinical_conductor.instances.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/instances.py">update</a>(instance_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/clinical_conductor/instance_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/instance_update_response.py">InstanceUpdateResponse</a></code>
- <code title="get /system/{tenant_db_name}/clinical-conductor/instances">client.system.clinical_conductor.instances.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/instances.py">list</a>(tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/instance_list_response.py">InstanceListResponse</a></code>
- <code title="delete /system/{tenant_db_name}/clinical-conductor/instances/{instance_id}">client.system.clinical_conductor.instances.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/instances.py">delete</a>(instance_id, \*, tenant_db_name) -> None</code>
- <code title="post /system/{tenant_db_name}/clinical-conductor/instances/{instance_id}/test-connection">client.system.clinical_conductor.instances.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/instances.py">test_connection</a>(instance_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/instance_test_connection_response.py">InstanceTestConnectionResponse</a></code>

### StudyConfigs

Types:

```python
from web_recruitment_sdk.types.system.clinical_conductor import (
    StudyConfigRetrieveResponse,
    StudyConfigUpdateResponse,
    StudyConfigRetrieveStudyConfigsResponse,
    StudyConfigRetrieveVisitsResponse,
    StudyConfigStudyConfigsResponse,
)
```

Methods:

- <code title="get /system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}">client.system.clinical_conductor.study_configs.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/study_configs.py">retrieve</a>(study_config_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/study_config_retrieve_response.py">StudyConfigRetrieveResponse</a></code>
- <code title="patch /system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}">client.system.clinical_conductor.study_configs.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/study_configs.py">update</a>(study_config_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/clinical_conductor/study_config_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/study_config_update_response.py">StudyConfigUpdateResponse</a></code>
- <code title="delete /system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}">client.system.clinical_conductor.study_configs.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/study_configs.py">delete</a>(study_config_id, \*, tenant_db_name) -> None</code>
- <code title="get /system/{tenant_db_name}/clinical-conductor/study-configs">client.system.clinical_conductor.study_configs.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/study_configs.py">retrieve_study_configs</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/clinical_conductor/study_config_retrieve_study_configs_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/study_config_retrieve_study_configs_response.py">StudyConfigRetrieveStudyConfigsResponse</a></code>
- <code title="get /system/{tenant_db_name}/clinical-conductor/study-configs/{study_config_id}/visits">client.system.clinical_conductor.study_configs.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/study_configs.py">retrieve_visits</a>(study_config_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/study_config_retrieve_visits_response.py">StudyConfigRetrieveVisitsResponse</a></code>
- <code title="post /system/{tenant_db_name}/clinical-conductor/study-configs">client.system.clinical_conductor.study_configs.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/study_configs.py">study_configs</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/clinical_conductor/study_config_study_configs_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/study_config_study_configs_response.py">StudyConfigStudyConfigsResponse</a></code>

### Appointments

Types:

```python
from web_recruitment_sdk.types.system.clinical_conductor import (
    AppointmentRetrieveResponse,
    AppointmentAvailabilityResponse,
    AppointmentCancelResponse,
)
```

Methods:

- <code title="get /system/{tenant_db_name}/clinical-conductor/appointments/{appointment_id}">client.system.clinical_conductor.appointments.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/appointments.py">retrieve</a>(appointment_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/appointment_retrieve_response.py">AppointmentRetrieveResponse</a></code>
- <code title="post /system/{tenant_db_name}/clinical-conductor/appointments/availability">client.system.clinical_conductor.appointments.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/appointments.py">availability</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/clinical_conductor/appointment_availability_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/appointment_availability_response.py">AppointmentAvailabilityResponse</a></code>
- <code title="post /system/{tenant_db_name}/clinical-conductor/appointments/{appointment_id}/cancel">client.system.clinical_conductor.appointments.<a href="./src/web_recruitment_sdk/resources/system/clinical_conductor/appointments.py">cancel</a>(appointment_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/clinical_conductor/appointment_cancel_response.py">AppointmentCancelResponse</a></code>

## SemanticPrefilterValidation

Types:

```python
from web_recruitment_sdk.types.system import SemanticPrefilterValidationRunResponse
```

Methods:

- <code title="post /system/semantic-prefilter-validation/run">client.system.semantic_prefilter_validation.<a href="./src/web_recruitment_sdk/resources/system/semantic_prefilter_validation.py">run</a>() -> <a href="./src/web_recruitment_sdk/types/system/semantic_prefilter_validation_run_response.py">SemanticPrefilterValidationRunResponse</a></code>

## Twilio

Methods:

- <code title="post /system/{tenant_db_name}/twilio/inbound-sms">client.system.twilio.<a href="./src/web_recruitment_sdk/resources/system/twilio.py">process_inbound_sms</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/twilio_process_inbound_sms_params.py">params</a>) -> object</code>

## Facebook

Types:

```python
from web_recruitment_sdk.types.system import FacebookProcessLeadResponse
```

Methods:

- <code title="post /system/facebook/leads/{page_id}">client.system.facebook.<a href="./src/web_recruitment_sdk/resources/system/facebook.py">process_lead</a>(page_id, \*\*<a href="src/web_recruitment_sdk/types/system/facebook_process_lead_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/facebook_process_lead_response.py">FacebookProcessLeadResponse</a></code>

## Booking

Types:

```python
from web_recruitment_sdk.types.system import (
    BookingGetStatusResponse,
    BookingGetVisitInfoResponse,
    BookingSubmitIntakeResponse,
    BookingSubmitScreeningResponse,
)
```

Methods:

- <code title="get /system/{tenant_db_name}/booking/status">client.system.booking.<a href="./src/web_recruitment_sdk/resources/system/booking/booking.py">get_status</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/booking_get_status_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/booking_get_status_response.py">BookingGetStatusResponse</a></code>
- <code title="get /system/{tenant_db_name}/booking/visit-info">client.system.booking.<a href="./src/web_recruitment_sdk/resources/system/booking/booking.py">get_visit_info</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/booking_get_visit_info_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/booking_get_visit_info_response.py">BookingGetVisitInfoResponse</a></code>
- <code title="post /system/{tenant_db_name}/booking/intake">client.system.booking.<a href="./src/web_recruitment_sdk/resources/system/booking/booking.py">submit_intake</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/booking_submit_intake_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/booking_submit_intake_response.py">BookingSubmitIntakeResponse</a></code>
- <code title="post /system/{tenant_db_name}/booking/screening">client.system.booking.<a href="./src/web_recruitment_sdk/resources/system/booking/booking.py">submit_screening</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/booking_submit_screening_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/booking_submit_screening_response.py">BookingSubmitScreeningResponse</a></code>

### Availability

Types:

```python
from web_recruitment_sdk.types.system.booking import (
    AvailabilityGetAvailableDatesResponse,
    AvailabilityGetTimeSlotsResponse,
)
```

Methods:

- <code title="get /system/{tenant_db_name}/booking/availability/dates">client.system.booking.availability.<a href="./src/web_recruitment_sdk/resources/system/booking/availability.py">get_available_dates</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/booking/availability_get_available_dates_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/booking/availability_get_available_dates_response.py">AvailabilityGetAvailableDatesResponse</a></code>
- <code title="get /system/{tenant_db_name}/booking/availability/slots">client.system.booking.availability.<a href="./src/web_recruitment_sdk/resources/system/booking/availability.py">get_time_slots</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/booking/availability_get_time_slots_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/booking/availability_get_time_slots_response.py">AvailabilityGetTimeSlotsResponse</a></code>

### Appointment

Types:

```python
from web_recruitment_sdk.types.system.booking import (
    AppointmentBookAppointmentResponse,
    AppointmentGetAppointmentResponse,
)
```

Methods:

- <code title="post /system/{tenant_db_name}/booking/appointment">client.system.booking.appointment.<a href="./src/web_recruitment_sdk/resources/system/booking/appointment.py">book_appointment</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/booking/appointment_book_appointment_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/booking/appointment_book_appointment_response.py">AppointmentBookAppointmentResponse</a></code>
- <code title="get /system/{tenant_db_name}/booking/appointment">client.system.booking.appointment.<a href="./src/web_recruitment_sdk/resources/system/booking/appointment.py">get_appointment</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/booking/appointment_get_appointment_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/booking/appointment_get_appointment_response.py">Optional[AppointmentGetAppointmentResponse]</a></code>

### Config

Types:

```python
from web_recruitment_sdk.types.system.booking import (
    ConfigGetBookingConfigResponse,
    ConfigGetPublicBookingConfigResponse,
)
```

Methods:

- <code title="get /system/{tenant_db_name}/booking/config/{slug}">client.system.booking.config.<a href="./src/web_recruitment_sdk/resources/system/booking/config.py">get_booking_config</a>(slug, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/booking/config_get_booking_config_response.py">ConfigGetBookingConfigResponse</a></code>
- <code title="get /system/{tenant_db_name}/booking/config/{slug}/public">client.system.booking.config.<a href="./src/web_recruitment_sdk/resources/system/booking/config.py">get_public_booking_config</a>(slug, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/booking/config_get_public_booking_config_response.py">ConfigGetPublicBookingConfigResponse</a></code>

## Nylas

### Grants

Types:

```python
from web_recruitment_sdk.types.system.nylas import (
    GrantCreateGrantResponse,
    GrantGetGrantResponse,
    GrantListGrantsResponse,
)
```

Methods:

- <code title="post /system/{tenant_db_name}/nylas/grants">client.system.nylas.grants.<a href="./src/web_recruitment_sdk/resources/system/nylas/grants.py">create_grant</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/nylas/grant_create_grant_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/nylas/grant_create_grant_response.py">GrantCreateGrantResponse</a></code>
- <code title="delete /system/{tenant_db_name}/nylas/grants/{grant_id}">client.system.nylas.grants.<a href="./src/web_recruitment_sdk/resources/system/nylas/grants.py">delete_grant</a>(grant_id, \*, tenant_db_name) -> None</code>
- <code title="get /system/{tenant_db_name}/nylas/grants/{grant_id}">client.system.nylas.grants.<a href="./src/web_recruitment_sdk/resources/system/nylas/grants.py">get_grant</a>(grant_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/nylas/grant_get_grant_response.py">GrantGetGrantResponse</a></code>
- <code title="get /system/{tenant_db_name}/nylas/grants">client.system.nylas.grants.<a href="./src/web_recruitment_sdk/resources/system/nylas/grants.py">list_grants</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/nylas/grant_list_grants_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/nylas/grant_list_grants_response.py">GrantListGrantsResponse</a></code>

### CalendarConfigs

Types:

```python
from web_recruitment_sdk.types.system.nylas import (
    CalendarConfigCreateCalendarConfigResponse,
    CalendarConfigGetCalendarConfigResponse,
    CalendarConfigListCalendarConfigsResponse,
    CalendarConfigUpdateCalendarConfigResponse,
)
```

Methods:

- <code title="post /system/{tenant_db_name}/nylas/calendar-configs">client.system.nylas.calendar_configs.<a href="./src/web_recruitment_sdk/resources/system/nylas/calendar_configs.py">create_calendar_config</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/nylas/calendar_config_create_calendar_config_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/nylas/calendar_config_create_calendar_config_response.py">CalendarConfigCreateCalendarConfigResponse</a></code>
- <code title="delete /system/{tenant_db_name}/nylas/calendar-configs/{config_id}">client.system.nylas.calendar_configs.<a href="./src/web_recruitment_sdk/resources/system/nylas/calendar_configs.py">delete_calendar_config</a>(config_id, \*, tenant_db_name) -> None</code>
- <code title="get /system/{tenant_db_name}/nylas/calendar-configs/{config_id}">client.system.nylas.calendar_configs.<a href="./src/web_recruitment_sdk/resources/system/nylas/calendar_configs.py">get_calendar_config</a>(config_id, \*, tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/nylas/calendar_config_get_calendar_config_response.py">CalendarConfigGetCalendarConfigResponse</a></code>
- <code title="get /system/{tenant_db_name}/nylas/calendar-configs">client.system.nylas.calendar_configs.<a href="./src/web_recruitment_sdk/resources/system/nylas/calendar_configs.py">list_calendar_configs</a>(tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/nylas/calendar_config_list_calendar_configs_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/nylas/calendar_config_list_calendar_configs_response.py">CalendarConfigListCalendarConfigsResponse</a></code>
- <code title="patch /system/{tenant_db_name}/nylas/calendar-configs/{config_id}">client.system.nylas.calendar_configs.<a href="./src/web_recruitment_sdk/resources/system/nylas/calendar_configs.py">update_calendar_config</a>(config_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/system/nylas/calendar_config_update_calendar_config_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/system/nylas/calendar_config_update_calendar_config_response.py">CalendarConfigUpdateCalendarConfigResponse</a></code>

## Scheduling

Types:

```python
from web_recruitment_sdk.types.system import SchedulingListProvidersResponse
```

Methods:

- <code title="get /system/{tenant_db_name}/scheduling/providers">client.system.scheduling.<a href="./src/web_recruitment_sdk/resources/system/scheduling.py">list_providers</a>(tenant_db_name) -> <a href="./src/web_recruitment_sdk/types/system/scheduling_list_providers_response.py">SchedulingListProvidersResponse</a></code>

# Dashboards

Types:

```python
from web_recruitment_sdk.types import ChartResponse
```

Methods:

- <code title="get /dashboards/age-distribution">client.dashboards.<a href="./src/web_recruitment_sdk/resources/dashboards.py">get_age_distribution</a>(\*\*<a href="src/web_recruitment_sdk/types/dashboard_get_age_distribution_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/chart_response.py">ChartResponse</a></code>
- <code title="get /dashboards/ethnic-distribution">client.dashboards.<a href="./src/web_recruitment_sdk/resources/dashboards.py">get_ethnic_distribution</a>(\*\*<a href="src/web_recruitment_sdk/types/dashboard_get_ethnic_distribution_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/chart_response.py">ChartResponse</a></code>
- <code title="get /dashboards/gender-distribution">client.dashboards.<a href="./src/web_recruitment_sdk/resources/dashboards.py">get_gender_distribution</a>(\*\*<a href="src/web_recruitment_sdk/types/dashboard_get_gender_distribution_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/chart_response.py">ChartResponse</a></code>
- <code title="get /dashboards/race-distribution">client.dashboards.<a href="./src/web_recruitment_sdk/resources/dashboards.py">get_race_distribution</a>(\*\*<a href="src/web_recruitment_sdk/types/dashboard_get_race_distribution_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/chart_response.py">ChartResponse</a></code>
- <code title="get /dashboards/conditions">client.dashboards.<a href="./src/web_recruitment_sdk/resources/dashboards.py">get_top_conditions</a>(\*\*<a href="src/web_recruitment_sdk/types/dashboard_get_top_conditions_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/chart_response.py">ChartResponse</a></code>
- <code title="get /dashboards/medications">client.dashboards.<a href="./src/web_recruitment_sdk/resources/dashboards.py">get_top_medications</a>(\*\*<a href="src/web_recruitment_sdk/types/dashboard_get_top_medications_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/chart_response.py">ChartResponse</a></code>
- <code title="get /dashboards/procedures">client.dashboards.<a href="./src/web_recruitment_sdk/resources/dashboards.py">get_top_procedures</a>(\*\*<a href="src/web_recruitment_sdk/types/dashboard_get_top_procedures_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/chart_response.py">ChartResponse</a></code>

# Protocols

Types:

```python
from web_recruitment_sdk.types import (
    ProtocolParsingRead,
    ProtocolParsingStatus,
    ProtocolListResponse,
    ProtocolGetCriteriaInstancesResponse,
    ProtocolGetMatchFacetsResponse,
    ProtocolGetMatchesResponse,
)
```

Methods:

- <code title="get /protocols/{protocol_id}">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">retrieve</a>(protocol_id) -> <a href="./src/web_recruitment_sdk/types/protocol_read.py">ProtocolRead</a></code>
- <code title="patch /protocols/{protocol_id}">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">update</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocol_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocol_read.py">ProtocolRead</a></code>
- <code title="get /protocols">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/protocol_list_response.py">ProtocolListResponse</a></code>
- <code title="delete /protocols/{protocol_id}">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">delete</a>(protocol_id) -> None</code>
- <code title="get /protocols/{protocol_id}/criteria_instances">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">get_criteria_instances</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocol_get_criteria_instances_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocol_get_criteria_instances_response.py">ProtocolGetCriteriaInstancesResponse</a></code>
- <code title="get /protocols/{protocol_id}/funnel">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">get_funnel</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocol_get_funnel_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/funnel_stats.py">FunnelStats</a></code>
- <code title="get /protocols/{protocol_id}/matches/facets">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">get_match_facets</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocol_get_match_facets_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocol_get_match_facets_response.py">ProtocolGetMatchFacetsResponse</a></code>
- <code title="get /protocols/{protocol_id}/matches">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">get_matches</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocol_get_matches_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocol_get_matches_response.py">ProtocolGetMatchesResponse</a></code>
- <code title="get /protocols/{protocol_id}/protocol-parsing">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">get_parsing_status</a>(protocol_id) -> <a href="./src/web_recruitment_sdk/types/protocol_parsing_read.py">ProtocolParsingRead</a></code>
- <code title="post /protocols/{protocol_id}/ready">client.protocols.<a href="./src/web_recruitment_sdk/resources/protocols/protocols.py">set_ready</a>(protocol_id) -> <a href="./src/web_recruitment_sdk/types/protocol_read.py">ProtocolRead</a></code>

## Sites

Types:

```python
from web_recruitment_sdk.types.protocols import SiteCreateResponse, SiteListResponse
```

Methods:

- <code title="post /protocols/{protocol_id}/sites/{site_id}">client.protocols.sites.<a href="./src/web_recruitment_sdk/resources/protocols/sites.py">create</a>(site_id, \*, protocol_id) -> <a href="./src/web_recruitment_sdk/types/protocols/site_create_response.py">SiteCreateResponse</a></code>
- <code title="get /protocols/{protocol_id}/sites">client.protocols.sites.<a href="./src/web_recruitment_sdk/resources/protocols/sites.py">list</a>(protocol_id) -> <a href="./src/web_recruitment_sdk/types/protocols/site_list_response.py">SiteListResponse</a></code>
- <code title="delete /protocols/{protocol_id}/sites/{site_id}">client.protocols.sites.<a href="./src/web_recruitment_sdk/resources/protocols/sites.py">delete</a>(site_id, \*, protocol_id) -> None</code>

## Criteria

Types:

```python
from web_recruitment_sdk.types.protocols import (
    CriterionListResponse,
    CriterionGetMatchingProgressResponse,
)
```

Methods:

- <code title="post /protocols/{protocol_id}/criteria">client.protocols.criteria.<a href="./src/web_recruitment_sdk/resources/protocols/criteria.py">create</a>(path_protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocols/criterion_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>
- <code title="put /protocols/{protocol_id}/criteria/{criterion_id}">client.protocols.criteria.<a href="./src/web_recruitment_sdk/resources/protocols/criteria.py">update</a>(criterion_id, \*, path_protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocols/criterion_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>
- <code title="get /protocols/{protocol_id}/criteria">client.protocols.criteria.<a href="./src/web_recruitment_sdk/resources/protocols/criteria.py">list</a>(protocol_id) -> <a href="./src/web_recruitment_sdk/types/protocols/criterion_list_response.py">CriterionListResponse</a></code>
- <code title="delete /protocols/{protocol_id}/criteria/{criterion_id}">client.protocols.criteria.<a href="./src/web_recruitment_sdk/resources/protocols/criteria.py">delete</a>(criterion_id, \*, protocol_id) -> None</code>
- <code title="get /protocols/{protocol_id}/criteria/matching-progress">client.protocols.criteria.<a href="./src/web_recruitment_sdk/resources/protocols/criteria.py">get_matching_progress</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocols/criterion_get_matching_progress_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocols/criterion_get_matching_progress_response.py">CriterionGetMatchingProgressResponse</a></code>
- <code title="put /protocols/{protocol_id}/criteria/{criterion_id}/priority">client.protocols.criteria.<a href="./src/web_recruitment_sdk/resources/protocols/criteria.py">set_priority</a>(criterion_id, \*, protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocols/criterion_set_priority_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/custom_searches/criteria_read.py">CriteriaRead</a></code>

## UserCriteria

Types:

```python
from web_recruitment_sdk.types.protocols import (
    UserCriterionUpdateResponse,
    UserCriterionListResponse,
)
```

Methods:

- <code title="put /protocols/{protocol_id}/user-criteria">client.protocols.user_criteria.<a href="./src/web_recruitment_sdk/resources/protocols/user_criteria.py">update</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocols/user_criterion_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocols/user_criterion_update_response.py">UserCriterionUpdateResponse</a></code>
- <code title="get /protocols/{protocol_id}/user-criteria">client.protocols.user_criteria.<a href="./src/web_recruitment_sdk/resources/protocols/user_criteria.py">list</a>(protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocols/user_criterion_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocols/user_criterion_list_response.py">UserCriterionListResponse</a></code>

## Patients

Types:

```python
from web_recruitment_sdk.types.protocols import PatientUpdateWorkflowTagResponse
```

Methods:

- <code title="put /protocols/{protocol_id}/patients/{patient_id}/workflow-tag">client.protocols.patients.<a href="./src/web_recruitment_sdk/resources/protocols/patients.py">update_workflow_tag</a>(patient_id, \*, protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocols/patient_update_workflow_tag_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocols/patient_update_workflow_tag_response.py">PatientUpdateWorkflowTagResponse</a></code>

## Documents

Types:

```python
from web_recruitment_sdk.types.protocols import DocumentGetDownloadURLResponse
```

Methods:

- <code title="get /protocols/{protocol_id}/documents/{document_metadata_id}/download-url">client.protocols.documents.<a href="./src/web_recruitment_sdk/resources/protocols/documents.py">get_download_url</a>(document_metadata_id, \*, protocol_id, \*\*<a href="src/web_recruitment_sdk/types/protocols/document_get_download_url_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/protocols/document_get_download_url_response.py">DocumentGetDownloadURLResponse</a></code>

# ExportJobs

Types:

```python
from web_recruitment_sdk.types import (
    ExportJobCreateResponse,
    ExportJobListResponse,
    ExportJobRetrievePatientsResponse,
)
```

Methods:

- <code title="post /export-job/sites/{site_id}">client.export_jobs.<a href="./src/web_recruitment_sdk/resources/export_jobs.py">create</a>(site_id, \*\*<a href="src/web_recruitment_sdk/types/export_job_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/export_job_create_response.py">ExportJobCreateResponse</a></code>
- <code title="get /export-jobs">client.export_jobs.<a href="./src/web_recruitment_sdk/resources/export_jobs.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/export_job_list_response.py">ExportJobListResponse</a></code>
- <code title="get /export-jobs/{export_job_id}/patients">client.export_jobs.<a href="./src/web_recruitment_sdk/resources/export_jobs.py">retrieve_patients</a>(export_job_id) -> <a href="./src/web_recruitment_sdk/types/export_job_retrieve_patients_response.py">ExportJobRetrievePatientsResponse</a></code>

# External

## Leads

### Campaigns

Types:

```python
from web_recruitment_sdk.types.external.leads import CampaignAddCandidateResponse
```

Methods:

- <code title="post /external/leads/{tenant_db_name}/campaigns/{campaign_id}/add-to-campaign">client.external.leads.campaigns.<a href="./src/web_recruitment_sdk/resources/external/leads/campaigns.py">add_candidate</a>(campaign_id, \*, tenant_db_name, \*\*<a href="src/web_recruitment_sdk/types/external/leads/campaign_add_candidate_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/external/leads/campaign_add_candidate_response.py">CampaignAddCandidateResponse</a></code>

# Outreach

Types:

```python
from web_recruitment_sdk.types import (
    OutreachGetCandidateAppointmentsResponse,
    OutreachTriggerCallResponse,
)
```

Methods:

- <code title="get /outreach/candidate-appointments">client.outreach.<a href="./src/web_recruitment_sdk/resources/outreach/outreach.py">get_candidate_appointments</a>() -> <a href="./src/web_recruitment_sdk/types/outreach_get_candidate_appointments_response.py">OutreachGetCandidateAppointmentsResponse</a></code>
- <code title="post /outreach/make-call">client.outreach.<a href="./src/web_recruitment_sdk/resources/outreach/outreach.py">trigger_call</a>(\*\*<a href="src/web_recruitment_sdk/types/outreach_trigger_call_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach_trigger_call_response.py">OutreachTriggerCallResponse</a></code>

## Campaigns

Types:

```python
from web_recruitment_sdk.types.outreach import (
    CampaignCreateResponse,
    CampaignListResponse,
    CampaignGetAnalyticsResponse,
    CampaignGetCandidatesResponse,
    CampaignPauseResponse,
    CampaignSetLandingPageResponse,
    CampaignStartResponse,
)
```

Methods:

- <code title="post /outreach/campaigns">client.outreach.campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/campaigns.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/outreach/campaign_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/campaign_create_response.py">CampaignCreateResponse</a></code>
- <code title="get /outreach/campaigns">client.outreach.campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/campaigns.py">list</a>(\*\*<a href="src/web_recruitment_sdk/types/outreach/campaign_list_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/campaign_list_response.py">CampaignListResponse</a></code>
- <code title="delete /outreach/campaigns/{campaign_id}">client.outreach.campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/campaigns.py">delete</a>(campaign_id) -> None</code>
- <code title="get /outreach/campaigns/{campaign_id}/analytics">client.outreach.campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/campaigns.py">get_analytics</a>(campaign_id, \*\*<a href="src/web_recruitment_sdk/types/outreach/campaign_get_analytics_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/campaign_get_analytics_response.py">CampaignGetAnalyticsResponse</a></code>
- <code title="get /outreach/campaigns/{campaign_id}/candidates">client.outreach.campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/campaigns.py">get_candidates</a>(campaign_id) -> <a href="./src/web_recruitment_sdk/types/outreach/campaign_get_candidates_response.py">CampaignGetCandidatesResponse</a></code>
- <code title="post /outreach/campaigns/{campaign_id}/pause">client.outreach.campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/campaigns.py">pause</a>(campaign_id) -> <a href="./src/web_recruitment_sdk/types/outreach/campaign_pause_response.py">CampaignPauseResponse</a></code>
- <code title="patch /outreach/campaigns/{campaign_id}/landing-page">client.outreach.campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/campaigns.py">set_landing_page</a>(campaign_id, \*\*<a href="src/web_recruitment_sdk/types/outreach/campaign_set_landing_page_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/campaign_set_landing_page_response.py">CampaignSetLandingPageResponse</a></code>
- <code title="post /outreach/campaigns/{campaign_id}/start">client.outreach.campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/campaigns.py">start</a>(campaign_id) -> <a href="./src/web_recruitment_sdk/types/outreach/campaign_start_response.py">CampaignStartResponse</a></code>

### Persons

Types:

```python
from web_recruitment_sdk.types.outreach.campaigns import (
    PersonGetActionsResponse,
    PersonGetAttemptsResponse,
)
```

Methods:

- <code title="get /outreach/campaigns/{campaign_id}/persons/{person_id}/actions">client.outreach.campaigns.persons.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/persons.py">get_actions</a>(person_id, \*, campaign_id) -> <a href="./src/web_recruitment_sdk/types/outreach/campaigns/person_get_actions_response.py">PersonGetActionsResponse</a></code>
- <code title="get /outreach/campaigns/{campaign_id}/persons/{person_id}/attempts">client.outreach.campaigns.persons.<a href="./src/web_recruitment_sdk/resources/outreach/campaigns/persons.py">get_attempts</a>(person_id, \*, campaign_id) -> <a href="./src/web_recruitment_sdk/types/outreach/campaigns/person_get_attempts_response.py">PersonGetAttemptsResponse</a></code>

## Sites

### Outreach

Types:

```python
from web_recruitment_sdk.types.outreach.sites import (
    OutreachCreateResponse,
    OutreachRetrieveResponse,
    OutreachUpdateResponse,
)
```

Methods:

- <code title="post /outreach/sites/{site_id}/outreach">client.outreach.sites.outreach.<a href="./src/web_recruitment_sdk/resources/outreach/sites/outreach.py">create</a>(site_id, \*\*<a href="src/web_recruitment_sdk/types/outreach/sites/outreach_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/sites/outreach_create_response.py">OutreachCreateResponse</a></code>
- <code title="get /outreach/sites/{site_id}/outreach">client.outreach.sites.outreach.<a href="./src/web_recruitment_sdk/resources/outreach/sites/outreach.py">retrieve</a>(site_id) -> <a href="./src/web_recruitment_sdk/types/outreach/sites/outreach_retrieve_response.py">Optional[OutreachRetrieveResponse]</a></code>
- <code title="patch /outreach/sites/{site_id}/outreach">client.outreach.sites.outreach.<a href="./src/web_recruitment_sdk/resources/outreach/sites/outreach.py">update</a>(site_id, \*\*<a href="src/web_recruitment_sdk/types/outreach/sites/outreach_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/sites/outreach_update_response.py">OutreachUpdateResponse</a></code>

## CandidateCampaigns

Types:

```python
from web_recruitment_sdk.types.outreach import CandidateCampaignCancelResponse
```

Methods:

- <code title="post /outreach/candidate-campaigns/{candidate_campaign_id}/cancel">client.outreach.candidate_campaigns.<a href="./src/web_recruitment_sdk/resources/outreach/candidate_campaigns.py">cancel</a>(candidate_campaign_id) -> <a href="./src/web_recruitment_sdk/types/outreach/candidate_campaign_cancel_response.py">CandidateCampaignCancelResponse</a></code>

## Candidates

Types:

```python
from web_recruitment_sdk.types.outreach import (
    CandidateListResponse,
    CandidateRetrieveJourneyResponse,
)
```

Methods:

- <code title="get /outreach/candidates">client.outreach.candidates.<a href="./src/web_recruitment_sdk/resources/outreach/candidates.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/outreach/candidate_list_response.py">CandidateListResponse</a></code>
- <code title="get /outreach/candidates/{candidate_id}/journey">client.outreach.candidates.<a href="./src/web_recruitment_sdk/resources/outreach/candidates.py">retrieve_journey</a>(candidate_id) -> <a href="./src/web_recruitment_sdk/types/outreach/candidate_retrieve_journey_response.py">CandidateRetrieveJourneyResponse</a></code>

## Workflows

Types:

```python
from web_recruitment_sdk.types.outreach import (
    WorkflowCreateResponse,
    WorkflowRetrieveResponse,
    WorkflowUpdateResponse,
    WorkflowListResponse,
)
```

Methods:

- <code title="post /outreach/workflows">client.outreach.workflows.<a href="./src/web_recruitment_sdk/resources/outreach/workflows.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/outreach/workflow_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/workflow_create_response.py">WorkflowCreateResponse</a></code>
- <code title="get /outreach/workflows/{workflow_id}">client.outreach.workflows.<a href="./src/web_recruitment_sdk/resources/outreach/workflows.py">retrieve</a>(workflow_id) -> <a href="./src/web_recruitment_sdk/types/outreach/workflow_retrieve_response.py">WorkflowRetrieveResponse</a></code>
- <code title="patch /outreach/workflows/{workflow_id}">client.outreach.workflows.<a href="./src/web_recruitment_sdk/resources/outreach/workflows.py">update</a>(workflow_id, \*\*<a href="src/web_recruitment_sdk/types/outreach/workflow_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/workflow_update_response.py">WorkflowUpdateResponse</a></code>
- <code title="get /outreach/workflows">client.outreach.workflows.<a href="./src/web_recruitment_sdk/resources/outreach/workflows.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/outreach/workflow_list_response.py">WorkflowListResponse</a></code>

## Tenant

Types:

```python
from web_recruitment_sdk.types.outreach import (
    TenantCreateResponse,
    TenantRetrieveResponse,
    TenantUpdateResponse,
)
```

Methods:

- <code title="post /outreach/tenant">client.outreach.tenant.<a href="./src/web_recruitment_sdk/resources/outreach/tenant.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/outreach/tenant_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/tenant_create_response.py">TenantCreateResponse</a></code>
- <code title="get /outreach/tenant">client.outreach.tenant.<a href="./src/web_recruitment_sdk/resources/outreach/tenant.py">retrieve</a>() -> <a href="./src/web_recruitment_sdk/types/outreach/tenant_retrieve_response.py">Optional[TenantRetrieveResponse]</a></code>
- <code title="patch /outreach/tenant">client.outreach.tenant.<a href="./src/web_recruitment_sdk/resources/outreach/tenant.py">update</a>(\*\*<a href="src/web_recruitment_sdk/types/outreach/tenant_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/tenant_update_response.py">TenantUpdateResponse</a></code>
- <code title="delete /outreach/tenant">client.outreach.tenant.<a href="./src/web_recruitment_sdk/resources/outreach/tenant.py">delete</a>() -> None</code>

## PersonSources

Types:

```python
from web_recruitment_sdk.types.outreach import (
    PersonSourceCreateResponse,
    PersonSourceRetrieveResponse,
    PersonSourceUpdateResponse,
    PersonSourceListResponse,
)
```

Methods:

- <code title="post /outreach/person-sources">client.outreach.person_sources.<a href="./src/web_recruitment_sdk/resources/outreach/person_sources.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/outreach/person_source_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/person_source_create_response.py">PersonSourceCreateResponse</a></code>
- <code title="get /outreach/person-sources/{source_id}">client.outreach.person_sources.<a href="./src/web_recruitment_sdk/resources/outreach/person_sources.py">retrieve</a>(source_id) -> <a href="./src/web_recruitment_sdk/types/outreach/person_source_retrieve_response.py">PersonSourceRetrieveResponse</a></code>
- <code title="put /outreach/person-sources/{source_id}">client.outreach.person_sources.<a href="./src/web_recruitment_sdk/resources/outreach/person_sources.py">update</a>(source_id, \*\*<a href="src/web_recruitment_sdk/types/outreach/person_source_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/outreach/person_source_update_response.py">PersonSourceUpdateResponse</a></code>
- <code title="get /outreach/person-sources">client.outreach.person_sources.<a href="./src/web_recruitment_sdk/resources/outreach/person_sources.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/outreach/person_source_list_response.py">PersonSourceListResponse</a></code>
- <code title="delete /outreach/person-sources/{source_id}">client.outreach.person_sources.<a href="./src/web_recruitment_sdk/resources/outreach/person_sources.py">delete</a>(source_id) -> None</code>

# Webhooks

Types:

```python
from web_recruitment_sdk.types import WebhookLogPayloadResponse
```

Methods:

- <code title="post /webhooks/log">client.webhooks.<a href="./src/web_recruitment_sdk/resources/webhooks/webhooks.py">log_payload</a>() -> <a href="./src/web_recruitment_sdk/types/webhook_log_payload_response.py">WebhookLogPayloadResponse</a></code>

## Rebrandly

### Link

Methods:

- <code title="post /webhooks/rebrandly/link/clicked">client.webhooks.rebrandly.link.<a href="./src/web_recruitment_sdk/resources/webhooks/rebrandly/link.py">handle_clicked</a>() -> object</code>

## Twilio

Methods:

- <code title="post /webhooks/twilio/inbound-sms/{tenant_db_name}">client.webhooks.twilio.<a href="./src/web_recruitment_sdk/resources/webhooks/twilio.py">handle_inbound_sms</a>(tenant_db_name) -> None</code>

## Bluejay

Methods:

- <code title="post /webhooks/bluejay/outbound_simulation_started">client.webhooks.bluejay.<a href="./src/web_recruitment_sdk/resources/webhooks/bluejay.py">handle_outbound_simulation_started</a>() -> object</code>

## Facebook

### Leads

Types:

```python
from web_recruitment_sdk.types.webhooks.facebook import LeadHandleLeadReceivedResponse
```

Methods:

- <code title="post /webhooks/facebook/leads">client.webhooks.facebook.leads.<a href="./src/web_recruitment_sdk/resources/webhooks/facebook/leads.py">handle_lead_received</a>() -> <a href="./src/web_recruitment_sdk/types/webhooks/facebook/lead_handle_lead_received_response.py">LeadHandleLeadReceivedResponse</a></code>
- <code title="get /webhooks/facebook/leads">client.webhooks.facebook.leads.<a href="./src/web_recruitment_sdk/resources/webhooks/facebook/leads.py">verify</a>(\*\*<a href="src/web_recruitment_sdk/types/webhooks/facebook/lead_verify_params.py">params</a>) -> object</code>

# Candidates

Types:

```python
from web_recruitment_sdk.types import CandidateImportCsvResponse
```

Methods:

- <code title="post /candidates/import-csv">client.candidates.<a href="./src/web_recruitment_sdk/resources/candidates.py">import_csv</a>(\*\*<a href="src/web_recruitment_sdk/types/candidate_import_csv_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/candidate_import_csv_response.py">CandidateImportCsvResponse</a></code>

# Workflows

Types:

```python
from web_recruitment_sdk.types import WorkflowCancelResponse, WorkflowSignalResponse
```

Methods:

- <code title="post /workflows/{workflow_id}/cancel">client.workflows.<a href="./src/web_recruitment_sdk/resources/workflows/workflows.py">cancel</a>(workflow_id) -> <a href="./src/web_recruitment_sdk/types/workflow_cancel_response.py">WorkflowCancelResponse</a></code>
- <code title="get /workflows/{workflow_id}/result">client.workflows.<a href="./src/web_recruitment_sdk/resources/workflows/workflows.py">retrieve_result</a>(workflow_id) -> object</code>
- <code title="post /workflows/{workflow_id}/signal">client.workflows.<a href="./src/web_recruitment_sdk/resources/workflows/workflows.py">signal</a>(workflow_id, \*\*<a href="src/web_recruitment_sdk/types/workflow_signal_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/workflow_signal_response.py">WorkflowSignalResponse</a></code>

## Greeting

Types:

```python
from web_recruitment_sdk.types.workflows import GreetingExecuteResponse, GreetingStartResponse
```

Methods:

- <code title="post /workflows/greeting/execute">client.workflows.greeting.<a href="./src/web_recruitment_sdk/resources/workflows/greeting/greeting.py">execute</a>(\*\*<a href="src/web_recruitment_sdk/types/workflows/greeting_execute_params.py">params</a>) -> str</code>
- <code title="post /workflows/greeting/start">client.workflows.greeting.<a href="./src/web_recruitment_sdk/resources/workflows/greeting/greeting.py">start</a>(\*\*<a href="src/web_recruitment_sdk/types/workflows/greeting_start_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/workflows/greeting_start_response.py">GreetingStartResponse</a></code>

### Schedule

Types:

```python
from web_recruitment_sdk.types.workflows.greeting import (
    ScheduleDeleteResponse,
    SchedulePauseResponse,
    ScheduleUnpauseResponse,
)
```

Methods:

- <code title="post /workflows/greeting/schedule/create">client.workflows.greeting.schedule.<a href="./src/web_recruitment_sdk/resources/workflows/greeting/schedule.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/workflows/greeting/schedule_create_params.py">params</a>) -> object</code>
- <code title="get /workflows/greeting/schedule/{schedule_id}">client.workflows.greeting.schedule.<a href="./src/web_recruitment_sdk/resources/workflows/greeting/schedule.py">retrieve</a>(schedule_id) -> object</code>
- <code title="delete /workflows/greeting/schedule/{schedule_id}">client.workflows.greeting.schedule.<a href="./src/web_recruitment_sdk/resources/workflows/greeting/schedule.py">delete</a>(schedule_id) -> <a href="./src/web_recruitment_sdk/types/workflows/greeting/schedule_delete_response.py">ScheduleDeleteResponse</a></code>
- <code title="post /workflows/greeting/schedule/{schedule_id}/pause">client.workflows.greeting.schedule.<a href="./src/web_recruitment_sdk/resources/workflows/greeting/schedule.py">pause</a>(schedule_id) -> <a href="./src/web_recruitment_sdk/types/workflows/greeting/schedule_pause_response.py">SchedulePauseResponse</a></code>
- <code title="post /workflows/greeting/schedule/{schedule_id}/unpause">client.workflows.greeting.schedule.<a href="./src/web_recruitment_sdk/resources/workflows/greeting/schedule.py">unpause</a>(schedule_id) -> <a href="./src/web_recruitment_sdk/types/workflows/greeting/schedule_unpause_response.py">ScheduleUnpauseResponse</a></code>

# ClinicalConductor

Types:

```python
from web_recruitment_sdk.types import ClinicalConductorListStudyConfigsResponse
```

Methods:

- <code title="get /clinical-conductor/study-configs">client.clinical_conductor.<a href="./src/web_recruitment_sdk/resources/clinical_conductor.py">list_study_configs</a>(\*\*<a href="src/web_recruitment_sdk/types/clinical_conductor_list_study_configs_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/clinical_conductor_list_study_configs_response.py">ClinicalConductorListStudyConfigsResponse</a></code>

# Facebook

## Pages

Types:

```python
from web_recruitment_sdk.types.facebook import (
    PageCreateConfigResponse,
    PageListConfigsResponse,
    PageListFormsResponse,
    PageRetrieveConfigResponse,
    PageUpdateConfigResponse,
)
```

Methods:

- <code title="post /facebook/pages">client.facebook.pages.<a href="./src/web_recruitment_sdk/resources/facebook/pages.py">create_config</a>(\*\*<a href="src/web_recruitment_sdk/types/facebook/page_create_config_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/facebook/page_create_config_response.py">PageCreateConfigResponse</a></code>
- <code title="delete /facebook/pages/{config_id}">client.facebook.pages.<a href="./src/web_recruitment_sdk/resources/facebook/pages.py">delete_config</a>(config_id) -> None</code>
- <code title="get /facebook/pages">client.facebook.pages.<a href="./src/web_recruitment_sdk/resources/facebook/pages.py">list_configs</a>() -> <a href="./src/web_recruitment_sdk/types/facebook/page_list_configs_response.py">PageListConfigsResponse</a></code>
- <code title="get /facebook/pages/{page_id}/forms">client.facebook.pages.<a href="./src/web_recruitment_sdk/resources/facebook/pages.py">list_forms</a>(page_id) -> <a href="./src/web_recruitment_sdk/types/facebook/page_list_forms_response.py">PageListFormsResponse</a></code>
- <code title="get /facebook/pages/{page_id}">client.facebook.pages.<a href="./src/web_recruitment_sdk/resources/facebook/pages.py">retrieve_config</a>(page_id) -> <a href="./src/web_recruitment_sdk/types/facebook/page_retrieve_config_response.py">PageRetrieveConfigResponse</a></code>
- <code title="patch /facebook/pages/{config_id}">client.facebook.pages.<a href="./src/web_recruitment_sdk/resources/facebook/pages.py">update_config</a>(config_id, \*\*<a href="src/web_recruitment_sdk/types/facebook/page_update_config_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/facebook/page_update_config_response.py">PageUpdateConfigResponse</a></code>

## FormMappings

Types:

```python
from web_recruitment_sdk.types.facebook import (
    FormMappingCreateMappingResponse,
    FormMappingListMappingsResponse,
)
```

Methods:

- <code title="post /facebook/form-mappings">client.facebook.form_mappings.<a href="./src/web_recruitment_sdk/resources/facebook/form_mappings.py">create_mapping</a>(\*\*<a href="src/web_recruitment_sdk/types/facebook/form_mapping_create_mapping_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/facebook/form_mapping_create_mapping_response.py">FormMappingCreateMappingResponse</a></code>
- <code title="delete /facebook/form-mappings/{mapping_id}">client.facebook.form_mappings.<a href="./src/web_recruitment_sdk/resources/facebook/form_mappings.py">delete_mapping</a>(mapping_id) -> None</code>
- <code title="get /facebook/form-mappings">client.facebook.form_mappings.<a href="./src/web_recruitment_sdk/resources/facebook/form_mappings.py">list_mappings</a>() -> <a href="./src/web_recruitment_sdk/types/facebook/form_mapping_list_mappings_response.py">FormMappingListMappingsResponse</a></code>

## Connect

Types:

```python
from web_recruitment_sdk.types.facebook import (
    ConnectFinalizeOAuthResponse,
    ConnectStartOAuthResponse,
)
```

Methods:

- <code title="post /facebook/connect/finalize">client.facebook.connect.<a href="./src/web_recruitment_sdk/resources/facebook/connect/connect.py">finalize_oauth</a>(\*\*<a href="src/web_recruitment_sdk/types/facebook/connect_finalize_oauth_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/facebook/connect_finalize_oauth_response.py">ConnectFinalizeOAuthResponse</a></code>
- <code title="get /facebook/connect/callback">client.facebook.connect.<a href="./src/web_recruitment_sdk/resources/facebook/connect/connect.py">handle_callback</a>(\*\*<a href="src/web_recruitment_sdk/types/facebook/connect_handle_callback_params.py">params</a>) -> object</code>
- <code title="get /facebook/connect/start">client.facebook.connect.<a href="./src/web_recruitment_sdk/resources/facebook/connect/connect.py">start_oauth</a>() -> <a href="./src/web_recruitment_sdk/types/facebook/connect_start_oauth_response.py">ConnectStartOAuthResponse</a></code>

### Pages

Types:

```python
from web_recruitment_sdk.types.facebook.connect import PageListSelectableResponse
```

Methods:

- <code title="delete /facebook/connect/pages/{page_id}">client.facebook.connect.pages.<a href="./src/web_recruitment_sdk/resources/facebook/connect/pages.py">disconnect</a>(page_id) -> None</code>
- <code title="get /facebook/connect/pages">client.facebook.connect.pages.<a href="./src/web_recruitment_sdk/resources/facebook/connect/pages.py">list_selectable</a>(\*\*<a href="src/web_recruitment_sdk/types/facebook/connect/page_list_selectable_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/facebook/connect/page_list_selectable_response.py">PageListSelectableResponse</a></code>

# Readiness

Methods:

- <code title="get /readiness">client.readiness.<a href="./src/web_recruitment_sdk/resources/readiness.py">check</a>() -> object</code>

# LandingPages

Types:

```python
from web_recruitment_sdk.types import (
    LandingPageCreateResponse,
    LandingPageRetrieveResponse,
    LandingPageUpdateResponse,
    LandingPageListResponse,
)
```

Methods:

- <code title="post /landing-pages">client.landing_pages.<a href="./src/web_recruitment_sdk/resources/landing_pages/landing_pages.py">create</a>(\*\*<a href="src/web_recruitment_sdk/types/landing_page_create_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/landing_page_create_response.py">LandingPageCreateResponse</a></code>
- <code title="get /landing-pages/{landing_page_id}">client.landing_pages.<a href="./src/web_recruitment_sdk/resources/landing_pages/landing_pages.py">retrieve</a>(landing_page_id) -> <a href="./src/web_recruitment_sdk/types/landing_page_retrieve_response.py">LandingPageRetrieveResponse</a></code>
- <code title="patch /landing-pages/{landing_page_id}">client.landing_pages.<a href="./src/web_recruitment_sdk/resources/landing_pages/landing_pages.py">update</a>(landing_page_id, \*\*<a href="src/web_recruitment_sdk/types/landing_page_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/landing_page_update_response.py">LandingPageUpdateResponse</a></code>
- <code title="get /landing-pages">client.landing_pages.<a href="./src/web_recruitment_sdk/resources/landing_pages/landing_pages.py">list</a>() -> <a href="./src/web_recruitment_sdk/types/landing_page_list_response.py">LandingPageListResponse</a></code>
- <code title="delete /landing-pages/{landing_page_id}">client.landing_pages.<a href="./src/web_recruitment_sdk/resources/landing_pages/landing_pages.py">delete</a>(landing_page_id) -> None</code>

## EmailTemplates

Types:

```python
from web_recruitment_sdk.types.landing_pages import (
    EmailTemplateUpdateResponse,
    EmailTemplateDeleteResponse,
)
```

Methods:

- <code title="put /landing-pages/{landing_page_id}/email-templates/{template_key}">client.landing_pages.email_templates.<a href="./src/web_recruitment_sdk/resources/landing_pages/email_templates.py">update</a>(template_key, \*, landing_page_id, \*\*<a href="src/web_recruitment_sdk/types/landing_pages/email_template_update_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/landing_pages/email_template_update_response.py">EmailTemplateUpdateResponse</a></code>
- <code title="delete /landing-pages/{landing_page_id}/email-templates/{template_key}">client.landing_pages.email_templates.<a href="./src/web_recruitment_sdk/resources/landing_pages/email_templates.py">delete</a>(template_key, \*, landing_page_id) -> <a href="./src/web_recruitment_sdk/types/landing_pages/email_template_delete_response.py">EmailTemplateDeleteResponse</a></code>

# Scheduling

Types:

```python
from web_recruitment_sdk.types import (
    SchedulingListCalendarConfigsResponse,
    SchedulingListProvidersResponse,
)
```

Methods:

- <code title="get /scheduling/calendar-configs">client.scheduling.<a href="./src/web_recruitment_sdk/resources/scheduling.py">list_calendar_configs</a>(\*\*<a href="src/web_recruitment_sdk/types/scheduling_list_calendar_configs_params.py">params</a>) -> <a href="./src/web_recruitment_sdk/types/scheduling_list_calendar_configs_response.py">SchedulingListCalendarConfigsResponse</a></code>
- <code title="get /scheduling/providers">client.scheduling.<a href="./src/web_recruitment_sdk/resources/scheduling.py">list_providers</a>() -> <a href="./src/web_recruitment_sdk/types/scheduling_list_providers_response.py">SchedulingListProvidersResponse</a></code>
