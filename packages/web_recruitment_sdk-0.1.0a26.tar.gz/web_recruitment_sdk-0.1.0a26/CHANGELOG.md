# Changelog

## 0.1.0-alpha.26 (2026-04-29)

Full Changelog: [v0.1.0-alpha.25...v0.1.0-alpha.26](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.25...v0.1.0-alpha.26)

### Features

* **api:** manual updates ([3a45627](https://github.com/TriallyAI/web-recruitment-sdk/commit/3a45627726b23eb3cbad830be193dbe8886b5f26))

## 0.1.0-alpha.25 (2026-04-29)

Full Changelog: [v0.1.0-alpha.24...v0.1.0-alpha.25](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.24...v0.1.0-alpha.25)

### Features

* adds sbom ([f4868df](https://github.com/TriallyAI/web-recruitment-sdk/commit/f4868df3fec2c1b65ff65f5714b24f99fbd6cb91))
* **api:** api update ([d8145ab](https://github.com/TriallyAI/web-recruitment-sdk/commit/d8145ab130deaa6feabead0c20485b0867ac665c))
* **api:** api update ([b3aaf96](https://github.com/TriallyAI/web-recruitment-sdk/commit/b3aaf96fe4c1d3fc4a084d506ca726832027acad))
* **api:** api update ([f9ca717](https://github.com/TriallyAI/web-recruitment-sdk/commit/f9ca7173c03eca29b6f72590c3086f884d8080ce))
* **api:** api update ([73e57ad](https://github.com/TriallyAI/web-recruitment-sdk/commit/73e57adfd3c6cb0984e052b2e1d99933f264f4b5))
* **api:** api update ([be4b550](https://github.com/TriallyAI/web-recruitment-sdk/commit/be4b5509a61fb3e179802b524ba6dfa046db18f6))
* **api:** api update ([ed41141](https://github.com/TriallyAI/web-recruitment-sdk/commit/ed41141e1c8fe13a68df7e880092a9853c4bf647))
* **api:** api update ([e055654](https://github.com/TriallyAI/web-recruitment-sdk/commit/e05565484318168d941a698ab456236e3a81c778))
* **api:** api update ([9701b27](https://github.com/TriallyAI/web-recruitment-sdk/commit/9701b27cd253f4271e4ae2c63592bfd3baf866af))
* **api:** api update ([e955b7a](https://github.com/TriallyAI/web-recruitment-sdk/commit/e955b7a4c5cd257458b1d43a7bab0075c477b5e5))
* **api:** api update ([5518a12](https://github.com/TriallyAI/web-recruitment-sdk/commit/5518a1272376f3dc84d2821ca2490d24876e8ca2))
* **api:** api update ([28e5fa1](https://github.com/TriallyAI/web-recruitment-sdk/commit/28e5fa1d70843d1290d81874c4e424dd08c4e29d))
* **api:** api update ([b0a3b90](https://github.com/TriallyAI/web-recruitment-sdk/commit/b0a3b905de41a14b7852ca1d45b4a6c6f46157b3))
* **api:** api update ([b383e2b](https://github.com/TriallyAI/web-recruitment-sdk/commit/b383e2bcad14402e67c47fb006b1d9cef49dd5a9))
* **api:** api update ([72ef700](https://github.com/TriallyAI/web-recruitment-sdk/commit/72ef700f0d0d3c881e77bcdc964f2f61dfd152ce))
* **api:** api update ([5d7c792](https://github.com/TriallyAI/web-recruitment-sdk/commit/5d7c7920d109461f966422906e3e9788743789c4))
* **api:** api update ([438aa47](https://github.com/TriallyAI/web-recruitment-sdk/commit/438aa47c8f688cfdf099399af9e80136e3c564ba))
* **api:** api update ([81cde78](https://github.com/TriallyAI/web-recruitment-sdk/commit/81cde78e6f150043736bf761376fd7fb9ec5c5e3))
* **api:** api update ([c5eefe4](https://github.com/TriallyAI/web-recruitment-sdk/commit/c5eefe489591b22f7d0768567f25148b7d43346a))
* **api:** api update ([0803062](https://github.com/TriallyAI/web-recruitment-sdk/commit/0803062efb659210b6319b660c2ffcc04b5bf0ff))
* **api:** api update ([31c2f4f](https://github.com/TriallyAI/web-recruitment-sdk/commit/31c2f4f7f8f6eb17f8102a1e93d296fa6e3ce05c))
* **api:** api update ([5c2d81e](https://github.com/TriallyAI/web-recruitment-sdk/commit/5c2d81e611fd8c471aa6362c3672c742b2039de0))
* **api:** api update ([6f62062](https://github.com/TriallyAI/web-recruitment-sdk/commit/6f62062d0cd7d5ba9c6e32721da80ed1bbf208c5))
* **api:** api update ([00ddcd5](https://github.com/TriallyAI/web-recruitment-sdk/commit/00ddcd5c027986509f5fb369fcca29e4904ca80f))
* **api:** api update ([faece01](https://github.com/TriallyAI/web-recruitment-sdk/commit/faece01212395c9c487ba64a54fcd3df97f09104))
* **api:** api update ([be9141b](https://github.com/TriallyAI/web-recruitment-sdk/commit/be9141bb61d4b1eb44495645973cd55d7d842155))
* **api:** api update ([80ca7db](https://github.com/TriallyAI/web-recruitment-sdk/commit/80ca7db57ac898666aed5a9c2af8c7df68b2ca5f))
* **api:** api update ([76358fb](https://github.com/TriallyAI/web-recruitment-sdk/commit/76358fb95a50285ae75ad3c5817af8381d1d83ea))
* **api:** api update ([710963a](https://github.com/TriallyAI/web-recruitment-sdk/commit/710963a89030a463f3b6b2cfb738dbfdfeffbf7d))
* **api:** api update ([971af04](https://github.com/TriallyAI/web-recruitment-sdk/commit/971af043a33f4837f8cf2133e7ae3a0597f84f48))
* **api:** api update ([972593e](https://github.com/TriallyAI/web-recruitment-sdk/commit/972593e7213e4822c2ac57fe1bd54146cd22fa78))
* **api:** api update ([d6eee07](https://github.com/TriallyAI/web-recruitment-sdk/commit/d6eee07fad3fcb572d81511db08e32d18fffd91e))
* **api:** api update ([fd47037](https://github.com/TriallyAI/web-recruitment-sdk/commit/fd470370921b475f248d09ba5c8af9138c0c31ac))
* **api:** api update ([24dae43](https://github.com/TriallyAI/web-recruitment-sdk/commit/24dae43dcc5c2877c67244abd3d51145a9416343))
* **api:** api update ([bae1b5d](https://github.com/TriallyAI/web-recruitment-sdk/commit/bae1b5d824c61d4a12ffb59ff17d76a406204119))
* **api:** api update ([f64bb7f](https://github.com/TriallyAI/web-recruitment-sdk/commit/f64bb7f35618a21b54b35d54581a349f44286100))
* **api:** api update ([45c1bf9](https://github.com/TriallyAI/web-recruitment-sdk/commit/45c1bf90897fe07e0544e0dc56da7026370de5fc))
* **api:** api update ([20f7329](https://github.com/TriallyAI/web-recruitment-sdk/commit/20f732940d7b6c56ae3b2cdadf27d4cec2e63870))
* **api:** api update ([12b49c9](https://github.com/TriallyAI/web-recruitment-sdk/commit/12b49c98f8f8be898586823990678919aa5b2d06))
* **api:** api update ([e375ece](https://github.com/TriallyAI/web-recruitment-sdk/commit/e375ece497008a381ee67af06d8ff2bead483490))
* **api:** api update ([60b4f4b](https://github.com/TriallyAI/web-recruitment-sdk/commit/60b4f4ba0ab7ceef66a6452712182a1cb6942c1e))
* **api:** api update ([e3cee8e](https://github.com/TriallyAI/web-recruitment-sdk/commit/e3cee8e24c0ef028319c3f35a769bca2735746c7))
* **api:** api update ([3780fca](https://github.com/TriallyAI/web-recruitment-sdk/commit/3780fcac019755afa6f1ec19e6319d6a7a61f539))
* **api:** api update ([0185586](https://github.com/TriallyAI/web-recruitment-sdk/commit/018558649d4788ded2ffd0f05523e9992c746339))
* **api:** api update ([4df846e](https://github.com/TriallyAI/web-recruitment-sdk/commit/4df846ecbd62fdd8fcea1efc197f74d84971b0bd))
* **api:** api update ([d68acfc](https://github.com/TriallyAI/web-recruitment-sdk/commit/d68acfc8677fbf0748fd457f7fddfd281ceed6d4))
* **api:** api update ([33e067c](https://github.com/TriallyAI/web-recruitment-sdk/commit/33e067c924640ff4e6da1300ea3ad9f894eedd3a))
* **api:** api update ([a854294](https://github.com/TriallyAI/web-recruitment-sdk/commit/a8542943f6ceb9f1cde4c263c547d87c9bd098af))
* **api:** api update ([273aee1](https://github.com/TriallyAI/web-recruitment-sdk/commit/273aee1eb559cf4aae54f87c8fc7da409822f653))
* **api:** api update ([1f3c008](https://github.com/TriallyAI/web-recruitment-sdk/commit/1f3c00837782f024ecaf022497ea4123cc44522c))
* **api:** api update ([a9a3ccd](https://github.com/TriallyAI/web-recruitment-sdk/commit/a9a3ccd6e4b6c8a71de7ba5d0fd2ee9a2002120b))
* **api:** api update ([77a8ea2](https://github.com/TriallyAI/web-recruitment-sdk/commit/77a8ea2e4db9112b6c71acf4c8e87083031d3a19))
* **api:** api update ([a195758](https://github.com/TriallyAI/web-recruitment-sdk/commit/a19575810a6433b5813dcb784c8df91b128ce047))
* **api:** api update ([61dd476](https://github.com/TriallyAI/web-recruitment-sdk/commit/61dd4764f674f00a2bce4b7b1f76e96ad11ab327))
* **api:** api update ([54c5060](https://github.com/TriallyAI/web-recruitment-sdk/commit/54c50603df08694e593de15172a70aa9367b9437))
* **api:** api update ([fcb39b3](https://github.com/TriallyAI/web-recruitment-sdk/commit/fcb39b3d0c66d2b2ee9c4e25945911c16a7fcf5f))
* **api:** api update ([eb05166](https://github.com/TriallyAI/web-recruitment-sdk/commit/eb05166a0287e8587d83cd613e997fd22fd0823c))
* **api:** api update ([20f91cb](https://github.com/TriallyAI/web-recruitment-sdk/commit/20f91cb09b6f8efa4852e0fe67672fbeb379dcf1))
* **api:** api update ([33f088c](https://github.com/TriallyAI/web-recruitment-sdk/commit/33f088cfc4fc7d083ed3c7d059d5619566e53548))
* **api:** api update ([99fe3bf](https://github.com/TriallyAI/web-recruitment-sdk/commit/99fe3bf04a55c3b4ef89d443ab8c917dc0aa6b45))
* **api:** api update ([236664c](https://github.com/TriallyAI/web-recruitment-sdk/commit/236664c77b682b3833eb4dfe970ac049af683563))
* **api:** api update ([a1eb252](https://github.com/TriallyAI/web-recruitment-sdk/commit/a1eb252c44043227d942fb29f7afdc79919b8af0))
* **api:** api update ([93328b5](https://github.com/TriallyAI/web-recruitment-sdk/commit/93328b5e8bf3317c413ac632da2659826c44e251))
* **api:** api update ([3e8fc1c](https://github.com/TriallyAI/web-recruitment-sdk/commit/3e8fc1c22371355d7f71d646eb362902e72c80df))
* **api:** api update ([807a8cf](https://github.com/TriallyAI/web-recruitment-sdk/commit/807a8cff8921b7b2c963b6a78738e5f27988dc31))
* **api:** api update ([6558a15](https://github.com/TriallyAI/web-recruitment-sdk/commit/6558a156c0e9a7585c7a262a8b30bf686b1ec242))
* **api:** api update ([c2bbfac](https://github.com/TriallyAI/web-recruitment-sdk/commit/c2bbfac7a6df3d9b17d6ccaf8961716e92bb2c57))
* **api:** api update ([fbc665e](https://github.com/TriallyAI/web-recruitment-sdk/commit/fbc665ea2c4d8557fdb797eed9b5231b635d3e80))
* **api:** api update ([9a92b66](https://github.com/TriallyAI/web-recruitment-sdk/commit/9a92b66a5ace29685fe537c2b2b3d26b0338c6a6))
* **api:** api update ([deb97ca](https://github.com/TriallyAI/web-recruitment-sdk/commit/deb97ca55ab81cb8f0f21afa242b88c98ac70abf))
* **api:** api update ([c23073f](https://github.com/TriallyAI/web-recruitment-sdk/commit/c23073f5f760fd3c3c0a231aa9609a5b43eb976e))
* **client:** add support for binary request streaming ([e78ea35](https://github.com/TriallyAI/web-recruitment-sdk/commit/e78ea3590a7eee07908550b2dcac32ada4f58c26))
* support setting headers via env ([d3dd737](https://github.com/TriallyAI/web-recruitment-sdk/commit/d3dd7378b585666ee619bab860beead90de39561))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([418b440](https://github.com/TriallyAI/web-recruitment-sdk/commit/418b440fee57c315e4c96ecc7e4905e4e9283aac))
* **deps:** bump minimum typing-extensions version ([dd9ba02](https://github.com/TriallyAI/web-recruitment-sdk/commit/dd9ba02772986dd064b651e87106a94030306bea))
* ensure streams are always closed ([502ff22](https://github.com/TriallyAI/web-recruitment-sdk/commit/502ff222df62f0a55bd87fcb5aa625cd5e5a4e63))
* **pydantic:** do not pass `by_alias` unless set ([b7e0d0e](https://github.com/TriallyAI/web-recruitment-sdk/commit/b7e0d0e4c6427ef65de63c7b03e339f5beba0a7b))
* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([b3603fe](https://github.com/TriallyAI/web-recruitment-sdk/commit/b3603fe4a5f1071736ea8a4f2fee3e0e9be4bc5f))
* use async_to_httpx_files in patch method ([9d03b51](https://github.com/TriallyAI/web-recruitment-sdk/commit/9d03b513ff48928789e8ec04ff422e3d7bf93807))


### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([3882cb6](https://github.com/TriallyAI/web-recruitment-sdk/commit/3882cb6f3408abc61b2c0c568933ff36e32d5d18))


### Chores

* add missing docstrings ([e3e1a64](https://github.com/TriallyAI/web-recruitment-sdk/commit/e3e1a64079e73451f9722db950fe6b9c71471546))
* **ci:** upgrade `actions/github-script` ([1717170](https://github.com/TriallyAI/web-recruitment-sdk/commit/1717170a85a53fa57881b19330960cdd6d6fed21))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([0881127](https://github.com/TriallyAI/web-recruitment-sdk/commit/0881127a6383cd889428372348975fee83f99579))
* **docs:** use environment variables for authentication in code snippets ([1dd7338](https://github.com/TriallyAI/web-recruitment-sdk/commit/1dd7338156bbe06b8bf08b96e2bca14d9beb5193))
* **internal:** add `--fix` argument to lint script ([059ef45](https://github.com/TriallyAI/web-recruitment-sdk/commit/059ef45a34ee40ae12f394ffa131df411e3fe20e))
* **internal:** add missing files argument to base client ([b4a579d](https://github.com/TriallyAI/web-recruitment-sdk/commit/b4a579dea1facf78c44ae94efd415731988a0866))
* **internal:** make `test_proxy_environment_variables` more resilient ([621af7c](https://github.com/TriallyAI/web-recruitment-sdk/commit/621af7c1f3185ef41e28195a2c2e1e577cae7c81))
* **internal:** tweak CI branches ([9122758](https://github.com/TriallyAI/web-recruitment-sdk/commit/9122758923b850cdd421f6f8d48fbe1a19c4077e))
* **internal:** update `actions/checkout` version ([66bb84b](https://github.com/TriallyAI/web-recruitment-sdk/commit/66bb84bee7feee3a6c04f94e3c28e8d3b938f159))
* speedup initial import ([ff64374](https://github.com/TriallyAI/web-recruitment-sdk/commit/ff64374080cd06c3fb1c514d8c704094cab91d00))
* update lockfile ([434b940](https://github.com/TriallyAI/web-recruitment-sdk/commit/434b940a01389a76866f094714e0ea699f7aced6))
* update placeholder string ([ed42da9](https://github.com/TriallyAI/web-recruitment-sdk/commit/ed42da922500d9283514dc5f8eb1e3e34a4d475b))

## 0.1.0-alpha.24 (2025-11-25)

Full Changelog: [v0.1.0-alpha.23...v0.1.0-alpha.24](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.23...v0.1.0-alpha.24)

### Features

* **api:** api update ([c669736](https://github.com/TriallyAI/web-recruitment-sdk/commit/c669736cbcf9a32216b7ed8beab86be22969f894))
* **api:** api update ([88f4889](https://github.com/TriallyAI/web-recruitment-sdk/commit/88f48897238de854f22e35f5563d0459837f1316))
* **api:** api update ([4382f6b](https://github.com/TriallyAI/web-recruitment-sdk/commit/4382f6b5e315a6bd6055980557306c3e63032e3f))
* **api:** api update ([4d96c05](https://github.com/TriallyAI/web-recruitment-sdk/commit/4d96c05a81627bd3862d9c7fb2d4ef12b234ad29))
* **api:** api update ([10ba27d](https://github.com/TriallyAI/web-recruitment-sdk/commit/10ba27dab3c4df4dba8bf6687cc612a9afbf508e))
* **api:** api update ([bdd1b93](https://github.com/TriallyAI/web-recruitment-sdk/commit/bdd1b931610b136b09c34bc899779f2f4156d795))
* **api:** api update ([46add6f](https://github.com/TriallyAI/web-recruitment-sdk/commit/46add6f4e32db7274d48711ec6f4243e4d4f1b9f))
* **api:** api update ([14b5ed8](https://github.com/TriallyAI/web-recruitment-sdk/commit/14b5ed886e6652ac775fee5fe2df27b8c6645575))
* **api:** api update ([6e74bee](https://github.com/TriallyAI/web-recruitment-sdk/commit/6e74bee011de314ab43a3ce659a8f7727c23a96a))
* **api:** api update ([98efc93](https://github.com/TriallyAI/web-recruitment-sdk/commit/98efc93fd4bd005e4656f62a15a721112e7fec9b))
* **api:** api update ([b9e0775](https://github.com/TriallyAI/web-recruitment-sdk/commit/b9e07754140f614b3fd64e9bc002ca4f73baca08))
* **api:** api update ([a04d9f5](https://github.com/TriallyAI/web-recruitment-sdk/commit/a04d9f5efa433baf798640860238a749f55ff9d6))
* **api:** manual updates ([7a93830](https://github.com/TriallyAI/web-recruitment-sdk/commit/7a9383054e44f1d51bbc0a032da9d9f5d06a782f))


### Bug Fixes

* **client:** close streams without requiring full consumption ([6b7646e](https://github.com/TriallyAI/web-recruitment-sdk/commit/6b7646e9d8346000f24017142608ba00477e7150))
* compat with Python 3.14 ([98fe2a6](https://github.com/TriallyAI/web-recruitment-sdk/commit/98fe2a616951cbd6ddeb158714dda27c82630dc6))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([3b0cb7b](https://github.com/TriallyAI/web-recruitment-sdk/commit/3b0cb7b2b5f1900a72c02c043e76145fb4aa9270))


### Chores

* add Python 3.14 classifier and testing ([519bbdf](https://github.com/TriallyAI/web-recruitment-sdk/commit/519bbdf0fe481cd1135370d3e12cfadfb7f13532))
* **internal/tests:** avoid race condition with implicit client cleanup ([fcb8312](https://github.com/TriallyAI/web-recruitment-sdk/commit/fcb83121fd444bc2d6acb5de9de476b97b91130a))
* **internal:** grammar fix (it's -&gt; its) ([c5a96e9](https://github.com/TriallyAI/web-recruitment-sdk/commit/c5a96e949c4979afbb07f7816a5df2e04c35a65d))
* **package:** drop Python 3.8 support ([dc38fff](https://github.com/TriallyAI/web-recruitment-sdk/commit/dc38fffd3e81bab75475038be633a45c37999f9f))

## 0.1.0-alpha.23 (2025-10-21)

Full Changelog: [v0.1.0-alpha.22...v0.1.0-alpha.23](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.22...v0.1.0-alpha.23)

### Features

* **api:** manual updates ([8778ec7](https://github.com/TriallyAI/web-recruitment-sdk/commit/8778ec79a2da73102b858d6cf3520b936c9ba3fa))

## 0.1.0-alpha.22 (2025-10-18)

Full Changelog: [v0.1.0-alpha.21...v0.1.0-alpha.22](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.21...v0.1.0-alpha.22)

### Features

* **api:** api update ([352f3f1](https://github.com/TriallyAI/web-recruitment-sdk/commit/352f3f120312197cb110dce450d83031ad8707a7))
* **api:** api update ([753dc8a](https://github.com/TriallyAI/web-recruitment-sdk/commit/753dc8a7eebe72927423bfd429a6a45a4e137ae3))
* **api:** api update ([add1ccc](https://github.com/TriallyAI/web-recruitment-sdk/commit/add1ccc041d83b7bd3c8e03215700efc2d96b5a0))
* **api:** api update ([52257a3](https://github.com/TriallyAI/web-recruitment-sdk/commit/52257a334ddad9d2d05ef9e36d9626651558a510))
* **api:** api update ([9a604c6](https://github.com/TriallyAI/web-recruitment-sdk/commit/9a604c69b5f759b131a54b7941a84bb8e7813e57))
* **api:** api update ([71d1ce3](https://github.com/TriallyAI/web-recruitment-sdk/commit/71d1ce373ccef53d1b5c3563bdc2883d1a22f025))
* **api:** api update ([daaa0bf](https://github.com/TriallyAI/web-recruitment-sdk/commit/daaa0bf742a6036bbf96a63f6bb444d4e3f2bed3))
* **api:** api update ([fd251fa](https://github.com/TriallyAI/web-recruitment-sdk/commit/fd251fa3114562c22084693c934981e27bd19739))
* **api:** api update ([dad1e3a](https://github.com/TriallyAI/web-recruitment-sdk/commit/dad1e3a361e44ee086b22f874889d21de72b3c4e))
* **api:** api update ([b621cd3](https://github.com/TriallyAI/web-recruitment-sdk/commit/b621cd3a8019d57e11a7ad0dbaa841a87660446a))
* **api:** api update ([2b1a3ef](https://github.com/TriallyAI/web-recruitment-sdk/commit/2b1a3ef28031f899997facbf722eecc5eea9e5d9))
* **api:** api update ([6976f56](https://github.com/TriallyAI/web-recruitment-sdk/commit/6976f5632ff02eeebd7f87bd8ee72da3541c2f11))
* **api:** api update ([b0a5f8e](https://github.com/TriallyAI/web-recruitment-sdk/commit/b0a5f8eebddd2cc4b9d21a919276eb0647b1a0d5))
* **api:** api update ([0ed1e87](https://github.com/TriallyAI/web-recruitment-sdk/commit/0ed1e87c6f87dbb276373d96678ed591ffd5323d))
* **api:** api update ([2bd85f8](https://github.com/TriallyAI/web-recruitment-sdk/commit/2bd85f83a324558f8b3fa5a49a2c1fa3b497f817))
* **api:** api update ([67e2dd1](https://github.com/TriallyAI/web-recruitment-sdk/commit/67e2dd174739bd741c4d4bb88e1869b7683d12e9))
* **api:** api update ([1e9724b](https://github.com/TriallyAI/web-recruitment-sdk/commit/1e9724b3c4f98f9afbf149ad7059a4d9cbd7cd06))
* **api:** api update ([e5293bf](https://github.com/TriallyAI/web-recruitment-sdk/commit/e5293bfccd6e4a476e3705f6306e6e32ca9ae1be))
* **api:** api update ([7a3b9c5](https://github.com/TriallyAI/web-recruitment-sdk/commit/7a3b9c525eeaf2b3d1ceb8487097d4e3ba84ed94))
* **api:** api update ([3229c3d](https://github.com/TriallyAI/web-recruitment-sdk/commit/3229c3d7592a62fe9433f0600c4b5372efbef75d))
* **api:** api update ([3e20980](https://github.com/TriallyAI/web-recruitment-sdk/commit/3e209808bf18207760480a55181f0d7f4112daac))
* improve future compat with pydantic v3 ([4e1de3a](https://github.com/TriallyAI/web-recruitment-sdk/commit/4e1de3a91ca4a67dd65c0e9c8c153e97ed5dc66b))
* **types:** replace List[str] with SequenceNotStr in params ([f4e795f](https://github.com/TriallyAI/web-recruitment-sdk/commit/f4e795febc77fa97ee39172ab1fb62fc48bd22ef))


### Bug Fixes

* avoid newer type syntax ([9487dd0](https://github.com/TriallyAI/web-recruitment-sdk/commit/9487dd0ef123a4d80c2e7c73136d98aac78730cc))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([cff2e32](https://github.com/TriallyAI/web-recruitment-sdk/commit/cff2e32ed9318baf6b5d52fe8864e8929d88d3df))
* do not install brew dependencies in ./scripts/bootstrap by default ([97f7d49](https://github.com/TriallyAI/web-recruitment-sdk/commit/97f7d49cb55692a283747a6281a01ac2db1bbf38))
* **internal:** add Sequence related utils ([7a1834c](https://github.com/TriallyAI/web-recruitment-sdk/commit/7a1834c75a7038e454a104f7c67f030cc551a8c5))
* **internal:** detect missing future annotations with ruff ([506c9b6](https://github.com/TriallyAI/web-recruitment-sdk/commit/506c9b6d9d34eb6c33d89d42f97e5055fb9784a7))
* **internal:** move mypy configurations to `pyproject.toml` file ([9d01102](https://github.com/TriallyAI/web-recruitment-sdk/commit/9d011024b3bd70e54eec8f496ba91a6da96435eb))
* **internal:** update pydantic dependency ([967c1bb](https://github.com/TriallyAI/web-recruitment-sdk/commit/967c1bb282da859649fd82dac547203f03cba5d1))
* **internal:** update pyright exclude list ([5d9c081](https://github.com/TriallyAI/web-recruitment-sdk/commit/5d9c081a1ddb63a8c62d2f90a8c14db386dfad1e))
* **tests:** simplify `get_platform` test ([b839572](https://github.com/TriallyAI/web-recruitment-sdk/commit/b839572081a5c6b6c375c4e4ed04b5bbd8ac5431))
* **types:** change optional parameter type from NotGiven to Omit ([e8b93dd](https://github.com/TriallyAI/web-recruitment-sdk/commit/e8b93dd006285fedd4e2dfb2558af8550b015c30))

## 0.1.0-alpha.21 (2025-08-25)

Full Changelog: [v0.1.0-alpha.20...v0.1.0-alpha.21](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.20...v0.1.0-alpha.21)

### Features

* **api:** api update ([1ec21bf](https://github.com/TriallyAI/web-recruitment-sdk/commit/1ec21bf722f10023f377aaf542b9c720a25ada70))
* **api:** api update ([911ad43](https://github.com/TriallyAI/web-recruitment-sdk/commit/911ad432ef272713cb4f2ab21b1515d38f735c0c))
* **api:** manual updates ([d9c6430](https://github.com/TriallyAI/web-recruitment-sdk/commit/d9c6430d58745b12f76b08b8cb414b740d27ccb3))


### Chores

* **internal:** change ci workflow machines ([ce08789](https://github.com/TriallyAI/web-recruitment-sdk/commit/ce08789c9837bd184252c672b472e2fc6e033c72))
* update github action ([a1e2d76](https://github.com/TriallyAI/web-recruitment-sdk/commit/a1e2d76da45f82b26339f2ce1b9318abb168d1f1))

## 0.1.0-alpha.20 (2025-08-18)

Full Changelog: [v0.1.0-alpha.19...v0.1.0-alpha.20](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.19...v0.1.0-alpha.20)

### Features

* **api:** api update ([113be05](https://github.com/TriallyAI/web-recruitment-sdk/commit/113be05f7117dfeaf30f6f9a0e7bd9266f826882))
* **api:** api update ([292d3a4](https://github.com/TriallyAI/web-recruitment-sdk/commit/292d3a4270fc271960f55b391cb621d729e40e0c))
* **api:** manual updates ([6c383f6](https://github.com/TriallyAI/web-recruitment-sdk/commit/6c383f629ff42c4c7d6c415134befc12707470c5))

## 0.1.0-alpha.19 (2025-08-18)

Full Changelog: [v0.1.0-alpha.18...v0.1.0-alpha.19](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.18...v0.1.0-alpha.19)

### Features

* **api:** api update ([0abdd51](https://github.com/TriallyAI/web-recruitment-sdk/commit/0abdd517b6dc482057dc6f527b261fe0e60a7cb5))
* **api:** api update ([fcd7c0c](https://github.com/TriallyAI/web-recruitment-sdk/commit/fcd7c0c669c98389cd0d81ca1c3e215a7c833930))
* **api:** api update ([46f9dc4](https://github.com/TriallyAI/web-recruitment-sdk/commit/46f9dc4db80066c9267af52d6003d3f8395b5e2f))
* **api:** api update ([496e840](https://github.com/TriallyAI/web-recruitment-sdk/commit/496e84001f5a8156710a5de889fe2c842df35eae))
* **api:** api update ([24dba3f](https://github.com/TriallyAI/web-recruitment-sdk/commit/24dba3f7c98621e8ddd212a7a2092abd08b928a8))
* **api:** api update ([55dcebd](https://github.com/TriallyAI/web-recruitment-sdk/commit/55dcebde5c5ce52c8031f82c867ab337a94b93b3))
* **api:** api update ([c21a02b](https://github.com/TriallyAI/web-recruitment-sdk/commit/c21a02bfa4e0ff232f83f327ec549a34d1a01729))
* **api:** api update ([9aac033](https://github.com/TriallyAI/web-recruitment-sdk/commit/9aac0335e6b92da4712df73b77f0464897e44ca4))
* **api:** api update ([9490196](https://github.com/TriallyAI/web-recruitment-sdk/commit/9490196e6534ada1d0f0227ddc0dc2b9a09a2004))
* **api:** api update ([36d7b5f](https://github.com/TriallyAI/web-recruitment-sdk/commit/36d7b5f634622750823183c3ddf66141399603a5))
* **api:** api update ([e270f5e](https://github.com/TriallyAI/web-recruitment-sdk/commit/e270f5e1b7472aa509f91759ec130c3c9c66a7c7))
* **api:** api update ([eaa66fd](https://github.com/TriallyAI/web-recruitment-sdk/commit/eaa66fd653f86461034d4a7a33c5268b83970854))
* **api:** api update ([e11d3d5](https://github.com/TriallyAI/web-recruitment-sdk/commit/e11d3d521fec0c69e03e429291c400fbda40c175))
* **api:** api update ([5c1eb93](https://github.com/TriallyAI/web-recruitment-sdk/commit/5c1eb935d6e01611b51aa0a973e316cd605ca4f4))
* **api:** manual updates ([828f918](https://github.com/TriallyAI/web-recruitment-sdk/commit/828f9183d8ed1c258f115c920d1632a9fabda5ba))
* clean up environment call outs ([85c1c2e](https://github.com/TriallyAI/web-recruitment-sdk/commit/85c1c2ee273480cff8fe3b4c578dad53e1b08e8b))
* **client:** support file upload requests ([30d6dbd](https://github.com/TriallyAI/web-recruitment-sdk/commit/30d6dbd9f1f925c0a7fb67f806a70a4a78b20d1e))


### Bug Fixes

* **client:** don't send Content-Type header on GET requests ([fbb6a29](https://github.com/TriallyAI/web-recruitment-sdk/commit/fbb6a29107e469b83a4f9bc5589b26a2329c8c17))
* **parsing:** ignore empty metadata ([4596be4](https://github.com/TriallyAI/web-recruitment-sdk/commit/4596be49d91e10036991088bab26042ba000ce39))
* **parsing:** parse extra field types ([ce0b314](https://github.com/TriallyAI/web-recruitment-sdk/commit/ce0b314e8ceb2ba3991f2b1bbd3190811337bac2))


### Chores

* **internal:** codegen related update ([1d56236](https://github.com/TriallyAI/web-recruitment-sdk/commit/1d56236f05573021f8b6ea7bd219a0266197021b))
* **internal:** fix ruff target version ([80659b7](https://github.com/TriallyAI/web-recruitment-sdk/commit/80659b76fba90ad9a83e55cd5016cf0119b2548b))
* **internal:** update comment in script ([4195505](https://github.com/TriallyAI/web-recruitment-sdk/commit/4195505df7ead433021bb25923d7f5f8d50833d5))
* **project:** add settings file for vscode ([b40d1ff](https://github.com/TriallyAI/web-recruitment-sdk/commit/b40d1ff429810c960085d486f09c89918feabc8b))
* update @stainless-api/prism-cli to v5.15.0 ([1f47faa](https://github.com/TriallyAI/web-recruitment-sdk/commit/1f47faaf5317c92aabbcdf0fa50e222186a8bf17))

## 0.1.0-alpha.18 (2025-07-11)

Full Changelog: [v0.1.0-alpha.17...v0.1.0-alpha.18](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.17...v0.1.0-alpha.18)

### Features

* **api:** api update ([91fd19a](https://github.com/TriallyAI/web-recruitment-sdk/commit/91fd19a3245d0204d468a42964088787f928a281))
* **api:** manual updates ([78ebd0a](https://github.com/TriallyAI/web-recruitment-sdk/commit/78ebd0adc2bf4a2954c03b7f20cb105ec1fff4db))


### Bug Fixes

* **parsing:** correctly handle nested discriminated unions ([8533825](https://github.com/TriallyAI/web-recruitment-sdk/commit/85338259ce03e49d381eafa0e68676b585393290))


### Chores

* **internal:** bump pinned h11 dep ([8dbf3ae](https://github.com/TriallyAI/web-recruitment-sdk/commit/8dbf3aef5b284ef6726f3046688010655fcbbbcd))
* **package:** mark python 3.13 as supported ([b6e7ef1](https://github.com/TriallyAI/web-recruitment-sdk/commit/b6e7ef17fa1d1a4e20bc6a64f1682fd018487c1d))
* **readme:** fix version rendering on pypi ([a72cc88](https://github.com/TriallyAI/web-recruitment-sdk/commit/a72cc885001067c42869b0d3e0e9e02e19140242))

## 0.1.0-alpha.17 (2025-07-03)

Full Changelog: [v0.1.0-alpha.16...v0.1.0-alpha.17](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.16...v0.1.0-alpha.17)

### Features

* **api:** manual updates ([9788948](https://github.com/TriallyAI/web-recruitment-sdk/commit/9788948077796b805d59f638503a1f217cd785c7))


### Chores

* **ci:** change upload type ([28563a9](https://github.com/TriallyAI/web-recruitment-sdk/commit/28563a9e5ea9bc504acc128340e91e4fc640ced2))

## 0.1.0-alpha.16 (2025-06-30)

Full Changelog: [v0.1.0-alpha.15...v0.1.0-alpha.16](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.15...v0.1.0-alpha.16)

### Features

* **api:** manual updates ([537ffd6](https://github.com/TriallyAI/web-recruitment-sdk/commit/537ffd6d9b17709f8ae498247db43468fb32718f))
* **api:** manual updates ([f8ee5a4](https://github.com/TriallyAI/web-recruitment-sdk/commit/f8ee5a40df513b3aa23f3a1c52921b86c76b2e5f))

## 0.1.0-alpha.15 (2025-06-30)

Full Changelog: [v0.1.0-alpha.14...v0.1.0-alpha.15](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.14...v0.1.0-alpha.15)

### Features

* **api:** api update ([ed05270](https://github.com/TriallyAI/web-recruitment-sdk/commit/ed05270a801795affb7d017ae3742be2092fe098))
* **api:** api update ([4674c6d](https://github.com/TriallyAI/web-recruitment-sdk/commit/4674c6dc71b1a2c4dd534354edc472e94f79d8fe))
* **api:** api update ([bcb95e6](https://github.com/TriallyAI/web-recruitment-sdk/commit/bcb95e67a2507af6bd6da084219573a98d26b6ef))
* **api:** api update ([9cba9a8](https://github.com/TriallyAI/web-recruitment-sdk/commit/9cba9a8c0330177adf318039bdf46f93b35ceacb))
* **api:** api update ([3a00cc2](https://github.com/TriallyAI/web-recruitment-sdk/commit/3a00cc21c4d15eb383f701eedbe4af4849522e70))
* **api:** api update ([957a06a](https://github.com/TriallyAI/web-recruitment-sdk/commit/957a06af9c6f4c0b2838f141d37d773fe16823dd))
* **api:** api update ([c842fbd](https://github.com/TriallyAI/web-recruitment-sdk/commit/c842fbd180ed2746efaf5367cc3cbeaea2c45b75))
* **api:** api update ([e308370](https://github.com/TriallyAI/web-recruitment-sdk/commit/e308370ab988ead88c49ba0b18fe7930777c172a))
* **api:** api update ([0697f06](https://github.com/TriallyAI/web-recruitment-sdk/commit/0697f064ae17ff4dff7d114938e9df9ee5522df1))
* **api:** api update ([7263aca](https://github.com/TriallyAI/web-recruitment-sdk/commit/7263aca8abc7cf3928dec0c5d1eea727e2adc443))
* **api:** api update ([5e67198](https://github.com/TriallyAI/web-recruitment-sdk/commit/5e67198ec343a0276aee29528968ce4b445657f4))
* **api:** api update ([bf5c17b](https://github.com/TriallyAI/web-recruitment-sdk/commit/bf5c17b630036f520a46641f861b1a08af30ee14))
* **api:** api update ([4de11eb](https://github.com/TriallyAI/web-recruitment-sdk/commit/4de11eb0c69bc8255fb2662f5f3e2dfebb32b613))
* **api:** api update ([85cadd5](https://github.com/TriallyAI/web-recruitment-sdk/commit/85cadd58da98422a7b54cf6740c52fe3984ba977))
* **api:** api update ([50ee214](https://github.com/TriallyAI/web-recruitment-sdk/commit/50ee214be428cb5d787d9c11e36f7c4a42500976))
* **api:** api update ([e065bbb](https://github.com/TriallyAI/web-recruitment-sdk/commit/e065bbb22bf8d4d7ef777a9a7a841857a2e209de))
* **api:** update OpenAPI spec or Stainless config ([b5dec27](https://github.com/TriallyAI/web-recruitment-sdk/commit/b5dec27e91a105f585f296d873dc99b7575798ae))
* **client:** add follow_redirects request option ([c465511](https://github.com/TriallyAI/web-recruitment-sdk/commit/c4655118ab29eee036bc2fadf690ffaa6827ed99))
* **client:** add support for aiohttp ([e0a3af2](https://github.com/TriallyAI/web-recruitment-sdk/commit/e0a3af288b13ae507debb584f4664aba088bdf38))


### Bug Fixes

* **ci:** correct conditional ([b5af719](https://github.com/TriallyAI/web-recruitment-sdk/commit/b5af7196d99fe51c3ffd5c05bc89d04a55190158))
* **ci:** release-doctor — report correct token name ([466380c](https://github.com/TriallyAI/web-recruitment-sdk/commit/466380c44803c0e76a764ff318816413be488b02))
* **client:** correctly parse binary response | stream ([c7f37a5](https://github.com/TriallyAI/web-recruitment-sdk/commit/c7f37a5442fa596e142ea11e14058e469056c6af))
* **tests:** fix: tests which call HTTP endpoints directly with the example parameters ([1902261](https://github.com/TriallyAI/web-recruitment-sdk/commit/190226196d08353fab69267002e9befc35c9d5a4))


### Chores

* change publish docs url ([9d5d87b](https://github.com/TriallyAI/web-recruitment-sdk/commit/9d5d87bc2bcef8b6efe74cc159ce589a584c9834))
* **ci:** enable for pull requests ([84a26ae](https://github.com/TriallyAI/web-recruitment-sdk/commit/84a26ae70cba0e5c1777f076cd7b344dfd3b9df3))
* **ci:** only run for pushes and fork pull requests ([fd14fdf](https://github.com/TriallyAI/web-recruitment-sdk/commit/fd14fdf6f67ddb00be5a097b86ae615807934ba1))
* **docs:** remove reference to rye shell ([5e58a60](https://github.com/TriallyAI/web-recruitment-sdk/commit/5e58a60416bab4c0eeee0b0907a21ff45a82c9d2))
* **internal:** update conftest.py ([9033e3d](https://github.com/TriallyAI/web-recruitment-sdk/commit/9033e3d56b00a62e339247662e0c6eaf21745379))
* **readme:** update badges ([1de293c](https://github.com/TriallyAI/web-recruitment-sdk/commit/1de293c327afebdaddc5eaec4ddd86f4a4d68b93))
* **tests:** add tests for httpx client instantiation & proxies ([1c0d002](https://github.com/TriallyAI/web-recruitment-sdk/commit/1c0d002a35711690e6cdcb077a30ba48d9c68a02))
* **tests:** run tests in parallel ([1cee152](https://github.com/TriallyAI/web-recruitment-sdk/commit/1cee15267b357aa29c70222dd1c0b86b3cfedf5a))
* **tests:** skip some failing tests on the latest python versions ([0eff2cc](https://github.com/TriallyAI/web-recruitment-sdk/commit/0eff2cc22a16e375d01ed18cb6243aaff72a7c11))


### Documentation

* **client:** fix httpx.Timeout documentation reference ([0f48077](https://github.com/TriallyAI/web-recruitment-sdk/commit/0f480777460aca3c73c89719df182a1f89ee54d3))

## 0.1.0-alpha.14 (2025-05-28)

Full Changelog: [v0.1.0-alpha.13...v0.1.0-alpha.14](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.13...v0.1.0-alpha.14)

### Bug Fixes

* **docs/api:** remove references to nonexistent types ([5e39d51](https://github.com/TriallyAI/web-recruitment-sdk/commit/5e39d51afaecd426021c1544af6bc2a12ce47456))

## 0.1.0-alpha.13 (2025-05-26)

Full Changelog: [v0.1.0-alpha.12...v0.1.0-alpha.13](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.12...v0.1.0-alpha.13)

### Features

* **api:** manual updates ([0bca135](https://github.com/TriallyAI/web-recruitment-sdk/commit/0bca13552818136322be5e4567ed65ad481f2641))

## 0.1.0-alpha.12 (2025-05-24)

Full Changelog: [v0.1.0-alpha.11...v0.1.0-alpha.12](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.11...v0.1.0-alpha.12)

### Features

* **api:** manual updates ([76f20f3](https://github.com/TriallyAI/web-recruitment-sdk/commit/76f20f3e27f83e22156795e1f008c7fd2fdf648b))
* **api:** manual updates environment ([37375fe](https://github.com/TriallyAI/web-recruitment-sdk/commit/37375fe692916d7ca8ebfc88758ed6dca9dbe1c4))


### Chores

* **docs:** grammar improvements ([ff3f83a](https://github.com/TriallyAI/web-recruitment-sdk/commit/ff3f83a94d7389c2318be1684c0d4c3172b73fcd))

## 0.1.0-alpha.11 (2025-05-21)

Full Changelog: [v0.1.0-alpha.10...v0.1.0-alpha.11](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.10...v0.1.0-alpha.11)

### Chores

* **ci:** fix installation instructions ([4414e56](https://github.com/TriallyAI/web-recruitment-sdk/commit/4414e56683844ca16d5d801be7f252b9c03a0af2))
* **ci:** upload sdks to package manager ([24c0dc1](https://github.com/TriallyAI/web-recruitment-sdk/commit/24c0dc1a3791815f49bdd59830aeff93c41b7841))
* **internal:** codegen related update ([832b625](https://github.com/TriallyAI/web-recruitment-sdk/commit/832b625cea64f86b0e7b70fcfeccfef180c61e72))

## 0.1.0-alpha.10 (2025-05-20)

Full Changelog: [v0.1.0-alpha.9...v0.1.0-alpha.10](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.9...v0.1.0-alpha.10)

### Features

* **api:** api update ([a130f47](https://github.com/TriallyAI/web-recruitment-sdk/commit/a130f47ec0ad5f68d7c1af2ffe6e321464cf0a4d))
* **api:** api update ([3958609](https://github.com/TriallyAI/web-recruitment-sdk/commit/395860912b610479010491a832dffeb41202f59d))
* **api:** api update ([1329494](https://github.com/TriallyAI/web-recruitment-sdk/commit/1329494c99ef9ef644184e15f3f772fed4732660))
* **api:** api update ([d193452](https://github.com/TriallyAI/web-recruitment-sdk/commit/d193452d3514317bd0f22938f4e8a9bf7191c0b7))
* **api:** api update ([8705e7b](https://github.com/TriallyAI/web-recruitment-sdk/commit/8705e7be0cd689c3dabacc6075d3ecd3d38ce2f8))
* **api:** api update ([58a8933](https://github.com/TriallyAI/web-recruitment-sdk/commit/58a8933fcb3df966e3d2ce86c8f51afada2dc761))
* **api:** api update ([5f8f0b8](https://github.com/TriallyAI/web-recruitment-sdk/commit/5f8f0b8d7d1e2ac90fe8e5b1f5265778bd21f492))
* **api:** api update ([20491d3](https://github.com/TriallyAI/web-recruitment-sdk/commit/20491d3c39db3c01ed3e740700bd0b5cad508164))
* **api:** api update ([6b520a9](https://github.com/TriallyAI/web-recruitment-sdk/commit/6b520a9d53f5f9df7a2642c6610829f5dd1df850))
* **api:** api update ([90e1e9c](https://github.com/TriallyAI/web-recruitment-sdk/commit/90e1e9c44d3db23511463a687525d4c814085a15))
* **api:** api update ([e79bc72](https://github.com/TriallyAI/web-recruitment-sdk/commit/e79bc72b1a03db983278252d1b6666661199edd6))
* **api:** api update ([9193ce4](https://github.com/TriallyAI/web-recruitment-sdk/commit/9193ce4efc8ea1aa231010be845debe9c0603c03))
* **api:** api update ([1c7f19b](https://github.com/TriallyAI/web-recruitment-sdk/commit/1c7f19b5eec7d2d07bacbfcc8e4543afc169e58b))
* **api:** api update ([#110](https://github.com/TriallyAI/web-recruitment-sdk/issues/110)) ([c0424ec](https://github.com/TriallyAI/web-recruitment-sdk/commit/c0424eca2642432e68840519ce5bf27ad36f1fb8))
* **api:** api update ([#114](https://github.com/TriallyAI/web-recruitment-sdk/issues/114)) ([7bd71c7](https://github.com/TriallyAI/web-recruitment-sdk/commit/7bd71c7b8136c4a49c3014261dd9890d4ba46ed4))
* **api:** api update ([#116](https://github.com/TriallyAI/web-recruitment-sdk/issues/116)) ([cb2d822](https://github.com/TriallyAI/web-recruitment-sdk/commit/cb2d822b4d3cc99d098e039ea20a54d69297084b))
* **api:** api update ([#123](https://github.com/TriallyAI/web-recruitment-sdk/issues/123)) ([ac21963](https://github.com/TriallyAI/web-recruitment-sdk/commit/ac21963fbb73c0ff2a16e8036e29f5f0fd817925))
* **api:** api update ([#124](https://github.com/TriallyAI/web-recruitment-sdk/issues/124)) ([dbe5c8f](https://github.com/TriallyAI/web-recruitment-sdk/commit/dbe5c8fce4027352d304f681d8c0db8916d7150d))
* **api:** api update ([#125](https://github.com/TriallyAI/web-recruitment-sdk/issues/125)) ([f874d61](https://github.com/TriallyAI/web-recruitment-sdk/commit/f874d61fa5ff7d6c65651a11b77eeda682ce2b80))
* **api:** api update ([#126](https://github.com/TriallyAI/web-recruitment-sdk/issues/126)) ([6a3ee88](https://github.com/TriallyAI/web-recruitment-sdk/commit/6a3ee885d7895dac5edd5e52c49d6a5568fec976))
* **api:** api update ([#128](https://github.com/TriallyAI/web-recruitment-sdk/issues/128)) ([1fa18e1](https://github.com/TriallyAI/web-recruitment-sdk/commit/1fa18e1617a9f8eba68e1c8366959a7ad7a934fc))
* **api:** api update ([#130](https://github.com/TriallyAI/web-recruitment-sdk/issues/130)) ([940beb1](https://github.com/TriallyAI/web-recruitment-sdk/commit/940beb16f73eb4ab7d8503c59adf2d3463e8286a))
* **client:** allow passing `NotGiven` for body ([#104](https://github.com/TriallyAI/web-recruitment-sdk/issues/104)) ([5b53a40](https://github.com/TriallyAI/web-recruitment-sdk/commit/5b53a40954088f6e7835db467b6cd4e85e377640))


### Bug Fixes

* **ci:** ensure pip is always available ([#121](https://github.com/TriallyAI/web-recruitment-sdk/issues/121)) ([bed6f83](https://github.com/TriallyAI/web-recruitment-sdk/commit/bed6f83d442b5021b172a09617546c755cd53090))
* **ci:** remove publishing patch ([#122](https://github.com/TriallyAI/web-recruitment-sdk/issues/122)) ([300cb6e](https://github.com/TriallyAI/web-recruitment-sdk/commit/300cb6ea2cb2ab4e3b7be2091f17d2e44194d588))
* **client:** mark some request bodies as optional ([5b53a40](https://github.com/TriallyAI/web-recruitment-sdk/commit/5b53a40954088f6e7835db467b6cd4e85e377640))
* **package:** support direct resource imports ([00add07](https://github.com/TriallyAI/web-recruitment-sdk/commit/00add07028a2681c7f047f61af310b6733379a4b))
* **perf:** optimize some hot paths ([74fef4d](https://github.com/TriallyAI/web-recruitment-sdk/commit/74fef4db38f46971ee4a5aa748abbec53e8ee035))
* **perf:** skip traversing types for NotGiven values ([16f9529](https://github.com/TriallyAI/web-recruitment-sdk/commit/16f95293cd5fd2415fcfd5e83696427ce7b29e71))
* **pydantic v1:** more robust ModelField.annotation check ([73188a4](https://github.com/TriallyAI/web-recruitment-sdk/commit/73188a47af005f0c1f77501c8ed63d781ee3ca32))
* **types:** handle more discriminated union shapes ([#120](https://github.com/TriallyAI/web-recruitment-sdk/issues/120)) ([0357e6c](https://github.com/TriallyAI/web-recruitment-sdk/commit/0357e6c48a796eef17b217bed56b1f1d0c06543b))


### Chores

* broadly detect json family of content-type headers ([6c01488](https://github.com/TriallyAI/web-recruitment-sdk/commit/6c01488c691983bcedf77d8322786204a9454839))
* **ci:** add timeout thresholds for CI jobs ([ba8bbac](https://github.com/TriallyAI/web-recruitment-sdk/commit/ba8bbaceb338c17b7f648f3d35734d97b80b84e6))
* **ci:** only use depot for staging repos ([1abfc1d](https://github.com/TriallyAI/web-recruitment-sdk/commit/1abfc1dfa480de8f91a6d48583b77af4c896f463))
* **client:** minor internal fixes ([d3481d3](https://github.com/TriallyAI/web-recruitment-sdk/commit/d3481d3450bdb406c2bc14824cc7dafa308cd638))
* **docs:** update client docstring ([#112](https://github.com/TriallyAI/web-recruitment-sdk/issues/112)) ([dcf0e86](https://github.com/TriallyAI/web-recruitment-sdk/commit/dcf0e86db3b4ad4c3aa55eecca8570b7b1275363))
* fix typos ([#127](https://github.com/TriallyAI/web-recruitment-sdk/issues/127)) ([0336bd9](https://github.com/TriallyAI/web-recruitment-sdk/commit/0336bd97061f35cdba9ba2642a3f57ac9c84a8b4))
* **internal:** avoid errors for isinstance checks on proxies ([4271bd8](https://github.com/TriallyAI/web-recruitment-sdk/commit/4271bd8ac4addde1e082917726c94dea168504ef))
* **internal:** base client updates ([d9fce5d](https://github.com/TriallyAI/web-recruitment-sdk/commit/d9fce5d58946b18175b32ad29cb12b3af07c7670))
* **internal:** bump pyright version ([31847cd](https://github.com/TriallyAI/web-recruitment-sdk/commit/31847cd2807af2435321098b332395b85021be25))
* **internal:** bump rye to 0.44.0 ([#119](https://github.com/TriallyAI/web-recruitment-sdk/issues/119)) ([1b68c87](https://github.com/TriallyAI/web-recruitment-sdk/commit/1b68c8744dfee0b9ff35807bdf13b31e7657f68d))
* **internal:** codegen related update ([40bb6f3](https://github.com/TriallyAI/web-recruitment-sdk/commit/40bb6f303e0937e6203bb3b4c5bfbcf05d13df7c))
* **internal:** codegen related update ([#108](https://github.com/TriallyAI/web-recruitment-sdk/issues/108)) ([b9aabab](https://github.com/TriallyAI/web-recruitment-sdk/commit/b9aababa8dd567f1b7150e035eb1a38265915a32))
* **internal:** codegen related update ([#109](https://github.com/TriallyAI/web-recruitment-sdk/issues/109)) ([a30ff7e](https://github.com/TriallyAI/web-recruitment-sdk/commit/a30ff7e2bf6462ec688422dd2a576740eca40435))
* **internal:** codegen related update ([#118](https://github.com/TriallyAI/web-recruitment-sdk/issues/118)) ([9af29c7](https://github.com/TriallyAI/web-recruitment-sdk/commit/9af29c77cc6ab53db994b4af3ae75d962b51af9e))
* **internal:** expand CI branch coverage ([fef2266](https://github.com/TriallyAI/web-recruitment-sdk/commit/fef2266b61b3ad749070659062a7085cfbe7c13e))
* **internal:** fix devcontainers setup ([#106](https://github.com/TriallyAI/web-recruitment-sdk/issues/106)) ([4d0cfb9](https://github.com/TriallyAI/web-recruitment-sdk/commit/4d0cfb98153ed1f8370497ce40a1bdabed372a23))
* **internal:** fix list file params ([1656b21](https://github.com/TriallyAI/web-recruitment-sdk/commit/1656b214a48f1cf6f987f32a92a975a27cfaf044))
* **internal:** import reformatting ([200e092](https://github.com/TriallyAI/web-recruitment-sdk/commit/200e092046ba875b5d39ed2c3481ba500a53bd99))
* **internal:** properly set __pydantic_private__ ([#107](https://github.com/TriallyAI/web-recruitment-sdk/issues/107)) ([5dec817](https://github.com/TriallyAI/web-recruitment-sdk/commit/5dec81743be59d6766060a87bc32767b5e0fb1c3))
* **internal:** reduce CI branch coverage ([427be90](https://github.com/TriallyAI/web-recruitment-sdk/commit/427be909dd1378665cc7c2011ec5a0e398789d70))
* **internal:** refactor retries to not use recursion ([4086957](https://github.com/TriallyAI/web-recruitment-sdk/commit/40869573e05d50bf197bf8157daf915f935cd9f0))
* **internal:** remove extra empty newlines ([#117](https://github.com/TriallyAI/web-recruitment-sdk/issues/117)) ([2424cc7](https://github.com/TriallyAI/web-recruitment-sdk/commit/2424cc70b9a488c54b6cdeb91ea8a5cd52d17e89))
* **internal:** remove trailing character ([#129](https://github.com/TriallyAI/web-recruitment-sdk/issues/129)) ([aac80ef](https://github.com/TriallyAI/web-recruitment-sdk/commit/aac80ef24b278fa48c34ca03dd0fa7687e184fcd))
* **internal:** remove unused http client options forwarding ([#113](https://github.com/TriallyAI/web-recruitment-sdk/issues/113)) ([fdab1f7](https://github.com/TriallyAI/web-recruitment-sdk/commit/fdab1f7475528854c8e37c3cdf2904f066b36701))
* **internal:** slight transform perf improvement ([#131](https://github.com/TriallyAI/web-recruitment-sdk/issues/131)) ([5adcfee](https://github.com/TriallyAI/web-recruitment-sdk/commit/5adcfeeb534a293cbe3afeb0d66676a1e52629eb))
* **internal:** update models test ([a1689a9](https://github.com/TriallyAI/web-recruitment-sdk/commit/a1689a9f039d8a48d196936cdd84963c88b207fb))
* **internal:** update pyright settings ([59c77e7](https://github.com/TriallyAI/web-recruitment-sdk/commit/59c77e7ff667679647e80871ca2198a3a92f4171))
* remove custom code ([ed43ecd](https://github.com/TriallyAI/web-recruitment-sdk/commit/ed43ecd89a79ea7a02cac43b284f06680c56f275))
* slight wording improvement in README ([#132](https://github.com/TriallyAI/web-recruitment-sdk/issues/132)) ([e4c4430](https://github.com/TriallyAI/web-recruitment-sdk/commit/e4c4430775fcb521fdbf95c2b269bd259938c686))


### Documentation

* update URLs from stainlessapi.com to stainless.com ([#111](https://github.com/TriallyAI/web-recruitment-sdk/issues/111)) ([eb4d298](https://github.com/TriallyAI/web-recruitment-sdk/commit/eb4d298a8607e793f17c2b0bec75a6b7125ddb1d))

## 0.1.0-alpha.9 (2025-02-19)

Full Changelog: [v0.1.0-alpha.8...v0.1.0-alpha.9](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.8...v0.1.0-alpha.9)

### Features

* **api:** api update ([#101](https://github.com/TriallyAI/web-recruitment-sdk/issues/101)) ([928bdf4](https://github.com/TriallyAI/web-recruitment-sdk/commit/928bdf4bba3c492c0c41c510e09fb01877e165ab))
* **api:** api update ([#97](https://github.com/TriallyAI/web-recruitment-sdk/issues/97)) ([b8379a5](https://github.com/TriallyAI/web-recruitment-sdk/commit/b8379a51d224a46300d441175b2a6ee2afe8101a))
* **api:** manual updates ([#100](https://github.com/TriallyAI/web-recruitment-sdk/issues/100)) ([e1373c9](https://github.com/TriallyAI/web-recruitment-sdk/commit/e1373c9c95094e618cf14b594cdb5c754b4b17f7))
* **api:** manual updates ([#102](https://github.com/TriallyAI/web-recruitment-sdk/issues/102)) ([3d020bb](https://github.com/TriallyAI/web-recruitment-sdk/commit/3d020bbbf2eff80d84106c7ae63e3d5f64f23e6b))
* **api:** manual updates ([#94](https://github.com/TriallyAI/web-recruitment-sdk/issues/94)) ([0007091](https://github.com/TriallyAI/web-recruitment-sdk/commit/00070918dea1585f34a9b083a23ebf4a188a6cd6))
* **api:** manual updates ([#96](https://github.com/TriallyAI/web-recruitment-sdk/issues/96)) ([6ed55a0](https://github.com/TriallyAI/web-recruitment-sdk/commit/6ed55a0b68d89ddc417afb28c1640673057b4424))
* **api:** manual updates ([#98](https://github.com/TriallyAI/web-recruitment-sdk/issues/98)) ([5ab59e5](https://github.com/TriallyAI/web-recruitment-sdk/commit/5ab59e55e40cd28cc87249b77b23533d11ca5d2f))


### Chores

* **internal:** codegen related update ([#99](https://github.com/TriallyAI/web-recruitment-sdk/issues/99)) ([c4dee00](https://github.com/TriallyAI/web-recruitment-sdk/commit/c4dee00bec697b4cc59146fb3830c32a14329286))

## 0.1.0-alpha.8 (2025-02-18)

Full Changelog: [v0.1.0-alpha.7...v0.1.0-alpha.8](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.7...v0.1.0-alpha.8)

### Features

* **api:** manual updates ([#92](https://github.com/TriallyAI/web-recruitment-sdk/issues/92)) ([8a32ee5](https://github.com/TriallyAI/web-recruitment-sdk/commit/8a32ee556f913cbffd377aa53a9586082e8d723a))


### Bug Fixes

* asyncify on non-asyncio runtimes ([#91](https://github.com/TriallyAI/web-recruitment-sdk/issues/91)) ([cf985d6](https://github.com/TriallyAI/web-recruitment-sdk/commit/cf985d662379f57a3cc42482e949e89bd670a856))


### Chores

* **internal:** update client tests ([#89](https://github.com/TriallyAI/web-recruitment-sdk/issues/89)) ([2bb7ff4](https://github.com/TriallyAI/web-recruitment-sdk/commit/2bb7ff4760f9b05b877ec3a6e7dff14895b26c15))

## 0.1.0-alpha.7 (2025-02-07)

Full Changelog: [v0.1.0-alpha.6...v0.1.0-alpha.7](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.6...v0.1.0-alpha.7)

### Features

* **client:** send `X-Stainless-Read-Timeout` header ([#85](https://github.com/TriallyAI/web-recruitment-sdk/issues/85)) ([26bad75](https://github.com/TriallyAI/web-recruitment-sdk/commit/26bad75e7045c34f799f4d89fc704c4ecb064808))


### Bug Fixes

* improve names for conflicting params ([#84](https://github.com/TriallyAI/web-recruitment-sdk/issues/84)) ([45a7849](https://github.com/TriallyAI/web-recruitment-sdk/commit/45a78496fe7436332859a9f63c07b417fa1ef8cc))


### Chores

* **internal:** bummp ruff dependency ([#83](https://github.com/TriallyAI/web-recruitment-sdk/issues/83)) ([6ec79ad](https://github.com/TriallyAI/web-recruitment-sdk/commit/6ec79adc54d48ac8ac507f2289c96713ff1bc04c))
* **internal:** change default timeout to an int ([#81](https://github.com/TriallyAI/web-recruitment-sdk/issues/81)) ([4ba8425](https://github.com/TriallyAI/web-recruitment-sdk/commit/4ba842592fb8f237707002b4b5d34917477538fa))
* **internal:** fix type traversing dictionary params ([#86](https://github.com/TriallyAI/web-recruitment-sdk/issues/86)) ([ac91850](https://github.com/TriallyAI/web-recruitment-sdk/commit/ac918504894de61300a49557dad4131589aa7984))
* **internal:** minor type handling changes ([#87](https://github.com/TriallyAI/web-recruitment-sdk/issues/87)) ([fa4b0e5](https://github.com/TriallyAI/web-recruitment-sdk/commit/fa4b0e5b3b732bba096d9f9b2bc8469828063abd))

## 0.1.0-alpha.6 (2025-01-31)

Full Changelog: [v0.1.0-alpha.5...v0.1.0-alpha.6](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.5...v0.1.0-alpha.6)

### Features

* **api:** api update ([#68](https://github.com/TriallyAI/web-recruitment-sdk/issues/68)) ([dfdd082](https://github.com/TriallyAI/web-recruitment-sdk/commit/dfdd082e60a1c8563254992cb2c9d54e18ceaba1))
* **api:** api update ([#70](https://github.com/TriallyAI/web-recruitment-sdk/issues/70)) ([eaf0780](https://github.com/TriallyAI/web-recruitment-sdk/commit/eaf0780170d5f3a6cd719ca039e55091f9b80869))
* **api:** api update ([#75](https://github.com/TriallyAI/web-recruitment-sdk/issues/75)) ([af8b300](https://github.com/TriallyAI/web-recruitment-sdk/commit/af8b3003bb2ccc834aff7512c3dfd9dfeca1b370))
* **api:** api update ([#78](https://github.com/TriallyAI/web-recruitment-sdk/issues/78)) ([98e47e9](https://github.com/TriallyAI/web-recruitment-sdk/commit/98e47e96d2bc4202ffc417ca51db530b2729d264))
* **api:** api update ([#79](https://github.com/TriallyAI/web-recruitment-sdk/issues/79)) ([3fe7552](https://github.com/TriallyAI/web-recruitment-sdk/commit/3fe7552ee13bbd3c1e5009b74a86accdf7734cb0))


### Bug Fixes

* **tests:** make test_get_platform less flaky ([#73](https://github.com/TriallyAI/web-recruitment-sdk/issues/73)) ([a27daa5](https://github.com/TriallyAI/web-recruitment-sdk/commit/a27daa5263e9f0200c4f031ee0bfed4626e64114))


### Chores

* **internal:** avoid pytest-asyncio deprecation warning ([#74](https://github.com/TriallyAI/web-recruitment-sdk/issues/74)) ([df8a825](https://github.com/TriallyAI/web-recruitment-sdk/commit/df8a825b31f929dcd0bedf78de43518b206f52f0))
* **internal:** codegen related update ([#66](https://github.com/TriallyAI/web-recruitment-sdk/issues/66)) ([58c41be](https://github.com/TriallyAI/web-recruitment-sdk/commit/58c41beaa8202dbca8e7173d049292c79da59cfe))
* **internal:** codegen related update ([#69](https://github.com/TriallyAI/web-recruitment-sdk/issues/69)) ([2e68b7b](https://github.com/TriallyAI/web-recruitment-sdk/commit/2e68b7b2db30cc5918eae712e66fc2440fdf1ca3))
* **internal:** codegen related update ([#71](https://github.com/TriallyAI/web-recruitment-sdk/issues/71)) ([3ebbae7](https://github.com/TriallyAI/web-recruitment-sdk/commit/3ebbae7a96503116542b3f09e7e2a65a3681aa2e))
* **internal:** codegen related update ([#76](https://github.com/TriallyAI/web-recruitment-sdk/issues/76)) ([f5da4bb](https://github.com/TriallyAI/web-recruitment-sdk/commit/f5da4bb9468133b7b674e968f8de92b9ca9d2603))
* **internal:** minor formatting changes ([#77](https://github.com/TriallyAI/web-recruitment-sdk/issues/77)) ([9665264](https://github.com/TriallyAI/web-recruitment-sdk/commit/9665264b3c46d0433590d9f1881139cf45534ecb))


### Documentation

* **raw responses:** fix duplicate `the` ([#72](https://github.com/TriallyAI/web-recruitment-sdk/issues/72)) ([ed8b6a3](https://github.com/TriallyAI/web-recruitment-sdk/commit/ed8b6a31f6df588b373fa6a60aad1643cc262161))

## 0.1.0-alpha.5 (2025-01-09)

Full Changelog: [v0.1.0-alpha.4...v0.1.0-alpha.5](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.4...v0.1.0-alpha.5)

### Features

* **api:** api update ([#64](https://github.com/TriallyAI/web-recruitment-sdk/issues/64)) ([523e3be](https://github.com/TriallyAI/web-recruitment-sdk/commit/523e3be9487e659e1238111eb8d6922b200c7568))


### Bug Fixes

* **client:** only call .close() when needed ([#61](https://github.com/TriallyAI/web-recruitment-sdk/issues/61)) ([9c9ec08](https://github.com/TriallyAI/web-recruitment-sdk/commit/9c9ec083e39bc471b4e2a181bdebe310b355f815))


### Chores

* **internal:** bump httpx dependency ([#59](https://github.com/TriallyAI/web-recruitment-sdk/issues/59)) ([745d402](https://github.com/TriallyAI/web-recruitment-sdk/commit/745d402c17d15d612bf5dbfe07b24f83f422defe))
* **internal:** codegen related update ([#63](https://github.com/TriallyAI/web-recruitment-sdk/issues/63)) ([eb1e588](https://github.com/TriallyAI/web-recruitment-sdk/commit/eb1e58868878029c14b2ae368e46fe1c65a68ca1))


### Documentation

* fix typos ([#62](https://github.com/TriallyAI/web-recruitment-sdk/issues/62)) ([6757907](https://github.com/TriallyAI/web-recruitment-sdk/commit/67579072d139e00f1d50ab0c5708614726ed313e))

## 0.1.0-alpha.4 (2025-01-08)

Full Changelog: [v0.1.0-alpha.3...v0.1.0-alpha.4](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.3...v0.1.0-alpha.4)

### Features

* **api:** manual updates ([#56](https://github.com/TriallyAI/web-recruitment-sdk/issues/56)) ([19e6939](https://github.com/TriallyAI/web-recruitment-sdk/commit/19e69395b033ea9fb47d0b564ccccc148a8e2103))

## 0.1.0-alpha.3 (2025-01-08)

Full Changelog: [v0.1.0-alpha.2...v0.1.0-alpha.3](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.2...v0.1.0-alpha.3)

### Features

* **api:** api update ([#54](https://github.com/TriallyAI/web-recruitment-sdk/issues/54)) ([4652c13](https://github.com/TriallyAI/web-recruitment-sdk/commit/4652c131457f6eff245297887da4e7f991f765c3))


### Chores

* **internal:** codegen related update ([#52](https://github.com/TriallyAI/web-recruitment-sdk/issues/52)) ([df00c7d](https://github.com/TriallyAI/web-recruitment-sdk/commit/df00c7d53837a3cb68383560e8bd311d9d3790f3))

## 0.1.0-alpha.2 (2025-01-06)

Full Changelog: [v0.1.0-alpha.1...v0.1.0-alpha.2](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.1.0-alpha.1...v0.1.0-alpha.2)

### Features

* **api:** update via SDK Studio ([#43](https://github.com/TriallyAI/web-recruitment-sdk/issues/43)) ([245adca](https://github.com/TriallyAI/web-recruitment-sdk/commit/245adcaa50e9a2bd1709b14128ffc9fcd4561050))
* **api:** update via SDK Studio ([#45](https://github.com/TriallyAI/web-recruitment-sdk/issues/45)) ([b22b107](https://github.com/TriallyAI/web-recruitment-sdk/commit/b22b10786f3f4bfa2797558949a8f57210b297c5))
* **api:** update via SDK Studio ([#46](https://github.com/TriallyAI/web-recruitment-sdk/issues/46)) ([e6d9808](https://github.com/TriallyAI/web-recruitment-sdk/commit/e6d9808a0d805b8824af02e6771ab03e3d2e8b0c))
* **api:** update via SDK Studio ([#47](https://github.com/TriallyAI/web-recruitment-sdk/issues/47)) ([f384267](https://github.com/TriallyAI/web-recruitment-sdk/commit/f384267a2121dff1d0b17ce4e0fb686795dd8a12))
* **api:** update via SDK Studio ([#48](https://github.com/TriallyAI/web-recruitment-sdk/issues/48)) ([48e47af](https://github.com/TriallyAI/web-recruitment-sdk/commit/48e47af67509f3de41e988a9ee0a973cf81aa4a8))
* **api:** update via SDK Studio ([#49](https://github.com/TriallyAI/web-recruitment-sdk/issues/49)) ([2b43ecf](https://github.com/TriallyAI/web-recruitment-sdk/commit/2b43ecfce1886ce3ffde7025abf01a78671e1b5c))
* **api:** update via SDK Studio ([#50](https://github.com/TriallyAI/web-recruitment-sdk/issues/50)) ([89733d0](https://github.com/TriallyAI/web-recruitment-sdk/commit/89733d0f32944c324611ea9aa1fdad1531d01472))

## 0.1.0-alpha.1 (2025-01-03)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/TriallyAI/web-recruitment-sdk/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

* **api:** update via SDK Studio ([#38](https://github.com/TriallyAI/web-recruitment-sdk/issues/38)) ([452fba8](https://github.com/TriallyAI/web-recruitment-sdk/commit/452fba802670beec6d319a9d8475346abbaa69d2))
* **api:** update via SDK Studio ([#39](https://github.com/TriallyAI/web-recruitment-sdk/issues/39)) ([5b231cd](https://github.com/TriallyAI/web-recruitment-sdk/commit/5b231cd34ca1345dc82ca72bd3118f52574c70a6))
* **api:** update via SDK Studio ([#41](https://github.com/TriallyAI/web-recruitment-sdk/issues/41)) ([43acddf](https://github.com/TriallyAI/web-recruitment-sdk/commit/43acddf03d26706ebf9d0c010d0dec322c9542d4))


### Chores

* go live ([#36](https://github.com/TriallyAI/web-recruitment-sdk/issues/36)) ([e3af34b](https://github.com/TriallyAI/web-recruitment-sdk/commit/e3af34b257bb97df4f627a0ca8646953a113c768))
* **internal:** codegen related update ([#40](https://github.com/TriallyAI/web-recruitment-sdk/issues/40)) ([5c0224c](https://github.com/TriallyAI/web-recruitment-sdk/commit/5c0224c9cd03ffa1e05a60c91ee88777d4999f23))
