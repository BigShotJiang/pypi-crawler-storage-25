from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, time
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

# Column headers (French accounting labels — kept as-is per client requirement)
HEADERS = [
    "Statut",
    "Jour",
    "Pièce",
    "Document",
    "Compte général",
    "Compte auxiliaire",
    "Libellé",
    "Débit",
    "Crédit",
    "Date de l'échéance",
    "Documents associés",
]


@dataclass
class Invoice:
    client: str
    date_iso: str  # "YYYY-MM-DD"
    total_ttc: float
    reference: str = ""  # Compte auxiliaire (client accounting code)


def _parse_iso_date(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


def _money(x: float) -> float:
    return round(x + 1e-12, 2)


def _zfill_int(n: int, width: int) -> str:
    return str(n).zfill(width)


def invoice_to_rows(
    inv: Invoice,
    *,
    piece: str,
    document: str,
    statut: str = "",
    tva_rate: float = 0.20,
) -> list[list[Any]]:
    d = _parse_iso_date(inv.date_iso)  # date
    jour_dt = datetime.combine(d, time.min)  # datetime (00:00:00)

    ttc = _money(inv.total_ttc)
    ht = _money(ttc / (1 + tva_rate))
    tva = _money(ttc - ht)

    # Columns: Status, Date, Piece, Document, General account, Auxiliary account,
    #          Label, Debit, Credit, Due date, Associated docs
    return [
        [statut, jour_dt, piece, document, "411", inv.reference, inv.client, ttc, "", d, ""],
        [statut, jour_dt, piece, document, "44571", "", inv.client, "", tva, "", ""],
        [statut, jour_dt, piece, document, "701", "", inv.client, "", ht, "", ""],
    ]


def style_as_table(ws) -> None:
    thin = Side(style="thin")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    header_fill = PatternFill("solid", fgColor="E6E6E6")
    header_font = Font(bold=True)
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    align_left = Alignment(horizontal="left", vertical="center")
    align_center = Alignment(horizontal="center", vertical="center")
    align_right = Alignment(horizontal="right", vertical="center")

    max_row = ws.max_row
    max_col = ws.max_column

    # Header style (row 1)
    for c in range(1, max_col + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = header_align
        cell.border = border

    # Body: borders + default alignment
    for r in range(2, max_row + 1):
        for c in range(1, max_col + 1):
            cell = ws.cell(row=r, column=c)
            cell.border = border
            cell.alignment = align_left

    # Per-column alignments (A..K)
    center_cols = ["A", "B", "C", "D", "E", "F", "J", "K"]
    right_cols = ["H", "I"]
    left_cols = ["G"]

    for col in center_cols:
        for r in range(2, max_row + 1):
            ws[f"{col}{r}"].alignment = align_center

    for col in right_cols:
        for r in range(2, max_row + 1):
            ws[f"{col}{r}"].alignment = align_right

    for col in left_cols:
        for r in range(2, max_row + 1):
            ws[f"{col}{r}"].alignment = align_left

    # Number formats
    # Date column (B): datetime, Due-date column (J): date, Amount columns (H/I)
    for r in range(2, max_row + 1):
        ws[f"B{r}"].number_format = "dd/mm/yyyy hh:mm:ss"
        ws[f"J{r}"].number_format = "dd/mm/yyyy"
        ws[f"H{r}"].number_format = "#,##0.00"
        ws[f"I{r}"].number_format = "#,##0.00"

    # Column widths (adjust as needed)
    widths = {
        "A": 10,
        "B": 20,
        "C": 8,
        "D": 10,
        "E": 14,
        "F": 16,
        "G": 40,
        "H": 12,
        "I": 12,
        "J": 16,
        "K": 20,
    }
    for col, w in widths.items():
        ws.column_dimensions[col].width = w

    # Header row height
    ws.row_dimensions[1].height = 20

    # Freeze + Filter
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(max_col)}{max_row}"


def write_xlsx_many(
    rows_all: list[list[Any]],
    output_path: str,
    *,
    sheet_name: str = "EBIA",
    include_headers: bool = True,
) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name

    # Header
    if include_headers:
        ws.append(HEADERS)

    # Data
    for r in rows_all:
        ws.append(r)

    # Apply table style (must run after all rows are written)
    if include_headers and ws.max_row >= 1 and ws.max_column >= 1:
        style_as_table(ws)

    wb.save(output_path)


def generate_xlsx_single(
    invoice_dict: dict,
    output_path: str,
    *,
    piece: str,
    document: str,
    tva_rate: float = 0.20,
    include_headers: bool = True,
) -> None:
    client = (invoice_dict.get("Client") or "").strip()
    date_iso = (invoice_dict.get("date") or "").strip()
    total_ttc = invoice_dict.get("total_ttc")
    reference = (invoice_dict.get("reference") or "").strip()

    if not client:
        raise ValueError("Missing 'Client'")
    if not date_iso:
        raise ValueError("Missing 'date' (expected YYYY-MM-DD)")
    if total_ttc is None:
        raise ValueError("Missing 'total_ttc'")

    inv = Invoice(client=client, date_iso=date_iso, total_ttc=float(total_ttc), reference=reference)
    rows = invoice_to_rows(inv, piece=piece, document=document, statut="", tva_rate=tva_rate)
    write_xlsx_many(rows, output_path, include_headers=include_headers)


def generate_xlsx_by_month_day(
    invoice_dicts: list[dict],
    output_dir: str,
    *,
    start_piece: int = 1,
    start_document: int = 1,
    start_by_month: dict[tuple[int, int], int] | None = None,
    piece_start_by_month: dict[tuple[int, int], int] | None = None,
    piece_width: int = 4,
    document_width: int = 5,
    tva_rate: float = 0.20,
    include_headers: bool = True,
) -> list[str]:
    """Generate one .xlsx per month, with one sheet per day inside each workbook.

    Invoices are sorted by date before numbering so piece/document counters
    are assigned in chronological order across all months.

    ``start_by_month`` — when provided, each month's *document* counter starts
    from the given value (keyed by ``(year, month)``).  This is the preferred
    mode for documents: ensures a second run continues from where the first left
    off.  ``start_piece`` / ``start_document`` are fallbacks when neither dict
    is given.

    ``piece_start_by_month`` — when provided, each month's *piece* counter uses
    this dict instead of ``start_by_month``.  Pass this when piece numbering
    must carry over across months within an accounting exercise (independent of
    the per-calendar-year document counter).

    Returns the list of generated file paths.
    """
    logger.info(
        "Starting Excel generation: %d invoice dict(s), output_dir=%s",
        len(invoice_dicts),
        output_dir,
    )

    # --- 1. Parse & validate all invoice dicts ---
    valid: list[tuple[Invoice, date]] = []
    skipped = 0
    for inv_dict in invoice_dicts:
        client = (inv_dict.get("Client") or "").strip()
        date_iso = (inv_dict.get("date") or "").strip()
        total_ttc = inv_dict.get("total_ttc")
        reference = (inv_dict.get("reference") or "").strip()
        if not client or not date_iso or total_ttc is None:
            logger.warning("Skipping incomplete invoice dict: %s", inv_dict)
            skipped += 1
            continue
        inv = Invoice(
            client=client, date_iso=date_iso, total_ttc=float(total_ttc), reference=reference
        )
        logger.debug(
            "Invoice queued: client=%-15s  date=%s  ttc=%.2f  ref=%s",
            client,
            date_iso,
            float(total_ttc),
            reference or "—",
        )
        valid.append((inv, _parse_iso_date(date_iso)))

    if skipped:
        logger.warning("%d invoice(s) skipped due to missing fields", skipped)

    # Sort chronologically so piece/document numbering follows invoice date order
    valid.sort(key=lambda t: t[1])

    # --- 2. Group by (year, month), then by day ---
    # Grouping happens before numbering so counters can reset per month.
    by_month_raw: dict[tuple[int, int], list[tuple[Invoice, date]]] = defaultdict(list)
    for inv, d in valid:
        by_month_raw[(d.year, d.month)].append((inv, d))

    # --- 3. Assign piece / document numbers ---
    # piece_start_by_month controls the Pièce column; start_by_month controls
    # the Document column.  When piece_start_by_month is None, pieces fall back
    # to start_by_month (backward-compatible).  When neither dict is given, the
    # legacy fallback resets both to 1 for every month after the first.
    by_month: dict[tuple[int, int], dict[int, list[tuple[Invoice, str, str]]]] = defaultdict(
        lambda: defaultdict(list)
    )
    piece_start = start_piece
    doc_start = start_document
    for month_key in sorted(by_month_raw):
        # Document counter start for this month
        if start_by_month is not None:
            doc_n = start_by_month.get(month_key, 1)
        else:
            doc_n = doc_start

        # Piece counter start for this month
        if piece_start_by_month is not None:
            piece_n = piece_start_by_month.get(month_key, 1)
        elif start_by_month is not None:
            piece_n = start_by_month.get(month_key, 1)
        else:
            piece_n = piece_start

        for inv, d in by_month_raw[month_key]:
            piece = _zfill_int(piece_n, piece_width)
            document = _zfill_int(doc_n, document_width)
            by_month[month_key][d.day].append((inv, piece, document))
            piece_n += 1
            doc_n += 1
        if start_by_month is None:
            # Legacy fallback: reset to 1 for all subsequent months
            piece_start = 1
            doc_start = 1

    # --- 4. Write one workbook per month ---
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    generated: list[str] = []

    for (year, month), days in sorted(by_month.items()):
        wb = Workbook()
        wb.remove(wb.active)  # drop the default empty sheet

        for day in sorted(days.keys()):
            sheet_name = f"{day:02d}"
            ws = wb.create_sheet(title=sheet_name)

            if include_headers:
                ws.append(HEADERS)

            for inv, piece, document in days[day]:
                logger.debug(
                    "  Sheet %s/%02d — piece=%s doc=%s client=%s ttc=%.2f",
                    f"{year}-{month:02d}",
                    day,
                    piece,
                    document,
                    inv.client,
                    inv.total_ttc,
                )
                for row in invoice_to_rows(inv, piece=piece, document=document, tva_rate=tva_rate):
                    ws.append(row)

            if include_headers and ws.max_row >= 1 and ws.max_column >= 1:
                style_as_table(ws)
            logger.debug("  Sheet '%s' written: %d data row(s)", sheet_name, ws.max_row - 1)

        filepath = str(out_dir / f"{year}-{month:02d}.xlsx")
        wb.save(filepath)
        generated.append(filepath)
        logger.info(
            "Generated %s (%d sheet(s), %d invoice(s))",
            filepath,
            len(days),
            sum(len(v) for v in days.values()),
        )

    logger.info("Excel generation complete: %d file(s) written", len(generated))
    return generated


# ---------------------------------------------------------------------------
# Patch helpers — used when late invoices arrive for an already-written month
# ---------------------------------------------------------------------------


def _last_doc_in_sheet(ws) -> int:
    """Return the last document number written in a sheet (0 if the sheet has no data rows)."""
    # Column D (index 3, 0-based) = "Document"
    for row in reversed(list(ws.iter_rows(min_row=2, values_only=True))):
        val = row[3]
        if val is not None:
            try:
                return int(str(val).strip())
            except ValueError:
                pass
    return 0


def _first_doc_in_workbook(wb) -> int:
    """Return the smallest document number across all day-sheets (0 if none found)."""
    min_doc: int | None = None
    for sheet in wb.worksheets:
        if not sheet.title.isdigit():
            continue
        for row in sheet.iter_rows(min_row=2, values_only=True):
            val = row[3]
            if val is not None:
                try:
                    n = int(str(val).strip())
                    if min_doc is None or n < min_doc:
                        min_doc = n
                except ValueError:
                    pass
    return min_doc if min_doc is not None else 0


def _last_doc_up_to_day(wb, target_day: int) -> int:
    """Return the last document number across all day-sheets with day <= target_day."""
    candidates = [
        (int(s.title), s) for s in wb.worksheets if s.title.isdigit() and int(s.title) <= target_day
    ]
    if not candidates:
        return 0
    _, ws = max(candidates, key=lambda t: t[0])
    return _last_doc_in_sheet(ws)


def _shift_doc_numbers(
    wb, after_day: int, increment: int, piece_width: int, document_width: int
) -> None:
    """Increment Pièce (col C) and Document (col D) in every sheet with day > after_day."""
    for sheet in wb.worksheets:
        if not sheet.title.isdigit() or int(sheet.title) <= after_day:
            continue
        for row in sheet.iter_rows(min_row=2):
            for cell, width in ((row[2], piece_width), (row[3], document_width)):
                if cell.value is not None:
                    try:
                        cell.value = _zfill_int(int(str(cell.value).strip()) + increment, width)
                    except (ValueError, TypeError):
                        pass


def patch_month_workbook(
    filepath: str,
    invoice_dicts: list[dict],
    *,
    piece_offset: int = 0,
    doc_floor: int = 0,
    piece_width: int = 4,
    document_width: int = 5,
    tva_rate: float = 0.20,
) -> int:
    """Insert invoices into an existing monthly workbook and renumber subsequent sheets.

    For each invoice (processed in chronological order):
    - Appends rows to the correct day-sheet (creating it if needed).
    - Increments Pièce/Document in all sheets for days that come after.

    ``piece_offset`` — constant difference between piece and document numbers within
    the month (piece = doc + piece_offset).  Derived from the independent accounting-
    exercise counter vs. the calendar-year document counter.  Default 0 (same number).

    ``doc_floor`` — the last document number from the previous month.  Used when the
    invoice day is earlier than all existing sheets in the workbook (so
    ``_last_doc_up_to_day`` returns 0), ensuring numbering continues from the previous
    month's endpoint rather than restarting from 1.  When 0 (the default), the floor
    is auto-detected from the workbook's minimum doc number — this handles the case
    where the engine's ``id_document_seed`` was set above 1 on first install and has
    since been auto-reset to 1, making the engine-computed floor stale.

    Returns the new last document number for the month.
    """
    # --- Validate & sort ---
    valid: list[tuple[Invoice, date]] = []
    for inv_dict in invoice_dicts:
        client = (inv_dict.get("Client") or "").strip()
        date_iso = (inv_dict.get("date") or "").strip()
        total_ttc = inv_dict.get("total_ttc")
        reference = (inv_dict.get("reference") or "").strip()
        if not client or not date_iso or total_ttc is None:
            logger.warning("Skipping incomplete invoice dict in patch: %s", inv_dict)
            continue
        inv = Invoice(
            client=client, date_iso=date_iso, total_ttc=float(total_ttc), reference=reference
        )
        valid.append((inv, _parse_iso_date(date_iso)))

    if not valid:
        logger.warning("patch_month_workbook called with no valid invoices — nothing to do")
        return 0

    valid.sort(key=lambda t: t[1])

    wb = load_workbook(filepath)

    # When no explicit floor is given, derive it from the workbook's minimum doc so
    # early-in-month patches don't restart from 1 on installs where id_document_seed
    # was set above 1 and has since been auto-reset to 1 by the engine.
    effective_floor = doc_floor
    if effective_floor == 0:
        first_in_wb = _first_doc_in_workbook(wb)
        if first_in_wb > 1:
            effective_floor = first_in_wb - 1

    # Track which sheets receive new rows so each is styled exactly once at the end,
    # rather than once per invoice (which is O(n²) for many patches on the same sheet).
    touched_sheets: set[str] = set()

    for inv, d in valid:
        day = d.day
        sheet_name = f"{day:02d}"

        # Find the last doc number at or before this day and derive piece from offset
        last_doc = max(_last_doc_up_to_day(wb, day), effective_floor)
        new_doc = last_doc + 1
        new_piece = new_doc + piece_offset

        # Get or create the target sheet
        if sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
        else:
            ws = wb.create_sheet(title=sheet_name)
            ws.append(HEADERS)

        # Append the three accounting rows for this invoice
        for row in invoice_to_rows(
            inv,
            piece=_zfill_int(new_piece, piece_width),
            document=_zfill_int(new_doc, document_width),
            tva_rate=tva_rate,
        ):
            ws.append(row)

        touched_sheets.add(sheet_name)

        logger.debug(
            "Patched sheet '%s': appended invoice %s (doc=%s piece=%s) [floor=%d], shifting later sheets",
            sheet_name,
            inv.client,
            _zfill_int(new_doc, document_width),
            _zfill_int(new_piece, piece_width),
            effective_floor,
        )

        # Shift Pièce/Document in all sheets after this day
        _shift_doc_numbers(wb, day, 1, piece_width, document_width)

    # Style each touched sheet once — borders, alignment, number formats applied
    # to all rows including the newly appended ones.
    for sheet_name in touched_sheets:
        style_as_table(wb[sheet_name])

    # Ensure sheets stay ordered by day
    wb._sheets.sort(key=lambda s: int(s.title) if s.title.isdigit() else float("inf"))

    wb.save(filepath)

    # Return the new last doc number in the file
    last_day = max((int(s.title) for s in wb.worksheets if s.title.isdigit()), default=0)
    return _last_doc_in_sheet(wb[f"{last_day:02d}"]) if last_day else 0
