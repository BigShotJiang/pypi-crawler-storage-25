"""Configuration and lab definitions"""

from pathlib import Path

LAB_CONFIGS = {
    "ml": {
        "name": "Machine Learning Lab",
        "description": "ML lab with datasets and jupyter notebooks",
        "url": "https://github.com/user/ML_Lab/archive/refs/heads/main.zip",
        "folder_name": "ML_Lab-main",
        "files": [
            "lab6_PCA.ipynb",
            "ML_lab_1.ipynb",
            "ml_lab_2.ipynb",
            "mllab3.ipynb",
            "mllab5.ipynb",
            "mllab8.ipynb",
            "mllab9.ipynb",
            "mllab10.ipynb",
            "pgm7.ipynb",
            "program4.ipynb",
            "breast-cancer.csv"
        ]
    },
    "sdp": {
        "name": "Software Development Project",
        "description": "SDP lab programs",
        "url": "https://github.com/user/sdp-program/archive/refs/heads/main.zip",
        "folder_name": "sdp-program-main",
        # You can list specific local files by absolute path; these will be copied
        "files": [
            r"C:\\2026proj\\OTHER HACKATHON\\LAB PACKAGE\\sdp program\\SDP Lab Program and Viva Questions.docx"
        ],
        # Optionally copy an entire folder (set to None if unused)
        "local_folder": None
    },
    "mad": {
        "name": "Mobile Application Development",
        "description": "MAD lab programs and resources",
        "url": "https://github.com/user/MAD-program/archive/refs/heads/main.zip",
        "folder_name": "MAD-program-main",
        # keep demo file list but also allow copying a whole local folder
        "files": ["MAD (1).txt"],
        "local_folder": r"C:\\2026proj\\OTHER HACKATHON\\LAB PACKAGE\\MAD PROGRAM"
    }
}

DEFAULT_DOWNLOAD_DIR = str(Path.home() / "Downloads")
