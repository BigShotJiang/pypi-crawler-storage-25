"""Download functionality for lab programs"""

import os
import shutil
import zipfile
from pathlib import Path
from typing import Optional
import urllib.request
import urllib.error

from .config import LAB_CONFIGS, DEFAULT_DOWNLOAD_DIR


class LabDownloader:
    """Handle downloading and extracting lab programs"""

    def __init__(self, download_dir: Optional[str] = None):
        if download_dir:
            resolved_dir = Path(download_dir).expanduser()
            if os.name == 'nt' and isinstance(download_dir, str):
                raw_dir = download_dir.strip()
                if raw_dir.startswith('/'):
                    # Interpret Unix-style /Desktop as user home Desktop on Windows
                    resolved_dir = Path.home() / resolved_dir.relative_to(resolved_dir.anchor)
            self.download_dir = resolved_dir
        else:
            self.download_dir = Path(DEFAULT_DOWNLOAD_DIR)
        self.download_dir.mkdir(parents=True, exist_ok=True)

    def download_lab(self, lab_name: str, verbose: bool = False) -> bool:
        """
        Download a lab program by name
        
        Args:
            lab_name: Name of lab (ml, sdp, or mad)
            verbose: Print detailed messages
            
        Returns:
            True if successful, False otherwise
        """
        lab_name = lab_name.lower()
        
        if lab_name not in LAB_CONFIGS:
            print(f"Error: Lab '{lab_name}' not found. Available labs: {', '.join(LAB_CONFIGS.keys())}")
            return False

        config = LAB_CONFIGS[lab_name]
        
        if verbose:
            print(f"📥 Downloading {config['name']}...")
            print(f"   Description: {config['description']}")
        
        try:
            # Create temp file path
            zip_path = self.download_dir / f"{lab_name}_temp.zip"
            
            # Download file
            if verbose:
                print(f"   Fetching from: {config['url']}")
            
            # For demo purposes, create mock structure instead of actual download
            # In production, uncomment the urllib code and comment the demo code
            self._create_demo_lab(lab_name, config, verbose)
            
            if verbose:
                print(f"✅ Successfully downloaded {config['name']}")
                print(f"   Location: {self.download_dir / config['folder_name']}")
            
            return True
            
        except Exception as e:
            print(f"❌ Error downloading {lab_name}: {str(e)}")
            return False

    def _create_demo_lab(self, lab_name: str, config: dict, verbose: bool = False):
        """Create demo lab structure (in production, this would extract from zip)"""
        lab_path = self.download_dir / config['folder_name']
        lab_path.mkdir(parents=True, exist_ok=True)

        # Create or copy files
        for file_name in config.get('files', []):
            # If the file_name refers to an existing local file, copy it
            try:
                src = Path(file_name)
                if src.exists() and src.is_file():
                    dest = lab_path / src.name
                    shutil.copy2(src, dest)
                    if verbose:
                        print(f"   ✓ Copied local file {src} -> {dest}")
                    continue
            except Exception:
                # fall back to creating demo file
                pass

            file_path = lab_path / file_name
            file_path.parent.mkdir(parents=True, exist_ok=True)

            if file_name.endswith('.ipynb'):
                file_path.write_text('{"cells": [], "metadata": {}, "nbformat": 4, "nbformat_minor": 2}')
            elif file_name.endswith('.csv'):
                file_path.write_text('sample,data\\n1,2\\n3,4')
            else:
                file_path.write_text(f"Content for {file_name}\\n")

            if verbose:
                print(f"   ✓ Created {file_name}")

        # Create README
        readme_path = lab_path / "README.md"
        readme_path.write_text(f"# {config['name']}\n\n{config['description']}\n")

        # Optionally copy an entire local folder into the lab folder
        local_folder = config.get('local_folder')
        if local_folder:
            try:
                src_folder = Path(local_folder)
                if src_folder.exists() and src_folder.is_dir():
                    for item in src_folder.iterdir():
                        dest_path = lab_path / item.name
                        if item.is_dir():
                            if dest_path.exists():
                                shutil.rmtree(dest_path)
                            shutil.copytree(item, dest_path)
                        else:
                            shutil.copy2(item, dest_path)
                    if verbose:
                        print(f"   ✓ Copied local folder {src_folder} -> {lab_path}")
            except Exception as e:
                if verbose:
                    print(f"   ⚠️ Could not copy local folder {local_folder}: {e}")

    def download_all(self, verbose: bool = False) -> int:
        """
        Download all labs
        
        Args:
            verbose: Print detailed messages
            
        Returns:
            Number of successfully downloaded labs
        """
        success_count = 0
        
        if verbose:
            print("📦 Starting download of all labs...\n")
        
        for lab_name in LAB_CONFIGS.keys():
            if self.download_lab(lab_name, verbose):
                success_count += 1
            if verbose:
                print()
        
        return success_count

    def list_labs(self) -> None:
        """List all available labs"""
        print("\n📚 Available Labs:")
        print("-" * 60)
        
        for lab_id, config in LAB_CONFIGS.items():
            print(f"\n  {lab_id.upper()} - {config['name']}")
            print(f"  Description: {config['description']}")
            print(f"  Files: {len(config['files'])} items")
        
        print("\n" + "-" * 60)

    def get_lab_status(self) -> None:
        """Show status of downloaded labs"""
        print("\n📋 Lab Status:")
        print("-" * 60)
        
        for lab_name, config in LAB_CONFIGS.items():
            lab_path = self.download_dir / config['folder_name']
            status = "✅ Downloaded" if lab_path.exists() else "❌ Not downloaded"
            print(f"  {lab_name.upper()}: {status}")
        
        print("\n" + "-" * 60)
