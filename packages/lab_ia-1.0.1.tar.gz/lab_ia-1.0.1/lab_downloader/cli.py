"""Command-line interface for lab downloader (renamed to lab-ia)"""

import argparse
import sys
from pathlib import Path

from .downloader import LabDownloader


def create_parser() -> argparse.ArgumentParser:
    """Create and return the argument parser with only two commands."""
    parser = argparse.ArgumentParser(
        prog='lab-ia',
        description='lab-ia: Download lab programs for ML, SDP, and MAD',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  lab-ia download-all              Download all labs to your Downloads folder
  lab-ia download --dir C:\\path   Download all labs to the specified directory
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Download all (uses default Downloads unless --dir provided)
    download_all = subparsers.add_parser('download-all', help='Download all labs')
    download_all.add_argument('--dir', type=str, default=None, help='Download directory (default: user Downloads)')
    download_all.add_argument('--verbose', '-v', action='store_true', help='Verbose output')

    # Download to specific path (explicit path required)
    download_to = subparsers.add_parser('download', help='Download all labs to a specific path')
    download_to.add_argument('--dir', type=str, required=True, help='Download directory (required)')
    download_to.add_argument('--verbose', '-v', action='store_true', help='Verbose output')

    return parser


def main(args=None) -> int:
    """Main entry point for CLI"""
    parser = create_parser()

    if args is None:
        args = sys.argv[1:]

    # If no arguments provided, show help
    if not args:
        parser.print_help()
        return 0

    parsed_args = parser.parse_args(args)

    try:
        if parsed_args.command == 'download-all':
            downloader = LabDownloader(parsed_args.dir)
            success_count = downloader.download_all(parsed_args.verbose)
            from .config import LAB_CONFIGS
            total_labs = len(LAB_CONFIGS)
            print(f"\n✨ Downloaded {success_count}/{total_labs} labs")
            return 0 if success_count > 0 else 1

        elif parsed_args.command == 'download':
            downloader = LabDownloader(parsed_args.dir)
            success_count = downloader.download_all(parsed_args.verbose)
            from .config import LAB_CONFIGS
            total_labs = len(LAB_CONFIGS)
            print(f"\n✨ Downloaded {success_count}/{total_labs} labs")
            return 0 if success_count > 0 else 1

        else:
            parser.print_help()
            return 0

    except KeyboardInterrupt:
        print("\n\n❌ Download cancelled by user")
        return 130
    except Exception as e:
        print(f"❌ Error: {str(e)}", file=sys.stderr)
        return 1


def cli():
    """Entry point for installed script"""
    sys.exit(main())


if __name__ == '__main__':
    sys.exit(main())
