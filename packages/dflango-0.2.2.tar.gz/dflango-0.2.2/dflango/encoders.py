# Built-in
import json
import enum
from uuid import UUID
from datetime import date, datetime
from decimal import Decimal


class CustomEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            # Convert UUID to its string representation
            return str(obj)
        if isinstance(obj, (date, datetime)):
            # Convert date and datetime objects to ISO 8601 formatted strings
            return obj.isoformat()
        if isinstance(obj, Decimal):
            # Convert Decimal to float
            return float(obj)
        if isinstance(obj, set):
            # Convert set to list
            return list(obj)
        if isinstance(obj, enum.Enum):
            # Convert Enum to its value
            return obj.value
        # If the object has a __json__ method, use it for serialization
        if hasattr(obj, "__json__"):
            return obj.__json__()
        # Otherwise, let the base class default method raise the TypeError
        return super().default(obj)
