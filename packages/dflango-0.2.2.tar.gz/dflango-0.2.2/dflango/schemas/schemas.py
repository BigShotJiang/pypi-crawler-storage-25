import logging

# Flask
from flask import abort, make_response, jsonify

# Third-party
from marshmallow import Schema as MarshmallowSchema, EXCLUDE, ValidationError

class Schema(MarshmallowSchema):
    def __init__(self, *args, context=None, **kwargs):

        self.context = context or {}

        super().__init__(*args, **kwargs)

    def validate(self, data, *args, **kwargs):
        # Deserialize data
        try:
            validation = super().validate(data, *args, **kwargs)
            self.load(data, partial=False, unknown=EXCLUDE)
            return validation
        except ValidationError as err:
            abort(make_response(jsonify(err.messages), 422))
        except Exception as e:
            logging.error(f"Unexpected error during validation: {e}")
            abort(make_response(jsonify({"error": "An unexpected error occurred during validation."}), 422))
