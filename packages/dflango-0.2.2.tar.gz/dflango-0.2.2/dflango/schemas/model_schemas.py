# Flask
from flask import abort, make_response, jsonify

# Third-party
from marshmallow import Schema, ValidationError, EXCLUDE
from sqlalchemy.exc import SQLAlchemyError

# DFlango
from dflango.core import get_db


class ModelSchema(Schema):

    instance = None

    class Meta:
        model = None

    def __init__(self, *args, instance=None, many=None, context=None, **kwargs):
        if not self.Meta.model:
            raise ValueError("Meta.model must be defined")

        if instance:
            self.instance = instance

        if "many" in kwargs:
            self.many = kwargs.pop("many")

        self.context = context or {}

        super().__init__(*args, **kwargs)

    def validate(self, data, *args, **kwargs):
        try:
            # Deserialize data
            loaded = self.load(data, partial=False, unknown=EXCLUDE)

            # Get the SQLAlchemy model class
            model_class = self.Meta.model

            # Check for unique constraints by querying the database directly
            errors = {}

            # Get all columns from the model
            for column in model_class.__table__.columns:
                # Check if column has unique constraint (including primary key)
                if column.unique or column.primary_key:
                    column_name = column.name

                    # If the column exists in our data
                    if column_name in loaded:
                        value = loaded[column_name]

                        # Skip None values
                        if value is None:
                            continue

                        # Get db from dflango context
                        db = get_db()
                        
                        # Create a query that searches for this value in this column
                        query = db.session.query(model_class).filter(
                            getattr(model_class, column_name) == value
                        )

                        # If we're updating an existing instance, exclude it from the query
                        if self.instance and hasattr(self.instance, "id"):
                            query = query.filter(model_class.id != self.instance.id)

                        # Check if any records exist with this value
                        if query.first() is not None:
                            label = column_name.replace("_", " ").capitalize()
                            msg = f"{label} '{value}' is already in use."
                            errors[column_name] = [msg]

            # Check foreign key constraints
            for column in model_class.__table__.columns:
                # Check if column is a foreign key
                if column.foreign_keys:
                    column_name = column.name

                    # If the column exists in our data
                    if column_name in loaded:
                        value = loaded[column_name]

                        # Skip None values for nullable foreign keys
                        if value is None:
                            continue

                        # Get db from dflango context
                        db = get_db()
                        
                        # Get the referenced table and column
                        foreign_key = list(column.foreign_keys)[0]
                        referenced_table = foreign_key.column.table
                        referenced_column = foreign_key.column

                        # Check if the referenced record exists
                        referenced_query = db.session.query(referenced_table).filter(
                            referenced_column == value
                        )

                        if referenced_query.first() is None:
                            # Format the field name for the error message
                            label = column_name.replace("_", " ").capitalize()
                            if label.endswith(" id"):
                                label = label[:-3]  # Remove " id" suffix
                            msg = f"This {label} does not exist."
                            errors[column_name] = [msg]

            # If we found any errors, abort with 422 status
            if errors:
                abort(make_response(jsonify(errors), 422))

            # If no errors, store the validated data
            self.validated_data = loaded

        except ValidationError as err:
            # If validation fails, return the errors
            abort(make_response(jsonify(err.messages), 422))

    def _separate_nested_data(self, data):
        """Separate data into flat fields and nested fields based on schema definition."""
        flat_data = {}
        nested_data = {}
        
        for key, value in data.items():
            field = self.fields.get(key)
            # If it's a nested field, separate it
            # ex. nested_field = fields.Nested(NestedSchema)
            if field and hasattr(field, 'nested') and isinstance(value, dict):
                nested_data[key] = value
            else:
                flat_data[key] = value
        
        return flat_data, nested_data

    def _is_column_nullable(self, model_instance, column_name):
        """Check if a database column is nullable."""
        if not hasattr(model_instance, '__table__'):
            return False
        
        if column_name not in model_instance.__table__.columns:
            return False
        
        return model_instance.__table__.columns[column_name].nullable

    def _set_nested_attribute(self, nested_instance, field_name, field_value, parent_key):
        """Set an attribute on a nested instance with error handling."""
        try:
            setattr(nested_instance, field_name, field_value)
        except AttributeError as e:
            error_msg = f"Invalid field: {parent_key}.{field_name}. {str(e)}"
            abort(make_response(jsonify({"error": error_msg}), 422))

    def _apply_dict_to_nested_instance(self, nested_instance, data, parent_key):
        """Apply dictionary data directly to nested instance (fallback method)."""
        for nested_key, nested_value in data.items():
            self._set_nested_attribute(nested_instance, nested_key, nested_value, parent_key)

    def _get_nested_schema_instance(self, schema_class, nested_instance):
        """Create an instance of a nested schema."""
        if issubclass(schema_class, ModelSchema):
            return schema_class(instance=nested_instance)
        return schema_class()

    def _validate_none_value(self, nested_instance, field_name, parent_key):
        """Validate that a None value can be set on a nullable field."""
        if self._is_column_nullable(nested_instance, field_name):
            return True
        
        error_msg = {parent_key: {field_name: ["Field may not be null."]}}
        abort(make_response(jsonify(error_msg), 422))
        return False

    def _process_nested_data_with_schema(self, nested_schema, data, nested_instance, parent_key, partial=True):
        """Validate and apply nested data using its schema.
        
        Args:
            nested_schema: The schema instance to use for validation
            data: The data to validate and apply
            nested_instance: The instance to apply validated data to
            parent_key: The key of the parent field (for error messages)
            partial: If True, allow partial updates (ignore required fields). 
                    If False, enforce required fields (used in create operations).
        """
        # Separate None values to handle them specially
        none_values = {k: v for k, v in data.items() if v is None}
        non_none_values = {k: v for k, v in data.items() if v is not None}
        
        # Validate non-None values
        try:
            validated_data = nested_schema.load(non_none_values, partial=partial, unknown=EXCLUDE)
            
            # Apply validated non-None data
            for field_name, field_value in validated_data.items():
                self._set_nested_attribute(nested_instance, field_name, field_value, parent_key)
            
            # Handle None values by checking database nullability
            for field_name in none_values:
                if self._validate_none_value(nested_instance, field_name, parent_key):
                    self._set_nested_attribute(nested_instance, field_name, None, parent_key)
                    
        except ValidationError as err:
            abort(make_response(jsonify({parent_key: err.messages}), 422))

    def _validate_and_apply_nested_field(self, instance, key, value, allow_none=False, partial=True):
        """Validate and apply a nested field to an instance.
        
        Args:
            instance: The parent instance
            key: The field name
            value: The data to apply
            allow_none: If True, don't error if nested instance doesn't exist
            partial: If True, allow partial updates of nested data (ignore required fields).
                    If False, enforce required fields in nested data.
        """
        field = self.fields.get(key)
        
        if not field or not hasattr(field, 'nested'):
            return
        
        nested_instance = getattr(instance, key, None)
        
        # Check if nested instance exists
        if nested_instance is None:
            if not allow_none:
                error_msg = f"Cannot update '{key}' because it does not exist."
                abort(make_response(jsonify({"error": error_msg}), 422))
            return

        nested_schema_class = field.nested
        
        # Handle string references (lazy loading)
        if isinstance(nested_schema_class, str):
            self._apply_dict_to_nested_instance(nested_instance, value, key)
            return
        
        # Handle class-based nested schemas
        try:
            nested_schema = self._get_nested_schema_instance(nested_schema_class, nested_instance)
            self._process_nested_data_with_schema(nested_schema, value, nested_instance, key, partial=partial)
        except TypeError:
            # Fallback to simple dict handling if schema creation fails
            self._apply_dict_to_nested_instance(nested_instance, value, key)

    def _apply_data_to_instance(self, instance, data):
        """Apply data to instance, handling both flat and nested fields."""
        flat_data, nested_data = self._separate_nested_data(data)
        
        # Apply flat data
        for key, value in flat_data.items():
            # Handle dict values that are not defined as Nested fields
            if isinstance(value, dict) and hasattr(instance, key):
                nested_instance = getattr(instance, key)
                if nested_instance is not None:
                    for nested_key, nested_value in value.items():
                        try:
                            setattr(nested_instance, nested_key, nested_value)
                        except AttributeError as e:
                            abort(make_response(jsonify({"error": f"Invalid field: {key}.{nested_key}. {str(e)}"}), 422))
                else:
                    abort(make_response(jsonify({"error": f"Cannot update '{key}' because it does not exist."}), 422))
            else:
                try:
                    setattr(instance, key, value)
                except AttributeError as e:
                    abort(make_response(jsonify({"error": f"Invalid field: {key}. {str(e)}"}), 422))
        
        # Apply nested data with validation
        for key, value in nested_data.items():
            self._validate_and_apply_nested_field(instance, key, value)

    def create(self, data, *args, **kwargs):
        """Create a new instance of the model. Return the instance."""
        
        # Separate flat and nested data
        flat_data, nested_data = self._separate_nested_data(data)
        
        # Create instance with flat data only
        instance = self.Meta.model(**flat_data)
        
        # Apply nested data with validation if any
        # Use partial=False to enforce required fields in nested data during creation
        for key, value in nested_data.items():
            self._validate_and_apply_nested_field(instance, key, value, allow_none=True, partial=False)

        return instance

    def update(self, data, *args, **kwargs):
        """Update an existing instance of the model. Return the instance."""
        
        instance = self.instance
        
        # Apply all data (flat and nested) to the instance
        self._apply_data_to_instance(instance, data)

        return instance

    def save(self, *args, **kwargs):
        """Save the instance to the database. Return the instance."""

        # Check if validated data exists. Before saving, validate must be called.
        if not hasattr(self, "validated_data"):
            raise ValueError("No validated data to save.")

        # Get db from dflango context
        db = get_db()
        
        # Create or update instance
        if not self.instance:
            self.instance = self.create(self.validated_data)
        else:
            self.instance = self.update(self.validated_data)

        # Save instance. If error, rollback and raise exception.
        try:
            db.session.add(self.instance)
            db.session.commit()
        except SQLAlchemyError as e:
            db.session.rollback()
            raise e

        return self.instance
