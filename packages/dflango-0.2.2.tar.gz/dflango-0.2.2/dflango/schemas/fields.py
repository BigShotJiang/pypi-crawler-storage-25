# Built-in
from datetime import timezone

# Third-party
from marshmallow import fields


class UtcDateTimeField(fields.DateTime):
    def __init__(
        self,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.format = "%Y-%m-%dT%H:%M:%SZ"

    def _deserialize(self, value, attr, data, **kwargs):
        dt = super()._deserialize(value, attr, data, **kwargs)
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)


class EnumField(fields.Field):
    """Field that serializes enum values to their string value and deserializes strings to enum instances."""
    
    def __init__(self, enum_class, *args, **kwargs):
        self.enum_class = enum_class
        super().__init__(*args, **kwargs)
    
    def _serialize(self, value, attr, obj, **kwargs):
        """Serialize enum to its value."""
        if value is None:
            return None
        return value.value if hasattr(value, 'value') else value
    
    def _deserialize(self, value, attr, data, **kwargs):
        """Deserialize string to enum instance."""
        if value is None:
            return None
        try:
            return self.enum_class(value)
        except (ValueError, KeyError):
            self.fail(f'Invalid value for {self.enum_class.__name__}: {value}')
