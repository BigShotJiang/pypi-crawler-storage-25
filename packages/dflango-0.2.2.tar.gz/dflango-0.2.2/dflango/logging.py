# Built-in
import logging
from logging import StreamHandler, Formatter, Filter
import sys
import json
from datetime import datetime


class MaxLevelFilter(Filter):
    """Filter that only allows log records up to a maximum level.
    
    Useful for separating logs between stdout and stderr:
    - stdout: DEBUG, INFO, WARNING (levels < ERROR)
    - stderr: ERROR, CRITICAL (levels >= ERROR)
    
    Args:
        max_level: Maximum log level to allow (inclusive)
    
    Example:
        >>> handler = logging.StreamHandler(sys.stdout)
        >>> handler.addFilter(MaxLevelFilter(logging.WARNING))
        >>> # Only DEBUG, INFO, WARNING messages will pass through
    """
    
    def __init__(self, max_level: int):
        super().__init__()
        self.max_level = max_level
    
    def filter(self, record: logging.LogRecord) -> bool:
        """Return True if record level is <= max_level."""
        return record.levelno <= self.max_level


class Logger:
    """Centralized logging configuration for Flask applications.
    
    Configures the root logger globally so that all logging.info(), logging.getLogger(__name__),
    etc. throughout the application use the configured handlers, formatters, and filters.
    
    The class follows the dflango pattern: set class attributes for simple configuration,
    or override getter methods for advanced customization.
    
    Class Attributes:
        stdout_handler: Custom handler for stdout (default: StreamHandler(sys.stdout))
        stdout_level: Minimum level for stdout (default: logging.DEBUG)
        stdout_filter: Filter for stdout (default: MaxLevelFilter(logging.WARNING))
        stdout_formatter: Formatter for stdout (default: simple format)
        
        stderr_handler: Custom handler for stderr (default: StreamHandler(sys.stderr))
        stderr_level: Minimum level for stderr (default: logging.ERROR)
        stderr_filter: Filter for stderr (default: None)
        stderr_formatter: Formatter for stderr (default: detailed format with timestamp)
    """
    stdout_handler = None
    stdout_level = None
    stdout_filter = None
    stdout_formatter = None
    
    stderr_handler = None
    stderr_level = None
    stderr_filter = None
    stderr_formatter = None


    def __init__(self, name: str = 'app'):
        """Initialize and configure global logging.
        
        Args:
            name: Optional name for identification (not used as logger name,
                  root logger is configured for global impact)
        """
        self.name = name
        self.configure()
    
    
    def configure(self):
        """Apply the logging configuration to the root logger.
        
        Clears existing handlers and configures new ones with custom
        formatters, filters, and levels.
        """
        # Get configured handlers
        stdout_handler = self.get_stdout_handler()
        stderr_handler = self.get_stderr_handler()
        
        # Get the minimum log level (most permissive of the two)
        stdout_level = self.get_stdout_level()
        stderr_level = self.get_stderr_level()
        root_level = min(stdout_level, stderr_level)
        
        # Configure stdout handler
        stdout_handler.setLevel(stdout_level)
        stdout_formatter = self.get_stdout_formatter()
        if stdout_formatter:
            stdout_handler.setFormatter(stdout_formatter)
        stdout_filter = self.get_stdout_filter()
        if stdout_filter:
            stdout_handler.addFilter(stdout_filter)
        
        # Configure stderr handler
        stderr_handler.setLevel(stderr_level)
        stderr_formatter = self.get_stderr_formatter()
        if stderr_formatter:
            stderr_handler.setFormatter(stderr_formatter)
        stderr_filter = self.get_stderr_filter()
        if stderr_filter:
            stderr_handler.addFilter(stderr_filter)
        
        # Configure root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(root_level)
        
        # Clear existing handlers to avoid duplicates
        root_logger.handlers.clear()
        
        # Add our configured handlers
        root_logger.addHandler(stdout_handler)
        root_logger.addHandler(stderr_handler)
    
    
    @staticmethod
    def simple_formatter() -> Formatter:
        """Simple formatter with level, name, and message.
        
        Format: "LEVEL - name - message"
        Example: "INFO - myapp.views - User logged in"
        """
        return Formatter('%(levelname)s - %(name)s - %(message)s')
    
    
    @staticmethod
    def detailed_formatter() -> Formatter:
        """Detailed formatter with timestamp, file, line, and message.
        
        Format: "YYYY-MM-DD HH:MM:SS - LEVEL - name [file:line] - message"
        Example: "2026-02-17 14:30:45 - INFO - myapp.views [views.py:42] - User logged in"
        """
        return Formatter(
            '%(asctime)s - %(levelname)s - %(name)s [%(filename)s:%(lineno)d] - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
    
    
    @staticmethod
    def json_formatter() -> Formatter:
        """JSON formatter for structured logging (useful for production).
        
        Creates a custom formatter that outputs JSON with timestamp, level,
        logger name, message, and additional context.
        """
        class JsonFormatter(Formatter):
            def format(self, record: logging.LogRecord) -> str:
                log_data = {
                    'timestamp': datetime.now().isoformat(),
                    'level': record.levelname,
                    'logger': record.name,
                    'message': record.getMessage(),
                    'module': record.module,
                    'function': record.funcName,
                    'line': record.lineno,
                }
                if record.exc_info:
                    log_data['exception'] = self.formatException(record.exc_info)
                return json.dumps(log_data)
        
        return JsonFormatter()
    
    
    def get_stdout_handler(self) -> StreamHandler:
        """Get or create the stdout handler.
        
        Returns:
            StreamHandler configured for sys.stdout
        """
        if self.stdout_handler is not None:
            return self.stdout_handler
        
        return StreamHandler(sys.stdout)
    
    
    def get_stdout_level(self) -> int:
        """
        Get the minimum log level for stdout. 
        This should be one of the following:
        - logging.DEBUG
        - logging.INFO
        - logging.WARNING
        - logging.ERROR
        - logging.CRITICAL
        """
        
        if self.stdout_level is not None:
            return self.stdout_level
        
        return logging.DEBUG
    
    
    def get_stdout_filter(self) -> Filter:
        """Get filter for stdout handler.
        
        By default, returns MaxLevelFilter(logging.WARNING) to only allow
        DEBUG, INFO, and WARNING messages to stdout (ERROR+ goes to stderr).
        
        Returns:
            Filter instance or None
        """
        if self.stdout_filter is not None:
            return self.stdout_filter
        
        # Default: only allow messages up to WARNING on stdout
        # ERROR and CRITICAL go to stderr
        return MaxLevelFilter(logging.WARNING)
    
    
    def get_stdout_formatter(self) -> Formatter:
        """Get formatter for stdout handler.
        
        Returns:
            Formatter instance for stdout logs
        """
        if self.stdout_formatter is not None:
            return self.stdout_formatter
        
        # Default: detailed formatter for stdout
        return self.detailed_formatter()
    
    
    def get_stderr_handler(self) -> StreamHandler:
        """Get or create the stderr handler.
        
        Returns:
            StreamHandler configured for sys.stderr
        """
        if self.stderr_handler is not None:
            return self.stderr_handler
        
        return StreamHandler(sys.stderr)
    
    
    def get_stderr_level(self) -> int:
        """
        Get the minimum log level for stderr. 
        This should be one of the following:
        - logging.DEBUG
        - logging.INFO
        - logging.WARNING
        - logging.ERROR
        - logging.CRITICAL
        """

        if self.stderr_level is not None:
            return self.stderr_level

        return logging.ERROR
    
    
    def get_stderr_filter(self) -> Filter:
        """Get filter for stderr handler.
        
        By default, no filter is applied (all ERROR+ messages pass through).
        
        Returns:
            Filter instance or None
        """
        if self.stderr_filter is not None:
            return self.stderr_filter
        
        # Default: no filter for stderr (all ERROR+ messages pass)
        return None
    
    
    def get_stderr_formatter(self) -> Formatter:
        """Get formatter for stderr handler.
        
        Returns:
            Formatter instance for stderr logs
        """
        if self.stderr_formatter is not None:
            return self.stderr_formatter
        
        # Default: detailed formatter with timestamp for errors
        return self.detailed_formatter()