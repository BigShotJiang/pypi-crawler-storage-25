import enum

class Enum(enum.Enum):
    """
    Base Enum class that returns the value when converted to a string.
    """
    def __str__(self):
        return self.value
    
    def __repr__(self):
        return self.value
    
    def __format__(self, format_spec):
        return self.value.__format__(format_spec)
    
    def __eq__(self, other):
        """Allow comparison with both Enum members and their values."""
        if isinstance(other, enum.Enum):
            return super().__eq__(other)
        return self.value == other
    
    def __hash__(self):
        """Maintain hashability for use in sets and as dict keys."""
        return super().__hash__()
