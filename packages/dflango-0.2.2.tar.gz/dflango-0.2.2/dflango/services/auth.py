# Built-in
import jwt

# Flask
from flask import current_app


def decode_jwt(token):
    return jwt.decode(token, current_app.config["SECRET_KEY"], algorithms=["HS256"])
