class RouteRegistry:
    """
    Base RouteRegistry class for defining blueprints and URL patterns.

    Attributes:
        blueprint: Flask Blueprint instance
        urlpatterns: List of URL patterns and their corresponding view functions

    Example:
        class MyRoute(RouteRegistry):
            blueprint = Blueprint('my_route', __name__, url_prefix='/myroute')
            urlpatterns = [
                ('/hello', hello_view_function),
                ('/goodbye', goodbye_view_function),
            ]
    """

    blueprint = None
    urlpatterns = []
