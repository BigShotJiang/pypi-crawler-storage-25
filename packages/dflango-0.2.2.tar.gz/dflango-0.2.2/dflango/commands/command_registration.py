# DFlango
from dflango.commands.load_fixtures import load_fixtures_command
from dflango.commands.start_app import start_app_command


def register_commands(app):
    """
    Register all commands.
    """

    # Register commands
    app.cli.add_command(load_fixtures_command)
    app.cli.add_command(start_app_command)
