import os
import shutil
import click


def _get_template_dir():
    """Get the path to the template directory."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    template_dir = os.path.join(os.path.dirname(current_dir), "templates", "app_template")
    return template_dir


def _replace_placeholders_in_file(file_path, app_name):
    """Replace {app_name} placeholders in a file with the actual app name."""
    with open(file_path, "r") as f:
        content = f.read()

    content = content.replace("{app_name}", app_name)

    with open(file_path, "w") as f:
        f.write(content)


@click.command(name="start-app")
@click.argument("name", required=True)
def start_app_command(name):
    """
    This command starts a new DFlango application with the given name.
    The application will be created in the current directory.
    The directory structure will be set up with default files and folders.
    Each file will contain boilerplate code to get you started quickly.
    """

    app_name = name

    # Check if directory already exists
    if os.path.exists(app_name):
        click.echo(f"Directory '{app_name}' already exists.")
        return

    # Get template directory
    template_dir = _get_template_dir()

    if not os.path.exists(template_dir):
        click.echo(f"Error: Template directory not found at {template_dir}")
        return

    # Copy template directory to new app directory
    shutil.copytree(template_dir, app_name)

    # Replace placeholders in all files
    for root, dirs, files in os.walk(app_name):
        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                _replace_placeholders_in_file(file_path, app_name)

    click.echo(f"DFlango application '{app_name}' has been created successfully.")
