# Built-in
import json
import os
import click
import logging
import uuid

# Flask
from flask.cli import with_appcontext

# SQLAlchemy
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm.exc import NoResultFound

# DFlango
from dflango.core import get_db


FIXTURES_DIR = os.path.join(os.getcwd(), "app/fixtures")


def get_model_by_name(name):
    """
    Searches for the model by comparing both the class name and the __tablename__ attribute.
    """
    db = get_db()
    for mapper in db.Model.registry.mappers:
        cls = mapper.class_
        if cls.__name__ == name or getattr(cls, "__tablename__", None) == name:
            return cls
    return None


def load_fixtures_from_file(filepath):
    """Loads fixtures from a single JSON file."""
    try:
        with open(filepath, "r") as f:
            data = json.load(f)
    except Exception as e:
        logging.error(f"Failed to load {filepath}: {e}")
        return

    inserted_count = 0  # Counter for inserted records
    updated_count = 0  # Counter for updated records

    for entry in data:
        model_name = entry.get("model")
        fields = entry.get("fields", {})
        model_class = get_model_by_name(model_name)

        if model_class is None:
            logging.error(f"Model '{model_name}' not found!")
            continue

        # Convert UUID fields correctly
        primary_key_fields = [
            column.name
            for column in model_class.__table__.columns
            if column.primary_key
        ]

        if not primary_key_fields:
            logging.error(f"Model '{model_name}' does not have primary keys defined!")
            continue

        for field_name, value in fields.items():
            column = getattr(model_class, field_name, None)
            column_type = column.type if hasattr(column, "type") else None

            if isinstance(column_type, UUID) and isinstance(value, str):
                fields[field_name] = uuid.UUID(value)

        # Check if the record exists using all primary keys
        primary_key_filters = {
            pk: fields[pk] for pk in primary_key_fields if pk in fields
        }

        existing_record = None
        if len(primary_key_filters) == len(
            primary_key_fields
        ):  # Ensure we have all primary keys
            db = get_db()
            try:
                existing_record = (
                    db.session.query(model_class)
                    .filter_by(**primary_key_filters)
                    .one_or_none()
                )
            except NoResultFound:
                existing_record = None

        if existing_record:
            # Update existing record
            for key, value in fields.items():
                setattr(existing_record, key, value)
            updated_count += 1  # Increment update counter
        else:
            # Insert new record
            instance = model_class(**fields)
            db.session.add(instance)
            inserted_count += 1  # Increment insert counter

    db.session.commit()

    # Log only once after processing all records
    logging.info(
        f"Fixtures from {filepath} loaded successfully. Inserted: {inserted_count}, Updated: {updated_count}"
    )


@click.command(name="load-fixtures")
@click.argument("filename", required=False)
@with_appcontext
def load_fixtures_command(filename=None):
    """
    Loads fixtures from a JSON file or from all JSON files in the 'fixtures' directory.
    """
    logging.info(f"Loading fixtures from {FIXTURES_DIR}")

    if filename:
        load_fixtures_from_file(filename)
    else:
        if not os.path.exists(FIXTURES_DIR) or not os.path.isdir(FIXTURES_DIR):
            logging.error(f"Fixtures directory '{FIXTURES_DIR}' not found!")
            return

        # Retrieve all JSON files and sort them alphabetically
        json_files = sorted(
            [f for f in os.listdir(FIXTURES_DIR) if f.endswith(".json")]
        )
        if not json_files:
            logging.warning("No JSON fixture files found in the 'fixtures' directory.")
            return

        logging.info(f"files: {json_files}")

        for json_file in json_files:
            load_fixtures_from_file(os.path.join(FIXTURES_DIR, json_file))
