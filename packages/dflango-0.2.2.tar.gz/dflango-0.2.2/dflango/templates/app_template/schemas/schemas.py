"""
This file contains the schemas for serializing and deserializing data.
Each schema corresponds to a database model.

Following is an example schema definition.


from dflango.schemas import BaseSchema
from marshmallow import fields

class ExampleReadSchema(BaseSchema):
    id = fields.UUID()
    name = fields.Str()
    created_at = fields.DateTime()

class ExampleWriteSchema(BaseSchema):
    name = fields.Str(required=True)
"""
