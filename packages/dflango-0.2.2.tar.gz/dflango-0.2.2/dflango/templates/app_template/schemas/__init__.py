# schemas module for {app_name} application
