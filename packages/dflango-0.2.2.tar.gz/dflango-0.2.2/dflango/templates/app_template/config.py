"""
This file contains the configuration settings for the application.
Each setting can be customized as needed via environment variables or directly in this file.

Following is an example configuration class.
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class Config:
    # Example configuration variables
    SECRET_KEY = os.getenv("SECRET_KEY", "default-secret-key")
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URI", "sqlite:///dflango.db")
    # ... Add here your configuration variables
