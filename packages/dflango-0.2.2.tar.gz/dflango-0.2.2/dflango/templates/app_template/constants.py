"""
This file contains an example of enum constants that can be used in the application.
You can define your own enums here as needed, and they will be available throughout the application.

Example usage:

"""

from dflango.enum import Enum


class TemplateRole(Enum):
    ADMIN = "ADMIN"
    GUEST = "GUEST"
