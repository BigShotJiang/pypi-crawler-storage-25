"""
This file contains the models for the application database.
Each model represents a database table.

Following is an example model definition.


from dflango.db import db
import uuid

class ExampleModel(db.Model):
    __tablename__ = 'example_model'
    id = db.Column(db.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
"""
