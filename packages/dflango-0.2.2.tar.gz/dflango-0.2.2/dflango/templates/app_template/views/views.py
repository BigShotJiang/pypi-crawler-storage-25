"""
This file contains the views for the application.
Each view corresponds to a specific endpoint and handles HTTP requests.

Following is an example health check view definition.


from dflango.views import BaseView

class HealthCheckView(BaseView):

    def get(self):
        return {"status": "ok"}, 200
"""
