"""
{app_name} application module.
"""

from flask import Flask
from dflango import DFlango

# Configuration
from .config import Config

# Blueprints
from .urls import TemplateRoute


def create_app():
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///dflango.db"

    # Initialize DFlango with routes
    dflango = DFlango()
    dflango.init_app(app, Config, TemplateRoute)

    return app
