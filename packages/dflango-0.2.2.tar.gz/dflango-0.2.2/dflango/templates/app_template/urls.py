"""
This file contains the URL routes for the application.
Each route maps a URL endpoint to a view.

Following is an example route definition.
"""

from flask import Blueprint
from dflango.routes import Route

# Views
# from .views.health import HealthCheckView


class TemplateRoute(Route):
    blueprint = Blueprint("{app_name}", __name__, url_prefix="/{app_name}")
    urlpatterns = [
        # ('/health', HealthCheckView.as_view('health_check')),
    ]
