# Flask
from flask.json.provider import DefaultJSONProvider

# Encoders
from dflango.encoders import CustomEncoder


class CustomJSONProvider(DefaultJSONProvider):
    """Custom JSON provider that uses our CustomEncoder."""
    
    def default(self, obj):
        """Use CustomEncoder's default method for serialization."""
        encoder = CustomEncoder()
        return encoder.default(obj)
