# Built-in
import importlib
import logging
from enum import Enum

# Flask
from flask import jsonify, request, make_response, current_app
from flask.views import MethodView
from werkzeug.exceptions import UnsupportedMediaType

# Third-party
from flask_sqlalchemy.model import DefaultMeta
from flask_sqlalchemy.query import Query
from marshmallow import Schema

# Local imports
from dflango.schemas import UtcDateTimeField
from dflango.services.auth import decode_jwt
from dflango.config import DFlangoConfig


class BaseView(MethodView):
    model = None
    query = None
    read_schema = None
    write_schema = None

    only_authenticated = False

    can_show_deleted = False

    accepted_methods = ["GET", "POST", "PUT", "DELETE"]

    get_permissions = []
    post_permissions = []
    put_patch_permissions = []
    delete_permissions = []

    roles = []
    get_roles = []
    post_roles = []
    put_patch_roles = []
    delete_roles = []

    access_type = None  # "role" or "permission" - defaults from config
    user_data_source = None  # "DB", "JWT", or "FUNCTION" - defaults from config
    # SQLAlchemy model for User lookups (example: "app.models.User")
    user_model = None
    # Callable for custom user fetching: must accept user ID and return user data
    user_fetcher_function = None
    # Marshmallow schema for normalizing user data returned by get_current_user()
    user_schema = None
    # Field name in user object to read roles/permissions from
    access_field_name = None

    def get_request_data(self):
        """
        Centralizes request data handling for different content types.
        Returns a dictionary with the request data regardless of the content type.
        """

        try:
            # First, try to get JSON data regardless of content-type
            json_data = request.get_json(silent=True)

            if json_data is not None:
                logging.debug(f"JSON data: {json_data}")
                return json_data

            # If get_json() failed but we have data, try to parse it as JSON manually
            if request.data:
                try:
                    import json

                    data = json.loads(request.data)
                    logging.debug(f"Manually parsed JSON data: {data}")
                    return data
                except (json.JSONDecodeError, ValueError) as e:
                    logging.debug(f"Failed to manually parse JSON: {e}")

            if request.content_type == "application/json":
                # Content-type says JSON but couldn't parse - this is an error
                logging.error(
                    f"Content-Type is application/json but failed to parse JSON. Data: {request.data}"
                )
                data = {}
            elif request.content_type and (
                request.content_type.startswith("multipart/form-data")
                or request.content_type == "application/x-www-form-urlencoded"
            ):
                data = request.form.to_dict()
                # Handle file uploads if present
                if request.files:
                    files_dict = {key: value for key, value in request.files.items()}
                    data.update(files_dict)
                logging.debug(f"Form data: {data}")
            else:
                # If no content type is specified but we have form data, try to handle it
                if request.form:
                    data = request.form.to_dict()
                    if request.files:
                        files_dict = {
                            key: value for key, value in request.files.items()
                        }
                        data.update(files_dict)
                    logging.debug(f"Default form data: {data}")
                else:
                    # No data found
                    logging.warning(
                        f"No data found in request. Raw data: {request.data}"
                    )
                    data = {}

            return data

        except Exception as e:
            logging.error(f"Error parsing request data: {str(e)}")
            raise UnsupportedMediaType(f"Unable to parse request data: {str(e)}")

    def get_model(self):
        """Get the SQLAlchemy model class for the view."""

        model = self.model

        # Check if the model attribute is set
        assert model is not None, (
            "'%s' should either include a `model` attribute, "
            "or override the `get_model()` method." % self.__class__.__name__
        )

        # Check if the model is a SQLAlchemy model
        assert isinstance(model, DefaultMeta), (
            "'%s.model' should be a SQLAlchemy model class." % self.__class__.__name__
        )

        return model

    def get_model_column(self, column_name):
        """
        Get the SQLAlchemy column object for the given column name.
        Returns None if the column is not found.
        """

        model = self.get_model()

        if hasattr(model, column_name):
            return getattr(model, column_name)
        elif hasattr(model, "c") and hasattr(model.c, column_name):
            return getattr(model.c, column_name)
        else:
            return None

    def get_query(self,  *args, **kwargs):
        """Get the SQLAlchemy query object for the view."""

        query = self.query

        # Check if the query attribute is set
        assert query is not None, (
            "'%s' should either include a `query` attribute, "
            "or override the `get_queryset()` method." % self.__class__.__name__
        )

        # Check if the query is a SQLAlchemy query object
        assert isinstance(query, Query), (
            "'%s.query' should be a SQLAlchemy query object." % self.__class__.__name__
        )

        return query

    def get_can_show_deleted(self):
        """Get the can_show_deleted attribute for the view."""

        can_show_deleted = self.can_show_deleted

        assert isinstance(can_show_deleted, bool), (
            "'%s.can_show_deleted' should be a boolean." % self.__class__.__name__
        )

        return can_show_deleted

    def get_filtered_query(self,  *args, **kwargs):
        """Return the filtered query based on the can_show_deleted attribute and the GET parameter 'show_deleted'.

        If the model has a 'deleted_at' field:
        - If can_show_deleted is False, always apply the filter (showing only records that are not deleted).
        - If can_show_deleted is True, check the GET parameter 'show_deleted':
            - If 'show_deleted' is set to a truthy value (e.g., "true", "1", "yes"), do not apply the filter.
            - Otherwise, apply the filter.
        """

        query = self.get_query(*args, **kwargs)

        deleted_at_column = self.get_model_column("deleted_at")
        if deleted_at_column is not None:
            if not self.get_can_show_deleted():
                # The user is not allowed to see deleted records; filter them out
                query = query.filter(deleted_at_column.is_(None))
            else:
                # The user is allowed to see deleted records; check the GET parameter 'show_deleted'
                show_deleted = request.args.get("show_deleted", "false").lower() in [
                    "true",
                    "1",
                    "yes",
                ]
                if not show_deleted:
                    query = query.filter(deleted_at_column.is_(None))

        return query

    def get_read_schema(self):
        """Get the Marshmallow schema class for reading data."""

        read_schema = self.read_schema

        # Check if the read_schema attribute is set
        assert read_schema is not None, (
            "'%s' should either include a `read_schema` attribute, "
            "or override the `get_read_schema()` method." % self.__class__.__name__
        )

        # Check if the read_schema is a Marshmallow schema class
        assert issubclass(read_schema, Schema), (
            "'%s.read_schema' should be a Marshmallow read_schema class."
            % self.__class__.__name__
        )

        # Get the schema context and model
        schema_context = self.get_schema_context()
        # removed the model variable since it was not used
        _ = self.get_model()

        # If schema context includes 'show_deleted' and the model has a 'deleted_at' field, add it to the schema
        deleted_at_column = self.get_model_column("deleted_at")
        if schema_context.get("show_deleted") and deleted_at_column is not None:
            # Check if the schema has the 'deleted_at' field
            declared_fields = getattr(read_schema, "_declared_fields", {})
            if "deleted_at" not in declared_fields:
                DynamicSchema = type(
                    "DynamicSchema",
                    (read_schema,),
                    {"deleted_at": UtcDateTimeField(dump_only=True, allow_none=True)},
                )
                read_schema = DynamicSchema

        return read_schema

    def get_write_schema(self):
        """Get the Marshmallow schema class for writing data."""

        write_schema = (
            self.write_schema if request.method in ["POST", "PUT", "PATCH"] else None
        )

        # Check if the write_schema attribute is set
        assert write_schema is not None, (
            "'%s' should either include a `write_schema` attribute, "
            "or override the `get_write_schema()` method." % self.__class__.__name__
        )

        # Check if the write_schema is a Marshmallow schema class
        assert issubclass(write_schema, Schema), (
            "'%s.write_schema' should be a Marshmallow write_schema class."
            % self.__class__.__name__
        )

        return write_schema

    def get_schema_context(self):
        """
        Returns a dictionary with context data for schema instantiation.
        Currently, it includes the 'show_deleted' flag based on the GET parameter.
        """
        show_deleted = request.args.get("show_deleted", "false").lower() in [
            "true",
            "1",
            "yes",
        ]
        return {"show_deleted": show_deleted}

    def dispatch_request(self, *args, **kwargs):
        """Handles request authentication, checks permissions, and delegates to the appropriate method."""

        self.args = args
        self.kwargs = kwargs

        # Check authentication
        if self.only_authenticated:
            is_auth = self.is_authenticated()
            if not is_auth:
                return jsonify({"error": "Unauthorized"}), 401

        if self.only_authenticated and not self.is_active():
            response = make_response(
                jsonify({"error": "User account is inactive"}), 401
            )
            response.set_cookie("access_token", "", expires=0)
            return response

        # Check permissions before dispatching the request.
        # The user should have at least one of the required permissions AND roles, if any.
        access_type = self.get_access_type().lower()
        check = (
            self.has_permissions()
            if access_type == "permission"
            else self.has_roles()
        )
        if not check:
            return (
                jsonify({"error": "Forbidden"}),
                403,
            )  # HTTP 403 for permission denied

        # Mapping HTTP methods to corresponding view methods
        method_map = {
            "GET": self.get,
            "POST": self.post,
            "PUT": self.put,
            "PATCH": self.put,  # PUT and PATCH handled by same method
            "DELETE": self.delete,
        }

        # Get the handler for the request method
        handler = method_map.get(request.method)

        # Check if the handler exists and the request method is allowed, then call the handler
        if handler and request.method in self.accepted_methods:
            return handler(*args, **kwargs)

        return jsonify({"error": "Method not allowed"}), 405

    def get_access_type(self):
        """
        Get the access control type following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        """
        # Check class attribute
        if self.access_type is not None:
            return self.access_type
        
        # Check Flask config
        access_type = current_app.config.get("DFLANGO_ACCESS_TYPE")
        if access_type is not None:
            return access_type
        
        # Fall back to dflango default
        return DFlangoConfig.ACCESS_TYPE
    
    def get_user_data_source(self):
        """
        Get the user data source following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        """
        # Check class attribute
        if self.user_data_source is not None:
            return self.user_data_source
        
        # Check Flask config
        user_data_source = current_app.config.get("DFLANGO_USER_DATA_SOURCE")
        if user_data_source is not None:
            return user_data_source
        
        # Fall back to dflango default
        return DFlangoConfig.USER_DATA_SOURCE
    
    def get_user_fetcher_function(self):
        """
        Get the user fetcher function following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        """
        # Check class attribute
        if self.user_fetcher_function is not None:
            fetcher_function = self.user_fetcher_function
        # Check Flask config
        elif current_app.config.get("DFLANGO_FETCHER_FUNCTION") is not None:
            fetcher_function = current_app.config.get("DFLANGO_FETCHER_FUNCTION")
        # Fall back to dflango default
        else:
            fetcher_function = getattr(DFlangoConfig, "FETCHER_FUNCTION", None)
        
        # If it's a string path, resolve it to the actual function
        if isinstance(fetcher_function, str):
            try:
                module_name, function_name = fetcher_function.rsplit(".", 1)
                module = importlib.import_module(module_name)
                fetcher_function = getattr(module, function_name)
            except (ValueError, AttributeError, ImportError) as e:
                logging.error(f"Error resolving user_fetcher_function from string '{fetcher_function}': {e}")
                return None
        
        return fetcher_function

    def get_user_model(self):
        """
        Get the user model class following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        """
        # Check class attribute
        if self.user_model is not None:
            user_model = self.user_model
        # Check Flask config
        elif current_app.config.get("DFLANGO_USER_MODEL") is not None:
            user_model = current_app.config.get("DFLANGO_USER_MODEL")
        # Fall back to dflango default
        else:
            user_model = DFlangoConfig.USER_MODEL
        
        # Only validate if user_model is actually needed (when using DB source)
        if user_model is None:
            return None
        
        # Resolve string path to class
        if isinstance(user_model, str):
            module_name, class_name = user_model.rsplit(".", 1)
            module = importlib.import_module(module_name)
            user_model = getattr(module, class_name)
        
        # Final check
        assert isinstance(
            user_model, type
        ), f"`user_model` must be a class or import path string, got {type(user_model)}"
        
        return user_model

    def get_user_schema(self):
        """
        Get the user schema class following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        
        Returns None if no schema is defined (falls back to default normalization).
        """
        
        # Check class attribute
        if self.user_schema is not None:
            user_schema = self.user_schema
        # Check Flask config
        elif current_app.config.get("DFLANGO_USER_SCHEMA") is not None:
            user_schema = current_app.config.get("DFLANGO_USER_SCHEMA")
        # Fall back to dflango default config
        else:
            user_schema = getattr(DFlangoConfig, "USER_SCHEMA", None)
        
        # If no schema defined, return None
        if user_schema is None:
            return None
        
        # Resolve string path to class if needed
        if isinstance(user_schema, str):
            try:
                module_name, class_name = user_schema.rsplit(".", 1)
                module = importlib.import_module(module_name)
                user_schema = getattr(module, class_name)
            except (ValueError, AttributeError, ImportError) as e:
                logging.error(f"Error resolving user_schema from string '{user_schema}': {e}")
                return None
        
        # Validate it's a Marshmallow schema
        if user_schema is not None:
            try:
                if not issubclass(user_schema, Schema):
                    logging.error(f"user_schema must be a Marshmallow Schema class, got {type(user_schema)}")
                    return None
            except TypeError:
                logging.error(f"user_schema must be a class, got {type(user_schema)}")
                return None
        
        logging.info(f"Returning user_schema: {user_schema}")
        return user_schema

    def get_access_field_name(self):
        """
        Get the field name in the user object containing roles or permissions.
        Following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        4. Auto-default: "roles" for role-based, "permissions" for permission-based
        """
        # Check class attribute
        if self.access_field_name is not None:
            return self.access_field_name
        
        # Check Flask config
        field_name = current_app.config.get("DFLANGO_ACCESS_FIELD_NAME")
        if field_name is not None:
            return field_name
        
        # Check dflango default config
        field_name = getattr(DFlangoConfig, "ACCESS_FIELD_NAME", None)
        if field_name is not None:
            return field_name
        
        # Auto-default based on ACCESS_TYPE
        access_type = self.get_access_type().lower()
        return "roles" if access_type == "role" else "permissions"

    def get_user_from_db(self):
        """
        Default: retrieve the user record directly from the database
        using SQLAlchemy based on the id from JWT payload.
        """
        id = request.jwt_data["user"]["id"]
        user_model = self.get_user_model()
        
        assert (
            user_model is not None
        ), f"'{self.__class__.__name__}' must define `user_model` or set DFLANGO_USER_MODEL in Flask config or dflango config when using DB as user_data_source."
        
        return user_model.query.filter_by(id=id).one_or_none()

    def get_user_from_jwt(self):
        """
        Default: extract all user information directly from the JWT payload
        without any external calls.
        """
        return request.jwt_data["user"]

    def get_user_from_function(self):
        """
        Call a custom function to fetch the user.
        Subclasses must set `user_fetcher_function` or override this method.
        The function should accept a user ID and return user data.
        """
        user_fetcher_function = self.get_user_fetcher_function()
        
        if user_fetcher_function is None:
            raise NotImplementedError(
                f"'{self.__class__.__name__}' must define `user_fetcher_function` "
                "or set DFLANGO_FETCHER_FUNCTION in Flask config or dflango config when using FUNCTION as user_data_source."
            )

        # Extract user_id from JWT data
        try:
            user_data = request.jwt_data.get("user", {})
            user_id = user_data.get("id")
            
            if user_id is None:
                logging.error(f"User ID not found in JWT data: {request.jwt_data}")
                return None
        except Exception as e:
            logging.error(f"Error extracting user ID from JWT: {e}")
            return None

        try:
            # Call the function with user_id as argument
            user = user_fetcher_function(user_id)

            if not user:
                logging.info(f"User with ID {user_id} not found via custom function.")
                return None
            return user
        except TypeError as e:
            logging.error(f"TypeError calling user fetcher function: {e}. Function: {user_fetcher_function}, user_id: {user_id}")
            raise
        except Exception as e:
            logging.error(f"Error calling custom user fetcher function with user_id={user_id}: {e}")
            raise

    def normalize_user_data(self, raw_user):
        """
        Normalize raw user data into a consistent dict format.
        
        If a user_schema is defined, it will be used to serialize the data.
        Otherwise, falls back to default normalization:
        {
            "id": str,
            "first_name": str,
            "last_name": str,
            "email": str,
            "role": str,
            "is_active": bool,
            ... (any additional fields from raw_user)
        }
        
        Override this method to customize normalization for your specific user model.
        """
        
        logging.debug(f"Starting normalization. raw_user type: {type(raw_user)}")
        
        # Check if a user schema is defined
        user_schema_class = self.get_user_schema()
        
        if user_schema_class:
            # Use the schema to serialize/normalize the user data
            try:
                schema = user_schema_class()
                result = schema.dump(raw_user)
                return result
            except Exception as e:
                logging.error(f"Error serializing user data with user_schema {user_schema_class}: {e}", exc_info=True)
                # Fall through to default normalization
        else:
            logging.info("No user_schema defined, using default normalization")

        # Default normalization (backward compatibility)
        # Extract basic fields
        # Support object attributes or dict keys
        def get_field(obj, field):
            if isinstance(obj, dict):
                return obj.get(field)
            return getattr(obj, field, None)

        user_id = get_field(raw_user, "id")
        first = get_field(raw_user, "first_name")
        last = get_field(raw_user, "last_name")
        email = get_field(raw_user, "email")
        is_active = get_field(raw_user, "is_active")
        role = get_field(raw_user, "role")

        normalized = {
            "id": str(user_id) if user_id else None,
            "first_name": first,
            "last_name": last,
            "email": email,
            "role": role.value if isinstance(role, Enum) else role,
            "is_active": is_active if is_active is not None else True,
        }

        # Include any additional fields from raw_user that aren't in the base normalized dict
        if isinstance(raw_user, dict):
            for key, value in raw_user.items():
                if key not in normalized:
                    normalized[key] = value
        
        return normalized

    def get_current_user(self):
        """
        Fetch the current user using the source specified in `user_data_source`.
        Returns a dict with keys: first_name, last_name, email, role.
        """
        # Ensure authentication (populates request.jwt_data)
        if not self.is_authenticated():
            return None

        # Dynamic provider selection
        source = (self.get_user_data_source() or "DB").upper()
        method_name = f"get_user_from_{source.lower()}"
        provider = getattr(self, method_name, None)

        if not provider:
            logging.warning(f"Unknown user_data_source '{source}', falling back to DB")
            provider = self.get_user_from_db

        raw_user = provider()
        if raw_user is None:
            logging.info("User not found in the selected data source.")
            return None

        # Normalize and return
        return self.normalize_user_data(raw_user)

    def has_permissions(self):
        """Checks whether the user has the required permissions based on the request method."""

        # Mapping request methods to required permissions
        permission_map = {
            "GET": "get_permissions",
            "POST": "post_permissions",
            "PUT": "put_permissions",
            "PATCH": "put_permissions",
            "DELETE": "delete_permissions",
        }

        # Get the required permissions for the request method
        required_permissions = getattr(self, permission_map.get(request.method, ""), [])
        
        # Handle both strings and Enum values
        required_permissions = [
            perm.value if isinstance(perm, Enum) else str(perm)
            for perm in required_permissions
        ]

        # If no specific permissions are required, grant access
        if not required_permissions:
            return True

        try:
            # Get the current user
            user = self.get_current_user()

            if not user:
                return False

            # Get the field name to read permissions from
            field_name = self.get_access_field_name()
            data = user.get(field_name, [])

            # Handle two cases:
            # 1. Direct list of permissions: ["perm1", "perm2"] or [{"code": "perm1"}, ...]
            # 2. Nested structure (roles with permissions): [{"permissions": [...]}, ...]
            
            user_permissions = []
            
            if not data:
                user_permissions = []
            elif not isinstance(data, list):
                # Single permission value
                if isinstance(data, dict):
                    user_permissions = [data.get("code", str(data))]
                elif isinstance(data, Enum):
                    user_permissions = [data.value]
                else:
                    user_permissions = [str(data)]
            else:
                # Check if it's a nested structure (roles with permissions) or flat list
                # by examining the first element
                first_elem = data[0] if data else None
                
                if isinstance(first_elem, dict) and "permissions" in first_elem:
                    # Nested structure: roles containing permissions
                    user_permissions = [
                        (perm["code"] if isinstance(perm, dict) else 
                         (perm.value if isinstance(perm, Enum) else str(perm)))
                        for role in data
                        for perm in (role.get("permissions", []) if isinstance(role, dict) else [])
                    ]
                else:
                    # Flat list of permissions
                    user_permissions = [
                        (item["code"] if isinstance(item, dict) and "code" in item else 
                         (item.value if isinstance(item, Enum) else str(item)))
                        for item in data
                    ]

            # Check if the user has at least one required permission
            return any(perm in user_permissions for perm in required_permissions)

        except Exception as e:
            logging.error(f"Error checking permissions: {e}")
            return False

    def has_roles(self):
        """Checks whether the user has the required roles based on the request method."""

        # Mapping request methods to required roles
        role_map = {
            "GET": "get_roles",
            "POST": "post_roles",
            "PUT": "put_roles",
            "PATCH": "put_roles",
            "DELETE": "delete_roles",
        }

        # Get the required roles for the request method
        required_roles = getattr(self, role_map.get(request.method, ""), [])
        if not required_roles:
            required_roles = self.roles or []
        # Handle both strings and Enum values
        required_roles = [
            (role.value if isinstance(role, Enum) else str(role)).lower() 
            for role in required_roles
        ]

        # If no specific roles are required, grant access
        if not required_roles:
            return True

        user = self.get_current_user()
        
        # Get the field name to read roles from
        field_name = self.get_access_field_name()
        user_roles_data = user.get(field_name)
        
        # Handle both single value and list of roles (including Enum support)
        if user_roles_data is None:
            # Fallback for backward compatibility with old "role" field
            fallback_role = user.get("role", "")
            if isinstance(fallback_role, Enum):
                user_roles = [fallback_role.value]
            else:
                user_roles = [str(fallback_role)] if fallback_role else []
        elif isinstance(user_roles_data, str):
            user_roles = [user_roles_data]
        elif isinstance(user_roles_data, Enum):
            user_roles = [user_roles_data.value]
        elif isinstance(user_roles_data, list):
            # Normalize list elements to strings, handling Enum values
            user_roles = [
                (r.value if isinstance(r, Enum) else str(r))
                for r in user_roles_data
            ]
        else:
            user_roles = [str(user_roles_data)]
        
        # Return boolean indicating if user has at least one required role
        return any(
            role.lower() in [r.lower() for r in user_roles] 
            for role in required_roles
        )

    def is_authenticated(self):
        """
        Checks if the user is authenticated by verifying the JWT token in the request cookies.
        Returns True if the user is authenticated, False otherwise.
        """

        # Verify X-Auth-Method header
        auth_method = request.headers.get("X-Auth-Method")

        # Default to 'cookie' if not provided or invalid
        if auth_method not in ["cookie", "bearer"]:
            auth_method = "cookie"

        if auth_method == "bearer":

            # For bearer token, check if the Authorization header is present
            if "Authorization" not in request.headers:
                return False

            # Extract the token from the Authorization header
            auth_header = request.headers.get("Authorization")
            if not auth_header.startswith("Bearer "):
                logging.warning(f"Authorization header doesn't start with 'Bearer ': {auth_header[:20]}...")
                return False

            token = auth_header.split(" ")[1]
        else:
            # Check if the access_token is present in the request cookies
            if "access_token" not in request.cookies:
                logging.warning(f"access_token cookie not found. Available cookies: {list(request.cookies.keys())}")
                return False

            token = request.cookies.get("access_token")

        try:
            # Decode the JWT token
            jwt_data = decode_jwt(token)
        except Exception as e:
            logging.error(f"Error decoding JWT token: {e}", exc_info=True)
            return False

        # Add the JWT data to the request object
        request.jwt_data = jwt_data

        return True

    def is_active(self) -> bool:
        """
        Checks if the current user is active.
        Returns True if the user is active, False otherwise.
        """

        try:
            user = self.get_current_user()
            if not user:
                return False

            is_active_value = user.get("is_active", False)
            return is_active_value

        except Exception as e:
            logging.error(f"Error checking if user is active: {e}", exc_info=True)
            return False

    def get(self, *args, **kwargs):
        """Default GET method for the view. Override this method to customize the behavior."""
        return jsonify({}), 200

    def post(self, *args, **kwargs):
        """Default POST method for the view. Override this method to customize the behavior."""
        return jsonify({}), 201

    def put(self, *args, **kwargs):
        """Default PUT method for the view. Override this method to customize the behavior."""
        return jsonify({}), 200

    def delete(self, *args, **kwargs):
        """Default DELETE method for the view. Override this method to customize the behavior."""
        return jsonify({}), 204
