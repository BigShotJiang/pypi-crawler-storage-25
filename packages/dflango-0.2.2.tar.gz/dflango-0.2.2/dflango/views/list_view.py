# Built-in
import logging
from math import ceil

# Flask
from flask import jsonify, request, url_for, current_app

# Third-party
from sqlalchemy import func, cast, Date

# DFlango
from dflango.views.base_view import BaseView
from dflango.config import DFlangoConfig


class ListView(BaseView):
    accepted_methods = ["GET", "POST"]

    get_permissions = []
    post_permissions = []

    allowed_filters = {}

    sort_default = None
    
    page_size = None
    max_page_size = None

    def get_filters(self):
        allowed_filters = getattr(self, "allowed_filters", {})

        filters = []

        for param, value in request.args.items():
            # Skip parameters used for pagination and ordering.
            if param in ["page", "per_page", "sort", "sort_field", "sort_order"]:
                continue

            # Skip parameters that are not allowed for filtering.
            if not value.strip():
                continue

            # Determine field and lookup type.
            # Optionally, a modifier can be specified to apply additional transformations to the field.
            parts = param.split("__")

            if len(parts) == 1:
                field = param
                lookup = "exact"
                modifier = None
            elif len(parts) == 2:
                field, lookup = parts
                modifier = None
            elif len(parts) == 3:
                field, modifier, lookup = parts
            else:
                field, modifier, lookup = parts[:3]

            # Check if the field is allowed for filtering and add it to the filters dictionary.
            if field in allowed_filters and lookup in allowed_filters[field]:
                filters.append(
                    {
                        "field": field,
                        "lookup": lookup,
                        "value": value,
                        "modifier": modifier,
                    }
                )

        return filters

    def validate_enum_value(self, column, value):
        """
        Validates if a value is valid for an enum column.
        Returns the enum value if valid, otherwise returns None.
        """
        # Check if the column type is an Enum
        column_type = column.type
        if hasattr(column_type, "enum_class"):
            enum_class = column_type.enum_class
            # Try to match the value with enum members
            try:
                # Check if the value exists in the enum
                for member in enum_class:
                    if member.value == value or member.name == value:
                        return member
                # Value not found in enum
                return None
            except (AttributeError, ValueError):
                return None
        # Not an enum column, value is valid
        return value

    def apply_filters(self, query):
        """
        Applies filters to the SQLAlchemy query based on allowed_filters and request parameters.
        Request parameters should be in the format: field or field__lookup.
        For example: ?name=John or ?name__icontains=John.

        Example usage:
        allowed_filters = {
            'name': ['exact', 'icontains'],
            'age': ['exact', 'gt', 'gte', 'lt', 'lte'],
        }
        """

        filters = self.get_filters()

        # Mapping lookup types to SQLAlchemy filter expressions.
        lookup_expression_map = {
            "exact": lambda col, val: col == val,
            "icontains": lambda col, val: col.ilike(f"%{val}%"),
            "contains": lambda col, val: col.like(f"%{val}%"),
            "gt": lambda col, val: col > val,
            "gte": lambda col, val: col >= val,
            "lt": lambda col, val: col < val,
            "lte": lambda col, val: col <= val,
            "in": lambda col, val: col.in_(val.split(",")),
        }

        modifier_expression_map = {
            None: lambda col: col,
            "date": lambda col: cast(func.timezone("Europe/Rome", col), Date),
        }

        # Apply the filters to the query
        for filter in filters:
            field = filter["field"]
            lookup = filter["lookup"]
            value = filter["value"]

            if lookup in lookup_expression_map:
                column = self.get_model_column(field)
                if column is not None:
                    # Validate enum values for exact lookups
                    if lookup == "exact":
                        validated_value = self.validate_enum_value(column, value)
                        if validated_value is None:
                            # Invalid enum value, return error response
                            column_type = column.type
                            if hasattr(column_type, "enum_class"):
                                enum_class = column_type.enum_class
                                valid_values = [member.value for member in enum_class]
                                error_response = {
                                    "error": f"Invalid value '{value}' for field '{field}'",
                                    "valid_values": valid_values,
                                }
                                return jsonify(error_response), 400
                        value = validated_value

                    modifier_function = modifier_expression_map.get(filter["modifier"])
                    if modifier_function is not None:
                        column = modifier_function(column)
                        query = query.filter(
                            lookup_expression_map[lookup](column, value)
                        )

        return query

    def get_page_size(self):
        """
        Get the default page size following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        """
        # Check class attribute
        if self.page_size is not None:
            return self.page_size
        
        # Check Flask config
        page_size = current_app.config.get("DFLANGO_DEFAULT_PAGE_SIZE")
        if page_size is not None:
            return page_size
        
        # Fall back to dflango default
        return DFlangoConfig.DEFAULT_PAGE_SIZE
    
    def get_max_page_size(self):
        """
        Get the maximum page size following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        """
        # Check class attribute
        if self.max_page_size is not None:
            return self.max_page_size
        
        # Check Flask config
        max_page_size = current_app.config.get("DFLANGO_MAX_PAGE_SIZE")
        if max_page_size is not None:
            return max_page_size
        
        # Fall back to dflango default
        return DFlangoConfig.MAX_PAGE_SIZE

    def sort_query(self, query):
        """Sorts the query based on the sort GET parameter."""

        # Retrieve GET parameter for sorting:
        sort_param = request.args.get("sort", self.sort_default)

        if sort_param:
            sort_order = "asc"
            sort_field = sort_param

            # Check if sort_param starts with '-', indicating descending order.
            if sort_param.startswith("-"):
                sort_order = "desc"
                sort_field = sort_param[1:]

            # If the model has the specified attribute, apply sorting.
            sort_column = self.get_model_column(sort_field)
            if sort_column is not None:
                query = query.order_by(
                    sort_column.desc() if sort_order == "desc" else sort_column.asc()
                )

        return query

    def paginate_query(self, *args, **kwargs):
        """Paginates the query and returns a paginated response."""

        default_per_page = self.get_page_size()

        # Get the filtered query.
        query = self.get_filtered_query()

        # Apply filters based on allowed_filters.
        filter_result = self.apply_filters(query)

        # Check if apply_filters returned an error response
        if isinstance(filter_result, tuple):
            return filter_result

        query = filter_result

        schema = self.get_read_schema()
        schema_context = self.get_schema_context()
        schema_instance = schema(context=schema_context)

        # Sort the query
        query = self.sort_query(query)

        # Retrieve pagination parameters.
        page = request.args.get("page", 1, type=int)
        if page < 1:
            page = 1

        per_page = request.args.get("per_page", default_per_page, type=int)
        if per_page < 1:
            per_page = default_per_page
        
        # Validate per_page against max_page_size
        max_per_page = self.get_max_page_size()
        if per_page > max_per_page:
            per_page = max_per_page

        # Calculate the total number of elements.
        total = query.count()

        # Calculate the total number of pages.
        total_pages = ceil(total / per_page)

        # Calculate the offset for the query.
        offset = (page - 1) * per_page

        # Get the elements for the current page.
        paginated_elements = query.offset(offset).limit(per_page).all()

        # Serialize the elements using the provided schema.
        elements_list = schema_instance.dump(paginated_elements, many=True)

        # Manually calculate the start and end indices for the current page.
        start_index = offset + 1  # +1 to start counting from 1.
        to_index = start_index + len(elements_list) - 1  # Calculate the end index.

        # If the requested page is invalid.
        if page > total_pages:
            total = 0
            start_index = 0
            to_index = 0
            elements_list = []

        # Create the paginated response.
        response = {
            "count": total,  # Total number of elements.
            "from": start_index,  # Starting index of the current page.
            "to": to_index,  # Ending index of the current page.
            "page": page,  # Current page number.
            "links": {
                "next": self.get_next_link(page, total_pages, per_page),
                "previous": self.get_previous_link(page, per_page),
            },
            "results": elements_list,  # Elements of the current page.
        }

        return response

    def get_next_link(self, current_page, total_pages, per_page):
        """Get the URL for the next page, if available."""

        if current_page < total_pages:
            # Preserve path parameters (request.view_args) and other query args
            # (filters, sort, etc.) while overriding page and per_page.
            values = {} if not request.view_args else dict(request.view_args)

            # Include existing query parameters except pagination params
            for k, v in request.args.items():
                if k in ["page", "per_page"]:
                    continue
                values[k] = v

            # Set the pagination params we want
            values["page"] = current_page + 1
            values["per_page"] = per_page

            return url_for(request.endpoint, _external=True, **values)
        return None

    def get_previous_link(self, current_page, per_page):
        """Get the URL for the previous page, if available."""

        if current_page > 1:
            # Preserve path parameters (request.view_args) and other query args
            # (filters, sort, etc.) while overriding page and per_page.
            values = {} if not request.view_args else dict(request.view_args)

            for k, v in request.args.items():
                if k in ["page", "per_page"]:
                    continue
                values[k] = v

            values["page"] = current_page - 1
            values["per_page"] = per_page

            return url_for(request.endpoint, _external=True, **values)
        return None

    def get(self, *args, **kwargs):
        """Default GET method for the view. The default behavior is to paginate the query.
        Override this method to customize the behavior."""

        # Return paginated response
        result = self.paginate_query()

        # Check if paginate_query returned an error response
        if isinstance(result, tuple):
            return result

        return jsonify(result), 200

    def post_create(self, new_instance):
        pass

    def post(self):
        """Default POST method for the view. The default behavior is to create a new instance.
        Override this method to customize the behavior."""

        # Get the schemas classes
        read_schema = self.get_read_schema()
        write_schema = self.get_write_schema()

        # Get the request data
        data = self.get_request_data()

        # Instantiate the schema
        schema_context = self.get_schema_context()
        write_schema_instance = write_schema(context=schema_context)

        # Validate the data
        write_schema_instance.validate(data)

        # Create a new instance
        new_instance = write_schema_instance.save()

        # Custom post-create logic
        self.post_create(new_instance)

        # Serialize the new instance and return it
        serialized_instance = read_schema().dump(new_instance)

        return serialized_instance, 201
