from decimal import Decimal
from enum import Enum

from flask import jsonify
from marshmallow import Schema
from sqlalchemy import Date, cast, func

from dflango.views.base_view import BaseView


class StatisticView(BaseView):
    """
    Generic view for exposing dashboard/statistic KPIs.

    Subclasses should define:
        - model
        - query
        - optionally read_schema, used by last_records
        - kpis

    Example:
        class LeadStatisticView(StatisticView):
            model = Lead
            query = Lead.query
            read_schema = LeadReadSchema

            kpis = [
                {"key": "total", "type": "count"},
                {"key": "latest", "type": "last_records", "field": "created_at", "limit": 5},
                {"key": "by_status", "type": "group_count", "field": "status"},
            ]
    """

    accepted_methods = ["GET"]

    kpis = []
    statistics_schema = None

    def get_kpis(self):
        """
        Return KPI definitions.

        Each KPI must be a dict with at least:
            - key
            - type

        Supported types:
            - count
            - distinct_count
            - aggregate
            - group_count
            - date_group_count
            - last_records
            - custom
        """
        kpis = self.kpis

        assert isinstance(kpis, list), (
            "'%s.kpis' should be a list of KPI definitions." % self.__class__.__name__
        )

        for kpi in kpis:
            assert isinstance(kpi, dict), (
                "Each KPI definition in '%s.kpis' should be a dict." % self.__class__.__name__
            )
            assert "key" in kpi, "Each KPI definition must include a 'key'."
            assert "type" in kpi, "Each KPI definition must include a 'type'."

        return kpis

    def get_statistics_schema(self):
        """
        Optional schema used to serialize the full statistics response.
        """
        statistics_schema = self.statistics_schema

        if statistics_schema is None:
            return None

        assert issubclass(statistics_schema, Schema), (
            "'%s.statistics_schema' should be a Marshmallow Schema class." % self.__class__.__name__
        )

        return statistics_schema

    def get_kpi_query(self, kpi):
        """
        Hook for customizing the base query of a specific KPI.

        By default, it uses get_filtered_query(), so soft-delete visibility
        logic from BaseView is preserved.
        """
        return self.get_filtered_query()

    def get_kpi_label(self, kpi):
        return kpi.get("label") or kpi["key"]

    def get_kpi_result(self, kpi):
        kpi_type = kpi["type"]

        handlers = {
            "count": self.build_count_kpi,
            "distinct_count": self.build_distinct_count_kpi,
            "aggregate": self.build_aggregate_kpi,
            "group_count": self.build_group_count_kpi,
            "date_group_count": self.build_date_group_count_kpi,
            "last_records": self.build_last_records_kpi,
            "custom": self.build_custom_kpi,
        }

        handler = handlers.get(kpi_type)

        assert handler is not None, "Unsupported KPI type '%s' in '%s'." % (
            kpi_type,
            self.__class__.__name__,
        )

        value = handler(kpi)

        return {
            "label": self.get_kpi_label(kpi),
            "type": kpi_type,
            "value": value,
        }

    def get(self, *args, **kwargs):
        """
        Return all configured KPIs.
        """
        result = {}

        for kpi in self.get_kpis():
            result[kpi["key"]] = self.get_kpi_result(kpi)

        statistics_schema = self.get_statistics_schema()

        if statistics_schema:
            result = statistics_schema().dump(result)

        return jsonify(result), 200

    # -------------------------------------------------------------------------
    # Query helpers
    # -------------------------------------------------------------------------

    def apply_kpi_filters(self, query, kpi):
        """
        Apply optional KPI-specific filters.

        Supported filter syntax:
            filters = {
                "status": "ACTIVE",
                "amount__gte": 100,
                "created_at__lt": "2026-01-01",
                "status__in": ["NEW", "ACTIVE"],
            }
        """
        filters = kpi.get("filters", {})

        assert isinstance(filters, dict), "KPI '%s' filters should be a dict." % kpi["key"]

        lookup_expression_map = {
            "exact": lambda col, val: col == val,
            "gt": lambda col, val: col > val,
            "gte": lambda col, val: col >= val,
            "lt": lambda col, val: col < val,
            "lte": lambda col, val: col <= val,
            "in": lambda col, val: col.in_(val if isinstance(val, list) else str(val).split(",")),
            "isnull": lambda col, val: col.is_(None) if self._is_truthy(val) else col.is_not(None),
        }

        for raw_field, value in filters.items():
            parts = raw_field.split("__")

            if len(parts) == 1:
                field = raw_field
                lookup = "exact"
            else:
                field = parts[0]
                lookup = parts[1]

            assert lookup in lookup_expression_map, "Unsupported lookup '%s' in KPI '%s'." % (
                lookup,
                kpi["key"],
            )

            column = self.get_model_column(field)

            assert column is not None, "KPI '%s' references unknown model field '%s'." % (
                kpi["key"],
                field,
            )

            query = query.filter(lookup_expression_map[lookup](column, value))

        return query

    def get_prepared_query(self, kpi):
        query = self.get_kpi_query(kpi)
        query = self.apply_kpi_filters(query, kpi)
        return query

    def get_required_column(self, kpi, field_name="field"):
        field = kpi.get(field_name)

        assert field is not None, "KPI '%s' must define '%s'." % (kpi["key"], field_name)

        column = self.get_model_column(field)

        assert column is not None, "KPI '%s' references unknown model field '%s'." % (
            kpi["key"],
            field,
        )

        return column

    # -------------------------------------------------------------------------
    # KPI builders
    # -------------------------------------------------------------------------

    def build_count_kpi(self, kpi):
        query = self.get_prepared_query(kpi)
        return query.order_by(None).count()

    def build_distinct_count_kpi(self, kpi):
        query = self.get_prepared_query(kpi)
        column = self.get_required_column(kpi)

        value = query.with_entities(func.count(func.distinct(column))).scalar()

        return value or 0

    def build_aggregate_kpi(self, kpi):
        """
        Aggregate KPI.

        Example:
            {
                "key": "total_revenue",
                "type": "aggregate",
                "operation": "sum",
                "field": "amount"
            }

        Supported operations:
            - sum
            - avg
            - min
            - max
        """
        query = self.get_prepared_query(kpi)
        column = self.get_required_column(kpi)
        operation = kpi.get("operation", "sum")

        operation_map = {
            "sum": func.sum,
            "avg": func.avg,
            "min": func.min,
            "max": func.max,
        }

        assert operation in operation_map, "Unsupported aggregate operation '%s' in KPI '%s'." % (
            operation,
            kpi["key"],
        )

        value = query.with_entities(operation_map[operation](column)).scalar()

        if value is None and operation in ["sum", "avg"]:
            return 0

        return self.serialize_value(value)

    def build_group_count_kpi(self, kpi):
        """
        Group count KPI.

        Example:
            {
                "key": "by_status",
                "type": "group_count",
                "field": "status"
            }
        """
        query = self.get_prepared_query(kpi)
        column = self.get_required_column(kpi)
        limit = kpi.get("limit")

        grouped_query = (
            query.with_entities(column.label("value"), func.count().label("count"))
            .group_by(column)
            .order_by(func.count().desc())
        )

        if limit:
            grouped_query = grouped_query.limit(limit)

        rows = grouped_query.all()

        return [
            {
                "value": self.serialize_value(row.value),
                "count": row.count,
            }
            for row in rows
        ]

    def build_date_group_count_kpi(self, kpi):
        """
        Date-based group count KPI.

        Example:
            {
                "key": "created_by_day",
                "type": "date_group_count",
                "field": "created_at",
                "interval": "day"
            }

        Supported intervals:
            - day
            - month
            - year

        Notes:
            - day uses CAST(field AS DATE)
            - month/year use date_trunc, which is PostgreSQL-friendly
        """
        query = self.get_prepared_query(kpi)
        column = self.get_required_column(kpi)
        interval = kpi.get("interval", "day")
        limit = kpi.get("limit")

        if interval == "day":
            expression = cast(column, Date)
        elif interval in ["month", "year"]:
            expression = func.date_trunc(interval, column)
        else:
            raise AssertionError("Unsupported interval '%s' in KPI '%s'." % (interval, kpi["key"]))

        grouped_query = (
            query.with_entities(expression.label("value"), func.count().label("count"))
            .group_by(expression)
            .order_by(expression.asc())
        )

        if limit:
            grouped_query = grouped_query.limit(limit)

        rows = grouped_query.all()

        return [
            {
                "value": self.serialize_value(row.value),
                "count": row.count,
            }
            for row in rows
        ]

    def build_last_records_kpi(self, kpi):
        """
        Last records KPI.

        Example:
            {
                "key": "latest_users",
                "type": "last_records",
                "field": "created_at",
                "limit": 5
            }
        """
        query = self.get_prepared_query(kpi)
        column = self.get_required_column(kpi)
        limit = kpi.get("limit", 5)
        direction = kpi.get("direction", "desc")

        if direction == "asc":
            query = query.order_by(column.asc())
        else:
            query = query.order_by(column.desc())

        records = query.limit(limit).all()

        schema_class = kpi.get("schema") or self.read_schema

        assert schema_class is not None, (
            "KPI '%s' needs a schema. Define 'schema' in the KPI "
            "or set 'read_schema' on the view." % kpi["key"]
        )

        assert issubclass(schema_class, Schema), (
            "KPI '%s' schema should be a Marshmallow Schema class." % kpi["key"]
        )

        schema_context = self.get_schema_context()
        schema = schema_class(context=schema_context)

        return schema.dump(records, many=True)

    def build_custom_kpi(self, kpi):
        """
        Custom KPI.

        Example:
            {
                "key": "conversion_rate",
                "type": "custom",
                "handler": "get_conversion_rate"
            }

            def get_conversion_rate(self, kpi):
                ...
        """
        handler = kpi.get("handler")

        assert handler is not None, "Custom KPI '%s' must define a 'handler'." % kpi["key"]

        if isinstance(handler, str):
            handler = getattr(self, handler, None)

        assert callable(handler), "Custom KPI '%s' handler must be callable." % kpi["key"]

        return handler(kpi)

    # -------------------------------------------------------------------------
    # Serialization helpers
    # -------------------------------------------------------------------------

    def serialize_value(self, value):
        if isinstance(value, Enum):
            return value.value

        if isinstance(value, Decimal):
            return float(value)

        if hasattr(value, "isoformat"):
            return value.isoformat()

        return value

    def _is_truthy(self, value):
        if isinstance(value, bool):
            return value

        return str(value).lower() in ["true", "1", "yes"]
