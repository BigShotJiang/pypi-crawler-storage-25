# Flask
from flask import jsonify, make_response, abort

# DFlango
from dflango.views.base_view import BaseView


class ConfigView(BaseView):
    accepted_methods = ["GET", "PUT"]

    get_permissions = []
    put_patch_permissions = []

    def get_instance(self):
        """Get the singleton instance from the filtered query."""

        query = self.get_filtered_query()
        instance = query.first()

        return instance

    def get_instance_or_404(self):
        """Get the singleton instance or return 404."""

        model = self.get_model()
        instance = self.get_instance()

        if not instance:
            response = make_response(
                jsonify({"error": f"{model.__name__} not found"}), 404
            )
            abort(response)

        return instance

    def get(self, *args, **kwargs):
        """Returns the singleton configuration instance."""

        instance = self.get_instance_or_404()

        read_schema = self.get_read_schema()
        serialized_instance = read_schema().dump(instance)

        return serialized_instance, 200

    def pre_edit(self, instance):
        return None

    def post_edit(self, old_instance, updated_instance):
        pass

    def put(self, *args, **kwargs):
        """Updates the singleton configuration instance."""

        instance = self.get_instance_or_404()

        old_data = self.get_read_schema()().dump(instance)

        pre_edit_context = self.pre_edit(instance)

        read_schema = self.get_read_schema()
        write_schema = self.get_write_schema()

        data = self.get_request_data()

        schema_context = self.get_schema_context()
        write_schema_instance = write_schema(instance=instance, context=schema_context)

        write_schema_instance.validate(data)

        updated_instance = write_schema_instance.save()

        serialized_instance = read_schema().dump(updated_instance)

        self.post_edit(old_data, updated_instance, **(pre_edit_context or {}))

        return serialized_instance, 200
