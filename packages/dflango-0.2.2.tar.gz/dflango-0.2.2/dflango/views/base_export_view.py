# Built-in
import logging

# Flask
from flask import jsonify, request, abort, make_response

# dFlango
from dflango.views.base_view import BaseView

# Exports
from dflango.exports.csv.registry import CSVExportRegistry
from dflango.exports.csv.schemas import ExportContext


class BaseExportRequestView(BaseView):
    """
    Base view for handling CSV export requests.

    Subclasses must:
    - set ``export_type``
    - override ``create_export()`` with the actual export creation logic
    - set ``export_client_class`` or override ``get_export_client()``

    Class attributes:
        export_type: identifier registered in CSVExportRegistry (required).
        export_client_class: class instantiated by get_export_client() (required
                             unless get_export_client() is overridden).
        excluded_filter_params: query-string keys to exclude from export filters.
    """

    accepted_methods = ["POST"]
    only_authenticated = True
    export_type = None
    export_client_class = None
    excluded_filter_params = ("page", "per_page", "sort", "sort_field", "sort_order")

    # ------------------------------------------------------------------
    # Hook methods – override in subclasses for custom behaviour
    # ------------------------------------------------------------------

    def get_export_client(self):
        """
        Return the client instance used to create export downloads.
        Override this method for custom client initialization.
        """
        if self.export_client_class is None:
            raise NotImplementedError(
                f"'{self.__class__.__name__}' must define 'export_client_class' "
                "or override 'get_export_client()'."
            )
        return self.export_client_class()

    def create_export(self, client, export_type, user, filters):
        """
        Call the client to create the export download record.
        Subclasses **must** override this method.
        """
        raise NotImplementedError(
            f"'{self.__class__.__name__}' must override 'create_export()'."
        )

    def handle_export_error(self, error):
        """
        Handle errors raised during export creation.
        Override to return custom error responses or error codes.
        """
        logging.error(f"Error creating export download: {error}")
        return jsonify({"error": "Internal server error"}), 500

    def get_success_response(self, result):
        """
        Return the HTTP response after a successful export request.
        Override to include extra data (e.g. the export download id).
        """
        return jsonify(result), 201

    # ------------------------------------------------------------------
    # Main handler
    # ------------------------------------------------------------------

    def post(self):
        user = self.get_current_user()
        export_type = self.export_type

        try:
            schema = CSVExportRegistry.get(export_type)
        except ValueError:
            abort(make_response(jsonify({"error": "Invalid export type"}), 400))

        raw_filters = {
            k: v
            for k, v in request.args.items()
            if k not in self.excluded_filter_params
        }
        filters = schema.validate_filters(raw_filters)

        context = ExportContext(
            user=user,
            filters=filters,
        )
        schema.check_permissions(context)

        try:
            client = self.get_export_client()
            result = self.create_export(client, export_type, user, filters)
        except Exception as e:
            return self.handle_export_error(e)

        return self.get_success_response(result)
