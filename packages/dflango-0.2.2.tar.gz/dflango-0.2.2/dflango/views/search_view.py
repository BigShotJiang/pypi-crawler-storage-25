# Built-in
import logging

# Flask
from flask import request

# Third-party
from sqlalchemy import String
from sqlalchemy.types import String as StringType, Text

# dFlango
from dflango.views.list_view import ListView
from dflango.core import get_db


class SearchView(ListView):
    """Base view to search records by configurable fields via a `query` GET parameter."""

    accepted_methods = ["GET"]
    only_authenticated = True

    search_fields = []

    def get_search_fields(self):
        """Return validated search fields that exist on the model."""
        model = self.get_model()
        valid_fields = []
        for field_name in self.search_fields:
            column = self.get_model_column(field_name)
            if column is not None:
                valid_fields.append(field_name)
            else:
                logging.warning(
                    f"SearchView: field '{field_name}' not found on model "
                    f"'{model.__name__}', skipping."
                )
        return valid_fields

    def _is_string_column(self, column):
        """Check if a column has a string-like type that supports ilike natively."""
        try:
            col_type = column.property.columns[0].type
        except (AttributeError, IndexError):
            col_type = getattr(column, "type", None)
        return isinstance(col_type, (StringType, Text))

    def _get_searchable_expression(self, column):
        """Return the column expression, casting to String if needed for ilike support."""
        if self._is_string_column(column):
            return column
        
        db = get_db()
        return db.cast(column, String)

    def get_query(self):
        model = self.get_model()
        query = model.query

        search_term = request.args.get("query")
        if search_term:
            db = get_db()
            conditions = []
            for field_name in self.get_search_fields():
                column = self.get_model_column(field_name)
                expr = self._get_searchable_expression(column)
                conditions.append(expr.ilike(f"%{search_term}%"))
            if conditions:
                query = query.filter(db.or_(*conditions))

        return query
