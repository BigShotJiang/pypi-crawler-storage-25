# Built-in
import logging

# Flask
from flask import jsonify, request, current_app

# Base view
from .base_view import BaseView


class InternalView(BaseView):
    """
    Base view for internal API endpoints that use token-based authentication
    instead of JWT authentication.
    
    This view overrides authentication methods to verify the X-Internal-Token header
    instead of checking JWT tokens in cookies or authorization headers.
    """
    
    # By default, internal endpoints don't use standard JWT authentication
    only_authenticated = True
    
    def is_authenticated(self):
        """
        Override authentication check to verify internal token.
        Returns True if the X-Internal-Token header matches the configured secret.
        """
        
        # Extract the token from the X-Internal-Token header
        token = request.headers.get('X-Internal-Token')
        
        # Log the presence of the token for debugging purposes
        if not token:
            logging.warning("Internal API call without X-Internal-Token header")
            return False
        
        # Retrieve the expected internal API secret from the application configuration
        internal_api_secret = current_app.config.get("INTERNAL_API_SECRET")
        
        # Log the expected secret for debugging purposes (avoid logging secrets in production)
        if token != internal_api_secret:
            logging.warning("Internal API call with invalid token")
            return False
        
        logging.debug("Internal API authentication successful")
        return True
    
    def is_active(self):
        """
        Override is_active check for internal endpoints.
        Internal services are always considered "active".
        """
        return True
    
    def has_roles(self):
        """
        Override role check for internal endpoints.
        Internal services bypass role-based access control.
        """
        return True
    
    def has_permissions(self):
        """
        Override permission check for internal endpoints.
        Internal services bypass permission-based access control.
        """
        return True
    
    def dispatch_request(self, *args, **kwargs):
        """
        Override dispatch to enforce internal token authentication.
        """
        self.args = args
        self.kwargs = kwargs
        
        # Check internal token authentication
        if not self.is_authenticated():
            return jsonify({
                "error": "Unauthorized", 
                "code": "UNAUTHORIZED_INTERNAL"
            }), 401
        
        # Mapping HTTP methods to corresponding view methods
        method_map = {
            "GET": self.get,
            "POST": self.post,
            "PUT": self.put,
            "PATCH": self.put,
            "DELETE": self.delete,
        }
        
        # Get the handler for the request method
        handler = method_map.get(request.method)
        
        # Check if the handler exists and the request method is allowed
        if handler and request.method in self.accepted_methods:
            return handler(*args, **kwargs)
        
        return jsonify({"error": "Method not allowed"}), 405
