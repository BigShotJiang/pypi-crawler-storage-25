# Flask
from flask import jsonify

# Third-party
from sqlalchemy import func, cast, Date, or_

# DFlango
from dflango.views.list_view import ListView


class GeneralListView(ListView):

    def is_array_column(self, column):
        """Check if a column is an ARRAY type."""
        return hasattr(column.type, "item_type")

    def validate_enum_value(self, column, value):
        """
        Validates if a value is valid for an enum column.
        Also handles ARRAY(Enum) columns.
        Returns the enum value if valid, otherwise returns None.
        """
        column_type = column.type

        # Check ARRAY(Enum) columns
        if hasattr(column_type, "item_type") and hasattr(column_type.item_type, "enum_class"):
            enum_class = column_type.item_type.enum_class
            try:
                for member in enum_class:
                    if member.value == value or member.name == value:
                        return member.value
                return None
            except (AttributeError, ValueError):
                return None

        # Check scalar Enum columns
        if hasattr(column_type, "enum_class"):
            enum_class = column_type.enum_class
            try:
                for member in enum_class:
                    if member.value == value or member.name == value:
                        return member
                return None
            except (AttributeError, ValueError):
                return None

        # Not an enum column, value is valid
        return value

    def apply_filters(self, query):
        filters = self.get_filters()

        lookup_expression_map = {
            "exact": lambda col, val: col == val,
            "icontains": lambda col, val: col.ilike(f"%{val}%"),
            "contains": lambda col, val: col.like(f"%{val}%"),
            "gt": lambda col, val: col > val,
            "gte": lambda col, val: col >= val,
            "lt": lambda col, val: col < val,
            "lte": lambda col, val: col <= val,
            "in": lambda col, val: col.in_(val.split(",")),
        }

        modifier_expression_map = {
            None: lambda col: col,
            "date": lambda col: cast(func.timezone("Europe/Rome", col), Date),
        }

        for filter in filters:
            field = filter["field"]
            lookup = filter["lookup"]
            value = filter["value"]

            if lookup in lookup_expression_map:
                column = self.get_model_column(field)
                if column is not None:
                    if lookup == "exact":
                        # Handle comma-separated values for enum columns
                        if "," in value:
                            column_type = column.type
                            enum_class = None
                            if hasattr(column_type, "item_type") and hasattr(column_type.item_type, "enum_class"):
                                enum_class = column_type.item_type.enum_class
                            elif hasattr(column_type, "enum_class"):
                                enum_class = column_type.enum_class

                            if enum_class is not None:
                                raw_values = [v.strip() for v in value.split(",") if v.strip()]
                                validated_values = []
                                for v in raw_values:
                                    validated = self.validate_enum_value(column, v)
                                    if validated is None:
                                        valid_values = [member.value for member in enum_class]
                                        return jsonify({
                                            "error": f"Invalid value '{v}' for field '{field}'",
                                            "valid_values": valid_values,
                                        }), 400
                                    validated_values.append(validated)

                                if self.is_array_column(column):
                                    query = query.filter(or_(*[column.any(v) for v in validated_values]))
                                else:
                                    modifier_function = modifier_expression_map.get(filter["modifier"])
                                    if modifier_function is not None:
                                        modified_column = modifier_function(column)
                                        query = query.filter(modified_column.in_(validated_values))
                                continue

                        validated_value = self.validate_enum_value(column, value)
                        if validated_value is None:
                            column_type = column.type
                            enum_class = None
                            if hasattr(column_type, "item_type") and hasattr(column_type.item_type, "enum_class"):
                                enum_class = column_type.item_type.enum_class
                            elif hasattr(column_type, "enum_class"):
                                enum_class = column_type.enum_class
                            if enum_class:
                                valid_values = [member.value for member in enum_class]
                                return jsonify({
                                    "error": f"Invalid value '{value}' for field '{field}'",
                                    "valid_values": valid_values,
                                }), 400
                        value = validated_value

                    # For ARRAY columns with exact lookup, use ANY instead of ==
                    if lookup == "exact" and self.is_array_column(column):
                        query = query.filter(column.any(value))
                    else:
                        modifier_function = modifier_expression_map.get(filter["modifier"])
                        if modifier_function is not None:
                            column = modifier_function(column)
                            query = query.filter(
                                lookup_expression_map[lookup](column, value)
                            )

        return query

