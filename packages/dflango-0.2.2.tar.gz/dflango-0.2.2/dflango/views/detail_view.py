# Built-in
import logging

# Flask
from flask import jsonify, request, abort, make_response

# DFlango
from dflango.views.base_view import BaseView
from dflango.core import get_db


class DetailView(BaseView):
    accepted_methods = ["GET", "PUT", "DELETE"]

    get_permissions = []
    put_permissions = []
    delete_permissions = []

    lookup_field = "id"
    lookup_url_kwarg = "id"

    soft_delete = False
    soft_delete_field = "deleted_at"

    def get_lookup_field(self):
        """Get the lookup field for the view."""

        lookup_field = self.lookup_field

        # Check if the lookup_field attribute is set
        assert lookup_field is not None, (
            "'%s' should either include a `lookup_field` attribute, "
            "or override the `get_lookup_field()` method." % self.__class__.__name__
        )

        # Check if the lookup_field is a string
        assert isinstance(lookup_field, str), (
            "'%s.lookup_field' should be a string." % self.__class__.__name__
        )

        # Check if the model has the lookup field
        lookup_column = self.get_model_column(lookup_field)
        assert lookup_column is not None, (
            "'%s' model does not have the lookup field." % self.__class__.__name__
        )

        lookup_url_kwarg = self.lookup_url_kwarg

        # Check if the lookup_url_kwarg attribute is set
        assert lookup_url_kwarg is not None, (
            "'%s' should either include a `lookup_url_kwarg` attribute, "
            "or override the `get_lookup_url_kwarg()` method." % self.__class__.__name__
        )

        # Check if the lookup_url_kwarg is a string
        assert isinstance(lookup_url_kwarg, str), (
            "'%s.lookup_url_kwarg' should be a string." % self.__class__.__name__
        )

        # Get the lookup value from the request view args
        lookup_value = request.view_args.get(lookup_url_kwarg)

        # Check if the lookup value is present
        assert (
            lookup_value is not None
        ), "'%s' view_args does not have the '%s' key." % (
            self.__class__.__name__,
            lookup_field,
        )

        return lookup_field

    def get_instance(self):
        """Get the instance based on the lookup field and value."""

        query = self.get_filtered_query()
        lookup_field = self.get_lookup_field()
        lookup_url_kwarg = self.lookup_url_kwarg

        # Get the lookup value from the request view args
        lookup_value = request.view_args.get(lookup_url_kwarg)

        # Get the instance based on the lookup field and value
        instance = query.filter_by(**{lookup_field: lookup_value}).first()

        return instance

    def get_instance_or_404(self):
        """Get the instance based on the lookup field and value or return 404."""

        model = self.get_model()
        instance = self.get_instance()

        # Return 404 if the instance is not found
        if not instance:
            response = make_response(
                jsonify({"error": f"{model.__name__} not found"}), 404
            )
            abort(response)

        return instance

    def is_soft_delete(self):
        """Check if the view uses soft delete."""

        soft_delete = self.soft_delete

        assert isinstance(soft_delete, bool), (
            "'%s.soft_delete' should be a boolean." % self.__class__.__name__
        )

        return soft_delete

    def get_soft_delete_field(self):
        """Get the soft delete field for the view."""

        soft_delete_field = self.soft_delete_field

        # Check if the soft_delete_field attribute is set
        assert soft_delete_field is not None, (
            "'%s' should either include a `soft_delete_field` attribute, "
            "or override the `get_soft_delete_field()` method."
            % self.__class__.__name__
        )

        # Check if the soft_delete_field is a string
        assert isinstance(soft_delete_field, str), (
            "'%s.soft_delete_field' should be a string." % self.__class__.__name__
        )

        model = self.get_model()

        # Check if the model has the soft delete field
        soft_delete_column = self.get_model_column(soft_delete_field)
        assert soft_delete_column is not None, (
            "'%s' model does not have the soft delete field." % self.__class__.__name__
        )

        return soft_delete_field

    def get(self, *args, **kwargs):
        """Default GET method for the view. The default behavior is to return the instance.
        Override this method to customize the behavior."""

        # Get the instance or return 404
        instance = self.get_instance_or_404()

        # Get the schemas classes
        read_schema = self.get_read_schema()

        # Serialize the instance and return it
        serialized_instance = read_schema().dump(instance)

        # Return the serialized instance
        return serialized_instance, 200

    def pre_edit(self, instance):
        return None

    def post_edit(self, old_instance, updated_instance):
        pass

    def put(self, *args, **kwargs):
        """Default PUT method for the view. The default behavior is to update the instance.
        Override this method to customize the behavior."""

        # Get the instance or return 404
        instance = self.get_instance_or_404()

        # Save the old instance
        old_data = self.get_read_schema()().dump(instance)

        # Custom pre-edit logic
        pre_edit_context = self.pre_edit(instance)

        # Get the schemas classes
        read_schema = self.get_read_schema()
        write_schema = self.get_write_schema()

        # Get the request data
        data = self.get_request_data()

        # Instantiate the schema with the instance
        schema_context = self.get_schema_context()
        write_schema_instance = write_schema(instance=instance, context=schema_context)

        # Validate the data
        write_schema_instance.validate(data)

        # Update the instance
        updated_instance = write_schema_instance.save()

        # Serialize the updated instance and return it
        serialized_instance = read_schema().dump(updated_instance)

        # Custom post-edit logic
        self.post_edit(old_data, updated_instance, **(pre_edit_context or {}))

        return serialized_instance, 200

    def pre_delete(self, instance):
        pass

    def post_delete(self, instance):
        pass

    def delete(self, *args, **kwargs):
        """Default DELETE method for the view. The default behavior is to delete the instance.
        Override this method to customize the behavior."""

        # Get the instance or return 404
        instance = self.get_instance_or_404()

        # Custom pre-delete logic
        pre_delete_context = self.pre_delete(instance)

        # Get db from dflango context
        db = get_db()
        
        # Soft delete or hard delete the instance
        if self.is_soft_delete():
            instance.deleted_at = db.func.now()
        else:
            db.session.delete(instance)

        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logging.error(f"Error deleting instance: {e}")
            return jsonify({"error": "Error deleting instance"}), 500

        # Custom post-create logic
        self.post_delete(instance, **(pre_delete_context or {}))

        return jsonify({}), 204
