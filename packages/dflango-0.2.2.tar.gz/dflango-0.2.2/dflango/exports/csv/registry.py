class CSVExportRegistry:
    _schemas: dict[str, type] = {}

    @classmethod
    def register(cls, schema_cls):
        cls._schemas[schema_cls.export_type] = schema_cls
        return schema_cls

    @classmethod
    def has(cls, export_type: str) -> bool:
        return export_type in cls._schemas

    @classmethod
    def get(cls, export_type: str):
        schema_cls = cls._schemas.get(export_type)
        if not schema_cls:
            raise ValueError(f"Unknown export type: {export_type}")
        return schema_cls()
