# Built-in
from datetime import datetime

# Local
from dflango.exports.csv.fields import sanitize_csv_value


class ExportContext:
    def __init__(self, user=None, filters=None, requested_at=None, export_download=None):
        self.user = user
        self.filters = filters or {}
        self.requested_at = requested_at or datetime.utcnow()
        self.export_download = export_download

    @classmethod
    def from_export_download(cls, export_download):
        return cls(
            filters=export_download.filters_json or {},
            requested_at=export_download.created_at,
            export_download=export_download,
        )


class CSVExportSchema:
    export_type: str
    filename_prefix: str
    fields: list
    batch_size: int = 2000
    delimiter: str = ","
    encoding: str = "utf-8"
    include_bom: bool = False

    def validate_filters(self, filters: dict) -> dict:
        return filters

    def check_permissions(self, context: ExportContext) -> None:
        pass

    def get_queryset(self, context: ExportContext):
        raise NotImplementedError

    def get_filename(self, context: ExportContext) -> str:
        timestamp = context.requested_at.strftime("%Y%m%d_%H%M%S")
        return f"{self.filename_prefix}_{timestamp}.csv"

    def get_headers(self) -> list[str]:
        return [field.header for field in self.fields]

    def serialize_row(self, obj) -> list[str]:
        return [sanitize_csv_value(field.get_value(obj)) for field in self.fields]
