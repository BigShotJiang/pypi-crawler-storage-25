# Built-in
from dataclasses import dataclass
from typing import Any, Callable


DANGEROUS_CSV_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def sanitize_csv_value(value: str) -> str:
    if value is None:
        return ""

    value = str(value)

    if value.startswith(DANGEROUS_CSV_PREFIXES):
        return "'" + value

    return value


@dataclass(frozen=True)
class CSVField:
    key: str
    header: str
    getter: Callable[[Any], Any] | None = None
    formatter: Callable[[Any], str] | None = None
    default: str = ""

    def get_value(self, obj: Any) -> str:
        if self.getter:
            raw_value = self.getter(obj)
        else:
            raw_value = getattr(obj, self.key, None)

        if raw_value is None:
            return self.default

        if self.formatter:
            return self.formatter(raw_value)

        return str(raw_value)


def format_datetime(value):
    if not value:
        return ""
    return value.isoformat()


def format_date(value):
    if not value:
        return ""
    return value.isoformat()


def format_decimal(value):
    if value is None:
        return ""
    return str(value)


def format_bool(value):
    if value is None:
        return ""
    return "true" if value else "false"
