# Built-in
import importlib
from enum import Enum

# Flask
from flask import request, current_app

# Config
from dflango.config import DFlangoConfig


class PermissionsMixin:
    """
    Mixin that automatically resolves required roles from a centralized permissions
    class using the current Flask endpoint name. Use with dFlango BaseView subclasses.

    Class attributes:
        permissions_class: The class mapping endpoint → method → roles.
                           Set to None for public endpoints.

    Resolution priority:
        1. Class attribute on the view
        2. Flask config: DFLANGO_PERMISSIONS_CLASS
        3. DFlangoConfig default (None)
    """

    permissions_class = None

    def get_permissions_class(self):
        """
        Get the permissions class following priority:
        1. Class attribute
        2. Flask config
        3. dflango default config
        """
        # Class attribute (explicit override on the view)
        if self.permissions_class is not None:
            return self.permissions_class

        # Flask config
        perm_class = current_app.config.get("DFLANGO_PERMISSIONS_CLASS")
        if perm_class is not None:
            if isinstance(perm_class, str):
                module_name, class_name = perm_class.rsplit(".", 1)
                module = importlib.import_module(module_name)
                perm_class = getattr(module, class_name)
            return perm_class

        # dflango default config
        return getattr(DFlangoConfig, "PERMISSIONS_CLASS", None)

    def has_roles(self):
        permissions_class = self.get_permissions_class()
        if permissions_class is None:
            return super().has_roles()

        # 1. Get the endpoint name from the current request
        endpoint_name = request.endpoint
        if "." in endpoint_name:
            endpoint_name = endpoint_name.rsplit(".", 1)[1]

        # 2. Look up the endpoint in permissions_class
        endpoint_perm = getattr(permissions_class, endpoint_name, None)
        if endpoint_perm is None:
            return True  # No permissions configured → access granted

        # 3. Map HTTP method → EndpointPermission attribute
        method_attr = request.method.lower()
        if method_attr == "patch":
            method_attr = "put"
        required_roles = getattr(endpoint_perm, method_attr, [])

        if not required_roles:
            return True

        # 4. Normalize required roles
        required_roles = [
            (role.value if isinstance(role, Enum) else str(role)).lower()
            for role in required_roles
        ]

        # 5. Get the current user and compare roles
        user = self.get_current_user()
        if not user:
            return False

        field_name = self.get_access_field_name()
        user_roles_data = user.get(field_name)

        if user_roles_data is None:
            fallback_role = user.get("roles", user.get("role", ""))
            if isinstance(fallback_role, Enum):
                user_roles = [fallback_role.value]
            else:
                user_roles = [str(fallback_role)] if fallback_role else []
        elif isinstance(user_roles_data, str):
            user_roles = [user_roles_data]
        elif isinstance(user_roles_data, Enum):
            user_roles = [user_roles_data.value]
        elif isinstance(user_roles_data, list):
            user_roles = [
                (r.value if isinstance(r, Enum) else str(r))
                for r in user_roles_data
            ]
        else:
            user_roles = [str(user_roles_data)]

        return any(
            role in [r.lower() for r in user_roles]
            for role in required_roles
        )
