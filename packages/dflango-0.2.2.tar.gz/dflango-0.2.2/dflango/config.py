"""
Configuration settings for dflango.
"""


class DFlangoConfig:
    """
    Default configuration for dflango.
    
    You can override these settings in your Flask app config by prefixing with 'DFLANGO_'.
    
    Example:
        class Config:
            DFLANGO_DEFAULT_PAGE_SIZE = 50
            DFLANGO_ENABLE_SOFT_DELETE = False
            DFLANGO_JWT_SECRET_KEY = 'my-secret'
        
        app.config.from_object(Config)
    """
    
    # Authentication settings
    JWT_SECRET_KEY = None
    JWT_ALGORITHM = 'HS256'
    JWT_EXPIRATION_DELTA = 3600  # 1 hour in seconds
    
    # Database settings
    USE_DATABASE = True
    
    # Pagination settings
    DEFAULT_PAGE_SIZE = 10
    MAX_PAGE_SIZE = 100
    
    # Soft delete settings
    ENABLE_SOFT_DELETE = True
    SOFT_DELETE_FIELD = 'deleted_at'

    # CORS settings
    CORS_ORIGINS = "*"
    CORS_ALLOW_HEADERS = "*"
    CORS_SUPPORTS_CREDENTIALS = False
    
    # Search settings
    DEFAULT_SEARCH_SIZE = 50

    # BaseView settings
    ACCESS_TYPE = "role"  # "role" or "permission"
    ACCESS_FIELD_NAME = None  # Field name in user object to read roles/permissions from (defaults to "roles" for role-based, "permissions" for permission-based)
    USER_DATA_SOURCE = "DB"  # "DB", "JWT", or "FUNCTION"
    USER_MODEL = None  # SQLAlchemy model for User lookups
    FETCHER_FUNCTION = None  # Callable for custom user fetching
    PERMISSIONS_CLASS = None  # Centralized permissions class for PermissionsMixin
    
    def __init__(self, **kwargs):
        """Initialize config with optional overrides."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
    
    @classmethod
    def from_app_config(cls, app_config):
        """
        Create DFlangoConfig from Flask app config.
        
        Reads all config keys prefixed with 'DFLANGO_' and maps them to
        the corresponding DFlangoConfig attribute.
        
        Example:
            app.config['DFLANGO_DEFAULT_PAGE_SIZE'] = 50
            # Maps to: config.DEFAULT_PAGE_SIZE = 50
        """
        config = cls()
        for key in dir(cls):
            if key.isupper() and not key.startswith('_'):
                config_key = f'DFLANGO_{key}'
                if config_key in app_config:
                    setattr(config, key, app_config[config_key])
        return config
    
    def update_from_app_config(self, app_config):
        """
        Update existing config from Flask app config.
        
        Useful for updating configuration after initialization.
        """
        for key in dir(self.__class__):
            if key.isupper() and not key.startswith('_'):
                config_key = f'DFLANGO_{key}'
                if config_key in app_config:
                    setattr(self, key, app_config[config_key])
    
    def to_dict(self):
        """Return configuration as a dictionary."""
        return {
            key: getattr(self, key)
            for key in dir(self.__class__)
            if key.isupper() and not key.startswith('_')
        }
