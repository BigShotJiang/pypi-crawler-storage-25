class MethodPermission(list):
    """
    Permissions for a single HTTP method.
    Extends list so it can be used directly as a list of roles in views.
    """

    def __init__(self, roles, description=""):
        super().__init__(roles)
        self.description = description


class EndpointPermission:
    """
    Permissions for an endpoint (all HTTP methods).
    Each method is an attribute containing a MethodPermission instance.
    """

    def __init__(self, **methods):
        for method_name, config in methods.items():
            setattr(
                self,
                method_name,
                MethodPermission(
                    roles=config["roles"],
                    description=config["description"],
                ),
            )
