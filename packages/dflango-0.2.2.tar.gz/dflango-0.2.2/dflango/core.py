# Flask
from flask import current_app
from flask_cors import CORS

# Third-party
from werkzeug.local import LocalProxy

# Config
from dflango.config import DFlangoConfig

# Database
from dflango.db import db, migrate

# Providers
from dflango.providers import CustomJSONProvider

# Logging
from dflango.logging import Logger


class DFlango:
    """
    Main dflango extension class.
    
    Usage:
        from flask import Flask
        from flask_sqlalchemy import SQLAlchemy
        from dflango import DFlango
        
        app = Flask(__name__)
        db = SQLAlchemy(app)
        dflango = DFlango()
        dflango.init_app(app, db)
        
        # Logging is automatically configured with default Logger
        # To customize, pass a Logger class or instance:
        from dflango.logging import Logger
        
        class MyLogger(Logger):
            stdout_level = logging.INFO
        
        dflango.init_app(app, db, logger=MyLogger)
    """
    
    def __init__(self, app=None, db=None, logger=None):
        self.app = app
        self.db = db
        self.logger = logger
        self.config = DFlangoConfig()
        
        if app is not None and db is not None:
            self.init_app(app, db, logger)
    
    def init_app(self, app, app_config, route=None, logger=None):
        """
        Initialize the dflango extension with a Flask app and optionally register routes.
        
        Configuration is automatically loaded from app.config.
        Use 'DFLANGO_' prefix for dflango settings.
        
        Example:
            app.config['DFLANGO_DEFAULT_PAGE_SIZE'] = 50
            app.config['DFLANGO_ENABLE_SOFT_DELETE'] = False
        
        Args:
            app: Flask application instance
            app_config: Flask application configuration (can be app.config or a config object)
            route: Optional Route instance to register. If None, no routes will be registered.
            logger: Optional Logger class or instance for configuring application logging.
                   If None, a default Logger will be instantiated automatically.
                   Can be a Logger class (will be instantiated) or instance (will be configured).
        """
        self.app = app
        self.db = db
        self.route = route if route is not None else None
        
        # Configure logging
        if logger is None:
            # If no logger is provided, instantiate default Logger
            self.logger = Logger(app.name)
        elif isinstance(logger, type) and issubclass(logger, Logger):
            # If logger is a class, instantiate it
            self.logger = logger(app.name)
        elif isinstance(logger, Logger):
            # If it's already an instance, just store and configure it
            self.logger = logger
            # Configure if not already done (in case user created instance without auto-configure)
            self.logger.configure()
        else:
            raise TypeError(
                f"logger must be a Logger class or instance, got {type(logger)}"
            )
        
        
        # Load configuration from app config
        app.config.from_object(app_config)

        self.config = DFlangoConfig.from_app_config(app.config)

        # Initialize db and migrate with the app
        if self.config.USE_DATABASE:
            db.init_app(app)
            migrate.init_app(app, db)
        
        # Configure custom JSON provider
        app.json = CustomJSONProvider(app)
        
        # Store dflango instance in app extensions
        if not hasattr(app, 'extensions'):
            app.extensions = {}
        app.extensions['dflango'] = self
        
        # Register commands
        self._register_commands(app)

        # Apply DFlango CORS defaults to app.config so flask-cors picks them up.
        # Using setdefault ensures developer-defined values in Flask config are preserved.
        app.config.setdefault('CORS_ORIGINS', self.config.CORS_ORIGINS)
        app.config.setdefault('CORS_ALLOW_HEADERS', self.config.CORS_ALLOW_HEADERS)
        app.config.setdefault('CORS_SUPPORTS_CREDENTIALS', self.config.CORS_SUPPORTS_CREDENTIALS)

        # Enable CORS
        CORS(
            app=app,
            origins=app.config['CORS_ORIGINS'],
            allow_headers=app.config['CORS_ALLOW_HEADERS'],
            supports_credentials=app.config['CORS_SUPPORTS_CREDENTIALS'],
        )

        # Register routes (only if route is provided)
        if self.route is not None:
            self._register_routes()
    
    def update_config(self, **kwargs):
        """
        Update dflango configuration programmatically.
        
        Example:
            dflango.update_config(DEFAULT_PAGE_SIZE=50, ENABLE_SOFT_DELETE=False)
        
        Args:
            **kwargs: Configuration key-value pairs to update
        """
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
            else:
                raise ValueError(f"Unknown configuration key: {key}")
    
    def reload_config(self):
        """
        Reload configuration from Flask app config.
        
        Useful when app.config has been updated after initialization.
        """
        if self.app:
            self.config.update_from_app_config(self.app.config)
    
    def _register_routes(self):
        """
        Register the blueprint with the Flask app.
        """
        if self.route is None:
            return
        
        for route, view_func in self.route.urlpatterns:
            self.route.blueprint.add_url_rule(route, view_func=view_func)
        self.app.register_blueprint(
            self.route.blueprint, url_prefix=self.route.blueprint.url_prefix
        )

    def _register_commands(self, app):
        """Register Flask CLI commands."""
        from .commands import register_commands
        try:
            register_commands(app)
        except Exception:
            # Commands registration is optional
            pass


def get_dflango():
    """Get the current dflango instance from Flask app context."""
    try:
        return current_app.extensions['dflango']
    except (KeyError, RuntimeError):
        raise RuntimeError(
            "DFlango not initialized. "
            "Make sure to call dflango.init_app(app, db) before using dflango."
        )


def get_db():
    """Get the database instance from current dflango context."""
    return get_dflango().db


# Proxy objects for convenient access
_dflango = LocalProxy(get_dflango)
_db = LocalProxy(get_db)
