from pathlib import Path
import json

import numpy as np
from PIL import Image

from JwzTumor.nnunet.dataset_export import (
    build_training_case_filename,
    export_png_pairs_to_nnunet_raw,
)


def test_build_training_case_filename_uses_channel_suffix():
    path = build_training_case_filename(Path("sample.png"), image_id="case001", is_label=False)

    assert path.name == "case001_0000.png"


def test_build_training_label_filename_has_no_channel_suffix():
    path = build_training_case_filename(Path("sample.png"), image_id="case001", is_label=True)

    assert path.name == "case001.png"


def test_export_png_pairs_to_nnunet_raw_creates_dataset_layout(tmp_path: Path):
    image_dir = tmp_path / "images"
    mask_dir = tmp_path / "masks"
    image_dir.mkdir()
    mask_dir.mkdir()
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 127).save(image_dir / "bus_0001-l.png")
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 255).save(mask_dir / "mask_0001-l.png")

    dataset_root = export_png_pairs_to_nnunet_raw(
        image_dir=image_dir,
        mask_dir=mask_dir,
        output_root=tmp_path / "raw",
        dataset_id="201",
        dataset_name="BUS",
    )

    assert (dataset_root / "imagesTr" / "bus_0001-l_0000.png").exists()
    assert (dataset_root / "labelsTr" / "bus_0001-l.png").exists()
    data = json.loads((dataset_root / "dataset.json").read_text(encoding="utf-8"))
    assert data["numTraining"] == 1
    assert data["channel_names"]["0"] == "grayscale"
