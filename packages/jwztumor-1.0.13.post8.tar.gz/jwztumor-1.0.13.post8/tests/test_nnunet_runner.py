from JwzTumor.nnunet.runner import build_predict_from_modelfolder_command
from JwzTumor.nnunet.runner import (
    build_nnunet_env,
    build_plan_and_preprocess_command,
    build_train_command,
)


def test_build_predict_from_modelfolder_command():
    cmd = build_predict_from_modelfolder_command(
        input_dir="/tmp/in",
        output_dir="/tmp/out",
        model_dir="/tmp/model",
        folds=["0", "1"],
        checkpoint="checkpoint_best.pth",
    )

    assert cmd[0].endswith("nnUNetv2_predict_from_modelfolder")
    assert "-i" in cmd
    assert "/tmp/in" in cmd
    assert "-o" in cmd
    assert "/tmp/out" in cmd
    assert "-m" in cmd
    assert "/tmp/model" in cmd
    assert "-chk" in cmd
    assert "checkpoint_best.pth" in cmd


def test_build_predict_from_modelfolder_can_save_probabilities():
    cmd = build_predict_from_modelfolder_command(
        input_dir="/tmp/in",
        output_dir="/tmp/out",
        model_dir="/tmp/model",
        save_probabilities=True,
    )

    assert "--save_probabilities" in cmd


def test_build_plan_and_preprocess_command():
    cmd = build_plan_and_preprocess_command(dataset_id="201", verify_dataset_integrity=True)

    assert cmd[0].endswith("nnUNetv2_plan_and_preprocess")
    assert "-d" in cmd
    assert "201" in cmd
    assert "--verify_dataset_integrity" in cmd


def test_build_train_command():
    cmd = build_train_command(dataset_id="201", configuration="2d", fold="0")

    assert cmd[0].endswith("nnUNetv2_train")
    assert cmd[-3:] == ["201", "2d", "0"]


def test_build_nnunet_env_sets_required_paths():
    env = build_nnunet_env(
        raw_dir="/tmp/raw",
        preprocessed_dir="/tmp/preprocessed",
        results_dir="/tmp/results",
        base_env={"KEEP": "1"},
    )

    assert env["nnUNet_raw"] == "/tmp/raw"
    assert env["nnUNet_preprocessed"] == "/tmp/preprocessed"
    assert env["nnUNet_results"] == "/tmp/results"
    assert env["KEEP"] == "1"
