from pathlib import Path
from types import SimpleNamespace

import numpy as np
from PIL import Image

from JwzTumor.nnunet.prior_export import generate_probability_from_mask
from JwzTumor.nnunet.prior_export import export_dataset_prior_cache


def test_generate_probability_from_mask_binary():
    mask = np.array([[0, 255], [1, 0]], dtype=np.uint8)

    prob = generate_probability_from_mask(mask, mode="binary")

    assert prob.dtype == np.float32
    assert prob.tolist() == [[0.0, 1.0], [1.0, 0.0]]


def test_generate_probability_from_mask_distance_softens_boundary():
    mask = np.zeros((9, 9), dtype=np.uint8)
    mask[3:6, 3:6] = 255

    prob = generate_probability_from_mask(mask, mode="distance", sigma=2.0)

    assert prob.shape == mask.shape
    assert 0.0 <= float(prob.min()) <= float(prob.max()) <= 1.0
    assert prob[4, 4] > prob[0, 0]
    assert 0.0 < prob[2, 4] < 1.0


def test_export_dataset_prior_cache_from_busbra_masks(tmp_path: Path):
    data_root = tmp_path / "BUSBRA"
    image_dir = data_root / "Images"
    mask_dir = data_root / "Masks"
    image_dir.mkdir(parents=True)
    mask_dir.mkdir()
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 120).save(image_dir / "bus_0001-l.png")
    mask = np.zeros((8, 8), dtype=np.uint8)
    mask[2:6, 2:6] = 255
    Image.fromarray(mask).save(mask_dir / "mask_0001-l.png")
    (data_root / "bus_data.csv").write_text(
        "ID,Case,Pathology\nbus_0001-l,1,benign\n",
        encoding="utf-8",
    )

    cfg = SimpleNamespace(
        dataset=SimpleNamespace(
            train_root=str(data_root),
            train_image_dir="Images",
            train_mask_dir="Masks",
            train_csv="bus_data.csv",
            test_root="",
            test_classes=["benign", "malignant"],
            ignore_classes=[],
            model_input_size=16,
            pad_mode="zero",
            image_interpolation="bilinear",
            mask_interpolation="nearest",
            label_mapping={"benign": 0, "malignant": 1},
        ),
        nnunet=SimpleNamespace(
            prob_dir=str(tmp_path / "prob"),
            mask_dir=str(tmp_path / "seg_mask"),
            prior_dataset="train",
            prob_mode="gaussian",
            prob_sigma=1.0,
        ),
    )

    count = export_dataset_prior_cache(cfg)

    assert count == 1
    assert (tmp_path / "prob" / "bus_0001-l.npz").exists()
    assert (tmp_path / "seg_mask" / "bus_0001-l.png").exists()
    assert np.load(tmp_path / "prob" / "bus_0001-l.npz")["seg_prob"].shape == (16, 16)
