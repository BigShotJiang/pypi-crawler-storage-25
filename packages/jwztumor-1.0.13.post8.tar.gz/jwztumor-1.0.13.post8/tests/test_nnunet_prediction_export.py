from pathlib import Path

import numpy as np
from PIL import Image

from JwzTumor.nnunet.prediction_export import export_prediction_arrays
from JwzTumor.nnunet.prediction_export import export_prediction_directory
from JwzTumor.nnunet.prediction_export import extract_probability_map


def test_export_prediction_arrays_writes_npz_and_png(tmp_path: Path):
    prob = np.full((64, 64), 0.75, dtype=np.float32)
    mask = (prob >= 0.5).astype(np.uint8)

    export_prediction_arrays(
        image_id="case001",
        prob=prob,
        mask=mask,
        prob_dir=tmp_path / "prob",
        mask_dir=tmp_path / "mask",
    )

    prob_path = tmp_path / "prob" / "case001.npz"
    mask_path = tmp_path / "mask" / "case001.png"
    assert prob_path.exists()
    assert mask_path.exists()
    assert np.load(prob_path)["seg_prob"].dtype == np.float32
    assert np.array(Image.open(mask_path)).max() == 255


def test_export_prediction_directory_writes_cache_files(tmp_path: Path):
    source_dir = tmp_path / "raw_pred"
    source_dir.mkdir()
    np.savez_compressed(source_dir / "case001.npz", seg_prob=np.full((8, 8), 0.9, dtype=np.float32))

    count = export_prediction_directory(
        source_dir=source_dir,
        prob_dir=tmp_path / "prob",
        mask_dir=tmp_path / "mask",
        threshold=0.5,
    )

    assert count == 1
    assert (tmp_path / "prob" / "case001.npz").exists()
    assert (tmp_path / "mask" / "case001.png").exists()


def test_extract_probability_map_uses_foreground_channel():
    probs = np.zeros((2, 4, 4), dtype=np.float32)
    probs[1] = 0.8

    out = extract_probability_map(probs, foreground_channel=1)

    assert out.shape == (4, 4)
    assert np.allclose(out, 0.8)


def test_export_prediction_directory_reads_nnunet_probabilities_key(tmp_path: Path):
    source_dir = tmp_path / "raw_pred"
    source_dir.mkdir()
    probs = np.zeros((2, 8, 8), dtype=np.float32)
    probs[1] = 0.7
    np.savez_compressed(source_dir / "case001.npz", probabilities=probs)

    count = export_prediction_directory(
        source_dir=source_dir,
        prob_dir=tmp_path / "prob",
        mask_dir=tmp_path / "mask",
        threshold=0.5,
        foreground_channel=1,
    )

    assert count == 1
    assert np.allclose(np.load(tmp_path / "prob" / "case001.npz")["seg_prob"], 0.7)
