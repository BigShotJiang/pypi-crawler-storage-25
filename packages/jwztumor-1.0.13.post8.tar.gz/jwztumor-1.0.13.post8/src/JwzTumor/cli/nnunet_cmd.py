"""nnUNetv2 command group for JwzTumor CLI."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer

from ..nnunet.dataset_export import export_png_pairs_to_nnunet_raw
from ..nnunet.prediction_export import (
    export_prediction_arrays,
    export_prediction_directory,
    load_prediction_array,
)
from ..nnunet.prior_export import export_dataset_prior_cache
from ..nnunet.runner import (
    build_nnunet_env,
    build_plan_and_preprocess_command,
    build_predict_from_modelfolder_command,
    build_train_command,
    run_command,
)

nnunet_app = typer.Typer(help="nnUNetv2 子模块")


@nnunet_app.command("prepare")
def prepare(
    config: Optional[str] = typer.Option(None, "--config", "-c", help="JwzTumor V2 配置文件路径"),
    image_dir: Optional[str] = typer.Option(None, "--image-dir", help="训练图像 PNG 目录"),
    mask_dir: Optional[str] = typer.Option(None, "--mask-dir", help="训练 mask PNG 目录"),
    raw_dir: Optional[str] = typer.Option(None, "--raw-dir", help="nnUNet_raw 输出根目录"),
    dataset_id: Optional[str] = typer.Option(None, "--dataset-id", "-d", help="nnUNetv2 Dataset ID"),
    dataset_name: Optional[str] = typer.Option(None, "--dataset-name", help="nnUNetv2 Dataset 名称"),
):
    """导出 PNG 图像/mask 对到 nnUNetv2 raw dataset。"""
    if config:
        from ..utils.config import Config

        cfg = Config(config)
        image_dir = image_dir or str(cfg.dataset.train_root + "/" + cfg.dataset.train_image_dir)
        mask_dir = mask_dir or str(cfg.dataset.train_root + "/" + cfg.dataset.train_mask_dir)
        raw_dir = raw_dir or cfg.nnunet.raw_dir
        dataset_id = dataset_id or cfg.nnunet.dataset_id
        dataset_name = dataset_name or cfg.nnunet.dataset_name
    missing = [
        name for name, value in {
            "image_dir": image_dir,
            "mask_dir": mask_dir,
            "raw_dir": raw_dir,
            "dataset_id": dataset_id,
            "dataset_name": dataset_name,
        }.items() if not value
    ]
    if missing:
        typer.echo(f"Missing required options: {', '.join(missing)}", err=True)
        raise typer.Exit(2)
    dataset_root = export_png_pairs_to_nnunet_raw(
        image_dir=Path(image_dir),
        mask_dir=Path(mask_dir),
        output_root=Path(raw_dir),
        dataset_id=str(dataset_id),
        dataset_name=str(dataset_name),
    )
    typer.echo(f"Exported nnUNetv2 raw dataset: {dataset_root}")
    if config:
        typer.echo(f"Source config: {config}")
    raise typer.Exit(0)


@nnunet_app.command("preprocess")
def preprocess(
    config: Optional[str] = typer.Option(None, "--config", "-c", help="JwzTumor V2 配置文件路径"),
    dataset_id: Optional[str] = typer.Option(None, "--dataset-id", "-d", help="nnUNetv2 Dataset ID"),
    raw_dir: Optional[str] = typer.Option(None, "--raw-dir", help="nnUNet_raw 路径"),
    preprocessed_dir: Optional[str] = typer.Option(None, "--preprocessed-dir", help="nnUNet_preprocessed 路径"),
    results_dir: Optional[str] = typer.Option(None, "--results-dir", help="nnUNet_results 路径"),
    verify_dataset_integrity: bool = typer.Option(False, "--verify-dataset-integrity", help="启用 nnUNetv2 数据完整性校验"),
    dry_run: bool = typer.Option(False, "--dry-run", help="只打印命令，不执行"),
):
    """调用 nnUNetv2 plan_and_preprocess。"""
    cfg = _load_config(config)
    dataset_id = _resolve(dataset_id, cfg, "nnunet.dataset_id", "nnunet.dataset_id")
    raw_dir = _resolve(raw_dir, cfg, "nnunet.raw_dir", "nnunet.raw_dir")
    preprocessed_dir = _resolve(preprocessed_dir, cfg, "nnunet.preprocessed_dir", "nnunet.preprocessed_dir")
    results_dir = _resolve(results_dir, cfg, "nnunet.results_dir", "nnunet.results_dir")
    command = build_plan_and_preprocess_command(dataset_id, verify_dataset_integrity)
    env = build_nnunet_env(raw_dir, preprocessed_dir, results_dir)
    _run_or_print(command, env, dry_run)


@nnunet_app.command("train")
def train(
    config: Optional[str] = typer.Option(None, "--config", "-c", help="JwzTumor V2 配置文件路径"),
    dataset_id: Optional[str] = typer.Option(None, "--dataset-id", "-d", help="nnUNetv2 Dataset ID"),
    configuration: Optional[str] = typer.Option(None, "--configuration", help="nnUNetv2 configuration，例如 2d"),
    fold: Optional[str] = typer.Option(None, "--fold", "-f", help="训练 fold"),
    raw_dir: Optional[str] = typer.Option(None, "--raw-dir", help="nnUNet_raw 路径"),
    preprocessed_dir: Optional[str] = typer.Option(None, "--preprocessed-dir", help="nnUNet_preprocessed 路径"),
    results_dir: Optional[str] = typer.Option(None, "--results-dir", help="nnUNet_results 路径"),
    trainer: str = typer.Option("", "--trainer", help="自定义 nnUNetTrainer 名称"),
    plans: str = typer.Option("", "--plans", help="自定义 nnUNet plans 名称"),
    pretrained_weights: str = typer.Option("", "--pretrained-weights", help="预训练权重路径"),
    dry_run: bool = typer.Option(False, "--dry-run", help="只打印命令，不执行"),
):
    """调用 nnUNetv2_train。"""
    cfg = _load_config(config)
    dataset_id = _resolve(dataset_id, cfg, "nnunet.dataset_id", "nnunet.dataset_id")
    configuration = _resolve(configuration, cfg, "nnunet.configuration", default="2d")
    fold = _resolve(fold, cfg, "nnunet.fold", default="0")
    raw_dir = _resolve(raw_dir, cfg, "nnunet.raw_dir", "nnunet.raw_dir")
    preprocessed_dir = _resolve(preprocessed_dir, cfg, "nnunet.preprocessed_dir", "nnunet.preprocessed_dir")
    results_dir = _resolve(results_dir, cfg, "nnunet.results_dir", "nnunet.results_dir")
    command = build_train_command(dataset_id, configuration, fold, trainer, plans, pretrained_weights)
    env = build_nnunet_env(raw_dir, preprocessed_dir, results_dir)
    _run_or_print(command, env, dry_run)


@nnunet_app.command("pipeline")
def pipeline(
    config: Optional[str] = typer.Option(None, "--config", "-c", help="JwzTumor V2 配置文件路径"),
    dataset_id: Optional[str] = typer.Option(None, "--dataset-id", "-d", help="nnUNetv2 Dataset ID"),
    raw_dir: Optional[str] = typer.Option(None, "--raw-dir", help="nnUNet_raw 路径"),
    preprocessed_dir: Optional[str] = typer.Option(None, "--preprocessed-dir", help="nnUNet_preprocessed 路径"),
    results_dir: Optional[str] = typer.Option(None, "--results-dir", help="nnUNet_results 路径"),
    configuration: Optional[str] = typer.Option(None, "--configuration", help="nnUNetv2 configuration，例如 2d"),
    fold: Optional[str] = typer.Option(None, "--fold", "-f", help="训练 fold"),
    predict_input_dir: str = typer.Option("", "--predict-input-dir", help="可选：nnUNetv2 预测输入目录"),
    predict_output_dir: str = typer.Option("", "--predict-output-dir", help="可选：nnUNetv2 原始预测输出目录"),
    model_dir: str = typer.Option("", "--model-dir", help="可选：predict 阶段使用的 model folder"),
    checkpoint: Optional[str] = typer.Option(None, "--checkpoint", "-chk", help="predict 阶段 checkpoint 名称"),
    prob_dir: str = typer.Option("", "--prob-dir", help="可选：export 后的 seg_prob 缓存目录"),
    mask_dir: str = typer.Option("", "--mask-dir", help="可选：export 后的 mask 缓存目录"),
    prior_source: Optional[str] = typer.Option(None, "--prior-source", help="V2 先验来源: nnunet / dataset_mask / generated_prob"),
    prob_mode: Optional[str] = typer.Option(None, "--prob-mode", help="dataset mask 生成概率图模式"),
    threshold: Optional[float] = typer.Option(None, "--threshold", help="export 阶段概率阈值"),
    save_probabilities: Optional[bool] = typer.Option(None, "--save-probabilities/--no-save-probabilities", help="nnUNetv2 预测时保存概率图"),
    save_probabilitiesd: bool = typer.Option(False, "--save-probabilitiesd", hidden=True),
    verify_dataset_integrity: bool = typer.Option(False, "--verify-dataset-integrity", help="启用 nnUNetv2 数据完整性校验"),
    dry_run: bool = typer.Option(False, "--dry-run", help="只打印命令，不执行"),
):
    """串联 nnUNetv2 preprocess 与 train。"""
    cfg = _load_config(config)
    source = _resolve(prior_source, cfg, "nnunet.prior_source", default="nnunet")
    if source in {"dataset_mask", "generated_prob"}:
        mode = "binary" if source == "dataset_mask" else _resolve(prob_mode, cfg, "nnunet.prob_mode", default="binary")
        if dry_run:
            typer.echo(f"export dataset prior cache: source={source}, mode={mode}")
            return
        count = export_dataset_prior_cache(cfg, prob_mode=mode)
        typer.echo(f"Exported V2 prior cache: {count} samples")
        return

    dataset_id = _resolve(dataset_id, cfg, "nnunet.dataset_id", "nnunet.dataset_id")
    raw_dir = _resolve(raw_dir, cfg, "nnunet.raw_dir", "nnunet.raw_dir")
    preprocessed_dir = _resolve(preprocessed_dir, cfg, "nnunet.preprocessed_dir", "nnunet.preprocessed_dir")
    results_dir = _resolve(results_dir, cfg, "nnunet.results_dir", "nnunet.results_dir")
    configuration = _resolve(configuration, cfg, "nnunet.configuration", default="2d")
    fold = _resolve(fold, cfg, "nnunet.fold", default="0")
    predict_input_dir = _resolve_optional(predict_input_dir, cfg, "nnunet.predict_input_dir") or _default_predict_input_dir(
        raw_dir,
        dataset_id,
        _resolve_optional(None, cfg, "nnunet.dataset_name"),
    )
    predict_output_dir = _resolve_optional(predict_output_dir, cfg, "nnunet.predict_output_dir") or "dataset/v2_cache/nnunet_pred"
    model_dir = _resolve_optional(model_dir, cfg, "nnunet.model_dir") or _default_model_dir(
        results_dir,
        dataset_id,
        _resolve_optional(None, cfg, "nnunet.dataset_name"),
        configuration,
    )
    checkpoint = _resolve_optional(checkpoint, cfg, "nnunet.checkpoint") or "checkpoint_best.pth"
    prob_dir = _resolve_optional(prob_dir, cfg, "nnunet.prob_dir")
    mask_dir = _resolve_optional(mask_dir, cfg, "nnunet.mask_dir")
    save_probabilities = True if save_probabilitiesd else _resolve_bool(save_probabilities, cfg, "nnunet.save_probabilities", default=True)
    env = build_nnunet_env(raw_dir, preprocessed_dir, results_dir)
    commands = [
        build_plan_and_preprocess_command(dataset_id, verify_dataset_integrity),
        build_train_command(dataset_id, configuration, fold),
    ]
    if predict_input_dir and predict_output_dir and model_dir:
        commands.append(
            build_predict_from_modelfolder_command(
                input_dir=predict_input_dir,
                output_dir=predict_output_dir,
                model_dir=model_dir,
                folds=[fold],
                checkpoint=checkpoint,
                save_probabilities=save_probabilities,
            )
        )
    for command in commands:
        _run_or_print(command, env, dry_run)
    if prob_dir and mask_dir and predict_output_dir:
        if dry_run:
            typer.echo(f"export predictions: {predict_output_dir} -> {prob_dir}, {mask_dir}")
        else:
            export_prediction_directory(
                source_dir=Path(predict_output_dir),
                prob_dir=Path(prob_dir),
                mask_dir=Path(mask_dir),
                threshold=float(threshold if threshold is not None else (_resolve_optional(None, cfg, "nnunet.threshold") or 0.5)),
                foreground_channel=int(_resolve_optional(None, cfg, "nnunet.foreground_channel") or -1),
            )


@nnunet_app.command("predict")
def predict(
    config: Optional[str] = typer.Option(None, "--config", "-c", help="JwzTumor V2 配置文件路径"),
    input_dir: Optional[str] = typer.Option(None, "--input-dir", "-i", help="nnUNetv2 输入目录"),
    output_dir: Optional[str] = typer.Option(None, "--output-dir", "-o", help="nnUNetv2 输出目录"),
    model_dir: Optional[str] = typer.Option(None, "--model-dir", "-m", help="nnUNetv2 model folder"),
    folds: list[str] = typer.Option(["0"], "--fold", "-f", help="预测使用的 fold，可重复传入"),
    checkpoint: Optional[str] = typer.Option(None, "--checkpoint", "-chk", help="nnUNetv2 checkpoint 文件名"),
    save_probabilities: Optional[bool] = typer.Option(None, "--save-probabilities/--no-save-probabilities", help="保存 nnUNetv2 概率图"),
    save_probabilitiesd: bool = typer.Option(False, "--save-probabilitiesd", hidden=True),
    dry_run: bool = typer.Option(False, "--dry-run", help="只打印命令，不执行"),
):
    """调用 nnUNetv2 model folder 执行预测。"""
    cfg = _load_config(config)
    input_dir = _resolve(input_dir, cfg, "nnunet.predict_input_dir", "nnunet.predict_input_dir")
    output_dir = _resolve(output_dir, cfg, "nnunet.predict_output_dir", "nnunet.predict_output_dir")
    model_dir = _resolve(model_dir, cfg, "nnunet.model_dir", "nnunet.model_dir")
    folds = folds if folds != ["0"] or cfg is None else list(getattr(cfg.nnunet, "folds", []) or [getattr(cfg.nnunet, "fold", "0")])
    checkpoint = _resolve_optional(checkpoint, cfg, "nnunet.checkpoint") or "checkpoint_best.pth"
    save_probabilities = True if save_probabilitiesd else _resolve_bool(save_probabilities, cfg, "nnunet.save_probabilities", default=False)
    command = build_predict_from_modelfolder_command(
        input_dir=input_dir,
        output_dir=output_dir,
        model_dir=model_dir,
        folds=folds,
        checkpoint=checkpoint,
        save_probabilities=save_probabilities,
    )
    if dry_run:
        typer.echo(" ".join(command))
        raise typer.Exit(0)
    run_command(command)


@nnunet_app.command("export")
def export(
    config: Optional[str] = typer.Option(None, "--config", "-c", help="JwzTumor V2 配置文件路径"),
    image_id: Optional[str] = typer.Option(None, "--image-id", help="导出的病例 ID"),
    prob_path: Optional[str] = typer.Option(None, "--prob-path", help="概率图 .npy/.npz 路径"),
    mask_path: Optional[str] = typer.Option(None, "--mask-path", help="二值 mask .npy/.npz 路径"),
    prob_dir: Optional[str] = typer.Option(None, "--prob-dir", help="输出概率图缓存目录"),
    mask_dir: Optional[str] = typer.Option(None, "--mask-dir", help="输出 mask PNG 缓存目录"),
    source_dir: Optional[str] = typer.Option(None, "--source-dir", help="nnUNetv2 原始预测输出目录"),
    prior_source: Optional[str] = typer.Option(None, "--prior-source", help="V2 先验来源: nnunet / dataset_mask / generated_prob"),
    prior_dataset: Optional[str] = typer.Option(None, "--prior-dataset", help="生成缓存的数据集: train / test"),
    prob_mode: Optional[str] = typer.Option(None, "--prob-mode", help="dataset mask 生成概率图模式"),
    threshold: Optional[float] = typer.Option(None, "--threshold", help="导出 mask 使用的概率阈值"),
):
    """导出 JwzTumor V2 使用的概率图和二值 mask 缓存。"""
    cfg = _load_config(config)
    source = _resolve(prior_source, cfg, "nnunet.prior_source", default="nnunet")
    prob_dir = _resolve(prob_dir, cfg, "nnunet.prob_dir", "nnunet.prob_dir")
    mask_dir = _resolve(mask_dir, cfg, "nnunet.mask_dir", "nnunet.mask_dir")
    threshold = float(threshold if threshold is not None else (_resolve_optional(None, cfg, "nnunet.threshold") or 0.5))

    if source in {"dataset_mask", "generated_prob"}:
        mode = "binary" if source == "dataset_mask" else _resolve(prob_mode, cfg, "nnunet.prob_mode", default="binary")
        count = export_dataset_prior_cache(
            cfg,
            prior_dataset=prior_dataset,
            prob_mode=mode,
            prob_dir=prob_dir,
            mask_dir=mask_dir,
        )
        typer.echo(f"Exported V2 prior cache: {count} samples")
        return

    if image_id and prob_path and mask_path:
        prob = load_prediction_array(prob_path, key="seg_prob")
        mask = load_prediction_array(mask_path, key="mask")
        out_prob, out_mask = export_prediction_arrays(image_id, prob, mask, prob_dir, mask_dir)
        typer.echo(f"Exported {out_prob}")
        typer.echo(f"Exported {out_mask}")
        return

    source_dir = _resolve(source_dir, cfg, "nnunet.predict_output_dir", "nnunet.predict_output_dir")
    count = export_prediction_directory(
        source_dir=Path(source_dir),
        prob_dir=Path(prob_dir),
        mask_dir=Path(mask_dir),
        threshold=threshold,
        foreground_channel=int(_resolve_optional(None, cfg, "nnunet.foreground_channel") or -1),
    )
    typer.echo(f"Exported V2 prior cache: {count} samples")


def _load_config(config_path: Optional[str]):
    if not config_path:
        return None
    from ..utils.config import Config

    return Config(config_path)


def _get_config_value(config, dotted: str):
    if config is None:
        return None
    current = config
    for part in dotted.split("."):
        current = getattr(current, part, None)
        if current is None:
            return None
    return current


def _resolve(value, config, dotted: str, required_name: str | None = None, default=None):
    resolved = value if value not in (None, "") else _get_config_value(config, dotted)
    if resolved in (None, ""):
        resolved = default
    if resolved in (None, "") and required_name:
        typer.echo(f"Missing required option or config value: {required_name}", err=True)
        raise typer.Exit(2)
    return resolved


def _resolve_optional(value, config, dotted: str):
    return value if value not in (None, "") else _get_config_value(config, dotted)


def _resolve_bool(value, config, dotted: str, default: bool) -> bool:
    resolved = value if value is not None else _get_config_value(config, dotted)
    return default if resolved is None else bool(resolved)


def _default_predict_input_dir(raw_dir: str, dataset_id: str, dataset_name: Optional[str]) -> str:
    if not dataset_name:
        return ""
    return str(Path(raw_dir) / f"Dataset{int(dataset_id):03d}_{dataset_name}" / "imagesTr")


def _default_model_dir(results_dir: str, dataset_id: str, dataset_name: Optional[str], configuration: str) -> str:
    if not dataset_name:
        return ""
    return str(Path(results_dir) / f"Dataset{int(dataset_id):03d}_{dataset_name}" / f"nnUNetTrainer__nnUNetPlans__{configuration}")


def _run_or_print(command: list[str], env: dict[str, str], dry_run: bool) -> None:
    if dry_run:
        typer.echo(f"nnUNet_raw={env['nnUNet_raw']}")
        typer.echo(f"nnUNet_preprocessed={env['nnUNet_preprocessed']}")
        typer.echo(f"nnUNet_results={env['nnUNet_results']}")
        typer.echo(" ".join(command))
        return
    run_command(command, env=env)
