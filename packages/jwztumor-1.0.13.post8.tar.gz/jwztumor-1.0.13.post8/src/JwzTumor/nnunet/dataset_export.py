"""Helpers for exporting JwzTumor cases into nnUNetv2 naming conventions."""
from __future__ import annotations

import json
import shutil
from pathlib import Path


def build_training_case_filename(root: Path, image_id: str, is_label: bool) -> Path:
    """Return nnUNetv2 image/label filename for one 2D case."""
    suffix = ".png"
    filename = f"{image_id}{suffix}" if is_label else f"{image_id}_0000{suffix}"
    return Path(root) / filename


def copy_training_case(
    image_path: Path,
    label_path: Path,
    image_id: str,
    images_dir: Path,
    labels_dir: Path,
) -> tuple[Path, Path]:
    """Copy an image/mask pair into nnUNetv2 folder naming."""
    images_dir.mkdir(parents=True, exist_ok=True)
    labels_dir.mkdir(parents=True, exist_ok=True)
    image_out = build_training_case_filename(images_dir, image_id=image_id, is_label=False)
    label_out = build_training_case_filename(labels_dir, image_id=image_id, is_label=True)
    shutil.copy2(image_path, image_out)
    shutil.copy2(label_path, label_out)
    return image_out, label_out


def export_png_pairs_to_nnunet_raw(
    image_dir: Path,
    mask_dir: Path,
    output_root: Path,
    dataset_id: str,
    dataset_name: str,
) -> Path:
    """Export paired PNG image/mask files into a minimal nnUNetv2 raw dataset."""
    image_dir = Path(image_dir)
    mask_dir = Path(mask_dir)
    output_root = Path(output_root)
    dataset_root = output_root / f"Dataset{int(dataset_id):03d}_{dataset_name}"
    images_tr = dataset_root / "imagesTr"
    labels_tr = dataset_root / "labelsTr"

    num_training = 0
    for image_path in sorted(image_dir.glob("*.png")):
        image_id = image_path.stem
        mask_stem = image_id.removeprefix("bus_")
        candidate_masks = [
            mask_dir / f"mask_{mask_stem}.png",
            mask_dir / f"{image_id}.png",
        ]
        mask_path = next((path for path in candidate_masks if path.exists()), None)
        if mask_path is None:
            continue
        copy_training_case(image_path, mask_path, image_id=image_id, images_dir=images_tr, labels_dir=labels_tr)
        num_training += 1

    dataset_json = {
        "channel_names": {"0": "grayscale"},
        "labels": {"background": 0, "tumor": 1},
        "numTraining": num_training,
        "file_ending": ".png",
        "dataset_name": dataset_name,
    }
    dataset_root.mkdir(parents=True, exist_ok=True)
    (dataset_root / "dataset.json").write_text(
        json.dumps(dataset_json, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return dataset_root
