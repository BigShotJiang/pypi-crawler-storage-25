"""Command builders and runners for nnUNetv2 CLI integration."""
from __future__ import annotations

import subprocess
import shutil
import os
from collections.abc import Sequence


def build_predict_from_modelfolder_command(
    input_dir: str,
    output_dir: str,
    model_dir: str,
    folds: Sequence[str] | None = None,
    checkpoint: str = "",
    save_probabilities: bool = False,
) -> list[str]:
    """Build an nnUNetv2 prediction command without executing it."""
    executable = shutil.which("nnUNetv2_predict_from_modelfolder") or "nnUNetv2_predict_from_modelfolder"
    command = [executable, "-i", input_dir, "-o", output_dir, "-m", model_dir]
    if folds:
        command.extend(["-f", *[str(fold) for fold in folds]])
    if checkpoint:
        command.extend(["-chk", checkpoint])
    if save_probabilities:
        command.append("--save_probabilities")
    return command


def build_plan_and_preprocess_command(
    dataset_id: str,
    verify_dataset_integrity: bool = False,
) -> list[str]:
    """Build an nnUNetv2 plan/preprocess command without executing it."""
    executable = shutil.which("nnUNetv2_plan_and_preprocess") or "nnUNetv2_plan_and_preprocess"
    command = [executable, "-d", str(dataset_id)]
    if verify_dataset_integrity:
        command.append("--verify_dataset_integrity")
    return command


def build_train_command(
    dataset_id: str,
    configuration: str = "2d",
    fold: str = "0",
    trainer: str = "",
    plans: str = "",
    pretrained_weights: str = "",
) -> list[str]:
    """Build an nnUNetv2 train command without executing it."""
    executable = shutil.which("nnUNetv2_train") or "nnUNetv2_train"
    command = [executable, str(dataset_id), configuration, str(fold)]
    if trainer:
        command.extend(["-tr", trainer])
    if plans:
        command.extend(["-p", plans])
    if pretrained_weights:
        command.extend(["-pretrained_weights", pretrained_weights])
    return command


def build_nnunet_env(
    raw_dir: str,
    preprocessed_dir: str,
    results_dir: str,
    base_env: dict[str, str] | None = None,
) -> dict[str, str]:
    """Return an environment mapping with nnUNetv2 path variables set."""
    env = dict(base_env if base_env is not None else os.environ)
    env["nnUNet_raw"] = raw_dir
    env["nnUNet_preprocessed"] = preprocessed_dir
    env["nnUNet_results"] = results_dir
    return env


def run_command(command: Sequence[str], env: dict[str, str] | None = None) -> subprocess.CompletedProcess:
    """Run an external command and fail if nnUNetv2 returns an error."""
    return subprocess.run(list(command), check=True, env=env)
