"""Configuration parsing for nasde projects.

Reads nasde.toml and task.toml files to build a unified configuration
for benchmark runs. The [nasde.source] section in task.toml is the
only nasde-specific addition on top of Harbor's standard task.toml
schema — used to auto-generate a Dockerfile when one is not provided.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SourceConfig:
    """Git source for a task's codebase — used to auto-generate a Dockerfile."""

    git: str
    ref: str


@dataclass
class PluginConfig:
    """Local Claude Code plugin shipped into the sandbox image.

    Mirrors [nasde.source]: one declaration in task.toml stages a local
    plugin directory (a dir containing .claude-plugin/plugin.json) into the
    benchmark sandbox AND registers it for the Claude Code agent — its
    skills are discoverable and its MCP server (from <plugin>/.mcp.json) is
    wired — with no vendored snapshot and no triple hand-wiring.

    See ADR-009.
    """

    path: str
    ref: str = ""
    install_root: str = ""
    build: str = ""
    env: dict[str, str] = field(default_factory=dict)


@dataclass
class DockerConfig:
    """Docker environment configuration."""

    base_image: str = "ubuntu:22.04"
    build_commands: list[str] = field(default_factory=list)


@dataclass
class EvaluationConfig:
    """Assessment evaluation settings."""

    backend: str = "claude"
    model: str = "claude-opus-4-7"
    dimensions_file: str = "assessment_dimensions.json"
    max_turns: int = 30
    allowed_tools: list[str] | None = None
    mcp_config: str | None = None
    skills_dir: str | None = None
    append_system_prompt: str | None = None
    include_trajectory: bool = False


@dataclass
class ReportingConfig:
    """Reporting platform settings."""

    platform: str = "opik"
    project_name: str = ""


@dataclass
class TaskConfig:
    """Configuration for a single benchmark task.

    Source is optional — required only when the task has no
    environment/Dockerfile and nasde must auto-generate one. Plugin is
    optional — set only when the task ships a local Claude Code plugin.
    """

    name: str
    path: Path
    source: SourceConfig | None = None
    plugin: PluginConfig | None = None
    docker: DockerConfig = field(default_factory=DockerConfig)


@dataclass
class ProjectConfig:
    """Top-level project configuration from nasde.toml."""

    name: str
    version: str = "1.0.0"
    project_dir: Path = field(default_factory=lambda: Path.cwd())
    default_variant: str = "vanilla"
    default_harbor_env: str | None = None
    docker: DockerConfig = field(default_factory=DockerConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    reporting: ReportingConfig = field(default_factory=ReportingConfig)
    tasks: list[TaskConfig] = field(default_factory=list)


def load_project_config(project_dir: Path | None = None) -> ProjectConfig:
    """Load nasde.toml and discover task.toml files."""
    project_dir = _find_project_dir(project_dir)
    toml_path = project_dir / "nasde.toml"

    if not toml_path.exists():
        raise FileNotFoundError(f"No nasde.toml found in {project_dir}")

    with open(toml_path, "rb") as f:
        raw = tomllib.load(f)

    config = _parse_toml(raw, project_dir)
    config.tasks = _discover_tasks(project_dir, config.docker)
    return config


def _find_project_dir(start: Path | None) -> Path:
    """Walk up from start to find directory containing nasde.toml."""
    current = start or Path.cwd()
    for parent in [current, *current.parents]:
        if (parent / "nasde.toml").exists():
            return parent
    return current


def _parse_toml(raw: dict, project_dir: Path) -> ProjectConfig:
    project = raw.get("project", {})
    defaults = raw.get("defaults", {})
    docker_raw = raw.get("docker", {})
    eval_raw = raw.get("evaluation", {})
    reporting_raw = raw.get("reporting", {})

    return ProjectConfig(
        name=project.get("name", "unnamed"),
        version=project.get("version", "1.0.0"),
        project_dir=project_dir,
        default_variant=defaults.get("variant", "vanilla"),
        default_harbor_env=defaults.get("harbor_env"),
        docker=DockerConfig(
            base_image=docker_raw.get("base_image", "ubuntu:22.04"),
            build_commands=docker_raw.get("build_commands", []),
        ),
        evaluation=EvaluationConfig(
            backend=eval_raw.get("backend", "claude"),
            model=eval_raw.get("model", "claude-opus-4-7"),
            dimensions_file=eval_raw.get("dimensions_file", "assessment_dimensions.json"),
            max_turns=eval_raw.get("max_turns", 30),
            allowed_tools=eval_raw.get("allowed_tools"),
            mcp_config=eval_raw.get("mcp_config"),
            skills_dir=eval_raw.get("skills_dir"),
            append_system_prompt=eval_raw.get("append_system_prompt"),
            include_trajectory=eval_raw.get("include_trajectory", False),
        ),
        reporting=ReportingConfig(
            platform=reporting_raw.get("platform", "opik"),
            project_name=reporting_raw.get("project_name", project.get("name", "")),
        ),
    )


def _discover_tasks(project_dir: Path, default_docker: DockerConfig) -> list[TaskConfig]:
    """Find all task directories and load their task.toml."""
    tasks_dir = _resolve_tasks_dir(project_dir)
    if not tasks_dir.exists():
        return []

    tasks = []
    for task_path in sorted(tasks_dir.iterdir()):
        task_toml_path = task_path / "task.toml"
        if not task_toml_path.exists():
            continue
        task = _load_task(task_path, task_toml_path, default_docker)
        tasks.append(task)

    return tasks


def _resolve_tasks_dir(project_dir: Path) -> Path:
    """Resolve tasks directory — check .nasde/tasks/ first, then tasks/."""
    nasde_tasks = project_dir / ".nasde" / "tasks"
    if nasde_tasks.exists():
        return nasde_tasks
    return project_dir / "tasks"


def _load_task(
    task_path: Path,
    task_toml_path: Path,
    default_docker: DockerConfig,
) -> TaskConfig:
    with open(task_toml_path, "rb") as f:
        raw = tomllib.load(f)

    nasde_raw = raw.get("nasde", {})
    source_raw = nasde_raw.get("source", {})
    plugin_raw = nasde_raw.get("plugin", {})
    docker_raw = nasde_raw.get("docker", {})

    source: SourceConfig | None = None
    if source_raw.get("git"):
        source = SourceConfig(
            git=source_raw["git"],
            ref=source_raw.get("ref", "HEAD"),
        )

    plugin = _parse_plugin(plugin_raw)

    task_section = raw.get("task", {})
    name = _resolve_task_name(task_section.get("name"), task_path)

    return TaskConfig(
        name=name,
        path=task_path,
        source=source,
        plugin=plugin,
        docker=DockerConfig(
            base_image=docker_raw.get("base_image", default_docker.base_image),
            build_commands=docker_raw.get("build_commands", default_docker.build_commands),
        ),
    )


def _parse_plugin(plugin_raw: dict) -> PluginConfig | None:
    """Build a PluginConfig from the [nasde.plugin] table, if present.

    A plugin is declared only when ``path`` is set. ``ref`` defaults to the
    working tree (empty string, same semantics as SourceConfig). ``env`` is
    a free-form table forwarded to the generated MCP server wrapper.
    """
    if not plugin_raw.get("path"):
        return None
    env_raw = plugin_raw.get("env", {})
    return PluginConfig(
        path=plugin_raw["path"],
        ref=plugin_raw.get("ref", ""),
        install_root=plugin_raw.get("install_root", ""),
        build=plugin_raw.get("build", ""),
        env={str(k): str(v) for k, v in env_raw.items()},
    )


def _resolve_task_name(raw_name: str | None, task_path: Path) -> str:
    """Strip Harbor's 'org/' prefix from task name; fall back to directory name."""
    if not raw_name:
        return task_path.name
    return raw_name.split("/", 1)[-1]
