"use strict";(self.webpackChunkxtralab=self.webpackChunkxtralab||[]).push([["2501"],{8475(e,o,t){t.d(o,{A:()=>l});var r=t(1601),a=t.n(r),i=t(6314),n=t.n(i)()(a());n.push([e.id,`/*
    See the JupyterLab Developer Guide for useful CSS Patterns:

    https://jupyterlab.readthedocs.io/en/stable/developer/css.html
*/

.jp-xtralab-FileBrowser {
  display: flex;
  flex-direction: column;
  min-width: 200px;
  overflow: hidden;
  background-color: var(--jp-layout-color1);

  /*
   * Map @pierre/trees CSS variables to the active JupyterLab theme. The
   * \`*-override\` variants take precedence over the library's defaults, so
   * these values track the JupyterLab theme automatically — no JS needed
   * when the theme switches.
   */
  --trees-bg-override: var(--jp-layout-color1);
  --trees-bg-muted-override: var(--jp-layout-color2);
  --trees-fg-override: var(--jp-ui-font-color1);
  --trees-fg-muted-override: var(--jp-ui-font-color2);
  --trees-accent-override: var(--jp-brand-color1);
  --trees-border-color-override: var(--jp-border-color2);
  --trees-indent-guide-bg-override: var(--jp-border-color3);
  --trees-input-bg-override: var(--jp-input-background);
  --trees-search-bg-override: var(--jp-input-background);
  --trees-search-fg-override: var(--jp-ui-font-color1);
  --trees-focus-ring-color-override: var(--jp-brand-color1);
  --trees-selected-bg-override: var(--jp-brand-color1);
  --trees-selected-fg-override: var(--jp-ui-inverse-font-color1);
  --trees-selected-focused-border-color-override: var(--jp-brand-color1);
  --trees-font-family-override: var(--jp-ui-font-family);
  --trees-font-size-override: var(--jp-ui-font-size1);

  /*
   * Push the search box, the scroll wrapper, and every row inside the
   * tree away from the sidebar edge. \`--trees-padding-inline\` is the
   * outer gutter the @pierre/trees host uses for the search box and the
   * scroll container, and the row strip sits inside that gutter — so
   * matching the 12px the JupyterLab toolbar uses on its sides keeps
   * the toolbar buttons, the search bar, and the row hover/selection
   * highlights vertically aligned. Row content padding stays at the
   * default 4px so the icon → text rhythm doesn't change.
   */
  --trees-padding-inline-override: 12px;
  --trees-item-padding-x-override: 4px;

  /* Must carry a length unit. The library subtracts this from
     \`--trees-padding-inline\` inside a \`calc()\`; a unitless \`0\` makes the
     subtraction type-invalid, the whole padding-inline rule drops out,
     and the rows snap back to the sidebar edge. */
  --trees-item-margin-x-override: 0px;
}

/*
 * Match the spacing the default file browser uses around its top toolbar
 * (8px above, 12px on each side, flush with the content below). Without
 * this, the toolbar inherits jp-Toolbar's default border + padding which
 * looks heavier than the rest of the JupyterLab sidebar.
 */
.jp-xtralab-FileBrowser-toolbar.jp-Toolbar {
  flex: 0 0 auto;
  height: auto;
  margin: 8px 12px 0;
  padding: 0;
  border-bottom: none;
  box-shadow: none;
}

.jp-xtralab-FileBrowser-toolbar.jp-Toolbar::part(positioning-region) {
  row-gap: 12px;
}

.jp-xtralab-FileBrowser-toolbar > .jp-Toolbar-item {
  flex: 0 0 auto;
  padding-left: 0;
  align-items: center;
  height: unset;
}

.jp-xtralab-FileBrowser-toolbar > .jp-Toolbar-item .jp-ToolbarButtonComponent {
  width: 28px;
}

/*
 * Promote the "new launcher" button to the same blue, wider call-to-action
 * the default file browser uses for \`launcher:create\`. The selectors mirror
 * the rules in \`@jupyterlab/launcher-extension/style/base.css\`, but target
 * our own command id and toolbar wrapper class.
 */
.jp-xtralab-FileBrowser-toolbar
  > .jp-Toolbar-item
  .jp-ToolbarButtonComponent[data-command='xtralab:new-launcher'] {
  width: 72px;
  background: var(--jp-accept-color-normal, var(--jp-brand-color1));
}

.jp-xtralab-FileBrowser-toolbar
  > .jp-Toolbar-item
  .jp-ToolbarButtonComponent[data-command='xtralab:new-launcher']:hover {
  background-color: var(--jp-accept-color-hover);
}

.jp-xtralab-FileBrowser-toolbar
  > .jp-Toolbar-item
  .jp-ToolbarButtonComponent[data-command='xtralab:new-launcher']:focus-visible {
  background-color: var(--jp-accept-color-active, var(--jp-brand-color0));
}

.jp-xtralab-FileBrowser-toolbar
  > .jp-Toolbar-item
  .jp-ToolbarButtonComponent[data-command='xtralab:new-launcher']
  .jp-icon3 {
  fill: var(--jp-layout-color1);
}

.jp-xtralab-FileBrowser-content {
  flex: 1 1 auto;
  display: flex;
  min-height: 0;
}

.jp-xtralab-FileBrowser-content > div {
  flex: 1 1 auto;
  display: flex;
  min-height: 0;
}

.jp-xtralab-FileBrowser file-tree-container {
  flex: 1 1 auto;
  min-height: 0;
}

/*
 * Drag image shown next to the cursor while dragging files out of the
 * tree. Mirrors the visual weight of the default file browser's drag
 * preview without depending on its DOM.
 */
.jp-xtralab-DragImage {
  position: absolute;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 2px 6px;
  background-color: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  border-radius: 2px;
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: var(--jp-ui-font-size1);
  pointer-events: none;
}

.jp-xtralab-DragImage-icon {
  display: inline-flex;
  align-items: center;
}

.jp-xtralab-DragImage-count {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  background-color: var(--jp-brand-color1);
  border-radius: 8px;
  color: var(--jp-ui-inverse-font-color1);
  font-size: var(--jp-ui-font-size0);
  line-height: 1;
}
`,""]);let l=n},6758(e,o,t){t.d(o,{A:()=>l});var r=t(1601),a=t.n(r),i=t(6314),n=t.n(i)()(a());n.push([e.id,`/*
 * Styles for the git changes panel and the diff viewer. The panel mirrors
 * the visual rhythm of the default JupyterLab side panels so it does not
 * stand out from the rest of the UI.
 */

.jp-xtralab-GitPanel {
  display: flex;
  flex-direction: column;
  min-width: 240px;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: var(--jp-ui-font-size1);
  overflow: hidden;
}

.jp-xtralab-GitPanel-content {
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
}

.jp-xtralab-GitPanel-header {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 8px 12px;
  border-bottom: 1px solid var(--jp-border-color2);
}

.jp-xtralab-GitPanel-headerInfo {
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex: 1 1 auto;
  min-width: 0;
}

.jp-xtralab-GitPanel-title {
  font-weight: 600;
  text-transform: uppercase;
  font-size: var(--jp-ui-font-size0);
  letter-spacing: 0.04em;
  color: var(--jp-ui-font-color2);
}

.jp-xtralab-GitPanel-repo {
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.jp-xtralab-GitPanel-branch {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-xtralab-GitPanel-error {
  margin: 12px;
  padding: 8px;
  border-radius: 4px;
  background-color: var(
    --jp-error-color3,
    var(--jp-rendermime-error-background)
  );
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size1);
  white-space: pre-wrap;
}

.jp-xtralab-GitPanel-empty {
  margin: 12px;
  color: var(--jp-ui-font-color2);
  font-style: italic;
  text-align: center;
}

.jp-xtralab-GitPanel-section {
  display: flex;
  flex-direction: column;
}

/*
 * Section headers and rows place their hover actions between the label
 * and the trailing count/badge, so the count stays pinned to the right
 * edge regardless of whether the section has any bulk actions. Reserving
 * the action width via \`visibility: hidden\` keeps the layout from
 * shifting when the cursor enters and leaves.
 */
.jp-xtralab-GitPanel-sectionHeader {
  display: flex;
  align-items: center;
  gap: 4px;
  height: 28px;
  padding: 0 12px;
  cursor: pointer;
  user-select: none;
  text-transform: uppercase;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  letter-spacing: 0.04em;
  color: var(--jp-ui-font-color2);
}

.jp-xtralab-GitPanel-sectionHeader:hover {
  background-color: var(--jp-layout-color2);
}

.jp-xtralab-GitPanel-sectionChevron {
  width: 12px;
  text-align: center;
  font-size: 10px;
}

.jp-xtralab-GitPanel-sectionLabel {
  flex: 1 1 auto;
}

.jp-xtralab-GitPanel-sectionCount {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 18px;
  height: 16px;
  padding: 0 4px;
  background-color: var(--jp-layout-color3);
  color: var(--jp-ui-font-color1);
  border-radius: 8px;
  font-size: var(--jp-ui-font-size0);
  font-weight: 500;
  line-height: 1;
}

.jp-xtralab-GitPanel-sectionActions {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  visibility: hidden;
}

.jp-xtralab-GitPanel-sectionHeader:hover .jp-xtralab-GitPanel-sectionActions {
  visibility: visible;
}

.jp-xtralab-GitPanel-sectionBody {
  display: flex;
  flex-direction: column;
}

/*
 * Three-column row layout: the label group on the left grows, the actions
 * column has a fixed reserved width that fits the worst-case button count,
 * and the badge column is auto-sized on the right edge. Reserving the
 * action column keeps the badge horizontally pinned regardless of the
 * row's hover state.
 */
.jp-xtralab-GitPanel-row {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 12px;
  cursor: pointer;
  user-select: none;
}

.jp-xtralab-GitPanel-row:hover {
  background-color: var(--jp-layout-color2);
}

.jp-xtralab-GitPanel-rowLabel {
  display: flex;
  align-items: baseline;
  gap: 6px;
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
}

.jp-xtralab-GitPanel-rowName {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 0 1 auto;
}

.jp-xtralab-GitPanel-rowPath {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 0 1 auto;
}

.jp-xtralab-GitPanel-rowActions {
  /*
   * Reserved width matches the worst case of two 20px buttons + a 2px
   * gap. Staged rows only host the unstage button, but pinning the
   * column width keeps the trailing badge horizontally aligned across
   * the staged and unstaged sections.
   */
  display: inline-flex;
  align-items: center;
  justify-content: flex-end;
  gap: 2px;
  flex: 0 0 42px;
  visibility: hidden;
}

.jp-xtralab-GitPanel-row:hover .jp-xtralab-GitPanel-rowActions,
.jp-xtralab-GitPanel-rowActions[data-pending='true'] {
  visibility: visible;
}

.jp-xtralab-GitPanel-rowBadge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: 0 0 16px;
  width: 16px;
  height: 16px;
  border-radius: 2px;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  font-family: var(--jp-code-font-family);
}

.jp-xtralab-GitPanel-rowBadge[data-status='modified'] {
  color: var(--jp-warn-color1);
}

.jp-xtralab-GitPanel-rowBadge[data-status='added'],
.jp-xtralab-GitPanel-rowBadge[data-status='untracked'] {
  color: var(--jp-success-color1);
}

.jp-xtralab-GitPanel-rowBadge[data-status='deleted'] {
  color: var(--jp-error-color1);
}

.jp-xtralab-GitPanel-rowBadge[data-status='renamed'] {
  color: var(--jp-info-color1, var(--jp-brand-color1));
}

.jp-xtralab-GitPanel-rowBadge[data-status='unmerged'] {
  color: var(--jp-error-color1);
}

.jp-xtralab-GitPanel-iconButton {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border: none;
  background: transparent;
  color: var(--jp-ui-font-color1);
  cursor: pointer;
  border-radius: 2px;
  font-size: var(--jp-ui-font-size1);
  line-height: 1;
}

.jp-xtralab-GitPanel-iconButton:hover {
  background-color: var(--jp-layout-color3);
}

.jp-xtralab-GitPanel-iconButton:disabled {
  opacity: 0.4;
  cursor: default;
}

/*
 * Diff viewer (main area). The \`MainAreaWidget\` holding the React content
 * gets sized by JupyterLab's box layout; the inner content div fills it
 * and provides vertical scroll. Horizontal scrolling within each code
 * block is owned by \`@pierre/diffs\` via its internal \`data-code\` rules.
 *
 * The block also forwards JupyterLab's theme variables onto the
 * \`--diffs-*-override\` properties the library exposes, so the diff
 * recolors with the active theme.
 */
.jp-xtralab-DiffWidget {
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
}

/*
 * Flex-column container: an optional toolbar at the top (notebook view
 * mode toggle) plus a body that hosts the scrollable diff and the
 * column resize handle. Splitting these responsibilities keeps the
 * resize handle pinned to the visible viewport while the diff content
 * scrolls underneath, and keeps the toolbar always visible.
 */
.jp-xtralab-DiffWidget-content {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);

  /*
   * Map JupyterLab's theme variables onto the \`--diffs-*-override\`
   * properties the library exposes. The \`*-override\` variants take
   * precedence over the library's defaults, so these values track the
   * JupyterLab theme automatically — no JS needed when the theme
   * switches. Theme-dependent colors (insertion green, deletion red, …)
   * still come from the active Shiki theme passed via \`options.theme\`.
   */
  --diffs-bg-override: var(--jp-layout-color1);
  --diffs-bg-buffer-override: var(--jp-layout-color1);
  --diffs-bg-context-override: var(--jp-layout-color1);
  --diffs-bg-separator-override: var(--jp-layout-color2);
  --diffs-bg-hover-override: var(--jp-layout-color2);
  --diffs-bg-selection-override: var(--jp-layout-color3);
  --diffs-bg-selection-number-override: var(--jp-layout-color3);
  --diffs-fg-override: var(--jp-ui-font-color1);
  --diffs-fg-number-override: var(--jp-ui-font-color3);
  --diffs-fg-conflict-marker-override: var(--jp-warn-color1);
  --diffs-modified-color-override: var(--jp-warn-color1);
}

/*
 * Body wrapping the scrollable diff + the column resize handle. Owns
 * its own positioning context so the resizer can be absolutely placed
 * within the body's bounds (and therefore aligned with the visible
 * scroll area, not the toolbar above it).
 */
.jp-xtralab-DiffWidget-body {
  position: relative;
  flex: 1 1 auto;
  min-height: 0;
}

.jp-xtralab-DiffWidget-scroll {
  position: absolute;
  inset: 0;
  overflow: auto;
}

/*
 * Notebook/JSON view-mode selector that lives in the \`MainAreaWidget\`
 * toolbar for \`.ipynb\` diffs. The host toolbar provides its own
 * background and border, so this is just the segmented control itself.
 */
.jp-xtralab-DiffWidget-viewModeToolbarItem {
  display: flex;
  align-items: center;
  font-size: var(--jp-ui-font-size0);
}

.jp-xtralab-DiffWidget-segmented {
  display: inline-flex;
  border: 1px solid var(--jp-border-color2);
  border-radius: 3px;
  overflow: hidden;
  background-color: var(--jp-layout-color1);
}

.jp-xtralab-DiffWidget-segmentedButton {
  padding: 2px 10px;
  border: none;
  background: transparent;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
  cursor: pointer;
  line-height: 1.4;
}

.jp-xtralab-DiffWidget-segmentedButton:hover {
  background-color: var(--jp-layout-color2);
}

.jp-xtralab-DiffWidget-segmentedButton[data-active='true'] {
  background-color: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.jp-xtralab-DiffWidget-segmentedButton[data-active='true']:hover {
  background-color: var(--jp-brand-color1);
}

/*
 * Draggable column splitter. Sits on top of the diff (z-index above the
 * content) but stays a thin strip so it doesn't visually intrude. The
 * \`transform: translateX(-50%)\` centers the strip on the column boundary
 * the inline \`left\` percentage points to.
 */
.jp-xtralab-DiffWidget-resizer {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 6px;
  transform: translateX(-50%);
  cursor: col-resize;
  z-index: 2;
  background-color: transparent;
  transition: background-color 0.1s ease;
  user-select: none;
  touch-action: none;
}

.jp-xtralab-DiffWidget-resizer:hover,
.jp-xtralab-DiffWidget-resizer[data-dragging='true'] {
  background-color: var(--jp-brand-color1);
}

.jp-xtralab-DiffWidget-status {
  margin: 12px;
  padding: 12px;
  border-radius: 4px;
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size1);
  white-space: pre-wrap;
}

.jp-xtralab-DiffWidget-status[data-error='true'] {
  background-color: var(
    --jp-error-color3,
    var(--jp-rendermime-error-background)
  );
  color: var(--jp-ui-font-color1);
}

/*
 * Per-hunk action overlay. The diff library injects a row at the
 * annotation's anchor line and renders this content inside it; we keep the
 * row visually unobtrusive — a single small icon button that fades in on
 * row hover — so the annotation does not compete with the diff content.
 */
.jp-xtralab-DiffWidget-hunkAnnotation {
  display: flex;
  justify-content: flex-end;
  padding: 0 8px;
  opacity: 0.4;
  transition: opacity 0.1s ease;
}

.jp-xtralab-DiffWidget-hunkAnnotation:hover {
  opacity: 1;
}

.jp-xtralab-DiffWidget-hunkButton {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: none;
  border-radius: 3px;
  background: transparent;
  color: var(--jp-ui-font-color1);
  cursor: pointer;
}

.jp-xtralab-DiffWidget-hunkButton:hover {
  background-color: var(--jp-layout-color3);
}

.jp-xtralab-DiffWidget-hunkButton-icon {
  display: inline-flex;
  width: 14px;
  height: 14px;
}

/*
 * Notebook diff. Renders one block per cell stacked vertically, plus an
 * optional notebook-level metadata block at the bottom. Each cell carries
 * its own header (kind badge + cell index + cell type) and a body with the
 * source / outputs / metadata sub-diffs the @pierre/diffs library produces.
 *
 * The sticky header keeps the scope visible while the user scrolls through
 * a long cell, and the data-kind attributes drive the colored badges and
 * left borders that distinguish added / removed / modified / unchanged.
 */
.jp-xtralab-NotebookDiff {
  display: flex;
  flex-direction: column;
  padding: 8px;
  gap: 8px;
}

/*
 * The cell entry grid. Two equal columns mirror the old / new mental model
 * the column header bar establishes; each cell entry below either spans
 * both columns (modified / unchanged) or sits in a single column with an
 * empty placeholder on the other side (added / removed). Auto rows let
 * each cell pick its own height naturally.
 */
.jp-xtralab-NotebookDiff-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px 8px;
  align-items: stretch;
}

.jp-xtralab-NotebookDiff-cell[data-placement='full'] {
  grid-column: 1 / -1;
}

.jp-xtralab-NotebookDiff-cell[data-placement='left'] {
  grid-column: 1;
}

.jp-xtralab-NotebookDiff-cell[data-placement='right'] {
  grid-column: 2;
}

/*
 * Empty placeholder rendered in the column opposite an added or removed
 * cell. Visible (dashed outline) so the user can see the alignment gap
 * the missing cell creates between old and new. Sized roughly like a
 * minimal cell card so the row height is consistent.
 */
.jp-xtralab-NotebookDiff-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 60px;
  padding: 12px;
  border: 1px dashed var(--jp-border-color2);
  border-radius: 4px;
  background-color: transparent;
}

.jp-xtralab-NotebookDiff-emptyLabel {
  color: var(--jp-ui-font-color3);
  font-size: var(--jp-ui-font-size0);
  font-style: italic;
}

.jp-xtralab-NotebookDiff-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 4px 8px;
  border-bottom: 1px solid var(--jp-border-color2);
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color1);
}

.jp-xtralab-NotebookDiff-headerCount {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-xtralab-NotebookDiff-stat {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.jp-xtralab-NotebookDiff-stat[data-kind='modified'] {
  color: var(--jp-warn-color1);
}

.jp-xtralab-NotebookDiff-stat[data-kind='added'] {
  color: var(--jp-success-color1);
}

.jp-xtralab-NotebookDiff-stat[data-kind='removed'] {
  color: var(--jp-error-color1);
}

.jp-xtralab-NotebookDiff-cell {
  display: flex;
  flex-direction: column;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background-color: var(--jp-layout-color1);
  overflow: hidden;
}

.jp-xtralab-NotebookDiff-cellHeader {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 10px;
  background-color: var(--jp-layout-color2);
  cursor: pointer;
  user-select: none;
  font-size: var(--jp-ui-font-size1);
}

.jp-xtralab-NotebookDiff-cellHeader:hover {
  background-color: var(--jp-layout-color3);
}

.jp-xtralab-NotebookDiff-cellChevron {
  width: 12px;
  text-align: center;
  font-size: 10px;
  color: var(--jp-ui-font-color2);
}

.jp-xtralab-NotebookDiff-cellBadge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  border-radius: 3px;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  font-family: var(--jp-code-font-family);
  background-color: var(--jp-layout-color1);
}

.jp-xtralab-NotebookDiff-cellBadge[data-kind='added'] {
  color: var(--jp-success-color1);
}

.jp-xtralab-NotebookDiff-cellBadge[data-kind='removed'] {
  color: var(--jp-error-color1);
}

.jp-xtralab-NotebookDiff-cellBadge[data-kind='modified'] {
  color: var(--jp-warn-color1);
}

.jp-xtralab-NotebookDiff-cellBadge[data-kind='unchanged'] {
  color: var(--jp-ui-font-color3);
}

.jp-xtralab-NotebookDiff-cellLabel {
  flex: 1 1 auto;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
}

.jp-xtralab-NotebookDiff-cellHint {
  color: var(--jp-ui-font-color3);
  font-size: var(--jp-ui-font-size0);
  font-style: italic;
}

.jp-xtralab-NotebookDiff-cellBody {
  display: flex;
  flex-direction: column;
}

.jp-xtralab-NotebookDiff-cellEmpty {
  padding: 8px 12px;
  color: var(--jp-ui-font-color3);
  font-style: italic;
  font-size: var(--jp-ui-font-size0);
}

.jp-xtralab-NotebookDiff-subdiff {
  display: flex;
  flex-direction: column;
  border-top: 1px solid var(--jp-border-color2);
}

.jp-xtralab-NotebookDiff-subdiff:first-child {
  border-top: none;
}

.jp-xtralab-NotebookDiff-subdiffLabel {
  padding: 4px 12px;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
  text-transform: uppercase;
  letter-spacing: 0.04em;
  font-weight: 600;
  border-bottom: 1px solid var(--jp-border-color3);
}

/*
 * The verbatim source listing rendered when the user expands an unchanged
 * cell. We don't pass it through @pierre/diffs because there is no diff —
 * just the cell contents — but match the diff library's monospace rhythm
 * so the surrounding cells still look uniform.
 */
.jp-xtralab-NotebookDiff-unchangedSource {
  margin: 0;
  padding: 8px 12px;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
  color: var(--jp-content-font-color1, var(--jp-ui-font-color1));
  white-space: pre-wrap;
  word-break: break-word;
}

.jp-xtralab-NotebookDiff-unchangedRendered,
.jp-xtralab-NotebookDiff-unchangedOutputs {
  padding: 8px 12px;
  background-color: var(--jp-layout-color1);
}

.jp-xtralab-NotebookDiff-unchangedOutputs {
  border-top: 1px solid var(--jp-border-color3);
}

/*
 * Side-by-side panes used by both OutputsSection and MarkdownPreviewSection.
 * The grid columns mirror the split-mode FileDiff above so the two halves
 * read as the same left=old / right=new mental model the user is already
 * tracking on the source diff.
 */
.jp-xtralab-NotebookDiff-sideBySide {
  display: flex;
  flex-direction: column;
  border-top: 1px solid var(--jp-border-color2);
}

.jp-xtralab-NotebookDiff-sideBySideGrid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  background-color: var(--jp-layout-color1);
}

.jp-xtralab-NotebookDiff-sideBySide[data-layout='single']
  .jp-xtralab-NotebookDiff-sideBySideGrid {
  grid-template-columns: 1fr;
}

/*
 * Each pane takes one column. The data-side colored bar on the left edge
 * matches the cell-block kind colors so the pane's role (old vs new) is
 * clear even in dark theme where the diff library's column-tint is subtle.
 */
.jp-xtralab-NotebookDiff-sidePane {
  padding: 8px 12px;
  min-width: 0;
  overflow-x: auto;
  background-color: var(--jp-layout-color1);
}

.jp-xtralab-NotebookDiff-sidePane[data-side='old'] {
  border-right: 1px solid var(--jp-border-color3);
  background-color: var(--jp-layout-color0, var(--jp-layout-color1));
}

.jp-xtralab-NotebookDiff-sidePane[data-side='new'] {
  background-color: var(--jp-layout-color1);
}

/*
 * Rendermime widgets bring their own padding/margin defaults; we constrain
 * them to the pane width so a wide HTML output (table, image) doesn't push
 * the grid out of shape.
 */
.jp-xtralab-NotebookDiff-sidePane .jp-RenderedHTMLCommon,
.jp-xtralab-NotebookDiff-sidePane .jp-OutputArea {
  max-width: 100%;
}

.jp-xtralab-NotebookDiff-sidePane .jp-OutputArea-output img {
  max-width: 100%;
  height: auto;
}

.jp-xtralab-NotebookDiff-fallbackText {
  margin: 0;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
  color: var(--jp-content-font-color1, var(--jp-ui-font-color1));
  white-space: pre-wrap;
  word-break: break-word;
}
`,""]);let l=n},6314(e){e.exports=function(e){var o=[];return o.toString=function(){return this.map(function(o){var t="",r=void 0!==o[5];return o[4]&&(t+="@supports (".concat(o[4],") {")),o[2]&&(t+="@media ".concat(o[2]," {")),r&&(t+="@layer".concat(o[5].length>0?" ".concat(o[5]):""," {")),t+=e(o),r&&(t+="}"),o[2]&&(t+="}"),o[4]&&(t+="}"),t}).join("")},o.i=function(e,t,r,a,i){"string"==typeof e&&(e=[[null,e,void 0]]);var n={};if(r)for(var l=0;l<this.length;l++){var s=this[l][0];null!=s&&(n[s]=!0)}for(var d=0;d<e.length;d++){var p=[].concat(e[d]);r&&n[p[0]]||(void 0!==i&&(void 0===p[5]||(p[1]="@layer".concat(p[5].length>0?" ".concat(p[5]):""," {").concat(p[1],"}")),p[5]=i),t&&(p[2]&&(p[1]="@media ".concat(p[2]," {").concat(p[1],"}")),p[2]=t),a&&(p[4]?(p[1]="@supports (".concat(p[4],") {").concat(p[1],"}"),p[4]=a):p[4]="".concat(a)),o.push(p))}},o}},1601(e){e.exports=function(e){return e[1]}},5072(e){var o=[];function t(e){for(var t=-1,r=0;r<o.length;r++)if(o[r].identifier===e){t=r;break}return t}function r(e,r){for(var a={},i=[],n=0;n<e.length;n++){var l=e[n],s=r.base?l[0]+r.base:l[0],d=a[s]||0,p="".concat(s," ").concat(d);a[s]=d+1;var c=t(p),f={css:l[1],media:l[2],sourceMap:l[3],supports:l[4],layer:l[5]};if(-1!==c)o[c].references++,o[c].updater(f);else{var u=function(e,o){var t=o.domAPI(o);return t.update(e),function(o){o?(o.css!==e.css||o.media!==e.media||o.sourceMap!==e.sourceMap||o.supports!==e.supports||o.layer!==e.layer)&&t.update(e=o):t.remove()}}(f,r);r.byIndex=n,o.splice(n,0,{identifier:p,updater:u,references:1})}i.push(p)}return i}e.exports=function(e,a){var i=r(e=e||[],a=a||{});return function(e){e=e||[];for(var n=0;n<i.length;n++){var l=t(i[n]);o[l].references--}for(var s=r(e,a),d=0;d<i.length;d++){var p=t(i[d]);0===o[p].references&&(o[p].updater(),o.splice(p,1))}i=s}}},7659(e){var o={};e.exports=function(e,t){var r=function(e){if(void 0===o[e]){var t=document.querySelector(e);if(window.HTMLIFrameElement&&t instanceof window.HTMLIFrameElement)try{t=t.contentDocument.head}catch(e){t=null}o[e]=t}return o[e]}(e);if(!r)throw Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");r.appendChild(t)}},540(e){e.exports=function(e){var o=document.createElement("style");return e.setAttributes(o,e.attributes),e.insert(o,e.options),o}},5056(e,o,t){e.exports=function(e){var o=t.nc;o&&e.setAttribute("nonce",o)}},7825(e){e.exports=function(e){if("u"<typeof document)return{update:function(){},remove:function(){}};var o=e.insertStyleElement(e);return{update:function(t){var r,a,i;r="",t.supports&&(r+="@supports (".concat(t.supports,") {")),t.media&&(r+="@media ".concat(t.media," {")),(a=void 0!==t.layer)&&(r+="@layer".concat(t.layer.length>0?" ".concat(t.layer):""," {")),r+=t.css,a&&(r+="}"),t.media&&(r+="}"),t.supports&&(r+="}"),(i=t.sourceMap)&&"u">typeof btoa&&(r+="\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(i))))," */")),e.styleTagTransform(r,o,e.options)},remove:function(){var e;null===(e=o).parentNode||e.parentNode.removeChild(e)}}}},1113(e){e.exports=function(e,o){if(o.styleSheet)o.styleSheet.cssText=e;else{for(;o.firstChild;)o.removeChild(o.firstChild);o.appendChild(document.createTextNode(e))}}},3028(e,o,t){var r=t(5072),a=t.n(r),i=t(7825),n=t.n(i),l=t(7659),s=t.n(l),d=t(5056),p=t.n(d),c=t(540),f=t.n(c),u=t(1113),b=t.n(u),h=t(8475),g={};g.styleTagTransform=b(),g.setAttributes=p(),g.insert=s().bind(null,"head"),g.domAPI=n(),g.insertStyleElement=f(),a()(h.A,g),h.A&&h.A.locals&&h.A.locals;var v=t(6758),x={};x.styleTagTransform=b(),x.setAttributes=p(),x.insert=s().bind(null,"head"),x.domAPI=n(),x.insertStyleElement=f(),a()(v.A,x),v.A&&v.A.locals&&v.A.locals}}]);