"""Tests for mosesaic-mcp — uses FastMCP + in-memory transport (no real network).

mcp.shared.memory.create_connected_server_and_client_session spins up a
FastMCP server and a ClientSession connected to it via in-process streams,
so no ports are opened and tests run completely in-process.
"""

from __future__ import annotations

import pytest
from mcp.server.fastmcp import FastMCP
from mcp.shared.memory import create_connected_server_and_client_session

from mosesaic.mcp.session import MCPSession, ToolInfo


# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def math_server() -> FastMCP:
    server = FastMCP("math")

    @server.tool()
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    @server.tool()
    def multiply(a: int, b: int) -> int:
        """Multiply two numbers."""
        return a * b

    return server


@pytest.fixture
def echo_server() -> FastMCP:
    server = FastMCP("echo")

    @server.tool()
    def echo(message: str) -> str:
        """Echo the message back."""
        return message

    @server.tool()
    def upper(text: str) -> str:
        """Return text in uppercase."""
        return text.upper()

    @server.tool()
    def fail_tool(reason: str) -> str:
        """Always raises."""
        raise ValueError(f"intentional failure: {reason}")

    return server


# ── list_tools ────────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_list_tools_returns_all_tools(echo_server):
    async with create_connected_server_and_client_session(echo_server) as client_session:
        session = MCPSession(client_session)
        tools = await session.list_tools()

    assert isinstance(tools, list)
    names = [t.name for t in tools]
    assert "echo" in names
    assert "upper" in names
    assert "fail_tool" in names


@pytest.mark.anyio
async def test_list_tools_returns_tool_info_objects(math_server):
    async with create_connected_server_and_client_session(math_server) as client_session:
        session = MCPSession(client_session)
        tools = await session.list_tools()

    assert all(isinstance(t, ToolInfo) for t in tools)
    add_info = next(t for t in tools if t.name == "add")
    assert add_info.description == "Add two numbers."
    assert isinstance(add_info.schema, dict)


# ── call_tool ─────────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_call_tool_returns_text_result(echo_server):
    async with create_connected_server_and_client_session(echo_server) as client_session:
        session = MCPSession(client_session)
        result = await session.call_tool("echo", {"message": "hello"})

    assert result == "hello"


@pytest.mark.anyio
async def test_call_tool_integer_result(math_server):
    async with create_connected_server_and_client_session(math_server) as client_session:
        session = MCPSession(client_session)
        result = await session.call_tool("add", {"a": 3, "b": 4})

    # FastMCP serialises int return values as text
    assert result == "7" or result == 7


@pytest.mark.anyio
async def test_call_tool_raises_on_error(echo_server):
    # The error is caught inside the context; must assert before exiting it
    raised: list[Exception] = []
    async with create_connected_server_and_client_session(echo_server) as client_session:
        session = MCPSession(client_session)
        try:
            await session.call_tool("fail_tool", {"reason": "test"})
        except RuntimeError as exc:
            raised.append(exc)
    assert raised, "Expected RuntimeError from fail_tool"
    assert "intentional failure" in str(raised[0])


@pytest.mark.anyio
async def test_call_tool_no_arguments(echo_server):
    """call_tool with empty arguments dict should not crash."""
    async with create_connected_server_and_client_session(echo_server) as client_session:
        session = MCPSession(client_session)
        result = await session.call_tool("echo", {"message": "no-args"})
    assert result == "no-args"


# ── tool_registry ─────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_tool_registry_names_match_server(math_server):
    async with create_connected_server_and_client_session(math_server) as client_session:
        session = MCPSession(client_session)
        registry = await session.tool_registry()

    assert "add" in registry.names()
    assert "multiply" in registry.names()


@pytest.mark.anyio
async def test_tool_registry_call_returns_tool_result(echo_server):
    result_holder: list = []
    async with create_connected_server_and_client_session(echo_server) as client_session:
        session = MCPSession(client_session)
        registry = await session.tool_registry()
        result_holder.append(await registry.call("echo", message="world"))

    result = result_holder[0]
    assert result.success
    assert result.output == "world"


@pytest.mark.anyio
async def test_tool_registry_error_captured_in_result(echo_server):
    result_holder: list = []
    async with create_connected_server_and_client_session(echo_server) as client_session:
        session = MCPSession(client_session)
        registry = await session.tool_registry()
        result_holder.append(await registry.call("fail_tool", reason="bang"))

    result = result_holder[0]
    assert not result.success
    assert result.error is not None
    assert "intentional failure" in result.error


@pytest.mark.anyio
async def test_tool_registry_missing_tool_fails_gracefully(echo_server):
    async with create_connected_server_and_client_session(echo_server) as client_session:
        session = MCPSession(client_session)
        registry = await session.tool_registry()
        result = await registry.call("nonexistent")

    assert not result.success
    assert "not registered" in (result.error or "")


# ── Integration: MCP tools inside AgentRuntime ────────────────────────────────


@pytest.mark.anyio
async def test_agent_uses_mcp_tool_via_ctx(math_server):
    """An agent registered in AgentRuntime can call MCP tools via ctx.tools."""
    import anyio
    from mosesaic.core.agent import agent
    from mosesaic.core.context import AgentContext
    from mosesaic.core.runtime import AgentRuntime

    results: list = []

    @agent(name="calculator")
    async def calculator(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        a, b = msg.payload
        result = await ctx.tools.call("add", a=a, b=b)
        results.append(result.output)

    async with create_connected_server_and_client_session(math_server) as client_session:
        session = MCPSession(client_session)
        registry = await session.tool_registry()

        runtime = AgentRuntime(tools=registry)
        runtime.register(calculator)

        async with runtime.run():
            await runtime.send("calculator", payload=(6, 7))
            await anyio.sleep(0.1)

    # FastMCP serialises int return values as text
    assert results[0] == "13" or results[0] == 13
