"""MCPClient — entry point for connecting to an MCP server.

Supports two transports:
  - Streamable HTTP  (MCPClient.http(url))
  - stdio            (MCPClient.stdio(command, *args))

Usage:
    from mosesaic.mcp import MCPClient
    from mosesaic.core import AgentRuntime

    # HTTP server
    async with MCPClient.http("http://localhost:8001/mcp").connect() as session:
        tools = await session.tool_registry()
        runtime = AgentRuntime(tools=tools)
        runtime.register(my_agent)
        async with runtime.run():
            await runtime.send("my-agent", payload="do something")

    # stdio server (e.g. npx-based MCP server)
    async with MCPClient.stdio("npx", "-y", "@modelcontextprotocol/server-filesystem", "/tmp").connect() as session:
        tools = await session.tool_registry()
        ...
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator, Sequence

from mosesaic.mcp.session import MCPSession


class MCPClient:
    """Configures how to connect to one MCP server.

    Create via the class methods ``http()`` or ``stdio()``, then use
    ``async with client.connect() as session:`` to open a live connection.

    The connection is kept open for the lifetime of the ``async with`` block.
    Any ToolRegistry produced inside that block is only valid while the
    connection is live.
    """

    def __init__(
        self,
        *,
        transport: str,
        url: str | None = None,
        command: str | None = None,
        args: Sequence[str] = (),
    ) -> None:
        self._transport = transport
        self._url = url
        self._command = command
        self._args = list(args)

    @classmethod
    def http(cls, url: str) -> "MCPClient":
        """Connect to an MCP server via Streamable HTTP.

        Args:
            url: Full URL to the MCP endpoint, e.g. ``http://localhost:8001/mcp``.
        """
        return cls(transport="http", url=url)

    @classmethod
    def stdio(cls, command: str, *args: str) -> "MCPClient":
        """Connect to an MCP server via stdio (subprocess).

        Args:
            command: Executable to run, e.g. ``npx`` or ``python``.
            *args: Arguments passed to the command.
        """
        return cls(transport="stdio", command=command, args=args)

    @asynccontextmanager
    async def connect(self) -> AsyncIterator[MCPSession]:
        """Open a connection to the MCP server and yield an MCPSession.

        The session remains live for the duration of the ``async with`` block.
        Closes cleanly on exit (or on exception).
        """
        if self._transport == "http":
            async for session in self._connect_http():
                yield session
        elif self._transport == "stdio":
            async for session in self._connect_stdio():
                yield session
        else:
            raise ValueError(f"Unknown transport: {self._transport!r}")

    @asynccontextmanager
    async def _connect_http(self) -> AsyncIterator[MCPSession]:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        assert self._url is not None
        async with streamablehttp_client(self._url) as (read, write, _):
            async with ClientSession(read, write) as session:
                await session.initialize()
                yield MCPSession(session)

    @asynccontextmanager
    async def _connect_stdio(self) -> AsyncIterator[MCPSession]:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        assert self._command is not None
        params = StdioServerParameters(command=self._command, args=self._args)
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                yield MCPSession(session)
