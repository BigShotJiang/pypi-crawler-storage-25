"""MCPSession — live connection to one MCP server.

Wraps mcp.ClientSession to expose a mosesaic-friendly API:
  - list_tools() → list of ToolInfo
  - call_tool(name, arguments) → Python value or raises on error
  - tool_registry() → ToolRegistry with all server tools pre-registered

The registry's NativeTool wrappers delegate to the live session, so
the MCPClient context manager must remain open for the lifetime of
any ToolRegistry produced here.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from mcp import ClientSession


@dataclass(frozen=True)
class ToolInfo:
    """Metadata for one tool advertised by an MCP server."""

    name: str
    description: str
    schema: dict  # JSON Schema for the tool's input arguments


class MCPSession:
    """Live connection to one MCP server.

    Do not instantiate directly — obtain via ``MCPClient.connect()``.
    """

    def __init__(self, session: ClientSession) -> None:
        self._session = session

    async def list_tools(self) -> list[ToolInfo]:
        """Return metadata for every tool advertised by the server."""
        result = await self._session.list_tools()
        return [
            ToolInfo(
                name=t.name,
                description=t.description or "",
                schema=t.inputSchema if isinstance(t.inputSchema, dict) else {},
            )
            for t in result.tools
        ]

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        """Call a tool on the server and return its extracted output.

        Returns:
            str if the result is a single text block.
            list[str] if the result contains multiple text blocks.
            dict if the result has structured content (outputSchema).
            None if the server returned no content.

        Raises:
            RuntimeError: If the server returned isError=True.
        """
        result = await self._session.call_tool(name, arguments or {})
        if result.isError:
            error_text = "; ".join(
                getattr(c, "text", str(c)) for c in result.content
            )
            raise RuntimeError(f"MCP tool '{name}' returned an error: {error_text}")

        # Prefer text content (universal across MCP servers).
        # Fall back to structuredContent only when there is no text output.
        text = _extract_text_content(result.content)
        if text is not None:
            return text
        if result.structuredContent:
            return result.structuredContent
        return None

    async def tool_registry(self) -> "ToolRegistry":  # type: ignore[name-defined]
        """Return a ToolRegistry with every server tool registered as a NativeTool.

        Each NativeTool wraps a closure that calls this session. The registry
        is only usable while this MCPClient context is open.
        """
        from mosesaic.tools.registry import ToolRegistry
        from mosesaic.tools.tool import NativeTool

        tools_result = await self._session.list_tools()
        registry = ToolRegistry()

        for tool_def in tools_result.tools:
            registry.register(
                _make_wrapper(self._session, tool_def.name, tool_def.description or "")
            )

        return registry


# ── Helpers ───────────────────────────────────────────────────────────────────


def _extract_text_content(content: list) -> Any:
    """Extract text from a list of MCP content blocks."""
    texts = [c.text for c in content if hasattr(c, "text")]
    if not texts:
        return None
    return texts[0] if len(texts) == 1 else texts


def _make_wrapper(session: ClientSession, name: str, description: str):
    """Return a NativeTool that delegates to the MCP server tool."""
    from mosesaic.tools.tool import NativeTool

    async def _call(**kwargs: Any) -> Any:
        result = await session.call_tool(name, arguments=kwargs if kwargs else None)
        if result.isError:
            error_text = "; ".join(getattr(c, "text", str(c)) for c in result.content)
            raise RuntimeError(f"MCP tool '{name}' returned an error: {error_text}")
        text = _extract_text_content(result.content)
        if text is not None:
            return text
        if result.structuredContent:
            return result.structuredContent
        return None

    return NativeTool(name=name, fn=_call, description=description)
