---
name: eval_isolation
description: Eval system must be fully isolated — never touch live sims or running apps
type: feedback
---

Eval replay runs MUST NOT interact with live simulators or running apps. Stuart caught eval agents using pepper-ctl against his Ice Cubes app on booted sims.

**Why:** Stuart uses the sims for real work. Eval agents interacting with live sims disrupts his workflow and produces unreliable results.

**How to apply:** Before running any eval, ensure:
1. Replay MCP server is actually connected (check init log for status: "connected", not "failed")
2. pepper-ctl via Bash is blocked in eval mode (guardrail, not prompt)
3. Never run eval commands without verifying isolation first
4. If MCP server fails, the eval should FAIL — not fall back to live sim
