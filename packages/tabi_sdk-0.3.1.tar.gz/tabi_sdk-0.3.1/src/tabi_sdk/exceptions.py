from __future__ import annotations

from typing import Any


class TabiError(Exception):
    """HTTP or API error from the Tabi REST API."""

    def __init__(self, message: str, status: int = 0, body: Any = None) -> None:
        super().__init__(message)
        self.status = status
        self.body = body
