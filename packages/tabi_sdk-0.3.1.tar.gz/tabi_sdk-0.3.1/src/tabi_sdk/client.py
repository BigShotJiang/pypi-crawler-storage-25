from __future__ import annotations

from tabi_sdk.http import HttpClient
from tabi_sdk.resources.analytics import Analytics
from tabi_sdk.resources.api_keys import ApiKeys
from tabi_sdk.resources.auth import Auth
from tabi_sdk.resources.automation_installs import AutomationInstalls
from tabi_sdk.resources.automation_templates import AutomationTemplates
from tabi_sdk.resources.campaigns import Campaigns
from tabi_sdk.resources.channels import Channels
from tabi_sdk.resources.contacts import Contacts
from tabi_sdk.resources.conversations import Conversations
from tabi_sdk.resources.files import Files
from tabi_sdk.resources.integrations import Integrations
from tabi_sdk.resources.messages import Messages
from tabi_sdk.resources.notifications import Notifications
from tabi_sdk.resources.quick_replies import QuickReplies
from tabi_sdk.resources.webhooks import Webhooks
from tabi_sdk.resources.workspaces import Workspaces


class TabiClient:
    """
    Official Tabi REST client. Use a workspace **API key** (``tk_...``) or user **JWT** depending on the endpoint.

    Example::

        client = TabiClient(api_key=\"tk_...\", base_url=\"https://api.tabi.africa/api/v1\")
        client.messages.send(channel_id, {\"to\": \"2347000000000\", \"content\": \"Hello\"})
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.tabi.africa/api/v1",
        timeout: float = 30.0,
    ) -> None:
        http = HttpClient(base_url.rstrip("/"), api_key, timeout=timeout)
        self.auth = Auth(http)
        self.channels = Channels(http)
        self.messages = Messages(http)
        self.contacts = Contacts(http)
        self.conversations = Conversations(http)
        self.webhooks = Webhooks(http)
        self.api_keys = ApiKeys(http)
        self.files = Files(http)
        self.campaigns = Campaigns(http)
        self.automation_templates = AutomationTemplates(http)
        self.automation_installs = AutomationInstalls(http)
        self.quick_replies = QuickReplies(http)
        self.analytics = Analytics(http)
        self.notifications = Notifications(http)
        self.integrations = Integrations(http)
        self.workspaces = Workspaces(http)
