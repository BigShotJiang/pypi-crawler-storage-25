from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Notifications:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/notifications", query)

    def mark_read(self, id: str) -> Any:
        return self._http.patch(f"/notifications/{id}/read", None)

    def mark_all_read(self) -> Any:
        return self._http.post("/notifications/read-all", None)

    def unread_count(self) -> Any:
        return self._http.get("/notifications/unread-count")
