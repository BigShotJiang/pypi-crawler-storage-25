from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Analytics:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def dashboard(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/analytics/dashboard", query)

    def channels(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/analytics/channels", query)

    def conversations(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/analytics/conversations", query)
