from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Campaigns:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/campaigns", dict(data))

    def list(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/campaigns", query)

    def get(self, id: str) -> Any:
        return self._http.get(f"/campaigns/{id}")

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/campaigns/{id}", dict(data))

    def delete(self, id: str) -> Any:
        return self._http.delete(f"/campaigns/{id}")

    def schedule(self, id: str) -> Any:
        return self._http.post(f"/campaigns/{id}/schedule", None)

    def pause(self, id: str) -> Any:
        return self._http.post(f"/campaigns/{id}/pause", None)

    def resume(self, id: str) -> Any:
        return self._http.post(f"/campaigns/{id}/resume", None)

    def cancel(self, id: str) -> Any:
        return self._http.post(f"/campaigns/{id}/cancel", None)
