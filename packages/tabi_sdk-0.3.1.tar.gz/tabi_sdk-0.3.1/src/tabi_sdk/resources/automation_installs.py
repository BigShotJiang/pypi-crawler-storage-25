from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class AutomationInstalls:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def install(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/automation-installs", dict(data))

    def list(self) -> Any:
        return self._http.get("/automation-installs")

    def get(self, id: str) -> Any:
        return self._http.get(f"/automation-installs/{id}")

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/automation-installs/{id}", dict(data))

    def enable(self, id: str) -> Any:
        return self._http.post(f"/automation-installs/{id}/enable", None)

    def disable(self, id: str) -> Any:
        return self._http.post(f"/automation-installs/{id}/disable", None)

    def uninstall(self, id: str) -> Any:
        return self._http.delete(f"/automation-installs/{id}")
