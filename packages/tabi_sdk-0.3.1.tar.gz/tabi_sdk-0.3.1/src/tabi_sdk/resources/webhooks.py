from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Webhooks:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/webhooks", dict(data))

    def list(self) -> Any:
        return self._http.get("/webhooks")

    def get(self, id: str) -> Any:
        return self._http.get(f"/webhooks/{id}")

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/webhooks/{id}", dict(data))

    def delete(self, id: str) -> Any:
        return self._http.delete(f"/webhooks/{id}")

    def ping(self, id: str) -> Any:
        return self._http.post(f"/webhooks/{id}/ping", None)

    def rotate_secret(self, id: str) -> Any:
        return self._http.post(f"/webhooks/{id}/rotate-secret", None)

    def delivery_logs(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/webhooks/delivery-logs", query)

    def start_test_capture(self) -> Any:
        return self._http.post("/webhooks/test-capture/start", None)

    def stop_test_capture(self) -> Any:
        return self._http.post("/webhooks/test-capture/stop", None)

    def test_capture_status(self) -> Any:
        return self._http.get("/webhooks/test-capture/status")
