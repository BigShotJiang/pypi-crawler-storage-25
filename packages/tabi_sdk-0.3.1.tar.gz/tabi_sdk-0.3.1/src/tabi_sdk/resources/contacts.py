from __future__ import annotations

from typing import Any, Mapping
from urllib.parse import quote

from tabi_sdk.http import HttpClient


class Contacts:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/contacts", dict(data))

    def list(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/contacts", query)

    def get(self, id: str) -> Any:
        return self._http.get(f"/contacts/{id}")

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/contacts/{id}", dict(data))

    def delete(self, id: str) -> Any:
        return self._http.delete(f"/contacts/{id}")

    def import_contacts(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/contacts/import", dict(data))

    def get_tags(self, id: str) -> Any:
        return self._http.get(f"/contacts/{id}/tags")

    def add_tag(self, id: str, tag: str) -> Any:
        return self._http.post(f"/contacts/{id}/tags", {"tag": tag})

    def remove_tag(self, id: str, tag: str) -> Any:
        return self._http.delete(f"/contacts/{id}/tags/{quote(tag, safe='')}")

    def opt_in(self, id: str) -> Any:
        return self._http.post(f"/contacts/{id}/opt-in")

    def opt_out(self, id: str) -> Any:
        return self._http.post(f"/contacts/{id}/opt-out")
