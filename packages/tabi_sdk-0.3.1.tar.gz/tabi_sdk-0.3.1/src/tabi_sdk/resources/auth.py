from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Auth:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def login(self, email: str, password: str) -> Any:
        return self._http.post("/auth/login", {"email": email, "password": password})

    def register(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/auth/register", dict(data))

    def refresh(self, refresh_token: str) -> Any:
        return self._http.post("/auth/refresh", {"refreshToken": refresh_token})

    def logout(self) -> Any:
        return self._http.post("/auth/logout", None)

    def me(self) -> Any:
        return self._http.get("/auth/me")

    def invite_preview(self, token: str) -> Any:
        return self._http.get("/auth/invite-preview", {"token": token})
