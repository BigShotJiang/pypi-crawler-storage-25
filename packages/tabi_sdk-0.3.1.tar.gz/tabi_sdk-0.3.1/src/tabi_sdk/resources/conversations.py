from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Conversations:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/conversations", query)

    def get(self, id: str) -> Any:
        return self._http.get(f"/conversations/{id}")

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/conversations/{id}", dict(data))

    def resolve(self, id: str) -> Any:
        return self._http.post(f"/conversations/{id}/resolve", None)

    def reopen(self, id: str) -> Any:
        return self._http.post(f"/conversations/{id}/reopen", None)

    def mark_read(self, id: str) -> Any:
        return self._http.post(f"/conversations/{id}/read", None)
