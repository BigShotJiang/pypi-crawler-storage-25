from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Messages:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def send(self, channel_id: str, data: Mapping[str, Any]) -> Any:
        """Queue outbound WhatsApp (or channel) message — ``POST /channels/:id/send``."""
        return self._http.post(f"/channels/{channel_id}/send", dict(data))

    def get(self, id: str) -> Any:
        return self._http.get(f"/messages/{id}")

    def list_by_conversation(self, conversation_id: str, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get(f"/conversations/{conversation_id}/messages", query)

    def reply(self, conversation_id: str, data: Mapping[str, Any]) -> Any:
        return self._http.post(f"/conversations/{conversation_id}/messages", dict(data))

    def send_sticker(self, channel_id: str, data: Mapping[str, Any]) -> Any:
        return self._http.post(f"/channels/{channel_id}/messaging/sticker", dict(data))

    def send_contact(self, channel_id: str, data: Mapping[str, Any]) -> Any:
        return self._http.post(f"/channels/{channel_id}/messaging/contact", dict(data))

    def send_location(self, channel_id: str, data: Mapping[str, Any]) -> Any:
        """``latitude`` / ``longitude`` may be passed as numbers; they are stringified."""
        payload = dict(data)
        if "latitude" in payload:
            payload["latitude"] = str(payload["latitude"])
        if "longitude" in payload:
            payload["longitude"] = str(payload["longitude"])
        return self._http.post(f"/channels/{channel_id}/messaging/location", payload)

    def send_poll(self, channel_id: str, data: Mapping[str, Any]) -> Any:
        return self._http.post(f"/channels/{channel_id}/messaging/poll", dict(data))

    def react(self, channel_id: str, message_id: str, data: Mapping[str, Any]) -> Any:
        return self._http.post(
            f"/channels/{channel_id}/messaging/messages/{message_id}/reaction",
            dict(data),
        )

    def mark_read(self, channel_id: str, message_id: str) -> Any:
        return self._http.post(f"/channels/{channel_id}/messaging/messages/{message_id}/mark-read", None)

    def revoke(self, channel_id: str, message_id: str) -> Any:
        return self._http.post(f"/channels/{channel_id}/messaging/messages/{message_id}/revoke", None)

    def edit(self, channel_id: str, message_id: str, data: Mapping[str, Any]) -> Any:
        return self._http.post(
            f"/channels/{channel_id}/messaging/messages/{message_id}/edit",
            dict(data),
        )

    def download_media(self, channel_id: str, message_id: str) -> Any:
        return self._http.get(f"/channels/{channel_id}/messaging/messages/{message_id}/media")
