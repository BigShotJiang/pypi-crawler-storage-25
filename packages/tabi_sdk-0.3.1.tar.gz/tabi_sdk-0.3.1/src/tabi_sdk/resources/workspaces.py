from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Workspaces:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/workspaces", dict(data))

    def list(self) -> Any:
        return self._http.get("/workspaces")

    def get(self, id: str) -> Any:
        return self._http.get(f"/workspaces/{id}")

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/workspaces/{id}", dict(data))

    def list_members(self, id: str) -> Any:
        return self._http.get(f"/workspaces/{id}/members")

    def invite_member(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.post(f"/workspaces/{id}/members/invite", dict(data))
