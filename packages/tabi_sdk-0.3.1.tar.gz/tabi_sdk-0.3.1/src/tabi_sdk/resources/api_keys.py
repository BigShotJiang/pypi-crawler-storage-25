from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class ApiKeys:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/api-keys", dict(data))

    def list(self, query: Mapping[str, Any] | None = None) -> Any:
        return self._http.get("/api-keys", query)

    def revoke(self, id: str) -> Any:
        return self._http.post(f"/api-keys/{id}/revoke", None)

    def delete(self, id: str) -> Any:
        return self._http.delete(f"/api-keys/{id}")
