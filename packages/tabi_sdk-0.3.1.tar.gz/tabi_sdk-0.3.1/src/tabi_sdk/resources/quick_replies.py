from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class QuickReplies:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self) -> Any:
        return self._http.get("/quick-replies")

    def create(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/quick-replies", dict(data))

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/quick-replies/{id}", dict(data))

    def delete(self, id: str) -> Any:
        return self._http.delete(f"/quick-replies/{id}")
