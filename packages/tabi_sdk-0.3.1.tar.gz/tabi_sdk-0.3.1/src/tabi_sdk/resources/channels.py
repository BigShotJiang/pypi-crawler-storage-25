from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Channels:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/channels", dict(data))

    def list(self) -> Any:
        return self._http.get("/channels")

    def get(self, id: str) -> Any:
        return self._http.get(f"/channels/{id}")

    def connect(self, id: str, data: Mapping[str, Any] | None = None) -> Any:
        return self._http.post(f"/channels/{id}/connect", dict(data) if data is not None else None)

    def disconnect(self, id: str) -> Any:
        return self._http.post(f"/channels/{id}/disconnect", None)

    def status(self, id: str) -> Any:
        return self._http.get(f"/channels/{id}/status")

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/channels/{id}", dict(data))

    def reconnect(self, id: str) -> Any:
        return self._http.post(f"/channels/{id}/reconnect", None)

    def delete(self, id: str) -> Any:
        return self._http.delete(f"/channels/{id}")

    def send_otp(self, id: str, data: Mapping[str, Any]) -> Any:
        """``POST /channels/:id/otp/send`` — server-side OTP generation, Redis-backed verify queue."""
        return self._http.post(f"/channels/{id}/otp/send", dict(data))

    def verify_otp(self, id: str, data: Mapping[str, Any]) -> Any:
        """``POST /channels/:id/otp/verify`` — verify submitted code (constant-time on server)."""
        return self._http.post(f"/channels/{id}/otp/verify", dict(data))
