from __future__ import annotations

from typing import Any, Mapping

from tabi_sdk.http import HttpClient


class Integrations:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list_providers(self) -> Any:
        return self._http.get("/integrations/providers")

    def create(self, data: Mapping[str, Any]) -> Any:
        return self._http.post("/integrations", dict(data))

    def list(self) -> Any:
        return self._http.get("/integrations")

    def get(self, id: str) -> Any:
        return self._http.get(f"/integrations/{id}")

    def update(self, id: str, data: Mapping[str, Any]) -> Any:
        return self._http.patch(f"/integrations/{id}", dict(data))

    def delete(self, id: str) -> Any:
        return self._http.delete(f"/integrations/{id}")

    def test(self, id: str) -> Any:
        return self._http.post(f"/integrations/{id}/test", None)
