from __future__ import annotations

from typing import Any

from tabi_sdk.http import HttpClient


class AutomationTemplates:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self) -> Any:
        return self._http.get("/automation-templates")

    def get(self, id: str) -> Any:
        return self._http.get(f"/automation-templates/{id}")
