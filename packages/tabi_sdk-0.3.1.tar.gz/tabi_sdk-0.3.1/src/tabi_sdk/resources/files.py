from __future__ import annotations

from typing import Any

from tabi_sdk.http import HttpClient


class Files:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self) -> Any:
        return self._http.get("/files")

    def get(self, id: str) -> Any:
        return self._http.get(f"/files/{id}")

    def get_url(self, id: str) -> Any:
        return self._http.get(f"/files/{id}/url")

    def delete(self, id: str) -> Any:
        return self._http.delete(f"/files/{id}")
