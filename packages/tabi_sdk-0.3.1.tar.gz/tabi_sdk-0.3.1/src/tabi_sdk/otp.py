"""
OTP helpers for WhatsApp verification flows.

**Preferred on Tabi Cloud:** use :meth:`tabi_sdk.resources.channels.Channels.send_otp` and
:meth:`tabi_sdk.resources.channels.Channels.verify_otp` (server-side hash + Redis + delivery).

Use these helpers when you **build your own** flow with :meth:`tabi_sdk.resources.messages.Messages.send`
(**generation**, **phone normalization**, **message templates**); you then persist and verify codes yourself.

See **OTP over WhatsApp** in the package README.
"""

from __future__ import annotations

import re
import secrets
from typing import Final

_DEFAULT_OTP_LENGTH: Final[int] = 6
_MAX_OTP_LENGTH: Final[int] = 12


def generate_numeric_otp(length: int = _DEFAULT_OTP_LENGTH, *, secure: bool = True) -> str:
    """
    Generate a numeric OTP string, left-padded with zeros (e.g. ``\"004821\"``).

    Parameters
    ----------
    length:
        Number of digits (default ``6``). Typical range: ``4``–``8``. Max ``12``.
    secure:
        If ``True`` (default), uses :func:`secrets.randbelow` (cryptographically strong).
        If ``False``, uses ``random`` — only for non-security test doubles.

    Raises
    ------
    ValueError
        If ``length`` is out of range.
    """
    if not 4 <= length <= _MAX_OTP_LENGTH:
        raise ValueError(f"length must be between 4 and {_MAX_OTP_LENGTH}, got {length}")
    if secure:
        n = secrets.randbelow(10**length)
    else:
        import random

        n = random.randrange(10**length)
    return f"{n:0{length}d}"


def normalize_phone_digits(phone: str) -> str:
    """
    Normalize a phone string to **digits only** (no ``+``, spaces, or dashes).

    Tabi's ``to`` field expects international format **without** the leading ``+``
    (e.g. country code + national digits).

    Examples
    --------
    >>> normalize_phone_digits("+234 700 000 0000")
    '2347000000000'
    """
    raw = phone.strip()
    digits = re.sub(r"\D", "", raw)
    if not digits:
        raise ValueError("phone must contain at least one digit")
    return digits


def build_otp_message(
    *,
    code: str,
    brand_name: str = "Tabi",
    expiry_minutes: int = 10,
    include_code_in_body: bool = True,
) -> str:
    """
    Build a short, clear OTP body for WhatsApp.

    Parameters
    ----------
    code:
        The OTP digits (never log this in production).
    brand_name:
        Your product or business name shown to the user.
    expiry_minutes:
        Shown in the message; should match your server-side TTL.
    include_code_in_body:
        If ``True``, interpolates ``code`` into the text (normal case).
        If ``False``, returns a template line without the code (rare — you would append code yourself).

    Notes
    -----
    Keep messages concise; avoid URLs in OTP texts unless required by policy.
    """
    if include_code_in_body:
        return (
            f"{brand_name}: Your verification code is {code}. "
            f"It expires in {expiry_minutes} minutes. Do not share this code."
        )
    return (
        f"{brand_name}: Your verification code will arrive in a separate line. "
        f"Code expires in {expiry_minutes} minutes. Do not share this code."
    )
