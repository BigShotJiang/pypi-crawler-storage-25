from __future__ import annotations

import json
from typing import Any, Mapping
from urllib.parse import urlencode

import requests

from tabi_sdk.exceptions import TabiError


class HttpClient:
    """JSON REST client with Bearer auth (API key `tk_...` or user JWT)."""

    def __init__(self, base_url: str, api_key: str, timeout: float = 30.0) -> None:
        self._base = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout

    def request(
        self,
        method: str,
        path: str,
        body: Mapping[str, Any] | None = None,
        query: Mapping[str, Any] | None = None,
    ) -> Any:
        url = f"{self._base}{path}"
        if query:
            q = {k: v for k, v in query.items() if v is not None}
            if q:
                url = f"{url}?{urlencode(q)}"

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
        }
        if body is not None:
            headers["Content-Type"] = "application/json"

        resp = requests.request(
            method.upper(),
            url,
            headers=headers,
            data=json.dumps(body) if body is not None else None,
            timeout=self._timeout,
        )

        try:
            parsed: Any = resp.json()
        except json.JSONDecodeError:
            parsed = None

        if resp.status_code >= 400:
            msg = f"Request failed ({resp.status_code})"
            if isinstance(parsed, dict):
                m = parsed.get("message")
                if isinstance(m, str):
                    msg = m
                elif isinstance(m, list):
                    msg = ", ".join(str(x) for x in m)
            raise TabiError(msg, resp.status_code, parsed)

        if isinstance(parsed, dict) and parsed.get("success") is True and "data" in parsed:
            return parsed["data"]

        return parsed

    def get(self, path: str, query: Mapping[str, Any] | None = None) -> Any:
        return self.request("GET", path, None, query)

    def post(self, path: str, body: Mapping[str, Any] | None = None) -> Any:
        return self.request("POST", path, body)

    def patch(self, path: str, body: Mapping[str, Any] | None = None) -> Any:
        return self.request("PATCH", path, body)

    def delete(self, path: str) -> Any:
        return self.request("DELETE", path)
