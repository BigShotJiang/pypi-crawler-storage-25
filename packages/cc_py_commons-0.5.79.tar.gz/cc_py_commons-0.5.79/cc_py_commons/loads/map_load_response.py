from datetime import datetime, timezone
from cc_py_commons.loads.load_schema import LoadSchema


def _to_date_iso(value):
  # Freight-hub sent epoch-ms; booking-agent sends ISO strings. Handle both.
  # Epoch-ms is interpreted in UTC so the parsed date doesn't shift by TZ.
  if not value:
    return value
  s = str(value)
  if s.lstrip('-').isdigit():
    return datetime.fromtimestamp(int(s) / 1000, tz=timezone.utc).date().isoformat()
  return s[:10]


def _to_datetime_iso(value):
  if not value:
    return value
  s = str(value)
  if s.lstrip('-').isdigit():
    return datetime.fromtimestamp(int(s) / 1000, tz=timezone.utc).isoformat()
  return s


def execute(freight_hub_json):
  freight_hub_json_copy = freight_hub_json.copy()

  pickup_date = freight_hub_json.get('pickupDate')
  if pickup_date:
    freight_hub_json_copy['pickupDate'] = _to_date_iso(pickup_date)

  delivery_date = freight_hub_json.get('deliveryDate')
  if delivery_date:
    freight_hub_json_copy['deliveryDate'] = _to_date_iso(delivery_date)

  available_time = freight_hub_json.get('availableTime')
  if available_time:
    freight_hub_json_copy['availableTime'] = _to_datetime_iso(available_time)

  created = freight_hub_json.get('created')
  if created:
    freight_hub_json_copy['created'] = _to_datetime_iso(created)

  invite_in_network_carriers_after = freight_hub_json.get('inviteInNetworkCarriersAfter')
  if invite_in_network_carriers_after:
    freight_hub_json_copy['inviteInNetworkCarriersAfter'] = _to_datetime_iso(invite_in_network_carriers_after)

  invite_out_of_network_carriers_after = freight_hub_json.get('inviteOutOfNetworkCarriersAfter')
  if invite_out_of_network_carriers_after:
    freight_hub_json_copy['inviteOutOfNetworkCarriersAfter'] = _to_datetime_iso(invite_out_of_network_carriers_after)

  return LoadSchema().load(freight_hub_json_copy)
