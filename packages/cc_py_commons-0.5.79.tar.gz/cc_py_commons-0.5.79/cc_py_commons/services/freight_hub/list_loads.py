import os
import traceback

import requests

from cc_py_commons.loads.map_load_response import execute as map_load_response
from cc_py_commons.utils import json_logger

FREIGHT_HUB_URL = os.environ.get('FREIGHT_HUB_URL')
FREIGHT_HUB_TOKEN = os.environ.get("FREIGHT_HUB_TOKEN")


def execute(parameters, account_id=None):
    """
    Returns a list of Load objects (possibly empty).
    Loads are retrieved from freight-hub using the specified attributes.
    View freight-hub LoadListCommand and LoadPredicates for valid filters.
    """
    url = f"{FREIGHT_HUB_URL}/freight"
    token = f"Bearer {FREIGHT_HUB_TOKEN}"
    headers = {
        "Authorization": token
    }
    json_logger.debug(account_id, 'Requesting load list from freight-hub', url=url, parameters=parameters)
    response = requests.get(url, params=parameters, headers=headers)
    loads = []

    if response.status_code == 200:
        json_data = response.json()

        if not json_data.get('content'):
            return []

        for load_data in json_data['content']:
            try:
                load = map_load_response(load_data)
                loads.append(load)
            except Exception as e:
                load_id = load_data.get('id') if isinstance(load_data, dict) else None
                parameter_keys = sorted(parameters.keys()) if isinstance(parameters, dict) else None
                json_logger.warning(account_id, 'Unable to map freight-hub response to load',
                                    parameter_keys=parameter_keys, load_id=load_id,
                                    error=str(e), stack_trace=traceback.format_exc())

    return loads
