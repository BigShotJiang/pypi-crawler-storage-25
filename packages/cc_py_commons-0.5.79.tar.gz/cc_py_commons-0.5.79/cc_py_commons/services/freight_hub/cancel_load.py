import os

import requests

from cc_py_commons.utils import json_logger

FREIGHT_HUB_URL = os.environ.get('FREIGHT_HUB_URL')
FREIGHT_HUB_TOKEN = os.environ.get("FREIGHT_HUB_TOKEN")


def execute(load_id, account_id=None):
    url = f"{FREIGHT_HUB_URL}/freight/{load_id}/cancel"
    token = f"Bearer {FREIGHT_HUB_TOKEN}"
    headers = {
        "Authorization": token
    }
    json_logger.debug(account_id, 'Canceling load on freight-hub', url=url, load_id=load_id)
    return requests.get(url, headers=headers)
