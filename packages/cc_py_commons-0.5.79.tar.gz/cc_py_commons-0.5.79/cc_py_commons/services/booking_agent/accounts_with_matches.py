import os

import requests

from cc_py_commons.utils.logger_v2 import logger

BOOKING_AGENT_URL = os.environ.get('BOOKING_AGENT_URL')
BOOKING_AGENT_TOKEN = os.environ.get('BOOKING_AGENT_TOKEN')


def execute(filter_dict=None, filter_list=None):
	"""
	Call booking-agent POST /v2/freight/accounts-with-matches to find which
	account ids have loads matching the given filter, without pulling the
	actual load rows back.

	Used by the load-refresh background job orchestrator (see
	docs/PLAN_AUTOMATIC_LOAD_RERUN.md in the workspace root) to identify
	the subset of TMS-integrated accounts that have stale active loads
	in the current cycle.

	Args:
		filter_dict (dict | None): Map of simple key=value filters. Same shape
			as the booking-agent /v2/freight `filter` field. May contain
			`status.id`, `customerIds`, `startDate`, `endDate`.
		filter_list (list[dict] | None): List of advanced filter dicts with
			fields `field`, `value`, `operator`, `condition` (and optionally
			`startValue`/`endValue` for `between` operator). Same shape as the
			booking-agent /v2/freight `filterList` field. Typically includes
			`accountIds` (multi-account), `lastModified` (staleness), and
			`pickupDate` (future-only).

	Returns:
		list[int]: Distinct account ids that match the filter. Returns an
			empty list on non-200 response, transport error, or no matches.
	"""
	url = f"{BOOKING_AGENT_URL}/v2/freight/accounts-with-matches"
	headers = {
		'Authorization': f"Bearer {BOOKING_AGENT_TOKEN}"
	}
	payload = {
		'filter': filter_dict or {},
		'filterList': filter_list or []
	}

	logger.debug(f"Requesting accounts-with-matches from booking-agent: {url}, payload={payload}")

	try:
		response = requests.post(url, json=payload, headers=headers)
	except Exception as e:
		logger.error(f"accounts_with_matches request failed: {e}")
		return []

	if response.status_code != 200:
		logger.warning(
			f"accounts_with_matches returned non-200: status={response.status_code}, body={response.text}"
		)
		return []

	try:
		data = response.json()
	except ValueError as e:
		logger.error(f"accounts_with_matches failed to parse response body as JSON: {e}")
		return []

	if data is None:
		return []
	return data
