import requests

from cc_py_commons.config.env import app_config
from cc_py_commons.loads.map_load_response import execute as map_load_response
from cc_py_commons.services.booking_agent.constants import BOOKING_AGENT_URL, BOOKING_AGENT_TOKEN
from cc_py_commons.services.freight_hub import get_load as freight_hub_get_load
from cc_py_commons.utils import json_logger


def execute(load_id, account_id=None):
    if not app_config.USE_BOOKING_AGENT_FOR_LOADS:
        return freight_hub_get_load.execute(load_id, account_id)

    if not load_id:
        json_logger.error(account_id, 'Invalid load_id provided', load_id=load_id)
        return None

    url = f"{BOOKING_AGENT_URL}/freight/{load_id}"
    token = f"Bearer {BOOKING_AGENT_TOKEN}"
    headers = {
        "Authorization": token
    }
    load = None
    try:
        response = requests.get(url, headers=headers, timeout=30)
        if response.status_code == 200:
            load = map_load_response(response.json())
        else:
            json_logger.warning(account_id, 'Failed to get load from booking-agent',
                                response_status_code=response.status_code, response_text=response.text)
    except Exception as e:
        json_logger.error(account_id, 'Error calling booking-agent API', error=str(e))

    return load
