import requests

from cc_py_commons.config.env import app_config
from cc_py_commons.services.booking_agent.constants import BOOKING_AGENT_URL, BOOKING_AGENT_TOKEN
from cc_py_commons.services.freight_hub import cancel_load as freight_hub_cancel_load
from cc_py_commons.utils import json_logger


def execute(load_id, account_id=None):
    if not app_config.USE_BOOKING_AGENT_FOR_LOADS:
        return freight_hub_cancel_load.execute(load_id, account_id)

    url = f"{BOOKING_AGENT_URL}/freight/{load_id}/cancel"
    token = f"Bearer {BOOKING_AGENT_TOKEN}"
    headers = {
        "Authorization": token
    }
    json_logger.debug(account_id, 'Canceling load on booking-agent', url=url, load_id=load_id)
    return requests.get(url, headers=headers)
