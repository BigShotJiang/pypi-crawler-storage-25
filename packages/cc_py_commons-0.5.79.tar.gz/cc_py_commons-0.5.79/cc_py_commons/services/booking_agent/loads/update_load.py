import requests

from cc_py_commons.config.env import app_config
from cc_py_commons.services.booking_agent.constants import BOOKING_AGENT_URL, BOOKING_AGENT_TOKEN
from cc_py_commons.services.freight_hub import update_load as freight_hub_update_load
from cc_py_commons.utils import json_logger


def execute(load_dict, account_id=None):
    if not app_config.USE_BOOKING_AGENT_FOR_LOADS:
        return freight_hub_update_load.execute(load_dict, account_id)

    load_id = load_dict.get('id')
    url = f"{BOOKING_AGENT_URL}/freight/{load_id}"
    token = f"Bearer {BOOKING_AGENT_TOKEN}"
    headers = {
        "Authorization": token
    }
    try:
        json_logger.debug(account_id, 'Updating load on booking-agent', url=url, load_id=load_id)
        response = requests.post(url, json=load_dict, headers=headers, timeout=30)
        if response.status_code not in (200, 201, 204):
            json_logger.warning(account_id, 'booking-agent update returned non-success status',
                                response_status_code=response.status_code,
                                response_text=response.text,
                                load_id=load_id,
                                load_dict=load_dict)
        return response
    except Exception as e:
        json_logger.error(account_id, 'Error calling booking-agent API for update',
                          error=str(e), load_id=load_id)
        return None
