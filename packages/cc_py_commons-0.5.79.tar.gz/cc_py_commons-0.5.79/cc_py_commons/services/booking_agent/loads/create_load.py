import requests

from cc_py_commons.config.env import app_config
from cc_py_commons.services.booking_agent.constants import BOOKING_AGENT_URL, BOOKING_AGENT_TOKEN
from cc_py_commons.services.freight_hub import post_freight_hub_load as freight_hub_create_load
from cc_py_commons.utils import json_logger


def execute(load, account_id=None):
    if not app_config.USE_BOOKING_AGENT_FOR_LOADS:
        return freight_hub_create_load.execute(load)

    url = f"{BOOKING_AGENT_URL}/freight"
    token = f"Bearer {BOOKING_AGENT_TOKEN}"
    headers = {
        "Authorization": token
    }
    json_logger.debug(account_id, 'Posting load to booking-agent', url=url)
    return requests.post(url, json=load, headers=headers)
