import os

import requests

from cc_py_commons.utils.logger_v2 import logger

BOOKING_AGENT_URL = os.environ.get('BOOKING_AGENT_URL')
BOOKING_AGENT_TOKEN = os.environ.get('BOOKING_AGENT_TOKEN')


def execute(filter_dict=None, filter_list=None, sort_list=None, page=0, size=100):
	"""
	Call booking-agent POST /v2/freight to list loads matching the given filter.

	Used by the load-refresh background job (see docs/PLAN_AUTOMATIC_LOAD_RERUN.md
	in the workspace root) to fetch a single account's stale active loads in
	bounded batches.

	Args:
		filter_dict (dict | None): Map of simple key=value filters. Same shape
			as the booking-agent /v2/freight `filter` field. May contain
			`status.id`, `customerIds`, `startDate`, `endDate`.
		filter_list (list[dict] | None): List of advanced filter dicts with
			fields `field`, `value`, `operator`, `condition` (and optionally
			`startValue`/`endValue` for `between` operator). Same shape as the
			booking-agent /v2/freight `filterList` field.
		sort_list (list[dict] | None): List of sort dicts with fields `field`
			and `direction`.
		page (int): Page number, 0-indexed. Defaults to 0.
		size (int): Page size. Defaults to 100. Booking-agent caps at 500.

	Returns:
		dict | None: Raw page response from booking-agent containing `content`,
			`totalElements`, `last`, `numberOfElements`, etc. Returns None on
			any non-200 response or transport error.
	"""
	url = f"{BOOKING_AGENT_URL}/v2/freight?page={page}&size={size}"
	headers = {
		'Authorization': f"Bearer {BOOKING_AGENT_TOKEN}"
	}
	payload = {
		'filter': filter_dict or {},
		'filterList': filter_list or [],
		'sortList': sort_list or []
	}

	logger.debug(f"Requesting loads from booking-agent: {url}, payload={payload}")

	try:
		response = requests.post(url, json=payload, headers=headers)
	except Exception as e:
		logger.error(f"list_loads_v2 request failed: {e}")
		return None

	if response.status_code != 200:
		logger.warning(
			f"list_loads_v2 returned non-200: status={response.status_code}, body={response.text}"
		)
		return None

	try:
		return response.json()
	except ValueError as e:
		logger.error(f"list_loads_v2 failed to parse response body as JSON: {e}")
		return None
