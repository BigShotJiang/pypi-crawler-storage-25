import json
import traceback

from cc_py_commons.sns.sns_service import SnsService
from cc_py_commons.utils import json_logger


class BookingAssistantFlowNotification:

	def __init__(self, app_config):
		self._app_config = app_config

	def send(self, user_id, load, params, capacity_search_equipments, request_id,
				 auto_invite_details=None, equipment_names=None):
		'''
	  Sends an event to the Booking Assistant Flow SQS queue specified in the config.
	  Returns the messageId of the enqueued message for later retrieval.

	  Step 2 of the BA-flow SNS payload cutover (plan task #29) emits BOTH
	  the legacy `capacitySearchEquipments` (list of {id,name} dicts) and the
	  new canonical `equipmentNames` (list of strings) so the booking-agent
	  consumer can switch off the legacy field after the soak window.

	  If `equipment_names` is not supplied, it is derived from
	  `capacity_search_equipments` by taking each item's `name` field.
	  '''
		c4_account_id = load.get('accountId')
		subject = self._app_config.BOOKING_ASSISTANT_SNS_SUBJECT
		if equipment_names is None:
			resolved_equipment_names = self._derive_equipment_names(capacity_search_equipments)
		elif isinstance(equipment_names, str):
			# Defensive: treat a stray single-string caller as a one-element list so
			# the SNS payload contract (List<String>) stays stable.
			resolved_equipment_names = [equipment_names]
		else:
			resolved_equipment_names = [name for name in equipment_names if name]
		event = {
			'userId': user_id,
			'loadDTO': load,
			'payload': params,
			'capacitySearchEquipments': capacity_search_equipments,
			'equipmentNames': resolved_equipment_names,
			'requestId': request_id,
			'subject': f'{subject}',
			'className': f'{self._app_config.BOOKING_ASSISTANT_SNS_CLASS_NAME}',
			'autoInviteDetails': auto_invite_details
		}
		json_logger.debug(c4_account_id, 'Sending booking assistant flow SNS notification',
						  topic=self._app_config.BOOKING_ASSISTANT_SNS_TOPIC_ARN, event=event)
		try:
			sns_service = SnsService()
			return sns_service.send(self._app_config.BOOKING_ASSISTANT_SNS_TOPIC_ARN, subject, json.dumps(event))
		except Exception as e:
			json_logger.warning(c4_account_id, 'Failed to send BookingAssistantFlowNotification',
								error=str(e), stacktrace=traceback.format_exc())

	@staticmethod
	def _derive_equipment_names(capacity_search_equipments):
		if not capacity_search_equipments:
			return []
		names = []
		for equipment in capacity_search_equipments:
			if not equipment:
				continue
			name = equipment.get('name') if isinstance(equipment, dict) else getattr(equipment, 'name', None)
			if name:
				names.append(name)
		return names
