import unittest
from unittest import mock


class TestBookingAgentLoadsDispatch(unittest.TestCase):
    """
    Verifies USE_BOOKING_AGENT_FOR_LOADS flag routes correctly:
    true  -> booking-agent path (no call into services.freight_hub.*)
    false -> delegates to services.freight_hub.*
    """

    def test_get_load_uses_booking_agent_when_flag_true(self):
        from cc_py_commons.services.booking_agent.loads import get_load

        with mock.patch('cc_py_commons.services.booking_agent.loads.get_load.app_config') as mock_cfg, \
             mock.patch('cc_py_commons.services.booking_agent.loads.get_load.requests') as mock_requests, \
             mock.patch('cc_py_commons.services.booking_agent.loads.get_load.freight_hub_get_load') as mock_fh:
            mock_cfg.USE_BOOKING_AGENT_FOR_LOADS = True
            mock_response = mock.Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {}
            mock_requests.get.return_value = mock_response

            get_load.execute('load-123', account_id=1)

            mock_requests.get.assert_called_once()
            mock_fh.execute.assert_not_called()

    def test_get_load_delegates_to_freight_hub_when_flag_false(self):
        from cc_py_commons.services.booking_agent.loads import get_load

        with mock.patch('cc_py_commons.services.booking_agent.loads.get_load.app_config') as mock_cfg, \
             mock.patch('cc_py_commons.services.booking_agent.loads.get_load.requests') as mock_requests, \
             mock.patch('cc_py_commons.services.booking_agent.loads.get_load.freight_hub_get_load') as mock_fh:
            mock_cfg.USE_BOOKING_AGENT_FOR_LOADS = False

            get_load.execute('load-123', account_id=1)

            mock_fh.execute.assert_called_once_with('load-123', 1)
            mock_requests.get.assert_not_called()

    def test_list_loads_delegates_to_freight_hub_when_flag_false(self):
        from cc_py_commons.services.booking_agent.loads import list_loads

        with mock.patch('cc_py_commons.services.booking_agent.loads.list_loads.app_config') as mock_cfg, \
             mock.patch('cc_py_commons.services.booking_agent.loads.list_loads.requests') as mock_requests, \
             mock.patch('cc_py_commons.services.booking_agent.loads.list_loads.freight_hub_list_loads') as mock_fh:
            mock_cfg.USE_BOOKING_AGENT_FOR_LOADS = False

            list_loads.execute({'accountId': 1})

            mock_fh.execute.assert_called_once_with({'accountId': 1}, None)
            mock_requests.get.assert_not_called()

    def test_create_load_uses_booking_agent_when_flag_true(self):
        from cc_py_commons.services.booking_agent.loads import create_load

        with mock.patch('cc_py_commons.services.booking_agent.loads.create_load.app_config') as mock_cfg, \
             mock.patch('cc_py_commons.services.booking_agent.loads.create_load.requests') as mock_requests, \
             mock.patch('cc_py_commons.services.booking_agent.loads.create_load.freight_hub_create_load') as mock_fh:
            mock_cfg.USE_BOOKING_AGENT_FOR_LOADS = True

            create_load.execute({'referenceNumber': 'R1'})

            mock_requests.post.assert_called_once()
            mock_fh.execute.assert_not_called()

    def test_update_load_delegates_to_freight_hub_when_flag_false(self):
        from cc_py_commons.services.booking_agent.loads import update_load

        with mock.patch('cc_py_commons.services.booking_agent.loads.update_load.app_config') as mock_cfg, \
             mock.patch('cc_py_commons.services.booking_agent.loads.update_load.requests') as mock_requests, \
             mock.patch('cc_py_commons.services.booking_agent.loads.update_load.freight_hub_update_load') as mock_fh:
            mock_cfg.USE_BOOKING_AGENT_FOR_LOADS = False

            update_load.execute({'id': 'load-1'}, account_id=1)

            mock_fh.execute.assert_called_once_with({'id': 'load-1'}, 1)
            mock_requests.post.assert_not_called()

    def test_cancel_load_uses_booking_agent_when_flag_true(self):
        from cc_py_commons.services.booking_agent.loads import cancel_load

        with mock.patch('cc_py_commons.services.booking_agent.loads.cancel_load.app_config') as mock_cfg, \
             mock.patch('cc_py_commons.services.booking_agent.loads.cancel_load.requests') as mock_requests, \
             mock.patch('cc_py_commons.services.booking_agent.loads.cancel_load.freight_hub_cancel_load') as mock_fh:
            mock_cfg.USE_BOOKING_AGENT_FOR_LOADS = True

            cancel_load.execute('load-1')

            mock_requests.get.assert_called_once()
            mock_fh.execute.assert_not_called()


if __name__ == '__main__':
    unittest.main()
