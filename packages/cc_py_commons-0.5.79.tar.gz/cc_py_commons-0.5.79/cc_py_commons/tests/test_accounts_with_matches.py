import unittest
from unittest import mock

from cc_py_commons.services.booking_agent import accounts_with_matches


class TestAccountsWithMatches(unittest.TestCase):

	@mock.patch('cc_py_commons.services.booking_agent.accounts_with_matches.requests')
	def test_execute_returns_account_ids_on_success(self, mock_requests):
		expected_ids = [101, 105, 207]
		mock_response = mock.Mock()
		mock_response.status_code = 200
		mock_response.json.return_value = expected_ids
		mock_requests.post.return_value = mock_response

		filter_dict = {'status.id': 'active-uuid'}
		filter_list = [
			{'field': 'accountIds', 'value': '101,102,103', 'operator': '=', 'condition': 'and'},
			{'field': 'lastModified', 'value': '2026-04-08 12:30:00', 'operator': '<=', 'condition': 'and'}
		]
		result = accounts_with_matches.execute(filter_dict=filter_dict, filter_list=filter_list)

		self.assertEqual(result, expected_ids)
		mock_requests.post.assert_called_once()
		call_args = mock_requests.post.call_args
		self.assertIn('/v2/freight/accounts-with-matches', call_args[0][0])
		self.assertEqual(call_args[1]['json']['filter'], filter_dict)
		self.assertEqual(call_args[1]['json']['filterList'], filter_list)

	@mock.patch('cc_py_commons.services.booking_agent.accounts_with_matches.requests')
	def test_execute_returns_empty_list_on_non_200(self, mock_requests):
		mock_response = mock.Mock()
		mock_response.status_code = 500
		mock_response.text = 'server error'
		mock_requests.post.return_value = mock_response

		result = accounts_with_matches.execute()

		self.assertEqual(result, [])

	@mock.patch('cc_py_commons.services.booking_agent.accounts_with_matches.requests')
	def test_execute_returns_empty_list_on_request_exception(self, mock_requests):
		mock_requests.post.side_effect = Exception('connection refused')

		result = accounts_with_matches.execute()

		self.assertEqual(result, [])

	@mock.patch('cc_py_commons.services.booking_agent.accounts_with_matches.requests')
	def test_execute_returns_empty_list_when_response_body_is_null(self, mock_requests):
		mock_response = mock.Mock()
		mock_response.status_code = 200
		mock_response.json.return_value = None
		mock_requests.post.return_value = mock_response

		result = accounts_with_matches.execute()

		self.assertEqual(result, [])

	@mock.patch('cc_py_commons.services.booking_agent.accounts_with_matches.requests')
	def test_execute_with_no_filters_sends_empty_payload(self, mock_requests):
		mock_response = mock.Mock()
		mock_response.status_code = 200
		mock_response.json.return_value = []
		mock_requests.post.return_value = mock_response

		accounts_with_matches.execute()

		call_args = mock_requests.post.call_args
		self.assertEqual(call_args[1]['json']['filter'], {})
		self.assertEqual(call_args[1]['json']['filterList'], [])

	@mock.patch('cc_py_commons.services.booking_agent.accounts_with_matches.requests')
	def test_execute_returns_empty_list_on_malformed_json(self, mock_requests):
		# 200 status but the body isn't valid JSON. Should not raise.
		mock_response = mock.Mock()
		mock_response.status_code = 200
		mock_response.json.side_effect = ValueError('Expecting value: line 1 column 1 (char 0)')
		mock_requests.post.return_value = mock_response

		result = accounts_with_matches.execute()

		self.assertEqual(result, [])
