import unittest
from unittest import mock

from cc_py_commons.services.booking_agent import list_loads_v2


class TestListLoadsV2(unittest.TestCase):

	@mock.patch('cc_py_commons.services.booking_agent.list_loads_v2.requests')
	def test_execute_returns_page_on_success(self, mock_requests):
		expected_page = {
			'content': [{'id': 'load-1'}, {'id': 'load-2'}],
			'totalElements': 2,
			'last': True,
			'numberOfElements': 2
		}
		mock_response = mock.Mock()
		mock_response.status_code = 200
		mock_response.json.return_value = expected_page
		mock_requests.post.return_value = mock_response

		filter_dict = {'status.id': 'active-uuid'}
		filter_list = [{
			'field': 'accountIds',
			'value': '101',
			'operator': '=',
			'condition': 'and'
		}]
		result = list_loads_v2.execute(
			filter_dict=filter_dict,
			filter_list=filter_list,
			page=0,
			size=200
		)

		self.assertEqual(result, expected_page)
		mock_requests.post.assert_called_once()
		call_args = mock_requests.post.call_args
		self.assertIn('page=0', call_args[0][0])
		self.assertIn('size=200', call_args[0][0])
		self.assertEqual(call_args[1]['json']['filter'], filter_dict)
		self.assertEqual(call_args[1]['json']['filterList'], filter_list)

	@mock.patch('cc_py_commons.services.booking_agent.list_loads_v2.requests')
	def test_execute_returns_none_on_non_200(self, mock_requests):
		mock_response = mock.Mock()
		mock_response.status_code = 500
		mock_response.text = 'server error'
		mock_requests.post.return_value = mock_response

		result = list_loads_v2.execute(filter_dict={}, filter_list=[])

		self.assertIsNone(result)

	@mock.patch('cc_py_commons.services.booking_agent.list_loads_v2.requests')
	def test_execute_returns_none_on_request_exception(self, mock_requests):
		mock_requests.post.side_effect = Exception('connection refused')

		result = list_loads_v2.execute(filter_dict={}, filter_list=[])

		self.assertIsNone(result)

	@mock.patch('cc_py_commons.services.booking_agent.list_loads_v2.requests')
	def test_execute_with_no_filters_sends_empty_payload(self, mock_requests):
		mock_response = mock.Mock()
		mock_response.status_code = 200
		mock_response.json.return_value = {'content': [], 'totalElements': 0, 'last': True}
		mock_requests.post.return_value = mock_response

		list_loads_v2.execute()

		call_args = mock_requests.post.call_args
		self.assertEqual(call_args[1]['json']['filter'], {})
		self.assertEqual(call_args[1]['json']['filterList'], [])
		self.assertEqual(call_args[1]['json']['sortList'], [])

	@mock.patch('cc_py_commons.services.booking_agent.list_loads_v2.requests')
	def test_execute_returns_none_on_malformed_json(self, mock_requests):
		# 200 status but the body isn't valid JSON. Should not raise.
		mock_response = mock.Mock()
		mock_response.status_code = 200
		mock_response.json.side_effect = ValueError('Expecting value: line 1 column 1 (char 0)')
		mock_requests.post.return_value = mock_response

		result = list_loads_v2.execute()

		self.assertIsNone(result)
