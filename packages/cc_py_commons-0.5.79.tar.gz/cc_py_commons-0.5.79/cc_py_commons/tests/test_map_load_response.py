import unittest
from datetime import datetime, timezone


class TestMapLoadResponse(unittest.TestCase):
    """
    map_load_response.execute must accept both formats:
    - legacy freight-hub: epoch-ms (int or numeric string)
    - booking-agent: ISO-8601 datetime string
    """

    def _base_payload(self):
        return {
            "id": "01f52ab3-e081-432a-aa6f-9aa7272643f9",
            "referenceNumber": "test-ref",
            "statusId": "9bcd4613-831e-4cb4-a76f-9166ce559fa6",
            "sourceId": "03caea36-98c9-46f6-aa9c-a102576bc185",
            "customerId": 504,
            "contact": None,
            "origin": {"city": "San Francisco", "state": "CA", "postcode": "94102"},
            "destination": {"city": "San Diego", "state": "CA", "postcode": "92101"},
            "equipment": [{"id": "b738a0d4-a03d-4302-8f57-2aa1f3eb2f9b", "name": "Van"}],
            "equipmentDescription": "Van",
        }

    def test_iso_string_date_fields(self):
        from cc_py_commons.loads.map_load_response import execute
        payload = self._base_payload()
        payload.update({
            "pickupDate": "2026-04-25T00:00:00.000+00:00",
            "deliveryDate": "2026-04-26T00:00:00.000+00:00",
            "availableTime": "2022-08-22T22:26:43.713+00:00",
            "created": "2026-04-24T10:14:32.984+00:00",
        })

        load = execute(payload)

        self.assertEqual(load.pickup_date.isoformat(), "2026-04-25")
        self.assertEqual(load.delivery_date.isoformat(), "2026-04-26")
        self.assertEqual(load.available_time.year, 2022)
        self.assertEqual(load.created.year, 2026)

    def test_epoch_ms_date_fields_still_work(self):
        from cc_py_commons.loads.map_load_response import execute
        payload = self._base_payload()
        # Epoch-ms timestamps are interpreted in UTC so the parsed date
        # is stable across developer machines.
        payload.update({
            "pickupDate": 1777075200000,     # 2026-04-25 00:00:00 UTC
            "deliveryDate": 1777161600000,   # 2026-04-26 00:00:00 UTC
            "availableTime": 1661207203713,  # 2022-08-22T22:26:43.713 UTC
            "created": 1777025672984,        # 2026-04-24T10:14:32.984 UTC
        })

        load = execute(payload)

        self.assertEqual(load.pickup_date.isoformat(), "2026-04-25")
        self.assertEqual(load.delivery_date.isoformat(), "2026-04-26")
        self.assertEqual(load.available_time.year, 2022)
        self.assertEqual(load.created.year, 2026)


if __name__ == '__main__':
    unittest.main()
