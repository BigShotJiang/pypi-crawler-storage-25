import json
import unittest
from unittest import mock

from cc_py_commons.sns.booking_assistant_flow_notification import BookingAssistantFlowNotification


class _AppConfig:
	BOOKING_ASSISTANT_SNS_SUBJECT = 'booking-assistant-flow'
	BOOKING_ASSISTANT_SNS_CLASS_NAME = 'com.cargochief.sdk.bookingagent.sns.BookingAssistantFlowNotification'
	BOOKING_ASSISTANT_SNS_TOPIC_ARN = 'arn:aws:sns:us-west-1:000:booking-assistant-flow-test'


class TestBookingAssistantFlowNotification(unittest.TestCase):
	"""
	Step 2 of the BA-flow SNS payload cutover (plan task #29). Producers must
	emit BOTH the legacy `capacitySearchEquipments` and the new canonical
	`equipmentNames` so the booking-agent consumer can switch off the legacy
	field after the soak window.
	"""

	def setUp(self):
		self.notification = BookingAssistantFlowNotification(_AppConfig())
		self.load = {'accountId': 1234, 'id': 'load-uuid'}
		self.equipments = [
			{'id': 'equipment-uuid-1', 'name': 'VAN'},
			{'id': 'equipment-uuid-2', 'name': 'REEFER'},
		]

	@mock.patch('cc_py_commons.sns.booking_assistant_flow_notification.SnsService')
	def test_send_emits_both_legacy_set_and_canonical_equipment_names(self, sns_service_mock):
		instance = sns_service_mock.return_value
		instance.send.return_value = 'message-id-123'

		self.notification.send(
			user_id=42,
			load=self.load,
			params={},
			capacity_search_equipments=self.equipments,
			request_id='req-1'
		)

		instance.send.assert_called_once()
		args, _ = instance.send.call_args
		published = json.loads(args[2])

		self.assertEqual(published['capacitySearchEquipments'], self.equipments,
			'Legacy capacitySearchEquipments must continue to be populated during the soak window')
		self.assertEqual(published['equipmentNames'], ['VAN', 'REEFER'],
			'equipmentNames must be derived from capacity_search_equipments by name')

	@mock.patch('cc_py_commons.sns.booking_assistant_flow_notification.SnsService')
	def test_send_uses_explicit_equipment_names_when_supplied(self, sns_service_mock):
		instance = sns_service_mock.return_value
		instance.send.return_value = 'message-id-456'

		self.notification.send(
			user_id=42,
			load=self.load,
			params={},
			capacity_search_equipments=self.equipments,
			request_id='req-1',
			equipment_names=['HOTSHOT']
		)

		args, _ = instance.send.call_args
		published = json.loads(args[2])

		self.assertEqual(published['capacitySearchEquipments'], self.equipments)
		self.assertEqual(published['equipmentNames'], ['HOTSHOT'],
			'Explicit equipment_names must override the derived list')

	@mock.patch('cc_py_commons.sns.booking_assistant_flow_notification.SnsService')
	def test_send_emits_empty_equipment_names_when_no_equipments(self, sns_service_mock):
		instance = sns_service_mock.return_value
		instance.send.return_value = 'message-id-789'

		self.notification.send(
			user_id=42,
			load=self.load,
			params={},
			capacity_search_equipments=None,
			request_id='req-1'
		)

		args, _ = instance.send.call_args
		published = json.loads(args[2])

		self.assertIsNone(published['capacitySearchEquipments'])
		self.assertEqual(published['equipmentNames'], [])

	@mock.patch('cc_py_commons.sns.booking_assistant_flow_notification.SnsService')
	def test_send_emits_empty_equipment_names_when_equipment_list_is_empty(self, sns_service_mock):
		instance = sns_service_mock.return_value
		instance.send.return_value = 'message-id-790'

		self.notification.send(
			user_id=42,
			load=self.load,
			params={},
			capacity_search_equipments=[],
			request_id='req-1'
		)

		args, _ = instance.send.call_args
		published = json.loads(args[2])

		self.assertEqual(published['capacitySearchEquipments'], [])
		self.assertEqual(published['equipmentNames'], [])

	@mock.patch('cc_py_commons.sns.booking_assistant_flow_notification.SnsService')
	def test_send_normalizes_string_equipment_names_to_list(self, sns_service_mock):
		instance = sns_service_mock.return_value
		instance.send.return_value = 'message-id-791'

		self.notification.send(
			user_id=42,
			load=self.load,
			params={},
			capacity_search_equipments=self.equipments,
			request_id='req-1',
			equipment_names='HOTSHOT'
		)

		args, _ = instance.send.call_args
		published = json.loads(args[2])

		self.assertEqual(published['equipmentNames'], ['HOTSHOT'],
			'A bare string should be normalized to a one-element list to keep the SNS contract stable')
