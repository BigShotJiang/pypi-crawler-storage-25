# S3PyArrowBackend

API reference for `S3PyArrowBackend` — drop-in alternative to `S3Backend`
that uses PyArrow's C++ S3 filesystem for higher throughput on large files.

::: remote_store.backends.S3PyArrowBackend
    options:
      show_bases: false

## See also

- [S3-PyArrow Backend Guide](../../backends/s3-pyarrow.md) — usage patterns, configuration, and examples
- [S3-PyArrow Backend example](../../examples/s3-pyarrow-backend.md) — S3-PyArrow backend in action
