# Changelog

All notable changes follow [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and the project version follows [PEP 440](https://peps.python.org/pep-0440/)
(SemVer-compatible, with `post` releases reserved for correctness-only patches).

## [Unreleased]

## [0.1.0a0] — 2026-05-23 (alpha pre-release)

> **Solo-maintained OSS. Best-effort response. No production SLA.**
>
> The `0.1.0` entry will be promoted from this `0.1.0a0` block at Phase 6 when
> the public release tag is cut (PEP 440 alpha → final). Until then `pip
> install hybridlens` resolves to this alpha; consumers should pin
> `hybridlens==0.1.0a0` for reproducibility.

### Alpha scope (runs vs raises)

Six of eight public APIs run end-to-end: `LayerLayout` / both adapters'
`discover_layout` / `ComponentSAEBundle` (save+load round-trip) /
`render_hybrid_explorer` / `hub_push_bundle` / `hub_load_bundle` /
`hooks.resolve_site`. The five remaining bindings raise
`NotImplementedError` in v0.1.0a0 — they require a live torch +
transformers + recurrentlens stack and land in v0.1.0 (final) after the
Phase 5 release-verify venv exercises them: `load_hybrid_model`,
`train_component_sae`, `attribute(method='ablation')`, the scale ≠ 0
branch of `steer_component`, and `hooks.install_capture_hook`.

Initial alpha release. Eight public APIs covering Jamba and Zamba2 hybrid
LLMs: cross-component SAEs, zero-ablation attribution, activation steering,
and Hub bundle I/O. Sibling of `recurrentlens`; reuses its `BaseSAE`,
`HookManager`, `ActivationCache`, and `hub.io` primitives.

### Added
- `load_hybrid_model(model_id, device, dtype, family)` — entrypoint that
  tags attention / SSM / MoE components via family-specific adapters.
- `HybridLensModel` — wrapper that **composes** `recurrentlens` primitives
  (`BaseSAE`, `HookManager`, `ActivationCache`) — does *not* subclass —
  and exposes per-component access via `LayerLayout` introspection.
- `LayerLayout` — pydantic schema describing per-layer component map.
- `train_component_sae(model, component, layer, ...)` — train an SAE on the
  hidden stream of one component (attn / ssm / mlp).
- `ComponentSAEBundle` — save/load collection of per-component SAEs as a
  single safetensors-backed directory.
- `attribute(model, input_ids, target_metric, method='ablation')` —
  zero-ablation attribution to a scalar metric.
- `steer_component(model, bundle, component, feature_id, scale)` —
  context-managed feature-level activation steering.
- `hub_push_bundle` / `hub_load_bundle` — HF Hub I/O for bundles.

### Known limitations
- Adapters only for Jamba and Zamba2. Nemotron-Nano and Samba arrive in v0.1.1.
- Attribution is zero-ablation only; integrated-gradients is v0.1.1.
- MoE expert routing trace and Sankey cross-component flow viz are v0.2.
- Default training dataset is Pile-uncopyrighted; users supplying other
  corpora are responsible for license compliance.
- No pretrained bundles in v0.1.0; first Hub releases land with v0.1.1.
