# Security policy

> **Solo-maintained OSS. Best-effort response. No production SLA.**

`hybridlens` is alpha software. Treat all loaded model artifacts, SAE
bundles, and Hub assets as **untrusted input** until you have verified
their provenance.

## Reporting a vulnerability

Open a GitHub Security Advisory at
https://github.com/hinanohart/hybridlens/security/advisories/new
(preferred) or open a regular Issue tagged `security` if private disclosure
is not required. Response is best-effort.

## Known upstream advisories (verified 2026-05-23)

- `transformers` 4.57.6 carries PYSEC-2025-217 and CVE-2026-1839; the
  fix lands in transformers 5.0.0rc3 and later. hybridlens' pin is
  `>=4.46,<6.0`, which permits the fix once a 5.x release is available
  on PyPI. Until then, run `pip install -U "transformers>=5.0.0rc3"`
  alongside hybridlens to receive the patched version.

## Known supply-chain surface

- `safetensors` files loaded by `ComponentSAEBundle.load` are validated
  against their metadata; mismatched `d_sae` or unknown variants are
  refused. Inherited from `recurrentlens`'s `BaseSAE.load`.
- `hub_load_bundle` downloads bundles from HF Hub. Pin a specific revision
  in production; the `revision=` argument is forwarded to
  `huggingface_hub.snapshot_download`.
- The `viz` HTML output passes user-controlled fields through `html.escape`.
- Pickle is **not** used anywhere in v0.1.0 load paths.
