"""Adapter / SAE / attribution backend protocols.

Protocols, not ABCs: third-party packages can implement them structurally
without subclassing. Runtime-checkable so `isinstance(x, HybridAdapter)`
works for duck-typed implementations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from hybridlens.core.layout import LayerLayout
    from hybridlens.core.types import Component, Family


@runtime_checkable
class HybridAdapter(Protocol):
    """Family-specific adapter that maps a loaded HF model to a LayerLayout."""

    family: Family

    def discover_layout(self, model: object) -> LayerLayout:
        """Inspect the model and return its per-layer component map."""
        ...

    def component_hidden_size(self, model: object, layer: int, component: Component) -> int:
        """Hidden-state width at the read site for the given component."""
        ...
