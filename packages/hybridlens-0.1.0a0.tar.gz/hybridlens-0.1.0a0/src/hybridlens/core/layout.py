"""Per-layer component layout (pydantic schema)."""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator

from hybridlens.core.types import Component, Family, HookSite


class LayerSlot(BaseModel):
    """One component slot within a hybrid layer.

    A Jamba layer with attention + MLP is two slots (attn, mlp). A Zamba2
    layer with SSM + MLP + MoE is three slots. The `site` records where in
    the layer's compute graph the hidden stream is read for SAE training.
    """

    layer: int = Field(ge=0, description="0-indexed layer position.")
    component: Component
    site: HookSite = "residual_post"
    d_model: int = Field(gt=0, description="Hidden-state width at the read site.")

    model_config = {"frozen": True}


class LayerLayout(BaseModel):
    """Layer-by-layer map of components for a single hybrid model.

    `slots` is ordered for stable iteration; uniqueness of
    `(layer, component, site)` triples is enforced at construction.
    """

    family: Family
    n_layers: int = Field(gt=0)
    slots: list[LayerSlot]

    @field_validator("slots")
    @classmethod
    def _unique_triples(cls, v: list[LayerSlot]) -> list[LayerSlot]:
        seen: set[tuple[int, str, str]] = set()
        for s in v:
            key = (s.layer, s.component, s.site)
            if key in seen:
                raise ValueError(f"duplicate slot for {key}")
            seen.add(key)
        return v

    def filter(
        self, *, component: Component | None = None, layer: int | None = None
    ) -> list[LayerSlot]:
        """Return slots matching the given component and/or layer filter."""
        out = self.slots
        if component is not None:
            out = [s for s in out if s.component == component]
        if layer is not None:
            out = [s for s in out if s.layer == layer]
        return out
