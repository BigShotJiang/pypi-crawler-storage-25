"""Shared type aliases and lightweight enums.

Pure stdlib; no torch / transformers / pydantic imports here so the module
participates in PEP 562 lazy import without paying any backend cost.
"""

from __future__ import annotations

from typing import Literal

Component = Literal["attn", "ssm", "mlp", "moe", "router"]
"""A component label within a hybrid layer.

`attn` and `ssm` are mutually exclusive per layer (one path or the other).
`mlp` is the post-mixer feed-forward. `moe` is a sparse MoE block; `router`
is the gating subnetwork tracked separately for attribution.
"""

Family = Literal["jamba", "zamba2"]
"""Supported hybrid families in v0.1.0.

`nemotron` and `samba` are reserved for v0.1.1 (validated at the adapter
registry, not in this Literal, to keep the public API additive).
"""

HookSite = Literal["residual_pre", "residual_post", "component_out"]
"""Where a hook reads the hidden stream.

- `residual_pre`: input to the layer's first sub-block (after norm).
- `residual_post`: output of the layer (sum of residual + component).
- `component_out`: raw output of a single component before residual add.
"""
