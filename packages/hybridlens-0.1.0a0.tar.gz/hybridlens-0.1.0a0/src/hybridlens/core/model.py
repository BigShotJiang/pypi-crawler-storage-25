"""HybridLensModel wrapper and `load_hybrid_model` entrypoint.

The wrapper does NOT subclass `recurrentlens.RecurrentLensModelImpl` in
v0.1.0a0: subclassing across PyPI releases would couple recurrentlens'
private layout to ours. We compose instead and re-expose the parts of the
recurrentlens public API (HookManager / ActivationCache) that hybrid users
need. This preserves the sibling relationship without locking either
project's internals.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from hybridlens.core.layout import LayerLayout
from hybridlens.core.types import Family

if TYPE_CHECKING:
    pass


class HybridLensModel:
    """A loaded hybrid LLM with its discovered LayerLayout.

    Lifecycle (Phase 3 impl):
      1. `load_hybrid_model(...)` resolves model + tokenizer via transformers.
      2. The family adapter inspects the model and emits a `LayerLayout`.
      3. The HybridLensModel is constructed and is the object every other
         hybridlens API (sae / attribution / features / hub) consumes.
    """

    def __init__(self, model: Any, tokenizer: Any, layout: LayerLayout) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.layout = layout

    @property
    def family(self) -> Family:
        return self.layout.family

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"HybridLensModel(family={self.family!r}, n_layers={self.layout.n_layers})"


def load_hybrid_model(
    model_id: str,
    *,
    family: Family,
    device: str = "cpu",
    dtype: str = "float32",
    revision: str | None = None,
    trust_remote_code: bool = False,
) -> HybridLensModel:
    """Load a hybrid model from HuggingFace and tag its components.

    Parameters
    ----------
    model_id : str
        HF model id (e.g. ``"ai21labs/Jamba-tiny-dev"``).
    family : {"jamba", "zamba2"}
        Adapter family to use for layout discovery.
    device, dtype : str
        Passed through to ``transformers.AutoModel.from_pretrained``.
    revision : str or None
        Pinned HF revision (recommended for reproducibility).
    trust_remote_code : bool
        Forwarded to ``transformers``. Zamba2 historically required True;
        consult the HF model card before flipping.
    """
    raise NotImplementedError(
        "load_hybrid_model: v0.1.0 final — requires torch + transformers; "
        "Phase 5 release-verify venv activates this."
    )
