"""HTML visualization of cross-component feature behavior."""

from hybridlens.viz.hybrid_explorer import render_hybrid_explorer

__all__ = ["render_hybrid_explorer"]
