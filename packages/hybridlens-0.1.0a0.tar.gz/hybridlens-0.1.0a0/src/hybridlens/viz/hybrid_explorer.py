"""HTML viz for a per-feature, per-component activation table.

Mirrors recurrentlens' `viz/feature_explorer` HTML-escape discipline: any
user-controlled field is passed through ``html.escape`` before string
interpolation. No JavaScript is emitted; the page is a static HTML table.

Sankey cross-component flow is intentionally **not** v0.1.0 work — it
ships in v0.2 alongside MoE expert tracing.
"""

from __future__ import annotations

import html
from typing import Any


def render_hybrid_explorer(
    *,
    bundle: Any,
    feature_id: int,
    context: str,
    model_id: str,
) -> str:
    """Return a self-contained HTML string for one feature.

    All caller-controlled fields (`context`, `model_id`, entry component
    names) are passed through `html.escape`. No JavaScript is emitted —
    the page is a static table the consumer can `open(path).write(...)`
    and load in any browser.
    """
    if feature_id < 0:
        raise ValueError("feature_id must be non-negative")
    safe_context = html.escape(context)
    safe_model = html.escape(model_id)
    rows: list[str] = []
    if bundle is not None and hasattr(bundle, "entries"):
        for e in bundle.entries:
            comp = html.escape(str(e.component))
            variant = html.escape(str(e.variant))
            rows.append(f"<tr><td>{comp}</td><td>{e.layer}</td><td>{variant}</td></tr>")
    body_rows = "\n".join(rows) if rows else "<tr><td colspan='3'>(empty bundle)</td></tr>"
    return (
        "<!DOCTYPE html>\n"
        "<html><head>"
        f"<title>hybridlens feature {feature_id} — {safe_model}</title>"
        "</head><body>"
        f"<h1>Feature {feature_id} — {safe_model}</h1>"
        f"<p><strong>Context:</strong> {safe_context}</p>"
        "<table border='1'><thead>"
        "<tr><th>component</th><th>layer</th><th>variant</th></tr>"
        f"</thead><tbody>{body_rows}</tbody></table>"
        "</body></html>"
    )
