"""Resolve `(layer, component, site)` to a concrete PyTorch module path.

This is the bridge between hybridlens' family-neutral LayerLayout and the
torch.nn.Module tree of the actual HF model. The Phase 3 impl walks
``model.named_modules()`` once at adapter-discover time and caches the
result per ``HybridLensModel``.
"""

from __future__ import annotations

from typing import Any

from hybridlens.core.layout import LayerLayout
from hybridlens.core.types import Component, HookSite

_FAMILY_PATHS: dict[tuple[str, str], str] = {
    # AI21 Jamba layer naming (model.layers.<L>.{self_attn, mamba, feed_forward})
    ("jamba", "attn"): "model.layers.{L}.self_attn",
    ("jamba", "ssm"): "model.layers.{L}.mamba",
    ("jamba", "mlp"): "model.layers.{L}.feed_forward",
    ("jamba", "moe"): "model.layers.{L}.feed_forward",
    ("jamba", "router"): "model.layers.{L}.feed_forward.router",
    # Zyphra Zamba2 layer naming (model.layers.<L>.{self_attn, mamba, mlp})
    ("zamba2", "attn"): "model.layers.{L}.self_attn",
    ("zamba2", "ssm"): "model.layers.{L}.mamba",
    ("zamba2", "mlp"): "model.layers.{L}.mlp",
}


def resolve_site(
    layout: LayerLayout,
    *,
    layer: int,
    component: Component,
    site: HookSite = "residual_post",
) -> str:
    """Return the dotted module path for the requested hook site.

    The path is family + component specific; the `site` argument is
    reserved for future per-site disambiguation (residual_pre /
    component_out require an extra dotted prefix that v0.1.0 does not
    introspect — every site currently resolves to the component module
    itself and the caller is expected to use a `forward_hook` whose
    `module` argument carries the residual context).

    Raises
    ------
    KeyError
        If the layout has no slot for the requested triple, or the
        family / component combination is not supported.
    """
    del site  # reserved for future variants
    matches = layout.filter(component=component, layer=layer)
    if not matches:
        raise KeyError(
            f"no slot for layer={layer} component={component!r} in layout (family={layout.family})"
        )
    key = (layout.family, component)
    if key not in _FAMILY_PATHS:
        raise KeyError(
            f"no module path template for family={layout.family!r} component={component!r}"
        )
    return _FAMILY_PATHS[key].format(L=layer)


def install_capture_hook(model: Any, module_path: str, buffer: list) -> Any:
    """Install a forward hook that appends activations to ``buffer``.

    Returns the hook handle; caller is responsible for `.remove()` (the
    `steer_component` contextmanager handles this automatically).
    """
    raise NotImplementedError(
        "install_capture_hook: v0.1.0 final — torch.nn.Module.register_forward_hook "
        "wrapper; Phase 5 release-verify venv activates this."
    )
