"""MoE expert-routing tap (Phase 1 surface freeze, v0.2 implementation).

We freeze the API here so that v0.1.0 consumers can write code against
the eventual MoE tap without import-time breakage. The actual capture of
router logits, expert indices, and load-balance loss is v0.2 work.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class RoutingTap:
    """Per-layer capture of MoE expert routing decisions.

    Empty in v0.1.0a0. Phase v0.2 fills:
      - `router_logits[t, e]` — softmax inputs for token t over expert e
      - `expert_indices[t, k]` — top-k routed experts for token t
      - `load_balance` — auxiliary loss term observed during the forward
    """

    layer: int
    expert_indices: list[list[int]] = field(default_factory=list)
    router_logits: list[list[float]] = field(default_factory=list)
    load_balance: float | None = None

    def __post_init__(self) -> None:
        if self.layer < 0:
            raise ValueError("layer must be non-negative")
