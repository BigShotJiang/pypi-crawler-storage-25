"""Jamba (AI21) hybrid adapter.

Jamba layers alternate attention and Mamba blocks with shared MLP + MoE
slots. The HF config field `attn_layer_offset` / `attn_layer_period` tells
us which layers are attention vs SSM; MoE blocks are gated by
`expert_layer_period` and `expert_layer_offset`.
"""

from __future__ import annotations

from typing import Any

from hybridlens.core.layout import LayerLayout, LayerSlot
from hybridlens.core.types import Component


def _has_attn(layer: int, period: int, offset: int) -> bool:
    if period <= 0:
        return False
    return (layer - offset) % period == 0 and layer >= offset


def _has_moe(layer: int, period: int, offset: int) -> bool:
    if period <= 1:
        return False
    return (layer - offset) % period == 0 and layer >= offset


class JambaAdapter:
    """Adapter for AI21's Jamba family (Jamba-tiny-dev / Jamba 1.5 Mini / Large)."""

    family = "jamba"

    def discover_layout(self, model: Any) -> LayerLayout:
        """Build a LayerLayout from the model's HF config.

        Reads ``num_hidden_layers``, ``hidden_size``, ``attn_layer_period``,
        ``attn_layer_offset``, ``expert_layer_period``,
        ``expert_layer_offset``. Layers that satisfy the attention
        condition get an ``attn`` slot; the rest get ``ssm``. Every layer
        gets an ``mlp`` slot. Layers matching the expert condition get an
        additional ``moe`` slot for downstream attribution.
        """
        cfg = model.config
        n_layers = int(cfg.num_hidden_layers)
        d_model = int(cfg.hidden_size)
        attn_period = int(getattr(cfg, "attn_layer_period", 8))
        attn_offset = int(getattr(cfg, "attn_layer_offset", 4))
        expert_period = int(getattr(cfg, "expert_layer_period", 0))
        expert_offset = int(getattr(cfg, "expert_layer_offset", 0))
        slots: list[LayerSlot] = []
        for layer in range(n_layers):
            comp_mixer: Component = "attn" if _has_attn(layer, attn_period, attn_offset) else "ssm"
            slots.append(LayerSlot(layer=layer, component=comp_mixer, d_model=d_model))
            slots.append(LayerSlot(layer=layer, component="mlp", d_model=d_model))
            if _has_moe(layer, expert_period, expert_offset):
                slots.append(LayerSlot(layer=layer, component="moe", d_model=d_model))
        return LayerLayout(family="jamba", n_layers=n_layers, slots=slots)

    def component_hidden_size(self, model: Any, layer: int, component: Component) -> int:
        """Hidden size for every Jamba component is `model.config.hidden_size`."""
        del layer, component  # uniform width in Jamba v1.x
        return int(model.config.hidden_size)
