"""Zamba2 (Zyphra) hybrid adapter.

Zamba2 interleaves Mamba2 blocks with shared-attention blocks. The HF
config uses `hybrid_layer_ids` to list which layers carry the shared
attention sub-block in addition to the default SSM. MLP is on every layer.
"""

from __future__ import annotations

from typing import Any

from hybridlens.core.layout import LayerLayout, LayerSlot
from hybridlens.core.types import Component


class Zamba2Adapter:
    """Adapter for Zyphra's Zamba2 family (Zamba2-1.2B / 2.7B / 7B)."""

    family = "zamba2"

    def discover_layout(self, model: Any) -> LayerLayout:
        """Build a LayerLayout from the model's HF config.

        Every layer carries an SSM (Mamba2) block. Layers whose index
        appears in ``model.config.hybrid_layer_ids`` *additionally* carry
        a shared-attention block. Every layer carries an MLP block.
        """
        cfg = model.config
        n_layers = int(cfg.num_hidden_layers)
        d_model = int(cfg.hidden_size)
        hybrid_ids = set(int(x) for x in getattr(cfg, "hybrid_layer_ids", ()))
        slots: list[LayerSlot] = []
        for layer in range(n_layers):
            slots.append(LayerSlot(layer=layer, component="ssm", d_model=d_model))
            if layer in hybrid_ids:
                slots.append(LayerSlot(layer=layer, component="attn", d_model=d_model))
            slots.append(LayerSlot(layer=layer, component="mlp", d_model=d_model))
        return LayerLayout(family="zamba2", n_layers=n_layers, slots=slots)

    def component_hidden_size(self, model: Any, layer: int, component: Component) -> int:
        """Hidden size for Zamba2 components is `model.config.hidden_size`."""
        del layer, component
        return int(model.config.hidden_size)
