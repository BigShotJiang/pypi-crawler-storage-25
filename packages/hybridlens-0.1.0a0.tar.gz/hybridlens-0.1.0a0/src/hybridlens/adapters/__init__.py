"""Family-specific adapters that derive a LayerLayout from a HF model.

v0.1.0a0 ships Jamba and Zamba2. Nemotron-Nano 2 and Samba are reserved
for v0.1.1 and are intentionally *not* exported from the public surface.
"""

from hybridlens.adapters.jamba import JambaAdapter
from hybridlens.adapters.zamba2 import Zamba2Adapter

__all__ = ["JambaAdapter", "Zamba2Adapter", "get_adapter"]


def get_adapter(family: str):
    """Return the adapter instance for a family string."""
    if family == "jamba":
        return JambaAdapter()
    if family == "zamba2":
        return Zamba2Adapter()
    raise ValueError(
        f"unknown family {family!r}; v0.1.0a0 supports 'jamba' and 'zamba2'. "
        "Nemotron-Nano and Samba are scheduled for v0.1.1."
    )
