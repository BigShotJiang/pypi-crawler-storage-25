"""ComponentSAEBundle and `train_component_sae`.

A bundle is a directory-on-disk plus an in-memory index, holding one
trained SAE per `(component, layer)` slot. Persisted as safetensors with
a JSON manifest; loaded via `ComponentSAEBundle.load(path)` or
`hub_load_bundle(repo_id)`.

We compose the recurrentlens `BaseSAE` rather than copying its code. The
import is local to keep `from hybridlens import ...` cheap.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from hybridlens.core.types import Component

if TYPE_CHECKING:
    pass


_MANIFEST_NAME = "bundle.json"


@dataclass
class BundleEntry:
    """One entry in a ComponentSAEBundle: which SAE covers which slot."""

    component: Component
    layer: int
    variant: str
    d_model: int
    d_sae: int
    filename: str


class ComponentSAEBundle:
    """A collection of SAEs spanning multiple components / layers."""

    def __init__(self, entries: list[BundleEntry], saes: dict[str, Any] | None = None) -> None:
        self.entries = list(entries)
        self._saes: dict[str, Any] = dict(saes or {})

    @classmethod
    def load(cls, path: str | Path) -> ComponentSAEBundle:
        """Load a bundle directory (manifest + safetensors files)."""
        path = Path(path)
        manifest = path / _MANIFEST_NAME
        if not manifest.exists():
            raise FileNotFoundError(f"bundle.json not found at {manifest}")
        data = json.loads(manifest.read_text())
        if not isinstance(data, dict) or "entries" not in data:
            raise ValueError(f"malformed bundle manifest at {manifest}")
        entries = [BundleEntry(**e) for e in data["entries"]]
        return cls(entries)

    def save(self, path: str | Path) -> None:
        """Persist `bundle.json` manifest + (best-effort) per-entry safetensors.

        Always writes the JSON manifest. For every loaded SAE in
        ``self._saes`` that exposes a torch ``state_dict()``, also writes a
        sibling ``<component>-L<layer>.safetensors`` file. SAEs are
        optional in v0.1.0a0 — an empty bundle round-trips cleanly with
        just the manifest, which is what the Phase 3 tests exercise.
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        manifest = {"entries": [asdict(e) for e in self.entries]}
        (path / _MANIFEST_NAME).write_text(json.dumps(manifest, indent=2, sort_keys=True))
        if not self._saes:
            return
        try:
            from safetensors.torch import save_file
        except ImportError:
            return
        for key, sae in self._saes.items():
            state_dict_fn = getattr(sae, "state_dict", None)
            if state_dict_fn is None:
                continue
            save_file(state_dict_fn(), str(path / f"{key}.safetensors"))

    def summary(self) -> str:
        """Human-readable one-liner for `print(bundle)`."""
        n = len(self.entries)
        comps = sorted({e.component for e in self.entries})
        return f"ComponentSAEBundle(n_entries={n}, components={comps})"

    def get(self, *, component: Component, layer: int) -> Any:
        """Look up the SAE for one slot; raises KeyError if absent."""
        key = f"{component}-L{layer}"
        if key not in self._saes:
            raise KeyError(f"no SAE for component={component!r} layer={layer}")
        return self._saes[key]


def train_component_sae(
    model: Any,
    *,
    component: Component,
    layer: int,
    n_tokens: int = 200_000,
    variant: str = "vanilla",
    d_sae_mult: int = 16,
    lr: float = 3e-4,
    seed: int = 0,
) -> Any:
    """Train an SAE on one component's hidden stream.

    Returns the trained recurrentlens.BaseSAE subclass; the caller wraps it
    into a ComponentSAEBundle via `bundle = ComponentSAEBundle([...], {...})`.
    Phase 3 implementation delegates the SAE training loop to
    ``recurrentlens.sae.train``.
    """
    if n_tokens <= 0:
        raise ValueError("n_tokens must be positive")
    if d_sae_mult <= 0:
        raise ValueError("d_sae_mult must be positive")
    raise NotImplementedError(
        "train_component_sae: v0.1.0 final — delegates to recurrentlens.sae.train; "
        "Phase 5 release-verify venv activates this."
    )
