"""HuggingFace Hub upload / download for ComponentSAEBundle.

We delegate to ``huggingface_hub.snapshot_download`` and
``HfApi.upload_folder``; both are import-late so a bare ``import
hybridlens`` does not touch the network or pull HF deps.

> Anonymous HF reads are rate-limited to 100 requests / hour; set
> ``HF_TOKEN`` for steady-state workloads. README mirrors this warning.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hybridlens.sae.per_component import ComponentSAEBundle


def hub_push_bundle(
    bundle: ComponentSAEBundle,
    *,
    repo_id: str,
    local_dir: str | Path | None = None,
    private: bool = True,
    commit_message: str = "upload hybridlens bundle",
) -> str:
    """Push a bundle to a HF model repo, creating it if absent.

    Returns the resolved HF URL. Phase 3 implementation:
      1. Save the bundle to ``local_dir`` (tempdir if None) via
         ``bundle.save(local_dir)``.
      2. ``HfApi().create_repo(repo_id, exist_ok=True, private=private)``.
      3. ``HfApi().upload_folder(folder_path=local_dir, repo_id=repo_id,
         commit_message=commit_message)``.
    """
    if not repo_id or "/" not in repo_id:
        raise ValueError(f"repo_id must be 'owner/name' form; got {repo_id!r}")
    from huggingface_hub import HfApi

    api = HfApi()
    api.create_repo(repo_id=repo_id, repo_type="model", exist_ok=True, private=private)
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        target = Path(local_dir) if local_dir is not None else Path(tmp)
        target.mkdir(parents=True, exist_ok=True)
        bundle.save(target)
        api.upload_folder(
            folder_path=str(target),
            repo_id=repo_id,
            repo_type="model",
            commit_message=commit_message,
        )
    return f"https://huggingface.co/{repo_id}"


def hub_load_bundle(
    repo_id: str,
    *,
    revision: str | None = None,
    cache_dir: str | Path | None = None,
    token: str | None = None,
) -> ComponentSAEBundle:
    """Download a bundle from HF Hub and return a `ComponentSAEBundle`.

    Pin ``revision=`` in production; anonymous reads hit the 100 req/h
    HF Hub rate limit, so set ``HF_TOKEN`` (or pass ``token=``) for
    sustained use.
    """
    if not repo_id or "/" not in repo_id:
        raise ValueError(f"repo_id must be 'owner/name' form; got {repo_id!r}")
    from huggingface_hub import snapshot_download

    from hybridlens.sae.per_component import ComponentSAEBundle as _Bundle

    local = snapshot_download(
        repo_id=repo_id,
        repo_type="model",
        revision=revision,
        cache_dir=str(cache_dir) if cache_dir is not None else None,
        token=token,
    )
    return _Bundle.load(local)
