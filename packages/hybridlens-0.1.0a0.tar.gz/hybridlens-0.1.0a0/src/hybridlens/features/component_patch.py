"""Feature-level activation steering on one component."""

from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

from hybridlens.core.types import Component

if TYPE_CHECKING:
    from hybridlens.sae.per_component import ComponentSAEBundle


@contextmanager
def steer_component(
    model: Any,
    bundle: ComponentSAEBundle,
    *,
    component: Component,
    feature_id: int,
    scale: float,
    layer: int | None = None,
):
    """Context manager that adds ``scale * decoder[feature_id]`` to the
    component's hidden stream while the block is active.

    If ``layer`` is None, the steering is applied at every layer in the
    bundle that hosts the requested component.

    The hook is removed on context exit even if the body raises.
    """
    if scale == 0.0:
        # nothing to do
        yield
        return

    if feature_id < 0:
        raise ValueError("feature_id must be non-negative")

    raise NotImplementedError(
        "steer_component (scale != 0 branch): v0.1.0 final — installs a forward "
        "hook that adds scale * W_dec[feature_id]; Phase 5 release-verify venv "
        "activates this."
    )
