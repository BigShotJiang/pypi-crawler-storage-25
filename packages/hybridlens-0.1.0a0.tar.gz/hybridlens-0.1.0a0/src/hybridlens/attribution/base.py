"""Shared attribution types."""

from __future__ import annotations

from dataclasses import dataclass

from hybridlens.core.types import Component


@dataclass(frozen=True)
class AttributionResult:
    """Result of one attribution call.

    `scores[i]` is the attribution of the i-th `(component, layer)` slot to
    the scalar target metric. `delta_metric` is the change in the metric
    when all slots are intervened simultaneously, useful as a soundness
    check on the per-slot decomposition.
    """

    method: str
    target_metric: str
    slots: tuple[tuple[Component, int], ...]
    scores: tuple[float, ...]
    delta_metric: float

    def __post_init__(self) -> None:
        if len(self.slots) != len(self.scores):
            raise ValueError(
                f"slots ({len(self.slots)}) and scores ({len(self.scores)}) length mismatch"
            )
