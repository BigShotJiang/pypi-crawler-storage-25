"""Attribution backends (ablation in v0.1.0; integrated-gradients in v0.1.1)."""

from hybridlens.attribution.ablation import AttributionResult, attribute

__all__ = ["AttributionResult", "attribute"]
