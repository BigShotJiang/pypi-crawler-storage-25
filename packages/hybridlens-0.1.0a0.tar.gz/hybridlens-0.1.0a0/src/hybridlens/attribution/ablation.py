"""Zero-ablation attribution.

For each `(component, layer)` slot in scope, the slot's contribution to
the residual stream is set to zero and the target metric is re-evaluated.
The attribution score is the metric delta versus the un-ablated forward.
Single-slot ablation (per-slot scores) and joint ablation
(`delta_metric` field on AttributionResult) are both reported.

Integrated-gradients (captum) is the v0.1.1 alternative `method='ig'`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from hybridlens.attribution.base import AttributionResult

if TYPE_CHECKING:
    from hybridlens.core.layout import LayerSlot

Method = Literal["ablation"]


def attribute(
    model: Any,
    *,
    input_ids: Any,
    target_metric: str = "logit_diff",
    method: Method = "ablation",
    slots: list[LayerSlot] | None = None,
) -> AttributionResult:
    """Attribute `target_metric` to per-component activations.

    Parameters
    ----------
    model : HybridLensModel
        The wrapped hybrid LLM.
    input_ids : tensor-like
        Token ids of shape ``(batch, seq)``.
    target_metric : str
        Name of a metric registered on the model. v0.1.0 default
        ``"logit_diff"`` requires a paired-prompt setup; future built-ins
        will land in v0.2.
    method : {"ablation"}
        Only ``"ablation"`` in v0.1.0. ``"ig"`` is reserved for v0.1.1.
    slots : list[LayerSlot] or None
        Restrict attribution to a subset of the model's layout; ``None``
        attributes to every slot.
    """
    if method != "ablation":
        raise NotImplementedError(
            f"method={method!r} is not supported in v0.1.0a0; "
            "captum-IG lands in v0.1.1 (see ROADMAP.md)."
        )
    raise NotImplementedError(
        "attribute(method='ablation'): v0.1.0 final — requires torch forward hooks; "
        "Phase 5 release-verify venv activates this."
    )
