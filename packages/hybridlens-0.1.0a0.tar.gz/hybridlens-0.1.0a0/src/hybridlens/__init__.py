"""hybridlens — mechanistic interpretability for hybrid Mamba-Attention LLMs.

The eight public APIs frozen in v0.1.0 are re-exported here. Stubs are filled
in across Phases 1-3 of the build; importing the package never executes a
heavy backend (torch is imported lazily by the implementations).
"""

from hybridlens._version import __version__

__all__ = [
    "__version__",
    "load_hybrid_model",
    "HybridLensModel",
    "LayerLayout",
    "train_component_sae",
    "ComponentSAEBundle",
    "attribute",
    "steer_component",
    "hub_push_bundle",
    "hub_load_bundle",
]


def __getattr__(name: str):  # PEP 562 lazy re-export
    if name in {"load_hybrid_model", "HybridLensModel"}:
        from hybridlens.core.model import HybridLensModel, load_hybrid_model

        return {"load_hybrid_model": load_hybrid_model, "HybridLensModel": HybridLensModel}[name]
    if name == "LayerLayout":
        from hybridlens.core.layout import LayerLayout

        return LayerLayout
    if name in {"train_component_sae", "ComponentSAEBundle"}:
        from hybridlens.sae.per_component import ComponentSAEBundle, train_component_sae

        return {
            "train_component_sae": train_component_sae,
            "ComponentSAEBundle": ComponentSAEBundle,
        }[name]
    if name == "attribute":
        from hybridlens.attribution.ablation import attribute

        return attribute
    if name == "steer_component":
        from hybridlens.features.component_patch import steer_component

        return steer_component
    if name in {"hub_push_bundle", "hub_load_bundle"}:
        from hybridlens.hub.io import hub_load_bundle, hub_push_bundle

        return {"hub_push_bundle": hub_push_bundle, "hub_load_bundle": hub_load_bundle}[name]
    raise AttributeError(f"module 'hybridlens' has no attribute {name!r}")
