# hybridlens — Roadmap

> Order is **intent**, not commitment. Solo-maintained; releases ship when
> tests, docs, and a working notebook all land together.

## v0.1.0a0 (alpha pre-release, 2026-05) — six APIs runnable, signatures frozen

Frozen contract → see `docs/ARCHITECTURE.md`. Six APIs run end-to-end;
five raise `NotImplementedError` and are filled in v0.1.0 (final) after
Phase 5 release-verify.

## v0.1.0 (final, 2026-05) — close the 5 torch-dependent stubs

Promote `[0.1.0a0]` → `[0.1.0]` once these are exercised in a Phase 5
release-verify venv that installs `torch`, `transformers`, and
`recurrentlens`:

- `core.model.load_hybrid_model` — wrap `transformers.AutoModel.from_pretrained`
  + `AutoTokenizer.from_pretrained`, call the family adapter for layout.
- `sae.per_component.train_component_sae` — delegate to
  `recurrentlens.sae.train` with the layer's hidden stream as the
  training corpus.
- `attribution.ablation.attribute` — install capture hooks per slot via
  `hooks.install_capture_hook`, run clean + ablated forwards, compute
  per-slot metric delta.
- `features.component_patch.steer_component` (scale ≠ 0 branch) —
  install a forward hook that adds `scale * W_dec[feature_id]` to the
  component's output.
- `hooks.sites.install_capture_hook` — `torch.nn.Module.register_forward_hook`
  wrapper that appends activations to a caller buffer.

Phase 5 unskips the matching integration xfails
(`tests/integration/test_pipeline_{jamba,zamba2}.py`,
`test_e2e_misc.py`).

## v0.1.1 — gap closures

- `captum`-backed integrated-gradients attribution (`method='ig'`).
- Nemotron-Nano 2 adapter (NVIDIA).
- Samba adapter (Microsoft) — gated on stable HF release of the reference checkpoint.
- First pretrained `ComponentSAEBundle` assets on HF Hub: at minimum
  Zamba2-2.7B layers 4 / 12 / 24 (attn + ssm + mlp slots each).
- HF Space (gradio ZeroGPU) for `render_hybrid_explorer` over a bundled
  pretrained Zamba2 SAE.

## v0.2 — observability inside MoE

- `RoutingTap` populated: per-token router logits, top-k expert indices,
  load-balance loss exposed via the standard attribution interface.
- `viz.cross_component_flow` Sankey diagram (attn → ssm → mlp → moe edge
  weights from one attribution call).
- `bench.component_eval` — paired-prompt benchmarks across families to
  detect adapter-induced attribution drift.

## v0.3 — temporal interpretability

- RLVR training-cycle SAE observation (the H2 HybridScope-RL track).
- Per-rollout `(component, layer, step) → feature_id` activation logs.
- Optional integration with `open-r1` training runs.

## Out of scope (any version)

- A full HF Transformers fork / monkey-patch. We adapt to upstream, not
  the other way around.
- Hosted inference. Bundles are user-deployed.
- Anything that requires loading pickled checkpoints.
