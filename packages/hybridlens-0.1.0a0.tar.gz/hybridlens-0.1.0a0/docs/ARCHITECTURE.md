# hybridlens v0.1.0 — Architecture

> Frozen at Phase 1 (2026-05-23). Signatures here are the contract for
> Phases 2 (test scaffold) and 3 (impl). Changes require a CHANGELOG entry.

## Why hybrid-specific tooling

The 2026 open-weight LLM landscape is **no longer pure-transformer**: AI21's
Jamba 1.5, Zyphra's Zamba2, NVIDIA's Nemotron Nano 2, and Microsoft's Samba
all ship Mamba + Attention + (optional MoE) inside a single forward pass.
The established mech-interp stack was written against decoder-only
transformers:

- `SAELens` and `OpenMOSS` assume one component family per layer; an
  SSM-side residual stream is silently mis-attributed when fed through
  their adapters.
- `circuit-tracer` and Anthropic's attribution-graph tooling target
  attention-only causal traces and have no schema for an SSM hidden state
  or a router decision.
- `recurrentlens` (the sibling project) covers the inverse case — pure-SSM
  models like Mamba and Mamba-2 — but stops short of mixed architectures.

`hybridlens` fills that gap with per-component SAEs trained on the
**actual** hidden stream each layer carries, plus attribution that respects
the component boundary (zero-ablation in v0.1.0; integrated-gradients in
v0.1.1). This is the "A2 HybridScope" candidate from the 2026-05-23 R14
exploration — picked because Jamba/Zamba2 are the most likely vendor
families to receive open releases through 2026 and because the sibling
relationship to recurrentlens halves the moat work for both projects.

## Public API surface (8 symbols)

```python
def load_hybrid_model(
    model_id: str,
    *,
    family: Literal["jamba", "zamba2"],
    device: str = "cpu",
    dtype: str = "float32",
    revision: str | None = None,
    trust_remote_code: bool = False,
) -> HybridLensModel
```

```python
class HybridLensModel:
    model: Any            # transformers PreTrainedModel
    tokenizer: Any        # transformers PreTrainedTokenizer
    layout: LayerLayout
    family: Family        # property
```

```python
class LayerLayout(BaseModel):
    family: Family
    n_layers: int
    slots: list[LayerSlot]
    def filter(*, component=None, layer=None) -> list[LayerSlot]
```

```python
def train_component_sae(
    model: HybridLensModel,
    *,
    component: Component,
    layer: int,
    n_tokens: int = 200_000,
    variant: str = "vanilla",
    d_sae_mult: int = 16,
    lr: float = 3e-4,
    seed: int = 0,
) -> BaseSAE  # recurrentlens.sae.BaseSAE
```

```python
class ComponentSAEBundle:
    entries: list[BundleEntry]
    @classmethod
    def load(cls, path) -> ComponentSAEBundle
    def save(self, path) -> None
    def summary(self) -> str
    def get(*, component, layer) -> BaseSAE
```

```python
def attribute(
    model: HybridLensModel,
    *,
    input_ids,
    target_metric: str = "logit_diff",
    method: Literal["ablation"] = "ablation",
    slots: list[LayerSlot] | None = None,
) -> AttributionResult
```

```python
@contextmanager
def steer_component(
    model: HybridLensModel,
    bundle: ComponentSAEBundle,
    *,
    component: Component,
    feature_id: int,
    scale: float,
    layer: int | None = None,
)
```

```python
def hub_push_bundle(
    bundle: ComponentSAEBundle, *, repo_id, local_dir=None, private=True,
    commit_message="upload hybridlens bundle",
) -> str

def hub_load_bundle(
    repo_id, *, revision=None, cache_dir=None, token=None,
) -> ComponentSAEBundle
```

## Module map

```
src/hybridlens/
├── _version.py
├── __init__.py            # PEP 562 lazy re-export of 8 APIs
├── core/
│   ├── types.py           # Component, Family, HookSite (pure stdlib)
│   ├── layout.py          # LayerLayout, LayerSlot (pydantic)
│   ├── protocols.py       # HybridAdapter Protocol
│   └── model.py           # HybridLensModel + load_hybrid_model
├── adapters/
│   ├── jamba.py           # JambaAdapter
│   └── zamba2.py          # Zamba2Adapter
├── hooks/
│   ├── sites.py           # resolve_site, install_capture_hook
│   └── routing.py         # RoutingTap (v0.2 fills)
├── sae/
│   └── per_component.py   # ComponentSAEBundle, train_component_sae
├── attribution/
│   ├── base.py            # AttributionResult dataclass
│   └── ablation.py        # attribute(method='ablation')
├── features/
│   └── component_patch.py # steer_component contextmanager
├── viz/
│   └── hybrid_explorer.py # render_hybrid_explorer (HTML)
└── hub/
    └── io.py              # hub_push_bundle / hub_load_bundle
```

## Composition vs subclassing decision

`HybridLensModel` **composes** rather than subclasses
`recurrentlens.RecurrentLensModelImpl`. Subclassing across PyPI releases
would couple recurrentlens' private layout to ours: a refactor in
recurrentlens 0.1.x → 0.2.x could break hybridlens at import time. By
composing and re-exporting only the public `recurrentlens.hooks` /
`recurrentlens.sae.BaseSAE` surface, the sibling boundary stays clean.

Composition is *not* zero dependency — hybridlens pins
`recurrentlens>=0.1.0.post1,<0.2` as a hard dep in `pyproject.toml`.
"Composes, does not subclass" refers to the **call-shape coupling**:
hybridlens uses recurrentlens through its public symbols, never through
its method-resolution order. Bumping recurrentlens within the pinned
range should not require a hybridlens code change.

## Out-of-scope for v0.1.0 (see ROADMAP.md)

- captum integrated-gradients attribution → `method='ig'` (v0.1.1)
- Nemotron-Nano 2 / Samba adapters (v0.1.1)
- Pretrained ComponentSAEBundle assets on the Hub (v0.1.1)
- HF Space (gradio ZeroGPU) deploy (v0.1.1)
- MoE expert routing trace + load-balance loss exposure (v0.2)
- Cross-component Sankey viz (v0.2)
- RLVR training-cycle SAE observation (v0.3, H2 HybridScope-RL track)
