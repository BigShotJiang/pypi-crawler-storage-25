# Contributing to hybridlens

Thanks for considering a contribution. `hybridlens` is solo-maintained; PRs
and Issues are welcome but response is best-effort.

## Development

```bash
git clone https://github.com/hinanohart/hybridlens.git
cd hybridlens
uv pip install -e ".[dev,mamba]"
pytest
ruff check src tests
ruff format src tests
```

## PR checklist

- [ ] `ruff check` passes
- [ ] `ruff format --check` passes
- [ ] `pytest -ra` passes (CPU)
- [ ] Coverage stays at ≥85% overall, ≥90% for `core/` and `sae/`
- [ ] New public symbols are exported from `hybridlens/__init__.py`
- [ ] CHANGELOG `[Unreleased]` section updated

## Scope discipline

v0.1.0 is intentionally small (8 public APIs). New adapters / attribution
methods / viz should target the v0.1.1 or v0.2 milestone unless they fix
a correctness bug in the eight APIs already shipped.
