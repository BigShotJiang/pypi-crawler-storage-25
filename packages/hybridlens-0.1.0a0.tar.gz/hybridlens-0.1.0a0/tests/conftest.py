"""Shared pytest fixtures.

Heavy backends (torch, transformers) are imported lazily inside fixtures so
that pure-metadata tests (smoke/unit on protocols, layouts) stay fast and the
collection step does not require CUDA wheels.
"""

from __future__ import annotations

import os

import pytest


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Skip GPU-marked tests when CUDA is unavailable or explicitly disabled."""
    skip_gpu = os.environ.get("HYBRIDLENS_SKIP_GPU_TESTS") == "1"
    cuda_available = False
    if not skip_gpu:
        try:
            import torch

            cuda_available = torch.cuda.is_available()
        except ImportError:
            cuda_available = False
    if skip_gpu or not cuda_available:
        skip_marker = pytest.mark.skip(reason="CUDA not available or HYBRIDLENS_SKIP_GPU_TESTS=1")
        for item in items:
            if "gpu" in item.keywords:
                item.add_marker(skip_marker)


@pytest.fixture(scope="session")
def torch_cpu():
    """Lazy torch import bound to CPU device; raises if torch is missing."""
    import torch

    torch.set_grad_enabled(False)
    return torch
