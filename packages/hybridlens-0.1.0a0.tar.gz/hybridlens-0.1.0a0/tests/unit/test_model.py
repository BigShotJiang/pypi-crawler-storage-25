"""Unit: HybridLensModel + load_hybrid_model."""

from __future__ import annotations

import pytest

from hybridlens.core.layout import LayerLayout, LayerSlot
from hybridlens.core.model import HybridLensModel, load_hybrid_model


def _toy_layout(family: str = "jamba") -> LayerLayout:
    return LayerLayout(
        family=family,  # type: ignore[arg-type]
        n_layers=2,
        slots=[LayerSlot(layer=0, component="attn", d_model=64)],
    )


def test_load_hybrid_model_v010_final_pending() -> None:
    with pytest.raises(NotImplementedError, match="v0.1.0 final"):
        load_hybrid_model("ai21labs/Jamba-tiny-dev", family="jamba")


def test_hybridlensmodel_family_property() -> None:
    m = HybridLensModel(model=None, tokenizer=None, layout=_toy_layout("jamba"))
    assert m.family == "jamba"


def test_hybridlensmodel_repr_shape() -> None:
    m = HybridLensModel(model=None, tokenizer=None, layout=_toy_layout("zamba2"))
    s = repr(m)
    assert "zamba2" in s
    assert "n_layers=2" in s
