"""Unit: ComponentSAEBundle + train_component_sae."""

from __future__ import annotations

import pytest

from hybridlens.sae.per_component import (
    BundleEntry,
    ComponentSAEBundle,
    train_component_sae,
)


def _entry(
    component: str = "attn",
    layer: int = 0,
    variant: str = "vanilla",
    d_model: int = 64,
    d_sae: int = 256,
    filename: str | None = None,
) -> BundleEntry:
    return BundleEntry(
        component=component,  # type: ignore[arg-type]
        layer=layer,
        variant=variant,
        d_model=d_model,
        d_sae=d_sae,
        filename=filename or f"{component}-L{layer}.safetensors",
    )


def test_bundle_load_missing_manifest_raises(tmp_path) -> None:
    with pytest.raises(FileNotFoundError):
        ComponentSAEBundle.load(tmp_path)


def test_bundle_summary_lists_components_and_count() -> None:
    b = ComponentSAEBundle([_entry()])
    s = b.summary()
    assert "attn" in s
    assert "n_entries=1" in s


def test_train_component_sae_n_tokens_must_be_positive() -> None:
    with pytest.raises(ValueError, match="n_tokens"):
        train_component_sae(model=None, component="attn", layer=0, n_tokens=0)


def test_train_component_sae_d_sae_mult_must_be_positive() -> None:
    with pytest.raises(ValueError, match="d_sae_mult"):
        train_component_sae(model=None, component="attn", layer=0, n_tokens=10, d_sae_mult=0)


def test_bundle_save_and_load_roundtrip(tmp_path) -> None:
    """Empty-SAE round-trip: save manifest, load it back, entries equal."""
    entries = [
        _entry(component="attn", layer=0),
        _entry(component="ssm", layer=4, variant="jumprelu"),
        _entry(component="mlp", layer=4, variant="vanilla"),
    ]
    b = ComponentSAEBundle(entries)
    b.save(tmp_path)
    assert (tmp_path / "bundle.json").exists()
    reloaded = ComponentSAEBundle.load(tmp_path)
    assert reloaded.entries == entries


def test_bundle_get_missing_raises() -> None:
    b = ComponentSAEBundle([_entry()])
    with pytest.raises(KeyError):
        b.get(component="attn", layer=99)
