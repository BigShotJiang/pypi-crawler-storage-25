"""Unit: attribute() function."""

from __future__ import annotations

import pytest

from hybridlens.attribution.ablation import attribute


def test_attribute_unsupported_method_points_to_v011() -> None:
    with pytest.raises(NotImplementedError, match="v0.1.1"):
        attribute(model=None, input_ids=None, method="ig")  # type: ignore[arg-type]
