"""Unit: Zamba2Adapter discovery (config-driven, no torch required)."""

from __future__ import annotations

from types import SimpleNamespace

from hybridlens.adapters.zamba2 import Zamba2Adapter


def _toy_model(
    *,
    n_layers: int = 4,
    d_model: int = 64,
    hybrid_layer_ids: tuple[int, ...] = (1, 3),
) -> SimpleNamespace:
    config = SimpleNamespace(
        num_hidden_layers=n_layers,
        hidden_size=d_model,
        hybrid_layer_ids=list(hybrid_layer_ids),
    )
    return SimpleNamespace(config=config)


def test_zamba2_family_attr() -> None:
    assert Zamba2Adapter().family == "zamba2"


def test_zamba2_discover_layout_every_layer_has_ssm_and_mlp() -> None:
    layout = Zamba2Adapter().discover_layout(_toy_model(n_layers=4))
    ssm_layers = {s.layer for s in layout.filter(component="ssm")}
    mlp_layers = {s.layer for s in layout.filter(component="mlp")}
    assert ssm_layers == set(range(4))
    assert mlp_layers == set(range(4))


def test_zamba2_discover_layout_hybrid_layers_add_attn() -> None:
    layout = Zamba2Adapter().discover_layout(_toy_model(n_layers=4, hybrid_layer_ids=(1, 3)))
    attn_layers = {s.layer for s in layout.filter(component="attn")}
    assert attn_layers == {1, 3}


def test_zamba2_component_hidden_size_uniform() -> None:
    model = _toy_model(n_layers=2, d_model=512)
    assert Zamba2Adapter().component_hidden_size(model, layer=0, component="ssm") == 512
