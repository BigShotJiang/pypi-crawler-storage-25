"""Unit: hub_push_bundle / hub_load_bundle repo-id guards."""

from __future__ import annotations

import pytest

from hybridlens.hub.io import hub_load_bundle, hub_push_bundle


def test_push_bundle_repo_id_requires_owner_slash_name() -> None:
    with pytest.raises(ValueError, match="owner/name"):
        hub_push_bundle(bundle=None, repo_id="no-slash")  # type: ignore[arg-type]


def test_load_bundle_repo_id_requires_owner_slash_name() -> None:
    with pytest.raises(ValueError, match="owner/name"):
        hub_load_bundle(repo_id="missing-slash")
