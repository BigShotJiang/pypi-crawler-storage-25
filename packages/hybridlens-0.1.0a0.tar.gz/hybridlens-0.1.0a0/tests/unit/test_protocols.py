"""Unit: HybridAdapter Protocol (structural check)."""

from __future__ import annotations

from hybridlens.adapters.jamba import JambaAdapter
from hybridlens.adapters.zamba2 import Zamba2Adapter
from hybridlens.core.protocols import HybridAdapter


def test_jamba_satisfies_hybrid_adapter() -> None:
    assert isinstance(JambaAdapter(), HybridAdapter)


def test_zamba2_satisfies_hybrid_adapter() -> None:
    assert isinstance(Zamba2Adapter(), HybridAdapter)
