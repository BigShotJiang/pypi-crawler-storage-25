"""Unit: hooks.resolve_site / install_capture_hook."""

from __future__ import annotations

import pytest

from hybridlens.core.layout import LayerLayout, LayerSlot
from hybridlens.hooks.sites import install_capture_hook, resolve_site


def _jamba_toy_layout() -> LayerLayout:
    return LayerLayout(
        family="jamba",
        n_layers=4,
        slots=[
            LayerSlot(layer=0, component="attn", d_model=64),
            LayerSlot(layer=0, component="mlp", d_model=64),
            LayerSlot(layer=1, component="ssm", d_model=64),
            LayerSlot(layer=1, component="mlp", d_model=64),
        ],
    )


def _zamba2_toy_layout() -> LayerLayout:
    return LayerLayout(
        family="zamba2",
        n_layers=2,
        slots=[
            LayerSlot(layer=0, component="ssm", d_model=64),
            LayerSlot(layer=0, component="mlp", d_model=64),
            LayerSlot(layer=1, component="ssm", d_model=64),
            LayerSlot(layer=1, component="attn", d_model=64),
            LayerSlot(layer=1, component="mlp", d_model=64),
        ],
    )


def test_resolve_site_missing_slot_raises_keyerror() -> None:
    layout = _jamba_toy_layout()
    with pytest.raises(KeyError):
        resolve_site(layout, layer=3, component="ssm")


def test_resolve_site_jamba_attn_path() -> None:
    path = resolve_site(_jamba_toy_layout(), layer=0, component="attn")
    assert path == "model.layers.0.self_attn"


def test_resolve_site_zamba2_ssm_path() -> None:
    path = resolve_site(_zamba2_toy_layout(), layer=0, component="ssm")
    assert path == "model.layers.0.mamba"


def test_resolve_site_zamba2_attn_only_on_hybrid_layer() -> None:
    layout = _zamba2_toy_layout()
    path = resolve_site(layout, layer=1, component="attn")
    assert path == "model.layers.1.self_attn"
    with pytest.raises(KeyError):
        resolve_site(layout, layer=0, component="attn")


@pytest.mark.xfail(
    reason="install_capture_hook requires torch — Phase 5 release verify activates",
    strict=False,
)
def test_install_capture_hook_phase5_pending() -> None:
    install_capture_hook(model=None, module_path="x", buffer=[])
