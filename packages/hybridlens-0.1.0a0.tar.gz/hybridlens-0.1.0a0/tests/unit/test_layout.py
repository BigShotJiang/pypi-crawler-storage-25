"""Unit: LayerLayout / LayerSlot pydantic schema."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from hybridlens.core.layout import LayerLayout, LayerSlot


def _slot(
    layer: int = 0,
    component: str = "attn",
    site: str = "residual_post",
    d_model: int = 512,
) -> LayerSlot:
    return LayerSlot(layer=layer, component=component, site=site, d_model=d_model)  # type: ignore[arg-type]


def test_layer_slot_frozen() -> None:
    s = _slot()
    with pytest.raises(ValidationError):
        s.layer = 5  # frozen=True forbids assignment


def test_layout_duplicate_triple_rejected() -> None:
    s1 = _slot(layer=0, component="attn", site="residual_post")
    s2 = _slot(layer=0, component="attn", site="residual_post")
    with pytest.raises(ValidationError, match="duplicate slot"):
        LayerLayout(family="jamba", n_layers=4, slots=[s1, s2])


def test_filter_by_component() -> None:
    s_attn = _slot(component="attn")
    s_mlp = _slot(layer=1, component="mlp")
    layout = LayerLayout(family="jamba", n_layers=4, slots=[s_attn, s_mlp])
    assert layout.filter(component="attn") == [s_attn]


def test_filter_by_layer() -> None:
    s0 = _slot(layer=0, component="ssm")
    s1 = _slot(layer=1, component="ssm")
    layout = LayerLayout(family="zamba2", n_layers=4, slots=[s0, s1])
    assert layout.filter(layer=1) == [s1]


def test_filter_layer_and_component() -> None:
    s0a = _slot(layer=0, component="attn")
    s0m = _slot(layer=0, component="mlp")
    s1a = _slot(layer=1, component="attn")
    layout = LayerLayout(family="jamba", n_layers=4, slots=[s0a, s0m, s1a])
    assert layout.filter(layer=0, component="attn") == [s0a]
