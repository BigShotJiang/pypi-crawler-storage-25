"""Unit: JambaAdapter discovery (config-driven, no torch required)."""

from __future__ import annotations

from types import SimpleNamespace

from hybridlens.adapters.jamba import JambaAdapter


def _toy_model(
    *,
    n_layers: int = 8,
    d_model: int = 128,
    attn_layer_period: int = 4,
    attn_layer_offset: int = 2,
    expert_layer_period: int = 2,
    expert_layer_offset: int = 1,
) -> SimpleNamespace:
    config = SimpleNamespace(
        num_hidden_layers=n_layers,
        hidden_size=d_model,
        attn_layer_period=attn_layer_period,
        attn_layer_offset=attn_layer_offset,
        expert_layer_period=expert_layer_period,
        expert_layer_offset=expert_layer_offset,
    )
    return SimpleNamespace(config=config)


def test_jamba_family_attr() -> None:
    assert JambaAdapter().family == "jamba"


def test_jamba_discover_layout_basic_shape() -> None:
    layout = JambaAdapter().discover_layout(_toy_model(n_layers=4, d_model=64))
    assert layout.family == "jamba"
    assert layout.n_layers == 4
    assert all(s.d_model == 64 for s in layout.slots)


def test_jamba_discover_layout_attn_period_picks_attn_layers() -> None:
    layout = JambaAdapter().discover_layout(
        _toy_model(n_layers=8, attn_layer_period=4, attn_layer_offset=2)
    )
    attn_layers = {s.layer for s in layout.filter(component="attn")}
    assert attn_layers == {2, 6}
    ssm_layers = {s.layer for s in layout.filter(component="ssm")}
    assert attn_layers.isdisjoint(ssm_layers)


def test_jamba_discover_layout_every_layer_has_mlp() -> None:
    layout = JambaAdapter().discover_layout(_toy_model(n_layers=6))
    mlp_layers = {s.layer for s in layout.filter(component="mlp")}
    assert mlp_layers == set(range(6))


def test_jamba_component_hidden_size_uniform() -> None:
    model = _toy_model(n_layers=2, d_model=256)
    assert JambaAdapter().component_hidden_size(model, layer=0, component="attn") == 256
    assert JambaAdapter().component_hidden_size(model, layer=1, component="ssm") == 256
