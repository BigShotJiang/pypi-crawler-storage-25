"""Unit: AttributionResult dataclass."""

from __future__ import annotations

import pytest

from hybridlens.attribution.base import AttributionResult


def test_attribution_result_length_mismatch_rejected() -> None:
    with pytest.raises(ValueError, match="length mismatch"):
        AttributionResult(
            method="ablation",
            target_metric="logit_diff",
            slots=(("attn", 0), ("mlp", 0)),
            scores=(0.1,),
            delta_metric=0.5,
        )
