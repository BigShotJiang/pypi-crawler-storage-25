"""Unit: steer_component contextmanager guards."""

from __future__ import annotations

import pytest

from hybridlens.features.component_patch import steer_component


def test_steer_zero_scale_is_noop() -> None:
    with steer_component(
        model=None,
        bundle=None,
        component="attn",
        feature_id=0,
        scale=0.0,
    ):
        pass  # context exits cleanly without raising


def test_steer_negative_feature_id_rejected() -> None:
    with (
        pytest.raises(ValueError, match="non-negative"),
        steer_component(
            model=None,
            bundle=None,
            component="attn",
            feature_id=-1,
            scale=1.0,
        ),
    ):
        pass
