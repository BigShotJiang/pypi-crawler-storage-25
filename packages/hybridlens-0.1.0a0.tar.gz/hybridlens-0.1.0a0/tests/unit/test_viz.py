"""Unit: render_hybrid_explorer HTML escaping + structure."""

from __future__ import annotations

import pytest

from hybridlens.sae.per_component import BundleEntry, ComponentSAEBundle
from hybridlens.viz.hybrid_explorer import render_hybrid_explorer


def test_render_negative_feature_id_rejected() -> None:
    with pytest.raises(ValueError):
        render_hybrid_explorer(bundle=None, feature_id=-1, context="ctx", model_id="m")


def test_render_empty_bundle_returns_html() -> None:
    html = render_hybrid_explorer(bundle=None, feature_id=3, context="hello", model_id="my/model")
    assert "<!DOCTYPE html>" in html
    assert "Feature 3" in html
    assert "(empty bundle)" in html


def test_render_escapes_caller_controlled_fields() -> None:
    html = render_hybrid_explorer(
        bundle=None,
        feature_id=0,
        context="<script>alert(1)</script>",
        model_id="<img onerror=x>",
    )
    assert "<script>" not in html
    assert "&lt;script&gt;" in html
    assert "&lt;img onerror=x&gt;" in html


def test_render_lists_bundle_entries() -> None:
    entries = [
        BundleEntry(
            component="attn",
            layer=4,
            variant="vanilla",
            d_model=64,
            d_sae=256,
            filename="attn-L4.safetensors",
        ),
        BundleEntry(
            component="ssm",
            layer=8,
            variant="jumprelu",
            d_model=64,
            d_sae=256,
            filename="ssm-L8.safetensors",
        ),
    ]
    bundle = ComponentSAEBundle(entries)
    html = render_hybrid_explorer(bundle=bundle, feature_id=0, context="ctx", model_id="m")
    assert "attn" in html
    assert "ssm" in html
    assert "vanilla" in html
    assert "jumprelu" in html
