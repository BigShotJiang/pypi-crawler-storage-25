"""Unit: type aliases."""

from __future__ import annotations

import typing

from hybridlens.core.types import Component, Family, HookSite


def test_component_literal_members() -> None:
    assert set(typing.get_args(Component)) == {"attn", "ssm", "mlp", "moe", "router"}


def test_family_literal_members() -> None:
    assert set(typing.get_args(Family)) == {"jamba", "zamba2"}


def test_hooksite_literal_members() -> None:
    assert set(typing.get_args(HookSite)) == {
        "residual_pre",
        "residual_post",
        "component_out",
    }
