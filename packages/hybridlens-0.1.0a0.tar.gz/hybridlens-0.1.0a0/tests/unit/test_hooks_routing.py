"""Unit: hooks.routing.RoutingTap."""

from __future__ import annotations

import pytest

from hybridlens.hooks.routing import RoutingTap


def test_routing_tap_negative_layer_rejected() -> None:
    with pytest.raises(ValueError, match="non-negative"):
        RoutingTap(layer=-1)


def test_routing_tap_default_state_is_empty() -> None:
    t = RoutingTap(layer=3)
    assert t.expert_indices == []
    assert t.router_logits == []
    assert t.load_balance is None
