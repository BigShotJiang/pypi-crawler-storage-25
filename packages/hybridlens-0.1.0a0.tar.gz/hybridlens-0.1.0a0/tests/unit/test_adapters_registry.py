"""Unit: adapter registry (`get_adapter`)."""

from __future__ import annotations

import pytest

from hybridlens.adapters import JambaAdapter, Zamba2Adapter, get_adapter


def test_get_jamba_returns_jamba_adapter() -> None:
    assert isinstance(get_adapter("jamba"), JambaAdapter)


def test_get_zamba2_returns_zamba2_adapter() -> None:
    assert isinstance(get_adapter("zamba2"), Zamba2Adapter)


def test_get_unknown_family_mentions_v011_path() -> None:
    with pytest.raises(ValueError, match="v0.1.1"):
        get_adapter("nemotron")
