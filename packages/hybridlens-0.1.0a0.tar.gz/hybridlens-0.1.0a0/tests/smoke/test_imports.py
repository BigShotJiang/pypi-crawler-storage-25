"""Smoke: PEP 562 lazy chain resolves every documented public API."""

from __future__ import annotations

import pytest

import hybridlens

pytestmark = pytest.mark.smoke

_EXPECTED = {
    "load_hybrid_model",
    "HybridLensModel",
    "LayerLayout",
    "train_component_sae",
    "ComponentSAEBundle",
    "attribute",
    "steer_component",
    "hub_push_bundle",
    "hub_load_bundle",
}


def test_all_public_apis_are_exported() -> None:
    assert set(hybridlens.__all__) >= _EXPECTED


def test_every_public_api_resolves_without_error() -> None:
    for name in _EXPECTED:
        obj = getattr(hybridlens, name)
        assert obj is not None, name
