"""Smoke: package metadata."""

from __future__ import annotations

import re

import pytest

import hybridlens

pytestmark = pytest.mark.smoke


def test_version_is_pep440_alpha() -> None:
    """`hybridlens.__version__` is a valid PEP 440 alpha pre-release."""
    assert re.fullmatch(r"\d+\.\d+\.\d+(a\d+)?", hybridlens.__version__)
    assert hybridlens.__version__ == "0.1.0a0"
