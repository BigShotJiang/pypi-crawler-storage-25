"""Property: ComponentSAEBundle summary counts entries."""

from __future__ import annotations

import pytest

from hybridlens.sae.per_component import BundleEntry, ComponentSAEBundle


@pytest.mark.property
def test_bundle_summary_counts_entries() -> None:
    entries = [
        BundleEntry(
            component="attn",
            layer=i,
            variant="vanilla",
            d_model=64,
            d_sae=256,
            filename=f"attn-L{i}.safetensors",
        )
        for i in range(3)
    ]
    b = ComponentSAEBundle(entries)
    assert "n_entries=3" in b.summary()
