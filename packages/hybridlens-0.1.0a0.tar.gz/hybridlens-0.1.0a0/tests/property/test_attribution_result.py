"""Property: AttributionResult length parity."""

from __future__ import annotations

import pytest
from hypothesis import given
from hypothesis import strategies as st

from hybridlens.attribution.base import AttributionResult


@given(n=st.integers(min_value=1, max_value=64))
@pytest.mark.property
def test_attribution_result_holds_when_lengths_match(n: int) -> None:
    slots = tuple(("attn", i) for i in range(n))
    scores = tuple(0.1 for _ in range(n))
    r = AttributionResult(
        method="ablation",
        target_metric="logit_diff",
        slots=slots,
        scores=scores,
        delta_metric=0.0,
    )
    assert len(r.slots) == len(r.scores) == n
