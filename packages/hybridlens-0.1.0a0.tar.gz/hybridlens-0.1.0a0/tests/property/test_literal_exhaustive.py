"""Property: every Literal member is a non-empty string."""

from __future__ import annotations

import typing

import pytest

from hybridlens.core.types import Component, Family, HookSite


@pytest.mark.property
def test_all_literal_members_are_non_empty_strings() -> None:
    for literal in (Component, Family, HookSite):
        members = typing.get_args(literal)
        assert len(members) > 0
        for member in members:
            assert isinstance(member, str)
            assert len(member) > 0
