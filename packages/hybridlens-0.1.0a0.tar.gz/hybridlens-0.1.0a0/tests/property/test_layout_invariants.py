"""Property: LayerLayout / LayerSlot invariants under hypothesis."""

from __future__ import annotations

import pytest
from hypothesis import given
from hypothesis import strategies as st
from pydantic import ValidationError

from hybridlens.core.layout import LayerSlot


@given(
    layer=st.integers(min_value=0, max_value=200),
    d=st.integers(min_value=1, max_value=4096),
)
@pytest.mark.property
def test_layer_slot_accepts_valid_ranges(layer: int, d: int) -> None:
    s = LayerSlot(layer=layer, component="attn", d_model=d)
    assert s.layer == layer
    assert s.d_model == d


@given(layer=st.integers(min_value=-100, max_value=-1))
@pytest.mark.property
def test_layer_slot_rejects_negative_layer(layer: int) -> None:
    with pytest.raises(ValidationError):
        LayerSlot(layer=layer, component="attn", d_model=64)
