"""Integration: bundle round-trip + hub push/load (xfail until phase 3).

Test-local `importorskip("recurrentlens")` keeps these out of the unit /
property / smoke run until the sibling dep is present. Hub tests
additionally `importorskip("huggingface_hub")` inside the test body.
"""

from __future__ import annotations

import pytest

pytest.importorskip("recurrentlens")

pytestmark = pytest.mark.integration

_PHASE3_PENDING = "phase 3 impl + recurrentlens>=0.1.0.post1 install required"


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_bundle_save_and_load_roundtrip(tmp_path) -> None:
    from hybridlens.sae.per_component import BundleEntry, ComponentSAEBundle

    entries = [
        BundleEntry(
            component="attn",
            layer=0,
            variant="vanilla",
            d_model=64,
            d_sae=256,
            filename="attn-L0.safetensors",
        )
    ]
    b = ComponentSAEBundle(entries)
    b.save(tmp_path)  # raises NotImplementedError in phase 1
    reloaded = ComponentSAEBundle.load(tmp_path)
    assert reloaded.entries == entries


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_hub_push_bundle_returns_repo_url() -> None:
    from hybridlens.hub.io import hub_push_bundle
    from hybridlens.sae.per_component import ComponentSAEBundle

    url = hub_push_bundle(ComponentSAEBundle([]), repo_id="hinanohart/hybridlens-empty")
    assert url.startswith("https://huggingface.co/")


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_hub_load_bundle_returns_bundle() -> None:
    from hybridlens.hub.io import hub_load_bundle

    b = hub_load_bundle("hinanohart/hybridlens-demo")
    assert b is not None


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_attribute_full_layout_decomposition() -> None:
    from hybridlens import attribute, load_hybrid_model

    model = load_hybrid_model("ai21labs/Jamba-tiny-dev", family="jamba")
    res = attribute(model, input_ids=None, method="ablation")
    assert len(res.slots) == len(res.scores)
