"""Integration: end-to-end Jamba pipeline (Phase 3 fills, currently xfail).

Skipped entirely while `recurrentlens` is not importable in the test env
(Phase 0a published `recurrentlens==0.1.0.post1` to PyPI, but the local
.venv used during Phases 2-3 does not install heavy backends). Once the
Phase 5 release-verify venv installs `recurrentlens`, the xfails become
the live gate.
"""

from __future__ import annotations

import pytest

pytest.importorskip("recurrentlens")

pytestmark = pytest.mark.integration

_PHASE3_PENDING = "phase 3 impl + recurrentlens>=0.1.0.post1 install required"


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_jamba_load_and_layout_discovery() -> None:
    from hybridlens import load_hybrid_model

    model = load_hybrid_model("ai21labs/Jamba-tiny-dev", family="jamba")
    assert model.family == "jamba"
    assert model.layout.n_layers > 0


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_jamba_train_attn_sae_returns_bundle_compatible() -> None:
    from hybridlens import load_hybrid_model, train_component_sae

    model = load_hybrid_model("ai21labs/Jamba-tiny-dev", family="jamba")
    sae = train_component_sae(model, component="attn", layer=0, n_tokens=200)
    assert sae is not None


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_jamba_attribute_ablation_runs() -> None:
    from hybridlens import attribute, load_hybrid_model

    model = load_hybrid_model("ai21labs/Jamba-tiny-dev", family="jamba")
    res = attribute(model, input_ids=None, method="ablation")
    assert res.method == "ablation"
