"""Integration: end-to-end Zamba2 pipeline (Phase 3 fills, currently xfail).

Module-level `importorskip("recurrentlens")` mirrors the Jamba integration
file: skip when the sibling dep is absent, xfail when it is present until
Phase 3 fills in the adapters.
"""

from __future__ import annotations

import pytest

pytest.importorskip("recurrentlens")

pytestmark = pytest.mark.integration

_PHASE3_PENDING = "phase 3 impl + recurrentlens>=0.1.0.post1 install required"


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_zamba2_load_and_layout_discovery() -> None:
    from hybridlens import load_hybrid_model

    model = load_hybrid_model("Zyphra/Zamba2-1.2B", family="zamba2")
    assert model.family == "zamba2"
    assert model.layout.n_layers > 0


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_zamba2_train_ssm_sae_returns_bundle_compatible() -> None:
    from hybridlens import load_hybrid_model, train_component_sae

    model = load_hybrid_model("Zyphra/Zamba2-1.2B", family="zamba2")
    sae = train_component_sae(model, component="ssm", layer=0, n_tokens=200)
    assert sae is not None


@pytest.mark.xfail(reason=_PHASE3_PENDING, strict=False)
def test_zamba2_steer_component_runs() -> None:
    from hybridlens import load_hybrid_model, steer_component

    model = load_hybrid_model("Zyphra/Zamba2-1.2B", family="zamba2")
    with steer_component(model, bundle=None, component="ssm", feature_id=0, scale=1.0):
        pass
