import time

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

from snowflake.connector.errors import (
    DatabaseError,
    InterfaceError,
    OperationalError,
    ProgrammingError,
)

from shared_kernel.config import Config
from shared_kernel.data_warehouse_handlers.utils import extract_error_message, extract_snowflake_error_message
from shared_kernel.interfaces.query_executor import DataWarehouseQueryExecutor
from shared_kernel.interfaces.warehouse_connection import DataWarehouseConnection
from shared_kernel.logger import Logger

config = Config()
logger = Logger(config.get("APP_NAME"))
MAX_QUERY_CONCURRENCY = 5


class SnowflakeQueryExecutor(DataWarehouseQueryExecutor):

    def __init__(self, warehouse_connection: DataWarehouseConnection) -> None:
        self.warehouse_connection = warehouse_connection

    def execute_query(
        self,
        query: str,
        params: Optional[tuple] = None,
    ) -> List[Dict[str, Any]]:
        """
        Execute a single SQL query and return all rows as a list of dicts.
        """
        with self.warehouse_connection.get_connection() as cursor:
            try:
                logger.info(f"Executing query: {query}")
                start = time.perf_counter()

                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)

                elapsed = time.perf_counter() - start
                logger.info(f"Query executed in {elapsed:.6f}s")

                columns = [col[0].lower() for col in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]

            except (OperationalError, ProgrammingError, InterfaceError, DatabaseError) as e:
                logger.error(f"Query failed: {query} — {e}", exc_info=True)
                user_msg = extract_snowflake_error_message(str(e))
                raise Exception(f"Query execution failed: {user_msg}") from e
            except Exception as e:
                raise Exception(f"Query execution failed: {str(e)}") from e

    def execute_queries(
        self,
        queries: List[str],
    ) -> List[List[Dict[str, Any]]]:
        """
        Execute multiple SQL queries in parallel and return results in input order.
        """
        if not queries:
            return []

        indexed: List[Tuple[int, str]] = list(enumerate(queries))
        results: List[Optional[List[Dict[str, Any]]]] = [None] * len(queries)

        with ThreadPoolExecutor(max_workers=MAX_QUERY_CONCURRENCY) as pool:
            future_to_index = {
                pool.submit(self.execute_query, query): idx
                for idx, query in indexed
            }

            for future in as_completed(future_to_index):
                idx = future_to_index[future]
                try:
                    results[idx] = future.result()
                except Exception as e:
                    # Cancel all pending futures
                    for pending in future_to_index:
                        if not pending.done():
                            pending.cancel()
                    raise Exception(
                        f"Parallel query execution failed on query index {idx}: {e}"
                    ) from e

        return results

    def execute_query_with_column_types(
        self,
        query: str,
        params: Optional[tuple] = None,
    ) -> Tuple[List[Dict[str, Any]], List[Tuple]]:
        """
        Execute a query and return both rows and raw DBAPI cursor description.

        The cursor description gives access to column-level metadata including
        the DBAPI type code for each column, needed for accurate type mapping.
        """
        with self.warehouse_connection.get_connection() as conn:
            try:
                logger.info(f"Executing query with column types: {query}")
                start = time.perf_counter()

                cursor = (
                    conn.execute(query, params)
                    if params
                    else conn.execute(query)
                )

                elapsed = time.perf_counter() - start
                logger.info(f"Query executed in {elapsed:.6f}s")

                description = cursor.description
                columns = [col[0].lower() for col in description]
                rows = [dict(zip(columns, row)) for row in cursor.fetchall()]

                return rows, description

            except (OperationalError, ProgrammingError, InterfaceError) as e:
                logger.error(f"Query failed: {query} — {e}", exc_info=True)
                user_msg = extract_error_message(str(e))
                raise Exception(f"Query execution failed: {user_msg}") from e
            except Exception as e:
                user_msg = extract_error_message(str(e))
                raise Exception(f"Query execution failed: {user_msg}") from e