import errno
import hashlib
import time
import threading

from contextlib import contextmanager
from typing import Dict

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import InterfaceError, OperationalError, ProgrammingError

from shared_kernel.dataclasses.warehouse_configs import RedshiftConfig
from shared_kernel.exceptions.http_exceptions import BadRequest
from shared_kernel.interfaces.warehouse_connection import DataWarehouseConnection
from shared_kernel.logger import Logger
from shared_kernel.config import Config

config = Config()
logger = Logger(config.get("APP_NAME"))


class RedshiftWarehouseConnection(DataWarehouseConnection):

    _engines: Dict[str, Engine] = {}
    _lock = threading.Lock()
    _last_dispose_time: Dict[str, float] = {}

    def __init__(
        self,
        source_config: RedshiftConfig,
        set_default_schema: bool = True,
    ):
        if source_config is None:
            raise ValueError(
                "Missing required parameter: source_config (RedshiftConfig)"
            )

        super().__init__(source_config)
        self._redshift_config = source_config
        self.org_schema = source_config.schema if source_config.schema else None
        self.set_default_schema = set_default_schema

    def _engine_key(self, cfg: RedshiftConfig) -> str:
        pwd_hash = hashlib.sha256(cfg.password.encode()).hexdigest()
        return f"{cfg.host}|{cfg.port}|{cfg.database}|{cfg.username}|{pwd_hash}"
    
    def invalidate_pool(self):
        key = self._engine_key(self._redshift_config)
        with self.__class__._lock:
            now = time.time()
            last_time = self._last_dispose_time.get(key, 0)
            # Throttle (5 seconds)
            if now - last_time < 5:
                return
            engine = self._engines.get(key)
            if engine:
                logger.warning(f"Disposing engine pool for {key} due to stale OID")
                engine.dispose()
                self._last_dispose_time[key] = now

    def _get_engine(self) -> Engine:
        cfg = self._redshift_config
        key = self._engine_key(cfg)

        if key not in self._engines:
            with self.__class__._lock: # thread-safe
                if key not in self._engines: # recheck
                    url = (
                        f"redshift+redshift_connector://{cfg.username}:{cfg.password}"
                        f"@{cfg.host}:{cfg.port}/{cfg.database}"
                    )
                    self._engines[key] = create_engine(
                        url,
                        pool_size=10,
                        max_overflow=5,
                        pool_timeout=30,
                        pool_recycle=1800,
                        pool_pre_ping=True,
                        isolation_level="AUTOCOMMIT",
                    )
                    logger.info(f"Created new engine for {cfg.host}:{cfg.port}/{cfg.database}")

        return self._engines[key]

    def _is_maintenance_error(self, exc: Exception) -> bool:
        """Return True when the error looks like a Redshift cluster reboot or maintenance."""
        err = exc
        while hasattr(err, "__cause__") and err.__cause__:
            err = err.__cause__

        if isinstance(err, ConnectionRefusedError):
            return err.errno in (errno.ECONNREFUSED, 10061)

        if isinstance(err, InterfaceError) and "ConnectionRefusedError" in str(err):
            return True

        return False

    @contextmanager
    def get_connection(self, retries: int = 3, delay: int = 5):
        """Context manager for database connections with retry mechanism"""
        engine = self._get_engine()
        last_exception = None

        for attempt in range(retries):
            conn = None
            try:
                conn = engine.connect()
                conn.execute(text("SET enable_case_sensitive_identifier TO on"))

                if self.org_schema and self.set_default_schema:
                    conn.execute(text(f"SET search_path TO {self.org_schema}"))
                    logger.info(f"Search path set to: {self.org_schema}")

                yield conn
                return

            except (OperationalError, InterfaceError, ProgrammingError) as e:
                last_exception = e
                if conn is not None:
                    conn.close()
                    conn = None

                if self._is_maintenance_error(e):
                    logger.warning(f"Redshift maintenance detected (attempt {attempt + 1}/{retries}): {e}")
                else:
                    logger.warning(f"Connection failed (attempt {attempt + 1}/{retries}): {e}")

                if attempt < retries - 1:
                    time.sleep(delay)
                    delay += 5
                    continue

                break

            finally:
                if conn is not None:
                    conn.close()

        raise BadRequest(
            f"Failed to connect to Redshift after {retries} attempts"
        ) from last_exception

    def close_connection(self):
        """Dispose all pooled engines managed by this class."""
        for engine in self._engines.values():
            engine.dispose()
        self._engines.clear()
        logger.info("All Redshift engine pools disposed.")

    def is_valid_connection(self) -> bool:
        """Pool health is managed by pool_pre_ping; no manual check needed."""
        return True

    def test_connection(self) -> bool:
        """Verify the connection is reachable. Raises ConnectionError on failure."""
        try:
            with self.get_connection():
                return True
        except Exception as e:
            raise ConnectionError(f"Redshift connection test failed: {e}") from e
        