import time

from contextlib import contextmanager

from databricks import sql
from databricks.sql.exc import InterfaceError, OperationalError, ProgrammingError

from shared_kernel.dataclasses.warehouse_configs import DatabricksConfig
from shared_kernel.exceptions.http_exceptions import BadRequest
from shared_kernel.interfaces.warehouse_connection import DataWarehouseConnection
from shared_kernel.logger import Logger
from shared_kernel.config import Config

config = Config()
logger = Logger(config.get("APP_NAME"))


class DatabricksWarehouseConnection(DataWarehouseConnection):
    # Override Databricks connector's internal retry behaviour — we handle
    # retries ourselves so the connector should fail fast.
    _CONNECT_KWARGS = {
        "_retry_stop_after_attempts_count": 1,
        "_retry_delay_max": 5,
    }

    def __init__(
        self,
        source_config: DatabricksConfig,
        set_default_schema: bool = True,
    ):
        if source_config is None:
            raise ValueError(
                "Missing required parameter: source_config (DatabricksConfig)"
            )

        self._databricks_config = source_config
        self.org_schema = source_config.schema if source_config.schema else None
        self.set_default_schema = set_default_schema

        pagination = getattr(source_config, "pagination", None) or {}
        self.page = pagination.get("page") if isinstance(pagination, dict) else None
        self.limit = pagination.get("limit") if isinstance(pagination, dict) else None
        self.search = pagination.get("search") if isinstance(pagination, dict) else None

        self._conn = None
        self._cursor = None

    def _create_connection(self):
        cfg = self._databricks_config
        logger.debug(f"Databricks connection configuration: {cfg.__dict__}")
        self._conn = sql.connect(
            server_hostname=cfg.server_hostname,
            http_path=cfg.http_path,
            access_token=cfg.access_token,
            catalog=cfg.catalog,
            **self._CONNECT_KWARGS,
        )
        self._cursor = self._conn.cursor()

    def _create_connection_with_retry(self, retries: int = 3, delay: int = 5):
        for attempt in range(retries):
            try:
                try:
                    self._create_connection()
                except (InterfaceError, OperationalError, ProgrammingError) as e:
                    raise BadRequest(f"Connection to warehouse failed: {str(e)}")
                return

            except BadRequest as e:
                logger.error(
                    f"Databricks connection attempt {attempt + 1} failed: {str(e)}",
                    exc_info=True,
                )
                if attempt == retries - 1:
                    raise

            except Exception as e:
                logger.error(
                    f"Databricks connection attempt {attempt + 1} failed: {str(e)}",
                    exc_info=True,
                )
                if attempt == retries - 1:
                    raise BadRequest(
                        f"Failed to connect after {retries} attempts due to {str(e)}"
                    ) from e

                time.sleep(delay)
                self.close_connection()

    @contextmanager
    def get_connection(self, retries: int = 3, delay: int = 5):
        if not (self._conn and self.is_valid_connection()):
            self._create_connection_with_retry(retries, delay)
        try:
            yield self._cursor
        except Exception as e:
            raise e
        finally:
            self._conn.commit()
            self.close_connection()

    def close_connection(self):
        """Safely close the Databricks connection and cursor."""
        try:
            if self._cursor:
                self._cursor.close()
                logger.info("Terminated Databricks cursor connection.")
            if self._conn:
                self._conn.close()
                logger.info("Terminated Databricks connection.")
        except Exception as e:
            logger.error(f"Error closing Databricks connection: {str(e)}", exc_info=True)
        finally:
            self._cursor = None
            self._conn = None

    def is_valid_connection(self) -> bool:
        """Validate connection is alive with a simple query."""
        try:
            if self._cursor is None:
                return False
            self._cursor.execute(
                "SELECT current_user(), current_database(), version()"
            )
            user, db, version = self._cursor.fetchone()
            logger.debug(f"Connected as {user} to {db}, version: {version}")
            return True
        except (OperationalError, ProgrammingError, InterfaceError) as e:
            logger.error(f"Databricks connection validation error: {str(e)}")
            raise e
        except Exception as e:
            logger.error(f"Unexpected Databricks validation failure: {str(e)}")
            raise Exception("Databricks connection validation failed.")

    def test_connection(self) -> bool:
        """Verify the connection is reachable."""
        try:
            self._create_connection()
            self.close_connection()
            return True
        except Exception:
            return False
        