from pypika import MySQLQuery

from shared_kernel.data_warehouse_handlers.connections.mysql_warehouse_connection import MySQLWarehouseConnection
from shared_kernel.data_warehouse_handlers.query_executors.mysql_query_executor import MySQLQueryExecutor
from shared_kernel.dataclasses.warehouse_configs import MySQLConfig
from shared_kernel.interfaces.data_warehouse_handler import WarehouseHandler


class MySQLWarehouseHandler(WarehouseHandler):

    def __init__(self, payload: dict = None):
        super().__init__(payload)
        self.set_default_schema = self.payload.get("set_default_schema", True)

    def get_config(self) -> MySQLConfig:
        source_config: MySQLConfig = self.payload.get("source_config")
        if source_config and isinstance(source_config, MySQLConfig):
            return source_config

        required = ("host", "user", "password", "database", "port")
        missing = [f for f in required if not self.payload.get(f)]
        if missing:
            raise ValueError(
                f"MySQL payload is missing required fields: {missing}."
            )

        return MySQLConfig(
            username=str(self.payload.get("user")).strip(),
            password=str(self.payload.get("password")).strip(),
            host=str(self.payload.get("host")).strip(),
            database=str(self.payload.get("database")).strip(),
            port=str(self.payload.get("port")).strip(),
            schema=str(self.payload.get("schema")).strip() if self.payload.get("schema") else None,
            schema_list=self.payload.get("schema_list"),
            pagination=self.pagination,
        )

    def _build_connection(self) -> MySQLWarehouseConnection:
        return MySQLWarehouseConnection(
            source_config=self.get_config(),
            set_default_schema=self.set_default_schema,
        )

    def get_executor(self) -> MySQLQueryExecutor:
        connection = self._build_connection()
        return MySQLQueryExecutor(warehouse_connection=connection)

    def get_query_object(self) -> MySQLQuery:
        return MySQLQuery

    def create_records_and_count_query(
        self,
        query: str,
        limit: str,
        page: str,
    ) -> tuple[str, str]:
        count_query = f"SELECT COUNT(*) FROM ({query}) AS _count"

        if limit:
            query = f"{query} LIMIT {int(limit)}"
            if page:
                offset = (int(page) - 1) * int(limit)
                query = f"{query} OFFSET {offset}"

        return count_query, query
    