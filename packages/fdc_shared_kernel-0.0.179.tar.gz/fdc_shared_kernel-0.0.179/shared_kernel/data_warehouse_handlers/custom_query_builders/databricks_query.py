from typing import Any
from pypika import Query
from pypika.queries import QueryBuilder, Selectable, AliasedQuery
from pypika.utils import format_quotes, builder


class DatabricksQuery(Query):
    """
    Defines a query class for use with Databricks.
    """

    @classmethod
    def _builder(cls, **kwargs) -> "DatabricksQueryBuilder":
        return DatabricksQueryBuilder(dialect="databricks", **kwargs)


class DatabricksQueryBuilder(QueryBuilder):
    QUERY_CLS = DatabricksQuery
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.quote_char = "`" # Set default quote_char to backticks

    def get_sql(self, *args, **kwargs) -> str:
        # Databricks uses backticks instead of double quotes etc. 
        kwargs["quote_char"] = self.quote_char
        return super().get_sql(*args, **kwargs)
    
    @builder
    def with_(self, selectable: Selectable, name: str) -> "QueryBuilder":
        # Unlike other  query builders for databricks we need backticks for ctename we cant use double quotes.
        if '"' in name:
            name = name.strip('"')
        t = AliasedQuery(name, selectable)
        self._with.append(t)
    
    def _with_sql(self, **kwargs: Any) -> str:
        return "WITH " + ",".join(
            format_quotes(clause.name, self.quote_char) + " AS (" + clause.get_sql(subquery=False, with_alias=False, **kwargs) + ") "
            for clause in self._with
        )