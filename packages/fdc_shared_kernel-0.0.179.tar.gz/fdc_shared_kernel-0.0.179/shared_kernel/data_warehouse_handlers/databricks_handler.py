from pypika import Query

from shared_kernel.data_warehouse_handlers.connections.databricks_warehouse_connection import DatabricksWarehouseConnection
from shared_kernel.data_warehouse_handlers.custom_query_builders.databricks_query import DatabricksQuery
from shared_kernel.data_warehouse_handlers.query_executors.databricks_query_executor import DatabricksQueryExecutor
from shared_kernel.dataclasses.warehouse_configs import DatabricksConfig
from shared_kernel.interfaces.data_warehouse_handler import WarehouseHandler


# NOTE:
# This handler requires the Databricks CLI to be installed and configured
# in the runtime environment for it to work.
class DatabricksWarehouseHandler(WarehouseHandler):

    def __init__(self, payload: dict = None):
        super().__init__(payload)
        self.set_default_schema = self.payload.get("set_default_schema", True)

    def get_config(self) -> DatabricksConfig:
        source_config: DatabricksConfig = self.payload.get("source_config")
        if source_config and isinstance(source_config, DatabricksConfig):
            return source_config

        required = ("server_hostname", "http_path", "access_token", "catalog")
        missing = [f for f in required if not self.payload.get(f)]
        if missing:
            raise ValueError(
                f"Databricks payload is missing required fields: {missing}."
            )

        return DatabricksConfig(
            server_hostname=str(self.payload.get("server_hostname")).strip(),
            http_path=str(self.payload.get("http_path")).strip(),
            access_token=str(self.payload.get("access_token")).strip(),
            catalog=str(self.payload.get("catalog")).strip(),
            schema=str(self.payload.get("schema")).strip() if self.payload.get("schema") else None,
            schema_list=self.payload.get("schema_list"),
            pagination=self.pagination,
        )

    def _build_connection(self) -> DatabricksWarehouseConnection:
        """Internal — not exposed to callers."""
        return DatabricksWarehouseConnection(
            source_config=self.get_config(),
            set_default_schema=self.set_default_schema,
        )

    def get_executor(self) -> DatabricksQueryExecutor:
        connection = self._build_connection()
        return DatabricksQueryExecutor(warehouse_connection=connection)

    def get_query_object(self) -> Query:
        """Return the PyPika Query builder class."""
        return DatabricksQuery

    def create_records_and_count_query(
        self,
        query: str,
        limit: str,
        page: str,
    ) -> tuple[str, str]:
        count_query = f"SELECT COUNT(*) FROM ({query}) AS _count"

        if limit:
            query = f"{query} LIMIT {int(limit)}"
            if page:
                offset = (int(page) - 1) * int(limit)
                query = f"{query} OFFSET {offset}"

        return count_query, query
    