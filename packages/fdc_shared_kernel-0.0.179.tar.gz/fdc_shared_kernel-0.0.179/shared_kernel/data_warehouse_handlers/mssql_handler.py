from pypika import MSSQLQuery

from shared_kernel.data_warehouse_handlers.connections.mssql_warehouse_connection import (
    MSSQLWarehouseConnection,
)
from shared_kernel.data_warehouse_handlers.query_executors.mssql_query_executor import (
    MSSQLQueryExecutor,
)
from shared_kernel.dataclasses.warehouse_configs import MSSQLConfig
from shared_kernel.interfaces.data_warehouse_handler import WarehouseHandler


class MSSQLWarehouseHandler(WarehouseHandler):

    def __init__(self, payload: dict = None):
        super().__init__(payload)
        self.set_default_schema = self.payload.get("set_default_schema", True)

    def get_config(self) -> MSSQLConfig:
        source_config: MSSQLConfig = self.payload.get("source_config")
        if source_config and isinstance(source_config, MSSQLConfig):
            return source_config

        required = ("host", "user", "password", "database", "port")
        missing = [f for f in required if not self.payload.get(f)]
        if missing:
            raise ValueError(f"MSSQL payload is missing required fields: {missing}.")

        return MSSQLConfig(
            username=str(self.payload.get("user")).strip(),
            password=str(self.payload.get("password")).strip(),
            host=str(self.payload.get("host")).strip(),
            database=str(self.payload.get("database")).strip(),
            port=str(self.payload.get("port")).strip(),
            schema=(
                str(self.payload.get("schema")).strip()
                if self.payload.get("schema")
                else None
            ),
            schema_list=self.payload.get("schema_list"),
            pagination=self.pagination,
        )

    def _build_connection(self) -> MSSQLWarehouseConnection:
        return MSSQLWarehouseConnection(
            source_config=self.get_config(),
            set_default_schema=self.set_default_schema,
        )

    def get_executor(self) -> MSSQLQueryExecutor:
        connection = self._build_connection()
        return MSSQLQueryExecutor(warehouse_connection=connection)

    def get_query_object(self) -> MSSQLQuery:
        return MSSQLQuery

    def create_records_and_count_query(
        self,
        query: str,
        limit: str,
        page: str,
    ) -> tuple[str, str]:
        count_query = f"SELECT COUNT(*) FROM ({query}) AS _count"

        if limit:
            offset = (int(page) - 1) * int(limit) if page else 0
            query = (
                f"{query} "
                f"ORDER BY (SELECT NULL) "
                f"OFFSET {offset} ROWS "
                f"FETCH NEXT {int(limit)} ROWS ONLY"
            )

        return count_query, query
