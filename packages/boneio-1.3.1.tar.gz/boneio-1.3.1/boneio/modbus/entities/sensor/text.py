from __future__ import annotations

import logging

from boneio.const import ID, MODEL, NAME, SENSOR
from boneio.core.config import ConfigHelper
from boneio.core.messaging.basic import MessageBus
from boneio.integration.homeassistant import modbus_sensor_availabilty_message
from boneio.modbus.entities.base import ModbusBaseEntity

_LOGGER = logging.getLogger(__name__)


class ModbusTextSensor(ModbusBaseEntity):

    _entity_type = SENSOR

    def __init__(
        self,
        name: str,
        parent: dict,
        register_address: int,
        base_address: int,
        unit_of_measurement: str | None,
        state_class: str | None,
        device_class: str | None,
        value_type: str | None,
        entity_category: str | None,
        filters: list,
        message_bus: MessageBus,
        config_helper: ConfigHelper,
        value_mapping: dict = None,
        user_filters: list | None = None,
        ha_filter: str = "",
    ) -> None:
        """Initialize single sensor.

        Args:
            name: name of sensor
            parent: parent device info
            register_address: address of register
            base_address: address of base
            unit_of_measurement: unit of measurement
            state_class: state class
            device_class: device class
            value_type: type of value for decoding
            filters: list of filters
            message_bus: message bus instance
            config_helper: config helper instance
            value_mapping: mapping of raw values to text
            user_filters: list of user filters
            ha_filter: HA filter string
        """
        if user_filters is None:
            user_filters = []
        if value_mapping is None:
            value_mapping = {}
        super().__init__(
            name=name,
            parent=parent,
            register_address=register_address,
            base_address=base_address,
            unit_of_measurement=unit_of_measurement,
            state_class=state_class,
            device_class=device_class,
            value_type=value_type,
            entity_category=entity_category,
            filters=filters,
            message_bus=message_bus,
            config_helper=config_helper,
            user_filters=user_filters,
            ha_filter="",
        )
        self._value_mapping = value_mapping

    @property
    def state(self) -> str:
        """Give rounded value of temperature."""
        return self._value or ""

    def set_value(self, value, timestamp: float) -> None:
        self._timestamp = timestamp
        self._value = self._value_mapping.get(str(value), "Unknown")

    def discovery_message(self):
        """Generate Home Assistant discovery message for this entity."""
        kwargs = {
            "value_template": f"{{{{ value_json.{self.decoded_name} }}}}",
        }
        return modbus_sensor_availabilty_message(
            entity_id=self._id,
            entity_name=self.display_name,
            device_id=self._parent[ID],
            device_name=self._parent[NAME],
            state_topic_base=str(self.base_address),
            model=self._parent[MODEL],
            manufacturer=self._parent.get("manufacturer", "boneIO"),
            area=self._parent.get("area"),
            config_helper=self._config_helper,
            has_custom_id=self._parent.get("has_custom_id", False),
            **kwargs,
        )
