"""Manager module - orchestrates all subsystems.

This module provides the main Manager class that coordinates:
- Outputs (relay, switch, light, led, valve)
- Inputs (event, binary_sensor)
- Covers (time-based, previous-state, venetian)
- Sensors (temperature, power, analog)
- Modbus (RTU/TCP devices)
- Display (OLED)
- Templates (thermostat, alarm panel)
"""

from boneio.core.manager.covers import CoverManager
from boneio.core.manager.display import DisplayManager
from boneio.core.manager.inputs import InputManager
from boneio.core.manager.irrigation import IrrigationManager
from boneio.core.manager.modbus import ModbusManager
from boneio.core.manager.outputs import OutputManager
from boneio.core.manager.sensors import SensorManager
from boneio.core.manager.templates import TemplateManager

__all__ = [
    "Manager",
    "OutputManager",
    "InputManager",
    "IrrigationManager",
    "CoverManager",
    "SensorManager",
    "ModbusManager",
    "DisplayManager",
    "TemplateManager",
]

# Import Manager from separate file to avoid circular imports
from boneio.core.manager.manager import Manager  # noqa: E402

__all__.append("Manager")
