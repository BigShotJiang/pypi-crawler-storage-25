# EKS Cluster Composition with Versioned Modules
#
# This file demonstrates:
# 1. Module version pinning via {{key.path}} placeholders
# 2. Runtime interpolation from hierarchical config
# 3. Per-cluster module version control

# VPC Module with versioned source
module "vpc" {
  # Version is resolved from hiera: vpc.module_version
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-vpc.git?ref=v5.1.2"
  
  name = var.config.cluster.fullName
  cidr = var.config.vpc.cidr_block
  
  azs             = var.config.vpc.availability_zones
  private_subnets = var.config.vpc.private_subnets
  public_subnets  = var.config.vpc.public_subnets
  
  enable_nat_gateway   = var.config.vpc.enable_nat_gateway
  single_nat_gateway   = var.config.vpc.single_nat_gateway
  enable_dns_hostnames = true
  enable_dns_support   = true
  
  tags = merge(
    var.config.tags,
    {
      Name = "${var.config.cluster.fullName}-vpc"
    }
  )
}

# EKS Module with versioned source
module "eks" {
  # Version is resolved from hiera: eks.module_version
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-eks.git?ref=v19.16.0"
  
  cluster_name    = var.config.cluster.fullName
  cluster_version = var.config.eks.cluster_version
  
  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets
  
  # Enable IRSA
  enable_irsa = true
  
  # Cluster endpoint access
  cluster_endpoint_public_access  = var.config.eks.endpoint_public_access
  cluster_endpoint_private_access = var.config.eks.endpoint_private_access
  
  # EKS Managed Node Groups
  eks_managed_node_groups = var.config.eks.node_groups
  
  tags = var.config.tags
}

# IAM role for cluster access
module "iam_assumable_role" {
  # Version is resolved from hiera: iam.module_version
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=v5.29.0"
  
  role_name         = "${var.config.cluster.fullName}-admin"
  create_role       = true
  role_requires_mfa = false
  
  trusted_role_arns = var.config.iam.trusted_role_arns
  
  custom_role_policy_arns = [
    "arn:aws:iam::aws:policy/AdministratorAccess"
  ]
  
  tags = var.config.tags
}

