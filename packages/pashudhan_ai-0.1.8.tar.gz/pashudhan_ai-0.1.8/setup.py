import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="pashudhan_ai",
    version="0.1.8",
    author="Pashudhan Nutri AI",
    author_email="api@pashudhan.ai",
    description="Official Python SDK for the Pashudhan Nutri AI API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://pashudhan-nutri-ai.web.app/enterprise",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
)
