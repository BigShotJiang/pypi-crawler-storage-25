# secondopinion-sdk

Official Python SDK for [2ndOpinion](https://get2ndopinion.dev) — AI-to-AI code review where Claude, Codex, and Gemini review your code together.

## Installation

```bash
pip install secondopinion-sdk
```

## Quick Start

```python
from secondopinion import SecondOpinion

client = SecondOpinion(api_key="sk_2op_...")

# Get a code review
result = client.opinion(diff="your git diff here", llm="codex")
print(result["analysis"]["summary"])

# Ask a question
answer = client.ask(question="Is this SQL query safe?", code="SELECT * FROM users WHERE id = " + user_id)
print(answer["response"])

# Check usage
status = client.status()
print(f"Credits: {status['totalAvailable']}")
```

## Available Methods

| Method | Description | Credits |
|--------|-------------|---------|
| `opinion(diff, llm, context)` | Single-model code review | 1 |
| `ask(question, llm, code, context)` | Ask an AI model a question | 1 |
| `review(diff, llm, context)` | Code review (alias for opinion) | 1 |
| `explain(diff, audience)` | Explain changes | 1 |
| `consensus(diff, context)` | 3-model consensus review | 3 |
| `bug_hunt(diff, context)` | 3-model bug detection | 3 |
| `security_audit(diff, context)` | OWASP security scan | 1-3 |
| `generate_tests(diff, llm, framework)` | Generate tests | 1 |
| `status()` | Check account credits | 0 |

## CI/CD Usage

Use in Python scripts for automated pipelines:

```python
import subprocess, json
from secondopinion import SecondOpinion

client = SecondOpinion(api_key=os.environ["SECONDOPINION_API_KEY"])
diff = subprocess.check_output(["git", "diff", "HEAD~1"]).decode()

result = client.opinion(diff=diff, llm="codex")

if result["analysis"]["recommendation"] == "reject":
    print("Code review failed:", result["analysis"]["summary"])
    exit(1)
```

Or use the CLI with `--ci` for JSON output:

```bash
npx 2ndopinion analyze --ci | python -c "import sys,json; print(json.load(sys.stdin)['verdict'])"
```

## Get an API Key

1. Sign up at [get2ndopinion.dev/signup](https://get2ndopinion.dev/signup)
2. Go to [Dashboard > API Keys](https://get2ndopinion.dev/dashboard/keys)
3. Create a key and pass it to the constructor

Free tier includes 5 credits/month. [See all plans](https://get2ndopinion.dev/pricing).

## Links

- [Documentation](https://get2ndopinion.dev/docs)
- [API Reference](https://get2ndopinion.dev/docs/api)
- [Playground](https://get2ndopinion.dev/playground) — try without signing up
- [Pricing](https://get2ndopinion.dev/pricing)
- [Support](mailto:hello@get2ndopinion.dev)
