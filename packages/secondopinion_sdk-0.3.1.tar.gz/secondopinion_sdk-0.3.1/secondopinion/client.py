"""2ndOpinion Python SDK"""

from __future__ import annotations

import time
from typing import Any, AsyncIterator, Optional

import httpx


class SecondOpinionError(Exception):
    """Error from the 2ndOpinion API."""

    def __init__(self, message: str, status: int, code: str):
        super().__init__(message)
        self.status = status
        self.code = code


class SecondOpinion:
    """Client for the 2ndOpinion API.

    Usage::

        client = SecondOpinion(api_key="sk_2op_...")
        result = client.opinion(diff="diff --git a/foo.ts ...")
        print(result["analysis"]["summary"])
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://get2ndopinion.dev",
        timeout: float = 45.0,
        max_retries: int = 2,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Content-Type": "application/json",
                "X-2ndOpinion-Key": self.api_key,
            },
            timeout=self.timeout,
        )

    def _request(self, method: str, path: str, **kwargs: Any) -> dict:
        last_error: Optional[Exception] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = self._client.request(method, path, **kwargs)

                if response.status_code >= 400:
                    body = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
                    error = SecondOpinionError(
                        body.get("error", f"HTTP {response.status_code}"),
                        response.status_code,
                        "RATE_LIMIT" if response.status_code == 429
                        else "INSUFFICIENT_CREDITS" if response.status_code == 402
                        else "FORBIDDEN" if response.status_code == 403
                        else "UNAUTHORIZED" if response.status_code == 401
                        else "API_ERROR",
                    )
                    if response.status_code != 429 and response.status_code < 500:
                        raise error
                    last_error = error
                    continue

                return response.json()

            except SecondOpinionError:
                raise
            except Exception as e:
                last_error = e
                if attempt < self.max_retries:
                    time.sleep(2**attempt)

        raise last_error or Exception("Request failed")

    def opinion(
        self,
        diff: str,
        context: str = "",
        llm: str = "codex",
    ) -> dict:
        """Analyze a git diff for risks and suggestions."""
        return self._request(
            "POST",
            "/api/gateway/opinion",
            json={"diff": diff, "context": context, "llm": llm},
        )

    def review(
        self,
        diff: str,
        context: str = "",
        llm: str = "codex",
    ) -> dict:
        """Detailed code review of a git diff."""
        return self._request(
            "POST",
            "/api/gateway/review",
            json={"diff": diff, "context": context, "llm": llm},
        )

    def ask(
        self,
        question: str,
        context: str = "",
        code: str = "",
        llm: str = "codex",
    ) -> dict:
        """Ask a question about code."""
        return self._request(
            "POST",
            "/api/gateway/ask",
            json={"question": question, "context": context, "code": code, "llm": llm},
        )

    def batch(
        self,
        files: list[dict],
        llm: str = "codex",
    ) -> dict:
        """Analyze multiple files in one request.

        Args:
            files: List of {"file": "path", "diff": "diff content"}
            llm: LLM to use
        """
        return self._request(
            "POST",
            "/api/gateway/batch",
            json={"files": files, "llm": llm},
        )

    def status(self) -> dict:
        """Get account status, usage, and available features."""
        return self._request("GET", "/api/gateway/status")

    def stream(
        self,
        diff: str,
        context: str = "",
        llm: str = "codex",
    ) -> httpx.Response:
        """Stream an analysis response (SSE).

        Returns an httpx Response that can be iterated::

            with client.stream(diff="...") as response:
                for line in response.iter_lines():
                    if line.startswith("data: "):
                        print(line[6:])
        """
        return self._client.stream(
            "POST",
            "/api/gateway/opinion/stream",
            json={"diff": diff, "context": context, "llm": llm},
        )

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
