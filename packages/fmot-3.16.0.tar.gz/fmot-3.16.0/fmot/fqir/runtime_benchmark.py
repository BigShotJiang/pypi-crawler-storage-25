from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import median
from time import perf_counter
from typing import Any, Dict, Iterable, Tuple

import numpy as np


@dataclass
class BackendBenchmarkResult:
    backend: str
    repeat: int
    warmup: int
    total_time_s: float
    avg_time_s: float
    median_time_s: float
    min_time_s: float
    max_time_s: float
    runs_per_second: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RuntimeBenchmarkReport:
    mode: str
    repeat: int
    warmup: int
    backends: Dict[str, BackendBenchmarkResult]
    speedup_vs_python: Dict[str, float | None]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mode": self.mode,
            "repeat": self.repeat,
            "warmup": self.warmup,
            "backends": {
                name: result.to_dict() for name, result in self.backends.items()
            },
            "speedup_vs_python": dict(self.speedup_vs_python),
        }


def _normalize_backends(backends: Iterable[str]) -> Tuple[str, ...]:
    out = tuple(dict.fromkeys(str(backend).lower() for backend in backends))
    if len(out) == 0:
        raise ValueError("Expected at least one backend to benchmark.")
    return out


def _assert_outputs_match(reference, candidate):
    if isinstance(reference, dict):
        assert isinstance(candidate, dict), "Runtime outputs differ in structure."
        assert reference.keys() == candidate.keys(), "Runtime output keys differ."
        for key in reference:
            _assert_outputs_match(reference[key], candidate[key])
        return
    if isinstance(reference, tuple):
        assert isinstance(candidate, tuple), "Runtime outputs differ in structure."
        assert len(reference) == len(
            candidate
        ), "Runtime tuple outputs differ in length."
        for ref_i, cand_i in zip(reference, candidate):
            _assert_outputs_match(ref_i, cand_i)
        return
    np.testing.assert_equal(reference, candidate)


def _benchmark_callable(fn, *, warmup: int, repeat: int) -> BackendBenchmarkResult:
    samples = []
    for _ in range(warmup):
        fn()

    t0 = perf_counter()
    for _ in range(repeat):
        t_run_0 = perf_counter()
        fn()
        samples.append(perf_counter() - t_run_0)
    total_time_s = perf_counter() - t0

    return BackendBenchmarkResult(
        backend="",
        repeat=repeat,
        warmup=warmup,
        total_time_s=total_time_s,
        avg_time_s=total_time_s / repeat,
        median_time_s=median(samples),
        min_time_s=min(samples),
        max_time_s=max(samples),
        runs_per_second=(repeat / total_time_s) if total_time_s > 0 else float("inf"),
    )


def benchmark_graph(
    graph,
    *inputs,
    backends=("python", "cpp"),
    warmup: int = 3,
    repeat: int = 20,
    dequant: bool = False,
    state=None,
    return_dict: bool = False,
    reshape: bool = True,
    verify: bool = True,
) -> RuntimeBenchmarkReport:
    backends = _normalize_backends(backends)
    runtimes = {backend: graph.compile_runtime(backend=backend) for backend in backends}

    if verify:
        reference_backend = backends[0]
        reference_output = runtimes[reference_backend].run(
            *inputs,
            dequant=dequant,
            state=state,
            return_dict=return_dict,
            reshape=reshape,
        )
        for backend in backends[1:]:
            candidate_output = runtimes[backend].run(
                *inputs,
                dequant=dequant,
                state=state,
                return_dict=return_dict,
                reshape=reshape,
            )
            _assert_outputs_match(reference_output, candidate_output)

    results = {}
    for backend in backends:
        runtime = runtimes[backend]

        def run_once():
            runtime.run(
                *inputs,
                dequant=dequant,
                state=state,
                return_dict=return_dict,
                reshape=reshape,
            )

        result = _benchmark_callable(run_once, warmup=warmup, repeat=repeat)
        result.backend = backend
        results[backend] = result

    speedup_vs_python: Dict[str, float | None] = {}
    python_avg = results["python"].avg_time_s if "python" in results else None
    for backend, result in results.items():
        if python_avg is None or backend == "python":
            speedup_vs_python[backend] = None if backend == "python" else None
        else:
            speedup_vs_python[backend] = python_avg / result.avg_time_s

    return RuntimeBenchmarkReport(
        mode="run",
        repeat=repeat,
        warmup=warmup,
        backends=results,
        speedup_vs_python=speedup_vs_python,
    )


def benchmark_graph_batch(
    graph,
    *inputs,
    backends=("python", "cpp"),
    warmup: int = 3,
    repeat: int = 20,
    dequant: bool = False,
    state=None,
    return_dict: bool = False,
    reshape: bool = True,
    verify: bool = True,
    max_workers: int = 1,
) -> RuntimeBenchmarkReport:
    backends = _normalize_backends(backends)
    runtimes = {backend: graph.compile_runtime(backend=backend) for backend in backends}

    if verify:
        reference_backend = backends[0]
        reference_output = runtimes[reference_backend].run_batch(
            *inputs,
            dequant=dequant,
            state=state,
            return_dict=return_dict,
            reshape=reshape,
            max_workers=max_workers,
        )
        for backend in backends[1:]:
            candidate_output = runtimes[backend].run_batch(
                *inputs,
                dequant=dequant,
                state=state,
                return_dict=return_dict,
                reshape=reshape,
                max_workers=max_workers,
            )
            _assert_outputs_match(reference_output, candidate_output)

    results = {}
    for backend in backends:
        runtime = runtimes[backend]

        def run_once():
            runtime.run_batch(
                *inputs,
                dequant=dequant,
                state=state,
                return_dict=return_dict,
                reshape=reshape,
                max_workers=max_workers,
            )

        result = _benchmark_callable(run_once, warmup=warmup, repeat=repeat)
        result.backend = backend
        results[backend] = result

    speedup_vs_python: Dict[str, float | None] = {}
    python_avg = results["python"].avg_time_s if "python" in results else None
    for backend, result in results.items():
        if python_avg is None or backend == "python":
            speedup_vs_python[backend] = None if backend == "python" else None
        else:
            speedup_vs_python[backend] = python_avg / result.avg_time_s

    return RuntimeBenchmarkReport(
        mode="run_batch",
        repeat=repeat,
        warmup=warmup,
        backends=results,
        speedup_vs_python=speedup_vs_python,
    )
