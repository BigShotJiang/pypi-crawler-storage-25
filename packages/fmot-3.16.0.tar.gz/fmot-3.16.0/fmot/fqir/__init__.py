from .variables import TensorProto, TensorSignature
from .nodes.optypes import registry_v1
from .nodes import NodeProto
from .graph_proto import GraphProto
from .runtime_plan import RuntimeGraphPlan
from .runtime_backend import is_runtime_backend_available, register_runtime_backend
from .runtime_benchmark import (
    BackendBenchmarkResult,
    RuntimeBenchmarkReport,
    benchmark_graph,
    benchmark_graph_batch,
)
from .cpp_backend import maybe_register_cpp_backend
from . import variables, nodes, graph_proto, writer
from . import metadata

# keep this to support legacy FQIR format
import sys

sys.setrecursionlimit(10000)

maybe_register_cpp_backend()
