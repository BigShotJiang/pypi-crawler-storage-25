from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any

from .runtime_backend import CompiledGraphRuntime, register_runtime_backend
from .runtime_plan import RuntimeGraphPlan

_CPP_RUNTIME_MODULE_NAME = "fmot.fqir._cpp_runtime"


def load_native_cpp_runtime_module():
    """Load the optional native FQIR runtime module if it is installed."""
    try:
        return importlib.import_module(_CPP_RUNTIME_MODULE_NAME)
    except ModuleNotFoundError:
        return None


@dataclass
class CompiledCppRuntime(CompiledGraphRuntime):
    native_runtime: Any = None
    plan_dict: Any = None

    def __post_init__(self):
        if self.plan_dict is None:
            self.plan_dict = self.plan.to_dict()
        if self.native_runtime is not None and hasattr(
            self.native_runtime, "prepare_plan"
        ):
            self.native_runtime.prepare_plan(self.plan_dict)

    def run(
        self,
        *inputs,
        return_objs: bool = False,
        dequant: bool = False,
        state=None,
        return_dict: bool = False,
        reshape: bool = True,
    ):
        if self.native_runtime is None:
            raise RuntimeError(
                "The native FQIR C++ runtime module is not installed. "
                "Build or install `fmot.fqir._cpp_runtime` to use backend='cpp'."
            )
        if reshape and self.graph.reshaper is not None:
            inputs = tuple(self.graph.reshaper(x) for x in inputs)
        return self.native_runtime.run(
            self.plan_dict,
            inputs,
            return_objs=return_objs,
            dequant=dequant,
            state=state,
            return_dict=return_dict,
        )

    def run_batch(
        self,
        *inputs,
        return_objs: bool = False,
        dequant: bool = False,
        state=None,
        return_dict: bool = False,
        reshape: bool = True,
        max_workers: int = 0,
    ):
        if self.native_runtime is None:
            raise RuntimeError(
                "The native FQIR C++ runtime module is not installed. "
                "Build or install `fmot.fqir._cpp_runtime` to use backend='cpp'."
            )
        if reshape and self.graph.reshaper is not None:
            inputs = tuple(self.graph.reshaper(x) for x in inputs)
        return self.native_runtime.run_batch(
            self.plan_dict,
            inputs,
            return_objs=return_objs,
            dequant=dequant,
            state=state,
            return_dict=return_dict,
            max_workers=max_workers,
        )

    def profile_run(
        self,
        *inputs,
        dequant: bool = False,
        state=None,
        return_dict: bool = False,
        reshape: bool = True,
    ):
        if self.native_runtime is None:
            raise RuntimeError(
                "The native FQIR C++ runtime module is not installed. "
                "Build or install `fmot.fqir._cpp_runtime` to use backend='cpp'."
            )
        if reshape and self.graph.reshaper is not None:
            inputs = tuple(self.graph.reshaper(x) for x in inputs)
        return self.native_runtime.profile_run(
            self.plan_dict,
            inputs,
            dequant=dequant,
            state=state,
            return_dict=return_dict,
        )

    def analyze_loop_vectorization(self):
        def walk(plan, reports):
            subgraphs = plan.get("subgraphs", {})
            for node in plan.get("nodes", []):
                if node["op_name"] != "loop":
                    continue
                report = {
                    "name": node["name"],
                    "subgraph": node.get("subgraph"),
                    "vectorizable": True,
                    "reasons": [],
                    "constants": dict(node.get("constants", {})),
                }
                subplan = subgraphs.get(node.get("subgraph"))
                if subplan is None:
                    report["vectorizable"] = False
                    report["reasons"].append("missing_subgraph")
                    reports.append(report)
                    continue

                constants = node.get("constants", {})
                if int(constants.get("n_recurse", 0)) != 0:
                    report["vectorizable"] = False
                    report["reasons"].append("has_recurrence")

                subgraph_ops = [
                    subnode["op_name"] for subnode in subplan.get("nodes", [])
                ]
                report["subgraph_ops"] = subgraph_ops
                blocked_ops = {
                    op
                    for op in subgraph_ops
                    if op
                    in {
                        "loop",
                        "strided_subgraph",
                        "temporal_unfold",
                        "temporal_conv2d",
                        "assign",
                    }
                }
                if blocked_ops:
                    report["vectorizable"] = False
                    report["reasons"].append(
                        "stateful_subgraph_ops:" + ",".join(sorted(blocked_ops))
                    )

                if (
                    subplan.get("subgraphs")
                    and "INIT" in subplan["subgraphs"]
                    and "ARITH" in subplan["subgraphs"]
                ):
                    report["vectorizable"] = False
                    report["reasons"].append("sequential_subgraph")

                shape_transform_ops = {
                    op for op in subgraph_ops if op in {"reshape", "transpose"}
                }
                if shape_transform_ops:
                    report["vectorizable"] = False
                    report["reasons"].append(
                        "shape_transform_subgraph_ops:"
                        + ",".join(sorted(shape_transform_ops))
                    )

                if (
                    int(constants.get("n_final", 0)) != 0
                    and int(constants.get("n_concat", 0)) == 0
                ):
                    report["reasons"].append("final_outputs_only")

                reports.append(report)

            for subplan in subgraphs.values():
                walk(subplan, reports)

        reports = []
        walk(self.plan_dict, reports)
        return reports

    def analyze_temporal_parallelism(self):
        batch_safe_ops = {
            "vvadd",
            "vvsub",
            "viadd",
            "vimul",
            "vvmul",
            "vneg",
            "relu",
            "gt0",
            "shift",
            "lut",
            "vvgt",
            "vvge",
            "vvlt",
            "vvle",
            "vveq",
            "vigt",
            "vige",
            "vilt",
            "vile",
            "vieq",
            "vvand",
            "vvor",
            "vvxor",
            "viand",
            "vior",
            "vixor",
            "split",
            "chunk",
            "cat",
        }

        def node_is_batch_safe(node):
            op_name = node["op_name"]
            if op_name == "loop":
                return False
            if node.get("subgraph") is not None:
                return False
            return op_name in batch_safe_ops

        def analyze_sequential_plan(plan_name, plan):
            if not (
                plan.get("subgraphs")
                and "INIT" in plan["subgraphs"]
                and "ARITH" in plan["subgraphs"]
            ):
                return None

            arith_plan = plan["subgraphs"]["ARITH"]
            init_plan = plan["subgraphs"]["INIT"]
            parent_input_names = {tensor["name"] for tensor in plan.get("inputs", [])}
            arith_parameter_names = {
                tensor["name"] for tensor in arith_plan.get("parameters", [])
            }
            state_tensor_names = {
                tensor["name"] for tensor in init_plan.get("outputs", [])
            }
            tensor_modes = {}

            for name in arith_parameter_names:
                tensor_modes[name] = "parallel"
            for tensor in arith_plan.get("inputs", []):
                name = tensor["name"]
                if name in parent_input_names:
                    tensor_modes[name] = "parallel"
                elif name in state_tensor_names:
                    tensor_modes[name] = "sequential"
                else:
                    tensor_modes[name] = "sequential"

            node_reports = []
            for idx, node in enumerate(arith_plan.get("nodes", [])):
                input_modes = {
                    port: tensor_modes.get(tensor_name, "sequential")
                    for port, tensor_name in node.get("inputs", {}).items()
                }
                batch_safe = node_is_batch_safe(node)
                mode = (
                    "parallel"
                    if batch_safe
                    and all(mode != "sequential" for mode in input_modes.values())
                    else "sequential"
                )
                for out_name in node.get("outputs", []):
                    tensor_modes[out_name] = mode
                node_reports.append(
                    {
                        "index": idx,
                        "name": node["name"],
                        "op_name": node["op_name"],
                        "mode": mode,
                        "batch_safe": batch_safe,
                        "input_modes": input_modes,
                    }
                )

            spans = []
            current = None
            for node in node_reports:
                if node["mode"] != "parallel":
                    if current is not None:
                        spans.append(current)
                        current = None
                    continue
                if current is None or node["index"] != current["end_index"] + 1:
                    if current is not None:
                        spans.append(current)
                    current = {
                        "start_index": node["index"],
                        "end_index": node["index"],
                        "node_names": [node["name"]],
                        "op_names": [node["op_name"]],
                    }
                else:
                    current["end_index"] = node["index"]
                    current["node_names"].append(node["name"])
                    current["op_names"].append(node["op_name"])
            if current is not None:
                spans.append(current)

            return {
                "plan_name": plan_name,
                "has_sequential_structure": True,
                "parallel_node_count": sum(
                    node["mode"] == "parallel" for node in node_reports
                ),
                "sequential_node_count": sum(
                    node["mode"] == "sequential" for node in node_reports
                ),
                "parallel_spans": spans,
                "node_reports": node_reports,
            }

        reports = []

        def walk(plan_name, plan):
            report = analyze_sequential_plan(plan_name, plan)
            if report is not None:
                reports.append(report)
            for subplan_name, subplan in plan.get("subgraphs", {}).items():
                walk(subplan_name, subplan)

        walk(self.plan_dict.get("name", "main"), self.plan_dict)
        return reports


def create_cpp_runtime(graph, plan: RuntimeGraphPlan) -> CompiledCppRuntime:
    native_runtime = load_native_cpp_runtime_module()
    return CompiledCppRuntime(
        graph=graph,
        backend="cpp",
        plan=plan,
        native_runtime=native_runtime,
    )


def maybe_register_cpp_backend():
    if load_native_cpp_runtime_module() is None:
        return False
    register_runtime_backend("cpp", create_cpp_runtime)
    return True
