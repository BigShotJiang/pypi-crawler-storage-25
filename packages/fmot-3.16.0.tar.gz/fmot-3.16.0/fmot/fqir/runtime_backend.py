from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict

from .graph_proto.graph_runtime import run_graph, run_sequential_graph
from .runtime_plan import RuntimeGraphPlan, graph_to_runtime_plan


BackendFactory = Callable[[Any, RuntimeGraphPlan], "CompiledGraphRuntime"]
_BACKEND_FACTORIES: Dict[str, BackendFactory] = {}


def _normalize_backend(backend: str) -> str:
    backend = backend.lower()
    valid_backends = {"python", "cpp"}
    if backend not in valid_backends:
        raise ValueError(
            f"Unknown FQIR runtime backend {backend!r}. "
            f"Expected one of {sorted(valid_backends)}."
        )
    return backend


def _run_graph_python_backend(
    graph,
    *inputs,
    return_objs: bool = False,
    dequant: bool = False,
    state=None,
    return_dict: bool = False,
):
    if "INIT" in graph.subgraphs:
        return run_sequential_graph(
            graph,
            *inputs,
            return_objs=return_objs,
            dequant=dequant,
            objs=state,
            return_dict=return_dict,
        )
    return run_graph(
        graph,
        *inputs,
        return_objs=return_objs,
        dequant=dequant,
        objs=state,
        return_dict=return_dict,
    )


@dataclass
class CompiledGraphRuntime:
    graph: Any
    backend: str
    plan: RuntimeGraphPlan

    def run(
        self,
        *inputs,
        return_objs: bool = False,
        dequant: bool = False,
        state=None,
        return_dict: bool = False,
        reshape: bool = True,
    ):
        if reshape and self.graph.reshaper is not None:
            inputs = tuple(self.graph.reshaper(x) for x in inputs)

        if self.backend == "python":
            return _run_graph_python_backend(
                self.graph,
                *inputs,
                return_objs=return_objs,
                dequant=dequant,
                state=state,
                return_dict=return_dict,
            )

        raise RuntimeError(
            "The FQIR C++ runtime backend is not available yet in this build. "
            "Use backend='python' for now."
        )

    def run_batch(
        self,
        *inputs,
        return_objs: bool = False,
        dequant: bool = False,
        state=None,
        return_dict: bool = False,
        reshape: bool = True,
        max_workers: int = 0,
    ):
        if self.backend == "python":
            return self.graph._run_batch_python_backend(
                *inputs,
                return_objs=return_objs,
                dequant=dequant,
                state=state,
                return_dict=return_dict,
                reshape=reshape,
                max_workers=max_workers,
            )

        raise RuntimeError(
            "The FQIR C++ runtime backend is not available yet in this build. "
            "Use backend='python' for now."
        )


def register_runtime_backend(name: str, factory: BackendFactory):
    _BACKEND_FACTORIES[_normalize_backend(name)] = factory


def is_runtime_backend_available(name: str) -> bool:
    backend = _normalize_backend(name)
    if backend == "python":
        return True
    if backend == "cpp" and backend not in _BACKEND_FACTORIES:
        from .cpp_backend import maybe_register_cpp_backend

        maybe_register_cpp_backend()
    return backend in _BACKEND_FACTORIES


def compile_runtime(graph, backend: str = "python") -> CompiledGraphRuntime:
    backend = _normalize_backend(backend)
    plan = graph_to_runtime_plan(graph)
    if backend == "cpp" and backend not in _BACKEND_FACTORIES:
        from .cpp_backend import maybe_register_cpp_backend

        maybe_register_cpp_backend()
    if backend != "python" and backend in _BACKEND_FACTORIES:
        return _BACKEND_FACTORIES[backend](graph, plan)
    return CompiledGraphRuntime(graph=graph, backend=backend, plan=plan)
