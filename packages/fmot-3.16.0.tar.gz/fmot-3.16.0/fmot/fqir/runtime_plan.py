from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np


def _normalize_scalar(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    return value


def normalize_runtime_value(value: Any) -> Any:
    """Convert runtime metadata to a JSON-friendly Python representation."""
    value = _normalize_scalar(value)

    if isinstance(value, np.ndarray):
        return {
            "kind": "ndarray",
            "dtype": str(value.dtype),
            "shape": list(value.shape),
            "data": value.tolist(),
        }
    if isinstance(value, type):
        return {"kind": "type", "name": value.__name__}
    if isinstance(value, np.dtype):
        return {"kind": "dtype", "name": str(value)}
    if isinstance(value, tuple):
        return [normalize_runtime_value(v) for v in value]
    if isinstance(value, list):
        return [normalize_runtime_value(v) for v in value]
    if isinstance(value, dict):
        return {str(k): normalize_runtime_value(v) for k, v in value.items()}
    return value


def denormalize_runtime_value(value: Any) -> Any:
    """Reconstruct normalized runtime metadata from Python containers."""
    if isinstance(value, list):
        return [denormalize_runtime_value(v) for v in value]

    if isinstance(value, dict):
        kind = value.get("kind")
        if kind == "ndarray":
            return np.array(value["data"], dtype=value["dtype"])
        if kind == "type":
            type_name = value["name"]
            builtin_types = {
                "int": int,
                "float": float,
                "bool": bool,
                "str": str,
            }
            return builtin_types.get(type_name, type_name)
        if kind == "dtype":
            return np.dtype(value["name"])
        return {k: denormalize_runtime_value(v) for k, v in value.items()}

    return value


@dataclass
class RuntimeTensor:
    name: str
    dtype: Any
    shape: List[int]
    quanta: Optional[int] = None
    is_bool: bool = False
    has_value: bool = False
    value: Optional[Any] = None
    roles: List[str] = field(default_factory=list)
    avg_sparsity: Optional[float] = None
    named_dims: Optional[Any] = None


@dataclass
class RuntimeNode:
    name: str
    op_name: Optional[str]
    inputs: Dict[str, str]
    outputs: List[str]
    constants: Dict[str, Any] = field(default_factory=dict)
    subgraph: Optional[str] = None


@dataclass
class RuntimeGraphPlan:
    name: str
    unbind_dim: Optional[int]
    stack_dim: Optional[int]
    inputs: List[RuntimeTensor]
    outputs: List[RuntimeTensor]
    parameters: List[RuntimeTensor]
    nodes: List[RuntimeNode]
    subgraphs: Dict[str, "RuntimeGraphPlan"] = field(default_factory=dict)
    version: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RuntimeGraphPlan":
        def load_tensor(tensor: Dict[str, Any]) -> RuntimeTensor:
            return RuntimeTensor(
                name=tensor["name"],
                dtype=denormalize_runtime_value(tensor["dtype"]),
                shape=tensor["shape"],
                quanta=tensor["quanta"],
                is_bool=tensor["is_bool"],
                has_value=tensor["has_value"],
                value=denormalize_runtime_value(tensor["value"]),
                roles=tensor["roles"],
                avg_sparsity=tensor["avg_sparsity"],
                named_dims=denormalize_runtime_value(tensor["named_dims"]),
            )

        return cls(
            name=data["name"],
            unbind_dim=data["unbind_dim"],
            stack_dim=data["stack_dim"],
            inputs=[load_tensor(tensor) for tensor in data["inputs"]],
            outputs=[load_tensor(tensor) for tensor in data["outputs"]],
            parameters=[load_tensor(tensor) for tensor in data["parameters"]],
            nodes=[
                RuntimeNode(
                    name=node["name"],
                    op_name=node["op_name"],
                    inputs=node["inputs"],
                    outputs=node["outputs"],
                    constants=denormalize_runtime_value(node["constants"]),
                    subgraph=node["subgraph"],
                )
                for node in data["nodes"]
            ],
            subgraphs={
                name: cls.from_dict(subgraph)
                for name, subgraph in data.get("subgraphs", {}).items()
            },
            version=data.get("version", 1),
        )

    def to_json(self, path: str | Path, *, indent: int = 2):
        Path(path).write_text(
            json.dumps(self.to_dict(), indent=indent), encoding="utf-8"
        )

    @classmethod
    def from_json(cls, path: str | Path) -> "RuntimeGraphPlan":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(data)


def _tensor_roles(graph, tensor) -> List[str]:
    roles = []
    if tensor in graph.inputs:
        roles.append("input")
    if tensor in graph.outputs:
        roles.append("output")
    if tensor in graph.parameters:
        roles.append("parameter")
    return roles


def _tensor_to_runtime_tensor(graph, tensor) -> RuntimeTensor:
    return RuntimeTensor(
        name=tensor.name,
        dtype=normalize_runtime_value(tensor.dtype),
        shape=list(tensor.shape),
        quanta=tensor.quanta,
        is_bool=getattr(tensor, "is_bool", False),
        has_value=tensor.value is not None,
        value=normalize_runtime_value(tensor.value),
        roles=_tensor_roles(graph, tensor),
        avg_sparsity=_normalize_scalar(tensor.avg_sparsity),
        named_dims=normalize_runtime_value(tensor.named_dims),
    )


def _make_runtime_parameter(name: str, value: Any) -> RuntimeTensor:
    value_arr = np.asarray(value)
    return RuntimeTensor(
        name=name,
        dtype=normalize_runtime_value(value_arr.dtype),
        shape=list(value_arr.shape),
        quanta=None,
        is_bool=False,
        has_value=True,
        value=normalize_runtime_value(value_arr),
        roles=["parameter"],
        avg_sparsity=None,
        named_dims=None,
    )


def _collect_runtime_subgraphs(graph) -> Dict[str, RuntimeGraphPlan]:
    subplans: Dict[str, RuntimeGraphPlan] = {}

    for name, subgraph in graph.subgraphs.items():
        subplans[name] = graph_to_runtime_plan(subgraph)

    for node in graph.nodes:
        if node.subgraph is not None and node.subgraph.name not in subplans:
            subplans[node.subgraph.name] = graph_to_runtime_plan(node.subgraph)

    return subplans


def graph_to_runtime_plan(graph) -> RuntimeGraphPlan:
    parameters = [
        _tensor_to_runtime_tensor(graph, tensor) for tensor in graph.parameters
    ]
    nodes = []
    for node in graph.nodes:
        node_inputs = {
            arg_name: tensor.name for arg_name, tensor in node.inputs.items()
        }
        node_constants = dict(node.constants)

        if (
            node.optype is not None
            and node.optype.name == "lut"
            and "table" in node_constants
        ):
            table = node_constants.pop("table")
            if len(node.outputs) == 0:
                table_values_name = f"{node.name or 'lut'}.table_values"
            else:
                table_values_name = f"{node.outputs[0].name}.table_values"
            node_inputs["table_values"] = table_values_name
            parameters.append(
                _make_runtime_parameter(table_values_name, np.asarray(table.y))
            )
            node_constants["table_min"] = _normalize_scalar(np.min(table.x))

        nodes.append(
            RuntimeNode(
                name=node.name,
                op_name=None if node.optype is None else node.optype.name,
                inputs=node_inputs,
                outputs=[tensor.name for tensor in node.outputs],
                constants=normalize_runtime_value(node_constants),
                subgraph=None if node.subgraph is None else node.subgraph.name,
            )
        )

    return RuntimeGraphPlan(
        name=graph.name,
        unbind_dim=graph.unbind_dim,
        stack_dim=graph.stack_dim,
        inputs=[_tensor_to_runtime_tensor(graph, tensor) for tensor in graph.inputs],
        outputs=[_tensor_to_runtime_tensor(graph, tensor) for tensor in graph.outputs],
        parameters=parameters,
        nodes=nodes,
        subgraphs=_collect_runtime_subgraphs(graph),
    )
