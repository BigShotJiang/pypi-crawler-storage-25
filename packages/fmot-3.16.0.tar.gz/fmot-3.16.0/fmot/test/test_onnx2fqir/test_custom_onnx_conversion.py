from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile

import numpy as np
import onnx
import onnxruntime as ort
import pytest
import tensorflow as tf
from onnxruntime.quantization import CalibrationDataReader

from fmot.onnx2fqir.converters import (
    convert_streaming_tdnn_to_fqir,
    convert_tdnn_tflite_to_onnx,
    quantize_to_QOperator,
)


TEST_DIR = Path(__file__).resolve().parent
SAVED_KERAS_MODEL = TEST_DIR / "model_keras.h5"


@dataclass(frozen=True)
class CustomConversionAsset:
    name: str
    tflite_path: Path
    input_shape: tuple[int, ...]
    runtime_rel_error_tol: float = 1e-5
    runtime_max_abs_error_tol: float = 1e-5
    fqir_rel_error_tol: float = 0.15


CUSTOM_CONVERSION_ASSETS = [
    CustomConversionAsset(
        name="user_example_conv1d_output",
        tflite_path=TEST_DIR / "user_example_conv1d_output.tflite",
        input_shape=(1, 120, 40),
    ),
]


def _run_tflite_model(model_path: Path, x: np.ndarray) -> np.ndarray:
    interpreter = tf.lite.Interpreter(
        model_path=str(model_path),
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]
    interpreter.set_tensor(input_detail["index"], x)
    interpreter.invoke()
    return interpreter.get_tensor(output_detail["index"])


def _run_tflite_model_content(model_content: bytes, x: np.ndarray) -> np.ndarray:
    interpreter = tf.lite.Interpreter(
        model_content=model_content,
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]
    interpreter.set_tensor(input_detail["index"], x)
    interpreter.invoke()
    return interpreter.get_tensor(output_detail["index"])


def _run_onnx_model(model_path: Path, x: np.ndarray) -> np.ndarray:
    session = ort.InferenceSession(str(model_path))
    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name
    return session.run([output_name], {input_name: x})[0]


class _CalibrationReader(CalibrationDataReader):
    def __init__(self, *, input_name: str, input_shape: tuple[int, ...], seed: int = 0):
        self._rng = np.random.default_rng(seed)
        self._samples = iter(
            [
                {input_name: self._rng.standard_normal(input_shape, dtype=np.float32)}
                for _ in range(8)
            ]
        )

    def get_next(self) -> dict[str, np.ndarray] | None:
        return next(self._samples, None)


@pytest.mark.parametrize(
    "asset",
    CUSTOM_CONVERSION_ASSETS,
    ids=[asset.name for asset in CUSTOM_CONVERSION_ASSETS],
)
def test_tflite_file_can_be_converted_to_onnx_and_runtime_matches(
    asset: CustomConversionAsset,
):
    rng = np.random.default_rng(0)
    onnx_model = convert_tdnn_tflite_to_onnx(model_path=str(asset.tflite_path))

    relative_errors = []
    max_abs_errors = []

    with NamedTemporaryFile(suffix=".onnx") as temp:
        onnx.save(onnx_model, temp.name)

        for _ in range(5):
            sample_input = rng.standard_normal(asset.input_shape, dtype=np.float32)
            tflite_output = _run_tflite_model(asset.tflite_path, sample_input)
            onnx_output = _run_onnx_model(Path(temp.name), sample_input)

            mse = np.mean((tflite_output - onnx_output) ** 2)
            denom = max(np.mean(tflite_output**2), 1e-12)
            relative_errors.append(np.sqrt(mse / denom))
            max_abs_errors.append(np.max(np.abs(tflite_output - onnx_output)))

    assert max(relative_errors) < asset.runtime_rel_error_tol
    assert max(max_abs_errors) < asset.runtime_max_abs_error_tol


@pytest.mark.parametrize(
    "asset",
    CUSTOM_CONVERSION_ASSETS,
    ids=[asset.name for asset in CUSTOM_CONVERSION_ASSETS],
)
def test_converted_onnx_graph_can_be_quantized_to_qoperator(
    asset: CustomConversionAsset,
):
    onnx_model = convert_tdnn_tflite_to_onnx(model_path=str(asset.tflite_path))
    input_name = onnx_model.graph.input[0].name

    with NamedTemporaryFile(suffix=".onnx") as temp:
        quantize_to_QOperator(
            model_input=onnx_model,
            model_output=temp.name,
            calibration_data_reader=_CalibrationReader(
                input_name=input_name,
                input_shape=asset.input_shape,
            ),
        )

        quantized_model = onnx.load(temp.name)
        quantized_op_types = [node.op_type for node in quantized_model.graph.node]

        assert "QLinearConv" in quantized_op_types
        assert any(
            op_type in quantized_op_types
            for op_type in {"QLinearAdd", "QLinearMul", "QLinearSoftmax"}
        )

        session = ort.InferenceSession(temp.name)
        assert session.get_inputs()
        assert session.get_outputs()


@pytest.mark.parametrize(
    "asset",
    CUSTOM_CONVERSION_ASSETS,
    ids=[asset.name for asset in CUSTOM_CONVERSION_ASSETS],
)
def test_quantized_custom_onnx_graph_can_be_converted_to_fqir(
    asset: CustomConversionAsset,
):
    onnx_model = convert_tdnn_tflite_to_onnx(model_path=str(asset.tflite_path))
    input_name = onnx_model.graph.input[0].name

    with NamedTemporaryFile(suffix=".onnx") as temp:
        quantize_to_QOperator(
            model_input=onnx_model,
            model_output=temp.name,
            calibration_data_reader=_CalibrationReader(
                input_name=input_name,
                input_shape=asset.input_shape,
            ),
        )

        quantized_model = onnx.load(temp.name)
        cstate = convert_streaming_tdnn_to_fqir(
            quantized_model,
            batch_dim=0,
            seq_dim=1,
            feature_dim=2,
            options=["conv1d_via_unfold", "allow_pad_dqq_noop"],
        )
        assert cstate is not None


@pytest.mark.parametrize(
    "asset",
    CUSTOM_CONVERSION_ASSETS,
    ids=[asset.name for asset in CUSTOM_CONVERSION_ASSETS],
)
def test_fqir_runtime_matches_quantized_onnx_runtime(
    asset: CustomConversionAsset,
):
    rng = np.random.default_rng(0)
    onnx_model = convert_tdnn_tflite_to_onnx(model_path=str(asset.tflite_path))
    input_name = onnx_model.graph.input[0].name

    with NamedTemporaryFile(suffix=".onnx") as temp:
        quantize_to_QOperator(
            model_input=onnx_model,
            model_output=temp.name,
            calibration_data_reader=_CalibrationReader(
                input_name=input_name,
                input_shape=asset.input_shape,
            ),
        )

        quantized_model = onnx.load(temp.name)
        cstate = convert_streaming_tdnn_to_fqir(
            quantized_model,
            batch_dim=0,
            seq_dim=1,
            feature_dim=2,
            options=["conv1d_via_unfold", "allow_pad_dqq_noop"],
        )

        relative_errors = []

        for _ in range(5):
            sample_input = rng.standard_normal(asset.input_shape, dtype=np.float32)
            onnx_output = _run_onnx_model(Path(temp.name), sample_input)

            (x_quant,) = cstate.quantize_inputs([sample_input[0]])
            fqir_output = cstate.fqir.run(x_quant)
            (fqir_output,) = cstate.dequantize_outputs([fqir_output])

            # The streaming FQIR conversion adds temporal padding internally.
            fqir_output = fqir_output[cstate.receptive_field :]

            mse = np.mean((fqir_output - onnx_output[0]) ** 2)
            denom = max(np.mean(onnx_output[0] ** 2), 1e-12)
            relative_errors.append(np.sqrt(mse / denom))

        assert max(relative_errors) < asset.fqir_rel_error_tol
        print(relative_errors)


def test_saved_keras_h5_tflite_conversion_matches_onnx_runtime():
    model = tf.keras.models.load_model(SAVED_KERAS_MODEL, compile=False)
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    tflite_model = converter.convert()
    onnx_model = convert_tdnn_tflite_to_onnx(model_content=tflite_model)

    rng = np.random.default_rng(0)
    relative_errors = []
    max_abs_errors = []

    with NamedTemporaryFile(suffix=".onnx") as temp:
        onnx.save(onnx_model, temp.name)

        for _ in range(5):
            sample_input = rng.standard_normal((1, 100, 40), dtype=np.float32)
            tflite_output = _run_tflite_model_content(tflite_model, sample_input)
            onnx_output = _run_onnx_model(Path(temp.name), sample_input)

            mse = np.mean((tflite_output - onnx_output) ** 2)
            denom = max(np.mean(tflite_output**2), 1e-12)
            relative_errors.append(np.sqrt(mse / denom))
            max_abs_errors.append(np.max(np.abs(tflite_output - onnx_output)))

    assert max(relative_errors) < 1e-5
    assert max(max_abs_errors) < 1e-5


if __name__ == "__main__":
    test_quantized_custom_onnx_graph_can_be_converted_to_fqir(
        asset=CUSTOM_CONVERSION_ASSETS[0]
    )
    test_fqir_runtime_matches_quantized_onnx_runtime(asset=CUSTOM_CONVERSION_ASSETS[0])
