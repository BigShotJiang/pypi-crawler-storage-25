from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

import numpy as np
import onnx
import onnxruntime as ort
import pytest
import tensorflow as tf

from fmot.onnx2fqir.main import (
    convert_tdnn_to_cstate,
    convert_tdnn_to_onnx,
    quantize_tdnn_onnx,
)
from fmot.onnx2fqir.tflite_patterns import analyze_dilated_conv1d_tflite_patterns

TEST_DIR = Path(__file__).resolve().parent
FAILURE_DUMP_DIR = TEST_DIR / "failed_main_api_roundtrip_graphs"
SAVED_KERAS_MODEL = TEST_DIR / "model_keras.h5"
TF2ONNX_XFAIL = pytest.mark.xfail(
    reason="tf2onnx conversion path is deprecated and produces unstable quantized graphs",
    strict=False,
)


@dataclass(frozen=True)
class MainAPITestCase:
    name: str
    source_format: str
    input_shape: tuple[int, ...]
    source_factory: object
    conversion_backend: str = "auto"
    fqir_rel_error_tol: float = 0.15
    marks: Any = ()


def create_keras_tdnn_batchnorm_model():
    input_layer = tf.keras.Input(shape=(10, 4), name="input")
    x = tf.keras.layers.Conv1D(
        filters=6,
        kernel_size=3,
        padding="valid",
        use_bias=False,
    )(input_layer)
    x = tf.keras.layers.BatchNormalization()(x)
    return tf.keras.Model(inputs=input_layer, outputs=x)


def create_doc_example_model():
    input_layer = tf.keras.Input(shape=(10, 16), name="input")
    x = input_layer
    for _ in range(2):
        x = tf.keras.layers.Conv1D(
            filters=32,
            kernel_size=3,
            padding="valid",
            use_bias=True,
            activation="relu",
            bias_initializer=tf.keras.initializers.RandomUniform(
                minval=-0.1, maxval=0.1, seed=None
            ),
        )(x)
    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(10, activation="softmax")(x)
    return tf.keras.Model(inputs=input_layer, outputs=x)


def create_custom_rewriter_tdnn_model(final_act="softmax", use_bias=True):
    input_layer = tf.keras.Input(shape=(10, 16), name="input")
    x = input_layer

    for _ in range(2):
        x = tf.keras.layers.Conv1D(
            filters=32,
            kernel_size=3,
            padding="valid",
            use_bias=use_bias,
            activation="relu",
            bias_initializer=tf.keras.initializers.RandomUniform(
                minval=-0.1, maxval=0.1, seed=None
            ),
        )(x)

    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(10, activation=final_act)(x)
    return tf.keras.Model(inputs=input_layer, outputs=x)


def create_custom_rewriter_tdnn_mixed_bias_model(final_act="softmax", use_bias=True):
    input_layer = tf.keras.Input(shape=(10, 16), name="input")

    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=use_bias,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
    )(input_layer)
    x = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=3,
        padding="valid",
        use_bias=not use_bias,
        activation="relu",
        bias_initializer=tf.keras.initializers.RandomUniform(
            minval=-0.1, maxval=0.1, seed=None
        ),
    )(x)

    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(10, activation=final_act)(x)
    return tf.keras.Model(inputs=input_layer, outputs=x)


def freeze_batchnorm_statistics(model: tf.keras.Model) -> tf.keras.Model:
    warmup_shape = [8] + list(model.input_shape[1:])
    for _ in range(10):
        _ = model(np.random.rand(*warmup_shape).astype(np.float32), training=True)
    for layer in model.layers:
        if isinstance(layer, tf.keras.layers.BatchNormalization):
            layer.trainable = False
    return model


def export_tflite_model(model: tf.keras.Model) -> bytes:
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    return converter.convert()


def load_keras_model_for_debug(source: object) -> tf.keras.Model:
    if isinstance(source, tf.keras.Model):
        return source
    if isinstance(source, (str, Path)):
        return tf.keras.models.load_model(source, compile=False)
    raise TypeError(f"Cannot load {type(source).__name__} as a Keras model")


def run_onnx_model(model_path: Path, x: np.ndarray) -> np.ndarray:
    session = ort.InferenceSession(str(model_path))
    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name
    return session.run([output_name], {input_name: x})[0]


def describe_source(source: object) -> str:
    if isinstance(source, tf.keras.Model):
        return (
            f"tf.keras.Model(name={source.name!r}, "
            f"input_shape={source.input_shape}, output_shape={source.output_shape})"
        )
    if isinstance(source, (str, Path)):
        path = Path(source)
        if path.exists():
            return f"path={path} size_bytes={path.stat().st_size}"
        return f"path={path} missing"
    return f"{type(source).__name__}"


def describe_onnx_value_info(value_info: onnx.ValueInfoProto) -> str:
    tensor_type = value_info.type.tensor_type
    dims = []
    for dim in tensor_type.shape.dim:
        if dim.dim_value:
            dims.append(str(dim.dim_value))
        elif dim.dim_param:
            dims.append(dim.dim_param)
        else:
            dims.append("?")
    return f"{value_info.name}[{', '.join(dims)}]"


def describe_onnx_model(model: onnx.ModelProto) -> str:
    op_counts = Counter(node.op_type for node in model.graph.node)
    ops = ", ".join(f"{op}:{count}" for op, count in sorted(op_counts.items()))
    inputs = ", ".join(describe_onnx_value_info(value) for value in model.graph.input)
    outputs = ", ".join(describe_onnx_value_info(value) for value in model.graph.output)
    return (
        f"nodes={len(model.graph.node)} initializers={len(model.graph.initializer)} "
        f"inputs=({inputs}) outputs=({outputs}) ops=({ops})"
    )


def dump_onnx_graph_for_failure(
    case_name: str,
    graph_name: str,
    onnx_model: onnx.ModelProto,
) -> Path:
    FAILURE_DUMP_DIR.mkdir(parents=True, exist_ok=True)
    safe_case_name = case_name.replace("/", "_").replace(" ", "_")
    safe_graph_name = graph_name.replace("/", "_").replace(" ", "_")
    path = FAILURE_DUMP_DIR / f"{safe_case_name}.{safe_graph_name}.onnx"
    onnx.save(onnx_model, path)
    return path


def dump_tflite_model_for_failure(case_name: str, tflite_model: bytes) -> Path:
    FAILURE_DUMP_DIR.mkdir(parents=True, exist_ok=True)
    safe_case_name = case_name.replace("/", "_").replace(" ", "_")
    path = FAILURE_DUMP_DIR / f"{safe_case_name}.materialized.tflite"
    path.write_bytes(tflite_model)
    return path


def describe_tflite_model(tflite_model: bytes) -> str:
    analysis = analyze_dilated_conv1d_tflite_patterns(model_content=tflite_model)
    ops = " -> ".join(
        f"{index}:{op_name}" for index, op_name in enumerate(analysis["all_op_names"])
    )
    matches = []
    for match in analysis["pattern_matches"]:
        match_ops = " -> ".join(op.get("op_name", "?") for op in match.get("ops", []))
        dilation = match.get("dilation", "?")
        matches.append(
            f"{match.get('match_start_op_index', '?')}"
            f"..{match.get('match_end_op_index', '?')}"
            f" dilation={dilation} ops={match_ops}"
        )
    match_summary = "; ".join(matches) if matches else "none"
    return f"ops={ops}; dilated_conv1d_matches={match_summary}"


def dump_tflite_debug_for_failure(case: MainAPITestCase, source: object) -> str:
    if not (
        case.source_format == "keras" and case.conversion_backend == "keras_via_tflite"
    ):
        return ""

    try:
        keras_model = load_keras_model_for_debug(source)
        tflite_model = export_tflite_model(keras_model)
        tflite_path = dump_tflite_model_for_failure(case.name, tflite_model)
        try:
            print(f"[roundtrip tflite] {describe_tflite_model(tflite_model)}")
        except Exception as exc:
            return (
                f" Saved materialized TFLite to {tflite_path}. "
                f"TFLite summary failed: {exc!r}."
            )
        return f" Saved materialized TFLite to {tflite_path}."
    except Exception as exc:
        return f" TFLite debug dump also failed: {exc!r}."


def dump_intermediate_onnx_graphs_for_failure(
    case_name: str,
    onnx_model: onnx.ModelProto,
    quantized_onnx_model: onnx.ModelProto,
) -> tuple[Path, Path]:
    FAILURE_DUMP_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = case_name.replace("/", "_").replace(" ", "_")
    fp_path = FAILURE_DUMP_DIR / f"{safe_name}.onnx"
    quant_path = FAILURE_DUMP_DIR / f"{safe_name}.qoperator.onnx"
    onnx.save(onnx_model, fp_path)
    onnx.save(quantized_onnx_model, quant_path)
    return fp_path, quant_path


def model_v3_0(
    num_class,
    feat_dim=40,
    convert_wav_to_fbank=False,
    num_frame=None,
    sample_rate=16000,
):
    tdnn1 = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=8,
        dilation_rate=1,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn1",
    )
    tdnn1_bn = tf.keras.layers.BatchNormalization(name="tdnn1_bn")
    tdnn2 = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=5,
        dilation_rate=2,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn2",
    )
    tdnn2_bn = tf.keras.layers.BatchNormalization(name="tdnn2_bn")
    tdnn3 = tf.keras.layers.Conv1D(
        filters=32,
        kernel_size=5,
        dilation_rate=5,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn3",
    )
    tdnn3_bn = tf.keras.layers.BatchNormalization(name="tdnn3_bn")
    tdnn4 = tf.keras.layers.Conv1D(
        filters=16,
        kernel_size=5,
        dilation_rate=5,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn4",
    )
    tdnn4_bn = tf.keras.layers.BatchNormalization(name="tdnn4_bn")
    tdnn5 = tf.keras.layers.Conv1D(
        filters=16,
        kernel_size=12,
        dilation_rate=4,
        activation="relu",
        kernel_initializer="glorot_normal",
        use_bias=True,
        padding="valid",
        name="tdnn5",
    )
    tdnn5_bn = tf.keras.layers.BatchNormalization(name="tdnn5_bn")
    if convert_wav_to_fbank:
        raise NotImplementedError("MelFilterBank")
        # input = tf.keras.Input(shape=(num_frame,), name='input_sample')
        # x = MelFilterBank(feat_dim, name='mel_filterbank_layer')(input)
        # x = tf.squeeze(x, axis=-1)
    else:
        input = tf.keras.Input(shape=(num_frame, feat_dim), name="input")
        x = input
    x = tdnn1_bn(tdnn1(x))
    x = tdnn2_bn(tdnn2(x))
    x = tdnn3_bn(tdnn3(x))
    x = tdnn4_bn(tdnn4(x))
    x = tdnn5_bn(tdnn5(x))
    e2e_out = tf.keras.layers.Dense(
        num_class, activation="softmax", use_bias=False, name="e2e_out"
    )(x)
    model = tf.keras.Model(inputs=input, outputs=e2e_out)
    return model


MAIN_API_TEST_CASES = [
    MainAPITestCase(
        name="batchnorm_keras",
        source_format="keras",
        conversion_backend="keras_tf2onnx",
        input_shape=(1, 10, 4),
        source_factory=lambda: freeze_batchnorm_statistics(
            create_keras_tdnn_batchnorm_model()
        ),
        fqir_rel_error_tol=0.15,
        marks=TF2ONNX_XFAIL,
    ),
    MainAPITestCase(
        name="doc_example_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=create_doc_example_model,
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="custom_rewriter_tdnn_bias_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=lambda: create_custom_rewriter_tdnn_model(use_bias=True),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="custom_rewriter_tdnn_nobias_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=lambda: create_custom_rewriter_tdnn_model(use_bias=False),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="custom_rewriter_tdnn_mixed_bias_true_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=lambda: create_custom_rewriter_tdnn_mixed_bias_model(
            use_bias=True
        ),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="custom_rewriter_tdnn_mixed_bias_false_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 10, 16),
        source_factory=lambda: create_custom_rewriter_tdnn_mixed_bias_model(
            use_bias=False
        ),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="model_v3_0_keras_tf2onnx",
        source_format="keras",
        conversion_backend="keras_tf2onnx",
        input_shape=(1, 120, 40),
        source_factory=lambda: freeze_batchnorm_statistics(
            model_v3_0(
                num_class=4,
                feat_dim=40,
                convert_wav_to_fbank=False,
                num_frame=120,
            )
        ),
        fqir_rel_error_tol=0.15,
        marks=TF2ONNX_XFAIL,
    ),
    MainAPITestCase(
        name="model_v3_0_keras_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 120, 40),
        source_factory=lambda: freeze_batchnorm_statistics(
            model_v3_0(
                num_class=4,
                feat_dim=40,
                convert_wav_to_fbank=False,
                num_frame=120,
            )
        ),
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="saved_keras_h5_via_tflite",
        source_format="keras",
        conversion_backend="keras_via_tflite",
        input_shape=(1, 100, 40),
        source_factory=lambda: SAVED_KERAS_MODEL,
        fqir_rel_error_tol=0.15,
    ),
    MainAPITestCase(
        name="user_example_tflite",
        source_format="tflite",
        conversion_backend="tflite_custom",
        input_shape=(1, 120, 40),
        source_factory=lambda: TEST_DIR / "user_example_conv1d_output.tflite",
        fqir_rel_error_tol=0.15,
    ),
]


@pytest.mark.parametrize(
    "case",
    [
        pytest.param(case, id=case.name, marks=case.marks)
        if case.marks
        else pytest.param(case, id=case.name)
        for case in MAIN_API_TEST_CASES
    ],
)
def test_main_api_roundtrip(case: MainAPITestCase, save_graphs=False):
    print(
        f"\n[roundtrip case] name={case.name} "
        f"source_format={case.source_format} "
        f"conversion_backend={case.conversion_backend} "
        f"input_shape={case.input_shape}"
    )
    tf.keras.utils.set_random_seed(0)
    tf.random.set_seed(0)
    np.random.seed(0)

    representative_data = [
        np.random.rand(*case.input_shape).astype(np.float32) for _ in range(25)
    ]
    source = case.source_factory()
    if case.source_format == "tflite" and isinstance(source, Path):
        source = str(source)
    print(f"[roundtrip source] {describe_source(source)}")

    try:
        onnx_model = convert_tdnn_to_onnx(
            source,
            source_format=case.source_format,
            conversion_backend=case.conversion_backend,
        )
    except Exception as exc:
        tflite_debug = dump_tflite_debug_for_failure(case, source)
        raise RuntimeError(
            f"convert_tdnn_to_onnx failed for {case.name}.{tflite_debug}"
        ) from exc
    print(f"[roundtrip onnx] {describe_onnx_model(onnx_model)}")

    try:
        quantized_onnx_model = quantize_tdnn_onnx(
            onnx_model, representative_data=representative_data
        )
    except Exception as exc:
        fp_path = dump_onnx_graph_for_failure(case.name, "floating_point", onnx_model)
        raise RuntimeError(
            f"quantize_tdnn_onnx failed for {case.name}. "
            f"Saved floating-point ONNX to {fp_path}."
        ) from exc
    print(f"[roundtrip quantized_onnx] {describe_onnx_model(quantized_onnx_model)}")

    try:
        cstate = convert_tdnn_to_cstate(
            source,
            representative_data,
            source_format=case.source_format,
            options=["conv1d_via_unfold"],
            conversion_backend=case.conversion_backend,
        )
    except Exception as exc:
        fp_path, quant_path = dump_intermediate_onnx_graphs_for_failure(
            case.name, onnx_model, quantized_onnx_model
        )
        raise RuntimeError(
            f"convert_tdnn_to_cstate failed for {case.name}. "
            f"Saved floating-point ONNX to {fp_path} and quantized ONNX to {quant_path}."
        ) from exc
    print(f"[roundtrip cstate] receptive_field={cstate.receptive_field}")

    if save_graphs:
        outdir = Path(__file__).parent
        onnx.save(onnx_model, outdir / "model_onnx.onnx")
        onnx.save(quantized_onnx_model, outdir / "quantized_model_onnx.onnx")

    with NamedTemporaryFile(suffix=".onnx") as temp:
        onnx.save(quantized_onnx_model, temp.name)

        sample_input = np.random.rand(*case.input_shape).astype(np.float32)
        onnx_output = run_onnx_model(Path(temp.name), sample_input)

        (x_quant,) = cstate.quantize_inputs([sample_input[0]])
        fqir_output = cstate.fqir.run(x_quant)
        (fqir_output,) = cstate.dequantize_outputs([fqir_output])
        fqir_output = fqir_output[cstate.receptive_field :]

    error = np.mean((fqir_output - onnx_output[0]) ** 2)
    error = np.sqrt(error / np.mean(onnx_output[0] ** 2))
    print(
        f"[roundtrip outputs] onnx_shape={onnx_output[0].shape} "
        f"fqir_shape={fqir_output.shape} rel_error={error}"
    )

    if error >= case.fqir_rel_error_tol:
        fp_path, quant_path = dump_intermediate_onnx_graphs_for_failure(
            case.name, onnx_model, quantized_onnx_model
        )
        pytest.fail(
            f"Roundtrip relative error for {case.name} was {error}, "
            f"expected < {case.fqir_rel_error_tol}. "
            f"Saved floating-point ONNX to {fp_path} and quantized ONNX to {quant_path}."
        )


if __name__ == "__main__":
    test_main_api_roundtrip(case=MAIN_API_TEST_CASES[1], save_graphs=True)
