import importlib

import numpy as np
import pytest

from fmot import fqir


cpp_runtime = pytest.importorskip("fmot.fqir._cpp_runtime")


def _make_single_node_graph(op_name, *, constants, include_y=False, outputs_name="z"):
    graph = fqir.GraphProto(name=f"{op_name}_graph")
    x = fqir.TensorProto("x", int, [4])
    graph.add_input(x)
    inputs = {"x": x}
    runtime_inputs = [x]

    if include_y:
        y = fqir.TensorProto("y", int, [4])
        graph.add_input(y)
        inputs["y"] = y
        runtime_inputs.append(y)

    z = fqir.TensorProto(outputs_name, int, [4])
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name=op_name,
            optype=fqir.registry_v1[op_name],
            inputs=inputs,
            outputs=[z],
            constants=constants,
        )
    )
    return graph


def _make_nullary_graph(op_name, *, constants, shape=(4,), outputs_name="z"):
    graph = fqir.GraphProto(name=f"{op_name}_graph")
    z = fqir.TensorProto(outputs_name, int, list(shape))
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name=op_name,
            optype=fqir.registry_v1[op_name],
            inputs={},
            outputs=[z],
            constants=constants,
        )
    )
    return graph


def test_cpp_runtime_contract_exports():
    assert hasattr(cpp_runtime, "run")
    assert hasattr(cpp_runtime, "run_batch")


@pytest.mark.parametrize(
    "op_name,constants,inputs",
    [
        (
            "vvadd",
            {
                "rounded": False,
                "shamt_x": 0,
                "shamt_y": 1,
                "shamt_bwred": 0,
                "bw": 8,
                "bw_x": 8,
                "bw_y": 8,
            },
            (np.array([1, 2, 3, 4]), np.array([5, 6, 7, 8])),
        ),
        (
            "viadd",
            {
                "y": 3,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 8,
                "bw_x": 8,
                "bw_y": 8,
                "rounded": False,
            },
            (np.array([1, 2, 3, 4]),),
        ),
        (
            "vvmul",
            {"rounded": False, "shamt_bwred": 0, "bw": 8},
            (np.array([1, 2, 3, 4]), np.array([2, 3, 4, 5])),
        ),
        (
            "vvsub",
            {
                "shamt_x": 1,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 8,
                "bw_x": 8,
                "bw_y": 8,
                "rounded": False,
            },
            (np.array([4, 5, 6, 7]), np.array([1, 2, 3, 4])),
        ),
        (
            "vimul",
            {"y": -2, "shamt_bwred": 0, "bw": 8, "rounded": False},
            (np.array([1, -2, 3, -4]),),
        ),
    ],
)
def test_cpp_backend_matches_python_for_stateless_subset(op_name, constants, inputs):
    graph = _make_single_node_graph(
        op_name,
        constants=constants,
        include_y=len(inputs) == 2,
    )
    python_out = graph.run(*inputs, backend="python")
    cpp_out = graph.run(*inputs, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


@pytest.mark.parametrize(
    "op_name,constants,inputs",
    [
        ("vneg", {"bw": 8}, (np.array([1, -2, 3, -4]),)),
        ("relu", {}, (np.array([1, -2, 3, -4]),)),
    ],
)
def test_cpp_backend_matches_python_for_unary_subset(op_name, constants, inputs):
    graph = _make_single_node_graph(op_name, constants=constants, include_y=False)
    python_out = graph.run(*inputs, backend="python")
    cpp_out = graph.run(*inputs, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


@pytest.mark.parametrize(
    "op_name,constants,shape",
    [
        ("zeros", {"shape": (2, 3)}, (2, 3)),
        ("constant", {"shape": (2, 3), "value": -4}, (2, 3)),
    ],
)
def test_cpp_backend_matches_python_for_nullary_subset(op_name, constants, shape):
    graph = _make_nullary_graph(op_name, constants=constants, shape=shape)
    python_out = graph.run(backend="python")
    cpp_out = graph.run(backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_quantize_matches_python():
    graph = fqir.GraphProto(name="quant_graph")
    x = fqir.TensorProto("x", float, [4])
    z = fqir.TensorProto("z", int, [4])
    graph.add_input(x)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="quantize",
            optype=fqir.registry_v1["quantize"],
            inputs={"x": x},
            outputs=[z],
            constants={"quanta": -1, "bw": 8},
        )
    )

    x_val = np.array([0.0, 0.25, 0.5, -0.75], dtype=np.float32)
    python_out = graph.run(x_val, backend="python")
    cpp_out = graph.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


@pytest.mark.parametrize(
    "op_name,constants,inputs",
    [
        ("constant_like", {"imm": -3}, (np.array([1, -2, 3, -4]),)),
        ("copy", {}, (np.array([1, -2, 3, -4]),)),
        ("shift", {"shamt": -1, "bw": 8}, (np.array([1, -2, 3, -4]),)),
        ("shift", {"shamt": 2, "bw": 8, "rounded": False}, (np.array([1, -2, 3, -4]),)),
    ],
)
def test_cpp_backend_matches_python_for_utility_subset(op_name, constants, inputs):
    graph = _make_single_node_graph(op_name, constants=constants, include_y=False)
    python_out = graph.run(*inputs, backend="python")
    cpp_out = graph.run(*inputs, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


@pytest.mark.parametrize(
    "op_name,constants,inputs",
    [
        ("vvgt", {}, (np.array([1, 2, 3, 4]), np.array([0, 2, 4, 1]))),
        ("vvge", {}, (np.array([1, 2, 3, 4]), np.array([0, 2, 4, 1]))),
        ("vvlt", {}, (np.array([1, 2, 3, 4]), np.array([0, 2, 4, 1]))),
        ("vvle", {}, (np.array([1, 2, 3, 4]), np.array([0, 2, 4, 1]))),
        ("vveq", {}, (np.array([1, 2, 3, 4]), np.array([0, 2, 4, 1]))),
    ],
)
def test_cpp_backend_matches_python_for_vv_comparisons(op_name, constants, inputs):
    graph = _make_single_node_graph(op_name, constants=constants, include_y=True)
    python_out = graph.run(*inputs, backend="python")
    cpp_out = graph.run(*inputs, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


@pytest.mark.parametrize(
    "op_name,constants,inputs",
    [
        ("vigt", {"imm": 2}, (np.array([1, 2, 3, 4]),)),
        ("vige", {"imm": 2}, (np.array([1, 2, 3, 4]),)),
        ("vilt", {"imm": 2}, (np.array([1, 2, 3, 4]),)),
        ("vile", {"imm": 2}, (np.array([1, 2, 3, 4]),)),
        ("vieq", {"imm": 2}, (np.array([1, 2, 3, 4]),)),
    ],
)
def test_cpp_backend_matches_python_for_vi_comparisons(op_name, constants, inputs):
    graph = _make_single_node_graph(op_name, constants=constants, include_y=False)
    python_out = graph.run(*inputs, backend="python")
    cpp_out = graph.run(*inputs, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


@pytest.mark.parametrize(
    "op_name,constants,inputs",
    [
        ("vvand", {}, (np.array([0, 1, 2, 0]), np.array([1, 0, 3, 0]))),
        ("vvor", {}, (np.array([0, 1, 2, 0]), np.array([1, 0, 3, 0]))),
        ("vvxor", {}, (np.array([0, 1, 2, 0]), np.array([1, 0, 3, 0]))),
    ],
)
def test_cpp_backend_matches_python_for_vv_boolean_ops(op_name, constants, inputs):
    graph = _make_single_node_graph(op_name, constants=constants, include_y=True)
    python_out = graph.run(*inputs, backend="python")
    cpp_out = graph.run(*inputs, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


@pytest.mark.parametrize(
    "op_name,constants,inputs",
    [
        ("viand", {"imm": 1}, (np.array([0, 1, 2, 0]),)),
        ("vior", {"imm": 0}, (np.array([0, 1, 2, 0]),)),
        ("vixor", {"imm": 1}, (np.array([0, 1, 2, 0]),)),
    ],
)
def test_cpp_backend_matches_python_for_vi_boolean_ops(op_name, constants, inputs):
    graph = _make_single_node_graph(op_name, constants=constants, include_y=False)
    python_out = graph.run(*inputs, backend="python")
    cpp_out = graph.run(*inputs, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_assign_matches_python():
    graph = fqir.GraphProto(name="assign_graph")
    y = fqir.TensorProto("y", int, [4])
    x = fqir.TensorProto("x", int, [4])
    graph.add_input(y)
    graph.add_input(x)
    graph.add_output(y)
    graph.add_node(
        fqir.NodeProto(
            name="assign",
            optype=fqir.registry_v1["assign"],
            inputs={"y": y, "x": x},
            outputs=[],
            constants={},
        )
    )
    python_out = graph.run(
        np.array([9, 9, 9, 9]), np.array([1, 2, 3, 4]), backend="python"
    )
    cpp_out = graph.run(np.array([9, 9, 9, 9]), np.array([1, 2, 3, 4]), backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_matmul_matches_python():
    graph = fqir.GraphProto(name="matmul_graph")
    x = fqir.TensorProto("x", int, [2, 2])
    y = fqir.TensorProto("y", int, [2, 2])
    z = fqir.TensorProto("z", int, [2, 2])
    graph.add_input(x)
    graph.add_input(y)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="matmul",
            optype=fqir.registry_v1["matmul"],
            inputs={"x": x, "y": y},
            outputs=[z],
            constants={"rounded": False, "shamt_bwred": 0, "bw_out": 16},
        )
    )
    x_val = np.array([[1, 2], [3, 4]], dtype=np.int32)
    y_val = np.array([[5, 6], [7, 8]], dtype=np.int32)
    python_out = graph.run(x_val, y_val, backend="python")
    cpp_out = graph.run(x_val, y_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_addmm_matches_python():
    graph = fqir.GraphProto(name="addmm_graph")
    bias = fqir.TensorProto("bias", int, [2])
    x = fqir.TensorProto("x", int, [2, 2])
    y = fqir.TensorProto("y", int, [2])
    z = fqir.TensorProto("z", int, [2])
    graph.add_input(bias)
    graph.add_input(x)
    graph.add_input(y)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="addmm",
            optype=fqir.registry_v1["addmm"],
            inputs={"bias": bias, "x": x, "y": y},
            outputs=[z],
            constants={
                "rounded": False,
                "shamt_bias": 0,
                "shamt_bwred": 0,
                "bw_out": 16,
            },
        )
    )
    bias_val = np.array([1, -1], dtype=np.int32)
    x_val = np.array([[1, 2], [3, 4]], dtype=np.int32)
    y_val = np.array([5, 6], dtype=np.int32)
    python_out = graph.run(bias_val, x_val, y_val, backend="python")
    cpp_out = graph.run(bias_val, x_val, y_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_lut_matches_python():
    class Table:
        pass

    table = Table()
    table.x = np.arange(256, dtype=np.int32)
    table.y = (np.arange(256, dtype=np.int32) * 3) - 7

    graph = fqir.GraphProto(name="lut_graph")
    x = fqir.TensorProto("x", int, [4])
    z = fqir.TensorProto("z", int, [4])
    graph.add_input(x)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="lut0",
            optype=fqir.registry_v1["lut"],
            inputs={"x": x},
            outputs=[z],
            constants={
                "shamt_address": 0,
                "bw_address": 8,
                "table": table,
                "function": "affine_test",
            },
        )
    )

    x_val = np.array([0, 1, 17, 255], dtype=np.int32)
    python_out = graph.run(x_val, backend="python")
    cpp_out = graph.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_dequantize_matches_python():
    graph = fqir.GraphProto(name="dequant_graph")
    x = fqir.TensorProto("x", int, [4])
    z = fqir.TensorProto("z", int, [4])
    graph.add_input(x)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="dequantize",
            optype=fqir.registry_v1["dequantize"],
            inputs={"x": x},
            outputs=[z],
            constants={"quanta": -2},
        )
    )
    x_val = np.array([0, 1, -2, 4], dtype=np.int32)
    python_out = graph.run(x_val, backend="python")
    cpp_out = graph.run(x_val, backend="cpp")
    np.testing.assert_allclose(cpp_out, python_out)


def test_cpp_backend_transpose_matches_python():
    graph = fqir.GraphProto(name="transpose_graph")
    x = fqir.TensorProto("x", int, [2, 3])
    z = fqir.TensorProto("z", int, [3, 2])
    graph.add_input(x)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="transpose",
            optype=fqir.registry_v1["transpose"],
            inputs={"x": x},
            outputs=[z],
            constants={"dim0": 0, "dim1": 1},
        )
    )
    x_val = np.array([[1, 2, 3], [4, 5, 6]], dtype=np.int32)
    python_out = graph.run(x_val, backend="python")
    cpp_out = graph.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_reshape_matches_python():
    graph = fqir.GraphProto(name="reshape_graph")
    x = fqir.TensorProto("x", int, [2, 2])
    z = fqir.TensorProto("z", int, [4])
    graph.add_input(x)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="reshape",
            optype=fqir.registry_v1["reshape"],
            inputs={"x": x},
            outputs=[z],
            constants={"shape": (4,)},
        )
    )
    x_val = np.array([[1, 2], [3, 4]], dtype=np.int32)
    python_out = graph.run(x_val, backend="python")
    cpp_out = graph.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_chunk_matches_python():
    graph = fqir.GraphProto(name="chunk_graph")
    x = fqir.TensorProto("x", int, [2, 2])
    z0 = fqir.TensorProto("z0", int, [1, 2])
    z1 = fqir.TensorProto("z1", int, [1, 2])
    graph.add_input(x)
    graph.add_output(z0)
    graph.add_output(z1)
    graph.add_node(
        fqir.NodeProto(
            name="chunk",
            optype=fqir.registry_v1["chunk"],
            inputs={"x": x},
            outputs=[z0, z1],
            constants={"chunks": 2, "dim": 0},
        )
    )
    x_val = np.array([[1, 2], [3, 4]], dtype=np.int32)
    python_out = graph.run(x_val, backend="python")
    cpp_out = graph.run(x_val, backend="cpp")
    assert isinstance(cpp_out, tuple)
    np.testing.assert_equal(cpp_out[0], python_out[0])
    np.testing.assert_equal(cpp_out[1], python_out[1])


def test_cpp_backend_cat_matches_python():
    graph = fqir.GraphProto(name="cat_graph")
    x0 = fqir.TensorProto("x0", int, [2, 2])
    x1 = fqir.TensorProto("x1", int, [2, 2])
    z = fqir.TensorProto("z", int, [4, 2])
    graph.add_input(x0)
    graph.add_input(x1)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="cat",
            optype=fqir.registry_v1["cat"],
            inputs={"x0": x0, "x1": x1},
            outputs=[z],
            constants={"dim": 0},
        )
    )
    x0_val = np.array([[1, 2], [3, 4]], dtype=np.int32)
    x1_val = np.array([[5, 6], [7, 8]], dtype=np.int32)
    python_out = graph.run(x0_val, x1_val, backend="python")
    cpp_out = graph.run(x0_val, x1_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_split_matches_python():
    graph = fqir.GraphProto(name="split_graph")
    x = fqir.TensorProto("x", int, [6])
    z0 = fqir.TensorProto("z0", int, [2])
    z1 = fqir.TensorProto("z1", int, [4])
    graph.add_input(x)
    graph.add_output(z0)
    graph.add_output(z1)
    graph.add_node(
        fqir.NodeProto(
            name="split",
            optype=fqir.registry_v1["split"],
            inputs={"x": x},
            outputs=[z0, z1],
            constants={"lengths": [2, 4], "dim": 0},
        )
    )
    x_val = np.array([1, 2, 3, 4, 5, 6], dtype=np.int32)
    python_out = graph.run(x_val, backend="python")
    cpp_out = graph.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out[0], python_out[0])
    np.testing.assert_equal(cpp_out[1], python_out[1])


def test_cpp_backend_split_batched_last_dim_matches_expected():
    graph = fqir.GraphProto(name="split_batched_graph")
    x = fqir.TensorProto("x", int, [2, 6])
    z0 = fqir.TensorProto("z0", int, [2, 2])
    z1 = fqir.TensorProto("z1", int, [2, 4])
    graph.add_input(x)
    graph.add_output(z0)
    graph.add_output(z1)
    graph.add_node(
        fqir.NodeProto(
            name="split",
            optype=fqir.registry_v1["split"],
            inputs={"x": x},
            outputs=[z0, z1],
            constants={"lengths": [2, 4], "dim": -1},
        )
    )
    x_val = np.arange(12, dtype=np.int32).reshape(2, 6)
    cpp_out = graph.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out[0], x_val[:, :2])
    np.testing.assert_equal(cpp_out[1], x_val[:, 2:])


def test_cpp_backend_gt0_matches_python():
    graph = fqir.GraphProto(name="gt0_graph")
    x = fqir.TensorProto("x", int, [5])
    z = fqir.TensorProto("z", int, [5])
    graph.add_input(x)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="gt0",
            optype=fqir.registry_v1["gt0"],
            inputs={"x": x},
            outputs=[z],
            constants={"bw": 8},
        )
    )
    x_val = np.array([-2, -1, 0, 1, 3], dtype=np.int32)
    python_out = graph.run(x_val, backend="python")
    cpp_out = graph.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_runtime_direct_plan_contract():
    graph = _make_single_node_graph(
        "vvadd",
        constants={
            "rounded": False,
            "shamt_x": 0,
            "shamt_y": 0,
            "shamt_bwred": 0,
            "bw": 8,
            "bw_x": 8,
            "bw_y": 8,
        },
        include_y=True,
    )
    plan = graph.lower_runtime_plan().to_dict()
    out = cpp_runtime.run(
        plan,
        (np.array([1, 2, 3, 4]), np.array([10, 20, 30, 40])),
        return_objs=False,
        dequant=False,
        state=None,
        return_dict=False,
    )
    np.testing.assert_equal(out, np.array([11, 22, 33, 44], dtype=np.int32))


def test_cpp_runtime_run_batch_matches_python():
    graph = _make_single_node_graph(
        "vvmul",
        constants={"rounded": False, "shamt_bwred": 0, "bw": 8},
        include_y=True,
    )
    x = np.arange(12).reshape(3, 4)
    y = np.ones((3, 4), dtype=int) * 2
    python_out = graph.run_batch(x, y, backend="python", max_workers=1)
    cpp_out = graph.run_batch(x, y, backend="cpp", max_workers=1)
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_sequential_init_arith_matches_python():
    init = fqir.GraphProto(name="INIT")
    state0 = fqir.TensorProto("state", int, [4], value=np.zeros(4, dtype=np.int32))
    init.add_parameter(state0)
    init.add_output(state0)

    arith = fqir.GraphProto(name="ARITH")
    x = fqir.TensorProto("x", int, [4])
    state_in = fqir.TensorProto("state", int, [4])
    state_out = fqir.TensorProto("state_next", int, [4])
    arith.add_input(x)
    arith.add_input(state_in)
    arith.add_node(
        fqir.NodeProto(
            name="accum",
            optype=fqir.registry_v1["vvadd"],
            inputs={"x": x, "y": state_in},
            outputs=[state_out],
            constants={
                "rounded": False,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 16,
                "bw_x": 16,
                "bw_y": 16,
            },
        )
    )
    arith.add_node(
        fqir.NodeProto(
            name="state_assign",
            optype=fqir.registry_v1["assign"],
            inputs={"y": state_in, "x": state_out},
            outputs=[],
            constants={},
        )
    )
    arith.add_output(state_out)

    main = fqir.GraphProto(name="MAIN", unbind_dim=0)
    main.add_node(
        fqir.NodeProto(
            name="ARITH",
            subgraph=arith,
            inputs={"x0": x, "x1": state_in},
            outputs=[],
            optype=None,
        )
    )
    main.add_node(
        fqir.NodeProto(
            name="INIT",
            subgraph=init,
            inputs={},
            outputs=[],
            optype=None,
        )
    )
    main.add_subgraph("INIT", init)
    main.add_subgraph("ARITH", arith)
    main.inputs = [x]
    main.outputs = [state_out]

    seq = np.arange(12, dtype=np.int32).reshape(3, 4)
    python_out = main.run(seq, backend="python")
    cpp_out = main.run(seq, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_sequential_parallel_precompute_matches_python():
    init = fqir.GraphProto(name="INIT")
    state0 = fqir.TensorProto("state", int, [4], value=np.zeros(4, dtype=np.int32))
    init.add_parameter(state0)
    init.add_output(state0)

    arith = fqir.GraphProto(name="ARITH")
    x = fqir.TensorProto("x", int, [4])
    state_in = fqir.TensorProto("state", int, [4])
    x_plus = fqir.TensorProto("x_plus", int, [4])
    state_out = fqir.TensorProto("state_next", int, [4])
    arith.add_input(x)
    arith.add_input(state_in)
    arith.add_node(
        fqir.NodeProto(
            name="parallel_viadd",
            optype=fqir.registry_v1["viadd"],
            inputs={"x": x},
            outputs=[x_plus],
            constants={
                "y": 3,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 16,
                "bw_x": 16,
                "bw_y": 16,
                "rounded": False,
            },
        )
    )
    arith.add_node(
        fqir.NodeProto(
            name="accum",
            optype=fqir.registry_v1["vvadd"],
            inputs={"x": x_plus, "y": state_in},
            outputs=[state_out],
            constants={
                "rounded": False,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 16,
                "bw_x": 16,
                "bw_y": 16,
            },
        )
    )
    arith.add_node(
        fqir.NodeProto(
            name="state_assign",
            optype=fqir.registry_v1["assign"],
            inputs={"y": state_in, "x": state_out},
            outputs=[],
            constants={},
        )
    )
    arith.add_output(state_out)

    main = fqir.GraphProto(name="MAIN", unbind_dim=0)
    main.add_node(
        fqir.NodeProto(
            name="ARITH",
            subgraph=arith,
            inputs={"x0": x, "x1": state_in},
            outputs=[],
            optype=None,
        )
    )
    main.add_node(
        fqir.NodeProto(
            name="INIT",
            subgraph=init,
            inputs={},
            outputs=[],
            optype=None,
        )
    )
    main.add_subgraph("INIT", init)
    main.add_subgraph("ARITH", arith)
    main.inputs = [x]
    main.outputs = [state_out]

    seq = np.arange(20, dtype=np.int32).reshape(5, 4)
    python_out = main.run(seq, backend="python")
    cpp_out = main.run(seq, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_temporal_unfold_matches_python():
    init = fqir.GraphProto(name="INIT")
    buffer0 = fqir.TensorProto("buffer", int, [4], value=np.zeros(4, dtype=np.int32))
    init.add_parameter(buffer0)
    init.add_output(buffer0)

    arith = fqir.GraphProto(name="ARITH")
    x = fqir.TensorProto("x", int, [4])
    buffer_in = fqir.TensorProto("buffer", int, [4])
    y = fqir.TensorProto("y", int, [8])
    arith.add_input(x)
    arith.add_input(buffer_in)
    arith.add_node(
        fqir.NodeProto(
            name="temporal_unfold",
            optype=fqir.registry_v1["temporal_unfold"],
            inputs={"x": x, "buffer": buffer_in},
            outputs=[y],
            constants={
                "kernel_size": 2,
                "dilation": 1,
                "buffer_length": 1,
            },
        )
    )
    arith.add_output(y)

    main = fqir.GraphProto(name="TEMPORAL_UNFOLD_MAIN", unbind_dim=0)
    main.add_node(
        fqir.NodeProto(
            name="ARITH",
            subgraph=arith,
            inputs={"x0": x, "x1": buffer_in},
            outputs=[],
            optype=None,
        )
    )
    main.add_node(
        fqir.NodeProto(
            name="INIT",
            subgraph=init,
            inputs={},
            outputs=[],
            optype=None,
        )
    )
    main.add_subgraph("INIT", init)
    main.add_subgraph("ARITH", arith)
    main.inputs = [x]
    main.outputs = [y]

    seq = np.arange(12, dtype=np.int32).reshape(3, 4)
    python_out = main.run(seq, backend="python")
    cpp_out = main.run(seq, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_temporal_conv2d_matches_python():
    init = fqir.GraphProto(name="INIT")
    buffer0 = fqir.TensorProto("buffer", int, [4], value=np.zeros(4, dtype=np.int32))
    init.add_parameter(buffer0)
    init.add_output(buffer0)

    arith = fqir.GraphProto(name="ARITH")
    input_t = fqir.TensorProto("input", int, [4])
    buffer_in = fqir.TensorProto("buffer", int, [4])
    weight = fqir.TensorProto(
        "weight",
        int,
        [2, 2, 1, 2],
        value=np.array(
            [
                [[[1, 0]], [[0, 1]]],
                [[[0, 1]], [[1, 0]]],
            ],
            dtype=np.int32,
        ),
    )
    bias = fqir.TensorProto("bias", int, [2], value=np.array([1, -1], dtype=np.int32))
    y = fqir.TensorProto("y", int, [4])
    arith.add_input(input_t)
    arith.add_input(buffer_in)
    arith.add_parameter(weight)
    arith.add_parameter(bias)
    arith.add_node(
        fqir.NodeProto(
            name="temporal_conv2d",
            optype=fqir.registry_v1["temporal_conv2d"],
            inputs={
                "input": input_t,
                "buffer": buffer_in,
                "weight": weight,
                "bias": bias,
            },
            outputs=[y],
            constants={
                "kernel_size_t": 2,
                "kernel_size_band": 1,
                "d_band_in": 2,
                "n_band_in": 2,
                "dilation_t": 1,
                "dilation_band": 1,
                "stride_band": 1,
                "padding_band": 0,
                "groups": 1,
                "shamt_bwred": 0,
                "shamt_bias": 0,
                "bw": 16,
            },
        )
    )
    arith.add_output(y)

    main = fqir.GraphProto(name="TEMPORAL_CONV_MAIN", unbind_dim=0)
    main.add_node(
        fqir.NodeProto(
            name="ARITH",
            subgraph=arith,
            inputs={"x0": input_t, "x1": buffer_in},
            outputs=[],
            optype=None,
        )
    )
    main.add_node(
        fqir.NodeProto(
            name="INIT",
            subgraph=init,
            inputs={},
            outputs=[],
            optype=None,
        )
    )
    main.add_subgraph("INIT", init)
    main.add_subgraph("ARITH", arith)
    main.inputs = [input_t]
    main.outputs = [y]

    seq = np.array(
        [
            [1, 2, 3, 4],
            [5, 6, 7, 8],
            [9, 10, 11, 12],
        ],
        dtype=np.int32,
    )
    python_out = main.run(seq, backend="python")
    cpp_out = main.run(seq, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_sequential_input_alias_matches_python():
    init = fqir.GraphProto(name="INIT")
    hidden0 = fqir.TensorProto(
        "hidden_state", int, [4], value=np.zeros(4, dtype=np.int32)
    )
    init.add_parameter(hidden0)
    init.add_output(hidden0)

    arith = fqir.GraphProto(name="ARITH")
    step_x = fqir.TensorProto("x", int, [4])
    hidden_in = fqir.TensorProto("hidden_state", int, [4])
    y = fqir.TensorProto("y", int, [4])
    arith.add_input(step_x)
    arith.add_input(hidden_in)
    arith.add_node(
        fqir.NodeProto(
            name="accum",
            optype=fqir.registry_v1["vvadd"],
            inputs={"x": step_x, "y": hidden_in},
            outputs=[y],
            constants={
                "rounded": False,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 16,
                "bw_x": 16,
                "bw_y": 16,
            },
        )
    )
    arith.add_output(y)

    main = fqir.GraphProto(name="SEQ_ALIAS_MAIN", unbind_dim=0)
    external = fqir.TensorProto("external_input", int, [4])
    main.add_node(
        fqir.NodeProto(
            name="ARITH",
            subgraph=arith,
            inputs={"x0": external, "x1": hidden0},
            outputs=[],
            optype=None,
        )
    )
    main.add_node(
        fqir.NodeProto(
            name="INIT",
            subgraph=init,
            inputs={},
            outputs=[],
            optype=None,
        )
    )
    main.add_subgraph("INIT", init)
    main.add_subgraph("ARITH", arith)
    main.inputs = [external]
    main.outputs = [y]

    seq = np.arange(12, dtype=np.int32).reshape(3, 4)
    python_out = main.run(seq, backend="python")
    cpp_out = main.run(seq, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_loop_matches_python():
    loop_body = fqir.GraphProto(name="sum_loop")
    sum_in = fqir.TensorProto("sum_in", int, [2])
    x_slice = fqir.TensorProto("x_slice", int, [2])
    sum_out = fqir.TensorProto("sum_out", int, [2])
    loop_body.add_input(sum_in)
    loop_body.add_input(x_slice)
    loop_body.add_node(
        fqir.NodeProto(
            name="add",
            optype=fqir.registry_v1["vvadd"],
            inputs={"x": x_slice, "y": sum_in},
            outputs=[sum_out],
            constants={
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 16,
                "bw_x": 16,
                "bw_y": 16,
            },
        )
    )
    loop_body.add_output(sum_out)
    loop_body.add_output(sum_out)

    arith = fqir.GraphProto(name="ARITH")
    x_in = fqir.TensorProto("x_sequence", int, [8])
    sum_init = fqir.TensorProto("sum_init", int, [2], value=np.zeros(2, dtype=np.int32))
    sum_final = fqir.TensorProto("sum_final", int, [2])
    arith.add_input(x_in)
    arith.add_parameter(sum_init)
    arith.add_node(
        fqir.NodeProto(
            name="loop",
            optype=fqir.registry_v1["loop"],
            inputs={"x_recurse_0": sum_init, "x_sliced_0": x_in},
            outputs=[sum_final],
            constants={
                "n_iter": 4,
                "n_recurse": 1,
                "n_sliced": 1,
                "n_concat": 0,
                "n_final": 1,
                "n_scope": 0,
                "block_size_sliced": [2],
                "reverse_sliced": [False],
                "reverse_concat": [],
            },
            subgraph=loop_body,
        )
    )
    arith.add_output(sum_final)
    arith.add_subgraph("sum_loop", loop_body)

    x_val = np.arange(8, dtype=np.int32)
    python_out = arith.run(x_val, backend="python")
    cpp_out = arith.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_vectorized_loop_matches_python():
    loop_body = fqir.GraphProto(name="map_loop")
    x_slice = fqir.TensorProto("x_slice", int, [2])
    y = fqir.TensorProto("y", int, [2])
    loop_body.add_input(x_slice)
    loop_body.add_node(
        fqir.NodeProto(
            name="plus_one",
            optype=fqir.registry_v1["viadd"],
            inputs={"x": x_slice},
            outputs=[y],
            constants={
                "y": 1,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 8,
                "bw_x": 8,
                "bw_y": 8,
            },
        )
    )
    loop_body.add_output(y)

    arith = fqir.GraphProto(name="vectorized_loop_parent")
    x_in = fqir.TensorProto("x_sequence", int, [4])
    z = fqir.TensorProto("z", int, [4])
    arith.add_input(x_in)
    arith.add_node(
        fqir.NodeProto(
            name="loop_like",
            optype=fqir.registry_v1["loop"],
            inputs={"x_sliced_0": x_in},
            outputs=[z],
            constants={
                "n_iter": 2,
                "n_recurse": 0,
                "n_sliced": 1,
                "n_concat": 1,
                "n_final": 0,
                "n_scope": 0,
                "block_size_sliced": [2],
                "reverse_sliced": [False],
                "reverse_concat": [False],
            },
            subgraph=loop_body,
        )
    )
    arith.add_output(z)
    arith.add_subgraph("map_loop", loop_body)

    x_val = np.arange(4, dtype=np.int32)
    python_out = arith.run(x_val, backend="python")
    cpp_out = arith.run(x_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_strided_subgraph_matches_python():
    subgraph = fqir.GraphProto(name="stride_body")
    x = fqir.TensorProto("x", int, [2])
    y = fqir.TensorProto("y", int, [2])
    subgraph.add_input(x)
    subgraph.add_node(
        fqir.NodeProto(
            name="plus_one",
            optype=fqir.registry_v1["viadd"],
            inputs={"x": x},
            outputs=[y],
            constants={
                "y": 1,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 16,
                "bw_x": 16,
                "bw_y": 16,
                "rounded": False,
            },
        )
    )
    subgraph.add_output(y)

    init = fqir.GraphProto(name="INIT")
    counter0 = fqir.TensorProto(
        "counter", int, [1], value=np.array([0], dtype=np.int32)
    )
    init.add_parameter(counter0)
    init.add_output(counter0)

    arith = fqir.GraphProto(name="ARITH")
    input_t = fqir.TensorProto("input_0", int, [2])
    default_y = fqir.TensorProto("default_output_0", int, [2])
    counter = fqir.TensorProto("counter", int, [1])
    out = fqir.TensorProto("out", int, [2])
    arith.add_input(input_t)
    arith.add_input(default_y)
    arith.add_input(counter)
    arith.add_node(
        fqir.NodeProto(
            name="strided_subgraph",
            optype=fqir.registry_v1["strided_subgraph"],
            inputs={
                "counter": counter,
                "input_0": input_t,
                "default_output_0": default_y,
            },
            outputs=[out],
            constants={"n": 2, "k": 0, "num_inputs": 1, "num_outputs": 1},
            subgraph=subgraph,
        )
    )
    arith.add_output(out)
    arith.add_subgraph("stride_body", subgraph)

    main = fqir.GraphProto(name="STRIDE_MAIN", unbind_dim=0)
    main.add_node(
        fqir.NodeProto(
            name="ARITH",
            subgraph=arith,
            inputs={"x0": input_t, "x1": default_y, "x2": counter},
            outputs=[],
            optype=None,
        )
    )
    main.add_node(
        fqir.NodeProto(
            name="INIT",
            subgraph=init,
            inputs={},
            outputs=[],
            optype=None,
        )
    )
    main.add_subgraph("INIT", init)
    main.add_subgraph("ARITH", arith)
    main.inputs = [input_t, default_y]
    main.outputs = [out]

    seq_in = np.array([[1, 2], [3, 4], [5, 6], [7, 8]], dtype=np.int32)
    seq_default = np.full((4, 2), -9, dtype=np.int32)
    python_out = main.run(seq_in, seq_default, backend="python")
    cpp_out = main.run(seq_in, seq_default, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_gmac_v2_vv_matches_python():
    graph = fqir.GraphProto(name="gmac_v2_vv_graph")
    x0 = fqir.TensorProto("x_vv_0", int, [4])
    y0 = fqir.TensorProto("y_vv_0", int, [4])
    z = fqir.TensorProto("z", int, [4])
    graph.add_input(x0)
    graph.add_input(y0)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="gmac_v2",
            optype=fqir.registry_v1["gmac_v2"],
            inputs={"x_vv_0": x0, "y_vv_0": y0},
            outputs=[z],
            constants={
                "shamts_vv": [0],
                "shamts_vi": [],
                "immediates_vi": [],
                "bits_out": [16],
            },
        )
    )
    x_val = np.array([1, 2, -3, 4], dtype=np.int32)
    y_val = np.array([5, -1, 2, 3], dtype=np.int32)
    python_out = graph.run(x_val, y_val, backend="python")
    cpp_out = graph.run(x_val, y_val, backend="cpp")
    np.testing.assert_equal(cpp_out, python_out)


def test_cpp_backend_gmac_v2_mixed_cached_matches_python():
    graph = fqir.GraphProto(name="gmac_v2_mixed_graph")
    x_vv_0 = fqir.TensorProto("x_vv_0", int, [4])
    y_vv_0 = fqir.TensorProto("y_vv_0", int, [4])
    x_vi_0 = fqir.TensorProto("x_vi_0", int, [4])
    z_lo = fqir.TensorProto("z_lo", int, [4])
    z_hi = fqir.TensorProto("z_hi", int, [4])
    graph.add_input(x_vv_0)
    graph.add_input(y_vv_0)
    graph.add_input(x_vi_0)
    graph.add_output(z_lo)
    graph.add_output(z_hi)
    graph.add_node(
        fqir.NodeProto(
            name="gmac_v2_mixed",
            optype=fqir.registry_v1["gmac_v2"],
            inputs={"x_vv_0": x_vv_0, "y_vv_0": y_vv_0, "x_vi_0": x_vi_0},
            outputs=[z_lo, z_hi],
            constants={
                "shamts_vv": [2],
                "shamts_vi": [0],
                "immediates_vi": [3],
                "bits_out": [8, 8],
            },
        )
    )
    xvv = np.array([7, -4, 2, 1], dtype=np.int32)
    yvv = np.array([3, 5, -2, 8], dtype=np.int32)
    xvi = np.array([1, 2, 3, 4], dtype=np.int32)

    cpp_runtime._GMAC_PLAN_CACHE.clear()
    python_out = graph.run(xvv, yvv, xvi, backend="python")
    cpp_out_0 = graph.run(xvv, yvv, xvi, backend="cpp")
    cpp_out_1 = graph.run(xvv, yvv, xvi, backend="cpp")

    assert len(cpp_runtime._GMAC_PLAN_CACHE) == 1
    assert next(iter(cpp_runtime._GMAC_PLAN_CACHE.keys()))[0] == "gmac_v2_mixed"
    np.testing.assert_equal(cpp_out_0[0], python_out[0])
    np.testing.assert_equal(cpp_out_0[1], python_out[1])
    np.testing.assert_equal(cpp_out_1[0], python_out[0])
    np.testing.assert_equal(cpp_out_1[1], python_out[1])
