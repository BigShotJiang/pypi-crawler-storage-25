import numpy as np
import pytest
import torch
import time
from torch import nn

import fmot


pytest.importorskip("fmot.fqir._cpp_runtime")


class _NotebookLSTMModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.LSTM(128, 128, num_layers=4, batch_first=True)

    def forward(self, x):
        y, _ = self.model(x)
        return y


def _make_notebook_trace_graph():
    torch.manual_seed(0)
    np.random.seed(0)

    model = _NotebookLSTMModel().eval()
    cmodel = fmot.ConvertedModel(model, batch_dim=0, seq_dim=1)
    cmodel.quantize([torch.randn(8, 100, 128) for _ in range(2)])
    return cmodel.trace()


@pytest.mark.slow
def test_cpp_runtime_matches_python_for_notebook_lstm_trace():
    """Regression for notebooks/fqir_runtime_test.ipynb."""
    graph = _make_notebook_trace_graph()

    x = np.random.randn(100, 128).astype(np.float32)
    out_py = graph.run(x, backend="python")
    out_cpp = graph.run(x, backend="cpp")

    np.testing.assert_equal(out_cpp, out_py)


@pytest.mark.slow
def test_cpp_runtime_is_faster_than_python_for_notebook_lstm_trace():
    graph = _make_notebook_trace_graph()
    x = np.random.randn(500, 128).astype(np.float32)

    graph.run(x, backend="python")
    graph.run(x, backend="cpp")

    py_times = []
    cpp_times = []
    for _ in range(3):
        t0 = time.perf_counter()
        graph.run(x, backend="python")
        t1 = time.perf_counter()
        graph.run(x, backend="cpp")
        t2 = time.perf_counter()
        py_times.append(t1 - t0)
        cpp_times.append(t2 - t1)

    py_avg = sum(py_times) / len(py_times)
    cpp_avg = sum(cpp_times) / len(cpp_times)

    assert cpp_avg < py_avg * 0.95, (
        f"Expected cpp runtime to be faster than python. "
        f"python_avg={py_avg:.4f}s cpp_avg={cpp_avg:.4f}s"
    )
