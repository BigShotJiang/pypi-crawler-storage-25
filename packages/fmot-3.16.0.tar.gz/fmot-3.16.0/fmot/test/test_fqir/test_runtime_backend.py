import numpy as np
import pytest
import tempfile
from pathlib import Path

from fmot import fqir


def make_vvadd_graph():
    graph = fqir.GraphProto(name="main")
    x = fqir.TensorProto("x", int, [2])
    y = fqir.TensorProto("y", int, [2])
    z = fqir.TensorProto("z", int, [2])
    graph.add_input(x)
    graph.add_input(y)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="add",
            optype=fqir.registry_v1["vvadd"],
            inputs={"x": x, "y": y},
            outputs=[z],
            constants={
                "rounded": False,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 8,
                "bw_x": 8,
                "bw_y": 8,
            },
        )
    )
    return graph


def test_python_backend_run_matches_default():
    graph = make_vvadd_graph()
    x = np.array([1, 2])
    y = np.array([3, 4])

    default_out = graph.run(x, y)
    backend_out = graph.run(x, y, backend="python")

    np.testing.assert_equal(default_out, backend_out)


def test_compile_runtime_python_backend_matches_graph_run():
    graph = make_vvadd_graph()
    runtime = graph.compile_runtime(backend="python")
    x = np.array([5, 7])
    y = np.array([11, 13])

    np.testing.assert_equal(runtime.run(x, y), graph.run(x, y))


def test_compile_runtime_caches_by_backend():
    graph = make_vvadd_graph()

    py_runtime_0 = graph.compile_runtime(backend="python")
    py_runtime_1 = graph.compile_runtime(backend="python")

    assert py_runtime_0 is py_runtime_1

    if fqir.is_runtime_backend_available("cpp"):
        cpp_runtime_0 = graph.compile_runtime(backend="cpp")
        cpp_runtime_1 = graph.compile_runtime(backend="cpp")
        assert cpp_runtime_0 is cpp_runtime_1


def test_lower_runtime_plan_is_cached():
    graph = make_vvadd_graph()

    plan_0 = graph.lower_runtime_plan()
    plan_1 = graph.lower_runtime_plan()

    assert plan_0 is plan_1


def test_runtime_plan_contains_graph_metadata():
    graph = make_vvadd_graph()
    plan = graph.lower_runtime_plan()

    assert plan.name == "main"
    assert [tensor.name for tensor in plan.inputs] == ["x", "y"]
    assert [tensor.name for tensor in plan.outputs] == ["z"]
    assert len(plan.nodes) == 1
    assert plan.nodes[0].name == "add"
    assert plan.nodes[0].op_name == "vvadd"
    assert plan.nodes[0].inputs == {"x": "x", "y": "y"}
    assert plan.nodes[0].outputs == ["z"]
    assert plan.inputs[0].dtype == {"kind": "type", "name": "int"}
    assert plan.inputs[0].roles == ["input"]
    assert plan.outputs[0].roles == ["output"]


def test_runtime_plan_serializes_parameter_payloads():
    graph = fqir.GraphProto(name="param_graph")
    x = fqir.TensorProto("x", int, [2])
    w = fqir.TensorProto("w", int, [2], value=np.array([10, 20], dtype=np.int16))
    z = fqir.TensorProto("z", int, [2])
    graph.add_input(x)
    graph.add_parameter(w)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="mul",
            optype=fqir.registry_v1["vvmul"],
            inputs={"x": x, "y": w},
            outputs=[z],
            constants={"rounded": False, "shamt_bwred": np.int64(0), "bw": 8},
        )
    )

    plan_dict = graph.lower_runtime_plan().to_dict()

    param_desc = plan_dict["parameters"][0]
    assert param_desc["name"] == "w"
    assert param_desc["has_value"] is True
    assert param_desc["roles"] == ["parameter"]
    assert param_desc["value"] == {
        "kind": "ndarray",
        "dtype": "int16",
        "shape": [2],
        "data": [10, 20],
    }
    assert plan_dict["nodes"][0]["constants"]["shamt_bwred"] == 0


def test_cpp_backend_reports_unavailable():
    graph = make_vvadd_graph()
    if fqir.is_runtime_backend_available("cpp"):
        out = graph.run(np.array([1, 2]), np.array([3, 4]), backend="cpp")
        np.testing.assert_equal(out, np.array([4, 6], dtype=np.int32))
    else:
        with pytest.raises(
            RuntimeError, match="C\\+\\+ runtime backend is not available"
        ):
            graph.run(np.array([1, 2]), np.array([3, 4]), backend="cpp")


def test_cpp_profile_runtime_reports_op_times():
    graph = make_vvadd_graph()
    x = np.array([1, 2])
    y = np.array([3, 4])

    if not fqir.is_runtime_backend_available("cpp"):
        with pytest.raises(
            RuntimeError, match="does not support profiling|not available"
        ):
            graph.profile_runtime(x, y, backend="cpp")
        return

    outputs, profile = graph.profile_runtime(x, y, backend="cpp")
    np.testing.assert_equal(outputs, np.array([4, 6], dtype=np.int32))
    assert profile["total_time_s"] >= 0.0
    assert "vvadd" in profile["ops"]
    assert profile["ops"]["vvadd"]["count"] == 1
    assert profile["ops"]["vvadd"]["time_s"] >= 0.0
    assert "phases" in profile
    assert "stateless_load_initial_objs" in profile["phases"]
    assert profile["phases"]["stateless_load_initial_objs"]["count"] >= 1
    assert profile["phases"]["stateless_load_initial_objs"]["time_s"] >= 0.0


def test_cpp_loop_vectorization_analysis_reports_candidates():
    if not fqir.is_runtime_backend_available("cpp"):
        pytest.skip("cpp backend unavailable")

    loop_body = fqir.GraphProto(name="map_loop")
    x_slice = fqir.TensorProto("x_slice", int, [2])
    y = fqir.TensorProto("y", int, [2])
    loop_body.add_input(x_slice)
    loop_body.add_node(
        fqir.NodeProto(
            name="double",
            optype=fqir.registry_v1["viadd"],
            inputs={"x": x_slice},
            outputs=[y],
            constants={
                "y": 1,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 8,
                "bw_x": 8,
                "bw_y": 8,
            },
        )
    )
    loop_body.add_output(y)

    graph = fqir.GraphProto(name="loop_parent")
    x = fqir.TensorProto("x", int, [4])
    z = fqir.TensorProto("z", int, [4])
    graph.add_input(x)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="loop_like",
            optype=fqir.registry_v1["loop"],
            inputs={"x_sliced_0": x},
            outputs=[z],
            constants={
                "n_iter": 2,
                "n_recurse": 0,
                "n_sliced": 1,
                "n_scope": 0,
                "n_concat": 1,
                "n_final": 0,
                "block_size_sliced": [2],
                "reverse_sliced": [False],
                "reverse_concat": [False],
            },
            subgraph=loop_body,
        )
    )
    graph.add_subgraph("map_loop", loop_body)

    reports = graph.analyze_loop_vectorization(backend="cpp")
    report = next(r for r in reports if r["name"] == "loop_like")
    assert report["vectorizable"] is True
    assert report["subgraph"] == "map_loop"
    assert "viadd" in report["subgraph_ops"]


def test_cpp_temporal_parallelism_analysis_finds_parallel_prefix():
    if not fqir.is_runtime_backend_available("cpp"):
        pytest.skip("cpp backend unavailable")

    init = fqir.GraphProto(name="INIT")
    state0 = fqir.TensorProto("state", int, [2], value=np.zeros(2, dtype=np.int32))
    init.add_parameter(state0)
    init.add_output(state0)

    arith = fqir.GraphProto(name="ARITH")
    x = fqir.TensorProto("x", int, [2])
    state_in = fqir.TensorProto("state", int, [2])
    x_plus = fqir.TensorProto("x_plus", int, [2])
    state_out = fqir.TensorProto("state_out", int, [2])
    arith.add_input(x)
    arith.add_input(state_in)
    arith.add_node(
        fqir.NodeProto(
            name="parallel_viadd",
            optype=fqir.registry_v1["viadd"],
            inputs={"x": x},
            outputs=[x_plus],
            constants={
                "y": 1,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 8,
                "bw_x": 8,
                "bw_y": 8,
            },
        )
    )
    arith.add_node(
        fqir.NodeProto(
            name="sequential_accum",
            optype=fqir.registry_v1["vvadd"],
            inputs={"x": x_plus, "y": state_in},
            outputs=[state_out],
            constants={
                "rounded": False,
                "shamt_x": 0,
                "shamt_y": 0,
                "shamt_bwred": 0,
                "bw": 16,
                "bw_x": 16,
                "bw_y": 16,
            },
        )
    )
    arith.add_node(
        fqir.NodeProto(
            name="state_assign",
            optype=fqir.registry_v1["assign"],
            inputs={"y": state_in, "x": state_out},
            outputs=[],
            constants={},
        )
    )
    arith.add_output(state_out)

    main = fqir.GraphProto(name="MAIN", unbind_dim=0)
    main.add_node(
        fqir.NodeProto(
            name="ARITH",
            subgraph=arith,
            inputs={"x0": x, "x1": state_in},
            outputs=[],
            optype=None,
        )
    )
    main.add_node(
        fqir.NodeProto(name="INIT", subgraph=init, inputs={}, outputs=[], optype=None)
    )
    main.add_subgraph("INIT", init)
    main.add_subgraph("ARITH", arith)
    main.inputs = [x]
    main.outputs = [state_out]

    reports = main.analyze_temporal_parallelism(backend="cpp")
    report = next(r for r in reports if r["plan_name"] == "MAIN")
    assert report["parallel_node_count"] == 1
    assert report["sequential_node_count"] == 2
    assert report["parallel_spans"][0]["node_names"] == ["parallel_viadd"]


def test_python_backend_batch_matches_default_batch():
    graph = make_vvadd_graph()
    x = np.arange(12).reshape(6, 2)
    y = np.ones((6, 2), dtype=int)

    default_out = graph.run_batch(x, y, max_workers=1)
    backend_out = graph.run_batch(x, y, max_workers=1, backend="python")

    np.testing.assert_equal(default_out, backend_out)


def test_backend_availability_api():
    assert fqir.is_runtime_backend_available("python") is True
    assert fqir.is_runtime_backend_available("cpp") in (True, False)


def test_runtime_plan_json_round_trip():
    graph = fqir.GraphProto(name="param_graph")
    x = fqir.TensorProto("x", int, [2])
    w = fqir.TensorProto("w", int, [2], value=np.array([10, 20], dtype=np.int16))
    z = fqir.TensorProto("z", int, [2])
    graph.add_input(x)
    graph.add_parameter(w)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="mul",
            optype=fqir.registry_v1["vvmul"],
            inputs={"x": x, "y": w},
            outputs=[z],
            constants={"rounded": False, "shamt_bwred": np.int64(0), "bw": 8},
        )
    )

    plan = graph.lower_runtime_plan()
    with tempfile.TemporaryDirectory() as tmpdir:
        path = Path(tmpdir) / "plan.json"
        plan.to_json(path)
        loaded = fqir.RuntimeGraphPlan.from_json(path)

    assert loaded.name == plan.name
    assert loaded.nodes[0].op_name == "vvmul"
    np.testing.assert_equal(
        loaded.parameters[0].value, np.array([10, 20], dtype=np.int16)
    )
    assert loaded.nodes[0].constants["shamt_bwred"] == 0


def test_graph_can_save_runtime_plan():
    graph = make_vvadd_graph()
    with tempfile.TemporaryDirectory() as tmpdir:
        path = Path(tmpdir) / "graph_plan.json"
        graph.save_runtime_plan(path)
        loaded = fqir.RuntimeGraphPlan.from_json(path)

    assert loaded.nodes[0].op_name == "vvadd"


def test_runtime_plan_lut_table_values_lower_to_parameter():
    class Table:
        pass

    table = Table()
    table.x = np.arange(256, dtype=np.int32)
    table.y = np.arange(256, dtype=np.int32)

    graph = fqir.GraphProto(name="lut_graph")
    x = fqir.TensorProto("x", int, [4])
    z = fqir.TensorProto("z", int, [4])
    graph.add_input(x)
    graph.add_output(z)
    graph.add_node(
        fqir.NodeProto(
            name="lut0",
            optype=fqir.registry_v1["lut"],
            inputs={"x": x},
            outputs=[z],
            constants={
                "shamt_address": 0,
                "bw_address": 8,
                "table": table,
                "function": "identity",
            },
        )
    )

    plan = graph.lower_runtime_plan()

    assert len(plan.parameters) == 1
    param = plan.parameters[0]
    assert param.name == "z.table_values"
    assert param.value == {
        "kind": "ndarray",
        "dtype": "int32",
        "shape": [256],
        "data": list(range(256)),
    }

    node = plan.nodes[0]
    assert node.inputs["x"] == "x"
    assert node.inputs["table_values"] == "z.table_values"
    assert "table" not in node.constants
    assert node.constants["table_min"] == 0
    assert node.constants["function"] == "identity"


def test_runtime_plan_includes_node_attached_subgraphs():
    body = fqir.GraphProto(name="body_only")
    x = fqir.TensorProto("x", int, [2])
    y = fqir.TensorProto("y", int, [2])
    body.add_input(x)
    body.add_node(
        fqir.NodeProto(
            name="copy",
            optype=fqir.registry_v1["copy"],
            inputs={"x": x},
            outputs=[y],
            constants={},
        )
    )
    body.add_output(y)

    main = fqir.GraphProto(name="main")
    x_in = fqir.TensorProto("x_in", int, [2])
    z = fqir.TensorProto("z", int, [2])
    main.add_input(x_in)
    main.add_output(z)
    main.add_node(
        fqir.NodeProto(
            name="loop_like",
            optype=fqir.registry_v1["loop"],
            inputs={"x_recurse_0": x_in},
            outputs=[z],
            constants={
                "n_iter": 1,
                "n_recurse": 1,
                "n_sliced": 0,
                "n_scope": 0,
                "n_concat": 0,
                "n_final": 1,
                "block_size_sliced": [],
                "reverse_sliced": [],
                "reverse_concat": [],
            },
            subgraph=body,
        )
    )

    plan = main.lower_runtime_plan()

    assert "body_only" in plan.subgraphs
    assert plan.nodes[0].subgraph == "body_only"


def test_graph_benchmark_python_backend_report_shape():
    graph = make_vvadd_graph()
    report = graph.benchmark(
        np.array([1, 2]),
        np.array([3, 4]),
        backends=("python",),
        warmup=0,
        repeat=2,
    )

    assert report.mode == "run"
    assert report.repeat == 2
    assert "python" in report.backends
    py_result = report.backends["python"]
    assert py_result.repeat == 2
    assert py_result.total_time_s >= 0
    assert py_result.avg_time_s >= 0
    assert py_result.runs_per_second >= 0
    assert report.speedup_vs_python["python"] is None


def test_graph_benchmark_batch_python_backend_report_shape():
    graph = make_vvadd_graph()
    x = np.arange(12).reshape(6, 2)
    y = np.ones((6, 2), dtype=int)
    report = graph.benchmark_batch(
        x,
        y,
        backends=("python",),
        warmup=0,
        repeat=2,
        max_workers=1,
    )

    assert report.mode == "run_batch"
    assert report.repeat == 2
    assert "python" in report.backends
    py_result = report.backends["python"]
    assert py_result.repeat == 2
    assert py_result.total_time_s >= 0
    assert py_result.avg_time_s >= 0
    assert py_result.runs_per_second >= 0
