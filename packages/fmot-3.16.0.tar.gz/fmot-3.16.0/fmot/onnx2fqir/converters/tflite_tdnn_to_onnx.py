from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import onnx
import tensorflow as tf
from onnx import TensorProto, helper, numpy_helper

from fmot.onnx2fqir.tflite_patterns import analyze_dilated_conv1d_tflite_patterns


@dataclass
class _PostOp:
    kind: str
    value: np.ndarray | None = None


@dataclass
class _TDNNLayer:
    name: str
    weight: np.ndarray
    bias: np.ndarray
    dilation: int
    post_ops: list[_PostOp]


@dataclass
class _TDNNHead:
    name: str
    kind: str
    weight: np.ndarray
    bias: np.ndarray
    input_rank: int | None = None
    endpoint_rank: int | None = None


def _make_interpreter(
    *, model_path: str | None = None, model_content: bytes | None = None
) -> tf.lite.Interpreter:
    if (model_path is None) == (model_content is None):
        raise ValueError("Provide exactly one of model_path or model_content")

    interpreter = tf.lite.Interpreter(
        model_path=model_path,
        model_content=model_content,
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()
    return interpreter


def _tensor_detail_map(interpreter: tf.lite.Interpreter) -> dict[int, dict[str, Any]]:
    return {int(detail["index"]): detail for detail in interpreter.get_tensor_details()}


def _const_tensor_value(
    interpreter: tf.lite.Interpreter, tensor_index: int
) -> np.ndarray:
    return interpreter.get_tensor(int(tensor_index))


def _conv1d_weight_from_tflite_filter(filter_value: np.ndarray) -> np.ndarray:
    if filter_value.ndim != 4 or filter_value.shape[1] != 1:
        raise ValueError(
            f"Expected TFLite Conv2D filter with shape [O,1,K,I], got {filter_value.shape}"
        )
    return np.transpose(filter_value[:, 0, :, :], (0, 2, 1)).astype(np.float32)


def _vector_for_nct_broadcast(vector: np.ndarray) -> np.ndarray:
    vector = np.asarray(vector, dtype=np.float32)
    if vector.ndim != 1:
        raise ValueError(f"Expected 1D broadcast vector, got shape {vector.shape}")
    return vector.reshape(1, vector.shape[0], 1)


def _op_name(ops: list[dict[str, Any]], index: int) -> str | None:
    if index < 0 or index >= len(ops):
        return None
    return str(ops[index]["op_name"])


def _tensor_producer_map(ops: list[dict[str, Any]]) -> dict[int, int]:
    return {
        int(tensor_index): op_index
        for op_index, op in enumerate(ops)
        for tensor_index in op["outputs"]
        if int(tensor_index) >= 0
    }


def _model_input_tensor_indices(interpreter: tf.lite.Interpreter) -> set[int]:
    return {int(detail["index"]) for detail in interpreter.get_input_details()}


def _channel_vector_value(value: np.ndarray) -> np.ndarray:
    value = np.asarray(value, dtype=np.float32)
    if value.ndim == 0:
        return value.reshape(1)

    value = np.squeeze(value)
    if value.ndim == 0:
        return value.reshape(1)
    if value.ndim != 1:
        raise ValueError(f"Expected scalar or channel vector, got shape {value.shape}")
    return value


def _elementwise_const_input_index(
    op: dict[str, Any],
    *,
    tensor_producers: dict[int, int],
    model_inputs: set[int],
) -> int:
    candidates = [
        int(tensor_index)
        for tensor_index in op["inputs"]
        if int(tensor_index) >= 0
        and int(tensor_index) not in tensor_producers
        and int(tensor_index) not in model_inputs
    ]
    if len(candidates) != 1:
        raise ValueError(
            f"Expected {op['op_name']} to have exactly one constant input, "
            f"got tensor indices {candidates}"
        )
    return candidates[0]


def _elementwise_const_value(
    interpreter: tf.lite.Interpreter,
    op: dict[str, Any],
    *,
    tensor_producers: dict[int, int],
    model_inputs: set[int],
) -> np.ndarray:
    tensor_index = _elementwise_const_input_index(
        op, tensor_producers=tensor_producers, model_inputs=model_inputs
    )
    return _channel_vector_value(_const_tensor_value(interpreter, tensor_index))


def _tflite_model_buffer(
    *, model_path: str | None, model_content: bytes | None
) -> bytes:
    if model_content is not None:
        return bytes(model_content)
    if model_path is not None:
        return Path(model_path).read_bytes()
    raise ValueError("Provide exactly one of model_path or model_content")


def _fused_activation_by_op_index(
    *, model_path: str | None, model_content: bytes | None
) -> dict[int, int]:
    from tensorflow.lite.python import schema_py_generated as tflite_schema

    model = tflite_schema.Model.GetRootAsModel(
        _tflite_model_buffer(model_path=model_path, model_content=model_content), 0
    )
    subgraph = model.Subgraphs(0)

    activations = {}
    for op_index in range(subgraph.OperatorsLength()):
        op = subgraph.Operators(op_index)
        options = op.BuiltinOptions()
        options_type = op.BuiltinOptionsType()
        if options is None:
            continue

        activation = None
        if options_type == tflite_schema.BuiltinOptions.Conv2DOptions:
            parsed = tflite_schema.Conv2DOptions()
            parsed.Init(options.Bytes, options.Pos)
            activation = parsed.FusedActivationFunction()
        elif options_type == tflite_schema.BuiltinOptions.AddOptions:
            parsed = tflite_schema.AddOptions()
            parsed.Init(options.Bytes, options.Pos)
            activation = parsed.FusedActivationFunction()
        elif options_type == tflite_schema.BuiltinOptions.MulOptions:
            parsed = tflite_schema.MulOptions()
            parsed.Init(options.Bytes, options.Pos)
            activation = parsed.FusedActivationFunction()
        elif options_type == tflite_schema.BuiltinOptions.FullyConnectedOptions:
            parsed = tflite_schema.FullyConnectedOptions()
            parsed.Init(options.Bytes, options.Pos)
            activation = parsed.FusedActivationFunction()

        if activation is not None:
            activations[op_index] = int(activation)

    return activations


def _append_fused_activation(
    post_ops: list[_PostOp], activation: int | None, *, context: str
) -> None:
    if activation in (None, 0):
        return
    if activation == 1:
        post_ops.append(_PostOp("relu"))
        return
    raise ValueError(
        f"Unsupported fused activation {activation} on {context}; only RELU is supported."
    )


def _consume_elementwise_post_ops(
    *,
    interpreter: tf.lite.Interpreter,
    ops: list[dict[str, Any]],
    cursor: int,
    post_ops: list[_PostOp],
    fused_activation_by_op_index: dict[int, int],
    tensor_producers: dict[int, int],
    model_inputs: set[int],
    stop_at: int | None = None,
) -> int:
    while cursor < len(ops) and (stop_at is None or cursor < stop_at):
        op_name = _op_name(ops, cursor)
        op = ops[cursor]
        if op_name == "RELU":
            post_ops.append(_PostOp("relu"))
            cursor += 1
            continue

        if op_name in {"MUL", "ADD"}:
            value = _elementwise_const_value(
                interpreter,
                op,
                tensor_producers=tensor_producers,
                model_inputs=model_inputs,
            )
            post_ops.append(_PostOp(op_name.lower(), value))
            _append_fused_activation(
                post_ops,
                fused_activation_by_op_index.get(cursor),
                context=f"{op_name} op {cursor}",
            )
            cursor += 1
            continue

        break

    return cursor


def _serialize_hidden_layer(
    *,
    interpreter: tf.lite.Interpreter,
    tensor_map: dict[int, dict[str, Any]],
    conv_op: dict[str, Any],
    dilation: int,
    post_ops: list[_PostOp] | None = None,
    name: str,
) -> _TDNNLayer:
    filter_value = _const_tensor_value(interpreter, int(conv_op["inputs"][1]))
    bias_value = _const_tensor_value(interpreter, int(conv_op["inputs"][2])).astype(
        np.float32
    )

    return _TDNNLayer(
        name=name,
        weight=_conv1d_weight_from_tflite_filter(filter_value),
        bias=bias_value,
        dilation=dilation,
        post_ops=list(post_ops or []),
    )


def _serialize_fully_connected_head(
    *,
    interpreter: tf.lite.Interpreter,
    tensor_map: dict[int, dict[str, Any]],
    fc_op: dict[str, Any],
    name: str,
) -> _TDNNHead:
    weight_value = _const_tensor_value(interpreter, int(fc_op["inputs"][1])).astype(
        np.float32
    )
    if weight_value.ndim != 2:
        raise ValueError(
            f"Expected TFLite FullyConnected weights with shape [O,I], got {weight_value.shape}"
        )

    bias_value = np.zeros(weight_value.shape[0], dtype=np.float32)
    if len(fc_op["inputs"]) > 2 and int(fc_op["inputs"][2]) >= 0:
        bias_value = _const_tensor_value(interpreter, int(fc_op["inputs"][2])).astype(
            np.float32
        )

    input_rank = None
    input_tensor_index = int(fc_op["inputs"][0])
    if input_tensor_index >= 0:
        input_rank = len(tensor_map[input_tensor_index]["shape"])

    output_rank = None
    output_tensor_index = int(fc_op["outputs"][0])
    if output_tensor_index >= 0:
        output_rank = len(tensor_map[output_tensor_index]["shape"])

    # TFLite FULLY_CONNECTED may present ambiguous input ranks across exports.
    # The output rank is the more reliable signal:
    # - rank 3 means a per-timestep projection
    # - rank 2 means a flattened endpoint classifier
    if output_rank is not None:
        input_rank = output_rank

    return _TDNNHead(
        name=name,
        kind="fully_connected",
        weight=weight_value,
        bias=bias_value,
        input_rank=input_rank,
    )


def _parse_tdnn_layers(
    interpreter: tf.lite.Interpreter,
    *,
    model_path: str | None,
    model_content: bytes | None,
) -> tuple[list[_TDNNLayer], _TDNNHead]:
    tensor_map = _tensor_detail_map(interpreter)
    ops = interpreter._get_ops_details()
    tensor_producers = _tensor_producer_map(ops)
    model_inputs = _model_input_tensor_indices(interpreter)
    fused_activation_by_op_index = _fused_activation_by_op_index(
        model_path=model_path,
        model_content=model_content,
    )
    pattern_analysis = analyze_dilated_conv1d_tflite_patterns(
        model_path=model_path,
        model_content=model_content,
    )
    pattern_matches = pattern_analysis["pattern_matches"]
    pattern_starts = {match["match_start_op_index"] for match in pattern_matches}

    hidden_layers: list[_TDNNLayer] = []

    cursor = 0
    layer_index = 1

    while cursor < len(ops) and cursor not in pattern_starts:
        if (
            _op_name(ops, cursor) == "EXPAND_DIMS"
            and _op_name(ops, cursor + 1) == "CONV_2D"
        ):
            conv_op_index = cursor + 1
            post_ops = []
            _append_fused_activation(
                post_ops,
                fused_activation_by_op_index.get(conv_op_index),
                context=f"CONV_2D op {conv_op_index}",
            )
            reshape_index = _consume_elementwise_post_ops(
                interpreter=interpreter,
                ops=ops,
                cursor=conv_op_index + 1,
                post_ops=post_ops,
                fused_activation_by_op_index=fused_activation_by_op_index,
                tensor_producers=tensor_producers,
                model_inputs=model_inputs,
            )
            if _op_name(ops, reshape_index) != "RESHAPE":
                break

            hidden_layers.append(
                _serialize_hidden_layer(
                    interpreter=interpreter,
                    tensor_map=tensor_map,
                    conv_op=ops[conv_op_index],
                    dilation=1,
                    post_ops=post_ops,
                    name=f"tdnn{layer_index}",
                )
            )
            cursor = reshape_index + 1
            layer_index += 1
            continue

        break

    if not hidden_layers:
        prefix_preview = " -> ".join(_op_name(ops, i) for i in range(min(8, len(ops))))
        raise ValueError(
            "Unsupported TDNN prefix: expected at least one fused Conv1D block, "
            f"got {prefix_preview}"
        )

    for match in pattern_matches:
        if hidden_layers:
            cursor = _consume_elementwise_post_ops(
                interpreter=interpreter,
                ops=ops,
                cursor=cursor,
                post_ops=hidden_layers[-1].post_ops,
                fused_activation_by_op_index=fused_activation_by_op_index,
                tensor_producers=tensor_producers,
                model_inputs=model_inputs,
                stop_at=match["match_start_op_index"],
            )

        if match["match_start_op_index"] != cursor:
            raise ValueError(
                f"Unsupported TDNN body: expected dilated-conv match at op {cursor}, "
                f"got {match['match_start_op_index']}"
            )

        conv_op_index = next(
            op["op_index"] for op in match["ops"] if op["op_name"] == "CONV_2D"
        )
        post_ops = []
        _append_fused_activation(
            post_ops,
            fused_activation_by_op_index.get(conv_op_index),
            context=f"CONV_2D op {conv_op_index}",
        )
        if match["bias_add"] is not None:
            bias_add_op_index = next(
                op["op_index"] for op in match["ops"] if op["op_name"] == "ADD"
            )
            bias_add_op = ops[bias_add_op_index]
            post_ops.append(
                _PostOp(
                    "add",
                    _elementwise_const_value(
                        interpreter,
                        bias_add_op,
                        tensor_producers=tensor_producers,
                        model_inputs=model_inputs,
                    ),
                )
            )
            _append_fused_activation(
                post_ops,
                fused_activation_by_op_index.get(bias_add_op_index),
                context=f"ADD op {bias_add_op_index}",
            )

        cursor = match["match_end_op_index"] + 1

        hidden_layers.append(
            _serialize_hidden_layer(
                interpreter=interpreter,
                tensor_map=tensor_map,
                conv_op=ops[conv_op_index],
                dilation=int(match["derived"]["inferred_dilation"]),
                post_ops=post_ops,
                name=f"tdnn{layer_index}",
            )
        )
        layer_index += 1

    if hidden_layers:
        cursor = _consume_elementwise_post_ops(
            interpreter=interpreter,
            ops=ops,
            cursor=cursor,
            post_ops=hidden_layers[-1].post_ops,
            fused_activation_by_op_index=fused_activation_by_op_index,
            tensor_producers=tensor_producers,
            model_inputs=model_inputs,
        )

    tail_ops = [_op_name(ops, i) for i in range(cursor, len(ops))]
    if not tail_ops or tail_ops[-1] != "SOFTMAX":
        raise ValueError(
            "Unsupported TDNN tail: expected a tail ending in SOFTMAX, "
            f"got {' -> '.join(tail_ops) if tail_ops else '<empty>'}"
        )

    tail_without_softmax = tail_ops[:-1]

    fc_positions = [
        i
        for i, op_name in enumerate(tail_without_softmax)
        if op_name == "FULLY_CONNECTED"
    ]
    conv_positions = [
        i for i, op_name in enumerate(tail_without_softmax) if op_name == "CONV_2D"
    ]

    if fc_positions:
        fc_rel_index = fc_positions[-1]
        fc_abs_index = cursor + fc_rel_index
        trailing_ops = tail_without_softmax[fc_rel_index + 1 :]
        if any(op_name != "RESHAPE" for op_name in trailing_ops):
            raise ValueError(
                "Unsupported FULLY_CONNECTED TDNN tail: expected only optional RESHAPE ops "
                f"after FULLY_CONNECTED, got {' -> '.join(tail_ops)}"
            )

        head_layer = _serialize_fully_connected_head(
            interpreter=interpreter,
            tensor_map=tensor_map,
            fc_op=ops[fc_abs_index],
            name="tdnn_head",
        )
    elif conv_positions:
        conv_rel_index = conv_positions[-1]
        conv_abs_index = cursor + conv_rel_index
        leading_ops = tail_without_softmax[:conv_rel_index]
        trailing_ops = tail_without_softmax[conv_rel_index + 1 :]

        if "EXPAND_DIMS" not in leading_ops:
            raise ValueError(
                "Unsupported CONV_2D TDNN tail: expected EXPAND_DIMS before CONV_2D, "
                f"got {' -> '.join(tail_ops)}"
            )
        if any(op_name != "RESHAPE" for op_name in trailing_ops):
            raise ValueError(
                "Unsupported CONV_2D TDNN tail: expected only optional RESHAPE ops "
                f"after CONV_2D, got {' -> '.join(tail_ops)}"
            )

        conv_head = _serialize_hidden_layer(
            interpreter=interpreter,
            tensor_map=tensor_map,
            conv_op=ops[conv_abs_index],
            dilation=1,
            post_ops=[],
            name="tdnn_head",
        )
        if fused_activation_by_op_index.get(conv_abs_index) not in (None, 0):
            raise ValueError(
                "Unsupported CONV_2D TDNN tail: fused activation on semantic head "
                f"op {conv_abs_index} is not supported."
            )
        head_layer = _TDNNHead(
            name=conv_head.name,
            kind="conv",
            weight=conv_head.weight,
            bias=conv_head.bias,
        )
    else:
        raise ValueError(
            "Unsupported TDNN tail: expected a semantic head ending in SOFTMAX, "
            f"got {' -> '.join(tail_ops)}"
        )

    return hidden_layers, head_layer


def convert_tdnn_tflite_to_onnx(
    *,
    model_path: str | None = None,
    model_content: bytes | None = None,
    opset_version: int = 18,
) -> onnx.ModelProto:
    interpreter = _make_interpreter(model_path=model_path, model_content=model_content)
    hidden_layers, head_layer = _parse_tdnn_layers(
        interpreter,
        model_path=model_path,
        model_content=model_content,
    )

    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]

    input_name = str(input_detail["name"])
    output_name = str(output_detail["name"])
    model_output_rank = len(output_detail["shape"])

    batch_dim = "batch"
    input_shape = [batch_dim] + [int(v) for v in input_detail["shape"][1:]]
    output_shape = [batch_dim] + [int(v) for v in output_detail["shape"][1:]]

    if head_layer.kind == "fully_connected":
        head_layer.endpoint_rank = model_output_rank

    nodes = []
    initializers = []

    current_name = input_name
    current_name_nct = f"{input_name}_nct"
    nodes.append(
        helper.make_node(
            "Transpose",
            [current_name],
            [current_name_nct],
            name="input_to_nct",
            perm=[0, 2, 1],
        )
    )
    current_name = current_name_nct

    def add_initializer(name: str, value: np.ndarray) -> str:
        initializers.append(
            numpy_helper.from_array(np.asarray(value, dtype=np.float32), name)
        )
        return name

    for layer in hidden_layers:
        weight_name = add_initializer(f"{layer.name}_W", layer.weight)
        bias_name = add_initializer(f"{layer.name}_B", layer.bias)

        conv_out = f"{layer.name}_conv"
        nodes.append(
            helper.make_node(
                "Conv",
                [current_name, weight_name, bias_name],
                [conv_out],
                name=conv_out,
                dilations=[int(layer.dilation)],
                strides=[1],
                auto_pad="VALID",
                kernel_shape=[int(layer.weight.shape[-1])],
            )
        )
        current_name = conv_out

        for post_op_index, post_op in enumerate(layer.post_ops):
            post_op_name = f"{layer.name}_{post_op.kind}_{post_op_index}"
            if post_op.kind == "relu":
                nodes.append(
                    helper.make_node(
                        "Relu", [current_name], [post_op_name], name=post_op_name
                    )
                )
                current_name = post_op_name
                continue

            if post_op.value is None:
                raise ValueError(f"{post_op.kind} post-op is missing a constant value")
            value_name = add_initializer(
                f"{post_op_name}_value", _vector_for_nct_broadcast(post_op.value)
            )
            onnx_op_type = {"mul": "Mul", "add": "Add"}[post_op.kind]
            nodes.append(
                helper.make_node(
                    onnx_op_type,
                    [current_name, value_name],
                    [post_op_name],
                    name=post_op_name,
                )
            )
            current_name = post_op_name

    softmax_axis = 2

    if head_layer.kind == "conv":
        weight_name = add_initializer(f"{head_layer.name}_W", head_layer.weight)
        bias_name = add_initializer(f"{head_layer.name}_B", head_layer.bias)
        head_out = f"{head_layer.name}_conv"
        nodes.append(
            helper.make_node(
                "Conv",
                [current_name, weight_name, bias_name],
                [head_out],
                name=head_out,
                dilations=[1],
                strides=[1],
                auto_pad="VALID",
                kernel_shape=[int(head_layer.weight.shape[-1])],
            )
        )
        current_name = head_out

        btc_name = f"{output_name}_pre_softmax"
        nodes.append(
            helper.make_node(
                "Transpose",
                [current_name],
                [btc_name],
                name="output_to_btc",
                perm=[0, 2, 1],
            )
        )
    elif head_layer.kind == "fully_connected":
        matmul_weight_name = add_initializer(
            f"{head_layer.name}_W", np.asarray(head_layer.weight.T, dtype=np.float32)
        )

        is_flat_endpoint = head_layer.endpoint_rank == 2
        if head_layer.endpoint_rank is None:
            is_flat_endpoint = head_layer.input_rank == 2

        if is_flat_endpoint:
            btc_input = f"{head_layer.name}_btc"
            nodes.append(
                helper.make_node(
                    "Transpose",
                    [current_name],
                    [btc_input],
                    name=f"{head_layer.name}_to_btc",
                    perm=[0, 2, 1],
                )
            )
            flatten_output = f"{head_layer.name}_flatten"
            nodes.append(
                helper.make_node(
                    "Flatten",
                    [btc_input],
                    [flatten_output],
                    name=f"{head_layer.name}_flatten",
                    axis=1,
                )
            )
            btc_name = f"{output_name}_pre_softmax"
            nodes.append(
                helper.make_node(
                    "MatMul",
                    [flatten_output, matmul_weight_name],
                    [btc_name],
                    name=f"{head_layer.name}_matmul",
                )
            )
            softmax_axis = 1
        else:
            btc_input = f"{head_layer.name}_btc"
            nodes.append(
                helper.make_node(
                    "Transpose",
                    [current_name],
                    [btc_input],
                    name=f"{head_layer.name}_to_btc",
                    perm=[0, 2, 1],
                )
            )
            btc_name = f"{output_name}_pre_softmax"
            nodes.append(
                helper.make_node(
                    "MatMul",
                    [btc_input, matmul_weight_name],
                    [btc_name],
                    name=f"{head_layer.name}_matmul",
                )
            )

        if np.any(head_layer.bias):
            bias_name = add_initializer(
                f"{head_layer.name}_B",
                np.asarray(head_layer.bias, dtype=np.float32),
            )
            biased_name = f"{btc_name}_biased"
            nodes.append(
                helper.make_node(
                    "Add",
                    [btc_name, bias_name],
                    [biased_name],
                    name=f"{head_layer.name}_bias",
                )
            )
            btc_name = biased_name
    else:
        raise ValueError(f"Unsupported TDNN head kind: {head_layer.kind}")

    nodes.append(
        helper.make_node(
            "Softmax",
            [btc_name],
            [output_name],
            name="output_softmax",
            axis=softmax_axis,
        )
    )

    graph = helper.make_graph(
        nodes,
        "tflite_tdnn",
        inputs=[
            helper.make_tensor_value_info(input_name, TensorProto.FLOAT, input_shape)
        ],
        outputs=[
            helper.make_tensor_value_info(output_name, TensorProto.FLOAT, output_shape)
        ],
        initializer=initializers,
    )

    model = helper.make_model(
        graph,
        producer_name="fmot.tflite_tdnn_to_onnx",
        opset_imports=[helper.make_opsetid("", opset_version)],
    )
    # Some deployed onnxruntime builds in our environments only support IR <= 11.
    model.ir_version = min(onnx.IR_VERSION, 11)
    onnx.checker.check_model(model)
    return model
