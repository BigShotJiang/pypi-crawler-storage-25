import logging
import os


class SessionManagerFileHandler(logging.FileHandler):
    def __init__(self, **kwargs):
        file_name = kwargs.pop("file_name")
        log_path = "/var/log/apps"
        log_filename = "{0}/{1}.log".format(log_path, file_name)
        try:
            os.makedirs(os.path.dirname(log_filename), exist_ok=True)
        except:
            log_filename = "/tmp" + log_filename
            os.makedirs(os.path.dirname(log_filename), exist_ok=True)
        super(SessionManagerFileHandler, self).__init__(
            filename=log_filename, **kwargs
        )


STUDIO_LOG_DIR = "/var/log/studio/sagemaker_connection_magic"
STUDIO_LOG_FILE = "sagemaker_connection_magic.log"


def setup_logger(logger, name, file_name, level=logging.INFO):
    logger.name = name
    logger.setLevel(level)

    logger.propagate = True
    log_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler = SessionManagerFileHandler(file_name=file_name)
    file_handler.setFormatter(log_formatter)
    logger.addHandler(file_handler)

    try:
        os.makedirs(STUDIO_LOG_DIR, exist_ok=True)
        studio_handler = logging.FileHandler(os.path.join(STUDIO_LOG_DIR, STUDIO_LOG_FILE))
        studio_handler.setFormatter(log_formatter)
        logger.addHandler(studio_handler)
    except OSError as e:
        logger.error("Failed to set up studio log handler at %s: %s", STUDIO_LOG_DIR, e)
