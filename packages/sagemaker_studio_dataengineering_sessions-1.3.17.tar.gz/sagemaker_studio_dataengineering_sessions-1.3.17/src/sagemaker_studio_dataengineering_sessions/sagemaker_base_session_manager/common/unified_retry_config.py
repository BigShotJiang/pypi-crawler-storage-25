"""
Unified retry configuration using default values.
"""

import logging
from typing import Dict, Any

from .constants import (
    SAGEMAKER_DEFAULT_RETRY_MAX_TIMEOUT_SECS,
    SAGEMAKER_DEFAULT_RETRY_INITIAL_DELAY_SECS,
    SAGEMAKER_DEFAULT_RETRY_INITIAL_DELAY_SECS_FOR_GET_DASHBOARD,
    SAGEMAKER_DEFAULT_RETRY_BACKOFF_FACTOR,
    SAGEMAKER_DEFAULT_RETRY_MAX_DELAY_SECS,
    EMR_SERVERLESS_GET_DASHBOARD_OPERATION,
)

logger = logging.getLogger(__name__)


class UnifiedRetryConfig:
    """Unified configuration for retry behavior using default values."""
    
    def __init__(self):
        self._config_cache = {}
    
    def get_config(self, operation_type: str) -> Dict[str, Any]:
        """Get retry configuration for AWS service operations.
        
        Args:
            operation_type: AWS service.api identifier (e.g., 'emr_serverless.get_application')
        """
        if operation_type in self._config_cache:
            return self._config_cache[operation_type]
        
        config = self._build_config(operation_type)
        
        self._config_cache[operation_type] = config
        return config
    
    def _build_config(self, operation_type: str = '') -> Dict[str, Any]:
        """Build configuration using default values."""
        # Get defaults based on operation type
        default_initial_delay = SAGEMAKER_DEFAULT_RETRY_INITIAL_DELAY_SECS_FOR_GET_DASHBOARD if operation_type == EMR_SERVERLESS_GET_DASHBOARD_OPERATION else SAGEMAKER_DEFAULT_RETRY_INITIAL_DELAY_SECS
        
        return {
            'max_timeout': SAGEMAKER_DEFAULT_RETRY_MAX_TIMEOUT_SECS,
            'max_delay': SAGEMAKER_DEFAULT_RETRY_MAX_DELAY_SECS,
            'initial_delay': default_initial_delay,
            'backoff_factor': SAGEMAKER_DEFAULT_RETRY_BACKOFF_FACTOR
        }
    

    def clear_config_cache(self):
        """Clear configuration cache."""
        self._config_cache.clear()


# Global instance for easy access
unified_retry_config = UnifiedRetryConfig()