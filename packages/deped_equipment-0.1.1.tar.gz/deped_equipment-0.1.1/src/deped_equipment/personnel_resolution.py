"""Personnel-resolution helpers for equipment builds."""

from __future__ import annotations

import sqlite3
from typing import cast

from deped_dcp_template.cleaners import (
    clean_text,
    parse_person_reference,
    person_name_key,
)

from .types import (
    EntityEmployeeKey,
    EntityNameKey,
    GovernanceScopeKey,
    LocalPersonnelResolutionRow,
    PersonnelResolutionLookups,
    PersonResolutionResult,
    ScopeEmployeeKey,
)


def governance_scope_key(
    entity_type: str, region: str | None, division: str | None
) -> GovernanceScopeKey:
    """Return the approved governance-scope fallback key."""
    if entity_type == "REGIONAL_OFFICE":
        return ("REGION", region or "", "")
    return ("DIVISION", region or "", division or "")


def build_personnel_resolution_lookups(
    conn: sqlite3.Connection,
) -> PersonnelResolutionLookups:
    """Build unique personnel lookups used for equipment-person resolution."""
    entity_employee_counts: dict[EntityEmployeeKey, list[int]] = {}
    scope_employee_counts: dict[ScopeEmployeeKey, list[int]] = {}
    entity_name_counts: dict[EntityNameKey, list[int]] = {}
    source_rows = cast(
        list[LocalPersonnelResolutionRow],
        conn.execute(
            """
            SELECT p.id, p.entity_id, p.employee_id, p.full_name, e.entity_type, e.region, e.division
            FROM personnel p
            JOIN entities e ON e.entity_id = p.entity_id
            """
        ).fetchall(),
    )
    for (
        person_id,
        entity_id,
        employee_id,
        full_name,
        entity_type,
        region,
        division,
    ) in source_rows:
        if employee_id:
            entity_employee_counts.setdefault((entity_id, employee_id), []).append(
                person_id
            )
            scope_key = governance_scope_key(entity_type, region, division)
            scope_employee_counts.setdefault((*scope_key, employee_id), []).append(
                person_id
            )
        name_key = person_name_key(full_name)
        if name_key:
            entity_name_counts.setdefault((entity_id, name_key), []).append(person_id)

    def split_unique[TKey](
        values: dict[TKey, list[int]],
    ) -> tuple[dict[TKey, int], set[TKey]]:
        unique: dict[TKey, int] = {}
        ambiguous: set[TKey] = set()
        for key, person_ids in values.items():
            if len(person_ids) == 1:
                unique[key] = person_ids[0]
            else:
                ambiguous.add(key)
        return unique, ambiguous

    entity_employee, entity_employee_ambiguous = split_unique(entity_employee_counts)
    scope_employee, scope_employee_ambiguous = split_unique(scope_employee_counts)
    entity_name, entity_name_ambiguous = split_unique(entity_name_counts)
    return {
        "entity_employee": entity_employee,
        "entity_employee_ambiguous": entity_employee_ambiguous,
        "scope_employee": scope_employee,
        "scope_employee_ambiguous": scope_employee_ambiguous,
        "entity_name": entity_name,
        "entity_name_ambiguous": entity_name_ambiguous,
    }


def resolve_person_reference(
    raw_value: str | None,
    entity_id: int,
    entity_type: str,
    region: str | None,
    division: str | None,
    resolution_lookups: PersonnelResolutionLookups,
) -> PersonResolutionResult:
    """Resolve a freeform equipment-person reference to a personnel row."""
    normalized_name, employee_id = parse_person_reference(raw_value)
    if clean_text(raw_value) is None:
        return None, None, None, "no_input"

    if employee_id:
        entity_key = (entity_id, employee_id)
        if entity_key in resolution_lookups["entity_employee"]:
            return (
                resolution_lookups["entity_employee"][entity_key],
                normalized_name,
                employee_id,
                "matched_by_employee_id",
            )
        if entity_key in resolution_lookups["entity_employee_ambiguous"]:
            return None, normalized_name, employee_id, "ambiguous"

        scope_key = (*governance_scope_key(entity_type, region, division), employee_id)
        if scope_key in resolution_lookups["scope_employee"]:
            return (
                resolution_lookups["scope_employee"][scope_key],
                normalized_name,
                employee_id,
                "matched_by_employee_id",
            )
        if scope_key in resolution_lookups["scope_employee_ambiguous"]:
            return None, normalized_name, employee_id, "ambiguous"

    name_key = person_name_key(normalized_name)
    if name_key:
        entity_name_key = (entity_id, name_key)
        if entity_name_key in resolution_lookups["entity_name"]:
            return (
                resolution_lookups["entity_name"][entity_name_key],
                normalized_name,
                employee_id,
                "matched_by_name",
            )
        if entity_name_key in resolution_lookups["entity_name_ambiguous"]:
            return None, normalized_name, employee_id, "ambiguous"

    return None, normalized_name, employee_id, "unmatched"
