from __future__ import annotations

from collections import Counter
from typing import Literal, TypeAlias, TypedDict

CsvRow: TypeAlias = dict[str, str]
EntityEmployeeKey: TypeAlias = tuple[int, str]
EntityNameKey: TypeAlias = tuple[int, str]
EntityIdRow: TypeAlias = tuple[int]
EntityLookup: TypeAlias = dict[str, int]
CanonicalNameLookup: TypeAlias = dict[str, int]
CanonicalNameRow: TypeAlias = tuple[str]
PackageLookupRow: TypeAlias = tuple[str, str | None]
PersonnelSnapshotRow: TypeAlias = tuple[int, str | None]
ImportedPersonnelResolutionRow: TypeAlias = tuple[
    int,
    str | None,
    str | None,
    str,
    str,
    str | None,
    str | None,
]
LocalPersonnelResolutionRow: TypeAlias = tuple[
    int,
    int,
    str | None,
    str | None,
    str,
    str | None,
    str | None,
]
GovernanceScope = Literal["REGION", "DIVISION"]
GovernanceScopeKey: TypeAlias = tuple[GovernanceScope, str, str]
ScopeEmployeeKey: TypeAlias = tuple[GovernanceScope, str, str, str]
SqlValue: TypeAlias = str | int | float | None

ResolutionStatus = Literal[
    "no_input",
    "matched_by_employee_id",
    "matched_by_name",
    "ambiguous",
    "unmatched",
]

EquipmentIssueKey: TypeAlias = tuple[str, str, str]
EquipmentIssueCounter: TypeAlias = Counter[EquipmentIssueKey]
EquipmentIssueRow: TypeAlias = tuple[str, str, str, str, int, int | None]
DateErrorRow: TypeAlias = tuple[str, str, int, int | None, str, str]
DateParseCandidate: TypeAlias = tuple[str, str | None, str | None]
PersonResolutionResult: TypeAlias = tuple[
    int | None, str | None, str | None, ResolutionStatus
]
EquipmentColumns: TypeAlias = tuple[str, ...]
EquipmentInsertRow: TypeAlias = tuple[SqlValue, ...]


class EntityRecord(TypedDict):
    entity_type: str
    school_id: int | None
    entity_name: str | None
    region: str | None
    division: str | None
    office_unit_name: str | None
    natural_key: str
    has_personnel: int
    has_equipment: int


class EntityAccumulator(TypedDict):
    entity_type: str
    school_id: int | None
    region: str | None
    division: str | None
    entity_name_counts: Counter[str]
    office_unit_counts: Counter[str]
    has_personnel: int
    has_equipment: int


class PersonnelResolutionLookups(TypedDict):
    entity_employee: dict[EntityEmployeeKey, int]
    entity_employee_ambiguous: set[EntityEmployeeKey]
    scope_employee: dict[ScopeEmployeeKey, int]
    scope_employee_ambiguous: set[ScopeEmployeeKey]
    entity_name: dict[EntityNameKey, int]
    entity_name_ambiguous: set[EntityNameKey]


class LookupMaps(TypedDict):
    equipment_items: CanonicalNameLookup
    equipment_brands: CanonicalNameLookup
    equipment_units: CanonicalNameLookup
    equipment_acquisition_modes: CanonicalNameLookup
    equipment_acquisition_mode_aliases: dict[str, str]
    equipment_acquisition_sources: CanonicalNameLookup
    equipment_categories: CanonicalNameLookup
    equipment_dcp_packages: CanonicalNameLookup
    equipment_dcp_attributions: CanonicalNameLookup
    equipment_dcp_attribution_aliases: dict[str, str]
    equipment_dcp_attribution_types: dict[str, str]
    equipment_locations: CanonicalNameLookup
    equipment_location_aliases: dict[str, str]
    equipment_suppliers: CanonicalNameLookup
    equipment_supplier_aliases: dict[str, str]
    equipment_disposition_statuses: CanonicalNameLookup
    equipment_disposition_status_aliases: dict[str, str]
    equipment_source_of_funds: CanonicalNameLookup
    equipment_source_of_funds_aliases: dict[str, str]
    equipment_donor_aliases: dict[str, str]
    equipment_conditions: CanonicalNameLookup
    equipment_condition_aliases: dict[str, str]
    equipment_dcp_years: CanonicalNameLookup
    equipment_models: CanonicalNameLookup
    # DCP cross-validation lookups (populated when --dcp-dataset-db is supplied)
    equipment_item_id_to_canonical: dict[int, str]  # item_id → canonical_name
    equipment_dcp_year_id_to_int: dict[int, int]  # dcp_year_package_id → integer year
    co_acquisition_source_ids: set[int]  # source_of_acquisition_ids for Central Office
