"""DCP procurement dataset loading and equipment cross-validation.

Implements the matching strategy validated by scripts/dcp_prototype.py.
See docs/dcp-cross-validation.md for the full rationale for each decision
(component map, year resolution, match types).

Primary concern: unit quantity first, cost second.
"""

from __future__ import annotations

import sqlite3
from contextlib import closing
from pathlib import Path

# ── Component Mapping ────────────────────────────────────────────────────────
# equipment canonical name → ordered list of DCP component names.
# One-to-many: matching tries each DCP component in list order and takes the
# first hit. Unit coverage is tracked per DCP component so Host Laptop and
# Laptop deliveries each show their own gap.
#
# Excluded intentionally:
#   "Tablet"                   — different product line (6,999–12,000/unit CO
#                                vs 13,000–15,000/unit DCP); school 303172.
#   "Thin Client Server (Set)" — pre-2018 thin-client era; DCP only covers
#                                2018+. no_match is expected, not an error.
DCP_COMPONENT_MAP: dict[str, list[str]] = {
    "Laptop": ["Laptop", "Host Laptop", "Specialized Laptop"],
    "2-In-1 Tablet": ["2-in-1 Tablet PC"],
    "Smart TV": ["Smart TV"],
    "External Hard Drive": ["External Hard Drive"],
    "Charging Cart": ["Charging Cart"],
    "Modem / Router": ["Wireless Router"],
    "Lapel": ["Lapel"],
    "AVR": ["AVR"],
    "Multifunction Printer": ["3-in-1 Multifunction Inkjet Printer"],
    "Desktop (Package)": ["Standalone PC", "Desktop"],
    "Standard TV": ["LED Television"],
}

# Type aliases for the two lookup structures used during matching.
# Keys use DCP component names (not equipment canonical names) because one
# equipment name maps to multiple DCP components.
DcpCostKey = tuple[int, int, str]  # (school_id, year, dcp_component)
DcpCostLookup = dict[
    DcpCostKey, tuple[float, str]
]  # → (min_unit_cost, supplier_of_min)
DcpBySchoolComponent = dict[
    tuple[int, str],  # (school_id, dcp_component)
    list[tuple[int, float, str]],  # [(year, min_cost, supplier)] desc
]

CO_SOURCE_CANONICAL = "Central Office"


# ── Lookup Construction ──────────────────────────────────────────────────────


def load_dcp_lookups(
    dcp_dataset_db: str | Path,
) -> tuple[DcpCostLookup, DcpBySchoolComponent]:
    """Load DCP delivery records from the procurement dataset into memory.

    Returns two lookup structures used by resolve_dcp_cost():

    dcp_cost_lookup
        (school_id, year, dcp_component) → (min_unit_cost, supplier_of_min_lot)
        Stores the minimum unit cost per key to give schools the most
        favourable baseline before flagging overstated costs.

    dcp_by_school_component
        (school_id, dcp_component) → [(year, min_cost, supplier)] sorted desc
        Used by the date-ceiling fallback: find the most recent DCP year ≤
        the ceiling derived from acquisition_date / date_received_new.
    """
    dcp_cost_lookup: DcpCostLookup = {}
    # Intermediate: accumulate all (cost, supplier) per key to find minimum.
    _lots: dict[DcpCostKey, list[tuple[float, str]]] = {}

    with closing(sqlite3.connect(dcp_dataset_db)) as conn:
        rows = conn.execute(
            """
            SELECT d.school_id,
                   d.year,
                   ci.package_component,
                   d.unit_actual_cost,
                   COALESCE(NULLIF(TRIM(s.supplier), ''), 'Unknown')
            FROM dcp d
            JOIN dcp_component_items ci ON ci.id = d.component_id
            JOIN dcp_suppliers s ON s.id = d.supplier_id
            WHERE ci.package_component IN ({})
            """.format(",".join("?" * sum(len(v) for v in DCP_COMPONENT_MAP.values()))),
            [comp for comps in DCP_COMPONENT_MAP.values() for comp in comps],
        ).fetchall()

    for school_id, year, component, cost, supplier in rows:
        key: DcpCostKey = (school_id, year, component)
        _lots.setdefault(key, []).append((cost, supplier))

    for key, lots in _lots.items():
        min_cost, min_supplier = min(lots, key=lambda t: t[0])
        dcp_cost_lookup[key] = (min_cost, min_supplier)

    # Build fallback lookup: per (school_id, component), sorted by year desc.
    by_sc: dict[tuple[int, str], list[tuple[int, float, str]]] = {}
    for (school_id, year, component), (
        min_cost,
        min_supplier,
    ) in dcp_cost_lookup.items():
        by_sc.setdefault((school_id, component), []).append(
            (year, min_cost, min_supplier)
        )
    for entries in by_sc.values():
        entries.sort(key=lambda t: t[0], reverse=True)

    return dcp_cost_lookup, by_sc


def load_dcp_delivery_rows(
    dcp_dataset_db: str | Path,
) -> list[tuple[int, int, str, int, int, int, float, str]]:
    """Return all DCP delivery rows for seeding dcp_delivery_summary.

    Each row: (school_id, year, component, pkg_count, units_per_pkg,
               expected_units, unit_cost, supplier)
    """
    with closing(sqlite3.connect(dcp_dataset_db)) as conn:
        return conn.execute(
            """
            SELECT d.school_id,
                   d.year,
                   ci.package_component,
                   d.pkg_count,
                   d.units_per_pkg,
                   d.pkg_count * d.units_per_pkg,
                   d.unit_actual_cost,
                   COALESCE(NULLIF(TRIM(s.supplier), ''), 'Unknown')
            FROM dcp d
            JOIN dcp_component_items ci ON ci.id = d.component_id
            JOIN dcp_suppliers s ON s.id = d.supplier_id
            WHERE ci.package_component IN ({})
            """.format(",".join("?" * sum(len(v) for v in DCP_COMPONENT_MAP.values()))),
            [comp for comps in DCP_COMPONENT_MAP.values() for comp in comps],
        ).fetchall()


# ── Year Resolution Helpers ──────────────────────────────────────────────────


def _year_from_date(date_str: str | None) -> int | None:
    """Extract the year from a YYYY-MM-DD date string."""
    if not date_str or len(date_str) < 4:
        return None
    try:
        return int(date_str[:4])
    except ValueError:
        return None


def _resolve_dcp_match(
    school_id: int,
    year_int: int | None,
    acq_date: str | None,
    date_received: str | None,
    dcp_components: list[str],
    dcp_cost_lookup: DcpCostLookup,
    dcp_by_school_component: DcpBySchoolComponent,
) -> tuple[str, float | None, int | None, str | None, str | None]:
    """Try to match one CO equipment row against its possible DCP components.

    Returns (match_type, dcp_cost, dcp_year, dcp_component, dcp_supplier).

    Primary path:
        Exact (school_id, year_int, dcp_component) lookup for each component
        in list order; takes the first hit.

    Fallback path:
        Derive a year ceiling from acquisition_date or date_received_new.
        Walk DCP entries for (school_id, component) desc by year and take the
        first entry with dcp.year ≤ ceiling.

    Note: when year_int is set but no exact match exists, the fallback still
    runs using year_int as the ceiling (fund-year offset pattern — see
    school 309025 in docs/dcp-cross-validation.md).

    Edge case (school 314904): if year_int < all DCP years for that school/
    component, the fallback finds no entry → no_match. This surfaces a year
    declaration error in the source data.
    """
    ceiling = _year_from_date(acq_date) or _year_from_date(date_received)

    # Primary: exact year match.
    if year_int is not None:
        for dcp_comp in dcp_components:
            key: DcpCostKey = (school_id, year_int, dcp_comp)
            if key in dcp_cost_lookup:
                cost, supplier = dcp_cost_lookup[key]
                return "exact", cost, year_int, dcp_comp, supplier

    # Fallback: use ceiling (fall back to year_int if no date available).
    if year_int is None and ceiling is None:
        return "no_year", None, None, None, None

    search_ceiling: int = ceiling if ceiling is not None else year_int  # type: ignore[assignment]
    for dcp_comp in dcp_components:
        entries = dcp_by_school_component.get((school_id, dcp_comp), [])
        found = next(
            ((y, c, s) for y, c, s in entries if y <= search_ceiling),
            None,
        )
        if found:
            dcp_year_found, dcp_cost, dcp_supplier = found
            match_type = (
                "inferred"
                if (year_int is None or year_int != dcp_year_found)
                else "exact"
            )
            return match_type, dcp_cost, dcp_year_found, dcp_comp, dcp_supplier

    return "no_match", None, None, None, None


# ── Main Resolution Entry Point ──────────────────────────────────────────────


def resolve_dcp_cost(
    school_id: int | None,
    item_canonical: str | None,
    dcp_year_int: int | None,
    source_canonical: str | None,
    acquisition_date: str | None,
    date_received_new: str | None,
    dcp_cost_lookup: DcpCostLookup,
    dcp_by_school_component: DcpBySchoolComponent,
) -> tuple[str, float | None, int | None, str | None, str | None]:
    """Resolve DCP enrichment for one equipment row.

    Decision tree (evaluated in order):
        1. Non-CO source       → non_co_source
        2. No school_id        → no_school_id
        3. No component mapping → no_component_mapping
        4–7. _resolve_dcp_match → exact / inferred / no_year / no_match

    Returns (match_type, dcp_cost, dcp_year, dcp_component, dcp_supplier).
    All fields except match_type are None when the row cannot be matched.
    """
    if source_canonical != CO_SOURCE_CANONICAL:
        return "non_co_source", None, None, None, None

    if not school_id:
        return "no_school_id", None, None, None, None

    dcp_components = DCP_COMPONENT_MAP.get(item_canonical or "")
    if not dcp_components:
        return "no_component_mapping", None, None, None, None

    return _resolve_dcp_match(
        school_id,
        dcp_year_int,
        acquisition_date,
        date_received_new,
        dcp_components,
        dcp_cost_lookup,
        dcp_by_school_component,
    )
