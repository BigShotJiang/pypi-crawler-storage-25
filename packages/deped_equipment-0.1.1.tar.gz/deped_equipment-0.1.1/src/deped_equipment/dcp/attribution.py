from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from importlib.resources import files

import yaml
from deped_dcp_template.cleaners import clean_text

_BATCH_PATTERN = re.compile(r"\bbatch\s+(\d{1,3})\b")
_PACKAGE_PATTERN = re.compile(r"\bpackage\s+(\d{1,2})\b")
_YEAR_PATTERN = re.compile(r"\b(19|20)\d{2}\b")
_NON_DCP_PATTERN = re.compile(r"\bnon\s*dcp\b")
_BARE_DCP_BATCH_PATTERN = re.compile(r"^(?:co\s+)?dcp\s+(\d{1,2})$")
_COMPACT_DCP_BATCH_PATTERN = re.compile(r"^dcp(\d{1,2})$")
_LEADING_LOT_PATTERN = re.compile(r"^lot\s*(?:no\s*)?\d+\s*")
_LOT_PATTERN = re.compile(r"\blot\s*(?:no\s*)?\d+\b")
_RAW_INVALID_PLACEHOLDERS = frozenset({"✓"})
_MAX_PROGRAMMATIC_BATCH_NUMBER = 44
_INVALID_NON_PACKAGE_REVIEW_KEYS = frozenset({"mooe", "high value", "low value", "x"})


@dataclass(frozen=True)
class DcpAttributionCanonicalRecord:
    canonical_name: str
    canonical_type: str
    lookup_code: str | None
    lookup_name: str | None
    program_year: int | None
    batch_number: int | None
    package_number: int | None
    review_status: str
    notes: str | None


@dataclass(frozen=True)
class DcpAttributionAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_dcp_attribution_review_key(value: str | None) -> str | None:
    text = clean_text(value)
    if text is None:
        return None
    normalized = unicodedata.normalize("NFKC", text).casefold()
    normalized = re.sub(r"[‐‑–—−]+", "-", normalized)
    normalized = normalized.replace("&", " and ")
    normalized = re.sub(r"\be[\s-]?learning\b", "elearning", normalized)
    normalized = re.sub(r"\be[\s-]?classroom\b", "eclassroom", normalized)
    normalized = re.sub(r"\bbatch\s*(?:no|number)[.,]?\s*", "batch ", normalized)
    normalized = re.sub(r"\bbatch\s*#\s*", "batch ", normalized)
    normalized = re.sub(r"\bdcp\s+project\b", "dcp", normalized)
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    if normalized.startswith("batch "):
        normalized = f"dcp {normalized}"
    return normalized or None


_INVALID_PLACEHOLDER_REVIEW_KEYS = frozenset(
    filter(
        None,
        (
            normalize_dcp_attribution_review_key(value)
            for value in (
                "0",
                "n/a",
                "na",
                "not applicable",
                "others",
                "other",
                "dcp package",
                "nil",
                "none",
                "null",
                "check",
                "✓",
            )
        ),
    )
)


def classify_dcp_attribution_value(
    raw_value: str | None, *, is_non_dcp: bool
) -> tuple[str | None, str | None]:
    text = clean_text(raw_value)
    if text in _RAW_INVALID_PLACEHOLDERS:
        return "invalid_placeholder", "invalid_placeholder"
    review_key = normalize_dcp_attribution_review_key(raw_value)
    if is_non_dcp:
        return "non_dcp", None
    if review_key is None:
        return None, None
    if _NON_DCP_PATTERN.search(review_key):
        return "non_dcp", None
    if review_key in _INVALID_PLACEHOLDER_REVIEW_KEYS:
        return "invalid_placeholder", "invalid_placeholder"
    if review_key in _INVALID_NON_PACKAGE_REVIEW_KEYS or re.fullmatch(
        r"(19|20)\d{2}", review_key
    ):
        return "invalid_non_package_value", "invalid_non_package_value"
    return "unclassified", "unclassified"


def infer_dcp_attribution_metadata(
    canonical_name: str,
) -> tuple[str, int | None, int | None, int | None]:
    review_key = normalize_dcp_attribution_review_key(canonical_name) or ""
    batch_match = _BATCH_PATTERN.search(review_key)
    package_match = _PACKAGE_PATTERN.search(review_key)
    year_match = _YEAR_PATTERN.search(review_key)
    batch_number = int(batch_match.group(1)) if batch_match else None
    package_number = int(package_match.group(1)) if package_match else None
    program_year = int(year_match.group(0)) if year_match else None
    if batch_number is not None and (
        program_year is not None or package_number is not None
    ):
        canonical_type = "hybrid_label"
    elif batch_number is not None:
        canonical_type = "batch_label"
    elif program_year is not None and package_number is not None:
        canonical_type = "hybrid_label"
    else:
        canonical_type = "named_package"
    return canonical_type, program_year, batch_number, package_number


def iter_programmatic_dcp_batch_canonicals() -> list[DcpAttributionCanonicalRecord]:
    return [
        DcpAttributionCanonicalRecord(
            canonical_name=f"DCP Batch {batch_number}",
            canonical_type="batch_label",
            lookup_code=None,
            lookup_name=None,
            program_year=None,
            batch_number=batch_number,
            package_number=None,
            review_status="approved",
            notes="Seeded programmatically from normalized batch pattern",
        )
        for batch_number in range(1, _MAX_PROGRAMMATIC_BATCH_NUMBER + 1)
    ]


def infer_programmatic_dcp_canonical(review_key: str | None) -> str | None:
    if review_key is None:
        return None
    normalized = _simplify_review_key(review_key)

    batch_match = _BATCH_PATTERN.search(normalized)
    if batch_match is not None:
        batch_number = int(batch_match.group(1))
        if 1 <= batch_number <= _MAX_PROGRAMMATIC_BATCH_NUMBER:
            return f"DCP Batch {batch_number}"

    bare_match = _BARE_DCP_BATCH_PATTERN.fullmatch(normalized)
    if bare_match is not None:
        return f"DCP Batch {int(bare_match.group(1))}"

    compact_match = _COMPACT_DCP_BATCH_PATTERN.fullmatch(normalized)
    if compact_match is not None:
        return f"DCP Batch {int(compact_match.group(1))}"

    if (
        "elearning cart" in normalized
        or "learning cart" in normalized
        or re.search(r"\belc\b", normalized)
        or re.search(r"\bdcp\s+2022\s+package\s+1\b", normalized)
    ):
        return "eLearning Cart Package"
    if "eclassroom" in normalized:
        return "eClassroom Package"
    if "laptop for teaching" in normalized:
        return "Laptop for Teaching"
    return None


def load_reviewed_dcp_attribution_dictionary() -> tuple[
    list[DcpAttributionCanonicalRecord],
    list[DcpAttributionAliasRecord],
]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/dcp_attribution_dictionary.yml"
    )
    with dictionary_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    canonicals: dict[str, DcpAttributionCanonicalRecord] = {}
    aliases: dict[str, DcpAttributionAliasRecord] = {}
    for canonical_name, entry in data.items():
        if entry.get("draft"):
            continue
        inferred_type, inferred_year, inferred_batch, inferred_package = (
            infer_dcp_attribution_metadata(canonical_name)
        )
        canonical = DcpAttributionCanonicalRecord(
            canonical_name=canonical_name,
            canonical_type=entry.get("type") or inferred_type,
            lookup_code=clean_text(entry.get("lookup_code")),
            lookup_name=None,
            program_year=entry.get("program_year") or inferred_year,
            batch_number=entry.get("batch_number") or inferred_batch,
            package_number=entry.get("package_number") or inferred_package,
            review_status="approved",
            notes=clean_text(entry.get("notes")),
        )
        _merge_canonical_record(canonicals, canonical)
        canonical_alias_key = normalize_dcp_attribution_review_key(canonical_name)
        if canonical_alias_key is not None:
            aliases.setdefault(
                canonical_alias_key,
                DcpAttributionAliasRecord(
                    alias_value=canonical_name,
                    normalized_alias_value=canonical_alias_key,
                    canonical_name=canonical_name,
                ),
            )
        for alias_value in entry.get("aliases") or []:
            alias_value = clean_text(alias_value)
            if alias_value is None:
                continue
            normalized_alias_value = normalize_dcp_attribution_review_key(alias_value)
            if normalized_alias_value is None:
                continue
            aliases.setdefault(
                normalized_alias_value,
                DcpAttributionAliasRecord(
                    alias_value=alias_value,
                    normalized_alias_value=normalized_alias_value,
                    canonical_name=canonical_name,
                ),
            )
    return sorted(canonicals.values(), key=lambda row: row.canonical_name), sorted(
        aliases.values(),
        key=lambda row: (row.normalized_alias_value, row.alias_value),
    )


def _merge_canonical_record(
    canonicals: dict[str, DcpAttributionCanonicalRecord],
    record: DcpAttributionCanonicalRecord,
) -> None:
    existing = canonicals.get(record.canonical_name)
    if existing is None:
        canonicals[record.canonical_name] = record
        return
    canonicals[record.canonical_name] = DcpAttributionCanonicalRecord(
        canonical_name=record.canonical_name,
        canonical_type=existing.canonical_type,
        lookup_code=existing.lookup_code or record.lookup_code,
        lookup_name=existing.lookup_name or record.lookup_name,
        program_year=existing.program_year or record.program_year,
        batch_number=existing.batch_number or record.batch_number,
        package_number=existing.package_number or record.package_number,
        review_status=existing.review_status,
        notes=existing.notes or record.notes,
    )


def _simplify_review_key(review_key: str) -> str:
    simplified = _LEADING_LOT_PATTERN.sub("", review_key)
    simplified = _LOT_PATTERN.sub("", simplified)
    simplified = re.sub(r"\b(?:sv|so|swps|ptrno)\s*[a-z0-9-]+\b", "", simplified)
    simplified = re.sub(r"\s+", " ", simplified).strip()
    return simplified
