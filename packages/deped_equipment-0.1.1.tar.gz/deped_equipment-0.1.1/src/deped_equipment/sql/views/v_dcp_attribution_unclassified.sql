CREATE VIEW v_dcp_attribution_unclassified AS
SELECT
    dcp_attribution_review_key,
    COUNT(*) AS row_count,
    COUNT(DISTINCT dcp_package_raw) AS distinct_raw_values,
    MIN(dcp_package_raw) AS sample_raw_value
FROM equipment
WHERE dcp_package_raw IS NOT NULL
  AND dcp_attribution_id IS NULL
  AND dcp_attribution_type = 'unclassified'
GROUP BY dcp_attribution_review_key
ORDER BY row_count DESC, dcp_attribution_review_key;
