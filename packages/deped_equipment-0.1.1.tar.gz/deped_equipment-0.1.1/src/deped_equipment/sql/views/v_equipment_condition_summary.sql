CREATE VIEW v_equipment_condition_summary AS
SELECT
    equipment_condition,
    disposition_status,
    COUNT(*) AS item_count,
    SUM(COALESCE(acquisition_cost, 0)) AS total_cost
FROM equipment
GROUP BY equipment_condition, disposition_status;
