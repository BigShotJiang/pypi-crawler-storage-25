-- Cost reporting accuracy for DCP-matched equipment rows.
-- Only applies to exact and inferred matches; unmatched rows are excluded.
--
-- flag_type values:
--   not_declared  — acquisition_cost is NULL or 0; DCP has the authoritative price
--   overstated    — declared > MIN(dcp lot cost) × 1.2
--   understated   — declared < MIN(dcp lot cost) × 0.8
--
-- Uses MIN lot cost per school/year/component (benefit of the doubt when
-- multiple lots exist at different prices — see docs/dcp-cross-validation.md).
CREATE VIEW v_audit_dcp_reported_cost AS
SELECT
    eq.id              AS equipment_id,
    eq.school_id,
    ei.canonical_name  AS item_name,
    eq.dcp_year,
    eq.dcp_component,
    eq.dcp_match_type,
    eq.acquisition_cost AS declared_cost,
    eq.dcp_cost,
    CASE
        WHEN eq.acquisition_cost IS NULL OR eq.acquisition_cost = 0
            THEN 'not_declared'
        WHEN eq.acquisition_cost > eq.dcp_cost * 1.2
            THEN 'overstated'
        WHEN eq.acquisition_cost < eq.dcp_cost * 0.8
            THEN 'understated'
    END AS flag_type,
    CASE
        WHEN eq.acquisition_cost IS NOT NULL AND eq.acquisition_cost > 0
             AND eq.dcp_cost > 0
            THEN ROUND(eq.acquisition_cost / eq.dcp_cost, 4)
        ELSE NULL
    END AS cost_ratio,
    eq.dcp_supplier
FROM equipment eq
LEFT JOIN equipment_items ei ON ei.id = eq.item_id
WHERE eq.dcp_match_type IN ('exact', 'inferred')
  AND eq.dcp_cost IS NOT NULL
  AND (
      eq.acquisition_cost IS NULL
      OR eq.acquisition_cost = 0
      OR eq.acquisition_cost > eq.dcp_cost * 1.2
      OR eq.acquisition_cost < eq.dcp_cost * 0.8
  );
