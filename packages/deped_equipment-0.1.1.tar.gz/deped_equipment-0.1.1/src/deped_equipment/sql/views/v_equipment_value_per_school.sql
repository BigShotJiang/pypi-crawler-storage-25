CREATE VIEW v_equipment_value_per_school AS
SELECT
    e.entity_id,
    e.school_id,
    e.entity_name AS school_name,
    e.region,
    e.division,
    COUNT(*) AS item_count,
    SUM(COALESCE(eq.acquisition_cost, 0)) AS total_cost,
    SUM(CASE WHEN eq.is_non_functional = 1 THEN 1 ELSE 0 END) AS non_functional_count,
    SUM(CASE WHEN ec.canonical_name = 'High-value' THEN 1 ELSE 0 END) AS high_value_count,
    SUM(CASE WHEN ec.canonical_name = 'Low-value' THEN 1 ELSE 0 END) AS low_value_count
FROM equipment eq
JOIN entities e ON e.entity_id = eq.entity_id
LEFT JOIN equipment_categories ec ON ec.id = eq.category_id
WHERE e.entity_type = 'SCHOOL'
GROUP BY e.entity_id, e.school_id, e.entity_name, e.region, e.division;
