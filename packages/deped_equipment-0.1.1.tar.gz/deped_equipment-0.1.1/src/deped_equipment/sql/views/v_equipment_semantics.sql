CREATE VIEW v_equipment_semantics AS
WITH base AS (
    SELECT
        vee.*,
        CASE
            WHEN COALESCE(vee.item_is_computer, 0) = 1 THEN 1
            ELSE 0
        END AS is_computing_device,
        CASE
            WHEN vee.equipment_location_name = 'classroom' THEN 1
            ELSE 0
        END AS is_classroom_location,
        CASE
            WHEN vee.equipment_location_name = 'ict/lab' THEN 1
            ELSE 0
        END AS is_ict_lab_location,
        CASE
            WHEN vee.equipment_location_name IN ('classroom', 'ict/lab') THEN 1
            ELSE 0
        END AS is_learning_space_location,
        CASE
            WHEN vee.disposition_status_name IN (
                'For Disposal',
                'Disposed',
                'Damaged due to calamity',
                'Lost/Stolen/Missing',
                'Transferred',
                'Donated'
            ) THEN 1
            ELSE 0
        END AS is_disposed_or_inactive,
        CASE
            WHEN vee.equipment_condition_name = 'For Repair' THEN 1
            ELSE 0
        END AS is_repairable,
        CASE
            WHEN COALESCE(vee.is_non_functional, 0) = 1 THEN 1
            WHEN vee.equipment_condition_name IN ('Unserviceable', 'Not Applicable') THEN 1
            ELSE 0
        END AS is_non_functional_effective,
        CASE
            WHEN vee.acquisition_date IS NOT NULL THEN vee.acquisition_date
            ELSE NULL
        END AS age_reference_date,
        CASE
            WHEN vee.acquisition_date IS NOT NULL THEN CAST(strftime('%Y', vee.acquisition_date) AS INTEGER)
            WHEN vee.dcp_year IS NOT NULL THEN vee.dcp_year
            WHEN vee.dcp_program_year IS NOT NULL THEN vee.dcp_program_year
            WHEN vee.dcp_year_name GLOB '*[0-9][0-9][0-9][0-9]' THEN CAST(substr(vee.dcp_year_name, -4) AS INTEGER)
            ELSE NULL
        END AS age_reference_year
    FROM v_equipment_enriched vee
)
SELECT
    base.*,
    CASE
        WHEN base.is_disposed_or_inactive = 0
             AND base.is_non_functional_effective = 0
             AND base.is_repairable = 0
             AND (
                 base.equipment_condition_name = 'Serviceable'
                 OR base.disposition_status_name = 'Normal'
             ) THEN 1
        ELSE 0
    END AS is_functional,
    CASE
        WHEN base.is_computing_device = 1
             AND base.is_learning_space_location = 1
             AND base.is_disposed_or_inactive = 0 THEN 1
        ELSE 0
    END AS is_learner_device,
    CASE
        WHEN base.is_computing_device = 1
             AND base.is_learning_space_location = 1
             AND base.is_disposed_or_inactive = 0
             AND base.is_non_functional_effective = 0
             AND base.is_repairable = 0
             AND (
                 base.equipment_condition_name = 'Serviceable'
                 OR base.disposition_status_name = 'Normal'
             ) THEN 1
        ELSE 0
    END AS is_active_learner_device,
    CASE
        WHEN base.is_computing_device = 0 THEN 'not_computing_device'
        WHEN base.equipment_location_name IS NULL THEN 'unresolved_location'
        WHEN base.is_learning_space_location = 0 THEN 'not_learning_space'
        WHEN base.is_disposed_or_inactive = 1 THEN 'disposed_or_inactive'
        WHEN base.equipment_condition_name IS NULL
             AND base.disposition_status_name IS NULL THEN 'unresolved_condition'
        WHEN base.is_repairable = 1 THEN 'for_repair'
        WHEN base.is_non_functional_effective = 1 THEN 'non_functional'
        ELSE NULL
    END AS semantics_exclusion_reason,
    CASE
        WHEN base.age_reference_date IS NOT NULL THEN ROUND(
            (julianday('now') - julianday(base.age_reference_date)) / 365.25,
            2
        )
        WHEN base.age_reference_year IS NOT NULL THEN CAST(
            CAST(strftime('%Y', 'now') AS INTEGER) - base.age_reference_year AS REAL
        )
        ELSE NULL
    END AS device_age_years
FROM base;
