-- Unit completeness per school/year/DCP-component.
-- Compares expected_units (from the DCP procurement contract) against
-- declared_units (equipment rows that matched this specific delivery).
--
-- coverage_flag values:
--   none_declared   — DCP delivered but zero matching equipment rows exist
--   underdeclared   — fewer declared rows than expected units (partial gap)
--   overdeclared    — more declared rows than expected units (informational;
--                     common for replacement units issued under the same year)
--   matched         — counts agree exactly
--
-- unit_gap > 0 means units are missing from equipment records.
-- Unit coverage is tracked at the DCP component level (not equipment canonical
-- level) so Laptop and Host Laptop deliveries show their own gaps separately.
CREATE VIEW v_audit_dcp_unit_coverage AS
SELECT
    ds.school_id,
    ds.year        AS dcp_year,
    ds.component   AS dcp_component,
    SUM(ds.expected_units) AS expected_units,
    COUNT(eq.id)           AS declared_units,
    SUM(ds.expected_units) - COUNT(eq.id) AS unit_gap,
    CASE
        WHEN COUNT(eq.id) = 0
            THEN 'none_declared'
        WHEN SUM(ds.expected_units) - COUNT(eq.id) > 0
            THEN 'underdeclared'
        WHEN SUM(ds.expected_units) - COUNT(eq.id) < 0
            THEN 'overdeclared'
        ELSE 'matched'
    END AS coverage_flag,
    -- Supplier with the highest expected_units for this delivery (for accountability).
    (
        SELECT supplier
        FROM dcp_delivery_summary ds2
        WHERE ds2.school_id = ds.school_id
          AND ds2.year = ds.year
          AND ds2.component = ds.component
        ORDER BY ds2.expected_units DESC
        LIMIT 1
    ) AS dcp_supplier
FROM dcp_delivery_summary ds
LEFT JOIN equipment eq
       ON eq.school_id = ds.school_id
      AND eq.dcp_year = ds.year
      AND eq.dcp_component = ds.component
      AND eq.dcp_match_type IN ('exact', 'inferred')
GROUP BY ds.school_id, ds.year, ds.component;
