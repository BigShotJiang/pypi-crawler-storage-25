CREATE VIEW v_link_resolution_coverage AS
SELECT 'accountable_officer' AS link_field, accountable_officer_link_status AS link_status, COUNT(*) AS row_count
FROM equipment GROUP BY accountable_officer_link_status
UNION ALL
SELECT 'custodian_end_user', custodian_end_user_link_status, COUNT(*)
FROM equipment GROUP BY custodian_end_user_link_status
UNION ALL
SELECT 'received_by', received_by_link_status, COUNT(*)
FROM equipment GROUP BY received_by_link_status;
