CREATE VIEW v_supplier_unclassified AS
SELECT
    supplier_review_key,
    COUNT(*) AS row_count,
    COUNT(DISTINCT supplier) AS distinct_raw_values,
    MIN(supplier) AS sample_raw_value
FROM equipment
WHERE supplier IS NOT NULL
  AND supplier_id IS NULL
  AND supplier_type = 'unclassified'
GROUP BY supplier_review_key
ORDER BY row_count DESC, supplier_review_key;
