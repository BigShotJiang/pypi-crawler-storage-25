CREATE VIEW v_disposition_status_unclassified AS
SELECT
    disposition_status_review_key,
    COUNT(*) AS row_count,
    COUNT(DISTINCT disposition_status) AS distinct_raw_values,
    MIN(disposition_status) AS sample_raw_value
FROM equipment
WHERE disposition_status IS NOT NULL
  AND disposition_status_id IS NULL
  AND disposition_status_type = 'unclassified'
GROUP BY disposition_status_review_key
ORDER BY row_count DESC, disposition_status_review_key;
