-- Three-field consistency audit: is_non_functional × equipment_condition × disposition_status.
--
-- Permitted combinations (no row emitted):
--   is_non_functional=0/NULL  + Serviceable      + Normal / Transferred / Donated / NULL
--   is_non_functional=0/NULL  + For Repair        + any disposition
--   is_non_functional=0/NULL  + Not Applicable    + any disposition
--   is_non_functional=1       + Unserviceable     + For Disposal / Disposed / Damaged due to calamity / Lost/Stolen/Missing / Transferred / Donated / NULL
--   is_non_functional=1       + For Repair        + For Disposal / Disposed / Damaged due to calamity / Lost/Stolen/Missing / Transferred / Donated / NULL
--   is_non_functional=1       + Not Applicable    + For Disposal / Disposed / Damaged due to calamity / Lost/Stolen/Missing / Transferred / Donated / NULL
--
-- flag_type values (in priority order):
--   non_functional_but_serviceable        — is_non_functional=1 AND condition=Serviceable (direct contradiction)
--   non_functional_normal_disposition     — is_non_functional=1 AND disposition=Normal (non-functional equipment cannot have a Normal disposition)
--   functional_but_unserviceable          — is_non_functional=0 AND condition=Unserviceable (checkbox may simply be absent; review)
--   serviceable_but_disposal_disposition  — condition=Serviceable AND disposition implies the equipment is gone/damaged
--   non_functional_no_disposition         — is_non_functional=1 AND disposition is unresolved/absent (expected for non-functional items to have a recorded disposition)
CREATE VIEW v_audit_condition_disposition_inconsistency AS
SELECT
    eq.id AS equipment_id,
    eq.is_non_functional,
    eco.canonical_name AS equipment_condition,
    eq.equipment_condition_type,
    eds.canonical_name AS disposition_status,
    eq.disposition_status_type,
    CASE
        WHEN eq.is_non_functional = 1 AND eco.canonical_name = 'Serviceable'
            THEN 'non_functional_but_serviceable'
        WHEN eq.is_non_functional = 1 AND eds.canonical_name = 'Normal'
            THEN 'non_functional_normal_disposition'
        WHEN eq.is_non_functional = 0 AND eco.canonical_name = 'Unserviceable'
            THEN 'functional_but_unserviceable'
        WHEN eco.canonical_name = 'Serviceable'
             AND eds.canonical_name IN ('For Disposal', 'Disposed', 'Damaged due to calamity')
            THEN 'serviceable_but_disposal_disposition'
        WHEN eq.is_non_functional = 1 AND eq.disposition_status_id IS NULL
            THEN 'non_functional_no_disposition'
    END AS flag_type
FROM equipment eq
LEFT JOIN equipment_conditions eco ON eco.id = eq.equipment_condition_id
LEFT JOIN equipment_disposition_statuses eds ON eds.id = eq.disposition_status_id
WHERE
    -- hard contradictions
    (eq.is_non_functional = 1 AND eco.canonical_name = 'Serviceable')
    OR (eq.is_non_functional = 1 AND eds.canonical_name = 'Normal')
    OR (eq.is_non_functional = 0 AND eco.canonical_name = 'Unserviceable')
    -- serviceable equipment marked for disposal / damaged
    OR (
        eco.canonical_name = 'Serviceable'
        AND eds.canonical_name IN ('For Disposal', 'Disposed', 'Damaged due to calamity')
    )
    -- non-functional with no resolved disposition
    OR (eq.is_non_functional = 1 AND eq.disposition_status_id IS NULL);
