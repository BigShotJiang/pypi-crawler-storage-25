CREATE VIEW v_equipment_condition_unclassified AS
SELECT
    equipment_condition_review_key,
    COUNT(*) AS row_count,
    COUNT(DISTINCT equipment_condition) AS distinct_raw_values,
    MIN(equipment_condition) AS sample_raw_value
FROM equipment
WHERE equipment_condition IS NOT NULL
  AND equipment_condition_id IS NULL
  AND equipment_condition_type = 'unclassified'
GROUP BY equipment_condition_review_key
ORDER BY row_count DESC, equipment_condition_review_key;
