CREATE VIEW v_audit_suspected_uacs_as_cost AS
SELECT
    eq.id AS equipment_id,
    COALESCE(ei.canonical_name, eq.item_raw) AS item_name,
    eq.acquisition_cost,
    CASE
        WHEN eq.acquisition_cost >= 5020321000 THEN 'uacs_code_as_cost'
        ELSE                                        'implausible_cost_for_peripheral'
    END AS flag_type
FROM equipment eq
LEFT JOIN equipment_items ei ON ei.id = eq.item_id
WHERE eq.acquisition_cost >= 5020321000
   OR (
       eq.acquisition_cost >= 100000000
       AND LOWER(COALESCE(ei.canonical_name, '')) IN (
           'keyboard', 'mouse', 'avr', 'speakers', 'ups',
           'monitor', 'external hard drive', 'charging cart'
       )
   );
