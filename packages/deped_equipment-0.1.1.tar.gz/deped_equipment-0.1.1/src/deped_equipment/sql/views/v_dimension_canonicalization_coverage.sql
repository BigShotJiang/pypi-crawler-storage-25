CREATE VIEW v_dimension_canonicalization_coverage AS
SELECT 'unit_of_measure' AS dimension_name,
       COUNT(*) AS total_rows,
       SUM(CASE WHEN unit_of_measure_raw IS NOT NULL THEN 1 ELSE 0 END) AS raw_present_rows,
       SUM(CASE WHEN unit_of_measure_id IS NOT NULL THEN 1 ELSE 0 END) AS canonicalized_rows,
       COUNT(DISTINCT unit_of_measure_raw) AS distinct_raw_values,
       COUNT(DISTINCT unit_of_measure_id) AS distinct_canonical_values
FROM equipment
UNION ALL
SELECT 'brand', COUNT(*),
       SUM(CASE WHEN brand_raw IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN brand_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT brand_raw),
       COUNT(DISTINCT brand_id)
FROM equipment
UNION ALL
SELECT 'model', COUNT(*),
       SUM(CASE WHEN model_raw IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN model_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT model_raw),
       COUNT(DISTINCT model_id)
FROM equipment
UNION ALL
SELECT 'dcp_package', COUNT(*),
       SUM(CASE WHEN dcp_package_raw IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN dcp_attribution_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT dcp_package_raw),
       COUNT(DISTINCT dcp_attribution_id)
FROM equipment
UNION ALL
SELECT 'dcp_attribution', COUNT(*),
       SUM(CASE WHEN dcp_package_raw IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN dcp_attribution_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT dcp_package_raw),
       COUNT(DISTINCT dcp_attribution_id)
FROM equipment
UNION ALL
SELECT 'dcp_year', COUNT(*),
       SUM(CASE WHEN dcp_year_package_raw IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN dcp_year_package_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT dcp_year_package_raw),
       COUNT(DISTINCT dcp_year_package_id)
FROM equipment
UNION ALL
SELECT 'mode_of_acquisition', COUNT(*),
       SUM(CASE WHEN mode_of_acquisition_raw IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN mode_of_acquisition_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT mode_of_acquisition_raw),
       COUNT(DISTINCT mode_of_acquisition_id)
FROM equipment
UNION ALL
SELECT 'donor', COUNT(*),
       SUM(CASE WHEN donor IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN donor_type IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT donor),
       COUNT(DISTINCT donor_type)
FROM equipment
UNION ALL
SELECT 'equipment_location', COUNT(*),
       SUM(CASE WHEN equipment_location IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN equipment_location_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT equipment_location),
       COUNT(DISTINCT equipment_location_id)
FROM equipment
UNION ALL
SELECT 'supplier', COUNT(*),
       SUM(CASE WHEN supplier IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN supplier_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT supplier),
       COUNT(DISTINCT supplier_id)
FROM equipment
UNION ALL
SELECT 'disposition_status', COUNT(*),
       SUM(CASE WHEN disposition_status IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN disposition_status_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT disposition_status),
       COUNT(DISTINCT disposition_status_id)
FROM equipment
UNION ALL
SELECT 'source_of_funds', COUNT(*),
       SUM(CASE WHEN source_of_funds IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN source_of_funds_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT source_of_funds),
       COUNT(DISTINCT source_of_funds_id)
FROM equipment
UNION ALL
SELECT 'source_of_acquisition', COUNT(*),
       SUM(CASE WHEN source_of_acquisition_raw IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN source_of_acquisition_id IS NOT NULL THEN 1 ELSE 0 END),
       COUNT(DISTINCT source_of_acquisition_raw),
       COUNT(DISTINCT source_of_acquisition_id)
FROM equipment;
