CREATE VIEW v_equipment_dimension_issue_summary AS
SELECT
    dimension_name,
    issue_type,
    raw_value,
    COUNT(*) AS row_count
FROM equipment_dimension_issues
GROUP BY dimension_name, issue_type, raw_value;
