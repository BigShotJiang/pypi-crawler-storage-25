CREATE VIEW v_source_of_funds_unclassified AS
SELECT
    source_of_funds_review_key,
    COUNT(*) AS row_count,
    COUNT(DISTINCT source_of_funds) AS distinct_raw_values,
    MIN(source_of_funds) AS sample_raw_value
FROM equipment
WHERE source_of_funds IS NOT NULL
  AND source_of_funds_id IS NULL
  AND source_of_funds_type = 'unclassified'
GROUP BY source_of_funds_review_key
ORDER BY row_count DESC, source_of_funds_review_key;
