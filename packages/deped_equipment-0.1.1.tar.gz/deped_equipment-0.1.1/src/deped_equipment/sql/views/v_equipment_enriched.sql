CREATE VIEW v_equipment_enriched AS
SELECT
    eq.*,
    -- DCP-authoritative cost when matched; declared cost otherwise.
    CASE
        WHEN eq.dcp_match_type IN ('exact', 'inferred') AND eq.dcp_cost IS NOT NULL
            THEN eq.dcp_cost
        ELSE eq.acquisition_cost
    END AS effective_acquisition_cost,
    e.entity_type,
    e.entity_name,
    e.region,
    e.division,
    ec.canonical_name AS category_name,
    ei.canonical_name AS item_name,
    ei.is_computer AS item_is_computer,
    ei.is_tv AS item_is_tv,
    ei.is_accessory AS item_is_accessory,
    eu.canonical_name AS unit_of_measure_name,
    eb.canonical_name AS brand_name,
    em.canonical_name AS model_name,
    el.canonical_name AS equipment_location_name,
    eco.canonical_name AS equipment_condition_name,
    es.canonical_name AS supplier_name,
    eds.canonical_name AS disposition_status_name,
    esof.canonical_name AS source_of_funds_name,
    eda.canonical_name AS dcp_attribution_name,
    eda.canonical_type AS dcp_attribution_type_name,
    eda.program_year AS dcp_program_year,
    eda.batch_number AS dcp_batch_number,
    eda.package_number AS dcp_package_number,
    COALESCE(eda.canonical_name, edp.canonical_name) AS dcp_package_name,
    edy.canonical_name AS dcp_year_name,
    eam.canonical_name AS mode_of_acquisition_name,
    eas.canonical_name AS source_of_acquisition_name,
    ap.full_name AS accountable_personnel_name,
    cp.full_name AS custodian_personnel_name,
    rp.full_name AS received_by_personnel_name
FROM equipment eq
JOIN entities e ON e.entity_id = eq.entity_id
LEFT JOIN equipment_categories ec ON ec.id = eq.category_id
LEFT JOIN equipment_items ei ON ei.id = eq.item_id
LEFT JOIN equipment_units eu ON eu.id = eq.unit_of_measure_id
LEFT JOIN equipment_brands eb ON eb.id = eq.brand_id
LEFT JOIN equipment_models em ON em.id = eq.model_id
LEFT JOIN equipment_locations el ON el.id = eq.equipment_location_id
LEFT JOIN equipment_conditions eco ON eco.id = eq.equipment_condition_id
LEFT JOIN equipment_suppliers es ON es.id = eq.supplier_id
LEFT JOIN equipment_disposition_statuses eds ON eds.id = eq.disposition_status_id
LEFT JOIN equipment_source_of_funds esof ON esof.id = eq.source_of_funds_id
LEFT JOIN equipment_dcp_attributions eda ON eda.id = eq.dcp_attribution_id
LEFT JOIN equipment_dcp_packages edp ON edp.id = eq.dcp_package_id
LEFT JOIN equipment_dcp_years edy ON edy.id = eq.dcp_year_package_id
LEFT JOIN equipment_acquisition_modes eam ON eam.id = eq.mode_of_acquisition_id
LEFT JOIN equipment_acquisition_sources eas ON eas.id = eq.source_of_acquisition_id
LEFT JOIN personnel ap ON ap.id = eq.accountable_personnel_id
LEFT JOIN personnel cp ON cp.id = eq.custodian_personnel_id
LEFT JOIN personnel rp ON rp.id = eq.received_by_personnel_id;
