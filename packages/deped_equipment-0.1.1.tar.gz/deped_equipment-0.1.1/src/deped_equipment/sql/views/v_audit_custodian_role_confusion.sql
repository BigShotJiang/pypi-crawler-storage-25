CREATE VIEW v_audit_custodian_role_confusion AS
WITH custodian_counts AS (
    SELECT
        entity_id,
        custodian_personnel_id,
        COUNT(*) AS devices_as_custodian
    FROM equipment
    WHERE custodian_personnel_id IS NOT NULL
    GROUP BY entity_id, custodian_personnel_id
),
accountable_counts AS (
    SELECT
        entity_id,
        accountable_personnel_id AS personnel_id,
        COUNT(*) AS school_records_as_accountable
    FROM equipment
    WHERE accountable_personnel_id IS NOT NULL
    GROUP BY entity_id, accountable_personnel_id
)
SELECT
    eq.id AS equipment_id,
    eq.entity_id,
    eq.property_no,
    eq.custodian_personnel_id,
    cp.full_name AS custodian_name,
    eq.accountable_personnel_id,
    ap.full_name AS accountable_name,
    cc.devices_as_custodian,
    COALESCE(ac.school_records_as_accountable, 0) AS school_records_as_accountable,
    'custodian_is_accountable_officer' AS flag_type
FROM equipment eq
JOIN custodian_counts cc
  ON cc.entity_id = eq.entity_id
 AND cc.custodian_personnel_id = eq.custodian_personnel_id
JOIN personnel cp ON cp.id = eq.custodian_personnel_id
LEFT JOIN personnel ap ON ap.id = eq.accountable_personnel_id
LEFT JOIN accountable_counts ac
  ON ac.entity_id = eq.entity_id
 AND ac.personnel_id = eq.custodian_personnel_id
WHERE eq.custodian_personnel_id IS NOT NULL
  AND eq.custodian_personnel_id = eq.accountable_personnel_id
UNION ALL
SELECT
    eq.id AS equipment_id,
    eq.entity_id,
    eq.property_no,
    eq.custodian_personnel_id,
    cp.full_name AS custodian_name,
    eq.accountable_personnel_id,
    ap.full_name AS accountable_name,
    cc.devices_as_custodian,
    COALESCE(ac.school_records_as_accountable, 0) AS school_records_as_accountable,
    'high_volume_custodian' AS flag_type
FROM equipment eq
JOIN custodian_counts cc
  ON cc.entity_id = eq.entity_id
 AND cc.custodian_personnel_id = eq.custodian_personnel_id
JOIN personnel cp ON cp.id = eq.custodian_personnel_id
LEFT JOIN personnel ap ON ap.id = eq.accountable_personnel_id
LEFT JOIN accountable_counts ac
  ON ac.entity_id = eq.entity_id
 AND ac.personnel_id = eq.custodian_personnel_id
WHERE eq.custodian_personnel_id IS NOT NULL
  AND cc.devices_as_custodian > 5
  AND (
      eq.accountable_personnel_id IS NULL
      OR eq.custodian_personnel_id != eq.accountable_personnel_id
  );
