CREATE VIEW v_audit_acquisition_cost_outlier AS
WITH item_costs AS (
    SELECT
        eq.id,
        ei.canonical_name AS item_name,
        eq.acquisition_cost,
        ROW_NUMBER() OVER (PARTITION BY ei.canonical_name ORDER BY eq.acquisition_cost) AS rn,
        COUNT(*)       OVER (PARTITION BY ei.canonical_name)                            AS cnt
    FROM equipment eq
    JOIN equipment_items ei ON ei.id = eq.item_id
    WHERE eq.acquisition_cost > 0
),
item_medians AS (
    SELECT item_name, AVG(acquisition_cost) AS median_cost
    FROM item_costs
    WHERE rn IN ((cnt + 1) / 2, (cnt + 2) / 2)
    GROUP BY item_name
)
SELECT
    eq.id AS equipment_id,
    ei.canonical_name AS item_name,
    eq.acquisition_cost,
    m.median_cost,
    CASE
        WHEN eq.acquisition_cost > m.median_cost * 10   THEN 'cost_above_10x_median'
        WHEN eq.acquisition_cost < m.median_cost * 0.01 THEN 'cost_below_1pct_median'
    END AS flag_type
FROM equipment eq
JOIN equipment_items ei ON ei.id = eq.item_id
JOIN item_medians m ON m.item_name = ei.canonical_name
WHERE eq.acquisition_cost > 0
  AND (
      eq.acquisition_cost > m.median_cost * 10
   OR eq.acquisition_cost < m.median_cost * 0.01
  );
