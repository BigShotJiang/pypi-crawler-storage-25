-- Serviceability of confirmed-delivered DCP equipment.
-- Only covers rows with dcp_match_type IN ('exact', 'inferred').
--
-- flag_type values:
--   non_functional       — DCP-matched equipment marked is_non_functional = 1
--   disposed_but_functional — has a disposition status but is_non_functional = 0
CREATE VIEW v_audit_dcp_condition AS
SELECT
    eq.id             AS equipment_id,
    eq.school_id,
    ei.canonical_name AS item_name,
    eq.dcp_year,
    eq.dcp_component,
    eq.dcp_match_type,
    eq.dcp_supplier,
    eq.is_non_functional,
    eds.canonical_name AS disposition_status,
    CASE
        WHEN eq.is_non_functional = 1
            THEN 'non_functional'
        WHEN eq.disposition_status_id IS NOT NULL AND eq.is_non_functional = 0
            THEN 'disposed_but_functional'
    END AS flag_type
FROM equipment eq
LEFT JOIN equipment_items ei ON ei.id = eq.item_id
LEFT JOIN equipment_disposition_statuses eds ON eds.id = eq.disposition_status_id
WHERE eq.dcp_match_type IN ('exact', 'inferred')
  AND (
      eq.is_non_functional = 1
      OR eq.disposition_status_id IS NOT NULL
  );
