-- Flags recognized standalone items with no acquisition cost recorded.
-- Peripherals commonly received as part of a bundled package (keyboard, mouse,
-- AVR, speakers, external hard drives, charging carts) are excluded because
-- missing cost is expected for those items.
CREATE VIEW v_audit_missing_cost AS
SELECT
    eq.id AS equipment_id,
    ei.canonical_name AS item_name,
    'missing_acquisition_cost' AS flag_type
FROM equipment eq
JOIN equipment_items ei ON ei.id = eq.item_id
WHERE (eq.acquisition_cost IS NULL OR eq.acquisition_cost = 0)
  AND LOWER(ei.canonical_name) NOT IN (
      'keyboard', 'mouse', 'avr', 'speakers',
      'external hard drive', 'charging cart'
  );
