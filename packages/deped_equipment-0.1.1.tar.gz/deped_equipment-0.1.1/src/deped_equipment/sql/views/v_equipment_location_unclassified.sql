CREATE VIEW v_equipment_location_unclassified AS
SELECT
    equipment_location_review_key,
    COUNT(*) AS row_count,
    COUNT(DISTINCT equipment_location) AS distinct_raw_values,
    MIN(equipment_location) AS sample_raw_value
FROM equipment
WHERE equipment_location IS NOT NULL
  AND equipment_location_id IS NULL
  AND equipment_location_type = 'unclassified'
GROUP BY equipment_location_review_key
ORDER BY row_count DESC, equipment_location_review_key;
