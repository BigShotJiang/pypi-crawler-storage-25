CREATE INDEX idx_entities_type ON entities(entity_type);
CREATE INDEX idx_entities_region ON entities(region);
CREATE INDEX idx_entities_division ON entities(division);
CREATE INDEX idx_entities_school_id ON entities(school_id);
