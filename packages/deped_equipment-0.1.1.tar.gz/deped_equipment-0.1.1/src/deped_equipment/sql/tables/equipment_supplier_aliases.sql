CREATE TABLE equipment_supplier_aliases (
    alias_value TEXT PRIMARY KEY,
    normalized_alias_value TEXT NOT NULL UNIQUE,
    canonical_supplier_id INTEGER NOT NULL REFERENCES equipment_suppliers(id)
);
