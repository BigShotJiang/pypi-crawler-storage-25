CREATE TABLE equipment_dcp_attribution_aliases (
    alias_value TEXT PRIMARY KEY,
    normalized_alias_value TEXT NOT NULL UNIQUE,
    canonical_attribution_id INTEGER NOT NULL REFERENCES equipment_dcp_attributions(id)
);
