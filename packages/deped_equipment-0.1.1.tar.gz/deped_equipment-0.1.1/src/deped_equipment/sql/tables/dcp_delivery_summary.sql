-- One row per DCP contract lot (not aggregated by school/year/component).
-- Preserving per-lot rows is required for cost fidelity when a school receives
-- multiple lots of the same component in the same year at different prices
-- (e.g. school 306188: two Laptop lots at 35,555 and 37,120 in 2023).
--
-- Unit coverage views sum expected_units across lots.
-- Cost comparison uses MIN(unit_cost) across lots per school/year/component.
CREATE TABLE dcp_delivery_summary (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id     INTEGER NOT NULL,
    year          INTEGER NOT NULL,
    component     TEXT NOT NULL,
    pkg_count     INTEGER NOT NULL,
    units_per_pkg INTEGER NOT NULL,
    expected_units INTEGER NOT NULL,  -- pkg_count * units_per_pkg
    unit_cost     REAL NOT NULL,
    supplier      TEXT NOT NULL
);
