CREATE TABLE equipment_acquisition_source_aliases (
    alias_value TEXT PRIMARY KEY,
    canonical_source_id INTEGER NOT NULL REFERENCES equipment_acquisition_sources(id)
);
