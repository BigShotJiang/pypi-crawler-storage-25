CREATE TABLE equipment_condition_aliases (
    alias_value TEXT PRIMARY KEY,
    normalized_alias_value TEXT NOT NULL UNIQUE,
    canonical_condition_id INTEGER NOT NULL REFERENCES equipment_conditions(id)
);
