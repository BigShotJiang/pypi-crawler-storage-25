CREATE TABLE equipment_disposition_status_aliases (
    alias_value TEXT PRIMARY KEY,
    normalized_alias_value TEXT NOT NULL UNIQUE,
    canonical_disposition_status_id INTEGER NOT NULL REFERENCES equipment_disposition_statuses(id)
);
