CREATE TABLE equipment_location_aliases (
    alias_value TEXT PRIMARY KEY,
    normalized_alias_value TEXT NOT NULL UNIQUE,
    canonical_location_id INTEGER NOT NULL REFERENCES equipment_locations(id)
);
