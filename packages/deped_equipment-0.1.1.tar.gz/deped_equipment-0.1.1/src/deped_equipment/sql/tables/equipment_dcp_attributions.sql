CREATE TABLE equipment_dcp_attributions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    canonical_name TEXT NOT NULL UNIQUE,
    canonical_type TEXT NOT NULL,
    lookup_code TEXT NULL,
    lookup_name TEXT NULL,
    program_year INTEGER NULL,
    batch_number INTEGER NULL,
    package_number INTEGER NULL,
    review_status TEXT NOT NULL DEFAULT 'approved',
    notes TEXT NULL
);
