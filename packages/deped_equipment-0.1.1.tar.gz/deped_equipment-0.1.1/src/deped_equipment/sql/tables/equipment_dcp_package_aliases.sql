CREATE TABLE equipment_dcp_package_aliases (
    alias_value TEXT PRIMARY KEY,
    canonical_package_id INTEGER NOT NULL REFERENCES equipment_dcp_packages(id)
);
