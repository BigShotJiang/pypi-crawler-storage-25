CREATE TABLE entities (
    entity_id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,
    school_id INTEGER NULL,
    entity_name TEXT NOT NULL,
    region TEXT NOT NULL,
    division TEXT NULL,
    office_unit_name TEXT NULL,
    has_personnel INTEGER NOT NULL DEFAULT 0,
    has_equipment INTEGER NOT NULL DEFAULT 0,
    natural_key TEXT NOT NULL UNIQUE
);
