CREATE TABLE equipment_source_of_funds_aliases (
    alias_value TEXT PRIMARY KEY,
    normalized_alias_value TEXT NOT NULL UNIQUE,
    canonical_source_of_funds_id INTEGER NOT NULL REFERENCES equipment_source_of_funds(id)
);
