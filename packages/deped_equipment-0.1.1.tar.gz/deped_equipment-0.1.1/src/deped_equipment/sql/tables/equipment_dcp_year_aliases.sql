CREATE TABLE equipment_dcp_year_aliases (
    alias_value TEXT PRIMARY KEY,
    canonical_year_id INTEGER NOT NULL REFERENCES equipment_dcp_years(id)
);
