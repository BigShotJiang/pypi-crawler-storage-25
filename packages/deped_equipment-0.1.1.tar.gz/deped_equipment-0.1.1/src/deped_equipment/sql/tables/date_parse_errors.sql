CREATE TABLE date_parse_errors (
    source_table TEXT,
    source_file TEXT,
    source_row_num INTEGER,
    source_record_id INTEGER,
    column_name TEXT,
    raw_value TEXT
);
