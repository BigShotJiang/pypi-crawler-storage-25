CREATE TABLE equipment_dimension_issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dimension_name TEXT NOT NULL,
    issue_type TEXT NOT NULL,
    raw_value TEXT NOT NULL,
    source_file TEXT NOT NULL,
    source_row_num INTEGER NOT NULL,
    source_record_id INTEGER NULL
);
