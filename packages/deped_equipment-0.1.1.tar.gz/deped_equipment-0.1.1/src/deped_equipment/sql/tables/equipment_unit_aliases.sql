CREATE TABLE equipment_unit_aliases (
    alias_value TEXT PRIMARY KEY,
    canonical_unit_id INTEGER NOT NULL REFERENCES equipment_units(id)
);
