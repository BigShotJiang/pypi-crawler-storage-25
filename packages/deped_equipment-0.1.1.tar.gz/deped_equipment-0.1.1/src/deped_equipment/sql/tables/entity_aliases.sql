CREATE TABLE entity_aliases (
    entity_id INTEGER NOT NULL REFERENCES entities(entity_id),
    alias_name TEXT NOT NULL,
    UNIQUE(entity_id, alias_name)
);
