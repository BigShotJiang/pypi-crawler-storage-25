from __future__ import annotations

import csv
import re
import sqlite3
from contextlib import closing
from hashlib import sha256
from importlib.resources import files
from pathlib import Path
from typing import cast

from deped_dcp_template.cleaners import (
    clean_text,
    normalize_equipment_item,
    normalize_low_cardinality_dimension,
)
from deped_dcp_template.constants import SCHEMA_VERSION, register_low_cardinality_values

from .csv_rows import row_get
from .dcp.attribution import (
    DcpAttributionAliasRecord,
    DcpAttributionCanonicalRecord,
    iter_programmatic_dcp_batch_canonicals,
    load_reviewed_dcp_attribution_dictionary,
    normalize_dcp_attribution_review_key,
)
from .dcp.dataset import load_dcp_delivery_rows
from .normalization.acquisition_mode import (
    load_reviewed_acquisition_mode_aliases,
)
from .normalization.condition import load_reviewed_equipment_condition_aliases
from .normalization.disposition import load_reviewed_disposition_aliases
from .normalization.donor import load_reviewed_donor_aliases
from .normalization.location import (
    iter_equipment_location_canonicals,
    load_reviewed_equipment_location_aliases,
)
from .normalization.source_of_funds import load_reviewed_source_of_funds_aliases
from .normalization.supplier import load_reviewed_supplier_aliases
from .types import (
    CanonicalNameLookup,
    CanonicalNameRow,
    EntityEmployeeKey,
    EntityLookup,
    EntityNameKey,
    ImportedPersonnelResolutionRow,
    LookupMaps,
    PackageLookupRow,
    PersonnelResolutionLookups,
    PersonnelSnapshotRow,
    ScopeEmployeeKey,
)

_SQL = files("deped_equipment.sql")

COMPUTER_ITEM_NAMES = frozenset(
    {
        "2-In-1 Tablet",
        "Desktop (Package)",
        "Laptop",
        "Server (Bundle)",
        "Server (System Unit)",
        "Smartphone",
        "Tablet",
        "Thin Client Server (Set)",
    }
)

TV_ITEM_NAMES = frozenset(
    {
        "Interactive Whiteboards / Smartboards",
        "Smart TV",
        "Standard TV",
    }
)

ACCESSORY_ITEM_NAMES = frozenset(
    {
        "Barcode Or QR Scanner",
        "Biometric Readers",
        "Bluetooth / Wi-Fi Adapter",
        "Docking Station / USB Hub",
        "Document Cameras / Visualizers",
        "External Hard Drive",
        "Headset With Microphone",
        "Keyboard",
        "Lapel",
        "Memory Card (RAM)",
        "Microphone",
        "Monitor",
        "Mouse",
        "Scanner",
        "Signature Pad",
        "Speakers",
        "Stylus",
        "Trackpad",
        "USB Flash Drive",
        "Voice Recorder",
        "Webcam",
    }
)


def _read_sql(name: str) -> str:
    return _SQL.joinpath(name).read_text()


def _apply_equipment_item_flags(conn: sqlite3.Connection) -> None:
    conn.execute(
        """--sql
        UPDATE equipment_items
        SET
            is_computer = CASE
                WHEN canonical_name IN ({computer_names}) THEN 1
                ELSE 0
            END,
            is_tv = CASE
                WHEN canonical_name IN ({tv_names}) THEN 1
                ELSE 0
            END,
            is_accessory = CASE
                WHEN canonical_name IN ({accessory_names}) THEN 1
                ELSE 0
            END
        """.format(
            computer_names=", ".join("?" for _ in COMPUTER_ITEM_NAMES),
            tv_names=", ".join("?" for _ in TV_ITEM_NAMES),
            accessory_names=", ".join("?" for _ in ACCESSORY_ITEM_NAMES),
        ),
        tuple(COMPUTER_ITEM_NAMES) + tuple(TV_ITEM_NAMES) + tuple(ACCESSORY_ITEM_NAMES),
    )


def create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(_read_sql("pragmas.sql"))
    for filename in (
        "tables/entities.sql",
        "tables/entity_aliases.sql",
        "tables/equipment.sql",
        "tables/equipment_items.sql",
        "tables/equipment_units.sql",
        "tables/equipment_unit_aliases.sql",
        "tables/equipment_brands.sql",
        "tables/equipment_models.sql",
        "tables/equipment_locations.sql",
        "tables/equipment_location_aliases.sql",
        "tables/equipment_conditions.sql",
        "tables/equipment_condition_aliases.sql",
        "tables/equipment_suppliers.sql",
        "tables/equipment_supplier_aliases.sql",
        "tables/equipment_disposition_statuses.sql",
        "tables/equipment_disposition_status_aliases.sql",
        "tables/equipment_source_of_funds.sql",
        "tables/equipment_source_of_funds_aliases.sql",
        "tables/equipment_categories.sql",
        "tables/equipment_dcp_packages.sql",
        "tables/equipment_dcp_package_aliases.sql",
        "tables/equipment_dcp_attributions.sql",
        "tables/equipment_dcp_attribution_aliases.sql",
        "tables/equipment_dcp_years.sql",
        "tables/equipment_dcp_year_aliases.sql",
        "tables/equipment_acquisition_modes.sql",
        "tables/equipment_acquisition_mode_aliases.sql",
        "tables/equipment_acquisition_sources.sql",
        "tables/equipment_acquisition_source_aliases.sql",
        "tables/equipment_dimension_issues.sql",
        "tables/date_parse_errors.sql",
        "tables/build_runs.sql",
        "tables/dcp_delivery_summary.sql",
    ):
        conn.executescript(_read_sql(filename))
    conn.executescript(
        """--sql
        CREATE TABLE personnel(
            id INTEGER PRIMARY KEY,
            full_name TEXT
        );
        """
    )


def create_indexes(conn: sqlite3.Connection) -> None:
    conn.executescript(_read_sql("indexes/entities.sql"))
    conn.executescript(_read_sql("indexes/equipment.sql"))


def create_views(conn: sqlite3.Connection) -> None:
    for filename in (
        "views/v_equipment_enriched.sql",
        "views/v_equipment_semantics.sql",
        "views/v_equipment_value_per_school.sql",
        "views/v_equipment_condition_summary.sql",
        "views/v_link_resolution_coverage.sql",
        "views/v_dimension_canonicalization_coverage.sql",
        "views/v_unresolved_dimension_values.sql",
        "views/v_equipment_dimension_issue_summary.sql",
        "views/v_audit_custodian_role_confusion.sql",
        "views/v_dcp_attribution_unclassified.sql",
        "views/v_equipment_location_unclassified.sql",
        "views/v_equipment_condition_unclassified.sql",
        "views/v_supplier_unclassified.sql",
        "views/v_disposition_status_unclassified.sql",
        "views/v_source_of_funds_unclassified.sql",
        "views/v_audit_dcp_reported_cost.sql",
        "views/v_audit_dcp_unit_coverage.sql",
        "views/v_audit_dcp_condition.sql",
        "views/v_audit_condition_disposition_inconsistency.sql",
    ):
        conn.executescript(_read_sql(filename))


def _seed_table(
    conn: sqlite3.Connection, table_name: str, values: list[str]
) -> CanonicalNameLookup:
    rows = sorted({value for value in values if value})
    if rows:
        conn.executemany(
            f"INSERT INTO {table_name}(canonical_name) VALUES (?)",
            [(value,) for value in rows],
        )
    return {
        name: row_id
        for row_id, name in conn.execute(f"SELECT id, canonical_name FROM {table_name}")
    }


def seed_lookup_tables(
    conn: sqlite3.Connection, lookups_db: str | Path, equipment_csv: str | Path
) -> LookupMaps:
    with closing(sqlite3.connect(lookups_db)) as lookup_conn:
        item_rows = cast(
            list[CanonicalNameRow],
            lookup_conn.execute(
                "SELECT canonical_name FROM equipment_items"
            ).fetchall(),
        )
        items = [row[0] for row in item_rows]
        brand_rows = cast(
            list[CanonicalNameRow],
            lookup_conn.execute(
                "SELECT canonical_name FROM equipment_brands"
            ).fetchall(),
        )
        brands = [row[0] for row in brand_rows]
        unit_rows = cast(
            list[CanonicalNameRow],
            lookup_conn.execute(
                "SELECT canonical_name FROM equipment_units"
            ).fetchall(),
        )
        units = [row[0] for row in unit_rows]
        mode_rows = cast(
            list[CanonicalNameRow],
            lookup_conn.execute(
                "SELECT canonical_name FROM acquisition_modes"
            ).fetchall(),
        )
        modes = [row[0] for row in mode_rows]
        source_rows = cast(
            list[CanonicalNameRow],
            lookup_conn.execute(
                "SELECT canonical_name FROM acquisition_sources"
            ).fetchall(),
        )
        sources = [row[0] for row in source_rows]
        packages = cast(
            list[PackageLookupRow],
            lookup_conn.execute("SELECT code, name FROM dcp_packages").fetchall(),
        )
    register_low_cardinality_values("unit", units)
    register_low_cardinality_values("acquisition_mode", modes)
    register_low_cardinality_values("acquisition_source", sources)
    conn.executemany(
        "INSERT INTO equipment_categories(canonical_name) VALUES (?)",
        [("High-value",), ("Low-value",), ("Unknown",)],
    )
    lookups: LookupMaps = {
        "equipment_items": _seed_table(
            conn,
            "equipment_items",
            [normalize_equipment_item(value) or value for value in items],
        ),
        "equipment_brands": _seed_table(conn, "equipment_brands", brands),
        "equipment_units": _seed_table(conn, "equipment_units", units),
        "equipment_acquisition_modes": _seed_table(
            conn, "equipment_acquisition_modes", modes
        ),
        "equipment_acquisition_mode_aliases": {},
        "equipment_acquisition_sources": _seed_table(
            conn, "equipment_acquisition_sources", sources
        ),
        "equipment_categories": {
            name: row_id
            for row_id, name in conn.execute(
                "SELECT id, canonical_name FROM equipment_categories"
            )
        },
        "equipment_dcp_packages": {},
        "equipment_dcp_attributions": {},
        "equipment_dcp_attribution_aliases": {},
        "equipment_dcp_attribution_types": {},
        "equipment_locations": {},
        "equipment_location_aliases": {},
        "equipment_conditions": {},
        "equipment_condition_aliases": {},
        "equipment_suppliers": {},
        "equipment_supplier_aliases": {},
        "equipment_disposition_statuses": {},
        "equipment_disposition_status_aliases": {},
        "equipment_source_of_funds": {},
        "equipment_source_of_funds_aliases": {},
        "equipment_donor_aliases": {},
        "equipment_dcp_years": {},
        "equipment_models": {},
        "equipment_item_id_to_canonical": {},
        "equipment_dcp_year_id_to_int": {},
        "co_acquisition_source_ids": set(),
    }
    _seed_equipment_acquisition_modes(conn)
    _apply_equipment_item_flags(conn)
    _seed_equipment_locations(conn)
    _seed_equipment_conditions(conn)
    _seed_equipment_suppliers(conn)
    _seed_equipment_disposition_statuses(conn)
    _seed_equipment_source_of_funds(conn)
    _seed_dcp_attributions(conn, packages)
    lookups["equipment_locations"] = {
        name: row_id
        for row_id, name in conn.execute(
            "SELECT id, canonical_name FROM equipment_locations"
        )
    }
    lookups["equipment_location_aliases"] = dict(
        conn.execute(
            """--sql
            SELECT aliases.normalized_alias_value, locations.canonical_name
            FROM equipment_location_aliases aliases
            JOIN equipment_locations locations
              ON locations.id = aliases.canonical_location_id
            """
        )
    )
    lookups["equipment_conditions"] = {
        name: row_id
        for row_id, name in conn.execute(
            "SELECT id, canonical_name FROM equipment_conditions"
        )
    }
    lookups["equipment_condition_aliases"] = dict(
        conn.execute(
            """--sql
            SELECT aliases.normalized_alias_value, conditions.canonical_name
            FROM equipment_condition_aliases aliases
            JOIN equipment_conditions conditions
              ON conditions.id = aliases.canonical_condition_id
            """
        )
    )
    lookups["equipment_suppliers"] = {
        name: row_id
        for row_id, name in conn.execute(
            "SELECT id, canonical_name FROM equipment_suppliers"
        )
    }
    lookups["equipment_supplier_aliases"] = dict(
        conn.execute(
            """--sql
            SELECT aliases.normalized_alias_value, suppliers.canonical_name
            FROM equipment_supplier_aliases aliases
            JOIN equipment_suppliers suppliers
              ON suppliers.id = aliases.canonical_supplier_id
            """
        )
    )
    lookups["equipment_disposition_statuses"] = {
        name: row_id
        for row_id, name in conn.execute(
            "SELECT id, canonical_name FROM equipment_disposition_statuses"
        )
    }
    lookups["equipment_disposition_status_aliases"] = dict(
        conn.execute(
            """--sql
            SELECT aliases.normalized_alias_value, statuses.canonical_name
            FROM equipment_disposition_status_aliases aliases
            JOIN equipment_disposition_statuses statuses
              ON statuses.id = aliases.canonical_disposition_status_id
            """
        )
    )
    lookups["equipment_source_of_funds"] = {
        name: row_id
        for row_id, name in conn.execute(
            "SELECT id, canonical_name FROM equipment_source_of_funds"
        )
    }
    lookups["equipment_source_of_funds_aliases"] = dict(
        conn.execute(
            """--sql
            SELECT aliases.normalized_alias_value, funds.canonical_name
            FROM equipment_source_of_funds_aliases aliases
            JOIN equipment_source_of_funds funds
              ON funds.id = aliases.canonical_source_of_funds_id
            """
        )
    )
    lookups["equipment_donor_aliases"] = {
        alias.normalized_alias_value: alias.canonical_name
        for alias in load_reviewed_donor_aliases()
    }
    lookups["equipment_dcp_attributions"] = {
        name: row_id
        for row_id, name in conn.execute(
            "SELECT id, canonical_name FROM equipment_dcp_attributions"
        )
    }
    lookups["equipment_dcp_packages"] = {
        name: row_id
        for row_id, name in conn.execute(
            "SELECT id, canonical_name FROM equipment_dcp_packages"
        )
    }
    lookups["equipment_dcp_attribution_aliases"] = dict(
        conn.execute(
            """--sql
            SELECT aliases.normalized_alias_value, attributions.canonical_name
            FROM equipment_dcp_attribution_aliases aliases
            JOIN equipment_dcp_attributions attributions
              ON attributions.id = aliases.canonical_attribution_id
            """
        )
    )
    lookups["equipment_dcp_attribution_types"] = dict(
        conn.execute(
            "SELECT canonical_name, canonical_type FROM equipment_dcp_attributions"
        )
    )
    dcp_years = set()
    with open(equipment_csv, "r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            raw_year = clean_text(
                row_get(row, "dcp_year", "DCP Year Package ", "DCP Year Package")
            )
            year = normalize_low_cardinality_dimension("dcp_year", raw_year)
            if year:
                dcp_years.add(year)
    lookups["equipment_dcp_years"] = _seed_table(
        conn, "equipment_dcp_years", sorted(dcp_years)
    )
    lookups["equipment_acquisition_mode_aliases"] = dict(
        conn.execute(
            """--sql
            SELECT aliases.normalized_alias_value, modes.canonical_name
            FROM equipment_acquisition_mode_aliases aliases
            JOIN equipment_acquisition_modes modes
              ON modes.id = aliases.canonical_mode_id
            """
        )
    )
    lookups["equipment_models"] = {}
    # Reverse lookup: item_id → canonical_name (for dcp_dataset resolution).
    lookups["equipment_item_id_to_canonical"] = {
        row_id: name for name, row_id in lookups["equipment_items"].items()
    }
    # Reverse lookup: dcp_year_package_id → integer year.
    lookups["equipment_dcp_year_id_to_int"] = {}
    for name, row_id in lookups["equipment_dcp_years"].items():
        try:
            lookups["equipment_dcp_year_id_to_int"][row_id] = int(name)
        except ValueError, TypeError:
            pass
    # IDs for Central Office acquisition source.
    co_id = lookups["equipment_acquisition_sources"].get("Central Office")
    lookups["co_acquisition_source_ids"] = {co_id} if co_id is not None else set()
    return lookups


def _seed_equipment_locations(conn: sqlite3.Connection) -> None:
    conn.executemany(
        "INSERT OR IGNORE INTO equipment_locations(canonical_name) VALUES (?)",
        [(name,) for name in iter_equipment_location_canonicals()],
    )
    aliases = {
        alias.normalized_alias_value: alias
        for alias in load_reviewed_equipment_location_aliases()
    }
    location_ids = {
        canonical_name: row_id
        for row_id, canonical_name in conn.execute(
            "SELECT id, canonical_name FROM equipment_locations"
        )
    }
    if aliases:
        conn.executemany(
            """--sql
            INSERT INTO equipment_location_aliases(
                alias_value, normalized_alias_value, canonical_location_id
            ) VALUES (?, ?, ?)
            """,
            [
                (
                    alias.alias_value,
                    alias.normalized_alias_value,
                    location_ids[alias.canonical_name],
                )
                for alias in aliases.values()
                if alias.canonical_name in location_ids
            ],
        )


def _seed_equipment_acquisition_modes(conn: sqlite3.Connection) -> None:
    aliases_by_normalized = {
        alias.normalized_alias_value: alias
        for alias in load_reviewed_acquisition_mode_aliases()
    }
    aliases = {alias.alias_value: alias for alias in aliases_by_normalized.values()}
    mode_ids = {
        canonical_name: row_id
        for row_id, canonical_name in conn.execute(
            "SELECT id, canonical_name FROM equipment_acquisition_modes"
        )
    }
    if aliases:
        conn.executemany(
            """--sql
            INSERT INTO equipment_acquisition_mode_aliases(
                alias_value, normalized_alias_value, canonical_mode_id
            ) VALUES (?, ?, ?)
            """,
            [
                (
                    alias.alias_value,
                    alias.normalized_alias_value,
                    mode_ids[alias.canonical_name],
                )
                for alias in aliases.values()
                if alias.canonical_name in mode_ids
            ],
        )


def _seed_equipment_conditions(conn: sqlite3.Connection) -> None:
    aliases_by_normalized = {
        alias.normalized_alias_value: alias
        for alias in load_reviewed_equipment_condition_aliases()
    }
    aliases = {alias.alias_value: alias for alias in aliases_by_normalized.values()}
    canonical_names = sorted({alias.canonical_name for alias in aliases.values()})
    if canonical_names:
        conn.executemany(
            "INSERT INTO equipment_conditions(canonical_name) VALUES (?)",
            [(name,) for name in canonical_names],
        )
    condition_ids = {
        canonical_name: row_id
        for row_id, canonical_name in conn.execute(
            "SELECT id, canonical_name FROM equipment_conditions"
        )
    }
    if aliases:
        conn.executemany(
            """--sql
            INSERT INTO equipment_condition_aliases(
                alias_value, normalized_alias_value, canonical_condition_id
            ) VALUES (?, ?, ?)
            """,
            sorted(
                {
                    (
                        alias.alias_value,
                        alias.normalized_alias_value,
                        condition_ids[alias.canonical_name],
                    )
                    for alias in aliases.values()
                    if alias.canonical_name in condition_ids
                }
            ),
        )


def _seed_equipment_suppliers(conn: sqlite3.Connection) -> None:
    aliases_by_normalized = {
        alias.normalized_alias_value: alias
        for alias in load_reviewed_supplier_aliases()
    }
    aliases = {alias.alias_value: alias for alias in aliases_by_normalized.values()}
    canonical_names = sorted({alias.canonical_name for alias in aliases.values()})
    if canonical_names:
        conn.executemany(
            "INSERT INTO equipment_suppliers(canonical_name) VALUES (?)",
            [(name,) for name in canonical_names],
        )
    supplier_ids = {
        canonical_name: row_id
        for row_id, canonical_name in conn.execute(
            "SELECT id, canonical_name FROM equipment_suppliers"
        )
    }
    if aliases:
        conn.executemany(
            """--sql
            INSERT INTO equipment_supplier_aliases(
                alias_value, normalized_alias_value, canonical_supplier_id
            ) VALUES (?, ?, ?)
            """,
            sorted(
                {
                    (
                        alias.alias_value,
                        alias.normalized_alias_value,
                        supplier_ids[alias.canonical_name],
                    )
                    for alias in aliases.values()
                    if alias.canonical_name in supplier_ids
                }
            ),
        )


def _seed_equipment_disposition_statuses(conn: sqlite3.Connection) -> None:
    aliases = {
        alias.normalized_alias_value: alias
        for alias in load_reviewed_disposition_aliases()
    }
    canonical_names = sorted({alias.canonical_name for alias in aliases.values()})
    if canonical_names:
        conn.executemany(
            "INSERT INTO equipment_disposition_statuses(canonical_name) VALUES (?)",
            [(name,) for name in canonical_names],
        )
    status_ids = {
        canonical_name: row_id
        for row_id, canonical_name in conn.execute(
            "SELECT id, canonical_name FROM equipment_disposition_statuses"
        )
    }
    if aliases:
        conn.executemany(
            """--sql
            INSERT INTO equipment_disposition_status_aliases(
                alias_value, normalized_alias_value, canonical_disposition_status_id
            ) VALUES (?, ?, ?)
            """,
            [
                (
                    alias.alias_value,
                    alias.normalized_alias_value,
                    status_ids[alias.canonical_name],
                )
                for alias in aliases.values()
                if alias.canonical_name in status_ids
            ],
        )


def _seed_equipment_source_of_funds(conn: sqlite3.Connection) -> None:
    aliases_by_normalized = {
        alias.normalized_alias_value: alias
        for alias in load_reviewed_source_of_funds_aliases()
    }
    aliases = {alias.alias_value: alias for alias in aliases_by_normalized.values()}
    canonical_names = sorted({alias.canonical_name for alias in aliases.values()})
    if canonical_names:
        conn.executemany(
            "INSERT INTO equipment_source_of_funds(canonical_name) VALUES (?)",
            [(name,) for name in canonical_names],
        )
    fund_ids = {
        canonical_name: row_id
        for row_id, canonical_name in conn.execute(
            "SELECT id, canonical_name FROM equipment_source_of_funds"
        )
    }
    if aliases:
        conn.executemany(
            """--sql
            INSERT INTO equipment_source_of_funds_aliases(
                alias_value, normalized_alias_value, canonical_source_of_funds_id
            ) VALUES (?, ?, ?)
            """,
            sorted(
                {
                    (
                        alias.alias_value,
                        alias.normalized_alias_value,
                        fund_ids[alias.canonical_name],
                    )
                    for alias in aliases.values()
                    if alias.canonical_name in fund_ids
                }
            ),
        )


def _seed_dcp_attributions(
    conn: sqlite3.Connection, packages: list[PackageLookupRow]
) -> None:
    canonicals: dict[str, DcpAttributionCanonicalRecord] = {}
    aliases: dict[str, DcpAttributionAliasRecord] = {}
    for canonical in [
        *_merge_lookup_packages(packages),
        *iter_programmatic_dcp_batch_canonicals(),
    ]:
        canonicals[canonical.canonical_name] = canonical
        review_key = normalize_dcp_attribution_review_key(canonical.canonical_name)
        if review_key is not None:
            aliases[review_key] = DcpAttributionAliasRecord(
                alias_value=canonical.canonical_name,
                normalized_alias_value=review_key,
                canonical_name=canonical.canonical_name,
            )
        if canonical.lookup_name:
            lookup_alias_key = normalize_dcp_attribution_review_key(
                canonical.lookup_name
            )
            if lookup_alias_key is not None:
                aliases[lookup_alias_key] = DcpAttributionAliasRecord(
                    alias_value=canonical.lookup_name,
                    normalized_alias_value=lookup_alias_key,
                    canonical_name=canonical.canonical_name,
                )
    reviewed_canonicals, reviewed_aliases = load_reviewed_dcp_attribution_dictionary()
    for canonical in reviewed_canonicals:
        canonicals[canonical.canonical_name] = _merge_dcp_canonical(
            canonicals.get(canonical.canonical_name),
            canonical,
        )
    for alias in reviewed_aliases:
        aliases[alias.normalized_alias_value] = alias

    canonical_rows = sorted(canonicals.values(), key=lambda row: row.canonical_name)
    if canonical_rows:
        conn.executemany(
            """--sql
            INSERT INTO equipment_dcp_attributions(
                canonical_name, canonical_type, lookup_code, lookup_name,
                program_year, batch_number, package_number, review_status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    row.canonical_name,
                    row.canonical_type,
                    row.lookup_code,
                    row.lookup_name,
                    row.program_year,
                    row.batch_number,
                    row.package_number,
                    row.review_status,
                    row.notes,
                )
                for row in canonical_rows
            ],
        )
        conn.executemany(
            "INSERT INTO equipment_dcp_packages(canonical_name) VALUES (?)",
            [(row.canonical_name,) for row in canonical_rows],
        )

    attribution_ids = {
        canonical_name: row_id
        for row_id, canonical_name in conn.execute(
            "SELECT id, canonical_name FROM equipment_dcp_attributions"
        )
    }
    if aliases:
        alias_rows = sorted(
            {
                (
                    alias.alias_value,
                    alias.normalized_alias_value,
                    attribution_ids[alias.canonical_name],
                )
                for alias in aliases.values()
                if alias.canonical_name in attribution_ids
            }
        )
        conn.executemany(
            """--sql
            INSERT INTO equipment_dcp_attribution_aliases(
                alias_value, normalized_alias_value, canonical_attribution_id
            ) VALUES (?, ?, ?)
            """,
            alias_rows,
        )
        conn.executemany(
            """--sql
            INSERT INTO equipment_dcp_package_aliases(alias_value, canonical_package_id)
            SELECT ?, id FROM equipment_dcp_packages WHERE canonical_name = ?
            """,
            [
                (alias.alias_value, alias.canonical_name)
                for alias in aliases.values()
                if alias.canonical_name in attribution_ids
            ],
        )


def _merge_lookup_packages(
    packages: list[PackageLookupRow],
) -> list[DcpAttributionCanonicalRecord]:
    canonicals: dict[str, DcpAttributionCanonicalRecord] = {}
    for code, name in packages:
        canonical = DcpAttributionCanonicalRecord(
            canonical_name=code,
            canonical_type="named_package",
            lookup_code=code,
            lookup_name=clean_text(name),
            program_year=None,
            batch_number=None,
            package_number=None,
            review_status="approved",
            notes="Seeded from lookups.db",
        )
        canonicals[code] = _merge_dcp_canonical(canonicals.get(code), canonical)
    return sorted(canonicals.values(), key=lambda row: row.canonical_name)


def _merge_dcp_canonical(
    existing: DcpAttributionCanonicalRecord | None,
    incoming: DcpAttributionCanonicalRecord,
) -> DcpAttributionCanonicalRecord:
    if existing is None:
        return incoming
    return DcpAttributionCanonicalRecord(
        canonical_name=incoming.canonical_name,
        canonical_type=existing.canonical_type,
        lookup_code=existing.lookup_code or incoming.lookup_code,
        lookup_name=existing.lookup_name or incoming.lookup_name,
        program_year=existing.program_year or incoming.program_year,
        batch_number=existing.batch_number or incoming.batch_number,
        package_number=existing.package_number or incoming.package_number,
        review_status=existing.review_status,
        notes=existing.notes or incoming.notes,
    )


def seed_dcp_delivery_summary(
    conn: sqlite3.Connection, dcp_dataset_db: str | Path
) -> None:
    """Seed dcp_delivery_summary from the procurement dataset.

    Stores one row per DCP contract lot (not aggregated) to preserve cost
    fidelity across multi-lot deliveries (see docs/dcp-cross-validation.md).
    Only components present in DCP_COMPONENT_MAP are loaded.
    """
    rows = load_dcp_delivery_rows(dcp_dataset_db)
    conn.executemany(
        """--sql
        INSERT INTO dcp_delivery_summary(
            school_id, year, component, pkg_count, units_per_pkg,
            expected_units, unit_cost, supplier
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        rows,
    )


def seed_personnel_snapshot(conn: sqlite3.Connection, personnel_db: str | Path) -> None:
    with closing(sqlite3.connect(personnel_db)) as personnel_conn:
        rows = cast(
            list[PersonnelSnapshotRow],
            personnel_conn.execute("SELECT id, full_name FROM personnel").fetchall(),
        )
    conn.executemany(
        "INSERT INTO personnel(id, full_name) VALUES (?, ?)",
        rows,
    )


def start_build_run(
    conn: sqlite3.Connection,
    equipment_path: str | Path,
    lookups_path: str | Path,
    entities_db_path: str | Path,
    personnel_db_path: str | Path,
    dcp_dataset_db_path: str | Path | None = None,
) -> int:
    equipment_path = Path(equipment_path)
    lookups_path = Path(lookups_path)
    entities_db_path = Path(entities_db_path)
    personnel_db_path = Path(personnel_db_path)
    equipment_hash = sha256(equipment_path.read_bytes()).hexdigest()
    lookups_hash = sha256(lookups_path.read_bytes()).hexdigest()
    entities_hash = sha256(entities_db_path.read_bytes()).hexdigest()
    personnel_hash = sha256(personnel_db_path.read_bytes()).hexdigest()
    dcp_file: str | None = None
    dcp_hash: str | None = None
    if dcp_dataset_db_path is not None:
        dcp_path = Path(dcp_dataset_db_path)
        dcp_file = dcp_path.name
        dcp_hash = sha256(dcp_path.read_bytes()).hexdigest()
    with open(equipment_path, "r", encoding="utf-8-sig", newline="") as handle:
        equipment_rows = sum(1 for _ in csv.DictReader(handle))
    cursor = conn.execute(
        """--sql
        INSERT INTO build_runs(
            build_type, started_at, schema_version,
            lookups_source_file, lookups_source_hash,
            entities_source_file, entities_source_hash,
            personnel_source_file, personnel_source_hash,
            equipment_source_file, equipment_source_hash, equipment_source_rows,
            dcp_dataset_source_file, dcp_dataset_source_hash
        ) VALUES (?, datetime('now'), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        (
            "full_rebuild",
            SCHEMA_VERSION,
            lookups_path.name,
            lookups_hash,
            entities_db_path.name,
            entities_hash,
            personnel_db_path.name,
            personnel_hash,
            equipment_path.name,
            equipment_hash,
            equipment_rows,
            dcp_file,
            dcp_hash,
        ),
    )
    conn.commit()
    if (v := cursor.lastrowid) is None:
        raise RuntimeError("Failed to create build run record")
    return int(v)


def complete_build_run(conn: sqlite3.Connection, build_run_id: int) -> None:
    conn.execute(
        """--sql
        UPDATE build_runs
        SET completed_at = datetime('now'),
            entity_count = (SELECT COUNT(*) FROM entities),
            personnel_count = (SELECT COUNT(*) FROM personnel),
            equipment_count = (SELECT COUNT(*) FROM equipment)
        WHERE id = ?;
        """,
        (build_run_id,),
    )
    conn.commit()


def build_personnel_resolution_lookups(
    personnel_db: str | Path, local_entity_lookup: EntityLookup
) -> PersonnelResolutionLookups:
    with closing(sqlite3.connect(personnel_db)) as personnel_conn:
        entity_employee_counts: dict[EntityEmployeeKey, list[int]] = {}
        scope_employee_counts: dict[ScopeEmployeeKey, list[int]] = {}
        entity_name_counts: dict[EntityNameKey, list[int]] = {}
        source_rows = cast(
            list[ImportedPersonnelResolutionRow],
            personnel_conn.execute(
                """--sql
                SELECT p.id, p.employee_id, p.full_name, e.natural_key, e.entity_type, e.region, e.division
                FROM personnel p
                JOIN entities e ON e.entity_id = p.entity_id;
                """
            ).fetchall(),
        )
        for (
            person_id,
            employee_id,
            full_name,
            natural_key,
            entity_type,
            region,
            division,
        ) in source_rows:
            mapped_entity_id = local_entity_lookup.get(natural_key)
            if employee_id:
                scope_key = (
                    "REGION" if entity_type == "REGIONAL_OFFICE" else "DIVISION",
                    region or "",
                    "" if entity_type == "REGIONAL_OFFICE" else (division or ""),
                    employee_id,
                )
                scope_employee_counts.setdefault(scope_key, []).append(person_id)
                if mapped_entity_id is not None:
                    entity_employee_counts.setdefault(
                        (mapped_entity_id, employee_id), []
                    ).append(person_id)
            if mapped_entity_id is None:
                continue
            name_key = re.sub(r"[^A-Z0-9]+", " ", (full_name or "").upper()).strip()
            if name_key:
                entity_name_counts.setdefault((mapped_entity_id, name_key), []).append(
                    person_id
                )

        def split_unique[TKey](
            values: dict[TKey, list[int]],
        ) -> tuple[dict[TKey, int], set[TKey]]:
            unique: dict[TKey, int] = {}
            ambiguous: set[TKey] = set()
            for key, person_ids in values.items():
                if len(person_ids) == 1:
                    unique[key] = person_ids[0]
                else:
                    ambiguous.add(key)
            return unique, ambiguous

        entity_employee, entity_employee_ambiguous = split_unique(
            entity_employee_counts
        )
        scope_employee, scope_employee_ambiguous = split_unique(scope_employee_counts)
        entity_name, entity_name_ambiguous = split_unique(entity_name_counts)
        return {
            "entity_employee": entity_employee,
            "entity_employee_ambiguous": entity_employee_ambiguous,
            "scope_employee": scope_employee,
            "scope_employee_ambiguous": scope_employee_ambiguous,
            "entity_name": entity_name,
            "entity_name_ambiguous": entity_name_ambiguous,
        }
