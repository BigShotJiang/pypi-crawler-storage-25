"""Equipment row loading pipeline."""

from __future__ import annotations

import sqlite3
from collections import Counter
from datetime import date
from pathlib import Path
from typing import cast

from deped_dcp_template.cleaners import (
    canonicalize_equipment_dimension,
    clean_text,
    normalize_equipment_category,
    normalize_equipment_item,
    normalize_identifier,
    normalize_low_cardinality_dimension,
    normalize_school_id,
    parse_cost,
    parse_date,
    parse_float,
    to_bool_int,
)
from deped_dcp_template.constants import BATCH_SIZE, EQUIPMENT_SOURCE
from deped_dcp_template.entities import build_natural_key, determine_entity_type
from deped_dcp_template.io import iter_csv_rows
from deped_dcp_template.personnel import flush_batch, maybe_log_date_error
from rich.progress import Progress, TaskID

from .csv_rows import row_get
from .dcp.attribution import (
    classify_dcp_attribution_value,
    infer_programmatic_dcp_canonical,
    normalize_dcp_attribution_review_key,
)
from .dcp.dataset import DcpBySchoolComponent, DcpCostLookup, resolve_dcp_cost
from .equipment_columns import DATE_ERROR_COLUMNS, EQUIPMENT_COLUMNS, ISSUE_COLUMNS
from .normalization.acquisition_mode import (
    classify_acquisition_mode_value,
    normalize_acquisition_mode_review_key,
)
from .normalization.condition import (
    classify_equipment_condition_value,
    normalize_equipment_condition_review_key,
)
from .normalization.disposition import (
    classify_disposition_value,
    normalize_disposition_review_key,
)
from .normalization.donor import (
    classify_donor_value,
    infer_donor_type,
    is_internal_deped_donor,
    normalize_donor_review_key,
)
from .normalization.location import (
    classify_equipment_location_value,
    infer_equipment_location_canonical,
    normalize_equipment_location_review_key,
)
from .normalization.source_of_funds import (
    classify_source_of_funds_value,
    normalize_source_of_funds_review_key,
)
from .normalization.supplier import (
    classify_supplier_value,
    normalize_supplier_review_key,
)
from .personnel_resolution import resolve_person_reference
from .types import (
    DateErrorRow,
    DateParseCandidate,
    EntityLookup,
    EquipmentInsertRow,
    EquipmentIssueCounter,
    EquipmentIssueRow,
    LookupMaps,
    PersonnelResolutionLookups,
)

MIN_ACQUISITION_DATE = date(2000, 1, 1)
MIN_ASSIGNMENT_DATE = date(2010, 1, 1)


def log_equipment_dimension_issue(
    issue_counts: EquipmentIssueCounter,
    issue_rows: list[EquipmentIssueRow],
    *,
    dimension_name: str,
    issue_type: str | None,
    raw_value: str | None,
    source_file: str,
    source_row_num: int,
    source_record_id: int | None,
) -> None:
    """Record a classified equipment-dimension issue for audits and QA views."""
    if raw_value is None or issue_type is None:
        return
    issue_counts[(dimension_name, issue_type, raw_value)] += 1
    issue_rows.append(
        (
            dimension_name,
            issue_type,
            raw_value,
            source_file,
            source_row_num,
            source_record_id,
        )
    )


def normalize_bounded_date(
    parsed_value: str | None, *, minimum_date: date
) -> str | None:
    """Reject parsed dates earlier than the supported lower bound."""
    if parsed_value is None:
        return None
    if date.fromisoformat(parsed_value) < minimum_date:
        return None
    return parsed_value


def _log_row_dimension_issues(
    issue_counts: EquipmentIssueCounter,
    issue_rows: list[EquipmentIssueRow],
    *,
    source_file: str,
    source_row_num: int,
    source_record_id: int | None,
    issues: tuple[tuple[str, str | None, str | None], ...],
) -> None:
    for dimension_name, issue_type, raw_value in issues:
        log_equipment_dimension_issue(
            issue_counts,
            issue_rows,
            dimension_name=dimension_name,
            issue_type=issue_type,
            raw_value=raw_value,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )


def _resolve_equipment_entity_id(
    entity_lookup: EntityLookup,
    natural_key: str,
    issue_counts: EquipmentIssueCounter,
    issue_rows: list[EquipmentIssueRow],
    *,
    source_file: str,
    source_row_num: int,
    source_record_id: int | None,
) -> int | None:
    entity_id = entity_lookup.get(natural_key)
    if entity_id is not None:
        return entity_id
    log_equipment_dimension_issue(
        issue_counts,
        issue_rows,
        dimension_name="entity",
        issue_type="missing_upstream_entity",
        raw_value=natural_key,
        source_file=source_file,
        source_row_num=source_row_num,
        source_record_id=source_record_id,
    )
    return None


def _start_equipment_progress_task(
    progress: Progress | None, path: str | Path
) -> TaskID | None:
    if progress is None:
        return None
    return progress.add_task(
        f"Load equipment: {Path(path).name} (0 rows)",
        total=Path(path).stat().st_size,
    )


def _flush_pending_rows(
    conn: sqlite3.Connection,
    rows: list[EquipmentInsertRow],
    issue_rows: list[EquipmentIssueRow],
    date_errors: list[DateErrorRow],
) -> None:
    flush_batch(conn, "equipment", list(EQUIPMENT_COLUMNS), rows)
    flush_batch(
        conn,
        "equipment_dimension_issues",
        list(ISSUE_COLUMNS),
        cast(list[tuple[object, ...]], issue_rows),
    )
    flush_batch(
        conn,
        "date_parse_errors",
        list(DATE_ERROR_COLUMNS),
        cast(list[tuple[object, ...]], date_errors),
    )


def resolve_dcp_attribution(
    lookup_maps: LookupMaps, dcp_package_raw: str | None, is_non_dcp: int | None
) -> tuple[int | None, str | None, str | None, int | None, str | None]:
    dcp_attribution_review_key = normalize_dcp_attribution_review_key(dcp_package_raw)
    dcp_attribution_type, dcp_issue = classify_dcp_attribution_value(
        dcp_package_raw,
        is_non_dcp=bool(is_non_dcp),
    )
    canonical_dcp_attribution = None
    if dcp_attribution_review_key is not None:
        canonical_dcp_attribution = lookup_maps[
            "equipment_dcp_attribution_aliases"
        ].get(dcp_attribution_review_key)
        if canonical_dcp_attribution is None:
            candidate_canonical = infer_programmatic_dcp_canonical(
                dcp_attribution_review_key
            )
            if candidate_canonical in lookup_maps["equipment_dcp_attributions"]:
                canonical_dcp_attribution = candidate_canonical
    dcp_attribution_id = None
    dcp_package_id = None
    if canonical_dcp_attribution is not None:
        dcp_attribution_id = lookup_maps["equipment_dcp_attributions"].get(
            canonical_dcp_attribution
        )
        dcp_package_id = lookup_maps["equipment_dcp_packages"].get(
            canonical_dcp_attribution
        )
        dcp_attribution_type = lookup_maps["equipment_dcp_attribution_types"].get(
            canonical_dcp_attribution,
            dcp_attribution_type,
        )
        dcp_issue = None
    return (
        dcp_attribution_id,
        dcp_attribution_type,
        dcp_attribution_review_key,
        dcp_package_id,
        dcp_issue,
    )


def resolve_equipment_location(
    lookup_maps: LookupMaps, equipment_location_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    equipment_location_review_key = normalize_equipment_location_review_key(
        equipment_location_raw
    )
    equipment_location_type, equipment_location_issue = (
        classify_equipment_location_value(equipment_location_raw)
    )
    canonical_equipment_location = None
    if equipment_location_review_key is not None:
        candidate = infer_equipment_location_canonical(equipment_location_review_key)
        if candidate is not None and candidate in lookup_maps["equipment_locations"]:
            canonical_equipment_location = candidate
        if canonical_equipment_location is None:
            canonical_equipment_location = lookup_maps[
                "equipment_location_aliases"
            ].get(equipment_location_review_key)
    equipment_location_id = None
    if canonical_equipment_location is not None:
        equipment_location_id = lookup_maps["equipment_locations"].get(
            canonical_equipment_location
        )
        equipment_location_type = "reviewed_location"
        equipment_location_issue = None
    return (
        equipment_location_id,
        equipment_location_type,
        equipment_location_review_key,
        equipment_location_issue,
    )


def resolve_supplier(
    lookup_maps: LookupMaps, supplier_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    supplier_review_key = normalize_supplier_review_key(supplier_raw)
    supplier_type, supplier_issue = classify_supplier_value(supplier_raw)
    canonical_supplier = None
    if supplier_review_key is not None:
        canonical_supplier = lookup_maps["equipment_supplier_aliases"].get(
            supplier_review_key
        )
    supplier_id = None
    if canonical_supplier is not None:
        supplier_id = lookup_maps["equipment_suppliers"].get(canonical_supplier)
        supplier_type = "reviewed_supplier"
        supplier_issue = None
    return supplier_id, supplier_type, supplier_review_key, supplier_issue


def resolve_acquisition_mode(
    lookup_maps: LookupMaps, acquisition_mode_raw: str | None
) -> tuple[int | None, str | None]:
    acquisition_mode_review_key = normalize_acquisition_mode_review_key(
        acquisition_mode_raw
    )
    _, acquisition_mode_issue = classify_acquisition_mode_value(acquisition_mode_raw)
    canonical_mode = None
    if acquisition_mode_review_key is not None:
        canonical_mode = lookup_maps["equipment_acquisition_mode_aliases"].get(
            acquisition_mode_review_key
        )
    acquisition_mode_id = None
    if canonical_mode is not None:
        acquisition_mode_id = lookup_maps["equipment_acquisition_modes"].get(
            canonical_mode
        )
        acquisition_mode_issue = None
    return acquisition_mode_id, acquisition_mode_issue


def resolve_donor(
    lookup_maps: LookupMaps, donor_raw: str | None
) -> tuple[str | None, str | None, str | None, bool]:
    donor_review_key = normalize_donor_review_key(donor_raw)
    donor_type = None
    donor_issue = None
    donor_is_internal_deped = is_internal_deped_donor(donor_raw)
    if donor_review_key is None:
        return donor_type, donor_review_key, donor_issue, donor_is_internal_deped
    if donor_is_internal_deped:
        return donor_type, donor_review_key, donor_issue, donor_is_internal_deped
    donor_type = lookup_maps["equipment_donor_aliases"].get(donor_review_key)
    if donor_type is None:
        donor_type = infer_donor_type(donor_review_key)
    if donor_type is None:
        _, donor_issue = classify_donor_value(donor_raw)
    return donor_type, donor_review_key, donor_issue, donor_is_internal_deped


def resolve_disposition_status(
    lookup_maps: LookupMaps, disposition_status_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    disposition_status_review_key = normalize_disposition_review_key(
        disposition_status_raw
    )
    disposition_status_type, disposition_status_issue = classify_disposition_value(
        disposition_status_raw
    )
    canonical_status = None
    if disposition_status_review_key is not None:
        canonical_status = lookup_maps["equipment_disposition_status_aliases"].get(
            disposition_status_review_key
        )
    disposition_status_id = None
    if canonical_status is not None:
        disposition_status_id = lookup_maps["equipment_disposition_statuses"].get(
            canonical_status
        )
        disposition_status_type = "reviewed_disposition"
        disposition_status_issue = None
    return (
        disposition_status_id,
        disposition_status_type,
        disposition_status_review_key,
        disposition_status_issue,
    )


def resolve_source_of_funds(
    lookup_maps: LookupMaps, source_of_funds_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    source_of_funds_review_key = normalize_source_of_funds_review_key(
        source_of_funds_raw
    )
    source_of_funds_type, source_of_funds_issue = classify_source_of_funds_value(
        source_of_funds_raw
    )
    canonical_fund = None
    if source_of_funds_review_key is not None:
        canonical_fund = lookup_maps["equipment_source_of_funds_aliases"].get(
            source_of_funds_review_key
        )
    source_of_funds_id = None
    if canonical_fund is not None:
        source_of_funds_id = lookup_maps["equipment_source_of_funds"].get(
            canonical_fund
        )
        source_of_funds_type = "reviewed_source_of_funds"
        source_of_funds_issue = None
    return (
        source_of_funds_id,
        source_of_funds_type,
        source_of_funds_review_key,
        source_of_funds_issue,
    )


def reconcile_acquisition_mode_with_donor(
    lookup_maps: LookupMaps,
    *,
    dcp_attribution_id: int | None,
    dcp_match_type: str | None,
    mode_id: int | None,
    donor_type: str | None,
    donor_review_key: str | None,
    donor_is_internal_deped: bool,
) -> tuple[int | None, str | None, str | None]:
    deped_purchase_id = lookup_maps["equipment_acquisition_modes"].get("DepEd Purchase")
    donation_id = lookup_maps["equipment_acquisition_modes"].get("Donation")
    is_dcp_purchase = dcp_attribution_id is not None or dcp_match_type in {
        "exact",
        "inferred",
    }
    if is_dcp_purchase or donor_is_internal_deped:
        return deped_purchase_id, None, None
    if donor_type is not None and mode_id in {None, deped_purchase_id}:
        return donation_id, donor_type, donor_review_key
    return mode_id, donor_type, donor_review_key


def resolve_equipment_condition(
    lookup_maps: LookupMaps, equipment_condition_raw: str | None
) -> tuple[int | None, str | None, str | None, str | None]:
    equipment_condition_review_key = normalize_equipment_condition_review_key(
        equipment_condition_raw
    )
    equipment_condition_type, equipment_condition_issue = (
        classify_equipment_condition_value(equipment_condition_raw)
    )
    canonical_condition = None
    if equipment_condition_review_key is not None:
        canonical_condition = lookup_maps["equipment_condition_aliases"].get(
            equipment_condition_review_key
        )
    equipment_condition_id = None
    if canonical_condition is not None:
        equipment_condition_id = lookup_maps["equipment_conditions"].get(
            canonical_condition
        )
        equipment_condition_type = "reviewed_equipment_condition"
        equipment_condition_issue = None
    return (
        equipment_condition_id,
        equipment_condition_type,
        equipment_condition_review_key,
        equipment_condition_issue,
    )


def reassign_condition_and_disposition(
    lookup_maps: LookupMaps,
    equipment_condition_raw: str | None,
    equipment_condition_id: int | None,
    equipment_condition_type: str | None,
    equipment_condition_review_key: str | None,
    equipment_condition_issue: str | None,
    disposition_status_raw: str | None,
    disposition_status_id: int | None,
    disposition_status_type: str | None,
    disposition_status_review_key: str | None,
    disposition_status_issue: str | None,
) -> tuple[
    int | None,
    str | None,
    str | None,
    str | None,
    int | None,
    str | None,
    str | None,
    str | None,
]:
    if equipment_condition_id is None and disposition_status_review_key is None:
        candidate_review_key = normalize_disposition_review_key(equipment_condition_raw)
        canonical_status = (
            lookup_maps["equipment_disposition_status_aliases"].get(
                candidate_review_key
            )
            if candidate_review_key is not None
            else None
        )
        if canonical_status is not None:
            disposition_status_id = lookup_maps["equipment_disposition_statuses"].get(
                canonical_status
            )
            disposition_status_type = "reviewed_disposition"
            disposition_status_review_key = candidate_review_key
            disposition_status_issue = None
            equipment_condition_type = None
            equipment_condition_review_key = None
            equipment_condition_issue = "auto_reassigned_to_disposition_status"

    if disposition_status_id is None and equipment_condition_review_key is None:
        candidate_review_key = normalize_equipment_condition_review_key(
            disposition_status_raw
        )
        canonical_condition = (
            lookup_maps["equipment_condition_aliases"].get(candidate_review_key)
            if candidate_review_key is not None
            else None
        )
        if canonical_condition is not None:
            equipment_condition_id = lookup_maps["equipment_conditions"].get(
                canonical_condition
            )
            equipment_condition_type = "reviewed_equipment_condition"
            equipment_condition_review_key = candidate_review_key
            equipment_condition_issue = None
            disposition_status_type = None
            disposition_status_review_key = None
            disposition_status_issue = "auto_reassigned_to_equipment_condition"

    return (
        equipment_condition_id,
        equipment_condition_type,
        equipment_condition_review_key,
        equipment_condition_issue,
        disposition_status_id,
        disposition_status_type,
        disposition_status_review_key,
        disposition_status_issue,
    )


_CONDITION_TO_DEFAULT_DISPOSITION: dict[str, str] = {
    "Serviceable": "Normal",
    "Unserviceable": "For Disposal",
    "For Repair": "Normal",
}

_DISPOSITION_TO_DEFAULT_CONDITION: dict[str, str] = {
    "Damaged due to calamity": "Not Applicable",
    "For Disposal": "Not Applicable",
}

_CONDITION_IMPLIES_FUNCTIONAL: frozenset[str] = frozenset({"Serviceable"})
_CONDITION_IMPLIES_NON_FUNCTIONAL: frozenset[str] = frozenset({"Unserviceable"})
_DISPOSITION_IMPLIES_FUNCTIONAL: frozenset[str] = frozenset({"Normal"})
_DISPOSITION_IMPLIES_NON_FUNCTIONAL: frozenset[str] = frozenset(
    {"Damaged due to calamity"}
)


def reconcile_non_functional_flag(
    is_non_functional: int | None,
    canonical_condition: str | None,
    canonical_disposition: str | None,
) -> int | None:
    """Align is_non_functional with the authoritative condition/disposition values.

    Typed condition and disposition fields are more deliberate than a checkbox, so
    they take precedence when they conflict.  Condition is checked before disposition
    since it is the primary equipment state assessment.

    This must run before apply_cross_field_defaults so the corrected flag is
    available as a guard against inferring contradictory disposition defaults.
    """
    if canonical_condition in _CONDITION_IMPLIES_FUNCTIONAL:
        return 0
    if canonical_disposition in _DISPOSITION_IMPLIES_FUNCTIONAL:
        return 0
    if canonical_condition in _CONDITION_IMPLIES_NON_FUNCTIONAL:
        return 1
    if canonical_disposition in _DISPOSITION_IMPLIES_NON_FUNCTIONAL:
        return 1
    return is_non_functional


def apply_cross_field_defaults(
    lookup_maps: LookupMaps,
    is_non_functional: int | None,
    equipment_condition_raw: str | None,
    equipment_condition_id: int | None,
    equipment_condition_type: str | None,
    equipment_condition_review_key: str | None,
    equipment_condition_issue: str | None,
    disposition_status_raw: str | None,
    disposition_status_id: int | None,
    disposition_status_type: str | None,
    disposition_status_review_key: str | None,
    disposition_status_issue: str | None,
) -> tuple[
    int | None,
    str | None,
    str | None,
    str | None,
    int | None,
    str | None,
    str | None,
    str | None,
]:
    # Rules 1-3: condition resolved, disposition absent from source
    if (
        equipment_condition_id is not None
        and disposition_status_raw is None
        and disposition_status_id is None
    ):
        canonical_condition = (
            lookup_maps["equipment_condition_aliases"].get(
                equipment_condition_review_key
            )
            if equipment_condition_review_key is not None
            else None
        )
        default_disposition = _CONDITION_TO_DEFAULT_DISPOSITION.get(
            canonical_condition or ""
        )
        # Don't infer Normal disposition when the non-functional flag is set —
        # that combination is contradictory and should surface as a DQ issue.
        if default_disposition == "Normal" and is_non_functional == 1:
            default_disposition = None
        if default_disposition is not None:
            inferred_id = lookup_maps["equipment_disposition_statuses"].get(
                default_disposition
            )
            if inferred_id is not None:
                disposition_status_id = inferred_id
                disposition_status_type = "inferred_from_condition"
                disposition_status_review_key = normalize_disposition_review_key(
                    default_disposition
                )
                disposition_status_issue = None

    # Rules 4-5: disposition resolved, condition absent from source
    if (
        disposition_status_id is not None
        and equipment_condition_raw is None
        and equipment_condition_id is None
    ):
        canonical_disposition = (
            lookup_maps["equipment_disposition_status_aliases"].get(
                disposition_status_review_key
            )
            if disposition_status_review_key is not None
            else None
        )
        default_condition = _DISPOSITION_TO_DEFAULT_CONDITION.get(
            canonical_disposition or ""
        )
        if default_condition is not None:
            inferred_id = lookup_maps["equipment_conditions"].get(default_condition)
            if inferred_id is not None:
                equipment_condition_id = inferred_id
                equipment_condition_type = "inferred_from_disposition"
                equipment_condition_review_key = (
                    normalize_equipment_condition_review_key(default_condition)
                )
                equipment_condition_issue = None

    return (
        equipment_condition_id,
        equipment_condition_type,
        equipment_condition_review_key,
        equipment_condition_issue,
        disposition_status_id,
        disposition_status_type,
        disposition_status_review_key,
        disposition_status_issue,
    )


def load_equipment(
    conn: sqlite3.Connection,
    path: str | Path,
    entity_lookup: EntityLookup,
    lookup_maps: LookupMaps,
    resolution_lookups: PersonnelResolutionLookups,
    progress: Progress | None = None,
    dcp_cost_lookup: DcpCostLookup | None = None,
    dcp_by_school_component: DcpBySchoolComponent | None = None,
) -> EquipmentIssueCounter:
    """Load cleaned equipment data into SQLite."""
    issue_counts: EquipmentIssueCounter = Counter()
    rows: list[EquipmentInsertRow] = []
    date_errors: list[DateErrorRow] = []
    issue_rows: list[EquipmentIssueRow] = []
    loaded_entity_ids: set[int] = set()
    source_file = Path(path).name
    task_id = _start_equipment_progress_task(progress, path)

    for source_row_num, row in iter_csv_rows(path, progress, task_id):
        entity_type = determine_entity_type(
            row_get(row, "governance_level", "Governance Level")
        )
        school_id = normalize_school_id(row_get(row, "school_id", "School ID"))
        region = clean_text(row_get(row, "region_name", "region", "Region"))
        division = clean_text(row_get(row, "division_name", "division", "Division"))
        source_record_id = normalize_school_id(row_get(row, "record_id", "ID"))
        natural_key = build_natural_key(entity_type, school_id, region, division)
        entity_id = _resolve_equipment_entity_id(
            entity_lookup,
            natural_key,
            issue_counts,
            issue_rows,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
        )
        if entity_id is None:
            continue
        loaded_entity_ids.add(entity_id)
        accountable_officer = clean_text(
            row_get(row, "accountable_officer", "Accountable Officer")
        )
        custodian_end_user = clean_text(
            row_get(row, "end_user", "Custodian / End User")
        )
        received_by = clean_text(row_get(row, "received_by", "Received by"))
        (
            accountable_personnel_id,
            accountable_normalized_name,
            accountable_employee_id,
            accountable_link_status,
        ) = resolve_person_reference(
            accountable_officer,
            entity_id,
            entity_type,
            region,
            division,
            resolution_lookups,
        )
        (
            custodian_personnel_id,
            custodian_normalized_name,
            custodian_employee_id,
            custodian_link_status,
        ) = resolve_person_reference(
            custodian_end_user,
            entity_id,
            entity_type,
            region,
            division,
            resolution_lookups,
        )
        (
            received_by_personnel_id,
            received_by_normalized_name,
            received_by_employee_id,
            received_by_link_status,
        ) = resolve_person_reference(
            received_by,
            entity_id,
            entity_type,
            region,
            division,
            resolution_lookups,
        )

        category_raw = clean_text(row_get(row, "category", "Category"))
        category_name = normalize_equipment_category(category_raw)
        item_raw = clean_text(row_get(row, "item", "Item"))
        unit_raw = clean_text(row_get(row, "uom", "Unit of Measure"))
        brand_raw = clean_text(
            row_get(row, "brand_manufacturer", "Brand / Manufacturer")
        )
        model_raw = clean_text(row_get(row, "model", "Model"))
        dcp_package_raw = clean_text(row_get(row, "dcp_package", "DCP Package"))
        dcp_year_package_raw = clean_text(
            row_get(row, "dcp_year", "DCP Year Package ", "DCP Year Package")
        )
        mode_raw = clean_text(row_get(row, "mode_acquisition", "Mode of Acquisition"))
        source_raw = clean_text(
            row_get(row, "source_acquisition", "Source of Acquisition")
        )
        equipment_location_raw = clean_text(
            row_get(row, "equipment_location", "Equipment Location")
        )
        donor_raw = clean_text(row_get(row, "donor", "Donor"))
        supplier_raw = clean_text(
            row_get(
                row, "supplier", "Supplier / Distributor", "Supplier / Distributor "
            )
        )
        source_of_funds_raw = clean_text(
            row_get(row, "source_fund", "Source of Funds", "Source of Funds\n")
        )
        equipment_condition_raw = clean_text(
            row_get(
                row,
                "equipment_condition",
                "erquipment_condition",
                "Equipment Condition",
            )
        )
        disposition_status_raw = clean_text(
            row_get(
                row,
                "disposition_status",
                "Accountability / Disposition Status",
                "Accountability / Disposition Status ",
            )
        )

        item_id = lookup_maps["equipment_items"].get(normalize_equipment_item(item_raw))
        unit_id = lookup_maps["equipment_units"].get(
            normalize_low_cardinality_dimension("unit", unit_raw)
        )
        brand_name, brand_issue = canonicalize_equipment_dimension("brand", brand_raw)
        brand_id = lookup_maps["equipment_brands"].get(brand_name)
        _, model_issue = canonicalize_equipment_dimension("model", model_raw)
        model_id = None
        is_non_functional = to_bool_int(
            row_get(row, "non_functional", "Non-Functional")
        )
        is_non_dcp = to_bool_int(row_get(row, "non_dcp", "Non-DCP"))
        (
            dcp_attribution_id,
            dcp_attribution_type,
            dcp_attribution_review_key,
            dcp_package_id,
            dcp_issue,
        ) = resolve_dcp_attribution(
            lookup_maps,
            dcp_package_raw,
            is_non_dcp,
        )
        dcp_year_package_id = lookup_maps["equipment_dcp_years"].get(
            normalize_low_cardinality_dimension("dcp_year", dcp_year_package_raw)
        )
        mode_id, mode_issue = resolve_acquisition_mode(lookup_maps, mode_raw)
        source_name, source_issue = canonicalize_equipment_dimension(
            "acquisition_source", source_raw
        )
        source_id = lookup_maps["equipment_acquisition_sources"].get(source_name)
        donor_type, donor_review_key, donor_issue, donor_is_internal_deped = (
            resolve_donor(lookup_maps, donor_raw)
        )
        (
            equipment_location_id,
            equipment_location_type,
            equipment_location_review_key,
            equipment_location_issue,
        ) = resolve_equipment_location(lookup_maps, equipment_location_raw)
        supplier_id, supplier_type, supplier_review_key, supplier_issue = (
            resolve_supplier(lookup_maps, supplier_raw)
        )
        (
            source_of_funds_id,
            source_of_funds_type,
            source_of_funds_review_key,
            source_of_funds_issue,
        ) = resolve_source_of_funds(lookup_maps, source_of_funds_raw)
        (
            equipment_condition_id,
            equipment_condition_type,
            equipment_condition_review_key,
            equipment_condition_issue,
        ) = resolve_equipment_condition(lookup_maps, equipment_condition_raw)
        (
            disposition_status_id,
            disposition_status_type,
            disposition_status_review_key,
            disposition_status_issue,
        ) = resolve_disposition_status(lookup_maps, disposition_status_raw)
        (
            equipment_condition_id,
            equipment_condition_type,
            equipment_condition_review_key,
            equipment_condition_issue,
            disposition_status_id,
            disposition_status_type,
            disposition_status_review_key,
            disposition_status_issue,
        ) = reassign_condition_and_disposition(
            lookup_maps,
            equipment_condition_raw,
            equipment_condition_id,
            equipment_condition_type,
            equipment_condition_review_key,
            equipment_condition_issue,
            disposition_status_raw,
            disposition_status_id,
            disposition_status_type,
            disposition_status_review_key,
            disposition_status_issue,
        )
        is_non_functional = reconcile_non_functional_flag(
            is_non_functional,
            lookup_maps["equipment_condition_aliases"].get(
                equipment_condition_review_key
            )
            if equipment_condition_review_key is not None
            else None,
            lookup_maps["equipment_disposition_status_aliases"].get(
                disposition_status_review_key
            )
            if disposition_status_review_key is not None
            else None,
        )
        (
            equipment_condition_id,
            equipment_condition_type,
            equipment_condition_review_key,
            equipment_condition_issue,
            disposition_status_id,
            disposition_status_type,
            disposition_status_review_key,
            disposition_status_issue,
        ) = apply_cross_field_defaults(
            lookup_maps,
            is_non_functional,
            equipment_condition_raw,
            equipment_condition_id,
            equipment_condition_type,
            equipment_condition_review_key,
            equipment_condition_issue,
            disposition_status_raw,
            disposition_status_id,
            disposition_status_type,
            disposition_status_review_key,
            disposition_status_issue,
        )

        _log_row_dimension_issues(
            issue_counts,
            issue_rows,
            source_file=source_file,
            source_row_num=source_row_num,
            source_record_id=source_record_id,
            issues=(
                ("brand", brand_issue, brand_raw),
                ("model", model_issue, model_raw),
                ("dcp_attribution", dcp_issue, dcp_package_raw),
                ("mode_of_acquisition", mode_issue, mode_raw),
                ("source_of_acquisition", source_issue, source_raw),
                ("donor", donor_issue, donor_raw),
                (
                    "equipment_location",
                    equipment_location_issue,
                    equipment_location_raw,
                ),
                ("supplier", supplier_issue, supplier_raw),
                ("source_of_funds", source_of_funds_issue, source_of_funds_raw),
                (
                    "equipment_condition",
                    equipment_condition_issue,
                    equipment_condition_raw,
                ),
                (
                    "disposition_status",
                    disposition_status_issue,
                    disposition_status_raw,
                ),
            ),
        )

        acquisition_date = normalize_bounded_date(
            parse_date(row_get(row, "received_date", "Acquisition / Received Date")),
            minimum_date=MIN_ACQUISITION_DATE,
        )
        date_accountable_officer = parse_date(
            row_get(
                row,
                "date_assigned_accountable_officer",
                "Date assigned to / received by Accountable Officer",
            )
        )
        date_custodian = normalize_bounded_date(
            parse_date(
                row_get(
                    row,
                    "date_assigned_end_user",
                    "Date assigned to / received by Custodian / End User",
                )
            ),
            minimum_date=MIN_ASSIGNMENT_DATE,
        )
        date_received_new = normalize_bounded_date(
            parse_date(
                row_get(
                    row,
                    "date_received_new_accountable",
                    "Date received by New Accountable Officer / Custodian / End User",
                )
            ),
            minimum_date=MIN_ASSIGNMENT_DATE,
        )
        end_of_warranty = parse_date(
            row_get(row, "end_warranty_date", "End of Warranty")
        )

        # DCP cross-validation (only runs when --dcp-dataset-db was supplied).
        if dcp_cost_lookup is not None and dcp_by_school_component is not None:
            item_canonical = (
                lookup_maps["equipment_item_id_to_canonical"].get(item_id)
                if item_id is not None
                else None
            )
            dcp_year_int = (
                lookup_maps["equipment_dcp_year_id_to_int"].get(dcp_year_package_id)
                if dcp_year_package_id is not None
                else None
            )
            # source_name is the canonical acquisition source string (e.g. "Central Office").
            (
                dcp_match_type,
                dcp_cost,
                dcp_year,
                dcp_component,
                dcp_supplier,
            ) = resolve_dcp_cost(
                school_id,
                item_canonical,
                dcp_year_int,
                source_name,
                acquisition_date,
                date_received_new,
                dcp_cost_lookup,
                dcp_by_school_component,
            )
        else:
            dcp_match_type = dcp_cost = dcp_year = dcp_component = dcp_supplier = None

        mode_id, donor_type, donor_review_key = reconcile_acquisition_mode_with_donor(
            lookup_maps,
            dcp_attribution_id=dcp_attribution_id,
            dcp_match_type=dcp_match_type,
            mode_id=mode_id,
            donor_type=donor_type,
            donor_review_key=donor_review_key,
            donor_is_internal_deped=donor_is_internal_deped,
        )
        if mode_id is not None:
            mode_issue = None
        if donor_type is not None or donor_is_internal_deped:
            donor_issue = None

        date_parse_candidates: tuple[DateParseCandidate, ...] = (
            (
                "acquisition_date",
                row_get(row, "received_date", "Acquisition / Received Date"),
                acquisition_date,
            ),
            (
                "date_accountable_officer",
                row_get(
                    row,
                    "date_assigned_accountable_officer",
                    "Date assigned to / received by Accountable Officer",
                ),
                date_accountable_officer,
            ),
            (
                "date_custodian",
                row_get(
                    row,
                    "date_assigned_end_user",
                    "Date assigned to / received by Custodian / End User",
                ),
                date_custodian,
            ),
            (
                "date_received_new",
                row_get(
                    row,
                    "date_received_new_accountable",
                    "Date received by New Accountable Officer / Custodian / End User",
                ),
                date_received_new,
            ),
            (
                "end_of_warranty",
                row_get(row, "end_warranty_date", "End of Warranty"),
                end_of_warranty,
            ),
        )
        for column_name, raw_value, parsed_value in date_parse_candidates:
            maybe_log_date_error(
                cast(list[tuple[object, ...]], date_errors),
                EQUIPMENT_SOURCE,
                source_file,
                source_row_num,
                source_record_id,
                column_name,
                raw_value,
                parsed_value,
            )

        rows.append(
            (
                entity_id,
                school_id,
                accountable_personnel_id,
                custodian_personnel_id,
                received_by_personnel_id,
                clean_text(row_get(row, "property_no", "Property No.")),
                clean_text(
                    row_get(row, "old_property_no", "Old / Previous Property No.")
                ),
                clean_text(row_get(row, "serial_number", "Serial Number")),
                item_id,
                item_raw,
                clean_text(row_get(row, "other_item", "Other Item")),
                unit_id,
                unit_raw,
                brand_id,
                brand_raw,
                model_id,
                model_raw,
                clean_text(row_get(row, "specifications", "Specifications")),
                is_non_dcp,
                dcp_attribution_id,
                dcp_attribution_type,
                dcp_attribution_review_key,
                dcp_package_id,
                dcp_package_raw,
                dcp_year_package_id,
                dcp_year_package_raw,
                lookup_maps["equipment_categories"][category_name],
                category_raw,
                clean_text(row_get(row, "classification", "Classification")),
                normalize_identifier(row_get(row, "gl_sl_code", "GL-SL Code")),
                clean_text(row_get(row, "uacs", "UACS")),
                parse_cost(row_get(row, "acquisition_cost", "Acquisition Cost")),
                acquisition_date,
                dcp_cost,
                dcp_year,
                dcp_component,
                dcp_match_type,
                dcp_supplier,
                parse_float(
                    row_get(row, "estimated_useful_life", "Estimated Useful Life")
                ),
                mode_id,
                mode_raw,
                source_id,
                source_raw,
                donor_raw,
                donor_type,
                donor_review_key,
                source_of_funds_id,
                source_of_funds_type,
                source_of_funds_review_key,
                source_of_funds_raw,
                clean_text(row_get(row, "allotment_class", "Allotment Class")),
                clean_text(row_get(row, "pm_plan", "Procurement Management Plan")),
                clean_text(
                    row_get(row, "supporting_documents1", "Supporting Documents")
                ),
                clean_text(row_get(row, "or_si_dr_iar_no", "OR / SI / DR / IAR No.")),
                clean_text(row_get(row, "transaction_type", "Transaction Type")),
                accountable_officer,
                accountable_normalized_name,
                accountable_employee_id,
                accountable_link_status,
                date_accountable_officer,
                custodian_end_user,
                custodian_normalized_name,
                custodian_employee_id,
                custodian_link_status,
                date_custodian,
                received_by,
                received_by_normalized_name,
                received_by_employee_id,
                received_by_link_status,
                date_received_new,
                clean_text(
                    row_get(row, "supporting_documents2", "Supporting Documents 2")
                )
                or clean_text(
                    row_get(row, "supporting_documents1", "Supporting Documents")
                ),
                clean_text(
                    row_get(
                        row, "par_ics_rrsp_rs_wmr_no", "PAR / ICS / RRSP / RS / WMR No."
                    )
                ),
                supplier_id,
                supplier_type,
                supplier_review_key,
                supplier_raw,
                to_bool_int(row_get(row, "under_warranty", "Under Warranty")),
                end_of_warranty,
                equipment_location_id,
                equipment_location_type,
                equipment_location_review_key,
                equipment_location_raw,
                is_non_functional,
                equipment_condition_id,
                equipment_condition_type,
                equipment_condition_review_key,
                equipment_condition_raw,
                disposition_status_id,
                disposition_status_type,
                disposition_status_review_key,
                disposition_status_raw,
                clean_text(row_get(row, "remarks", "Remarks")),
                source_file,
                source_row_num,
                source_record_id,
            )
        )

        if len(rows) >= BATCH_SIZE:
            _flush_pending_rows(conn, rows, issue_rows, date_errors)
            conn.commit()
            rows.clear()
            date_errors.clear()
            issue_rows.clear()

    _flush_pending_rows(conn, rows, issue_rows, date_errors)
    if loaded_entity_ids:
        conn.executemany(
            "UPDATE entities SET has_equipment = 1 WHERE entity_id = ?",
            [(entity_id,) for entity_id in sorted(loaded_entity_ids)],
        )
    conn.commit()
    if progress is not None and task_id is not None:
        progress.update(task_id, completed=Path(path).stat().st_size)
    return issue_counts
