from __future__ import annotations

import re
from dataclasses import dataclass
from importlib.resources import files

import yaml

from ._dictionary_aliases import build_alias_records
from ._review_keys import clean_review_text, normalize_review_key

_NULL_PATTERNS = (
    re.compile(r"^0+$"),
    re.compile(r"^\d+$"),
    re.compile(r"\bnot applicable\b", re.IGNORECASE),
    re.compile(r"\bno data found\b", re.IGNORECASE),
    re.compile(r"\bunknown\b", re.IGNORECASE),
    re.compile(r"\bun-known\b", re.IGNORECASE),
    re.compile(r"\bnone\b", re.IGNORECASE),
    re.compile(r"\bunidentified\b", re.IGNORECASE),
    re.compile(r"\bn/?a\b", re.IGNORECASE),
)

_INTERNAL_DEPED_PATTERNS = (
    re.compile(r"\bdeped\b"),
    re.compile(r"\bdepartment of education\b"),
    re.compile(r"\bosec\b"),
    re.compile(r"\bdcp\b"),
    re.compile(r"\bcentral office\b"),
    re.compile(r"\bdeped central\b"),
    re.compile(r"\bdeped ncr\b"),
    re.compile(r"\bregional office\b"),
    re.compile(r"\bschool division office\b"),
    re.compile(r"\bdivision office\b"),
    re.compile(r"\bmooe\b"),
    re.compile(r"^central$"),
)

_PTA_PATTERNS = (
    re.compile(r"\bpta\b"),
    re.compile(r"\bspta\b"),
    re.compile(r"\bparent teacher"),
    re.compile(r"\balumni\b"),
)

_LGU_PATTERNS = (
    re.compile(r"\blgu\b"),
    re.compile(r"\blocal government\b"),
    re.compile(r"\bcity government\b"),
    re.compile(r"\bmunicipal government\b"),
    re.compile(r"\bprovincial government\b"),
    re.compile(r"\bprovince of\b"),
    re.compile(r"\bmayor\b"),
    re.compile(r"\bsef\b"),
    re.compile(r"\bcity of\b"),
    re.compile(r"\bmunicipality of\b"),
    re.compile(r"^lgu of\b"),
    re.compile(r"^[a-z0-9 .,'-]+-lgu$"),
    re.compile(r"^[a-z0-9 .,'-]+ city$"),
)

_NGA_PATTERNS = (
    re.compile(r"\bdepartment of\b"),
    re.compile(r"\bcommission on\b"),
    re.compile(r"\badministration\b"),
    re.compile(r"\bauthority\b"),
    re.compile(r"\binsurance system\b"),
    re.compile(r"\bdepartment of trade and industry\b"),
    re.compile(r"\bgsis\b"),
    re.compile(r"\bdict\b"),
)

_PRIVATE_PATTERNS = (
    re.compile(r"\bfoundation\b"),
    re.compile(r"\bcompany\b"),
    re.compile(r"\bconsultancy\b"),
    re.compile(r"\bassociation\b"),
    re.compile(r"\bcooperative\b"),
    re.compile(r"\bfamily\b"),
    re.compile(r"\buniversity\b"),
    re.compile(r"\bacademy\b"),
    re.compile(r"\bmarketing\b"),
    re.compile(r"\btechnolog(?:y|ies)\b"),
    re.compile(r"\bchamber\b"),
    re.compile(r"\bincorporated\b"),
    re.compile(r"\binc\b"),
    re.compile(r"\bcorporation\b"),
    re.compile(r"\bcorp\b"),
)

_SCHOOL_BOARD_REVIEW_KEYS = frozenset(
    {
        "psb",
        "lsb",
        "local school board",
        "provincial school board",
        "public school board",
        "public school board psb",
    }
)


@dataclass(frozen=True)
class EquipmentDonorAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_donor_review_key(value: str | None) -> str | None:
    text = clean_review_text(value, null_patterns=_NULL_PATTERNS)
    if text is None:
        return None
    return normalize_review_key(text)


def is_internal_deped_donor(raw_value: str | None) -> bool:
    review_key = normalize_donor_review_key(raw_value)
    if review_key is None:
        return False
    return _matches_any_pattern(review_key, _INTERNAL_DEPED_PATTERNS)


def infer_donor_type(review_key: str | None) -> str | None:
    if review_key is None:
        return None
    if _matches_any_pattern(review_key, _PTA_PATTERNS):
        return "PTA"
    if review_key in _SCHOOL_BOARD_REVIEW_KEYS:
        return "School Board"
    if _matches_any_pattern(review_key, _LGU_PATTERNS):
        return "LGU"
    if _matches_any_pattern(review_key, _NGA_PATTERNS):
        return "NGA"
    if _matches_any_pattern(review_key, _PRIVATE_PATTERNS):
        return "private"
    return None


def classify_donor_value(raw_value: str | None) -> tuple[str | None, str | None]:
    review_key = normalize_donor_review_key(raw_value)
    if review_key is None:
        return None, None
    if is_internal_deped_donor(raw_value):
        return None, None
    return "unclassified", "unclassified"


def load_reviewed_donor_aliases() -> list[EquipmentDonorAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/donor_dictionary.yml"
    )
    with dictionary_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    return build_alias_records(
        data,
        normalize_donor_review_key,
        EquipmentDonorAliasRecord,
    )


def _matches_any_pattern(
    review_key: str, patterns: tuple[re.Pattern[str], ...]
) -> bool:
    return any(pattern.search(review_key) for pattern in patterns)
