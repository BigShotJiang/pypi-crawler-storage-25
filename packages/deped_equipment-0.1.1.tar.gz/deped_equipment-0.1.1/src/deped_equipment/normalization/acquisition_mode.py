from __future__ import annotations

import re
from dataclasses import dataclass
from importlib.resources import files

import yaml
from deped_dcp_template.cleaners import clean_text

from ._dictionary_aliases import build_alias_records
from ._review_keys import clean_review_text, normalize_review_key

_INVALID_PATTERNS = (
    re.compile(r"^0+$"),
    re.compile(r"^\d+$"),
    re.compile(r"\bno data found\b", re.IGNORECASE),
    re.compile(r"\bnot applicable\b", re.IGNORECASE),
    re.compile(r"\bunable to locate\b", re.IGNORECASE),
    re.compile(r"\bno proper turnover documents\b", re.IGNORECASE),
)


@dataclass(frozen=True)
class EquipmentAcquisitionModeAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_acquisition_mode_review_key(value: str | None) -> str | None:
    text = clean_review_text(value, null_patterns=_INVALID_PATTERNS)
    if text is None:
        return None
    return normalize_review_key(text)


def classify_acquisition_mode_value(
    raw_value: str | None,
) -> tuple[str | None, str | None]:
    text = clean_text(raw_value)
    if text is not None:
        lowered = text.casefold()
        for pattern in _INVALID_PATTERNS:
            if pattern.search(lowered):
                return "invalid_value", "invalid_value"
    review_key = normalize_acquisition_mode_review_key(raw_value)
    if review_key is None:
        return None, None
    return "unclassified", "unclassified"


def load_reviewed_acquisition_mode_aliases() -> list[
    EquipmentAcquisitionModeAliasRecord
]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/acquisition_mode_dictionary.yml"
    )
    with dictionary_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    return build_alias_records(
        data,
        normalize_acquisition_mode_review_key,
        EquipmentAcquisitionModeAliasRecord,
    )
