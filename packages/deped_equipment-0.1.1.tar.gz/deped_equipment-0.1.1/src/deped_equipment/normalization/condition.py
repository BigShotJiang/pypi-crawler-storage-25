from __future__ import annotations

import re
from dataclasses import dataclass
from importlib.resources import files

import yaml
from deped_dcp_template.cleaners import clean_text

from ._dictionary_aliases import build_alias_records
from ._review_keys import clean_review_text, normalize_review_key

_INVALID_PATTERNS = (
    re.compile(r"\binventory custodian slip\b"),
    re.compile(r"\breturned\b"),
    re.compile(r"\btransferred\b"),
)

_NULL_PATTERNS = (re.compile(r"^[✓0-9]+$"),)

_MIN_VALUE_LENGTH = 4


@dataclass(frozen=True)
class EquipmentConditionAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def _normalize_equipment_condition_candidate(value: str | None) -> str | None:
    return normalize_review_key(value)


def _load_short_valid_review_keys() -> frozenset[str]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/equipment_condition_dictionary.yml"
    )
    with dictionary_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    review_keys: set[str] = set()
    for canonical_name, entry in data.items():
        if entry.get("draft"):
            continue
        for raw_value in [canonical_name, *(entry.get("aliases") or [])]:
            alias_value = clean_text(raw_value)
            if alias_value is None or len(alias_value) > _MIN_VALUE_LENGTH:
                continue
            review_key = _normalize_equipment_condition_candidate(alias_value)
            if review_key is not None:
                review_keys.add(review_key)
    return frozenset(review_keys)


_SHORT_VALID_REVIEW_KEYS = _load_short_valid_review_keys()


def normalize_equipment_condition_review_key(value: str | None) -> str | None:
    text = clean_review_text(value, null_patterns=_NULL_PATTERNS)
    if text is None:
        return None
    review_key = _normalize_equipment_condition_candidate(text)
    if review_key is None:
        return None
    if len(text) <= _MIN_VALUE_LENGTH and review_key not in _SHORT_VALID_REVIEW_KEYS:
        return None
    return review_key


def classify_equipment_condition_value(
    raw_value: str | None,
) -> tuple[str | None, str | None]:
    review_key = normalize_equipment_condition_review_key(raw_value)
    if review_key is None:
        return None, None
    text = clean_text(raw_value)
    if text is not None:
        lowered = text.casefold()
        for pattern in _INVALID_PATTERNS:
            if pattern.search(lowered):
                return (
                    "invalid_equipment_condition_value",
                    "invalid_equipment_condition_value",
                )
    return "unclassified", "unclassified"


def load_reviewed_equipment_condition_aliases() -> list[EquipmentConditionAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/equipment_condition_dictionary.yml"
    )
    with dictionary_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    return build_alias_records(
        data,
        normalize_equipment_condition_review_key,
        EquipmentConditionAliasRecord,
    )
