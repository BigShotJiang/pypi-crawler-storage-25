from __future__ import annotations

import re
from dataclasses import dataclass
from importlib.resources import files

import yaml
from deped_dcp_template.cleaners import clean_text

from ._dictionary_aliases import build_alias_records
from ._review_keys import normalize_review_key

_INVALID_PATTERNS = (
    re.compile(r"\bnot applicable\b"),
    re.compile(r"\bnone on record\b"),
    re.compile(r"\bno document"),
    re.compile(r"\binventory custodian slip\b"),
    re.compile(r"\bdelivery receipt\b"),
    re.compile(r"^\d+$"),
)


@dataclass(frozen=True)
class SourceOfFundsAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_source_of_funds_review_key(value: str | None) -> str | None:
    return normalize_review_key(value)


def classify_source_of_funds_value(
    raw_value: str | None,
) -> tuple[str | None, str | None]:
    text = clean_text(raw_value)
    if text is not None:
        lowered = text.casefold()
        for pattern in _INVALID_PATTERNS:
            if pattern.search(lowered):
                return "invalid_source_of_funds_value", "invalid_source_of_funds_value"
    review_key = normalize_source_of_funds_review_key(raw_value)
    if review_key is None:
        return None, None
    return "unclassified", "unclassified"


def load_reviewed_source_of_funds_aliases() -> list[SourceOfFundsAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/source_of_funds_dictionary.yml"
    )
    with dictionary_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    return build_alias_records(
        data,
        normalize_source_of_funds_review_key,
        SourceOfFundsAliasRecord,
    )
