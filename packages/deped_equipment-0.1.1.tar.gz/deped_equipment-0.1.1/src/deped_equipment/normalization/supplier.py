from __future__ import annotations

import re
from dataclasses import dataclass
from importlib.resources import files

import yaml

from ._dictionary_aliases import build_alias_records
from ._review_keys import normalize_review_key

_INTERNAL_SUPPLIER_PATTERNS = (
    re.compile(r"\bdeped\b"),
    re.compile(r"\bcentral office\b"),
    re.compile(r"\bdivision office\b"),
    re.compile(r"\bsdo\b"),
    re.compile(r"\blgu\b"),
    re.compile(r"\bnot applicable\b"),
)


@dataclass(frozen=True)
class EquipmentSupplierAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_supplier_review_key(value: str | None) -> str | None:
    return normalize_review_key(
        value,
        replacements=(
            (re.compile(r"\bincorporated\b"), "inc"),
            (re.compile(r"\bphilippines\b"), "phils"),
            (re.compile(r"\bcorporation\b"), "corp"),
            (re.compile(r"\bmarketing\b"), "mktg"),
            (re.compile(r"\bjv\b"), "joint venture"),
        ),
    )


def classify_supplier_value(raw_value: str | None) -> tuple[str | None, str | None]:
    review_key = normalize_supplier_review_key(raw_value)
    if review_key is None:
        return None, None
    for pattern in _INTERNAL_SUPPLIER_PATTERNS:
        if pattern.search(review_key):
            return "internal_or_non_supplier", "internal_or_non_supplier"
    return "unclassified", "unclassified"


def load_reviewed_supplier_aliases() -> list[EquipmentSupplierAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/supplier_dictionary.yml"
    )
    with dictionary_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    return build_alias_records(
        data,
        normalize_supplier_review_key,
        EquipmentSupplierAliasRecord,
    )
