from __future__ import annotations

import re
from dataclasses import dataclass
from importlib.resources import files

import yaml

from ._dictionary_aliases import build_alias_records
from ._review_keys import normalize_review_key

_EQUIPMENT_LOCATION_CANONICALS = [
    "classroom",
    "ict/lab",
    "admin/office",
    "principal",
    "faculty",
    "stock room",
    "lib",
    "als",
    "clinic",
    "canteen",
    "personnel",
    "not_applicable",
]

_ALS_PATTERN = re.compile(r"\bals\b")
_CLASSROOM_PATTERN = re.compile(
    r"\b("
    r"classroom|class\s+room|classrooms"
    r"|grades?\s+(?:\d+[a-z]?|[ivx]{1,4}|one|two|three|four|five|six)"
    r"(?:\s+(?:classroom|room))?"
    r"|kinder(?:garten)?\s+(?:classroom|room)"
    r")\b"
)
_ICT_LAB_PATTERN = re.compile(
    r"\b(ict|computer|comlab|eclassroom|e room|e-room|laboratory|laboratories|lab)\b"
)
_PRINCIPAL_PATTERN = re.compile(r"\b(principal|school head)\b")
_FACULTY_PATTERN = re.compile(r"\bfaculty\b")
_STOCK_ROOM_PATTERN = re.compile(
    r"\b(stock\s*room|storage\s*room|stockroom|supply\s*room|supply\s*office|property\s*room|physical facilities room)\b"
)
_LIB_PATTERN = re.compile(r"\b(library|e library|e-library|lib)\b")
_ADMIN_PATTERN = re.compile(
    r"\b(admin(istrative)?|office|division office|sdo|a?sds|accounting|cid|sgod|ictu)\b"
)
_PERSONNEL_PATTERN = re.compile(
    r"\b(teacher|teachers|teaching|personnel|end\s+user|student)\b"
)
_SCHOOL_NAME_PATTERN = re.compile(
    r"\b(campus|integrated\s+school|national\s+high\s+school|elementary\s+school|central\s+school)\b"
    r"|\b(es|mihs|inhs)\b"
)
_PURE_DIGIT_PATTERN = re.compile(r"^\d+$")
_ROOM_NUMBER_PATTERN = re.compile(r"^room\s+(?:no\s+)?\d+$")
_GENERIC_INVALID_PATTERN = re.compile(
    r"\b(school|elementary school|high school|building)\b"
)


@dataclass(frozen=True)
class EquipmentLocationAliasRecord:
    alias_value: str
    normalized_alias_value: str
    canonical_name: str


def normalize_equipment_location_review_key(value: str | None) -> str | None:
    return normalize_review_key(
        value,
        replacements=(
            (re.compile(r"\be[\s-]?classroom\b"), "eclassroom"),
            (re.compile(r"\be[\s-]?library\b"), "elibrary"),
            (re.compile(r"\bprincipal'?s\b"), "principal"),
        ),
    )


def _has_specific_location_pattern(review_key: str) -> bool:
    return bool(
        _CLASSROOM_PATTERN.search(review_key)
        or _ICT_LAB_PATTERN.search(review_key)
        or _PRINCIPAL_PATTERN.search(review_key)
        or _FACULTY_PATTERN.search(review_key)
        or _STOCK_ROOM_PATTERN.search(review_key)
        or _LIB_PATTERN.search(review_key)
        or _ADMIN_PATTERN.search(review_key)
        or _ALS_PATTERN.search(review_key)
        or _PERSONNEL_PATTERN.search(review_key)
    )


def classify_equipment_location_value(
    raw_value: str | None,
) -> tuple[str | None, str | None]:
    review_key = normalize_equipment_location_review_key(raw_value)
    if review_key is None:
        return None, None
    if _PURE_DIGIT_PATTERN.match(review_key):
        return "invalid_pure_digit_location", "invalid_pure_digit_location"
    if _GENERIC_INVALID_PATTERN.search(
        review_key
    ) and not _has_specific_location_pattern(review_key):
        return "invalid_generic_location", "invalid_generic_location"
    if _SCHOOL_NAME_PATTERN.search(review_key) and not _has_specific_location_pattern(
        review_key
    ):
        return "invalid_school_name_location", "invalid_school_name_location"
    return "unclassified", "unclassified"


def iter_equipment_location_canonicals() -> list[str]:
    return _EQUIPMENT_LOCATION_CANONICALS


_INFERENCE_RULES: list[tuple[re.Pattern[str], str]] = [
    (_ALS_PATTERN, "als"),
    (_LIB_PATTERN, "lib"),
    (_CLASSROOM_PATTERN, "classroom"),
    (_ICT_LAB_PATTERN, "ict/lab"),
    (_PRINCIPAL_PATTERN, "principal"),
    (_FACULTY_PATTERN, "faculty"),
    (_STOCK_ROOM_PATTERN, "stock room"),
    (_ADMIN_PATTERN, "admin/office"),
    (_PERSONNEL_PATTERN, "personnel"),
]


def infer_equipment_location_canonical(review_key: str | None) -> str | None:
    if review_key is None:
        return None
    for pattern, canonical in _INFERENCE_RULES:
        if pattern.search(review_key):
            return canonical
    if _ROOM_NUMBER_PATTERN.fullmatch(review_key):
        return "classroom"
    return None


def load_reviewed_equipment_location_aliases() -> list[EquipmentLocationAliasRecord]:
    dictionary_path = files("deped_equipment").joinpath(
        "dictionaries/equipment_location_dictionary.yml"
    )
    with dictionary_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    return build_alias_records(
        data,
        normalize_equipment_location_review_key,
        EquipmentLocationAliasRecord,
    )
