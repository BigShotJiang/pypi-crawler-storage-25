from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import TypeVar

from deped_dcp_template.cleaners import clean_text

T = TypeVar("T")


def build_alias_records(
    data: dict[str, dict],
    normalize: Callable[[str | None], str | None],
    record_factory: Callable[[str, str, str], T],
) -> list[T]:
    aliases_by_normalized: dict[str, T] = {}
    for canonical_name, entry in data.items():
        if entry.get("draft"):
            continue
        for alias_value in _iter_alias_values(
            canonical_name, entry.get("aliases") or []
        ):
            normalized_alias_value = normalize(alias_value)
            if normalized_alias_value is None:
                continue
            aliases_by_normalized.setdefault(
                normalized_alias_value,
                record_factory(alias_value, normalized_alias_value, canonical_name),
            )
    return sorted(
        aliases_by_normalized.values(),
        key=lambda row: (row.normalized_alias_value, row.alias_value),
    )


def _iter_alias_values(
    canonical_name: str, explicit_aliases: Iterable[str | None]
) -> list[str]:
    alias_values: list[str] = []
    seen: set[str] = set()
    for raw_value in [canonical_name, *explicit_aliases]:
        alias_value = clean_text(raw_value)
        if alias_value is None or alias_value in seen:
            continue
        seen.add(alias_value)
        alias_values.append(alias_value)
    return alias_values
