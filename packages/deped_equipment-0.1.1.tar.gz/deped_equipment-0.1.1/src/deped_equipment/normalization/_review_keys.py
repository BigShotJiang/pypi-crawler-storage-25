from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable
from re import Pattern

from deped_dcp_template.cleaners import clean_text

_DASH_PATTERN = re.compile(r"[‐‑–—−]+")
_NON_ALNUM_PATTERN = re.compile(r"[^a-z0-9]+")
_WHITESPACE_PATTERN = re.compile(r"\s+")


def clean_review_text(
    value: str | None,
    *,
    min_value_length: int | None = None,
    null_patterns: Iterable[Pattern[str]] = (),
) -> str | None:
    text = clean_text(value)
    if text is None:
        return None
    if min_value_length is not None and len(text) <= min_value_length:
        return None
    for pattern in null_patterns:
        if pattern.search(text):
            return None
    return text


def normalize_review_key(
    value: str | None,
    *,
    min_value_length: int | None = None,
    null_patterns: Iterable[Pattern[str]] = (),
    replacements: Iterable[tuple[Pattern[str], str]] = (),
) -> str | None:
    text = clean_review_text(
        value,
        min_value_length=min_value_length,
        null_patterns=null_patterns,
    )
    if text is None:
        return None
    normalized = unicodedata.normalize("NFKC", text).casefold()
    normalized = _DASH_PATTERN.sub("-", normalized)
    normalized = normalized.replace("&", " and ")
    for pattern, replacement in replacements:
        normalized = pattern.sub(replacement, normalized)
    normalized = _NON_ALNUM_PATTERN.sub(" ", normalized)
    normalized = _WHITESPACE_PATTERN.sub(" ", normalized).strip()
    return normalized or None
