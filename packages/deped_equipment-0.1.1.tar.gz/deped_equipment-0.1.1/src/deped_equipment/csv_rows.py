from __future__ import annotations

from .types import CsvRow


def row_get(row: CsvRow, *keys: str) -> str | None:
    """Return the first present CSV value across header variants."""
    for key in keys:
        value = row.get(key)
        if value is not None:
            return value
    return None
