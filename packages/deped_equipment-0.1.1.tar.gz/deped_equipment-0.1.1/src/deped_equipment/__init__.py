"""Equipment cleaning package."""
