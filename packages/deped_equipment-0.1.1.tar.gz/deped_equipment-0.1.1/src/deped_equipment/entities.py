"""Entity import helpers for equipment builds."""

from __future__ import annotations

import sqlite3
from contextlib import closing
from pathlib import Path
from typing import cast

from deped_hr.entities import import_entities as import_upstream_entities

from .types import EntityIdRow, EntityLookup


def _mark_entities_with_personnel(
    conn: sqlite3.Connection, personnel_db_path: str | Path
) -> None:
    with closing(sqlite3.connect(personnel_db_path)) as personnel_conn:
        entity_ids = cast(
            list[EntityIdRow],
            personnel_conn.execute(
                """--sql
                SELECT DISTINCT entity_id
                FROM personnel
                WHERE entity_id IS NOT NULL;
                """
            ).fetchall(),
        )
    if entity_ids:
        conn.executemany(
            """--sql
            UPDATE entities
            SET has_personnel = 1
            WHERE entity_id = ?;
            """,
            entity_ids,
        )


def load_entities(
    conn: sqlite3.Connection,
    entities_path: str | Path,
    personnel_db_path: str | Path,
) -> EntityLookup:
    """Import upstream entities and mark the subset present in personnel."""
    entity_lookup = import_upstream_entities(conn, entities_path)
    _mark_entities_with_personnel(conn, personnel_db_path)
    conn.commit()
    return entity_lookup
