from deped_dcp_template.cleaners import (
    canonicalize_equipment_dimension,
    classify_equipment_dimension_value,
)

from deped_equipment.dcp.attribution import (
    classify_dcp_attribution_value,
    infer_dcp_attribution_metadata,
    infer_programmatic_dcp_canonical,
    normalize_dcp_attribution_review_key,
)
from deped_equipment.normalization.condition import (
    classify_equipment_condition_value,
    normalize_equipment_condition_review_key,
)
from deped_equipment.normalization.disposition import (
    classify_disposition_value,
    normalize_disposition_review_key,
)
from deped_equipment.normalization.location import (
    classify_equipment_location_value,
    infer_equipment_location_canonical,
    normalize_equipment_location_review_key,
)
from deped_equipment.normalization.source_of_funds import (
    classify_source_of_funds_value,
    normalize_source_of_funds_review_key,
)
from deped_equipment.normalization.supplier import (
    classify_supplier_value,
    normalize_supplier_review_key,
)


def test_equipment_dimension_policies() -> None:
    assert classify_equipment_dimension_value("brand", "Others") == (
        "Others",
        "generic_value",
    )
    assert canonicalize_equipment_dimension("brand", "hewlett packard") == ("HP", None)
    assert canonicalize_equipment_dimension("brand", "Others") == (
        None,
        "generic_value",
    )
    assert canonicalize_equipment_dimension("model", "EliteBook 840 G5") == (
        None,
        "raw_only_value",
    )
    assert canonicalize_equipment_dimension("acquisition_mode", "5") == (
        None,
        "invalid_value",
    )
    assert canonicalize_equipment_dimension("acquisition_source", "PSB") == (
        None,
        "unmapped_value",
    )


def test_dcp_attribution_review_key_and_classification() -> None:
    assert normalize_dcp_attribution_review_key("Batch No. 36") == "dcp batch 36"
    assert normalize_dcp_attribution_review_key("DCP Batch No, 26") == "dcp batch 26"
    assert normalize_dcp_attribution_review_key("DCP BATCH (26)") == "dcp batch 26"
    assert (
        normalize_dcp_attribution_review_key(
            "DCP 2022 - Package 1: e-Learning Cart (eLC)"
        )
        == "dcp 2022 package 1 elearning cart elc"
    )
    assert classify_dcp_attribution_value("✓", is_non_dcp=False) == (
        "invalid_placeholder",
        "invalid_placeholder",
    )
    assert classify_dcp_attribution_value("NON-DCP for learners", is_non_dcp=False) == (
        "non_dcp",
        None,
    )
    assert classify_dcp_attribution_value("DCP Batch 36", is_non_dcp=False) == (
        "unclassified",
        "unclassified",
    )
    assert classify_dcp_attribution_value("MOOE", is_non_dcp=False) == (
        "invalid_non_package_value",
        "invalid_non_package_value",
    )
    assert infer_dcp_attribution_metadata("DCP Batch 36") == (
        "batch_label",
        None,
        36,
        None,
    )
    assert infer_dcp_attribution_metadata("DCP 2022 Package 1 eLearning Cart") == (
        "hybrid_label",
        2022,
        None,
        1,
    )
    assert infer_programmatic_dcp_canonical("dcp package batch 36") == "DCP Batch 36"
    assert (
        infer_programmatic_dcp_canonical("batch 2024 01 elearning cart package")
        == "eLearning Cart Package"
    )
    assert infer_programmatic_dcp_canonical("dcp eclassroom") == "eClassroom Package"


def test_equipment_location_review_key_and_classification() -> None:
    assert normalize_equipment_location_review_key("Principal's Office") == (
        "principal office"
    )
    assert normalize_equipment_location_review_key("E-Classroom") == "eclassroom"
    assert infer_equipment_location_canonical("grade 6 classroom") == "classroom"
    assert infer_equipment_location_canonical("school ict room") == "ict/lab"
    assert infer_equipment_location_canonical("faculty office") == "faculty"
    assert infer_equipment_location_canonical("als room") == "als"
    assert classify_equipment_location_value("School") == (
        "invalid_generic_location",
        "invalid_generic_location",
    )
    assert classify_equipment_location_value("SECURITY BANK BUILDING") == (
        "invalid_generic_location",
        "invalid_generic_location",
    )
    assert classify_equipment_location_value("Unmapped Place") == (
        "unclassified",
        "unclassified",
    )


def test_supplier_review_key_and_classification() -> None:
    assert (
        normalize_supplier_review_key("COLUMBIA TECHNOLOGIES, INC.")
        == "columbia technologies inc"
    )
    assert classify_supplier_value("DepEd Central Office") == (
        "internal_or_non_supplier",
        "internal_or_non_supplier",
    )
    assert classify_supplier_value("Columbia Technologies, Inc.") == (
        "unclassified",
        "unclassified",
    )


def test_disposition_review_key_and_classification() -> None:
    assert normalize_disposition_review_key("FOR  DISPOSAL") == "for disposal"
    assert classify_disposition_value("05/21/2022") == (
        "invalid_disposition_value",
        "invalid_disposition_value",
    )
    assert normalize_disposition_review_key("Lost") == "lost"
    assert normalize_disposition_review_key("2022") is None
    assert classify_disposition_value("✓") == (None, None)
    assert classify_disposition_value("N/A") == (None, None)
    assert classify_disposition_value("For Disposal") == (
        "unclassified",
        "unclassified",
    )


def test_source_of_funds_review_key_and_classification() -> None:
    assert (
        normalize_source_of_funds_review_key(
            "Maintenance and Other Operating Expenses (MOOE)"
        )
        == "maintenance and other operating expenses mooe"
    )
    assert classify_source_of_funds_value("Not Applicable") == (
        "invalid_source_of_funds_value",
        "invalid_source_of_funds_value",
    )
    assert classify_source_of_funds_value("MOOE") == (
        "unclassified",
        "unclassified",
    )


def test_equipment_condition_review_key_and_classification() -> None:
    assert normalize_equipment_condition_review_key("In Good Condition") == (
        "in good condition"
    )
    assert normalize_equipment_condition_review_key("GOOD") == "good"
    assert normalize_equipment_condition_review_key("N/A") is None
    assert classify_equipment_condition_value("12345") == (None, None)
    assert classify_equipment_condition_value("Not Applicable") == (
        "unclassified",
        "unclassified",
    )
    assert classify_equipment_condition_value("Serviceable") == (
        "unclassified",
        "unclassified",
    )
