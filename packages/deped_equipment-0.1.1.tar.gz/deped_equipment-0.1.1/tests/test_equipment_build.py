import csv
import sqlite3
from contextlib import closing
from pathlib import Path

from deped_equipment.cli import build_equipment_db
from deped_equipment.normalization import (
    load_reviewed_disposition_aliases,
    load_reviewed_equipment_condition_aliases,
    load_reviewed_equipment_location_aliases,
    load_reviewed_source_of_funds_aliases,
    load_reviewed_supplier_aliases,
)

EQUIPMENT_HEADERS = [
    "ID",
    "Governance Level",
    "Region",
    "Division",
    "School ID",
    "School Name",
    "Property No. ",
    "Old / Previous Property No. ",
    "Serial Number ",
    "Item",
    "Other Item",
    "Unit of Measure",
    "Brand / Manufacturer",
    "Model ",
    "Specifications",
    "Non-DCP",
    "DCP Package",
    "DCP Year Package ",
    "Category",
    "Classification",
    "GL-SL Code ",
    "UACS",
    "Acquisition Cost",
    "Acquisition / \nReceived Date ",
    "Estimated Useful Life ",
    "Mode of Acquisition",
    "Source of Acquisition",
    "Donor",
    "Source of Funds\n",
    "Allotment Class",
    "Procurement Management Plan",
    "Supporting Documents ",
    "OR / SI / DR / IAR No. ",
    "Transaction Type",
    "Accountable Officer",
    "Date assigned to / received by Accountable Officer",
    "Custodian / End User",
    "Date assigned to / received by Custodian / End User",
    "Received by",
    "Date received by New Accountable Officer / Custodian / End User ",
    "Supporting Documents",
    "PAR / ICS / RRSP / RS / WMR No. ",
    "Supplier / Distributor ",
    "Under Warranty",
    "End of Warranty",
    "Equipment Location",
    "Non-Functional",
    "Equipment Condition",
    "Accountability / Disposition Status ",
    "Remarks ",
]

SNAKE_CASE_EQUIPMENT_HEADERS = [
    "record_id",
    "governance_level",
    "region_name",
    "division_name",
    "school_id",
    "school_name",
    "property_no",
    "old_property_no",
    "serial_number",
    "item",
    "uom",
    "brand_manufacturer",
    "model",
    "specifications",
    "non_dcp",
    "dcp_package",
    "dcp_year",
    "category",
    "classification",
    "gl_sl_code",
    "uacs",
    "acquisition_cost",
    "received_date",
    "estimated_useful_life",
    "mode_acquisition",
    "source_acquisition",
    "donor",
    "source_fund",
    "allotment_class",
    "pm_plan",
    "supporting_documents1",
    "or_si_dr_iar_no",
    "transaction_type",
    "accountable_officer",
    "date_assigned_accountable_officer",
    "end_user",
    "date_assigned_end_user",
    "received_by",
    "date_received_new_accountable",
    "supporting_documents2",
    "par_ics_rrsp_rs_wmr_no",
    "supplier",
    "under_warranty",
    "end_warranty_date",
    "equipment_location",
    "non_functional",
    "erquipment_condition",
    "disposition_status",
    "remarks",
]


def write_csv(path: Path, headers: list[str], rows: list[list[str]]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        writer.writerows(rows)


def row_from_mapping(headers: list[str], values: dict[str, str]) -> list[str]:
    return [values.get(header, "") for header in headers]


def make_lookup_db(path: Path) -> None:
    conn = sqlite3.connect(path)
    try:
        conn.executescript(
            """
            CREATE TABLE equipment_items(id INTEGER PRIMARY KEY, canonical_name TEXT NOT NULL);
            CREATE TABLE equipment_brands(id INTEGER PRIMARY KEY, canonical_name TEXT NOT NULL);
            CREATE TABLE equipment_units(id INTEGER PRIMARY KEY, canonical_name TEXT NOT NULL);
            CREATE TABLE acquisition_modes(id INTEGER PRIMARY KEY, canonical_name TEXT NOT NULL);
            CREATE TABLE acquisition_sources(id INTEGER PRIMARY KEY, canonical_name TEXT NOT NULL);
            CREATE TABLE dcp_packages(
                id INTEGER PRIMARY KEY,
                code TEXT NOT NULL,
                name TEXT,
                description TEXT
            );
            """
        )
        conn.executemany(
            "INSERT INTO equipment_items(canonical_name) VALUES (?)",
            [("Laptop",), ("Printer",), ("Router",), ("Mouse",)],
        )
        conn.executemany(
            "INSERT INTO equipment_brands(canonical_name) VALUES (?)",
            [("HP",), ("Apple",)],
        )
        conn.executemany(
            "INSERT INTO equipment_units(canonical_name) VALUES (?)",
            [("Piece",), ("Unit",), ("Set",)],
        )
        conn.executemany(
            "INSERT INTO acquisition_modes(canonical_name) VALUES (?)",
            [("DepEd Purchase",), ("Donation",)],
        )
        conn.executemany(
            "INSERT INTO acquisition_sources(canonical_name) VALUES (?)",
            [
                ("Private Corporation",),
                ("School Division Office",),
                ("Local Government Unit (LGU)",),
            ],
        )
        conn.executemany(
            "INSERT INTO dcp_packages(code, name, description) VALUES (?, ?, ?)",
            [("Laptop for Teaching", "Laptop for Teaching", "L4T")],
        )
        conn.commit()
    finally:
        conn.close()


def make_personnel_db(path: Path) -> None:
    conn = sqlite3.connect(path)
    try:
        conn.executescript(
            """
            CREATE TABLE entities(
                entity_id INTEGER PRIMARY KEY,
                entity_type TEXT NOT NULL,
                school_id INTEGER,
                region TEXT,
                division TEXT,
                natural_key TEXT NOT NULL
            );
            CREATE TABLE personnel(
                id INTEGER PRIMARY KEY,
                entity_id INTEGER NOT NULL,
                employee_id TEXT,
                full_name TEXT
            );
            """
        )
        conn.executemany(
            """
            INSERT INTO entities(entity_id, entity_type, school_id, region, division, natural_key)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [
                (1, "SCHOOL", 1001, "Region I", "Alpha", "SCHOOL:1001"),
                (
                    2,
                    "DIVISION_OFFICE",
                    None,
                    "Region I",
                    "Alpha",
                    "DIVISION_OFFICE:Region I:Alpha",
                ),
            ],
        )
        conn.executemany(
            """
            INSERT INTO personnel(id, entity_id, employee_id, full_name)
            VALUES (?, ?, ?, ?)
            """,
            [
                (1, 1, "E-001", "Jane Doe"),
                (2, 2, "E-002", "John Smith"),
                (3, 1, "E-003", "Pat Cruz"),
                (4, 1, "E-004", "Pat Cruz"),
            ],
        )
        conn.commit()
    finally:
        conn.close()


def make_entities_db(path: Path) -> None:
    conn = sqlite3.connect(path)
    try:
        conn.executescript(
            """
            CREATE TABLE entities(
                entity_id INTEGER PRIMARY KEY,
                entity_type TEXT NOT NULL,
                school_id INTEGER,
                natural_key TEXT NOT NULL,
                regional_office TEXT,
                school_division_office TEXT,
                school_name TEXT,
                date_time_submitted TEXT
            );
            """
        )
        conn.executemany(
            """
            INSERT INTO entities(
                entity_id, entity_type, school_id, natural_key,
                regional_office, school_division_office, school_name,
                date_time_submitted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    1,
                    "SCHOOL",
                    1001,
                    "SCHOOL:1001",
                    "Region I",
                    "Alpha",
                    "Alpha ES",
                    "2026-04-01 00:00:00",
                ),
                (
                    2,
                    "DIVISION_OFFICE",
                    None,
                    "DIVISION_OFFICE:Region I:Alpha",
                    "Region I",
                    "Alpha",
                    None,
                    "2026-04-01 00:00:00",
                ),
            ],
        )
        conn.commit()
    finally:
        conn.close()


def test_build_equipment_db_resolves_dimensions_and_person_links(
    tmp_path: Path,
) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "10",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-1",
                    "Serial Number ": "SN-1",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Model ": "MacBook Air",
                    "Category": "High-value",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                    "DCP Package": "Laptop for Teaching",
                    "DCP Year Package ": "CY 2024",
                    "Accountable Officer": "Jane Doe",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "11",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-2",
                    "Serial Number ": "SN-2",
                    "Item": "Printer",
                    "Unit of Measure": "pcs",
                    "Brand / Manufacturer": "hewlett packard",
                    "Model ": "Model P",
                    "Category": "Low-value",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "School Division Office",
                    "Accountable Officer": "Officer Unknown (E-002)",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "12",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-3",
                    "Serial Number ": "SN-3",
                    "Item": "Router",
                    "Unit of Measure": "set",
                    "Brand / Manufacturer": "Apple",
                    "Model ": "Model R",
                    "Category": "Low-value",
                    "Mode of Acquisition": "Donation",
                    "Source of Acquisition": "Local Government Unit (LGU)",
                    "Accountable Officer": "Pat Cruz",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "13",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-4",
                    "Serial Number ": "SN-4",
                    "Item": "Mouse",
                    "Unit of Measure": "unit",
                    "Brand / Manufacturer": "Others",
                    "Model ": "0",
                    "Category": "Low-value",
                    "Mode of Acquisition": "5",
                    "Source of Acquisition": "PSB",
                    "Accountable Officer": "Ghost User",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "14",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "9999",
                    "School Name": "Missing ES",
                    "Property No. ": "PN-5",
                    "Serial Number ": "SN-5",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Model ": "Missing Model",
                    "Category": "High-value",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        rows = conn.execute(
            """
            SELECT property_no, accountable_officer_link_status, accountable_personnel_name
            FROM v_equipment_enriched
            ORDER BY property_no
            """
        ).fetchall()
        assert rows == [
            ("PN-1", "matched_by_name", "Jane Doe"),
            ("PN-2", "matched_by_employee_id", "John Smith"),
            ("PN-3", "ambiguous", None),
            ("PN-4", "unmatched", None),
        ]

        canonicalized = conn.execute(
            """
            SELECT raw_present_rows, canonicalized_rows
            FROM v_dimension_canonicalization_coverage
            WHERE dimension_name = 'brand'
            """
        ).fetchone()
        assert canonicalized == (4, 3)
        build_run = conn.execute(
            """
            SELECT build_type, lookups_source_file, entities_source_file,
                   personnel_source_file, equipment_source_file,
                   equipment_source_rows, entity_count,
                   personnel_count, equipment_count, completed_at IS NOT NULL
            FROM build_runs
            """
        ).fetchone()
        assert build_run == (
            "full_rebuild",
            "lookups.db",
            "entities.db",
            "personnel.db",
            "equipment.csv",
            5,
            2,
            4,
            4,
            1,
        )

    audit_path = tmp_path / "equipment_dimension_issues.txt"
    assert audit_path.exists()
    audit_text = audit_path.read_text(encoding="utf-8")
    assert "1\tbrand\tgeneric_value\tOthers" in audit_text
    assert "1\tentity\tmissing_upstream_entity\tSCHOOL:9999" in audit_text
    assert "1\tmodel\tinvalid_value\t0" in audit_text
    assert "1\tmode_of_acquisition\tinvalid_value\t5" in audit_text
    assert "1\tsource_of_acquisition\tunmapped_value\tPSB" in audit_text


def test_build_equipment_db_accepts_snake_case_headers(tmp_path: Path) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_snake.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        SNAKE_CASE_EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                SNAKE_CASE_EQUIPMENT_HEADERS,
                {
                    "record_id": "20",
                    "governance_level": "SCHOOL",
                    "region_name": "Region I",
                    "division_name": "Alpha",
                    "school_id": "1001",
                    "school_name": "Alpha ES",
                    "property_no": "PN-SNAKE",
                    "serial_number": "SN-SNAKE",
                    "item": "Laptop",
                    "uom": "Piece",
                    "brand_manufacturer": "Apple",
                    "model": "MacBook Air",
                    "dcp_package": "Laptop for Teaching",
                    "dcp_year": "CY 2024",
                    "category": "High-value",
                    "mode_acquisition": "DepEd Purchase",
                    "source_acquisition": "Private Corporation",
                    "accountable_officer": "Jane Doe",
                    "received_date": "2024-01-15",
                    "under_warranty": "Yes",
                    "equipment_location": "Library",
                    "non_functional": "No",
                    "erquipment_condition": "Good",
                    "disposition_status": "In use",
                    "remarks": "ok",
                },
            )
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        row = conn.execute(
            """
            SELECT property_no, accountable_officer_link_status, accountable_personnel_name,
                   acquisition_date, equipment_condition, disposition_status
            FROM v_equipment_enriched
            """
        ).fetchone()
        assert row == (
            "PN-SNAKE",
            "matched_by_name",
            "Jane Doe",
            "2024-01-15",
            "Good",
            "In use",
        )


def test_build_equipment_db_rejects_dates_earlier_than_supported_bounds(
    tmp_path: Path,
) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_invalid_acquisition_date.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        SNAKE_CASE_EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                SNAKE_CASE_EQUIPMENT_HEADERS,
                {
                    "record_id": "21",
                    "governance_level": "SCHOOL",
                    "region_name": "Region I",
                    "division_name": "Alpha",
                    "school_id": "1001",
                    "school_name": "Alpha ES",
                    "property_no": "PN-OLD-DATE",
                    "item": "Laptop",
                    "uom": "Piece",
                    "brand_manufacturer": "Apple",
                    "category": "High-value",
                    "mode_acquisition": "DepEd Purchase",
                    "source_acquisition": "Private Corporation",
                    "received_date": "1999-12-31",
                    "date_assigned_end_user": "2009-12-31",
                    "date_received_new_accountable": "2009-12-31",
                },
            )
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        acquisition_date = conn.execute(
            """
            SELECT acquisition_date, date_custodian, date_received_new
            FROM equipment
            WHERE property_no = ?
            """,
            ("PN-OLD-DATE",),
        ).fetchone()
        assert acquisition_date == (None, None, None)

        date_errors = conn.execute(
            """
            SELECT source_table, source_file, source_row_num, source_record_id, column_name, raw_value
            FROM date_parse_errors
            WHERE column_name IN (?, ?, ?)
            ORDER BY column_name
            """,
            ("acquisition_date", "date_custodian", "date_received_new"),
        ).fetchall()
        assert date_errors == [
            (
                "equipment",
                equipment_csv.name,
                2,
                21,
                "acquisition_date",
                "1999-12-31",
            ),
            (
                "equipment",
                equipment_csv.name,
                2,
                21,
                "date_custodian",
                "2009-12-31",
            ),
            (
                "equipment",
                equipment_csv.name,
                2,
                21,
                "date_received_new",
                "2009-12-31",
            ),
        ]


def test_build_equipment_db_creates_custodian_role_confusion_audit_view(
    tmp_path: Path,
) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_custodian_audit.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    rows: list[list[str]] = []
    for record_id in range(30, 36):
        values = {
            "ID": str(record_id),
            "Governance Level": "SCHOOL",
            "Region": "Region I",
            "Division": "Alpha",
            "School ID": "1001",
            "School Name": "Alpha ES",
            "Property No. ": f"PN-{record_id}",
            "Serial Number ": f"SN-{record_id}",
            "Item": "Laptop",
            "Unit of Measure": "Piece",
            "Brand / Manufacturer": "Apple",
            "Model ": f"Model {record_id}",
            "Category": "High-value",
            "Mode of Acquisition": "DepEd Purchase",
            "Source of Acquisition": "Private Corporation",
            "Custodian / End User": "Jane Doe",
        }
        if record_id == 30:
            values["Accountable Officer"] = "Jane Doe"
        else:
            values["Accountable Officer"] = "Officer Unknown (E-002)"
        rows.append(row_from_mapping(EQUIPMENT_HEADERS, values))

    write_csv(equipment_csv, EQUIPMENT_HEADERS, rows)

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        audit_rows = conn.execute(
            """
            SELECT property_no, custodian_name, accountable_name,
                   devices_as_custodian, school_records_as_accountable, flag_type
            FROM v_audit_custodian_role_confusion
            ORDER BY property_no
            """
        ).fetchall()

    assert audit_rows == [
        (
            "PN-30",
            "Jane Doe",
            "Jane Doe",
            6,
            1,
            "custodian_is_accountable_officer",
        ),
        (
            "PN-31",
            "Jane Doe",
            "John Smith",
            6,
            1,
            "high_volume_custodian",
        ),
        (
            "PN-32",
            "Jane Doe",
            "John Smith",
            6,
            1,
            "high_volume_custodian",
        ),
        (
            "PN-33",
            "Jane Doe",
            "John Smith",
            6,
            1,
            "high_volume_custodian",
        ),
        (
            "PN-34",
            "Jane Doe",
            "John Smith",
            6,
            1,
            "high_volume_custodian",
        ),
        (
            "PN-35",
            "Jane Doe",
            "John Smith",
            6,
            1,
            "high_volume_custodian",
        ),
    ]


def test_build_equipment_db_normalizes_reviewed_dcp_attributions(
    tmp_path: Path,
) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_dcp.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "30",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-L4T",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "DCP Package": "Laptop for Teaching",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "31",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-B36",
                    "Item": "Printer",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "HP",
                    "Category": "Low-value",
                    "DCP Package": "Batch 36",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "School Division Office",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "32",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-B7",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "DCP Package": "DCP Batch 7",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "33",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-HYBRID",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "DCP Package": "DCP 2022 - Package 1: e-Learning Cart (eLC)",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "34",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-NON-DCP",
                    "Item": "Router",
                    "Unit of Measure": "Set",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "DCP Package": "NON-DCP for learners",
                    "Mode of Acquisition": "Donation",
                    "Source of Acquisition": "Local Government Unit (LGU)",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "35",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-PLACEHOLDER",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "DCP Package": "✓",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "36",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-UNCLASSIFIED",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "DCP Package": "Tablet",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "37",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-B36-ALT",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "DCP Package": "DCP package Batch 36",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "38",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-ELC-2024",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "DCP Package": "Batch 2024-01:e-Learning Cart Package",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "39",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-ECLASS",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "DCP Package": "DCP E-classroom Package",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "40",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "PN-MOOE",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "DCP Package": "MOOE",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        rows = conn.execute(
            """
            SELECT
                property_no,
                dcp_attribution_type,
                dcp_attribution_name,
                dcp_package_name,
                dcp_program_year,
                dcp_batch_number,
                dcp_package_number
            FROM v_equipment_enriched
            ORDER BY property_no
            """
        ).fetchall()
        assert rows == [
            ("PN-B36", "batch_label", "DCP Batch 36", "DCP Batch 36", None, 36, None),
            (
                "PN-B36-ALT",
                "batch_label",
                "DCP Batch 36",
                "DCP Batch 36",
                None,
                36,
                None,
            ),
            ("PN-B7", "batch_label", "DCP Batch 7", "DCP Batch 7", None, 7, None),
            (
                "PN-ECLASS",
                "named_package",
                "eClassroom Package",
                "eClassroom Package",
                None,
                None,
                None,
            ),
            (
                "PN-ELC-2024",
                "named_package",
                "eLearning Cart Package",
                "eLearning Cart Package",
                None,
                None,
                None,
            ),
            (
                "PN-HYBRID",
                "named_package",
                "eLearning Cart Package",
                "eLearning Cart Package",
                None,
                None,
                None,
            ),
            (
                "PN-L4T",
                "named_package",
                "Laptop for Teaching",
                "Laptop for Teaching",
                None,
                None,
                None,
            ),
            ("PN-MOOE", "invalid_non_package_value", None, None, None, None, None),
            ("PN-NON-DCP", "non_dcp", None, None, None, None, None),
            ("PN-PLACEHOLDER", "invalid_placeholder", None, None, None, None, None),
            ("PN-UNCLASSIFIED", "unclassified", None, None, None, None, None),
        ]

        coverage = conn.execute(
            """
            SELECT raw_present_rows, canonicalized_rows
            FROM v_dimension_canonicalization_coverage
            WHERE dimension_name = 'dcp_attribution'
            """
        ).fetchone()
        assert coverage == (11, 7)

        candidate_rows = conn.execute(
            """
            SELECT dcp_attribution_review_key, row_count, distinct_raw_values, sample_raw_value
            FROM v_dcp_attribution_unclassified
            """
        ).fetchall()
        assert candidate_rows == [("tablet", 1, 1, "Tablet")]

        dcp_issues = conn.execute(
            """
            SELECT issue_type, raw_value
            FROM equipment_dimension_issues
            WHERE dimension_name = 'dcp_attribution'
            ORDER BY raw_value
            """
        ).fetchall()
        assert dcp_issues == [
            ("invalid_non_package_value", "MOOE"),
            ("unclassified", "Tablet"),
            ("invalid_placeholder", "✓"),
        ]


def test_build_equipment_db_normalizes_reviewed_locations(tmp_path: Path) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_locations.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "40",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "LOC-CLASS",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Location": "Grade 6 Classroom",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "41",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "LOC-LAB",
                    "Item": "Printer",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "HP",
                    "Category": "Low-value",
                    "Equipment Location": "School ICT Room",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "School Division Office",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "42",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "LOC-ADMIN",
                    "Item": "Router",
                    "Unit of Measure": "Set",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Equipment Location": "Accounting Office",
                    "Mode of Acquisition": "Donation",
                    "Source of Acquisition": "Local Government Unit (LGU)",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "43",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "LOC-INVALID",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Equipment Location": "SECURITY BANK BUILDING",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "44",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "LOC-UNCLASSIFIED",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Equipment Location": "Covered Court",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        rows = conn.execute(
            """
            SELECT property_no, equipment_location_type, equipment_location_name
            FROM v_equipment_enriched
            ORDER BY property_no
            """
        ).fetchall()
        assert rows == [
            ("LOC-ADMIN", "reviewed_location", "admin/office"),
            ("LOC-CLASS", "reviewed_location", "classroom"),
            ("LOC-INVALID", "invalid_generic_location", None),
            ("LOC-LAB", "reviewed_location", "ict/lab"),
            ("LOC-UNCLASSIFIED", "unclassified", None),
        ]

        coverage = conn.execute(
            """
            SELECT raw_present_rows, canonicalized_rows
            FROM v_dimension_canonicalization_coverage
            WHERE dimension_name = 'equipment_location'
            """
        ).fetchone()
        assert coverage == (5, 3)

        unresolved = conn.execute(
            """
            SELECT equipment_location_review_key, row_count, sample_raw_value
            FROM v_equipment_location_unclassified
            """
        ).fetchall()
        assert unresolved == [("covered court", 1, "Covered Court")]

        location_issues = conn.execute(
            """
            SELECT issue_type, raw_value
            FROM equipment_dimension_issues
            WHERE dimension_name = 'equipment_location'
            ORDER BY raw_value
            """
        ).fetchall()
        assert location_issues == [
            ("unclassified", "Covered Court"),
            ("invalid_generic_location", "SECURITY BANK BUILDING"),
        ]


def test_build_equipment_db_normalizes_supplier_and_disposition(tmp_path: Path) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_supplier_disposition.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "50",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SUP-CANON",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Supplier / Distributor ": "COLUMBIA TECHNOLOGIES, INC.",
                    "Accountability / Disposition Status ": "FOR  DISPOSAL",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "51",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SUP-INTERNAL",
                    "Item": "Printer",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "HP",
                    "Category": "Low-value",
                    "Supplier / Distributor ": "DepEd Central Office",
                    "Accountability / Disposition Status ": "05/21/2022",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "School Division Office",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "52",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SUP-UNCLASS",
                    "Item": "Router",
                    "Unit of Measure": "Set",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Supplier / Distributor ": "Unknown Vendor",
                    "Accountability / Disposition Status ": "Pending inspection",
                    "Mode of Acquisition": "Donation",
                    "Source of Acquisition": "Local Government Unit (LGU)",
                },
            ),
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        rows = conn.execute(
            """
            SELECT property_no, supplier_type, supplier_name,
                   disposition_status_type, disposition_status_name
            FROM v_equipment_enriched
            ORDER BY property_no
            """
        ).fetchall()
        assert rows == [
            (
                "SUP-CANON",
                "reviewed_supplier",
                "Columbia Technologies Inc",
                "reviewed_disposition",
                "For Disposal",
            ),
            (
                "SUP-INTERNAL",
                "internal_or_non_supplier",
                None,
                "invalid_disposition_value",
                None,
            ),
            (
                "SUP-UNCLASS",
                "unclassified",
                None,
                "unclassified",
                None,
            ),
        ]

        supplier_unresolved = conn.execute(
            """
            SELECT supplier_review_key, row_count, sample_raw_value
            FROM v_supplier_unclassified
            """
        ).fetchall()
        assert supplier_unresolved == [("unknown vendor", 1, "Unknown Vendor")]

        disposition_unresolved = conn.execute(
            """
            SELECT disposition_status_review_key, row_count, sample_raw_value
            FROM v_disposition_status_unclassified
            """
        ).fetchall()
        assert disposition_unresolved == [
            ("pending inspection", 1, "Pending inspection")
        ]


def test_build_equipment_db_normalizes_source_of_funds(tmp_path: Path) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_source_of_funds.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "60",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SOF-MOOE",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Source of Funds\n": "Maintenance and Other Operating Expenses (MOOE)",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "61",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SOF-SEF",
                    "Item": "Printer",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "HP",
                    "Category": "Low-value",
                    "Source of Funds\n": "Special Education Fund (SEF)",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "School Division Office",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "62",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SOF-CO",
                    "Item": "Router",
                    "Unit of Measure": "Set",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Source of Funds\n": "DepEd Central Office",
                    "Mode of Acquisition": "Donation",
                    "Source of Acquisition": "Local Government Unit (LGU)",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "63",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SOF-INVALID",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Source of Funds\n": "Delivery Receipt",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "64",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SOF-UNCLASSIFIED",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Source of Funds\n": "Grant",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        rows = conn.execute(
            """
            SELECT property_no, source_of_funds_type, source_of_funds_name
            FROM v_equipment_enriched
            ORDER BY property_no
            """
        ).fetchall()
        assert rows == [
            ("SOF-CO", "reviewed_source_of_funds", "Central Office"),
            ("SOF-INVALID", "invalid_source_of_funds_value", None),
            ("SOF-MOOE", "reviewed_source_of_funds", "MOOE"),
            ("SOF-SEF", "reviewed_source_of_funds", "SEF"),
            ("SOF-UNCLASSIFIED", "unclassified", None),
        ]

        unresolved = conn.execute(
            """
            SELECT source_of_funds_review_key, row_count, sample_raw_value
            FROM v_source_of_funds_unclassified
            """
        ).fetchall()
        assert unresolved == [("grant", 1, "Grant")]


def test_build_equipment_db_normalizes_equipment_condition(tmp_path: Path) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_condition.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "70",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "COND-SVC",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Condition": "In Good Condition",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "71",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "COND-UNSVC",
                    "Item": "Printer",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "HP",
                    "Category": "Low-value",
                    "Equipment Condition": "Obsolete",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "School Division Office",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "72",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "COND-REPAIR",
                    "Item": "Router",
                    "Unit of Measure": "Set",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Equipment Condition": "Needs Repair",
                    "Mode of Acquisition": "Donation",
                    "Source of Acquisition": "Local Government Unit (LGU)",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "73",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "COND-INVALID",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Equipment Condition": "Inventory Custodian Slip (ICS)",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "74",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "COND-UNCLASSIFIED",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Equipment Condition": "For Assessment",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        rows = conn.execute(
            """
            SELECT property_no, equipment_condition_type, equipment_condition_name
            FROM v_equipment_enriched
            ORDER BY property_no
            """
        ).fetchall()
        assert rows == [
            ("COND-INVALID", "invalid_equipment_condition_value", None),
            ("COND-REPAIR", "reviewed_equipment_condition", "For Repair"),
            ("COND-SVC", "reviewed_equipment_condition", "Serviceable"),
            ("COND-UNCLASSIFIED", "unclassified", None),
            ("COND-UNSVC", "reviewed_equipment_condition", "Unserviceable"),
        ]

        unresolved = conn.execute(
            """
            SELECT equipment_condition_review_key, row_count, sample_raw_value
            FROM v_equipment_condition_unclassified
            """
        ).fetchall()
        assert unresolved == [("for assessment", 1, "For Assessment")]


def test_build_equipment_db_auto_reassigns_condition_and_disposition(
    tmp_path: Path,
) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_condition_disposition_swap.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "80",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SWAP-COND",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Equipment Condition": "Returned in Supply Office",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "81",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SWAP-DISP",
                    "Item": "Mouse",
                    "Unit of Measure": "Unit",
                    "Brand / Manufacturer": "Apple",
                    "Category": "Low-value",
                    "Accountability / Disposition Status ": "GOOD",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        rows = conn.execute(
            """
            SELECT property_no, equipment_condition_type, equipment_condition_name,
                   disposition_status_type, disposition_status_name
            FROM v_equipment_enriched
            ORDER BY property_no
            """
        ).fetchall()
        assert rows == [
            (
                "SWAP-COND",
                None,
                None,
                "reviewed_disposition",
                "Transferred",
            ),
            (
                "SWAP-DISP",
                "reviewed_equipment_condition",
                "Serviceable",
                None,
                None,
            ),
        ]

        issues = conn.execute(
            """
            SELECT dimension_name, issue_type, raw_value
            FROM equipment_dimension_issues
            WHERE issue_type LIKE 'auto_reassigned_%'
            ORDER BY raw_value
            """
        ).fetchall()
        assert issues == [
            (
                "disposition_status",
                "auto_reassigned_to_equipment_condition",
                "GOOD",
            ),
            (
                "equipment_condition",
                "auto_reassigned_to_disposition_status",
                "Returned in Supply Office",
            ),
        ]


def test_build_equipment_db_exposes_equipment_semantics(tmp_path: Path) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    personnel_db = tmp_path / "personnel.db"
    equipment_csv = tmp_path / "equipment_semantics.csv"
    equipment_db = tmp_path / "equipment.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)
    make_personnel_db(personnel_db)

    write_csv(
        equipment_csv,
        EQUIPMENT_HEADERS,
        [
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "90",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SEM-ACTIVE",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Location": "Grade 5 Classroom",
                    "Equipment Condition": "In Good Condition",
                    "Acquisition / \nReceived Date ": "2024-01-15",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "91",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SEM-REPAIR",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Location": "School ICT Room",
                    "Equipment Condition": "Needs Repair",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "92",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SEM-CONTRADICT",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Location": "Grade 6 Classroom",
                    "Equipment Condition": "In Good Condition",
                    "Non-Functional": "Yes",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "93",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SEM-DCP-AGE",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Location": "Grade 4 Classroom",
                    "Equipment Condition": "In Good Condition",
                    "DCP Package": "DCP 2022 - Package 1: e-Learning Cart (eLC)",
                    "DCP Year Package ": "CY 2022",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "94",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SEM-NONCOMP",
                    "Item": "Printer",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "HP",
                    "Category": "Low-value",
                    "Equipment Location": "Grade 3 Classroom",
                    "Equipment Condition": "In Good Condition",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "School Division Office",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "95",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SEM-NO-AGE",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Location": "Grade 2 Classroom",
                    "Equipment Condition": "In Good Condition",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "96",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SEM-OFFICE",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Location": "Office of the Principal",
                    "Equipment Condition": "In Good Condition",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
            row_from_mapping(
                EQUIPMENT_HEADERS,
                {
                    "ID": "97",
                    "Governance Level": "SCHOOL",
                    "Region": "Region I",
                    "Division": "Alpha",
                    "School ID": "1001",
                    "School Name": "Alpha ES",
                    "Property No. ": "SEM-TRANSFER",
                    "Item": "Laptop",
                    "Unit of Measure": "Piece",
                    "Brand / Manufacturer": "Apple",
                    "Category": "High-value",
                    "Equipment Location": "Grade 1 Classroom",
                    "Accountability / Disposition Status ": "Returned in Supply Office",
                    "Mode of Acquisition": "DepEd Purchase",
                    "Source of Acquisition": "Private Corporation",
                },
            ),
        ],
    )

    build_equipment_db(
        equipment_csv,
        lookups_db,
        entities_db,
        personnel_db,
        equipment_db,
    )

    with closing(sqlite3.connect(equipment_db)) as conn:
        current_year = conn.execute(
            "SELECT CAST(strftime('%Y', 'now') AS INTEGER)"
        ).fetchone()[0]
        rows = conn.execute(
            """
            SELECT
                property_no,
                is_computing_device,
                is_learning_space_location,
                is_classroom_location,
                is_ict_lab_location,
                is_functional,
                is_non_functional_effective,
                is_repairable,
                is_disposed_or_inactive,
                is_learner_device,
                is_active_learner_device,
                age_reference_date,
                age_reference_year,
                semantics_exclusion_reason
            FROM v_equipment_semantics
            ORDER BY property_no
            """
        ).fetchall()
        assert rows == [
            ("SEM-ACTIVE", 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, "2024-01-15", 2024, None),
            ("SEM-CONTRADICT", 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, None, None, None),
            ("SEM-DCP-AGE", 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, None, 2022, None),
            ("SEM-NO-AGE", 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, None, None, None),
            (
                "SEM-NONCOMP",
                0,
                1,
                1,
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                None,
                None,
                "not_computing_device",
            ),
            (
                "SEM-OFFICE",
                1,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                None,
                None,
                "not_learning_space",
            ),
            ("SEM-REPAIR", 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, None, None, "for_repair"),
            (
                "SEM-TRANSFER",
                1,
                1,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                None,
                None,
                "disposed_or_inactive",
            ),
        ]

        age_rows = conn.execute(
            """
            SELECT property_no, device_age_years
            FROM v_equipment_semantics
            WHERE property_no IN ('SEM-ACTIVE', 'SEM-DCP-AGE', 'SEM-NO-AGE')
            ORDER BY property_no
            """
        ).fetchall()
        assert age_rows[0][0] == "SEM-ACTIVE"
        assert age_rows[0][1] is not None and age_rows[0][1] > 0
        assert age_rows[1] == ("SEM-DCP-AGE", float(current_year - 2022))
        assert age_rows[2] == ("SEM-NO-AGE", None)

        aggregate = conn.execute(
            """
            SELECT
                entity_name,
                SUM(CASE WHEN is_computing_device = 1 THEN 1 ELSE 0 END) AS computing_device_count,
                SUM(CASE WHEN is_computing_device = 1 AND is_functional = 1 THEN 1 ELSE 0 END) AS functional_count,
                SUM(CASE WHEN is_computing_device = 1 AND is_non_functional_effective = 1 THEN 1 ELSE 0 END) AS non_functional_count,
                SUM(CASE WHEN is_computing_device = 1 AND is_repairable = 1 THEN 1 ELSE 0 END) AS repairable_count,
                SUM(CASE WHEN is_active_learner_device = 1 THEN 1 ELSE 0 END) AS active_learner_device_count,
                ROUND(
                    1.0 * SUM(CASE WHEN is_computing_device = 1 AND is_functional = 1 THEN 1 ELSE 0 END)
                    / NULLIF(SUM(CASE WHEN is_computing_device = 1 THEN 1 ELSE 0 END), 0),
                    4
                ) AS functional_share
            FROM v_equipment_semantics
            GROUP BY entity_name
            """
        ).fetchone()
        assert aggregate[:6] == ("Alpha ES", 7, 5, 0, 1, 4)
        assert abs(aggregate[6] - 0.7143) < 1e-9


def test_reviewed_aliases_are_deduped_by_normalized_key() -> None:
    alias_sets = [
        load_reviewed_disposition_aliases(),
        load_reviewed_equipment_condition_aliases(),
        load_reviewed_equipment_location_aliases(),
        load_reviewed_source_of_funds_aliases(),
        load_reviewed_supplier_aliases(),
    ]

    for aliases in alias_sets:
        normalized_alias_values = [alias.normalized_alias_value for alias in aliases]
        assert len(normalized_alias_values) == len(set(normalized_alias_values))


def test_reviewed_dcp_canonicals_seed_their_own_aliases() -> None:
    from deped_equipment.dcp.attribution import load_reviewed_dcp_attribution_dictionary

    _, aliases = load_reviewed_dcp_attribution_dictionary()
    by_key = {alias.normalized_alias_value: alias.canonical_name for alias in aliases}

    assert by_key["elearning cart package"] == "eLearning Cart Package"
    assert by_key["dcp 2022 package 1 elearning cart elc"] == "eLearning Cart Package"
