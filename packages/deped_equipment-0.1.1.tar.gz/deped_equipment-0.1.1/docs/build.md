# Build Guide

This page covers the expected workflow for producing the equipment artifact.

## Prerequisites

- Python 3.14+
- `uv`
- A valid equipment CSV export
- A lookup database produced by `deped-dcp-template`
- An entity database produced by `deped-entity`
- A personnel database produced by `deped-hr`
- *(Optional)* The DCP procurement dataset (`deped-dataset/db.sqlite3`) for cross-validation

## 1. Build The Lookup Database

The equipment package expects a lookup database with canonical referential values.

```sh
uv run deped-dcp-template extract \
--templates-dir templates \
--output artifacts/lookups.db
```

## 2. Ensure The Personnel Database Exists

The equipment build resolves accountable people from the personnel artifact.

## 3. Ensure The Entity Database Exists

The equipment build imports entities from the upstream entity artifact.

## 4. Build The Equipment Database

Run the equipment build from the repository root:

```sh
uv run equipment build \
--equipment data/2026-04-02-equipment.csv \
--lookups artifacts/lookups.db \
--entities-db ../deped-entity/artifacts/entities.db \
--personnel-db ../deped-hr/artifacts/personnel.db \
--dcp-dataset-db ../deped-dataset/db.sqlite3 \
--db artifacts/equipment.db
```

Arguments:

- `--equipment`: source CSV file
- `--lookups`: lookup SQLite database
- `--entities-db`: upstream entity SQLite database
- `--personnel-db`: personnel SQLite database
- `--dcp-dataset-db`: *(optional)* DCP procurement dataset for cross-validation.
  When omitted, all `dcp_*` columns on `equipment` remain `NULL` and the three
  `v_audit_dcp_*` views return no rows. Existing builds without this flag are
  unaffected.
- `--db`: destination SQLite database

The command prints the output database path on success.

## 5. Audit The Result

Run the lightweight audit command after a build:

```sh
uv run equipment audit \
--db artifacts/equipment.db
```

Current audit output includes:

- `equipment_rows`
- `dimension_issue_rows`

## Generated Files

The build produces:

- `artifacts/equipment.db`
- `artifacts/equipment_dimension_issues.txt`

The text audit file lists raw dimension values that did not map cleanly to the canonical lookup tables, plus equipment rows whose entity natural key was missing from the upstream entity artifact.

## DCP Cross-Validation (when `--dcp-dataset-db` is supplied)

The build populates five columns on `equipment` (`dcp_cost`, `dcp_year`,
`dcp_component`, `dcp_match_type`, `dcp_supplier`) and seeds the
`dcp_delivery_summary` table. Three audit views then expose:

```sql
-- Cost reporting accuracy (overstated / understated / not_declared)
SELECT item_name, flag_type, COUNT(*) AS flagged
FROM v_audit_dcp_reported_cost
GROUP BY item_name, flag_type ORDER BY flagged DESC;

-- Unit gaps (focus on none_declared and underdeclared)
SELECT dcp_year, dcp_component, coverage_flag, COUNT(*) AS schools
FROM v_audit_dcp_unit_coverage
WHERE coverage_flag IN ('none_declared', 'underdeclared')
GROUP BY dcp_year, dcp_component, coverage_flag
ORDER BY dcp_year, dcp_component, schools DESC;

-- Non-functional DCP-matched equipment
SELECT dcp_year, dcp_component, COUNT(*) AS non_functional
FROM v_audit_dcp_condition
WHERE flag_type = 'non_functional'
GROUP BY dcp_year, dcp_component ORDER BY non_functional DESC;
```

See `docs/dcp-cross-validation.md` for the full matching logic and match type reference.

## DCP Attribution Review Workflow

DCP attribution normalization is review-driven. The build preserves raw source text in `equipment.dcp_package_raw`, then resolves reviewed values through the checked-in dictionary at `src/deped_equipment/dictionaries/dcp_attribution_dictionary.csv`.

Use the built artifact to inspect unresolved DCP labels:

```sql
SELECT *
FROM v_dcp_attribution_unclassified;
```

Recommended review loop:

1. Build `artifacts/equipment.db`.
2. Inspect `v_dcp_attribution_unclassified` and `equipment_dimension_issues` for high-frequency DCP labels.
3. Update the reviewed dictionary with approved canonical names and aliases.
4. Rebuild `artifacts/equipment.db`.
5. Recheck `v_dimension_canonicalization_coverage` for `dcp_attribution` and confirm unresolved values dropped as expected.

## Equipment Location Review Workflow

Equipment location normalization is also review-driven. The build preserves raw source text in `equipment.equipment_location`, then resolves reviewed values through the checked-in dictionary at `src/deped_equipment/dictionaries/equipment_location_dictionary.csv`.

Use the built artifact to inspect unresolved equipment locations:

```sql
SELECT *
FROM v_equipment_location_unclassified;
```

Recommended review loop:

1. Build `artifacts/equipment.db`.
2. Inspect `v_equipment_location_unclassified` and `equipment_dimension_issues` for high-frequency raw locations.
3. Update the reviewed dictionary with approved canonical names and aliases.
4. Rebuild `artifacts/equipment.db`.
5. Recheck `v_dimension_canonicalization_coverage` for `equipment_location`.

## Supplier And Disposition Review Workflow

Supplier and disposition normalization are also review-driven, with dictionaries at:

- `src/deped_equipment/dictionaries/supplier_dictionary.csv`
- `src/deped_equipment/dictionaries/disposition_status_dictionary.csv`
- `src/deped_equipment/dictionaries/source_of_funds_dictionary.csv`
- `src/deped_equipment/dictionaries/equipment_condition_dictionary.csv`

Use the built artifact to inspect unresolved candidates:

```sql
SELECT * FROM v_supplier_unclassified;
SELECT * FROM v_disposition_status_unclassified;
SELECT * FROM v_source_of_funds_unclassified;
SELECT * FROM v_equipment_condition_unclassified;
```

When extending normalization beyond the current dictionaries, follow the extension rules documented in `docs/dcp-attribution-curation.md`: preserve the raw value, add a reviewed dictionary, add canonical and alias tables, add `*_id` / `*_type` / `*_review_key` columns, and expose unresolved candidates through a dedicated review view.
