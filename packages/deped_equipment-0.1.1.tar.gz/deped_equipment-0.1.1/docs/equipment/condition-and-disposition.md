# Condition And Disposition

This concern covers serviceability, lifecycle state, and whether the row is marked non-functional.

## Source Columns

- `equipment_condition`
- `equipment_condition_id`
- `equipment_condition_type`
- `equipment_condition_review_key`
- `disposition_status`
- `disposition_status_id`
- `disposition_status_type`
- `disposition_status_review_key`
- `is_non_functional`
- `remarks`

## Normalization Rules

- Condition and disposition are normalized independently through reviewed dictionaries.
- Misplaced values can be reassigned across the two fields when the source row clearly put the value in the wrong column.
- Cross-field defaults can infer a missing condition or disposition from the other field.
- `is_non_functional` is reconciled against resolved condition and disposition values before inference finalizes.

Detailed cross-field rules and consistency expectations are maintained in `docs/normalization-customization.md`.

## Canonical Values And Related Tables

- `equipment_conditions`
- `equipment_disposition_statuses`
- `v_equipment_condition_summary`
- `v_equipment_condition_unclassified`
- `v_disposition_status_unclassified`
- `v_audit_dcp_condition`

## Known Issues

- Source users often mix condition and disposition in the wrong columns.
- The non-functional checkbox can contradict the typed condition.
- Disposal-related states may be missing even when the item is clearly unserviceable.

## Query Guidance

Define serviceable equipment explicitly in analysis. A practical starting point is rows with `is_non_functional = 0` and no disposal status, but the exact definition should be documented per report.
