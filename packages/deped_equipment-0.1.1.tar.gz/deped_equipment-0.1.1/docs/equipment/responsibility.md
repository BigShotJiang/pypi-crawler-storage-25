# Responsibility

This concern covers the people attached to an equipment row:

- receiver: who received the item into record
- accountable officer: who is formally responsible for it, often the supply officer
- custodian or end user: who physically holds or uses it

## Source Columns

- `received_by`, `received_by_normalized_name`, `received_by_employee_id`, `received_by_personnel_id`, `received_by_link_status`, `date_received_new`
- `accountable_officer`, `accountable_officer_normalized_name`, `accountable_officer_employee_id`, `accountable_personnel_id`, `accountable_officer_link_status`, `date_accountable_officer`
- `custodian_end_user`, `custodian_end_user_normalized_name`, `custodian_end_user_employee_id`, `custodian_personnel_id`, `custodian_end_user_link_status`, `date_custodian`

## Normalization Rules

- Person names are cleaned before matching.
- Employee IDs are used when present and usable.
- Name-based matching is attempted only after stronger identifiers are considered.
- Ambiguous matches remain ambiguous instead of being guessed.
- Unresolved people remain visible in the row through raw and normalized columns.

## Canonical Values And Related Tables

- `personnel`
- `v_link_resolution_coverage`
- `v_audit_custodian_role_confusion`

## Known Issues

- The same real person may appear under spelling variants across rows.
- Receivers, accountable officers, and custodians can be confused in source submissions.
- A school may record the supply officer as both accountable officer and custodian.

## Query Guidance

Use the `*_personnel_id` columns when counting linked people. Use the raw and normalized text fields when auditing gaps in personnel matching.
