# Equipment Data Model

The `equipment` table is the central fact table in `equipment.db`. Each row represents one declared equipment record from a source inventory submission, enriched through normalization, personnel linking, and DCP cross-validation.

Use this section for focused discussion of each concern carried by an equipment row:

- [Overview](./overview.md)
- [Responsibility](./responsibility.md)
- [Acquisition](./acquisition.md)
- [Accounting](./accounting.md)
- [Item Classification](./item-classification.md)
- [Location](./location.md)
- [Condition And Disposition](./condition-and-disposition.md)
- [Identification And Specs](./identification-and-specs.md)
- [Semantic Reporting](./semantic-reporting.md)

View contracts for reporting-oriented equipment views live under `docs/views/`:

- [v_equipment_enriched](../views/v_equipment_enriched.md)
- [v_equipment_semantics](../views/v_equipment_semantics.md)
- [v_equipment_condition_summary](../views/v_equipment_condition_summary.md)
- [v_audit_condition_disposition_inconsistency](../views/v_audit_condition_disposition_inconsistency.md)

Keep field-level contract details in `docs/data-contract.md`. Keep cross-cutting dictionary and alias maintenance guidance in `docs/normalization-customization.md`.
