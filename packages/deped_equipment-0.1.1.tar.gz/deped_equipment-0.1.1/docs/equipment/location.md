# Location

This concern covers where the equipment is recorded as being located within the school or office.

## Source Columns

- `equipment_location`
- `equipment_location_id`
- `equipment_location_type`
- `equipment_location_review_key`

## Normalization Rules

- Raw location text is preserved in `equipment_location`.
- Reviewed and inferred canonical locations are stored through `equipment_location_id`.
- `equipment_location_type` distinguishes reviewed, inferred, invalid, and unresolved outcomes.
- Location normalization uses a combination of programmatic inference and reviewed aliases.

Detailed location rules, inference priorities, and invalid-pattern handling are maintained in `docs/normalization-customization.md`.

## Canonical Values And Related Tables

- `equipment_locations`
- `equipment_location_aliases`
- `v_equipment_location_unclassified`

## Known Issues

- School names are often entered where room or custody location should be recorded.
- Generic values like `school` or numeric identifiers can appear in the location field.
- Mixed strings can mention both a school name and a usable room label.

## Query Guidance

Use canonical location names for grouping. Use `equipment_location_type` and the unclassified view when monitoring review backlog or data-entry problems.
