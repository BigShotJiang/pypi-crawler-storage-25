# Semantic Reporting

This page defines the reusable reporting layer that sits above canonical enrichment. Use it when the question is not just what the source row says, but how downstream analysis should interpret the row consistently.

## Design Rule

- Canonical dimensions and `v_equipment_enriched` answer what the row says after normalization.
- `v_equipment_semantics` answers how reporting should interpret those normalized values for reusable device metrics.
- Audit views remain remediation surfaces. Do not use them as reporting denominators.

## Preferred Upstream View

Use `v_equipment_semantics` for:

- computing-device counts
- learner-device counts
- active learner-device counts
- functional versus non-functional splits
- repairable-device counts
- device-age reporting

Use `v_equipment_enriched` when you need raw-enriched facts or canonical labels without the reporting semantics.

## Metric Guidance

- Publish numerator and denominator together for proportions.
- Distinguish all computing devices from learner devices and active learner devices.
- Average age only over rows where `device_age_years IS NOT NULL`.
- Group by `entity_id`, `entity_name`, `division`, and `region` for upstream entity rollups.

## Recipes

### Active learner devices by entity

```sql
SELECT
    entity_id,
    entity_name,
    division,
    region,
    COUNT(*) AS active_learner_device_count
FROM v_equipment_semantics
WHERE is_active_learner_device = 1
GROUP BY entity_id, entity_name, division, region
ORDER BY active_learner_device_count DESC, entity_name;
```

### Average age of collected computing devices

```sql
SELECT
    entity_id,
    entity_name,
    AVG(device_age_years) AS avg_device_age_years,
    COUNT(*) AS dated_device_count
FROM v_equipment_semantics
WHERE is_computing_device = 1
  AND device_age_years IS NOT NULL
GROUP BY entity_id, entity_name
ORDER BY avg_device_age_years DESC, entity_name;
```

### Functional versus non-functional computing devices

```sql
SELECT
    entity_id,
    entity_name,
    SUM(CASE WHEN is_computing_device = 1 THEN 1 ELSE 0 END) AS computing_device_count,
    SUM(CASE WHEN is_computing_device = 1 AND is_functional = 1 THEN 1 ELSE 0 END) AS functional_count,
    SUM(CASE WHEN is_computing_device = 1 AND is_non_functional_effective = 1 THEN 1 ELSE 0 END) AS non_functional_count,
    ROUND(
        1.0 * SUM(CASE WHEN is_computing_device = 1 AND is_functional = 1 THEN 1 ELSE 0 END)
        / NULLIF(SUM(CASE WHEN is_computing_device = 1 THEN 1 ELSE 0 END), 0),
        4
    ) AS functional_share
FROM v_equipment_semantics
GROUP BY entity_id, entity_name
ORDER BY entity_name;
```

### Repairable computing devices

```sql
SELECT
    entity_id,
    entity_name,
    COUNT(*) AS repairable_computing_device_count
FROM v_equipment_semantics
WHERE is_computing_device = 1
  AND is_repairable = 1
GROUP BY entity_id, entity_name
ORDER BY repairable_computing_device_count DESC, entity_name;
```

### Classroom versus ICT/lab learner-space counts

```sql
SELECT
    entity_id,
    entity_name,
    SUM(CASE WHEN is_computing_device = 1 AND is_classroom_location = 1 THEN 1 ELSE 0 END) AS classroom_computing_devices,
    SUM(CASE WHEN is_computing_device = 1 AND is_ict_lab_location = 1 THEN 1 ELSE 0 END) AS ict_lab_computing_devices
FROM v_equipment_semantics
GROUP BY entity_id, entity_name
ORDER BY entity_name;
```

### Excluded-device breakdown

```sql
SELECT
    semantics_exclusion_reason,
    COUNT(*) AS row_count
FROM v_equipment_semantics
WHERE semantics_exclusion_reason IS NOT NULL
GROUP BY semantics_exclusion_reason
ORDER BY row_count DESC, semantics_exclusion_reason;
```
