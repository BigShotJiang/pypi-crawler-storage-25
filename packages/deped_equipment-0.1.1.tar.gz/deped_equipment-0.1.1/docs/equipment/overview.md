# Equipment Overview

The `equipment` table combines several distinct concerns in one row:

- responsibility and personnel linkage
- acquisition provenance, including DCP attribution
- accounting classification
- semantic item classification
- physical location
- condition, disposition, and functionality
- identifying and descriptive attributes

This is best understood as one fact table with several attached dimensions rather than as a flat list of unrelated columns.

## Column Groups

- Responsibility: `received_by_*`, `accountable_*`, `custodian_*`
- Acquisition: `mode_of_acquisition_*`, `source_of_acquisition_*`, `dcp_*`, `supplier_*`, `source_of_funds_*`
- Accounting: `category_*`, `classification`, `gl_sl_code`, `uacs`, `acquisition_cost`
- Item classification: `item_id`, `item_raw`, `other_item`
- Location: `equipment_location*`
- Condition and disposition: `equipment_condition*`, `disposition_status*`, `is_non_functional`
- Identification and specs: `property_no`, `old_property_no`, `serial_number`, `brand_*`, `model_*`, `unit_of_measure_*`, `specifications`

## Normalization Rules

Normalization rules are documented in the concern page they belong to. That keeps the business meaning, lookup tables, and data quality behavior in the same place.

Use `docs/normalization-customization.md` for:

- where reviewed dictionaries live
- how aliases are added
- how invalid-pattern checks work
- shared normalization behavior across dimensions

## Query Guidance

For analysis, start from `v_equipment_enriched` when you want canonical labels. Join directly to dimension tables only when you need raw storage details or specialized filters.
