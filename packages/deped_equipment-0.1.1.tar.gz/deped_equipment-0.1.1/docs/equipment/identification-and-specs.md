# Identification And Specs

This concern covers the identifiers and descriptive attributes attached to the equipment item.

## Source Columns

- `property_no`
- `old_property_no`
- `serial_number`
- `brand_id`, `brand_raw`
- `model_id`, `model_raw`
- `unit_of_measure_id`, `unit_of_measure_raw`
- `specifications`

## Normalization Rules

- Brand, model, and unit-of-measure values are normalized into their lookup tables.
- Raw values remain available for audit and review.
- Property and serial numbers are preserved as record identifiers rather than aggressively canonicalized.
- Specifications remain free text.

## Canonical Values And Related Tables

- `equipment_brands`
- `equipment_models`
- `equipment_units`
- `v_dimension_canonicalization_coverage`
- `v_unresolved_dimension_values`

## Known Issues

- Property numbers and serial numbers can be absent or inconsistent.
- Model and brand may be swapped in source submissions.
- Unit of measure can be noisy even when the item itself is canonicalized correctly.

## Query Guidance

Use canonical brand, model, and unit fields for grouped analysis. Use property number and serial number carefully because they are useful identifiers but not guaranteed to be globally unique or clean.
