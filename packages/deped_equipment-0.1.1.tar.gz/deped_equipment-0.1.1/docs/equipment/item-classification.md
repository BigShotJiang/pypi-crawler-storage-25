# Item Classification

This concern covers what the item is, both as a canonical equipment item and through lightweight semantic flags used for reporting.

## Source Columns

- `item_id`
- `item_raw`
- `other_item`

## Normalization Rules

- Raw item labels are normalized into canonical `equipment_items` rows.
- The canonical item table is the stable place for semantic item metadata.
- Current semantic flags are stored on `equipment_items`:
  - `is_computer`
  - `is_tv`
  - `is_accessory`
- `CPU` is intentionally excluded from `is_computer`.
- Semantic flags are separate from accounting classification and from DCP attribution.

## Canonical Values And Related Tables

- `equipment_items`
- `v_equipment_enriched.item_name`
- `v_equipment_enriched.item_is_computer`
- `v_equipment_enriched.item_is_tv`
- `v_equipment_enriched.item_is_accessory`

## Known Issues

- `Others` remains a catch-all and should not be overinterpreted.
- Semantic flags are intentionally simple and will not cover every analytical use case.
- Some item names represent bundles or packages rather than a single physical component.

## Query Guidance

Use `item_id` or `item_name` when the exact canonical item matters. Use `item_is_computer`, `item_is_tv`, and `item_is_accessory` when you want reusable reporting groups without rewriting item lists in every query.
