# Acquisition

This concern explains how an equipment row entered the inventory and whether it can be tied to a DCP delivery.

## Source Columns

- `mode_of_acquisition_*`
- `source_of_acquisition_*`
- `donor`
- `supplier*`
- `source_of_funds*`
- `acquisition_date`, `acquisition_cost`
- `dcp_attribution_id`, `dcp_attribution_type`, `dcp_attribution_review_key`
- `dcp_package_id`, `dcp_package_raw`
- `dcp_year_package_id`, `dcp_year_package_raw`
- `dcp_year`, `dcp_component`, `dcp_match_type`, `dcp_cost`, `dcp_supplier`

## Normalization Rules

- Acquisition mode and source are canonicalized into lookup tables.
- DCP package text from the source is preserved separately from the reviewed attribution mapping.
- Reviewed DCP attribution dictionaries are applied after lookup seeding.
- DCP-specific derived fields such as `dcp_year`, `dcp_component`, and `dcp_cost` are populated only when the row can be matched against the DCP dataset.
- Supplier and source-of-funds values go through their own reviewed normalization pipelines.

## Canonical Values And Related Tables

- `equipment_acquisition_modes`
- `equipment_acquisition_sources`
- `equipment_dcp_attributions`
- `equipment_dcp_packages`
- `equipment_dcp_years`
- `equipment_suppliers`
- `equipment_source_of_funds`

## Known Issues

- Source rows may contain DCP labels in inconsistent formats.
- Declared acquisition cost can disagree with DCP-authoritative cost.
- Non-DCP rows may still contain package-like text that needs review.

## Query Guidance

Use `dcp_match_type in ('exact', 'inferred')` when you want DCP-backed analytics. Use `v_equipment_enriched` when you need canonical attribution names alongside raw package text.
