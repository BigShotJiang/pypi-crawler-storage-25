# Accounting

This concern covers how the item is classified for accounting and inventory control, not what the item is semantically.

## Source Columns

- `category_id`, `category_raw`
- `classification`
- `gl_sl_code`
- `uacs`
- `acquisition_cost`
- `estimated_useful_life`

## Normalization Rules

- `category_id` is the normalized accounting bucket, currently `High-value`, `Low-value`, or `Unknown`.
- `category_raw` preserves the source wording, including noisy or expanded variants.
- Accounting classification is kept separate from semantic item typing such as computer, TV, or accessory.
- Cost values are parsed numerically when possible and left nullable when unusable.

## Canonical Values And Related Tables

- `equipment_categories`
- `v_equipment_value_per_school`

## Known Issues

- Raw category labels vary widely in capitalization and phrasing.
- UACS and GL/SL codes may be missing, misplaced, or encoded as free text.
- Declared costs may not align with DCP-backed costs on matched rows.

## Query Guidance

Use `category_id` or `category_name` for accounting analysis. Do not use accounting columns as a substitute for device-type analysis.
