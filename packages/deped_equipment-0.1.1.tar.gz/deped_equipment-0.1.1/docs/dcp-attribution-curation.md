# DCP Attribution Curation

DCP attribution normalization is review-driven. Raw source values stay on `equipment.dcp_package_raw`, while reviewed canonical values resolve into `equipment_dcp_attributions`.

## Normalization Extension Rules

Use these rules whenever extending normalization to a new field or updating an existing reviewed dictionary.

### 1. Preserve Raw Source Data

- Keep the original CSV value on the `equipment` row unchanged.
- Add reviewed canonical IDs and review keys beside the raw field instead of replacing it.
- Treat the raw field as provenance and the canonical field as interpretation.

### 2. Prefer Aliases Over New Canonicals

- Add a new canonical value only when the raw values refer to a genuinely distinct business concept.
- Add an alias when the difference is only case, punctuation, spacing, abbreviations, spelling mistakes, or harmless wording changes.
- Collapse variants such as casing, punctuation, and numbering noise before deciding a new canonical is needed.

### 3. Do Not Canonicalize Noise

- Do not promote placeholders, comments, document references, school names, people names, dates, room descriptions, or audit notes into canonical dimensions.
- Classify those as invalid or unresolved through `equipment_dimension_issues` and the corresponding `*_unclassified` views.
- Use reviewed dictionaries only for values that represent stable analysis dimensions.

### 4. Add A Dictionary Before Adding A Rule

- Every reviewed normalization must have a checked-in dictionary under `src/deped_equipment/dictionaries/`.
- The dictionary should contain canonicals plus approved aliases.
- Loader code should resolve through the dictionary first; heuristic keyword logic may help classify invalid or unresolved values, but it should not silently invent canonicals.

### 5. Extend Schema Consistently

When adding normalization for a new field, follow the same artifact pattern:

- raw source column remains unchanged
- canonical dimension table
- alias table
- `*_id` column on `equipment`
- `*_type` column on `equipment`
- `*_review_key` column on `equipment`
- unresolved review view
- coverage row in `v_dimension_canonicalization_coverage`
- entries in `v_unresolved_dimension_values`

### 6. Require Reviewable Outcomes

- High-frequency unresolved values should surface in a dedicated `*_unclassified` view.
- New dictionaries should ship with representative tests for canonical mappings, invalid values, and unresolved values.
- If a normalization rule cannot be explained clearly in the docs and dictionary, it is too implicit.

## Source Of Truth

The reviewed dictionary lives at `src/deped_equipment/dictionaries/dcp_attribution_dictionary.csv`.

Expected columns:

- `canonical_name`
- `canonical_type`
- `alias_value`
- `normalized_alias_value`
- `lookup_code`
- `program_year`
- `batch_number`
- `package_number`
- `review_status`
- `notes`

Only rows with `review_status=approved` populate canonical attribution tables during the build.

## Review Rules

- Keep `dcp_package_raw` unchanged as source provenance.
- Promote a value to `canonical_name` only after review.
- Use `alias_value` for observed free-form variants that should resolve to an approved canonical value.
- Treat placeholders such as `✓`, `0`, and `Not Applicable` as non-canonical.
- Treat explicit non-DCP labels as row classifications, not canonical DCP values.
- Use `program_year`, `batch_number`, and `package_number` when they are clear attributes of the procurement label.

## Review Loop

1. Build `artifacts/equipment.db`.
2. Inspect `v_dcp_attribution_unclassified` to find frequent unresolved review keys.
3. Inspect `equipment_dimension_issues` for `dimension_name='dcp_attribution'`.
4. Add approved canonical names and aliases to the reviewed dictionary.
5. Rebuild and verify `v_dimension_canonicalization_coverage` for `dcp_attribution`.

## Examples

- `Laptop for Teaching` -> canonical named package
- `Batch 36` -> alias of `DCP Batch 36`
- `DCP 2022 - Package 1: e-Learning Cart (eLC)` -> reviewed hybrid procurement label
- `✓` -> invalid placeholder, not canonical
- `NON-DCP for learners` -> `non_dcp` classification, not canonical

## Equipment Location Curation

Equipment location review follows the same pattern, with the reviewed dictionary at `src/deped_equipment/dictionaries/equipment_location_dictionary.csv`.

Current reviewed location canonicals:

- `classroom`
- `ict/lab`
- `admin/office`
- `principal`
- `faculty`
- `stock room`
- `lib`
- `als`

Location review rules:

- Keep `equipment_location` unchanged as source provenance.
- Promote a raw location to a reviewed alias only after checking frequency and meaning.
- Map grade-specific classrooms and kindergarten rooms to `classroom`.
- Map computer labs, ICT rooms, e-classrooms, and numbered laboratories to `ict/lab`.
- Map generic buildings and school names such as `School`, `Senior High School`, or `SECURITY BANK BUILDING` to non-canonical invalid classifications instead of canonical locations.

## Other Reviewed Dimensions

The same extension rules now apply to these reviewed dictionaries:

- `src/deped_equipment/dictionaries/supplier_dictionary.csv`
- `src/deped_equipment/dictionaries/disposition_status_dictionary.csv`
- `src/deped_equipment/dictionaries/source_of_funds_dictionary.csv`
- `src/deped_equipment/dictionaries/equipment_condition_dictionary.csv`
