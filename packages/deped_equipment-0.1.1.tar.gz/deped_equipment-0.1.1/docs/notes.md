# Audit Notes

## 1. Acquisition Cost Outliers

Observation:

- Cost distributions vary sharply by canonical item type.
- A small number of extreme values heavily inflate means.
- Some apparent costs are implausibly large for the item and are likely encoding mistakes.

Primary audit view:

```sql
SELECT *
FROM v_audit_acquisition_cost_outlier
ORDER BY item_name, acquisition_cost DESC;
```

Useful summary query:

```sql
SELECT item_name, flag_type, COUNT(*) AS flagged_rows
FROM v_audit_acquisition_cost_outlier
GROUP BY item_name, flag_type
ORDER BY flagged_rows DESC, item_name, flag_type;
```

Interpretation:

- `cost_above_10x_median` usually indicates a misplaced code or an extra-zero error.
- `cost_below_1pct_median` usually indicates unit mismatch, truncation, or bad parsing.

## 2. Suspected UACS Or GL Codes Stored As Cost

Observation:

- Values such as `5020321003` recur across unrelated equipment types.
- These match known UACS or GL code patterns and are not plausible acquisition costs.

Primary audit view:

```sql
SELECT *
FROM v_audit_suspected_uacs_as_cost
ORDER BY acquisition_cost DESC, item_name;
```

Useful summary query:

```sql
SELECT item_name, flag_type, COUNT(*) AS flagged_rows
FROM v_audit_suspected_uacs_as_cost
GROUP BY item_name, flag_type
ORDER BY flagged_rows DESC, item_name;
```

Interpretation:

- Very large costs on peripherals are near-certain data entry errors.
- UACS-family values should be treated as a field-misalignment signal, not a pricing outlier only.

## 3. Condition Versus Disposition Inconsistencies

Observation:

- Some rows are marked non-functional but have no recorded disposition action.
- Other rows show disposal-related status while still being marked functional.

Primary audit view:

```sql
SELECT *
FROM v_audit_condition_disposition_inconsistency
ORDER BY flag_type, equipment_id;
```

Useful summary query:

```sql
SELECT flag_type, COUNT(*) AS flagged_rows
FROM v_audit_condition_disposition_inconsistency
GROUP BY flag_type
ORDER BY flagged_rows DESC, flag_type;
```

Interpretation:

- `non_functional_no_disposition` means the item is broken but no follow-up action was recorded.
- `disposal_status_but_functional` means the condition flag and disposition state disagree.

## 4. Missing Cost Data

Observation:

- Missing cost is common for bundled peripherals and expected in some cases.
- Missing cost on standalone items such as laptops or desktops is more suspicious.

Primary audit view:

```sql
SELECT *
FROM v_audit_missing_cost
ORDER BY item_name, equipment_id;
```

Useful summary query:

```sql
SELECT item_name, COUNT(*) AS missing_cost_rows
FROM v_audit_missing_cost
GROUP BY item_name
ORDER BY missing_cost_rows DESC, item_name;
```

Interpretation:

- This view excludes common bundled peripherals where zero or null cost is often expected.
- High counts for standalone items usually indicate incomplete upstream capture.

## 5. Custodian Assigned To Excessive Devices

Observation:

- The accountable officer can legitimately appear on many school records.
- The custodian or end user should usually be a single-device or low-device assignment.
- A person appearing as custodian for many devices in one school often means the accountable officer was entered in the wrong field.

Primary audit view:

```sql
SELECT *
FROM v_audit_custodian_role_confusion
ORDER BY devices_as_custodian DESC, entity_id, property_no;
```

Useful summary query:

```sql
SELECT flag_type, custodian_name, entity_id,
       devices_as_custodian, school_records_as_accountable
FROM v_audit_custodian_role_confusion
ORDER BY devices_as_custodian DESC, flag_type, custodian_name;
```

Interpretation:

- `custodian_is_accountable_officer` is an unambiguous same-record role collision.
- `high_volume_custodian` flags more than 5 device assignments to one custodian within a school.
- `school_records_as_accountable` helps confirm whether the same person also appears as an accountable officer for that school.

## Recommended Review Flow

1. Build `artifacts/equipment.db`.
2. Inspect each `v_audit_*` view for high-count flags.
3. Spot-check flagged records in `v_equipment_enriched`.
4. Decide whether the issue is upstream data entry, normalization logic, or an expected exception.
5. Keep these notes updated when new audit views are added or thresholds change.
