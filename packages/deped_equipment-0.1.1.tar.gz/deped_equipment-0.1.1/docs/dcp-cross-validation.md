# DCP Cross-Validation

Central Office DCP procurement (2018–2025) is the authoritative record for
centrally-delivered equipment. This document covers how admin-declared equipment
data is validated against DCP contracts, the matching logic, and how to read
the prototype inspection database produced by Phase 1.

**Scope**: Central Office DCP procurement only. LGU, SEF, DICT, Regional
Office, donations, and other non-CO sources are outside the cross-validation
scope.

**Primary concern**: Unit quantity first, cost second. The main question is
whether the school declared the correct number of units. Cost figures are
informational — a property officer may not have known the contract price.
Review `sample_unit_coverage` coverage gaps before looking at cost fields.

---

## Authoritative Source

`deped-dataset/db.sqlite3` — the procurement contract database.

Relevant tables:

| Table | Purpose |
| --- | --- |
| `dcp` | One row per school × year × component delivery |
| `dcp_component_items` | Component name lookup (e.g. "Laptop", "2-in-1 Tablet PC") |
| `dcp_suppliers` | Vendor name lookup |
| `dcp_packages` | Package name lookup (e.g. "IT Equipment") |

Key columns of `dcp`:

| Column | Meaning |
| --- | --- |
| `year` | DCP fund year (procurement authorisation), **not** delivery year |
| `school_id` | Recipient school |
| `component_id` | Foreign key → `dcp_component_items` |
| `unit_actual_cost` | Contract price per unit — the authoritative figure |
| `pkg_count` | Number of packages contracted |
| `units_per_pkg` | Units per package |
| `pkg_count × units_per_pkg` | Total expected units |
| `supplier_id` | Foreign key → `dcp_suppliers` |

---

## Component Mapping

The mapping is one-to-many: one equipment canonical name may correspond to
multiple DCP component names. Matching tries each DCP component in list order
and takes the first hit. Unit coverage is tracked per DCP component separately
so each delivery type shows its own gap.

| equipment canonical name | DCP component name(s) |
| --- | --- |
| Laptop | Laptop, Host Laptop, Specialized Laptop |
| 2-In-1 Tablet | 2-in-1 Tablet PC |
| Smart TV | Smart TV |
| External Hard Drive | External Hard Drive |
| Charging Cart | Charging Cart |
| Modem / Router | Wireless Router |
| Lapel | Lapel |
| AVR | AVR |
| Multifunction Printer | 3-in-1 Multifunction Inkjet Printer |
| Desktop (Package) | Standalone PC, Desktop |
| Standard TV | LED Television |

The "Laptop" → `["Laptop", "Host Laptop", "Specialized Laptop"]` coverage is
confirmed by school 303383: DCP delivered 1 Host Laptop + 50 Laptops in 2019;
the school declared all 59 as "Laptop". Both DCP components must be reachable
via the equipment canonical name.

`Desktop (Package)` and `Standard TV` are confirmed by school 314904: DCP
delivered 41 Standalone PCs at 44,688 and 1 LED Television at 30,344; the
school declared Desktop (Package) at 44,688 ×42 and Standard TV at 30,344 ×1.
Costs match exactly.

**Excluded permanently:**

- `Tablet` — different product from DCP 2-in-1. CO Tablets run 6,999–12,000
  per unit; DCP 2-in-1 Tablet PC contracts run 13,000–15,000 per unit. Unit
  counts also diverge (school 303172: 439 CO Tablets vs 50 DCP units).
- `Thin Client Server (Set)` — pre-2018 thin-client era hardware; the DCP
  dataset only covers 2018 onwards. `no_match` is expected, not an error.

When the Phase 2 build runs, any Central-Office-sourced item that cannot be
mapped gets `dcp_match_type = 'no_component_mapping'`.

---

## Pre-2018 Equipment (Outside DCP Scope)

The DCP dataset only covers 2018 onwards. Schools may have Central-Office-
sourced equipment from earlier procurement programmes (2010–2017) that will
never match any DCP record:

- 2010–2017: Legacy desktop-based e-classrooms using a thin-client approach.
  One Host PC per six thin-client terminals.
- Items from this era: "Thin Client Server (Set)", older "Laptop",
  "Desktop (Package)", "AVR", etc.

These produce `no_match` or `no_year` when they carry a CO source and a
pre-2018 year. This is **expected** — the DCP dataset simply does not cover
that period. Phase 2 must not flag pre-2018 CO items as anomalies.

---

## Year Resolution Logic

DCP fund years are procurement authorisation years. Physical delivery happens
after the fund year, so the invariant is:

```text
dcp.year ≤ received_year
```

### Primary path (exact match)

```text
equipment.dcp_year_package_id
  → equipment_dcp_years.canonical_name   (e.g. "2022")
  → cast to integer
  → look up (school_id, year, dcp_component) in DCP
  → if found: dcp_match_type = "exact"
```

### Fallback path (inferred match)

Used when `dcp_year_package_id` is NULL or no exact DCP row exists for the
declared year:

```text
1. Parse year from acquisition_date (YYYY-MM-DD) → use as ceiling
2. If no acquisition_date, try date_received_new
3. Walk DCP records for (school_id, dcp_component) sorted by year descending
4. Take the first entry with dcp.year ≤ ceiling
   → dcp_match_type = "inferred"
5. If no entry satisfies the ceiling constraint → dcp_match_type = "no_match"
6. If no ceiling can be derived at all → dcp_match_type = "no_year"
```

### Edge cases exercised by sample schools

- **School 309025** (fund-year offset) — equipment declares year_pkg=2019 for
  2-In-1 Tablets; DCP fund year=2018. Exact match fails. Fallback resolves
  correctly to 2018 (`inferred`). Surfaces a 3-unit gap (47 declared vs 50
  expected).
- **School 102851** (no declared year) — dcp_year_package_id is NULL; fallback
  uses acquisition_date 2022-03-04 as ceiling and resolves to DCP year 2020.
- **School 314904** (ceiling below DCP year) — equipment declares year_pkg=2017
  for items that DCP records under fund year 2018. With ceiling=2017 and DCP
  year=2018 > 2017, the fallback finds no entry → `no_match`. This surfaces a
  year declaration error; Phase 2 flags for review rather than silently dropping.

---

## Match Type Reference

| dcp_match_type | Meaning |
| --- | --- |
| `exact` | Declared fund year matched a DCP record exactly |
| `inferred` | Matched via date ceiling fallback (fund-year ≤ ceiling) |
| `non_co_source` | Equipment sourced from non-Central-Office; DCP validation skipped |
| `no_school_id` | Equipment row has no school_id |
| `no_component_mapping` | Item not in DCP component map |
| `no_year` | No fund year and no usable date to derive a ceiling |
| `no_match` | Year and component known but no DCP delivery exists |

---

## Phase 1: Prototype Inspection Database

Before touching the build pipeline, `scripts/dcp_prototype.py` produces
`artifacts/dcp_prototype.db` — a small database joining the two sources for
19 sample schools chosen to cover distinct failure modes.

### Running the prototype

```bash
python scripts/dcp_prototype.py \
  --equipment-db artifacts/equipment.db \
  --dcp-dataset-db ../deped-dataset/db.sqlite3 \
  --output artifacts/dcp_prototype.db
```

Primary inspection (start here):

```bash
sqlite3 -header -column artifacts/dcp_prototype.db \
  "SELECT school_id, dcp_year, dcp_component,
          expected_units, declared_units, unit_gap, coverage_flag, dcp_supplier
   FROM sample_unit_coverage
   WHERE coverage_flag != 'matched'
   ORDER BY ABS(unit_gap) DESC;"
```

### Output tables

**`sample_equipment`** — admin-declared rows for the sample schools with
canonical dimension names pre-joined.

**`sample_dcp`** — DCP delivery records for the same schools. Each row is one
contracted component/year/school. `unit_actual_cost` is the authoritative
per-unit price; `supplier` is the contracted vendor.

**`sample_matched`** — one row per equipment row with DCP enrichment appended.
Use this to compare `declared_cost` vs `dcp_cost` and inspect match types.

**`sample_unit_coverage`** ← **primary inspection table** — per
school/year/DCP-component: expected units from DCP vs declared equipment rows.
Positive `unit_gap` means units are missing. `dcp_supplier` traces the
contracted vendor for accountability on each delivery.

### Sample schools

#### Overstated cost (declared > 120% of contract price)

| school_id | year | item | declared | dcp_cost | ratio | supplier |
| --- | --- | --- | --- | --- | --- | --- |
| 301142 | 2022 | Laptop | 58,270 | 25,781 | 2.3× | Columbia Technologies |
| 303377 | 2022 | Laptop | 76,000 | 36,666 | 2.1× | Accel Prime Technologies |
| 306188 | 2023 | Laptop | 58,270 | 37,120 | 1.6× | Joneco Technologies |
| 128450 | 2023 | Laptop | 60,601 | 36,558 | 1.7× | Reddot Imaging |

#### Not declared (cost NULL, DCP has authoritative price)

| school_id | year | item | dcp_cost | declared_units |
| --- | --- | --- | --- | --- |
| 312506 | 2019 | Laptop | 32,732 | 51 (cost NULL) |

#### Undeclared equipment (DCP delivery exists, zero equipment rows)

| school_id | DCP years covered | largest gap |
| --- | --- | --- |
| 104278 | 2020 | Laptop+Lapel+Smart TV, 1 unit each |
| 305416 | 2018–2024 | 2022: 46 Laptops missing |
| 301710 | 2018–2019 | 2019: 50 Laptops missing |
| 302780 | 2018–2025 | 2022: 46 Laptops missing |

#### Non-CO source (DCP records exist but equipment attributed elsewhere)

| school_id | source | DCP records | behaviour |
| --- | --- | --- | --- |
| 102912 | Regional Office | 2023 Laptop × 5 | `non_co_source` — not matched |
| 300460 | DICT | 2019+2020+2022 | `non_co_source` — not matched |
| 305214 | DICT | 2018+2020+2022 | `non_co_source` — not matched |
| 301064 | LGU (474) + CO (49) | 2021+2022 | CO rows match; LGU rows do not |

School 301064 is worth studying: it has both LGU-sourced and CO-sourced
Laptops. Only the CO rows receive DCP enrichment. The LGU rows are silently
excluded from unit coverage, so the coverage count reflects CO declarations
only.

#### Fund-year offset and year edge cases (inferred / no_match)

| school_id | declared_year | matched_dcp_year | item | note |
| --- | --- | --- | --- | --- |
| 309025 | 2019 | 2018 | 2-In-1 Tablet | 47 declared, 50 expected → 3-unit gap |
| 102851 | (none) | 2020 | Laptop | fallback via acquisition_date 2022-03-04 |
| 314904 | 2017 | — | Desktop (Package) | ceiling < DCP year 2018 → no_match |

#### Mapping-exploration schools

| school_id | scenario | finding |
| --- | --- | --- |
| 303383 | Host Laptop | DCP: 1 Host Laptop + 50 Laptop; school declares 59 Laptop. Confirms Host Laptop must be in the Laptop mapping. |
| 314904 | Desktop + Standard TV | DCP: 41 Standalone PC at 44,688 + 1 LED Television at 30,344. School declares Desktop (Package) ×42 + Standard TV ×1 at matching costs. Confirms both mappings. |
| 303172 | Tablet ambiguity | CO Tablets at 6,999/unit vs DCP 2-in-1 Tablet PC at 14,807/unit; 439 CO vs 50 DCP units. Confirms Tablet must stay excluded. |

### Inspection queries

```sql
-- Match type distribution
SELECT dcp_match_type, COUNT(*) AS cnt
FROM sample_matched
GROUP BY dcp_match_type
ORDER BY cnt DESC;

-- Cost discrepancies for matched rows
SELECT school_id, item_canonical, dcp_year,
       declared_cost, dcp_cost,
       ROUND(declared_cost / dcp_cost, 2) AS ratio,
       dcp_supplier
FROM sample_matched
WHERE dcp_match_type IN ('exact', 'inferred')
  AND dcp_cost IS NOT NULL
  AND (declared_cost IS NULL OR declared_cost = 0
       OR declared_cost > dcp_cost * 1.2
       OR declared_cost < dcp_cost * 0.8)
ORDER BY ABS(COALESCE(declared_cost, 0) - dcp_cost) DESC;

-- Unit gaps by supplier (accountability tracing)
SELECT dcp_supplier, dcp_year, dcp_component,
       SUM(unit_gap) AS total_gap,
       COUNT(*) AS schools_affected
FROM sample_unit_coverage
WHERE coverage_flag IN ('none_declared', 'underdeclared')
GROUP BY dcp_supplier, dcp_year, dcp_component
ORDER BY total_gap DESC;

-- Non-functional DCP-matched equipment
SELECT school_id, item_canonical, dcp_year, dcp_supplier, disposition
FROM sample_matched
WHERE dcp_match_type IN ('exact', 'inferred')
  AND is_non_functional = 1
ORDER BY school_id, dcp_year;

-- Unmapped Central Office items (candidates to add to DCP_COMPONENT_MAP)
SELECT item_canonical, COUNT(*) AS cnt
FROM sample_matched
WHERE dcp_match_type = 'no_component_mapping'
  AND source_of_acquisition = 'Central Office'
GROUP BY item_canonical
ORDER BY cnt DESC;
```

### What to verify before Phase 2

1. **Component mapping completeness** — are there CO items in the unmapped
   summary that clearly correspond to a DCP component? The mapping is now
   considered finalised based on prototype findings; revisit only if new
   unmapped items surface in the full run.
2. **Year matching accuracy** — does the fund-year ≤ ceiling logic produce
   sensible matches for the inferred rows? Check 309025 (2-In-1 Tablet year
   offset) and 102851 (date fallback). Confirm 314904 produces `no_match` as
   expected (not a regression).
3. **Cost discrepancy realism** — are the flagged overstated/understated cases
   genuine price errors, or could the declared cost include installation,
   delivery, or bundle pricing?
4. **Unit gap realism** — do the expected vs declared counts make sense? Some
   overdeclared schools (more rows than DCP units) may reflect replacement
   equipment recorded under the same DCP year.
5. **Non-CO filtering** — does school 301064 correctly split its CO and LGU
   rows? Verify the CO rows match and the LGU rows do not.
6. **Supplier column completeness** — `sample_unit_coverage.dcp_supplier` and
   `sample_matched.dcp_supplier` should be populated for all exact/inferred
   rows. NULL supplier in a matched row is a data quality issue in the DCP
   dataset itself.

---

## Build Integration

The matching logic is embedded in the full equipment build pipeline. Pass
`--dcp-dataset-db ../deped-dataset/db.sqlite3` to activate it; omitting the
flag leaves all `dcp_*` columns NULL and does not affect existing invocations.

### Equipment table columns

Five columns are written after `acquisition_date` for every equipment row:

| Column | Type | Meaning |
| --- | --- | --- |
| `dcp_cost` | REAL | Contract unit price (MIN lot cost when multiple lots exist) |
| `dcp_year` | INTEGER | DCP fund year matched against |
| `dcp_component` | TEXT | Specific DCP component name matched (e.g. "Host Laptop") |
| `dcp_match_type` | TEXT | See match type reference above |
| `dcp_supplier` | TEXT | Contracted vendor for this delivery |

### `dcp_delivery_summary` table

Seeded from the procurement dataset during the build. Stores **one row per
DCP contract lot** — not aggregated by school/year/component — to preserve
cost fidelity across multi-lot deliveries.

Two schools in the prototype sample illustrate why aggregation is wrong:

| school | year | component | lots | costs |
| --- | --- | --- | --- | --- |
| 305416 | 2023 | Laptop | 2 | 33,744 / 33,744 |
| 306188 | 2023 | Laptop | 2 | 35,555 / 37,120 |

Using a single-keyed dict for cost lookup silently discards one lot. School
306188's declared cost (58,270) would be compared against whichever lot was
written last rather than the lower 35,555. The table stores all lots; cost
comparison uses `MIN(unit_cost)` per school/year/component to give schools
the most favourable baseline before flagging overstated costs.

### `effective_acquisition_cost`

`v_equipment_enriched` exposes `effective_acquisition_cost`: it coalesces
`dcp_cost` over `acquisition_cost` for matched rows, giving a single
authoritative cost column regardless of how accurately the school declared it.

### Audit views

| View | What it flags |
| --- | --- |
| `v_audit_dcp_reported_cost` | `overstated` (>120% of contract), `understated` (<80%), `not_declared` (NULL/0 cost) |
| `v_audit_dcp_unit_coverage` | `none_declared`, `underdeclared`, `overdeclared` (informational), `matched` |
| `v_audit_dcp_condition` | `non_functional`, `disposed_but_functional` |

`overdeclared` in `v_audit_dcp_unit_coverage` is informational — replacement
units are issued and recorded under the same DCP year; this is expected and
should not be treated as a hard error.
