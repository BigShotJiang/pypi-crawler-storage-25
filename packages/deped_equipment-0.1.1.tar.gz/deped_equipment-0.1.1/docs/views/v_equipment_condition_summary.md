# `v_equipment_condition_summary`

## Purpose

Provide a simple cross-tab summary of raw condition and disposition combinations in the fact table.

## Source Tables And Views

- `equipment`

## Grain

One row per distinct `equipment_condition` and `disposition_status` text pair.

## Key Columns

- `equipment_condition`
- `disposition_status`
- `item_count`
- `total_cost`

## Business Meaning

This view is a raw summary of the stored fact values. It is useful for profiling source distributions and spotting high-volume condition/disposition combinations before deeper interpretation.

## Caveats And Exclusions

- This is not a resolved functional-status view.
- It groups raw stored values, not reporting-semantic flags.
- Use `v_equipment_semantics` for functional, learner-device, repairable, and age-based fleet metrics.

## Example Queries

```sql
SELECT equipment_condition, disposition_status, item_count
FROM v_equipment_condition_summary
ORDER BY item_count DESC;
```
