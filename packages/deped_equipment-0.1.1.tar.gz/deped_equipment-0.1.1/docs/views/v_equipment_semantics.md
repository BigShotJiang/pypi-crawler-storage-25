# `v_equipment_semantics`

## Purpose

Provide a reusable reporting-semantic layer for device analytics on top of `v_equipment_enriched`.

## Source Tables And Views

- `v_equipment_enriched`

## Grain

One row per `equipment.id`.

## Key Columns

- `is_computing_device`
- `is_learning_space_location`
- `is_classroom_location`
- `is_ict_lab_location`
- `is_functional`
- `is_non_functional_effective`
- `is_repairable`
- `is_disposed_or_inactive`
- `is_learner_device`
- `is_active_learner_device`
- `age_reference_date`
- `age_reference_year`
- `device_age_years`
- `semantics_exclusion_reason`

## Business Meaning

- `is_computing_device` is derived from the stable item semantic flag `item_is_computer`.
- learner-space location means canonical location `classroom` or `ict/lab`.
- `is_learner_device` means computing device in a learner-space location that is still part of active inventory.
- `is_active_learner_device` applies the stricter stock rule: learner device, functional, not for repair, and not inactive/disposed.
- age uses `acquisition_date` first, then DCP year/program year as a coarse fallback.

## Caveats And Exclusions

- `For Repair` is treated as repairable but not active.
- disposal-like states include `For Disposal`, `Disposed`, `Damaged due to calamity`, `Lost/Stolen/Missing`, `Transferred`, and `Donated`.
- semantics operate on post-reconciliation values from the build. If a source contradiction is fully reconciled upstream, this view reflects the reconciled result rather than the original raw conflict.
- year-only age fallback is coarse and should not be mixed with day-precision ages without acknowledging the difference.

## Example Queries

```sql
SELECT property_no, is_learner_device, is_active_learner_device, semantics_exclusion_reason
FROM v_equipment_semantics
WHERE is_computing_device = 1
ORDER BY property_no;
```
