# `v_audit_condition_disposition_inconsistency`

## Purpose

Flag rows where `is_non_functional`, canonical condition, and canonical disposition still disagree after normalization and cross-field reconciliation.

## Source Tables And Views

- `equipment`
- `equipment_conditions`
- `equipment_disposition_statuses`

## Grain

One row per flagged `equipment.id`.

## Key Columns

- `equipment_id`
- `is_non_functional`
- `equipment_condition`
- `disposition_status`
- `flag_type`

## Business Meaning

This is a remediation view. It surfaces contradictions that remain after reconciliation, such as:

- `non_functional_but_serviceable`
- `non_functional_normal_disposition`
- `functional_but_unserviceable`
- `serviceable_but_disposal_disposition`
- `non_functional_no_disposition`

Use it to inspect source-data errors and review backlog, not as a direct reporting denominator.

## Caveats And Exclusions

- The view intentionally keeps both hard and soft contradictions.
- A flagged row may still be usable for conservative reporting through `v_equipment_semantics`.
- This audit does not decide learner-device eligibility or active-stock status by itself.

## Example Queries

```sql
SELECT flag_type, COUNT(*) AS row_count
FROM v_audit_condition_disposition_inconsistency
GROUP BY flag_type
ORDER BY row_count DESC, flag_type;
```
