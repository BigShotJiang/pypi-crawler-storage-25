# `v_equipment_enriched`

## Purpose

Provide the canonical enriched equipment fact view used by downstream consumers that need one row per equipment record with normalized labels attached.

## Source Tables And Views

- `equipment`
- `entities`
- canonical dimension tables such as `equipment_items`, `equipment_locations`, `equipment_conditions`, and related acquisition tables

## Grain

One row per `equipment.id`.

## Key Columns

- all persisted `equipment.*` fields
- canonical labels such as `item_name`, `equipment_location_name`, `equipment_condition_name`, `disposition_status_name`
- semantic item flags from `equipment_items`: `item_is_computer`, `item_is_tv`, `item_is_accessory`
- `effective_acquisition_cost`

## Business Meaning

This is the canonical enrichment layer. It preserves the built row and adds resolved labels needed for analysis without deciding higher-level reporting semantics such as learner-device eligibility or active-stock rules.

## Caveats And Exclusions

- `v_equipment_enriched` is not the final reporting-semantic layer.
- Report definitions that combine item, location, condition, and disposition should use `v_equipment_semantics`.
- Contradictory condition/disposition rows can still appear here because this view is descriptive, not adjudicative.

## Example Queries

```sql
SELECT property_no, item_name, equipment_location_name, equipment_condition_name
FROM v_equipment_enriched
WHERE entity_name = 'Alpha ES';
```
