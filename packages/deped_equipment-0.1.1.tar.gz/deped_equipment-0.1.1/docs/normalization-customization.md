# Dictionaries

Use this document for cross-cutting normalization mechanics and dictionary maintenance. Concern-specific normalization rules are documented alongside the equipment concern they belong to under `docs/equipment/`.

Each YAML file under /dictionaries, maps raw alias values — as they appear in source equipment CSV files — to a canonical name for that dimension. The loader reads the file, normalizes each alias, and returns a sorted list of `AliasRecord` dataclasses used to seed the lookup tables.

## How classification works

Every dimension goes through two stages before a canonical name is assigned:

1. **Invalid-pattern check** (Python, in `normalization/<dimension>.py`)
   Regex patterns that match values which can never belong to this dimension — for example,
   `returned` or `transferred` in the condition column are disposition statuses entered in the wrong field. These are classified as `invalid_<dimension>_value` and written to the issue log. They do **not** appear in the dictionary.

2. **Dictionary lookup** (YAML, this folder)
   Values that pass the invalid-pattern check and have a normalized form are looked up against the alias table. A hit returns the canonical name; a miss is classified as `unclassified` and queued for review.

When adding a new alias value, check whether it is genuinely the wrong kind of data (→ add a pattern to `_INVALID_PATTERNS` in the Python file) or a valid-but-unrecognized value
(→ add it to the YAML dictionary here).

---

## Cross-field condition/disposition inference

When one of `equipment_condition` or `disposition_status` is absent from the source row (raw value is null/empty), the loader infers a default for the missing field based on the resolved canonical of the present field. This runs in `apply_cross_field_defaults()` in `equipment_loader.py`, after `reassign_condition_and_disposition` has already handled misplaced values.

Inferred rows get `*_type = "inferred_from_condition"` or `"inferred_from_disposition"` instead of `"reviewed_*"`, making them auditable.

### Condition → Disposition defaults

Applied when `equipment_condition_id` is resolved and `disposition_status` raw value is null:

| Canonical condition | Inferred disposition |
| ------------------- | -------------------- |
| `Serviceable`       | `Normal`             |
| `Unserviceable`     | `For Disposal`       |
| `For Repair`        | `Normal`             |

### Disposition → Condition defaults

Applied when `disposition_status_id` is resolved and `equipment_condition` raw value is null:

| Canonical disposition      | Inferred condition  |
| -------------------------- | ------------------- |
| `Damaged due to calamity`  | `Not Applicable`    |
| `For Disposal`             | `Not Applicable`    |

### Interaction with `reassign_condition_and_disposition`

`reassign_condition_and_disposition` runs first and handles the case where a value was entered in the **wrong column** (e.g. a condition value typed into the disposition field). Once either field has an ID from that step, the cross-field default rules are suppressed for that field — `apply_cross_field_defaults` only fires when a field's raw value is genuinely absent **and** no ID was assigned by the reassign step.

### Interaction with `is_non_functional`

Before defaults are inferred, `reconcile_non_functional_flag()` aligns the raw checkbox value against the already-resolved condition and disposition. Typed fields are treated as more deliberate than a checkbox (e.g. a user who ticked "Non-Functional" but also entered "Serviceable" as the condition):

| Resolved canonical | Effect on `is_non_functional` |
| ------------------ | ------------------------------ |
| condition = `Serviceable` | forced to `0` |
| condition = `Unserviceable` | forced to `1` |
| disposition = `Normal` | forced to `0` (if condition didn't already decide) |
| disposition = `Damaged due to calamity` | forced to `1` (if condition didn't already decide) |
| anything else | raw source value kept |

This reconciliation runs **between** `reassign_condition_and_disposition` and `apply_cross_field_defaults`, so the corrected flag is available as a guard against inferring contradictory defaults. Specifically: `apply_cross_field_defaults` will not infer `disposition = Normal` when `is_non_functional = 1` (after reconciliation). Rows that remain contradictory after all steps surface in the DQ audit view described below.

---

## Condition / disposition / is_non_functional consistency

Three fields interact and must be mutually consistent. The `v_audit_condition_disposition_inconsistency` view flags rows that violate the rules below.

### Permitted combinations

| `is_non_functional` | `equipment_condition` | `disposition_status` |
| ------------------- | --------------------- | -------------------- |
| 0 / NULL | `Serviceable` | `Normal`, `Transferred`, `Donated`, NULL |
| 0 / NULL | `For Repair` | any |
| 0 / NULL | `Not Applicable` | any |
| 1 | `Unserviceable` | `For Disposal`, `Disposed`, `Damaged due to calamity`, `Lost/Stolen/Missing`, `Transferred`, `Donated`, NULL |
| 1 | `For Repair` | same as Unserviceable row above |
| 1 | `Not Applicable` | same as Unserviceable row above |

### Flagged combinations

| `flag_type` | Condition | Severity |
| ----------- | --------- | -------- |
| `non_functional_but_serviceable` | `is_non_functional=1` AND `condition=Serviceable` | Hard — direct contradiction |
| `non_functional_normal_disposition` | `is_non_functional=1` AND `disposition=Normal` | Hard — non-functional equipment cannot be Normal |
| `functional_but_unserviceable` | `is_non_functional=0` AND `condition=Unserviceable` | Soft — checkbox may simply be unchecked; review |
| `serviceable_but_disposal_disposition` | `condition=Serviceable` AND `disposition` ∈ {For Disposal, Disposed, Damaged due to calamity} | Soft — may be valid (e.g. obsolescence disposal) |
| `non_functional_no_disposition` | `is_non_functional=1` AND `disposition_status_id IS NULL` | Soft — non-functional items should have a recorded disposition |

Hard flags almost always indicate erroneous source data. Soft flags require human review — the combination is unusual but not impossible.

---

## Equipment location — extended classification

`equipment_location` uses a three-tier resolution pipeline defined in
`normalization/location.py` and wired in `equipment_loader.py`:

### Tier 1 — programmatic inference (`infer_equipment_location_canonical`)

Before the YAML is consulted, a set of regex rules resolves the normalized value directly
to a canonical. Rules are evaluated in priority order; the first match wins.

| Priority | Pattern | Canonical | Notes |
| -------- | ------- | --------- | ----- |
| 1 | `\bals\b` | `als` | |
| 2 | `\b(library\|…\|lib)\b` | `lib` | |
| 3 | `\b(classroom\|grade\s+\d+…)\b` | `classroom` | includes `grade N`, `grade N room`, kinder variants |
| 4 | `\b(ict\|computer\|lab\|…)\b` | `ict/lab` | |
| 5 | `\b(principal\|school head)\b` | `principal` | |
| 6 | `\bfaculty\b` | `faculty` | |
| 7 | `\b(stock\s*room\|storage\s*room\|…)\b` | `stock room` | |
| 8 | `\b(admin\|office\|sdo\|…)\b` | `admin/office` | |
| 9 | `\b(teacher\|teachers\|teaching\|personnel\|end\s+user\|student)\b` | `personnel` | covers all teacher-custody/assignment variants |
| 10 | full match `^room\s+(?:no\s+)?\d+$` | `classroom` | bare "Room 5" / "Room No. 3"; compound strings like "DCP Room 1" fall through to YAML |

Classroom takes precedence over `ict/lab` so that compound strings like
"Timbanga ES, ICT Room/Grade 5 Classroom" resolve to `classroom`.
`ict/lab` takes precedence over `faculty`/`stock room`/`admin` so that
"ICT room / storage room / faculty room" resolves to `ict/lab`.

### Tier 2 — YAML dictionary fallback

Only consulted when inference returns `None`. The YAML dictionary is therefore intentionally
slim — it covers genuine exceptions that patterns cannot handle:

- Non-pattern aliases: `avr`, `dcp room`, `dcp room 1`, `jhs dcp room`, `storage`, `storage area`, `cyberlab`, `elibrary`, `eroom`, `dcp`, etc.
- `lib` abbreviations not in the pattern: `slrc`, `lrc`, `learning resource center`, `ilrc center`
- Bare abbreviated forms: `kinder`, `kindergarten` (standalone, without classroom/room suffix)
- Personnel entries with no pattern keyword: `ict coordinator`, `movable`
- `not_applicable` values: `n/a`, `na`, `not available`, `0`, `✓`

Do **not** add aliases that are already handled by inference — they will never be reached.
The YAML is loaded once at schema init time and stored in memory; there is no per-row I/O.

### Invalid classification

Values that cannot be resolved are classified before inference runs:

| Issue type | Condition | Examples |
| ---------- | --------- | ------- |
| `invalid_pure_digit_location` | Entire normalized value is digits | `658`, `45804003` (BEIS school IDs in the wrong field) |
| `invalid_generic_location` | Matches `\b(school\|high school\|building)\b` with no room/location keyword present | `School`, `NEW BUILDING`, `Security Bank Building` |
| `invalid_school_name_location` | Matches school-name suffixes (`\bes\b`, `\bmihs\b`, `\binhs\b`, etc.) or phrases (`integrated school`, `national high school`, …) with no room/location keyword | `Nasuji ES`, `F.M. Posadas ES`, `SHS-LUCSUHIN INTEGRATED SCHOOL` |

The "rescue" check (`_has_specific_location_pattern`) prevents false positives: a string
that contains a school-name indicator **and** a room keyword (e.g. `Grade 5 Classroom, Bataan ES`)
is not flagged — inference resolves it normally.

### Canonical seeding

All ten canonical location names are always inserted into the database at schema init
(`iter_equipment_location_canonicals()`), independent of YAML content. This guarantees
that inference-resolved canonicals exist in `lookup_maps["equipment_locations"]` even
when a canonical has no YAML aliases.

---

## YAML format

```yaml
Canonical Name:            # the standardized value stored in the database
  aliases:
    - Raw Alias Value      # exact string as found in source data
    - ANOTHER VARIANT      # case/spacing variants are common
    - Alternate Spelling   # misspellings or abbreviations
```

### Optional fields

```yaml
Canonical Name:
  draft: true              # exclude from build output until reviewed
  aliases:
    - Pending Value
```

All entries without `draft: true` are treated as approved.

### DCP attribution — additional fields

The DCP attribution dictionary carries metadata used to seed the `dcp_attributions` table.
Omit any field whose value can be inferred from the canonical name by
`infer_dcp_attribution_metadata()` (batch numbers, program years, package numbers).

```yaml
DCP Batch 99:
  type: batch_label        # batch_label | hybrid_label | named_package
  batch_number: 99         # integer; inferred from canonical name if absent
  program_year: 2024       # integer; inferred if absent
  package_number: 1        # integer; inferred if absent
  lookup_code: ABC-99      # external lookup code; omit if none
  notes: Human-readable context about this entry.
  aliases:
    - DCP Batch 99
    - Batch 99
    - "Batch 99: Special Label"   # quote strings containing ': '
```

---

## Adding a new entry

1. Identify the canonical name (the standardized form that will be stored in the database).
2. Collect all alias values seen in source data that should map to it.
3. Add them under a new top-level key. Start with `draft: true` if the mapping needs a second
   review; remove the flag once confirmed.
4. Run a build — unrecognized values appear in the dimension issues report, which makes it
   easy to spot new aliases that need to be added.

## Normalizing aliases

The loader normalizes each alias value before lookup using the dimension's
`normalize_<dimension>_review_key()` function (Unicode NFKC, casefold, whitespace collapse,
common substitutions). Two aliases that normalize to the same key are treated as identical, so
you do not need to enumerate every case variant — only include variants that differ in ways
the normalizer does not collapse (e.g. distinct abbreviations, genuine spelling variants).
