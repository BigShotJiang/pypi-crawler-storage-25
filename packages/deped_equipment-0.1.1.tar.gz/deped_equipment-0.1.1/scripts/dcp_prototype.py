"""Phase 1: Prototype Inspection Database for DCP Cross-Validation.

PURPOSE
-------
This script validates the matching strategy that Phase 2 will embed into the
full build pipeline. It joins equipment.db (admin-declared) against
deped-dataset/db.sqlite3 (authoritative DCP procurement contracts) for a
curated set of sample schools, each chosen to stress-test a specific failure
mode.

PRIMARY CONCERN: QUANTITY
The main question is whether the school declared the correct number of units.
Cost figures are secondary — the property officer who encoded the record may
simply not have known the contract price. Unit gaps (none_declared,
underdeclared) are the actionable signal. Cost discrepancies are informational.

Run this script, then open artifacts/dcp_prototype.db and focus first on
sample_unit_coverage before looking at sample_matched cost fields.

OUTPUT TABLES
-------------
sample_equipment
    Raw equipment rows for the sample schools, with canonical dimension names
    already resolved (item, dcp_year_package, source_of_acquisition,
    disposition). This is what the admin declared.

sample_dcp
    DCP delivery records for the same schools pulled from the procurement
    dataset. Each row is one contracted component delivered to one school in
    one year. unit_actual_cost is the contract price per unit (authoritative).
    The supplier column names the contracted vendor.

sample_matched
    The join result — one row per equipment row with DCP fields appended.
    dcp_match_type describes how (or why not) the match was made:

        exact            — dcp_year_package_id integer matched a DCP fund year
                           exactly.
        inferred         — no exact year match; used acquisition_date or
                           date_received_new as a ceiling and took the most
                           recent DCP year ≤ ceiling for that school/component.
        non_co_source    — source_of_acquisition is not Central Office; DCP
                           validation does not apply regardless of DCP records.
        no_school_id     — equipment row has no school_id; cannot look up DCP.
        no_component_mapping — item has no entry in DCP_COMPONENT_MAP.
                           These are worth studying: see SAMPLE_SCHOOL_IDS
                           notes on schools 303172 (Tablet ambiguity) and
                           314904 (Thin Client Server / Standalone PC).
        no_year          — no dcp_year_package_id and no usable date for
                           fallback. Cannot determine which DCP year to match.
        no_match         — component is mappable and a year ceiling is known,
                           but no DCP delivery exists for that school/component
                           at or before the ceiling. May indicate a dataset gap
                           or incorrectly labelled DCP provenance.

sample_unit_coverage  ← PRIMARY INSPECTION TABLE
    Per school/year/DCP-component. Compares expected_units (from DCP contract)
    against declared_units (equipment rows that matched this delivery). The gap
    is the key signal. dcp_supplier names the contracted vendor.

        coverage_flag values:
        none_declared  — DCP records show delivery but zero matching equipment rows
        underdeclared  — fewer declared rows than expected units (partial gap)
        overdeclared   — more declared rows than expected units (replacement units
                         or equipment from a prior DCP year counted here)
        matched        — counts agree exactly

COMPONENT MAPPING (one-to-many on the DCP side)
-------------------------------------------------
equipment canonical name → list of DCP component names it can match.

For equipment with multiple possible DCP counterparts (e.g. "Laptop" covers
both "Laptop" and "Host Laptop"), matching tries each DCP component in list
order and takes the first hit. Unit coverage is tracked per DCP component
separately so each delivery type shows its own gap.

PRE-2018 EQUIPMENT (OUTSIDE DCP SCOPE)
--------------------------------------
The DCP dataset only covers 2018 onwards. Schools may have Central-Office-
sourced equipment from earlier procurement programmes that will never match
any DCP record:

    2010–2017: Legacy desktop-based e-classrooms ("thin-client" approach).
    One Host PC per six thin-client terminals. Cost-effective but processing
    power was shared across devices. Shifted to individual laptops from 2018.

Equipment items from this era — "Thin Client Server (Set)", older "Laptop",
"Desktop (Package)", "AVR", etc. — will produce no_match or no_year when
they have a CO source and a pre-2018 year. This is EXPECTED; it does not
indicate mislabelling. The DCP dataset simply does not cover that period.

Excluded from the DCP_COMPONENT_MAP:
    "Tablet"                  — CO Tablets appear at ~7,000–12,000/unit while
                                DCP 2-in-1 Tablet PC contracts run ~13,000–
                                15,000/unit. Almost certainly a different product
                                line. School 303172 demonstrates the ambiguity.
    "Thin Client Server (Set)"— Pre-2018 thin-client era hardware. Not in DCP
                                (DCP only covers 2018+). Do not map.

YEAR RESOLUTION LOGIC
---------------------
DCP fund years are procurement authorisation years, not delivery years.
Delivery physically happens after the fund year, so:

    dcp.year ≤ received_year / acquisition_year

Primary path:
    equipment.dcp_year_package_id → equipment_dcp_years.canonical_name (an
    integer string) → cast to int → look up (school_id, year, component) in
    DCP. If found → match_type = "exact".

Fallback path (when dcp_year_package_id is NULL or no exact DCP row exists):
    Parse year from acquisition_date or date_received_new (YYYY-MM-DD).
    Use that year as a ceiling. Walk DCP records for (school_id, component)
    sorted by year descending and take the first entry with year ≤ ceiling.
    → match_type = "inferred".

Edge cases exercised by sample schools:
    • School 309025 — equipment declares year_pkg = 2019 for 2-In-1 Tablets,
      but the DCP fund year is 2018. An exact match fails. Fallback resolves
      correctly as "inferred" against DCP year 2018 (fund-year offset pattern).
    • School 102851 — dcp_year_package_id is NULL; fallback uses acquisition
      date 2022-03-04 as ceiling and resolves to DCP year 2020.
    • School 314904 — equipment declares year_pkg = 2017 for items that the
      DCP records in year 2018 (Desktop/Standard TV package). With ceiling=2017
      and DCP year=2018 > 2017, the fallback finds no entry → no_match. This
      surfaces a year declaration error; Phase 2 must handle gracefully.

SAMPLE SCHOOL SELECTION
-----------------------
Original 7 + 12 extended (3 per scenario) + 3 new mapping-exploration schools:

  Scenario               Schools
  ─────────────────────  ──────────────────────────────────────────────────────
  not_declared           312506
  understated+nf         309025
  inferred               102851
  multi-year+cond        300418
  overstated (×4)        301142, 303377, 306188, 128450
  undeclared (×4)        104278, 305416, 301710, 302780
  non_co_source (×4)     102912, 300460, 305214, 301064
  host_laptop mapping    303383  — DCP delivers Host Laptop + Laptop together;
                                   school declares all as "Laptop"
  standalone_pc mapping  314904  — DCP delivers Standalone PC + LED Television;
                                   school declares Desktop (Package) + Standard TV
  tablet ambiguity       303172  — CO Tablets at 6,999/unit vs DCP 2-in-1 at
                                   14,807/unit; clearly different products

Usage:
    python scripts/dcp_prototype.py \\
      --equipment-db artifacts/equipment.db \\
      --dcp-dataset-db ../deped-dataset/db.sqlite3 \\
      --output artifacts/dcp_prototype.db

Primary inspection (start here):
    sqlite3 -header -column artifacts/dcp_prototype.db \\
      "SELECT school_id, dcp_year, dcp_component,
              expected_units, declared_units, unit_gap, coverage_flag, dcp_supplier
       FROM sample_unit_coverage
       WHERE coverage_flag != 'matched'
       ORDER BY ABS(unit_gap) DESC;"
"""

from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

# ── Sample Schools ──────────────────────────────────────────────────────────
# Each school demonstrates a distinct real-world scenario.
#
# Original 7 (one-of-a-kind cases):
#   312506 — not_declared          : 50+ CO Laptops in 2019, acquisition_cost
#                                    all NULL. DCP says 32,732/unit.
#   309025 — understated + nf      : 2018 Laptop 25,175 vs DCP 34,480.
#                                    2-In-1 Tablets declared year_pkg=2019 but
#                                    DCP fund year=2018 (fund-year offset).
#   102851 — inferred (no yr_pkg)  : dcp_year_package_id NULL; matched via
#                                    acquisition_date=2022-03-04 → DCP year 2020.
#   300418 — multi-year+condition  : 2019+2024 DCP deliveries; 2018 Laptops
#                                    non-functional. Condition tracing.
#
# Overstated (×4 — cost declared >20% above contract price):
#   301142 — 2022 Laptop 58,270 vs DCP 25,781  (~2.3×)
#   303377 — 2022 Laptop 76,000 vs DCP 36,666  (~2.1×)
#   306188 — 2023 Laptop 58,270 vs DCP 37,120  (~1.6×)
#   128450 — 2023 Laptop 60,601 vs DCP 36,558  (~1.7×)
#
# Undeclared (×4 — DCP shows delivery, zero or very few equipment rows):
#   104278 — 2020 delivery (Laptop+Lapel+Smart TV), no equipment rows
#   305416 — zero rows; deliveries 2018–2024 across many components
#   301710 — zero rows; deliveries 2018–2019
#   302780 — zero rows; deliveries 2018–2025 (widest gap in sample)
#
# Non-CO source (×4 — equipment attributed to non-Central-Office source):
#   102912 — Regional Office; has 2023 DCP Laptop records → non_co_source
#   300460 — DICT source; DCP 2019+2020+2022 → non_co_source
#   305214 — DICT source; DCP 2018+2020+2022 → non_co_source
#   301064 — LGU (474 Laptops) + CO (49 Laptops) mixed; CO rows match
#
# New mapping-exploration schools:
#   303383 — Host Laptop pattern   : DCP 2019 = Host Laptop (1 unit, 32,732) +
#                                    Laptop (50 units, 32,732). School declares
#                                    59 Laptops at 32,732. Shows that Host Laptop
#                                    must be covered by the "Laptop" mapping.
#   314904 — Desktop+Standard TV   : DCP 2018 = Standalone PC (41 units, 44,688)
#                                    + LED Television (1 unit, 30,344). School
#                                    declares Desktop (Package) at 44,688 ×42 and
#                                    Standard TV at 30,344 ×1 (costs match).
#                                    Also has yr_pkg=2017 rows that the DCP
#                                    records under 2018 → no_match edge case.
#   303172 — Tablet ambiguity      : CO Tablets declared at 6,999/unit (no yr_pkg)
#                                    vs DCP 2018 2-in-1 Tablet PC at 14,807/unit.
#                                    Unit counts also diverge (439 vs 50).
#                                    Demonstrates why "Tablet" stays excluded.
SAMPLE_SCHOOL_IDS = (
    # original
    312506,
    309025,
    301142,
    102851,
    102912,
    104278,
    300418,
    # overstated additions
    303377,
    306188,
    128450,
    # undeclared additions
    305416,
    301710,
    302780,
    # non_co_source additions
    300460,
    305214,
    301064,
    # mapping-exploration
    303383,
    314904,
    303172,
)

# ── Component Mapping (one-to-many) ─────────────────────────────────────────
# equipment_items.canonical_name → list of dcp_component_items.package_component
#
# A list is used because some equipment canonical names correspond to multiple
# DCP component types (e.g. "Laptop" covers standard Laptops, Host Laptops, and
# Specialized Laptops — all declared as "Laptop" in equipment). Matching tries
# each DCP component in list order and takes the first hit.
#
# Excluded intentionally:
#   "Tablet"                  — see docstring and school 303172 for rationale.
#   "Thin Client Server (Set)"— pre-2018 thin-client era hardware; DCP only
#                                covers 2018+. No_match is expected, not an error.
DCP_COMPONENT_MAP: dict[str, list[str]] = {
    "Laptop": ["Laptop", "Host Laptop", "Specialized Laptop"],
    "2-In-1 Tablet": ["2-in-1 Tablet PC"],
    "Smart TV": ["Smart TV"],
    "External Hard Drive": ["External Hard Drive"],
    "Charging Cart": ["Charging Cart"],
    "Modem / Router": ["Wireless Router"],
    "Lapel": ["Lapel"],
    "AVR": ["AVR"],
    "Multifunction Printer": ["3-in-1 Multifunction Inkjet Printer"],
    "Desktop (Package)": ["Standalone PC", "Desktop"],
    "Standard TV": ["LED Television"],
}

# Flat reverse map: DCP component name → equipment canonical name.
# Built from DCP_COMPONENT_MAP; used to map DCP coverage rows back to equipment.
_DCP_TO_EQUIPMENT: dict[str, str] = {
    dcp_comp: equip_name
    for equip_name, dcp_comps in DCP_COMPONENT_MAP.items()
    for dcp_comp in dcp_comps
}

# Only equipment sourced from Central Office is subject to DCP cross-validation.
CO_SOURCE_CANONICAL = "Central Office"


# ── Helpers ─────────────────────────────────────────────────────────────────


def _attach(conn: sqlite3.Connection, path: Path, alias: str) -> None:
    conn.execute(f"ATTACH DATABASE ? AS {alias}", (str(path),))


def _dcp_year_from_canonical(name: str) -> int | None:
    """Cast equipment_dcp_years.canonical_name (e.g. '2022') to int."""
    try:
        return int(name)
    except ValueError, TypeError:
        return None


def _year_from_date(date_str: str | None) -> int | None:
    """Extract the year from a YYYY-MM-DD date string."""
    if not date_str or len(date_str) < 4:
        return None
    try:
        return int(date_str[:4])
    except ValueError:
        return None


# ── Table Creation ───────────────────────────────────────────────────────────


def create_tables(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        -- Admin-declared equipment for the sample schools.
        -- Canonical dimension names are pre-joined from equipment.db lookups.
        CREATE TABLE IF NOT EXISTS sample_equipment (
            equipment_id        INTEGER,  -- equipment.id
            school_id           INTEGER,  -- entity school_id foreign key
            item_canonical      TEXT,     -- equipment_items.canonical_name
            dcp_year_package    TEXT,     -- equipment_dcp_years.canonical_name (e.g. '2022')
            acquisition_cost    REAL,     -- declared per-unit cost (may be NULL or wrong)
            source_of_acquisition TEXT,   -- equipment_acquisition_sources.canonical_name
            is_non_functional   INTEGER,  -- 1 if marked non-functional
            disposition         TEXT,     -- equipment_disposition_statuses.canonical_name
            acquisition_date    TEXT,     -- YYYY-MM-DD; fallback for year resolution
            date_received_new   TEXT      -- YYYY-MM-DD; secondary fallback
        );

        -- Authoritative DCP delivery records from the procurement dataset.
        -- Each row is one contracted component delivered to one school in one year.
        -- unit_actual_cost is the contract price per unit — the authoritative figure.
        CREATE TABLE IF NOT EXISTS sample_dcp (
            school_id        INTEGER,  -- recipient school
            year             INTEGER,  -- DCP fund year (procurement authorisation year)
            component        TEXT,     -- dcp_component_items.package_component
            unit_actual_cost REAL,     -- contract price per unit (authoritative)
            pkg_count        INTEGER,  -- number of packages contracted
            units_per_pkg    INTEGER,  -- units per package
            expected_units   INTEGER,  -- pkg_count × units_per_pkg (total units)
            supplier         TEXT      -- contracted vendor name
        );

        -- One row per equipment row with DCP enrichment appended.
        -- dcp_match_type explains how the match was made (or why it was not).
        -- For non-matched rows, all dcp_* fields are NULL.
        CREATE TABLE IF NOT EXISTS sample_matched (
            equipment_id          INTEGER,
            school_id             INTEGER,
            item_canonical        TEXT,
            -- admin-declared fields
            declared_cost         REAL,    -- acquisition_cost as declared
            declared_year         TEXT,    -- dcp_year_package as declared
            source_of_acquisition TEXT,
            -- authoritative DCP fields (NULL when not matched)
            dcp_cost              REAL,    -- unit_actual_cost from DCP contract
            dcp_year              INTEGER, -- DCP fund year matched against
            dcp_component         TEXT,    -- specific DCP component name matched
            dcp_match_type        TEXT,    -- see module docstring for values
            dcp_supplier          TEXT,    -- contracted vendor for this delivery
            -- condition
            is_non_functional     INTEGER,
            disposition           TEXT
        );

        -- PRIMARY INSPECTION TABLE.
        -- Unit coverage per school/year/DCP-component.
        -- expected_units comes from the DCP contract; declared_units is the count
        -- of equipment rows that matched this specific delivery. Positive unit_gap
        -- means units are missing from the equipment records.
        CREATE TABLE IF NOT EXISTS sample_unit_coverage (
            school_id       INTEGER,
            dcp_year        INTEGER,
            dcp_component   TEXT,     -- specific DCP component (may differ from equip name)
            expected_units  INTEGER,  -- from DCP contract (authoritative)
            declared_units  INTEGER,  -- matched equipment rows for this dcp_component
            unit_gap        INTEGER,  -- expected − declared (positive = missing units)
            coverage_flag   TEXT,     -- none_declared / underdeclared / overdeclared / matched
            dcp_supplier    TEXT      -- contracted vendor for this delivery
        );
    """)


# ── Extract Equipment ────────────────────────────────────────────────────────


def extract_sample_equipment(conn: sqlite3.Connection) -> None:
    """Pull equipment rows for the sample schools, resolving canonical names."""
    placeholders = ",".join("?" for _ in SAMPLE_SCHOOL_IDS)
    conn.execute(
        f"""
        INSERT INTO sample_equipment
        SELECT
            e.id,
            e.school_id,
            ei.canonical_name,
            edy.canonical_name,
            e.acquisition_cost,
            eas.canonical_name,
            e.is_non_functional,
            eds.canonical_name,
            e.acquisition_date,
            e.date_received_new
        FROM eq.equipment e
        LEFT JOIN eq.equipment_items ei ON e.item_id = ei.id
        LEFT JOIN eq.equipment_dcp_years edy ON e.dcp_year_package_id = edy.id
        LEFT JOIN eq.equipment_acquisition_sources eas
            ON e.source_of_acquisition_id = eas.id
        LEFT JOIN eq.equipment_disposition_statuses eds
            ON e.disposition_status_id = eds.id
        WHERE e.school_id IN ({placeholders})
        """,
        SAMPLE_SCHOOL_IDS,
    )
    count = conn.execute("SELECT COUNT(*) FROM sample_equipment").fetchone()[0]
    print(f"  sample_equipment: {count} rows")


# ── Extract DCP ──────────────────────────────────────────────────────────────


def extract_sample_dcp(conn: sqlite3.Connection) -> None:
    """Pull DCP delivery records for the sample schools."""
    placeholders = ",".join("?" for _ in SAMPLE_SCHOOL_IDS)
    conn.execute(
        f"""
        INSERT INTO sample_dcp
        SELECT
            d.school_id,
            d.year,
            ci.package_component,
            d.unit_actual_cost,
            d.pkg_count,
            d.units_per_pkg,
            d.pkg_count * d.units_per_pkg,
            s.supplier
        FROM ds.dcp d
        JOIN ds.dcp_component_items ci ON d.component_id = ci.id
        JOIN ds.dcp_suppliers s ON d.supplier_id = s.id
        WHERE d.school_id IN ({placeholders})
        """,
        SAMPLE_SCHOOL_IDS,
    )
    count = conn.execute("SELECT COUNT(*) FROM sample_dcp").fetchone()[0]
    print(f"  sample_dcp: {count} rows")


# ── Matching Logic ───────────────────────────────────────────────────────────


def _build_dcp_exact_lookup(
    conn: sqlite3.Connection,
) -> dict[tuple[int, int, str], tuple[float, str]]:
    """Build (school_id, year, dcp_component) → (unit_cost, supplier) for exact match.

    When a school has multiple lots for the same (year, component), stores the
    last-written value. Use _build_dcp_min_cost_lookup for cost comparison.
    """
    lookup: dict[tuple[int, int, str], tuple[float, str]] = {}
    for school_id, year, component, cost, supplier in conn.execute(
        "SELECT school_id, year, component, unit_actual_cost, supplier FROM sample_dcp"
    ):
        lookup[(school_id, year, component)] = (cost, supplier)
    return lookup


def _build_dcp_fallback_lookup(
    conn: sqlite3.Connection,
) -> dict[tuple[int, str], list[tuple[int, float, str]]]:
    """Build (school_id, dcp_component) → [(year, cost, supplier)] desc by year.

    Used for the fallback path: find the most recent DCP year ≤ a date ceiling.
    """
    by_sc: dict[tuple[int, str], list[tuple[int, float, str]]] = {}
    for school_id, year, component, cost, supplier in conn.execute(
        "SELECT school_id, year, component, unit_actual_cost, supplier FROM sample_dcp"
    ):
        by_sc.setdefault((school_id, component), []).append((year, cost, supplier))
    for entries in by_sc.values():
        entries.sort(key=lambda x: x[0], reverse=True)
    return by_sc


def _resolve_dcp_match(
    school_id: int,
    year_int: int | None,
    acq_date: str | None,
    date_received: str | None,
    dcp_components: list[str],
    dcp_exact: dict[tuple[int, int, str], tuple[float, str]],
    dcp_fallback: dict[tuple[int, str], list[tuple[int, float, str]]],
) -> tuple[str, float | None, int | None, str | None, str | None]:
    """Try to match one equipment row against its possible DCP components.

    Tries each component in dcp_components (in order) using the primary exact
    path first, then the date-ceiling fallback. Returns the first successful
    match found, or a no_* result if nothing matches.

    Returns (match_type, dcp_cost, dcp_year, dcp_component, dcp_supplier).
    """
    ceiling = _year_from_date(acq_date) or _year_from_date(date_received)

    # Primary path: try exact year match for each DCP component in order.
    if year_int is not None:
        for dcp_comp in dcp_components:
            key = (school_id, year_int, dcp_comp)
            if key in dcp_exact:
                cost, supplier = dcp_exact[key]
                return "exact", cost, year_int, dcp_comp, supplier

    # Fallback path: try date-ceiling match for each DCP component in order.
    if year_int is None and ceiling is None:
        return "no_year", None, None, None, None

    search_ceiling: int = ceiling or year_int  # type: ignore[assignment]
    for dcp_comp in dcp_components:
        entries = dcp_fallback.get((school_id, dcp_comp), [])
        found = next(
            ((y, c, s) for y, c, s in entries if y <= search_ceiling),
            None,
        )
        if found:
            dcp_year_found, dcp_cost, dcp_supplier = found
            match_type = (
                "inferred"
                if (year_int is None or year_int != dcp_year_found)
                else "exact"
            )
            return match_type, dcp_cost, dcp_year_found, dcp_comp, dcp_supplier

    return "no_match", None, None, None, None


def match_equipment(conn: sqlite3.Connection) -> None:
    """Populate sample_matched with DCP enrichment for each equipment row.

    Match type decision tree (evaluated in order):
        1. Non-CO source         → non_co_source (skip DCP entirely)
        2. No school_id          → no_school_id
        3. No component mapping  → no_component_mapping
        4–7. See _resolve_dcp_match for exact/inferred/no_year/no_match logic.

    For equipment items with multiple DCP counterparts (e.g. "Laptop" covers
    "Laptop", "Host Laptop", "Specialized Laptop"), the first DCP component
    with a matching record wins. Unit coverage is tracked per DCP component.
    """
    dcp_exact = _build_dcp_exact_lookup(conn)
    dcp_fallback = _build_dcp_fallback_lookup(conn)

    equip_rows = conn.execute(
        """
        SELECT equipment_id, school_id, item_canonical, dcp_year_package,
               acquisition_cost, source_of_acquisition, is_non_functional,
               disposition, acquisition_date, date_received_new
        FROM sample_equipment
        """
    ).fetchall()

    matched_rows: list[tuple] = []
    for row in equip_rows:
        (
            eq_id,
            school_id,
            item_canonical,
            dcp_year_pkg,
            acq_cost,
            source_acq,
            is_nf,
            disposition,
            acq_date,
            date_received,
        ) = row

        dcp_components: list[str] | None = (
            DCP_COMPONENT_MAP.get(item_canonical) if item_canonical else None
        )

        if source_acq and source_acq != CO_SOURCE_CANONICAL:
            # Equipment from a non-Central-Office source. DCP validation skipped.
            match_type = "non_co_source"
            dcp_cost = dcp_year = dcp_comp = dcp_supplier = None

        elif not school_id:
            match_type = "no_school_id"
            dcp_cost = dcp_year = dcp_comp = dcp_supplier = None

        elif not dcp_components:
            # Item has no DCP component equivalent.
            match_type = "no_component_mapping"
            dcp_cost = dcp_year = dcp_comp = dcp_supplier = None

        else:
            year_int = _dcp_year_from_canonical(dcp_year_pkg) if dcp_year_pkg else None
            match_type, dcp_cost, dcp_year, dcp_comp, dcp_supplier = _resolve_dcp_match(
                school_id,
                year_int,
                acq_date,
                date_received,
                dcp_components,
                dcp_exact,
                dcp_fallback,
            )

        matched_rows.append(
            (
                eq_id,
                school_id,
                item_canonical,
                acq_cost,
                dcp_year_pkg,
                source_acq,
                dcp_cost,
                dcp_year,
                dcp_comp,
                match_type,
                dcp_supplier,
                is_nf,
                disposition,
            )
        )

    conn.executemany(
        "INSERT INTO sample_matched VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        matched_rows,
    )

    type_counts = conn.execute(
        """
        SELECT dcp_match_type, COUNT(*) FROM sample_matched
        GROUP BY dcp_match_type ORDER BY COUNT(*) DESC
        """
    ).fetchall()
    total = sum(c for _, c in type_counts)
    print(f"  sample_matched: {total} rows")
    for mt, cnt in type_counts:
        print(f"    {mt}: {cnt}")


# ── Unit Coverage ────────────────────────────────────────────────────────────


def compute_unit_coverage(conn: sqlite3.Connection) -> None:
    """Populate sample_unit_coverage: expected vs declared units per delivery.

    For each (school, year, DCP-component) in sample_dcp, counts how many
    equipment rows matched specifically to that DCP component. A positive gap
    means the school declared fewer units than DCP records show were delivered.

    When a school receives multiple lots of the same component in the same year
    (different suppliers or prices), expected_units is the SUM across all lots.
    The supplier shown is the one with the highest expected_units for that year.

    Unit coverage is tracked at the DCP-component level (not the equipment
    canonical level) so that "Laptop" and "Host Laptop" deliveries each show
    their own gap. This makes it possible to see whether Host Laptop units are
    specifically being declared.
    """
    dcp_rows = conn.execute(
        """
        SELECT school_id, year, component,
               SUM(expected_units)                                         AS expected,
               supplier
        FROM (
            SELECT school_id, year, component, expected_units, supplier,
                   ROW_NUMBER() OVER (
                       PARTITION BY school_id, year, component
                       ORDER BY expected_units DESC
                   ) AS rn
            FROM sample_dcp
        )
        WHERE rn = 1
        GROUP BY school_id, year, component
        """
    ).fetchall()

    coverage_rows: list[tuple] = []
    for school_id, year, component, expected, supplier in dcp_rows:
        if component not in _DCP_TO_EQUIPMENT:
            # DCP component has no equipment canonical counterpart — skip.
            # These are surfaced in the "Unmapped DCP Components" terminal section.
            continue

        declared = conn.execute(
            """
            SELECT COUNT(*) FROM sample_matched
            WHERE school_id = ?
              AND dcp_year = ?
              AND dcp_component = ?
              AND dcp_match_type IN ('exact', 'inferred')
            """,
            (school_id, year, component),
        ).fetchone()[0]

        gap = expected - declared
        if declared == 0:
            flag = "none_declared"
        elif gap > 0:
            flag = "underdeclared"
        elif gap < 0:
            flag = "overdeclared"
        else:
            flag = "matched"

        coverage_rows.append(
            (school_id, year, component, expected, declared, gap, flag, supplier)
        )

    conn.executemany(
        "INSERT INTO sample_unit_coverage VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        coverage_rows,
    )

    count = len(coverage_rows)
    matched = sum(1 for r in coverage_rows if r[6] == "matched")
    gaps = [r for r in coverage_rows if r[6] != "matched"]
    print(
        f"  sample_unit_coverage: {count} rows ({matched} matched, {len(gaps)} with gaps)"
    )
    for row in sorted(gaps, key=lambda r: -abs(r[5])):
        school_id, year, comp, exp, decl, gap, flag, supplier = row
        print(
            f"    {school_id}/{year}/{comp}: expected={exp} declared={decl} gap={gap:+d} → {flag}  [{supplier}]"
        )


# ── Summary Printing ─────────────────────────────────────────────────────────


def _print_unit_gaps(conn: sqlite3.Connection) -> None:
    """Print missing/underdeclared unit gaps — the primary concern."""
    print("\n── Unit Coverage Gaps (primary concern) ──")
    rows = conn.execute(
        """
        SELECT school_id, dcp_year, dcp_component,
               expected_units, declared_units, unit_gap, coverage_flag, dcp_supplier
        FROM sample_unit_coverage
        WHERE coverage_flag IN ('none_declared', 'underdeclared')
        ORDER BY unit_gap DESC, school_id
        """
    ).fetchall()
    if rows:
        total_missing = sum(r[5] for r in rows)
        print(
            f"  {len(rows)} deliveries with missing units, {total_missing} total units unaccounted for"
        )
        for sid, yr, comp, exp, decl, gap, flag, supplier in rows:
            print(
                f"  {sid}/{yr}/{comp}: expected={exp} declared={decl} missing={gap} → {flag}  [{supplier}]"
            )
    else:
        print("  (none)")


def _print_overdeclared(conn: sqlite3.Connection) -> None:
    """Print overdeclared units — informational only."""
    print("\n── Overdeclared (informational — may be replacements or multi-lot) ──")
    rows = conn.execute(
        """
        SELECT school_id, dcp_year, dcp_component,
               expected_units, declared_units, unit_gap, dcp_supplier
        FROM sample_unit_coverage
        WHERE coverage_flag = 'overdeclared'
        ORDER BY unit_gap, school_id
        """
    ).fetchall()
    if rows:
        for sid, yr, comp, exp, decl, gap, supplier in rows:
            print(
                f"  {sid}/{yr}/{comp}: expected={exp} declared={decl} extra={-gap}  [{supplier}]"
            )
    else:
        print("  (none)")


def _print_unmapped_dcp(conn: sqlite3.Connection) -> None:
    """Print DCP components that have no equipment canonical mapping."""
    print("\n── DCP Components With No Equipment Mapping ──")
    rows = conn.execute(
        """
        SELECT component, SUM(expected_units) AS total_units, COUNT(DISTINCT school_id) AS schools
        FROM sample_dcp
        WHERE component NOT IN (SELECT DISTINCT dcp_component FROM sample_unit_coverage)
        GROUP BY component
        ORDER BY total_units DESC
        """
    ).fetchall()
    if rows:
        for comp, units, schools in rows:
            print(f"  {comp}: {units} units across {schools} schools")
    else:
        print("  (none)")


def _print_unmapped_equipment(conn: sqlite3.Connection) -> None:
    """Print CO equipment items that have no DCP component mapping."""
    print("\n── CO Equipment With No DCP Component Mapping ──")
    rows = conn.execute(
        """
        SELECT item_canonical, COUNT(*) AS cnt
        FROM sample_matched
        WHERE dcp_match_type = 'no_component_mapping'
          AND source_of_acquisition = 'Central Office'
          AND item_canonical IS NOT NULL
        GROUP BY item_canonical
        ORDER BY cnt DESC
        """
    ).fetchall()
    if rows:
        for name, cnt in rows:
            print(f"  {name}: {cnt} rows")
    else:
        print("  (none — mapping complete for CO items)")


def _print_cost_discrepancies(conn: sqlite3.Connection) -> None:
    """Print cost discrepancies for matched rows.

    Declared cost may reflect the property officer's ignorance of the contract
    price rather than deliberate misreporting. Treat as a pattern signal, not
    evidence. Quantity gaps (see _print_unit_gaps) are the primary concern.
    """
    print("\n── Cost Discrepancies (informational) ──")
    rows = conn.execute(
        """
        SELECT school_id, item_canonical, dcp_year,
               declared_cost, dcp_cost,
               ROUND(declared_cost / dcp_cost, 2) AS ratio,
               CASE
                   WHEN declared_cost IS NULL OR declared_cost = 0 THEN 'not_declared'
                   WHEN declared_cost > dcp_cost * 1.2               THEN 'overstated'
                   WHEN declared_cost < dcp_cost * 0.8               THEN 'understated'
               END AS flag
        FROM sample_matched
        WHERE dcp_match_type IN ('exact', 'inferred')
          AND dcp_cost IS NOT NULL
          AND (
              declared_cost IS NULL OR declared_cost = 0
              OR declared_cost > dcp_cost * 1.2
              OR declared_cost < dcp_cost * 0.8
          )
        GROUP BY school_id, item_canonical, dcp_year, flag
        ORDER BY ABS(COALESCE(declared_cost, 0) - dcp_cost) DESC
        """
    ).fetchall()
    if rows:
        for sid, item, dy, dcost, dcp, ratio, flag in rows:
            ratio_str = f"×{ratio}" if ratio is not None else "N/A"
            print(
                f"  {sid} | {item} yr={dy} | declared={dcost} dcp={dcp} ({ratio_str}) → {flag}"
            )
    else:
        print("  (none)")


def print_summary(conn: sqlite3.Connection) -> None:
    """Print all terminal summaries. Unit gaps first, cost last."""
    _print_unit_gaps(conn)
    _print_overdeclared(conn)
    _print_unmapped_dcp(conn)
    _print_unmapped_equipment(conn)
    _print_cost_discrepancies(conn)


# ── Main ─────────────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build DCP prototype inspection database (Phase 1).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--equipment-db",
        type=Path,
        default=Path("artifacts/equipment.db"),
        help="Path to equipment.db (default: artifacts/equipment.db)",
    )
    parser.add_argument(
        "--dcp-dataset-db",
        type=Path,
        default=Path("../deped-dataset/db.sqlite3"),
        help="Path to deped-dataset/db.sqlite3",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/dcp_prototype.db"),
        help="Output prototype database (default: artifacts/dcp_prototype.db)",
    )
    args = parser.parse_args()

    for db_path in (args.equipment_db, args.dcp_dataset_db):
        if not db_path.exists():
            raise FileNotFoundError(f"Database not found: {db_path}")

    if args.output.exists():
        args.output.unlink()

    conn = sqlite3.connect(str(args.output))
    conn.execute("PRAGMA journal_mode=WAL")
    _attach(conn, args.equipment_db, "eq")
    _attach(conn, args.dcp_dataset_db, "ds")

    print("Creating tables...")
    create_tables(conn)

    print("Extracting sample equipment...")
    extract_sample_equipment(conn)

    print("Extracting sample DCP records...")
    extract_sample_dcp(conn)

    print("Matching equipment to DCP...")
    match_equipment(conn)

    print("Computing unit coverage...")
    compute_unit_coverage(conn)

    conn.commit()

    print_summary(conn)

    conn.close()

    db = args.output
    print(f"""
── Done ─────────────────────────────────────────────────────────────────────
{db}

Start with unit coverage (primary concern — quantity):

  sqlite3 -header -column {db} \\
    "SELECT school_id, dcp_year, dcp_component,
            expected_units, declared_units, unit_gap, coverage_flag, dcp_supplier
     FROM sample_unit_coverage
     WHERE coverage_flag IN ('none_declared','underdeclared')
     ORDER BY unit_gap DESC;"

Then inspect matched rows:

  sqlite3 -header -column {db} \\
    "SELECT school_id, item_canonical, dcp_year, dcp_component,
            declared_cost, dcp_cost, dcp_match_type, dcp_supplier
     FROM sample_matched
     WHERE dcp_match_type IN ('exact','inferred')
     ORDER BY school_id, dcp_year;"

Match type distribution:

  sqlite3 -header -column {db} \\
    "SELECT dcp_match_type, COUNT(*) AS cnt
     FROM sample_matched
     GROUP BY dcp_match_type ORDER BY cnt DESC;"

See docs/dcp-cross-validation.md for full query reference and Phase 2 plan.
""")


if __name__ == "__main__":
    main()
