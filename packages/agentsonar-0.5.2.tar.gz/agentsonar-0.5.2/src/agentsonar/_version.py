"""Single source of truth for the AgentSonar version.

Both `agentsonar/__init__.py` and `agentsonar._core.engine` import from
here, so version bumps only need to land in one place. Keeps the
version-sync regression we hit at 0.3.0 from happening again.

When releasing:
    1. Bump __version__ here
    2. Bump version in pyproject.toml to match
    3. (No other places to edit.)
"""
from __future__ import annotations

__version__ = "0.5.2"
