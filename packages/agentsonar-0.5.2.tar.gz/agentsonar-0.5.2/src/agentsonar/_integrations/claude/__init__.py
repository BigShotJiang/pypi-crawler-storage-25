"""Claude Code adapter package.

Public surface for the Claude Code integration. The implementation
lives in `adapter.py` (hook handling, metadata extraction, edge
translation) and `installer.py` (.claude/settings.json writer).
"""
from agentsonar._integrations.claude.adapter import (
    ENV_ARCHIVE_RETENTION_DAYS,
    ENV_INACTIVITY_SECONDS,
    ENV_LOCK_TIMEOUT_SECONDS,
    ENV_REGULATED,
    ENV_ROOT_DIR,
    TIMELINE_SCHEMA_VERSION,
    derive_source_agent,
    derive_target_agent,
    extract_metadata,
    handle_hook,
    resolve_root_session_id,
    run_hook,
)
from agentsonar._integrations.claude.installer import install

__all__ = [
    "handle_hook",
    "run_hook",
    "extract_metadata",
    "derive_source_agent",
    "derive_target_agent",
    "resolve_root_session_id",
    "install",
    "ENV_REGULATED",
    "ENV_ROOT_DIR",
    "ENV_INACTIVITY_SECONDS",
    "ENV_LOCK_TIMEOUT_SECONDS",
    "ENV_ARCHIVE_RETENTION_DAYS",
    "TIMELINE_SCHEMA_VERSION",
]
