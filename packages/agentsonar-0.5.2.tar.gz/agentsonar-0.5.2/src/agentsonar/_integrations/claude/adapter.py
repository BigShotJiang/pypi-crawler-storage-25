"""
Claude Code adapter, hook-driven integration with Anthropic's terminal
coding agent.

Wire AgentSonar into Claude Code by pasting the hooks block from
`settings.json` into `.claude/settings.json`. Every tool call fires
`python -m agentsonar claude-code-hook <event>`, which records
content-blind metadata, runs detection, and exits 0 (or 2 on a
Prevent Mode trip).

Public surface:
    run_hook(event_name, stdin=sys.stdin) -> int
    handle_hook(event_name, payload) -> int
    extract_metadata(payload, hook_arrival_ts) -> dict
    derive_source_agent(payload) -> str
    derive_target_agent(tool_name, metadata) -> str
    resolve_root_session_id(payload) -> str

Host-safety: every public entry point returns 0 on internal failure.
Only code 2 from a deliberate Prevent Mode trip is non-zero.
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import pickle
import shutil
import sys
import time
import uuid
from pathlib import Path
from typing import Any

from agentsonar._core._content_blind import (
    ENV_REGULATED,
    derive_status,
    fingerprint_input,
    maybe_redact_path,
    safe_int,
    safe_size_bytes,
    safe_str,
    safe_str_or_none,
)
from agentsonar._core._persistence import (
    atomic_write_bytes,
    atomic_write_text,
    file_lock,
)
from agentsonar._core.models import InteractionEvent, PreventError
from agentsonar._integrations._safe_engine import build_engine_safely
from agentsonar._telemetry import session_start
from agentsonar._version import __version__

logger = logging.getLogger("agentsonar.claude_code")


# Locked at first release. Treat as protocol: future versions may add
# optional fields; never remove or rename.
TIMELINE_SCHEMA_VERSION = "1.0.0"

_KNOWN_HOOK_EVENTS = frozenset({
    "PreToolUse",
    "PostToolUse",
    "Stop",
    "SubagentStop",
    "UserPromptSubmit",
    "Notification",
})

_PATH_BEARING_TOOLS = frozenset({
    "Read", "Edit", "Write", "MultiEdit", "NotebookEdit",
    "Grep", "Glob",
})

_DEFAULT_ROOT_DIR = Path.home() / ".agentsonar"
_DEFAULT_INACTIVITY_SECONDS = 24 * 60 * 60
# 30s, not 2s: a cold Claude Code hook subprocess takes ~500ms to
# import the engine module on Windows. N parallel hooks serializing
# through the per-tree lock need N * 500ms in the worst case. 30s
# absorbs ~60 parallel hooks before any drop, vs ~4 at 2s.
_DEFAULT_LOCK_TIMEOUT_SECONDS = 30.0
_DEFAULT_ARCHIVE_RETENTION_DAYS = 90

ENV_ROOT_DIR = "AGENTSONAR_CLAUDE_CODE_ROOT"
ENV_INACTIVITY_SECONDS = "AGENTSONAR_INACTIVITY_SECONDS"
ENV_LOCK_TIMEOUT_SECONDS = "AGENTSONAR_LOCK_TIMEOUT_SECONDS"
ENV_ARCHIVE_RETENTION_DAYS = "AGENTSONAR_ARCHIVE_RETENTION_DAYS"

_ADAPTER_LABEL = "claude_code"

# Disable the engine's built-in console + file output; we emit our own
# one-line stderr summary plus a dedicated timeline writer under
# ~/.agentsonar/sessions/.
_DEFAULT_ENGINE_CONFIG: dict = {
    "console_output": False,
    "file_output": False,
}


def _env_float(name: str, default: float) -> float:
    try:
        raw = os.environ.get(name)
        if raw is None or raw.strip() == "":
            return default
        return float(raw)
    except Exception:
        return default


def _env_int(name: str, default: int) -> int:
    try:
        raw = os.environ.get(name)
        if raw is None or raw.strip() == "":
            return default
        return int(raw)
    except Exception:
        return default


def _root_dir() -> Path:
    try:
        override = os.environ.get(ENV_ROOT_DIR)
        if override and override.strip():
            return Path(override.strip())
    except Exception:
        pass
    return _DEFAULT_ROOT_DIR


def _hash_subagent_type(subagent_type: Any, length: int = 16) -> str | None:
    """Hash the user-chosen subagent_type label so it never lands cleartext."""
    if subagent_type is None:
        return None
    try:
        s = str(subagent_type)
        if not s:
            return None
        return hashlib.sha256(s.encode("utf-8")).hexdigest()[:length]
    except Exception:
        return None


def _extract_target_path(tool_name: str, tool_input: Any) -> str | None:
    if tool_name not in _PATH_BEARING_TOOLS:
        return None
    if not isinstance(tool_input, dict):
        return None
    raw = tool_input.get("file_path")
    if raw is None:
        raw = tool_input.get("path")
    if raw is None:
        return None
    try:
        return str(raw)
    except Exception:
        return None


def _is_mcp_tool(tool_name: str) -> bool:
    try:
        return tool_name.startswith("mcp__")
    except Exception:
        return False


def _mcp_server_name(tool_name: str) -> str | None:
    """Parse `mcp__<server>__<tool>` -> server. Adapter-specific:
    the `mcp__<server>__<tool>` convention is Claude Code's; other
    MCP-aware adapters may use different shapes."""
    if not _is_mcp_tool(tool_name):
        return None
    try:
        parts = tool_name.split("__")
        if len(parts) >= 2:
            return parts[1] or None
    except Exception:
        pass
    return None


def _mcp_tool_name(tool_name: str) -> str | None:
    if not _is_mcp_tool(tool_name):
        return None
    try:
        parts = tool_name.split("__", 2)
        if len(parts) >= 3:
            return parts[2] or None
    except Exception:
        pass
    return None


def extract_metadata(payload: dict, hook_arrival_ts: float) -> dict:
    """Apply the content-blind allowlist to a hook payload.

    Allowed: tool_name, input/output fingerprints + sizes, status,
    session ids, subagent depth + hashed type, cwd, timestamp, and
    target_path (clear by default, hashed under AGENTSONAR_REGULATED).
    MCP-naming-convention tools also get mcp_server and mcp_tool
    (the `<server>` and `<tool>` segments of `mcp__<server>__<tool>`).

    Forbidden: tool input content, tool output bodies, user prompts,
    file contents. Never extracted, never logged, never persisted.
    """
    if not isinstance(payload, dict):
        payload = {}

    tool_name = safe_str(payload.get("tool_name"), default="unknown")
    tool_input = payload.get("tool_input")
    tool_response = payload.get("tool_response")

    target_path_raw = _extract_target_path(tool_name, tool_input)
    target_path = maybe_redact_path(target_path_raw)

    subagent_type_raw = None
    if isinstance(tool_input, dict):
        subagent_type_raw = tool_input.get("subagent_type")
    if subagent_type_raw is None:
        subagent_type_raw = payload.get("subagent_type")

    metadata: dict = {
        "tool_name": tool_name,
        "input_fingerprint": fingerprint_input(tool_input),
        "input_size_bytes": safe_size_bytes(tool_input),
        "output_size_bytes": safe_size_bytes(tool_response),
        "status": derive_status(tool_response),
        "session_id": safe_str(payload.get("session_id"), default="unknown"),
        "parent_session_id": safe_str_or_none(payload.get("parent_session_id")),
        "subagent_depth": safe_int(payload.get("subagent_depth"), default=0),
        "subagent_type": _hash_subagent_type(subagent_type_raw),
        "cwd": safe_str_or_none(payload.get("cwd")),
        "timestamp": float(hook_arrival_ts),
        "target_path": target_path,
    }

    if _is_mcp_tool(tool_name):
        server = _mcp_server_name(tool_name)
        if server:
            metadata["mcp_server"] = server
        tool = _mcp_tool_name(tool_name)
        if tool:
            metadata["mcp_tool"] = tool

    return metadata


def derive_source_agent(payload: dict) -> str:
    """`main` for root sessions, `subagent_<task_id>` for spawned ones.
    Per-instance (not per-type) so two parallel subagents of the same
    type produce distinct source_agent values."""
    if not isinstance(payload, dict):
        return "main"
    parent = payload.get("parent_session_id")
    if parent is None:
        return "main"
    sid = safe_str(payload.get("session_id"), default="")
    task_id = sid[:8] if sid else "00000000"
    return f"subagent_{task_id}"


def derive_target_agent(tool_name: str, metadata: dict) -> str:
    """Target depends on the tool kind.

    Path-bearing tools (Read, Edit, Write, Grep, etc.): the file path
    directly so the edge is readable. AGENTSONAR_REGULATED already
    swaps in `path:<8hex>` upstream.

    Task: `Task_spawn:<subagent_type[:8]>` (or fingerprint when no
    subagent_type). Per-type aggregation catches subagent explosion.

    Everything else (Bash, MCP, WebFetch): `<tool_name>:<fp[:8]>`.
    The fingerprint is the only stable structural identifier when
    content is content-blind.
    """
    if tool_name == "Task":
        st = metadata.get("subagent_type")
        if isinstance(st, str) and st:
            return f"Task_spawn:{st[:8]}"
        fp = safe_str(metadata.get("input_fingerprint"), default="00000000")[:8]
        return f"Task_spawn:{fp}"

    target_path = metadata.get("target_path")
    if target_path:
        return f"{tool_name}:{target_path}"

    fp = safe_str(metadata.get("input_fingerprint"), default="00000000")[:8]
    return f"{tool_name}:{fp}"


# Engine state snapshot: DetectionEngine carries a threading.Lock and
# possibly logger handles, neither picklable. We snapshot the picklable
# attributes; on load we build a fresh engine (fresh lock + logger)
# and overlay the saved attributes onto its __dict__.


def _picklable_engine_dict(engine: Any) -> dict:
    _SKIP = ("_lock", "logger", "_logger")
    try:
        candidate = {
            k: v for k, v in engine.__dict__.items() if k not in _SKIP
        }
    except Exception:
        return {}
    try:
        pickle.dumps(candidate, protocol=pickle.DEFAULT_PROTOCOL)
        return candidate
    except Exception:
        pass
    out: dict[str, Any] = {}
    for key, value in candidate.items():
        try:
            pickle.dumps(value, protocol=pickle.DEFAULT_PROTOCOL)
        except Exception:
            continue
        out[key] = value
    return out


def _engine_state_snapshot(engine: Any) -> dict:
    try:
        snapshot = _picklable_engine_dict(engine)
        engine_dict_bytes = pickle.dumps(snapshot, protocol=pickle.DEFAULT_PROTOCOL)
    except Exception:
        engine_dict_bytes = b""
    return {
        "schema_version": TIMELINE_SCHEMA_VERSION,
        "engine_dict_bytes": engine_dict_bytes,
        "created_at": time.time(),
    }


def _load_or_build_engine(state_path: Path, config: dict) -> Any:
    """Build a fresh engine then overlay saved attributes if any.
    Missing file, empty blob, corrupt pickle, garbage shape: all
    degrade to the fresh engine."""
    engine = build_engine_safely(config, adapter=_ADAPTER_LABEL)
    if not state_path.exists():
        return engine
    try:
        with open(state_path, "rb") as f:
            blob = pickle.load(f)
        if not isinstance(blob, dict):
            return engine
        engine_dict_bytes = blob.get("engine_dict_bytes")
        if not engine_dict_bytes:
            return engine
        try:
            saved_dict = pickle.loads(engine_dict_bytes)
        except Exception:
            logger.debug("corrupt engine snapshot at %s", state_path, exc_info=True)
            return engine
        if not isinstance(saved_dict, dict):
            return engine
        try:
            for key, value in saved_dict.items():
                try:
                    engine.__dict__[key] = value
                except Exception:
                    continue
        except Exception:
            return build_engine_safely(config, adapter=_ADAPTER_LABEL)
        return engine
    except Exception:
        logger.debug("could not load state from %s", state_path, exc_info=True)
        return engine


def _save_engine_state(state_path: Path, engine: Any) -> None:
    try:
        snapshot = _engine_state_snapshot(engine)
        atomic_write_bytes(
            state_path,
            pickle.dumps(snapshot, protocol=pickle.DEFAULT_PROTOCOL),
        )
    except Exception:
        logger.debug("could not save state to %s", state_path, exc_info=True)


def _timeline_record(
    event_name: str,
    payload: dict,
    metadata: dict,
    source_agent: str,
    target_agent: str,
    hook_arrival_ts: float,
    *,
    root_session_id: str,
    detector_alerts: list | None = None,
    prevented: bool = False,
) -> dict:
    """Build one timeline.jsonl record. Field set locked at
    TIMELINE_SCHEMA_VERSION = "1.0.0"; future versions add optional
    fields, never remove or rename."""
    return {
        "schema_version": TIMELINE_SCHEMA_VERSION,
        "event_id": uuid.uuid4().hex,
        "event_name": safe_str(event_name, default="unknown"),
        "root_session_id": root_session_id,
        "source_session_id": safe_str(
            payload.get("session_id") if isinstance(payload, dict) else None,
            default="unknown",
        ),
        "source_agent": source_agent,
        "target_agent": target_agent,
        "timestamp": float(hook_arrival_ts),
        "metadata": metadata,
        "alerts": _summarize_alerts(detector_alerts or []),
        "prevented": bool(prevented),
    }


def _summarize_alerts(alerts: list) -> list[dict]:
    """Pull structural fields off Alert objects. Drop anything that
    could carry user content."""
    out: list[dict] = []
    if not alerts:
        return out
    _SAFE_DETAIL_KEYS = (
        "rotations", "cycle_path", "weight", "events",
        "trigger", "threshold", "limit", "rate", "window",
        "fingerprint", "agents_involved", "edge_count",
    )
    for alert in alerts:
        try:
            entry = {
                "pattern": safe_str(getattr(alert, "pattern", None), default="unknown"),
                "severity": safe_str(getattr(alert, "severity", None), default="INFO"),
            }
            details = getattr(alert, "details", None)
            if isinstance(details, dict):
                entry["details"] = {
                    k: details[k] for k in _SAFE_DETAIL_KEYS if k in details
                }
            out.append(entry)
        except Exception:
            continue
    return out


def _append_timeline(timeline_path: Path, record: dict) -> None:
    """Append one JSON line. Binary mode keeps LF a single byte on
    Windows; text mode's CRLF translation breaks strict JSONL parsers."""
    try:
        if not timeline_path.parent.exists():
            timeline_path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(
            record,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
            allow_nan=False,
            ensure_ascii=False,
        )
        with open(timeline_path, "ab") as f:
            f.write(line.encode("utf-8"))
            f.write(b"\n")
    except Exception:
        logger.debug("timeline append failed at %s", timeline_path, exc_info=True)


def _load_subagent_types(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return {
                str(k): str(v)
                for k, v in data.items()
                if k is not None and v is not None
            }
    except Exception:
        logger.debug("could not load subagent types at %s", path, exc_info=True)
    return {}


def _save_subagent_types(path: Path, types_map: dict[str, str]) -> None:
    try:
        atomic_write_text(path, json.dumps(types_map, sort_keys=True, indent=2))
    except Exception:
        logger.debug("could not save subagent types at %s", path, exc_info=True)


def _register_subagent_type_if_task(
    payload: dict,
    event_name: str,
    types_path: Path,
) -> None:
    """On Task PostToolUse, record spawned_session_id -> hashed_type."""
    if event_name != "PostToolUse":
        return
    if not isinstance(payload, dict):
        return
    if safe_str(payload.get("tool_name")) != "Task":
        return
    response = payload.get("tool_response")
    if not isinstance(response, dict):
        return
    spawned_sid = None
    for key in ("session_id", "subagent_session_id", "spawned_session_id"):
        candidate = response.get(key)
        if candidate:
            spawned_sid = safe_str(candidate)
            break
    if not spawned_sid:
        return
    tool_input = payload.get("tool_input")
    subagent_type_raw = None
    if isinstance(tool_input, dict):
        subagent_type_raw = tool_input.get("subagent_type")
    type_hash = _hash_subagent_type(subagent_type_raw)
    if not type_hash:
        return
    try:
        existing = _load_subagent_types(types_path)
        existing[spawned_sid] = type_hash
        _save_subagent_types(types_path, existing)
    except Exception:
        logger.debug("failed to register subagent type", exc_info=True)


def resolve_root_session_id(payload: dict) -> str:
    """Walk parent_session_id to the root. Phase 1 assumes one-hop;
    deeper subagent nesting needs a persistent parent map (Phase 4+)."""
    if not isinstance(payload, dict):
        return "unknown"
    parent = payload.get("parent_session_id")
    if parent is None or safe_str(parent) == "":
        return safe_str(payload.get("session_id"), default="unknown")
    return safe_str(parent)


def _session_dir(root: Path, root_session_id: str) -> Path:
    return root / "sessions" / root_session_id


def _reports_dir(root: Path, root_session_id: str) -> Path:
    return root / "reports" / root_session_id


def _archived_dir(root: Path) -> Path:
    return root / "sessions" / "archived"


def _touch_last_hook_at(session_dir: Path) -> None:
    try:
        with open(session_dir / "last_hook_at", "wb") as f:
            f.write(str(time.time()).encode("utf-8"))
    except Exception:
        pass


def _read_last_hook_at(session_dir: Path) -> float:
    p = session_dir / "last_hook_at"
    if not p.exists():
        return 0.0
    try:
        return float(p.read_text(encoding="utf-8").strip())
    except Exception:
        return 0.0


def _archive_session_tree(root: Path, root_session_id: str) -> None:
    src = _session_dir(root, root_session_id)
    if not src.exists():
        return
    dst_parent = _archived_dir(root)
    dst = dst_parent / root_session_id
    try:
        dst_parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            return
        shutil.move(str(src), str(dst))
    except Exception:
        logger.debug("archive of %s failed", root_session_id, exc_info=True)


def _inactivity_sweep(root: Path, current_root_session_id: str) -> None:
    """Archive every session tree idle longer than the inactivity threshold."""
    threshold = _env_float(ENV_INACTIVITY_SECONDS, _DEFAULT_INACTIVITY_SECONDS)
    sessions_root = root / "sessions"
    if not sessions_root.exists():
        return
    now = time.time()
    try:
        for entry in sessions_root.iterdir():
            if not entry.is_dir():
                continue
            if entry.name == "archived":
                continue
            if entry.name == current_root_session_id:
                continue
            last = _read_last_hook_at(entry)
            if last == 0.0:
                continue
            if now - last > threshold:
                _archive_session_tree(root, entry.name)
    except Exception:
        logger.debug("inactivity sweep failed", exc_info=True)


# Cumulative report regeneration runs on every root-session Stop.
# Builds report.html / report.json / alerts.log from the bounded engine
# state. Does NOT touch timeline.jsonl (append-only during ingest) and
# does NOT call engine.shutdown (state must survive across turns).


def _enum_display(value: Any, default: str = "unknown") -> str:
    """Render an enum-or-string value as a clean name. `str(SomeEnum.MEMBER)`
    returns "SomeEnum.MEMBER" which leaks the class name into alerts.log."""
    if value is None:
        return default
    try:
        v = getattr(value, "value", None)
        if isinstance(v, str) and v:
            return v
        name = getattr(value, "name", None)
        if isinstance(name, str) and name:
            return name
    except Exception:
        pass
    try:
        return str(value)
    except Exception:
        return default


def _format_alerts_log(events: list) -> str:
    lines: list[str] = []
    for ev in events:
        try:
            ts = getattr(ev, "timestamp", None)
            if isinstance(ts, (int, float)):
                ts_str = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(float(ts))) + "Z"
            else:
                ts_str = "unknown-time"
            severity = _enum_display(getattr(ev, "severity", None), default="INFO").upper()
            failure_class = _enum_display(getattr(ev, "failure_class", None), default="unknown")
            summary = safe_str(getattr(ev, "summary", None), default="")
            lines.append(f"{ts_str}  {severity:<8}  {failure_class}  {summary}")
        except Exception:
            continue
    if not lines:
        lines.append(
            time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            + "  INFO      session_checkpoint  no coordination failures detected"
        )
    return "\n".join(lines) + "\n"


def _regenerate_reports(engine: Any, reports_dir: Path) -> None:
    try:
        events = list(engine.get_recent_events())
    except Exception:
        events = []

    edge_activity = None
    try:
        graph = getattr(engine, "coord_graph", None)
        if graph is not None:
            summary_method = getattr(graph, "edge_activity_summary", None)
            if callable(summary_method):
                edge_activity = list(summary_method())
    except Exception:
        edge_activity = None

    session_log = None
    session_log_total = None
    try:
        sl = getattr(engine, "_session_log", None)
        if isinstance(sl, list):
            session_log = list(sl)
        sl_total = getattr(engine, "_session_log_total", None)
        if isinstance(sl_total, int):
            session_log_total = sl_total
    except Exception:
        session_log = None
        session_log_total = None

    reports_dir.mkdir(parents=True, exist_ok=True)

    # Lazy imports: the HTML renderer is heavy and shouldn't land on
    # the hot path of PreToolUse / PostToolUse hooks.
    try:
        from agentsonar._output.json_export import events_to_json
        atomic_write_text(reports_dir / "report.json", events_to_json(events, dedupe=True))
    except Exception:
        logger.debug("report.json regen failed", exc_info=True)

    try:
        from agentsonar._output.html_report import events_to_html
        html_text = events_to_html(
            events,
            title="AgentSonar Claude Code Report",
            dedupe=True,
            edge_activity=edge_activity,
            session_log=session_log,
            session_log_total=session_log_total,
        )
        atomic_write_text(reports_dir / "report.html", html_text)
    except Exception:
        logger.debug("report.html regen failed", exc_info=True)

    try:
        atomic_write_text(reports_dir / "alerts.log", _format_alerts_log(events))
    except Exception:
        logger.debug("alerts.log regen failed", exc_info=True)


def _update_latest_pointer(root: Path, root_session_id: str) -> None:
    try:
        reports_root = root / "reports"
        reports_root.mkdir(parents=True, exist_ok=True)
        atomic_write_text(reports_root / "latest", root_session_id)
    except Exception:
        pass


def _print_stop_summary(events: list, report_path: Path) -> None:
    """One-line stderr summary. No cost number (FinOps is later)."""
    try:
        count = 0
        seen_fingerprints: set[str] = set()
        for ev in events:
            try:
                severity = _enum_display(getattr(ev, "severity", None)).upper()
                if severity not in ("WARNING", "CRITICAL"):
                    continue
                fp = safe_str(getattr(ev, "coordination_fingerprint", None))
                if fp and fp in seen_fingerprints:
                    continue
                if fp:
                    seen_fingerprints.add(fp)
                count += 1
            except Exception:
                continue

        if count == 0:
            line = "AgentSonar: session checkpoint, 0 coordination patterns detected."
        else:
            label = "pattern" if count == 1 else "patterns"
            line = f"AgentSonar: detected {count} coordination {label}."
        print(line, file=sys.stderr)
        print(f"  See {report_path} for details.", file=sys.stderr)
    except Exception:
        pass


def _fire_session_start_if_first(session_dir: Path) -> None:
    """Fire telemetry once per session tree; marker prevents re-fires."""
    marker = session_dir / "telemetry_fired"
    if marker.exists():
        return
    try:
        session_start(adapter=_ADAPTER_LABEL, version=__version__)
    except Exception:
        pass
    try:
        session_dir.mkdir(parents=True, exist_ok=True)
        atomic_write_text(marker, str(time.time()))
    except Exception:
        pass


def handle_hook(event_name: str, payload: Any) -> int:
    """Dispatch one hook. Returns 0 (proceed), 2 (Prevent trip), or 0
    on any internal failure (host-safety contract)."""
    hook_arrival_ts = time.time()

    try:
        event_name = safe_str(event_name, default="unknown")
        if event_name not in _KNOWN_HOOK_EVENTS:
            logger.debug("unknown hook event %r; ignoring", event_name)
            return 0

        if event_name in ("UserPromptSubmit", "Notification"):
            return 0

        if not isinstance(payload, dict):
            logger.debug("payload not dict (%s); ignoring", type(payload).__name__)
            return 0

        root = _root_dir()
        root_session_id = resolve_root_session_id(payload)

        _inactivity_sweep(root, root_session_id)

        session_dir = _session_dir(root, root_session_id)
        session_dir.mkdir(parents=True, exist_ok=True)

        _fire_session_start_if_first(session_dir)

        lock_path = session_dir / "lock"
        state_path = session_dir / "state.pkl"
        timeline_path = session_dir / "timeline.jsonl"
        types_path = session_dir / "subagent_types.json"

        lock_timeout = _env_float(
            ENV_LOCK_TIMEOUT_SECONDS,
            _DEFAULT_LOCK_TIMEOUT_SECONDS,
        )

        try:
            with file_lock(lock_path, timeout=lock_timeout):
                return _handle_hook_locked(
                    event_name=event_name,
                    payload=payload,
                    root=root,
                    root_session_id=root_session_id,
                    session_dir=session_dir,
                    state_path=state_path,
                    timeline_path=timeline_path,
                    types_path=types_path,
                    hook_arrival_ts=hook_arrival_ts,
                )
        except TimeoutError:
            logger.debug(
                "lock contention exceeded %ss; dropping event %s",
                lock_timeout,
                event_name,
            )
            return 0

    except SystemExit:
        raise
    except Exception:
        try:
            logger.debug(
                "handle_hook (%s) raised; returning 0 per host-safety contract",
                event_name,
                exc_info=True,
            )
        except Exception:
            pass
        return 0


def _handle_hook_locked(
    *,
    event_name: str,
    payload: dict,
    root: Path,
    root_session_id: str,
    session_dir: Path,
    state_path: Path,
    timeline_path: Path,
    types_path: Path,
    hook_arrival_ts: float,
) -> int:
    metadata = extract_metadata(payload, hook_arrival_ts)
    source_agent = derive_source_agent(payload)
    tool_name = safe_str(metadata.get("tool_name"), default="unknown")
    target_agent = derive_target_agent(tool_name, metadata)

    # Stop / SubagentStop synthesize a terminal session_exit edge so
    # tree-level views see the close. Fixed sentinel; not a tool.
    if event_name in ("Stop", "SubagentStop"):
        target_agent = "session_exit"

    engine = _load_or_build_engine(state_path, dict(_DEFAULT_ENGINE_CONFIG))

    # Registry update runs even if engine ingest fails so the
    # subagent_types map stays in sync with reality.
    _register_subagent_type_if_task(payload, event_name, types_path)

    detector_alerts: list = []
    prevented = False

    try:
        event = InteractionEvent(
            source_agent=source_agent,
            target_agent=target_agent,
            timestamp=float(hook_arrival_ts),
            metadata=dict(metadata),
        )
        try:
            alerts = engine.ingest(event)
            if isinstance(alerts, list):
                detector_alerts = alerts
        except Exception:
            logger.debug("engine.ingest raised; keeping timeline", exc_info=True)
    except Exception:
        logger.debug("could not build InteractionEvent", exc_info=True)

    # Prevent Mode only on PreToolUse. PreventError -> exit 2
    # (Claude Code's "block this tool call" signal).
    if event_name == "PreToolUse":
        try:
            check = getattr(engine, "check_prevent", None)
            if callable(check):
                check()
        except PreventError as exc:
            prevented = True
            try:
                reason = safe_str(getattr(exc, "reason", None), default="prevent triggered")
                print(
                    f"AgentSonar: blocking tool call ({reason}).",
                    file=sys.stderr,
                )
                print(
                    "  Open ~/.agentsonar/reports/latest for the full report.",
                    file=sys.stderr,
                )
            except Exception:
                pass
        except Exception:
            logger.debug("check_prevent raised non-PreventError; ignoring", exc_info=True)

    record = _timeline_record(
        event_name=event_name,
        payload=payload,
        metadata=metadata,
        source_agent=source_agent,
        target_agent=target_agent,
        hook_arrival_ts=hook_arrival_ts,
        root_session_id=root_session_id,
        detector_alerts=detector_alerts,
        prevented=prevented,
    )
    _append_timeline(timeline_path, record)

    _save_engine_state(state_path, engine)

    _touch_last_hook_at(session_dir)

    # Root-session Stop regenerates the cumulative report. Subagent
    # Stops close their slice; the report belongs to the root.
    if event_name == "Stop":
        is_root_session = (
            safe_str(payload.get("parent_session_id"), default="") == ""
        )
        if is_root_session:
            reports_dir = _reports_dir(root, root_session_id)
            _regenerate_reports(engine, reports_dir)
            _update_latest_pointer(root, root_session_id)
            try:
                events_for_summary = list(engine.get_recent_events())
            except Exception:
                events_for_summary = []
            _print_stop_summary(
                events_for_summary,
                reports_dir / "report.html",
            )

    if prevented:
        return 2
    return 0


def run_hook(event_name: str, stdin: io.TextIOBase | None = None) -> int:
    """Read JSON payload from stdin and dispatch to handle_hook.
    Returns the exit code per handle_hook's contract; never raises."""
    try:
        source = stdin if stdin is not None else sys.stdin
        try:
            raw = source.read()
        except Exception:
            raw = ""
        try:
            payload = json.loads(raw) if raw else {}
        except Exception:
            logger.debug("malformed JSON on stdin; dropping event", exc_info=True)
            payload = {}
        return handle_hook(event_name, payload)
    except Exception:
        try:
            logger.debug("run_hook raised; returning 0", exc_info=True)
        except Exception:
            pass
        return 0


__all__ = [
    "handle_hook",
    "run_hook",
    "extract_metadata",
    "derive_source_agent",
    "derive_target_agent",
    "resolve_root_session_id",
    "ENV_REGULATED",
    "ENV_ROOT_DIR",
    "ENV_INACTIVITY_SECONDS",
    "ENV_LOCK_TIMEOUT_SECONDS",
    "ENV_ARCHIVE_RETENTION_DAYS",
    "TIMELINE_SCHEMA_VERSION",
]
