"""
Standalone sanity-check / bug-hunt script. NOT part of pytest. Run
directly to exercise the adapter end-to-end across paths the unit
tests don't cover:

  1. Cross-process file lock under real parallel subprocesses.
  2. timeline.jsonl line endings (LF, not CRLF).
  3. Settings template JSON validity + structure.
  4. Pickle round-trip preserves Prevent Mode tracked state.
  5. Empty events report.html rendering.
  6. Subprocess CLI invocation end to end with stdin JSON.
  7. Payload corner cases (missing fields, weird types).
  8. Long session ids on Windows.
  9. Concurrent first-hook race.
 10. Symbol audit (unused imports).
"""
from __future__ import annotations

import json
import os
import pickle
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
VENV_PY = REPO / ".venv" / "Scripts" / "python.exe"
if not VENV_PY.exists():
    VENV_PY = REPO / ".venv" / "bin" / "python"


def banner(n: int, name: str) -> None:
    print(f"\n=== TEST {n}: {name} ===")


def run_hook_subprocess(event: str, payload: dict, env: dict) -> tuple[int, str, str]:
    """Spawn a real subprocess invoking the CLI hook and pipe payload JSON to stdin."""
    proc = subprocess.run(
        [str(VENV_PY), "-m", "agentsonar", "claude-code-hook", event],
        input=json.dumps(payload),
        capture_output=True,
        text=True,
        env=env,
        cwd=str(REPO),
    )
    return proc.returncode, proc.stdout, proc.stderr


def test_1_cross_process_lock() -> None:
    banner(1, "cross-process file lock under parallel subprocesses")
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"

    sid = f"xproc-{os.getpid()}"
    n_processes = 5
    payloads = [
        {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": f"/x/{i}.py"},
            "cwd": "/home/test",
        }
        for i in range(n_processes)
    ]

    procs = []
    for p in payloads:
        proc = subprocess.Popen(
            [str(VENV_PY), "-m", "agentsonar", "claude-code-hook", "PreToolUse"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            cwd=str(REPO),
            text=True,
        )
        proc.stdin.write(json.dumps(p))
        proc.stdin.close()
        procs.append(proc)

    exit_codes = [p.wait() for p in procs]
    print(f"exit codes: {exit_codes}")

    timeline = tmp / "sessions" / sid / "timeline.jsonl"
    state = tmp / "sessions" / sid / "state.pkl"
    assert timeline.exists(), f"FAIL: timeline missing at {timeline}"
    assert state.exists(), f"FAIL: state.pkl missing at {state}"

    lines = [line for line in timeline.read_text(encoding="utf-8").splitlines() if line.strip()]
    print(f"expected lines: {n_processes}, actual: {len(lines)}")
    assert len(lines) == n_processes, f"FAIL: expected {n_processes} lines, got {len(lines)}"

    for i, line in enumerate(lines):
        try:
            rec = json.loads(line)
        except Exception as exc:
            print(f"FAIL: line {i} not valid JSON: {exc}")
            print(f"  line: {line!r}")
            raise
        assert rec["schema_version"] == "1.0.0"
        assert rec["root_session_id"] == sid

    state_blob = pickle.load(open(state, "rb"))
    assert isinstance(state_blob, dict)
    assert state_blob["schema_version"] == "1.0.0"
    print(f"state.pkl parseable, size={state.stat().st_size} bytes")
    print("PASS")


def test_2_line_endings() -> None:
    banner(2, "timeline.jsonl line endings (LF, not CRLF)")
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"

    sid = "lf-check"
    for i in range(3):
        run_hook_subprocess(
            "PreToolUse",
            {"session_id": sid, "parent_session_id": None, "tool_name": "Read", "tool_input": {"file_path": f"/x/{i}.py"}},
            env,
        )

    timeline = tmp / "sessions" / sid / "timeline.jsonl"
    raw = timeline.read_bytes()
    crlf_count = raw.count(b"\r\n")
    lone_lf_count = raw.count(b"\n") - crlf_count

    print(f"CRLF count: {crlf_count}, lone LF count: {lone_lf_count}")
    if crlf_count > 0:
        print("FAIL: timeline.jsonl contains CRLF; naive JSONL readers will choke on Windows")
        raise AssertionError("CRLF in timeline.jsonl")
    if lone_lf_count != 3:
        print(f"FAIL: expected exactly 3 LF separators, got {lone_lf_count}")
        raise AssertionError("wrong LF count")
    print("PASS")


def test_3_settings_template() -> None:
    banner(3, "settings.json template JSON validity")
    template = REPO / "src" / "agentsonar" / "_integrations" / "claude" / "settings.json"
    assert template.exists(), f"FAIL: template not at {template}"

    raw = template.read_text(encoding="utf-8")
    try:
        data = json.loads(raw)
    except Exception as exc:
        print(f"FAIL: not valid JSON: {exc}")
        raise

    assert "hooks" in data, "FAIL: no top-level 'hooks' key"
    hooks = data["hooks"]
    for event in ("PreToolUse", "PostToolUse", "Stop", "SubagentStop"):
        assert event in hooks, f"FAIL: missing event {event}"
        entries = hooks[event]
        assert isinstance(entries, list) and entries, f"FAIL: empty entries for {event}"
        for entry in entries:
            for inner in entry.get("hooks", []):
                assert inner.get("type") == "command", f"FAIL: bad hook type in {event}"
                assert "command" in inner, f"FAIL: missing command in {event}"
                # 0.5.2+ template uses `python -m agentsonar claude-code-hook ...`
                # (cross-shell PATH portable). Accept both forms during the
                # transition; once all distributors update, drop the legacy form.
                cmd = inner["command"]
                ok = (
                    cmd.startswith("python -m agentsonar claude-code-hook ")
                    or cmd.startswith("agentsonar claude-code-hook ")
                )
                assert ok, f"FAIL: bad command shape: {cmd!r}"

    comment_keys = [k for k in data.keys() if k.startswith("_comment")]
    print(f"top-level keys: {sorted(data.keys())}")
    print(f"comment keys (will be ignored by Claude Code per JSON convention): {len(comment_keys)}")
    print("CAVEAT: if Claude Code's settings parser is strict about unknown top-level keys, these would need to be removed.")
    print("PASS (with caveat noted)")


def test_4_pickle_roundtrip_preserves_prevent_state() -> None:
    banner(4, "pickle round-trip preserves Prevent Mode tracked state")
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"

    sys.path.insert(0, str(REPO / "src"))
    from agentsonar._integrations.claude import adapter as cc
    from agentsonar._core.models import InteractionEvent

    prevent_config = dict(cc._DEFAULT_ENGINE_CONFIG)
    prevent_config.update({
        "warning_threshold": 2,
        "critical_threshold": 4,
        "per_edge_limit": 999,
        "global_limit": 9999,
        "prevent": {"cyclic_delegation": {"max_rotations": 3}},
    })

    state_path = tmp / "sessions" / "preserve" / "state.pkl"
    state_path.parent.mkdir(parents=True, exist_ok=True)

    engine_a = cc._load_or_build_engine(state_path, dict(prevent_config))
    ts = 1.0
    for _ in range(5):
        for src, tgt in (("main", "A"), ("A", "B"), ("B", "main")):
            engine_a.ingest(InteractionEvent(src, tgt, ts, None))
            ts += 1.0
    prevent_a = engine_a.should_prevent()
    print(f"engine A (before save) should_prevent: {'TRIPPED' if prevent_a else 'no trip'}")
    assert prevent_a is not None, "FAIL: engine A failed to trip Prevent"

    cc._save_engine_state(state_path, engine_a)
    print(f"saved state.pkl, size={state_path.stat().st_size} bytes")

    engine_b = cc._load_or_build_engine(state_path, dict(prevent_config))
    prevent_b = engine_b.should_prevent()
    print(f"engine B (after load) should_prevent: {'TRIPPED' if prevent_b else 'no trip'}")
    if prevent_b is None:
        print("FAIL: Prevent state lost across pickle round-trip")
        print(f"engine A._recent_alerts: {getattr(engine_a, '_recent_alerts', '<missing>')}")
        print(f"engine B._recent_alerts: {getattr(engine_b, '_recent_alerts', '<missing>')}")
        raise AssertionError("Prevent state lost across pickle round-trip")

    a_count = len(getattr(engine_a, "_recent_alerts", []))
    b_count = len(getattr(engine_b, "_recent_alerts", []))
    print(f"recent_alerts count: A={a_count}, B={b_count}")
    if a_count != b_count:
        print("FAIL: alert count mismatch")
        raise AssertionError("alert count mismatch")

    a_tracked = len(getattr(getattr(engine_a, "_alert_mgr", None), "_tracked", {}))
    b_tracked = len(getattr(getattr(engine_b, "_alert_mgr", None), "_tracked", {}))
    print(f"alert_mgr._tracked count: A={a_tracked}, B={b_tracked}")
    if a_tracked != b_tracked:
        print("FAIL: tracked alert count mismatch")
        raise AssertionError("tracked alert count mismatch")
    print("PASS")


def test_5_empty_events_render() -> None:
    banner(5, "empty events report.html / report.json render path")
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"

    sid = "empty-events"
    rc, out, err = run_hook_subprocess(
        "Stop",
        {"session_id": sid, "parent_session_id": None},
        env,
    )
    print(f"Stop on empty session: exit_code={rc}")
    assert rc == 0, f"FAIL: empty Stop returned {rc}, expected 0"

    report_html = tmp / "reports" / sid / "report.html"
    report_json = tmp / "reports" / sid / "report.json"
    alerts_log = tmp / "reports" / sid / "alerts.log"
    for art in (report_html, report_json, alerts_log):
        assert art.exists(), f"FAIL: {art} missing"

    json_data = json.loads(report_json.read_text(encoding="utf-8"))
    assert isinstance(json_data, list), f"FAIL: report.json is {type(json_data).__name__}, expected list"
    print(f"report.json: {json_data}")
    print(f"report.html size: {report_html.stat().st_size} bytes")
    print(f"alerts.log first line: {alerts_log.read_text(encoding='utf-8').splitlines()[0] if alerts_log.stat().st_size else '<empty>'}")
    html = report_html.read_text(encoding="utf-8")
    assert html.startswith("<!DOCTYPE"), "FAIL: report.html doesn't start with <!DOCTYPE>"
    assert "</html>" in html, "FAIL: report.html missing closing tag"
    print("PASS")


def test_6_subprocess_cli_full_wire() -> None:
    banner(6, "subprocess CLI: real exit codes + stderr + file outputs")
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"

    sid = "subproc-wire"
    for event in ("PreToolUse", "PostToolUse"):
        rc, out, err = run_hook_subprocess(
            event,
            {
                "session_id": sid,
                "parent_session_id": None,
                "tool_name": "Read",
                "tool_input": {"file_path": "/x.py"},
                "tool_response": {"content": "..."} if event == "PostToolUse" else None,
            },
            env,
        )
        assert rc == 0, f"FAIL: {event} returned {rc}, stderr={err!r}"

    rc, out, err = run_hook_subprocess("Stop", {"session_id": sid, "parent_session_id": None}, env)
    assert rc == 0
    print(f"Stop stderr: {err.strip()!r}")
    print("PASS")


def test_7_payload_corner_cases() -> None:
    banner(7, "payload corner cases (missing/weird fields)")
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"

    cases = [
        ("empty dict", {}),
        ("only session_id", {"session_id": "x"}),
        ("non-string session_id", {"session_id": 12345, "tool_name": "Read"}),
        ("None tool_name", {"session_id": "x", "tool_name": None, "tool_input": {}}),
        ("deeply nested tool_input", {"session_id": "x", "tool_name": "Read", "tool_input": {"a": {"b": {"c": {"d": {"e": "deep"}}}}}}),
        ("tool_input as list", {"session_id": "x", "tool_name": "Bash", "tool_input": ["ls", "-la"]}),
        ("tool_input as string", {"session_id": "x", "tool_name": "Bash", "tool_input": "ls -la"}),
        ("unicode session_id", {"session_id": "session-🌐-emoji", "tool_name": "Read", "tool_input": {"file_path": "/x"}}),
    ]
    for label, payload in cases:
        rc, _, err = run_hook_subprocess("PreToolUse", payload, env)
        marker = "OK" if rc == 0 else "FAIL"
        print(f"  [{marker}] {label}: exit_code={rc} {('stderr: ' + err.strip()) if err.strip() else ''}")
        assert rc == 0, f"corner case '{label}' returned {rc}"
    print("PASS")


def test_8_long_session_id() -> None:
    banner(8, "long session_id (Windows path limit guard)")
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"

    sid = "x" * 100
    rc, _, err = run_hook_subprocess(
        "PreToolUse",
        {"session_id": sid, "parent_session_id": None, "tool_name": "Read", "tool_input": {"file_path": "/x.py"}},
        env,
    )
    print(f"100-char session id: exit_code={rc}")
    if rc != 0:
        print(f"stderr: {err.strip()!r}")
    full_path = tmp / "sessions" / sid / "timeline.jsonl"
    print(f"full path length: {len(str(full_path))}")
    if not full_path.exists():
        print(f"FAIL: timeline at long path not created (Windows path limit?)")
        raise AssertionError("long path failed")
    print("PASS")


def test_9_concurrent_first_hook_race() -> None:
    banner(9, "concurrent first hooks on the same brand-new session id")
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"

    sid = f"first-race-{os.getpid()}"
    n = 6
    procs = []
    for i in range(n):
        proc = subprocess.Popen(
            [str(VENV_PY), "-m", "agentsonar", "claude-code-hook", "PreToolUse"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            cwd=str(REPO),
            text=True,
        )
        proc.stdin.write(json.dumps({
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": f"/x/{i}.py"},
        }))
        proc.stdin.close()
        procs.append(proc)
    exit_codes = [p.wait() for p in procs]
    print(f"exit codes: {exit_codes}")
    assert all(rc == 0 for rc in exit_codes), f"FAIL: some processes returned non-zero: {exit_codes}"

    timeline = tmp / "sessions" / sid / "timeline.jsonl"
    lines = [line for line in timeline.read_text(encoding="utf-8").splitlines() if line.strip()]
    print(f"expected timeline lines: {n}, actual: {len(lines)}")
    assert len(lines) == n, f"FAIL: lost lines under first-hook race"
    print("PASS")


def test_10_no_unused_imports() -> None:
    banner(10, "import audit (any unused imports in claude/adapter.py?)")
    module = REPO / "src" / "agentsonar" / "_integrations" / "claude" / "adapter.py"
    src = module.read_text(encoding="utf-8")

    import_lines = []
    for line in src.splitlines():
        s = line.strip()
        if s.startswith("import ") or s.startswith("from "):
            import_lines.append(line.rstrip())

    declared = set()
    for line in import_lines:
        s = line.strip()
        if " as " in s:
            declared.add(s.split(" as ")[-1].strip())
        elif s.startswith("from "):
            after_import = s.split(" import ")[-1]
            for part in after_import.split(","):
                declared.add(part.strip().split(" as ")[-1].strip())
        elif s.startswith("import "):
            declared.add(s.split()[-1].split(".")[0])

    unused = []
    body_after_imports = src.split("logger = logging.getLogger")[1] if "logger = logging.getLogger" in src else src
    for sym in sorted(declared):
        if sym in ("annotations",):
            continue
        if sym not in body_after_imports:
            unused.append(sym)

    if unused:
        print(f"WARN: possibly unused imports: {unused}")
    else:
        print("no obviously unused imports")
    print("PASS")


def main() -> int:
    tests = [
        test_1_cross_process_lock,
        test_2_line_endings,
        test_3_settings_template,
        test_4_pickle_roundtrip_preserves_prevent_state,
        test_5_empty_events_render,
        test_6_subprocess_cli_full_wire,
        test_7_payload_corner_cases,
        test_8_long_session_id,
        test_9_concurrent_first_hook_race,
        test_10_no_unused_imports,
    ]
    failed = []
    for test in tests:
        try:
            test()
        except Exception as exc:
            failed.append((test.__name__, exc))
            print(f"!! {test.__name__} raised: {type(exc).__name__}: {exc}")

    print("\n" + "=" * 60)
    if failed:
        print(f"FAILURES ({len(failed)}/{len(tests)}):")
        for name, exc in failed:
            print(f"  - {name}: {exc}")
        return 1
    print(f"ALL {len(tests)} SANITY CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
