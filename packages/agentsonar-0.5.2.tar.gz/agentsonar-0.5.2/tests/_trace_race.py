"""Trace 6 concurrent processes to find where events vanish."""
import os
import sys
import json
import subprocess
import tempfile
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
VENV_PY = REPO / ".venv" / "Scripts" / "python.exe"

tmp = Path(tempfile.mkdtemp())
trace_log = tmp / "trace.log"

env = dict(os.environ)
env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
env["AGENTSONAR_TELEMETRY"] = "off"
env["AGENTSONAR_TRACE_LOG"] = str(trace_log)

worker_src = '''
import os, sys, json, time

trace_log = os.environ["AGENTSONAR_TRACE_LOG"]
def trace(msg):
    try:
        with open(trace_log, "ab") as f:
            f.write(f"{os.getpid():>6} t={time.time():.3f} {msg}\\n".encode())
    except Exception:
        pass

trace("worker start")

from agentsonar._integrations.claude import adapter as cc

orig_lock = cc.file_lock
import contextlib
@contextlib.contextmanager
def traced_lock(path, timeout):
    trace(f"lock acquire begin {path}")
    t0 = time.time()
    try:
        with orig_lock(path, timeout) as fh:
            trace(f"lock acquire done in {(time.time()-t0)*1000:.1f}ms")
            yield fh
        trace("lock released cleanly")
    except TimeoutError as e:
        trace(f"lock TIMEOUT {e}")
        raise
    except Exception as e:
        trace(f"lock EXCEPTION {type(e).__name__}: {e}")
        raise
cc.file_lock = traced_lock

orig_locked = cc._handle_hook_locked
def traced_locked(**kw):
    event = kw["event_name"]
    trace(f"in critical section for event={event}")
    try:
        rc = orig_locked(**kw)
        trace(f"critical section done event={event} rc={rc}")
        return rc
    except Exception as e:
        trace(f"critical section RAISED {type(e).__name__}: {e}")
        raise
cc._handle_hook_locked = traced_locked

orig_append = cc._append_timeline
def traced_append(path, record):
    trace(f"timeline append called event_id={record.get('event_id', '?')}")
    try:
        orig_append(path, record)
        trace(f"timeline append done")
    except Exception as e:
        trace(f"timeline append RAISED {type(e).__name__}: {e}")
        raise
cc._append_timeline = traced_append

sid = sys.argv[1]
i = int(sys.argv[2])
payload = {
    "session_id": sid,
    "parent_session_id": None,
    "tool_name": "Read",
    "tool_input": {"file_path": f"/x/{i}.py"},
}
trace(f"calling handle_hook i={i}")
rc = cc.handle_hook("PreToolUse", payload)
trace(f"handle_hook returned {rc}")
sys.exit(rc)
'''

worker_path = tmp / "worker.py"
worker_path.write_text(worker_src, encoding="utf-8")

sid = "trace-race"
n = 6
procs = []
for i in range(n):
    proc = subprocess.Popen(
        [str(VENV_PY), str(worker_path), sid, str(i)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        cwd=str(REPO),
        text=True,
    )
    procs.append(proc)

results = []
for p in procs:
    stdout, stderr = p.communicate()
    results.append((p.returncode, stdout, stderr))

print("exit codes:", [r[0] for r in results])
for i, (rc, out, err) in enumerate(results):
    if rc != 0 or err.strip():
        print(f"proc {i}: rc={rc}\n  stderr: {err.strip()[:500]}")

timeline = tmp / "sessions" / sid / "timeline.jsonl"
if timeline.exists():
    lines = [l for l in timeline.read_text(encoding="utf-8").splitlines() if l.strip()]
    print(f"timeline lines: {len(lines)}/{n}")
    event_ids = [json.loads(l)["event_id"] for l in lines]
    print(f"event_ids in timeline: {event_ids}")
else:
    print("no timeline file")

if trace_log.exists():
    print("---trace (sorted by time)---")
    raw = trace_log.read_text(encoding="utf-8")
    lines = [l for l in raw.splitlines() if l.strip()]
    lines.sort(key=lambda x: float(x.split("t=")[1].split()[0]))
    for line in lines:
        print(line)
else:
    print("no trace log")
