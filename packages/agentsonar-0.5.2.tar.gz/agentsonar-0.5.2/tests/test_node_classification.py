"""
Tests for the universal node-type classifier.

This is the load-bearing test for the "one classifier, every adapter"
architecture. Every classification rule and edge case lives here.
Adapter-specific tests should NOT duplicate these checks.

Coverage:
  - Each NodeType has at least one positive case
  - Convention-based TOOL recognition (the part that scales without
    code edits)
  - All multi-agent adapter inputs default to AGENT (the regression
    guard that protects CrewAI / LangGraph / custom orchestrator)
  - Defensive input handling (None, non-strings, empty, malformed)
  - partition_nodes preserves order, deduplicates, never raises
"""
from __future__ import annotations

import pytest

from agentsonar._core._node_types import (
    NodeType,
    classify_node,
    partition_nodes,
)


# =====================================================================
# NodeType enum sanity
# =====================================================================


class TestNodeTypeEnum:

    def test_node_type_is_string_enum(self):
        """JSON-serializable for free; matches FailureClass / AlertSeverity pattern."""
        assert NodeType.AGENT.value == "agent"
        assert NodeType.TOOL.value == "tool"
        assert NodeType.MCP.value == "mcp"
        assert NodeType.TASK_SPAWN.value == "task_spawn"
        assert NodeType.SENTINEL.value == "sentinel"

    def test_node_type_string_equality(self):
        """str.Enum members compare equal to their string value."""
        assert NodeType.AGENT == "agent"
        assert NodeType.TOOL == "tool"
        assert NodeType.MCP == "mcp"


# =====================================================================
# Sentinels and literals (rules 1-2)
# =====================================================================


class TestSentinelAndLiteralRules:

    def test_session_exit_classifies_as_sentinel(self):
        assert classify_node("session_exit") == NodeType.SENTINEL

    def test_main_classifies_as_agent(self):
        assert classify_node("main") == NodeType.AGENT

    def test_session_exit_is_case_sensitive(self):
        """Only the exact literal matches as sentinel."""
        assert classify_node("Session_Exit") != NodeType.SENTINEL
        assert classify_node("SESSION_EXIT") != NodeType.SENTINEL

    def test_main_is_case_sensitive(self):
        """Only the exact 'main' literal matches as agent literal.
        Other 'main'-like names fall through to default AGENT (still
        correct, just by a different rule)."""
        assert classify_node("Main") != NodeType.SENTINEL
        # "Main" capitalized falls through to default AGENT (no colon, no prefix)
        assert classify_node("Main") == NodeType.AGENT


# =====================================================================
# Subagent prefix (rule 3)
# =====================================================================


class TestSubagentPrefixRule:

    def test_subagent_with_8_hex_classifies_as_agent(self):
        assert classify_node("subagent_a1b2c3d4") == NodeType.AGENT

    def test_subagent_with_long_id_classifies_as_agent(self):
        assert classify_node("subagent_a1b2c3d4e5f6g7h8") == NodeType.AGENT

    def test_subagent_with_short_id_classifies_as_agent(self):
        assert classify_node("subagent_x") == NodeType.AGENT

    def test_subagent_prefix_alone_classifies_as_agent(self):
        """The prefix-only string still falls into AGENT , defensive."""
        assert classify_node("subagent_") == NodeType.AGENT


# =====================================================================
# MCP prefix (rule 4)
# =====================================================================


class TestMcpPrefixRule:

    def test_canonical_mcp_form_classifies_as_mcp(self):
        assert classify_node("mcp__github__create_issue") == NodeType.MCP

    def test_mcp_with_fingerprint_tail_classifies_as_mcp(self):
        assert classify_node("mcp__github__create_issue:abc12345") == NodeType.MCP

    def test_future_mcp_server_classifies_as_mcp(self):
        """Any future MCP server works automatically , no code change."""
        assert classify_node("mcp__brand_new_server__brand_new_tool") == NodeType.MCP
        assert classify_node("mcp__brand_new_server__brand_new_tool:fp") == NodeType.MCP

    def test_mcp_prefix_is_case_sensitive(self):
        """Anthropic's MCP spec uses lowercase 'mcp__'. Other casings
        do not match this rule , they fall through to TOOL (if
        capitalized + colon) or AGENT (otherwise)."""
        assert classify_node("MCP__server__tool") != NodeType.MCP
        # "MCP__server__tool" starts with capitalized "MCP", has no colon,
        # so falls through to AGENT (default).
        assert classify_node("MCP__server__tool") == NodeType.AGENT

    def test_mcp_prefix_alone_classifies_as_mcp(self):
        """Defensive: even malformed 'mcp__' classifies; downstream logic
        can decide whether to treat it as a real call."""
        assert classify_node("mcp__") == NodeType.MCP


# =====================================================================
# Task_spawn prefix (rule 5)
# =====================================================================


class TestTaskSpawnPrefixRule:

    def test_task_spawn_classifies_as_task_spawn(self):
        assert classify_node("Task_spawn:reviewer") == NodeType.TASK_SPAWN

    def test_task_spawn_with_hash_classifies_as_task_spawn(self):
        assert classify_node("Task_spawn:a1b2c3d4") == NodeType.TASK_SPAWN

    def test_task_spawn_is_case_sensitive(self):
        """The Task_spawn convention has specific capitalization."""
        assert classify_node("task_spawn:reviewer") != NodeType.TASK_SPAWN
        # "task_spawn:reviewer" , lowercase head doesn't match TOOL convention either,
        # falls through to AGENT.
        assert classify_node("task_spawn:reviewer") == NodeType.AGENT


# =====================================================================
# Generic TOOL convention (rule 6) , the load-bearing one
# =====================================================================


class TestGenericToolConventionRule:
    """The convention-based TOOL classification. This is what makes
    the classifier scale without code changes."""

    def test_currently_shipped_claude_code_tools_classify_as_tool(self):
        """Every tool that Claude Code's derive_target_agent emits today."""
        for tool in (
            "Read:/src/hello.py",
            "Edit:/src/hello.py",
            "Write:/src/new.py",
            "MultiEdit:/src/x.py",
            "NotebookEdit:/src/n.ipynb",
            "Grep:/src",
            "Glob:/src",
            "Bash:abc12345",
            "WebFetch:def67890",
            "WebSearch:ghi13579",
        ):
            assert classify_node(tool) == NodeType.TOOL, f"{tool} should be TOOL"

    def test_unlisted_but_existing_claude_code_tools_classify_as_tool(self):
        """Tools that exist in Claude Code but were never explicitly
        listed in any classifier table. Validates convention scales."""
        for tool in (
            "TodoWrite:abc",
            "KillBash:def",
            "BashOutput:ghi",
            "ExitPlanMode:xyz",
        ):
            assert classify_node(tool) == NodeType.TOOL, f"{tool} should be TOOL"

    def test_future_tool_classifies_as_tool(self):
        """A tool Anthropic ships tomorrow with a name we've never
        seen. The convention IS the contract."""
        assert classify_node("BrandNewTool:fingerprint") == NodeType.TOOL
        assert classify_node("AnotherNewTool:/some/path") == NodeType.TOOL
        assert classify_node("MyFutureTool_v2:identifier") == NodeType.TOOL

    def test_lowercase_head_does_not_classify_as_tool(self):
        """Convention requires capitalized head."""
        assert classify_node("read:/x") != NodeType.TOOL
        assert classify_node("edit:/x") != NodeType.TOOL

    def test_tool_with_path_containing_colons_classifies_as_tool(self):
        """Path itself may contain colons (e.g. Windows drive letters).
        Only the first colon delimits head from tail."""
        assert classify_node("Read:C:\\Users\\srini\\src\\hello.py") == NodeType.TOOL
        assert classify_node("Edit:C:/strange:path/file.py") == NodeType.TOOL

    def test_tool_with_unicode_path_classifies_as_tool(self):
        assert classify_node("Read:/src/日本語/файл.py") == NodeType.TOOL

    def test_tool_with_underscores_in_head_classifies_as_tool(self):
        """Head allows underscores: NotebookEdit, MultiEdit, etc."""
        assert classify_node("Custom_Tool:identifier") == NodeType.TOOL

    def test_tool_with_digits_in_head_classifies_as_tool(self):
        assert classify_node("Tool2:identifier") == NodeType.TOOL

    def test_special_chars_in_head_do_not_classify_as_tool(self):
        """Head must be alphanumeric + underscore only."""
        assert classify_node("Tool-Name:x") != NodeType.TOOL
        assert classify_node("Tool.Name:x") != NodeType.TOOL
        assert classify_node("Tool Name:x") != NodeType.TOOL


# =====================================================================
# AGENT default (rule 7) , the multi-agent adapter regression guard
# =====================================================================


class TestAgentDefaultRule:
    """Multi-agent adapters (CrewAI, LangGraph, custom orchestrator)
    emit bare agent names. These MUST default to AGENT so those
    adapters keep working unchanged."""

    def test_crewai_style_lowercase_names_classify_as_agent(self):
        for name in ("planner", "researcher", "writer", "manager", "reviewer"):
            assert classify_node(name) == NodeType.AGENT

    def test_langgraph_style_node_names_classify_as_agent(self):
        for name in ("plan_node", "research_step", "writer_node", "review-step"):
            assert classify_node(name) == NodeType.AGENT

    def test_custom_orchestrator_arbitrary_names_classify_as_agent(self):
        for name in ("agent-1", "agent_2", "AgentA", "MyAgent"):
            assert classify_node(name) == NodeType.AGENT

    def test_capitalized_bare_agent_name_classifies_as_agent(self):
        """No colon = no TOOL classification, even if capitalized.
        This is the contract that protects multi-agent adapters."""
        for name in ("Planner", "Researcher", "Writer", "Manager"):
            assert classify_node(name) == NodeType.AGENT


# =====================================================================
# Defensive input handling
# =====================================================================


class TestDefensiveInputHandling:

    def test_none_classifies_as_agent(self):
        assert classify_node(None) == NodeType.AGENT

    def test_empty_string_classifies_as_agent(self):
        assert classify_node("") == NodeType.AGENT

    def test_integer_input_classifies_as_agent(self):
        assert classify_node(42) == NodeType.AGENT

    def test_dict_input_classifies_as_agent(self):
        assert classify_node({"name": "x"}) == NodeType.AGENT

    def test_list_input_classifies_as_agent(self):
        assert classify_node(["a", "b"]) == NodeType.AGENT

    def test_bytes_input_classifies_as_agent(self):
        assert classify_node(b"main") == NodeType.AGENT

    def test_object_with_broken_str_classifies_as_agent(self):
        class Bad:
            def __str__(self):
                raise RuntimeError("nope")
        assert classify_node(Bad()) == NodeType.AGENT


# =====================================================================
# partition_nodes
# =====================================================================


class TestPartitionNodes:

    def test_partition_groups_by_type(self):
        result = partition_nodes([
            "main",
            "Read:/src/foo.py",
            "mcp__github__create_issue:fp",
            "Task_spawn:reviewer",
            "subagent_abc12345",
            "session_exit",
        ])
        assert result[NodeType.AGENT] == ("main", "subagent_abc12345")
        assert result[NodeType.TOOL] == ("Read:/src/foo.py",)
        assert result[NodeType.MCP] == ("mcp__github__create_issue:fp",)
        assert result[NodeType.TASK_SPAWN] == ("Task_spawn:reviewer",)
        assert result[NodeType.SENTINEL] == ("session_exit",)

    def test_partition_preserves_first_seen_order(self):
        result = partition_nodes([
            "Read:/c.py",
            "Read:/a.py",
            "Read:/b.py",
        ])
        assert result[NodeType.TOOL] == (
            "Read:/c.py",
            "Read:/a.py",
            "Read:/b.py",
        )

    def test_partition_deduplicates_within_buckets(self):
        result = partition_nodes([
            "Read:/foo.py",
            "Read:/foo.py",
            "Read:/foo.py",
        ])
        assert result[NodeType.TOOL] == ("Read:/foo.py",)

    def test_partition_returns_empty_dict_for_empty_input(self):
        assert partition_nodes([]) == {}

    def test_partition_returns_empty_dict_for_none_input(self):
        assert partition_nodes(None) == {}

    def test_partition_returns_empty_dict_for_non_iterable_input(self):
        assert partition_nodes(42) == {}

    def test_partition_missing_keys_means_empty_buckets(self):
        """Callers use .get(NodeType.X, ()) rather than raw indexing."""
        result = partition_nodes(["planner", "researcher"])
        assert result[NodeType.AGENT] == ("planner", "researcher")
        assert NodeType.TOOL not in result
        assert NodeType.MCP not in result
        assert result.get(NodeType.TOOL, ()) == ()
        assert result.get(NodeType.MCP, ()) == ()

    def test_partition_skips_non_string_entries_gracefully(self):
        """Mixed input with garbage entries: classifier handles them as
        AGENT (default), so they bucket under AGENT but with empty
        string keys (deduped)."""
        result = partition_nodes(["main", None, 42, "main"])
        # "main" once, plus one empty string from None/42 (which classify
        # as AGENT but their key is "")
        assert NodeType.AGENT in result
        assert "main" in result[NodeType.AGENT]

    def test_partition_realistic_claude_code_event(self):
        """End-to-end realistic input: a Claude Code cycle event."""
        result = partition_nodes([
            "main",
            "Read:/src/hello.py",
            "Edit:/src/hello.py",
            "Task_spawn:reviewer",
            "mcp__github__get_issue:fp",
        ])
        assert result[NodeType.AGENT] == ("main",)
        assert result[NodeType.TOOL] == ("Read:/src/hello.py", "Edit:/src/hello.py")
        assert result[NodeType.TASK_SPAWN] == ("Task_spawn:reviewer",)
        assert result[NodeType.MCP] == ("mcp__github__get_issue:fp",)

    def test_partition_realistic_multi_agent_event(self):
        """CrewAI / LangGraph / custom-orchestrator event: all
        bare names. Every node lands in AGENT bucket; other buckets
        are absent. This is the regression guard for multi-agent
        adapters - they must keep working unchanged."""
        result = partition_nodes([
            "planner",
            "researcher",
            "writer",
        ])
        assert result[NodeType.AGENT] == ("planner", "researcher", "writer")
        assert NodeType.TOOL not in result
        assert NodeType.MCP not in result
        assert NodeType.TASK_SPAWN not in result


# =====================================================================
# Cross-adapter regression matrix (the protection contract)
# =====================================================================


class TestCrossAdapterRegressionMatrix:
    """Symbolic check: every adapter today should still classify its
    standard event shapes correctly under the new classifier.
    Failures here mean we accidentally broke another adapter while
    enriching Claude Code."""

    @pytest.mark.parametrize("adapter,nodes,expected_types", [
        (
            "custom_python",
            ["planner", "researcher", "writer"],
            {NodeType.AGENT},
        ),
        (
            "crewai",
            ["manager", "researcher"],
            {NodeType.AGENT},
        ),
        (
            "langgraph",
            ["plan_node", "research_step", "writer_node"],
            {NodeType.AGENT},
        ),
        (
            "claude_code_simple",
            ["main", "Read:/src/foo.py"],
            {NodeType.AGENT, NodeType.TOOL},
        ),
        (
            "claude_code_mcp",
            ["main", "mcp__github__create_issue:fp"],
            {NodeType.AGENT, NodeType.MCP},
        ),
        (
            "claude_code_subagent_spawn",
            ["main", "Task_spawn:reviewer"],
            {NodeType.AGENT, NodeType.TASK_SPAWN},
        ),
        (
            "claude_code_subagent_doing_tool",
            ["subagent_abc12345", "Read:/src/foo.py"],
            {NodeType.AGENT, NodeType.TOOL},
        ),
        (
            "claude_code_session_end",
            ["main", "session_exit"],
            {NodeType.AGENT, NodeType.SENTINEL},
        ),
    ])
    def test_adapter_shape_classifies_correctly(self, adapter, nodes, expected_types):
        result = partition_nodes(nodes)
        actual_types = set(result.keys())
        assert actual_types == expected_types, (
            f"{adapter}: expected {expected_types}, got {actual_types}"
        )
