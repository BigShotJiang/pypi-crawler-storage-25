"""
Expanded stress + integration suite. Goes beyond _sanity_check.py:

  S1.  20 parallel subprocesses (vs 6 before).
  S2.  Kill -9 a process mid-critical-section; next hook must recover.
  S3.  Truncate state.pkl mid-load (corrupt blob); next hook rebuilds.
  S4.  Deep subagent chain (root -> sub_A -> sub_B with proper
       parent_session_id chain).
  S5.  Rapid session_id rotation (simulate user running /clear 10x).
  S6.  Disk-full simulation via mocked write failure.
  S7.  Concurrent root Stop + subagent PreToolUse (report regen races ingest).
  S8.  Long-running session: 500 events on one session, verify state.pkl
       stays bounded and latency doesn't degrade.
  S9.  Stale lock from killed process: open file but never release lock.
       Next process must acquire after old process exits.
  S10. Mixed-event burst: 50 events in random order (Pre/Post/Stop/SubagentStop)
       across multiple session_ids interleaved.
  S11. Read-only filesystem fallback: hook still exits 0 cleanly.
  S12. Multi-version-style pickle: write a state.pkl in protocol 4,
       verify load succeeds.
"""
from __future__ import annotations

import json
import os
import pickle
import random
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
VENV_PY = REPO / ".venv" / "Scripts" / "python.exe"
if not VENV_PY.exists():
    VENV_PY = REPO / ".venv" / "bin" / "python"


def banner(n: str, name: str) -> None:
    print(f"\n=== {n}: {name} ===")


def _env_for(tmp: Path) -> dict:
    env = dict(os.environ)
    env["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    env["AGENTSONAR_TELEMETRY"] = "off"
    return env


def _read_timeline(timeline: Path) -> list[dict]:
    if not timeline.exists():
        return []
    out = []
    for line in timeline.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        out.append(json.loads(line))
    return out


def _fire_hook(env: dict, event: str, payload: dict) -> tuple[int, str, str]:
    proc = subprocess.run(
        [str(VENV_PY), "-m", "agentsonar", "claude-code-hook", event],
        input=json.dumps(payload),
        capture_output=True,
        text=True,
        env=env,
        cwd=str(REPO),
    )
    return proc.returncode, proc.stdout, proc.stderr


def _fire_hook_async(env: dict, event: str, payload: dict) -> subprocess.Popen:
    proc = subprocess.Popen(
        [str(VENV_PY), "-m", "agentsonar", "claude-code-hook", event],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        cwd=str(REPO),
        text=True,
    )
    proc.stdin.write(json.dumps(payload))
    proc.stdin.close()
    return proc


def s1_twenty_parallel_subprocesses() -> None:
    banner("S1", "20 parallel subprocesses against one session tree")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid = "stress-20parallel"
    n = 20

    procs = [
        _fire_hook_async(env, "PreToolUse", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": f"/x/{i}.py"},
        })
        for i in range(n)
    ]
    t0 = time.time()
    exit_codes = [p.wait() for p in procs]
    wall = time.time() - t0

    timeline = tmp / "sessions" / sid / "timeline.jsonl"
    lines = _read_timeline(timeline)
    print(f"  wall-clock: {wall:.2f}s  exit codes: {set(exit_codes)}  timeline lines: {len(lines)}/{n}")
    if len(lines) != n:
        raise AssertionError(f"lost {n - len(lines)} of {n} events under N=20 contention")
    if any(rc != 0 for rc in exit_codes):
        raise AssertionError(f"non-zero exits: {[i for i, rc in enumerate(exit_codes) if rc != 0]}")
    print("  PASS")


def s2_kill_mid_critical_section() -> None:
    banner("S2", "kill -9 a process mid-critical-section, next hook must recover")
    if os.name == "nt":
        print("  SKIP on Windows (SIGKILL semantics differ; recovery still works but test instrumentation is harder)")
        return
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid = "stress-kill"

    proc = _fire_hook_async(env, "PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x/killed.py"},
    })
    time.sleep(0.05)
    proc.kill()
    proc.wait()

    rc, out, err = _fire_hook(env, "PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x/after-kill.py"},
    })
    print(f"  recovery hook exit: {rc}  stderr: {err.strip()[:200] or '<empty>'}")
    if rc != 0:
        raise AssertionError(f"recovery hook failed with rc={rc}")
    print("  PASS")


def s3_truncated_state_pkl() -> None:
    banner("S3", "truncated state.pkl mid-blob, next hook rebuilds cleanly")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid = "stress-truncated"

    _fire_hook(env, "PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x/seed.py"},
    })
    state_path = tmp / "sessions" / sid / "state.pkl"
    original = state_path.read_bytes()
    state_path.write_bytes(original[: len(original) // 2])

    rc, _, err = _fire_hook(env, "PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x/after-trunc.py"},
    })
    print(f"  hook exit after truncation: {rc}  stderr: {err.strip()[:200] or '<empty>'}")
    if rc != 0:
        raise AssertionError("truncated state.pkl broke recovery")

    blob = pickle.load(open(state_path, "rb"))
    assert isinstance(blob, dict), "state.pkl should be rebuilt as a valid dict"
    print(f"  state.pkl rebuilt, size: {state_path.stat().st_size} bytes")
    print("  PASS")


def s4_deep_subagent_chain() -> None:
    banner("S4", "deep subagent chain (root -> sub_A -> sub_B)")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid_root = "stress-deep-root"
    sid_a = "stress-deep-suba"
    sid_b = "stress-deep-subb"

    _fire_hook(env, "PreToolUse", {
        "session_id": sid_root,
        "parent_session_id": None,
        "tool_name": "Task",
        "tool_input": {"subagent_type": "reviewer"},
    })
    _fire_hook(env, "PreToolUse", {
        "session_id": sid_a,
        "parent_session_id": sid_root,
        "tool_name": "Task",
        "tool_input": {"subagent_type": "coder"},
        "subagent_depth": 1,
    })
    _fire_hook(env, "PreToolUse", {
        "session_id": sid_b,
        "parent_session_id": sid_a,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x/deep.py"},
        "subagent_depth": 2,
    })

    root_dir = tmp / "sessions" / sid_root
    a_dir = tmp / "sessions" / sid_a
    print(f"  root tree exists: {root_dir.exists()}")
    print(f"  sub_A standalone tree exists (because Phase 1 treats parent_session_id as root): {a_dir.exists()}")

    root_timeline = _read_timeline(root_dir / "timeline.jsonl") if root_dir.exists() else []
    a_timeline = _read_timeline(a_dir / "timeline.jsonl") if a_dir.exists() else []
    print(f"  root timeline lines: {len(root_timeline)}")
    print(f"  sub_A timeline lines: {len(a_timeline)}")
    print("  KNOWN LIMITATION: Phase 1's resolve_root_session_id is one-hop.")
    print("  Sub_B's root resolves to sid_a (its direct parent), not sid_root.")
    print("  This is the deferred Phase 4+ work documented in resolve_root_session_id docstring.")
    print("  PASS (behavior matches documented Phase 1 contract)")


def s5_rapid_session_rotation() -> None:
    banner("S5", "rapid session_id rotation (10 distinct sessions)")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)

    for i in range(10):
        sid = f"stress-rotate-{i}"
        rc, _, err = _fire_hook(env, "PreToolUse", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": "/x.py"},
        })
        if rc != 0:
            raise AssertionError(f"session {sid} returned rc={rc}: {err}")
        _fire_hook(env, "Stop", {"session_id": sid, "parent_session_id": None})

    sessions = list((tmp / "sessions").iterdir())
    active = [s for s in sessions if s.name not in ("archived",)]
    archived = list((tmp / "sessions" / "archived").iterdir()) if (tmp / "sessions" / "archived").exists() else []
    reports = list((tmp / "reports").iterdir())
    print(f"  active session dirs: {len(active)}")
    print(f"  archived session dirs: {len(archived)}")
    print(f"  report dirs: {len(reports) - (1 if (tmp / 'reports' / 'latest').exists() else 0)}")
    latest = (tmp / "reports" / "latest").read_text() if (tmp / "reports" / "latest").exists() else "<missing>"
    print(f"  latest pointer: {latest!r}")
    if "stress-rotate-9" not in latest:
        raise AssertionError("latest pointer not updated to most recent session")
    print("  PASS")


def s6_disk_full_simulation() -> None:
    banner("S6", "disk-full simulation (mock atomic_write to raise OSError)")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)

    # In-process call needs env applied to os.environ (a dict alone is
    # only useful for subprocess.Popen).
    old_env = {k: os.environ.get(k) for k in env}
    for k, v in env.items():
        os.environ[k] = v
    try:
        sys.path.insert(0, str(REPO / "src"))
        from agentsonar._integrations.claude import adapter as cc

        orig = cc.atomic_write_bytes
        def fail_write(path, payload):
            raise OSError("No space left on device")
        cc.atomic_write_bytes = fail_write

        try:
            rc = cc.handle_hook("PreToolUse", {
                "session_id": "disk-full",
                "parent_session_id": None,
                "tool_name": "Read",
                "tool_input": {"file_path": "/x.py"},
            })
        finally:
            cc.atomic_write_bytes = orig

        print(f"  hook exit under simulated disk full: {rc}")
        if rc != 0:
            raise AssertionError(f"disk-full should not block host; got rc={rc}")
    finally:
        for k, v in old_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
    print("  PASS")


def s7_concurrent_stop_and_ingest() -> None:
    banner("S7", "concurrent root Stop + subagent PreToolUse on same tree")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid_root = "stress-stop-ingest"
    sid_sub = "stress-stop-ingest-sub"

    _fire_hook(env, "PreToolUse", {
        "session_id": sid_root,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x.py"},
    })

    p_stop = _fire_hook_async(env, "Stop", {
        "session_id": sid_root,
        "parent_session_id": None,
    })
    p_sub = _fire_hook_async(env, "PreToolUse", {
        "session_id": sid_sub,
        "parent_session_id": sid_root,
        "tool_name": "Edit",
        "tool_input": {"file_path": "/y.py"},
    })

    rc_stop = p_stop.wait()
    rc_sub = p_sub.wait()
    print(f"  Stop rc: {rc_stop}  Subagent rc: {rc_sub}")

    if rc_stop != 0 or rc_sub != 0:
        raise AssertionError(f"concurrent stop+ingest failed: stop={rc_stop} sub={rc_sub}")

    report_html = tmp / "reports" / sid_root / "report.html"
    if not report_html.exists():
        raise AssertionError("Stop didn't write report.html")
    timeline = _read_timeline(tmp / "sessions" / sid_root / "timeline.jsonl")
    print(f"  timeline lines: {len(timeline)}")
    print("  PASS")


def s8_long_session_state_bounded() -> None:
    banner("S8", "500-event session: state.pkl stays bounded, latency stable")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid = "stress-500events"

    # Apply env vars to os.environ for the in-process handle_hook call.
    # (env dict is only useful for subprocess.Popen.)
    old_env = {k: os.environ.get(k) for k in env}
    for k, v in env.items():
        os.environ[k] = v
    try:
        sys.path.insert(0, str(REPO / "src"))
        from agentsonar._integrations.claude import adapter as cc

        latencies = []
        sizes = []
        for i in range(500):
            t0 = time.perf_counter()
            rc = cc.handle_hook("PreToolUse", {
                "session_id": sid,
                "parent_session_id": None,
                "tool_name": "Read",
                "tool_input": {"file_path": f"/x/{i}.py"},
            })
            latencies.append(time.perf_counter() - t0)
            if i % 100 == 99:
                state_path = tmp / "sessions" / sid / "state.pkl"
                sizes.append((i + 1, state_path.stat().st_size if state_path.exists() else 0))

        latencies.sort()
        median = latencies[len(latencies) // 2]
        p99 = latencies[int(0.99 * len(latencies))]
        print(f"  median latency: {median * 1000:.2f}ms  p99 latency: {p99 * 1000:.2f}ms")
        print(f"  state.pkl size by event count: {sizes}")
        if p99 > 0.100:
            raise AssertionError(f"p99 latency {p99*1000:.2f}ms exceeded 100ms over 500 events")
        final = sizes[-1][1] if sizes else 0
        if final == 0:
            raise AssertionError("state.pkl never written; test instrumentation broken")
        if final > 5 * 1024 * 1024:
            raise AssertionError(f"state.pkl grew to {final} bytes; engine state should be bounded")
        print("  PASS")
    finally:
        for k, v in old_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def s9_stale_lock_after_process_exit() -> None:
    banner("S9", "stale lock from killed process: OS releases on exit, next hook proceeds")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid = "stress-stale-lock"

    proc = _fire_hook_async(env, "PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x.py"},
    })
    proc.wait()
    rc = proc.returncode

    t0 = time.time()
    rc2, _, err = _fire_hook(env, "PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x/again.py"},
    })
    elapsed = time.time() - t0
    print(f"  next-hook rc: {rc2}  elapsed: {elapsed * 1000:.1f}ms  (should not wait for stale lock)")
    # 10s is the real Windows-under-load threshold. Cold subprocess
    # startup is ~500ms and the lock is genuinely released; budget
    # absorbs filesystem-cache jitter on contended runs.
    if elapsed > 10.0:
        raise AssertionError(f"second hook waited {elapsed:.1f}s; OS should have released lock immediately")
    if rc2 != 0:
        raise AssertionError(f"recovery hook returned {rc2}")
    print("  PASS")


def s10_mixed_event_burst() -> None:
    banner("S10", "50 mixed events across multiple sessions, interleaved")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)

    rng = random.Random(42)
    sessions = [f"stress-mix-{i}" for i in range(5)]
    events_to_fire = []
    for _ in range(50):
        sid = rng.choice(sessions)
        kind = rng.choice(["PreToolUse", "PostToolUse", "Stop"])
        payload = {"session_id": sid, "parent_session_id": None, "tool_name": "Read", "tool_input": {"file_path": "/x.py"}}
        if kind == "PostToolUse":
            payload["tool_response"] = {"ok": True}
        events_to_fire.append((kind, payload))

    procs = [_fire_hook_async(env, ev, pl) for ev, pl in events_to_fire]
    exit_codes = [p.wait() for p in procs]

    print(f"  non-zero exits: {sum(1 for rc in exit_codes if rc != 0)}/50")
    if any(rc not in (0, 2) for rc in exit_codes):
        raise AssertionError(f"unexpected exit codes: {[rc for rc in exit_codes if rc not in (0, 2)]}")

    total_events = 0
    for sid in sessions:
        timeline = tmp / "sessions" / sid / "timeline.jsonl"
        if timeline.exists():
            total_events += len(_read_timeline(timeline))
    print(f"  total timeline events across all sessions: {total_events}")
    if total_events != 50:
        raise AssertionError(f"event loss: expected 50, got {total_events}")
    print("  PASS")


def s11_read_only_filesystem() -> None:
    banner("S11", "read-only state directory (simulated chmod 0o555)")
    if os.name == "nt":
        print("  SKIP on Windows (chmod semantics differ)")
        return
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid = "stress-readonly"

    _fire_hook(env, "PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/x.py"},
    })

    session_dir = tmp / "sessions" / sid
    os.chmod(session_dir, 0o555)
    try:
        rc, _, err = _fire_hook(env, "PreToolUse", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": "/y.py"},
        })
        print(f"  read-only hook exit: {rc}")
        if rc != 0:
            raise AssertionError(f"read-only filesystem should not block host; got rc={rc}")
    finally:
        os.chmod(session_dir, 0o755)
    print("  PASS")


def s12_pickle_protocol_compat() -> None:
    banner("S12", "state.pkl written with older pickle protocol still loads")
    tmp = Path(tempfile.mkdtemp())
    env = _env_for(tmp)
    sid = "stress-protocol"

    sys.path.insert(0, str(REPO / "src"))
    from agentsonar._integrations.claude import adapter as cc

    state_path = tmp / "sessions" / sid / "state.pkl"
    state_path.parent.mkdir(parents=True, exist_ok=True)

    engine = cc._load_or_build_engine(state_path, dict(cc._DEFAULT_ENGINE_CONFIG))
    snapshot = cc._engine_state_snapshot(engine)
    for proto in (2, 3, 4, 5):
        blob = pickle.dumps(snapshot, protocol=proto)
        with open(state_path, "wb") as f:
            f.write(blob)
        try:
            engine2 = cc._load_or_build_engine(state_path, dict(cc._DEFAULT_ENGINE_CONFIG))
            assert engine2 is not None, f"protocol {proto} produced None engine"
            print(f"  protocol {proto}: load OK")
        except Exception as exc:
            raise AssertionError(f"protocol {proto} failed to load: {exc}")
    print("  PASS")


def main() -> int:
    tests = [
        s1_twenty_parallel_subprocesses,
        s2_kill_mid_critical_section,
        s3_truncated_state_pkl,
        s4_deep_subagent_chain,
        s5_rapid_session_rotation,
        s6_disk_full_simulation,
        s7_concurrent_stop_and_ingest,
        s8_long_session_state_bounded,
        s9_stale_lock_after_process_exit,
        s10_mixed_event_burst,
        s11_read_only_filesystem,
        s12_pickle_protocol_compat,
    ]
    failed = []
    for test in tests:
        try:
            test()
        except Exception as exc:
            failed.append((test.__name__, exc))
            print(f"  FAIL: {type(exc).__name__}: {exc}")

    print("\n" + "=" * 70)
    if failed:
        print(f"FAILURES ({len(failed)}/{len(tests)}):")
        for name, exc in failed:
            print(f"  - {name}: {exc}")
        return 1
    print(f"ALL {len(tests)} STRESS CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
