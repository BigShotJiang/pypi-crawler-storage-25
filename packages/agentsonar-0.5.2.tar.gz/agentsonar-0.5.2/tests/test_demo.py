"""
Tests for the `agentsonar demo` command (and the underlying `run_demo`
function in `agentsonar/_demo.py`).

Two test surfaces, both important:

  1. The in-process `run_demo(output_dir=...)` function. Fast, easy to
     introspect — captures stderr, asserts on the artifacts written
     under the supplied output_dir.

  2. The actual `python -m agentsonar demo` subprocess invocation.
     Validates the console-script wiring + argparse dispatch, since a
     working `run_demo` and a broken `__main__.py` would otherwise
     ship a demo that doesn't run at install time.

Cross-language parity surface: the npm SDK's `tests/cli.test.ts` mirrors
these tests one-for-one against its own demo. Same stdout shape, same
exit codes.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys

import pytest

from agentsonar._demo import run_demo


# Match a "Report written: <path>" line so tests can extract the path
# without baking in the tmpdir layout.
_REPORT_LINE_RE = re.compile(r"^Report written: (.+)$", re.MULTILINE)


def test_run_demo_exits_clean_and_catches_prevent(tmp_path, capsys):
    """The canonical happy path.

    Prevent Mode trips at rotation 5; run_demo catches the PreventError
    and returns 0. The exit-1 regression branch is covered separately
    below.
    """
    rc = run_demo(output_dir=str(tmp_path))
    assert rc == 0

    captured = capsys.readouterr()
    # Header lines are emitted to stderr verbatim. We pin the substantive
    # ones — the exact wording is the cross-language parity contract.
    assert "AgentSonar demo: a silent loop between three agents" in captured.err
    assert "researcher → writer → reviewer → researcher → ..." in captured.err
    # PreventError catch summary.
    assert "caught the loop at rotation 5" in captured.err
    assert "PreventError fired" in captured.err


def test_run_demo_writes_report_html(tmp_path, capsys):
    """Verify the report file exists on disk and the stderr line points to it.

    The HTML report is the artifact the user opens after the demo runs;
    if the file isn't there OR the path printed to stderr doesn't match,
    the user lands on a 404 and concludes AgentSonar is broken.
    """
    rc = run_demo(output_dir=str(tmp_path))
    assert rc == 0

    captured = capsys.readouterr()
    match = _REPORT_LINE_RE.search(captured.err)
    assert match is not None, (
        "Demo did not print a `Report written: <path>` line. "
        "Full stderr:\n" + captured.err
    )

    report_path = match.group(1).strip()
    assert os.path.exists(report_path), (
        f"Demo printed a report path that doesn't exist on disk: {report_path}"
    )
    assert report_path.endswith("report.html")

    # report.json should be sibling — same run-dir. Belt-and-suspenders
    # against future regressions in the auto-export wiring.
    json_path = os.path.join(os.path.dirname(report_path), "report.json")
    assert os.path.exists(json_path), (
        "report.json missing alongside report.html — auto-export wiring broke"
    )


def test_run_demo_idempotent_across_repeat_invocations(tmp_path):
    """Calling run_demo twice with different output dirs both succeed.

    Singletons / global state would surface here as the second call
    failing because the first poisoned the engine.
    """
    rc1 = run_demo(output_dir=str(tmp_path / "first"))
    rc2 = run_demo(output_dir=str(tmp_path / "second"))
    assert rc1 == 0
    assert rc2 == 0
    # Both runs land their own reports.
    assert os.path.isdir(tmp_path / "first" / "agentsonar_logs")
    assert os.path.isdir(tmp_path / "second" / "agentsonar_logs")


def test_run_demo_writes_to_cwd_agentsonar_logs_when_no_output_dir(
    tmp_path, monkeypatch, capsys,
):
    """Default behavior: when called with no arguments, the demo writes
    to ``./agentsonar_logs/`` in the current working directory. This is
    the path the actual CLI invocation takes — users don't pass
    ``--output-dir``, and reports land next to their code so they can
    open them directly.

    We monkeypatch into ``tmp_path`` so the test doesn't pollute the
    test runner's cwd with a stray ``agentsonar_logs/`` dir.
    """
    monkeypatch.chdir(tmp_path)

    rc = run_demo()
    assert rc == 0

    captured = capsys.readouterr()
    match = _REPORT_LINE_RE.search(captured.err)
    assert match is not None, (
        "Demo did not print a `Report written:` line.\n" + captured.err
    )
    report_path = match.group(1).strip()

    # The report MUST land under tmp_path/agentsonar_logs/, NOT under
    # a system tmpdir. Both checks: it's inside tmp_path (cwd-relative)
    # AND mentions the agentsonar_logs subdir.
    assert "agentsonar_logs" in report_path, (
        f"Report path missing agentsonar_logs/ segment: {report_path}"
    )
    assert os.path.exists(report_path), (
        f"Report path printed but file doesn't exist: {report_path}"
    )
    # Specifically inside our test's tmp_path (not some other cwd).
    expected_root = os.path.join(str(tmp_path), "agentsonar_logs")
    assert report_path.startswith(expected_root) or os.path.normpath(
        report_path
    ).startswith(os.path.normpath(expected_root)), (
        f"Report path {report_path} did not land under expected root {expected_root}"
    )


def test_subprocess_python_m_agentsonar_demo(tmp_path):
    """Validate the actual `python -m agentsonar demo --output-dir X` wiring.

    A working `run_demo` and a broken `__main__.py` would still ship a
    demo that doesn't run at install time. This subprocess test pins
    the dispatcher path end-to-end.

    Uses sys.executable so the test runs against the same interpreter
    pytest does — no PATH ambiguity, no venv mixups.
    """
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "agentsonar",
            "demo",
            "--output-dir",
            str(tmp_path),
        ],
        capture_output=True,
        text=True,
        # Generous timeout — even on slow CI the demo should finish well
        # under 5 seconds. Failing here means the subprocess wedged.
        timeout=30,
    )
    assert result.returncode == 0, (
        f"`python -m agentsonar demo` exited {result.returncode}.\n"
        f"--- stdout ---\n{result.stdout}\n"
        f"--- stderr ---\n{result.stderr}"
    )
    # The demo's output goes to stderr by design (matches the colored
    # alert stream convention).
    assert "caught the loop at rotation 5" in result.stderr
    assert "Report written:" in result.stderr


def test_subprocess_agentsonar_version_flag():
    """`python -m agentsonar --version` prints the version and exits 0."""
    from agentsonar._version import __version__

    result = subprocess.run(
        [sys.executable, "-m", "agentsonar", "--version"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert result.returncode == 0
    # argparse prints to stdout for --version (unlike --help which goes
    # to stdout too on Python 3.10+). Either stream is acceptable for
    # robustness against argparse version changes.
    combined = result.stdout + result.stderr
    assert __version__ in combined
    assert "agentsonar" in combined


def test_subprocess_bare_invocation_prints_help_and_exits_nonzero():
    """Bare `python -m agentsonar` (no subcommand) prints help, exit code 2.

    Matches the standard argparse "no command given" UX. Exit 2 is the
    argparse convention for usage errors.
    """
    result = subprocess.run(
        [sys.executable, "-m", "agentsonar"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert result.returncode == 2
    # Help text mentions the demo subcommand.
    combined = result.stdout + result.stderr
    assert "demo" in combined


def test_main_outer_safety_net_swallows_unexpected_exception(monkeypatch, capsys):
    """`__main__.main()` must NEVER let a stray exception bubble out as
    a raw traceback. Mock the demo to raise an arbitrary RuntimeError
    and verify main() prints a clean error line and returns nonzero.

    This is the Python parity for npm `cli/index.ts:main()`'s outer
    try/catch. The golden rule ("observability never breaks the
    observed") applies to the CLI too — a user who ran `agentsonar demo`
    and hit a disk-full / OOM / weird-platform error should see a clean
    one-liner, not 30 lines of stack trace.
    """
    from agentsonar import __main__ as cli_main

    def _raise(**_kwargs):
        raise RuntimeError("simulated catastrophic failure")

    # Patch run_demo inside the lazy-imported _demo module so main()'s
    # `from agentsonar._demo import run_demo` resolves to the mock.
    monkeypatch.setattr("agentsonar._demo.run_demo", _raise)

    rc = cli_main.main(["demo"])
    assert rc == 1, "main() must return nonzero on unexpected exception"

    captured = capsys.readouterr()
    # Clean error message — NOT a raw traceback.
    assert "Unexpected error" in captured.err
    assert "RuntimeError" in captured.err
    assert "simulated catastrophic failure" in captured.err
    # Without AGENTSONAR_DEBUG, the traceback should NOT be printed.
    assert 'File "' not in captured.err, (
        "Traceback should be suppressed unless AGENTSONAR_DEBUG=1 — "
        "users running a CLI shouldn't see stack frames by default"
    )


def test_main_keyboard_interrupt_returns_130(monkeypatch, capsys):
    """KeyboardInterrupt (Ctrl-C) during the demo prints a friendly
    message and returns 130 (the standard Unix exit code for SIGINT,
    128 + 2). Without the catch, KeyboardInterrupt would propagate as
    a raw traceback.
    """
    from agentsonar import __main__ as cli_main

    def _raise_interrupt(**_kwargs):
        raise KeyboardInterrupt()

    monkeypatch.setattr("agentsonar._demo.run_demo", _raise_interrupt)

    rc = cli_main.main(["demo"])
    assert rc == 130

    captured = capsys.readouterr()
    assert "Interrupted" in captured.err
    assert "Traceback" not in captured.err


def test_main_debug_env_var_prints_traceback(monkeypatch, capsys):
    """When AGENTSONAR_DEBUG=1, main()'s outer catch DOES print the
    full traceback so developers can diagnose. Without the env var the
    traceback is suppressed (verified by the test above)."""
    from agentsonar import __main__ as cli_main

    def _raise(**_kwargs):
        raise RuntimeError("diagnostic test")

    monkeypatch.setattr("agentsonar._demo.run_demo", _raise)
    monkeypatch.setenv("AGENTSONAR_DEBUG", "1")

    rc = cli_main.main(["demo"])
    assert rc == 1

    captured = capsys.readouterr()
    # The traceback's `File "..."` line is the standard signature.
    assert 'File "' in captured.err
    assert "RuntimeError: diagnostic test" in captured.err
