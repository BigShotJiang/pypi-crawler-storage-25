"""Pytest configuration shared across the AgentSonar test suite.

Currently does one thing: disable session-event telemetry for the entire
test run. Pytest imports conftest.py before any test module, so by the
time a test constructs a `DetectionEngine`, the env var is already set
and telemetry skips its work cleanly.

Without this:
- Every test that constructs a DetectionEngine would print the first-run
  disclosure message to stderr, cluttering test output.
- The state file at ~/.agentsonar/state.json would be created on the
  developer's machine just from running the tests.
- A daemon thread would fire a fire-and-forget HTTP request that
  silently fails (no endpoint reachable from test environments).

Set `AGENTSONAR_TELEMETRY=on` explicitly if you ever need to test the
telemetry path itself.
"""
from __future__ import annotations

import os

os.environ.setdefault("AGENTSONAR_TELEMETRY", "off")
