"""
Regression tests for Prevent Mode — opt-in auto-raise on tracked
coordination failures.

Prevent Mode is the "control-plane" half of AgentSonar. Default
behavior is unchanged (Detect Mode: emit alerts, never raise).
When the user opts in via `prevent={...}` config, the adapter
auto-raises `PreventError` to terminate the host loop on a
tripped failure.

Covered:
  * Prevent disabled (default) — never raises
  * Default mode (`prevent={"cyclic_delegation": True}`) — trips on CRITICAL
  * Custom `max_rotations` — trips at the user's threshold
  * Auto-lower of warning_threshold so max_rotations actually applies
  * `raise: False` escape hatch — returns result, never raises
  * PreventionResult fields populated from the cycle alert
  * PreventError convenience attrs mirror the prevention
  * Bad prevent config shapes (string, list, garbage) — silently disabled
  * Unknown failure classes (future enums) — silently ignored
  * Caller can recover after PreventError — adapter API still functional
"""
from __future__ import annotations

import pytest

from agentsonar import (
    PreventError,
    PreventionResult,
    monitor_orchestrator,
)


def _drive_cycle(adapter, rotations: int) -> None:
    """Run a 3-node cycle (a -> b -> c -> a) for `rotations` iterations."""
    for _ in range(rotations):
        adapter.delegation("a", "b")
        adapter.delegation("b", "c")
        adapter.delegation("c", "a")


def _adapter(prevent=None, **extra):
    """Build a monitor_orchestrator() with file/console output silenced."""
    cfg = {
        "console_output": False,
        "file_output": False,
        "warning_threshold": 5,
        "critical_threshold": 15,
    }
    cfg.update(extra)
    if prevent is not None:
        cfg["prevent"] = prevent
    return monitor_orchestrator(config=cfg)


# ---------------------------------------------------------------------------
# Default behavior — Prevent Mode is OPT-IN
# ---------------------------------------------------------------------------

def test_no_prevent_config_never_raises():
    """Without `prevent={...}`, the adapter is in pure detect mode and
    must never raise — same contract as before Prevent Mode shipped."""
    adapter = _adapter()
    try:
        # Burn through enough cycles to hit CRITICAL severity
        _drive_cycle(adapter, 30)
    finally:
        adapter.shutdown()


def test_should_prevent_returns_none_when_disabled():
    adapter = _adapter()
    try:
        _drive_cycle(adapter, 30)
        assert adapter.engine.should_prevent() is None
        assert adapter.engine.check_prevent() is None
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# Default mode — trip on CRITICAL severity
# ---------------------------------------------------------------------------

def test_default_mode_trips_on_critical():
    """`prevent={"cyclic_delegation": True}` trips when the cycle alert
    reaches CRITICAL severity (== critical_threshold rotations)."""
    adapter = _adapter(
        prevent={"cyclic_delegation": True},
        warning_threshold=2,
        critical_threshold=5,
    )
    caught = None
    try:
        try:
            _drive_cycle(adapter, 30)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None, "expected PreventError on CRITICAL trip"
    assert caught.severity == "CRITICAL"
    assert caught.failure_class == "cyclic_delegation"


def test_default_mode_skips_warning_alerts():
    """Default mode MUST NOT trip on WARNING — only CRITICAL.
    With critical_threshold=100, no trip should happen even at 30 rotations."""
    adapter = _adapter(
        prevent={"cyclic_delegation": True},
        warning_threshold=2,
        critical_threshold=100,
    )
    raised = False
    try:
        try:
            _drive_cycle(adapter, 30)
        except PreventError:
            raised = True
    finally:
        adapter.shutdown()
    assert not raised


# ---------------------------------------------------------------------------
# Custom max_rotations override
# ---------------------------------------------------------------------------

def test_max_rotations_trips_at_user_threshold():
    """`max_rotations: 3` trips at exactly 3 rotations regardless of
    WARNING/CRITICAL severity."""
    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 3}},
        critical_threshold=100,  # high — proves trip is via rotations, not severity
    )
    caught = None
    try:
        try:
            _drive_cycle(adapter, 30)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None
    assert caught.rotations == 3, f"expected exactly 3, got {caught.rotations}"


def test_max_rotations_auto_lowers_cycle_warning_threshold():
    """If max_rotations < cycle_warning_threshold, the engine auto-lowers
    cycle_warning_threshold so alerts emit early enough for trip detection.

    Behavior in 0.4.3+: the auto-lower is scoped to the cycle threshold
    (Prevent Mode only configures cyclic_delegation today). Pre-0.4.3
    this lowered the GENERIC `warning_threshold`, which silently
    affected edge_anomaly alerts too. The new scope is more precise.
    """
    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 2}},
        warning_threshold=10,
    )
    try:
        # Cycle threshold lowered to match max_rotations
        assert adapter.engine._cycle_warning_threshold == 2
        # Generic threshold UNCHANGED (since 0.4.3 — the override is
        # scoped to the cycle pattern, not all patterns).
        assert adapter.engine._warning_threshold == 10
    finally:
        adapter.shutdown()


def test_max_rotations_does_not_raise_cycle_warning_threshold():
    """If max_rotations >= cycle_warning_threshold, leave it alone."""
    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 50}},
        warning_threshold=5,
    )
    try:
        assert adapter.engine._cycle_warning_threshold == 5  # unchanged
        assert adapter.engine._warning_threshold == 5
    finally:
        adapter.shutdown()


def test_max_rotations_above_critical_threshold_trips_at_max(_=None):
    """B1 regression — max_rotations > critical_threshold must trip at the
    user's max_rotations, NOT wait for the alert state machine's
    opportunistic re-alert path. Uses live `_alert_mgr._tracked` rotation
    count instead of the stale value frozen in the alert."""
    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 20}},
        warning_threshold=5,
        critical_threshold=10,
    )
    caught = None
    try:
        try:
            _drive_cycle(adapter, 30)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None
    # Trip MUST be at exactly 20 (or extremely close — <=22 to allow
    # for the small overshoot caused by check_prevent firing only
    # after the post-ingest delegation completes).
    assert caught.rotations >= 20, f"too early: {caught.rotations}"
    assert caught.rotations <= 22, (
        f"trip happened way after max_rotations=20 — looks like the "
        f"old _recent_alerts-only path (got rotations={caught.rotations})"
    )


def test_negative_max_rotations_clamps_to_one():
    """B2 regression — negative max_rotations must NOT propagate into
    warning_threshold as a negative number."""
    adapter = _adapter(prevent={"cyclic_delegation": {"max_rotations": -5}})
    try:
        cfg = adapter.engine._prevent_classes["cyclic_delegation"]
        assert cfg["max_rotations"] == 1, f"expected 1, got {cfg['max_rotations']}"
        # And warning_threshold should be clamped consequence-wise
        assert adapter.engine._warning_threshold >= 1
    finally:
        adapter.shutdown()


def test_zero_max_rotations_clamps_to_one():
    """max_rotations=0 also gets clamped to 1 (treats as 'trip on first alert')."""
    adapter = _adapter(prevent={"cyclic_delegation": {"max_rotations": 0}})
    try:
        cfg = adapter.engine._prevent_classes["cyclic_delegation"]
        assert cfg["max_rotations"] == 1
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# Escape hatch — raise: False
# ---------------------------------------------------------------------------

def test_raise_false_does_not_raise():
    """`raise: False` — adapter keeps running; user must poll
    engine.should_prevent() themselves."""
    adapter = _adapter(
        prevent={"cyclic_delegation": True, "raise": False},
        warning_threshold=2,
        critical_threshold=5,
    )
    raised = False
    try:
        try:
            _drive_cycle(adapter, 30)
        except PreventError:
            raised = True
        result = adapter.engine.should_prevent()
        assert isinstance(result, PreventionResult)
        assert result.failure_class == "cyclic_delegation"
        assert result.rotations >= 5
    finally:
        adapter.shutdown()
    assert not raised, "raise:False must never raise"


def test_check_prevent_returns_result_when_raise_false():
    """`check_prevent()` returns the PreventionResult instead of raising
    when `raise: False`."""
    adapter = _adapter(
        prevent={"cyclic_delegation": True, "raise": False},
        warning_threshold=2,
        critical_threshold=5,
    )
    try:
        _drive_cycle(adapter, 30)
        result = adapter.engine.check_prevent()
        assert isinstance(result, PreventionResult)
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# PreventionResult shape
# ---------------------------------------------------------------------------

def test_prevention_result_carries_full_cycle_path():
    adapter = _adapter(prevent={"cyclic_delegation": {"max_rotations": 3}})
    caught = None
    try:
        try:
            _drive_cycle(adapter, 10)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None
    assert isinstance(caught.prevention, PreventionResult)
    # Cycle path order can start anywhere on the cycle, but must be
    # the same set of agents.
    assert set(caught.prevention.cycle_path) == {"a", "b", "c"}
    assert caught.prevention.rotations >= 3
    assert caught.prevention.severity in ("WARNING", "CRITICAL")
    assert caught.prevention.timestamp > 0
    assert caught.prevention.failure_class == "cyclic_delegation"


def test_prevention_result_is_immutable():
    """Frozen dataclass — callers cannot mutate engine state via the result."""
    adapter = _adapter(prevent={"cyclic_delegation": {"max_rotations": 3}})
    caught = None
    try:
        try:
            _drive_cycle(adapter, 10)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None
    with pytest.raises((TypeError, AttributeError)):
        caught.prevention.rotations = 99  # type: ignore[misc]


def test_prevent_error_attrs_mirror_prevention():
    """PreventError exposes prevention's fields directly so callers can
    write `e.cycle_path` instead of `e.prevention.cycle_path`."""
    adapter = _adapter(prevent={"cyclic_delegation": {"max_rotations": 3}})
    caught = None
    try:
        try:
            _drive_cycle(adapter, 10)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None
    p = caught.prevention
    assert caught.failure_class == p.failure_class
    assert caught.reason == p.reason
    assert caught.cycle_path == list(p.cycle_path)
    assert caught.rotations == p.rotations
    assert caught.severity == p.severity
    assert caught.timestamp == p.timestamp


# ---------------------------------------------------------------------------
# Bad inputs — never crash the host
# ---------------------------------------------------------------------------

def test_garbage_prevent_value_silently_disables():
    """Strings, lists, ints, etc. for the prevent value should silently
    disable Prevent Mode without crashing the engine into NoOp."""
    for bad in ["yes", ["cyclic_delegation"], 42, 3.14]:
        adapter = monitor_orchestrator(config={
            "console_output": False,
            "file_output": False,
            "prevent": bad,
        })
        try:
            # Engine should still be the real DetectionEngine — Prevent
            # mode is just disabled.
            assert adapter.engine.should_prevent() is None
            # Detection still works
            adapter.delegation("a", "b")
        finally:
            adapter.shutdown()


def test_garbage_failure_class_value_silently_disables():
    """If `cyclic_delegation` value is neither True nor a dict — silently disable."""
    adapter = monitor_orchestrator(config={
        "console_output": False,
        "file_output": False,
        "prevent": {"cyclic_delegation": "tripwire"},  # invalid
    })
    try:
        assert adapter.engine.should_prevent() is None
    finally:
        adapter.shutdown()


def test_garbage_max_rotations_value_silently_disables_threshold():
    """A non-numeric max_rotations falls back to None (CRITICAL severity)."""
    adapter = monitor_orchestrator(config={
        "console_output": False,
        "file_output": False,
        "warning_threshold": 2,
        "critical_threshold": 5,
        "prevent": {"cyclic_delegation": {"max_rotations": "abc"}},
    })
    try:
        # Engine still works; falls back to CRITICAL-severity gating.
        cfg = adapter.engine._prevent_classes.get("cyclic_delegation")
        assert cfg is not None
        assert cfg.get("max_rotations") is None
    finally:
        adapter.shutdown()


def test_unknown_failure_class_silently_ignored():
    """Future failure classes the user types early shouldn't crash."""
    adapter = monitor_orchestrator(config={
        "console_output": False,
        "file_output": False,
        "prevent": {"deadlock": True, "cyclic_delegation": True},
    })
    try:
        # 'deadlock' is unrecognized — only 'cyclic_delegation' is wired up
        assert "deadlock" not in adapter.engine._prevent_classes
        assert "cyclic_delegation" in adapter.engine._prevent_classes
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# Loop semantics
# ---------------------------------------------------------------------------

def test_caller_can_recover_after_prevent_error():
    """User catches PreventError, calls shutdown — no further crashes."""
    adapter = _adapter(prevent={"cyclic_delegation": {"max_rotations": 3}})
    try:
        with pytest.raises(PreventError):
            _drive_cycle(adapter, 30)
        # post-trip: adapter API still works
        summary = adapter.get_summary()
        assert summary["alerts_raised"] >= 1
    finally:
        adapter.shutdown()


def test_prevent_error_subclasses_exception():
    """PreventError must be catchable as `except Exception` for users
    who already have broad catches in their orchestrator loop."""
    assert issubclass(PreventError, Exception)


def test_prevent_mode_emits_prevention_event_with_live_rotations():
    """Regression: when Prevent Mode trips between alert-emission boundaries
    (e.g. max_rotations is HIGHER than critical_threshold + re_alert_interval
    won't have fired by the trip), the report should still show the actual
    trip rotation count — not the last alert's stale count.

    Verifies:
      1. A CoordinationEvent with event_type='prevention' is appended to
         _recent_events on the first PreventError raise.
      2. Its `topology.occurrence_count` matches the live rotation count
         from the trip (not the last cycle alert's frozen value).
      3. Calling delegation again after the catch does NOT create a second
         prevention event (one-shot _prevent_event_emitted flag).
    """
    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 25}},
        warning_threshold=5,
        critical_threshold=10,  # alerts fire at 5 + 10; trip fires at 25
    )
    caught = None
    try:
        try:
            _drive_cycle(adapter, 30)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()

    assert caught is not None, "trip never fired"

    # Find the prevention event among _recent_events
    events = adapter.engine.get_recent_events()
    prevention_events = [e for e in events if e.event_type == "prevention"]
    assert len(prevention_events) == 1, (
        f"expected exactly 1 prevention event, got {len(prevention_events)}"
    )
    pe = prevention_events[0]
    # The trip rotation should be >= max_rotations (25), not the last alert's
    # frozen count (which was 10 at CRITICAL).
    assert pe.topology is not None
    assert pe.topology.occurrence_count >= 25, (
        f"prevention event undercounts rotations: {pe.topology.occurrence_count} "
        f"(expected >= 25 from max_rotations override)"
    )
    assert "Prevent Mode tripped" in pe.summary
    assert pe.failure_class.value == "cyclic_delegation"
    assert pe.severity.value == "CRITICAL"


def test_chronological_log_keeps_alert_row_coloring_after_prevention_dedup():
    """Regression: the synthetic prevention event uses time.time() as its
    timestamp so it wins dedup-by-fingerprint. But the Chronological Log
    row coloring matches alert timestamps against session log delegation
    timestamps. If we computed the alert-timestamp map from the deduped
    event list, only the prevention event's (artificial) timestamp would
    end up there — and no log row would get colored, even though many
    alerts actually fired. This test verifies the renderer computes the
    map from the PRE-DEDUP event list so all WARNING/CRITICAL alerts
    contribute to row coloring."""
    from agentsonar._output.html_report import (
        _compute_alert_timestamps_by_severity,
    )

    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 25}},
        warning_threshold=5,
        critical_threshold=10,
    )
    try:
        try:
            _drive_cycle(adapter, 30)
        except PreventError:
            pass
    finally:
        adapter.shutdown()

    events = adapter.engine.get_recent_events()

    # Sanity: the run produced multiple alerts (WARNING@5, CRITICAL@10,
    # plus possibly re-alerts and the synthetic prevention event).
    sev_counts = {}
    for e in events:
        sev_counts[e.severity.value] = sev_counts.get(e.severity.value, 0) + 1
    assert sev_counts.get("WARNING", 0) >= 1, "expected at least 1 WARNING"
    assert sev_counts.get("CRITICAL", 0) >= 2, (
        "expected at least 2 CRITICALs (real alert + prevention event)"
    )

    # The map computed from the FULL event list must contain MORE
    # timestamps than just the prevention event's. Specifically: each
    # WARNING and CRITICAL alert with a real delegation timestamp should
    # contribute. The prevention event itself is filtered out by
    # _compute_alert_timestamps_by_severity.
    ts_map = _compute_alert_timestamps_by_severity(events)
    assert len(ts_map) >= 2, (
        f"chronological log row coloring is broken: only {len(ts_map)} "
        f"timestamps in map, expected >= 2 (one per alert that fired)"
    )
    # Ensure the prevention event's synthetic time.time() didn't sneak in:
    # all timestamps should match a delegation event from the run, not be
    # close to the shutdown moment.
    prevention_events = [e for e in events if e.event_type == "prevention"]
    if prevention_events:
        prev_ts = prevention_events[0].timestamp
        assert prev_ts not in ts_map, (
            "prevention event's synthetic timestamp leaked into the alert "
            "timestamp map — would have caused the chronological log to "
            "lose row coloring"
        )


def test_edge_activity_alert_counts_after_prevention_dedup():
    """Regression: same root-cause as the chronological log fix, but for
    the Edge Activity tab. The synthetic prevention event has empty
    `topology.edge_frequency` and wins dedup-by-fingerprint, so if the
    edge-activity enrichment runs on the deduped event list, every
    edge's alert count zeroes out (showing "NO ALERTS" in the UI even
    when the run had multiple critical alerts). The HTML renderer must
    enrich from the PRE-DEDUP event list so edge alert counts reflect
    the full alert history."""
    from agentsonar._output.html_report import (
        _enrich_edge_activity_by_severity,
    )

    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 25}},
        warning_threshold=5,
        critical_threshold=10,
    )
    try:
        try:
            _drive_cycle(adapter, 30)
        except PreventError:
            pass
    finally:
        adapter.shutdown()

    events = adapter.engine.get_recent_events()

    # Simulate edge_activity records the engine would normally pass to
    # the renderer (the actual engine builds them from coord_graph;
    # here we synthesize the minimum shape the enricher reads).
    edge_activity = [
        {"source": "a", "target": "b", "count": 30,
         "first_ts": 0.0, "last_ts": 1.0, "alert_count": 0},
        {"source": "b", "target": "c", "count": 30,
         "first_ts": 0.0, "last_ts": 1.0, "alert_count": 0},
        {"source": "c", "target": "a", "count": 30,
         "first_ts": 0.0, "last_ts": 1.0, "alert_count": 0},
    ]

    # OLD (broken) behavior — pass the deduped survivor only:
    deduped = [e for e in events if e.event_type == "prevention"]
    enriched_broken = _enrich_edge_activity_by_severity(edge_activity, deduped)
    # Sanity: the broken path zeroes out everything (this is the bug we're guarding against)
    assert all(r["critical_count"] == 0 for r in enriched_broken), (
        "test setup is wrong — deduped path should zero everything"
    )

    # NEW (fixed) behavior — pass the pre-dedup, INFO-filtered, prevention-
    # filtered list, matching what _render_html does:
    enrich_source = [
        e for e in events
        if e.severity.value in ("CRITICAL", "WARNING")
        and e.event_type != "prevention"
    ]
    enriched_fixed = _enrich_edge_activity_by_severity(edge_activity, enrich_source)
    total_critical = sum(r["critical_count"] for r in enriched_fixed)
    total_warning = sum(r["warning_count"] for r in enriched_fixed)
    assert total_critical >= 1, (
        f"edge activity should show at least one CRITICAL after fix, "
        f"got total_critical={total_critical}"
    )
    # All three edges of the cycle should have non-zero alert attribution
    edges_with_alerts = sum(
        1 for r in enriched_fixed
        if r["critical_count"] + r["warning_count"] > 0
    )
    assert edges_with_alerts >= 1, (
        "at least one edge should be attributed to alerts after the fix"
    )


def test_prevention_event_emitted_only_once_across_repeated_trips():
    """Regression: subsequent delegations after a caught PreventError
    re-raise (documented behavior), but must NOT spam _recent_events with
    duplicate prevention entries — the report should show one trip, not N."""
    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 5}},
    )
    # First trip
    try:
        _drive_cycle(adapter, 20)
    except PreventError:
        pass
    # Subsequent trips (user catches and naively continues)
    for _ in range(3):
        try:
            _drive_cycle(adapter, 5)
        except PreventError:
            pass
    adapter.shutdown()

    events = adapter.engine.get_recent_events()
    prevention_events = [e for e in events if e.event_type == "prevention"]
    assert len(prevention_events) == 1, (
        f"prevention event spam: {len(prevention_events)} entries"
    )


def test_prevented_line_written_to_alerts_log():
    """Regression: when Prevent Mode trips, the human-readable
    `alerts.log` should get a 🛑 PREVENTED line, mirroring the trip
    in the HTML report. Otherwise the chronological signal log is
    incomplete — users would see WARNING/CRITICAL alerts but no
    indication that prevent actually fired."""
    import os
    import tempfile
    tmp = tempfile.mkdtemp(prefix="agentsonar_prev_log_")
    try:
        sonar = monitor_orchestrator(config={
            "console_output": False,
            "file_output": True,
            "log_dir": tmp,
            "warning_threshold": 2,
            "critical_threshold": 5,
            "prevent": {"cyclic_delegation": True},
        })
        try:
            for _ in range(20):
                sonar.delegation("a", "b")
                sonar.delegation("b", "c")
                sonar.delegation("c", "a")
        except PreventError:
            pass
        sonar.shutdown()

        logs_root = os.path.join(tmp, "agentsonar_logs")
        run_dirs = [
            os.path.join(logs_root, d) for d in os.listdir(logs_root)
            if d.startswith("run-")
        ]
        assert run_dirs
        alerts_path = os.path.join(run_dirs[0], "alerts.log")
        with open(alerts_path, encoding="utf-8") as f:
            content = f.read()
        assert "PREVENTED" in content, (
            f"alerts.log missing the PREVENTED line. Content was:\n{content}"
        )
        assert "cyclic_delegation" in content
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def test_prevention_event_has_matching_fingerprint_when_scc_alert_wins():
    """Regression: when both Layer 3 (cycle) and Layer 5 (SCC) fire for
    the SAME cycle, scc_cycle is appended to _recent_alerts AFTER the
    cycle alert. should_prevent() walks reverse-chronologically, so it
    sees the scc_cycle alert FIRST. scc_cycle alerts must include
    cycle_path in their details (or fall back to `agents`) so the
    PreventionResult carries the right agent set, the prevention event's
    fingerprint matches the cycle alert's fingerprint, and dedupe
    collapses them into one card with the 🛑 PREVENTED badge.

    Without this, the report renders TWO cards instead of one — the
    detected cycle (3 agents) and a phantom 'unknown' prevention event."""
    adapter = _adapter(
        prevent={"cyclic_delegation": {"max_rotations": 3}},
        warning_threshold=2,
        critical_threshold=3,
        # Force the SCC analyzer to run alongside the cycle detector so
        # both paths emit alerts for the same fingerprint.
        scc_interval_events=1,
    )
    caught = None
    try:
        try:
            _drive_cycle(adapter, 10)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None

    events = adapter.engine.get_recent_events()
    cycle_events = [
        e for e in events
        if e.failure_class.value == "cyclic_delegation"
        and e.event_type != "prevention"
    ]
    prevention_events = [e for e in events if e.event_type == "prevention"]
    assert len(prevention_events) == 1, (
        f"expected 1 prevention event, got {len(prevention_events)}"
    )
    assert len(cycle_events) >= 1

    # The prevention event's fingerprint MUST match at least one of the
    # cycle-alert fingerprints. If they diverge (the bug we're guarding),
    # dedupe-by-fingerprint produces two cards instead of one.
    pe = prevention_events[0]
    cycle_fps = {e.coordination_fingerprint for e in cycle_events}
    assert pe.coordination_fingerprint in cycle_fps, (
        f"prevention event fingerprint {pe.coordination_fingerprint} "
        f"doesn't match any cycle event fingerprint {cycle_fps}. "
        f"This means the prevent card will render separately from the "
        f"cycle card in the HTML report — two cards instead of one."
    )
    # And the agents set should not be ['unknown'] — it should be the
    # real agents from the cycle.
    assert pe.topology is not None
    agents_in_topology = set(pe.topology.agents_involved)
    assert "unknown" not in agents_in_topology
    assert len(agents_in_topology) >= 2


def test_prevent_error_pickles_round_trip():
    """PreventError must survive pickle/unpickle so users can log it
    via libraries that serialize exception state (Sentry, structured
    log forwarders, multiprocessing handoff)."""
    import pickle
    adapter = _adapter(prevent={"cyclic_delegation": {"max_rotations": 3}})
    caught = None
    try:
        try:
            _drive_cycle(adapter, 10)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None
    restored = pickle.loads(pickle.dumps(caught))
    assert isinstance(restored, PreventError)
    assert restored.failure_class == caught.failure_class
    assert restored.cycle_path == caught.cycle_path
    assert restored.rotations == caught.rotations
    assert restored.severity == caught.severity


def test_prevention_result_pickles_round_trip():
    import pickle
    adapter = _adapter(prevent={"cyclic_delegation": {"max_rotations": 3}})
    caught = None
    try:
        try:
            _drive_cycle(adapter, 10)
        except PreventError as e:
            caught = e
    finally:
        adapter.shutdown()
    assert caught is not None
    restored = pickle.loads(pickle.dumps(caught.prevention))
    assert restored == caught.prevention


# ---------------------------------------------------------------------------
# LangGraph integration — Prevent Mode via the AgentSonarCallback
# ---------------------------------------------------------------------------
# Skip the LangGraph block if langchain-core / langgraph aren't installed.
# The callback class itself raises a clean RuntimeError at construction
# time when the optional extra is missing; we catch that here and skip.

langchain_core = pytest.importorskip("langchain_core")
langgraph_core = pytest.importorskip("langgraph")

import operator  # noqa: E402
from typing import Any, Literal  # noqa: E402

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage  # noqa: E402
from langgraph.graph import END, START, StateGraph  # noqa: E402
from typing_extensions import Annotated, TypedDict  # noqa: E402

from agentsonar import AgentSonarCallback, monitor  # noqa: E402


class _LGState(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]
    iteration: int


def _build_infinite_cycle_graph():
    """A 3-node cycle that loops without an exit condition.
    Without Prevent Mode it would run until `recursion_limit` is hit.
    """
    def planner(s: _LGState):
        return {"messages": [AIMessage(content="plan")]}

    def researcher(s: _LGState):
        return {"messages": [AIMessage(content="research")]}

    def reviewer(s: _LGState):
        return {
            "messages": [AIMessage(content="revise")],
            "iteration": s.get("iteration", 0) + 1,
        }

    def loop(s: _LGState) -> Literal["planner"]:
        # Always loop — never returns END. Prevent Mode is the
        # only thing that can stop this run cleanly.
        return "planner"

    b = StateGraph(_LGState)
    b.add_node("planner", planner)
    b.add_node("researcher", researcher)
    b.add_node("reviewer", reviewer)
    b.add_edge(START, "planner")
    b.add_edge("planner", "researcher")
    b.add_edge("researcher", "reviewer")
    b.add_conditional_edges("reviewer", loop)
    return b.compile()


def _chain_start(cb: AgentSonarCallback, node: str, step: int) -> None:
    """Simulate a LangGraph on_chain_start event (unit-level helper)."""
    cb.on_chain_start(
        serialized={"name": node},
        inputs={},
        metadata={"langgraph_node": node, "langgraph_step": step},
    )


# Unit-level: callback raises PreventError on the right call

def test_langgraph_callback_raises_prevent_error_on_cycle():
    cb = AgentSonarCallback(config={
        "console_output": False, "file_output": False,
        "warning_threshold": 2, "critical_threshold": 5,
        "prevent": {"cyclic_delegation": True},
    })
    caught = None
    try:
        # Drive a 3-node cycle until it trips
        for i in range(30):
            try:
                _chain_start(cb, "a", i * 3)
                _chain_start(cb, "b", i * 3 + 1)
                _chain_start(cb, "c", i * 3 + 2)
            except PreventError as e:
                caught = e
                break
    finally:
        cb.shutdown()
    assert caught is not None
    assert caught.severity == "CRITICAL"


def test_langgraph_callback_no_prevent_config_keeps_default_behavior():
    """Without prevent config, raise_error MUST stay False so callback
    exceptions are swallowed (preserves host safety for the 95% case)."""
    cb = AgentSonarCallback(config={
        "console_output": False, "file_output": False,
    })
    try:
        # raise_error is the LangChain attribute that controls propagation
        assert getattr(cb, "raise_error", False) is False
    finally:
        cb.shutdown()


def test_langgraph_callback_raise_error_set_when_prevent_enabled():
    """With prevent config, raise_error must be True so PreventError
    propagates through CallbackManager to graph.invoke()."""
    cb = AgentSonarCallback(config={
        "console_output": False, "file_output": False,
        "prevent": {"cyclic_delegation": True},
    })
    try:
        assert cb.raise_error is True
    finally:
        cb.shutdown()


# End-to-end: PreventError propagates through graph.invoke()

def test_langgraph_prevent_mode_e2e_via_callback():
    """The hardest case — does PreventError actually escape through
    LangChain's CallbackManager to the user's try/except?"""
    graph = _build_infinite_cycle_graph()
    cb = AgentSonarCallback(config={
        "console_output": False, "file_output": False,
        "warning_threshold": 2, "critical_threshold": 5,
        "prevent": {"cyclic_delegation": True},
    })
    caught = None
    try:
        try:
            graph.invoke(
                {"messages": [HumanMessage(content="go")], "iteration": 0},
                config={"callbacks": [cb], "recursion_limit": 100},
            )
        except PreventError as e:
            caught = e
    finally:
        cb.shutdown()
    assert caught is not None, "PreventError did not propagate through graph.invoke()"
    assert caught.failure_class == "cyclic_delegation"
    assert caught.severity == "CRITICAL"


def test_langgraph_prevent_mode_e2e_via_monitor_wrapper():
    """Same end-to-end test but through the recommended `monitor()` API."""
    graph = _build_infinite_cycle_graph()
    monitored = monitor(graph, config={
        "console_output": False, "file_output": False,
        "warning_threshold": 2, "critical_threshold": 5,
        "prevent": {"cyclic_delegation": True},
    })
    caught = None
    try:
        try:
            monitored.invoke(
                {"messages": [HumanMessage(content="go")], "iteration": 0},
                config={"recursion_limit": 100},
            )
        except PreventError as e:
            caught = e
    finally:
        monitored.shutdown()
    assert caught is not None, "PreventError did not propagate via monitor()"
    assert caught.failure_class == "cyclic_delegation"


def test_langgraph_default_mode_does_not_raise_into_host():
    """Sanity: WITHOUT prevent config, even on a runaway cycle, no
    exception escapes to the host's try/except — only LangGraph's own
    GraphRecursionError once recursion_limit is hit."""
    graph = _build_infinite_cycle_graph()
    monitored = monitor(graph, config={
        "console_output": False, "file_output": False,
    })
    saw_prevent = False
    try:
        try:
            monitored.invoke(
                {"messages": [HumanMessage(content="go")], "iteration": 0},
                config={"recursion_limit": 6},  # tight cap to exit fast
            )
        except PreventError:
            saw_prevent = True
        except Exception:
            # GraphRecursionError or similar — fine, that's LangGraph's own
            # plumbing, not us.
            pass
    finally:
        monitored.shutdown()
    assert not saw_prevent, "Detection-only mode raised PreventError (should never)"
