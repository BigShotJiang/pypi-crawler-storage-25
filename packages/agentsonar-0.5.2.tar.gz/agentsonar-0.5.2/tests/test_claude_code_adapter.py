"""
Tests for the Claude Code adapter (`agentsonar._integrations.claude`).

Coverage groups:
  1. Hook payload parsing
  2. Content-blind extraction (load-bearing privacy claim)
  3. Edge translation (source_agent, target_agent, Task spawn shape)
  4. State persistence (load, save, corruption recovery, file lock)
  5. Exit codes (host-safety contract: only Prevent trip is non-zero)
  6. Cumulative report regeneration on Stop
  7. Session boundary detection (new session_id, inactivity sweep)
  8. Subagent type registry
  9. timeline.jsonl protocol commitments (schema, append-only)
 10. AGENTSONAR_REGULATED path redaction
 11. The CONTENT-BLIND SENTINEL AUDIT (THE most-load-bearing test)

The sentinel audit (section 11) is the privacy claim's enforcement
point. It runs payloads that include unique canary strings as tool
input / tool response content, then greps EVERY file the adapter
wrote on disk for the sentinel. The adapter's content-blind contract
fails the moment the sentinel appears anywhere on disk.

Test isolation:
  Every test routes the adapter's state directory through a per-test
  tmp_path via the AGENTSONAR_CLAUDE_CODE_ROOT env var. No test
  pollutes the developer's real ~/.agentsonar/.
"""
from __future__ import annotations

import json
import os
import pickle
import sys
import threading
import time
from pathlib import Path
from typing import Any

import pytest

from agentsonar._integrations.claude import adapter as cc
from agentsonar._integrations.claude import (
    derive_source_agent,
    derive_target_agent,
    extract_metadata,
    handle_hook,
    resolve_root_session_id,
    run_hook,
    TIMELINE_SCHEMA_VERSION,
)


# =====================================================================
# Fixtures
# =====================================================================

@pytest.fixture(autouse=True)
def _isolate_adapter_state(tmp_path, monkeypatch):
    """Route AGENTSONAR_CLAUDE_CODE_ROOT to a per-test tmpdir.

    Every test gets a fresh state directory. No test touches the
    developer's real `~/.agentsonar/`. Also disables telemetry.
    """
    monkeypatch.setenv("AGENTSONAR_CLAUDE_CODE_ROOT", str(tmp_path))
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")
    # Ensure AGENTSONAR_REGULATED is NOT set unless a specific test
    # opts in (paths default to clear-text per Section 4.3).
    monkeypatch.delenv("AGENTSONAR_REGULATED", raising=False)
    yield tmp_path


def _payload(
    *,
    session_id: str = "session-root-1234",
    parent_session_id: str | None = None,
    tool_name: str = "Read",
    tool_input: Any | None = None,
    tool_response: Any | None = None,
    cwd: str = "/home/test",
    subagent_depth: int = 0,
) -> dict:
    """Build a Claude Code hook payload for tests."""
    if tool_input is None:
        tool_input = {"file_path": "/src/foo.py"}
    p: dict = {
        "session_id": session_id,
        "parent_session_id": parent_session_id,
        "tool_name": tool_name,
        "tool_input": tool_input,
        "cwd": cwd,
        "subagent_depth": subagent_depth,
    }
    if tool_response is not None:
        p["tool_response"] = tool_response
    return p


def _read_lines(path: Path) -> list[dict]:
    """Read all lines from `timeline.jsonl` and parse each as JSON."""
    if not path.exists():
        return []
    out: list[dict] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def _all_files_on_disk(root: Path) -> list[Path]:
    """Recursively list every file under `root`."""
    return [p for p in root.rglob("*") if p.is_file()]


# =====================================================================
# 1. Hook payload parsing
# =====================================================================

class TestHookPayloadParsing:

    def test_pretooluse_known_event_returns_0(self):
        rc = handle_hook("PreToolUse", _payload())
        assert rc == 0

    def test_posttooluse_known_event_returns_0(self):
        rc = handle_hook("PostToolUse", _payload(tool_response={"ok": True}))
        assert rc == 0

    def test_stop_known_event_returns_0(self):
        rc = handle_hook("Stop", _payload())
        assert rc == 0

    def test_subagentstop_known_event_returns_0(self):
        rc = handle_hook(
            "SubagentStop",
            _payload(
                session_id="subagent-aaaa",
                parent_session_id="root-1234",
            ),
        )
        assert rc == 0

    def test_unknown_event_name_returns_0_silently(self):
        rc = handle_hook("DefinitelyNotAHookEvent", _payload())
        assert rc == 0

    def test_userpromptsubmit_is_explicitly_ignored(self):
        rc = handle_hook("UserPromptSubmit", _payload())
        assert rc == 0
        # No state directory should be created for an ignored event.
        # (The session_id was set but we never reached session_dir.mkdir.)

    def test_notification_is_explicitly_ignored(self):
        rc = handle_hook("Notification", _payload())
        assert rc == 0

    def test_non_dict_payload_returns_0(self):
        rc = handle_hook("PreToolUse", "not a dict")
        assert rc == 0

    def test_run_hook_with_malformed_stdin_returns_0(self):
        import io
        bad_stdin = io.StringIO("{this is not json}")
        rc = run_hook("PreToolUse", stdin=bad_stdin)
        assert rc == 0

    def test_run_hook_with_empty_stdin_returns_0(self):
        import io
        rc = run_hook("PreToolUse", stdin=io.StringIO(""))
        assert rc == 0


# =====================================================================
# 2. Content-blind extraction
# =====================================================================

class TestContentBlindExtraction:

    def test_allowlist_fields_present(self):
        meta = extract_metadata(_payload(), hook_arrival_ts=1700000000.0)
        for key in (
            "tool_name", "input_fingerprint", "input_size_bytes",
            "output_size_bytes", "status", "session_id", "timestamp",
        ):
            assert key in meta, f"missing required key {key}"

    def test_fingerprint_stable_for_same_input(self):
        m1 = extract_metadata(
            _payload(tool_input={"file_path": "/x/y.py"}),
            hook_arrival_ts=1.0,
        )
        m2 = extract_metadata(
            _payload(tool_input={"file_path": "/x/y.py"}),
            hook_arrival_ts=2.0,
        )
        assert m1["input_fingerprint"] == m2["input_fingerprint"]

    def test_fingerprint_differs_for_different_input(self):
        m1 = extract_metadata(
            _payload(tool_input={"file_path": "/x/y.py"}),
            hook_arrival_ts=1.0,
        )
        m2 = extract_metadata(
            _payload(tool_input={"file_path": "/x/z.py"}),
            hook_arrival_ts=1.0,
        )
        assert m1["input_fingerprint"] != m2["input_fingerprint"]

    def test_subagent_type_is_hashed_not_clear(self):
        payload = _payload(
            tool_name="Task",
            tool_input={"subagent_type": "code-reviewer"},
        )
        meta = extract_metadata(payload, hook_arrival_ts=1.0)
        assert meta["subagent_type"] is not None
        # The hash must NOT contain the original label.
        assert "code-reviewer" not in meta["subagent_type"]

    def test_subagent_type_same_label_same_hash(self):
        meta_a = extract_metadata(
            _payload(tool_name="Task", tool_input={"subagent_type": "code-reviewer"}),
            hook_arrival_ts=1.0,
        )
        meta_b = extract_metadata(
            _payload(tool_name="Task", tool_input={"subagent_type": "code-reviewer"}),
            hook_arrival_ts=1.0,
        )
        assert meta_a["subagent_type"] == meta_b["subagent_type"]

    def test_target_path_extracted_for_path_bearing_tools(self):
        for tool in ("Read", "Edit", "Write", "MultiEdit", "NotebookEdit"):
            meta = extract_metadata(
                _payload(tool_name=tool, tool_input={"file_path": "/a/b.py"}),
                hook_arrival_ts=1.0,
            )
            assert meta.get("target_path") == "/a/b.py", f"{tool} missed target_path"

    def test_target_path_is_none_for_pathless_tools(self):
        """Pathless tools (Bash, Task, WebFetch) keep the target_path
        key on the record but set it to None. Stable-schema commitment
        for downstream consumers: keys are always present; absent
        values are explicit None."""
        for tool in ("Bash", "Task", "WebFetch"):
            meta = extract_metadata(
                _payload(tool_name=tool, tool_input={"command": "ls"}),
                hook_arrival_ts=1.0,
            )
            assert "target_path" in meta, f"{tool} missing target_path key"
            assert meta["target_path"] is None, (
                f"{tool} should have target_path=None, got {meta['target_path']}"
            )

    def test_mcp_tool_naming_convention_enriched(self):
        meta = extract_metadata(
            _payload(tool_name="mcp__github__create_issue", tool_input={"title": "x"}),
            hook_arrival_ts=1.0,
        )
        assert meta.get("mcp_server") == "github"

    def test_mcp_tool_segment_extracted_as_separate_metadata(self):
        """0.5.2: alongside mcp_server, the tool segment of
        mcp__<server>__<tool> is parsed into mcp_tool metadata. Both
        are content-blind (extracted from the tool_name string, which
        is already in the allowlist)."""
        meta = extract_metadata(
            _payload(tool_name="mcp__github__create_issue", tool_input={"title": "x"}),
            hook_arrival_ts=1.0,
        )
        assert meta.get("mcp_server") == "github"
        assert meta.get("mcp_tool") == "create_issue"

    def test_mcp_tool_segment_handles_underscores_in_tool_name(self):
        """The tool segment may itself contain underscores. The split
        is `mcp__<server>__<rest>` so the tool part can be multi-word."""
        meta = extract_metadata(
            _payload(
                tool_name="mcp__brand_new_server__do_a_thing_with_underscores",
                tool_input={},
            ),
            hook_arrival_ts=1.0,
        )
        assert meta.get("mcp_server") == "brand_new_server"
        assert meta.get("mcp_tool") == "do_a_thing_with_underscores"

    def test_non_mcp_tool_has_no_mcp_tool_field(self):
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/x"}),
            hook_arrival_ts=1.0,
        )
        assert "mcp_tool" not in meta
        assert "mcp_server" not in meta

    def test_non_mcp_tool_has_no_mcp_server_key(self):
        meta = extract_metadata(
            _payload(tool_name="Bash", tool_input={"command": "ls"}),
            hook_arrival_ts=1.0,
        )
        assert "mcp_server" not in meta

    def test_status_derived_from_response_shape(self):
        success = extract_metadata(
            _payload(tool_response={"result": "ok"}),
            hook_arrival_ts=1.0,
        )
        assert success["status"] == "success"
        error = extract_metadata(
            _payload(tool_response={"error": "boom"}),
            hook_arrival_ts=1.0,
        )
        assert error["status"] == "error"
        is_error = extract_metadata(
            _payload(tool_response={"is_error": True, "message": "x"}),
            hook_arrival_ts=1.0,
        )
        assert is_error["status"] == "error"

    def test_input_size_bytes_reflects_canonical_json_length(self):
        meta = extract_metadata(
            _payload(tool_input={"k": "v"}),
            hook_arrival_ts=1.0,
        )
        assert meta["input_size_bytes"] > 0

    def test_garbage_payload_does_not_raise(self):
        # Throw a kitchen sink of broken inputs at it.
        for bad in (None, "string", 42, [], {"tool_input": object()}):
            meta = extract_metadata(bad, hook_arrival_ts=1.0)  # type: ignore[arg-type]
            assert isinstance(meta, dict)


# =====================================================================
# 3. Edge translation
# =====================================================================

class TestEdgeTranslation:

    def test_root_session_source_is_main(self):
        assert derive_source_agent(_payload(parent_session_id=None)) == "main"

    def test_subagent_session_source_is_per_instance(self):
        p = _payload(
            session_id="abcdef1234567890",
            parent_session_id="root-xxx",
        )
        assert derive_source_agent(p) == "subagent_abcdef12"

    def test_two_subagents_same_type_have_distinct_source_agents(self):
        a = derive_source_agent(_payload(
            session_id="aaaaaaaa-1111",
            parent_session_id="root",
        ))
        b = derive_source_agent(_payload(
            session_id="bbbbbbbb-2222",
            parent_session_id="root",
        ))
        assert a != b

    def test_task_spawn_target_uses_subagent_type_when_present(self):
        meta = extract_metadata(
            _payload(tool_name="Task", tool_input={"subagent_type": "reviewer"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Task", meta)
        assert target.startswith("Task_spawn:")
        assert meta["subagent_type"][:8] in target

    def test_task_spawn_target_falls_back_to_input_fingerprint(self):
        meta = extract_metadata(
            _payload(tool_name="Task", tool_input={"description": "no subagent_type"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Task", meta)
        assert target.startswith("Task_spawn:")

    def test_normal_tool_target_uses_input_fingerprint(self):
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/x"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Read", meta)
        assert target.startswith("Read:")

    def test_path_bearing_tool_target_uses_file_path_not_fingerprint(self):
        """Demo-readability: Read on /src/hello.py shows as
        'Read:/src/hello.py', not 'Read:<8-char-hex>'. Same path always
        produces the same edge so Layer 2 detection still works."""
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/hello.py"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Read", meta)
        assert target == "Read:/src/hello.py", (
            f"path-bearing target should be path-based; got {target!r}"
        )
        for tool in ("Edit", "Write", "Grep", "Glob", "MultiEdit"):
            meta = extract_metadata(
                _payload(tool_name=tool, tool_input={"file_path": "/src/x.py"}),
                hook_arrival_ts=1.0,
            )
            target = derive_target_agent(tool, meta)
            assert target == f"{tool}:/src/x.py", (
                f"{tool} target should be path-based; got {target!r}"
            )

    def test_path_bearing_target_honors_regulated_redaction(self, monkeypatch):
        """Under AGENTSONAR_REGULATED, target_path is hashed, and the
        edge name picks up the hashed form. Detection still works
        because hashes are deterministic."""
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/secret.py"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Read", meta)
        assert target.startswith("Read:path:"), (
            f"regulated target should embed the hash form; got {target!r}"
        )
        assert "secret.py" not in target

    def test_non_path_tool_keeps_fingerprint_form(self):
        """Tools without target_path (Bash, MCP, WebFetch) still use
        the 8-char fingerprint tail. The fingerprint is the only stable
        structural identifier when no path is available, and we can't
        echo the command string (content-blind contract)."""
        for tool in ("Bash", "WebFetch", "mcp__github__create_issue"):
            meta = extract_metadata(
                _payload(tool_name=tool, tool_input={"command": "ls"}),
                hook_arrival_ts=1.0,
            )
            target = derive_target_agent(tool, meta)
            assert ":" in target
            tail = target.split(":", 1)[1]
            assert len(tail) == 8 and all(c in "0123456789abcdef" for c in tail), (
                f"{tool} target tail should be 8 hex chars; got {target!r}"
            )

    def test_resolve_root_session_id_returns_session_for_root(self):
        p = _payload(session_id="root-xyz", parent_session_id=None)
        assert resolve_root_session_id(p) == "root-xyz"

    def test_resolve_root_session_id_returns_parent_for_subagent(self):
        p = _payload(session_id="sub-xyz", parent_session_id="root-xyz")
        assert resolve_root_session_id(p) == "root-xyz"


# =====================================================================
# 4. State persistence
# =====================================================================

class TestStatePersistence:

    def test_first_hook_creates_session_dir(self, tmp_path):
        rc = handle_hook("PreToolUse", _payload(session_id="sid-new"))
        assert rc == 0
        assert (tmp_path / "sessions" / "sid-new" / "state.pkl").exists()
        assert (tmp_path / "sessions" / "sid-new" / "timeline.jsonl").exists()
        assert (tmp_path / "sessions" / "sid-new" / "last_hook_at").exists()

    def test_subsequent_hook_loads_existing_state(self, tmp_path):
        handle_hook("PreToolUse", _payload(session_id="sid-load"))
        state_path = tmp_path / "sessions" / "sid-load" / "state.pkl"
        first_mtime = state_path.stat().st_mtime
        time.sleep(0.05)
        handle_hook("PostToolUse", _payload(
            session_id="sid-load",
            tool_response={"ok": True},
        ))
        # state.pkl was rewritten.
        assert state_path.stat().st_mtime > first_mtime

    def test_corrupt_state_pkl_recovered(self, tmp_path):
        # Pre-populate with garbage.
        session_dir = tmp_path / "sessions" / "sid-corrupt"
        session_dir.mkdir(parents=True, exist_ok=True)
        (session_dir / "state.pkl").write_bytes(b"this is not a pickle")
        # Hook should still succeed.
        rc = handle_hook("PreToolUse", _payload(session_id="sid-corrupt"))
        assert rc == 0
        # State pkl was rewritten to a valid one.
        with open(session_dir / "state.pkl", "rb") as f:
            blob = pickle.load(f)
        assert isinstance(blob, dict)
        assert blob.get("schema_version") == TIMELINE_SCHEMA_VERSION

    def test_timeline_is_append_only(self, tmp_path):
        for _ in range(5):
            handle_hook("PreToolUse", _payload(session_id="sid-append"))
        timeline = tmp_path / "sessions" / "sid-append" / "timeline.jsonl"
        lines = _read_lines(timeline)
        assert len(lines) == 5
        for line in lines:
            assert line["schema_version"] == TIMELINE_SCHEMA_VERSION

    def test_state_pkl_atomic_rename_leaves_no_temp_files(self, tmp_path):
        for _ in range(10):
            handle_hook("PreToolUse", _payload(session_id="sid-atomic"))
        session_dir = tmp_path / "sessions" / "sid-atomic"
        leftover = list(session_dir.glob("state.pkl.tmp.*"))
        assert leftover == []

    def test_concurrent_hooks_do_not_corrupt_state(self, tmp_path):
        # Spawn N threads each firing K hooks. The shared state.pkl
        # must be parseable at the end and the timeline must have
        # exactly N*K lines.
        n_threads = 4
        per_thread = 10
        sid = "sid-concurrent"
        errors: list[Exception] = []

        def worker(idx: int):
            try:
                for j in range(per_thread):
                    handle_hook("PreToolUse", _payload(
                        session_id=sid,
                        tool_input={"file_path": f"/x/{idx}-{j}.py"},
                    ))
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == []
        # state.pkl must be parseable.
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        with open(state_path, "rb") as f:
            blob = pickle.load(f)
        assert isinstance(blob, dict)
        # timeline.jsonl must have N*K lines.
        timeline = tmp_path / "sessions" / sid / "timeline.jsonl"
        lines = _read_lines(timeline)
        assert len(lines) == n_threads * per_thread


# =====================================================================
# 5. Exit codes (host-safety contract)
# =====================================================================

class TestExitCodes:

    def test_pretooluse_no_prevent_returns_0(self):
        rc = handle_hook("PreToolUse", _payload())
        assert rc == 0

    def test_posttooluse_always_returns_0(self):
        rc = handle_hook("PostToolUse", _payload(tool_response={"ok": True}))
        assert rc == 0

    def test_stop_returns_0(self):
        handle_hook("PreToolUse", _payload(session_id="sid-stop"))
        rc = handle_hook("Stop", _payload(session_id="sid-stop"))
        assert rc == 0

    def test_subagentstop_returns_0(self):
        rc = handle_hook(
            "SubagentStop",
            _payload(
                session_id="sub-end",
                parent_session_id="root-end",
            ),
        )
        assert rc == 0

    def test_internal_exception_returns_0_never_blocks(self, monkeypatch):
        """If an internal helper raises unexpectedly, the hook still
        returns 0. The host-safety contract is non-negotiable."""
        # Patch a load-bearing internal to raise.
        def boom(*args, **kwargs):
            raise RuntimeError("synthetic crash")
        monkeypatch.setattr(cc, "_load_or_build_engine", boom)
        rc = handle_hook("PreToolUse", _payload())
        assert rc == 0

    def test_pretooluse_with_prevent_trip_returns_2(self, tmp_path, monkeypatch):
        """When the user opts into Prevent Mode AND a tracked failure
        crosses the trip threshold, PreToolUse exits with code 2.
        Claude Code blocks the tool call."""
        # Override the default engine config to enable Prevent Mode
        # with a low rotation threshold so a 3-edge cycle trips
        # almost immediately.
        prevent_config = dict(cc._DEFAULT_ENGINE_CONFIG)
        prevent_config.update({
            "warning_threshold": 2,
            "critical_threshold": 4,
            "per_edge_limit": 999,
            "global_limit": 9999,
            "prevent": {"cyclic_delegation": {"max_rotations": 3}},
        })
        monkeypatch.setattr(cc, "_DEFAULT_ENGINE_CONFIG", prevent_config)

        sid = "sid-prevent"
        # Build a 3-agent cycle (main -> subA -> subB -> main repeated).
        # But Claude Code's edges are tool calls, not agents. To form
        # a true cycle in the engine we need distinct sources and
        # targets that close back. Simulate by firing the SAME
        # source_agent (subagent_<id>) hitting different tool
        # fingerprints repeatedly through the same root.
        #
        # The simplest reliable trip: use a real cycle by alternating
        # subagent_ids that all share a root. main -> sub_A,
        # sub_A -> Read:fp1, etc. is not a cycle. Instead, build
        # cross-subagent loop where the engine sees a cycle.
        #
        # For testability, do an end-to-end trip via the existing
        # Layer 2 repetition detector: same edge fires many times,
        # which trips the Prevent Mode on the cycle pattern after the
        # warning + critical thresholds are crossed. The cyclic
        # prevent specifically tracks cycles, so we need to actually
        # form one. Use the lower-level API: build interaction events
        # that form a 3-rotation cycle directly through the engine.
        from agentsonar._core.models import InteractionEvent
        engine = cc._load_or_build_engine(
            tmp_path / "sessions" / sid / "state.pkl",
            dict(prevent_config),
        )
        ts = 1.0
        # 3-rotation cycle: main->A->B->main, repeat 5x.
        for _ in range(5):
            for src, tgt in (("main", "A"), ("A", "B"), ("B", "main")):
                engine.ingest(InteractionEvent(src, tgt, ts, None))
                ts += 1.0
        # Persist this primed engine state so the hook loads it.
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        cc._save_engine_state(session_dir / "state.pkl", engine)
        # Now fire a PreToolUse; Prevent Mode should trip and return 2.
        rc = handle_hook("PreToolUse", _payload(session_id=sid))
        assert rc == 2

    def test_prevent_trip_recorded_in_timeline(self, tmp_path, monkeypatch):
        """When a Prevent trip happens, the timeline record carries
        `prevented: true` for that event."""
        prevent_config = dict(cc._DEFAULT_ENGINE_CONFIG)
        prevent_config.update({
            "warning_threshold": 2,
            "critical_threshold": 4,
            "per_edge_limit": 999,
            "global_limit": 9999,
            "prevent": {"cyclic_delegation": {"max_rotations": 3}},
        })
        monkeypatch.setattr(cc, "_DEFAULT_ENGINE_CONFIG", prevent_config)

        from agentsonar._core.models import InteractionEvent
        sid = "sid-prev-timeline"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        engine = cc._load_or_build_engine(
            session_dir / "state.pkl",
            dict(prevent_config),
        )
        ts = 1.0
        for _ in range(5):
            for src, tgt in (("main", "A"), ("A", "B"), ("B", "main")):
                engine.ingest(InteractionEvent(src, tgt, ts, None))
                ts += 1.0
        cc._save_engine_state(session_dir / "state.pkl", engine)
        handle_hook("PreToolUse", _payload(session_id=sid))

        lines = _read_lines(session_dir / "timeline.jsonl")
        assert lines, "timeline should have at least one record"
        # The most recent record (the one we just fired) should be marked.
        assert lines[-1]["prevented"] is True


# =====================================================================
# 6. Cumulative report regeneration
# =====================================================================

class TestCumulativeReportRegeneration:

    def test_stop_on_root_writes_report_html_json_alerts(self, tmp_path):
        sid = "sid-report"
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        reports_dir = tmp_path / "reports" / sid
        assert (reports_dir / "report.html").exists()
        assert (reports_dir / "report.json").exists()
        assert (reports_dir / "alerts.log").exists()

    def test_stop_on_subagent_does_not_regenerate_report(self, tmp_path):
        """SubagentStop and a Stop on a subagent session should NOT
        write a report. The report belongs to the root session."""
        sid_root = "sid-rootonly"
        sid_sub = "sid-subonly"
        handle_hook("PreToolUse", _payload(session_id=sid_root))
        handle_hook("Stop", _payload(
            session_id=sid_sub,
            parent_session_id=sid_root,
        ))
        # Reports for sid_sub should NOT exist as its own tree.
        assert not (tmp_path / "reports" / sid_sub).exists()

    def test_stop_updates_latest_pointer(self, tmp_path):
        sid = "sid-latest"
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        latest = tmp_path / "reports" / "latest"
        assert latest.exists()
        assert latest.read_text(encoding="utf-8").strip() == sid

    def test_stop_does_not_call_engine_shutdown(self, tmp_path):
        """Engine state must survive across turns. Stop regenerates
        the report but does NOT trigger a full shutdown."""
        sid = "sid-no-shutdown"
        for _ in range(3):
            handle_hook("PreToolUse", _payload(session_id=sid))
            handle_hook("PostToolUse", _payload(
                session_id=sid,
                tool_response={"ok": True},
            ))
        handle_hook("Stop", _payload(session_id=sid))
        # Engine state.pkl is intact and reusable after Stop.
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        assert state_path.exists()
        # Another turn after Stop appends to the same timeline.
        handle_hook("PreToolUse", _payload(session_id=sid))
        timeline = tmp_path / "sessions" / sid / "timeline.jsonl"
        lines = _read_lines(timeline)
        # 3 Pre + 3 Post + 1 Stop + 1 new Pre = 8
        assert len(lines) == 8

    def test_report_html_is_non_empty(self, tmp_path):
        sid = "sid-htmlsize"
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        report = tmp_path / "reports" / sid / "report.html"
        contents = report.read_text(encoding="utf-8")
        assert len(contents) > 1000
        assert "<html" in contents

    def test_alerts_log_uses_clean_enum_names(self, tmp_path):
        """Regression for 0.5.1: alerts.log must NOT show
        'ALERTSEVERITY.CRITICAL' or 'FailureClass.RESOURCE_EXHAUSTION'.
        These are Python enum reprs leaking through; we use the enum's
        .value or .name instead."""
        sid = "sid-enum-labels"
        for i in range(20):
            handle_hook("PreToolUse", _payload(
                session_id=sid,
                tool_name="Read",
                tool_input={"file_path": "/src/same.py"},
            ))
        handle_hook("Stop", _payload(session_id=sid))
        alerts_log = tmp_path / "reports" / sid / "alerts.log"
        contents = alerts_log.read_text(encoding="utf-8")
        assert "ALERTSEVERITY." not in contents, (
            f"alerts.log shows raw enum repr; saw lines: {contents[:500]}"
        )
        assert "FailureClass." not in contents, (
            f"alerts.log shows raw enum class prefix; saw lines: {contents[:500]}"
        )

    def test_stop_summary_count_matches_real_alert_count(self, tmp_path, capsys):
        """Regression for 0.5.1: the stderr Stop summary said
        '0 coordination patterns detected' even when there were 2 alerts,
        because _safe_str(enum).upper() returned 'ALERTSEVERITY.WARNING'
        and never matched the 'WARNING'/'CRITICAL' check. Use
        _enum_display so the membership check works."""
        sid = "sid-stop-summary-count"
        for _ in range(20):
            handle_hook("PreToolUse", _payload(
                session_id=sid,
                tool_name="Read",
                tool_input={"file_path": "/src/hammered.py"},
            ))
        handle_hook("Stop", _payload(session_id=sid))
        captured = capsys.readouterr()
        # Stop summary should mention "1 coordination pattern" or
        # "2 coordination patterns", never "0".
        assert "0 coordination patterns" not in captured.err, (
            f"Stop summary undercounted alerts; stderr was: {captured.err!r}"
        )
        assert "AgentSonar: detected" in captured.err, (
            f"Stop summary missing or malformed; stderr was: {captured.err!r}"
        )

    def test_report_html_includes_session_log_panel(self, tmp_path):
        """Regression for 0.5.1: the Chronological Log panel must
        actually render. Earlier versions called a nonexistent
        engine._session_log_snapshot() method and silently skipped the
        panel."""
        sid = "sid-session-log-render"
        for i in range(5):
            handle_hook("PreToolUse", _payload(
                session_id=sid,
                tool_name="Read",
                tool_input={"file_path": f"/src/{i}.py"},
            ))
        handle_hook("Stop", _payload(session_id=sid))
        report = tmp_path / "reports" / sid / "report.html"
        contents = report.read_text(encoding="utf-8").lower()
        has_chronological = any(
            tok in contents
            for tok in ("chronological", "session log", "session_log", "session-log")
        )
        assert has_chronological, (
            "Chronological Log / Session Log panel missing from report.html"
        )


# =====================================================================
# 7. Session boundary detection
# =====================================================================

class TestSessionBoundaryDetection:

    def test_inactivity_sweep_archives_stale_session(self, tmp_path, monkeypatch):
        """A session_id whose last_hook_at is older than the threshold
        gets archived when a different session fires its next hook."""
        monkeypatch.setenv("AGENTSONAR_INACTIVITY_SECONDS", "1")
        sid_old = "sid-stale"
        sid_new = "sid-fresh"
        # Create the old session.
        handle_hook("PreToolUse", _payload(session_id=sid_old))
        # Make it stale (last_hook_at deep in the past).
        last_hook_at = tmp_path / "sessions" / sid_old / "last_hook_at"
        last_hook_at.write_text("100.0", encoding="utf-8")
        # Fire a hook on a different session; should sweep the stale one.
        handle_hook("PreToolUse", _payload(session_id=sid_new))
        # Old session moved under archived/.
        assert (tmp_path / "sessions" / "archived" / sid_old).exists()
        assert not (tmp_path / "sessions" / sid_old).exists()

    def test_inactivity_sweep_does_not_archive_current_session(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_INACTIVITY_SECONDS", "1")
        sid = "sid-current"
        handle_hook("PreToolUse", _payload(session_id=sid))
        # Forge an ancient last_hook_at to test the protection logic.
        (tmp_path / "sessions" / sid / "last_hook_at").write_text(
            "100.0", encoding="utf-8"
        )
        # Fire the next hook on the SAME session; sweep should NOT touch it.
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_response={"ok": True},
        ))
        assert (tmp_path / "sessions" / sid).exists()
        assert not (tmp_path / "sessions" / "archived" / sid).exists()


# =====================================================================
# 8. Subagent type registry
# =====================================================================

class TestSubagentTypeRegistry:

    def test_task_posttooluse_registers_subagent_type(self, tmp_path):
        """When Task PostToolUse fires with a tool_response containing
        a session_id, register the spawned subagent's session_id ->
        type_hash mapping."""
        sid_root = "sid-task-root"
        payload = _payload(
            session_id=sid_root,
            tool_name="Task",
            tool_input={"subagent_type": "code-reviewer"},
            tool_response={"session_id": "spawned-sub-1234"},
        )
        handle_hook("PostToolUse", payload)
        types_path = tmp_path / "sessions" / sid_root / "subagent_types.json"
        assert types_path.exists()
        data = json.loads(types_path.read_text(encoding="utf-8"))
        assert "spawned-sub-1234" in data
        # The value is a hash, not the cleartext type.
        assert "code-reviewer" not in data["spawned-sub-1234"]

    def test_non_task_posttooluse_does_not_register(self, tmp_path):
        sid = "sid-noregister"
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_response={"file_path": "/x.py"},
        ))
        types_path = tmp_path / "sessions" / sid / "subagent_types.json"
        assert not types_path.exists()

    def test_task_response_without_session_id_skipped_silently(self, tmp_path):
        sid = "sid-nositd"
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Task",
            tool_input={"subagent_type": "code-reviewer"},
            tool_response={"result": "no session_id here"},
        ))
        types_path = tmp_path / "sessions" / sid / "subagent_types.json"
        assert not types_path.exists()


# =====================================================================
# 9. timeline.jsonl protocol commitments
# =====================================================================

class TestTimelineProtocol:

    def test_schema_version_locked_at_1_0_0(self):
        """If you change TIMELINE_SCHEMA_VERSION without thinking
        carefully, this test reminds you of the protocol commitment."""
        assert TIMELINE_SCHEMA_VERSION == "1.0.0"

    def test_every_line_carries_schema_version(self, tmp_path):
        sid = "sid-schema"
        for event in ("PreToolUse", "PostToolUse"):
            handle_hook(event, _payload(
                session_id=sid,
                tool_response={"ok": True} if event == "PostToolUse" else None,
            ))
        lines = _read_lines(tmp_path / "sessions" / sid / "timeline.jsonl")
        assert len(lines) == 2
        for line in lines:
            assert line["schema_version"] == "1.0.0"

    def test_required_fields_on_every_line(self, tmp_path):
        sid = "sid-fields"
        handle_hook("PreToolUse", _payload(session_id=sid))
        line = _read_lines(tmp_path / "sessions" / sid / "timeline.jsonl")[0]
        for required in (
            "schema_version", "event_id", "event_name",
            "root_session_id", "source_session_id",
            "source_agent", "target_agent", "timestamp",
            "metadata", "alerts", "prevented",
        ):
            assert required in line, f"timeline line missing {required}"

    def test_timeline_only_grows_never_truncates(self, tmp_path):
        """The append-only contract: a Stop hook does NOT truncate
        or rewrite timeline.jsonl."""
        sid = "sid-grow"
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        first_line_count = len(_read_lines(
            tmp_path / "sessions" / sid / "timeline.jsonl"
        ))
        handle_hook("PreToolUse", _payload(session_id=sid))
        second_line_count = len(_read_lines(
            tmp_path / "sessions" / sid / "timeline.jsonl"
        ))
        assert second_line_count > first_line_count


# =====================================================================
# 10. AGENTSONAR_REGULATED path redaction
# =====================================================================

class TestRegulatedMode:

    def test_clear_path_in_metadata_by_default(self):
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/secret.py"}),
            hook_arrival_ts=1.0,
        )
        assert meta["target_path"] == "/src/secret.py"

    def test_regulated_redacts_path(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/secret.py"}),
            hook_arrival_ts=1.0,
        )
        assert meta["target_path"] is not None
        assert meta["target_path"].startswith("path:")
        assert "secret.py" not in meta["target_path"]

    def test_regulated_same_path_same_hash(self, monkeypatch):
        """Detection still works on hashed paths because same path
        produces same hash (flap detection survives redaction)."""
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        m1 = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/x.py"}),
            hook_arrival_ts=1.0,
        )
        m2 = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/x.py"}),
            hook_arrival_ts=2.0,
        )
        assert m1["target_path"] == m2["target_path"]

    def test_regulated_different_paths_different_hashes(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        m1 = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/x.py"}),
            hook_arrival_ts=1.0,
        )
        m2 = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/y.py"}),
            hook_arrival_ts=1.0,
        )
        assert m1["target_path"] != m2["target_path"]

    def test_regulated_path_absent_from_disk(self, tmp_path, monkeypatch):
        """End-to-end: with AGENTSONAR_REGULATED=1, the cleartext
        path must not appear in any file the adapter writes."""
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        sid = "sid-redacted"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/regulated/super-secret-path.py"},
        ))
        handle_hook("Stop", _payload(session_id=sid))
        for file in _all_files_on_disk(tmp_path):
            try:
                contents = file.read_bytes()
            except Exception:
                continue
            assert b"super-secret-path.py" not in contents, (
                f"redacted path leaked into {file}"
            )


# =====================================================================
# 11. THE CONTENT-BLIND SENTINEL AUDIT (the load-bearing privacy test)
# =====================================================================

# The single most important test in this file. The adapter's
# content-blind contract claims that tool input bodies, tool output
# bodies, user prompts, and file contents NEVER land on disk.
#
# This audit puts unique sentinel strings into each forbidden field,
# runs a full PreToolUse + PostToolUse + Stop sequence, and greps
# every file the adapter wrote for the sentinel. Each test fails the
# moment a sentinel appears anywhere on disk.
#
# The audit sweep covers every artifact the plan commits to:
#   - state.pkl
#   - timeline.jsonl
#   - report.html
#   - report.json
#   - alerts.log
#   - subagent_types.json
#   - last_hook_at
#   - any other file the adapter creates in the session tree

class TestContentBlindSentinelAudit:

    _SENTINEL_BASH = "SENTINEL-BASH-COMMAND-AGENTSONAR-CONTENT-LEAK-CANARY-A"
    _SENTINEL_EDIT_OLD = "SENTINEL-EDIT-OLD-AGENTSONAR-CONTENT-LEAK-CANARY-B"
    _SENTINEL_EDIT_NEW = "SENTINEL-EDIT-NEW-AGENTSONAR-CONTENT-LEAK-CANARY-C"
    _SENTINEL_GREP_PATTERN = "SENTINEL-GREP-PATTERN-AGENTSONAR-CONTENT-LEAK-CANARY-D"
    _SENTINEL_WRITE_CONTENT = "SENTINEL-WRITE-CONTENT-AGENTSONAR-CONTENT-LEAK-CANARY-E"
    _SENTINEL_RESPONSE = "SENTINEL-TOOL-RESPONSE-AGENTSONAR-CONTENT-LEAK-CANARY-F"
    _SENTINEL_USERPROMPT = "SENTINEL-USERPROMPT-AGENTSONAR-CONTENT-LEAK-CANARY-G"

    _ALL_SENTINELS = (
        _SENTINEL_BASH,
        _SENTINEL_EDIT_OLD,
        _SENTINEL_EDIT_NEW,
        _SENTINEL_GREP_PATTERN,
        _SENTINEL_WRITE_CONTENT,
        _SENTINEL_RESPONSE,
        _SENTINEL_USERPROMPT,
    )

    def _assert_no_sentinels(self, root: Path):
        """Grep every file under `root` for any sentinel string."""
        leaks: list[str] = []
        for file in _all_files_on_disk(root):
            try:
                contents = file.read_bytes()
            except Exception:
                continue
            for sentinel in self._ALL_SENTINELS:
                if sentinel.encode("utf-8") in contents:
                    leaks.append(f"{sentinel} in {file}")
        assert not leaks, "content leaks: " + "; ".join(leaks)

    def test_bash_command_string_never_persisted(self, tmp_path):
        sid = "sid-leak-bash"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
            tool_response={"stdout": self._SENTINEL_RESPONSE},
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_edit_old_and_new_strings_never_persisted(self, tmp_path):
        sid = "sid-leak-edit"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Edit",
            tool_input={
                "file_path": "/src/x.py",
                "old_string": self._SENTINEL_EDIT_OLD,
                "new_string": self._SENTINEL_EDIT_NEW,
            },
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Edit",
            tool_input={
                "file_path": "/src/x.py",
                "old_string": self._SENTINEL_EDIT_OLD,
                "new_string": self._SENTINEL_EDIT_NEW,
            },
            tool_response={"result": self._SENTINEL_RESPONSE},
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_grep_pattern_never_persisted(self, tmp_path):
        sid = "sid-leak-grep"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Grep",
            tool_input={
                "pattern": self._SENTINEL_GREP_PATTERN,
                "path": "/src",
            },
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_write_content_never_persisted(self, tmp_path):
        sid = "sid-leak-write"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Write",
            tool_input={
                "file_path": "/src/x.py",
                "content": self._SENTINEL_WRITE_CONTENT,
            },
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_read_response_body_never_persisted(self, tmp_path):
        """The most-likely leak vector. Read's tool_response IS the
        file contents."""
        sid = "sid-leak-read"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/src/x.py"},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/src/x.py"},
            tool_response={
                "content": (
                    f"file body line 1\n"
                    f"second line with {self._SENTINEL_RESPONSE}\n"
                    f"third line"
                ),
            },
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_user_prompt_text_never_persisted(self, tmp_path):
        sid = "sid-leak-userprompt"
        handle_hook("UserPromptSubmit", _payload(
            session_id=sid,
            tool_name="user-prompt",
            tool_input={"prompt": self._SENTINEL_USERPROMPT},
        ))
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_kitchen_sink_all_sentinels_at_once(self, tmp_path):
        """Run every sentinel in a single end-to-end sequence."""
        sid = "sid-leak-kitchen-sink"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
            tool_response={
                "stdout": self._SENTINEL_RESPONSE,
                "extra": self._SENTINEL_WRITE_CONTENT,
            },
        ))
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Edit",
            tool_input={
                "file_path": "/src/x.py",
                "old_string": self._SENTINEL_EDIT_OLD,
                "new_string": self._SENTINEL_EDIT_NEW,
            },
        ))
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Grep",
            tool_input={"pattern": self._SENTINEL_GREP_PATTERN},
        ))
        handle_hook("UserPromptSubmit", _payload(
            session_id=sid,
            tool_input={"prompt": self._SENTINEL_USERPROMPT},
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_audit_explicitly_inspects_each_artifact_by_name(self, tmp_path):
        """Belt-and-suspenders: prove the audit DOES open the canonical
        files by name (not just every file via rglob).

        Documents that the audit covers all five artifacts the plan
        commits to: state.pkl, timeline.jsonl, report.html, report.json,
        alerts.log.
        """
        sid = "sid-explicit-audit"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
            tool_response={"stdout": self._SENTINEL_RESPONSE},
        ))
        handle_hook("Stop", _payload(session_id=sid))

        # The five files must exist (so the test is genuinely auditing
        # them, not silently passing on missing files).
        artifacts = {
            tmp_path / "sessions" / sid / "state.pkl",
            tmp_path / "sessions" / sid / "timeline.jsonl",
            tmp_path / "reports" / sid / "report.html",
            tmp_path / "reports" / sid / "report.json",
            tmp_path / "reports" / sid / "alerts.log",
        }
        for art in artifacts:
            assert art.exists(), f"missing canonical artifact {art}"

        # Each one must be sentinel-free.
        for art in artifacts:
            contents = art.read_bytes()
            for sentinel in self._ALL_SENTINELS:
                assert sentinel.encode("utf-8") not in contents, (
                    f"{sentinel} leaked into {art}"
                )


# =====================================================================
# 12. Latency benchmark
# =====================================================================

class TestLatency:

    @pytest.mark.performance
    def test_p99_under_75ms_on_200_event_session(self, tmp_path):
        """200-event synthetic load, p99 budget <75ms per hook.

        The plan's 10ms aspirational target assumed Unix filesystem
        performance (sub-millisecond open() calls). On Windows NTFS
        each open() is ~4ms, and we do ~5 opens per hook (lock,
        state.pkl read, timeline append, state.pkl atomic rewrite,
        last_hook_at write), so ~25ms is the structural floor without
        deeper architectural changes (batched async I/O, custom
        lock-file reuse, etc., which are out of scope for Phase 1).

        75ms is the cross-platform realistic budget with headroom for
        filesystem-cache jitter on Windows. On Linux this test passes
        with significant margin (typically <15ms p99). Either way the
        hook latency is invisible next to the Python interpreter
        cold-start cost (~50-100ms per hook subprocess on Windows).

        Performance-marked: only runs with `pytest -m performance`.
        The default test invocation excludes this so noisy CI runners
        do not flake.
        """
        sid = "sid-perf"
        latencies: list[float] = []
        for i in range(200):
            payload = _payload(
                session_id=sid,
                tool_input={"file_path": f"/src/{i}.py"},
            )
            start = time.perf_counter()
            handle_hook("PreToolUse", payload)
            latencies.append(time.perf_counter() - start)

        latencies.sort()
        p99 = latencies[int(0.99 * len(latencies))]
        assert p99 < 0.075, f"p99 latency {p99 * 1000:.2f}ms exceeds 75ms budget"


# =====================================================================
# 13. Concurrent hooks (integration)
# =====================================================================

class TestConcurrentHooks:

    def test_5_parallel_subagent_hooks_share_state(self, tmp_path):
        """5 parallel subagents each fire 10 hooks against the same
        root session tree. The file lock and atomic rename guarantee
        no corruption. End-to-end aggregate event count must equal
        the sum of inputs."""
        sid_root = "sid-paralleltree"
        subagent_ids = [f"sub-{i:04d}-aaaa-bbbb" for i in range(5)]
        per_subagent = 10
        errors: list[Exception] = []

        def fire_subagent(sub_sid: str):
            try:
                for j in range(per_subagent):
                    handle_hook("PreToolUse", _payload(
                        session_id=sub_sid,
                        parent_session_id=sid_root,
                        tool_input={"file_path": f"/src/{sub_sid}-{j}.py"},
                    ))
            except Exception as exc:
                errors.append(exc)

        threads = [
            threading.Thread(target=fire_subagent, args=(s,))
            for s in subagent_ids
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert errors == []
        timeline = tmp_path / "sessions" / sid_root / "timeline.jsonl"
        lines = _read_lines(timeline)
        assert len(lines) == 5 * per_subagent
        # All lines should share the same root_session_id.
        for line in lines:
            assert line["root_session_id"] == sid_root
