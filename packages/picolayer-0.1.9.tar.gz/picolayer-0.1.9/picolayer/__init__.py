"""Picolayer CLI — scaffold, test, and deploy embedded firmware tests."""

__version__ = "0.1.9"
