from .dpi import truemove_air
from .. import usbhid

profile = {
    "name": "SteelSeries Rival 5",
    "models": [
        {
            "name": "SteelSeries Rival 5",
            "vendor_id": 0x1038,
            "product_id": 0x183C,
            "endpoint": 0,
        },
        {
            "name": "SteelSeries Rival 5 Destiny Edition",
            "vendor_id": 0x1038,
            "product_id": 0x183E,
            "endpoint": 0,
        },
    ],
    "settings": {
        "sensitivity": {
            "label": "Sensitivity presets",
            "description": "Set sensitivity presets (DPI)",
            "cli": ["-s", "--sensitivity"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            "command": [0x2D],
            "value_type": "multidpi_range_choice",
            "input_range": [100, 18000, 100],
            "output_choices": truemove_air.choices,
            "dpi_length_byte": 1,
            "first_preset": 0,
            "max_preset_count": 5,
            "default": "400, 800, 1200, 2400, 3200",
        },
        "polling_rate": {
            "label": "Polling rate",
            "description": "Set polling rate (Hz)",
            "cli": ["-p", "--polling-rate"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            "command": [0x2B],
            "value_type": "choice",
            "choices": {
                125: 0x04,
                250: 0x03,
                500: 0x02,
                1000: 0x01,
            },
            "default": 1000,
        },
        "wheel_color": {
            "label": "Wheel LED color",
            "description": "Set the color of the wheel LED",
            "cli": ["-C", "--wheel-color", "--z0"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b00000001, 0b00000000,   # Flags
                *[0x00, 0x00, 0x00] * 0,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "z2_color": {
            "label": "Left strip, top LED color",
            "description": "Set the color of the top LED of the left strip",
            "cli": ["--left-strip-top-color", "--z2"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b00000010, 0b00000000,   # Flags
                *[0x00, 0x00, 0x00] * 1,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "z3_color": {
            "label": "Right strip, top LED color",
            "description": "Set the color of the top LED of the right strip",
            "cli": ["--right-strip-top-color", "--z3"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b00000100, 0b00000000,   # Flags
                *[0x00, 0x00, 0x00] * 2,  # padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "z4_color": {
            "label": "Left strip, middle top LED color",
            "description": "Set the color of the middle top LED of the left strip",
            "cli": ["--left-strip-middle-top-color", "--z4"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b00001000, 0b00000000,   # Flags
                *[0x00, 0x00, 0x00] * 3,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "z5_color": {
            "label": "Right strip, middle top LED color",
            "description": "Set the color of the middle top LED of the right strip",
            "cli": ["--right-strip-middle-top-color", "--z5"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b00010000, 0b00000000,   # Flags
                *[0x00, 0x00, 0x00] * 4,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "z6_color": {
            "label": "Left strip, middle bottom LED color",
            "description": "Set the color of the middle bottom LED of the left strip",
            "cli": ["--left-strip-middle-bottom-color", "--z6"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b00100000, 0b00000000,   # Flags
                *[0x00, 0x00, 0x00] * 5,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "z7_color": {
            "label": "Right strip, middle bottom LED color",
            "description": "Set the color of the middle bottom LED of the right strip",
            "cli": ["--right-strip-middle-bottom-color", "--z7"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b01000000, 0b00000000,   # Flags
                *[0x00, 0x00, 0x00] * 6,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "z8_color": {
            "label": "Left strip, bottom LED color",
            "description": "Set the color of the bottom LED of the left strip",
            "cli": ["--left-strip-bottom-color", "--z8"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b10000000, 0b00000000,   # Flags
                *[0x00, 0x00, 0x00] * 7,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "z9_color": {
            "label": "Right strip, bottom LED color",
            "description": "Set the color of the bottom LED of the right strip",
            "cli": ["--right-strip-bottom-color", "--z9"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b00000000, 0b00000001,   # Flags
                *[0x00, 0x00, 0x00] * 8,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "logo_color": {
            "label": "Logo LED color",
            "description": "Set the color of the logo LED",
            "cli": ["-c", "--logo-color", "--z1"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            # fmt: off
            "command": [
                0x21,                     # Command
                0b00000000, 0b00000010,   # Flags
                *[0x00, 0x00, 0x00] * 9,  # Padding
            ],
            # fmt: on
            "value_type": "rgbcolor",
            "default": "#ff1800",
        },
        "reactive_color": {
            "label": "Reactive color",
            "description": "Set the color of the LEDs in reaction to a button click",
            "cli": ["-a", "--reactive-color"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            "command": [0x26],
            "value_type": "reactive_rgbcolor",
            "default": "white",
        },
        "led_brightness": {
            "label": "LED Brightness",
            "description": "Set the brightness of the LEDs",
            "cli": ["-l", "--led-brightness"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            "command": [0x23],
            "value_type": "choice",
            "choices": {
                100: 0x64,
                75: 0x32,
                50: 0x19,
                25: 0x0C,
                0: 0x00,
            },
            "default": 100,
        },
        "buttons_mapping": {
            "label": "Buttons mapping",
            "description": "Set the mapping of the buttonsX",
            "cli": ["-b", "--buttons"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            "command": [0x2A],
            "value_type": "buttons",
            "buttons": {
                "Button1": {"id": 0x01, "offset": 0x00, "default": "button1"},
                "Button2": {"id": 0x02, "offset": 0x05, "default": "button2"},
                "Button3": {"id": 0x03, "offset": 0x0A, "default": "button3"},
                "Button4": {"id": 0x04, "offset": 0x0F, "default": "button4"},
                "Button5": {"id": 0x05, "offset": 0x14, "default": "button5"},
                "Button6": {"id": 0x06, "offset": 0x19, "default": "disabled"},
                "Button7": {"id": 0x00, "offset": 0x1E, "default": "disabled"},
                "Button8": {"id": 0x00, "offset": 0x23, "default": "disabled"},
                "Button9": {"id": 0x00, "offset": 0x28, "default": "dpi"},
                "ScrollUp": {"id": 0x31, "offset": 0x2D, "default": "scrollup"},
                "ScrollDown": {"id": 0x32, "offset": 0x32, "default": "scrolldown"},
            },
            "button_field_length": 5,
            "button_disable": 0x00,
            "button_keyboard": 0x51,
            "button_multimedia": 0x61,
            "button_dpi_switch": 0x30,
            "button_scroll_up": None,
            "button_scroll_down": None,
            "default": "buttons(button1=button1; button2=button2; button3=button3; button4=button4; button5=button5; button6=disabled; button7=disabled; button8=disabled; button9=dpi; scrollup=scrollup; scrolldown=scrolldown; layout=qwerty)",
        },
        # XXX It is possible to reset only some of the LEDs using the same
        # XXX bit mask than for color commands. (TODO later)
        "rainbow_effect": {
            "label": "rainbow effect",
            "description": "Enable the rainbow effect (can be disabled by setting a color)",
            "cli": ["-e", "--rainbow-effect"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            "command": [0x22, 0xFF, 0x03],
            "value_type": "none",
        },
        "default_lighting": {
            "label": "Default lighting",
            "description": "Set default lighting at mouse startup, Reactive-color must be toggled separately!",
            "cli": ["-d", "--default-lighting"],
            "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
            "command": [0x27],
            "value_type": "choice",
            "choices": {
                "off": 0x00,
                "rainbow": 0x01,
            },
            "default": "rainbow",
        },
    },
    "save_command": {
        "report_type": usbhid.HID_REPORT_TYPE_OUTPUT,
        "command": [0x11, 0x00],
    },
}
