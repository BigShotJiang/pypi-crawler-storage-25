# marker for adapters tests
