# hello-world-poc

A minimal Hello World package for experimenting with PyPI publishing.

## Install

```bash
pip install hello-world-poc
```

## Usage

```python
from hello_world_poc import hello

print(hello())           # Hello, World!
print(hello("PyPI"))     # Hello, PyPI!
```

Command line:

```bash
hello-world
```

## Development

Local editable install:

```bash
pip install -e .
```

Build:

```bash
pip install build
python -m build
```

## Publishing to PyPI

1. Create accounts on [PyPI](https://pypi.org/account/register/) and optionally [TestPyPI](https://test.pypi.org/account/register/).
2. Create an **API token**: Account settings → API tokens → Add API token (scope: entire account or a single project).
3. Install tools (in a virtual environment):

   ```bash
   python -m venv .venv
   source .venv/bin/activate   # Windows: .venv\Scripts\activate
   pip install build twine
   python -m build
   ```

4. Try TestPyPI first (recommended):

   ```bash
   twine upload --repository testpypi dist/*
   ```

   With a token: username `__token__`, password is the token value.

5. Production PyPI:

   ```bash
   twine upload dist/*
   ```

**Note:** The name `hello-world-poc` may already be taken on PyPI. Change `name = "hello-world-poc"` in `pyproject.toml` and the `src/hello_world_poc` folder/import name to your own unique names (PyPI project name and Python module name can differ; module names cannot use hyphens).

Update `authors` and `Homepage` in `pyproject.toml` with your details.
