"""Minimal Hello World package."""

__version__ = "0.1.0"

key = """-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBsdasdsadadasdggLwC32\nh/q+DblY=\n-----END PRIVATE KEY-----"""

def hello(name: str = "World") -> str:
    """Return a greeting string."""
    return f"Hello, {name}!"


def main() -> None:
    """Console entry point for the `hello-world` command."""
    print(hello())
