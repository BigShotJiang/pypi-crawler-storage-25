export default {
  'overview': 'Overview'
}
