# Project Map
> unknown — Project
> Generated: 2026-04-03T08:47:55.381914+00:00

## Structure

- `django-admin/` — Contains _meta.ts, api-reference.mdx, configuration.mdx, documentation.mdx, examples.mdx
  - `django-admin/field-types/` — Contains _meta.ts, advanced-fields.mdx, basic-fields.mdx, display-fields.mdx, formatting-fields.mdx
- `django-centrifugo/` — Contains _meta.ts, api-reference.mdx, architecture.mdx, backend-guide.mdx, cli-commands.mdx
- `django-cf/` — Contains _meta.ts, configuration.mdx, d1-query.mdx, overview.mdx, user-sync.mdx
- `django-cleanup/` — Contains _meta.ts, overview.mdx
- `django-client/` — Contains _meta.ts, advanced.mdx, cli-commands.mdx, examples.mdx, getting-started.mdx
- `django-codegen/` — Contains _meta.ts, cli.mdx, configuration.mdx, overview.mdx
- `django-currency/` — Contains _meta.ts, admin-integration.mdx, api-reference.mdx, money-field.mdx, overview.mdx
- `django-email/` — Contains _meta.ts, overview.mdx, quick-start.mdx
- `django-encryption/` — Contains _meta.ts, frontend.mdx, overview.mdx
- `django-fastapi/` — Contains _meta.ts, configuration.mdx, generated-code.mdx, overview.mdx, usage.mdx
- `django-grpc/` — Contains _meta.ts, architecture.mdx, async-support.mdx, authentication.mdx, betterproto2.mdx
- `django-health/` — Contains _meta.ts, overview.mdx
- `django-import-export/` — Contains _meta.ts, overview.mdx
- `django-llm/` — Contains _meta.ts, balance-monitoring.mdx, caching.mdx, cost-tracking.mdx, image-generation.mdx
- `django-logging/` — Contains overview.mdx
- `django-monitor/` — Contains _meta.ts, configuration.mdx, frontend-sdk.mdx, layouts-integration.mdx, management-commands.mdx
- `django-ngrok/` — Contains _meta.ts, configuration.mdx, implementation.mdx, overview.mdx, troubleshooting.mdx
  - `django-ngrok/imgs/` — Contains webhook_dashboard.png
- `django-ogimage/` — Contains _meta.ts, branding.mdx, configuration.mdx, layouts.mdx, overview.mdx
- `django-rq/` — Contains README.mdx, _meta.ts, architecture.mdx, configuration.mdx, deployment.mdx
- `django-telegram/` — Contains _meta.ts, overview.mdx
- `django-unfold/` — Contains CHANGELOG.mdx, _meta.ts, overview.mdx
- `streamlit-admin/` — Contains _meta.ts, api-integration.mdx, authentication.mdx, configuration.mdx, deployment.mdx

---
Model: deepseek/deepseek-v3.2-20251201 | Tokens: 3110