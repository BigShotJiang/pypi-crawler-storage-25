# Project Map
> documentation-site — A documentation site for Django-CFG, a type-safe configuration framework for Django with features like encryption and user management.
> Generated: 2026-04-03T10:07:31.592590+00:00

## Structure

- `api/` — Contains _meta.ts, index.mdx, intro.mdx
- `business/` — Contains _meta.ts, index.mdx, reduce-django-development-costs.mdx
- `cli/` — Contains _meta.ts, custom-commands.mdx, index.mdx, introduction.mdx
  - `cli/commands/` — Documentation for CLI command reference, built with Nextra for a static site.
- `configuration/` — Documentation for Django-CFG configuration models (Pydantic v2) including environment, database, cache, email, and security settings.
- `core/` — Documentation for Django-CFG core concepts like architecture, type safety, builder pattern, middleware, and Django integration.
  - `core/encryption/` — Documentation for the encryption module covering API protection and client-side decryption.
- `database/` — Documentation for Django-CFG database configuration, multi-database setup, routing, and cross-database relations.
- `deployment/` — Contains _meta.ts, environment-setup.mdx, index.mdx, logging.mdx, monitoring.mdx
- `extensions/` — Documentation for the core modular extension system of the Django-CFG framework.
- `features/` — Contains _meta.ts, index.mdx
  - `features/api-generation/` — Contains _meta.ts, cli-usage.mdx, generated-clients.mdx, groups.mdx, index.mdx
  - `features/built-in-apps/` — Contains _meta.ts, index.mdx, overview.mdx
    - `features/built-in-apps/user-management/` — Documentation for the built-in user management application covering authentication and account features.
  - `features/drf-guide/` — Contains _meta.ts, drf-array-responses.mdx, drf-nested-serializers.mdx, drf-pagination.mdx, drf-pydantic-responses.mdx
  - `features/integrations/` — Contains _meta.ts, auth-system.mdx, auth.mdx, index.mdx, overview.mdx
    - `features/integrations/oauth/` — Contains _meta.ts, configuration.mdx, frontend.mdx, github.mdx, index.mdx
  - `features/modules/` — Contains _meta.ts, index.mdx, overview.mdx
    - `features/modules/django-admin/` — Contains _meta.ts, api-reference.mdx, configuration.mdx, documentation.mdx, examples.mdx
    - `features/modules/django-centrifugo/` — Contains _meta.ts, api-reference.mdx, architecture.mdx, backend-guide.mdx, cli-commands.mdx
    - `features/modules/django-cf/` — Documentation for a Django Cloudflare integration module, covering configuration, D1 SQL factory, user sync, and usage tracking.
    - `features/modules/django-cleanup/` — Contains _meta.ts, overview.mdx
    - `features/modules/django-client/` — Contains _meta.ts, advanced.mdx, cli-commands.mdx, examples.mdx, getting-started.mdx
    - `features/modules/django-codegen/` — Contains _meta.ts, cli.mdx, configuration.mdx, overview.mdx
    - `features/modules/django-currency/` — Documentation for Django-CFG's currency system module covering MoneyField, admin integration, and API reference.
    - `features/modules/django-drf-theme/` — Documentation for the Django REST Framework Tailwind CSS theme extension module.
    - `features/modules/django-email/` — Documentation for Django-CFG's auto-configuring email service module with template support.
    - `features/modules/django-fastapi/` — Documentation for Django-CFG's FastAPI ORM Generator that creates SQLModel code from Django models.
    - `features/modules/django-grpc/` — Contains _meta.ts, architecture.mdx, async-support.mdx, authentication.mdx, betterproto2.mdx
    - `features/modules/django-health/` — Documentation for Django-CFG's health check endpoints module for system monitoring.
    - `features/modules/django-import-export/` — Documentation for Django-CFG's import/export module with built-in validation.
    - `features/modules/django-llm/` — Documentation for Django-CFG's LLM integration module covering text, vision, caching, and cost tracking.
    - `features/modules/django-llm-monitoring/` — Documentation for the LLM API usage monitoring and alerting extension module.
    - `features/modules/django-logging/` — Documentation for the structured logging and alerting extension module.
    - `features/modules/django-monitor/` — Contains _meta.ts, configuration.mdx, frontend-sdk.mdx, layouts-integration.mdx, management-commands.mdx
    - `features/modules/django-ngrok/` — Contains _meta.ts, configuration.mdx, implementation.mdx, overview.mdx, troubleshooting.mdx
    - `features/modules/django-ogimage/` — Documentation for Django-CFG's Open Graph image generation module for branding and layouts.
    - `features/modules/django-rq/` — Contains README.mdx, _meta.ts, architecture.mdx, configuration.mdx, deployment.mdx
    - `features/modules/django-tailwind/` — Documentation for the universal Tailwind CSS layout templates extension module.
    - `features/modules/django-telegram/` — Documentation for Django-CFG's Telegram integration module.
    - `features/modules/django-unfold/` — Documentation for Django-CFG's Unfold admin theme module, including changelog.
    - `features/modules/streamlit-admin/` — Contains _meta.ts, api-integration.mdx, authentication.mdx, configuration.mdx, deployment.mdx
  - `features/tools/` — Contains _meta.ts
    - `features/tools/currency/` — Documentation for the Django-CFG currency tool, covering configuration, models, and field integration.
    - `features/tools/geo/` — Documentation for the Django-CFG geographic tool, covering location fields, geo models, and geocoding services.
- `frontend/` — Core frontend architecture guide for Next.js applications within the Django-CFG ecosystem.
  - `frontend/recipes/` — Implementation recipes and patterns for specific frontend concerns like state management, forms, and animations.
- `getting-started/` — Introductory documentation for installing, configuring, and starting a first project with Django-CFG.
- `guides/` — Main documentation guides covering tutorials, FAQs, configuration, and migration for the framework.

---
Model: cache | Tokens: 0