from urllib import request

import json
import time
import shutil


BASE_URL = 'http://127.0.0.1:8000'
PROMPT_ENDPOINT_URL = f'{BASE_URL}/prompt'
HISTORY_ENDPOINT_URL = f'{BASE_URL}/history'
OUTPUT_PATH = 'C:/ComfyUI/output/'

# TODO: Maybe singleton (?)
class ComfyUIAPI:
    """
    Class to represent the connection with the ComfyUI API.
    """

    def __init__(
        self,
        comfyui_base_url: str = BASE_URL,
        comfyui_output_path: str = OUTPUT_PATH,
        request_timeout: float = 180.0
    ):
        self.base_url: str = comfyui_base_url
        """
        The base url of the ComfyUI server.
        """
        self._output_path: str = comfyui_output_path
        """
        *For internal use only*

        The output path of the ComfyUI server, which is set
        when the app is installed.
        """
        self._request_timeout: float = request_timeout
        """
        *For internal use only*

        The maximum time we will be waiting for the request
        to be completed.
        """

    def _queue_workflow(
        self,
        workflow: 'Workflow'
    ) -> str:
        """
        *For internal use only*

        Send the `workflow` provided to the queue to be processed
        and get the `prompt_id` that can be used to receive the
        result when finished.
        """
        p = {'prompt': workflow.prompt}
        data = json.dumps(p).encode('utf-8')
        req = request.Request(PROMPT_ENDPOINT_URL, data = data)
        res = json.loads(request.urlopen(req).read())

        return res['prompt_id']
    
    def _wait_for_completion(
        self,
        prompt_id: str
    ) -> dict:
        """
        *For internal use only*

        Wait for the completion of the `prompt_id` provided,
        waiting a maximum time of `timeout` seconds.
        """
        TIME_IN_BETWEEN_CHECKS: float = 1.0
        start_time = time.monotonic()

        while True:
            if time.monotonic() - start_time >= self._request_timeout:
                # TODO: Maybe return None instead (?)
                raise TimeoutError(f'Timeout waiting for prompt_id={prompt_id}')

            try:
                with request.urlopen(f'{HISTORY_ENDPOINT_URL}/{prompt_id}') as res:
                    history = json.loads(res.read())

                if prompt_id in history:
                    return history[prompt_id]

            except Exception:
                pass

            time.sleep(TIME_IN_BETWEEN_CHECKS)

    def _get_images(
        self,
        result_json: dict
    ) -> list[dict]:
        """
        *For internal use only*

        Get the images from the `result_json` provided, that
        must be the result of a task queued that has been
        completed.
        """
        outputs = result_json['outputs']
        images = []

        for node_id in outputs:
            node_output = outputs[node_id]

            if 'images' in node_output:
                for img in node_output['images']:
                    images.append(img)

        return images
    
    """
    TODO: We should have different process for the different
    results we can have. This one below is currently a single
    image but we can obtain a video, a prompt, etc.
    """
    def process_workflow(
        self,
        workflow: 'Workflow'
    ) -> str:
        """
        Process the `workflow` provided and store the image
        result locally.
        """
        prompt_id = self._queue_workflow(workflow)
        print(f'Queued prompt_id: {prompt_id}')
        result = self._wait_for_completion(prompt_id)
        print(f'The prompt_id: {prompt_id} has been completed!')

        images = self._get_images(result)

        for index, image in enumerate(images):
            print(image)
            extension = image['filename'].split('.')[-1]
            # TODO: How do we do if more than one image (?)
            output_filename = f'./test_files/{prompt_id}_{str(index)}.{extension}'
            shutil.copy(f'{OUTPUT_PATH}/{image["filename"]}', output_filename)
            return output_filename