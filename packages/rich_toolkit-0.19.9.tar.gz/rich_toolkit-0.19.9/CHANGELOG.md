CHANGELOG
=========

0.19.9 - 2026-05-13
-------------------

This release fixes progress log rendering when messages contain embedded
newlines.

`Progress.log()` now preserves multiline messages in non-inline progress
rendering, while inline progress logs split embedded newlines into separate log
entries. This keeps partial-line logging with `end=""` working while also
handling output that arrives with newline characters already included.

Cancelled progress rendering now keeps the progress output that was already
visible and always shows `Cancelled.` on its own final line, avoiding duplicated
titles in framed styles.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#58](https://github.com/patrick91/rich-toolkit/pull/58)

0.19.8 - 2026-05-12
-------------------

This release adds support for passing `end` to `RichToolkit.print()`,
`RichToolkit.print_title()`, and `Progress.log()`.

This makes it possible to print or log partial lines without automatically
ending them with a newline:

```python
app.print("Hello, ", end="")
app.print("World!")

with app.progress("Downloading") as progress:
    progress.log("Downloaded ", end="")
    progress.log("50%")
```

This release was contributed by [@patrick91](https://github.com/patrick91) in [#56](https://github.com/patrick91/rich-toolkit/pull/56)

0.19.7 - 2026-02-24
-------------------

Show cancelled state when progress is interrupted with Ctrl+C.

Previously, pressing Ctrl+C during a progress operation would exit without
any visual indication that the operation was cancelled. Now, the progress
displays "Cancelled." (matching how inputs and menus already handle cancellation).

The tagged style also shows the tag blocks in red (using error animation colors)
when a progress is cancelled.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#55](https://github.com/patrick91/rich-toolkit/pull/55)

0.19.6 - 2026-02-24
-------------------

Fix metadata being lost when passed to `Progress`. `Element.__init__` was called
without the `metadata` argument, causing it to be overwritten to an empty dict.
Also removed a redundant `self.metadata` assignment in `Menu`.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#54](https://github.com/patrick91/rich-toolkit/pull/54)

0.19.5 - 2026-02-24
-------------------

Add `**metadata` support to the `progress()` method, aligning it with the other
`RichToolkit` methods (`print`, `input`, `confirm`, `ask`) that already accept
and forward metadata to the underlying components.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#53](https://github.com/patrick91/rich-toolkit/pull/53)

0.19.4 - 2026-02-12
-------------------

This release adds support for passing a `value` parameter to `Input` and `RichToolkit.input()`, which sets the initial editable text of the input field. The cursor is positioned at the end of the value, so users can immediately continue typing or edit the pre-populated text.

```python
app.input(
    "What is your name?",
    value="Patrick",
)
```

This release was contributed by [@patrick91](https://github.com/patrick91) in [#52](https://github.com/patrick91/rich-toolkit/pull/52)

0.19.3 - 2026-02-11
-------------------

This release fixes the input component to show the explicit placeholder text
when both a `placeholder` and `default` value are provided. Previously, the
default value would always take priority, hiding the placeholder text.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#51](https://github.com/patrick91/rich-toolkit/pull/51)

0.19.2 - 2026-02-10
-------------------

This release hides the placeholder text when an input is cancelled. Previously,
the placeholder was shown with strikethrough styling, but now only user-typed
text is displayed when cancelling.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#50](https://github.com/patrick91/rich-toolkit/pull/50)

0.19.1 - 2026-02-10
-------------------

This release fixes an issue where the cursor would appear in the wrong position
when an input's label was long enough to wrap to multiple lines. It also fixes
text being cut off at the terminal edge in FancyStyle instead of wrapping
correctly.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#49](https://github.com/patrick91/rich-toolkit/pull/49)

0.19.0 - 2026-02-09
-------------------

This release refactors our styling a bit, improving the visual distinction between submitted input values and placeholders, and properly handling the cancelled state of inputs.

In addition to that we also merge the custom theme on top of the base theme instead of replacing it, which allows us to preserve base styles like `placeholder.cancelled` while still allowing users to customize their themes.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#48](https://github.com/patrick91/rich-toolkit/pull/48)

0.18.1 - 2026-02-01
-------------------

Fixed a crash that occurred when pressing Ctrl+C to cancel a menu. Previously, the `render_menu` function would crash with an `IndexError` when trying to display a cancelled menu because it attempted to access an invalid selection index.

The fix checks if the menu element was cancelled or has an invalid selection index before attempting to access the selected option, and displays "Cancelled." instead.

This also includes comprehensive test coverage for cancelled menu rendering scenarios.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#42](https://github.com/patrick91/rich-toolkit/pull/42)

0.18.0 - 2026-02-01
-------------------

This release adds multiple selection support to the Menu component.

When passing `multiple=True` to `RichToolkit.ask()` or `Menu()`, the menu
switches to multi-select mode:

- Uses square characters (`■`/`□`) instead of circles (`●`/`○`)
- **Space** toggles the checked state of the current item
- **Arrow keys / j/k** move the cursor independently of checked state
- **Enter** confirms the selection (requires at least one checked item)
- Returns a list of selected values instead of a single value

```python
selected = app.ask(
    "Which languages do you use?",
    options=[
        {"name": "Python", "value": "python"},
        {"name": "JavaScript", "value": "javascript"},
        {"name": "Rust", "value": "rust"},
    ],
    multiple=True,
)
# selected is e.g. ["python", "rust"]
```

Works with filtering (`allow_filtering=True`) and all existing styles
(tagged, bordered, etc.). Raises `ValueError` if combined with `inline=True`.

This release was contributed by [@patrick91](https://github.com/patrick91) in [#46](https://github.com/patrick91/rich-toolkit/pull/46)

0.17.2 - 2026-01-29
-------------------

This release fixed the colour detection function, mostly to fix a bug 
interfering with forked worker processes (e.g. uvicorn with `--workers`).

The colour query now uses a dedicated file descriptor instead of stdin/stdout,
preventing issues with logging and signal handling in multi-process environments.

0.17.1 - 2025-12-17
-------------------

Fix inline menu option wrapping by using spaces instead of tabs.

When using inline menus (e.g., `app.confirm()`), options like "Yes" and "No" were wrapping to separate lines due to tab character separators expanding unpredictably in fixed-width table columns. This release replaces tab separators with two spaces for consistent, predictable spacing.

**Before:**
```
● Yes
○ No
```

**After:**
```
● Yes  ○ No
```

0.17.0 - 2025-11-27
-------------------

Add scrolling support for menus with many options.

When a menu has more options than can fit on the terminal screen, it now
automatically scrolls as the user navigates with arrow keys. This prevents
the UI from breaking when the terminal is too small to display all options.

Features:
- Automatic scrolling based on terminal height
- Scroll indicators (`↑ more` / `↓ more`) show when more options exist
- Works with both `TaggedStyle` and `BorderedStyle`
- Works with filterable menus (scroll resets when filter changes)
- Optional `max_visible` parameter for explicit control

Example usage:

```python
from rich_toolkit import RichToolkit
from rich_toolkit.styles.tagged import TaggedStyle

# Auto-scrolling based on terminal height
with RichToolkit(style=TaggedStyle()) as app:
    result = app.ask(
        "Select a country:",
        options=[{"name": country, "value": country} for country in countries],
        allow_filtering=True,
    )

# Or with explicit max_visible limit
from rich_toolkit.menu import Menu

menu = Menu(
    label="Pick an option:",
    options=[{"name": f"Option {i}", "value": i} for i in range(50)],
    max_visible=10,  # Only show 10 options at a time
)
result = menu.ask()
```

0.16.0 - 2025-11-19
-------------------

Add Pydantic v1/v2 compatibility for Input validators using a Protocol-based approach.

The `Input` component now accepts any object with a `validate_python` method through the new `Validator` protocol, making it compatible with both Pydantic v1 and v2.

**Usage with Pydantic v2:**
```python
from pydantic import TypeAdapter

validator = TypeAdapter(int)
app.input("Enter a number:", validator=validator)
```

**Usage with Pydantic v1:**
```python
from pydantic import parse_obj_as

class V1Validator:
    def __init__(self, type_):
        self.type_ = type_

    def validate_python(self, value):
        return parse_obj_as(self.type_, value)

validator = V1Validator(int)
app.input("Enter a number:", validator=validator)
```

**Changes:**
- Added `Validator` protocol that accepts any object with a `validate_python` method
- Improved error message extraction from Pydantic validation errors
- Added cross-version compatibility tests
- Updated CI to test both Pydantic v1 and v2 across Python 3.8-3.14

0.15.1 - 2025-09-04
-------------------

This release add proper support for CJK characters

0.15.0 - 2025-08-11
-------------------

This release increases the paste buffer from 32 to 4096 characters, enabling users to paste longer text into input fields.

It also adds full Windows compatibility with proper special key handling and fixes how password fields to always show asterisks.