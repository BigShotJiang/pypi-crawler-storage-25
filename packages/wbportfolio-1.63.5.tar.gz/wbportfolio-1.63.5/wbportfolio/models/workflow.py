import logging
from datetime import date

from celery import shared_task
from django.contrib.contenttypes.models import ContentType
from django.db.models import F, QuerySet, Window
from django.db.models.functions import RowNumber
from tqdm import tqdm
from wbcore.contrib.color.models import ColorGradient
from wbcore.contrib.currency.models import Currency
from wbcore.contrib.directory.models import Company
from wbcore.workers import Queue
from wbfdm.models import Instrument
from wbreport.models import Report, ReportClass

from wbportfolio.models import (
    AssetPosition,
    FeeProductPercentage,
    Index,
    InstrumentPortfolioThroughModel,
    Order,
    OrderProposal,
    Portfolio,
    PortfolioPortfolioThroughModel,
    Product,
)
from wbportfolio.models.asset import adjust_assets
from wbportfolio.models.orders.orders import adjust_orders

logger = logging.getLogger("pms")


def adjust_quote(
    old_quote: Instrument,
    new_quote: Instrument,
    adjust_after: date | None = None,
    only_portfolios: QuerySet[Portfolio] | None = None,
    force_share_adjustment: bool = False,
    debug: bool = False,
    override_currency_check: bool = False,
):
    different_currency = old_quote.currency != new_quote.currency
    if not override_currency_check and different_currency:
        raise ValueError("cannot safely switch quotes that are not of the same currency")
    assets_to_change = AssetPosition.objects.filter(underlying_quote=old_quote)
    orders_to_change = Order.objects.filter(underlying_instrument=old_quote)
    new_quote.import_prices()
    if adjust_after:
        assets_to_change = assets_to_change.filter(date__gt=adjust_after)
        orders_to_change = orders_to_change.filter(value_date__gt=adjust_after)
    if only_portfolios is not None:
        assets_to_change = assets_to_change.filter(portfolio__in=only_portfolios)
        orders_to_change = orders_to_change.filter(order_proposal__portfolio__in=only_portfolios)
    if debug:
        assets_to_change = tqdm(assets_to_change, total=assets_to_change.count())
        orders_to_change = tqdm(orders_to_change, total=orders_to_change.count())

    # gather the list of order proposal to replay (if the quote led to missing position, we want to replay it to correct automatically the issue)
    latest_orders = orders_to_change.annotate(
        row_number=Window(
            expression=RowNumber(), partition_by=[F("order_proposal__portfolio")], order_by=F("value_date").desc()
        )
    ).filter(row_number=1)
    order_proposals_to_replay = OrderProposal.objects.filter(
        portfolio__is_manageable=True, id__in=latest_orders.values("order_proposal")
    )
    logger.info("adjusting asset positions...")
    # Adjust assets to the new quote
    adjust_assets(
        assets_to_change,
        new_quote,
        change_currency_fx_rate=different_currency,
        force_share_adjustment=force_share_adjustment,
    )
    logger.info("adjusting orders...")
    # Adjust orders to the new quote
    adjust_orders(
        orders_to_change,
        new_quote,
        change_currency_fx_rate=different_currency,
        force_share_adjustment=force_share_adjustment,
    )

    # replay latest order proposal
    for op in order_proposals_to_replay:
        op.replay(reapply_order_proposal=True)


@shared_task(queue=Queue.BACKGROUND.value)
def adjust_quote_as_task(
    old_quote_id: int, new_quote_id: int, adjust_after: date | None = None, only_portfolio_ids: list[int] | None = None
):
    old_quote = Instrument.objects.get(id=old_quote_id)
    new_quote = Instrument.objects.get(id=new_quote_id)
    only_portfolios = Portfolio.objects.filter(id__in=only_portfolio_ids) if only_portfolio_ids else None
    adjust_quote(old_quote, new_quote, adjust_after=adjust_after, only_portfolios=only_portfolios)


def create_ownership(
    root_portfolio: Portfolio,
    initial_composition: list[tuple[str, float, list]],
    root_currency: Currency,
    inception_date: date,
):
    def _create_ownership_rec(portfolio: Portfolio, composition: list[tuple[str, float, list]]):
        total_sum = sum(map(lambda o: o[1], composition))
        if total_sum != 1:
            raise ValueError(f"A valid composition needs to sum to 1 ({total_sum})")
        portfolios = []
        for ticker, weight, childs in composition:
            index_title = f"Index - {ticker}"
            index = Index.objects.get_or_create(
                ticker=ticker, defaults={"name": index_title, "currency": root_currency}
            )[0]
            index_portfolio = index.portfolio
            if not index_portfolio:
                index_portfolio = Portfolio.objects.create(name=index_title, currency=root_currency)
                InstrumentPortfolioThroughModel.objects.get_or_create(instrument=index, portfolio=index_portfolio)
                if childs:
                    for child_portfolio in _create_ownership_rec(index_portfolio, childs):
                        PortfolioPortfolioThroughModel.objects.get_or_create(
                            portfolio=index_portfolio,
                            dependency_portfolio=child_portfolio,
                            type=PortfolioPortfolioThroughModel.Type.HIERARCHICAL,
                        )
            portfolios.append(index_portfolio)
            AssetPosition.objects.get_or_create(
                portfolio=portfolio,
                underlying_quote=index,
                date=inception_date,
                defaults={"is_estimated": True, "weighting": weight, "initial_price": index.issue_price},
            )
        return portfolios

    for child_portfolio in _create_ownership_rec(root_portfolio, initial_composition):
        PortfolioPortfolioThroughModel.objects.get_or_create(
            portfolio=root_portfolio,
            dependency_portfolio=child_portfolio,
            type=PortfolioPortfolioThroughModel.Type.HIERARCHICAL,
        )


def create_product(
    name: str,
    isin: str,
    ticker: str,
    currency: Currency,
    bank: Company,
    inception_date: date,
    management_fees: float = 0,
    issuer_fees: float = 0,
    performance_fees: float = 0,
    product_portfolio: Portfolio | None = None,
    lookthrough_portfolio: Portfolio | None = None,
    replication_ownership: list[tuple[str, float, list]] | None = None,
    report_class: ReportClass | None = None,
    **kwargs,
):
    product_defaults = kwargs.get("product_kwargs", {})
    portfolio_kwargs = kwargs.get("portfolio_kwargs", {})
    factsheet_kwargs = kwargs.get("factsheet_kwargs", {})

    product_defaults.update({"name": name, "ticker": ticker, "currency": currency, "bank": bank})
    product, _ = Product.objects.update_or_create(isin=isin, defaults=product_defaults)
    if management_fees:
        FeeProductPercentage.objects.update_or_create(
            type=FeeProductPercentage.Type.MANAGEMENT,
            product=product,
            timespan__contains=inception_date,
            defaults={"percent": management_fees},
        )

    if issuer_fees:
        FeeProductPercentage.objects.update_or_create(
            type=FeeProductPercentage.Type.BANK,
            product=product,
            timespan__contains=inception_date,
            defaults={"percent": issuer_fees},
        )

    if performance_fees:
        FeeProductPercentage.objects.update_or_create(
            type=FeeProductPercentage.Type.PERFORMANCE,
            product=product,
            timespan__contains=inception_date,
            defaults={"percent": performance_fees},
        )
    is_lookthrough = lookthrough_portfolio is not None or replication_ownership is not None
    if not product_portfolio:
        if product.portfolio:
            product_portfolio = product.portfolio
        else:
            ptf_tilte = f"Product {name} - {bank} - {isin}"
            if is_lookthrough:
                ptf_tilte += " (Look-Through)"
            product_portfolio = Portfolio.objects.create(
                name=ptf_tilte, currency=currency, is_lookthrough=is_lookthrough, **portfolio_kwargs
            )
    product.portfolios.clear()  # ensure we don't already have a link, we refresh it bellow
    InstrumentPortfolioThroughModel.objects.get_or_create(instrument=product, portfolio=product_portfolio)

    # example Cybersecurity product ISIN=i invest into index with ticker=t
    # ptf structure:
    # ptf look-through i
    # --> dependant on (LOOKTHROUGH) primary ptf "Product i" (needed for to store trades on the product, always stored at product.primary_portfolio)
    #    --> get_or_create Index ptf t (Hierarchical relationship) with its ptf t
    #  "Product i" needs to investe 100% into Index ptfs t
    lookthrough_portfolio = lookthrough_portfolio or product_portfolio.primary_portfolio

    if replication_ownership:
        if not lookthrough_portfolio:
            lookthrough_portfolio = Portfolio.objects.create(
                name=f"Product {name} - {bank} - {isin}", currency=currency
            )
    if lookthrough_portfolio:
        # if lookthrogh ptf is defined, we linked it with a lookthrough relationship to our base product ptf
        PortfolioPortfolioThroughModel.objects.get_or_create(
            portfolio=product_portfolio,
            dependency_portfolio=lookthrough_portfolio,
            type=PortfolioPortfolioThroughModel.Type.LOOK_THROUGH,
        )
    if replication_ownership:
        create_ownership(product.primary_portfolio, replication_ownership, currency, inception_date)

    if report_class:
        factsheet_defaults = {
            "title": f"{name.title()} ({isin})",
            "key": "factsheet",
            "parent_report": Report.objects.get(namespace="factsheet", level=0),
            "permission_type": "PUBLIC",
            "is_active": True,
            "color_palette": ColorGradient.objects.first(),
            "report_class": report_class,
        }
        factsheet_defaults.update(factsheet_kwargs)
        Report.objects.get_or_create(
            content_type=ContentType.objects.get_for_model(Product), object_id=product.id, defaults=factsheet_kwargs
        )

    return product
