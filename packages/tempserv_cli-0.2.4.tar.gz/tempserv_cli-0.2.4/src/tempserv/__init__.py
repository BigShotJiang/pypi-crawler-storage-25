"""Tempserv CLI - Python API for temporary file & site hosting."""

__version__ = "0.1.0"

from tempserv.api import TempservClient, upload, download, info, delete, replace

__all__ = [
    "TempservClient",
    "upload",
    "download",
    "info",
    "delete",
    "replace",
]
