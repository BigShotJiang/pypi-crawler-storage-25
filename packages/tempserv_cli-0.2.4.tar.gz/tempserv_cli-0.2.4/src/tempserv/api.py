"""Tempserv API client - handles all HTTP interactions."""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

import httpx
from tqdm import tqdm

from tempserv.config import Config, UploadRecord, add_upload, load_config, save_config


EXPIRY_MAP = {
    "15min": 15 * 60,
    "30min": 30 * 60,
    "1hr": 60 * 60,
    "2hr": 2 * 60 * 60,
    "6hr": 6 * 60 * 60,
    "12hr": 12 * 60 * 60,
    "24hr": 24 * 60 * 60,
}


class TempservClient:
    def __init__(self, base_url: Optional[str] = None, config: Optional[Config] = None):
        self.config = config or load_config()
        self.base_url = (base_url or self.config.base_url).rstrip("/")
        self._client = httpx.Client(timeout=60.0)

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def upload_file(
        self,
        file_path: str,
        mode: str = "file",
        expiry: str = "1hr",
        password: Optional[str] = None,
    ) -> dict:
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if path.is_dir():
            return self.upload_folder(path, expiry=expiry, password=password)

        if path.stat().st_size > 20 * 1024 * 1024:
            raise ValueError(f"File exceeds 20MB limit: {path.name}")

        expiry_seconds = self._parse_expiry(expiry)
        
        file_size = path.stat().st_size
        with open(path, "rb") as f:
            files = {
                "files": (path.name, f, "application/octet-stream"),
                "mode": (None, mode),
                "expiry": (None, expiry),
                "paths": (None, json.dumps([path.name])),
            }
            if password:
                files["password"] = (None, password)

            with tqdm(
                total=file_size,
                unit="B",
                unit_scale=True,
                desc=f"Uploading {path.name}",
            ) as pbar:
                response = self._client.post(
                    self._url("/api/upload"),
                    files=files,
                )
                pbar.update(file_size)

        if response.status_code != 201:
            raise Exception(f"Upload failed: {response.text}")

        result = response.json()
        record = UploadRecord(
            slug=result["slug"],
            url=result["url"],
            token=result["accessToken"],
            mode=mode,
            uploaded_at=datetime.utcnow().isoformat(),
            expires_at=datetime.utcfromtimestamp(result["expiresAt"]).isoformat(),
        )
        add_upload(self.config, record)
        return result

    def upload_folder(
        self,
        folder_path: Path,
        expiry: str = "1hr",
        password: Optional[str] = None,
    ) -> dict:
        folder_path = Path(folder_path)
        if not folder_path.is_dir():
            raise NotADirectoryError(f"Not a directory: {folder_path}")

        files = []
        paths = []
        total_size = 0

        for root, _, filenames in os.walk(folder_path):
            for fname in filenames:
                fpath = Path(root) / fname
                rel_path = fpath.relative_to(folder_path)
                fsize = fpath.stat().st_size
                if fsize > 20 * 1024 * 1024:
                    raise ValueError(f"File exceeds 20MB limit: {rel_path}")
                total_size += fsize
                files.append((str(rel_path), fpath))
                paths.append(str(rel_path))

        if total_size > 50 * 1024 * 1024:
            raise ValueError("Total folder size exceeds 50MB limit")

        has_index = any(p.endswith("index.html") for p in paths)
        if not has_index:
            raise ValueError("Site mode requires an index.html file")

        expiry_seconds = self._parse_expiry(expiry)
        
        files_payload = []
        files_payload.append(("mode", (None, "site")))
        files_payload.append(("expiry", (None, expiry)))
        files_payload.append(("paths", (None, json.dumps(paths))))
        if password:
            files_payload.append(("password", (None, password)))
        
        for rel_path, fpath in files:
            files_payload.append(
                ("files", (rel_path, open(fpath, "rb"), "application/octet-stream"))
            )

        with tqdm(total=total_size, unit="B", unit_scale=True, desc=f"Uploading {folder_path.name}") as pbar:
            response = self._client.post(
                self._url("/api/upload"),
                files=files_payload,
            )
            pbar.update(total_size)

        for _, item in files_payload:
            if isinstance(item, tuple) and len(item) > 1 and hasattr(item[1], 'close'):
                item[1].close()

        if response.status_code != 201:
            raise Exception(f"Upload failed: {response.text}")

        result = response.json()
        record = UploadRecord(
            slug=result["slug"],
            url=result["url"],
            token=result["accessToken"],
            mode="site",
            folder_path=str(folder_path.resolve()),
            uploaded_at=datetime.utcnow().isoformat(),
            expires_at=datetime.utcfromtimestamp(result["expiresAt"]).isoformat(),
        )
        add_upload(self.config, record)
        return result

    def download_file(
        self,
        slug: str,
        output_path: Optional[str] = None,
        password: Optional[str] = None,
    ) -> Path:
        headers = {}
        if password:
            headers["X-File-Password"] = password

        response = self._client.get(
            self._url(f"/file/{slug}/dl"),
            headers=headers,
            follow_redirects=True,
        )

        if response.status_code != 200:
            raise Exception(f"Download failed: {response.text}")

        content_disp = response.headers.get("Content-Disposition", "")
        filename = "download"
        if "filename=" in content_disp:
            filename = content_disp.split("filename=")[1].strip('"')

        output = Path(output_path) if output_path else Path(filename)
        output.parent.mkdir(parents=True, exist_ok=True)

        total_size = int(response.headers.get("Content-Length", 0))
        with open(output, "wb") as f:
            with tqdm(total=total_size, unit="B", unit_scale=True, desc=f"Downloading {filename}") as pbar:
                for chunk in response.iter_bytes(chunk_size=8192):
                    f.write(chunk)
                    pbar.update(len(chunk))

        return output

    def get_info(self, slug: str) -> dict:
        response = self._client.get(self._url(f"/file/{slug}"))
        if response.status_code == 404:
            raise Exception(f"File not found: {slug}")
        response.raise_for_status()

        import re
        html = response.text

        info = {}
        fname_match = re.search(r'<div class="fname">([^<]+)</div>', html)
        if fname_match:
            info["filename"] = fname_match.group(1).strip()

        meta_matches = re.findall(r'<div class="meta-row"><span class="label">([^<]+)</span><span class="value">([^<]+)</span></div>', html)
        for label, value in meta_matches:
            info[label.lower().replace(" ", "_")] = value.strip()

        return info

    def check_health(self) -> dict:
        try:
            response = self._client.get(self._url("/"))
            return {
                "status": "healthy" if response.status_code == 200 else "degraded",
                "status_code": response.status_code,
                "response_time_ms": response.elapsed.total_seconds() * 1000,
                "url": self.base_url,
            }
        except Exception as e:
            return {
                "status": "down",
                "error": str(e),
                "url": self.base_url,
            }

    def get_folder_diff(self, folder_path: Path, slug: str, token: Optional[str] = None) -> dict:
        folder_path = Path(folder_path)
        if not folder_path.is_dir():
            raise NotADirectoryError(f"Not a directory: {folder_path}")

        local_files = {}
        for root, _, filenames in os.walk(folder_path):
            for fname in filenames:
                fpath = Path(root) / fname
                rel_path = str(fpath.relative_to(folder_path))
                local_files[rel_path] = fpath.stat().st_size

        response = self._client.get(self._url(f"/api/info/{slug}"))
        if response.status_code != 200:
            raise Exception(f"Failed to fetch server info: {response.text}")

        server_data = response.json()
        server_files = {}
        for f in server_data.get("files", []):
            server_files[f["path"]] = f["size"]

        new_files = set(local_files.keys()) - set(server_files.keys())
        removed_files = set(server_files.keys()) - set(local_files.keys())
        changed_files = []
        for f in local_files:
            if f in server_files:
                if local_files[f] != server_files.get(f, -1):
                    changed_files.append(f)

        return {
            "new": list(new_files),
            "removed": list(removed_files),
            "changed": changed_files,
            "total_local": len(local_files),
            "total_server": len(server_files),
        }

    def delete_file(self, slug: str, token: Optional[str] = None) -> dict:
        if not token:
            record = self._find_record(slug)
            if record:
                token = record.token
            else:
                raise ValueError(f"No token found for {slug}. Provide --token or use a recent upload.")

        response = self._client.delete(
            self._url(f"/api/{slug}"),
            headers={"X-Access-Token": token},
        )

        if response.status_code != 200:
            raise Exception(f"Delete failed: {response.text}")

        return response.json()

    def replace_file(
        self,
        slug: str,
        file_path: str,
        token: Optional[str] = None,
    ) -> dict:
        if not token:
            record = self._find_record(slug)
            if record:
                token = record.token
            else:
                raise ValueError(f"No token found for {slug}. Provide --token.")

        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        form_data = {"paths": json.dumps([path.name])}
        with open(path, "rb") as f:
            files = {"files": (path.name, f, "application/octet-stream")}
            data = {k: (None, v) for k, v in form_data.items()}

            response = self._client.put(
                self._url(f"/api/{slug}"),
                headers={"X-Access-Token": token},
                data=data,
                files=files,
            )

        if response.status_code != 200:
            raise Exception(f"Replace failed: {response.text}")

        return response.json()

    def replace_folder(
        self,
        slug: str,
        folder_path: Path,
        token: Optional[str] = None,
    ) -> dict:
        if not token:
            record = self._find_record(slug)
            if record:
                token = record.token
            else:
                raise ValueError(f"No token found for {slug}. Provide --token.")

        folder_path = Path(folder_path)
        if not folder_path.is_dir():
            raise NotADirectoryError(f"Not a directory: {folder_path}")

        files = []
        paths = []
        total_size = 0

        for root, _, filenames in os.walk(folder_path):
            for fname in filenames:
                fpath = Path(root) / fname
                rel_path = fpath.relative_to(folder_path)
                fsize = fpath.stat().st_size
                if fsize > 20 * 1024 * 1024:
                    raise ValueError(f"File exceeds 20MB limit: {rel_path}")
                total_size += fsize
                files.append((str(rel_path), fpath))
                paths.append(str(rel_path))

        if total_size > 50 * 1024 * 1024:
            raise ValueError("Total folder size exceeds 50MB limit")

        has_index = any(p.endswith("index.html") for p in paths)
        if not has_index:
            raise ValueError("Site mode requires an index.html file")

        files_payload = []
        files_payload.append(("paths", (None, json.dumps(paths))))
        for rel_path, fpath in files:
            files_payload.append(
                ("files", (rel_path, open(fpath, "rb"), "application/octet-stream"))
            )

        with tqdm(total=total_size, unit="B", unit_scale=True, desc=f"Replacing {folder_path.name}") as pbar:
            response = self._client.put(
                self._url(f"/api/{slug}"),
                headers={"X-Access-Token": token},
                files=files_payload,
            )
            pbar.update(total_size)

        for _, item in files_payload:
            if isinstance(item, tuple) and len(item) > 1 and hasattr(item[1], 'close'):
                item[1].close()

        if response.status_code != 200:
            raise Exception(f"Replace failed: {response.text}")

        record = self._find_record(slug)
        if record:
            record.folder_path = str(folder_path.resolve())
            save_config(self.config)

        return response.json()

    def _find_record(self, slug: str) -> Optional[UploadRecord]:
        from tempserv.config import find_upload
        return find_upload(self.config, slug)

    def _parse_expiry(self, expiry: str) -> int:
        if expiry in EXPIRY_MAP:
            return EXPIRY_MAP[expiry]
        try:
            minutes = int(expiry)
            if 1 <= minutes <= 1440:
                return minutes * 60
        except ValueError:
            pass
        raise ValueError(f"Invalid expiry: {expiry}. Use presets (15min, 1hr, etc) or 1-1440 minutes.")


def upload(
    file_path: str,
    mode: str = "file",
    expiry: str = "1hr",
    password: Optional[str] = None,
    base_url: Optional[str] = None,
) -> dict:
    client = TempservClient(base_url=base_url)
    path = Path(file_path)
    if path.is_dir():
        return client.upload_folder(path, expiry=expiry, password=password)
    return client.upload_file(file_path, mode=mode, expiry=expiry, password=password)


def download(
    slug: str,
    output_path: Optional[str] = None,
    password: Optional[str] = None,
    base_url: Optional[str] = None,
) -> Path:
    client = TempservClient(base_url=base_url)
    return client.download_file(slug, output_path=output_path, password=password)


def info(
    slug: str,
    base_url: Optional[str] = None,
) -> dict:
    client = TempservClient(base_url=base_url)
    return client.get_info(slug)


def delete(
    slug: str,
    token: Optional[str] = None,
    base_url: Optional[str] = None,
) -> dict:
    client = TempservClient(base_url=base_url)
    return client.delete_file(slug, token=token)


def replace(
    slug: str,
    file_path: str,
    token: Optional[str] = None,
    base_url: Optional[str] = None,
) -> dict:
    client = TempservClient(base_url=base_url)
    return client.replace_file(slug, file_path, token=token)
