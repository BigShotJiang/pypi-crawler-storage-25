"""Configuration management for Tempserv CLI."""

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class UploadRecord:
    slug: str
    url: str
    token: str
    mode: str = "file"
    folder_path: str = ""
    uploaded_at: str = ""
    expires_at: str = ""


@dataclass
class Config:
    base_url: str = "https://tempserv.badman993944.workers.dev"
    default_expiry: str = "1hr"
    default_mode: str = "file"
    recent_uploads: list = field(default_factory=list)


CONFIG_DIR = Path.home() / ".tempserv"
CONFIG_FILE = CONFIG_DIR / "config.json"


def load_config() -> Config:
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text())
            uploads = [UploadRecord(**u) for u in data.get("recent_uploads", [])]
            return Config(
                base_url=data.get("base_url", Config.base_url),
                default_expiry=data.get("default_expiry", Config.default_expiry),
                default_mode=data.get("default_mode", Config.default_mode),
                recent_uploads=uploads,
            )
        except (json.JSONDecodeError, Exception):
            pass
    return Config()


def save_config(config: Config) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = {
        "base_url": config.base_url,
        "default_expiry": config.default_expiry,
        "default_mode": config.default_mode,
        "recent_uploads": [
            {
                "slug": u.slug,
                "url": u.url,
                "token": u.token,
                "mode": u.mode,
                "folder_path": u.folder_path,
                "uploaded_at": u.uploaded_at,
                "expires_at": u.expires_at,
            }
            for u in config.recent_uploads
        ],
    }
    CONFIG_FILE.write_text(json.dumps(data, indent=2))


def add_upload(config: Config, record: UploadRecord) -> Config:
    config.recent_uploads.insert(0, record)
    config.recent_uploads = config.recent_uploads[:50]
    save_config(config)
    return config


def find_upload(config: Config, slug: str) -> Optional[UploadRecord]:
    for rec in config.recent_uploads:
        if rec.slug == slug:
            return rec
    return None


def find_by_folder(config: Config, folder_path: str) -> Optional[UploadRecord]:
    abs_path = str(Path(folder_path).resolve())
    for rec in config.recent_uploads:
        if rec.folder_path and str(Path(rec.folder_path).resolve()) == abs_path:
            return rec
    return None
