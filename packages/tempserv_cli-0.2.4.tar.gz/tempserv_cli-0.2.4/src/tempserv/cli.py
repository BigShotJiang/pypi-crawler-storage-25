"""CLI entry point for Tempserv."""

import json
import sys
import webbrowser
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

from tempserv.api import TempservClient
from tempserv.config import load_config, save_config, Config, find_by_folder

console = Console()


@click.group()
@click.version_option(version="0.1.0", prog_name="tempserv")
@click.option(
    "--url",
    "-u",
    default=None,
    help="Base URL of the tempserv instance",
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Output in JSON format",
)
@click.pass_context
def cli(ctx, url: Optional[str], json_output: bool):
    """Tempserv CLI - Temporary file & site hosting."""
    ctx.ensure_object(dict)
    ctx.obj["json"] = json_output
    if url:
        ctx.obj["base_url"] = url


@cli.command()
@click.argument("url", required=False)
@click.option("--default-expiry", default=None, help="Default expiry time")
@click.option("--default-mode", default=None, help="Default upload mode")
def login(url: Optional[str], default_expiry: Optional[str], default_mode: Optional[str]):
    """Configure tempserv instance URL (optional - already preconfigured)."""
    config = load_config()
    if url:
        config.base_url = url.rstrip("/")
    if default_expiry:
        config.default_expiry = default_expiry
    if default_mode:
        config.default_mode = default_mode
    save_config(config)
    console.print(Panel(
        f"[green]✓[/green] Configured tempserv at [cyan]{config.base_url}[/cyan]\n"
        f"Default expiry: [yellow]{config.default_expiry}[/yellow]\n"
        f"Default mode: [yellow]{config.default_mode}[/yellow]",
        title="Config Saved",
        border_style="green",
    ))


@cli.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--mode", "-m", default=None, help="Upload mode: file or site")
@click.option("--expiry", "-e", default=None, help="Expiry time (e.g., 15min, 1hr, 24hr, or custom minutes)")
@click.option("--password", "-p", default=None, help="Password protect the upload (file mode only)")
@click.pass_context
def upload(ctx, file_path: str, mode: Optional[str], expiry: Optional[str], password: Optional[str]):
    """Upload a file or folder to tempserv."""
    path = Path(file_path)
    config = load_config()
    base_url = ctx.obj.get("base_url")

    client = TempservClient(base_url=base_url, config=config)

    if mode is None:
        mode = "site" if path.is_dir() else config.default_mode

    if expiry is None:
        expiry = config.default_expiry

    if mode == "site" and password:
        console.print(Panel(
            "[yellow]⚠ Site mode does NOT support password protection.[/yellow]\n\n"
            "Sites are always public and accessible without a password.\n\n"
            "Your options:\n"
            "1. Upload without password (site will be public)\n"
            "2. Use file mode instead if you need password protection\n\n"
            "Note: The server will reject this upload if a password is provided.",
            title="Password Not Supported for Sites",
            border_style="yellow",
        ))
        if not click.confirm("Do you want to continue uploading WITHOUT password protection?", default=True):
            console.print("[yellow]Upload cancelled.[/yellow]")
            sys.exit(0)
        password = None

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Uploading {path.name}...", total=None)

        try:
            if path.is_dir():
                result = client.upload_folder(path, expiry=expiry, password=password)
            else:
                result = client.upload_file(file_path, mode=mode, expiry=expiry, password=password)

            progress.update(task, completed=True)

            if ctx.obj.get("json"):
                click.echo(json.dumps(result, indent=2))
            else:
                table = Table(title="Upload Successful", border_style="green")
                table.add_column("Field", style="cyan")
                table.add_column("Value", style="white")
                table.add_row("URL", result["url"])
                table.add_row("Slug", result["slug"])
                table.add_row("Access Token", result["accessToken"])
                table.add_row("Mode", result["mode"])
                table.add_row("Protected", "No (sites are always public)" if result["mode"] == "site" else ("Yes" if result.get("protected") else "No"))
                console.print(table)

        except Exception as e:
            progress.update(task, completed=True)
            console.print(f"[red]✗ Error:[/red] {e}")
            sys.exit(1)


@cli.command()
@click.argument("slug")
@click.option("--output", "-o", default=None, help="Output file path")
@click.option("--password", "-p", default=None, help="Password for protected files")
@click.pass_context
def download(ctx, slug: str, output: Optional[str], password: Optional[str]):
    """Download a file from tempserv."""
    base_url = ctx.obj.get("base_url")
    client = TempservClient(base_url=base_url)

    try:
        output_path = client.download_file(slug, output_path=output, password=password)
        if ctx.obj.get("json"):
            click.echo(json.dumps({"output": str(output_path)}, indent=2))
        else:
            console.print(Panel(
                f"[green]✓[/green] Downloaded to [cyan]{output_path}[/cyan]",
                title="Download Complete",
                border_style="green",
            ))
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")
        sys.exit(1)


@cli.command()
@click.argument("slug")
@click.pass_context
def info(ctx, slug: str):
    """View file information."""
    base_url = ctx.obj.get("base_url")
    client = TempservClient(base_url=base_url)

    try:
        file_info = client.get_info(slug)
        if ctx.obj.get("json"):
            click.echo(json.dumps(file_info, indent=2))
        else:
            table = Table(title=f"File Info: {slug}", border_style="cyan")
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="white")
            for key, value in file_info.items():
                table.add_row(key.replace("_", " ").title(), value)
            console.print(table)
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")
        sys.exit(1)


@cli.command()
@click.argument("slug")
@click.option("--token", "-t", default=None, help="Access token")
@click.pass_context
def delete(ctx, slug: str, token: Optional[str]):
    """Delete a file from tempserv."""
    base_url = ctx.obj.get("base_url")
    client = TempservClient(base_url=base_url)

    try:
        result = client.delete_file(slug, token=token)
        if ctx.obj.get("json"):
            click.echo(json.dumps(result, indent=2))
        else:
            console.print(Panel(
                f"[green]✓[/green] File [cyan]{slug}[/cyan] deleted successfully",
                title="Delete Successful",
                border_style="green",
            ))
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")
        sys.exit(1)


@cli.command()
@click.argument("slug")
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--token", "-t", default=None, help="Access token")
@click.pass_context
def replace(ctx, slug: str, file_path: str, token: Optional[str]):
    """Replace an existing file."""
    base_url = ctx.obj.get("base_url")
    client = TempservClient(base_url=base_url)

    try:
        result = client.replace_file(slug, file_path, token=token)
        if ctx.obj.get("json"):
            click.echo(json.dumps(result, indent=2))
        else:
            console.print(Panel(
                f"[green]✓[/green] File replaced successfully",
                title="Replace Successful",
                border_style="green",
            ))
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")
        sys.exit(1)


@cli.command()
@click.argument("folder_path", type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.option("--expiry", "-e", default=None, help="Expiry time (e.g., 15min, 1hr, 24hr, or custom minutes)")
@click.option("--password", "-p", default=None, help="Password protect the upload (file mode only)")
@click.option("--compress", "-c", is_flag=True, help="Minify HTML, CSS, and JS before upload")
@click.pass_context
def site(ctx, folder_path: str, expiry: Optional[str], password: Optional[str], compress: bool):
    """Deploy a static site folder to tempserv."""
    path = Path(folder_path)
    index_file = path / "index.html"
    if not index_file.exists():
        console.print("[red]✗ Error:[/red] No index.html found in folder. Site mode requires index.html.")
        sys.exit(1)

    if password:
        console.print(Panel(
            "[yellow]⚠ Site mode does NOT support password protection.[/yellow]\n\n"
            "Sites are always public and accessible without a password.\n\n"
            "Your options:\n"
            "1. Deploy without password (site will be public)\n"
            "2. Use file mode instead if you need password protection\n\n"
            "Note: The server will reject this upload if a password is provided.",
            title="Password Not Supported for Sites",
            border_style="yellow",
        ))
        if not click.confirm("Do you want to continue deploying WITHOUT password protection?", default=True):
            console.print("[yellow]Deployment cancelled.[/yellow]")
            sys.exit(0)
        password = None

    config = load_config()
    base_url = ctx.obj.get("base_url")
    client = TempservClient(base_url=base_url, config=config)

    if expiry is None:
        expiry = config.default_expiry

    upload_path = path
    if compress:
        import tempfile
        from tempserv.compress import compress_folder
        temp_dir = Path(tempfile.mkdtemp(prefix="tempserv_"))
        total_original, total_compressed = compress_folder(path, temp_dir)
        upload_path = temp_dir
        savings = total_original - total_compressed
        pct = (savings / total_original * 100) if total_original > 0 else 0
        console.print(f"[dim]Compressed: {total_original:,} → {total_compressed:,} bytes ({pct:.1f}% saved)[/dim]")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Deploying {path.name}...", total=None)
        try:
            result = client.upload_folder(upload_path, expiry=expiry, password=password)
            progress.update(task, completed=True)

            if compress:
                import shutil
                shutil.rmtree(upload_path, ignore_errors=True)

            if ctx.obj.get("json"):
                click.echo(json.dumps(result, indent=2))
            else:
                table = Table(title="Site Deployed", border_style="green")
                table.add_column("Field", style="cyan")
                table.add_column("Value", style="white")
                table.add_row("URL", result["url"])
                table.add_row("Slug", result["slug"])
                table.add_row("Access Token", result["accessToken"])
                table.add_row("Mode", result["mode"])
                table.add_row("Protected", "No (sites are always public)")
                console.print(table)
                console.print(Panel(
                    f"[green]✓[/green] Site deployed from [cyan]{path.resolve()}[/cyan]\n"
                    f"[dim]ℹ Sites are publicly accessible - no password protection available.[/dim]",
                    border_style="green",
                ))
        except Exception as e:
            progress.update(task, completed=True)
            if compress:
                import shutil
                shutil.rmtree(upload_path, ignore_errors=True)
            console.print(f"[red]✗ Error:[/red] {e}")
            sys.exit(1)


@cli.command()
@click.argument("folder_path", type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.option("--slug", "-s", default=None, help="Override slug")
@click.option("--token", "-t", default=None, help="Override access token")
@click.option("--compress", "-c", is_flag=True, help="Minify HTML, CSS, and JS before sync")
@click.pass_context
def sync(ctx, folder_path: str, slug: Optional[str], token: Optional[str], compress: bool):
    """Sync a local folder to an existing site deployment."""
    path = Path(folder_path).resolve()
    index_file = path / "index.html"
    if not index_file.exists():
        console.print("[red]✗ Error:[/red] No index.html found in folder. Site mode requires index.html.")
        sys.exit(1)

    config = load_config()
    base_url = ctx.obj.get("base_url")
    client = TempservClient(base_url=base_url, config=config)

    record = find_by_folder(config, str(path))

    if slug and token:
        pass
    elif record:
        slug = record.slug
        token = record.token
    else:
        console.print(Panel(
            f"[yellow]⚠ No existing deployment found for [cyan]{path}[/cyan]\n\n"
            f"Options:\n"
            f"1. Run [bold]tempserv site {path}[/bold] to deploy first\n"
            f"2. Provide --slug and --token manually",
            border_style="yellow",
            title="No Deployment Found",
        ))
        sys.exit(1)

    upload_path = path
    if compress:
        import tempfile
        from tempserv.compress import compress_folder
        temp_dir = Path(tempfile.mkdtemp(prefix="tempserv_"))
        total_original, total_compressed = compress_folder(path, temp_dir)
        upload_path = temp_dir
        savings = total_original - total_compressed
        pct = (savings / total_original * 100) if total_original > 0 else 0
        console.print(f"[dim]Compressed: {total_original:,} → {total_compressed:,} bytes ({pct:.1f}% saved)[/dim]")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Syncing {path.name}...", total=None)
        try:
            result = client.replace_folder(slug, upload_path, token=token)
            progress.update(task, completed=True)

            if compress:
                import shutil
                shutil.rmtree(upload_path, ignore_errors=True)

            if ctx.obj.get("json"):
                click.echo(json.dumps(result, indent=2))
            else:
                console.print(Panel(
                    f"[green]✓[/green] Site synced successfully\n"
                    f"URL: [cyan]{base_url or config.base_url}/site/{slug}[/cyan]",
                    title="Sync Complete",
                    border_style="green",
                ))
        except Exception as e:
            progress.update(task, completed=True)
            if compress:
                import shutil
                shutil.rmtree(upload_path, ignore_errors=True)
            console.print(f"[red]✗ Error:[/red] {e}")
            sys.exit(1)


@cli.command()
@click.argument("target", required=False)
@click.pass_context
def open(ctx, target: Optional[str]):
    """Open a deployed site or recent upload in browser."""
    config = load_config()
    base_url = ctx.obj.get("base_url") or config.base_url

    if target:
        if target.startswith("http"):
            url = target
        elif "/" in target:
            path = Path(target).resolve()
            record = find_by_folder(config, str(path))
            if record:
                url = record.url
            else:
                console.print(f"[red]✗ No deployment found for {path}[/red]")
                sys.exit(1)
        else:
            url = f"{base_url}/site/{target}" if target.isalpha() else f"{base_url}/file/{target}"
    else:
        if not config.recent_uploads:
            console.print("[yellow]No recent uploads found.[/yellow]")
            sys.exit(1)
        latest = config.recent_uploads[0]
        url = latest.url

    webbrowser.open(url)
    console.print(Panel(
        f"[green]✓[/green] Opening in browser:\n[cyan]{url}[/cyan]",
        title="Browser Opened",
        border_style="green",
    ))


@cli.command()
@click.option("--expired-only", "-e", is_flag=True, help="Only remove expired records")
@click.option("--all", "-a", "all_records", is_flag=True, help="Remove all records")
@click.pass_context
def clean(ctx, expired_only: bool, all_records: bool):
    """Clean up expired or dead upload records from local config."""
    config = load_config()
    if not config.recent_uploads:
        console.print("[yellow]No records to clean.[/yellow]")
        return

    from datetime import datetime
    now = datetime.utcnow()
    removed = 0
    kept = []

    for record in config.recent_uploads:
        if all_records:
            removed += 1
            continue
        if expired_only:
            try:
                expires_at = datetime.fromisoformat(record.expires_at)
                if expires_at < now:
                    removed += 1
                    continue
            except (ValueError, TypeError):
                pass
        kept.append(record)

    if all_records:
        kept = []

    config.recent_uploads = kept
    save_config(config)

    if ctx.obj.get("json"):
        click.echo(json.dumps({"removed": removed, "remaining": len(kept)}, indent=2))
    else:
        console.print(Panel(
            f"[green]✓[/green] Removed [yellow]{removed}[/yellow] record(s)\n"
            f"[cyan]{len(kept)}[/cyan] record(s) remaining",
            title="Clean Complete",
            border_style="green",
        ))


@cli.command()
@click.option("--limit", "-l", default=10, help="Number of recent uploads to show")
@click.pass_context
def list(ctx, limit: int):
    """Show recent uploads."""
    config = load_config()
    uploads = config.recent_uploads[:limit]

    if not uploads:
        console.print("[yellow]No recent uploads found.[/yellow]")
        return

    if ctx.obj.get("json"):
        click.echo(json.dumps([u.__dict__ for u in uploads], indent=2))
    else:
        table = Table(title="Recent Uploads", border_style="cyan")
        table.add_column("Slug", style="cyan")
        table.add_column("URL", style="white")
        table.add_column("Mode", style="yellow")
        table.add_column("Folder", style="dim")
        table.add_column("Uploaded", style="green")
        for upload in uploads:
            folder_display = ""
            if upload.folder_path:
                folder_display = Path(upload.folder_path).name
            table.add_row(
                upload.slug,
                upload.url,
                upload.mode,
                folder_display,
                upload.uploaded_at[:19],
            )
        console.print(table)


@cli.command()
@click.pass_context
def status(ctx):
    """Check worker health and local config status."""
    config = load_config()
    base_url = ctx.obj.get("base_url") or config.base_url
    client = TempservClient(base_url=base_url, config=config)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Checking worker health...", total=None)
        health = client.check_health()
        progress.update(task, completed=True)

    if ctx.obj.get("json"):
        click.echo(json.dumps({
            "health": health,
            "config": {
                "base_url": config.base_url,
                "default_expiry": config.default_expiry,
                "recent_uploads": len(config.recent_uploads),
            }
        }, indent=2))
    else:
        status_icon = "🟢" if health["status"] == "healthy" else "🔴"
        table = Table(title=f"{status_icon} Tempserv Status", border_style="green")
        table.add_column("Component", style="cyan")
        table.add_column("Status", style="white")
        table.add_column("Details", style="dim")

        table.add_row("Worker", health["status"].upper(), f"{health.get('response_time_ms', 0):.0f}ms")
        table.add_row("Base URL", "configured", config.base_url)
        table.add_row("Default Expiry", "set", config.default_expiry)
        table.add_row("Recent Uploads", str(len(config.recent_uploads)), "stored locally")

        console.print(table)


@cli.command()
@click.argument("slug", required=False)
@click.option("--copy", "-c", is_flag=True, help="Copy URL to clipboard")
@click.pass_context
def share(ctx, slug: Optional[str], copy: bool):
    """Get shareable link for a deployment."""
    config = load_config()
    base_url = ctx.obj.get("base_url") or config.base_url

    if not slug:
        if not config.recent_uploads:
            console.print("[yellow]No recent uploads found.[/yellow]")
            sys.exit(1)
        slug = config.recent_uploads[0].slug

    record = None
    for r in config.recent_uploads:
        if r.slug == slug:
            record = r
            break

    if record:
        url = record.url
        mode = record.mode
    else:
        url = f"{base_url}/site/{slug}"
        mode = "unknown"

    if copy:
        try:
            import pyperclip
            pyperclip.copy(url)
            copied_msg = "[green]✓[/green] Copied to clipboard!"
        except ImportError:
            copied_msg = "[yellow]⚠ pyperclip not installed. Install with: pip install pyperclip[/yellow]"
    else:
        copied_msg = ""

    if ctx.obj.get("json"):
        click.echo(json.dumps({"slug": slug, "url": url, "mode": mode}, indent=2))
    else:
        table = Table(title="Share Link", border_style="cyan")
        table.add_column("Field", style="cyan")
        table.add_column("Value", style="white")
        table.add_row("Slug", slug)
        table.add_row("URL", url)
        table.add_row("Mode", mode)
        console.print(table)
        if copied_msg:
            console.print(copied_msg)


@cli.command()
@click.argument("folder_path", type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.argument("slug")
@click.pass_context
def diff(ctx, folder_path: str, slug: str):
    """Compare local folder with deployed site."""
    path = Path(folder_path).resolve()
    config = load_config()
    base_url = ctx.obj.get("base_url")
    client = TempservClient(base_url=base_url, config=config)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Comparing files...", total=None)
        try:
            result = client.get_folder_diff(path, slug)
            progress.update(task, completed=True)
        except Exception as e:
            progress.update(task, completed=True)
            if "404" in str(e) or "not found" in str(e).lower():
                console.print(Panel(
                    f"[yellow]⚠ Server doesn't support file listing yet.[/yellow]\n"
                    f"Deploy the updated worker with /api/info/ endpoint first.\n"
                    f"[dim]Error: {e}[/dim]",
                    border_style="yellow",
                    title="Endpoint Not Available",
                ))
                sys.exit(1)
            console.print(f"[red]✗ Error:[/red] {e}")
            sys.exit(1)

    if ctx.obj.get("json"):
        click.echo(json.dumps(result, indent=2))
    else:
        table = Table(title=f"Diff: {path.name} vs {slug}", border_style="cyan")
        table.add_column("Status", style="cyan")
        table.add_column("File", style="white")
        table.add_column("Size", style="dim")

        for f in result["new"]:
            fpath = path / f
            size = fpath.stat().st_size
            size_str = f"{size/1024:.1f}KB" if size > 1024 else f"{size}B"
            table.add_row("[green]+ NEW[/green]", f, size_str)

        for f in result["changed"]:
            fpath = path / f
            size = fpath.stat().st_size
            size_str = f"{size/1024:.1f}KB" if size > 1024 else f"{size}B"
            table.add_row("[yellow]~ CHANGED[/yellow]", f, size_str)

        for f in result["removed"]:
            table.add_row("[red]- REMOVED[/red]", f, "")

        if not result["new"] and not result["changed"] and not result["removed"]:
            table.add_row("[green]✓ SYNCED[/green]", "All files match", "")

        console.print(table)
        console.print(f"[dim]Local: {result['total_local']} files | Server: {result['total_server']} files[/dim]")


@cli.command("help")
@click.pass_context
def help_cmd(ctx):
    """Show help, benefits, and web UI info."""
    config = load_config()
    base_url = ctx.obj.get("base_url") or config.base_url

    console.print(Panel(
        f"[bold cyan]🔥 Tempserv v0.2.3[/bold cyan]\n\n"
        f"[bold]Why Use the CLI?[/bold]\n\n"
        f"  [green]🔑[/green] Auto Token Management — tokens saved to [cyan]~/.tempserv/config.json[/cyan]\n"
        f"  [green]🔄[/green] One-Command Sync — [cyan]tempserv sync ./folder[/cyan]\n"
        f"  [green]📦[/green] Compress — minify HTML/CSS/JS with [cyan]--compress[/cyan]\n"
        f"  [green]📊[/green] Diff — compare local vs live with [cyan]tempserv diff[/cyan]\n"
        f"  [green]🚀[/green] CI/CD Ready — scriptable, JSON output, no browser needed\n"
        f"  [green]🌐[/green] Web UI — visit [cyan]{base_url}[/cyan] for drag & drop uploads\n\n"
        f"[bold]Quick Commands:[/bold]\n"
        f"  [cyan]tempserv site ./folder[/cyan]       — Deploy a website\n"
        f"  [cyan]tempserv upload file.zip[/cyan]     — Upload a file\n"
        f"  [cyan]tempserv sync ./folder[/cyan]       — Sync changes\n"
        f"  [cyan]tempserv list[/cyan]                — Recent uploads\n"
        f"  [cyan]tempserv status[/cyan]              — Health check\n\n"
        f"💡 [dim]Web UI available at {base_url} for quick drag & drop uploads[/dim]",
        title="📖 Tempserv Help & Benefits",
        border_style="cyan",
    ))


def main():
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
