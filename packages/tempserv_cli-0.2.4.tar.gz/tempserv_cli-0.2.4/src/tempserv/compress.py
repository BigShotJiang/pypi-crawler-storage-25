"""File compression utilities for minifying HTML, CSS, and JS."""

import os
import re
from pathlib import Path
from typing import Tuple


def compress_html(content: str) -> str:
    try:
        import htmlmin
        return htmlmin.minify(content, remove_comments=True, remove_empty_space=True)
    except (ImportError, ModuleNotFoundError):
        pass
    try:
        import htmlmin2
        return htmlmin2.minify(content, remove_comments=True, remove_empty_space=True)
    except (ImportError, ModuleNotFoundError):
        pass
    content = re.sub(r'<!--.*?-->', '', content, flags=re.DOTALL)
    content = re.sub(r'\s+', ' ', content)
    content = re.sub(r'>\s+<', '><', content)
    return content.strip()


def compress_css(content: str) -> str:
    try:
        from csscompressor import compress
        return compress(content)
    except (ImportError, ModuleNotFoundError):
        content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
        content = re.sub(r'\s+', ' ', content)
        content = re.sub(r'\s*([{}:;,])\s*', r'\1', content)
        return content.strip()


def compress_js(content: str) -> str:
    try:
        import rjsmin
        return rjsmin.jsmin(content)
    except (ImportError, ModuleNotFoundError):
        content = re.sub(r'//.*?$', '', content, flags=re.MULTILINE)
        content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
        content = re.sub(r'\s+', ' ', content)
        return content.strip()


def compress_file(content: str, file_path: str) -> Tuple[str, int]:
    original_size = len(content.encode('utf-8'))
    ext = Path(file_path).suffix.lower()

    if ext == '.html' or ext == '.htm':
        compressed = compress_html(content)
    elif ext == '.css':
        compressed = compress_css(content)
    elif ext == '.js':
        compressed = compress_js(content)
    else:
        return content, original_size

    compressed_size = len(compressed.encode('utf-8'))
    return compressed, compressed_size


def compress_folder(folder_path: Path, temp_dir: Path) -> Tuple[int, int]:
    folder_path = Path(folder_path)
    temp_dir = Path(temp_dir)
    temp_dir.mkdir(parents=True, exist_ok=True)

    total_original = 0
    total_compressed = 0

    for root, _, filenames in os.walk(folder_path):
        for fname in filenames:
            fpath = Path(root) / fname
            rel_path = fpath.relative_to(folder_path)
            temp_fpath = temp_dir / rel_path
            temp_fpath.parent.mkdir(parents=True, exist_ok=True)

            ext = fpath.suffix.lower()
            if ext in ('.html', '.htm', '.css', '.js'):
                try:
                    content = fpath.read_text(encoding='utf-8')
                    compressed, compressed_size = compress_file(content, str(rel_path))
                    original_size = len(content.encode('utf-8'))
                    temp_fpath.write_text(compressed, encoding='utf-8')
                    total_original += original_size
                    total_compressed += compressed_size
                except Exception:
                    import shutil
                    shutil.copy2(fpath, temp_fpath)
                    size = fpath.stat().st_size
                    total_original += size
                    total_compressed += size
            else:
                import shutil
                shutil.copy2(fpath, temp_fpath)
                size = fpath.stat().st_size
                total_original += size
                total_compressed += size

    return total_original, total_compressed
