# Tempserv CLI

A command-line interface for [Tempserv](https://tempserv.badman993944.workers.dev) - temporary file & site hosting on Cloudflare Workers.

## Installation

```bash
pip install -e .
```

Or install from PyPI (once published):

```bash
pip install tempserv-cli
```

## Quick Start

```bash
# Configure your tempserv instance
tempserv login https://tempserv.badman993944.workers.dev

# Upload a single file
tempserv upload photo.jpg

# Upload a folder (site mode)
tempserv upload ./my-website --mode site

# Upload with password protection
tempserv upload secret.pdf --password "mysecret"

# Upload with custom expiry
tempserv upload video.mp4 --expiry 6hr

# Download a file
tempserv download abc123

# View file info
tempserv info abc123

# Replace an existing file
tempserv replace abc123 new-version.jpg

# Delete a file
tempserv delete abc123

# List recent uploads
tempserv list
```

## Commands

| Command | Description |
|---------|-------------|
| `tempserv login [URL]` | Configure tempserv instance URL |
| `tempserv upload FILE` | Upload a file or folder |
| `tempserv download SLUG` | Download a file |
| `tempserv info SLUG` | View file metadata |
| `tempserv delete SLUG` | Delete a file |
| `tempserv replace SLUG FILE` | Replace an existing file |
| `tempserv list` | Show recent uploads |

## Options

### Upload Options
- `--mode, -m` - Upload mode: `file` or `site` (auto-detected for folders)
- `--expiry, -e` - Expiry time: `15min`, `30min`, `1hr`, `2hr`, `6hr`, `12hr`, `24hr`, or custom minutes (1-1440)
- `--password, -p` - Password protect the upload

### Global Options
- `--url, -u` - Override base URL for a single command
- `--json` - Output in JSON format (for scripting)

## Python API

```python
from tempserv import upload, download, info, delete, replace

# Upload a file
result = upload("photo.jpg", expiry="1hr", password="secret")
print(result["url"])

# Download a file
download("abc123", output_path="./downloads/")

# Get file info
file_info = info("abc123")
print(file_info)

# Delete a file
delete("abc123", token="your-access-token")

# Replace a file
replace("abc123", "new-version.jpg", token="your-access-token")
```

## Configuration

Config is stored in `~/.tempserv/config.json`:

```json
{
  "base_url": "https://tempserv.badman993944.workers.dev",
  "default_expiry": "1hr",
  "default_mode": "file",
  "recent_uploads": [
    {
      "slug": "abc123",
      "url": "https://tempserv.badman993944.workers.dev/file/abc123",
      "token": "XyZ12",
      "mode": "file",
      "uploaded_at": "2024-01-01T00:00:00",
      "expires_at": "2024-01-01T01:00:00"
    }
  ]
}
```

## License

MIT
