"""Tests for Tempserv CLI."""

import pytest
from pathlib import Path
from tempserv.config import Config, UploadRecord, load_config, save_config, add_upload, find_upload
from tempserv.api import EXPIRY_MAP


class TestConfig:
    def test_default_config(self):
        config = Config()
        assert config.base_url == "https://tempserv.badman993944.workers.dev"
        assert config.default_expiry == "1hr"
        assert config.default_mode == "file"
        assert config.recent_uploads == []

    def test_expiry_map(self):
        assert EXPIRY_MAP["15min"] == 900
        assert EXPIRY_MAP["1hr"] == 3600
        assert EXPIRY_MAP["24hr"] == 86400

    def test_add_upload(self, tmp_path):
        import tempserv.config as config_mod
        config_mod.CONFIG_FILE = tmp_path / "config.json"
        config_mod.CONFIG_DIR = tmp_path

        config = Config()
        record = UploadRecord(
            slug="test123",
            url="https://example.com/file/test123",
            token="abc",
            mode="file",
            uploaded_at="2024-01-01T00:00:00",
            expires_at="2024-01-01T01:00:00",
        )
        config = add_upload(config, record)
        assert len(config.recent_uploads) == 1
        assert config.recent_uploads[0].slug == "test123"

    def test_find_upload(self, tmp_path):
        import tempserv.config as config_mod
        config_mod.CONFIG_FILE = tmp_path / "config.json"
        config_mod.CONFIG_DIR = tmp_path

        config = Config()
        record = UploadRecord(
            slug="findme",
            url="https://example.com/file/findme",
            token="xyz",
            mode="file",
            uploaded_at="2024-01-01T00:00:00",
            expires_at="2024-01-01T01:00:00",
        )
        config = add_upload(config, record)
        found = find_upload(config, "findme")
        assert found is not None
        assert found.slug == "findme"
        assert find_upload(config, "notfound") is None
