"""vfd_video_asr atom: 飞书视频下载 → ffmpeg 抽音 → 火山 ASR 2.0 → intermediate/asr.json + transcript.srt."""
from __future__ import annotations

import argparse
import base64
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import requests

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.runtime import usage
from scholai.common.credentials_reader import get_volc_asr_api_key

_ASR_SUBMIT_URL = "https://openspeech.bytedance.com/api/v3/auc/bigmodel/submit"
_ASR_QUERY_URL = "https://openspeech.bytedance.com/api/v3/auc/bigmodel/query"
_ASR_RESOURCE_ID = "volc.seedasr.auc"
_POLL_INTERVAL = 5
_MAX_WAIT = 600  # 10 分钟上限（30 分钟视频的转录一般 2–5 分钟）


def _download_video(message_id: str, file_key: str, out_path) -> None:
    # lark-cli rejects absolute paths in --output (validation: "relative only").
    # Pass filename + set cwd so the resolved write target is still out_path.
    out_path = Path(out_path)
    cmd = [
        "lark-cli", "im", "+messages-resources-download",
        "--message-id", message_id,
        "--file-key", file_key,
        "--type", "file",
        "--output", out_path.name,
        "--as", "bot",
    ]
    proc = subprocess.run(
        cmd, capture_output=True, text=True, timeout=600,
        cwd=str(out_path.parent),
    )
    if proc.returncode != 0:
        raise RuntimeError(f"lark-cli download failed (rc={proc.returncode}): {proc.stderr[:500]}")
    if not out_path.exists() or out_path.stat().st_size == 0:
        raise RuntimeError(f"lark-cli download produced no file at {out_path}")


def _extract_audio(video_path, audio_path) -> None:
    cmd = ["ffmpeg", "-y", "-i", str(video_path),
           "-vn", "-acodec", "libmp3lame", "-ar", "16000", "-ac", "1",
           str(audio_path)]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg failed (rc={proc.returncode}): {proc.stderr[-500:]}")


def _asr_transcribe(audio_path, api_key: str) -> dict:
    """Submit + poll until ASR done; return full response dict."""
    audio_bytes = audio_path.read_bytes()
    b64_audio = base64.b64encode(audio_bytes).decode("ascii")
    ext = audio_path.suffix.lower().lstrip(".")
    audio_format = ext if ext in ("wav", "mp3", "ogg", "raw") else "mp3"

    task_id = str(uuid.uuid4())
    submit_headers = {
        "X-Api-Key": api_key,
        "X-Api-Resource-Id": _ASR_RESOURCE_ID,
        "X-Api-Request-Id": task_id,
        "X-Api-Sequence": "-1",
        "Content-Type": "application/json",
    }
    payload = {
        "audio": {"data": b64_audio, "format": audio_format},
        "request": {
            "model_name": "bigmodel",
            "enable_punc": True,
            "enable_itn": True,
            "show_utterances": True,
        },
    }

    resp = requests.post(_ASR_SUBMIT_URL, headers=submit_headers, json=payload, timeout=60)
    code = resp.headers.get("X-Api-Status-Code", "")
    if code != "20000000":
        msg = resp.headers.get("X-Api-Message", "")
        raise RuntimeError(f"ASR submit failed: {code} - {msg}: {resp.text[:300]}")

    query_headers = {
        "X-Api-Key": api_key,
        "X-Api-Resource-Id": _ASR_RESOURCE_ID,
        "X-Api-Request-Id": task_id,
        "Content-Type": "application/json",
    }
    elapsed = 0
    while elapsed < _MAX_WAIT:
        time.sleep(_POLL_INTERVAL)
        elapsed += _POLL_INTERVAL
        q = requests.post(_ASR_QUERY_URL, headers=query_headers, json={}, timeout=30)
        q_code = q.headers.get("X-Api-Status-Code", "")
        if q_code == "20000000":
            return json.loads(q.text)
        if q_code in ("20000001", "20000002"):
            continue
        raise RuntimeError(f"ASR query failed: {q_code}: {q.text[:300]}")
    raise TimeoutError(f"ASR polling timed out after {_MAX_WAIT}s")


def _format_srt_time(ms: int) -> str:
    total_seconds, milli = divmod(int(ms), 1000)
    h, rem = divmod(total_seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d},{milli:03d}"


def _utterances_to_srt(utterances: list[dict]) -> str:
    lines = []
    for i, u in enumerate(utterances, 1):
        start = _format_srt_time(u.get("start_time", 0))
        end = _format_srt_time(u.get("end_time", 0))
        text = u.get("text", "").strip()
        lines += [str(i), f"{start} --> {end}", text, ""]
    return "\n".join(lines)


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "vfd_video_asr")
    ws = workspace_path(run_id)
    src_path = ws / "input" / "source.json"
    video_path = ws / "input" / "video.mp4"
    audio_path = ws / "intermediate" / "audio.mp3"
    asr_path = ws / "intermediate" / "asr.json"
    srt_path = ws / "intermediate" / "transcript.srt"

    try:
        api_key = get_volc_asr_api_key()
        if not api_key:
            raise RuntimeError("VOLC_ASR_API_KEY 未配置；跑 scholai-plugin-onboard 补。")

        from scholai.course.schemas.source import SourceSpec, VideoSource
        spec = SourceSpec.model_validate_json(src_path.read_text(encoding="utf-8"))
        if not isinstance(spec.root, VideoSource):
            raise ValueError(f"vfd_video_asr: expected source type='video', got {spec.root.type!r}")
        vsrc = spec.root

        audio_path.parent.mkdir(parents=True, exist_ok=True)

        if not video_path.exists():
            log.info("downloading video %s (file_key=%s)", vsrc.message_id, vsrc.file_key)
            _download_video(vsrc.message_id, vsrc.file_key, video_path)
            log.info("downloaded %d bytes", video_path.stat().st_size)
        else:
            log.info("video already present at %s, skip download", video_path)

        log.info("extracting audio → %s", audio_path)
        _extract_audio(video_path, audio_path)
        log.info("audio extracted (%d bytes)", audio_path.stat().st_size)

        log.info("calling volc ASR 2.0 (resource=%s)", _ASR_RESOURCE_ID)
        result = _asr_transcribe(audio_path, api_key)
        duration_ms = result.get("audio_info", {}).get("duration", vsrc.duration_ms)
        usage.record_asr(duration_seconds=duration_ms / 1000.0)

        asr_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        utterances = result.get("result", {}).get("utterances", [])
        log.info("ASR returned %d utterances, %.1fs", len(utterances), duration_ms / 1000.0)

        srt_path.write_text(_utterances_to_srt(utterances), encoding="utf-8")
        log.info("done → intermediate/asr.json + transcript.srt")
        return {"status": "done", "path": "intermediate/asr.json"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
