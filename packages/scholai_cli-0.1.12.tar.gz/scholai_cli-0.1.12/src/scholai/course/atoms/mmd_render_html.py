"""mmd_render_html atom: output/mindmap.md → output/mindmap.html (markmap autoloader template, 零 LLM)."""
from __future__ import annotations

import argparse
import json
import re
import sys

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger


_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)


# CSS 与 savePNG JS 整段从 shared-prompts/思维导图转html prompt.md 照搬。
# 双花括号 {{ }} 是 .format() 的字面量转义（CSS / JS 大量用花括号）。
_HTML_SHELL = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title} - 思维导图</title>
  <script src="https://cdn.jsdelivr.net/npm/markmap-autoloader@0.16"></script>
  <style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{ font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif; background: #f5f5f5; }}
    #toolbar {{ position: fixed; top: 16px; right: 16px; z-index: 100; }}
    #save-png-btn {{
      padding: 8px 20px;
      background: #4a90e2; color: white; border: none; border-radius: 6px;
      cursor: pointer; font-size: 14px;
    }}
    #save-png-btn:hover {{ background: #357abd; }}
    .markmap {{ width: 100vw; height: 100vh; }}
  </style>
</head>
<body>
  <div id="toolbar">
    <button id="save-png-btn" onclick="savePNG()">保存为 PNG</button>
  </div>
  <div class="markmap">
    <script type="text/template">
{mmd_content}
    </script>
  </div>
  <script>
    async function savePNG() {{
      const svg = document.querySelector('svg.markmap');
      if (!svg) {{ alert('思维导图尚未加载完成，请稍后再试'); return; }}

      const scale = 2;
      const padding = 24;
      const bbox = svg.getBBox();
      const w = bbox.width + padding * 2;
      const h = bbox.height + padding * 2;

      const clone = svg.cloneNode(true);
      const liveEls = Array.from(svg.querySelectorAll('*'));
      const cloneEls = Array.from(clone.querySelectorAll('*'));
      const inlineProps = [
        'fill', 'fill-opacity', 'stroke', 'stroke-width', 'stroke-opacity',
        'stroke-linecap', 'stroke-linejoin', 'stroke-dasharray',
        'opacity', 'font-size', 'font-family', 'font-weight',
        'text-anchor', 'dominant-baseline', 'display', 'visibility'
      ];
      liveEls.forEach((el, i) => {{
        const cloneEl = cloneEls[i];
        if (!cloneEl) return;
        const computed = window.getComputedStyle(el);
        inlineProps.forEach(prop => {{
          const val = computed.getPropertyValue(prop);
          if (val) cloneEl.setAttribute(prop, val);
        }});
        cloneEl.removeAttribute('filter');
        cloneEl.style.filter = 'none';
      }});
      clone.querySelectorAll('filter').forEach(el => el.remove());

      clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
      clone.setAttribute('width', w);
      clone.setAttribute('height', h);
      clone.setAttribute('viewBox', `${{bbox.x - padding}} ${{bbox.y - padding}} ${{w}} ${{h}}`);

      const styleEl = document.createElementNS('http://www.w3.org/2000/svg', 'style');
      styleEl.textContent = '* {{ filter: none !important; }} a, text, tspan {{ text-decoration: none !important; }}';
      clone.insertBefore(styleEl, clone.firstChild);

      const svgStr = new XMLSerializer().serializeToString(clone);
      const dataUri = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgStr);

      const canvas = document.createElement('canvas');
      canvas.width = w * scale;
      canvas.height = h * scale;
      const ctx = canvas.getContext('2d');
      ctx.scale(scale, scale);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, w, h);

      const filename = document.title.replace(' - 思维导图', '') + '_思维导图.png';

      const img = new Image();
      img.onload = async function () {{
        try {{
          ctx.drawImage(img, 0, 0, w, h);

          if (window.showSaveFilePicker) {{
            try {{
              const handle = await window.showSaveFilePicker({{
                suggestedName: filename,
                types: [{{ description: 'PNG 图片', accept: {{ 'image/png': ['.png'] }} }}]
              }});
              const writable = await handle.createWritable();
              canvas.toBlob(async (blob) => {{
                await writable.write(blob);
                await writable.close();
              }}, 'image/png');
              return;
            }} catch (e) {{
              if (e.name === 'AbortError') return;
            }}
          }}

          const a = document.createElement('a');
          a.download = filename;
          a.href = canvas.toDataURL('image/png');
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }} catch (e) {{
          alert('PNG 导出失败：' + e.message);
        }}
      }};
      img.onerror = function () {{
        alert('图片渲染失败，无法导出 PNG。');
      }};
      img.src = dataUri;
    }}
  </script>
</body>
</html>
"""


def _extract_title(mmd: str, fallback: str) -> str:
    m = _H1_RE.search(mmd)
    return m.group(1).strip() if m else fallback


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "mmd_render_html")
    try:
        ws = workspace_path(run_id)
        src = (ws / "output" / "mindmap.md").read_text(encoding="utf-8")
        log.info("read mindmap.md (%d chars)", len(src))
        title = _extract_title(src, fallback=run_id)
        html = _HTML_SHELL.format(title=title, mmd_content=src)
        out = ws / "output" / "mindmap.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html, encoding="utf-8")
        log.info("done → output/mindmap.html (%d bytes)", len(html.encode()))
        return {"status": "done", "path": "output/mindmap.html"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
