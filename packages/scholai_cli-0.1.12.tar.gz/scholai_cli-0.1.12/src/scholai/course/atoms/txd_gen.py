"""txd_gen atom: VFD + IOD + PD → TXD.md (含 image 占位符)。"""
from __future__ import annotations

import argparse
import json
import sys

from scholai.runtime.llm import llm_text
from scholai.runtime.prompt_loader import get_prompt
from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "txd_gen")
    try:
        ws = workspace_path(run_id)
        vfd = (ws / "intermediate" / "VFD.json").read_text(encoding="utf-8")
        iod = (ws / "intermediate" / "IOD.json").read_text(encoding="utf-8")
        pd = (ws / "intermediate" / "PD.md").read_text(encoding="utf-8")
        log.info("read VFD+IOD+PD, calling LLM")
        prompt = get_prompt("course", "txd").format(vfd=vfd, iod=iod, pd=pd)
        md = llm_text(prompt, temperature=0.5)
        log.info("LLM returned %d chars", len(md))
        out = ws / "intermediate" / "TXD.md"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(md, encoding="utf-8")
        log.info("done → %s", out.relative_to(ws))
        return {"status": "done", "path": "intermediate/TXD.md"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
