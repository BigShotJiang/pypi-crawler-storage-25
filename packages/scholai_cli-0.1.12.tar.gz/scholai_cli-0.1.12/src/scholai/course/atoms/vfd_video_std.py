"""vfd_video_std atom: intermediate/asr.json → intermediate/std.md (LLM 分段)."""
from __future__ import annotations

import argparse
import json
import sys

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.runtime.llm import llm_text
from scholai.runtime.prompt_loader import get_prompt


def _format_utterances(utterances: list[dict]) -> str:
    lines = []
    for u in utterances:
        sec = int((u.get("start_time", 0)) / 1000)
        mm, ss = divmod(sec, 60)
        text = (u.get("text") or "").strip()
        lines.append(f"[{mm:02d}:{ss:02d}] {text}")
    return "\n".join(lines)


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "vfd_video_std")
    ws = workspace_path(run_id)
    asr_path = ws / "intermediate" / "asr.json"
    out_path = ws / "intermediate" / "std.md"
    try:
        asr = json.loads(asr_path.read_text(encoding="utf-8"))
        utterances = asr.get("result", {}).get("utterances", [])
        if not utterances:
            raise RuntimeError("asr.json contains no utterances")

        formatted = _format_utterances(utterances)
        log.info("formatting %d utterances → LLM", len(utterances))

        # Prompt 模板与 vfd-gen/shared-prompts/分段prompt.md 字字对应；逐字稿在外层拼接喂入。
        prompt_tpl = get_prompt("course", "video_std")
        prompt = f"{prompt_tpl}\n\n# 实际逐字稿\n\n{formatted}"
        std = llm_text(prompt, temperature=0.3)
        if not std.strip():
            raise RuntimeError("LLM returned empty STD")

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(std, encoding="utf-8")
        log.info("done → intermediate/std.md (%d chars)", len(std))
        return {"status": "done", "path": "intermediate/std.md"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
