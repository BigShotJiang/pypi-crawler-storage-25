"""IOD atom: 从 VFD.json 提取教学目标, 产 IOD.json。"""
from __future__ import annotations

import argparse
import json
import sys

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.runtime.llm import llm_structured
from scholai.runtime.prompt_loader import get_prompt
from scholai.course.schemas.iod import IOD


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "iod")
    ws = workspace_path(run_id)
    vfd_path = ws / "intermediate" / "VFD.json"
    out_path = ws / "intermediate" / "IOD.json"

    try:
        vfd_text = vfd_path.read_text(encoding="utf-8")
        log.info("read VFD.json (%d bytes), calling LLM", len(vfd_text))
        prompt = get_prompt("course", "iod").replace("{vfd}", vfd_text)
        iod: IOD = llm_structured(prompt, response_schema=IOD)
        log.info("LLM returned %d objectives", len(iod.objectives) if hasattr(iod, "objectives") else -1)
        out_path.write_text(iod.model_dump_json(indent=2), encoding="utf-8")
        log.info("done → %s", out_path.relative_to(ws))
        return {"status": "done", "path": "intermediate/IOD.json"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
