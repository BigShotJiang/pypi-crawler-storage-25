"""txd_imagegen atom: TXD.md 的 {image:slot:prompt} 占位符 → images/<slot>.jpg + TXD_final.md。"""
from __future__ import annotations

import argparse
import json
import re
import struct
import sys
from concurrent.futures import ThreadPoolExecutor

from scholai.runtime.llm import llm_image_gen
from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger


_PLACEHOLDER_RE = re.compile(r"\{image:(?P<slot>[a-z0-9_-]+):(?P<prompt>[^}]+)\}")

_MAX_WORKERS = 4


def _image_size(data: bytes) -> str:
    if data[:8] == b'\x89PNG\r\n\x1a\n':
        w, h = struct.unpack('>II', data[16:24])
        return f"{w}x{h}"
    if data[:2] == b'\xff\xd8':
        i = 2
        while i + 4 <= len(data):
            if data[i] != 0xff:
                break
            marker = data[i + 1]
            if marker in (0xc0, 0xc1, 0xc2):
                h, w = struct.unpack('>HH', data[i + 5:i + 9])
                return f"{w}x{h}"
            length = struct.unpack('>H', data[i + 2:i + 4])[0]
            i += 2 + length
    return "unknown"


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "txd_imagegen")
    try:
        ws = workspace_path(run_id)
        txd_path = ws / "intermediate" / "TXD.md"
        img_dir = ws / "intermediate" / "images"
        img_dir.mkdir(parents=True, exist_ok=True)

        txd = txd_path.read_text(encoding="utf-8")
        matches = list(_PLACEHOLDER_RE.finditer(txd))
        log.info("found %d image placeholders", len(matches))

        def _gen_one(m: re.Match) -> tuple[str, str]:
            slot = m.group("slot")
            prompt = m.group("prompt").strip()
            log.info("generating image: slot=%s prompt=%r", slot, prompt[:80])
            data = llm_image_gen(prompt)
            (img_dir / f"{slot}.jpg").write_bytes(data)
            log.info("saved %s.jpg (%s, %d bytes)", slot, _image_size(data), len(data))
            return m.group(0), f"![{slot}](images/{slot}.jpg)"

        with ThreadPoolExecutor(max_workers=_MAX_WORKERS) as pool:
            # pool.map preserves order and re-raises the first exception immediately.
            replacements = dict(pool.map(_gen_one, matches))

        final = _PLACEHOLDER_RE.sub(lambda m: replacements[m.group(0)], txd)
        (ws / "intermediate" / "TXD_final.md").write_text(final, encoding="utf-8")
        log.info("done → intermediate/TXD_final.md")
        return {"status": "done", "path": "intermediate/TXD_final.md"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
