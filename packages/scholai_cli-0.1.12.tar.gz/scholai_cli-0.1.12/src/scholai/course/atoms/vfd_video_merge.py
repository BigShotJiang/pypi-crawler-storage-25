"""vfd_video_merge atom: std.md + frames_cache.json → intermediate/VFD.json.

合成逻辑参考 vfd-gen step_volcark_video分析.py 的 merge_vfd()：subject / summary
直接从分段数据取，不再过 LLM。
"""
from __future__ import annotations

import argparse
import json
import sys

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.course.schemas.vfd import VFD, VFDFragment
from scholai.course.atoms.vfd_video_frames import _parse_std_segments


def _build_summary(segments: list[dict]) -> str:
    """把所有分段的 desc 字段用「。」拼起来。不做截断 —— 对齐 vfd-gen 的 merge_vfd 思路。"""
    descs = [seg["desc"].strip() for seg in segments if seg.get("desc")]
    return "。".join(descs)


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "vfd_video_merge")
    ws = workspace_path(run_id)
    src_path = ws / "input" / "source.json"
    std_path = ws / "intermediate" / "std.md"
    cache_path = ws / "intermediate" / "frames_cache.json"
    out_path = ws / "intermediate" / "VFD.json"
    try:
        from scholai.course.schemas.source import SourceSpec, VideoSource
        spec = SourceSpec.model_validate_json(src_path.read_text(encoding="utf-8"))
        if not isinstance(spec.root, VideoSource):
            raise ValueError(f"vfd_video_merge: expected source type='video', got {spec.root.type!r}")
        vsrc = spec.root

        std = std_path.read_text(encoding="utf-8")
        segments = _parse_std_segments(std)
        if not segments:
            raise RuntimeError("std.md parsed 0 segments")

        cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
        log.info("merging %d segments (cache hits=%d)", len(segments), len(cache))

        # subject = 第一段标题；summary = 各段 desc 拼接截断 —— 对齐 vfd-gen 的非 LLM 合成方式。
        subject = segments[0]["title"]
        summary = _build_summary(segments)
        log.info("subject=%r summary_len=%d", subject, len(summary))

        # fragments
        fragments: list[VFDFragment] = []
        for i, seg in enumerate(segments, 1):
            tr = seg["time_range"]
            content = f"[{tr}] {seg['title']}\n{seg['desc']}\n\n{seg['transcript']}"
            visual = cache.get(tr)
            fragments.append(VFDFragment(
                ref=f"seg_{i:02d}",
                content=content,
                visual_description=visual,
            ))

        vfd = VFD(
            source_type="video",
            source_uri=vsrc.file_key,
            subject=subject,
            summary=summary,
            fragments=fragments,
        )
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(vfd.model_dump_json(indent=2), encoding="utf-8")
        log.info("done → intermediate/VFD.json (subject=%r, fragments=%d)",
                 subject, len(fragments))
        return {"status": "done", "path": "intermediate/VFD.json"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
