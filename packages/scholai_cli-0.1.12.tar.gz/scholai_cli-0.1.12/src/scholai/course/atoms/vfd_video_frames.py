"""vfd_video_frames atom: input/video.mp4 + intermediate/std.md → intermediate/frames_cache.json.

每段视频上传到火山方舟 Files API，调用 Doubao 多模态做画面分析。
中途失败时缓存已分析段，重跑时跳过。

不走通用 llm_vision() —— ARK Files + responses 是 ARK 专用接口，
通用 OpenAI 兼容接口不支持视频文件上传。
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.runtime.prompt_loader import get_prompt
from scholai.runtime import usage
from scholai.common.credentials_reader import get_volc_vision_api_key


_ARK_BASE = "https://ark.cn-beijing.volces.com/api/v3"
_DEFAULT_MODEL = "doubao-seed-2-0-pro-260215"
_WAIT_TIMEOUT = 120  # seconds; ARK 文件 active 等待
# 画面分析并发上限。要调直接改这个常量；ARK 实测 5 路稳定，更高有限流风险。
_CONCURRENCY = 5


def _parse_std_segments(std_text: str) -> list[dict]:
    """STD markdown → list of {time_range, start_sec, end_sec, title, desc, transcript}."""
    pattern = re.compile(
        r"\[(\d{2}:\d{2}(?::\d{2})?\s*-\s*\d{2}:\d{2}(?::\d{2})?)\]\s*\n"
        r"([^\n]+)\n"
        r"([^\n]+)\n"
        r"([\s\S]*?)(?=\n\[\d{2}:\d{2}(?::\d{2})?\s*-|\Z)",
        re.MULTILINE,
    )
    segments = []
    for m in pattern.finditer(std_text):
        raw_range = m.group(1).strip()
        parts = re.split(r"\s*-\s*", raw_range, maxsplit=1)
        start_sec = _mmss_to_sec(parts[0])
        end_sec = _mmss_to_sec(parts[1])
        segments.append({
            "time_range": raw_range,
            "start_sec": start_sec,
            "end_sec": end_sec,
            "duration_sec": end_sec - start_sec,
            "title": m.group(2).strip(),
            "desc": m.group(3).strip(),
            "transcript": m.group(4).strip(),
        })
    return segments


def _mmss_to_sec(s: str) -> float:
    parts = s.strip().split(":")
    if len(parts) == 2:
        return int(parts[0]) * 60 + float(parts[1])
    return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])


def _cut_segment(video_path, start: float, duration: float, out_path) -> None:
    cmd = ["ffmpeg", "-y", "-ss", str(start), "-i", str(video_path),
           "-t", str(duration), "-c", "copy", str(out_path)]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg cut failed: {proc.stderr[-500:]}")


def _upload(api_key: str, file_path) -> str:
    with open(file_path, "rb") as f:
        resp = requests.post(
            f"{_ARK_BASE}/files",
            headers={"Authorization": f"Bearer {api_key}"},
            files={"file": (file_path.name, f, "video/mp4")},
            data={"purpose": "user_data"},
            timeout=300,
        )
    resp.raise_for_status()
    return resp.json()["id"]


def _wait_active(api_key: str, file_id: str) -> None:
    for _ in range(_WAIT_TIMEOUT):
        resp = requests.get(
            f"{_ARK_BASE}/files/{file_id}",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30,
        )
        resp.raise_for_status()
        st = resp.json().get("status")
        if st == "active":
            return
        if st == "error":
            raise RuntimeError(f"ARK file processing failed: {file_id}")
        time.sleep(1)
    raise TimeoutError(f"ARK file active wait timed out: {file_id}")


def _analyze(api_key: str, model: str, file_id: str, time_range: str, prompt_tpl: str) -> str:
    # Prompt 模板与 vfd-gen/shared-prompts/画面描述prompt.md 字字对应；
    # 时间范围在外层拼接，与 vfd-gen step_volcark_video分析.py 同样的方式。
    prompt = f"以下是该视频片段的时间范围：{time_range}\n\n{prompt_tpl}"
    payload = {
        "model": model,
        "input": [{
            "role": "user",
            "content": [
                {"type": "input_video", "file_id": file_id},
                {"type": "input_text", "text": prompt},
            ],
        }],
    }
    resp = requests.post(
        f"{_ARK_BASE}/responses",
        headers={"Authorization": f"Bearer {api_key}",
                 "Content-Type": "application/json"},
        json=payload,
        timeout=300,
    )
    resp.raise_for_status()
    data = resp.json()
    for item in data.get("output", []):
        if item.get("type") == "message":
            return item["content"][0]["text"]
    raise RuntimeError(f"ARK response missing message: {json.dumps(data)[:300]}")


def _delete(api_key: str, file_id: str) -> None:
    try:
        requests.delete(
            f"{_ARK_BASE}/files/{file_id}",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30,
        )
    except Exception:
        pass  # 删除失败仅占用配额，不影响主流程


def _process_segment(
    api_key: str, model: str, video_path, seg: dict, idx: int, total: int,
    seg_dir, prompt_tpl: str, cache: dict, cache_lock: threading.Lock,
    cache_path, log,
) -> None:
    """Single-segment work: cut → upload → wait → analyze → cache. Thread-safe via cache_lock."""
    tr = seg["time_range"]
    seg_path = seg_dir / f"seg_{idx:02d}.mp4"
    log.info("[%d/%d] %s — cut", idx, total, tr)
    _cut_segment(video_path, seg["start_sec"], seg["duration_sec"], seg_path)
    log.info("[%d/%d] %s — upload", idx, total, tr)
    file_id = _upload(api_key, seg_path)
    try:
        _wait_active(api_key, file_id)
        log.info("[%d/%d] %s — analyze", idx, total, tr)
        text = _analyze(api_key, model, file_id, tr, prompt_tpl)
        with cache_lock:
            cache[tr] = text
            cache_path.write_text(
                json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")
        usage.record_video_vision(model=model, segment_seconds=seg["duration_sec"])
        log.info("[%d/%d] %s — done (%d chars)", idx, total, tr, len(text))
    finally:
        _delete(api_key, file_id)


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "vfd_video_frames")
    ws = workspace_path(run_id)
    video_path = ws / "input" / "video.mp4"
    std_path = ws / "intermediate" / "std.md"
    cache_path = ws / "intermediate" / "frames_cache.json"
    seg_dir = ws / "intermediate" / "segments"

    try:
        api_key = get_volc_vision_api_key()
        if not api_key:
            raise RuntimeError("VOLC_VISION_API_KEY 未配置；跑 scholai-plugin-onboard 补。")
        if not video_path.exists():
            raise FileNotFoundError(f"video missing: {video_path}")
        if not std_path.exists():
            raise FileNotFoundError(f"std missing: {std_path}")

        seg_dir.mkdir(parents=True, exist_ok=True)
        std = std_path.read_text(encoding="utf-8")
        segments = _parse_std_segments(std)
        if not segments:
            raise RuntimeError("std.md parsed 0 segments")
        log.info("parsed %d segments from std.md", len(segments))

        cache: dict = {}
        if cache_path.exists():
            cache = json.loads(cache_path.read_text(encoding="utf-8"))
            log.info("loaded cache with %d cached segments", len(cache))

        prompt_tpl = get_prompt("course", "video_frames")
        model = _DEFAULT_MODEL

        pending: list[tuple[int, dict]] = []
        for i, seg in enumerate(segments, 1):
            if seg["time_range"] in cache:
                log.info("[%d/%d] %s — cached, skip", i, len(segments), seg["time_range"])
            else:
                pending.append((i, seg))

        if not pending:
            log.info("all %d segments cached → intermediate/frames_cache.json", len(segments))
            return {"status": "done", "path": "intermediate/frames_cache.json"}

        log.info("processing %d pending segments with concurrency=%d",
                 len(pending), _CONCURRENCY)

        cache_lock = threading.Lock()
        errors: list[tuple[int, str, BaseException]] = []
        with ThreadPoolExecutor(max_workers=_CONCURRENCY) as pool:
            future_map = {
                pool.submit(
                    _process_segment, api_key, model, video_path, seg, i,
                    len(segments), seg_dir, prompt_tpl, cache, cache_lock,
                    cache_path, log,
                ): (i, seg)
                for i, seg in pending
            }
            # Don't fail-fast: wait for all in-flight so partial cache lands.
            for fut in as_completed(future_map):
                i, seg = future_map[fut]
                try:
                    fut.result()
                except BaseException as e:
                    errors.append((i, seg["time_range"], e))
                    log.error("[%d/%d] %s — failed: %s: %s",
                              i, len(segments), seg["time_range"], type(e).__name__, e)

        if errors:
            i, tr, e = errors[0]
            raise RuntimeError(
                f"{len(errors)}/{len(pending)} segments failed; first: seg_{i:02d} ({tr}): {type(e).__name__}: {e}"
            ) from e

        log.info("all %d segments cached → intermediate/frames_cache.json", len(segments))
        return {"status": "done", "path": "intermediate/frames_cache.json"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
