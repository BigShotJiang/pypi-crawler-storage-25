"""lark_send atom: 把 output/video.mp4 用 lark-cli 推到原 IM 会话。

输入参数:
- run_id
- chat_type: 'direct' | 'group'
- chat_native_id: ou_xxx (direct) | oc_xxx (group)
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger


_VALID_CHAT_TYPES = {"direct", "group"}
_LARK_FILE_LIMIT_BYTES = 50 * 1024 * 1024  # Lark IM 文件上限


def run(run_id: str, chat_type: str, chat_native_id: str) -> dict:
    log = get_run_logger(run_id, "lark_send")
    try:
        if chat_type not in _VALID_CHAT_TYPES:
            raise ValueError(f"chat_type must be in {_VALID_CHAT_TYPES}, got {chat_type!r}")
        if not chat_native_id:
            raise ValueError("chat_native_id is empty")

        ws = workspace_path(run_id)
        video_path = ws / "output" / "video.mp4"
        cover_path = ws / "output" / "cover.jpg"
        if not video_path.is_file():
            raise FileNotFoundError(f"missing video: {video_path}")
        if not cover_path.is_file():
            raise FileNotFoundError(f"missing cover: {cover_path}")

        video_bytes = video_path.stat().st_size
        if video_bytes > _LARK_FILE_LIMIT_BYTES:
            raise ValueError(
                f"video too large: {video_bytes // 1024 // 1024}MB > "
                f"{_LARK_FILE_LIMIT_BYTES // 1024 // 1024}MB Lark limit"
            )

        target_flag = "--user-id" if chat_type == "direct" else "--chat-id"
        # lark-cli 1.0.23+ sandbox: --video / --video-cover 必须是当前 cwd 内的相对路径，
        # 绝对路径会被拒（"--file must be a relative path within the current directory"）。
        # 把 cwd 设到 output/，传 basename。
        cmd = [
            "lark-cli", "im", "+messages-send",
            "--as", "bot",
            target_flag, chat_native_id,
            "--video", video_path.name,
            "--video-cover", cover_path.name,
        ]
        log.info("lark-cli send video to %s=%s (cwd=%s)", target_flag, chat_native_id, video_path.parent)
        proc = subprocess.run(cmd, capture_output=True, text=True, cwd=str(video_path.parent))
        if proc.returncode != 0:
            raise RuntimeError(
                f"lark-cli returncode={proc.returncode}, "
                f"stdout={proc.stdout[:500]}, stderr={proc.stderr[:500]}"
            )

        # lark-cli stdout 含上传进度提示（"uploading video: ..."）后跟 JSON。
        # 跳过非 JSON 前缀，从首个 '{' 开始解析。
        message_id = ""
        json_start = proc.stdout.find("{")
        if json_start >= 0:
            try:
                payload = json.loads(proc.stdout[json_start:])
                message_id = payload.get("data", {}).get("message_id", "")
            except json.JSONDecodeError:
                pass

        out_path = ws / "output" / "lark_send.json"
        out_path.write_text(
            json.dumps({
                "status": "done",
                "chat_type": chat_type,
                "chat_id": chat_native_id,
                "message_id": message_id,
            }, ensure_ascii=False),
            encoding="utf-8",
        )
        log.info("done → message_id=%s", message_id)
        return {"status": "done", "path": "output/lark_send.json", "message_id": message_id}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--chat-type", required=True, choices=sorted(_VALID_CHAT_TYPES))
    ap.add_argument("--chat-native-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id, args.chat_type, args.chat_native_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
