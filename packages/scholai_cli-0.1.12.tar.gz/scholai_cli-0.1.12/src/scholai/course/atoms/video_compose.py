"""video_compose atom: SSD + images + audio → output/video.mp4 + cover.jpg.

moviepy 2.x 拼段; ffmpeg 烧 SRT 字幕。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys

import numpy as np
from PIL import Image
from moviepy import ImageClip, AudioFileClip, concatenate_videoclips

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.course.schemas.ssd import SSD


_FPS = 25
_CRF = "23"
_AUDIO_BITRATE = "128k"
_SUBTITLE_LINE_MAX = 15  # 每条字幕 ≤15 字
_VIDEO_W = 1280
_VIDEO_H = 720
_FONT_STYLE = (
    "FontName=PingFang SC,Fontsize=22,"
    "PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,"
    "Outline=2,Shadow=0,Alignment=2,MarginV=8"
)


def _split_narration(text: str, max_chars: int = _SUBTITLE_LINE_MAX) -> list[str]:
    """两级切分：句末标点 → 逗号/顿号/分号/破折号，去除末尾标点。"""
    # 一级：按句末标点切
    parts = re.split(r"(?<=[。！？…])", text)
    result: list[str] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if len(part) <= max_chars:
            result.append(re.sub(r"[。！？…，、；]+$", "", part))
        else:
            # 二级：按逗号/顿号/分号/破折号切
            sub_parts = re.split(r"(?<=[，、；])|——", part)
            for sp in sub_parts:
                sp = re.sub(r"[。！？…，、；]+$", "", sp.strip())
                if sp:
                    result.append(sp)
    return result or [text]


def _load_frame(img_path: str) -> np.ndarray:
    """加载图片，缩放并填充黑边至 1280×720，返回 numpy array。"""
    img = Image.open(img_path).convert("RGB")
    img.thumbnail((_VIDEO_W, _VIDEO_H), Image.LANCZOS)
    bg = Image.new("RGB", (_VIDEO_W, _VIDEO_H), (0, 0, 0))
    bg.paste(img, ((_VIDEO_W - img.width) // 2, (_VIDEO_H - img.height) // 2))
    return np.array(bg)


def _build_srt(ssd: SSD, durations: dict[str, float]) -> str:
    """SSD + durations → SRT 字符串。"""
    lines: list[str] = []
    cursor = 0.0
    idx = 1
    for seg in ssd.segments:
        tag = f"SEG-{seg.seq:02d}"
        seg_dur = durations.get(tag, seg.est_seconds)
        chunks = _split_narration(seg.narration)
        total_chars = sum(len(c) for c in chunks) or 1
        for chunk in chunks:
            sub_dur = max((len(chunk) / total_chars) * seg_dur, 0.5)
            start = cursor
            end = cursor + sub_dur
            lines.append(str(idx))
            lines.append(f"{_fmt_t(start)} --> {_fmt_t(end)}")
            lines.append(chunk)
            lines.append("")
            cursor = end
            idx += 1
    return "\n".join(lines)


def _fmt_t(t: float) -> str:
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int((t - int(t)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "video_compose")
    try:
        ws = workspace_path(run_id)
        ssd_path = ws / "intermediate" / "SSD.json"
        img_dir = ws / "intermediate" / "images"
        audio_dir = ws / "intermediate" / "audio"
        out_dir = ws / "output"
        out_dir.mkdir(parents=True, exist_ok=True)

        ssd = SSD.model_validate_json(ssd_path.read_text(encoding="utf-8"))
        durations = json.loads((audio_dir / "durations.json").read_text(encoding="utf-8"))
        log.info("composing %d segments", len(ssd.segments))

        clips = []
        for seg in ssd.segments:
            tag = f"SEG-{seg.seq:02d}"
            img_path = img_dir / f"{tag}.jpg"
            audio_path = audio_dir / f"{tag}.mp3"
            if not img_path.is_file():
                raise FileNotFoundError(f"missing image for {tag}: {img_path}")
            if not audio_path.is_file():
                raise FileNotFoundError(f"missing audio for {tag}: {audio_path}")
            audio_clip = AudioFileClip(str(audio_path))
            frame = _load_frame(str(img_path))
            clip = ImageClip(frame).with_duration(audio_clip.duration).with_audio(audio_clip)
            clips.append(clip)

        final = concatenate_videoclips(clips, method="compose")
        tmp_path = ws / "intermediate" / "video_no_subs.mp4"
        final.write_videofile(
            str(tmp_path), fps=_FPS, codec="libx264", audio_codec="aac",
            ffmpeg_params=["-crf", _CRF, "-b:a", _AUDIO_BITRATE],
        )
        final.close()
        for c in clips:
            c.close()
        log.info("intermediate written → %s", tmp_path.relative_to(ws))

        # 字幕
        srt_path = ws / "intermediate" / "SSD.srt"
        srt_path.write_text(_build_srt(ssd, durations), encoding="utf-8")
        log.info("srt written → %s", srt_path.relative_to(ws))

        # ffmpeg burn-in
        out_video = out_dir / "video.mp4"
        ffmpeg = os.path.expanduser("~/bin/ffmpeg") if os.path.isfile(os.path.expanduser("~/bin/ffmpeg")) else "ffmpeg"
        # ffmpeg filtergraph 中 ':' 是选项分隔符，路径里的冒号必须转义
        srt_escaped = str(srt_path).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
        cmd = [
            ffmpeg, "-y", "-i", str(tmp_path),
            "-vf", f"subtitles='{srt_escaped}':force_style='{_FONT_STYLE}'",
            "-c:a", "copy",
            str(out_video),
        ]
        log.info("ffmpeg burn subtitles: %s", " ".join(cmd))
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            log.warning("ffmpeg subtitle burn failed (rc=%d), falling back to no-subs copy: %s",
                        proc.returncode, proc.stderr[:200])
            shutil.copyfile(tmp_path, out_video)

        # 封面 = SEG-00.jpg
        cover_src = img_dir / "SEG-00.jpg"
        if not cover_src.is_file():
            raise FileNotFoundError(f"missing cover image: {cover_src}")
        shutil.copyfile(cover_src, out_dir / "cover.jpg")

        log.info("done → output/video.mp4 + output/cover.jpg")
        return {"status": "done", "path": "output/video.mp4"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
