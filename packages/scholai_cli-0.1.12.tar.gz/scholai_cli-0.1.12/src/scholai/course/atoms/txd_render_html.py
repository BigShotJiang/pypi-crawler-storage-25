"""txd_render_html atom: TXD_final.md → article.html (内联 base64 图片)。"""
from __future__ import annotations

import argparse
import base64
import io
import json
import logging
import re
import sys
from pathlib import Path

import markdown as md_lib
from PIL import Image

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger


_IMG_SRC_RE = re.compile(r'<img([^>]*?)src="images/([^"]+)"')

_TARGET_BYTES = 100_000
_COMPRESS_LADDER = [(1024, 75), (800, 70), (640, 65), (480, 60)]


def _encode_jpeg(img: Image.Image, max_w: int, quality: int) -> tuple[bytes, tuple[int, int]]:
    """resize (保持宽高比, 不放大) + JPEG 重编码; 返回 (bytes, (w, h))。"""
    work = img.copy()
    if work.width > max_w:
        work.thumbnail((max_w, max_w * 10), Image.LANCZOS)
    buf = io.BytesIO()
    work.save(buf, format="JPEG", quality=quality, optimize=True)
    return buf.getvalue(), work.size


def _compress_image(data: bytes, filename: str, log: logging.Logger) -> bytes:
    """按阶梯降质重编码 JPEG, 直到 ≤ _TARGET_BYTES; 走完仍超限则用最后一档并 warn。"""
    orig_size = len(data)
    img = Image.open(io.BytesIO(data))
    if img.mode != "RGB":
        img = img.convert("RGB")

    last_out: bytes | None = None
    last_dims: tuple[int, int] | None = None
    last_quality: int | None = None
    for max_w, quality in _COMPRESS_LADDER:
        out, dims = _encode_jpeg(img, max_w, quality)
        last_out, last_dims, last_quality = out, dims, quality
        if len(out) <= _TARGET_BYTES:
            ratio = round(len(out) / orig_size * 100) if orig_size else 0
            log.info(
                "inlined image %s: %d → %d bytes (%d%%, %dx%d, q=%d)",
                filename, orig_size, len(out), ratio, dims[0], dims[1], quality,
            )
            return out

    assert last_out is not None and last_dims is not None and last_quality is not None
    ratio = round(len(last_out) / orig_size * 100) if orig_size else 0
    log.warning(
        "image %s still %d bytes after max compression (%dx%d, q=%d, %d%% of %d)",
        filename, len(last_out), last_dims[0], last_dims[1], last_quality, ratio, orig_size,
    )
    return last_out

_HTML_SHELL = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>scholai course article</title>
<style>
body {{ font-family: sans-serif; max-width: 800px; margin: 2rem auto; padding: 1rem; line-height: 1.6; color: #222; }}
h1, h2, h3 {{ color: #111; }}
img {{ max-width: 100%; height: auto; margin: 1rem 0; border-radius: 4px; }}
</style>
</head>
<body>
{body}
</body>
</html>
"""


def _inline_image(match: re.Match, images_dir: Path, log: logging.Logger) -> str:
    attrs = match.group(1)
    filename = match.group(2)
    img_path = images_dir / filename
    if not img_path.is_file():
        log.warning("image %s not found at %s, keeping original src", filename, img_path)
        return match.group(0)
    compressed = _compress_image(img_path.read_bytes(), filename, log)
    b64 = base64.b64encode(compressed).decode("ascii")
    # b64 = base64.b64encode(img_path.read_bytes()).decode("ascii")
    return f'<img{attrs}src="data:image/jpeg;base64,{b64}"'


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "txd_render_html")
    try:
        ws = workspace_path(run_id)
        src = (ws / "intermediate" / "TXD_final.md").read_text(encoding="utf-8")
        log.info("read TXD_final.md (%d chars)", len(src))
        images_dir = ws / "intermediate" / "images"
        body = md_lib.markdown(src, extensions=["fenced_code", "tables"])
        n_images = len(_IMG_SRC_RE.findall(body))
        body = _IMG_SRC_RE.sub(lambda m: _inline_image(m, images_dir, log), body)
        log.info("inlined %d images as base64", n_images)
        html = _HTML_SHELL.format(body=body)
        out = ws / "output" / "article.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html, encoding="utf-8")
        log.info("done → output/article.html (%d bytes)", len(html.encode()))
        return {"status": "done", "path": "output/article.html"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
