"""ssd_gen atom: VFD.json → intermediate/SSD.json (LLM structured)."""
from __future__ import annotations

import argparse
import json
import sys
import time

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.runtime.llm import llm_structured
from scholai.runtime.prompt_loader import get_prompt
from scholai.course.schemas.ssd import SSD


_RETRIES = 3
_RETRY_SLEEP = 2


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "ssd_gen")
    ws = workspace_path(run_id)
    vfd_path = ws / "intermediate" / "VFD.json"
    out_path = ws / "intermediate" / "SSD.json"

    try:
        vfd_text = vfd_path.read_text(encoding="utf-8")
        log.info("read VFD.json (%d bytes), calling LLM", len(vfd_text))
        prompt = get_prompt("course", "ssd").replace("{vfd}", vfd_text)
        last_err = None
        for attempt in range(_RETRIES):
            try:
                ssd: SSD = llm_structured(prompt, response_schema=SSD, temperature=0.3)
                log.info("LLM returned %d segments, total %.2fs", len(ssd.segments), ssd.total_seconds)
                out_path.write_text(ssd.model_dump_json(indent=2), encoding="utf-8")
                log.info("done → %s", out_path.relative_to(ws))
                return {"status": "done", "path": "intermediate/SSD.json"}
            except Exception as e:
                last_err = e
                log.warning("attempt %d/%d failed: %s", attempt + 1, _RETRIES, e)
                if attempt < _RETRIES - 1:
                    time.sleep(_RETRY_SLEEP)
        raise last_err
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
