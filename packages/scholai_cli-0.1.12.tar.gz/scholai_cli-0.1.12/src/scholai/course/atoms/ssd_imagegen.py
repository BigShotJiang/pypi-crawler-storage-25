"""ssd_imagegen atom: SSD.json → intermediate/images/SEG-NN.jpg + manifest.json."""
from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO

from PIL import Image

from scholai.runtime.llm import llm_image_gen
from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.runtime.prompt_loader import get_prompt
from scholai.course.schemas.ssd import SSD


_MAX_WORKERS = 4
_ASPECT = "16:9"
_RETRIES = 3
_RETRY_SLEEP = 2


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "ssd_imagegen")
    try:
        ws = workspace_path(run_id)
        ssd_path = ws / "intermediate" / "SSD.json"
        img_dir = ws / "intermediate" / "images"
        img_dir.mkdir(parents=True, exist_ok=True)

        ssd = SSD.model_validate_json(ssd_path.read_text(encoding="utf-8"))
        style = get_prompt("course", "ssd_image_style").strip()
        log.info("found %d segments to imagegen", len(ssd.segments))

        def _gen_one(seg) -> dict | None:
            out_path = img_dir / f"SEG-{seg.seq:02d}.jpg"
            if out_path.is_file():
                log.info("SEG-%02d already exists, skipping", seg.seq)
                return {
                    "seq": seg.seq,
                    "prompt": seg.image_prompt,
                    "path": str(out_path.relative_to(ws)),
                    "bytes": out_path.stat().st_size,
                }
            full_prompt = f"{style}\n\n{seg.image_prompt}"
            log.info("generating image SEG-%02d: prompt=%r", seg.seq, seg.image_prompt[:60])
            last_err = None
            for attempt in range(_RETRIES):
                try:
                    data = llm_image_gen(full_prompt, aspect_ratio=_ASPECT)
                    img = Image.open(BytesIO(data)).convert("RGB")
                    if img.width > 1280:
                        img = img.resize((1280, int(img.height * 1280 / img.width)), Image.LANCZOS)
                    img.save(str(out_path), format="JPEG", quality=85, optimize=True)
                    log.info("saved SEG-%02d.jpg (%d bytes)", seg.seq, out_path.stat().st_size)
                    return {
                        "seq": seg.seq,
                        "prompt": seg.image_prompt,
                        "path": str(out_path.relative_to(ws)),
                        "bytes": out_path.stat().st_size,
                    }
                except Exception as e:
                    last_err = e
                    log.warning("SEG-%02d attempt %d/%d failed: %s", seg.seq, attempt + 1, _RETRIES, e)
                    if attempt < _RETRIES - 1:
                        time.sleep(_RETRY_SLEEP)
            log.error("SEG-%02d failed after %d retries: %s", seg.seq, _RETRIES, last_err)
            return None

        with ThreadPoolExecutor(max_workers=_MAX_WORKERS) as pool:
            results = list(pool.map(_gen_one, ssd.segments))
        entries = [r for r in results if r is not None]

        manifest_path = img_dir / "manifest.json"
        manifest_path.write_text(
            json.dumps(entries, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        log.info("done → %s (%d images)", img_dir.relative_to(ws), len(entries))
        if not entries:
            return {"status": "failed", "error": "all image generations failed"}
        return {"status": "done", "path": "intermediate/images"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
