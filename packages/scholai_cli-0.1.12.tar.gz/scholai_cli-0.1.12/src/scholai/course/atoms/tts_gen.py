"""tts_gen atom: SSD.json → intermediate/audio/SEG-NN.mp3 + durations.json (edge-tts CLI)."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.course.schemas.ssd import SSD


_VOICE = "zh-CN-YunxiNeural"
_RETRIES = 3
_BACKOFF = (0.5, 2.0)  # retry 1 等 0.5s,retry 2 等 2.0s


def _mp3_duration(path) -> float:
    """读 mp3 时长(秒)。优先 mutagen，降级 ffprobe。"""
    try:
        from mutagen.mp3 import MP3
        return float(MP3(str(path)).info.length)
    except Exception:
        pass
    ffprobe = os.path.expanduser("~/bin/ffprobe") if os.path.isfile(os.path.expanduser("~/bin/ffprobe")) else "ffprobe"
    result = subprocess.run(
        [ffprobe, "-v", "quiet", "-print_format", "json", "-show_streams", str(path)],
        capture_output=True, text=True,
    )
    try:
        data = json.loads(result.stdout)
        for stream in data.get("streams", []):
            if stream.get("codec_type") == "audio":
                return float(stream.get("duration", 0))
    except Exception:
        pass
    return 0.0


def _tts_one(text: str, out_path) -> None:
    last_err = None
    for attempt in range(_RETRIES):
        cmd = [sys.executable, "-m", "edge_tts", "--voice", _VOICE, "--text", text,
               "--write-media", str(out_path)]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode == 0 and out_path.is_file() and out_path.stat().st_size > 0:
            return
        last_err = f"edge-tts returncode={proc.returncode}, stderr={proc.stderr[:200]}"
        if attempt < _RETRIES - 1:
            time.sleep(_BACKOFF[attempt])
    raise RuntimeError(last_err or "edge-tts failed")


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "tts_gen")
    try:
        ws = workspace_path(run_id)
        ssd_path = ws / "intermediate" / "SSD.json"
        audio_dir = ws / "intermediate" / "audio"
        audio_dir.mkdir(parents=True, exist_ok=True)

        ssd = SSD.model_validate_json(ssd_path.read_text(encoding="utf-8"))
        log.info("synthesizing %d segments via edge-tts (voice=%s)", len(ssd.segments), _VOICE)

        durations_path = audio_dir / "durations.json"
        durations: dict[str, float] = {}
        if durations_path.is_file():
            durations = json.loads(durations_path.read_text(encoding="utf-8"))

        for seg in ssd.segments:
            tag = f"SEG-{seg.seq:02d}"
            out_path = audio_dir / f"{tag}.mp3"
            if out_path.is_file() and out_path.stat().st_size > 0:
                if tag not in durations:
                    durations[tag] = round(_mp3_duration(out_path) or seg.est_seconds, 2)
                log.info("%s already exists, skipping (%.2fs)", tag, durations[tag])
                continue
            log.info("tts %s (chars=%d)", tag, len(seg.narration))
            _tts_one(seg.narration, out_path)
            dur = _mp3_duration(out_path)
            if dur <= 0:
                dur = seg.est_seconds
                log.warning("%s duration undetectable, using est_seconds=%.2fs", tag, dur)
            log.info("%s done (%.2fs)", tag, dur)
            durations[tag] = round(dur, 2)
            # 每段完成立即写入，断点续跑不丢数据
            durations_path.write_text(
                json.dumps(durations, ensure_ascii=False, indent=2), encoding="utf-8"
            )

        durations_path.write_text(
            json.dumps(durations, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        log.info("done → %s (total %.2fs)", audio_dir.relative_to(ws), sum(durations.values()))
        return {"status": "done", "path": "intermediate/audio"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
