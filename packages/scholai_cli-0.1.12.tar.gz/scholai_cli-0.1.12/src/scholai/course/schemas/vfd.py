from __future__ import annotations

from typing import Literal
from pydantic import BaseModel


class VFDFragment(BaseModel):
    ref: str
    content: str
    visual_description: str | None = None


class VFD(BaseModel):
    source_type: Literal["video", "pdf", "url"]
    source_uri: str
    subject: str
    summary: str
    fragments: list[VFDFragment]
