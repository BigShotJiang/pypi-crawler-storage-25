from __future__ import annotations

from pydantic import BaseModel, Field


class SSDSegment(BaseModel):
    seq: int = Field(..., ge=0)
    title: str
    narration: str = Field(..., min_length=10)
    image_prompt: str = Field(..., min_length=1)
    est_seconds: float = Field(..., gt=0)


class SSD(BaseModel):
    subject: str
    segments: list[SSDSegment] = Field(..., min_length=1)
    total_seconds: float = Field(..., gt=0)
