from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field

BloomLevel = Literal["记忆", "理解", "应用", "分析", "评价", "创造"]


class Objective(BaseModel):
    description: str = Field(..., description="以可观察可评估的动词开头")
    bloom_level: BloomLevel
    keywords: list[str] = Field(default_factory=list)


class IOD(BaseModel):
    subject: str
    objectives: list[Objective] = Field(..., min_length=4, max_length=7)
    summary: str = Field(..., max_length=200)
