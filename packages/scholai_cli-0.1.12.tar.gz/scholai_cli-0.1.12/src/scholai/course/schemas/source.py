"""input/source.json schema — normalized pipeline input layer.

Replaces the old input/url.txt path. Handler (or pipeline setup step) writes
this file with the user's actual input; downstream `vfd-*` atoms dispatch on
the discriminated `type` field.
"""
from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field, RootModel


class UrlSource(BaseModel):
    type: Literal["url"]
    value: str


class VideoSource(BaseModel):
    type: Literal["video"]
    file_key: str           # 飞书消息内 video 资源 key（v_xxx）
    message_id: str         # 视频消息 om_xxx，下载 API 必传
    duration_ms: int        # 飞书消息体 duration（毫秒），handler 前置校验已通过 ≤ 30 分钟
    size_bytes: int         # 飞书消息体 size（字节），handler 前置校验已通过 ≤ 500 MB
    filename: str           # 原始文件名，仅作日志/审计用


SourceUnion = Annotated[Union[UrlSource, VideoSource],
                        Field(discriminator="type")]


class SourceSpec(RootModel[SourceUnion]):
    """Discriminated union root. Use SourceSpec.model_validate(dict_or_json)."""
    pass
