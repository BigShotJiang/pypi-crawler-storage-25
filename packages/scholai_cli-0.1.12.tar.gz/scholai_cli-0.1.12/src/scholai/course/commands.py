"""Typer subcommand group: `scholai course <atom> --run-id <id>`.

薄壳,把 CLI 参数映射到 atom 的 run() 纯函数,打印 JSON,按 status 设 exit code。
"""
from __future__ import annotations

import json
import os
import sys

import typer

from scholai.course.atoms.vfd_url import run as vfd_url_run
from scholai.course.atoms.vfd_video_asr import run as vfd_video_asr_run
from scholai.course.atoms.vfd_video_std import run as vfd_video_std_run
from scholai.course.atoms.vfd_video_frames import run as vfd_video_frames_run
from scholai.course.atoms.vfd_video_merge import run as vfd_video_merge_run
from scholai.course.atoms.iod import run as iod_run
from scholai.course.atoms.pd import run as pd_run
from scholai.course.atoms.txd_gen import run as txd_gen_run
from scholai.course.atoms.txd_imagegen import run as txd_imagegen_run
from scholai.course.atoms.txd_render_html import run as txd_render_html_run
from scholai.course.atoms.mmd_gen import run as mmd_gen_run
from scholai.course.atoms.mmd_render_html import run as mmd_render_html_run
from scholai.course.atoms.esd_gen import run as esd_gen_run
from scholai.course.atoms.ssd_gen import run as ssd_gen_run
from scholai.course.atoms.ssd_imagegen import run as ssd_imagegen_run
from scholai.course.atoms.tts_gen import run as tts_gen_run
from scholai.course.atoms.video_compose import run as video_compose_run
from scholai.course.atoms.lark_send import run as lark_send_run
from scholai.common.publish import run as publish_run


course_app = typer.Typer(
    name="course",
    help="Courseware pipeline atoms (vfd/iod/pd/txd/mmd/esd/ssd/tts/video/publish/lark-send).",
    no_args_is_help=True,
)


def _emit(result: dict) -> None:
    typer.echo(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result.get("status") == "done" else 1)


def _enter_atom(run_id: str, skill: str, atom: str) -> None:
    os.environ["SCHOLAI_RUN_ID"] = run_id
    os.environ["SCHOLAI_SKILL"] = skill
    os.environ["SCHOLAI_ATOM"] = atom


@course_app.command("vfd-url")
def cmd_vfd_url(run_id: str = typer.Option(..., "--run-id", help="Run identifier")):
    """Extract VFD.json from input/source.json (type=url)."""
    _enter_atom(run_id, "article", "vfd_url")
    _emit(vfd_url_run(run_id))


@course_app.command("vfd-video-asr")
def cmd_vfd_video_asr(run_id: str = typer.Option(..., "--run-id")):
    """飞书视频下载 + ffmpeg 抽音 + 火山 ASR 2.0 → intermediate/asr.json + transcript.srt。"""
    _enter_atom(run_id, "video_input", "vfd_video_asr")
    _emit(vfd_video_asr_run(run_id))


@course_app.command("vfd-video-std")
def cmd_vfd_video_std(run_id: str = typer.Option(..., "--run-id")):
    """ASR utterances → LLM 分段 → intermediate/std.md。"""
    _enter_atom(run_id, "video_input", "vfd_video_std")
    _emit(vfd_video_std_run(run_id))


@course_app.command("vfd-video-frames")
def cmd_vfd_video_frames(run_id: str = typer.Option(..., "--run-id")):
    """每段视频上传火山方舟 → Doubao 多模态画面分析 → intermediate/frames_cache.json。"""
    _enter_atom(run_id, "video_input", "vfd_video_frames")
    _emit(vfd_video_frames_run(run_id))


@course_app.command("vfd-video-merge")
def cmd_vfd_video_merge(run_id: str = typer.Option(..., "--run-id")):
    """std + frames → intermediate/VFD.json。"""
    _enter_atom(run_id, "video_input", "vfd_video_merge")
    _emit(vfd_video_merge_run(run_id))


@course_app.command("iod")
def cmd_iod(run_id: str = typer.Option(..., "--run-id")):
    """Generate IOD.json from VFD.json (Gemini structured output)."""
    _enter_atom(run_id, "article", "iod")
    _emit(iod_run(run_id))


@course_app.command("pd")
def cmd_pd(run_id: str = typer.Option(..., "--run-id")):
    """Generate PD.md (teacher-facing design) from VFD + IOD."""
    _enter_atom(run_id, "article", "pd")
    _emit(pd_run(run_id))


@course_app.command("txd-gen")
def cmd_txd_gen(run_id: str = typer.Option(..., "--run-id")):
    """Generate TXD.md with image-slot placeholders."""
    _enter_atom(run_id, "article", "txd_gen")
    _emit(txd_gen_run(run_id))


@course_app.command("txd-imagegen")
def cmd_txd_imagegen(run_id: str = typer.Option(..., "--run-id")):
    """Fill image slots in TXD.md -> TXD_final.md + intermediate/images/*.jpg."""
    _enter_atom(run_id, "article", "txd_imagegen")
    _emit(txd_imagegen_run(run_id))


@course_app.command("txd-render-html")
def cmd_txd_render_html(run_id: str = typer.Option(..., "--run-id")):
    """Render TXD_final.md -> output/article.html with inline base64 images."""
    _enter_atom(run_id, "article", "txd_render_html")
    _emit(txd_render_html_run(run_id))


@course_app.command("mmd-gen")
def cmd_mmd_gen(run_id: str = typer.Option(..., "--run-id")):
    """Generate output/mindmap.md from IOD.json (LLM)."""
    _enter_atom(run_id, "mindmap", "mmd_gen")
    _emit(mmd_gen_run(run_id))


@course_app.command("mmd-render-html")
def cmd_mmd_render_html(run_id: str = typer.Option(..., "--run-id")):
    """Render output/mindmap.md → output/mindmap.html (markmap autoloader template)."""
    _enter_atom(run_id, "mindmap", "mmd_render_html")
    _emit(mmd_render_html_run(run_id))


@course_app.command("esd-gen")
def cmd_esd_gen(run_id: str = typer.Option(..., "--run-id")):
    """Generate output/exercise.md from IOD.json (LLM)."""
    _enter_atom(run_id, "exercise", "esd_gen")
    _emit(esd_gen_run(run_id))


@course_app.command("ssd-gen")
def cmd_ssd_gen(run_id: str = typer.Option(..., "--run-id")):
    """Generate SSD.json from VFD.json (LLM structured)."""
    _enter_atom(run_id, "video", "ssd_gen")
    _emit(ssd_gen_run(run_id))


@course_app.command("ssd-imagegen")
def cmd_ssd_imagegen(run_id: str = typer.Option(..., "--run-id")):
    """Generate intermediate/images/SEG-NN.jpg per SSD segment."""
    _enter_atom(run_id, "video", "ssd_imagegen")
    _emit(ssd_imagegen_run(run_id))


@course_app.command("tts-gen")
def cmd_tts_gen(run_id: str = typer.Option(..., "--run-id")):
    """Synthesize SEG-NN.mp3 + durations.json via edge-tts."""
    _enter_atom(run_id, "video", "tts_gen")
    _emit(tts_gen_run(run_id))


@course_app.command("video-compose")
def cmd_video_compose(run_id: str = typer.Option(..., "--run-id")):
    """Compose output/video.mp4 + cover.jpg (moviepy + ffmpeg subtitle burn)."""
    _enter_atom(run_id, "video", "video_compose")
    _emit(video_compose_run(run_id))


@course_app.command("lark-send")
def cmd_lark_send(
    run_id: str = typer.Option(..., "--run-id"),
    chat_type: str = typer.Option(..., "--chat-type", help="direct | group"),
    chat_native_id: str = typer.Option(..., "--chat-native-id",
                                       help="ou_xxx (direct) | oc_xxx (group)"),
):
    """Push output/video.mp4 to IM via lark-cli."""
    _enter_atom(run_id, "video", "lark_send")
    _emit(lark_send_run(run_id, chat_type, chat_native_id))


@course_app.command("publish")
def cmd_publish(
    run_id: str = typer.Option(..., "--run-id"),
    kind: str = typer.Option(..., "--kind", help="article (only kind in MVP)"),
):
    """POST workspace artifact to scholai backend by kind."""
    _emit(publish_run(run_id, kind))
