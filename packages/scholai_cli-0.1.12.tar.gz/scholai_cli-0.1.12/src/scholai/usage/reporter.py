"""Render usage events as plain-text tables (no rich/tabulate)."""
from __future__ import annotations

from scholai.runtime.workspace import RunMeta
from scholai.usage.aggregator import group_by
from scholai.usage.pricing import Pricing


def _fmt_int(v) -> str:
    if v is None:
        return "-"
    return f"{v:,}"


def _fmt_cost(v) -> str:
    if v is None:
        return "-"
    return f"¥{v:.4f}"


def _render_table(rows: list[dict], dim_cols: list[str], pricing: Pricing | None,
                  show_cost: bool, missing_models: set[str]) -> str:
    token_cols = ["calls", "prompt", "cached", "completion"]
    headers = dim_cols + token_cols + (["cost"] if show_cost else [])

    # build display rows
    display: list[list[str]] = []
    for r in rows:
        row_data: list[str] = [str(r.get(d, "")) for d in dim_cols]
        row_data.append(str(r["calls"]))
        row_data.append(_fmt_int(r.get("prompt_tokens")))
        row_data.append(_fmt_int(r.get("cached_tokens")))
        row_data.append(_fmt_int(r.get("completion_tokens")))
        if show_cost:
            cost_val = r.get("cost")
            row_data.append(_fmt_cost(cost_val))
            if cost_val is None:
                for m_key in ["model"] + dim_cols:
                    if m_key in r:
                        missing_models.add(r[m_key])
        display.append(row_data)

    # compute col widths
    widths = [len(h) for h in headers]
    for row_data in display:
        for i, cell in enumerate(row_data):
            widths[i] = max(widths[i], len(cell))

    def fmt_row(cells: list[str]) -> str:
        parts = []
        for i, cell in enumerate(cells):
            if i < len(dim_cols) or i == len(dim_cols):  # dims + calls left-aligned
                parts.append(cell.ljust(widths[i]))
            else:
                parts.append(cell.rjust(widths[i]))
        return "  ".join(parts)

    lines = [fmt_row(headers)]
    for row_data in display:
        lines.append(fmt_row(row_data))
    return "\n".join(lines)


def _build_footer(pricing: Pricing | None, show_cost: bool,
                  missing_models: set[str]) -> str:
    lines: list[str] = []
    if not show_cost:
        lines.append(
            "未配置价格 → 跳过金额计算。"
            "提示：在 ~/.openclaw/usage/pricing.toml 添加单价。"
        )
    elif missing_models:
        cleaned = {m for m in missing_models if m}
        if cleaned:
            lines.append(f"以下 model 未配价格 → {', '.join(sorted(cleaned))}")
    return "\n".join(lines)


def render_period(label: str, events: list[dict], pricing: Pricing | None) -> str:
    if not events:
        return f"{label}\n\n当天无用量"

    show_cost = pricing is not None
    missing_models: set[str] = set()

    by_skill_atom = group_by(events, ["skill", "atom"], pricing)
    by_model = group_by(events, ["model"], pricing)

    total_calls = sum(r["calls"] for r in by_skill_atom)
    total_cost: float | None = None
    if show_cost:
        costs = [r["cost"] for r in by_skill_atom if r["cost"] is not None]
        total_cost = sum(costs) if costs else 0.0

    lines = [label, ""]
    lines.append("By skill / atom:")
    lines.append(_render_table(by_skill_atom, ["skill", "atom"], pricing, show_cost, missing_models))
    lines.append("")
    lines.append("By model:")
    lines.append(_render_table(by_model, ["model"], pricing, show_cost, missing_models))
    lines.append("")

    if show_cost and total_cost is not None:
        lines.append(f"Total: ¥{total_cost:.4f} across {total_calls} calls.")
    else:
        lines.append(f"Total: {total_calls} calls.")

    footer = _build_footer(pricing, show_cost, missing_models)
    if footer:
        lines.append("")
        lines.append(footer)

    return "\n".join(lines)


def render_run(run_id: str, meta: RunMeta, events: list[dict],
               pricing: Pricing | None) -> str:
    if not events:
        return f"Run {run_id} 无用量记录"

    show_cost = pricing is not None
    missing_models: set[str] = set()

    rows = group_by(events, ["atom", "model"], pricing)

    total_cost: float | None = None
    if show_cost:
        costs = [r["cost"] for r in rows if r["cost"] is not None]
        total_cost = sum(costs) if costs else 0.0

    header_line = f"Run {run_id} ({meta.skill}, started {meta.created_at})"
    lines = [header_line, ""]
    lines.append(_render_table(rows, ["atom", "model"], pricing, show_cost, missing_models))
    lines.append("")

    if show_cost and total_cost is not None:
        lines.append(f"Total: ¥{total_cost:.4f}")
    else:
        lines.append(f"Total: {sum(r['calls'] for r in rows)} calls.")

    footer = _build_footer(pricing, show_cost, missing_models)
    if footer:
        lines.append("")
        lines.append(footer)

    return "\n".join(lines)
