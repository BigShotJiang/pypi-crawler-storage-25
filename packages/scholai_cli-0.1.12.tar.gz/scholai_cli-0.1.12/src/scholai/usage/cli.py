"""scholai usage subcommand group."""
from __future__ import annotations

from datetime import date, timedelta

import typer

from scholai.usage.aggregator import read_events_for_dates, read_events_for_run
from scholai.usage.pricing import load_pricing
from scholai.usage.reporter import render_period, render_run

usage_app = typer.Typer(name="usage", help="Token usage queries.", no_args_is_help=True)


@usage_app.command("today")
def cmd_today(skill: str | None = typer.Option(None, "--skill", help="Filter by skill")):
    """Show today's token usage."""
    today = date.today()
    events = read_events_for_dates([today])
    if skill:
        events = [e for e in events if e.get("skill") == skill]
    pricing = load_pricing()
    typer.echo(render_period(f"{today.isoformat()} 用量", events, pricing))


@usage_app.command("yesterday")
def cmd_yesterday(skill: str | None = typer.Option(None, "--skill", help="Filter by skill")):
    """Show yesterday's token usage."""
    yesterday = date.today() - timedelta(days=1)
    events = read_events_for_dates([yesterday])
    if skill:
        events = [e for e in events if e.get("skill") == skill]
    pricing = load_pricing()
    typer.echo(render_period(f"{yesterday.isoformat()} 用量", events, pricing))


@usage_app.command("range")
def cmd_range(
    from_: str = typer.Option(..., "--from", help="Start date YYYY-MM-DD"),
    to: str = typer.Option(..., "--to", help="End date YYYY-MM-DD"),
    skill: str | None = typer.Option(None, "--skill", help="Filter by skill"),
):
    """Show token usage for a date range (inclusive)."""
    start = date.fromisoformat(from_)
    end = date.fromisoformat(to)
    dates = []
    cur = start
    while cur <= end:
        dates.append(cur)
        cur += timedelta(days=1)
    events = read_events_for_dates(dates)
    if skill:
        events = [e for e in events if e.get("skill") == skill]
    pricing = load_pricing()
    label = f"{from_} → {to} 用量"
    typer.echo(render_period(label, events, pricing))


@usage_app.command("run")
def cmd_run(run_id: str = typer.Argument(..., help="Run ID")):
    """Show token usage for a specific run."""
    try:
        meta, events = read_events_for_run(run_id)
    except FileNotFoundError:
        typer.echo(f"Run {run_id} 无用量记录")
        raise typer.Exit(1)
    pricing = load_pricing()
    typer.echo(render_run(run_id, meta, events, pricing))
