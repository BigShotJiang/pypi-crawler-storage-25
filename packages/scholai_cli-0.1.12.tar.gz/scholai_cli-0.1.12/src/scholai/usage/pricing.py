"""Load pricing.toml and compute per-event cost."""
from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path


@dataclass
class ChatRate:
    prompt: float
    prompt_cached: float | None
    completion: float


@dataclass
class ImageRate:
    per_call: float


@dataclass
class Pricing:
    chat: dict[str, ChatRate]
    image: dict[str, ImageRate]


def _pricing_path() -> Path:
    import os
    home = Path(
        os.environ.get("OPENCLAW_STATE_DIR")
        or os.environ.get("OPENCLAW_HOME")
        or (Path.home() / ".openclaw")
    )
    return home / "scholai-usage" / "pricing.toml"


def load_pricing() -> Pricing | None:
    path = _pricing_path()
    if not path.exists():
        return None
    with open(path, "rb") as f:
        raw = tomllib.load(f)

    chat: dict[str, ChatRate] = {}
    for model, cfg in raw.get("chat", {}).items():
        chat[model] = ChatRate(
            prompt=float(cfg["prompt"]),
            prompt_cached=float(cfg["prompt_cached"]) if "prompt_cached" in cfg else None,
            completion=float(cfg["completion"]),
        )

    image: dict[str, ImageRate] = {}
    for model, cfg in raw.get("image", {}).items():
        image[model] = ImageRate(per_call=float(cfg["per_call"]))

    return Pricing(chat=chat, image=image)


def compute_cost(event: dict, pricing: Pricing | None) -> float | None:
    if pricing is None:
        return None
    model = event.get("model", "")
    kind = event.get("kind", "")

    if kind == "chat":
        rate = pricing.chat.get(model)
        if rate is None:
            return None
        prompt = event.get("prompt_tokens", 0) or 0
        cached = event.get("cached_tokens", 0) or 0
        completion = event.get("completion_tokens", 0) or 0
        cached_rate = rate.prompt_cached if rate.prompt_cached is not None else rate.prompt
        cost = (
            (prompt - cached) * rate.prompt
            + cached * cached_rate
            + completion * rate.completion
        ) / 1_000_000
        return cost

    if kind == "image":
        rate = pricing.image.get(model)
        if rate is None:
            return None
        count = event.get("count", 1) or 1
        return count * rate.per_call

    return None
