"""Read JSONL event files and aggregate by dimensions."""
from __future__ import annotations

import json
import os
from datetime import date
from pathlib import Path

from scholai.runtime.workspace import RunMeta, WorkspaceState
from scholai.usage.pricing import Pricing, compute_cost


def _openclaw_home() -> Path:
    return Path(
        os.environ.get("OPENCLAW_STATE_DIR")
        or os.environ.get("OPENCLAW_HOME")
        or (Path.home() / ".openclaw")
    )


def _read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    events = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return events


def read_events_for_dates(dates: list[date]) -> list[dict]:
    home = _openclaw_home()
    events: list[dict] = []
    for d in dates:
        path = home / "scholai-usage" / f"{d.isoformat()}.jsonl"
        events.extend(_read_jsonl(path))
    return events


def _find_run_dir(run_id: str) -> Path | None:
    """扫描所有 agents 目录，找到包含 run_id 的 run 目录（不要求有 workspace.json）。"""
    agents_root = _openclaw_home() / "agents"
    if not agents_root.exists():
        return None
    for bot_dir in agents_root.iterdir():
        candidate = bot_dir / "workspace" / "runs" / run_id
        if candidate.is_dir():
            return candidate
    return None


def _meta_from_events(run_id: str, events: list[dict]) -> RunMeta:
    """从事件里推断 RunMeta（workspace.json 不存在时的回退）。"""
    first = events[0] if events else {}
    return RunMeta(
        run_id=run_id,
        bot_id=first.get("bot_id", "unknown"),
        skill=first.get("skill", "unknown"),
        chat_id="",
        created_at=first.get("ts", ""),
        last_updated=first.get("ts", ""),
    )


def read_events_for_run(run_id: str) -> tuple[RunMeta, list[dict]]:
    run_dir = _find_run_dir(run_id)
    if run_dir is None:
        raise FileNotFoundError(f"run directory not found for run_id={run_id!r}")
    events = _read_jsonl(run_dir / "logs" / "usage.jsonl")
    ws_file = run_dir / "workspace.json"
    if ws_file.exists():
        state = WorkspaceState.model_validate_json(ws_file.read_text(encoding="utf-8"))
        meta = state.meta
    else:
        meta = _meta_from_events(run_id, events)
    return meta, events


def group_by(events: list[dict], dims: list[str], pricing: Pricing | None) -> list[dict]:
    buckets: dict[tuple, dict] = {}
    for event in events:
        key = tuple(event.get(d, "") for d in dims)
        if key not in buckets:
            buckets[key] = {
                **{d: event.get(d, "") for d in dims},
                "calls": 0,
                "prompt_tokens": 0,
                "cached_tokens": 0,
                "completion_tokens": 0,
                "cost": 0.0,
                "_cost_unknown": False,
                "_is_image": False,
            }
        b = buckets[key]
        b["calls"] += 1
        kind = event.get("kind", "")
        if kind == "image":
            b["_is_image"] = True
        else:
            b["prompt_tokens"] += event.get("prompt_tokens", 0) or 0
            b["cached_tokens"] += event.get("cached_tokens", 0) or 0
            b["completion_tokens"] += event.get("completion_tokens", 0) or 0

        c = compute_cost(event, pricing)
        if c is None:
            b["_cost_unknown"] = True
        else:
            b["cost"] = (b["cost"] or 0.0) + c

    result = []
    for b in buckets.values():
        row = {d: b[d] for d in dims}
        row["calls"] = b["calls"]
        if b["_is_image"] and b["prompt_tokens"] == 0:
            row["prompt_tokens"] = None
            row["cached_tokens"] = None
            row["completion_tokens"] = None
        else:
            row["prompt_tokens"] = b["prompt_tokens"]
            row["cached_tokens"] = b["cached_tokens"]
            row["completion_tokens"] = b["completion_tokens"]
        row["cost"] = None if b["_cost_unknown"] else b["cost"]
        result.append(row)
    return result
