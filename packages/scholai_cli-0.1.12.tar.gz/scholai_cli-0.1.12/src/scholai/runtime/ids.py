from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass(frozen=True)
class RunIdParts:
    yymmdd: str
    chat_short: str
    skill: str
    seq: str


def _chat_short(chat_id: str) -> str:
    return hashlib.sha256(chat_id.encode("utf-8")).hexdigest()[:8]


def _openclaw_home() -> Path:
    return Path(os.environ.get("OPENCLAW_HOME", Path.home() / ".openclaw"))


def _workspace_runs_root(bot_id: str | None = None) -> Path:
    bot_id = bot_id or os.environ.get("OPENCLAW_AGENT_ID", "default")
    return _openclaw_home() / "agents" / bot_id / "workspace" / "runs"


def generate_run_id(chat_id: str, skill: str, when: datetime | None = None,
                    bot_id: str | None = None) -> str:
    """格式: yymmdd-<chat_short>-<skill>-<seq>"""
    when = when or datetime.now(timezone.utc)
    yymmdd = when.strftime("%y%m%d")
    chat = _chat_short(chat_id)
    prefix = f"{yymmdd}-{chat}-{skill}-"

    runs_root = _workspace_runs_root(bot_id)
    existing = []
    if runs_root.exists():
        existing = [p.name for p in runs_root.iterdir()
                    if p.is_dir() and p.name.startswith(prefix)]
    seq_num = len(existing) + 1
    seq = f"{seq_num:02d}"
    return f"{prefix}{seq}"


def parse_run_id(run_id: str) -> RunIdParts:
    parts = run_id.split("-")
    if len(parts) != 4:
        raise ValueError(f"invalid run_id format: {run_id!r}")
    yymmdd, chat_short, skill, seq = parts
    if len(yymmdd) != 6 or not yymmdd.isdigit():
        raise ValueError(f"invalid yymmdd: {yymmdd!r}")
    if len(chat_short) != 8:
        raise ValueError(f"invalid chat_short: {chat_short!r}")
    if not seq.isdigit():
        raise ValueError(f"invalid seq: {seq!r}")
    return RunIdParts(yymmdd=yymmdd, chat_short=chat_short, skill=skill, seq=seq)


def main() -> None:
    import argparse
    import json

    ap = argparse.ArgumentParser(prog="python -m scholai.runtime.ids")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p_gen = sub.add_parser("generate")
    p_gen.add_argument("--chat-id", required=True)
    p_gen.add_argument("--skill", required=True)

    args = ap.parse_args()
    if args.cmd == "generate":
        run_id = generate_run_id(args.chat_id, args.skill)
        print(json.dumps({"status": "done", "run_id": run_id}, ensure_ascii=False))


if __name__ == "__main__":
    main()
