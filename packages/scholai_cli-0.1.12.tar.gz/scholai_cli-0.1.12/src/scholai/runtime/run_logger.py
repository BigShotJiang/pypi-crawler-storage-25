"""Per-run file logger. Writes to <run_id>/logs/run.log (UTC, append)."""
from __future__ import annotations

import logging
import time
from pathlib import Path

from scholai.runtime.workspace import workspace_path


class _UTCFormatter(logging.Formatter):
    converter = time.gmtime


def get_run_logger(run_id: str, name: str) -> logging.Logger:
    """Return a logger that appends to <run_id>/logs/run.log.

    Each atom process is short-lived, so handlers never accumulate across
    calls in production. The guard is only relevant in tests.
    """
    logger = logging.getLogger(f"scholai.run.{run_id}.{name}")
    if logger.handlers:
        return logger

    log_path = workspace_path(run_id) / "logs" / "run.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    handler = logging.FileHandler(log_path, encoding="utf-8")
    handler.setFormatter(_UTCFormatter(
        fmt="%(asctime)s [%(name_short)s] %(levelname)s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%SZ",
    ))
    handler.addFilter(_NameShortFilter(name))

    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    return logger


class _NameShortFilter(logging.Filter):
    """Inject %(name_short)s so the formatter doesn't embed the full dotted name."""
    def __init__(self, short: str) -> None:
        super().__init__()
        self._short = short

    def filter(self, record: logging.LogRecord) -> bool:
        record.name_short = self._short  # type: ignore[attr-defined]
        return True
