"""workspace state machine: Pydantic models + path + I/O."""
from __future__ import annotations

import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
from pydantic import BaseModel, Field

CardItemStatus = Literal["pending", "in_progress", "done", "failed"]


class CardItemState(BaseModel):
    status: CardItemStatus = "pending"
    error: str | None = None
    started_at: str | None = None
    completed_at: str | None = None
    failed_at: str | None = None
    subagent_run_id: str | None = None


class RunMeta(BaseModel):
    run_id: str
    bot_id: str
    skill: str
    chat_id: str
    card_id: str | None = None
    current_card_item: str | None = None
    created_at: str
    last_updated: str


class WorkspaceState(BaseModel):
    meta: RunMeta
    card_items: dict[str, CardItemState] = Field(default_factory=dict)


def _openclaw_home() -> Path:
    # OPENCLAW_STATE_DIR is injected by openclaw into all child processes and
    # shifts when using --dev mode (~/.openclaw-dev). Prefer it over OPENCLAW_HOME
    # so Python atoms and the lobster shell steps always share the same root.
    return Path(
        os.environ.get("OPENCLAW_STATE_DIR")
        or os.environ.get("OPENCLAW_HOME")
        or (Path.home() / ".openclaw")
    )


def workspace_root(bot_id: str | None = None) -> Path:
    """~/.openclaw/agents/<bot_id>/workspace/runs/"""
    bot_id = bot_id or os.environ.get("OPENCLAW_AGENT_ID", "default")
    return _openclaw_home() / "agents" / bot_id / "workspace" / "runs"


def workspace_path(run_id: str, bot_id: str | None = None) -> Path:
    return workspace_root(bot_id) / run_id


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _atomic_write_json(path: Path, state: "WorkspaceState") -> None:
    """tempfile + os.replace 保证原子写。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".ws-", suffix=".json")
    try:
        os.close(fd)
        Path(tmp).write_text(state.model_dump_json(indent=2), encoding="utf-8")
        os.replace(tmp, path)
    except Exception:
        Path(tmp).unlink(missing_ok=True)
        raise


def ensure_run(run_id: str, bot_id: str, skill: str, chat_id: str,
               card_item_ids: list[str],
               card_id: str | None = None) -> Path:
    """建 run_id 目录 + 子目录 + 初始 workspace.json; 返回 workspace_path。"""
    p = workspace_path(run_id, bot_id)
    for sub in ("input", "intermediate", "output"):
        (p / sub).mkdir(parents=True, exist_ok=True)

    now = _iso_now()
    state = WorkspaceState(
        meta=RunMeta(
            run_id=run_id, bot_id=bot_id, skill=skill, chat_id=chat_id,
            card_id=card_id, current_card_item=None,
            created_at=now, last_updated=now,
        ),
        card_items={item: CardItemState() for item in card_item_ids},
    )
    _atomic_write_json(p / "workspace.json", state)
    return p


def read_state(run_id: str, bot_id: str | None = None) -> WorkspaceState:
    p = workspace_path(run_id, bot_id) / "workspace.json"
    if not p.exists():
        raise FileNotFoundError(f"workspace.json not found for run_id={run_id!r}")
    return WorkspaceState.model_validate_json(p.read_text(encoding="utf-8"))


def update_meta(run_id: str, bot_id: str | None = None, **fields) -> WorkspaceState:
    state = read_state(run_id, bot_id)
    meta_dict = state.meta.model_dump()
    for k, v in fields.items():
        meta_dict[k] = v
    meta_dict["last_updated"] = _iso_now()
    state = WorkspaceState(meta=RunMeta(**meta_dict), card_items=state.card_items)
    _atomic_write_json(workspace_path(run_id, bot_id) / "workspace.json", state)
    return state


def update_card_item(run_id: str, item: str, status: CardItemStatus,
                     error: str | None = None,
                     subagent_run_id: str | None = None,
                     bot_id: str | None = None) -> WorkspaceState:
    state = read_state(run_id, bot_id)
    if item not in state.card_items:
        raise KeyError(f"card item {item!r} not declared in workspace.json")
    now = _iso_now()
    ci = state.card_items[item]
    ci_dict = ci.model_dump()
    ci_dict["status"] = status
    if status == "in_progress" and ci_dict.get("started_at") is None:
        ci_dict["started_at"] = now
    if status == "done":
        ci_dict["completed_at"] = now
    if status == "failed":
        ci_dict["failed_at"] = now
        if error is not None:
            ci_dict["error"] = error
    if subagent_run_id is not None:
        ci_dict["subagent_run_id"] = subagent_run_id

    state.card_items[item] = CardItemState(**ci_dict)
    state.meta = RunMeta(**{**state.meta.model_dump(), "last_updated": now})
    _atomic_write_json(workspace_path(run_id, bot_id) / "workspace.json", state)
    return state


def _env_bot_id() -> str:
    return os.environ.get("OPENCLAW_AGENT_ID", "default")


def _list_runs(chat_id: str, skill: str, status_filter: str) -> list[dict]:
    """扫 workspace_root 下 run_id 目录,按 chat_id+skill 过滤,读 workspace.json 判未完成。"""
    root = workspace_root()
    if not root.exists():
        return []
    result = []
    for run_dir in sorted(root.iterdir()):
        if not run_dir.is_dir():
            continue
        if not (run_dir / "workspace.json").is_file():
            continue
        try:
            state = read_state(run_dir.name)
        except Exception:
            continue
        if state.meta.chat_id != chat_id or state.meta.skill != skill:
            continue
        unfinished = any(item.status not in ("done", "failed")
                         for item in state.card_items.values())
        if status_filter == "unfinished" and not unfinished:
            continue
        result.append({
            "run_id": run_dir.name,
            "current_card_item": state.meta.current_card_item,
            "unfinished": unfinished,
        })
    return result


def main() -> None:
    import argparse
    import json
    import sys

    ap = argparse.ArgumentParser(prog="python -m scholai.runtime.workspace")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_ensure = sub.add_parser("ensure")
    p_ensure.add_argument("--run-id", required=True)
    p_ensure.add_argument("--skill", required=True)
    p_ensure.add_argument("--chat-id", required=True)
    p_ensure.add_argument("--card-items", required=True,
                          help="逗号分隔 item id 列表")
    p_ensure.add_argument("--card-id", default=None)

    p_update_meta = sub.add_parser("update-meta")
    p_update_meta.add_argument("--run-id", required=True)
    p_update_meta.add_argument("--card-id")
    p_update_meta.add_argument("--current-card-item")

    p_update_item = sub.add_parser("update-card-item")
    p_update_item.add_argument("--run-id", required=True)
    p_update_item.add_argument("--item", required=True)
    p_update_item.add_argument("--status", required=True,
                               choices=["pending", "in_progress", "done", "failed"])
    p_update_item.add_argument("--error", default=None)
    p_update_item.add_argument("--subagent-run-id", default=None)

    p_read = sub.add_parser("read")
    p_read.add_argument("--run-id", required=True)

    p_path = sub.add_parser("path")
    p_path.add_argument("--run-id", required=True)

    p_list = sub.add_parser("list-runs")
    p_list.add_argument("--chat-id", required=True)
    p_list.add_argument("--skill", required=True)
    p_list.add_argument("--status", default="all",
                        choices=["all", "unfinished"])

    args = ap.parse_args()
    try:
        if args.cmd == "ensure":
            items = [i.strip() for i in args.card_items.split(",") if i.strip()]
            ensure_run(args.run_id, bot_id=_env_bot_id(), skill=args.skill,
                       chat_id=args.chat_id, card_item_ids=items,
                       card_id=args.card_id)
            print(json.dumps({"status": "done",
                              "workspace": str(workspace_path(args.run_id))},
                             ensure_ascii=False))
        elif args.cmd == "update-meta":
            fields = {k: v for k, v in
                      [("card_id", args.card_id),
                       ("current_card_item", args.current_card_item)]
                      if v is not None}
            update_meta(args.run_id, **fields)
            print(json.dumps({"status": "done"}, ensure_ascii=False))
        elif args.cmd == "update-card-item":
            update_card_item(args.run_id, args.item, args.status,
                             error=args.error,
                             subagent_run_id=args.subagent_run_id)
            print(json.dumps({"status": "done"}, ensure_ascii=False))
        elif args.cmd == "read":
            state = read_state(args.run_id)
            print(json.dumps({"status": "done",
                              "state": state.model_dump()},
                             ensure_ascii=False))
        elif args.cmd == "path":
            print(json.dumps({"status": "done",
                              "path": str(workspace_path(args.run_id))},
                             ensure_ascii=False))
        elif args.cmd == "list-runs":
            runs = _list_runs(args.chat_id, args.skill, args.status)
            print(json.dumps({"status": "done", "runs": runs},
                             ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"status": "failed",
                          "error": f"{type(e).__name__}: {e}"},
                         ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
