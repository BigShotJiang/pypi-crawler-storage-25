"""OpenAI-compatible LLM client. All calls go through the openai SDK.

Per-role credentials: text and image roles each have independent api_key +
base_url + model envs (LLM_TEXT_* / LLM_IMAGE_*). The dormant llm_vision()
piggybacks on text creds for now (no callers in production); replace with
LLM_VISION_* when rewiring callers.
"""
from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import TypeVar

from openai import OpenAI
from pydantic import BaseModel

from scholai.common.credentials_reader import (
    get_llm_image_api_key,
    get_llm_image_base_url,
    get_llm_image_model,
    get_llm_text_api_key,
    get_llm_text_base_url,
    get_llm_text_model,
    get_llm_vision_model,
)
from scholai.runtime import usage

T = TypeVar("T", bound=BaseModel)


class LLMError(RuntimeError):
    """Wraps openai SDK errors so atom layer only catches LLMError."""
    pass


# ---- text role ----

def _get_text_creds() -> tuple[str, str]:
    api_key = get_llm_text_api_key()
    if not api_key:
        raise LLMError("LLM_TEXT_API_KEY not set; 跑 `npx @scholai/openclaw-scholai-tools install` 或 export LLM_TEXT_API_KEY。")
    base_url = get_llm_text_base_url()
    if not base_url:
        raise LLMError("LLM_TEXT_BASE_URL not set; 跑 `npx @scholai/openclaw-scholai-tools install` 或 export LLM_TEXT_BASE_URL。")
    return api_key, base_url


def _get_text_model(model: str | None) -> str:
    resolved = model or get_llm_text_model()
    if not resolved:
        raise LLMError("LLM_TEXT_MODEL not set; 跑 `npx @scholai/openclaw-scholai-tools install` 或 export LLM_TEXT_MODEL。")
    return resolved


def _make_text_client() -> OpenAI:
    api_key, base_url = _get_text_creds()
    return OpenAI(api_key=api_key, base_url=base_url)


# ---- image role ----

def _get_image_creds() -> tuple[str, str]:
    api_key = get_llm_image_api_key()
    if not api_key:
        raise LLMError("LLM_IMAGE_API_KEY not set; 跑 `npx @scholai/openclaw-scholai-tools install` 或 export LLM_IMAGE_API_KEY。")
    base_url = get_llm_image_base_url()
    if not base_url:
        raise LLMError("LLM_IMAGE_BASE_URL not set; 跑 `npx @scholai/openclaw-scholai-tools install` 或 export LLM_IMAGE_BASE_URL。")
    return api_key, base_url


def _get_image_model() -> str:
    resolved = get_llm_image_model()
    if not resolved:
        raise LLMError("LLM_IMAGE_MODEL not set; 跑 `npx @scholai/openclaw-scholai-tools install` 或 export LLM_IMAGE_MODEL。")
    return resolved


def _make_image_client() -> OpenAI:
    api_key, base_url = _get_image_creds()
    return OpenAI(api_key=api_key, base_url=base_url)


# ---- vision dormant ----

def _get_vision_model(model: str | None) -> str:
    resolved = model or get_llm_vision_model()
    if not resolved:
        raise LLMError("LLM_VISION_MODEL not set; 跑 `npx @scholai/openclaw-scholai-tools install` 或 export LLM_VISION_MODEL。")
    return resolved


# ---- chat / image entry points ----

def _llm_chat(*, messages: list[dict], model: str, temperature: float,
              response_format: dict | None = None):
    """Single SDK call entry point for chat completions — mock this in tests."""
    kwargs: dict = {"model": model, "messages": messages, "temperature": temperature}
    if response_format:
        kwargs["response_format"] = response_format
    resp = _make_text_client().chat.completions.create(**kwargs)
    usage.record_chat(model, resp)
    return resp


def _llm_image_generate(*, prompt: str, model: str, size: str) -> bytes:
    """Image generation entry point — mock this in tests.

    Handles both response formats:
    - b64_json: OpenAI / providers that honour response_format="b64_json"
    - url: GLM CogView and other providers that always return a URL
    """
    resp = _make_image_client().images.generate(
        model=model,
        prompt=prompt,
        n=1,
        size=size,
        response_format="b64_json",  # hint only; some providers ignore and return url
    )
    item = resp.data[0] if resp.data else None
    if not item:
        raise LLMError("image generation: empty response")
    if item.b64_json:
        data = base64.b64decode(item.b64_json)
    elif item.url:
        import urllib.request
        with urllib.request.urlopen(item.url, timeout=30) as r:
            data = r.read()
    else:
        raise LLMError("image generation: no b64_json or url in response")
    usage.record_image(model, size, 1)
    return data


# ---- public API ----

def llm_structured(prompt: str, response_schema: type[T],
                   model: str | None = None,
                   temperature: float = 0.3) -> T:
    """返回 response_schema 实例，使用 json_object 模式约束输出。"""
    schema_str = json.dumps(response_schema.model_json_schema(), ensure_ascii=False, indent=2)
    augmented = (
        f"{prompt}\n\n"
        f"请严格按以下 JSON Schema 输出顶层字段，不要用任何额外键包裹：\n{schema_str}"
    )
    resp = _llm_chat(
        messages=[{"role": "user", "content": augmented}],
        model=_get_text_model(model),
        temperature=temperature,
        response_format={"type": "json_object"},
    )
    return response_schema.model_validate_json(resp.choices[0].message.content)


def llm_text(prompt: str, model: str | None = None,
             temperature: float = 0.5) -> str:
    resp = _llm_chat(
        messages=[{"role": "user", "content": prompt}],
        model=_get_text_model(model),
        temperature=temperature,
    )
    return resp.choices[0].message.content


def llm_vision(prompt: str, images: list[Path],
               model: str | None = None,
               temperature: float = 0.3) -> str:
    """vision dormant: 借用 text 凭据 + LLM_VISION_MODEL；启用 vision 时改回独立 client。"""
    content: list[dict] = [{"type": "text", "text": prompt}]
    for p in images:
        b64 = base64.b64encode(p.read_bytes()).decode()
        content.append({"type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
    resp = _llm_chat(
        messages=[{"role": "user", "content": content}],
        model=_get_vision_model(model),
        temperature=temperature,
    )
    return resp.choices[0].message.content


def llm_image_gen(prompt: str, aspect_ratio: str = "1:1") -> bytes:
    model = _get_image_model()
    if model.startswith("doubao"):
        size = "2k"
    elif model.startswith("cogView"):
        size = "512x512"
    else:
        size = "2k"
    return _llm_image_generate(
        prompt=f"{prompt}\n\n(aspect ratio: {aspect_ratio})",
        model=model,
        size=size,
    )
