"""从打包资源加载 markdown prompt。"""
from __future__ import annotations

from importlib.resources import files


def get_prompt(agent: str, name: str) -> str:
    """
    get_prompt('course', 'iod') → src/scholai/course/prompts/iod.md
    """
    pkg = f"scholai.{agent}.prompts"
    try:
        return files(pkg).joinpath(f"{name}.md").read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError) as e:
        raise FileNotFoundError(
            f"prompt not found: agent={agent!r} name={name!r}"
        ) from e
