"""解析 SubAgent 输出尾部的 STATUS 块(设计 §3.3 + §14 #7)。"""
from __future__ import annotations

import re


_STATUS_RE = re.compile(
    r"---\s*\n"
    r"STATUS:\s*(?P<status>\w+)\s*\n"
    r"(?P<body>.*?)"
    r"\n---",
    re.DOTALL,
)


def _last_status_block(text: str) -> re.Match | None:
    """找最后一个 STATUS 块(兼容 code fence / 尾部赘文)。"""
    matches = list(_STATUS_RE.finditer(text))
    return matches[-1] if matches else None


def parse(text: str) -> dict:
    m = _last_status_block(text)
    if not m:
        return {"status": "malformed", "raw": text}

    status = m.group("status").strip().lower()
    body = m.group("body")

    if status == "done":
        artifacts_line = _extract_line(body, "ARTIFACTS")
        artifacts = [a.strip() for a in (artifacts_line or "").split(",") if a.strip()]
        return {"status": "done", "artifacts": artifacts}

    if status == "failed":
        error = _extract_line(body, "ERROR") or ""
        return {"status": "failed", "error": error.strip()}

    return {"status": "malformed", "raw": text}


def _extract_line(body: str, key: str) -> str | None:
    """从 body 里抓 'KEY: value' 的 value。"""
    for line in body.splitlines():
        line = line.strip()
        if line.upper().startswith(f"{key}:"):
            return line[len(key) + 1:].strip()
    return None


def main() -> None:
    """stdin → STATUS 解析 JSON(MainAgent bash 用)。"""
    import json
    import sys

    text = sys.stdin.read()
    result = parse(text)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
