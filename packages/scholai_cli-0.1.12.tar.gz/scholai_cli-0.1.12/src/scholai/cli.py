"""scholai root Typer CLI.

Only hosts the `course` subcommand group (atom invocations).
setup/login/logout/config were historically here; moved to
@scholai/openclaw-scholai-tools (TS, terminal CLI).
"""
from __future__ import annotations

import typer

from scholai import __version__
from scholai.course.commands import course_app
from scholai.usage.cli import usage_app

app = typer.Typer(
    name="scholai",
    help="scholai course atoms CLI",
    no_args_is_help=True,
)


@app.callback()
def _main():
    """scholai course atoms CLI."""


@app.command()
def version():
    """Show scholai-cli version."""
    typer.echo(__version__)


app.add_typer(course_app, name="course")
app.add_typer(usage_app, name="usage")


if __name__ == "__main__":
    app()
