"""env-only credentials reader for atoms.

Centralizes scholai env var names + URL default. Atoms call these
getters instead of os.environ.get(...) so the env contract lives in
one file. No file fallback — operators must inject env vars (e.g. via
openclaw skills.entries.<skill>.env mechanism).
"""
from __future__ import annotations

import os

DEFAULT_SCHOLAI_API_URL = "https://api.scholai.io"


# ---- text role ----

def get_llm_text_api_key() -> str | None:
    """读 LLM_TEXT_API_KEY env，缺则 None。"""
    return os.environ.get("LLM_TEXT_API_KEY") or None


def get_llm_text_base_url() -> str | None:
    """读 LLM_TEXT_BASE_URL env，缺则 None。"""
    return os.environ.get("LLM_TEXT_BASE_URL") or None


def get_llm_text_model() -> str | None:
    """读 LLM_TEXT_MODEL env，缺则 None。"""
    return os.environ.get("LLM_TEXT_MODEL") or None


# ---- image role ----

def get_llm_image_api_key() -> str | None:
    """读 LLM_IMAGE_API_KEY env，缺则 None。"""
    return os.environ.get("LLM_IMAGE_API_KEY") or None


def get_llm_image_base_url() -> str | None:
    """读 LLM_IMAGE_BASE_URL env，缺则 None。"""
    return os.environ.get("LLM_IMAGE_BASE_URL") or None


def get_llm_image_model() -> str | None:
    """读 LLM_IMAGE_MODEL env，缺则 None。"""
    return os.environ.get("LLM_IMAGE_MODEL") or None


# ---- vision dormant: model name reader 保留，凭据 reader 暂不引入 ----

def get_llm_vision_model() -> str | None:
    """读 LLM_VISION_MODEL env，缺则 None。"""
    return os.environ.get("LLM_VISION_MODEL") or None


# ---- 火山 ASR ----

def get_volc_asr_api_key() -> str | None:
    """读 VOLC_ASR_API_KEY env，缺则 None。火山 ASR 2.0 (volc.seedasr.auc)。"""
    return os.environ.get("VOLC_ASR_API_KEY") or None


# ---- 火山方舟视觉/视频理解 ----

def get_volc_vision_api_key() -> str | None:
    """读 VOLC_VISION_API_KEY env，缺则 None。豆包多模态视频理解 (ARK Files API)。"""
    return os.environ.get("VOLC_VISION_API_KEY") or None


# ---- scholai backend ----

def get_scholai_api_key() -> str | None:
    """读 SCHOLAI_API_KEY env，缺则 None。"""
    return os.environ.get("SCHOLAI_API_KEY")


def get_scholai_api_url() -> str:
    """读 SCHOLAI_API_URL env，缺则默认。返回值不以 `/` 结尾。"""
    return (os.environ.get("SCHOLAI_API_URL") or DEFAULT_SCHOLAI_API_URL).rstrip("/")
