"""publish atom: POST workspace artifact to scholai 平台。MVP 仅支持 kind=article。"""
from __future__ import annotations

import argparse
import json
import sys

import requests
from urllib.parse import urljoin

from scholai.common.credentials_reader import get_scholai_api_key, get_scholai_api_url
from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger


_PUBLISH_PATH = "/api/document"


_PAYLOAD_BY_KIND: dict[str, str] = {
    "article": "output/article.html",
    "mindmap": "output/mindmap.md",   # backend MARKDOWN_KINDS 白名单 → 必须 Markdown
    "exercise": "output/exercise.md", # backend MARKDOWN_KINDS 白名单 → 必须 Markdown
}


def _resolve_content(run_id: str, kind: str) -> dict:
    rel = _PAYLOAD_BY_KIND.get(kind)
    if rel is None:
        raise ValueError(
            f"unsupported kind={kind!r}, expected one of {sorted(_PAYLOAD_BY_KIND)}"
        )
    ws = workspace_path(run_id)
    content = (ws / rel).read_text(encoding="utf-8")
    return {"kind": kind, "content": content}


def run(run_id: str, kind: str) -> dict:
    log = get_run_logger(run_id, "publish")
    try:
        payload = _resolve_content(run_id, kind)
        log.info("resolved content: kind=%s, size=%d bytes", kind, len(payload["content"].encode()))

        api_key = get_scholai_api_key()
        if not api_key:
            raise RuntimeError("SCHOLAI_API_KEY not set")

        endpoint = f"{get_scholai_api_url()}{_PUBLISH_PATH}"
        log.info("POST %s", endpoint)
        resp = requests.post(
            endpoint,
            json=payload,
            headers={"x-api-key": api_key},
            timeout=60,
        )
        log.info("response: HTTP %d", resp.status_code)
        resp.raise_for_status()
        body = resp.json()
        url = body.get("url", "")
        if url.startswith("/"):
            url = urljoin(get_scholai_api_url(), url)
        log.info("published → %s", url)
        out = {"status": "done", "url": url}
        ws = workspace_path(run_id)
        (ws / "output" / "publish.json").write_text(
            json.dumps(out, ensure_ascii=False), encoding="utf-8"
        )
        return out
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--kind", required=True, help="article | mindmap | exercise")
    args = ap.parse_args()
    result = run(args.run_id, args.kind)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
