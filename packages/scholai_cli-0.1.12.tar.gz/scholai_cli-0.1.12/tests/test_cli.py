"""scholai CLI 烟测:root + course 子命令组。"""
from typer.testing import CliRunner

from scholai import __version__
from scholai.cli import app


runner = CliRunner()


def test_root_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "scholai" in result.stdout.lower()
    assert "course" in result.stdout


def test_version_command():
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert __version__ in result.stdout


def test_course_help():
    result = runner.invoke(app, ["course", "--help"])
    assert result.exit_code == 0
    assert "vfd-url" in result.stdout
    assert "iod" in result.stdout
    assert "pd" in result.stdout
    assert "txd-gen" in result.stdout
    assert "txd-imagegen" in result.stdout
    assert "txd-render-html" in result.stdout
    assert "publish" in result.stdout


def test_course_vfd_url_help():
    result = runner.invoke(app, ["course", "vfd-url", "--help"])
    assert result.exit_code == 0
    assert "--run-id" in result.stdout


def test_course_vfd_url_calls_run(mocker, tmp_workspace):
    """vfd-url CLI 应映射到 course.atoms.vfd_url.run(run_id),并打印 JSON。"""
    fake_result = {"status": "done", "path": "intermediate/VFD.json"}
    mocker.patch("scholai.course.commands.vfd_url_run", return_value=fake_result)
    result = runner.invoke(app, ["course", "vfd-url", "--run-id", tmp_workspace.run_id])
    assert result.exit_code == 0
    assert "done" in result.stdout
    assert "intermediate/VFD.json" in result.stdout


def test_course_vfd_url_failure_exit_code(mocker, tmp_workspace):
    mocker.patch("scholai.course.commands.vfd_url_run",
                 return_value={"status": "failed", "error": "boom"})
    result = runner.invoke(app, ["course", "vfd-url", "--run-id", tmp_workspace.run_id])
    assert result.exit_code == 1
    assert "failed" in result.stdout
    assert "boom" in result.stdout
