from typing import List, Optional, Dict
import pandas as pd
import numpy as np
import scipy.stats as sps

from aboba.base import BaseTest, TestResult


class RelativeIndependentTTest(BaseTest):
    """
    Performs an independent t-test using a ratio-based measure for effect size relative
    to the control group.
    
    Compatible with CUPED preprocessing: when used with CupedProcessor, automatically
    uses the original (pre-CUPED) control mean for denominator calculation, ensuring
    correct interpretation of relative effects while benefiting from variance reduction.

    Attributes:
        value_column (str): Name of the column containing the values to test.
        alternative (str): Defines the alternative hypothesis. Must be one of
            {'two-sided', 'less', 'greater'}.
        alpha (float): Significance level for confidence intervals (default: 0.05).
    """
    
    def __init__(
        self,
        value_column="target",
        alternative="two-sided",
        alpha=0.05,
    ):
        """
        Independent t-test for relative difference between two groups.
        
        This test compares the means of two independent groups to determine if there
        is a statistically significant relative difference between them. The relative
        difference is calculated as (test_mean - control_mean) / control_mean.
        
        When used after CUPED preprocessing, automatically uses the original control
        mean (before CUPED transformation) for correct relative effect calculation.
        This provides the best of both worlds: variance reduction from CUPED and
        correct relative effect interpretation.
        
        Args:
            value_column (str): Name of the column containing the values to test.
            alternative (str): Defines the alternative hypothesis. Options are:
                'two-sided' (default), 'less', or 'greater'.
            alpha (float): Significance level for confidence intervals (default: 0.05).
        
        Examples:
            ```python
            import pandas as pd
            import numpy as np
            from aboba.tests.relative_ttest import RelativeIndependentTTest

            # Example 1: Basic usage without CUPED
            np.random.seed(42)
            control = pd.DataFrame({'target': np.random.normal(100, 10, 100)})
            test = pd.DataFrame({'target': np.random.normal(105, 10, 100)})  # 5% increase

            test_instance = RelativeIndependentTTest(value_column='target')
            result = test_instance.test([control, test])
            print(f"P-value: {result.pvalue:.4f}")
            print(f"Relative Effect: {result.effect:.4f} ({result.effect*100:.2f}%)")
            
            # Example 2: Usage with CUPED (artifacts passed automatically by pipeline)
            # The test will automatically detect and use original control mean from artifacts
            ```
        """
        super().__init__()
        self.value_column = value_column
        self.alternative = alternative
        self.alpha = alpha
        assert alternative in {"two-sided", "less", "greater"}

    def test(self, groups: List[pd.DataFrame], artefacts: Optional[Dict] = None) -> TestResult:
        """
        Perform the relative independent t-test on the provided groups.
        
        Args:
            groups (List[pd.DataFrame]): List of two DataFrames representing the groups to compare.
                The first group is treated as the control group, the second as the test group.
            artefacts (Optional[Dict]): Artifacts from preprocessing pipeline. 
                If 'cuped_original_control_mean' is present, uses it as denominator for relative effect.
                This enables correct relative effect calculation when using CUPED.

        Returns:
            TestResult: Object containing the p-value and relative effect size.
                - pvalue: Statistical significance
                - effect: Relative effect (test - control) / control_mean
                - effect_type: "relative_control"
                - effect_interval: Confidence interval for the effect
        """

        control_group, test_group = groups

        Y = control_group[self.value_column].to_numpy(float)
        X = test_group[self.value_column].to_numpy(float)
        
        var_1, var_2 = np.var(X, ddof=1), np.var(Y, ddof=1)
        a_1, a_2 = np.mean(X), np.mean(Y)
        
        # Check if we have CUPED artifacts with original control mean
        if artefacts is not None and 'cuped_original_control_mean' in artefacts:
            original_control_mean = artefacts['cuped_original_control_mean']
            R = (a_1 - a_2) / original_control_mean
            # var_R = var_1 / (a_2**2) + (a_1**2) / (a_2**4) * var_2
            var_R = (var_1 + var_2) / (original_control_mean ** 2)
        else:
            R = (a_1 - a_2) / a_2
            var_R = var_1 / (a_2**2) + (a_1**2) / (a_2**4) * var_2
        
        n = len(test_group)
        stat = np.sqrt(n) * R / np.sqrt(var_R)

        if self.alternative == "two-sided":
            pvalue = 2 * min(sps.norm.cdf(stat), sps.norm.sf(stat))
            pvalue = min(pvalue, 1.0)
        elif self.alternative == "less":
            pvalue = sps.norm.cdf(stat)
        elif self.alternative == "greater":
            pvalue = sps.norm.sf(stat)
        else:
            raise ValueError(f"Unknown alternative: {self.alternative}")

        q = sps.norm.ppf(1 - self.alpha/2)
        left_bound = R - q * np.sqrt(var_R / n)
        right_bound = R + q * np.sqrt(var_R / n)

        return TestResult(
            pvalue=pvalue, 
            effect=R, 
            effect_type="relative_control", 
            effect_interval=(left_bound, right_bound)
        )
