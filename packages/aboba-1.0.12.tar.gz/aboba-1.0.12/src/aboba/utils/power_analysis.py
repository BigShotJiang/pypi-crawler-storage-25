# utils/power_analysis.py

from typing import List, Tuple, Optional
from tqdm.auto import tqdm
import pandas as pd
import numpy as np
from aboba.base.base_test import BaseTest, TestResult
from aboba.pipeline import Pipeline
from aboba.base import EffectModifier
from statsmodels.stats.proportion import proportion_confint


def simulate_power_for_effect(
    test: BaseTest,
    data: pd.DataFrame,
    pipeline: Pipeline,
    effect_modifier: Optional[EffectModifier],
    n_iter: int,
    alpha: float,
    effect_size: float,
    progress_desc: str = "Simulating"
) -> Tuple[int, List[float]]:
    """
    Simulates the experiment `n_iter` times for a given `effect_size` to estimate power.

    Uses the provided `test`, `data`, and `pipeline`. Applies the `effect_modifier`
    configured for the given `effect_size` during each simulation iteration.
    
    Compatible with updated Pipeline that returns (groups, artifacts) tuple.

    Parameters
    ----------
    test : BaseTest
        The statistical test to use (e.g., AbsoluteIndependentTTest, RelativeIndependentTTest).
    data : pd.DataFrame
        The source data to sample from using the pipeline.
    pipeline : Pipeline
        The pipeline to sample and potentially preprocess data.
        Now returns (groups, artifacts) tuple.
    effect_modifier : EffectModifier, optional
        The modifier to apply the effect. If None, no effect is applied (useful for alpha).
        This modifier should be pre-configured to apply `effect_size` to the correct group/column.
    n_iter : int
        Number of simulation iterations.
    alpha : float
        Significance level for determining rejections.
    effect_size : float
        The magnitude of the effect being simulated (passed to effect_modifier).
    progress_desc : str, optional
        Description for the progress bar.

    Returns
    -------
    Tuple[int, List[float]]
        n_rejects : int
            Number of times the null hypothesis was rejected (p < alpha).
        p_values : List[float]
            List of all p-values obtained from the simulations.
            
    Examples
    --------
    ```python
    from aboba.utils.power_analysis import simulate_power_for_effect
    from aboba.effect_modifiers import GroupModifier
    
    # Create effect modifier for 5% effect
    effect_mod = GroupModifier(
        effects={1: 0.05},
        value_column='metric',
        group_column='group'
    )
    
    # Simulate power
    n_rejects, p_values = simulate_power_for_effect(
        test=my_test,
        data=my_data,
        pipeline=my_pipeline,
        effect_modifier=effect_mod,
        n_iter=500,
        alpha=0.05,
        effect_size=0.05
    )
    
    power = n_rejects / 500
    print(f"Statistical power: {power:.3f}")
    ```
    """
    n_rejects = 0
    p_values = []

    for _ in tqdm(range(n_iter), desc=progress_desc, leave=False):
        pipeline_result = pipeline.transform(data)
        
        if isinstance(pipeline_result, tuple) and len(pipeline_result) == 2:
            sampled_groups, artifacts = pipeline_result
        else:
            sampled_groups = pipeline_result
            artifacts = None

        if effect_modifier is not None:
            modified_groups = effect_modifier(sampled_groups)
        else:
            modified_groups = sampled_groups

        test_result: TestResult = test.test(modified_groups, artefacts=artifacts)

        p_val = test_result.pvalue
        p_values.append(p_val)
        
        if p_val < alpha:
            n_rejects += 1

    return n_rejects, p_values
