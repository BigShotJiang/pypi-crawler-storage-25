"""
Pipeline allows you to sequentially apply preprocessors and splitter to your data.
"""


from .pipeline import Pipeline

