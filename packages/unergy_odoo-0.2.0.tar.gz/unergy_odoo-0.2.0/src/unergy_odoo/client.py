import os
import ssl
import time
import xmlrpc.client

_ssl_context = ssl.create_default_context()
_ssl_context.check_hostname = False
_ssl_context.verify_mode = ssl.CERT_NONE

_IDLE_RETRIES = 3
_IDLE_DELAY = 5  # seconds between retries when Odoo.sh is waking up


class OdooManager:
    """
    Base Odoo XML-RPC connection manager.

    Credentials are resolved in this order:
        1. Constructor arguments (host, db, username, password)
        2. Environment variables: ODOO_HOST, ODOO_DB, ODOO_USERNAME, ODOO_PASSWORD
    """

    def __init__(
        self,
        host: str | None = None,
        db: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ):
        self.host = host or os.environ["ODOO_HOST"]
        self.db = db or os.environ["ODOO_DB"]
        self.username = username or os.environ["ODOO_USERNAME"]
        self.password = password or os.environ["ODOO_PASSWORD"]

        # Per-instance proxies — shared proxies are not thread-safe.
        self.common = xmlrpc.client.ServerProxy(
            f"{self.host}/xmlrpc/2/common", context=_ssl_context
        )
        self.models = xmlrpc.client.ServerProxy(
            uri=f"{self.host}/xmlrpc/2/object", allow_none=True, context=_ssl_context
        )

    def _exec(self, *args, **kwargs):
        for attempt in range(_IDLE_RETRIES + 1):
            try:
                return self.models.execute_kw(*args, **kwargs)
            except xmlrpc.client.Fault as e:
                if "Idle" in str(e.faultString) and attempt < _IDLE_RETRIES:
                    time.sleep(_IDLE_DELAY)
                    continue
                raise

    def authenticate(self):
        try:
            uid = self.common.authenticate(self.db, self.username, self.password, {})
            return uid
        except (ConnectionRefusedError, TimeoutError):
            print("ERROR: Odoo connection error.")


class Odoo(OdooManager):
    class DoesNotExist(Exception):
        pass

    def __init__(
        self,
        model_name: str,
        host: str | None = None,
        db: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ):
        super().__init__(host=host, db=db, username=username, password=password)
        self.model_name = model_name
        self.uid = self.authenticate()

    def info_model(self):
        attrs = self._exec(
            self.db,
            self.uid,
            self.password,
            self.model_name,
            "fields_get",
            [],
            {"attributes": ["string", "help", "type", "relation", "selection"]},
        )
        return attrs

    def call_method(self, method, args):
        attrs = self._exec(
            self.db,
            self.uid,
            self.password,
            self.model_name,
            method,
            args,
        )
        return attrs

    def create(self, context):
        """
        Create record.

        Parameters:
            context: Dictionary of partner object

        Returns:
            id (int) of created record
        """
        id = self._exec(
            self.db, self.uid, self.password, self.model_name, "create", [context]
        )
        return id

    def delete(self, ids):
        """
        Delete record.

        Parameters:
            ids: list of ids

        Returns:
            True if register was deleted else False
        """
        return self._exec(
            self.db, self.uid, self.password, self.model_name, "unlink", [ids]
        )

    def filter(self, fields="all", filter=[["id", "!=", -1]], limit=None, extra={}):
        """
        Get matching records.

        Parameters:
            fields: list of fields
            filter: list of elements to filter
            limit: maximum number of records to retrieve
        """
        if fields == "all":
            match = self._exec(
                self.db,
                self.uid,
                self.password,
                self.model_name,
                "search_read",
                [filter],
                {"limit": limit, **extra},
            )
        else:
            match = self._exec(
                self.db,
                self.uid,
                self.password,
                self.model_name,
                "search_read",
                [filter],
                {"fields": fields, "limit": limit, **extra},
            )

        return match

    def get(self, fields="all", filter=[["id", "!=", -1]], extra={}):
        try:
            return self.filter(fields=fields, filter=filter, extra=extra, limit=1)[0]
        except IndexError:
            raise self.DoesNotExist(
                f"No record that matches the given filter exists in the model {self.model_name}"
            )

    def get_id(self, filter):
        return self.get(fields=["id"], filter=filter)["id"]

    def get_value_field(self, fields, filter, field, extra, limit=None):
        try:
            return self.filter(fields=fields, filter=filter, extra=extra, limit=limit)[
                0
            ][field]
        except IndexError:
            raise self.DoesNotExist(
                f"No record that matches the given filter exists in the model {self.model_name}"
            )
        except KeyError:
            raise KeyError(
                f'The field "{field}" does not exist in the model {self.model_name}. Available fields: {list(self.info_model().keys())}'
            )

    def get_list_value_field(
        self, fields="all", filter=[["id", "!=", -1]], field="id", extra={}
    ):
        """
        Get a list of values for a specific field from the filtered records.

        Parameters:
            fields: list of fields to retrieve
            filter: list of elements to filter
            field: the specific field to extract values from
            extra: additional parameters for the search_read method

        Returns:
            A list of values for the specified field.
        """
        records = self.filter(fields=fields, filter=filter, extra=extra)
        return [record[field] for record in records if field in record]

    def count(self, fields="all", filter=[["id", "!=", -1]], extra={}):
        """
        Count matching records.

        https://www.odoo.com/documentation/13.0/reference/orm.html#reference-orm-domains
        """
        if fields == "all":
            match = self._exec(
                self.db,
                self.uid,
                self.password,
                self.model_name,
                "search_count",
                [filter],
                extra,
            )
        else:
            match = self._exec(
                self.db,
                self.uid,
                self.password,
                self.model_name,
                "search_count",
                [filter],
                {"fields": fields, **extra},
            )

        return match

    def get_by_id(self, id="all", fields="all", filter=["id", "!=", -1]):
        """
        Get record information by id.

        Parameters:
            ids (int or list of ints): Records ids.
            fields: list of fields
            filter: list of elements to filter

        https://www.odoo.com/documentation/13.0/reference/orm.html#reference-orm-domains
        """
        if id == "all":
            id = self._exec(
                self.db,
                self.uid,
                self.password,
                self.model_name,
                "search",
                [[filter]],
            )

        if fields == "all":
            partners = self._exec(
                self.db, self.uid, self.password, self.model_name, "read", [id]
            )
        else:
            partners = self._exec(
                self.db,
                self.uid,
                self.password,
                self.model_name,
                "read",
                [id],
                {"fields": fields},
            )

        return partners

    def update(self, ids, context):
        """
        Update record.

        Parameters:
            ids: list of ids
            context: dictionary with attributes to be updated.

        Returns:
            True if register was updated else False
        """
        return self._exec(
            self.db,
            self.uid,
            self.password,
            self.model_name,
            "write",
            [ids, context],
        )

    def call_kw(self, id, kw, context={}):
        """
        Calls custom keyword/method.
        """
        return self._exec(
            self.db, self.uid, self.password, self.model_name, kw, [[id]], context
        )


FIELD_TYPES = (
    "char", "text", "integer", "float", "boolean", "date", "datetime",
    "selection", "many2one", "one2many", "many2many", "binary", "html",
    "monetary",
)

RELATIONAL_TYPES = ("many2one", "one2many", "many2many")


class OdooExplorer(OdooManager):
    """
    Read-only introspection utilities for discovering Odoo models,
    fields, relations, and sample data. Never writes to Odoo.
    """

    def __init__(
        self,
        host: str | None = None,
        db: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ):
        super().__init__(host=host, db=db, username=username, password=password)
        self.uid = self.authenticate()

    def _exec(self, model: str, method: str, args: list, kwargs: dict = {}):
        return super()._exec(self.db, self.uid, self.password, model, method, args, kwargs)

    # ------------------------------------------------------------------
    # Model discovery
    # ------------------------------------------------------------------

    def search_models(self, keyword: str) -> list[dict]:
        """
        Search Odoo models whose technical name or display name contains
        the given keyword (case-insensitive).

        Returns a list of dicts with keys: name, model, info.

        Example:
            explorer.search_models("nomina")
            explorer.search_models("payslip")
        """
        return self._exec(
            "ir.model",
            "search_read",
            [["|", ["name", "ilike", keyword], ["model", "ilike", keyword]]],
            {"fields": ["name", "model", "info"], "order": "model asc"},
        )

    def count_records(self, model_name: str, domain: list = []) -> int:
        """
        Count records in a model, optionally filtered by domain.
        Useful for confirming a model has real data before digging deeper.

        Example:
            explorer.count_records("hr.payslip")
            explorer.count_records("hr.contract", [["state", "=", "open"]])
        """
        return self._exec(model_name, "search_count", [domain])

    # ------------------------------------------------------------------
    # Field inspection
    # ------------------------------------------------------------------

    def model_fields(
        self,
        model_name: str,
        field_type: str | None = None,
    ) -> dict:
        """
        Return all fields of a model with their metadata.
        Optionally filter by field_type (e.g. "many2one", "char", "selection").

        Valid field types: char, text, integer, float, boolean, date,
        datetime, selection, many2one, one2many, many2many, binary, html, monetary.

        Example:
            explorer.model_fields("hr.payslip")
            explorer.model_fields("hr.payslip", field_type="selection")
        """
        fields = self._exec(
            model_name,
            "fields_get",
            [],
            {
                "attributes": [
                    "string", "help", "type", "relation",
                    "selection", "required", "readonly",
                ]
            },
        )
        if field_type:
            fields = {k: v for k, v in fields.items() if v.get("type") == field_type}
        return fields

    def model_relations(self, model_name: str) -> dict:
        """
        Return only the relational fields (many2one, one2many, many2many)
        of a model, including the target model name under the 'relation' key.

        Useful for mapping how models connect to each other.

        Example:
            explorer.model_relations("hr.payslip")
        """
        fields = self._exec(
            model_name,
            "fields_get",
            [],
            {"attributes": ["string", "type", "relation", "required", "readonly"]},
        )
        return {k: v for k, v in fields.items() if v.get("type") in RELATIONAL_TYPES}

    # ------------------------------------------------------------------
    # Sample data
    # ------------------------------------------------------------------

    def sample(
        self,
        model_name: str,
        limit: int = 3,
        fields: list[str] | None = None,
        domain: list = [],
    ) -> list[dict]:
        """
        Fetch a small number of real records from a model to inspect
        what the data actually looks like in production.

        Example:
            explorer.sample("hr.payslip", limit=2)
            explorer.sample("hr.payslip", fields=["name", "state", "employee_id"])
        """
        kwargs: dict = {"limit": limit}
        if fields:
            kwargs["fields"] = fields
        return self._exec(model_name, "search_read", [domain], kwargs)
