from unergy_odoo.client import FIELD_TYPES, RELATIONAL_TYPES, Odoo, OdooExplorer, OdooManager
from unergy_odoo.novedades import (
    Attachment,
    BonoGimnasio,
    Deuda,
    EmployeeNotFound,
    NovedadBase,
    Viatico,
)

__all__ = [
    "OdooManager",
    "Odoo",
    "OdooExplorer",
    "FIELD_TYPES",
    "RELATIONAL_TYPES",
    "NovedadBase",
    "BonoGimnasio",
    "Deuda",
    "Viatico",
    "EmployeeNotFound",
    "Attachment",
]
