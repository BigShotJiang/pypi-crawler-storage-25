import os
import stat
import subprocess
import sys

from proot_distro.constants import INSTALLED_ROOTFS_DIR, DISTRO_CONFIGS_DIR
from proot_distro.colors import C, msg


def command_backup(args, configs: dict) -> None:
    distro_name = args.alias
    output_path = getattr(args, "output", None)

    if distro_name not in configs:
        msg()
        msg(f"{C['BRED']}Error: unknown distribution '{C['YELLOW']}{distro_name}{C['BRED']}' was requested for backup.{C['RST']}")
        msg()
        sys.exit(1)

    rootfs_dir = os.path.join(INSTALLED_ROOTFS_DIR, distro_name)
    if not os.path.isdir(rootfs_dir):
        msg()
        msg(f"{C['BRED']}Error: distribution '{C['YELLOW']}{distro_name}{C['BRED']}' is not installed.{C['RST']}")
        msg()
        sys.exit(1)

    cfg = configs[distro_name]
    config_file = cfg.config_path

    if output_path:
        if os.path.isdir(output_path):
            msg()
            msg(f"{C['BRED']}Error: '{C['YELLOW']}{output_path}{C['BRED']}' is a directory.{C['RST']}")
            sys.exit(1)
        if os.path.isfile(output_path):
            msg()
            msg(f"{C['BRED']}Error: file '{C['YELLOW']}{output_path}{C['BRED']}' already exists.{C['RST']}")
            sys.exit(1)
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Tarball will be written to '{output_path}'.{C['RST']}")
    else:
        if sys.stdout.isatty():
            msg()
            msg(f"{C['BRED']}Error: tarball cannot be printed to console. Please use option "
                f"'{C['YELLOW']}--output{C['BRED']}' to specify a file or use pipe for sending the output to another program.{C['RST']}")
            msg()
            sys.exit(1)
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Tarball will be written to stdout.{C['RST']}")

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Backing up {C['YELLOW']}{cfg.name}{C['CYAN']}...{C['RST']}")

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Fixing file permissions in rootfs...{C['RST']}")
    for dirpath, dirs, files in os.walk(rootfs_dir):
        try:
            os.chmod(dirpath, os.stat(dirpath).st_mode | stat.S_IRUSR | stat.S_IXUSR)
        except OSError:
            pass
        for fname in files:
            fpath = os.path.join(dirpath, fname)
            try:
                fstat = os.lstat(fpath)
                if stat.S_ISREG(fstat.st_mode):
                    mode = fstat.st_mode
                    if mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH):
                        os.chmod(fpath, mode | stat.S_IRUSR | stat.S_IXUSR)
                    else:
                        os.chmod(fpath, mode | stat.S_IRUSR)
            except OSError:
                pass

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Archiving the rootfs and plug-in...{C['RST']}")

    configs_parent = os.path.dirname(DISTRO_CONFIGS_DIR)   # $PREFIX/etc
    configs_base   = os.path.basename(DISTRO_CONFIGS_DIR)  # proot-distro
    rootfs_parent  = os.path.dirname(INSTALLED_ROOTFS_DIR)  # $PREFIX/var/lib/proot-distro
    rootfs_base    = os.path.basename(INSTALLED_ROOTFS_DIR) # installed-rootfs

    config_rel = os.path.join(configs_base, os.path.basename(config_file))
    rootfs_rel = os.path.join(rootfs_base, distro_name)

    if output_path:
        tar_cmd = ["tar", "-c", "--auto-compress", "--warning=no-file-ignored",
                   "-f", output_path,
                   "-C", configs_parent, config_rel,
                   "-C", rootfs_parent, rootfs_rel]
    else:
        tar_cmd = ["tar", "-c", "--warning=no-file-ignored",
                   "-C", configs_parent, config_rel,
                   "-C", rootfs_parent, rootfs_rel]

    try:
        subprocess.run(tar_cmd, check=True)
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
    except subprocess.CalledProcessError:
        if output_path:
            try:
                os.remove(output_path)
            except OSError:
                pass
        sys.exit(1)
