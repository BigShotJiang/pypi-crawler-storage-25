from proot_distro.constants import PROGRAM_NAME, RUNTIME_DIR, TERMUX_APP_PACKAGE
from proot_distro.colors import C, msg, show_version


_HELP_COMMANDS = {
    "install":  lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}install {C['CYAN']}[OPTIONS] ALIAS{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Command aliases: {C['GREEN']}add, i, in, ins{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Install a specified Linux distribution.{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Options:{C['RST']}"), msg(),
        msg(f"  {C['GREEN']}--help                        {C['CYAN']}- Show this help.{C['RST']}"),
        msg(f"  {C['GREEN']}--override-alias [alias]      {C['CYAN']}- Install under a custom alias.{C['RST']}"),
        msg(),
        msg(f"{C['CYAN']}Override tarball URL via env: {C['GREEN']}PD_OVERRIDE_TARBALL_URL{C['RST']}"),
        msg(f"{C['CYAN']}Override checksum via env:    {C['GREEN']}PD_OVERRIDE_TARBALL_SHA256{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "remove":   lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}remove {C['CYAN']}ALIAS{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Command aliases: {C['GREEN']}rm{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Remove a specified Linux distribution. No confirmation prompt.{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "rename":   lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}rename {C['CYAN']}ORIG-ALIAS NEW-ALIAS{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Command aliases: {C['GREEN']}mv{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Rename an installed distribution.{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "reset":    lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}reset {C['CYAN']}ALIAS{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Reinstall the specified Linux distribution from scratch.{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "login":    lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}login {C['CYAN']}[OPTIONS] ALIAS [-- COMMAND]{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Command aliases: {C['GREEN']}sh{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Options:{C['RST']}"), msg(),
        msg(f"  {C['GREEN']}--user [user]        {C['CYAN']}- Login as specified user (default: root).{C['RST']}"),
        msg(f"  {C['GREEN']}--fix-low-ports      {C['CYAN']}- Remap protected ports to higher numbers.{C['RST']}"),
        msg(f"  {C['GREEN']}--isolated           {C['CYAN']}- No access to host filesystem.{C['RST']}"),
        msg(f"  {C['GREEN']}--termux-home        {C['CYAN']}- Mount Termux home into the distro.{C['RST']}"),
        msg(f"  {C['GREEN']}--shared-tmp         {C['CYAN']}- Mount Termux tmp to /tmp.{C['RST']}"),
        msg(f"  {C['GREEN']}--bind [path:path]   {C['CYAN']}- Custom bind mount (repeatable).{C['RST']}"),
        msg(f"  {C['GREEN']}--no-link2symlink    {C['CYAN']}- Disable hardlink emulation.{C['RST']}"),
        msg(f"  {C['GREEN']}--no-sysvipc         {C['CYAN']}- Disable System V IPC emulation.{C['RST']}"),
        msg(f"  {C['GREEN']}--no-kill-on-exit    {C['CYAN']}- Wait for all processes before exit.{C['RST']}"),
        msg(f"  {C['GREEN']}--no-arch-warning    {C['CYAN']}- Suppress 32-bit arch warnings.{C['RST']}"),
        msg(f"  {C['GREEN']}--kernel [string]    {C['CYAN']}- Fake kernel release string.{C['RST']}"),
        msg(f"  {C['GREEN']}--hostname [string]  {C['CYAN']}- Custom hostname.{C['RST']}"),
        msg(f"  {C['GREEN']}--work-dir [path]    {C['CYAN']}- Set working directory.{C['RST']}"),
        msg(f"  {C['GREEN']}--env VAR=val        {C['CYAN']}- Set environment variable (repeatable).{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "list":     lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}list{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Command aliases: {C['GREEN']}li, ls{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Options:{C['RST']}"), msg(),
        msg(f"  {C['GREEN']}--verbose   {C['CYAN']}- Detailed output.{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "backup":   lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}backup {C['CYAN']}[OPTIONS] ALIAS{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Command aliases: {C['GREEN']}bak, bkp{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Options:{C['RST']}"), msg(),
        msg(f"  {C['GREEN']}--output [file]  {C['CYAN']}- Write tarball to file (auto-compress by extension).{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "restore":  lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}restore {C['CYAN']}[FILENAME.TAR]{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Restore from a backup tarball, or pipe from stdin (uncompressed).{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "clear-cache": lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}clear-cache{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Command aliases: {C['GREEN']}clear, cl{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Remove all cached rootfs archives.{C['RST']}"),
        msg(), show_version(), msg(),
    ),
    "copy":     lambda: (
        msg(), msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME} {C['GREEN']}copy {C['CYAN']}[OPTIONS] [DIST:]SRC [DIST:]DEST{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Command aliases: {C['GREEN']}cp{C['RST']}"),
        msg(), msg(f"{C['CYAN']}Options:{C['RST']}"), msg(),
        msg(f"  {C['GREEN']}--move     {C['CYAN']}- Move instead of copying.{C['RST']}"),
        msg(f"  {C['GREEN']}--verbose  {C['CYAN']}- Show copied files.{C['RST']}"),
        msg(), show_version(), msg(),
    ),
}


def command_help(args, configs: dict) -> None:
    msg()
    msg(f"{C['BYELLOW']}Usage: {C['BCYAN']}{PROGRAM_NAME}{C['CYAN']} [COMMAND] [ARGUMENTS]{C['RST']}")
    msg()
    msg(f"{C['CYAN']}PRoot-Distro is a utility for managing Linux proot containers{C['RST']}")
    msg(f"{C['CYAN']}on Termux. It provides a standardized interface to install,{C['RST']}")
    msg(f"{C['CYAN']}launch, and manage Linux distributions.{C['RST']}")
    msg()
    msg(f"{C['CYAN']}List of available commands:{C['RST']}")
    msg()
    msg(f"  {C['GREEN']}help         {C['CYAN']}- Show this help information.{C['RST']}")
    msg(f"  {C['GREEN']}backup       {C['CYAN']}- Backup a specified distribution.{C['RST']}")
    msg(f"  {C['GREEN']}install      {C['CYAN']}- Install a specified Linux distribution.{C['RST']}")
    msg(f"  {C['GREEN']}list         {C['CYAN']}- List supported distributions and their{C['RST']}")
    msg(f"                 {C['CYAN']}installation status.{C['RST']}")
    msg(f"  {C['GREEN']}login        {C['CYAN']}- Start login shell for the specified distribution.{C['RST']}")
    msg(f"  {C['GREEN']}remove       {C['CYAN']}- Delete a specified Linux distribution.{C['RST']}")
    msg(f"                 {C['RED']}WARNING: this command destroys data!{C['RST']}")
    msg(f"  {C['GREEN']}rename       {C['CYAN']}- Rename installed distribution.{C['RST']}")
    msg(f"  {C['GREEN']}reset        {C['CYAN']}- Reinstall from scratch a specified distribution.{C['RST']}")
    msg(f"                 {C['RED']}WARNING: this command destroys data!{C['RST']}")
    msg(f"  {C['GREEN']}restore      {C['CYAN']}- Restore a specified distribution.{C['RST']}")
    msg(f"                 {C['RED']}WARNING: this command destroys data!{C['RST']}")
    msg(f"  {C['GREEN']}clear-cache  {C['CYAN']}- Clear cache of downloaded files.{C['RST']}")
    msg(f"  {C['GREEN']}copy         {C['CYAN']}- Copy files from/to distribution.{C['RST']}")
    msg()
    msg(f"{C['CYAN']}Each command has its own help: {C['GREEN']}{PROGRAM_NAME} <command> --help{C['RST']}")
    msg()
    msg(f"{C['CYAN']}Runtime data directory:{C['RST']}")
    msg(f"{C['YELLOW']}  {RUNTIME_DIR}{C['RST']}")
    msg()
    msg(f"{C['CYAN']}If you have issues with proot, try setting {C['GREEN']}PROOT_NO_SECCOMP=1{C['RST']}")
    msg()
    show_version()
    msg()
