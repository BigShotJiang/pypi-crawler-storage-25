import os
import re
import shutil
import subprocess
import sys

import yaml

from proot_distro.constants import (
    DISTRO_CONFIGS_DIR,
    DOWNLOAD_CACHE_DIR,
    INSTALLED_ROOTFS_DIR,
    PROGRAM_NAME,
    _SAVED_LD_PRELOAD,
)
from proot_distro.colors import C, msg
from proot_distro.config import load_config, _write_yaml
from proot_distro.arch import get_device_cpu_arch, get_distro_arch_override
from proot_distro.sysdata import setup_fake_sysdata
from proot_distro.download import sha256_file, download_file
from proot_distro.rootfs import (
    _write_environment,
    _fix_path_in_configs,
    _write_resolv_conf,
    _write_hosts,
    _register_android_ids,
    _run_post_install,
)

_ALIAS_RE = re.compile(r'^[a-z0-9][a-z0-9_.+\-]*$')


def _validate_alias(alias: str) -> bool:
    return bool(_ALIAS_RE.match(alias)) and not alias.endswith(".yaml")


def command_install(args, configs: dict) -> None:
    distro_name = args.alias
    override_alias = getattr(args, "override_alias", None)

    if distro_name not in configs:
        msg()
        msg(f"{C['BRED']}Error: unknown distribution '{C['YELLOW']}{distro_name}{C['BRED']}' was requested to be installed.{C['RST']}")
        msg()
        msg(f"{C['CYAN']}View supported distributions by: {C['GREEN']}{PROGRAM_NAME} list{C['RST']}")
        msg()
        sys.exit(1)

    cfg = configs[distro_name]
    install_name = distro_name

    if override_alias:
        if not _validate_alias(override_alias):
            msg()
            msg(f"{C['BRED']}Error: invalid alias '{C['YELLOW']}{override_alias}{C['BRED']}'. "
                f"Must start with alphanumeric and contain only [a-z0-9_.+-].{C['RST']}")
            msg()
            sys.exit(1)
        if os.path.exists(os.path.join(DISTRO_CONFIGS_DIR, override_alias + ".yaml")) \
                or os.path.exists(os.path.join(DISTRO_CONFIGS_DIR, override_alias + ".override.yaml")):
            msg()
            msg(f"{C['BRED']}Error: distribution with alias '{C['YELLOW']}{override_alias}{C['BRED']}' already exists.{C['RST']}")
            msg()
            sys.exit(1)
        # Create override config with the new alias appended to name.
        override_path = os.path.join(DISTRO_CONFIGS_DIR, override_alias + ".override.yaml")
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating override config '{override_path}'...{C['RST']}")
        with open(cfg.config_path) as fh:
            orig_data = yaml.safe_load(fh)
        orig_data["name"] = f"{cfg.name} - {override_alias}"
        _write_yaml(override_path, orig_data)
        install_name = override_alias
        cfg = load_config(override_path, override_alias)

    rootfs_dir = os.path.join(INSTALLED_ROOTFS_DIR, install_name)
    if os.path.isdir(rootfs_dir):
        msg()
        msg(f"{C['BRED']}Error: distribution '{C['YELLOW']}{install_name}{C['BRED']}' is already installed.{C['RST']}")
        msg()
        msg(f"{C['CYAN']}Log in:     {C['GREEN']}{PROGRAM_NAME} login {install_name}{C['RST']}")
        msg(f"{C['CYAN']}Reinstall:  {C['GREEN']}{PROGRAM_NAME} reset {install_name}{C['RST']}")
        msg(f"{C['CYAN']}Uninstall:  {C['GREEN']}{PROGRAM_NAME} remove {install_name}{C['RST']}")
        msg()
        sys.exit(1)

    # Determine architecture.
    device_arch = get_device_cpu_arch()
    distro_arch = get_distro_arch_override() or device_arch
    arch_entry = next((e for e in cfg.architectures if e.arch == distro_arch), None)
    if arch_entry is None:
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}The distribution is not available for CPU architecture '{distro_arch}'.{C['RST']}")
        sys.exit(1)

    # Allow env override of URL/checksum.
    url = os.environ.get("PD_OVERRIDE_TARBALL_URL", "") or arch_entry.url
    checksum = os.environ.get("PD_OVERRIDE_TARBALL_SHA256", "") or arch_entry.checksum
    if os.environ.get("PD_OVERRIDE_TARBALL_URL"):
        checksum = os.environ.get("PD_OVERRIDE_TARBALL_SHA256", "")

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Installing {C['YELLOW']}{cfg.name}{C['CYAN']}...{C['RST']}")

    os.makedirs(rootfs_dir, exist_ok=True)
    l2s_dir = os.path.join(rootfs_dir, ".l2s")
    os.makedirs(l2s_dir, exist_ok=True)

    def _cleanup():
        try:
            shutil.rmtree(rootfs_dir)
        except OSError:
            pass
        if override_alias:
            override_path = os.path.join(DISTRO_CONFIGS_DIR, override_alias + ".override.yaml")
            try:
                os.remove(override_path)
            except OSError:
                pass

    try:
        os.makedirs(DOWNLOAD_CACHE_DIR, exist_ok=True)
        archive_name = os.path.basename(url.split("?")[0])
        archive_path = os.path.join(DOWNLOAD_CACHE_DIR, archive_name)

        if os.path.isfile(archive_path):
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Using cached rootfs archive...{C['RST']}")
        else:
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Downloading rootfs archive...{C['RST']}")
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}URL: {url}{C['RST']}")
            download_file(url, archive_path)

        if checksum:
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Verifying rootfs checksum...{C['RST']}")
            actual = sha256_file(archive_path)
            if actual != checksum:
                msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Verification failure: downloaded file is corrupted.{C['RST']}")
                os.remove(archive_path)
                _cleanup()
                sys.exit(1)
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Integrity check passed.{C['RST']}")
        else:
            msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Integrity checking of downloaded rootfs has been disabled.{C['RST']}")

        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Extracting rootfs, please wait...{C['RST']}")

        tar_cmd = [
            "proot", "--link2symlink",
            "tar", "-C", rootfs_dir,
            "--warning=no-unknown-keyword",
            "--delay-directory-restore",
            "--preserve-permissions",
        ]
        if cfg.tarball_strip:
            tar_cmd.append(f"--strip={cfg.tarball_strip}")
        tar_cmd += ["-xf", archive_path, "--exclude=dev"]

        env = os.environ.copy()
        env.pop("LD_PRELOAD", None)
        env["PROOT_L2S_DIR"] = l2s_dir

        proc = subprocess.run(tar_cmd, env=env, capture_output=True, text=True)
        # Suppress noisy linkerconfig warnings.
        for line in proc.stderr.splitlines():
            if "/linkerconfig/" not in line:
                msg(line)
        if _SAVED_LD_PRELOAD:
            os.environ["LD_PRELOAD"] = _SAVED_LD_PRELOAD

        if not os.path.isdir(os.path.join(rootfs_dir, "etc")):
            msg()
            msg(f"{C['BRED']}Error: the rootfs of distribution '{C['YELLOW']}{install_name}{C['BRED']}' has unexpected structure "
                f"(no /etc directory). Make sure that variable TARBALL_STRIP_OPT specified in distribution plug-in is correct.{C['RST']}")
            msg()
            _cleanup()
            sys.exit(1)

        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Writing file '{rootfs_dir}/etc/environment'...{C['RST']}")
        _write_environment(rootfs_dir)
        _fix_path_in_configs(rootfs_dir)

        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating file '{rootfs_dir}/etc/resolv.conf'...{C['RST']}")
        _write_resolv_conf(rootfs_dir)

        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Creating file '{rootfs_dir}/etc/hosts'...{C['RST']}")
        _write_hosts(rootfs_dir)

        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Registering Android-specific UIDs and GIDs...{C['RST']}")
        _register_android_ids(rootfs_dir)

        setup_fake_sysdata(install_name)

        if cfg.post_install_automation.strip():
            msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Running distribution-specific configuration steps...{C['RST']}")
            _run_post_install(install_name, cfg.post_install_automation, distro_arch)

    except Exception:
        _cleanup()
        raise

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")
    msg()
    msg(f"{C['CYAN']}Log in with: {C['GREEN']}{PROGRAM_NAME} login {install_name}{C['CYAN']}{C['RST']}")
    msg()
