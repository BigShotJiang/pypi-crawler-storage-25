import os
import re
import sys
from dataclasses import dataclass, field

try:
    import yaml
except ImportError:
    print("Error: PyYAML is required. Install with: pip install pyyaml", file=sys.stderr)
    sys.exit(1)

from proot_distro.constants import DISTRO_CONFIGS_DIR

# Configs bundled with the package (lowest priority; overridden by DISTRO_CONFIGS_DIR).
_BUNDLED_CONFIGS_DIR = os.path.join(os.path.dirname(__file__), "configs")
from proot_distro.colors import C, msg


@dataclass
class ArchEntry:
    arch: str
    url: str
    checksum: str = ""


@dataclass
class DistroConfig:
    alias: str
    config_path: str
    name: str
    version: str
    architectures: list  # list[ArchEntry]
    description: str = ""
    post_install_automation: str = ""
    tarball_strip: int = 0


def _parse_arch_entries(raw: list) -> list:
    entries = []
    for item in raw:
        if not isinstance(item, dict):
            raise ValueError(f"Expected a mapping in architectures list, got {type(item).__name__}")
        checksum = str(item.get("checksum", ""))
        for key, value in item.items():
            if key == "checksum":
                continue
            entries.append(ArchEntry(arch=str(key), url=str(value), checksum=checksum))
            break
    return entries


def load_config(path: str, alias: str) -> DistroConfig:
    with open(path) as fh:
        data = yaml.safe_load(fh)
    if not isinstance(data, dict):
        raise ValueError("Config file does not contain a YAML mapping")
    return DistroConfig(
        alias=alias,
        config_path=path,
        name=str(data.get("name", alias)),
        version=str(data.get("version", "")),
        architectures=_parse_arch_entries(data.get("architectures", [])),
        description=str(data.get("description", "")),
        post_install_automation=str(data.get("post_install_automation", "") or ""),
        tarball_strip=int(data.get("tarball_strip", 0)),
    )


def discover_configs() -> dict:
    """Return {alias: DistroConfig} for all known distribution configs.

    Priority (highest to lowest):
      1. DISTRO_CONFIGS_DIR/*.override.yaml  — user/system overrides
      2. DISTRO_CONFIGS_DIR/*.yaml           — system-installed configs
      3. proot_distro/configs/*.yaml         — configs bundled with the package
    """
    base: dict = {}
    override: dict = {}

    # Bundled package configs (lowest priority).
    if os.path.isdir(_BUNDLED_CONFIGS_DIR):
        for fname in os.listdir(_BUNDLED_CONFIGS_DIR):
            if fname.endswith(".yaml") and not fname.endswith(".override.yaml"):
                alias = fname[: -len(".yaml")]
                base[alias] = os.path.join(_BUNDLED_CONFIGS_DIR, fname)

    # System/user configs; .yaml files override bundled ones, .override.yaml
    # files take the highest precedence.
    if os.path.isdir(DISTRO_CONFIGS_DIR):
        for fname in os.listdir(DISTRO_CONFIGS_DIR):
            full = os.path.join(DISTRO_CONFIGS_DIR, fname)
            if not os.path.isfile(full):
                continue
            if fname.endswith(".override.yaml"):
                alias = fname[: -len(".override.yaml")]
                override[alias] = full
            elif fname.endswith(".yaml"):
                alias = fname[: -len(".yaml")]
                base[alias] = full

    configs: dict = {}
    for alias in sorted(set(base) | set(override)):
        path = override.get(alias) or base.get(alias, "")
        try:
            configs[alias] = load_config(path, alias)
        except Exception as exc:
            msg(f"{C['BRED']}Warning: failed to load config for '{alias}': {exc}{C['RST']}")
    return configs


def config_file_for_alias(alias: str) -> str:
    """Return the active config file path for *alias*, or empty string."""
    for ext in (".override.yaml", ".yaml"):
        p = os.path.join(DISTRO_CONFIGS_DIR, alias + ext)
        if os.path.isfile(p):
            return p
    return ""


def _write_yaml(path: str, data: dict) -> None:
    """Write *data* as YAML to *path* using manual formatting for clean output."""
    lines = []
    for key, value in data.items():
        if isinstance(value, str) and "\n" in value:
            lines.append(f"{key}: |")
            for line in value.splitlines():
                lines.append(f"  {line}")
        elif isinstance(value, list):
            lines.append(f"{key}:")
            for item in value:
                if isinstance(item, dict):
                    first = True
                    for k, v in item.items():
                        prefix = "  - " if first else "    "
                        lines.append(f'{prefix}{k}: "{v}"')
                        first = False
                else:
                    lines.append(f"  - {item}")
        else:
            lines.append(f'{key}: "{value}"')
    lines.append("")
    with open(path, "w") as fh:
        fh.write("\n".join(lines))
