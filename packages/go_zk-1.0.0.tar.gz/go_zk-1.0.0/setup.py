# -*- coding: utf-8 -*-from setuptools import setup
from setuptools import setup
setup(
    name='go-zk',
    version='1.0.0',
    description='A fork of pyzk with ping check removed for restricted network environments',
    url='https://github.com/Golive-Solution/go-zk',
    author='Golive Solutions',
    author_email='info@golive-solutions.com',
    license='LICENSE.txt',
    packages=['zk'],
    keywords=[
        'zk',
        'pyzk',
        'zksoftware',
        'attendance machine',
        'fingerprint',
        'biometrics',
        'security'
    ],
    zip_safe=False
)