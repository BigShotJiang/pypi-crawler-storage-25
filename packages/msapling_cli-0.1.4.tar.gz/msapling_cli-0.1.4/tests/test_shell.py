"""Tests for shell utilities."""
from unittest.mock import patch

from msapling_cli.shell import (
    INSTRUCTION_FILES,
    _load_hooks,
    _load_project_instructions,
    _safe_path,
    _save_hooks,
)


def test_safe_path_normal(tmp_path):
    (tmp_path / "file.py").write_text("x = 1")
    result = _safe_path(str(tmp_path), "file.py")
    assert result is not None
    assert result.name == "file.py"


def test_safe_path_blocks_traversal(tmp_path):
    result = _safe_path(str(tmp_path), "../../etc/passwd")
    assert result is None


def test_safe_path_blocks_absolute(tmp_path):
    result = _safe_path(str(tmp_path), "/etc/passwd")
    if result is not None:
        assert str(result).startswith(str(tmp_path))


def test_safe_path_subdirectory(tmp_path):
    sub = tmp_path / "src"
    sub.mkdir()
    (sub / "main.py").write_text("pass")
    result = _safe_path(str(tmp_path), "src/main.py")
    assert result is not None
    assert "src" in str(result)


def test_safe_path_blocks_prefixed_sibling(tmp_path):
    sibling = tmp_path.parent / f"{tmp_path.name}-evil"
    sibling.mkdir()
    target = sibling / "secret.py"
    target.write_text("pass")
    assert _safe_path(str(tmp_path), str(target)) is None


def test_load_project_instructions_msapling(tmp_path):
    (tmp_path / ".msapling.md").write_text("# Project Rules\nUse Python 3.10+")
    result = _load_project_instructions(str(tmp_path))
    assert "Project Rules" in result
    assert ".msapling.md" in result


def test_load_project_instructions_claude(tmp_path):
    (tmp_path / "CLAUDE.md").write_text("# Claude Instructions\nBe concise")
    result = _load_project_instructions(str(tmp_path))
    assert "Claude Instructions" in result


def test_load_project_instructions_none(tmp_path):
    result = _load_project_instructions(str(tmp_path))
    assert result == ""


def test_load_project_instructions_priority(tmp_path):
    (tmp_path / ".msapling.md").write_text("msapling rules")
    (tmp_path / "CLAUDE.md").write_text("claude rules")
    result = _load_project_instructions(str(tmp_path))
    assert "msapling rules" in result


def test_hooks_save_load(tmp_path):
    hooks_file = tmp_path / "hooks.json"
    with patch("msapling_cli.shell.HOOKS_FILE", hooks_file):
        _save_hooks({"on_session_start": ["echo hello"]})
        loaded = _load_hooks()
        assert "on_session_start" in loaded
        assert loaded["on_session_start"] == ["echo hello"]


def test_hooks_load_empty(tmp_path):
    with patch("msapling_cli.shell.HOOKS_FILE", tmp_path / "nonexistent.json"):
        loaded = _load_hooks()
        assert loaded == {}


def test_instruction_files_list():
    assert ".msapling.md" in INSTRUCTION_FILES
    assert "CLAUDE.md" in INSTRUCTION_FILES
    assert "GEMINI.md" in INSTRUCTION_FILES
    assert "AGENTS.md" in INSTRUCTION_FILES