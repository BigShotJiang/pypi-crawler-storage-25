"""Tests for CLI configuration."""
import json
import os
from pathlib import Path
from unittest.mock import patch

from msapling_cli.config import Settings, get_settings, save_settings, get_token, save_token, clear_token


def test_default_settings():
    s = Settings()
    assert s.api_url == "https://api.msapling.com"
    assert s.default_model == "google/gemini-2.0-flash-001"
    assert s.temperature == 0.7
    assert s.theme == "dark"


def test_settings_env_override():
    with patch.dict(os.environ, {"MSAPLING_API_URL": "http://localhost:9999"}):
        s = Settings()
        assert s.api_url == "http://localhost:9999"


def test_save_and_load_settings(tmp_path):
    config_file = tmp_path / "config.json"
    with patch("msapling_cli.config._CONFIG_FILE", config_file):
        s = Settings(api_url="http://test:8000", default_model="test-model")
        save_settings(s)
        assert config_file.exists()
        loaded = get_settings()
        assert loaded.api_url == "http://test:8000"
        assert loaded.default_model == "test-model"


def test_token_save_load_clear(tmp_path):
    token_file = tmp_path / "token"
    with patch("msapling_cli.config._TOKEN_FILE", token_file), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path):
        save_token("test-jwt-token-123")
        assert token_file.exists()
        assert get_token() == "test-jwt-token-123"
        clear_token()
        assert not token_file.exists()


def test_get_token_from_env():
    with patch("msapling_cli.config._TOKEN_FILE", Path("/nonexistent")), \
         patch.dict(os.environ, {"MSAPLING_TOKEN": "env-token-456"}):
        assert get_token() == "env-token-456"


def test_get_token_none_when_missing():
    with patch("msapling_cli.config._TOKEN_FILE", Path("/nonexistent")), \
         patch.dict(os.environ, {}, clear=True):
        # Remove MSAPLING_TOKEN if set
        os.environ.pop("MSAPLING_TOKEN", None)
        assert get_token() is None
