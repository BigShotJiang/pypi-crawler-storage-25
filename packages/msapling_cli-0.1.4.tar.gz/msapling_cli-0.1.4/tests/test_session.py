"""Tests for session persistence."""
import json
from pathlib import Path
from unittest.mock import patch

from msapling_cli.session import save_session, load_session, list_sessions, delete_session


def test_save_and_load(tmp_path):
    session_dir = tmp_path / "sessions"
    with patch("msapling_cli.session._SESSION_DIR", session_dir):
        save_session(
            session_id="test-123",
            messages=[{"role": "user", "content": "hello"}],
            model="gpt-4o",
            project_root="/tmp/project",
            cost_total=0.05,
            tokens_total=100,
        )
        loaded = load_session("test-123")
        assert loaded is not None
        assert loaded["id"] == "test-123"
        assert loaded["model"] == "gpt-4o"
        assert len(loaded["messages"]) == 1
        assert loaded["cost_total"] == 0.05
        assert loaded["tokens_total"] == 100


def test_load_nonexistent(tmp_path):
    with patch("msapling_cli.session._SESSION_DIR", tmp_path):
        assert load_session("nonexistent") is None


def test_list_sessions(tmp_path):
    session_dir = tmp_path / "sessions"
    with patch("msapling_cli.session._SESSION_DIR", session_dir):
        save_session("s1", [{"role": "user", "content": "first"}], "model-a")
        save_session("s2", [{"role": "user", "content": "second"}], "model-b")
        sessions = list_sessions()
        assert len(sessions) == 2
        ids = {s["id"] for s in sessions}
        assert "s1" in ids
        assert "s2" in ids


def test_delete_session(tmp_path):
    session_dir = tmp_path / "sessions"
    with patch("msapling_cli.session._SESSION_DIR", session_dir):
        save_session("to-delete", [], "m")
        assert load_session("to-delete") is not None
        assert delete_session("to-delete") is True
        assert load_session("to-delete") is None


def test_delete_nonexistent(tmp_path):
    with patch("msapling_cli.session._SESSION_DIR", tmp_path):
        assert delete_session("nope") is False


def test_corrupted_session_returns_none(tmp_path):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir(parents=True)
    (session_dir / "bad.json").write_text("NOT JSON{{{", encoding="utf-8")
    with patch("msapling_cli.session._SESSION_DIR", session_dir):
        assert load_session("bad") is None


def test_session_file_permissions(tmp_path):
    import sys
    session_dir = tmp_path / "sessions"
    with patch("msapling_cli.session._SESSION_DIR", session_dir):
        path = save_session("perm-test", [], "m")
        assert path.exists()
        if sys.platform != "win32":
            import stat
            mode = path.stat().st_mode & 0o777
            assert mode == 0o600, f"Expected 0o600, got {oct(mode)}"
