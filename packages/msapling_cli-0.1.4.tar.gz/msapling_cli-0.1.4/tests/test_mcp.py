"""Tests for MCP server tool definitions."""
from msapling_cli.mcp.server import TOOLS


def test_tool_count():
    assert len(TOOLS) >= 9, f"Expected 9+ tools, got {len(TOOLS)}"


def test_all_tools_have_required_fields():
    for tool in TOOLS:
        assert "name" in tool, f"Tool missing 'name': {tool}"
        assert "description" in tool, f"Tool missing 'description': {tool.get('name')}"
        assert "inputSchema" in tool, f"Tool missing 'inputSchema': {tool.get('name')}"


def test_all_tools_have_unique_names():
    names = [t["name"] for t in TOOLS]
    assert len(names) == len(set(names)), f"Duplicate tool names: {names}"


def test_tool_schemas_valid():
    for tool in TOOLS:
        schema = tool["inputSchema"]
        assert schema.get("type") == "object", f"Tool {tool['name']} schema not object type"
        assert "properties" in schema, f"Tool {tool['name']} missing properties"


def test_required_tools_present():
    names = {t["name"] for t in TOOLS}
    expected = {
        "msapling_chat",
        "msapling_diff",
        "msapling_apply_diff",
        "msapling_search_files",
        "msapling_read_file",
        "msapling_write_file",
        "msapling_project_context",
        "msapling_cost_check",
        "msapling_models",
        "msapling_multi_chat",
        "msapling_swarm",
    }
    missing = expected - names
    assert not missing, f"Missing tools: {missing}"


def test_chat_tool_schema():
    chat = next(t for t in TOOLS if t["name"] == "msapling_chat")
    props = chat["inputSchema"]["properties"]
    assert "prompt" in props
    required = chat["inputSchema"].get("required", [])
    assert "prompt" in required


def test_swarm_tool_schema():
    swarm = next(t for t in TOOLS if t["name"] == "msapling_swarm")
    props = swarm["inputSchema"]["properties"]
    assert "prompt" in props
    assert "models" in props
