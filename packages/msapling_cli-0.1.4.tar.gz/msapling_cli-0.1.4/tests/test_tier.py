"""Tests for tier gating logic."""
from msapling_cli.tier import PRO_COMMANDS, check_tier, is_free_model


def _free_user():
    return {"tier": "free", "is_pro": False}


def _pro_user():
    return {"tier": "monthly", "is_pro": True}


def _lifetime_user():
    return {"tier": "lifetime", "is_pro": True}


def test_free_model_flash():
    assert is_free_model("google/gemini-flash-1.5") is True


def test_free_model_haiku():
    assert is_free_model("anthropic/claude-3-haiku") is True


def test_free_model_mini():
    assert is_free_model("openai/gpt-4o-mini") is True


def test_free_model_llama():
    assert is_free_model("meta-llama/llama-3.1-8b") is True


def test_free_model_ollama():
    assert is_free_model("ollama/codellama") is True


def test_pro_model_gpt4():
    assert is_free_model("openai/gpt-4o") is False


def test_pro_model_claude():
    assert is_free_model("anthropic/claude-3.5-sonnet") is False


def test_pro_model_opus():
    assert is_free_model("anthropic/claude-3-opus") is False


def test_free_user_chat_free_model():
    ok, msg = check_tier(_free_user(), "chat", "google/gemini-flash-1.5")
    assert ok is True


def test_free_user_chat_pro_model():
    ok, msg = check_tier(_free_user(), "chat", "openai/gpt-4o")
    assert ok is False
    assert "Pro" in msg


def test_free_user_multi_blocked():
    ok, msg = check_tier(_free_user(), "multi")
    assert ok is False
    assert "Pro" in msg


def test_free_user_swarm_blocked():
    ok, msg = check_tier(_free_user(), "swarm")
    assert ok is False


def test_free_user_edit_blocked():
    ok, msg = check_tier(_free_user(), "edit")
    assert ok is False


def test_free_user_benchmark_blocked():
    ok, msg = check_tier(_free_user(), "benchmark")
    assert ok is False


def test_pro_user_all_allowed():
    for cmd in ("chat", "multi", "swarm", "edit", "benchmark"):
        ok, msg = check_tier(_pro_user(), cmd, "openai/gpt-4o")
        assert ok is True, f"Pro user blocked from {cmd}"


def test_lifetime_user_all_allowed():
    for cmd in ("chat", "multi", "swarm", "edit", "benchmark"):
        ok, msg = check_tier(_lifetime_user(), cmd, "anthropic/claude-3-opus")
        assert ok is True, f"Lifetime user blocked from {cmd}"


def test_free_user_scan_allowed():
    ok, msg = check_tier(_free_user(), "scan")
    assert ok is True


def test_free_user_context_allowed():
    ok, msg = check_tier(_free_user(), "context")
    assert ok is True


def test_pro_commands_set():
    assert "multi" in PRO_COMMANDS
    assert "swarm" in PRO_COMMANDS
    assert "edit" in PRO_COMMANDS
    assert "benchmark" in PRO_COMMANDS
    assert "chat" not in PRO_COMMANDS
