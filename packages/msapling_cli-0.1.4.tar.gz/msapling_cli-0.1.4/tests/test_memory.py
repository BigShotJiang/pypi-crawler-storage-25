"""Tests for persistent memory system."""
from pathlib import Path
from unittest.mock import patch

from msapling_cli.memory import add_memory, get_memories, list_memories, clear_memories


def test_add_and_get_project_memory(tmp_path):
    mem_file = tmp_path / ".msapling" / "memory.json"
    with patch("msapling_cli.memory._project_memory_file", return_value=mem_file):
        add_memory("Use pytest for testing", project_root=str(tmp_path), scope="project")
        result = get_memories(str(tmp_path))
        assert "pytest" in result


def test_add_global_memory(tmp_path):
    mem_file = tmp_path / "global_memory.json"
    with patch("msapling_cli.memory._GLOBAL_MEMORY_FILE", mem_file):
        add_memory("I prefer concise responses", scope="global")
        result = get_memories()
        assert "concise" in result


def test_list_memories(tmp_path):
    proj_file = tmp_path / ".msapling" / "memory.json"
    global_file = tmp_path / "global.json"
    with patch("msapling_cli.memory._project_memory_file", return_value=proj_file), \
         patch("msapling_cli.memory._GLOBAL_MEMORY_FILE", global_file):
        add_memory("global note", scope="global")
        add_memory("project note", project_root=str(tmp_path), scope="project")
        entries = list_memories(str(tmp_path))
        assert len(entries) == 2


def test_clear_memories(tmp_path):
    proj_file = tmp_path / ".msapling" / "memory.json"
    global_file = tmp_path / "global.json"
    with patch("msapling_cli.memory._project_memory_file", return_value=proj_file), \
         patch("msapling_cli.memory._GLOBAL_MEMORY_FILE", global_file):
        add_memory("to be cleared", scope="global")
        clear_memories(scope="global")
        assert list_memories() == []


def test_memory_cap(tmp_path):
    mem_file = tmp_path / "mem.json"
    with patch("msapling_cli.memory._GLOBAL_MEMORY_FILE", mem_file):
        for i in range(110):
            add_memory(f"entry {i}", scope="global")
        entries = list_memories()
        assert len(entries) <= 100


def test_empty_memories(tmp_path):
    with patch("msapling_cli.memory._GLOBAL_MEMORY_FILE", tmp_path / "nope.json"):
        result = get_memories()
        assert result == ""
