"""Tests for API client."""
import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from msapling_cli.api import MSaplingClient, _retry_request, OfflineError, APIError, _DIFF_SYSTEM_PROMPT


@pytest.fixture
def client():
    return MSaplingClient(api_url="http://test:8000", token="test-token")


def test_client_init():
    c = MSaplingClient(api_url="http://localhost:9000", token="tok123")
    assert c.api_url == "http://localhost:9000"
    assert c.token == "tok123"
    assert c.diff_mode is False


def test_client_diff_mode_off():
    c = MSaplingClient(diff_mode=False)
    assert c.diff_mode is False


def test_client_diff_mode_on():
    c = MSaplingClient(diff_mode=True)
    assert c.diff_mode is True


@pytest.mark.asyncio
async def test_retry_success_first_try():
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    result = await _retry_request(AsyncMock(return_value=mock_resp))
    assert result.status_code == 200


@pytest.mark.asyncio
async def test_retry_on_429():
    call_count = 0
    mock_429 = MagicMock()
    mock_429.status_code = 429
    mock_429.headers = {}
    mock_429.raise_for_status = MagicMock(side_effect=Exception("429"))
    mock_200 = MagicMock()
    mock_200.status_code = 200

    async def _fn():
        nonlocal call_count
        call_count += 1
        return mock_429 if call_count < 3 else mock_200

    result = await _retry_request(_fn, retries=3, backoff=0.01)
    assert result.status_code == 200
    assert call_count == 3


@pytest.mark.asyncio
async def test_retry_offline_raises():
    import httpx

    async def _fail():
        raise httpx.ConnectError("refused")

    with pytest.raises(OfflineError):
        await _retry_request(_fail, retries=2, backoff=0.01)


@pytest.mark.asyncio
async def test_health_check_offline(client):
    with patch.object(client, "_get_client") as mock:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(side_effect=Exception("offline"))
        mock.return_value = mock_client
        assert await client.health_check() is False


@pytest.mark.asyncio
async def test_diff_mode_injects_system_prompt():
    client = MSaplingClient(diff_mode=True)
    messages = [{"role": "user", "content": "hello"}]
    if client.diff_mode:
        messages = [{"role": "system", "content": _DIFF_SYSTEM_PROMPT}] + messages
    assert messages[0]["role"] == "system"
    assert "unified diff" in messages[0]["content"]
    assert messages[1]["content"] == "hello"

@pytest.mark.asyncio
async def test_projects_overview_falls_back_to_legacy_projects():
    client = MSaplingClient(api_url="http://test:8000", token="test-token")

    overview_resp = MagicMock()
    overview_resp.status_code = 405

    legacy_resp = MagicMock()
    legacy_resp.status_code = 200
    legacy_resp.raise_for_status = MagicMock()
    legacy_resp.json.return_value = {
        "projects": {
            "Default Project": {"chats": [{"id": "1"}, {"id": "2"}], "slots": []},
            "Work": {"chats": [{"id": "3"}], "slots": []},
        }
    }

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(side_effect=[overview_resp, legacy_resp])

    with patch.object(client, "_get_client", AsyncMock(return_value=mock_client)):
        overview = await client.projects_overview({"tier": "monthly", "is_pro": True})

    assert overview["project_limit"] == 10
    assert overview["project_count"] == 2
    assert overview["can_create_project"] is True
    assert overview["projects"][0]["name"] == "Default Project"
    assert overview["projects"][0]["chat_limit"] == 10
    assert overview["projects"][1]["chat_limit"] == 6


@pytest.mark.asyncio
async def test_mdrive_write_uses_scoped_path_payload():
    client = MSaplingClient(api_url="http://test:8000", token="test-token")
    response = MagicMock()
    response.status_code = 200
    response.raise_for_status = MagicMock()
    response.json.return_value = {"status": "success"}

    mock_client = AsyncMock()
    mock_client.post = AsyncMock(return_value=response)

    with patch.object(client, "_get_client", AsyncMock(return_value=mock_client)):
        result = await client.mdrive_write("Default Project", "src/app.py", "print(1)")

    assert result == {"status": "success"}
    _, kwargs = mock_client.post.call_args
    assert kwargs["json"]["path"] == "Default Project/src/app.py"
    assert kwargs["json"]["content"] == "print(1)"


@pytest.mark.asyncio
async def test_list_project_chats_uses_trailing_slash():
    client = MSaplingClient(api_url="http://test:8000", token="test-token")
    response = MagicMock()
    response.status_code = 200
    response.raise_for_status = MagicMock()
    response.json.return_value = {"projects": {"Default Project": {"chats": [{"id": "1"}]}}}

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=response)

    with patch.object(client, "_get_client", AsyncMock(return_value=mock_client)):
        chats = await client.list_project_chats("Default Project")

    assert chats == [{"id": "1"}]
    args, kwargs = mock_client.get.call_args
    assert args[0] == "/api/projects/"
    assert kwargs["params"] == {"limit": 100}
