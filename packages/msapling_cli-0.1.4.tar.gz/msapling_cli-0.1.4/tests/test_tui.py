"""Tests for TUI rendering components."""
from rich.text import Text

from msapling_cli.tui import (
    shimmer_text,
    status_bar,
    tool_header,
    tool_result_display,
    _make_inline_diff,
    _lang_from_path,
    MSAPLING_THEME,
)


def test_shimmer_text_returns_text():
    result = shimmer_text("Working", elapsed=1.5)
    assert isinstance(result, Text)
    assert "Working" in result.plain


def test_shimmer_text_shows_elapsed():
    result = shimmer_text("Thinking", elapsed=5.0)
    assert "5s" in result.plain


def test_shimmer_text_minutes():
    result = shimmer_text("Working", elapsed=90.0)
    assert "1m" in result.plain


def test_status_bar_returns_text():
    bar = status_bar(model="gpt-4o", cost=0.05, tokens=1000, mode="agent", project="myapp", tier="pro", credits=5.0)
    assert isinstance(bar, Text)
    plain = bar.plain
    assert "gpt-4o" in plain
    assert "AGENT" in plain
    assert "1,000" in plain


def test_status_bar_simple_mode():
    bar = status_bar(mode="simple")
    assert "SIMPLE" in bar.plain


def test_tool_header_read():
    panel = tool_header("read_file", {"path": "src/main.py"})
    assert panel is not None


def test_tool_header_run():
    panel = tool_header("run_command", {"command": "pytest tests/"})
    assert panel is not None


def test_tool_result_edit():
    panel = tool_result_display("edit_file", "Edited src/app.py", {"path": "src/app.py", "old_string": "x = 1", "new_string": "x = 42"})
    assert panel is not None


def test_tool_result_command():
    panel = tool_result_display("run_command", "PASSED\n3 tests")
    assert panel is not None


def test_tool_result_read_long():
    content = "\n".join(f"line {i}" for i in range(50))
    panel = tool_result_display("read_file", content, {"path": "big.py"})
    assert panel is not None


def test_make_inline_diff():
    diff = _make_inline_diff("old line", "new line", "file.py")
    assert "--- a/file.py" in diff
    assert "+++ b/file.py" in diff
    assert "- old line" in diff
    assert "+ new line" in diff


def test_lang_from_path():
    assert _lang_from_path("main.py") == "python"
    assert _lang_from_path("app.ts") == "typescript"
    assert _lang_from_path("index.js") == "javascript"
    assert _lang_from_path("README.md") == "markdown"
    assert _lang_from_path("Makefile") == "text"


def test_theme_has_required_styles():
    styles = MSAPLING_THEME.styles
    assert "ms.accent" in styles
    assert "ms.error" in styles
    assert "ms.tool" in styles
    assert "ms.file" in styles
    assert "ms.prompt" in styles
    assert "ms.diff.add" in styles
    assert "ms.diff.del" in styles
    assert "ms.status" in styles
