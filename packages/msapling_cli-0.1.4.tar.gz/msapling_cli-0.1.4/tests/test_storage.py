"""Tests for storage helpers."""
from msapling_cli.storage import _project_slug


def test_project_slug_unique_for_prefixed_paths(tmp_path):
    project_a = tmp_path / "repo"
    project_b = tmp_path / "repo-copy"
    project_a.mkdir()
    project_b.mkdir()

    assert _project_slug(str(project_a)) != _project_slug(str(project_b))
