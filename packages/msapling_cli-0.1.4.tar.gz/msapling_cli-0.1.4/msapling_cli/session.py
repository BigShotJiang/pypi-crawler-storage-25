"""Session persistence for MSapling CLI.

Saves and resumes conversation history, project context, and settings
so users can pick up where they left off.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_SESSION_DIR = Path.home() / ".msapling" / "sessions"


def _ensure_dir():
    _SESSION_DIR.mkdir(parents=True, exist_ok=True)
    try:
        _SESSION_DIR.chmod(0o700)
    except OSError:
        pass  # Windows doesn't support Unix permissions


def save_session(
    session_id: str,
    messages: List[Dict[str, str]],
    model: str,
    project_root: Optional[str] = None,
    cost_total: float = 0.0,
    tokens_total: int = 0,
    metadata: Optional[Dict[str, Any]] = None,
) -> Path:
    _ensure_dir()
    path = _SESSION_DIR / f"{session_id}.json"
    data = {
        "id": session_id,
        "messages": messages,
        "model": model,
        "project_root": project_root,
        "cost_total": cost_total,
        "tokens_total": tokens_total,
        "updated_at": time.time(),
        "metadata": metadata or {},
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass  # Windows doesn't support Unix permissions
    return path


def load_session(session_id: str) -> Optional[Dict[str, Any]]:
    _ensure_dir()
    path = _SESSION_DIR / f"{session_id}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def list_sessions(limit: int = 20) -> List[Dict[str, Any]]:
    _ensure_dir()
    sessions = []
    for p in sorted(_SESSION_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            data["_path"] = str(p)
            msg_count = len(data.get("messages", []))
            last_msg = ""
            for m in reversed(data.get("messages", [])):
                if m.get("role") == "user":
                    last_msg = (m.get("content", "") or "")[:80]
                    break
            data["_summary"] = f"{msg_count} msgs | {last_msg}"
            sessions.append(data)
        except Exception:
            continue
        if len(sessions) >= limit:
            break
    return sessions


def delete_session(session_id: str) -> bool:
    path = _SESSION_DIR / f"{session_id}.json"
    if not path.exists():
        return False
    try:
        path.chmod(0o666)  # Ensure writable before delete (Windows compat)
    except OSError:
        pass
    for _ in range(5):
        try:
            path.unlink()
            return True
        except PermissionError:
            time.sleep(0.05)
        except FileNotFoundError:
            return True
    return False