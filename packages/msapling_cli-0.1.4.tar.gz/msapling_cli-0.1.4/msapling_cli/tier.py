﻿"""Tier gating for MSapling CLI.

Free users get:
  - Local commands (scan, context, git) - always free, no server
  - chat with free models (flash, haiku, mini) - 10 msgs/day
  - models, projects, whoami, config, ls, cat
  - mcp-serve (basic tools only)

Pro users ($20/mo) get everything:
  - All models (GPT-4, Claude 3.5, etc.)
  - multi (parallel multi-model)
  - swarm (parallel + judge synthesis)
  - edit (LLM-driven file editing)
  - benchmark (compare multiple models side-by-side)
  - mcp-serve (all tools including swarm/multi)
  - Unlimited messages
"""
from __future__ import annotations

from typing import Optional, Tuple

from rich.console import Console

console = Console()

FREE_MODELS = ("flash", "haiku", "mini", "gemma", "phi", "llama", "mistral", "qwen")
PRO_COMMANDS = {"multi", "swarm", "edit", "benchmark"}


def is_free_model(model_id: str) -> bool:
    """Check if a model is available on free tier."""
    mid = (model_id or "").lower()
    if mid.startswith("ollama/"):
        return True
    return any(hint in mid for hint in FREE_MODELS)


def check_tier(user: dict, command: str, model: Optional[str] = None) -> Tuple[bool, str]:
    """Check if user's tier allows this command.

    Returns (allowed, message).
    """
    tier = str(user.get("tier", "free")).lower()
    is_pro = tier in ("pro", "monthly", "lifetime", "enterprise") or user.get("is_pro", False)

    if is_pro:
        return True, ""

    if command in PRO_COMMANDS:
        return False, (
            f"'{command}' requires a Pro subscription ($20/mo).\n"
            f"  Upgrade at: https://msapling.com/pricing\n"
            f"  Or use: msapling chat -i (free with basic models)"
        )

    if command == "chat" and model and not is_free_model(model):
        return False, (
            f"Model '{model}' requires Pro. Free tier models: Flash, Haiku, Mini, Llama, Mistral.\n"
            "  Try: msapling chat \"your prompt\" -m google/gemini-flash-1.5\n"
            "  Upgrade: https://msapling.com/pricing"
        )

    return True, ""


def require_pro(user: dict, command: str, model: Optional[str] = None) -> None:
    """Check tier and exit with message if not allowed."""
    allowed, msg = check_tier(user, command, model)
    if not allowed:
        console.print(f"[yellow]{msg}[/yellow]")
        raise SystemExit(0)


def require_auth(token: Optional[str]) -> None:
    """Check that user is authenticated."""
    if not token:
        console.print("[red]Not logged in. Run: msapling login[/red]")
        raise SystemExit(1)
