"""MSapling MCP Server - Expose MSapling features to Claude Code, Cursor, and other MCP-compatible tools."""
