"""
MSapling MCP Server

Exposes MSapling capabilities as MCP tools that Claude Code, Cursor,
Windsurf, and other MCP-compatible AI tools can call.

Tools exposed:
  - msapling_chat: Send a message to any LLM via MSapling (multi-model)
  - msapling_diff: Generate unified diff between two texts
  - msapling_apply_diff: Apply a unified diff to file content
  - msapling_search_files: Semantic search across MDrive files
  - msapling_read_file: Read a file from MDrive
  - msapling_write_file: Write a file to MDrive with versioning
  - msapling_project_context: Scan local project and build LLM context
  - msapling_cost_check: Check remaining fuel credits and usage
  - msapling_models: List available models with pricing

Usage in Claude Code:
  Add to ~/.claude/settings.json:
  {
    "mcpServers": {
      "msapling": {
        "command": "msapling",
        "args": ["mcp-serve"],
        "env": {
          "MSAPLING_TOKEN": "your-jwt-token",
          "MSAPLING_API_URL": "https://api.msapling.com"
        }
      }
    }
  }

Usage in Cursor:
  Add to .cursor/mcp.json:
  {
    "msapling": {
      "command": "msapling",
      "args": ["mcp-serve"]
    }
  }
"""
from __future__ import annotations

import asyncio
import json
import sys
from typing import Any, Dict, List, Optional

# MCP protocol: communicate over stdin/stdout with JSON-RPC 2.0


def _write_message(msg: dict) -> None:
    """Write a JSON-RPC message to stdout."""
    raw = json.dumps(msg)
    sys.stdout.write(f"Content-Length: {len(raw)}\r\n\r\n{raw}")
    sys.stdout.flush()


def _read_message() -> Optional[dict]:
    """Read a JSON-RPC message from stdin."""
    # Read headers
    headers = {}
    while True:
        line = sys.stdin.readline()
        if not line or line.strip() == "":
            break
        if ":" in line:
            key, val = line.split(":", 1)
            headers[key.strip().lower()] = val.strip()

    content_length = int(headers.get("content-length", 0))
    if content_length == 0:
        return None

    # Read exactly content_length bytes, handling partial reads
    body = ""
    remaining = content_length
    while remaining > 0:
        chunk = sys.stdin.read(remaining)
        if not chunk:
            break
        body += chunk
        remaining -= len(chunk)
    if len(body) < content_length:
        return None
    return json.loads(body)


# ─── Tool Definitions ─────────────────────────────────────────────────

TOOLS = [
    {
        "name": "msapling_chat",
        "description": "Send a message to any LLM through MSapling. Supports 200+ models via OpenRouter, OpenAI, Anthropic, Google, Ollama. Tracks costs automatically.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The message to send"},
                "model": {"type": "string", "description": "Model ID (e.g. 'google/gemini-flash-1.5', 'anthropic/claude-3.5-sonnet')", "default": "google/gemini-flash-1.5"},
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "msapling_diff",
        "description": "Generate a unified diff between old and new content. Uses MSapling's MLineage engine for validated, structured diffs.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "old_content": {"type": "string", "description": "Original file content"},
                "new_content": {"type": "string", "description": "Modified file content"},
                "filename": {"type": "string", "description": "Filename for diff headers", "default": "file"},
            },
            "required": ["old_content", "new_content"],
        },
    },
    {
        "name": "msapling_apply_diff",
        "description": "Apply a unified diff to original content. Returns the patched content. Safe: validates diff format before applying.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "original_content": {"type": "string", "description": "Original file content"},
                "diff_text": {"type": "string", "description": "Unified diff to apply"},
            },
            "required": ["original_content", "diff_text"],
        },
    },
    {
        "name": "msapling_search_files",
        "description": "Search files in an MDrive project by keyword relevance. Returns ranked results with content previews.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "MDrive project ID"},
                "query": {"type": "string", "description": "Search query"},
                "limit": {"type": "integer", "description": "Max results", "default": 5},
            },
            "required": ["project_id", "query"],
        },
    },
    {
        "name": "msapling_read_file",
        "description": "Read a file from MDrive storage. Returns file content with version info.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "MDrive project ID"},
                "file_path": {"type": "string", "description": "Path to file"},
            },
            "required": ["project_id", "file_path"],
        },
    },
    {
        "name": "msapling_write_file",
        "description": "Write a file to MDrive storage with automatic versioning and conflict detection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "MDrive project ID"},
                "file_path": {"type": "string", "description": "Path to file"},
                "content": {"type": "string", "description": "File content to write"},
            },
            "required": ["project_id", "file_path", "content"],
        },
    },
    {
        "name": "msapling_project_context",
        "description": "Scan a local directory and build an LLM-ready context block with file tree and contents. Works offline, no server needed.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Project directory path", "default": "."},
                "max_files": {"type": "integer", "description": "Maximum files to include", "default": 30},
                "max_file_size_kb": {"type": "integer", "description": "Skip files larger than this (KB)", "default": 50},
            },
        },
    },
    {
        "name": "msapling_cost_check",
        "description": "Check your MSapling account: remaining fuel credits, tier, and usage stats.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "msapling_models",
        "description": "List available LLM models with pricing info. Includes OpenRouter, OpenAI, Anthropic, Google, Ollama models.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "msapling_multi_chat",
        "description": "Send the same prompt to multiple LLM models IN PARALLEL. Returns all responses for comparison. Useful for getting diverse perspectives or benchmarking models.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The prompt to send to all models"},
                "models": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of model IDs to query in parallel",
                    "default": ["google/gemini-flash-1.5", "anthropic/claude-3-haiku", "openai/gpt-4o-mini"],
                },
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "msapling_swarm",
        "description": "Run a multi-model swarm: sends prompt to N models in parallel, then a judge model synthesizes the best answer. Returns both individual responses and the synthesis.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The task for the swarm"},
                "models": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Models to run in parallel (default: gemini, claude, gpt)",
                },
                "judge_model": {"type": "string", "description": "Model to synthesize final answer"},
            },
            "required": ["prompt"],
        },
    },
]


# ─── Tool Handlers ────────────────────────────────────────────────────

async def _handle_tool(name: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Dispatch a tool call to the appropriate handler."""
    from ..api import MSaplingClient
    from ..local import detect_project_root, build_file_tree, read_files_as_context

    if name == "msapling_project_context":
        # Local only — no server needed
        path = args.get("path", ".")
        root, info = detect_project_root(path)
        files = build_file_tree(root, max_files=args.get("max_files", 30))
        context = read_files_as_context(root, files, max_size_kb=args.get("max_file_size_kb", 50))
        return {
            "content": [{"type": "text", "text": context}],
            "metadata": {"root": root, "type": info["type"], "files": len(files), "tokens_est": len(context) // 4},
        }

    # All other tools need the API client
    client = MSaplingClient()
    try:
        if name == "msapling_chat":
            import uuid
            parts = []
            async for chunk in client.stream_chat(
                chat_id=str(uuid.uuid4()),
                prompt=args["prompt"],
                model=args.get("model", "google/gemini-flash-1.5"),
            ):
                content = chunk.get("content", "")
                if content:
                    parts.append(content)
            return {"content": [{"type": "text", "text": "".join(parts)}]}

        elif name == "msapling_diff":
            result = await client.generate_diff(
                args["old_content"], args["new_content"], args.get("filename", "file"),
            )
            diff_text = result.get("diff", result.get("unified_diff", ""))
            return {"content": [{"type": "text", "text": diff_text}]}

        elif name == "msapling_apply_diff":
            result = await client.apply_diff(args["original_content"], args["diff_text"])
            applied = result.get("applied_content", result.get("content", ""))
            return {"content": [{"type": "text", "text": applied}]}

        elif name == "msapling_search_files":
            # Direct HTTP call for search
            http_client = await client._get_client()
            resp = await http_client.post("/api/mdrive/search", json={
                "project_id": args["project_id"],
                "query": args["query"],
                "limit": args.get("limit", 5),
            })
            resp.raise_for_status()
            return {"content": [{"type": "text", "text": json.dumps(resp.json(), indent=2)}]}

        elif name == "msapling_read_file":
            content = await client.read_file(args["project_id"], args["file_path"])
            return {"content": [{"type": "text", "text": content}]}

        elif name == "msapling_write_file":
            result = await client.write_file(args["project_id"], args["file_path"], args["content"])
            return {"content": [{"type": "text", "text": json.dumps(result)}]}

        elif name == "msapling_cost_check":
            user = await client.me()
            text = (
                f"Tier: {user.get('tier', 'free')}\n"
                f"Fuel Credits: ${user.get('fuel_credits', 0):.4f}\n"
                f"Pro: {user.get('is_pro', False)}"
            )
            return {"content": [{"type": "text", "text": text}]}

        elif name == "msapling_models":
            models = await client.get_models()
            lines = [f"{m.get('id', '?')} (ctx: {m.get('context_length', '?')})" for m in models[:30]]
            return {"content": [{"type": "text", "text": "\n".join(lines)}]}

        elif name == "msapling_multi_chat":
            # Tier check: multi requires pro
            user = await client.me()
            tier = str(user.get("tier", "free")).lower()
            if tier not in ("pro", "monthly", "lifetime", "enterprise") and not user.get("is_pro"):
                return {"content": [{"type": "text", "text": "multi_chat requires Pro subscription. Upgrade at https://msapling.com/pricing"}], "isError": True}
            default_models = ["google/gemini-flash-1.5", "anthropic/claude-3-haiku", "openai/gpt-4o-mini"]
            models = args.get("models", default_models)
            results = await client.multi_chat(args["prompt"], models)
            lines = []
            for r in results:
                status = "OK" if r["status"] == "ok" else f"FAILED: {r.get('error', '')}"
                lines.append(f"### {r['model']} ({status})\n{r['response'][:2000]}")
            return {"content": [{"type": "text", "text": "\n\n---\n\n".join(lines)}]}

        elif name == "msapling_swarm":
            # Tier check: swarm requires pro
            user = await client.me()
            tier = str(user.get("tier", "free")).lower()
            if tier not in ("pro", "monthly", "lifetime", "enterprise") and not user.get("is_pro"):
                return {"content": [{"type": "text", "text": "swarm requires Pro subscription. Upgrade at https://msapling.com/pricing"}], "isError": True}
            models = args.get("models")
            judge = args.get("judge_model")
            result = await client.swarm(args["prompt"], models=models, synthesize_model=judge)
            parts = []
            for r in result["agent_responses"]:
                parts.append(f"**{r['model']}**: {r['response'][:1000]}")
            parts.append(f"\n---\n## Synthesis ({result['judge_model']})\n{result['synthesis']}")
            return {"content": [{"type": "text", "text": "\n\n".join(parts)}]}

        else:
            return {"content": [{"type": "text", "text": f"Unknown tool: {name}"}], "isError": True}

    finally:
        await client.close()


# ─── MCP Protocol Handler ─────────────────────────────────────────────

def serve():
    """Run the MCP server (stdin/stdout JSON-RPC)."""
    import sys
    sys.stderr.write("MSapling MCP Server starting...\n")

    # Single event loop for the entire server lifetime
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    try:
        while True:
            msg = _read_message()
            if msg is None:
                break

            method = msg.get("method", "")
            msg_id = msg.get("id")
            params = msg.get("params", {})

            if method == "initialize":
                _write_message({
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "msapling", "version": "0.1.0"},
                    },
                })

            elif method == "notifications/initialized":
                pass  # No response needed

            elif method == "tools/list":
                _write_message({
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {"tools": TOOLS},
                })

            elif method == "tools/call":
                tool_name = params.get("name", "")
                tool_args = params.get("arguments", {})
                try:
                    result = loop.run_until_complete(_handle_tool(tool_name, tool_args))
                    _write_message({
                        "jsonrpc": "2.0",
                        "id": msg_id,
                        "result": result,
                    })
                except Exception as e:
                    _write_message({
                        "jsonrpc": "2.0",
                        "id": msg_id,
                        "result": {
                            "content": [{"type": "text", "text": f"Error: {e}"}],
                            "isError": True,
                        },
                    })

            elif msg_id is not None:
                _write_message({
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "error": {"code": -32601, "message": f"Method not found: {method}"},
                })
    finally:
        loop.close()
