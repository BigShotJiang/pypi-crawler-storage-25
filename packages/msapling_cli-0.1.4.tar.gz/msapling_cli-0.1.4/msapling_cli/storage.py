﻿"""Local file storage helpers for MSapling CLI."""
from __future__ import annotations

import hashlib
import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


_ROOT = Path.home() / ".msapling"


def _ensure(*parts: str) -> Path:
    path = _ROOT.joinpath(*parts)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _legacy_project_slug(project_root: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]", "-", str(project_root).strip('/\\'))


def _project_slug(project_root: str) -> str:
    """Convert a project path to a collision-resistant slug."""
    resolved_root = str(Path(project_root).resolve())
    base = _legacy_project_slug(resolved_root).strip("-") or "project"
    digest = hashlib.sha256(resolved_root.lower().encode("utf-8")).hexdigest()[:10]
    return f"{base}-{digest}"


def _project_dirs(project_root: str) -> List[Path]:
    primary = _ROOT / "projects" / _project_slug(project_root)
    legacy = _ROOT / "projects" / _legacy_project_slug(project_root)
    dirs = [primary]
    if legacy != primary and legacy.exists():
        dirs.append(legacy)
    return dirs


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


# Settings

def load_settings() -> Dict[str, Any]:
    path = _ROOT / "settings.json"
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "permissions": {"allow": ["read_file", "glob_files", "grep_search", "web_search"]},
        "model": "google/gemini-flash-1.5",
        "effortLevel": "high",
    }


def save_settings(settings: Dict[str, Any]):
    _ensure()
    path = _ROOT / "settings.json"
    path.write_text(json.dumps(settings, indent=2), encoding="utf-8")


# History

def append_history(prompt: str, project: str, session_id: str):
    """Append a user prompt to global history."""
    _ensure()
    path = _ROOT / "history.jsonl"
    entry = {
        "display": prompt[:500],
        "timestamp": int(time.time() * 1000),
        "project": project,
        "sessionId": session_id,
    }
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry) + "\n")


def load_history(limit: int = 50) -> List[Dict[str, Any]]:
    path = _ROOT / "history.jsonl"
    if not path.exists():
        return []
    entries = []
    try:
        for line in path.read_text(encoding="utf-8").strip().splitlines():
            if line.strip():
                entries.append(json.loads(line))
    except Exception:
        pass
    return entries[-limit:]


# Sessions

def register_session(pid: int, session_id: str, cwd: str):
    """Register an active session."""
    _ensure("sessions")
    path = _ROOT / "sessions" / f"{pid}.json"
    path.write_text(json.dumps({
        "pid": pid,
        "sessionId": session_id,
        "cwd": cwd,
        "startedAt": int(time.time() * 1000),
        "kind": "interactive",
        "entrypoint": "cli",
    }), encoding="utf-8")


def unregister_session(pid: int):
    path = _ROOT / "sessions" / f"{pid}.json"
    if path.exists():
        path.unlink()


def list_active_sessions() -> List[Dict[str, Any]]:
    sessions_dir = _ROOT / "sessions"
    if not sessions_dir.exists():
        return []
    results = []
    for session_file in sessions_dir.glob("*.json"):
        try:
            results.append(json.loads(session_file.read_text(encoding="utf-8")))
        except Exception:
            continue
    return results


# Project conversations

def append_conversation(
    project_root: str,
    session_id: str,
    msg_type: str,
    content: str,
    parent_uuid: Optional[str] = None,
    uuid_val: Optional[str] = None,
):
    """Append a message to the conversation transcript."""
    import uuid as _uuid

    slug = _project_slug(project_root)
    _ensure("projects", slug)
    path = _ROOT / "projects" / slug / f"{session_id}.jsonl"
    entry = {
        "parentUuid": parent_uuid,
        "type": msg_type,
        "message": {"role": msg_type, "content": content[:10000]},
        "uuid": uuid_val or str(_uuid.uuid4()),
        "timestamp": _utc_timestamp(),
        "sessionId": session_id,
        "cwd": project_root,
    }
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry) + "\n")


def list_project_sessions(project_root: str) -> List[Dict[str, Any]]:
    project_dirs = [path for path in _project_dirs(project_root) if path.exists()]
    if not project_dirs:
        return []

    results = []
    seen_session_ids = set()
    files = []
    for project_dir in project_dirs:
        files.extend(project_dir.glob("*.jsonl"))

    for transcript in sorted(files, key=lambda x: x.stat().st_mtime, reverse=True):
        session_id = transcript.stem
        if session_id in seen_session_ids:
            continue
        try:
            lines = transcript.read_text(encoding="utf-8").strip().splitlines()
            first_user = ""
            for line in lines:
                entry = json.loads(line)
                if entry.get("type") == "user" and not entry.get("isMeta"):
                    first_user = entry.get("message", {}).get("content", "")[:80]
                    break
            results.append({
                "session_id": session_id,
                "messages": len(lines),
                "first_prompt": first_user,
                "modified": transcript.stat().st_mtime,
            })
            seen_session_ids.add(session_id)
        except Exception:
            continue
    return results


# Plans

def save_plan(name: str, content: str):
    _ensure("plans")
    path = _ROOT / "plans" / f"{name}.md"
    path.write_text(content, encoding="utf-8")


def list_plans() -> List[str]:
    plans_dir = _ROOT / "plans"
    if not plans_dir.exists():
        return []
    return [plan.stem for plan in plans_dir.glob("*.md")]


def load_plan(name: str) -> Optional[str]:
    path = _ROOT / "plans" / f"{name}.md"
    if path.exists():
        return path.read_text(encoding="utf-8")
    return None


# File backups

def backup_file(file_path: str, content: str, session_id: str):
    """Save a backup of a file before editing."""
    _ensure("backups", session_id)
    safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", file_path)
    backup_path = _ROOT / "backups" / session_id / f"{safe_name}.{int(time.time())}"
    backup_path.write_text(content, encoding="utf-8")
    return str(backup_path)


def list_backups(session_id: str) -> List[Dict[str, Any]]:
    backup_dir = _ROOT / "backups" / session_id
    if not backup_dir.exists():
        return []
    results = []
    for backup in sorted(backup_dir.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
        results.append({
            "name": backup.name,
            "size": backup.stat().st_size,
            "time": backup.stat().st_mtime,
        })
    return results


# Cache

def cache_set(key: str, data: Any, ttl: int = 3600):
    _ensure("cache")
    path = _ROOT / "cache" / f"{key}.json"
    payload = {"data": data, "expires": time.time() + ttl}
    path.write_text(json.dumps(payload), encoding="utf-8")


def cache_get(key: str) -> Optional[Any]:
    path = _ROOT / "cache" / f"{key}.json"
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if payload.get("expires", 0) < time.time():
            path.unlink()
            return None
        return payload.get("data")
    except Exception:
        return None
