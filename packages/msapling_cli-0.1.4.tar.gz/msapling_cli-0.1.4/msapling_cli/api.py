"""HTTP client for MSapling backend API with retry logic and offline detection."""
from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any, AsyncGenerator, Dict, List, Optional

import httpx

from .config import get_settings, get_token

DEFAULT_PROJECT_NAME = "Default Project"
PAID_PROJECT_LIMIT = 10
FREE_PROJECT_LIMIT = 3
PAID_PROJECT_CHAT_LIMIT = 6
FREE_PROJECT_CHAT_LIMIT = 2
PAID_DEFAULT_CHAT_LIMIT = 10
FREE_DEFAULT_CHAT_LIMIT = 5


def _mdrive_scoped_path(project_id: str, file_path: str = "") -> str:
    project = str(project_id or "").strip().strip("/")
    rel = str(file_path or "").strip().strip("/")
    if project and rel:
        return f"{project}/{rel}"
    return project or rel or "."


def _is_paid_user(user: Optional[Dict[str, Any]]) -> bool:
    tier = str((user or {}).get("tier", "free")).lower()
    return bool((user or {}).get("is_pro", False)) or tier in ("lifetime", "monthly", "pro", "enterprise")


def _project_limit_for_user(user: Optional[Dict[str, Any]]) -> int:
    return PAID_PROJECT_LIMIT if _is_paid_user(user) else FREE_PROJECT_LIMIT


def _chat_limit_for_project(user: Optional[Dict[str, Any]], project_name: str) -> int:
    is_default = project_name == DEFAULT_PROJECT_NAME
    if _is_paid_user(user):
        return PAID_DEFAULT_CHAT_LIMIT if is_default else PAID_PROJECT_CHAT_LIMIT
    return FREE_DEFAULT_CHAT_LIMIT if is_default else FREE_PROJECT_CHAT_LIMIT


def _normalize_legacy_projects_overview(payload: Dict[str, Any], user: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    project_map = payload.get("projects", {}) if isinstance(payload, dict) else {}
    projects = []
    for name, raw in project_map.items():
        chats = raw.get("chats", []) if isinstance(raw, dict) else []
        chat_count = len(chats)
        chat_limit = _chat_limit_for_project(user, name)
        projects.append({
            "name": name,
            "chat_count": chat_count,
            "chat_limit": chat_limit,
            "is_full": chat_count >= chat_limit,
            "chats": chats,
        })
    project_limit = _project_limit_for_user(user)
    return {
        "projects": projects,
        "project_count": len(projects),
        "project_limit": project_limit,
        "can_create_project": len(projects) < project_limit,
    }


_DIFF_SYSTEM_PROMPT = (
    "You are a code assistant running in a CLI terminal. "
    "When the user asks you to modify, edit, fix, refactor, or write code, "
    "ALWAYS respond with a unified diff (--- / +++ / @@ format). "
    "Do NOT output the full file — only the diff of what changed. "
    "For non-code questions (explanations, debugging help, general questions), "
    "respond normally but keep answers concise and terminal-friendly."
)

# Retry configuration
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1.0  # seconds
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


class APIError(Exception):
    """Raised when an API call fails after all retries."""

    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


class OfflineError(Exception):
    """Raised when the API is unreachable."""
    pass


async def _retry_request(
    fn,
    *,
    retries: int = MAX_RETRIES,
    backoff: float = RETRY_BACKOFF_BASE,
) -> httpx.Response:
    """Execute an HTTP request with exponential backoff retry on transient errors."""
    last_exc = None
    for attempt in range(retries):
        try:
            resp = await fn()
            if resp.status_code not in RETRYABLE_STATUS_CODES:
                return resp
            # Retryable status — wait and try again
            if attempt < retries - 1:
                wait = backoff * (2 ** attempt)
                if resp.status_code == 429:
                    # Respect Retry-After header if present
                    retry_after = resp.headers.get("retry-after")
                    if retry_after and retry_after.isdigit():
                        wait = max(wait, int(retry_after))
                await asyncio.sleep(wait)
            else:
                resp.raise_for_status()
        except httpx.ConnectError as e:
            last_exc = OfflineError(f"Cannot connect to API: {e}")
            if attempt < retries - 1:
                await asyncio.sleep(backoff * (2 ** attempt))
            else:
                raise last_exc
        except httpx.TimeoutException as e:
            last_exc = OfflineError(f"API request timed out: {e}")
            if attempt < retries - 1:
                await asyncio.sleep(backoff * (2 ** attempt))
            else:
                raise last_exc
        except httpx.HTTPStatusError:
            raise
    raise last_exc or APIError("Request failed after retries")


class MSaplingClient:
    """Async HTTP client for MSapling backend with retry and offline support."""

    def __init__(self, api_url: Optional[str] = None, token: Optional[str] = None, diff_mode: bool = False):
        settings = get_settings()
        self.api_url = (api_url or settings.api_url).rstrip("/")
        self.token = token or get_token()
        self.diff_mode = diff_mode  # Only inject diff system prompt when explicitly enabled
        self._client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers = {"Content-Type": "application/json"}
            cookies = {}
            if self.token:
                cookies["msaplingauth"] = self.token
            self._client = httpx.AsyncClient(
                base_url=self.api_url,
                headers=headers,
                cookies=cookies,
                timeout=60.0,
            )
            # Bootstrap CSRF token from /health endpoint
            try:
                health = await self._client.get("/health")
                csrf = health.cookies.get("msapling_csrftoken") or self._client.cookies.get("msapling_csrftoken")
                if csrf:
                    self._client.headers["X-CSRF-Token"] = csrf
            except Exception:
                pass  # Offline — CSRF will be missing but local commands still work
        return self._client

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def health_check(self) -> bool:
        """Check if API is reachable. Returns False if offline."""
        try:
            client = await self._get_client()
            resp = await asyncio.wait_for(client.get("/health"), timeout=5.0)
            return resp.status_code == 200
        except Exception:
            return False

    # --- Auth ---

    async def login(self, email: str, password: str) -> Dict[str, Any]:
        client = await self._get_client()
        # Step 1: GET /health to obtain CSRF cookie
        health_resp = await client.get("/health")
        csrf_token = health_resp.cookies.get("msapling_csrftoken") or client.cookies.get("msapling_csrftoken")
        # Step 2: POST /auth/login with CSRF header
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        if csrf_token:
            headers["X-CSRF-Token"] = csrf_token
        resp = await _retry_request(lambda: client.post(
            "/auth/login",
            data={"username": email, "password": password},
            headers=headers,
        ))
        resp.raise_for_status()
        token = resp.cookies.get("msaplingauth") or client.cookies.get("msaplingauth")
        if token:
            self.token = token
            self._client = None
        return resp.json()

    async def me(self) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/users/me"))
        resp.raise_for_status()
        return resp.json()

    # --- Chat ---

    async def stream_chat(
        self,
        chat_id: str,
        prompt: str,
        model: str,
        *,
        project_name: Optional[str] = None,
        history: Optional[list] = None,
        agent_mode: bool = False,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Stream chat response as NDJSON chunks."""
        client = await self._get_client()
        messages = list(history or [])
        if self.diff_mode:
            messages = [{"role": "system", "content": _DIFF_SYSTEM_PROMPT}] + messages
        payload = {
            "chat_id": chat_id,
            "prompt": prompt,
            "model": model,
            "project_name": project_name or "",
            "messages": messages,
            "agent_mode": agent_mode,
        }
        async with client.stream("POST", "/api/chat/message", json=payload) as resp:
            resp.raise_for_status()
            buffer = ""
            async for chunk in resp.aiter_text():
                buffer += chunk
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    line = line.strip()
                    if line:
                        try:
                            yield json.loads(line)
                        except json.JSONDecodeError:
                            continue
            if buffer.strip():
                try:
                    yield json.loads(buffer.strip())
                except json.JSONDecodeError:
                    pass

    async def get_models(self) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/chat/models"))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("models", data.get("data", []))

    # --- Projects ---

    async def list_projects(self) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/projects/"))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("projects", [])

    async def projects_overview(self, user: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Get projects with chat counts and limits. Used by CLI startup."""
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/projects/overview"))
        if resp.status_code in (404, 405):
            current_user = user
            if current_user is None:
                try:
                    current_user = await self.me()
                except Exception:
                    current_user = {}
            legacy_resp = await _retry_request(lambda: client.get("/api/projects/"))
            legacy_resp.raise_for_status()
            return _normalize_legacy_projects_overview(legacy_resp.json(), current_user)
        resp.raise_for_status()
        return resp.json()

    async def create_project(self, name: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post("/api/projects/", json={
            "project_name": name,
        }))
        resp.raise_for_status()
        return resp.json()

    async def create_chat(
        self, project_name: str, title: str = "CLI Chat",
        model: str = "", client_type: str = "cli",
    ) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post("/api/projects/chat/new", json={
            "project_name": project_name,
            "slot_label": title,
            "model": model or get_settings().default_model,
            "client_type": client_type,
        }))
        resp.raise_for_status()
        return resp.json()

    async def list_project_chats(self, project_name: str) -> List[Dict[str, Any]]:
        """Get chats for a specific project."""
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/projects/", params={
            "limit": 100,
        }))
        resp.raise_for_status()
        data = resp.json()
        projects = data if isinstance(data, dict) else {}
        if isinstance(data, dict) and "projects" in data:
            projects = data["projects"]
        proj_data = projects.get(project_name, {})
        return proj_data.get("chats", [])

    async def delete_chat(self, chat_id: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.request("DELETE", f"/api/projects/chat/{chat_id}"))
        resp.raise_for_status()
        return resp.json()

    # --- Multi-Chat / Swarm ---

    async def chat_once(self, prompt: str, model: str, history: Optional[list] = None) -> str:
        """Non-streaming single-shot chat. Returns full response text."""
        parts = []
        async for chunk in self.stream_chat(
            chat_id=str(uuid.uuid4()),
            prompt=prompt,
            model=model,
            history=history,
        ):
            content = chunk.get("content", "")
            if content:
                parts.append(content)
        return "".join(parts)

    async def multi_chat(
        self,
        prompt: str,
        models: List[str],
        history: Optional[list] = None,
    ) -> List[Dict[str, Any]]:
        """Send the same prompt to multiple models in parallel."""

        async def _single(model: str) -> Dict[str, Any]:
            try:
                text = await self.chat_once(prompt, model, history)
                return {"model": model, "response": text, "status": "ok"}
            except Exception as e:
                return {"model": model, "response": "", "status": "error", "error": str(e)}

        results = await asyncio.gather(*[_single(m) for m in models])
        return list(results)

    async def swarm(
        self,
        prompt: str,
        models: Optional[List[str]] = None,
        synthesize_model: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run swarm: multiple models answer in parallel, then a judge synthesizes."""
        default_models = [
            "google/gemini-flash-1.5",
            "anthropic/claude-3-haiku",
            "openai/gpt-4o-mini",
        ]
        use_models = models or default_models
        judge = synthesize_model or use_models[0]

        responses = await self.multi_chat(prompt, use_models)

        agent_outputs = []
        for r in responses:
            status = "OK" if r["status"] == "ok" else "FAILED"
            agent_outputs.append(f"[{r['model']} - {status}]:\n{r['response'][:2000]}")

        synthesis_prompt = (
            f"You are a synthesis judge. Multiple AI models were asked the same question.\n\n"
            f"Original question: {prompt}\n\n"
            f"Their responses:\n\n" + "\n\n---\n\n".join(agent_outputs) + "\n\n"
            f"Synthesize the best answer. Combine strengths, note disagreements, give a final answer."
        )

        synthesis = await self.chat_once(synthesis_prompt, judge)
        return {
            "agent_responses": responses,
            "synthesis": synthesis,
            "judge_model": judge,
            "models_used": use_models,
        }

    # --- MLineage ---

    async def generate_diff(self, old_content: str, new_content: str, filename: str = "file") -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post("/api/mlineage/generate-diff", json={
            "old_content": old_content,
            "new_content": new_content,
            "filename": filename,
        }))
        resp.raise_for_status()
        return resp.json()

    async def apply_diff(self, original: str, diff_text: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post("/api/mlineage/apply-diff", json={
            "original_content": original,
            "diff_text": diff_text,
        }))
        resp.raise_for_status()
        return resp.json()

    # --- MDrive ---

    async def list_files(self, project_id: str, path: str = "/") -> list:
        client = await self._get_client()
        scoped_path = _mdrive_scoped_path(project_id, "" if path in ("", "/", ".") else path)
        resp = await _retry_request(lambda: client.get("/api/mdrive/list", params={"path": scoped_path}))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("files", [])

    async def mdrive_read(self, project_id: str, file_path: str) -> str:
        client = await self._get_client()
        payload = {"path": _mdrive_scoped_path(project_id, file_path)}
        resp = await _retry_request(lambda: client.post("/api/mdrive/read", json=payload))
        resp.raise_for_status()
        return resp.json().get("content", "")

    # Keep old name as alias
    async def read_file(self, project_id: str, file_path: str) -> str:
        return await self.mdrive_read(project_id, file_path)

    async def mdrive_write(
        self, project_id: str, file_path: str, content: str,
        agent_id: str = "", change_summary: str = "",
    ) -> Dict[str, Any]:
        client = await self._get_client()
        payload: Dict[str, Any] = {
            "path": _mdrive_scoped_path(project_id, file_path),
            "content": content,
        }
        if agent_id:
            payload["agent_id"] = agent_id
        if change_summary:
            payload["change_summary"] = change_summary
        resp = await _retry_request(lambda: client.post("/api/mdrive/write", json=payload))
        resp.raise_for_status()
        return resp.json()

    # Keep old name as alias
    async def write_file(self, project_id: str, file_path: str, content: str) -> Dict[str, Any]:
        return await self.mdrive_write(project_id, file_path, content)

    async def mdrive_delete(self, project_id: str, file_path: str) -> Dict[str, Any]:
        client = await self._get_client()
        payload = {"path": _mdrive_scoped_path(project_id, file_path)}
        resp = await _retry_request(lambda: client.post("/api/mdrive/delete", json=payload))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_versions(self, project_id: str, file_path: str) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(
            f"/api/mdrive/versions/{project_id}/{file_path}",
        ))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("versions", [])

    async def mdrive_restore(self, project_id: str, file_path: str, version_id: str = "") -> Dict[str, Any]:
        client = await self._get_client()
        payload: Dict[str, Any] = {"project_id": project_id, "file_path": file_path}
        if version_id:
            payload["version_id"] = version_id
        resp = await _retry_request(lambda: client.post(
            f"/api/mdrive/restore/{project_id}/{file_path}", json=payload,
        ))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_trash(self, project_id: str) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(f"/api/mdrive/trash/{project_id}"))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("files", [])

    async def mdrive_undelete(self, project_id: str, file_path: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post(
            f"/api/mdrive/undelete/{project_id}/{file_path}",
        ))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_usage(self) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/mdrive/usage"))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_detect_conflict(
        self, project_id: str, file_path: str, base_version: str, content: str,
    ) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post(
            f"/api/mdrive/detect-conflict/{project_id}/{file_path}",
            json={"base_version": base_version, "content": content},
        ))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_search(self, project_id: str, query: str, limit: int = 10) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post("/api/mdrive/search", json={
            "project_id": project_id, "query": query, "limit": limit,
        }))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("results", [])

    # --- Chat Context / Summary ---

    async def get_chat_history(self, chat_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Fetch server-side chat history (includes Layer 0/1/2 compressed context)."""
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(
            f"/api/chat/history/{chat_id}", params={"limit": limit},
        ))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("messages", data.get("history", []))

    async def get_chat_settings(self, chat_id: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(f"/api/chat/settings/{chat_id}"))
        resp.raise_for_status()
        return resp.json()

    async def get_context_stats(self, chat_id: str) -> Dict[str, Any]:
        """Fetch summary layer stats for a chat (blocks, sagas, token estimates)."""
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(
            f"/api/chat/settings/{chat_id}/token-usage",
        ))
        resp.raise_for_status()
        return resp.json()

    # --- Load Project Context ---

    async def load_project(self, chat_id: str, project_path: str = "", patterns: Optional[list] = None) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post("/api/chat/load-project", json={
            "chat_id": chat_id,
            "project_path": project_path,
            "file_patterns": patterns or ["*.py", "*.ts", "*.tsx", "*.js", "*.md"],
            "max_files": 30,
        }))
        resp.raise_for_status()
        return resp.json()
