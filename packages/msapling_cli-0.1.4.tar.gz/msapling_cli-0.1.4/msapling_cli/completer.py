"""Tab completion for MSapling interactive shell.

Provides:
- Slash command completion: typing "/" then Tab shows matching commands
- File path completion: after /read, /edit, /write, /mention, /image, Tab completes
  file paths relative to the project root
- Model completion: after /model, Tab shows available model IDs

Uses Python's readline module on Linux/Mac. On Windows, attempts to use
pyreadline3; if unavailable, completion is silently disabled.
"""
from __future__ import annotations

import glob as globmod
import os
from pathlib import Path
from typing import List, Optional, Sequence

# ---------------------------------------------------------------------------
# All known slash commands (extracted from shell.py SLASH_HELP + handlers)
# ---------------------------------------------------------------------------
SLASH_COMMANDS: List[str] = [
    "/help",
    "/clear",
    "/compact",
    "/context",
    "/save",
    "/resume",
    "/sessions",
    "/fork",
    "/rewind",
    "/quit",
    "/exit",
    "/q",
    "/model",
    "/models",
    "/plan",
    "/agent",
    "/simple",
    "/vim",
    "/fast",
    "/effort",
    "/files",
    "/read",
    "/write",
    "/edit",
    "/grep",
    "/mention",
    "/attach",
    "/image",
    "/run",
    "/git",
    "/diff",
    "/status",
    "/multi",
    "/swarm",
    "/project",
    "/init",
    "/whoami",
    "/cost",
    "/hooks",
    "/memory",
    "/mdrive",
    "/workers",
    "/join",
    "/broadcast",
    "/collect",
    "/kill",
    "/budget",
    "/copy",
    "/export",
    "/restore",
    "/permissions",
    "/sandbox",
    "/worktree",
]

# Commands after which Tab should complete file paths
FILE_PATH_COMMANDS = {"/read", "/edit", "/write", "/mention", "/attach", "/image"}

# Directories to skip during file path completion
_SKIP_DIRS = {".git", "node_modules", "__pycache__", "venv", ".venv", "dist", "build", ".mypy_cache", ".pytest_cache"}

# Well-known model IDs for offline completion (supplemented at runtime)
DEFAULT_MODELS: List[str] = [
    "google/gemini-2.0-flash-001",
    "google/gemini-pro-1.5",
    "google/gemini-2.0-flash",
    "anthropic/claude-3-haiku",
    "anthropic/claude-3-sonnet",
    "anthropic/claude-3-opus",
    "anthropic/claude-3.5-sonnet",
    "openai/gpt-4o",
    "openai/gpt-4o-mini",
    "openai/gpt-4-turbo",
    "openai/o1-mini",
    "openai/o1-preview",
    "meta-llama/llama-3-70b-instruct",
    "meta-llama/llama-3-8b-instruct",
    "mistralai/mistral-large",
    "mistralai/mistral-small",
    "qwen/qwen-2-72b-instruct",
]


class MSaplingCompleter:
    """Readline-compatible completer for the MSapling interactive shell."""

    def __init__(
        self,
        commands: Optional[Sequence[str]] = None,
        project_root: str = ".",
        models: Optional[Sequence[str]] = None,
    ):
        self.commands = sorted(commands or SLASH_COMMANDS)
        self.project_root = os.path.abspath(project_root)
        self.models = sorted(set(models or DEFAULT_MODELS))
        self._matches: List[str] = []

    def set_models(self, models: Sequence[str]) -> None:
        """Update the model list (e.g. after fetching from the server)."""
        self.models = sorted(set(list(models) + DEFAULT_MODELS))

    # ------------------------------------------------------------------
    # Core readline interface
    # ------------------------------------------------------------------

    def complete(self, text: str, state: int) -> Optional[str]:
        """Called by readline for each successive completion.

        *text* is the current word being completed (the portion after the
        last whitespace). *state* counts up from 0; return None to signal
        end of matches.
        """
        if state == 0:
            # Compute matches fresh for state == 0
            try:
                line = _get_line_buffer()
            except Exception:
                line = text
            # If line buffer is empty (readline not fully wired), use text
            if not line:
                line = text

            self._matches = self._compute_matches(text, line)

        if state < len(self._matches):
            return self._matches[state]
        return None

    # ------------------------------------------------------------------
    # Match computation
    # ------------------------------------------------------------------

    def _compute_matches(self, text: str, full_line: str) -> List[str]:
        """Decide which completions to offer based on context."""
        stripped = full_line.lstrip()

        # ── Case 1: completing a slash command name ──────────────────
        if stripped.startswith("/") and " " not in stripped:
            return [cmd + " " for cmd in self.commands if cmd.startswith(stripped)]

        # ── Case 2: completing arguments to a command ────────────────
        parts = stripped.split(None, 1)
        if len(parts) >= 1:
            cmd = parts[0].lower()

            # File path completion
            if cmd in FILE_PATH_COMMANDS:
                partial = parts[1] if len(parts) > 1 else ""
                return self._complete_path(partial)

            # Model completion
            if cmd == "/model":
                partial = parts[1] if len(parts) > 1 else ""
                return [m + " " for m in self.models if m.startswith(partial)]

            # /effort level completion
            if cmd == "/effort":
                partial = parts[1] if len(parts) > 1 else ""
                levels = ["low", "medium", "high"]
                return [lv + " " for lv in levels if lv.startswith(partial)]

            # /hooks subcommand completion
            if cmd == "/hooks":
                partial = parts[1] if len(parts) > 1 else ""
                hook_subs = ["add", "remove", "clear"]
                return [s + " " for s in hook_subs if s.startswith(partial)]

            # /mdrive subcommand completion
            if cmd == "/mdrive":
                partial = parts[1] if len(parts) > 1 else ""
                mdrive_subs = ["status", "ls", "push", "pull"]
                return [s + " " for s in mdrive_subs if s.startswith(partial)]

            # /memory subcommand completion
            if cmd == "/memory":
                partial = parts[1] if len(parts) > 1 else ""
                mem_subs = ["add", "clear"]
                return [s + " " for s in mem_subs if s.startswith(partial)]

        return []

    # ------------------------------------------------------------------
    # File path completion
    # ------------------------------------------------------------------

    def _complete_path(self, partial: str) -> List[str]:
        """Complete a file path relative to the project root.

        Returns paths with a trailing '/' for directories so the user can
        keep drilling down without pressing Tab again.
        """
        # Normalise to forward slashes for cross-platform consistency
        partial = partial.replace("\\", "/")

        # Build the absolute prefix to glob against
        abs_prefix = os.path.join(self.project_root, partial)

        # Glob for matches
        try:
            raw = globmod.glob(abs_prefix + "*")
        except Exception:
            return []

        matches: List[str] = []
        for full_path in sorted(raw)[:60]:
            rel = os.path.relpath(full_path, self.project_root).replace("\\", "/")

            # Skip hidden / noisy directories
            parts = rel.split("/")
            if any(p in _SKIP_DIRS for p in parts):
                continue

            if os.path.isdir(full_path):
                matches.append(rel + "/")
            else:
                matches.append(rel + " ")

        return matches


# ======================================================================
# Module-level setup function (called from shell.py)
# ======================================================================

_rl = None  # Will hold the readline module if available


def _get_line_buffer() -> str:
    """Return the current readline line buffer, or empty string."""
    if _rl is not None:
        try:
            return _rl.get_line_buffer()
        except Exception:
            pass
    return ""


def setup_completion(
    project_root: str = ".",
    commands: Optional[Sequence[str]] = None,
    models: Optional[Sequence[str]] = None,
) -> Optional[MSaplingCompleter]:
    """Configure readline tab completion for the interactive shell.

    Returns the MSaplingCompleter instance (so the caller can later call
    ``completer.set_models(...)``), or ``None`` if readline is not available.

    Safe to call on any platform -- silently does nothing on Windows if
    neither readline nor pyreadline3 is installed.
    """
    global _rl

    # Try to import readline (works on Linux/Mac; may exist on Windows with pyreadline3)
    try:
        import readline as rl
        _rl = rl
    except ImportError:
        try:
            # pyreadline3 is a Windows drop-in replacement
            import pyreadline3 as rl  # type: ignore[import-untyped]
            _rl = rl
        except ImportError:
            # No readline available -- tab completion disabled silently
            return None

    completer = MSaplingCompleter(
        commands=commands,
        project_root=project_root,
        models=models,
    )

    _rl.set_completer(completer.complete)

    # Set the word delimiters. We want "/" to NOT be a delimiter so that
    # "/mod" is treated as one word (not split at "/").
    _rl.set_completer_delims(" \t\n;")

    # Enable tab completion binding.
    # On Mac with libedit, the syntax is different.
    try:
        if "libedit" in (_rl.__doc__ or ""):
            _rl.parse_and_bind("bind ^I rl_complete")
        else:
            _rl.parse_and_bind("tab: complete")
    except Exception:
        # Last resort -- try both and ignore errors
        try:
            _rl.parse_and_bind("tab: complete")
        except Exception:
            pass

    return completer


# ======================================================================
# Fuzzy model resolver
# ======================================================================

# Common model aliases — user-friendly names → OpenRouter IDs
MODEL_ALIASES: dict[str, str] = {
    # Gemini
    "gemini flash": "google/gemini-2.0-flash-001",
    "gemini 2.0 flash": "google/gemini-2.0-flash-001",
    "gemini 2 flash": "google/gemini-2.0-flash-001",
    "gemini 2.5 flash": "google/gemini-2.5-flash-preview-05-20",
    "gemini flash 1.5": "google/gemini-flash-1.5",
    "gemini 1.5 flash": "google/gemini-flash-1.5",
    "gemini pro": "google/gemini-2.0-pro-exp-02-05",
    "gemini 2.0 pro": "google/gemini-2.0-pro-exp-02-05",
    "gemini 1.5 pro": "google/gemini-pro-1.5",
    # Claude
    "claude": "anthropic/claude-3.5-sonnet",
    "claude sonnet": "anthropic/claude-3.5-sonnet",
    "claude 3.5 sonnet": "anthropic/claude-3.5-sonnet",
    "claude haiku": "anthropic/claude-3-haiku",
    "claude 3 haiku": "anthropic/claude-3-haiku",
    "claude opus": "anthropic/claude-3-opus",
    "claude 3 opus": "anthropic/claude-3-opus",
    # GPT
    "gpt4": "openai/gpt-4o",
    "gpt 4": "openai/gpt-4o",
    "gpt4o": "openai/gpt-4o",
    "gpt 4o": "openai/gpt-4o",
    "gpt4 mini": "openai/gpt-4o-mini",
    "gpt 4o mini": "openai/gpt-4o-mini",
    "gpt mini": "openai/gpt-4o-mini",
    "o1": "openai/o1",
    "o1 mini": "openai/o1-mini",
    "o3 mini": "openai/o3-mini",
    # Llama
    "llama": "meta-llama/llama-3.1-70b-instruct",
    "llama 3": "meta-llama/llama-3.1-70b-instruct",
    "llama 3.1": "meta-llama/llama-3.1-70b-instruct",
    "llama 70b": "meta-llama/llama-3.1-70b-instruct",
    "llama 8b": "meta-llama/llama-3.1-8b-instruct",
    # Mistral
    "mistral": "mistralai/mistral-large",
    "mistral large": "mistralai/mistral-large",
    "mistral small": "mistralai/mistral-small",
    # DeepSeek
    "deepseek": "deepseek/deepseek-chat",
    "deepseek coder": "deepseek/deepseek-coder",
    # Qwen
    "qwen": "qwen/qwen-2.5-72b-instruct",
}


def resolve_model(user_input: str, available_models: Optional[List[str]] = None) -> tuple[str, bool]:
    """Resolve a fuzzy model name to an exact OpenRouter model ID.

    Args:
        user_input: What the user typed (e.g. "gemini 2.0 flash", "gpt4", "claude")
        available_models: Optional list of available model IDs from the server

    Returns:
        (model_id, was_fuzzy) — the resolved ID and whether fuzzy matching was used.
    """
    raw = user_input.strip()
    if not raw:
        return "google/gemini-2.0-flash-001", True

    # 1. Exact match (user typed a full ID like "google/gemini-2.0-flash-001")
    if "/" in raw:
        return raw, False

    # 2. Alias match (case-insensitive)
    lower = raw.lower()
    if lower in MODEL_ALIASES:
        return MODEL_ALIASES[lower], True

    # 3. Partial alias match — find best match by checking if all user words appear in alias
    user_words = lower.split()
    best_alias = None
    best_score = 0
    for alias, model_id in MODEL_ALIASES.items():
        alias_words = alias.split()
        matches = sum(1 for w in user_words if any(w in aw for aw in alias_words))
        if matches > best_score:
            best_score = matches
            best_alias = model_id
    if best_alias and best_score >= len(user_words) * 0.5:
        return best_alias, True

    # 4. Search available models by substring
    if available_models:
        for mid in available_models:
            if lower in mid.lower():
                return mid, True

    # 5. Search default models
    for mid in DEFAULT_MODELS:
        if lower.replace(" ", "").replace(".", "") in mid.lower().replace("-", "").replace(".", ""):
            return mid, True

    # 6. Give up — return as-is, let the API decide
    return raw, False
