"""MSapling TUI — Terminal UI layer matching Claude Code / Codex / Gemini CLI polish.

Provides:
- Status bar at bottom (model, cost, tokens, mode, project)
- Animated working indicator with shimmer effect
- Inline colored diffs for file edits
- Styled tool execution blocks with spinners
- Themed prompt and response rendering
- Width-responsive layout
"""
from __future__ import annotations

import math
import os
import time
from typing import Any, Dict, List, Optional

from rich.console import Console, Group
from rich.columns import Columns
from rich.live import Live
from rich.markdown import Markdown
from rich.markup import escape
from rich.panel import Panel
from rich.rule import Rule
from rich.style import Style
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

# ─── MSapling Color Theme ─────────────────────────────────────────────

MSAPLING_THEME = Theme({
    "ms.accent": "bold #3b82f6",        # Blue accent
    "ms.accent2": "#22c55e",             # Green
    "ms.warn": "#f59e0b",               # Amber
    "ms.error": "bold #ef4444",          # Red
    "ms.dim": "dim #64748b",            # Slate gray
    "ms.muted": "#94a3b8",              # Light slate
    "ms.tool": "bold #a78bfa",          # Purple for tool names
    "ms.file": "bold #38bdf8",          # Sky blue for file paths
    "ms.cost": "#facc15",               # Yellow for costs
    "ms.prompt": "bold #22c55e",        # Green prompt
    "ms.user": "bold #e2e8f0",          # Bright user text
    "ms.assistant": "#e2e8f0",          # Assistant text
    "ms.diff.add": "#22c55e",           # Diff added
    "ms.diff.del": "#ef4444",           # Diff removed
    "ms.diff.hunk": "bold #3b82f6",    # Diff hunk header
    "ms.status": "#94a3b8 on #1e293b",  # Status bar
    "ms.status.key": "bold #3b82f6 on #1e293b",
})

console = Console(theme=MSAPLING_THEME)

# ─── Working Indicator ─────────────────────────────────────────────────

_SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
_SHIMMER_CHARS = "MSapling"


def shimmer_text(label: str = "Working", elapsed: float = 0.0) -> Text:
    """Create a shimmer animation effect on text (like Claude Code's 'Working' indicator)."""
    text = Text()
    frame_idx = int(elapsed * 8) % len(_SPINNER_FRAMES)
    text.append(f" {_SPINNER_FRAMES[frame_idx]} ", style="ms.accent")

    # Shimmer: sweep a bright highlight across the label
    cycle = 2.0  # seconds per sweep
    phase = (elapsed % cycle) / cycle
    for i, ch in enumerate(label):
        char_pos = i / max(len(label) - 1, 1)
        distance = abs(char_pos - phase)
        brightness = max(0, 1.0 - distance * 3)
        if brightness > 0.5:
            text.append(ch, style="bold #ffffff")
        elif brightness > 0.2:
            text.append(ch, style="#e2e8f0")
        else:
            text.append(ch, style="ms.dim")

    # Elapsed time
    if elapsed >= 60:
        mins = int(elapsed // 60)
        secs = int(elapsed % 60)
        time_str = f" {mins}m {secs}s"
    else:
        time_str = f" {elapsed:.0f}s"
    text.append(time_str, style="ms.dim")
    text.append("  press Esc to interrupt", style="ms.dim")
    return text


# ─── Status Bar ────────────────────────────────────────────────────────

def status_bar(
    model: str = "",
    cost: float = 0.0,
    tokens: int = 0,
    mode: str = "agent",
    project: str = "",
    tier: str = "free",
    credits: float = 0.0,
) -> Text:
    """Render a bottom status bar like Claude Code / Gemini CLI."""
    width = console.width or 80
    bar = Text()

    # Left side: model + mode
    model_short = model.split("/")[-1] if "/" in model else model
    bar.append(f" {model_short} ", style="ms.status.key")
    bar.append(" ", style="ms.status")

    mode_style = "bold #22c55e on #1e293b" if mode == "agent" else "bold #f59e0b on #1e293b"
    bar.append(f" {mode.upper()} ", style=mode_style)
    bar.append(" ", style="ms.status")

    # Center: project
    proj_short = project[:20] if project else "~"
    bar.append(f" {proj_short} ", style="ms.status")

    # Right side: cost + tokens + credits
    right_parts = []
    if tokens > 0:
        right_parts.append(f"{tokens:,} tok")
    if cost > 0:
        right_parts.append(f"${cost:.4f}")
    right_parts.append(f"${credits:.2f} fuel")
    right_parts.append(tier)
    right_text = "  ".join(right_parts)

    # Pad to fill width
    used = bar.cell_len + len(right_text) + 2
    padding = max(0, width - used)
    bar.append(" " * padding, style="ms.status")
    bar.append(f" {right_text} ", style="ms.status")

    return bar


# ─── Tool Execution Display ───────────────────────────────────────────

def tool_header(tool_name: str, args: Dict[str, Any]) -> Panel:
    """Render a tool execution header with icon and args summary."""
    icons = {
        "read_file": "📖",
        "write_file": "📝",
        "edit_file": "✏️",
        "run_command": "⚡",
        "glob_files": "🔍",
        "grep_search": "🔎",
        "web_search": "🌐",
    }
    icon = icons.get(tool_name, "🔧")

    # Format args concisely
    if tool_name in ("read_file", "write_file", "edit_file"):
        summary = args.get("path", "")
    elif tool_name == "run_command":
        summary = args.get("command", "")[:60]
    elif tool_name == "glob_files":
        summary = args.get("pattern", "")
    elif tool_name == "grep_search":
        summary = f"{args.get('pattern', '')} in {args.get('path', '.')}"
    elif tool_name == "web_search":
        summary = args.get("query", "")[:60]
    else:
        summary = str(args)[:60]

    title = Text()
    title.append(f" {icon} ", style="ms.tool")
    title.append(tool_name, style="ms.tool")
    title.append(f"  {summary}", style="ms.file")

    return Panel(title, border_style="ms.dim", padding=(0, 1), expand=True)


def tool_result_display(tool_name: str, result: str, args: Dict[str, Any] = None) -> Panel:
    """Render tool result with appropriate formatting."""
    args = args or {}

    # For edit_file, show a mini diff
    if tool_name == "edit_file" and "Edited" in result:
        old_s = args.get("old_string", "")
        new_s = args.get("new_string", "")
        diff_text = _make_inline_diff(old_s, new_s, args.get("path", ""))
        content = Syntax(diff_text, "diff", theme="monokai", line_numbers=False)
        return Panel(content, border_style="ms.accent2", title="[ms.accent2]edit applied[/ms.accent2]", padding=(0, 1))

    # For run_command, show as terminal output
    if tool_name == "run_command":
        lines = result.strip().split("\n")
        display = "\n".join(lines[:20])
        if len(lines) > 20:
            display += f"\n... ({len(lines) - 20} more lines)"
        return Panel(
            Text(display, style="ms.muted"),
            border_style="ms.dim",
            title="[ms.dim]output[/ms.dim]",
            padding=(0, 1),
        )

    # For read_file, show truncated with syntax highlighting
    if tool_name == "read_file" and len(result) > 200:
        path = args.get("path", "")
        ext = path.rsplit(".", 1)[-1] if "." in path else ""
        lang = {"py": "python", "ts": "typescript", "js": "javascript", "tsx": "tsx", "rs": "rust", "go": "go"}.get(ext, ext)
        lines = result.split("\n")
        preview = "\n".join(lines[:15])
        if len(lines) > 15:
            preview += f"\n... ({len(lines) - 15} more lines)"
        return Panel(
            Syntax(preview, lang or "text", theme="monokai", line_numbers=True),
            border_style="ms.dim",
            title=f"[ms.file]{path}[/ms.file]",
            padding=(0, 1),
        )

    # Default: plain text
    display = result[:500]
    if len(result) > 500:
        display += "..."
    return Panel(Text(display, style="ms.muted"), border_style="ms.dim", padding=(0, 1))


def _make_inline_diff(old_string: str, new_string: str, path: str = "") -> str:
    """Create a minimal inline diff for display."""
    lines = []
    lines.append(f"--- a/{path}")
    lines.append(f"+++ b/{path}")
    lines.append("@@ @@")
    for line in old_string.splitlines():
        lines.append(f"- {line}")
    for line in new_string.splitlines():
        lines.append(f"+ {line}")
    return "\n".join(lines)


# ─── Prompt Rendering ──────────────────────────────────────────────────

def render_prompt() -> str:
    """Return the styled prompt string for input."""
    return "[ms.prompt]❯[/ms.prompt] "


def render_user_message(text: str):
    """Display a user message in the conversation."""
    console.print()
    msg = Text()
    msg.append("❯ ", style="ms.prompt")
    msg.append(text, style="ms.user")
    console.print(msg)


def render_assistant_response(text: str):
    """Display the assistant's final response."""
    console.print()
    console.print(Markdown(text))


def render_cost_footer(tokens: int, cost: float):
    """Show a compact cost footer after a response."""
    footer = Text()
    footer.append(f"  {tokens:,} tokens", style="ms.dim")
    footer.append(f"  ${cost:.4f}", style="ms.cost")
    console.print(footer)


# ─── Session Header ───────────────────────────────────────────────────

def render_session_header(
    model: str,
    tier: str,
    credits: float,
    project: str,
    agent_mode: bool,
    instructions_loaded: bool = False,
    memories_loaded: bool = False,
):
    """Render the session startup header."""
    console.print()

    # Title
    title = Text()
    title.append("  ◆ ", style="ms.accent")
    title.append("MSapling", style="bold #ffffff")
    title.append("  v0.1.0", style="ms.dim")

    # Info lines
    info = Text()
    info.append(f"\n  Model   ", style="ms.dim")
    info.append(model, style="ms.accent")
    info.append(f"\n  Project ", style="ms.dim")
    info.append(project, style="ms.file")
    info.append(f"\n  Tier    ", style="ms.dim")
    info.append(tier, style="ms.accent2" if tier != "free" else "ms.warn")
    info.append(f"  •  ${credits:.4f} fuel", style="ms.cost")

    mode_text = "Agent mode" if agent_mode else "Simple mode"
    mode_style = "ms.accent2" if agent_mode else "ms.warn"
    info.append(f"\n  Mode    ", style="ms.dim")
    info.append(mode_text, style=mode_style)
    if agent_mode:
        info.append("  (AI reads files, writes code, runs commands)", style="ms.dim")

    # Context loaded
    if instructions_loaded or memories_loaded:
        info.append(f"\n  Context ", style="ms.dim")
        parts = []
        if instructions_loaded:
            parts.append("project instructions")
        if memories_loaded:
            parts.append("memories")
        info.append(", ".join(parts), style="ms.dim")

    console.print(Panel(
        Group(title, info),
        border_style="ms.accent",
        padding=(0, 1),
    ))

    # Hint line
    hint = Text()
    hint.append("  /help", style="ms.accent")
    hint.append(" commands  ", style="ms.dim")
    hint.append("/simple", style="ms.accent")
    hint.append(" chat-only  ", style="ms.dim")
    hint.append("Ctrl+C", style="ms.accent")
    hint.append(" exit", style="ms.dim")
    console.print(hint)
    console.print()


# ─── Approval Prompt ──────────────────────────────────────────────────

def render_approval_prompt(tool_name: str, args: Dict[str, Any]) -> str:
    """Show a styled approval prompt. Returns 'y', 'n', or 'always'."""
    icons = {
        "write_file": "📝",
        "edit_file": "✏️",
        "run_command": "⚡",
    }
    icon = icons.get(tool_name, "🔧")

    console.print()
    if tool_name == "write_file":
        path = args.get("path", "?")
        content = args.get("content", "")
        lines = content.split("\n")
        preview = "\n".join(lines[:10])
        if len(lines) > 10:
            preview += f"\n... ({len(lines) - 10} more lines)"
        console.print(Panel(
            Group(
                Text(f"Path: {path}", style="ms.file"),
                Text(),
                Syntax(preview, _lang_from_path(path), theme="monokai"),
            ),
            title=f"[ms.warn]{icon} write_file[/ms.warn]",
            border_style="ms.warn",
            padding=(0, 1),
        ))
    elif tool_name == "edit_file":
        path = args.get("path", "?")
        old_s = args.get("old_string", "")
        new_s = args.get("new_string", "")
        diff = _make_inline_diff(old_s, new_s, path)
        console.print(Panel(
            Syntax(diff, "diff", theme="monokai"),
            title=f"[ms.warn]{icon} edit_file → {path}[/ms.warn]",
            border_style="ms.warn",
            padding=(0, 1),
        ))
    elif tool_name == "run_command":
        cmd = args.get("command", "")
        console.print(Panel(
            Text(f"$ {cmd}", style="bold"),
            title=f"[ms.warn]{icon} run_command[/ms.warn]",
            border_style="ms.warn",
            padding=(0, 1),
        ))
    else:
        console.print(Panel(
            Text(f"{tool_name}: {args}", style="ms.muted"),
            title=f"[ms.warn]{icon} {tool_name}[/ms.warn]",
            border_style="ms.warn",
        ))

    while True:
        answer = console.input("[ms.warn]  Allow? [/ms.warn][ms.dim](y/n/always)[/ms.dim] ").strip().lower()
        if answer in ("y", "yes"):
            return "y"
        if answer in ("n", "no"):
            return "n"
        if answer in ("always", "a"):
            return "always"
        console.print("  [ms.dim]Enter y, n, or always[/ms.dim]")


def _lang_from_path(path: str) -> str:
    ext = path.rsplit(".", 1)[-1] if "." in path else ""
    return {"py": "python", "ts": "typescript", "js": "javascript", "tsx": "tsx", "rs": "rust", "go": "go", "rb": "ruby", "java": "java", "md": "markdown"}.get(ext, "text")


# ─── Slash Command Help ───────────────────────────────────────────────

def render_help():
    """Render styled help panel."""
    sections = [
        ("Session", [
            ("/help", "Show this help"),
            ("/clear", "Clear conversation"),
            ("/compact", "Compress context (LLM-summarized)"),
            ("/context", "Show context usage"),
            ("/save", "Save session"),
            ("/resume", "Resume previous session"),
            ("/fork", "Fork conversation"),
            ("/rewind [n]", "Undo last n messages"),
            ("/quit", "Exit"),
        ]),
        ("Model & Mode", [
            ("/model <id>", "Switch model"),
            ("/models", "List available models"),
            ("/agent", "Agent mode (AI uses tools)"),
            ("/simple", "Simple chat (no tools)"),
            ("/plan", "Plan mode (suggest only)"),
            ("/vim", "Multiline input"),
            ("/effort <lvl>", "low / medium / high"),
        ]),
        ("Files", [
            ("/files [glob]", "List files"),
            ("/read <path>", "Read file into context"),
            ("/write <path>", "Write file"),
            ("/edit <path>", "AI-edit file"),
            ("/grep <pattern>", "Search file contents"),
            ("/mention <path>", "Attach to next message"),
            ("/image <path>", "Attach image"),
        ]),
        ("Terminal & Git", [
            ("/run <cmd>", "Execute command"),
            ("/git <args>", "Git command"),
            ("/diff", "Git diff"),
            ("/status", "Git status"),
            ("/worktree", "Git worktree management"),
        ]),
        ("Multi-Model (Pro)", [
            ("/multi <prompt>", "Parallel comparison"),
            ("/swarm <prompt>", "Parallel + synthesis"),
            ("/agent spawn", "Background subagent"),
        ]),
        ("Workers (Multi-Chat)", [
            ("/workers", "List parallel workers"),
            ("/join <name|#>", "Switch to worker"),
            ("/broadcast <msg>", "Message all workers"),
            ("/collect", "Show worker outputs"),
            ("/kill <name|#>", "Remove a worker"),
            ("/budget [amt]", "Set cost ceiling"),
        ]),
        ("System", [
            ("/project", "Project info"),
            ("/init", "Generate .msapling.md"),
            ("/cost", "Session cost"),
            ("/memory", "Persistent memory"),
            ("/hooks", "Lifecycle hooks"),
            ("/mdrive", "Cloud file sync"),
            ("/whoami", "Account info"),
        ]),
    ]

    for section_name, commands in sections:
        table = Table(show_header=False, border_style="ms.dim", padding=(0, 1), expand=True)
        table.add_column("Command", style="ms.accent", min_width=20)
        table.add_column("Description", style="ms.muted")
        for cmd, desc in commands:
            table.add_row(cmd, desc)
        console.print(Panel(table, title=f"[ms.accent]{section_name}[/ms.accent]", border_style="ms.dim", padding=(0, 0)))
