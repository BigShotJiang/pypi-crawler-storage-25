"""Configuration and authentication for MSapling CLI."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings


_CONFIG_DIR = Path.home() / ".msapling"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
_TOKEN_FILE = _CONFIG_DIR / "token"


class Settings(BaseSettings):
    api_url: str = "https://api.msapling.com"
    default_model: str = "google/gemini-2.0-flash-001"
    max_tokens: int = 4096
    temperature: float = 0.7
    theme: str = "dark"

    model_config = {"env_prefix": "MSAPLING_"}


def get_settings() -> Settings:
    if _CONFIG_FILE.exists():
        try:
            data = json.loads(_CONFIG_FILE.read_text())
            return Settings(**data)
        except Exception:
            pass
    return Settings()


def save_settings(settings: Settings) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(settings.model_dump(), indent=2))


def get_token() -> Optional[str]:
    if _TOKEN_FILE.exists():
        return _TOKEN_FILE.read_text().strip()
    return os.getenv("MSAPLING_TOKEN")


def save_token(token: str) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _TOKEN_FILE.write_text(token)
    try:
        _TOKEN_FILE.chmod(0o600)
    except OSError:
        pass  # Windows doesn't support Unix permissions


def clear_token() -> None:
    if _TOKEN_FILE.exists():
        _TOKEN_FILE.unlink()
