# MSapling CLI

Multi-chat AI development environment in your terminal. Chat with 200+ LLM models, run multi-model swarms, edit code with AI-generated diffs, and manage files from one command.

## Install

```bash
pip install msapling-cli
```

From GitHub while developing:

```bash
pip install git+https://github.com/Kandy00/CLI.git
```

## Quick Start

```bash
# 1. Create a free account at https://msapling.com
# 2. Login
msapling login

# 3. Chat with any model
msapling chat "explain async/await in Python"

# 4. Interactive session
msapling chat -i

# 5. Scan your project
msapling scan .
```

## Commands

### Free (no subscription needed)

| Command | What it does |
|---------|-------------|
| `msapling chat "prompt"` | Chat with free models (Gemini Flash, Haiku, Mini, Llama, Mistral) |
| `msapling chat -i` | Interactive chat session |
| `msapling scan .` | Detect project type, language, framework, and file stats |
| `msapling context .` | Build LLM-ready context from any project (local, no server) |
| `msapling git status` | Git with rich formatting |
| `msapling models` | List available models |
| `msapling projects` | List your projects |
| `msapling whoami` | Show account info and credits |
| `msapling diff old.py new.py` | Generate a unified diff between files |

### Pro ($20/mo)

| Command | What it does |
|---------|-------------|
| `msapling chat -m gpt-4o "prompt"` | Chat with any model (GPT-4, Claude, Gemini Pro, and more) |
| `msapling multi "prompt"` | Send to multiple models in parallel and compare side-by-side |
| `msapling swarm "task"` | Run a multi-model swarm with judge synthesis |
| `msapling edit "instruction" file.py` | AI-driven file editing with diff preview |
| `msapling benchmark "prompt"` | Compare response speed, tokens, and cost across models |

### MCP Server (for Claude Code / Cursor)

```bash
msapling mcp-serve
```

Add to Claude Code (`~/.claude/settings.json`):

```json
{
  "mcpServers": {
    "msapling": {
      "command": "msapling",
      "args": ["mcp-serve"],
      "env": { "MSAPLING_TOKEN": "your-token" }
    }
  }
}
```

## Diff Mode

CLI coding responses use diff mode by default. The AI returns unified diffs instead of full files, which keeps token usage down for coding workflows.

## Links

- Website: https://msapling.com
- Pricing: https://msapling.com/pricing
- Docs: https://docs.msapling.com
- Repository: https://github.com/Kandy00/CLI
