"""Perplexity API client — async, three-tier, citation-aware.

Plan: tasks/plan-research-perplexity.md (S1).

Wraps three Perplexity Sonar models behind one client surface:
    - sonar-pro             — fast research per-query (~$0.003, 10-30s wall clock)
    - sonar-reasoning-pro   — synthesis (follows instructions, supports markdown)
    - sonar-deep-research   — long-form deliverable (~$1-3, 5-15min wall clock)

Architectural choices (locked, see plan §"Architectural choices locked"):

    1. httpx.AsyncClient (NOT requests). AgntSpace is async-first.
    2. Fail-open at every error path. Every call returns a dict; errors carry
       ``error`` + ``cost_usd: 0.0``. Callers branch on ``error`` instead of
       try/except. A broken Perplexity NEVER breaks the agent loop.
    3. Three-mode timeouts — 120s for fast / synthesis modes, 300s for deep.
    4. Retry with exponential backoff (1s, 3s, 8s) on 429 / 5xx. Network errors
       use the same schedule.
    5. Citations come back in either ``data["citations"]`` (legacy) or
       ``data["search_results"]`` (newer). Both shapes handled by
       ``_extract_citations``.
    6. ``<think>...</think>`` blocks leaked by sonar-reasoning models stripped
       before the text is returned. ``_strip_think_blocks`` is a pure helper.
    7. Cost computed via the local ``cost_for_response`` helper, which reads
       per-model pricing from ``pricing.yaml`` via the shared CostTracker
       pricing layer. Never depends on Perplexity returning a cost field.

The client itself is stateless — instantiate once at lifespan, share across
the process. Recreate when the user rotates the API key.
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from typing import Any

import httpx

log = logging.getLogger(__name__)

# ── public model identifiers ──────────────────────────────────────────────

# These are the Perplexity model IDs as documented by their API. Kept here
# because the mapping is structural (not user-tunable strategy) — the IDs are
# Perplexity's vendor convention. Adding a new tier means a new constant AND a
# matching pricing entry.
MODEL_FAST: str = "sonar-pro"  # arch:deterministic — Perplexity vendor model ID
MODEL_REASONING: str = "sonar-reasoning-pro"  # arch:deterministic — vendor ID
MODEL_DEEP: str = "sonar-deep-research"  # arch:deterministic — vendor ID

ALL_MODELS: tuple[str, ...] = (MODEL_FAST, MODEL_REASONING, MODEL_DEEP)  # arch:deterministic

# ── internal constants (deterministic infrastructure) ─────────────────────

_API_URL: str = "https://api.perplexity.ai/chat/completions"  # arch:deterministic — Perplexity OpenAI-compatible endpoint

_RETRY_DELAYS: tuple[float, ...] = (1.0, 3.0, 8.0)  # arch:deterministic — exponential backoff schedule

_RETRY_STATUS_CODES: frozenset[int] = frozenset({429, 500, 502, 503, 504})  # arch:deterministic — transient error class

# Per-mode timeout in seconds. Deep mode legitimately runs 5-15 min — the
# model walks an exhaustive citation tree before returning. 900s gives a
# 50% headroom over the documented 600s ceiling so a slow-but-still-running
# call is not killed mid-synthesis. Fast / reasoning modes stay at 120s.
_TIMEOUTS: dict[str, float] = {  # arch:deterministic — per-vendor-mode wall-clock cap
    MODEL_FAST: 120.0,
    MODEL_REASONING: 120.0,
    MODEL_DEEP: 900.0,
}

# Strip ``<think>...</think>`` blocks emitted by sonar-reasoning models.
# DOTALL so newlines inside the block don't break the match.
_THINK_RE: re.Pattern[str] = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


# ── pure helpers (testable without a network) ─────────────────────────────


def strip_think_blocks(text: str) -> str:
    """Remove ``<think>...</think>`` deliberation blocks from output text.

    sonar-reasoning models emit these. Strip before returning to the caller.
    Idempotent — calling twice produces the same result. Non-string inputs
    return empty string defensively.
    """
    if not isinstance(text, str) or not text:
        return ""
    return _THINK_RE.sub("", text).strip()


def extract_citations(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Normalize Perplexity's two citation shapes into a single list.

    Older API: ``data["citations"]`` is a list of plain URL strings.
    Newer API: ``data["search_results"]`` is a list of dicts with
    ``url`` / ``title`` / ``date`` / ``last_updated``.

    Returns a list of dicts. Each dict ALWAYS has at least ``url`` (a string,
    possibly empty). Other fields are present iff the API provided them.
    Defensive: malformed input returns ``[]`` without raising.
    """
    if not isinstance(data, dict):
        return []

    out: list[dict[str, Any]] = []

    # New shape — list of dicts.
    sr = data.get("search_results")
    if isinstance(sr, list):
        for entry in sr:
            if not isinstance(entry, dict):
                continue
            url = entry.get("url") or entry.get("link") or ""
            if not isinstance(url, str):
                url = ""
            cite: dict[str, Any] = {"url": url}
            for k in ("title", "date", "last_updated", "snippet"):
                v = entry.get(k)
                if isinstance(v, str) and v:
                    cite[k] = v
            out.append(cite)
        if out:
            return out

    # Legacy shape — list of URL strings.
    cs = data.get("citations")
    if isinstance(cs, list):
        for entry in cs:
            if isinstance(entry, str) and entry:
                out.append({"url": entry})
            elif isinstance(entry, dict):
                url = entry.get("url") or ""
                if isinstance(url, str) and url:
                    out.append({"url": url, **{k: v for k, v in entry.items() if k != "url"}})

    return out


def cost_for_response(
    model: str,
    usage: dict[str, Any] | None,
    pricing: dict[str, dict[str, float]] | None = None,
) -> float:
    """Estimate USD cost for a Perplexity response from token usage.

    Uses the shared ``cost_tracker._estimate_cost`` family — but Perplexity
    surfaces input + output tokens directly (no cache fields), so the math is
    a straight ``input_tokens / 1M * input_price + output_tokens / 1M * output_price``.

    When ``pricing`` is None we look up via the shared CostTracker pricing
    cache. Falls back to ``$0.005/1k input + $0.020/1k output`` when no
    pricing entry exists for the model — conservative overestimate so we
    never silently undercount.
    """
    if not isinstance(usage, dict):
        usage = {}

    input_tokens = int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0)
    output_tokens = int(usage.get("completion_tokens") or usage.get("output_tokens") or 0)

    # Look up pricing.
    table: dict[str, dict[str, float]] = {}
    if pricing is not None:
        table = pricing
    else:
        try:
            from agntspace.infra import cost_tracker as _ct
            table = _ct._pricing or {}  # noqa: SLF001 — module-level cache
        except Exception:
            table = {}

    # Try ``perplexity/<model>`` first, then bare ``<model>``, then default.
    entry: dict[str, float] | None = None
    for candidate in (f"perplexity/{model}", model, "_default"):
        if candidate in table and isinstance(table[candidate], dict):
            entry = table[candidate]
            break

    if entry is None:
        # Conservative final fallback — $5/1M input, $20/1M output.
        input_price = 5.0
        output_price = 20.0
    else:
        input_price = float(entry.get("input", 5.0))
        output_price = float(entry.get("output", 20.0))

    cost = (input_tokens / 1_000_000.0) * input_price + (output_tokens / 1_000_000.0) * output_price
    return round(max(cost, 0.0), 6)


# ── client ────────────────────────────────────────────────────────────────


@dataclass
class PerplexityResponse:
    """Structured response shape returned by every PerplexityClient call.

    Always populated — ``error`` is non-empty when the call failed; the rest
    of the fields fall back to safe empty values. Callers branch on
    ``error`` rather than try/except.
    """

    text: str
    citations: list[dict[str, Any]]
    model: str
    cost_usd: float
    raw: dict[str, Any]
    error: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "citations": list(self.citations),
            "model": self.model,
            "cost_usd": self.cost_usd,
            "raw": dict(self.raw),
            "error": self.error,
        }

    @property
    def ok(self) -> bool:
        return not self.error


class PerplexityClient:
    """Async Perplexity client.

    Construct once, share the instance across the process. The underlying
    httpx.AsyncClient is created lazily on first call so a server with no
    Perplexity configured pays no network or descriptor cost.
    """

    def __init__(
        self,
        api_key: str,
        *,
        timeout_overrides: dict[str, float] | None = None,
        retry_delays: tuple[float, ...] | None = None,
        api_url: str = _API_URL,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_key = (api_key or "").strip()
        self._timeouts: dict[str, float] = dict(_TIMEOUTS)
        if timeout_overrides:
            for k, v in timeout_overrides.items():
                if k in self._timeouts:
                    try:
                        self._timeouts[k] = float(v)
                    except (TypeError, ValueError):
                        pass
        self._retry_delays = retry_delays if retry_delays is not None else _RETRY_DELAYS
        self._api_url = api_url
        self._client_override = http_client
        self._client: httpx.AsyncClient | None = None

    @property
    def configured(self) -> bool:
        return bool(self._api_key)

    async def aclose(self) -> None:
        if self._client is not None and self._client_override is None:
            try:
                await self._client.aclose()
            except Exception:
                log.exception("Failed to close Perplexity httpx client")
        self._client = None

    def _get_client(self, model: str) -> httpx.AsyncClient:
        if self._client_override is not None:
            return self._client_override
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self._timeouts.get(model, 120.0))
        return self._client

    async def complete(
        self,
        prompt: str,
        *,
        model: str = MODEL_FAST,
        system: str | None = None,
        messages: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        max_tokens: int | None = None,
        extra_payload: dict[str, Any] | None = None,
    ) -> PerplexityResponse:
        """Fire a single completion against Perplexity.

        ``model`` selects the tier (``MODEL_FAST`` / ``MODEL_REASONING`` /
        ``MODEL_DEEP``). ``messages`` overrides the simple ``system`` + ``prompt``
        construction when callers need multi-turn conversation context.

        Returns a ``PerplexityResponse`` — never raises. Network / 5xx /
        429 errors retry with exponential backoff up to ``len(_retry_delays)``
        attempts, then surface as ``error="..."``.
        """
        if not self._api_key:
            return PerplexityResponse(
                text="",
                citations=[],
                model=model,
                cost_usd=0.0,
                raw={},
                error="perplexity_not_configured: no API key set",
            )

        if model not in ALL_MODELS:
            return PerplexityResponse(
                text="",
                citations=[],
                model=model,
                cost_usd=0.0,
                raw={},
                error=f"unknown_model: {model!r} not in {list(ALL_MODELS)}",
            )

        # Build messages payload.
        if messages is None:
            built: list[dict[str, Any]] = []
            if system:
                built.append({"role": "system", "content": system})
            built.append({"role": "user", "content": prompt})
            messages = built

        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            payload["max_tokens"] = int(max_tokens)
        if extra_payload:
            for k, v in extra_payload.items():
                if k not in payload:
                    payload[k] = v

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        timeout = self._timeouts.get(model, 120.0)
        client = self._get_client(model)

        last_error = ""
        attempts = max(1, len(self._retry_delays) + 1)
        for attempt in range(attempts):
            try:
                resp = await client.post(self._api_url, headers=headers, json=payload, timeout=timeout)
            except httpx.TimeoutException:
                last_error = f"timeout after {timeout}s"
            except httpx.HTTPError as exc:
                last_error = f"http_error: {type(exc).__name__}: {exc}"
            except Exception as exc:
                last_error = f"unexpected_error: {type(exc).__name__}: {exc}"
                log.exception("Perplexity unexpected error")
            else:
                if resp.status_code == 200:
                    return self._parse_success(resp, model)

                # Retryable status codes.
                if resp.status_code in _RETRY_STATUS_CODES:
                    last_error = f"http_{resp.status_code}: {self._safe_excerpt(resp)}"
                else:
                    # Non-retryable — surface immediately.
                    return PerplexityResponse(
                        text="",
                        citations=[],
                        model=model,
                        cost_usd=0.0,
                        raw={},
                        error=f"http_{resp.status_code}: {self._safe_excerpt(resp)}",
                    )

            # Schedule next retry if any delays remain.
            if attempt < len(self._retry_delays):
                try:
                    await asyncio.sleep(self._retry_delays[attempt])
                except asyncio.CancelledError:
                    raise
                except Exception:
                    pass

        return PerplexityResponse(
            text="",
            citations=[],
            model=model,
            cost_usd=0.0,
            raw={},
            error=last_error or "unknown_error",
        )

    def _parse_success(self, resp: httpx.Response, model: str) -> PerplexityResponse:
        try:
            data = resp.json()
        except Exception:
            log.exception("Perplexity 200 response failed to parse as JSON")
            return PerplexityResponse(
                text="",
                citations=[],
                model=model,
                cost_usd=0.0,
                raw={},
                error="invalid_json_response",
            )

        if not isinstance(data, dict):
            return PerplexityResponse(
                text="",
                citations=[],
                model=model,
                cost_usd=0.0,
                raw={},
                error="non_dict_response",
            )

        # Extract first choice's content.
        text = ""
        choices = data.get("choices")
        if isinstance(choices, list) and choices:
            first = choices[0]
            if isinstance(first, dict):
                msg = first.get("message")
                if isinstance(msg, dict):
                    content = msg.get("content")
                    if isinstance(content, str):
                        text = content

        text = strip_think_blocks(text)
        citations = extract_citations(data)
        usage = data.get("usage") if isinstance(data.get("usage"), dict) else {}
        cost = cost_for_response(model, usage)

        return PerplexityResponse(
            text=text,
            citations=citations,
            model=model,
            cost_usd=cost,
            raw=data,
            error="",
        )

    @staticmethod
    def _safe_excerpt(resp: httpx.Response, limit: int = 240) -> str:
        try:
            body = resp.text or ""
        except Exception:
            return ""
        body = body.replace("\n", " ").strip()
        if len(body) > limit:
            body = body[:limit] + "..."
        return body
