from importlib.resources import files

def get_pack_path():
    return files(__name__) / "ta.json"
