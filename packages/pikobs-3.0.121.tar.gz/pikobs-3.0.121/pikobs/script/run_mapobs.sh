#!/usr/bin/env bash
# ============================================================================
# run_mapobs.sh — Wrapper for pikobs.mapobs
# Two modes:
#   MODE 1 (compute):  inside PBS job or --run → loads env and runs
#   MODE 2 (submit):   login node → submits to PBS and tails the log
# Usage:
#   ./run_mapobs.sh              # auto-decides
#   ./run_mapobs.sh --run        # force compute mode
#   ./run_mapobs.sh --no-submit  # run locally without qsub
# ============================================================================
set -eo pipefail

# === USER SETTINGS ==========================================================
PATHWORK="/home/dlo001/sites8/pikobsmapsobs2/"
PATH_EXPERIENCE="/home/dlo001/sites8/Data_pikobs/monitoring/"
EXPERIENCE_NAME="experiment"
DATESTART="2026020100"
DATEEND="2026020200"
FAMILY="ch"
FLAGS_CRITERIA="all assimilee cloudy_sky clear_sky"
N_CPUS=40
WALLTIME="02:00:00"
PIKOBS_PROJECT_DIR="${PIKOBS_PROJECT_DIR:-/fs/homeu3/eccc/cmd/cmda/dlo001/pikobs_install}"
PIKOBS_SRC="${PIKOBS_SRC:-/fs/homeu3/eccc/cmd/cmda/dlo001/python/Pikobs}"
AUTO_GIT_UPDATE="${AUTO_GIT_UPDATE:-1}"
# ============================================================================

# --- Argument parsing -------------------------------------------------------
MODE="auto"
LOG_FILE_ARG=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --run)        MODE="run";   shift ;;
        --no-submit)  MODE="local"; shift ;;
        --log)        LOG_FILE_ARG="$2"; shift 2 ;;
        -h|--help) sed -n '1,/^# ====/p' "$0" | sed 's/^# \?//'; exit 0 ;;
        *) echo "Unknown argument: $1" >&2; exit 1 ;;
    esac
done

[[ "${MODE}" == "auto" ]] && { [[ -n "${PBS_JOBID:-}" ]] && MODE="run" || MODE="submit"; }


# ============================================================================
# MODE 1: COMPUTE
# ============================================================================
if [[ "${MODE}" == "run" ]] || [[ "${MODE}" == "local" ]]; then

    [[ -n "${LOG_FILE_ARG}" ]] && { mkdir -p "$(dirname "${LOG_FILE_ARG}")"; exec > >(tee -a "${LOG_FILE_ARG}") 2>&1; }

    export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1
    export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
    export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
    export HDF5_USE_FILE_LOCKING=FALSE

    echo "================================================================="
    echo " Running on : $(hostname)"
    echo " JobID      : ${PBS_JOBID:-local}"
    echo " Date       : $(date '+%Y-%m-%d %H:%M:%S')"
    echo "================================================================="

    LOADER="${PIKOBS_PROJECT_DIR}/load_pikobs.sh"
    [[ -f "${LOADER}" ]] || { echo "ERROR loader not found: ${LOADER}"; exit 1; }
    source "${LOADER}"

    [[ -d "${PIKOBS_SRC}" ]] && export PYTHONPATH="${PIKOBS_SRC}:${PYTHONPATH:-}"

    # --- Optional git update ------------------------------------------------
    if [[ "${AUTO_GIT_UPDATE}" == "1" ]] && [[ -d "${PIKOBS_SRC}/.git" ]]; then
        echo "Checking pikobs source for updates..."
        pushd "${PIKOBS_SRC}" >/dev/null
        if timeout 30 git fetch origin master -q 2>/dev/null; then
            LOCAL=$(git rev-parse HEAD)
            REMOTE=$(git rev-parse origin/master 2>/dev/null || echo "${LOCAL}")
            if [[ "${LOCAL}" != "${REMOTE}" ]]; then
                echo "  Updating to latest master..."
                timeout 30 git pull -q || echo "  WARN git pull failed; using local copy."
            else
                echo "  Already up to date."
            fi
        else
            echo "  WARN git fetch timed out; using local copy."
        fi
        popd >/dev/null
    fi

    # --- Version banner + pip update check ----------------------------------
    PY_VER=$(python -c "import platform; print(platform.python_version())" 2>/dev/null || echo "UNKNOWN")
    PIKOBS_VER=$(python -c "
import sys
try:
    import pikobs
except ImportError:
    sys.exit(1)
try:
    print(pikobs.__version__)
except AttributeError:
    try:
        from importlib.metadata import version
        print(version('pikobs'))
    except Exception:
        print('installed')
" 2>/dev/null || echo "IMPORT_ERROR")

    [[ "${PIKOBS_VER}" == "IMPORT_ERROR" ]] && { echo "ERROR cannot import pikobs."; exit 1; }

    # Check if a newer version is available on PyPI
    PIKOBS_LATEST=$(python -c "
import urllib.request, json
try:
    with urllib.request.urlopen('https://pypi.org/pypi/pikobs/json', timeout=10) as r:
        print(json.loads(r.read())['info']['version'])
except Exception:
    print('')
" 2>/dev/null || echo "")

    echo "Python : ${PY_VER}"
    echo "Pikobs : ${PIKOBS_VER}${PIKOBS_LATEST:+  (latest on PyPI: ${PIKOBS_LATEST})}"

    # Version info only (update was already offered on the login node)
    if [[ -n "${PIKOBS_LATEST}" ]] && [[ "${PIKOBS_LATEST}" != "${PIKOBS_VER}" ]]; then
        CMP=$(python -c "
from packaging.version import Version
try:
    print('older' if Version('${PIKOBS_VER}') < Version('${PIKOBS_LATEST}') else 'newer')
except Exception: print('unknown')
" 2>/dev/null || echo "unknown")
        [[ "${CMP}" == "older" ]] && echo "  ⚠️  PyPI has ${PIKOBS_LATEST} — run: pip install --upgrade pikobs"
        [[ "${CMP}" == "newer" ]] && echo "  ℹ️  Dev build (${PIKOBS_VER} > PyPI ${PIKOBS_LATEST})"
    fi

    echo "================================================================="

    LAUNCHER="/tmp/pikobs_launch_$$_$(date +%s).py"
    touch "${LAUNCHER}"
    trap 'rm -f "${LAUNCHER}"' EXIT
    cat > "${LAUNCHER}" << 'PYEOF'
import pikobs
if __name__ == "__main__":
    pikobs.mapobs.arg_call()
PYEOF

    python -u "${LAUNCHER}" \
        --path_experience "${PATH_EXPERIENCE}" \
        --experience_name "${EXPERIENCE_NAME}" \
        --pathwork        "${PATHWORK}" \
        --datestart       "${DATESTART}" \
        --dateend         "${DATEEND}" \
        --family          ${FAMILY} \
        --flags_criteria  ${FLAGS_CRITERIA} \
        --n_cpus          "${N_CPUS}"

    echo ""
    echo "================================================================="
    echo " ✅ Completed at $(date '+%Y-%m-%d %H:%M:%S')"
    echo " Output: ${PATHWORK}"
    echo "================================================================="
    exit 0
fi


# ============================================================================
# MODE 2: SUBMIT
# ============================================================================
SCRIPT_PATH="$(realpath "$0")"
mkdir -p "${PATHWORK}"

# --- Version check before submitting (we have a tty here) -------------------
_PIKOBS_LATEST=$(python -c "
import urllib.request, json
try:
    with urllib.request.urlopen('https://pypi.org/pypi/pikobs/json', timeout=10) as r:
        print(json.loads(r.read())['info']['version'])
except Exception:
    print('')
" 2>/dev/null || echo "")

if [[ -n "${_PIKOBS_LATEST}" ]]; then
    _PIKOBS_LOCAL=$(python -c "
try:
    from importlib.metadata import version; print(version('pikobs'))
except Exception:
    print('')
" 2>/dev/null || echo "")

    if [[ -n "${_PIKOBS_LOCAL}" ]]; then
        _CMP=$(python -c "
from packaging.version import Version
try:
    print('older' if Version('${_PIKOBS_LOCAL}') < Version('${_PIKOBS_LATEST}') else 'ok')
except Exception:
    print('ok')
" 2>/dev/null || echo "ok")

        if [[ "${_CMP}" == "older" ]]; then
            echo ""
            echo "  ⚠️  A newer version of pikobs is available: ${_PIKOBS_LATEST}"
            echo "  Installed: ${_PIKOBS_LOCAL}"
            read -r -p "  Update now before submitting? [y/N] " _ans
            if [[ "${_ans}" =~ ^[Yy]$ ]]; then
                echo "  Updating pikobs in env: ${PIKOBS_PROJECT_DIR}/env ..."
                # Install into the conda env that the PBS job will activate
                _PIP="${PIKOBS_PROJECT_DIR}/env/bin/pip"
                if [[ -x "${_PIP}" ]]; then
                    "${_PIP}" install --upgrade pikobs -q                         && echo "  ✅ Updated to ${_PIKOBS_LATEST} in ${PIKOBS_PROJECT_DIR}/env"
                else
                    pip install --upgrade pikobs -q                         && echo "  ✅ Updated to ${_PIKOBS_LATEST} (active env)"
                fi
            else
                echo "  Skipping update."
            fi
            echo ""
        fi
    fi
fi
# ----------------------------------------------------------------------------
LOG_FILE="${PATHWORK}/mapobs_$(date +%Y%m%d_%H%M%S).log"
touch "${LOG_FILE}"

if ! command -v qsub >/dev/null 2>&1; then
    echo "WARNING qsub not available — running locally."
    exec /usr/bin/env bash "${SCRIPT_PATH}" --run --log "${LOG_FILE}"
fi

echo "================================================================="
echo " Submitting to PBS"
echo "   log      : ${LOG_FILE}"
echo "   walltime : ${WALLTIME}  cpus: ${N_CPUS}"
echo "================================================================="

JOB_ID=$(qsub -V \
    -N pikobs_mapobs \
    -l "select=1:ncpus=${N_CPUS}:mem=185gb" \
    -l "walltime=${WALLTIME}" \
    -j oe -o "${LOG_FILE}" \
    -- "${SCRIPT_PATH}" --run --log "${LOG_FILE}")
JOB_ID=$(echo "${JOB_ID}" | awk '{print $1}')
[[ -z "${JOB_ID}" ]] && { echo "ERROR qsub returned no job ID."; exit 1; }

echo "Job: ${JOB_ID}  Log: ${LOG_FILE}"
echo "Tip: Ctrl+C to detach — job keeps running."
echo "     Re-attach: tail -f ${LOG_FILE}"

MAX_WAIT=120; waited=0
while [[ ! -s "${LOG_FILE}" ]]; do
    sleep 3; waited=$((waited+3))
    if [[ ${waited} -ge ${MAX_WAIT} ]]; then
        qstat "${JOB_ID}" >/dev/null 2>&1 || { echo "ERROR job gone, empty log. Check: qstat -xf ${JOB_ID}"; exit 1; }
        echo "Still waiting for job to start..."; waited=0
    fi
done

tail -n +1 -f "${LOG_FILE}" & TAIL_PID=$!
trap 'kill ${TAIL_PID} 2>/dev/null || true' EXIT INT TERM
while qstat "${JOB_ID}" >/dev/null 2>&1; do sleep 5; done
sleep 3; kill ${TAIL_PID} 2>/dev/null || true
trap - EXIT INT TERM

echo ""
echo "================================================================="
echo " Job ${JOB_ID} finished.  Log: ${LOG_FILE}"
echo "================================================================="
