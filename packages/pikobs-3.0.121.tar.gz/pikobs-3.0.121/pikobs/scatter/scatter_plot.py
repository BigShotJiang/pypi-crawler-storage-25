#!/usr/bin/env python3
"""Scatter plot visualization module for observational data."""

import sqlite3
import datetime
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colorbar as cbar
import matplotlib.cm as cm
import matplotlib.colors as colors
from matplotlib.ticker import FuncFormatter
from matplotlib.collections import PatchCollection
from mpl_toolkits.axes_grid1 import make_axes_locatable
import cartopy.feature

import pikobs


def project_polygon(proj, lat, lon, deltax, deltay, src_crs):
    """Transform polygon corners from lat/lon to projection coordinates."""
    points = []
    for dlon, dlat in [(-deltax, -deltay), (-deltax, deltay), (deltax, deltay), (deltax, -deltay)]:
        x, y = proj.transform_point(lon + dlon, lat + dlat, src_crs)
        points.append([x, y])
    return points


def surface_area_lat_lon(lat1, lat2, lon1, lon2):
    """Calculate surface area in km² for a lat/lon rectangle."""
    r_earth = 6371.0
    lat1 = np.clip(lat1, -90.0, 90.0)
    lat2 = np.clip(lat2, -90.0, 90.0)
    
    lat1_rad = np.deg2rad(lat1)
    lat2_rad = np.deg2rad(lat2)
    
    surf = (r_earth**2 * np.deg2rad(1.0) * np.abs(np.sin(lat2_rad) - np.sin(lat1_rad)) * np.abs(lon2 - lon1))
    return surf


def days_between(d1: str, d2: str) -> float:
    """Calculate days between two dates in format YYYYMMDDHH."""
    d1_dt = datetime.datetime.strptime(d1, "%Y%m%d%H")
    d2_dt = datetime.datetime.strptime(d2, "%Y%m%d%H")
    return (d2_dt - d1_dt).total_seconds() / (24 * 3600)


def format_scientific_adaptive(x: float) -> str:
    """Format number with adaptive decimal places based on magnitude."""
    if x == 0:
        return "0"
    abs_x = abs(x)
    if abs_x >= 10:
        return f"{int(x)}"
    elif abs_x >= 0.1:
        return f"{round(x, 2)}"
    else:
        mantissa, exp = f"{x:.1e}".split("e")
        mantissa = mantissa.split(".")[0]
        return f"{mantissa}e{int(exp)}"


WIND_TYPE_MAPPING = {
    1: "Wind derived from cloud motion observed in the infrared channel",
    2: "Wind derived from cloud motion observed in the visible channel",
    3: "Wind derived from cloud motion observed in the water vapour channel",
    4: "Wind derived from motion observed in a combination of spectral channels",
    5: "Wind derived from motion observed in the water vapour channel in clear air",
    6: "Wind derived from motion observed in the ozone channel",
    7: "Wind derived from motion observed in water vapour channel (cloud or clear air not specified)",
}


def _build_where_clause(id_stn: str, vcoord: str) -> str:
    """Build SQL WHERE clause based on id_stn and vcoord parameters."""
    if id_stn == 'join' and vcoord == 'join':
        return ""
    elif id_stn == 'join' and vcoord != 'join':
        return f" and vcoord = {vcoord}"
    elif id_stn != 'join' and vcoord == 'join':
        return f" and id_stn = '{id_stn}'"
    else:
        return f" and vcoord = {vcoord} and id_stn = '{id_stn}'"


def get_wind_type(code_or_codes):
    """Get wind type description(s) for given code(s)."""
    def map_one(c):
        try:
            return WIND_TYPE_MAPPING.get(int(c), f"Unknown code {c}")
        except (ValueError, TypeError):
            return f"Unknown code {c}"

    if isinstance(code_or_codes, (list, tuple, set)):
        return [map_one(c) for c in code_or_codes]

    if isinstance(code_or_codes, pd.Series):
        return code_or_codes.map(map_one)

    return map_one(code_or_codes)


def scatter_plot(
    mode: str,
    region: str,
    family: str,
    id_stn: str,
    datestart: str,
    dateend: str,
    Points: str,
    boxsizex: float,
    boxsizey: float,
    proj: str,
    pathwork: str,
    flag_criteria: str,
    fonction: str,
    vcoord: str,
    filesin: List[str],
    namesin: List[str],
    varno: int,
    intervales: Tuple,
    condition_sw: Optional[int] = None
) -> None:

    # Extract plot configuration
    selected_flags = pikobs.flag_criteria(flag_criteria)
    plot_type = fonction
    
    deltay = float(boxsizey) / 2.0
    deltax = float(boxsizex) / 2.0

    interval_a, interval_b = intervales
    if interval_a is None and interval_b is None:
        criteria_interval = ''
        layer_label = 'layer_all'
    else:
        criteria_interval = f' and {interval_a*100} <= vcoord <= {interval_b*100}'
        layer_label = f'Layer: {interval_a} hPa - {interval_b} hPa'

    # Database setup
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("PRAGMA TEMP_STORE=memory")
    cursor.execute(f"ATTACH DATABASE '{filesin[0]}' AS db1")

    FNAM, FNAMP, SUM_STR, SUM2_STR = pikobs.type_boxes(fonction)
    where_clause = _build_where_clause(id_stn, vcoord)

    if len(filesin) > 1:
        create_table = 'boites1'
        info_name = f"{namesin[0]} VS {namesin[1]}"
    else:
        create_table = 'AVG'
        info_name = namesin[0]

    criteria_wind = ''
    name_wind_suffix = ''
    layer_wind_desc = ''
    if condition_sw is not None:
        criteria_wind = f' and WIND_COMP_METHOD={condition_sw}'
        name_wind_suffix = f'_OBS_SWMT_{condition_sw}_'
        layer_wind_desc = get_wind_type(condition_sw)

    # Note: 'boite' and 'moyenne' are kept as they correspond to upstream DB schema
    query = f"""
        CREATE TEMPORARY TABLE {create_table} AS
        SELECT boite, lat, lon, varno, vcoord,
               SUM({SUM_STR})/SUM(CAST(N AS FLOAT)) AVG,
               SQRT(SUM({SUM2_STR})/SUM(CAST(N AS FLOAT)) - SUM({SUM_STR})/SUM(CAST(N AS FLOAT))*SUM({SUM_STR})/SUM(CAST(N AS FLOAT))) STD,
               SUM(sumstat)/SUM(CAST(N AS FLOAT)) BCORR,
               SUM(n) N
        FROM db1.moyenne
        WHERE varno={varno} {where_clause} {criteria_wind}
        GROUP BY boite, lat, lon, varno HAVING sum(n)>3;
    """
    cursor.execute(query)

    if len(filesin) > 1:
        cursor.execute(f"ATTACH DATABASE '{filesin[1]}' AS db2")
        query = f"""
            CREATE TEMPORARY TABLE boites2 AS
            SELECT boite, lat, lon, varno, vcoord,
                   SUM({SUM_STR})/SUM(CAST(N AS FLOAT)) AVG,
                   SQRT(SUM({SUM2_STR})/SUM(CAST(N AS FLOAT)) - SUM({SUM_STR})/SUM(CAST(N AS FLOAT))*SUM({SUM_STR})/SUM(CAST(N AS FLOAT))) STD,
                   SUM(sumstat)/SUM(CAST(N AS FLOAT)) BCORR,
                   SUM(n) N
            FROM db2.moyenne
            WHERE varno={varno} {where_clause} {criteria_wind}
            GROUP BY boite, lat, lon, varno HAVING sum(n)>3;
        """
        cursor.execute(query)

        query = """
            CREATE TEMPORARY TABLE AVG AS
            SELECT BOITES1.boite BOITE, BOITES1.lat LAT, BOITES1.lon LON,
                   BOITES1.vcoord VCOORD, BOITES1.varno VARNO,
                   ABS(BOITES1.avg) - ABS(BOITES2.avg) AVG,
                   COALESCE(ABS(BOITES1.avg), 8888) AVG1,
                   COALESCE(ABS(BOITES2.avg), 8888) AVG2,
                   ABS(BOITES1.std) - ABS(BOITES2.std) STD,
                   COALESCE(ABS(BOITES1.std), 8888) AS std1,
                   COALESCE(ABS(BOITES2.std), 8888) AS std2,
                   ABS(BOITES1.bcorr) - ABS(BOITES2.bcorr) BCORR,
                   COALESCE(ABS(BOITES1.bcorr), 8888) AS bcorr1,
                   COALESCE(ABS(BOITES2.bcorr), 8888) AS bcorr2,
                   BOITES1.N - BOITES2.N N,
                   COALESCE(BOITES1.N, 8888) AS N1,
                   COALESCE(BOITES2.N, 8888) AS N2
            FROM BOITES1
            JOIN BOITES2 ON BOITES1.boite = BOITES2.boite AND BOITES1.VCOORD = BOITES2.VCOORD;
        """
        cursor.execute(query)
        
    if len(filesin) > 1:
        query = "SELECT lat, lon, avg, std, N, N1, N2, avg1, avg2, std1, std2, bcorr, bcorr1, bcorr2 FROM AVG;"
    else:
        query = "SELECT lat, lon, avg, std, BCORR, N FROM AVG;"

    cursor.execute(query)
    sql_results = cursor.fetchall()

    # Extract arrays
    lat = np.array([row[0] for row in sql_results], dtype=float)
    lon = np.array([row[1] for row in sql_results], dtype=float)
    avg = np.array([row[2] for row in sql_results])
    std = np.array([row[3] for row in sql_results])
    
    if len(filesin) == 1:
        bcorr = np.array([row[4] for row in sql_results])
        n_obs_array = np.array([row[5] for row in sql_results], dtype=float)
    else:
        n_obs_array = np.array([row[4] for row in sql_results], dtype=float)
        n1_array = np.array([row[5] for row in sql_results], dtype=float)
        n2_array = np.array([row[6] for row in sql_results], dtype=float)
        avg1 = np.array([row[7] for row in sql_results], dtype=float)
        avg2 = np.array([row[8] for row in sql_results], dtype=float)
        std1 = np.array([row[9] for row in sql_results], dtype=float)
        std2 = np.array([row[10] for row in sql_results], dtype=float)
        bcorr = np.array([row[11] for row in sql_results])
        bcorr1 = np.array([row[12] for row in sql_results], dtype=float)
        bcorr2 = np.array([row[13] for row in sql_results], dtype=float)

    diff_exclusive_boxes = []
    if len(filesin) > 1:
        sql = """
            SELECT b1.boite, b1.lat, b1.lon FROM boites1 b1 LEFT JOIN boites2 b2 ON b1.boite = b2.boite WHERE b2.boite IS NULL
            UNION
            SELECT b2.boite, b2.lat, b2.lon FROM boites2 b2 LEFT JOIN boites1 b1 ON b2.boite = b1.boite WHERE b1.boite IS NULL
        """
        cursor.execute(sql)
        diff_exclusive_boxes = cursor.fetchall()
        
    # --- Clean up None values safely ---
    valid_mask = np.array([x is not None for x in avg])
    lat = lat[valid_mask]
    lon = lon[valid_mask]
    avg = avg[valid_mask].astype(float)
    std = std[valid_mask].astype(float)
    bcorr = bcorr[valid_mask].astype(float)
    n_obs_array = n_obs_array[valid_mask]
    
    if len(filesin) > 1:
        n1_array = n1_array[valid_mask]
        n2_array = n2_array[valid_mask]
        avg1 = avg1[valid_mask]
        avg2 = avg2[valid_mask]
        std1 = std1[valid_mask]
        std2 = std2[valid_mask]
        bcorr1 = bcorr1[valid_mask]
        bcorr2 = bcorr2[valid_mask]

    areas = surface_area_lat_lon(lat - deltay, lat + deltay, lon - deltax, lon + deltax)
    with np.errstate(divide='ignore', invalid='ignore'):
        density = np.where(areas > 0, n_obs_array / areas, 0)

    query = f"""
        SELECT '{datestart}', '{dateend}', '{family}', '{varno}', 
               avg(avg), avg(std), sum(N)
        FROM AVG;
    """
    cursor.execute(query)
    agg_results = cursor.fetchone()
    mu_val = agg_results[4]
    sigma_val = agg_results[5]
    total_obs = agg_results[6]

    conn.close()
    
    if sigma_val is not None:
        sigma_val = np.round(sigma_val, 3)
        period_str = f'From {datestart} To {dateend}'
        n_days = max(1/4, days_between(datestart, dateend))
        variable_name, units, vcoord_type = pikobs.type_varno(varno)
        
        if vcoord == 'join':
            var_name_label = f"{variable_name} {units} \n id_stn:{id_stn} vcoord/channel:{(vcoord)} {layer_label} \n {layer_wind_desc}"
        else:
            var_name_label = f"{variable_name} {units} \n id_stn:{id_stn} vcoord/channel:{int(vcoord)} {layer_label} "
        
        plt.close('all')
        fig = plt.figure(figsize=(10, 10))
        plt.rcParams['axes.linewidth'] = 1
        n_intervals = 10
        
        # --- Value ranges and color logic ---
        with np.errstate(divide='ignore', invalid='ignore'):
            if plot_type in ['dens', 'dens%']:
                if len(filesin) > 1:
                    den1 = np.where(areas > 0, n1_array / areas, 0)
                    den2 = np.where(areas > 0, n2_array / areas, 0)
                    plot_values = np.where(den1 != 0, (den2 - den1) * 100 / den1, 0)
                    vmin, vmax = -100, 100
                else:
                    plot_values = density / n_days 
                    vmin, vmax = np.nanmin(plot_values), np.nanmax(plot_values)
                    
                cmap_base = cm.get_cmap('PuRd', lut=n_intervals)

            elif plot_type in ['nobs', 'NOBSHDR']:
                if len(filesin) > 1:
                    plot_values = np.where(n1_array != 0, ((n2_array / n_days) - (n1_array / n_days)) * 100 / (n1_array / n_days), 0)
                    vmin, vmax = -100, 100
                else:
                    plot_values = n_obs_array / n_days
                    vmin, vmax = np.nanmin(plot_values), np.nanmax(plot_values)

                if len(filesin) == 1 and vmin > 0.0:
                    n_intervals = 11
                    cmap_base = cm.get_cmap('PuRd', lut=n_intervals)
                    vmin, vmax = vmin + 1, vmax
                else:
                    max_abs = max(abs(vmin), abs(vmax))
                    cmap_base = cm.get_cmap('RdYlBu_r', lut=n_intervals)
                    vmin, vmax = -max_abs, max_abs

            elif plot_type == 'obs':
                if len(filesin) > 1:
                    plot_values = np.where(avg1 != 0, (abs(avg2) - abs(avg1)) * 100 / abs(avg1), 0)
                    vmin, vmax = -100, 100
                else:
                    plot_values = avg
                    vmin, vmax = np.nanmin(plot_values), np.nanmax(plot_values)
                cmap_base = cm.get_cmap('RdYlBu_r', lut=n_intervals)  

            elif plot_type == 'bcorr':
                if len(filesin) > 1:
                    plot_values = np.where(bcorr1 != 0, (abs(bcorr2) - abs(bcorr1)) * 100 / abs(bcorr1), 0)
                    vmin, vmax = -100, 100
                else:
                    plot_values = bcorr
                    vmin, vmax = np.nanmin(plot_values), np.nanmax(plot_values)
                cmap_base = cm.get_cmap('RdYlBu_r', lut=n_intervals)

            elif plot_type in ['omp', 'oma', 'stdomp', 'stdoma']:
                n_colors = 10
                if len(filesin) > 1:
                    if plot_type in ['omp', 'oma']: 
                        plot_values = np.where(avg1 != 0, (abs(avg2) - abs(avg1)) * 100 / abs(avg1), 0)
                    else:
                        plot_values = np.where(std1 != 0, (abs(std2) - abs(std1)) * 100 / abs(std1), 0)
                    vmin, vmax = -100, 100
                else:
                    if plot_type in ['omp', 'oma']: 
                        plot_values = avg
                        vmax = np.nanmax(np.abs(plot_values))
                        vmin = -vmax
                        cmap_base = cm.get_cmap('seismic', lut=n_colors)
                    else:
                        plot_values = std
                        vmin = np.nanmin(plot_values)
                        vmax = np.nanmax(plot_values)
                        cmap_base = cm.get_cmap('PuRd', lut=n_intervals)

        if len(filesin) > 1:
            extend_color = 'both'
            vmin, vmax = -100, 100
            boundaries = np.array(list(range(vmin, -5, 20)) + [-5, 5] + list(range(20, vmax+10, 20))) 
            y_centers = boundaries

            neg_colors = [cm.RdYlBu_r(x) for x in np.linspace(0.08, 0.40, sum(boundaries < -2))]
            white_color = (1.0, 1.0, 1.0, 1.0)
            pos_colors = [cm.RdYlBu_r(x) for x in np.linspace(0.60, 0.92, sum(boundaries > 2))]
            
            color_list = neg_colors + [white_color] + pos_colors
            cmap = colors.ListedColormap(color_list)
            cmap.set_under('#0235ad')
            cmap.set_over('#b30000')
            norm = colors.BoundaryNorm(boundaries, cmap.N)
            ticks = list(boundaries[boundaries < -5]) + [-5, 5] + list(boundaries[boundaries > 5])
        else:
            boundaries = np.linspace(vmin, vmax, n_intervals + 1)
            y_centers = boundaries[:-1] + (boundaries[1] - boundaries[0]) / 2
            cmap = cmap_base
            norm = cm.colors.Normalize(vmin=vmin, vmax=vmax)
            extend_color = None
            ticks = boundaries

        mapper = cm.ScalarMappable(norm=norm, cmap=cmap)
        rgba_colors = [mapper.to_rgba(x) for x in y_centers]
        color_indices = np.digitize(plot_values, boundaries) - 1
        color_indices = np.clip(color_indices, 0, len(rgba_colors) - 1)
        
        # --- Draw Map ---
        ax, fig, lat_pos, proj_obj, pc = pikobs.type_projection(proj)
        on_map_obs, on_map_obs2 = 0, 0

        patches_list = []
        facecolors_list = []

        for i in range(len(n_obs_array)):
            point = proj_obj.transform_point(lon[i], lat[i], src_crs=pc)
            fig_coords = ax.transData.transform(point)
            ax_coords = ax.transAxes.inverted().transform(fig_coords)
            xx, yy = ax_coords
            
            if -0.01 <= xx <= 1.01 and -0.01 <= yy <= 1.01:
                on_map_obs += n_obs_array[i]
                if len(filesin) > 1:
                    on_map_obs2 += n1_array[i]
                
                if Points == 'ON':
                    plt.text(point[0], point[1], int(np.floor(n_obs_array[i])), color="k", 
                             fontsize=17, zorder=5, ha='center', va='center', weight='bold')
                else: 
                    if boxsizex >= 10:
                        plt.text(point[0], point[1], format_scientific_adaptive(plot_values[i]), color="b", 
                                 fontsize=5, zorder=5, ha='center', va='center', weight='bold')
                  
                    poly_points = project_polygon(proj_obj, lat[i], lon[i], deltax, deltay, pc)
                    val = plot_values[i]

                    if len(filesin) > 1:
                        if val < -100:
                            col = '#0235ad'     
                        elif val > 100:
                            col = '#b30000'         
                        else:
                            col = rgba_colors[color_indices[i]]
                    else:
                        col = rgba_colors[color_indices[i]]
                    
                    poly = plt.Polygon(poly_points)
                    patches_list.append(poly)
                    facecolors_list.append(col)
                    
        # Render polygons efficiently with transparency so continents show through
        if patches_list:
            collection = PatchCollection(patches_list, facecolor=facecolors_list, edgecolor='none', alpha=0.85, zorder=4)
            ax.add_collection(collection)

        if len(filesin) > 1 and diff_exclusive_boxes:
            diff_patches = []
            for box_id, latn, lonn in diff_exclusive_boxes:
                poly_points = project_polygon(proj_obj, latn, lonn, deltax, deltay, pc)
                diff_patches.append(plt.Polygon(poly_points))
            
            diff_coll = PatchCollection(diff_patches, facecolor=(0,0,0,1), edgecolor='k', linewidth=0.8, alpha=1.0, zorder=5)
            ax.add_collection(diff_coll)

        # Cartopy features using explicit NaturalEarth resolutions
        map_res = '50m'
        land_feat = cartopy.feature.NaturalEarthFeature('physical', 'land', map_res, edgecolor='#C0C0C0', facecolor='#f4f3f0')
        ocean_feat = cartopy.feature.NaturalEarthFeature('physical', 'ocean', map_res, edgecolor='#7f7f7f', facecolor='#e0f3f8')
        borders_feat = cartopy.feature.NaturalEarthFeature('cultural', 'admin_0_boundary_lines_land', map_res, edgecolor='#555555', facecolor='none', linewidth=0.5)
        coastline_feat = cartopy.feature.NaturalEarthFeature('physical', 'coastline', map_res, edgecolor='#333333', facecolor='none', linewidth=0.8)

        ax.add_feature(land_feat, zorder=1)
        ax.add_feature(ocean_feat, zorder=0)
        ax.add_feature(coastline_feat, zorder=10)
        ax.add_feature(borders_feat, zorder=10)

        ax.gridlines(color='gray', linestyle='--', xlocs=range(-180, 190, 20), ylocs=lat_pos, draw_labels=False, zorder=2, alpha=0.4)
        
        divider = make_axes_locatable(ax)
        ax_cbar = divider.append_axes("right", size="5%", pad=0.05, axes_class=plt.Axes)
        
        cb = cbar.ColorbarBase(
            ax_cbar, cmap=cmap, norm=norm, orientation='vertical', drawedges=True,
            extend=extend_color, ticks=ticks, boundaries=boundaries, alpha=1.0
        )

        def scifmt(x, pos):
            return f'{x:.1e}'
        
        if plot_type == 'dens' and len(filesin) == 1:
            cb.ax.yaxis.set_major_formatter(FuncFormatter(scifmt))
        
        y_labels = {
            'dens': ('Increase in sum(dens)/days relative to {namesin[0]} [%]', 'Density [obs/km²]/day'),
            'nobs': ('Increase in sum(obs)/days relative to {namesin[0]} [%]', 'Total Obs/day'),
            'omp': ('Improvement in OMP relative to {namesin[0]} [%]', 'OMP {units}'),
            'oma': ('Improvement in OMA relative to {namesin[0]} [%]', 'OMA {units}'),
            'obs': ('Improvement in {variable_name} relative to {namesin[0]} [%]', '{variable_name} {units}'),
            'bcorr': ('Increase in Bias Correction relative to {namesin[0]} [%]', 'Bias Correction {units}'),
            'stdomp': ('Increase in STD(OMP) relative to {namesin[0]} [%]', 'STD(OMP) {units}'),
            'stdoma': ('Increase in STD(OMA) relative to {namesin[0]} [%]', 'STD(OMA) {units}')
        }

        if plot_type in y_labels:
            label_tmpl = y_labels[plot_type][0] if len(filesin) > 1 else y_labels[plot_type][1]
            cb.ax.set_ylabel(label_tmpl.format(namesin=namesin, variable_name=variable_name, units=units), 
                             fontsize=15 if plot_type == 'obs' else 18, rotation=90, labelpad=20)

        # Main Titles and Alignment
        if len(filesin) == 1:
            ax.set_title(namesin[0], loc='left', fontsize=12, color='blue', pad=25)
        else:
            ax.set_title(f"Diff {namesin[0]}", loc='left', fontsize=12, color='blue', pad=25)
            ax.set_title(f"- {namesin[1]}", loc='center', fontsize=12, color='red', pad=25)
            
        ax.text(0.00, 1.02, period_str, fontsize=12, color='#3366FF', transform=ax.transAxes)
        ax.text(0.35, 1.05, var_name_label, fontsize=12, color='black', transform=ax.transAxes, fontweight='bold')
        
        ax.text(0.5, -0.08, 'Longitude', transform=ax.transAxes, ha='center', va='top', fontsize=14)
        ax.text(-0.06, 0.5, 'Latitude', transform=ax.transAxes, ha='center', va='bottom', rotation='vertical', fontsize=14)
        
        # Stats Box
        props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
        if len(filesin) < 2:
            if plot_type in ['dens', 'nobs']:
                textstr = f'Nobs={int(on_map_obs)} (for {n_days:.2f} days)'
            else:
                textstr = f'$\\bar{{\\mu}}={mu_val:.3f}$ $\\bar{{\\sigma}}={sigma_val:.3f}$ \nNobs={int(on_map_obs)} (for {n_days:.2f} days)'
            ax.text(0.85, 1.10, textstr, transform=ax.transAxes, fontsize=12, verticalalignment='top', bbox=props)
        else:
            textstr = f'Diff Nobs={int(on_map_obs)} \nDiff%={((on_map_obs/(on_map_obs2*n_days))*100):.2f}% for {n_days:.2f} days'
            ax.text(0.85, 1.10, textstr, transform=ax.transAxes, fontsize=12, verticalalignment='top', bbox=props)
        
        plt.rcParams['axes.linewidth'] = 2
        
        suffix = f"_{int(vcoord)}" if vcoord != 'join' else f"_{vcoord}"
        output_file = f'{pathwork}/{family}/{fonction}_{proj}_{layer_label}_id_stn_{id_stn}_{region}_vcoord{suffix}_varno{varno}{name_wind_suffix}.png'
        
        plt.savefig(output_file, dpi=600, format='png', bbox_inches='tight')
        plt.close(fig)
