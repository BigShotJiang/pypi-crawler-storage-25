"""HTML/SVG generation for Python. Zero dependencies."""
__version__ = '0.1.4'
__author__ = 'Deufel'
from .node import Safe
from .emit import render_attrs, to_html, pretty, html_to_tag
from .tag import SvgNs, ModuleClass
__all__ = [
    "ModuleClass",
    "Safe",
    "SvgNs",
    "html_to_tag",
    "pretty",
    "render_attrs",
    "to_html",
]
def __getattr__(name):
        real_name = SVG_NAMES_LOWER.get(name.lower())
        if real_name:
            return mktag(real_name)
        return mktag(name.rstrip('_').replace('_', '-'))
