import types
from collections import namedtuple

VOID = frozenset('area base br col embed hr img input link meta source track wbr'.split())
RAW = frozenset(['script', 'style'])
SVG_VOID = frozenset('stop set image use'.split()) | frozenset('feBlend feColorMatrix feComposite feConvolveMatrix feDisplacementMap feDistantLight feDropShadow feFlood feFuncA feFuncB feFuncG feFuncR feGaussianBlur feImage feMergeNode feMorphology feOffset fePointLight feSpotLight feTile feTurbulence'.split())
SVG_SC = frozenset('circle ellipse line path polygon polyline rect animate animateMotion animateTransform'.split())
SVG_NAMES = dict(clipPath='clipPath', foreignObject='foreignObject', linearGradient='linearGradient', radialGradient='radialGradient', textPath='textPath', animateMotion='animateMotion', animateTransform='animateTransform', **{k: k for k in 'feBlend feColorMatrix feComponentTransfer feComposite feConvolveMatrix feDiffuseLighting feDisplacementMap feDistantLight feDropShadow feFlood feFuncA feFuncB feFuncG feFuncR feGaussianBlur feImage feMerge feMergeNode feMorphology feOffset fePointLight feSpecularLighting feSpotLight feTile feTurbulence'.split()})
_ATTR_MAP = {'cls': 'class', '_class': 'class', '_for': 'for', '_from': 'from', '_in': 'in', '_is': 'is'}
SVG_NAMES_LOWER = {k.lower(): v for k, v in SVG_NAMES.items()}

"""Tag tree node: pure data, no rendering."""

class Safe(str):
    """Pre-escaped HTML string."""
    def __html__(self): return self
