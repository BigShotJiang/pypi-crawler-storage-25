import logging
import traceback
from contextlib import contextmanager
from typing import Any, Dict, Generator, List, cast

from celery import shared_task
from django.conf import settings
from django.db import transaction
from django.utils.timezone import now
from notifications_python_client.errors import HTTPError
from notifications_python_client.notifications import NotificationsAPIClient

from .models import EmailMessage, EmailMessageEvent

logger = logging.getLogger(__name__)

statuses_to_try_to_send = (
    EmailMessage.STATUS_SENDING_TO_NOTIFY,
    EmailMessage.STATUS_RETRYING_SEND_TO_NOTIFY,
)

status_to_try_get_data = (
    EmailMessage.STATUS_SENT_TO_NOTIFY,
    EmailMessage.STATUS_NOTIFY_CREATED,
    EmailMessage.STATUS_NOTIFY_SENDING,
    EmailMessage.STATUS_NOTIFY_TEMPORARY_FAILURE,
)


@shared_task
def send_email(email_message_id: int) -> None:
    logger.info("send_email %s", email_message_id)
    notifications_client = NotificationsAPIClient(
        settings.DJANGO_GOVUK_NOTIFY_OUTBOX__API_KEY)  # type: ignore

    try:
        email_message = EmailMessage.objects.filter(
            pk=email_message_id,
            status__in=statuses_to_try_to_send,
        ).get()
    except EmailMessage.DoesNotExist:
        return

    _send_email(notifications_client, email_message)


@shared_task
def sync() -> None:
    try:
        send_emails()
    except Exception:
        logger.error("Failed send_emails")

    try:
        get_message_data()
    except Exception:
        logger.error("Failed get_message_data")


def send_emails(batch_size: int = 100) -> None:
    logger.info("send_emails")
    notifications_client = NotificationsAPIClient(
        settings.DJANGO_GOVUK_NOTIFY_OUTBOX__API_KEY)  # type: ignore

    email_messages = EmailMessage.objects.filter(
        status__in=statuses_to_try_to_send
    )[:batch_size]
    for email_message in email_messages:
        _send_email(notifications_client, email_message)


def _send_email(
        notifications_client: Any,
        email_message: EmailMessage) -> None:
    logger.info("_send_email %s", email_message)
    max_attempts = 5

    with transaction.atomic():
        # Re-fetch in transaction with select_for_update(skip_locked=True to make sure we don't duplicate
        try:
            email_message = EmailMessage.objects.filter(
                pk=email_message.pk, status__in=statuses_to_try_to_send).select_for_update(skip_locked=True).get()
        except EmailMessage.DoesNotExist:
            return

        email_message.send_to_notify_attempts += 1
        update_fields = ["send_to_notify_attempts"]

        try:
            with logged_api_call(email_message, EmailMessageEvent.TYPE_SEND_TO_NOTIFY) as log:
                response = notifications_client.send_email_notification(
                    email_address=email_message.email_address,
                    template_id=email_message.template_id,
                    reference=email_message.reference,
                    personalisation=email_message.personalisation,
                    email_reply_to_id=email_message.email_reply_to_id,
                    one_click_unsubscribe_url=email_message.one_click_unsubscribe_url,
                )
                log({"http_response": response})
                email_message.status = EmailMessage.STATUS_SENT_TO_NOTIFY
                email_message.notify_id = response['id']
                update_fields += ["status", "notify_id"]
        except BaseException as exception:
            # ALL exceptions so we try as hard as possible to not exceed max attempts, no matter what
            # went wrong (HTTPErrors, Python exceptions in the notifications library etc), to not
            # bombard the user with emails in case exceptions are raised _after_ sending
            email_message.status = \
                EmailMessage.STATUS_FAILED_SEND_TO_NOTIFY if email_message.send_to_notify_attempts >= max_attempts else \
                EmailMessage.STATUS_RETRYING_SEND_TO_NOTIFY
            update_fields += ["status"]
        finally:
            email_message.save(update_fields=update_fields)


def get_message_data() -> None:
    logger.info("get_message_data")
    notifications_client = NotificationsAPIClient(
        settings.DJANGO_GOVUK_NOTIFY_OUTBOX__API_KEY)  # type: ignore

    messages = EmailMessage.objects.filter(status__in=status_to_try_get_data)
    for message in messages:
        _get_message_data(notifications_client, message)


def _get_message_data(notifications_client: Any, email_message: EmailMessage) -> None:
    logger.info("_get_message_data", email_message)
    with transaction.atomic():
        # Re-fetch in transaction with select_for_update(skip_locked=True to make sure we don't duplicate
        try:
            email_message = EmailMessage.objects.filter(
                pk=email_message.pk, status__in=status_to_try_get_data).select_for_update(skip_locked=True).get()
        except EmailMessage.DoesNotExist:
            return

        with logged_api_call(email_message, EmailMessageEvent.TYPE_GET_DATA_FROM_NOTIFY) as log:
            response = notifications_client.get_notification_by_id(email_message.notify_id)
            log({"http_response": response})

        response = notifications_client.get_notification_by_id(email_message.notify_id)
        email_message.status = 'notify-' + response['status']
        email_message.save(update_fields=["status"])


@contextmanager
def logged_api_call(message: EmailMessage, type: str) -> Generator[Any, Any, Any]:
    start = now()
    extra = {}

    def log(new_extra: Dict[str, Any]) -> None:
        extra.update(new_extra)

    try:
        yield log
    except HTTPError as http_exception:
        message.events.create(
            type=type,
            start=start,
            end=now(),
            result=EmailMessageEvent.RESULT_FAILURE,
            exception_type=http_exception.__class__.__name__,
            exception_message=str(http_exception.message),
            exception_stack_trace=traceback.format_exc(),
            http_error_status_code=http_exception.status_code,
            http_error_type=cast(List[dict[Any, Any]], http_exception.message)[0]['error'],
            http_error_message=cast(List[dict[Any, Any]], http_exception.message)[0]['message'],
            **extra,
        )
        raise
    except BaseException as exception:
        message.events.create(
            type=type,
            start=start,
            end=now(),
            result=EmailMessageEvent.RESULT_FAILURE,
            exception_type=exception.__class__.__name__,
            exception_message=str(exception),
            exception_stack_trace=traceback.format_exc(),
            **extra,
        )
        raise

    message.events.create(
        type=type,
        start=start,
        end=now(),
        result=EmailMessageEvent.RESULT_SUCCESS,
        **extra,
    )
