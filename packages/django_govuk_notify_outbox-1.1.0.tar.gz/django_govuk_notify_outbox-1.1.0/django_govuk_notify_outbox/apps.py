from django.apps import AppConfig


class GOVUKNotifyOutboxConfig(AppConfig):
    name = 'django_govuk_notify_outbox'
    verbose_name = "GOV.UK Notify Outbox"
