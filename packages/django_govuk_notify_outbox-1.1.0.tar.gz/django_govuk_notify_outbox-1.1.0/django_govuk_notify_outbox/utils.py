import traceback
from functools import partial
from typing import Any, Callable, Optional

from django.db import transaction
from notifications_python_client.errors import HTTPError

from .models import EmailMessage, EmailMessageEvent, Message
from .tasks import send_email


def send_email_notification(
    email_address: str,
    template_id: str,
    personalisation: Optional[dict[str, Any]] = None,
    reference: Optional[str] = None,
    email_reply_to_id: Optional[str] = None,
    one_click_unsubscribe_url: Optional[str] = None,
) -> EmailMessage:

    email_message = EmailMessage.objects.create(
        email_address=email_address,
        template_id=template_id,
        personalisation=personalisation,
        reference=reference,
        email_reply_to_id=email_reply_to_id,
        one_click_unsubscribe_url=one_click_unsubscribe_url,
    )
    email_message.events.create(type=EmailMessageEvent.TYPE_CREATE)
    transaction.on_commit(partial(send_email.delay, email_message.id))
    return email_message
