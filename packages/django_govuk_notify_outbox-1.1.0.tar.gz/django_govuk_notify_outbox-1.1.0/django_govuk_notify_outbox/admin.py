import json
from typing import Any, List, Optional, Tuple

from django.contrib import admin
from django.http import HttpRequest
from django.urls import reverse

from .models import EmailMessage, EmailMessageEvent


class MessageEventInline(admin.StackedInline[EmailMessageEvent, EmailMessage]):
    model = EmailMessageEvent


@admin.register(EmailMessage)
class EmailMessageAdmin(admin.ModelAdmin[EmailMessage]):
    list_display = [
        "email_address",
        "reference",
        "status",
        "created_on",
    ]
    inlines = [MessageEventInline]

    def get_ordering(self, request: HttpRequest) -> Tuple[str]:
        return ("-created_on",)

    def has_change_permission(self, request: HttpRequest, obj: Optional[EmailMessage] = None) -> bool:
        return False

    def has_add_permission(self, request: HttpRequest) -> bool:
        return False

    def has_delete_permission(
        self, request: HttpRequest, obj: Optional[EmailMessage] = None
    ) -> bool:
        return False
