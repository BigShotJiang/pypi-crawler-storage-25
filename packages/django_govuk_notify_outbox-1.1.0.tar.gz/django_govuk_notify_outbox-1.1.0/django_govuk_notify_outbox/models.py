from django.db import models
from django.utils.timezone import now


class BaseModel(models.Model):
    created_on = models.DateTimeField(db_index=True, null=False, auto_now_add=True)
    modified_on = models.DateTimeField(null=False, auto_now=True)

    class Meta:
        abstract = True


class Message(BaseModel):
    template_id = models.CharField(null=False, blank=False)
    reference = models.CharField(null=True)
    personalisation = models.JSONField(null=True)

    STATUS_SENDING_TO_NOTIFY = "sending-to-notify"
    STATUS_RETRYING_SEND_TO_NOTIFY = "retrying-send-to-notify"
    STATUS_FAILED_SEND_TO_NOTIFY = "failed-send-to-notify"
    STATUS_SENT_TO_NOTIFY = "sent-to-notify"
    STATUS_NOTIFY_CREATED = "notify-created"
    STATUS_NOTIFY_SENDING = "notify-sending"
    STATUS_NOTIFY_DELIVERED = "notify-delivered"
    STATUS_NOTIFY_TEMPORARY_FAILURE = "notify-temporary-failure"
    STATUS_NOTIFY_PERMANENT_FAILURE = "notify-permanent-failure"
    STATUS_NOTIFY_TECHNICAL_FAILURE = "notify-technical-failure"
    STATUS_CHOICES = {
        STATUS_SENDING_TO_NOTIFY: "Sending to GOV.UK Notify",
        STATUS_RETRYING_SEND_TO_NOTIFY: "Retrying send to GOV.UK Notify",
        STATUS_FAILED_SEND_TO_NOTIFY: "Failed sending to GOV.UK Notify",
        STATUS_SENT_TO_NOTIFY: "Sent to GOV.UK Notify",
        STATUS_NOTIFY_CREATED: "Created (queued) on GOV.UK Notify",
        STATUS_NOTIFY_SENDING: "Sending on GOV.UK Notify",
        STATUS_NOTIFY_DELIVERED: "Delivered",
        STATUS_NOTIFY_TEMPORARY_FAILURE: "Temporary failure",
        STATUS_NOTIFY_PERMANENT_FAILURE: "Permanent failure",
        STATUS_NOTIFY_TECHNICAL_FAILURE: "Technical failure",
    }
    status = models.CharField(
        choices=STATUS_CHOICES,
        null=True, blank=False, default=STATUS_SENDING_TO_NOTIFY,
    )
    send_to_notify_attempts = models.IntegerField(null=False, default=0)
    notify_id = models.UUIDField(null=True, blank=False)

    class Meta:
        abstract = True
        indexes = [
            models.Index(fields=["created_on"]),
            models.Index(fields=["status"]),
        ]
        ordering = ("created_on",)


class EmailMessage(Message):
    email_address = models.EmailField(null=False, blank=False)
    email_reply_to_id = models.CharField(null=True)
    one_click_unsubscribe_url = models.CharField(null=True)

    class Meta(Message.Meta):
        indexes = Message.Meta.indexes + [
            models.Index(fields=["email_address"]),
        ]

    def __str__(self) -> str:
        return self.email_address


class MessageEvent(BaseModel):
    TYPE_CREATE = 'create'
    TYPE_SEND_TO_NOTIFY = 'send-to-govuk-notify'
    TYPE_GET_DATA_FROM_NOTIFY = 'get-data-from-govuk-notify'
    TYPE_CHOICES = {
        TYPE_CREATE: 'Create',
        TYPE_SEND_TO_NOTIFY: 'Send to GOV.UK Notify',
        TYPE_GET_DATA_FROM_NOTIFY: 'Get data from GOV.UK Notify',
    }
    type = models.CharField(
        choices=TYPE_CHOICES,
        null=False, blank=False, default=TYPE_CREATE,
    )

    RESULT_SUCCESS = 'success'
    RESULT_FAILURE = 'failure'
    RESULT_CHOICES = {
        RESULT_SUCCESS: 'Success',
        RESULT_FAILURE: 'Failure',
    }
    result = models.CharField(
        choices=RESULT_CHOICES,
        null=False, blank=False, default=RESULT_SUCCESS,
    )
    start = models.DateTimeField(null=False, blank=False, default=now)
    end = models.DateTimeField(null=False, blank=False, default=now)

    # Special case of HTTP (API) success
    http_response = models.JSONField(null=True)

    # Special case of HTTP (API) error
    http_error_status_code = models.IntegerField(null=True)
    http_error_type = models.CharField(null=True)
    http_error_message = models.JSONField(null=True)

    # If any exception raised
    exception_type = models.CharField(null=True)
    exception_message = models.CharField(null=True)
    exception_stack_trace = models.TextField(null=True)

    class Meta:
        abstract = True
        indexes = [
            models.Index(fields=["created_on"]),
        ]
        ordering = ("-created_on",)

    def __str__(self) -> str:
        return self.TYPE_CHOICES.get(self.type, self.type)


class EmailMessageEvent(MessageEvent):
    message = models.ForeignKey(EmailMessage, on_delete=models.CASCADE, related_name="events")

    class Meta(MessageEvent.Meta):
        indexes = MessageEvent.Meta.indexes + [
            models.Index(fields=["message"]),
        ]
