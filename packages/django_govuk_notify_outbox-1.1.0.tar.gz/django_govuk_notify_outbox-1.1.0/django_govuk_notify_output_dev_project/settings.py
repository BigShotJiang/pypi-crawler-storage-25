# Exists because tools (such as django-stubs and the usual way of making migrations) need a
# Django _project_, which at the bare minimum is a settings file. This is true even if making a
# reusable Django app

from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
DEBUG = True
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}
INSTALLED_APPS = (
    "django_govuk_notify_outbox",
)
TIME_ZONE = "UTC"
USE_TZ = True
