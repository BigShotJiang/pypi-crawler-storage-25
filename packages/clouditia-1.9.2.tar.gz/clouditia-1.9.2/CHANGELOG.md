# Changelog

All notable changes to the Clouditia SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.5.0] - 2026-04-08

### Added
- **`wait_until_ready(timeout, poll_interval, verbose)`** — blocks until the session
  is fully ready to use, with a live progress line showing workspace download
  status for sessions resumed from a custom environment (venv).
- **`is_ready()`** — returns `True` if the last `verify()` call reports the session
  as fully accessible.
- `verify()` now returns three additional fields:
  - **`ready: bool`** — `True` only if the session is `running` AND any background
    workspace download (from a custom env resume) is complete.
  - **`estimated_ready_in_seconds: int | None`** — ETA until the session becomes
    ready (0 if already ready, `None` if unknown).
  - **`workspace_sync: dict | None`** — live progress of the workspace restore:
    `{in_progress, bytes_done, bytes_total, files_done, pct, rate_bps, eta_seconds}`.

### Why this matters
When a session is resumed from a custom environment, the remote pod streams
the workspace (models, caches, code…) back from S3 before code-server /
Jupyter can start. For large vLLM-style workspaces (10+ GB, 70k+ files)
this can take several minutes. Previously, the SDK would receive
`status=running` and assume the session was usable, only to fail with
connection errors. Now `wait_until_ready()` provides a clean blocking
API with a progress bar, and `ready=true` only fires when the pod is
actually usable.

### Migration
No breaking changes. Existing code using `verify()` continues to work.
For best UX when resuming a custom env session:

```python
session = clouditia.connect("sk_live_...")
session.wait_until_ready()  # NEW: blocks with progress bar
result = session.run("torch.cuda.is_available()")
```

## [1.4.0] - 2026-01-08

### Fixed
- Fixed `get()` returning "Unknown error" - now correctly retrieves variable values from persistent sessions
- Fixed error handling - Python exceptions are now properly detected as failures (`result.success = False`)
- Fixed persistent session REPL process management - no more duplicate processes
- Fixed expression evaluation in persistent sessions - last expression value is now returned
- Improved REPL daemonization with `setsid` for better process isolation

### Changed
- SDK now reads `result` field from API response for expression values
- Better error messages for execution failures

## [1.0.0] - 2026-01-05

### Added
- Initial release of Clouditia SDK
- `GPUSession` class for connecting to remote GPU sessions
- `run()` method for executing Python code
- `exec()` method for executing code without return value
- `shell()` method for executing shell commands
- `set()` and `get()` methods for variable transfer
- `submit()` method for async job submission
- `jobs()` method for listing async jobs
- `@session.remote` decorator for remote function execution
- `AsyncJob` class with status monitoring and log streaming
- `ExecutionResult` class for handling execution results
- Jupyter magic `%%clouditia` for notebook integration
- `%clouditia_status` and `%clouditia_jobs` line magics
- Comprehensive exception hierarchy:
  - `ClouditiaError` (base)
  - `AuthenticationError`
  - `SessionError`
  - `ExecutionError`
  - `TimeoutError`
  - `CommandBlockedError`
- Full type hints support
- Comprehensive documentation and examples
