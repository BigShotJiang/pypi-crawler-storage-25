"""Dependency injection — pre-planned at registration, executed per request.

Public API: `Depends`, `Security`, `DependencyResolver`. The resolver walks a
pre-built `HandlerPlan` (see `veloce._handler_plan`) rather than reflecting on
the handler signature per request.
"""

from __future__ import annotations

import asyncio
import contextlib
import functools
import inspect
import weakref
from collections.abc import Callable
from enum import Enum
from typing import Any, Literal, get_args, get_origin

from pydantic import TypeAdapter
from pydantic import ValidationError as PydanticValidationError

from veloce._handler_plan import (
    K_BG_TASKS,
    K_BODY_MODEL,
    K_DEPENDS,
    K_PARAM_MARKER,
    K_PATH,
    K_QUERY,
    K_QUERY_LIST,
    K_REQUEST,
    K_RESPONSE,
    K_SECURITY_SCOPES,
    K_UPLOAD_FILE,
    K_WEBSOCKET,
)
from veloce.background import BackgroundTasks
from veloce.exceptions import RequestValidationError, ValidationError
from veloce.http.request import Request
from veloce.http.response import Response


class Depends:
    """Dependency marker — use in function signature defaults.

    `dependency` may be omitted (`Depends()`); the resolver then infers
    it from the parameter's type annotation — the shorthand for
    `x: SomeClass = Depends()`.
    """

    __slots__ = ("dependency", "use_cache")

    def __init__(self, dependency: Callable | None = None, use_cache: bool = True) -> None:
        self.dependency = dependency
        self.use_cache = use_cache


class Security(Depends):
    """Dependency marker with OAuth2 scopes for OpenAPI emission."""

    __slots__ = ("scopes",)

    def __init__(
        self,
        dependency: Callable | None = None,
        scopes: list[str] | None = None,
        use_cache: bool = True,
    ) -> None:
        super().__init__(dependency=dependency, use_cache=use_cache)
        self.scopes = scopes or []


class SecurityScopes:
    """Aggregated OAuth 2.0 scopes for the current Security() chain.

    A handler / sub-dependency that declares a parameter of this type
    receives the union of all `Security(..., scopes=[...])` calls between
    the route entry and this point in the dependency graph. Typical use:
    an authorising dependency checks `security_scopes.scopes` against
    the scopes the bearer token actually carries and builds a
    `WWW-Authenticate: Bearer scope="<...>"` header when denying.

    Per RFC 6749 §3.3 the scope-string serialisation is space-separated.
    """

    __slots__ = ("scopes", "scope_str")

    def __init__(self, scopes: list[str] | None = None) -> None:
        self.scopes: list[str] = list(scopes) if scopes else []
        self.scope_str: str = " ".join(self.scopes)

    def __repr__(self) -> str:
        return f"SecurityScopes({self.scopes!r})"


@functools.lru_cache(maxsize=512)
def _type_adapter(target_type: Any) -> TypeAdapter | None:
    """Build (once) and cache a Pydantic ``TypeAdapter`` for a parameter type.

    Adapters are keyed on the annotation object, so a route that declares
    `created: datetime = Query(...)` pays the adapter-construction cost once
    at first request, never again. ``None`` — the result for an annotation
    Pydantic cannot build an adapter for — is cached too, so an un-adaptable
    type is not re-attempted (and re-failed) on every subsequent request.
    """
    try:
        return TypeAdapter(target_type)
    except Exception:
        return None


def _coerce_literal(value: Any, target_type: Any, param_name: str, loc: str) -> Any:
    """Match a request value against a `Literal[...]` parameter.

    Request values arrive as strings, so Pydantic's strict literal check
    rejects an `int` / `bool` literal outright. Each plausible coercion of
    the value — the raw string, a bool, an int, a float — is compared
    against the literal members by *exact* runtime type, sidestepping
    Python's loose `1 == True` equivalence.
    """
    members = get_args(target_type)
    candidates: list[Any] = [value]
    if isinstance(value, str):
        candidates.append(value.lower() in ("true", "1", "yes"))
        with contextlib.suppress(ValueError):
            candidates.append(int(value))
        with contextlib.suppress(ValueError):
            candidates.append(float(value))
    for member in members:
        # An `Enum` member is matched against its underlying value, so a
        # `str` / `int`-backed enum member still accepts the plain request
        # value while the original member object is what gets returned.
        comparand = member.value if isinstance(member, Enum) else member
        for candidate in candidates:
            if type(candidate) is type(comparand) and candidate == comparand:
                return member
    raise RequestValidationError(
        [
            {
                "loc": [loc, param_name],
                "msg": f"Input should be one of: {', '.join(repr(m) for m in members)}",
                "type": "literal_error",
            }
        ]
    )


def _coerce_via_pydantic(value: Any, target_type: Any, param_name: str, loc: str) -> Any:
    """Validate and coerce a request value through Pydantic.

    The fast scalar branches of `_coerce_value` cover `str` / `int` / `float`
    / `bool` / `Enum`; every other annotation — `datetime`, `date`, `time`,
    `UUID`, `Decimal`, `Path`, constrained generics — is handled here so
    query / path / header / cookie parameters get the same full validation a
    request-body model already enjoys.

    If Pydantic cannot build an adapter for the annotation the raw value is
    returned unchanged, preserving the previous pass-through behaviour.
    """
    try:
        adapter = _type_adapter(target_type)
    except TypeError:
        # Unhashable annotation — `lru_cache` cannot key it. Fall back to
        # the raw value, the behaviour before Pydantic coercion existed.
        return value
    if adapter is None:
        return value
    try:
        return adapter.validate_python(value)
    except PydanticValidationError as err:
        raise RequestValidationError(
            [
                {
                    "loc": [loc, param_name],
                    "msg": e["msg"],
                    "type": e["type"],
                }
                for e in err.errors()
            ]
        ) from err


def _coerce_value(value: Any, target_type: Any, param_name: str, loc: str) -> Any:
    """Coerce a string value to the target type."""
    if target_type is str or target_type is Any or target_type is None:
        return value
    try:
        if target_type is int:
            return int(value)
        if target_type is float:
            return float(value)
        if target_type is bool:
            if isinstance(value, str):
                return value.lower() in ("true", "1", "yes")
            return bool(value)
        # Enum (or any class with __members__).
        if hasattr(target_type, "__members__"):
            try:
                return target_type(value)
            except (ValueError, KeyError) as err:
                valid = list(target_type.__members__.keys())
                raise RequestValidationError(
                    [
                        {
                            "loc": [loc, param_name],
                            "msg": f"Invalid value for {param_name}: must be one of {valid}",
                            "type": "type_error",
                        }
                    ]
                ) from err
    except (ValueError, TypeError) as err:
        raise RequestValidationError(
            [
                {
                    "loc": [loc, param_name],
                    "msg": f"Invalid value for {param_name}: expected {getattr(target_type, '__name__', target_type)}",
                    "type": "type_error",
                }
            ]
        ) from err

    # No fast scalar branch matched. `Literal[...]` needs string-aware
    # member matching; everything else goes to Pydantic for full coverage.
    if get_origin(target_type) is Literal:
        return _coerce_literal(value, target_type, param_name, loc)
    return _coerce_via_pydantic(value, target_type, param_name, loc)


_MARKER_LOC = {
    # Map MK_* → openapi-style location string. Resolved lazily to avoid import
    # ordering issues.
    0: "query",
    1: "path",
    2: "header",
    3: "cookie",
    4: "body",
    5: "form",
    6: "form",
}


# Shared empty sentinels for resolvers that never see app-level overrides
# (the dispatcher overwrites the slot before any read, so the sentinels
# never appear on the dispatch path). Module-level so they are not
# reallocated per request. `_EMPTY_OVERRIDES` is only ever `.get(...)`'d
# by `_exec_depends`, so it stays untouched. `_EMPTY_OVERRIDE_SUBPLANS`
# is read AND written by `_exec_depends`; the writer swaps the slot to a
# fresh `WeakKeyDictionary` on the first write so the sentinel is never
# mutated and cross-resolver contamination is impossible for direct
# `DependencyResolver()` callers (tests, public-API users).
_EMPTY_OVERRIDES: dict[Callable, Callable] = {}
_EMPTY_OVERRIDE_SUBPLANS: weakref.WeakKeyDictionary[Callable, Any] = weakref.WeakKeyDictionary()


class DependencyResolver:
    """Walks a `HandlerPlan` to produce kwargs for a handler.

    Per-request lifecycle: `_cache` is cleared on entry to `resolve_plan`.
    `_overrides` is set by the application (dependency
    overrides) and persists across requests.
    """

    __slots__ = (
        "_cache",
        "_overrides",
        "_override_subplans",
        "_teardowns",
        "_scope_stack",
    )

    def __init__(self) -> None:
        self._cache: dict[Callable, Any] = {}
        # `_overrides` and `_override_subplans` are immediately overwritten
        # by `Veloce._dispatch_request` with the app-scoped instances. Skip
        # the throwaway dict + WeakKeyDictionary allocation here on the hot
        # path; the module-level sentinels below provide the same
        # iteration / `.get(...)` semantics for resolvers constructed
        # outside the dispatcher (unit tests, direct callers).
        self._overrides: dict[Callable, Callable] = _EMPTY_OVERRIDES
        self._override_subplans: weakref.WeakKeyDictionary[Callable, Any] = _EMPTY_OVERRIDE_SUBPLANS
        # Per-request stack of yield-style dependency teardowns. Each entry is
        # `(kind, generator)` where kind is "sync" or "async". The stack is
        # drained in reverse by `run_teardowns()` after the response.
        self._teardowns: list[tuple[str, Any]] = []
        # Per-request accumulator of `Security(..., scopes=[...])` scopes.
        # Pushed before a Security sub-plan resolves, popped after. A
        # `SecurityScopes` parameter inside the chain reads this stack.
        self._scope_stack: list[str] = []

    def reset(self) -> None:
        """Clear the per-request resolver state.

        Run at the top of every `resolve_plan`, and also called directly
        by the dispatcher's trivial-route fast path (a route with no
        parameters and no dependencies) so the shared resolver never
        carries a previous request's cached results into the next one.
        """
        self._cache.clear()
        self._teardowns.clear()
        self._scope_stack.clear()

    async def resolve_plan(
        self,
        plan: Any,
        request: Request,
        path_params: dict[str, str],
        route_dep_plans: list[Any] | None = None,
    ) -> dict[str, Any]:
        """Fast path — consume a pre-built `HandlerPlan`."""
        self.reset()

        if route_dep_plans:
            for slot in route_dep_plans:
                await self._exec_depends(slot, request, path_params)

        return await self._resolve_slots(plan.slots, request, path_params)

    async def resolve_ws_plan(
        self,
        plan: Any,
        websocket: Any,
        path_params: dict[str, str],
        route_dep_plans: list[Any] | None = None,
    ) -> dict[str, Any]:
        """Resolve a WebSocket handler's plan.

        The shared slot machinery is reused — the `WebSocket` is passed
        where an HTTP resolve passes the `Request`, so `K_WEBSOCKET` slots,
        the `Depends` graph (with `yield`-teardown and `Security` scope
        accumulation), and `path` parameters all resolve through one code
        path. Run teardowns with `run_teardowns()` once the handler returns.
        """
        self.reset()

        if route_dep_plans:
            for slot in route_dep_plans:
                await self._exec_depends(slot, websocket, path_params)

        return await self._resolve_slots(plan.slots, websocket, path_params)

    async def run_teardowns(self, exc: BaseException | None = None) -> None:
        """Run yield-dependency teardowns in reverse registration order.

        Each generator is advanced one step (or thrown into if `exc` is set)
        so the code after its `yield` executes. Exceptions inside teardown
        code are logged but do not interrupt the chain.
        """
        # Drain in reverse so the most recently set-up dependency tears down
        # first — matches Python's contextlib.ExitStack semantics.
        while self._teardowns:
            kind, gen = self._teardowns.pop()
            try:
                if kind == "sync":
                    if exc is not None:
                        # Teardown's own exception while handling the outer
                        # one: swallow to keep draining the stack.
                        with contextlib.suppress(StopIteration, Exception):
                            gen.throw(exc)
                    else:
                        with contextlib.suppress(StopIteration):
                            next(gen)
                else:  # async
                    if exc is not None:
                        with contextlib.suppress(StopAsyncIteration, Exception):
                            await gen.athrow(exc)
                    else:
                        with contextlib.suppress(StopAsyncIteration):
                            await gen.__anext__()
            except Exception:
                # Last-resort safety net — never crash the response cycle
                # because a teardown raised.
                pass

    async def resolve(
        self,
        handler: Callable,
        request: Request,
        path_params: dict[str, str],
        route_dependencies: list[Depends] | None = None,
    ) -> dict[str, Any]:
        """Back-compat path — build a plan on demand. Tests and direct
        callers that did not pre-plan land here.
        """
        from veloce._handler_plan import build_plan, build_route_dep_plans

        plan = build_plan(handler)
        rdp = build_route_dep_plans(route_dependencies) if route_dependencies else None
        return await self.resolve_plan(plan, request, path_params, rdp)

    async def _resolve_slots(
        self,
        slots: list[Any],
        request: Request,
        path_params: dict[str, str],
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {}

        i = 0
        n = len(slots)
        while i < n:
            slot = slots[i]
            kind = slot.kind
            name = slot.name

            if kind == K_REQUEST:
                kwargs[name] = request
                i += 1
                continue

            if kind == K_WEBSOCKET:
                # WebSocket plans pass the connection where an HTTP resolve
                # passes the `Request`, so the same object is bound here.
                kwargs[name] = request
                i += 1
                continue

            if kind == K_BG_TASKS:
                if request._background_tasks is None:
                    request._background_tasks = BackgroundTasks()
                kwargs[name] = request._background_tasks
                i += 1
                continue

            if kind == K_RESPONSE:
                # Response injection. One Response per
                # request, shared between the handler and any dependency
                # that also declares the parameter. `status_code = 0` is
                # the "not set by the handler" sentinel the dispatcher
                # checks before merging.
                injected = request._state.get("_injected_response")
                if injected is None:
                    injected = Response()
                    injected.status_code = 0
                    request._state["_injected_response"] = injected
                kwargs[name] = injected
                i += 1
                continue

            if kind == K_SECURITY_SCOPES:
                # Snapshot the accumulated scopes — copy so later
                # mutations of `_scope_stack` don't affect this instance.
                kwargs[name] = SecurityScopes(list(self._scope_stack))
                i += 1
                continue

            if kind == K_DEPENDS:
                # Look ahead for a contiguous run of `K_DEPENDS` siblings
                # that can safely run in parallel. The constraints
                # — no Security() scope mutation, no yield-style
                # dependencies, no two slots sharing a use_cache=True
                # callable — protect the shared resolver state. When
                # the run isn't safe (or is just one slot), fall back to
                # the sequential await. See `_parallel_dep_group_end`.
                end = self._parallel_dep_group_end(slots, i)
                if end > i + 1:
                    group = slots[i:end]
                    results = await asyncio.gather(
                        *(self._exec_depends(s, request, path_params) for s in group)
                    )
                    for s, r in zip(group, results, strict=True):
                        kwargs[s.name] = r
                    i = end
                    continue
                kwargs[name] = await self._exec_depends(slot, request, path_params)
                i += 1
                continue

            if kind == K_PARAM_MARKER:
                kwargs[name] = await self._resolve_marker(slot, request, path_params)
                i += 1
                continue

            if kind == K_BODY_MODEL:
                kwargs[name] = self._resolve_body_model(slot, request)
                i += 1
                continue

            if kind == K_UPLOAD_FILE:
                form = await request.form()
                upload = form.get(name)
                if upload is None and slot.is_optional:
                    kwargs[name] = None
                elif upload is not None:
                    kwargs[name] = upload
                # else: leave unset (handler default will apply if any)
                i += 1
                continue

            if kind == K_QUERY_LIST:
                # Lists may come from path or query; prefer path.
                if name in path_params:
                    raw = path_params[name]
                    kwargs[name] = [_coerce_value(raw, slot.list_inner, name, "path")]
                elif name in request.query_params:
                    # MultiDict.getall returns every value the URL carried
                    # for this key. `?tag=a&tag=b` → ["a", "b"].
                    values = request.query_params.getall(name)
                    kwargs[name] = [
                        _coerce_value(v, slot.list_inner, name, "query") for v in values
                    ]
                elif slot.has_default:
                    kwargs[name] = slot.default
                elif slot.is_optional:
                    kwargs[name] = None
                i += 1
                continue

            if kind == K_QUERY:
                # Path-or-query: a handler param that wasn't otherwise tagged.
                # Path bindings win if the route's matched params include this
                # name; else fall back to query string.
                if name in path_params:
                    kwargs[name] = _coerce_value(
                        path_params[name], slot.target_type or str, name, "path"
                    )
                elif name in request.query_params:
                    val = request.query_params[name]
                    kwargs[name] = _coerce_value(val, slot.target_type or str, name, "query")
                elif slot.has_default:
                    kwargs[name] = slot.default
                elif slot.is_optional:
                    kwargs[name] = None
                i += 1
                continue

            # K_PATH and K_NONE are not currently emitted by build_plan; future-proof.
            if kind == K_PATH:
                if name in path_params:
                    kwargs[name] = _coerce_value(
                        path_params[name], slot.target_type or str, name, "path"
                    )
                elif slot.has_default:
                    kwargs[name] = slot.default
                elif slot.is_optional:
                    kwargs[name] = None
                i += 1
                continue

            # Fall-through: kind didn't match anything; advance so the
            # loop terminates instead of spinning on an unknown slot.
            i += 1

        return kwargs

    def _parallel_dep_group_end(self, slots: list[Any], start: int) -> int:
        """Return the index past the last K_DEPENDS sibling safely
        parallelisable with `slots[start]`.

        A run is parallelisable when every slot in it:
        - is `K_DEPENDS`,
        - pushes no `SecurityScopes` **transitively** — neither the
          slot itself nor any K_DEPENDS in its `sub_plan.slots` may
          carry a scope list. Security() deps mutate the shared
          `_scope_stack` around their inner resolve, and two parallel
          siblings whose sub-plans each push different scopes would
          interleave on that shared list and corrupt the snapshot any
          `SecurityScopes` parameter sees.
        - is not a yield-style dependency, transitively — generator-
          driven teardowns push onto a shared list whose order we
          would otherwise lose,
        - and does not share a `use_cache=True` callable with another
          slot in the run (would race for `self._cache[callable]`).

        Returns `start + 1` when the run cannot be expanded, so the
        caller falls back to the sequential await.
        """
        n = len(slots)
        if start >= n:
            return start
        seen_cached: set[Any] = set()
        end = start
        while end < n:
            s = slots[end]
            if s.kind != K_DEPENDS:
                break
            if not self._slot_safe_for_parallel(s, set()):
                break
            # Cache collision with an earlier sibling in this same run.
            if s.use_cache:
                if s.dep_callable in seen_cached:
                    break
                seen_cached.add(s.dep_callable)
            end += 1
        return end

    def _slot_safe_for_parallel(self, slot: Any, seen_plans: set[int]) -> bool:
        """Transitive safety check: the slot itself and every
        `K_DEPENDS` reachable through its `sub_plan` chain must avoid
        the shared-state hazards (Security() scope push, yield-style
        teardown).

        Cycle-guarded via `seen_plans` so a self-referential plan
        graph doesn't blow the recursion stack.
        """
        if isinstance(slot.target_type, list) and slot.target_type:
            return False
        if getattr(slot, "dep_is_gen", False) or getattr(slot, "dep_is_async_gen", False):
            return False
        sub_plan = getattr(slot, "sub_plan", None)
        if sub_plan is None:
            return True
        plan_id = id(sub_plan)
        if plan_id in seen_plans:
            return True
        seen_plans.add(plan_id)
        for sub in getattr(sub_plan, "slots", ()):
            if sub.kind == K_DEPENDS and not self._slot_safe_for_parallel(sub, seen_plans):
                return False
        return True

    def _resolve_body_model(self, slot: Any, request: Request) -> Any:
        try:
            body_data = request.json()
            return slot.model.model_validate(body_data)
        except PydanticValidationError as e:
            raise RequestValidationError(
                [
                    {
                        "loc": err["loc"],
                        "msg": err["msg"],
                        "type": err["type"],
                    }
                    for err in e.errors()
                ]
            ) from e
        except ValidationError:
            raise
        except Exception as err:
            raise RequestValidationError(
                [
                    {
                        "loc": ["body"],
                        "msg": "Invalid request body",
                        "type": "value_error",
                    }
                ]
            ) from err

    async def _resolve_marker(
        self, slot: Any, request: Request, path_params: dict[str, str]
    ) -> Any:
        marker = slot.marker
        mk = slot.marker_kind
        lookup = slot.lookup_name

        # List-typed query / header / cookie / form marker
        # (`tags: list[str] = Query(...)` / `Header(...)` / `Cookie(...)`
        # / `Form(...)`) — collect every repeated value, not just the
        # first.
        if mk in (0, 2, 3, 5) and get_origin(slot.target_type) in (list, set, tuple):
            inner_args = get_args(slot.target_type)
            inner = inner_args[0] if inner_args else str
            if mk == 5:  # MK_FORM
                values = (await request.form()).getlist(lookup)
            elif mk == 2:  # MK_HEADER
                values = request.headers.getlist(lookup.lower())
            elif mk == 3:  # MK_COOKIE
                values = request.cookies.getlist(lookup)
            else:  # MK_QUERY
                values = request.query_params.getlist(lookup)
            loc = _MARKER_LOC[mk]
            if not values:
                if marker.has_default:
                    return marker.default
                if slot.is_optional:
                    return None
                raise RequestValidationError(
                    [
                        {
                            "loc": [loc, slot.name],
                            "msg": f"Missing required parameter: {slot.name}",
                            "type": "value_error.missing",
                        }
                    ]
                )
            return [v if inner is str else _coerce_value(v, inner, slot.name, loc) for v in values]

        if mk == 1:  # MK_PATH
            raw = path_params.get(lookup)
        elif mk == 2:  # MK_HEADER
            raw = request.headers.get(lookup.lower())
        elif mk == 3:  # MK_COOKIE
            raw = request.cookies.get(lookup)
        elif mk == 4:  # MK_BODY
            body = request.json() if request.body else None
            # `Body(embed=True)` — the value lives under the param name
            # inside the JSON object, rather than being the whole body.
            if getattr(marker, "embed", False) and isinstance(body, dict):
                raw = body.get(lookup)
            else:
                raw = body
        elif mk in (5, 6):  # MK_FORM / MK_FILE
            form = await request.form()
            raw = form.get(lookup)
        else:  # MK_QUERY (0)
            raw = request.query_params.get(lookup)

        if raw is None:
            if marker.has_default:
                return marker.default
            if slot.is_optional:
                return None
            raise RequestValidationError(
                [
                    {
                        "loc": [_MARKER_LOC[mk], slot.name],
                        "msg": f"Missing required parameter: {slot.name}",
                        "type": "value_error.missing",
                    }
                ]
            )

        target = slot.target_type
        if target and target is not str and not isinstance(raw, (dict, list)):
            raw = _coerce_value(raw, target, slot.name, _MARKER_LOC[mk])

        try:
            return marker.validate(raw, slot.name)
        except ValueError as e:
            raise RequestValidationError(
                [
                    {
                        "loc": [_MARKER_LOC[mk], slot.name],
                        "msg": str(e),
                        "type": "value_error",
                    }
                ]
            ) from e

    async def _exec_depends(self, slot: Any, request: Request, path_params: dict[str, str]) -> Any:
        """Resolve a K_DEPENDS slot with caching and override support."""
        dep_callable = slot.dep_callable
        actual = self._overrides.get(dep_callable, dep_callable)

        if slot.use_cache and actual in self._cache:
            return self._cache[actual]

        if actual is dep_callable:
            sub_plan = slot.sub_plan
            is_coro = slot.dep_is_coro
            is_gen = slot.dep_is_gen
            is_async_gen = slot.dep_is_async_gen
        else:
            # Override path: subplan + the three callable-kind flags are
            # memoised on the override callable; the resolver shares this
            # cache across requests via the Veloce instance.
            entry = self._override_subplans.get(actual)
            if entry is None:
                # local: avoids dependency <-> _handler_plan cycle
                from veloce._handler_plan import build_plan

                entry = (
                    build_plan(actual),
                    inspect.iscoroutinefunction(actual),
                    inspect.isgeneratorfunction(actual),
                    inspect.isasyncgenfunction(actual),
                )
                # Override targets that aren't weak-referenceable (some
                # C-level callables) silently skip caching — re-probing
                # is fine, leaking the entry is not.
                # Before the first write, replace the shared module-level
                # sentinel with a per-resolver `WeakKeyDictionary`. Without
                # this swap, a resolver constructed outside the dispatcher
                # (tests, direct callers — see `__init__` docstring) would
                # mutate the sentinel and silently accumulate plans
                # process-globally across unrelated callers.
                if self._override_subplans is _EMPTY_OVERRIDE_SUBPLANS:
                    self._override_subplans = weakref.WeakKeyDictionary()
                with contextlib.suppress(TypeError):
                    self._override_subplans[actual] = entry
            sub_plan, is_coro, is_gen, is_async_gen = entry

        # Push this Security()'s scopes onto the stack so a `SecurityScopes`
        # slot inside the sub-plan sees them. Plain `Depends` has no scopes
        # so the push is a no-op. The stack is popped after the sub-plan
        # resolves regardless of success/failure.
        new_scopes: list[str] = slot.target_type if isinstance(slot.target_type, list) else []
        if new_scopes:
            self._scope_stack.extend(new_scopes)
        try:
            sub_kwargs = await self._resolve_slots(sub_plan.slots, request, path_params)
        finally:
            if new_scopes:
                del self._scope_stack[-len(new_scopes) :]

        if is_gen:
            # Sync generator: start it, capture the first yielded value as
            # the dependency result, and push the live generator onto the
            # teardown stack so `run_teardowns` advances past the yield.
            gen = actual(**sub_kwargs)
            try:
                result = next(gen)
            except StopIteration as err:
                raise RuntimeError(
                    f"yield dependency {actual!r} returned without yielding a value"
                ) from err
            self._teardowns.append(("sync", gen))
        elif is_async_gen:
            agen = actual(**sub_kwargs)
            try:
                result = await agen.__anext__()
            except StopAsyncIteration as err:
                raise RuntimeError(
                    f"yield dependency {actual!r} returned without yielding a value"
                ) from err
            self._teardowns.append(("async", agen))
        elif is_coro:
            result = await actual(**sub_kwargs)
        else:
            result = actual(**sub_kwargs)

        if slot.use_cache:
            self._cache[actual] = result
        return result
