"""WebSocket support — basic implementation over raw asyncio."""

from __future__ import annotations

import asyncio
import base64
import contextlib
import enum
import hashlib
import struct
from collections.abc import Iterable
from typing import Any

import orjson

from veloce.exceptions import WebSocketDisconnect
from veloce.http.response import _reject_header_crlf


class WebSocketState(enum.IntEnum):
    """Connection-state enum — ASGI shape.

    `CONNECTING` is the initial state before `accept()` has been sent
    (client side) or received (application side). `CONNECTED` once the
    handshake completes; `DISCONNECTED` once a close frame has been
    sent or received on the corresponding side.
    """

    CONNECTING = 0
    CONNECTED = 1
    DISCONNECTED = 2


class WebSocket:
    """WebSocket connection handler."""

    GUID = "258EAFA5-E914-47DA-95CA-5AB5DC525D63"

    # Cap inbound frame backlog. An unbounded `asyncio.Queue` lets a peer
    # that sends faster than the handler reads grow it without limit —
    # a DoS / backpressure vector. With a cap, the protocol's `put` (the
    # producer) `await`s once the cap is hit, which is the backpressure
    # signal: the application either reads faster or closes the
    # connection. Configurable via constructor for apps with legitimate
    # high-burst peers.
    DEFAULT_RECV_QUEUE_MAXSIZE = 64

    def __init__(
        self,
        transport: asyncio.Transport,
        headers: dict[str, str],
        recv_queue_maxsize: int | None = None,
    ) -> None:
        self.transport = transport
        self.headers = headers
        self._accepted = False
        self._closed = False
        maxsize = (
            recv_queue_maxsize
            if recv_queue_maxsize is not None
            else self.DEFAULT_RECV_QUEUE_MAXSIZE
        )
        self._receive_queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=maxsize)
        # Fragmented-message reassembly state (RFC 6455 §5.4). `_frag_opcode`
        # is the data opcode of the message currently being assembled, or
        # `None` when no fragmented message is in progress.
        self._frag_opcode: int | None = None
        self._frag_buffer: bytearray = bytearray()
        # ASGI mode (W1). When wired through `Veloce.__call__`'s websocket
        # branch, the transport is None and we drive the connection through
        # ASGI receive/send callables instead. Set by `from_asgi`.
        self._asgi_receive: Any = None
        self._asgi_send: Any = None
        self.scope: dict | None = None
        self.path: str = ""
        self.path_params: dict[str, Any] = {}

    @classmethod
    def from_asgi(
        cls,
        scope: dict,
        receive: Any,
        send: Any,
    ) -> WebSocket:
        """Construct an ASGI-driven WebSocket (no asyncio.Transport).

        Used by `Veloce.__call__` for `scope["type"] == "websocket"`.
        Headers come from `scope["headers"]` (list of `(bytes, bytes)`),
        decoded latin-1 per ASGI. `accept`/`send_*`/`receive_*`/`close`
        all dispatch through `send`/`receive` instead of the raw frame
        writer used by the asyncio.Transport mode.
        """
        headers: dict[str, str] = {}
        for k, v in scope.get("headers", []):
            headers[k.decode("latin-1").lower()] = v.decode("latin-1")
        # `cls.__new__` to skip the transport-required __init__.
        ws = cls.__new__(cls)
        ws.transport = None  # type: ignore[assignment]
        ws.headers = headers
        ws._accepted = False
        ws._closed = False
        # Bounded — even though ASGI mode never feeds this queue, an
        # unbounded queue is a footgun if any future change starts pushing.
        ws._receive_queue = asyncio.Queue(maxsize=cls.DEFAULT_RECV_QUEUE_MAXSIZE)
        ws._frag_opcode = None  # unused in ASGI mode (no raw frame parsing)
        ws._frag_buffer = bytearray()
        ws._asgi_receive = receive
        ws._asgi_send = send
        ws.scope = scope
        ws.path = scope.get("path", "")
        ws.path_params = {}
        return ws

    @property
    def _is_asgi(self) -> bool:
        return self._asgi_send is not None

    @property
    def query_params(self) -> Any:
        """Parsed query string of the WebSocket handshake URL.

        Read it as `ws.query_params["token"]`. Backed by
        `QueryParams` (multi-value, `getlist`-aware). Empty when the
        scope carries no `query_string`.
        """
        from veloce.http.datastructures import QueryParams

        raw = b""
        if self.scope:
            raw = self.scope.get("query_string", b"") or b""
        qs = raw.decode("latin-1") if isinstance(raw, bytes) else str(raw)
        return QueryParams.from_query_string(qs)

    @property
    def url(self) -> str:
        """The WebSocket handshake URL path — ASGI-style shape.

        Returns `path` plus `?query` when a query string is present.
        """
        raw = b""
        if self.scope:
            raw = self.scope.get("query_string", b"") or b""
        qs = raw.decode("latin-1") if isinstance(raw, bytes) else str(raw)
        return f"{self.path}?{qs}" if qs else self.path

    @property
    def client(self) -> Any:
        """The connecting peer as an `Address(host, port)`.

        Reads `scope["client"]` (the ASGI `(host, port)` pair).
        Returns `None` when the scope carries no client info.
        """
        from veloce.http.request import Address

        client = self.scope.get("client") if self.scope else None
        if client:
            return Address(client[0], client[1])
        return None

    @property
    def state(self) -> Any:
        """Per-connection scratch namespace.

        Lazily-created `State` (a dict subclass) supporting both
        `ws.state.user = ...` attribute access and `ws.state["user"]`.
        """
        from veloce.http.request import State

        existing = getattr(self, "_state", None)
        if existing is None:
            existing = State()
            object.__setattr__(self, "_state", existing)
        return existing

    @property
    def cookies(self) -> dict[str, str]:
        """Cookies sent with the WebSocket handshake.

        Parses the handshake `Cookie` header into `{name: value}`.
        Empty when no cookie header was present.
        """
        from veloce.http.cookies import parse_cookie

        return parse_cookie(self.headers.get("cookie", ""))

    @property
    def application_state(self) -> WebSocketState:
        """Server-side state of the WebSocket.

        - `CONNECTING` before the app sends `accept()`.
        - `CONNECTED` after `accept()` and until `close()` is sent.
        - `DISCONNECTED` after `close()` (locally) or after the peer
          half-closes (observed via `WebSocketDisconnect`).
        """
        if self._closed:
            return WebSocketState.DISCONNECTED
        if self._accepted:
            return WebSocketState.CONNECTED
        return WebSocketState.CONNECTING

    @property
    def client_state(self) -> WebSocketState:
        """Client-side state of the WebSocket.

        Veloce does not distinguish the two halves at the protocol level
        beyond the close flag, so this mirrors `application_state` once
        the peer disconnects and otherwise stays `CONNECTED` once the
        handshake completes.
        """
        return self.application_state

    @property
    def origin(self) -> str | None:
        """The client-supplied `Origin` header, or `None` if absent.

        WebSocket handshakes carry `Origin` per RFC 6455 §10.2 / §4.1.
        Browsers always send it; non-browser clients may omit it. The
        header is the application's primary defence against Cross-Site
        WebSocket Hijacking — CSWSH bypasses CORS because the handshake
        is plain HTTP/1.1 and Same-Origin Policy does not apply to it.
        Pair this accessor with `check_origin(allowed)` before `accept()`.
        """
        return self.headers.get("origin")

    def check_origin(self, allowed: str | Iterable[str]) -> bool:
        """Return `True` when the handshake's `Origin` is in `allowed`.

        Pass a single origin string or an iterable of allowed origins
        (e.g. `["https://app.example.com", "https://admin.example.com"]`).
        Normalisation matches `WebSocketOriginMiddleware`: each side is
        lowercased *and* has any trailing slash stripped, so allow-lists
        written for one API are interchangeable with the other.

        - **Wildcard.** `"*"` in `allowed` accepts any origin and is the
          opt-in "I have my own check elsewhere" escape hatch — the
          symmetric behaviour to `WebSocketOriginMiddleware`'s
          `allowed_origins=["*"]`.
        - **Missing `Origin`** (no header at all, or a literal
          `Origin: null` from a sandboxed iframe / `file://` page) is
          a non-match and returns `False`. Non-browser clients
          legitimately omit the header — if you want to allow them,
          branch on `ws.origin is None` explicitly. The
          `WebSocketOriginMiddleware` middleware path also offers an
          `allow_missing=True` switch; this in-handler helper is
          deliberately strict-by-default.

        Usage:
            @app.websocket("/ws")
            async def chat(ws: WebSocket):
                if not ws.check_origin("https://app.example.com"):
                    await ws.close(code=1008)  # policy violation
                    return
                await ws.accept()
                ...

        For the middleware-style check (registered once, runs before
        the handler) reach for `veloce.SecurityHeadersMiddleware`'s
        sibling `WebSocketOriginMiddleware`.
        """
        allowed_set = frozenset((allowed,)) if isinstance(allowed, str) else frozenset(allowed)
        # Wildcard short-circuit — accept anything, including a missing
        # `Origin`. Matches the middleware's `_allow_all` branch.
        if "*" in allowed_set:
            return True
        if self.origin is None or self.origin == "null":
            return False
        origin_norm = self.origin.rstrip("/").lower()
        normalised = {a.rstrip("/").lower() for a in allowed_set}
        return origin_norm in normalised

    @property
    def requested_subprotocols(self) -> list[str]:
        """Subprotocols the client offered in `Sec-WebSocket-Protocol`.

        Returns them in client preference order (RFC 6455 §1.9). Empty
        list when the header is absent. Whitespace around each token is
        stripped; the comparison the negotiator performs is case-sensitive
        per the spec.
        """
        raw = self.headers.get("sec-websocket-protocol", "")
        if not raw:
            return []
        return [p.strip() for p in raw.split(",") if p.strip()]

    def negotiate_subprotocol(self, supported: list[str]) -> str | None:
        """Pick the first client-offered subprotocol that the server supports.

        Per RFC 6455 §4.1, the server picks ONE protocol from the client's
        list. Most servers prefer to honour the client's preference order
        (first match wins), which is what we do.
        """
        offered = self.requested_subprotocols
        if not offered:
            return None
        wanted = set(supported)
        for proto in offered:
            if proto in wanted:
                return proto
        return None

    async def accept(
        self,
        subprotocol: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Complete the WebSocket handshake."""
        # Enforce the handshake state machine: accepting an already-accepted
        # or already-closed connection is a programming error — surface it
        # as a clear exception rather than re-running the handshake.
        if self._accepted:
            raise RuntimeError("WebSocket.accept(): connection is already accepted")
        if self._closed:
            raise RuntimeError("WebSocket.accept(): connection is already closed")
        # Reject CR/LF in the negotiated subprotocol and any custom
        # handshake headers — they are written into the 101 response.
        if subprotocol:
            _reject_header_crlf(subprotocol, "WebSocket subprotocol")
        if headers:
            for _k, _v in headers.items():
                _reject_header_crlf(_k, "WebSocket header name")
                _reject_header_crlf(_v, "WebSocket header value")

        if self._is_asgi:
            # ASGI: consume the connect message, then emit accept.
            msg = await self._asgi_receive()
            if msg["type"] != "websocket.connect":
                raise RuntimeError(f"expected websocket.connect, got {msg['type']!r}")
            accept_msg: dict[str, Any] = {"type": "websocket.accept"}
            if subprotocol:
                accept_msg["subprotocol"] = subprotocol
            if headers:
                accept_msg["headers"] = [
                    (k.encode("latin-1"), v.encode("latin-1")) for k, v in headers.items()
                ]
            await self._asgi_send(accept_msg)
            self._accepted = True
            return

        # Raw-transport mode (HTTP/1.1 101 handshake).
        key = self.headers.get("sec-websocket-key", "")
        accept_key = base64.b64encode(
            hashlib.sha1((key + self.GUID).encode()).digest()  # noqa: S324
        ).decode()

        lines = [
            "HTTP/1.1 101 Switching Protocols",
            "Upgrade: websocket",
            "Connection: Upgrade",
            f"Sec-WebSocket-Accept: {accept_key}",
        ]
        if subprotocol:
            lines.append(f"Sec-WebSocket-Protocol: {subprotocol}")
        if headers:
            for k, v in headers.items():
                lines.append(f"{k}: {v}")
        response = "\r\n".join(lines) + "\r\n\r\n"
        self.transport.write(response.encode())
        self._accepted = True

    async def send_text(self, data: str) -> None:
        """Send a text frame."""
        if not self._accepted:
            raise RuntimeError("WebSocket.send_text(): call accept() before sending")
        if self._closed:
            raise WebSocketDisconnect()
        if self._is_asgi:
            await self._asgi_send({"type": "websocket.send", "text": data})
            return
        self._send_frame(data.encode("utf-8"), opcode=0x1)

    async def send_json(self, data: Any, mode: str = "text") -> None:
        """Send JSON data.

        `mode="text"` (default) wraps the JSON in a text frame (opcode 0x1).
        `mode="binary"` sends the raw JSON bytes as a binary frame (0x2).
        """
        if mode not in ("text", "binary"):
            raise ValueError(f"mode must be 'text' or 'binary', got {mode!r}")
        payload = orjson.dumps(data)
        if mode == "binary":
            await self.send_bytes(payload)
        else:
            await self.send_text(payload.decode("utf-8"))

    async def send_bytes(self, data: bytes) -> None:
        """Send a binary frame."""
        if not self._accepted:
            raise RuntimeError("WebSocket.send_bytes(): call accept() before sending")
        if self._closed:
            raise WebSocketDisconnect()
        if self._is_asgi:
            await self._asgi_send({"type": "websocket.send", "bytes": data})
            return
        self._send_frame(data, opcode=0x2)

    async def _asgi_recv_msg(self) -> dict:
        msg = await self._asgi_receive()
        if msg["type"] == "websocket.disconnect":
            self._closed = True
            raise WebSocketDisconnect()
        return msg

    async def receive(self) -> dict:
        """Receive a raw ASGI WebSocket message.

        Returns the message dict as the ASGI server delivered it
        (`{"type": "websocket.receive", "text"/"bytes": ...}`). A
        `websocket.disconnect` message raises `WebSocketDisconnect`.
        ASGI-mode only — raw asyncio-transport connections don't carry
        ASGI message envelopes.

        The same handshake state machine the typed `receive_*` helpers
        enforce: the raw escape hatch must not be a way around
        receive-before-accept or receive-after-close (which would
        consume the `websocket.connect` envelope and corrupt the next
        `accept()`).
        """
        self._check_can_receive("receive")
        if not self._is_asgi:
            raise RuntimeError(
                "WebSocket.receive() is ASGI-mode only; use receive_text/"
                "receive_bytes for raw asyncio-transport connections"
            )
        return await self._asgi_recv_msg()

    async def send(self, message: dict) -> None:
        """Send a raw ASGI WebSocket message.

        `message` is forwarded straight to the ASGI `send` callable,
        e.g. `{"type": "websocket.send", "text": "..."}`.
        """
        # Same handshake state machine the typed send_* helpers enforce:
        # the raw escape hatch must not be a way around accept-before-send
        # or send-after-close.
        if not self._accepted:
            raise RuntimeError("WebSocket.send(): call accept() before sending")
        if self._closed:
            raise WebSocketDisconnect()
        if not self._is_asgi:
            raise RuntimeError(
                "WebSocket.send() is ASGI-mode only; use send_text/send_bytes "
                "for raw asyncio-transport connections"
            )
        await self._asgi_send(message)

    def _check_can_receive(self, method: str) -> None:
        """Enforce the handshake state machine for receive operations.

        Mirrors the `send_text`/`send_bytes` guards — a handler that
        calls a receive method before `accept()` would otherwise hang on
        an empty queue (raw transport) or on the ASGI receive callable
        (ASGI mode), with no clear failure mode. A receive on a
        already-closed connection is a `WebSocketDisconnect`.
        """
        if not self._accepted:
            raise RuntimeError(f"WebSocket.{method}(): call accept() before receiving")
        if self._closed:
            raise WebSocketDisconnect()

    async def receive_text(self, timeout: float | None = None) -> str:
        """Receive a text message. Raises asyncio.TimeoutError if timeout exceeded."""
        self._check_can_receive("receive_text")
        if self._is_asgi:
            msg = await asyncio.wait_for(self._asgi_recv_msg(), timeout=timeout)
            data = msg.get("text") or (msg.get("bytes") or b"").decode("utf-8")
            return data
        data = await asyncio.wait_for(self._receive_queue.get(), timeout=timeout)
        return data.decode("utf-8") if isinstance(data, bytes) else str(data)

    async def receive_json(self, timeout: float | None = None) -> Any:
        """Receive and parse JSON."""
        # Routes through `receive_text`, which enforces the state guards.
        text = await self.receive_text(timeout=timeout)
        return orjson.loads(text)

    async def receive_bytes(self, timeout: float | None = None) -> bytes:
        """Receive binary data. Raises asyncio.TimeoutError if timeout exceeded."""
        self._check_can_receive("receive_bytes")
        if self._is_asgi:
            msg = await asyncio.wait_for(self._asgi_recv_msg(), timeout=timeout)
            return msg.get("bytes") or msg.get("text", "").encode("utf-8")
        return await asyncio.wait_for(self._receive_queue.get(), timeout=timeout)

    async def iter_text(self) -> Any:
        """Async-iterate over incoming text frames until the peer closes.

        Usage:
            async for msg in ws.iter_text():
                ...

        Terminates cleanly on `WebSocketDisconnect`. Other exceptions
        propagate.
        """
        from veloce.exceptions import WebSocketDisconnect

        try:
            while True:
                yield await self.receive_text()
        except WebSocketDisconnect:
            return

    async def iter_bytes(self) -> Any:
        """Async-iterate over incoming binary frames until the peer closes."""
        from veloce.exceptions import WebSocketDisconnect

        try:
            while True:
                yield await self.receive_bytes()
        except WebSocketDisconnect:
            return

    async def iter_json(self) -> Any:
        """Async-iterate over incoming JSON-decoded frames until peer closes."""
        from veloce.exceptions import WebSocketDisconnect

        try:
            while True:
                yield await self.receive_json()
        except WebSocketDisconnect:
            return

    async def close(self, code: int = 1000, reason: str = "") -> None:
        """Send a close frame.

        Per RFC 6455 §5.5.1 the close-frame payload is a 2-byte big-endian
        status code optionally followed by a UTF-8 reason of at most
        123 bytes (so the whole payload fits in the 125-byte
        control-frame budget). Reasons longer than 123 bytes are
        truncated to a clean UTF-8 boundary.
        """
        if self._closed:
            return
        self._closed = True
        if self._is_asgi:
            await self._asgi_send({"type": "websocket.close", "code": code, "reason": reason or ""})
            return
        payload = struct.pack("!H", code)
        if reason:
            reason_bytes = reason.encode("utf-8")[:123]
            # Walk back from a 123-byte truncation if the byte boundary
            # landed mid-codepoint — keeps the close-frame valid UTF-8.
            while reason_bytes:
                try:
                    reason_bytes.decode("utf-8")
                    break
                except UnicodeDecodeError:
                    reason_bytes = reason_bytes[:-1]
            payload += reason_bytes
        self._send_frame(payload, opcode=0x8)
        self.transport.close()

    def feed_data(self, data: bytes) -> None:
        """Feed one raw WebSocket frame from the transport (called by the
        protocol).

        Handles fragmented messages (RFC 6455 §5.4): a data frame with
        `FIN=0` opens a message that subsequent continuation frames
        (opcode `0x0`) extend, and the `FIN=1` continuation completes it.
        Control frames (close / ping / pong) are never fragmented and may
        be interleaved within a fragmented message without disturbing the
        reassembly buffer.
        """
        # One frame is assumed to arrive per call — a frame split across
        # transport reads is dropped by the length guards below.
        if len(data) < 2:
            return

        fin = bool(data[0] & 0x80)
        opcode = data[0] & 0x0F
        masked = bool(data[1] & 0x80)
        payload_len = data[1] & 0x7F

        offset = 2
        if payload_len == 126:
            if len(data) < 4:
                return
            payload_len = struct.unpack("!H", data[2:4])[0]
            offset = 4
        elif payload_len == 127:
            if len(data) < 10:
                return
            payload_len = struct.unpack("!Q", data[2:10])[0]
            offset = 10

        if masked:
            if len(data) < offset + 4:
                return
            mask = data[offset : offset + 4]
            offset += 4

        if len(data) < offset + payload_len:
            return

        payload_bytes = bytes(data[offset : offset + payload_len])
        if masked and payload_len:
            # Bulk XOR via Python's bignum int. Tile the 4-byte mask to
            # the payload length and XOR in a single C-level op — far
            # cheaper than a Python-level per-byte loop for any frame
            # past a handful of bytes (and WebSocket frames are usually
            # hundreds to KiB-sized).
            tiled = (mask * ((payload_len + 3) // 4))[:payload_len]
            payload_bytes = (
                int.from_bytes(payload_bytes, "big") ^ int.from_bytes(tiled, "big")
            ).to_bytes(payload_len, "big")
        payload = bytearray(payload_bytes)

        # Control frames (close / ping / pong) — never fragmented; handled
        # independently of any fragmented message in progress.
        if opcode == 0x8:  # Close
            self._closed = True
            raise WebSocketDisconnect()
        if opcode == 0x9:  # Ping
            self._send_frame(bytes(payload), opcode=0xA)  # Pong
            return
        if opcode == 0xA:  # Pong — no application-level action.
            return

        # Data frames (text / binary) and continuation frames.
        if opcode in (0x1, 0x2):
            # A data frame must not arrive mid-fragmentation — RFC 6455
            # §5.4 allows only continuation frames after the opening
            # frame. If a peer sends one anyway, discard the abandoned
            # partial and clear the reassembly state cleanly so a later
            # continuation cannot append to a stale buffer.
            if fin:
                # Unfragmented message — deliver immediately.
                self._frag_opcode = None
                self._frag_buffer = bytearray()
                self._enqueue_or_close(bytes(payload))
            else:
                # Opening frame of a fragmented message — start buffering
                # (supersedes any abandoned partial).
                self._frag_opcode = opcode
                self._frag_buffer = bytearray(payload)
        elif opcode == 0x0:  # Continuation frame.
            if self._frag_opcode is None:
                # A continuation with no message in progress is a protocol
                # error — drop the stray frame rather than corrupt state.
                return
            self._frag_buffer += payload
            if fin:
                # Final fragment — the reassembled message is complete.
                self._enqueue_or_close(bytes(self._frag_buffer))
                self._frag_opcode = None
                self._frag_buffer = bytearray()

    def _enqueue_or_close(self, payload: bytes) -> None:
        """Push a reassembled message onto the receive queue.

        The queue has a finite `maxsize`; if a peer outpaces the
        application reader it fills up. `put_nowait` raising
        `QueueFull` is the backpressure signal at this layer — we
        close the connection with `1009 Message Too Big` rather than
        let the exception unwind into the asyncio Protocol callback,
        and rather than grow the queue without bound (the DoS the
        cap was added to prevent).
        """
        try:
            self._receive_queue.put_nowait(payload)
        except asyncio.QueueFull:
            # Close synchronously — no `await` available from inside
            # `feed_data`. The frame writer is synchronous and only
            # needs the transport.
            with contextlib.suppress(Exception):
                self._send_frame(
                    (1009).to_bytes(2, "big"),
                    opcode=0x8,  # Close
                )
            self._closed = True
            with contextlib.suppress(Exception):
                if self.transport is not None:
                    self.transport.close()

    def _send_frame(self, data: bytes, opcode: int) -> None:
        """Send a WebSocket frame.

        The header is built into a small bytearray and the payload is
        handed to the transport via `writelines` — that avoids a
        bytearray.extend copy of the (potentially KiB-sized) payload
        followed by a `bytes(frame)` copy on the way out the door.
        """
        header = bytearray()
        header.append(0x80 | opcode)  # FIN + opcode

        length = len(data)
        if length < 126:
            header.append(length)
        elif length < 65536:
            header.append(126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(127)
            header.extend(struct.pack("!Q", length))

        # `transport.writelines` (where supported) keeps the header and
        # payload as separate buffers; otherwise fall back to a single
        # concatenated `write` for transports / test fakes that only
        # implement the basic `WriteTransport` API.
        writelines = getattr(self.transport, "writelines", None)
        if writelines is not None:
            writelines((bytes(header), data))
        else:
            self.transport.write(bytes(header) + bytes(data))
