import datetime
import inspect
import itertools
import re
import socket
import time
from inspect import isclass
from io import BytesIO
from operator import itemgetter

import gridfs
import pymongo
from bson import SON, DBRef, ObjectId
from pymongo import ReturnDocument

from autonomous import log

try:
    import dateutil
except ImportError:
    dateutil = None
else:
    import dateutil.parser

from autonomous.db.base import (
    BaseDocument,
    BaseField,
    ComplexBaseField,
    ObjectIdField,
    get_document,
)
from autonomous.db.base.utils import LazyRegexCompiler
from autonomous.db.connection import DEFAULT_CONNECTION_NAME, get_db
from autonomous.db.document import Document, EmbeddedDocument
from autonomous.db.errors import (
    DoesNotExist,
    InvalidQueryError,
    ValidationError,
)
from autonomous.db.queryset import DO_NOTHING
from autonomous.db.queryset.base import BaseQuerySet
from autonomous.db.queryset.transform import STRING_OPERATORS

try:
    from PIL import Image, ImageOps, UnidentifiedImageError

    if hasattr(Image, "Resampling"):
        LANCZOS = Image.Resampling.LANCZOS
    else:
        LANCZOS = Image.LANCZOS
except ImportError:
    # pillow is optional so may not be installed
    Image = None

    class UnidentifiedImageError(Exception):  # type: ignore[no-redef]
        """Shim so ImageField's except tuple is valid when Pillow is absent."""
    ImageOps = None


__all__ = (
    "StringField",
    "EmailField",
    "IntField",
    "FloatField",
    "BooleanField",
    "DateTimeField",
    "DateField",
    "EmbeddedDocumentField",
    "ObjectIdField",
    "DynamicField",
    "ListField",
    "EmbeddedDocumentListField",
    "DictField",
    "ReferenceField",
    "GenericReferenceField",
    "GridFSError",
    "GridFSProxy",
    "FileField",
    "ImageGridFsProxy",
    "ImproperlyConfigured",
    "ImageField",
    "EnumField",
)

RECURSIVE_REFERENCE_CONSTANT = "self"


class StringField(BaseField):
    """A unicode string field."""

    def __init__(self, regex=None, max_length=None, min_length=None, **kwargs):
        """
        :param regex: (optional) A string pattern that will be applied during validation
        :param max_length: (optional) A max length that will be applied during validation
        :param min_length: (optional) A min length that will be applied during validation
        :param kwargs: Keyword arguments passed into the parent :class:`~autonomous.db.BaseField`
        """
        self.regex = re.compile(regex) if regex else None
        self.max_length = max_length
        self.min_length = min_length
        super().__init__(**kwargs)

    def to_python(self, value):
        if isinstance(value, str):
            return value
        try:
            value = value.decode("utf-8")
        except (UnicodeDecodeError, AttributeError):
            # Non-utf8 bytes or a type without .decode — leave as-is so
            # downstream validate() can complain clearly.
            pass
        return value

    def validate(self, value):
        if not isinstance(value, str):
            self.error("StringField only accepts string values")

        if self.max_length is not None and len(value) > self.max_length:
            self.error("String value is too long")

        if self.min_length is not None and len(value) < self.min_length:
            self.error("String value is too short")

        if self.regex is not None and self.regex.match(value) is None:
            self.error("String value did not match validation regex")

    def lookup_member(self, member_name):
        return None

    def prepare_query_value(self, op, value):
        if not isinstance(op, str):
            return value

        if op in STRING_OPERATORS:
            case_insensitive = op.startswith("i")
            op = op.lstrip("i")

            flags = re.IGNORECASE if case_insensitive else 0

            regex = r"%s"
            if op == "startswith":
                regex = r"^%s"
            elif op == "endswith":
                regex = r"%s$"
            elif op == "exact":
                regex = r"^%s$"
            elif op == "wholeword":
                regex = r"\b%s\b"
            elif op == "regex":
                regex = value

            if op == "regex":
                value = re.compile(regex, flags)
            else:
                # escape unsafe characters which could lead to a re.error
                value = re.escape(value)
                value = re.compile(regex % value, flags)
        return super().prepare_query_value(op, value)


class EmailField(StringField):
    """A field that validates input as an email address."""

    USER_REGEX = LazyRegexCompiler(
        # `dot-atom` defined in RFC 5322 Section 3.2.3.
        r"(^[-!#$%&'*+/=?^_`{}|~0-9A-Z]+(\.[-!#$%&'*+/=?^_`{}|~0-9A-Z]+)*\Z"
        # `quoted-string` defined in RFC 5322 Section 3.2.4.
        r'|^"([\001-\010\013\014\016-\037!#-\[\]-\177]|\\[\001-\011\013\014\016-\177])*"\Z)',
        re.IGNORECASE,
    )

    UTF8_USER_REGEX = LazyRegexCompiler(
        (
            # RFC 6531 Section 3.3 extends `atext` (used by dot-atom) to
            # include `UTF8-non-ascii`.
            r"(^[-!#$%&'*+/=?^_`{}|~0-9A-Z\u0080-\U0010FFFF]+(\.[-!#$%&'*+/=?^_`{}|~0-9A-Z\u0080-\U0010FFFF]+)*\Z"
            # `quoted-string`
            r'|^"([\001-\010\013\014\016-\037!#-\[\]-\177]|\\[\001-\011\013\014\016-\177])*"\Z)'
        ),
        re.IGNORECASE | re.UNICODE,
    )

    DOMAIN_REGEX = LazyRegexCompiler(
        r"((?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+)(?:[A-Z0-9-]{2,63}(?<!-))\Z",
        re.IGNORECASE,
    )

    error_msg = "Invalid email address: %s"

    def __init__(
        self,
        domain_whitelist=None,
        allow_utf8_user=False,
        allow_ip_domain=False,
        *args,
        **kwargs,
    ):
        """
        :param domain_whitelist: (optional) list of valid domain names applied during validation
        :param allow_utf8_user: Allow user part of the email to contain utf8 char
        :param allow_ip_domain: Allow domain part of the email to be an IPv4 or IPv6 address
        :param kwargs: Keyword arguments passed into the parent :class:`~autonomous.db.StringField`
        """
        self.domain_whitelist = domain_whitelist or []
        self.allow_utf8_user = allow_utf8_user
        self.allow_ip_domain = allow_ip_domain
        super().__init__(*args, **kwargs)

    def validate_user_part(self, user_part):
        """Validate the user part of the email address. Return True if
        valid and False otherwise.
        """
        if self.allow_utf8_user:
            return self.UTF8_USER_REGEX.match(user_part)
        return self.USER_REGEX.match(user_part)

    def validate_domain_part(self, domain_part):
        """Validate the domain part of the email address. Return True if
        valid and False otherwise.
        """
        # Skip domain validation if it's in the whitelist.
        if domain_part in self.domain_whitelist:
            return True

        if self.DOMAIN_REGEX.match(domain_part):
            return True

        # Validate IPv4/IPv6, e.g. user@[192.168.0.1]
        if self.allow_ip_domain and domain_part[0] == "[" and domain_part[-1] == "]":
            for addr_family in (socket.AF_INET, socket.AF_INET6):
                try:
                    socket.inet_pton(addr_family, domain_part[1:-1])
                    return True
                except (OSError, UnicodeEncodeError):
                    pass

        return False

    def validate(self, value):
        super().validate(value)

        if "@" not in value:
            self.error(self.error_msg % value)

        user_part, domain_part = value.rsplit("@", 1)

        # Validate the user part.
        if not self.validate_user_part(user_part):
            self.error(self.error_msg % value)

        # Validate the domain and, if invalid, see if it's IDN-encoded.
        if not self.validate_domain_part(domain_part):
            try:
                domain_part = domain_part.encode("idna").decode("ascii")
            except UnicodeError:
                self.error(
                    "{} {}".format(
                        self.error_msg % value, "(domain failed IDN encoding)"
                    )
                )
            else:
                if not self.validate_domain_part(domain_part):
                    self.error(
                        "{} {}".format(
                            self.error_msg % value, "(domain validation failed)"
                        )
                    )


class IntField(BaseField):
    """32-bit integer field."""

    def __init__(self, min_value=None, max_value=None, **kwargs):
        """
        :param min_value: (optional) A min value that will be applied during validation
        :param max_value: (optional) A max value that will be applied during validation
        :param kwargs: Keyword arguments passed into the parent :class:`~autonomous.db.BaseField`
        """
        self.min_value, self.max_value = min_value, max_value
        super().__init__(**kwargs)

    def to_python(self, value):
        try:
            value = int(value)
        except (TypeError, ValueError):
            pass
        return value

    def validate(self, value):
        try:
            value = int(value)
        except (TypeError, ValueError):
            self.error("%s could not be converted to int" % value)

        if self.min_value is not None and value < self.min_value:
            self.error("Integer value is too small")

        if self.max_value is not None and value > self.max_value:
            self.error("Integer value is too large")

    def prepare_query_value(self, op, value):
        if value is None:
            return value

        return super().prepare_query_value(op, int(value))


class FloatField(BaseField):
    """Floating point number field."""

    def __init__(self, min_value=None, max_value=None, **kwargs):
        """
        :param min_value: (optional) A min value that will be applied during validation
        :param max_value: (optional) A max value that will be applied during validation
        :param kwargs: Keyword arguments passed into the parent :class:`~autonomous.db.BaseField`
        """
        self.min_value, self.max_value = min_value, max_value
        super().__init__(**kwargs)

    def to_python(self, value):
        try:
            value = float(value)
        except ValueError:
            pass
        return value

    def validate(self, value):
        if isinstance(value, int):
            try:
                value = float(value)
            except OverflowError:
                self.error("The value is too large to be converted to float")

        if not isinstance(value, float):
            self.error("FloatField only accepts float and integer values")

        if self.min_value is not None and value < self.min_value:
            self.error("Float value is too small")

        if self.max_value is not None and value > self.max_value:
            self.error("Float value is too large")

    def prepare_query_value(self, op, value):
        if value is None:
            return value

        return super().prepare_query_value(op, float(value))


class BooleanField(BaseField):
    """Boolean field type."""

    def to_python(self, value):
        try:
            value = bool(value)
        except (ValueError, TypeError):
            pass
        return value

    def validate(self, value):
        if not isinstance(value, bool):
            self.error("BooleanField only accepts boolean values")


class DateTimeField(BaseField):
    """Datetime field.

    Uses the python-dateutil library if available alternatively use time.strptime
    to parse the dates.  Note: python-dateutil's parser is fully featured and when
    installed you can utilise it to convert varying types of date formats into valid
    python datetime objects.

    Note: To default the field to the current datetime, use: DateTimeField(default=datetime.utcnow)

    Note: Microseconds are rounded to the nearest millisecond.
    """

    def validate(self, value):
        new_value = self.to_mongo(value)
        if not isinstance(new_value, (datetime.datetime, datetime.date)):
            self.error('cannot parse date "%s"' % value)

    def to_mongo(self, value):
        if value is None:
            return value
        if isinstance(value, datetime.datetime):
            return value
        if isinstance(value, datetime.date):
            return datetime.datetime(value.year, value.month, value.day)
        if callable(value):
            return value()

        if isinstance(value, str):
            return self._parse_datetime(value)
        else:
            return None

    @staticmethod
    def _parse_datetime(value):
        # Attempt to parse a datetime from a string
        value = value.strip()
        if not value:
            return None

        if dateutil:
            try:
                return dateutil.parser.parse(value)
            except (TypeError, ValueError, OverflowError):
                return None

        # split usecs, because they are not recognized by strptime.
        if "." in value:
            try:
                value, usecs = value.split(".")
                usecs = int(usecs)
            except ValueError:
                return None
        else:
            usecs = 0
        kwargs = {"microsecond": usecs}
        try:  # Seconds are optional, so try converting seconds first.
            return datetime.datetime(
                *time.strptime(value, "%Y-%m-%d %H:%M:%S")[:6], **kwargs
            )
        except ValueError:
            try:  # Try without seconds.
                return datetime.datetime(
                    *time.strptime(value, "%Y-%m-%d %H:%M")[:5], **kwargs
                )
            except ValueError:  # Try without hour/minutes/seconds.
                try:
                    return datetime.datetime(
                        *time.strptime(value, "%Y-%m-%d")[:3], **kwargs
                    )
                except ValueError:
                    return None

    def prepare_query_value(self, op, value):
        return super().prepare_query_value(op, self.to_mongo(value))


class DateField(DateTimeField):
    def to_mongo(self, value):
        value = super().to_mongo(value)
        # drop hours, minutes, seconds
        if isinstance(value, datetime.datetime):
            value = datetime.datetime(value.year, value.month, value.day)
        return value

    def to_python(self, value):
        value = super().to_python(value)
        # convert datetime to date
        if isinstance(value, datetime.datetime):
            value = datetime.date(value.year, value.month, value.day)
        return value


class EmbeddedDocumentField(BaseField):
    """An embedded document field - with a declared document_type.
    Only valid values are subclasses of :class:`~autonomous.db.EmbeddedDocument`.
    """

    def __init__(self, document_type, **kwargs):
        if not (
            isinstance(document_type, str)
            or issubclass(document_type, EmbeddedDocument)
        ):
            self.error(
                "Invalid embedded document class provided to an EmbeddedDocumentField"
            )

        self.document_type_obj = document_type
        super().__init__(**kwargs)

    @property
    def document_type(self):
        if isinstance(self.document_type_obj, str):
            if self.document_type_obj == RECURSIVE_REFERENCE_CONSTANT:
                resolved_document_type = self.owner_document
            else:
                resolved_document_type = get_document(self.document_type_obj)

            if not issubclass(resolved_document_type, EmbeddedDocument):
                # Due to the late resolution of the document_type
                # There is a chance that it won't be an EmbeddedDocument (#1661)
                self.error(
                    "Invalid embedded document class provided to an "
                    "EmbeddedDocumentField"
                )
            self.document_type_obj = resolved_document_type

        return self.document_type_obj

    def to_python(self, value):
        if not isinstance(value, self.document_type):
            return self.document_type._from_son(
                value, _auto_dereference=self._auto_dereference
            )
        return value

    def to_mongo(self, value, use_db_field=True, fields=None):
        if not isinstance(value, self.document_type):
            return value
        return self.document_type.to_mongo(value, use_db_field, fields)

    def validate(self, value, clean=True):
        """Make sure that the document instance is an instance of the
        EmbeddedDocument subclass provided when the document was defined.
        """
        # Using isinstance also works for subclasses of self.document
        if not isinstance(value, self.document_type):
            self.error(
                "Invalid embedded document instance provided to an "
                "EmbeddedDocumentField"
            )
        value.validate(clean=clean)

    def lookup_member(self, member_name):
        doc_and_subclasses = [self.document_type] + self.document_type.__subclasses__()
        for doc_type in doc_and_subclasses:
            field = doc_type._fields.get(member_name)
            if field:
                return field

    def prepare_query_value(self, op, value):
        if value is not None and not isinstance(value, self.document_type):
            # Short circuit for special operators, returning them as is
            if isinstance(value, dict) and all(k.startswith("$") for k in value.keys()):
                return value
            try:
                value = self.document_type._from_son(value)
            except ValueError:
                raise InvalidQueryError(
                    "Querying the embedded document '%s' failed, due to an invalid query value"
                    % (self.document_type._class_name,)
                )
        super().prepare_query_value(op, value)
        return self.to_mongo(value)


class DynamicField(BaseField):
    """A truly dynamic field type capable of handling different and varying
    types of data.

    Used by :class:`~autonomous.db.DynamicDocument` to handle dynamic data"""

    def to_mongo(self, value, use_db_field=True, fields=None):
        """Convert a Python type to a MongoDB compatible type."""

        if isinstance(value, str):
            return value

        if hasattr(value, "to_mongo"):
            cls = value.__class__
            val = value.to_mongo(use_db_field, fields)
            # If we its a document thats not inherited add _cls
            if isinstance(value, Document):
                val = {"_ref": value.to_dbref(), "_cls": cls.__name__}
            if isinstance(value, EmbeddedDocument):
                val["_cls"] = cls.__name__
            return val

        if not isinstance(value, (dict, list, tuple)):
            return value

        is_list = False
        if not hasattr(value, "items"):
            is_list = True
            value = {k: v for k, v in enumerate(value)}

        data = {}
        for k, v in value.items():
            data[k] = self.to_mongo(v, use_db_field, fields)

        value = data
        if is_list:  # Convert back to a list
            value = [v for k, v in sorted(data.items(), key=itemgetter(0))]
        return value

    def to_python(self, value):
        if isinstance(value, dict) and "_cls" in value:
            doc_cls = get_document(value["_cls"])
            if "_ref" in value:
                value = doc_cls._get_db().dereference(value["_ref"])
            return doc_cls._from_son(value)

        return super().to_python(value)

    def lookup_member(self, member_name):
        return member_name

    def prepare_query_value(self, op, value):
        if isinstance(value, str):
            return StringField().prepare_query_value(op, value)
        return super().prepare_query_value(op, self.to_mongo(value))

    def validate(self, value, clean=True):
        if hasattr(value, "validate"):
            value.validate(clean=clean)


class ListField(ComplexBaseField):
    """A list field that wraps a standard field, allowing multiple instances
    of the field to be used as a list in the database.

    If using with ReferenceFields see: :ref:`many-to-many-with-listfields`

    .. note::
        Required means it cannot be empty - as the default for ListFields is []
    """

    def __init__(self, field=None, *, max_length=None, **kwargs):
        self.max_length = max_length
        if not kwargs.get("default"):
            kwargs["default"] = list
        super().__init__(field=field, **kwargs)

    def __get__(self, instance, owner):
        if instance is None:
            # Document class being used rather than a document object
            return self
        return super().__get__(instance, owner)

    def validate(self, value):
        """Make sure that a list of valid fields is being used."""
        if not isinstance(value, (list, tuple, BaseQuerySet)):
            self.error("Only lists and tuples may be used in a list field")

        # Validate that max_length is not exceeded.
        # NOTE It's still possible to bypass this enforcement by using $push.
        # However, if the document is reloaded after $push and then re-saved,
        # the validation error will be raised.
        if self.max_length is not None and len(value) > self.max_length:
            self.error("List is too long")

        super().validate(value)

    def prepare_query_value(self, op, value):
        # Validate that the `set` operator doesn't contain more items than `max_length`.
        if op == "set" and self.max_length is not None and len(value) > self.max_length:
            self.error("List is too long")

        if self.field:
            # If the value is iterable and it's not a string nor a
            # BaseDocument, call prepare_query_value for each of its items.
            is_iter = hasattr(value, "__iter__")
            eligible_iter = is_iter and not isinstance(value, (str, BaseDocument))
            if (
                op in ("set", "unset", "gt", "gte", "lt", "lte", "ne", None)
                and eligible_iter
            ):
                return [self.field.prepare_query_value(op, v) for v in value]

            return self.field.prepare_query_value(op, value)

        return super().prepare_query_value(op, value)


class EmbeddedDocumentListField(ListField):
    """A :class:`~autonomous.db.ListField` designed specially to hold a list of
    embedded documents to provide additional query helpers.

    .. note::
        The only valid list values are subclasses of
        :class:`~autonomous.db.EmbeddedDocument`.
    """

    def __init__(self, document_type, **kwargs):
        """
        :param document_type: The type of
         :class:`~autonomous.db.EmbeddedDocument` the list will hold.
        :param kwargs: Keyword arguments passed into the parent :class:`~autonomous.db.ListField`
        """
        super().__init__(field=EmbeddedDocumentField(document_type), **kwargs)


def key_not_string(d):
    """Helper function to recursively determine if any key in a
    dictionary is not a string.
    """
    for k, v in d.items():
        if not isinstance(k, str) or (isinstance(v, dict) and key_not_string(v)):
            return True


def key_starts_with_dollar(d):
    """Helper function to recursively determine if any key in a
    dictionary starts with a dollar
    """
    for k, v in d.items():
        if (k.startswith("$")) or (isinstance(v, dict) and key_starts_with_dollar(v)):
            return True


class DictField(ComplexBaseField):
    """A dictionary field that wraps a standard Python dictionary. This is
    similar to an embedded document, but the structure is not defined.

    .. note::
        Required means it cannot be empty - as the default for DictFields is {}
    """

    def __init__(self, field=None, *args, **kwargs):
        kwargs.setdefault("default", dict)
        super().__init__(*args, field=field, **kwargs)
        self.set_auto_dereferencing(False)

    def validate(self, value):
        """Make sure that a list of valid fields is being used."""
        if not isinstance(value, dict):
            self.error("Only dictionaries may be used in a DictField")

        if key_not_string(value):
            msg = "Invalid dictionary key - documents must have only string keys"
            self.error(msg)

        # Following condition applies to MongoDB >= 3.6
        # older Mongo has stricter constraints but
        # it will be rejected upon insertion anyway
        # Having a validation that depends on the MongoDB version
        # is not straightforward as the field isn't aware of the connected Mongo
        if key_starts_with_dollar(value):
            self.error(
                'Invalid dictionary key name - keys may not startswith "$" characters'
            )
        super().validate(value)

    def lookup_member(self, member_name):
        return DictField(db_field=member_name)

    def prepare_query_value(self, op, value):
        match_operators = [*STRING_OPERATORS]

        if op in match_operators and isinstance(value, str):
            return StringField().prepare_query_value(op, value)

        if hasattr(
            self.field, "field"
        ):  # Used for instance when using DictField(ListField(IntField()))
            if op in ("set", "unset") and isinstance(value, dict):
                return {
                    k: self.field.prepare_query_value(op, v) for k, v in value.items()
                }
            return self.field.prepare_query_value(op, value)

        return super().prepare_query_value(op, value)


class ReferenceField(BaseField):
    """A reference to a document that will be automatically dereferenced on
    access (lazily).

    Note this means you will get a database I/O access everytime you access
    this field. This is necessary because the field returns a :class:`~autonomous.db.Document`
    which precise type can depend of the value of the `_cls` field present in the
    document in database.
    In short, using this type of field can lead to poor performances (especially
    if you access this field only to retrieve it `pk` field which is already
    known before dereference).

    Use the `reverse_delete_rule` to handle what should happen if the document
    the field is referencing is deleted.  EmbeddedDocuments, DictFields and
    MapFields does not support reverse_delete_rule and an `InvalidDocumentError`
    will be raised if trying to set on one of these Document / Field types.

    The options are:

      * DO_NOTHING (0)  - don't do anything (default).
      * NULLIFY    (1)  - Updates the reference to null.
      * CASCADE    (2)  - Deletes the documents associated with the reference.
      * DENY       (3)  - Prevent the deletion of the reference object.
      * PULL       (4)  - Pull the reference from a :class:`~autonomous.db.fields.ListField` of references

    Alternative syntax for registering delete rules (useful when implementing
    bi-directional delete rules)

    .. code-block:: python

        class Org(Document):
            owner = ReferenceField('User')

        class User(Document):
            org = ReferenceField('Org', reverse_delete_rule=CASCADE)

        User.register_delete_rule(Org, 'owner', DENY)
    """

    def __init__(
        self, document_type, dbref=False, reverse_delete_rule=DO_NOTHING, **kwargs
    ):
        """Initialises the Reference Field.

        :param document_type: The type of Document that will be referenced
        :param dbref:  Store the reference as :class:`~pymongo.dbref.DBRef`
          or as the :class:`~pymongo.objectid.ObjectId`.
        :param reverse_delete_rule: Determines what to do when the referring
          object is deleted
        :param kwargs: Keyword arguments passed into the parent :class:`~autonomous.db.BaseField`

        .. note ::
            A reference to an abstract document type is always stored as a
            :class:`~pymongo.dbref.DBRef`, regardless of the value of `dbref`.
        """
        # XXX ValidationError raised outside of the "validate" method.
        if not (
            isinstance(document_type, str)
            or (isclass(document_type) and issubclass(document_type, Document))
        ):
            self.error(
                "Argument to ReferenceField constructor must be a "
                "document class or a string"
            )

        self.dbref = dbref
        self.document_type_obj = document_type
        self.reverse_delete_rule = reverse_delete_rule
        super().__init__(**kwargs)

    @property
    def document_type(self):
        if isinstance(self.document_type_obj, str):
            if self.document_type_obj == RECURSIVE_REFERENCE_CONSTANT:
                self.document_type_obj = self.owner_document
            else:
                self.document_type_obj = get_document(self.document_type_obj)
        return self.document_type_obj

    @staticmethod
    def _lazy_load_ref(ref_cls, dbref):
        dereferenced_son = ref_cls._get_db().dereference(dbref)
        if dereferenced_son is None:
            raise DoesNotExist(f"Trying to dereference unknown document {dbref}")

        return ref_cls._from_son(dereferenced_son)

    def __get__(self, instance, owner):
        """Descriptor to allow lazy dereferencing."""
        if instance is None:
            # Document class being used rather than a document object
            return self

        # Get value from document instance if available
        ref_value = instance._data.get(self.name)
        auto_dereference = instance._fields[self.name]._auto_dereference
        # Dereference DBRefs
        if auto_dereference and isinstance(ref_value, DBRef):
            if hasattr(ref_value, "cls"):
                # Dereference using the class type specified in the reference
                cls = get_document(ref_value.cls)
            else:
                cls = self.document_type

            instance._data[self.name] = self._lazy_load_ref(cls, ref_value)

        return super().__get__(instance, owner)

    def to_mongo(self, document):
        if isinstance(document, DBRef):
            if not self.dbref:
                return document.id
            return document

        if isinstance(document, Document):
            # We need the id from the saved object to create the DBRef
            id_ = document.pk

            # XXX ValidationError raised outside of the "validate" method.
            if id_ is None:
                self.error(
                    "You can only reference documents once they have"
                    " been saved to the database"
                )

            # Use the attributes from the document instance, so that they
            # override the attributes of this field's document type
            cls = document
        else:
            id_ = document
            cls = self.document_type

        id_field_name = cls._meta["id_field"]
        id_field = cls._fields[id_field_name]

        id_ = id_field.to_mongo(id_)
        if self.document_type._meta.get("abstract"):
            collection = cls._get_collection_name()
            return DBRef(collection, id_, cls=cls._class_name)
        elif self.dbref:
            collection = cls._get_collection_name()
            return DBRef(collection, id_)

        return id_

    def to_python(self, value):
        """Convert a MongoDB-compatible type to a Python type."""
        if not self.dbref and not isinstance(
            value, (DBRef, Document, EmbeddedDocument)
        ):
            collection = self.document_type._get_collection_name()
            value = DBRef(collection, self.document_type.id.to_python(value))
        return value

    def prepare_query_value(self, op, value):
        if value is None:
            return None
        super().prepare_query_value(op, value)
        return self.to_mongo(value)

    def validate(self, value):
        if not isinstance(value, (self.document_type, DBRef, ObjectId)):
            self.error(
                "A ReferenceField only accepts DBRef, ObjectId or documents"
            )

        if isinstance(value, Document) and value.id is None:
            self.error(
                "You can only reference documents once they have been "
                "saved to the database"
            )

    def lookup_member(self, member_name):
        return self.document_type._fields.get(member_name)



class GenericReferenceField(BaseField):
    """A reference to *any* :class:`~autonomous.db.document.Document` subclass
    that will be automatically dereferenced on access (lazily).

    Note this field works the same way as :class:`~autonomous.db.document.ReferenceField`,
    doing database I/O access the first time it is accessed (even if it's to access
    it ``pk`` or ``id`` field).

    .. note ::
        * Any documents used as a generic reference must be registered in the
          document registry.  Importing the model will automatically register
          it.

        * You can use the choices param to limit the acceptable Document types
    """

    def __init__(self, *args, **kwargs):
        choices = kwargs.pop("choices", None)
        super().__init__(*args, **kwargs)
        self.choices = []
        # Keep the choices as a list of allowed Document class names
        if choices:
            for choice in choices:
                if isinstance(choice, str):
                    self.choices.append(choice)
                elif isinstance(choice, type) and issubclass(choice, Document):
                    self.choices.append(choice.__name__)
                else:
                    # XXX ValidationError raised outside of the "validate"
                    # method.
                    self.error(
                        "Invalid choices provided: must be a list of"
                        "Document subclasses and/or str"
                    )

    def _validate_choices(self, value):
        if not value and self.null:
            return
        elif isinstance(value, dict):
            # If the field has not been dereferenced, it is still a dict
            # of class and DBRef
            # value = value.get("_cls")
            try:
                value = self._lazy_load_ref(
                    get_document(value.get("_cls")), value.get("_ref")
                )
            except DoesNotExist:
                return

        if isinstance(value, Document):
            mro = [cls.__name__ for cls in value.__class__.mro()]
            base_value = None
            for choice in self.choices:
                if choice in mro:
                    base_value = choice
                    break
            if base_value:
                value = base_value
            else:
                raise ValidationError(
                    f"Invalid Model Type. Must be or derive from on of: {self.choices}, not: {value} for attribute {self.name}"
                )
        else:
            value = value.__class__.__name__
        super()._validate_choices(value)

    @staticmethod
    def _lazy_load_ref(ref_cls, dbref):
        dereferenced_son = ref_cls._get_db().dereference(dbref)
        if dereferenced_son is None:
            raise DoesNotExist(f"Trying to dereference unknown document {dbref}")

        return ref_cls._from_son(dereferenced_son)

    def __get__(self, instance, owner):
        if instance is None:
            return self

        value = instance._data.get(self.name)

        auto_dereference = instance._fields[self.name]._auto_dereference
        if auto_dereference and isinstance(value, dict) and "_cls" in value:
            doc_cls = get_document(value["_cls"])
            instance._data[self.name] = self._lazy_load_ref(doc_cls, value["_ref"])

        return super().__get__(instance, owner)

    def validate(self, value):
        if not value and self.null:
            return
        if not isinstance(value, (Document, DBRef, dict, SON)):
            self.error("GenericReferences can only contain documents")

        if isinstance(value, (dict, SON)):
            if "_ref" not in value or "_cls" not in value:
                self.error("GenericReferences can only contain documents")

        # We need the id from the saved object to create the DBRef
        elif isinstance(value, Document) and value.id is None:
            self.error(
                "You can only reference documents once they have been"
                " saved to the database"
            )

    def to_mongo(self, document):
        if document is None:
            return None

        if isinstance(document, (dict, SON, ObjectId, DBRef)):
            return document

        id_field_name = document.__class__._meta["id_field"]
        id_field = document.__class__._fields[id_field_name]

        if isinstance(document, Document):
            # We need the id from the saved object to create the DBRef
            id_ = document.id
            if id_ is None:
                # XXX ValidationError raised outside of the "validate" method.
                self.error(
                    "You can only reference documents once they have"
                    " been saved to the database"
                )
        else:
            id_ = document

        id_ = id_field.to_mongo(id_)
        collection = document._get_collection_name()
        ref = DBRef(collection, id_)
        return SON((("_cls", document._class_name), ("_ref", ref)))

    def prepare_query_value(self, op, value):
        if value is None:
            return None

        return self.to_mongo(value)


class EnumField(BaseField):
    """Enumeration Field. Values are stored underneath as is,
    so it will only work with simple types (str, int, etc) that
    are bson encodable

    Example usage:

    .. code-block:: python

        class Status(Enum):
            NEW = 'new'
            ONGOING = 'ongoing'
            DONE = 'done'

        class ModelWithEnum(Document):
            status = EnumField(Status, default=Status.NEW)

        ModelWithEnum(status='done')
        ModelWithEnum(status=Status.DONE)

    Enum fields can be searched using enum or its value:

    .. code-block:: python

        ModelWithEnum.objects(status='new').count()
        ModelWithEnum.objects(status=Status.NEW).count()

    The values can be restricted to a subset of the enum by using the ``choices`` parameter:

    .. code-block:: python

        class ModelWithEnum(Document):
            status = EnumField(Status, choices=[Status.NEW, Status.DONE])
    """

    def __init__(self, enum, **kwargs):
        self._enum_cls = enum
        if kwargs.get("choices"):
            invalid_choices = []
            for choice in kwargs["choices"]:
                if not isinstance(choice, enum):
                    invalid_choices.append(choice)
            if invalid_choices:
                raise ValueError("Invalid choices: %r" % invalid_choices)
        else:
            kwargs["choices"] = list(self._enum_cls)  # Implicit validator
        super().__init__(**kwargs)

    def validate(self, value):
        if isinstance(value, self._enum_cls):
            return super().validate(value)
        try:
            self._enum_cls(value)
        except ValueError:
            self.error(f"{value} is not a valid {self._enum_cls}")

    def to_python(self, value):
        value = super().to_python(value)
        if not isinstance(value, self._enum_cls):
            try:
                return self._enum_cls(value)
            except ValueError:
                return value
        return value

    def __set__(self, instance, value):
        return super().__set__(instance, self.to_python(value))

    def to_mongo(self, value):
        if isinstance(value, self._enum_cls):
            return value.value
        return value

    def prepare_query_value(self, op, value):
        if value is None:
            return value
        return super().prepare_query_value(op, self.to_mongo(value))


class GridFSError(Exception):
    pass


class GridFSProxy:
    """Proxy object to handle writing and reading of files to and from GridFS"""

    _fs = None

    def __init__(
        self,
        grid_id=None,
        key=None,
        instance=None,
        db_alias=DEFAULT_CONNECTION_NAME,
        collection_name="fs",
    ):
        self.grid_id = grid_id  # Store GridFS id for file
        self.key = key
        self.instance = instance
        self.db_alias = db_alias
        self.collection_name = collection_name
        self.newfile = None  # Used for partial writes
        self.gridout = None

    def __getattr__(self, name):
        attrs = (
            "_fs",
            "grid_id",
            "key",
            "instance",
            "db_alias",
            "collection_name",
            "newfile",
            "gridout",
        )
        if name in attrs:
            return self.__getattribute__(name)
        obj = self.get()
        if hasattr(obj, name):
            return getattr(obj, name)
        raise AttributeError

    def __get__(self, instance, value):
        return self

    def __bool__(self):
        return bool(self.grid_id)

    def __getstate__(self):
        self_dict = self.__dict__
        self_dict["_fs"] = None
        return self_dict

    def __copy__(self):
        copied = GridFSProxy()
        copied.__dict__.update(self.__getstate__())
        return copied

    def __deepcopy__(self, memo):
        return self.__copy__()

    def __repr__(self):
        return f"<{self.__class__.__name__}: {self.grid_id}>"

    def __str__(self):
        gridout = self.get()
        filename = gridout.filename if gridout else "<no file>"
        return f"<{self.__class__.__name__}: {filename} ({self.grid_id})>"

    def __eq__(self, other):
        if isinstance(other, GridFSProxy):
            return (
                (self.grid_id == other.grid_id)
                and (self.collection_name == other.collection_name)
                and (self.db_alias == other.db_alias)
            )
        else:
            return False

    def __ne__(self, other):
        return not self == other

    @property
    def fs(self):
        if not self._fs:
            self._fs = gridfs.GridFS(get_db(self.db_alias), self.collection_name)
        return self._fs

    def get(self, grid_id=None):
        if grid_id:
            self.grid_id = grid_id

        if self.grid_id is None:
            return None

        try:
            if self.gridout is None:
                self.gridout = self.fs.get(self.grid_id)
            return self.gridout
        except gridfs.errors.NoFile:
            # File has been deleted
            return None

    def new_file(self, **kwargs):
        self.newfile = self.fs.new_file(**kwargs)
        self.grid_id = self.newfile._id
        self._mark_as_changed()

    def put(self, file_obj, **kwargs):
        if self.grid_id:
            raise GridFSError(
                "This document already has a file. Either delete "
                "it or call replace to overwrite it"
            )
        self.grid_id = self.fs.put(file_obj, **kwargs)
        self._mark_as_changed()

    def write(self, string):
        if self.grid_id:
            if not self.newfile:
                raise GridFSError(
                    "This document already has a file. Either "
                    "delete it or call replace to overwrite it"
                )
        else:
            self.new_file()
        self.newfile.write(string)

    def writelines(self, lines):
        if not self.newfile:
            self.new_file()
            self.grid_id = self.newfile._id
        self.newfile.writelines(lines)

    def read(self, size=-1):
        gridout = self.get()
        if gridout is None:
            return None
        try:
            return gridout.read(size)
        except (gridfs.errors.CorruptGridFile, OSError):
            # Corrupt chunk or closed underlying cursor — treat as empty.
            return ""

    def delete(self):
        # Delete file from GridFS, FileField still remains
        self.fs.delete(self.grid_id)
        self.grid_id = None
        self.gridout = None
        self._mark_as_changed()

    def replace(self, file_obj, **kwargs):
        self.delete()
        self.put(file_obj, **kwargs)

    def close(self):
        if self.newfile:
            self.newfile.close()

    def _mark_as_changed(self):
        """Inform the instance that `self.key` has been changed"""
        if self.instance:
            self.instance._mark_as_changed(self.key)


class FileField(BaseField):
    """A GridFS storage field."""

    proxy_class = GridFSProxy

    def __init__(
        self, db_alias=DEFAULT_CONNECTION_NAME, collection_name="fs", **kwargs
    ):
        super().__init__(**kwargs)
        self.collection_name = collection_name
        self.db_alias = db_alias

    def __get__(self, instance, owner):
        if instance is None:
            return self

        # Check if a file already exists for this model
        grid_file = instance._data.get(self.name)
        if not isinstance(grid_file, self.proxy_class):
            grid_file = self.get_proxy_obj(key=self.name, instance=instance)
            instance._data[self.name] = grid_file

        if not grid_file.key:
            grid_file.key = self.name
            grid_file.instance = instance
        return grid_file

    def __set__(self, instance, value):
        key = self.name
        if (
            hasattr(value, "read") and not isinstance(value, GridFSProxy)
        ) or isinstance(value, (bytes, str)):
            # using "FileField() = file/string" notation
            grid_file = instance._data.get(self.name)
            # If a file already exists, best-effort delete. A missing
            # underlying GridFS object is fine; anything else is fine
            # too because we're about to overwrite the slot anyway.
            if grid_file:
                try:
                    grid_file.delete()
                except gridfs.errors.NoFile:
                    pass

            # Create a new proxy object as we don't already have one
            instance._data[key] = self.get_proxy_obj(key=key, instance=instance)
            instance._data[key].put(value)
        else:
            instance._data[key] = value

        instance._mark_as_changed(key)

    def get_proxy_obj(self, key, instance, db_alias=None, collection_name=None):
        if db_alias is None:
            db_alias = self.db_alias
        if collection_name is None:
            collection_name = self.collection_name

        return self.proxy_class(
            key=key,
            instance=instance,
            db_alias=db_alias,
            collection_name=collection_name,
        )

    def to_mongo(self, value):
        # Store the GridFS file id in MongoDB
        if isinstance(value, self.proxy_class) and value.grid_id is not None:
            return value.grid_id
        return None

    def to_python(self, value):
        if value is not None:
            return self.proxy_class(
                value, collection_name=self.collection_name, db_alias=self.db_alias
            )

    def validate(self, value):
        if value.grid_id is not None:
            if not isinstance(value, self.proxy_class):
                self.error("FileField only accepts GridFSProxy values")
            if not isinstance(value.grid_id, ObjectId):
                self.error("Invalid GridFSProxy value")


class ImageGridFsProxy(GridFSProxy):
    """Proxy for ImageField"""

    def put(self, file_obj, **kwargs):
        """
        Insert a image in database
        applying field properties (size, thumbnail_size)
        """
        field = self.instance._fields[self.key]
        # Handle nested fields
        if hasattr(field, "field") and isinstance(field.field, FileField):
            field = field.field

        try:
            img = Image.open(file_obj)
            img_format = img.format
        except (UnidentifiedImageError, OSError, ValueError) as e:
            raise ValidationError("Invalid image: %s" % e) from e

        # Progressive JPEG
        # TODO: fixme, at least unused, at worst bad implementation
        progressive = img.info.get("progressive") or False

        if (
            kwargs.get("progressive")
            and isinstance(kwargs.get("progressive"), bool)
            and img_format == "JPEG"
        ):
            progressive = True
        else:
            progressive = False

        if field.size and (
            img.size[0] > field.size["width"] or img.size[1] > field.size["height"]
        ):
            size = field.size

            if size["force"]:
                img = ImageOps.fit(img, (size["width"], size["height"]), LANCZOS)
            else:
                img.thumbnail((size["width"], size["height"]), LANCZOS)

        thumbnail = None
        if field.thumbnail_size:
            size = field.thumbnail_size

            if size["force"]:
                thumbnail = ImageOps.fit(img, (size["width"], size["height"]), LANCZOS)
            else:
                thumbnail = img.copy()
                thumbnail.thumbnail((size["width"], size["height"]), LANCZOS)

        if thumbnail:
            thumb_id = self._put_thumbnail(thumbnail, img_format, progressive)
        else:
            thumb_id = None

        w, h = img.size

        io = BytesIO()
        img.save(io, img_format, progressive=progressive)
        io.seek(0)

        return super().put(
            io, width=w, height=h, format=img_format, thumbnail_id=thumb_id, **kwargs
        )

    def delete(self, *args, **kwargs):
        # deletes thumbnail
        out = self.get()
        if out and out.thumbnail_id:
            self.fs.delete(out.thumbnail_id)

        return super().delete()

    def _put_thumbnail(self, thumbnail, format, progressive, **kwargs):
        w, h = thumbnail.size

        io = BytesIO()
        thumbnail.save(io, format, progressive=progressive)
        io.seek(0)

        return self.fs.put(io, width=w, height=h, format=format, **kwargs)

    @property
    def size(self):
        """
        return a width, height of image
        """
        out = self.get()
        if out:
            return out.width, out.height

    @property
    def format(self):
        """
        return format of image
        ex: PNG, JPEG, GIF, etc
        """
        out = self.get()
        if out:
            return out.format

    @property
    def thumbnail(self):
        """
        return a gridfs.grid_file.GridOut
        representing a thumbnail of Image
        """
        out = self.get()
        if out and out.thumbnail_id:
            return self.fs.get(out.thumbnail_id)

    def write(self, *args, **kwargs):
        raise RuntimeError('Please use "put" method instead')

    def writelines(self, *args, **kwargs):
        raise RuntimeError('Please use "put" method instead')


class ImproperlyConfigured(Exception):
    pass


class ImageField(FileField):
    """
    A Image File storage field.

    :param size: max size to store images, provided as (width, height, force)
        if larger, it will be automatically resized (ex: size=(800, 600, True))
    :param thumbnail_size: size to generate a thumbnail, provided as (width, height, force)
    """

    proxy_class = ImageGridFsProxy

    def __init__(
        self, size=None, thumbnail_size=None, collection_name="images", **kwargs
    ):
        if not Image:
            raise ImproperlyConfigured("PIL library was not found")

        params_size = ("width", "height", "force")
        extra_args = {"size": size, "thumbnail_size": thumbnail_size}
        for att_name, att in extra_args.items():
            value = None
            if isinstance(att, (tuple, list)):
                value = dict(itertools.zip_longest(params_size, att, fillvalue=None))

            setattr(self, att_name, value)

        super().__init__(collection_name=collection_name, **kwargs)


