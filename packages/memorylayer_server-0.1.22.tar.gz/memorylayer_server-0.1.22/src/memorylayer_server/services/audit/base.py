"""Audit Service - Pluggable audit logging interface."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import UTC, datetime
from uuid import uuid4

from ...config import DEFAULT_MEMORYLAYER_AUDIT_SERVICE, MEMORYLAYER_AUDIT_SERVICE
from .._constants import EXT_AUDIT_SERVICE
from .._plugin_factory import make_service_plugin_base

# Re-export for backward compatibility
__all__ = [
    "AuditEvent",
    "AuditService",
    "AuditServicePluginBase",
    "EXT_AUDIT_SERVICE",
]


@dataclass
class AuditEvent:
    """Structured audit event."""

    event_type: str
    """Event category: 'auth', 'memory', 'session', 'workspace', 'admin'."""

    action: str
    """Operation performed: 'create', 'read', 'update', 'delete', 'login', 'deny'."""

    tenant_id: str
    """Tenant this event belongs to."""

    workspace_id: str | None = None
    """Workspace scope, if applicable."""

    user_id: str | None = None
    """Acting user or principal, if known."""

    resource_type: str | None = None
    """Type of resource acted upon: 'memory', 'session', 'workspace', etc."""

    resource_id: str | None = None
    """Identifier of the specific resource."""

    metadata: dict = field(default_factory=dict)
    """Additional context (IP address, user-agent, request ID, etc.)."""

    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    """UTC timestamp when the event occurred."""

    id: str = field(default_factory=lambda: uuid4().hex)
    """Unique event identifier (uuid4 hex)."""


class AuditService(ABC):
    """Abstract audit service interface.

    Provides a structured event recording interface that can be implemented
    by different backends (no-op, PostgreSQL, etc.).
    """

    @abstractmethod
    async def record(self, event: AuditEvent) -> None:
        """Record a single audit event.

        Args:
            event: The audit event to record.
        """
        pass

    @abstractmethod
    async def record_batch(self, events: list[AuditEvent]) -> None:
        """Record multiple audit events in a single operation.

        Args:
            events: List of audit events to record.
        """
        pass

    @abstractmethod
    async def query(
        self,
        tenant_id: str,
        workspace_id: str | None = None,
        event_type: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[AuditEvent]:
        """Query audit events.

        Args:
            tenant_id: Tenant to query events for (required).
            workspace_id: Filter by workspace, or None for all workspaces.
            event_type: Filter by event type, or None for all types.
            since: Return only events at or after this UTC datetime.
            limit: Maximum number of events to return.

        Returns:
            List of matching audit events ordered by timestamp descending.
        """
        pass


# noinspection PyAbstractClass
AuditServicePluginBase = make_service_plugin_base(
    ext_name=EXT_AUDIT_SERVICE,
    config_key=MEMORYLAYER_AUDIT_SERVICE,
    default_value=DEFAULT_MEMORYLAYER_AUDIT_SERVICE,
)
