import json
import tarfile
import tempfile
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import click
import yaml
from rich.console import Console
from rich.table import Table

from nucl import __version__
from nucl.api import delete, get, patch, post, post_multipart
from nucl.config import clear_session, get_api_url, get_org_id, load_session, save_session, set_org_id

console = Console()


# ---------------------------------------------------------------------------
# Main group
# ---------------------------------------------------------------------------


@click.group()
@click.version_option(__version__)
def cli():
    """NUCL - Minimal ML experiment platform."""


# ---------------------------------------------------------------------------
# Auth group
# ---------------------------------------------------------------------------


@cli.group()
def auth():
    """Manage authentication."""


@auth.command("login")
@click.option("--api-url", default=None, help="API base URL")
def auth_login(api_url: str | None):
    """Log in via browser OAuth flow."""
    api_url = api_url or get_api_url()

    received_key: list[str | None] = [None]

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            qs = parse_qs(urlparse(self.path).query)
            received_key[0] = qs.get("key", [None])[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<h1>Login successful. You can close this tab.</h1>")

        def log_message(self, format, *args):
            pass  # silence request logs

    server = HTTPServer(("127.0.0.1", 0), CallbackHandler)
    port = server.server_address[1]
    url = f"{api_url}/cli-auth?port={port}"
    click.echo(f"Opening browser to {url}")
    webbrowser.open(url)

    server.handle_request()
    server.server_close()

    key = received_key[0]
    if not key:
        click.echo("Login failed: no key received.", err=True)
        raise SystemExit(1)

    save_session(key, api_url)
    click.echo("Logged in successfully.")


@auth.command("logout")
def auth_logout():
    """Clear saved session."""
    clear_session()
    click.echo("Logged out.")


@auth.command("status")
def auth_status():
    """Show current login status."""
    session = load_session()
    if session:
        click.echo(f"Logged in to {session.get('api_url', 'unknown')}")
        org = session.get("org_id")
        if org:
            click.echo(f"Active team: {org}")
        else:
            click.echo("No active team. Run: nucl team set <name>")
    else:
        click.echo("Not logged in.")


# ---------------------------------------------------------------------------
# Team group (replaces profile)
# ---------------------------------------------------------------------------


@cli.group()
def team():
    """Manage teams (Clerk Organizations)."""


@team.command("list")
def team_list():
    """List all teams you belong to."""
    data = get("/api/team/list")
    teams = data.get("teams", [])

    current = get_org_id()

    table = Table(title="Teams")
    table.add_column("")
    table.add_column("ID")
    table.add_column("Name")
    table.add_column("Role")

    for t in teams:
        marker = "*" if t.get("id") == current else ""
        table.add_row(marker, t.get("id", ""), t.get("name", ""), t.get("role", ""))

    console.print(table)


@team.command("show")
def team_show():
    """Show current team and configured platforms."""
    org_id = get_org_id()
    if not org_id:
        click.echo("No active team. Run: nucl team set <org-id>")
        raise SystemExit(1)

    data = get("/api/team/config")
    click.echo(f"  Team: {data.get('name', 'unknown')}")
    click.echo(f"  Default platform: {data.get('defaultPlatform', 'sandbox')}")
    click.echo(f"  Azure: {'configured' if data.get('azureConfigured') else 'not configured'}")
    click.echo(f"  Vertex: {'configured' if data.get('vertexConfigured') else 'not configured'}")
    click.echo("  Sandbox: always available")


@team.command("set")
@click.argument("org_id")
def team_set(org_id: str):
    """Set active team by org ID."""
    set_org_id(org_id)
    click.echo(f"Active team set to {org_id}")


@team.command("setup")
def team_setup():
    """Interactive setup using az/gcloud CLIs."""
    org_id = get_org_id()
    if not org_id:
        click.echo("No active team. Run: nucl team set <org-id>", err=True)
        raise SystemExit(1)

    import shutil

    from nucl.setup import setup_azure, setup_vertex

    has_az = shutil.which("az") is not None
    has_gcloud = shutil.which("gcloud") is not None

    if not has_az and not has_gcloud:
        click.echo("No cloud CLIs found. Install az or gcloud first.", err=True)
        raise SystemExit(1)

    platforms: list[str] = []
    if has_az and click.confirm("Configure Azure ML?", default=True):
        platforms.append("azure")
    if has_gcloud and click.confirm("Configure Vertex AI?", default=True):
        platforms.append("vertex")

    if not platforms:
        click.echo("Nothing to configure.")
        return

    for platform in platforms:
        click.echo(f"\n--- {platform.upper()} ---")
        if platform == "azure":
            credentials = setup_azure()
        else:
            credentials = setup_vertex()

        default = click.confirm(f"Set {platform} as default platform?", default=len(platforms) == 1)
        body: dict = {"platform": platform, "credentials": credentials}
        if default:
            body["defaultPlatform"] = platform
        post("/api/team/config", json=body)
        click.echo(f"{platform.capitalize()} credentials saved.")

    click.echo("\nSetup complete.")


@team.group("config")
def team_config():
    """Configure team cloud credentials (manual)."""


@team_config.command("azure")
def team_config_azure():
    """Configure Azure ML credentials manually."""
    org_id = get_org_id()
    if not org_id:
        click.echo("No active team. Run: nucl team set <org-id>", err=True)
        raise SystemExit(1)

    credentials = {
        "subscriptionId": click.prompt("Subscription ID"),
        "resourceGroup": click.prompt("Resource Group"),
        "workspace": click.prompt("Workspace"),
        "tenantId": click.prompt("Tenant ID"),
        "clientId": click.prompt("Client ID"),
        "clientSecret": click.prompt("Client Secret", hide_input=True),
    }

    default = click.confirm("Set Azure as default platform?", default=False)

    body: dict = {"platform": "azure", "credentials": credentials}
    if default:
        body["defaultPlatform"] = "azure"

    post("/api/team/config", json=body)
    click.echo("Azure credentials saved.")


@team_config.command("vertex")
def team_config_vertex():
    """Configure Vertex AI credentials manually."""
    org_id = get_org_id()
    if not org_id:
        click.echo("No active team. Run: nucl team set <org-id>", err=True)
        raise SystemExit(1)

    project = click.prompt("Project ID")
    location = click.prompt("Location", default="us-central1")
    sa_path = click.prompt("Service Account JSON path")
    sa_json = Path(sa_path).read_text()

    credentials = {
        "project": project,
        "location": location,
        "serviceAccountJson": sa_json,
    }

    default = click.confirm("Set Vertex as default platform?", default=False)

    body: dict = {"platform": "vertex", "credentials": credentials}
    if default:
        body["defaultPlatform"] = "vertex"

    post("/api/team/config", json=body)
    click.echo("Vertex credentials saved.")


# ---------------------------------------------------------------------------
# Job commands (top-level)
# ---------------------------------------------------------------------------


def _tar_cwd() -> str:
    """Create a tar.gz of the current directory, excluding .git."""
    tmp = tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False)
    with tarfile.open(tmp.name, "w:gz") as tar:
        for path in Path.cwd().rglob("*"):
            if ".git" in path.parts:
                continue
            tar.add(path, arcname=path.relative_to(Path.cwd()))
    return tmp.name


@cli.command("run")
@click.option("--name", required=True, help="Job name (use folder/name for hierarchy)")
@click.option("--script", required=True, help="Entry script (relative path)")
@click.option("--gpu-type", default=None, help="GPU type")
@click.option("--docker-image", default=None, help="Docker image")
def job_run(name: str, script: str, gpu_type: str | None, docker_image: str | None):
    """Submit a job from the current directory."""
    click.echo("Packaging workspace...")
    archive = _tar_cwd()

    metadata: dict = {"name": name, "script": script}
    if gpu_type:
        metadata["gpuType"] = gpu_type
    if docker_image:
        metadata["dockerImage"] = docker_image

    click.echo("Uploading...")
    result = post_multipart("/api/jobs", metadata, archive)
    Path(archive).unlink(missing_ok=True)

    click.echo(f"Job submitted: {result.get('id', 'unknown')}")
    if result.get("consoleUrl"):
        click.echo(f"Console: {result['consoleUrl']}")


@cli.command("ps")
@click.argument("prefix", required=False, default="")
@click.option("-n", "--num", default=20, help="Number of jobs to show")
def job_ps(prefix: str, num: int):
    """List recent jobs. Optionally filter by folder prefix."""
    data = get("/api/jobs", limit=num)
    jobs = data.get("jobs", data) if isinstance(data, dict) else data

    if prefix:
        jobs = [j for j in jobs if j.get("name", "").startswith(prefix)]

    table = Table(title="Jobs")
    table.add_column("ID")
    table.add_column("Name")
    table.add_column("Status")
    table.add_column("Created")

    for j in jobs:
        table.add_row(
            j.get("id", ""),
            j.get("name", ""),
            j.get("status", ""),
            j.get("createdAt", ""),
        )

    console.print(table)


@cli.command("log")
@click.argument("job_id")
@click.option("-f", "--follow", is_flag=True, help="Follow log output")
def job_log(job_id: str, follow: bool):
    """Stream logs for a job."""
    offset = 0
    while True:
        data = get(f"/api/jobs/{job_id}/logs", offset=offset)
        for line in data.get("lines", []):
            click.echo(line)
        offset = data.get("nextOffset", offset)
        if not follow or data.get("done"):
            break
        time.sleep(2)


@cli.command("stop")
@click.argument("job_id")
def job_stop(job_id: str):
    """Stop a running job."""
    post(f"/api/jobs/{job_id}/stop")
    click.echo(f"Job {job_id} stopped.")


@cli.command("pull")
@click.argument("job_id")
@click.argument("target", default=".")
def job_pull(job_id: str, target: str):
    """Download job outputs."""
    import httpx

    from nucl.config import get_api_key

    data = get(f"/api/jobs/{job_id}/outputs")
    files = data.get("files", [])
    if not files:
        click.echo("No output files.")
        return

    dest = Path(target)
    dest.mkdir(parents=True, exist_ok=True)
    key = get_api_key()

    for f in files:
        name = f.get("name", "file")
        url = f.get("url", "")
        click.echo(f"Downloading {name}...")
        r = httpx.get(url, headers={"Authorization": f"Bearer {key}"}, timeout=300)
        r.raise_for_status()
        (dest / name).write_bytes(r.content)

    click.echo(f"Downloaded {len(files)} file(s) to {dest}")


# ---------------------------------------------------------------------------
# Model group
# ---------------------------------------------------------------------------


@cli.group()
def model():
    """Manage models."""


@model.command("ls")
def model_ls():
    """List available models."""
    data = get("/api/models")
    models = data.get("models", data) if isinstance(data, dict) else data

    table = Table(title="Models")
    table.add_column("Name")
    table.add_column("Size")
    table.add_column("Updated")

    for m in models:
        table.add_row(m.get("name", ""), m.get("size", ""), m.get("updatedAt", ""))

    console.print(table)


@model.command("pull")
@click.argument("name")
def model_pull(name: str):
    """Download a model by name."""
    import httpx

    from nucl.config import get_api_key

    data = get(f"/api/models/{name}")
    url = data.get("url", "")
    if not url:
        click.echo("No download URL returned.", err=True)
        raise SystemExit(1)

    filename = data.get("filename", f"{name}.bin")
    click.echo(f"Downloading {filename}...")
    key = get_api_key()

    with httpx.stream("GET", url, headers={"Authorization": f"Bearer {key}"}, timeout=300) as r:
        r.raise_for_status()
        with open(filename, "wb") as f:
            for chunk in r.iter_bytes(chunk_size=8192):
                f.write(chunk)

    click.echo(f"Saved to {filename}")


# ---------------------------------------------------------------------------
# HPO group
# ---------------------------------------------------------------------------


@cli.group()
def hpo():
    """Hyperparameter optimization."""


@hpo.command("run")
@click.argument("config_file", type=click.Path(exists=True))
def hpo_run(config_file: str):
    """Submit an HPO sweep from a YAML config file."""
    config = yaml.safe_load(Path(config_file).read_text())
    config["type"] = "sweep"
    result = post("/api/jobs", json=config)
    click.echo(f"Sweep submitted: {result.get('id', 'unknown')}")
    if result.get("consoleUrl"):
        click.echo(f"Console: {result['consoleUrl']}")


# ---------------------------------------------------------------------------
# MCP group
# ---------------------------------------------------------------------------


@cli.group()
def mcp():
    """MCP server for AI agents."""


@mcp.command("serve")
def mcp_serve():
    """Start MCP server (stdio transport)."""
    from nucl.mcp_server import server

    server.run(transport="stdio")
