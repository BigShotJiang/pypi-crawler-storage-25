import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".nucl"
SESSION_FILE = CONFIG_DIR / "session.json"


def load_session() -> dict | None:
    if not SESSION_FILE.exists():
        return None
    return json.loads(SESSION_FILE.read_text())


def save_session(key: str, api_url: str, org_id: str | None = None) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = {"key": key, "api_url": api_url}
    if org_id:
        data["org_id"] = org_id
    SESSION_FILE.write_text(json.dumps(data, indent=2))


def clear_session() -> None:
    SESSION_FILE.unlink(missing_ok=True)


def get_api_url() -> str:
    session = load_session()
    return session["api_url"] if session else "https://www.lunit.dev"


def get_api_key() -> str | None:
    session = load_session()
    return session["key"] if session else None


def get_org_id() -> str | None:
    session = load_session()
    return session.get("org_id") if session else None


def set_org_id(org_id: str) -> None:
    session = load_session()
    if not session:
        raise RuntimeError("Not logged in. Run: nucl auth login")
    session["org_id"] = org_id
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    SESSION_FILE.write_text(json.dumps(session, indent=2))
