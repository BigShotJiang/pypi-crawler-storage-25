import tarfile
import tempfile
import time
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from nucl.api import get, post, post_multipart
from nucl.config import get_api_key, get_org_id, load_session, set_org_id

server = FastMCP("nucl")


def _check_auth() -> str | None:
    if not get_api_key():
        return "Not logged in. Run: nucl auth login"
    return None


def _check_org() -> str | None:
    err = _check_auth()
    if err:
        return err
    if not get_org_id():
        return "No active team. Run: nucl team set <org-id>"
    return None


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


@server.tool()
def nucl_auth_status() -> str:
    """Show current login status."""
    session = load_session()
    if not session:
        return "Not logged in."
    lines = [f"Logged in to {session.get('api_url', 'unknown')}"]
    org = session.get("org_id")
    if org:
        lines.append(f"Active team: {org}")
    else:
        lines.append("No active team. Run: nucl team set <org-id>")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------


@server.tool()
def nucl_team_list() -> str:
    """List all teams you belong to."""
    err = _check_auth()
    if err:
        return err
    data = get("/api/team/list")
    teams = data.get("teams", [])
    if not teams:
        return "No teams found."
    current = get_org_id()
    lines = [f"{'':2} {'ID':<30} {'Name':<30} {'Role'}"]
    for t in teams:
        marker = "*" if t.get("id") == current else " "
        lines.append(f"{marker:2} {t.get('id', ''):<30} {t.get('name', ''):<30} {t.get('role', '')}")
    return "\n".join(lines)


@server.tool()
def nucl_team_show() -> str:
    """Show current team and configured platforms."""
    err = _check_org()
    if err:
        return err
    data = get("/api/team/config")
    lines = [
        f"Team: {data.get('name', 'unknown')}",
        f"Default platform: {data.get('defaultPlatform', 'sandbox')}",
        f"Azure: {'configured' if data.get('azureConfigured') else 'not configured'}",
        f"Vertex: {'configured' if data.get('vertexConfigured') else 'not configured'}",
        "Sandbox: always available",
    ]
    return "\n".join(lines)


@server.tool()
def nucl_team_set(org_id: str) -> str:
    """Set active team by org ID."""
    err = _check_auth()
    if err:
        return err
    set_org_id(org_id)
    return f"Active team set to {org_id}"


@server.tool()
def nucl_team_config_azure(
    subscription_id: str,
    resource_group: str,
    workspace: str,
    tenant_id: str,
    client_id: str,
    client_secret: str,
    set_default: bool = False,
) -> str:
    """Configure Azure ML credentials for the current team."""
    err = _check_org()
    if err:
        return err
    body: dict = {
        "platform": "azure",
        "credentials": {
            "subscriptionId": subscription_id,
            "resourceGroup": resource_group,
            "workspace": workspace,
            "tenantId": tenant_id,
            "clientId": client_id,
            "clientSecret": client_secret,
        },
    }
    if set_default:
        body["defaultPlatform"] = "azure"
    post("/api/team/config", json=body)
    return "Azure credentials saved."


@server.tool()
def nucl_team_config_vertex(
    project: str,
    location: str,
    service_account_json: str,
    set_default: bool = False,
) -> str:
    """Configure Vertex AI credentials for the current team."""
    err = _check_org()
    if err:
        return err
    body: dict = {
        "platform": "vertex",
        "credentials": {
            "project": project,
            "location": location,
            "serviceAccountJson": service_account_json,
        },
    }
    if set_default:
        body["defaultPlatform"] = "vertex"
    post("/api/team/config", json=body)
    return "Vertex credentials saved."


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------


def _tar_directory(directory: str) -> str:
    """Create a tar.gz of the given directory, excluding .git."""
    tmp = tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False)
    cwd = Path(directory)
    with tarfile.open(tmp.name, "w:gz") as tar:
        for path in cwd.rglob("*"):
            if ".git" in path.parts:
                continue
            tar.add(path, arcname=path.relative_to(cwd))
    return tmp.name


@server.tool()
def nucl_run(
    name: str,
    script: str,
    directory: str = ".",
    gpu_type: str | None = None,
    docker_image: str | None = None,
) -> str:
    """Submit a training job. Packages the given directory and uploads it."""
    err = _check_org()
    if err:
        return err
    archive = _tar_directory(directory)
    metadata: dict = {"name": name, "script": script}
    if gpu_type:
        metadata["gpuType"] = gpu_type
    if docker_image:
        metadata["dockerImage"] = docker_image
    result = post_multipart("/api/jobs", metadata, archive)
    Path(archive).unlink(missing_ok=True)
    lines = [f"Job submitted: {result.get('id', 'unknown')}"]
    if result.get("consoleUrl"):
        lines.append(f"Console: {result['consoleUrl']}")
    return "\n".join(lines)


@server.tool()
def nucl_ps(prefix: str = "", num: int = 20) -> str:
    """List recent jobs. Optionally filter by folder prefix."""
    err = _check_org()
    if err:
        return err
    data = get("/api/jobs", limit=num)
    jobs = data.get("jobs", data) if isinstance(data, dict) else data
    if prefix:
        jobs = [j for j in jobs if j.get("name", "").startswith(prefix)]
    if not jobs:
        return "No jobs found."
    lines = [f"{'ID':<20} {'Name':<40} {'Status':<15} {'Created'}"]
    for j in jobs:
        lines.append(
            f"{j.get('id', ''):<20} {j.get('name', ''):<40} "
            f"{j.get('status', ''):<15} {j.get('createdAt', '')}"
        )
    return "\n".join(lines)


@server.tool()
def nucl_log(job_id: str, follow: bool = False) -> str:
    """Get logs for a job. If follow=True, polls until done."""
    err = _check_org()
    if err:
        return err
    all_lines: list[str] = []
    offset = 0
    while True:
        data = get(f"/api/jobs/{job_id}/logs", offset=offset)
        all_lines.extend(data.get("lines", []))
        offset = data.get("nextOffset", offset)
        if not follow or data.get("done"):
            break
        time.sleep(2)
    return "\n".join(all_lines) if all_lines else "No log output."


@server.tool()
def nucl_stop(job_id: str) -> str:
    """Stop a running job."""
    err = _check_org()
    if err:
        return err
    post(f"/api/jobs/{job_id}/stop")
    return f"Job {job_id} stopped."


@server.tool()
def nucl_pull(job_id: str, target: str = ".") -> str:
    """Download job outputs to a local directory."""
    err = _check_org()
    if err:
        return err
    import httpx

    data = get(f"/api/jobs/{job_id}/outputs")
    files = data.get("files", [])
    if not files:
        return "No output files."
    dest = Path(target)
    dest.mkdir(parents=True, exist_ok=True)
    key = get_api_key()
    downloaded = []
    for f in files:
        name = f.get("name", "file")
        url = f.get("url", "")
        r = httpx.get(url, headers={"Authorization": f"Bearer {key}"}, timeout=300)
        r.raise_for_status()
        (dest / name).write_bytes(r.content)
        downloaded.append(name)
    return f"Downloaded {len(downloaded)} file(s) to {dest}: {', '.join(downloaded)}"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


@server.tool()
def nucl_model_ls() -> str:
    """List available models."""
    err = _check_org()
    if err:
        return err
    data = get("/api/models")
    models = data.get("models", data) if isinstance(data, dict) else data
    if not models:
        return "No models found."
    lines = [f"{'Name':<40} {'Size':<15} {'Updated'}"]
    for m in models:
        lines.append(
            f"{m.get('name', ''):<40} {m.get('size', ''):<15} {m.get('updatedAt', '')}"
        )
    return "\n".join(lines)


@server.tool()
def nucl_model_pull(name: str, target: str = ".") -> str:
    """Download a model by name."""
    err = _check_org()
    if err:
        return err
    import httpx

    data = get(f"/api/models/{name}")
    url = data.get("url", "")
    if not url:
        return "No download URL returned."
    filename = data.get("filename", f"{name}.bin")
    key = get_api_key()
    dest = Path(target) / filename
    with httpx.stream("GET", url, headers={"Authorization": f"Bearer {key}"}, timeout=300) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_bytes(chunk_size=8192):
                f.write(chunk)
    return f"Saved to {dest}"


# ---------------------------------------------------------------------------
# HPO
# ---------------------------------------------------------------------------


@server.tool()
def nucl_hpo_run(config_path: str) -> str:
    """Submit an HPO sweep from a YAML config file."""
    err = _check_org()
    if err:
        return err
    import yaml

    config = yaml.safe_load(Path(config_path).read_text())
    config["type"] = "sweep"
    result = post("/api/jobs", json=config)
    lines = [f"Sweep submitted: {result.get('id', 'unknown')}"]
    if result.get("consoleUrl"):
        lines.append(f"Console: {result['consoleUrl']}")
    return "\n".join(lines)
