import json

import pytest

from nucl.config import (
    clear_session,
    get_api_key,
    get_api_url,
    get_org_id,
    load_session,
    save_session,
    set_org_id,
)


@pytest.fixture(autouse=True)
def mock_config_dir(tmp_path, monkeypatch):
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")


# ---------------------------------------------------------------------------
# load_session
# ---------------------------------------------------------------------------


def test_load_session_returns_none_when_file_missing():
    assert load_session() is None


def test_load_session_returns_parsed_json(tmp_path):
    data = {"key": "abc", "api_url": "https://example.com"}
    (tmp_path / "session.json").write_text(json.dumps(data))
    assert load_session() == data


# ---------------------------------------------------------------------------
# save_session
# ---------------------------------------------------------------------------


def test_save_session_creates_config_dir(tmp_path):
    nested = tmp_path / "deep" / "dir"
    import nucl.config as cfg

    cfg.CONFIG_DIR = nested
    cfg.SESSION_FILE = nested / "session.json"

    save_session("key1", "https://x.com")
    assert nested.exists()
    assert (nested / "session.json").exists()


def test_save_session_writes_correct_json(tmp_path):
    save_session("mykey", "https://api.test")
    raw = json.loads((tmp_path / "session.json").read_text())
    assert raw == {"key": "mykey", "api_url": "https://api.test"}


def test_save_session_includes_org_id_when_provided(tmp_path):
    save_session("k", "https://a.com", org_id="org-1")
    raw = json.loads((tmp_path / "session.json").read_text())
    assert raw["org_id"] == "org-1"


def test_save_session_omits_org_id_when_none(tmp_path):
    save_session("k", "https://a.com", org_id=None)
    raw = json.loads((tmp_path / "session.json").read_text())
    assert "org_id" not in raw


def test_save_session_omits_org_id_when_empty_string(tmp_path):
    save_session("k", "https://a.com", org_id="")
    raw = json.loads((tmp_path / "session.json").read_text())
    assert "org_id" not in raw


# ---------------------------------------------------------------------------
# save_session -> load_session roundtrip
# ---------------------------------------------------------------------------


def test_roundtrip_without_org():
    save_session("rt_key", "https://rt.app")
    loaded = load_session()
    assert loaded == {"key": "rt_key", "api_url": "https://rt.app"}


def test_roundtrip_with_org():
    save_session("rt_key", "https://rt.app", org_id="org-rt")
    loaded = load_session()
    assert loaded == {"key": "rt_key", "api_url": "https://rt.app", "org_id": "org-rt"}


# ---------------------------------------------------------------------------
# clear_session
# ---------------------------------------------------------------------------


def test_clear_session_removes_file(tmp_path):
    save_session("k", "https://a.com")
    assert (tmp_path / "session.json").exists()
    clear_session()
    assert not (tmp_path / "session.json").exists()


def test_clear_session_noop_when_file_missing():
    clear_session()  # should not raise


# ---------------------------------------------------------------------------
# get_api_url
# ---------------------------------------------------------------------------


def test_get_api_url_returns_url_from_session():
    save_session("k", "https://custom.url")
    assert get_api_url() == "https://custom.url"


def test_get_api_url_returns_default_when_no_session():
    assert get_api_url() == "https://www.lunit.dev"


# ---------------------------------------------------------------------------
# get_api_key
# ---------------------------------------------------------------------------


def test_get_api_key_returns_key_from_session():
    save_session("secret123", "https://a.com")
    assert get_api_key() == "secret123"


def test_get_api_key_returns_none_when_no_session():
    assert get_api_key() is None


# ---------------------------------------------------------------------------
# get_org_id
# ---------------------------------------------------------------------------


def test_get_org_id_returns_org_from_session():
    save_session("k", "https://a.com", org_id="org-42")
    assert get_org_id() == "org-42"


def test_get_org_id_returns_none_when_no_session():
    assert get_org_id() is None


def test_get_org_id_returns_none_when_no_org_in_session():
    save_session("k", "https://a.com")
    assert get_org_id() is None


# ---------------------------------------------------------------------------
# set_org_id
# ---------------------------------------------------------------------------


def test_set_org_id_updates_existing_session():
    save_session("k", "https://a.com")
    set_org_id("org-new")
    assert get_org_id() == "org-new"
    # key and api_url preserved
    s = load_session()
    assert s["key"] == "k"
    assert s["api_url"] == "https://a.com"


def test_set_org_id_overwrites_previous_org():
    save_session("k", "https://a.com", org_id="old")
    set_org_id("new")
    assert get_org_id() == "new"


def test_set_org_id_raises_when_not_logged_in():
    with pytest.raises(RuntimeError, match="Not logged in"):
        set_org_id("org-x")
