import json
from unittest.mock import patch, MagicMock

import pytest

from nucl.setup import setup_azure, setup_vertex, _run, _pick


# ---------------------------------------------------------------------------
# _run
# ---------------------------------------------------------------------------


def test_run_returns_parsed_json():
    with patch("nucl.setup.subprocess.run") as mock:
        mock.return_value = MagicMock(returncode=0, stdout='[{"id": "1"}]')
        result = _run(["az", "account", "list"])
        assert result == [{"id": "1"}]


def test_run_raises_on_failure():
    with patch("nucl.setup.subprocess.run") as mock:
        mock.return_value = MagicMock(returncode=1, stderr="error msg")
        with pytest.raises(Exception, match="failed"):
            _run(["az", "bad", "command"])


# ---------------------------------------------------------------------------
# _pick
# ---------------------------------------------------------------------------


def test_pick_returns_selected_item(monkeypatch):
    monkeypatch.setattr("click.prompt", lambda *a, **kw: 1)
    items = [{"name": "a"}, {"name": "b"}, {"name": "c"}]
    result = _pick(items, "name", "Things")
    assert result == {"name": "b"}


def test_pick_raises_on_empty():
    with pytest.raises(Exception, match="No items found"):
        _pick([], "name", "items")


# ---------------------------------------------------------------------------
# setup_azure
# ---------------------------------------------------------------------------


@patch("nucl.setup._has", return_value=False)
def test_setup_azure_fails_without_cli(_):
    with pytest.raises(Exception, match="Azure CLI not found"):
        setup_azure()


@patch("nucl.setup.get_org_id", return_value="org-test")
@patch("nucl.setup._has", return_value=True)
@patch("nucl.setup._run")
def test_setup_azure_create_new_sp(mock_run, _, __, monkeypatch):
    # Mock subprocess calls in order:
    # 1. az account list
    # 2. az ml workspace list
    # 3. az ad sp create-for-rbac
    mock_run.side_effect = [
        [{"id": "sub-1", "name": "My Sub", "tenantId": "t-1"}],
        [{"name": "ws-1", "resource_group": "rg-1"}],
        {"appId": "app-1", "password": "secret-1"},
    ]

    # Mock click.prompt to always pick index 0, and click.confirm to say No
    monkeypatch.setattr("click.prompt", lambda *a, **kw: 0)
    monkeypatch.setattr("click.confirm", lambda *a, **kw: False)

    result = setup_azure()

    assert result == {
        "subscriptionId": "sub-1",
        "resourceGroup": "rg-1",
        "workspace": "ws-1",
        "tenantId": "t-1",
        "clientId": "app-1",
        "clientSecret": "secret-1",
    }
    assert mock_run.call_count == 3


@patch("nucl.setup._has", return_value=True)
@patch("nucl.setup._run")
def test_setup_azure_existing_sp(mock_run, _, monkeypatch):
    mock_run.side_effect = [
        [{"id": "sub-1", "name": "My Sub", "tenantId": "t-1"}],
        [{"name": "ws-1", "resource_group": "rg-1"}],
    ]

    prompts = iter([0, 0, "existing-client-id", "existing-secret"])
    monkeypatch.setattr("click.prompt", lambda *a, **kw: next(prompts))
    monkeypatch.setattr("click.confirm", lambda *a, **kw: True)  # use existing

    result = setup_azure()

    assert result["clientId"] == "existing-client-id"
    assert result["clientSecret"] == "existing-secret"
    assert mock_run.call_count == 2  # no SP creation


# ---------------------------------------------------------------------------
# setup_vertex
# ---------------------------------------------------------------------------


@patch("nucl.setup._has", return_value=False)
def test_setup_vertex_fails_without_cli(_):
    with pytest.raises(Exception, match="Google Cloud CLI not found"):
        setup_vertex()


@patch("nucl.setup.subprocess.run")
@patch("nucl.setup.get_org_id", return_value="org-test")
@patch("nucl.setup._has", return_value=True)
@patch("nucl.setup._run")
def test_setup_vertex_create_new_sa(mock_run, _, __, mock_subprocess, monkeypatch):
    mock_run.return_value = [{"projectId": "my-proj", "name": "My Project"}]
    mock_subprocess.return_value = MagicMock(
        returncode=0, stdout='{"type": "service_account"}'
    )

    prompts = iter([0, 0])
    monkeypatch.setattr("click.prompt", lambda *a, **kw: next(prompts))
    monkeypatch.setattr("click.confirm", lambda *a, **kw: False)  # create new

    result = setup_vertex()

    assert result["project"] == "my-proj"
    assert result["location"] == "us-central1"
    assert "service_account" in result["serviceAccountJson"]


@patch("nucl.setup._has", return_value=True)
@patch("nucl.setup._run")
def test_setup_vertex_existing_sa(mock_run, _, monkeypatch, tmp_path):
    mock_run.return_value = [{"projectId": "my-proj", "name": "My Project"}]

    sa_file = tmp_path / "sa.json"
    sa_file.write_text('{"type": "service_account", "project_id": "my-proj"}')

    prompts = iter([0, 0, str(sa_file)])
    monkeypatch.setattr("click.prompt", lambda *a, **kw: next(prompts))
    monkeypatch.setattr("click.confirm", lambda *a, **kw: True)  # use existing

    result = setup_vertex()

    assert result["project"] == "my-proj"
    assert "my-proj" in result["serviceAccountJson"]
