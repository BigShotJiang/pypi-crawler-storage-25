import json

import httpx
import pytest

from nucl.api import delete, get, patch, post, post_multipart


@pytest.fixture(autouse=True)
def mock_config(monkeypatch):
    monkeypatch.setattr("nucl.api.get_api_key", lambda: "ak_live_test_key")
    monkeypatch.setattr("nucl.api.get_api_url", lambda: "https://test.nucl.app")
    monkeypatch.setattr("nucl.api.get_org_id", lambda: None)


# ---------------------------------------------------------------------------
# GET
# ---------------------------------------------------------------------------


def test_get_sends_request_with_auth_and_returns_json(httpx_mock):
    httpx_mock.add_response(
        json={"items": [1, 2]},
        url="https://test.nucl.app/api/things",
    )
    result = get("/api/things")
    assert result == {"items": [1, 2]}
    req = httpx_mock.get_request()
    assert req.headers["authorization"] == "Bearer ak_live_test_key"


def test_get_passes_query_params(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    get("/api/items", limit=10, offset=5)
    req = httpx_mock.get_request()
    assert "limit=10" in str(req.url)
    assert "offset=5" in str(req.url)


def test_get_raises_on_non_2xx(httpx_mock):
    httpx_mock.add_response(status_code=404, json={"error": "not found"})
    with pytest.raises(httpx.HTTPStatusError):
        get("/api/missing")


# ---------------------------------------------------------------------------
# POST
# ---------------------------------------------------------------------------


def test_post_sends_json_body(httpx_mock):
    httpx_mock.add_response(json={"id": "new-1"})
    result = post("/api/jobs", json={"name": "test"})
    assert result == {"id": "new-1"}
    req = httpx_mock.get_request()
    assert req.method == "POST"
    body = json.loads(req.content)
    assert body == {"name": "test"}


def test_post_raises_on_non_2xx(httpx_mock):
    httpx_mock.add_response(status_code=500, json={"error": "boom"})
    with pytest.raises(httpx.HTTPStatusError):
        post("/api/fail", json={})


# ---------------------------------------------------------------------------
# POST multipart
# ---------------------------------------------------------------------------


def test_post_multipart_sends_file_and_metadata(httpx_mock, tmp_path):
    httpx_mock.add_response(json={"id": "job-1"})
    archive = tmp_path / "code.tar.gz"
    archive.write_bytes(b"fake-archive-content")

    metadata = {"name": "my-job", "script": "train.py"}
    result = post_multipart("/api/jobs", metadata, str(archive))
    assert result == {"id": "job-1"}

    req = httpx_mock.get_request()
    assert req.method == "POST"
    # multipart body should contain both 'metadata' and 'code' parts
    body = req.content.decode("utf-8", errors="replace")
    assert "my-job" in body
    assert "fake-archive-content" in body


def test_post_multipart_raises_on_non_2xx(httpx_mock, tmp_path):
    httpx_mock.add_response(status_code=400, json={"error": "bad"})
    archive = tmp_path / "f.tar.gz"
    archive.write_bytes(b"x")
    with pytest.raises(httpx.HTTPStatusError):
        post_multipart("/api/jobs", {}, str(archive))


# ---------------------------------------------------------------------------
# PATCH
# ---------------------------------------------------------------------------


def test_patch_sends_json_body(httpx_mock):
    httpx_mock.add_response(json={"updated": True})
    result = patch("/api/jobs/1", {"status": "stopped"})
    assert result == {"updated": True}
    req = httpx_mock.get_request()
    assert req.method == "PATCH"
    body = json.loads(req.content)
    assert body == {"status": "stopped"}


def test_patch_raises_on_non_2xx(httpx_mock):
    httpx_mock.add_response(status_code=403, json={"error": "forbidden"})
    with pytest.raises(httpx.HTTPStatusError):
        patch("/api/x", {"a": 1})


# ---------------------------------------------------------------------------
# DELETE
# ---------------------------------------------------------------------------


def test_delete_sends_request(httpx_mock):
    httpx_mock.add_response(json={"deleted": True})
    result = delete("/api/jobs/99")
    assert result == {"deleted": True}
    req = httpx_mock.get_request()
    assert req.method == "DELETE"


def test_delete_raises_on_non_2xx(httpx_mock):
    httpx_mock.add_response(status_code=500, json={"error": "oops"})
    with pytest.raises(httpx.HTTPStatusError):
        delete("/api/x")


# ---------------------------------------------------------------------------
# _client edge cases
# ---------------------------------------------------------------------------


def test_client_exits_when_no_api_key(monkeypatch):
    monkeypatch.setattr("nucl.api.get_api_key", lambda: None)
    with pytest.raises(SystemExit):
        get("/api/anything")


def test_client_includes_org_header_when_set(httpx_mock, monkeypatch):
    monkeypatch.setattr("nucl.api.get_org_id", lambda: "org-abc")
    httpx_mock.add_response(json={})
    get("/api/team/config")
    req = httpx_mock.get_request()
    assert req.headers["x-nucl-org"] == "org-abc"


def test_client_omits_org_header_when_none(httpx_mock):
    httpx_mock.add_response(json={})
    get("/api/things")
    req = httpx_mock.get_request()
    assert "x-nucl-org" not in req.headers
