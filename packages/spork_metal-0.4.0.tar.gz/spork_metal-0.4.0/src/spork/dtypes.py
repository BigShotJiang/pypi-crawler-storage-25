from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Dtype:
    name      : str
    metal     : str
    nbytes    : int
    is_float  : bool = False
    is_signed : bool = True

    def __repr__(self) -> str:
        return f"dt.{self.name}"


float32 = Dtype("float32", "float", 4, is_float=True)
float16 = Dtype("float16", "half", 2, is_float=True)
bfloat16 = Dtype("bfloat16", "bfloat", 2, is_float=True)
int32 = Dtype("int32", "int", 4)
uint32 = Dtype("uint32", "uint", 4, is_signed=False)
int64 = Dtype("int64", "long", 8)
uint64 = Dtype("uint64", "ulong", 8, is_signed=False)
bool_ = Dtype("bool", "bool", 1, is_signed=False)

# Atomic dtypes — pointers declared with these emit `device atomic_T *`.
# Memory layout matches the underlying type, so numpy args are passed as
# the underlying dtype (uint32 / int32 / float32).
atomic_uint32  = Dtype("atomic_uint32",  "atomic_uint",  4, is_signed=False)
atomic_int32   = Dtype("atomic_int32",   "atomic_int",   4)
atomic_float32 = Dtype("atomic_float32", "atomic_float", 4, is_float=True)


_ATOMIC_UNDERLYING = {
    atomic_uint32  : uint32,
    atomic_int32   : int32,
    atomic_float32 : float32,
}


def underlying(d : "Dtype") -> "Dtype":
    """
    Return the non-atomic dtype that an atomic dtype shares memory layout with.

    For non-atomic dtypes, returns the input unchanged.
    """
    return _ATOMIC_UNDERLYING.get(d, d)


_NUMPY_TO_DTYPE = {
    np.dtype(np.float32): float32,
    np.dtype(np.float16): float16,
    np.dtype(np.int32): int32,
    np.dtype(np.uint32): uint32,
    np.dtype(np.int64): int64,
    np.dtype(np.uint64): uint64,
    np.dtype(np.bool_): bool_,
}


def from_numpy(np_dtype) -> Dtype:
    key = np.dtype(np_dtype)
    if key not in _NUMPY_TO_DTYPE:
        raise TypeError(f"No spork dtype for numpy dtype {np_dtype}")
    return _NUMPY_TO_DTYPE[key]
