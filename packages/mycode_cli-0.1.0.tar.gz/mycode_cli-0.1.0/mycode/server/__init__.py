"""FastAPI server interface."""
