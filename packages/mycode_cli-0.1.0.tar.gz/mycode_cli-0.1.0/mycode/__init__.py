"""mycode — minimal coding agent."""
