"""CLI package for mycode."""
