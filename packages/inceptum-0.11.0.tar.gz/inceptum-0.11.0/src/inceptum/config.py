import json
import os
from pathlib import Path
from typing import Any


class Config:
    def __init__(self):
        self._dir = Path(os.environ.get("INCEPTUM", "~/.config/inceptum")).expanduser()
        self._cache: dict[str, Any] = {}

    def get_module(self, name: str) -> dict[str, Any]:
        if name not in self._cache:
            with open(self._dir / f"{name}.json") as file:
                self._cache[name] = json.load(file)
        return self._cache[name]

    def get(self, *args: str, default: Any = None) -> Any:
        path = [p for arg in args for p in arg.split(".")]
        match path:
            case [name, *rest]:
                try:
                    data = self.get_module(name)
                except FileNotFoundError:
                    return default
                for key in rest:
                    if isinstance(data, dict) and key in data:
                        data = data[key]
                    else:
                        return default
                return data
            case _:
                return default


_config = Config()
config = _config.get


__all__ = ["Config", "config"]
