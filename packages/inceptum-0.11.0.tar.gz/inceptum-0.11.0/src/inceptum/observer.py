import logging
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import Enum
from fnmatch import fnmatch
from typing import ContextManager, Protocol, runtime_checkable

from .registry import registry

logger = logging.getLogger(__name__)


class ObserveMode(str, Enum):
    FULL = "full"
    TRUNCATED = "truncated"
    HASH = "hash"
    LENGTH = "length"
    OFF = "off"


@dataclass(frozen=True)
class ObservePolicy:
    default: ObserveMode = ObserveMode.FULL
    rules: dict[str, ObserveMode] = field(default_factory=dict)
    max_string_length: int = 2048

    def mode_for(self, key: str) -> ObserveMode:
        exact = self.rules.get(key)

        if exact is not None:
            return exact

        for pattern, mode in self.rules.items():
            if fnmatch(key, pattern):
                return mode

        return self.default


@runtime_checkable
class Span(Protocol):
    def observe[T](self, value: T, key: str | None = None) -> T: ...


@runtime_checkable
class Observer(Protocol):
    def span(self, name: str) -> ContextManager[Span]: ...

    def log(self, level: int, message: str, *args, **kwargs) -> None: ...
    def debug(self, message: str, *args, **kwargs) -> None: ...
    def error(self, message: str, *args, **kwargs) -> None: ...
    def exception(self, message: str, *args, **kwargs) -> None: ...
    def info(self, message: str, *args, **kwargs) -> None: ...
    def warning(self, message: str, *args, **kwargs) -> None: ...


@runtime_checkable
class ObserverFactory(Protocol):
    def get_observer(self, name: str) -> Observer: ...


@runtime_checkable
class Observability(Protocol):
    def init_observability(
        self,
        name: str,
        log_level: int,
        policy: ObservePolicy,
    ) -> None: ...


class NullSpan(Span):
    def observe[T](self, value: T, key: str | None = None) -> T:
        _ = key  # ignore
        return value


class DefaultObserver(Observer):
    def __init__(self, name: str):
        self._logger = logging.getLogger(name)

    @contextmanager
    def span(self, name: str) -> Iterator[Span]:
        _ = name  # ignore
        yield NullSpan()

    def log(self, level: int, message: str, *args, **kwargs) -> None:
        self._log(level, message, *args, **kwargs)

    def debug(self, message: str, *args, **kwargs) -> None:
        self._log(logging.DEBUG, message, *args, **kwargs)

    def error(self, message: str, *args, **kwargs) -> None:
        self._log(logging.ERROR, message, *args, **kwargs)

    def exception(self, message: str, *args, **kwargs) -> None:
        self._logger.exception(message, *args, stacklevel=2, **kwargs)

    def info(self, message: str, *args, **kwargs) -> None:
        self._log(logging.INFO, message, *args, **kwargs)

    def warning(self, message: str, *args, **kwargs) -> None:
        self._log(logging.WARNING, message, *args, **kwargs)

    def _log(self, level: int, message: str, *args, stacklevel: int = 3, **kwargs):
        self._logger.log(level, message, *args, stacklevel=stacklevel, **kwargs)


def get_observer(name: str) -> Observer:
    registry.load_plugins()
    if factory := registry.resolve(ObserverFactory):
        return factory.get_observer(name)
    else:
        return DefaultObserver(name)


def init_observability(
    name: str, log_level: int = logging.WARNING, policy: ObservePolicy | None = None
) -> None:
    registry.load_plugins()
    if observability := registry.resolve(Observability):
        observability.init_observability(name, log_level, policy or ObservePolicy())
    else:
        logger.info("No observability plugin found")


__all__ = [
    "DefaultObserver",
    "Observability",
    "ObserveMode",
    "ObservePolicy",
    "Observer",
    "Span",
    "get_observer",
    "init_observability",
]
