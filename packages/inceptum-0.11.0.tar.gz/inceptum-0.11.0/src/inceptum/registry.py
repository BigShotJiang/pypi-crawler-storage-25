import inspect
import logging
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from importlib.metadata import entry_points
from threading import Lock
from typing import Any, Iterator, MutableMapping, Protocol, TypeVar, get_type_hints

logger = logging.getLogger(__name__)

T = TypeVar("T")


class DependencyError(Exception): ...


class CircularDependencyError(DependencyError): ...


class MissingDependencyError(DependencyError): ...


class Binding(Protocol):
    interface: type[Any]
    factory: Callable[..., Any]


@dataclass(slots=True)
class Provider:
    name: str
    interface: type[Any]
    factory: Callable[..., Any] | None = None
    instance: Any | None = None


class Registry:
    def __init__(self):
        self._loaded: bool = False
        self._registry: MutableMapping[type[Any], list[Provider]] = defaultdict(list)
        self._lock: Lock = Lock()

    def load_plugins(self) -> None:
        with self._lock:
            if self._loaded:
                return
            for ep in entry_points(group="inceptum"):
                try:
                    bindings: Callable[[], Iterator[Binding]] = ep.load()
                except Exception:
                    logger.exception(
                        "Failed to load entry point %r from %s",
                        ep.name,
                        ep.value,
                    )
                else:
                    for binding in bindings():
                        self._registry[binding.interface].append(
                            Provider(
                                name=ep.name,
                                interface=binding.interface,
                                factory=binding.factory,
                            )
                        )
            self._loaded = True

    def register(
        self,
        interface: type[T],
        instance: T | None = None,
        factory: Callable[..., T] | None = None,
        unique=True,
        before=False,
        name="unknown",
    ) -> None:
        provider = Provider(
            name=name,
            interface=interface,
            instance=instance,
            factory=factory,
        )
        if unique:
            self._registry[interface] = [provider]
        elif before:
            self._registry[interface].insert(0, provider)
        else:
            self._registry[interface].append(provider)

    def unregister(self, interface: type[T]) -> None:
        self._registry[interface] = []

    def resolve(self, interface: type[T], seen: list | None = None) -> T | None:
        match self._registry.get(interface):
            case [*_, provider]:
                if provider.instance is None:
                    if provider.factory is not None:
                        if seen is None:
                            seen = []
                        elif interface in seen:
                            cycle = " -> ".join(t.__name__ for t in [*seen, interface])
                            raise CircularDependencyError(
                                f"Circular dependency detected: {cycle}"
                            )
                        seen.append(interface)
                        provider.instance = self.inject(
                            provider.factory,
                            name=provider.name,
                            seen=seen,
                        )
                    else:
                        return
                return provider.instance

    def inject(
        self,
        callable: Callable[..., T],
        name: str | None = None,
        seen: list | None = None,
    ) -> T:
        target = callable.__init__ if inspect.isclass(callable) else callable

        # If this is a class with no custom constructor, instantiate directly.
        if target is object.__init__:
            return callable()

        signature = inspect.signature(target)
        hints = get_type_hints(target)
        args = []
        for n, p in signature.parameters.items():
            if n in {"self", "cls"}:
                continue
            if n == "name":
                args.append(name)
                continue
            annotation = hints.get(n)
            if annotation is None:
                raise TypeError(
                    f"Parameter {n!r} in {callable!r} must have a type annotation"
                )
            value = self.resolve(annotation, seen)
            if value is None:
                if p.default is not inspect.Parameter.empty:
                    value = p.default
                else:
                    raise MissingDependencyError(
                        f"no implementation for parameter {n!r} with type {annotation!r} in {callable!r}"
                    )
            args.append(value)
        return callable(*args)


registry = Registry()

__all__ = [
    "DependencyError",
    "CircularDependencyError",
    "MissingDependencyError",
    "Registry",
    "registry",
]
