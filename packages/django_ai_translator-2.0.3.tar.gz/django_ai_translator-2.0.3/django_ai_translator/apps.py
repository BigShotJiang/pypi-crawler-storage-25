from django.apps import AppConfig


class DjangoAiTranslatorConfig(AppConfig):
    name = "django_ai_translator"
    verbose_name = "Django AI Translator"
    default_auto_field = "django.db.models.BigAutoField"
