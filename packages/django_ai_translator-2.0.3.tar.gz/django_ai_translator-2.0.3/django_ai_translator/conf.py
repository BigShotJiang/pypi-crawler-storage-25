"""
Central project-detection module.

Every other module imports from here instead of reading settings directly.
Handles every edge case:
  - LOCALE_PATHS missing or empty        → fallback to BASE_DIR/locale
  - LANGUAGES not defined                → fallback to Django defaults
  - BASE_DIR is str instead of Path      → normalised to Path
  - locale directory doesn't exist       → auto-created
  - .po files missing for a language     → auto-created on write
  - ROOT_URLCONF missing or unusual      → graceful skip
  - SETTINGS_MODULE not set              → graceful fallback
"""

import sys
from pathlib import Path

from django.conf import settings


def get_base_dir() -> Path:
    """Return BASE_DIR as a Path — works whether it's str or Path in settings."""
    return Path(getattr(settings, "BASE_DIR", "."))


def get_locale_path() -> Path:
    """
    Resolve the locale directory.
    Priority:
      1. First entry in LOCALE_PATHS (if defined and non-empty)
      2. BASE_DIR / 'locale'
      3. BASE_DIR / <settings_package> / 'locale'
    Auto-creates the directory if it doesn't exist.
    """
    locale_paths = getattr(settings, "LOCALE_PATHS", None)

    if locale_paths and len(locale_paths) > 0:
        resolved = Path(locale_paths[0])
        resolved.mkdir(parents=True, exist_ok=True)
        return resolved

    base = get_base_dir()

    # Try BASE_DIR/locale (most common in modern Django)
    candidate = base / "locale"
    if candidate.exists():
        return candidate

    # Try BASE_DIR/<settings_pkg>/locale (older Django layout)
    settings_pkg = _get_settings_package()
    if settings_pkg:
        pkg_candidate = base / settings_pkg / "locale"
        if pkg_candidate.exists():
            return pkg_candidate

    # Default: create BASE_DIR/locale
    candidate.mkdir(parents=True, exist_ok=True)
    return candidate


def get_languages() -> dict[str, str]:
    """
    Return {lang_code: lang_name} from settings.LANGUAGES.
    Falls back to Django's default LANGUAGES if not customised.
    """
    raw = getattr(settings, "LANGUAGES", None)

    if not raw:
        # Django always has a default, but guard anyway
        return {"en": "English"}

    return {code: str(name) for code, name in raw}


def get_target_languages() -> dict[str, str]:
    """Non-English languages only."""
    return {code: name for code, name in get_languages().items() if code != "en"}


def get_project_package() -> str | None:
    """
    Detect the host project's Python package name.
    Uses ROOT_URLCONF (e.g. 'myproject.urls' → 'myproject').
    Returns None if unresolvable.
    """
    urlconf = getattr(settings, "ROOT_URLCONF", "")
    if urlconf and "." in urlconf:
        return urlconf.split(".")[0]
    return None


def get_manage_py() -> str:
    """Return the path to manage.py, or 'manage.py' as fallback."""
    base = get_base_dir()
    candidate = base / "manage.py"
    if candidate.exists():
        return str(candidate)
    # fallback: rely on it being in PATH / cwd
    return "manage.py"


def get_python_executable() -> str:
    """Return the current Python interpreter path."""
    return sys.executable or "python3"


def _get_settings_package() -> str | None:
    """Extract settings package name from SETTINGS_MODULE."""
    mod = getattr(settings, "SETTINGS_MODULE", "")
    if mod and "." in mod:
        return mod.split(".")[0]
    return None


def ensure_locale_structure(locale_base: Path, lang_codes: list[str]):
    """
    Ensure <locale_base>/<lang>/LC_MESSAGES/ exists for every language.
    Called before any .po read/write to prevent FileNotFoundError.
    """
    for code in lang_codes:
        lc_dir = locale_base / code / "LC_MESSAGES"
        lc_dir.mkdir(parents=True, exist_ok=True)
