"""
.po file manager — reads, diffs, and updates translation files.

Uses polib for robust .po manipulation.
Atomic writes prevent file corruption.
Never overwrites existing non-empty msgstr.
Only adds messages that are actually missing per language.
"""

import logging
import os
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import polib

from django_ai_translator.conf import (
    ensure_locale_structure,
    get_base_dir,
    get_locale_path,
    get_manage_py,
    get_python_executable,
    get_target_languages,
)

logger = logging.getLogger("auto_translate")


class POManager:
    """Read, diff, and update .po translation files."""

    def __init__(self):
        self.locale_base = get_locale_path()
        self.target_languages = get_target_languages()

        # Ensure every language has its LC_MESSAGES directory
        ensure_locale_structure(self.locale_base, list(self.target_languages.keys()))

    def get_target_languages(self) -> dict[str, str]:
        return self.target_languages

    def find_globally_missing(self, messages: set[str]) -> list[str]:
        """Messages missing in at least one target language."""
        missing: set[str] = set()
        for lang_code in self.target_languages:
            existing = self._load_existing(self._po_path(lang_code))
            for msg in messages:
                if msg not in existing or not existing[msg]:
                    missing.add(msg)
        return sorted(missing)

    def find_missing_by_lang(self, messages: set[str]) -> dict[str, list[str]]:
        """Per-language breakdown of missing translations."""
        result: dict[str, list[str]] = {}
        for lang_code in self.target_languages:
            existing = self._load_existing(self._po_path(lang_code))
            lang_missing = sorted(msg for msg in messages if msg not in existing or not existing[msg])
            if lang_missing:
                result[lang_code] = lang_missing
        return result

    def apply_translations(
        self,
        translations: dict[str, dict[str, str]],
        missing_by_lang: dict[str, list[str]],
    ) -> dict[str, int]:
        """
        Write ONLY missing messages to .po files.
        Never overwrites existing non-empty msgstr.
        """
        stats: dict[str, int] = {}
        for lang_code in self.target_languages:
            lang_missing = missing_by_lang.get(lang_code, [])
            if not lang_missing:
                stats[lang_code] = 0
                continue
            added = self._update_po(lang_code, translations, set(lang_missing))
            stats[lang_code] = added
        return stats

    def compile_messages(self) -> bool:
        """Run compilemessages using the current Python interpreter."""
        manage_py = get_manage_py()
        python = get_python_executable()
        base_dir = str(get_base_dir())
        try:
            proc = subprocess.run(
                [python, manage_py, "compilemessages"],
                capture_output=True,
                text=True,
                timeout=120,
                cwd=base_dir,
            )
            return proc.returncode == 0
        except Exception as exc:
            logger.error("compilemessages error: %s", exc)
            return False

    # ── Internals ─────────────────────────────────────────────────────

    def _po_path(self, lang_code: str) -> Path:
        return self.locale_base / lang_code / "LC_MESSAGES" / "django.po"

    def _load_existing(self, po_path: Path) -> dict[str, str]:
        if not po_path.exists():
            return {}
        try:
            po = polib.pofile(str(po_path))
            return {e.msgid: e.msgstr for e in po if e.msgid}
        except UnicodeDecodeError:
            logger.warning("Encoding error in .po file: %s — fixing encoding", po_path)
            self._fix_encoding(po_path)
            try:
                po = polib.pofile(str(po_path))
                return {e.msgid: e.msgstr for e in po if e.msgid}
            except Exception:
                logger.warning("Still corrupt after encoding fix — repairing: %s", po_path)
                repaired = self._repair_po(po_path)
                return {e.msgid: e.msgstr for e in repaired if e.msgid}
        except Exception:
            logger.warning("Corrupt .po file detected: %s — auto-repairing", po_path)
            repaired = self._repair_po(po_path)
            return {e.msgid: e.msgstr for e in repaired if e.msgid}

    @staticmethod
    def _fix_encoding(po_path: Path):
        """Re-encode a .po file to UTF-8, stripping invalid bytes."""
        try:
            raw = po_path.read_bytes()
            # Try common encodings
            for encoding in ("utf-8", "latin-1", "cp1252", "iso-8859-1"):
                try:
                    text = raw.decode(encoding)
                    po_path.write_text(text, encoding="utf-8")
                    logger.info("Re-encoded %s from %s to UTF-8", po_path, encoding)
                    return
                except (UnicodeDecodeError, UnicodeEncodeError):
                    continue
            # Last resort: decode with replacement
            text = raw.decode("utf-8", errors="replace")
            po_path.write_text(text, encoding="utf-8")
            logger.warning("Force-decoded %s with replacement chars", po_path)
        except Exception as exc:
            logger.error("Failed to fix encoding for %s: %s", po_path, exc)

    def _repair_po(self, po_path: Path) -> polib.POFile:
        """
        Auto-repair a corrupt .po file:
          1. Back up the corrupt file as .po.corrupt
          2. Try to salvage valid entries from raw text
          3. Write a clean .po file with recovered entries
        """
        # Step 1: Back up corrupt file
        backup_path = po_path.with_suffix(".po.corrupt")
        shutil.copy2(str(po_path), str(backup_path))
        logger.info("Corrupt file backed up to: %s", backup_path)

        # Step 2: Try to salvage entries from raw text
        lang_code = po_path.parent.parent.name  # locale/<lang>/LC_MESSAGES/django.po
        salvaged = []
        try:
            raw = po_path.read_text(encoding="utf-8", errors="ignore")
            import re
            # Find all msgid/msgstr pairs in raw text
            pairs = re.findall(
                r'msgid\s+"(.+?)"\s*\nmsgstr\s+"(.*?)"',
                raw,
            )
            for msgid, msgstr in pairs:
                if msgid:  # skip empty msgid (header)
                    salvaged.append((msgid, msgstr))
            logger.info("Salvaged %d entries from corrupt file", len(salvaged))
        except Exception:
            logger.warning("Could not salvage entries — starting fresh")

        # Step 3: Write clean .po file
        po = self._new_po(lang_code)
        for msgid, msgstr in salvaged:
            po.append(polib.POEntry(msgid=msgid, msgstr=msgstr))
        self._atomic_save(po, po_path)
        logger.info("Repaired .po file written: %s", po_path)
        return po

    def _update_po(
        self,
        lang_code: str,
        translations: dict[str, dict[str, str]],
        missing_messages: set[str],
    ) -> int:
        po_path = self._po_path(lang_code)
        po_path.parent.mkdir(parents=True, exist_ok=True)

        if po_path.exists():
            try:
                po = polib.pofile(str(po_path))
            except UnicodeDecodeError:
                logger.warning("Encoding error during update: %s — fixing", po_path)
                self._fix_encoding(po_path)
                try:
                    po = polib.pofile(str(po_path))
                except Exception:
                    po = self._repair_po(po_path)
            except Exception:
                logger.warning("Corrupt .po detected during update: %s — repairing", po_path)
                po = self._repair_po(po_path)
        else:
            po = self._new_po(lang_code)
        existing_ids = {e.msgid for e in po if e.msgid}
        added = 0

        for msg in sorted(missing_messages):
            translated = translations.get(msg, {}).get(lang_code, "")

            if msg in existing_ids:
                entry = po.find(msg)
                if entry and not entry.msgstr and translated:
                    entry.msgstr = translated
                    added += 1
                continue

            po.append(polib.POEntry(msgid=msg, msgstr=translated))
            added += 1

        if added > 0:
            self._atomic_save(po, po_path)
        return added

    @staticmethod
    def _atomic_save(po: polib.POFile, target: Path):
        fd, tmp = tempfile.mkstemp(suffix=".po", dir=str(target.parent))
        os.close(fd)
        try:
            po.save(tmp)
            if target.exists():
                os.chmod(tmp, os.stat(target).st_mode)
            shutil.move(tmp, str(target))
        except Exception:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise

    @staticmethod
    def _new_po(lang_code: str) -> polib.POFile:
        po = polib.POFile()
        po.metadata = {
            "Project-Id-Version": "django-ai-translator",
            "Report-Msgid-Bugs-To": "",
            "POT-Creation-Date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M%z"),
            "PO-Revision-Date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M%z"),
            "Last-Translator": "django-ai-translator",
            "Language-Team": lang_code,
            "Language": lang_code,
            "MIME-Version": "1.0",
            "Content-Type": "text/plain; charset=UTF-8",
            "Content-Transfer-Encoding": "8bit",
        }
        return po
