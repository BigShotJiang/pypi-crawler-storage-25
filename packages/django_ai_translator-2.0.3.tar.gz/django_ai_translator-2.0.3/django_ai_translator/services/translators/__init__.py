"""
Translator backends — pluggable architecture.

Usage:
    from django_ai_translator.services.translators import get_translator

    translator = get_translator('claude', api_key='sk-...')
    result = translator.translate_batch(messages, target_languages)
"""

from django_ai_translator.services.translators.base import (
    BaseTranslator,
    DummyTranslator,
)
from django_ai_translator.services.translators.base import (
    build_prompt as build_prompt,
)
from django_ai_translator.services.translators.base import (
    parse_response as parse_response,
)
from django_ai_translator.services.translators.claude import ClaudeTranslator
from django_ai_translator.services.translators.gemini import GeminiTranslator
from django_ai_translator.services.translators.mistral import MistralTranslator
from django_ai_translator.services.translators.openai import OpenAITranslator
from django_ai_translator.services.translators.openrouter import OpenRouterTranslator

# ── Provider registry ────────────────────────────────────────────────

PROVIDER_ENV_KEYS = {
    "claude": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "gemini": "GOOGLE_GEMINI_KEY",
    "mistral": "MISTRAL_API_KEY",
}

ALL_ENV_KEYS = {
    "ANTHROPIC_API_KEY": "Claude (Anthropic)",
    "OPENAI_API_KEY": "OpenAI GPT",
    "OPENROUTER_API_KEY": "OpenRouter (100+ models)",
    "GOOGLE_GEMINI_KEY": "Google Gemini",
    "MISTRAL_API_KEY": "Mistral AI",
}

OPENROUTER_MODELS = [
    {"id": "anthropic/claude-sonnet-4", "name": "Claude Sonnet 4", "tag": "Best Quality", "color": "bright_cyan"},
    {"id": "openai/gpt-4o", "name": "GPT-4o", "tag": "Powerful", "color": "bright_green"},
    {"id": "openai/gpt-4o-mini", "name": "GPT-4o Mini", "tag": "Fast & Cheap", "color": "green"},
    {"id": "google/gemini-2.0-flash-001", "name": "Gemini 2.0 Flash", "tag": "Ultra Fast", "color": "bright_yellow"},
    {"id": "google/gemini-2.5-pro-preview", "name": "Gemini 2.5 Pro", "tag": "Premium", "color": "yellow"},
    {"id": "meta-llama/llama-4-maverick", "name": "Llama 4 Maverick", "tag": "Open Source", "color": "bright_blue"},
    {"id": "meta-llama/llama-3.3-70b-instruct", "name": "Llama 3.3 70B", "tag": "Balanced", "color": "blue"},
    {
        "id": "mistralai/mistral-large-2411",
        "name": "Mistral Large",
        "tag": "European Languages",
        "color": "bright_magenta",
    },
    {"id": "deepseek/deepseek-chat-v3-0324", "name": "DeepSeek V3", "tag": "Budget King", "color": "bright_red"},
    {"id": "qwen/qwen-2.5-72b-instruct", "name": "Qwen 2.5 72B", "tag": "Asian Languages", "color": "bright_white"},
]

TRANSLATOR_MAP = {
    "claude": ClaudeTranslator,
    "openai": OpenAITranslator,
    "openrouter": OpenRouterTranslator,
    "gemini": GeminiTranslator,
    "mistral": MistralTranslator,
    "skip": DummyTranslator,
}


def get_translator(provider: str, api_key: str = "", model_id: str = "") -> BaseTranslator:
    """Factory: return the right translator instance."""
    cls = TRANSLATOR_MAP.get(provider)
    if cls is None:
        raise ValueError(f"Unknown provider: {provider}")
    if provider == "skip":
        return cls()
    if provider == "openrouter":
        return cls(api_key=api_key, model_id=model_id or "anthropic/claude-sonnet-4")
    return cls(api_key=api_key)
