"""
Base translator class, shared prompt builder, and JSON response parser.
"""

import json
import logging
import re
import time
from abc import ABC, abstractmethod

logger = logging.getLogger("auto_translate")

MAX_RETRIES = 3
RETRY_BACKOFF = 2


def build_prompt(messages: list[str], target_languages: dict[str, str]) -> str:
    """Build the translation prompt used by all LLM providers."""
    langs_json = json.dumps(target_languages, ensure_ascii=False, indent=2)
    msgs_json = json.dumps(messages, ensure_ascii=False, indent=2)

    example_msg = messages[0] if messages else "Hello"
    example_langs = {code: "..." for code in target_languages}
    example_out = json.dumps({example_msg: example_langs}, ensure_ascii=False, indent=2)

    return (
        "You are a professional translator for a Django web application.\n"
        "Translate the following English messages into the specified target languages.\n\n"
        "RULES:\n"
        "1. Preserve ALL placeholders exactly as-is: {username}, {id}, {name}, etc.\n"
        "2. Preserve ALL Django template placeholders exactly as-is: %(users)d, %(items)d, %(count)d, etc.\n"
        "3. Keep the tone natural and appropriate for the application.\n"
        "4. Return ONLY valid JSON — no explanation, no markdown, no code fences.\n"
        "5. Every source message MUST appear as a key in the output.\n"
        "6. Every target language MUST appear for every message.\n\n"
        f"Messages to translate:\n{msgs_json}\n\n"
        f"Target languages (ISO code → language name):\n{langs_json}\n\n"
        f"Return format (example for first message):\n{example_out}\n\n"
        "Now translate ALL messages above. Return ONLY the JSON object."
    )


def parse_response(
    raw: str,
    expected_messages: list[str],
    target_languages: dict[str, str],
) -> dict[str, dict[str, str]] | None:
    """Parse and validate LLM JSON output."""
    cleaned = raw.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    cleaned = cleaned.strip()

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        logger.error("Invalid JSON: %s — raw[:200]: %.200s", exc, raw)
        return None

    if not isinstance(data, dict):
        logger.error("Expected dict, got %s", type(data).__name__)
        return None

    lang_codes = set(target_languages.keys())
    validated: dict[str, dict[str, str]] = {}

    for msg in expected_messages:
        if msg not in data:
            continue
        langs = data[msg]
        if not isinstance(langs, dict):
            continue
        valid = {}
        for code in lang_codes:
            if code in langs and isinstance(langs[code], str) and langs[code].strip():
                valid[code] = langs[code].strip()
        if valid:
            validated[msg] = valid

    return validated if validated else None


class BaseTranslator(ABC):
    """Abstract translator interface."""

    name: str = "base"

    def __init__(self, api_key: str):
        self.api_key = api_key

    @abstractmethod
    def validate_key(self) -> bool: ...

    @abstractmethod
    def _call_api(self, prompt: str) -> str | None: ...

    def translate_batch(
        self,
        messages: list[str],
        target_languages: dict[str, str],
    ) -> dict[str, dict[str, str]] | None:
        """Translate with retry logic."""
        prompt = build_prompt(messages, target_languages)

        for attempt in range(1, MAX_RETRIES + 1):
            raw = self._call_api(prompt)
            if raw is None:
                if attempt < MAX_RETRIES:
                    wait = RETRY_BACKOFF**attempt
                    logger.warning("Retry %d/%d in %ds…", attempt, MAX_RETRIES, wait)
                    time.sleep(wait)
                continue

            result = parse_response(raw, messages, target_languages)
            if result is not None:
                return result

            if attempt < MAX_RETRIES:
                wait = RETRY_BACKOFF**attempt
                logger.warning("Bad response, retry %d/%d in %ds…", attempt, MAX_RETRIES, wait)
                time.sleep(wait)

        return None


class DummyTranslator(BaseTranslator):
    """No-op translator — adds msgid with empty msgstr."""

    name = "Skip (no translation)"

    def __init__(self):
        super().__init__(api_key="")

    def validate_key(self) -> bool:
        return True

    def _call_api(self, prompt: str) -> str | None:
        return None

    def translate_batch(self, messages, target_languages):
        return {}
