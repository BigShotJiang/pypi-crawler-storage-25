"""OpenRouter translator backend — 100+ models via OpenAI-compatible API."""

import logging

from django_ai_translator.services.translators.base import BaseTranslator

logger = logging.getLogger("auto_translate")


class OpenRouterTranslator(BaseTranslator):
    name = "OpenRouter"

    def __init__(self, api_key: str, model_id: str = "anthropic/claude-sonnet-4"):
        super().__init__(api_key)
        self.model_id = model_id
        self.name = f"OpenRouter → {model_id}"

    def validate_key(self) -> bool:
        try:
            import openai as openai_lib

            client = openai_lib.OpenAI(
                api_key=self.api_key,
                base_url="https://openrouter.ai/api/v1",
            )
            resp = client.chat.completions.create(
                model=self.model_id,
                max_tokens=10,
                messages=[{"role": "user", "content": "Reply with: ok"}],
            )
            return bool(resp.choices)
        except Exception:
            return False

    def _call_api(self, prompt: str) -> str | None:
        try:
            import openai as openai_lib

            client = openai_lib.OpenAI(
                api_key=self.api_key,
                base_url="https://openrouter.ai/api/v1",
            )
            resp = client.chat.completions.create(
                model=self.model_id,
                max_tokens=8192,
                temperature=0.3,
                messages=[
                    {"role": "system", "content": "You are a professional translator. Return ONLY valid JSON."},
                    {"role": "user", "content": prompt},
                ],
                extra_headers={
                    "X-Title": "Django AI Translator",
                },
            )
            return resp.choices[0].message.content
        except Exception as exc:
            logger.error("OpenRouter API error: %s", exc)
            return None
