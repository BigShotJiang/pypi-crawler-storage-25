"""Google Gemini translator backend."""

import logging

from django_ai_translator.services.translators.base import BaseTranslator

logger = logging.getLogger("auto_translate")


class GeminiTranslator(BaseTranslator):
    name = "Google Gemini"

    def validate_key(self) -> bool:
        try:
            import google.generativeai as genai

            genai.configure(api_key=self.api_key)
            model = genai.GenerativeModel("gemini-2.0-flash")
            resp = model.generate_content("Reply with: ok")
            return bool(resp.text)
        except Exception:
            return False

    def _call_api(self, prompt: str) -> str | None:
        try:
            import google.generativeai as genai

            genai.configure(api_key=self.api_key)
            model = genai.GenerativeModel("gemini-2.0-flash")
            resp = model.generate_content(
                prompt,
                generation_config=genai.types.GenerationConfig(
                    temperature=0.3,
                    max_output_tokens=8192,
                ),
            )
            return resp.text
        except Exception as exc:
            logger.error("Gemini API error: %s", exc)
            return None
