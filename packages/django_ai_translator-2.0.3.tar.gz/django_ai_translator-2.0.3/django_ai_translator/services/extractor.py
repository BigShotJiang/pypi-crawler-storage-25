"""
AST-based scanner — extracts every user-facing translatable string from
the Django project source tree.

Targets:
  _("...")  gettext_lazy("...")  ValidationError("...")
  error_messages={...}  notification_message_list values

Skips:
  f-strings with complex expressions, logger/print calls,
  strings < 2 chars, URL-only strings, HTML-heavy strings.
"""

import ast
import hashlib
import importlib
import os
import re
from pathlib import Path

from django_ai_translator.conf import get_base_dir, get_project_package

TRANSLATABLE_CALL_NAMES = frozenset(
    {
        "_",
        "gettext",
        "gettext_lazy",
        "ugettext",
        "ugettext_lazy",
        "ValidationError",
    }
)

SKIP_CALL_NAMES = frozenset(
    {
        "logger",
        "logging",
        "print",
        "log",
        "warning",
        "error",
        "info",
        "debug",
        "critical",
        "exception",
    }
)

MIN_LENGTH = 2
MAX_HTML_TAGS = 3
HTML_TAG_RE = re.compile(r"<[a-zA-Z/][^>]*>")

SKIP_DIRS = frozenset(
    {
        "migrations",
        "__pycache__",
        ".git",
        "node_modules",
        "static",
        "media",
        "venv",
        ".venv",
        "env",
        "locale",
        "django_ai_translator",
    }
)


class TranslationExtractor:
    """Walk Python source files → extract translatable message strings."""

    def __init__(self, project_root: str | None = None):
        self.project_root = Path(project_root) if project_root else get_base_dir()
        self._messages: dict[str, set[str]] = {}
        self.files_scanned = 0
        self.skipped_dynamic = 0

    def extract_all(self) -> dict[str, set[str]]:
        self._messages.clear()
        self.files_scanned = 0
        self.skipped_dynamic = 0

        for py_file in self._iter_python_files():
            try:
                self._extract_from_file(py_file)
                self.files_scanned += 1
            except SyntaxError:
                pass
            except Exception:
                pass

        self._extract_notification_messages()
        return self._messages

    @staticmethod
    def message_hash(message: str) -> str:
        return hashlib.sha256(message.encode("utf-8")).hexdigest()[:16]

    # ── File iteration ────────────────────────────────────────────────

    def _iter_python_files(self):
        for root, dirs, files in os.walk(self.project_root):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for fname in files:
                if fname.endswith(".py"):
                    yield os.path.join(root, fname)

    # ── AST extraction ────────────────────────────────────────────────

    def _extract_from_file(self, filepath: str):
        with open(filepath, encoding="utf-8", errors="ignore") as fh:
            source = fh.read()
        tree = ast.parse(source, filename=filepath)
        for child in ast.walk(tree):
            if isinstance(child, ast.Call):
                func_name = self._get_call_name(child)
                if not func_name:
                    continue
                if self._is_skip_call(func_name, child):
                    continue
                if func_name in TRANSLATABLE_CALL_NAMES:
                    self._extract_strings_from_args(child, filepath)

    @staticmethod
    def _get_call_name(node: ast.Call) -> str | None:
        func = node.func
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            return func.attr
        return None

    @staticmethod
    def _get_full_call_chain(node: ast.Call) -> list[str]:
        parts = []
        func = node.func
        while isinstance(func, ast.Attribute):
            parts.append(func.attr)
            func = func.value
        if isinstance(func, ast.Name):
            parts.append(func.id)
        parts.reverse()
        return parts

    def _is_skip_call(self, func_name: str, node: ast.Call) -> bool:
        if func_name.lower() in SKIP_CALL_NAMES:
            return True
        chain = self._get_full_call_chain(node)
        return any(part.lower() in SKIP_CALL_NAMES for part in chain)

    def _extract_strings_from_args(self, call_node: ast.Call, filepath: str):
        for arg in call_node.args:
            self._collect_string(arg, filepath)
        for kw in call_node.keywords:
            self._collect_string(kw.value, filepath)

    def _collect_string(self, node: ast.AST, filepath: str):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            self._add_message(node.value, filepath, getattr(node, "lineno", 0))
        elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            combined = self._try_concat(node)
            if combined is not None:
                self._add_message(combined, filepath, getattr(node, "lineno", 0))
        elif isinstance(node, ast.JoinedStr):
            self._handle_fstring(node, filepath)

    def _handle_fstring(self, node: ast.JoinedStr, filepath: str):
        parts = []
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append(value.value)
            elif isinstance(value, ast.FormattedValue):
                if isinstance(value.value, ast.Name) and value.conversion == -1 and value.format_spec is None:
                    parts.append("{" + value.value.id + "}")
                else:
                    self.skipped_dynamic += 1
                    return
            else:
                self.skipped_dynamic += 1
                return
        self._add_message("".join(parts), filepath, getattr(node, "lineno", 0))

    def _try_concat(self, node) -> str | None:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left = self._try_concat(node.left)
            right = self._try_concat(node.right)
            if left is not None and right is not None:
                return left + right
        return None

    def _add_message(self, message: str, filepath: str, lineno: int):
        message = " ".join(message.split())
        if not self._should_include(message):
            return
        location = f"{os.path.relpath(filepath, self.project_root)}:{lineno}"
        self._messages.setdefault(message, set()).add(location)

    # ── Notification message list (auto-detect) ───────────────────────

    def _extract_notification_messages(self):
        """Auto-detect and import notification_message_list from the host project."""
        project_pkg = get_project_package()
        if not project_pkg:
            return
        try:
            mod = importlib.import_module(f"{project_pkg}.notification_message_list")
            message_list = getattr(mod, "message_list", {})
            for _key, msg in message_list.items():
                msg = " ".join(msg.split())
                if self._should_include(msg):
                    self._messages.setdefault(msg, set()).add(f"{project_pkg}/notification_message_list.py")
        except (ImportError, AttributeError, Exception):
            pass

    # ── Filters ───────────────────────────────────────────────────────

    @staticmethod
    def _should_include(message: str) -> bool:
        if len(message) < MIN_LENGTH:
            return False
        if re.fullmatch(r"[\w_\-./]+", message) and " " not in message:
            return False
        if len(HTML_TAG_RE.findall(message)) > MAX_HTML_TAGS:
            return False
        if message.startswith(("http://", "https://", "ftp://")):
            return False
        return not re.fullmatch(r"[\d\s.,%]+", message)
