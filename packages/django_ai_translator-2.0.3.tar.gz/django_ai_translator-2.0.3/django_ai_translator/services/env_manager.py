"""
.env file manager — auto-creates, scaffolds, loads, and writes API keys.

Auto-detects .env location from the Django project structure.
"""

import os
from pathlib import Path

from dotenv import dotenv_values, set_key

from django_ai_translator.conf import _get_settings_package, get_base_dir
from django_ai_translator.services.translators import ALL_ENV_KEYS


def _env_path() -> Path:
    """Auto-detect .env file location from the Django project."""
    base = get_base_dir()

    # 1. Check inside the settings package directory
    pkg = _get_settings_package()
    if pkg:
        pkg_env = base / pkg / ".env"
        if pkg_env.exists():
            return pkg_env

    # 2. Check project root
    root_env = base / ".env"
    if root_env.exists():
        return root_env

    # 3. Default: settings package dir if resolvable, else root
    if pkg:
        return base / pkg / ".env"
    return root_env


def ensure_env_exists() -> Path:
    """Create .env if missing. Scaffold all translation API key placeholders."""
    env_file = _env_path()

    if not env_file.exists():
        env_file.parent.mkdir(parents=True, exist_ok=True)
        env_file.touch()

    existing = dotenv_values(str(env_file))
    raw_text = env_file.read_text()

    missing = []
    for key, description in ALL_ENV_KEYS.items():
        if key not in existing and key not in raw_text:
            missing.append((key, description))

    if missing:
        with open(env_file, "a") as f:
            if not any(k in raw_text for k in ALL_ENV_KEYS):
                f.write("\n# ── AI Translator API Keys ──\n")
            for key, desc in missing:
                f.write(f"# {desc}\n")
                f.write(f"{key}=\n")

    return env_file


def get_env_status() -> dict[str, str | None]:
    """Return {env_var: value_or_None} for all translation provider keys."""
    env_file = _env_path()
    file_values = dotenv_values(str(env_file)) if env_file.exists() else {}

    status = {}
    for key in ALL_ENV_KEYS:
        val = file_values.get(key, "").strip()
        if not val:
            val = os.environ.get(key, "").strip()
        status[key] = val if val else None
    return status


def load_key(env_var: str) -> str | None:
    """Read a key from .env (or os.environ fallback)."""
    env_file = _env_path()
    if env_file.exists():
        values = dotenv_values(str(env_file))
        val = values.get(env_var, "").strip()
        if val:
            return val
    val = os.environ.get(env_var, "").strip()
    return val if val else None


def save_key(env_var: str, value: str):
    """Write/update a key in .env file."""
    env_file = _env_path()
    if not env_file.exists():
        env_file.parent.mkdir(parents=True, exist_ok=True)
        env_file.touch()
    set_key(str(env_file), env_var, value)
