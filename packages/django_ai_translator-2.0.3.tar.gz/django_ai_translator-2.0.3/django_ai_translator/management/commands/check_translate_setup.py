"""
Post-install validation command.

Usage:
    python manage.py check_translate_setup
"""

from django.core.management.base import BaseCommand

from django_ai_translator.conf import (
    get_base_dir,
    get_languages,
    get_locale_path,
    get_target_languages,
)


class Command(BaseCommand):
    help = "Validate django-ai-translator setup and show diagnostics."

    def handle(self, *args, **options):
        from rich import box
        from rich.console import Console
        from rich.panel import Panel

        console = Console()
        all_ok = True

        console.print()
        console.print(
            Panel(
                "[bold bright_green]django-ai-translator — Setup Check[/]",
                border_style="green",
                box=box.DOUBLE_EDGE,
                padding=(0, 3),
            )
        )
        console.print()

        # ── 1. Package importable ─────────────────────────────────────
        try:
            import django_ai_translator

            ver = django_ai_translator.__version__
            console.print(f"[bold green]✔[/] Package installed: v{ver}")
        except ImportError:
            console.print("[bold red]✗[/] Package NOT importable — pip install failed?")
            all_ok = False

        # ── 2. INSTALLED_APPS ─────────────────────────────────────────
        from django.conf import settings

        if "django_ai_translator" in settings.INSTALLED_APPS:
            console.print("[bold green]✔[/] INSTALLED_APPS: django_ai_translator found")
        else:
            console.print(
                "[bold red]✗[/] INSTALLED_APPS: django_ai_translator [bold]NOT[/] found\n"
                "  [dim]Add [/][bold]'django_ai_translator'[/][dim] to INSTALLED_APPS in settings.py[/]"
            )
            all_ok = False

        # ── 3. BASE_DIR ───────────────────────────────────────────────
        base = get_base_dir()
        console.print(f"[bold green]✔[/] BASE_DIR: {base}")

        # ── 4. LANGUAGES ──────────────────────────────────────────────
        langs = get_languages()
        targets = get_target_languages()
        console.print(f"[bold green]✔[/] LANGUAGES: {len(langs)} total, {len(targets)} target (non-English)")

        if not targets:
            console.print(
                "[bold yellow]⚠[/] No target languages configured — nothing to translate\n"
                "  [dim]Add languages to LANGUAGES in settings.py[/]"
            )

        # ── 5. LOCALE_PATHS ───────────────────────────────────────────
        locale = get_locale_path()
        if locale.exists():
            console.print(f"[bold green]✔[/] Locale path: {locale}")
        else:
            console.print(f"[bold yellow]⚠[/] Locale path created: {locale}")

        # ── 6. .po files ──────────────────────────────────────────────
        po_count = 0
        for lang_code in targets:
            po_file = locale / lang_code / "LC_MESSAGES" / "django.po"
            if po_file.exists():
                po_count += 1
        if po_count > 0:
            console.print(f"[bold green]✔[/] .po files found: {po_count}/{len(targets)} languages")
        else:
            console.print("[bold yellow]⚠[/] No .po files found yet — they will be created on first run")

        # ── 7. Dependencies ───────────────────────────────────────────
        dep_checks = [
            ("polib", "polib"),
            ("rich", "rich"),
            ("dotenv", "python-dotenv"),
        ]
        for mod_name, pip_name in dep_checks:
            try:
                __import__(mod_name)
                console.print(f"[bold green]✔[/] Dependency: {pip_name}")
            except ImportError:
                console.print(f"[bold red]✗[/] Missing: {pip_name}  →  pip install {pip_name}")
                all_ok = False

        # ── 8. AI provider SDKs (optional) ────────────────────────────
        console.print()
        console.print("[dim]Optional AI provider SDKs:[/]")
        optional = [
            ("anthropic", "anthropic", "Claude"),
            ("openai", "openai", "OpenAI / OpenRouter"),
            ("google.generativeai", "google-generativeai", "Gemini"),
            ("mistralai", "mistralai", "Mistral"),
        ]
        for mod_name, pip_name, label in optional:
            try:
                __import__(mod_name)
                console.print(f"  [green]✔[/] {label} ({pip_name})")
            except ImportError:
                console.print(f"  [dim]–[/] {label} [dim]not installed (pip install {pip_name})[/]")

        # ── Summary ───────────────────────────────────────────────────
        console.print()
        if all_ok:
            console.print(
                Panel(
                    "[bold bright_green]All checks passed![/]\n\n"
                    "[green]Run:[/]  [bold]python manage.py auto_translate[/]",
                    border_style="green",
                    box=box.ROUNDED,
                    padding=(0, 3),
                )
            )
        else:
            console.print(
                Panel(
                    "[bold red]Some checks failed — fix the issues above.[/]",
                    border_style="red",
                    box=box.ROUNDED,
                    padding=(0, 3),
                )
            )

        console.print()
