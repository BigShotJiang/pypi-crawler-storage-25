"""
Django management command: auto_translate

Usage:
    python manage.py auto_translate                              # interactive
    python manage.py auto_translate --provider claude            # direct provider
    python manage.py auto_translate --provider openrouter        # OpenRouter (picks model)
    python manage.py auto_translate --provider openrouter --model deepseek/deepseek-chat-v3-0324
    python manage.py auto_translate --dry-run                    # preview only
    python manage.py auto_translate --no-input --provider skip   # CI/CD mode
    python manage.py auto_translate --debug                      # verbose logging
    python manage.py auto_translate --batch-size 10              # control batch size
"""

import fcntl
import logging
import os
import signal
import sys
import time

from django.core.management.base import BaseCommand

from django_ai_translator.cli import ui
from django_ai_translator.conf import get_base_dir, get_languages, get_locale_path
from django_ai_translator.services.env_manager import (
    ensure_env_exists,
    get_env_status,
    load_key,
    save_key,
)
from django_ai_translator.services.extractor import TranslationExtractor
from django_ai_translator.services.po_manager import POManager
from django_ai_translator.services.translators import (
    ALL_ENV_KEYS,
    OPENROUTER_MODELS,
    PROVIDER_ENV_KEYS,
    get_translator,
)

# ── SDK availability map ─────────────────────────────────────────────

PROVIDER_SDK_MAP = {
    "claude": ("anthropic", "anthropic"),
    "openai": ("openai", "openai"),
    "openrouter": ("openai", "openai"),
    "gemini": ("google.generativeai", "google-generativeai"),
    "mistral": ("mistralai", "mistralai"),
}


def _check_sdk_installed(provider: str) -> bool:
    """Check if the required SDK is installed for the given provider."""
    if provider not in PROVIDER_SDK_MAP:
        return True
    module_name, _ = PROVIDER_SDK_MAP[provider]
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False


def _get_sdk_install_hint(provider: str) -> str:
    """Return pip install command for missing SDK."""
    if provider not in PROVIDER_SDK_MAP:
        return ""
    _, pip_name = PROVIDER_SDK_MAP[provider]
    return f"pip install {pip_name}  (or: pip install django-ai-translator[{provider}])"


def _check_gettext_installed() -> bool:
    """Check if GNU gettext (msgfmt) is available for .mo compilation."""
    import shutil

    return shutil.which("msgfmt") is not None


class Command(BaseCommand):
    help = "Auto-extract and translate missing Django .po messages via AI."

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._lock_file = None
        self._interrupted = False
        self._partial_translations = {}
        self._po_manager = None
        self._missing_by_lang = {}

    def add_arguments(self, parser):
        parser.add_argument(
            "--provider",
            type=str,
            default=None,
            choices=["claude", "openai", "openrouter", "gemini", "mistral", "skip"],
            help="Translation provider (skips interactive menu).",
        )
        parser.add_argument(
            "--model",
            type=str,
            default=None,
            help="OpenRouter model ID (e.g. anthropic/claude-sonnet-4).",
        )
        parser.add_argument("--dry-run", action="store_true", help="Preview without changes.")
        parser.add_argument("--no-input", action="store_true", help="Non-interactive CI/CD mode.")
        parser.add_argument("--debug", action="store_true", help="Debug-level logging.")
        parser.add_argument(
            "--batch-size", type=int, default=20, help="Messages per API call (default: 20)."
        )

    def handle(self, *args, **options):
        dry_run = options["dry_run"]
        no_input = options["no_input"]
        debug = options["debug"]
        batch_size = options["batch_size"]
        provider_flag = options["provider"]
        model_flag = options["model"]

        self._setup_logging(debug)
        start_time = time.time()

        # ── LOCK: prevent concurrent runs ─────────────────────────────
        if not self._acquire_lock():
            ui.show_error(
                "Another auto_translate process is already running.\n"
                "  Wait for it to finish, or remove the lock file:\n"
                "  rm -f /tmp/.django_ai_translator.lock"
            )
            sys.exit(1)

        # ── SIGNAL: graceful Ctrl+C handling ──────────────────────────
        original_sigint = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, self._handle_interrupt)

        try:
            self._run(
                dry_run=dry_run,
                no_input=no_input,
                batch_size=batch_size,
                provider_flag=provider_flag,
                model_flag=model_flag,
                start_time=start_time,
            )
        except PermissionError as exc:
            ui.show_error(
                f"Permission denied: {exc.filename or exc}\n"
                "  Check file/folder permissions on your locale directory.\n"
                "  Try: sudo chown -R $USER locale/"
            )
            sys.exit(1)
        except OSError as exc:
            if exc.errno == 28:  # ENOSPC — disk full
                ui.show_error(
                    "Disk full — cannot write translation files.\n"
                    "  Free up disk space and try again."
                )
            else:
                ui.show_error(
                    f"File system error: {exc}\n"
                    "  Check disk space and permissions."
                )
            sys.exit(1)
        finally:
            signal.signal(signal.SIGINT, original_sigint)
            self._release_lock()

    def _run(self, *, dry_run, no_input, batch_size, provider_flag, model_flag, start_time):
        # ── PRE-FLIGHT CHECK ──────────────────────────────────────────
        target_langs = get_languages()
        non_english = {c: n for c, n in target_langs.items() if c != "en"}
        if not non_english:
            ui.show_error(
                "No target languages found in settings.LANGUAGES.\n"
                "  Add languages to LANGUAGES in your settings.py, e.g.:\n"
                "  LANGUAGES = [('en', 'English'), ('es', 'Spanish'), ('fr', 'French')]"
            )
            sys.exit(1)

        locale_path = get_locale_path()  # auto-creates if missing
        base_dir = get_base_dir()

        # ── BOOT ──────────────────────────────────────────────────────
        ui.show_boot_sequence()

        ensure_env_exists()
        key_status = get_env_status()
        ui.show_env_key_status(key_status, ALL_ENV_KEYS)

        ui.show_project_detected(
            project_path=str(base_dir),
            locale_path=str(locale_path),
            lang_count=len(target_langs),
        )

        if dry_run:
            ui.show_dry_run_banner()

        # ── STEP 1: MODEL SELECTION ───────────────────────────────────
        ui.show_step(1, "SELECT TRANSLATION ENGINE")
        provider = ui.show_model_selection(no_input=no_input, provider=provider_flag)

        selected_model_id = ""
        if provider == "openrouter":
            selected_model_id = ui.show_openrouter_model_selection(
                models=OPENROUTER_MODELS,
                no_input=no_input,
                model_flag=model_flag,
            )

        # ── SDK CHECK ─────────────────────────────────────────────────
        if provider != "skip" and not _check_sdk_installed(provider):
            hint = _get_sdk_install_hint(provider)
            ui.show_error(
                f"Required SDK for '{provider}' is not installed.\n"
                f"  Install it with:\n"
                f"  {hint}"
            )
            sys.exit(1)

        # ── STEP 2: API KEY VERIFICATION ──────────────────────────────
        translator = None

        if provider != "skip":
            ui.show_step(2, "API KEY VERIFICATION")

            env_var = PROVIDER_ENV_KEYS.get(provider)
            api_key = load_key(env_var) if env_var else None

            if not api_key:
                if no_input:
                    ui.show_error(f"{env_var} not found in .env. Set it or use --provider skip.")
                    sys.exit(1)
                api_key = ui.prompt_api_key(provider.capitalize(), env_var)
                save_key(env_var, api_key)
                ui.show_success(f"Key saved to .env as {env_var}")

            translator = get_translator(provider, api_key, model_id=selected_model_id)
            ui.show_info(f"Validating API key for {translator.name}...")

            if not dry_run:
                if translator.validate_key():
                    ui.show_success("API Key Verified")
                else:
                    ui.show_auth_failure(translator.name)
                    sys.exit(1)
            else:
                ui.show_info("Key validation skipped (dry-run mode)")
                ui.show_success("API Key Loaded")
        else:
            translator = get_translator("skip")
            ui.show_info("Translation skipped — only msgid entries will be added.")

        # ── STEP 3: PROJECT SCAN ──────────────────────────────────────
        ui.show_step(3, "SCANNING CODEBASE")
        ui.console.print("[dim cyan][ SCANNING PROJECT FILES... ][/]")

        extractor = TranslationExtractor()
        messages_map = extractor.extract_all()
        all_messages = set(messages_map.keys())

        # Empty project check
        if not all_messages:
            ui.show_warning(
                "No translatable messages found in your project.\n"
                "  Make sure your code uses _(), gettext_lazy(), or ValidationError().\n"
                "  Example:\n"
                '    from django.utils.translation import gettext as _\n'
                '    msg = _("Hello world")'
            )
            elapsed = time.time() - start_time
            ui.show_final_report(
                files_scanned=extractor.files_scanned,
                total_messages=0,
                new_messages=0,
                translated=0,
                skipped=extractor.skipped_dynamic,
                languages=0,
                elapsed=elapsed,
                provider=translator.name,
                success=True,
            )
            return

        self._po_manager = POManager()
        target_languages = self._po_manager.get_target_languages()
        globally_missing = self._po_manager.find_globally_missing(all_messages)
        self._missing_by_lang = self._po_manager.find_missing_by_lang(all_messages)

        ui.show_scan_results(
            files_scanned=extractor.files_scanned,
            total_messages=len(all_messages),
            new_messages=len(globally_missing),
            skipped_dynamic=extractor.skipped_dynamic,
        )
        ui.show_languages(target_languages)

        if not globally_missing:
            ui.show_success("All messages are already translated. Nothing to do.")
            elapsed = time.time() - start_time
            ui.show_final_report(
                files_scanned=extractor.files_scanned,
                total_messages=len(all_messages),
                new_messages=0,
                translated=0,
                skipped=extractor.skipped_dynamic,
                languages=len(target_languages),
                elapsed=elapsed,
                provider=translator.name,
                success=True,
            )
            return

        if dry_run:
            ui.show_dry_run_messages(globally_missing, len(self._missing_by_lang))
            elapsed = time.time() - start_time
            ui.show_final_report(
                files_scanned=extractor.files_scanned,
                total_messages=len(all_messages),
                new_messages=len(globally_missing),
                translated=0,
                skipped=extractor.skipped_dynamic,
                languages=len(target_languages),
                elapsed=elapsed,
                provider=translator.name,
                success=True,
            )
            return

        # ── STEP 4: TRANSLATION PIPELINE ──────────────────────────────
        ui.show_step(4, "TRANSLATION PIPELINE")
        all_translations: dict[str, dict[str, str]] = {}

        if provider != "skip":
            ui.console.print("[dim cyan][ INITIATING TRANSLATION PIPELINE... ][/]\n")
            total_batches = (len(globally_missing) + batch_size - 1) // batch_size
            progress = ui.create_translation_progress()

            with progress:
                task = progress.add_task("Translating…", total=len(globally_missing))
                for i in range(0, len(globally_missing), batch_size):
                    # Check if interrupted
                    if self._interrupted:
                        break

                    batch = globally_missing[i : i + batch_size]
                    batch_num = (i // batch_size) + 1
                    progress.update(task, description=f"Batch {batch_num}/{total_batches}")
                    result = translator.translate_batch(batch, target_languages)
                    if result:
                        all_translations.update(result)
                    else:
                        ui.show_warning(
                            f"Batch {batch_num}/{total_batches} failed — "
                            f"messages will have empty msgstr."
                        )
                    progress.advance(task, len(batch))

            # Store for graceful shutdown
            self._partial_translations = all_translations

            if self._interrupted:
                ui.console.print()
                ui.show_warning(
                    f"Interrupted! Saving {len(all_translations)} "
                    f"completed translations before exit..."
                )

            ui.console.print()
            ui.show_success(
                f"Translated {len(all_translations)}/{len(globally_missing)} messages"
            )
        else:
            ui.show_info("Skipping translation — adding msgid entries only.")

        # ── STEP 5: .PO FILE UPDATE ───────────────────────────────────
        ui.show_step(5, ".PO FILE UPDATE")
        stats = self._po_manager.apply_translations(all_translations, self._missing_by_lang)
        ui.show_po_update_results(stats)

        # ── STEP 6: COMPILE TRANSLATIONS ──────────────────────────────
        ui.show_step(6, "COMPILE TRANSLATIONS")

        if not _check_gettext_installed():
            ui.show_warning(
                "GNU gettext (msgfmt) is not installed — skipping .mo compilation.\n"
                "  .po files are saved, but .mo files were not generated.\n"
                "  Install gettext:\n"
                "    Ubuntu/Debian: sudo apt install gettext\n"
                "    macOS:         brew install gettext\n"
                "    Windows:       download from https://mlocati.github.io/articles/gettext-iconv-windows.html"
            )
        elif self._po_manager.compile_messages():
            ui.show_success("Compilation successful — .mo files ready")
        else:
            ui.show_warning(
                "compilemessages failed — .po files are saved but .mo not generated.\n"
                "  Try running manually: python manage.py compilemessages"
            )

        # ── FINAL REPORT ──────────────────────────────────────────────
        elapsed = time.time() - start_time
        ui.show_final_report(
            files_scanned=extractor.files_scanned,
            total_messages=len(all_messages),
            new_messages=len(globally_missing),
            translated=len(all_translations),
            skipped=extractor.skipped_dynamic,
            languages=len(target_languages),
            elapsed=elapsed,
            provider=translator.name,
            success=len(all_translations) > 0 or provider == "skip",
        )

    # ── Graceful interrupt handler ────────────────────────────────────

    def _handle_interrupt(self, signum, frame):
        """Handle Ctrl+C — save partial work instead of crashing."""
        if self._interrupted:
            # Second Ctrl+C = force exit
            ui.console.print("\n[bold red]  Force quit.[/]")
            sys.exit(130)

        self._interrupted = True
        ui.console.print("\n[bold yellow]  ▲ Ctrl+C detected — finishing current batch...[/]")

    # ── Lock file management ──────────────────────────────────────────

    def _acquire_lock(self) -> bool:
        """Acquire a lock file to prevent concurrent runs."""
        lock_path = "/tmp/.django_ai_translator.lock"
        try:
            self._lock_file = open(lock_path, "w")
            fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            self._lock_file.write(str(os.getpid()))
            self._lock_file.flush()
            return True
        except (OSError, IOError):
            if self._lock_file:
                self._lock_file.close()
                self._lock_file = None
            return False

    def _release_lock(self):
        """Release the lock file."""
        if self._lock_file:
            try:
                fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_UN)
                self._lock_file.close()
                os.unlink("/tmp/.django_ai_translator.lock")
            except OSError:
                pass
            self._lock_file = None

    @staticmethod
    def _setup_logging(debug: bool):
        log = logging.getLogger("auto_translate")
        if not log.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
            log.addHandler(handler)
        log.setLevel(logging.DEBUG if debug else logging.WARNING)
