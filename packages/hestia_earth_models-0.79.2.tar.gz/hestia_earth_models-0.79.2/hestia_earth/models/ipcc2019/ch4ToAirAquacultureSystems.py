from hestia_earth.schema import EmissionMethodTier, CycleFunctionalUnit
from hestia_earth.utils.model import find_term_match
from hestia_earth.utils.tools import safe_parse_float, non_empty_list, list_sum

from hestia_earth.models.log import logRequirements, logShouldRun
from hestia_earth.models.utils.term import get_lookup_value
from hestia_earth.models.utils.emission import _new_emission
from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "siteArea": "",
        "siteDuration": "",
        "functionalUnit": "relative",
        "site": {
            "@type": "Site",
            "measurements": [
                {
                    "@type": "Measurement",
                    "term.@id": ["salineWater", "brackishWater", "freshWater"],
                }
            ],
        },
        "optional": {
            "otherSitesArea": "",
            "otherSitesDuration": "",
        },
    }
}
LOOKUPS = {"measurement": "IPCC_2019_CH4_aquaculture_EF"}
RETURNS = {
    "Emission": [
        {
            "value": "",
            "min": "",
            "max": "",
            "methodTier": "tier 1",
            "statsDefinition": "modelled",
        }
    ]
}
TERM_ID = "ch4ToAirAquacultureSystems"
TIER = EmissionMethodTier.TIER_1.value
_WATER_TERM_IDS = ["salineWater", "brackishWater", "freshWater"]


def _emission(value: float, min: float, max: float):
    emission = _new_emission(term=TERM_ID, model=MODEL, value=value, min=min, max=max)
    emission["methodTier"] = TIER
    return emission


def _find_measurement(site: dict):
    measurements = non_empty_list(
        [
            find_term_match(site.get("measurements", []), term_id, None)
            for term_id in _WATER_TERM_IDS
        ]
    )
    return measurements[0] if measurements else None


def _run(cycle: dict, factors: list):
    site_areas = non_empty_list(
        [cycle.get("siteArea")] + cycle.get("otherSitesArea", [])
    )
    site_durations = non_empty_list(
        [cycle.get("siteDuration")] + cycle.get("otherSitesDuration", [])
    )

    ratio = list_sum(
        [
            site_duration * site_area / 365
            for site_area, site_duration in zip(site_areas, site_durations)
        ]
    )

    factor_value, factor_min, factor_max = factors
    return [_emission(ratio * factor_value, ratio * factor_min, ratio * factor_max)]


def _should_run(cycle: dict):
    is_relative = cycle.get("functionalUnit") == CycleFunctionalUnit.RELATIVE.value
    site_area = cycle.get("siteArea")
    site_duration = cycle.get("siteDuration")

    water_measurement = _find_measurement(cycle.get("site", {}))
    has_water_type = water_measurement is not None
    water_term = (water_measurement or {}).get("term", {})
    factor_value = safe_parse_float(
        get_lookup_value(water_term, LOOKUPS.get("measurement")), default=None
    )
    factor_min = safe_parse_float(
        get_lookup_value(water_term, f"{LOOKUPS.get('measurement')}-min"), default=None
    )
    factor_max = safe_parse_float(
        get_lookup_value(water_term, f"{LOOKUPS.get('measurement')}-max"), default=None
    )

    logRequirements(
        cycle,
        model=MODEL,
        term=TERM_ID,
        is_relative=is_relative,
        site_area=site_area,
        site_duration=site_duration,
        has_water_type=has_water_type,
    )

    should_run = all(
        [
            site_duration,
            is_relative,
            site_area,
            has_water_type,
            factor_value is not None,
            factor_min is not None,
            factor_max is not None,
        ]
    )
    logShouldRun(cycle, MODEL, TERM_ID, should_run, methodTier=TIER)
    return should_run, [factor_value, factor_min, factor_max]


def run(cycle: dict):
    should_run, factors = _should_run(cycle)
    return _run(cycle, factors) if should_run else []
