from hestia_earth.schema import EmissionMethodTier
from hestia_earth.utils.tools import flatten
from hestia_earth.utils.blank_node import group_by_keys

from hestia_earth.models.log import logShouldRun, logRequirements
from hestia_earth.models.utils.completeness import _is_term_type_complete
from .n2OToAir_indirect_emissions_utils import _INPUTS_GROUP_KEYS, run as run_emission
from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "completeness.electricityFuel": "True",
        "emissions": [
            {
                "@type": "Emission",
                "value": "",
                "term.@id": "nh3ToAirFuelCombustion",
                "inputs": [
                    {
                        "@type": "Input",
                        "value": "",
                        "term.termType": "fuel",
                        "optional": {"operation": ""},
                    }
                ],
            },
            {
                "@type": "Emission",
                "value": "",
                "term.@id": "noxToAirFuelCombustion",
                "inputs": [
                    {
                        "@type": "Input",
                        "value": "",
                        "term.termType": "fuel",
                        "optional": {"operation": ""},
                    }
                ],
            },
        ],
        "optional": {
            "site": {
                "@type": "Site",
                "measurements": [
                    {"@type": "Measurement", "value": "", "term.@id": "ecoClimateZone"}
                ],
            }
        },
    }
}
LOOKUPS = {
    "emission": [
        "IPCC_2019_EF4_FACTORS",
        "IPCC_2019_EF4_FACTORS-max",
        "IPCC_2019_EF4_FACTORS-min",
        "IPCC_2019_EF5_FACTORS",
        "IPCC_2019_EF5_FACTORS-max",
        "IPCC_2019_EF5_FACTORS-min",
    ]
}
RETURNS = {
    "Emission": [{"value": "", "methodTier": "tier 1", "inputs": "", "operation": ""}]
}
TERM_ID = "n2OToAirFuelCombustionIndirect"
TIER = EmissionMethodTier.TIER_1.value
_EMISSION_IDS = [e["term.@id"] for e in REQUIREMENTS["Cycle"]["emissions"]]


def _should_run(cycle: dict):
    # group emissions by inputs first
    emissions = [
        e
        for e in cycle.get("emissions", [])
        if e.get("term", {}).get("@id") in _EMISSION_IDS
    ]
    grouped_emissions = group_by_keys(emissions, _INPUTS_GROUP_KEYS)

    has_emissions = bool(grouped_emissions)
    is_complete = _is_term_type_complete(cycle, "electricityFuel")

    should_run = all([has_emissions, is_complete])

    # only log failure at the cycle level
    if not should_run:
        logRequirements(
            cycle,
            model=MODEL,
            term=TERM_ID,
            has_emissions=has_emissions,
            term_type_electricityFuel_complete=is_complete,
        )
        logShouldRun(cycle, MODEL, TERM_ID, should_run)

    return should_run, grouped_emissions


def run(cycle: dict):
    should_run, grouped_emissions = _should_run(cycle)

    return (
        flatten(
            [
                run_emission(
                    TERM_ID,
                    _EMISSION_IDS,
                    cycle | {"emissions": emissions},
                    group_by_inputs=True,
                )
                for emissions in grouped_emissions.values()
            ]
        )
        if should_run
        else []
    )
