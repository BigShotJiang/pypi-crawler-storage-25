from hestia_earth.schema import SiteSiteType
from hestia_earth.utils.lookup import download_lookup, get_table_value
from hestia_earth.utils.tools import safe_parse_float

from hestia_earth.models.log import debugMissingLookup
from hestia_earth.models.utils.impact_assessment import get_site
from hestia_earth.models.utils.lookup import get_region_lookup_value
from hestia_earth.models.utils.impacts import run_from_resourceUses
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "site": {
            "@type": "Site",
            "or": {
                "awareWaterBasinId": "",
                "country": {"@type": "Term", "termType": "region"},
            },
        },
        "emissionsResourceUse": [
            {
                "@type": "Indicator",
                "term.@id": "freshwaterWithdrawalsDuringCycle",
                "value": "",
            },
            {
                "@type": "Indicator",
                "term.@id": "freshwaterWithdrawalsInputsProduction",
                "value": "",
            },
        ],
    }
}
RETURNS = {"Indicator": [{"value": ""}]}
LOOKUPS = {
    "@doc": "Different lookup files are used depending on the situation",
    "awareWaterBasinId-2-0": ["CFs_agri", "CFs_nonagri", "CFs_unspecified"],
    "region-aware-2-0-factors": ["CFs_agri", "CFs_nonagri", "CFs_unspecified"],
}
TERM_ID = "scarcityWeightedWaterUse"
AWARE_KEY = "awareWaterBasinId"
AGRI_SITE_TYPES = [
    SiteSiteType.CROPLAND.value,
    SiteSiteType.GLASS_OR_HIGH_ACCESSIBLE_COVER.value,
    SiteSiteType.PERMANENT_PASTURE.value,
]
_REGION_LOOKUP = "region-aware-2-0-factors.csv"
_AWARE_LOOKUP = "awareWaterBasinId-2-0.csv"


def _lookup_column(site: dict):
    site_type = site.get("siteType")
    return (
        "CFs_unspecified"
        if not site_type
        else "CFs_agri" if site_type in AGRI_SITE_TYPES else "CFs_nonagri"
    )


def _get_factor_from_basinId(site: dict, aware_id: str) -> float:
    lookup_col = _lookup_column(site)
    lookup = download_lookup(_AWARE_LOOKUP)
    value = get_table_value(lookup, AWARE_KEY, int(aware_id), lookup_col)
    debugMissingLookup(
        _AWARE_LOOKUP, AWARE_KEY, aware_id, lookup_col, value, model=MODEL, term=TERM_ID
    )
    return safe_parse_float(value, default=None)


def _get_factor_from_region(region_id: str, site: dict):
    lookup_col = _lookup_column(site)
    value = get_region_lookup_value(
        _REGION_LOOKUP, region_id, lookup_col, model=MODEL, term=TERM_ID
    )
    return safe_parse_float(value, default=None)


def _extend_data(impact_assessment: dict):
    site = get_site(impact_assessment)
    aware_id = site.get(AWARE_KEY)
    aware_factor_from_basinId = (
        _get_factor_from_basinId(site, aware_id) if aware_id else None
    )

    def get_data(blank_node: dict, country_id: str):
        term_id = blank_node.get("term", {}).get("@id")
        is_during_cycle = term_id.endswith("DuringCycle")

        factor = (
            aware_factor_from_basinId if is_during_cycle else None
        ) or _get_factor_from_region(country_id, site if is_during_cycle else {})

        return {
            "aware-id": aware_id,
            "factor": factor,
        }

    return get_data


def run(impact_assessment: dict):
    return run_from_resourceUses(
        model=MODEL,
        term_id=TERM_ID,
        indicator_prefix="freshwaterWithdrawals",
        impact_assessment=impact_assessment,
        extend_data_func=_extend_data(impact_assessment),
    )
