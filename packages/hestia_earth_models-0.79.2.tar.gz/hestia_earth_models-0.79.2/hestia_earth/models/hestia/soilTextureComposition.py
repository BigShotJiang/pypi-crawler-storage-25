from math import isclose

from hestia_earth.schema import MeasurementMethodClassification, TermTermType
from hestia_earth.utils.blank_node import get_node_value, flatten
from hestia_earth.utils.model import filter_list_term_type
from hestia_earth.utils.tools import non_empty_list
from hestia_earth.utils.log_utils import (
    log_as_table,
    format_bool,
    format_conditional_message,
    format_float,
    format_str,
)

from hestia_earth.models.log import (
    logRequirements,
    logShouldRun,
)
from hestia_earth.models.utils.blank_node import (
    filter_list_term_id,
    split_nodes_by_dates,
)
from hestia_earth.models.utils.group_nodes import group_nodes_by
from hestia_earth.models.utils.measurement import (
    _new_measurement,
    by_strongest_method_classification,
)
from hestia_earth.models.utils.select_nodes import (
    _shallowest_node,
    select_nodes_by,
    prioritise_nodes_where,
)
from hestia_earth.models.utils.term import get_lookup_value
from . import MODEL

REQUIREMENTS = {
    "Site": {
        "measurements": [
            {
                "@type": "Measurement",
                "value": "100",
                "term.termType": "soilTexture",
                "optional": {"dates": "", "depthUpper": "", "depthLower": ""},
            }
        ],
        "none": {
            "measurements": [
                {
                    "@type": "Measurement",
                    "term.@id": ["clayContent", "sandContent", "siltContent"],
                }
            ],
        },
    }
}
RETURNS = {
    "Measurement": [
        {
            "value": "",
            "min": "",
            "max": "",
            "methodClassification": "modelled using other measurements",
        }
    ]
}
LOOKUPS = {
    "soilTexture": [
        "clayContentAverage",
        "clayContentMax",
        "clayContentMin",
        "sandContentAverage",
        "sandContentMax",
        "sandContentMin",
        "siltContentAverage",
        "siltContentMax",
        "siltContentMin",
    ]
}
TERM_ID = "clayContent,sandContent,siltContent"

MEASUREMENT_TERM_IDS = TERM_ID.split(",")
CLAY_CONTENT_TERM_ID = MEASUREMENT_TERM_IDS[0]
SAND_CONTENT_TERM_ID = MEASUREMENT_TERM_IDS[1]
SILT_CONTENT_TERM_ID = MEASUREMENT_TERM_IDS[2]
METHOD = MeasurementMethodClassification.MODELLED_USING_OTHER_MEASUREMENTS.value


def _measurement(
    term_id: str,
    value: float,
    min: float,
    max: float,
    depth_upper: float = None,
    depth_lower: float = None,
    dates: list[str] = None,
):
    measurement = _new_measurement(
        term_id,
        value=value,
        min=min,
        max=max,
        depthUpper=depth_upper,
        depthLower=depth_lower,
        model=MODEL,
    )
    update_dict = {
        "methodClassification": METHOD,
        **({"dates": dates} if dates else {}),
    }
    return measurement | update_dict


def _has_depth(node: dict) -> bool:
    """Whether a Measurement includes complete depth data."""
    return all(
        [
            (node.get("depthUpper") is not None),
            (node.get("depthLower") is not None),
        ]
    )


def _has_dates(node: dict) -> bool:
    """Whether a Measurement includes dates."""
    return bool(node.get("dates", []))


def _has_value_100(node: dict) -> bool:
    """Whether a node's value is 100 (within a tolerence of ±0.5"""
    return isclose(get_node_value(node), 100, abs_tol=0.5)


def _get_soil_texture_nodes(measurements: list[dict]) -> list[dict]:
    """
    Get `soilTexture` Measurements from a list of measurements.

    Prioritise nodes with depth and dates. Split nodes by dates where possible.
    """
    soil_texture_nodes = select_nodes_by(
        measurements,
        [
            lambda nodes: filter_list_term_type(nodes, TermTermType.SOILTEXTURE),
            lambda nodes: prioritise_nodes_where(nodes, _has_depth),
            lambda nodes: prioritise_nodes_where(nodes, _has_dates),
        ],
    )
    return split_nodes_by_dates(soil_texture_nodes)


def _retrieve_model_factors(soil_texture_nodes: list[dict]) -> dict:
    """
    Retrieve model factors for average, min & max clay, sand and silt contents from lookups.

    Each unique `soilTexture` Measurement should have associated factors.
    """
    unique_soil_textures = {
        id: term
        for node in soil_texture_nodes
        if (id := (term := node.get("term", {})).get("@id"))
    }

    return {
        id: {
            column: get_lookup_value(term, column, default_value=None)
            for column in LOOKUPS["soilTexture"]
        }
        for id, term in unique_soil_textures.items()
    }


def _format_has_clay_sand_silt(val: bool, nodes: list[dict]):
    """
    Format log message for whether a Site already has a value for clay, sand or silt content.
    """
    unique_ids = group_nodes_by(nodes, "term.@id").keys()
    ids_joined = " and ".join(unique_ids)
    return format_conditional_message(
        val,
        f"True (Site has existing value for {ids_joined} - model cannot run)",
        "False (Site has no existing values for clayContent sandContent or siltContent - model may run)",
    )


def _format_factors(model_factors: dict) -> str:
    """
    Format model factors as a table for logging.
    """
    return (
        log_as_table(
            {
                "term_id": format_str(term_id),
                **{
                    key: format_float(factors.get(key), "pct")
                    for key in LOOKUPS["soilTexture"]
                },
            }
            for term_id, factors in model_factors.items()
        )
        if model_factors
        else "None"
    )


def _format_nodes(soil_texture_nodes: list[dict]) -> str:
    """Format `soilTexture` Measurement data as a table for logging."""
    return (
        log_as_table(
            {
                "term_id": format_str(node.get("term", {}).get("@id")),
                "value": format_float(get_node_value(node), "pct"),
                "depthUpper": format_float(node.get("depthUpper"), "cm"),
                "depthLower": format_float(node.get("depthLower"), "cm"),
                "dates": " ".join(format_str(date) for date in node.get("dates", [])),
                "methodClassification": format_str(
                    node.get("methodClassification", {})
                ),
            }
            for node in soil_texture_nodes
        )
        if soil_texture_nodes
        else "None"
    )


def _should_run(site: dict):
    """
    Determine whether the model can run on a Site.

    Parameters
    ----------
    site : dict
        A HESTIA Site[https://www.hestia.earth/schema/Site]

    Returns
    -------
    should_run : bool
    soil_texture_nodes : list[dict]
    model_factors : dict
    """
    measurements = site.get("measurements", [])

    soil_composition_nodes = filter_list_term_id(measurements, MEASUREMENT_TERM_IDS)
    has_clay_sand_silt_content = bool(soil_composition_nodes)

    soil_texture_nodes = _get_soil_texture_nodes(measurements)
    model_factors = _retrieve_model_factors(soil_texture_nodes)

    soil_texture_values_all_100 = all(
        _has_value_100(node) for node in soil_texture_nodes
    )

    model_factors_complete = not any(
        v is None for group in model_factors.values() for v in group
    )

    should_run = all(
        [
            not has_clay_sand_silt_content,
            bool(soil_texture_nodes) and soil_texture_values_all_100,
            bool(model_factors) and model_factors_complete,
        ]
    )

    for term_id in MEASUREMENT_TERM_IDS:

        logRequirements(
            site,
            model=MODEL,
            term=term_id,
            has_clay_sand_silt_content=_format_has_clay_sand_silt(
                has_clay_sand_silt_content, soil_composition_nodes
            ),
            soil_texture_values_100=format_conditional_message(
                soil_texture_values_all_100,
                "True (All soilTexture measurements have value 100 - model may run)",
                "False (Not all soilTexture measurements have value 100 - model cannot run)",
            ),
            model_factors_complete=format_bool(model_factors_complete),
            has_soil_texture=format_bool(bool(soil_texture_nodes)),
            model_factors=_format_factors(model_factors),
            soil_texture_nodes=_format_nodes(soil_texture_nodes),
        )

        logShouldRun(site, MODEL, term_id, should_run)

    return should_run, soil_texture_nodes, model_factors


def _run(soil_texture_nodes, model_factors) -> list[dict]:
    """
    Run the model.

    For each unique combination of depth and date, select the `soilTexture` measurement with the strongest method
    classifcation and convert it to clay, sand and silt Measurements.
    """
    grouped = group_nodes_by(soil_texture_nodes, ["depthUpper", "depthLower", "dates"])
    strongest = non_empty_list(
        [
            select_nodes_by(
                nodes, [by_strongest_method_classification, _shallowest_node]
            )
            for nodes in grouped.values()
        ]
    )

    def convert_node(node: dict) -> list[dict]:
        """
        Convert a soil texture node to clay, sand and silt nodes.
        """
        input_id = node["term"]["@id"]
        factors = model_factors[input_id]
        dates = node.get("dates")
        return [
            _measurement(
                term_id=output_id,
                value=factors[f"{output_id}Average"],
                min=factors[f"{output_id}Min"],
                max=factors[f"{output_id}Max"],
                depth_upper=node.get("depthUpper"),
                depth_lower=node.get("depthLower"),
                dates=dates[:1] if dates else None,
            )
            for output_id in MEASUREMENT_TERM_IDS
        ]

    return flatten([convert_node(node) for node in strongest])


def run(site: dict):
    should_run, soil_texture_nodes, model_factors = _should_run(site)
    return _run(soil_texture_nodes, model_factors) if should_run else []
