from hestia_earth.utils.model import find_term_match, find_primary_product
from hestia_earth.utils.blank_node import get_node_value

from hestia_earth.models.log import logRequirements, logShouldRun
from . import MODEL


def should_run(term_id: str, cycle: dict):
    product = find_primary_product(cycle) or {}
    product_value = get_node_value(product, default=None)

    practices = cycle.get("practices", [])
    currentPlantationAge = get_node_value(
        find_term_match(practices, "currentPlantationAge"), default=None
    )
    lifespan = get_node_value(
        find_term_match(practices, "plantationLifespan"), default=None
    )
    productive_lifespan = get_node_value(
        find_term_match(practices, "plantationProductiveLifespan"), default=None
    )

    logRequirements(
        cycle,
        model=MODEL,
        term=term_id,
        product_value=product_value,
        currentPlantationAge=currentPlantationAge,
        plantationLifespan=lifespan,
        plantationProductiveLifespan=productive_lifespan,
    )

    should_run = any(
        [
            all([product_value is not None, currentPlantationAge is None]),
            all(
                [
                    lifespan is not None,
                    productive_lifespan is not None,
                ]
            ),
        ]
    )
    logShouldRun(cycle, MODEL, term_id, should_run)
    return should_run, [currentPlantationAge, lifespan, productive_lifespan]
