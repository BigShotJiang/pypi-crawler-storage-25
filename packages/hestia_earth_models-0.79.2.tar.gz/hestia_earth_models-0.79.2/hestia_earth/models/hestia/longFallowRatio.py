from hestia_earth.utils.model import find_term_match
from hestia_earth.utils.tools import list_sum
from hestia_earth.utils.log_utils import format_conditional_message

from hestia_earth.models.log import (
    logRequirements,
    logShouldRun,
)
from hestia_earth.models.utils.practice import _new_practice
from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "practices": [
            {"@type": "Practice", "value": "> 0", "term.@id": "longFallowDuration"},
            {
                "@type": "Practice",
                "value": "> 0 and greater than longFallowDuration",
                "term.@id": "rotationDuration",
            },
        ]
    }
}
RETURNS = {"Practice": [{"value": ""}]}
TERM_ID = "longFallowRatio"


def _run(longFallowDuration: float, rotationDuration: float):
    value = rotationDuration / (rotationDuration - longFallowDuration)
    return [_new_practice(term=TERM_ID, model=MODEL, value=value)]


def _should_run(cycle: dict):
    practices = cycle.get("practices", [])

    longFallowDuration = list_sum(
        find_term_match(practices, "longFallowDuration", {}).get("value", 0), 0
    )
    rotationDuration = list_sum(
        find_term_match(practices, "rotationDuration", {}).get("value", 0), 0
    )

    valid_rotationDuration = (
        rotationDuration > longFallowDuration
    )  # rotation includes long fallow

    logRequirements(
        cycle,
        model=MODEL,
        term=TERM_ID,
        longFallowDuration=longFallowDuration,
        rotationDuration=rotationDuration,
        valid_rotationDuration=format_conditional_message(
            valid_rotationDuration,
            "True",
            "False (rotationDuration must be longer than longFallowDuration)",
        ),
    )

    should_run = all(
        [longFallowDuration > 0, rotationDuration > 0, valid_rotationDuration]
    )
    logShouldRun(cycle, MODEL, TERM_ID, should_run)
    return should_run, longFallowDuration, rotationDuration


def run(cycle: dict):
    should_run, longFallowDuration, rotationDuration = _should_run(cycle)
    return _run(longFallowDuration, rotationDuration) if should_run else []
