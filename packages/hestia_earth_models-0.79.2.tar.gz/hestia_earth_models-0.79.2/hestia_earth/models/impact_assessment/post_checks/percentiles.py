from hestia_earth.models.utils.percentiles import include_percentiles


def run(impact: dict):
    return include_percentiles(impact, ["emissionsResourceUse", "impacts", "endpoints"])
