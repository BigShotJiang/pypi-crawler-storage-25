import os
import platform
import resource
from functools import wraps
from typing import Callable, Union
from hestia_earth.utils.log import get_logger, log_join_args, log_node_suffix
from hestia_earth.utils.tools import to_precision

from .log_utils import _accumulate, _format_log, _format_missingLookup_log

logger_name = "models"
logger = get_logger("hestia_earth." + logger_name)


def debugValues(log_node: dict, **kwargs):
    logger.debug(log_node_suffix(log_node) + log_join_args(**kwargs))
    model = kwargs.pop("model", None)
    term = kwargs.pop("term", None)
    _accumulate(
        _format_log(log_node, model=model, term=term, logger_name=logger_name, **kwargs)
    )


def logRequirements(log_node: dict, **kwargs):
    logger.info(
        log_node_suffix(log_node) + "requirements=true, " + log_join_args(**kwargs)
    )
    model = kwargs.pop("model", None)
    term = kwargs.pop("term", None)
    _accumulate(
        _format_log(
            log_node,
            model=model,
            term=term,
            logger_name=logger_name,
            requirements=True,
            **kwargs,
        )
    )


def logShouldRun(
    log_node: dict, model: str, term: Union[str, None], should_run: bool, **kwargs
):
    extra = (", " + log_join_args(**kwargs)) if kwargs else ""
    logger.info(
        log_node_suffix(log_node) + "should_run=%s, model=%s, term=%s" + extra,
        should_run,
        model,
        term,
    )
    _accumulate(
        _format_log(
            log_node,
            model=model,
            term=term,
            logger_name=logger_name,
            shouldRun=should_run,
            **kwargs,
        )
    )


def debugMissingLookup(
    lookup_name: str, row: str, row_value: str, col: str, value, **kwargs
):
    if value is not None and value != "":
        return
    extra = (", " + log_join_args(**kwargs)) if kwargs else ""
    logger.warning(
        f"Missing lookup={lookup_name}, {row}={row_value}, column={col}" + extra
    )
    model = kwargs.pop("model", None)
    model and _format_missingLookup_log(
        model, lookup_name, row, row_value, col, **kwargs
    )


def logErrorRun(model: str, term: str, error: str):
    logger.error("model=%s, term=%s, error=%s", model, term, error)
    _accumulate({term: {logger_name: {model: {"error": error}}}})


def _get_memory_use():
    factor = 1024 * (1024 if platform.system() in ["Darwin", "Windows"] else 1)
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / factor


def log_memory(**kwargs):
    """
    Log memory usage at a specific moment.
    """
    value = _get_memory_use()
    extra = (", " + log_join_args(**kwargs)) if len(kwargs.keys()) > 0 else ""
    logger.info("memory_used=%s, unit=MB" + extra, value)


def log_memory_use(func: Callable):
    """
    Log the memory usage of a function when it is called.
    """
    name = func.__name__
    module = os.path.basename(func.__code__.co_filename)

    @wraps(func)
    def wrapper(*args, **kwargs):
        before = _get_memory_use()
        result = func(*args, **kwargs)
        after = _get_memory_use()
        value = after - before
        logger.info(
            log_join_args(
                memory_used=to_precision(value),
                before=to_precision(before),
                after=to_precision(after),
                unit="MB",
                name=name,
                module=module,
            )
        )
        return result

    return wrapper
