from hestia_earth.models.log import logShouldRun
from hestia_earth.models.utils.indicator import _new_indicator
from hestia_earth.models.utils.impact_assessment import impact_country_value
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "emissionsResourceUse": [
            {"@type": "Indicator", "value": "", "term.termType": "emission"}
        ],
        "site": {"@type": "Site", "country": {"@type": "Term", "termType": "region"}},
    }
}
RETURNS = {"Indicator": {"value": ""}}
LOOKUPS = {"region-emission-OzoneFormationDamageToHumanHealthLCImpactCF": ""}
TERM_ID = "damageToHumanHealthPhotochemicalOzoneFormation"


def run(impact_assessment: dict):
    value = impact_country_value(
        MODEL, TERM_ID, impact_assessment, f"{list(LOOKUPS.keys())[0]}.csv"
    )

    logShouldRun(impact_assessment, MODEL, TERM_ID, value is not None)
    return _new_indicator(term=TERM_ID, model=MODEL, value=value)
