from hestia_earth.utils.tools import non_empty_list
from hestia_earth.utils.emission import emissions_in_system_boundary

from hestia_earth.models.log import logShouldRun
from .. import MODEL

REQUIREMENTS = {
    "Cycle": {
        "emissions": [{"@type": "Emission"}],
    }
}
RETURNS = {"Emission": [{"deleted": "True"}]}
MODEL_KEY = "deleted"


def _run_emission(cycle: dict, term_ids: list):
    def run(emission: dict):
        term_id = emission.get("term", {}).get("@id")
        should_run = term_id not in term_ids
        if should_run:
            logShouldRun(cycle, MODEL, term_id, should_run, key=MODEL_KEY)
        return (emission | {"deleted": True}) if should_run else None

    return run


def run(cycle: dict):
    emission_ids = emissions_in_system_boundary()
    emissions = cycle.get("emissions", [])
    return (
        non_empty_list(map(_run_emission(cycle, emission_ids), emissions))
        if len(emission_ids) > 0
        else []
    )
