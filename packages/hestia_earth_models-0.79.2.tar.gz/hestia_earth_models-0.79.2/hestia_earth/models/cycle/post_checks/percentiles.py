from hestia_earth.models.utils.percentiles import include_percentiles


def run(cycle: dict):
    # other blank node percentiles are generated during aggregation
    return include_percentiles(cycle, ["emissions"])
