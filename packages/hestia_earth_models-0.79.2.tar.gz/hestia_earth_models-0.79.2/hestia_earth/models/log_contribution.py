import os

# Global dictionary to store contributions
_contributions = {}


def _enabled():
    return os.getenv("LOG_CONTRIBUTION_ENABLED", "false").lower() == "true"


def reset_contributions():
    global _contributions
    _contributions = {}


def get_contributions():
    return _contributions


def register_contribution(
    index: int,
    model: str,
    term_id: str,
    value: float,
    key: str = "emissionsResourceUse",
):
    # do not store `0` values, which represent 90% of the total size of the file
    # logs should be used to determine what is missing - the rest has `0` factor and does not contribute
    if _enabled() and index is not None and value:
        index_str = str(index)
        _contributions[key] = _contributions.get(key, {})
        _contributions[key][index_str] = _contributions[key].get(index_str, {})
        _contributions[key][index_str][term_id] = _contributions[key][index_str].get(
            term_id, {}
        ) | {model: value}
