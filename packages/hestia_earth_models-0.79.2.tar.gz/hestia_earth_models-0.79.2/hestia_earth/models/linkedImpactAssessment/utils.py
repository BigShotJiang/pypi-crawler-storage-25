from hestia_earth.utils.tools import non_empty_list, flatten, list_sum, pick
from hestia_earth.utils.log_utils import log_as_table
from hestia_earth.utils.blank_node import get_node_value

from hestia_earth.models.log import (
    debugValues,
    logRequirements,
    logShouldRun,
)
from hestia_earth.models.utils import sum_values
from hestia_earth.models.utils.group_nodes import group_nodes_by
from hestia_earth.models.utils.indicator import _new_indicator
from hestia_earth.models.utils.impact_assessment import (
    get_product,
    convert_value_from_cycle,
)
from hestia_earth.models.utils.input import load_impacts
from . import MODEL


def _indicator(model: str, term_id: str, value: float, input: dict):
    indicator = _new_indicator(term=term_id, model=model, value=value, inputs=[input])
    return indicator


def _run_indicators(impact_assessment: dict, product: dict, term_id: str, model: str):
    def run(values: list):
        input = values[0].get("input").get("term", {})
        indicator = values[0].get("indicator")
        values_from_cycle = non_empty_list(
            [
                value.get("input-value") * value.get("indicator").get("value")
                for value in values
            ]
        )
        value = convert_value_from_cycle(
            product,
            sum_values(values_from_cycle),
        )

        # show values per input in the logs
        debugValues(
            impact_assessment,
            model=model,
            term=term_id,
            value=value,
            coefficient=1,
            input=input.get("@id"),
        )

        return (
            (
                _indicator(model, term_id, value, input)
                | pick(indicator, ["landCover", "previousLandCover"])
            )
            if value is not None
            else None
        )

    return run


def _run_inputs_production(impact_assessment: dict, term_id: str, model: str):
    product = get_product(impact_assessment)
    cycle = impact_assessment.get("cycle", {})
    inputs = load_impacts(cycle.get("inputs", []))

    # group all indicators per `landCover` and `previousLandCover`
    all_indicators = flatten(
        [
            {
                "indicator": indicator,
                "indicator-value": get_node_value(indicator),
                "input": input,
                "input-value": get_node_value(input),
            }
            for input in inputs
            for indicator in (
                input.get("impactAssessment", {}).get("emissionsResourceUse", [])
                + input.get("impactAssessment", {}).get("impacts", [])
            )
            if indicator.get("term", {}).get("@id")
            in [term_id, term_id.replace("InputsProduction", "DuringCycle")]
        ]
    )
    valid_indicators = [
        value
        for value in all_indicators
        if all(
            [
                (value.get("indicator-value") or -1) > 0,
                (value.get("input-value") or -1) > 0,
            ]
        )
    ]
    grouped_indicators = group_nodes_by(
        valid_indicators,
        [
            "input.term.@id",
            "indicator.landCover.@id",
            "indicator.previousLandCover.@id",
        ],
    )

    # log per valid group only
    for indicators in grouped_indicators.values():
        input_term_id = indicators[0].get("input").get("term", {}).get("@id")

        logRequirements(
            impact_assessment,
            model=model,
            term=input_term_id,
            emission_id=term_id,
            indicators=log_as_table(
                [
                    {
                        "indicator-id": value.get("indicator")
                        .get("term", {})
                        .get("@id"),
                        "indicator-value": value.get("indicator-value"),
                        "input-value": value.get("input-value"),
                    }
                    for value in indicators
                ]
            ),
        )
        logShouldRun(impact_assessment, model, term_id, True, emission_id=term_id)

    return non_empty_list(
        flatten(
            map(
                _run_indicators(impact_assessment, product, term_id, model),
                grouped_indicators.values(),
            )
        )
    )


def _should_run(impact_assessment: dict):
    product = get_product(impact_assessment) or {}
    product_value = list_sum(product.get("value", []), default=None)
    economic_value = product.get("economicValueShare")
    # we do not log anything here as we should not show logs on the resourceUse level - only inputs level
    return all([product, product_value, economic_value])


def run_inputs_production(impact_assessment: dict, term_id: str, model: str = MODEL):
    should_run = _should_run(impact_assessment)
    return (
        _run_inputs_production(impact_assessment, term_id, model) if should_run else []
    )
