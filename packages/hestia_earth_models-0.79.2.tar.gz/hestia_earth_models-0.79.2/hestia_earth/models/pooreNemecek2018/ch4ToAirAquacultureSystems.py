from hestia_earth.schema import EmissionMethodTier, TermTermType
from hestia_earth.utils.model import find_term_match, filter_list_term_type
from hestia_earth.utils.tools import flatten, list_sum, non_empty_list
from hestia_earth.utils.blank_node import get_node_value

from hestia_earth.models.log import logRequirements, logShouldRun
from hestia_earth.models.utils.blank_node import convert_to_carbon
from hestia_earth.models.utils.emission import _new_emission
from hestia_earth.models.utils.measurement import most_relevant_measurement_value
from hestia_earth.models.utils.aquacultureManagement import valid_site_type
from hestia_earth.models.utils.completeness import _is_term_type_complete
from hestia_earth.models.utils.input import get_feed_inputs
from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "endDate": "",
        "siteArea": "",
        "siteDuration": "",
        "completeness.product": "True",
        "completeness.animalFeed": "True",
        "completeness.fertiliser": "True",
        "products": [
            {
                "@type": "Product",
                "term.termType": "liveAquaticSpecies",
                "properties": [
                    {
                        "@type": "Property",
                        "term.@id": [
                            "carbonContent",
                            "energyContentHigherHeatingValue",
                        ],
                    }
                ],
            }
        ],
        "inputs": [
            {
                "@type": "Input",
                "term.units": "kg",
                "value": "> 0",
                "isAnimalFeed": "True",
            }
        ],
        "site": {
            "@type": "Site",
            "siteType": ["pond", "sea or ocean", "river or stream", "lake"],
            "measurements": [
                {"@type": "Measurement", "term.@id": "netPrimaryProduction"},
                {"@type": "Measurement", "term.@id": "temperatureAnnual"},
                {"@type": "Measurement", "term.@id": "waterDepth"},
            ],
            "optional": {
                "measurements": [
                    {"@type": "Measurement", "term.@id": "salineWater"},
                    {"@type": "Measurement", "term.@id": "fastFlowingWater"},
                ]
            },
        },
        "optional": {
            "otherSitesArea": "",
            "otherSitesDuration": "",
        },
    }
}
RETURNS = {"Emission": [{"value": "", "methodTier": "tier 2"}]}
TERM_ID = "ch4ToAirAquacultureSystems"
TIER = EmissionMethodTier.TIER_2.value

_CONV_AQUACULTURE_CH4CMAX_RATE = 0.50239  # g CH4-C per m2 x day


def _emission(value: float):
    emission = _new_emission(term=TERM_ID, model=MODEL, value=value)
    emission["methodTier"] = TIER
    return emission


def _get_all_blank_nodes(cycle: dict, list_key: str):
    return cycle.get(list_key, []) + flatten(
        [a.get(list_key, []) for a in cycle.get("animals", [])]
    )


def _run(data: list):
    cs, m, m_ch4_c, r, max_ch4_c = data
    value = min(cs * m * m_ch4_c * r, max_ch4_c) * 16 / 12
    return [_emission(value)]


def _should_run(cycle: dict):
    is_product_complete = _is_term_type_complete(cycle, "product")
    is_animalFeed_complete = _is_term_type_complete(cycle, "animalFeed")
    is_fertiliser_complete = _is_term_type_complete(cycle, "fertiliser")

    all_inputs = _get_all_blank_nodes(cycle, "inputs")
    feed_inputs = get_feed_inputs(cycle)

    c_feed = convert_to_carbon(cycle, MODEL, feed_inputs)
    c_fert = convert_to_carbon(
        cycle,
        MODEL,
        filter_list_term_type(all_inputs, TermTermType.ORGANICFERTILISER),
    )
    c_harvest = convert_to_carbon(
        cycle,
        MODEL,
        filter_list_term_type(
            cycle.get("products", []), TermTermType.LIVEAQUATICSPECIES
        ),
    )
    c_resp = c_harvest
    c_excr = c_harvest / 2 if c_harvest is not None else None
    end_date = cycle.get("endDate")

    site = cycle.get("site", {})
    measurements = site.get("measurements", [])
    npp = most_relevant_measurement_value(
        measurements, "netPrimaryProduction", end_date
    )
    temp = most_relevant_measurement_value(measurements, "temperatureAnnual", end_date)
    depth = most_relevant_measurement_value(measurements, "waterDepth", end_date)

    site_areas = non_empty_list(
        [cycle.get("siteArea")] + cycle.get("otherSitesArea", [])
    )
    site_durations = non_empty_list(
        [cycle.get("siteDuration")] + cycle.get("otherSitesDuration", [])
    )

    c_npp = (
        list_sum(
            [
                site_duration * site_area * 10000 * npp / 1000
                for site_area, site_duration in zip(site_areas, site_durations)
            ]
        )
        if all(
            [
                site_areas,
                site_durations,
                len(site_areas) == len(site_durations),
                npp is not None,
            ]
        )
        else None
    )

    max_ch4_c = (
        list_sum(
            [
                site_duration
                * site_area
                * 10000
                * _CONV_AQUACULTURE_CH4CMAX_RATE
                / 1000
                for site_area, site_duration in zip(site_areas, site_durations)
            ]
        )
        if all([site_areas, site_durations, len(site_areas) == len(site_durations)])
        else None
    )

    salineWater = find_term_match(measurements, "salineWater")
    is_saline_water = get_node_value(salineWater) if salineWater else False

    fastFlowingWater = find_term_match(measurements, "fastFlowingWater")
    is_fast_flowing_water = (
        get_node_value(fastFlowingWater) if fastFlowingWater else False
    )

    # S: Sedimentation fraction
    s = 0.55 if is_saline_water else 0.35

    # M: Fraction mineralised
    m = 0.6 if temp is not None and temp >= 23.5 else 0.3
    # MCH4-C: Fraction mineralised carbon which is CH4
    m_ch4_c = (
        0
        if is_fast_flowing_water
        else (
            0.04
            if is_saline_water
            else (0.45 if temp is not None and temp >= 23.5 else 0.2)
        )
    )

    # R: Fraction emitted to air
    r = 0.22 if depth is not None and depth >= 2 else 0.61

    has_feed_inputs = bool(feed_inputs)
    set_to_zero = not valid_site_type(cycle)

    cs = (
        max(c_feed + c_fert + c_npp - c_harvest - c_resp, c_excr) * s
        if all(
            v is not None
            for v in [
                c_feed,
                c_fert,
                c_npp,
                c_harvest,
                c_resp,
                c_excr,
                s,
            ]
        )
        else None
    )

    data = [cs, m, m_ch4_c, r, max_ch4_c]

    should_run = all(
        [
            is_product_complete,
            is_animalFeed_complete,
            is_fertiliser_complete,
            cs is not None,
            has_feed_inputs,
        ]
        + [v is not None for v in data]
    )

    logRequirements(
        cycle,
        model=MODEL,
        term=TERM_ID,
        term_type_product_complete=is_product_complete,
        term_type_animalFeed_complete=is_animalFeed_complete,
        term_type_fertiliser_complete=is_fertiliser_complete,
        c_feed=c_feed,
        c_fert=c_fert,
        c_harvest=c_harvest,
        c_resp=c_resp,
        c_excr=c_excr,
        c_npp=c_npp,
        max_ch4_c=max_ch4_c,
        npp=npp,
        temp=temp,
        depth=depth,
        is_saline_water=is_saline_water,
        is_fast_flowing_water=is_fast_flowing_water,
        m_ch4_c=m_ch4_c,
        s=s,
        m=m,
        r=r,
        has_feed_inputs=has_feed_inputs,
        set_to_zero=set_to_zero,
    )

    logShouldRun(cycle, MODEL, TERM_ID, should_run or set_to_zero, methodTier=TIER)
    return should_run, set_to_zero, data


def run(cycle: dict):
    should_run, set_to_zero, data = _should_run(cycle)
    return [_emission(0)] if set_to_zero else (_run(data) if should_run else [])
