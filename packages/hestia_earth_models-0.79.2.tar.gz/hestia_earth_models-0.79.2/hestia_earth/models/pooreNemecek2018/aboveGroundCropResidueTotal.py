from hestia_earth.schema import TermTermType
from hestia_earth.utils.model import filter_list_term_type
from hestia_earth.utils.tools import safe_parse_float
from hestia_earth.utils.log_utils import log_as_table
from hestia_earth.utils.blank_node import get_node_value

from hestia_earth.models.log import logRequirements, logShouldRun
from hestia_earth.models.utils import weighted_average
from hestia_earth.models.utils.completeness import _is_term_type_incomplete
from hestia_earth.models.utils.product import _new_product
from hestia_earth.models.utils.crop import get_crop_lookup_value
from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "completeness.cropResidue": "False",
        "products": [{"@type": "Product", "term.termType": "crop", "value": "> 0"}],
    }
}
LOOKUPS = {"crop": "Default_ag_dm_crop_residue"}
RETURNS = {"Product": [{"value": ""}]}
TERM_ID = "aboveGroundCropResidueTotal"


def _product(value: float = None):
    return _new_product(term=TERM_ID, model=MODEL, value=value)


def _run(products: list):
    value = weighted_average(
        [(product["lookup-value"], product["value"]) for product in products]
    )
    return [_product(value)]


def _get_lookup_value(product: dict):
    term_id = product.get("term", {}).get("@id", "")
    return safe_parse_float(
        get_crop_lookup_value(MODEL, TERM_ID, term_id, LOOKUPS["crop"]), default=None
    )


def _product_data(product: dict):
    return {
        "id": product.get("term", {}).get("@id"),
        "value": get_node_value(product),
        "lookup-value": _get_lookup_value(product),
    }


def _should_run(cycle: dict):
    term_type_incomplete = _is_term_type_incomplete(cycle, TERM_ID)

    # filter crop products with matching data in the lookup
    products = list(
        map(
            _product_data,
            filter_list_term_type(cycle.get("products", []), TermTermType.CROP),
        )
    )
    valid_products = [p for p in products if p.get("value") > 0]
    has_valid_products = bool(valid_products)
    all_valid_products_with_lookup = all(
        [p.get("lookup-value") is not None for p in valid_products]
    )

    logRequirements(
        cycle,
        model=MODEL,
        term=TERM_ID,
        term_type_cropResidue_incomplete=term_type_incomplete,
        products=log_as_table(products),
        has_valid_products=has_valid_products,
        all_valid_products_with_lookup=all_valid_products_with_lookup,
    )

    should_run = all([has_valid_products, all_valid_products_with_lookup])
    logShouldRun(cycle, MODEL, TERM_ID, should_run)
    return should_run, valid_products


def run(cycle: dict):
    should_run, products = _should_run(cycle)
    return _run(products) if should_run else []
