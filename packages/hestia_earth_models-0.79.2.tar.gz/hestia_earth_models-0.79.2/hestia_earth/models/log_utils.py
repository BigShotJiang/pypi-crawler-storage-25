import os
from functools import reduce
from hestia_earth.schema import NODE_TYPES

_lower_types = [e.lower() for e in NODE_TYPES]
# In-memory accumulator for building a single merged JSON of all logs
_accumulated_logs: dict = {}


def _enabled():
    return os.getenv("LOG_JSON_ENABLED", "false").lower() == "true"


def get_collected_logs() -> dict:
    """Return the accumulated logs as a single deep-merged JSON dict."""
    return _accumulated_logs


def reset_collected_logs():
    """Clear the accumulated logs (call before processing a new node)."""
    global _accumulated_logs
    _accumulated_logs = {}


def _deep_merge(base: dict, update: dict) -> dict:
    return {
        **base,
        **{
            k: (
                _deep_merge(base[k], v)
                if k in base and isinstance(base[k], dict) and isinstance(v, dict)
                else v
            )
            for k, v in update.items()
        },
    }


def _accumulate(log_data: dict):
    if not _enabled():
        return
    global _accumulated_logs
    if log_data:
        _accumulated_logs = _deep_merge(_accumulated_logs, log_data)


def _sanitize_str(value: str):
    if str(value).lower() in ["true", "false"]:
        return str(value).lower() == "true"
    if value in ["None"]:
        return None
    return str(value)


def _sanitize(value):
    return (
        value
        if value is None or isinstance(value, (bool, int, float))
        else (
            list(map(_sanitize, value))
            if isinstance(value, list)
            else (
                {k: _sanitize(v) for k, v in value.items()}
                if isinstance(value, dict)
                else _sanitize_str(value)
            )
        )
    )


def _get_node_id(node: dict) -> dict:
    node_type = node.get("@type", node.get("type"))
    node_id = node.get("@id", node.get("id"))
    if node_id:
        return {} if node_type in NODE_TYPES else {node_type.lower(): node_id}
    return {
        k: v
        for k, v in {
            "term": node.get("term", {}).get("@id"),
            "startDate": node.get("startDate"),
            "endDate": node.get("endDate"),
            "depthUpper": node.get("depthUpper"),
            "depthLower": node.get("depthLower"),
        }.items()
        if v is not None
    }


def _split_model(model: str, term: str):
    """Split "namespace/value" model strings into (model, term).
    Any remaining slashes in the term are replaced with dots for use as a grouping key.
    """
    if not (model and "/" in model):
        return (model, term)
    head, *rest = model.split("/")
    return (head, ".".join(rest))


def _depth_key(node: dict):
    upper = node.get("depthUpper")
    lower = node.get("depthLower")
    return f"{upper}-{lower}" if upper is not None or lower is not None else None


_TERM_KEY_FIELDS = ["key", "property", "animalId", "emission_id", "model_key"]


def _pop_term_key(kwargs: dict, model: str, log_node: dict = {}) -> tuple:
    """Pop grouping fields from kwargs and return (term_key, cleaned_kwargs)."""
    values = {f: kwargs.pop(f, None) for f in _TERM_KEY_FIELDS}
    fallback = next((values[f] for f in _TERM_KEY_FIELDS if values[f]), None)
    term_key = fallback or model or (log_node.get("@type") or "node").lower()
    return term_key, kwargs


def _format_log(log_node: dict, logger_name: str, **kwargs) -> dict:
    model = kwargs.pop("model", None)
    term = kwargs.pop("term", None)

    if term in _lower_types:
        return {}

    is_key = logger_name == "models" and "key" in kwargs
    is_property = logger_name == "models" and "property" in kwargs
    input_group_id = kwargs.get("input_group_id")

    model, term = _split_model(model, term)
    term_key, kwargs = _pop_term_key(kwargs, model, log_node)
    # term takes priority over all other grouping fields
    term_key = term or term_key

    depth = _depth_key(log_node)
    data = (
        _sanitize(kwargs)
        | _get_node_id(log_node)
        | ({"isKey": True} if is_key else {})
        | ({"isProperty": True} if is_property else {})
        | ({"groupId": input_group_id} if input_group_id else {})
    )
    log_content = (
        {model: data}
        if logger_name == "models" and model and term_key != model
        else data
    )
    inner = {logger_name: log_content}
    return {term_key: {depth: inner} if depth else inner} if log_content else {}


def _format_missingLookup_log(
    model: str,
    lookup_name: str,
    row: str,
    row_value: str,
    col: str,
    **kwargs,
):
    if not _enabled():
        return
    term = kwargs.pop("term", None)
    model, term = _split_model(model, term)
    term_key, kwargs = _pop_term_key(kwargs, model)
    # term takes priority over all other grouping fields
    term_key = term or term_key
    node = reduce(
        lambda d, k: d.setdefault(k, {}), [term_key, "models", model], _accumulated_logs
    )

    lookup_entry = _sanitize(
        {
            "lookup": lookup_name,
            "row": row,
            "row_value": row_value,
            "column": col,
            **kwargs,
        }
    )
    node.setdefault("missingLookups", []).append(lookup_entry)
