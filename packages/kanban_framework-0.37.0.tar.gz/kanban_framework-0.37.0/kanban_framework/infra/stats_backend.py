"""Stats backend abstraction — pluggable token/time statistics providers.

Same middleware pattern as knowledge_backend.py:
  Dashboard / CLI commands (unchanged)
        ↓
  StatsBackend (Protocol)
    ├─ NativeBackend  → read Claude Code JSONL directly, zero deps
    └─ CodeBurnBackend → delegate to codeburn CLI for aggregated analytics

Switch via config.json: {"stats": {"backend": "native"}}
"""

from __future__ import annotations
import json
import os
import time
from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class StatsBackend(Protocol):
    """Protocol for token/time statistics backends."""

    def get_stats(self, days: int = 30) -> dict:
        """Return aggregated stats for the last N days.

        Returns:
            {
                "total_tokens": int,
                "total_input": int,
                "total_output": int,
                "total_prompt_calls": int,
                "total_duration_seconds": float,
                "sessions": int,
                "by_model": {model_name: {"tokens": int, "calls": int}},
                "daily": [{"date": "2026-05-22", "tokens": int, "calls": int}],
                "source": "native|codeburn"
            }
        """
        ...


class NativeBackend:
    """Read Claude Code JSONL conversation logs for the current project.

    Scans ~/.claude/projects/<project-hash>/*.jsonl for operation logs
    and augments with global stats-cache.json counters (scoped to project).

    Zero dependencies — data already exists on disk.
    """

    def __init__(self, project_root: Path):
        self._root = Path(project_root).resolve()
        self._claude_dir = Path.home() / ".claude"

    def get_stats(self, days: int = 30) -> dict:
        cutoff = time.time() - days * 86400

        stats: dict = {
            "total_tokens": 0, "total_input": 0, "total_output": 0,
            "total_prompt_calls": 0, "total_duration_seconds": 0.0,
            "sessions": 0, "by_model": {}, "daily": {},
            "source": "native",
        }

        # ── Scan THIS project's JSONL session files ──
        project_jsonl = self._find_project_jsonl_files()
        seen_sessions = set()

        for jf in project_jsonl:
            try:
                for line in jf.read_text(encoding="utf-8", errors="replace").strip().split("\n"):
                    if not line.strip():
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    ts = entry.get("timestamp", "")
                    try:
                        if isinstance(ts, (int, float)):
                            t = float(ts)
                        else:
                            from datetime import datetime
                            t = datetime.fromisoformat(str(ts).replace("Z", "+00:00")).timestamp()
                    except (ValueError, TypeError):
                        continue

                    if t < cutoff:
                        continue

                    sid = entry.get("sessionId", "")
                    if sid:
                        seen_sessions.add(sid)

                    stats["total_prompt_calls"] += 1

                    # Collect daily counts
                    from datetime import datetime
                    date_key = datetime.fromtimestamp(t).strftime("%Y-%m-%d")
                    dd = stats["daily"].setdefault(date_key, {"tokens": 0, "calls": 0})
                    dd["calls"] += 1

            except Exception:
                pass

        stats["sessions"] = len(seen_sessions)

        # ── Augment with global stats-cache.json (model/token totals) ──
        # The cache aggregates all projects, but model distribution is useful
        cache_file = self._claude_dir / "stats-cache.json"
        if cache_file.is_file():
            try:
                cache = json.loads(cache_file.read_text(encoding="utf-8"))
                model_usage = cache.get("modelUsage", {})
                if isinstance(model_usage, str):
                    model_usage = json.loads(model_usage)
                for model, mu in model_usage.items():
                    stats["by_model"][model] = {
                        "tokens": mu.get("inputTokens", 0) + mu.get("outputTokens", 0),
                        "calls": mu.get("messageCount", 0),
                    }
            except Exception:
                pass

        stats["daily"] = sorted(
            [{"date": k, **v} for k, v in stats["daily"].items()],
            key=lambda x: x["date"], reverse=True
        )[:days]

        return stats

    def _find_project_jsonl_files(self) -> list[Path]:
        """Find JSONL session files for this specific project.

        Claude Code organizes sessions under:
          ~/.claude/projects/<project-name-hash>/<uuid>.jsonl

        We match the project by resolving the project root path and looking
        for a matching directory name pattern.
        """
        files: list[Path] = []
        projects_dir = self._claude_dir / "projects"
        if not projects_dir.is_dir():
            return files

        # Match: project root name appears in the project dir name
        # e.g., "-Users-ks-128-Documents-important-demo"
        # Claude Code replaces underscores with hyphens in directory names
        root_name = str(self._root).replace("/", "-").replace("_", "-")
        if root_name.startswith("-"):
            root_name = root_name[1:]  # strip leading dash

        best_dir = None
        for proj_dir in projects_dir.iterdir():
            if not proj_dir.is_dir():
                continue
            dir_name = proj_dir.name
            # Match: project dir name contains the project path
            if root_name in dir_name or dir_name in root_name:
                if best_dir is None or len(list(proj_dir.glob("*.jsonl"))) > len(list(best_dir.glob("*.jsonl"))):
                    best_dir = proj_dir

        if best_dir is not None:
            for jf in sorted(best_dir.glob("*.jsonl")):
                if "subagents" not in str(jf):
                    files.append(jf)

        return files


class CodeBurnBackend:
    """Delegate to codeburn CLI for aggregated analytics.

    Requires: codeburn (brew install codeburn or pip install codeburn)
    Falls back to NativeBackend if codeburn is not installed.
    """

    def __init__(self, project_root: Path):
        self._root = Path(project_root)
        self._native = NativeBackend(project_root)

    def get_stats(self, days: int = 30) -> dict:
        import subprocess
        try:
            result = subprocess.run(
                ["codeburn", "report", "-p", str(days), "--format", "json"],
                capture_output=True, text=True, timeout=15,
                cwd=str(self._root),
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                overview = data.get("overview", {})
                return {
                    "total_tokens": overview.get("totalTokens", 0),
                    "total_input": overview.get("inputTokens", 0),
                    "total_output": overview.get("outputTokens", 0),
                    "total_prompt_calls": overview.get("totalCalls", 0),
                    "total_duration_seconds": overview.get("totalDuration", 0),
                    "sessions": overview.get("sessions", 0),
                    "by_model": data.get("models", {}),
                    "daily": data.get("daily", []),
                    "source": "codeburn",
                    "raw": data,
                }
        except Exception:
            pass
        # Fallback to native
        return self._native.get_stats(days)


# Registry
STATS_BACKEND_REGISTRY = {
    "native": NativeBackend,
    "codeburn": CodeBurnBackend,
}


def resolve_stats_backend(name: str, project_root: Path) -> StatsBackend:
    """Resolve a stats backend by name. Falls back to native."""
    cls = STATS_BACKEND_REGISTRY.get(name)
    if cls is None:
        import warnings
        warnings.warn(f"Unknown stats backend '{name}', falling back to native")
        cls = NativeBackend
    return cls(project_root)
