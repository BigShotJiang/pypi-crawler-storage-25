"""LLM client — talks to Ollama via PastaWater broker or directly to a brain."""

import json
import requests
from typing import Iterator


DEFAULT_API_URL = "https://pastawater.io"


class LLMClient:
    """Client that talks to Ollama via PastaWater broker API or direct brain connection."""

    def __init__(
        self,
        token: str = "",
        device_id: str = "",
        slot: int = 0,
        model: str = "",
        api_url: str = DEFAULT_API_URL,
        brain_url: str = "",
        brain_key: str = "",
    ):
        self.token = token
        self.device_id = device_id
        self.slot = slot
        self.model = model
        self.api_url = api_url.rstrip("/")
        self.brain_url = brain_url.rstrip("/") if brain_url else ""
        self.brain_key = brain_key
        self.direct_mode = bool(brain_url)

        self.session = requests.Session()
        self.session.headers["Content-Type"] = "application/json"
        # Auth: PW token works for both cloud API and local brain proxy
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"
        if brain_key:
            self.session.headers["X-Controller-API-Key"] = brain_key

    def chat(self, messages: list[dict], temperature: float = 0.3, context_length: int = 8192) -> str:
        """Send messages and return the full response text."""
        chunks = []
        for chunk in self.chat_stream(messages, temperature, context_length):
            chunks.append(chunk)
        return "".join(chunks)

    def chat_stream(self, messages: list[dict], temperature: float = 0.3, context_length: int = 8192) -> Iterator[str]:
        """Stream chat tokens from Ollama."""
        if self.direct_mode:
            yield from self._stream_direct(messages, temperature, context_length)
        else:
            yield from self._stream_broker(messages, temperature, context_length)

    def _stream_direct(self, messages: list[dict], temperature: float, context_length: int) -> Iterator[str]:
        """Stream directly from brain's Ollama endpoint."""
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            "options": {
                "temperature": temperature,
                "num_ctx": context_length,
            },
        }

        try:
            resp = self.session.post(
                f"{self.brain_url}/api/chat",
                json=payload,
                stream=True,
                timeout=300,
            )
        except requests.exceptions.ConnectionError:
            yield f"[Error: Could not connect to brain at {self.brain_url}]"
            return
        except requests.exceptions.Timeout:
            yield "[Error: Request timed out]"
            return

        if resp.status_code != 200:
            yield f"[Error: Brain returned {resp.status_code}]"
            return

        for line in resp.iter_lines():
            if not line:
                continue
            try:
                data = json.loads(line)
                content = data.get("message", {}).get("content", "")
                if content:
                    yield content
                if data.get("done"):
                    return
            except json.JSONDecodeError:
                continue

    def _flatten_messages(self, messages: list[dict]) -> str:
        """Flatten chat messages into a single prompt string for the llm model."""
        parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                parts.append(f"<|system|>\n{content}")
            elif role == "assistant":
                parts.append(f"<|assistant|>\n{content}")
            else:
                parts.append(f"<|user|>\n{content}")
        parts.append("<|assistant|>")
        return "\n".join(parts)

    def _stream_broker(self, messages: list[dict], temperature: float, context_length: int) -> Iterator[str]:
        """Stream via PastaWater broker API."""
        # Send structured messages so the brain can use /api/chat with native templates
        payload = {
            "model": "llm",
            "slot": self.slot,
            "prompt": messages[-1].get("content", "") if messages else "",  # Required field
            "messages": messages,  # Brain uses this for /api/chat
            "llm_model": self.model,
            "temperature": temperature,
            "max_tokens": min(context_length, 4096),
        }

        # Retry on 504 (Cloudflare timeout) — slow GPUs may need multiple attempts
        max_retries = 3
        resp = None
        for attempt in range(max_retries):
            try:
                resp = self.session.post(
                    f"{self.api_url}/api/v1/playground/generate",
                    json=payload,
                    timeout=300,
                )
                if resp.status_code != 504:
                    break
                if attempt < max_retries - 1:
                    import sys
                    sys.stderr.write(f"\r  \033[33mRetrying ({attempt + 2}/{max_retries})...\033[0m")
                    sys.stderr.flush()
            except requests.exceptions.Timeout:
                yield "[Error: Request timed out]"
                return
            except requests.exceptions.ConnectionError:
                yield f"[Error: Could not connect to {self.api_url}]"
                return

        if resp is None:
            yield "[Error: No response from server]"
            return
        if resp.status_code == 401:
            yield "[Error: Invalid API token]"
            return
        if resp.status_code == 403:
            yield "[Error: Access denied]"
            return
        if resp.status_code != 200:
            yield f"[Error: API returned {resp.status_code}: {resp.text[:200]}]"
            return

        try:
            data = resp.json()
        except json.JSONDecodeError:
            yield "[Error: Invalid JSON response]"
            return

        if not data.get("success"):
            yield f"[Error: {data.get('error', 'Unknown error')}]"
            return

        result = data.get("result", {})
        text = result.get("text", "") or result.get("response", "") or ""
        yield text

    def list_devices(self) -> list:
        """List online GPU devices with running LLM."""
        if self.direct_mode:
            return [{"slot": 0, "device_id": "local", "device_name": "local", "gpu": "direct", "llm_model": self.model}]

        try:
            resp = self.session.get(f"{self.api_url}/api/user/byog/slots", timeout=15)
            if resp.status_code != 200:
                return []
            data = resp.json()
            if not data.get("success"):
                return []

            devices = []
            for s in data.get("slots", []):
                if not s.get("online"):
                    continue
                running = s.get("running_services", [])
                if "llm" in running:
                    devices.append({
                        "slot": s.get("slot_number"),
                        "device_id": s.get("device_id", ""),
                        "device_name": s.get("device_name", "Unknown"),
                        "gpu": s.get("gpu_info", {}).get("name", "Unknown"),
                        "vram_gb": round(s.get("gpu_info", {}).get("memory_total_mb", 0) / 1024, 1),
                        "llm_model": s.get("llm_current_model") or "ollama",
                    })
            return devices
        except Exception:
            return []

    def test_connection(self) -> tuple[bool, str]:
        """Test connectivity and return (ok, message)."""
        if self.direct_mode:
            try:
                resp = self.session.get(f"{self.brain_url}/api/tags", timeout=10)
                if resp.status_code != 200:
                    return False, f"Brain returned {resp.status_code}"
                data = resp.json()
                models = [m["name"] for m in data.get("models", [])]
                if self.model and self.model not in models:
                    available = ", ".join(models[:5]) or "none"
                    return False, f"Model '{self.model}' not found. Available: {available}"
                return True, f"Connected to brain at {self.brain_url} ({self.model})"
            except requests.exceptions.ConnectionError:
                return False, f"Could not connect to {self.brain_url}"
            except Exception as e:
                return False, str(e)

        # Cloud mode — find our slot
        try:
            resp = self.session.get(f"{self.api_url}/api/user/byog/slots", timeout=15)
            if resp.status_code == 401:
                return False, "Invalid API token"
            if resp.status_code != 200:
                return False, f"API error: {resp.status_code}"

            data = resp.json()
            if not data.get("success"):
                return False, data.get("error", "API error")

            for s in data.get("slots", []):
                if s.get("slot_number") == self.slot:
                    if not s.get("online"):
                        return False, f"Slot {self.slot} is offline"
                    if "llm" not in s.get("running_services", []):
                        return False, f"Slot {self.slot} has no LLM running"
                    gpu = s.get("gpu_info", {}).get("name", "unknown")
                    model = s.get("llm_current_model") or self.model or "ollama"
                    return True, f"Connected to {model} on {gpu} (slot {self.slot})"

            return False, f"Slot {self.slot} not found"
        except requests.exceptions.ConnectionError:
            return False, f"Could not connect to {self.api_url}"
        except Exception as e:
            return False, str(e)
