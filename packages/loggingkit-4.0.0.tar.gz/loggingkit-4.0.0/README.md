# LoggingKit

A simple Python logging utility

## Installation

```bash
pip install loggingkit
```

## Importing

```python
import loggingkit
```

## Usage

Just as an example, we will use this code:

```python
log1 = loggingkit.Logger()
```

### create\_log()

The function create\_log() takes one argument: the name of the log. It creates a new log

```python
log1.log("test")
```

### warning()

The function warning() takes one argument and one \* argument: the name of the log you want the warning in and the warning, which is the \* argument. It creates the specified warning in the specified log.

```python
log1.warning("test",  "This is a warning", "line 21")
```

### info()

The function info() takes one argument and one \* argument: the name of the log you want the info in and the info, which is the \* argument. It creates the specified info in the specified log.

```python
log1.info("test", "This is an info", "line 21")
```

### error()

The function error() takes one argument and one \* argument: the name of the log you want the error in and the error, which is the \* argument. It creates the specified error in the specified log.

```python
log1.error("test", "This is an error", "Line 21")
```
### plain()

The function plain() takes one argument and one \* argument: the name of the log you want the note in and the note, which is the \* argument. It creates the specified plain note in the specified log with no W, I or E  tags.

```python
log1.plain("test", "This is a note", "Line 21")
```

### clear()

The function clear() takes one argument: the name of the log you want to clear. It deletes all entries of the specified log.

```python
log1.clear("test")
```

### return\_log()

```python
log1.return_log("test")
```

### save\_log()

The function save\_log() takes one argument which has a default, log.json: the name of the file you want to export the  logs into. (With the extension!) It exports the set of logs into the specified filename.

```python
log1.save_log() #The default will be used here
```

### open\_log()

The function open\_log() takes one argument, which has a default, log.json: The name of the file you want to import the logs from. (Also with the extension!) It imports the logs from the specified filename.

```python
log1.open_log() #The default will be used here as well
```

