import time
import json
class Logger:
    def __init__(self):
        self.logs = dict()
    def _ensure_log(self, log_name):
        if log_name not in self.logs:
            self.logs[log_name] = []
    def create_log(self, name):
        self.logs[name] = []
    def warning(self, log_name, *description):
        self._ensure_log(log_name)
        self.logs[log_name].append(("W", time.strftime("%H:%M:%S"), *description))
    def info(self, log_name, *description):
        self._ensure_log(log_name)
        self.logs[log_name].append(("I", time.strftime("%H:%M:%S"), *description))
    def error(self, log_name, *description):
        self._ensure_log(log_name)
        self.logs[log_name].append(("E", time.strftime("%H:%M:%S"),  *description))
    def plain(self, log_name, *description):
        self._ensure_log(log_name)
        self.logs[log_name].append((time.strftime("%H:%M:%S"),  *description))
    def clear(self, log_name):
        self.logs[log_name].clear()
    def return_log(self, log_name):
        self._ensure_log(log_name)
        return self.logs[log_name]
    def save_log(self, filename="log.json"):
        with open(filename, "w") as f:
            json.dump(self.logs, f, indent=2)
    def open_log(self, filename="log.json"):
        with open(filename) as f:
            self.logs = json.load(f)
    def __repr__(self):
        return f"<Logger logs: {len(self.logs)}>"
