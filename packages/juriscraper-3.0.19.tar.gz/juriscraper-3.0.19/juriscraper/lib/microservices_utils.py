import os
from urllib.parse import urljoin

import httpx
from httpx import AsyncClient, Response, TimeoutException
from lxml import html

from juriscraper.lib.log_tools import make_default_logger

MICROSERVICE_URLS = {
    "document-extract": "{}/extract/doc/text/",
    "buffer-extension": "{}/utils/file/extension/",
}

logger = make_default_logger()


async def test_for_meta_redirections(
    r: Response,
) -> tuple[bool, str | None]:
    """Test for meta data redirections

    :param r: A response object
    :return:  A boolean and value
    """
    try:
        extension = await get_extension(r.content)
    except TimeoutException as e:
        # Transient network issues - don't send to Sentry
        logger.warning(
            "Timeout error getting extension from microservice: %s",
            e,
        )
        extension = ""
    except Exception:
        # blanket exception until we get more error information
        logger.error("Error getting extension on juriscraper", exc_info=True)
        extension = ""

    if extension != ".html":
        return False, None

    html_tree = html.fromstring(r.text)

    path = (
        "//meta[translate(@http-equiv, 'REFSH', 'refsh') = 'refresh']/@content"
    )
    try:
        attr = html_tree.xpath(path)[0]
        wait, text = attr.split(";")
        if text.lower().startswith("url="):
            url = text[4:]
            if not url.startswith("http"):
                # Relative URL, adapt
                url = urljoin(r.url, url)
            return True, url
    except IndexError:
        return False, None

    return False, None


async def follow_redirections(r: Response, s: AsyncClient) -> Response:
    """
    Parse and recursively follow meta refresh redirections if they exist until
    there are no more.
    """
    redirected, url = await test_for_meta_redirections(r)
    if redirected:
        logger.info(f"Following a meta redirection to: {url.encode()}")
        r = await follow_redirections(await s.get(url), s)
    return r


async def get_extension(content: bytes) -> str:
    """
    Get the extension of a file using a microservice.

    :param r: The item to get the extension for
    :return extension: The extension of the file, e.g. ".pdf", ".html", etc.
    """
    # Get the file type from the document's raw content
    doctor_host = os.environ.get("DOCTOR_HOST", "http://cl-doctor:5050")
    extension_url = MICROSERVICE_URLS["buffer-extension"].format(doctor_host)
    async with httpx.AsyncClient() as client:
        extension_response = await client.post(
            extension_url, files={"file": ("filename", content)}, timeout=30
        )
    extension_response.raise_for_status()
    extension = extension_response.text

    return extension
