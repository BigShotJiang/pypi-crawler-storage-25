import{n as e,t}from"./rolldown-runtime-DF2fYuay.js";import{a as n,c as r,i,l as a,n as o,o as s,r as c,s as l,t as u,u as d}from"./lit-CNFZiXEs.js";import{a as f,i as p,n as m,r as h,t as g}from"./markdown-CV8Hi911.js";import{a as _,c as v,d as y,f as b,i as x,l as S,n as C,o as w,p as T,r as E,s as D,t as ee,u as te}from"./hljs-v0CKncSw.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var ne={"--radius-xs":`var(--rh-border-radius-default, 3px)`,"--radius-sm":`8px`,"--radius-md":`12px`,"--radius-lg":`16px`,"--radius-xl":`24px`,"--radius-full":`var(--rh-border-radius-pill, 64px)`,"--sidebar-width":`280px`,"--topbar-height":`48px`,"--chat-max-width":`768px`,"--detail-pane-width":`340px`,"--detail-pane-min-width":`200px`,"--chat-area-min-width":`320px`,"--transition-fast":`150ms ease`,"--transition-normal":`250ms ease`,"--font-size-xs":`var(--rh-font-size-body-text-xs, 0.75rem)`,"--font-size-sm":`var(--rh-font-size-body-text-sm, 0.875rem)`,"--font-size-base":`var(--rh-font-size-body-text-md, 1rem)`,"--font-size-lg":`var(--rh-font-size-body-text-lg, 1.125rem)`,"--font-size-xl":`var(--rh-font-size-body-text-2xl, 1.5rem)`,"--font-weight-normal":`var(--rh-font-weight-body-text-regular, 400)`,"--font-weight-medium":`var(--rh-font-weight-body-text-medium, 500)`,"--font-weight-bold":`var(--rh-font-weight-heading-bold, 700)`,"--line-height":`var(--rh-line-height-body-text, 1.5)`},re={...ne,"--bg-primary":`#F8F6FB`,"--bg-secondary":`#F0ECF5`,"--bg-tertiary":`#E4DEF0`,"--bg-user-bubble":`#DCE8DC`,"--bg-assistant":`transparent`,"--bg-sidebar":`#F2F5F2`,"--bg-input":`#FFFFFF`,"--bg-code":`#F3EEF8`,"--bg-hover":`rgba(90, 70, 140, 0.06)`,"--bg-tool":`#F0ECF5`,"--bg-tool-header":`#E4DEF0`,"--text-primary":`#2D2B3D`,"--text-secondary":`#6B6880`,"--text-tertiary":`#9895AA`,"--text-inverse":`#FFFFFF`,"--text-code":`#7C5CBF`,"--border-primary":`rgba(80, 60, 120, 0.15)`,"--border-secondary":`rgba(80, 60, 120, 0.08)`,"--accent-primary":`#5B9EA6`,"--accent-hover":`#4A8A93`,"--accent-success":`#6B9F6B`,"--accent-danger":`#C27070`,"--accent-warning":`#C4966E`,"--accent-info":`#7B9EC9`,"--hat-color":`#E06060`,"--font-sans":`'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`,"--font-mono":`'SF Mono', 'Fira Code', 'Fira Mono', 'Roboto Mono', monospace`,"--shadow-sm":`0 1px 2px rgba(60, 40, 100, 0.06)`,"--shadow-md":`0 2px 8px rgba(60, 40, 100, 0.10)`,"--shadow-lg":`0 4px 16px rgba(60, 40, 100, 0.14)`},ie={...ne,"--bg-primary":`#1E1B2E`,"--bg-secondary":`#262340`,"--bg-tertiary":`#352F54`,"--bg-user-bubble":`#3A3458`,"--bg-assistant":`transparent`,"--bg-sidebar":`#151324`,"--bg-input":`#262340`,"--bg-code":`#262340`,"--bg-hover":`rgba(180, 160, 255, 0.08)`,"--bg-tool":`#1C1930`,"--bg-tool-header":`#2E2A48`,"--text-primary":`#E8E4F0`,"--text-secondary":`#ACA8C0`,"--text-tertiary":`#7E7A96`,"--text-inverse":`#1E1B2E`,"--text-code":`#E8A8C0`,"--border-primary":`rgba(200, 180, 255, 0.15)`,"--border-secondary":`rgba(200, 180, 255, 0.08)`,"--accent-primary":`#A78BFA`,"--accent-hover":`#B89FF8`,"--accent-success":`#86D9A8`,"--accent-danger":`#F08080`,"--accent-warning":`#E8C06A`,"--accent-info":`#88B8E8`,"--hat-color":`#F07888`,"--font-sans":`'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`,"--font-mono":`'SF Mono', 'Fira Code', 'Fira Mono', 'Roboto Mono', monospace`,"--shadow-sm":`0 1px 2px rgba(10, 8, 30, 0.3)`,"--shadow-md":`0 2px 8px rgba(10, 8, 30, 0.4)`,"--shadow-lg":`0 4px 16px rgba(10, 8, 30, 0.5)`},ae={...ne,"--bg-primary":`#e6e6e6`,"--bg-secondary":`#f5f5f5`,"--bg-tertiary":`var(--rh-color-surface-light, #e0e0e0)`,"--bg-user-bubble":`var(--rh-color-gray-20, #e0e0e0)`,"--bg-assistant":`transparent`,"--bg-sidebar":`var(--rh-color-gray-10, #f5f5f5)`,"--bg-input":`var(--rh-color-surface-lightest, #ffffff)`,"--bg-code":`var(--rh-color-surface-lighter, #f2f2f2)`,"--bg-hover":`var(--rh-color-surface-lighter, rgba(21, 21, 21, 0.04))`,"--bg-tool":`var(--rh-color-gray-10, #f2f2f2)`,"--bg-tool-header":`var(--rh-color-gray-20, #e0e0e0)`,"--text-primary":`var(--rh-color-text-primary-on-light, #151515)`,"--text-secondary":`var(--rh-color-text-secondary-on-light, #4d4d4d)`,"--text-tertiary":`var(--rh-color-gray-50, #707070)`,"--text-inverse":`var(--rh-color-text-primary-on-dark, #ffffff)`,"--text-code":`var(--rh-color-blue-70, #003366)`,"--border-primary":`var(--rh-color-border-subtle-on-light, #c7c7c7)`,"--border-secondary":`var(--rh-color-border-subtle-on-light, rgba(21, 21, 21, 0.10))`,"--accent-primary":`var(--rh-color-interactive-blue-darker, #0066cc)`,"--accent-hover":`var(--rh-color-interactive-blue-darkest, #003366)`,"--accent-success":`var(--rh-color-status-success-on-light, #3d7317)`,"--accent-danger":`var(--rh-color-status-danger-on-light, #b1380b)`,"--accent-warning":`var(--rh-color-status-warning-on-light, #dca614)`,"--accent-info":`var(--rh-color-interactive-blue-darker, #0066cc)`,"--hat-color":`var(--rh-color-brand-red-on-light, #ee0000)`,"--font-sans":`var(--rh-font-family-body-text, 'Red Hat Text', 'Red Hat Display', sans-serif)`,"--font-mono":`var(--rh-font-family-code, 'Red Hat Mono', 'Courier New', monospace)`,"--shadow-sm":`var(--rh-box-shadow-sm, 0 1px 2px rgba(21, 21, 21, 0.1))`,"--shadow-md":`var(--rh-box-shadow-md, 0 2px 4px rgba(21, 21, 21, 0.12))`,"--shadow-lg":`var(--rh-box-shadow-lg, 0 4px 8px rgba(21, 21, 21, 0.15))`},oe={...ne,"--bg-primary":`#252525`,"--bg-secondary":`#2a2a2a`,"--bg-tertiary":`var(--rh-color-gray-60, #4d4d4d)`,"--bg-user-bubble":`var(--rh-color-gray-70, #3d3d3d)`,"--bg-assistant":`transparent`,"--bg-sidebar":`var(--rh-color-surface-darkest, #151515)`,"--bg-input":`#2a2a2a`,"--bg-code":`var(--rh-color-gray-70, #333333)`,"--bg-hover":`var(--rh-color-surface-darker, rgba(255, 255, 255, 0.06))`,"--bg-tool":`var(--rh-color-surface-darker, #1f1f1f)`,"--bg-tool-header":`var(--rh-color-surface-dark, #383838)`,"--text-primary":`var(--rh-color-text-primary-on-dark, #ffffff)`,"--text-secondary":`var(--rh-color-text-secondary-on-dark, #c7c7c7)`,"--text-tertiary":`#a0a0a0`,"--text-inverse":`var(--rh-color-text-primary-on-light, #151515)`,"--text-code":`var(--rh-color-red-orange-30, #f89b78)`,"--border-primary":`var(--rh-color-border-subtle-on-dark, #707070)`,"--border-secondary":`var(--rh-color-border-subtle-on-dark, rgba(242, 242, 242, 0.08))`,"--accent-primary":`var(--rh-color-interactive-blue-lighter, #92c5f9)`,"--accent-hover":`var(--rh-color-interactive-blue-lightest, #b9dafc)`,"--accent-success":`var(--rh-color-status-success-on-dark, #87bb62)`,"--accent-danger":`var(--rh-color-status-danger-on-dark, #f0561d)`,"--accent-warning":`var(--rh-color-status-warning-on-dark, #ffcc17)`,"--accent-info":`var(--rh-color-interactive-blue-lighter, #92c5f9)`,"--hat-color":`var(--rh-color-brand-red-on-dark, #ee0000)`,"--font-sans":`var(--rh-font-family-body-text, 'Red Hat Text', 'Red Hat Display', sans-serif)`,"--font-mono":`var(--rh-font-family-code, 'Red Hat Mono', 'Courier New', monospace)`,"--shadow-sm":`var(--rh-box-shadow-sm, 0 1px 2px rgba(21, 21, 21, 0.15))`,"--shadow-md":`var(--rh-box-shadow-md, 0 2px 4px rgba(21, 21, 21, 0.18))`,"--shadow-lg":`var(--rh-box-shadow-lg, 0 4px 8px rgba(21, 21, 21, 0.22))`},se=[{id:`light`,label:`Light`,theme:re,dark:!1},{id:`dark`,label:`Dark`,theme:ie,dark:!0},{id:`rh-light`,label:`Red Hat Light`,theme:ae,dark:!1},{id:`rh-dark`,label:`Red Hat Dark`,theme:oe,dark:!0}],ce=new Map(se.map(e=>[e.id,e])),le=`agent-theme`,ue=new class{constructor(){this.themeName=this.loadPreference();let e=ce.get(this.themeName);this.current=e?e.theme:re,this.apply()}get name(){return this.themeName}get isDark(){let e=ce.get(this.themeName);return e?e.dark:!1}get themes(){return se}toggle(){let e=se.map(e=>e.id),t=e[(e.indexOf(this.themeName)+1)%e.length];this.setTheme(t)}setTheme(e,t){this.themeName=e;let n=ce.get(e),r=n?n.theme:re;this.current=t?Object.assign({},r,t):r,this.apply(),this.savePreference()}apply(){let e=document.documentElement;for(let[t,n]of Object.entries(this.current))e.style.setProperty(t,n)}loadPreference(){try{let e=localStorage.getItem(le);if(e&&ce.has(e))return e}catch{}return window.matchMedia?.(`(prefers-color-scheme: dark)`).matches?`dark`:`light`}savePreference(){try{localStorage.setItem(le,this.themeName)}catch{}}},de=[{name:`set_context`,description:`Set or update a context key-value pair for the conversation`},{name:`select_skill`,description:`Load a reference guide (skill) for the current conversation`}],O=new class{constructor(){this.data={sessionId:null,activeChatId:null,chatList:[],messages:[],isStreaming:!1,usage:null,model:``,mcpServers:[],toolCount:0,contextWindow:0,maxActiveSkills:3,availableSkills:[],activeSkills:[],context:{},availableModels:[],availablePlaybooks:[],availableTools:[],toolPolicies:{},pinCards:[],sidebarOpen:!0,detailPaneOpen:!0,detailPaneWidth:340,error:null,warning:null,streamStartTime:null,streamElapsed:null},this.listeners=new Set}get state(){return this.data}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}notify(){for(let e of this.listeners)e()}update(e){Object.assign(this.data,e),this.notify()}addMessage(e){this.data.messages=[...this.data.messages,e],this.notify()}updateLastAssistant(e){let t=[...this.data.messages];for(let n=t.length-1;n>=0;n--)if(t[n].role===`assistant`){t[n]=e(t[n]);break}this.data.messages=t,this.notify()}addToolCallToLast(e){this.updateLastAssistant(t=>({...t,toolCalls:[...t.toolCalls??[],e]}))}updateLastToolCall(e){this.updateLastAssistant(t=>{let n=[...t.toolCalls??[]];return n.length>0&&(n[n.length-1]=e(n[n.length-1])),{...t,toolCalls:n}})}clearMessages(){this.data.messages=[],this.data.sessionId=null,this.data.activeChatId=null,this.data.isStreaming=!1,this.data.usage=null,this.data.error=null,this.data.streamStartTime=null,this.data.streamElapsed=null,this.notify()}setChatList(e){this.data.chatList=e,this.notify()}setActiveChat(e,t,n){this.data.activeChatId=e,this.data.sessionId=t,this.data.messages=n,this.data.isStreaming=!1,this.data.usage=null,this.data.error=null,this.data.streamStartTime=null,this.data.streamElapsed=null,this.notify()}removeChat(e){this.data.chatList=this.data.chatList.filter(t=>t.id!==e),this.data.activeChatId===e&&this.clearMessages(),this.notify()}setContext(e,t){this.data.context={...this.data.context,[e]:t},this.notify()}removeContext(e){let t={...this.data.context};delete t[e],this.data.context=t,this.notify()}clearContext(){this.data.context={},this.notify()}toggleSkill(e){let t=[...this.data.activeSkills],n=t.indexOf(e);n>=0?t.splice(n,1):(t.push(e),t.length>this.data.maxActiveSkills&&t.shift()),this.data.activeSkills=t,this.notify()}setActiveSkills(e){this.data.activeSkills=e,this.notify()}needsApproval(){let e=Object.values(this.data.toolPolicies);return e.length===0?!0:e.some(e=>e!==`auto-accept`)}setToolPolicy(e,t){this.data.toolPolicies={...this.data.toolPolicies,[e]:t},this.notify()}setAllToolPolicies(e){let t={};for(let n of this.data.availableTools)t[n.name]=e;this.data.toolPolicies=t,this.notify()}hasCard(e){return this.data.pinCards.some(t=>t.id===e)}addCard(e){this.hasCard(e.id)||(this.data.pinCards=[...this.data.pinCards,e],this.notify())}removeCard(e){this.data.pinCards=this.data.pinCards.filter(t=>t.id!==e),this.notify()}moveCard(e,t){let n=[...this.data.pinCards],r=n.findIndex(t=>t.id===e);if(r<0||r===t)return;let[i]=n.splice(r,1);n.splice(t,0,i),this.data.pinCards=n,this.notify()}updateCardContent(e,t){this.data.pinCards=this.data.pinCards.map(n=>n.id===e?{...n,content:t,timestamp:Date.now()}:n),this.notify()}updateCard(e,t){this.data.pinCards=this.data.pinCards.map(n=>n.id===e?{...n,...t}:n),this.notify()}updateCardHeight(e,t){this.data.pinCards=this.data.pinCards.map(n=>n.id===e?{...n,height:t}:n),this.notify()}genId(){return`${Date.now()}-${Math.random().toString(36).slice(2,8)}`}};function fe(e){return e===`set_context`||e===`select_skill`||e.endsWith(`_read`)||e.endsWith(`_help`)?`auto-accept`:`ask`}var pe=`/api`;async function k(e,t){let n=await fetch(`${pe}${e}`,{headers:{"Content-Type":`application/json`},...t});if(!n.ok)throw Error(`API ${n.status}: ${n.statusText}`);return n.json()}async function me(){return k(`/status`)}async function A(){return(await k(`/models`)).models}async function j(e){return k(`/model`,{method:`PUT`,body:JSON.stringify({model:e})})}async function he(){return(await k(`/tools`)).tools}async function ge(){return(await k(`/skills`)).skills}async function _e(){return(await k(`/playbooks`)).playbooks}async function ve(){return(await k(`/mcp`)).servers}async function ye(e){return k(`/mcp/${encodeURIComponent(e)}`,{method:`POST`})}async function be(e){return k(`/mcp/${encodeURIComponent(e)}`,{method:`DELETE`})}async function xe(){return(await k(`/chats`)).chats}async function Se(e){return k(`/chats/${encodeURIComponent(e)}`)}async function Ce(e){await k(`/chats/${encodeURIComponent(e)}`,{method:`DELETE`})}async function we(e,t={}){return k(`/tools/${encodeURIComponent(e)}`,{method:`POST`,body:JSON.stringify({arguments:t})})}async function M(e,t,n){let r={approved:t};n&&(r.reason=n),await k(`/chat/${e}/approve`,{method:`POST`,body:JSON.stringify(r)})}async function Te(e){await k(`/chat/${e}/cancel`,{method:`POST`})}function Ee(e){let t=`${pe}/chat/${e}/cancel`;navigator.sendBeacon(t)}var De=`/api`;async function Oe(e,t,n){let r=`${De}/chat/stream${n?.approve?`?approve=true`:``}`,i;try{i=await fetch(r,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(e),signal:n?.signal})}catch(e){t.onError?.(e instanceof Error?e:Error(String(e)));return}if(!i.ok){t.onError?.(Error(`Stream ${i.status}: ${i.statusText}`));return}let a=i.body?.getReader();if(!a){t.onError?.(Error(`No response body`));return}let o=new TextDecoder,s=``,c=``;try{for(;;){let{done:e,value:n}=await a.read();if(e)break;s+=o.decode(n,{stream:!0});let r=s.split(`
`);s=r.pop()??``;for(let e of r)if(e.startsWith(`event:`))c=e.slice(6).trim();else if(e.startsWith(`data:`)){let n=e.slice(5).trim();if(!n)continue;let r;try{r=JSON.parse(n)}catch{continue}ke(c,r,t),c=``}}}catch(e){e.name!==`AbortError`&&t.onError?.(e instanceof Error?e:Error(String(e)))}}function ke(e,t,n){switch(e){case`session`:n.onSession?.(t.session_id);break;case`thinking`:n.onThinking?.();break;case`usage`:n.onUsage?.(t);break;case`tool_call`:n.onToolCall?.(t.name,t.arguments);break;case`tool_result`:n.onToolResult?.(t.name,t.result);break;case`tool_denied`:n.onToolDenied?.(t.name,t.reason);break;case`skill_selected`:n.onSkillSelected?.(t.name);break;case`skill_cleared`:n.onSkillCleared?.();break;case`context_set`:n.onContextSet?.(t.key,t.value);break;case`context_unset`:n.onContextUnset?.(t.key);break;case`content`:n.onContent?.(t.content);break;case`cancelled`:n.onCancelled?.(t.content);break;case`done`:n.onDone?.(t.content);break}}async function Ae(){try{let e=(await xe()).map(e=>({id:e.id,title:e.title,updatedAt:e.updated_at}));O.setChatList(e)}catch{}}function je(e,t,n,r){let i=O.state;return Oe({message:e,session_id:i.sessionId??void 0,skills:i.activeSkills.length?i.activeSkills:void 0,context:Object.keys(i.context).length?i.context:void 0},{onSession:t=>{if(O.update({sessionId:t,activeChatId:t}),!O.state.chatList.some(e=>e.id===t)){let n=e.replace(/^#{1,6}\s+/gm,``).replace(/\*{1,3}(.+?)\*{1,3}/g,`$1`).replace(/`(.+?)`/g,`$1`).replace(/\[([^\]]+)\]\([^)]+\)/g,`$1`).replace(/^[-*>]+\s+/gm,``).replace(/\n/g,` `).trim(),r=n.length>80?n.slice(0,80).trimEnd()+`...`:n;O.setChatList([{id:t,title:r||`New Chat`,updatedAt:Date.now()/1e3},...O.state.chatList])}},onThinking:()=>{O.updateLastAssistant(e=>({...e,thinking:!0}))},onUsage:e=>{O.update({usage:{totalTokens:e.total_tokens,promptTokens:e.prompt_tokens,completionTokens:e.completion_tokens,contextWindow:e.context_window}})},onToolCall:(e,n)=>{O.updateLastAssistant(e=>({...e,thinking:!1}));let r=O.state.toolPolicies[e]??fe(e);if(e===`select_skill`){let e=n.name??``;O.state.activeSkills.some(t=>t.toLowerCase()===e.toLowerCase())&&(r=`auto-accept`)}let i=t&&r===`ask`;if(O.addToolCallToLast({name:e,arguments:n,pending:i}),t&&r!==`ask`){let e=O.state.sessionId;if(e){let t=r===`auto-accept`;M(e,t,t?void 0:`auto-rejected by policy`).catch(()=>{}),t||O.updateLastToolCall(e=>({...e,pending:!1,denied:!0,denyReason:`auto-rejected by policy`}))}}},onToolResult:(e,t)=>{O.updateLastToolCall(e=>({...e,result:t,pending:!1}))},onToolDenied:(e,t)=>{O.updateLastToolCall(e=>({...e,denied:!0,denyReason:t,pending:!1}))},onSkillSelected:e=>{O.state.activeSkills.includes(e)||O.setActiveSkills([...O.state.activeSkills,e])},onSkillCleared:()=>{O.setActiveSkills([])},onContextSet:(e,t)=>{(O.state.toolPolicies.set_context??fe(`set_context`))!==`auto-reject`&&O.setContext(e,t)},onContextUnset:e=>{(O.state.toolPolicies.set_context??fe(`set_context`))!==`auto-reject`&&O.removeContext(e)},onContent:e=>{O.updateLastAssistant(t=>({...t,content:e,thinking:!1}))},onCancelled:e=>{let t=(performance.now()-n)/1e3;O.updateLastAssistant(t=>({...t,content:e||t.content||``,thinking:!1,cancelled:!0})),O.update({isStreaming:!1,streamElapsed:t,activeChatId:O.state.sessionId}),Ae()},onDone:e=>{let t=(performance.now()-n)/1e3;O.updateLastAssistant(t=>({...t,content:e,thinking:!1})),O.update({isStreaming:!1,streamElapsed:t,activeChatId:O.state.sessionId}),Ae()},onError:e=>{O.updateLastAssistant(t=>({...t,content:`Error: ${e.message}`,thinking:!1})),O.update({isStreaming:!1})}},{approve:t,signal:r})}function Me(e,t,n){let r=[],i=0,a=()=>`${t}-${i++}`;for(let t=0;t<e.length;t++){let i=e[t];if(i.role===`user`){r.push({id:a(),role:`user`,content:i.content??``,timestamp:n});continue}if(i.role===`assistant`&&i.tool_calls?.length){let o=[];for(let n of i.tool_calls){let r={};try{r=JSON.parse(n.function.arguments)}catch{}let i={name:n.function.name,arguments:r};for(let r=t+1;r<e.length;r++)if(e[r].role===`tool`&&e[r].tool_call_id===n.id){i.result=e[r].content??``;break}o.push(i)}let s=i.content??``,c,l=t+1;for(;l<e.length&&e[l].role===`tool`;)l++;l<e.length&&e[l].role===`assistant`&&!e[l].tool_calls?.length&&(c=e[l],s=c.content??``),r.push({id:a(),role:`assistant`,content:s,toolCalls:o,cancelled:c?.cancelled||void 0,timestamp:n});continue}if(i.role===`assistant`){if(r.length>0){let e=r[r.length-1];if(e.role===`assistant`&&e.toolCalls?.length&&e.content===i.content)continue}r.push({id:a(),role:`assistant`,content:i.content??``,cancelled:i.cancelled||void 0,timestamp:n});continue}}return r}function N(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var Ne,Pe=(Ne=class extends l{constructor(...e){super(...e),this.sidebarOpen=O.state.sidebarOpen,this.detailPaneOpen=O.state.detailPaneOpen,this.detailPaneWidth=O.state.detailPaneWidth,this.dragStartWidth=0,this.onBeforeUnload=()=>{if(O.state.isStreaming){let e=O.state.sessionId;e&&Ee(e)}},this.onSendMessage=e=>{this.handleSend(e.detail.message)},this.onCancelStream=()=>{this.handleCancel()},this.onLoadChat=async e=>{O.state.isStreaming&&this.handleCancel();let{chatId:t}=e.detail;try{let e=await Se(t),n=Me(e.messages??[],e.id,e.updated_at*1e3);O.setActiveChat(t,t,n)}catch(e){O.update({error:`Failed to load chat: ${e.message}`})}},this.onDeleteChat=async e=>{let{chatId:t}=e.detail;try{await Ce(t),O.removeChat(t)}catch(e){O.update({error:`Failed to delete chat: ${e.message}`})}},this.onPinCard=e=>{O.addCard(e.detail.card),O.state.detailPaneOpen||O.update({detailPaneOpen:!0})},this.onPaneResize=e=>{let t=getComputedStyle(this),n=parseInt(t.getPropertyValue(`--detail-pane-min-width`))||200,r=parseInt(t.getPropertyValue(`--chat-area-min-width`))||320,i=this.shadowRoot?.querySelector(`.main`),a=(i?i.clientWidth:1/0)-r-4;this.dragStartWidth||=this.detailPaneWidth,this.detailPaneWidth=Math.max(n,Math.min(a,this.dragStartWidth-e.detail.delta))},this.onPaneResizeEnd=()=>{O.update({detailPaneWidth:this.detailPaneWidth}),this.dragStartWidth=0}}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.sidebarOpen=O.state.sidebarOpen,this.detailPaneOpen=O.state.detailPaneOpen,!O.state.isStreaming&&this.abortController&&(this.abortController.abort(),this.abortController=void 0)}),this.addEventListener(`send-message`,this.onSendMessage),this.addEventListener(`cancel-stream`,this.onCancelStream),this.addEventListener(`load-chat`,this.onLoadChat),this.addEventListener(`delete-chat`,this.onDeleteChat),this.addEventListener(`pin-card`,this.onPinCard),window.addEventListener(`beforeunload`,this.onBeforeUnload),this.loadInitialData()}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),this.removeEventListener(`send-message`,this.onSendMessage),this.removeEventListener(`cancel-stream`,this.onCancelStream),this.removeEventListener(`load-chat`,this.onLoadChat),this.removeEventListener(`delete-chat`,this.onDeleteChat),this.removeEventListener(`pin-card`,this.onPinCard),window.removeEventListener(`beforeunload`,this.onBeforeUnload)}async loadInitialData(){try{let[e,t,n,r,i,a]=await Promise.all([me(),ge(),_e(),ve(),he(),xe()]),o=r,s=i,c=a.map(e=>({id:e.id,title:e.title,updatedAt:e.updated_at})),l=[],u=null;if(e.llm_status!==`ok`)u=`LLM server is unreachable. Start your LLM server and reload the page.`;else try{l=await A()}catch{u=`Could not fetch model list from LLM server.`}let d=o.filter(e=>!e.connected),f=[],p=e.tools;for(let e of d)try{let t=await ye(e.name);o=t.servers,p=t.tools}catch{f.push(e.name)}if(f.length>0){let e=f.join(`, `);u=[u,`MCP server${f.length>1?`s`:``} unreachable: ${e}.`].filter(Boolean).join(` `)}d.length>0&&(s=await he());let m=[...s,...de],h={};for(let e of m)h[e.name]=O.state.toolPolicies[e.name]??fe(e.name);O.update({model:e.model,mcpServers:o,toolCount:p,contextWindow:e.context_window,maxActiveSkills:e.max_active_skills,availableModels:l,availableSkills:t,availablePlaybooks:n,availableTools:m,toolPolicies:h,chatList:c,warning:u})}catch(e){O.update({error:`Cannot connect to agent server: ${e.message}`})}}handleCancel(){if(!this.abortController)return;let e=O.state.sessionId;e&&Te(e).catch(()=>{}),this.abortController.abort(),this.abortController=void 0,O.updateLastAssistant(e=>({...e,thinking:!1,content:e.content||``,cancelled:!0})),O.update({isStreaming:!1})}async handleSend(e){if(O.state.isStreaming)return;O.addMessage({id:O.genId(),role:`user`,content:e,timestamp:Date.now()}),O.addMessage({id:O.genId(),role:`assistant`,content:``,thinking:!0,timestamp:Date.now()});let t=O.needsApproval(),n=performance.now();O.update({isStreaming:!0,error:null,streamStartTime:Date.now()}),this.abortController=new AbortController,await je(e,t,n,this.abortController.signal)}render(){return a`
      <top-bar></top-bar>
      <div class="content">
        <div class="sidebar-container ${this.sidebarOpen?``:`collapsed`}">
          <agent-sidebar></agent-sidebar>
        </div>
        <div class="main">
          <div class="chat-area">
            <agent-chat></agent-chat>
          </div>
          ${this.detailPaneOpen?a`
                <resize-handle
                  @handle-resize=${this.onPaneResize}
                  @resize-end=${this.onPaneResizeEnd}
                ></resize-handle>
                <detail-pane style="width:${this.detailPaneWidth}px"></detail-pane>
              `:``}
        </div>
      </div>
    `}},Ne.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: var(--bg-primary);
      color: var(--text-primary);
      font-family: var(--font-sans);
    }

    .content {
      display: flex;
      flex: 1;
      min-height: 0;
      overflow: hidden;
    }

    .sidebar-container {
      width: var(--sidebar-width);
      min-width: var(--sidebar-width);
      height: 100%;
      transition: margin-left var(--transition-normal);
      overflow: hidden;
    }

    .sidebar-container.collapsed {
      margin-left: calc(-1 * var(--sidebar-width));
    }

    .main {
      flex: 1;
      display: flex;
      flex-direction: row;
      height: 100%;
      min-width: 0;
      position: relative;
    }

    .chat-area {
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100%;
      min-width: var(--chat-area-min-width);
      position: relative;
    }

    detail-pane {
      height: 100%;
      flex-shrink: 0;
    }

    @media (max-width: 768px) {
      .sidebar-container {
        position: absolute;
        z-index: 100;
        top: 0;
        left: 0;
        height: 100%;
        box-shadow: var(--shadow-lg);
      }

      .sidebar-container.collapsed {
        margin-left: calc(-1 * var(--sidebar-width));
      }

      resize-handle,
      detail-pane {
        display: none;
      }
    }
  `,Ne);N([i()],Pe.prototype,`sidebarOpen`,void 0),N([i()],Pe.prototype,`detailPaneOpen`,void 0),N([i()],Pe.prototype,`detailPaneWidth`,void 0),Pe=N([s(`agent-app`)],Pe);var Fe,Ie=(Fe=class extends l{constructor(...e){super(...e),this.model=``,this.toolCount=0,this.contextWindow=0,this.sessionId=null,this.activeChatId=null,this.chatList=[],this.error=null,this.warning=null,this.openSections={status:!1,session:!1,model:!1,mcp:!1,skills:!1,context:!1,policies:!1}}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{let e=O.state;this.model=e.model,this.toolCount=e.toolCount,this.contextWindow=e.contextWindow,this.sessionId=e.sessionId,this.activeChatId=e.activeChatId,this.chatList=e.chatList,this.error=e.error,this.warning=e.warning})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}newChat(){O.clearMessages()}selectChat(e){e!==this.activeChatId&&this.dispatchEvent(new CustomEvent(`load-chat`,{detail:{chatId:e},bubbles:!0,composed:!0}))}deleteChat(e,t){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`delete-chat`,{detail:{chatId:t},bubbles:!0,composed:!0}))}toggleSection(e){this.openSections={...this.openSections,[e]:!this.openSections[e]}}renderAccordion(e,t,n){let r=this.openSections[e]??!1;return a`
      <div class="accordion">
        <div class="accordion-header" @click=${()=>this.toggleSection(e)}>
          <span class="section-title">${t}</span>
          <svg
            class="accordion-chevron ${r?`open`:``}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6"></polyline>
          </svg>
        </div>
        <div class="accordion-body ${r?`open`:``}">
          <div>${n}</div>
        </div>
      </div>
    `}relativeTime(e){let t=Math.floor(Date.now()/1e3-e);if(t<60)return`just now`;let n=Math.floor(t/60);if(n<60)return`${n}m ago`;let r=Math.floor(n/60);return r<24?`${r}h ago`:`${Math.floor(r/24)}d ago`}render(){return a`
      <div class="body">
        ${this.error?a`<div class="error-banner">${this.error}</div>`:``}
        ${this.warning?a`<div class="warning-banner">${this.warning}</div>`:``}

        <div class="section">
          <span class="section-title">Chats</span>
          <button class="new-chat-btn" ?disabled=${!this.activeChatId} @click=${this.newChat}>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            New Chat
          </button>
          ${this.chatList.length?a`
                <div class="chat-list">
                  ${this.chatList.map(e=>a`
                      <div
                        class="chat-item ${e.id===this.activeChatId?`active`:``}"
                        @click=${()=>this.selectChat(e.id)}
                      >
                        <span class="chat-item-indicator">
                          ${e.id===this.activeChatId?a`<svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                              >
                                <path
                                  d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
                                ></path>
                              </svg>`:``}
                        </span>
                        <span class="chat-item-title">${e.title}</span>
                        <span class="chat-item-trailing">
                          <span class="chat-item-time">${this.relativeTime(e.updatedAt)}</span>
                          <button
                            class="chat-item-delete"
                            title="Delete chat"
                            @click=${t=>this.deleteChat(t,e.id)}
                          >
                            <svg
                              width="14"
                              height="14"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            >
                              <polyline points="3 6 5 6 21 6"></polyline>
                              <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"></path>
                              <path d="M10 11v6"></path>
                              <path d="M14 11v6"></path>
                            </svg>
                          </button>
                        </span>
                      </div>
                    `)}
                </div>
              `:``}
        </div>

        ${this.renderAccordion(`status`,`Status`,a`
            <div class="status-grid">
              <span class="status-label">Model</span>
              <span class="status-value">${this.model||`—`}</span>
              <span class="status-label">Tools</span>
              <span class="status-value">${this.toolCount}</span>
              <span class="status-label">Context</span>
              <span class="status-value">
                ${this.contextWindow?`${(this.contextWindow/1e3).toFixed(1)}k tokens`:`—`}
              </span>
            </div>
          `)}
        ${this.sessionId?this.renderAccordion(`session`,`Session`,a`<div class="session-id">${this.sessionId}</div>`):``}
        ${this.renderAccordion(`model`,`Model`,a`<model-selector></model-selector>`)}
        ${this.renderAccordion(`mcp`,`MCP Servers`,a`<mcp-manager></mcp-manager>`)}
        ${this.renderAccordion(`skills`,`Skills`,a`<skill-selector></skill-selector>`)}
        ${this.renderAccordion(`context`,`Context`,a`<context-editor></context-editor>`)}
        ${this.renderAccordion(`policies`,`Tool Policies`,a`<tool-policy-editor></tool-policy-editor>`)}
      </div>
    `}},Fe.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      background: var(--bg-sidebar);
      border-right: none;
      overflow: hidden;
    }

    .new-chat-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 14px;
      border-radius: var(--radius-sm);
      background: var(--accent-primary);
      color: var(--text-inverse);
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      border: none;
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .new-chat-btn:hover:not(:disabled) {
      background: var(--accent-hover);
    }

    .new-chat-btn:disabled {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      cursor: default;
    }

    .new-chat-btn svg {
      width: 14px;
      height: 14px;
    }

    .body {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .body::-webkit-scrollbar {
      width: 4px;
    }

    .body::-webkit-scrollbar-track {
      background: transparent;
    }

    .body::-webkit-scrollbar-thumb {
      background: var(--border-primary);
      border-radius: 2px;
    }

    .section {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .section-title {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .status-grid {
      display: grid;
      grid-template-columns: auto 1fr;
      gap: 4px 12px;
      font-size: var(--font-size-sm);
    }

    .status-label {
      color: var(--text-tertiary);
    }

    .status-value {
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .session-id {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      padding: 4px 0;
      word-break: break-all;
    }

    .footer {
      padding: 12px 16px;
      border-top: 1px solid var(--border-secondary);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .error-banner {
      padding: 8px 12px;
      background: var(--accent-danger);
      color: var(--text-inverse);
      font-size: var(--font-size-sm);
      border-radius: var(--radius-xs);
    }

    .warning-banner {
      padding: 8px 12px;
      background: var(--accent-warning, #b45309);
      color: var(--text-inverse, #fff);
      font-size: var(--font-size-sm);
      border-radius: var(--radius-xs);
    }

    .chat-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .chat-item {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 6px 10px;
      border-radius: var(--radius-xs);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .chat-item:hover {
      background: var(--bg-hover);
    }

    .chat-item.active {
      background: var(--bg-active, var(--bg-hover));
    }

    .chat-item-indicator {
      flex-shrink: 0;
      width: 14px;
      height: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--accent-primary);
    }

    .chat-item-indicator svg {
      width: 14px;
      height: 14px;
    }

    .chat-item-title {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: var(--font-size-sm);
      color: var(--text-primary);
    }

    .chat-item-trailing {
      flex-shrink: 0;
      display: grid;
      place-items: center;
    }

    .chat-item-trailing > * {
      grid-area: 1 / 1;
    }

    .chat-item-time {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      pointer-events: none;
      transition: opacity var(--transition-fast);
    }

    .chat-item-delete {
      z-index: 1;
      background: none;
      border: none;
      cursor: pointer;
      color: var(--text-tertiary);
      padding: 2px;
      border-radius: var(--radius-xs);
      line-height: 1;
      opacity: 0;
      transition:
        opacity var(--transition-fast),
        color var(--transition-fast);
    }

    .chat-item-delete:hover {
      color: var(--accent-danger);
    }

    .chat-item:hover .chat-item-delete {
      opacity: 1;
    }

    .chat-item:hover .chat-item-time {
      opacity: 0;
    }

    .accordion {
      display: flex;
      flex-direction: column;
    }

    .accordion-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
      user-select: none;
      padding: 2px 0;
    }

    .accordion-header:hover .accordion-chevron {
      color: var(--text-primary);
    }

    .accordion-chevron {
      width: 14px;
      height: 14px;
      color: var(--text-tertiary);
      transition:
        transform var(--transition-fast),
        color var(--transition-fast);
      flex-shrink: 0;
    }

    .accordion-chevron.open {
      transform: rotate(90deg);
    }

    .accordion-body {
      display: grid;
      grid-template-rows: 0fr;
      transition: grid-template-rows 0.2s ease;
    }

    .accordion-body.open {
      grid-template-rows: 1fr;
    }

    .accordion-body > div {
      overflow: hidden;
      padding-top: 0;
      transition: padding-top 0.2s ease;
    }

    .accordion-body.open > div {
      padding-top: 8px;
    }
  `,Fe);N([i()],Ie.prototype,`model`,void 0),N([i()],Ie.prototype,`toolCount`,void 0),N([i()],Ie.prototype,`contextWindow`,void 0),N([i()],Ie.prototype,`sessionId`,void 0),N([i()],Ie.prototype,`activeChatId`,void 0),N([i()],Ie.prototype,`chatList`,void 0),N([i()],Ie.prototype,`error`,void 0),N([i()],Ie.prototype,`warning`,void 0),N([i()],Ie.prototype,`openSections`,void 0),Ie=N([s(`agent-sidebar`)],Ie);var Le,Re={Health:`monitor_heart`,Migration:`swap_horiz`,Setup:`build`};function ze(e){return e.split(`-`).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(` `)}var Be=(Le=class extends l{constructor(...e){super(...e),this.messages=[],this.playbooks=[],this.showPlaybooks=!1,this.hasUserToggledPlaybooks=!1}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{let e=this.messages;this.messages=O.state.messages,this.playbooks=O.state.availablePlaybooks,e.length>0&&this.messages.length===0&&(this.hasUserToggledPlaybooks=!1),this.hasUserToggledPlaybooks||(this.showPlaybooks=this.messages.length===0),this.messages!==e&&this.scrollToBottom()})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}scrollToBottom(){requestAnimationFrame(()=>{this.scrollContainer&&(this.scrollContainer.scrollTop=this.scrollContainer.scrollHeight)})}onTogglePlaybooks(){this.hasUserToggledPlaybooks=!0,this.showPlaybooks=!this.showPlaybooks}onPlaybookClick(e){this.showPlaybooks=!1,this.dispatchEvent(new CustomEvent(`send-message`,{detail:{message:e.body},bubbles:!0,composed:!0}))}renderPlaybooks(){if(!this.playbooks.length)return r;let e=new Map;for(let t of this.playbooks){let n=e.get(t.category)??[];n.push(t),e.set(t.category,n)}return a`${Array.from(e.entries()).map(([e,t])=>a`
        <div class="playbook-section">
          <div class="playbook-category">${e}</div>
          <div class="playbook-grid">
            ${t.map(t=>a`
                <div class="playbook-card" @click=${()=>this.onPlaybookClick(t)}>
                  <span class="card-icon">${Re[e]??`article`}</span>
                  <div class="card-text">
                    <div class="card-name">${ze(t.name)}</div>
                    <div class="card-desc">${t.description}</div>
                  </div>
                </div>
              `)}
          </div>
        </div>
      `)}`}render(){return a`
      ${this.messages.length>0?a`
            <div class="messages-scroll">
              <div class="messages">
                ${o(this.messages,e=>e.id,e=>a`<chat-message .msg=${e}></chat-message>`)}
              </div>
            </div>
          `:a`
            <div class="empty-state ${this.showPlaybooks?`compact`:``}">
              <div class="empty-header">
                <span class="empty-icon">forklift</span>
                <div class="empty-title">Moving your virtual machines?</div>
                <div class="empty-hint">Pick a playbook to get started, or ask me anything.</div>
              </div>
            </div>
          `}

      <div class="composer-area">
        <div class="composer-inner">
          <chat-composer
            .playbooksOpen=${this.showPlaybooks}
            @toggle-playbooks=${this.onTogglePlaybooks}
          ></chat-composer>
          <div class="playbook-panel ${this.showPlaybooks?`open`:``}">
            ${this.renderPlaybooks()}
          </div>
        </div>
      </div>
    `}},Le.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
    }

    .messages-scroll {
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      padding: 60px 24px 12px;
      scroll-behavior: smooth;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .messages-scroll::-webkit-scrollbar {
      width: 6px;
    }

    .messages-scroll::-webkit-scrollbar-track {
      background: transparent;
    }

    .messages-scroll::-webkit-scrollbar-thumb {
      background: var(--border-primary);
      border-radius: 3px;
    }

    .messages {
      max-width: var(--chat-max-width);
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .empty-state {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      overflow-y: auto;
      padding: 24px;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .empty-state.compact {
      flex: none;
      justify-content: flex-end;
      min-height: 180px;
    }

    .empty-header {
      text-align: center;
      margin-bottom: 32px;
    }

    .empty-icon {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 48px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
      opacity: 0.4;
      color: var(--text-tertiary);
    }

    .empty-title {
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-medium);
      color: var(--text-secondary);
      margin-top: 12px;
    }

    .empty-hint {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      margin-top: 4px;
    }

    .playbook-section {
      width: 100%;
      max-width: var(--chat-max-width);
      margin-bottom: 24px;
    }

    .playbook-category {
      font-size: var(--font-size-xs, 11px);
      font-weight: var(--font-weight-semibold, 600);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--text-tertiary);
      margin-bottom: 8px;
      padding-left: 4px;
    }

    .playbook-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 10px;
    }

    .playbook-card {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 14px 16px;
      border-radius: var(--radius-lg, 12px);
      border: 1px solid var(--border-primary);
      background: var(--bg-secondary);
      cursor: pointer;
      transition:
        border-color var(--transition-fast),
        box-shadow var(--transition-fast);
    }

    .playbook-card:hover {
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 1px var(--accent-primary);
    }

    .card-icon {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 22px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
      color: var(--accent-primary);
      flex-shrink: 0;
      margin-top: 1px;
    }

    .card-text {
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
    }

    .card-name {
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
    }

    .card-desc {
      font-size: var(--font-size-xs, 11px);
      color: var(--text-tertiary);
      line-height: 1.4;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .composer-area {
      padding: 8px 24px 24px;
    }

    .composer-inner {
      max-width: var(--chat-max-width);
      margin: 0 auto;
    }

    .playbook-panel {
      max-width: var(--chat-max-width);
      margin: 0 auto;
      overflow: hidden;
      max-height: 0;
      opacity: 0;
      transition:
        max-height 0.3s ease,
        opacity 0.25s ease,
        padding 0.3s ease;
      padding: 0;
    }

    .playbook-panel.open {
      max-height: min(2000px, 60vh);
      opacity: 1;
      padding: 12px 0 0;
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }
  `,Le);N([i()],Be.prototype,`messages`,void 0),N([i()],Be.prototype,`playbooks`,void 0),N([i()],Be.prototype,`showPlaybooks`,void 0),N([c(`.messages-scroll`)],Be.prototype,`scrollContainer`,void 0),Be=N([s(`agent-chat`)],Be);var Ve,He=(Ve=class extends l{constructor(...e){super(...e),this.userExpanded=!1,this.userOverflows=!1}updated(){this.msg.role!==`user`||!this.msg.content||(this.renderRoot.querySelector(`markdown-renderer`)?.updateComplete??Promise.resolve()).then(()=>{requestAnimationFrame(()=>this._measureOverflow())})}_measureOverflow(){let e=this.renderRoot.querySelector(`.bubble`);if(!e)return;let t=this.userExpanded?!0:e.scrollHeight>e.clientHeight+1;t!==this.userOverflows&&(this.userOverflows=t)}toggleExpand(){this.userExpanded=!this.userExpanded}formatTime(e){return new Date(e).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}render(){let e=this.msg,t=e.role===`user`,n=e.role===`assistant`&&e.cancelled===!0;return a`
      <div class="message ${e.role}${n?` cancelled`:``}">
        ${t?r:a`<span class="role-label">Assistant</span>`}
        ${e.thinking?a`<thinking-indicator></thinking-indicator>`:r}
        ${e.toolCalls?.length?a`
              <div class="tool-calls">
                ${e.toolCalls.map(e=>a`<tool-call-card .entry=${e} .sessionId=${this.msg.id}></tool-call-card>`)}
              </div>
            `:r}
        ${e.content?t?a`
                <div class="bubble-wrapper">
                  <div class="bubble ${this.userExpanded?``:`truncated`}">
                    <markdown-renderer .content=${e.content}></markdown-renderer>
                  </div>
                  ${this.userOverflows?a`<button
                        class="expand-toggle"
                        @click=${this.toggleExpand}
                        title=${this.userExpanded?`Collapse`:`Expand`}
                      >
                        ${this.userExpanded?`▽`:`◁`}
                      </button>`:r}
                </div>
              `:a`
                <div class="bubble">
                  <markdown-renderer .content=${e.content}></markdown-renderer>
                </div>
              `:r}
        ${n?a`<span class="cancelled-label" aria-label="This response was cancelled"
              >cancelled<span class="sr-only"> — response was interrupted</span></span
            >`:r}
        <span class="timestamp">${this.formatTime(e.timestamp)}</span>
      </div>
    `}},Ve.styles=d`
    :host {
      display: block;
      padding: 4px 0;
      animation: fadeIn 0.25s ease;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(8px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .message {
      display: flex;
      flex-direction: column;
      max-width: 100%;
    }

    .message.user {
      align-items: flex-end;
    }

    .message.assistant {
      align-items: flex-start;
    }

    .bubble {
      max-width: 85%;
      border-radius: var(--radius-lg);
      line-height: var(--line-height);
    }

    .user .bubble-wrapper .bubble {
      max-width: 100%;
    }

    .user .bubble-wrapper {
      position: relative;
      max-width: 85%;
    }

    .user .bubble {
      background: var(--bg-user-bubble);
      color: var(--text-primary);
      padding: 10px 16px;
      border-bottom-right-radius: var(--radius-xs);
      --md-h1-size: 1em;
      --md-h2-size: 1em;
      --md-h3-size: 1em;
      --md-h4-size: 1em;
    }

    .user .bubble.truncated {
      max-height: 6.4em;
      overflow: hidden;
    }

    .expand-toggle {
      position: absolute;
      top: 4px;
      right: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      font-size: 14px;
      line-height: 1;
      color: var(--text-tertiary);
      background: var(--bg-user-bubble);
      border: none;
      border-radius: var(--radius-xs);
      cursor: pointer;
      padding: 0;
      z-index: 1;
    }

    .expand-toggle:hover {
      color: var(--text-secondary);
    }

    .assistant .bubble {
      background: var(--bg-assistant);
      color: var(--text-primary);
      max-width: 100%;
      padding: 4px 0;
    }

    .tool-calls {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin: 8px 0;
      max-width: 100%;
    }

    .timestamp {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      margin-top: 4px;
      padding: 0 4px;
    }

    .role-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-medium);
      color: var(--text-tertiary);
      margin-bottom: 4px;
      padding: 0 4px;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    .message.assistant.cancelled .bubble {
      opacity: 0.7;
      border-left: 3px solid #d32f2f;
      padding-left: 8px;
    }

    .cancelled-label {
      font-size: var(--font-size-xs);
      color: #d32f2f;
      font-style: italic;
      margin-top: 2px;
      padding: 0 4px;
    }

    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
  `,Ve);N([n({type:Object})],He.prototype,`msg`,void 0),N([i()],He.prototype,`userExpanded`,void 0),N([i()],He.prototype,`userOverflows`,void 0),He=N([s(`chat-message`)],He);var Ue,We=(Ue=class extends l{constructor(...e){super(...e),this.playbooksOpen=!1,this.text=``,this.isStreaming=!1,this.usage=null,this.elapsed=null}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.isStreaming=O.state.isStreaming,this.usage=O.state.usage,this.elapsed=O.state.streamElapsed})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}autoResize(){let e=this.textarea;e&&(e.style.height=`auto`,e.scrollHeight>e.clientHeight?e.style.height=Math.min(e.scrollHeight,200)+`px`:e.style.removeProperty(`height`))}handleInput(e){this.text=e.target.value,this.autoResize()}handleKeyDown(e){e.key===`Enter`&&!e.shiftKey&&(e.preventDefault(),this.send())}togglePlaybooks(){this.dispatchEvent(new CustomEvent(`toggle-playbooks`,{bubbles:!0,composed:!0}))}send(){let e=this.text.trim();!e||this.isStreaming||(this.text=``,this.textarea&&(this.textarea.style.height=`auto`),this.dispatchEvent(new CustomEvent(`send-message`,{detail:{message:e},bubbles:!0,composed:!0})))}cancel(){this.dispatchEvent(new CustomEvent(`cancel-stream`,{bubbles:!0,composed:!0}))}formatTokens(e){return e>=1e3?`${(e/1e3).toFixed(1)}k`:String(e)}render(){return a`
      ${this.usage||this.elapsed!==null?a`
            <div class="usage-bar">
              ${this.usage?a`<span>
                    ${this.formatTokens(this.usage.totalTokens)} /
                    ${this.formatTokens(this.usage.contextWindow)} tokens
                  </span>`:``}
              ${this.elapsed===null?``:a`<span>${this.elapsed.toFixed(1)}s</span>`}
            </div>
          `:``}

      <div class="composer">
        <button
          class="toggle-btn ${this.playbooksOpen?`open`:``}"
          @click=${this.togglePlaybooks}
          title="${this.playbooksOpen?`Hide playbooks`:`Show playbooks`}"
          aria-label="${this.playbooksOpen?`Hide playbooks`:`Show playbooks`}"
        >
          <span class="material-symbols-outlined">add</span>
        </button>
        <textarea
          rows="1"
          placeholder="Send a message..."
          .value=${this.text}
          @input=${this.handleInput}
          @keydown=${this.handleKeyDown}
        ></textarea>
        ${this.isStreaming?a`<button class="send-btn stop" @click=${this.cancel} title="Stop" aria-label="Stop">
              <span class="material-symbols-outlined">forklift</span>
            </button>`:a`<button
              class="send-btn"
              @click=${this.send}
              ?disabled=${!this.text.trim()}
              title="Send message"
              aria-label="Send message"
            >
              <span class="material-symbols-outlined">forklift</span>
            </button>`}
      </div>
    `}},Ue.styles=d`
    :host {
      display: block;
    }

    .usage-bar {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 12px;
      padding: 4px 8px;
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
    }

    .composer {
      display: flex;
      align-items: flex-end;
      gap: 8px;
      padding: 12px 16px;
      background: var(--bg-input);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-md);
      transition:
        border-color var(--transition-fast),
        box-shadow var(--transition-fast);
    }

    .composer:focus-within {
      border-color: var(--accent-primary);
      box-shadow:
        var(--shadow-md),
        0 0 0 2px rgba(174, 86, 48, 0.15);
    }

    textarea {
      flex: 1;
      border: none;
      background: none;
      resize: none;
      outline: none;
      font-family: var(--font-sans);
      font-size: var(--font-size-base);
      line-height: var(--line-height);
      color: var(--text-primary);
      max-height: 200px;
      min-height: 24px;
      padding: 7px 0;
    }

    textarea::placeholder {
      color: var(--text-tertiary);
    }

    .send-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border: none;
      border-radius: var(--radius-full);
      background: var(--accent-primary);
      color: var(--text-inverse);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        background var(--transition-fast),
        transform var(--transition-fast);
    }

    .send-btn:hover {
      background: var(--accent-hover);
    }

    .send-btn:active {
      transform: scale(0.95);
    }

    .send-btn:disabled {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      cursor: not-allowed;
    }

    .send-btn.stop {
      background: var(--status-error, #d32f2f);
    }

    .send-btn.stop:hover {
      background: color-mix(in srgb, var(--status-error, #d32f2f) 85%, black);
    }

    .send-btn .material-symbols-outlined {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 20px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
    }

    .toggle-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border: none;
      border-radius: var(--radius-full);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        color var(--transition-fast),
        background var(--transition-fast),
        transform var(--transition-fast);
    }

    .toggle-btn:hover {
      color: var(--accent-primary);
      background: var(--bg-secondary);
    }

    .toggle-btn.open {
      color: var(--accent-primary);
      transform: rotate(45deg);
    }

    .toggle-btn .material-symbols-outlined {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 22px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
    }
  `,Ue);N([n({type:Boolean})],We.prototype,`playbooksOpen`,void 0),N([i()],We.prototype,`text`,void 0),N([i()],We.prototype,`isStreaming`,void 0),N([i()],We.prototype,`usage`,void 0),N([i()],We.prototype,`elapsed`,void 0),N([c(`textarea`)],We.prototype,`textarea`,void 0),We=N([s(`chat-composer`)],We);var Ge={table:`markdown`,graph:`graph`,markdown:`markdown`,text:`text`,log:`text`,raw:`text`};function Ke(e){return Ge[e]}function qe(e){let t=p.lexer(e);for(let e of t)if(e.type===`table`){let t=e;return{headers:t.header.map(e=>e.text),rows:t.rows.map(e=>e.map(e=>e.text))}}return null}function Je(e){return e.replace(/^-+\s*/,``).replace(/\s*-+$/,``).trim()}function Ye(e){let t=p.lexer(e),n=[],r;for(let e of t)if(e.type===`heading`)r=Je(e.text);else if(e.type===`table`){let t=e;n.push({heading:r,table:{headers:t.header.map(e=>e.text),rows:t.rows.map(e=>e.map(e=>e.text))}}),r=void 0}else e.type!==`space`&&(r=void 0);return n}function Xe(e){let t=[0],n=0;for(let r=0;r<e.length;r++)e[r]===` `?n++:(n>=2&&t.push(r),n=0);return t}function Ze(e){let t=e.split(`
`).filter(e=>e.trim());if(t.length<2)return null;let n=Xe(t[0]);if(n.length<2)return null;let r=e=>n.map((t,r)=>{let i=r<n.length-1?n[r+1]:e.length;return e.substring(t,i).trim()});return{headers:r(t[0]),rows:t.slice(1).map(e=>r(e))}}function Qe(e){let t=e.search(/[[{]/);if(t<0)return null;let n=e.slice(t);try{return JSON.parse(n)}catch{return null}}function $e(e){return e==null?``:typeof e==`object`?JSON.stringify(e):String(e)}function et(e){let t=Qe(e);if(typeof t!=`object`||!t)return null;let n=[];if(Array.isArray(t))for(let e of t)typeof e==`object`&&e&&!Array.isArray(e)&&n.push(e);else n.push(t);if(n.length===0)return null;let r=new Set;for(let e of n)for(let t of Object.keys(e))r.add(t);let i=[...r];return i.length===0?null:{headers:i,rows:n.map(e=>i.map(t=>$e(e[t])))}}function tt(e){return qe(e)??Ze(e)??et(e)}var nt=new Set([`true`,`yes`]),rt=new Set([`false`,`no`]);function it(e){let t=e.trim();if(!t)return t;let n=t.toLowerCase();if(nt.has(n))return`true`;if(rt.has(n))return`false`;if(/^[+-]?\d+(\.\d+)?$/.test(t)){let e=parseFloat(t);if(!isNaN(e))return String(e)}return t}function at(e){return{headers:e.headers,rows:e.rows.map(e=>e.map(it))}}function ot(e){let t=e=>`| `+e.join(` | `)+` |`,n=e.headers.map(()=>`---`);return[t(e.headers),t(n),...e.rows.map(t)].join(`
`)}function st(e){if(!e?.trim())return e;let t=tt(e);return t?ot(at(t)):e}function ct(e){return e?.trim()?st(e):e}function lt(e){return e}var ut=`mtv_read`,dt=`user-kubectl-mtv`,ft=[`get plan`,`get provider`,`get hook`,`get host`,`get mapping`];function pt(e){return typeof e.command==`string`?e.command.trim():``}var mt=[{server:dt,tool:ut,category:`inventory-list`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){return pt(e).startsWith(`get inventory`)},parse:ct},{server:dt,tool:ut,category:`resource-describe`,renderer:`markdown`,canPin:!0,canPinGraph:!1,match(e){return pt(e).startsWith(`describe`)},parse:lt},{server:dt,tool:ut,category:`health`,renderer:`text`,canPin:!0,canPinGraph:!1,match(e){return pt(e)===`health`},parse:lt},{server:dt,tool:ut,category:`settings`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){let t=pt(e);return t===`settings`||t===`settings get`},parse:ct},{server:dt,tool:ut,category:`resource-list`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){let t=pt(e);return ft.some(e=>t===e||t.startsWith(e+` `))},parse:ct}],ht=[{server:`user-kubectl-mtv`,tool:`mtv_write`,category:`write`,renderer:`markdown`,canPin:!1,canPinGraph:!1,match(){return!0},parse:lt}],gt=[{server:`user-kubectl-mtv`,tool:`mtv_help`,category:`help`,renderer:`markdown`,canPin:!1,canPinGraph:!1,match(){return!0},parse:lt}];function _t(e){return e}var vt=`metrics_read`,yt=`user-kubectl-metrics`;function P(e){return typeof e.command==`string`?e.command.trim():``}var bt=[{server:yt,tool:vt,category:`query-range`,renderer:`graph`,canPin:!0,canPinGraph:!0,match(e){let t=P(e);return t===`query_range`||t===`preset`},parse:_t},{server:yt,tool:vt,category:`query`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){return P(e)===`query`},parse:ct},{server:yt,tool:vt,category:`discover`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){let t=P(e);return t===`discover`||t===`labels`},parse:ct}],xt=[{server:`user-kubectl-metrics`,tool:`metrics_help`,category:`help`,renderer:`markdown`,canPin:!1,canPinGraph:!1,match(){return!0},parse:lt}];function St(e){return e?.trim()?"```\n"+e.trimEnd()+"\n```":e}var Ct=`debug_read`,F=`user-kubectl-debug-queries`;function wt(e){return typeof e.command==`string`?e.command.trim():``}var Tt=[{server:F,tool:Ct,category:`resource-list`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){return wt(e)===`list`},parse:ct},{server:F,tool:Ct,category:`resource-get`,renderer:`markdown`,canPin:!0,canPinGraph:!1,match(e){return wt(e)===`get`},parse:lt},{server:F,tool:Ct,category:`logs`,renderer:`log`,canPin:!0,canPinGraph:!1,match(e){return wt(e)===`logs`},parse:St},{server:F,tool:Ct,category:`events`,renderer:`table`,canPin:!0,canPinGraph:!1,match(e){return wt(e)===`events`},parse:ct}],Et=[{server:`user-kubectl-debug-queries`,tool:`debug_help`,category:`help`,renderer:`markdown`,canPin:!1,canPinGraph:!1,match(){return!0},parse:lt}],Dt=[{server:`builtin`,tool:`web_fetch`,category:`web-fetch`,renderer:`markdown`,canPin:!0,canPinGraph:!1,match(){return!0},parse:lt}],Ot=[...mt,...ht,...gt,...bt,...xt,...Tt,...Et,...Dt];function kt(e){if(!e?.trim())return{text:``,hasError:!0,errorMessage:`Empty tool result`};try{let t=JSON.parse(e);if(!t||typeof t!=`object`)return{text:e,hasError:!1};let n=t.return_value,r=typeof t.output==`string`?t.output:``,i=typeof t.stderr==`string`?t.stderr.trim():``;if(typeof n==`number`&&n!==0){let e=i||r||`Tool exited with code ${n}`;return{text:r||i,hasError:!0,errorMessage:e}}return i&&typeof n!=`number`?{text:r,hasError:!0,errorMessage:i}:typeof t.output==`string`?{text:r,hasError:!1}:{text:e,hasError:!1}}catch{return{text:e,hasError:!1}}}function At(e){return e?.trim()?"```\n"+e.trimEnd()+"\n```":e}var jt=new Set([`json`,`yaml`]);function Mt(e,t){return"```"+t+`
`+e.trimEnd()+"\n```"}var Nt=new Map;for(let e of Ot){let t=Nt.get(e.tool)??[];t.push(e),Nt.set(e.tool,t)}function Pt(e){let t=e.flags;if(t&&typeof t==`object`&&!Array.isArray(t)){let e=t.output;if(typeof e==`string`)return e}if(typeof e.output==`string`)return e.output}function Ft(e){return typeof e.command==`string`?e.command.trim():``}function It(e,t){let n=Nt.get(e);if(n){for(let e of n)if(e.match(t))return{identified:!0,server:e.server,tool:e.tool,command:Ft(t),category:e.category,renderer:e.renderer,outputFlag:Pt(t),canPin:e.canPin,canPinGraph:e.canPinGraph}}return{identified:!1,server:`unknown`,tool:e,command:Ft(t),category:`unknown`,renderer:`raw`,outputFlag:Pt(t),canPin:!1,canPinGraph:!1}}function Lt(e){if(e.identified)return Nt.get(e.tool)?.find(t=>t.category===e.category)}function Rt(e,t){let n=kt(t),r=`text`;if(n.hasError)return{hasError:!0,errorMessage:n.errorMessage,content:n.text||n.errorMessage||t,displayType:r,raw:t};let i=Lt(e),a=n.text,o=e.outputFlag?.toLowerCase();return o&&jt.has(o)?{hasError:!1,content:Mt(a,o),displayType:`markdown`,raw:t}:o===`markdown`?{hasError:!1,content:i?i.parse(a):a,displayType:`markdown`,raw:t}:{hasError:!1,content:i?i.parse(a):At(a),displayType:i?Ke(i.renderer):r,raw:t}}var zt={k:1e3,K:1e3,M:1e6,G:1e9,T:0xe8d4a51000};function Bt(e){let t=e.trim();if(!t)return NaN;let n=t.match(/^([+-]?\d+(?:\.\d+)?)\s*([kKMGT])?$/);return n?parseFloat(n[1])*(n[2]?zt[n[2]]??1:1):NaN}function Vt(e,t){let{headers:n,rows:r}=e,i=n.findIndex(e=>/^timestamp$/i.test(e));if(i<0)return[];let a=n.map((e,t)=>({name:e,idx:t})).filter(({idx:e})=>e!==i);if(a.length===0)return[];let o=[];for(let e of a){let n=t??e.name,a=[];for(let t of r){let n=t[i]?.trim(),r=t[e.idx]?.trim();if(!n||!r)continue;let o=Date.parse(n),s=Bt(r);isNaN(o)||isNaN(s)||a.push({x:o,y:s})}a.length>0&&(a.sort((e,t)=>e.x-t.x),o.push({name:n,data:a}))}return o}function Ht(e){if(!e?.trim())return null;let t=Ye(e);if(t.length>0){let e=t.flatMap(e=>Vt(e.table,e.heading));if(e.length>0)return{series:e}}let n=tt(e);if(!n)return null;let r=Vt(n);return r.length>0?{series:r}:null}function Ut(e,t){let n=e+JSON.stringify(t),r=5381;for(let e=0;e<n.length;e++)r=(r<<5)+r+n.charCodeAt(e)>>>0;return`card-${r.toString(36)}`}function Wt(e){let t=kt(e).text;return t?.trim()?Ht(t):null}var Gt,Kt=(Gt=class extends l{constructor(...e){super(...e),this.sessionId=``,this.expanded=!1,this.pinned=!1,this.graphPinned=!1,this.denyReasonInput=``,this._graphCacheValue=!1}get identification(){let e=this.entry,t=e.name+JSON.stringify(e.arguments);return this._idCacheKey===t&&this._idCacheValue?this._idCacheValue:(this._idCacheKey=t,this._idCacheValue=It(e.name,e.arguments),this._idCacheValue)}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>this.syncPinned())}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}syncPinned(){let e=this.entry;e.result&&!e.denied&&(this.pinned=O.hasCard(Ut(e.name,e.arguments)),this.graphPinned=O.hasCard(`graph-${Ut(e.name,e.arguments)}`))}toggle(){this.expanded=!this.expanded}pinCard(e){e.stopPropagation();let t=this.entry,n=Ut(t.name,t.arguments);if(O.hasCard(n)){O.removeCard(n);return}let r=t.arguments.command,i=r?`${t.name}: ${r}`:t.name,a=t.result,o={id:n,title:i,content:``,timestamp:Date.now(),toolName:t.name,toolArgs:t.arguments,loading:!0};this.dispatchEvent(new CustomEvent(`pin-card`,{detail:{card:o},bubbles:!0,composed:!0})),setTimeout(()=>{let e=Rt(this.identification,a),t=this.identification.canPinGraph?`text`:e.displayType;O.updateCard(n,{content:e.content,type:t,loading:!1})},0)}async approve(){let e=O.state.sessionId;if(e){O.updateLastToolCall(e=>({...e,pending:!1}));try{await M(e,!0)}catch{}}}async deny(){let e=O.state.sessionId;if(!e)return;let t=this.denyReasonInput.trim()||`denied by user`;this.denyReasonInput=``,O.updateLastToolCall(e=>({...e,pending:!1,denied:!0,denyReason:t}));try{await M(e,!1,t)}catch{}}get hasResultError(){return this.entry.result?Rt(this.identification,this.entry.result).hasError:!1}get statusBadge(){let e=this.entry;return e.denied?a`<span class="badge denied">denied</span>`:e.pending?a`<span class="badge waiting">waiting</span>`:e.result===void 0?a`<span class="badge running">running</span>`:this.hasResultError?a`<span class="badge error">error</span>`:a`<span class="badge done">done</span>`}get iconClass(){let e=this.entry;return e.denied?`denied`:e.pending?`pending`:e.result===void 0?`call`:`result`}get canPin(){let e=this.entry;return!e.result||e.denied?!1:this.identification.canPin}get canPinGraph(){let e=this.entry;if(!e.result||e.denied||!this.identification.canPinGraph)return!1;if(this._graphCacheKey===e.result)return this._graphCacheValue;this._graphCacheKey=e.result;let t=Wt(e.result);return this._graphCacheValue=t!==null&&t.series.length>0,this._graphCacheValue}get pinButton(){return this.canPin?a`
      <button
        class="pin-btn ${this.pinned?`pinned`:``}"
        @click=${this.pinCard}
        title=${this.pinned?`Pinned`:`Pin to detail pane`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="${this.pinned?`currentColor`:`none`}"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="M12 2 L12 12" />
          <path d="M18.5 8.5 C18.5 12 16 14 12 14 C8 14 5.5 12 5.5 8.5" />
          <path d="M12 14 L12 22" />
        </svg>
      </button>
    `:r}pinGraphCard(e){e.stopPropagation();let t=this.entry,n=`graph-${Ut(t.name,t.arguments)}`;if(O.hasCard(n)){O.removeCard(n);return}let r=t.arguments.command,i={id:n,title:r?`${t.name}: ${r}`:t.name,content:t.result,timestamp:Date.now(),toolName:t.name,toolArgs:t.arguments,type:`graph`};this.dispatchEvent(new CustomEvent(`pin-card`,{detail:{card:i},bubbles:!0,composed:!0}))}get graphPinButton(){return this.canPinGraph?a`
      <button
        class="pin-btn ${this.graphPinned?`pinned`:``}"
        @click=${this.pinGraphCard}
        title=${this.graphPinned?`Graph pinned`:`Pin as graph`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="${this.graphPinned?`currentColor`:`none`}"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
        </svg>
      </button>
    `:r}render(){let e=this.entry,t=JSON.stringify(e.arguments,null,2);return a`
      <div class="card">
        <div class="header" @click=${this.toggle}>
          <svg
            class="chevron ${this.expanded?`open`:``}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <svg
            class="icon ${this.iconClass}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path
              d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"
            />
          </svg>
          <span class="name">${e.name}</span>
          ${this.identification.identified?a`<span class="badge category">${this.identification.category}</span>`:r}
          ${this.statusBadge} ${this.graphPinButton} ${this.pinButton}
        </div>

        ${this.expanded?a`
              <div class="body">
                <div class="section-label">Arguments</div>
                <div class="code-block">${t}</div>

                ${e.result===void 0?r:a`
                      <div class="result-section">
                        <div class="section-label">Result</div>
                        <div class="code-block">${e.result}</div>
                      </div>
                    `}
                ${e.denied&&e.denyReason?a`
                      <div class="result-section">
                        <div class="section-label">Denial reason</div>
                        <div class="code-block">${e.denyReason}</div>
                      </div>
                    `:r}
              </div>
            `:r}
        ${e.pending?a`
              <div class="approval-bar">
                <input
                  class="deny-reason-input"
                  type="text"
                  placeholder="Reason for denial (optional)"
                  .value=${this.denyReasonInput}
                  @input=${e=>{this.denyReasonInput=e.target.value}}
                />
                <div class="approval-actions">
                  <span>Approve this tool call?</span>
                  <button class="deny-btn" @click=${this.deny}>Deny</button>
                  <button class="approve-btn" @click=${this.approve}>Approve</button>
                </div>
              </div>
            `:r}
      </div>
    `}},Gt.styles=d`
    :host {
      display: block;
    }

    .card {
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-sm);
      background: var(--bg-tool);
      overflow: hidden;
      font-size: var(--font-size-sm);
    }

    .header {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-tool-header);
      cursor: pointer;
      user-select: none;
      transition: background var(--transition-fast);
    }

    .header:hover {
      background: var(--bg-hover);
    }

    .chevron {
      width: 14px;
      height: 14px;
      color: var(--text-tertiary);
      transition: transform var(--transition-fast);
      flex-shrink: 0;
    }

    .chevron.open {
      transform: rotate(90deg);
    }

    .icon {
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }

    .icon.call {
      color: var(--accent-warning);
    }

    .icon.result {
      color: var(--accent-success);
    }

    .icon.denied {
      color: var(--accent-danger);
    }

    .icon.pending {
      color: var(--accent-info);
    }

    .name {
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .badge {
      font-size: var(--font-size-xs);
      padding: 2px 6px;
      border-radius: var(--radius-full);
      font-weight: var(--font-weight-medium);
      white-space: nowrap;
    }

    .badge.category {
      background: rgba(50, 102, 173, 0.1);
      color: var(--text-tertiary);
      font-family: var(--font-mono);
    }

    .badge.running {
      background: rgba(59, 130, 246, 0.1);
      color: var(--accent-info);
    }

    .badge.done {
      background: rgba(34, 197, 94, 0.1);
      color: var(--accent-success);
    }

    .badge.error,
    .badge.denied {
      background: rgba(239, 68, 68, 0.1);
      color: var(--accent-danger);
    }

    .badge.waiting {
      background: rgba(59, 130, 246, 0.1);
      color: var(--accent-info);
    }

    .body {
      padding: 10px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .section-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 4px;
    }

    .code-block {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      padding: 8px 10px;
      background: var(--bg-code);
      border-radius: var(--radius-xs);
      white-space: pre-wrap;
      word-break: break-all;
      overflow-x: auto;
      max-height: 300px;
      overflow-y: auto;
      color: var(--text-primary);
      line-height: 1.5;
    }

    .result-section {
      margin-top: 10px;
    }

    .approval-bar {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 10px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .deny-reason-input {
      width: 100%;
      box-sizing: border-box;
      padding: 6px 10px;
      font-size: var(--font-size-sm);
      font-family: inherit;
      color: var(--text-primary);
      background: var(--bg-code);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xs);
      outline: none;
      transition: border-color var(--transition-fast);
    }

    .deny-reason-input::placeholder {
      color: var(--text-tertiary);
    }

    .deny-reason-input:focus {
      border-color: var(--accent-info);
    }

    .approval-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .approval-actions span {
      flex: 1;
      font-size: var(--font-size-sm);
      color: var(--text-secondary);
    }

    .approve-btn,
    .deny-btn {
      padding: 6px 14px;
      border-radius: var(--radius-sm);
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .approve-btn {
      background: var(--accent-success);
      color: white;
    }

    .approve-btn:hover {
      filter: brightness(1.1);
    }

    .deny-btn {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      border: 1px solid var(--border-primary);
    }

    .deny-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-danger);
    }

    .pin-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 24px;
      height: 24px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .pin-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .pin-btn.pinned {
      color: var(--accent-primary);
    }

    .pin-btn svg {
      width: 14px;
      height: 14px;
    }
  `,Gt);N([n({type:Object})],Kt.prototype,`entry`,void 0),N([n({type:String})],Kt.prototype,`sessionId`,void 0),N([i()],Kt.prototype,`expanded`,void 0),N([i()],Kt.prototype,`pinned`,void 0),N([i()],Kt.prototype,`graphPinned`,void 0),N([i()],Kt.prototype,`denyReasonInput`,void 0),Kt=N([s(`tool-call-card`)],Kt);var qt,Jt=[{value:`auto-accept`,label:`Accept`},{value:`ask`,label:`Ask`},{value:`auto-reject`,label:`Reject`}],Yt=(qt=class extends l{constructor(...e){super(...e),this.tools=[],this.policies={}}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.tools=O.state.availableTools,this.policies=O.state.toolPolicies}),this.tools=O.state.availableTools,this.policies=O.state.toolPolicies}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}setPolicy(e,t){O.setToolPolicy(e,t)}setAll(e){O.setAllToolPolicies(e)}get allPolicy(){let e=Object.values(this.policies);if(e.length===0)return null;let t=e[0];return e.every(e=>e===t)?t:null}render(){if(!this.tools.length)return a`<div class="empty">No tools available</div>`;let e=this.allPolicy;return a`
      <div class="bulk-actions">
        ${Jt.map(t=>a`
            <button
              class="bulk-btn ${e===t.value?`active`:``}"
              @click=${()=>this.setAll(t.value)}
            >
              All ${t.label}
            </button>
          `)}
      </div>
      <div class="tool-list">
        ${this.tools.map(e=>{let t=this.policies[e.name]??fe(e.name);return a`
            <div class="tool-row">
              <div class="tool-name-wrap">
                <div class="tool-name">${e.name}</div>
                ${e.description?a`<div class="tool-tip">${e.description}</div>`:r}
              </div>
              <div class="policy-toggle">
                ${Jt.map(n=>a`
                    <button
                      class="policy-btn ${t===n.value?`selected-${n.value}`:``}"
                      @click=${()=>this.setPolicy(e.name,n.value)}
                      title=${n.label}
                    >
                      ${n.label}
                    </button>
                  `)}
              </div>
            </div>
          `})}
      </div>
    `}},qt.styles=d`
    :host {
      display: block;
    }

    .bulk-actions {
      display: flex;
      gap: 6px;
      margin-bottom: 8px;
    }

    .bulk-btn {
      padding: 3px 10px;
      border-radius: var(--radius-full);
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-medium);
      border: 1px solid var(--border-primary);
      background: var(--bg-primary);
      color: var(--text-secondary);
      cursor: pointer;
      transition: all var(--transition-fast);
    }

    .bulk-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .bulk-btn.active {
      background: var(--accent-primary);
      color: var(--text-inverse);
      border-color: var(--accent-primary);
    }

    .tool-list {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .tool-row {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 0;
    }

    .tool-name-wrap {
      flex: 1;
      min-width: 0;
      position: relative;
    }

    .tool-name {
      font-size: var(--font-size-xs);
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: default;
    }

    .tool-tip {
      display: none;
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      z-index: 100;
      max-width: 280px;
      padding: 6px 10px;
      border-radius: var(--radius-sm);
      background: var(--bg-tertiary);
      border: 1px solid var(--border-primary);
      color: var(--text-secondary);
      font-size: var(--font-size-xs);
      line-height: 1.4;
      white-space: normal;
      word-wrap: break-word;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      pointer-events: none;
    }

    .tool-name-wrap:hover .tool-tip {
      display: block;
    }

    .policy-toggle {
      display: flex;
      border-radius: var(--radius-full);
      border: 1px solid var(--border-primary);
      overflow: hidden;
      flex-shrink: 0;
    }

    .policy-btn {
      padding: 2px 8px;
      font-size: 10px;
      font-weight: var(--font-weight-medium);
      border: none;
      background: var(--bg-primary);
      color: var(--text-tertiary);
      cursor: pointer;
      transition: all var(--transition-fast);
      line-height: 1.4;
    }

    .policy-btn:not(:last-child) {
      border-right: 1px solid var(--border-primary);
    }

    .policy-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .policy-btn.selected-auto-accept {
      background: var(--accent-success);
      color: white;
    }

    .policy-btn.selected-ask {
      background: var(--accent-info);
      color: white;
    }

    .policy-btn.selected-auto-reject {
      background: var(--accent-danger);
      color: white;
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `,qt);N([i()],Yt.prototype,`tools`,void 0),N([i()],Yt.prototype,`policies`,void 0),Yt=N([s(`tool-policy-editor`)],Yt);var Xt,Zt=(Xt=class extends l{render(){return a`
      <div class="dots">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
      </div>
      <span class="label">Thinking...</span>
    `}},Xt.styles=d`
    :host {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 12px 0;
    }

    .dots {
      display: flex;
      gap: 4px;
    }

    .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--accent-primary);
      opacity: 0.3;
      animation: pulse 1.4s ease-in-out infinite;
    }

    .dot:nth-child(2) {
      animation-delay: 0.2s;
    }

    .dot:nth-child(3) {
      animation-delay: 0.4s;
    }

    @keyframes pulse {
      0%,
      80%,
      100% {
        opacity: 0.3;
        transform: scale(0.8);
      }
      40% {
        opacity: 1;
        transform: scale(1);
      }
    }

    .label {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
    }
  `,Xt);Zt=N([s(`thinking-indicator`)],Zt);var Qt;T.registerLanguage(`bash`,b),T.registerLanguage(`sh`,b),T.registerLanguage(`shell`,b),T.registerLanguage(`javascript`,y),T.registerLanguage(`js`,y),T.registerLanguage(`typescript`,te),T.registerLanguage(`ts`,te),T.registerLanguage(`python`,S),T.registerLanguage(`py`,S),T.registerLanguage(`json`,v),T.registerLanguage(`yaml`,D),T.registerLanguage(`yml`,D),T.registerLanguage(`xml`,w),T.registerLanguage(`html`,w),T.registerLanguage(`css`,_),T.registerLanguage(`sql`,x),T.registerLanguage(`markdown`,E),T.registerLanguage(`md`,E),T.registerLanguage(`go`,C),T.registerLanguage(`rust`,ee);var $t=new h(m({langPrefix:`hljs language-`,highlight(e,t){if(t&&T.getLanguage(t))try{return T.highlight(e,{language:t}).value}catch{}return T.highlightAuto(e).value}}));$t.setOptions({breaks:!0,gfm:!0});var en=(Qt=class extends l{constructor(...e){super(...e),this.content=``,this._cacheKey=``,this._cacheHtml=``}renderMarkdown(){if(!this.content)return``;if(this._cacheKey===this.content)return this._cacheHtml;this._cacheKey=this.content;let e=$t.parse(this.content);return this._cacheHtml=g.sanitize(e),this._cacheHtml}render(){return a`<div class="md">${u(this.renderMarkdown())}</div>`}},Qt.styles=d`
    :host {
      display: block;
      line-height: var(--line-height);
      color: var(--text-primary);
      word-wrap: break-word;
      overflow-wrap: break-word;
    }

    .md h1,
    .md h2,
    .md h3,
    .md h4 {
      margin-top: 1.2em;
      margin-bottom: 0.4em;
      font-weight: var(--font-weight-bold);
      line-height: 1.3;
    }

    .md h1 {
      font-size: var(--md-h1-size, 1.5em);
    }
    .md h2 {
      font-size: var(--md-h2-size, 1.3em);
    }
    .md h3 {
      font-size: var(--md-h3-size, 1.15em);
    }
    .md h4 {
      font-size: var(--md-h4-size, 1em);
    }

    .md h1:first-child,
    .md h2:first-child,
    .md h3:first-child {
      margin-top: 0;
    }

    .md p {
      margin: 0.6em 0;
    }

    .md p:first-child {
      margin-top: 0;
    }

    .md p:last-child {
      margin-bottom: 0;
    }

    .md ul,
    .md ol {
      margin: 0.6em 0;
      padding-left: 1.5em;
    }

    .md li {
      margin: 0.2em 0;
    }

    .md code {
      font-family: var(--font-mono);
      font-size: 0.9em;
      padding: 0.15em 0.4em;
      border-radius: var(--radius-xs);
      background: var(--bg-code);
      color: var(--text-code);
    }

    .md pre {
      margin: 0.8em 0;
      padding: 14px 16px;
      border-radius: var(--radius-sm);
      background: var(--bg-code);
      overflow-x: auto;
      font-size: 0.88em;
      line-height: 1.5;
    }

    .md pre code {
      padding: 0;
      background: none;
      color: var(--text-primary);
      font-size: inherit;
    }

    .md blockquote {
      margin: 0.8em 0;
      padding: 0.4em 1em;
      border-left: 3px solid var(--accent-primary);
      color: var(--text-secondary);
      background: var(--bg-tertiary);
      border-radius: 0 var(--radius-xs) var(--radius-xs) 0;
    }

    .md table {
      width: 100%;
      border-collapse: collapse;
      margin: 0.8em 0;
      font-size: var(--font-size-sm);
    }

    .md th,
    .md td {
      padding: 8px 12px;
      text-align: left;
      border-bottom: 1px solid var(--border-secondary);
    }

    .md th {
      font-weight: var(--font-weight-bold);
      color: var(--text-secondary);
      border-bottom-color: var(--border-primary);
    }

    .md a {
      color: var(--accent-info);
      text-decoration: none;
    }

    .md a:hover {
      text-decoration: underline;
    }

    .md hr {
      margin: 1.2em 0;
      border: none;
      border-top: 1px solid var(--border-secondary);
    }

    .md img {
      max-width: 100%;
      border-radius: var(--radius-sm);
    }

    /* highlight.js theme integration */
    .md .hljs-keyword,
    .md .hljs-selector-tag,
    .md .hljs-built_in,
    .md .hljs-name,
    .md .hljs-tag {
      color: var(--accent-primary);
    }
    .md .hljs-string,
    .md .hljs-title,
    .md .hljs-section,
    .md .hljs-attribute,
    .md .hljs-literal,
    .md .hljs-template-tag,
    .md .hljs-template-variable,
    .md .hljs-type,
    .md .hljs-addition {
      color: var(--accent-success);
    }
    .md .hljs-comment,
    .md .hljs-quote,
    .md .hljs-deletion,
    .md .hljs-meta {
      color: var(--text-tertiary);
    }
    .md .hljs-number,
    .md .hljs-regexp,
    .md .hljs-literal,
    .md .hljs-bullet,
    .md .hljs-link {
      color: var(--accent-info);
    }
    .md .hljs-emphasis {
      font-style: italic;
    }
    .md .hljs-strong {
      font-weight: var(--font-weight-bold);
    }
  `,Qt);N([n({type:String})],en.prototype,`content`,void 0),en=N([s(`markdown-renderer`)],en);var tn=d`
  :host {
    display: block;
  }

  .chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }

  .chip {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    border-radius: var(--radius-full);
    font-size: var(--font-size-xs);
    border: 1px solid var(--border-primary);
    background: var(--bg-primary);
    color: var(--text-secondary);
    cursor: pointer;
    transition: all var(--transition-fast);
    white-space: nowrap;
  }

  .chip:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
  }

  .chip.active {
    background: var(--accent-primary);
    color: var(--text-inverse);
    border-color: var(--accent-primary);
  }

  .chip.active:hover {
    background: var(--accent-hover);
  }

  .chip:disabled {
    opacity: 0.5;
    cursor: wait;
  }

  .chip .dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
    opacity: 0.6;
  }

  .empty {
    font-size: var(--font-size-sm);
    color: var(--text-tertiary);
    padding: 4px 0;
  }
`,nn,rn=(nn=class extends l{constructor(...e){super(...e),this.available=[],this.active=[]}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.available=O.state.availableSkills,this.active=O.state.activeSkills}),this.available=O.state.availableSkills,this.active=O.state.activeSkills}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}toggle(e){O.toggleSkill(e)}render(){return this.available.length?a`
      <div class="chips">
        ${this.available.map(e=>{let t=this.active.includes(e.name);return a`
            <button
              class="chip ${t?`active`:``}"
              @click=${()=>this.toggle(e.name)}
              title=${e.description}
            >
              ${t?a`<span class="dot"></span>`:``} ${e.name}
            </button>
          `})}
      </div>
    `:a`<div class="empty">No skills loaded</div>`}},nn.styles=tn,nn);N([i()],rn.prototype,`available`,void 0),N([i()],rn.prototype,`active`,void 0),rn=N([s(`skill-selector`)],rn);var an,on=(an=class extends l{constructor(...e){super(...e),this.context={},this.newKey=``,this.newValue=``}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.context=O.state.context}),this.context=O.state.context}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}removeKey(e){O.removeContext(e)}add(){let e=this.newKey.trim(),t=this.newValue.trim();!e||!t||(O.setContext(e,t),this.newKey=``,this.newValue=``)}onKeyDown(e){e.key===`Enter`&&this.add()}render(){let e=Object.entries(this.context);return a`
      ${e.length?a`
            <div class="entries">
              ${e.map(([e,t])=>a`
                  <div class="entry">
                    <span class="entry-key">${e}</span>
                    <span class="entry-value">${t}</span>
                    <button
                      class="remove-btn"
                      @click=${()=>this.removeKey(e)}
                      title="Remove ${e}"
                    >
                      <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <line x1="18" y1="6" x2="6" y2="18" />
                        <line x1="6" y1="6" x2="18" y2="18" />
                      </svg>
                    </button>
                  </div>
                `)}
            </div>
          `:a`<div class="empty">No context set</div>`}

      <div class="add-row">
        <input
          type="text"
          placeholder="key"
          .value=${this.newKey}
          @input=${e=>this.newKey=e.target.value}
          @keydown=${this.onKeyDown}
        />
        <input
          type="text"
          placeholder="value"
          .value=${this.newValue}
          @input=${e=>this.newValue=e.target.value}
          @keydown=${this.onKeyDown}
        />
        <button class="add-btn" @click=${this.add}>Add</button>
      </div>
    `}},an.styles=d`
    :host {
      display: block;
    }

    .entries {
      display: flex;
      flex-direction: column;
      gap: 4px;
      margin-bottom: 8px;
    }

    .entry {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: var(--font-size-sm);
      padding: 4px 8px;
      border-radius: var(--radius-xs);
      background: var(--bg-tertiary);
    }

    .entry-key {
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
    }

    .entry-value {
      color: var(--text-secondary);
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .remove-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      border: none;
      background: none;
      border-radius: var(--radius-xs);
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        color var(--transition-fast),
        background var(--transition-fast);
    }

    .remove-btn:hover {
      color: var(--accent-danger);
      background: var(--bg-hover);
    }

    .remove-btn svg {
      width: 12px;
      height: 12px;
    }

    .add-row {
      display: flex;
      gap: 6px;
    }

    .add-row input {
      flex: 1;
      padding: 6px 8px;
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xs);
      background: var(--bg-input);
      font-size: var(--font-size-sm);
      min-width: 0;
    }

    .add-row input::placeholder {
      color: var(--text-tertiary);
    }

    .add-btn {
      padding: 6px 10px;
      border: none;
      border-radius: var(--radius-xs);
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      font-size: var(--font-size-sm);
      cursor: pointer;
      white-space: nowrap;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
    }

    .add-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `,an);N([i()],on.prototype,`context`,void 0),N([i()],on.prototype,`newKey`,void 0),N([i()],on.prototype,`newValue`,void 0),on=N([s(`context-editor`)],on);var sn,cn=(sn=class extends l{constructor(...e){super(...e),this.models=[],this.current=``}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.models=O.state.availableModels,this.current=O.state.model}),this.models=O.state.availableModels,this.current=O.state.model}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}async onChange(e){let t=e.target.value;if(!(!t||t===this.current))try{let e=await j(t);O.update({model:e.model,contextWindow:e.context_window})}catch(e){O.update({error:e.message})}}render(){return this.models.length?a`
      <select .value=${this.current} @change=${this.onChange}>
        ${this.models.map(e=>a`<option value=${e} ?selected=${e===this.current}>${e}</option>`)}
      </select>
    `:a`<div class="empty">No models available</div>`}},sn.styles=d`
    :host {
      display: block;
    }

    select {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-sm);
      background: var(--bg-input);
      color: var(--text-primary);
      font-size: var(--font-size-sm);
      cursor: pointer;
      appearance: auto;
    }

    select:focus {
      outline: 2px solid var(--accent-primary);
      outline-offset: -1px;
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `,sn);N([i()],cn.prototype,`models`,void 0),N([i()],cn.prototype,`current`,void 0),cn=N([s(`model-selector`)],cn);var ln,un=(ln=class extends l{constructor(...e){super(...e),this.servers=[],this.busy=!1}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.servers=O.state.mcpServers}),this.servers=O.state.mcpServers}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}async toggle(e){if(!this.busy){this.busy=!0;try{let t=e.connected?await be(e.name):await ye(e.name);O.update({mcpServers:t.servers,toolCount:t.tools});let n=[...await he(),...de],r=O.state.toolPolicies,i={};for(let e of n)i[e.name]=r[e.name]??fe(e.name);O.update({availableTools:n,toolPolicies:i})}catch(e){O.update({error:e.message})}finally{this.busy=!1}}}render(){return this.servers.length?a`
      <div class="chips">
        ${this.servers.map(e=>a`
            <button
              class="chip ${e.connected?`active`:``}"
              ?disabled=${this.busy}
              @click=${()=>this.toggle(e)}
              title=${e.url}
            >
              ${e.connected?a`<span class="dot"></span>`:``} ${e.name}
            </button>
          `)}
      </div>
    `:a`<div class="empty">No MCP servers configured</div>`}},ln.styles=tn,ln);N([i()],un.prototype,`servers`,void 0),N([i()],un.prototype,`busy`,void 0),un=N([s(`mcp-manager`)],un);var dn,fn=(dn=class extends l{constructor(...e){super(...e),this.open=!1,this.currentTheme=ue.name,this.outsideClickHandler=e=>{this.open&&(e.composedPath().includes(this)||(this.open=!1))},this.swatchColors={light:[`#FAF9F5`,`#AE5630`],dark:[`#1A1918`,`#D4703C`],"rh-light":[`#ffffff`,`#a60000`],"rh-dark":[`#151515`,`#f56e6e`]}}connectedCallback(){super.connectedCallback(),document.addEventListener(`click`,this.outsideClickHandler,!0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`click`,this.outsideClickHandler,!0)}toggleDropdown(){this.open=!this.open}selectTheme(e){ue.setTheme(e),this.currentTheme=ue.name,this.open=!1,this.dispatchEvent(new CustomEvent(`theme-changed`,{detail:{theme:ue.name},bubbles:!0,composed:!0}))}render(){let e=ue.isDark,t=ue.themes;return a`
      <button
        class="trigger"
        @click=${this.toggleDropdown}
        title="Change theme"
        aria-label="Change theme"
        aria-expanded=${this.open}
      >
        ${e?a`<svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <circle cx="12" cy="12" r="5" />
              <line x1="12" y1="1" x2="12" y2="3" />
              <line x1="12" y1="21" x2="12" y2="23" />
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
              <line x1="1" y1="12" x2="3" y2="12" />
              <line x1="21" y1="12" x2="23" y2="12" />
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
            </svg>`:a`<svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
            </svg>`}
      </button>

      <div class="dropdown ${this.open?`open`:``}">
        ${t.map(e=>a`
            <button
              class=${e.id===this.currentTheme?`active`:``}
              @click=${()=>this.selectTheme(e.id)}
            >
              <span
                class="swatch"
                style="background: linear-gradient(135deg, ${this.swatchColors[e.id]?.[0]??`#888`} 50%, ${this.swatchColors[e.id]?.[1]??`#444`} 50%)"
              ></span>
              ${e.label}
              <span class="check">&#10003;</span>
            </button>
          `)}
      </div>
    `}},dn.styles=d`
    :host {
      display: inline-flex;
      position: relative;
    }

    button.trigger {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: var(--radius-sm);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      cursor: pointer;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
    }

    button.trigger:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    svg {
      width: 18px;
      height: 18px;
    }

    .dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      margin-top: 4px;
      min-width: 160px;
      background: var(--bg-input);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-sm);
      box-shadow: var(--shadow-md);
      z-index: 200;
      padding: 4px;
      opacity: 0;
      transform: translateY(-4px);
      pointer-events: none;
      transition:
        opacity var(--transition-fast),
        transform var(--transition-fast);
    }

    .dropdown.open {
      opacity: 1;
      transform: translateY(0);
      pointer-events: auto;
    }

    .dropdown button {
      display: flex;
      align-items: center;
      gap: 8px;
      width: 100%;
      padding: 8px 10px;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-primary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .dropdown button:hover {
      background: var(--bg-hover);
    }

    .dropdown button.active {
      background: var(--bg-tertiary);
      font-weight: var(--font-weight-medium);
    }

    .swatch {
      width: 14px;
      height: 14px;
      border-radius: var(--radius-xs);
      border: 1px solid var(--border-primary);
      flex-shrink: 0;
    }

    .check {
      margin-left: auto;
      font-size: 13px;
      opacity: 0;
    }

    .active .check {
      opacity: 1;
    }
  `,dn);N([i()],fn.prototype,`open`,void 0),N([i()],fn.prototype,`currentTheme`,void 0),fn=N([s(`theme-picker`)],fn);var pn,mn=(pn=class extends l{constructor(...e){super(...e),this.sidebarOpen=O.state.sidebarOpen}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.sidebarOpen=O.state.sidebarOpen})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}toggleSidebar(){O.update({sidebarOpen:!this.sidebarOpen})}render(){return a`
      <button
        class="toggle-btn"
        @click=${this.toggleSidebar}
        title=${this.sidebarOpen?`Close sidebar`:`Open sidebar`}
        aria-label=${this.sidebarOpen?`Close sidebar`:`Open sidebar`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <line x1="3" y1="6" x2="21" y2="6" />
          <line x1="3" y1="12" x2="21" y2="12" />
          <line x1="3" y1="18" x2="21" y2="18" />
        </svg>
      </button>

      <div class="brand">
        <svg class="hat-icon" viewBox="0 0 136 103" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="m 90.6538,59.2537 c 8.9312,0 21.8512,-1.8412 21.8512,-12.4662 0.029,-0.82 -0.045,-1.64 -0.22,-2.4413 l -5.3175,-23.1 C 105.7363,16.1575 104.6575,13.8525 95.7363,9.39 88.8075,5.85 73.725,0 69.2625,0 65.1075,0 63.9013,5.3575 58.945,5.3575 c -4.7712,0 -8.3112,-4 -12.7737,-4 -4.2825,0 -7.075,2.92 -9.2338,8.9262 0,0 -6,16.9338 -6.7725,19.39 -0.1262,0.4538 -0.18,0.9175 -0.16,1.3863 0,6.5825 25.9175,28.1687 60.6488,28.1687 m 23.2225,-8.125 c 1.235,5.845 1.235,6.46 1.235,7.2313 0,9.995 -11.235,15.5425 -26.01,15.5425 -33.3838,0.02 -62.6275,-19.5413 -62.6275,-32.4713 0,-1.8012 0.3612,-3.5837 1.075,-5.2337 C 15.5413,36.7725 0,38.9162 0,52.6375 c 0,22.475 53.2513,50.175 95.42,50.175 32.3288,0 40.4825,-14.6188 40.4825,-26.1663 0,-9.0825 -7.8512,-19.39 -22.0112,-25.5425"
            fill="var(--hat-color)"
          />
          <path
            d="m 113.8763,51.1037 c 1.235,5.845 1.235,6.46 1.235,7.2313 0,9.995 -11.235,15.5425 -26.01,15.5425 -33.3838,0.02 -62.6275,-19.5413 -62.6275,-32.4713 0,-1.8012 0.3612,-3.5837 1.075,-5.2337 l 2.6162,-6.47 c -0.1212,0.445 -0.175,0.8987 -0.16,1.3575 0,6.5825 25.9175,28.1687 60.6488,28.1687 8.9312,0 21.8512,-1.845 21.8512,-12.47 0.029,-0.8162 -0.045,-1.6362 -0.22,-2.4412 l 1.5913,6.7862 z"
            fill="rgba(0,0,0,0.2)"
          />
        </svg>
        <span class="title">Forklift</span>
      </div>

      <div class="spacer"></div>

      <theme-picker></theme-picker>
    `}},pn.styles=d`
    :host {
      display: flex;
      align-items: center;
      height: var(--topbar-height);
      min-height: var(--topbar-height);
      padding: 0 12px;
      background: var(--bg-sidebar);
      border-bottom: none;
      gap: 8px;
    }

    .toggle-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: var(--radius-sm);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      cursor: pointer;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
      flex-shrink: 0;
    }

    .toggle-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .toggle-btn svg {
      width: 18px;
      height: 18px;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .hat-icon {
      width: 28px;
      height: 22px;
      flex-shrink: 0;
    }

    .title {
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-bold);
      color: var(--text-primary);
      white-space: nowrap;
    }

    .spacer {
      flex: 1;
    }
  `,pn);N([i()],mn.prototype,`sidebarOpen`,void 0),mn=N([s(`top-bar`)],mn);var hn,gn=(hn=class extends l{constructor(...e){super(...e),this.startX=0,this.onMouseDown=e=>{e.preventDefault(),this.startX=e.clientX,this.setAttribute(`active`,``),document.addEventListener(`mousemove`,this.onMouseMove),document.addEventListener(`mouseup`,this.onMouseUp)},this.onMouseMove=e=>{this.emitResize(e.clientX-this.startX)},this.onMouseUp=()=>{this.removeAttribute(`active`),document.removeEventListener(`mousemove`,this.onMouseMove),document.removeEventListener(`mouseup`,this.onMouseUp),this.emitResizeEnd()}}emitResize(e){this.dispatchEvent(new CustomEvent(`handle-resize`,{detail:{delta:e},bubbles:!0,composed:!0}))}emitResizeEnd(){this.dispatchEvent(new CustomEvent(`resize-end`,{bubbles:!0,composed:!0}))}render(){return a`<div class="overlay"></div>`}connectedCallback(){super.connectedCallback(),this.addEventListener(`mousedown`,this.onMouseDown)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(`mousedown`,this.onMouseDown),document.removeEventListener(`mousemove`,this.onMouseMove),document.removeEventListener(`mouseup`,this.onMouseUp)}},hn.styles=d`
    :host {
      display: block;
      width: 4px;
      min-width: 4px;
      cursor: col-resize;
      background: var(--border-secondary);
      transition: background var(--transition-fast);
      position: relative;
      z-index: 2;
    }

    :host(:hover),
    :host([active]) {
      background: var(--accent-primary);
    }

    .overlay {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 9999;
      cursor: col-resize;
    }

    :host([active]) .overlay {
      display: block;
    }
  `,hn);gn=N([s(`resize-handle`)],gn);var _n,vn=(_n=class extends l{constructor(...e){super(...e),this.matchCount=0,this.activeIndex=-1}firstUpdated(){this.input?.focus()}onInput(e){let t=e.target.value;this.emit(`search-input`,t)}onKeyDown(e){e.key===`Escape`?this.emit(`search-close`):e.key===`Enter`&&(e.shiftKey?this.emit(`search-prev`):this.emit(`search-next`))}emit(e,t){this.dispatchEvent(new CustomEvent(e,{detail:t,bubbles:!0,composed:!0}))}get countLabel(){return this.matchCount===0?r:a`<span class="count">${this.activeIndex+1} / ${this.matchCount}</span>`}render(){let e=this.matchCount===0;return a`
      <input
        type="text"
        placeholder="Search…"
        spellcheck="false"
        @input=${this.onInput}
        @keydown=${this.onKeyDown}
      />
      ${this.countLabel}
      <button
        class="nav-btn"
        title="Previous (Shift+Enter)"
        ?disabled=${e}
        @click=${()=>this.emit(`search-prev`)}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="18 15 12 9 6 15" />
        </svg>
      </button>
      <button
        class="nav-btn"
        title="Next (Enter)"
        ?disabled=${e}
        @click=${()=>this.emit(`search-next`)}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
    `}},_n.styles=d`
    :host {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 12px;
      background: var(--bg-tertiary);
      border-top: 1px solid var(--border-secondary);
    }

    input {
      flex: 1;
      min-width: 0;
      padding: 3px 8px;
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-xs);
      background: var(--bg-input, var(--bg-primary));
      color: var(--text-primary);
      font-family: inherit;
      font-size: var(--font-size-xs);
      outline: none;
      transition: border-color var(--transition-fast);
    }

    input:focus {
      border-color: var(--accent-primary);
    }

    .count {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      white-space: nowrap;
      min-width: 40px;
      text-align: center;
      font-variant-numeric: tabular-nums;
    }

    .nav-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .nav-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .nav-btn:disabled {
      opacity: 0.3;
      cursor: default;
    }

    .nav-btn svg {
      width: 12px;
      height: 12px;
    }
  `,_n);N([n({type:Number})],vn.prototype,`matchCount`,void 0),N([n({type:Number})],vn.prototype,`activeIndex`,void 0),N([c(`input`)],vn.prototype,`input`,void 0),vn=N([s(`card-search-bar`)],vn);function yn(e){return e+.5|0}var bn=(e,t,n)=>Math.max(Math.min(e,n),t);function xn(e){return bn(yn(e*2.55),0,255)}function Sn(e){return bn(yn(e*255),0,255)}function Cn(e){return bn(yn(e/2.55)/100,0,1)}function wn(e){return bn(yn(e*100),0,100)}var Tn={0:0,1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,A:10,B:11,C:12,D:13,E:14,F:15,a:10,b:11,c:12,d:13,e:14,f:15},En=[...`0123456789ABCDEF`],Dn=e=>En[e&15],On=e=>En[(e&240)>>4]+En[e&15],kn=e=>(e&240)>>4==(e&15),An=e=>kn(e.r)&&kn(e.g)&&kn(e.b)&&kn(e.a);function jn(e){var t=e.length,n;return e[0]===`#`&&(t===4||t===5?n={r:255&Tn[e[1]]*17,g:255&Tn[e[2]]*17,b:255&Tn[e[3]]*17,a:t===5?Tn[e[4]]*17:255}:(t===7||t===9)&&(n={r:Tn[e[1]]<<4|Tn[e[2]],g:Tn[e[3]]<<4|Tn[e[4]],b:Tn[e[5]]<<4|Tn[e[6]],a:t===9?Tn[e[7]]<<4|Tn[e[8]]:255})),n}var Mn=(e,t)=>e<255?t(e):``;function Nn(e){var t=An(e)?Dn:On;return e?`#`+t(e.r)+t(e.g)+t(e.b)+Mn(e.a,t):void 0}var Pn=/^(hsla?|hwb|hsv)\(\s*([-+.e\d]+)(?:deg)?[\s,]+([-+.e\d]+)%[\s,]+([-+.e\d]+)%(?:[\s,]+([-+.e\d]+)(%)?)?\s*\)$/;function Fn(e,t,n){let r=t*Math.min(n,1-n),i=(t,i=(t+e/30)%12)=>n-r*Math.max(Math.min(i-3,9-i,1),-1);return[i(0),i(8),i(4)]}function In(e,t,n){let r=(r,i=(r+e/60)%6)=>n-n*t*Math.max(Math.min(i,4-i,1),0);return[r(5),r(3),r(1)]}function Ln(e,t,n){let r=Fn(e,1,.5),i;for(t+n>1&&(i=1/(t+n),t*=i,n*=i),i=0;i<3;i++)r[i]*=1-t-n,r[i]+=t;return r}function Rn(e,t,n,r,i){return e===i?(t-n)/r+(t<n?6:0):t===i?(n-e)/r+2:(e-t)/r+4}function zn(e){let t=e.r/255,n=e.g/255,r=e.b/255,i=Math.max(t,n,r),a=Math.min(t,n,r),o=(i+a)/2,s,c,l;return i!==a&&(l=i-a,c=o>.5?l/(2-i-a):l/(i+a),s=Rn(t,n,r,l,i),s=s*60+.5),[s|0,c||0,o]}function Bn(e,t,n,r){return(Array.isArray(t)?e(t[0],t[1],t[2]):e(t,n,r)).map(Sn)}function Vn(e,t,n){return Bn(Fn,e,t,n)}function Hn(e,t,n){return Bn(Ln,e,t,n)}function Un(e,t,n){return Bn(In,e,t,n)}function Wn(e){return(e%360+360)%360}function Gn(e){let t=Pn.exec(e),n=255,r;if(!t)return;t[5]!==r&&(n=t[6]?xn(+t[5]):Sn(+t[5]));let i=Wn(+t[2]),a=t[3]/100,o=t[4]/100;return r=t[1]===`hwb`?Hn(i,a,o):t[1]===`hsv`?Un(i,a,o):Vn(i,a,o),{r:r[0],g:r[1],b:r[2],a:n}}function Kn(e,t){var n=zn(e);n[0]=Wn(n[0]+t),n=Vn(n),e.r=n[0],e.g=n[1],e.b=n[2]}function qn(e){if(!e)return;let t=zn(e),n=t[0],r=wn(t[1]),i=wn(t[2]);return e.a<255?`hsla(${n}, ${r}%, ${i}%, ${Cn(e.a)})`:`hsl(${n}, ${r}%, ${i}%)`}var Jn={x:`dark`,Z:`light`,Y:`re`,X:`blu`,W:`gr`,V:`medium`,U:`slate`,A:`ee`,T:`ol`,S:`or`,B:`ra`,C:`lateg`,D:`ights`,R:`in`,Q:`turquois`,E:`hi`,P:`ro`,O:`al`,N:`le`,M:`de`,L:`yello`,F:`en`,K:`ch`,G:`arks`,H:`ea`,I:`ightg`,J:`wh`},Yn={OiceXe:`f0f8ff`,antiquewEte:`faebd7`,aqua:`ffff`,aquamarRe:`7fffd4`,azuY:`f0ffff`,beige:`f5f5dc`,bisque:`ffe4c4`,black:`0`,blanKedOmond:`ffebcd`,Xe:`ff`,XeviTet:`8a2be2`,bPwn:`a52a2a`,burlywood:`deb887`,caMtXe:`5f9ea0`,KartYuse:`7fff00`,KocTate:`d2691e`,cSO:`ff7f50`,cSnflowerXe:`6495ed`,cSnsilk:`fff8dc`,crimson:`dc143c`,cyan:`ffff`,xXe:`8b`,xcyan:`8b8b`,xgTMnPd:`b8860b`,xWay:`a9a9a9`,xgYF:`6400`,xgYy:`a9a9a9`,xkhaki:`bdb76b`,xmagFta:`8b008b`,xTivegYF:`556b2f`,xSange:`ff8c00`,xScEd:`9932cc`,xYd:`8b0000`,xsOmon:`e9967a`,xsHgYF:`8fbc8f`,xUXe:`483d8b`,xUWay:`2f4f4f`,xUgYy:`2f4f4f`,xQe:`ced1`,xviTet:`9400d3`,dAppRk:`ff1493`,dApskyXe:`bfff`,dimWay:`696969`,dimgYy:`696969`,dodgerXe:`1e90ff`,fiYbrick:`b22222`,flSOwEte:`fffaf0`,foYstWAn:`228b22`,fuKsia:`ff00ff`,gaRsbSo:`dcdcdc`,ghostwEte:`f8f8ff`,gTd:`ffd700`,gTMnPd:`daa520`,Way:`808080`,gYF:`8000`,gYFLw:`adff2f`,gYy:`808080`,honeyMw:`f0fff0`,hotpRk:`ff69b4`,RdianYd:`cd5c5c`,Rdigo:`4b0082`,ivSy:`fffff0`,khaki:`f0e68c`,lavFMr:`e6e6fa`,lavFMrXsh:`fff0f5`,lawngYF:`7cfc00`,NmoncEffon:`fffacd`,ZXe:`add8e6`,ZcSO:`f08080`,Zcyan:`e0ffff`,ZgTMnPdLw:`fafad2`,ZWay:`d3d3d3`,ZgYF:`90ee90`,ZgYy:`d3d3d3`,ZpRk:`ffb6c1`,ZsOmon:`ffa07a`,ZsHgYF:`20b2aa`,ZskyXe:`87cefa`,ZUWay:`778899`,ZUgYy:`778899`,ZstAlXe:`b0c4de`,ZLw:`ffffe0`,lime:`ff00`,limegYF:`32cd32`,lRF:`faf0e6`,magFta:`ff00ff`,maPon:`800000`,VaquamarRe:`66cdaa`,VXe:`cd`,VScEd:`ba55d3`,VpurpN:`9370db`,VsHgYF:`3cb371`,VUXe:`7b68ee`,VsprRggYF:`fa9a`,VQe:`48d1cc`,VviTetYd:`c71585`,midnightXe:`191970`,mRtcYam:`f5fffa`,mistyPse:`ffe4e1`,moccasR:`ffe4b5`,navajowEte:`ffdead`,navy:`80`,Tdlace:`fdf5e6`,Tive:`808000`,TivedBb:`6b8e23`,Sange:`ffa500`,SangeYd:`ff4500`,ScEd:`da70d6`,pOegTMnPd:`eee8aa`,pOegYF:`98fb98`,pOeQe:`afeeee`,pOeviTetYd:`db7093`,papayawEp:`ffefd5`,pHKpuff:`ffdab9`,peru:`cd853f`,pRk:`ffc0cb`,plum:`dda0dd`,powMrXe:`b0e0e6`,purpN:`800080`,YbeccapurpN:`663399`,Yd:`ff0000`,Psybrown:`bc8f8f`,PyOXe:`4169e1`,saddNbPwn:`8b4513`,sOmon:`fa8072`,sandybPwn:`f4a460`,sHgYF:`2e8b57`,sHshell:`fff5ee`,siFna:`a0522d`,silver:`c0c0c0`,skyXe:`87ceeb`,UXe:`6a5acd`,UWay:`708090`,UgYy:`708090`,snow:`fffafa`,sprRggYF:`ff7f`,stAlXe:`4682b4`,tan:`d2b48c`,teO:`8080`,tEstN:`d8bfd8`,tomato:`ff6347`,Qe:`40e0d0`,viTet:`ee82ee`,JHt:`f5deb3`,wEte:`ffffff`,wEtesmoke:`f5f5f5`,Lw:`ffff00`,LwgYF:`9acd32`};function Xn(){let e={},t=Object.keys(Yn),n=Object.keys(Jn),r,i,a,o,s;for(r=0;r<t.length;r++){for(o=s=t[r],i=0;i<n.length;i++)a=n[i],s=s.replace(a,Jn[a]);a=parseInt(Yn[o],16),e[s]=[a>>16&255,a>>8&255,a&255]}return e}var Zn;function Qn(e){Zn||(Zn=Xn(),Zn.transparent=[0,0,0,0]);let t=Zn[e.toLowerCase()];return t&&{r:t[0],g:t[1],b:t[2],a:t.length===4?t[3]:255}}var $n=/^rgba?\(\s*([-+.\d]+)(%)?[\s,]+([-+.e\d]+)(%)?[\s,]+([-+.e\d]+)(%)?(?:[\s,/]+([-+.e\d]+)(%)?)?\s*\)$/;function er(e){let t=$n.exec(e),n=255,r,i,a;if(t){if(t[7]!==r){let e=+t[7];n=t[8]?xn(e):bn(e*255,0,255)}return r=+t[1],i=+t[3],a=+t[5],r=255&(t[2]?xn(r):bn(r,0,255)),i=255&(t[4]?xn(i):bn(i,0,255)),a=255&(t[6]?xn(a):bn(a,0,255)),{r,g:i,b:a,a:n}}}function tr(e){return e&&(e.a<255?`rgba(${e.r}, ${e.g}, ${e.b}, ${Cn(e.a)})`:`rgb(${e.r}, ${e.g}, ${e.b})`)}var nr=e=>e<=.0031308?e*12.92:e**(1/2.4)*1.055-.055,rr=e=>e<=.04045?e/12.92:((e+.055)/1.055)**2.4;function ir(e,t,n){let r=rr(Cn(e.r)),i=rr(Cn(e.g)),a=rr(Cn(e.b));return{r:Sn(nr(r+n*(rr(Cn(t.r))-r))),g:Sn(nr(i+n*(rr(Cn(t.g))-i))),b:Sn(nr(a+n*(rr(Cn(t.b))-a))),a:e.a+n*(t.a-e.a)}}function ar(e,t,n){if(e){let r=zn(e);r[t]=Math.max(0,Math.min(r[t]+r[t]*n,t===0?360:1)),r=Vn(r),e.r=r[0],e.g=r[1],e.b=r[2]}}function or(e,t){return e&&Object.assign(t||{},e)}function sr(e){var t={r:0,g:0,b:0,a:255};return Array.isArray(e)?e.length>=3&&(t={r:e[0],g:e[1],b:e[2],a:255},e.length>3&&(t.a=Sn(e[3]))):(t=or(e,{r:0,g:0,b:0,a:1}),t.a=Sn(t.a)),t}function cr(e){return e.charAt(0)===`r`?er(e):Gn(e)}var lr=class e{constructor(t){if(t instanceof e)return t;let n=typeof t,r;n===`object`?r=sr(t):n===`string`&&(r=jn(t)||Qn(t)||cr(t)),this._rgb=r,this._valid=!!r}get valid(){return this._valid}get rgb(){var e=or(this._rgb);return e&&(e.a=Cn(e.a)),e}set rgb(e){this._rgb=sr(e)}rgbString(){return this._valid?tr(this._rgb):void 0}hexString(){return this._valid?Nn(this._rgb):void 0}hslString(){return this._valid?qn(this._rgb):void 0}mix(e,t){if(e){let n=this.rgb,r=e.rgb,i,a=t===i?.5:t,o=2*a-1,s=n.a-r.a,c=((o*s===-1?o:(o+s)/(1+o*s))+1)/2;i=1-c,n.r=255&c*n.r+i*r.r+.5,n.g=255&c*n.g+i*r.g+.5,n.b=255&c*n.b+i*r.b+.5,n.a=a*n.a+(1-a)*r.a,this.rgb=n}return this}interpolate(e,t){return e&&(this._rgb=ir(this._rgb,e._rgb,t)),this}clone(){return new e(this.rgb)}alpha(e){return this._rgb.a=Sn(e),this}clearer(e){let t=this._rgb;return t.a*=1-e,this}greyscale(){let e=this._rgb;return e.r=e.g=e.b=yn(e.r*.3+e.g*.59+e.b*.11),this}opaquer(e){let t=this._rgb;return t.a*=1+e,this}negate(){let e=this._rgb;return e.r=255-e.r,e.g=255-e.g,e.b=255-e.b,this}lighten(e){return ar(this._rgb,2,e),this}darken(e){return ar(this._rgb,2,-e),this}saturate(e){return ar(this._rgb,1,e),this}desaturate(e){return ar(this._rgb,1,-e),this}rotate(e){return Kn(this._rgb,e),this}};function ur(){}var dr=(()=>{let e=0;return()=>e++})();function I(e){return e==null}function L(e){if(Array.isArray&&Array.isArray(e))return!0;let t=Object.prototype.toString.call(e);return t.slice(0,7)===`[object`&&t.slice(-6)===`Array]`}function R(e){return e!==null&&Object.prototype.toString.call(e)===`[object Object]`}function z(e){return(typeof e==`number`||e instanceof Number)&&isFinite(+e)}function fr(e,t){return z(e)?e:t}function B(e,t){return e===void 0?t:e}var pr=(e,t)=>typeof e==`string`&&e.endsWith(`%`)?parseFloat(e)/100:+e/t,mr=(e,t)=>typeof e==`string`&&e.endsWith(`%`)?parseFloat(e)/100*t:+e;function V(e,t,n){if(e&&typeof e.call==`function`)return e.apply(n,t)}function H(e,t,n,r){let i,a,o;if(L(e))if(a=e.length,r)for(i=a-1;i>=0;i--)t.call(n,e[i],i);else for(i=0;i<a;i++)t.call(n,e[i],i);else if(R(e))for(o=Object.keys(e),a=o.length,i=0;i<a;i++)t.call(n,e[o[i]],o[i])}function hr(e,t){let n,r,i,a;if(!e||!t||e.length!==t.length)return!1;for(n=0,r=e.length;n<r;++n)if(i=e[n],a=t[n],i.datasetIndex!==a.datasetIndex||i.index!==a.index)return!1;return!0}function gr(e){if(L(e))return e.map(gr);if(R(e)){let t=Object.create(null),n=Object.keys(e),r=n.length,i=0;for(;i<r;++i)t[n[i]]=gr(e[n[i]]);return t}return e}function _r(e){return[`__proto__`,`prototype`,`constructor`].indexOf(e)===-1}function vr(e,t,n,r){if(!_r(e))return;let i=t[e],a=n[e];R(i)&&R(a)?yr(i,a,r):t[e]=gr(a)}function yr(e,t,n){let r=L(t)?t:[t],i=r.length;if(!R(e))return e;n||={};let a=n.merger||vr,o;for(let t=0;t<i;++t){if(o=r[t],!R(o))continue;let i=Object.keys(o);for(let t=0,r=i.length;t<r;++t)a(i[t],e,o,n)}return e}function br(e,t){return yr(e,t,{merger:xr})}function xr(e,t,n){if(!_r(e))return;let r=t[e],i=n[e];R(r)&&R(i)?br(r,i):Object.prototype.hasOwnProperty.call(t,e)||(t[e]=gr(i))}var Sr={"":e=>e,x:e=>e.x,y:e=>e.y};function Cr(e){let t=e.split(`.`),n=[],r=``;for(let e of t)r+=e,r.endsWith(`\\`)?r=r.slice(0,-1)+`.`:(n.push(r),r=``);return n}function wr(e){let t=Cr(e);return e=>{for(let n of t){if(n===``)break;e&&=e[n]}return e}}function Tr(e,t){return(Sr[t]||(Sr[t]=wr(t)))(e)}function Er(e){return e.charAt(0).toUpperCase()+e.slice(1)}var Dr=e=>e!==void 0,Or=e=>typeof e==`function`,kr=(e,t)=>{if(e.size!==t.size)return!1;for(let n of e)if(!t.has(n))return!1;return!0};function Ar(e){return e.type===`mouseup`||e.type===`click`||e.type===`contextmenu`}var U=Math.PI,W=2*U,jr=W+U,Mr=1/0,Nr=U/180,G=U/2,Pr=U/4,Fr=U*2/3,Ir=Math.log10,Lr=Math.sign;function Rr(e,t,n){return Math.abs(e-t)<n}function zr(e){let t=Math.round(e);e=Rr(e,t,e/1e3)?t:e;let n=10**Math.floor(Ir(e)),r=e/n;return(r<=1?1:r<=2?2:r<=5?5:10)*n}function Br(e){let t=[],n=Math.sqrt(e),r;for(r=1;r<n;r++)e%r===0&&(t.push(r),t.push(e/r));return n===(n|0)&&t.push(n),t.sort((e,t)=>e-t).pop(),t}function Vr(e){return typeof e==`symbol`||typeof e==`object`&&!!e&&!(Symbol.toPrimitive in e||`toString`in e||`valueOf`in e)}function Hr(e){return!Vr(e)&&!isNaN(parseFloat(e))&&isFinite(e)}function Ur(e,t){let n=Math.round(e);return n-t<=e&&n+t>=e}function Wr(e,t,n){let r,i,a;for(r=0,i=e.length;r<i;r++)a=e[r][n],isNaN(a)||(t.min=Math.min(t.min,a),t.max=Math.max(t.max,a))}function Gr(e){return U/180*e}function Kr(e){return 180/U*e}function qr(e){if(!z(e))return;let t=1,n=0;for(;Math.round(e*t)/t!==e;)t*=10,n++;return n}function Jr(e,t){let n=t.x-e.x,r=t.y-e.y,i=Math.sqrt(n*n+r*r),a=Math.atan2(r,n);return a<-.5*U&&(a+=W),{angle:a,distance:i}}function Yr(e,t){return Math.sqrt((t.x-e.x)**2+(t.y-e.y)**2)}function Xr(e,t){return(e-t+jr)%W-U}function K(e){return(e%W+W)%W}function Zr(e,t,n,r){let i=K(e),a=K(t),o=K(n),s=K(a-i),c=K(o-i),l=K(i-a),u=K(i-o);return i===a||i===o||r&&a===o||s>c&&l<u}function q(e,t,n){return Math.max(t,Math.min(n,e))}function Qr(e){return q(e,-32768,32767)}function $r(e,t,n,r=1e-6){return e>=Math.min(t,n)-r&&e<=Math.max(t,n)+r}function ei(e,t,n){n||=(n=>e[n]<t);let r=e.length-1,i=0,a;for(;r-i>1;)a=i+r>>1,n(a)?i=a:r=a;return{lo:i,hi:r}}var ti=(e,t,n,r)=>ei(e,n,r?r=>{let i=e[r][t];return i<n||i===n&&e[r+1][t]===n}:r=>e[r][t]<n),ni=(e,t,n)=>ei(e,n,r=>e[r][t]>=n);function ri(e,t,n){let r=0,i=e.length;for(;r<i&&e[r]<t;)r++;for(;i>r&&e[i-1]>n;)i--;return r>0||i<e.length?e.slice(r,i):e}var ii=[`push`,`pop`,`shift`,`splice`,`unshift`];function ai(e,t){if(e._chartjs){e._chartjs.listeners.push(t);return}Object.defineProperty(e,`_chartjs`,{configurable:!0,enumerable:!1,value:{listeners:[t]}}),ii.forEach(t=>{let n=`_onData`+Er(t),r=e[t];Object.defineProperty(e,t,{configurable:!0,enumerable:!1,value(...t){let i=r.apply(this,t);return e._chartjs.listeners.forEach(e=>{typeof e[n]==`function`&&e[n](...t)}),i}})})}function oi(e,t){let n=e._chartjs;if(!n)return;let r=n.listeners,i=r.indexOf(t);i!==-1&&r.splice(i,1),!(r.length>0)&&(ii.forEach(t=>{delete e[t]}),delete e._chartjs)}function si(e){let t=new Set(e);return t.size===e.length?e:Array.from(t)}var ci=function(){return typeof window>`u`?function(e){return e()}:window.requestAnimationFrame}();function li(e,t){let n=[],r=!1;return function(...i){n=i,r||(r=!0,ci.call(window,()=>{r=!1,e.apply(t,n)}))}}function ui(e,t){let n;return function(...r){return t?(clearTimeout(n),n=setTimeout(e,t,r)):e.apply(this,r),t}}var di=e=>e===`start`?`left`:e===`end`?`right`:`center`,fi=(e,t,n)=>e===`start`?t:e===`end`?n:(t+n)/2,pi=(e,t,n,r)=>e===(r?`left`:`right`)?n:e===`center`?(t+n)/2:t;function mi(e,t,n){let r=t.length,i=0,a=r;if(e._sorted){let{iScale:o,vScale:s,_parsed:c}=e,l=e.dataset&&e.dataset.options?e.dataset.options.spanGaps:null,u=o.axis,{min:d,max:f,minDefined:p,maxDefined:m}=o.getUserBounds();if(p){if(i=Math.min(ti(c,u,d).lo,n?r:ti(t,u,o.getPixelForValue(d)).lo),l){let e=c.slice(0,i+1).reverse().findIndex(e=>!I(e[s.axis]));i-=Math.max(0,e)}i=q(i,0,r-1)}if(m){let e=Math.max(ti(c,o.axis,f,!0).hi+1,n?0:ti(t,u,o.getPixelForValue(f),!0).hi+1);if(l){let t=c.slice(e-1).findIndex(e=>!I(e[s.axis]));e+=Math.max(0,t)}a=q(e,i,r)-i}else a=r-i}return{start:i,count:a}}function hi(e){let{xScale:t,yScale:n,_scaleRanges:r}=e,i={xmin:t.min,xmax:t.max,ymin:n.min,ymax:n.max};if(!r)return e._scaleRanges=i,!0;let a=r.xmin!==t.min||r.xmax!==t.max||r.ymin!==n.min||r.ymax!==n.max;return Object.assign(r,i),a}var gi=e=>e===0||e===1,_i=(e,t,n)=>-(2**(10*--e)*Math.sin((e-t)*W/n)),vi=(e,t,n)=>2**(-10*e)*Math.sin((e-t)*W/n)+1,yi={linear:e=>e,easeInQuad:e=>e*e,easeOutQuad:e=>-e*(e-2),easeInOutQuad:e=>(e/=.5)<1?.5*e*e:-.5*(--e*(e-2)-1),easeInCubic:e=>e*e*e,easeOutCubic:e=>--e*e*e+1,easeInOutCubic:e=>(e/=.5)<1?.5*e*e*e:.5*((e-=2)*e*e+2),easeInQuart:e=>e*e*e*e,easeOutQuart:e=>-(--e*e*e*e-1),easeInOutQuart:e=>(e/=.5)<1?.5*e*e*e*e:-.5*((e-=2)*e*e*e-2),easeInQuint:e=>e*e*e*e*e,easeOutQuint:e=>--e*e*e*e*e+1,easeInOutQuint:e=>(e/=.5)<1?.5*e*e*e*e*e:.5*((e-=2)*e*e*e*e+2),easeInSine:e=>-Math.cos(e*G)+1,easeOutSine:e=>Math.sin(e*G),easeInOutSine:e=>-.5*(Math.cos(U*e)-1),easeInExpo:e=>e===0?0:2**(10*(e-1)),easeOutExpo:e=>e===1?1:-(2**(-10*e))+1,easeInOutExpo:e=>gi(e)?e:e<.5?.5*2**(10*(e*2-1)):.5*(-(2**(-10*(e*2-1)))+2),easeInCirc:e=>e>=1?e:-(Math.sqrt(1-e*e)-1),easeOutCirc:e=>Math.sqrt(1- --e*e),easeInOutCirc:e=>(e/=.5)<1?-.5*(Math.sqrt(1-e*e)-1):.5*(Math.sqrt(1-(e-=2)*e)+1),easeInElastic:e=>gi(e)?e:_i(e,.075,.3),easeOutElastic:e=>gi(e)?e:vi(e,.075,.3),easeInOutElastic(e){let t=.1125,n=.45;return gi(e)?e:e<.5?.5*_i(e*2,t,n):.5+.5*vi(e*2-1,t,n)},easeInBack(e){let t=1.70158;return e*e*((t+1)*e-t)},easeOutBack(e){let t=1.70158;return--e*e*((t+1)*e+t)+1},easeInOutBack(e){let t=1.70158;return(e/=.5)<1?.5*(e*e*(((t*=1.525)+1)*e-t)):.5*((e-=2)*e*(((t*=1.525)+1)*e+t)+2)},easeInBounce:e=>1-yi.easeOutBounce(1-e),easeOutBounce(e){let t=7.5625,n=2.75;return e<1/n?t*e*e:e<2/n?t*(e-=1.5/n)*e+.75:e<2.5/n?t*(e-=2.25/n)*e+.9375:t*(e-=2.625/n)*e+.984375},easeInOutBounce:e=>e<.5?yi.easeInBounce(e*2)*.5:yi.easeOutBounce(e*2-1)*.5+.5};function bi(e){if(e&&typeof e==`object`){let t=e.toString();return t===`[object CanvasPattern]`||t===`[object CanvasGradient]`}return!1}function xi(e){return bi(e)?e:new lr(e)}function Si(e){return bi(e)?e:new lr(e).saturate(.5).darken(.1).hexString()}var Ci=[`x`,`y`,`borderWidth`,`radius`,`tension`],wi=[`color`,`borderColor`,`backgroundColor`];function Ti(e){e.set(`animation`,{delay:void 0,duration:1e3,easing:`easeOutQuart`,fn:void 0,from:void 0,loop:void 0,to:void 0,type:void 0}),e.describe(`animation`,{_fallback:!1,_indexable:!1,_scriptable:e=>e!==`onProgress`&&e!==`onComplete`&&e!==`fn`}),e.set(`animations`,{colors:{type:`color`,properties:wi},numbers:{type:`number`,properties:Ci}}),e.describe(`animations`,{_fallback:`animation`}),e.set(`transitions`,{active:{animation:{duration:400}},resize:{animation:{duration:0}},show:{animations:{colors:{from:`transparent`},visible:{type:`boolean`,duration:0}}},hide:{animations:{colors:{to:`transparent`},visible:{type:`boolean`,easing:`linear`,fn:e=>e|0}}}})}function Ei(e){e.set(`layout`,{autoPadding:!0,padding:{top:0,right:0,bottom:0,left:0}})}var Di=new Map;function Oi(e,t){t||={};let n=e+JSON.stringify(t),r=Di.get(n);return r||(r=new Intl.NumberFormat(e,t),Di.set(n,r)),r}function ki(e,t,n){return Oi(t,n).format(e)}var Ai={values(e){return L(e)?e:``+e},numeric(e,t,n){if(e===0)return`0`;let r=this.chart.options.locale,i,a=e;if(n.length>1){let t=Math.max(Math.abs(n[0].value),Math.abs(n[n.length-1].value));(t<1e-4||t>0x38d7ea4c68000)&&(i=`scientific`),a=ji(e,n)}let o=Ir(Math.abs(a)),s=isNaN(o)?1:Math.max(Math.min(-1*Math.floor(o),20),0),c={notation:i,minimumFractionDigits:s,maximumFractionDigits:s};return Object.assign(c,this.options.ticks.format),ki(e,r,c)},logarithmic(e,t,n){if(e===0)return`0`;let r=n[t].significand||e/10**Math.floor(Ir(e));return[1,2,3,5,10,15].includes(r)||t>.8*n.length?Ai.numeric.call(this,e,t,n):``}};function ji(e,t){let n=t.length>3?t[2].value-t[1].value:t[1].value-t[0].value;return Math.abs(n)>=1&&e!==Math.floor(e)&&(n=e-Math.floor(e)),n}var Mi={formatters:Ai};function Ni(e){e.set(`scale`,{display:!0,offset:!1,reverse:!1,beginAtZero:!1,bounds:`ticks`,clip:!0,grace:0,grid:{display:!0,lineWidth:1,drawOnChartArea:!0,drawTicks:!0,tickLength:8,tickWidth:(e,t)=>t.lineWidth,tickColor:(e,t)=>t.color,offset:!1},border:{display:!0,dash:[],dashOffset:0,width:1},title:{display:!1,text:``,padding:{top:4,bottom:4}},ticks:{minRotation:0,maxRotation:50,mirror:!1,textStrokeWidth:0,textStrokeColor:``,padding:3,display:!0,autoSkip:!0,autoSkipPadding:3,labelOffset:0,callback:Mi.formatters.values,minor:{},major:{},align:`center`,crossAlign:`near`,showLabelBackdrop:!1,backdropColor:`rgba(255, 255, 255, 0.75)`,backdropPadding:2}}),e.route(`scale.ticks`,`color`,``,`color`),e.route(`scale.grid`,`color`,``,`borderColor`),e.route(`scale.border`,`color`,``,`borderColor`),e.route(`scale.title`,`color`,``,`color`),e.describe(`scale`,{_fallback:!1,_scriptable:e=>!e.startsWith(`before`)&&!e.startsWith(`after`)&&e!==`callback`&&e!==`parser`,_indexable:e=>e!==`borderDash`&&e!==`tickBorderDash`&&e!==`dash`}),e.describe(`scales`,{_fallback:`scale`}),e.describe(`scale.ticks`,{_scriptable:e=>e!==`backdropPadding`&&e!==`callback`,_indexable:e=>e!==`backdropPadding`})}var Pi=Object.create(null),Fi=Object.create(null);function Ii(e,t){if(!t)return e;let n=t.split(`.`);for(let t=0,r=n.length;t<r;++t){let r=n[t];e=e[r]||(e[r]=Object.create(null))}return e}function Li(e,t,n){return typeof t==`string`?yr(Ii(e,t),n):yr(Ii(e,``),t)}var J=new class{constructor(e,t){this.animation=void 0,this.backgroundColor=`rgba(0,0,0,0.1)`,this.borderColor=`rgba(0,0,0,0.1)`,this.color=`#666`,this.datasets={},this.devicePixelRatio=e=>e.chart.platform.getDevicePixelRatio(),this.elements={},this.events=[`mousemove`,`mouseout`,`click`,`touchstart`,`touchmove`],this.font={family:`'Helvetica Neue', 'Helvetica', 'Arial', sans-serif`,size:12,style:`normal`,lineHeight:1.2,weight:null},this.hover={},this.hoverBackgroundColor=(e,t)=>Si(t.backgroundColor),this.hoverBorderColor=(e,t)=>Si(t.borderColor),this.hoverColor=(e,t)=>Si(t.color),this.indexAxis=`x`,this.interaction={mode:`nearest`,intersect:!0,includeInvisible:!1},this.maintainAspectRatio=!0,this.onHover=null,this.onClick=null,this.parsing=!0,this.plugins={},this.responsive=!0,this.scale=void 0,this.scales={},this.showLine=!0,this.drawActiveElementsOnTop=!0,this.describe(e),this.apply(t)}set(e,t){return Li(this,e,t)}get(e){return Ii(this,e)}describe(e,t){return Li(Fi,e,t)}override(e,t){return Li(Pi,e,t)}route(e,t,n,r){let i=Ii(this,e),a=Ii(this,n),o=`_`+t;Object.defineProperties(i,{[o]:{value:i[t],writable:!0},[t]:{enumerable:!0,get(){let e=this[o],t=a[r];return R(e)?Object.assign({},t,e):B(e,t)},set(e){this[o]=e}}})}apply(e){e.forEach(e=>e(this))}}({_scriptable:e=>!e.startsWith(`on`),_indexable:e=>e!==`events`,hover:{_fallback:`interaction`},interaction:{_scriptable:!1,_indexable:!1}},[Ti,Ei,Ni]);function Ri(e){return!e||I(e.size)||I(e.family)?null:(e.style?e.style+` `:``)+(e.weight?e.weight+` `:``)+e.size+`px `+e.family}function zi(e,t,n,r,i){let a=t[i];return a||(a=t[i]=e.measureText(i).width,n.push(i)),a>r&&(r=a),r}function Bi(e,t,n,r){r||={};let i=r.data=r.data||{},a=r.garbageCollect=r.garbageCollect||[];r.font!==t&&(i=r.data={},a=r.garbageCollect=[],r.font=t),e.save(),e.font=t;let o=0,s=n.length,c,l,u,d,f;for(c=0;c<s;c++)if(d=n[c],d!=null&&!L(d))o=zi(e,i,a,o,d);else if(L(d))for(l=0,u=d.length;l<u;l++)f=d[l],f!=null&&!L(f)&&(o=zi(e,i,a,o,f));e.restore();let p=a.length/2;if(p>n.length){for(c=0;c<p;c++)delete i[a[c]];a.splice(0,p)}return o}function Vi(e,t,n){let r=e.currentDevicePixelRatio,i=n===0?0:Math.max(n/2,.5);return Math.round((t-i)*r)/r+i}function Hi(e,t){!t&&!e||(t||=e.getContext(`2d`),t.save(),t.resetTransform(),t.clearRect(0,0,e.width,e.height),t.restore())}function Ui(e,t,n,r){Wi(e,t,n,r,null)}function Wi(e,t,n,r,i){let a,o,s,c,l,u,d,f,p=t.pointStyle,m=t.rotation,h=t.radius,g=(m||0)*Nr;if(p&&typeof p==`object`&&(a=p.toString(),a===`[object HTMLImageElement]`||a===`[object HTMLCanvasElement]`)){e.save(),e.translate(n,r),e.rotate(g),e.drawImage(p,-p.width/2,-p.height/2,p.width,p.height),e.restore();return}if(!(isNaN(h)||h<=0)){switch(e.beginPath(),p){default:i?e.ellipse(n,r,i/2,h,0,0,W):e.arc(n,r,h,0,W),e.closePath();break;case`triangle`:u=i?i/2:h,e.moveTo(n+Math.sin(g)*u,r-Math.cos(g)*h),g+=Fr,e.lineTo(n+Math.sin(g)*u,r-Math.cos(g)*h),g+=Fr,e.lineTo(n+Math.sin(g)*u,r-Math.cos(g)*h),e.closePath();break;case`rectRounded`:l=h*.516,c=h-l,o=Math.cos(g+Pr)*c,d=Math.cos(g+Pr)*(i?i/2-l:c),s=Math.sin(g+Pr)*c,f=Math.sin(g+Pr)*(i?i/2-l:c),e.arc(n-d,r-s,l,g-U,g-G),e.arc(n+f,r-o,l,g-G,g),e.arc(n+d,r+s,l,g,g+G),e.arc(n-f,r+o,l,g+G,g+U),e.closePath();break;case`rect`:if(!m){c=Math.SQRT1_2*h,u=i?i/2:c,e.rect(n-u,r-c,2*u,2*c);break}g+=Pr;case`rectRot`:d=Math.cos(g)*(i?i/2:h),o=Math.cos(g)*h,s=Math.sin(g)*h,f=Math.sin(g)*(i?i/2:h),e.moveTo(n-d,r-s),e.lineTo(n+f,r-o),e.lineTo(n+d,r+s),e.lineTo(n-f,r+o),e.closePath();break;case`crossRot`:g+=Pr;case`cross`:d=Math.cos(g)*(i?i/2:h),o=Math.cos(g)*h,s=Math.sin(g)*h,f=Math.sin(g)*(i?i/2:h),e.moveTo(n-d,r-s),e.lineTo(n+d,r+s),e.moveTo(n+f,r-o),e.lineTo(n-f,r+o);break;case`star`:d=Math.cos(g)*(i?i/2:h),o=Math.cos(g)*h,s=Math.sin(g)*h,f=Math.sin(g)*(i?i/2:h),e.moveTo(n-d,r-s),e.lineTo(n+d,r+s),e.moveTo(n+f,r-o),e.lineTo(n-f,r+o),g+=Pr,d=Math.cos(g)*(i?i/2:h),o=Math.cos(g)*h,s=Math.sin(g)*h,f=Math.sin(g)*(i?i/2:h),e.moveTo(n-d,r-s),e.lineTo(n+d,r+s),e.moveTo(n+f,r-o),e.lineTo(n-f,r+o);break;case`line`:o=i?i/2:Math.cos(g)*h,s=Math.sin(g)*h,e.moveTo(n-o,r-s),e.lineTo(n+o,r+s);break;case`dash`:e.moveTo(n,r),e.lineTo(n+Math.cos(g)*(i?i/2:h),r+Math.sin(g)*h);break;case!1:e.closePath();break}e.fill(),t.borderWidth>0&&e.stroke()}}function Gi(e,t,n){return n||=.5,!t||e&&e.x>t.left-n&&e.x<t.right+n&&e.y>t.top-n&&e.y<t.bottom+n}function Ki(e,t){e.save(),e.beginPath(),e.rect(t.left,t.top,t.right-t.left,t.bottom-t.top),e.clip()}function qi(e){e.restore()}function Ji(e,t,n,r,i){if(!t)return e.lineTo(n.x,n.y);if(i===`middle`){let r=(t.x+n.x)/2;e.lineTo(r,t.y),e.lineTo(r,n.y)}else i===`after`==!!r?e.lineTo(n.x,t.y):e.lineTo(t.x,n.y);e.lineTo(n.x,n.y)}function Yi(e,t,n,r){if(!t)return e.lineTo(n.x,n.y);e.bezierCurveTo(r?t.cp1x:t.cp2x,r?t.cp1y:t.cp2y,r?n.cp2x:n.cp1x,r?n.cp2y:n.cp1y,n.x,n.y)}function Xi(e,t){t.translation&&e.translate(t.translation[0],t.translation[1]),I(t.rotation)||e.rotate(t.rotation),t.color&&(e.fillStyle=t.color),t.textAlign&&(e.textAlign=t.textAlign),t.textBaseline&&(e.textBaseline=t.textBaseline)}function Zi(e,t,n,r,i){if(i.strikethrough||i.underline){let a=e.measureText(r),o=t-a.actualBoundingBoxLeft,s=t+a.actualBoundingBoxRight,c=n-a.actualBoundingBoxAscent,l=n+a.actualBoundingBoxDescent,u=i.strikethrough?(c+l)/2:l;e.strokeStyle=e.fillStyle,e.beginPath(),e.lineWidth=i.decorationWidth||2,e.moveTo(o,u),e.lineTo(s,u),e.stroke()}}function Qi(e,t){let n=e.fillStyle;e.fillStyle=t.color,e.fillRect(t.left,t.top,t.width,t.height),e.fillStyle=n}function $i(e,t,n,r,i,a={}){let o=L(t)?t:[t],s=a.strokeWidth>0&&a.strokeColor!==``,c,l;for(e.save(),e.font=i.string,Xi(e,a),c=0;c<o.length;++c)l=o[c],a.backdrop&&Qi(e,a.backdrop),s&&(a.strokeColor&&(e.strokeStyle=a.strokeColor),I(a.strokeWidth)||(e.lineWidth=a.strokeWidth),e.strokeText(l,n,r,a.maxWidth)),e.fillText(l,n,r,a.maxWidth),Zi(e,n,r,l,a),r+=Number(i.lineHeight);e.restore()}function ea(e,t){let{x:n,y:r,w:i,h:a,radius:o}=t;e.arc(n+o.topLeft,r+o.topLeft,o.topLeft,1.5*U,U,!0),e.lineTo(n,r+a-o.bottomLeft),e.arc(n+o.bottomLeft,r+a-o.bottomLeft,o.bottomLeft,U,G,!0),e.lineTo(n+i-o.bottomRight,r+a),e.arc(n+i-o.bottomRight,r+a-o.bottomRight,o.bottomRight,G,0,!0),e.lineTo(n+i,r+o.topRight),e.arc(n+i-o.topRight,r+o.topRight,o.topRight,0,-G,!0),e.lineTo(n+o.topLeft,r)}var ta=/^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/,na=/^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/;function ra(e,t){let n=(``+e).match(ta);if(!n||n[1]===`normal`)return t*1.2;switch(e=+n[2],n[3]){case`px`:return e;case`%`:e/=100;break}return t*e}var ia=e=>+e||0;function aa(e,t){let n={},r=R(t),i=r?Object.keys(t):t,a=R(e)?r?n=>B(e[n],e[t[n]]):t=>e[t]:()=>e;for(let e of i)n[e]=ia(a(e));return n}function oa(e){return aa(e,{top:`y`,right:`x`,bottom:`y`,left:`x`})}function sa(e){return aa(e,[`topLeft`,`topRight`,`bottomLeft`,`bottomRight`])}function Y(e){let t=oa(e);return t.width=t.left+t.right,t.height=t.top+t.bottom,t}function X(e,t){e||={},t||=J.font;let n=B(e.size,t.size);typeof n==`string`&&(n=parseInt(n,10));let r=B(e.style,t.style);r&&!(``+r).match(na)&&(console.warn(`Invalid font style specified: "`+r+`"`),r=void 0);let i={family:B(e.family,t.family),lineHeight:ra(B(e.lineHeight,t.lineHeight),n),size:n,style:r,weight:B(e.weight,t.weight),string:``};return i.string=Ri(i),i}function ca(e,t,n,r){let i=!0,a,o,s;for(a=0,o=e.length;a<o;++a)if(s=e[a],s!==void 0&&(t!==void 0&&typeof s==`function`&&(s=s(t),i=!1),n!==void 0&&L(s)&&(s=s[n%s.length],i=!1),s!==void 0))return r&&!i&&(r.cacheable=!1),s}function la(e,t,n){let{min:r,max:i}=e,a=mr(t,(i-r)/2),o=(e,t)=>n&&e===0?0:e+t;return{min:o(r,-Math.abs(a)),max:o(i,a)}}function ua(e,t){return Object.assign(Object.create(e),t)}function da(e,t=[``],n,r,i=()=>e[0]){let a=n||e;r===void 0&&(r=Da(`_fallback`,e));let o={[Symbol.toStringTag]:`Object`,_cacheable:!0,_scopes:e,_rootScopes:a,_fallback:r,_getTarget:i,override:n=>da([n,...e],t,a,r)};return new Proxy(o,{deleteProperty(t,n){return delete t[n],delete t._keys,delete e[0][n],!0},get(n,r){return ga(n,r,()=>Ea(r,t,e,n))},getOwnPropertyDescriptor(e,t){return Reflect.getOwnPropertyDescriptor(e._scopes[0],t)},getPrototypeOf(){return Reflect.getPrototypeOf(e[0])},has(e,t){return Oa(e).includes(t)},ownKeys(e){return Oa(e)},set(e,t,n){let r=e._storage||=i();return e[t]=r[t]=n,delete e._keys,!0}})}function fa(e,t,n,r){let i={_cacheable:!1,_proxy:e,_context:t,_subProxy:n,_stack:new Set,_descriptors:pa(e,r),setContext:t=>fa(e,t,n,r),override:i=>fa(e.override(i),t,n,r)};return new Proxy(i,{deleteProperty(t,n){return delete t[n],delete e[n],!0},get(e,t,n){return ga(e,t,()=>_a(e,t,n))},getOwnPropertyDescriptor(t,n){return t._descriptors.allKeys?Reflect.has(e,n)?{enumerable:!0,configurable:!0}:void 0:Reflect.getOwnPropertyDescriptor(e,n)},getPrototypeOf(){return Reflect.getPrototypeOf(e)},has(t,n){return Reflect.has(e,n)},ownKeys(){return Reflect.ownKeys(e)},set(t,n,r){return e[n]=r,delete t[n],!0}})}function pa(e,t={scriptable:!0,indexable:!0}){let{_scriptable:n=t.scriptable,_indexable:r=t.indexable,_allKeys:i=t.allKeys}=e;return{allKeys:i,scriptable:n,indexable:r,isScriptable:Or(n)?n:()=>n,isIndexable:Or(r)?r:()=>r}}var ma=(e,t)=>e?e+Er(t):t,ha=(e,t)=>R(t)&&e!==`adapters`&&(Object.getPrototypeOf(t)===null||t.constructor===Object);function ga(e,t,n){if(Object.prototype.hasOwnProperty.call(e,t)||t===`constructor`)return e[t];let r=n();return e[t]=r,r}function _a(e,t,n){let{_proxy:r,_context:i,_subProxy:a,_descriptors:o}=e,s=r[t];return Or(s)&&o.isScriptable(t)&&(s=va(t,s,e,n)),L(s)&&s.length&&(s=ya(t,s,e,o.isIndexable)),ha(t,s)&&(s=fa(s,i,a&&a[t],o)),s}function va(e,t,n,r){let{_proxy:i,_context:a,_subProxy:o,_stack:s}=n;if(s.has(e))throw Error(`Recursion detected: `+Array.from(s).join(`->`)+`->`+e);s.add(e);let c=t(a,o||r);return s.delete(e),ha(e,c)&&(c=Ca(i._scopes,i,e,c)),c}function ya(e,t,n,r){let{_proxy:i,_context:a,_subProxy:o,_descriptors:s}=n;if(a.index!==void 0&&r(e))return t[a.index%t.length];if(R(t[0])){let n=t,r=i._scopes.filter(e=>e!==n);t=[];for(let c of n){let n=Ca(r,i,e,c);t.push(fa(n,a,o&&o[e],s))}}return t}function ba(e,t,n){return Or(e)?e(t,n):e}var xa=(e,t)=>e===!0?t:typeof e==`string`?Tr(t,e):void 0;function Sa(e,t,n,r,i){for(let a of t){let t=xa(n,a);if(t){e.add(t);let a=ba(t._fallback,n,i);if(a!==void 0&&a!==n&&a!==r)return a}else if(t===!1&&r!==void 0&&n!==r)return null}return!1}function Ca(e,t,n,r){let i=t._rootScopes,a=ba(t._fallback,n,r),o=[...e,...i],s=new Set;s.add(r);let c=wa(s,o,n,a||n,r);return c===null||a!==void 0&&a!==n&&(c=wa(s,o,a,c,r),c===null)?!1:da(Array.from(s),[``],i,a,()=>Ta(t,n,r))}function wa(e,t,n,r,i){for(;n;)n=Sa(e,t,n,r,i);return n}function Ta(e,t,n){let r=e._getTarget();t in r||(r[t]={});let i=r[t];return L(i)&&R(n)?n:i||{}}function Ea(e,t,n,r){let i;for(let a of t)if(i=Da(ma(a,e),n),i!==void 0)return ha(e,i)?Ca(n,r,e,i):i}function Da(e,t){for(let n of t){if(!n)continue;let t=n[e];if(t!==void 0)return t}}function Oa(e){let t=e._keys;return t||=e._keys=ka(e._scopes),t}function ka(e){let t=new Set;for(let n of e)for(let e of Object.keys(n).filter(e=>!e.startsWith(`_`)))t.add(e);return Array.from(t)}function Aa(e,t,n,r){let{iScale:i}=e,{key:a=`r`}=this._parsing,o=Array(r),s,c,l,u;for(s=0,c=r;s<c;++s)l=s+n,u=t[l],o[s]={r:i.parse(Tr(u,a),l)};return o}var ja=2**-52||1e-14,Ma=(e,t)=>t<e.length&&!e[t].skip&&e[t],Na=e=>e===`x`?`y`:`x`;function Pa(e,t,n,r){let i=e.skip?t:e,a=t,o=n.skip?t:n,s=Yr(a,i),c=Yr(o,a),l=s/(s+c),u=c/(s+c);l=isNaN(l)?0:l,u=isNaN(u)?0:u;let d=r*l,f=r*u;return{previous:{x:a.x-d*(o.x-i.x),y:a.y-d*(o.y-i.y)},next:{x:a.x+f*(o.x-i.x),y:a.y+f*(o.y-i.y)}}}function Fa(e,t,n){let r=e.length,i,a,o,s,c,l=Ma(e,0);for(let u=0;u<r-1;++u)if(c=l,l=Ma(e,u+1),!(!c||!l)){if(Rr(t[u],0,ja)){n[u]=n[u+1]=0;continue}i=n[u]/t[u],a=n[u+1]/t[u],s=i**2+a**2,!(s<=9)&&(o=3/Math.sqrt(s),n[u]=i*o*t[u],n[u+1]=a*o*t[u])}}function Ia(e,t,n=`x`){let r=Na(n),i=e.length,a,o,s,c=Ma(e,0);for(let l=0;l<i;++l){if(o=s,s=c,c=Ma(e,l+1),!s)continue;let i=s[n],u=s[r];o&&(a=(i-o[n])/3,s[`cp1${n}`]=i-a,s[`cp1${r}`]=u-a*t[l]),c&&(a=(c[n]-i)/3,s[`cp2${n}`]=i+a,s[`cp2${r}`]=u+a*t[l])}}function La(e,t=`x`){let n=Na(t),r=e.length,i=Array(r).fill(0),a=Array(r),o,s,c,l=Ma(e,0);for(o=0;o<r;++o)if(s=c,c=l,l=Ma(e,o+1),c){if(l){let e=l[t]-c[t];i[o]=e===0?0:(l[n]-c[n])/e}a[o]=s?l?Lr(i[o-1])===Lr(i[o])?(i[o-1]+i[o])/2:0:i[o-1]:i[o]}Fa(e,i,a),Ia(e,a,t)}function Ra(e,t,n){return Math.max(Math.min(e,n),t)}function za(e,t){let n,r,i,a,o,s=Gi(e[0],t);for(n=0,r=e.length;n<r;++n)o=a,a=s,s=n<r-1&&Gi(e[n+1],t),a&&(i=e[n],o&&(i.cp1x=Ra(i.cp1x,t.left,t.right),i.cp1y=Ra(i.cp1y,t.top,t.bottom)),s&&(i.cp2x=Ra(i.cp2x,t.left,t.right),i.cp2y=Ra(i.cp2y,t.top,t.bottom)))}function Ba(e,t,n,r,i){let a,o,s,c;if(t.spanGaps&&(e=e.filter(e=>!e.skip)),t.cubicInterpolationMode===`monotone`)La(e,i);else{let n=r?e[e.length-1]:e[0];for(a=0,o=e.length;a<o;++a)s=e[a],c=Pa(n,s,e[Math.min(a+1,o-(r?0:1))%o],t.tension),s.cp1x=c.previous.x,s.cp1y=c.previous.y,s.cp2x=c.next.x,s.cp2y=c.next.y,n=s}t.capBezierPoints&&za(e,n)}function Va(){return typeof window<`u`&&typeof document<`u`}function Ha(e){let t=e.parentNode;return t&&t.toString()===`[object ShadowRoot]`&&(t=t.host),t}function Ua(e,t,n){let r;return typeof e==`string`?(r=parseInt(e,10),e.indexOf(`%`)!==-1&&(r=r/100*t.parentNode[n])):r=e,r}var Wa=e=>e.ownerDocument.defaultView.getComputedStyle(e,null);function Ga(e,t){return Wa(e).getPropertyValue(t)}var Ka=[`top`,`right`,`bottom`,`left`];function qa(e,t,n){let r={};n=n?`-`+n:``;for(let i=0;i<4;i++){let a=Ka[i];r[a]=parseFloat(e[t+`-`+a+n])||0}return r.width=r.left+r.right,r.height=r.top+r.bottom,r}var Ja=(e,t,n)=>(e>0||t>0)&&(!n||!n.shadowRoot);function Ya(e,t){let n=e.touches,r=n&&n.length?n[0]:e,{offsetX:i,offsetY:a}=r,o=!1,s,c;if(Ja(i,a,e.target))s=i,c=a;else{let e=t.getBoundingClientRect();s=r.clientX-e.left,c=r.clientY-e.top,o=!0}return{x:s,y:c,box:o}}function Xa(e,t){if(`native`in e)return e;let{canvas:n,currentDevicePixelRatio:r}=t,i=Wa(n),a=i.boxSizing===`border-box`,o=qa(i,`padding`),s=qa(i,`border`,`width`),{x:c,y:l,box:u}=Ya(e,n),d=o.left+(u&&s.left),f=o.top+(u&&s.top),{width:p,height:m}=t;return a&&(p-=o.width+s.width,m-=o.height+s.height),{x:Math.round((c-d)/p*n.width/r),y:Math.round((l-f)/m*n.height/r)}}function Za(e,t,n){let r,i;if(t===void 0||n===void 0){let a=e&&Ha(e);if(!a)t=e.clientWidth,n=e.clientHeight;else{let e=a.getBoundingClientRect(),o=Wa(a),s=qa(o,`border`,`width`),c=qa(o,`padding`);t=e.width-c.width-s.width,n=e.height-c.height-s.height,r=Ua(o.maxWidth,a,`clientWidth`),i=Ua(o.maxHeight,a,`clientHeight`)}}return{width:t,height:n,maxWidth:r||Mr,maxHeight:i||Mr}}var Qa=e=>Math.round(e*10)/10;function $a(e,t,n,r){let i=Wa(e),a=qa(i,`margin`),o=Ua(i.maxWidth,e,`clientWidth`)||Mr,s=Ua(i.maxHeight,e,`clientHeight`)||Mr,c=Za(e,t,n),{width:l,height:u}=c;if(i.boxSizing===`content-box`){let e=qa(i,`border`,`width`),t=qa(i,`padding`);l-=t.width+e.width,u-=t.height+e.height}return l=Math.max(0,l-a.width),u=Math.max(0,r?l/r:u-a.height),l=Qa(Math.min(l,o,c.maxWidth)),u=Qa(Math.min(u,s,c.maxHeight)),l&&!u&&(u=Qa(l/2)),(t!==void 0||n!==void 0)&&r&&c.height&&u>c.height&&(u=c.height,l=Qa(Math.floor(u*r))),{width:l,height:u}}function eo(e,t,n){let r=t||1,i=Qa(e.height*r),a=Qa(e.width*r);e.height=Qa(e.height),e.width=Qa(e.width);let o=e.canvas;return o.style&&(n||!o.style.height&&!o.style.width)&&(o.style.height=`${e.height}px`,o.style.width=`${e.width}px`),e.currentDevicePixelRatio!==r||o.height!==i||o.width!==a?(e.currentDevicePixelRatio=r,o.height=i,o.width=a,e.ctx.setTransform(r,0,0,r,0,0),!0):!1}var to=function(){let e=!1;try{let t={get passive(){return e=!0,!1}};Va()&&(window.addEventListener(`test`,null,t),window.removeEventListener(`test`,null,t))}catch{}return e}();function no(e,t){let n=Ga(e,t),r=n&&n.match(/^(\d+)(\.\d+)?px$/);return r?+r[1]:void 0}function ro(e,t,n,r){return{x:e.x+n*(t.x-e.x),y:e.y+n*(t.y-e.y)}}function io(e,t,n,r){return{x:e.x+n*(t.x-e.x),y:r===`middle`?n<.5?e.y:t.y:r===`after`?n<1?e.y:t.y:n>0?t.y:e.y}}function ao(e,t,n,r){let i={x:e.cp2x,y:e.cp2y},a={x:t.cp1x,y:t.cp1y},o=ro(e,i,n),s=ro(i,a,n),c=ro(a,t,n);return ro(ro(o,s,n),ro(s,c,n),n)}var oo=function(e,t){return{x(n){return e+e+t-n},setWidth(e){t=e},textAlign(e){return e===`center`?e:e===`right`?`left`:`right`},xPlus(e,t){return e-t},leftForLtr(e,t){return e-t}}},so=function(){return{x(e){return e},setWidth(e){},textAlign(e){return e},xPlus(e,t){return e+t},leftForLtr(e,t){return e}}};function co(e,t,n){return e?oo(t,n):so()}function lo(e,t){let n,r;(t===`ltr`||t===`rtl`)&&(n=e.canvas.style,r=[n.getPropertyValue(`direction`),n.getPropertyPriority(`direction`)],n.setProperty(`direction`,t,`important`),e.prevTextDirection=r)}function uo(e,t){t!==void 0&&(delete e.prevTextDirection,e.canvas.style.setProperty(`direction`,t[0],t[1]))}function fo(e){return e===`angle`?{between:Zr,compare:Xr,normalize:K}:{between:$r,compare:(e,t)=>e-t,normalize:e=>e}}function po({start:e,end:t,count:n,loop:r,style:i}){return{start:e%n,end:t%n,loop:r&&(t-e+1)%n===0,style:i}}function mo(e,t,n){let{property:r,start:i,end:a}=n,{between:o,normalize:s}=fo(r),c=t.length,{start:l,end:u,loop:d}=e,f,p;if(d){for(l+=c,u+=c,f=0,p=c;f<p&&o(s(t[l%c][r]),i,a);++f)l--,u--;l%=c,u%=c}return u<l&&(u+=c),{start:l,end:u,loop:d,style:e.style}}function ho(e,t,n){if(!n)return[e];let{property:r,start:i,end:a}=n,o=t.length,{compare:s,between:c,normalize:l}=fo(r),{start:u,end:d,loop:f,style:p}=mo(e,t,n),m=[],h=!1,g=null,_,v,y,b=()=>c(i,y,_)&&s(i,y)!==0,x=()=>s(a,_)===0||c(a,y,_),S=()=>h||b(),C=()=>!h||x();for(let e=u,n=u;e<=d;++e)v=t[e%o],!v.skip&&(_=l(v[r]),_!==y&&(h=c(_,i,a),g===null&&S()&&(g=s(_,i)===0?e:n),g!==null&&C()&&(m.push(po({start:g,end:e,loop:f,count:o,style:p})),g=null),n=e,y=_));return g!==null&&m.push(po({start:g,end:d,loop:f,count:o,style:p})),m}function go(e,t){let n=[],r=e.segments;for(let i=0;i<r.length;i++){let a=ho(r[i],e.points,t);a.length&&n.push(...a)}return n}function _o(e,t,n,r){let i=0,a=t-1;if(n&&!r)for(;i<t&&!e[i].skip;)i++;for(;i<t&&e[i].skip;)i++;for(i%=t,n&&(a+=i);a>i&&e[a%t].skip;)a--;return a%=t,{start:i,end:a}}function vo(e,t,n,r){let i=e.length,a=[],o=t,s=e[t],c;for(c=t+1;c<=n;++c){let n=e[c%i];n.skip||n.stop?s.skip||(r=!1,a.push({start:t%i,end:(c-1)%i,loop:r}),t=o=n.stop?c:null):(o=c,s.skip&&(t=c)),s=n}return o!==null&&a.push({start:t%i,end:o%i,loop:r}),a}function yo(e,t){let n=e.points,r=e.options.spanGaps,i=n.length;if(!i)return[];let a=!!e._loop,{start:o,end:s}=_o(n,i,a,r);return r===!0?bo(e,[{start:o,end:s,loop:a}],n,t):bo(e,vo(n,o,s<o?s+i:s,!!e._fullLoop&&o===0&&s===i-1),n,t)}function bo(e,t,n,r){return!r||!r.setContext||!n?t:xo(e,t,n,r)}function xo(e,t,n,r){let i=e._chart.getContext(),a=So(e.options),{_datasetIndex:o,options:{spanGaps:s}}=e,c=n.length,l=[],u=a,d=t[0].start,f=d;function p(e,t,r,i){let a=s?-1:1;if(e!==t){for(e+=c;n[e%c].skip;)e-=a;for(;n[t%c].skip;)t+=a;e%c!==t%c&&(l.push({start:e%c,end:t%c,loop:r,style:i}),u=i,d=t%c)}}for(let e of t){d=s?d:e.start;let t=n[d%c],a;for(f=d+1;f<=e.end;f++){let s=n[f%c];a=So(r.setContext(ua(i,{type:`segment`,p0:t,p1:s,p0DataIndex:(f-1)%c,p1DataIndex:f%c,datasetIndex:o}))),Co(a,u)&&p(d,f-1,e.loop,u),t=s,u=a}d<f-1&&p(d,f-1,e.loop,u)}return l}function So(e){return{backgroundColor:e.backgroundColor,borderCapStyle:e.borderCapStyle,borderDash:e.borderDash,borderDashOffset:e.borderDashOffset,borderJoinStyle:e.borderJoinStyle,borderWidth:e.borderWidth,borderColor:e.borderColor}}function Co(e,t){if(!t)return!1;let n=[],r=function(e,t){return bi(t)?(n.includes(t)||n.push(t),n.indexOf(t)):t};return JSON.stringify(e,r)!==JSON.stringify(t,r)}function wo(e,t,n){return e.options.clip?e[n]:t[n]}function To(e,t){let{xScale:n,yScale:r}=e;return n&&r?{left:wo(n,t,`left`),right:wo(n,t,`right`),top:wo(r,t,`top`),bottom:wo(r,t,`bottom`)}:t}function Eo(e,t){let n=t._clip;if(n.disabled)return!1;let r=To(t,e.chartArea);return{left:n.left===!1?0:r.left-(n.left===!0?0:n.left),right:n.right===!1?e.width:r.right+(n.right===!0?0:n.right),top:n.top===!1?0:r.top-(n.top===!0?0:n.top),bottom:n.bottom===!1?e.height:r.bottom+(n.bottom===!0?0:n.bottom)}}var Do=new class{constructor(){this._request=null,this._charts=new Map,this._running=!1,this._lastDate=void 0}_notify(e,t,n,r){let i=t.listeners[r],a=t.duration;i.forEach(r=>r({chart:e,initial:t.initial,numSteps:a,currentStep:Math.min(n-t.start,a)}))}_refresh(){this._request||=(this._running=!0,ci.call(window,()=>{this._update(),this._request=null,this._running&&this._refresh()}))}_update(e=Date.now()){let t=0;this._charts.forEach((n,r)=>{if(!n.running||!n.items.length)return;let i=n.items,a=i.length-1,o=!1,s;for(;a>=0;--a)s=i[a],s._active?(s._total>n.duration&&(n.duration=s._total),s.tick(e),o=!0):(i[a]=i[i.length-1],i.pop());o&&(r.draw(),this._notify(r,n,e,`progress`)),i.length||(n.running=!1,this._notify(r,n,e,`complete`),n.initial=!1),t+=i.length}),this._lastDate=e,t===0&&(this._running=!1)}_getAnims(e){let t=this._charts,n=t.get(e);return n||(n={running:!1,initial:!0,items:[],listeners:{complete:[],progress:[]}},t.set(e,n)),n}listen(e,t,n){this._getAnims(e).listeners[t].push(n)}add(e,t){!t||!t.length||this._getAnims(e).items.push(...t)}has(e){return this._getAnims(e).items.length>0}start(e){let t=this._charts.get(e);t&&(t.running=!0,t.start=Date.now(),t.duration=t.items.reduce((e,t)=>Math.max(e,t._duration),0),this._refresh())}running(e){if(!this._running)return!1;let t=this._charts.get(e);return!(!t||!t.running||!t.items.length)}stop(e){let t=this._charts.get(e);if(!t||!t.items.length)return;let n=t.items,r=n.length-1;for(;r>=0;--r)n[r].cancel();t.items=[],this._notify(e,t,Date.now(),`complete`)}remove(e){return this._charts.delete(e)}},Oo=`transparent`,ko={boolean(e,t,n){return n>.5?t:e},color(e,t,n){let r=xi(e||Oo),i=r.valid&&xi(t||Oo);return i&&i.valid?i.mix(r,n).hexString():t},number(e,t,n){return e+(t-e)*n}},Ao=class{constructor(e,t,n,r){let i=t[n];r=ca([e.to,r,i,e.from]);let a=ca([e.from,i,r]);this._active=!0,this._fn=e.fn||ko[e.type||typeof a],this._easing=yi[e.easing]||yi.linear,this._start=Math.floor(Date.now()+(e.delay||0)),this._duration=this._total=Math.floor(e.duration),this._loop=!!e.loop,this._target=t,this._prop=n,this._from=a,this._to=r,this._promises=void 0}active(){return this._active}update(e,t,n){if(this._active){this._notify(!1);let r=this._target[this._prop],i=n-this._start,a=this._duration-i;this._start=n,this._duration=Math.floor(Math.max(a,e.duration)),this._total+=i,this._loop=!!e.loop,this._to=ca([e.to,t,r,e.from]),this._from=ca([e.from,r,t])}}cancel(){this._active&&(this.tick(Date.now()),this._active=!1,this._notify(!1))}tick(e){let t=e-this._start,n=this._duration,r=this._prop,i=this._from,a=this._loop,o=this._to,s;if(this._active=i!==o&&(a||t<n),!this._active){this._target[r]=o,this._notify(!0);return}if(t<0){this._target[r]=i;return}s=t/n%2,s=a&&s>1?2-s:s,s=this._easing(Math.min(1,Math.max(0,s))),this._target[r]=this._fn(i,o,s)}wait(){let e=this._promises||=[];return new Promise((t,n)=>{e.push({res:t,rej:n})})}_notify(e){let t=e?`res`:`rej`,n=this._promises||[];for(let e=0;e<n.length;e++)n[e][t]()}},jo=class{constructor(e,t){this._chart=e,this._properties=new Map,this.configure(t)}configure(e){if(!R(e))return;let t=Object.keys(J.animation),n=this._properties;Object.getOwnPropertyNames(e).forEach(r=>{let i=e[r];if(!R(i))return;let a={};for(let e of t)a[e]=i[e];(L(i.properties)&&i.properties||[r]).forEach(e=>{(e===r||!n.has(e))&&n.set(e,a)})})}_animateOptions(e,t){let n=t.options,r=No(e,n);if(!r)return[];let i=this._createAnimations(r,n);return n.$shared&&Mo(e.options.$animations,n).then(()=>{e.options=n},()=>{}),i}_createAnimations(e,t){let n=this._properties,r=[],i=e.$animations||={},a=Object.keys(t),o=Date.now(),s;for(s=a.length-1;s>=0;--s){let c=a[s];if(c.charAt(0)===`$`)continue;if(c===`options`){r.push(...this._animateOptions(e,t));continue}let l=t[c],u=i[c],d=n.get(c);if(u)if(d&&u.active()){u.update(d,l,o);continue}else u.cancel();if(!d||!d.duration){e[c]=l;continue}i[c]=u=new Ao(d,e,c,l),r.push(u)}return r}update(e,t){if(this._properties.size===0){Object.assign(e,t);return}let n=this._createAnimations(e,t);if(n.length)return Do.add(this._chart,n),!0}};function Mo(e,t){let n=[],r=Object.keys(t);for(let t=0;t<r.length;t++){let i=e[r[t]];i&&i.active()&&n.push(i.wait())}return Promise.all(n)}function No(e,t){if(!t)return;let n=e.options;if(!n){e.options=t;return}return n.$shared&&(e.options=n=Object.assign({},n,{$shared:!1,$animations:{}})),n}function Po(e,t){let n=e&&e.options||{},r=n.reverse,i=n.min===void 0?t:0,a=n.max===void 0?t:0;return{start:r?a:i,end:r?i:a}}function Fo(e,t,n){if(n===!1)return!1;let r=Po(e,n),i=Po(t,n);return{top:i.end,right:r.end,bottom:i.start,left:r.start}}function Io(e){let t,n,r,i;return R(e)?(t=e.top,n=e.right,r=e.bottom,i=e.left):t=n=r=i=e,{top:t,right:n,bottom:r,left:i,disabled:e===!1}}function Lo(e,t){let n=[],r=e._getSortedDatasetMetas(t),i,a;for(i=0,a=r.length;i<a;++i)n.push(r[i].index);return n}function Ro(e,t,n,r={}){let i=e.keys,a=r.mode===`single`,o,s,c,l;if(t===null)return;let u=!1;for(o=0,s=i.length;o<s;++o){if(c=+i[o],c===n){if(u=!0,r.all)continue;break}l=e.values[c],z(l)&&(a||t===0||Lr(t)===Lr(l))&&(t+=l)}return!u&&!r.all?0:t}function zo(e,t){let{iScale:n,vScale:r}=t,i=n.axis===`x`?`x`:`y`,a=r.axis===`x`?`x`:`y`,o=Object.keys(e),s=Array(o.length),c,l,u;for(c=0,l=o.length;c<l;++c)u=o[c],s[c]={[i]:u,[a]:e[u]};return s}function Bo(e,t){let n=e&&e.options.stacked;return n||n===void 0&&t.stack!==void 0}function Vo(e,t,n){return`${e.id}.${t.id}.${n.stack||n.type}`}function Ho(e){let{min:t,max:n,minDefined:r,maxDefined:i}=e.getUserBounds();return{min:r?t:-1/0,max:i?n:1/0}}function Uo(e,t,n){let r=e[t]||(e[t]={});return r[n]||(r[n]={})}function Wo(e,t,n,r){for(let i of t.getMatchingVisibleMetas(r).reverse()){let t=e[i.index];if(n&&t>0||!n&&t<0)return i.index}return null}function Go(e,t){let{chart:n,_cachedMeta:r}=e,i=n._stacks||={},{iScale:a,vScale:o,index:s}=r,c=a.axis,l=o.axis,u=Vo(a,o,r),d=t.length,f;for(let e=0;e<d;++e){let n=t[e],{[c]:a,[l]:d}=n,p=n._stacks||={};f=p[l]=Uo(i,u,a),f[s]=d,f._top=Wo(f,o,!0,r.type),f._bottom=Wo(f,o,!1,r.type);let m=f._visualValues||={};m[s]=d}}function Ko(e,t){let n=e.scales;return Object.keys(n).filter(e=>n[e].axis===t).shift()}function qo(e,t){return ua(e,{active:!1,dataset:void 0,datasetIndex:t,index:t,mode:`default`,type:`dataset`})}function Jo(e,t,n){return ua(e,{active:!1,dataIndex:t,parsed:void 0,raw:void 0,element:n,index:t,mode:`default`,type:`data`})}function Yo(e,t){let n=e.controller.index,r=e.vScale&&e.vScale.axis;if(r){t||=e._parsed;for(let e of t){let t=e._stacks;if(!t||t[r]===void 0||t[r][n]===void 0)return;delete t[r][n],t[r]._visualValues!==void 0&&t[r]._visualValues[n]!==void 0&&delete t[r]._visualValues[n]}}}var Xo=e=>e===`reset`||e===`none`,Zo=(e,t)=>t?e:Object.assign({},e),Qo=(e,t,n)=>e&&!t.hidden&&t._stacked&&{keys:Lo(n,!0),values:null},$o=class{constructor(e,t){this.chart=e,this._ctx=e.ctx,this.index=t,this._cachedDataOpts={},this._cachedMeta=this.getMeta(),this._type=this._cachedMeta.type,this.options=void 0,this._parsing=!1,this._data=void 0,this._objectData=void 0,this._sharedOptions=void 0,this._drawStart=void 0,this._drawCount=void 0,this.enableOptionSharing=!1,this.supportsDecimation=!1,this.$context=void 0,this._syncList=[],this.datasetElementType=new.target.datasetElementType,this.dataElementType=new.target.dataElementType,this.initialize()}initialize(){let e=this._cachedMeta;this.configure(),this.linkScales(),e._stacked=Bo(e.vScale,e),this.addElements(),this.options.fill&&!this.chart.isPluginEnabled(`filler`)&&console.warn(`Tried to use the 'fill' option without the 'Filler' plugin enabled. Please import and register the 'Filler' plugin and make sure it is not disabled in the options`)}updateIndex(e){this.index!==e&&Yo(this._cachedMeta),this.index=e}linkScales(){let e=this.chart,t=this._cachedMeta,n=this.getDataset(),r=(e,t,n,r)=>e===`x`?t:e===`r`?r:n,i=t.xAxisID=B(n.xAxisID,Ko(e,`x`)),a=t.yAxisID=B(n.yAxisID,Ko(e,`y`)),o=t.rAxisID=B(n.rAxisID,Ko(e,`r`)),s=t.indexAxis,c=t.iAxisID=r(s,i,a,o),l=t.vAxisID=r(s,a,i,o);t.xScale=this.getScaleForId(i),t.yScale=this.getScaleForId(a),t.rScale=this.getScaleForId(o),t.iScale=this.getScaleForId(c),t.vScale=this.getScaleForId(l)}getDataset(){return this.chart.data.datasets[this.index]}getMeta(){return this.chart.getDatasetMeta(this.index)}getScaleForId(e){return this.chart.scales[e]}_getOtherScale(e){let t=this._cachedMeta;return e===t.iScale?t.vScale:t.iScale}reset(){this._update(`reset`)}_destroy(){let e=this._cachedMeta;this._data&&oi(this._data,this),e._stacked&&Yo(e)}_dataCheck(){let e=this.getDataset(),t=e.data||=[],n=this._data;if(R(t)){let e=this._cachedMeta;this._data=zo(t,e)}else if(n!==t){if(n){oi(n,this);let e=this._cachedMeta;Yo(e),e._parsed=[]}t&&Object.isExtensible(t)&&ai(t,this),this._syncList=[],this._data=t}}addElements(){let e=this._cachedMeta;this._dataCheck(),this.datasetElementType&&(e.dataset=new this.datasetElementType)}buildOrUpdateElements(e){let t=this._cachedMeta,n=this.getDataset(),r=!1;this._dataCheck();let i=t._stacked;t._stacked=Bo(t.vScale,t),t.stack!==n.stack&&(r=!0,Yo(t),t.stack=n.stack),this._resyncElements(e),(r||i!==t._stacked)&&(Go(this,t._parsed),t._stacked=Bo(t.vScale,t))}configure(){let e=this.chart.config,t=e.datasetScopeKeys(this._type),n=e.getOptionScopes(this.getDataset(),t,!0);this.options=e.createResolver(n,this.getContext()),this._parsing=this.options.parsing,this._cachedDataOpts={}}parse(e,t){let{_cachedMeta:n,_data:r}=this,{iScale:i,_stacked:a}=n,o=i.axis,s=e===0&&t===r.length?!0:n._sorted,c=e>0&&n._parsed[e-1],l,u,d;if(this._parsing===!1)n._parsed=r,n._sorted=!0,d=r;else{d=L(r[e])?this.parseArrayData(n,r,e,t):R(r[e])?this.parseObjectData(n,r,e,t):this.parsePrimitiveData(n,r,e,t);let i=()=>u[o]===null||c&&u[o]<c[o];for(l=0;l<t;++l)n._parsed[l+e]=u=d[l],s&&(i()&&(s=!1),c=u);n._sorted=s}a&&Go(this,d)}parsePrimitiveData(e,t,n,r){let{iScale:i,vScale:a}=e,o=i.axis,s=a.axis,c=i.getLabels(),l=i===a,u=Array(r),d,f,p;for(d=0,f=r;d<f;++d)p=d+n,u[d]={[o]:l||i.parse(c[p],p),[s]:a.parse(t[p],p)};return u}parseArrayData(e,t,n,r){let{xScale:i,yScale:a}=e,o=Array(r),s,c,l,u;for(s=0,c=r;s<c;++s)l=s+n,u=t[l],o[s]={x:i.parse(u[0],l),y:a.parse(u[1],l)};return o}parseObjectData(e,t,n,r){let{xScale:i,yScale:a}=e,{xAxisKey:o=`x`,yAxisKey:s=`y`}=this._parsing,c=Array(r),l,u,d,f;for(l=0,u=r;l<u;++l)d=l+n,f=t[d],c[l]={x:i.parse(Tr(f,o),d),y:a.parse(Tr(f,s),d)};return c}getParsed(e){return this._cachedMeta._parsed[e]}getDataElement(e){return this._cachedMeta.data[e]}applyStack(e,t,n){let r=this.chart,i=this._cachedMeta,a=t[e.axis];return Ro({keys:Lo(r,!0),values:t._stacks[e.axis]._visualValues},a,i.index,{mode:n})}updateRangeFromParsed(e,t,n,r){let i=n[t.axis],a=i===null?NaN:i,o=r&&n._stacks[t.axis];r&&o&&(r.values=o,a=Ro(r,i,this._cachedMeta.index)),e.min=Math.min(e.min,a),e.max=Math.max(e.max,a)}getMinMax(e,t){let n=this._cachedMeta,r=n._parsed,i=n._sorted&&e===n.iScale,a=r.length,o=this._getOtherScale(e),s=Qo(t,n,this.chart),c={min:1/0,max:-1/0},{min:l,max:u}=Ho(o),d,f;function p(){f=r[d];let t=f[o.axis];return!z(f[e.axis])||l>t||u<t}for(d=0;d<a&&!(!p()&&(this.updateRangeFromParsed(c,e,f,s),i));++d);if(i){for(d=a-1;d>=0;--d)if(!p()){this.updateRangeFromParsed(c,e,f,s);break}}return c}getAllParsedValues(e){let t=this._cachedMeta._parsed,n=[],r,i,a;for(r=0,i=t.length;r<i;++r)a=t[r][e.axis],z(a)&&n.push(a);return n}getMaxOverflow(){return!1}getLabelAndValue(e){let t=this._cachedMeta,n=t.iScale,r=t.vScale,i=this.getParsed(e);return{label:n?``+n.getLabelForValue(i[n.axis]):``,value:r?``+r.getLabelForValue(i[r.axis]):``}}_update(e){let t=this._cachedMeta;this.update(e||`default`),t._clip=Io(B(this.options.clip,Fo(t.xScale,t.yScale,this.getMaxOverflow())))}update(e){}draw(){let e=this._ctx,t=this.chart,n=this._cachedMeta,r=n.data||[],i=t.chartArea,a=[],o=this._drawStart||0,s=this._drawCount||r.length-o,c=this.options.drawActiveElementsOnTop,l;for(n.dataset&&n.dataset.draw(e,i,o,s),l=o;l<o+s;++l){let t=r[l];t.hidden||(t.active&&c?a.push(t):t.draw(e,i))}for(l=0;l<a.length;++l)a[l].draw(e,i)}getStyle(e,t){let n=t?`active`:`default`;return e===void 0&&this._cachedMeta.dataset?this.resolveDatasetElementOptions(n):this.resolveDataElementOptions(e||0,n)}getContext(e,t,n){let r=this.getDataset(),i;if(e>=0&&e<this._cachedMeta.data.length){let t=this._cachedMeta.data[e];i=t.$context||=Jo(this.getContext(),e,t),i.parsed=this.getParsed(e),i.raw=r.data[e],i.index=i.dataIndex=e}else i=this.$context||=qo(this.chart.getContext(),this.index),i.dataset=r,i.index=i.datasetIndex=this.index;return i.active=!!t,i.mode=n,i}resolveDatasetElementOptions(e){return this._resolveElementOptions(this.datasetElementType.id,e)}resolveDataElementOptions(e,t){return this._resolveElementOptions(this.dataElementType.id,t,e)}_resolveElementOptions(e,t=`default`,n){let r=t===`active`,i=this._cachedDataOpts,a=e+`-`+t,o=i[a],s=this.enableOptionSharing&&Dr(n);if(o)return Zo(o,s);let c=this.chart.config,l=c.datasetElementScopeKeys(this._type,e),u=r?[`${e}Hover`,`hover`,e,``]:[e,``],d=c.getOptionScopes(this.getDataset(),l),f=Object.keys(J.elements[e]),p=c.resolveNamedOptions(d,f,()=>this.getContext(n,r,t),u);return p.$shared&&(p.$shared=s,i[a]=Object.freeze(Zo(p,s))),p}_resolveAnimations(e,t,n){let r=this.chart,i=this._cachedDataOpts,a=`animation-${t}`,o=i[a];if(o)return o;let s;if(r.options.animation!==!1){let r=this.chart.config,i=r.datasetAnimationScopeKeys(this._type,t),a=r.getOptionScopes(this.getDataset(),i);s=r.createResolver(a,this.getContext(e,n,t))}let c=new jo(r,s&&s.animations);return s&&s._cacheable&&(i[a]=Object.freeze(c)),c}getSharedOptions(e){if(e.$shared)return this._sharedOptions||=Object.assign({},e)}includeOptions(e,t){return!t||Xo(e)||this.chart._animationsDisabled}_getSharedOptions(e,t){let n=this.resolveDataElementOptions(e,t),r=this._sharedOptions,i=this.getSharedOptions(n),a=this.includeOptions(t,i)||i!==r;return this.updateSharedOptions(i,t,n),{sharedOptions:i,includeOptions:a}}updateElement(e,t,n,r){Xo(r)?Object.assign(e,n):this._resolveAnimations(t,r).update(e,n)}updateSharedOptions(e,t,n){e&&!Xo(t)&&this._resolveAnimations(void 0,t).update(e,n)}_setStyle(e,t,n,r){e.active=r;let i=this.getStyle(t,r);this._resolveAnimations(t,n,r).update(e,{options:!r&&this.getSharedOptions(i)||i})}removeHoverStyle(e,t,n){this._setStyle(e,n,`active`,!1)}setHoverStyle(e,t,n){this._setStyle(e,n,`active`,!0)}_removeDatasetHoverStyle(){let e=this._cachedMeta.dataset;e&&this._setStyle(e,void 0,`active`,!1)}_setDatasetHoverStyle(){let e=this._cachedMeta.dataset;e&&this._setStyle(e,void 0,`active`,!0)}_resyncElements(e){let t=this._data,n=this._cachedMeta.data;for(let[e,t,n]of this._syncList)this[e](t,n);this._syncList=[];let r=n.length,i=t.length,a=Math.min(i,r);a&&this.parse(0,a),i>r?this._insertElements(r,i-r,e):i<r&&this._removeElements(i,r-i)}_insertElements(e,t,n=!0){let r=this._cachedMeta,i=r.data,a=e+t,o,s=e=>{for(e.length+=t,o=e.length-1;o>=a;o--)e[o]=e[o-t]};for(s(i),o=e;o<a;++o)i[o]=new this.dataElementType;this._parsing&&s(r._parsed),this.parse(e,t),n&&this.updateElements(i,e,t,`reset`)}updateElements(e,t,n,r){}_removeElements(e,t){let n=this._cachedMeta;if(this._parsing){let r=n._parsed.splice(e,t);n._stacked&&Yo(n,r)}n.data.splice(e,t)}_sync(e){if(this._parsing)this._syncList.push(e);else{let[t,n,r]=e;this[t](n,r)}this.chart._dataChanges.push([this.index,...e])}_onDataPush(){let e=arguments.length;this._sync([`_insertElements`,this.getDataset().data.length-e,e])}_onDataPop(){this._sync([`_removeElements`,this._cachedMeta.data.length-1,1])}_onDataShift(){this._sync([`_removeElements`,0,1])}_onDataSplice(e,t){t&&this._sync([`_removeElements`,e,t]);let n=arguments.length-2;n&&this._sync([`_insertElements`,e,n])}_onDataUnshift(){this._sync([`_insertElements`,0,arguments.length])}};f($o,`defaults`,{}),f($o,`datasetElementType`,null),f($o,`dataElementType`,null);function es(e,t){if(!e._cache.$bar){let n=e.getMatchingVisibleMetas(t),r=[];for(let t=0,i=n.length;t<i;t++)r=r.concat(n[t].controller.getAllParsedValues(e));e._cache.$bar=si(r.sort((e,t)=>e-t))}return e._cache.$bar}function ts(e){let t=e.iScale,n=es(t,e.type),r=t._length,i,a,o,s,c=()=>{o===32767||o===-32768||(Dr(s)&&(r=Math.min(r,Math.abs(o-s)||r)),s=o)};for(i=0,a=n.length;i<a;++i)o=t.getPixelForValue(n[i]),c();for(s=void 0,i=0,a=t.ticks.length;i<a;++i)o=t.getPixelForTick(i),c();return r}function ns(e,t,n,r){let i=n.barThickness,a,o;return I(i)?(a=t.min*n.categoryPercentage,o=n.barPercentage):(a=i*r,o=1),{chunk:a/r,ratio:o,start:t.pixels[e]-a/2}}function rs(e,t,n,r){let i=t.pixels,a=i[e],o=e>0?i[e-1]:null,s=e<i.length-1?i[e+1]:null,c=n.categoryPercentage;o===null&&(o=a-(s===null?t.end-t.start:s-a)),s===null&&(s=a+a-o);let l=a-(a-Math.min(o,s))/2*c;return{chunk:Math.abs(s-o)/2*c/r,ratio:n.barPercentage,start:l}}function is(e,t,n,r){let i=n.parse(e[0],r),a=n.parse(e[1],r),o=Math.min(i,a),s=Math.max(i,a),c=o,l=s;Math.abs(o)>Math.abs(s)&&(c=s,l=o),t[n.axis]=l,t._custom={barStart:c,barEnd:l,start:i,end:a,min:o,max:s}}function as(e,t,n,r){return L(e)?is(e,t,n,r):t[n.axis]=n.parse(e,r),t}function os(e,t,n,r){let i=e.iScale,a=e.vScale,o=i.getLabels(),s=i===a,c=[],l,u,d,f;for(l=n,u=n+r;l<u;++l)f=t[l],d={},d[i.axis]=s||i.parse(o[l],l),c.push(as(f,d,a,l));return c}function ss(e){return e&&e.barStart!==void 0&&e.barEnd!==void 0}function cs(e,t,n){return e===0?(t.isHorizontal()?1:-1)*(t.min>=n?1:-1):Lr(e)}function ls(e){let t,n,r,i,a;return e.horizontal?(t=e.base>e.x,n=`left`,r=`right`):(t=e.base<e.y,n=`bottom`,r=`top`),t?(i=`end`,a=`start`):(i=`start`,a=`end`),{start:n,end:r,reverse:t,top:i,bottom:a}}function us(e,t,n,r){let i=t.borderSkipped,a={};if(!i){e.borderSkipped=a;return}if(i===!0){e.borderSkipped={top:!0,right:!0,bottom:!0,left:!0};return}let{start:o,end:s,reverse:c,top:l,bottom:u}=ls(e);i===`middle`&&n&&(e.enableBorderRadius=!0,(n._top||0)===r?i=l:(n._bottom||0)===r?i=u:(a[ds(u,o,s,c)]=!0,i=l)),a[ds(i,o,s,c)]=!0,e.borderSkipped=a}function ds(e,t,n,r){return r?(e=fs(e,t,n),e=ps(e,n,t)):e=ps(e,t,n),e}function fs(e,t,n){return e===t?n:e===n?t:e}function ps(e,t,n){return e===`start`?t:e===`end`?n:e}function ms(e,{inflateAmount:t},n){e.inflateAmount=t===`auto`?n===1?.33:0:t}var hs=class extends $o{parsePrimitiveData(e,t,n,r){return os(e,t,n,r)}parseArrayData(e,t,n,r){return os(e,t,n,r)}parseObjectData(e,t,n,r){let{iScale:i,vScale:a}=e,{xAxisKey:o=`x`,yAxisKey:s=`y`}=this._parsing,c=i.axis===`x`?o:s,l=a.axis===`x`?o:s,u=[],d,f,p,m;for(d=n,f=n+r;d<f;++d)m=t[d],p={},p[i.axis]=i.parse(Tr(m,c),d),u.push(as(Tr(m,l),p,a,d));return u}updateRangeFromParsed(e,t,n,r){super.updateRangeFromParsed(e,t,n,r);let i=n._custom;i&&t===this._cachedMeta.vScale&&(e.min=Math.min(e.min,i.min),e.max=Math.max(e.max,i.max))}getMaxOverflow(){return 0}getLabelAndValue(e){let{iScale:t,vScale:n}=this._cachedMeta,r=this.getParsed(e),i=r._custom,a=ss(i)?`[`+i.start+`, `+i.end+`]`:``+n.getLabelForValue(r[n.axis]);return{label:``+t.getLabelForValue(r[t.axis]),value:a}}initialize(){this.enableOptionSharing=!0,super.initialize();let e=this._cachedMeta;e.stack=this.getDataset().stack}update(e){let t=this._cachedMeta;this.updateElements(t.data,0,t.data.length,e)}updateElements(e,t,n,r){let i=r===`reset`,{index:a,_cachedMeta:{vScale:o}}=this,s=o.getBasePixel(),c=o.isHorizontal(),l=this._getRuler(),{sharedOptions:u,includeOptions:d}=this._getSharedOptions(t,r);for(let f=t;f<t+n;f++){let t=this.getParsed(f),n=i||I(t[o.axis])?{base:s,head:s}:this._calculateBarValuePixels(f),p=this._calculateBarIndexPixels(f,l),m=(t._stacks||{})[o.axis],h={horizontal:c,base:n.base,enableBorderRadius:!m||ss(t._custom)||a===m._top||a===m._bottom,x:c?n.head:p.center,y:c?p.center:n.head,height:c?p.size:Math.abs(n.size),width:c?Math.abs(n.size):p.size};d&&(h.options=u||this.resolveDataElementOptions(f,e[f].active?`active`:r));let g=h.options||e[f].options;us(h,g,m,a),ms(h,g,l.ratio),this.updateElement(e[f],f,h,r)}}_getStacks(e,t){let{iScale:n}=this._cachedMeta,r=n.getMatchingVisibleMetas(this._type).filter(e=>e.controller.options.grouped),i=n.options.stacked,a=[],o=this._cachedMeta.controller.getParsed(t),s=o&&o[n.axis],c=e=>{let t=e._parsed.find(e=>e[n.axis]===s),r=t&&t[e.vScale.axis];if(I(r)||isNaN(r))return!0};for(let n of r)if(!(t!==void 0&&c(n))&&((i===!1||a.indexOf(n.stack)===-1||i===void 0&&n.stack===void 0)&&a.push(n.stack),n.index===e))break;return a.length||a.push(void 0),a}_getStackCount(e){return this._getStacks(void 0,e).length}_getAxisCount(){return this._getAxis().length}getFirstScaleIdForIndexAxis(){let e=this.chart.scales,t=this.chart.options.indexAxis;return Object.keys(e).filter(n=>e[n].axis===t).shift()}_getAxis(){let e={},t=this.getFirstScaleIdForIndexAxis();for(let n of this.chart.data.datasets)e[B(this.chart.options.indexAxis===`x`?n.xAxisID:n.yAxisID,t)]=!0;return Object.keys(e)}_getStackIndex(e,t,n){let r=this._getStacks(e,n),i=t===void 0?-1:r.indexOf(t);return i===-1?r.length-1:i}_getRuler(){let e=this.options,t=this._cachedMeta,n=t.iScale,r=[],i,a;for(i=0,a=t.data.length;i<a;++i)r.push(n.getPixelForValue(this.getParsed(i)[n.axis],i));let o=e.barThickness;return{min:o||ts(t),pixels:r,start:n._startPixel,end:n._endPixel,stackCount:this._getStackCount(),scale:n,grouped:e.grouped,ratio:o?1:e.categoryPercentage*e.barPercentage}}_calculateBarValuePixels(e){let{_cachedMeta:{vScale:t,_stacked:n,index:r},options:{base:i,minBarLength:a}}=this,o=i||0,s=this.getParsed(e),c=s._custom,l=ss(c),u=s[t.axis],d=0,f=n?this.applyStack(t,s,n):u,p,m;f!==u&&(d=f-u,f=u),l&&(u=c.barStart,f=c.barEnd-c.barStart,u!==0&&Lr(u)!==Lr(c.barEnd)&&(d=0),d+=u);let h=!I(i)&&!l?i:d,g=t.getPixelForValue(h);if(p=this.chart.getDataVisibility(e)?t.getPixelForValue(d+f):g,m=p-g,Math.abs(m)<a){m=cs(m,t,o)*a,u===o&&(g-=m/2);let e=t.getPixelForDecimal(0),i=t.getPixelForDecimal(1),c=Math.min(e,i),d=Math.max(e,i);g=Math.max(Math.min(g,d),c),p=g+m,n&&!l&&(s._stacks[t.axis]._visualValues[r]=t.getValueForPixel(p)-t.getValueForPixel(g))}if(g===t.getPixelForValue(o)){let e=Lr(m)*t.getLineWidthForValue(o)/2;g+=e,m-=e}return{size:m,base:g,head:p,center:p+m/2}}_calculateBarIndexPixels(e,t){let n=t.scale,r=this.options,i=r.skipNull,a=B(r.maxBarThickness,1/0),o,s,c=this._getAxisCount();if(t.grouped){let n=i?this._getStackCount(e):t.stackCount,l=r.barThickness===`flex`?rs(e,t,r,n*c):ns(e,t,r,n*c),u=this.chart.options.indexAxis===`x`?this.getDataset().xAxisID:this.getDataset().yAxisID,d=this._getAxis().indexOf(B(u,this.getFirstScaleIdForIndexAxis())),f=this._getStackIndex(this.index,this._cachedMeta.stack,i?e:void 0)+d;o=l.start+l.chunk*f+l.chunk/2,s=Math.min(a,l.chunk*l.ratio)}else o=n.getPixelForValue(this.getParsed(e)[n.axis],e),s=Math.min(a,t.min*t.ratio);return{base:o-s/2,head:o+s/2,center:o,size:s}}draw(){let e=this._cachedMeta,t=e.vScale,n=e.data,r=n.length,i=0;for(;i<r;++i)this.getParsed(i)[t.axis]!==null&&!n[i].hidden&&n[i].draw(this._ctx)}};f(hs,`id`,`bar`),f(hs,`defaults`,{datasetElementType:!1,dataElementType:`bar`,categoryPercentage:.8,barPercentage:.9,grouped:!0,animations:{numbers:{type:`number`,properties:[`x`,`y`,`base`,`width`,`height`]}}}),f(hs,`overrides`,{scales:{_index_:{type:`category`,offset:!0,grid:{offset:!0}},_value_:{type:`linear`,beginAtZero:!0}}});var gs=class extends $o{initialize(){this.enableOptionSharing=!0,super.initialize()}parsePrimitiveData(e,t,n,r){let i=super.parsePrimitiveData(e,t,n,r);for(let e=0;e<i.length;e++)i[e]._custom=this.resolveDataElementOptions(e+n).radius;return i}parseArrayData(e,t,n,r){let i=super.parseArrayData(e,t,n,r);for(let e=0;e<i.length;e++){let r=t[n+e];i[e]._custom=B(r[2],this.resolveDataElementOptions(e+n).radius)}return i}parseObjectData(e,t,n,r){let i=super.parseObjectData(e,t,n,r);for(let e=0;e<i.length;e++){let r=t[n+e];i[e]._custom=B(r&&r.r&&+r.r,this.resolveDataElementOptions(e+n).radius)}return i}getMaxOverflow(){let e=this._cachedMeta.data,t=0;for(let n=e.length-1;n>=0;--n)t=Math.max(t,e[n].size(this.resolveDataElementOptions(n))/2);return t>0&&t}getLabelAndValue(e){let t=this._cachedMeta,n=this.chart.data.labels||[],{xScale:r,yScale:i}=t,a=this.getParsed(e),o=r.getLabelForValue(a.x),s=i.getLabelForValue(a.y),c=a._custom;return{label:n[e]||``,value:`(`+o+`, `+s+(c?`, `+c:``)+`)`}}update(e){let t=this._cachedMeta.data;this.updateElements(t,0,t.length,e)}updateElements(e,t,n,r){let i=r===`reset`,{iScale:a,vScale:o}=this._cachedMeta,{sharedOptions:s,includeOptions:c}=this._getSharedOptions(t,r),l=a.axis,u=o.axis;for(let d=t;d<t+n;d++){let t=e[d],n=!i&&this.getParsed(d),f={},p=f[l]=i?a.getPixelForDecimal(.5):a.getPixelForValue(n[l]),m=f[u]=i?o.getBasePixel():o.getPixelForValue(n[u]);f.skip=isNaN(p)||isNaN(m),c&&(f.options=s||this.resolveDataElementOptions(d,t.active?`active`:r),i&&(f.options.radius=0)),this.updateElement(t,d,f,r)}}resolveDataElementOptions(e,t){let n=this.getParsed(e),r=super.resolveDataElementOptions(e,t);r.$shared&&(r=Object.assign({},r,{$shared:!1}));let i=r.radius;return t!==`active`&&(r.radius=0),r.radius+=B(n&&n._custom,i),r}};f(gs,`id`,`bubble`),f(gs,`defaults`,{datasetElementType:!1,dataElementType:`point`,animations:{numbers:{type:`number`,properties:[`x`,`y`,`borderWidth`,`radius`]}}}),f(gs,`overrides`,{scales:{x:{type:`linear`},y:{type:`linear`}}});function _s(e,t,n){let r=1,i=1,a=0,o=0;if(t<W){let s=e,c=s+t,l=Math.cos(s),u=Math.sin(s),d=Math.cos(c),f=Math.sin(c),p=(e,t,r)=>Zr(e,s,c,!0)?1:Math.max(t,t*n,r,r*n),m=(e,t,r)=>Zr(e,s,c,!0)?-1:Math.min(t,t*n,r,r*n),h=p(0,l,d),g=p(G,u,f),_=m(U,l,d),v=m(U+G,u,f);r=(h-_)/2,i=(g-v)/2,a=-(h+_)/2,o=-(g+v)/2}return{ratioX:r,ratioY:i,offsetX:a,offsetY:o}}var vs=class extends $o{constructor(e,t){super(e,t),this.enableOptionSharing=!0,this.innerRadius=void 0,this.outerRadius=void 0,this.offsetX=void 0,this.offsetY=void 0}linkScales(){}parse(e,t){let n=this.getDataset().data,r=this._cachedMeta;if(this._parsing===!1)r._parsed=n;else{let i=e=>+n[e];if(R(n[e])){let{key:e=`value`}=this._parsing;i=t=>+Tr(n[t],e)}let a,o;for(a=e,o=e+t;a<o;++a)r._parsed[a]=i(a)}}_getRotation(){return Gr(this.options.rotation-90)}_getCircumference(){return Gr(this.options.circumference)}_getRotationExtents(){let e=W,t=-W;for(let n=0;n<this.chart.data.datasets.length;++n)if(this.chart.isDatasetVisible(n)&&this.chart.getDatasetMeta(n).type===this._type){let r=this.chart.getDatasetMeta(n).controller,i=r._getRotation(),a=r._getCircumference();e=Math.min(e,i),t=Math.max(t,i+a)}return{rotation:e,circumference:t-e}}update(e){let{chartArea:t}=this.chart,n=this._cachedMeta,r=n.data,i=this.getMaxBorderWidth()+this.getMaxOffset(r)+this.options.spacing,a=Math.max((Math.min(t.width,t.height)-i)/2,0),o=Math.min(pr(this.options.cutout,a),1),s=this._getRingWeight(this.index),{circumference:c,rotation:l}=this._getRotationExtents(),{ratioX:u,ratioY:d,offsetX:f,offsetY:p}=_s(l,c,o),m=(t.width-i)/u,h=(t.height-i)/d,g=Math.max(Math.min(m,h)/2,0),_=mr(this.options.radius,g),v=(_-Math.max(_*o,0))/this._getVisibleDatasetWeightTotal();this.offsetX=f*_,this.offsetY=p*_,n.total=this.calculateTotal(),this.outerRadius=_-v*this._getRingWeightOffset(this.index),this.innerRadius=Math.max(this.outerRadius-v*s,0),this.updateElements(r,0,r.length,e)}_circumference(e,t){let n=this.options,r=this._cachedMeta,i=this._getCircumference();return t&&n.animation.animateRotate||!this.chart.getDataVisibility(e)||r._parsed[e]===null||r.data[e].hidden?0:this.calculateCircumference(r._parsed[e]*i/W)}updateElements(e,t,n,r){let i=r===`reset`,a=this.chart,o=a.chartArea,s=a.options.animation,c=(o.left+o.right)/2,l=(o.top+o.bottom)/2,u=i&&s.animateScale,d=u?0:this.innerRadius,f=u?0:this.outerRadius,{sharedOptions:p,includeOptions:m}=this._getSharedOptions(t,r),h=this._getRotation(),g;for(g=0;g<t;++g)h+=this._circumference(g,i);for(g=t;g<t+n;++g){let t=this._circumference(g,i),n=e[g],a={x:c+this.offsetX,y:l+this.offsetY,startAngle:h,endAngle:h+t,circumference:t,outerRadius:f,innerRadius:d};m&&(a.options=p||this.resolveDataElementOptions(g,n.active?`active`:r)),h+=t,this.updateElement(n,g,a,r)}}calculateTotal(){let e=this._cachedMeta,t=e.data,n=0,r;for(r=0;r<t.length;r++){let i=e._parsed[r];i!==null&&!isNaN(i)&&this.chart.getDataVisibility(r)&&!t[r].hidden&&(n+=Math.abs(i))}return n}calculateCircumference(e){let t=this._cachedMeta.total;return t>0&&!isNaN(e)?Math.abs(e)/t*W:0}getLabelAndValue(e){let t=this._cachedMeta,n=this.chart,r=n.data.labels||[],i=ki(t._parsed[e],n.options.locale);return{label:r[e]||``,value:i}}getMaxBorderWidth(e){let t=0,n=this.chart,r,i,a,o,s;if(!e){for(r=0,i=n.data.datasets.length;r<i;++r)if(n.isDatasetVisible(r)){a=n.getDatasetMeta(r),e=a.data,o=a.controller;break}}if(!e)return 0;for(r=0,i=e.length;r<i;++r)s=o.resolveDataElementOptions(r),s.borderAlign!==`inner`&&(t=Math.max(t,s.borderWidth||0,s.hoverBorderWidth||0));return t}getMaxOffset(e){let t=0;for(let n=0,r=e.length;n<r;++n){let e=this.resolveDataElementOptions(n);t=Math.max(t,e.offset||0,e.hoverOffset||0)}return t}_getRingWeightOffset(e){let t=0;for(let n=0;n<e;++n)this.chart.isDatasetVisible(n)&&(t+=this._getRingWeight(n));return t}_getRingWeight(e){return Math.max(B(this.chart.data.datasets[e].weight,1),0)}_getVisibleDatasetWeightTotal(){return this._getRingWeightOffset(this.chart.data.datasets.length)||1}};f(vs,`id`,`doughnut`),f(vs,`defaults`,{datasetElementType:!1,dataElementType:`arc`,animation:{animateRotate:!0,animateScale:!1},animations:{numbers:{type:`number`,properties:[`circumference`,`endAngle`,`innerRadius`,`outerRadius`,`startAngle`,`x`,`y`,`offset`,`borderWidth`,`spacing`]}},cutout:`50%`,rotation:0,circumference:360,radius:`100%`,spacing:0,indexAxis:`r`}),f(vs,`descriptors`,{_scriptable:e=>e!==`spacing`,_indexable:e=>e!==`spacing`&&!e.startsWith(`borderDash`)&&!e.startsWith(`hoverBorderDash`)}),f(vs,`overrides`,{aspectRatio:1,plugins:{legend:{labels:{generateLabels(e){let t=e.data,{labels:{pointStyle:n,textAlign:r,color:i,useBorderRadius:a,borderRadius:o}}=e.legend.options;return t.labels.length&&t.datasets.length?t.labels.map((t,s)=>{let c=e.getDatasetMeta(0).controller.getStyle(s);return{text:t,fillStyle:c.backgroundColor,fontColor:i,hidden:!e.getDataVisibility(s),lineDash:c.borderDash,lineDashOffset:c.borderDashOffset,lineJoin:c.borderJoinStyle,lineWidth:c.borderWidth,strokeStyle:c.borderColor,textAlign:r,pointStyle:n,borderRadius:a&&(o||c.borderRadius),index:s}}):[]}},onClick(e,t,n){n.chart.toggleDataVisibility(t.index),n.chart.update()}}}});var ys=class extends $o{initialize(){this.enableOptionSharing=!0,this.supportsDecimation=!0,super.initialize()}update(e){let t=this._cachedMeta,{dataset:n,data:r=[],_dataset:i}=t,a=this.chart._animationsDisabled,{start:o,count:s}=mi(t,r,a);this._drawStart=o,this._drawCount=s,hi(t)&&(o=0,s=r.length),n._chart=this.chart,n._datasetIndex=this.index,n._decimated=!!i._decimated,n.points=r;let c=this.resolveDatasetElementOptions(e);this.options.showLine||(c.borderWidth=0),c.segment=this.options.segment,this.updateElement(n,void 0,{animated:!a,options:c},e),this.updateElements(r,o,s,e)}updateElements(e,t,n,r){let i=r===`reset`,{iScale:a,vScale:o,_stacked:s,_dataset:c}=this._cachedMeta,{sharedOptions:l,includeOptions:u}=this._getSharedOptions(t,r),d=a.axis,f=o.axis,{spanGaps:p,segment:m}=this.options,h=Hr(p)?p:1/0,g=this.chart._animationsDisabled||i||r===`none`,_=t+n,v=e.length,y=t>0&&this.getParsed(t-1);for(let n=0;n<v;++n){let p=e[n],v=g?p:{};if(n<t||n>=_){v.skip=!0;continue}let b=this.getParsed(n),x=I(b[f]),S=v[d]=a.getPixelForValue(b[d],n),C=v[f]=i||x?o.getBasePixel():o.getPixelForValue(s?this.applyStack(o,b,s):b[f],n);v.skip=isNaN(S)||isNaN(C)||x,v.stop=n>0&&Math.abs(b[d]-y[d])>h,m&&(v.parsed=b,v.raw=c.data[n]),u&&(v.options=l||this.resolveDataElementOptions(n,p.active?`active`:r)),g||this.updateElement(p,n,v,r),y=b}}getMaxOverflow(){let e=this._cachedMeta,t=e.dataset,n=t.options&&t.options.borderWidth||0,r=e.data||[];if(!r.length)return n;let i=r[0].size(this.resolveDataElementOptions(0)),a=r[r.length-1].size(this.resolveDataElementOptions(r.length-1));return Math.max(n,i,a)/2}draw(){let e=this._cachedMeta;e.dataset.updateControlPoints(this.chart.chartArea,e.iScale.axis),super.draw()}};f(ys,`id`,`line`),f(ys,`defaults`,{datasetElementType:`line`,dataElementType:`point`,showLine:!0,spanGaps:!1}),f(ys,`overrides`,{scales:{_index_:{type:`category`},_value_:{type:`linear`}}});var bs=class extends $o{constructor(e,t){super(e,t),this.innerRadius=void 0,this.outerRadius=void 0}getLabelAndValue(e){let t=this._cachedMeta,n=this.chart,r=n.data.labels||[],i=ki(t._parsed[e].r,n.options.locale);return{label:r[e]||``,value:i}}parseObjectData(e,t,n,r){return Aa.bind(this)(e,t,n,r)}update(e){let t=this._cachedMeta.data;this._updateRadius(),this.updateElements(t,0,t.length,e)}getMinMax(){let e=this._cachedMeta,t={min:1/0,max:-1/0};return e.data.forEach((e,n)=>{let r=this.getParsed(n).r;!isNaN(r)&&this.chart.getDataVisibility(n)&&(r<t.min&&(t.min=r),r>t.max&&(t.max=r))}),t}_updateRadius(){let e=this.chart,t=e.chartArea,n=e.options,r=Math.min(t.right-t.left,t.bottom-t.top),i=Math.max(r/2,0),a=(i-Math.max(n.cutoutPercentage?i/100*n.cutoutPercentage:1,0))/e.getVisibleDatasetCount();this.outerRadius=i-a*this.index,this.innerRadius=this.outerRadius-a}updateElements(e,t,n,r){let i=r===`reset`,a=this.chart,o=a.options.animation,s=this._cachedMeta.rScale,c=s.xCenter,l=s.yCenter,u=s.getIndexAngle(0)-.5*U,d=u,f,p=360/this.countVisibleElements();for(f=0;f<t;++f)d+=this._computeAngle(f,r,p);for(f=t;f<t+n;f++){let t=e[f],n=d,m=d+this._computeAngle(f,r,p),h=a.getDataVisibility(f)?s.getDistanceFromCenterForValue(this.getParsed(f).r):0;d=m,i&&(o.animateScale&&(h=0),o.animateRotate&&(n=m=u));let g={x:c,y:l,innerRadius:0,outerRadius:h,startAngle:n,endAngle:m,options:this.resolveDataElementOptions(f,t.active?`active`:r)};this.updateElement(t,f,g,r)}}countVisibleElements(){let e=this._cachedMeta,t=0;return e.data.forEach((e,n)=>{!isNaN(this.getParsed(n).r)&&this.chart.getDataVisibility(n)&&t++}),t}_computeAngle(e,t,n){return this.chart.getDataVisibility(e)?Gr(this.resolveDataElementOptions(e,t).angle||n):0}};f(bs,`id`,`polarArea`),f(bs,`defaults`,{dataElementType:`arc`,animation:{animateRotate:!0,animateScale:!0},animations:{numbers:{type:`number`,properties:[`x`,`y`,`startAngle`,`endAngle`,`innerRadius`,`outerRadius`]}},indexAxis:`r`,startAngle:0}),f(bs,`overrides`,{aspectRatio:1,plugins:{legend:{labels:{generateLabels(e){let t=e.data;if(t.labels.length&&t.datasets.length){let{labels:{pointStyle:n,color:r}}=e.legend.options;return t.labels.map((t,i)=>{let a=e.getDatasetMeta(0).controller.getStyle(i);return{text:t,fillStyle:a.backgroundColor,strokeStyle:a.borderColor,fontColor:r,lineWidth:a.borderWidth,pointStyle:n,hidden:!e.getDataVisibility(i),index:i}})}return[]}},onClick(e,t,n){n.chart.toggleDataVisibility(t.index),n.chart.update()}}},scales:{r:{type:`radialLinear`,angleLines:{display:!1},beginAtZero:!0,grid:{circular:!0},pointLabels:{display:!1},startAngle:0}}});var xs=class extends vs{};f(xs,`id`,`pie`),f(xs,`defaults`,{cutout:0,rotation:0,circumference:360,radius:`100%`});var Ss=class extends $o{getLabelAndValue(e){let t=this._cachedMeta.vScale,n=this.getParsed(e);return{label:t.getLabels()[e],value:``+t.getLabelForValue(n[t.axis])}}parseObjectData(e,t,n,r){return Aa.bind(this)(e,t,n,r)}update(e){let t=this._cachedMeta,n=t.dataset,r=t.data||[],i=t.iScale.getLabels();if(n.points=r,e!==`resize`){let t=this.resolveDatasetElementOptions(e);this.options.showLine||(t.borderWidth=0);let a={_loop:!0,_fullLoop:i.length===r.length,options:t};this.updateElement(n,void 0,a,e)}this.updateElements(r,0,r.length,e)}updateElements(e,t,n,r){let i=this._cachedMeta.rScale,a=r===`reset`;for(let o=t;o<t+n;o++){let t=e[o],n=this.resolveDataElementOptions(o,t.active?`active`:r),s=i.getPointPositionForValue(o,this.getParsed(o).r),c=a?i.xCenter:s.x,l=a?i.yCenter:s.y,u={x:c,y:l,angle:s.angle,skip:isNaN(c)||isNaN(l),options:n};this.updateElement(t,o,u,r)}}};f(Ss,`id`,`radar`),f(Ss,`defaults`,{datasetElementType:`line`,dataElementType:`point`,indexAxis:`r`,showLine:!0,elements:{line:{fill:`start`}}}),f(Ss,`overrides`,{aspectRatio:1,scales:{r:{type:`radialLinear`}}});var Cs=class extends $o{getLabelAndValue(e){let t=this._cachedMeta,n=this.chart.data.labels||[],{xScale:r,yScale:i}=t,a=this.getParsed(e),o=r.getLabelForValue(a.x),s=i.getLabelForValue(a.y);return{label:n[e]||``,value:`(`+o+`, `+s+`)`}}update(e){let t=this._cachedMeta,{data:n=[]}=t,r=this.chart._animationsDisabled,{start:i,count:a}=mi(t,n,r);if(this._drawStart=i,this._drawCount=a,hi(t)&&(i=0,a=n.length),this.options.showLine){this.datasetElementType||this.addElements();let{dataset:i,_dataset:a}=t;i._chart=this.chart,i._datasetIndex=this.index,i._decimated=!!a._decimated,i.points=n;let o=this.resolveDatasetElementOptions(e);o.segment=this.options.segment,this.updateElement(i,void 0,{animated:!r,options:o},e)}else this.datasetElementType&&=(delete t.dataset,!1);this.updateElements(n,i,a,e)}addElements(){let{showLine:e}=this.options;!this.datasetElementType&&e&&(this.datasetElementType=this.chart.registry.getElement(`line`)),super.addElements()}updateElements(e,t,n,r){let i=r===`reset`,{iScale:a,vScale:o,_stacked:s,_dataset:c}=this._cachedMeta,l=this.resolveDataElementOptions(t,r),u=this.getSharedOptions(l),d=this.includeOptions(r,u),f=a.axis,p=o.axis,{spanGaps:m,segment:h}=this.options,g=Hr(m)?m:1/0,_=this.chart._animationsDisabled||i||r===`none`,v=t>0&&this.getParsed(t-1);for(let l=t;l<t+n;++l){let t=e[l],n=this.getParsed(l),m=_?t:{},y=I(n[p]),b=m[f]=a.getPixelForValue(n[f],l),x=m[p]=i||y?o.getBasePixel():o.getPixelForValue(s?this.applyStack(o,n,s):n[p],l);m.skip=isNaN(b)||isNaN(x)||y,m.stop=l>0&&Math.abs(n[f]-v[f])>g,h&&(m.parsed=n,m.raw=c.data[l]),d&&(m.options=u||this.resolveDataElementOptions(l,t.active?`active`:r)),_||this.updateElement(t,l,m,r),v=n}this.updateSharedOptions(u,r,l)}getMaxOverflow(){let e=this._cachedMeta,t=e.data||[];if(!this.options.showLine){let e=0;for(let n=t.length-1;n>=0;--n)e=Math.max(e,t[n].size(this.resolveDataElementOptions(n))/2);return e>0&&e}let n=e.dataset,r=n.options&&n.options.borderWidth||0;if(!t.length)return r;let i=t[0].size(this.resolveDataElementOptions(0)),a=t[t.length-1].size(this.resolveDataElementOptions(t.length-1));return Math.max(r,i,a)/2}};f(Cs,`id`,`scatter`),f(Cs,`defaults`,{datasetElementType:!1,dataElementType:`point`,showLine:!1,fill:!1}),f(Cs,`overrides`,{interaction:{mode:`point`},scales:{x:{type:`linear`},y:{type:`linear`}}});function ws(){throw Error(`This method is not implemented: Check that a complete date adapter is provided.`)}var Ts={_date:class e{static override(t){Object.assign(e.prototype,t)}constructor(e){f(this,`options`,void 0),this.options=e||{}}init(){}formats(){return ws()}parse(){return ws()}format(){return ws()}add(){return ws()}diff(){return ws()}startOf(){return ws()}endOf(){return ws()}}};function Es(e,t,n,r){let{controller:i,data:a,_sorted:o}=e,s=i._cachedMeta.iScale,c=e.dataset&&e.dataset.options?e.dataset.options.spanGaps:null;if(s&&t===s.axis&&t!==`r`&&o&&a.length){let o=s._reversePixels?ni:ti;if(!r){let r=o(a,t,n);if(c){let{vScale:t}=i._cachedMeta,{_parsed:n}=e,a=n.slice(0,r.lo+1).reverse().findIndex(e=>!I(e[t.axis]));r.lo-=Math.max(0,a);let o=n.slice(r.hi).findIndex(e=>!I(e[t.axis]));r.hi+=Math.max(0,o)}return r}else if(i._sharedOptions){let e=a[0],r=typeof e.getRange==`function`&&e.getRange(t);if(r){let e=o(a,t,n-r),i=o(a,t,n+r);return{lo:e.lo,hi:i.hi}}}}return{lo:0,hi:a.length-1}}function Ds(e,t,n,r,i){let a=e.getSortedVisibleDatasetMetas(),o=n[t];for(let e=0,n=a.length;e<n;++e){let{index:n,data:s}=a[e],{lo:c,hi:l}=Es(a[e],t,o,i);for(let e=c;e<=l;++e){let t=s[e];t.skip||r(t,n,e)}}}function Os(e){let t=e.indexOf(`x`)!==-1,n=e.indexOf(`y`)!==-1;return function(e,r){let i=t?Math.abs(e.x-r.x):0,a=n?Math.abs(e.y-r.y):0;return Math.sqrt(i**2+a**2)}}function ks(e,t,n,r,i){let a=[];return!i&&!e.isPointInArea(t)||Ds(e,n,t,function(n,o,s){!i&&!Gi(n,e.chartArea,0)||n.inRange(t.x,t.y,r)&&a.push({element:n,datasetIndex:o,index:s})},!0),a}function As(e,t,n,r){let i=[];function a(e,n,a){let{startAngle:o,endAngle:s}=e.getProps([`startAngle`,`endAngle`],r),{angle:c}=Jr(e,{x:t.x,y:t.y});Zr(c,o,s)&&i.push({element:e,datasetIndex:n,index:a})}return Ds(e,n,t,a),i}function js(e,t,n,r,i,a){let o=[],s=Os(n),c=1/0;function l(n,l,u){let d=n.inRange(t.x,t.y,i);if(r&&!d)return;let f=n.getCenterPoint(i);if(!(a||e.isPointInArea(f))&&!d)return;let p=s(t,f);p<c?(o=[{element:n,datasetIndex:l,index:u}],c=p):p===c&&o.push({element:n,datasetIndex:l,index:u})}return Ds(e,n,t,l),o}function Ms(e,t,n,r,i,a){return!a&&!e.isPointInArea(t)?[]:n===`r`&&!r?As(e,t,n,i):js(e,t,n,r,i,a)}function Ns(e,t,n,r,i){let a=[],o=n===`x`?`inXRange`:`inYRange`,s=!1;return Ds(e,n,t,(e,r,c)=>{e[o]&&e[o](t[n],i)&&(a.push({element:e,datasetIndex:r,index:c}),s||=e.inRange(t.x,t.y,i))}),r&&!s?[]:a}var Ps={evaluateInteractionItems:Ds,modes:{index(e,t,n,r){let i=Xa(t,e),a=n.axis||`x`,o=n.includeInvisible||!1,s=n.intersect?ks(e,i,a,r,o):Ms(e,i,a,!1,r,o),c=[];return s.length?(e.getSortedVisibleDatasetMetas().forEach(e=>{let t=s[0].index,n=e.data[t];n&&!n.skip&&c.push({element:n,datasetIndex:e.index,index:t})}),c):[]},dataset(e,t,n,r){let i=Xa(t,e),a=n.axis||`xy`,o=n.includeInvisible||!1,s=n.intersect?ks(e,i,a,r,o):Ms(e,i,a,!1,r,o);if(s.length>0){let t=s[0].datasetIndex,n=e.getDatasetMeta(t).data;s=[];for(let e=0;e<n.length;++e)s.push({element:n[e],datasetIndex:t,index:e})}return s},point(e,t,n,r){return ks(e,Xa(t,e),n.axis||`xy`,r,n.includeInvisible||!1)},nearest(e,t,n,r){let i=Xa(t,e),a=n.axis||`xy`,o=n.includeInvisible||!1;return Ms(e,i,a,n.intersect,r,o)},x(e,t,n,r){return Ns(e,Xa(t,e),`x`,n.intersect,r)},y(e,t,n,r){return Ns(e,Xa(t,e),`y`,n.intersect,r)}}},Fs=[`left`,`top`,`right`,`bottom`];function Is(e,t){return e.filter(e=>e.pos===t)}function Ls(e,t){return e.filter(e=>Fs.indexOf(e.pos)===-1&&e.box.axis===t)}function Rs(e,t){return e.sort((e,n)=>{let r=t?n:e,i=t?e:n;return r.weight===i.weight?r.index-i.index:r.weight-i.weight})}function zs(e){let t=[],n,r,i,a,o,s;for(n=0,r=(e||[]).length;n<r;++n)i=e[n],{position:a,options:{stack:o,stackWeight:s=1}}=i,t.push({index:n,box:i,pos:a,horizontal:i.isHorizontal(),weight:i.weight,stack:o&&a+o,stackWeight:s});return t}function Bs(e){let t={};for(let n of e){let{stack:e,pos:r,stackWeight:i}=n;if(!e||!Fs.includes(r))continue;let a=t[e]||(t[e]={count:0,placed:0,weight:0,size:0});a.count++,a.weight+=i}return t}function Vs(e,t){let n=Bs(e),{vBoxMaxWidth:r,hBoxMaxHeight:i}=t,a,o,s;for(a=0,o=e.length;a<o;++a){s=e[a];let{fullSize:o}=s.box,c=n[s.stack],l=c&&s.stackWeight/c.weight;s.horizontal?(s.width=l?l*r:o&&t.availableWidth,s.height=i):(s.width=r,s.height=l?l*i:o&&t.availableHeight)}return n}function Hs(e){let t=zs(e),n=Rs(t.filter(e=>e.box.fullSize),!0),r=Rs(Is(t,`left`),!0),i=Rs(Is(t,`right`)),a=Rs(Is(t,`top`),!0),o=Rs(Is(t,`bottom`)),s=Ls(t,`x`),c=Ls(t,`y`);return{fullSize:n,leftAndTop:r.concat(a),rightAndBottom:i.concat(c).concat(o).concat(s),chartArea:Is(t,`chartArea`),vertical:r.concat(i).concat(c),horizontal:a.concat(o).concat(s)}}function Us(e,t,n,r){return Math.max(e[n],t[n])+Math.max(e[r],t[r])}function Ws(e,t){e.top=Math.max(e.top,t.top),e.left=Math.max(e.left,t.left),e.bottom=Math.max(e.bottom,t.bottom),e.right=Math.max(e.right,t.right)}function Gs(e,t,n,r){let{pos:i,box:a}=n,o=e.maxPadding;if(!R(i)){n.size&&(e[i]-=n.size);let t=r[n.stack]||{size:0,count:1};t.size=Math.max(t.size,n.horizontal?a.height:a.width),n.size=t.size/t.count,e[i]+=n.size}a.getPadding&&Ws(o,a.getPadding());let s=Math.max(0,t.outerWidth-Us(o,e,`left`,`right`)),c=Math.max(0,t.outerHeight-Us(o,e,`top`,`bottom`)),l=s!==e.w,u=c!==e.h;return e.w=s,e.h=c,n.horizontal?{same:l,other:u}:{same:u,other:l}}function Ks(e){let t=e.maxPadding;function n(n){let r=Math.max(t[n]-e[n],0);return e[n]+=r,r}e.y+=n(`top`),e.x+=n(`left`),n(`right`),n(`bottom`)}function qs(e,t){let n=t.maxPadding;function r(e){let r={left:0,top:0,right:0,bottom:0};return e.forEach(e=>{r[e]=Math.max(t[e],n[e])}),r}return r(e?[`left`,`right`]:[`top`,`bottom`])}function Js(e,t,n,r){let i=[],a,o,s,c,l,u;for(a=0,o=e.length,l=0;a<o;++a){s=e[a],c=s.box,c.update(s.width||t.w,s.height||t.h,qs(s.horizontal,t));let{same:o,other:d}=Gs(t,n,s,r);l|=o&&i.length,u||=d,c.fullSize||i.push(s)}return l&&Js(i,t,n,r)||u}function Ys(e,t,n,r,i){e.top=n,e.left=t,e.right=t+r,e.bottom=n+i,e.width=r,e.height=i}function Xs(e,t,n,r){let i=n.padding,{x:a,y:o}=t;for(let s of e){let e=s.box,c=r[s.stack]||{count:1,placed:0,weight:1},l=s.stackWeight/c.weight||1;if(s.horizontal){let r=t.w*l,a=c.size||e.height;Dr(c.start)&&(o=c.start),e.fullSize?Ys(e,i.left,o,n.outerWidth-i.right-i.left,a):Ys(e,t.left+c.placed,o,r,a),c.start=o,c.placed+=r,o=e.bottom}else{let r=t.h*l,o=c.size||e.width;Dr(c.start)&&(a=c.start),e.fullSize?Ys(e,a,i.top,o,n.outerHeight-i.bottom-i.top):Ys(e,a,t.top+c.placed,o,r),c.start=a,c.placed+=r,a=e.right}}t.x=a,t.y=o}var Zs={addBox(e,t){e.boxes||=[],t.fullSize=t.fullSize||!1,t.position=t.position||`top`,t.weight=t.weight||0,t._layers=t._layers||function(){return[{z:0,draw(e){t.draw(e)}}]},e.boxes.push(t)},removeBox(e,t){let n=e.boxes?e.boxes.indexOf(t):-1;n!==-1&&e.boxes.splice(n,1)},configure(e,t,n){t.fullSize=n.fullSize,t.position=n.position,t.weight=n.weight},update(e,t,n,r){if(!e)return;let i=Y(e.options.layout.padding),a=Math.max(t-i.width,0),o=Math.max(n-i.height,0),s=Hs(e.boxes),c=s.vertical,l=s.horizontal;H(e.boxes,e=>{typeof e.beforeLayout==`function`&&e.beforeLayout()});let u=c.reduce((e,t)=>t.box.options&&t.box.options.display===!1?e:e+1,0)||1,d=Object.freeze({outerWidth:t,outerHeight:n,padding:i,availableWidth:a,availableHeight:o,vBoxMaxWidth:a/2/u,hBoxMaxHeight:o/2}),f=Object.assign({},i);Ws(f,Y(r));let p=Object.assign({maxPadding:f,w:a,h:o,x:i.left,y:i.top},i),m=Vs(c.concat(l),d);Js(s.fullSize,p,d,m),Js(c,p,d,m),Js(l,p,d,m)&&Js(c,p,d,m),Ks(p),Xs(s.leftAndTop,p,d,m),p.x+=p.w,p.y+=p.h,Xs(s.rightAndBottom,p,d,m),e.chartArea={left:p.left,top:p.top,right:p.left+p.w,bottom:p.top+p.h,height:p.h,width:p.w},H(s.chartArea,t=>{let n=t.box;Object.assign(n,e.chartArea),n.update(p.w,p.h,{left:0,top:0,right:0,bottom:0})})}},Qs=class{acquireContext(e,t){}releaseContext(e){return!1}addEventListener(e,t,n){}removeEventListener(e,t,n){}getDevicePixelRatio(){return 1}getMaximumSize(e,t,n,r){return t=Math.max(0,t||e.width),n||=e.height,{width:t,height:Math.max(0,r?Math.floor(t/r):n)}}isAttached(e){return!0}updateConfig(e){}},$s=class extends Qs{acquireContext(e){return e&&e.getContext&&e.getContext(`2d`)||null}updateConfig(e){e.options.animation=!1}},ec=`$chartjs`,tc={touchstart:`mousedown`,touchmove:`mousemove`,touchend:`mouseup`,pointerenter:`mouseenter`,pointerdown:`mousedown`,pointermove:`mousemove`,pointerup:`mouseup`,pointerleave:`mouseout`,pointerout:`mouseout`},nc=e=>e===null||e===``;function rc(e,t){let n=e.style,r=e.getAttribute(`height`),i=e.getAttribute(`width`);if(e[ec]={initial:{height:r,width:i,style:{display:n.display,height:n.height,width:n.width}}},n.display=n.display||`block`,n.boxSizing=n.boxSizing||`border-box`,nc(i)){let t=no(e,`width`);t!==void 0&&(e.width=t)}if(nc(r))if(e.style.height===``)e.height=e.width/(t||2);else{let t=no(e,`height`);t!==void 0&&(e.height=t)}return e}var ic=to?{passive:!0}:!1;function ac(e,t,n){e&&e.addEventListener(t,n,ic)}function oc(e,t,n){e&&e.canvas&&e.canvas.removeEventListener(t,n,ic)}function sc(e,t){let n=tc[e.type]||e.type,{x:r,y:i}=Xa(e,t);return{type:n,chart:t,native:e,x:r===void 0?null:r,y:i===void 0?null:i}}function cc(e,t){for(let n of e)if(n===t||n.contains(t))return!0}function lc(e,t,n){let r=e.canvas,i=new MutationObserver(e=>{let t=!1;for(let n of e)t||=cc(n.addedNodes,r),t&&=!cc(n.removedNodes,r);t&&n()});return i.observe(document,{childList:!0,subtree:!0}),i}function uc(e,t,n){let r=e.canvas,i=new MutationObserver(e=>{let t=!1;for(let n of e)t||=cc(n.removedNodes,r),t&&=!cc(n.addedNodes,r);t&&n()});return i.observe(document,{childList:!0,subtree:!0}),i}var dc=new Map,fc=0;function pc(){let e=window.devicePixelRatio;e!==fc&&(fc=e,dc.forEach((t,n)=>{n.currentDevicePixelRatio!==e&&t()}))}function mc(e,t){dc.size||window.addEventListener(`resize`,pc),dc.set(e,t)}function hc(e){dc.delete(e),dc.size||window.removeEventListener(`resize`,pc)}function gc(e,t,n){let r=e.canvas,i=r&&Ha(r);if(!i)return;let a=li((e,t)=>{let r=i.clientWidth;n(e,t),r<i.clientWidth&&n()},window),o=new ResizeObserver(e=>{let t=e[0],n=t.contentRect.width,r=t.contentRect.height;n===0&&r===0||a(n,r)});return o.observe(i),mc(e,a),o}function _c(e,t,n){n&&n.disconnect(),t===`resize`&&hc(e)}function vc(e,t,n){let r=e.canvas,i=li(t=>{e.ctx!==null&&n(sc(t,e))},e);return ac(r,t,i),i}var yc=class extends Qs{acquireContext(e,t){let n=e&&e.getContext&&e.getContext(`2d`);return n&&n.canvas===e?(rc(e,t),n):null}releaseContext(e){let t=e.canvas;if(!t[ec])return!1;let n=t[ec].initial;[`height`,`width`].forEach(e=>{let r=n[e];I(r)?t.removeAttribute(e):t.setAttribute(e,r)});let r=n.style||{};return Object.keys(r).forEach(e=>{t.style[e]=r[e]}),t.width=t.width,delete t[ec],!0}addEventListener(e,t,n){this.removeEventListener(e,t);let r=e.$proxies||={};r[t]=({attach:lc,detach:uc,resize:gc}[t]||vc)(e,t,n)}removeEventListener(e,t){let n=e.$proxies||={},r=n[t];r&&(({attach:_c,detach:_c,resize:_c}[t]||oc)(e,t,r),n[t]=void 0)}getDevicePixelRatio(){return window.devicePixelRatio}getMaximumSize(e,t,n,r){return $a(e,t,n,r)}isAttached(e){let t=e&&Ha(e);return!!(t&&t.isConnected)}};function bc(e){return!Va()||typeof OffscreenCanvas<`u`&&e instanceof OffscreenCanvas?$s:yc}var xc=class{constructor(){f(this,`x`,void 0),f(this,`y`,void 0),f(this,`active`,!1),f(this,`options`,void 0),f(this,`$animations`,void 0)}tooltipPosition(e){let{x:t,y:n}=this.getProps([`x`,`y`],e);return{x:t,y:n}}hasValue(){return Hr(this.x)&&Hr(this.y)}getProps(e,t){let n=this.$animations;if(!t||!n)return this;let r={};return e.forEach(e=>{r[e]=n[e]&&n[e].active()?n[e]._to:this[e]}),r}};f(xc,`defaults`,{}),f(xc,`defaultRoutes`,void 0);function Sc(e,t){let n=e.options.ticks,r=Cc(e),i=Math.min(n.maxTicksLimit||r,r),a=n.major.enabled?Tc(t):[],o=a.length,s=a[0],c=a[o-1],l=[];if(o>i)return Ec(t,l,a,o/i),l;let u=wc(a,t,i);if(o>0){let e,n,r=o>1?Math.round((c-s)/(o-1)):null;for(Dc(t,l,u,I(r)?0:s-r,s),e=0,n=o-1;e<n;e++)Dc(t,l,u,a[e],a[e+1]);return Dc(t,l,u,c,I(r)?t.length:c+r),l}return Dc(t,l,u),l}function Cc(e){let t=e.options.offset,n=e._tickSize(),r=e._length/n+(t?0:1),i=e._maxLength/n;return Math.floor(Math.min(r,i))}function wc(e,t,n){let r=Oc(e),i=t.length/n;if(!r)return Math.max(i,1);let a=Br(r);for(let e=0,t=a.length-1;e<t;e++){let t=a[e];if(t>i)return t}return Math.max(i,1)}function Tc(e){let t=[],n,r;for(n=0,r=e.length;n<r;n++)e[n].major&&t.push(n);return t}function Ec(e,t,n,r){let i=0,a=n[0],o;for(r=Math.ceil(r),o=0;o<e.length;o++)o===a&&(t.push(e[o]),i++,a=n[i*r])}function Dc(e,t,n,r,i){let a=B(r,0),o=Math.min(B(i,e.length),e.length),s=0,c,l,u;for(n=Math.ceil(n),i&&(c=i-r,n=c/Math.floor(c/n)),u=a;u<0;)s++,u=Math.round(a+s*n);for(l=Math.max(a,0);l<o;l++)l===u&&(t.push(e[l]),s++,u=Math.round(a+s*n))}function Oc(e){let t=e.length,n,r;if(t<2)return!1;for(r=e[0],n=1;n<t;++n)if(e[n]-e[n-1]!==r)return!1;return r}var kc=e=>e===`left`?`right`:e===`right`?`left`:e,Ac=(e,t,n)=>t===`top`||t===`left`?e[t]+n:e[t]-n,jc=(e,t)=>Math.min(t||e,e);function Mc(e,t){let n=[],r=e.length/t,i=e.length,a=0;for(;a<i;a+=r)n.push(e[Math.floor(a)]);return n}function Nc(e,t,n){let r=e.ticks.length,i=Math.min(t,r-1),a=e._startPixel,o=e._endPixel,s=1e-6,c=e.getPixelForTick(i),l;if(!(n&&(l=r===1?Math.max(c-a,o-c):t===0?(e.getPixelForTick(1)-c)/2:(c-e.getPixelForTick(i-1))/2,c+=i<t?l:-l,c<a-s||c>o+s)))return c}function Pc(e,t){H(e,e=>{let n=e.gc,r=n.length/2,i;if(r>t){for(i=0;i<r;++i)delete e.data[n[i]];n.splice(0,r)}})}function Fc(e){return e.drawTicks?e.tickLength:0}function Ic(e,t){if(!e.display)return 0;let n=X(e.font,t),r=Y(e.padding);return(L(e.text)?e.text.length:1)*n.lineHeight+r.height}function Lc(e,t){return ua(e,{scale:t,type:`scale`})}function Rc(e,t,n){return ua(e,{tick:n,index:t,type:`tick`})}function zc(e,t,n){let r=di(e);return(n&&t!==`right`||!n&&t===`right`)&&(r=kc(r)),r}function Bc(e,t,n,r){let{top:i,left:a,bottom:o,right:s,chart:c}=e,{chartArea:l,scales:u}=c,d=0,f,p,m,h=o-i,g=s-a;if(e.isHorizontal()){if(p=fi(r,a,s),R(n)){let e=Object.keys(n)[0],r=n[e];m=u[e].getPixelForValue(r)+h-t}else m=n===`center`?(l.bottom+l.top)/2+h-t:Ac(e,n,t);f=s-a}else{if(R(n)){let e=Object.keys(n)[0],r=n[e];p=u[e].getPixelForValue(r)-g+t}else p=n===`center`?(l.left+l.right)/2-g+t:Ac(e,n,t);m=fi(r,o,i),d=n===`left`?-G:G}return{titleX:p,titleY:m,maxWidth:f,rotation:d}}var Vc=class e extends xc{constructor(e){super(),this.id=e.id,this.type=e.type,this.options=void 0,this.ctx=e.ctx,this.chart=e.chart,this.top=void 0,this.bottom=void 0,this.left=void 0,this.right=void 0,this.width=void 0,this.height=void 0,this._margins={left:0,right:0,top:0,bottom:0},this.maxWidth=void 0,this.maxHeight=void 0,this.paddingTop=void 0,this.paddingBottom=void 0,this.paddingLeft=void 0,this.paddingRight=void 0,this.axis=void 0,this.labelRotation=void 0,this.min=void 0,this.max=void 0,this._range=void 0,this.ticks=[],this._gridLineItems=null,this._labelItems=null,this._labelSizes=null,this._length=0,this._maxLength=0,this._longestTextCache={},this._startPixel=void 0,this._endPixel=void 0,this._reversePixels=!1,this._userMax=void 0,this._userMin=void 0,this._suggestedMax=void 0,this._suggestedMin=void 0,this._ticksLength=0,this._borderValue=0,this._cache={},this._dataLimitsCached=!1,this.$context=void 0}init(e){this.options=e.setContext(this.getContext()),this.axis=e.axis,this._userMin=this.parse(e.min),this._userMax=this.parse(e.max),this._suggestedMin=this.parse(e.suggestedMin),this._suggestedMax=this.parse(e.suggestedMax)}parse(e,t){return e}getUserBounds(){let{_userMin:e,_userMax:t,_suggestedMin:n,_suggestedMax:r}=this;return e=fr(e,1/0),t=fr(t,-1/0),n=fr(n,1/0),r=fr(r,-1/0),{min:fr(e,n),max:fr(t,r),minDefined:z(e),maxDefined:z(t)}}getMinMax(e){let{min:t,max:n,minDefined:r,maxDefined:i}=this.getUserBounds(),a;if(r&&i)return{min:t,max:n};let o=this.getMatchingVisibleMetas();for(let s=0,c=o.length;s<c;++s)a=o[s].controller.getMinMax(this,e),r||(t=Math.min(t,a.min)),i||(n=Math.max(n,a.max));return t=i&&t>n?n:t,n=r&&t>n?t:n,{min:fr(t,fr(n,t)),max:fr(n,fr(t,n))}}getPadding(){return{left:this.paddingLeft||0,top:this.paddingTop||0,right:this.paddingRight||0,bottom:this.paddingBottom||0}}getTicks(){return this.ticks}getLabels(){let e=this.chart.data;return this.options.labels||(this.isHorizontal()?e.xLabels:e.yLabels)||e.labels||[]}getLabelItems(e=this.chart.chartArea){return this._labelItems||=this._computeLabelItems(e)}beforeLayout(){this._cache={},this._dataLimitsCached=!1}beforeUpdate(){V(this.options.beforeUpdate,[this])}update(e,t,n){let{beginAtZero:r,grace:i,ticks:a}=this.options,o=a.sampleSize;this.beforeUpdate(),this.maxWidth=e,this.maxHeight=t,this._margins=n=Object.assign({left:0,right:0,top:0,bottom:0},n),this.ticks=null,this._labelSizes=null,this._gridLineItems=null,this._labelItems=null,this.beforeSetDimensions(),this.setDimensions(),this.afterSetDimensions(),this._maxLength=this.isHorizontal()?this.width+n.left+n.right:this.height+n.top+n.bottom,this._dataLimitsCached||=(this.beforeDataLimits(),this.determineDataLimits(),this.afterDataLimits(),this._range=la(this,i,r),!0),this.beforeBuildTicks(),this.ticks=this.buildTicks()||[],this.afterBuildTicks();let s=o<this.ticks.length;this._convertTicksToLabels(s?Mc(this.ticks,o):this.ticks),this.configure(),this.beforeCalculateLabelRotation(),this.calculateLabelRotation(),this.afterCalculateLabelRotation(),a.display&&(a.autoSkip||a.source===`auto`)&&(this.ticks=Sc(this,this.ticks),this._labelSizes=null,this.afterAutoSkip()),s&&this._convertTicksToLabels(this.ticks),this.beforeFit(),this.fit(),this.afterFit(),this.afterUpdate()}configure(){let e=this.options.reverse,t,n;this.isHorizontal()?(t=this.left,n=this.right):(t=this.top,n=this.bottom,e=!e),this._startPixel=t,this._endPixel=n,this._reversePixels=e,this._length=n-t,this._alignToPixels=this.options.alignToPixels}afterUpdate(){V(this.options.afterUpdate,[this])}beforeSetDimensions(){V(this.options.beforeSetDimensions,[this])}setDimensions(){this.isHorizontal()?(this.width=this.maxWidth,this.left=0,this.right=this.width):(this.height=this.maxHeight,this.top=0,this.bottom=this.height),this.paddingLeft=0,this.paddingTop=0,this.paddingRight=0,this.paddingBottom=0}afterSetDimensions(){V(this.options.afterSetDimensions,[this])}_callHooks(e){this.chart.notifyPlugins(e,this.getContext()),V(this.options[e],[this])}beforeDataLimits(){this._callHooks(`beforeDataLimits`)}determineDataLimits(){}afterDataLimits(){this._callHooks(`afterDataLimits`)}beforeBuildTicks(){this._callHooks(`beforeBuildTicks`)}buildTicks(){return[]}afterBuildTicks(){this._callHooks(`afterBuildTicks`)}beforeTickToLabelConversion(){V(this.options.beforeTickToLabelConversion,[this])}generateTickLabels(e){let t=this.options.ticks,n,r,i;for(n=0,r=e.length;n<r;n++)i=e[n],i.label=V(t.callback,[i.value,n,e],this)}afterTickToLabelConversion(){V(this.options.afterTickToLabelConversion,[this])}beforeCalculateLabelRotation(){V(this.options.beforeCalculateLabelRotation,[this])}calculateLabelRotation(){let e=this.options,t=e.ticks,n=jc(this.ticks.length,e.ticks.maxTicksLimit),r=t.minRotation||0,i=t.maxRotation,a=r,o,s,c;if(!this._isVisible()||!t.display||r>=i||n<=1||!this.isHorizontal()){this.labelRotation=r;return}let l=this._getLabelSizes(),u=l.widest.width,d=l.highest.height,f=q(this.chart.width-u,0,this.maxWidth);o=e.offset?this.maxWidth/n:f/(n-1),u+6>o&&(o=f/(n-(e.offset?.5:1)),s=this.maxHeight-Fc(e.grid)-t.padding-Ic(e.title,this.chart.options.font),c=Math.sqrt(u*u+d*d),a=Kr(Math.min(Math.asin(q((l.highest.height+6)/o,-1,1)),Math.asin(q(s/c,-1,1))-Math.asin(q(d/c,-1,1)))),a=Math.max(r,Math.min(i,a))),this.labelRotation=a}afterCalculateLabelRotation(){V(this.options.afterCalculateLabelRotation,[this])}afterAutoSkip(){}beforeFit(){V(this.options.beforeFit,[this])}fit(){let e={width:0,height:0},{chart:t,options:{ticks:n,title:r,grid:i}}=this,a=this._isVisible(),o=this.isHorizontal();if(a){let a=Ic(r,t.options.font);if(o?(e.width=this.maxWidth,e.height=Fc(i)+a):(e.height=this.maxHeight,e.width=Fc(i)+a),n.display&&this.ticks.length){let{first:t,last:r,widest:i,highest:a}=this._getLabelSizes(),s=n.padding*2,c=Gr(this.labelRotation),l=Math.cos(c),u=Math.sin(c);if(o){let t=n.mirror?0:u*i.width+l*a.height;e.height=Math.min(this.maxHeight,e.height+t+s)}else{let t=n.mirror?0:l*i.width+u*a.height;e.width=Math.min(this.maxWidth,e.width+t+s)}this._calculatePadding(t,r,u,l)}}this._handleMargins(),o?(this.width=this._length=t.width-this._margins.left-this._margins.right,this.height=e.height):(this.width=e.width,this.height=this._length=t.height-this._margins.top-this._margins.bottom)}_calculatePadding(e,t,n,r){let{ticks:{align:i,padding:a},position:o}=this.options,s=this.labelRotation!==0,c=o!==`top`&&this.axis===`x`;if(this.isHorizontal()){let o=this.getPixelForTick(0)-this.left,l=this.right-this.getPixelForTick(this.ticks.length-1),u=0,d=0;s?c?(u=r*e.width,d=n*t.height):(u=n*e.height,d=r*t.width):i===`start`?d=t.width:i===`end`?u=e.width:i!==`inner`&&(u=e.width/2,d=t.width/2),this.paddingLeft=Math.max((u-o+a)*this.width/(this.width-o),0),this.paddingRight=Math.max((d-l+a)*this.width/(this.width-l),0)}else{let n=t.height/2,r=e.height/2;i===`start`?(n=0,r=e.height):i===`end`&&(n=t.height,r=0),this.paddingTop=n+a,this.paddingBottom=r+a}}_handleMargins(){this._margins&&(this._margins.left=Math.max(this.paddingLeft,this._margins.left),this._margins.top=Math.max(this.paddingTop,this._margins.top),this._margins.right=Math.max(this.paddingRight,this._margins.right),this._margins.bottom=Math.max(this.paddingBottom,this._margins.bottom))}afterFit(){V(this.options.afterFit,[this])}isHorizontal(){let{axis:e,position:t}=this.options;return t===`top`||t===`bottom`||e===`x`}isFullSize(){return this.options.fullSize}_convertTicksToLabels(e){this.beforeTickToLabelConversion(),this.generateTickLabels(e);let t,n;for(t=0,n=e.length;t<n;t++)I(e[t].label)&&(e.splice(t,1),n--,t--);this.afterTickToLabelConversion()}_getLabelSizes(){let e=this._labelSizes;if(!e){let t=this.options.ticks.sampleSize,n=this.ticks;t<n.length&&(n=Mc(n,t)),this._labelSizes=e=this._computeLabelSizes(n,n.length,this.options.ticks.maxTicksLimit)}return e}_computeLabelSizes(e,t,n){let{ctx:r,_longestTextCache:i}=this,a=[],o=[],s=Math.floor(t/jc(t,n)),c=0,l=0,u,d,f,p,m,h,g,_,v,y,b;for(u=0;u<t;u+=s){if(p=e[u].label,m=this._resolveTickFontOptions(u),r.font=h=m.string,g=i[h]=i[h]||{data:{},gc:[]},_=m.lineHeight,v=y=0,!I(p)&&!L(p))v=zi(r,g.data,g.gc,v,p),y=_;else if(L(p))for(d=0,f=p.length;d<f;++d)b=p[d],!I(b)&&!L(b)&&(v=zi(r,g.data,g.gc,v,b),y+=_);a.push(v),o.push(y),c=Math.max(v,c),l=Math.max(y,l)}Pc(i,t);let x=a.indexOf(c),S=o.indexOf(l),C=e=>({width:a[e]||0,height:o[e]||0});return{first:C(0),last:C(t-1),widest:C(x),highest:C(S),widths:a,heights:o}}getLabelForValue(e){return e}getPixelForValue(e,t){return NaN}getValueForPixel(e){}getPixelForTick(e){let t=this.ticks;return e<0||e>t.length-1?null:this.getPixelForValue(t[e].value)}getPixelForDecimal(e){this._reversePixels&&(e=1-e);let t=this._startPixel+e*this._length;return Qr(this._alignToPixels?Vi(this.chart,t,0):t)}getDecimalForPixel(e){let t=(e-this._startPixel)/this._length;return this._reversePixels?1-t:t}getBasePixel(){return this.getPixelForValue(this.getBaseValue())}getBaseValue(){let{min:e,max:t}=this;return e<0&&t<0?t:e>0&&t>0?e:0}getContext(e){let t=this.ticks||[];if(e>=0&&e<t.length){let n=t[e];return n.$context||=Rc(this.getContext(),e,n)}return this.$context||=Lc(this.chart.getContext(),this)}_tickSize(){let e=this.options.ticks,t=Gr(this.labelRotation),n=Math.abs(Math.cos(t)),r=Math.abs(Math.sin(t)),i=this._getLabelSizes(),a=e.autoSkipPadding||0,o=i?i.widest.width+a:0,s=i?i.highest.height+a:0;return this.isHorizontal()?s*n>o*r?o/n:s/r:s*r<o*n?s/n:o/r}_isVisible(){let e=this.options.display;return e===`auto`?this.getMatchingVisibleMetas().length>0:!!e}_computeGridLineItems(e){let t=this.axis,n=this.chart,r=this.options,{grid:i,position:a,border:o}=r,s=i.offset,c=this.isHorizontal(),l=this.ticks.length+(s?1:0),u=Fc(i),d=[],f=o.setContext(this.getContext()),p=f.display?f.width:0,m=p/2,h=function(e){return Vi(n,e,p)},g,_,v,y,b,x,S,C,w,T,E,D;if(a===`top`)g=h(this.bottom),x=this.bottom-u,C=g-m,T=h(e.top)+m,D=e.bottom;else if(a===`bottom`)g=h(this.top),T=e.top,D=h(e.bottom)-m,x=g+m,C=this.top+u;else if(a===`left`)g=h(this.right),b=this.right-u,S=g-m,w=h(e.left)+m,E=e.right;else if(a===`right`)g=h(this.left),w=e.left,E=h(e.right)-m,b=g+m,S=this.left+u;else if(t===`x`){if(a===`center`)g=h((e.top+e.bottom)/2+.5);else if(R(a)){let e=Object.keys(a)[0],t=a[e];g=h(this.chart.scales[e].getPixelForValue(t))}T=e.top,D=e.bottom,x=g+m,C=x+u}else if(t===`y`){if(a===`center`)g=h((e.left+e.right)/2);else if(R(a)){let e=Object.keys(a)[0],t=a[e];g=h(this.chart.scales[e].getPixelForValue(t))}b=g-m,S=b-u,w=e.left,E=e.right}let ee=B(r.ticks.maxTicksLimit,l),te=Math.max(1,Math.ceil(l/ee));for(_=0;_<l;_+=te){let e=this.getContext(_),t=i.setContext(e),r=o.setContext(e),a=t.lineWidth,l=t.color,u=r.dash||[],f=r.dashOffset,p=t.tickWidth,m=t.tickColor,h=t.tickBorderDash||[],g=t.tickBorderDashOffset;v=Nc(this,_,s),v!==void 0&&(y=Vi(n,v,a),c?b=S=w=E=y:x=C=T=D=y,d.push({tx1:b,ty1:x,tx2:S,ty2:C,x1:w,y1:T,x2:E,y2:D,width:a,color:l,borderDash:u,borderDashOffset:f,tickWidth:p,tickColor:m,tickBorderDash:h,tickBorderDashOffset:g}))}return this._ticksLength=l,this._borderValue=g,d}_computeLabelItems(e){let t=this.axis,n=this.options,{position:r,ticks:i}=n,a=this.isHorizontal(),o=this.ticks,{align:s,crossAlign:c,padding:l,mirror:u}=i,d=Fc(n.grid),f=d+l,p=u?-l:f,m=-Gr(this.labelRotation),h=[],g,_,v,y,b,x,S,C,w,T,E,D,ee=`middle`;if(r===`top`)x=this.bottom-p,S=this._getXAxisLabelAlignment();else if(r===`bottom`)x=this.top+p,S=this._getXAxisLabelAlignment();else if(r===`left`){let e=this._getYAxisLabelAlignment(d);S=e.textAlign,b=e.x}else if(r===`right`){let e=this._getYAxisLabelAlignment(d);S=e.textAlign,b=e.x}else if(t===`x`){if(r===`center`)x=(e.top+e.bottom)/2+f;else if(R(r)){let e=Object.keys(r)[0],t=r[e];x=this.chart.scales[e].getPixelForValue(t)+f}S=this._getXAxisLabelAlignment()}else if(t===`y`){if(r===`center`)b=(e.left+e.right)/2-f;else if(R(r)){let e=Object.keys(r)[0],t=r[e];b=this.chart.scales[e].getPixelForValue(t)}S=this._getYAxisLabelAlignment(d).textAlign}t===`y`&&(s===`start`?ee=`top`:s===`end`&&(ee=`bottom`));let te=this._getLabelSizes();for(g=0,_=o.length;g<_;++g){v=o[g],y=v.label;let e=i.setContext(this.getContext(g));C=this.getPixelForTick(g)+i.labelOffset,w=this._resolveTickFontOptions(g),T=w.lineHeight,E=L(y)?y.length:1;let t=E/2,n=e.color,s=e.textStrokeColor,l=e.textStrokeWidth,d=S;a?(b=C,S===`inner`&&(d=g===_-1?this.options.reverse?`left`:`right`:g===0?this.options.reverse?`right`:`left`:`center`),D=r===`top`?c===`near`||m!==0?-E*T+T/2:c===`center`?-te.highest.height/2-t*T+T:-te.highest.height+T/2:c===`near`||m!==0?T/2:c===`center`?te.highest.height/2-t*T:te.highest.height-E*T,u&&(D*=-1),m!==0&&!e.showLabelBackdrop&&(b+=T/2*Math.sin(m))):(x=C,D=(1-E)*T/2);let f;if(e.showLabelBackdrop){let t=Y(e.backdropPadding),n=te.heights[g],r=te.widths[g],i=D-t.top,a=0-t.left;switch(ee){case`middle`:i-=n/2;break;case`bottom`:i-=n;break}switch(S){case`center`:a-=r/2;break;case`right`:a-=r;break;case`inner`:g===_-1?a-=r:g>0&&(a-=r/2);break}f={left:a,top:i,width:r+t.width,height:n+t.height,color:e.backdropColor}}h.push({label:y,font:w,textOffset:D,options:{rotation:m,color:n,strokeColor:s,strokeWidth:l,textAlign:d,textBaseline:ee,translation:[b,x],backdrop:f}})}return h}_getXAxisLabelAlignment(){let{position:e,ticks:t}=this.options;if(-Gr(this.labelRotation))return e===`top`?`left`:`right`;let n=`center`;return t.align===`start`?n=`left`:t.align===`end`?n=`right`:t.align===`inner`&&(n=`inner`),n}_getYAxisLabelAlignment(e){let{position:t,ticks:{crossAlign:n,mirror:r,padding:i}}=this.options,a=this._getLabelSizes(),o=e+i,s=a.widest.width,c,l;return t===`left`?r?(l=this.right+i,n===`near`?c=`left`:n===`center`?(c=`center`,l+=s/2):(c=`right`,l+=s)):(l=this.right-o,n===`near`?c=`right`:n===`center`?(c=`center`,l-=s/2):(c=`left`,l=this.left)):t===`right`?r?(l=this.left+i,n===`near`?c=`right`:n===`center`?(c=`center`,l-=s/2):(c=`left`,l-=s)):(l=this.left+o,n===`near`?c=`left`:n===`center`?(c=`center`,l+=s/2):(c=`right`,l=this.right)):c=`right`,{textAlign:c,x:l}}_computeLabelArea(){if(this.options.ticks.mirror)return;let e=this.chart,t=this.options.position;if(t===`left`||t===`right`)return{top:0,left:this.left,bottom:e.height,right:this.right};if(t===`top`||t===`bottom`)return{top:this.top,left:0,bottom:this.bottom,right:e.width}}drawBackground(){let{ctx:e,options:{backgroundColor:t},left:n,top:r,width:i,height:a}=this;t&&(e.save(),e.fillStyle=t,e.fillRect(n,r,i,a),e.restore())}getLineWidthForValue(e){let t=this.options.grid;if(!this._isVisible()||!t.display)return 0;let n=this.ticks.findIndex(t=>t.value===e);return n>=0?t.setContext(this.getContext(n)).lineWidth:0}drawGrid(e){let t=this.options.grid,n=this.ctx,r=this._gridLineItems||=this._computeGridLineItems(e),i,a,o=(e,t,r)=>{!r.width||!r.color||(n.save(),n.lineWidth=r.width,n.strokeStyle=r.color,n.setLineDash(r.borderDash||[]),n.lineDashOffset=r.borderDashOffset,n.beginPath(),n.moveTo(e.x,e.y),n.lineTo(t.x,t.y),n.stroke(),n.restore())};if(t.display)for(i=0,a=r.length;i<a;++i){let e=r[i];t.drawOnChartArea&&o({x:e.x1,y:e.y1},{x:e.x2,y:e.y2},e),t.drawTicks&&o({x:e.tx1,y:e.ty1},{x:e.tx2,y:e.ty2},{color:e.tickColor,width:e.tickWidth,borderDash:e.tickBorderDash,borderDashOffset:e.tickBorderDashOffset})}}drawBorder(){let{chart:e,ctx:t,options:{border:n,grid:r}}=this,i=n.setContext(this.getContext()),a=n.display?i.width:0;if(!a)return;let o=r.setContext(this.getContext(0)).lineWidth,s=this._borderValue,c,l,u,d;this.isHorizontal()?(c=Vi(e,this.left,a)-a/2,l=Vi(e,this.right,o)+o/2,u=d=s):(u=Vi(e,this.top,a)-a/2,d=Vi(e,this.bottom,o)+o/2,c=l=s),t.save(),t.lineWidth=i.width,t.strokeStyle=i.color,t.beginPath(),t.moveTo(c,u),t.lineTo(l,d),t.stroke(),t.restore()}drawLabels(e){if(!this.options.ticks.display)return;let t=this.ctx,n=this._computeLabelArea();n&&Ki(t,n);let r=this.getLabelItems(e);for(let e of r){let n=e.options,r=e.font,i=e.label,a=e.textOffset;$i(t,i,0,a,r,n)}n&&qi(t)}drawTitle(){let{ctx:e,options:{position:t,title:n,reverse:r}}=this;if(!n.display)return;let i=X(n.font),a=Y(n.padding),o=n.align,s=i.lineHeight/2;t===`bottom`||t===`center`||R(t)?(s+=a.bottom,L(n.text)&&(s+=i.lineHeight*(n.text.length-1))):s+=a.top;let{titleX:c,titleY:l,maxWidth:u,rotation:d}=Bc(this,s,t,o);$i(e,n.text,0,0,i,{color:n.color,maxWidth:u,rotation:d,textAlign:zc(o,t,r),textBaseline:`middle`,translation:[c,l]})}draw(e){this._isVisible()&&(this.drawBackground(),this.drawGrid(e),this.drawBorder(),this.drawTitle(),this.drawLabels(e))}_layers(){let t=this.options,n=t.ticks&&t.ticks.z||0,r=B(t.grid&&t.grid.z,-1),i=B(t.border&&t.border.z,0);return!this._isVisible()||this.draw!==e.prototype.draw?[{z:n,draw:e=>{this.draw(e)}}]:[{z:r,draw:e=>{this.drawBackground(),this.drawGrid(e),this.drawTitle()}},{z:i,draw:()=>{this.drawBorder()}},{z:n,draw:e=>{this.drawLabels(e)}}]}getMatchingVisibleMetas(e){let t=this.chart.getSortedVisibleDatasetMetas(),n=this.axis+`AxisID`,r=[],i,a;for(i=0,a=t.length;i<a;++i){let a=t[i];a[n]===this.id&&(!e||a.type===e)&&r.push(a)}return r}_resolveTickFontOptions(e){return X(this.options.ticks.setContext(this.getContext(e)).font)}_maxDigits(){let e=this._resolveTickFontOptions(0).lineHeight;return(this.isHorizontal()?this.width:this.height)/e}},Hc=class{constructor(e,t,n){this.type=e,this.scope=t,this.override=n,this.items=Object.create(null)}isForType(e){return Object.prototype.isPrototypeOf.call(this.type.prototype,e.prototype)}register(e){let t=Object.getPrototypeOf(e),n;Gc(t)&&(n=this.register(t));let r=this.items,i=e.id,a=this.scope+`.`+i;if(!i)throw Error(`class does not have id: `+e);return i in r?a:(r[i]=e,Uc(e,a,n),this.override&&J.override(e.id,e.overrides),a)}get(e){return this.items[e]}unregister(e){let t=this.items,n=e.id,r=this.scope;n in t&&delete t[n],r&&n in J[r]&&(delete J[r][n],this.override&&delete Pi[n])}};function Uc(e,t,n){let r=yr(Object.create(null),[n?J.get(n):{},J.get(t),e.defaults]);J.set(t,r),e.defaultRoutes&&Wc(t,e.defaultRoutes),e.descriptors&&J.describe(t,e.descriptors)}function Wc(e,t){Object.keys(t).forEach(n=>{let r=n.split(`.`),i=r.pop(),a=[e].concat(r).join(`.`),o=t[n].split(`.`),s=o.pop(),c=o.join(`.`);J.route(a,i,c,s)})}function Gc(e){return`id`in e&&`defaults`in e}var Kc=new class{constructor(){this.controllers=new Hc($o,`datasets`,!0),this.elements=new Hc(xc,`elements`),this.plugins=new Hc(Object,`plugins`),this.scales=new Hc(Vc,`scales`),this._typedRegistries=[this.controllers,this.scales,this.elements]}add(...e){this._each(`register`,e)}remove(...e){this._each(`unregister`,e)}addControllers(...e){this._each(`register`,e,this.controllers)}addElements(...e){this._each(`register`,e,this.elements)}addPlugins(...e){this._each(`register`,e,this.plugins)}addScales(...e){this._each(`register`,e,this.scales)}getController(e){return this._get(e,this.controllers,`controller`)}getElement(e){return this._get(e,this.elements,`element`)}getPlugin(e){return this._get(e,this.plugins,`plugin`)}getScale(e){return this._get(e,this.scales,`scale`)}removeControllers(...e){this._each(`unregister`,e,this.controllers)}removeElements(...e){this._each(`unregister`,e,this.elements)}removePlugins(...e){this._each(`unregister`,e,this.plugins)}removeScales(...e){this._each(`unregister`,e,this.scales)}_each(e,t,n){[...t].forEach(t=>{let r=n||this._getRegistryForType(t);n||r.isForType(t)||r===this.plugins&&t.id?this._exec(e,r,t):H(t,t=>{let r=n||this._getRegistryForType(t);this._exec(e,r,t)})})}_exec(e,t,n){let r=Er(e);V(n[`before`+r],[],n),t[e](n),V(n[`after`+r],[],n)}_getRegistryForType(e){for(let t=0;t<this._typedRegistries.length;t++){let n=this._typedRegistries[t];if(n.isForType(e))return n}return this.plugins}_get(e,t,n){let r=t.get(e);if(r===void 0)throw Error(`"`+e+`" is not a registered `+n+`.`);return r}},qc=class{constructor(){this._init=void 0}notify(e,t,n,r){if(t===`beforeInit`&&(this._init=this._createDescriptors(e,!0),this._notify(this._init,e,`install`)),this._init===void 0)return;let i=r?this._descriptors(e).filter(r):this._descriptors(e),a=this._notify(i,e,t,n);return t===`afterDestroy`&&(this._notify(i,e,`stop`),this._notify(this._init,e,`uninstall`),this._init=void 0),a}_notify(e,t,n,r){r||={};for(let i of e){let e=i.plugin,a=e[n];if(V(a,[t,r,i.options],e)===!1&&r.cancelable)return!1}return!0}invalidate(){I(this._cache)||(this._oldCache=this._cache,this._cache=void 0)}_descriptors(e){if(this._cache)return this._cache;let t=this._cache=this._createDescriptors(e);return this._notifyStateChanges(e),t}_createDescriptors(e,t){let n=e&&e.config,r=B(n.options&&n.options.plugins,{}),i=Jc(n);return r===!1&&!t?[]:Xc(e,i,r,t)}_notifyStateChanges(e){let t=this._oldCache||[],n=this._cache,r=(e,t)=>e.filter(e=>!t.some(t=>e.plugin.id===t.plugin.id));this._notify(r(t,n),e,`stop`),this._notify(r(n,t),e,`start`)}};function Jc(e){let t={},n=[],r=Object.keys(Kc.plugins.items);for(let e=0;e<r.length;e++)n.push(Kc.getPlugin(r[e]));let i=e.plugins||[];for(let e=0;e<i.length;e++){let r=i[e];n.indexOf(r)===-1&&(n.push(r),t[r.id]=!0)}return{plugins:n,localIds:t}}function Yc(e,t){return!t&&e===!1?null:e===!0?{}:e}function Xc(e,{plugins:t,localIds:n},r,i){let a=[],o=e.getContext();for(let s of t){let t=s.id,c=Yc(r[t],i);c!==null&&a.push({plugin:s,options:Zc(e.config,{plugin:s,local:n[t]},c,o)})}return a}function Zc(e,{plugin:t,local:n},r,i){let a=e.pluginScopeKeys(t),o=e.getOptionScopes(r,a);return n&&t.defaults&&o.push(t.defaults),e.createResolver(o,i,[``],{scriptable:!1,indexable:!1,allKeys:!0})}function Qc(e,t){let n=J.datasets[e]||{};return((t.datasets||{})[e]||{}).indexAxis||t.indexAxis||n.indexAxis||`x`}function $c(e,t){let n=e;return e===`_index_`?n=t:e===`_value_`&&(n=t===`x`?`y`:`x`),n}function el(e,t){return e===t?`_index_`:`_value_`}function tl(e){if(e===`x`||e===`y`||e===`r`)return e}function nl(e){if(e===`top`||e===`bottom`)return`x`;if(e===`left`||e===`right`)return`y`}function rl(e,...t){if(tl(e))return e;for(let n of t){let t=n.axis||nl(n.position)||e.length>1&&tl(e[0].toLowerCase());if(t)return t}throw Error(`Cannot determine type of '${e}' axis. Please provide 'axis' or 'position' option.`)}function il(e,t,n){if(n[t+`AxisID`]===e)return{axis:t}}function al(e,t){if(t.data&&t.data.datasets){let n=t.data.datasets.filter(t=>t.xAxisID===e||t.yAxisID===e);if(n.length)return il(e,`x`,n[0])||il(e,`y`,n[0])}return{}}function ol(e,t){let n=Pi[e.type]||{scales:{}},r=t.scales||{},i=Qc(e.type,t),a=Object.create(null);return Object.keys(r).forEach(t=>{let o=r[t];if(!R(o))return console.error(`Invalid scale configuration for scale: ${t}`);if(o._proxy)return console.warn(`Ignoring resolver passed as options for scale: ${t}`);let s=rl(t,o,al(t,e),J.scales[o.type]),c=el(s,i),l=n.scales||{};a[t]=br(Object.create(null),[{axis:s},o,l[s],l[c]])}),e.data.datasets.forEach(n=>{let i=n.type||e.type,o=n.indexAxis||Qc(i,t),s=(Pi[i]||{}).scales||{};Object.keys(s).forEach(e=>{let t=$c(e,o),i=n[t+`AxisID`]||t;a[i]=a[i]||Object.create(null),br(a[i],[{axis:t},r[i],s[e]])})}),Object.keys(a).forEach(e=>{let t=a[e];br(t,[J.scales[t.type],J.scale])}),a}function sl(e){let t=e.options||={};t.plugins=B(t.plugins,{}),t.scales=ol(e,t)}function cl(e){return e||={},e.datasets=e.datasets||[],e.labels=e.labels||[],e}function ll(e){return e||={},e.data=cl(e.data),sl(e),e}var ul=new Map,dl=new Set;function fl(e,t){let n=ul.get(e);return n||(n=t(),ul.set(e,n),dl.add(n)),n}var pl=(e,t,n)=>{let r=Tr(t,n);r!==void 0&&e.add(r)},ml=class{constructor(e){this._config=ll(e),this._scopeCache=new Map,this._resolverCache=new Map}get platform(){return this._config.platform}get type(){return this._config.type}set type(e){this._config.type=e}get data(){return this._config.data}set data(e){this._config.data=cl(e)}get options(){return this._config.options}set options(e){this._config.options=e}get plugins(){return this._config.plugins}update(){let e=this._config;this.clearCache(),sl(e)}clearCache(){this._scopeCache.clear(),this._resolverCache.clear()}datasetScopeKeys(e){return fl(e,()=>[[`datasets.${e}`,``]])}datasetAnimationScopeKeys(e,t){return fl(`${e}.transition.${t}`,()=>[[`datasets.${e}.transitions.${t}`,`transitions.${t}`],[`datasets.${e}`,``]])}datasetElementScopeKeys(e,t){return fl(`${e}-${t}`,()=>[[`datasets.${e}.elements.${t}`,`datasets.${e}`,`elements.${t}`,``]])}pluginScopeKeys(e){let t=e.id,n=this.type;return fl(`${n}-plugin-${t}`,()=>[[`plugins.${t}`,...e.additionalOptionScopes||[]]])}_cachedScopes(e,t){let n=this._scopeCache,r=n.get(e);return(!r||t)&&(r=new Map,n.set(e,r)),r}getOptionScopes(e,t,n){let{options:r,type:i}=this,a=this._cachedScopes(e,n),o=a.get(t);if(o)return o;let s=new Set;t.forEach(t=>{e&&(s.add(e),t.forEach(t=>pl(s,e,t))),t.forEach(e=>pl(s,r,e)),t.forEach(e=>pl(s,Pi[i]||{},e)),t.forEach(e=>pl(s,J,e)),t.forEach(e=>pl(s,Fi,e))});let c=Array.from(s);return c.length===0&&c.push(Object.create(null)),dl.has(t)&&a.set(t,c),c}chartOptionScopes(){let{options:e,type:t}=this;return[e,Pi[t]||{},J.datasets[t]||{},{type:t},J,Fi]}resolveNamedOptions(e,t,n,r=[``]){let i={$shared:!0},{resolver:a,subPrefixes:o}=hl(this._resolverCache,e,r),s=a;if(_l(a,t)){i.$shared=!1,n=Or(n)?n():n;let t=this.createResolver(e,n,o);s=fa(a,n,t)}for(let e of t)i[e]=s[e];return i}createResolver(e,t,n=[``],r){let{resolver:i}=hl(this._resolverCache,e,n);return R(t)?fa(i,t,void 0,r):i}};function hl(e,t,n){let r=e.get(t);r||(r=new Map,e.set(t,r));let i=n.join(),a=r.get(i);return a||(a={resolver:da(t,n),subPrefixes:n.filter(e=>!e.toLowerCase().includes(`hover`))},r.set(i,a)),a}var gl=e=>R(e)&&Object.getOwnPropertyNames(e).some(t=>Or(e[t]));function _l(e,t){let{isScriptable:n,isIndexable:r}=pa(e);for(let i of t){let t=n(i),a=r(i),o=(a||t)&&e[i];if(t&&(Or(o)||gl(o))||a&&L(o))return!0}return!1}var vl=`4.5.1`,yl=[`top`,`bottom`,`left`,`right`,`chartArea`];function bl(e,t){return e===`top`||e===`bottom`||yl.indexOf(e)===-1&&t===`x`}function xl(e,t){return function(n,r){return n[e]===r[e]?n[t]-r[t]:n[e]-r[e]}}function Sl(e){let t=e.chart,n=t.options.animation;t.notifyPlugins(`afterRender`),V(n&&n.onComplete,[e],t)}function Cl(e){let t=e.chart,n=t.options.animation;V(n&&n.onProgress,[e],t)}function wl(e){return Va()&&typeof e==`string`?e=document.getElementById(e):e&&e.length&&(e=e[0]),e&&e.canvas&&(e=e.canvas),e}var Tl={},El=e=>{let t=wl(e);return Object.values(Tl).filter(e=>e.canvas===t).pop()};function Dl(e,t,n){let r=Object.keys(e);for(let i of r){let r=+i;if(r>=t){let a=e[i];delete e[i],(n>0||r>t)&&(e[r+n]=a)}}}function Ol(e,t,n,r){return!n||e.type===`mouseout`?null:r?t:e}var kl=class{static register(...e){Kc.add(...e),Al()}static unregister(...e){Kc.remove(...e),Al()}constructor(e,t){let n=this.config=new ml(t),r=wl(e),i=El(r);if(i)throw Error(`Canvas is already in use. Chart with ID '`+i.id+`' must be destroyed before the canvas with ID '`+i.canvas.id+`' can be reused.`);let a=n.createResolver(n.chartOptionScopes(),this.getContext());this.platform=new(n.platform||(bc(r))),this.platform.updateConfig(n);let o=this.platform.acquireContext(r,a.aspectRatio),s=o&&o.canvas,c=s&&s.height,l=s&&s.width;if(this.id=dr(),this.ctx=o,this.canvas=s,this.width=l,this.height=c,this._options=a,this._aspectRatio=this.aspectRatio,this._layers=[],this._metasets=[],this._stacks=void 0,this.boxes=[],this.currentDevicePixelRatio=void 0,this.chartArea=void 0,this._active=[],this._lastEvent=void 0,this._listeners={},this._responsiveListeners=void 0,this._sortedMetasets=[],this.scales={},this._plugins=new qc,this.$proxies={},this._hiddenIndices={},this.attached=!1,this._animationsDisabled=void 0,this.$context=void 0,this._doResize=ui(e=>this.update(e),a.resizeDelay||0),this._dataChanges=[],Tl[this.id]=this,!o||!s){console.error(`Failed to create chart: can't acquire context from the given item`);return}Do.listen(this,`complete`,Sl),Do.listen(this,`progress`,Cl),this._initialize(),this.attached&&this.update()}get aspectRatio(){let{options:{aspectRatio:e,maintainAspectRatio:t},width:n,height:r,_aspectRatio:i}=this;return I(e)?t&&i?i:r?n/r:null:e}get data(){return this.config.data}set data(e){this.config.data=e}get options(){return this._options}set options(e){this.config.options=e}get registry(){return Kc}_initialize(){return this.notifyPlugins(`beforeInit`),this.options.responsive?this.resize():eo(this,this.options.devicePixelRatio),this.bindEvents(),this.notifyPlugins(`afterInit`),this}clear(){return Hi(this.canvas,this.ctx),this}stop(){return Do.stop(this),this}resize(e,t){Do.running(this)?this._resizeBeforeDraw={width:e,height:t}:this._resize(e,t)}_resize(e,t){let n=this.options,r=this.canvas,i=n.maintainAspectRatio&&this.aspectRatio,a=this.platform.getMaximumSize(r,e,t,i),o=n.devicePixelRatio||this.platform.getDevicePixelRatio(),s=this.width?`resize`:`attach`;this.width=a.width,this.height=a.height,this._aspectRatio=this.aspectRatio,eo(this,o,!0)&&(this.notifyPlugins(`resize`,{size:a}),V(n.onResize,[this,a],this),this.attached&&this._doResize(s)&&this.render())}ensureScalesHaveIDs(){H(this.options.scales||{},(e,t)=>{e.id=t})}buildOrUpdateScales(){let e=this.options,t=e.scales,n=this.scales,r=Object.keys(n).reduce((e,t)=>(e[t]=!1,e),{}),i=[];t&&(i=i.concat(Object.keys(t).map(e=>{let n=t[e],r=rl(e,n),i=r===`r`,a=r===`x`;return{options:n,dposition:i?`chartArea`:a?`bottom`:`left`,dtype:i?`radialLinear`:a?`category`:`linear`}}))),H(i,t=>{let i=t.options,a=i.id,o=rl(a,i),s=B(i.type,t.dtype);(i.position===void 0||bl(i.position,o)!==bl(t.dposition))&&(i.position=t.dposition),r[a]=!0;let c=null;a in n&&n[a].type===s?c=n[a]:(c=new(Kc.getScale(s))({id:a,type:s,ctx:this.ctx,chart:this}),n[c.id]=c),c.init(i,e)}),H(r,(e,t)=>{e||delete n[t]}),H(n,e=>{Zs.configure(this,e,e.options),Zs.addBox(this,e)})}_updateMetasets(){let e=this._metasets,t=this.data.datasets.length,n=e.length;if(e.sort((e,t)=>e.index-t.index),n>t){for(let e=t;e<n;++e)this._destroyDatasetMeta(e);e.splice(t,n-t)}this._sortedMetasets=e.slice(0).sort(xl(`order`,`index`))}_removeUnreferencedMetasets(){let{_metasets:e,data:{datasets:t}}=this;e.length>t.length&&delete this._stacks,e.forEach((e,n)=>{t.filter(t=>t===e._dataset).length===0&&this._destroyDatasetMeta(n)})}buildOrUpdateControllers(){let e=[],t=this.data.datasets,n,r;for(this._removeUnreferencedMetasets(),n=0,r=t.length;n<r;n++){let r=t[n],i=this.getDatasetMeta(n),a=r.type||this.config.type;if(i.type&&i.type!==a&&(this._destroyDatasetMeta(n),i=this.getDatasetMeta(n)),i.type=a,i.indexAxis=r.indexAxis||Qc(a,this.options),i.order=r.order||0,i.index=n,i.label=``+r.label,i.visible=this.isDatasetVisible(n),i.controller)i.controller.updateIndex(n),i.controller.linkScales();else{let t=Kc.getController(a),{datasetElementType:r,dataElementType:o}=J.datasets[a];Object.assign(t,{dataElementType:Kc.getElement(o),datasetElementType:r&&Kc.getElement(r)}),i.controller=new t(this,n),e.push(i.controller)}}return this._updateMetasets(),e}_resetElements(){H(this.data.datasets,(e,t)=>{this.getDatasetMeta(t).controller.reset()},this)}reset(){this._resetElements(),this.notifyPlugins(`reset`)}update(e){let t=this.config;t.update();let n=this._options=t.createResolver(t.chartOptionScopes(),this.getContext()),r=this._animationsDisabled=!n.animation;if(this._updateScales(),this._checkEventBindings(),this._updateHiddenIndices(),this._plugins.invalidate(),this.notifyPlugins(`beforeUpdate`,{mode:e,cancelable:!0})===!1)return;let i=this.buildOrUpdateControllers();this.notifyPlugins(`beforeElementsUpdate`);let a=0;for(let e=0,t=this.data.datasets.length;e<t;e++){let{controller:t}=this.getDatasetMeta(e),n=!r&&i.indexOf(t)===-1;t.buildOrUpdateElements(n),a=Math.max(+t.getMaxOverflow(),a)}a=this._minPadding=n.layout.autoPadding?a:0,this._updateLayout(a),r||H(i,e=>{e.reset()}),this._updateDatasets(e),this.notifyPlugins(`afterUpdate`,{mode:e}),this._layers.sort(xl(`z`,`_idx`));let{_active:o,_lastEvent:s}=this;s?this._eventHandler(s,!0):o.length&&this._updateHoverStyles(o,o,!0),this.render()}_updateScales(){H(this.scales,e=>{Zs.removeBox(this,e)}),this.ensureScalesHaveIDs(),this.buildOrUpdateScales()}_checkEventBindings(){let e=this.options;(!kr(new Set(Object.keys(this._listeners)),new Set(e.events))||!!this._responsiveListeners!==e.responsive)&&(this.unbindEvents(),this.bindEvents())}_updateHiddenIndices(){let{_hiddenIndices:e}=this,t=this._getUniformDataChanges()||[];for(let{method:n,start:r,count:i}of t)Dl(e,r,n===`_removeElements`?-i:i)}_getUniformDataChanges(){let e=this._dataChanges;if(!e||!e.length)return;this._dataChanges=[];let t=this.data.datasets.length,n=t=>new Set(e.filter(e=>e[0]===t).map((e,t)=>t+`,`+e.splice(1).join(`,`))),r=n(0);for(let e=1;e<t;e++)if(!kr(r,n(e)))return;return Array.from(r).map(e=>e.split(`,`)).map(e=>({method:e[1],start:+e[2],count:+e[3]}))}_updateLayout(e){if(this.notifyPlugins(`beforeLayout`,{cancelable:!0})===!1)return;Zs.update(this,this.width,this.height,e);let t=this.chartArea,n=t.width<=0||t.height<=0;this._layers=[],H(this.boxes,e=>{n&&e.position===`chartArea`||(e.configure&&e.configure(),this._layers.push(...e._layers()))},this),this._layers.forEach((e,t)=>{e._idx=t}),this.notifyPlugins(`afterLayout`)}_updateDatasets(e){if(this.notifyPlugins(`beforeDatasetsUpdate`,{mode:e,cancelable:!0})!==!1){for(let e=0,t=this.data.datasets.length;e<t;++e)this.getDatasetMeta(e).controller.configure();for(let t=0,n=this.data.datasets.length;t<n;++t)this._updateDataset(t,Or(e)?e({datasetIndex:t}):e);this.notifyPlugins(`afterDatasetsUpdate`,{mode:e})}}_updateDataset(e,t){let n=this.getDatasetMeta(e),r={meta:n,index:e,mode:t,cancelable:!0};this.notifyPlugins(`beforeDatasetUpdate`,r)!==!1&&(n.controller._update(t),r.cancelable=!1,this.notifyPlugins(`afterDatasetUpdate`,r))}render(){this.notifyPlugins(`beforeRender`,{cancelable:!0})!==!1&&(Do.has(this)?this.attached&&!Do.running(this)&&Do.start(this):(this.draw(),Sl({chart:this})))}draw(){let e;if(this._resizeBeforeDraw){let{width:e,height:t}=this._resizeBeforeDraw;this._resizeBeforeDraw=null,this._resize(e,t)}if(this.clear(),this.width<=0||this.height<=0||this.notifyPlugins(`beforeDraw`,{cancelable:!0})===!1)return;let t=this._layers;for(e=0;e<t.length&&t[e].z<=0;++e)t[e].draw(this.chartArea);for(this._drawDatasets();e<t.length;++e)t[e].draw(this.chartArea);this.notifyPlugins(`afterDraw`)}_getSortedDatasetMetas(e){let t=this._sortedMetasets,n=[],r,i;for(r=0,i=t.length;r<i;++r){let i=t[r];(!e||i.visible)&&n.push(i)}return n}getSortedVisibleDatasetMetas(){return this._getSortedDatasetMetas(!0)}_drawDatasets(){if(this.notifyPlugins(`beforeDatasetsDraw`,{cancelable:!0})===!1)return;let e=this.getSortedVisibleDatasetMetas();for(let t=e.length-1;t>=0;--t)this._drawDataset(e[t]);this.notifyPlugins(`afterDatasetsDraw`)}_drawDataset(e){let t=this.ctx,n={meta:e,index:e.index,cancelable:!0},r=Eo(this,e);this.notifyPlugins(`beforeDatasetDraw`,n)!==!1&&(r&&Ki(t,r),e.controller.draw(),r&&qi(t),n.cancelable=!1,this.notifyPlugins(`afterDatasetDraw`,n))}isPointInArea(e){return Gi(e,this.chartArea,this._minPadding)}getElementsAtEventForMode(e,t,n,r){let i=Ps.modes[t];return typeof i==`function`?i(this,e,n,r):[]}getDatasetMeta(e){let t=this.data.datasets[e],n=this._metasets,r=n.filter(e=>e&&e._dataset===t).pop();return r||(r={type:null,data:[],dataset:null,controller:null,hidden:null,xAxisID:null,yAxisID:null,order:t&&t.order||0,index:e,_dataset:t,_parsed:[],_sorted:!1},n.push(r)),r}getContext(){return this.$context||=ua(null,{chart:this,type:`chart`})}getVisibleDatasetCount(){return this.getSortedVisibleDatasetMetas().length}isDatasetVisible(e){let t=this.data.datasets[e];if(!t)return!1;let n=this.getDatasetMeta(e);return typeof n.hidden==`boolean`?!n.hidden:!t.hidden}setDatasetVisibility(e,t){let n=this.getDatasetMeta(e);n.hidden=!t}toggleDataVisibility(e){this._hiddenIndices[e]=!this._hiddenIndices[e]}getDataVisibility(e){return!this._hiddenIndices[e]}_updateVisibility(e,t,n){let r=n?`show`:`hide`,i=this.getDatasetMeta(e),a=i.controller._resolveAnimations(void 0,r);Dr(t)?(i.data[t].hidden=!n,this.update()):(this.setDatasetVisibility(e,n),a.update(i,{visible:n}),this.update(t=>t.datasetIndex===e?r:void 0))}hide(e,t){this._updateVisibility(e,t,!1)}show(e,t){this._updateVisibility(e,t,!0)}_destroyDatasetMeta(e){let t=this._metasets[e];t&&t.controller&&t.controller._destroy(),delete this._metasets[e]}_stop(){let e,t;for(this.stop(),Do.remove(this),e=0,t=this.data.datasets.length;e<t;++e)this._destroyDatasetMeta(e)}destroy(){this.notifyPlugins(`beforeDestroy`);let{canvas:e,ctx:t}=this;this._stop(),this.config.clearCache(),e&&(this.unbindEvents(),Hi(e,t),this.platform.releaseContext(t),this.canvas=null,this.ctx=null),delete Tl[this.id],this.notifyPlugins(`afterDestroy`)}toBase64Image(...e){return this.canvas.toDataURL(...e)}bindEvents(){this.bindUserEvents(),this.options.responsive?this.bindResponsiveEvents():this.attached=!0}bindUserEvents(){let e=this._listeners,t=this.platform,n=(n,r)=>{t.addEventListener(this,n,r),e[n]=r},r=(e,t,n)=>{e.offsetX=t,e.offsetY=n,this._eventHandler(e)};H(this.options.events,e=>n(e,r))}bindResponsiveEvents(){this._responsiveListeners||={};let e=this._responsiveListeners,t=this.platform,n=(n,r)=>{t.addEventListener(this,n,r),e[n]=r},r=(n,r)=>{e[n]&&(t.removeEventListener(this,n,r),delete e[n])},i=(e,t)=>{this.canvas&&this.resize(e,t)},a,o=()=>{r(`attach`,o),this.attached=!0,this.resize(),n(`resize`,i),n(`detach`,a)};a=()=>{this.attached=!1,r(`resize`,i),this._stop(),this._resize(0,0),n(`attach`,o)},t.isAttached(this.canvas)?o():a()}unbindEvents(){H(this._listeners,(e,t)=>{this.platform.removeEventListener(this,t,e)}),this._listeners={},H(this._responsiveListeners,(e,t)=>{this.platform.removeEventListener(this,t,e)}),this._responsiveListeners=void 0}updateHoverStyle(e,t,n){let r=n?`set`:`remove`,i,a,o,s;for(t===`dataset`&&(i=this.getDatasetMeta(e[0].datasetIndex),i.controller[`_`+r+`DatasetHoverStyle`]()),o=0,s=e.length;o<s;++o){a=e[o];let t=a&&this.getDatasetMeta(a.datasetIndex).controller;t&&t[r+`HoverStyle`](a.element,a.datasetIndex,a.index)}}getActiveElements(){return this._active||[]}setActiveElements(e){let t=this._active||[],n=e.map(({datasetIndex:e,index:t})=>{let n=this.getDatasetMeta(e);if(!n)throw Error(`No dataset found at index `+e);return{datasetIndex:e,element:n.data[t],index:t}});hr(n,t)||(this._active=n,this._lastEvent=null,this._updateHoverStyles(n,t))}notifyPlugins(e,t,n){return this._plugins.notify(this,e,t,n)}isPluginEnabled(e){return this._plugins._cache.filter(t=>t.plugin.id===e).length===1}_updateHoverStyles(e,t,n){let r=this.options.hover,i=(e,t)=>e.filter(e=>!t.some(t=>e.datasetIndex===t.datasetIndex&&e.index===t.index)),a=i(t,e),o=n?e:i(e,t);a.length&&this.updateHoverStyle(a,r.mode,!1),o.length&&r.mode&&this.updateHoverStyle(o,r.mode,!0)}_eventHandler(e,t){let n={event:e,replay:t,cancelable:!0,inChartArea:this.isPointInArea(e)},r=t=>(t.options.events||this.options.events).includes(e.native.type);if(this.notifyPlugins(`beforeEvent`,n,r)===!1)return;let i=this._handleEvent(e,t,n.inChartArea);return n.cancelable=!1,this.notifyPlugins(`afterEvent`,n,r),(i||n.changed)&&this.render(),this}_handleEvent(e,t,n){let{_active:r=[],options:i}=this,a=t,o=this._getActiveElements(e,r,n,a),s=Ar(e),c=Ol(e,this._lastEvent,n,s);n&&(this._lastEvent=null,V(i.onHover,[e,o,this],this),s&&V(i.onClick,[e,o,this],this));let l=!hr(o,r);return(l||t)&&(this._active=o,this._updateHoverStyles(o,r,t)),this._lastEvent=c,l}_getActiveElements(e,t,n,r){if(e.type===`mouseout`)return[];if(!n)return t;let i=this.options.hover;return this.getElementsAtEventForMode(e,i.mode,i,r)}};f(kl,`defaults`,J),f(kl,`instances`,Tl),f(kl,`overrides`,Pi),f(kl,`registry`,Kc),f(kl,`version`,vl),f(kl,`getChart`,El);function Al(){return H(kl.instances,e=>e._plugins.invalidate())}function jl(e,t,n){let{startAngle:r,x:i,y:a,outerRadius:o,innerRadius:s,options:c}=t,{borderWidth:l,borderJoinStyle:u}=c,d=Math.min(l/o,K(r-n));if(e.beginPath(),e.arc(i,a,o-l/2,r+d/2,n-d/2),s>0){let t=Math.min(l/s,K(r-n));e.arc(i,a,s+l/2,n-t/2,r+t/2,!0)}else{let t=Math.min(l/2,o*K(r-n));if(u===`round`)e.arc(i,a,t,n-U/2,r+U/2,!0);else if(u===`bevel`){let o=2*t*t,s=-o*Math.cos(n+U/2)+i,c=-o*Math.sin(n+U/2)+a,l=o*Math.cos(r+U/2)+i,u=o*Math.sin(r+U/2)+a;e.lineTo(s,c),e.lineTo(l,u)}}e.closePath(),e.moveTo(0,0),e.rect(0,0,e.canvas.width,e.canvas.height),e.clip(`evenodd`)}function Ml(e,t,n){let{startAngle:r,pixelMargin:i,x:a,y:o,outerRadius:s,innerRadius:c}=t,l=i/s;e.beginPath(),e.arc(a,o,s,r-l,n+l),c>i?(l=i/c,e.arc(a,o,c,n+l,r-l,!0)):e.arc(a,o,i,n+G,r-G),e.closePath(),e.clip()}function Nl(e){return aa(e,[`outerStart`,`outerEnd`,`innerStart`,`innerEnd`])}function Pl(e,t,n,r){let i=Nl(e.options.borderRadius),a=(n-t)/2,o=Math.min(a,r*t/2),s=e=>{let t=(n-Math.min(a,e))*r/2;return q(e,0,Math.min(a,t))};return{outerStart:s(i.outerStart),outerEnd:s(i.outerEnd),innerStart:q(i.innerStart,0,o),innerEnd:q(i.innerEnd,0,o)}}function Fl(e,t,n,r){return{x:n+e*Math.cos(t),y:r+e*Math.sin(t)}}function Il(e,t,n,r,i,a){let{x:o,y:s,startAngle:c,pixelMargin:l,innerRadius:u}=t,d=Math.max(t.outerRadius+r+n-l,0),f=u>0?u+r+n+l:0,p=0,m=i-c;if(r){let e=((u>0?u-r:0)+(d>0?d-r:0))/2;p=(m-(e===0?m:m*e/(e+r)))/2}let h=(m-Math.max(.001,m*d-n/U)/d)/2,g=c+h+p,_=i-h-p,{outerStart:v,outerEnd:y,innerStart:b,innerEnd:x}=Pl(t,f,d,_-g),S=d-v,C=d-y,w=g+v/S,T=_-y/C,E=f+b,D=f+x,ee=g+b/E,te=_-x/D;if(e.beginPath(),a){let t=(w+T)/2;if(e.arc(o,s,d,w,t),e.arc(o,s,d,t,T),y>0){let t=Fl(C,T,o,s);e.arc(t.x,t.y,y,T,_+G)}let n=Fl(D,_,o,s);if(e.lineTo(n.x,n.y),x>0){let t=Fl(D,te,o,s);e.arc(t.x,t.y,x,_+G,te+Math.PI)}let r=(_-x/f+(g+b/f))/2;if(e.arc(o,s,f,_-x/f,r,!0),e.arc(o,s,f,r,g+b/f,!0),b>0){let t=Fl(E,ee,o,s);e.arc(t.x,t.y,b,ee+Math.PI,g-G)}let i=Fl(S,g,o,s);if(e.lineTo(i.x,i.y),v>0){let t=Fl(S,w,o,s);e.arc(t.x,t.y,v,g-G,w)}}else{e.moveTo(o,s);let t=Math.cos(w)*d+o,n=Math.sin(w)*d+s;e.lineTo(t,n);let r=Math.cos(T)*d+o,i=Math.sin(T)*d+s;e.lineTo(r,i)}e.closePath()}function Ll(e,t,n,r,i){let{fullCircles:a,startAngle:o,circumference:s}=t,c=t.endAngle;if(a){Il(e,t,n,r,c,i);for(let t=0;t<a;++t)e.fill();isNaN(s)||(c=o+(s%W||W))}return Il(e,t,n,r,c,i),e.fill(),c}function Rl(e,t,n,r,i){let{fullCircles:a,startAngle:o,circumference:s,options:c}=t,{borderWidth:l,borderJoinStyle:u,borderDash:d,borderDashOffset:f,borderRadius:p}=c,m=c.borderAlign===`inner`;if(!l)return;e.setLineDash(d||[]),e.lineDashOffset=f,m?(e.lineWidth=l*2,e.lineJoin=u||`round`):(e.lineWidth=l,e.lineJoin=u||`bevel`);let h=t.endAngle;if(a){Il(e,t,n,r,h,i);for(let t=0;t<a;++t)e.stroke();isNaN(s)||(h=o+(s%W||W))}m&&Ml(e,t,h),c.selfJoin&&h-o>=U&&p===0&&u!==`miter`&&jl(e,t,h),a||(Il(e,t,n,r,h,i),e.stroke())}var zl=class extends xc{constructor(e){super(),f(this,`circumference`,void 0),f(this,`endAngle`,void 0),f(this,`fullCircles`,void 0),f(this,`innerRadius`,void 0),f(this,`outerRadius`,void 0),f(this,`pixelMargin`,void 0),f(this,`startAngle`,void 0),this.options=void 0,this.circumference=void 0,this.startAngle=void 0,this.endAngle=void 0,this.innerRadius=void 0,this.outerRadius=void 0,this.pixelMargin=0,this.fullCircles=0,e&&Object.assign(this,e)}inRange(e,t,n){let{angle:r,distance:i}=Jr(this.getProps([`x`,`y`],n),{x:e,y:t}),{startAngle:a,endAngle:o,innerRadius:s,outerRadius:c,circumference:l}=this.getProps([`startAngle`,`endAngle`,`innerRadius`,`outerRadius`,`circumference`],n),u=(this.options.spacing+this.options.borderWidth)/2,d=B(l,o-a),f=Zr(r,a,o)&&a!==o,p=d>=W||f,m=$r(i,s+u,c+u);return p&&m}getCenterPoint(e){let{x:t,y:n,startAngle:r,endAngle:i,innerRadius:a,outerRadius:o}=this.getProps([`x`,`y`,`startAngle`,`endAngle`,`innerRadius`,`outerRadius`],e),{offset:s,spacing:c}=this.options,l=(r+i)/2,u=(a+o+c+s)/2;return{x:t+Math.cos(l)*u,y:n+Math.sin(l)*u}}tooltipPosition(e){return this.getCenterPoint(e)}draw(e){let{options:t,circumference:n}=this,r=(t.offset||0)/4,i=(t.spacing||0)/2,a=t.circular;if(this.pixelMargin=t.borderAlign===`inner`?.33:0,this.fullCircles=n>W?Math.floor(n/W):0,n===0||this.innerRadius<0||this.outerRadius<0)return;e.save();let o=(this.startAngle+this.endAngle)/2;e.translate(Math.cos(o)*r,Math.sin(o)*r);let s=r*(1-Math.sin(Math.min(U,n||0)));e.fillStyle=t.backgroundColor,e.strokeStyle=t.borderColor,Ll(e,this,s,i,a),Rl(e,this,s,i,a),e.restore()}};f(zl,`id`,`arc`),f(zl,`defaults`,{borderAlign:`center`,borderColor:`#fff`,borderDash:[],borderDashOffset:0,borderJoinStyle:void 0,borderRadius:0,borderWidth:2,offset:0,spacing:0,angle:void 0,circular:!0,selfJoin:!1}),f(zl,`defaultRoutes`,{backgroundColor:`backgroundColor`}),f(zl,`descriptors`,{_scriptable:!0,_indexable:e=>e!==`borderDash`});function Bl(e,t,n=t){e.lineCap=B(n.borderCapStyle,t.borderCapStyle),e.setLineDash(B(n.borderDash,t.borderDash)),e.lineDashOffset=B(n.borderDashOffset,t.borderDashOffset),e.lineJoin=B(n.borderJoinStyle,t.borderJoinStyle),e.lineWidth=B(n.borderWidth,t.borderWidth),e.strokeStyle=B(n.borderColor,t.borderColor)}function Vl(e,t,n){e.lineTo(n.x,n.y)}function Hl(e){return e.stepped?Ji:e.tension||e.cubicInterpolationMode===`monotone`?Yi:Vl}function Ul(e,t,n={}){let r=e.length,{start:i=0,end:a=r-1}=n,{start:o,end:s}=t,c=Math.max(i,o),l=Math.min(a,s),u=i<o&&a<o||i>s&&a>s;return{count:r,start:c,loop:t.loop,ilen:l<c&&!u?r+l-c:l-c}}function Wl(e,t,n,r){let{points:i,options:a}=t,{count:o,start:s,loop:c,ilen:l}=Ul(i,n,r),u=Hl(a),{move:d=!0,reverse:f}=r||{},p,m,h;for(p=0;p<=l;++p)m=i[(s+(f?l-p:p))%o],!m.skip&&(d?(e.moveTo(m.x,m.y),d=!1):u(e,h,m,f,a.stepped),h=m);return c&&(m=i[(s+(f?l:0))%o],u(e,h,m,f,a.stepped)),!!c}function Gl(e,t,n,r){let i=t.points,{count:a,start:o,ilen:s}=Ul(i,n,r),{move:c=!0,reverse:l}=r||{},u=0,d=0,f,p,m,h,g,_,v=e=>(o+(l?s-e:e))%a,y=()=>{h!==g&&(e.lineTo(u,g),e.lineTo(u,h),e.lineTo(u,_))};for(c&&(p=i[v(0)],e.moveTo(p.x,p.y)),f=0;f<=s;++f){if(p=i[v(f)],p.skip)continue;let t=p.x,n=p.y,r=t|0;r===m?(n<h?h=n:n>g&&(g=n),u=(d*u+t)/++d):(y(),e.lineTo(t,n),m=r,d=0,h=g=n),_=n}y()}function Kl(e){let t=e.options,n=t.borderDash&&t.borderDash.length;return!e._decimated&&!e._loop&&!t.tension&&t.cubicInterpolationMode!==`monotone`&&!t.stepped&&!n?Gl:Wl}function ql(e){return e.stepped?io:e.tension||e.cubicInterpolationMode===`monotone`?ao:ro}function Jl(e,t,n,r){let i=t._path;i||(i=t._path=new Path2D,t.path(i,n,r)&&i.closePath()),Bl(e,t.options),e.stroke(i)}function Yl(e,t,n,r){let{segments:i,options:a}=t,o=Kl(t);for(let s of i)Bl(e,a,s.style),e.beginPath(),o(e,t,s,{start:n,end:n+r-1})&&e.closePath(),e.stroke()}var Xl=typeof Path2D==`function`;function Zl(e,t,n,r){Xl&&!t.options.segment?Jl(e,t,n,r):Yl(e,t,n,r)}var Ql=class extends xc{constructor(e){super(),this.animated=!0,this.options=void 0,this._chart=void 0,this._loop=void 0,this._fullLoop=void 0,this._path=void 0,this._points=void 0,this._segments=void 0,this._decimated=!1,this._pointsUpdated=!1,this._datasetIndex=void 0,e&&Object.assign(this,e)}updateControlPoints(e,t){let n=this.options;if((n.tension||n.cubicInterpolationMode===`monotone`)&&!n.stepped&&!this._pointsUpdated){let r=n.spanGaps?this._loop:this._fullLoop;Ba(this._points,n,e,r,t),this._pointsUpdated=!0}}set points(e){this._points=e,delete this._segments,delete this._path,this._pointsUpdated=!1}get points(){return this._points}get segments(){return this._segments||=yo(this,this.options.segment)}first(){let e=this.segments,t=this.points;return e.length&&t[e[0].start]}last(){let e=this.segments,t=this.points,n=e.length;return n&&t[e[n-1].end]}interpolate(e,t){let n=this.options,r=e[t],i=this.points,a=go(this,{property:t,start:r,end:r});if(!a.length)return;let o=[],s=ql(n),c,l;for(c=0,l=a.length;c<l;++c){let{start:l,end:u}=a[c],d=i[l],f=i[u];if(d===f){o.push(d);continue}let p=s(d,f,Math.abs((r-d[t])/(f[t]-d[t])),n.stepped);p[t]=e[t],o.push(p)}return o.length===1?o[0]:o}pathSegment(e,t,n){return Kl(this)(e,this,t,n)}path(e,t,n){let r=this.segments,i=Kl(this),a=this._loop;t||=0,n||=this.points.length-t;for(let o of r)a&=i(e,this,o,{start:t,end:t+n-1});return!!a}draw(e,t,n,r){let i=this.options||{};(this.points||[]).length&&i.borderWidth&&(e.save(),Zl(e,this,n,r),e.restore()),this.animated&&(this._pointsUpdated=!1,this._path=void 0)}};f(Ql,`id`,`line`),f(Ql,`defaults`,{borderCapStyle:`butt`,borderDash:[],borderDashOffset:0,borderJoinStyle:`miter`,borderWidth:3,capBezierPoints:!0,cubicInterpolationMode:`default`,fill:!1,spanGaps:!1,stepped:!1,tension:0}),f(Ql,`defaultRoutes`,{backgroundColor:`backgroundColor`,borderColor:`borderColor`}),f(Ql,`descriptors`,{_scriptable:!0,_indexable:e=>e!==`borderDash`&&e!==`fill`});function $l(e,t,n,r){let i=e.options,{[n]:a}=e.getProps([n],r);return Math.abs(t-a)<i.radius+i.hitRadius}var eu=class extends xc{constructor(e){super(),f(this,`parsed`,void 0),f(this,`skip`,void 0),f(this,`stop`,void 0),this.options=void 0,this.parsed=void 0,this.skip=void 0,this.stop=void 0,e&&Object.assign(this,e)}inRange(e,t,n){let r=this.options,{x:i,y:a}=this.getProps([`x`,`y`],n);return(e-i)**2+(t-a)**2<(r.hitRadius+r.radius)**2}inXRange(e,t){return $l(this,e,`x`,t)}inYRange(e,t){return $l(this,e,`y`,t)}getCenterPoint(e){let{x:t,y:n}=this.getProps([`x`,`y`],e);return{x:t,y:n}}size(e){e=e||this.options||{};let t=e.radius||0;t=Math.max(t,t&&e.hoverRadius||0);let n=t&&e.borderWidth||0;return(t+n)*2}draw(e,t){let n=this.options;this.skip||n.radius<.1||!Gi(this,t,this.size(n)/2)||(e.strokeStyle=n.borderColor,e.lineWidth=n.borderWidth,e.fillStyle=n.backgroundColor,Ui(e,n,this.x,this.y))}getRange(){let e=this.options||{};return e.radius+e.hitRadius}};f(eu,`id`,`point`),f(eu,`defaults`,{borderWidth:1,hitRadius:1,hoverBorderWidth:1,hoverRadius:4,pointStyle:`circle`,radius:3,rotation:0}),f(eu,`defaultRoutes`,{backgroundColor:`backgroundColor`,borderColor:`borderColor`});function tu(e,t){let{x:n,y:r,base:i,width:a,height:o}=e.getProps([`x`,`y`,`base`,`width`,`height`],t),s,c,l,u,d;return e.horizontal?(d=o/2,s=Math.min(n,i),c=Math.max(n,i),l=r-d,u=r+d):(d=a/2,s=n-d,c=n+d,l=Math.min(r,i),u=Math.max(r,i)),{left:s,top:l,right:c,bottom:u}}function nu(e,t,n,r){return e?0:q(t,n,r)}function ru(e,t,n){let r=e.options.borderWidth,i=e.borderSkipped,a=oa(r);return{t:nu(i.top,a.top,0,n),r:nu(i.right,a.right,0,t),b:nu(i.bottom,a.bottom,0,n),l:nu(i.left,a.left,0,t)}}function iu(e,t,n){let{enableBorderRadius:r}=e.getProps([`enableBorderRadius`]),i=e.options.borderRadius,a=sa(i),o=Math.min(t,n),s=e.borderSkipped,c=r||R(i);return{topLeft:nu(!c||s.top||s.left,a.topLeft,0,o),topRight:nu(!c||s.top||s.right,a.topRight,0,o),bottomLeft:nu(!c||s.bottom||s.left,a.bottomLeft,0,o),bottomRight:nu(!c||s.bottom||s.right,a.bottomRight,0,o)}}function au(e){let t=tu(e),n=t.right-t.left,r=t.bottom-t.top,i=ru(e,n/2,r/2),a=iu(e,n/2,r/2);return{outer:{x:t.left,y:t.top,w:n,h:r,radius:a},inner:{x:t.left+i.l,y:t.top+i.t,w:n-i.l-i.r,h:r-i.t-i.b,radius:{topLeft:Math.max(0,a.topLeft-Math.max(i.t,i.l)),topRight:Math.max(0,a.topRight-Math.max(i.t,i.r)),bottomLeft:Math.max(0,a.bottomLeft-Math.max(i.b,i.l)),bottomRight:Math.max(0,a.bottomRight-Math.max(i.b,i.r))}}}}function ou(e,t,n,r){let i=t===null,a=n===null,o=e&&!(i&&a)&&tu(e,r);return o&&(i||$r(t,o.left,o.right))&&(a||$r(n,o.top,o.bottom))}function su(e){return e.topLeft||e.topRight||e.bottomLeft||e.bottomRight}function cu(e,t){e.rect(t.x,t.y,t.w,t.h)}function lu(e,t,n={}){let r=e.x===n.x?0:-t,i=e.y===n.y?0:-t,a=(e.x+e.w===n.x+n.w?0:t)-r,o=(e.y+e.h===n.y+n.h?0:t)-i;return{x:e.x+r,y:e.y+i,w:e.w+a,h:e.h+o,radius:e.radius}}var uu=class extends xc{constructor(e){super(),this.options=void 0,this.horizontal=void 0,this.base=void 0,this.width=void 0,this.height=void 0,this.inflateAmount=void 0,e&&Object.assign(this,e)}draw(e){let{inflateAmount:t,options:{borderColor:n,backgroundColor:r}}=this,{inner:i,outer:a}=au(this),o=su(a.radius)?ea:cu;e.save(),(a.w!==i.w||a.h!==i.h)&&(e.beginPath(),o(e,lu(a,t,i)),e.clip(),o(e,lu(i,-t,a)),e.fillStyle=n,e.fill(`evenodd`)),e.beginPath(),o(e,lu(i,t)),e.fillStyle=r,e.fill(),e.restore()}inRange(e,t,n){return ou(this,e,t,n)}inXRange(e,t){return ou(this,e,null,t)}inYRange(e,t){return ou(this,null,e,t)}getCenterPoint(e){let{x:t,y:n,base:r,horizontal:i}=this.getProps([`x`,`y`,`base`,`horizontal`],e);return{x:i?(t+r)/2:t,y:i?n:(n+r)/2}}getRange(e){return e===`x`?this.width/2:this.height/2}};f(uu,`id`,`bar`),f(uu,`defaults`,{borderSkipped:`start`,borderWidth:0,borderRadius:0,inflateAmount:`auto`,pointStyle:void 0}),f(uu,`defaultRoutes`,{backgroundColor:`backgroundColor`,borderColor:`borderColor`});function du(e,t,n){let r=e.segments,i=e.points,a=t.points,o=[];for(let e of r){let{start:r,end:s}=e;s=mu(r,s,i);let c=fu(n,i[r],i[s],e.loop);if(!t.segments){o.push({source:e,target:c,start:i[r],end:i[s]});continue}let l=go(t,c);for(let t of l){let r=fu(n,a[t.start],a[t.end],t.loop),s=ho(e,i,r);for(let e of s)o.push({source:e,target:t,start:{[n]:hu(c,r,`start`,Math.max)},end:{[n]:hu(c,r,`end`,Math.min)}})}}return o}function fu(e,t,n,r){if(r)return;let i=t[e],a=n[e];return e===`angle`&&(i=K(i),a=K(a)),{property:e,start:i,end:a}}function pu(e,t){let{x:n=null,y:r=null}=e||{},i=t.points,a=[];return t.segments.forEach(({start:e,end:t})=>{t=mu(e,t,i);let o=i[e],s=i[t];r===null?n!==null&&(a.push({x:n,y:o.y}),a.push({x:n,y:s.y})):(a.push({x:o.x,y:r}),a.push({x:s.x,y:r}))}),a}function mu(e,t,n){for(;t>e;t--){let e=n[t];if(!isNaN(e.x)&&!isNaN(e.y))break}return t}function hu(e,t,n,r){return e&&t?r(e[n],t[n]):e?e[n]:t?t[n]:0}function gu(e,t){let n=[],r=!1;return L(e)?(r=!0,n=e):n=pu(e,t),n.length?new Ql({points:n,options:{tension:0},_loop:r,_fullLoop:r}):null}function _u(e){return e&&e.fill!==!1}function vu(e,t,n){let r=e[t].fill,i=[t],a;if(!n)return r;for(;r!==!1&&i.indexOf(r)===-1;){if(!z(r))return r;if(a=e[r],!a)return!1;if(a.visible)return r;i.push(r),r=a.fill}return!1}function yu(e,t,n){let r=Cu(e);if(R(r))return isNaN(r.value)?!1:r;let i=parseFloat(r);return z(i)&&Math.floor(i)===i?bu(r[0],t,i,n):[`origin`,`start`,`end`,`stack`,`shape`].indexOf(r)>=0&&r}function bu(e,t,n,r){return(e===`-`||e===`+`)&&(n=t+n),n===t||n<0||n>=r?!1:n}function xu(e,t){let n=null;return e===`start`?n=t.bottom:e===`end`?n=t.top:R(e)?n=t.getPixelForValue(e.value):t.getBasePixel&&(n=t.getBasePixel()),n}function Su(e,t,n){let r;return r=e===`start`?n:e===`end`?t.options.reverse?t.min:t.max:R(e)?e.value:t.getBaseValue(),r}function Cu(e){let t=e.options,n=t.fill,r=B(n&&n.target,n);return r===void 0&&(r=!!t.backgroundColor),r===!1||r===null?!1:r===!0?`origin`:r}function wu(e){let{scale:t,index:n,line:r}=e,i=[],a=r.segments,o=r.points,s=Tu(t,n);s.push(gu({x:null,y:t.bottom},r));for(let e=0;e<a.length;e++){let t=a[e];for(let e=t.start;e<=t.end;e++)Eu(i,o[e],s)}return new Ql({points:i,options:{}})}function Tu(e,t){let n=[],r=e.getMatchingVisibleMetas(`line`);for(let e=0;e<r.length;e++){let i=r[e];if(i.index===t)break;i.hidden||n.unshift(i.dataset)}return n}function Eu(e,t,n){let r=[];for(let i=0;i<n.length;i++){let a=n[i],{first:o,last:s,point:c}=Du(a,t,`x`);if(!(!c||o&&s)){if(o)r.unshift(c);else if(e.push(c),!s)break}}e.push(...r)}function Du(e,t,n){let r=e.interpolate(t,n);if(!r)return{};let i=r[n],a=e.segments,o=e.points,s=!1,c=!1;for(let e=0;e<a.length;e++){let t=a[e],r=o[t.start][n],l=o[t.end][n];if($r(i,r,l)){s=i===r,c=i===l;break}}return{first:s,last:c,point:r}}var Ou=class{constructor(e){this.x=e.x,this.y=e.y,this.radius=e.radius}pathSegment(e,t,n){let{x:r,y:i,radius:a}=this;return t||={start:0,end:W},e.arc(r,i,a,t.end,t.start,!0),!n.bounds}interpolate(e){let{x:t,y:n,radius:r}=this,i=e.angle;return{x:t+Math.cos(i)*r,y:n+Math.sin(i)*r,angle:i}}};function ku(e){let{chart:t,fill:n,line:r}=e;if(z(n))return Au(t,n);if(n===`stack`)return wu(e);if(n===`shape`)return!0;let i=ju(e);return i instanceof Ou?i:gu(i,r)}function Au(e,t){let n=e.getDatasetMeta(t);return n&&e.isDatasetVisible(t)?n.dataset:null}function ju(e){return(e.scale||{}).getPointPositionForValue?Nu(e):Mu(e)}function Mu(e){let{scale:t={},fill:n}=e,r=xu(n,t);if(z(r)){let e=t.isHorizontal();return{x:e?r:null,y:e?null:r}}return null}function Nu(e){let{scale:t,fill:n}=e,r=t.options,i=t.getLabels().length,a=r.reverse?t.max:t.min,o=Su(n,t,a),s=[];if(r.grid.circular){let e=t.getPointPositionForValue(0,a);return new Ou({x:e.x,y:e.y,radius:t.getDistanceFromCenterForValue(o)})}for(let e=0;e<i;++e)s.push(t.getPointPositionForValue(e,o));return s}function Pu(e,t,n){let r=ku(t),{chart:i,index:a,line:o,scale:s,axis:c}=t,l=o.options,u=l.fill,d=l.backgroundColor,{above:f=d,below:p=d}=u||{},m=Eo(i,i.getDatasetMeta(a));r&&o.points.length&&(Ki(e,n),Fu(e,{line:o,target:r,above:f,below:p,area:n,scale:s,axis:c,clip:m}),qi(e))}function Fu(e,t){let{line:n,target:r,above:i,below:a,area:o,scale:s,clip:c}=t,l=n._loop?`angle`:t.axis;e.save();let u=a;a!==i&&(l===`x`?(Iu(e,r,o.top),Ru(e,{line:n,target:r,color:i,scale:s,property:l,clip:c}),e.restore(),e.save(),Iu(e,r,o.bottom)):l===`y`&&(Lu(e,r,o.left),Ru(e,{line:n,target:r,color:a,scale:s,property:l,clip:c}),e.restore(),e.save(),Lu(e,r,o.right),u=i)),Ru(e,{line:n,target:r,color:u,scale:s,property:l,clip:c}),e.restore()}function Iu(e,t,n){let{segments:r,points:i}=t,a=!0,o=!1;e.beginPath();for(let s of r){let{start:r,end:c}=s,l=i[r],u=i[mu(r,c,i)];a?(e.moveTo(l.x,l.y),a=!1):(e.lineTo(l.x,n),e.lineTo(l.x,l.y)),o=!!t.pathSegment(e,s,{move:o}),o?e.closePath():e.lineTo(u.x,n)}e.lineTo(t.first().x,n),e.closePath(),e.clip()}function Lu(e,t,n){let{segments:r,points:i}=t,a=!0,o=!1;e.beginPath();for(let s of r){let{start:r,end:c}=s,l=i[r],u=i[mu(r,c,i)];a?(e.moveTo(l.x,l.y),a=!1):(e.lineTo(n,l.y),e.lineTo(l.x,l.y)),o=!!t.pathSegment(e,s,{move:o}),o?e.closePath():e.lineTo(n,u.y)}e.lineTo(n,t.first().y),e.closePath(),e.clip()}function Ru(e,t){let{line:n,target:r,property:i,color:a,scale:o,clip:s}=t,c=du(n,r,i);for(let{source:t,target:l,start:u,end:d}of c){let{style:{backgroundColor:c=a}={}}=t,f=r!==!0;e.save(),e.fillStyle=c,zu(e,o,s,f&&fu(i,u,d)),e.beginPath();let p=!!n.pathSegment(e,t),m;if(f){p?e.closePath():Bu(e,r,d,i);let t=!!r.pathSegment(e,l,{move:p,reverse:!0});m=p&&t,m||Bu(e,r,u,i)}e.closePath(),e.fill(m?`evenodd`:`nonzero`),e.restore()}}function zu(e,t,n,r){let i=t.chart.chartArea,{property:a,start:o,end:s}=r||{};if(a===`x`||a===`y`){let t,r,c,l;a===`x`?(t=o,r=i.top,c=s,l=i.bottom):(t=i.left,r=o,c=i.right,l=s),e.beginPath(),n&&(t=Math.max(t,n.left),c=Math.min(c,n.right),r=Math.max(r,n.top),l=Math.min(l,n.bottom)),e.rect(t,r,c-t,l-r),e.clip()}}function Bu(e,t,n,r){let i=t.interpolate(n,r);i&&e.lineTo(i.x,i.y)}var Vu={id:`filler`,afterDatasetsUpdate(e,t,n){let r=(e.data.datasets||[]).length,i=[],a,o,s,c;for(o=0;o<r;++o)a=e.getDatasetMeta(o),s=a.dataset,c=null,s&&s.options&&s instanceof Ql&&(c={visible:e.isDatasetVisible(o),index:o,fill:yu(s,o,r),chart:e,axis:a.controller.options.indexAxis,scale:a.vScale,line:s}),a.$filler=c,i.push(c);for(o=0;o<r;++o)c=i[o],!(!c||c.fill===!1)&&(c.fill=vu(i,o,n.propagate))},beforeDraw(e,t,n){let r=n.drawTime===`beforeDraw`,i=e.getSortedVisibleDatasetMetas(),a=e.chartArea;for(let t=i.length-1;t>=0;--t){let n=i[t].$filler;n&&(n.line.updateControlPoints(a,n.axis),r&&n.fill&&Pu(e.ctx,n,a))}},beforeDatasetsDraw(e,t,n){if(n.drawTime!==`beforeDatasetsDraw`)return;let r=e.getSortedVisibleDatasetMetas();for(let t=r.length-1;t>=0;--t){let n=r[t].$filler;_u(n)&&Pu(e.ctx,n,e.chartArea)}},beforeDatasetDraw(e,t,n){let r=t.meta.$filler;!_u(r)||n.drawTime!==`beforeDatasetDraw`||Pu(e.ctx,r,e.chartArea)},defaults:{propagate:!0,drawTime:`beforeDatasetDraw`}},Hu=(e,t)=>{let{boxHeight:n=t,boxWidth:r=t}=e;return e.usePointStyle&&(n=Math.min(n,t),r=e.pointStyleWidth||Math.min(r,t)),{boxWidth:r,boxHeight:n,itemHeight:Math.max(t,n)}},Uu=(e,t)=>e!==null&&t!==null&&e.datasetIndex===t.datasetIndex&&e.index===t.index,Wu=class extends xc{constructor(e){super(),this._added=!1,this.legendHitBoxes=[],this._hoveredItem=null,this.doughnutMode=!1,this.chart=e.chart,this.options=e.options,this.ctx=e.ctx,this.legendItems=void 0,this.columnSizes=void 0,this.lineWidths=void 0,this.maxHeight=void 0,this.maxWidth=void 0,this.top=void 0,this.bottom=void 0,this.left=void 0,this.right=void 0,this.height=void 0,this.width=void 0,this._margins=void 0,this.position=void 0,this.weight=void 0,this.fullSize=void 0}update(e,t,n){this.maxWidth=e,this.maxHeight=t,this._margins=n,this.setDimensions(),this.buildLabels(),this.fit()}setDimensions(){this.isHorizontal()?(this.width=this.maxWidth,this.left=this._margins.left,this.right=this.width):(this.height=this.maxHeight,this.top=this._margins.top,this.bottom=this.height)}buildLabels(){let e=this.options.labels||{},t=V(e.generateLabels,[this.chart],this)||[];e.filter&&(t=t.filter(t=>e.filter(t,this.chart.data))),e.sort&&(t=t.sort((t,n)=>e.sort(t,n,this.chart.data))),this.options.reverse&&t.reverse(),this.legendItems=t}fit(){let{options:e,ctx:t}=this;if(!e.display){this.width=this.height=0;return}let n=e.labels,r=X(n.font),i=r.size,a=this._computeTitleHeight(),{boxWidth:o,itemHeight:s}=Hu(n,i),c,l;t.font=r.string,this.isHorizontal()?(c=this.maxWidth,l=this._fitRows(a,i,o,s)+10):(l=this.maxHeight,c=this._fitCols(a,r,o,s)+10),this.width=Math.min(c,e.maxWidth||this.maxWidth),this.height=Math.min(l,e.maxHeight||this.maxHeight)}_fitRows(e,t,n,r){let{ctx:i,maxWidth:a,options:{labels:{padding:o}}}=this,s=this.legendHitBoxes=[],c=this.lineWidths=[0],l=r+o,u=e;i.textAlign=`left`,i.textBaseline=`middle`;let d=-1,f=-l;return this.legendItems.forEach((e,p)=>{let m=n+t/2+i.measureText(e.text).width;(p===0||c[c.length-1]+m+2*o>a)&&(u+=l,c[c.length-(p>0?0:1)]=0,f+=l,d++),s[p]={left:0,top:f,row:d,width:m,height:r},c[c.length-1]+=m+o}),u}_fitCols(e,t,n,r){let{ctx:i,maxHeight:a,options:{labels:{padding:o}}}=this,s=this.legendHitBoxes=[],c=this.columnSizes=[],l=a-e,u=o,d=0,f=0,p=0,m=0;return this.legendItems.forEach((e,a)=>{let{itemWidth:h,itemHeight:g}=Gu(n,t,i,e,r);a>0&&f+g+2*o>l&&(u+=d+o,c.push({width:d,height:f}),p+=d+o,m++,d=f=0),s[a]={left:p,top:f,col:m,width:h,height:g},d=Math.max(d,h),f+=g+o}),u+=d,c.push({width:d,height:f}),u}adjustHitBoxes(){if(!this.options.display)return;let e=this._computeTitleHeight(),{legendHitBoxes:t,options:{align:n,labels:{padding:r},rtl:i}}=this,a=co(i,this.left,this.width);if(this.isHorizontal()){let i=0,o=fi(n,this.left+r,this.right-this.lineWidths[i]);for(let s of t)i!==s.row&&(i=s.row,o=fi(n,this.left+r,this.right-this.lineWidths[i])),s.top+=this.top+e+r,s.left=a.leftForLtr(a.x(o),s.width),o+=s.width+r}else{let i=0,o=fi(n,this.top+e+r,this.bottom-this.columnSizes[i].height);for(let s of t)s.col!==i&&(i=s.col,o=fi(n,this.top+e+r,this.bottom-this.columnSizes[i].height)),s.top=o,s.left+=this.left+r,s.left=a.leftForLtr(a.x(s.left),s.width),o+=s.height+r}}isHorizontal(){return this.options.position===`top`||this.options.position===`bottom`}draw(){if(this.options.display){let e=this.ctx;Ki(e,this),this._draw(),qi(e)}}_draw(){let{options:e,columnSizes:t,lineWidths:n,ctx:r}=this,{align:i,labels:a}=e,o=J.color,s=co(e.rtl,this.left,this.width),c=X(a.font),{padding:l}=a,u=c.size,d=u/2,f;this.drawTitle(),r.textAlign=s.textAlign(`left`),r.textBaseline=`middle`,r.lineWidth=.5,r.font=c.string;let{boxWidth:p,boxHeight:m,itemHeight:h}=Hu(a,u),g=function(e,t,n){if(isNaN(p)||p<=0||isNaN(m)||m<0)return;r.save();let i=B(n.lineWidth,1);if(r.fillStyle=B(n.fillStyle,o),r.lineCap=B(n.lineCap,`butt`),r.lineDashOffset=B(n.lineDashOffset,0),r.lineJoin=B(n.lineJoin,`miter`),r.lineWidth=i,r.strokeStyle=B(n.strokeStyle,o),r.setLineDash(B(n.lineDash,[])),a.usePointStyle)Wi(r,{radius:m*Math.SQRT2/2,pointStyle:n.pointStyle,rotation:n.rotation,borderWidth:i},s.xPlus(e,p/2),t+d,a.pointStyleWidth&&p);else{let a=t+Math.max((u-m)/2,0),o=s.leftForLtr(e,p),c=sa(n.borderRadius);r.beginPath(),Object.values(c).some(e=>e!==0)?ea(r,{x:o,y:a,w:p,h:m,radius:c}):r.rect(o,a,p,m),r.fill(),i!==0&&r.stroke()}r.restore()},_=function(e,t,n){$i(r,n.text,e,t+h/2,c,{strikethrough:n.hidden,textAlign:s.textAlign(n.textAlign)})},v=this.isHorizontal(),y=this._computeTitleHeight();f=v?{x:fi(i,this.left+l,this.right-n[0]),y:this.top+l+y,line:0}:{x:this.left+l,y:fi(i,this.top+y+l,this.bottom-t[0].height),line:0},lo(this.ctx,e.textDirection);let b=h+l;this.legendItems.forEach((o,u)=>{r.strokeStyle=o.fontColor,r.fillStyle=o.fontColor;let m=r.measureText(o.text).width,h=s.textAlign(o.textAlign||=a.textAlign),x=p+d+m,S=f.x,C=f.y;if(s.setWidth(this.width),v?u>0&&S+x+l>this.right&&(C=f.y+=b,f.line++,S=f.x=fi(i,this.left+l,this.right-n[f.line])):u>0&&C+b>this.bottom&&(S=f.x=S+t[f.line].width+l,f.line++,C=f.y=fi(i,this.top+y+l,this.bottom-t[f.line].height)),g(s.x(S),C,o),S=pi(h,S+p+d,v?S+x:this.right,e.rtl),_(s.x(S),C,o),v)f.x+=x+l;else if(typeof o.text!=`string`){let e=c.lineHeight;f.y+=Ju(o,e)+l}else f.y+=b}),uo(this.ctx,e.textDirection)}drawTitle(){let e=this.options,t=e.title,n=X(t.font),r=Y(t.padding);if(!t.display)return;let i=co(e.rtl,this.left,this.width),a=this.ctx,o=t.position,s=n.size/2,c=r.top+s,l,u=this.left,d=this.width;if(this.isHorizontal())d=Math.max(...this.lineWidths),l=this.top+c,u=fi(e.align,u,this.right-d);else{let t=this.columnSizes.reduce((e,t)=>Math.max(e,t.height),0);l=c+fi(e.align,this.top,this.bottom-t-e.labels.padding-this._computeTitleHeight())}let f=fi(o,u,u+d);a.textAlign=i.textAlign(di(o)),a.textBaseline=`middle`,a.strokeStyle=t.color,a.fillStyle=t.color,a.font=n.string,$i(a,t.text,f,l,n)}_computeTitleHeight(){let e=this.options.title,t=X(e.font),n=Y(e.padding);return e.display?t.lineHeight+n.height:0}_getLegendItemAt(e,t){let n,r,i;if($r(e,this.left,this.right)&&$r(t,this.top,this.bottom)){for(i=this.legendHitBoxes,n=0;n<i.length;++n)if(r=i[n],$r(e,r.left,r.left+r.width)&&$r(t,r.top,r.top+r.height))return this.legendItems[n]}return null}handleEvent(e){let t=this.options;if(!Yu(e.type,t))return;let n=this._getLegendItemAt(e.x,e.y);if(e.type===`mousemove`||e.type===`mouseout`){let r=this._hoveredItem,i=Uu(r,n);r&&!i&&V(t.onLeave,[e,r,this],this),this._hoveredItem=n,n&&!i&&V(t.onHover,[e,n,this],this)}else n&&V(t.onClick,[e,n,this],this)}};function Gu(e,t,n,r,i){return{itemWidth:Ku(r,e,t,n),itemHeight:qu(i,r,t.lineHeight)}}function Ku(e,t,n,r){let i=e.text;return i&&typeof i!=`string`&&(i=i.reduce((e,t)=>e.length>t.length?e:t)),t+n.size/2+r.measureText(i).width}function qu(e,t,n){let r=e;return typeof t.text!=`string`&&(r=Ju(t,n)),r}function Ju(e,t){return t*(e.text?e.text.length:0)}function Yu(e,t){return!!((e===`mousemove`||e===`mouseout`)&&(t.onHover||t.onLeave)||t.onClick&&(e===`click`||e===`mouseup`))}var Xu={id:`legend`,_element:Wu,start(e,t,n){let r=e.legend=new Wu({ctx:e.ctx,options:n,chart:e});Zs.configure(e,r,n),Zs.addBox(e,r)},stop(e){Zs.removeBox(e,e.legend),delete e.legend},beforeUpdate(e,t,n){let r=e.legend;Zs.configure(e,r,n),r.options=n},afterUpdate(e){let t=e.legend;t.buildLabels(),t.adjustHitBoxes()},afterEvent(e,t){t.replay||e.legend.handleEvent(t.event)},defaults:{display:!0,position:`top`,align:`center`,fullSize:!0,reverse:!1,weight:1e3,onClick(e,t,n){let r=t.datasetIndex,i=n.chart;i.isDatasetVisible(r)?(i.hide(r),t.hidden=!0):(i.show(r),t.hidden=!1)},onHover:null,onLeave:null,labels:{color:e=>e.chart.options.color,boxWidth:40,padding:10,generateLabels(e){let t=e.data.datasets,{labels:{usePointStyle:n,pointStyle:r,textAlign:i,color:a,useBorderRadius:o,borderRadius:s}}=e.legend.options;return e._getSortedDatasetMetas().map(e=>{let c=e.controller.getStyle(n?0:void 0),l=Y(c.borderWidth);return{text:t[e.index].label,fillStyle:c.backgroundColor,fontColor:a,hidden:!e.visible,lineCap:c.borderCapStyle,lineDash:c.borderDash,lineDashOffset:c.borderDashOffset,lineJoin:c.borderJoinStyle,lineWidth:(l.width+l.height)/4,strokeStyle:c.borderColor,pointStyle:r||c.pointStyle,rotation:c.rotation,textAlign:i||c.textAlign,borderRadius:o&&(s||c.borderRadius),datasetIndex:e.index}},this)}},title:{color:e=>e.chart.options.color,display:!1,position:`center`,text:``}},descriptors:{_scriptable:e=>!e.startsWith(`on`),labels:{_scriptable:e=>![`generateLabels`,`filter`,`sort`].includes(e)}}},Zu={average(e){if(!e.length)return!1;let t,n,r=new Set,i=0,a=0;for(t=0,n=e.length;t<n;++t){let n=e[t].element;if(n&&n.hasValue()){let e=n.tooltipPosition();r.add(e.x),i+=e.y,++a}}return a===0||r.size===0?!1:{x:[...r].reduce((e,t)=>e+t)/r.size,y:i/a}},nearest(e,t){if(!e.length)return!1;let n=t.x,r=t.y,i=1/0,a,o,s;for(a=0,o=e.length;a<o;++a){let n=e[a].element;if(n&&n.hasValue()){let e=Yr(t,n.getCenterPoint());e<i&&(i=e,s=n)}}if(s){let e=s.tooltipPosition();n=e.x,r=e.y}return{x:n,y:r}}};function Qu(e,t){return t&&(L(t)?Array.prototype.push.apply(e,t):e.push(t)),e}function $u(e){return(typeof e==`string`||e instanceof String)&&e.indexOf(`
`)>-1?e.split(`
`):e}function ed(e,t){let{element:n,datasetIndex:r,index:i}=t,a=e.getDatasetMeta(r).controller,{label:o,value:s}=a.getLabelAndValue(i);return{chart:e,label:o,parsed:a.getParsed(i),raw:e.data.datasets[r].data[i],formattedValue:s,dataset:a.getDataset(),dataIndex:i,datasetIndex:r,element:n}}function td(e,t){let n=e.chart.ctx,{body:r,footer:i,title:a}=e,{boxWidth:o,boxHeight:s}=t,c=X(t.bodyFont),l=X(t.titleFont),u=X(t.footerFont),d=a.length,f=i.length,p=r.length,m=Y(t.padding),h=m.height,g=0,_=r.reduce((e,t)=>e+t.before.length+t.lines.length+t.after.length,0);if(_+=e.beforeBody.length+e.afterBody.length,d&&(h+=d*l.lineHeight+(d-1)*t.titleSpacing+t.titleMarginBottom),_){let e=t.displayColors?Math.max(s,c.lineHeight):c.lineHeight;h+=p*e+(_-p)*c.lineHeight+(_-1)*t.bodySpacing}f&&(h+=t.footerMarginTop+f*u.lineHeight+(f-1)*t.footerSpacing);let v=0,y=function(e){g=Math.max(g,n.measureText(e).width+v)};return n.save(),n.font=l.string,H(e.title,y),n.font=c.string,H(e.beforeBody.concat(e.afterBody),y),v=t.displayColors?o+2+t.boxPadding:0,H(r,e=>{H(e.before,y),H(e.lines,y),H(e.after,y)}),v=0,n.font=u.string,H(e.footer,y),n.restore(),g+=m.width,{width:g,height:h}}function nd(e,t){let{y:n,height:r}=t;return n<r/2?`top`:n>e.height-r/2?`bottom`:`center`}function rd(e,t,n,r){let{x:i,width:a}=r,o=n.caretSize+n.caretPadding;if(e===`left`&&i+a+o>t.width||e===`right`&&i-a-o<0)return!0}function id(e,t,n,r){let{x:i,width:a}=n,{width:o,chartArea:{left:s,right:c}}=e,l=`center`;return r===`center`?l=i<=(s+c)/2?`left`:`right`:i<=a/2?l=`left`:i>=o-a/2&&(l=`right`),rd(l,e,t,n)&&(l=`center`),l}function ad(e,t,n){let r=n.yAlign||t.yAlign||nd(e,n);return{xAlign:n.xAlign||t.xAlign||id(e,t,n,r),yAlign:r}}function od(e,t){let{x:n,width:r}=e;return t===`right`?n-=r:t===`center`&&(n-=r/2),n}function sd(e,t,n){let{y:r,height:i}=e;return t===`top`?r+=n:t===`bottom`?r-=i+n:r-=i/2,r}function cd(e,t,n,r){let{caretSize:i,caretPadding:a,cornerRadius:o}=e,{xAlign:s,yAlign:c}=n,l=i+a,{topLeft:u,topRight:d,bottomLeft:f,bottomRight:p}=sa(o),m=od(t,s),h=sd(t,c,l);return c===`center`?s===`left`?m+=l:s===`right`&&(m-=l):s===`left`?m-=Math.max(u,f)+i:s===`right`&&(m+=Math.max(d,p)+i),{x:q(m,0,r.width-t.width),y:q(h,0,r.height-t.height)}}function ld(e,t,n){let r=Y(n.padding);return t===`center`?e.x+e.width/2:t===`right`?e.x+e.width-r.right:e.x+r.left}function ud(e){return Qu([],$u(e))}function dd(e,t,n){return ua(e,{tooltip:t,tooltipItems:n,type:`tooltip`})}function fd(e,t){let n=t&&t.dataset&&t.dataset.tooltip&&t.dataset.tooltip.callbacks;return n?e.override(n):e}var pd={beforeTitle:ur,title(e){if(e.length>0){let t=e[0],n=t.chart.data.labels,r=n?n.length:0;if(this&&this.options&&this.options.mode===`dataset`)return t.dataset.label||``;if(t.label)return t.label;if(r>0&&t.dataIndex<r)return n[t.dataIndex]}return``},afterTitle:ur,beforeBody:ur,beforeLabel:ur,label(e){if(this&&this.options&&this.options.mode===`dataset`)return e.label+`: `+e.formattedValue||e.formattedValue;let t=e.dataset.label||``;t&&(t+=`: `);let n=e.formattedValue;return I(n)||(t+=n),t},labelColor(e){let t=e.chart.getDatasetMeta(e.datasetIndex).controller.getStyle(e.dataIndex);return{borderColor:t.borderColor,backgroundColor:t.backgroundColor,borderWidth:t.borderWidth,borderDash:t.borderDash,borderDashOffset:t.borderDashOffset,borderRadius:0}},labelTextColor(){return this.options.bodyColor},labelPointStyle(e){let t=e.chart.getDatasetMeta(e.datasetIndex).controller.getStyle(e.dataIndex);return{pointStyle:t.pointStyle,rotation:t.rotation}},afterLabel:ur,afterBody:ur,beforeFooter:ur,footer:ur,afterFooter:ur};function Z(e,t,n,r){let i=e[t].call(n,r);return i===void 0?pd[t].call(n,r):i}var md=class extends xc{constructor(e){super(),this.opacity=0,this._active=[],this._eventPosition=void 0,this._size=void 0,this._cachedAnimations=void 0,this._tooltipItems=[],this.$animations=void 0,this.$context=void 0,this.chart=e.chart,this.options=e.options,this.dataPoints=void 0,this.title=void 0,this.beforeBody=void 0,this.body=void 0,this.afterBody=void 0,this.footer=void 0,this.xAlign=void 0,this.yAlign=void 0,this.x=void 0,this.y=void 0,this.height=void 0,this.width=void 0,this.caretX=void 0,this.caretY=void 0,this.labelColors=void 0,this.labelPointStyles=void 0,this.labelTextColors=void 0}initialize(e){this.options=e,this._cachedAnimations=void 0,this.$context=void 0}_resolveAnimations(){let e=this._cachedAnimations;if(e)return e;let t=this.chart,n=this.options.setContext(this.getContext()),r=n.enabled&&t.options.animation&&n.animations,i=new jo(this.chart,r);return r._cacheable&&(this._cachedAnimations=Object.freeze(i)),i}getContext(){return this.$context||=dd(this.chart.getContext(),this,this._tooltipItems)}getTitle(e,t){let{callbacks:n}=t,r=Z(n,`beforeTitle`,this,e),i=Z(n,`title`,this,e),a=Z(n,`afterTitle`,this,e),o=[];return o=Qu(o,$u(r)),o=Qu(o,$u(i)),o=Qu(o,$u(a)),o}getBeforeBody(e,t){return ud(Z(t.callbacks,`beforeBody`,this,e))}getBody(e,t){let{callbacks:n}=t,r=[];return H(e,e=>{let t={before:[],lines:[],after:[]},i=fd(n,e);Qu(t.before,$u(Z(i,`beforeLabel`,this,e))),Qu(t.lines,Z(i,`label`,this,e)),Qu(t.after,$u(Z(i,`afterLabel`,this,e))),r.push(t)}),r}getAfterBody(e,t){return ud(Z(t.callbacks,`afterBody`,this,e))}getFooter(e,t){let{callbacks:n}=t,r=Z(n,`beforeFooter`,this,e),i=Z(n,`footer`,this,e),a=Z(n,`afterFooter`,this,e),o=[];return o=Qu(o,$u(r)),o=Qu(o,$u(i)),o=Qu(o,$u(a)),o}_createItems(e){let t=this._active,n=this.chart.data,r=[],i=[],a=[],o=[],s,c;for(s=0,c=t.length;s<c;++s)o.push(ed(this.chart,t[s]));return e.filter&&(o=o.filter((t,r,i)=>e.filter(t,r,i,n))),e.itemSort&&(o=o.sort((t,r)=>e.itemSort(t,r,n))),H(o,t=>{let n=fd(e.callbacks,t);r.push(Z(n,`labelColor`,this,t)),i.push(Z(n,`labelPointStyle`,this,t)),a.push(Z(n,`labelTextColor`,this,t))}),this.labelColors=r,this.labelPointStyles=i,this.labelTextColors=a,this.dataPoints=o,o}update(e,t){let n=this.options.setContext(this.getContext()),r=this._active,i,a=[];if(!r.length)this.opacity!==0&&(i={opacity:0});else{let e=Zu[n.position].call(this,r,this._eventPosition);a=this._createItems(n),this.title=this.getTitle(a,n),this.beforeBody=this.getBeforeBody(a,n),this.body=this.getBody(a,n),this.afterBody=this.getAfterBody(a,n),this.footer=this.getFooter(a,n);let t=this._size=td(this,n),o=Object.assign({},e,t),s=ad(this.chart,n,o),c=cd(n,o,s,this.chart);this.xAlign=s.xAlign,this.yAlign=s.yAlign,i={opacity:1,x:c.x,y:c.y,width:t.width,height:t.height,caretX:e.x,caretY:e.y}}this._tooltipItems=a,this.$context=void 0,i&&this._resolveAnimations().update(this,i),e&&n.external&&n.external.call(this,{chart:this.chart,tooltip:this,replay:t})}drawCaret(e,t,n,r){let i=this.getCaretPosition(e,n,r);t.lineTo(i.x1,i.y1),t.lineTo(i.x2,i.y2),t.lineTo(i.x3,i.y3)}getCaretPosition(e,t,n){let{xAlign:r,yAlign:i}=this,{caretSize:a,cornerRadius:o}=n,{topLeft:s,topRight:c,bottomLeft:l,bottomRight:u}=sa(o),{x:d,y:f}=e,{width:p,height:m}=t,h,g,_,v,y,b;return i===`center`?(y=f+m/2,r===`left`?(h=d,g=h-a,v=y+a,b=y-a):(h=d+p,g=h+a,v=y-a,b=y+a),_=h):(g=r===`left`?d+Math.max(s,l)+a:r===`right`?d+p-Math.max(c,u)-a:this.caretX,i===`top`?(v=f,y=v-a,h=g-a,_=g+a):(v=f+m,y=v+a,h=g+a,_=g-a),b=v),{x1:h,x2:g,x3:_,y1:v,y2:y,y3:b}}drawTitle(e,t,n){let r=this.title,i=r.length,a,o,s;if(i){let c=co(n.rtl,this.x,this.width);for(e.x=ld(this,n.titleAlign,n),t.textAlign=c.textAlign(n.titleAlign),t.textBaseline=`middle`,a=X(n.titleFont),o=n.titleSpacing,t.fillStyle=n.titleColor,t.font=a.string,s=0;s<i;++s)t.fillText(r[s],c.x(e.x),e.y+a.lineHeight/2),e.y+=a.lineHeight+o,s+1===i&&(e.y+=n.titleMarginBottom-o)}}_drawColorBox(e,t,n,r,i){let a=this.labelColors[n],o=this.labelPointStyles[n],{boxHeight:s,boxWidth:c}=i,l=X(i.bodyFont),u=ld(this,`left`,i),d=r.x(u),f=s<l.lineHeight?(l.lineHeight-s)/2:0,p=t.y+f;if(i.usePointStyle){let t={radius:Math.min(c,s)/2,pointStyle:o.pointStyle,rotation:o.rotation,borderWidth:1},n=r.leftForLtr(d,c)+c/2,l=p+s/2;e.strokeStyle=i.multiKeyBackground,e.fillStyle=i.multiKeyBackground,Ui(e,t,n,l),e.strokeStyle=a.borderColor,e.fillStyle=a.backgroundColor,Ui(e,t,n,l)}else{e.lineWidth=R(a.borderWidth)?Math.max(...Object.values(a.borderWidth)):a.borderWidth||1,e.strokeStyle=a.borderColor,e.setLineDash(a.borderDash||[]),e.lineDashOffset=a.borderDashOffset||0;let t=r.leftForLtr(d,c),n=r.leftForLtr(r.xPlus(d,1),c-2),o=sa(a.borderRadius);Object.values(o).some(e=>e!==0)?(e.beginPath(),e.fillStyle=i.multiKeyBackground,ea(e,{x:t,y:p,w:c,h:s,radius:o}),e.fill(),e.stroke(),e.fillStyle=a.backgroundColor,e.beginPath(),ea(e,{x:n,y:p+1,w:c-2,h:s-2,radius:o}),e.fill()):(e.fillStyle=i.multiKeyBackground,e.fillRect(t,p,c,s),e.strokeRect(t,p,c,s),e.fillStyle=a.backgroundColor,e.fillRect(n,p+1,c-2,s-2))}e.fillStyle=this.labelTextColors[n]}drawBody(e,t,n){let{body:r}=this,{bodySpacing:i,bodyAlign:a,displayColors:o,boxHeight:s,boxWidth:c,boxPadding:l}=n,u=X(n.bodyFont),d=u.lineHeight,f=0,p=co(n.rtl,this.x,this.width),m=function(n){t.fillText(n,p.x(e.x+f),e.y+d/2),e.y+=d+i},h=p.textAlign(a),g,_,v,y,b,x,S;for(t.textAlign=a,t.textBaseline=`middle`,t.font=u.string,e.x=ld(this,h,n),t.fillStyle=n.bodyColor,H(this.beforeBody,m),f=o&&h!==`right`?a===`center`?c/2+l:c+2+l:0,y=0,x=r.length;y<x;++y){for(g=r[y],_=this.labelTextColors[y],t.fillStyle=_,H(g.before,m),v=g.lines,o&&v.length&&(this._drawColorBox(t,e,y,p,n),d=Math.max(u.lineHeight,s)),b=0,S=v.length;b<S;++b)m(v[b]),d=u.lineHeight;H(g.after,m)}f=0,d=u.lineHeight,H(this.afterBody,m),e.y-=i}drawFooter(e,t,n){let r=this.footer,i=r.length,a,o;if(i){let s=co(n.rtl,this.x,this.width);for(e.x=ld(this,n.footerAlign,n),e.y+=n.footerMarginTop,t.textAlign=s.textAlign(n.footerAlign),t.textBaseline=`middle`,a=X(n.footerFont),t.fillStyle=n.footerColor,t.font=a.string,o=0;o<i;++o)t.fillText(r[o],s.x(e.x),e.y+a.lineHeight/2),e.y+=a.lineHeight+n.footerSpacing}}drawBackground(e,t,n,r){let{xAlign:i,yAlign:a}=this,{x:o,y:s}=e,{width:c,height:l}=n,{topLeft:u,topRight:d,bottomLeft:f,bottomRight:p}=sa(r.cornerRadius);t.fillStyle=r.backgroundColor,t.strokeStyle=r.borderColor,t.lineWidth=r.borderWidth,t.beginPath(),t.moveTo(o+u,s),a===`top`&&this.drawCaret(e,t,n,r),t.lineTo(o+c-d,s),t.quadraticCurveTo(o+c,s,o+c,s+d),a===`center`&&i===`right`&&this.drawCaret(e,t,n,r),t.lineTo(o+c,s+l-p),t.quadraticCurveTo(o+c,s+l,o+c-p,s+l),a===`bottom`&&this.drawCaret(e,t,n,r),t.lineTo(o+f,s+l),t.quadraticCurveTo(o,s+l,o,s+l-f),a===`center`&&i===`left`&&this.drawCaret(e,t,n,r),t.lineTo(o,s+u),t.quadraticCurveTo(o,s,o+u,s),t.closePath(),t.fill(),r.borderWidth>0&&t.stroke()}_updateAnimationTarget(e){let t=this.chart,n=this.$animations,r=n&&n.x,i=n&&n.y;if(r||i){let n=Zu[e.position].call(this,this._active,this._eventPosition);if(!n)return;let a=this._size=td(this,e),o=Object.assign({},n,this._size),s=ad(t,e,o),c=cd(e,o,s,t);(r._to!==c.x||i._to!==c.y)&&(this.xAlign=s.xAlign,this.yAlign=s.yAlign,this.width=a.width,this.height=a.height,this.caretX=n.x,this.caretY=n.y,this._resolveAnimations().update(this,c))}}_willRender(){return!!this.opacity}draw(e){let t=this.options.setContext(this.getContext()),n=this.opacity;if(!n)return;this._updateAnimationTarget(t);let r={width:this.width,height:this.height},i={x:this.x,y:this.y};n=Math.abs(n)<.001?0:n;let a=Y(t.padding),o=this.title.length||this.beforeBody.length||this.body.length||this.afterBody.length||this.footer.length;t.enabled&&o&&(e.save(),e.globalAlpha=n,this.drawBackground(i,e,r,t),lo(e,t.textDirection),i.y+=a.top,this.drawTitle(i,e,t),this.drawBody(i,e,t),this.drawFooter(i,e,t),uo(e,t.textDirection),e.restore())}getActiveElements(){return this._active||[]}setActiveElements(e,t){let n=this._active,r=e.map(({datasetIndex:e,index:t})=>{let n=this.chart.getDatasetMeta(e);if(!n)throw Error(`Cannot find a dataset at index `+e);return{datasetIndex:e,element:n.data[t],index:t}}),i=!hr(n,r),a=this._positionChanged(r,t);(i||a)&&(this._active=r,this._eventPosition=t,this._ignoreReplayEvents=!0,this.update(!0))}handleEvent(e,t,n=!0){if(t&&this._ignoreReplayEvents)return!1;this._ignoreReplayEvents=!1;let r=this.options,i=this._active||[],a=this._getActiveElements(e,i,t,n),o=this._positionChanged(a,e),s=t||!hr(a,i)||o;return s&&(this._active=a,(r.enabled||r.external)&&(this._eventPosition={x:e.x,y:e.y},this.update(!0,t))),s}_getActiveElements(e,t,n,r){let i=this.options;if(e.type===`mouseout`)return[];if(!r)return t.filter(e=>this.chart.data.datasets[e.datasetIndex]&&this.chart.getDatasetMeta(e.datasetIndex).controller.getParsed(e.index)!==void 0);let a=this.chart.getElementsAtEventForMode(e,i.mode,i,n);return i.reverse&&a.reverse(),a}_positionChanged(e,t){let{caretX:n,caretY:r,options:i}=this,a=Zu[i.position].call(this,e,t);return a!==!1&&(n!==a.x||r!==a.y)}};f(md,`positioners`,Zu);var hd={id:`tooltip`,_element:md,positioners:Zu,afterInit(e,t,n){n&&(e.tooltip=new md({chart:e,options:n}))},beforeUpdate(e,t,n){e.tooltip&&e.tooltip.initialize(n)},reset(e,t,n){e.tooltip&&e.tooltip.initialize(n)},afterDraw(e){let t=e.tooltip;if(t&&t._willRender()){let n={tooltip:t};if(e.notifyPlugins(`beforeTooltipDraw`,{...n,cancelable:!0})===!1)return;t.draw(e.ctx),e.notifyPlugins(`afterTooltipDraw`,n)}},afterEvent(e,t){if(e.tooltip){let n=t.replay;e.tooltip.handleEvent(t.event,n,t.inChartArea)&&(t.changed=!0)}},defaults:{enabled:!0,external:null,position:`average`,backgroundColor:`rgba(0,0,0,0.8)`,titleColor:`#fff`,titleFont:{weight:`bold`},titleSpacing:2,titleMarginBottom:6,titleAlign:`left`,bodyColor:`#fff`,bodySpacing:2,bodyFont:{},bodyAlign:`left`,footerColor:`#fff`,footerSpacing:2,footerMarginTop:6,footerFont:{weight:`bold`},footerAlign:`left`,padding:6,caretPadding:2,caretSize:5,cornerRadius:6,boxHeight:(e,t)=>t.bodyFont.size,boxWidth:(e,t)=>t.bodyFont.size,multiKeyBackground:`#fff`,displayColors:!0,boxPadding:0,borderColor:`rgba(0,0,0,0)`,borderWidth:0,animation:{duration:400,easing:`easeOutQuart`},animations:{numbers:{type:`number`,properties:[`x`,`y`,`width`,`height`,`caretX`,`caretY`]},opacity:{easing:`linear`,duration:200}},callbacks:pd},defaultRoutes:{bodyFont:`font`,footerFont:`font`,titleFont:`font`},descriptors:{_scriptable:e=>e!==`filter`&&e!==`itemSort`&&e!==`external`,_indexable:!1,callbacks:{_scriptable:!1,_indexable:!1},animation:{_fallback:!1},animations:{_fallback:`animation`}},additionalOptionScopes:[`interaction`]},gd=(e,t,n,r)=>(typeof t==`string`?(n=e.push(t)-1,r.unshift({index:n,label:t})):isNaN(t)&&(n=null),n);function _d(e,t,n,r){let i=e.indexOf(t);return i===-1?gd(e,t,n,r):i===e.lastIndexOf(t)?i:n}var vd=(e,t)=>e===null?null:q(Math.round(e),0,t);function yd(e){let t=this.getLabels();return e>=0&&e<t.length?t[e]:e}var bd=class extends Vc{constructor(e){super(e),this._startValue=void 0,this._valueRange=0,this._addedLabels=[]}init(e){let t=this._addedLabels;if(t.length){let e=this.getLabels();for(let{index:n,label:r}of t)e[n]===r&&e.splice(n,1);this._addedLabels=[]}super.init(e)}parse(e,t){if(I(e))return null;let n=this.getLabels();return t=isFinite(t)&&n[t]===e?t:_d(n,e,B(t,e),this._addedLabels),vd(t,n.length-1)}determineDataLimits(){let{minDefined:e,maxDefined:t}=this.getUserBounds(),{min:n,max:r}=this.getMinMax(!0);this.options.bounds===`ticks`&&(e||(n=0),t||(r=this.getLabels().length-1)),this.min=n,this.max=r}buildTicks(){let e=this.min,t=this.max,n=this.options.offset,r=[],i=this.getLabels();i=e===0&&t===i.length-1?i:i.slice(e,t+1),this._valueRange=Math.max(i.length-(n?0:1),1),this._startValue=this.min-(n?.5:0);for(let n=e;n<=t;n++)r.push({value:n});return r}getLabelForValue(e){return yd.call(this,e)}configure(){super.configure(),this.isHorizontal()||(this._reversePixels=!this._reversePixels)}getPixelForValue(e){return typeof e!=`number`&&(e=this.parse(e)),e===null?NaN:this.getPixelForDecimal((e-this._startValue)/this._valueRange)}getPixelForTick(e){let t=this.ticks;return e<0||e>t.length-1?null:this.getPixelForValue(t[e].value)}getValueForPixel(e){return Math.round(this._startValue+this.getDecimalForPixel(e)*this._valueRange)}getBasePixel(){return this.bottom}};f(bd,`id`,`category`),f(bd,`defaults`,{ticks:{callback:yd}});function xd(e,t){let n=[],{bounds:r,step:i,min:a,max:o,precision:s,count:c,maxTicks:l,maxDigits:u,includeBounds:d}=e,f=i||1,p=l-1,{min:m,max:h}=t,g=!I(a),_=!I(o),v=!I(c),y=(h-m)/(u+1),b=zr((h-m)/p/f)*f,x,S,C,w;if(b<1e-14&&!g&&!_)return[{value:m},{value:h}];w=Math.ceil(h/b)-Math.floor(m/b),w>p&&(b=zr(w*b/p/f)*f),I(s)||(x=10**s,b=Math.ceil(b*x)/x),r===`ticks`?(S=Math.floor(m/b)*b,C=Math.ceil(h/b)*b):(S=m,C=h),g&&_&&i&&Ur((o-a)/i,b/1e3)?(w=Math.round(Math.min((o-a)/b,l)),b=(o-a)/w,S=a,C=o):v?(S=g?a:S,C=_?o:C,w=c-1,b=(C-S)/w):(w=(C-S)/b,w=Rr(w,Math.round(w),b/1e3)?Math.round(w):Math.ceil(w));let T=Math.max(qr(b),qr(S));x=10**(I(s)?T:s),S=Math.round(S*x)/x,C=Math.round(C*x)/x;let E=0;for(g&&(d&&S!==a?(n.push({value:a}),S<a&&E++,Rr(Math.round((S+E*b)*x)/x,a,Sd(a,y,e))&&E++):S<a&&E++);E<w;++E){let e=Math.round((S+E*b)*x)/x;if(_&&e>o)break;n.push({value:e})}return _&&d&&C!==o?n.length&&Rr(n[n.length-1].value,o,Sd(o,y,e))?n[n.length-1].value=o:n.push({value:o}):(!_||C===o)&&n.push({value:C}),n}function Sd(e,t,{horizontal:n,minRotation:r}){let i=Gr(r),a=(n?Math.sin(i):Math.cos(i))||.001,o=.75*t*(``+e).length;return Math.min(t/a,o)}var Cd=class extends Vc{constructor(e){super(e),this.start=void 0,this.end=void 0,this._startValue=void 0,this._endValue=void 0,this._valueRange=0}parse(e,t){return I(e)||(typeof e==`number`||e instanceof Number)&&!isFinite(+e)?null:+e}handleTickRangeOptions(){let{beginAtZero:e}=this.options,{minDefined:t,maxDefined:n}=this.getUserBounds(),{min:r,max:i}=this,a=e=>r=t?r:e,o=e=>i=n?i:e;if(e){let e=Lr(r),t=Lr(i);e<0&&t<0?o(0):e>0&&t>0&&a(0)}if(r===i){let t=i===0?1:Math.abs(i*.05);o(i+t),e||a(r-t)}this.min=r,this.max=i}getTickLimit(){let{maxTicksLimit:e,stepSize:t}=this.options.ticks,n;return t?(n=Math.ceil(this.max/t)-Math.floor(this.min/t)+1,n>1e3&&(console.warn(`scales.${this.id}.ticks.stepSize: ${t} would result generating up to ${n} ticks. Limiting to 1000.`),n=1e3)):(n=this.computeTickLimit(),e||=11),e&&(n=Math.min(e,n)),n}computeTickLimit(){return 1/0}buildTicks(){let e=this.options,t=e.ticks,n=this.getTickLimit();n=Math.max(2,n);let r=xd({maxTicks:n,bounds:e.bounds,min:e.min,max:e.max,precision:t.precision,step:t.stepSize,count:t.count,maxDigits:this._maxDigits(),horizontal:this.isHorizontal(),minRotation:t.minRotation||0,includeBounds:t.includeBounds!==!1},this._range||this);return e.bounds===`ticks`&&Wr(r,this,`value`),e.reverse?(r.reverse(),this.start=this.max,this.end=this.min):(this.start=this.min,this.end=this.max),r}configure(){let e=this.ticks,t=this.min,n=this.max;if(super.configure(),this.options.offset&&e.length){let r=(n-t)/Math.max(e.length-1,1)/2;t-=r,n+=r}this._startValue=t,this._endValue=n,this._valueRange=n-t}getLabelForValue(e){return ki(e,this.chart.options.locale,this.options.ticks.format)}},wd=class extends Cd{determineDataLimits(){let{min:e,max:t}=this.getMinMax(!0);this.min=z(e)?e:0,this.max=z(t)?t:1,this.handleTickRangeOptions()}computeTickLimit(){let e=this.isHorizontal(),t=e?this.width:this.height,n=Gr(this.options.ticks.minRotation),r=(e?Math.sin(n):Math.cos(n))||.001,i=this._resolveTickFontOptions(0);return Math.ceil(t/Math.min(40,i.lineHeight/r))}getPixelForValue(e){return e===null?NaN:this.getPixelForDecimal((e-this._startValue)/this._valueRange)}getValueForPixel(e){return this._startValue+this.getDecimalForPixel(e)*this._valueRange}};f(wd,`id`,`linear`),f(wd,`defaults`,{ticks:{callback:Mi.formatters.numeric}});var Td=e=>Math.floor(Ir(e)),Ed=(e,t)=>10**(Td(e)+t);function Dd(e){return e/10**Td(e)==1}function Od(e,t,n){let r=10**n,i=Math.floor(e/r);return Math.ceil(t/r)-i}function kd(e,t){let n=Td(t-e);for(;Od(e,t,n)>10;)n++;for(;Od(e,t,n)<10;)n--;return Math.min(n,Td(e))}function Ad(e,{min:t,max:n}){t=fr(e.min,t);let r=[],i=Td(t),a=kd(t,n),o=a<0?10**Math.abs(a):1,s=10**a,c=i>a?10**i:0,l=Math.round((t-c)*o)/o,u=Math.floor((t-c)/s/10)*s*10,d=Math.floor((l-u)/10**a),f=fr(e.min,Math.round((c+u+d*10**a)*o)/o);for(;f<n;)r.push({value:f,major:Dd(f),significand:d}),d>=10?d=d<15?15:20:d++,d>=20&&(a++,d=2,o=a>=0?1:o),f=Math.round((c+u+d*10**a)*o)/o;let p=fr(e.max,f);return r.push({value:p,major:Dd(p),significand:d}),r}var jd=class extends Vc{constructor(e){super(e),this.start=void 0,this.end=void 0,this._startValue=void 0,this._valueRange=0}parse(e,t){let n=Cd.prototype.parse.apply(this,[e,t]);if(n===0){this._zero=!0;return}return z(n)&&n>0?n:null}determineDataLimits(){let{min:e,max:t}=this.getMinMax(!0);this.min=z(e)?Math.max(0,e):null,this.max=z(t)?Math.max(0,t):null,this.options.beginAtZero&&(this._zero=!0),this._zero&&this.min!==this._suggestedMin&&!z(this._userMin)&&(this.min=e===Ed(this.min,0)?Ed(this.min,-1):Ed(this.min,0)),this.handleTickRangeOptions()}handleTickRangeOptions(){let{minDefined:e,maxDefined:t}=this.getUserBounds(),n=this.min,r=this.max,i=t=>n=e?n:t,a=e=>r=t?r:e;n===r&&(n<=0?(i(1),a(10)):(i(Ed(n,-1)),a(Ed(r,1)))),n<=0&&i(Ed(r,-1)),r<=0&&a(Ed(n,1)),this.min=n,this.max=r}buildTicks(){let e=this.options,t=Ad({min:this._userMin,max:this._userMax},this);return e.bounds===`ticks`&&Wr(t,this,`value`),e.reverse?(t.reverse(),this.start=this.max,this.end=this.min):(this.start=this.min,this.end=this.max),t}getLabelForValue(e){return e===void 0?`0`:ki(e,this.chart.options.locale,this.options.ticks.format)}configure(){let e=this.min;super.configure(),this._startValue=Ir(e),this._valueRange=Ir(this.max)-Ir(e)}getPixelForValue(e){return(e===void 0||e===0)&&(e=this.min),e===null||isNaN(e)?NaN:this.getPixelForDecimal(e===this.min?0:(Ir(e)-this._startValue)/this._valueRange)}getValueForPixel(e){let t=this.getDecimalForPixel(e);return 10**(this._startValue+t*this._valueRange)}};f(jd,`id`,`logarithmic`),f(jd,`defaults`,{ticks:{callback:Mi.formatters.logarithmic,major:{enabled:!0}}});function Md(e){let t=e.ticks;if(t.display&&e.display){let e=Y(t.backdropPadding);return B(t.font&&t.font.size,J.font.size)+e.height}return 0}function Nd(e,t,n){return n=L(n)?n:[n],{w:Bi(e,t.string,n),h:n.length*t.lineHeight}}function Pd(e,t,n,r,i){return e===r||e===i?{start:t-n/2,end:t+n/2}:e<r||e>i?{start:t-n,end:t}:{start:t,end:t+n}}function Fd(e){let t={l:e.left+e._padding.left,r:e.right-e._padding.right,t:e.top+e._padding.top,b:e.bottom-e._padding.bottom},n=Object.assign({},t),r=[],i=[],a=e._pointLabels.length,o=e.options.pointLabels,s=o.centerPointLabels?U/a:0;for(let c=0;c<a;c++){let a=o.setContext(e.getPointLabelContext(c));i[c]=a.padding;let l=e.getPointPosition(c,e.drawingArea+i[c],s),u=X(a.font),d=Nd(e.ctx,u,e._pointLabels[c]);r[c]=d;let f=K(e.getIndexAngle(c)+s),p=Math.round(Kr(f));Id(n,t,f,Pd(p,l.x,d.w,0,180),Pd(p,l.y,d.h,90,270))}e.setCenterPoint(t.l-n.l,n.r-t.r,t.t-n.t,n.b-t.b),e._pointLabelItems=zd(e,r,i)}function Id(e,t,n,r,i){let a=Math.abs(Math.sin(n)),o=Math.abs(Math.cos(n)),s=0,c=0;r.start<t.l?(s=(t.l-r.start)/a,e.l=Math.min(e.l,t.l-s)):r.end>t.r&&(s=(r.end-t.r)/a,e.r=Math.max(e.r,t.r+s)),i.start<t.t?(c=(t.t-i.start)/o,e.t=Math.min(e.t,t.t-c)):i.end>t.b&&(c=(i.end-t.b)/o,e.b=Math.max(e.b,t.b+c))}function Ld(e,t,n){let r=e.drawingArea,{extra:i,additionalAngle:a,padding:o,size:s}=n,c=e.getPointPosition(t,r+i+o,a),l=Math.round(Kr(K(c.angle+G))),u=Hd(c.y,s.h,l),d=Bd(l),f=Vd(c.x,s.w,d);return{visible:!0,x:c.x,y:u,textAlign:d,left:f,top:u,right:f+s.w,bottom:u+s.h}}function Rd(e,t){if(!t)return!0;let{left:n,top:r,right:i,bottom:a}=e;return!(Gi({x:n,y:r},t)||Gi({x:n,y:a},t)||Gi({x:i,y:r},t)||Gi({x:i,y:a},t))}function zd(e,t,n){let r=[],i=e._pointLabels.length,a=e.options,{centerPointLabels:o,display:s}=a.pointLabels,c={extra:Md(a)/2,additionalAngle:o?U/i:0},l;for(let a=0;a<i;a++){c.padding=n[a],c.size=t[a];let i=Ld(e,a,c);r.push(i),s===`auto`&&(i.visible=Rd(i,l),i.visible&&(l=i))}return r}function Bd(e){return e===0||e===180?`center`:e<180?`left`:`right`}function Vd(e,t,n){return n===`right`?e-=t:n===`center`&&(e-=t/2),e}function Hd(e,t,n){return n===90||n===270?e-=t/2:(n>270||n<90)&&(e-=t),e}function Ud(e,t,n){let{left:r,top:i,right:a,bottom:o}=n,{backdropColor:s}=t;if(!I(s)){let n=sa(t.borderRadius),c=Y(t.backdropPadding);e.fillStyle=s;let l=r-c.left,u=i-c.top,d=a-r+c.width,f=o-i+c.height;Object.values(n).some(e=>e!==0)?(e.beginPath(),ea(e,{x:l,y:u,w:d,h:f,radius:n}),e.fill()):e.fillRect(l,u,d,f)}}function Wd(e,t){let{ctx:n,options:{pointLabels:r}}=e;for(let i=t-1;i>=0;i--){let t=e._pointLabelItems[i];if(!t.visible)continue;let a=r.setContext(e.getPointLabelContext(i));Ud(n,a,t);let o=X(a.font),{x:s,y:c,textAlign:l}=t;$i(n,e._pointLabels[i],s,c+o.lineHeight/2,o,{color:a.color,textAlign:l,textBaseline:`middle`})}}function Gd(e,t,n,r){let{ctx:i}=e;if(n)i.arc(e.xCenter,e.yCenter,t,0,W);else{let n=e.getPointPosition(0,t);i.moveTo(n.x,n.y);for(let a=1;a<r;a++)n=e.getPointPosition(a,t),i.lineTo(n.x,n.y)}}function Kd(e,t,n,r,i){let a=e.ctx,o=t.circular,{color:s,lineWidth:c}=t;!o&&!r||!s||!c||n<0||(a.save(),a.strokeStyle=s,a.lineWidth=c,a.setLineDash(i.dash||[]),a.lineDashOffset=i.dashOffset,a.beginPath(),Gd(e,n,o,r),a.closePath(),a.stroke(),a.restore())}function qd(e,t,n){return ua(e,{label:n,index:t,type:`pointLabel`})}var Jd=class extends Cd{constructor(e){super(e),this.xCenter=void 0,this.yCenter=void 0,this.drawingArea=void 0,this._pointLabels=[],this._pointLabelItems=[]}setDimensions(){let e=this._padding=Y(Md(this.options)/2),t=this.width=this.maxWidth-e.width,n=this.height=this.maxHeight-e.height;this.xCenter=Math.floor(this.left+t/2+e.left),this.yCenter=Math.floor(this.top+n/2+e.top),this.drawingArea=Math.floor(Math.min(t,n)/2)}determineDataLimits(){let{min:e,max:t}=this.getMinMax(!1);this.min=z(e)&&!isNaN(e)?e:0,this.max=z(t)&&!isNaN(t)?t:0,this.handleTickRangeOptions()}computeTickLimit(){return Math.ceil(this.drawingArea/Md(this.options))}generateTickLabels(e){Cd.prototype.generateTickLabels.call(this,e),this._pointLabels=this.getLabels().map((e,t)=>{let n=V(this.options.pointLabels.callback,[e,t],this);return n||n===0?n:``}).filter((e,t)=>this.chart.getDataVisibility(t))}fit(){let e=this.options;e.display&&e.pointLabels.display?Fd(this):this.setCenterPoint(0,0,0,0)}setCenterPoint(e,t,n,r){this.xCenter+=Math.floor((e-t)/2),this.yCenter+=Math.floor((n-r)/2),this.drawingArea-=Math.min(this.drawingArea/2,Math.max(e,t,n,r))}getIndexAngle(e){let t=W/(this._pointLabels.length||1),n=this.options.startAngle||0;return K(e*t+Gr(n))}getDistanceFromCenterForValue(e){if(I(e))return NaN;let t=this.drawingArea/(this.max-this.min);return this.options.reverse?(this.max-e)*t:(e-this.min)*t}getValueForDistanceFromCenter(e){if(I(e))return NaN;let t=e/(this.drawingArea/(this.max-this.min));return this.options.reverse?this.max-t:this.min+t}getPointLabelContext(e){let t=this._pointLabels||[];if(e>=0&&e<t.length){let n=t[e];return qd(this.getContext(),e,n)}}getPointPosition(e,t,n=0){let r=this.getIndexAngle(e)-G+n;return{x:Math.cos(r)*t+this.xCenter,y:Math.sin(r)*t+this.yCenter,angle:r}}getPointPositionForValue(e,t){return this.getPointPosition(e,this.getDistanceFromCenterForValue(t))}getBasePosition(e){return this.getPointPositionForValue(e||0,this.getBaseValue())}getPointLabelPosition(e){let{left:t,top:n,right:r,bottom:i}=this._pointLabelItems[e];return{left:t,top:n,right:r,bottom:i}}drawBackground(){let{backgroundColor:e,grid:{circular:t}}=this.options;if(e){let n=this.ctx;n.save(),n.beginPath(),Gd(this,this.getDistanceFromCenterForValue(this._endValue),t,this._pointLabels.length),n.closePath(),n.fillStyle=e,n.fill(),n.restore()}}drawGrid(){let e=this.ctx,t=this.options,{angleLines:n,grid:r,border:i}=t,a=this._pointLabels.length,o,s,c;if(t.pointLabels.display&&Wd(this,a),r.display&&this.ticks.forEach((e,t)=>{if(t!==0||t===0&&this.min<0){s=this.getDistanceFromCenterForValue(e.value);let n=this.getContext(t),o=r.setContext(n),c=i.setContext(n);Kd(this,o,s,a,c)}}),n.display){for(e.save(),o=a-1;o>=0;o--){let r=n.setContext(this.getPointLabelContext(o)),{color:i,lineWidth:a}=r;!a||!i||(e.lineWidth=a,e.strokeStyle=i,e.setLineDash(r.borderDash),e.lineDashOffset=r.borderDashOffset,s=this.getDistanceFromCenterForValue(t.reverse?this.min:this.max),c=this.getPointPosition(o,s),e.beginPath(),e.moveTo(this.xCenter,this.yCenter),e.lineTo(c.x,c.y),e.stroke())}e.restore()}}drawBorder(){}drawLabels(){let e=this.ctx,t=this.options,n=t.ticks;if(!n.display)return;let r=this.getIndexAngle(0),i,a;e.save(),e.translate(this.xCenter,this.yCenter),e.rotate(r),e.textAlign=`center`,e.textBaseline=`middle`,this.ticks.forEach((r,o)=>{if(o===0&&this.min>=0&&!t.reverse)return;let s=n.setContext(this.getContext(o)),c=X(s.font);if(i=this.getDistanceFromCenterForValue(this.ticks[o].value),s.showLabelBackdrop){e.font=c.string,a=e.measureText(r.label).width,e.fillStyle=s.backdropColor;let t=Y(s.backdropPadding);e.fillRect(-a/2-t.left,-i-c.size/2-t.top,a+t.width,c.size+t.height)}$i(e,r.label,0,-i,c,{color:s.color,strokeColor:s.textStrokeColor,strokeWidth:s.textStrokeWidth})}),e.restore()}drawTitle(){}};f(Jd,`id`,`radialLinear`),f(Jd,`defaults`,{display:!0,animate:!0,position:`chartArea`,angleLines:{display:!0,lineWidth:1,borderDash:[],borderDashOffset:0},grid:{circular:!1},startAngle:0,ticks:{showLabelBackdrop:!0,callback:Mi.formatters.numeric},pointLabels:{backdropColor:void 0,backdropPadding:2,display:!0,font:{size:10},callback(e){return e},padding:5,centerPointLabels:!1}}),f(Jd,`defaultRoutes`,{"angleLines.color":`borderColor`,"pointLabels.color":`color`,"ticks.color":`color`}),f(Jd,`descriptors`,{angleLines:{_fallback:`grid`}});var Yd={millisecond:{common:!0,size:1,steps:1e3},second:{common:!0,size:1e3,steps:60},minute:{common:!0,size:6e4,steps:60},hour:{common:!0,size:36e5,steps:24},day:{common:!0,size:864e5,steps:30},week:{common:!1,size:6048e5,steps:4},month:{common:!0,size:2628e6,steps:12},quarter:{common:!1,size:7884e6,steps:4},year:{common:!0,size:3154e7}},Q=Object.keys(Yd);function Xd(e,t){return e-t}function Zd(e,t){if(I(t))return null;let n=e._adapter,{parser:r,round:i,isoWeekday:a}=e._parseOpts,o=t;return typeof r==`function`&&(o=r(o)),z(o)||(o=typeof r==`string`?n.parse(o,r):n.parse(o)),o===null?null:(i&&(o=i===`week`&&(Hr(a)||a===!0)?n.startOf(o,`isoWeek`,a):n.startOf(o,i)),+o)}function Qd(e,t,n,r){let i=Q.length;for(let a=Q.indexOf(e);a<i-1;++a){let e=Yd[Q[a]],i=e.steps?e.steps:2**53-1;if(e.common&&Math.ceil((n-t)/(i*e.size))<=r)return Q[a]}return Q[i-1]}function $d(e,t,n,r,i){for(let a=Q.length-1;a>=Q.indexOf(n);a--){let n=Q[a];if(Yd[n].common&&e._adapter.diff(i,r,n)>=t-1)return n}return Q[n?Q.indexOf(n):0]}function ef(e){for(let t=Q.indexOf(e)+1,n=Q.length;t<n;++t)if(Yd[Q[t]].common)return Q[t]}function tf(e,t,n){if(!n)e[t]=!0;else if(n.length){let{lo:r,hi:i}=ei(n,t),a=n[r]>=t?n[r]:n[i];e[a]=!0}}function nf(e,t,n,r){let i=e._adapter,a=+i.startOf(t[0].value,r),o=t[t.length-1].value,s,c;for(s=a;s<=o;s=+i.add(s,1,r))c=n[s],c>=0&&(t[c].major=!0);return t}function rf(e,t,n){let r=[],i={},a=t.length,o,s;for(o=0;o<a;++o)s=t[o],i[s]=o,r.push({value:s,major:!1});return a===0||!n?r:nf(e,r,i,n)}var af=class extends Vc{constructor(e){super(e),this._cache={data:[],labels:[],all:[]},this._unit=`day`,this._majorUnit=void 0,this._offsets={},this._normalized=!1,this._parseOpts=void 0}init(e,t={}){let n=e.time||={},r=this._adapter=new Ts._date(e.adapters.date);r.init(t),br(n.displayFormats,r.formats()),this._parseOpts={parser:n.parser,round:n.round,isoWeekday:n.isoWeekday},super.init(e),this._normalized=t.normalized}parse(e,t){return e===void 0?null:Zd(this,e)}beforeLayout(){super.beforeLayout(),this._cache={data:[],labels:[],all:[]}}determineDataLimits(){let e=this.options,t=this._adapter,n=e.time.unit||`day`,{min:r,max:i,minDefined:a,maxDefined:o}=this.getUserBounds();function s(e){!a&&!isNaN(e.min)&&(r=Math.min(r,e.min)),!o&&!isNaN(e.max)&&(i=Math.max(i,e.max))}(!a||!o)&&(s(this._getLabelBounds()),(e.bounds!==`ticks`||e.ticks.source!==`labels`)&&s(this.getMinMax(!1))),r=z(r)&&!isNaN(r)?r:+t.startOf(Date.now(),n),i=z(i)&&!isNaN(i)?i:+t.endOf(Date.now(),n)+1,this.min=Math.min(r,i-1),this.max=Math.max(r+1,i)}_getLabelBounds(){let e=this.getLabelTimestamps(),t=1/0,n=-1/0;return e.length&&(t=e[0],n=e[e.length-1]),{min:t,max:n}}buildTicks(){let e=this.options,t=e.time,n=e.ticks,r=n.source===`labels`?this.getLabelTimestamps():this._generate();e.bounds===`ticks`&&r.length&&(this.min=this._userMin||r[0],this.max=this._userMax||r[r.length-1]);let i=this.min,a=this.max,o=ri(r,i,a);return this._unit=t.unit||(n.autoSkip?Qd(t.minUnit,this.min,this.max,this._getLabelCapacity(i)):$d(this,o.length,t.minUnit,this.min,this.max)),this._majorUnit=!n.major.enabled||this._unit===`year`?void 0:ef(this._unit),this.initOffsets(r),e.reverse&&o.reverse(),rf(this,o,this._majorUnit)}afterAutoSkip(){this.options.offsetAfterAutoskip&&this.initOffsets(this.ticks.map(e=>+e.value))}initOffsets(e=[]){let t=0,n=0,r,i;this.options.offset&&e.length&&(r=this.getDecimalForValue(e[0]),t=e.length===1?1-r:(this.getDecimalForValue(e[1])-r)/2,i=this.getDecimalForValue(e[e.length-1]),n=e.length===1?i:(i-this.getDecimalForValue(e[e.length-2]))/2);let a=e.length<3?.5:.25;t=q(t,0,a),n=q(n,0,a),this._offsets={start:t,end:n,factor:1/(t+1+n)}}_generate(){let e=this._adapter,t=this.min,n=this.max,r=this.options,i=r.time,a=i.unit||Qd(i.minUnit,t,n,this._getLabelCapacity(t)),o=B(r.ticks.stepSize,1),s=a===`week`?i.isoWeekday:!1,c=Hr(s)||s===!0,l={},u=t,d,f;if(c&&(u=+e.startOf(u,`isoWeek`,s)),u=+e.startOf(u,c?`day`:a),e.diff(n,t,a)>1e5*o)throw Error(t+` and `+n+` are too far apart with stepSize of `+o+` `+a);let p=r.ticks.source===`data`&&this.getDataTimestamps();for(d=u,f=0;d<n;d=+e.add(d,o,a),f++)tf(l,d,p);return(d===n||r.bounds===`ticks`||f===1)&&tf(l,d,p),Object.keys(l).sort(Xd).map(e=>+e)}getLabelForValue(e){let t=this._adapter,n=this.options.time;return n.tooltipFormat?t.format(e,n.tooltipFormat):t.format(e,n.displayFormats.datetime)}format(e,t){let n=this.options.time.displayFormats,r=this._unit,i=t||n[r];return this._adapter.format(e,i)}_tickFormatFunction(e,t,n,r){let i=this.options,a=i.ticks.callback;if(a)return V(a,[e,t,n],this);let o=i.time.displayFormats,s=this._unit,c=this._majorUnit,l=s&&o[s],u=c&&o[c],d=n[t],f=c&&u&&d&&d.major;return this._adapter.format(e,r||(f?u:l))}generateTickLabels(e){let t,n,r;for(t=0,n=e.length;t<n;++t)r=e[t],r.label=this._tickFormatFunction(r.value,t,e)}getDecimalForValue(e){return e===null?NaN:(e-this.min)/(this.max-this.min)}getPixelForValue(e){let t=this._offsets,n=this.getDecimalForValue(e);return this.getPixelForDecimal((t.start+n)*t.factor)}getValueForPixel(e){let t=this._offsets,n=this.getDecimalForPixel(e)/t.factor-t.end;return this.min+n*(this.max-this.min)}_getLabelSize(e){let t=this.options.ticks,n=this.ctx.measureText(e).width,r=Gr(this.isHorizontal()?t.maxRotation:t.minRotation),i=Math.cos(r),a=Math.sin(r),o=this._resolveTickFontOptions(0).size;return{w:n*i+o*a,h:n*a+o*i}}_getLabelCapacity(e){let t=this.options.time,n=t.displayFormats,r=n[t.unit]||n.millisecond,i=this._tickFormatFunction(e,0,rf(this,[e],this._majorUnit),r),a=this._getLabelSize(i),o=Math.floor(this.isHorizontal()?this.width/a.w:this.height/a.h)-1;return o>0?o:1}getDataTimestamps(){let e=this._cache.data||[],t,n;if(e.length)return e;let r=this.getMatchingVisibleMetas();if(this._normalized&&r.length)return this._cache.data=r[0].controller.getAllParsedValues(this);for(t=0,n=r.length;t<n;++t)e=e.concat(r[t].controller.getAllParsedValues(this));return this._cache.data=this.normalize(e)}getLabelTimestamps(){let e=this._cache.labels||[],t,n;if(e.length)return e;let r=this.getLabels();for(t=0,n=r.length;t<n;++t)e.push(Zd(this,r[t]));return this._cache.labels=this._normalized?e:this.normalize(e)}normalize(e){return si(e.sort(Xd))}};f(af,`id`,`time`),f(af,`defaults`,{bounds:`data`,adapters:{},time:{parser:!1,unit:!1,round:!1,isoWeekday:!1,minUnit:`millisecond`,displayFormats:{}},ticks:{source:`auto`,callback:!1,major:{enabled:!1}}});function of(e,t,n){let r=0,i=e.length-1,a,o,s,c;n?(t>=e[r].pos&&t<=e[i].pos&&({lo:r,hi:i}=ti(e,`pos`,t)),{pos:a,time:s}=e[r],{pos:o,time:c}=e[i]):(t>=e[r].time&&t<=e[i].time&&({lo:r,hi:i}=ti(e,`time`,t)),{time:a,pos:s}=e[r],{time:o,pos:c}=e[i]);let l=o-a;return l?s+(c-s)*(t-a)/l:s}var sf=class extends af{constructor(e){super(e),this._table=[],this._minPos=void 0,this._tableRange=void 0}initOffsets(){let e=this._getTimestampsForTable(),t=this._table=this.buildLookupTable(e);this._minPos=of(t,this.min),this._tableRange=of(t,this.max)-this._minPos,super.initOffsets(e)}buildLookupTable(e){let{min:t,max:n}=this,r=[],i=[],a,o,s,c,l;for(a=0,o=e.length;a<o;++a)c=e[a],c>=t&&c<=n&&r.push(c);if(r.length<2)return[{time:t,pos:0},{time:n,pos:1}];for(a=0,o=r.length;a<o;++a)l=r[a+1],s=r[a-1],c=r[a],Math.round((l+s)/2)!==c&&i.push({time:c,pos:a/(o-1)});return i}_generate(){let e=this.min,t=this.max,n=super.getDataTimestamps();return(!n.includes(e)||!n.length)&&n.splice(0,0,e),(!n.includes(t)||n.length===1)&&n.push(t),n.sort((e,t)=>e-t)}_getTimestampsForTable(){let e=this._cache.all||[];if(e.length)return e;let t=this.getDataTimestamps(),n=this.getLabelTimestamps();return e=t.length&&n.length?this.normalize(t.concat(n)):t.length?t:n,e=this._cache.all=e,e}getDecimalForValue(e){return(of(this._table,e)-this._minPos)/this._tableRange}getValueForPixel(e){let t=this._offsets,n=this.getDecimalForPixel(e)/t.factor-t.end;return of(this._table,n*this._tableRange+this._minPos,!0)}};f(sf,`id`,`timeseries`),f(sf,`defaults`,af.defaults);var cf=e(t(((e,t)=>{(function(e,n,r,i){var a=[``,`webkit`,`Moz`,`MS`,`ms`,`o`],o=n.createElement(`div`),s=`function`,c=Math.round,l=Math.abs,u=Date.now;function d(e,t,n){return setTimeout(y(e,n),t)}function f(e,t,n){return Array.isArray(e)?(p(e,n[t],n),!0):!1}function p(e,t,n){var r;if(e)if(e.forEach)e.forEach(t,n);else if(e.length!==i)for(r=0;r<e.length;)t.call(n,e[r],r,e),r++;else for(r in e)e.hasOwnProperty(r)&&t.call(n,e[r],r,e)}function m(t,n,r){var i=`DEPRECATED METHOD: `+n+`
`+r+` AT 
`;return function(){var n=Error(`get-stack-trace`),r=n&&n.stack?n.stack.replace(/^[^\(]+?[\n$]/gm,``).replace(/^\s+at\s+/gm,``).replace(/^Object.<anonymous>\s*\(/gm,`{anonymous}()@`):`Unknown Stack Trace`,a=e.console&&(e.console.warn||e.console.log);return a&&a.call(e.console,i,r),t.apply(this,arguments)}}var h=typeof Object.assign==`function`?Object.assign:function(e){if(e===i||e===null)throw TypeError(`Cannot convert undefined or null to object`);for(var t=Object(e),n=1;n<arguments.length;n++){var r=arguments[n];if(r!==i&&r!==null)for(var a in r)r.hasOwnProperty(a)&&(t[a]=r[a])}return t},g=m(function(e,t,n){for(var r=Object.keys(t),a=0;a<r.length;)(!n||n&&e[r[a]]===i)&&(e[r[a]]=t[r[a]]),a++;return e},`extend`,"Use `assign`."),_=m(function(e,t){return g(e,t,!0)},`merge`,"Use `assign`.");function v(e,t,n){var r=t.prototype,i=e.prototype=Object.create(r);i.constructor=e,i._super=r,n&&h(i,n)}function y(e,t){return function(){return e.apply(t,arguments)}}function b(e,t){return typeof e==s?e.apply(t&&t[0]||i,t):e}function x(e,t){return e===i?t:e}function S(e,t,n){p(E(t),function(t){e.addEventListener(t,n,!1)})}function C(e,t,n){p(E(t),function(t){e.removeEventListener(t,n,!1)})}function w(e,t){for(;e;){if(e==t)return!0;e=e.parentNode}return!1}function T(e,t){return e.indexOf(t)>-1}function E(e){return e.trim().split(/\s+/g)}function D(e,t,n){if(e.indexOf&&!n)return e.indexOf(t);for(var r=0;r<e.length;){if(n&&e[r][n]==t||!n&&e[r]===t)return r;r++}return-1}function ee(e){return Array.prototype.slice.call(e,0)}function te(e,t,n){for(var r=[],i=[],a=0;a<e.length;){var o=t?e[a][t]:e[a];D(i,o)<0&&r.push(e[a]),i[a]=o,a++}return n&&(r=t?r.sort(function(e,n){return e[t]>n[t]}):r.sort()),r}function ne(e,t){for(var n,r,o=t[0].toUpperCase()+t.slice(1),s=0;s<a.length;){if(n=a[s],r=n?n+o:t,r in e)return r;s++}return i}var re=1;function ie(){return re++}function ae(t){var n=t.ownerDocument||t;return n.defaultView||n.parentWindow||e}var oe=/mobile|tablet|ip(ad|hone|od)|android/i,se=`ontouchstart`in e,ce=ne(e,`PointerEvent`)!==i,le=se&&oe.test(navigator.userAgent),ue=`touch`,de=`pen`,O=`mouse`,fe=`kinect`,pe=25,k=1,me=2,A=4,j=8,he=1,ge=2,_e=4,ve=8,ye=16,be=ge|_e,xe=ve|ye,Se=be|xe,Ce=[`x`,`y`],we=[`clientX`,`clientY`];function M(e,t){var n=this;this.manager=e,this.callback=t,this.element=e.element,this.target=e.options.inputTarget,this.domHandler=function(t){b(e.options.enable,[e])&&n.handler(t)},this.init()}M.prototype={handler:function(){},init:function(){this.evEl&&S(this.element,this.evEl,this.domHandler),this.evTarget&&S(this.target,this.evTarget,this.domHandler),this.evWin&&S(ae(this.element),this.evWin,this.domHandler)},destroy:function(){this.evEl&&C(this.element,this.evEl,this.domHandler),this.evTarget&&C(this.target,this.evTarget,this.domHandler),this.evWin&&C(ae(this.element),this.evWin,this.domHandler)}};function Te(e){var t;return t=e.options.inputClass||(ce?Ge:le?$e:se?rt:Be),new t(e,Ee)}function Ee(e,t,n){var r=n.pointers.length,i=n.changedPointers.length,a=t&k&&r-i===0,o=t&(A|j)&&r-i===0;n.isFirst=!!a,n.isFinal=!!o,a&&(e.session={}),n.eventType=t,De(e,n),e.emit(`hammer.input`,n),e.recognize(n),e.session.prevInput=n}function De(e,t){var n=e.session,r=t.pointers,i=r.length;n.firstInput||=Ae(t),i>1&&!n.firstMultiple?n.firstMultiple=Ae(t):i===1&&(n.firstMultiple=!1);var a=n.firstInput,o=n.firstMultiple,s=o?o.center:a.center,c=t.center=je(r);t.timeStamp=u(),t.deltaTime=t.timeStamp-a.timeStamp,t.angle=Pe(s,c),t.distance=Ne(s,c),Oe(n,t),t.offsetDirection=N(t.deltaX,t.deltaY);var d=Me(t.deltaTime,t.deltaX,t.deltaY);t.overallVelocityX=d.x,t.overallVelocityY=d.y,t.overallVelocity=l(d.x)>l(d.y)?d.x:d.y,t.scale=o?Ie(o.pointers,r):1,t.rotation=o?Fe(o.pointers,r):0,t.maxPointers=n.prevInput?t.pointers.length>n.prevInput.maxPointers?t.pointers.length:n.prevInput.maxPointers:t.pointers.length,ke(n,t);var f=e.element;w(t.srcEvent.target,f)&&(f=t.srcEvent.target),t.target=f}function Oe(e,t){var n=t.center,r=e.offsetDelta||{},i=e.prevDelta||{},a=e.prevInput||{};(t.eventType===k||a.eventType===A)&&(i=e.prevDelta={x:a.deltaX||0,y:a.deltaY||0},r=e.offsetDelta={x:n.x,y:n.y}),t.deltaX=i.x+(n.x-r.x),t.deltaY=i.y+(n.y-r.y)}function ke(e,t){var n=e.lastInterval||t,r=t.timeStamp-n.timeStamp,a,o,s,c;if(t.eventType!=j&&(r>pe||n.velocity===i)){var u=t.deltaX-n.deltaX,d=t.deltaY-n.deltaY,f=Me(r,u,d);o=f.x,s=f.y,a=l(f.x)>l(f.y)?f.x:f.y,c=N(u,d),e.lastInterval=t}else a=n.velocity,o=n.velocityX,s=n.velocityY,c=n.direction;t.velocity=a,t.velocityX=o,t.velocityY=s,t.direction=c}function Ae(e){for(var t=[],n=0;n<e.pointers.length;)t[n]={clientX:c(e.pointers[n].clientX),clientY:c(e.pointers[n].clientY)},n++;return{timeStamp:u(),pointers:t,center:je(t),deltaX:e.deltaX,deltaY:e.deltaY}}function je(e){var t=e.length;if(t===1)return{x:c(e[0].clientX),y:c(e[0].clientY)};for(var n=0,r=0,i=0;i<t;)n+=e[i].clientX,r+=e[i].clientY,i++;return{x:c(n/t),y:c(r/t)}}function Me(e,t,n){return{x:t/e||0,y:n/e||0}}function N(e,t){return e===t?he:l(e)>=l(t)?e<0?ge:_e:t<0?ve:ye}function Ne(e,t,n){n||=Ce;var r=t[n[0]]-e[n[0]],i=t[n[1]]-e[n[1]];return Math.sqrt(r*r+i*i)}function Pe(e,t,n){n||=Ce;var r=t[n[0]]-e[n[0]],i=t[n[1]]-e[n[1]];return Math.atan2(i,r)*180/Math.PI}function Fe(e,t){return Pe(t[1],t[0],we)+Pe(e[1],e[0],we)}function Ie(e,t){return Ne(t[0],t[1],we)/Ne(e[0],e[1],we)}var Le={mousedown:k,mousemove:me,mouseup:A},Re=`mousedown`,ze=`mousemove mouseup`;function Be(){this.evEl=Re,this.evWin=ze,this.pressed=!1,M.apply(this,arguments)}v(Be,M,{handler:function(e){var t=Le[e.type];t&k&&e.button===0&&(this.pressed=!0),t&me&&e.which!==1&&(t=A),this.pressed&&(t&A&&(this.pressed=!1),this.callback(this.manager,t,{pointers:[e],changedPointers:[e],pointerType:O,srcEvent:e}))}});var Ve={pointerdown:k,pointermove:me,pointerup:A,pointercancel:j,pointerout:j},He={2:ue,3:de,4:O,5:fe},Ue=`pointerdown`,We=`pointermove pointerup pointercancel`;e.MSPointerEvent&&!e.PointerEvent&&(Ue=`MSPointerDown`,We=`MSPointerMove MSPointerUp MSPointerCancel`);function Ge(){this.evEl=Ue,this.evWin=We,M.apply(this,arguments),this.store=this.manager.session.pointerEvents=[]}v(Ge,M,{handler:function(e){var t=this.store,n=!1,r=Ve[e.type.toLowerCase().replace(`ms`,``)],i=He[e.pointerType]||e.pointerType,a=i==ue,o=D(t,e.pointerId,`pointerId`);r&k&&(e.button===0||a)?o<0&&(t.push(e),o=t.length-1):r&(A|j)&&(n=!0),!(o<0)&&(t[o]=e,this.callback(this.manager,r,{pointers:t,changedPointers:[e],pointerType:i,srcEvent:e}),n&&t.splice(o,1))}});var Ke={touchstart:k,touchmove:me,touchend:A,touchcancel:j},qe=`touchstart`,Je=`touchstart touchmove touchend touchcancel`;function Ye(){this.evTarget=qe,this.evWin=Je,this.started=!1,M.apply(this,arguments)}v(Ye,M,{handler:function(e){var t=Ke[e.type];if(t===k&&(this.started=!0),this.started){var n=Xe.call(this,e,t);t&(A|j)&&n[0].length-n[1].length===0&&(this.started=!1),this.callback(this.manager,t,{pointers:n[0],changedPointers:n[1],pointerType:ue,srcEvent:e})}}});function Xe(e,t){var n=ee(e.touches),r=ee(e.changedTouches);return t&(A|j)&&(n=te(n.concat(r),`identifier`,!0)),[n,r]}var Ze={touchstart:k,touchmove:me,touchend:A,touchcancel:j},Qe=`touchstart touchmove touchend touchcancel`;function $e(){this.evTarget=Qe,this.targetIds={},M.apply(this,arguments)}v($e,M,{handler:function(e){var t=Ze[e.type],n=et.call(this,e,t);n&&this.callback(this.manager,t,{pointers:n[0],changedPointers:n[1],pointerType:ue,srcEvent:e})}});function et(e,t){var n=ee(e.touches),r=this.targetIds;if(t&(k|me)&&n.length===1)return r[n[0].identifier]=!0,[n,n];var i,a,o=ee(e.changedTouches),s=[],c=this.target;if(a=n.filter(function(e){return w(e.target,c)}),t===k)for(i=0;i<a.length;)r[a[i].identifier]=!0,i++;for(i=0;i<o.length;)r[o[i].identifier]&&s.push(o[i]),t&(A|j)&&delete r[o[i].identifier],i++;if(s.length)return[te(a.concat(s),`identifier`,!0),s]}var tt=2500,nt=25;function rt(){M.apply(this,arguments);var e=y(this.handler,this);this.touch=new $e(this.manager,e),this.mouse=new Be(this.manager,e),this.primaryTouch=null,this.lastTouches=[]}v(rt,M,{handler:function(e,t,n){var r=n.pointerType==ue,i=n.pointerType==O;if(!(i&&n.sourceCapabilities&&n.sourceCapabilities.firesTouchEvents)){if(r)it.call(this,t,n);else if(i&&ot.call(this,n))return;this.callback(e,t,n)}},destroy:function(){this.touch.destroy(),this.mouse.destroy()}});function it(e,t){e&k?(this.primaryTouch=t.changedPointers[0].identifier,at.call(this,t)):e&(A|j)&&at.call(this,t)}function at(e){var t=e.changedPointers[0];if(t.identifier===this.primaryTouch){var n={x:t.clientX,y:t.clientY};this.lastTouches.push(n);var r=this.lastTouches;setTimeout(function(){var e=r.indexOf(n);e>-1&&r.splice(e,1)},tt)}}function ot(e){for(var t=e.srcEvent.clientX,n=e.srcEvent.clientY,r=0;r<this.lastTouches.length;r++){var i=this.lastTouches[r],a=Math.abs(t-i.x),o=Math.abs(n-i.y);if(a<=nt&&o<=nt)return!0}return!1}var st=ne(o.style,`touchAction`),ct=st!==i,lt=`compute`,ut=`auto`,dt=`manipulation`,ft=`none`,pt=`pan-x`,mt=`pan-y`,ht=vt();function gt(e,t){this.manager=e,this.set(t)}gt.prototype={set:function(e){e==lt&&(e=this.compute()),ct&&this.manager.element.style&&ht[e]&&(this.manager.element.style[st]=e),this.actions=e.toLowerCase().trim()},update:function(){this.set(this.manager.options.touchAction)},compute:function(){var e=[];return p(this.manager.recognizers,function(t){b(t.options.enable,[t])&&(e=e.concat(t.getTouchAction()))}),_t(e.join(` `))},preventDefaults:function(e){var t=e.srcEvent,n=e.offsetDirection;if(this.manager.session.prevented){t.preventDefault();return}var r=this.actions,i=T(r,ft)&&!ht[ft],a=T(r,mt)&&!ht[mt],o=T(r,pt)&&!ht[pt];if(i){var s=e.pointers.length===1,c=e.distance<2,l=e.deltaTime<250;if(s&&c&&l)return}if(!(o&&a)&&(i||a&&n&be||o&&n&xe))return this.preventSrc(t)},preventSrc:function(e){this.manager.session.prevented=!0,e.preventDefault()}};function _t(e){if(T(e,ft))return ft;var t=T(e,pt),n=T(e,mt);return t&&n?ft:t||n?t?pt:mt:T(e,dt)?dt:ut}function vt(){if(!ct)return!1;var t={},n=e.CSS&&e.CSS.supports;return[`auto`,`manipulation`,`pan-y`,`pan-x`,`pan-x pan-y`,`none`].forEach(function(r){t[r]=n?e.CSS.supports(`touch-action`,r):!0}),t}var yt=1,P=2,bt=4,xt=8,St=xt,Ct=16,F=32;function wt(e){this.options=h({},this.defaults,e||{}),this.id=ie(),this.manager=null,this.options.enable=x(this.options.enable,!0),this.state=yt,this.simultaneous={},this.requireFail=[]}wt.prototype={defaults:{},set:function(e){return h(this.options,e),this.manager&&this.manager.touchAction.update(),this},recognizeWith:function(e){if(f(e,`recognizeWith`,this))return this;var t=this.simultaneous;return e=Dt(e,this),t[e.id]||(t[e.id]=e,e.recognizeWith(this)),this},dropRecognizeWith:function(e){return f(e,`dropRecognizeWith`,this)?this:(e=Dt(e,this),delete this.simultaneous[e.id],this)},requireFailure:function(e){if(f(e,`requireFailure`,this))return this;var t=this.requireFail;return e=Dt(e,this),D(t,e)===-1&&(t.push(e),e.requireFailure(this)),this},dropRequireFailure:function(e){if(f(e,`dropRequireFailure`,this))return this;e=Dt(e,this);var t=D(this.requireFail,e);return t>-1&&this.requireFail.splice(t,1),this},hasRequireFailures:function(){return this.requireFail.length>0},canRecognizeWith:function(e){return!!this.simultaneous[e.id]},emit:function(e){var t=this,n=this.state;function r(n){t.manager.emit(n,e)}n<xt&&r(t.options.event+Tt(n)),r(t.options.event),e.additionalEvent&&r(e.additionalEvent),n>=xt&&r(t.options.event+Tt(n))},tryEmit:function(e){if(this.canEmit())return this.emit(e);this.state=F},canEmit:function(){for(var e=0;e<this.requireFail.length;){if(!(this.requireFail[e].state&(F|yt)))return!1;e++}return!0},recognize:function(e){var t=h({},e);if(!b(this.options.enable,[this,t])){this.reset(),this.state=F;return}this.state&(St|Ct|F)&&(this.state=yt),this.state=this.process(t),this.state&(P|bt|xt|Ct)&&this.tryEmit(t)},process:function(e){},getTouchAction:function(){},reset:function(){}};function Tt(e){return e&Ct?`cancel`:e&xt?`end`:e&bt?`move`:e&P?`start`:``}function Et(e){return e==ye?`down`:e==ve?`up`:e==ge?`left`:e==_e?`right`:``}function Dt(e,t){var n=t.manager;return n?n.get(e):e}function Ot(){wt.apply(this,arguments)}v(Ot,wt,{defaults:{pointers:1},attrTest:function(e){var t=this.options.pointers;return t===0||e.pointers.length===t},process:function(e){var t=this.state,n=e.eventType,r=t&(P|bt),i=this.attrTest(e);return r&&(n&j||!i)?t|Ct:r||i?n&A?t|xt:t&P?t|bt:P:F}});function kt(){Ot.apply(this,arguments),this.pX=null,this.pY=null}v(kt,Ot,{defaults:{event:`pan`,threshold:10,pointers:1,direction:Se},getTouchAction:function(){var e=this.options.direction,t=[];return e&be&&t.push(mt),e&xe&&t.push(pt),t},directionTest:function(e){var t=this.options,n=!0,r=e.distance,i=e.direction,a=e.deltaX,o=e.deltaY;return i&t.direction||(t.direction&be?(i=a===0?he:a<0?ge:_e,n=a!=this.pX,r=Math.abs(e.deltaX)):(i=o===0?he:o<0?ve:ye,n=o!=this.pY,r=Math.abs(e.deltaY))),e.direction=i,n&&r>t.threshold&&i&t.direction},attrTest:function(e){return Ot.prototype.attrTest.call(this,e)&&(this.state&P||!(this.state&P)&&this.directionTest(e))},emit:function(e){this.pX=e.deltaX,this.pY=e.deltaY;var t=Et(e.direction);t&&(e.additionalEvent=this.options.event+t),this._super.emit.call(this,e)}});function At(){Ot.apply(this,arguments)}v(At,Ot,{defaults:{event:`pinch`,threshold:0,pointers:2},getTouchAction:function(){return[ft]},attrTest:function(e){return this._super.attrTest.call(this,e)&&(Math.abs(e.scale-1)>this.options.threshold||this.state&P)},emit:function(e){if(e.scale!==1){var t=e.scale<1?`in`:`out`;e.additionalEvent=this.options.event+t}this._super.emit.call(this,e)}});function jt(){wt.apply(this,arguments),this._timer=null,this._input=null}v(jt,wt,{defaults:{event:`press`,pointers:1,time:251,threshold:9},getTouchAction:function(){return[ut]},process:function(e){var t=this.options,n=e.pointers.length===t.pointers,r=e.distance<t.threshold,i=e.deltaTime>t.time;if(this._input=e,!r||!n||e.eventType&(A|j)&&!i)this.reset();else if(e.eventType&k)this.reset(),this._timer=d(function(){this.state=St,this.tryEmit()},t.time,this);else if(e.eventType&A)return St;return F},reset:function(){clearTimeout(this._timer)},emit:function(e){this.state===St&&(e&&e.eventType&A?this.manager.emit(this.options.event+`up`,e):(this._input.timeStamp=u(),this.manager.emit(this.options.event,this._input)))}});function Mt(){Ot.apply(this,arguments)}v(Mt,Ot,{defaults:{event:`rotate`,threshold:0,pointers:2},getTouchAction:function(){return[ft]},attrTest:function(e){return this._super.attrTest.call(this,e)&&(Math.abs(e.rotation)>this.options.threshold||this.state&P)}});function Nt(){Ot.apply(this,arguments)}v(Nt,Ot,{defaults:{event:`swipe`,threshold:10,velocity:.3,direction:be|xe,pointers:1},getTouchAction:function(){return kt.prototype.getTouchAction.call(this)},attrTest:function(e){var t=this.options.direction,n;return t&(be|xe)?n=e.overallVelocity:t&be?n=e.overallVelocityX:t&xe&&(n=e.overallVelocityY),this._super.attrTest.call(this,e)&&t&e.offsetDirection&&e.distance>this.options.threshold&&e.maxPointers==this.options.pointers&&l(n)>this.options.velocity&&e.eventType&A},emit:function(e){var t=Et(e.offsetDirection);t&&this.manager.emit(this.options.event+t,e),this.manager.emit(this.options.event,e)}});function Pt(){wt.apply(this,arguments),this.pTime=!1,this.pCenter=!1,this._timer=null,this._input=null,this.count=0}v(Pt,wt,{defaults:{event:`tap`,pointers:1,taps:1,interval:300,time:250,threshold:9,posThreshold:10},getTouchAction:function(){return[dt]},process:function(e){var t=this.options,n=e.pointers.length===t.pointers,r=e.distance<t.threshold,i=e.deltaTime<t.time;if(this.reset(),e.eventType&k&&this.count===0)return this.failTimeout();if(r&&i&&n){if(e.eventType!=A)return this.failTimeout();var a=this.pTime?e.timeStamp-this.pTime<t.interval:!0,o=!this.pCenter||Ne(this.pCenter,e.center)<t.posThreshold;if(this.pTime=e.timeStamp,this.pCenter=e.center,!o||!a?this.count=1:this.count+=1,this._input=e,this.count%t.taps===0)return this.hasRequireFailures()?(this._timer=d(function(){this.state=St,this.tryEmit()},t.interval,this),P):St}return F},failTimeout:function(){return this._timer=d(function(){this.state=F},this.options.interval,this),F},reset:function(){clearTimeout(this._timer)},emit:function(){this.state==St&&(this._input.tapCount=this.count,this.manager.emit(this.options.event,this._input))}});function Ft(e,t){return t||={},t.recognizers=x(t.recognizers,Ft.defaults.preset),new Rt(e,t)}Ft.VERSION=`2.0.7`,Ft.defaults={domEvents:!1,touchAction:lt,enable:!0,inputTarget:null,inputClass:null,preset:[[Mt,{enable:!1}],[At,{enable:!1},[`rotate`]],[Nt,{direction:be}],[kt,{direction:be},[`swipe`]],[Pt],[Pt,{event:`doubletap`,taps:2},[`tap`]],[jt]],cssProps:{userSelect:`none`,touchSelect:`none`,touchCallout:`none`,contentZooming:`none`,userDrag:`none`,tapHighlightColor:`rgba(0,0,0,0)`}};var It=1,Lt=2;function Rt(e,t){this.options=h({},Ft.defaults,t||{}),this.options.inputTarget=this.options.inputTarget||e,this.handlers={},this.session={},this.recognizers=[],this.oldCssProps={},this.element=e,this.input=Te(this),this.touchAction=new gt(this,this.options.touchAction),zt(this,!0),p(this.options.recognizers,function(e){var t=this.add(new e[0](e[1]));e[2]&&t.recognizeWith(e[2]),e[3]&&t.requireFailure(e[3])},this)}Rt.prototype={set:function(e){return h(this.options,e),e.touchAction&&this.touchAction.update(),e.inputTarget&&(this.input.destroy(),this.input.target=e.inputTarget,this.input.init()),this},stop:function(e){this.session.stopped=e?Lt:It},recognize:function(e){var t=this.session;if(!t.stopped){this.touchAction.preventDefaults(e);var n,r=this.recognizers,i=t.curRecognizer;(!i||i&&i.state&St)&&(i=t.curRecognizer=null);for(var a=0;a<r.length;)n=r[a],t.stopped!==Lt&&(!i||n==i||n.canRecognizeWith(i))?n.recognize(e):n.reset(),!i&&n.state&(P|bt|xt)&&(i=t.curRecognizer=n),a++}},get:function(e){if(e instanceof wt)return e;for(var t=this.recognizers,n=0;n<t.length;n++)if(t[n].options.event==e)return t[n];return null},add:function(e){if(f(e,`add`,this))return this;var t=this.get(e.options.event);return t&&this.remove(t),this.recognizers.push(e),e.manager=this,this.touchAction.update(),e},remove:function(e){if(f(e,`remove`,this))return this;if(e=this.get(e),e){var t=this.recognizers,n=D(t,e);n!==-1&&(t.splice(n,1),this.touchAction.update())}return this},on:function(e,t){if(e!==i&&t!==i){var n=this.handlers;return p(E(e),function(e){n[e]=n[e]||[],n[e].push(t)}),this}},off:function(e,t){if(e!==i){var n=this.handlers;return p(E(e),function(e){t?n[e]&&n[e].splice(D(n[e],t),1):delete n[e]}),this}},emit:function(e,t){this.options.domEvents&&Bt(e,t);var n=this.handlers[e]&&this.handlers[e].slice();if(!(!n||!n.length)){t.type=e,t.preventDefault=function(){t.srcEvent.preventDefault()};for(var r=0;r<n.length;)n[r](t),r++}},destroy:function(){this.element&&zt(this,!1),this.handlers={},this.session={},this.input.destroy(),this.element=null}};function zt(e,t){var n=e.element;if(n.style){var r;p(e.options.cssProps,function(i,a){r=ne(n.style,a),t?(e.oldCssProps[r]=n.style[r],n.style[r]=i):n.style[r]=e.oldCssProps[r]||``}),t||(e.oldCssProps={})}}function Bt(e,t){var r=n.createEvent(`Event`);r.initEvent(e,!0,!0),r.gesture=t,t.target.dispatchEvent(r)}h(Ft,{INPUT_START:k,INPUT_MOVE:me,INPUT_END:A,INPUT_CANCEL:j,STATE_POSSIBLE:yt,STATE_BEGAN:P,STATE_CHANGED:bt,STATE_ENDED:xt,STATE_RECOGNIZED:St,STATE_CANCELLED:Ct,STATE_FAILED:F,DIRECTION_NONE:he,DIRECTION_LEFT:ge,DIRECTION_RIGHT:_e,DIRECTION_UP:ve,DIRECTION_DOWN:ye,DIRECTION_HORIZONTAL:be,DIRECTION_VERTICAL:xe,DIRECTION_ALL:Se,Manager:Rt,Input:M,TouchAction:gt,TouchInput:$e,MouseInput:Be,PointerEventInput:Ge,TouchMouseInput:rt,SingleTouchInput:Ye,Recognizer:wt,AttrRecognizer:Ot,Tap:Pt,Pan:kt,Swipe:Nt,Pinch:At,Rotate:Mt,Press:jt,on:S,off:C,each:p,merge:_,extend:g,assign:h,inherit:v,bindFn:y,prefixed:ne});var Vt=e===void 0?typeof self<`u`?self:{}:e;Vt.Hammer=Ft,typeof define==`function`&&define.amd?define(function(){return Ft}):t!==void 0&&t.exports?t.exports=Ft:e[r]=Ft})(window,document,`Hammer`)}))()),lf=e=>e&&e.enabled&&e.modifierKey,uf=(e,t)=>e&&t[e+`Key`],df=(e,t)=>e&&!t[e+`Key`];function ff(e,t,n){return e===void 0?!0:typeof e==`string`?e.indexOf(t)!==-1:typeof e==`function`?e({chart:n}).indexOf(t)!==-1:!1}function pf(e,t){return typeof e==`function`&&(e=e({chart:t})),typeof e==`string`?{x:e.indexOf(`x`)!==-1,y:e.indexOf(`y`)!==-1}:{x:!1,y:!1}}function mf(e,t){let n;return function(){return clearTimeout(n),n=setTimeout(e,t),t}}function hf({x:e,y:t},n){let r=n.scales,i=Object.keys(r);for(let n=0;n<i.length;n++){let a=r[i[n]];if(t>=a.top&&t<=a.bottom&&e>=a.left&&e<=a.right)return a}return null}function gf(e,t,n){let{mode:r=`xy`,scaleMode:i,overScaleMode:a}=e||{},o=hf(t,n),s=pf(r,n),c=pf(i,n);if(a){let e=pf(a,n);for(let t of[`x`,`y`])e[t]&&(c[t]=s[t],s[t]=!1)}if(o&&c[o.axis])return[o];let l=[];return H(n.scales,function(e){s[e.axis]&&l.push(e)}),l}var _f=new WeakMap;function $(e){let t=_f.get(e);return t||(t={originalScaleLimits:{},updatedScaleLimits:{},handlers:{},panDelta:{},dragging:!1,panning:!1},_f.set(e,t)),t}function vf(e){_f.delete(e)}function yf(e,t,n,r){let i=Math.max(0,Math.min(1,(e-t)/n||0)),a=1-i;return{min:r*i,max:r*a}}function bf(e,t){let n=e.isHorizontal()?t.x:t.y;return e.getValueForPixel(n)}function xf(e,t,n){let r=e.max-e.min,i=r*(t-1);return yf(bf(e,n),e.min,r,i)}function Sf(e,t,n){let r=bf(e,n);if(r===void 0)return{min:e.min,max:e.max};let i=Math.log10(e.min),a=Math.log10(e.max),o=Math.log10(r),s=a-i,c=yf(o,i,s,s*(t-1));return{min:10**(i+c.min),max:10**(a-c.max)}}function Cf(e,t){return t&&(t[e.id]||t[e.axis])||{}}function wf(e,t,n,r,i){let a=n[r];if(a===`original`){let n=e.originalScaleLimits[t.id][r];a=B(n.options,n.scale)}return B(a,i)}function Tf(e,t,n){let r=e.getValueForPixel(t),i=e.getValueForPixel(n);return{min:Math.min(r,i),max:Math.max(r,i)}}function Ef(e,{min:t,max:n,minLimit:r,maxLimit:i},a){let o=(e-n+t)/2;t-=o,n+=o;let s=a.min.options??a.min.scale,c=a.max.options??a.max.scale,l=e/1e6;return Rr(t,s,l)&&(t=s),Rr(n,c,l)&&(n=c),t<r?(t=r,n=Math.min(r+e,i)):n>i&&(n=i,t=Math.max(i-e,r)),{min:t,max:n}}function Df(e,{min:t,max:n},r,i=!1){let a=$(e.chart),{options:o}=e,s=Cf(e,r),{minRange:c=0}=s,l=wf(a,e,s,`min`,-1/0),u=wf(a,e,s,`max`,1/0);if(i===`pan`&&(t<l||n>u))return!0;let d=e.max-e.min,f=i?Math.max(n-t,c):d;if(i&&f===c&&d<=c)return!0;let p=Ef(f,{min:t,max:n,minLimit:l,maxLimit:u},a.originalScaleLimits[e.id]);return o.min=p.min,o.max=p.max,a.updatedScaleLimits[e.id]=p,e.parse(p.min)!==e.min||e.parse(p.max)!==e.max}function Of(e,t,n,r){let i=xf(e,t,n);return Df(e,{min:e.min+i.min,max:e.max-i.max},r,!0)}function kf(e,t,n,r){return Df(e,Sf(e,t,n),r,!0)}function Af(e,t,n,r){Df(e,Tf(e,t,n),r,!0)}var jf=e=>e===0||isNaN(e)?0:e<0?Math.min(Math.round(e),-1):Math.max(Math.round(e),1);function Mf(e){let t=e.getLabels().length-1;e.min>0&&--e.min,e.max<t&&(e.max+=1)}function Nf(e,t,n,r){let i=xf(e,t,n);return e.min===e.max&&t<1&&Mf(e),Df(e,{min:e.min+jf(i.min),max:e.max-jf(i.max)},r,!0)}function Pf(e){return e.isHorizontal()?e.width:e.height}function Ff(e,t,n){let r=e.getLabels().length-1,{min:i,max:a}=e,o=Math.max(a-i,1),s=Math.round(Pf(e)/Math.max(o,10)),c=Math.round(Math.abs(t/s)),l;return t<-s?(a=Math.min(a+c,r),i=o===1?a:a-o,l=a===r):t>s&&(i=Math.max(0,i-c),a=o===1?i:i+o,l=i===0),Df(e,{min:i,max:a},n)||l}var If={second:500,minute:30*1e3,hour:1800*1e3,day:720*60*1e3,week:3.5*24*60*60*1e3,month:360*60*60*1e3,quarter:1440*60*60*1e3,year:4368*60*60*1e3};function Lf(e,t,n,r=!1){let{min:i,max:a,options:o}=e,s=If[o.time&&o.time.round]||0,c=e.getValueForPixel(e.getPixelForValue(i+s)-t),l=e.getValueForPixel(e.getPixelForValue(a+s)-t);return isNaN(c)||isNaN(l)?!0:Df(e,{min:c,max:l},n,r?`pan`:!1)}function Rf(e,t,n){return Lf(e,t,n,!0)}var zf={category:Nf,default:Of,logarithmic:kf},Bf={default:Af},Vf={category:Ff,default:Lf,logarithmic:Rf,timeseries:Rf};function Hf(e,t,n){let{id:r,options:{min:i,max:a}}=e;if(!t[r]||!n[r])return!0;let o=n[r];return o.min!==i||o.max!==a}function Uf(e,t){H(e,(n,r)=>{t[r]||delete e[r]})}function Wf(e,t){let{scales:n}=e,{originalScaleLimits:r,updatedScaleLimits:i}=t;return H(n,function(e){Hf(e,r,i)&&(r[e.id]={min:{scale:e.min,options:e.options.min},max:{scale:e.max,options:e.options.max}})}),Uf(r,n),Uf(i,n),r}function Gf(e,t,n,r){V(zf[e.type]||zf.default,[e,t,n,r])}function Kf(e,t,n,r){V(Bf[e.type]||Bf.default,[e,t,n,r])}function qf(e){let t=e.chartArea;return{x:(t.left+t.right)/2,y:(t.top+t.bottom)/2}}function Jf(e,t,n=`none`,r=`api`){let{x:i=1,y:a=1,focalPoint:o=qf(e)}=typeof t==`number`?{x:t,y:t}:t,s=$(e),{options:{limits:c,zoom:l}}=s;Wf(e,s);let u=i!==1,d=a!==1;H(gf(l,o,e)||e.scales,function(e){e.isHorizontal()&&u?Gf(e,i,o,c):!e.isHorizontal()&&d&&Gf(e,a,o,c)}),e.update(n),V(l.onZoom,[{chart:e,trigger:r}])}function Yf(e,t,n,r=`none`,i=`api`){let a=$(e),{options:{limits:o,zoom:s}}=a,{mode:c=`xy`}=s;Wf(e,a);let l=ff(c,`x`,e),u=ff(c,`y`,e);H(e.scales,function(e){e.isHorizontal()&&l?Kf(e,t.x,n.x,o):!e.isHorizontal()&&u&&Kf(e,t.y,n.y,o)}),e.update(r),V(s.onZoom,[{chart:e,trigger:i}])}function Xf(e,t,n,r=`none`,i=`api`){let a=$(e);Wf(e,a);let o=e.scales[t];Df(o,n,void 0,!0),e.update(r),V(a.options.zoom?.onZoom,[{chart:e,trigger:i}])}function Zf(e,t=`default`){let n=$(e),r=Wf(e,n);H(e.scales,function(e){let t=e.options;r[e.id]?(t.min=r[e.id].min.options,t.max=r[e.id].max.options):(delete t.min,delete t.max),delete n.updatedScaleLimits[e.id]}),e.update(t),V(n.options.zoom.onZoomComplete,[{chart:e}])}function Qf(e,t){let n=e.originalScaleLimits[t];if(!n)return;let{min:r,max:i}=n;return B(i.options,i.scale)-B(r.options,r.scale)}function $f(e){let t=$(e),n=1,r=1;return H(e.scales,function(e){let i=Qf(t,e.id);if(i){let t=Math.round(i/(e.max-e.min)*100)/100;n=Math.min(n,t),r=Math.max(r,t)}}),n<1?n:r}function ep(e,t,n,r){let{panDelta:i}=r,a=i[e.id]||0;Lr(a)===Lr(t)&&(t+=a),V(Vf[e.type]||Vf.default,[e,t,n])?i[e.id]=0:i[e.id]=t}function tp(e,t,n,r=`none`){let{x:i=0,y:a=0}=typeof t==`number`?{x:t,y:t}:t,o=$(e),{options:{pan:s,limits:c}}=o,{onPan:l}=s||{};Wf(e,o);let u=i!==0,d=a!==0;H(n||e.scales,function(e){e.isHorizontal()&&u?ep(e,i,c,o):!e.isHorizontal()&&d&&ep(e,a,c,o)}),e.update(r),V(l,[{chart:e}])}function np(e){let t=$(e);Wf(e,t);let n={};for(let r of Object.keys(e.scales)){let{min:e,max:i}=t.originalScaleLimits[r]||{min:{},max:{}};n[r]={min:e.scale,max:i.scale}}return n}function rp(e){let t=$(e),n={};for(let r of Object.keys(e.scales))n[r]=t.updatedScaleLimits[r];return n}function ip(e){let t=np(e);for(let n of Object.keys(e.scales)){let{min:r,max:i}=t[n];if(r!==void 0&&e.scales[n].min!==r||i!==void 0&&e.scales[n].max!==i)return!0}return!1}function ap(e){let t=$(e);return t.panning||t.dragging}var op=(e,t,n)=>Math.min(n,Math.max(t,e));function sp(e,t){let{handlers:n}=$(e),r=n[t];r&&r.target&&(r.target.removeEventListener(t,r),delete n[t])}function cp(e,t,n,r){let{handlers:i,options:a}=$(e),o=i[n];if(o&&o.target===t)return;sp(e,n),i[n]=t=>r(e,t,a),i[n].target=t;let s=n===`wheel`?!1:void 0;t.addEventListener(n,i[n],{passive:s})}function lp(e,t){let n=$(e);n.dragStart&&(n.dragging=!0,n.dragEnd=t,e.update(`none`))}function up(e,t){let n=$(e);!n.dragStart||t.key!==`Escape`||(sp(e,`keydown`),n.dragging=!1,n.dragStart=n.dragEnd=null,e.update(`none`))}function dp(e,t){if(e.target!==t.canvas){let n=t.canvas.getBoundingClientRect();return{x:e.clientX-n.left,y:e.clientY-n.top}}return Xa(e,t)}function fp(e,t,n){let{onZoomStart:r,onZoomRejected:i}=n;if(r&&V(r,[{chart:e,event:t,point:dp(t,e)}])===!1)return V(i,[{chart:e,event:t}]),!1}function pp(e,t){if(e.legend&&Gi(Xa(t,e),e.legend))return;let n=$(e),{pan:r,zoom:i={}}=n.options;if(t.button!==0||uf(lf(r),t)||df(lf(i.drag),t))return V(i.onZoomRejected,[{chart:e,event:t}]);fp(e,t,i)!==!1&&(n.dragStart=t,cp(e,e.canvas.ownerDocument,`mousemove`,lp),cp(e,window.document,`keydown`,up))}function mp({begin:e,end:t},n){let r=t.x-e.x,i=t.y-e.y,a=Math.abs(r/i);a>n?r=Math.sign(r)*Math.abs(i*n):a<n&&(i=Math.sign(i)*Math.abs(r/n)),t.x=e.x+r,t.y=e.y+i}function hp(e,t,n,{min:r,max:i,prop:a}){e[r]=op(Math.min(n.begin[a],n.end[a]),t[r],t[i]),e[i]=op(Math.max(n.begin[a],n.end[a]),t[r],t[i])}function gp(e,t,n){let r={begin:dp(t.dragStart,e),end:dp(t.dragEnd,e)};return n&&mp(r,e.chartArea.width/e.chartArea.height),r}function _p(e,t,n,r){let i=ff(t,`x`,e),a=ff(t,`y`,e),{top:o,left:s,right:c,bottom:l,width:u,height:d}=e.chartArea,f={top:o,left:s,right:c,bottom:l},p=gp(e,n,r&&i&&a);i&&hp(f,e.chartArea,p,{min:`left`,max:`right`,prop:`x`}),a&&hp(f,e.chartArea,p,{min:`top`,max:`bottom`,prop:`y`});let m=f.right-f.left,h=f.bottom-f.top;return{...f,width:m,height:h,zoomX:i&&m?1+(u-m)/u:1,zoomY:a&&h?1+(d-h)/d:1}}function vp(e,t){let n=$(e);if(!n.dragStart)return;sp(e,`mousemove`);let{mode:r,onZoomComplete:i,drag:{threshold:a=0,maintainAspectRatio:o}}=n.options.zoom,s=_p(e,r,{dragStart:n.dragStart,dragEnd:t},o),c=ff(r,`x`,e)?s.width:0,l=ff(r,`y`,e)?s.height:0,u=Math.sqrt(c*c+l*l);if(n.dragStart=n.dragEnd=null,u<=a){n.dragging=!1,e.update(`none`);return}Yf(e,{x:s.left,y:s.top},{x:s.right,y:s.bottom},`zoom`,`drag`),n.dragging=!1,n.filterNextClick=!0,V(i,[{chart:e}])}function yp(e,t,n){if(df(lf(n.wheel),t)){V(n.onZoomRejected,[{chart:e,event:t}]);return}if(fp(e,t,n)!==!1&&(t.cancelable&&t.preventDefault(),t.deltaY!==void 0))return!0}function bp(e,t){let{handlers:{onZoomComplete:n},options:{zoom:r}}=$(e);if(!yp(e,t,r))return;let i=t.target.getBoundingClientRect(),a=r.wheel.speed,o=t.deltaY>=0?2-1/(1-a):1+a;Jf(e,{x:o,y:o,focalPoint:{x:t.clientX-i.left,y:t.clientY-i.top}},`zoom`,`wheel`),V(n,[{chart:e}])}function xp(e,t,n,r){n&&($(e).handlers[t]=mf(()=>V(n,[{chart:e}]),r))}function Sp(e,t){let n=e.canvas,{wheel:r,drag:i,onZoomComplete:a}=t.zoom;r.enabled?(cp(e,n,`wheel`,bp),xp(e,`onZoomComplete`,a,250)):sp(e,`wheel`),i.enabled?(cp(e,n,`mousedown`,pp),cp(e,n.ownerDocument,`mouseup`,vp)):(sp(e,`mousedown`),sp(e,`mousemove`),sp(e,`mouseup`),sp(e,`keydown`))}function Cp(e){sp(e,`mousedown`),sp(e,`mousemove`),sp(e,`mouseup`),sp(e,`wheel`),sp(e,`click`),sp(e,`keydown`)}function wp(e,t){return function(n,r){let{pan:i,zoom:a={}}=t.options;if(!i||!i.enabled)return!1;let o=r&&r.srcEvent;return o&&!t.panning&&r.pointerType===`mouse`&&(df(lf(i),o)||uf(lf(a.drag),o))?(V(i.onPanRejected,[{chart:e,event:r}]),!1):!0}}function Tp(e,t){let n=Math.abs(e.clientX-t.clientX),r=Math.abs(e.clientY-t.clientY),i=n/r,a,o;return i>.3&&i<1.7?a=o=!0:n>r?a=!0:o=!0,{x:a,y:o}}function Ep(e,t,n){if(t.scale){let{center:r,pointers:i}=n,a=1/t.scale*n.scale,o=n.target.getBoundingClientRect(),s=Tp(i[0],i[1]),c=t.options.zoom.mode;Jf(e,{x:s.x&&ff(c,`x`,e)?a:1,y:s.y&&ff(c,`y`,e)?a:1,focalPoint:{x:r.x-o.left,y:r.y-o.top}},`zoom`,`pinch`),t.scale=n.scale}}function Dp(e,t,n){if(t.options.zoom.pinch.enabled){let r=Xa(n,e);V(t.options.zoom.onZoomStart,[{chart:e,event:n,point:r}])===!1?(t.scale=null,V(t.options.zoom.onZoomRejected,[{chart:e,event:n}])):t.scale=1}}function Op(e,t,n){t.scale&&(Ep(e,t,n),t.scale=null,V(t.options.zoom.onZoomComplete,[{chart:e}]))}function kp(e,t,n){let r=t.delta;r&&(t.panning=!0,tp(e,{x:n.deltaX-r.x,y:n.deltaY-r.y},t.panScales),t.delta={x:n.deltaX,y:n.deltaY})}function Ap(e,t,n){let{enabled:r,onPanStart:i,onPanRejected:a}=t.options.pan;if(!r)return;let o=n.target.getBoundingClientRect(),s={x:n.center.x-o.left,y:n.center.y-o.top};if(V(i,[{chart:e,event:n,point:s}])===!1)return V(a,[{chart:e,event:n}]);t.panScales=gf(t.options.pan,s,e),t.delta={x:0,y:0},kp(e,t,n)}function jp(e,t){t.delta=null,t.panning&&(t.panning=!1,t.filterNextClick=!0,V(t.options.pan.onPanComplete,[{chart:e}]))}var Mp=new WeakMap;function Np(e,t){let n=$(e),r=e.canvas,{pan:i,zoom:a}=t,o=new cf.default.Manager(r);a&&a.pinch.enabled&&(o.add(new cf.default.Pinch),o.on(`pinchstart`,t=>Dp(e,n,t)),o.on(`pinch`,t=>Ep(e,n,t)),o.on(`pinchend`,t=>Op(e,n,t))),i&&i.enabled&&(o.add(new cf.default.Pan({threshold:i.threshold,enable:wp(e,n)})),o.on(`panstart`,t=>Ap(e,n,t)),o.on(`panmove`,t=>kp(e,n,t)),o.on(`panend`,()=>jp(e,n))),Mp.set(e,o)}function Pp(e){let t=Mp.get(e);t&&(t.remove(`pinchstart`),t.remove(`pinch`),t.remove(`pinchend`),t.remove(`panstart`),t.remove(`pan`),t.remove(`panend`),t.destroy(),Mp.delete(e))}function Fp(e,t){let{pan:n,zoom:r}=e,{pan:i,zoom:a}=t;return r?.zoom?.pinch?.enabled!==a?.zoom?.pinch?.enabled||n?.enabled!==i?.enabled||n?.threshold!==i?.threshold}var Ip=`2.2.0`;function Lp(e,t,n){let r=n.zoom.drag,{dragStart:i,dragEnd:a}=$(e);if(r.drawTime!==t||!a)return;let{left:o,top:s,width:c,height:l}=_p(e,n.zoom.mode,{dragStart:i,dragEnd:a},r.maintainAspectRatio),u=e.ctx;u.save(),u.beginPath(),u.fillStyle=r.backgroundColor||`rgba(225,225,225,0.3)`,u.fillRect(o,s,c,l),r.borderWidth>0&&(u.lineWidth=r.borderWidth,u.strokeStyle=r.borderColor||`rgba(225,225,225)`,u.strokeRect(o,s,c,l)),u.restore()}var Rp={id:`zoom`,version:Ip,defaults:{pan:{enabled:!1,mode:`xy`,threshold:10,modifierKey:null},zoom:{wheel:{enabled:!1,speed:.1,modifierKey:null},drag:{enabled:!1,drawTime:`beforeDatasetsDraw`,modifierKey:null},pinch:{enabled:!1},mode:`xy`}},start:function(e,t,n){let r=$(e);r.options=n,Object.prototype.hasOwnProperty.call(n.zoom,`enabled`)&&console.warn("The option `zoom.enabled` is no longer supported. Please use `zoom.wheel.enabled`, `zoom.drag.enabled`, or `zoom.pinch.enabled`."),(Object.prototype.hasOwnProperty.call(n.zoom,`overScaleMode`)||Object.prototype.hasOwnProperty.call(n.pan,`overScaleMode`))&&console.warn("The option `overScaleMode` is deprecated. Please use `scaleMode` instead (and update `mode` as desired)."),cf.default&&Np(e,n),e.pan=(t,n,r)=>tp(e,t,n,r),e.zoom=(t,n)=>Jf(e,t,n),e.zoomRect=(t,n,r)=>Yf(e,t,n,r),e.zoomScale=(t,n,r)=>Xf(e,t,n,r),e.resetZoom=t=>Zf(e,t),e.getZoomLevel=()=>$f(e),e.getInitialScaleBounds=()=>np(e),e.getZoomedScaleBounds=()=>rp(e),e.isZoomedOrPanned=()=>ip(e),e.isZoomingOrPanning=()=>ap(e)},beforeEvent(e,{event:t}){if(ap(e))return!1;if(t.type===`click`||t.type===`mouseup`){let t=$(e);if(t.filterNextClick)return t.filterNextClick=!1,!1}},beforeUpdate:function(e,t,n){let r=$(e),i=r.options;r.options=n,Fp(i,n)&&(Pp(e),Np(e,n)),Sp(e,n)},beforeDatasetsDraw(e,t,n){Lp(e,`beforeDatasetsDraw`,n)},afterDatasetsDraw(e,t,n){Lp(e,`afterDatasetsDraw`,n)},beforeDraw(e,t,n){Lp(e,`beforeDraw`,n)},afterDraw(e,t,n){Lp(e,`afterDraw`,n)},stop:function(e){Cp(e),cf.default&&Pp(e),vf(e)},panFunctions:Vf,zoomFunctions:zf,zoomRectFunctions:Bf},zp;kl.register(ys,Ql,eu,wd,af,hd,Xu,Vu,Rp);var Bp=[`#3b82f6`,`#ef4444`,`#10b981`,`#f59e0b`,`#8b5cf6`,`#ec4899`,`#06b6d4`,`#84cc16`,`#f97316`,`#6366f1`],Vp=[{label:`5m`,ms:5*6e4},{label:`15m`,ms:15*6e4},{label:`1h`,ms:60*6e4},{label:`6h`,ms:360*6e4},{label:`All`,ms:null}],Hp=(zp=class extends l{constructor(...e){super(...e),this.content=``,this.hiddenSeries=new Set,this.activeZoom=`All`,this.error=!1,this.chart=null,this.buildPending=!1,this._cachedContent=``,this._cachedParsed=null,this._boundWrap=null,this.onWrapWheel=e=>{this.chart&&(e.preventDefault(),e.stopPropagation())}}disconnectedCallback(){super.disconnectedCallback(),this.destroyChart(),this.detachWrapListeners()}destroyChart(){this.chart&&=(this.chart.destroy(),null)}attachWrapListeners(){this.detachWrapListeners();let e=this.shadowRoot?.querySelector(`.chart-wrap`);e&&(this._boundWrap=e,e.addEventListener(`wheel`,this.onWrapWheel,{passive:!1}))}detachWrapListeners(){this._boundWrap&&=(this._boundWrap.removeEventListener(`wheel`,this.onWrapWheel),null)}updated(e){e.has(`content`)&&(this.hiddenSeries=new Set,this.activeZoom=`All`,this.error=!1,this._cachedContent=this.content,this._cachedParsed=Wt(this.content),this.scheduleBuild())}get parsed(){return this._cachedContent!==this.content&&(this._cachedContent=this.content,this._cachedParsed=Wt(this.content)),this._cachedParsed}scheduleBuild(){this.buildPending||(this.buildPending=!0,setTimeout(()=>{this.buildPending=!1,this.buildChart()},0))}getTimeRange(){let e=this.parsed;if(!e)return null;let t=1/0,n=-1/0;for(let r of e.series)for(let e of r.data)e.x<t&&(t=e.x),e.x>n&&(n=e.x);return isFinite(t)&&isFinite(n)?{min:t,max:n}:null}buildChart(){this.destroyChart();let e=this.parsed;if(!e||e.series.length===0){this.error=!0;return}let t=this.shadowRoot?.querySelector(`canvas`);if(!t)return;let n=t.getContext(`2d`);if(!n)return;let r=getComputedStyle(this).getPropertyValue(`--text-secondary`).trim()||`#999`,i=getComputedStyle(this).getPropertyValue(`--border-secondary`).trim()||`rgba(128,128,128,0.2)`;this.chart=new kl(n,{type:`line`,data:{datasets:e.series.map((e,t)=>({label:e.name,data:e.data,borderColor:Bp[t%Bp.length],backgroundColor:Bp[t%Bp.length]+`22`,borderWidth:1.5,pointRadius:0,pointHitRadius:6,tension:.25,fill:!1,hidden:this.hiddenSeries.has(t)}))},options:{responsive:!0,maintainAspectRatio:!1,animation:{duration:300},interaction:{mode:`index`,intersect:!1},plugins:{legend:{display:!1},tooltip:{callbacks:{title:e=>{if(!e.length)return``;let t=e[0].parsed.x;return t==null?``:new Date(t).toLocaleString()}}},zoom:{pan:{enabled:!1},zoom:{wheel:{enabled:!0},drag:{enabled:!0,backgroundColor:`rgba(59,130,246,0.12)`,borderColor:`rgba(59,130,246,0.4)`,borderWidth:1},mode:`x`,onZoomComplete:()=>{this.activeZoom=``,this.requestUpdate()}}}},scales:{x:{type:`linear`,ticks:{color:r,font:{size:10},maxTicksLimit:8,callback:e=>new Date(e).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})},grid:{color:i}},y:{ticks:{color:r,font:{size:10},maxTicksLimit:6},grid:{color:i}}}}}),this.attachWrapListeners()}toggleSeries(e){let t=new Set(this.hiddenSeries);if(t.has(e)?t.delete(e):t.add(e),this.hiddenSeries=t,this.chart){let n=this.chart.getDatasetMeta(e);n.hidden=t.has(e),this.chart.update(`none`)}}applyZoom(e){if(this.activeZoom=e.label,!this.chart)return;if(e.ms===null){this.chart.resetZoom(`default`);return}let t=this.getTimeRange();if(!t)return;let n=t.max,r=Math.max(t.min,n-e.ms);this.chart.zoomScale(`x`,{min:r,max:n},`default`)}renderLegend(e){return e.series.map((e,t)=>a`
        <button
          class="legend-item ${this.hiddenSeries.has(t)?`hidden`:``}"
          @click=${()=>this.toggleSeries(t)}
          title="${this.hiddenSeries.has(t)?`Show`:`Hide`} ${e.name}"
        >
          <span class="legend-swatch" style="background:${Bp[t%Bp.length]}"></span>
          ${e.name}
        </button>
      `)}renderZoomControls(){return a`
      <span class="zoom-hint">Zoom:</span>
      ${Vp.map(e=>a`
          <button
            class="zoom-btn ${this.activeZoom===e.label?`active`:``}"
            @click=${()=>this.applyZoom(e)}
          >
            ${e.label}
          </button>
        `)}
    `}render(){let e=this.parsed;return this.error||!e?a`<div class="fallback">Unable to parse time-series data</div>`:a`
      <div class="toolbar">
        <div class="legend-area">${this.renderLegend(e)}</div>
        <div class="zoom-controls">${this.renderZoomControls()}</div>
      </div>
      <div class="chart-wrap">
        <canvas></canvas>
      </div>
    `}},zp.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
      user-select: none;
    }

    .toolbar {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 2px 2px;
      flex-wrap: wrap;
    }

    .legend-area {
      display: flex;
      align-items: center;
      gap: 4px;
      flex-wrap: wrap;
      flex: 1;
      min-width: 0;
    }

    .legend-item {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 6px;
      border-radius: var(--radius-xs, 4px);
      cursor: pointer;
      font-size: 11px;
      font-family: var(--font-sans, sans-serif);
      color: var(--text-secondary, #999);
      background: transparent;
      border: 1px solid transparent;
      transition:
        opacity 0.15s,
        background 0.15s;
      user-select: none;
    }

    .legend-item:hover {
      background: var(--bg-hover, rgba(128, 128, 128, 0.1));
    }

    .legend-item.hidden {
      opacity: 0.4;
    }

    .legend-item.hidden .legend-swatch {
      background: var(--text-tertiary, #666) !important;
    }

    .legend-swatch {
      width: 10px;
      height: 3px;
      border-radius: 1px;
      flex-shrink: 0;
    }

    .zoom-controls {
      display: flex;
      align-items: center;
      gap: 2px;
      flex-shrink: 0;
    }

    .zoom-btn {
      padding: 2px 7px;
      border-radius: var(--radius-xs, 4px);
      cursor: pointer;
      font-size: 10px;
      font-family: var(--font-mono, monospace);
      color: var(--text-secondary, #999);
      background: transparent;
      border: 1px solid var(--border-secondary, rgba(128, 128, 128, 0.15));
      transition:
        background 0.15s,
        color 0.15s,
        border-color 0.15s;
      user-select: none;
      line-height: 1.5;
    }

    .zoom-btn:hover {
      background: var(--bg-hover, rgba(128, 128, 128, 0.1));
      color: var(--text-primary, #ccc);
    }

    .zoom-btn.active {
      background: var(--accent-primary, #3b82f6);
      color: var(--text-inverse, #fff);
      border-color: var(--accent-primary, #3b82f6);
    }

    .zoom-hint {
      font-size: 10px;
      color: var(--text-tertiary, #666);
      font-family: var(--font-sans, sans-serif);
      padding: 0 4px;
    }

    .chart-wrap {
      position: relative;
      width: 100%;
      flex: 1;
      min-height: 0;
      touch-action: none;
    }

    .fallback {
      padding: 16px;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-mono);
      text-align: center;
    }
  `,zp);N([n({type:String})],Hp.prototype,`content`,void 0),N([i()],Hp.prototype,`hiddenSeries`,void 0),N([i()],Hp.prototype,`activeZoom`,void 0),N([i()],Hp.prototype,`error`,void 0),Hp=N([s(`chart-card`)],Hp);var Up=`highlight-utils-style`;function Wp(e){if(e.getElementById(Up))return;let t=document.createElement(`style`);t.id=Up,t.textContent=`
    mark[data-hl] {
      background: var(--accent-warning, #e8a817);
      color: inherit;
      border-radius: 2px;
      padding: 0;
    }
    mark[data-hl].active {
      background: var(--accent-primary, #2563eb);
      color: #fff;
    }
  `,e.appendChild(t)}function Gp(e,t){if(Kp(e),!t)return 0;let n=t.toLowerCase(),r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),i=[];for(;r.nextNode();)i.push(r.currentNode);let a=0;for(let e of i){let t=Jp(e.nodeValue??``,n);if(t.length<=1)continue;let r=document.createDocumentFragment();for(let e of t)if(e.match){let t=document.createElement(`mark`);t.setAttribute(`data-hl`,``),t.textContent=e.text,r.appendChild(t),a++}else r.appendChild(document.createTextNode(e.text));e.parentNode.replaceChild(r,e)}return a}function Kp(e){let t=e.querySelectorAll(`mark[data-hl]`);for(let e of t){let t=e.parentNode,n=document.createTextNode(e.textContent??``);t.replaceChild(n,e),t.normalize()}}function qp(e,t){let n=e.querySelectorAll(`mark[data-hl]`);for(let e=0;e<n.length;e++){let r=n[e];e===t?(r.classList.add(`active`),r.scrollIntoView({block:`nearest`,behavior:`smooth`})):r.classList.remove(`active`)}}function Jp(e,t){let n=[],r=e.toLowerCase(),i=0;for(;i<e.length;){let a=r.indexOf(t,i);if(a===-1){n.push({text:e.slice(i),match:!1});break}a>i&&n.push({text:e.slice(i,a),match:!1}),n.push({text:e.slice(a,a+t.length),match:!0}),i=a+t.length}return n}var Yp,Xp=(Yp=class extends l{constructor(...e){super(...e),this.content=``}render(){return a`<pre class="text">${this.content}</pre>`}},Yp.styles=d`
    :host {
      display: block;
      color: var(--text-primary);
    }

    .text {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      line-height: 1.5;
      white-space: pre;
      overflow-x: auto;
      padding: 4px 0;
      margin: 0;
    }
  `,Yp);N([n({type:String})],Xp.prototype,`content`,void 0),Xp=N([s(`text-renderer`)],Xp);var Zp,Qp,$p=(Zp=class extends l{constructor(...e){super(...e),this.cards=[],this.expandedToolStrips=new Set,this.rerunningCards=new Set,this.copiedCards=new Set,this.searchOpen=new Set,this.searchState=new Map,this.dragId=null,this.resizeCardId=null,this.resizeStartY=0,this.resizeStartHeight=0,this.onResizeMove=e=>{if(!this.resizeCardId)return;let t=e.clientY-this.resizeStartY,n=Math.max(Qp.MIN_CARD_HEIGHT,this.resizeStartHeight+t),r=this.shadowRoot?.querySelector(`.card-body[data-card-id="${this.resizeCardId}"]`);r&&(r.style.height=`${n}px`)},this.onResizeEnd=()=>{if(!this.resizeCardId)return;let e=this.shadowRoot?.querySelector(`.card-body[data-card-id="${this.resizeCardId}"]`),t=e?parseInt(e.style.height,10):this.resizeStartHeight;O.updateCardHeight(this.resizeCardId,t),this.shadowRoot?.querySelectorAll(`.resize-grip.active`).forEach(e=>{e.classList.remove(`active`)}),this.resizeCardId=null,document.removeEventListener(`mousemove`,this.onResizeMove),document.removeEventListener(`mouseup`,this.onResizeEnd)}}connectedCallback(){super.connectedCallback(),this.unsubscribe=O.subscribe(()=>{this.cards=O.state.pinCards}),this.cards=O.state.pinCards}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),document.removeEventListener(`mousemove`,this.onResizeMove),document.removeEventListener(`mouseup`,this.onResizeEnd)}close(e){O.removeCard(e)}async copyCard(e){try{await navigator.clipboard.writeText(e.content);let t=new Set(this.copiedCards);t.add(e.id),this.copiedCards=t,setTimeout(()=>{let t=new Set(this.copiedCards);t.delete(e.id),this.copiedCards=t},1500)}catch{}}toggleToolStrip(e){let t=new Set(this.expandedToolStrips);t.has(e)?t.delete(e):t.add(e),this.expandedToolStrips=t}async rerunTool(e){if(!e.toolName||this.rerunningCards.has(e.id))return;let t=new Set(this.rerunningCards);t.add(e.id),this.rerunningCards=t;try{let t=await we(e.toolName,e.toolArgs??{});O.updateCard(e.id,{loading:!0}),await new Promise(n=>setTimeout(()=>{if(e.type===`graph`)O.updateCard(e.id,{content:t.result,loading:!1,timestamp:Date.now()});else{let n=It(e.toolName,e.toolArgs??{}),r=Rt(n,t.result),i=n.canPinGraph?`text`:r.displayType;O.updateCard(e.id,{content:r.content,type:i,loading:!1,timestamp:Date.now()})}n()},0))}catch(t){O.updateCard(e.id,{content:`**Error re-running tool:** ${t.message}`,loading:!1})}finally{let t=new Set(this.rerunningCards);t.delete(e.id),this.rerunningCards=t}}onDragStart(e,t){this.dragId=e,t.dataTransfer.effectAllowed=`move`}onDragOver(e){e.preventDefault(),e.dataTransfer.dropEffect=`move`}onDragEnter(e){e.currentTarget.closest(`.card`)?.classList.add(`drag-over`)}onDragLeave(e){let t=e.currentTarget.closest(`.card`),n=e.relatedTarget;t&&!t.contains(n)&&t.classList.remove(`drag-over`)}onDrop(e,t){if(t.preventDefault(),t.currentTarget.closest(`.card`)?.classList.remove(`drag-over`),!this.dragId||this.dragId===e)return;let n=this.cards.findIndex(t=>t.id===e);n>=0&&O.moveCard(this.dragId,n),this.dragId=null}onDragEnd(){this.dragId=null,this.shadowRoot?.querySelectorAll(`.drag-over`).forEach(e=>{e.classList.remove(`drag-over`)})}onResizeStart(e,t){t.preventDefault(),this.resizeCardId=e,this.resizeStartY=t.clientY,this.resizeStartHeight=this.cards.find(t=>t.id===e)?.height??Qp.DEFAULT_CARD_HEIGHT,t.currentTarget.classList.add(`active`),document.addEventListener(`mousemove`,this.onResizeMove),document.addEventListener(`mouseup`,this.onResizeEnd)}formatTimeAgo(e){let t=Math.floor((Date.now()-e)/1e3);if(t<5)return`just now`;if(t<60)return`${t}s ago`;let n=Math.floor(t/60);if(n<60)return`${n}m ago`;let r=Math.floor(n/60);return r<24?`${r}h ago`:`${Math.floor(r/24)}d ago`}getRendererRoot(e){let t=this.shadowRoot?.querySelector(`.card-body[data-card-id="${e}"]`),n=t?.querySelector(`markdown-renderer`);if(n){let e=n.shadowRoot?.querySelector(`.md`);return e&&n.shadowRoot&&Wp(n.shadowRoot),e}let r=t?.querySelector(`text-renderer`);if(r){let e=r.shadowRoot?.querySelector(`.text`);return e&&r.shadowRoot&&Wp(r.shadowRoot),e}return null}toggleSearch(e){let t=new Set(this.searchOpen);if(t.has(e)){t.delete(e);let n=this.getRendererRoot(e);n&&Kp(n);let r=new Map(this.searchState);r.delete(e),this.searchState=r}else t.add(e);this.searchOpen=t}onSearchInput(e,t){let n=t.detail??``,r=this.getRendererRoot(e);if(!r)return;let i=Gp(r,n),a=i>0?0:-1;i>0&&qp(r,0);let o=new Map(this.searchState);o.set(e,{query:n,count:i,index:a}),this.searchState=o}onSearchNav(e,t){let n=this.searchState.get(e);if(!n||n.count===0)return;let r=(n.index+t+n.count)%n.count,i=this.getRendererRoot(e);i&&qp(i,r);let a=new Map(this.searchState);a.set(e,{...n,index:r}),this.searchState=a}toolSummary(e){if(!e.toolArgs||Object.keys(e.toolArgs).length===0)return``;let t=e.toolArgs.command;if(typeof t==`string`)return t;let n=Object.values(e.toolArgs).map(e=>typeof e==`string`?e:JSON.stringify(e)).join(`, `);return n.length>60?n.slice(0,57)+`...`:n}renderToolStrip(e){if(!e.toolName)return r;let t=this.expandedToolStrips.has(e.id),n=this.toolSummary(e),i=JSON.stringify(e.toolArgs??{},null,2);return a`
      <div class="tool-strip">
        <div class="tool-strip-header" @click=${()=>this.toggleToolStrip(e.id)}>
          <svg
            class="tool-chevron ${t?`open`:``}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <svg
            class="tool-icon"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path
              d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"
            />
          </svg>
          <span class="tool-name">${e.toolName}</span>
          ${n?a`<span class="tool-summary">${n}</span>`:r}
        </div>
        ${t?a`
              <div class="tool-detail">
                <div class="tool-detail-label">Arguments</div>
                <div class="tool-code">${i}</div>
              </div>
            `:r}
      </div>
    `}renderRerunButton(e){return e.toolName?a`
      <button
        class="header-btn rerun ${this.rerunningCards.has(e.id)?`rerunning`:``}"
        title="Re-run tool call"
        @click=${t=>{t.stopPropagation(),this.rerunTool(e)}}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="23 4 23 10 17 10" />
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
        </svg>
      </button>
    `:r}renderSearchBar(e){if(!this.searchOpen.has(e.id))return r;let t=this.searchState.get(e.id);return a`
      <card-search-bar
        .matchCount=${t?.count??0}
        .activeIndex=${t?.index??-1}
        @search-input=${t=>this.onSearchInput(e.id,t)}
        @search-prev=${()=>this.onSearchNav(e.id,-1)}
        @search-next=${()=>this.onSearchNav(e.id,1)}
        @search-close=${()=>this.toggleSearch(e.id)}
      ></card-search-bar>
    `}renderCard(e){return a`
      <div
        class="card"
        @dragover=${this.onDragOver}
        @dragenter=${this.onDragEnter}
        @dragleave=${this.onDragLeave}
        @drop=${t=>this.onDrop(e.id,t)}
      >
        <div
          class="card-header"
          draggable="true"
          @dragstart=${t=>this.onDragStart(e.id,t)}
          @dragend=${this.onDragEnd}
        >
          <button
            class="header-btn copy ${this.copiedCards.has(e.id)?`copied`:``}"
            title=${this.copiedCards.has(e.id)?`Copied!`:`Copy content`}
            @click=${t=>{t.stopPropagation(),this.copyCard(e)}}
          >
            ${this.copiedCards.has(e.id)?a`<svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <polyline points="20 6 9 17 4 12" />
                </svg>`:a`<svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                </svg>`}
          </button>
          <span class="card-title" title=${e.title}>${e.title}</span>
          <span class="timestamp" title=${new Date(e.timestamp).toLocaleString()}
            >${this.formatTimeAgo(e.timestamp)}</span
          >
          <button
            class="header-btn search"
            title="Search"
            @click=${()=>this.toggleSearch(e.id)}
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </button>
          ${this.renderRerunButton(e)}
          <button class="header-btn close" title="Close" @click=${()=>this.close(e.id)}>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        ${this.renderSearchBar(e)} ${this.renderToolStrip(e)}
        <div
          class="card-body ${e.type===`graph`?`no-scroll`:``}"
          data-card-id=${e.id}
          style="height: ${e.height??Qp.DEFAULT_CARD_HEIGHT}px"
        >
          ${e.loading?a`<div class="card-loading">
                <span class="card-loading-dot"></span>
                <span class="card-loading-dot"></span>
                <span class="card-loading-dot"></span>
                <span>Preparing&hellip;</span>
              </div>`:e.type===`graph`?a`<chart-card .content=${e.content}></chart-card>`:e.type===`text`?a`<text-renderer .content=${e.content}></text-renderer>`:a`<markdown-renderer .content=${e.content}></markdown-renderer>`}
        </div>
        <div
          class="resize-grip"
          @mousedown=${t=>this.onResizeStart(e.id,t)}
        ></div>
      </div>
    `}render(){return this.cards.length===0?a`<div class="placeholder">Pinned results will appear here</div>`:a` <div class="cards">${this.cards.map(e=>this.renderCard(e))}</div> `}},Qp=Zp,Zp.styles=d`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
      background: var(--bg-secondary);
      box-sizing: border-box;
    }

    .cards {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .card {
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-sm);
      background: var(--bg-primary);
      overflow: hidden;
    }

    .card.drag-over {
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 1px var(--accent-primary);
    }

    .card-header {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-tertiary);
      cursor: grab;
      user-select: none;
    }

    .card-header:active {
      cursor: grabbing;
    }

    .card-title {
      flex: 1;
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .timestamp {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      white-space: nowrap;
      flex-shrink: 0;
      font-variant-numeric: tabular-nums;
    }

    .header-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .header-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .header-btn.search {
      color: var(--text-tertiary);
    }

    .header-btn.close:hover {
      color: var(--accent-danger);
    }

    .header-btn.rerun:hover {
      color: var(--accent-success);
    }

    .header-btn.rerunning {
      color: var(--accent-info);
      animation: spin 1s linear infinite;
    }

    .header-btn.copy.copied {
      color: var(--accent-success);
    }

    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }

    .header-btn svg {
      width: 14px;
      height: 14px;
    }

    /* --- tool-call info strip ------------------------------------------- */

    .tool-strip {
      border-top: 1px solid var(--border-secondary);
      background: var(--bg-tool-header, var(--bg-tertiary));
      font-size: var(--font-size-xs);
      overflow: hidden;
    }

    .tool-strip-header {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 12px;
      cursor: pointer;
      user-select: none;
      transition: background var(--transition-fast);
    }

    .tool-strip-header:hover {
      background: var(--bg-hover);
    }

    .tool-chevron {
      width: 12px;
      height: 12px;
      color: var(--text-tertiary);
      transition: transform var(--transition-fast);
      flex-shrink: 0;
    }

    .tool-chevron.open {
      transform: rotate(90deg);
    }

    .tool-icon {
      width: 12px;
      height: 12px;
      color: var(--accent-warning);
      flex-shrink: 0;
    }

    .tool-name {
      font-family: var(--font-mono);
      color: var(--text-secondary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .tool-summary {
      color: var(--text-tertiary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
    }

    .tool-detail {
      padding: 6px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .tool-detail-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 2px;
    }

    .tool-code {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      padding: 6px 8px;
      background: var(--bg-code);
      border-radius: var(--radius-xs);
      white-space: pre-wrap;
      word-break: break-all;
      overflow-x: auto;
      max-height: 200px;
      overflow-y: auto;
      color: var(--text-primary);
      line-height: 1.4;
    }

    /* --- card body ------------------------------------------------------- */

    .card-body {
      padding: 10px 12px;
      overflow: auto;
      user-select: text;
      cursor: auto;
    }

    .card-body.no-scroll {
      overflow: hidden;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }

    .resize-grip {
      height: 6px;
      cursor: ns-resize;
      background: var(--bg-tertiary);
      display: flex;
      align-items: center;
      justify-content: center;
      user-select: none;
      flex-shrink: 0;
      transition: background var(--transition-fast);
    }

    .resize-grip:hover,
    .resize-grip.active {
      background: var(--accent-primary);
    }

    .resize-grip::after {
      content: "";
      display: block;
      width: 32px;
      height: 2px;
      border-radius: 1px;
      background: var(--text-tertiary);
      opacity: 0.5;
    }

    .resize-grip:hover::after,
    .resize-grip.active::after {
      background: var(--bg-primary);
      opacity: 0.8;
    }

    .placeholder {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
      padding: 16px;
      text-align: center;
      user-select: none;
    }

    .card-loading {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 24px 12px;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
    }

    .card-loading-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--text-tertiary);
      animation: loadPulse 1.2s ease-in-out infinite;
    }

    .card-loading-dot:nth-child(2) {
      animation-delay: 0.15s;
    }

    .card-loading-dot:nth-child(3) {
      animation-delay: 0.3s;
    }

    @keyframes loadPulse {
      0%,
      80%,
      100% {
        opacity: 0.25;
        transform: scale(0.8);
      }
      40% {
        opacity: 1;
        transform: scale(1);
      }
    }
  `,Zp.DEFAULT_CARD_HEIGHT=400,Zp.MIN_CARD_HEIGHT=80,Zp);N([i()],$p.prototype,`cards`,void 0),N([i()],$p.prototype,`expandedToolStrips`,void 0),N([i()],$p.prototype,`rerunningCards`,void 0),N([i()],$p.prototype,`copiedCards`,void 0),N([i()],$p.prototype,`searchOpen`,void 0),N([i()],$p.prototype,`searchState`,void 0),$p=Qp=N([s(`detail-pane`)],$p);