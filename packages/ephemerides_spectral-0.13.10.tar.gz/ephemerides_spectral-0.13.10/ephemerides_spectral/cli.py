"""``ephemerides-spectral`` console script — entry point for the CLI.

Subcommand-driven; each subcommand maps to one or two bridge methods
and prints the resulting JSON to stdout (compact or pretty-formatted).

The CLI is intentionally thin: it does input parsing + subcommand
dispatch + JSON serialisation. Numerical work happens in the bridge
layer (``ephemerides_spectral.bridge``).

Subcommands
-----------

* ``version`` — package version + frozen-data manifest
* ``bodies`` — list every body in the Sol Star System Laplacian
* ``kernel list`` — list allowed JPL DE-kernels
* ``resolution`` — temporal resolution (sec/residue) for a body
* ``encode`` — encode a JD as a system state (BIP or complex128)
* ``local-view`` — topocentric observer-bound view
* ``eclipse`` — syzygy probability via spectral alignment
* ``couplings`` — list off-diagonal Laplacian fiber couplings
* ``adaptive`` — Phase 9 state-dependent (adaptive / "breathing")
  coupling LUT modulation at a JD. ``breathing`` is an accepted
  hidden synonym for users who prefer the visual metaphor.

Use ``ephemerides-spectral <command> --help`` for per-subcommand detail.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, List, Optional

from ephemerides_spectral import bridge
from ephemerides_spectral.bridge import (
    ALLOWED_KERNELS,
    DEFAULT_BACKEND,
    SUPPORTED_BACKENDS,
    SUPPORTED_BODIES,
)
from ephemerides_spectral.version import __version__

_KERNEL_CHOICES = list(ALLOWED_KERNELS)
_BACKEND_CHOICES = list(SUPPORTED_BACKENDS)
_BODY_CHOICES = list(SUPPORTED_BODIES)


# ──────────────────────────────────────────────────────────────────────
# Output helpers
# ──────────────────────────────────────────────────────────────────────

def _emit(result: Dict[str, Any], *, pretty: bool = True) -> int:
    if pretty:
        sys.stdout.write(json.dumps(result, indent=2, sort_keys=True))
    else:
        sys.stdout.write(json.dumps(result, separators=(",", ":")))
    sys.stdout.write("\n")
    sys.stdout.flush()
    return 0 if result.get("ok") is not False else 1


def _emit_proper(result: Dict[str, Any], args: argparse.Namespace) -> int:
    """Emit a Sol Time bridge result, optionally applying ``--proper``.

    When ``args.proper`` is set, the result is augmented in place with
    proper-time-corrected count fields (`<field>_proper`) and a
    `proper_time` metadata block, transparently to the user. The
    correction body and count-field set are looked up from the
    canonical map in `bridge.apply_proper_correction`, keyed by
    ``args.subcommand_name`` (set via `set_defaults(...)` on each
    time-* subparser).
    """
    if getattr(args, "proper", False):
        result = bridge.apply_proper_correction(
            result, args.subcommand_name,
            lat=getattr(args, "lat", None),
            lon=getattr(args, "lon", None),
            reference=getattr(args, "reference", "tcb"),
        )
    if getattr(args, "state", False):
        result = bridge.apply_state_correction(
            result, args.subcommand_name,
            frame=getattr(args, "frame", "heliocentric_ecliptic"),
        )
    if getattr(args, "dynamics", False):
        result = bridge.apply_dynamics_correction(
            result, args.subcommand_name,
            frame=getattr(args, "frame", "heliocentric_ecliptic"),
        )
    return _emit(result, pretty=args.pretty)


# ──────────────────────────────────────────────────────────────────────
# Subcommand implementations
# ──────────────────────────────────────────────────────────────────────

def _cmd_version(args: argparse.Namespace) -> int:
    return _emit(bridge.get_version(), pretty=args.pretty)


def _cmd_bodies(args: argparse.Namespace) -> int:
    return _emit(bridge.list_bodies(), pretty=args.pretty)


def _cmd_kernel_list(args: argparse.Namespace) -> int:
    return _emit(bridge.list_kernels(), pretty=args.pretty)


def _cmd_resolution(args: argparse.Namespace) -> int:
    return _emit(bridge.get_resolution(args.body, D=args.D),
                 pretty=args.pretty)


def _cmd_encode(args: argparse.Namespace) -> int:
    return _emit(
        bridge.get_system_state(
            args.jd, backend=args.backend, kernel=args.kernel,
            force_high_res=args.force_high_res, D=args.D,
        ),
        pretty=args.pretty,
    )


def _cmd_local_view(args: argparse.Namespace) -> int:
    return _emit(
        bridge.get_local_view(args.jd, args.body, args.lat, args.lon,
                              kernel=args.kernel),
        pretty=args.pretty,
    )


def _cmd_eclipse(args: argparse.Namespace) -> int:
    return _emit(
        bridge.get_eclipse_probability(args.jd, kernel=args.kernel),
        pretty=args.pretty,
    )


def _cmd_couplings(args: argparse.Namespace) -> int:
    return _emit(bridge.list_couplings(), pretty=args.pretty)


def _cmd_adaptive(args: argparse.Namespace) -> int:
    """Phase 9 state-dependent (adaptive) coupling modulation.

    Also reachable via the hidden ``breathing`` subcommand for users
    who prefer the visual metaphor — same handler, identical output.
    """
    return _emit(
        bridge.get_breathing_modulation(
            args.jd, pair=(args.pair_a, args.pair_b),
            n_lobes=(args.n_a, args.n_b), kernel=args.kernel,
        ),
        pretty=args.pretty,
    )


# Backwards-compatible synonym kept so test fixtures and callers that
# import _cmd_breathing keep working. Equivalent to _cmd_adaptive.
_cmd_breathing = _cmd_adaptive


def _cmd_time_mars(args: argparse.Namespace) -> int:
    if args.msd is not None:
        return _emit(
            bridge.mars_time_to_jd(args.msd, leap_seconds=args.leap_seconds),
            pretty=args.pretty,
        )
    return _emit_proper(
        bridge.jd_to_mars_time(args.jd, leap_seconds=args.leap_seconds),
        args,
    )


def _cmd_time_lunar(args: argparse.Namespace) -> int:
    return _emit_proper(bridge.get_lunar_phase(args.jd), args)


def _cmd_time_uranus(args: argparse.Namespace) -> int:
    if args.usd is not None:
        return _emit(bridge.sol_uranian_time_to_jd(args.usd), pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_uranian_time(args.jd), args)


# ── v0.8.0 Sol Symphony Times: Venus, Mercury, Pluto, Sol, Jupiter, Saturn

def _cmd_time_venus(args: argparse.Namespace) -> int:
    if args.vsd_solar is not None:
        return _emit(bridge.sol_venus_time_to_jd(args.vsd_solar),
                     pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_venus_time(args.jd), args)


def _cmd_time_mercury(args: argparse.Namespace) -> int:
    if args.mer_sd_solar is not None:
        return _emit(bridge.sol_mercury_time_to_jd(args.mer_sd_solar),
                     pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_mercury_time(args.jd), args)


def _cmd_time_pluto(args: argparse.Namespace) -> int:
    if args.psd is not None:
        return _emit(bridge.sol_pluto_time_to_jd(args.psd),
                     pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_pluto_time(args.jd), args)


def _cmd_time_sol(args: argparse.Namespace) -> int:
    if args.crn is not None:
        return _emit(bridge.sol_sol_time_to_jd(args.crn), pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_sol_time(args.jd), args)


def _cmd_time_jupiter(args: argparse.Namespace) -> int:
    if args.jsd is not None:
        return _emit(bridge.sol_jovian_time_to_jd(args.jsd),
                     pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_jovian_time(args.jd), args)


def _cmd_time_saturn(args: argparse.Namespace) -> int:
    if args.ssd is not None:
        return _emit(bridge.sol_saturnian_time_to_jd(args.ssd),
                     pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_saturnian_time(args.jd), args)


def _cmd_time_neptune(args: argparse.Namespace) -> int:
    if args.nsd is not None:
        return _emit(bridge.sol_neptunian_time_to_jd(args.nsd),
                     pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_neptunian_time(args.jd), args)


def _cmd_time_terra(args: argparse.Namespace) -> int:
    if args.tsd_solar is not None:
        return _emit(bridge.sol_terra_time_to_jd(args.tsd_solar),
                     pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_terra_time(args.jd), args)


def _cmd_time_luna(args: argparse.Namespace) -> int:
    if args.lsd_solar is not None:
        return _emit(bridge.sol_luna_time_to_jd(args.lsd_solar),
                     pretty=args.pretty)
    return _emit_proper(bridge.jd_to_sol_luna_time(args.jd), args)


def _cmd_time_terra_luna(args: argparse.Namespace) -> int:
    """v0.10.0 Sol Terra-Luna Time (STLT) — anchored Lunar time, synodic-month count.

    Default epoch is Meton's summer solstice (27 June 432 BCE) — the
    foundational Greek lunar-solar reconciliation anchor. Pass
    ``--epoch <name>`` to switch to one of the other historical anchors:
    ``antikythera`` (205 BCE solar eclipse), ``hipparchus`` (141 BCE
    lunar eclipse), ``mardokempad`` (721 BCE Babylonian lunar eclipse),
    or ``j2000`` (modern Terra-borrowed reference).
    """
    if args.synodic_count is not None:
        return _emit(
            bridge.sol_terra_luna_time_to_jd(args.synodic_count, epoch=args.epoch),
            pretty=args.pretty,
        )
    return _emit_proper(
        bridge.jd_to_sol_terra_luna_time(args.jd, epoch=args.epoch),
        args,
    )


# ── v0.11.0 Sol Proper Time (SPrT) — standalone rate-only query

def _cmd_time_proper(args: argparse.Namespace) -> int:
    """v0.11.0 Sol Proper Time — gravitational + kinematic time-dilation rate.

    Standalone "just give me the rate" surface, complementary to the
    ``--proper`` flag on every other ``time-*`` subcommand. With
    ``--compare-to <body>``, returns the rate ratio + drift per
    Earth-year between two bodies — the most intuitive number for
    human comparison.
    """
    if args.compare_to is not None:
        return _emit(
            bridge.compare_proper_times(args.body, args.compare_to,
                                        reference=args.reference),
            pretty=args.pretty,
        )
    return _emit(
        bridge.get_proper_time_rate(
            args.body, lat=args.lat, lon=args.lon, reference=args.reference,
        ),
        pretty=args.pretty,
    )


# ── v0.12.0 Sol Kinematics — orbital state queries

def _cmd_kinematics(args: argparse.Namespace) -> int:
    """v0.12.0 Sol Kinematics — per-body or full-system orbital state.

    Standalone "give me the orbital state" surface, complementary to
    the ``--state`` flag on every ``time-*`` subcommand. With
    ``--all``, dumps every body in the 38-body roster + system totals
    (Jupiter angular-momentum fraction, etc.).
    """
    if args.all:
        return _emit(
            bridge.get_full_system_state(jd_tdb=args.jd, frame=args.frame),
            pretty=args.pretty,
        )
    if args.body is None:
        return _emit(
            {"ok": False,
             "error": "must specify --body <name> or --all"},
            pretty=args.pretty,
        )
    return _emit(
        bridge.get_kinematic_state(
            args.body, jd_tdb=args.jd, frame=args.frame,
        ),
        pretty=args.pretty,
    )


# ── v0.13.0 Sol Dynamics — system energy / forces / per-body energy budgets

def _cmd_dynamics(args: argparse.Namespace) -> int:
    """v0.13.0 Sol Dynamics — system aggregate, per-body energies, or pair forces.

    Three query modes:
      - default: system-level aggregate (KE / PE / total / L partitions)
      - --body X: that body's energy budget (KE + PE + total)
      - --body X --from Y: gravitational force on X from Y
    """
    if args.from_body is not None:
        if args.body is None:
            return _emit(
                {"ok": False,
                 "error": "--from <Y> requires --body <X>"},
                pretty=args.pretty,
            )
        return _emit(
            bridge.get_force_between(
                args.body, args.from_body,
                jd_tdb=args.jd, frame=args.frame,
            ),
            pretty=args.pretty,
        )
    if args.body is not None:
        return _emit(
            bridge.get_body_energies(
                args.body, jd_tdb=args.jd, frame=args.frame,
            ),
            pretty=args.pretty,
        )
    return _emit(
        bridge.get_dynamics(jd_tdb=args.jd, frame=args.frame),
        pretty=args.pretty,
    )


def _cmd_find_tubes(args: argparse.Namespace) -> int:
    return _emit(
        bridge.find_itn_pathways(
            args.from_jd, args.to_jd,
            departure=args.departure, target=args.target,
            threshold=args.threshold, max_candidates=args.max_candidates,
        ),
        pretty=args.pretty,
    )


def _cmd_lunar_kernels(args: argparse.Namespace) -> int:
    return _emit(bridge.list_lunar_kernels(), pretty=args.pretty)


def _cmd_natural_group(args: argparse.Namespace) -> int:
    return _emit(bridge.get_natural_resonance_group(), pretty=args.pretty)


def _cmd_find_syzygies(args: argparse.Namespace) -> int:
    return _emit(
        bridge.find_syzygies(
            args.from_jd, args.to_jd,
            kind=args.kind, threshold=args.threshold,
        ),
        pretty=args.pretty,
    )


def _cmd_patches_catalog(args: argparse.Namespace) -> int:
    return _emit(bridge.list_catalog_patches(), pretty=args.pretty)


def _cmd_patches_active(args: argparse.Namespace) -> int:
    return _emit(bridge.list_active_patches(), pretty=args.pretty)


def _cmd_patches_apply(args: argparse.Namespace) -> int:
    return _emit(bridge.apply_patch(args.name), pretty=args.pretty)


def _cmd_patches_clear(args: argparse.Namespace) -> int:
    return _emit(bridge.clear_patches(), pretty=args.pretty)


# ──────────────────────────────────────────────────────────────────────
# Parser construction
# ──────────────────────────────────────────────────────────────────────

_TOPLEVEL_DESCRIPTION = """\
Ephemerides Spectral — high-precision HDC reference instrument for the
Sol Star System.

Encodes celestial bodies (planets, moons, asteroids) as resonant phases
in a high-dimensional cyclic-group space (Z_{2^32} for the BIP backend
at D=65536). Two interchangeable backends:

  * 'bip' (default)    — bit-serialised integer ALU, 305x speedup,
                         pure-integer cyclic-group reduction via uint32
                         overflow. Phase 9 adaptive couplings (Jupiter-
                         Saturn 5:2 resonance) — also called "breathing"
                         couplings in the visual / informal register —
                         handled with an integer cosine LUT, no FPU in
                         the hot path.
  * 'complex128'       — FPU complex128 reference encoder; same
                         algebraic structure, used for regression and
                         the Syzygy / observer-binding operators.

The system Laplacian decomposes as:

  * Diagonal       — Newtonian mean motions (2pi / period_days).
  * Diagonal (PN)  — Mercury 43"/century relativistic precession.
  * Off-diagonal   — gravitational fiber couplings (planet-sun,
                     moon-planet, J-S resonance, asteroid-Jupiter).

Phase 9 (adaptive / "breathing") modulates the off-diagonal weights
with the resonant phase difference cos(n_a*phi_a - n_b*phi_b) via a
1024-entry int32 cosine LUT (Q1.14 amplitude, 4 KB). The construction
is a state-dependent (non-autonomous) graph Laplacian — adaptive in
the network-science sense (Gross & Blasius 2008, adaptive Kuramoto)
and informally "breathing" because the couplings inhale/exhale with
the relative resonant phase.
"""

_TOPLEVEL_EPILOG = """\
Examples
--------

    # Package version + frozen-data manifest
    ephemerides-spectral version

    # All 26 bodies in the Sol Star System Laplacian
    ephemerides-spectral bodies

    # Terra temporal resolution at the default D=65536
    ephemerides-spectral resolution --body terra

    # Encode J2000 with the integer ALU backend (default)
    ephemerides-spectral encode --jd 2451545.0

    # Same JD with the FPU complex128 reference encoder
    ephemerides-spectral encode --jd 2451545.0 --backend complex128

    # Topocentric view from London at J2000
    ephemerides-spectral local-view --jd 2451545.0 --body terra \\
                          --lat 51.5 --lon -0.1

    # Syzygy alignment probability at a JD
    ephemerides-spectral eclipse --jd 2451545.0

    # Off-diagonal couplings (Laplacian fiber bundle)
    ephemerides-spectral couplings

    # Phase 9 adaptive modulation for Jupiter-Saturn 5:2 at +20 yr
    ephemerides-spectral adaptive --jd 2458850.0

    # Override resonance: 3:2 Neptune-Pluto
    ephemerides-spectral adaptive --jd 2451545.0 \\
                          --pair-a neptune --pair-b pluto --n-a 3 --n-b 2

    # `breathing` is an accepted hidden synonym (same handler):
    ephemerides-spectral breathing --jd 2458850.0

References
----------

* Research notebook:    ../ephemerides_spectral_research_notebook.md
* RBS-HDC evaluation:   ../research/resonant_bit_serialized_hdc_evaluation.md
* Cross-pollination:    chess-spectral notebook §20.13-§20.17
                        (Z_{640} vs Z_{2^32} group-theoretic isomorphism)
* Companion project:    antikythera-spectral (sibling research notebook)

Reference time
--------------

REFERENCE_JD = 2451545.0 (J2000.0). The BIP int64 envelope tolerates
|jd - REFERENCE_JD| up to ~1.86 Myr, well beyond the DE441 epoch
(-13200 BCE .. +17200 CE).
"""


def _add_proper_flags(parser: argparse.ArgumentParser) -> None:
    """Add the v0.11.0 ``--proper``/``--lat``/``--lon``/``--reference`` flag set.

    Called on every ``time-*`` subparser so every Sol Time gets a
    transparent proper-time-correction option without ceremony.
    """
    grp = parser.add_argument_group(
        "proper-time correction (v0.11.0)",
        "Apply gravitational + orbital-kinematic time dilation for the "
        "body's surface (no-op without --proper). Implementation lives "
        "in `bridge.apply_proper_correction`; output gains "
        "`<count>_proper` sibling fields and a `proper_time` block.",
    )
    grp.add_argument(
        "--proper", action="store_true",
        help="Apply Sol Proper Time (SPrT) correction. Augments the "
             "result with proper-time-corrected count fields and a "
             "`proper_time` metadata block. v0.11.0 captures GR surface + "
             "orbital kinematic; J2 oblateness deferred.",
    )
    grp.add_argument(
        "--lat", type=float, default=None,
        help="Surface latitude in degrees (forward-compat for J2 "
             "oblateness; v0.11.0 ignores).",
    )
    grp.add_argument(
        "--lon", type=float, default=None,
        help="Surface longitude in degrees (forward-compat for J2 "
             "oblateness; v0.11.0 ignores).",
    )
    grp.add_argument(
        "--reference", choices=("tcb", "tdb"), default="tcb",
        help="Reference time scale (default 'tcb', barycentric "
             "coordinate time per IAU 2000).",
    )
    # v0.12.0 — Sol Kinematics --state flag, added uniformly to every
    # time-* subcommand the same way --proper is. When set, augments
    # the time output with a `kinematic_state` block (orbital velocity,
    # semi-major axis, kinetic energy, angular momentum) for the
    # subcommand's canonical body.
    state_grp = parser.add_argument_group(
        "kinematic state (v0.12.0)",
        "Augment the result with a Sol Kinematics block for the "
        "subcommand's canonical body (no-op without --state). "
        "Implementation lives in `bridge.apply_state_correction`; "
        "output gains a `kinematic_state` block.",
    )
    state_grp.add_argument(
        "--state", action="store_true",
        help="Apply Sol Kinematics augmentation. Adds a "
             "`kinematic_state` block with orbital velocity, "
             "semi-major axis, kinetic energy, angular momentum.",
    )
    state_grp.add_argument(
        "--frame", choices=("heliocentric_ecliptic", "parent_centric"),
        default="heliocentric_ecliptic",
        help="Reference frame for the kinematic state (default "
             "'heliocentric_ecliptic'). v0.12.0 ships circular Kepler "
             "approximation; both frames produce the same elements.",
    )
    # v0.13.0 — Sol Dynamics --dynamics flag, added uniformly to every
    # time-* subcommand the same way --proper and --state are. When
    # set, augments the time output with a `dynamics` block (KE, PE,
    # total energy, is_bound) for the subcommand's canonical body.
    dyn_grp = parser.add_argument_group(
        "kinematic dynamics (v0.13.0)",
        "Augment the result with a Sol Dynamics block for the "
        "subcommand's canonical body (no-op without --dynamics). "
        "Implementation lives in `bridge.apply_dynamics_correction`; "
        "output gains a `dynamics` block with KE / PE / total energy.",
    )
    dyn_grp.add_argument(
        "--dynamics", action="store_true",
        help="Apply Sol Dynamics augmentation. Adds a `dynamics` "
             "block with kinetic energy, potential energy, total "
             "energy, and is_bound flag. Same body as --state and "
             "--proper.",
    )


def _make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ephemerides-spectral",
        description=_TOPLEVEL_DESCRIPTION,
        epilog=_TOPLEVEL_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--version", action="version",
                   version=f"ephemerides-spectral {__version__}")
    p.add_argument("--no-pretty", dest="pretty", action="store_false",
                   default=True,
                   help="Emit compact (single-line) JSON instead of pretty-printed.")

    sub = p.add_subparsers(dest="cmd", required=True, title="Commands",
                           metavar="<command>")

    # version
    v = sub.add_parser(
        "version",
        help="Print package version + frozen-data manifest",
        description=(
            "Emits {package, version, manifest} where manifest is the "
            "codegen-stamped table of frozen research-module SHAs."
        ),
    )
    v.set_defaults(func=_cmd_version)

    # bodies
    b = sub.add_parser(
        "bodies",
        help="List the 26 bodies in the Sol Star System Laplacian",
        description=(
            "Star + 9 planets (incl. Pluto) + 12 major moons + 4 main-belt "
            "asteroids. Each row carries period_days and mass_earth used "
            "by the Laplacian construction."
        ),
    )
    b.set_defaults(func=_cmd_bodies)

    # kernel list
    kn = sub.add_parser(
        "kernel",
        help="JPL DE-kernel utilities",
        description="List allowed JPL DE-series ephemeris kernels.",
    )
    kn_sub = kn.add_subparsers(dest="kernel_cmd", required=True)
    kn_list = kn_sub.add_parser(
        "list",
        help="List the allowed DE-kernel set",
        description=(
            "Prints the ALLOWED_KERNELS allowlist (de421/de440/de441/"
            "de442). Actual on-disk availability is determined when an "
            "instrument is constructed; the loader falls back to de421 "
            "if a higher-resolution kernel is missing (unless "
            "force_high_res)."
        ),
    )
    kn_list.set_defaults(func=_cmd_kernel_list)

    # resolution
    r = sub.add_parser(
        "resolution",
        help="Seconds per residue shift for a body at a given D",
        description=(
            "Returns sec/residue and min/residue for one body. At "
            "D=65536, Earth ≈ 481.4 s/residue (~8 min). Resolution "
            "scales linearly with D — bump to D=2^25 for ~1 s/residue."
        ),
        epilog="Example: ephemerides-spectral resolution --body mars --D 65536",
    )
    r.add_argument("--body", default="terra", choices=_BODY_CHOICES,
                   help="Body name (default 'terra')")
    r.add_argument("--D", type=int, default=65536,
                   help="Hypervector dimension (default 65536)")
    r.set_defaults(func=_cmd_resolution)

    # encode
    e = sub.add_parser(
        "encode",
        help="Encode a JD as the system state vector",
        description=(
            "Build the HDC system state for a Julian Date. The default "
            "'bip' backend returns per-body uint32 phase residues from "
            "the integer-ALU encoder; 'complex128' returns the FPU "
            "reference's interleaved-Float32 complex state."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral encode --jd 2451545.0\n"
            "  ephemerides-spectral encode --jd 2451545.0 --backend complex128\n"
            "  ephemerides-spectral encode --jd 2451545.0 --kernel de441 --force-high-res"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    e.add_argument("--jd", type=float, required=True,
                   help="Julian Date in TDB")
    e.add_argument("--backend", choices=_BACKEND_CHOICES, default=DEFAULT_BACKEND,
                   help=f"HDC backend (default {DEFAULT_BACKEND!r})")
    e.add_argument("--kernel", choices=_KERNEL_CHOICES, default="de441",
                   help="JPL DE-kernel for calibration (default 'de441')")
    e.add_argument("--force-high-res", dest="force_high_res", action="store_true",
                   help="Abort if the requested kernel is missing (no de421 fallback)")
    e.add_argument("--D", type=int, default=65536,
                   help="Hypervector dimension; must be a power of 2 (default 65536)")
    e.set_defaults(func=_cmd_encode)

    # local-view
    lv = sub.add_parser(
        "local-view",
        help="Topocentric view bound to a body + (lat, lon)",
        description=(
            "Extracts a 'Local View' hypervector by binding a unitary "
            "Observer Operator to the global system state. Encodes the "
            "perspective of an observer at (lat, lon) on body."
        ),
        epilog=(
            "Example: ephemerides-spectral local-view --jd 2451545.0 \\\n"
            "                --body terra --lat 51.5 --lon -0.1"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    lv.add_argument("--jd", type=float, required=True, help="Julian Date in TDB")
    lv.add_argument("--body", required=True, choices=_BODY_CHOICES,
                    help="Body name")
    lv.add_argument("--lat", type=float, required=True,
                    help="Geographic latitude (-90 .. 90)")
    lv.add_argument("--lon", type=float, required=True,
                    help="Geographic longitude (-180 .. 360)")
    lv.add_argument("--kernel", choices=_KERNEL_CHOICES, default="de441",
                    help="JPL DE-kernel (default 'de441')")
    lv.set_defaults(func=_cmd_local_view)

    # eclipse
    ec = sub.add_parser(
        "eclipse",
        help="Syzygy probability at a JD via spectral alignment",
        description=(
            "Inner product of the system state with the Syzygy Operator "
            "(Sun + Moon + lunar Node basis). Returns a magnitude in "
            "[0, 1]; high values indicate a syzygy (eclipse / "
            "conjunction) is spectrally close."
        ),
    )
    ec.add_argument("--jd", type=float, required=True, help="Julian Date in TDB")
    ec.add_argument("--kernel", choices=_KERNEL_CHOICES, default="de441",
                    help="JPL DE-kernel (default 'de441')")
    ec.set_defaults(func=_cmd_eclipse)

    # couplings
    cp = sub.add_parser(
        "couplings",
        help="Off-diagonal Laplacian couplings (gravitational fibers)",
        description=(
            "Lists every off-diagonal weight in the static Laplacian, "
            "categorised as planet-sun / moon-planet / asteroid-jupiter "
            "/ resonance. Output includes both the rad/day weight and "
            "the residues/day fixed-point conversion (Q-format)."
        ),
    )
    cp.set_defaults(func=_cmd_couplings)

    # adaptive (primary) + breathing (hidden synonym)
    #
    # Phase 9 modulates the off-diagonal Laplacian weights with the
    # resonant phase difference cos(n_a*phi_a - n_b*phi_b). This is a
    # state-dependent (non-autonomous) graph Laplacian — adaptive in
    # the network-science sense (Gross & Blasius 2008, adaptive Kuramoto
    # coupling). Informally we call it "breathing" because the couplings
    # inhale/exhale with the relative resonant phase. `adaptive` is the
    # primary subcommand; `breathing` is preserved as a hidden synonym
    # for users who prefer the visual metaphor — same handler, same args.

    def _add_adaptive_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--jd", type=float, required=True,
                       help="Julian Date in TDB")
        p.add_argument("--pair-a", dest="pair_a", default="jupiter",
                       choices=_BODY_CHOICES, help="First body of the pair")
        p.add_argument("--pair-b", dest="pair_b", default="saturn",
                       choices=_BODY_CHOICES, help="Second body of the pair")
        p.add_argument("--n-a", dest="n_a", type=int, default=5,
                       help="Resonance multiplier on phi_a (default 5)")
        p.add_argument("--n-b", dest="n_b", type=int, default=2,
                       help="Resonance multiplier on phi_b (default 2)")
        p.add_argument("--kernel", choices=_KERNEL_CHOICES, default="de441",
                       help="JPL DE-kernel (default 'de441')")
        p.set_defaults(func=_cmd_adaptive)

    ad = sub.add_parser(
        "adaptive",
        help="Phase 9 adaptive (a.k.a. 'breathing') coupling LUT at a JD",
        description=(
            "Computes the resonant phase n_a*phi_a - n_b*phi_b (mod "
            "2^32) for a body pair at a JD, then evaluates the integer "
            "cosine LUT (Q1.14, 1024 entries). Returns both the LUT "
            "value and a float reference for calibration. The "
            "construction is a state-dependent (non-autonomous) graph "
            "Laplacian — adaptive in the adaptive-networks / adaptive-"
            "Kuramoto sense (Gross & Blasius 2008). The visual / "
            "informal name is 'breathing' couplings; the `breathing` "
            "subcommand is an accepted hidden synonym (same handler)."
        ),
        epilog=(
            "Examples:\n"
            "  # Default Jupiter-Saturn 5:2 resonance\n"
            "  ephemerides-spectral adaptive --jd 2451545.0\n\n"
            "  # Neptune-Pluto 3:2 resonance\n"
            "  ephemerides-spectral adaptive --jd 2451545.0 \\\n"
            "         --pair-a neptune --pair-b pluto --n-a 3 --n-b 2\n\n"
            "  # Io-Europa 1:2 (note ordering: smaller multiplier first)\n"
            "  ephemerides-spectral adaptive --jd 2451545.0 \\\n"
            "         --pair-a europa --pair-b io --n-a 1 --n-b 2\n\n"
            "  # `breathing` is an accepted hidden synonym:\n"
            "  ephemerides-spectral breathing --jd 2451545.0"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_adaptive_args(ad)

    # Hidden synonym: invisible in `--help` (help=argparse.SUPPRESS) but
    # fully functional when typed. Kept for visual-metaphor users and
    # backwards compatibility with v0.9.1 and earlier scripts.
    br = sub.add_parser(
        "breathing",
        help=argparse.SUPPRESS,
        description=(
            "Hidden synonym for `adaptive`. Phase 9 state-dependent "
            "coupling modulation. See `ephemerides-spectral adaptive "
            "--help` for the canonical help text."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_adaptive_args(br)

    # time-mars
    tm = sub.add_parser(
        "time-mars",
        help="Mars Sol Date + Mars Coordinated Time at a JD (or invert)",
        description=(
            "Convert UTC Julian Date to Mars Sol Date (MSD) + Mars "
            "Coordinated Time (MTC) per Allison & McEwen 2000. "
            "Use --msd to invert (MSD -> JD_UTC). The default leap-"
            "second offset (37 s) is the IERS Bulletin C value from "
            "Jan 2017, unchanged through 2026."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-mars --jd 2451549.5    # MSD reference\n"
            "  ephemerides-spectral time-mars --jd 2461165.0    # today-ish\n"
            "  ephemerides-spectral time-mars --msd 50000       # MSD -> JD"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tm_group = tm.add_mutually_exclusive_group(required=True)
    tm_group.add_argument("--jd", type=float, default=None,
                          help="UTC Julian Date to convert to MSD + MTC")
    tm_group.add_argument("--msd", type=float, default=None,
                          help="Mars Sol Date to invert back to JD_UTC")
    tm.add_argument("--leap-seconds", dest="leap_seconds", type=int,
                    default=37,
                    help="TAI - UTC offset, seconds (default 37)")
    _add_proper_flags(tm)
    tm.set_defaults(func=_cmd_time_mars, subcommand_name="time-mars")

    # time-lunar
    tl = sub.add_parser(
        "time-lunar",
        help="Mean synodic + sidereal lunar age/phase at a JD",
        description=(
            "Returns mean lunar synodic and sidereal age (days since "
            "the J2000-anchored reference new moon) and phase ([0,1)). "
            "These are the bronze-dial primitives — fixed-period "
            "approximations sufficient for HDC encoding and Saros-"
            "class navigation. For arc-second-class precision use "
            "the JPL ephemeris path via `encode --jd ...` and read "
            "the moon residue."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-lunar --jd 2451545.0   # J2000\n"
            "  ephemerides-spectral time-lunar --jd 2461165.0   # today-ish"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tl.add_argument("--jd", type=float, required=True,
                    help="Julian Date in TDB")
    _add_proper_flags(tl)
    tl.set_defaults(func=_cmd_time_lunar, subcommand_name="time-lunar")

    # time-uranus (v0.5.4)
    tu = sub.add_parser(
        "time-uranus",
        help="Sol Uranian Time (USD + SUT) + orbital season at a JD (or invert)",
        description=(
            "Convert JD (TDB) to Sol Uranian Time. The third planetary "
            "time system in the package alongside Mars (MSD/MTC) and "
            "lunar synodic/sidereal phase. Three independent cycles:\n"
            "  - USD (Uranian Sol Date): Uranian sidereal days since the "
            "    SUT epoch (2007-12-16 northern equinox). 1 USD ~= 17.24 h.\n"
            "  - SUT (Sol Uranian Time): time-of-day at Uranus's prime "
            "    meridian, 0-24 hours. 1 Uranian hour ~= 43.1 Earth-min.\n"
            "  - Orbital phase + season: Uranus's 84.02-yr orbit is "
            "    partitioned into 4 ~21-yr seasons. Anchored at the 2007 "
            "    northern equinox. Uranus rotates retrograde (the rotation "
            "    direction is backwards relative to its orbital motion); "
            "    the result carries `retrograde=True`.\n"
            "Use --usd to invert (USD -> JD_TDB)."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-uranus --jd 2451545.0    # J2000\n"
            "  ephemerides-spectral time-uranus --jd 2454451.0    # SUT epoch (2007 equinox)\n"
            "  ephemerides-spectral time-uranus --jd 2461165.0    # today-ish\n"
            "  ephemerides-spectral time-uranus --usd 4046.45     # USD -> JD_TDB\n\n"
            "Sol Uranian Time and Mars Sol Date are independent: their cyclic\n"
            "groups don't share natural-coprime structure (Uranus does not\n"
            "sit in a clean integer mean-motion resonance with anything in\n"
            "the Sol Star System). See research notebook §7 for the\n"
            "natural-harmonic discussion + the 4-season geometry."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tu_group = tu.add_mutually_exclusive_group(required=True)
    tu_group.add_argument("--jd", type=float, default=None,
                          help="JD (TDB) to convert to Sol Uranian Time")
    tu_group.add_argument("--usd", type=float, default=None,
                          help="Uranian Sol Date to invert back to JD_TDB")
    _add_proper_flags(tu)
    tu.set_defaults(func=_cmd_time_uranus, subcommand_name="time-uranus")

    # ── v0.8.0 Sol Symphony Times: Venus, Mercury, Pluto, Sol, Jupiter, Saturn

    # time-venus
    tv = sub.add_parser(
        "time-venus",
        help="Sol Venusian Time at a JD (sidereal + solar day phase)",
        description=(
            "Convert JD (TDB) to Sol Venusian Time. Venus's sidereal day\n"
            "(243.0 Earth-days) is LONGER than its 224.7-day year, so the\n"
            "sidereal vs. solar day distinction matters: the result\n"
            "carries both. Solar day = 116.75 Earth-days = the natural\n"
            "answer to 'what time is it on Venus' (one sunrise to next).\n"
            "Venus rotates retrograde; the result carries `retrograde=True`.\n"
            "Use --vsd-solar to invert (Venus solar-day count -> JD_TDB)."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-venus --jd 2451545.0     # J2000 (anchor)\n"
            "  ephemerides-spectral time-venus --vsd-solar 100    # 100 solar days past J2000\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tv_g = tv.add_mutually_exclusive_group(required=True)
    tv_g.add_argument("--jd", type=float, default=None,
                       help="JD (TDB) to convert to Sol Venusian Time")
    tv_g.add_argument("--vsd-solar", dest="vsd_solar", type=float, default=None,
                       help="Venus solar-day count to invert back to JD_TDB")
    _add_proper_flags(tv)
    tv.set_defaults(func=_cmd_time_venus, subcommand_name="time-venus")

    # time-mercury
    tm2 = sub.add_parser(
        "time-mercury",
        help="Sol Mercurian Time at a JD (3:2 spin-orbit resonance)",
        description=(
            "Convert JD (TDB) to Sol Mercurian Time. Mercury is in 3:2\n"
            "spin-orbit resonance: the solar day = 2 Mercury years exactly.\n"
            "Sidereal day = 58.65 Earth-days, solar day = 175.98 Earth-days,\n"
            "year = 87.97 Earth-days. The result carries both sidereal-day\n"
            "and solar-day phase coordinates.\n"
            "Use --mer-sd-solar to invert."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-mercury --jd 2451545.0       # J2000 (anchor)\n"
            "  ephemerides-spectral time-mercury --mer-sd-solar 50    # 50 solar days past J2000"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tm2_g = tm2.add_mutually_exclusive_group(required=True)
    tm2_g.add_argument("--jd", type=float, default=None,
                        help="JD (TDB) to convert to Sol Mercurian Time")
    tm2_g.add_argument("--mer-sd-solar", dest="mer_sd_solar",
                        type=float, default=None,
                        help="Mercury solar-day count to invert back to JD_TDB")
    _add_proper_flags(tm2)
    tm2.set_defaults(func=_cmd_time_mercury, subcommand_name="time-mercury")

    # time-pluto
    tp = sub.add_parser(
        "time-pluto",
        help="Sol Plutonian Time at a JD (Pluto-Charon system rotation)",
        description=(
            "Convert JD (TDB) to Sol Plutonian Time. Pluto sidereal day =\n"
            "6.39 Earth-days; year = 248 Earth-years. The Pluto-Charon\n"
            "system is mutually tidally locked — Charon's orbital period\n"
            "equals Pluto's rotation period exactly. IAU-2015 anchors the\n"
            "prime meridian at the sub-Charon point. Pluto's tilt of 122.5°\n"
            "puts it in the retrograde-rotation regime (similar to Uranus).\n"
            "Use --psd to invert."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-pluto --jd 2457217.0    # New Horizons closest approach (anchor)\n"
            "  ephemerides-spectral time-pluto --jd 2451545.0    # J2000\n"
            "  ephemerides-spectral time-pluto --psd 365         # 365 Pluto-sols past anchor"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tp_g = tp.add_mutually_exclusive_group(required=True)
    tp_g.add_argument("--jd", type=float, default=None,
                       help="JD (TDB) to convert to Sol Plutonian Time")
    tp_g.add_argument("--psd", type=float, default=None,
                       help="Pluto sol-date count to invert back to JD_TDB")
    _add_proper_flags(tp)
    tp.set_defaults(func=_cmd_time_pluto, subcommand_name="time-pluto")

    # time-sol (the Sun's own time, Carrington system)
    ts = sub.add_parser(
        "time-sol",
        help="Sol Sol Time — the Sun's own time, Carrington rotation system",
        description=(
            "Convert JD (TDB) to Sol Sol Time. The Sun has no IAU prime\n"
            "meridian (no solid surface), so the Carrington Rotation Number\n"
            "(CRN) is the conventional reference: integer counter starting\n"
            "at CRN 1 on 1853-11-09, each rotation = 25.38 Earth-days at\n"
            "~16° solar latitude. The Sun has differential rotation (equator\n"
            "~24.47 d, poles ~38 d); 25.38 d is the Carrington reference.\n"
            "Use --crn to invert (CRN -> JD_TDB)."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-sol --jd 2398167.4    # CRN 1 epoch (anchor)\n"
            "  ephemerides-spectral time-sol --jd 2451545.0    # J2000 (~CRN 1956)\n"
            "  ephemerides-spectral time-sol --jd 2461165.0    # today-ish\n"
            "  ephemerides-spectral time-sol --crn 2300        # CRN -> JD_TDB"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ts_g = ts.add_mutually_exclusive_group(required=True)
    ts_g.add_argument("--jd", type=float, default=None,
                       help="JD (TDB) to convert to Sol Sol Time")
    ts_g.add_argument("--crn", type=float, default=None,
                       help="Carrington Rotation Number to invert back to JD_TDB")
    _add_proper_flags(ts)
    ts.set_defaults(func=_cmd_time_sol, subcommand_name="time-sol")

    # time-jupiter
    tj = sub.add_parser(
        "time-jupiter",
        help="Sol Jovian Time at a JD (Jupiter System III magnetic-field rotation)",
        description=(
            "Convert JD (TDB) to Sol Jovian Time using System III rotation\n"
            "(magnetic-field axis, 9h 55m 30s — the IAU standard). System I\n"
            "(equatorial cloud features) and System II (mid-latitude clouds)\n"
            "have different rates and are not exposed here. Year = 11.86\n"
            "Earth-years.\n"
            "Use --jsd to invert."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-jupiter --jd 2444000.5   # System III 1965.0 (anchor)\n"
            "  ephemerides-spectral time-jupiter --jd 2451545.0   # J2000\n"
            "  ephemerides-spectral time-jupiter --jsd 1000       # 1000 Jovian sols past anchor"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tj_g = tj.add_mutually_exclusive_group(required=True)
    tj_g.add_argument("--jd", type=float, default=None,
                       help="JD (TDB) to convert to Sol Jovian Time")
    tj_g.add_argument("--jsd", type=float, default=None,
                       help="Jupiter sol-date count (System III) to invert back to JD_TDB")
    _add_proper_flags(tj)
    tj.set_defaults(func=_cmd_time_jupiter, subcommand_name="time-jupiter")

    # time-saturn
    tsat = sub.add_parser(
        "time-saturn",
        help="Sol Saturnian Time at a JD (Cassini-revised System III)",
        description=(
            "Convert JD (TDB) to Sol Saturnian Time using the Cassini-revised\n"
            "System III rotation period (10h 32m 35s, Mankovich et al. 2019\n"
            "ApJ 871:1 — supersedes the older Voyager value of 10h 39m 22.4s).\n"
            "Saturn's rotation rate was determined via ring seismology, not\n"
            "moon orbits — Sol Saturnian Time is fully independent of any\n"
            "Saturnian moon set. Year = 29.46 Earth-years.\n"
            "Use --ssd to invert."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-saturn --jd 2451545.0   # J2000 (anchor)\n"
            "  ephemerides-spectral time-saturn --jd 2461165.0   # today-ish\n"
            "  ephemerides-spectral time-saturn --ssd 5000       # 5000 Saturnian sols past J2000"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tsat_g = tsat.add_mutually_exclusive_group(required=True)
    tsat_g.add_argument("--jd", type=float, default=None,
                         help="JD (TDB) to convert to Sol Saturnian Time")
    tsat_g.add_argument("--ssd", type=float, default=None,
                         help="Saturn sol-date count to invert back to JD_TDB")
    _add_proper_flags(tsat)
    tsat.set_defaults(func=_cmd_time_saturn, subcommand_name="time-saturn")

    # time-neptune
    tn = sub.add_parser(
        "time-neptune",
        help="Sol Neptunian Time at a JD (Voyager 2 magnetic-field rotation)",
        description=(
            "Convert JD (TDB) to Sol Neptunian Time. Neptune's System III\n"
            "rotation period (16h 6m 36s ± 3s) was measured by Voyager 2\n"
            "in 1989 from magnetic-field tilt-tracking; still the canonical\n"
            "value (no Cassini-equivalent ring seismology mission to Neptune\n"
            "yet). Prograde rotation, axial tilt 28.32°, year = 164.79 Earth-\n"
            "years. Anchor: J2000.0.\n"
            "Use --nsd to invert."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-neptune --jd 2451545.0   # J2000 (anchor)\n"
            "  ephemerides-spectral time-neptune --jd 2461165.0   # today-ish\n"
            "  ephemerides-spectral time-neptune --nsd 5000       # 5000 Neptunian sols past J2000"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tn_g = tn.add_mutually_exclusive_group(required=True)
    tn_g.add_argument("--jd", type=float, default=None,
                       help="JD (TDB) to convert to Sol Neptunian Time")
    tn_g.add_argument("--nsd", type=float, default=None,
                       help="Neptune sol-date count to invert back to JD_TDB")
    _add_proper_flags(tn)
    tn.set_defaults(func=_cmd_time_neptune, subcommand_name="time-neptune")

    # time-terra (v0.9.1) — Sol Terra Time (STT)
    tt = sub.add_parser(
        "time-terra",
        help="Sol Terra Time (STT) at a JD — Earth's surface clock",
        description=(
            "Convert JD (TDB) to Sol Terra Time. Terra's surface clock\n"
            "anchored at J2000.0 with Greenwich as the prime meridian.\n"
            "  sidereal day = 23h 56m 4s = 0.99726957 Earth-days\n"
            "  solar day    = 24h        = 1.0 Earth-day (by definition)\n"
            "  year         = 365.256 Earth-days\n"
            "Use --tsd-solar to invert."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-terra --jd 2451545.0   # J2000 (anchor)\n"
            "  ephemerides-spectral time-terra --jd 2461165.0   # today-ish\n"
            "  ephemerides-spectral time-terra --tsd-solar 5000 # 5000 Terra solar days past J2000"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tt_g = tt.add_mutually_exclusive_group(required=True)
    tt_g.add_argument("--jd", type=float, default=None,
                       help="JD (TDB) to convert to Sol Terra Time")
    tt_g.add_argument("--tsd-solar", dest="tsd_solar", type=float, default=None,
                       help="Terra solar-day count to invert back to JD_TDB")
    _add_proper_flags(tt)
    tt.set_defaults(func=_cmd_time_terra, subcommand_name="time-terra")

    # time-luna (v0.9.1) — Sol Luna Time (SLT)
    tl2 = sub.add_parser(
        "time-luna",
        help="Sol Luna Time (SLT) at a JD — Luna's surface clock",
        description=(
            "Convert JD (TDB) to Sol Luna Time. Luna's surface clock,\n"
            "tidally locked to Terra so sidereal day = orbital period.\n"
            "  sidereal day = orbital period = 27.32 Earth-days\n"
            "  solar day    = synodic month  = 29.53 Earth-days\n"
            "Anchored at J2000.0 with the IAU 2015 prime meridian at\n"
            "the sub-Terra point.\n"
            "\n"
            "DISTINCT FROM Sol Lunar Time (`time-lunar`), which returns\n"
            "Luna's synodic + sidereal phase as observed from Terra.\n"
            "Same body, different observer frame.\n"
            "Use --lsd-solar to invert."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral time-luna --jd 2451545.0     # J2000 (anchor)\n"
            "  ephemerides-spectral time-luna --jd 2461165.0     # today-ish\n"
            "  ephemerides-spectral time-luna --lsd-solar 100    # 100 Luna synodic days past J2000"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tl2_g = tl2.add_mutually_exclusive_group(required=True)
    tl2_g.add_argument("--jd", type=float, default=None,
                        help="JD (TDB) to convert to Sol Luna Time")
    tl2_g.add_argument("--lsd-solar", dest="lsd_solar", type=float, default=None,
                        help="Luna solar (synodic) day count to invert back to JD_TDB")
    _add_proper_flags(tl2)
    tl2.set_defaults(func=_cmd_time_luna, subcommand_name="time-luna")

    # time-terra-luna (v0.10.0) — Sol Terra-Luna Time (STLT)
    #
    # Anchored Lunar time using the synodic month — primary lunar-time
    # entry per the moons-stuck-to-parent `Sol <Parent>-<Body> Time`
    # convention. First Sol Time member
    # whose default epoch is NOT J2000.0 / Terra-borrowed: ships with
    # Meton's summer solstice (27 Jun 432 BCE) as the default house
    # epoch, with four other Greek-historical alternatives via --epoch.
    from ephemerides_spectral.bridge import STLT_EPOCHS, STLT_DEFAULT_EPOCH
    _STLT_EPOCH_CHOICES = sorted(STLT_EPOCHS)

    ttl = sub.add_parser(
        "time-terra-luna",
        help="Sol Terra-Luna Time (STLT) at a JD — anchored Lunar time, synodic-month count",
        description=(
            "Convert JD (TDB) to Sol Terra-Luna Time (STLT) — anchored\n"
            "Lunar time using the synodic month (29.530589 days) as\n"
            "the natural unit. The 'Terra-Luna' in the name follows the\n"
            "moons-stuck-to-parent `Sol <Parent>-<Body> Time` convention.\n"
            "Saros (18.03 yr) and Metonic (19.00 yr) cycle counts come\n"
            "along for free.\n"
            "\n"
            "First Sol Time in the package whose DEFAULT epoch is not\n"
            "J2000.0 / Terra-borrowed. Default is Meton of Athens's\n"
            "summer solstice (27 June 432 BCE) — the calibration\n"
            "anchor of the Metonic cycle (235 synodic months ≈ 19\n"
            "tropical years). Greek mathematical astronomy's center of\n"
            "mass: the Hipparchus-Babylonian eclipse-archive midpoint\n"
            "lands within +240 days of Meton's solstice (same year).\n"
            "\n"
            "Available epochs (--epoch <name>):\n"
            "  meton        Meton's summer solstice 432 BCE  (default)\n"
            "  antikythera  Antikythera Saros eclipse 205 BCE\n"
            "  hipparchus   Hipparchus's lunar eclipse 141 BCE\n"
            "  mardokempad  Babylonian lunar eclipse 721 BCE\n"
            "  j2000        Modern reference (Terra-borrowed)\n"
            "\n"
            "DISTINCT from SLT (Luna's surface clock), Sol Lunar Time\n"
            "(Luna's phase observed from Terra), and STT (Terra's\n"
            "surface clock). STLT is the *system-level* (Sun-Terra-\n"
            "Luna pair) clock — natural home for eclipses, conjunctions,\n"
            "and Saros / Metonic cycle counts.\n"
            "\n"
            "House-epoch design choice; not a claim to be NASA's\n"
            "eventual LCT (Lunar Coordinated Time) standard.\n"
            "\n"
            "Use --synodic-count to invert."
        ),
        epilog=(
            "Examples:\n"
            "  # Default Meton epoch — synodic count from 432 BCE solstice\n"
            "  ephemerides-spectral time-terra-luna --jd 2451545.0\n\n"
            "  # Antikythera Saros anchor (Freeth & Jones 2012)\n"
            "  ephemerides-spectral time-terra-luna --jd 2451545.0 --epoch antikythera\n\n"
            "  # Modern J2000 reference\n"
            "  ephemerides-spectral time-terra-luna --jd 2451545.0 --epoch j2000\n\n"
            "  # Inverse: synodic count back to JD_TDB (Meton epoch)\n"
            "  ephemerides-spectral time-terra-luna --synodic-count 27294.31"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ttl_g = ttl.add_mutually_exclusive_group(required=True)
    ttl_g.add_argument("--jd", type=float, default=None,
                       help="JD (TDB) to convert to Sol Terra-Luna Time")
    ttl_g.add_argument("--synodic-count", dest="synodic_count", type=float, default=None,
                       help="Synodic-month count (since the chosen epoch) "
                            "to invert back to JD_TDB")
    ttl.add_argument("--epoch", choices=_STLT_EPOCH_CHOICES,
                     default=STLT_DEFAULT_EPOCH,
                     help=f"Historical anchor (default {STLT_DEFAULT_EPOCH!r})")
    _add_proper_flags(ttl)
    ttl.set_defaults(func=_cmd_time_terra_luna, subcommand_name="time-terra-luna")

    # time-proper (v0.11.0) — Sol Proper Time standalone rate-only query
    _SPRT_BODY_CHOICES = sorted(SUPPORTED_BODIES)
    tprop = sub.add_parser(
        "time-proper",
        help="Sol Proper Time (SPrT) rate at a body, vs. TCB / TDB",
        description=(
            "Compute the leading-order proper-time rate for a body's\n"
            "surface clock relative to TCB (barycentric coordinate time).\n"
            "\n"
            "Two components, both positive (clocks tick slower):\n"
            "  - gr_surface       = GM/(R*c²)         (gravitational well)\n"
            "  - kinematic_orbital = v_orb²/(2c²)     (SR time dilation)\n"
            "\n"
            "rate = 1 - gr_surface - kinematic_orbital\n"
            "\n"
            "With --compare-to <body>, returns the rate ratio + drift per\n"
            "Earth-year between two bodies — the most intuitive number for\n"
            "human comparison.\n"
            "\n"
            "Complementary to the --proper flag on every other time-*\n"
            "subcommand (which APPLIES the correction to a Sol Time count).\n"
            "Same physics, different surface."
        ),
        epilog=(
            "Examples:\n"
            "  # Mars surface vs. TCB — 3.38e-9 fractional rate (clocks slower).\n"
            "  ephemerides-spectral time-proper --body mars\n\n"
            "  # Sun surface — biggest dilation in the roster.\n"
            "  ephemerides-spectral time-proper --body sun\n\n"
            "  # Compare two bodies — Mars vs Terra: ~0.071 s/Earth-year.\n"
            "  ephemerides-spectral time-proper --body mars --compare-to terra\n\n"
            "  # With (lat, lon) — forward-compat for J2 oblateness (v0.11.0 ignores).\n"
            "  ephemerides-spectral time-proper --body terra --lat 51.5 --lon -0.1"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tprop.add_argument("--body", required=True, choices=_SPRT_BODY_CHOICES,
                       help="Body to query.")
    tprop.add_argument("--compare-to", dest="compare_to", default=None,
                       choices=_SPRT_BODY_CHOICES,
                       help="If set, return the rate ratio + drift "
                            "between --body and this body.")
    tprop.add_argument("--lat", type=float, default=None,
                       help="Surface latitude in degrees (forward-compat; "
                            "v0.11.0 ignores).")
    tprop.add_argument("--lon", type=float, default=None,
                       help="Surface longitude in degrees (forward-compat; "
                            "v0.11.0 ignores).")
    tprop.add_argument("--reference", choices=("tcb", "tdb"), default="tcb",
                       help="Reference time scale (default 'tcb').")
    tprop.set_defaults(func=_cmd_time_proper)

    # kinematics (v0.12.0) — Sol Kinematics standalone subcommand
    kine = sub.add_parser(
        "kinematics",
        help="Sol Kinematics — orbital state for one body or the full system",
        description=(
            "Compute mean orbital kinematic state — semi-major axis,\n"
            "orbital velocity, kinetic energy, angular momentum — for a\n"
            "single body or the full 38-body roster.\n"
            "\n"
            "v0.12.0 implements the circular-orbit Kepler-mean approximation\n"
            "from Kepler's third law (same math as `proper_time.py`'s\n"
            "kinematic-dilation term). Eccentricity / inclination corrections\n"
            "ship as v0.12.x refinements; per-JD evolution + force vectors +\n"
            "energy budgets ship as v0.13.0 *Dynamics*.\n"
            "\n"
            "Mirror of chess-spectral's `qm_2d.py`/`qm_4d.py` *kinematics*\n"
            "layer — static observables, no time-evolution.\n"
            "\n"
            "Validated against published NASA fact-sheet velocities for\n"
            "Mercury / Earth / Mars / Jupiter / Pluto to within 0.02-1.1 %\n"
            "and the Solar-System angular-momentum decomposition (Jupiter\n"
            "holds ~61 %; outer planets hold ~99.84 % of planet total)."
        ),
        epilog=(
            "Examples:\n"
            "  # Mars's mean orbital state\n"
            "  ephemerides-spectral kinematics --body mars\n\n"
            "  # Full system at J2000 with totals\n"
            "  ephemerides-spectral kinematics --all\n\n"
            "  # Specific JD (currently no-op — v0.12.0 uses mean elements)\n"
            "  ephemerides-spectral kinematics --body terra --jd 2451545.0\n\n"
            "  # Pair-centric frame (moons; v0.12.0 same elements as default)\n"
            "  ephemerides-spectral kinematics --body luna --frame parent_centric"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    kine.add_argument("--body", choices=_BODY_CHOICES, default=None,
                      help="Body to query (omit if using --all).")
    kine.add_argument("--all", action="store_true",
                      help="Return state for every body in the 38-body "
                           "roster, plus system-level totals.")
    kine.add_argument("--jd", type=float, default=None,
                      help="JD (TDB) — accepted for forward compat; "
                           "v0.12.0 uses mean orbital elements regardless.")
    kine.add_argument("--frame",
                      choices=("heliocentric_ecliptic", "parent_centric"),
                      default="heliocentric_ecliptic",
                      help="Reference frame (default 'heliocentric_ecliptic').")
    kine.set_defaults(func=_cmd_kinematics)

    # dynamics (v0.13.0) — Sol Dynamics standalone subcommand
    dyn = sub.add_parser(
        "dynamics",
        help="Sol Dynamics — system energy budget, per-body energies, or pair forces",
        description=(
            "Three query modes selected by which flags you pass:\n"
            "\n"
            "  default       System aggregate: total KE + PE + total E,\n"
            "                is_bound, angular-momentum partitions\n"
            "                (Jupiter holds ~61.5%, outer planets ~99.84%).\n"
            "\n"
            "  --body X      That body's energy budget: KE + PE + total E.\n"
            "                Heliocentric PE for Sol-orbiting bodies;\n"
            "                parent-centric PE for moons.\n"
            "\n"
            "  --body X --from Y\n"
            "                Newtonian gravitational force ON body X FROM body Y.\n"
            "                v0.13.0 reports magnitude only; 3D vectors\n"
            "                queued for v0.13.x with the position decoder.\n"
            "\n"
            "Mirror of chess-spectral's `qm_*_dynamics.py` *dynamics*\n"
            "layer — Hamiltonian + evolution + force / energy queries.\n"
            "Counterpart to v0.12.0's Sol Kinematics.\n"
            "\n"
            "Validated against published Solar-System totals: total\n"
            "energy < 0 (system bound), Earth-Sun force ≈ 3.54e22 N at\n"
            "1 AU, Sun KE / Mc² ≈ 8.6e-16."
        ),
        epilog=(
            "Examples:\n"
            "  # System totals\n"
            "  ephemerides-spectral dynamics\n\n"
            "  # Mars's energy budget\n"
            "  ephemerides-spectral dynamics --body mars\n\n"
            "  # Force on Mars from Jupiter\n"
            "  ephemerides-spectral dynamics --body mars --from jupiter\n\n"
            "  # Earth-Sun force (validation reference)\n"
            "  ephemerides-spectral dynamics --body terra --from sun"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    dyn.add_argument("--body", choices=_BODY_CHOICES, default=None,
                     help="Body to query (omit for system aggregate).")
    dyn.add_argument("--from", dest="from_body",
                     choices=_BODY_CHOICES, default=None,
                     help="If set with --body, return force on body from this body.")
    dyn.add_argument("--jd", type=float, default=None,
                     help="JD (TDB) — accepted for forward compat; v0.13.0 "
                          "uses mean orbital elements regardless.")
    dyn.add_argument("--frame",
                     choices=("heliocentric_ecliptic", "parent_centric"),
                     default="heliocentric_ecliptic",
                     help="Reference frame (default 'heliocentric_ecliptic').")
    dyn.set_defaults(func=_cmd_dynamics)

    # find-tubes (v0.8.1) — ITN pathway / Lagrange-tube query
    ft = sub.add_parser(
        "find-tubes",
        help="ITN pathway query: enumerate Hohmann transfer windows in a JD range",
        description=(
            "Enumerate launch windows in [from-jd, to-jd] (TDB) for a\n"
            "Hohmann transfer from `--departure` to `--target`. Mirrors\n"
            "find-syzygies's discipline: closed-form synodic-period\n"
            "enumeration anchored at the Hohmann launch geometry, no\n"
            "encoder calls.\n"
            "\n"
            "First-cut implementation. Future versions add low-energy /\n"
            "heteroclinic-tube candidates under the same surface; the\n"
            "transfer_kind field reserves room for them ('hohmann' for\n"
            "now). The user-friendly framing: 'surfing the perturbations'\n"
            "via the Solar System's natural cyclic structure.\n"
            "\n"
            "References:\n"
            "  - Koon, Lo, Marsden, Ross 2011 (the canonical ITN text)\n"
            "  - Lo's Genesis spacecraft trajectory work (1997)"
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral find-tubes --from-jd 2451545.0 --to-jd 2470000.0 \\\n"
            "      --departure terra --target mars\n"
            "  # All Mars windows in J2000 + 50yr at default tight (3.6deg) threshold\n"
            "\n"
            "  ephemerides-spectral find-tubes --from-jd 2452000.0 --to-jd 2456000.0 \\\n"
            "      --departure terra --target jupiter --threshold 0.05\n"
            "  # Terra->Jupiter windows, looser 9deg threshold"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ft.add_argument("--from-jd", dest="from_jd", type=float, required=True,
                    help="Window start in JD (TDB)")
    ft.add_argument("--to-jd", dest="to_jd", type=float, required=True,
                    help="Window end in JD (TDB)")
    ft.add_argument("--departure", required=True,
                    help="Departure body name (e.g. terra, mars)")
    ft.add_argument("--target", required=True,
                    help="Target body name (e.g. mars, jupiter)")
    ft.add_argument("--threshold", type=float, default=0.02,
                    help="Phase residual cutoff in (0, 1]; |residual|/pi. "
                         "0.02 = ~3.6 deg tight; 0.05 = ~9 deg looser. "
                         "Default 0.02.")
    ft.add_argument("--max-candidates", dest="max_candidates",
                    type=int, default=1000,
                    help="Max candidates returned (safety cap)")
    ft.set_defaults(func=_cmd_find_tubes)

    # lunar-kernels
    lk = sub.add_parser(
        "lunar-kernels",
        help="Lunar-time / lunar-orientation kernel metadata (LTE440, etc.)",
        description=(
            "v0.3.0 ships *awareness* of LTE440 (Lin et al. 2025) "
            "— SPICE-format Lunar Time Ephemeris on DE440, accuracy "
            "0.15 ns through 2050. The kernel must be staged "
            "separately (github.com/xlucn/LTE440 releases); "
            "ephemerides-spectral does not auto-download. When LTC "
            "(Lunar Coordinated Time) is finalised by NASA + "
            "international agencies, this command becomes the "
            "runtime surface for LTC <-> UTC <-> JD_TDB."
        ),
    )
    lk.set_defaults(func=_cmd_lunar_kernels)

    # natural-group
    ng = sub.add_parser(
        "natural-group",
        help="Resonance-derived natural cyclic group (LCM, CRT prime factorisation)",
        description=(
            "Reads the Phase 9 RESONANCES table and returns the natural "
            "cyclic group the resonances themselves demand — distinct "
            "from the encoder's architectural Z_{2^32} modulus. For "
            "each pair (n_a, m_b) the per-pair natural cycle is "
            "lcm(n_a, m_b); the aggregate is LCM across pairs. By CRT "
            "the aggregate factors into prime cyclic groups: those are "
            "the natural coprimes the resonance topology lives in. "
            "See research notebook §6 for the full discussion + the "
            "connection to chess-spectral's non-Markovian sheaf."
        ),
        epilog=(
            "On the v0.3.0 four-resonance set:\n"
            "  J-S 5:2 -> lcm(5,2)=10\n"
            "  N-P 3:2 -> lcm(3,2)=6\n"
            "  Io-Eu 2:1 -> lcm(2,1)=2\n"
            "  Eu-Ga 2:1 -> lcm(2,1)=2\n"
            "  Aggregate: lcm(10, 6, 2, 2) = 30 = 2 x 3 x 5"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ng.set_defaults(func=_cmd_natural_group)

    # find-syzygies (v0.3.1)
    fs = sub.add_parser(
        "find-syzygies",
        help="Spectral-native syzygy window search (HDC-native; not encode-then-check)",
        description=(
            "Enumerates candidate syzygies in a JD window in closed "
            "form by walking new/full moon multiples of the synodic "
            "month + confirming against the draconic-month phase. "
            "Replaces the v0.3.0 point-evaluation `eclipse --jd` "
            "pattern for window searches: cost goes from O(window_days "
            "× encode) to O(n_syzygies × confirmation), typically "
            "100-1000× faster for multi-decade windows since syzygies "
            "are rare events on the calendar (~5/yr combined solar+lunar)."
        ),
        epilog=(
            "Example: find solar/lunar syzygies in 2024 (UTC ≈ JD 2460311 to 2460676):\n"
            "  ephemerides-spectral find-syzygies --from-jd 2460311 --to-jd 2460676\n\n"
            "For arc-second-class precision (totality, location, partial-vs-total)\n"
            "confirm each returned candidate against a JPL ephemeris via skyfield."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    fs.add_argument("--from-jd", dest="from_jd", type=float, required=True,
                    help="Window lower bound in JD (TDB)")
    fs.add_argument("--to-jd", dest="to_jd", type=float, required=True,
                    help="Window upper bound in JD (TDB)")
    fs.add_argument("--kind", choices=["solar", "lunar", "all"], default="all",
                    help="Syzygy kind filter (default 'all')")
    fs.add_argument("--threshold", type=float, default=0.05,
                    help=("Score cutoff [0, 0.5]; 0.05 ≈ total-class "
                          "(default), 0.1 ≈ partial-class"))
    fs.set_defaults(func=_cmd_find_syzygies)

    # patches (v0.4.0+) — runtime kernel-patching surface
    pp = sub.add_parser(
        "patches",
        help="Diagnosed-fiber runtime overlay (v0.4.0+). Apply / list / clear "
             "Fourier corrections without mutating the published kernel.",
        description=(
            "Diagnosed-fiber patches are runtime overlays on the spectral "
            "kernel: DATA, not code edits, summed onto the encoded phases "
            "AFTER the base encode loop. The published kernel bytes never "
            "change.\n\n"
            "Both backends apply the overlay (v0.4.1 native ABI v2 + "
            "Python BIP). With v0.5.2's CATALOG_V2 (LS-fit, vindicated), "
            "Mars/Mercury/Jupiter-Saturn patches drop their targeted FFT "
            "residual peak by >=96%. Six total patches in the bundled "
            "catalogs (3 v0.4.0 magnitude-only + 3 v0.5.2 LS-fit `-v2`)."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral patches catalog\n"
            "  ephemerides-spectral patches apply --name jupiter-saturn-9.56yr-coupled-v2\n"
            "  ephemerides-spectral patches active\n"
            "  ephemerides-spectral patches clear\n\n"
            "Use `patches <op> --help` for sub-command detail."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pp_sub = pp.add_subparsers(dest="patch_cmd", required=True,
                                title="Patch operations", metavar="<op>")

    pp_catalog = pp_sub.add_parser(
        "catalog",
        help="List the bundled diagnosed-fiber patch catalog.",
        description=(
            "Each entry includes name + kind + targeted body / coupling, "
            "amplitude (deg), period (days), phase (rad), and free-text "
            "notes describing the suspected missing physics + (for v0.5.2 "
            "`-v2` entries) the measured shrinkage% of the targeted FFT "
            "residual peak."
        ),
        epilog=(
            "Example:\n"
            "  ephemerides-spectral patches catalog\n\n"
            "The combined catalog has 6 entries:\n"
            "  v0.4.0 (magnitude-only authoring; superseded):\n"
            "    mars-7.96yr-diagonal\n"
            "    mercury-10.69yr-diagonal\n"
            "    jupiter-saturn-9.56yr-coupled\n"
            "  v0.5.2 (LS-fit, measured-vindicated):\n"
            "    mars-7.96yr-diagonal-v2              99.2% shrinkage\n"
            "    mercury-10.69yr-diagonal-v2          99.9% shrinkage\n"
            "    jupiter-saturn-9.56yr-coupled-v2     97.6% / 96.0% (J / S)"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pp_catalog.set_defaults(func=_cmd_patches_catalog)

    pp_active = pp_sub.add_parser(
        "active",
        help="List the currently-active runtime patches.",
        description=(
            "Patches are an in-process registry; they don't persist "
            "across interpreter restarts. Each fresh `python` invocation "
            "starts with no active patches."
        ),
        epilog=(
            "Example:\n"
            "  ephemerides-spectral patches active"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pp_active.set_defaults(func=_cmd_patches_active)

    pp_apply = pp_sub.add_parser(
        "apply",
        help="Load a named CATALOG patch into the overlay registry.",
        description=(
            "Same patch cannot be applied twice — clear first if you mean "
            "to replace it. The patch is mirrored into both the Python "
            "BIP registry and the C-side native registry (ABI v2); "
            "byte-for-byte identical phases on both backends."
        ),
        epilog=(
            "Examples:\n"
            "  ephemerides-spectral patches apply --name mars-7.96yr-diagonal-v2\n"
            "  ephemerides-spectral patches apply --name jupiter-saturn-9.56yr-coupled-v2\n\n"
            "Use `patches catalog` to see all available patch names."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pp_apply.add_argument("--name", required=True,
                          help="Catalog patch name (use `patches catalog` to list)")
    pp_apply.set_defaults(func=_cmd_patches_apply)

    pp_clear = pp_sub.add_parser(
        "clear",
        help="Remove every active runtime patch.",
        description=(
            "Wipes both the Python BIP registry and the C-side native "
            "registry. After this the encoder is byte-identical to the "
            "published kernel (no overlay deltas applied)."
        ),
        epilog=(
            "Example:\n"
            "  ephemerides-spectral patches clear"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pp_clear.set_defaults(func=_cmd_patches_clear)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = _make_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
