"""Version information for xeries."""

__version__ = "0.2.1"
