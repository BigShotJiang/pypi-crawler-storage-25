"""Durability backends for the AbstractFlow web backend.

The web host should leverage AbstractRuntime's file-based stores so:
- Runs can be inspected and controlled (pause/resume/cancel) by run_id.
- Time-based waits have durable semantics across longer sessions.

Tests use an isolated temp directory to avoid cross-test interference.
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Tuple

from .paths import resolve_runtime_dir


_IS_TEST = bool(os.getenv("PYTEST_CURRENT_TEST") or "pytest" in sys.modules)
_TEST_BASE_DIRS: dict[str, Path] = {}


def _base_dir_for_call() -> Path:
    # Isolate each test run to avoid cross-test interference (events scan the run store).
    if _IS_TEST:
        # IMPORTANT:
        # Multiple backend calls inside a single pytest test often need to see the same stores
        # (e.g. create run -> query run). Keep isolation *per test* but stable within a test.
        key = str(os.getenv("PYTEST_CURRENT_TEST") or "").strip()
        if key:
            base = _TEST_BASE_DIRS.get(key)
            if base is None:
                base = Path(tempfile.mkdtemp(prefix="abstractflow-runtime-"))
                base.mkdir(parents=True, exist_ok=True)
                _TEST_BASE_DIRS[key] = base
            return base

        base = Path(tempfile.mkdtemp(prefix="abstractflow-runtime-"))
        base.mkdir(parents=True, exist_ok=True)
        return base
    return resolve_runtime_dir()


def get_runtime_stores() -> Tuple[Any, Any, Any]:
    """Return (run_store, ledger_store, artifact_store)."""
    from abstractruntime import FileArtifactStore, JsonFileRunStore, JsonlLedgerStore, ObservableLedgerStore

    base = _base_dir_for_call()
    run_store = JsonFileRunStore(base)
    ledger_store = ObservableLedgerStore(JsonlLedgerStore(base))
    artifact_store = FileArtifactStore(base)
    return (run_store, ledger_store, artifact_store)
