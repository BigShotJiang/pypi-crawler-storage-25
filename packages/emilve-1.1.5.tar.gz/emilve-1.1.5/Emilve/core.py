# Emilve/core.py
import sys, builtins, inspect, re

class CaseSensivity:
    def __init__(self, Active=True):
        self.Active = Active

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self.Active and exc_type is NameError:
            frame = exc_tb.tb_frame
            linea_codigo = inspect.getinnerframes(exc_tb)[-1].code_context[0].strip()
            
            mapa_existencias = {n.lower(): n for n in frame.f_locals.keys()}
            for n in dir(builtins):
                mapa_existencias[n.lower()] = n

            palabras = re.findall(r'\b\w+\b', linea_codigo)
            linea_corregida = linea_codigo
            
            for p in palabras:
                if p.lower() in mapa_existencias:
                    nombre_real = mapa_existencias[p.lower()]
                    if p != nombre_real:
                        linea_corregida = re.sub(rf'\b{p}\b', nombre_real, linea_corregida)

            if linea_corregida != linea_codigo:
                for p in palabras:
                    if p.lower() in mapa_existencias:
                        nombre_real = mapa_existencias[p.lower()]
                        if nombre_real in frame.f_locals:
                            frame.f_locals[p] = frame.f_locals[nombre_real]
                        elif hasattr(builtins, nombre_real):
                            frame.f_locals[p] = getattr(builtins, nombre_real)

                exec(linea_corregida, frame.f_globals, frame.f_locals)
                return True
        return False