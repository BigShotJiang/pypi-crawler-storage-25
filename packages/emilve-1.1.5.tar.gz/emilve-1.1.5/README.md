﻿# Emilve 🚀
**Developed by Emiliano (emicicx)**

A library designed to break traditional Python rules and improve developer efficiency.

## Features:
* **AutoPip**: Detects missing libraries, installs them, and restarts the script automatically.
* **Braces**: Enables the use of curly braces `{}` to define code blocks.
* **CaseSensivity**: Ignores Case Sensitivity errors in functions and variables.

## Installation:
pip install Emilve

Perfecto, Emiliano. Si quieres que tu librería se vea profesional en PyPI, el inglés es el estándar de oro para que gente de todo el mundo la descargue. He ajustado el setup.py para que sea serio, pero con ese toque personal al final para que sepan de dónde viene el autor de esta locura.

Como no quieres usar GitHub, simplemente omitiremos la URL en el archivo de configuración.

Aquí tienes los archivos listos para tu Evolve Maestro:

1. setup.py (The Configuration)
Python
from setuptools import setup, find_packages

setup(
    name="Emilve", 
    version="1.1.0",
    author="Emiliano",
    description="A library to hack Python syntax: Case Sensitivity, Braces, and Auto-Installation.",
    long_description="Emilve allows you to use curly braces {}, ignore case sensitivity in functions/variables, and automatically install missing dependencies.",
    long_description_content_type="text/plain",
    # No GitHub URL as requested
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
    ],
    python_requires='>=3.6',
    include_package_data=True,
)
2. README.md (The Documentation)
Este es el archivo que se lee cuando alguien busca tu librería en PyPI. He puesto la nota que querías al final.

Markdown
# Emilve 🚀
**Developed by Emiliano (emicicx)**

A library designed to break traditional Python rules and improve developer efficiency.

## Features:
* **AutoPip**: Detects missing libraries, installs them, and restarts the script automatically.
* **Braces**: Enables the use of curly braces `{}` to define code blocks.
* **CaseSensivity**: Ignores Case Sensitivity errors in functions and variables.

## Installation:
```bash
pip install Emilve

## Quick Start:
Python
from Emilve import AutoPip, Braces, CaseSensivity

# The monitor activates automatically upon import
import Emilve.AutoPip

# Use braces and forget about Shift keys
with CaseSensivity(Active=False):
    with Braces("""
    def greet() {
        PrInT("Hello from Emilve!")
    }
    greet()
    """):
        pass
		
(In reality, I speak Spanish!)