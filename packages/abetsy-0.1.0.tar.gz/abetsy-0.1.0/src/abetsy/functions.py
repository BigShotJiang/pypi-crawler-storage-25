"""Functions that print the content of each corresponding file."""

_CONTENT_12 = """\
seats = [20, 8, 14, 3, 18, 8, 30, 17, 6, 12, 29, 21, 5, 19, 11, 3, 27, 14, 2, 24, 18, 9, 30, 16, 7, 23, 1, 10, 28, 4]

now_seats = set(seats)

miss_seats = []

for i in range(1,31):
    if i not in now_seats:
        miss_seats.append(i)

print('目前的座位', now_seats)
print('缺少的座位', miss_seats)"""

_CONTENT_13 = """\
import os
from PIL import Image

input_path = '/vol1/@appshare/fn-codeserver/Betsy/case_13/image'
output_path = '/vol1/@appshare/fn-codeserver/Betsy/case_13/output'
for filename in os.listdir(input_path):
    if filename.lower().endswith('.png'):
        image_path = os.path.join(input_path,filename)
        with Image.open(image_path) as img:
            if img.size != (25,23):
                continue
            output_Img = os.path.join(output_path,filename)
            img.save(output_Img)"""

_CONTENT_17 = """\
大纲
1. 数据标注概述
定义、作用、在AI模型训练中的地位
2. 数据标注分类
图像、语音、文本、视频等标注类型详解
3. 数据标注常用工具与技术
主流工具（如LabelImg、CVAT）操作演示，AI辅助标注介绍
4. 数据标注流程和管理
四大流程（采集→清洗→标注→质检）全流程讲解
5. 数据标注的质量管理
质检标准、错误类型识别、一致性控制方法
6. 数据标注的实践应用
图灵测试、机器视觉、语义识别处理


参考
1. 理解数据标注（基础认知）
明确数据标注是什么，以及它在AI系统中的位置。
不仅是知道定义，更要理解它对机器学习模型效果的决定性作用——垃圾进，垃圾出（Garbage in, garbage out）。
2. 设定标注目标（方向确立）
在开始标注前，必须先定下"规矩"。
如何根据项目需求设定清晰的目标，并据此定义出具体的标注依据和要求。这决定了后续所有工作的标准。
3. 协商标注类别（标准细化）
把模糊的任务转化为明确的分类标准。
探讨不同的分类选项，并给出具体的示例（如对象类别、属性值、文本内容怎么标），确保团队对"标什么"没有歧义。
4. 数据集收集策略（素材准备）
标注的前提是有数据，数据的质量直接决定标注的上限。
不仅要有收集高质量数据的方法，还要考虑如何通过扩展数据集来提升最终结果的可靠性（可能涉及数据增强或扩充）。
5. 标注工具与技术（手段选择）
工欲善其事，必先利其器。
了解市面上常用的工具和技术，并能根据当前项目的特性（如图像、文本、视频）选择最合适的工具和模板。
6. 监控标注质量（过程控制）
标注过程中不能"放羊"，需要随时纠偏。
建立有效的质量监控流程，发现问题后提出改进措施并落实，这是一个PDCA（计划-执行-检查-行动）的闭环。
7. 结果评估与优化（收尾与迭代）
标注完成后的验收与总结。
建立评估标准来验证标注结果的有效性，并掌握确保准确性和有效性的技巧，为未来的项目积累经验。
"""

_CONTENT_29 = """\
import torch.nn as nn

# 根据下方搭建的模型框架, 补全神经网络

class MyNet(nn.Module):
    def __init__(self):
        super(MyNet, self).__init__()
        self.l1 = nn.Linear(X.shape[1], 128)
        self.l2 = nn.Linear(128, 256)
        self.l3 = nn.Linear(256, 1)

        self.b1 = nn.BatchNorm1d(128)
        self.b2 = nn.BatchNorm1d(256)

    def forward(self, x):
        out = self.l1(x)
        out = self.b1(out)
        out = torch.relu(out)

        out = self.l2(out)
        out = self.b2(out)
        out = torch.relu(out)

        out = self.l3(out)

        return out


model = MyNet()"""

_CONTENT_35 = """\
#读取数据并划分数据集
fd = pd.read_csv('/vol1/@appshare/fn-codeserver/Anorak/case_35/diabetes_data.csv')
X = fd.loc[:,fd.columns != 'label']
Y = fd['label']

X = X.to_numpy()
X = torch.from_numpy(X)
X = X.to(torch.float32)

Y = Y.to_numpy()
Y = torch.from_numpy(Y.copy())
Y = Y.to(torch.int64)

X = X.view((-1,28,28))
X = X[:,torch.newaxis,:,:]
X = X / 255

class CosmicDataset(torch.utils.data.Dataset):
    def __init__(self):
        pass
    def __len__(self):
        return len(X)
    def __getitem__(self, index):
        return X[index], Y[index]
n = len(X)
n1 = int(n * 0.7)
n2 = n - n1
train, test = random_split(CosmicDataset(), (n1, n2))



import torch.nn as nn

class MyNet(nn.Module):
    def __init__(self):
        super(MyNet, self).__init__()
        self.c1 = nn.Conv2d(1, 32, 7, 2, 3)
        self.b1 = nn.BatchNorm2d(32)

        self.c2 = nn.Conv2d(32, 64, 5, 2, 2)
        self.b2 = nn.BatchNorm2d(64)

        self.L1 = nn.Linear(3136, 10)

    def forward(self, x):
        out = self.c1(x)
        out = self.b1(out)
        out = torch.relu(out)

        out = self.c2(out)
        out = self.b2(out)
        out = torch.relu(out)

        out = torch.flatten(out, start_dim=1)
        out = self.L1(out)

        return out

model = MyNet()"""

_CONTENT_42 = """\
# 怎么去划分训练和测试的数据集
folder = ImageFolder('',tranform = trans_compose)
n = len(folder.imgs)
n1 = int(n*0.8)
n2 = n-n1
train,test = random_split(folder,(n1,n2))


import torchmetrics

# 如何进行模型的训练和评估
lossf = nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
metricf = torchmetrics.Accuracy(task='multiclass', num_classes=len(folder.classes))

for i in range(1):
    for batchX, batchY in data_loader:
        score = model(batchX)
        score = torch.squeeze(score)
        loss = lossf(score,batchY)

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        metricsf(score,batchY)
        print(loss,metricsf.compute())
        metricsf.reset()

torch.save(model,'model_demo.pth')"""


def _12():
    """Print the content of file 12."""
    print(_CONTENT_12)


def _13():
    """Print the content of file 13."""
    print(_CONTENT_13)


def _17():
    """Print the content of file 17."""
    print(_CONTENT_17)


def _29():
    """Print the content of file 29."""
    print(_CONTENT_29)


def _35():
    """Print the content of file 35."""
    print(_CONTENT_35)


def _42():
    """Print the content of file 42."""
    print(_CONTENT_42)
