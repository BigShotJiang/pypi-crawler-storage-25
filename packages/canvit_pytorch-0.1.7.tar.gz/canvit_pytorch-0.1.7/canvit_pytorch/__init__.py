"""CanViT: Dual-stream vision transformer with canvas cross-attention."""

from canvit_pytorch.backbone import BackboneName, ViTBackbone, create_backbone
from canvit_pytorch.model import (
    CanViT,
    CanViTConfig,
    CanViTForImageClassification,
    CanViTForPretraining,
    CanViTForPretrainingConfig,
    CanViTForPretrainingHFHub,
    CanViTOutput,
    RecurrentState,
    fuse_probe,
)
from canvit_pytorch.standardizers import CLSStandardizer, PatchStandardizer, PositionAwareStandardizer
from canvit_pytorch.viewpoint import Viewpoint, sample_at_viewpoint
from canvit_pytorch.vpe import VPEEncoder

__all__ = [
    "BackboneName",
    "CLSStandardizer",
    "CanViT",
    "CanViTConfig",
    "CanViTForImageClassification",
    "CanViTForPretraining",
    "CanViTForPretrainingConfig",
    "CanViTForPretrainingHFHub",
    "CanViTOutput",
    "PatchStandardizer",
    "PositionAwareStandardizer",
    "RecurrentState",
    "VPEEncoder",
    "Viewpoint",
    "ViTBackbone",
    "create_backbone",
    "fuse_probe",
    "sample_at_viewpoint",
]
