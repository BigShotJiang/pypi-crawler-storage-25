"""
refinex-mcp — MCP server for the RefineX spot signal API.

Wraps https://refinex-api.onrender.com as MCP tools for Claude Code / Cursor.

Public tools (no API key required):
  - get_live_signal       → /v1/signals/now
  - get_suppression_log   → /v1/signals/public
  - get_health            → /v1/health

Authenticated tools (require REFINEX_API_KEY env var):
  - list_signals          → /v1/signals
  - get_signal_for_instance → /v1/signals/active
  - get_signals_summary   → /v1/signals/summary

Claude Code config (~/.claude/settings.json):
  {
    "mcpServers": {
      "refinex": {
        "command": "refinex-mcp",
        "env": {
          "REFINEX_API_KEY": "your-key-here"
        }
      }
    }
  }

Without an API key, get_live_signal and get_suppression_log still work —
no credentials needed to see real AWS spot data.
"""

import os
import httpx
from mcp.server.fastmcp import FastMCP

BASE_URL = os.environ.get("REFINEX_API_BASE_URL", "https://refinex-api.onrender.com")
API_KEY = os.environ.get("REFINEX_API_KEY", "")

mcp = FastMCP(
    "refinex",
    instructions=(
        "RefineX delivers AWS spot price arbitrage signals with deterministic confidence "
        "scoring and a public suppression log. "
        "get_live_signal and get_suppression_log work without an API key — use them first. "
        "For list_signals, get_signal_for_instance, and get_signals_summary set "
        "REFINEX_API_KEY in your MCP environment config. "
        "Every signal has a confidence score (0.0–1.0) and a TTL in minutes. "
        "RefineX suppresses more than it fires — suppressed_last_6h tells you what "
        "was detected but held back."
    ),
)


def _auth_headers() -> dict:
    h = {"Accept": "application/json"}
    if API_KEY:
        h["X-API-Key"] = API_KEY
    return h


def _require_key() -> str | None:
    if not API_KEY:
        return (
            "REFINEX_API_KEY not set. "
            'Add it to your MCP config: { "env": { "REFINEX_API_KEY": "your-key" } }. '
            "You can still call get_live_signal or get_suppression_log without a key."
        )
    return None


@mcp.tool()
def get_live_signal() -> dict:
    """
    Get the single best active AWS spot arbitrage signal right now.
    No API key required.

    Returns the highest-confidence active signal including:
    - action: "buy_spot" | "migrate_spot" | "wait" | "use_on_demand"
    - cloud, region, availability_zone, instance_type
    - spot_price_usd, on_demand_price_usd, discount_pct
    - confidence (0.0–1.0, deterministic — no LLM scoring)
    - ttl_minutes: how long this signal is valid
    - suppressed_last_6h: signals detected but held back in last 6 hours
    - signal_id: use this to reference a specific signal

    If no signal clears the confidence threshold, returns action="use_on_demand"
    with a rationale. suppressed_last_6h will still be populated.

    This is the fastest way to get real AWS spot data — zero credentials needed.
    """
    with httpx.Client(timeout=10) as client:
        r = client.get(f"{BASE_URL}/v1/signals/now")
        r.raise_for_status()
        return r.json()


@mcp.tool()
def get_suppression_log(limit: int = 20) -> dict:
    """
    Get the RefineX suppression log — a mix of delivered and suppressed signals.
    Shows what RefineX fired vs. what it held back and why.
    No API key required.

    Args:
        limit: Number of signals to return (1–20, default 20)

    Returns:
    - signals[]: each has region, instance_type, confidence, savings_pct, action,
                 suppressed (bool), suppression_reason
    - count: total signals returned
    - delivered: signals that cleared the confidence threshold
    - suppressed: signals that were detected but held back
    - suppression_rate: percentage suppressed (e.g. 65.0 means 65% held back)

    Suppression reasons: "confidence_below_threshold", "stale_data", "ttl_expired".
    A high suppression rate is intentional — discipline is the product.
    """
    with httpx.Client(timeout=10) as client:
        r = client.get(
            f"{BASE_URL}/v1/signals/public",
            params={"limit": min(limit, 20)},
        )
        r.raise_for_status()
        return r.json()


@mcp.tool()
def get_health() -> dict:
    """
    Get RefineX API health and last AWS data ingestion timestamp.
    No API key required.

    Returns:
    - status: "healthy" | "degraded"
    - version: API version string
    - timestamp: current server time (UTC ISO-8601)
    - clouds.aws.status: "active" | "degraded"
    - clouds.aws.last_ingestion: ISO-8601 timestamp of last AWS price poll
    - clouds.aws.realtime: true (live AWS data as of 2026-03-26)

    Use this to verify real-time data is flowing before making infrastructure
    decisions. If aws.status is "degraded", last_ingestion is >10 minutes old.
    """
    with httpx.Client(timeout=10) as client:
        r = client.get(f"{BASE_URL}/v1/health")
        r.raise_for_status()
        return r.json()


@mcp.tool()
def list_signals(
    cloud: str = "aws",
    region: str = None,
    instance_type: str = None,
    confidence_min: float = 0.0,
    page: int = 1,
    limit: int = 50,
) -> dict:
    """
    List active spot arbitrage signals with optional filters.
    Requires REFINEX_API_KEY env var.

    Args:
        cloud: Cloud provider — "aws", "gcp", or "azure" (default: "aws")
        region: Filter by region, e.g. "us-east-1", "us-west-2" (optional)
        instance_type: Filter by EC2 type, e.g. "m6i.large", "c7g.xlarge" (optional)
        confidence_min: Minimum confidence score 0.0–1.0 (default: 0.0)
        page: Page number (default: 1)
        limit: Results per page, max 500 (default: 50)

    Returns:
    - signals[]: each has signal_id, type, source{cloud, region, az},
                 asset{instance_type, spot_price, on_demand_price},
                 action, expected_value{savings_percent}, confidence, ttl, expires_at
    - count: signals on this page
    - page, total_pages, next: pagination info
    """
    err = _require_key()
    if err:
        return {"error": err}

    params: dict = {
        "cloud": cloud,
        "confidence_min": confidence_min,
        "page": page,
        "limit": limit,
    }
    if region:
        params["region"] = region
    if instance_type:
        params["instance_type"] = instance_type

    with httpx.Client(timeout=10) as client:
        r = client.get(
            f"{BASE_URL}/v1/signals",
            params=params,
            headers=_auth_headers(),
        )
        r.raise_for_status()
        return r.json()


@mcp.tool()
def get_signal_for_instance(
    cloud: str,
    region: str,
    instance_type: str,
    fallback: str = "on_demand",
) -> dict:
    """
    Get the single best spot action for a specific cloud/region/instance type.
    Optimized for autoscalers that need one clear, deterministic action.
    Requires REFINEX_API_KEY env var.

    Args:
        cloud: Cloud provider — "aws", "gcp", or "azure"
        region: AWS region, e.g. "us-east-1", "us-west-2", "eu-west-1"
        instance_type: EC2 instance type, e.g. "m6i.large", "c7g.xlarge", "t3.medium"
        fallback: What to return when no signal exists —
                  "on_demand" (default), "wait", or "none"

    Returns:
    - action: "buy_spot" | "migrate_spot" | "wait" | "use_on_demand"
    - signal{}: full signal detail for the chosen action
    - alternatives[]: other AZs for the same instance type, with their prices/confidence

    Use fallback="on_demand" in CI/CD pipelines so you always get a safe default.
    Use fallback="wait" in cost-sensitive batch jobs.
    """
    err = _require_key()
    if err:
        return {"error": err}

    with httpx.Client(timeout=10) as client:
        r = client.get(
            f"{BASE_URL}/v1/signals/active",
            params={
                "cloud": cloud,
                "region": region,
                "instance_type": instance_type,
                "fallback": fallback,
            },
            headers=_auth_headers(),
        )
        r.raise_for_status()
        return r.json()


@mcp.tool()
def get_signals_summary(
    cloud: str = None,
    region: str = None,
    min_savings: float = 50.0,
    confidence_min: float = 0.80,
) -> dict:
    """
    Get aggregate summary of current AWS spot opportunities.
    Requires REFINEX_API_KEY env var.

    Args:
        cloud: Filter by cloud provider (optional)
        region: Filter by region (optional)
        min_savings: Minimum savings % to include in summary (default: 50.0)
        confidence_min: Minimum confidence score (default: 0.80)

    Returns:
    - summary{total_signals, spot_arbitrage, interruption_risk,
               avg_savings_percent, avg_confidence}
    - by_cloud{aws: {signals, avg_savings_percent, top_instance_types[]}}
    - ttl: cache validity in seconds
    - next_update: ISO-8601 timestamp when summary refreshes

    Use this for dashboards or periodic CI checks:
    "How many high-confidence deals exist right now, and in which regions?"
    """
    err = _require_key()
    if err:
        return {"error": err}

    params: dict = {
        "min_savings": min_savings,
        "confidence_min": confidence_min,
    }
    if cloud:
        params["cloud"] = cloud
    if region:
        params["region"] = region

    with httpx.Client(timeout=10) as client:
        r = client.get(
            f"{BASE_URL}/v1/signals/summary",
            params=params,
            headers=_auth_headers(),
        )
        r.raise_for_status()
        return r.json()


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
