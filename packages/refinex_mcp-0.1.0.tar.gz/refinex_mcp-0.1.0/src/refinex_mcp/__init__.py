"""refinex-mcp — MCP server for the RefineX spot signal API."""

__version__ = "0.1.0"
