"""Application context that carries gateways through the Click command tree."""

from __future__ import annotations

from dataclasses import dataclass

from nonslop.gateways.gh.gateway import GhCli
from nonslop.gateways.npx_skills.gateway import NpxSkills


@dataclass
class NonslopContext:
    """Container for nonslop's external-tool gateways.

    Production code constructs this with real gateways in ``cli.main``.
    Tests construct it with fake gateways and pass it to
    ``CliRunner.invoke(..., obj=ctx)``.
    """

    gh: GhCli
    npx_skills: NpxSkills
