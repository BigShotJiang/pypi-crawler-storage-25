from __future__ import annotations

from nonslop.check.base import ProjectCheck, SkillCheck
from nonslop.check.checks.github_skill import GitHubSkillStructureCheck
from nonslop.check.checks.local_skill import LocalSkillStructureCheck
from nonslop.check.checks.orphans import OrphansCheck
from nonslop.check.checks.pairing import PairingCheck
from nonslop.check.checks.skill_md import SkillMdCheck

DEFAULT_SKILL_CHECKS: list[SkillCheck] = [
    LocalSkillStructureCheck(),
    GitHubSkillStructureCheck(),
    SkillMdCheck(),
]

DEFAULT_PROJECT_CHECKS: list[ProjectCheck] = [
    OrphansCheck(),
    PairingCheck(),
]
