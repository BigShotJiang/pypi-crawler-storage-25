from __future__ import annotations

import os
from collections.abc import Iterator
from pathlib import Path
from typing import ClassVar

from nonslop.check.base import ProjectCheck
from nonslop.check.models import CheckContext, IssueKind, SkillIssue

_PAIRING_PRUNED_DIR_NAMES = {".venv", ".git", "node_modules"}
_PAIRING_PRUNED_RELPATHS = {
    Path("src/nonslop/_templates"),
    Path(".agents/skills"),
    Path(".claude/skills"),
}


def _iter_pairing_dirs(project_dir: Path) -> Iterator[Path]:
    """Yield each directory under project_dir that contains AGENTS.md or CLAUDE.md."""
    for dirpath, dirnames, filenames in os.walk(project_dir):
        current = Path(dirpath)
        rel = current.relative_to(project_dir)
        dirnames[:] = sorted(
            d
            for d in dirnames
            if d not in _PAIRING_PRUNED_DIR_NAMES and (rel / d) not in _PAIRING_PRUNED_RELPATHS
        )
        if "AGENTS.md" in filenames or "CLAUDE.md" in filenames:
            yield current


class PairingCheck(ProjectCheck):
    name: ClassVar[str] = "pairing"

    def run(self, ctx: CheckContext) -> list[SkillIssue]:
        issues: list[SkillIssue] = []
        project_dir = ctx.project_dir
        for dir_path in _iter_pairing_dirs(project_dir):
            agents_path = dir_path / "AGENTS.md"
            claude_path = dir_path / "CLAUDE.md"
            agents_exists = agents_path.is_file()
            claude_exists = claude_path.is_file()

            if agents_exists and not claude_exists:
                rel = agents_path.relative_to(project_dir).as_posix()
                issues.append(
                    SkillIssue(
                        rel,
                        IssueKind.CLAUDE_MD_MISSING_PEER,
                        f"AGENTS.md at {rel} has no peer CLAUDE.md in the same directory",
                    )
                )
            elif claude_exists and not agents_exists:
                rel = claude_path.relative_to(project_dir).as_posix()
                issues.append(
                    SkillIssue(
                        rel,
                        IssueKind.AGENTS_MD_MISSING_PEER,
                        f"CLAUDE.md at {rel} has no peer AGENTS.md in the same directory",
                    )
                )
            else:
                claude_text = claude_path.read_text(encoding="utf-8")
                if "@AGENTS.md" not in claude_text:
                    rel = claude_path.relative_to(project_dir).as_posix()
                    issues.append(
                        SkillIssue(
                            rel,
                            IssueKind.CLAUDE_MD_MISSING_AGENTS_REF,
                            f"CLAUDE.md at {rel} does not include peer AGENTS.md"
                            f" via @AGENTS.md syntax",
                        )
                    )
        return issues
