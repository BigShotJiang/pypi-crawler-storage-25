from __future__ import annotations

import click

from nonslop.check.runner import check_cmd
from nonslop.context import NonslopContext
from nonslop.create_project import create_project
from nonslop.gateways.gh.real import RealGhCli
from nonslop.gateways.npx_skills.real import RealNpxSkills
from nonslop.skillx import exec_group
from nonslop.update_skills import update_skills_cmd


@click.group()
@click.pass_context
def main(ctx: click.Context) -> None:
    """nonslop CLI."""
    if ctx.obj is None:
        ctx.obj = NonslopContext(gh=RealGhCli(), npx_skills=RealNpxSkills())


main.add_command(create_project)
main.add_command(check_cmd)
main.add_command(exec_group)
main.add_command(update_skills_cmd)

if __name__ == "__main__":
    main()
