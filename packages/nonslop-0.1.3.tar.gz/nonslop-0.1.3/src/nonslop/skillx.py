"""Skillx: run skills from GitHub repos without installing them."""

from __future__ import annotations

import json
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import click

from nonslop.context import NonslopContext
from nonslop.gateways.gh.gateway import GhAuthError, GhCli, GhError, GhNotFound
from nonslop.gateways.npx_skills.gateway import NpxSkills, NpxSkillsError
from nonslop.preconditions import requires_gh, requires_npx

_NONSLOP_REPO = "nseng-ai/nonslop"
_REPO_RE = re.compile(r"^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+$")


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ParseResult:
    success: bool
    repo: str | None = None
    skill: str | None = None
    format: str | None = None
    error: str | None = None

    def to_dict(self) -> dict:
        if self.success:
            return {"success": True, "repo": self.repo, "skill": self.skill, "format": self.format}
        return {"success": False, "error": self.error}


@dataclass(frozen=True)
class ListResult:
    success: bool
    repo: str | None = None
    skills: list[str] | None = None
    error: str | None = None
    hint: str | None = None

    def to_dict(self) -> dict:
        if self.success:
            return {"success": True, "repo": self.repo, "skills": self.skills}
        d: dict = {"success": False, "error": self.error}
        if self.hint:
            d["hint"] = self.hint
        return d


@dataclass(frozen=True)
class FetchResult:
    success: bool
    repo: str | None = None
    skill: str | None = None
    tmp_dir: str | None = None
    skill_dir: str | None = None
    skill_md: str | None = None
    files: list[str] | None = None
    needs_selection: bool = False
    available_skills: list[str] | None = None
    error: str | None = None

    def to_dict(self) -> dict:
        if self.success:
            d: dict = {
                "success": True,
                "repo": self.repo,
                "skill": self.skill,
                "tmp_dir": self.tmp_dir,
                "skill_dir": self.skill_dir,
                "skill_md": self.skill_md,
                "files": self.files,
            }
            if self.needs_selection:
                d["needs_selection"] = True
                d["available_skills"] = self.available_skills
            return d
        return {"success": False, "error": self.error, "tmp_dir": None}


@dataclass(frozen=True)
class CleanupResult:
    success: bool
    removed: str | None = None
    error: str | None = None

    def to_dict(self) -> dict:
        if self.success:
            return {"success": True, "removed": self.removed}
        return {"success": False, "error": self.error}


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------


def parse_skill_input(raw: str) -> ParseResult:
    """Parse user input into repo and optional skill name."""
    raw = raw.strip()
    if not raw:
        return ParseResult(success=False, error="Empty input")

    # 1. GitHub URL
    parsed = urlparse(raw)
    if parsed.scheme in ("http", "https") and parsed.netloc == "github.com":
        parts = [p for p in parsed.path.strip("/").split("/") if p]
        if len(parts) >= 2:
            repo = f"{parts[0]}/{parts[1]}"
            # Look for skills/<name> in the path
            skill = None
            for i, segment in enumerate(parts):
                if segment == "skills" and i + 1 < len(parts):
                    skill = parts[i + 1]
                    break
            return ParseResult(success=True, repo=repo, skill=skill, format="url")

    # 2. --skill / -s flag: owner/repo --skill skill-name (or -s skill-name)
    flag_match = re.search(r"\s(?:--skill|-s)(?:\s|$)", raw)
    if flag_match:
        repo_candidate = raw[: flag_match.start()].strip()
        skill = raw[flag_match.end() :].strip() or None
        if _REPO_RE.match(repo_candidate):
            return ParseResult(success=True, repo=repo_candidate, skill=skill, format="skill_flag")

    # 3. Plain: owner/repo [skill-name]
    tokens = raw.split()
    if tokens and _REPO_RE.match(tokens[0]):
        repo = tokens[0]
        skill = tokens[1] if len(tokens) >= 2 else None
        fmt = "plain" if skill else "repo_only"
        return ParseResult(success=True, repo=repo, skill=skill, format=fmt)

    return ParseResult(success=False, error=f"Could not extract owner/repo from input: {raw!r}")


def list_skills(repo: str, *, gh: GhCli) -> ListResult:
    """List available skills from a GitHub repo via the `gh` gateway."""
    try:
        entries = gh.list_directory(repo, "skills")
    except GhNotFound:
        return ListResult(
            success=False,
            error=f"No skills directory found in {repo}",
            hint="Check that the repo exists and has a skills/ directory",
        )
    except GhAuthError:
        return ListResult(
            success=False,
            error=f"Authentication error accessing {repo}",
            hint="Check `gh auth status` for authentication issues",
        )
    except GhError as e:
        return ListResult(success=False, error=str(e))

    return ListResult(success=True, repo=repo, skills=sorted(entries))


def fetch_skill(repo: str, skill: str | None, *, npx_skills: NpxSkills) -> FetchResult:
    """Fetch a skill into a temp directory via the `npx skills` gateway."""
    tmp_dir = tempfile.mkdtemp(prefix="skillx.")
    tmp_path = Path(tmp_dir)

    try:
        npx_skills.add(
            repo,
            skills=[skill] if skill else None,
            agents=["codex"],
            cwd=tmp_path,
        )
    except NpxSkillsError as e:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return FetchResult(success=False, error=f"npx skills add failed: {e}")

    agents_skills = tmp_path / ".agents" / "skills"
    if not agents_skills.is_dir():
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return FetchResult(success=False, error="No skills were installed")

    installed = sorted(p.name for p in agents_skills.iterdir() if p.is_dir() or p.is_symlink())
    if not installed:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return FetchResult(success=False, error="No skills were installed")

    # Multiple skills installed and none was specified
    if not skill and len(installed) > 1:
        return FetchResult(
            success=True,
            repo=repo,
            tmp_dir=tmp_dir,
            needs_selection=True,
            available_skills=installed,
        )

    target_name = skill if skill else installed[0]
    skill_dir = agents_skills / target_name
    skill_md = skill_dir / "SKILL.md"

    if not skill_dir.is_dir():
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return FetchResult(
            success=False,
            error=f"Skill {target_name!r} was not found in installed skills",
        )

    files = sorted(str(p.relative_to(skill_dir)) for p in skill_dir.rglob("*") if p.is_file())

    return FetchResult(
        success=True,
        repo=repo,
        skill=target_name,
        tmp_dir=tmp_dir,
        skill_dir=str(skill_dir),
        skill_md=str(skill_md),
        files=files,
    )


def cleanup_skill_dir(path: str) -> CleanupResult:
    """Remove a skillx temp directory with safety validation."""
    p = Path(path)

    # Safety: must be under the system temp directory and have skillx. prefix
    tmp_root = Path(tempfile.gettempdir())
    try:
        p.relative_to(tmp_root)
    except ValueError:
        return CleanupResult(
            success=False,
            error=f"Refusing to remove: {path!r} is not under {tmp_root}",
        )

    if not p.name.startswith("skillx."):
        return CleanupResult(
            success=False,
            error=f"Refusing to remove: {path!r} does not have 'skillx.' prefix",
        )

    if not p.exists():
        return CleanupResult(
            success=False,
            error=f"Directory does not exist: {path!r}",
        )

    shutil.rmtree(p)
    return CleanupResult(success=True, removed=path)


# ---------------------------------------------------------------------------
# Click commands: exec group
# ---------------------------------------------------------------------------


def _emit(result_obj: ParseResult | ListResult | FetchResult | CleanupResult) -> None:
    click.echo(json.dumps(result_obj.to_dict(), indent=2))


@click.group("exec", hidden=True)
def exec_group() -> None:
    """Internal commands for agent consumption."""


# -- skillx subgroup --------------------------------------------------------


@exec_group.group("skillx")
def skillx_group() -> None:
    """Run skills from GitHub repos without installing."""


@skillx_group.command("parse")
@click.argument("input_text")
def skillx_parse_cmd(input_text: str) -> None:
    """Parse user input into repo and skill name."""
    _emit(parse_skill_input(input_text))


@skillx_group.command("list")
@click.option("--repo", required=True, help="GitHub repo (owner/repo).")
@click.pass_obj
def skillx_list_cmd(ctx: NonslopContext, repo: str) -> None:
    """List available skills from a GitHub repo."""
    requires_gh()
    result = list_skills(repo, gh=ctx.gh)
    _emit(result)
    if not result.success:
        raise SystemExit(1)


@skillx_group.command("fetch")
@click.option("--repo", required=True, help="GitHub repo (owner/repo).")
@click.option("--skill", "skill_name", default=None, help="Specific skill to fetch.")
@click.pass_obj
def skillx_fetch_cmd(ctx: NonslopContext, repo: str, skill_name: str | None) -> None:
    """Fetch a skill into a temp directory."""
    requires_npx()
    result = fetch_skill(repo, skill_name, npx_skills=ctx.npx_skills)
    _emit(result)
    if not result.success:
        raise SystemExit(1)


@skillx_group.command("cleanup")
@click.option("--dir", "dir_path", required=True, help="Temp directory to remove.")
def skillx_cleanup_cmd(dir_path: str) -> None:
    """Remove a skillx temp directory."""
    result = cleanup_skill_dir(dir_path)
    _emit(result)
    if not result.success:
        raise SystemExit(1)


# -- nsx subgroup -----------------------------------------------------------


@exec_group.group("nsx")
def nsx_group() -> None:
    """Run skills from nseng-ai/nonslop without installing."""


@nsx_group.command("list")
@click.pass_obj
def nsx_list_cmd(ctx: NonslopContext) -> None:
    """List available skills from nseng-ai/nonslop."""
    requires_gh()
    result = list_skills(_NONSLOP_REPO, gh=ctx.gh)
    _emit(result)
    if not result.success:
        raise SystemExit(1)


@nsx_group.command("fetch")
@click.option("--skill", "skill_name", default=None, help="Specific skill to fetch.")
@click.pass_obj
def nsx_fetch_cmd(ctx: NonslopContext, skill_name: str | None) -> None:
    """Fetch a skill from nseng-ai/nonslop into a temp directory."""
    requires_npx()
    result = fetch_skill(_NONSLOP_REPO, skill_name, npx_skills=ctx.npx_skills)
    _emit(result)
    if not result.success:
        raise SystemExit(1)


@nsx_group.command("cleanup")
@click.option("--dir", "dir_path", required=True, help="Temp directory to remove.")
def nsx_cleanup_cmd(dir_path: str) -> None:
    """Remove a skillx temp directory."""
    result = cleanup_skill_dir(dir_path)
    _emit(result)
    if not result.success:
        raise SystemExit(1)
