# nonslop

AI-native project scaffolding.

## The idea

The new way to bootstrap projects is **skills**. Instead of language-specific scaffolding tools, you start with a skills-ready project and compose what you need. Skills are universal -- they work across any project, any language, and any AI coding agent.

## Quick start

```bash
uvx nonslop create-project my-project
```

Creates a new `my-project/` directory in the current working directory, pre-wired with skill infrastructure. Two skills are preinstalled:

- **ns-skill-management** -- manage persistent skills with `npx skills`
- **ns-skillx** -- invoke any skill ephemerally from a GitHub repo, like `npx` for skills

## Example: creating a Python project

From your new project, invoke `skillx` to scaffold a Python package:

In **Claude Code**:

```
/ns-skillx nseng-ai/nonslop --skill ns-create-pypackage-project
```

In **Codex**:

```
$ns-skillx nseng-ai/nonslop --skill ns-create-pypackage-project
```

The skill is fetched, executed, and discarded -- your project gets the Python scaffolding without permanently installing anything.

## What you get

After `create-project`, your project has:

```
my-project/
├── .agents/skills/         # installed skills (universal agent directory)
├── .claude/                # Claude Code config + skill symlinks
├── AGENTS.md               # project instructions for agents
├── CLAUDE.md               # project instructions
├── nonslop.json            # agents this project targets
├── skills-lock.json        # installed skill metadata
└── .gitignore
```

## Development

```bash
uv sync
just check
```
