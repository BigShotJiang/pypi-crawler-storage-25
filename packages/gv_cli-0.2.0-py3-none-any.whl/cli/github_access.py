from __future__ import annotations
import subprocess,sys
from textwrap import dedent
from.import ssh_access
LOCAL_GH_INSTALL_MESSAGE='GitHub CLI (`gh`) is required for this command. Install it from https://cli.github.com/ and run `gh auth login`.'
LOCAL_GH_REAUTH_HINT='Re-authenticate local GitHub CLI with:\n  gh auth logout\n  gh auth login\nChoose: GitHub.com, HTTPS, Skip uploading your local SSH key, then paste a classic PAT with `repo`, `read:org`, and `admin:public_key`.\nVerify it with: gh api user/keys'
LOCAL_GH_REFRESH_COMMAND='gh auth refresh -h github.com -s repo,read:org,admin:public_key'
REMOTE_GH_SSH_KEY_PERMISSION_HINT=f"Failed to inspect GitHub SSH keys. Ensure the local gh token grants SSH key management access.\n{LOCAL_GH_REAUTH_HINT}"
LOCAL_GH_REFRESH_HINT=f"Refresh local GitHub CLI permissions with:\n  {LOCAL_GH_REFRESH_COMMAND}"
LOCAL_GH_REFRESH_MESSAGE='Your local GitHub CLI token cannot manage SSH keys yet. Running `gh auth refresh` to request `admin:public_key` so GitHub access can be enabled.\n'
GITHUB_SSH_CONFIG=dedent('    Host github.com\n      HostName github.com\n      User git\n      IdentityFile ~/.ssh/id_ed25519_github\n      IdentitiesOnly yes\n    ')
FIND_EXISTING_SSH_KEY_ID_PYTHON="import json, os, sys; data=json.load(sys.stdin); pub=os.environ['PUBKEY']; print(next((str(item['id']) for item in data if item.get('key') == pub), ''), end='')"
FIND_EXISTING_SSH_KEY_IDS_PYTHON="import json, os, sys; data=json.load(sys.stdin) if sys.stdin.readable() else []; pub=os.environ['PUBKEY']; print(' '.join(str(item['id']) for item in data if item.get('key') == pub), end='')"
REMOVE_MANAGED_SSH_CONFIG_PYTHON=dedent(f"""    from pathlib import Path

    config_path = Path.home() / '.ssh' / 'config'
    if config_path.exists():
        text = config_path.read_text()
        managed = {GITHUB_SSH_CONFIG!r}
        if text == managed:
            config_path.unlink()
    """)
HAS_MANAGED_SSH_CONFIG_PYTHON=dedent(f"""    from pathlib import Path

    config_path = Path.home() / '.ssh' / 'config'
    if not config_path.exists():
        raise SystemExit(1)
    text = config_path.read_text()
    managed = {GITHUB_SSH_CONFIG!r}
    raise SystemExit(0 if managed in text else 1)
    """)
def read_local_github_token()->str:
	_check_local_gh_installed();A=_read_authenticated_local_github_token()
	if not _local_github_can_manage_ssh_keys():
		_refresh_local_github_permissions();A=_read_authenticated_local_github_token()
		if not _local_github_can_manage_ssh_keys():raise RuntimeError(f"Local GitHub CLI still cannot inspect SSH keys after refresh.\n{LOCAL_GH_REFRESH_HINT}\n{LOCAL_GH_REAUTH_HINT}")
	if not A:raise RuntimeError(f"GitHub CLI did not return a token.\n{LOCAL_GH_REAUTH_HINT}")
	return A
def _check_local_gh_installed()->None:
	try:subprocess.run(['gh','--version'],check=True,capture_output=True,text=True)
	except FileNotFoundError as A:raise RuntimeError(LOCAL_GH_INSTALL_MESSAGE)from A
	except subprocess.CalledProcessError as A:raise RuntimeError('GitHub CLI (`gh`) is installed but could not be executed.')from A
def _read_authenticated_local_github_token()->str:
	try:B=subprocess.run(['gh','auth','token'],check=True,capture_output=True,text=True)
	except FileNotFoundError as A:raise RuntimeError(LOCAL_GH_INSTALL_MESSAGE)from A
	except subprocess.CalledProcessError as A:raise RuntimeError(f"GitHub CLI is installed but not authenticated.\n{LOCAL_GH_REAUTH_HINT}")from A
	return B.stdout.strip()
def _local_github_can_manage_ssh_keys()->bool:A=subprocess.run(['gh','api','user/keys','--paginate'],capture_output=True,text=True,check=False);return A.returncode==0
def _refresh_local_github_permissions()->None:
	try:sys.stderr.write(LOCAL_GH_REFRESH_MESSAGE);sys.stderr.flush();subprocess.run(['gh','auth','refresh','-h','github.com','-s','repo,read:org,admin:public_key'],check=True)
	except FileNotFoundError as A:raise RuntimeError(LOCAL_GH_INSTALL_MESSAGE)from A
	except subprocess.CalledProcessError as A:raise RuntimeError(f"GitHub CLI needs additional permissions to manage SSH keys, and `gh auth refresh` did not complete.\n{LOCAL_GH_REFRESH_HINT}\n{LOCAL_GH_REAUTH_HINT}")from A
def enable_github(env_id:str,ssh_details:ssh_access.EnvSshAccess,github_token:str)->None:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_enable_script(github_token),capture_output=True)
	if A.returncode!=0:raise RuntimeError(_stderr_message(A,'Failed to enable GitHub auth.'))
def disable_github(env_id:str,ssh_details:ssh_access.EnvSshAccess)->None:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_disable_script(),capture_output=True)
	if A.returncode!=0:raise RuntimeError(_stderr_message(A,'Failed to disable GitHub auth.'))
def github_status(env_id:str,ssh_details:ssh_access.EnvSshAccess)->str:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_status_script(),capture_output=True)
	if A.returncode==0:return A.stdout.strip()or'enabled'
	if A.returncode==10:return'disabled'
	raise RuntimeError(_stderr_message(A,'Failed to read GitHub auth status.'))
def _enable_script(github_token:str)->str:A=github_token.replace("'",'\'"\'"\'');B=_ssh_key_title('$HOSTNAME');C=_shell_single_quote(REMOTE_GH_SSH_KEY_PERMISSION_HINT);return _join_script_sections('set -euo pipefail',dedent(f"""            # Validate remote prerequisites and declare shared paths.
            command -v gh >/dev/null || {{
              printf 'gh is not installed on the env. Reprovision with the latest bootstrap.
' >&2
              exit 1
            }}
            token='{A}'
            ssh_key_path=\"$HOME/.ssh/id_ed25519_github\"
            ssh_key_title=\"{B}\"
            """),dedent(f"""            # Log gh into GitHub and verify the token can inspect SSH keys.
            printf '%s
' \"$token\" | gh auth login --hostname github.com --git-protocol https --with-token
            gh config set -h github.com git_protocol ssh >/dev/null
            if ! existing_keys_json=\"$(gh api user/keys --paginate 2>/dev/null)\"; then
              printf '{C}
' >&2
              exit 1
            fi
            """),dedent(f'''            # Create or reuse the dedicated GitHub SSH key on the VM.
            install -d -m 700 "$HOME/.ssh"
            if [[ ! -f "$ssh_key_path" ]]; then
              ssh-keygen -t ed25519 -N \'\' -f "$ssh_key_path" -C "$ssh_key_title" >/dev/null
            fi
            touch "$HOME/.ssh/known_hosts"
            chmod 600 "$HOME/.ssh/known_hosts"
            if ! ssh-keygen -F github.com -f "$HOME/.ssh/known_hosts" >/dev/null; then
              ssh-keyscan github.com >> "$HOME/.ssh/known_hosts" 2>/dev/null
            fi
            pubkey="$(cat "$ssh_key_path.pub")"
            existing_id="$(PUBKEY="$pubkey" python3 -c "{FIND_EXISTING_SSH_KEY_ID_PYTHON}" <<<"$existing_keys_json")"
            if [[ -z "$existing_id" ]]; then
              if ! gh ssh-key add "$ssh_key_path.pub" --title "$ssh_key_title" >/dev/null 2>&1; then
                printf \'Failed to register the env SSH key with GitHub. Ensure the local gh token grants SSH key management access.
\' >&2
                exit 1
              fi
            fi
            '''),'\n'.join(('# Persist the GitHub SSH host config and HTTPS git credential helper.','cat > "$HOME/.ssh/config" <<\'EOF_GV_GITHUB_SSH\'',GITHUB_SSH_CONFIG.rstrip(),'EOF_GV_GITHUB_SSH','chmod 600 "$HOME/.ssh/config"','git config --global --unset-all credential.https://github.com.helper || true',"git config --global --add credential.https://github.com.helper ''","git config --global --add credential.https://github.com.helper '!gh auth git-credential'","printf 'GitHub auth enabled.\\n'")))
def _disable_script()->str:return _join_script_sections('set -euo pipefail',dedent(f'''            # If gh is still authenticated, remove the matching SSH key from GitHub.
            ssh_key_path="$HOME/.ssh/id_ed25519_github"
            if command -v gh >/dev/null && gh auth status --hostname github.com >/dev/null 2>&1 && [[ -f "$ssh_key_path.pub" ]]; then
              pubkey="$(cat "$ssh_key_path.pub")"
              existing_keys_json="$(gh api user/keys --paginate 2>/dev/null || true)"
              existing_ids="$(PUBKEY="$pubkey" python3 -c "{FIND_EXISTING_SSH_KEY_IDS_PYTHON}" <<<"$existing_keys_json" || true)"
              for key_id in $existing_ids; do
                gh api -X DELETE "user/keys/$key_id" >/dev/null 2>&1 || true
              done
            fi
            '''),'\n'.join(('# Remove VM-side gh auth, SSH material, and HTTPS git helper config.','rm -f "$HOME/.config/gh/hosts.yml"','rm -f "$HOME/.ssh/id_ed25519_github" "$HOME/.ssh/id_ed25519_github.pub"','if [[ -f "$HOME/.ssh/config" ]]; then',"python3 - <<'PY'",REMOVE_MANAGED_SSH_CONFIG_PYTHON.rstrip(),'PY','fi','git config --global --unset-all credential.https://github.com.helper || true',"printf 'GitHub auth disabled.\\n'")))
def _status_script()->str:return _join_script_sections('set -euo pipefail','\n'.join(('# Report enabled when gh auth and the managed git credential helper are present.','command -v gh >/dev/null || {',"  printf 'gh not installed\\n' >&2",'  exit 1','}','if gh auth status --hostname github.com >/dev/null 2>&1; then',"  if git config --global --get-all credential.https://github.com.helper | grep -Fxq '!gh auth git-credential'; then","    printf 'enabled\\n'",'    exit 0','  fi','fi',"printf 'disabled\\n'",'exit 10')))
def _stderr_message(result:subprocess.CompletedProcess[str],fallback:str)->str:A=result;B=(A.stderr or A.stdout or'').strip();return B or fallback
def _ssh_key_title(hostname:str)->str:return f"gv-{hostname}-github"
def _shell_single_quote(value:str)->str:return value.replace("'",'\'"\'"\'')
def _join_script_sections(*A:str)->str:return'\n\n'.join(A.strip('\n')for A in A if A).strip()+'\n'