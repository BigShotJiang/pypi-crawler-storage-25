from __future__ import annotations
import json,os,re,subprocess,sys,time
from dataclasses import dataclass
from typing import Any
from urllib import error,request
import click
from.import auth_flow,cursor_launcher,github_access,opencode_launcher,petname,vscode_launcher
from.api_url import normalize_api_url,resolve_api_url
from.auth_session import CONFIG_PATH,get_api_auth_header,load_cli_config,redact_cli_config,save_cli_config
from.profile import handle_profile_apply,handle_profile_job,handle_profile_pull,handle_profile_push,handle_profile_show
from.import ssh_access
from.repo_add import handle_repo_add
from.repo_env import handle_env_add,handle_env_list,handle_env_rm,handle_repo_onboard,handle_repo_list
ENV_NAME_RE=re.compile('^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])?$')
EMAIL_RE=re.compile('^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$')
VM_USERNAME_RE=re.compile('^[a-z][a-z0-9_-]{0,31}$')
RESERVED_VM_USERNAMES={'root'}
HTTP_USER_AGENT='gv-cli/0.1'
@dataclass(frozen=True)
class CreateEnvInput:
	name:str;git_user_name:str;git_user_email:str;vm_username:str|None=None
	def to_payload(A)->dict[str,str]:
		B={'name':A.name,'gitUserName':A.git_user_name,'gitUserEmail':A.git_user_email}
		if A.vm_username:B['vmUsername']=A.vm_username
		return B
@dataclass(frozen=True)
class EnvRecord:
	id:str;name:str;domain:str;status:str;step:str;instance_id:str|None;public_ip:str|None;cf_record_id:str|None;vm_username:str;opencode_username:str;opencode_password:str;git_user_name:str;git_user_email:str;error_message:str|None;created_at:str;updated_at:str;ssh_key_fingerprint:str|None=None;url:str|None=None
	@classmethod
	def from_payload(B,payload:dict[str,Any])->'EnvRecord':A=payload;return B(id=str(A['id']),name=str(A['name']),domain=str(A['domain']),status=str(A['status']),step=str(A['step']),instance_id=_optional_string(A.get('instanceId')),public_ip=_optional_string(A.get('publicIp')),cf_record_id=_optional_string(A.get('cfRecordId')),vm_username=str(A.get('vmUsername')or A['opencodeUsername']),opencode_username=str(A['opencodeUsername']),opencode_password=str(A['opencodePassword']),git_user_name=str(A['gitUserName']),git_user_email=str(A['gitUserEmail']),ssh_key_fingerprint=_optional_string(A.get('sshKeyFingerprint')),error_message=_optional_string(A.get('errorMessage')),created_at=str(A['createdAt']),updated_at=str(A['updatedAt']),url=_optional_string(A.get('url')))
class ApiRequestError(RuntimeError):
	def __init__(A,message:str,status_code:int):super().__init__(message);A.status_code=status_code
def _optional_string(value:Any)->str|None:
	A=value
	if A is None:return
	return str(A)
def normalize_env_name(value:str)->str:return value.strip().lower()
def validate_create_env_input(name:str,git_user_name:str,git_user_email:str,vm_username:str|None=None)->CreateEnvInput:
	B=normalize_env_name(name);C=git_user_name.strip();D=git_user_email.strip();A=(vm_username or'').strip().lower()or None
	if not ENV_NAME_RE.match(B):raise ValueError('Environment name must be 3-30 chars of lowercase letters, numbers, or hyphens, and cannot start or end with a hyphen.')
	if len(C)<2:raise ValueError('Git author name must be at least 2 characters.')
	if not EMAIL_RE.match(D):raise ValueError('Git author email must look like an email address.')
	if A:
		if A in RESERVED_VM_USERNAMES:raise ValueError('VM username is reserved and cannot be used.')
		if not VM_USERNAME_RE.match(A):raise ValueError('VM username must start with a lowercase letter and use only lowercase letters, numbers, underscores, or hyphens.')
	return CreateEnvInput(name=B,git_user_name=C,git_user_email=D,vm_username=A)
def read_git_config(key:str)->str:
	try:A=subprocess.run(['git','config','--global','--get',key],check=True,capture_output=True,text=True)
	except(FileNotFoundError,subprocess.CalledProcessError):return''
	return A.stdout.strip()
def default_init_values(name_arg:str|None)->tuple[str,str,str]:return normalize_env_name(name_arg or os.getenv('USER','')),read_git_config('user.name'),read_git_config('user.email')
def read_local_whoami()->str:
	try:A=subprocess.run(['whoami'],check=True,capture_output=True,text=True)
	except(FileNotFoundError,subprocess.CalledProcessError):return os.getenv('USER','').strip()
	return A.stdout.strip()or os.getenv('USER','').strip()
def is_interactive_input()->bool:return click.get_text_stream('stdin').isatty()
def check_name_availability(api_url:str,name:str)->bool:
	B=request_api_json(api_url,'GET',f"/v1/envs/check-name/{normalize_env_name(name)}");A=B.get('available')
	if not isinstance(A,bool):raise RuntimeError('Control plane returned an invalid availability response')
	return A
def suggest_env_name(api_url:str)->str:
	for A in petname.generate_candidates():
		if check_name_availability(api_url,A):return A
	raise click.ClickException('Could not find an available suggested environment name.')
def missing_init_options(name:str|None,git_user_name:str|None,git_user_email:str|None)->list[str]:
	A=[]
	if not(name or'').strip():A.append('--name')
	if not(git_user_name or'').strip():A.append('--git-user-name')
	if not(git_user_email or'').strip():A.append('--git-user-email')
	return A
def collect_init_input(api_url:str|None,name_arg:str|None,git_user_name_arg:str|None,git_user_email_arg:str|None)->CreateEnvInput:
	I=git_user_email_arg;H=git_user_name_arg;C=api_url;A=name_arg;M,N,O=default_init_values(A);P=read_local_whoami();Q=A if A is not None else M;J=H if H is not None else N;K=I if I is not None else O
	if not is_interactive_input():
		R=missing_init_options(Q,J,K)
		if R:raise click.ClickException('Missing required options for non-interactive use: '+', '.join(R))
		try:return validate_create_env_input(Q,J,K,P)
		except ValueError as G:raise click.ClickException(str(G))from G
	if not N or not O:click.echo('Hint: local git defaults come from `git config --global --get user.name` and `git config --global --get user.email`.\n')
	L=A is None;S=H is None;T=I is None;B=A if A is not None else suggest_env_name(C)if C else M;D=J;E=K
	while True:
		U=click.prompt('Environment name',default=B,show_default=bool(B))if L else B;V=click.prompt('Git author name',default=D,show_default=bool(D))if S else D;W=click.prompt('Git author email',default=E,show_default=bool(E))if T else E
		try:F=validate_create_env_input(U,V,W,P)
		except ValueError as G:click.echo(f"\n{G}\n",err=True);B=U;D=V;E=W;L=True;S=True;T=True;continue
		if C and not check_name_availability(C,F.name):click.echo(f"\nEnvironment name {F.name} already exists.\n",err=True);B=suggest_env_name(C);D=F.git_user_name;E=F.git_user_email;click.echo(f"Suggested available name: {B}");L=True;continue
		return F
def _parse_error_message(payload:dict[str,Any],status_code:int)->str:
	B=payload;C=B.get('error')
	if isinstance(C,str)and C:
		D=B.get('error_description')
		if isinstance(D,str)and D:return D
		return C
	A=B.get('detail')
	if isinstance(A,str)and A:return A
	if isinstance(A,list):
		E=[]
		for F in A:
			if isinstance(F,dict)and F.get('msg'):E.append(str(F['msg']))
		if E:return'; '.join(E)
	return f"Request failed with {status_code}"
def _extract_error_message(raw:str,status_code:int)->str:
	B=status_code;A=raw
	try:D=json.loads(A)if A else{}
	except json.JSONDecodeError:D={}
	C=_parse_error_message(D,B)
	if C!=f"Request failed with {B}":return C
	if A.strip():return f"Request failed with {B}: {A.strip()}"
	return C
def _request_json(method:str,url:str,payload:dict[str,Any]|None=None,*,headers:dict[str,str]|None=None)->dict[str,Any]:
	C=headers;B=payload;E=json.dumps(B).encode('utf-8')if B is not None else None;D={'Content-Type':'application/json','Accept':'application/json','User-Agent':HTTP_USER_AGENT}
	if C:D.update(C)
	F=request.Request(url,method=method,data=E,headers=D)
	try:
		with request.urlopen(F,timeout=30)as G:return json.loads(G.read().decode('utf-8'))
	except error.HTTPError as A:H=A.read().decode('utf-8');raise ApiRequestError(_extract_error_message(H,A.code),A.code)from A
	except error.URLError as A:raise RuntimeError(str(A.reason))from A
def create_env(api_url:str,input_data:CreateEnvInput)->EnvRecord:
	B=request_api_json(api_url,'POST','/v1/envs',input_data.to_payload());A=B.get('env')
	if not isinstance(A,dict):raise RuntimeError('Control plane returned an invalid environment response')
	return EnvRecord.from_payload(A)
def fetch_env(api_url:str,env_id:str)->EnvRecord:
	B=request_api_json(api_url,'GET',f"/v1/envs/{env_id}");A=B.get('env')
	if not isinstance(A,dict):raise RuntimeError('Control plane returned an invalid environment response')
	return EnvRecord.from_payload(A)
def list_envs(api_url:str)->list[EnvRecord]:
	B=request_api_json(api_url,'GET','/v1/envs');A=B.get('envs')
	if not isinstance(A,list):raise RuntimeError('Control plane returned an invalid environment list response')
	return[EnvRecord.from_payload(A)for A in A if isinstance(A,dict)]
def find_env_by_name(envs:list[EnvRecord],name:str)->EnvRecord:
	A=normalize_env_name(name)
	for B in envs:
		if B.name==A:return B
	raise RuntimeError(f"Environment {A} not found.")
def _resolve_repo_add_env(directory:str,env_name:str|None)->tuple[str|None,str|None,str|None,str|None]:
	B=env_name
	if B is None:raise click.ClickException('`gv repo add` requires `--env <name>` for control-plane sync.')
	C=resolve_api_url();A=find_env_by_name(list_envs(C),B)
	if A.status!='ready'or not A.public_ip:raise click.ClickException(f"Environment {A.name} is not ready yet (status: {A.status}, step: {A.step}).")
	return A.id,A.name,A.url,A.vm_username
def request_api_json(api_url:str,method:str,path:str,payload:dict[str,Any]|None=None,*,authenticated:bool=True)->dict[str,Any]:
	B=authenticated;C:dict[str,str]={}
	if B:C['Authorization']=get_api_auth_header()
	try:return _request_json(method,f"{api_url}{path}",payload,headers=C)
	except ApiRequestError as A:
		if B and A.status_code==401:raise RuntimeError('Unauthorized. Run `gv login` and try again.')from A
		raise RuntimeError(str(A))from A
def handle_login()->int:return auth_flow.login(resolve_api_url())
def handle_logout()->int:
	C=auth_flow.logout();A,B=ssh_access.clear_managed_ssh_state()
	if A or B:click.echo(f"Removed gv-managed SSH state ({A} key{"s"if A!=1 else""}, {B} config block{"s"if B!=1 else""}).")
	return C
def print_env_info(env:EnvRecord,*,title:str,sensitive:bool,github_status:str|None=None)->None:
	B=github_status;A=env;click.echo(f"\n{title}\n");click.echo(f"Name: {A.name}");click.echo(f"Status: {A.status}");click.echo(f"Step: {A.step}");click.echo(f"URL: {A.url}");click.echo(f"OpenCode Username: {A.opencode_username}");click.echo(f"VM Username: {A.vm_username}")
	if sensitive:click.echo(f"Password: {A.opencode_password}")
	else:click.echo('Password: *** (reveal this with --sensitive flag)')
	if A.public_ip:click.echo(f"SSH Host: {A.public_ip}");click.echo(f"SSH User: {A.vm_username}");click.echo(f"SSH Command: gv ssh {A.name}")
	if A.ssh_key_fingerprint:click.echo(f"SSH Key: {A.ssh_key_fingerprint}")
	if B is not None:
		if B=='disabled':click.echo(f"GitHub: disabled (enable with `gv github enable {A.name}`)")
		else:click.echo(f"GitHub: {B}")
	if A.error_message:click.echo(f"Error: {A.error_message}")
def select_env_interactively(envs:list[EnvRecord])->EnvRecord:
	B=[A.name for A in envs];C=click.prompt('Environment name',type=click.Choice(B,case_sensitive=False));D=normalize_env_name(C)
	for A in envs:
		if A.name==D:return A
	raise RuntimeError('Selected environment was not found')
def print_env_list(envs:list[EnvRecord])->None:
	click.echo('\nEnvironments\n')
	for A in envs:click.echo(f"- {A.name}: {A.status} ({A.step}) {A.url}")
	click.echo(f"\nUse `gv info <env>` to show details for one environment, for example `gv info {envs[0].name}`.")
def print_ready_env(env:EnvRecord)->None:print_env_info(env,title='Environment ready',sensitive=True)
def handle_init(name_arg:str|None,git_user_name_arg:str|None,git_user_email_arg:str|None)->int:
	G=name_arg;L=30;C:str|None=None
	if is_interactive_input():
		try:C=resolve_api_url()
		except RuntimeError as B:raise click.ClickException(str(B))from B
	while True:
		M=collect_init_input(C,G,git_user_name_arg,git_user_email_arg)
		if C is None:
			try:C=resolve_api_url()
			except RuntimeError as B:raise click.ClickException(str(B))from B
		try:
			H=create_env(C,M);click.echo(f"\nCreating environment {H.name}...");I='';E=time.monotonic();J=E
			while True:
				A=fetch_env(C,H.id);K=f"{A.status}:{A.step}";D=time.monotonic()
				if K!=I:click.echo(f"- {A.status} ({A.step})");I=K;J=D;E=D
				elif D-E>=L:N=int(D-J);click.echo(f"- still {A.status} ({A.step}) after {N}s");E=D
				if A.status=='ready':print_ready_env(A);return 0
				if A.status=='failed':raise RuntimeError(A.error_message or'Provisioning failed.')
				time.sleep(5)
		except RuntimeError as B:
			F=str(B)
			if'already exists'not in F:raise click.ClickException(F)from B
			if not is_interactive_input():raise click.ClickException(F)from B
			click.echo(f"\n{F}\n",err=True);G=None
def handle_info(name:str|None,sensitive:bool)->int:
	D=sensitive;C:str|None=None
	try:
		if D:
			if not is_interactive_input():raise click.ClickException('`gv info --sensitive` requires a terminal confirmation prompt.')
			if not click.confirm('This will show the OpenCode password. Would you like to proceed?',default=False):return 0
		E=resolve_api_url();A=list_envs(E)
		if name is not None:B=find_env_by_name(A,name)
		else:
			if not A:click.echo('No environments found.');return 0
			if len(A)==1:B=A[0]
			elif is_interactive_input():print_env_list(A);B=select_env_interactively(A)
			else:print_env_list(A);raise click.ClickException('Multiple environments found. Re-run with `gv info <name>`.')
	except RuntimeError as F:raise click.ClickException(str(F))from F
	if B.public_ip:
		try:G=ssh_access.fetch_env_ssh_access(E,B.id,request_api_json);C=github_access.github_status(B.id,G)
		except RuntimeError:C='unknown'
	print_env_info(B,title='Environment info',sensitive=D,github_status=C);return 0
def destroy_env(api_url:str,env_id:str)->None:request_api_json(api_url,'DELETE',f"/v1/envs/{env_id}")
def handle_destroy(name:str|None,all_envs:bool,yes:bool)->int:
	E=all_envs;D=name
	if E and D:raise click.ClickException('Pass either NAME or --all, not both.')
	if not E and not D:raise click.ClickException('Pass an environment name, or --all.')
	try:F=resolve_api_url();G=list_envs(F)
	except RuntimeError as A:raise click.ClickException(str(A))from A
	if E:C=G
	else:
		try:C=[find_env_by_name(G,D)]
		except RuntimeError as A:raise click.ClickException(str(A))from A
	if not C:click.echo('No environments to destroy.');return 0
	if not yes:
		if not is_interactive_input():raise click.ClickException('Refusing to destroy without --yes in a non-interactive shell.')
		click.echo('The following environments will be destroyed:')
		for B in C:click.echo(f"- {B.name} ({B.status}) {B.url or""}".rstrip())
		if not click.confirm('This terminates the EC2 instance, deletes the Cloudflare DNS record, and removes the control-plane row. Continue?',default=False):click.echo('Aborted.');return 1
	H=0
	for B in C:
		try:destroy_env(F,B.id);click.echo(f"Destroyed {B.name}.")
		except RuntimeError as A:H=1;click.echo(f"Failed to destroy {B.name}: {A}",err=True)
	return H
def handle_ssh(name:str,ssh_args:tuple[str,...])->int:
	try:A=resolve_api_url();B=find_env_by_name(list_envs(A),name);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return ssh_access.run_ssh(B.id,D,ssh_args)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_opencode(name:str)->int:
	try:B=resolve_api_url();C=find_env_by_name(list_envs(B),name);return opencode_launcher.handle_opencode(C)
	except RuntimeError as A:raise click.ClickException(str(A))from A
def handle_vscode(name:str)->int:
	try:A=resolve_api_url();B=find_env_by_name(list_envs(A),name);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return vscode_launcher.handle_vscode(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_cursor(name:str)->int:
	try:A=resolve_api_url();B=find_env_by_name(list_envs(A),name);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return cursor_launcher.handle_cursor(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_github_enable(name:str)->int:
	try:
		if not is_interactive_input():raise click.ClickException('`gv github enable` requires a terminal confirmation prompt before reading your local GitHub token.')
		if not click.confirm('This will read your GitHub token from the local `gh` CLI and send it to the selected environment to configure GitHub access. Do you want to continue?',default=False):return 0
		B=resolve_api_url();A=find_env_by_name(list_envs(B),name);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=github_access.read_local_github_token();github_access.enable_github(A.id,D,E)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"GitHub auth enabled for {A.name}.");return 0
def handle_github_disable(name:str)->int:
	try:B=resolve_api_url();A=find_env_by_name(list_envs(B),name);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);github_access.disable_github(A.id,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"GitHub auth disabled for {A.name}.");return 0
def handle_github_status(name:str)->int:
	try:B=resolve_api_url();A=find_env_by_name(list_envs(B),name);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=github_access.github_status(A.id,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"{A.name}: {E}");return 0
class OrderedGroup(click.Group):
	def list_commands(A,ctx:click.Context)->list[str]:return list(A.commands)
@click.group(cls=OrderedGroup,context_settings={'help_option_names':['-h','--help']},help='Provision always on cloud dev environments.\n\nAgent Instructions:\n  Some commands may prompt for missing required input.\n  Prompting is intended for human use.\n  For agent or CI usage, always pass required options explicitly.\n  If required options are missing in a non-interactive environment, the command will fail instead of prompting.\n\n')
def cli()->None:0
@cli.command(help='Create a new environment. Prompts for missing required values when run in a terminal.')
@click.option('--name',help='Environment name.')
@click.option('--git-user-name',help='Git author name for commits made in the environment.')
@click.option('--git-user-email',help='Git author email for commits made in the environment.')
def init(name:str|None,git_user_name:str|None,git_user_email:str|None)->None:handle_init(name,git_user_name,git_user_email)
@cli.command(help='Show environment connection details.')
@click.argument('name',required=False)
@click.option('--sensitive',is_flag=True,help='Prompt before including sensitive fields like the OpenCode password.')
def info(name:str|None,sensitive:bool)->None:raise click.exceptions.Exit(handle_info(name,sensitive))
@cli.command(context_settings={'ignore_unknown_options':True},help='SSH into an environment. Pass a remote command after `--` to run it over SSH.')
@click.argument('name')
@click.argument('ssh_args',nargs=-1,type=click.UNPROCESSED)
def ssh(name:str,ssh_args:tuple[str,...])->None:raise click.exceptions.Exit(handle_ssh(name,ssh_args))
@cli.command(help='Open a local OpenCode TUI attached to a remote environment.')
@click.argument('name')
def opencode(name:str)->None:raise click.exceptions.Exit(handle_opencode(name))
@cli.command(name='vscode',help='Open VS Code on a selected remote workspace.')
@click.argument('name')
def vscode(name:str)->None:raise click.exceptions.Exit(handle_vscode(name))
@cli.command(name='cursor',help='Open Cursor on a selected remote workspace.')
@click.argument('name')
def cursor(name:str)->None:raise click.exceptions.Exit(handle_cursor(name))
@cli.command(help='Destroy an environment (terminates EC2, removes Cloudflare DNS, deletes the control-plane row). Use --all to destroy every env you own.')
@click.argument('name',required=False)
@click.option('--all','all_envs',is_flag=True,help='Destroy every environment you own.')
@click.option('--yes',is_flag=True,help='Skip the confirmation prompt.')
def destroy(name:str|None,all_envs:bool,yes:bool)->None:raise click.exceptions.Exit(handle_destroy(name,all_envs,yes))
@cli.command(help='Log in with Clerk.')
def login()->None:raise click.exceptions.Exit(handle_login())
@cli.command(help='Clear the saved Clerk login.')
def logout()->None:raise click.exceptions.Exit(handle_logout())
@cli.group(help='Manage CLI configuration.')
def config()->None:0
@cli.group('repo',help='Repo onboarding commands.')
def repo_group()->None:0
@cli.group('project',help='Alias for `repo` commands.')
def project_group()->None:0
@cli.group('github',help='Manage GitHub access on an environment.')
def github_group()->None:0
@config.command('set-api-url',help='Persist the control plane API URL.')
@click.argument('url')
def config_set_api_url(url:str)->None:
	try:B=normalize_api_url(url);C=load_cli_config();C['api_url']=B;save_cli_config(C);click.echo(f"Saved api_url to {CONFIG_PATH}");click.echo(B)
	except ValueError as A:raise click.ClickException(str(A))from A
	except RuntimeError as A:raise click.ClickException(str(A))from A
@config.command('show',help='Show the saved CLI configuration.')
def config_show()->None:
	try:B=load_cli_config();click.echo(json.dumps(redact_cli_config(B),indent=2,sort_keys=True))
	except RuntimeError as A:raise click.ClickException(str(A))from A
@github_group.command('enable',help='Enable GitHub auth on an environment.')
@click.argument('name')
def github_enable_command(name:str)->None:raise click.exceptions.Exit(handle_github_enable(name))
@github_group.command('disable',help='Remove GitHub auth from an environment.')
@click.argument('name')
def github_disable_command(name:str)->None:raise click.exceptions.Exit(handle_github_disable(name))
@github_group.command('status',help='Show GitHub auth status on an environment.')
@click.argument('name')
def github_status_command(name:str)->None:raise click.exceptions.Exit(handle_github_status(name))
def _repo_add_options(func):A=func;A=click.argument('directory',type=click.Path(exists=True,file_okay=False,path_type=str))(A);A=click.option('--env','env_name',type=str,help='Target environment name for the remote clone.')(A);A=click.option('--local-only',is_flag=True,help='Skip the control plane POST; print what would have been sent.')(A);A=click.option('--yes','auto_approve',is_flag=True,help='Accept the default classification without an interactive review.')(A);A=click.option('--no-env','skip_env',is_flag=True,help='Skip env var discovery entirely.')(A);return A
def _run_repo_add(directory:str,local_only:bool,auto_approve:bool,skip_env:bool,env_name:str|None)->None:
	B=local_only;A=directory;C:str|None=None;D:str|None=None;E:str|None=None;F:str|None=None
	if not B:C,D,E,F=_resolve_repo_add_env(A,env_name)
	raise click.exceptions.Exit(handle_repo_add(A,local_only=B,auto_approve=auto_approve,skip_env=skip_env,target_env_id=C,target_env_name=D,target_env_url=E,target_env_vm_user=F))
@repo_group.command('add',help='Register a repo with the control plane.')
@_repo_add_options
def repo_add_command(directory:str,env_name:str|None,local_only:bool,auto_approve:bool,skip_env:bool)->None:_run_repo_add(directory,local_only,auto_approve,skip_env,env_name)
@project_group.command('add',help='Alias for `gv repo add`.')
@_repo_add_options
def project_add_command(directory:str,env_name:str|None,local_only:bool,auto_approve:bool,skip_env:bool)->None:_run_repo_add(directory,local_only,auto_approve,skip_env,env_name)
def _run_repo_list(json_out:bool)->None:raise click.exceptions.Exit(handle_repo_list(json_out=json_out))
@repo_group.command('list',help='List repos you have registered.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def repo_list_command(json_out:bool)->None:_run_repo_list(json_out)
@project_group.command('list',help='Alias for `gv repo list`.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def project_list_command(json_out:bool)->None:_run_repo_list(json_out)
@repo_group.group('env',help='Manage env vars / secrets on a repo.')
def repo_env_group()->None:0
@project_group.group('env',help='Alias for `gv repo env`.')
def project_env_group()->None:0
def _repo_flag(func):return click.option('--repo','repo',default=None,help='Repo id (or id-prefix / name). Defaults to the repo at $PWD.')(func)
def _run_repo_onboard(repo:str|None)->None:raise click.exceptions.Exit(handle_repo_onboard(repo=repo))
@repo_group.command('onboard',help='Re-run backend onboarding for an already-registered repo.')
@_repo_flag
def repo_onboard_command(repo:str|None)->None:_run_repo_onboard(repo)
@project_group.command('onboard',help='Alias for `gv repo onboard`.')
@_repo_flag
def project_onboard_command(repo:str|None)->None:_run_repo_onboard(repo)
def _env_list_options(func):A=func;A=click.option('--json','json_out',is_flag=True,help='Emit JSON.')(A);A=click.option('--reveal',is_flag=True,help='Show secret values in plaintext.')(A);A=_repo_flag(A);return A
def _run_env_list(repo:str|None,reveal:bool,json_out:bool)->None:raise click.exceptions.Exit(handle_env_list(repo=repo,reveal=reveal,json_out=json_out))
@repo_env_group.command('list',help='List env vars / secrets on a repo.')
@_env_list_options
def repo_env_list_command(repo:str|None,reveal:bool,json_out:bool)->None:_run_env_list(repo,reveal,json_out)
@project_env_group.command('list',help='Alias for `gv repo env list`.')
@_env_list_options
def project_env_list_command(repo:str|None,reveal:bool,json_out:bool)->None:_run_env_list(repo,reveal,json_out)
def _env_add_options(func):A=func;A=click.argument('assignment')(A);A=click.option('--source',default='.env',show_default=True,help='Source path recorded with the entry (relative to repo root).')(A);A=click.option('--secret/--plain','mark_secret',default=None,help="Override auto-classification. If unset, the CLI's classifier decides.")(A);A=_repo_flag(A);return A
def _run_env_add(repo:str|None,assignment:str,source:str,mark_secret:bool|None)->None:raise click.exceptions.Exit(handle_env_add(repo=repo,assignment=assignment,source=source,mark_secret=mark_secret))
@repo_env_group.command('add',help='Upsert an env var on a repo (KEY=VALUE).')
@_env_add_options
def repo_env_add_command(repo:str|None,assignment:str,source:str,mark_secret:bool|None)->None:_run_env_add(repo,assignment,source,mark_secret)
@project_env_group.command('add',help='Alias for `gv repo env add`.')
@_env_add_options
def project_env_add_command(repo:str|None,assignment:str,source:str,mark_secret:bool|None)->None:_run_env_add(repo,assignment,source,mark_secret)
def _env_rm_options(func):A=func;A=click.argument('key')(A);A=click.option('--source',default=None,help='Restrict delete to this source path. Required if the key is ambiguous.')(A);A=click.option('--yes','yes',is_flag=True,help='Skip the confirmation prompt.')(A);A=_repo_flag(A);return A
def _run_env_rm(repo:str|None,key:str,source:str|None,yes:bool)->None:raise click.exceptions.Exit(handle_env_rm(repo=repo,key=key,source=source,yes=yes))
@repo_env_group.command('rm',help='Delete an env var from a repo.')
@_env_rm_options
def repo_env_rm_command(repo:str|None,key:str,source:str|None,yes:bool)->None:_run_env_rm(repo,key,source,yes)
@project_env_group.command('rm',help='Alias for `gv repo env rm`.')
@_env_rm_options
def project_env_rm_command(repo:str|None,key:str,source:str|None,yes:bool)->None:_run_env_rm(repo,key,source,yes)
@cli.group('profile',cls=OrderedGroup,help='Capture your local dev environment.')
def profile_group()->None:0
@profile_group.command('show',help='Print your locally-detected profile. No upload.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_show_command(json_out:bool)->None:handle_profile_show(json_out)
@profile_group.command('push',help='Upload your local profile to the control plane.')
@click.option('--env','env_name',default=None,help='After pushing, install the profile on this env (runs async on the control plane).')
@click.option('--no-wait','no_wait',is_flag=True,help='With --env, return immediately instead of polling the job until it finishes.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_push_command(env_name:str|None,no_wait:bool,json_out:bool)->None:
	B=no_wait;A=env_name
	if B and A is None:raise click.UsageError('--no-wait only makes sense with --env.')
	handle_profile_push(json_out=json_out,env_name=A,no_wait=B)
@profile_group.command('apply',help='Install the pushed profile on an env (without re-pushing).')
@click.argument('env_name')
@click.option('--no-wait','no_wait',is_flag=True,help='Return immediately instead of polling the job until it finishes.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_apply_command(env_name:str,no_wait:bool,json_out:bool)->None:handle_profile_apply(env_name,json_out=json_out,no_wait=no_wait)
@profile_group.command('job',help='Show status of a profile-apply job.')
@click.argument('job_id')
@click.option('--watch',is_flag=True,help='Poll until the job finishes.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_job_command(job_id:str,watch:bool,json_out:bool)->None:handle_profile_job(job_id,json_out=json_out,watch=watch)
@profile_group.command('pull',help='Fetch the profile stored on the control plane.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_pull_command(json_out:bool)->None:handle_profile_pull(json_out)
def main()->int:
	try:cli.main(args=sys.argv[1:],prog_name='gv',standalone_mode=False);return 0
	except click.ClickException as A:A.show();return A.exit_code
	except click.exceptions.Exit as A:return A.exit_code
	except KeyboardInterrupt:click.echo('',err=True);return 130
	except RuntimeError as A:click.echo(str(A),err=True);return 1
if __name__=='__main__':raise SystemExit(main())