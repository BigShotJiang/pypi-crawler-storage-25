from __future__ import annotations
import os,re
from dataclasses import dataclass
from pathlib import Path
ENV_FILENAMES:frozenset[str]=frozenset({'.env','.env.local','.env.development','.env.development.local','.env.test','.env.test.local','.env.production','.env.production.local'})
PRUNE_DIRS:frozenset[str]=frozenset({'.git','.hg','.svn','node_modules','dist','build','.next','.turbo','.cache','.venv','venv','env','target','.tox','.mypy_cache','.pytest_cache','__pycache__','.gradle','.idea','.vscode'})
MAX_DEPTH=10
_ENV_KEY_RE=re.compile('^[A-Za-z_][A-Za-z0-9_]*$')
@dataclass(frozen=True)
class RawEnvVar:key:str;value:str;source_path:str
def parse_env_file(path:Path)->dict[str,str]:
	try:B=path.read_text(encoding='utf-8')
	except OSError:return{}
	if B.startswith('\ufeff'):B=B[1:]
	D:dict[str,str]={}
	for F in B.splitlines():
		C=F.strip()
		if not C or C.startswith('#'):continue
		A=C
		if A.startswith('export '):A=A[len('export '):].strip()
		if'='not in A:continue
		G,H=A.split('=',maxsplit=1);E=G.strip()
		if not _ENV_KEY_RE.match(E):continue
		D[E]=_parse_value(H)
	return D
def _parse_value(value:str)->str:
	A=value.strip()
	if len(A)>=2 and A[0]==A[-1]and A[0]in{'"',"'"}:return A[1:-1]
	return A
def discover_env_files(repo_root:Path)->list[Path]:
	A=repo_root.resolve();B:list[Path]=[];F=len(A.parts)
	for(G,C,H)in os.walk(A,followlinks=False):
		D=Path(G);I=len(D.parts)-F;C[:]=sorted(A for A in C if A not in PRUNE_DIRS and not A.startswith('.git'))
		if I>=MAX_DEPTH:C[:]=[]
		for E in sorted(H):
			if E in ENV_FILENAMES:B.append(D/E)
	def J(p:Path)->tuple[int,str]:return len(p.relative_to(A).parts),p.relative_to(A).as_posix()
	B.sort(key=J);return B
def collect_env_vars(repo_root:Path)->list[RawEnvVar]:
	A=repo_root.resolve();D=discover_env_files(A);B:list[RawEnvVar]=[]
	for C in D:
		E=C.relative_to(A).as_posix()
		for(F,G)in sorted(parse_env_file(C).items()):B.append(RawEnvVar(key=F,value=G,source_path=E))
	return B