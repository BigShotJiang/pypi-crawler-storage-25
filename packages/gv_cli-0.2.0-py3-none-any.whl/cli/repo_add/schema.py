from __future__ import annotations
from pydantic import BaseModel,ConfigDict,Field
from pydantic.alias_generators import to_camel
class _WireModel(BaseModel):model_config=ConfigDict(alias_generator=to_camel,populate_by_name=True,extra='ignore')
class EnvVarEntry(_WireModel):key:str=Field(min_length=1);value:str;source_path:str=Field(min_length=1);is_secret:bool
class GitInfo(_WireModel):remote_url:str|None=None;active_branch:str|None=None;default_branch:str|None=None
class RepoAddRequest(_WireModel):local_path:str=Field(min_length=1);name:str=Field(min_length=1);target_env_id:str|None=None;git_remote_url:str|None=None;active_branch:str|None=None;default_branch:str|None=None;env_vars:list[EnvVarEntry]=Field(default_factory=list)
class RepoAddOutcome(BaseModel):exit_code:int;repo_name:str;target_env_name:str|None=None;target_env_url:str|None=None;target_env_vm_user:str|None=None;opencode_session_url:str|None=None;opencode_session_id:str|None=None;git_remote_url:str|None=None;env_captured:int=0;secrets_captured:int=0;env_sources:list[str]=Field(default_factory=list);backend_sync_error:str|None=None;sync_status:str|None=None;sync_step:str|None=None;skipped_env:bool=False;dry_run:bool=False