from __future__ import annotations
import math,re
from collections import Counter
SECRET_KEY_PATTERNS:tuple[re.Pattern[str],...]=(re.compile('(?i)(TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL|PRIVATE|DSN|SIGNATURE)'),re.compile('(?i)(API[_-]?KEY|ACCESS[_-]?KEY|SECRET[_-]?KEY|AUTH[_-]?KEY)'),re.compile('(?i)(SESSION[_-]?(ID|KEY)|COOKIE[_-]?(SECRET|KEY))'),re.compile('(?i)(CERT|CERTIFICATE)[_-]?(KEY|PEM|DATA)?'))
PUBLIC_KEY_PATTERNS:tuple[re.Pattern[str],...]=(re.compile('(?i)^NEXT_PUBLIC_'),re.compile('(?i)^VITE_PUBLIC_'),re.compile('(?i)^REACT_APP_PUBLIC_'),re.compile('(?i)^PUBLIC_'),re.compile('(?i)(PUBLIC[_-]KEY|PUBKEY)'))
ENTROPY_MIN_LEN=20
ENTROPY_MIN_BITS=4.
_ALNUM_RUN=re.compile('^[A-Za-z0-9+/_=\\-\\.]+$')
_URL_WITH_CREDS=re.compile('^[a-zA-Z][a-zA-Z0-9+\\-.]*://[^/@\\s:]+:[^/@\\s]+@')
def shannon_entropy(value:str)->float:
	A=value
	if not A:return .0
	C=Counter(A);B=len(A);return-sum(A/B*math.log2(A/B)for A in C.values())
def _key_looks_secret(key:str)->bool:
	for A in PUBLIC_KEY_PATTERNS:
		if A.search(key):return False
	for B in SECRET_KEY_PATTERNS:
		if B.search(key):return True
	return False
def _value_looks_secret(value:str)->bool:
	A=value
	if len(A)<ENTROPY_MIN_LEN:return False
	if' 'in A:return False
	if not _ALNUM_RUN.match(A):return False
	return shannon_entropy(A)>=ENTROPY_MIN_BITS
def _url_embeds_credentials(value:str)->bool:return _URL_WITH_CREDS.match(value)is not None
def classify(key:str,value:str)->bool:
	A=value
	if _key_looks_secret(key):return True
	if _url_embeds_credentials(A):return True
	return _value_looks_secret(A)