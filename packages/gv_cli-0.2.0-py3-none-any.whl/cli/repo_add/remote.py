from __future__ import annotations
import subprocess
from pathlib import Path
from.schema import GitInfo
def read_git_info(repo_root:Path)->GitInfo:A=repo_root;return GitInfo(remote_url=_run(A,['git','remote','get-url','origin']),active_branch=_run(A,['git','rev-parse','--abbrev-ref','HEAD']),default_branch=_default_branch(A))
def _default_branch(repo_root:Path)->str|None:
	B=repo_root;A=_run(B,['git','symbolic-ref','refs/remotes/origin/HEAD'])
	if A and A.startswith('refs/remotes/origin/'):return A[len('refs/remotes/origin/'):]
	for C in('main','master'):
		D=_run(B,['git','rev-parse','--verify',f"refs/heads/{C}"])
		if D:return C
def _run(repo_root:Path,args:list[str])->str|None:
	try:A=subprocess.run(args,cwd=str(repo_root),capture_output=True,text=True,check=False,timeout=5)
	except(OSError,subprocess.SubprocessError):return
	if A.returncode!=0:return
	B=A.stdout.strip();return B or None