from __future__ import annotations
import asyncio,os,re,shutil,subprocess
from dataclasses import dataclass
from typing import Any,Protocol
import click,httpx
from.import remote_workspaces
MINIMUM_OPENCODE_VERSION=1,14,11
MINIMUM_OPENCODE_VERSION_TEXT='.'.join(str(A)for A in MINIMUM_OPENCODE_VERSION)
class EnvLike(Protocol):name:str;url:str|None;opencode_username:str;opencode_password:str
@dataclass(frozen=True)
class SessionRecord:id:str;title:str;directory:str;updated_at:int
@dataclass(frozen=True)
class LaunchChoice:
	project_label:str;workspace_label:str;directory:str;session_id:str|None;session_title:str|None
	@property
	def is_new_session(self)->bool:return self.session_id is None
def handle_opencode(env:EnvLike)->int:
	A=env;ensure_local_opencode_installed();validate_env_supports_attach(A)
	try:B=asyncio.run(discover_launch_choices(A))
	except httpx.HTTPError as C:raise RuntimeError(f"Failed to query remote OpenCode: {C}")from C
	if not B:raise RuntimeError('OpenCode has no known projects in this environment yet. Open the web UI first to initialize one.')
	D=choose_launch_choice(A.name,B);exec_attach(A,D);return 0
def ensure_local_opencode_installed()->None:
	B=shutil.which('opencode')
	if not B:raise RuntimeError('OpenCode CLI is not installed locally. Install it with `curl -fsSL https://opencode.ai/install | bash` and try again.')
	try:A=subprocess.run([B,'--version'],check=False,capture_output=True,text=True,timeout=10)
	except OSError as C:raise RuntimeError(f"OpenCode CLI is installed at `{B}` but could not be executed: {C}. Reinstall it with `curl -fsSL https://opencode.ai/install | bash`.")from C
	except subprocess.TimeoutExpired as C:raise RuntimeError(f"OpenCode CLI at `{B}` did not respond to `opencode --version`. Reinstall or upgrade it with `curl -fsSL https://opencode.ai/install | bash`.")from C
	if A.returncode==0:
		D=(A.stdout or A.stderr).strip();E=_parse_opencode_version(D)
		if E is None:G=D or'<empty output>';raise RuntimeError(f"OpenCode CLI at `{B}` returned an unrecognized version string `{G}`. Upgrade it to {MINIMUM_OPENCODE_VERSION_TEXT} or newer with `curl -fsSL https://opencode.ai/install | bash`.")
		if E<MINIMUM_OPENCODE_VERSION:raise RuntimeError(f"OpenCode CLI at `{B}` is too old ({D}). Version {MINIMUM_OPENCODE_VERSION_TEXT} or newer is required. Upgrade it with `curl -fsSL https://opencode.ai/install | bash`.")
		return
	H=f"signal {-A.returncode}"if A.returncode<0 else f"exit code {A.returncode}";F=(A.stderr or A.stdout).strip();I=f" {F}"if F else'';raise RuntimeError(f"OpenCode CLI at `{B}` failed to run `opencode --version` ({H}).{I} Reinstall or upgrade it with `curl -fsSL https://opencode.ai/install | bash`.")
def validate_env_supports_attach(env:EnvLike)->None:
	if not env.url:raise RuntimeError('Environment does not have an OpenCode URL yet.')
	if env.opencode_username!='opencode':raise RuntimeError('This environment uses a non-default OpenCode username. `opencode attach` currently requires username `opencode`.')
async def discover_launch_choices(env:EnvLike)->list[LaunchChoice]:
	B=env
	async with httpx.AsyncClient(timeout=15,auth=httpx.BasicAuth(B.opencode_username,B.opencode_password))as D:E=await remote_workspaces.fetch_workspace_records(D,B.url or'');G=await asyncio.gather(*(fetch_sessions(D,B.url or'',A.directory)for A in E))
	C:list[LaunchChoice]=[]
	for(A,H)in zip(E,G,strict=True):
		for F in H:C.append(LaunchChoice(project_label=A.project_label,workspace_label=A.workspace_label,directory=A.directory,session_id=F.id,session_title=F.title))
		C.append(LaunchChoice(project_label=A.project_label,workspace_label=A.workspace_label,directory=A.directory,session_id=None,session_title=None))
	return C
async def fetch_sessions(client:httpx.AsyncClient,base_url:str,directory:str)->list[SessionRecord]:
	D=await client.get(f"{base_url.rstrip("/")}/session",params={'directory':directory});D.raise_for_status();I=D.json();J=_extract_items(I,singular='session',plural='sessions');B:list[SessionRecord]=[]
	for A in J:
		if _string(A.get('parentID')):continue
		C=A.get('time')
		if not isinstance(C,dict):continue
		if C.get('archived')is not None:continue
		E=_string(A.get('id'));F=_string(A.get('title'));G=_string(A.get('directory'));H=_int_value(C.get('updated'))
		if not E or not F or not G or H is None:continue
		B.append(SessionRecord(id=E,title=F,directory=G,updated_at=H))
	B.sort(key=lambda session:(-session.updated_at,session.title.lower(),session.id));return B
def choose_launch_choice(env_name:str,choices:list[LaunchChoice])->LaunchChoice:
	B=choices;click.echo(f"\nOpenCode sessions for {env_name}\n");D:str|None=None;C:tuple[str,str]|None=None
	for(E,A)in enumerate(B,start=1):
		if A.project_label!=D:D=A.project_label;C=None;click.echo(remote_workspaces.display_directory(_project_directory_for_choice(A,B)))
		F=A.project_label,A.workspace_label
		if F!=C:C=F;click.echo(f"  {A.workspace_label}")
		if A.is_new_session:click.echo(f"    [{E}] New session")
		else:click.echo(f"    [{E}] Resume: {A.session_title}")
	if len(B)==1:return B[0]
	G=click.prompt('Choose a session (input number)',type=click.IntRange(1,len(B)));return B[G-1]
def exec_attach(env:EnvLike,choice:LaunchChoice)->None:
	A=choice;B=['opencode','attach',env.url or'','--dir',A.directory]
	if A.session_id:B.extend(['--session',A.session_id])
	C=os.environ.copy();C['OPENCODE_SERVER_PASSWORD']=env.opencode_password;os.execvpe(B[0],B,C)
def _project_directory_for_choice(choice:LaunchChoice,choices:list[LaunchChoice])->str:
	B=choice
	for A in choices:
		if A.project_label==B.project_label and A.workspace_label=='main':return A.directory
	return B.directory
def _extract_items(payload:Any,*,singular:str,plural:str)->list[dict[str,Any]]:
	C=plural;A=payload
	if isinstance(A,list):return[A for A in A if isinstance(A,dict)]
	if isinstance(A,dict):
		for D in(C,singular):
			B=A.get(D)
			if isinstance(B,list):return[A for A in B if isinstance(A,dict)]
			if isinstance(B,dict):return[B]
	raise RuntimeError(f"OpenCode returned an invalid {C} response.")
def _string(value:Any)->str|None:
	A=value
	if A is None:return
	B=str(A);return B or None
def _int_value(value:Any)->int|None:
	A=value
	if A is None:return
	try:return int(A)
	except(TypeError,ValueError):return
def _parse_opencode_version(output:str)->tuple[int,int,int]|None:
	A=re.search('(?<!\\d)(\\d+)\\.(\\d+)\\.(\\d+)(?!\\d)',output)
	if not A:return
	return tuple(int(A)for A in A.groups())