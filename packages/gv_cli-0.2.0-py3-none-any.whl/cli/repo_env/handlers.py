from __future__ import annotations
import json as json_lib,time
from dataclasses import dataclass
from typing import Any
import click
from..repo_add.classify import classify
from.client import delete_json,get_json,post_json
from.format import build_opencode_session_url,format_opencode_hints,preview_value,render_table,short_id
from.resolve import RepoRef,list_repos,resolve_repo
@dataclass(frozen=True)
class TargetEnvInfo:id:str;name:str|None;url:str|None;vm_user:str|None
def _repo_open_url(repo:RepoRef,target_env:TargetEnvInfo|None)->str|None:
	B=repo;A=target_env
	if A is None:return
	if B.opencode_session_id:return build_opencode_session_url(A.url,A.vm_user,B.name,B.opencode_session_id,workspace_name='onboarding')
	return build_opencode_session_url(A.url,A.vm_user,B.name)
def _echo_target(repo_name:str,repo_id:str)->None:click.echo(f"Repo: {repo_name} ({short_id(repo_id)})")
def _list_target_envs()->dict[str,TargetEnvInfo]:
	H=get_json('/v1/envs');B=H.get('envs')
	if not isinstance(B,list):return{}
	C:dict[str,TargetEnvInfo]={}
	for A in B:
		if not isinstance(A,dict)or'id'not in A:continue
		D=str(A['id']);E=A.get('name');F=A.get('url');G=A.get('vmUsername')or A.get('opencodeUsername');C[D]=TargetEnvInfo(id=D,name=str(E)if E else None,url=str(F)if F else None,vm_user=str(G)if G else None)
	return C
def handle_repo_onboard(repo:str|None)->int:
	C=resolve_repo(repo);F=_list_target_envs();B=F.get(C.target_env_id or'');G=post_json(f"/v1/repos/{C.id}/onboard",{});D=G.get('repo')
	if not isinstance(D,dict):raise RuntimeError('Control plane returned an invalid repo response.')
	A=RepoRef.from_payload(D);A=_poll_repo_onboarding(A);click.echo('');click.echo(f"Repo: {A.name}")
	if B and B.name:click.echo(f"Target env: {B.name}")
	E=_repo_open_url(A,B)
	if E:
		for H in format_opencode_hints(E,A.name,has_session_id=bool(A.opencode_session_id)):click.echo(H)
	if A.git_remote_url:click.echo(f"Remote: {A.git_remote_url}")
	if A.sync_error_message:click.echo(f"Backend sync failed: {A.sync_error_message}",err=True);return 1
	click.echo('Backend sync: ok');click.echo(f"Remote sync: {A.sync_status}"+(f" ({A.sync_step})"if A.sync_step else''))
	if A.sync_status not in{'ready','failed'}:click.echo('Remote sync is still running. You do not need to wait.');click.echo('Check progress later with `gv repo list`.')
	return 0
def _poll_repo_onboarding(repo:RepoRef,*,timeout_seconds:float=8.,interval_seconds:float=1.)->RepoRef:
	A=repo
	if A.sync_status in{'ready','failed'}:return A
	C=time.monotonic()+timeout_seconds
	while time.monotonic()<C:
		time.sleep(interval_seconds);D=get_json(f"/v1/repos/{A.id}");B=D.get('repo')
		if not isinstance(B,dict):break
		A=RepoRef.from_payload(B)
		if A.sync_status in{'ready','failed'}:return A
	return A
def handle_repo_list(json_out:bool)->int:
	A=list_repos();B=_list_target_envs()
	if json_out:click.echo(json_lib.dumps([{'id':A.id,'owner':A.git_owner,'name':A.name,'gitRemoteUrl':A.git_remote_url,'localPath':A.local_path,'targetEnvId':A.target_env_id,'activeBranch':A.active_branch,'defaultBranch':A.default_branch,'envVarCount':A.env_var_count,'secretCount':A.secret_count,'syncStatus':A.sync_status,'syncStep':A.sync_step,'syncErrorMessage':A.sync_error_message,'opencodeSessionUrl':_repo_open_url(A,B.get(A.target_env_id or''))}for A in A],indent=2));return 0
	if not A:click.echo('No repos registered. Run `gv repo add <dir>` to register one.');return 0
	C=[[short_id(A.id),A.git_owner or'-',A.name,A.local_path,A.active_branch or'-',f"{A.env_var_count} ({A.secret_count} secret)",A.sync_status,A.sync_step,_repo_open_url(A,B.get(A.target_env_id or''))or'-']for A in A];click.echo(render_table(C,['ID','OWNER','NAME','LOCAL_PATH','BRANCH','ENV_VARS','STATUS','STEP','OPEN_URL']));return 0
def handle_env_list(repo:str|None,reveal:bool,json_out:bool)->int:
	C=reveal;B=resolve_repo(repo);D=get_json(f"/v1/repos/{B.id}/env-vars");A:list[dict[str,Any]]=D.get('envVars')or[]
	if json_out:
		if not C:A=[{**A,'value':'********'if A.get('isSecret')else A.get('value')}for A in A]
		click.echo(json_lib.dumps({'repo':B.name,'envVars':A},indent=2));return 0
	_echo_target(B.name,B.id)
	if not A:click.echo('No env vars captured yet.');return 0
	E=sorted(A,key=lambda v:(0 if v.get('isSecret')else 1,str(v.get('key',''))));F=[['secret'if A.get('isSecret')else'plain',str(A.get('key','')),str(A.get('sourcePath','')),preview_value(str(A.get('value','')),bool(A.get('isSecret')),reveal=C)]for A in E];click.echo(render_table(F,['TYPE','KEY','SOURCE','VALUE']));return 0
def _parse_assignment(assignment:str)->tuple[str,str]:
	B=assignment
	if'='not in B:raise RuntimeError(f"Expected KEY=VALUE, got {B!r}. Example: FEATURE_X=on")
	A,C=B.split('=',1);A=A.strip()
	if not A:raise RuntimeError('Env var key cannot be empty.')
	return A,C
def handle_env_add(repo:str|None,assignment:str,source:str,mark_secret:bool|None)->int:D=mark_secret;C=source;A,E=_parse_assignment(assignment);F=classify(A,E)if D is None else D;B=resolve_repo(repo);_echo_target(B.name,B.id);post_json(f"/v1/repos/{B.id}/env-vars",{'key':A,'value':E,'sourcePath':C,'isSecret':F});G='secret'if F else'plain';click.echo(f"Saved {A} as {G} in {C}.");return 0
def handle_env_rm(repo:str|None,key:str,source:str|None,yes:bool)->int:
	C=key;A=source;B=resolve_repo(repo);_echo_target(B.name,B.id);D=f" (source: {A})"if A else''
	if not yes and not click.confirm(f"Remove {C}{D} from {B.name}?",default=False):click.echo('Aborted.');return 0
	E={'sourcePath':A}if A else None;F=delete_json(f"/v1/repos/{B.id}/env-vars/{C}",params=E);G=int(F.get('deleted',0));click.echo(f"Removed {G} row(s) for {C}.");return 0