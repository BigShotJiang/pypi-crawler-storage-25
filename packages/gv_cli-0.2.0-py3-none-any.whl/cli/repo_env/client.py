from __future__ import annotations
from typing import Any
import httpx
from..http_client import api_base_url,auth_headers,raise_for_response
def get_json(path:str,*,params:dict[str,Any]|None=None)->dict[str,Any]:
	with httpx.Client(timeout=30,headers=auth_headers())as B:A=B.get(f"{api_base_url()}{path}",params=params)
	raise_for_response(A);return A.json()
def post_json(path:str,body:dict[str,Any])->dict[str,Any]:
	with httpx.Client(timeout=30,headers=auth_headers())as B:A=B.post(f"{api_base_url()}{path}",json=body)
	raise_for_response(A);return A.json()
def delete_json(path:str,*,params:dict[str,Any]|None=None)->dict[str,Any]:
	with httpx.Client(timeout=30,headers=auth_headers())as B:A=B.delete(f"{api_base_url()}{path}",params=params)
	raise_for_response(A);return A.json()