from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
import os,shutil,subprocess
from pathlib import Path
def _read_git_config(key:str)->str:
	try:A=subprocess.run(['git','config','--global','--get',key],check=True,capture_output=True,text=True,timeout=2)
	except(FileNotFoundError,OSError,subprocess.CalledProcessError,subprocess.TimeoutExpired):return''
	return A.stdout.strip()
TOOLS:list[str]=['vim','nvim','emacs','helix','zsh','fish','tmux','screen','zellij','ack','rg','fd','fzf','bat','eza','tree','jq','yq','git','gh','glab','lazygit','node','go','rustc','ruby','java','deno','bun','pyenv','rbenv','mise','uv','pipx','cargo','pip','poetry','pnpm','yarn','npm','docker','kubectl','helm','terraform','aws','gcloud','flyctl','psql','redis-cli','sqlite3','curl','wget','htop','btop','direnv','make']
GIT_KEYS:tuple[tuple[str,str],...]=(('gitUserName','user.name'),('gitUserEmail','user.email'),('gitCoreEditor','core.editor'),('gitPullRebase','pull.rebase'))
VERSION_PROBE_TIMEOUT_SECONDS=1.5
MAX_VERSION_PROBE_WORKERS=8
def detect_shell()->str|None:A=os.environ.get('SHELL','').strip();return A or None
def detect_editor()->str|None:
	for B in('VISUAL','EDITOR'):
		A=os.environ.get(B,'').strip()
		if A:return A
_VERSION_COMMANDS:dict[str,tuple[str,...]]={'go':('version',),'kubectl':('version','--client'),'screen':('-v',),'tmux':('-V',)}
def _version_command(name:str)->tuple[str,...]:return _VERSION_COMMANDS.get(name,('--version',))
def _nonzero_version_output_ok(name:str,first_line:str)->bool:return name=='screen'and first_line.startswith('Screen version ')
def _probe_version(name:str,binary:str)->str|None:
	try:A=subprocess.run([binary,*_version_command(name)],capture_output=True,text=True,timeout=VERSION_PROBE_TIMEOUT_SECONDS,check=False,stdin=subprocess.DEVNULL,start_new_session=True)
	except(FileNotFoundError,OSError,subprocess.TimeoutExpired):return
	C=(A.stdout or A.stderr or'').strip()
	if not C:return
	B=C.splitlines()[0].strip()
	if not B:return
	if A.returncode==0 or _nonzero_version_output_ok(name,B):return B
def _detect_one_tool(name:str,binary:str)->dict[str,str|None]:return{'name':name,'version':_probe_version(name,binary)}
def detect_tools()->list[dict[str,str|None]]:
	A=[(A,C)for A in TOOLS if(C:=shutil.which(A))];B:list[dict[str,str|None]]=[]
	if A:
		D=min(MAX_VERSION_PROBE_WORKERS,len(A))
		with ThreadPoolExecutor(max_workers=D)as E:F=[E.submit(_detect_one_tool,A,B)for(A,B)in A];B=[A.result()for A in F]
	B.extend(_detect_shell_function_tools());return B
_SHELL_FUNCTION_MARKERS:tuple[tuple[str,str],...]=(('nvm','.nvm/nvm.sh'),('asdf','.asdf/asdf.sh'))
def _detect_shell_function_tools()->list[dict[str,str|None]]:
	B=Path.home();A:list[dict[str,str|None]]=[]
	for(C,D)in _SHELL_FUNCTION_MARKERS:
		if(B/D).is_file():A.append({'name':C,'version':None})
	return A
def detect_git_config()->dict[str,str|None]:
	A:dict[str,str|None]={}
	for(B,C)in GIT_KEYS:D=_read_git_config(C);A[B]=D or None
	return A