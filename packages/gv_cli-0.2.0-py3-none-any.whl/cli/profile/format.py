from __future__ import annotations
from typing import Any
from..repo_env.format import render_table
def render_profile(profile:dict[str,Any])->str:
	B=profile;A:list[str]=[];A.append('# Shell & editor');A.append(f"  shell         {B.get("shell")or"-"}");A.append(f"  editor        {B.get("editor")or"-"}");A.append('');A.append('# Git config');A.append(f"  user.name     {B.get("gitUserName")or"-"}");A.append(f"  user.email    {B.get("gitUserEmail")or"-"}");A.append(f"  core.editor   {B.get("gitCoreEditor")or"-"}");A.append(f"  pull.rebase   {B.get("gitPullRebase")or"-"}");A.append('');C=B.get('tools')or[];A.append(f"# Tools ({len(C)})")
	if C:D=[[str(A.get('name','')),str(A.get('version')or'-')]for A in sorted(C,key=lambda t:str(t.get('name','')))];A.append(render_table(D,['TOOL','VERSION']))
	else:A.append('  (none detected)')
	return'\n'.join(A)