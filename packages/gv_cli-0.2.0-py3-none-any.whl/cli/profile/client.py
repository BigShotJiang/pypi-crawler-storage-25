from __future__ import annotations
from typing import Any
import httpx
from..http_client import api_base_url,auth_headers,raise_for_response
class ProfileNotFound(RuntimeError):0
def get_profile()->dict[str,Any]:
	with httpx.Client(timeout=30,headers=auth_headers())as B:A=B.get(f"{api_base_url()}/v1/profile")
	raise_for_response(A,error_factories={404:ProfileNotFound});return A.json()
def put_profile(body:dict[str,Any])->dict[str,Any]:
	with httpx.Client(timeout=30,headers=auth_headers())as B:A=B.put(f"{api_base_url()}/v1/profile",json=body)
	raise_for_response(A);return A.json()
def create_profile_apply_job(env_name:str)->dict[str,Any]:
	with httpx.Client(timeout=30,headers=auth_headers())as B:A=B.post(f"{api_base_url()}/v1/profile/apply",json={'envName':env_name})
	raise_for_response(A);return A.json()
def get_profile_job(job_id:str)->dict[str,Any]:
	with httpx.Client(timeout=30,headers=auth_headers())as B:A=B.get(f"{api_base_url()}/v1/profile/jobs/{job_id}")
	raise_for_response(A);return A.json()