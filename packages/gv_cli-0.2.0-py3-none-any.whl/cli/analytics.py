from __future__ import annotations
import getpass,logging,os
from dataclasses import dataclass
from pathlib import Path
try:from posthog import Posthog
except ImportError:Posthog=None
DEFAULT_POSTHOG_HOST='https://eu.i.posthog.com'
@dataclass(frozen=True)
class _PostHogConfig:api_key:str|None;host:str
def capture_repo_add_unsupported(*,directory:Path,reason:str,local_only:bool)->None:
	B=directory
	if Posthog is None:return
	A=_load_posthog_config()
	if not A.api_key:return
	try:C=Posthog(project_api_key=A.api_key,host=A.host);C.capture(distinct_id=_distinct_id(),event='gv_repo_add_unsupported',properties={'source':'gv_cli','reason':reason,'local_only':local_only,'directory':str(B),'repo_name':B.name});C.shutdown()
	except Exception as D:logging.getLogger(__name__).debug('analytics capture failed: %s',D)
def _load_posthog_config()->_PostHogConfig:A=os.getenv('GV_POSTHOG_API_KEY','').strip()or os.getenv('POSTHOG_API_KEY','').strip()or None;B=os.getenv('GV_POSTHOG_HOST','').strip()or os.getenv('POSTHOG_HOST','').strip()or DEFAULT_POSTHOG_HOST;return _PostHogConfig(api_key=A,host=B)
def _distinct_id()->str:
	try:A=getpass.getuser().strip()
	except Exception:A=''
	if A:return f"gv-cli:{A}"
	return'gv-cli:unknown'