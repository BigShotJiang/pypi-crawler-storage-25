import os

def interactive_list(folder_path):
    # Get a list of all Python files (excluding dunder methods)
    files = [
        f for f in os.listdir(folder_path)
        if f.endswith(".py") and not f.startswith("__")
    ]
    
    # Sort the files alphabetically
    files.sort()

    if not files:
        print("No code files found.")
        return

    print("\nSelect a file to view:\n")

    # Display the files with a number assigned to each one
    for idx, file in enumerate(files, start=1):
        print(f"{idx}. {file}")

    try:
        # Prompt user for input to select a file by number
        choice = int(input("\nEnter your choice (number): "))
        
        # Validate input to ensure it's within the correct range
        if choice < 1 or choice > len(files):
            raise ValueError
    except ValueError:
        print("Invalid selection. Please enter a valid number.")
        return

    # Get the path of the selected file
    selected_file = files[choice - 1]
    file_path = os.path.join(folder_path, selected_file)

    # Display the contents of the selected file
    print(f"\n--- Showing code of {selected_file} ---\n")
    with open(file_path, "r", encoding="utf-8") as f:
        print(f.read())