# pip install speechrecognition pydub nltk
import speech_recognition as sr
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

nltk.download('punkt')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger')
































































def asr_nlp_pipeline(audio_file):
    r = sr.Recognizer()

    try:
        with sr.AudioFile(audio_file) as source:
            audio = r.record(source)
        text = r.recognize_google(audio)
    except:
        return "Could not recognize audio", [], [], []

    tokens = word_tokenize(text.lower())
    stop_words = set(stopwords.words("english"))
    words = [w for w in tokens if w.isalpha() and w not in stop_words]

    stemmed = [PorterStemmer().stem(w) for w in words]
    pos_tags = nltk.pos_tag(words)
    return text, words, stemmed, pos_tags


























































text, words, stemmed, pos = asr_nlp_pipeline("sample.wav")

print("\nSPEECH TO TEXT:")
print(text)
print("\nFILTERED WORDS:")
print(", ".join(words))
print("\nSTEMMED WORDS:")
print(", ".join(stemmed))
print("\nPOS TAGS:")
for w, t in pos:
    print(f"{w:<10} :- {t}")
