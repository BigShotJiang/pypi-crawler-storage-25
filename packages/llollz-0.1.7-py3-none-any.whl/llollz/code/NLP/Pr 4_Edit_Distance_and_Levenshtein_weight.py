def print_dp_matrix(dp, s1, s2):
    print("\nDP Matrix:\n")
    print("    ", end="")
    print("  _", end="")
    for ch in s2:
        print(f"  {ch}", end="")
    print()

    for i in range(len(dp)):
        if i == 0:
            print("_", end="   ")
        else:
            print(s1[i - 1], end="   ")

        for j in range(len(dp[0])):
            print(dp[i][j], end="  ")
        print()

















































#EDIT DISTANCE
def edit_distance(s1, s2, print_matrix=False):
    n, m = len(s1), len(s2)
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    for i in range(n + 1):
        dp[i][0] = i
    for j in range(m + 1):
        dp[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if s1[i - 1] == s2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(
                    dp[i - 1][j],
                    dp[i][j - 1],
                    dp[i - 1][j - 1]
                )

    if print_matrix:
        print_dp_matrix(dp, s1, s2)
    return dp[n][m]




























































#WEIGHTED EDIT DISTANCE
def weighted_edit_distance(s1, s2, ins_cost=1, del_cost=1, sub_cost=2, print_matrix=False):
    n, m = len(s1), len(s2)
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    for i in range(n + 1):
        dp[i][0] = i * del_cost
    for j in range(m + 1):
        dp[0][j] = j * ins_cost
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if s1[i - 1] == s2[j - 1]:
                cost = 0
            else:
                cost = sub_cost
                
            dp[i][j] = min(
                dp[i - 1][j] + del_cost,
                dp[i][j - 1] + ins_cost,
                dp[i - 1][j - 1] + cost
            )

    if print_matrix:
        print_dp_matrix(dp, s1, s2)
    return dp[n][m]


#WORD LEVEL EDIT DISTANCE
def word_level_distance(sentence1, sentence2, print_matrix=False):
    words1 = sentence1.split()
    words2 = sentence2.split()
    return edit_distance(words1, words2, print_matrix=print_matrix)



























#MAIN PROGRAM
if __name__ == "__main__":

    s1 = "kitten"
    s2 = "sitting"

    print("Edit distance (kitten, sitting):",
          edit_distance(s1, s2, print_matrix=True))
    print("\nWeighted edit distance (kitten, sitting):",
          weighted_edit_distance(
              s1, s2,
              ins_cost=1,
              del_cost=1,
              sub_cost=2,
              print_matrix=True
          ))


















































    sentence1 = "I love natural language processing"
    sentence2 = "I enjoy learning language processing"

    print("\nWord-level edit distance:")
    print("Sentence 1:", sentence1)
    print("Sentence 2:", sentence2)
    print("Distance:",
          word_level_distance(sentence1, sentence2, print_matrix=True))
