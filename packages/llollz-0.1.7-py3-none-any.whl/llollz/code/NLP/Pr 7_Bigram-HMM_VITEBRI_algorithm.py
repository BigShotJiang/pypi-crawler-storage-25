import math

sent = ["I", "love", "cats"]
tags = ["PRON", "VERB", "NOUN"]
T = {
    "START": {"PRON": 2/3, "NOUN": 1/3},
    "PRON": {"VERB": 1},
    "VERB": {"NOUN": 2/3},
    "NOUN": {"VERB": 1}
}

E = {
    "PRON": {"I": 1/2, "You": 1/2},
    "VERB": {"love": 2/3, "meow": 1/3},
    "NOUN": {"cats": 1/2, "dogs": 1/2}
}
V = [{}]
B = [{}]
























































for t in tags:
    V[0][t] = T["START"].get(t, 0) * E.get(t, {}).get(sent[0], 0)
    B[0][t] = "START"

for i in range(1, len(sent)):
    V.append({})
    B.append({})
    for t in tags:
        prob, prev_tag = max(
            (
                V[i-1][pt] *
                T.get(pt, {}).get(t, 0) *
                E.get(t, {}).get(sent[i], 0),
                pt
            )
            for pt in tags
        )
        V[i][t] = prob
        B[i][t] = prev_tag

final_tag = max(V[-1], key=V[-1].get)









































path = [final_tag]
for i in range(len(sent) - 1, 0, -1):
    path.insert(0, B[i][path[0]])

print("\n VITERBI TAGGING OUTPUT")
for word, tag in zip(sent, path):
    print(word, ":-", tag)
