import re
from nltk.util import ngrams

def preprocess(text):
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', '', text)
    return text.split()















































def generate_ngrams(tokens, n):
    return list(ngrams(tokens, n))

def jaccard_coefficient(text1, text2, n):
    tokens1 = preprocess(text1)
    tokens2 = preprocess(text2)








































    ngrams1 = set(generate_ngrams(tokens1, n))
    ngrams2 = set(generate_ngrams(tokens2, n))

    intersection = ngrams1.intersection(ngrams2)
    union = ngrams1.union(ngrams2)

    if len(union) == 0:
        return 0.0

    return len(intersection) / len(union)

text1 = input("Enter first sentence: ")
text2 = input("Enter second sentence: ")
tokens1 = preprocess(text1)
tokens2 = preprocess(text2)






























print("\n N-Grams for Sentence 1:")
print("Unigrams:", generate_ngrams(tokens1, 1))
print("Bigrams :", generate_ngrams(tokens1, 2))
print("Trigrams:", generate_ngrams(tokens1, 3))

print("\n N-Grams for Sentence 2:")
print("Unigrams:", generate_ngrams(tokens2, 1))
print("Bigrams :", generate_ngrams(tokens2, 2))
print("Trigrams:", generate_ngrams(tokens2, 3))











































print("\n Jaccard Coefficient")
print("Bigram Jaccard Similarity :", jaccard_coefficient(text1, text2, 2))
print("Trigram Jaccard Similarity:", jaccard_coefficient(text1, text2, 3))
