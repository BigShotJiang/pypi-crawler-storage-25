#Stemming
from nltk.stem import PorterStemmer, LancasterStemmer
porter = PorterStemmer()
lancaster = LancasterStemmer()
words = ["running", "runner", "runs", "easily", "happier", "better"]
print("Porter Stemmer:")
for w in words:
    print(w, " :- ", porter.stem(w))
print("\nLancaster Stemmer:")
for w in words:
    print(w, " :- ", lancaster.stem(w))












































#Lemmatization
import nltk
from nltk.stem import WordNetLemmatizer
nltk.download('wordnet')
nltk.download('omw-1.4')
lemmatizer = WordNetLemmatizer()
words = ["running", "runner", "runs", "easily", "happier", "better"]
print("Lemmatization (Verb):")
for w in words:
    print(w, " :- ", lemmatizer.lemmatize(w, pos="v"))


#Morphological Analysis
import nltk
from nltk.tokenize import word_tokenize
nltk.download('punkt')
words = ["running", "easily", "cats", "jumping", "slowly"]

def morphological_analysis(word):
    suffixes = ["ing", "ly", "s", "es", "ed"]
    for suf in suffixes:
        if word.endswith(suf):
            return word[:-len(suf)], suf
    return word, None
for w in words:
    root, suffix = morphological_analysis(w)
    print(f"{w} :- Root: {root}, Suffix: {suffix}")
















































#WordNet
from nltk.corpus import wordnet 
def wordnet_morphology(word):
    return wordnet.morphy(word) 
words = ["running", "played", "happily", "cats", "jump"]
for w in words:
    print(w, " :- ", wordnet_morphology(w))


#Prefix-Suffix
prefixes = ["un", "re", "in", "im", "dis", "pre"]
suffixes = ["ing", "ed", "ly", "s", "es", "er"]
words = ["running", "played", "happily", "cats", "jump"]

def split_affixes(word):
    found_prefix = None
    found_suffix = None

    for p in prefixes:
        if word.startswith(p):
            found_prefix = p
            word = word[len(p):]
            break
    for s in suffixes:
        if word.endswith(s):
            found_suffix = s
            word = word[:-len(s)]
            break
    return found_prefix, word, found_suffix

for w in words:
    p, root, s = split_affixes(w)
    print(f"{w} :- Prefix: {p}, Root: {root}, Suffix: {s}")













































#RE for Compound Word Segmentation
import re
def split_compound(word):
    return re.findall(r'[A-Z][a-z]*|[a-z]+', word)
words = ["sunflower", "notebook", "blueberry", "football"]
for w in words:
    print(w, " :- ", split_compound(w))


#Spacy for Compound Word Detection
import spacy
nlp = spacy.load("en_core_web_sm")
words = ["sunflower", "airplane", "football"]
for w in words:
    doc = nlp(w)
    print(w, " :- ", [token.morph for token in doc])

prefixes = [
    "un", "re", "in", "im", "dis", "pre",
    "mis", "non", "over", "under"
]

suffixes = [
    "ing", "ed", "ly", "s", "es", "er",
    "est", "ment", "ness", "able", "ful"
]
















def split_word(word):
    root = word
    found_prefix = None
    found_suffix = None
    for p in prefixes:
        if root.startswith(p):
            found_prefix = p
            root = root[len(p):]
            break
    for s in suffixes:
        if root.endswith(s):
            found_suffix = s
            root = root[:-len(s)]
            break
    return {
        "word": word,
        "prefix": found_prefix,
        "root": root,
        "suffix": found_suffix
    }






































words = ["running", "played", "happily", "cats", "jump"]
for w in words:
    print(split_word(w))
