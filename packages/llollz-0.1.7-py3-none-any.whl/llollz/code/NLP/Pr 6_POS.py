#1. universal_tagset
import nltk
from nltk.corpus import brown 
nltk.download('punkt_tab') 
nltk.download('averaged_perceptron_tagger_eng') 
nltk.download('brown') 
nltk.download('universal_tagset') 
 
sentence = "The quick brown fox jumped over the lazy dog." 
tokens = nltk.word_tokenize(sentence) 
tagged = nltk.pos_tag(tokens) 
print(tagged) 

























































#2. brown 
import nltk 
from nltk.tokenize import word_tokenize 
from nltk import pos_tag
nltk.download('punkt') 
nltk.download('averaged_perceptron_tagger') 
 
text = "The quick brown fox jumps over the lazy dog." 
tokens = word_tokenize(text)  
tagged_tokens = pos_tag(tokens) 
for token, tag in tagged_tokens: 
    print(f"{token}: {tag}")














































#3. averaged_perceptron_tagger
import spacy 
 
nlp = spacy.load("en_core_web_sm") 
text = "The quick brown fox jumps over the lazy dog." 
doc = nlp(text) 
 
for token in doc: 
    print(f"{token.text}: {token.pos_}")


#4. spacy with en_core_web_sm 
import spacy 
 
nlp = spacy.load("en_core_web_sm") 
text = "Google Colab is a great platform for running Python code." 
doc = nlp(text) 
for token in doc: 
    print(f"{token.text}\t{token.pos_}\t{token.dep_}")















































#5. Naive Bayes classifier 
import nltk 
from nltk.classify import NaiveBayesClassifier 
from nltk.corpus import names 

nltk.download('names') 
nltk.download('punkt')
# Feature extractor function 
def gender_features(word): 
    return {'last_letter': word[-1]} 
 

names = ([(name, 'male') for name in names.words('male.txt')] + 
         [(name, 'female') for name in names.words('female.txt')]) 
  















































import random 
random.shuffle(names) 
 
featuresets = [(gender_features(n), gender) for (n, gender) in names] 
train_set, test_set = featuresets[500:], featuresets[:500] 
classifier = NaiveBayesClassifier.train(train_set) 
print("Accuracy:", nltk.classify.accuracy(classifier, test_set)) 
 
classifier.show_most_informative_features(5) 
print("Classification:", classifier.classify(gender_features('John')))
