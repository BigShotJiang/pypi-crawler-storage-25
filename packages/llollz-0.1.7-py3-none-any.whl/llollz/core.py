def hello():
    print("Hello from llollz core!")
