# yxim-nim-bot

`yxim-nim-bot` packages the Node.js SDK `@yxim/nim-bot` as a Python distribution.

This is a wrapper package, not a source-to-source port. The Python package vendors:

- `@yxim/nim-bot@10.9.81`
- `ws`

and provides:

- Python helpers to locate the vendored Node.js entrypoint
- a small runtime wrapper that launches `node`
- a CLI for running inline JavaScript or external `.mjs` scripts with the SDK preloaded

## Requirements

- Python 3.10+
- Node.js 20+

The SDK itself still runs in Node.js. This package only makes it distributable through `pip`.

## Install

```bash
pip install .
```

## Python API

```python
from yxim_nim_bot import NimBotRuntime

runtime = NimBotRuntime()

result = runtime.eval(
    """
    const nim = nimModule.default ?? nimModule;
    return Object.keys(nim).slice(0, 10);
    """,
    json_output=True,
)

print(result.stdout)
```

Useful helpers:

```python
from yxim_nim_bot import package_root, entrypoint, node_binary
```

## CLI

Show vendored paths:

```bash
yxim-nim-bot paths
```

Evaluate inline JavaScript with `nim` and `nimModule` injected:

```bash
yxim-nim-bot eval "return Object.keys(nim).slice(0, 3)" --json
```

Run an external script:

```bash
yxim-nim-bot run ./demo.mjs -- foo bar
```

When using `run`, the bootstrap injects:

- `globalThis.nim`
- `globalThis.nimModule`
- `globalThis.nimArgs`
- `process.env.YXIM_NIM_BOT_ENTRY`
- `process.env.YXIM_NIM_BOT_PACKAGE_ROOT`

So a script can use either:

```js
const nim = globalThis.nim;
```

or:

```js
const nimModule = await import(process.env.YXIM_NIM_BOT_ENTRY);
const nim = nimModule.default ?? nimModule;
```

## Package layout

The vendored Node.js dependencies live under:

```text
src/yxim_nim_bot/_vendor/node_modules/
```

This keeps Node's normal module resolution working for the SDK's `ws` dependency.

## Notes

- This package does not try to wrap the full SDK surface into native Python classes.
- It is intended for Python projects that still want to execute the official Node.js SDK.
- If you need a true Python-native SDK, the Node.js logic has to be reimplemented.
