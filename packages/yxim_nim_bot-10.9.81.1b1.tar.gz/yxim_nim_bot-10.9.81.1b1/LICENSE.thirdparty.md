# Third-Party Components

This package vendors the following third-party Node.js packages:

- `@yxim/nim-bot@10.9.81`
  - License: ISC
  - Source package metadata is preserved under `src/yxim_nim_bot/_vendor/node_modules/@yxim/nim-bot/package.json`
- `ws`
  - License: MIT
  - License text is preserved under `src/yxim_nim_bot/_vendor/node_modules/ws/LICENSE`

This Python package adds only the wrapping code required to distribute and launch the vendored Node.js SDK from Python.
