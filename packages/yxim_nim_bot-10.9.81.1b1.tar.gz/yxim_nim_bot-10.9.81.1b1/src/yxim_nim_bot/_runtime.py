"""Runtime helpers for launching the vendored Node.js SDK."""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence


_BOOTSTRAP = r"""
import process from 'node:process';
import { pathToFileURL } from 'node:url';

const nimModule = await import(pathToFileURL(process.env.YXIM_NIM_BOT_ENTRY).href);
const nim = nimModule.default ?? nimModule;

globalThis.nimModule = nimModule;
globalThis.nim = nim;
globalThis.nimArgs = process.argv.slice(2);

const mode = process.env.YXIM_NIM_BOT_MODE;

if (mode === 'eval') {
  const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
  const fn = new AsyncFunction('nim', 'nimModule', 'args', process.env.YXIM_NIM_BOT_SOURCE);
  const result = await fn(nim, nimModule, process.argv.slice(2));
  if (process.env.YXIM_NIM_BOT_JSON === '1') {
    console.log(result === undefined ? 'null' : JSON.stringify(result));
  } else if (result !== undefined) {
    console.log(String(result));
  }
} else if (mode === 'run') {
  globalThis.nimScript = process.env.YXIM_NIM_BOT_SCRIPT;
  await import(pathToFileURL(process.env.YXIM_NIM_BOT_SCRIPT).href);
} else {
  throw new Error(`Unsupported bootstrap mode: ${mode}`);
}
"""


def _module_dir() -> Path:
    return Path(__file__).resolve().parent


def package_root() -> Path:
    """Return the vendored ``@yxim/nim-bot`` package root."""
    return _module_dir() / "_vendor" / "node_modules" / "@yxim" / "nim-bot"


def entrypoint() -> Path:
    """Return the vendored Node.js SDK entrypoint."""
    return package_root() / "dist" / "nodejs" / "nim.js"


def node_binary(explicit: str | None = None) -> str:
    """Resolve the Node.js executable."""
    candidate = explicit or os.environ.get("YXIM_NIM_BOT_NODE") or shutil.which("node")
    if not candidate:
        raise FileNotFoundError(
            "Node.js executable not found. Install Node.js 20+ or set YXIM_NIM_BOT_NODE."
        )
    return candidate


def _parse_node_major(version_text: str) -> int | None:
    text = version_text.strip().lstrip("v")
    if not text:
        return None
    try:
        return int(text.split(".", 1)[0])
    except ValueError:
        return None


@dataclass(slots=True)
class NimBotRuntime:
    """Small launcher around the vendored ``@yxim/nim-bot`` package."""

    node: str | None = None
    min_node_major: int = 20

    def resolve_node(self) -> str:
        return node_binary(self.node)

    def assert_node_compatible(self) -> str:
        binary = self.resolve_node()
        result = subprocess.run(
            [binary, "--version"],
            capture_output=True,
            text=True,
            check=True,
        )
        major = _parse_node_major(result.stdout)
        if major is None or major < self.min_node_major:
            raise RuntimeError(
                f"Node.js {self.min_node_major}+ is required, got {result.stdout.strip()!r}."
            )
        return binary

    def base_env(self, extra_env: Mapping[str, str] | None = None) -> dict[str, str]:
        env = dict(os.environ)
        env["YXIM_NIM_BOT_ENTRY"] = str(entrypoint())
        env["YXIM_NIM_BOT_PACKAGE_ROOT"] = str(package_root())
        if extra_env:
            env.update({key: str(value) for key, value in extra_env.items()})
        return env

    def eval(
        self,
        source: str,
        *,
        args: Sequence[str] = (),
        cwd: str | os.PathLike[str] | None = None,
        env: Mapping[str, str] | None = None,
        json_output: bool = False,
        check: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        runtime_env = self.base_env(env)
        runtime_env["YXIM_NIM_BOT_MODE"] = "eval"
        runtime_env["YXIM_NIM_BOT_SOURCE"] = source
        runtime_env["YXIM_NIM_BOT_JSON"] = "1" if json_output else "0"
        return self._run_bootstrap(
            args=args,
            cwd=cwd,
            env=runtime_env,
            check=check,
        )

    def run_script(
        self,
        script: str | os.PathLike[str],
        *,
        args: Sequence[str] = (),
        cwd: str | os.PathLike[str] | None = None,
        env: Mapping[str, str] | None = None,
        check: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        runtime_env = self.base_env(env)
        runtime_env["YXIM_NIM_BOT_MODE"] = "run"
        runtime_env["YXIM_NIM_BOT_SCRIPT"] = str(Path(script).resolve())
        return self._run_bootstrap(
            args=args,
            cwd=cwd,
            env=runtime_env,
            check=check,
        )

    def _run_bootstrap(
        self,
        *,
        args: Sequence[str],
        cwd: str | os.PathLike[str] | None,
        env: Mapping[str, str],
        check: bool,
    ) -> subprocess.CompletedProcess[str]:
        binary = self.assert_node_compatible()
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".mjs",
            prefix="yxim_nim_bot_",
            delete=False,
            encoding="utf-8",
        ) as handle:
            handle.write(_BOOTSTRAP)
            bootstrap_path = Path(handle.name)
        try:
            return subprocess.run(
                [binary, str(bootstrap_path), *args],
                cwd=cwd,
                env=dict(env),
                capture_output=True,
                text=True,
                check=check,
            )
        finally:
            bootstrap_path.unlink(missing_ok=True)

    def inspect(self) -> dict[str, str]:
        binary = self.assert_node_compatible()
        return {
            "node": binary,
            "entrypoint": str(entrypoint()),
            "package_root": str(package_root()),
        }
