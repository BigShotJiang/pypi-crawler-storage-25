"""CLI for the vendored ``@yxim/nim-bot`` runtime."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from ._runtime import NimBotRuntime


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="yxim-nim-bot",
        description="Launch the vendored @yxim/nim-bot Node.js SDK from Python.",
    )
    parser.add_argument(
        "--node",
        help="Explicit Node.js binary to use. Defaults to YXIM_NIM_BOT_NODE or PATH.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("paths", help="Print resolved runtime paths as JSON.")

    eval_parser = subparsers.add_parser("eval", help="Evaluate inline JavaScript.")
    eval_parser.add_argument("source", help="JavaScript source to evaluate.")
    eval_parser.add_argument(
        "--json",
        action="store_true",
        help="JSON-encode the returned value.",
    )

    run_parser = subparsers.add_parser(
        "run",
        help="Run an external .mjs script with nim injected on globalThis.",
    )
    run_parser.add_argument("script", help="Path to the JavaScript module to run.")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args, passthrough = parser.parse_known_args(argv)
    runtime = NimBotRuntime(node=args.node)

    if args.command == "paths":
        print(json.dumps(runtime.inspect(), indent=2, sort_keys=True))
        return 0

    if args.command == "eval":
        script_args = _strip_sentinel(passthrough)
        result = runtime.eval(args.source, args=script_args, json_output=args.json, check=False)
        return _emit_result(result)

    if args.command == "run":
        script_args = _strip_sentinel(passthrough)
        result = runtime.run_script(Path(args.script), args=script_args, check=False)
        return _emit_result(result)

    parser.error(f"Unsupported command: {args.command}")
    return 2


def _strip_sentinel(values: list[str]) -> list[str]:
    if values[:1] == ["--"]:
        return values[1:]
    return values


def _emit_result(result) -> int:
    if result.stdout:
        print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, end="", file=sys.stderr)
    return int(result.returncode)
