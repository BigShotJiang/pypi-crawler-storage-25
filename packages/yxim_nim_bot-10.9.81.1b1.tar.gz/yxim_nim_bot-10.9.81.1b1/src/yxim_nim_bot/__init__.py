"""Python wrapper for the vendored ``@yxim/nim-bot`` Node.js SDK."""

from ._runtime import NimBotRuntime, entrypoint, node_binary, package_root

__all__ = [
    "NimBotRuntime",
    "entrypoint",
    "node_binary",
    "package_root",
]
