"""Trained models — the user-facing output of training.

Three classes live here:

- :class:`~outerproduct.model.Model` — a deployable predictor returned by
  :meth:`~outerproduct.trainer.Trainer.run`. Minimal surface: predict, as_predictor.
- :class:`~outerproduct.model.ReasoningModel` — extends :class:`~outerproduct.model.Model` with
  explanation, interpretation, and counterfactual methods.
  Returned by :func:`~outerproduct.reasoning.fit`.
- :class:`~outerproduct.model.Predictor` — a duck-typed wrapper around an external
  prediction endpoint, used to hand black-box models into
  :func:`~outerproduct.reasoning.fit` as ``teacher`` arguments for distillation.

End-to-end shape:

import outerproduct as op
connector = op.FileUploadConnector()
dataset = connector.upload("data.csv", label_column="churn")
reasoning_model = op.reasoning.fit(dataset)
predictions = reasoning_model.predict(X)
reasoning = reasoning_model.explain(X)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from outerproduct.utils import _client

if TYPE_CHECKING:
    import numpy as np

    from outerproduct.dataset import Column
    from outerproduct.reasoning import Reasoning, ReasoningTrace


class Model:
    """A trained, deployable predictor.

    Returned by :meth:`~outerproduct.trainer.Trainer.run`. ``Model`` is intentionally
    minimal — it exposes prediction and persistence, nothing else. For
    explanations, counterfactuals, and segmentation, configure the trainer
    with ``reasoning=True`` to get a :class:`~outerproduct.model.ReasoningModel` instead.

    Models are usually constructed by the trainer; users rarely call the
    constructor directly.
    """

    def __init__(
        self,
        *,
        id: str,
        feature_names: list[str] | None = None,
    ) -> None:
        self._id = id
        self._feature_names = feature_names

    @property
    def id(self) -> str:
        """The model's unique server-side identifier."""
        return self._id

    @property
    def schema(self) -> list[Column]:
        """Per-column schema of the training data this model was fit on."""
        from outerproduct.dataset import Column

        if self._feature_names is None:
            raise RuntimeError(
                "Feature names are not available. "
                "Load the model from a saved file or re-train to populate schema."
            )
        return [Column(name=n) for n in self._feature_names]

    def predict(self, X: Any) -> np.ndarray:
        """Predict targets for a batch of samples.

        Parameters
        ----------
        X : :class:`~outerproduct.dataset.Dataset`, pandas.DataFrame, numpy.ndarray, or list of lists
            Input features. Columns must match the schema this model
            was trained on. Passing the same
            :class:`~outerproduct.dataset.Dataset` used for training
            uses its feature columns (label column dropped).

        Returns
        -------
        numpy.ndarray
            Regression: shape ``(n_samples,)``.
            Classification: shape ``(n_samples, n_classes)`` of class
            probabilities.
        """
        import numpy as np

        from outerproduct_http_types import PredictRequest

        from outerproduct.utils import _prepare_samples

        samples, feature_names = _prepare_samples(X, self._feature_names)
        request = PredictRequest(samples=samples, feature_names=feature_names)
        with _client() as c:
            resp = c.inference_api.predict(self._id, request)
        return np.asarray(resp.predictions)

    def as_predictor(self) -> Predictor:
        """Wrap this trained model as a :class:`~outerproduct.model.Predictor`.

        Returns a :class:`~outerproduct.model.Predictor` that calls this model's prediction
        endpoint on the OuterProduct server. Useful for passing a trained
        model into :func:`~outerproduct.reasoning.fit` as a ``teacher`` argument
        for distillation, or for handing the model to other parts of a
        pipeline that expect the duck-typed :class:`~outerproduct.model.Predictor`
        interface.

        Returns
        -------
        Predictor
            A predictor whose :meth:`~outerproduct.model.Predictor.predict` routes
            through this model's server-side endpoint.
        """
        from outerproduct import _state
        from outerproduct.client import API_VERSION, resolve_api_key, resolve_base_url

        base = resolve_base_url(_state.base_url)
        key = resolve_api_key(_state.api_key)
        url = f"{base}/{API_VERSION}/models/{self._id}/predict"
        return Predictor(url, headers={"Authorization": f"Bearer {key}"})

    def __repr__(self) -> str:
        return f"{type(self).__name__}(id={self._id!r})"


class DiffModel(Model):
    """A trained :class:`~outerproduct.model.Model` with native gradient access.

    Server-side handle to a trainer ``DiffModel`` subclass — currently
    ``TabM``, ``XRFM``, or ``DiffEnsemble``. The class mirrors the trainer
    inheritance hierarchy (``DiffModel`` is a ``Model``) so anywhere a
    :class:`~outerproduct.model.Model` is accepted, a
    :class:`~outerproduct.model.DiffModel` works too.

    When passed as the ``teacher`` argument to
    :func:`~outerproduct.reasoning.fit`, the SDK signals to the server that
    the teacher is differentiable. The server skips synth-gen and
    student fitting, and runs only the finalize step (AGOP aggregation +
    ReasoningModel assembly) against the user's full real training data
    — no 10k-sample distillation, no second model fit.
    """

    pass


class ReasoningModel(Model):
    """A :class:`~outerproduct.model.Model` augmented with explanation and reasoning methods.

    Returned by :func:`~outerproduct.reasoning.fit`. Inherits everything from
    :class:`~outerproduct.model.Model` and adds methods for local/global
    explanations and counterfactual scenarios. For population-level
    decomposition, fit a
    :class:`~outerproduct.reasoning.pattern_tracker.PatternTracker` separately.

    The return types of these methods are :class:`~outerproduct.reasoning.Reasoning`
    (single explanation) and :class:`~outerproduct.reasoning.ReasoningTrace`
    (multi-step explanation).
    """

    def explain(self, X: Any) -> Reasoning:
        """Per-sample local explanation for ``X``.

        Parameters
        ----------
        X : :class:`~outerproduct.dataset.Dataset`, pandas.DataFrame, numpy.ndarray, or list of lists
            Inputs to explain. Passing a
            :class:`~outerproduct.dataset.Dataset` uses its feature
            columns (label column dropped).

        Returns
        -------
        :class:`~outerproduct.reasoning.Reasoning`
            Per-feature attributions with shape
            ``(n_samples, n_features)``.
        """
        import numpy as np

        from outerproduct_http_types import ExplainRequest

        from outerproduct.reasoning import Reasoning
        from outerproduct.utils import _prepare_samples

        samples, feature_names = _prepare_samples(X, self._feature_names)
        request = ExplainRequest(samples=samples, feature_names=feature_names)
        with _client() as c:
            resp = c.inference_api.explain(self._id, request)

        return Reasoning(
            feature_names=resp.feature_names,
            attributions=np.asarray(resp.attributions),
        )

    def predict_and_explain(
        self,
        X: Any,
        *,
        rule_kwargs: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, Reasoning]:
        """Predict and explain in a single round-trip.

        Parameters
        ----------
        X : array-like
            Inputs.
        rule_kwargs : dict, optional
            Gates per-sample local-rule computation on the server.
            ``None`` (default) skips rule computation entirely. ``{}``
            runs the rule-explanation backend with all defaults.
            A populated dict overrides those defaults — e.g.
            ``{"selector": "lift_threshold", "lift_threshold": 0.9}``.
            See ``outerproduct_reasoning.local_rule_explanations`` for
            the full keyword set (``selector``, ``lift_threshold``,
            ``max_rules``, ``max_depth``, ``min_support``, …).

        Returns
        -------
        predictions : numpy.ndarray
            See :meth:`~outerproduct.model.Model.predict`.
        reasoning : :class:`~outerproduct.reasoning.Reasoning`
            See :meth:`~outerproduct.model.ReasoningModel.explain`.
            When ``rule_kwargs`` was provided, per-sample rule
            explanations are available at
            ``reasoning.metadata["local_rules"]`` (a list aligned with
            the input rows).
        """
        import numpy as np

        from outerproduct_http_types import PredictAndExplainRequest

        from outerproduct.reasoning import Reasoning
        from outerproduct.utils import _prepare_samples

        samples, feature_names = _prepare_samples(X, self._feature_names)
        request = PredictAndExplainRequest(
            samples=samples,
            feature_names=feature_names,
            rule_kwargs=rule_kwargs,
        )
        with _client() as c:
            resp = c.inference_api.predict_and_explain(self._id, request)

        predictions = np.asarray(resp.predictions)
        reasoning = Reasoning(
            feature_names=resp.feature_names,
            attributions=np.asarray(resp.attributions),
            metadata={"local_rules": resp.local_rules},
        )
        return predictions, reasoning

    def get_global_drivers(self) -> Reasoning:
        """Model-wide global feature importance.

        Returns
        -------
        :class:`~outerproduct.reasoning.Reasoning`
            Attributions of shape ``(n_features,)``.
        """
        import numpy as np

        from outerproduct_http_types import GlobalDriversRequest

        from outerproduct.reasoning import Reasoning

        request = GlobalDriversRequest()
        with _client() as c:
            resp = c.inference_api.get_global_drivers(self._id, request)

        return Reasoning(
            feature_names=resp.feature_names or [],
            attributions=np.asarray(resp.global_drivers),
        )

    def scenario(
        self,
        X: Any,
        *,
        target_class: int | str | None = None,
        n_walks: int = 500,
        max_steps: int = 30,
        epsilon: float = 0.2,
        random_state: int | None = 42,
        constraints: dict[str, Any] | None = None,
    ) -> ReasoningTrace:
        """Search for a counterfactual: minimal feature changes that flip the prediction.

        Parameters
        ----------
        X : array-like
            Starting point(s) for the search.
        target_class : int or str, optional
            Desired class label. If omitted, defaults to ``1``.
        n_walks : int, default 500
            Number of random walks to run per query.
        max_steps : int, default 30
            Maximum number of edit steps per walk.
        epsilon : float, default 0.2
            Step size for each walk iteration.
        random_state : int or None, default 42
            Random seed for reproducibility. ``None`` disables seeding.
        constraints : dict, optional
            Per-feature constraints applied during walks. Keys are feature
            names; values are dicts (or
            :class:`~outerproduct_http_types.FeatureConstraintSchema`
            instances) with optional keys ``immutable`` (bool),
            ``monotonic`` (``"increase"`` or ``"decrease"``),
            ``value_range`` (``[lo, hi]``), and ``allowed_values``
            (list).

        Returns
        -------
        :class:`~outerproduct.reasoning.ReasoningTrace`
            One step per candidate counterfactual, grouped by query.
        """
        import numpy as np

        from outerproduct_http_types import FeatureConstraintSchema, ScenarioRequest

        from outerproduct.reasoning import Reasoning, ReasoningTrace
        from outerproduct.utils import _prepare_samples

        samples, feature_names = _prepare_samples(X, self._feature_names)
        desired_class = int(target_class) if target_class is not None else 1

        parsed_constraints: dict[str, FeatureConstraintSchema] = {}
        if constraints:
            if self._feature_names is not None:
                unknown = [k for k in constraints if k not in self._feature_names]
                if unknown:
                    raise ValueError(
                        f"Unknown features in constraints: {unknown}. "
                        f"Model features: {self._feature_names}."
                    )
            for feat, spec in constraints.items():
                if isinstance(spec, FeatureConstraintSchema):
                    parsed_constraints[feat] = spec
                else:
                    parsed_constraints[feat] = FeatureConstraintSchema(**spec)

        request = ScenarioRequest(
            queries=samples,
            feature_names=feature_names,
            desired_class=desired_class,
            n_walks=n_walks,
            max_steps=max_steps,
            epsilon=epsilon,
            random_state=random_state,
            constraints=parsed_constraints,
        )
        with _client() as c:
            resp = c.inference_api.scenario(self._id, request)

        steps: list[Reasoning] = []
        for result_item in resp.results:
            for candidate in result_item.scenarios:
                changed_features = list(candidate.changes.keys())
                steps.append(
                    Reasoning(
                        feature_names=changed_features,
                        attributions=np.zeros(len(changed_features)),
                        metadata={
                            "query_index": result_item.query_index,
                            "baseline_prediction": result_item.baseline_prediction,
                            "row": candidate.row,
                            "changes": {
                                k: {
                                    "from": v.from_,
                                    "to": v.to,
                                    "delta": v.delta,
                                }
                                for k, v in candidate.changes.items()
                            },
                            "n_changes": candidate.n_changes,
                        },
                    )
                )

        return ReasoningTrace(
            steps=steps,
            metadata={"desired_class": resp.desired_class},
        )


def predict(model: Model, X: Any) -> np.ndarray:
    """Top-level prediction shortcut.

    Equivalent to ``model.predict(X)``. Provided as a free function so users
    can write ``outerproduct.predict(model, X)`` without first reaching for
    the method.

    Parameters
    ----------
    model : :class:`~outerproduct.model.Model`
        A trained model.
    X : array-like
        Inputs.

    Returns
    -------
    numpy.ndarray
        See :meth:`~outerproduct.model.Model.predict`.
    """
    return model.predict(X)


class Predictor:
    """A black-box prediction interface.

    A :class:`~outerproduct.model.Predictor` wraps an external prediction
    endpoint behind a single ``predict(X)`` method. It's the canonical way
    to hand a model that lives outside OuterProduct — your own deployed
    service, a third-party API, a competitor's model — to
    :func:`~outerproduct.reasoning.fit` as a ``teacher`` argument so the
    OuterProduct reasoning stack can distill it into a
    :class:`~outerproduct.model.ReasoningModel`.

    Anything with a ``.predict(X)`` method is duck-typed as a predictor in
    the SDK; this class is the official adapter for HTTP endpoints. Trained
    :class:`~outerproduct.model.Model` instances expose :meth:`~outerproduct.model.Model.as_predictor` to
    surface the same interface without going through a URL.

    Examples
    --------
    .. code-block:: python

        import outerproduct as op

        teacher = op.model.Predictor(
            "https://api.example.com/predict",
            headers={"Authorization": "Bearer ..."},
        )
        teacher.predict(X)            # call the endpoint directly
        rm = op.reasoning.fit(dataset, teacher=teacher)   # distill it

    Parameters
    ----------
    url : str
        Prediction endpoint. Expected to accept a JSON body of features
        and return a JSON response with predictions.
    headers : dict, optional
        Additional HTTP headers — typically authentication. The same
        headers are forwarded server-side during distillation so the
        OuterProduct backend can call the endpoint on the user's behalf.
    timeout : float, default 60.0
        Per-request HTTP timeout in seconds.
    """

    def __init__(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        timeout: float = 60.0,
    ) -> None:
        self._url = url
        self._headers = dict(headers) if headers else {}
        self._timeout = timeout

    @classmethod
    def from_url(
        cls,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        timeout: float = 60.0,
    ) -> Predictor:
        """Construct a :class:`~outerproduct.model.Predictor` from a URL.

        Equivalent to ``Predictor(url, headers=..., timeout=...)``. Provided
        as a named factory for readability when the call site benefits from
        spelling out where the predictor came from.

        Parameters
        ----------
        url : str
            Prediction endpoint.
        headers : dict, optional
            HTTP headers.
        timeout : float, default 60.0
            Per-request timeout.

        Returns
        -------
        :class:`~outerproduct.model.Predictor`
            A predictor wrapping the given URL.
        """
        return cls(url, headers=headers, timeout=timeout)

    @property
    def url(self) -> str:
        """The wrapped prediction endpoint."""
        return self._url

    @property
    def headers(self) -> dict[str, str]:
        """HTTP headers sent on each call. Empty dict if none configured."""
        return dict(self._headers)

    def predict(self, X: Any) -> np.ndarray:
        """POST ``X`` to the wrapped endpoint and return predictions.

        Parameters
        ----------
        X : pandas.DataFrame, numpy.ndarray, or list of lists
            Input features.

        Returns
        -------
        numpy.ndarray
            Predictions, shape matching the underlying endpoint's
            response. The wrapper makes no assumptions about regression
            vs classification — that's defined by the endpoint.
        """
        import httpx
        import numpy as np

        from outerproduct.utils import _prepare_samples

        samples, feature_names = _prepare_samples(X)
        with httpx.Client(timeout=self._timeout) as http:
            resp = http.post(
                self._url,
                json={"samples": samples, "feature_names": feature_names},
                headers=self._headers or None,
            )
            resp.raise_for_status()
        body = resp.json()
        return np.asarray(body.get("predictions", body))

    def __repr__(self) -> str:
        return f"{type(self).__name__}(url={self._url!r})"
