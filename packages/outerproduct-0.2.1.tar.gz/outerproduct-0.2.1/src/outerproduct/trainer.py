"""Training orchestration — fits :class:`~outerproduct.model.Model` against a :class:`~outerproduct.dataset.Dataset`.

The :class:`~outerproduct.trainer.Trainer` is the user's entry point to general-purpose
model training. It is a thin client over the OuterProduct API: a configured
:class:`~outerproduct.trainer.Trainer` instance holds the request shape, and
:meth:`~outerproduct.trainer.Trainer.run` POSTs to ``/v1/trainer/run`` and
(by default) polls ``GET /v1/models/{model_id}/status`` until the job
completes.

Model families and search strategies are passed as plain strings (e.g.
``model_types=["tabm", "xgboost"]``, ``strategy="random"``) and resolved
server-side. Hardware and metrics retain their typed objects:
:class:`~outerproduct.trainer.Hardware` is configured once at process start via
:func:`~outerproduct.init` and shared by every :class:`~outerproduct.trainer.Trainer` and
:func:`~outerproduct.reasoning.fit` call; :class:`~outerproduct.trainer.Metric` retains
its dataclass shape so users can attach a custom scoring callable. Custom
callables are not yet sent over the wire; only :attr:`~outerproduct.trainer.Metric.name`
is forwarded, and setting :attr:`~outerproduct.trainer.Metric.fn` raises until
server-side custom metrics land.

:meth:`~outerproduct.trainer.Trainer.run` always returns a plain :class:`~outerproduct.model.Model`; to
produce a :class:`~outerproduct.model.ReasoningModel` use
:func:`~outerproduct.reasoning.fit`.

Examples
--------
.. code-block:: python

    import outerproduct as op

    op.init(api_key="...")
    connector = op.FileUploadConnector()
    dataset = connector.upload("data.csv", label_column="churn")
    trainer = op.Trainer.configure(
        dataset,
        model_types=["tabm", "xgboost"],
    )
    model = trainer.run(strategy="random")
    predictions = model.predict(X)
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from outerproduct_http_types import ModalHardwareSpec

if TYPE_CHECKING:
    from outerproduct_http_types import HardwareSpec, TrainerRunRequest

    from outerproduct.dataset import Dataset
    from outerproduct.job import TrainerJob
    from outerproduct.model import Model, Predictor


# ----------------------------------------------------------------------
# Hardware
# ----------------------------------------------------------------------


@dataclass
class Hardware:
    """Base class for hardware execution targets.

    Subclasses describe *where* training runs — locally, on a Modal worker,
    on a managed GPU, etc.
    """

    def to_http_hardware_spec(self) -> HardwareSpec:
        """Translate this user-facing dataclass into its server-side Pydantic spec."""
        raise NotImplementedError


@dataclass
class ModalHardware(Hardware):
    """Run training on Modal's managed GPU workers.

    Parameters
    ----------
    gpu : str, default "A10G"
        GPU type to request.
    timeout : int, default 3600
        Per-trial timeout in seconds.
    n_concurrent : int, default 4
        Max parallel trial containers.
    """

    gpu: str = "A10G"
    timeout: int = 3600
    n_concurrent: int = 4

    def to_http_hardware_spec(self) -> ModalHardwareSpec:
        return ModalHardwareSpec(
            gpu=self.gpu,
            timeout_s=self.timeout,
            n_concurrent=self.n_concurrent,
        )


# ----------------------------------------------------------------------
# Metric
# ----------------------------------------------------------------------


@dataclass
class Metric:
    """An evaluation metric used to score candidate models.

    Parameters
    ----------
    name : str
        Display name used in logs and reports. Forwarded to the server.
    fn : callable, optional
        Scoring callable with signature ``fn(y_true, y_pred) -> float``.
        Higher values are better. **Not yet supported** — setting ``fn``
        raises in this version because callables can't be serialised over
        the wire. The metric is resolved server-side by ``name``.
    """

    name: str
    fn: Callable[..., float] | None = None


# ----------------------------------------------------------------------
# Job handle (returned by run(non_blocking=True))
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
# Trainer
# ----------------------------------------------------------------------


class Trainer:
    """Configures and runs training to produce a :class:`~outerproduct.model.Model`.

    The full lifecycle is:

    1. :meth:`~outerproduct.trainer.Trainer.configure` — describe what to train, where, and how.
    2. :meth:`~outerproduct.trainer.Trainer.run` — execute the configured plan and return a
       trained :class:`~outerproduct.model.Model`.

    :class:`~outerproduct.trainer.Trainer` always returns a plain :class:`~outerproduct.model.Model`. To
    produce a :class:`~outerproduct.model.ReasoningModel` (with explain,
    get_global_drivers, scenario, segment methods) use
    :func:`~outerproduct.reasoning.fit` instead.
    """

    def __init__(
        self,
        dataset: Dataset,
        *,
        model_types: list[str] | None,
        metric: Metric | list[Metric] | None,
        teacher: Model | Predictor | None,
        task_type: str | None,
    ) -> None:
        self._dataset = dataset
        self._model_types = model_types
        self._metric = metric
        self._teacher = teacher
        self._task_type = task_type

    @classmethod
    def configure(
        cls,
        dataset: Dataset,
        *,
        model_types: list[str] | None = None,
        metric: Metric | list[Metric] | None = None,
        teacher: Model | Predictor | None = None,
        task_type: str | None = None,
    ) -> Trainer:
        """Configure a trainer for ``dataset`` and return it ready to :meth:`~outerproduct.trainer.Trainer.run`.

        Parameters
        ----------
        dataset : :class:`~outerproduct.dataset.Dataset`
            Training data.
        model_types : list of str, optional
            Candidate model-family identifiers (e.g. ``["tabm",
            "xgboost"]``). Resolved server-side. Defaults to a curated
            set chosen from the dataset's size and schema.
        metric : :class:`~outerproduct.trainer.Metric` or list of :class:`~outerproduct.trainer.Metric`, optional
            One or more metrics. The first is the primary objective;
            additional metrics are reported alongside.
        teacher : :class:`~outerproduct.model.Model` or :class:`~outerproduct.model.Predictor`, optional
            If provided, :meth:`~outerproduct.trainer.Trainer.run` distills this teacher's
            predictions on ``dataset``'s features rather than training
            against ``dataset.label_column``. Most users leave this as
            ``None``.

        Returns
        -------
        :class:`~outerproduct.trainer.Trainer`
            A configured trainer. Call :meth:`~outerproduct.trainer.Trainer.run` to start training.

        Notes
        -----
        Execution hardware is configured once via
        :func:`~outerproduct.init` and is not a per-call argument.
        """
        return cls(
            dataset=dataset,
            model_types=model_types,
            metric=metric,
            teacher=teacher,
            task_type=task_type,
        )

    def run(
        self,
        strategy: str | None = None,
        *,
        non_blocking: bool = False,
        n_trials: int = 4,
        n_splits: int | None = None,
        ensemble: bool = False,
        grid_size: float | None = None,
        random_state: int = 42,
        poll_interval: float = 2.0,
        poll_timeout: float = 3600.0,
    ) -> Model | TrainerJob:
        """Execute the configured training plan.

        Parameters
        ----------
        strategy : str, optional
            Hyperparameter-search strategy identifier (e.g. ``"random"``,
            ``"optuna"``). Resolved server-side. Defaults to ``"random"``.
        non_blocking : bool, default False
            If ``True``, return a :class:`~outerproduct.job.TrainerJob`
            handle immediately. If ``False`` (default), block until
            training completes and return the trained model.
        n_trials : int, default 4
            Number of hyperparameter trials to run.
        n_splits : int, optional
            Number of cross-validation splits. If omitted, the server
            chooses a default.
        ensemble : bool, default False
            Whether to ensemble the top-performing trials.
        grid_size : float, optional
            Grid-search resolution. If omitted, the server uses its
            default.
        random_state : int, default 42
            Random seed for reproducibility.
        poll_interval : float, default 2.0
            Seconds between status polls while blocking.
        poll_timeout : float, default 3600.0
            Maximum seconds to wait before raising a timeout error.

        Returns
        -------
        :class:`~outerproduct.model.Model` or :class:`~outerproduct.job.TrainerJob`
            The trained model when blocking (default). A
            :class:`~outerproduct.job.TrainerJob` when ``non_blocking=True``.
            To get a :class:`~outerproduct.model.ReasoningModel` instead,
            use :func:`~outerproduct.reasoning.fit`.
        """
        from outerproduct import _state
        from outerproduct.client import OuterProductClient
        from outerproduct.model import DiffModel, Model

        request = self._build_trainer_request(
            strategy=strategy or "random",
            n_trials=n_trials,
            n_splits=n_splits,
            ensemble=ensemble,
            grid_size=grid_size,
            random_state=random_state,
        )

        with OuterProductClient.from_credentials(
            _state.base_url, _state.api_key
        ) as client:
            resp = client.trainer_api.run(request)
            model_id = resp.model_id

            # Connector-backed datasets don't have local feature names;
            # the backend discovers them from the remote source.
            ds_feature_names = (
                None
                if self._dataset.is_connector_backed
                else self._dataset.feature_names
            )

            if non_blocking:
                from outerproduct.job import TrainerJob

                return TrainerJob(
                    model_id,
                    feature_names=ds_feature_names,
                )

            client.wait_for(
                model_id,
                poll_interval=poll_interval,
                poll_timeout=poll_timeout,
            )

        # If the user pinned the search to a single trainer DiffModel class
        # (TabM / XRFM / DiffEnsemble), return the DiffModel handle so it can
        # be passed straight into reasoning.fit(teacher=...) and trigger the
        # finalize-only short-circuit. Otherwise return a plain Model.
        model_cls = DiffModel if _is_pinned_to_diffmodel(self._model_types) else Model
        return model_cls(id=model_id, feature_names=ds_feature_names)

    # ------------------------------------------------------------------
    # Internal — request shaping
    # ------------------------------------------------------------------

    def _build_trainer_request(
        self,
        *,
        strategy: str,
        n_trials: int,
        n_splits: int | None,
        ensemble: bool,
        grid_size: float | None,
        random_state: int,
    ) -> TrainerRunRequest:
        from outerproduct import _state
        from outerproduct_http_types import TrainerRunRequest

        inline = self._dataset._to_inline_payload()
        payload: dict[str, Any] = {
            "strategy": strategy,
            "n_trials": n_trials,
            "n_splits": n_splits,
            "ensemble": ensemble,
            "grid_size": grid_size,
            "random_state": random_state,
        }
        # Only set `hardware` when the user explicitly configured one. Omitting
        # it lets the API server pick its default (currently Modal).
        if _state.hardware is not None:
            payload["hardware"] = _state.hardware.to_http_hardware_spec()

        if inline.get("data_connector"):
            payload["data_connector"] = True
            payload["connector_id"] = inline["connector_id"]
            payload["table_name"] = inline["table_name"]
        elif inline.get("data_uploaded"):
            # `dataset_id` is the canonical signal for pre-uploaded data; the
            # schema dropped the explicit `data_uploaded` flag in OUT-361.
            payload["dataset_id"] = inline["dataset_id"]
            payload["feature_names"] = inline.get("feature_names")
        else:
            payload["data"] = inline["data"]
            payload["feature_names"] = inline.get("feature_names")
            payload["labels"] = inline.get("labels")

        if inline.get("label_column") is not None:
            payload["label_column"] = inline["label_column"]

        if self._model_types is not None:
            payload["model_types"] = list(self._model_types)

        if self._metric is not None:
            metrics_list = (
                [self._metric]
                if isinstance(self._metric, Metric)
                else list(self._metric)
            )
            for m in metrics_list:
                if m.fn is not None:
                    raise NotImplementedError(
                        "Metric.fn (custom Python callable) is not supported in v1; "
                        "the metric must be resolved server-side by name."
                    )
            payload["metrics"] = [m.name for m in metrics_list]

        if self._teacher is not None:
            url, headers = _extract_teacher_request(self._teacher)
            payload["teacher_predict_url"] = url
            if headers:
                payload["teacher_predict_headers"] = headers

        if self._task_type is not None:
            payload["task_type"] = self._task_type

        return TrainerRunRequest.model_validate(payload)


_DIFFMODEL_TYPE_NAMES = frozenset({"tabm", "xrfm", "diff_ensemble"})


def _is_pinned_to_diffmodel(model_types: list[str] | None) -> bool:
    """True when the user pinned the trainer to a single DiffModel class.

    The set ``{"tabm", "xrfm", "diff_ensemble"}`` mirrors the concrete
    ``DiffModel`` subclasses in ``outerproduct-trainer``; anything else
    (XGBoost, TabICL, Ensemble, or a multi-class search) returns False.
    """
    if not model_types or len(model_types) != 1:
        return False
    return str(model_types[0]).lower() in _DIFFMODEL_TYPE_NAMES


def _extract_teacher_url(teacher: Any) -> str:
    """Pull a predict URL from a teacher. See `_extract_teacher_request` for the
    headers companion."""
    return _extract_teacher_request(teacher)[0]


def _extract_teacher_request(
    teacher: Any,
) -> tuple[str, dict[str, str] | None]:
    """Pull ``(predict_url, headers)`` from a teacher.

    For a same-server :class:`~outerproduct.model.Model`, the headers carry the
    SDK's bearer token so the API server can call its own ``/predict``
    endpoint on the user's behalf during distillation. For a
    :class:`~outerproduct.model.Predictor`, the user-supplied headers are
    returned as-is. URL strings have no headers.
    """
    predict_url, _get_grads_url, headers = _extract_teacher_endpoints(teacher)
    return predict_url, headers


def _extract_teacher_endpoints(
    teacher: Any,
) -> tuple[str, str | None, dict[str, str] | None]:
    """Pull ``(predict_url, get_grads_url, headers)`` from a teacher.

    ``get_grads_url`` is set when the teacher is a
    :class:`~outerproduct.model.DiffModel` server handle — the server uses
    it as the signal to short-circuit ``reasoning.fit`` past synth-gen and
    student fitting and run finalize-only. For plain
    :class:`~outerproduct.model.Model` / :class:`~outerproduct.model.Predictor`
    / URL teachers, ``get_grads_url`` is ``None``.
    """
    from outerproduct.model import DiffModel, Model, Predictor

    if isinstance(teacher, str):
        return teacher, None, None
    if isinstance(teacher, Predictor):
        headers = teacher.headers or None
        return teacher.url, None, headers
    if isinstance(teacher, Model):
        from outerproduct import _state
        from outerproduct.client import API_VERSION, resolve_api_key, resolve_base_url

        base = resolve_base_url(_state.base_url)
        predict_url = f"{base}/{API_VERSION}/models/{teacher.id}/predict"
        get_grads_url = (
            f"{base}/{API_VERSION}/models/{teacher.id}/get_grads"
            if isinstance(teacher, DiffModel)
            else None
        )
        try:
            key = resolve_api_key(_state.api_key)
        except Exception:
            key = None
        headers = {"Authorization": f"Bearer {key}"} if key else None
        return predict_url, get_grads_url, headers
    raise TypeError(
        f"Cannot extract a predict URL from {type(teacher).__name__}. "
        "Pass a Predictor, a trained Model, or a URL string."
    )
