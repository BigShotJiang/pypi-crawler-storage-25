"""Shared utilities for the OuterProduct SDK."""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import numpy as np
    import pandas as pd

    from outerproduct.client import OuterProductClient


@contextmanager
def _client() -> Generator[OuterProductClient, None, None]:
    """Open a short-lived :class:`OuterProductClient` from global state."""
    from outerproduct import _state
    from outerproduct.client import OuterProductClient

    with OuterProductClient.from_credentials(_state.base_url, _state.api_key) as c:
        yield c


def _prepare_samples(
    X: pd.DataFrame | np.ndarray | list[list[Any]],
    feature_names: list[str] | None = None,
) -> tuple[list[list[Any]], list[str]]:
    """Normalise user input into ``(samples, feature_names)`` for wire requests.

    When *feature_names* is provided, *X* is validated against the expected
    schema:

    - DataFrame columns must equal *feature_names* as a set. Columns are
      reordered to match *feature_names* so the wire payload is always in
      training-time order.
    - ndarray / list column count must equal ``len(feature_names)``.

    When *feature_names* is ``None``, DataFrame columns are used as-is and
    ndarray / list inputs get auto-generated ``x0, x1, ...`` names.

    Parameters
    ----------
    X : pandas.DataFrame, numpy.ndarray, or list of lists
        Input features in any of the SDK's accepted formats.
    feature_names : list of str, optional
        Expected feature schema (typically the model's training-time
        feature names).

    Returns
    -------
    samples : list of lists
        Row-major nested list suitable for the JSON wire format.
    feature_names : list of str
        Column names matching *samples*.

    Raises
    ------
    ValueError
        If *feature_names* is provided and *X*'s columns or column count
        do not match.
    TypeError
        If *X* is not a supported type.
    """
    import numpy as np
    import pandas as pd

    if isinstance(X, pd.DataFrame):
        cols = list(X.columns)
        if feature_names is not None:
            # Duplicate columns must be caught explicitly: set comparison
            # would collapse them and X[feature_names] would silently
            # return the wrong shape.
            if len(cols) != len(set(cols)):
                dupes = sorted({c for c in cols if cols.count(c) > 1})
                raise ValueError(
                    f"DataFrame has duplicate column names: {dupes}. "
                    "Each feature must have a unique name."
                )
            if set(cols) != set(feature_names):
                missing = [n for n in feature_names if n not in cols]
                extra = [c for c in cols if c not in feature_names]
                parts: list[str] = []
                if missing:
                    parts.append(f"missing {missing}")
                if extra:
                    parts.append(f"unexpected {extra}")
                raise ValueError(
                    "DataFrame columns do not match the model's feature schema "
                    f"({'; '.join(parts)}). Expected: {feature_names}."
                )
            X = X[feature_names]
            cols = list(feature_names)
        return X.values.tolist(), cols

    if isinstance(X, np.ndarray):
        arr = np.atleast_2d(X)
        if feature_names is not None and arr.shape[1] != len(feature_names):
            raise ValueError(
                f"Input has {arr.shape[1]} columns but the model expects "
                f"{len(feature_names)} ({feature_names})."
            )
        names = feature_names or [f"x{i}" for i in range(arr.shape[1])]
        return arr.tolist(), list(names)

    if isinstance(X, list):
        n_cols = len(X[0]) if X else 0
        if feature_names is not None and n_cols != len(feature_names):
            raise ValueError(
                f"Input has {n_cols} columns but the model expects "
                f"{len(feature_names)} ({feature_names})."
            )
        names = feature_names or [f"x{i}" for i in range(n_cols)]
        return X, list(names)

    raise TypeError(
        f"Unsupported input type {type(X).__name__}; "
        "expected pandas.DataFrame, numpy.ndarray, or list of lists"
    )
