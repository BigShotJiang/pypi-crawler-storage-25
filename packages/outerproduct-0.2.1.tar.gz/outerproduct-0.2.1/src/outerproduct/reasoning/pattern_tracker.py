"""PatternTracker — aggregate a :class:`ReasoningModel`'s local-rule
explanations into a small, frozen set of labeled filter patterns.

The fit dispatches to a one-shot Modal CPU function on the API server: it
loads the cloudpickled ReasoningModel, materializes X from the supplied
:class:`~outerproduct.dataset.Dataset` (inline / pre-uploaded /
connector-backed — same routing as :func:`outerproduct.reasoning.fit`),
runs ``predict`` + ``explain_prediction`` + ``build_patterns`` end-to-end,
and persists the result. The SDK polls a single GET endpoint and returns
the populated :class:`PatternTracker`.

Quickstart
----------
.. code-block:: python

    import outerproduct as op

    op.init(api_key="...")
    ds = op.FileUploadConnector().upload("data.csv", label_column="churn")
    rm = op.reasoning.fit(ds)
    pt = op.reasoning.pattern_tracker.fit(rm, ds, target_range=(0.5, None))

    pt.patterns           # tuple[FilterPattern, ...]
    pt.distribution(X)    # pd.Series indexed by pattern labels
    pt.transform(X)       # bool DataFrame (n × n_patterns)
    pt.partition(X)       # dict[label, np.ndarray of positional indices]
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from outerproduct.utils import _client, _prepare_samples

if TYPE_CHECKING:
    import numpy as np
    import pandas as pd

    from outerproduct.dataset import Dataset
    from outerproduct.model import ReasoningModel


@dataclass(frozen=True)
class Predicate:
    """One literal of a conjunctive filter: ``feature <op> value``.

    Mirrors the server-side
    ``outerproduct_reasoning.internal.local_rules.Predicate``. ``op`` is
    ``"<="`` or ``">="`` for continuous features (numeric ``value``) or
    ``"=="`` for categoricals.
    """

    feature: str
    op: str
    value: float | int | str | bool

    def evaluate(self, X: pd.DataFrame) -> np.ndarray:
        """Boolean mask: ``True`` where this literal holds for each row of ``X``."""
        col = X[self.feature]
        if self.op == "<=":
            return (col <= self.value).to_numpy()
        if self.op == ">=":
            return (col >= self.value).to_numpy()
        if self.op == "==":
            return (col == self.value).to_numpy()
        raise ValueError(f"Unknown Predicate op: {self.op!r}")


@dataclass(frozen=True)
class FilterPattern:
    """One executable conjunctive filter with coverage stats and a label."""

    predicates: tuple[Predicate, ...]
    label: str
    support_rejects: float
    precision: float
    lift: float
    n_local_rules_covered: int

    def evaluate(self, X: pd.DataFrame) -> np.ndarray:
        """Boolean mask: ``True`` where every predicate holds for the row."""
        import numpy as np

        mask = np.ones(len(X), dtype=bool)
        for p in self.predicates:
            mask &= p.evaluate(X)
        return mask


@dataclass(frozen=True)
class SchemaInfo:
    """Column / dtype / categorical-level snapshot captured at fit time."""

    columns: tuple[str, ...]
    dtypes: dict[str, str] = field(default_factory=dict)
    categorical_levels: dict[str, frozenset] = field(default_factory=dict)


@dataclass(frozen=True)
class PatternTracker:
    """A fitted server-side pattern tracker.

    Construct via :func:`fit`. The instance carries enough metadata
    (``id``, ``model_id``) to call back to the server for
    ``transform`` / ``distribution`` / ``partition`` against fresh data.
    """

    id: str
    model_id: str
    patterns: tuple[FilterPattern, ...]
    schema: SchemaInfo
    target_range: tuple[float | None, float | None]
    n_rejected_fit: int
    coverage_fit: float

    def transform(self, X: Any) -> pd.DataFrame:
        """Boolean DataFrame of shape ``(n_samples, n_patterns)`` — cell
        ``(i, j)`` is true iff sample ``i`` matches pattern label ``j``."""
        import pandas as pd

        from outerproduct_http_types import PatternTrackerApplyRequest

        samples, feature_names = _prepare_samples(X, list(self.schema.columns))
        request = PatternTrackerApplyRequest(
            samples=samples, feature_names=feature_names
        )
        with _client() as c:
            resp = c.pattern_tracker_api.transform(self.model_id, self.id, request)
        return pd.DataFrame(resp.matrix, columns=pd.Index(resp.labels))

    def distribution(self, X: Any) -> pd.Series:
        """Per-pattern match rate over the supplied samples."""
        import pandas as pd

        from outerproduct_http_types import PatternTrackerApplyRequest

        samples, feature_names = _prepare_samples(X, list(self.schema.columns))
        request = PatternTrackerApplyRequest(
            samples=samples, feature_names=feature_names
        )
        with _client() as c:
            resp = c.pattern_tracker_api.distribution(self.model_id, self.id, request)
        labels = [p.label for p in self.patterns]
        return pd.Series(
            {lbl: resp.match_rate.get(lbl, 0.0) for lbl in labels},
            dtype=float,
        )

    def partition(self, X: Any) -> dict[str, np.ndarray]:
        """Positional row indices into ``X`` keyed by pattern label."""
        import numpy as np

        from outerproduct_http_types import PatternTrackerApplyRequest

        samples, feature_names = _prepare_samples(X, list(self.schema.columns))
        request = PatternTrackerApplyRequest(
            samples=samples, feature_names=feature_names
        )
        with _client() as c:
            resp = c.pattern_tracker_api.partition(self.model_id, self.id, request)
        return {
            lbl: np.asarray(idx, dtype=np.int64) for lbl, idx in resp.indices.items()
        }

    def __repr__(self) -> str:
        return (
            f"PatternTracker(id={self.id!r}, model_id={self.model_id!r}, "
            f"patterns={len(self.patterns)}, "
            f"n_rejected_fit={self.n_rejected_fit}, "
            f"coverage_fit={self.coverage_fit:.3f})"
        )


# ---------------------------------------------------------------------
# Module-level fit() — the canonical entry point
# ---------------------------------------------------------------------


def fit(
    reasoning_model: ReasoningModel,
    dataset: Dataset,
    *,
    target_range: tuple[float | None, float | None],
    mode: str = "discovery",
    max_patterns: int = 25,
    coverage_target: float = 0.95,
    min_pattern_support: float = 0.005,
    min_precision: float = 0.5,
    max_pattern_size: int = 3,
    threshold_n_bins: int = 10,
    ensure_coverage: bool = True,
    min_wracc: float = 0.0,
    diversity_threshold: float = 0.5,
    drop_redundant: bool = True,
    child_overlap_threshold: float = 0.9,
    explained_lift_threshold: float = 1.1,
    rule_kwargs: dict[str, Any] | None = None,
    non_blocking: bool = False,
    poll_interval: float = 2.0,
    poll_timeout: float = 3600.0,
) -> "PatternTracker | PatternTrackerJob":
    """Fit a :class:`PatternTracker` against ``reasoning_model`` over
    ``dataset``'s rows.

    Parameters
    ----------
    reasoning_model : :class:`~outerproduct.model.ReasoningModel`
        The model whose rejected rows define the aggregation target.
    dataset : :class:`~outerproduct.dataset.Dataset`
        The data to score and aggregate. Inline / pre-uploaded /
        connector-backed datasets are all supported (same routing as
        :func:`outerproduct.reasoning.fit`).
    target_range : (lo, hi) tuple
        Inclusive prediction band that defines "rejected" rows. Either
        side may be ``None`` for an open bound; at least one must be set.
    non_blocking : bool, default False
        If ``True``, return a :class:`PatternTrackerJob` immediately;
        otherwise block until the fit completes and return the populated
        tracker.

    All remaining keyword arguments mirror the server-side fit
    hyperparameters; see ``outerproduct_reasoning.PatternTracker.fit``
    for their semantics.
    """
    from outerproduct_http_types import PatternTrackerFitRequest

    inline = dataset._to_inline_payload()
    payload: dict[str, Any] = {
        "target_range": target_range,
        "mode": mode,
        "max_patterns": max_patterns,
        "coverage_target": coverage_target,
        "min_pattern_support": min_pattern_support,
        "min_precision": min_precision,
        "max_pattern_size": max_pattern_size,
        "threshold_n_bins": threshold_n_bins,
        "ensure_coverage": ensure_coverage,
        "min_wracc": min_wracc,
        "diversity_threshold": diversity_threshold,
        "drop_redundant": drop_redundant,
        "child_overlap_threshold": child_overlap_threshold,
        "explained_lift_threshold": explained_lift_threshold,
        "rule_kwargs": rule_kwargs,
    }

    # Dataset routing — mirrors outerproduct.reasoning.fit's branching.
    if inline.get("data_connector"):
        payload["data_connector"] = True
        payload["connector_id"] = inline["connector_id"]
        payload["table_name"] = inline["table_name"]
    elif inline.get("data_uploaded"):
        payload["data_uploaded"] = True
        payload["data_model_id"] = inline["dataset_id"]
        payload["feature_names"] = inline.get("feature_names")
    else:
        payload["data"] = inline["data"]
        payload["feature_names"] = inline.get("feature_names")

    if inline.get("label_column") is not None:
        payload["label_column"] = inline["label_column"]

    request = PatternTrackerFitRequest.model_validate(payload)
    with _client() as c:
        resp = c.pattern_tracker_api.create_fit(reasoning_model.id, request)

    tracker_id = resp.tracker_id
    if non_blocking:
        return PatternTrackerJob(model_id=reasoning_model.id, tracker_id=tracker_id)

    return _poll_until_ready(
        reasoning_model.id,
        tracker_id,
        poll_interval=poll_interval,
        poll_timeout=poll_timeout,
    )


# ---------------------------------------------------------------------
# Non-blocking job handle
# ---------------------------------------------------------------------


class PatternTrackerJob:
    """Handle returned by :func:`fit` with ``non_blocking=True``."""

    def __init__(self, *, model_id: str, tracker_id: str) -> None:
        self._model_id = model_id
        self._tracker_id = tracker_id

    @property
    def model_id(self) -> str:
        return self._model_id

    @property
    def tracker_id(self) -> str:
        return self._tracker_id

    def status(self) -> str:
        with _client() as c:
            resp = c.pattern_tracker_api.get(self._model_id, self._tracker_id)
        return resp.status

    def wait(
        self,
        *,
        poll_interval: float = 2.0,
        poll_timeout: float = 3600.0,
    ) -> PatternTracker:
        return _poll_until_ready(
            self._model_id,
            self._tracker_id,
            poll_interval=poll_interval,
            poll_timeout=poll_timeout,
        )

    def __repr__(self) -> str:
        return (
            f"PatternTrackerJob(model_id={self._model_id!r}, "
            f"tracker_id={self._tracker_id!r})"
        )


# ---------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------


def _poll_until_ready(
    model_id: str,
    tracker_id: str,
    *,
    poll_interval: float,
    poll_timeout: float,
) -> PatternTracker:
    """Poll GET /patterns/{tracker_id} until the fit completes; return the
    fully-populated :class:`PatternTracker`. Raises on terminal failure or
    when the deadline elapses."""
    from outerproduct.client.exceptions import JobFailedError, PollTimeoutError

    deadline = time.monotonic() + poll_timeout
    while True:
        with _client() as c:
            resp = c.pattern_tracker_api.get(model_id, tracker_id)
        status = resp.status
        if status == "completed":
            return _from_response(resp)
        if status == "failed":
            raise JobFailedError(model_id, resp.error_message)
        if time.monotonic() > deadline:
            raise PollTimeoutError(
                f"PatternTracker {tracker_id!r} did not complete within "
                f"{poll_timeout}s (last status: {status!r})"
            )
        time.sleep(poll_interval)


def _from_response(resp: Any) -> PatternTracker:
    """Build a frozen client-side :class:`PatternTracker` from the wire response."""
    patterns_wire = resp.patterns or []
    patterns = tuple(
        FilterPattern(
            predicates=tuple(
                Predicate(feature=p.feature, op=p.op, value=p.value)
                for p in fp.predicates
            ),
            label=fp.label,
            support_rejects=fp.support_rejects,
            precision=fp.precision,
            lift=fp.lift,
            n_local_rules_covered=fp.n_local_rules_covered,
        )
        for fp in patterns_wire
    )
    schema_wire = resp.schema_info
    if schema_wire is not None:
        schema = SchemaInfo(
            columns=tuple(schema_wire.columns),
            dtypes=dict(schema_wire.dtypes),
            categorical_levels={
                k: frozenset(v)
                for k, v in (schema_wire.categorical_levels or {}).items()
            },
        )
    else:
        schema = SchemaInfo(columns=())
    target_range = resp.target_range or (None, None)
    return PatternTracker(
        id=resp.tracker_id,
        model_id=resp.model_id,
        patterns=patterns,
        schema=schema,
        target_range=tuple(target_range),
        n_rejected_fit=resp.n_rejected_fit or 0,
        coverage_fit=resp.coverage_fit or 0.0,
    )


__all__ = [
    "FilterPattern",
    "PatternTracker",
    "PatternTrackerJob",
    "Predicate",
    "SchemaInfo",
    "fit",
]
