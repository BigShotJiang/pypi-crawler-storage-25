"""Resource-scoped sub-APIs.

Each class is a thin namespace that delegates to
:meth:`OuterProductClient._get` / :meth:`._post` with the appropriate
typed endpoint constant from :mod:`outerproduct.client.endpoints`. The
endpoints carry the request and response types, so these wrappers add
ergonomic method names without duplicating any type machinery.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from outerproduct_http_types import (
    ConnectorResponse,
    CreateConnectorRequest,
    CreateDocumentUploadRequest,
    CreateDocumentUploadResponse,
    CreateUploadRequest,
    CreateUploadResponse,
    DeleteConnectorResponse,
    ExplainRequest,
    ExplainResponse,
    GlobalDriversRequest,
    GlobalDriversResponse,
    InduceSchemaJobResponse,
    InduceSchemaRequest,
    ListConnectorsResponse,
    ListTablesRequest,
    ListTablesResponse,
    PatternTrackerApplyRequest,
    PatternTrackerDistributionResponse,
    PatternTrackerFitRequest,
    PatternTrackerFitResponse,
    PatternTrackerPartitionResponse,
    PatternTrackerResponse,
    PatternTrackerTransformResponse,
    PredictAndExplainRequest,
    PredictAndExplainResponse,
    PredictRequest,
    PredictResponse,
    ReasoningFitRequest,
    ReasoningFitResponse,
    ScenarioRequest,
    ScenarioResponse,
    SchemaResultResponse,
    TabularizeJobResponse,
    TabularizeRequest,
    TabularizeResultResponse,
    TrainerRunRequest,
    TrainerRunResponse,
    ValidateConnectorResponse,
)

from outerproduct.client.endpoints import (
    CREATE_CONNECTOR,
    CREATE_DOCUMENT_UPLOAD,
    CREATE_UPLOAD,
    DELETE_CONNECTOR,
    EXPLAIN,
    GET_CONNECTOR,
    GET_DOCUMENT_SCHEMA,
    GET_DOCUMENT_TABLE,
    GLOBAL_DRIVERS,
    INDUCE_DOCUMENT_SCHEMA,
    LIST_CONNECTORS,
    LIST_TABLES,
    PATTERN_TRACKER_DISTRIBUTION,
    PATTERN_TRACKER_FIT,
    PATTERN_TRACKER_GET,
    PATTERN_TRACKER_PARTITION,
    PATTERN_TRACKER_TRANSFORM,
    PREDICT,
    PREDICT_AND_EXPLAIN,
    REASONING_FIT,
    SCENARIO,
    TABULARIZE_DOCUMENTS,
    TRAINER_RUN,
    VALIDATE_CONNECTOR,
)

if TYPE_CHECKING:
    from outerproduct.client.client import OuterProductClient


class UploadsAPI:
    """``POST /v1/uploads`` — request a presigned upload URL."""

    def __init__(self, client: OuterProductClient) -> None:
        self._client = client

    def create(self, request: CreateUploadRequest) -> CreateUploadResponse:
        return self._client._post(CREATE_UPLOAD, request)

    def create_document(
        self, request: CreateDocumentUploadRequest
    ) -> CreateDocumentUploadResponse:
        """``POST /v1/uploads/documents`` — presigned URL for one document file."""
        return self._client._post(CREATE_DOCUMENT_UPLOAD, request)


class AgenticDocumentsAPI:
    """Agent-driven document tabularization.

    Endpoints:
      - ``POST /v1/agentic/documents/induce_schema``     → :meth:`induce_schema`
      - ``GET  /v1/agentic/documents/schemas/{model_id}``→ :meth:`get_schema`
      - ``POST /v1/agentic/documents/tabularize``        → :meth:`tabularize`
      - ``GET  /v1/agentic/documents/tables/{model_id}`` → :meth:`get_table`
    """

    def __init__(self, client: OuterProductClient) -> None:
        self._client = client

    def induce_schema(self, request: InduceSchemaRequest) -> InduceSchemaJobResponse:
        return self._client._post(INDUCE_DOCUMENT_SCHEMA, request)

    def get_schema(self, model_id: str) -> SchemaResultResponse:
        return self._client._get(GET_DOCUMENT_SCHEMA, model_id=model_id)

    def tabularize(self, request: TabularizeRequest) -> TabularizeJobResponse:
        return self._client._post(TABULARIZE_DOCUMENTS, request)

    def get_table(self, model_id: str) -> TabularizeResultResponse:
        return self._client._get(GET_DOCUMENT_TABLE, model_id=model_id)


class TrainerAPI:
    """``POST /v1/trainer/run`` — configure a Trainer and run HPO."""

    def __init__(self, client: OuterProductClient) -> None:
        self._client = client

    def run(self, request: TrainerRunRequest) -> TrainerRunResponse:
        return self._client._post(TRAINER_RUN, request)


class ReasoningAPI:
    """``POST /v1/reasoning/fit`` — fit a ReasoningModel."""

    def __init__(self, client: OuterProductClient) -> None:
        self._client = client

    def fit(self, request: ReasoningFitRequest) -> ReasoningFitResponse:
        return self._client._post(REASONING_FIT, request)


class InferenceAPI:
    """Synchronous inference on ``/v1/models/{model_id}/...``."""

    def __init__(self, client: OuterProductClient) -> None:
        self._client = client

    def predict(self, model_id: str, request: PredictRequest) -> PredictResponse:
        return self._client._post(PREDICT, request, model_id=model_id)

    def explain(self, model_id: str, request: ExplainRequest) -> ExplainResponse:
        return self._client._post(EXPLAIN, request, model_id=model_id)

    def predict_and_explain(
        self, model_id: str, request: PredictAndExplainRequest
    ) -> PredictAndExplainResponse:
        return self._client._post(PREDICT_AND_EXPLAIN, request, model_id=model_id)

    def get_global_drivers(
        self, model_id: str, request: GlobalDriversRequest | None = None
    ) -> GlobalDriversResponse:
        return self._client._post(
            GLOBAL_DRIVERS, request or GlobalDriversRequest(), model_id=model_id
        )

    def scenario(self, model_id: str, request: ScenarioRequest) -> ScenarioResponse:
        return self._client._post(SCENARIO, request, model_id=model_id)


class PatternTrackerAPI:
    """Pattern-tracker lifecycle (``fit`` + ``get`` + apply endpoints)."""

    def __init__(self, client: OuterProductClient) -> None:
        self._client = client

    def create_fit(
        self, model_id: str, request: PatternTrackerFitRequest
    ) -> PatternTrackerFitResponse:
        return self._client._post(PATTERN_TRACKER_FIT, request, model_id=model_id)

    def get(self, model_id: str, tracker_id: str) -> PatternTrackerResponse:
        return self._client._get(
            PATTERN_TRACKER_GET, model_id=model_id, tracker_id=tracker_id
        )

    def transform(
        self,
        model_id: str,
        tracker_id: str,
        request: PatternTrackerApplyRequest,
    ) -> PatternTrackerTransformResponse:
        return self._client._post(
            PATTERN_TRACKER_TRANSFORM,
            request,
            model_id=model_id,
            tracker_id=tracker_id,
        )

    def distribution(
        self,
        model_id: str,
        tracker_id: str,
        request: PatternTrackerApplyRequest,
    ) -> PatternTrackerDistributionResponse:
        return self._client._post(
            PATTERN_TRACKER_DISTRIBUTION,
            request,
            model_id=model_id,
            tracker_id=tracker_id,
        )

    def partition(
        self,
        model_id: str,
        tracker_id: str,
        request: PatternTrackerApplyRequest,
    ) -> PatternTrackerPartitionResponse:
        return self._client._post(
            PATTERN_TRACKER_PARTITION,
            request,
            model_id=model_id,
            tracker_id=tracker_id,
        )


class ConnectorsAPI:
    """CRUD and discovery for registered data connectors.

    Endpoints:
      - ``POST   /v1/connectors``                        → create
      - ``GET    /v1/connectors``                         → list
      - ``GET    /v1/connectors/{connector_id}``          → get
      - ``DELETE /v1/connectors/{connector_id}``          → delete
      - ``POST   /v1/connectors/{connector_id}/tables``   → list_tables
      - ``POST   /v1/connectors/{connector_id}/validate`` → validate
    """

    def __init__(self, client: OuterProductClient) -> None:
        self._client = client

    def create(self, request: CreateConnectorRequest) -> ConnectorResponse:
        """Register a new connector (or return existing if name matches)."""
        # CreateConnectorRequest / ConnectorResponse are discriminated
        # `Annotated[Union[...]]` aliases; runtime is fine via TypeAdapter,
        # but ty can't narrow `RespT` to a union alias.
        return self._client._post(  # ty: ignore[invalid-return-type]
            CREATE_CONNECTOR,  # ty: ignore[invalid-argument-type]
            request,
        )

    def list(self) -> ListConnectorsResponse:
        """List all connectors for the authenticated org."""
        return self._client._get(LIST_CONNECTORS)

    def get(self, connector_id: str) -> ConnectorResponse:
        """Get a single connector by ID."""
        return self._client._get(  # ty: ignore[invalid-return-type]
            GET_CONNECTOR,
            connector_id=connector_id,
        )

    def delete(self, connector_id: str) -> DeleteConnectorResponse:
        """Delete a connector."""
        return self._client._delete(DELETE_CONNECTOR, connector_id=connector_id)

    def list_tables(self, connector_id: str) -> ListTablesResponse:
        """List tables/paths available through a connector."""
        return self._client._post(
            LIST_TABLES, ListTablesRequest(), connector_id=connector_id
        )

    def validate(self, connector_id: str) -> ValidateConnectorResponse:
        """Test connectivity for a connector."""
        return self._client._post(
            VALIDATE_CONNECTOR, ListTablesRequest(), connector_id=connector_id
        )


__all__ = [
    "AgenticDocumentsAPI",
    "ConnectorsAPI",
    "InferenceAPI",
    "PatternTrackerAPI",
    "ReasoningAPI",
    "TrainerAPI",
    "UploadsAPI",
]
