"""
pola: Python package for calculating critical bandwidth for bimodal distributions

This package implements algorithms to detect the critical bandwidth in kernel density
estimation, which is the smallest bandwidth where the density estimate remains unimodal.
"""

from .bandwidth import silverman_bandwidth, critical_bandwidth, gaussian_kde

__version__ = "0.0.1"
__all__ = ["silverman_bandwidth", "critical_bandwidth", "gaussian_kde"]
