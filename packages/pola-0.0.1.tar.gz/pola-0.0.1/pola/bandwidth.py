"""
Bandwidth calculation functions for kernel density estimation.
Includes Silverman's rule of thumb and critical bandwidth detection for bimodal distributions.
"""

import numpy as np
from scipy import integrate, optimize
from typing import Optional, Tuple


def silverman_bandwidth(x: np.ndarray) -> float:
    """
    Calculate Silverman's rule of thumb bandwidth for univariate data.
    
    Parameters
    ----------
    x : np.ndarray
        1D array of input data points
        
    Returns
    -------
    float
        Silverman's rule of thumb bandwidth value
        
    Notes
    -----
    Formula: h = 1.06 * min(std, IQR/1.34) * n^(-1/5)
    """
    n = len(x)
    
    if n == 1:
        return 1.0  # Default bandwidth for single point
    
    std = np.std(x, ddof=1)
    iqr = np.subtract(*np.percentile(x, [75, 25]))
    return 1.06 * np.min([std, iqr / 1.34]) * (n ** (-0.2))


def count_modes(x: np.ndarray, h: float, grid_points: int = 1000) -> int:
    """
    Count number of modes in kernel density estimate for given bandwidth.
    
    Parameters
    ----------
    x : np.ndarray
        Input data
    h : float
        Bandwidth value
    grid_points : int, optional
        Number of evaluation points
        
    Returns
    -------
    int
        Number of detected modes
    """
    grid = np.linspace(x.min() - 3*h, x.max() + 3*h, grid_points)
    kde_vals = gaussian_kde(x, grid, h)
    
    # Count sign changes in first derivative (local maxima)
    diff = np.diff(kde_vals)
    sign_changes = ((diff[:-1] > 0) & (diff[1:] < 0)).sum()
    
    return sign_changes + 1


def gaussian_kde(x: np.ndarray, grid: np.ndarray, h: float) -> np.ndarray:
    """
    Gaussian kernel density estimation.
    
    Parameters
    ----------
    x : np.ndarray
        Input data points
    grid : np.ndarray
        Points where density is evaluated
    h : float
        Bandwidth
        
    Returns
    -------
    np.ndarray
        Density estimates at grid points
    """
    n = len(x)
    return np.array([
        np.sum(np.exp(-(xi - x)**2 / (2 * h**2))) / (n * h * np.sqrt(2 * np.pi))
        for xi in grid
    ])


def critical_bandwidth(x: np.ndarray, 
                       h_min: Optional[float] = None,
                       h_max: Optional[float] = None,
                       tol: float = 1e-6,
                       max_iter: int = 100) -> Tuple[float, bool]:
    """
    Calculate critical bandwidth for bimodal distribution.
    
    Critical bandwidth is the smallest bandwidth where the kernel density
    estimate becomes unimodal.
    
    Parameters
    ----------
    x : np.ndarray
        1D array of input data
    h_min : float, optional
        Lower bound for bandwidth search
    h_max : float, optional
        Upper bound for bandwidth search
    tol : float, optional
        Convergence tolerance
    max_iter : int, optional
        Maximum number of iterations
        
    Returns
    -------
    tuple
        (critical_bandwidth_value, convergence_success)
    """
    if h_min is None:
        h_min = silverman_bandwidth(x) / 20.0
    if h_max is None:
        h_max = silverman_bandwidth(x) * 10.0
    
    # Check boundary conditions
    modes_min = count_modes(x, h_min)
    modes_max = count_modes(x, h_max)
    
    if modes_max >= 2:
        return h_max, False  # Unimodal not found even at max bandwidth
    
    if modes_min == 1:
        return h_min, False  # Already unimodal at min bandwidth
    
    # Binary search for critical bandwidth
    low, high = h_min, h_max
    
    for _ in range(max_iter):
        mid = (low + high) / 2
        modes = count_modes(x, mid)
        
        if modes >= 2:
            low = mid
        else:
            high = mid
        
        if high - low < tol:
            break
    
    return (low + high) / 2, True
