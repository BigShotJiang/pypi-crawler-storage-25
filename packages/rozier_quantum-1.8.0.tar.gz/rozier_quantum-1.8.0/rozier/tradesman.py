# rozier/tradesman.py
# =========================================================
# TRADESMAN TOOLS
#
# Physical layout logic for spatial coherence.
# Backdoor solutions for when Smart tech fails.
# The Rozier Standard applied to the physical site.
#
# Tools:
#   calculate_slope_per_foot()  Standard grade logic
#   radius_grade_check()        3D radius backdoor
#   evaluate_pin_density()      How many pins to hold the line
#
# "The Layout is always the answer."
# =========================================================

import numpy as np


class TradesmanTools:
    """
    Sovereign tools for the field.
    When the tablet fails, the math holds.
    """

    def calculate_slope_per_foot(self, rise, run):
        """
        Standard slope-per-foot calculation.
        The String Line for any grade problem.

        Args:
            rise: Total elevation change (feet)
            run:  Total horizontal distance (feet)

        Returns:
            float: Slope in feet per foot
        """
        if run == 0:
            return 0.0
        return round(rise / run, 6)

    def radius_grade_check(
        self, start_elev, end_elev,
        total_arc_length, check_distance
    ):
        """
        The Backdoor Radius.
        Finds elevation at any point on a radius arc
        even when the tablet cannot render it in 3D.

        Args:
            start_elev:       Elevation at arc start (feet)
            end_elev:         Elevation at arc end (feet)
            total_arc_length: Full arc length (feet)
            check_distance:   Distance from start to check (feet)

        Returns:
            dict:
                slope_per_ft:      Grade of the arc
                target_elevation:  Elevation at check_distance
                bust_detected:     True if grade exceeds tolerance
        """
        if total_arc_length == 0:
            return {
                "slope_per_ft"    : 0.0,
                "target_elevation": start_elev,
                "bust_detected"   : False
            }

        total_drop       = start_elev - end_elev
        slope_per_ft     = total_drop / total_arc_length
        drop_at_point    = slope_per_ft * check_distance
        target_elevation = start_elev - drop_at_point

        # Standard tolerance: 1/8 inch = 0.01042 feet
        tolerance    = 0.01042
        bust_detected = abs(total_drop) > tolerance

        return {
            "slope_per_ft"    : round(slope_per_ft, 6),
            "target_elevation": round(target_elevation, 3),
            "bust_detected"   : bust_detected
        }

    def evaluate_pin_density(
        self, total_distance, total_drop, tolerance=0.01042
    ):
        """
        Dynamic Pin Decision.
        Determines how many Stakes are needed
        to hold the line within the Rozier Standard.

        Args:
            total_distance: Length of the run (feet)
            total_drop:     Elevation change (feet)
            tolerance:      Max allowed sag (default 1/8 inch)

        Returns:
            dict:
                pins_needed:   Number of stakes to drive
                slope_per_ft:  Grade of the run
                tension_score: Structural tension value
                status:        DIAMOND STABLE or SUPPORT NEEDED
        """
        if total_distance == 0:
            return {
                "pins_needed"  : 2,
                "slope_per_ft" : 0.0,
                "tension_score": 0.0,
                "status"       : "DIAMOND STABLE"
            }

        slope = total_drop / total_distance

        # Tension = how hard the string is working
        # D4 Neighbors (24) absorb the base load
        tension_score = (abs(slope) * total_distance) / 24

        # Pin decision: one pin per tension unit
        pins_needed = int(np.ceil(tension_score / tolerance))
        pins_needed = max(2, pins_needed)

        status = (
            "DIAMOND STABLE"
            if pins_needed <= 3
            else "SUPPORT NEEDED"
        )

        return {
            "pins_needed"  : pins_needed,
            "slope_per_ft" : round(slope, 6),
            "tension_score": round(tension_score, 6),
            "status"       : status
        }
