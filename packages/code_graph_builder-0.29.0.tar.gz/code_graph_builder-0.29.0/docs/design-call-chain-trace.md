# Call Chain Trace - 向上调用链追踪功能设计

## 1. 需求概述

针对指定的目标函数（如 `LogSaveWithSubId`），找到所有直接调用它的函数，然后从每个 caller 递归向上追溯，直到找到没有被任何函数调用的**入口点（entry point）**，最终以 tree 文本格式展示完整的调用路径，并集成到 Wiki 生成流程中。

## 2. 核心流程

```
用户输入 target_function (e.g. "LogSaveWithSubId")
        │
        ▼
Step 1: 在图数据库中查找 target 节点
        │
        ▼
Step 2: 查找所有直接调用 target 的函数 (direct callers)
        │
        ▼
Step 3: 对每个 direct caller，BFS 向上递归查找 callers
        │  - visited set 防止循环引用
        │  - max_depth 限制深度 (默认 10)
        │  - 无 caller 的节点标记为 entry_point
        │
        ▼
Step 4: 重建所有从 entry_point → ... → direct_caller → target 的路径
        │
        ▼
Step 5: 格式化为 tree 文本输出 + 生成 Wiki 页面
```

## 3. MCP Tool 定义

### 3.1 Tool: `trace_call_chain`

```python
ToolDefinition(
    name="trace_call_chain",
    description=(
        "Trace the complete upward call chain for a given function. "
        "Finds all functions that call the target (directly or indirectly) "
        "and traces each path upward to the top-level entry point. "
        "Outputs a tree-format report and optionally generates a wiki page."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "target_function": {
                "type": "string",
                "description": (
                    "Target function name to trace. Supports simple name "
                    "(e.g. 'LogSaveWithSubId') or fully qualified name "
                    "(e.g. 'project.pkg.log.LogSaveWithSubId')."
                ),
            },
            "max_depth": {
                "type": "integer",
                "description": (
                    "Maximum upward traversal depth. Default: 10. "
                    "Prevents infinite loops in recursive call graphs."
                ),
            },
            "save_wiki": {
                "type": "boolean",
                "description": (
                    "Whether to save the result as a wiki page. Default: true."
                ),
            },
        },
        "required": ["target_function"],
    },
)
```

## 4. 核心算法

### 4.1 BFS 向上追溯 + 路径重建

```python
def trace_upward_call_chain(
    graph_service,       # KuzuIngestor (read-only)
    target_function: str,
    max_depth: int = 10,
) -> TraceResult:
    """
    返回值 TraceResult 包含:
      - target: 目标函数信息
      - direct_callers: 直接调用者列表
      - entry_points: 入口点列表（无 caller 的函数）
      - paths: 所有从 entry_point 到 target 的完整路径
      - tree: 格式化好的 tree 文本
    """

    # --- Step 1: 定位 target 节点 ---
    # 先尝试 qualified_name 精确匹配，再 fallback 到 name 模糊匹配
    # 如果匹配到多个同名函数，全部纳入分析

    # --- Step 2: BFS 向上追溯 ---
    # 数据结构:
    #   parent_map: dict[str, set[str]]
    #     key = 函数 qualified_name
    #     value = 该函数的所有 caller 的 qualified_name 集合
    #   node_info: dict[str, NodeInfo]
    #     key = qualified_name
    #     value = (name, path, start_line, end_line, module)

    queue = deque()  # (qualified_name, current_depth)
    visited = set()
    entry_points = set()

    # 初始化: 将所有 direct callers 入队
    for direct_caller in fetch_callers(target_function):
        queue.append((direct_caller.qualified_name, 1))
        parent_map[direct_caller.qualified_name].add(target_function)

    while queue:
        current_qn, depth = queue.popleft()
        if current_qn in visited:
            continue
        visited.add(current_qn)

        if depth >= max_depth:
            # 达到深度上限，标记为截断入口
            entry_points.add(current_qn)
            continue

        callers = fetch_callers(current_qn)
        if not callers:
            # 没有 caller → 这是入口点
            entry_points.add(current_qn)
        else:
            for caller in callers:
                if caller.qualified_name not in visited:
                    parent_map[caller.qualified_name].add(current_qn)
                    queue.append((caller.qualified_name, depth + 1))

    # --- Step 3: 路径重建 (DFS from each entry_point) ---
    # 从每个 entry_point 出发，沿 parent_map 的反向关系
    # 向下走到 target，收集所有完整路径
    paths = []
    for ep in entry_points:
        dfs_collect_paths(ep, target_qn, call_graph, paths)

    return TraceResult(...)
```

### 4.2 Cypher 查询

复用现有 `GraphQueryService.fetch_callers()` 的逻辑，单层查询：

```cypher
MATCH (caller:Function)-[:CALLS]->(callee)
WHERE callee.qualified_name = $name
   OR callee.name = $name
RETURN caller.qualified_name AS qualified_name,
       caller.name AS name,
       caller.path AS path,
       caller.start_line AS start_line,
       caller.end_line AS end_line
```

逐层 BFS 调用此查询，而非一次性写复杂递归 Cypher，原因：
- Kùzu 对递归路径查询的支持有限
- 逐层查询可以精确控制深度和环检测
- 每层查询结果量小，性能不是瓶颈

## 5. 输出格式：Tree 文本

### 5.1 输出示例

```
============================================================
  Call Chain Trace: LogSaveWithSubId
============================================================

Target: LogSaveWithSubId
  File: pkg/log/save.go:30
  Direct callers: 3
  Entry points: 2
  Total paths: 4
  Max depth: 5

------------------------------------------------------------
  Entry Point 1: main (cmd/main.go:10)
------------------------------------------------------------

main()                                         cmd/main.go:10
└── initServer()                               cmd/init.go:25
    └── startHTTPServer()                      server/http.go:40
        └── handleOrderCreate()                api/order.go:85
            └── saveOrderLog()                 service/order.go:200
                └── LogSaveWithSubId()         pkg/log/save.go:30

main()                                         cmd/main.go:10
└── initServer()                               cmd/init.go:25
    └── startHTTPServer()                      server/http.go:40
        └── handlePaymentCallback()            api/payment.go:120
            └── logPaymentResult()             service/payment.go:95
                └── LogSaveWithSubId()         pkg/log/save.go:30

------------------------------------------------------------
  Entry Point 2: runCronJob (jobs/cron.go:15)
------------------------------------------------------------

runCronJob()                                   jobs/cron.go:15
└── syncExternalData()                         jobs/sync.go:55
    └── logSyncResult()                        jobs/sync.go:88
        └── LogSaveWithSubId()                 pkg/log/save.go:30

============================================================
  Summary
============================================================
  Modules involved: cmd, server, api, service, jobs, pkg
  Deepest chain: 5 levels (main → ... → LogSaveWithSubId)
  Shallowest chain: 3 levels (runCronJob → ... → LogSaveWithSubId)
============================================================
```

### 5.2 格式化规则

- 每个 entry point 独立分组，用分隔线隔开
- 函数名左对齐，文件位置右对齐（用空格填充到固定列宽）
- 使用 `└──` 表示调用层级（Unicode box-drawing 字符）
- target 函数始终出现在每条路径的最底部
- 同一 entry point 下的多条路径按深度排序

## 6. Wiki 集成

### 6.1 Wiki 页面生成

在现有 Wiki 目录下新增 `call-traces/` 子目录：

```
{artifact_dir}/
├── wiki/
│   ├── index.md
│   ├── wiki/
│   │   ├── page-1.md
│   │   └── ...
│   └── call-traces/                    ← 新增
│       └── trace-LogSaveWithSubId.md   ← 每次 trace 生成一个页面
```

### 6.2 Wiki 页面模板

```markdown
# Call Chain Trace: {target_function}

> Generated: {timestamp}
> Repository: {repo_name}

## Overview

| Metric | Value |
|--------|-------|
| Target Function | `{target_function}` |
| File | `{target_file}:{target_line}` |
| Direct Callers | {direct_caller_count} |
| Entry Points | {entry_point_count} |
| Total Paths | {path_count} |
| Max Chain Depth | {max_depth} |

## Call Tree

\```
{tree_text_output}
\```

## Entry Points

{for each entry_point}
### {entry_point_name}
- **File**: `{file}:{line}`
- **Paths to target**: {path_count}
- **Modules traversed**: {module_list}
{end for}

## Direct Callers

| Function | File | Line |
|----------|------|------|
{for each direct_caller}
| `{name}` | `{file}` | {line} |
{end for}

## Affected Modules

{module_list_with_function_counts}
```

### 6.3 与现有 Wiki 系统的集成点

在 `MCPToolsRegistry` 中：
- `trace_call_chain` handler 执行完追踪后，若 `save_wiki=True`，将结果写入 `call-traces/` 目录
- 同时更新 wiki 的 `index.md`，在底部追加 "Call Chain Traces" 索引区域
- `list_wiki_pages` handler 需要同时返回 `call-traces/` 下的页面

## 7. 新增文件

| 文件路径 | 职责 |
|----------|------|
| `code_graph_builder/tools/call_chain_tracer.py` | 核心追踪逻辑：BFS 遍历、路径重建、tree 格式化 |
| `code_graph_builder/mcp/tools.py` | 新增 tool 定义 + handler（修改现有文件） |

### 7.1 `call_chain_tracer.py` 模块结构

```python
# --- 数据类 ---

@dataclass
class NodeInfo:
    """追踪过程中的函数节点信息"""
    qualified_name: str
    name: str
    path: str | None
    start_line: int | None
    end_line: int | None

@dataclass
class CallPath:
    """一条从 entry_point 到 target 的完整调用路径"""
    nodes: list[NodeInfo]   # 从 entry_point 到 target 的有序节点列表
    depth: int

@dataclass
class TraceResult:
    """追踪结果"""
    target: NodeInfo
    direct_callers: list[NodeInfo]
    entry_points: list[NodeInfo]
    paths: list[CallPath]
    max_depth_reached: bool   # 是否触达 max_depth 上限

# --- 核心函数 ---

def trace_call_chain(
    graph_service: QueryProtocol,
    target_function: str,
    max_depth: int = 10,
) -> TraceResult:
    """BFS 向上追溯 + DFS 路径重建"""

def format_tree(result: TraceResult) -> str:
    """将 TraceResult 格式化为 tree 文本"""

def generate_wiki_page(result: TraceResult, tree_text: str) -> str:
    """生成 Markdown wiki 页面内容"""

def save_wiki_page(
    artifact_dir: Path,
    target_name: str,
    content: str,
) -> Path:
    """写入 wiki 文件并更新索引"""
```

### 7.2 `tools.py` 修改点

```python
# 1. tools() 方法中新增 ToolDefinition（见 §3.1）

# 2. get_handler() 中新增映射:
"trace_call_chain": self._handle_trace_call_chain,

# 3. 新增 handler:
async def _handle_trace_call_chain(
    self,
    target_function: str,
    max_depth: int = 10,
    save_wiki: bool = True,
    _progress_cb: ProgressCb = None,
) -> dict[str, Any]:
    self._require_active()

    with self._temporary_ingestor() as ingestor:
        result = trace_call_chain(ingestor, target_function, max_depth)

    tree_text = format_tree(result)
    response = {
        "target": target_function,
        "direct_callers": len(result.direct_callers),
        "entry_points": len(result.entry_points),
        "total_paths": len(result.paths),
        "tree": tree_text,
    }

    if save_wiki and self._active_artifact_dir:
        wiki_content = generate_wiki_page(result, tree_text)
        wiki_path = save_wiki_page(
            self._active_artifact_dir, target_function, wiki_content
        )
        response["wiki_page"] = str(wiki_path)

    return response
```

## 8. 边界情况处理

| 场景 | 处理方式 |
|------|----------|
| 目标函数不存在 | 返回错误 `"Function '{name}' not found in the graph"` |
| 目标函数无 caller | 返回结果，direct_callers=0，提示函数未被调用 |
| 递归/循环调用 (A→B→A) | visited set 防止重复遍历，路径中标注 `[cycle]` |
| 达到 max_depth | 将截断节点标记为 `[truncated at depth N]`，设置 `max_depth_reached=True` |
| 同名函数多个匹配 | 全部纳入分析，在输出中用 qualified_name 区分 |
| 超大调用图 (>1000 paths) | 只保留前 100 条路径，附带总数提示 |

## 9. 对应 Slash Command

新增 Claude Code slash command，方便直接调用：

```
/trace-call-chain <function_name>
```

对应 `.claude/commands/` 下已有的 command 注册模式。
