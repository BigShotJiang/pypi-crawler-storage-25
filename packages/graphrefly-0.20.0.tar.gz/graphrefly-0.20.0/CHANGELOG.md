# CHANGELOG

<!-- version list -->

## v0.20.0 (2026-04-11)

### Chores

- Add integrations page
  ([`7f16d1b`](https://github.com/graphrefly/graphrefly-py/commit/7f16d1b9d9b5aadb5875e4bcb08e6decae469d1f))

- Update docs
  ([`0f2d779`](https://github.com/graphrefly/graphrefly-py/commit/0f2d779eeddcf9eec9ed339bcae4dbf6899363d3))

### Features

- Fix bug
  ([`e5f9cc4`](https://github.com/graphrefly/graphrefly-py/commit/e5f9cc440a854cde0aac1060f02121b85ce06831))


## v0.19.0 (2026-04-10)

### Chores

- 9.0 initial test (needs revisit)
  ([`f47a8b4`](https://github.com/graphrefly/graphrefly-py/commit/f47a8b4d32e999d4f867465f678d576184fc111d))

### Features

- Add start
  ([`4a008dc`](https://github.com/graphrefly/graphrefly-py/commit/4a008dcda7704e14be12a7111b1d0b9188c736b3))

- Address optimization items
  ([`371f9e2`](https://github.com/graphrefly/graphrefly-py/commit/371f9e25e590ded4150fd6aed7e0de3933b8f0f3))

- Consolidate inspection tools
  ([`94aa9af`](https://github.com/graphrefly/graphrefly-py/commit/94aa9af3e3d793103496bfcc71a0a4bbb38f5ea3))

- Fix
  ([`222e66f`](https://github.com/graphrefly/graphrefly-py/commit/222e66f4d8954aa772534c9fc796eea3ba30a304))

- Fix async pytest
  ([`f25ae08`](https://github.com/graphrefly/graphrefly-py/commit/f25ae0885fd824320b498fd2d923f6e4f6ebb0f5))

- Fix inspection tool
  ([`09c90f2`](https://github.com/graphrefly/graphrefly-py/commit/09c90f273613fbae1fd7987397d85d4b6fabec8d))

- Fix retries and reingestions
  ([`55d1a3d`](https://github.com/graphrefly/graphrefly-py/commit/55d1a3d0beff848a6ecefb054e42d194050d5c37))

- Reusable harness patterns
  ([`84bafbb`](https://github.com/graphrefly/graphrefly-py/commit/84bafbb8476c1d00ae373bbc757d4bf813ce16c8))


## v0.18.0 (2026-04-08)

### Features

- Address optimizations
  ([`beddc97`](https://github.com/graphrefly/graphrefly-py/commit/beddc979beda1b8320f4eb94f997c7ee142abed4))


## v0.17.0 (2026-04-07)

### Features

- 9.0 part 2
  ([`1f2bcb7`](https://github.com/graphrefly/graphrefly-py/commit/1f2bcb704ab86e62901114a08433f42edf6a5415))


## v0.16.0 (2026-04-07)

### Features

- 9.0 wiring
  ([`d4d6c72`](https://github.com/graphrefly/graphrefly-py/commit/d4d6c720015b197d8c0f76d5364c090f21a24709))


## v0.15.0 (2026-04-07)

### Features

- Emit -> down
  ([`3c693dd`](https://github.com/graphrefly/graphrefly-py/commit/3c693dda94eb289ef9b017fa5d742cc6bb16059e))


## v0.14.0 (2026-04-07)

### Features

- 9.0
  ([`8fa6920`](https://github.com/graphrefly/graphrefly-py/commit/8fa6920e8b02716fd55bfbb85f1f8329865fad0f))


## v0.13.0 (2026-04-07)

### Features

- Fix stratify
  ([`2dc57ff`](https://github.com/graphrefly/graphrefly-py/commit/2dc57ff6ddbbbfde6c4fc4e3bcdb12375f1eb640))


## v0.12.0 (2026-04-06)

### Features

- Optimize
  ([`f13c4e4`](https://github.com/graphrefly/graphrefly-py/commit/f13c4e4031f00b6a34ab1f94ddc2f5f4184b2545))


## v0.11.0 (2026-04-06)

### Features

- Update descriptions
  ([`ef334eb`](https://github.com/graphrefly/graphrefly-py/commit/ef334ebc347e88c047e6d8ec61307b986841875a))


## v0.10.0 (2026-04-06)

### Features

- 8.2
  ([`abe2102`](https://github.com/graphrefly/graphrefly-py/commit/abe210208ff248d883ac319855108aa4d345812f))


## v0.9.0 (2026-04-06)

### Features

- 8.3
  ([`39b0a9e`](https://github.com/graphrefly/graphrefly-py/commit/39b0a9e8e2a034a27352b2ea054182d58065903f))


## v0.8.0 (2026-04-06)

### Features

- 8.1 + django integration
  ([`5dcfd3d`](https://github.com/graphrefly/graphrefly-py/commit/5dcfd3d78561e7ae8cdc905f95f9b4922926881e))


## v0.7.0 (2026-04-06)

### Features

- Central timer util
  ([`d1285d5`](https://github.com/graphrefly/graphrefly-py/commit/d1285d5c4c95928b1c27e10ca77204ee0f8aaa5e))

- Redesign initial + cached
  ([`86d8506`](https://github.com/graphrefly/graphrefly-py/commit/86d850623e4e09fda1e8547ab67ca6e4cefb2a48))


## v0.6.0 (2026-04-05)

### Chores

- Inspector + data_class
  ([`5bfb409`](https://github.com/graphrefly/graphrefly-py/commit/5bfb409eb62a82cc72d7b4d404981789ded3a3ca))

### Features

- 3.1c
  ([`914e424`](https://github.com/graphrefly/graphrefly-py/commit/914e424e7f934b71e407da187536c16cb63ee43a))


## v0.5.0 (2026-04-05)

### Chores

- Fix mobile nav
  ([`a372c40`](https://github.com/graphrefly/graphrefly-py/commit/a372c40274d1cd7ec57b69414ada245605177334))

### Features

- Address optimization items
  ([`8911fd4`](https://github.com/graphrefly/graphrefly-py/commit/8911fd41a177fe9cfaa7e8932f24f2c2af44135a))


## v0.4.0 (2026-04-04)

### Features

- Fix readme badges
  ([`c88a6ca`](https://github.com/graphrefly/graphrefly-py/commit/c88a6ca8312ab92b709c9d725da1583436318dd9))


## v0.3.0 (2026-04-04)

### Chores

- Fix code pane
  ([`a844d7f`](https://github.com/graphrefly/graphrefly-py/commit/a844d7f3e5d5a34169d67d668f0b9556888814e1))

- Update readme and fix site
  ([`dbcd4d1`](https://github.com/graphrefly/graphrefly-py/commit/dbcd4d11f878b77a3f4ab95ae359d528b1b073af))

### Features

- Fix website's contrast
  ([`002ac99`](https://github.com/graphrefly/graphrefly-py/commit/002ac9988c9051bbbfc2c857a7259ff6f66e3def))


## v0.2.0 (2026-04-04)

### Features

- Fix release version
  ([`2fb85ed`](https://github.com/graphrefly/graphrefly-py/commit/2fb85edb0b106c7253235f072adbe23f540ffa93))

- Use proper zero version
  ([`141805b`](https://github.com/graphrefly/graphrefly-py/commit/141805ba34d88c0a24527735f011f44c806915f2))


## v1.1.0 (2026-04-04)

### Features

- Update release
  ([`af1f04a`](https://github.com/graphrefly/graphrefly-py/commit/af1f04a0a5c984e8c70e1a3a1a30401fa6ba7ec9))


## v1.0.0 (2026-04-04)

- Initial Release
