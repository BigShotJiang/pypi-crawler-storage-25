"""Orient commands — status, balance, positions, orders."""

from typing import Annotated, Optional

import typer

from hl_cli.client import get_account_mode, get_address, get_all_mids, get_dex_balances, get_info, get_spot_balances
from hl_cli.main import hl_app
from hl_cli.output import format_timestamp, output
from hl_cli.resolver import get_resolver


@hl_app.command()
def status(
    ctx: typer.Context,
    address: Annotated[Optional[str], typer.Option("--address", help="Check another address")] = None,
):
    """One-shot account overview: balance + positions + open orders."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address(address)

    state = info.user_state(addr)
    orders = info.frontend_open_orders(addr)
    mids = get_all_mids(info)
    account_mode = get_account_mode(info, addr)
    spot_balances = get_spot_balances(info, addr)
    dex_balances = get_dex_balances(info, addr)

    margin = state.get("crossMarginSummary", state.get("marginSummary", {}))

    positions = []
    for p in state.get("assetPositions", []):
        pos = p["position"]
        size = float(pos["szi"])
        if size == 0:
            continue
        coin = pos["coin"]
        lev = pos["leverage"]
        positions.append({
            "asset": coin,
            "side": "long" if size > 0 else "short",
            "size": str(abs(size)),
            "entry_price": pos["entryPx"],
            "mark_price": mids.get(coin, ""),
            "unrealized_pnl": pos["unrealizedPnl"],
            "liquidation_price": pos.get("liquidationPx", ""),
            "leverage": str(lev["value"]) if isinstance(lev, dict) else str(lev),
            "margin_used": pos["marginUsed"],
        })

    order_list = []
    for o in orders:
        order_list.append({
            "oid": o["oid"],
            "asset": o["coin"],
            "side": "buy" if o["side"] == "B" else "sell",
            "price": o["limitPx"],
            "size": o["sz"],
            "type": (o.get("orderType") or "Limit").lower(),
            "tif": (o.get("tif") or "").lower() or None,
            "reduce_only": o.get("reduceOnly", False),
            "timestamp": format_timestamp(o.get("timestamp", 0)),
        })

    result = {
        "account_mode": account_mode,
        "account_value": margin.get("accountValue", "0"),
        "withdrawable": state.get("withdrawable", "0"),
        "total_margin_used": margin.get("totalMarginUsed", "0"),
        "total_ntl_pos": margin.get("totalNtlPos", "0"),
        "positions": positions,
        "open_orders": order_list,
        "spot_balances": spot_balances,
        "dex_balances": dex_balances,
    }
    output(result, opts["fields"])


@hl_app.command()
def balance(
    ctx: typer.Context,
    address: Annotated[Optional[str], typer.Option("--address", help="Check another address")] = None,
):
    """Account balance."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address(address)

    state = info.user_state(addr)
    account_mode = get_account_mode(info, addr)
    spot_balances = get_spot_balances(info, addr)
    dex_balances = get_dex_balances(info, addr)
    margin = state.get("crossMarginSummary", state.get("marginSummary", {}))

    result = {
        "account_mode": account_mode,
        "account_value": margin.get("accountValue", "0"),
        "total_margin_used": margin.get("totalMarginUsed", "0"),
        "total_ntl_pos": margin.get("totalNtlPos", "0"),
        "withdrawable": state.get("withdrawable", "0"),
        "spot_balances": spot_balances,
        "dex_balances": dex_balances,
    }
    output(result, opts["fields"])


@hl_app.command()
def positions(
    ctx: typer.Context,
    asset: Annotated[Optional[str], typer.Argument(help="Filter by asset")] = None,
    address: Annotated[Optional[str], typer.Option("--address", help="Check another address")] = None,
):
    """Open positions with P&L."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address(address)

    state = info.user_state(addr)
    mids = get_all_mids(info)

    resolved = None
    if asset:
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset)

    result = []
    for p in state.get("assetPositions", []):
        pos = p["position"]
        size = float(pos["szi"])
        if size == 0:
            continue
        coin = pos["coin"]
        if resolved and coin != resolved:
            continue
        lev = pos["leverage"]
        result.append({
            "asset": coin,
            "side": "long" if size > 0 else "short",
            "size": str(abs(size)),
            "entry_price": pos["entryPx"],
            "mark_price": mids.get(coin, ""),
            "unrealized_pnl": pos["unrealizedPnl"],
            "liquidation_price": pos.get("liquidationPx", ""),
            "leverage": str(lev["value"]) if isinstance(lev, dict) else str(lev),
            "margin_used": pos["marginUsed"],
        })

    output(result, opts["fields"])


@hl_app.command()
def orders(
    ctx: typer.Context,
    asset: Annotated[Optional[str], typer.Argument(help="Filter by asset")] = None,
):
    """Open/pending orders."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address()

    raw = info.frontend_open_orders(addr)

    resolved = None
    if asset:
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset)

    result = []
    for o in raw:
        coin = o["coin"]
        if resolved and coin != resolved:
            continue
        result.append({
            "oid": o["oid"],
            "asset": coin,
            "side": "buy" if o["side"] == "B" else "sell",
            "price": o["limitPx"],
            "size": o["sz"],
            "type": (o.get("orderType") or "Limit").lower(),
            "tif": (o.get("tif") or "").lower() or None,
            "reduce_only": o.get("reduceOnly", False),
            "timestamp": format_timestamp(o.get("timestamp", 0)),
        })

    output(result, opts["fields"])
