"""Asset name resolution — maps short tickers to full coin names."""

from hyperliquid.info import Info

from hl_cli.output import die


class Resolver:
    """Resolves user-typed asset names to SDK coin names.

    - Exact match on known coin (e.g. "BTC", "xyz:TSLA") -> use it
    - Case-insensitive match on default perps -> use it
    - Short HIP-3 ticker (e.g. "TSLA") -> resolve, error if ambiguous
    - Lazy-loads HIP-3 dex metadata on first miss against default perps
    """

    def __init__(self, info: Info):
        self.info = info
        self._dexes_loaded = False
        self._short_map: dict[str, list[str]] = {}  # UPPER ticker -> [full names]
        self._build_default_map()

    def _build_default_map(self):
        """Index default perps by uppercase name."""
        for name in self.info.coin_to_asset:
            if ":" not in name and "@" not in name:
                key = name.upper()
                self._short_map.setdefault(key, []).append(name)

    def _load_dexes(self):
        """Lazily load all HIP-3 deployer metadata into the Info client."""
        if self._dexes_loaded:
            return
        self._dexes_loaded = True

        try:
            dex_list = self.info.post("/info", {"type": "perpDexs"})
        except Exception:
            return  # can't load dexes, resolve will fail with unknown_asset

        for idx, dex_info in enumerate(dex_list[1:]):  # skip default dex
            dex_name = dex_info["name"]
            try:
                dex_meta = self.info.meta(dex=dex_name)
                offset = 110000 + idx * 10000
                self.info.set_perp_meta(dex_meta, offset)

                # Index by short ticker for disambiguation
                for asset_info in dex_meta["universe"]:
                    full_name = asset_info["name"]
                    # The API may or may not prefix with dex name
                    if ":" in full_name:
                        _, ticker = full_name.split(":", 1)
                    else:
                        ticker = full_name
                    key = ticker.upper()
                    self._short_map.setdefault(key, []).append(full_name)
            except Exception:
                continue

    def _find_exact(self, name: str) -> str | None:
        """Case-insensitive exact match against all known coins."""
        if name in self.info.coin_to_asset:
            return name
        upper = name.upper()
        for known in self.info.coin_to_asset:
            if known.upper() == upper:
                return known
        return None

    def resolve(self, name: str) -> str:
        """Resolve a user-typed asset name to the SDK coin name.

        Returns the canonical coin name or calls die() on error.
        """
        # Exact match (already known to SDK)
        exact = self._find_exact(name)
        if exact:
            return exact

        # Short-name match against indexed tickers
        key = name.upper()
        matches = self._short_map.get(key)

        if matches is None and not self._dexes_loaded:
            # Try loading HIP-3 dexes
            self._load_dexes()
            # Re-check exact match (full names now loaded)
            exact = self._find_exact(name)
            if exact:
                return exact
            matches = self._short_map.get(key)

        if not matches:
            die(
                "validation_error", "UNKNOWN_ASSET",
                f"Unknown asset: {name}",
                hint="Use 'regard hl assets' to list available assets, or specify full name like 'xyz:TSLA'",
            )

        if len(matches) == 1:
            return matches[0]

        # Multiple matches — prefer default perp (no colon) over HIP-3
        defaults = [m for m in matches if ":" not in m]
        if len(defaults) == 1:
            return defaults[0]

        # Ambiguous — build match info for the error
        mids = {}
        try:
            mids = self.info.all_mids()
            # Also fetch HIP-3 mids for the deployers involved
            dex_list = self.info.post("/info", {"type": "perpDexs"})
            deployers = {m.split(":")[0] for m in matches if ":" in m}
            for dex_info in dex_list[1:]:
                if dex_info["name"] in deployers:
                    dex_mids = self.info.post("/info", {"type": "allMids", "dex": dex_info["name"]})
                    mids.update(dex_mids)
        except Exception:
            pass

        match_info = []
        for m in matches:
            deployer = m.split(":")[0] if ":" in m else ""
            match_info.append({"asset": m, "deployer": deployer, "mid": mids.get(m, "")})

        die(
            "validation_error", "AMBIGUOUS_ASSET",
            f"{name} matches multiple markets",
            hint=f"Use full name: regard hl <command> {matches[0]} ...",
            extra={"matches": match_info},
        )


# Module-level singleton per Info instance
_resolvers: dict[int, Resolver] = {}


def get_resolver(info: Info) -> Resolver:
    """Get or create a Resolver for the given Info client."""
    key = id(info)
    if key not in _resolvers:
        _resolvers[key] = Resolver(info)
    return _resolvers[key]
