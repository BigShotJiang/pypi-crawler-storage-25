from flask import Flask, jsonify, request
from flask_cors import CORS

from crackedai_connect import __version__
from crackedai_connect.detect import detect_environment
from crackedai_connect.executor import execute


def create_app():
    app = Flask(__name__)

    CORS(app, origins=["https://crackedaicode.com", "http://localhost:4000"])

    # Cache detection at startup
    env_info = detect_environment()

    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "ok", "version": __version__, **env_info})

    @app.route("/execute", methods=["POST"])
    def execute_code():
        data = request.get_json()
        required = ["code", "framework", "function_name", "test_cases"]
        missing = [f for f in required if f not in data]
        if missing:
            return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

        result = execute(
            code=data["code"],
            framework=data["framework"],
            function_name=data["function_name"],
            test_cases=data["test_cases"],
            timeout_ms=data.get("timeout_ms", 30000),
            reference_code=data.get("reference_code"),
        )
        return jsonify(result)

    return app
