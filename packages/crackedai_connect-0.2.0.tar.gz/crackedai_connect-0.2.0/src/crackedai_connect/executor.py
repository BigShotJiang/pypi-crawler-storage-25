import json
import statistics
import subprocess
import sys
import tempfile
from pathlib import Path


def _benchmark(code, framework, function_name, test_cases, timeout_ms, runs=3):
    """Run code multiple times and return median runtime_ms.

    Does 1 warmup run (discarded) + `runs` timed runs, returns median.
    Returns None if any run fails.
    """
    harness_path = Path(__file__).parent / "harness.py"
    timeout_sec = timeout_ms / 1000
    runtimes = []

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        (tmpdir / "solution.py").write_text(code)
        (tmpdir / "run_tests.py").write_text(harness_path.read_text())

        for i in range(1 + runs):  # 1 warmup + runs timed
            try:
                result = subprocess.run(
                    [sys.executable, str(tmpdir / "run_tests.py"), framework, function_name, json.dumps(test_cases)],
                    capture_output=True, text=True, timeout=timeout_sec, cwd=str(tmpdir),
                )
            except subprocess.TimeoutExpired:
                return None

            if result.returncode != 0 and not result.stdout.strip():
                return None

            try:
                parsed = json.loads(result.stdout)
            except json.JSONDecodeError:
                return None

            if parsed.get("status") != "passed":
                return None

            if i > 0:  # skip warmup (i == 0)
                runtimes.append(parsed["runtime_ms"])

    return statistics.median(runtimes) if runtimes else None


def execute(code, framework, function_name, test_cases, timeout_ms=30000, reference_code=None):
    """Execute user code against test cases in an isolated subprocess."""
    harness_path = Path(__file__).parent / "harness.py"

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        (tmpdir / "solution.py").write_text(code)
        (tmpdir / "run_tests.py").write_text(harness_path.read_text())

        timeout_sec = timeout_ms / 1000
        try:
            result = subprocess.run(
                [sys.executable, str(tmpdir / "run_tests.py"), framework, function_name, json.dumps(test_cases)],
                capture_output=True, text=True, timeout=timeout_sec, cwd=str(tmpdir),
            )
        except subprocess.TimeoutExpired:
            return {"status": "error", "test_results": [], "stdout": "", "stderr": f"Timed out after {timeout_ms}ms", "runtime_ms": timeout_ms}

        if result.returncode != 0 and not result.stdout.strip():
            return {"status": "error", "test_results": [], "stdout": result.stdout, "stderr": result.stderr, "runtime_ms": 0}

        try:
            parsed = json.loads(result.stdout)
        except json.JSONDecodeError:
            return {"status": "error", "test_results": [], "stdout": result.stdout, "stderr": result.stderr or "Failed to parse harness output", "runtime_ms": 0}

    # Benchmark if reference_code provided and all tests passed
    if reference_code and parsed.get("status") == "passed":
        user_median = _benchmark(code, framework, function_name, test_cases, timeout_ms)
        ref_median = _benchmark(reference_code, framework, function_name, test_cases, timeout_ms)

        if user_median is not None and ref_median is not None and ref_median > 0:
            parsed["benchmark"] = {
                "user_median_ms": round(user_median, 2),
                "reference_median_ms": round(ref_median, 2),
                "ratio": round(user_median / ref_median, 3),
            }

    return parsed
