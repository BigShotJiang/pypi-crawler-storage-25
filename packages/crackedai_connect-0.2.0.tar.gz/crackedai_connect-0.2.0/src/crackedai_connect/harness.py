"""Test harness — runs as a standalone script inside the subprocess.
Usage: python run_tests.py <framework> <function_name> <test_cases_json>
Prints JSON results to stdout.
"""
import json
import sys
import time
import traceback


def deserialize_value(value, framework):
    """Convert JSON value to framework tensor if it has shape+values."""
    if isinstance(value, dict) and "shape" in value and "values" in value:
        import numpy as np
        arr = np.array(value["values"], dtype=np.float32).reshape(value["shape"])
        if framework == "pytorch":
            import torch
            return torch.tensor(arr)
        elif framework == "jax":
            import jax.numpy as jnp
            return jnp.array(arr)
    return value


def serialize_value(value, framework):
    """Convert framework tensor to JSON-serializable format."""
    import numpy as np
    if framework == "pytorch":
        import torch
        if isinstance(value, torch.Tensor):
            return {"shape": list(value.shape), "values": value.detach().cpu().numpy().tolist()}
    elif framework == "jax":
        if hasattr(value, "shape") and hasattr(value, "dtype"):
            return {"shape": list(value.shape), "values": np.array(value).tolist()}
    if isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, np.ndarray):
        return {"shape": list(value.shape), "values": value.tolist()}
    return value


def compare_outputs(actual, expected, tolerance):
    """Compare outputs with numerical tolerance."""
    import numpy as np
    if isinstance(expected, dict) and "values" in expected:
        if isinstance(actual, dict) and "values" in actual:
            return bool(np.allclose(np.array(actual["values"]), np.array(expected["values"]), atol=tolerance))
        return False
    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        return abs(actual - expected) < tolerance
    return actual == expected


def run_tests(framework, function_name, test_cases):
    """Import solution, run test cases, return results."""
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("solution", "solution.py")
        solution = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(solution)
    except Exception:
        return {"status": "error", "test_results": [], "stdout": "", "stderr": traceback.format_exc(), "runtime_ms": 0}

    func = getattr(solution, function_name, None)
    if func is None:
        return {"status": "error", "test_results": [], "stdout": "", "stderr": f"Function '{function_name}' not found in solution.py", "runtime_ms": 0}

    results = []
    total_start = time.time()
    for tc in test_cases:
        start = time.time()
        try:
            kwargs = {k: deserialize_value(v, framework) for k, v in tc["inputs"].items()}
            actual_raw = func(**kwargs)
            actual = serialize_value(actual_raw, framework)
            passed = compare_outputs(actual, tc["expected"], tc.get("tolerance", 1e-5))
            elapsed = int((time.time() - start) * 1000)
            results.append({"id": tc["id"], "passed": passed, "actual": actual, "error": "", "runtime_ms": elapsed})
        except Exception:
            elapsed = int((time.time() - start) * 1000)
            results.append({"id": tc["id"], "passed": False, "actual": None, "error": traceback.format_exc(), "runtime_ms": elapsed})

    total_ms = int((time.time() - total_start) * 1000)
    all_passed = len(results) > 0 and all(r["passed"] for r in results)
    return {"status": "passed" if all_passed else "failed", "test_results": results, "stdout": "", "stderr": "", "runtime_ms": total_ms}


if __name__ == "__main__":
    framework = sys.argv[1]
    function_name = sys.argv[2]
    test_cases = json.loads(sys.argv[3])
    result = run_tests(framework, function_name, test_cases)
    print(json.dumps(result))
