import json
import pytest
from crackedai_connect.server import create_app


@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_health_returns_ok(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "ok"
    assert "hardware" in data
    assert "frameworks" in data
    assert "python" in data


def test_health_has_version(client):
    resp = client.get("/health")
    data = resp.get_json()
    assert data["version"] == "0.1.0"


def test_execute_correct_solution(client):
    resp = client.post("/execute", json={
        "code": "def add(a, b):\n    return a + b",
        "framework": "pytorch",
        "function_name": "add",
        "test_cases": [{"id": "t1", "inputs": {"a": 2, "b": 3}, "expected": 5, "tolerance": 1e-5}],
        "timeout_ms": 5000,
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "passed"
    assert data["test_results"][0]["passed"] is True


def test_execute_wrong_answer(client):
    resp = client.post("/execute", json={
        "code": "def add(a, b):\n    return 0",
        "framework": "pytorch",
        "function_name": "add",
        "test_cases": [{"id": "t1", "inputs": {"a": 2, "b": 3}, "expected": 5, "tolerance": 1e-5}],
        "timeout_ms": 5000,
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "failed"


def test_execute_missing_fields(client):
    resp = client.post("/execute", json={"code": "pass"})
    assert resp.status_code == 400


def test_cors_localhost_allowed(client):
    resp = client.get("/health", headers={"Origin": "http://localhost:4000"})
    assert resp.status_code == 200
    # Check CORS header is present
    assert resp.headers.get("Access-Control-Allow-Origin") is not None
