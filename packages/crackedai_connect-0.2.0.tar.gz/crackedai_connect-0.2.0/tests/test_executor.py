from crackedai_connect.executor import execute


def test_execute_correct_solution():
    result = execute(
        code="import torch\n\ndef softmax(x):\n    e = torch.exp(x - torch.max(x))\n    return e / torch.sum(e)",
        framework="pytorch",
        function_name="softmax",
        test_cases=[{"id": "t1", "inputs": {"x": {"shape": [3], "values": [1.0, 2.0, 3.0]}},
                     "expected": {"shape": [3], "values": [0.0900306, 0.2447285, 0.6652409]}, "tolerance": 1e-4}],
        timeout_ms=10000,
    )
    assert result["status"] == "passed"


def test_execute_timeout():
    result = execute(
        code="import time\n\ndef slow(x):\n    time.sleep(10)\n    return x",
        framework="pytorch",
        function_name="slow",
        test_cases=[{"id": "t1", "inputs": {"x": 1}, "expected": 1, "tolerance": 1e-5}],
        timeout_ms=1000,
    )
    assert result["status"] == "error"
    assert "timeout" in result["stderr"].lower() or "timed out" in result["stderr"].lower()


def test_execute_crash_doesnt_kill_caller():
    result = execute(
        code="import sys; sys.exit(1)",
        framework="pytorch",
        function_name="nope",
        test_cases=[{"id": "t1", "inputs": {"x": 1}, "expected": 1, "tolerance": 1e-5}],
        timeout_ms=5000,
    )
    assert result["status"] == "error"
    assert True  # We're still alive
