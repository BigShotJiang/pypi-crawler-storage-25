# crackedai-connect

Local runtime for [crackedaicode.com](https://crackedaicode.com) — execute ML code on your own machine using your own GPU.

## Install & Run

```bash
pip install crackedai-connect
crackedai-connect
```

That's it. On first run, the CLI auto-detects your hardware and installs the right versions of PyTorch and JAX:

- **NVIDIA GPU** — installs PyTorch + JAX with CUDA support (detects your CUDA version)
- **Apple Silicon** — installs PyTorch with MPS + JAX
- **CPU only** — installs lightweight CPU-only versions

```
$ crackedai-connect

  CrackedAI Runtime v0.1.0

  Missing: PyTorch, JAX
  Detecting hardware...
  Found NVIDIA GPU (CUDA 12.4)
  Installing PyTorch (CUDA 12)... done
  Installing JAX (CUDA 12)... done

  Detected: NVIDIA RTX 4090 | Linux
    pytorch 2.3.0 ✓ (CUDA accelerated)
    jax 0.4.30 ✓ (cuda)
    numpy 1.26.4 ✓

  Listening on http://127.0.0.1:52341
  Open crackedaicode.com to start solving problems.
```

Then open [crackedaicode.com](https://crackedaicode.com) — the website automatically detects the running runtime.

## What This Does

When you click "Run" or "Submit" on crackedaicode.com, your code executes **locally on your machine** — not on a remote server:

- **Your own GPU** — CUDA, Apple Silicon MPS, or CPU
- **Your own packages** — whatever versions the installer sets up
- **Zero latency** — no round-trip to a server
- **Full privacy** — code never leaves your machine

## How It Works

```
Browser (crackedaicode.com)  <-->  localhost:52341 (crackedai-connect)
                                          |
                                 Python subprocess
                                    (your code)
```

## Already Have PyTorch/JAX?

If you already have them installed, `crackedai-connect` will detect and use your existing installation. It only installs frameworks if they're missing.

## For Contributors

```bash
git clone https://github.com/anupa/cracked-ai-connect.git
cd cracked-ai-connect
pixi install
pixi run test
pixi run connect
```

## License

MIT
