# langchain-mixpeek

**AI agents are blind. Mixpeek gives them eyes, ears, and memory.**

`langchain-mixpeek` is the official LangChain integration for [Mixpeek](https://mixpeek.com) — the infrastructure layer that lets AI agents search video, images, audio, and documents. One API to decompose unstructured content into searchable features your agents can query and act on.

## Install

```bash
pip install langchain-mixpeek
```

## Quick start

### 1. Search with a retriever

```python
from langchain_mixpeek import MixpeekRetriever

retriever = MixpeekRetriever(
    api_key="mxp_...",
    retriever_id="ret_abc123",
    namespace="my-namespace",
)
docs = retriever.invoke("find the red cup")
```

Each result is a LangChain `Document` with `page_content` and metadata (`document_id`, `score`, `namespace`).

### 2. One-line agent tool

```python
# Any retriever becomes an agent tool in one line
tool = retriever.as_tool()
```

Or create a standalone tool:

```python
from langchain_mixpeek import MixpeekTool

tool = MixpeekTool(
    api_key="mxp_...",
    retriever_id="ret_abc123",
    namespace="my-namespace",
    name="search_video_archive",
    description="Search video archive for specific scenes, faces, or moments.",
)
result = tool.invoke("camo pattern jacket")  # returns JSON string
```

### 3. Full agent toolkit (6 tools)

Give your agent search, ingest, process, classify, cluster, and alert capabilities:

```python
from langchain_mixpeek import MixpeekToolkit
from langgraph.prebuilt import create_react_agent
from langchain_anthropic import ChatAnthropic

toolkit = MixpeekToolkit(
    api_key="mxp_...",
    namespace="brand-protection",
    bucket_id="bkt_...",
    collection_id="col_...",
    retriever_id="ret_...",
)

agent = create_react_agent(
    ChatAnthropic(model="claude-sonnet-4-20250514"),
    toolkit.get_tools(),
)

result = agent.invoke({
    "messages": [("user", "Scan these product URLs and alert me about counterfeits")]
})
```

| Tool | What it does |
|------|-------------|
| `mixpeek_search` | Search video, images, audio, documents by natural language |
| `mixpeek_ingest` | Upload text, images, video, audio, PDFs, spreadsheets |
| `mixpeek_process` | Trigger feature extraction (embedding, OCR, transcription, face detection) |
| `mixpeek_classify` | Run taxonomy classification on documents |
| `mixpeek_cluster` | Group similar documents (kmeans, dbscan, hdbscan, etc.) |
| `mixpeek_alert` | Set up monitoring with webhook, Slack, or email notifications |

Scope which tools your agent gets:

```python
# Search-only agent
toolkit.get_tools(actions=["search"])

# Ingest + search agent
toolkit.get_tools(actions=["search", "ingest", "process"])
```

### 4. VectorStore (ingest any content type)

```python
from langchain_mixpeek import MixpeekVectorStore

store = MixpeekVectorStore(
    api_key="mxp_...",
    namespace="my-namespace",
    bucket_id="bkt_...",
    collection_id="col_...",
    retriever_id="ret_...",
)

# Ingest any content type
store.add_texts(["product description..."])
store.add_images(["https://example.com/photo.jpg"])
store.add_videos(["https://example.com/clip.mp4"])
store.add_audio(["https://example.com/recording.mp3"])
store.add_pdfs(["https://example.com/doc.pdf"])
store.add_excel(["https://example.com/data.xlsx"])

# Trigger processing (embedding, OCR, face detection, etc.)
store.trigger_processing()

# Search across all modalities
docs = store.similarity_search("red cup on the table")

# Convert to agent tools anytime
tool = store.as_tool()
toolkit = store.as_toolkit()
retriever = store.as_retriever()
```

### 5. Search-only (minimal config)

If you only need search, skip the bucket/collection config:

```python
store = MixpeekVectorStore.from_retriever(
    api_key="mxp_...",
    namespace="my-namespace",
    retriever_id="ret_abc123",
)
docs = store.similarity_search("red cup")
```

### 6. RAG chain

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_anthropic import ChatAnthropic
from langchain_mixpeek import MixpeekRetriever

retriever = MixpeekRetriever(
    api_key="mxp_...",
    retriever_id="ret_...",
    namespace="my-namespace",
)
llm = ChatAnthropic(model="claude-sonnet-4-20250514")

prompt = ChatPromptTemplate.from_template(
    "Answer using this context:\n{context}\n\nQuestion: {question}"
)

chain = {"context": retriever, "question": lambda x: x} | prompt | llm
response = chain.invoke("what happens at 2 minutes?")
```

### 7. Async retriever

```python
from langchain_mixpeek import AsyncMixpeekRetriever

retriever = AsyncMixpeekRetriever(
    api_key="mxp_...",
    retriever_id="ret_abc123",
    namespace="my-namespace",
)
docs = await retriever.ainvoke("find the red cup")
```

## Configuration

| Parameter | Type | Default | Description |
|---|---|---|---|
| `api_key` | str | required | Mixpeek API key (`mxp_...`) |
| `retriever_id` | str | required | Retriever ID for search (`ret_...`) |
| `namespace` | str | required | Namespace to operate in |
| `bucket_id` | str | required* | Bucket for uploads (`bkt_...`) |
| `collection_id` | str | required* | Collection for processing (`col_...`) |
| `top_k` | int | `10` / `5` | Max results (retriever / tool) |
| `content_field` | str | `"text"` | Metadata field used as `page_content` |
| `filters` | dict | `None` | Attribute filters passed to the retriever |

*Required for ingest/processing. Not needed for search-only via `from_retriever()`.

## Platform features

The VectorStore and Toolkit expose the full Mixpeek platform:

- **Taxonomies** — create and execute document classification pipelines
- **Clusters** — group similar documents (kmeans, dbscan, hdbscan, spectral, etc.)
- **Alerts** — set up monitoring with webhook, Slack, or email notifications
- **Plugins** — manage and test custom feature extractors

See the [full documentation](https://docs.mixpeek.com/agent-integrations/langchain) for details.

## Links

- [Documentation](https://docs.mixpeek.com/agent-integrations/langchain)
- [PyPI](https://pypi.org/project/langchain-mixpeek/)
- [GitHub](https://github.com/mixpeek/langchain-mixpeek)
- [Examples](https://github.com/mixpeek/langchain-mixpeek/tree/main/examples)
- [Mixpeek](https://mixpeek.com)

## License

MIT
