"""
Sentry integration for agents deployed on AWS Lambda.

Init runs at module import (not at Agent construction) so exceptions thrown
during cold-start evaluation — user module imports, config loading — are
also captured. Gated on AWS_LAMBDA_FUNCTION_NAME + CIRCUIT_STAGE so local
`circuit run` iteration stays silent.

Capture paths:

  - "user-function": uncaught exceptions from the user's run / unwind
    handlers. Warning level — agent-code bugs, not SDK bugs.
  - "status-update": the agent exhausted all retries trying to POST job
    status back to agent-api.

FastAPI / Starlette HTTP-framework errors are covered by sentry-sdk's
auto-enabled integrations (when AWS_LAMBDA_FUNCTION_NAME is set), along
with top-level uncaught exceptions and unhandled asyncio task errors.
"""

import os
from typing import Any, Literal

_DSN = (
    "https://45c6df6b2cfa7fc716cfe93ac51bfacf"
    "@o4510024638201856.ingest.us.sentry.io/4511237355601920"
)

AgentExceptionSource = Literal["user-function", "status-update"]


def _init() -> Any:
    if not os.environ.get("AWS_LAMBDA_FUNCTION_NAME"):
        return None

    # CIRCUIT_STAGE is normally "staging" or "prod" (set by the agent-upload
    # orchestrator, see infra/agent-upload/src/config/agent-lambda.ts). If it's
    # anything else — missing, mutated, a new stage we haven't added yet —
    # still init and pass the raw value through: losing runtime signal would
    # be worse than a visible orphan bucket that can be hidden in the UI.
    stage = os.environ.get("CIRCUIT_STAGE")
    if stage not in ("staging", "prod"):
        print(
            f"[AGENT-SDK] CIRCUIT_STAGE is unexpected ({stage!r}); "
            f"Sentry events will land in environment={stage or 'unknown'!r}"
        )

    try:
        import sentry_sdk

        sentry_sdk.init(
            dsn=_DSN,
            environment=stage or "unknown",
            traces_sample_rate=0,
        )
        sentry_sdk.set_tag("sdk", "python")
        sentry_sdk.set_tag("runtime", "python")
        return sentry_sdk
    except Exception as err:
        print(f"[AGENT-SDK] Sentry init failed: {err}")
        return None


_sentry: Any = _init()


def capture_agent_exception(
    exc: BaseException,
    *,
    source: AgentExceptionSource,
    session_id: int | None = None,
    job_id: str | None = None,
    kind: Literal["run", "unwind"] | None = None,
) -> None:
    """Capture an exception with scoped tags."""
    if _sentry is None:
        return

    try:
        with _sentry.new_scope() as scope:
            # User-function errors are user-code bugs, not SDK/infra failures —
            # tag them as warnings so they don't page on default alerting.
            scope.set_level("warning" if source == "user-function" else "error")
            scope.set_tag("agent.error.source", source)
            if session_id is not None:
                scope.set_tag("agent.session.id", str(session_id))
            if job_id:
                scope.set_tag("agent.job.id", job_id)
            if kind:
                scope.set_tag("agent.job.kind", kind)
            _sentry.capture_exception(exc)
        _sentry.flush(timeout=2)
    except Exception as err:
        print(f"[AGENT-SDK] Sentry capture failed: {err}")
