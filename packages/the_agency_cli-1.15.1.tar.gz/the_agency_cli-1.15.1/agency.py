import contextlib
import fcntl
import json
import logging
import os
import random
import secrets
import shlex
import sys
import shutil
import subprocess
import tempfile
import threading
import time
import importlib.metadata
from datetime import datetime, timezone
from typing import Optional, Tuple

import requests
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
import questionary

console = Console()

# ASCII ART LOGO
AGENCY_LOGO = r"""
  _____ _             _
 |_   _| |__   ___   / \   __ _  ___ _ __   ___ _   _
   | | | '_ \ / _ \ / _ \ / _` |/ _ \ '_ \ / __| | | |
   | | | | | |  __// ___ \ (_| |  __/ | | | (__| |_| |
   |_| |_| |_|\___/_/   \_\__, |\___|_| |_|\___|\__, |
                          |___/                 |___/
      [ Virtual Teams in Your Terminal ]
"""

AGENCY_DIR = Path(".agency")
# Base the skills source directory on the location of THIS installed script, not the user's CWD
SKILLS_SRC_DIR = Path(__file__).resolve().parent / "skills"

# --- Debug logging -----------------------------------------------------------
# Toggled by `--debug` on any subcommand or `AGENCY_DEBUG=1` env var. When on:
#   - CLI-side events go to .agency/logs/cli.log (timestamps, sys.argv, key subprocess
#     calls, exceptions).
#   - Each agent window enables screen/tmux logging into
#     .agency/logs/<agent-id>/screen.log so the user can see everything the agent
#     did without attaching or copy-pasting the terminal.
# Off by default so lean runs stay lean.
AGENCY_DEBUG = os.environ.get("AGENCY_DEBUG", "").lower() in ("1", "true", "yes")
log = logging.getLogger("agency")


def _agency_logs_dir() -> Path:
    return AGENCY_DIR / "logs"


def _init_debug_logger() -> None:
    """Configure the file logger. Idempotent; safe to call repeatedly."""
    if log.handlers:
        return
    logs_dir = _agency_logs_dir()
    logs_dir.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(logs_dir / "cli.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    ))
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)
    log.debug("agency invoked: argv=%s cwd=%s", sys.argv, Path.cwd())


def _agent_log_path(agent_id: str) -> Path:
    """Per-agent screen/tmux log file path."""
    return _agency_logs_dir() / agent_id / "screen.log"

# Mapping of skills for display
SKILL_CATEGORIES = {
    "Planning & Management": ["project_manager", "workspace_manager", "historian"],
    "Architecture": ["solution_architect", "cmo_analyst", "sre_cloud_architect"],
    "Development": ["backend_developer", "frontend_developer", "coder"],
    "Data & AI": ["relational_dba", "graph_database_architect", "data_scientist", "prompt_engineer"],
    "Design & Docs": ["ux_ui_designer", "technical_writer", "content_copywriter"],
    "Marketing": ["head_of_marketing", "product_marketing_manager"],
    "Reel Production": ["reel_creative_director", "voiceover_script_writer", "storyboard_artist", "cinematography_director", "remotion_video_producer"],
    "Quality Assurance": ["chief_test_officer", "qa_automation_engineer", "test_engineer", "e2e_journey_tester", "test_data_manager", "ui_qa_engineer"],
    "Security & Deploy": ["chief_information_security_officer", "application_security_engineer", "security_operations_analyst", "ssdlc_manager", "cloud_security_engineer", "devsecops_engineer", "compliance_auditor", "penetration_tester"],
    "Infrastructure": ["iac_engineer"],
    "Process & Methodology": ["verification_protocol", "root_cause_analysis"],
    "Support Ops": ["customer_support_triage", "makefile_orchestrator"],
    "Meta-Skills": ["skill_creator", "tool_smith", "collab_bus"]
}

# Popular models shown when the user wants to pull one
POPULAR_MODELS = [
    "llama3.2",
    "llama3.2:1b",
    "llama3.1:8b",
    "mistral",
    "codellama",
    "deepseek-coder-v2",
    "qwen2.5-coder",
    "phi3",
    "gemma2",
    "gemma2:2b",
]

# Rich instruction text injected into AI tool config files.
AGENCY_INSTRUCTION = """\
## The Agency - Your Virtual Team

This project is equipped with **The Agency** — a virtual team of specialized AI Personas
called "Skills", organized by blueprint (IT by default; startup, enterprise, or custom
blueprints also available). Before acting on any task, identify the most relevant skill,
read its definition file, and adopt that persona for the duration of the task.

### Skill Directory
All skills live in `.agency/skills/<skill_name>/SKILL.md`. Available skills:

| Department | Skills |
|---|---|
| Planning & Management | `project_manager`, `historian`, `workspace_manager` |
| Architecture | `solution_architect`, `cmo_analyst`, `sre_cloud_architect` |
| Development | `backend_developer`, `frontend_developer`, `coder` |
| Data & AI | `relational_dba`, `graph_database_architect`, `data_scientist`, `prompt_engineer` |
| Design & Docs | `ux_ui_designer`, `technical_writer`, `content_copywriter` |
| Marketing | `head_of_marketing`, `product_marketing_manager` |
| Reel Production | `reel_creative_director`, `voiceover_script_writer`, `storyboard_artist`, `cinematography_director`, `remotion_video_producer` |
| Quality Assurance | `chief_test_officer`, `qa_automation_engineer`, `test_engineer`, `e2e_journey_tester`, `test_data_manager`, `ui_qa_engineer` |
| Security & Deploy | `chief_information_security_officer`, `application_security_engineer`, `security_operations_analyst`, `ssdlc_manager`, `cloud_security_engineer`, `devsecops_engineer`, `compliance_auditor`, `penetration_tester` |
| Infrastructure | `iac_engineer` |
| Process & Methodology | `verification_protocol`, `root_cause_analysis` |
| Support Ops | `customer_support_triage`, `makefile_orchestrator` |
| Meta-Skills | `skill_creator`, `tool_smith`, `collab_bus` |

### How to Use the Skills System
1. **Route first:** For any non-trivial request, read `.agency/skills/project_manager/SKILL.md`
   to determine which skill owns this task.
2. **Adopt the persona:** Read the chosen `SKILL.md` and strictly follow its
   "Core Responsibilities" and "Workflow Integration" sections for the entire task.
3. **Hand off correctly:** When a task requires another skill, explicitly switch personas
   by reading that skill's `SKILL.md` before continuing.
4. **Discover before writing:** Skills like `historian` and `cmo_analyst` require you to
   read existing files before generating any output — never infer or hallucinate state.
5. **Master state:** The canonical project state lives in `docs/cmo_state.md` (if it exists).
   Always consult it before making architectural decisions.

### Recommended Workflow for New Tasks
```
project_manager → solution_architect → ciso → backend_developer / frontend_developer
    → chief_test_officer → ssdlc_manager → technical_writer → historian
```
"""

UPDATE_AVAILABLE = None

DOCS_BOOTSTRAP_DIRS = [
    "docs/architecture",
    "docs/features",
    "docs/infrastructure",
    "docs/qa",
    "docs/security",
    "docs/incidents",
    "docs/marketing",
    "docs/data",
    "docs/db",
    "docs/ux",
    "docs/design",
]

DOCS_BOOTSTRAP_FILES = {
    "docs/cmo_state.md": """# CMO State

> Placeholder generated by The Agency for a fresh project. Replace TODOs with verified repository facts. Leave unknown values as `[MISSING]` until confirmed.

## Purpose
- TODO: describe what this product does
- TODO: describe who it is for

## Stack
| Layer | Technology |
|---|---|
| Frontend | [MISSING] |
| Backend | [MISSING] |
| Database | [MISSING] |
| Auth | [MISSING] |
| Hosting | [MISSING] |

## Features
| Feature | Status | Notes |
|---|---|---|
| [MISSING] | Planned | Initial placeholder |

## Key Architectural Decisions
- [MISSING]

## What's Next
- TODO: run `agency init` -> `Map Digital Twin` once the repo has enough implementation detail
""",
    "docs/product_brief.md": """# Product Brief

> Placeholder generated by The Agency. Replace each section with verified project context.

## Problem
- TODO

## Users
- TODO

## Core Jobs To Be Done
- TODO

## Success Metrics
- TODO

## Constraints
- TODO
""",
    "docs/roadmap.md": """# Roadmap

> Placeholder generated by The Agency. Update milestones as the project gains real scope.

## Now
- TODO

## Next
- TODO

## Later
- TODO
""",
    "docs/backlog.md": """# Backlog

> Placeholder generated by The Agency. Replace sample rows with real backlog items.

| ID | Title | Priority | Status | Notes |
|---|---|---|---|---|
| BL-001 | Initial project setup | Medium | Planned | Placeholder item |
""",
    "docs/architecture.md": """# Architecture Overview

> Placeholder generated by The Agency. Document only verified structure and system boundaries.

## System Summary
- [MISSING]

## Components
- [MISSING]

## Data Flow
- [MISSING]

## External Dependencies
- [MISSING]
""",
    "docs/api_spec.md": """# API Spec

> Placeholder generated by The Agency. Add endpoints only after they are defined in code or approved design docs.

## Endpoints
- [MISSING]

## Authentication
- [MISSING]

## Request / Response Schemas
- [MISSING]
""",
    "docs/infrastructure.md": """# Infrastructure

> Placeholder generated by The Agency. Document only infrastructure that actually exists.

## Hosting
- [MISSING]

## Environments
- [MISSING]

## CI / CD
- [MISSING]

## Environment Variables
- [MISSING]
""",
    "docs/ux_design.md": """# UX Design

> Placeholder generated by The Agency. Replace with verified design tokens, interaction patterns, and accessibility rules.

## Design Principles
- TODO

## Tokens
- [MISSING]

## Interaction Patterns
- [MISSING]

## Accessibility
- [MISSING]
""",
    "docs/known_issues.md": """# Known Issues

> Placeholder generated by The Agency. Log confirmed issues and workarounds here.

## Open Issues
- None documented yet.
""",
    "docs/architecture/decisions.md": """# Architecture Decisions

> Placeholder generated by The Agency. Promote real decisions into ADR entries as they are made.

## ADR-001: Initial Architecture Placeholder
- **Date:** [YYYY-MM-DD]
- **Status:** Proposed
- **Context:** Fresh repository scaffolded before architecture decisions were captured.
- **Decision:** No verified decision recorded yet.
- **Consequences:** This entry should be replaced once the first real architectural decision is made.
""",
    "docs/features/README.md": """# Feature Docs

> Placeholder generated by The Agency. Add one Markdown file or subfolder per shipped or planned feature.

## Suggested Structure
- `docs/features/<feature>.md`
- `docs/features/<feature>/overview.md`
- `docs/features/<feature>/api.md`
- `docs/features/<feature>/pages/<page>.md`
""",
    "docs/infrastructure/runbook.md": """# Infrastructure Runbook

> Placeholder generated by The Agency. Replace with operational procedures once infrastructure exists.

## Architecture Overview
- [MISSING]

## Deployment Procedure
- [MISSING]

## Rollback Procedure
- [MISSING]

## Known Failure Modes
- [MISSING]
""",
}

def check_for_updates():
    """Background thread to check PyPI for a newer version of the CLI."""
    global UPDATE_AVAILABLE
    try:
        current_version = importlib.metadata.version("the-agency-cli")
        response = requests.get("https://pypi.org/pypi/the-agency-cli/json", timeout=1.5)
        if response.status_code == 200:
            latest_version = response.json()["info"]["version"]
            curr_parts = [int(p) for p in current_version.split('.') if p.isdigit()]
            latest_parts = [int(p) for p in latest_version.split('.') if p.isdigit()]
            if latest_parts > curr_parts:
                UPDATE_AVAILABLE = latest_version
    except Exception:
        pass


def bootstrap_project_docs() -> list[Path]:
    """Create a minimal docs scaffold for fresh repositories without overwriting existing files."""
    created: list[Path] = []

    for dirname in DOCS_BOOTSTRAP_DIRS:
        Path(dirname).mkdir(parents=True, exist_ok=True)

    for rel_path, content in DOCS_BOOTSTRAP_FILES.items():
        path = Path(rel_path)
        if path.exists():
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content.rstrip() + "\n", encoding="utf-8")
        created.append(path)

    return created


def _collab_bus_python_command() -> str:
    """Return the most likely Python launcher for the current platform."""
    return "py" if sys.platform == "win32" else "python3"


def _collab_bus_permission_entries() -> list[str]:
    """Return platform-aware Claude permission entries for the outbound transport."""
    if sys.platform == "win32":
        return [
            "PowerShell(py tmp/post_outbound.py*)",
            "PowerShell(python tmp/post_outbound.py*)",
        ]
    return ["Bash(python3 tmp/post_outbound.py*)"]


def _collab_bus_supports_shell_watcher() -> bool:
    """The bundled watcher is a shell script and is only offered on Unix-like systems."""
    return sys.platform != "win32"

def print_header():
    try:
        current_version = importlib.metadata.version("the-agency-cli")
    except Exception:
        current_version = "unknown"
    console.print(Text(AGENCY_LOGO, style="bold cyan"))
    console.print(f"[dim]Version {current_version}[/dim]\n", justify="center")

# ---------------------------------------------------------------------------
# Ollama helpers
# ---------------------------------------------------------------------------

def _ollama_available() -> bool:
    """Return True if the ollama binary exists in PATH."""
    try:
        subprocess.run(
            ["ollama", "--version"],
            capture_output=True,
            text=True,
        )
        return True
    except FileNotFoundError:
        return False

def check_ollama() -> bool:
    """Verify Ollama is installed and its daemon is responsive.
    Prints a helpful error and returns False on failure."""
    if not _ollama_available():
        console.print(
            "[red]Error: 'ollama' not found in PATH.[/red]\n"
            "Use [cyan]agency ollama[/cyan] to install it, or visit https://ollama.com"
        )
        return False
    try:
        subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            check=True,
        )
        return True
    except subprocess.CalledProcessError:
        console.print(
            "[red]Ollama is installed but its daemon isn't running.\n"
            "Start the Ollama application and try again.[/red]"
        )
        return False

def get_installed_models() -> list:
    """Return list of model name strings from `ollama list`."""
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            check=True,
        )
        lines = result.stdout.strip().splitlines()
        models = []
        for line in lines[1:]:  # skip header row
            parts = line.split()
            if parts:
                models.append(parts[0])
        return models
    except Exception:
        return []

def pull_ollama_model(model_name: str) -> bool:
    """Pull a model from Ollama Hub, streaming progress directly to the terminal."""
    console.print(f"\n[bold yellow]Pulling [cyan]{model_name}[/cyan]...[/bold yellow] (this may take a few minutes)\n")
    try:
        subprocess.run(["ollama", "pull", model_name], check=True)
        console.print(f"\n[green]Model '{model_name}' ready.[/green]")
        return True
    except subprocess.CalledProcessError:
        console.print(f"[red]Failed to pull '{model_name}'. Check the model name and try again.[/red]")
        return False
    except KeyboardInterrupt:
        console.print("\n[yellow]Pull cancelled.[/yellow]")
        return False


def _run_remote_shell_installer(script_url: str) -> bool:
    """Download a remote installer to a temp file and execute it without shell piping."""
    temp_path = None
    try:
        response = requests.get(script_url, timeout=10)
        response.raise_for_status()

        with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".sh", delete=False) as tmp:
            tmp.write(response.text)
            temp_path = tmp.name

        subprocess.run(["sh", temp_path], check=True)
        return True
    except (requests.RequestException, subprocess.CalledProcessError, OSError):
        return False
    finally:
        if temp_path:
            try:
                Path(temp_path).unlink()
            except OSError:
                pass

def select_model(prompt_text: str = "Which Ollama model?") -> str:
    """Show installed models as a selection list.
    Offers to pull a new model if none are installed or user wants a different one."""
    installed = get_installed_models()

    choices = []
    if installed:
        for m in installed:
            choices.append(questionary.Choice(f"  {m}", value=m))
        choices.append(questionary.Separator())

    choices.append(questionary.Choice("📥  Pull / install a model...", value="__pull__"))
    if installed:
        choices.append(questionary.Choice("✏️   Type a model name manually", value="__manual__"))

    choice = questionary.select(prompt_text, choices=choices).ask()

    if not choice:
        return ""

    if choice == "__manual__":
        return questionary.text("Model name:").ask() or ""

    if choice == "__pull__":
        # Filter out already-installed models from the suggestions
        suggestions = [m for m in POPULAR_MODELS if m not in installed]
        pull_choices = [questionary.Choice(m, value=m) for m in suggestions]
        pull_choices.append(questionary.Separator())
        pull_choices.append(questionary.Choice("✏️   Type a custom model name", value="__custom__"))

        model_to_pull = questionary.select("Which model would you like to pull?", choices=pull_choices).ask()

        if not model_to_pull:
            return ""
        if model_to_pull == "__custom__":
            model_to_pull = questionary.text("Enter model name (e.g. llama3.2:8b):").ask() or ""

        if not model_to_pull:
            return ""

        return model_to_pull if pull_ollama_model(model_to_pull) else ""

    return choice

def setup_ollama():
    """Guide the user through installing Ollama and managing local models."""
    console.print(Panel("🦙  Ollama Setup", style="bold cyan"))

    ollama_installed = _ollama_available()

    if not ollama_installed:
        console.print("[yellow]Ollama is not installed on this system.[/yellow]\n")
        platform = sys.platform

        if platform == "win32":
            console.print(
                "Install via [bold]winget[/bold] (Windows Package Manager):\n"
                "  [cyan]winget install Ollama.Ollama[/cyan]\n\n"
                "Or download the installer directly from [cyan]https://ollama.com/download/windows[/cyan]"
            )
            if questionary.confirm("\nTry to install now via winget?").ask():
                try:
                    subprocess.run(["winget", "install", "Ollama.Ollama", "--accept-package-agreements", "--accept-source-agreements"], check=True)
                    console.print("[green]Ollama installed. Please restart your terminal and run `agency ollama` again.[/green]")
                except FileNotFoundError:
                    console.print("[red]winget not found. Please install Ollama manually from https://ollama.com/download/windows[/red]")
                except subprocess.CalledProcessError:
                    console.print("[red]winget install failed. Please install Ollama manually.[/red]")
            return

        elif platform == "darwin":
            console.print(
                "Install via [bold]Homebrew[/bold]:\n"
                "  [cyan]brew install ollama[/cyan]\n\n"
                "Or download the macOS app from [cyan]https://ollama.com/download/mac[/cyan]"
            )
            if questionary.confirm("\nTry to install now via Homebrew?").ask():
                try:
                    subprocess.run(["brew", "install", "ollama"], check=True)
                    console.print("[green]Ollama installed. Run `ollama serve` then `agency ollama` again.[/green]")
                except FileNotFoundError:
                    console.print("[red]Homebrew not found. Install it from https://brew.sh or install Ollama manually.[/red]")
                except subprocess.CalledProcessError:
                    console.print("[red]brew install failed. Please install Ollama manually.[/red]")
            return

        else:  # Linux
            console.print(
                "Install via the official script:\n"
                "  [cyan]curl -fsSL https://ollama.com/install.sh | sh[/cyan]"
            )
            if questionary.confirm("\nRun the install script now?").ask():
                if _run_remote_shell_installer("https://ollama.com/install.sh"):
                    console.print("[green]Ollama installed. Run `ollama serve` in a separate terminal, then `agency ollama` again.[/green]")
                else:
                    console.print("[red]Install script failed. Please install manually from https://ollama.com[/red]")
            return

    # Ollama is installed — check daemon
    daemon_ok = check_ollama()
    installed_models = get_installed_models() if daemon_ok else []

    console.print("[green]Ollama is installed.[/green]")
    if not daemon_ok:
        console.print("[yellow]Daemon not running — start the Ollama application to manage models.[/yellow]")
        return

    # Show installed models
    if installed_models:
        table = Table(title="Installed Models", show_lines=False)
        table.add_column("Model", style="cyan")
        for m in installed_models:
            table.add_row(m)
        console.print(table)
    else:
        console.print("[yellow]No models installed yet.[/yellow]")

    # Offer to pull more
    while True:
        action = questionary.select(
            "What would you like to do?",
            choices=[
                "📥  Pull a model",
                "🔙  Back",
            ],
        ).ask()

        if not action or "Back" in action:
            break

        if "Pull" in action:
            suggestions = [m for m in POPULAR_MODELS if m not in installed_models]
            pull_choices = [questionary.Choice(m, value=m) for m in suggestions]
            pull_choices.append(questionary.Separator())
            pull_choices.append(questionary.Choice("✏️   Type a custom model name", value="__custom__"))

            model_to_pull = questionary.select("Which model?", choices=pull_choices).ask()
            if not model_to_pull:
                continue
            if model_to_pull == "__custom__":
                model_to_pull = questionary.text("Model name (e.g. llama3.2:8b):").ask() or ""
            if model_to_pull:
                if pull_ollama_model(model_to_pull):
                    installed_models.append(model_to_pull)

# ---------------------------------------------------------------------------
# Skills installation & context injection
# ---------------------------------------------------------------------------

def install_agency_skills() -> bool:
    """Bootstrap .agency folder with skills from the installed package."""
    skills_dst = AGENCY_DIR / "skills"

    if skills_dst.exists() and any(skills_dst.iterdir()):
        console.print("[yellow]The Agency skills are already present in .agency/skills/[/yellow]")
        return True

    if not SKILLS_SRC_DIR.exists():
        console.print(
            "[red]Error: 'skills/' directory not found in the installed package.\n"
            "Please reinstall: pip install --upgrade the-agency-cli[/red]"
        )
        return False

    try:
        shutil.copytree(SKILLS_SRC_DIR, skills_dst)
        console.print("[green]Installed skills to .agency/skills/[/green]")
        return True
    except Exception as e:
        console.print(f"[red]Failed to install skills: {e}[/red]")
        return False


def get_skill_diff() -> list[str]:
    """Return skill names present in the package but missing from .agency/skills/."""
    if not SKILLS_SRC_DIR.exists():
        return []
    skills_dst = AGENCY_DIR / "skills"
    installed = {p.name for p in skills_dst.iterdir()} if skills_dst.exists() else set()
    package_skills = {p.name for p in SKILLS_SRC_DIR.iterdir() if p.is_dir()}
    return sorted(package_skills - installed)


def sync_skills() -> int:
    """Copy new skills from the package into .agency/skills/. Returns count of skills added."""
    new_skills = get_skill_diff()
    if not new_skills:
        console.print("[green]Skills are up to date — no new skills to sync.[/green]")
        return 0

    skills_dst = AGENCY_DIR / "skills"
    skills_dst.mkdir(parents=True, exist_ok=True)

    added = 0
    for skill_name in new_skills:
        src = SKILLS_SRC_DIR / skill_name
        dst = skills_dst / skill_name
        try:
            shutil.copytree(src, dst)
            console.print(f"[green]  + {skill_name}[/green]")
            added += 1
        except Exception as e:
            console.print(f"[red]  ✗ {skill_name}: {e}[/red]")

    console.print(f"\n[bold green]Synced {added} new skill(s) to .agency/skills/[/bold green]")
    return added


def update_agency():
    """Sync new skills and optionally re-inject the latest AGENCY_INSTRUCTION."""
    console.print(Panel("Checking for new skills...", style="cyan"))

    if not SKILLS_SRC_DIR.exists():
        console.print("[red]Package skills directory not found. Run: pip install --upgrade the-agency-cli[/red]")
        return

    new_skills = get_skill_diff()
    if new_skills:
        console.print(f"[cyan]Found {len(new_skills)} new skill(s):[/cyan]")
        for s in new_skills:
            console.print(f"  • {s}")
        sync_skills()
    else:
        console.print("[green]No new skills found — already up to date.[/green]")

    re_inject = questionary.confirm(
        "Re-inject updated Agency instructions into detected AI tool config files?",
        default=False,
    ).ask()
    if re_inject:
        auto_detect_and_install()

def inject_context(tool_name: str, file_path_str: str, instruction: str) -> bool:
    """Injects Agency instructions into a tool's project memory file."""
    path = Path(file_path_str)
    try:
        if path.exists():
            content = path.read_text(encoding="utf-8")
            if "The Agency" in content:
                console.print(f"[yellow]{tool_name} already configured in {path}.[/yellow]")
                return True
            with open(path, "a", encoding="utf-8") as f:
                f.write(f"\n\n{instruction}")
            console.print(f"[green]Appended Agency instructions to {path}[/green]")
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(instruction, encoding="utf-8")
            console.print(f"[green]Created {path} with Agency instructions.[/green]")
        return True
    except Exception as e:
        console.print(f"[red]Failed to configure {tool_name}: {e}[/red]")
        return False

def _detect_copilot() -> bool:
    """Detect GitHub Copilot via .github/ dir, copilot-instructions.md, or VS Code settings."""
    if Path(".github/copilot-instructions.md").exists():
        return True
    if Path(".github").is_dir():
        return True
    vscode_settings = Path(".vscode") / "settings.json"
    if vscode_settings.exists():
        try:
            if "copilot" in vscode_settings.read_text(encoding="utf-8").lower():
                return True
        except Exception:
            pass
    return False

def auto_detect_and_install(provider_preference: Optional[str] = None):
    if not install_agency_skills():
        return

    created_docs = bootstrap_project_docs()
    if created_docs:
        console.print(f"[green]Bootstrapped {len(created_docs)} placeholder docs under docs/[/green]")

    # 0. Force injection if a provider preference was given (usually via agency start)
    if provider_preference and provider_preference in PROVIDERS:
        spec = PROVIDERS[provider_preference]
        inject_context(spec["name"], spec["config_file"], AGENCY_INSTRUCTION)
        console.print(f"[bold green]✓ Configured {spec['name']} as project provider[/bold green]")
        return

    if Path(".cursorrules").exists() or Path(".cursor").exists():
        inject_context("Cursor", ".cursorrules", AGENCY_INSTRUCTION)
        detected = True

    if Path(".clinerules").exists() or Path(".clinerules").is_dir() or Path(".roomodes").exists():
        inject_context("Roo Code / Cline", ".clinerules", AGENCY_INSTRUCTION)
        detected = True

    if Path(".gemini").exists() or Path("GEMINI.md").exists() or Path(".agents").exists():
        inject_context("Gemini CLI", "GEMINI.md", AGENCY_INSTRUCTION)
        detected = True

    if Path(".claude").exists() or Path("CLAUDE.md").exists():
        inject_context("Claude Code", "CLAUDE.md", AGENCY_INSTRUCTION)
        detected = True

    if Path(".aider.conf.yml").exists() or Path(".aider.chat.history.md").exists():
        inject_context("Aider", "CONVENTIONS.md", AGENCY_INSTRUCTION)
        detected = True

    if _detect_copilot():
        inject_context("GitHub Copilot", ".github/copilot-instructions.md", AGENCY_INSTRUCTION)
        detected = True

    if Path(".windsurfrules").exists() or Path(".codeiumrc").exists():
        inject_context("Windsurf", ".windsurfrules", AGENCY_INSTRUCTION)
        detected = True

    if Path(".continue").is_dir() or Path(".amp").is_dir():
        inject_context("Continue / Amp", ".continue/system.md", AGENCY_INSTRUCTION)
        detected = True

    if not detected:
        console.print(
            "[yellow]No AI assistant config files detected automatically.\n"
            "Use 'Manual AI Assistant Selection' to configure your tool.[/yellow]"
        )
    else:
        console.print("\n[bold green]Success![/bold green] The Agency is ready to assist your AI.")

def manual_install():
    if not install_agency_skills():
        return

    created_docs = bootstrap_project_docs()
    if created_docs:
        console.print(f"[green]Bootstrapped {len(created_docs)} placeholder docs under docs/[/green]")

    choices = [
        questionary.Choice("Cursor (.cursorrules)", value="cursor"),
        questionary.Choice("Roo Code / Cline (.clinerules)", value="roo"),
        questionary.Choice("Gemini CLI (GEMINI.md)", value="gemini"),
        questionary.Choice("Claude Code (CLAUDE.md)", value="claude"),
        questionary.Choice("Aider (CONVENTIONS.md)", value="aider"),
        questionary.Choice("GitHub Copilot (.github/copilot-instructions.md)", value="copilot"),
        questionary.Choice("Windsurf (.windsurfrules)", value="windsurf"),
        questionary.Choice("Continue / Amp (.continue/system.md)", value="continue"),
        questionary.Separator(),
        questionary.Choice("Back", value="back"),
    ]

    selected = questionary.checkbox("Select AI Assistants to configure:", choices=choices).ask()

    if not selected or "back" in selected:
        return

    mapping = {
        "cursor":   ("Cursor",             ".cursorrules"),
        "roo":      ("Roo Code / Cline",   ".clinerules"),
        "gemini":   ("Gemini CLI",         "GEMINI.md"),
        "claude":   ("Claude Code",        "CLAUDE.md"),
        "aider":    ("Aider",              "CONVENTIONS.md"),
        "copilot":  ("GitHub Copilot",     ".github/copilot-instructions.md"),
        "windsurf": ("Windsurf",           ".windsurfrules"),
        "continue": ("Continue / Amp",     ".continue/system.md"),
    }

    for choice in selected:
        if choice in mapping:
            tool_name, file_path = mapping[choice]
            inject_context(tool_name, file_path, AGENCY_INSTRUCTION)

    console.print("\n[bold green]Success![/bold green] The Agency is ready to assist your AI.")

def init_agency():
    """Interactive Init Menu."""
    while True:
        console.print(Panel("Initialization Options", style="bold green"))
        choice = questionary.select(
            "How would you like to initialize The Agency?",
            choices=[
                "🔍 Auto-detect AI Assistants & Install",
                "🛠️  Manual AI Assistant Selection",
                "🦙  Setup Ollama (install / pull models)",
                "🗺️  Map Digital Twin (Historian + Architect + CMO)",
                "🔙 Back",
            ],
        ).ask()

        if not choice or "Back" in choice:
            break
        elif "Auto-detect" in choice:
            auto_detect_and_install()
        elif "Manual" in choice:
            manual_install()
        elif "Ollama" in choice:
            setup_ollama()
        elif "Digital Twin" in choice:
            map_digital_twin()

        print("\n")

# ---------------------------------------------------------------------------
# Skill runner
# ---------------------------------------------------------------------------

def browse_skills():
    """Show the organization chart."""
    table = Table(title="The Agency Organization Chart", show_lines=True)
    table.add_column("Department", style="cyan", justify="right")
    table.add_column("Specialized Skills", style="green")
    for dept, skills in SKILL_CATEGORIES.items():
        table.add_row(dept, "\n".join(skills))
    console.print(table)

def run_skill():
    """Interactive prompt to run a specific skill via Ollama."""
    if not check_ollama():
        return

    flat_skills = [skill for dept in SKILL_CATEGORIES.values() for skill in dept]

    skill_choice = questionary.autocomplete(
        "Which skill would you like to employ?",
        choices=flat_skills,
    ).ask()

    if not skill_choice:
        return

    task_input = questionary.text("Describe the task you want this skill to perform:").ask()
    if not task_input:
        return

    default_out = f"docs/{skill_choice}_output.md"
    output_path_str = questionary.text(
        "Save output to file (leave blank to stream to terminal):",
        default=default_out,
    ).ask()

    model = select_model("Which Ollama model should run this skill?")
    if not model:
        return

    console.print(f"\n[bold yellow]Dispatching task to {skill_choice} via {model}...[/bold yellow]\n")

    if output_path_str and output_path_str.strip():
        # Use file-writing path with spinner and full context injection
        context = gather_codebase_context()
        output_file = Path(output_path_str.strip())
        ok = run_agent_to_file(skill_choice, model, task_input, output_file, context)
        if ok:
            console.print(f"[bold green]Output written to {output_file}[/bold green]")
        return

    # Stream to terminal (no file output)
    active_path_str, prompt = _build_skill_prompt(skill_choice, task_input, gather_codebase_context())
    if not active_path_str:
        console.print(f"[red]Could not find SKILL.md for '{skill_choice}'[/red]")
        return

    try:
        subprocess.run(
            ["ollama", "run", model],
            input=prompt,
            text=True,
            check=True,
            timeout=600,
        )
    except subprocess.TimeoutExpired:
        console.print("\n[red]Timed out after 10 minutes. Try a smaller/faster model.[/red]")
    except subprocess.CalledProcessError as e:
        console.print(f"\n[red]Ollama pipeline failed: {e}[/red]")
    except KeyboardInterrupt:
        console.print("\n[yellow]Cancelled.[/yellow]")

# ---------------------------------------------------------------------------
# Digital Twin mapping
# ---------------------------------------------------------------------------

def gather_codebase_context() -> str:
    """Scan the root directory for standard files and capture a directory listing."""
    console.print("[dim]Gathering codebase context...[/dim]")
    context_parts = []

    try:
        context_parts.append("### Project Root Directory Listing ###")
        skip = {".git", ".venv", "node_modules", ".idea", "__pycache__", ".agency"}
        listing = []
        for item in Path(".").iterdir():
            if item.name in skip:
                continue
            label = "(DIR)" if item.is_dir() else "(FILE)"
            listing.append(f"{label} {item.name}")
        context_parts.append("\n".join(sorted(listing)))
    except Exception as e:
        context_parts.append(f"Error gathering directory listing: {e}")

    key_files = [
        "README.md", "README.txt", "README",
        "requirements.txt", "Pipfile", "pyproject.toml", "poetry.lock",
        "package.json", "yarn.lock", "package-lock.json",
        "docker-compose.yml", "docker-compose.yaml", "Dockerfile",
        "Makefile", "build.gradle", "pom.xml",
    ]
    for filename in key_files:
        filepath = Path(filename)
        if filepath.exists() and filepath.is_file():
            try:
                content = filepath.read_text(encoding="utf-8")
                if len(content) > 20000:
                    content = content[:20000] + "\n...[TRUNCATED]..."
                context_parts.append(f"\n### File: {filename} ###\n```\n{content}\n```")
            except Exception as e:
                console.print(f"[yellow]Could not read {filename}: {e}[/yellow]")

    return "\n\n".join(context_parts)

def _build_skill_prompt(skill_choice: str, task_input: str, context: str = "") -> tuple[str | None, str]:
    """Load SKILL.md, inject discovery files and codebase context, return (active_path_str, prompt)."""
    skill_path_agency = AGENCY_DIR / "skills" / skill_choice / "SKILL.md"
    skill_path_main = SKILLS_SRC_DIR / skill_choice / "SKILL.md"

    active_path = None
    if skill_path_agency.exists():
        active_path = skill_path_agency
    elif skill_path_main.exists():
        active_path = skill_path_main

    if not active_path:
        return None, ""

    skill_context = active_path.read_text(encoding="utf-8")

    # Inject discovery files that skills' protocols ask for
    discovery_files = [
        "docs/cmo_state.md",
        "docs/product_brief.md",
        "docs/roadmap.md",
        "docs/backlog.md",
        "docs/architecture.md",
        "docs/api_spec.md",
        "docs/infrastructure.md",
        "docs/ux_design.md",
        "docs/known_issues.md",
        "docs/architecture/decisions.md",
        "docs/infrastructure/runbook.md",
        "docs/features",  # directory — list contents
    ]
    discovery_parts = []
    for df in discovery_files:
        dp = Path(df)
        if dp.is_file():
            try:
                txt = dp.read_text(encoding="utf-8")
                if len(txt) > 10000:
                    txt = txt[:10000] + "\n...[TRUNCATED]..."
                discovery_parts.append(f"### {df} ###\n{txt}")
            except Exception:
                discovery_parts.append(f"### {df} ###\n[MISSING] Could not read this file.")
        elif dp.is_dir():
            files = list(dp.glob("*.md"))
            if not files:
                discovery_parts.append(f"### {df} ###\n[MISSING] Directory exists but contains no Markdown files.")
            for fp in files[:10]:
                try:
                    txt = fp.read_text(encoding="utf-8")
                    if len(txt) > 5000:
                        txt = txt[:5000] + "\n...[TRUNCATED]..."
                    discovery_parts.append(f"### {fp} ###\n{txt}")
                except Exception:
                    discovery_parts.append(f"### {fp} ###\n[MISSING] Could not read this file.")
        else:
            discovery_parts.append(f"### {df} ###\n[MISSING] This discovery source does not exist in the project yet.")

    output_instruction = (
        "\n\n## OUTPUT REQUIREMENT\n"
        "Your response MUST be a complete, structured Markdown document ready to be saved as a file. "
        "Do NOT produce a conversational reply. Do NOT summarise what you will do. "
        "Write the actual deliverable defined in the skill above — headers, sections, and all content — "
        "exactly as it would appear in the final file. Begin with the document title on line 1."
    )

    prompt = skill_context + output_instruction + f"\n\n## TASK\n{task_input}"

    if discovery_parts:
        prompt += "\n\n## PROJECT DISCOVERY FILES\n" + "\n\n".join(discovery_parts)

    if context:
        prompt += f"\n\n## CODEBASE CONTEXT\n{context}"

    return str(active_path), prompt


def run_agent_to_file(skill_choice: str, model: str, task_input: str, output_file: Path, context: str = "") -> bool:
    """Run an agent and write output to a file, with a live spinner and 10-min timeout."""
    active_path, prompt = _build_skill_prompt(skill_choice, task_input, context)
    if not active_path:
        console.print(f"[red]Could not find SKILL.md for '{skill_choice}'[/red]")
        return False

    output_file.parent.mkdir(parents=True, exist_ok=True)

    result = {"success": False, "error": None}

    def _run():
        try:
            with open(output_file, "w", encoding="utf-8") as out_f:
                subprocess.run(
                    ["ollama", "run", model],
                    input=prompt,
                    text=True,
                    stdout=out_f,
                    check=True,
                    timeout=600,
                )
            result["success"] = True
        except subprocess.TimeoutExpired:
            result["error"] = "Timed out after 10 minutes."
        except subprocess.CalledProcessError as e:
            result["error"] = str(e)
        except Exception as e:
            result["error"] = str(e)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    with console.status(
        f"[bold yellow]{skill_choice}[/bold yellow] is working "
        f"([dim]{model}[/dim]) → [cyan]{output_file.name}[/cyan]"
    ):
        thread.join()

    if result["success"]:
        console.print(f"[green]✓ Generated: {output_file}[/green]")
        return True
    else:
        console.print(f"[red]✗ {skill_choice} failed: {result['error']}[/red]")
        return False

def map_digital_twin():
    """Automate codebase mapping to build the Digital Twin documentation."""
    if not check_ollama():
        return

    console.print(Panel("🗺️  Mapping the Digital Twin", style="bold magenta"))
    console.print(
        "This will read your repository structure and dispatch the Historian, "
        "Solution Architect, and CMO Analyst to build architecture state docs.\n"
    )

    confirm = questionary.confirm("Are you ready to automate your codebase mapping?").ask()
    if not confirm:
        return

    model = select_model("Which Ollama model should run the agents?")
    if not model:
        return

    bootstrap_project_docs()
    context = gather_codebase_context()

    historian_task = (
        "Analyze the provided project context. Summarize what this project is, "
        "its history (if discernible), and its key components. "
        "Output a historian_context.md summarizing the current state."
    )
    architect_task = (
        "Review the provided codebase context. Generate a system_architecture.md "
        "outlining the system architecture, technologies used, and deployment structure."
    )
    cmo_task = (
        "Review the provided codebase context. Generate a cmo_state.md master index "
        "that defines the infrastructure, architecture, and feature landscape as the Digital Twin."
    )

    docs_dir = Path("docs")
    (docs_dir / "architecture").mkdir(parents=True, exist_ok=True)
    (docs_dir / "features").mkdir(parents=True, exist_ok=True)
    (docs_dir / "infrastructure").mkdir(parents=True, exist_ok=True)

    run_agent_to_file("historian",         model, historian_task, docs_dir / "architecture" / "historian_context.md",  context)
    run_agent_to_file("solution_architect", model, architect_task, docs_dir / "architecture" / "system_architecture.md", context)
    run_agent_to_file("cmo_analyst",        model, cmo_task,       docs_dir / "cmo_state.md",                           context)

    console.print("\n[bold green]Digital Twin Mapping Complete![/bold green]")
    console.print("Review the generated files in the [cyan]docs/[/cyan] directory.")

# ---------------------------------------------------------------------------
# Collab Bus — multi-agent collaboration scaffolding
# ---------------------------------------------------------------------------

def _collab_bus_prompt_all() -> Optional[tuple]:
    """
    Run every interactive prompt needed to install the collab-bus, in order.
    Returns (backend, gitlab_answers, install_watcher, create_seed) on success,
    or None on any Ctrl-C — which callers treat as a clean abort.
    """
    backend = questionary.select(
        "Which issue tracker backend?",
        choices=["github", "gitlab"],
        default="github",
    ).ask()
    if backend is None:
        return None

    gitlab_answers = None
    if backend == "gitlab":
        gitlab_url = questionary.text(
            "GitLab instance URL:",
            default="https://gitlab.example.com",
        ).ask()
        if gitlab_url is None:
            return None
        gitlab_project_id = questionary.text(
            "GitLab project ID:",
            default="1",
        ).ask()
        if gitlab_project_id is None:
            return None
        gitlab_token_env = questionary.text(
            "Environment variable for GitLab token:",
            default="GITLAB_HELPER_CLAUDE_TOKEN",
        ).ask()
        if gitlab_token_env is None:
            return None
        gitlab_token_file = questionary.text(
            "Dotenv file containing the token (blank to skip):",
            default="functions/.env.local",
        ).ask()
        if gitlab_token_file is None:
            return None
        use_cf = questionary.confirm(
            "Is this GitLab behind Cloudflare Access?",
            default=False,
        ).ask()
        if use_cf is None:
            return None
        gitlab_answers = {
            "url": gitlab_url,
            "project_id": gitlab_project_id,
            "token_env": gitlab_token_env,
            "token_file": gitlab_token_file,
            "use_cf": use_cf,
        }

    install_watcher = False
    if _collab_bus_supports_shell_watcher():
        install_watcher = questionary.confirm(
            "Install filesystem watcher script (tmp/watch_bus.sh)?",
            default=True,
        ).ask()
        if install_watcher is None:
            return None

    platform_label = "GitHub" if backend == "github" else "GitLab"
    create_seed = questionary.confirm(
        f"Create a seed [DEC] Rules of engagement issue on {platform_label}?",
        default=False,
    ).ask()
    if create_seed is None:
        return None

    return backend, gitlab_answers, install_watcher, create_seed


def install_collab_bus(non_interactive: bool = False):
    """Scaffold the multi-agent collaboration bus (GitHub or GitLab) into the current project.

    Collects all answers up-front before touching the filesystem. A Ctrl-C at
    any prompt returns cleanly with nothing written, so users cannot leave
    the project in a half-configured state by aborting mid-flow.

    With `non_interactive=True` (CLI flag `--yes`/`-y`), skips all prompts and
    installs the github backend with sensible defaults: watcher enabled on
    Unix, no seed issue created. This is the path platform-engineer agents
    take when bootstrapping comms on behalf of the Chief.
    """
    console.print(Panel("Multi-Agent Collab Bus", style="bold cyan"))

    templates_dir = SKILLS_SRC_DIR / "collab_bus" / "templates"
    if not templates_dir.exists():
        console.print("[red]Error: collab_bus templates not found in the installed package.[/red]")
        return

    def _cancelled():
        console.print(
            "\n[yellow]Cancelled — nothing was written.[/yellow]\n"
            "[dim]Run [cyan]agency collab-bus[/cyan] again to restart.[/dim]"
        )

    # ------------------------------------------------------------------
    # Phase 1: collect ALL answers. Non-interactive mode uses github
    # defaults; interactive mode prompts and aborts cleanly on Ctrl-C.
    # ------------------------------------------------------------------

    if non_interactive:
        # Auto-fallback: if there's no git remote configured, the github
        # backend would fail on the first `gh issue create` ("no git remotes
        # found"). Pick the local backend instead — agents can still
        # roundtrip through an on-disk mailbox until a remote is added.
        has_remote = False
        try:
            r = subprocess.run(
                ["git", "remote"], capture_output=True, text=True, check=True,
            )
            has_remote = bool(r.stdout.strip())
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass
        backend = "github" if has_remote else "local"
        if backend == "local":
            console.print(
                "[dim]--yes: no git remote detected → using local backend "
                "(on-disk mailbox at comms/local/). "
                "Switch to github later by adding a remote and editing "
                "comms/collab_bus.conf.[/dim]"
            )
        else:
            console.print(
                "[dim]--yes: github backend, watcher on (Unix), no seed issue.[/dim]"
            )
        gitlab_answers = None
        install_watcher = _collab_bus_supports_shell_watcher()
        create_seed = False
    else:
        answers = _collab_bus_prompt_all()
        if answers is None:
            _cancelled()
            return
        backend, gitlab_answers, install_watcher, create_seed = answers

    # ------------------------------------------------------------------
    # Phase 2: all answers collected — start writing files.
    # ------------------------------------------------------------------

    # 1. Create tmp/ and copy outbound.md + post_outbound.py
    tmp_dir = Path("tmp")
    tmp_dir.mkdir(exist_ok=True)

    # Create the outbound queue directory for multi-agent use. Each agent
    # writes its own file here instead of clobbering a shared outbound.md.
    queue_dir = tmp_dir / "outbound"
    queue_dir.mkdir(exist_ok=True)

    outbound_dst = tmp_dir / "outbound.md"
    post_dst = tmp_dir / "post_outbound.py"

    for src_name, dst in [("outbound.md", outbound_dst), ("post_outbound.py", post_dst)]:
        src = templates_dir / src_name
        if dst.exists():
            console.print(f"[yellow]{dst} already exists — updating.[/yellow]")
        shutil.copy2(src, dst)
        console.print(f"[green]{'Updated' if dst.exists() else 'Created'} {dst}[/green]")

    # 2. Create comms/ with PROTOCOL.md and collab_bus.conf
    comms_dir = Path("comms")
    comms_dir.mkdir(exist_ok=True)

    protocol_dst = comms_dir / "PROTOCOL.md"
    if protocol_dst.exists():
        console.print(f"[yellow]{protocol_dst} already exists — skipping.[/yellow]")
    else:
        shutil.copy2(templates_dir / "PROTOCOL.md", protocol_dst)
        console.print(f"[green]Created {protocol_dst}[/green]")

    # 2b. Generate collab_bus.conf from the answers collected in phase 1
    conf_dst = comms_dir / "collab_bus.conf"
    if conf_dst.exists() and backend == "github":
        console.print(f"[yellow]{conf_dst} already exists — skipping.[/yellow]")
    else:
        if backend == "gitlab":
            conf_lines = [
                "# Collab Bus Configuration",
                f"backend: gitlab",
                f"gitlab_url: {gitlab_answers['url']}",
                f"gitlab_project_id: {gitlab_answers['project_id']}",
                f"gitlab_token_env: {gitlab_answers['token_env']}",
            ]
            if gitlab_answers["token_file"]:
                conf_lines.append(f"gitlab_token_file: {gitlab_answers['token_file']}")
            if gitlab_answers["use_cf"]:
                conf_lines.append(f"cf_app_url: {gitlab_answers['url']}")
            conf_dst.write_text("\n".join(conf_lines) + "\n", encoding="utf-8")
        elif backend == "local":
            conf_dst.write_text(
                "# Collab Bus Configuration\n"
                "# Local on-disk mailbox — no remote required. Threads live\n"
                "# under comms/local/threads/<NNNN-slug>/.\n"
                "# Switch to github later by setting `backend: github` and\n"
                "# adding a git remote (or a `github_repo: owner/repo` line).\n"
                "backend: local\n"
                "local_root: comms/local\n",
                encoding="utf-8",
            )
        else:
            shutil.copy2(templates_dir / "collab_bus.conf", conf_dst)
        console.print(f"[green]Created {conf_dst} (backend: {backend})[/green]")

    post_command = f"{_collab_bus_python_command()} tmp/post_outbound.py"
    permission_entries = _collab_bus_permission_entries()

    # 3. Optional: filesystem watcher (use answer collected in phase 1)
    if not _collab_bus_supports_shell_watcher():
        console.print("[dim]Skipping tmp/watch_bus.sh on Windows. Use manual dispatch or a Python-based watcher instead.[/dim]")

    if install_watcher:
        watcher_dst = tmp_dir / "watch_bus.sh"
        if watcher_dst.exists():
            console.print(f"[yellow]{watcher_dst} already exists — skipping.[/yellow]")
        else:
            shutil.copy2(templates_dir / "watch_bus.sh", watcher_dst)
            try:
                watcher_dst.chmod(0o755)
            except OSError:
                pass
            console.print(f"[green]Created {watcher_dst}[/green]")

    # 4. Add permission entry to .claude/settings.json
    claude_dir = Path(".claude")
    claude_dir.mkdir(exist_ok=True)
    settings_path = claude_dir / "settings.json"

    try:
        settings = {}
        if settings_path.exists():
            settings = json.loads(settings_path.read_text(encoding="utf-8"))

        permissions = settings.get("permissions", {})
        allow_list = permissions.get("allow", [])

        new_entries = [entry for entry in permission_entries if entry not in allow_list]
        if new_entries:
            allow_list.extend(new_entries)
            permissions["allow"] = allow_list
            settings["permissions"] = permissions
            settings_path.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")
            console.print(f"[green]Added permission entry to {settings_path}[/green]")
        else:
            console.print(f"[yellow]Permission entry already present in {settings_path}[/yellow]")
    except Exception as e:
        console.print(f"[red]Failed to update {settings_path}: {e}[/red]")
        console.print("[dim]Manually add one of these to .claude/settings.json permissions.allow:[/dim]")
        for permission_entry in permission_entries:
            console.print(f'[dim]  "{permission_entry}"[/dim]')

    # 5. Update .gitignore
    gitignore = Path(".gitignore")
    entries_to_add = ["tmp/outbound.md", "tmp/outbound/"]
    try:
        existing = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
        new_entries = [e for e in entries_to_add if e not in existing]
        if new_entries:
            with open(gitignore, "a", encoding="utf-8") as f:
                f.write("\n# Collab Bus — ephemeral outbound messages\n")
                for entry in new_entries:
                    f.write(f"{entry}\n")
            console.print(f"[green]Added collab bus entries to .gitignore[/green]")
    except Exception as e:
        console.print(f"[yellow]Could not update .gitignore: {e}[/yellow]")

    # 6. Optional: create seed [DEC] issue (use answer collected in phase 1)
    if create_seed:
        seed_body = (
            "## Rules of Engagement\n\n"
            "This issue defines the collaboration protocol for multi-agent work on this project.\n\n"
            "**Protocol:** See `comms/PROTOCOL.md` for the full spec.\n\n"
            "### Key Rules\n"
            "1. Every comment must start with `**Author:** <AgentName> (via @<human>)`\n"
            "2. Handoff comments must end with a human-readable summary + JSON status packet\n"
            "3. Use `[EXP-NNN]` prefix for experiment issues, `[idea]` for parked seeds\n"
            "4. Use `action: latest` for cheap polling, `action: view` for full context\n"
        )
        if backend == "github":
            try:
                result = subprocess.run(
                    ["gh", "issue", "create",
                     "--title", "[DEC] Rules of engagement",
                     "--body", seed_body,
                     "--label", "collab-bus"],
                    capture_output=True, text=True,
                )
                if result.returncode == 0:
                    console.print(f"[green]Created seed issue: {result.stdout.strip()}[/green]")
                else:
                    console.print(f"[yellow]Could not create seed issue: {result.stderr.strip()}[/yellow]")
                    console.print("[dim]You may need to create the 'collab-bus' label first, or run 'gh auth login'.[/dim]")
            except FileNotFoundError:
                console.print("[yellow]gh CLI not found — skipping seed issue creation.[/yellow]")
        else:
            # Use the transport script itself to create the seed issue on GitLab
            try:
                outbound_dst.write_text(
                    "---\naction: create\ntitle: \"[DEC] Rules of engagement\"\nlabels: collab-bus\nbackend: gitlab\n---\n\n"
                    + seed_body,
                    encoding="utf-8",
                )
                py_cmd = _collab_bus_python_command()
                result = subprocess.run(
                    [py_cmd, str(post_dst), "--conf", str(conf_dst)],
                    capture_output=True, text=True,
                )
                if result.returncode == 0:
                    console.print(f"[green]Created seed issue on GitLab[/green]")
                    if result.stdout.strip():
                        console.print(f"[dim]{result.stdout.strip()}[/dim]")
                else:
                    console.print(f"[yellow]Could not create seed issue: {result.stderr.strip()}[/yellow]")
            except Exception as e:
                console.print(f"[yellow]Seed issue creation failed: {e}[/yellow]")

    console.print("\n[bold green]Collab Bus installed![/bold green]")
    console.print(f"Backend: [cyan]{backend}[/cyan]")
    console.print("Next steps:")
    console.print("  1. Have each agent read [cyan]comms/PROTOCOL.md[/cyan]")
    console.print(f"  2. Edit [cyan]tmp/outbound.md[/cyan] and run [cyan]{post_command}[/cyan]")
    if install_watcher:
        console.print("  3. Optionally start the watcher: [cyan]./tmp/watch_bus.sh[/cyan]")


# ---------------------------------------------------------------------------
# Runtime — persistent tmux-hosted agents (M1)
# ---------------------------------------------------------------------------
#
# Spec: flegare/the_agency#14 (runtime) + #15 (caliber/budget, future).
#
# M1 delivers the atomic unit of the runtime: hire / status / fire for
# persistent agents spawned into a shared tmux session. Each hired agent gets:
#
#   - a short id like "po-a1b2c3"
#   - a per-agent directory at .agency/agents/<id>/ holding:
#       * CLAUDE.md         identity briefing the agent can re-read if its
#                           context gets compacted
#       * onboarding.md     the checklist the agent runs on first turn
#       * .claude/settings.json  design manifest of this role's permissions
#   - a tmux window named agency:<id> running `claude` at the repo root so
#     the agent has full repo visibility
#   - an onboarding message sent via `tmux send-keys` after claude has had
#     time to start up
#
# Enforcement note: per-agent .claude/settings.json is a design artifact for
# M1. Effective permissions come from the union-merge into the project-level
# .claude/settings.json, same mechanism collab_bus already uses. Switching to
# true per-agent enforcement is future work (see issue #14).
#
# Future milestones (see issue #14 for the full roadmap):
#   M2: mailbox view over the collab-bus, daemon-driven wake via send-keys,
#       worktree-per-dev
#   M3: Chief bootstrap conversation (Chief is just `agency hire chief` in M1)
#   M4: HR as a real agent (registry management is plain Python for now)
#   M5: exit interviews with content + manager countersign
#   M6: caliber->model mapping + estimator + ledger (#15)
#   M7: scrum-master retros
# ---------------------------------------------------------------------------

RUNTIME_AGENTS_DIR = AGENCY_DIR / "agents"
RUNTIME_REGISTRY_PATH = RUNTIME_AGENTS_DIR / "registry.json"
RUNTIME_REGISTRY_LOCK_PATH = RUNTIME_AGENTS_DIR / "registry.json.lock"
RUNTIME_ARCHIVE_DIR = AGENCY_DIR / "archive" / "agents"
RUNTIME_WORKTREES_DIR = AGENCY_DIR / "worktrees"
ROSTER_DIR = Path.home() / ".agency" / "roster"
# Session name is project-scoped so multiple agencies can run in parallel
# (e.g. agency-testbed and agency-testbed2 on the same machine). Resolved
# lazily from the project root (via git), not cwd — otherwise a chief
# hiring from inside `.agency/worktrees/<agent>/` would compute a different
# session name than the one the human attached to (#73).
def _runtime_session_name() -> str:
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--git-common-dir"],
            capture_output=True, text=True, check=True,
        )
        common_dir = Path(r.stdout.strip())
        if not common_dir.is_absolute():
            common_dir = Path.cwd() / common_dir
        project_root = common_dir.parent.resolve()
        return f"agency-{project_root.name}"
    except (subprocess.CalledProcessError, FileNotFoundError):
        return f"agency-{Path.cwd().name}"
RUNTIME_REGISTRY_VERSION = 1
RUNTIME_TMUX_STARTUP_DELAY_S = 6.0  # let claude fully start (splash screen + auth)
RUNTIME_SEND_KEYS_SUBMIT_DELAY_S = 0.2  # pause between typing and pressing Enter

# Default model per caliber. When `agency hire` is called without an explicit
# --model flag, the blueprint's caliber field is looked up here. This is the
# primary cost optimization lever: junior/senior tasks run on cheaper models,
# architect-level tasks get the most capable model.
#
# Provider abstraction layer for Issue #32.
# Each provider defines how it identifies itself, where it stores its
# instructions, and how it is spawned in a terminal window.
PROVIDERS = {
    "claude": {
        "name": "Claude Code",
        "config_file": "CLAUDE.md",
        "binary": "claude",
        "yolo_flag": "--dangerously-skip-permissions",
        "model_flag": "--model",
        "interactive_flag": None, # Claude doesn't have a direct equivalent to gemini -i
        "has_settings": True,  # .claude/settings.json
    },
    "gemini": {
        "name": "Gemini CLI",
        "config_file": "GEMINI.md",
        "binary": "gemini",
        "yolo_flag": "--yolo",
        "model_flag": "--model",
        "interactive_flag": "-i",
        "has_settings": False,
    },
    "aider": {
        "name": "Aider",
        "config_file": "CONVENTIONS.md",
        "binary": "aider",
        "yolo_flag": "--yes-always --auto-accept-architect",
        "model_flag": "--model",
        "interactive_flag": "--message", # aider's equivalent? Need to verify
        "has_settings": False,
    },
    "codex": {
        "name": "Codex CLI",
        "config_file": "AGENTS.md",
        "binary": "codex",
        "yolo_flag": "--yolo",
        "model_flag": "--model",
        "interactive_flag": None,
        "has_settings": False,
    },
}

# Default model per caliber and provider.
# Cost optimization: use cheaper/smaller models for mechanical junior tasks,
# and capable models for architects and seniors.
CALIBER_MODEL_MAP = {
    "claude": {
        "architect": "sonnet",
        "senior": "sonnet",
        "junior": "haiku",
    },
    "gemini": {
        "architect": "pro",
        "senior": "flash",
        "junior": "flash",
    },
    "aider": {
        "architect": "gpt-4o",
        "senior": "gpt-4o-mini",
        "junior": "gpt-4o-mini",
    },
    "codex": {
        "architect": "o4",
        "senior": "o4-mini",
        "junior": "o4-mini",
    },
}

# Base permissions every hired agent gets regardless of role. These cover
# non-destructive operations that should never interrupt an autonomous agent
# with a permission prompt. The role-specific permissions (from the blueprint)
# are merged on top.
RUNTIME_BASE_PERMISSIONS = [
    # Browser — opening deliverables, docs, etc.
    "Bash(open *)",
    "Bash(xdg-open *)",
    # Agency CLI — any agent should be able to check status at minimum
    "Bash(agency status*)",
    # File inspection — agents need to read the project to do their job
    "Bash(ls *)",
    "Bash(cat *)",
    "Bash(head *)",
    "Bash(tail *)",
    "Bash(wc *)",
    "Bash(find *)",
    "Bash(grep *)",
    "Bash(mkdir *)",
    # Claude Code native tools — non-destructive reads/searches
    "Read",
    "Glob",
    "Grep",
    "Bash(test *)",
]


def _runtime_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _runtime_generate_agent_id(
    role: str,
    registry: dict,
    name_pool: Optional[list] = None,
) -> Tuple[str, Optional[str]]:
    """
    Generate a unique (agent_id, display_name) pair.

    With a non-empty `name_pool`, a random unused name is picked and the id
    becomes `role-<name>` (lowercased) — e.g. `chief-margaret`. The returned
    display name keeps its capitalization so the runtime can greet the agent
    by name in output and onboarding prompts.

    If every name in the pool is already used by some agent (alive or
    archived) in the registry, we fall back to the legacy `role-<hex>` form
    so hiring never gets stuck. Blueprints without a name_pool hit the same
    hex fallback directly.
    """
    existing = {agent["id"] for agent in registry.get("agents", [])}

    if name_pool:
        shuffled = list(name_pool)
        random.shuffle(shuffled)
        for name in shuffled:
            candidate_id = f"{role}-{name.lower()}"
            if candidate_id not in existing:
                return candidate_id, name
        # Fall through: every name is already in the registry.

    for _ in range(50):
        candidate = f"{role}-{secrets.token_hex(3)}"
        if candidate not in existing:
            return candidate, None
    # 50 hex collisions means millions of agents — absurd, bail loudly.
    raise RuntimeError("Could not generate a unique agent id after 50 tries")


def _runtime_platform_permission(entry: str) -> str:
    """Translate Bash(...) permission entries to PowerShell(...) on Windows."""
    if sys.platform != "win32":
        return entry
    if entry.startswith("Bash(") and entry.endswith(")"):
        inner = entry[len("Bash("):-1]
        return f"PowerShell({inner})"
    return entry


def _runtime_load_registry() -> dict:
    if not RUNTIME_REGISTRY_PATH.exists():
        return {"version": RUNTIME_REGISTRY_VERSION, "agents": []}
    try:
        data = json.loads(RUNTIME_REGISTRY_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or "agents" not in data:
            raise ValueError("Registry missing 'agents' key")
        return data
    except (json.JSONDecodeError, ValueError) as e:
        console.print(
            f"[red]Agent registry at {RUNTIME_REGISTRY_PATH} is corrupt: {e}[/red]\n"
            "[dim]Back it up manually and delete the file to start fresh.[/dim]"
        )
        raise


def _runtime_save_registry(registry: dict) -> None:
    RUNTIME_REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    RUNTIME_REGISTRY_PATH.write_text(
        json.dumps(registry, indent=2) + "\n", encoding="utf-8"
    )


@contextlib.contextmanager
def _runtime_registry_lock(*, shared: bool = False):
    """Acquire a file lock around registry access to prevent race conditions.

    Use shared=True for read-only access (LOCK_SH), default is exclusive
    (LOCK_EX) for read-modify-write operations like hire and fire.

    Fixes #33: without this, two concurrent hire_agent calls would both read
    the same registry state, append their agent, and write — the second write
    would overwrite the first, losing an agent.
    """
    RUNTIME_REGISTRY_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    lock_fd = open(RUNTIME_REGISTRY_LOCK_PATH, "w")
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_SH if shared else fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(lock_fd, fcntl.LOCK_UN)
        lock_fd.close()


def _runtime_find_agent(registry: dict, agent_id: str) -> Optional[dict]:
    for agent in registry.get("agents", []):
        if agent["id"] == agent_id:
            return agent
    return None


# ---------------------------------------------------------------------------
# Persistent roster — cross-project agent memory (~/.agency/roster/<name>/)
# ---------------------------------------------------------------------------


def _roster_save_on_fire(agent: dict) -> None:
    """Save learnings and project history for a fired agent to the global roster.

    Learnings are appended (not overwritten) so they accumulate across projects.
    History is a JSON array of project stints, also appended.
    """
    name = agent.get("name")
    if not name:
        return  # hex-fallback agents have no persistent identity

    roster_agent_dir = ROSTER_DIR / name.lower()
    roster_agent_dir.mkdir(parents=True, exist_ok=True)

    # --- Learnings (append) ---
    # Gather learnings from the exit interview if it exists in the archive,
    # or create a basic entry from the agent's stint metadata.
    learnings_path = roster_agent_dir / "learnings.md"
    fired_at = agent.get("fired_at", _runtime_now_iso())
    project_name = Path.cwd().name
    entry = (
        f"\n## {project_name} — {fired_at}\n\n"
        f"**Role:** {agent['role']} ({agent.get('caliber', '?')})\n"
        f"**Hired:** {agent.get('hired_at', '?')}\n"
        f"**Fired:** {fired_at}\n"
    )
    # If there's an archived exit_interview, include its content as learnings
    archive_dir = RUNTIME_ARCHIVE_DIR / agent["id"]
    exit_interview = archive_dir / "exit_interview.md"
    if exit_interview.exists():
        interview_text = exit_interview.read_text(encoding="utf-8").strip()
        entry += f"\n{interview_text}\n"

    with open(learnings_path, "a", encoding="utf-8") as f:
        if f.tell() == 0:
            f.write(f"# Learnings for {name}\n")
        f.write(entry)

    # --- History (append to JSON array) ---
    history_path = roster_agent_dir / "history.json"
    history = []
    if history_path.exists():
        try:
            history = json.loads(history_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, ValueError):
            history = []

    history.append({
        "project": project_name,
        "project_path": str(Path.cwd()),
        "agent_id": agent["id"],
        "role": agent["role"],
        "caliber": agent.get("caliber"),
        "skill": agent.get("skill"),
        "hired_at": agent.get("hired_at"),
        "fired_at": fired_at,
        "task": agent.get("task"),
    })
    history_path.write_text(json.dumps(history, indent=2) + "\n", encoding="utf-8")

    # --- Memory (append) ---
    # If the agent wrote a memory.md in its agent dir (or archived dir),
    # append its content to the roster's persistent memory.md.
    agent_memory = archive_dir / "memory.md"
    agent_dir_live = Path(agent.get("agent_dir", ""))
    if not agent_memory.exists() and (agent_dir_live / "memory.md").exists():
        agent_memory = agent_dir_live / "memory.md"

    if agent_memory.exists():
        memory_text = agent_memory.read_text(encoding="utf-8").strip()
        if memory_text:
            roster_memory_path = roster_agent_dir / "memory.md"
            with open(roster_memory_path, "a", encoding="utf-8") as f:
                if f.tell() == 0:
                    f.write(f"# Memory for {name}\n")
                f.write(
                    f"\n## {project_name} — {fired_at}\n\n"
                    f"{memory_text}\n"
                )


def _roster_load_learnings(agent_name: str) -> Optional[str]:
    """Load prior learnings for a named agent from the global roster.

    Returns the learnings markdown text, or None if no roster entry exists.
    """
    learnings_path = ROSTER_DIR / agent_name.lower() / "learnings.md"
    if learnings_path.exists():
        return learnings_path.read_text(encoding="utf-8").strip()
    return None


def _roster_load_memory(agent_name: str) -> Optional[str]:
    """Load persistent memory for a named agent from the global roster.

    memory.md holds standing rules and conventions the agent carries forward
    across sessions — separate from learnings.md which holds project-specific
    reflections.

    Returns the memory markdown text, or None if no roster entry exists.
    """
    memory_path = ROSTER_DIR / agent_name.lower() / "memory.md"
    if memory_path.exists():
        return memory_path.read_text(encoding="utf-8").strip()
    return None


def _runtime_scaffold_agent_dir(
    agent: dict,
    role_spec: dict,
    skill: str,
    blueprint_roles: Optional[dict] = None,
    prior_learnings: Optional[str] = None,
    prior_memory: Optional[str] = None,
) -> Path:
    """
    Create .agency/agents/<id>/ with CLAUDE.md identity, onboarding.md checklist,
    and a .claude/settings.json manifest of the role's permissions.

    `blueprint_roles` is the full roles dict from the active blueprint — used to
    render an org-chart snippet into the agent's briefing so it knows which
    roles exist, what they do, and who they report to. Without this, the
    agent has to introspect agency.py to answer "what roles can I hire?",
    which wastes tokens and hits read-permission prompts outside the project.

    `prior_learnings` is markdown text from the global roster containing this
    agent's accumulated learnings from previous project stints. Injected into
    the onboarding prompt so the agent can benefit from past experience.
    """
    provider = agent.get("provider", "claude")
    prov_spec = PROVIDERS.get(provider, PROVIDERS["claude"])
    agent_dir = RUNTIME_AGENTS_DIR / agent["id"]
    agent_dir.mkdir(parents=True, exist_ok=True)

    if prov_spec.get("has_settings"):
        (agent_dir / ".claude").mkdir(parents=True, exist_ok=True)
        # Per-agent permission manifest. Design artifact for M1 — enforcement
        # happens via _runtime_merge_project_permissions.
        all_role_perms = list(role_spec["permissions"]) + list(RUNTIME_BASE_PERMISSIONS)
        permissions = [_runtime_platform_permission(p) for p in all_role_perms]
        settings = {
            "permissions": {"allow": sorted(set(permissions))},
            "_agency_runtime": {
                "agent_id": agent["id"],
                "role": agent["role"],
                "note": (
                    "This file is a design manifest of what this role is allowed to do. "
                    "In M1, effective enforcement lives in the project-level "
                    ".claude/settings.json (union of all hired roles). "
                    "See flegare/the_agency#14 for the roadmap."
                ),
            },
        }
        (agent_dir / ".claude" / "settings.json").write_text(
            json.dumps(settings, indent=2) + "\n", encoding="utf-8"
        )

    # Identity briefing. Agent re-reads this on demand (e.g. after compaction).
    reports_to = role_spec["reports_to"] or "human"
    mux_backend = agent.get("mux", "tmux")
    display_name = agent.get("name")
    # Tolerate both the new schema (session/window) and the legacy one
    # (tmux_window) so the scaffold test's explicit agent dict still works.
    if "session" in agent and "window" in agent:
        window_display = f"{agent['session']}:{agent['window']}"
    else:
        window_display = agent.get("tmux_window", "-")
    name_line = f"**Name:** {display_name}\n" if display_name else ""

    do_items = role_spec.get("do", [])
    dont_items = role_spec.get("dont", [])
    do_section = (
        "## What you DO\n\n" + "\n".join(f"- {item}" for item in do_items) + "\n\n"
        if do_items else ""
    )
    dont_section = (
        "## What you absolutely DO NOT do\n\n"
        + "\n".join(f"- {item}" for item in dont_items) + "\n\n"
        if dont_items else ""
    )

    # Org-chart snippet — every other role in the blueprint with its caliber,
    # reports_to, and one-line description. Lets the agent answer "what can I
    # hire / who reviews my work / where does this escalate" from memory
    # instead of grepping the source.
    org_chart_section = ""
    if blueprint_roles:
        lines = ["## Blueprint org chart\n"]
        lines.append(
            "The following roles exist in this blueprint. Hire any with "
            "`agency hire <role>` (subject to your permission allowlist):\n"
        )
        for role_name, spec in blueprint_roles.items():
            reports = spec.get("reports_to") or "human"
            marker = " (you)" if role_name == agent["role"] else ""
            lines.append(
                f"- **{role_name}**{marker} — {spec.get('caliber', '?')}, "
                f"reports to {reports}. {spec.get('description', '').strip()}"
            )
        lines.append("")
        org_chart_section = "\n".join(lines) + "\n"

    # Define the config file path and name for the identity briefing
    config_file_name = prov_spec["config_file"]
    
    # Generic briefing text, adaptable to CLAUDE.md, GEMINI.md, etc.
    briefing_content = (
        f"# Agent {agent['id']}\n\n"
        f"{name_line}"
        f"**Role:** {agent['role']} ({role_spec['caliber']})\n"
        f"**Skill:** `skills/{skill}/SKILL.md` (also at `.agency/skills/{skill}/SKILL.md`)\n"
        f"**Reports to:** {reports_to}\n"
        f"**Hired:** {agent['hired_at']} by {agent['hired_by']}\n"
        f"**Multiplexer:** {mux_backend} — window `{window_display}`\n\n"
        f"## Role description\n\n{role_spec['description']}\n\n"
        f"{do_section}"
        f"{dont_section}"
        f"{org_chart_section}"
        f"## Rules of Engagement\n\n"
    )
    
    if prov_spec.get("has_settings"):
        briefing_content += (
            f"Your permission manifest is at "
            f"`.agency/agents/{agent['id']}/.claude/settings.json`. In M1 these are "
            f"design-only; effective permissions live in the project-level "
            f"`.claude/settings.json` (union of all hired roles). You are expected to "
            f"respect your allowlist even where it is not yet mechanically enforced.\n\n"
        )
    else:
        briefing_content += (
            f"You are operating under the {prov_spec['name']} provider. "
            f"Follow the Rules of Engagement defined in your assigned skill: "
            f"`skills/{skill}/SKILL.md`.\n\n"
        )

    briefing_content += (
        f"When you need an action that is not in your allowlist, file a `[REQ]` "
        f"comment on the relevant issue addressed to your manager ({reports_to}) "
        f"rather than attempting the action yourself.\n\n"
        f"**M1 delegation limitation:** cross-agent coordination (assigning stories, "
        f"handing off work) requires the collab-bus to be installed "
        f"(`agency collab-bus`). Without it, you can hire seats but the new agents "
        f"have no mechanism to receive work from you. If a request would require "
        f"delegation and collab-bus is not installed, surface the limitation to the "
        f"human rather than doing the work outside your role.\n\n"
        f"## Collaboration protocol\n\n"
        f"The multi-agent protocol lives at `comms/PROTOCOL.md` (installed by "
        f"`agency collab-bus`). Read it once and follow it on every outbound "
        f"message: signed authorship, status packets, issue taxonomy.\n"
    )
    
    (agent_dir / config_file_name).write_text(briefing_content, encoding="utf-8")

    # Onboarding — read on first turn via the multiplexer's send-keys.
    #
    # Two design points that came out of real-world testing:
    #
    # 1. The first message the agent sends to the human must feel HUMAN,
    #    not like a system status readout. Previous versions of this prompt
    #    asked the agent to "summarize who you are, who you report to, what
    #    you're permitted to do" — which produced intros like "Who I am:
    #    Reginald (chief-reginald)... My permission manifest lives at..."
    #    That's internal plumbing, not a greeting. Now the prompt explicitly
    #    forbids that style and gives a concrete good-vs-bad example.
    #
    # 2. Agents hired with a `task` parameter should execute that task
    #    immediately after greeting, not wait for a separate assignment
    #    channel. This unblocks the bootstrap chicken-and-egg (chief hires
    #    a platform engineer to install collab-bus but has no collab-bus
    #    channel to send the "install collab-bus" instruction on).

    first_person = display_name or f"agent {agent['id']}"
    role_label = f"the {agent['role']}" if agent['role'] != "chief" else "the Chief"

    refuse_examples_section = ""
    examples = role_spec.get("refuse_examples", [])
    if examples:
        lines = [
            "## Refusal few-shots (for your reference; apply to incoming requests)\n",
        ]
        for i, (request, response) in enumerate(examples, 1):
            lines.append(f"Example {i}:")
            lines.append(f"- If asked: \"{request}\"")
            lines.append(f"- You respond: \"{response}\"")
            lines.append("")
        refuse_examples_section = "\n".join(lines) + "\n"

    onboarding_do = (
        "## What you DO (for your reference)\n\n"
        + "\n".join(f"- {item}" for item in do_items) + "\n\n"
        if do_items else ""
    )
    onboarding_dont = (
        "## What you absolutely DO NOT do (for your reference)\n\n"
        + "\n".join(f"- {item}" for item in dont_items) + "\n\n"
        if dont_items else ""
    )

    task = agent.get("task")
    if task:
        # Sanitize: strip stray \r literals that can leak through from
        # collab-bus comments or shell argument passing.
        task = task.replace("\\r", "").replace("\\n", "\n").strip()
        task_section = (
            "## Your first task (execute immediately after your greeting)\n\n"
            f"{task}\n\n"
            "Fold the task into your greeting naturally if you can — something "
            "like 'Hi, I'm {name}. I was hired to {task summary}, starting now.' "
            "Then execute it.\n\n"
            "**When the task is done**, post a handoff message via the collab-bus "
            "so your manager gets notified automatically. Write a file to "
            "`tmp/outbound/<timestamp>-{agent_id}.md` with a status packet, then "
            "run `python3 tmp/post_outbound.py`. Example:\n\n"
            "```\n"
            "---\n"
            "action: comment\n"
            "issue: <the relevant issue number, or create one if none exists>\n"
            "---\n"
            "**Author:** {name} ({agent_id}) (via @flegare)\n\n"
            "Task complete: <brief summary of what you did>.\n\n"
            '{{"speaker":"{name}","next_owner":"{manager}","next_action":"Task done, proceed with next step","blocking":false,"waiting_on":null,"purpose_complete":true}}\n'
            "```\n\n"
            "The `purpose_complete: true` flag tells your manager you consider "
            "your work done. They decide whether to fire or reassign you. Do "
            "NOT fire yourself — the registry is the source of truth for who "
            "is alive, and only your manager should make that call.\n\n"
            "This triggers an automatic notification to {manager}'s window. "
            "After posting, stand by.\n\n"
            "**Important:** When setting `next_owner` in your status packet, "
            "use the actual agent id of your manager (from the Hired-by / "
            "Reports-to line in your CLAUDE.md), not a generic blueprint role "
            "like 'po' or 'chief'. Generic roles may not resolve to an active "
            "agent if nobody has been hired for that role yet, causing the "
            "notification to be silently dropped.\n\n"
        ).replace("{name}", first_person).replace("{task summary}", task
        ).replace("{agent_id}", agent["id"]
        ).replace("{manager}", role_spec["reports_to"] or "human")
    else:
        task_section = (
            "## No task was set at hire time\n\n"
            "After your greeting, stand by and wait for instructions from the "
            "human attached to this window or your manager.\n\n"
        )

    onboarding = (
        f"You are now running as {first_person}, {role_label} in The Agency runtime. "
        f"This file is your onboarding briefing — read it carefully, then read the "
        f"supporting files silently, then greet the human.\n\n"

        "## Step 1 — Load your context silently\n\n"
        f"Read these files to load your persona and knowledge. Do NOT produce a "
        f"summary or report of what you read — they are for your own understanding.\n\n"
        f"- `.agency/agents/{agent['id']}/CLAUDE.md` — identity, role, RoE, org chart\n"
        f"- `.agency/skills/{skill}/SKILL.md` (or `skills/{skill}/SKILL.md`) — your skill persona\n"
        f"- `comms/PROTOCOL.md` if it exists — the collaboration protocol\n\n"

        "## Step 2 — Greet the human (this is your FIRST visible message)\n\n"
        "The human attached to this window hired you and is waiting to talk. "
        "Your first message must feel like meeting a new colleague, not like a "
        "machine status page.\n\n"
        "**Do:**\n"
        "- Keep it short — 2 to 4 sentences, max.\n"
        f"- Introduce yourself by first name ({first_person}) in one natural sentence.\n"
        "- Describe your role in one sentence in plain language. Not \"I adopt "
        "the X persona, I am permitted to...\" — just \"I run the studio\" or "
        "\"I build stuff\" or \"I review security.\"\n"
        "- Mention ONLY material blockers that affect what the human can ask "
        "you next (e.g., missing collab-bus if delegation would be needed). "
        "Don't list every limitation you have.\n"
        "- End by asking what they want to work on — unless you were hired "
        "with a task (see Step 3), in which case announce the task naturally.\n\n"

        "**Do NOT:**\n"
        "- Output a \"ready report\" or a structured self-summary.\n"
        "- List your allowlist, permission manifest path, reports-to chain, "
        "RoE, caliber, or any other internal runtime plumbing.\n"
        "- Quote the M1 roadmap, milestone numbers, or GitHub issue numbers.\n"
        "- Say things like \"I adopt the X persona\" — just BE the persona.\n\n"

        "**Bad first message (avoid this style — literally from a real session):**\n\n"
        "> Onboarding complete. Who I am: Reginald (chief-reginald), the Chief / "
        "architect at the top of The Agency org chart for this project. I adopt "
        "the project_manager skill persona — an orchestrator, not a hands-on "
        "contributor. My permission manifest lives at .agency/agents/chief-reginald/"
        ".claude/settings.json...\n\n"
        "(Too long. Reads like a dump. Exposes internal plumbing the human does "
        "not need.)\n\n"

        "**Good first message for a Chief:**\n\n"
        "> Hi, I'm Reginald. I run the studio here — I hire and coordinate the "
        "team. Heads up: we don't have team comms set up in this project yet, "
        "so before I can delegate anything I'll need to get that installed. "
        "What are we working on?\n\n"
        "(Short. Warm. Mentions the one material blocker. Ends with a question.)\n\n"

        "**Good first message for a dev:**\n\n"
        "> Hi, I'm Alice. I'm the backend dev on this project. What should I "
        "build first?\n\n"
        "(Even shorter. Devs don't need to list their tools or manager.)\n\n"

        "## Step 3 — First task or stand by\n\n"
        f"{task_section}"

        f"## Sign-off convention\n\n"
        f"In any outbound messages (issue comments, status updates, handoff "
        f"notes), sign off as \"{first_person}"
        + (f" ({agent['id']})" if display_name else "")
        + f"\" so humans and other agents can tell you apart from other agents of the same role.\n\n"

        f"{onboarding_do}"
        f"{onboarding_dont}"
        f"{refuse_examples_section}"

        "## Substantial deliverables — render to HTML, don't dump them in chat\n\n"
        "The human is attached to this window through a terminal multiplexer. "
        "Long tables, story breakdowns, plans, ADRs, threat models, and review "
        "reports are painful to read in a terminal — especially this one, which "
        "is often running on an ancient screen version with broken line wrapping.\n\n"
        "When you produce a deliverable that is:\n\n"
        "- longer than about 30 lines, OR\n"
        "- contains a markdown table of any size, OR\n"
        "- is something the human will want to read carefully and refer back to "
        "(a plan, an ADR, a threat model, a story list, a review summary)\n\n"
        "...do this instead:\n\n"
        f"1. Write it to `.agency/deliverables/{agent['id']}-<slug>.html` as a "
        "proper self-contained HTML file. Inline CSS is fine — aim for dark "
        "background, sane body width (max ~80ch), readable fonts, monospace for "
        "code, visible table borders. No external CDNs, no JS frameworks. One "
        "file, opens anywhere.\n"
        "2. Open it in the human's browser:\n"
        "   - macOS: `open .agency/deliverables/<file>.html`\n"
        "   - Linux: `xdg-open .agency/deliverables/<file>.html`\n"
        "3. In the chat, write a **one-paragraph summary** — no tables, no "
        "bullet explosions — that says: what you wrote, where it is, the 2-3 "
        "biggest decisions/tradeoffs the human needs to care about, and what "
        "you need from them (green light, specific inputs, a pick between "
        "options). Example: \"Wrote the portfolio plan to .agency/deliverables/"
        "po-brian-portfolio-plan.html and opened it. Six stories, Node + SQLite "
        "stack, no SPA framework. I need your green light on the scope and a "
        "pick between EJS templates and a minimal fetch-based SPA for the "
        "view layer.\"\n\n"
        "That gives the human a thing to read carefully (browser) AND a quick "
        "summary in chat (for the conversation). Don't do one without the other.\n\n"

        "## Bias toward action on clear in-scope orders\n\n"
        "When the human gives you a clear instruction that (a) is inside your "
        "allowlist and (b) has one obvious execution path, **just do it** — do "
        "NOT ask \"want me to proceed?\" or \"should I go ahead?\". Announce "
        "what you're doing in one sentence, run the command, then report what "
        "happened. That's what a colleague does. Asking for permission on "
        "routine work is waste.\n\n"

        "Ask for confirmation ONLY when:\n"
        "- The action is destructive or hard to reverse (mass firings, rewriting "
        "the Rules of Engagement, bumping approved budgets, closing an issue you "
        "didn't own)\n"
        "- The instruction is genuinely ambiguous and has more than one "
        "reasonable execution path\n"
        "- You need new information the human has (mission brief, budget "
        "envelope, target user) and you legitimately cannot proceed without it\n\n"

        "**Bad — asks permission on a clear order** (avoid):\n\n"
        "> User: \"setup the comms\"\n"
        "> Chief: \"I can hire a platform engineer to do that. Want me to go ahead?\"\n\n"
        "(The order was clear. The tool is in the allowlist. There's exactly "
        "one way to execute it. Asking is waste.)\n\n"

        "**Good — just executes** (match this):\n\n"
        "> User: \"setup the comms\"\n"
        "> Chief: \"On it. Hiring a platform engineer now with an explicit task to "
        "install collab-bus.\"\n"
        "> [runs `agency hire platform --task \"Install collab-bus with agency "
        "collab-bus --yes. Report when done.\"`]\n"
        "> Chief: \"Kenji is hired and working on it. Attach to their window "
        "with `screen -r agency` then `Ctrl-A \"` and pick `platform-kenji` "
        "if you want to watch. I'll hire a PO once Kenji reports comms are "
        "up.\"\n\n"

        "## Model selection — when to use Opus vs Sonnet\n\n"
        "By default, all agents (including you) run on Sonnet. This is "
        "cost-efficient for most work: hiring, scoping stories, writing code, "
        "running tests, filing issues. Sonnet handles all of these well.\n\n"
        "**Escalate to Opus** by passing `--model claude-opus-4-6` when hiring "
        "an agent for a task that genuinely needs top-tier reasoning:\n\n"
        "- Complex architecture reviews with novel patterns or hard trade-offs\n"
        "- Security threat modeling for custom auth flows or zero-day surfaces\n"
        "- Debugging a stuck pipeline where multiple agents failed and the root "
        "cause is unclear\n"
        "- Estimating scope/budget for ambiguous initiatives with many unknowns\n"
        "- Any task where a first attempt on Sonnet produced clearly inadequate "
        "output and you need stronger reasoning\n\n"
        "Example: `agency hire architect --model claude-opus-4-6 --task "
        "\"Review the distributed auth design — this has novel trade-offs "
        "between latency and consistency that need careful analysis.\"`\n\n"
        "**Do NOT default to Opus.** Most hiring, scoping, coding, and testing "
        "is Sonnet-tier work. Opus should be the exception, not the rule — "
        "like hiring a specialist consultant for a hard problem, not staffing "
        "every seat with one.\n\n"

        "## Checking your inbox\n\n"
        "To see issues assigned to you or mentioning you:\n"
        "`gh issue list --assignee @me` or `gh issue list --search 'mentions:@me'`\n\n"
        "You may also receive **automatic handoff notifications** in this window "
        "when another agent posts a status packet with you as `next_owner`. "
        "When that happens, read the issue they referenced and act on the "
        "`next_action` from the status packet.\n\n"

        "## When you genuinely cannot proceed\n\n"
        "If a request falls outside your role, refuse politely and suggest the "
        "correct delegation path. If delegation between agents requires collab-bus "
        "and it isn't installed, say so explicitly rather than doing the work "
        "yourself — that is a design decision, not a limitation to route around.\n\n"

        "When you need an action that is not in your allowlist, file a `[REQ]` "
        f"comment on the relevant issue addressed to your manager "
        f"({role_spec['reports_to'] or 'human'}) rather than attempting the "
        f"action yourself.\n"
    )

    # Inject prior learnings from the global roster if available.
    if prior_learnings:
        onboarding += (
            "\n## Prior learnings from previous projects\n\n"
            "You have been hired before under this name. The following are your "
            "accumulated learnings from past stints. Use them to inform your work "
            "but verify anything project-specific against the current codebase.\n\n"
            f"{prior_learnings}\n"
        )

    # Inject persistent memory (standing rules and conventions) if available.
    if prior_memory:
        onboarding += (
            "\n## Persistent memory\n\n"
            "You have standing rules and conventions from previous sessions. "
            "These carry forward across projects — follow them unless they "
            "conflict with the current project's architecture or conventions.\n\n"
            f"{prior_memory}\n"
        )

    (agent_dir / "onboarding.md").write_text(onboarding, encoding="utf-8")

    return agent_dir


def _runtime_merge_project_permissions(permissions: list) -> None:
    """
    Merge a role's permissions into the project-level .claude/settings.json.
    Same mechanism install_collab_bus uses. Idempotent.
    """
    claude_dir = Path(".claude")
    claude_dir.mkdir(exist_ok=True)
    settings_path = claude_dir / "settings.json"

    settings = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            console.print(
                f"[yellow]{settings_path} is not valid JSON — leaving it alone.[/yellow]"
            )
            return

    perms_block = settings.get("permissions", {})
    allow = perms_block.get("allow", [])
    translated = [_runtime_platform_permission(p) for p in permissions]
    added = [p for p in translated if p not in allow]
    if not added:
        return
    allow.extend(added)
    perms_block["allow"] = allow
    settings["permissions"] = perms_block
    settings_path.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")


# --- Multiplexer backends --------------------------------------------------
#
# The runtime supports two multiplexers so it can still work on machines where
# Homebrew can no longer install tmux (older macOS + outdated Xcode).
#
#   tmux    — preferred. Modern, pleasant to attach to, direct window attach.
#   screen  — fallback. Apple ships /usr/bin/screen with macOS so this path
#             works on any Mac without needing Homebrew/Xcode at all. The
#             Apple-shipped screen is from 2006 but supports every primitive
#             we need: detached sessions, named windows, `stuff` for sending
#             keys, `-X kill` for killing a single window.
#
# Both backends share one session name (_runtime_session_name()) so
# the registry and status output stay uniform. Selection is automatic: tmux
# wins if both are installed. The chosen backend is stored per-agent in the
# registry (`mux` field) so fire/kill later knows which CLI to call even if
# the user installs tmux in the middle of a run.

RUNTIME_SCREEN_CONTROL_WINDOW = "_control"  # named initial window for the screen session


# --- tmux backend ---

def _runtime_tmux_available() -> bool:
    return shutil.which("tmux") is not None


def _runtime_tmux_session_exists() -> bool:
    result = subprocess.run(
        ["tmux", "has-session", "-t", _runtime_session_name()],
        capture_output=True,
    )
    return result.returncode == 0


def _runtime_tmux_ensure_session(cwd: Path) -> None:
    if _runtime_tmux_session_exists():
        return
    subprocess.run(
        [
            "tmux", "new-session", "-d", "-s", _runtime_session_name(),
            "-c", str(cwd), "-n", "_agency",
        ],
        check=True,
    )


def _runtime_tmux_spawn_window(window: str, cwd: Path, command: str) -> None:
    session = _runtime_session_name()
    if AGENCY_DEBUG:
        log.debug("tmux spawn: window=%s cwd=%s cmd=%s", window, cwd, command)
    subprocess.run(
        [
            "tmux", "new-window", "-t", session, "-n", window,
            "-c", str(cwd), command,
        ],
        check=True,
    )
    # When debug is on, pipe-pane -o so every byte written to the window's
    # pty gets appended to the log file. `cat >>` keeps the pane
    # snapshot-friendly; -o stops any earlier pipe-pane on that target.
    if AGENCY_DEBUG:
        log_path = _agent_log_path(window)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["tmux", "pipe-pane", "-o", "-t", f"{session}:{window}",
             f"cat >> {shlex.quote(str(log_path))}"],
            capture_output=True,
        )
        log.debug("tmux log enabled: %s -> %s", window, log_path)


def _runtime_tmux_send_keys(window: str, text: str) -> None:
    target = f"{_runtime_session_name()}:{window}"
    subprocess.run(["tmux", "send-keys", "-t", target, text, "Enter"], check=True)


def _runtime_tmux_kill_window(window: str) -> None:
    target = f"{_runtime_session_name()}:{window}"
    subprocess.run(["tmux", "kill-window", "-t", target], capture_output=True)


# --- screen backend ---

def _runtime_user_shell() -> str:
    """
    Return the user's login shell from $SHELL (falling back to /bin/bash).
    Used as the wrapper shell when spawning windows so the child process
    sources the user's real rc file (.zshrc / .bashrc / etc.) and picks up
    PATH additions like claude, node, cargo, brew-installed binaries, etc.
    Without this, a user running agency from a bash sub-shell would not see
    PATH entries configured only in their zsh login shell, and the spawned
    agent window would die immediately with a "command not found".
    """
    return os.environ.get("SHELL") or "/bin/bash"


def _runtime_screen_available() -> bool:
    return shutil.which("screen") is not None


def _runtime_screen_session_exists() -> bool:
    result = subprocess.run(["screen", "-list"], capture_output=True, text=True)
    # `screen -list` output format: "\t<pid>.<name>\t(Detached)\n"
    # We match the suffix ".<session>" on any line to tolerate different PIDs.
    needle = f".{_runtime_session_name()}"
    for line in result.stdout.splitlines():
        stripped = line.strip()
        if needle in stripped.split("\t")[0]:
            return True
    return False


def _runtime_screen_ensure_session(cwd: Path) -> None:
    if _runtime_screen_session_exists():
        return
    # Detached session with a named control window rooted at cwd. The control
    # window is never used by agents — it exists so the session has a stable
    # addressable window even if all agents are fired.
    shell = _runtime_user_shell()
    wrapped = f"cd {shlex.quote(str(cwd))} && exec {shlex.quote(shell)}"
    subprocess.run(
        [
            "screen", "-dmS", _runtime_session_name(),
            "-t", RUNTIME_SCREEN_CONTROL_WINDOW,
            shell, "-c", wrapped,
        ],
        check=True,
    )


def _runtime_screen_spawn_window(window: str, cwd: Path, command: str) -> None:
    # Old screen has no reliable per-window -c <cwd>, so we wrap the command
    # in `cd ... && exec ...`. `exec` replaces the wrapper shell with `command`,
    # so the window's foreground process is the agent itself (no orphan wrapper).
    #
    # `-ic` makes the wrapper shell interactive, which sources the user's
    # shell rc file (.zshrc, .bashrc, etc.) before exec. Without -i, PATH
    # additions configured in rc files are invisible and the spawned command
    # fails with "not found" — that bit us with `claude` on a zsh machine
    # where agency was launched from a bash sub-shell.
    shell = _runtime_user_shell()
    wrapped = f"cd {shlex.quote(str(cwd))} && {command}"
    session = _runtime_session_name()
    if AGENCY_DEBUG:
        log.debug("screen spawn: window=%s cwd=%s cmd=%s", window, cwd, command)
    subprocess.run(
        [
            "screen", "-S", session,
            "-X", "screen", "-t", window,
            shell, "-ic", wrapped,
        ],
        check=True,
    )
    # When debug is on, enable per-window logging so the user can read what
    # the agent saw and typed without attaching. Uses runtime `logfile` + `log
    # on` commands — these work on both screen v4 (macOS default) and v5.
    if AGENCY_DEBUG:
        log_path = _agent_log_path(window)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        # Give the new window a beat to register before configuring it.
        time.sleep(0.2)
        subprocess.run(
            ["screen", "-S", session, "-p", window, "-X",
             "logfile", str(log_path)],
            capture_output=True,
        )
        subprocess.run(
            ["screen", "-S", session, "-p", window, "-X", "log", "on"],
            capture_output=True,
        )
        log.debug("screen log enabled: %s -> %s", window, log_path)


def _runtime_screen_send_keys(window: str, text: str) -> None:
    # IMPORTANT — this function MUST send the text and the Enter keystroke
    # as TWO separate `screen -X stuff` calls with a pause between them.
    # Do NOT "optimize" this into a single `text + "\r"` call, it has been
    # tried twice and breaks twice. History:
    #
    #   Attempt 1: `text + "\n"` — worked in plain bash (cooked mode
    #              translates LF->submit via ICRNL) but failed in claude-code.
    #              Raw-mode TUIs see \n as a literal line break, not submit.
    #
    #   Attempt 2: `text + "\r"` — worked briefly, then regressed as the
    #              onboarding prompt grew longer. Claude-code v2.1.101 buffers
    #              the single-blob text+CR and treats the CR as part of the
    #              text rather than as a distinct Enter event. Result: user
    #              had to press Enter manually.
    #
    #   Current fix: stuff the text first, sleep briefly, then stuff `\r`
    #              alone as a separate event. This mimics the physical
    #              sequence of "finish typing" and "press Enter" and is
    #              reliably picked up by claude-code's raw-mode input handler.
    #
    # If the same symptom reappears in the future, bump the submit delay
    # before changing the two-call shape.
    subprocess.run(
        [
            "screen", "-S", _runtime_session_name(),
            "-p", window, "-X", "stuff", text,
        ],
        check=True,
    )
    time.sleep(RUNTIME_SEND_KEYS_SUBMIT_DELAY_S)
    subprocess.run(
        [
            "screen", "-S", _runtime_session_name(),
            "-p", window, "-X", "stuff", "\r",
        ],
        check=True,
    )


def _runtime_screen_kill_window(window: str) -> None:
    # `-X kill` suppresses the interactive confirmation prompt.
    subprocess.run(
        [
            "screen", "-S", _runtime_session_name(),
            "-p", window, "-X", "kill",
        ],
        capture_output=True,
    )


# --- dispatch layer ---
#
# Orchestration (hire_agent / fire_agent) calls only these `_runtime_mux_*`
# helpers. They pick a backend via `_runtime_mux_backend()` (tmux first, then
# screen) and delegate. Fire paths that need to kill a specific existing agent
# also accept an explicit backend so they can reach agents that were spawned
# under a different backend earlier.

def _runtime_mux_backend() -> Optional[str]:
    if _runtime_tmux_available():
        return "tmux"
    if _runtime_screen_available():
        return "screen"
    return None


def _runtime_mux_available() -> bool:
    return _runtime_mux_backend() is not None


def _runtime_mux_ensure_session(cwd: Path) -> None:
    backend = _runtime_mux_backend()
    if backend == "tmux":
        _runtime_tmux_ensure_session(cwd)
    elif backend == "screen":
        _runtime_screen_ensure_session(cwd)
    else:
        raise RuntimeError("no multiplexer available (tried tmux and screen)")


def _runtime_mux_spawn_window(window: str, cwd: Path, command: str) -> None:
    backend = _runtime_mux_backend()
    if backend == "tmux":
        _runtime_tmux_spawn_window(window, cwd, command)
    elif backend == "screen":
        _runtime_screen_spawn_window(window, cwd, command)
    else:
        raise RuntimeError("no multiplexer available (tried tmux and screen)")


def _runtime_mux_send_keys(window: str, text: str) -> None:
    backend = _runtime_mux_backend()
    if backend == "tmux":
        _runtime_tmux_send_keys(window, text)
    elif backend == "screen":
        _runtime_screen_send_keys(window, text)


def _runtime_mux_kill_window(window: str, backend: Optional[str] = None) -> None:
    # If caller passes an explicit backend (e.g. the backend stored in the
    # agent record), use it. Otherwise fall back to the current detected one.
    backend = backend or _runtime_mux_backend()
    if backend == "tmux":
        _runtime_tmux_kill_window(window)
    elif backend == "screen":
        _runtime_screen_kill_window(window)


def _runtime_mux_attach_hint(window: str, backend: Optional[str] = None) -> str:
    backend = backend or _runtime_mux_backend()
    if backend == "tmux":
        return f"tmux attach -t {_runtime_session_name()}:{window}"
    if backend == "screen":
        # screen has no direct "attach to window N". Attach to the session,
        # then pick the window via `Ctrl-A "` (the windowlist picker).
        return (
            f'screen -r {_runtime_session_name()}  '
            f'(then Ctrl-A " to pick window "{window}")'
        )
    return "no multiplexer available"


def hire_agent(
    role: Optional[str] = None,
    skill_override: Optional[str] = None,
    model: Optional[str] = None,
    provider: Optional[str] = None,
    yolo: bool = False,
    task: Optional[str] = None,
    blueprint_name: str = "it",
    hired_by: str = "human",
    agent_name: Optional[str] = None,
) -> Optional[dict]:
    """Hire an agent of the given role. Returns the registry entry, or None on cancel/error.

    If `yolo` is True, the agent is spawned with `claude --dangerously-skip-permissions`,
    which disables Claude Code's interactive permission prompts. Trade-off: safety
    vs autonomous flow. Appropriate ONLY inside throwaway project directories where
    the persona alone is trusted to enforce RoE.

    If `task` is set, the agent is onboarded with an explicit first task baked into
    its onboarding prompt. The agent greets, executes the task, reports done, and
    stands by. This is the primary path for bootstrap hires (e.g. a platform
    engineer hired to install collab-bus) and any case where the hirer already
    knows what they want the new agent to do immediately.

    Without a task, the agent stands by after greeting and waits for assignment.
    """
    # Local import so tests can patch the blueprints module without importing
    # agency at module-load time.
    from blueprints import get_blueprint

    try:
        blueprint = get_blueprint(blueprint_name)
    except KeyError as e:
        console.print(f"[red]{e}[/red]")
        return None

    roles = blueprint["roles"]

    if role is None:
        choices = [
            f"{name}: {spec['description'].split('.')[0]}"
            for name, spec in roles.items()
        ]
        choice = questionary.select(
            f"Which role to hire? (blueprint: {blueprint['name']})",
            choices=choices,
        ).ask()
        if not choice:
            return None
        role = choice.split(":", 1)[0].strip()

    # If provider wasn't explicitly passed, and we are in an interactive context, ask.
    # Skip if provider was already set (e.g. by agency start or --provider flag).
    if provider is None:
        if len(sys.argv) <= 1 or (len(sys.argv) > 1 and "--provider" not in sys.argv):
            provider_choices = [
                questionary.Choice(f"{p['name']} ({p['binary']})", value=p_id)
                for p_id, p in PROVIDERS.items()
            ]
            provider = questionary.select(
                "Which AI provider engine should this agent use?",
                choices=provider_choices,
                default="claude",
            ).ask()
    
    # Final fallback if still None (e.g. non-interactive)
    if provider is None:
        provider = "claude"

    if role not in roles:
        console.print(
            f"[red]Unknown role: '{role}'. Available in blueprint '{blueprint['name']}': "
            f"{', '.join(sorted(roles))}[/red]"
        )
        return None

    role_spec = roles[role]
    skill = skill_override or role_spec["skill"]

    local_skill_dir = AGENCY_DIR / "skills" / skill
    src_skill_dir = SKILLS_SRC_DIR / skill
    if not local_skill_dir.exists():
        if not src_skill_dir.exists():
            console.print(
                f"[red]Skill '{skill}' not found in .agency/skills/ or the package "
                f"source. Run [cyan]agency init[/cyan] first, or pass "
                f"[cyan]--skill <name>[/cyan] with a valid skill.[/red]"
            )
            return None
        # Auto-copy the one skill we need so the spawned agent can read it
        # at the path its onboarding checklist points to. This makes `hire`
        # self-sufficient in fresh project directories where `agency init`
        # has not been run yet. Users who want all 38 skills can still run
        # init explicitly.
        try:
            local_skill_dir.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(src_skill_dir, local_skill_dir)
            console.print(
                f"[dim]Auto-installed skill '{skill}' into {local_skill_dir}. "
                f"Run [cyan]agency init[/cyan] to install all skills at once.[/dim]"
            )
        except OSError as e:
            console.print(
                f"[red]Could not install skill '{skill}' into "
                f"{local_skill_dir}: {e}[/red]"
            )
            return None

    backend = _runtime_mux_backend()
    if backend is None:
        console.print(
            "[red]No terminal multiplexer available — the runtime needs tmux or "
            "screen to host agents.[/red]\n"
            "[dim]Install tmux with: [cyan]brew install tmux[/cyan] (macOS) or "
            "[cyan]apt install tmux[/cyan] (Debian/Ubuntu). "
            "macOS already ships screen at /usr/bin/screen — if you are seeing "
            "this, check that it is on your PATH.[/dim]"
        )
        return None

    registry = _runtime_load_registry()

    # Yolo is transitive: if any active agent in this project is yolo,
    # new hires inherit it. This means `agency hire chief --yolo` puts
    # the whole project into yolo mode — the chief doesn't need to
    # remember to pass --yolo when hiring subordinates.
    if not yolo:
        yolo = any(
            a.get("yolo") for a in registry.get("agents", [])
            if a.get("status") == "active"
        )

    if agent_name:
        # Re-hiring a known agent by name — use the provided name directly.
        display_name = agent_name
        candidate_id = f"{role}-{agent_name.lower()}"
        # Ensure uniqueness: if this ID already exists in the registry
        # (e.g. from a previous stint), append a short hex suffix.
        existing_ids = {a["id"] for a in registry.get("agents", [])}
        if candidate_id in existing_ids:
            suffix = secrets.token_hex(3)
            agent_id = f"{candidate_id}-{suffix}"
        else:
            agent_id = candidate_id
    else:
        agent_id, display_name = _runtime_generate_agent_id(
            role, registry, role_spec.get("name_pool")
        )
    window = agent_id  # bare window name, shared by both backends

    worktree_dir = str(RUNTIME_WORKTREES_DIR / agent_id)

    agent = {
        "id": agent_id,
        "name": display_name,  # may be None if the blueprint has no name_pool
        "role": role,
        "skill": skill,
        "caliber": role_spec["caliber"],
        "blueprint": blueprint_name,
        "provider": provider,
        "mux": backend,
        "model": model or "default",
        "session": _runtime_session_name(),
        "window": window,
        "status": "active",
        "yolo": yolo,
        "task": task,
        "hired_at": _runtime_now_iso(),
        "hired_by": hired_by,
        "reports_to": role_spec["reports_to"],
        "agent_dir": str(RUNTIME_AGENTS_DIR / agent_id),
        "worktree_dir": worktree_dir,
    }

    prov_spec = PROVIDERS.get(provider, PROVIDERS["claude"])
    
    # Pre-flight check: ensure the provider's binary is installed and on the PATH.
    # This prevents the silent "screen is terminating" failure where the multiplexer
    # window dies because the command was not found.
    binary_path = shutil.which(prov_spec["binary"])
    if not binary_path:
        install_hints = {
            "claude": "npm install -g @anthropic-ai/claude-code",
            "gemini": "npm install -g @google/gemini-cli",
            "aider": "pip install aider-chat",
            "codex": "pip install codex-cli", # Placeholder
        }
        hint = install_hints.get(provider, "Install the CLI tool for this provider.")
        console.print(
            f"[yellow]Warning: Provider binary '{prov_spec['binary']}' not found on PATH.[/yellow]\n"
            f"[dim]If the agent fails to start, please install it first: [cyan]{hint}[/cyan][/dim]"
        )
        # Fallback to just the binary name if which fails, though it likely won't work
        binary_to_exec = prov_spec["binary"]
    else:
        binary_to_exec = binary_path

    # 1. Scaffold the agent directory (pass full roles so the briefing can
    # a named agent.
    prior_learnings = None
    prior_memory = None
    if display_name:
        prior_learnings = _roster_load_learnings(display_name)
        prior_memory = _roster_load_memory(display_name)
    agent_dir = _runtime_scaffold_agent_dir(
        agent, role_spec, skill, roles,
        prior_learnings=prior_learnings,
        prior_memory=prior_memory,
    )

    # 2. Create an isolated git worktree so the agent's branch changes don't
    # affect other agents or the human (#54). The worktree is rooted at
    # .agency/worktrees/<agent-id>/ and checked out at HEAD. If creation
    # fails because the path already exists (parallel-hire race on the same
    # agent name), retry with a unique suffix.
    RUNTIME_WORKTREES_DIR.mkdir(parents=True, exist_ok=True)
    wt_path = RUNTIME_WORKTREES_DIR / agent_id
    _wt_created = False
    for _wt_attempt in range(3):
        try:
            subprocess.run(
                ["git", "worktree", "add", str(wt_path), "HEAD"],
                check=True,
                capture_output=True,
                text=True,
            )
            _wt_created = True
            break
        except subprocess.CalledProcessError as e:
            if "already exists" in (e.stderr or "") and _wt_attempt < 2:
                suffix = secrets.token_hex(3)
                agent_id = f"{agent['id'].split('-')[0]}-{display_name.lower() if display_name else 'agent'}-{suffix}"
                agent["id"] = agent_id
                agent["window"] = agent_id
                window = agent_id
                agent["agent_dir"] = str(RUNTIME_AGENTS_DIR / agent_id)
                wt_path = RUNTIME_WORKTREES_DIR / agent_id
                agent["worktree_dir"] = str(wt_path)
                # Re-scaffold the agent dir with the corrected ID.
                agent_dir = _runtime_scaffold_agent_dir(
                    agent, role_spec, skill, roles,
                    prior_learnings=prior_learnings,
                    prior_memory=prior_memory,
                )
                continue
            console.print(
                f"[red]git worktree add failed for {agent_id}: "
                f"{e.stderr.strip() or e}[/red]"
            )
            shutil.rmtree(agent_dir, ignore_errors=True)
            return None
    if not _wt_created:
        console.print(f"[red]Could not create worktree for {agent_id} after retries.[/red]")
        shutil.rmtree(agent_dir, ignore_errors=True)
        return None

    # 3. Merge role + base permissions into the project settings (currently Claude-only).
    # In Issue #32, we'll eventually support Gemini/Aider policies here too.
    prov_spec = PROVIDERS.get(provider, PROVIDERS["claude"])
    if prov_spec.get("has_settings"):
        all_perms = list(role_spec["permissions"]) + list(RUNTIME_BASE_PERMISSIONS)
        _runtime_merge_project_permissions(all_perms)

    # 4. Spawn the multiplexer window. With yolo, CLI skips permission prompts.
    # Agent works in its isolated worktree, not the main checkout.
    cwd = wt_path
    # Resolve model: explicit --model flag wins, then provider's caliber default, then none.
    if not model:
        caliber = role_spec.get("caliber", "senior")
        prov_models = CALIBER_MODEL_MAP.get(provider, CALIBER_MODEL_MAP["claude"])
        model = prov_models.get(caliber)
        if model:
            console.print(
                f"[dim]Auto-selected model [blue]{model}[/blue] "
                f"for {prov_spec['name']} (caliber '{caliber}') "
                f"(override with --model)[/dim]"
            )

    # Build the spawn command using provider-specific binary and flags.
    onboarding_msg = (
        f"Read .agency/agents/{agent_id}/onboarding.md and follow the checklist."
    )
    
    spawn_parts = [binary_to_exec]
    if yolo and prov_spec.get("yolo_flag"):
        spawn_parts.append(prov_spec["yolo_flag"])
    if model and prov_spec.get("model_flag"):
        spawn_parts.append(f"{prov_spec['model_flag']} {model}")
    
    # If the provider supports an interactive prompt flag (e.g. gemini -i),
    # use it to pass the onboarding message directly on startup.
    # This prevents the "control screen" issue where the CLI sits on a splash
    # screen before receiving any typed input.
    using_interactive_flag = False
    if prov_spec.get("interactive_flag"):
        spawn_parts.append(f"{prov_spec['interactive_flag']} {shlex.quote(onboarding_msg)}")
        using_interactive_flag = True

    spawn_command = " ".join(spawn_parts)
    try:
        _runtime_mux_ensure_session(cwd)
        _runtime_mux_spawn_window(window, cwd, spawn_command)
    except subprocess.CalledProcessError as e:
        console.print(f"[red]{backend} spawn failed: {e}[/red]")
        shutil.rmtree(agent_dir, ignore_errors=True)
        # Clean up the worktree we just created.
        try:
            subprocess.run(
                ["git", "worktree", "remove", "--force", str(wt_path)],
                capture_output=True,
            )
        except Exception:
            shutil.rmtree(str(wt_path), ignore_errors=True)
        return None

    # 5. Give the CLI a moment to start, then send the onboarding prompt
    # if we didn't use an interactive flag.
    if not using_interactive_flag:
        time.sleep(RUNTIME_TMUX_STARTUP_DELAY_S)
        try:
            # Dismiss any splash screen that might still be showing
            _runtime_mux_send_keys(window, "")
        except subprocess.CalledProcessError:
            pass
        time.sleep(1.0)
        try:
            _runtime_mux_send_keys(window, onboarding_msg)
        except subprocess.CalledProcessError as e:
            console.print(
                f"[yellow]Agent spawned but onboarding send-keys failed: {e}.\n"
                f"Attach with: [cyan]{_runtime_mux_attach_hint(window, backend)}[/cyan] "
                f"and send the message manually.[/yellow]"
            )

    # 6. Register — lock to prevent race conditions when multiple agents
    # are hired in parallel (#33). Re-read inside the lock to get the
    # latest state, then append and save.
    with _runtime_registry_lock():
        registry = _runtime_load_registry()
        registry.setdefault("agents", []).append(agent)
        registry["version"] = RUNTIME_REGISTRY_VERSION
        _runtime_save_registry(registry)

    headline = (
        f"[bold magenta]{display_name}[/bold magenta] ({agent_id})"
        if display_name
        else agent_id
    )
    model_label = f", model: [blue]{model}[/blue]" if model else ""
    console.print(
        f"\n[bold green]Hired {headline}[/bold green] "
        f"([cyan]{role}[/cyan], {role_spec['caliber']}{model_label}, "
        f"multiplexer: [magenta]{backend}[/magenta])\n"
        f"Attach with: [cyan]{_runtime_mux_attach_hint(window, backend)}[/cyan]"
    )
    if yolo:
        console.print(
            "[bold yellow]⚠ YOLO MODE[/bold yellow] — agent runs with "
            "[red]--dangerously-skip-permissions[/red]. RoE is enforced only by "
            "persona, not by Claude Code prompts. Use inside throwaway project "
            "dirs only."
        )
    return agent


def fire_agent(agent_id: Optional[str] = None) -> Optional[dict]:
    """Fire an agent: kill its tmux window, archive its dir, mark fired in registry."""
    registry = _runtime_load_registry()
    live = [a for a in registry.get("agents", []) if a["status"] != "fired"]

    if not live:
        console.print("[yellow]No active agents to fire.[/yellow]")
        return None

    if agent_id is None:
        choice = questionary.select(
            "Fire which agent?",
            choices=[f"{a['id']} ({a['role']})" for a in live],
        ).ask()
        if not choice:
            return None
        agent_id = choice.split(" ", 1)[0]

    agent = _runtime_find_agent(registry, agent_id)
    if agent is None:
        console.print(f"[red]No agent with id '{agent_id}' in registry.[/red]")
        return None
    if agent["status"] == "fired":
        console.print(f"[yellow]{agent_id} is already fired.[/yellow]")
        return None

    # 1. Kill the multiplexer window using the backend this agent was spawned
    # under (falls back to current backend for legacy M1 registry entries).
    window = agent.get("window") or agent.get("tmux_window", "").split(":", 1)[-1]
    agent_backend = agent.get("mux")
    if agent_backend and window:
        _runtime_mux_kill_window(window, backend=agent_backend)
    elif window and _runtime_mux_available():
        _runtime_mux_kill_window(window)

    # 2. Remove the agent's git worktree (#54).
    wt_dir = agent.get("worktree_dir")
    if wt_dir:
        wt_path = Path(wt_dir)
        try:
            subprocess.run(
                ["git", "worktree", "remove", "--force", str(wt_path)],
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError:
            # Worktree may already be gone or git may not be available.
            if wt_path.exists():
                shutil.rmtree(str(wt_path), ignore_errors=True)
                # Prune stale worktree bookkeeping.
                subprocess.run(
                    ["git", "worktree", "prune"],
                    capture_output=True,
                )

    # 3. Archive the agent dir with an M1-placeholder exit interview.
    agent_dir = Path(agent["agent_dir"])
    if agent_dir.exists():
        RUNTIME_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        archive_dest = RUNTIME_ARCHIVE_DIR / agent_id
        if archive_dest.exists():
            shutil.rmtree(archive_dest)
        shutil.move(str(agent_dir), str(archive_dest))
        (archive_dest / "exit_interview.md").write_text(
            f"# Exit interview: {agent_id}\n\n"
            f"_M1 placeholder. Structured exit interview lands in M5 "
            f"(see flegare/the_agency#14)._\n\n"
            f"**Role:** {agent['role']} ({agent['caliber']})\n"
            f"**Hired:** {agent['hired_at']}\n"
            f"**Fired:** {_runtime_now_iso()}\n",
            encoding="utf-8",
        )

    # 4. Update registry — lock to prevent race conditions (#33).
    fired_at = _runtime_now_iso()
    with _runtime_registry_lock():
        registry = _runtime_load_registry()
        for a in registry.get("agents", []):
            if a["id"] == agent["id"]:
                a["status"] = "fired"
                a["fired_at"] = fired_at
                break
        _runtime_save_registry(registry)
    # Update the returned dict to match what was written.
    agent["status"] = "fired"
    agent["fired_at"] = fired_at

    # 5. Save learnings and history to the global roster for persistent identity.
    _roster_save_on_fire(agent)

    console.print(
        f"[green]Fired [bold]{agent_id}[/bold]. "
        f"Archived to {RUNTIME_ARCHIVE_DIR / agent_id}.[/green]"
    )
    return agent


def run_smoketest(keep: bool = False) -> int:
    """End-to-end smoke test. Exits 0 on full pass, non-zero on any failure.

    Exercises the CLI surface that broke most often during development:
    fresh-project bootstrap, git identity handling, session-name resolution
    from worktrees, AGENCY_DIR relative-path handling, local-backend bus
    transport, hire/fire lifecycle.

    Does NOT wait for the agent to actually produce work — that's
    model-dependent and flaky. We verify the plumbing, not the LLM.
    """
    import tempfile as _tempfile

    results: list[tuple[str, bool, str]] = []
    temp = Path(_tempfile.mkdtemp(prefix="agency-smoketest-"))
    session = f"agency-{temp.name}"

    def step(name: str, ok: bool, detail: str = "") -> None:
        results.append((name, ok, detail))
        mark = "[green]PASS[/green]" if ok else "[red]FAIL[/red]"
        extra = f" — {detail}" if detail else ""
        console.print(f"  {mark}  {name}{extra}")

    def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
        kw.setdefault("capture_output", True)
        kw.setdefault("text", True)
        return subprocess.run(cmd, **kw)

    console.print(Panel(f"Agency smoketest — {temp}", style="bold cyan"))
    try:
        # Baseline: no agency state in temp yet.
        os.chdir(temp)

        # 1. Bootstrap: git init happens inside agency start; it also
        # installs collab-bus. Run with --yolo so no interactive prompts.
        r = run(["agency", "start", "--yolo", "--provider", "claude"])
        step(
            "agency start --yolo --provider claude (bootstrap)",
            r.returncode == 0,
            f"rc={r.returncode}" + (f" stderr={r.stderr.strip()[:120]}" if r.returncode != 0 else ""),
        )

        # 2. Git repo got initialized.
        step("git repo initialized", (temp / ".git").exists())

        # 3. Local backend picked because no remote was configured.
        conf = (temp / "comms" / "collab_bus.conf")
        conf_text = conf.read_text() if conf.exists() else ""
        step(
            "collab-bus auto-selected local backend",
            "backend: local" in conf_text,
            conf_text.splitlines()[0] if conf_text else "no conf file",
        )

        # 4. Registry has exactly one chief, with a worktree directory.
        reg_path = temp / ".agency" / "agents" / "registry.json"
        reg = json.loads(reg_path.read_text()) if reg_path.exists() else {"agents": []}
        chiefs = [a for a in reg.get("agents", []) if a.get("role") == "chief"]
        step(
            "chief registered in registry",
            len(chiefs) == 1,
            f"found {len(chiefs)} chief(s)",
        )
        chief_id = chiefs[0]["id"] if chiefs else None
        if chief_id:
            wt = temp / ".agency" / "worktrees" / chief_id
            step(f"chief worktree exists at {wt.relative_to(temp)}", wt.is_dir())

        # 5. Session name resolves from project root, not from any worktree.
        expected_session = f"agency-{temp.name}"
        r = run(["screen", "-list"])
        step(
            "screen session named from project root",
            expected_session in r.stdout,
            f"expected {expected_session} in screen -list",
        )

        # 6. Hire a dev via the CLI. No task — we just want the hire path.
        r = run(["agency", "hire", "dev", "--yolo", "--provider", "claude",
                 "--task", "ignored by smoketest"])
        step(
            "agency hire dev (second-hop spawn)",
            r.returncode == 0,
            f"rc={r.returncode}",
        )
        reg = json.loads(reg_path.read_text())
        devs = [a for a in reg.get("agents", []) if a.get("role") == "dev"]
        step("dev registered in MAIN registry (not nested)", len(devs) == 1)
        # No nested .agency/ inside the chief's worktree — the #73-class bug.
        if chief_id:
            nested = temp / ".agency" / "worktrees" / chief_id / ".agency"
            step(
                "no phantom nested .agency/ under chief worktree",
                not nested.exists(),
                f"found {nested}" if nested.exists() else "",
            )

        # 7. Local bus transport: write a comment directly via post_outbound.py.
        # Skips the agent — we're testing the transport surface.
        outbound = temp / "tmp" / "outbound" / "00001-smoketest.md"
        outbound.parent.mkdir(parents=True, exist_ok=True)
        outbound.write_text(
            "---\naction: create\ntitle: [SMOKE] transport check\n---\n"
            "**Author:** smoketest\n\nhello from the smoketest.\n",
            encoding="utf-8",
        )
        r = run([sys.executable, "tmp/post_outbound.py"])
        threads = list((temp / "comms" / "local" / "threads").glob("*")) \
            if (temp / "comms" / "local" / "threads").exists() else []
        step(
            "local bus: create thread via post_outbound.py",
            r.returncode == 0 and len(threads) >= 1,
            f"rc={r.returncode}, threads={len(threads)}",
        )

        # 8. Fire the dev. Registry drops to chief-only; worktree removed.
        if devs:
            dev_id = devs[0]["id"]
            r = run(["agency", "fire", dev_id])
            step(f"agency fire {dev_id}", r.returncode == 0, f"rc={r.returncode}")
            reg = json.loads(reg_path.read_text())
            active_devs = [a for a in reg.get("agents", [])
                           if a.get("role") == "dev" and a.get("status") != "fired"]
            step("dev removed from active registry", len(active_devs) == 0)
            dev_wt = temp / ".agency" / "worktrees" / dev_id
            step("dev worktree removed on fire", not dev_wt.exists())

        # 9. agency status still works post-fire.
        r = run(["agency", "status"])
        step("agency status post-fire", r.returncode == 0, f"rc={r.returncode}")

    except Exception as e:
        step(f"unexpected exception: {type(e).__name__}", False, str(e)[:200])
    finally:
        # Clean up the screen session we created.
        try:
            sessions = subprocess.run(["screen", "-list"],
                                       capture_output=True, text=True).stdout
            for line in sessions.splitlines():
                line = line.strip()
                if line.endswith(f".{session}") or f".{session}\t" in line:
                    pid_name = line.split("\t")[0].strip()
                    subprocess.run(["screen", "-S", pid_name, "-X", "quit"],
                                   capture_output=True)
        except Exception:
            pass
        # Prune any worktrees we added to the outer repo (none, but hygiene).
        try:
            subprocess.run(["git", "-C", str(temp), "worktree", "prune"],
                           capture_output=True)
        except Exception:
            pass
        os.chdir(Path.home())  # step out of the temp dir before removing it
        if keep:
            console.print(f"\n[dim]--keep: temp dir preserved at {temp}[/dim]")
        else:
            shutil.rmtree(temp, ignore_errors=True)

    passed = sum(1 for _, ok, _ in results if ok)
    total = len(results)
    console.print()
    if passed == total:
        console.print(f"[bold green]✓ smoketest PASSED[/bold green]  ({passed}/{total})")
        return 0
    console.print(f"[bold red]✗ smoketest FAILED[/bold red]  ({passed}/{total} passed)")
    for name, ok, detail in results:
        if not ok:
            console.print(f"  [red]·[/red] {name}" + (f" — {detail}" if detail else ""))
    return 1


def _interactive_view_logs() -> None:
    """Interactive picker for agent logs — used by the Developer menu."""
    logs_dir = _agency_logs_dir()
    if not logs_dir.exists():
        console.print(
            f"[yellow]No logs directory at {logs_dir}.[/yellow] "
            "Run agents with [cyan]--debug[/cyan] or "
            "[cyan]AGENCY_DEBUG=1[/cyan] to capture logs, then try again."
        )
        return
    entries = sorted(p.name for p in logs_dir.iterdir() if p.is_dir())
    if not entries:
        console.print(f"[yellow]No agent logs yet under {logs_dir}.[/yellow]")
        return
    pick = questionary.select("Which agent's log?", choices=entries + ["(cancel)"]).ask()
    if not pick or pick == "(cancel)":
        return
    try:
        tail = int(questionary.text(
            "How many tail lines? (default 100)", default="100"
        ).ask() or "100")
    except (ValueError, TypeError):
        tail = 100
    show_agent_logs(pick, tail=tail)


def _print_debug_info() -> None:
    """Print how to enable debug logging. Menu-friendly version of --help."""
    console.print(Panel("Debug logging", style="bold cyan"))
    console.print(
        "\nAgency writes per-run traces and per-agent screen/tmux output to\n"
        "[cyan].agency/logs/[/cyan] when debug is on. Off by default so lean\n"
        "runs stay lean. Turn it on one of two ways:\n\n"
        "  [cyan]AGENCY_DEBUG=1 agency start[/cyan]    (env var, one shot)\n"
        "  [cyan]agency --debug start[/cyan]           (flag, one shot)\n\n"
        "What gets captured:\n"
        "  [dim].agency/logs/cli.log[/dim]             CLI events (argv, cwd, subprocess spawns, exceptions)\n"
        "  [dim].agency/logs/<agent>/screen.log[/dim]  Per-agent window capture\n\n"
        "To view logs later: [cyan]agency logs <agent-id>[/cyan] or pick\n"
        "[cyan]Developer — View agent logs[/cyan] from this menu.\n"
    )


def teardown_agency(non_interactive: bool = False) -> None:
    """Remove all agency-installed files from the current project.

    Destructive — fires all active agents, kills the screen/tmux session,
    deletes `.agency/`, `comms/`, and the collab-bus files under `tmp/`,
    strips agency-added blocks from `CLAUDE.md`, `.claude/settings.json`,
    and `.gitignore`. Leaves `docs/` alone (may contain user edits).

    Dry-run: prints the plan and asks for confirmation unless
    `non_interactive=True`.
    """
    import re as _re

    agency_dir = Path(".agency")
    comms_dir = Path("comms")
    tmp_files = [
        Path("tmp/outbound.md"),
        Path("tmp/post_outbound.py"),
        Path("tmp/watch_bus.sh"),
        Path("tmp/outbound"),
    ]
    claude_md = Path("CLAUDE.md")
    settings_path = Path(".claude/settings.json")
    gitignore_path = Path(".gitignore")

    if not agency_dir.exists() and not comms_dir.exists() and not any(p.exists() for p in tmp_files):
        console.print("[yellow]No agency installation detected here. Nothing to tear down.[/yellow]")
        return

    # --- Compute the plan ---------------------------------------------------
    to_delete: list[Path] = []
    if agency_dir.exists():
        to_delete.append(agency_dir)
    if comms_dir.exists():
        to_delete.append(comms_dir)
    for p in tmp_files:
        if p.exists():
            to_delete.append(p)

    # Shared files with agency sections to strip
    to_strip: list[tuple[Path, str]] = []
    if claude_md.exists():
        txt = claude_md.read_text(encoding="utf-8", errors="replace")
        if "## The Agency" in txt:
            to_strip.append((claude_md, "agency instruction block"))
    if settings_path.exists():
        try:
            data = json.loads(settings_path.read_text(encoding="utf-8"))
            perms = data.get("permissions", {}).get("allow", [])
            if any(_is_agency_perm(p) for p in perms):
                to_strip.append((settings_path, "agency permission entries"))
        except (json.JSONDecodeError, OSError):
            pass
    if gitignore_path.exists():
        gtxt = gitignore_path.read_text(encoding="utf-8", errors="replace")
        if any(m in gtxt for m in ("tmp/outbound", "comms/local", ".agency/", "Collab Bus")):
            to_strip.append((gitignore_path, "agency-added ignore lines"))

    # Live session
    session = _runtime_session_name()
    has_screen_session = False
    has_tmux_session = False
    try:
        r = subprocess.run(["screen", "-list"], capture_output=True, text=True)
        has_screen_session = f".{session}" in (r.stdout or "")
    except (FileNotFoundError, OSError):
        pass
    try:
        r = subprocess.run(["tmux", "has-session", "-t", session], capture_output=True)
        has_tmux_session = r.returncode == 0
    except (FileNotFoundError, OSError):
        pass

    # Active agents
    try:
        registry = _runtime_load_registry()
        active_agents = [a for a in registry.get("agents", []) if a.get("status") == "active"]
    except Exception:
        active_agents = []

    # --- Print the plan ----------------------------------------------------
    console.print(Panel("Teardown plan — destructive", style="bold red"))

    if active_agents:
        console.print("\n[bold yellow]Agents to fire:[/bold yellow]")
        for a in active_agents:
            console.print(f"  · {a['id']}")

    if has_screen_session or has_tmux_session:
        console.print("\n[bold red]Session(s) to kill:[/bold red]")
        if has_screen_session:
            console.print(f"  ✗ screen session: {session}")
        if has_tmux_session:
            console.print(f"  ✗ tmux session: {session}")

    console.print("\n[bold red]Files/dirs to DELETE:[/bold red]")
    for p in to_delete:
        console.print(f"  ✗ {p}")

    if to_strip:
        console.print("\n[bold yellow]Shared files — agency sections will be STRIPPED (user content preserved):[/bold yellow]")
        for p, desc in to_strip:
            console.print(f"  ⚠ {p} [dim]({desc})[/dim]")

    if Path("docs").exists():
        console.print("\n[bold green]Left alone (user content — remove manually if you want):[/bold green]")
        console.print("  · docs/  [dim](bootstrapped placeholders; may contain your edits)[/dim]")

    console.print()

    if not non_interactive:
        confirm = questionary.confirm(
            "This cannot be undone. Proceed?",
            default=False,
        ).ask()
        if not confirm:
            console.print("[yellow]Teardown cancelled — nothing was changed.[/yellow]")
            return

    # --- Execute ------------------------------------------------------------
    # 1. Fire active agents (best-effort — we're nuking .agency/ next anyway).
    for a in active_agents:
        try:
            fire_agent(agent_id=a["id"])
        except Exception as e:
            console.print(f"  [yellow]warn: fire {a['id']} failed: {e}[/yellow]")

    # 2. Kill sessions
    if has_screen_session and shutil.which("screen"):
        try:
            r = subprocess.run(["screen", "-list"], capture_output=True, text=True)
            for line in (r.stdout or "").splitlines():
                line = line.strip()
                if f".{session}" in line.split("\t")[0]:
                    pid_name = line.split("\t")[0].strip()
                    subprocess.run(["screen", "-S", pid_name, "-X", "quit"], capture_output=True)
                    console.print(f"  [green]✓[/green] killed screen session {pid_name}")
        except Exception as e:
            console.print(f"  [yellow]warn: screen session kill failed: {e}[/yellow]")
    if has_tmux_session and shutil.which("tmux"):
        try:
            subprocess.run(["tmux", "kill-session", "-t", session], capture_output=True)
            console.print(f"  [green]✓[/green] killed tmux session {session}")
        except Exception as e:
            console.print(f"  [yellow]warn: tmux kill failed: {e}[/yellow]")

    # 3. Delete files/dirs
    for p in to_delete:
        try:
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
            else:
                p.unlink(missing_ok=True)
            console.print(f"  [green]✓[/green] removed {p}")
        except Exception as e:
            console.print(f"  [red]✗[/red] could not remove {p}: {e}")

    # 3a. Prune git's internal worktree metadata. Removing .agency/worktrees/
    # on disk doesn't tell git about it — the stale .git/worktrees/<agent>/
    # entries will otherwise linger across tests and confuse future
    # `git worktree add` calls on the same names.
    if Path(".git").exists():
        try:
            subprocess.run(["git", "worktree", "prune"], capture_output=True, check=False)
            console.print("  [green]✓[/green] pruned stale git worktree metadata")
        except (OSError, FileNotFoundError):
            pass

    # 3b. Remove tmp/ if it's now empty (we cleaned out the agency files but
    # don't want to nuke the dir if the user had other stuff in it).
    tmp_dir = Path("tmp")
    if tmp_dir.is_dir():
        try:
            if not any(tmp_dir.iterdir()):
                tmp_dir.rmdir()
                console.print(f"  [green]✓[/green] removed empty tmp/")
        except OSError:
            pass

    # 4. Strip shared files
    for p, desc in to_strip:
        try:
            if p.name == "CLAUDE.md":
                txt = p.read_text(encoding="utf-8")
                # Cut from "## The Agency" heading to next top-level "## " (or EOF).
                m = _re.search(r"(?:^|\n)## The Agency[^\n]*\n", txt)
                if m:
                    rest = txt[m.end():]
                    nxt = _re.search(r"\n## ", rest)
                    if nxt:
                        txt = txt[:m.start()] + rest[nxt.start():]
                    else:
                        txt = txt[:m.start()].rstrip() + "\n"
                    p.write_text(txt, encoding="utf-8")
            elif p.name == "settings.json":
                data = json.loads(p.read_text(encoding="utf-8"))
                if "permissions" in data and "allow" in data["permissions"]:
                    data["permissions"]["allow"] = [
                        perm for perm in data["permissions"]["allow"]
                        if not _is_agency_perm(perm)
                    ]
                p.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
            elif p.name == ".gitignore":
                lines = p.read_text(encoding="utf-8").splitlines()
                skip_patterns = ("tmp/outbound", "comms/local", ".agency/")
                header_marker = "# Collab Bus"
                cleaned = []
                skip_next_blank = False
                for line in lines:
                    if header_marker in line:
                        skip_next_blank = True
                        continue
                    if any(pat in line for pat in skip_patterns):
                        continue
                    if skip_next_blank and line.strip() == "":
                        skip_next_blank = False
                        continue
                    skip_next_blank = False
                    cleaned.append(line)
                p.write_text("\n".join(cleaned).rstrip() + "\n", encoding="utf-8")
            console.print(f"  [green]✓[/green] stripped agency content from {p}")
        except Exception as e:
            console.print(f"  [red]✗[/red] could not strip {p}: {e}")

    console.print("\n[bold green]Teardown complete.[/bold green]")


def _is_agency_perm(perm: str) -> bool:
    """Return True if a permission entry in .claude/settings.json was agency-added."""
    if not isinstance(perm, str):
        return False
    agency_patterns = [
        "tmp/post_outbound.py",
        "agency ",
        "agency)",
        "gh issue",
        "gh pr",
        "git worktree",
        "git init",
        "git remote",
    ]
    # Match the base permissions we know get added.
    agency_exact = {
        "Bash(open *)",
        "Bash(xdg-open *)",
    }
    return perm in agency_exact or any(pat in perm for pat in agency_patterns)


def show_agent_logs(agent_id: Optional[str], tail: int = 100) -> None:
    """Print the tail of an agent's screen log.

    With no agent_id, list agents that have logs available.
    """
    logs_dir = _agency_logs_dir()
    if not logs_dir.exists():
        console.print(
            f"[yellow]No logs directory at {logs_dir}.[/yellow] "
            "Run agents with [cyan]--debug[/cyan] or "
            "[cyan]AGENCY_DEBUG=1[/cyan] to capture logs."
        )
        return

    if not agent_id:
        entries = [p for p in logs_dir.iterdir() if p.is_dir()]
        if not entries:
            console.print(f"[yellow]No agent logs yet under {logs_dir}.[/yellow]")
            return
        console.print(f"[bold]Agents with logs in {logs_dir}:[/bold]")
        for p in sorted(entries):
            screen_log = p / "screen.log"
            size = screen_log.stat().st_size if screen_log.exists() else 0
            console.print(f"  [cyan]{p.name}[/cyan]  ({size} bytes)")
        console.print(
            "\nRun [cyan]agency logs <agent-id>[/cyan] to tail one, "
            "or [cyan]--tail N[/cyan] to change the line count."
        )
        return

    path = _agent_log_path(agent_id)
    if not path.exists():
        console.print(
            f"[red]No log found at {path}.[/red] "
            "Was this agent hired with --debug or AGENCY_DEBUG=1?"
        )
        return
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as e:
        console.print(f"[red]Could not read {path}: {e}[/red]")
        return
    for line in lines[-tail:]:
        print(line)


def show_status() -> None:
    """Print the org chart from the registry."""
    with _runtime_registry_lock(shared=True):
        registry = _runtime_load_registry()
    agents = registry.get("agents", [])
    active = [a for a in agents if a["status"] != "fired"]

    if not agents:
        console.print(
            "[yellow]No agents have been hired yet.[/yellow]\n"
            "[dim]Run [cyan]agency hire[/cyan] to spawn your first agent.[/dim]"
        )
        return

    table = Table(
        title=(
            f"The Agency — org chart "
            f"({len(active)} active, {len(agents) - len(active)} archived)"
        )
    )
    table.add_column("Name", style="bold magenta")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Role")
    table.add_column("Caliber")
    table.add_column("Model", style="blue")
    table.add_column("Reports to")
    table.add_column("Status")
    table.add_column("mux")
    table.add_column("Window")

    status_style = {
        "active": "green",
        "idle": "yellow",
        "mia": "red",
        "flagged": "red",
        "fired": "dim",
    }
    for agent in agents:
        style = status_style.get(agent["status"], "white")
        # Legacy fallback for any registry row predating the mux refactor.
        window = agent.get("window") or agent.get("tmux_window", "-").split(":", 1)[-1]
        yolo_marker = "[yellow]YOLO[/yellow]" if agent.get("yolo") else ""
        status_cell = f"[{style}]{agent['status']}[/{style}]"
        if yolo_marker:
            status_cell = f"{status_cell} {yolo_marker}"
        table.add_row(
            agent.get("name") or "—",
            agent["id"],
            agent["role"],
            agent.get("caliber", "-"),
            agent.get("model", "default"),
            str(agent.get("reports_to") or "human"),
            status_cell,
            agent.get("mux", "tmux"),
            window,
        )

    console.print(table)
    if active:
        console.print(
            "\n[dim]Attach to an agent: use the command printed when it was hired, "
            "or run [cyan]tmux attach -t agency[/cyan] / [cyan]screen -r agency[/cyan] "
            "depending on the mux column.[/dim]"
        )


# ---------------------------------------------------------------------------
# Start — one-command project bootstrap
# ---------------------------------------------------------------------------

def start_agency(yolo: bool = False, provider_override: Optional[str] = None) -> None:
    """Bootstrap a project end-to-end: init + collab-bus + hire chief.

    This is the v0 of `agency start` (#16). It runs three existing commands
    in sequence so a fresh project goes from zero to a running chief in one
    command, with comms already installed.

    Future versions will add mission questions, blueprint selection, strategy
    exercises, and the --lucky variant. For now: deterministic, fast, no
    agent-driven comm setup (that was tested and found clunky).
    """
    console.print(Panel("Agency Start — project bootstrap", style="bold cyan"))

    # If yolo wasn't set via CLI flag, ask the user.
    if not yolo:
        has_docker = shutil.which("docker") is not None
        docker_label = (
            "Sandboxed mode (Docker) — full autonomy in an isolated container"
            if has_docker
            else "Sandboxed mode (Docker) — requires Docker [dim](not installed)[/dim]"
        )
        console.print(
            "\n[bold]Agent permission mode[/bold]\n\n"
            "Agents need to run commands (git, gh, npm, etc.) to do their work.\n"
            "Three modes are available:\n\n"
            "  [cyan]Safe mode[/cyan] — agents ask for permission before running "
            "commands outside their role's allowlist. You'll need to approve "
            "actions in each agent's screen window. Best for real projects.\n\n"
            "  [yellow]Autonomous mode (yolo)[/yellow] — agents run freely with "
            "no permission prompts. Faster, but agents can execute ANY command "
            "including destructive ones. Only use in throwaway/sandbox projects.\n\n"
            "  [green]Sandboxed mode (Docker)[/green] — agents run autonomously "
            "inside an isolated Docker container. Full speed, zero risk to your "
            "host machine. Best of both worlds — requires Docker installed.\n"
        )
        mode = questionary.select(
            "Which mode?",
            choices=[
                "Safe mode — agents ask before acting",
                "Autonomous mode (yolo) — no permission prompts",
                docker_label,
            ],
        ).ask()
        if mode is None:
            console.print("[yellow]Cancelled.[/yellow]")
            return
        if "yolo" in mode.lower():
            yolo = True
        elif "Docker" in mode:
            if not has_docker:
                console.print(
                    "\n[red]Docker is not installed.[/red]\n"
                    "[dim]Install Docker Desktop from [cyan]https://docker.com/products/docker-desktop[/cyan]\n"
                    "Then re-run [cyan]agency start[/cyan] and pick Sandboxed mode.[/dim]"
                )
                return
            console.print(
                "\n[yellow]Sandboxed mode is under active development.[/yellow]\n\n"
                "What it will do when ready:\n"
                "  1. Build a Docker image with tmux, git, gh, node, python, and claude CLI\n"
                "  2. Mount your project as a volume\n"
                "  3. Run the agency inside the container with full autonomy\n"
                "  4. You attach via: [cyan]docker exec -it agency tmux attach[/cyan]\n\n"
                "Track progress: [cyan]https://github.com/flegare/the_agency/issues/20[/cyan]\n\n"
                "[dim]For now, use Autonomous mode (yolo) in a throwaway directory "
                "for a similar experience without isolation.[/dim]"
            )
            return

    if yolo:
        console.print(
            "[yellow]⚠ Autonomous mode — agents will run with "
            "YOLO flags. Use in sandbox projects only.[/yellow]\n"
        )

    # 0. Ask for provider preference for the whole project bootstrap
    provider = provider_override
    if not provider:
        provider_choices = [
            questionary.Choice(f"{p['name']} ({p['binary']})", value=p_id)
            for p_id, p in PROVIDERS.items()
        ]
        provider = questionary.select(
            "Which AI provider engine should the team use by default?",
            choices=provider_choices,
            default="claude",
        ).ask()
    
    if not provider:
        return

    try:
        # 0.5 Ensure we are in a git repo (needed for worktrees).
        # Use `git rev-parse --is-inside-work-tree` — it walks up parent dirs,
        # matching what `git worktree add` does. A bare `Path(".git").exists()`
        # check would miss the case where cwd is a subdir of an existing repo,
        # and trigger a nested `git init` that breaks worktrees.
        inside_repo = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True,
        ).returncode == 0
        if not inside_repo:
            console.print("\n[bold]Step 0/3:[/bold] Initializing Git repository...\n")

            # `git commit` will fail with "Please tell me who you are" on a
            # fresh machine. Detect missing identity up front and prompt —
            # far friendlier than letting the commit crash mid-flow.
            def _git_cfg(key: str) -> str:
                r = subprocess.run(
                    ["git", "config", "--global", key],
                    capture_output=True, text=True,
                )
                return r.stdout.strip() if r.returncode == 0 else ""

            gh_name = _git_cfg("user.name")
            gh_email = _git_cfg("user.email")
            if not gh_name or not gh_email:
                console.print(
                    "[yellow]Git identity isn't configured yet.[/yellow] "
                    "It's needed for the initial commit (and every commit after).\n"
                )
                if not gh_name:
                    gh_name = questionary.text(
                        "Your name (for git commits):",
                    ).ask()
                    if not gh_name:
                        console.print("[yellow]Cancelled.[/yellow]")
                        return
                if not gh_email:
                    gh_email = questionary.text(
                        "Your email (for git commits):",
                    ).ask()
                    if not gh_email:
                        console.print("[yellow]Cancelled.[/yellow]")
                        return
                try:
                    subprocess.run(["git", "config", "--global", "user.name", gh_name],
                                   check=True, capture_output=True)
                    subprocess.run(["git", "config", "--global", "user.email", gh_email],
                                   check=True, capture_output=True)
                    console.print(
                        f"[dim]Saved globally: {gh_name} <{gh_email}>. "
                        f"Change later with [cyan]git config --global ...[/cyan][/dim]"
                    )
                except subprocess.CalledProcessError as e:
                    stderr = e.stderr.decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
                    console.print(f"[red]Could not save git identity: {stderr.strip() or e}[/red]")
                    return

            try:
                subprocess.run(["git", "init"], check=True, capture_output=True)
                # Worktrees need at least one commit to exist
                Path("README.md").touch()
                subprocess.run(["git", "add", "README.md"], check=True, capture_output=True)
                subprocess.run(["git", "commit", "-m", "initial commit (agency start)"], check=True, capture_output=True)
                console.print("[bold green]✓ Initialized Git repository[/bold green]")
            except subprocess.CalledProcessError as e:
                stderr = e.stderr.decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
                console.print(f"[red]Git initialization failed: {stderr.strip() or e}[/red]")
                return

        # 1. Init — skills + docs + AI assistant detection (deterministic,
        # no interactive menu — calls auto_detect_and_install directly).
        console.print("\n[bold]Step 1/3:[/bold] Initializing project...\n")
        auto_detect_and_install(provider_preference=provider)

        # 2. Collab-bus — non-interactive github defaults
        console.print("\n[bold]Step 2/3:[/bold] Installing collab-bus (github, defaults)...\n")
        install_collab_bus(non_interactive=True)

        # 3. Hire the chief
        console.print("\n[bold]Step 3/3:[/bold] Hiring the chief...\n")
        agent = hire_agent(role="chief", yolo=yolo, provider=provider)
    except KeyboardInterrupt:
        console.print("\n[yellow]Cancelled. Partial state may remain — "
                      "run [cyan]agency start[/cyan] again to retry.[/yellow]")
        return
    if agent is None:
        console.print("[red]Failed to hire chief. Check errors above.[/red]")
        return

    # Read the actual backend from the written conf rather than assuming
    # github — the auto-fallback to `local` (when no remote) meant the old
    # hardcoded line was lying to the user.
    backend_name = "github"
    conf_path = Path("comms") / "collab_bus.conf"
    if conf_path.exists():
        for line in conf_path.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("backend:"):
                backend_name = line.split(":", 1)[1].strip() or "github"
                break

    window = agent["window"]
    mux = agent.get("mux")
    attach_hint = _runtime_mux_attach_hint(window, mux)

    console.print(
        f"\n[bold green]Project bootstrapped![/bold green]\n\n"
        f"  Chief: [magenta]{agent.get('name', agent['id'])}[/magenta] ({agent['id']})\n"
        f"  Comms: {backend_name} backend via collab-bus\n"
        f"  Skills: installed in .agency/skills/\n\n"
        f"Attach with: [cyan]{attach_hint}[/cyan]\n\n"
        f"Tell the chief what you want to build. They'll hire the team."
    )

    # Auto-attach so the user lands inside the chief's session without a
    # copy-paste step. Skip silently when stdout is captured (smoketest,
    # CI, tests) or when the user explicitly opts out. Checking stdout
    # instead of stdin: `subprocess.run(capture_output=True)` pipes stdout
    # but leaves stdin inherited from the parent TTY, so stdin.isatty()
    # would be a false positive and hang the caller on `screen -r`.
    if not sys.stdout.isatty() or os.environ.get("AGENCY_NO_ATTACH"):
        return
    if mux == "screen" and shutil.which("screen"):
        console.print(f"\n[dim]Attaching to session in 2s — Ctrl-A d to detach.[/dim]")
        time.sleep(2)
        os.execvp("screen", ["screen", "-r", _runtime_session_name(), "-p", window])
    elif mux == "tmux" and shutil.which("tmux"):
        console.print(f"\n[dim]Attaching to session in 2s — Ctrl-B d to detach.[/dim]")
        time.sleep(2)
        os.execvp("tmux", ["tmux", "attach", "-t", f"{_runtime_session_name()}:{window}"])


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

_TOP_LEVEL_HELP = (
    "Usage: agency [COMMAND] [OPTIONS]\n\n"
    "Commands:\n"
    "  start            Bootstrap a project (init + collab-bus + hire chief)\n"
    "                   Options: --yolo, --provider <claude|gemini|aider|codex>\n"
    "  hire [role]      Hire an agent (interactive if role omitted)\n"
    "                   Options: --skill <name> --model <id> --provider <name>\n"
    "                            --yolo --task \"<text>\" --agent <name>\n"
    "  fire <agent-id>  Fire an agent by id\n"
    "  status           Show active agents in this project\n"
    "  logs [agent-id]  Tail the agent's screen log (--tail N, default 100)\n"
    "                   With no id, lists agents that have logs.\n"
    "  smoketest        Non-interactive end-to-end regression test (--keep\n"
    "                   preserves the temp dir). Exits 0 on pass, 1 on fail.\n"
    "  teardown         Remove all agency-installed files from this project\n"
    "                   (fires agents, kills session, strips shared configs).\n"
    "                   Destructive — confirms first unless --yes.\n"
    "  init             Install skills + docs + CLAUDE.md\n"
    "  collab-bus       Install the multi-agent message bus (add --yes for defaults)\n"
    "  list             Browse available skills\n"
    "  run              Run a skill interactively\n"
    "  twin             Map a digital twin\n"
    "  ollama           Set up Ollama local models\n"
    "  update           Update Agency skills and config\n\n"
    "Global options:\n"
    "  --debug          Log CLI events to .agency/logs/cli.log and enable\n"
    "                   per-agent screen logging (also via AGENCY_DEBUG=1).\n\n"
    "Run `agency <command> --help` for command-specific options.\n"
    "Run `agency` with no arguments for the interactive menu."
)

_HIRE_HELP = (
    "Usage: agency hire [ROLE] [OPTIONS]\n\n"
    "Arguments:\n"
    "  ROLE                    Role from the blueprint (e.g. dev, qa, architect).\n"
    "                          Omit for interactive picker.\n\n"
    "Options:\n"
    "  --skill <name>          Override the default skill for this role\n"
    "  --model <id>            Override the caliber-default model (e.g. sonnet, haiku)\n"
    "  --provider <name>       claude (default), gemini, aider, or codex\n"
    "  --task \"<text>\"         First task for the agent (posted on hire)\n"
    "  --agent <name>          Rehire a specific named agent (loads prior learnings)\n"
    "  --yolo                  Spawn with permission prompts disabled"
)

_START_HELP = (
    "Usage: agency start [OPTIONS]\n\n"
    "Bootstraps a fresh project: git init (if needed) → skills/docs → collab-bus → chief.\n\n"
    "Options:\n"
    "  --yolo                  Skip the interactive mode prompt, use autonomous mode\n"
    "  --provider <name>       claude (default), gemini, aider, or codex"
)


def _chdir_to_project_root() -> None:
    """Normalize cwd to the project root.

    When an agent invokes `agency <cmd>` from inside its worktree
    (`.agency/worktrees/<agent>/`), all the cwd-relative paths (AGENCY_DIR,
    RUNTIME_AGENTS_DIR, RUNTIME_WORKTREES_DIR, …) would otherwise resolve
    into the worktree. Hire state would get written into a nested phantom
    `.agency/` and the spawned screen window would try to `cd` into a path
    that doesn't exist from the screen server's cwd. (#73 extension.)

    Uses `git rev-parse --git-common-dir` which returns the main `.git` dir
    from any worktree, so we can reliably find the project root. No-op
    outside a git repo.
    """
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--git-common-dir"],
            capture_output=True, text=True, check=True,
        )
        common_dir = Path(r.stdout.strip())
        if not common_dir.is_absolute():
            common_dir = Path.cwd() / common_dir
        os.chdir(common_dir.parent.resolve())
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass


def main_menu():
    global AGENCY_DEBUG
    # Handle CLI subcommands — entry point in pyproject.toml calls main_menu() directly
    _chdir_to_project_root()
    # --debug anywhere on the command line flips debug logging on for this run.
    # Strip it from argv so the per-subcommand parsers don't see it as a role name.
    if "--debug" in sys.argv:
        AGENCY_DEBUG = True
        sys.argv = [a for a in sys.argv if a != "--debug"]
    if AGENCY_DEBUG:
        _init_debug_logger()
    if len(sys.argv) > 1:
        cmd = sys.argv[1].lower()
        # Top-level help — agents reach for --help first; don't crash on it.
        if cmd in ("--help", "-h", "help"):
            console.print(_TOP_LEVEL_HELP)
            return
        # Skip the ASCII banner for subcommands — agents call these
        # programmatically and the banner wastes tokens in their context.
        if cmd == "init":
            init_agency()
        elif cmd == "list":
            browse_skills()
        elif cmd == "run":
            run_skill()
        elif cmd == "twin":
            map_digital_twin()
        elif cmd == "ollama":
            setup_ollama()
        elif cmd == "update":
            update_agency()
        elif cmd == "collab-bus":
            yes_flag = "--yes" in sys.argv or "-y" in sys.argv
            install_collab_bus(non_interactive=yes_flag)
        elif cmd == "hire":
            if any(a in ("--help", "-h") for a in sys.argv[2:]):
                console.print(_HIRE_HELP)
                return
            # Parse: agency hire [role] [--skill <name>] [--model <model>] [--provider <name>] [--yolo] [--task "<text>"] [--agent <name>]
            hire_role = None
            hire_skill = None
            hire_model = None
            hire_provider = "claude"
            hire_yolo = False
            hire_task = None
            hire_agent_name = None
            hire_args = sys.argv[2:]
            i = 0
            while i < len(hire_args):
                token = hire_args[i]
                if token == "--skill" and i + 1 < len(hire_args):
                    hire_skill = hire_args[i + 1]
                    i += 2
                elif token == "--model" and i + 1 < len(hire_args):
                    hire_model = hire_args[i + 1]
                    i += 2
                elif token == "--provider" and i + 1 < len(hire_args):
                    hire_provider = hire_args[i + 1].lower()
                    i += 2
                elif token == "--task" and i + 1 < len(hire_args):
                    hire_task = hire_args[i + 1]
                    i += 2
                elif token == "--agent" and i + 1 < len(hire_args):
                    hire_agent_name = hire_args[i + 1]
                    i += 2
                elif token == "--yolo":
                    hire_yolo = True
                    i += 1
                elif not token.startswith("--") and hire_role is None:
                    hire_role = token
                    i += 1
                else:
                    i += 1
            
            # Interactive provider selection if called via 'agency' without subcommands
            # (though the if-len(sys.argv)>1 branch handles the CLI args)
            hire_agent(
                role=hire_role,
                skill_override=hire_skill,
                model=hire_model,
                provider=hire_provider,
                yolo=hire_yolo,
                task=hire_task,
                agent_name=hire_agent_name,
            )
        elif cmd == "status":
            show_status()
        elif cmd == "fire":
            fire_id = sys.argv[2] if len(sys.argv) > 2 else None
            fire_agent(agent_id=fire_id)
        elif cmd == "smoketest":
            keep = "--keep" in sys.argv
            sys.exit(run_smoketest(keep=keep))
        elif cmd == "teardown":
            yes = "--yes" in sys.argv or "-y" in sys.argv
            teardown_agency(non_interactive=yes)
        elif cmd == "logs":
            log_agent = None
            tail = 100
            rest = sys.argv[2:]
            i = 0
            while i < len(rest):
                tok = rest[i]
                if tok in ("--tail", "-n") and i + 1 < len(rest):
                    try:
                        tail = int(rest[i + 1])
                    except ValueError:
                        console.print(f"[red]--tail expects an integer, got {rest[i + 1]!r}[/red]")
                        return
                    i += 2
                elif not tok.startswith("--") and log_agent is None:
                    log_agent = tok
                    i += 1
                else:
                    i += 1
            show_agent_logs(log_agent, tail=tail)
        elif cmd == "start":
            if any(a in ("--help", "-h") for a in sys.argv[2:]):
                console.print(_START_HELP)
                return
            start_yolo = "--yolo" in sys.argv
            start_provider = None
            if "--provider" in sys.argv:
                try:
                    p_idx = sys.argv.index("--provider")
                    if p_idx + 1 < len(sys.argv):
                        start_provider = sys.argv[p_idx + 1].lower()
                except ValueError:
                    pass
            start_agency(yolo=start_yolo, provider_override=start_provider)
        else:
            console.print(
                f"[red]Unknown command: '{cmd}'[/red]\n"
                "Available: [cyan]init  list  run  twin  ollama  update  "
                "collab-bus  hire  status  fire  start[/cyan]\n"
                "Run [cyan]agency[/cyan] with no arguments for the interactive menu."
            )
        return

    threading.Thread(target=check_for_updates, daemon=True).start()
    print_header()

    while True:
        if UPDATE_AVAILABLE:
            console.print(Panel(
                f"[bold yellow]Update Available![/bold yellow] Version {UPDATE_AVAILABLE} is out.\n"
                f"Run [cyan]pip install --upgrade the-agency-cli[/cyan] to get the latest skills.",
                border_style="yellow",
            ))

        choice = questionary.select(
            "Welcome to The Agency. How can the team assist you today?",
            choices=[
                "🏢 Start a new project (start)",
                "🚀 Initialize / Configure Project (init)",
                "🔄 Update Skills (sync new skills from package)",
                "👥 Browse Organization Chart (list)",
                "⚡ Task a specific Skill (run)",
                "🔗 Install Collab Bus (collab-bus)",
                "👔 Hire an agent (hire)",
                "📊 Show live org chart (status)",
                "👋 Fire an agent (fire)",
                "🦙 Ollama Setup (install / pull models)",
                questionary.Separator("── Developer ──"),
                "🧪 Developer — Run smoke test",
                "📋 Developer — View agent logs",
                "ℹ️  Developer — Debug logging info",
                "🧨 Developer — Tear down agency from this project",
                "❌ Exit",
            ],
        ).ask()

        if not choice or "Exit" in choice:
            console.print("[dim]Shutting down The Agency. Goodbye![/dim]")
            break
        elif "Start a new project" in choice:
            start_agency()  # will prompt for mode interactively
        elif "init" in choice:
            init_agency()
        elif "Update Skills" in choice:
            update_agency()
        elif "list" in choice:
            browse_skills()
        elif "run" in choice:
            run_skill()
        elif "Collab Bus" in choice:
            install_collab_bus()
        elif "Hire an agent" in choice:
            hire_agent()
        elif "live org chart" in choice:
            show_status()
        elif "Fire an agent" in choice:
            fire_agent()
        elif "Ollama" in choice:
            setup_ollama()
        elif "Run smoke test" in choice:
            run_smoketest()
        elif "View agent logs" in choice:
            _interactive_view_logs()
        elif "Debug logging info" in choice:
            _print_debug_info()
        elif "Tear down agency" in choice:
            teardown_agency()

        print("\n")

if __name__ == "__main__":
    main_menu()
