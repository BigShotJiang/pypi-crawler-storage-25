import argparse
import sys
import textwrap
import shutil

from clichatty.ui import UI
from clichatty.sms import SMS, SMSCreateError, SMSSendError, SMSDeleteError
from clichatty.db import DB


def send_msg(thread_id, thread_name, msg):
    try:
        sms = SMS(thread_name, msg)
    except SMSCreateError as e:
        print(e, file=sys.stderr)
        return 1
    try:
        sms.send()
        with DB() as db:
            db.insert_message(thread_id, msg)
            msgs = db.get_thread(thread_id)
    except (SMSSendError, SMSDeleteError) as e:
        print(e, file=sys.stderr)
        return 1


def show_tail(thread_id, n):
    termw = shutil.get_terminal_size().columns
    with DB() as db:
        msgs = db.get_thread(thread_id, last_n_messages=n)
    alm = max(set([len(alias) for _, alias, _, _ in msgs]))
    if msgs:
        for _, alias, datetime, body in msgs[::-1]:
            dtl = len(datetime)
            al = len(alias)
            body_wrapped = []
            for l in body.split('\n'):
                body_wrapped += textwrap.wrap(l, 
                                              width=termw - dtl - alm - 8,
                                              break_long_words=False)
            for i, l in enumerate(body_wrapped):
                if i == 0:
                    print(alias, ' ' * (alm - al + 2), datetime, '  ', l)
                else:
                    print(' ' * (dtl + alm + 4), '  ', l)


def main():
    if len(sys.argv) == 1:
        UI()
    else:
        ap = argparse.ArgumentParser(description='''
                Terminal interface to the phone's modem, integrating with the
                chatty database. Run without arguments for the curses
                interface''')
        ap.add_argument('-m', '--message')
        ap.add_argument('-a', '--alias')
        ap.add_argument('-t', '--tail', nargs='?', type=int, const=10)
        ap.add_argument('-2', '--tfa', nargs='?', type=int, const=1)
        args = ap.parse_args()

        if args.alias:
            with DB() as db:
                threads = db.get_threads()
            for thread_id, thread_alias, thread_name in threads:
                if args.alias == thread_alias:
                    if args.message:
                        send_msg(thread_id, thread_name, args.message)
                    elif args.tail: 
                        show_tail(thread_id, args.tail)
        elif args.tfa:
            with DB() as db:
                matches = db.get_tfa(args.tfa)
            for m in matches:
                print(m)


if __name__ == "__main__":
    main()
