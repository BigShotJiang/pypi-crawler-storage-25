"""Pure tests for the stamp_math helpers (no network)."""

from __future__ import annotations

from bee.postage import (
    get_depth_for_size,
    get_stamp_cost,
    get_stamp_effective_bytes,
    get_stamp_theoretical_bytes,
    get_stamp_usage,
)


def test_theoretical_bytes_at_depth_17() -> None:
    # 4096 * 2^17 = 536_870_912
    assert get_stamp_theoretical_bytes(17) == 536_870_912


def test_theoretical_bytes_at_depth_22() -> None:
    # 4096 * 2^22 = 17_179_869_184
    assert get_stamp_theoretical_bytes(22) == 17_179_869_184


def test_cost_at_depth_zero_is_amount() -> None:
    assert get_stamp_cost(0, 100) == 100


def test_cost_at_depth_three_is_eight_amount() -> None:
    assert get_stamp_cost(3, 100) == 800


def test_cost_handles_python_arbitrary_precision_ints() -> None:
    # bee-rs uses BigInt; Python int is arbitrary-precision so we just
    # need to confirm we don't overflow a 2^53 safe-integer boundary.
    huge = 2**100
    assert get_stamp_cost(50, huge) == 2**50 * huge


def test_effective_bytes_uses_table_at_depth_17() -> None:
    # 0.00004089 * 1e9 = 40_890
    assert get_stamp_effective_bytes(17) == 40_890


def test_effective_bytes_below_17_is_zero() -> None:
    assert get_stamp_effective_bytes(16) == 0
    assert get_stamp_effective_bytes(0) == 0


def test_effective_bytes_above_34_uses_theoretical_fallback() -> None:
    # depth 35 isn't in the table → 0.9 * theoretical
    expected = int(get_stamp_theoretical_bytes(35) * 0.9)
    assert get_stamp_effective_bytes(35) == expected


def test_depth_for_size_smallest_covering() -> None:
    # 1 MB → fits in depth-18 (0.00609 GB ≈ 6.09 MB)
    assert get_depth_for_size(1_000_000) == 18


def test_depth_for_size_above_table_returns_35() -> None:
    # 100 TB exceeds depth-34's 63150 GB cap (only barely — 63.15 TB).
    # So 100 TB → 35.
    assert get_depth_for_size(100 * 1_000_000_000_000) == 35


def test_depth_for_size_one_kb_fits_smallest_depth() -> None:
    # 1 KB easily fits in depth-17 (0.04 MB cap).
    assert get_depth_for_size(1_000) == 17


def test_usage_fraction_at_half() -> None:
    # utilization = 8, depth = 20, bucket_depth = 16 → 8 / (1 << 4) = 0.5
    assert abs(get_stamp_usage(8, 20, 16) - 0.5) < 1e-9


def test_usage_fraction_at_zero() -> None:
    assert get_stamp_usage(0, 22, 16) == 0.0


def test_usage_fraction_at_full() -> None:
    # 64 chunks at depth-22 / bucket_depth-16 → 64 / 64 = 1.0
    assert get_stamp_usage(64, 22, 16) == 1.0
