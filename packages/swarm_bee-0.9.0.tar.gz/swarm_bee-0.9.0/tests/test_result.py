"""Tests for the upload/download return types."""

from __future__ import annotations

from bee import FileHeaders, UploadResult
from bee.api.result import parse_content_disposition_filename


def test_upload_result_parses_reference_and_headers() -> None:
    ref_hex = "ab" * 32
    headers = {
        "Swarm-Tag": "42",
        "Swarm-Act-History-Address": "cd" * 32,
    }
    r = UploadResult.from_response(ref_hex, headers)
    assert r.reference.to_hex() == ref_hex
    assert r.tag_uid == 42
    assert r.history_address is not None
    assert r.history_address.to_hex() == "cd" * 32


def test_upload_result_handles_missing_headers() -> None:
    r = UploadResult.from_response("00" * 32, {})
    assert r.tag_uid is None
    assert r.history_address is None


def test_upload_result_lookup_is_case_insensitive() -> None:
    r = UploadResult.from_response("00" * 32, {"swarm-tag": "7"})
    assert r.tag_uid == 7


def test_file_headers_parse_quoted_filename() -> None:
    h = {
        "Content-Type": "text/plain",
        "Content-Disposition": 'attachment; filename="hello.txt"',
        "Swarm-Tag-Uid": "7",
    }
    fh = FileHeaders.from_response(h)
    assert fh.content_type == "text/plain"
    assert fh.name == "hello.txt"
    assert fh.tag_uid == 7


def test_parse_content_disposition_rfc5987() -> None:
    assert (
        parse_content_disposition_filename("attachment; filename*=UTF-8''my%20file.txt")
        == "my%20file.txt"
    )


def test_parse_content_disposition_unquoted() -> None:
    assert parse_content_disposition_filename("attachment; filename=plain.txt") == "plain.txt"


def test_parse_content_disposition_no_filename() -> None:
    assert parse_content_disposition_filename("attachment") is None
