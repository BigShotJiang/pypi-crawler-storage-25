"""End-to-end tests for ``client.file.upload_data`` / ``download_data`` /
``probe_data`` against respx-mocked Bee responses."""

from __future__ import annotations

import httpx
import pytest
import respx

from bee import (
    AsyncBee,
    Bee,
    BeeJsonError,
    BeeResponseError,
    DownloadOptions,
    RedundancyLevel,
    RedundantUploadOptions,
)
from bee.swarm import BatchId, Reference

BATCH = BatchId(b"\xab" * 32)
REF_HEX = "cd" * 32


@respx.mock
async def test_async_upload_data_sends_required_headers_and_returns_result() -> None:
    route = respx.post("http://localhost:1633/bytes").mock(
        return_value=httpx.Response(
            200,
            json={"reference": REF_HEX},
            headers={"Swarm-Tag": "11"},
        )
    )

    async with AsyncBee("http://localhost:1633") as client:
        result = await client.file.upload_data(BATCH, b"hello swarm")

    assert result.reference.to_hex() == REF_HEX
    assert result.tag_uid == 11
    assert result.history_address is None

    sent = route.calls.last.request
    assert sent.headers["swarm-postage-batch-id"] == "ab" * 32
    assert sent.headers["content-type"] == "application/octet-stream"
    assert sent.content == b"hello swarm"


@respx.mock
async def test_async_upload_data_includes_redundancy_header_when_set() -> None:
    route = respx.post("http://localhost:1633/bytes").mock(
        return_value=httpx.Response(200, json={"reference": REF_HEX})
    )
    async with AsyncBee() as client:
        await client.file.upload_data(
            BATCH,
            b"x",
            RedundantUploadOptions(
                pin=True,
                encrypt=False,
                redundancy_level=RedundancyLevel.STRONG,
            ),
        )
    sent = route.calls.last.request
    assert sent.headers["swarm-pin"] == "true"
    assert sent.headers["swarm-encrypt"] == "false"
    assert sent.headers["swarm-redundancy-level"] == "2"


@respx.mock
async def test_async_upload_data_propagates_response_error() -> None:
    respx.post("http://localhost:1633/bytes").mock(
        return_value=httpx.Response(422, content=b"stamp not usable")
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeResponseError) as ei:
            await client.file.upload_data(BATCH, b"x")
    assert ei.value.status == 422
    assert ei.value.body == b"stamp not usable"


@respx.mock
async def test_async_upload_data_raises_on_missing_reference_field() -> None:
    respx.post("http://localhost:1633/bytes").mock(
        return_value=httpx.Response(200, json={"unexpected": "shape"})
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeJsonError):
            await client.file.upload_data(BATCH, b"x")


@respx.mock
async def test_async_download_data_returns_body_for_plain_reference() -> None:
    ref = Reference.from_hex(REF_HEX)
    respx.get(f"http://localhost:1633/bytes/{REF_HEX}").mock(
        return_value=httpx.Response(200, content=b"hello swarm")
    )
    async with AsyncBee() as client:
        body = await client.file.download_data(ref)
    assert body == b"hello swarm"


@respx.mock
async def test_async_download_data_works_for_encrypted_reference() -> None:
    enc_hex = "ab" * 64  # 64-byte encrypted ref
    ref = Reference.from_hex(enc_hex)
    respx.get(f"http://localhost:1633/bytes/{enc_hex}").mock(
        return_value=httpx.Response(200, content=b"plaintext")
    )
    async with AsyncBee() as client:
        body = await client.file.download_data(ref)
    assert body == b"plaintext"


@respx.mock
async def test_async_download_data_passes_strategy_header() -> None:
    ref = Reference.from_hex(REF_HEX)
    route = respx.get(f"http://localhost:1633/bytes/{REF_HEX}").mock(
        return_value=httpx.Response(200, content=b"x")
    )
    async with AsyncBee() as client:
        await client.file.download_data(ref, DownloadOptions(timeout_ms=2000))
    assert route.calls.last.request.headers["swarm-chunk-retrieval-timeout"] == "2000"


@respx.mock
async def test_async_probe_data_returns_content_length() -> None:
    ref = Reference.from_hex(REF_HEX)
    respx.head(f"http://localhost:1633/bytes/{REF_HEX}").mock(
        return_value=httpx.Response(200, headers={"Content-Length": "9999"})
    )
    async with AsyncBee() as client:
        info = await client.file.probe_data(ref)
    assert info.content_length == 9999


@respx.mock
def test_sync_upload_and_download_round_trip() -> None:
    respx.post("http://localhost:1633/bytes").mock(
        return_value=httpx.Response(200, json={"reference": REF_HEX})
    )
    respx.get(f"http://localhost:1633/bytes/{REF_HEX}").mock(
        return_value=httpx.Response(200, content=b"sync hello")
    )
    with Bee() as client:
        result = client.file.upload_data(BATCH, b"sync hello")
        body = client.file.download_data(result.reference)
    assert body == b"sync hello"
