"""Tests for ``bee.pss`` (HTTP send) — subscribe is async-WS and is
covered by the live integration check, not these mocks."""

from __future__ import annotations

import httpx
import respx

from bee import AsyncBee, Bee
from bee.swarm import BatchId, PrivateKey, Topic

BATCH = BatchId(b"\xab" * 32)


@respx.mock
async def test_async_pss_send_posts_with_batch_header() -> None:
    topic = Topic.from_string("greetings")
    target = "1234"
    expected_url = f"http://localhost:1633/pss/send/{topic.to_hex()}/{target}"

    route = respx.post(expected_url).mock(return_value=httpx.Response(200))

    async with AsyncBee() as client:
        await client.pss.send(BATCH, topic, target, b"hello pss")

    sent = route.calls.last.request
    assert sent.headers["swarm-postage-batch-id"] == "ab" * 32
    assert sent.content == b"hello pss"
    # No recipient → no recipient= query.
    assert "recipient" not in sent.url.params


@respx.mock
async def test_async_pss_send_with_recipient_adds_query() -> None:
    topic = Topic.from_string("encrypted")
    pk = PrivateKey(bytes([0x42]) * 32)
    recipient = pk.public_key()
    expected_url = f"http://localhost:1633/pss/send/{topic.to_hex()}/abcd"

    route = respx.post(expected_url).mock(return_value=httpx.Response(200))

    async with AsyncBee() as client:
        await client.pss.send(
            BATCH, topic, "abcd", b"secret", recipient=recipient
        )

    sent = route.calls.last.request
    assert sent.url.params["recipient"] == recipient.compressed_hex()


@respx.mock
def test_sync_pss_send() -> None:
    topic = Topic.from_string("sync-pss")
    target = "55aa"
    expected_url = f"http://localhost:1633/pss/send/{topic.to_hex()}/{target}"

    respx.post(expected_url).mock(return_value=httpx.Response(200))

    with Bee() as client:
        client.pss.send(BATCH, topic, target, b"sync hello")
