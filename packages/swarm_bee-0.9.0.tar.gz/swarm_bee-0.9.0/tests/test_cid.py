"""Tests for ``bee.swarm.cid`` — Reference ↔ CID conversion."""

from __future__ import annotations

import pytest

from bee.swarm import (
    CidType,
    Reference,
    convert_cid_to_reference,
    convert_reference_to_cid,
)
from bee.swarm.cid import _b32_decode, _b32_encode  # type: ignore[attr-defined]
from bee.swarm.errors import BeeArgumentError


def test_round_trip_feed() -> None:
    """Same fixture as bee-go's TestCID."""
    hex_str = "ca6357a08e317d15ec560fef34e4c45f8f19f01c75d6f20a7021602e9575a617"
    reference = Reference.from_hex(hex_str)
    cid = convert_reference_to_cid(reference, CidType.FEED)
    assert cid.startswith("b")
    decoded = convert_cid_to_reference(cid)
    assert decoded.kind is CidType.FEED
    assert decoded.reference.to_hex() == hex_str


def test_round_trip_manifest() -> None:
    hex_str = "f" * 64
    reference = Reference.from_hex(hex_str)
    cid = convert_reference_to_cid(reference, CidType.MANIFEST)
    decoded = convert_cid_to_reference(cid)
    assert decoded.kind is CidType.MANIFEST
    assert decoded.reference.to_hex() == hex_str


def test_rejects_encrypted_reference() -> None:
    encrypted = Reference.from_hex("a" * 128)
    with pytest.raises(BeeArgumentError):
        convert_reference_to_cid(encrypted, CidType.FEED)


def test_rejects_unknown_codec() -> None:
    # Hand-craft a CID with codec byte 0x55.
    header = bytes([1, 0x55, 1, 0x1B, 32]) + bytes(32)
    cid = "b" + _b32_encode(header).lower()
    with pytest.raises(BeeArgumentError):
        convert_cid_to_reference(cid)


def test_rejects_missing_prefix() -> None:
    with pytest.raises(BeeArgumentError):
        convert_cid_to_reference("acafef00")


def test_rejects_short_cid() -> None:
    cid = "b" + _b32_encode(bytes(8)).lower()
    with pytest.raises(BeeArgumentError):
        convert_cid_to_reference(cid)


@pytest.mark.parametrize(
    "raw, encoded",
    [
        (b"", ""),
        (b"f", "MY"),
        (b"fo", "MZXQ"),
        (b"foo", "MZXW6"),
        (b"foob", "MZXW6YQ"),
        (b"fooba", "MZXW6YTB"),
        (b"foobar", "MZXW6YTBOI"),
    ],
)
def test_b32_round_trip_matches_rfc4648(raw: bytes, encoded: str) -> None:
    """Direct check against the RFC 4648 §10 vectors."""
    assert _b32_encode(raw) == encoded
    assert _b32_decode(encoded) == raw


def test_b32_decode_rejects_invalid_character() -> None:
    with pytest.raises(BeeArgumentError):
        _b32_decode("MZXW8")  # 8 is not in the base32 alphabet
