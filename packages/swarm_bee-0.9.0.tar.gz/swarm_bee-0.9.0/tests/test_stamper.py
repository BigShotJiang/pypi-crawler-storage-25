"""Tests for the offline ``Stamper`` and ``marshal_stamp``."""

from __future__ import annotations

import pytest

from bee import BeeArgumentError
from bee.postage import (
    MARSHALED_STAMP_LENGTH,
    Envelope,
    Stamper,
    convert_envelope_to_marshaled_stamp,
    marshal_stamp,
)
from bee.swarm import (
    BatchId,
    PrivateKey,
    Signature,
    keccak256,
    verify_signature,
)


def _signer() -> PrivateKey:
    return PrivateKey(b"\x11" * 32)


def _batch() -> BatchId:
    return BatchId(b"\x00" * 32)


def test_stamp_increments_bucket_and_signs_verifiably() -> None:
    stamper = Stamper.from_blank(_signer(), _batch(), 20)
    addr = b"\x00" * 32
    env = stamper.stamp(addr)

    assert env.batch_id == _batch()
    assert len(env.signature.as_bytes()) == 65
    assert len(env.index) == 8
    assert len(env.issuer.as_bytes()) == 20
    assert stamper.state()[0] == 1

    # Signature verifies against the recovered issuer using the same
    # `chunk || batch || index || timestamp` payload.
    to_sign = addr + _batch().as_bytes() + env.index + env.timestamp
    assert verify_signature(env.signature, to_sign, env.issuer)


def test_consecutive_stamps_bump_bucket_height() -> None:
    stamper = Stamper.from_blank(_signer(), _batch(), 20)
    env1 = stamper.stamp(b"\x00" * 32)
    env2 = stamper.stamp(b"\x00" * 32)
    assert stamper.state()[0] == 2
    # Index height bumped from 0 → 1 (last 4 bytes of index).
    assert env1.index[4:] == b"\x00\x00\x00\x00"
    assert env2.index[4:] == b"\x00\x00\x00\x01"


def test_rejects_depth_at_or_below_floor() -> None:
    with pytest.raises(BeeArgumentError):
        Stamper.from_blank(_signer(), _batch(), 16)
    with pytest.raises(BeeArgumentError):
        Stamper.from_blank(_signer(), _batch(), 0)
    Stamper.from_blank(_signer(), _batch(), 17)  # ok


def test_rejects_bad_chunk_address_length() -> None:
    stamper = Stamper.from_blank(_signer(), _batch(), 20)
    with pytest.raises(BeeArgumentError):
        stamper.stamp(b"\x00" * 31)
    with pytest.raises(BeeArgumentError):
        stamper.stamp(b"\x00" * 33)


def test_bucket_full_errors() -> None:
    """depth 17 → max_slot = 2^1 = 2. Two stamps fit, third overflows."""
    stamper = Stamper.from_blank(_signer(), _batch(), 17)
    addr = b"\x00" * 32
    stamper.stamp(addr)
    stamper.stamp(addr)
    with pytest.raises(BeeArgumentError):
        stamper.stamp(addr)


def test_from_state_round_trips_bucket_counters() -> None:
    a = Stamper.from_blank(_signer(), _batch(), 18)
    a.stamp(b"\x00" * 32)
    a.stamp(b"\x00" * 32)
    snapshot = a.state()
    b = Stamper.from_state(_signer(), _batch(), snapshot, 18)
    assert b.state()[0] == 2


def test_state_returns_defensive_copy() -> None:
    a = Stamper.from_blank(_signer(), _batch(), 18)
    a.stamp(b"\x00" * 32)
    snap = a.state()
    snap[0] = 99
    # Mutating the copy must not affect the stamper.
    assert a.state()[0] == 1


def test_rejects_wrong_state_length() -> None:
    with pytest.raises(BeeArgumentError):
        Stamper.from_state(_signer(), _batch(), [0] * 10, 18)


def test_bucket_routing_uses_first_two_bytes_be() -> None:
    stamper = Stamper.from_blank(_signer(), _batch(), 20)
    addr = bytearray(32)
    addr[0] = 0xAB
    addr[1] = 0xCD
    stamper.stamp(bytes(addr))
    assert stamper.state()[0xABCD] == 1
    assert stamper.state()[0] == 0


def test_realistic_chunk_address_routes_to_correct_bucket() -> None:
    """Use a real BMT address: keccak256("hello")."""
    stamper = Stamper.from_blank(_signer(), _batch(), 20)
    addr = keccak256(b"hello")
    expected_bucket = int.from_bytes(addr[:2], "big")
    stamper.stamp(addr)
    assert stamper.state()[expected_bucket] == 1


def test_marshal_stamp_layout() -> None:
    batch_id = BatchId(b"\xaa" * 32)
    stamper = Stamper.from_blank(_signer(), batch_id, 17)
    chunk_addr = b"\x42" * 32
    env = stamper.stamp(chunk_addr)

    out = convert_envelope_to_marshaled_stamp(env)
    assert len(out) == MARSHALED_STAMP_LENGTH
    assert out[:32] == batch_id.as_bytes()
    assert out[32:40] == env.index
    assert out[40:48] == env.timestamp
    assert out[48:] == env.signature.as_bytes()


def test_marshal_stamp_timestamp_is_recent_unix_ms() -> None:
    import time

    stamper = Stamper.from_blank(_signer(), _batch(), 17)
    env = stamper.stamp(b"\x42" * 32)
    ts_ms = int.from_bytes(env.timestamp, "big")
    now_ms = time.time_ns() // 1_000_000
    assert ts_ms <= now_ms
    assert now_ms - ts_ms < 24 * 60 * 60 * 1000


def test_marshal_stamp_rejects_short_index_or_timestamp() -> None:
    batch_id = BatchId(b"\x00" * 32)
    sig = Signature(b"\xab" * 65)
    with pytest.raises(BeeArgumentError):
        marshal_stamp(batch_id, b"\x01\x02\x03", b"\x00" * 8, sig)
    with pytest.raises(BeeArgumentError):
        marshal_stamp(batch_id, b"\x00" * 8, b"\x01\x02", sig)
    # Correct lengths succeed.
    out = marshal_stamp(batch_id, b"\x00" * 8, b"\x00" * 8, sig)
    assert len(out) == MARSHALED_STAMP_LENGTH


def test_envelope_dataclass_is_frozen() -> None:
    stamper = Stamper.from_blank(_signer(), _batch(), 20)
    env = stamper.stamp(b"\x00" * 32)
    with pytest.raises(Exception):  # noqa: B017 — FrozenInstanceError is the actual
        env.batch_id = _batch()  # type: ignore[misc]
    assert isinstance(env, Envelope)
