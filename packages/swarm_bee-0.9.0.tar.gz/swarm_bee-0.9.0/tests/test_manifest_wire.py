"""Tests for the Mantaray v0.2 wire format."""

from __future__ import annotations

import pytest

from bee.manifest import (
    MantarayNode,
    calculate_self_address,
    marshal,
    populate_self_addresses,
    unmarshal,
)
from bee.swarm import BeeArgumentError, Reference


def _r32(byte: int) -> Reference:
    return Reference(bytes([byte]) * 32)


def test_marshal_requires_populated_self_addresses() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    # Children's self_address is None until populate is called.
    with pytest.raises(BeeArgumentError):
        marshal(root)


def test_empty_root_round_trips() -> None:
    root = MantarayNode()
    addr = populate_self_addresses(root)
    bytes_ = marshal(root)
    parsed = unmarshal(bytes_, addr)
    assert parsed.target_address == root.target_address
    assert not parsed.forks


def test_single_fork_round_trips_and_preserves_prefix() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    addr = populate_self_addresses(root)
    bytes_ = marshal(root)
    parsed = unmarshal(bytes_, addr)
    assert len(parsed.forks) == 1
    fork = next(iter(parsed.forks.values()))
    assert fork.prefix == b"hello"


def test_marshal_matches_bee_rs_byte_for_byte() -> None:
    """Cross-checked vs bee-rs: a fresh root with a single fork
    ("hello", 0x11…32 / zero obfuscation key) marshals to this exact
    byte sequence and the chunk address matches.
    """
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    addr = populate_self_addresses(root)
    bytes_ = marshal(root)

    want_addr = "4a108a007edc05666fb74d907b5c9c03e893604d5b8306bdaf8e0fc5f5c772ac"
    want_data = "00000000000000000000000000000000000000000000000000000000000000005768b3b6a7db56d21d1abff40d41cebfc83448fed8d7e9b06ec0d3b073f28f2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000020568656c6c6f000000000000000000000000000000000000000000000000007900d12931b05071bd6860466d56a64d9eb2fc409725f0305d3df0083fa3d2fc"  # noqa: E501
    assert addr.hex() == want_addr
    assert bytes_.hex() == want_data
    assert len(bytes_) == 192


def test_metadata_round_trips() -> None:
    root = MantarayNode()
    meta = {"Content-Type": "text/plain", "filename": "hello.txt"}
    root.add_fork(b"hello.txt", _r32(0xEE), meta)
    addr = populate_self_addresses(root)
    bytes_ = marshal(root)
    parsed = unmarshal(bytes_, addr)

    fork = next(iter(parsed.forks.values()))
    assert fork.node.metadata is not None
    assert fork.node.metadata["filename"] == "hello.txt"
    assert fork.node.metadata["Content-Type"] == "text/plain"


def test_obfuscation_key_round_trips() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    root.obfuscation_key = bytes([0xAA] * 32)
    addr = populate_self_addresses(root)
    bytes_ = marshal(root)
    # First 32 bytes are the key in plaintext; rest XORed with it.
    assert bytes_[:32] == bytes([0xAA] * 32)
    parsed = unmarshal(bytes_, addr)
    assert parsed.obfuscation_key == bytes([0xAA] * 32)
    assert len(parsed.forks) == 1


def test_multiple_paths_round_trip_full_structure() -> None:
    root = MantarayNode()
    root.add_fork(b"a/b/c.txt", _r32(0x01))
    root.add_fork(b"a/b/d.txt", _r32(0x02))
    root.add_fork(b"x.txt", _r32(0x03))
    addr = populate_self_addresses(root)
    bytes_ = marshal(root)
    parsed = unmarshal(bytes_, addr)
    # Round-trip preserves the top-level fork structure.
    assert len(parsed.forks) >= 1


def test_calculate_self_address_uses_existing_when_set() -> None:
    root = MantarayNode()
    fixed = bytes([0xAB] * 32)
    root.self_address = fixed
    assert calculate_self_address(root) == fixed


def test_unmarshal_rejects_short_data() -> None:
    with pytest.raises(BeeArgumentError):
        unmarshal(b"\x00" * 16, b"\x00" * 32)


def test_unmarshal_rejects_invalid_version_hash() -> None:
    bad = b"\x00" * 32 + b"\xff" * 64
    with pytest.raises(BeeArgumentError):
        unmarshal(bad, b"\x00" * 32)
