"""Tests for ``bee.swarm.soc`` (Single Owner Chunks)."""

from __future__ import annotations

import pytest

from bee.swarm import (
    BeeArgumentError,
    EthAddress,
    Identifier,
    PrivateKey,
    Reference,
    calculate_single_owner_chunk_address,
    keccak256,
    make_single_owner_chunk,
    unmarshal_single_owner_chunk,
)


def _signer(byte: int) -> PrivateKey:
    return PrivateKey(bytes([byte]) * 32)


def test_calculate_address_is_keccak_id_owner() -> None:
    identifier = Identifier.from_string("hello")
    owner = EthAddress.from_hex("fb6916095ca1df60bb79ce92ce3ea74c37c5d359")
    addr = calculate_single_owner_chunk_address(identifier, owner)
    expected = keccak256(identifier.as_bytes() + owner.as_bytes())
    assert addr.as_bytes() == expected


def test_make_and_unmarshal_round_trip() -> None:
    identifier = Identifier.from_string("test-identifier")
    pk = _signer(0x55)
    payload = b"single owner chunk payload"

    soc = make_single_owner_chunk(identifier, payload, pk)

    # Owner must match signer's address.
    assert soc.owner == pk.public_key().address()
    # V byte normalized to {27, 28}.
    assert soc.signature.as_bytes()[64] in (27, 28)

    address = soc.address()
    parsed = unmarshal_single_owner_chunk(soc.data(), address)

    assert parsed.identifier == soc.identifier
    assert parsed.signature == soc.signature
    assert parsed.owner == soc.owner
    assert parsed.span == soc.span
    assert parsed.payload == soc.payload


def test_unmarshal_rejects_wrong_address() -> None:
    identifier = Identifier.from_string("id")
    pk = _signer(0x66)
    soc = make_single_owner_chunk(identifier, b"x", pk)

    wrong = Reference(b"\x00" * 32)
    with pytest.raises(BeeArgumentError):
        unmarshal_single_owner_chunk(soc.data(), wrong)


def test_unmarshal_rejects_short_data() -> None:
    any_addr = Reference(b"\x00" * 32)
    with pytest.raises(BeeArgumentError):
        unmarshal_single_owner_chunk(b"\x00" * 10, any_addr)


def test_make_rejects_oversized_payload() -> None:
    pk = _signer(0x77)
    identifier = Identifier(b"\x00" * 32)
    with pytest.raises(BeeArgumentError):
        make_single_owner_chunk(identifier, b"x" * 5000, pk)


def test_soc_address_independent_of_payload() -> None:
    """SOC addressing is identifier+owner — payload changes don't move
    the address."""
    pk = _signer(0x88)
    identifier = Identifier.from_string("stable")
    a = make_single_owner_chunk(identifier, b"first", pk)
    b = make_single_owner_chunk(identifier, b"second-different-payload", pk)
    assert a.address() == b.address()
