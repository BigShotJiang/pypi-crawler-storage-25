"""Round-trip and validation tests for the swarm typed-byte newtypes."""

from __future__ import annotations

import pytest

from bee.swarm import (
    BatchId,
    BeeHexError,
    BeeLengthMismatchError,
    EthAddress,
    FeedIndex,
    Identifier,
    Reference,
    Span,
    Topic,
)


def test_hex_round_trip_with_and_without_0x_prefix() -> None:
    hex_str = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    a = BatchId.from_hex(hex_str)
    b = BatchId.from_hex(f"0x{hex_str}")
    assert a == b
    assert a.to_hex() == hex_str


def test_fixed_length_rejects_wrong_size() -> None:
    with pytest.raises(BeeLengthMismatchError):
        BatchId(b"\x00" * 31)
    with pytest.raises(BeeLengthMismatchError):
        BatchId(b"\x00" * 33)
    BatchId(b"\x00" * 32)  # ok


def test_reference_accepts_32_or_64_bytes() -> None:
    r32 = "ab" * 32
    r64 = "cd" * 64
    a = Reference.from_hex(r32)
    b = Reference.from_hex(r64)
    assert not a.is_encrypted()
    assert b.is_encrypted()
    assert a.to_hex() == r32
    assert b.to_hex() == r64
    assert len(a) == 32
    assert len(b) == 64

    with pytest.raises(BeeLengthMismatchError):
        Reference.from_hex("ab" * 31)
    with pytest.raises(BeeLengthMismatchError):
        Reference.from_hex("ab" * 48)


def test_identifier_from_string_is_keccak256_utf8() -> None:
    # keccak256("hello") (Ethereum keccak, not SHA3-256)
    want = "1c8aff950685c2ed4bc3174f3472287b56d9517b9c948127319a09a7a36deac8"
    assert Identifier.from_string("hello").to_hex() == want


def test_topic_from_string_is_deterministic() -> None:
    a = Topic.from_string("my-topic")
    b = Topic.from_string("my-topic")
    assert a == b
    assert a != Topic.from_string("other")


def test_eth_address_eip55_checksum() -> None:
    raw = "fb6916095ca1df60bb79ce92ce3ea74c37c5d359"
    addr = EthAddress.from_hex(raw)
    assert addr.to_checksum() == "0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359"


def test_span_round_trip_little_endian() -> None:
    for n in (0, 1, 4096, 1 << 40):
        assert Span.from_int(n).to_int() == n
    assert Span.from_int(1).as_bytes() == b"\x01\x00\x00\x00\x00\x00\x00\x00"


def test_feed_index_round_trip_big_endian_and_next() -> None:
    for n in (0, 1, 100, (1 << 32) - 1):
        assert FeedIndex.from_int(n).to_int() == n
    assert FeedIndex.from_int(1).as_bytes() == b"\x00\x00\x00\x00\x00\x00\x00\x01"
    assert FeedIndex.from_int(5).next().to_int() == 6
    assert FeedIndex.MINUS_ONE.next().to_int() == 0


def test_repr_includes_type_name() -> None:
    bid = BatchId(b"\xab" * 32)
    s = repr(bid)
    assert s.startswith("BatchId(")
    assert "ab" * 32 in s


def test_invalid_hex_raises_bee_hex_error() -> None:
    with pytest.raises(BeeHexError):
        BatchId.from_hex("nothex" * 11)  # 66 chars, none valid


def test_distinct_subclasses_with_same_bytes_are_not_equal() -> None:
    raw = b"\x00" * 32
    assert BatchId(raw) != Identifier(raw)
