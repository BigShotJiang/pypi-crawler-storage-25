"""Tests for ``bee.feeds`` — pure helpers + respx-mocked HTTP surface."""

from __future__ import annotations

import httpx
import pytest
import respx

from bee import AsyncBee, Bee
from bee.feeds import (
    FeedUpdate,
    feed_update_chunk_address,
    make_feed_identifier,
)
from bee.swarm import (
    BatchId,
    BeeResponseError,
    EthAddress,
    Identifier,
    PrivateKey,
    Reference,
    Topic,
)
from bee.swarm.bmt import keccak256

BATCH = BatchId(b"\xab" * 32)


def _signer(byte: int) -> PrivateKey:
    return PrivateKey(bytes([byte]) * 32)


# ---- Pure helpers --------------------------------------------------------


def test_make_feed_identifier_matches_keccak_spec() -> None:
    topic = Topic.from_string("hello")
    expected = Identifier(keccak256(topic.as_bytes() + (5).to_bytes(8, "big")))
    assert make_feed_identifier(topic, 5) == expected


def test_make_feed_identifier_index_is_big_endian() -> None:
    topic = Topic.from_string("t")
    a = make_feed_identifier(topic, 1)
    b = make_feed_identifier(topic, 256)
    assert a != b
    # Byte 7 differs by 1 for index 1; byte 6 differs by 1 for index 256.
    raw_a = keccak256(topic.as_bytes() + b"\x00\x00\x00\x00\x00\x00\x00\x01")
    raw_b = keccak256(topic.as_bytes() + b"\x00\x00\x00\x00\x00\x00\x01\x00")
    assert a.as_bytes() == raw_a
    assert b.as_bytes() == raw_b


def test_make_feed_identifier_rejects_out_of_range_index() -> None:
    topic = Topic.from_string("t")
    with pytest.raises(OverflowError):
        make_feed_identifier(topic, 1 << 64)
    with pytest.raises(OverflowError):
        make_feed_identifier(topic, -1)


def test_feed_update_chunk_address_combines_identifier_and_owner() -> None:
    topic = Topic.from_string("t")
    owner = _signer(0x11).public_key().address()
    addr = feed_update_chunk_address(owner, topic, 0)
    ident = make_feed_identifier(topic, 0)
    expected = Reference(keccak256(ident.as_bytes() + owner.as_bytes()))
    assert addr == expected


# ---- HTTP surface (respx-mocked) ----------------------------------------


def _feed_path(owner: EthAddress, topic: Topic) -> str:
    return f"http://localhost:1633/feeds/{owner.to_hex()}/{topic.to_hex()}"


@respx.mock
async def test_async_create_feed_manifest_posts_with_batch_header() -> None:
    pk = _signer(0x33)
    owner = pk.public_key().address()
    topic = Topic.from_string("manifest")
    manifest_ref = Reference(b"\x77" * 32)

    route = respx.post(_feed_path(owner, topic)).mock(
        return_value=httpx.Response(200, json={"reference": manifest_ref.to_hex()})
    )

    async with AsyncBee() as client:
        ref = await client.feeds.create_feed_manifest(BATCH, owner, topic)

    assert ref == manifest_ref
    assert route.calls.last.request.headers["swarm-postage-batch-id"] == "ab" * 32


@respx.mock
async def test_async_get_feed_lookup_decodes_reference() -> None:
    pk = _signer(0x55)
    owner = pk.public_key().address()
    topic = Topic.from_string("lookup")
    manifest_ref = Reference(b"\x44" * 32)

    respx.get(_feed_path(owner, topic)).mock(
        return_value=httpx.Response(200, json={"reference": manifest_ref.to_hex()})
    )

    async with AsyncBee() as client:
        ref = await client.feeds.get_feed_lookup(owner, topic)

    assert ref == manifest_ref


@respx.mock
async def test_async_fetch_latest_decodes_indexes_from_headers() -> None:
    pk = _signer(0x66)
    owner = pk.public_key().address()
    topic = Topic.from_string("fetch")
    payload = (1700000000).to_bytes(8, "big") + b"hello"

    respx.get(_feed_path(owner, topic)).mock(
        return_value=httpx.Response(
            200,
            content=payload,
            headers={
                "swarm-feed-index": (3).to_bytes(8, "big").hex(),
                "swarm-feed-index-next": (4).to_bytes(8, "big").hex(),
            },
        )
    )

    async with AsyncBee() as client:
        update = await client.feeds.fetch_latest(owner, topic)

    assert update == FeedUpdate(payload=payload, index=3, index_next=4)


@respx.mock
async def test_async_find_next_index_returns_zero_for_empty_feed() -> None:
    pk = _signer(0x77)
    owner = pk.public_key().address()
    topic = Topic.from_string("empty")

    respx.get(_feed_path(owner, topic)).mock(return_value=httpx.Response(404))

    async with AsyncBee() as client:
        idx = await client.feeds.find_next_index(owner, topic)

    assert idx == 0


@respx.mock
async def test_async_find_next_index_propagates_other_errors() -> None:
    pk = _signer(0x78)
    owner = pk.public_key().address()
    topic = Topic.from_string("bad")

    respx.get(_feed_path(owner, topic)).mock(return_value=httpx.Response(503))

    async with AsyncBee() as client:
        with pytest.raises(BeeResponseError) as excinfo:
            await client.feeds.find_next_index(owner, topic)

    assert excinfo.value.status == 503


@respx.mock
async def test_async_update_feed_with_index_signs_and_uploads_soc() -> None:
    pk = _signer(0x42)
    owner = pk.public_key().address()
    topic = Topic.from_string("write")
    identifier = make_feed_identifier(topic, 7)
    expected_addr = feed_update_chunk_address(owner, topic, 7)

    soc_path = f"http://localhost:1633/soc/{owner.to_hex()}/{identifier.to_hex()}"
    route = respx.post(soc_path).mock(
        return_value=httpx.Response(200, json={"reference": expected_addr.to_hex()})
    )

    async with AsyncBee() as client:
        result = await client.feeds.update_feed_with_index(BATCH, pk, topic, 7, b"hi")

    assert result.reference == expected_addr
    sent = route.calls.last.request
    # Body is span(8) || payload, where payload starts with an 8-byte timestamp.
    body = sent.content
    assert len(body) == 8 + 8 + 2  # span + timestamp + b"hi"
    assert body[16:] == b"hi"
    assert sent.headers["swarm-postage-batch-id"] == "ab" * 32
    assert sent.url.params["sig"]


@respx.mock
async def test_async_update_feed_uses_find_next_index() -> None:
    pk = _signer(0x12)
    owner = pk.public_key().address()
    topic = Topic.from_string("auto")

    # 1) Empty feed → next=0
    respx.get(_feed_path(owner, topic)).mock(return_value=httpx.Response(404))
    expected_addr = feed_update_chunk_address(owner, topic, 0)
    identifier = make_feed_identifier(topic, 0)
    soc_path = f"http://localhost:1633/soc/{owner.to_hex()}/{identifier.to_hex()}"
    respx.post(soc_path).mock(
        return_value=httpx.Response(200, json={"reference": expected_addr.to_hex()})
    )

    async with AsyncBee() as client:
        result = await client.feeds.update_feed(BATCH, pk, topic, b"first")

    assert result.reference == expected_addr


@respx.mock
async def test_async_is_feed_retrievable_returns_false_on_404() -> None:
    pk = _signer(0x88)
    owner = pk.public_key().address()
    topic = Topic.from_string("gone")

    respx.get(_feed_path(owner, topic)).mock(return_value=httpx.Response(404))

    async with AsyncBee() as client:
        assert await client.feeds.is_feed_retrievable(owner, topic) is False


# ---- Reader / Writer wrappers -------------------------------------------


@respx.mock
async def test_async_writer_round_trips_via_reader() -> None:
    pk = _signer(0xAA)
    owner = pk.public_key().address()
    topic = Topic.from_string("round")

    # find_next_index path: returns index 2 (so next write goes to 3? no:
    # index_next is the *next* slot, so this lookup says "wrote 2 last,
    # next is 3"). Then SOC POST at index 3 succeeds, then a fresh
    # fetch_latest returns the new payload at index 3.
    payload_old = (1).to_bytes(8, "big") + b"old"
    respx.get(_feed_path(owner, topic)).mock(
        return_value=httpx.Response(
            200,
            content=payload_old,
            headers={
                "swarm-feed-index": (2).to_bytes(8, "big").hex(),
                "swarm-feed-index-next": (3).to_bytes(8, "big").hex(),
            },
        )
    )
    addr_3 = feed_update_chunk_address(owner, topic, 3)
    identifier_3 = make_feed_identifier(topic, 3)
    respx.post(
        f"http://localhost:1633/soc/{owner.to_hex()}/{identifier_3.to_hex()}"
    ).mock(return_value=httpx.Response(200, json={"reference": addr_3.to_hex()}))

    async with AsyncBee() as client:
        writer = client.feeds.make_writer(pk, topic)
        result = await writer.upload_payload(BATCH, b"new")
        reader = client.feeds.make_reader(owner, topic)
        # next_index uses fetch_latest's index_next.
        assert await reader.next_index() == 3

    assert result.reference == addr_3
    assert writer.owner == owner
    assert writer.topic == topic


# ---- Sync surface --------------------------------------------------------


@respx.mock
def test_sync_update_feed_with_index_round_trip() -> None:
    pk = _signer(0xCC)
    owner = pk.public_key().address()
    topic = Topic.from_string("sync")
    identifier = make_feed_identifier(topic, 0)
    addr = feed_update_chunk_address(owner, topic, 0)

    respx.post(
        f"http://localhost:1633/soc/{owner.to_hex()}/{identifier.to_hex()}"
    ).mock(return_value=httpx.Response(200, json={"reference": addr.to_hex()}))

    with Bee() as client:
        result = client.feeds.update_feed_with_index(BATCH, pk, topic, 0, b"x")

    assert result.reference == addr
