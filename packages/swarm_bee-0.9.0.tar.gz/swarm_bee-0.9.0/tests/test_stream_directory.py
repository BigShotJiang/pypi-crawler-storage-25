"""Tests for ``client.file.stream_directory`` /
``stream_collection_entries`` / ``save_manifest_recursively``.

These exercise the full streaming path: chunker → bounded-concurrency
chunk uploads → recursive Mantaray persistence. respx mocks the Bee
server's POST /chunks and POST /bytes endpoints.
"""

from __future__ import annotations

import re

import httpx
import pytest
import respx

from bee import AsyncBee, CollectionEntry, CollectionUploadOptions
from bee.file import StreamProgress
from bee.file._stream import total_chunks_for
from bee.swarm import CHUNK_SIZE, BatchId

BATCH = BatchId(b"\xab" * 32)


def _setup_bee_server() -> tuple[list[bytes], list[bytes]]:
    """Mock POST /chunks and POST /bytes; return capture lists."""
    chunks_seen: list[bytes] = []
    bytes_seen: list[bytes] = []

    def chunks_handler(request: httpx.Request) -> httpx.Response:
        body = request.content
        chunks_seen.append(body)
        # Reference is a 32-byte hex of the chunk data — for testing
        # we can use any deterministic 32-byte hex; the real address
        # doesn't matter to stream_directory's logic.
        ref_hex = (b"\xaa" * 32).hex()
        return httpx.Response(200, json={"reference": ref_hex})

    def bytes_handler(request: httpx.Request) -> httpx.Response:
        body = request.content
        bytes_seen.append(body)
        ref_hex = (b"\xbb" * 32).hex()
        return httpx.Response(200, json={"reference": ref_hex})

    respx.post("http://localhost:1633/chunks").mock(side_effect=chunks_handler)
    respx.post("http://localhost:1633/bytes").mock(side_effect=bytes_handler)
    return chunks_seen, bytes_seen


# ---- total_chunks_for ----------------------------------------------------


def test_total_chunks_for_known_sizes() -> None:
    assert total_chunks_for(0) == 0
    assert total_chunks_for(1) == 1
    assert total_chunks_for(CHUNK_SIZE) == 1
    # 4097 bytes → 2 leaves + 1 intermediate
    assert total_chunks_for(CHUNK_SIZE + 1) == 3
    # 128 leaves (one full intermediate level) → 128 + 1
    assert total_chunks_for(CHUNK_SIZE * 128) == 128 + 1
    # 129 leaves → 129 leaves + 2 intermediates + 1 root
    assert total_chunks_for(CHUNK_SIZE * 129) == 129 + 2 + 1


# ---- stream_collection_entries ------------------------------------------


@respx.mock
async def test_stream_collection_entries_uploads_one_chunk_per_small_file() -> None:
    chunks, bzz = _setup_bee_server()
    entries = [
        CollectionEntry("a.txt", b"hello"),
        CollectionEntry("b.txt", b"world"),
    ]
    async with AsyncBee() as client:
        result = await client.file.stream_collection_entries(BATCH, entries)
    # 2 leaf chunks via /chunks (one per file). The Mantaray is
    # walked depth-first; each node and the root all get uploaded
    # via /bytes — exactly how many depends on how the trie chains
    # the prefixes (we only assert the leaf-chunk count is right and
    # that *some* manifest /bytes uploads happened).
    assert len(chunks) == 2
    assert len(bzz) >= 1
    assert result.reference.to_hex() == "bb" * 32


@respx.mock
async def test_stream_collection_entries_progress_callback_fires_per_chunk() -> None:
    _setup_bee_server()
    entries = [CollectionEntry("a.txt", b"hello")]
    seen: list[StreamProgress] = []
    async with AsyncBee() as client:
        await client.file.stream_collection_entries(
            BATCH, entries, on_progress=seen.append
        )
    # One leaf chunk uploaded → one progress event with total=1.
    assert seen == [StreamProgress(total=1, processed=1)]


@respx.mock
async def test_stream_collection_entries_chunks_multi_chunk_file() -> None:
    chunks, bzz = _setup_bee_server()
    big_payload = b"x" * (CHUNK_SIZE * 2 + 100)
    entries = [CollectionEntry("big.bin", big_payload)]
    async with AsyncBee() as client:
        await client.file.stream_collection_entries(BATCH, entries)
    # ceil(8292/4096) = 3 leaves, +1 intermediate → 4 leaf-tree chunks.
    assert len(chunks) == 4
    assert len(bzz) >= 1


@respx.mock
async def test_stream_collection_entries_rejects_empty_file() -> None:
    from bee.swarm import BeeArgumentError

    _setup_bee_server()
    entries = [CollectionEntry("empty", b"")]
    async with AsyncBee() as client:
        with pytest.raises(BeeArgumentError):
            await client.file.stream_collection_entries(BATCH, entries)


@respx.mock
async def test_stream_collection_entries_applies_index_document_metadata() -> None:
    _setup_bee_server()
    entries = [
        CollectionEntry("index.html", b"<html/>"),
        CollectionEntry("readme.txt", b"hi"),
    ]
    async with AsyncBee() as client:
        result = await client.file.stream_collection_entries(BATCH, entries)
    # We can't easily verify the manifest's metadata without parsing
    # it, but this should round-trip with no errors.
    assert result.reference.to_hex() == "bb" * 32


@respx.mock
async def test_stream_collection_entries_explicit_index_and_error_documents() -> None:
    _setup_bee_server()
    entries = [
        CollectionEntry("home.html", b"<html/>"),
        CollectionEntry("404.html", b"<html>404</html>"),
    ]
    async with AsyncBee() as client:
        result = await client.file.stream_collection_entries(
            BATCH,
            entries,
            CollectionUploadOptions(
                index_document="home.html", error_document="404.html"
            ),
        )
    assert result.reference.to_hex() == "bb" * 32


# ---- save_manifest_recursively ------------------------------------------


@respx.mock
async def test_save_manifest_recursively_uploads_root_via_bytes() -> None:
    chunks, bzz = _setup_bee_server()
    from bee.manifest import MantarayNode
    from bee.swarm import Reference

    node = MantarayNode()
    node.add_fork(b"file.txt", Reference(b"\xcd" * 32), None)

    async with AsyncBee() as client:
        result = await client.file.save_manifest_recursively(node, BATCH)

    # Single-node manifest → one POST /bytes; no /chunks calls.
    assert len(chunks) == 0
    assert len(bzz) >= 1  # may be more if forks chain
    assert result.reference.to_hex() == "bb" * 32


# ---- stream_directory (filesystem) --------------------------------------


@respx.mock
async def test_stream_directory_walks_filesystem(tmp_path) -> None:  # type: ignore[no-untyped-def]
    _setup_bee_server()
    (tmp_path / "a.txt").write_bytes(b"hello")
    (tmp_path / "nested").mkdir()
    (tmp_path / "nested" / "b.bin").write_bytes(b"world")

    async with AsyncBee() as client:
        result = await client.file.stream_directory(BATCH, tmp_path)
    assert result.reference.to_hex() == "bb" * 32


# ---- stream_collection_entries calls /chunks with span+payload framing ---


@respx.mock
async def test_stream_chunk_body_is_span_plus_payload() -> None:
    chunks, _ = _setup_bee_server()
    payload = b"hello"
    entries = [CollectionEntry("a.txt", payload)]
    async with AsyncBee() as client:
        await client.file.stream_collection_entries(BATCH, entries)
    # Single small file → one chunk: span(8 LE) + payload bytes.
    assert len(chunks) == 1
    body = chunks[0]
    assert len(body) == 8 + len(payload)
    span_le = int.from_bytes(body[:8], "little")
    assert span_le == len(payload)
    assert body[8:] == payload


# ---- ensure /chunks calls were stamped with the correct batch ------------


@respx.mock
async def test_stream_chunks_carry_postage_batch_id() -> None:
    captured_headers: list[dict[str, str]] = []

    def chunks_handler(request: httpx.Request) -> httpx.Response:
        captured_headers.append(dict(request.headers))
        return httpx.Response(
            200, json={"reference": (b"\xaa" * 32).hex()}
        )

    respx.post("http://localhost:1633/chunks").mock(side_effect=chunks_handler)
    respx.post("http://localhost:1633/bytes").mock(
        return_value=httpx.Response(200, json={"reference": (b"\xbb" * 32).hex()})
    )

    entries = [CollectionEntry("a.txt", b"hi")]
    async with AsyncBee() as client:
        await client.file.stream_collection_entries(BATCH, entries)

    assert captured_headers
    # Header keys are case-insensitive; httpx returns them lower-case.
    h = {k.lower(): v for k, v in captured_headers[0].items()}
    assert h.get("swarm-postage-batch-id") == BATCH.to_hex()


# ---- /bytes upload also carries the batch header ------------------------


@respx.mock
async def test_manifest_bytes_carries_postage_batch_id() -> None:
    _setup_bee_server()
    captured_bytes_headers: list[dict[str, str]] = []

    def bytes_handler(request: httpx.Request) -> httpx.Response:
        captured_bytes_headers.append(dict(request.headers))
        return httpx.Response(
            200, json={"reference": (b"\xbb" * 32).hex()}
        )

    # Override the /bytes mock to capture headers.
    respx.post("http://localhost:1633/bytes").mock(side_effect=bytes_handler)

    entries = [CollectionEntry("a.txt", b"hi")]
    async with AsyncBee() as client:
        await client.file.stream_collection_entries(BATCH, entries)

    assert captured_bytes_headers
    h = {k.lower(): v for k, v in captured_bytes_headers[0].items()}
    assert h.get("swarm-postage-batch-id") == BATCH.to_hex()


# ---- regex-based mock url for verifying chunk count ---------------------


@respx.mock
async def test_chunks_route_is_a_single_endpoint() -> None:
    """All chunk uploads hit the single /chunks endpoint, never a
    per-chunk path."""
    _setup_bee_server()
    entries = [CollectionEntry("a", b"x" * (CHUNK_SIZE * 5))]
    async with AsyncBee() as client:
        await client.file.stream_collection_entries(BATCH, entries)
    # All POSTs should target /chunks (verified by the mock setup
    # above — any other URL would 404 in respx).
    posts = [c for c in respx.calls if re.search(r"/chunks$", str(c.request.url))]
    assert posts  # at least one
