"""Tests for the offline ``hash_collection_entries`` predictor."""

from __future__ import annotations

import pytest

from bee import CollectionEntry
from bee.file import hash_collection_entries
from bee.swarm import MAX_PAYLOAD_SIZE, BeeArgumentError, FileChunker


def test_deterministic_for_same_inputs() -> None:
    a = [CollectionEntry("index.html", b"<html/>")]
    b = [CollectionEntry("index.html", b"<html/>")]
    assert hash_collection_entries(a) == hash_collection_entries(b)


def test_path_change_changes_address() -> None:
    a = [CollectionEntry("index.html", b"x")]
    b = [CollectionEntry("other.html", b"x")]
    assert hash_collection_entries(a) != hash_collection_entries(b)


def test_data_change_changes_address() -> None:
    a = [CollectionEntry("file.txt", b"first")]
    b = [CollectionEntry("file.txt", b"second")]
    assert hash_collection_entries(a) != hash_collection_entries(b)


def test_three_entry_collection_round_trips() -> None:
    entries = [
        CollectionEntry("index.html", b"<html>hi</html>"),
        CollectionEntry("readme.txt", b"hello"),
        CollectionEntry("nested/data.bin", bytes([0, 1, 2, 3])),
    ]
    addr = hash_collection_entries(entries)
    assert len(addr.as_bytes()) == 32


def test_rejects_empty_entry() -> None:
    with pytest.raises(BeeArgumentError):
        hash_collection_entries([CollectionEntry("file", b"")])


def test_handles_max_chunk_sized_entry() -> None:
    entries = [CollectionEntry("max", b"x" * MAX_PAYLOAD_SIZE)]
    addr = hash_collection_entries(entries)
    assert len(addr.as_bytes()) == 32


def test_handles_multi_chunk_entry_via_filechunker() -> None:
    """0.8: multi-chunk entries are chunked through FileChunker; the
    leaf reference inserted into the manifest matches the chunker's
    root."""
    big_payload = b"x" * (MAX_PAYLOAD_SIZE * 2 + 100)
    entries = [CollectionEntry("big.bin", big_payload)]
    addr = hash_collection_entries(entries)
    assert len(addr.as_bytes()) == 32
    # The same content under a different path should produce a
    # different manifest address — confirms the chunker output is
    # being incorporated into the manifest.
    other = [CollectionEntry("other.bin", big_payload)]
    assert addr != hash_collection_entries(other)


def test_multi_chunk_entry_root_matches_filechunker_directly() -> None:
    """The manifest stores FileChunker's root as the leaf reference."""
    chunker = FileChunker()
    payload = b"y" * (MAX_PAYLOAD_SIZE + 500)
    chunker.write(payload)
    expected_root = chunker.finalize().address
    # Round-tripping the same payload via hash_collection_entries
    # should yield a manifest whose only fork's reference equals the
    # chunker's root. We verify indirectly: changing payload by one
    # byte must change the manifest address.
    a = hash_collection_entries([CollectionEntry("f", payload)])
    b = hash_collection_entries([CollectionEntry("f", payload + b"!")])
    assert a != b
    # Sanity: expected_root is the right shape.
    assert len(expected_root.as_bytes()) == 32
