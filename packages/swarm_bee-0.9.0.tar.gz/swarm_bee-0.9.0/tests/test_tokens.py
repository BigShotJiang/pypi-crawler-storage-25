"""Tests for ``bee.swarm.tokens`` — Bzz / Dai fixed-point arithmetic."""

from __future__ import annotations

import math

import pytest

from bee.swarm import Bzz, Dai
from bee.swarm.errors import BeeArgumentError


def test_bzz_from_decimal_truncates_extra_digits() -> None:
    # 17 fractional digits — last is dropped (BZZ has 16).
    b = Bzz.from_decimal_str("1.50000000000000009")
    assert b.to_base_units_string() == "15000000000000000"
    assert b.to_decimal_string() == "1.5000000000000000"


def test_bzz_from_base_units_str_round_trip() -> None:
    b = Bzz.from_base_units_str("12345678901234567890")
    assert b.to_base_units_string() == "12345678901234567890"


def test_bzz_arithmetic_matches_plur() -> None:
    a = Bzz.from_base_units(100)
    b = Bzz.from_base_units(40)
    assert (a + b).to_base_units_string() == "140"
    assert (a - b).to_base_units_string() == "60"


def test_bzz_negative_decimal_round_trip() -> None:
    b = Bzz.from_decimal_str("-2.5")
    assert b.to_decimal_string() == "-2.5000000000000000"


def test_dai_pads_fractional_part_to_eighteen_digits() -> None:
    d = Dai.from_decimal_str("0.5")
    # 0.5 DAI = 5 * 10^17 wei
    assert d.to_base_units_string() == "500000000000000000"
    assert d.to_decimal_string() == "0.500000000000000000"


def test_exchange_to_dai_uses_dai_per_bzz_rate() -> None:
    # Rate: 0.10 DAI per 1 BZZ → 1 BZZ → 0.10 DAI.
    rate = Dai.from_decimal_str("0.10")
    one_bzz = Bzz.from_decimal_str("1")
    got = one_bzz.exchange_to_dai(rate)
    assert got.to_decimal_string() == "0.100000000000000000"


def test_exchange_to_bzz_inverts_rate() -> None:
    # Rate: 0.10 DAI per 1 BZZ → 1 DAI buys 10 BZZ.
    rate = Dai.from_decimal_str("0.10")
    one_dai = Dai.from_decimal_str("1")
    bzz = one_dai.exchange_to_bzz(rate)
    assert bzz.to_decimal_string() == "10.0000000000000000"


def test_exchange_to_bzz_zero_rate_raises() -> None:
    with pytest.raises(BeeArgumentError):
        Dai.from_decimal_str("1").exchange_to_bzz(Dai.from_base_units(0))


def test_cmp_orders_by_base_units() -> None:
    a = Bzz.from_base_units(100)
    b = Bzz.from_base_units(200)
    assert a < b
    assert b > a
    assert a == Bzz.from_base_units(100)


def test_divide_and_times_scale_correctly() -> None:
    a = Bzz.from_base_units(1000)
    assert a.divide(4).to_base_units_string() == "250"
    assert a.times(3).to_base_units_string() == "3000"


def test_to_significant_digits_truncates_only() -> None:
    b = Bzz.from_decimal_str("1.5")
    assert b.to_significant_digits(2) == "1.50"
    # bee-go parity: digits=0 keeps the trailing dot.
    assert b.to_significant_digits(0) == "1."


def test_from_float_strips_trailing_zeros_before_parse() -> None:
    b = Bzz.from_float(0.5)
    assert b.to_decimal_string() == "0.5000000000000000"


def test_rejects_non_finite_floats() -> None:
    with pytest.raises(BeeArgumentError):
        Bzz.from_float(math.nan)
    with pytest.raises(BeeArgumentError):
        Dai.from_float(math.inf)


def test_neg_round_trips() -> None:
    a = Bzz.from_base_units(10)
    assert (-a).to_base_units() == -10


def test_str_renders_as_decimal_string() -> None:
    b = Bzz.from_decimal_str("2.5")
    assert str(b) == "2.5000000000000000"


def test_hash_distinguishes_types_at_same_base_units() -> None:
    # Bzz(1) and Dai(1) should not hash equal — base units carry
    # different meaning.
    assert hash(Bzz.from_base_units(1)) != hash(Dai.from_base_units(1))


def test_eq_rejects_cross_type_comparison() -> None:
    assert (Bzz.from_base_units(1) == Dai.from_base_units(1)) is False
