"""End-to-end tests for ``client.file.upload_soc`` /
``client.file.download_soc`` against respx-mocked Bee responses.

The mock simulates Bee's behavior: an upload returns a JSON
``{reference: …}``, and a follow-up download at the SOC address returns
the wire-form bytes the client originally sent (sans
``identifier|signature`` since that's reconstructed)."""

from __future__ import annotations

import httpx
import respx

from bee import AsyncBee, Bee
from bee.swarm import (
    BatchId,
    Identifier,
    PrivateKey,
    make_single_owner_chunk,
)

BATCH = BatchId(b"\xab" * 32)


def _signer(byte: int) -> PrivateKey:
    return PrivateKey(bytes([byte]) * 32)


@respx.mock
async def test_async_upload_soc_uses_correct_path_and_query() -> None:
    pk = _signer(0x42)
    identifier = Identifier.from_string("topic")
    soc = make_single_owner_chunk(identifier, b"hello soc", pk)

    expected_url = f"http://localhost:1633/soc/{soc.owner.to_hex()}/{identifier.to_hex()}"
    route = respx.post(expected_url).mock(
        return_value=httpx.Response(200, json={"reference": soc.address().to_hex()})
    )

    async with AsyncBee("http://localhost:1633") as client:
        # Body sent to /soc is span || payload (NOT the full SOC wire form;
        # identifier + sig live in the URL).
        body = soc.span.as_bytes() + soc.payload
        result = await client.file.upload_soc(BATCH, soc.owner, identifier, soc.signature, body)

    assert result.reference == soc.address()

    sent = route.calls.last.request
    assert sent.headers["swarm-postage-batch-id"] == "ab" * 32
    assert sent.headers["content-type"] == "application/octet-stream"
    assert sent.url.params["sig"] == soc.signature.to_hex()
    assert sent.content == body


@respx.mock
async def test_async_download_soc_round_trips_via_chunks_endpoint() -> None:
    pk = _signer(0x77)
    identifier = Identifier.from_string("download-topic")
    soc = make_single_owner_chunk(identifier, b"download me", pk)

    addr_hex = soc.address().to_hex()
    respx.get(f"http://localhost:1633/chunks/{addr_hex}").mock(
        return_value=httpx.Response(200, content=soc.data())
    )

    async with AsyncBee() as client:
        parsed = await client.file.download_soc(soc.owner, identifier)

    assert parsed.identifier == soc.identifier
    assert parsed.owner == soc.owner
    assert parsed.payload == b"download me"
    assert parsed.signature == soc.signature


@respx.mock
def test_sync_soc_upload_and_download_round_trip() -> None:
    pk = _signer(0x99)
    identifier = Identifier.from_string("sync-topic")
    soc = make_single_owner_chunk(identifier, b"sync bytes", pk)

    addr_hex = soc.address().to_hex()
    respx.post(f"http://localhost:1633/soc/{soc.owner.to_hex()}/{identifier.to_hex()}").mock(
        return_value=httpx.Response(200, json={"reference": addr_hex})
    )
    respx.get(f"http://localhost:1633/chunks/{addr_hex}").mock(
        return_value=httpx.Response(200, content=soc.data())
    )

    with Bee() as client:
        body = soc.span.as_bytes() + soc.payload
        result = client.file.upload_soc(BATCH, soc.owner, identifier, soc.signature, body)
        parsed = client.file.download_soc(soc.owner, identifier)

    assert result.reference == soc.address()
    assert parsed.payload == b"sync bytes"
