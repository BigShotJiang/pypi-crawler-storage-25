"""Tests for ``client.debug.*`` — the full 0.7 debug surface."""

from __future__ import annotations

import base64
import json

import httpx
import pytest
import respx

from bee import AsyncBee, Bee
from bee.debug import (
    Addresses,
    Balance,
    ChainState,
    Cheque,
    ChequebookBalance,
    LastCheque,
    Logger,
    NodeInfo,
    Peer,
    ReserveState,
    Settlement,
    Settlements,
    TransactionInfo,
    Wallet,
)
from bee.swarm import BeeJsonError, BeeResponseError

# ---- node + chain -------------------------------------------------------


@respx.mock
async def test_async_chain_state_decodes_bigints() -> None:
    respx.get("http://localhost:1633/chainstate").mock(
        return_value=httpx.Response(
            200,
            json={
                "block": 100,
                "chainTip": 105,
                "currentPrice": "12345",
                "totalAmount": "98765",
            },
        )
    )
    async with AsyncBee() as client:
        cs = await client.debug.chain_state()
    assert cs == ChainState(
        block=100, chain_tip=105, current_price=12345, total_amount=98765
    )


@respx.mock
async def test_async_chain_state_empty_bigints_become_zero() -> None:
    respx.get("http://localhost:1633/chainstate").mock(
        return_value=httpx.Response(
            200, json={"block": 1, "chainTip": 1, "currentPrice": "", "totalAmount": ""}
        )
    )
    async with AsyncBee() as client:
        cs = await client.debug.chain_state()
    assert cs.current_price == 0
    assert cs.total_amount == 0


@respx.mock
async def test_async_node_info_round_trip() -> None:
    respx.get("http://localhost:1633/node").mock(
        return_value=httpx.Response(
            200,
            json={"beeMode": "full", "chequebookEnabled": True, "swapEnabled": True},
        )
    )
    async with AsyncBee() as client:
        info = await client.debug.node_info()
    assert info == NodeInfo(bee_mode="full", chequebook_enabled=True, swap_enabled=True)


@respx.mock
async def test_async_status_handles_partial_payload() -> None:
    respx.get("http://localhost:1633/status").mock(
        return_value=httpx.Response(
            200,
            json={"overlay": "abcd", "beeMode": "full", "isReachable": True},
        )
    )
    async with AsyncBee() as client:
        s = await client.debug.status()
    assert s.overlay == "abcd"
    assert s.bee_mode == "full"
    assert s.is_reachable is True
    assert s.connected_peers == 0  # default


@respx.mock
async def test_async_status_peers_carries_request_failed_flag() -> None:
    respx.get("http://localhost:1633/status/peers").mock(
        return_value=httpx.Response(
            200,
            json={
                "snapshots": [
                    {"overlay": "aa", "beeMode": "full"},
                    {"overlay": "bb", "requestFailed": True},
                ]
            },
        )
    )
    async with AsyncBee() as client:
        peers = await client.debug.status_peers()
    assert len(peers) == 2
    assert peers[0].request_failed is False
    assert peers[1].request_failed is True


@respx.mock
async def test_async_readiness_translates_503_to_false() -> None:
    respx.get("http://localhost:1633/readiness").mock(return_value=httpx.Response(503))
    async with AsyncBee() as client:
        assert await client.debug.readiness() is False


@respx.mock
async def test_async_is_gateway_404_to_false() -> None:
    respx.get("http://localhost:1633/gateway").mock(return_value=httpx.Response(404))
    async with AsyncBee() as client:
        assert await client.debug.is_gateway() is False


@respx.mock
async def test_async_is_gateway_returns_payload() -> None:
    respx.get("http://localhost:1633/gateway").mock(
        return_value=httpx.Response(200, json={"gateway": True})
    )
    async with AsyncBee() as client:
        assert await client.debug.is_gateway() is True


@respx.mock
async def test_async_is_connected_handles_failure() -> None:
    respx.get("http://localhost:1633/").mock(side_effect=httpx.ConnectError("nope"))
    async with AsyncBee() as client:
        assert await client.debug.is_connected() is False


# ---- accounting + stake -------------------------------------------------


@respx.mock
async def test_async_balances_decodes_list() -> None:
    respx.get("http://localhost:1633/balances").mock(
        return_value=httpx.Response(
            200,
            json={
                "balances": [
                    {"peer": "aa", "balance": "100"},
                    {"peer": "bb", "balance": "-50"},
                ]
            },
        )
    )
    async with AsyncBee() as client:
        bs = await client.debug.balances()
    assert bs == [Balance(peer="aa", balance=100), Balance(peer="bb", balance=-50)]


@respx.mock
async def test_async_peer_balance_round_trip() -> None:
    respx.get("http://localhost:1633/balances/aa").mock(
        return_value=httpx.Response(200, json={"peer": "aa", "balance": "42"})
    )
    async with AsyncBee() as client:
        b = await client.debug.peer_balance("aa")
    assert b == Balance(peer="aa", balance=42)


@respx.mock
async def test_async_accounting_decodes_optional_bigints() -> None:
    respx.get("http://localhost:1633/accounting").mock(
        return_value=httpx.Response(
            200,
            json={
                "peerData": {
                    "aa": {"balance": "100", "consumedBalance": ""},
                    "bb": {"surplusBalance": "5", "balance": "0"},
                }
            },
        )
    )
    async with AsyncBee() as client:
        acc = await client.debug.accounting()
    assert acc["aa"].balance == 100
    assert acc["aa"].consumed_balance is None  # empty string → None
    assert acc["bb"].surplus_balance == 5
    assert acc["bb"].balance == 0


@respx.mock
async def test_async_stake_returns_int() -> None:
    respx.get("http://localhost:1633/stake").mock(
        return_value=httpx.Response(200, json={"stakedAmount": "1000000"})
    )
    async with AsyncBee() as client:
        s = await client.debug.stake()
    assert s == 1_000_000


@respx.mock
async def test_async_deposit_stake_returns_tx_hash() -> None:
    route = respx.post("http://localhost:1633/stake/500").mock(
        return_value=httpx.Response(200, json={"txHash": "0xabc"})
    )
    async with AsyncBee() as client:
        h = await client.debug.deposit_stake(500)
    assert h == "0xabc"
    assert route.called


@respx.mock
async def test_async_redistribution_state_round_trip() -> None:
    respx.get("http://localhost:1633/redistributionstate").mock(
        return_value=httpx.Response(
            200,
            json={
                "isFrozen": False,
                "isFullySynced": True,
                "phase": "claim",
                "round": 12,
                "lastSampleDurationSeconds": 37.96,
                "reward": "1000",
            },
        )
    )
    async with AsyncBee() as client:
        rs = await client.debug.redistribution_state()
    assert rs.phase == "claim"
    assert rs.round == 12
    assert rs.is_fully_synced is True
    assert rs.last_sample_duration_seconds == pytest.approx(37.96)
    assert rs.reward == 1000


# ---- chequebook + settlements + wallet ----------------------------------


@respx.mock
async def test_async_wallet_accepts_legacy_chequebook_key() -> None:
    respx.get("http://localhost:1633/wallet").mock(
        return_value=httpx.Response(
            200,
            json={
                "chequebook": "0xCB",  # legacy key
                "bzzBalance": "1000",
                "nativeTokenBalance": "5",
                "chainID": 100,
                "walletAddress": "0xWAL",
            },
        )
    )
    async with AsyncBee() as client:
        w = await client.debug.wallet()
    assert w.chequebook_contract_address == "0xCB"
    assert w.bzz_balance == 1000
    assert w.native_token_balance == 5
    assert w.chain_id == 100


@respx.mock
async def test_async_wallet_prefers_new_key() -> None:
    respx.get("http://localhost:1633/wallet").mock(
        return_value=httpx.Response(
            200,
            json={
                "chequebook": "0xOLD",
                "chequebookContractAddress": "0xNEW",
                "chainID": 100,
                "walletAddress": "0xWAL",
            },
        )
    )
    async with AsyncBee() as client:
        w = await client.debug.wallet()
    assert w.chequebook_contract_address == "0xNEW"


@respx.mock
async def test_async_chequebook_balance() -> None:
    respx.get("http://localhost:1633/chequebook/balance").mock(
        return_value=httpx.Response(
            200, json={"totalBalance": "100", "availableBalance": "60"}
        )
    )
    async with AsyncBee() as client:
        cb = await client.debug.chequebook_balance()
    assert cb == ChequebookBalance(total_balance=100, available_balance=60)


@respx.mock
async def test_async_chequebook_deposit_passes_amount_query() -> None:
    route = respx.post("http://localhost:1633/chequebook/deposit").mock(
        return_value=httpx.Response(200, json={"transactionHash": "0xdead"})
    )
    async with AsyncBee() as client:
        h = await client.debug.chequebook_deposit(1234)
    assert h == "0xdead"
    assert route.calls.last.request.url.params["amount"] == "1234"


@respx.mock
async def test_async_last_cheques_decodes_list() -> None:
    respx.get("http://localhost:1633/chequebook/cheque").mock(
        return_value=httpx.Response(
            200,
            json={
                "lastcheques": [
                    {
                        "peer": "aa",
                        "lastreceived": {
                            "beneficiary": "0xBEN",
                            "chequebook": "0xCB",
                            "payout": "100",
                        },
                    },
                    {"peer": "bb"},
                ]
            },
        )
    )
    async with AsyncBee() as client:
        cheques = await client.debug.last_cheques()
    assert cheques[0].peer == "aa"
    assert cheques[0].last_received == Cheque(
        beneficiary="0xBEN", chequebook="0xCB", payout=100
    )
    assert cheques[1] == LastCheque(peer="bb", last_received=None)


@respx.mock
async def test_async_cashout_last_cheque_with_gas_price() -> None:
    route = respx.post("http://localhost:1633/chequebook/cashout/aa").mock(
        return_value=httpx.Response(200, json={"transactionHash": "0xbeef"})
    )
    async with AsyncBee() as client:
        await client.debug.cashout_last_cheque("aa", gas_price=1234567890)
    assert route.calls.last.request.headers["gas-price"] == "1234567890"


@respx.mock
async def test_async_settlements_round_trip() -> None:
    respx.get("http://localhost:1633/settlements").mock(
        return_value=httpx.Response(
            200,
            json={
                "totalReceived": "100",
                "totalSent": "50",
                "settlements": [
                    {"peer": "aa", "received": "100", "sent": "50"},
                ],
            },
        )
    )
    async with AsyncBee() as client:
        s = await client.debug.settlements()
    assert s == Settlements(
        total_received=100,
        total_sent=50,
        settlements=[Settlement(peer="aa", received=100, sent=50)],
    )


# ---- peers + topology ---------------------------------------------------


@respx.mock
async def test_async_peers_decodes_list() -> None:
    respx.get("http://localhost:1633/peers").mock(
        return_value=httpx.Response(
            200, json={"peers": [{"address": "aa", "fullNode": True}]}
        )
    )
    async with AsyncBee() as client:
        peers = await client.debug.peers()
    assert peers == [Peer(address="aa", full_node=True)]


@respx.mock
async def test_async_ping_peer_returns_rtt() -> None:
    respx.post("http://localhost:1633/pingpong/aa").mock(
        return_value=httpx.Response(200, json={"rtt": "2.5ms"})
    )
    async with AsyncBee() as client:
        rtt = await client.debug.ping_peer("aa")
    assert rtt == "2.5ms"


@respx.mock
async def test_async_connect_peer_strips_leading_slash() -> None:
    route = respx.post(
        "http://localhost:1633/connect/dns/bee.example/tcp/1634"
    ).mock(return_value=httpx.Response(200, json={"address": "abcd"}))
    async with AsyncBee() as client:
        addr = await client.debug.connect_peer("/dns/bee.example/tcp/1634")
    assert addr == "abcd"
    assert route.called


@respx.mock
async def test_async_addresses_decodes_underlay_list() -> None:
    respx.get("http://localhost:1633/addresses").mock(
        return_value=httpx.Response(
            200,
            json={
                "overlay": "aa",
                "underlay": ["/ip4/1.2.3.4"],
                "ethereum": "0xeth",
                "publicKey": "0xpk",
                "pssPublicKey": "0xpss",
            },
        )
    )
    async with AsyncBee() as client:
        a = await client.debug.addresses()
    assert a == Addresses(
        overlay="aa",
        underlay=["/ip4/1.2.3.4"],
        ethereum="0xeth",
        public_key="0xpk",
        pss_public_key="0xpss",
    )


@respx.mock
async def test_async_topology_collapses_bin_keys() -> None:
    payload: dict[str, object] = {
        "baseAddr": "aa",
        "population": 1,
        "depth": 4,
    }
    payload["bin_3"] = {"population": 5, "connected": 2}
    respx.get("http://localhost:1633/topology").mock(
        return_value=httpx.Response(200, json=payload)
    )
    async with AsyncBee() as client:
        t = await client.debug.topology()
    assert t.base_addr == "aa"
    assert len(t.bins) == 32
    assert t.bins[3].population == 5
    assert t.bins[3].connected == 2
    assert t.bins[0].population == 0  # missing → default


@respx.mock
async def test_async_topology_handles_null_peer_lists() -> None:
    payload: dict[str, object] = {"baseAddr": "aa", "depth": 0}
    payload["bin_0"] = {
        "population": 0,
        "connected": 0,
        "connectedPeers": None,
        "disconnectedPeers": None,
    }
    respx.get("http://localhost:1633/topology").mock(
        return_value=httpx.Response(200, json=payload)
    )
    async with AsyncBee() as client:
        t = await client.debug.topology()
    assert t.bins[0].connected_peers == []
    assert t.bins[0].disconnected_peers == []


@respx.mock
async def test_async_reserve_state_round_trip() -> None:
    respx.get("http://localhost:1633/reservestate").mock(
        return_value=httpx.Response(
            200, json={"radius": 8, "storageRadius": 8, "commitment": 1024}
        )
    )
    async with AsyncBee() as client:
        rs = await client.debug.reserve_state()
    assert rs == ReserveState(radius=8, storage_radius=8, commitment=1024)


@respx.mock
async def test_async_welcome_message_get_set() -> None:
    respx.get("http://localhost:1633/welcome-message").mock(
        return_value=httpx.Response(200, json={"welcomeMessage": "hi"})
    )
    set_route = respx.post("http://localhost:1633/welcome-message").mock(
        return_value=httpx.Response(200)
    )
    async with AsyncBee() as client:
        msg = await client.debug.welcome_message()
        await client.debug.set_welcome_message("howdy")
    assert msg == "hi"
    body = json.loads(set_route.calls.last.request.content)
    assert body == {"welcomeMessage": "howdy"}


# ---- transactions -------------------------------------------------------


@respx.mock
async def test_async_pending_transactions_round_trip() -> None:
    respx.get("http://localhost:1633/transactions").mock(
        return_value=httpx.Response(
            200,
            json={
                "pendingTransactions": [
                    {
                        "transactionHash": "0xa",
                        "to": "0xb",
                        "nonce": 1,
                        "gasPrice": "100",
                        "gasLimit": 21000,
                        "value": "5",
                    },
                ]
            },
        )
    )
    async with AsyncBee() as client:
        txs = await client.debug.pending_transactions()
    assert txs == [
        TransactionInfo(
            transaction_hash="0xa",
            to="0xb",
            nonce=1,
            gas_price=100,
            gas_limit=21000,
            value=5,
        )
    ]


@respx.mock
async def test_async_cancel_transaction_with_gas_price_header() -> None:
    route = respx.delete("http://localhost:1633/transactions/0xa").mock(
        return_value=httpx.Response(200, json={"transactionHash": "0xb"})
    )
    async with AsyncBee() as client:
        h = await client.debug.cancel_transaction("0xa", gas_price=999)
    assert h == "0xb"
    assert route.calls.last.request.headers["gas-price"] == "999"


# ---- loggers ------------------------------------------------------------


@respx.mock
async def test_async_loggers_round_trip() -> None:
    respx.get("http://localhost:1633/loggers").mock(
        return_value=httpx.Response(
            200,
            json={
                "loggers": [
                    {
                        "logger": "x",
                        "verbosity": "info",
                        "subsystem": "y",
                        "id": "id1",
                    }
                ]
            },
        )
    )
    async with AsyncBee() as client:
        listing = await client.debug.loggers()
    assert listing.loggers == [
        Logger(logger="x", verbosity="info", subsystem="y", id="id1")
    ]


@respx.mock
async def test_async_loggers_by_expression_base64_encodes() -> None:
    expr = "node/.*"
    encoded = base64.b64encode(expr.encode("utf-8")).decode("ascii")
    route = respx.get(f"http://localhost:1633/loggers/{encoded}").mock(
        return_value=httpx.Response(200, json={"loggers": []})
    )
    async with AsyncBee() as client:
        await client.debug.loggers_by_expression(expr)
    assert route.called


@respx.mock
async def test_async_set_logger_verbosity_uses_put_with_b64() -> None:
    expr = "swarm/.*=debug"
    encoded = base64.b64encode(expr.encode("utf-8")).decode("ascii")
    route = respx.put(f"http://localhost:1633/loggers/{encoded}").mock(
        return_value=httpx.Response(200)
    )
    async with AsyncBee() as client:
        await client.debug.set_logger_verbosity(expr)
    assert route.called


# ---- error decoding -----------------------------------------------------


@respx.mock
async def test_async_chain_state_invalid_bigint_surfaces_json_error() -> None:
    respx.get("http://localhost:1633/chainstate").mock(
        return_value=httpx.Response(
            200,
            json={
                "block": 1,
                "chainTip": 1,
                "currentPrice": "not-a-number",
                "totalAmount": "0",
            },
        )
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeJsonError):
            await client.debug.chain_state()


@respx.mock
async def test_async_health_invalid_payload_surfaces_json_error() -> None:
    respx.get("http://localhost:1633/health").mock(
        return_value=httpx.Response(200, json={"foo": "bar"})
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeJsonError):
            await client.debug.health()


@respx.mock
async def test_async_balances_propagates_500() -> None:
    respx.get("http://localhost:1633/balances").mock(return_value=httpx.Response(500))
    async with AsyncBee() as client:
        with pytest.raises(BeeResponseError):
            await client.debug.balances()


# ---- sync surface --------------------------------------------------------


@respx.mock
def test_sync_balances_round_trip() -> None:
    respx.get("http://localhost:1633/balances").mock(
        return_value=httpx.Response(
            200, json={"balances": [{"peer": "aa", "balance": "1"}]}
        )
    )
    with Bee() as client:
        bs = client.debug.balances()
    assert bs == [Balance(peer="aa", balance=1)]


@respx.mock
def test_sync_wallet_round_trip() -> None:
    respx.get("http://localhost:1633/wallet").mock(
        return_value=httpx.Response(
            200, json={"chequebookContractAddress": "0xCB", "chainID": 100, "walletAddress": "0xW"}
        )
    )
    with Bee() as client:
        w = client.debug.wallet()
    assert isinstance(w, Wallet)
    assert w.chequebook_contract_address == "0xCB"


@respx.mock
def test_sync_loggers_set_verbosity() -> None:
    expr = "x"
    encoded = base64.b64encode(expr.encode("utf-8")).decode("ascii")
    route = respx.put(f"http://localhost:1633/loggers/{encoded}").mock(
        return_value=httpx.Response(200)
    )
    with Bee() as client:
        client.debug.set_logger_verbosity(expr)
    assert route.called
