"""End-to-end tests for ``client.file.upload_chunk`` / ``download_chunk``
against respx-mocked Bee responses, plus a BMT integration check."""

from __future__ import annotations

import httpx
import pytest
import respx

from bee import AsyncBee, Bee, BeeResponseError, UploadOptions
from bee.swarm import BatchId, Reference, make_content_addressed_chunk

BATCH = BatchId(b"\xab" * 32)


@respx.mock
async def test_async_upload_chunk_uses_post_chunks() -> None:
    """A locally-computed BMT address should round-trip back from
    Bee unchanged (i.e. the wire body is exactly ``span || payload``)."""
    chunk = make_content_addressed_chunk(b"hello world")
    expected_hex = chunk.address.to_hex()

    route = respx.post("http://localhost:1633/chunks").mock(
        return_value=httpx.Response(200, json={"reference": expected_hex})
    )

    async with AsyncBee("http://localhost:1633") as client:
        result = await client.file.upload_chunk(BATCH, chunk.data())

    assert result.reference == chunk.address
    sent = route.calls.last.request
    assert sent.headers["swarm-postage-batch-id"] == "ab" * 32
    assert sent.headers["content-type"] == "application/octet-stream"
    assert sent.content == chunk.data()


@respx.mock
async def test_async_upload_chunk_includes_pin_header() -> None:
    chunk = make_content_addressed_chunk(b"data")
    route = respx.post("http://localhost:1633/chunks").mock(
        return_value=httpx.Response(200, json={"reference": chunk.address.to_hex()})
    )
    async with AsyncBee() as client:
        await client.file.upload_chunk(BATCH, chunk.data(), UploadOptions(pin=True))
    assert route.calls.last.request.headers["swarm-pin"] == "true"


@respx.mock
async def test_async_download_chunk_returns_wire_bytes() -> None:
    chunk = make_content_addressed_chunk(b"chunked")
    respx.get(f"http://localhost:1633/chunks/{chunk.address.to_hex()}").mock(
        return_value=httpx.Response(200, content=chunk.data())
    )
    async with AsyncBee() as client:
        body = await client.file.download_chunk(chunk.address)
    assert body == chunk.data()
    assert body[:8] == chunk.span.as_bytes()
    assert body[8:] == b"chunked"


@respx.mock
async def test_async_download_chunk_404_surfaces_response_error() -> None:
    ref = Reference.from_hex("00" * 32)
    respx.get(f"http://localhost:1633/chunks/{ref.to_hex()}").mock(
        return_value=httpx.Response(404, content=b"not found")
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeResponseError) as ei:
            await client.file.download_chunk(ref)
    assert ei.value.status == 404


@respx.mock
def test_sync_chunk_round_trip_via_bmt_address() -> None:
    chunk = make_content_addressed_chunk(b"sync chunk")
    expected_hex = chunk.address.to_hex()

    respx.post("http://localhost:1633/chunks").mock(
        return_value=httpx.Response(200, json={"reference": expected_hex})
    )
    respx.get(f"http://localhost:1633/chunks/{expected_hex}").mock(
        return_value=httpx.Response(200, content=chunk.data())
    )

    with Bee() as client:
        result = client.file.upload_chunk(BATCH, chunk.data())
        body = client.file.download_chunk(result.reference)

    assert result.reference == chunk.address
    assert body == chunk.data()
