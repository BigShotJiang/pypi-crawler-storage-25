"""Tests for ``bee.swarm.Size``."""

from __future__ import annotations

import math

import pytest

from bee.swarm import Size
from bee.swarm.errors import BeeArgumentError
from bee.swarm.size import GB, KB, MB


def test_from_bytes_rounds_up() -> None:
    assert Size.from_bytes(10.4).to_bytes() == 11
    assert Size.from_bytes(0).to_bytes() == 0


def test_from_kilobytes_uses_decimal_base() -> None:
    s = Size.from_kilobytes(1.5)
    assert s.to_bytes() == 1500


def test_from_megabytes_to_kilobytes_round_trip() -> None:
    s = Size.from_megabytes(2)
    assert s.to_kilobytes() == pytest.approx(2_000.0)


def test_parse_compound() -> None:
    s = Size.parse("1gb256mb")
    assert s.to_bytes() == GB + 256 * MB


def test_parse_handles_whitespace_and_mixed_case() -> None:
    s = Size.parse("  512 kB  ")
    assert s.to_bytes() == 512 * KB


def test_parse_decimal_value() -> None:
    s = Size.parse("1.5gb")
    assert s.to_bytes() == math.ceil(1.5 * GB)


def test_parse_rejects_empty() -> None:
    with pytest.raises(BeeArgumentError):
        Size.parse("")
    with pytest.raises(BeeArgumentError):
        Size.parse("   ")


def test_parse_rejects_unknown_unit() -> None:
    with pytest.raises(BeeArgumentError):
        Size.parse("2pb")


def test_negative_or_nan_rejected() -> None:
    with pytest.raises(BeeArgumentError):
        Size.from_bytes(-1)
    with pytest.raises(BeeArgumentError):
        Size.from_bytes(math.nan)


def test_str_auto_scales() -> None:
    assert str(Size.from_bytes(1)) == "1 B"
    assert str(Size.from_kilobytes(1.5)) == "1.50 kB"
    assert str(Size.from_megabytes(28)) == "28.00 MB"
    assert str(Size.from_gigabytes(1)) == "1.00 GB"
    assert str(Size.from_terabytes(2)) == "2.00 TB"


def test_orders_by_bytes() -> None:
    a = Size.from_megabytes(1)
    b = Size.from_megabytes(2)
    assert a < b
    assert hash(a) != hash(b)
    assert Size.from_megabytes(1) == a
