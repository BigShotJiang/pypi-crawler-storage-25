"""Tests for ``bee.swarm.Network``."""

from __future__ import annotations

from bee.swarm import Network


def test_block_times_match_chain() -> None:
    assert Network.MAINNET.block_time_seconds() == 15
    assert Network.GNOSIS.block_time_seconds() == 5


def test_seconds_to_blocks_rounds_up() -> None:
    assert Network.GNOSIS.seconds_to_blocks(0) == 0
    assert Network.GNOSIS.seconds_to_blocks(1) == 1
    assert Network.GNOSIS.seconds_to_blocks(5) == 1
    assert Network.GNOSIS.seconds_to_blocks(6) == 2
    assert Network.MAINNET.seconds_to_blocks(60) == 4
    assert Network.MAINNET.seconds_to_blocks(61) == 5


def test_blocks_to_seconds_round_trip() -> None:
    assert Network.GNOSIS.blocks_to_seconds(12) == 60
    assert Network.MAINNET.blocks_to_seconds(4) == 60
