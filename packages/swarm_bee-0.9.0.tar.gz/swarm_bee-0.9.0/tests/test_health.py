"""End-to-end test for ``client.debug.health()`` against a respx mock."""

from __future__ import annotations

import httpx
import pytest
import respx

from bee import AsyncBee, Bee, BeeJsonError, BeeResponseError
from bee.debug import SUPPORTED_API_VERSION


@respx.mock
async def test_async_health_returns_parsed_payload() -> None:
    respx.get("http://localhost:1633/health").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "ok",
                "version": "2.7.2-rc1-83612d37",
                "apiVersion": "8.0.0",
            },
        )
    )

    async with AsyncBee("http://localhost:1633") as client:
        h = await client.debug.health()

    assert h.status == "ok"
    assert h.version == "2.7.2-rc1-83612d37"
    assert h.api_version == "8.0.0"


@respx.mock
async def test_async_is_supported_api_version_compares_field() -> None:
    respx.get("http://localhost:1633/health").mock(
        return_value=httpx.Response(
            200,
            json={"status": "ok", "version": "2.7.2", "apiVersion": SUPPORTED_API_VERSION},
        )
    )
    async with AsyncBee() as client:
        assert await client.debug.is_supported_api_version()


@respx.mock
async def test_async_response_error_captures_status_and_body() -> None:
    respx.get("http://localhost:1633/health").mock(
        return_value=httpx.Response(503, content=b"down for maintenance"),
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeResponseError) as ei:
            await client.debug.health()
    assert ei.value.status == 503
    assert ei.value.body == b"down for maintenance"
    assert ei.value.method == "GET"


@respx.mock
async def test_async_json_error_on_invalid_payload() -> None:
    respx.get("http://localhost:1633/health").mock(
        return_value=httpx.Response(200, content=b"not json")
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeJsonError):
            await client.debug.health()


@respx.mock
def test_sync_health_returns_parsed_payload() -> None:
    respx.get("http://localhost:1633/health").mock(
        return_value=httpx.Response(
            200,
            json={"status": "ok", "version": "2.7.2", "apiVersion": "8.0.0"},
        )
    )

    with Bee("http://localhost:1633") as client:
        h = client.debug.health()

    assert h.status == "ok"
    assert h.api_version == "8.0.0"


def test_base_url_is_normalized() -> None:
    assert Bee("http://localhost:1633/").base_url == "http://localhost:1633"
    assert AsyncBee("http://localhost:1633//").base_url == "http://localhost:1633"
