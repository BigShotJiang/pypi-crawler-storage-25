"""Tests for ``bee.swarm.gsoc`` (proximity + mining) and
``bee.gsoc`` (HTTP send / soc_address)."""

from __future__ import annotations

import httpx
import pytest
import respx

from bee import AsyncBee, Bee
from bee.gsoc import soc_address
from bee.swarm import (
    BatchId,
    Identifier,
    PrivateKey,
    calculate_single_owner_chunk_address,
    gsoc_mine,
    make_single_owner_chunk,
    proximity,
)
from bee.swarm.errors import BeeArgumentError

BATCH = BatchId(b"\xab" * 32)


def _signer(byte: int) -> PrivateKey:
    return PrivateKey(bytes([byte]) * 32)


# ---- proximity -----------------------------------------------------------


def test_proximity_zero_for_max_diff() -> None:
    a = b"\x00" * 32
    b = b"\xff" + b"\x00" * 31
    assert proximity(a, b) == 0


def test_proximity_full_for_equal() -> None:
    a = b"\x42" * 32
    assert proximity(a, a) == 8 * 32


def test_proximity_counts_leading_common_bits() -> None:
    a = b"\xff" * 32
    b = bytes([0xFE]) + a[1:]  # first 7 bits common, 8th differs
    assert proximity(a, b) == 7


def test_proximity_returns_zero_for_length_mismatch() -> None:
    assert proximity(b"\x00" * 16, b"\x00" * 32) == 0


# ---- gsoc_mine -----------------------------------------------------------


def test_gsoc_mine_finds_low_proximity_key_quickly() -> None:
    target = b"\xaa" * 32
    identifier = Identifier.from_string("test")
    key = gsoc_mine(target, identifier, target_proximity=0)
    # Sanity: key is valid (derives a public key + address).
    assert key.public_key().address() is not None


def test_gsoc_mine_rejects_wrong_target_length() -> None:
    identifier = Identifier.from_string("x")
    with pytest.raises(BeeArgumentError):
        gsoc_mine(b"\x00" * 31, identifier, 1)


def test_gsoc_mine_address_meets_proximity() -> None:
    target = b"\xff" * 32
    identifier = Identifier.from_string("proxim")
    key = gsoc_mine(target, identifier, target_proximity=4)
    addr = soc_address(identifier, key.public_key().address())
    assert proximity(addr.as_bytes(), target) >= 4


# ---- soc_address ---------------------------------------------------------


def test_soc_address_matches_calculate_helper() -> None:
    pk = _signer(0x11)
    owner = pk.public_key().address()
    identifier = Identifier.from_string("hello")
    assert soc_address(identifier, owner) == calculate_single_owner_chunk_address(
        identifier, owner
    )


# ---- HTTP surface (respx) ------------------------------------------------


@respx.mock
async def test_async_gsoc_send_uploads_signed_soc() -> None:
    pk = _signer(0x42)
    identifier = Identifier.from_string("gsoc")
    soc = make_single_owner_chunk(identifier, b"hello gsoc", pk)

    expected_url = (
        f"http://localhost:1633/soc/{soc.owner.to_hex()}/{identifier.to_hex()}"
    )
    route = respx.post(expected_url).mock(
        return_value=httpx.Response(200, json={"reference": soc.address().to_hex()})
    )

    async with AsyncBee() as client:
        result = await client.gsoc.send(BATCH, pk, identifier, b"hello gsoc")

    assert result.reference == soc.address()
    sent = route.calls.last.request
    assert sent.headers["swarm-postage-batch-id"] == "ab" * 32
    assert sent.url.params["sig"] == soc.signature.to_hex()


@respx.mock
def test_sync_gsoc_send_uploads_signed_soc() -> None:
    pk = _signer(0x43)
    identifier = Identifier.from_string("sync-gsoc")
    soc = make_single_owner_chunk(identifier, b"sync gsoc", pk)

    respx.post(
        f"http://localhost:1633/soc/{soc.owner.to_hex()}/{identifier.to_hex()}"
    ).mock(return_value=httpx.Response(200, json={"reference": soc.address().to_hex()}))

    with Bee() as client:
        result = client.gsoc.send(BATCH, pk, identifier, b"sync gsoc")

    assert result.reference == soc.address()
