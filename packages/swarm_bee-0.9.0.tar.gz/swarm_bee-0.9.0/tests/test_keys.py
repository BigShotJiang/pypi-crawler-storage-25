"""Tests for ``bee.swarm.keys`` (PrivateKey, PublicKey, sign + recover)."""

from __future__ import annotations

import pytest

from bee.swarm import (
    BeeCryptoError,
    BeeLengthMismatchError,
    EthAddress,
    PrivateKey,
    PublicKey,
    Signature,
    eth_signed_message_digest,
    keccak256,
    recover_public_key,
    verify_signature,
)


def _priv(byte: int) -> PrivateKey:
    return PrivateKey(bytes([byte]) * 32)


def test_private_key_rejects_wrong_length() -> None:
    with pytest.raises(BeeLengthMismatchError):
        PrivateKey(b"\x00" * 31)


def test_private_to_public_to_address_is_deterministic() -> None:
    pk = _priv(0x11)
    a = pk.public_key()
    b = pk.public_key()
    assert a.as_bytes() == b.as_bytes()
    assert a.address() == b.address()
    assert len(a.as_bytes()) == 64
    assert len(a.address().as_bytes()) == 20


def test_public_key_compressed_round_trip() -> None:
    pk = _priv(0x22)
    full = pk.public_key()
    compressed = full.compressed_bytes()
    assert len(compressed) == 33
    rebuilt = PublicKey(compressed)
    assert rebuilt.as_bytes() == full.as_bytes()
    # Hex form of compressed encoding round-trips too.
    rebuilt2 = PublicKey.from_hex(full.compressed_hex())
    assert rebuilt2.as_bytes() == full.as_bytes()


def test_public_key_rejects_invalid_length() -> None:
    with pytest.raises(BeeLengthMismatchError):
        PublicKey(b"\x00" * 50)


def test_sign_recover_round_trip() -> None:
    pk = _priv(0x33)
    data = b"hello swarm"
    sig = pk.sign(data)
    assert isinstance(sig, Signature)

    # V is normalized to {27, 28} per bee-js wire format.
    v = sig.as_bytes()[64]
    assert v in (27, 28), f"V was {v}"

    recovered = recover_public_key(sig, data)
    assert recovered.as_bytes() == pk.public_key().as_bytes()

    addr = pk.public_key().address()
    assert verify_signature(sig, data, addr)
    assert not verify_signature(sig, b"tampered", addr)


def test_verify_returns_false_on_garbage_signature() -> None:
    addr = EthAddress(b"\x00" * 20)
    bogus = Signature(b"\x00" * 65)
    assert verify_signature(bogus, b"data", addr) is False


def test_repr_does_not_leak_private_bytes() -> None:
    pk = _priv(0x44)
    s = repr(pk)
    assert "44" not in s
    assert "redacted" in s


def test_zeroize_clears_private_bytes() -> None:
    pk = _priv(0x55)
    assert pk.as_bytes() == b"\x55" * 32
    pk.zeroize()
    assert pk.as_bytes() == b"\x00" * 32


def test_private_key_eq_is_constant_time_and_correct() -> None:
    a = _priv(0x66)
    b = _priv(0x66)
    c = _priv(0x77)
    assert a == b
    assert a != c
    # Stable hash so PrivateKey can live in a set; equality forces
    # constant-time comparison.
    assert hash(a) == hash(b) == hash(c) == 0


def test_eth_signed_message_digest_matches_construction() -> None:
    data = b"some payload"
    inner = keccak256(data)
    expected = keccak256(b"\x19Ethereum Signed Message:\n32" + inner)
    assert eth_signed_message_digest(data) == expected
    assert len(expected) == 32


def test_recover_public_key_rejects_invalid_v() -> None:
    sig = Signature(b"\x00" * 64 + b"\x05")  # V=5, not 0/1/27/28
    with pytest.raises(BeeCryptoError):
        recover_public_key(sig, b"data")
