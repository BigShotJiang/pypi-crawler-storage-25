"""Tests for ``bee.swarm.Duration``."""

from __future__ import annotations

import datetime
import math

import pytest

from bee.swarm import Duration
from bee.swarm.duration import (
    SECONDS_IN_DAY,
    SECONDS_IN_HOUR,
    SECONDS_IN_MINUTE,
)
from bee.swarm.errors import BeeArgumentError


def test_negative_or_nan_clamps_to_zero() -> None:
    assert Duration.from_seconds(-1.0).to_seconds() == 0
    assert Duration.from_seconds(math.nan).to_seconds() == 0


def test_fractional_seconds_round_up() -> None:
    assert Duration.from_seconds(0.1).to_seconds() == 1
    assert Duration.from_milliseconds(1500).to_seconds() == 2


def test_unit_constructors_match_seconds() -> None:
    assert Duration.from_minutes(1).to_seconds() == 60
    assert Duration.from_hours(1).to_seconds() == 3600
    assert Duration.from_days(1).to_seconds() == 86_400
    assert Duration.from_weeks(1).to_seconds() == 7 * 86_400
    assert Duration.from_years(1).to_seconds() == 365 * 86_400


def test_parse_compound_string() -> None:
    d = Duration.parse("1d 4h 5m 30s")
    want = SECONDS_IN_DAY + 4 * SECONDS_IN_HOUR + 5 * SECONDS_IN_MINUTE + 30
    assert d.to_seconds() == want


def test_parse_decimal_hours() -> None:
    assert Duration.parse("1.5h").to_seconds() == 5400


def test_parse_handles_whitespace_and_case() -> None:
    assert Duration.parse("  2 Weeks  ").to_seconds() == 14 * SECONDS_IN_DAY


def test_parse_milliseconds_round_up() -> None:
    # 1500 ms → 2s after ceil rounding.
    assert Duration.parse("1500ms").to_seconds() == 2


def test_parse_rejects_empty() -> None:
    with pytest.raises(BeeArgumentError):
        Duration.parse("")
    with pytest.raises(BeeArgumentError):
        Duration.parse("   ")


def test_parse_rejects_unknown_unit() -> None:
    with pytest.raises(BeeArgumentError):
        Duration.parse("3decades")


def test_str_decomposes_into_units() -> None:
    assert str(Duration.zero()) == "0s"
    d = Duration.from_seconds(SECONDS_IN_DAY + 4 * SECONDS_IN_HOUR + 5)
    assert str(d) == "1d 4h 5s"


def test_round_trip_through_timedelta() -> None:
    d = Duration.from_minutes(2.5)
    td = d.to_timedelta()
    back = Duration.from_timedelta(td)
    assert d == back


def test_orders_by_seconds() -> None:
    a = Duration.from_seconds(60)
    b = Duration.from_seconds(120)
    assert a < b
    assert hash(a) != hash(b)
    assert a != b
    assert Duration.from_minutes(1) == a


def test_to_milliseconds_uses_whole_seconds() -> None:
    assert Duration.from_seconds(2).to_milliseconds() == 2000


def test_is_zero_only_for_zero_seconds() -> None:
    assert Duration.zero().is_zero() is True
    assert Duration.from_seconds(1).is_zero() is False


def test_to_timedelta_returns_correct_seconds() -> None:
    d = Duration.from_minutes(5)
    assert d.to_timedelta() == datetime.timedelta(minutes=5)
