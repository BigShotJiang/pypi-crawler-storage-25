"""Tests for ``client.api.*`` — pins, tags, stewardship, grantee, envelope."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from bee import AsyncBee, Bee, EnvelopeResponse, GranteeResponse, Tag
from bee.swarm import BatchId, BeeJsonError, BeeResponseError, Reference

BATCH = BatchId(b"\xab" * 32)


def _r(byte: int) -> Reference:
    return Reference(bytes([byte]) * 32)


# ---- pins ---------------------------------------------------------------


@respx.mock
async def test_async_pin_unpin_round_trip() -> None:
    ref = _r(0x11)
    pin_url = f"http://localhost:1633/pins/{ref.to_hex()}"
    post = respx.post(pin_url).mock(return_value=httpx.Response(200))
    delete = respx.delete(pin_url).mock(return_value=httpx.Response(200))

    async with AsyncBee() as client:
        await client.api.pin(ref)
        await client.api.unpin(ref)

    assert post.called
    assert delete.called


@respx.mock
async def test_async_get_pin_translates_404_to_false() -> None:
    ref = _r(0x22)
    pin_url = f"http://localhost:1633/pins/{ref.to_hex()}"

    respx.get(pin_url).mock(return_value=httpx.Response(404))
    async with AsyncBee() as client:
        assert await client.api.get_pin(ref) is False


@respx.mock
async def test_async_get_pin_returns_true_on_200() -> None:
    ref = _r(0x33)
    respx.get(f"http://localhost:1633/pins/{ref.to_hex()}").mock(
        return_value=httpx.Response(200, json={})
    )
    async with AsyncBee() as client:
        assert await client.api.get_pin(ref) is True


@respx.mock
async def test_async_get_pin_propagates_other_errors() -> None:
    ref = _r(0x44)
    respx.get(f"http://localhost:1633/pins/{ref.to_hex()}").mock(
        return_value=httpx.Response(500)
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeResponseError):
            await client.api.get_pin(ref)


@respx.mock
async def test_async_list_pins_decodes_references() -> None:
    a, b = _r(0x55), _r(0x66)
    respx.get("http://localhost:1633/pins").mock(
        return_value=httpx.Response(
            200, json={"references": [a.to_hex(), b.to_hex()]}
        )
    )
    async with AsyncBee() as client:
        pins = await client.api.list_pins()
    assert pins == [a, b]


# ---- tags ---------------------------------------------------------------


@respx.mock
async def test_async_create_tag_parses_response() -> None:
    respx.post("http://localhost:1633/tags").mock(
        return_value=httpx.Response(
            200,
            json={
                "uid": 7,
                "name": "",
                "total": 0,
                "split": 0,
                "seen": 0,
                "stored": 0,
                "sent": 0,
                "synced": 0,
                "address": "",
                "startedAt": "2026-05-07T00:00:00Z",
            },
        )
    )
    async with AsyncBee() as client:
        tag = await client.api.create_tag()
    assert tag.uid == 7
    assert tag.started_at == "2026-05-07T00:00:00Z"


@respx.mock
async def test_async_get_tag_round_trip() -> None:
    respx.get("http://localhost:1633/tags/42").mock(
        return_value=httpx.Response(
            200, json={"uid": 42, "split": 5, "synced": 3, "address": "ab" * 32}
        )
    )
    async with AsyncBee() as client:
        tag = await client.api.get_tag(42)
    assert tag.uid == 42
    assert tag.split == 5
    assert tag.synced == 3


@respx.mock
async def test_async_list_tags_with_pagination() -> None:
    route = respx.get("http://localhost:1633/tags").mock(
        return_value=httpx.Response(
            200, json={"tags": [{"uid": 1}, {"uid": 2}]}
        )
    )
    async with AsyncBee() as client:
        tags = await client.api.list_tags(offset=10, limit=20)

    assert [t.uid for t in tags] == [1, 2]
    sent = route.calls.last.request
    assert sent.url.params["offset"] == "10"
    assert sent.url.params["limit"] == "20"


@respx.mock
async def test_async_list_tags_no_zero_query_params() -> None:
    route = respx.get("http://localhost:1633/tags").mock(
        return_value=httpx.Response(200, json={"tags": []})
    )
    async with AsyncBee() as client:
        await client.api.list_tags(offset=0, limit=0)
    # offset=0/limit=0 should not appear (matches bee-rs behavior).
    assert "offset" not in route.calls.last.request.url.params
    assert "limit" not in route.calls.last.request.url.params


@respx.mock
async def test_async_delete_tag() -> None:
    route = respx.delete("http://localhost:1633/tags/9").mock(
        return_value=httpx.Response(200)
    )
    async with AsyncBee() as client:
        await client.api.delete_tag(9)
    assert route.called


@respx.mock
async def test_async_update_tag_serializes_body() -> None:
    tag = Tag(uid=1, name="upload", total=100, split=50, address="cd" * 32)
    route = respx.patch("http://localhost:1633/tags/1").mock(
        return_value=httpx.Response(200)
    )
    async with AsyncBee() as client:
        await client.api.update_tag(1, tag)

    sent = route.calls.last.request
    assert sent.headers["content-type"] == "application/json"
    body = json.loads(sent.content)
    assert body["uid"] == 1
    assert body["name"] == "upload"
    assert body["startedAt"] == ""  # camelCase on the wire


# ---- stewardship --------------------------------------------------------


@respx.mock
async def test_async_reupload_sends_batch_header() -> None:
    ref = _r(0x77)
    route = respx.put(f"http://localhost:1633/stewardship/{ref.to_hex()}").mock(
        return_value=httpx.Response(200)
    )
    async with AsyncBee() as client:
        await client.api.reupload(ref, BATCH)
    assert route.calls.last.request.headers["swarm-postage-batch-id"] == "ab" * 32


@respx.mock
async def test_async_is_retrievable_accepts_camel_case() -> None:
    ref = _r(0x88)
    respx.get(f"http://localhost:1633/stewardship/{ref.to_hex()}").mock(
        return_value=httpx.Response(200, json={"isRetrievable": True})
    )
    async with AsyncBee() as client:
        assert await client.api.is_retrievable(ref) is True


@respx.mock
async def test_async_is_retrievable_accepts_snake_case() -> None:
    ref = _r(0x99)
    respx.get(f"http://localhost:1633/stewardship/{ref.to_hex()}").mock(
        return_value=httpx.Response(200, json={"is_retrievable": False})
    )
    async with AsyncBee() as client:
        assert await client.api.is_retrievable(ref) is False


@respx.mock
async def test_async_is_retrievable_rejects_unknown_shape() -> None:
    ref = _r(0xAA)
    respx.get(f"http://localhost:1633/stewardship/{ref.to_hex()}").mock(
        return_value=httpx.Response(200, json={"unrelated": True})
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeJsonError):
            await client.api.is_retrievable(ref)


# ---- grantees -----------------------------------------------------------


@respx.mock
async def test_async_get_grantees_returns_array() -> None:
    ref = _r(0xBB)
    respx.get(f"http://localhost:1633/grantee/{ref.to_hex()}").mock(
        return_value=httpx.Response(200, json=["pk1", "pk2", "pk3"])
    )
    async with AsyncBee() as client:
        grantees = await client.api.get_grantees(ref)
    assert grantees == ["pk1", "pk2", "pk3"]


@respx.mock
async def test_async_create_grantees_posts_json() -> None:
    route = respx.post("http://localhost:1633/grantee").mock(
        return_value=httpx.Response(
            200, json={"ref": "11" * 32, "historyref": "22" * 32}
        )
    )
    async with AsyncBee() as client:
        result = await client.api.create_grantees(BATCH, ["pk1", "pk2"])
    assert result == GranteeResponse(reference="11" * 32, history_reference="22" * 32)
    sent = route.calls.last.request
    assert sent.headers["swarm-postage-batch-id"] == "ab" * 32
    body = json.loads(sent.content)
    assert body == {"grantees": ["pk1", "pk2"]}


@respx.mock
async def test_async_patch_grantees_omits_empty_keys() -> None:
    ref = _r(0xCC)
    history = _r(0xDD)
    route = respx.patch(f"http://localhost:1633/grantee/{ref.to_hex()}").mock(
        return_value=httpx.Response(
            200, json={"ref": "33" * 32, "historyref": "44" * 32}
        )
    )
    async with AsyncBee() as client:
        await client.api.patch_grantees(BATCH, ref, history, add=["pk1"], revoke=[])

    sent = route.calls.last.request
    body = json.loads(sent.content)
    assert body == {"add": ["pk1"]}  # revoke omitted because empty
    assert sent.headers["swarm-act-history-address"] == history.to_hex()


# ---- envelope -----------------------------------------------------------


@respx.mock
async def test_async_post_envelope_parses_quadruple() -> None:
    ref = _r(0xEE)
    respx.post(f"http://localhost:1633/envelope/{ref.to_hex()}").mock(
        return_value=httpx.Response(
            200,
            json={
                "issuer": "0xdead",
                "index": "0x01",
                "timestamp": "0xff",
                "signature": "0xab" * 32,
            },
        )
    )
    async with AsyncBee() as client:
        env = await client.api.post_envelope(BATCH, ref)
    assert env == EnvelopeResponse(
        issuer="0xdead",
        index="0x01",
        timestamp="0xff",
        signature="0xab" * 32,
    )


# ---- sync surface --------------------------------------------------------


@respx.mock
def test_sync_pin_and_list() -> None:
    ref = _r(0x12)
    respx.post(f"http://localhost:1633/pins/{ref.to_hex()}").mock(
        return_value=httpx.Response(200)
    )
    respx.get("http://localhost:1633/pins").mock(
        return_value=httpx.Response(200, json={"references": [ref.to_hex()]})
    )

    with Bee() as client:
        client.api.pin(ref)
        pins = client.api.list_pins()

    assert pins == [ref]


@respx.mock
def test_sync_create_tag() -> None:
    respx.post("http://localhost:1633/tags").mock(
        return_value=httpx.Response(200, json={"uid": 99})
    )
    with Bee() as client:
        tag = client.api.create_tag()
    assert tag.uid == 99
