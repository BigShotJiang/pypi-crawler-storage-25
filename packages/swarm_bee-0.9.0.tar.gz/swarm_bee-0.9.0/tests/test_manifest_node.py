"""Tests for the Mantaray trie operations (no wire format yet)."""

from __future__ import annotations

import pytest

from bee.manifest import (
    MAX_PREFIX_LENGTH,
    TYPE_EDGE,
    TYPE_VALUE,
    MantarayNode,
)
from bee.manifest._helpers import (
    common_prefix,
    get_bit_le,
    has_type,
    pad_end_to_multiple,
    set_bit_le,
    xor_in_place,
)
from bee.swarm import BeeArgumentError, Reference


def _r32(byte: int) -> Reference:
    return Reference(bytes([byte]) * 32)


# ---- helpers tests --------------------------------------------------------


def test_xor_round_trip() -> None:
    buf = bytearray([0xAA] * 10)
    original = bytes(buf)
    xor_in_place(buf, b"key")
    xor_in_place(buf, b"key")
    assert bytes(buf) == original


def test_xor_empty_key_is_noop() -> None:
    buf = bytearray([1, 2, 3])
    original = bytes(buf)
    xor_in_place(buf, b"")
    assert bytes(buf) == original


def test_set_get_bit_le_packing() -> None:
    buf = bytearray(4)
    set_bit_le(buf, 0)
    set_bit_le(buf, 9)
    set_bit_le(buf, 17)
    assert get_bit_le(buf, 0)
    assert get_bit_le(buf, 9)
    assert get_bit_le(buf, 17)
    assert not get_bit_le(buf, 1)
    assert bytes(buf) == bytes([0b0000_0001, 0b0000_0010, 0b0000_0010, 0])


def test_common_prefix_returns_shared() -> None:
    assert common_prefix(b"hello", b"help") == b"hel"
    assert common_prefix(b"abc", b"abc") == b"abc"
    assert common_prefix(b"abc", b"xyz") == b""
    assert common_prefix(b"abc", b"ab") == b"ab"


def test_pad_end_to_multiple_aligns() -> None:
    assert pad_end_to_multiple(b"\x01\x02\x03", 8, 0xAA) == b"\x01\x02\x03" + b"\xaa" * 5
    assert pad_end_to_multiple(b"\x01" * 8, 8, 0) == b"\x01" * 8


def test_has_type_bits() -> None:
    assert has_type(0b0110, 0b0010)
    assert has_type(0b0110, 0b0100)
    assert not has_type(0b0110, 0b0001)
    assert has_type(0b1111, 0b0110)


# ---- node tests -----------------------------------------------------------


def test_add_and_find_simple() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    n = root.find(b"hello")
    assert n is not None
    assert n.target_address == bytes([0x11] * 32)


def test_find_returns_none_for_missing_path() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    assert root.find(b"world") is None
    # Diverges inside fork prefix → no descent → no match.
    assert root.find(b"helicopter") is None


def test_find_closest_matched_only_consumed() -> None:
    """matched is the path actually consumed by descending into existing
    forks. If a fork's prefix diverges before being fully consumed, no
    descent — matched stays at the last fully-consumed boundary."""
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    _, matched = root.find_closest(b"helicopter")
    assert matched == b""
    _, matched = root.find_closest(b"hello/world")
    assert matched == b"hello"


def test_two_paths_share_prefix() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    root.add_fork(b"help", _r32(0x22))
    assert root.find(b"hello") is not None
    assert root.find(b"hello").target_address == bytes([0x11] * 32)  # type: ignore[union-attr]
    assert root.find(b"help") is not None
    assert root.find(b"help").target_address == bytes([0x22] * 32)  # type: ignore[union-attr]


def test_three_paths_with_shared_prefix() -> None:
    root = MantarayNode()
    root.add_fork(b"index.html", _r32(0xAA))
    root.add_fork(b"index.css", _r32(0xBB))
    root.add_fork(b"index.js", _r32(0xCC))
    assert root.find(b"index.html").target_address == bytes([0xAA] * 32)  # type: ignore[union-attr]
    assert root.find(b"index.css").target_address == bytes([0xBB] * 32)  # type: ignore[union-attr]
    assert root.find(b"index.js").target_address == bytes([0xCC] * 32)  # type: ignore[union-attr]


def test_long_path_chunks_into_chained_nodes() -> None:
    root = MantarayNode()
    path = b"a" * 100  # > MAX_PREFIX_LENGTH=30 → multiple chained chunks
    assert len(path) > MAX_PREFIX_LENGTH
    root.add_fork(path, _r32(0x33))
    assert root.find(path).target_address == bytes([0x33] * 32)  # type: ignore[union-attr]


def test_remove_fork_keeps_other_paths() -> None:
    root = MantarayNode()
    root.add_fork(b"foo/a", _r32(0xAA))
    root.add_fork(b"foo/b", _r32(0xBB))
    root.remove_fork(b"foo/a")
    assert root.find(b"foo/a") is None
    assert root.find(b"foo/b").target_address == bytes([0xBB] * 32)  # type: ignore[union-attr]


def test_remove_fork_reinserts_grandchildren() -> None:
    root = MantarayNode()
    root.add_fork(b"a/b/c", _r32(0x01))
    root.add_fork(b"a/b/d", _r32(0x02))
    root.add_fork(b"a/x", _r32(0x03))
    root.remove_fork(b"a/b/c")
    assert root.find(b"a/b/c") is None
    assert root.find(b"a/b/d").target_address == bytes([0x02] * 32)  # type: ignore[union-attr]
    assert root.find(b"a/x").target_address == bytes([0x03] * 32)  # type: ignore[union-attr]


def test_remove_fork_unknown_path_errors() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x01))
    with pytest.raises(BeeArgumentError):
        root.remove_fork(b"world")


def test_remove_fork_empty_path_errors() -> None:
    root = MantarayNode()
    with pytest.raises(BeeArgumentError):
        root.remove_fork(b"")


def test_collect_returns_full_paths_for_leaves() -> None:
    root = MantarayNode()
    root.add_fork(b"a", _r32(0x01))
    root.add_fork(b"ab", _r32(0x02))
    root.add_fork(b"abc", _r32(0x03))
    paths = sorted(p for p, _ in root.collect())
    assert paths == [b"a", b"ab", b"abc"]


def test_collect_and_map_returns_string_keyed_refs() -> None:
    root = MantarayNode()
    root.add_fork(b"hello.txt", _r32(0xEE))
    m = root.collect_and_map()
    assert len(m) == 1
    assert m["hello.txt"].as_bytes() == bytes([0xEE] * 32)


def test_determine_type_packs_value_bit_for_leaf() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    leaf = root.find(b"hello")
    assert leaf is not None
    t = leaf.determine_type()
    assert t & TYPE_VALUE != 0
    assert t & TYPE_EDGE == 0


def test_determine_type_packs_edge_bit_for_branch() -> None:
    root = MantarayNode()
    root.add_fork(b"hello", _r32(0x11))
    root.add_fork(b"help", _r32(0x22))
    # The fork at 'h' should be a branch (path "hel") with two children.
    branch = root.forks[ord("h")].node
    t = branch.determine_type()
    assert t & TYPE_EDGE != 0


def test_metadata_is_preserved() -> None:
    root = MantarayNode()
    meta = {"k": "v"}
    root.add_fork(b"foo", _r32(0xAA), meta)
    n = root.find(b"foo")
    assert n is not None
    assert n.metadata == meta


def test_self_address_is_invalidated_by_add_fork() -> None:
    root = MantarayNode()
    root.self_address = b"\xff" * 32
    root.add_fork(b"x", _r32(0x01))
    assert root.self_address is None
