"""Tests for ``client.file.chunks_stream`` — websocket bulk upload session.

Uses a real local WebSocket server (``websockets.asyncio.server``) so
the wire protocol (binary frame from client → ``\\x00`` ack from
server) is exercised end-to-end. respx is HTTP-only.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator

import pytest
from websockets.asyncio.server import ServerConnection, serve

from bee import AsyncBee
from bee.swarm import BatchId
from bee.swarm.errors import BeeArgumentError, BeeTransportError

BATCH = BatchId(b"\xab" * 32)


@pytest.fixture
async def echo_ack_server() -> AsyncIterator[tuple[str, list[bytes]]]:
    """Spin up a server that records each binary frame and replies with
    a single ``b"\\x00"`` ack."""
    received: list[bytes] = []

    async def handler(ws: ServerConnection) -> None:
        async for msg in ws:
            if isinstance(msg, bytes):
                received.append(msg)
                await ws.send(b"\x00")
            else:
                await ws.send(f"unexpected text: {msg}")

    server = await serve(handler, "127.0.0.1", 0)
    try:
        # Pull the bound port from the underlying socket so the test
        # can connect deterministically without racing on /1633.
        sock = next(iter(server.sockets))
        port = sock.getsockname()[1]
        yield (f"http://127.0.0.1:{port}", received)
    finally:
        server.close()
        await server.wait_closed()


@pytest.fixture
async def error_server() -> AsyncIterator[str]:
    """Server that replies to every binary frame with a text frame —
    treated as a server error by the client."""

    async def handler(ws: ServerConnection) -> None:
        async for _ in ws:
            await ws.send("nope")

    server = await serve(handler, "127.0.0.1", 0)
    try:
        sock = next(iter(server.sockets))
        port = sock.getsockname()[1]
        yield f"http://127.0.0.1:{port}"
    finally:
        server.close()
        await server.wait_closed()


async def test_send_chunk_round_trips_against_server(
    echo_ack_server: tuple[str, list[bytes]],
) -> None:
    base_url, received = echo_ack_server
    async with AsyncBee(base_url) as client, await client.file.chunks_stream(BATCH) as stream:
        await stream.send_chunk(b"chunk-one")
        await stream.send_chunk(b"chunk-two")
    # The server should have observed both chunks in order.
    assert received == [b"chunk-one", b"chunk-two"]


async def test_send_chunk_after_close_raises(
    echo_ack_server: tuple[str, list[bytes]],
) -> None:
    base_url, _ = echo_ack_server
    async with AsyncBee(base_url) as client:
        stream = await client.file.chunks_stream(BATCH)
        await stream.close()
        with pytest.raises(BeeArgumentError):
            await stream.send_chunk(b"too-late")


async def test_text_response_treated_as_server_error(error_server: str) -> None:
    async with AsyncBee(error_server) as client, await client.file.chunks_stream(
        BATCH
    ) as stream:
        with pytest.raises(BeeArgumentError) as excinfo:
            await stream.send_chunk(b"x")
    assert "nope" in str(excinfo.value)


async def test_connect_failure_surfaces_transport_error() -> None:
    # Port 1 is unprivileged-not-listening on every Linux box.
    async with AsyncBee("http://127.0.0.1:1") as client:
        with pytest.raises(BeeTransportError):
            await client.file.chunks_stream(BATCH)


async def test_tag_query_param_appended(
    echo_ack_server: tuple[str, list[bytes]],
) -> None:
    """Connecting with a tag should include ``swarm-tag=N`` in the URL.

    We cover this indirectly: a server fixture that captures the
    incoming request path lets us inspect the query string.
    """
    captured_paths: list[str] = []

    async def handler(ws: ServerConnection) -> None:
        captured_paths.append(ws.request.path)
        async for msg in ws:
            if isinstance(msg, bytes):
                await ws.send(b"\x00")

    server = await serve(handler, "127.0.0.1", 0)
    try:
        sock = next(iter(server.sockets))
        port = sock.getsockname()[1]
        async with AsyncBee(
            f"http://127.0.0.1:{port}"
        ) as client, await client.file.chunks_stream(BATCH, tag=42) as stream:
            await stream.send_chunk(b"x")
        assert captured_paths
        assert "swarm-tag=42" in captured_paths[0]
    finally:
        server.close()
        await server.wait_closed()


async def test_postage_batch_header_sent_on_handshake(
    echo_ack_server: tuple[str, list[bytes]],
) -> None:
    captured_headers: list[dict[str, str]] = []

    async def handler(ws: ServerConnection) -> None:
        captured_headers.append(dict(ws.request.headers))
        async for msg in ws:
            if isinstance(msg, bytes):
                await ws.send(b"\x00")

    server = await serve(handler, "127.0.0.1", 0)
    try:
        sock = next(iter(server.sockets))
        port = sock.getsockname()[1]
        async with AsyncBee(
            f"http://127.0.0.1:{port}"
        ) as client, await client.file.chunks_stream(BATCH) as stream:
            await stream.send_chunk(b"x")
        assert captured_headers
        # Header names are case-insensitive on the wire; websockets
        # normalizes them to lowercase keys.
        hdrs = {k.lower(): v for k, v in captured_headers[0].items()}
        assert hdrs.get("swarm-postage-batch-id") == BATCH.to_hex()
    finally:
        server.close()
        await server.wait_closed()


async def test_close_is_idempotent(
    echo_ack_server: tuple[str, list[bytes]],
) -> None:
    base_url, _ = echo_ack_server
    async with AsyncBee(base_url) as client:
        stream = await client.file.chunks_stream(BATCH)
        await stream.close()
        # Second close should not raise.
        await stream.close()
        # Use asyncio.sleep to make pytest happy about no awaits in
        # case the test runner skips above.
        await asyncio.sleep(0)
