"""Tests for ``bee.postage`` reads + writes against respx mocks."""

from __future__ import annotations

import httpx
import pytest
import respx

from bee import (
    AsyncBee,
    Bee,
    BeeJsonError,
    BeeResponseError,
    PostageBatchOptions,
)
from bee.postage import GlobalPostageBatch, PostageBatch, PostageBatchBuckets
from bee.swarm import BatchId

BATCH_HEX = "ef" * 32


def _stamps_payload(**overrides: object) -> dict[str, object]:
    base: dict[str, object] = {
        "batchID": BATCH_HEX,
        "amount": "500000000",
        "start": 10806084,
        "owner": "ab" * 20,
        "depth": 22,
        "bucketDepth": 16,
        "immutableFlag": True,
        "batchTTL": 28591,
        "utilization": 0,
        "usable": True,
        "exists": True,
        "label": "bench",
        "blockNumber": 10806084,
    }
    base.update(overrides)
    return base


@respx.mock
async def test_async_get_postage_batches_unwraps_stamps_envelope() -> None:
    respx.get("http://localhost:1633/stamps").mock(
        return_value=httpx.Response(200, json={"stamps": [_stamps_payload()]})
    )
    async with AsyncBee() as client:
        batches = await client.postage.get_postage_batches()
    assert len(batches) == 1
    b = batches[0]
    assert isinstance(b, PostageBatch)
    assert b.batch_id == BatchId.from_hex(BATCH_HEX)
    assert b.amount == 500_000_000  # bigint string parsed to int
    assert b.depth == 22
    assert b.bucket_depth == 16
    assert b.immutable is True
    assert b.usable is True
    assert b.label == "bench"


@respx.mock
async def test_async_get_postage_batch_handles_missing_optional_fields() -> None:
    """Older Bee builds may omit `exists` / `label` — defaults must hold."""
    minimal = {
        "batchID": BATCH_HEX,
        "depth": 22,
        "bucketDepth": 16,
    }
    respx.get(f"http://localhost:1633/stamps/{BATCH_HEX}").mock(
        return_value=httpx.Response(200, json=minimal)
    )
    async with AsyncBee() as client:
        b = await client.postage.get_postage_batch(BatchId.from_hex(BATCH_HEX))
    assert b.amount is None
    assert b.label == ""
    assert b.exists is False
    assert b.usable is False


@respx.mock
async def test_async_get_postage_batch_buckets_parses_nested_list() -> None:
    payload = {
        "depth": 22,
        "bucketDepth": 16,
        "bucketUpperBound": 64,
        "buckets": [
            {"bucketID": 0, "collisions": 5},
            {"bucketID": 1, "collisions": 3},
        ],
    }
    respx.get(f"http://localhost:1633/stamps/{BATCH_HEX}/buckets").mock(
        return_value=httpx.Response(200, json=payload)
    )
    async with AsyncBee() as client:
        bb = await client.postage.get_postage_batch_buckets(BatchId.from_hex(BATCH_HEX))
    assert isinstance(bb, PostageBatchBuckets)
    assert bb.bucket_upper_bound == 64
    assert [(b.bucket_id, b.collisions) for b in bb.buckets] == [(0, 5), (1, 3)]


@respx.mock
async def test_async_get_global_postage_batches_uses_value_and_immutable_keys() -> None:
    """Wire-format gotcha: the chain endpoint uses `"value"` (not `"amount"`)
    and `"immutable"` (not `"immutableFlag"`)."""
    payload = {
        "batches": [
            {
                "batchID": BATCH_HEX,
                "value": "1000000000",
                "start": 10800000,
                "owner": "cd" * 20,
                "depth": 22,
                "bucketDepth": 16,
                "immutable": True,
                "batchTTL": 100000,
            }
        ]
    }
    respx.get("http://localhost:1633/batches").mock(return_value=httpx.Response(200, json=payload))
    async with AsyncBee() as client:
        batches = await client.postage.get_global_postage_batches()
    assert len(batches) == 1
    g = batches[0]
    assert isinstance(g, GlobalPostageBatch)
    assert g.value == 1_000_000_000
    assert g.immutable is True


@respx.mock
async def test_async_create_postage_batch_uses_amount_depth_path() -> None:
    route = respx.post("http://localhost:1633/stamps/500000000/22").mock(
        return_value=httpx.Response(200, json={"batchID": BATCH_HEX})
    )
    async with AsyncBee() as client:
        bid = await client.postage.create_postage_batch(500_000_000, 22, label="my-batch")
    assert bid == BatchId.from_hex(BATCH_HEX)
    sent = route.calls.last.request
    assert sent.url.params["label"] == "my-batch"


@respx.mock
async def test_async_create_postage_batch_threads_immutable_and_gas_headers() -> None:
    route = respx.post("http://localhost:1633/stamps/100/20").mock(
        return_value=httpx.Response(200, json={"batchID": BATCH_HEX})
    )
    opts = PostageBatchOptions(
        label="x",
        immutable=False,
        gas_price="1000000",
        gas_limit="500000",
    )
    async with AsyncBee() as client:
        await client.postage.create_postage_batch(100, 20, opts=opts)
    sent = route.calls.last.request
    assert sent.url.params["label"] == "x"
    assert sent.url.params["immutable"] == "false"
    assert sent.headers["gas-price"] == "1000000"
    assert sent.headers["gas-limit"] == "500000"


@respx.mock
async def test_async_create_postage_batch_rejects_conflicting_label_args() -> None:
    opts = PostageBatchOptions(label="opts-label")
    async with AsyncBee() as client:
        with pytest.raises(BeeJsonError):
            await client.postage.create_postage_batch(100, 20, label="arg-label", opts=opts)


@respx.mock
async def test_async_top_up_batch_patches_correct_path() -> None:
    route = respx.patch(f"http://localhost:1633/stamps/topup/{BATCH_HEX}/100000").mock(
        return_value=httpx.Response(200, json={})
    )
    async with AsyncBee() as client:
        await client.postage.top_up_batch(BatchId.from_hex(BATCH_HEX), 100_000)
    assert route.called


@respx.mock
async def test_async_dilute_batch_patches_correct_path() -> None:
    route = respx.patch(f"http://localhost:1633/stamps/dilute/{BATCH_HEX}/24").mock(
        return_value=httpx.Response(200, json={})
    )
    async with AsyncBee() as client:
        await client.postage.dilute_batch(BatchId.from_hex(BATCH_HEX), 24)
    assert route.called


@respx.mock
async def test_async_dilute_batch_propagates_response_error() -> None:
    respx.patch(f"http://localhost:1633/stamps/dilute/{BATCH_HEX}/10").mock(
        return_value=httpx.Response(400, content=b"depth can only grow")
    )
    async with AsyncBee() as client:
        with pytest.raises(BeeResponseError) as ei:
            await client.postage.dilute_batch(BatchId.from_hex(BATCH_HEX), 10)
    assert ei.value.status == 400


@respx.mock
def test_sync_get_postage_batches_works() -> None:
    respx.get("http://localhost:1633/stamps").mock(
        return_value=httpx.Response(200, json={"stamps": [_stamps_payload()]})
    )
    with Bee() as client:
        batches = client.postage.get_postage_batches()
    assert len(batches) == 1
    assert batches[0].batch_id == BatchId.from_hex(BATCH_HEX)
