"""Tests for ``bee.storage`` — high-level (size, duration) helpers."""

from __future__ import annotations

import httpx
import respx

from bee import AsyncBee, Bee
from bee.storage import (
    StorageOptions,
    buy_storage,
    buy_storage_sync,
    calculate_top_up_for_bzz,
    extend_storage_duration,
    extend_storage_size,
    get_duration_extension_cost,
    get_size_extension_cost,
    get_storage_cost,
)
from bee.swarm import Duration, Network, Size

# A current_price of 24000 PLUR/chunk/block makes the math easy to
# follow: 12 blocks = 60 seconds on Gnosis → 24000*12 = 288_000 PLUR/chunk
_CHAIN_STATE = {
    "block": 100,
    "chainTip": 100,
    "currentPrice": "24000",
    "totalAmount": "0",
}


def _mock_chain() -> respx.Route:
    return respx.get("http://localhost:1633/chainstate").mock(
        return_value=httpx.Response(200, json=_CHAIN_STATE)
    )


def _mock_batch(batch_hex: str, depth: int, amount: str | None = "100") -> respx.Route:
    body: dict[str, object] = {
        "batchID": batch_hex,
        "depth": depth,
        "bucketDepth": 16,
        "blockNumber": 1,
        "immutableFlag": True,
        "exists": True,
        "batchTTL": 1000,
        "label": "x",
        "usable": True,
        "utilization": 0,
    }
    if amount is not None:
        body["amount"] = amount
    return respx.get(f"http://localhost:1633/stamps/{batch_hex}").mock(
        return_value=httpx.Response(200, json=body)
    )


# ---- get_storage_cost ----------------------------------------------------


@respx.mock
async def test_get_storage_cost_uses_chainstate() -> None:
    _mock_chain()
    async with AsyncBee() as client:
        cost = await get_storage_cost(
            client,
            Size.from_megabytes(100),
            Duration.from_minutes(1),
            Network.GNOSIS,
        )
    # 1 minute on Gnosis = 12 blocks; 24000 * 12 = 288000 PLUR per chunk.
    assert cost.blocks == 12
    assert cost.amount_per_chunk == 288_000
    assert cost.depth >= 16
    # total_cost = 2^depth * amount_per_chunk
    assert cost.total_cost == (1 << cost.depth) * 288_000


# ---- buy_storage ---------------------------------------------------------


@respx.mock
async def test_buy_storage_creates_batch_with_computed_args() -> None:
    _mock_chain()
    captured: list[str] = []

    def respond(request: httpx.Request) -> httpx.Response:
        captured.append(str(request.url))
        return httpx.Response(200, json={"batchID": "ab" * 32})

    respx.post(url__regex=r"http://localhost:1633/stamps/.*").mock(side_effect=respond)

    async with AsyncBee() as client:
        batch_id = await buy_storage(
            client,
            Size.from_megabytes(100),
            Duration.from_minutes(1),
            StorageOptions(network=Network.GNOSIS, label="ci"),
        )

    assert batch_id.to_hex() == "ab" * 32
    assert captured, "no /stamps POST was made"
    # URL is /stamps/{amount}/{depth}
    parts = captured[0].split("/stamps/")[-1].split("?")[0].split("/")
    assert parts[0] == "288000"
    # Depth should be ≥ 16 (computed from 100 MB).
    assert int(parts[1]) >= 16


# ---- extend_storage_duration --------------------------------------------


@respx.mock
async def test_extend_storage_duration_tops_up_amount() -> None:
    _mock_chain()
    batch_hex = "11" * 32
    captured: list[str] = []

    def respond(request: httpx.Request) -> httpx.Response:
        captured.append(str(request.url))
        return httpx.Response(200)

    respx.patch(url__regex=r"http://localhost:1633/stamps/topup/.*").mock(
        side_effect=respond
    )

    async with AsyncBee() as client:
        from bee.swarm import BatchId

        await extend_storage_duration(
            client,
            BatchId.from_hex(batch_hex),
            Duration.from_minutes(1),
            Network.GNOSIS,
        )

    # 1 min on Gnosis = 12 blocks * 24000 = 288000 PLUR.
    assert any(captured[0].endswith("/288000") for _ in [None])
    assert "/stamps/topup/" + batch_hex in captured[0]


# ---- extend_storage_size -------------------------------------------------


@respx.mock
async def test_extend_storage_size_skips_when_already_deep_enough() -> None:
    batch_hex = "22" * 32
    _mock_batch(batch_hex, depth=22)  # depth 22 covers > 4 GB
    # No PATCH /dilute should be made — assert by not registering the route.

    async with AsyncBee() as client:
        from bee.swarm import BatchId

        await extend_storage_size(
            client, BatchId.from_hex(batch_hex), Size.from_megabytes(10)
        )


@respx.mock
async def test_extend_storage_size_dilutes_when_too_shallow() -> None:
    batch_hex = "33" * 32
    _mock_batch(batch_hex, depth=16)
    captured: list[str] = []

    def respond(request: httpx.Request) -> httpx.Response:
        captured.append(str(request.url))
        return httpx.Response(200)

    respx.patch(url__regex=r"http://localhost:1633/stamps/dilute/.*").mock(
        side_effect=respond
    )

    async with AsyncBee() as client:
        from bee.swarm import BatchId

        await extend_storage_size(
            client, BatchId.from_hex(batch_hex), Size.from_gigabytes(10)
        )

    assert captured, "expected a dilute PATCH"
    # /stamps/dilute/{id}/{depth} where depth is the new (larger) target.
    parts = captured[0].split("/stamps/dilute/")[-1].split("/")
    assert parts[0] == batch_hex
    assert int(parts[1]) > 16


# ---- cost previews --------------------------------------------------------


@respx.mock
async def test_get_duration_extension_cost_multiplies_by_capacity() -> None:
    _mock_chain()
    batch_hex = "44" * 32
    _mock_batch(batch_hex, depth=18)

    async with AsyncBee() as client:
        from bee.swarm import BatchId

        cost = await get_duration_extension_cost(
            client,
            BatchId.from_hex(batch_hex),
            Duration.from_minutes(1),
            Network.GNOSIS,
        )
    # amount_per_chunk = 24000 * 12 = 288000; total = 2^18 * 288000.
    assert cost == (1 << 18) * 288_000


@respx.mock
async def test_get_size_extension_cost_zero_when_already_deep() -> None:
    batch_hex = "55" * 32
    _mock_batch(batch_hex, depth=24)

    async with AsyncBee() as client:
        from bee.swarm import BatchId

        cost = await get_size_extension_cost(
            client, BatchId.from_hex(batch_hex), Size.from_megabytes(1)
        )
    assert cost == 0


@respx.mock
async def test_get_size_extension_cost_uses_amount() -> None:
    batch_hex = "66" * 32
    _mock_batch(batch_hex, depth=16, amount="1000")

    async with AsyncBee() as client:
        from bee.swarm import BatchId

        cost = await get_size_extension_cost(
            client, BatchId.from_hex(batch_hex), Size.from_gigabytes(50)
        )
    # New depth ≥ 22; cost = (2^22 - 2^16) * 1000 ≥ (2^21) * 1000.
    assert cost > 0


# ---- calculate_top_up_for_bzz --------------------------------------------


@respx.mock
async def test_calculate_top_up_for_bzz_returns_difference() -> None:
    batch_hex = "77" * 32
    _mock_batch(batch_hex, depth=16, amount="500")

    async with AsyncBee() as client:
        from bee.swarm import BatchId

        diff = await calculate_top_up_for_bzz(
            client, BatchId.from_hex(batch_hex), 1500
        )
    assert diff == 1000


@respx.mock
async def test_calculate_top_up_for_bzz_zero_when_below_target() -> None:
    batch_hex = "88" * 32
    _mock_batch(batch_hex, depth=16, amount="2000")

    async with AsyncBee() as client:
        from bee.swarm import BatchId

        diff = await calculate_top_up_for_bzz(
            client, BatchId.from_hex(batch_hex), 1500
        )
    assert diff == 0


# ---- sync surface --------------------------------------------------------


@respx.mock
def test_sync_get_storage_cost() -> None:
    _mock_chain()
    with Bee() as client:
        from bee.storage import get_storage_cost_sync

        cost = get_storage_cost_sync(
            client, Size.from_megabytes(10), Duration.from_minutes(1)
        )
    assert cost.blocks == 12
    assert cost.amount_per_chunk == 288_000


@respx.mock
def test_sync_buy_storage() -> None:
    _mock_chain()
    respx.post(url__regex=r"http://localhost:1633/stamps/.*").mock(
        return_value=httpx.Response(200, json={"batchID": "cd" * 32})
    )
    with Bee() as client:
        batch_id = buy_storage_sync(
            client, Size.from_megabytes(10), Duration.from_minutes(1)
        )
    assert batch_id.to_hex() == "cd" * 32


@respx.mock
def test_sync_extend_storage_size_skips_when_deep_enough() -> None:
    batch_hex = "99" * 32
    _mock_batch(batch_hex, depth=24)
    with Bee() as client:
        from bee.storage import extend_storage_size_sync
        from bee.swarm import BatchId

        extend_storage_size_sync(
            client, BatchId.from_hex(batch_hex), Size.from_megabytes(1)
        )
