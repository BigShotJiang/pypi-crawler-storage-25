"""End-to-end tests for ``client.file.upload_file`` /
``download_file`` / ``upload_collection_entries`` against respx-mocked
Bee responses."""

from __future__ import annotations

import io
import tarfile

import httpx
import pytest
import respx

from bee import (
    AsyncBee,
    Bee,
    CollectionEntry,
    CollectionUploadOptions,
    FileUploadOptions,
)
from bee.file import build_tar_archive, collection_size, read_directory_entries
from bee.swarm import BatchId, Reference

BATCH = BatchId(b"\xab" * 32)
REF_HEX = "cd" * 32


@respx.mock
async def test_async_upload_file_sends_name_query_and_content_type() -> None:
    route = respx.post("http://localhost:1633/bzz").mock(
        return_value=httpx.Response(200, json={"reference": REF_HEX})
    )
    async with AsyncBee("http://localhost:1633") as client:
        result = await client.file.upload_file(
            BATCH, b"<html/>", name="index.html", content_type="text/html"
        )

    assert result.reference.to_hex() == REF_HEX
    sent = route.calls.last.request
    assert sent.url.params["name"] == "index.html"
    assert sent.headers["content-type"] == "text/html"
    assert sent.headers["swarm-postage-batch-id"] == "ab" * 32
    assert sent.content == b"<html/>"


@respx.mock
async def test_async_upload_file_default_content_type() -> None:
    route = respx.post("http://localhost:1633/bzz").mock(
        return_value=httpx.Response(200, json={"reference": REF_HEX})
    )
    async with AsyncBee() as client:
        await client.file.upload_file(BATCH, b"raw bytes")
    assert route.calls.last.request.headers["content-type"] == "application/octet-stream"


@respx.mock
async def test_async_upload_file_options_override_arg_content_type() -> None:
    route = respx.post("http://localhost:1633/bzz").mock(
        return_value=httpx.Response(200, json={"reference": REF_HEX})
    )
    opts = FileUploadOptions(content_type="application/json", size=128)
    async with AsyncBee() as client:
        await client.file.upload_file(BATCH, b"{}", content_type="text/plain", opts=opts)
    sent = route.calls.last.request
    assert sent.headers["content-type"] == "application/json"
    assert sent.headers["content-length"] == "128"


@respx.mock
async def test_async_download_file_returns_body_and_parsed_headers() -> None:
    ref = Reference.from_hex(REF_HEX)
    respx.get(f"http://localhost:1633/bzz/{REF_HEX}").mock(
        return_value=httpx.Response(
            200,
            content=b"<html/>",
            headers={
                "Content-Type": "text/html",
                "Content-Disposition": 'attachment; filename="index.html"',
                "Swarm-Tag-Uid": "5",
            },
        )
    )
    async with AsyncBee() as client:
        body, fh = await client.file.download_file(ref)
    assert body == b"<html/>"
    assert fh.content_type == "text/html"
    assert fh.name == "index.html"
    assert fh.tag_uid == 5


@respx.mock
async def test_async_download_file_path_handles_leading_slash() -> None:
    ref = Reference.from_hex(REF_HEX)
    respx.get(f"http://localhost:1633/bzz/{REF_HEX}/nested/file.txt").mock(
        return_value=httpx.Response(200, content=b"nested")
    )
    async with AsyncBee() as client:
        body, _fh = await client.file.download_file_path(ref, "/nested/file.txt")
    assert body == b"nested"


@respx.mock
async def test_async_upload_collection_sends_tar_with_swarm_collection_header() -> None:
    route = respx.post("http://localhost:1633/bzz").mock(
        return_value=httpx.Response(200, json={"reference": REF_HEX})
    )
    entries = [
        CollectionEntry("index.html", b"<html/>"),
        CollectionEntry("nested/data.bin", b"\x00\x01\x02"),
    ]
    async with AsyncBee() as client:
        await client.file.upload_collection_entries(BATCH, entries)

    sent = route.calls.last.request
    assert sent.headers["content-type"] == "application/x-tar"
    assert sent.headers["swarm-collection"] == "true"

    # Body must be a valid tar containing the same paths + data we sent.
    found: dict[str, bytes] = {}
    with tarfile.open(fileobj=io.BytesIO(sent.content), mode="r") as ar:
        for member in ar.getmembers():
            f = ar.extractfile(member)
            assert f is not None
            found[member.name] = f.read()
    assert found == {"index.html": b"<html/>", "nested/data.bin": b"\x00\x01\x02"}


@respx.mock
async def test_async_upload_collection_threads_index_document_header() -> None:
    route = respx.post("http://localhost:1633/bzz").mock(
        return_value=httpx.Response(200, json={"reference": REF_HEX})
    )
    entries = [CollectionEntry("a.html", b"a")]
    opts = CollectionUploadOptions(index_document="a.html", error_document="404.html")
    async with AsyncBee() as client:
        await client.file.upload_collection_entries(BATCH, entries, opts)
    sent = route.calls.last.request
    assert sent.headers["swarm-index-document"] == "a.html"
    assert sent.headers["swarm-error-document"] == "404.html"


@respx.mock
def test_sync_upload_collection_from_directory(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "nested").mkdir()
    (tmp_path / "index.html").write_bytes(b"<html/>")
    (tmp_path / "nested" / "data.bin").write_bytes(b"\x00\x01\x02")

    route = respx.post("http://localhost:1633/bzz").mock(
        return_value=httpx.Response(200, json={"reference": REF_HEX})
    )

    with Bee() as client:
        result = client.file.upload_collection(BATCH, tmp_path)

    assert result.reference.to_hex() == REF_HEX
    sent = route.calls.last.request
    found: dict[str, bytes] = {}
    with tarfile.open(fileobj=io.BytesIO(sent.content), mode="r") as ar:
        for member in ar.getmembers():
            f = ar.extractfile(member)
            assert f is not None
            found[member.name] = f.read()
    assert found == {"index.html": b"<html/>", "nested/data.bin": b"\x00\x01\x02"}


def test_collection_size_sums_entries() -> None:
    entries = [
        CollectionEntry("a.txt", b"abc"),
        CollectionEntry("b.txt", b"defgh"),
    ]
    assert collection_size(entries) == 8


def test_build_tar_archive_round_trip() -> None:
    entries = [
        CollectionEntry("index.html", b"<html/>"),
        CollectionEntry("nested/data.bin", b"\x00\x01\x02"),
    ]
    tar_bytes = build_tar_archive(entries)
    found: list[tuple[str, bytes]] = []
    with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r") as ar:
        for member in ar.getmembers():
            f = ar.extractfile(member)
            assert f is not None
            found.append((member.name, f.read()))
    assert found == [
        ("index.html", b"<html/>"),
        ("nested/data.bin", b"\x00\x01\x02"),
    ]


def test_read_directory_entries_walks_recursively_sorted(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "nested").mkdir()
    (tmp_path / "a.txt").write_bytes(b"alpha")
    (tmp_path / "nested" / "b.bin").write_bytes(bytes([0, 1, 2]))

    entries = read_directory_entries(tmp_path)
    assert [(e.path, e.data) for e in entries] == [
        ("a.txt", b"alpha"),
        ("nested/b.bin", b"\x00\x01\x02"),
    ]


def test_read_directory_entries_rejects_non_directory(tmp_path) -> None:  # type: ignore[no-untyped-def]
    f = tmp_path / "file.txt"
    f.write_bytes(b"x")
    with pytest.raises(Exception):  # noqa: B017 - generic by design
        read_directory_entries(f)
