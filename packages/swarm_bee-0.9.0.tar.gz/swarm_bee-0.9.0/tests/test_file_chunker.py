"""Tests for ``bee.swarm.FileChunker`` — multi-chunk BMT tree."""

from __future__ import annotations

import pytest

from bee.swarm import (
    CHUNK_SIZE,
    MAX_BRANCHES,
    FileChunker,
    SealedChunk,
    chunk_file,
    make_content_addressed_chunk,
)
from bee.swarm.errors import BeeArgumentError


def test_single_chunk_matches_direct_cac() -> None:
    """A short payload should produce the same root as a direct
    single-chunk content-address."""
    root = chunk_file(b"hello world")
    direct = make_content_addressed_chunk(b"hello world")
    assert root.address == direct.address
    assert root.span == direct.span


def test_empty_input_errors() -> None:
    chunker = FileChunker()
    with pytest.raises(BeeArgumentError):
        chunker.finalize()


def test_callback_fires_for_every_chunk() -> None:
    seen: list[SealedChunk] = []
    chunker = FileChunker(on_chunk=seen.append)
    payload = bytes([0xAB] * (CHUNK_SIZE * 2))
    chunker.write(payload)
    chunker.finalize()
    # 2 leaves + 1 parent
    assert len(seen) == 3


def test_root_span_is_total_byte_count() -> None:
    payload = bytes([0xCD] * (CHUNK_SIZE * 2 + 10))
    root = chunk_file(payload)
    assert root.span.to_int() == CHUNK_SIZE * 2 + 10


def test_write_in_small_pieces_matches_one_shot() -> None:
    payload = bytes(range(256)) * 50  # 12_800 bytes — across leaves
    one_shot = chunk_file(payload)
    chunker = FileChunker()
    for i in range(0, len(payload), 17):
        chunker.write(payload[i : i + 17])
    piecewise = chunker.finalize()
    assert one_shot.address == piecewise.address
    assert one_shot.span == piecewise.span


def test_three_level_tree_for_max_branches_plus_one() -> None:
    """MAX_BRANCHES + 1 leaves overflow into a 3-level tree."""
    # MAX_BRANCHES leaves fill one parent exactly; +1 forces a third
    # level. Total leaves = 129, total parents = 2 (a 128-fanout one
    # and a 1-fanout one), grandparent = 1 → 132 chunks.
    seen: list[SealedChunk] = []
    chunker = FileChunker(on_chunk=seen.append)
    leaf_count = MAX_BRANCHES + 1
    chunker.write(bytes([0xEE] * (CHUNK_SIZE * leaf_count)))
    root = chunker.finalize()
    assert len(seen) == leaf_count + 2 + 1  # 129 leaves + 2 parents + 1 grandparent
    assert root.span.to_int() == CHUNK_SIZE * leaf_count


def test_partial_trailing_leaf_keeps_payload_size() -> None:
    """A trailing leaf shorter than CHUNK_SIZE should be sealed at
    its actual length (the leaf's span must equal its payload size)."""
    seen: list[SealedChunk] = []
    chunker = FileChunker(on_chunk=seen.append)
    payload = bytes([0x11]) * (CHUNK_SIZE + 100)
    chunker.write(payload)
    chunker.finalize()
    # 2 leaves + 1 parent — one leaf is full, the other is 100 bytes.
    sizes = sorted(c.span.to_int() for c in seen)
    assert CHUNK_SIZE in sizes
    assert 100 in sizes


def test_finalize_twice_raises() -> None:
    chunker = FileChunker()
    chunker.write(b"x")
    chunker.finalize()
    with pytest.raises(BeeArgumentError):
        chunker.finalize()


def test_write_after_finalize_raises() -> None:
    chunker = FileChunker()
    chunker.write(b"x")
    chunker.finalize()
    with pytest.raises(BeeArgumentError):
        chunker.write(b"more")


def test_sealed_chunk_data_concatenates_span_and_payload() -> None:
    seen: list[SealedChunk] = []
    chunker = FileChunker(on_chunk=seen.append)
    chunker.write(b"hi")
    chunker.finalize()
    assert seen[0].data() == seen[0].span.as_bytes() + seen[0].payload
