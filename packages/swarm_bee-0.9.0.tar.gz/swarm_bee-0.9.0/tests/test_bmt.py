"""Tests for BMT chunk addressing."""

from __future__ import annotations

import pytest

from bee.swarm import (
    CHUNK_SIZE,
    MAX_PAYLOAD_SIZE,
    SEGMENT_SIZE,
    SEGMENTS_COUNT,
    BeeArgumentError,
    calculate_chunk_address,
    keccak256,
    make_content_addressed_chunk,
)


def test_keccak256_known_empty_input() -> None:
    # Well-known keccak256("") (Ethereum keccak, not SHA3-256).
    assert (
        keccak256(b"").hex() == "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"
    )


def test_keccak256_returns_32_bytes() -> None:
    assert len(keccak256(b"some-input")) == 32


def test_cac_address_for_known_payload() -> None:
    """Cross-checked against bee-go / bee-rs (`MakeContentAddressedChunk`):
    BMT address of "hello world" is this value.
    """
    chunk = make_content_addressed_chunk(b"hello world")
    assert (
        chunk.address.to_hex() == "92672a471f4419b255d7cb0cf313474a6f5856fb347c5ece85fb706d644b630f"
    )
    assert chunk.span.to_int() == 11
    assert chunk.payload == b"hello world"


def test_cac_rejects_empty_and_oversized_payload() -> None:
    with pytest.raises(BeeArgumentError):
        make_content_addressed_chunk(b"")
    with pytest.raises(BeeArgumentError):
        make_content_addressed_chunk(b"\x00" * (MAX_PAYLOAD_SIZE + 1))


def test_cac_data_returns_span_then_payload() -> None:
    chunk = make_content_addressed_chunk(b"test")
    data = chunk.data()
    assert len(data) == 8 + 4
    assert data[:8] == chunk.span.as_bytes()
    assert data[8:] == b"test"


def test_calculate_chunk_address_rejects_short_data() -> None:
    with pytest.raises(BeeArgumentError):
        calculate_chunk_address(b"\x00" * 4)
    # Span-only with empty payload is OK (zero-padded).
    addr = calculate_chunk_address(b"\x00" * 8)
    assert len(addr) == 32


def test_calculate_chunk_address_rejects_oversized_payload() -> None:
    with pytest.raises(BeeArgumentError):
        calculate_chunk_address(b"\x00" * 8 + b"x" * (CHUNK_SIZE + 1))


def test_bmt_constants_consistent() -> None:
    assert SEGMENTS_COUNT * SEGMENT_SIZE == CHUNK_SIZE
    assert SEGMENTS_COUNT == 128
    assert SEGMENT_SIZE == 32


def test_full_4096_byte_payload_is_accepted() -> None:
    chunk = make_content_addressed_chunk(b"\xaa" * MAX_PAYLOAD_SIZE)
    assert chunk.span.to_int() == MAX_PAYLOAD_SIZE
    assert len(chunk.payload) == MAX_PAYLOAD_SIZE
    assert len(chunk.address.as_bytes()) == 32
