"""Tests for upload/download header preparation."""

from __future__ import annotations

from bee import (
    DownloadOptions,
    RedundancyLevel,
    RedundantUploadOptions,
    UploadOptions,
)
from bee.api.options import (
    CollectionUploadOptions,
    FileUploadOptions,
    prepare_collection_upload_headers,
    prepare_download_headers,
    prepare_file_upload_headers,
    prepare_redundant_upload_headers,
    prepare_upload_headers,
)
from bee.swarm import BatchId, Reference

BATCH = BatchId(b"\xab" * 32)


def _header(headers: list[tuple[str, str]], name: str) -> str | None:
    for k, v in headers:
        if k == name:
            return v
    return None


def test_upload_headers_omit_unset_fields() -> None:
    h = prepare_upload_headers(BATCH)
    assert _header(h, "Swarm-Postage-Batch-Id") == "ab" * 32
    assert _header(h, "Swarm-Pin") is None
    assert _header(h, "Swarm-Encrypt") is None


def test_upload_headers_distinguish_none_from_explicit_false() -> None:
    h = prepare_upload_headers(BATCH, UploadOptions(pin=False))
    assert _header(h, "Swarm-Pin") == "false"

    h = prepare_upload_headers(BATCH, UploadOptions(pin=True))
    assert _header(h, "Swarm-Pin") == "true"

    h = prepare_upload_headers(BATCH, UploadOptions())
    assert _header(h, "Swarm-Pin") is None


def test_upload_tag_zero_omits_header() -> None:
    h = prepare_upload_headers(BATCH, UploadOptions(tag=0))
    assert _header(h, "Swarm-Tag") is None
    h = prepare_upload_headers(BATCH, UploadOptions(tag=42))
    assert _header(h, "Swarm-Tag") == "42"


def test_upload_act_history_address_emits_hex() -> None:
    ref = Reference.from_hex("ab" * 32)
    h = prepare_upload_headers(BATCH, UploadOptions(act=True, act_history_address=ref))
    assert _header(h, "Swarm-Act") == "true"
    assert _header(h, "Swarm-Act-History-Address") == "ab" * 32


def test_redundancy_off_is_omitted() -> None:
    opts = RedundantUploadOptions(redundancy_level=RedundancyLevel.OFF)
    h = prepare_redundant_upload_headers(BATCH, opts)
    assert _header(h, "Swarm-Redundancy-Level") is None


def test_redundancy_medium_emits_header() -> None:
    opts = RedundantUploadOptions(redundancy_level=RedundancyLevel.MEDIUM)
    h = prepare_redundant_upload_headers(BATCH, opts)
    assert _header(h, "Swarm-Redundancy-Level") == "1"


def test_file_upload_emits_size_and_content_type() -> None:
    opts = FileUploadOptions(size=2048, content_type="text/plain")
    h = prepare_file_upload_headers(BATCH, opts)
    assert _header(h, "Content-Length") == "2048"
    assert _header(h, "Content-Type") == "text/plain"


def test_collection_upload_emits_index_and_error_documents() -> None:
    opts = CollectionUploadOptions(
        index_document="index.html",
        error_document="404.html",
    )
    h = prepare_collection_upload_headers(BATCH, opts)
    assert _header(h, "Swarm-Index-Document") == "index.html"
    assert _header(h, "Swarm-Error-Document") == "404.html"


def test_download_no_options_no_headers() -> None:
    assert prepare_download_headers(None) == []
    assert prepare_download_headers(DownloadOptions()) == []


def test_download_act_history_implies_swarm_act_true() -> None:
    ref = Reference.from_hex("00" * 32)
    h = prepare_download_headers(DownloadOptions(act_history_address=ref))
    assert _header(h, "Swarm-Act") == "true"
    assert _header(h, "Swarm-Act-History-Address") == "00" * 32


def test_download_timeout_zero_is_omitted() -> None:
    h = prepare_download_headers(DownloadOptions(timeout_ms=0))
    assert _header(h, "Swarm-Chunk-Retrieval-Timeout") is None
    h = prepare_download_headers(DownloadOptions(timeout_ms=5000))
    assert _header(h, "Swarm-Chunk-Retrieval-Timeout") == "5000"
