"""Tests for ResourceLocator and resolve_path."""

from __future__ import annotations

import pytest

from bee.manifest import (
    MantarayNode,
    ResourceLocator,
    resolve_path,
    target_reference,
)
from bee.swarm import BeeArgumentError, BeeHexError, Reference


def _r32(byte: int) -> Reference:
    return Reference(bytes([byte]) * 32)


# ---- ResourceLocator -----------------------------------------------------


def test_parses_ens_names() -> None:
    loc = ResourceLocator.parse("hello.eth")
    assert loc.is_ens()
    assert not loc.is_reference()
    assert str(loc) == "hello.eth"


def test_parses_hex_reference() -> None:
    hex_str = "ab" * 32
    loc = ResourceLocator.parse(hex_str)
    assert loc.is_reference()
    assert not loc.is_ens()
    assert str(loc) == hex_str


def test_rejects_invalid_hex() -> None:
    with pytest.raises(BeeHexError):
        ResourceLocator.parse("not-hex")


def test_from_reference_round_trip() -> None:
    r = Reference.from_hex("cd" * 32)
    loc = ResourceLocator.from_reference(r)
    assert str(loc) == r.to_hex()
    assert loc.reference == r


def test_from_ens_rejects_empty() -> None:
    with pytest.raises(BeeArgumentError):
        ResourceLocator.from_ens("")


def test_from_ens_accepts_subdomains() -> None:
    loc = ResourceLocator.from_ens("docs.example.eth")
    assert loc.ens == "docs.example.eth"


# ---- resolve_path --------------------------------------------------------


def test_resolve_path_finds_added_fork() -> None:
    m = MantarayNode()
    target = _r32(0xAA)
    m.add_fork(b"index.html", target)
    got = resolve_path(m, "/index.html")
    assert got == target


def test_resolve_path_handles_nested_paths() -> None:
    m = MantarayNode()
    leaf = _r32(0xBB)
    m.add_fork(b"assets/logo.png", leaf)
    got = resolve_path(m, "assets/logo.png")
    assert got == leaf


def test_resolve_path_with_leading_slash_works() -> None:
    m = MantarayNode()
    leaf = _r32(0xCC)
    m.add_fork(b"a", leaf)
    got = resolve_path(m, "/a")
    assert got == leaf


def test_resolve_path_errors_for_missing_path() -> None:
    m = MantarayNode()
    with pytest.raises(BeeArgumentError):
        resolve_path(m, "/nope")


def test_target_reference_returns_none_for_null_target() -> None:
    n = MantarayNode()  # default target is NULL_ADDRESS
    assert target_reference(n) is None


def test_target_reference_extracts_ref_for_leaf() -> None:
    m = MantarayNode()
    m.add_fork(b"file", _r32(0xEE))
    leaf = m.find(b"file")
    assert leaf is not None
    r = target_reference(leaf)
    assert r is not None
    assert r.as_bytes() == bytes([0xEE] * 32)
