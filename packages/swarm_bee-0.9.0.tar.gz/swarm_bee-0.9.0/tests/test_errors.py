"""Exception-hierarchy tests."""

from __future__ import annotations

from bee import (
    BeeArgumentError,
    BeeError,
    BeeHexError,
    BeeLengthMismatchError,
    BeeResponseError,
)


def test_length_mismatch_message_format() -> None:
    e = BeeLengthMismatchError("Reference", [32, 64], 16)
    assert "Reference" in str(e)
    assert "16" in str(e)
    assert "[32, 64]" in str(e)


def test_argument_error_subclasses_bee_error() -> None:
    assert issubclass(BeeArgumentError, BeeError)
    assert issubclass(BeeLengthMismatchError, BeeArgumentError)
    assert issubclass(BeeHexError, BeeArgumentError)


def test_response_error_captures_fields() -> None:
    e = BeeResponseError(
        method="GET",
        url="http://example.com/health",
        status=503,
        status_text="503 Service Unavailable",
        body=b"down for maintenance",
    )
    assert e.status == 503
    assert e.method == "GET"
    assert e.body == b"down for maintenance"
    assert "GET http://example.com/health: 503" in str(e)
