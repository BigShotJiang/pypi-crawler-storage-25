"""In-memory collection helpers used by ``/bzz`` collection uploads.

Mirrors the in-memory pieces of bee-rs ``file::bzz``: ``CollectionEntry``,
``collection_size``, ``build_tar_archive``, ``read_directory_entries``,
and ``hash_collection_entries`` (offline manifest address prediction).
"""

from __future__ import annotations

import io
import tarfile
from dataclasses import dataclass
from pathlib import Path

from ..manifest import MantarayNode, populate_self_addresses
from ..swarm.errors import BeeArgumentError
from ..swarm.file_chunker import chunk_file
from ..swarm.typed_bytes import Reference


@dataclass(frozen=True, slots=True)
class CollectionEntry:
    """One entry of an in-memory collection: a tar path plus raw bytes.

    Mirrors bee-go ``CollectionEntry`` and bee-js's ``Collection`` items.
    """

    #: Relative path inside the collection (e.g. ``"index.html"`` or
    #: ``"assets/logo.png"``). Forward slashes only.
    path: str
    #: File contents.
    data: bytes


def collection_size(entries: list[CollectionEntry]) -> int:
    """Cumulative byte size of the entries' data — equivalent to bee-js
    ``getCollectionSize``."""
    return sum(len(e.data) for e in entries)


def read_directory_entries(directory: str | Path) -> list[CollectionEntry]:
    """Walk ``directory`` recursively and collect every regular file as
    a :class:`CollectionEntry` with its filesystem-relative path.

    Mirrors bee-go's ``filepath.Walk`` in ``UploadCollection``: symlinks
    and special files are skipped, paths are forward-slash form, and
    the result is sorted by path so the resulting tar (and downstream
    Mantaray address) is deterministic.
    """
    root = Path(directory).expanduser().resolve()
    if not root.is_dir():
        raise BeeArgumentError(f"not a directory: {directory!r}")
    out: list[CollectionEntry] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(root).as_posix()
        out.append(CollectionEntry(path=rel, data=path.read_bytes()))
    return out


def hash_collection_entries(entries: list[CollectionEntry]) -> Reference:
    """Predict the Mantaray manifest address of ``entries`` offline.

    Each entry's data is content-addressed via :class:`FileChunker`
    (a multi-level BMT tree if the entry exceeds 4096 bytes); those
    root references are inserted into a fresh Mantaray as
    ``(path, ref, None)`` tuples; the manifest's self-address is
    computed and returned.

    .. note::
       The manifest itself must still fit in a single chunk (≤ 4096
       bytes after marshaling). bee-rs's ``hash_collection_entries``
       is also known to diverge from bee-go's server-side Mantaray
       for some inputs (default ``index.html`` handling) — we
       inherit that limitation.
    """
    manifest = MantarayNode()
    for entry in entries:
        if len(entry.data) == 0:
            raise BeeArgumentError(f"empty entry data: path={entry.path!r}")
        root = chunk_file(entry.data)
        manifest.add_fork(entry.path.encode("utf-8"), root.address, None)
    addr = populate_self_addresses(manifest)
    return Reference(addr)


def build_tar_archive(entries: list[CollectionEntry]) -> bytes:
    """Encode the entries as a USTAR archive in memory.

    Each entry is written with mode ``0o644``. Layout matches bee-go's
    ``UploadCollectionEntries`` and bee-rs's ``build_tar_archive``.
    """
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.USTAR_FORMAT) as tw:
        for e in entries:
            info = tarfile.TarInfo(name=e.path)
            info.size = len(e.data)
            info.mode = 0o644
            info.type = tarfile.REGTYPE
            tw.addfile(info, io.BytesIO(e.data))
    return buf.getvalue()


__all__ = [
    "CollectionEntry",
    "build_tar_archive",
    "collection_size",
    "hash_collection_entries",
    "read_directory_entries",
]
