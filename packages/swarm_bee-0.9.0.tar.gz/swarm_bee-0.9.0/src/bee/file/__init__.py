"""``/bytes``, ``/chunks``, ``/soc``, ``/bzz`` upload + download.

Mirrors ``pkg/file`` in bee-go and ``file::{data,chunk,soc,bzz}`` in
bee-rs. Feed read/write helpers land in 0.5.
"""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path

from .._inner import _AsyncInner, _decode_json, _SyncInner
from ..api.options import (
    CollectionUploadOptions,
    DownloadOptions,
    FileUploadOptions,
    RedundantUploadOptions,
    UploadOptions,
    prepare_collection_upload_headers,
    prepare_download_headers,
    prepare_file_upload_headers,
    prepare_redundant_upload_headers,
    prepare_upload_headers,
)
from ..api.result import FileHeaders, ReferenceInformation, UploadResult
from ..manifest import MantarayNode
from ..swarm.errors import BeeArgumentError, BeeJsonError
from ..swarm.soc import (
    SingleOwnerChunk,
    calculate_single_owner_chunk_address,
    unmarshal_single_owner_chunk,
)
from ..swarm.typed_bytes import (
    BatchId,
    EthAddress,
    Identifier,
    Reference,
    Signature,
)
from ._chunks_stream import AsyncChunkStream
from ._collection import (
    CollectionEntry,
    build_tar_archive,
    collection_size,
    hash_collection_entries,
    read_directory_entries,
)
from ._stream import OnStreamProgress, StreamProgress

#: Content-Type sent with raw-bytes uploads.
_BYTES_CONTENT_TYPE = "application/octet-stream"
#: Content-Type sent with collection (tar) uploads.
_TAR_CONTENT_TYPE = "application/x-tar"


def _parse_upload_response(payload: object) -> str:
    """Pull the ``"reference"`` field out of an upload response body."""
    if not isinstance(payload, dict) or "reference" not in payload:
        raise BeeJsonError(f"missing 'reference' in upload response: {payload!r}")
    ref = payload["reference"]
    if not isinstance(ref, str):
        raise BeeJsonError(f"'reference' is not a string: {ref!r}")
    return ref


def _content_length_from_headers(headers: Mapping[str, str]) -> int:
    """Extract ``Content-Length`` from a headers mapping. Raises
    :class:`BeeArgumentError` if missing or non-integer."""
    raw = headers.get("content-length") or headers.get("Content-Length")
    if raw is None:
        raise BeeArgumentError("missing Content-Length")
    try:
        return int(raw)
    except ValueError as e:
        raise BeeArgumentError(f"invalid Content-Length: {raw!r}") from e


class AsyncFileApi:
    """Async file-domain handle. Reachable as :attr:`bee.AsyncBee.file`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _AsyncInner) -> None:
        self._inner = inner

    async def chunks_stream(
        self, batch_id: BatchId, tag: int | None = None
    ) -> AsyncChunkStream:
        """Open a ``WS /chunks/stream`` upload session.

        - ``batch_id`` is sent in ``Swarm-Postage-Batch-Id`` and stamps
          every chunk uploaded over this socket.
        - ``tag`` (optional) becomes the ``swarm-tag`` query parameter.
          Without a tag, chunks are forwarded to the network as they
          arrive.

        Returns an :class:`AsyncChunkStream` whose
        :meth:`AsyncChunkStream.send_chunk` blocks until the server
        acks each frame. Use as an async context manager or call
        :meth:`AsyncChunkStream.close` for graceful shutdown.
        """
        return await AsyncChunkStream.open(self._inner.base_url, batch_id, tag)

    async def save_manifest_recursively(
        self,
        node: MantarayNode,
        batch_id: BatchId,
        opts: UploadOptions | None = None,
    ) -> UploadResult:
        """Persist a :class:`MantarayNode` tree depth-first.

        Each child is uploaded first (so its ``self_address`` is
        populated), then the node itself is marshaled and uploaded
        via ``POST /bytes``. Returns the root upload result.
        """
        from ._stream import save_manifest_recursively as _save

        return await _save(self, node, batch_id, opts)

    async def stream_directory(
        self,
        batch_id: BatchId,
        directory: str | Path,
        opts: CollectionUploadOptions | None = None,
        on_progress: OnStreamProgress | None = None,
    ) -> UploadResult:
        """Stream a directory upload chunk-by-chunk.

        Walks ``directory``, content-addresses each file via
        :class:`FileChunker`, uploads chunks via ``POST /chunks`` with
        bounded concurrency, and persists a Mantaray manifest pointing
        at every file's root reference. ``on_progress`` (when set)
        fires once per uploaded chunk with ``(processed, total)``.
        """
        from ._stream import stream_directory as _stream

        return await _stream(self, batch_id, directory, opts, on_progress)

    async def stream_collection_entries(
        self,
        batch_id: BatchId,
        entries: list[CollectionEntry],
        opts: CollectionUploadOptions | None = None,
        on_progress: OnStreamProgress | None = None,
    ) -> UploadResult:
        """Same as :meth:`stream_directory` but for pre-built entries."""
        from ._stream import stream_collection_entries as _stream

        return await _stream(self, batch_id, entries, opts, on_progress)

    async def upload_data(
        self,
        batch_id: BatchId,
        data: bytes,
        opts: RedundantUploadOptions | None = None,
    ) -> UploadResult:
        """Upload raw bytes via ``POST /bytes``.

        The body is sent as ``application/octet-stream``. Returns an
        :class:`UploadResult` with the content reference, optional tag
        UID, and (when ACT was requested) the history address.
        """
        headers = prepare_redundant_upload_headers(batch_id, opts)
        headers.append(("Content-Type", _BYTES_CONTENT_TYPE))
        response = await self._inner.send("POST", "bytes", content=data, headers=headers)
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    async def download_data(
        self,
        reference: Reference,
        opts: DownloadOptions | None = None,
    ) -> bytes:
        """Download raw bytes via ``GET /bytes/{ref}``.

        Returns the full body in memory. For multi-GB references, drive
        the underlying :class:`httpx.AsyncClient` directly via
        ``client._inner._http`` (a documented escape hatch will land in
        a later milestone).
        """
        headers = prepare_download_headers(opts)
        response = await self._inner.send("GET", f"bytes/{reference.to_hex()}", headers=headers)
        return response.content

    async def probe_data(self, reference: Reference) -> ReferenceInformation:
        """Probe the size of the data behind a ``/bytes`` reference using
        ``HEAD``. Mirrors bee-js ``Bee.probeData``."""
        response = await self._inner.send("HEAD", f"bytes/{reference.to_hex()}")
        return ReferenceInformation(content_length=_content_length_from_headers(response.headers))

    async def upload_chunk(
        self,
        batch_id: BatchId,
        data: bytes,
        opts: UploadOptions | None = None,
    ) -> UploadResult:
        """Upload a single raw chunk (``span || payload``) via
        ``POST /chunks``. ``data`` is sent as
        ``application/octet-stream``."""
        headers = prepare_upload_headers(batch_id, opts)
        headers.append(("Content-Type", _BYTES_CONTENT_TYPE))
        response = await self._inner.send("POST", "chunks", content=data, headers=headers)
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    async def download_chunk(
        self,
        reference: Reference,
        opts: DownloadOptions | None = None,
    ) -> bytes:
        """Download a single chunk's bytes via ``GET /chunks/{ref}``."""
        headers = prepare_download_headers(opts)
        response = await self._inner.send("GET", f"chunks/{reference.to_hex()}", headers=headers)
        return response.content

    async def upload_soc(
        self,
        batch_id: BatchId,
        owner: EthAddress,
        identifier: Identifier,
        signature: Signature,
        data: bytes,
        opts: UploadOptions | None = None,
    ) -> UploadResult:
        """Upload a Single Owner Chunk to ``POST /soc/{owner}/{id}?sig=…``.

        ``data`` must be the SOC body in wire form: ``span (8) || payload``.
        Mirrors bee-go ``(*Service).UploadSOC``.
        """
        path = f"soc/{owner.to_hex()}/{identifier.to_hex()}"
        headers = prepare_upload_headers(batch_id, opts)
        headers.append(("Content-Type", _BYTES_CONTENT_TYPE))
        response = await self._inner.send(
            "POST",
            path,
            content=data,
            headers=headers,
            params={"sig": signature.to_hex()},
        )
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    async def download_soc(
        self,
        owner: EthAddress,
        identifier: Identifier,
    ) -> SingleOwnerChunk:
        """Fetch the SOC at ``keccak256(identifier || owner)``, parse
        the wire form, and verify the recovered owner matches.
        """
        address = calculate_single_owner_chunk_address(identifier, owner)
        body = await self.download_chunk(address)
        return unmarshal_single_owner_chunk(body, address)

    async def upload_file(
        self,
        batch_id: BatchId,
        data: bytes,
        name: str = "",
        content_type: str = "",
        opts: FileUploadOptions | None = None,
    ) -> UploadResult:
        """Upload a single file via ``POST /bzz``.

        ``name`` is sent as the ``name=`` query parameter (Bee uses it
        as the filename in ``Content-Disposition`` on download). When
        ``content_type`` is empty and ``opts`` does not specify one,
        ``application/octet-stream`` is used.
        """
        headers = prepare_file_upload_headers(batch_id, opts)
        # The helper already added Content-Type if opts.content_type
        # was set; only fall back to the content_type arg / default.
        if opts is None or opts.content_type is None:
            headers.append(("Content-Type", content_type or _BYTES_CONTENT_TYPE))
        params = {"name": name} if name else None
        response = await self._inner.send(
            "POST", "bzz", content=data, headers=headers, params=params
        )
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    async def download_file(
        self,
        reference: Reference,
        opts: DownloadOptions | None = None,
    ) -> tuple[bytes, FileHeaders]:
        """Download a file via ``GET /bzz/{ref}``.

        Returns the body bytes plus a parsed :class:`FileHeaders`
        (filename, content-type, tag UID).
        """
        headers = prepare_download_headers(opts)
        response = await self._inner.send("GET", f"bzz/{reference.to_hex()}", headers=headers)
        return response.content, FileHeaders.from_response(response.headers)

    async def download_file_path(
        self,
        reference: Reference,
        path: str,
        opts: DownloadOptions | None = None,
    ) -> tuple[bytes, FileHeaders]:
        """Download a path inside a collection via
        ``GET /bzz/{ref}/{path}``."""
        rel = path.lstrip("/")
        headers = prepare_download_headers(opts)
        response = await self._inner.send("GET", f"bzz/{reference.to_hex()}/{rel}", headers=headers)
        return response.content, FileHeaders.from_response(response.headers)

    async def upload_collection_entries(
        self,
        batch_id: BatchId,
        entries: list[CollectionEntry],
        opts: CollectionUploadOptions | None = None,
    ) -> UploadResult:
        """Upload an in-memory collection as a tar stream via
        ``POST /bzz``. Mirrors bee-go ``UploadCollectionEntries`` and
        bee-js ``bzz.uploadCollection``.
        """
        tar_bytes = build_tar_archive(entries)
        headers = prepare_collection_upload_headers(batch_id, opts)
        headers.append(("Content-Type", _TAR_CONTENT_TYPE))
        headers.append(("Swarm-Collection", "true"))
        response = await self._inner.send("POST", "bzz", content=tar_bytes, headers=headers)
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    async def upload_collection(
        self,
        batch_id: BatchId,
        directory: str | Path,
        opts: CollectionUploadOptions | None = None,
    ) -> UploadResult:
        """Walk ``directory``, build a tar archive of every regular
        file (relative paths preserved, sorted), and upload via
        ``POST /bzz``. Symlinks and special files are skipped.
        Mirrors bee-go ``UploadCollection``.
        """
        return await self.upload_collection_entries(
            batch_id, read_directory_entries(directory), opts
        )


class FileApi:
    """Sync file-domain handle. Reachable as :attr:`bee.Bee.file`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _SyncInner) -> None:
        self._inner = inner

    def upload_data(
        self,
        batch_id: BatchId,
        data: bytes,
        opts: RedundantUploadOptions | None = None,
    ) -> UploadResult:
        """Upload raw bytes via ``POST /bytes``."""
        headers = prepare_redundant_upload_headers(batch_id, opts)
        headers.append(("Content-Type", _BYTES_CONTENT_TYPE))
        response = self._inner.send("POST", "bytes", content=data, headers=headers)
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    def download_data(
        self,
        reference: Reference,
        opts: DownloadOptions | None = None,
    ) -> bytes:
        """Download raw bytes via ``GET /bytes/{ref}``."""
        headers = prepare_download_headers(opts)
        response = self._inner.send("GET", f"bytes/{reference.to_hex()}", headers=headers)
        return response.content

    def probe_data(self, reference: Reference) -> ReferenceInformation:
        """Probe the size of the data behind a ``/bytes`` reference using
        ``HEAD``."""
        response = self._inner.send("HEAD", f"bytes/{reference.to_hex()}")
        return ReferenceInformation(content_length=_content_length_from_headers(response.headers))

    def upload_chunk(
        self,
        batch_id: BatchId,
        data: bytes,
        opts: UploadOptions | None = None,
    ) -> UploadResult:
        """Upload a single raw chunk (``span || payload``) via
        ``POST /chunks``."""
        headers = prepare_upload_headers(batch_id, opts)
        headers.append(("Content-Type", _BYTES_CONTENT_TYPE))
        response = self._inner.send("POST", "chunks", content=data, headers=headers)
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    def download_chunk(
        self,
        reference: Reference,
        opts: DownloadOptions | None = None,
    ) -> bytes:
        """Download a single chunk's bytes via ``GET /chunks/{ref}``."""
        headers = prepare_download_headers(opts)
        response = self._inner.send("GET", f"chunks/{reference.to_hex()}", headers=headers)
        return response.content

    def upload_soc(
        self,
        batch_id: BatchId,
        owner: EthAddress,
        identifier: Identifier,
        signature: Signature,
        data: bytes,
        opts: UploadOptions | None = None,
    ) -> UploadResult:
        """Upload a Single Owner Chunk to ``POST /soc/{owner}/{id}?sig=…``."""
        path = f"soc/{owner.to_hex()}/{identifier.to_hex()}"
        headers = prepare_upload_headers(batch_id, opts)
        headers.append(("Content-Type", _BYTES_CONTENT_TYPE))
        response = self._inner.send(
            "POST",
            path,
            content=data,
            headers=headers,
            params={"sig": signature.to_hex()},
        )
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    def download_soc(
        self,
        owner: EthAddress,
        identifier: Identifier,
    ) -> SingleOwnerChunk:
        """Fetch the SOC at ``keccak256(identifier || owner)``, parse
        the wire form, and verify the recovered owner matches."""
        address = calculate_single_owner_chunk_address(identifier, owner)
        body = self.download_chunk(address)
        return unmarshal_single_owner_chunk(body, address)

    def upload_file(
        self,
        batch_id: BatchId,
        data: bytes,
        name: str = "",
        content_type: str = "",
        opts: FileUploadOptions | None = None,
    ) -> UploadResult:
        """Upload a single file via ``POST /bzz``."""
        headers = prepare_file_upload_headers(batch_id, opts)
        if opts is None or opts.content_type is None:
            headers.append(("Content-Type", content_type or _BYTES_CONTENT_TYPE))
        params = {"name": name} if name else None
        response = self._inner.send("POST", "bzz", content=data, headers=headers, params=params)
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    def download_file(
        self,
        reference: Reference,
        opts: DownloadOptions | None = None,
    ) -> tuple[bytes, FileHeaders]:
        """Download a file via ``GET /bzz/{ref}``."""
        headers = prepare_download_headers(opts)
        response = self._inner.send("GET", f"bzz/{reference.to_hex()}", headers=headers)
        return response.content, FileHeaders.from_response(response.headers)

    def download_file_path(
        self,
        reference: Reference,
        path: str,
        opts: DownloadOptions | None = None,
    ) -> tuple[bytes, FileHeaders]:
        """Download a path inside a collection via
        ``GET /bzz/{ref}/{path}``."""
        rel = path.lstrip("/")
        headers = prepare_download_headers(opts)
        response = self._inner.send("GET", f"bzz/{reference.to_hex()}/{rel}", headers=headers)
        return response.content, FileHeaders.from_response(response.headers)

    def upload_collection_entries(
        self,
        batch_id: BatchId,
        entries: list[CollectionEntry],
        opts: CollectionUploadOptions | None = None,
    ) -> UploadResult:
        """Upload an in-memory collection as a tar stream via
        ``POST /bzz``."""
        tar_bytes = build_tar_archive(entries)
        headers = prepare_collection_upload_headers(batch_id, opts)
        headers.append(("Content-Type", _TAR_CONTENT_TYPE))
        headers.append(("Swarm-Collection", "true"))
        response = self._inner.send("POST", "bzz", content=tar_bytes, headers=headers)
        payload = _decode_json(response.content)
        return UploadResult.from_response(_parse_upload_response(payload), response.headers)

    def upload_collection(
        self,
        batch_id: BatchId,
        directory: str | Path,
        opts: CollectionUploadOptions | None = None,
    ) -> UploadResult:
        """Walk ``directory`` and upload every regular file as a tar
        collection via ``POST /bzz``."""
        return self.upload_collection_entries(batch_id, read_directory_entries(directory), opts)


__all__ = [
    "AsyncChunkStream",
    "AsyncFileApi",
    "CollectionEntry",
    "FileApi",
    "OnStreamProgress",
    "StreamProgress",
    "build_tar_archive",
    "collection_size",
    "hash_collection_entries",
    "read_directory_entries",
]
