"""``WS /chunks/stream`` — websocket-driven chunk upload session.

Mirrors bee-rs ``file::chunks_stream`` and bee-go's
``chunks/stream`` server-side handler: each chunk is sent as a binary
WebSocket frame and the server replies with a single-byte ``0x00``
ack. A non-zero binary frame or a text frame is treated as an error
from the server.

Tag-bound uploads (``swarm-tag`` query) keep chunks local until the
socket closes; tag-less uploads forward each chunk to the network
as it arrives.
"""

from __future__ import annotations

from types import TracebackType
from typing import TYPE_CHECKING

from typing_extensions import Self

from .._ws import _build_ws_url
from ..swarm.errors import BeeArgumentError, BeeTransportError
from ..swarm.typed_bytes import BatchId

if TYPE_CHECKING:
    from websockets.asyncio.client import ClientConnection


class AsyncChunkStream:
    """Active ``/chunks/stream`` upload session.

    Each :meth:`send_chunk` sends one binary frame and awaits the
    server's ``0x00`` ack before returning. Use as an async context
    manager or call :meth:`close` for graceful shutdown.
    """

    __slots__ = ("_closed", "_ws")

    def __init__(self, ws: ClientConnection) -> None:
        self._ws = ws
        self._closed = False

    @classmethod
    async def open(
        cls, base_url: str, batch_id: BatchId, tag: int | None = None
    ) -> Self:
        """Open a session against ``base_url + "/chunks/stream"``.

        ``Swarm-Postage-Batch-Id`` is sent as a header; ``tag`` (when
        not ``None``) becomes the ``swarm-tag`` query param.
        """
        from websockets.asyncio.client import connect
        from websockets.exceptions import WebSocketException

        path = "chunks/stream"
        if tag is not None:
            path = f"{path}?swarm-tag={tag}"
        url = _build_ws_url(base_url, path)
        try:
            ws = await connect(
                url,
                additional_headers={"swarm-postage-batch-id": batch_id.to_hex()},
            )
        except (OSError, WebSocketException) as e:
            raise BeeTransportError(f"chunks_stream connect: {e}") from e
        return cls(ws)

    async def send_chunk(self, chunk: bytes) -> None:
        """Send one chunk (``span || payload``) and await the ack.

        Raises :class:`BeeArgumentError` if the session is closed or
        the server replies with anything other than the empty / zero
        ack.
        """
        from websockets.exceptions import ConnectionClosed, WebSocketException

        if self._closed:
            raise BeeArgumentError("chunk stream is closed")
        try:
            await self._ws.send(chunk)
        except WebSocketException as e:
            raise BeeTransportError(f"websocket send: {e}") from e

        # Wait for the next non-control frame and validate it as the
        # ack. websockets' asyncio client transparently handles ping /
        # pong frames so they shouldn't surface here, but recv()
        # returning bytes vs. str distinguishes binary from text.
        while True:
            try:
                msg = await self._ws.recv()
            except ConnectionClosed as e:
                self._closed = True
                raise BeeArgumentError(f"chunk stream closed: {e}") from e
            except WebSocketException as e:
                raise BeeTransportError(f"websocket recv: {e}") from e
            if isinstance(msg, str):
                raise BeeArgumentError(f"chunk stream server error: {msg}")
            if not msg or msg == b"\x00":
                return
            raise BeeArgumentError(
                f"chunk stream unexpected ack bytes: {msg!r}"
            )

    async def close(self) -> None:
        """Close the WebSocket gracefully. Idempotent."""
        if self._closed:
            return
        self._closed = True
        await self._ws.close()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()


__all__ = ["AsyncChunkStream"]
