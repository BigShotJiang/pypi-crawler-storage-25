"""Streaming directory upload + recursive Mantaray persistence.

Mirrors bee-rs ``file::stream`` and bee-js ``Bee.streamDirectory``.

For each regular file under a directory, content-addresses it via
:class:`FileChunker`, uploads the resulting chunks via ``POST /chunks``
with bounded concurrency, then assembles a Mantaray manifest with one
fork per file. The manifest is persisted depth-first via
:func:`save_manifest_recursively`.

Differences from bee-js:
- File contents are read fully into memory before being fed to the
  chunker (matching bee-rs).
- Per-file metadata (Content-Type / Filename) is left empty on
  Mantaray forks. The tar-based ``upload_collection_entries`` path
  lets Bee infer types server-side.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from ..api.options import CollectionUploadOptions, RedundantUploadOptions, UploadOptions
from ..api.result import UploadResult
from ..manifest import MantarayNode, marshal
from ..swarm.bmt import CHUNK_SIZE
from ..swarm.errors import BeeArgumentError
from ..swarm.file_chunker import MAX_BRANCHES, FileChunker, SealedChunk
from ..swarm.typed_bytes import BatchId, Reference
from ._collection import CollectionEntry, read_directory_entries

if TYPE_CHECKING:
    from . import AsyncFileApi


#: Default in-flight upload cap (matches bee-rs / bee-js).
STREAM_CONCURRENCY: int = 64


@dataclass(frozen=True, slots=True)
class StreamProgress:
    """Per-chunk upload signal emitted by ``stream_directory``.

    Mirrors bee-js ``UploadProgress``.
    """

    #: Total chunks the upload will produce (computed before upload).
    total: int
    #: Chunks uploaded so far (post-this-callback).
    processed: int


OnStreamProgress = Callable[[StreamProgress], None]


def total_chunks_for(num_bytes: int) -> int:
    """Total chunks (leaves + intermediates) a ``num_bytes`` file will
    produce in the Swarm BMT chunker.

    Mirrors bee-js ``totalChunks(size)``. Empty input → ``0``.
    """
    if num_bytes <= 0:
        return 0
    leaves = -(-num_bytes // CHUNK_SIZE)  # ceil(num_bytes / CHUNK_SIZE)
    total = leaves
    while leaves > 1:
        leaves = -(-leaves // MAX_BRANCHES)  # ceil
        total += leaves
    return total


def _seal_entry(data: bytes) -> tuple[Reference, list[SealedChunk]]:
    """Run the chunker on ``data`` and return ``(root, sealed)``."""
    sealed: list[SealedChunk] = []
    chunker = FileChunker(on_chunk=sealed.append)
    chunker.write(data)
    root = chunker.finalize()
    return root.address, sealed


async def _upload_chunks_bounded(
    api: AsyncFileApi,
    batch_id: BatchId,
    sealed: list[SealedChunk],
    upload_opts: UploadOptions | None,
    semaphore: asyncio.Semaphore,
    bump: Callable[[], None],
) -> None:
    async def upload_one(chunk: SealedChunk) -> None:
        async with semaphore:
            await api.upload_chunk(batch_id, chunk.data(), upload_opts)
            bump()

    await asyncio.gather(*(upload_one(c) for c in sealed))


def _reference_to_self_address(ref: Reference) -> bytes:
    """Truncate a 32-or-64-byte reference to its 32-byte chunk address."""
    raw = ref.as_bytes()
    if len(raw) < 32:
        raise BeeArgumentError("manifest child reference < 32 bytes")
    return raw[:32]


async def save_manifest_recursively(
    api: AsyncFileApi,
    node: MantarayNode,
    batch_id: BatchId,
    opts: UploadOptions | None = None,
) -> UploadResult:
    """Persist a :class:`MantarayNode` tree depth-first.

    Each child is uploaded first (so its ``self_address`` is
    populated), then the node itself is marshaled and uploaded via
    ``POST /bytes``. The resulting reference is stored on the node's
    ``self_address`` and returned to the caller.
    """
    return await _save_inner(api, node, batch_id, opts)


async def _save_inner(
    api: AsyncFileApi,
    node: MantarayNode,
    batch_id: BatchId,
    opts: UploadOptions | None,
) -> UploadResult:
    # Save children first so each fork's self_address is populated
    # before we marshal this node.
    for fork in node.forks.values():
        result = await _save_inner(api, fork.node, batch_id, opts)
        fork.node.self_address = _reference_to_self_address(result.reference)
    body = marshal(node)
    redundant: RedundantUploadOptions | None = None
    if opts is not None:
        redundant = RedundantUploadOptions(
            act=opts.act,
            act_history_address=opts.act_history_address,
            pin=opts.pin,
            encrypt=opts.encrypt,
            tag=opts.tag,
            deferred=opts.deferred,
            redundancy_level=None,
        )
    result = await api.upload_data(batch_id, body, redundant)
    node.self_address = _reference_to_self_address(result.reference)
    return result


async def stream_directory(
    api: AsyncFileApi,
    batch_id: BatchId,
    directory: str | Path,
    opts: CollectionUploadOptions | None = None,
    on_progress: OnStreamProgress | None = None,
) -> UploadResult:
    """Stream a directory upload chunk-by-chunk.

    See module docstring for the full algorithm. ``on_progress``
    fires once per uploaded chunk with ``(processed, total)``.
    """
    entries = read_directory_entries(directory)
    return await stream_collection_entries(api, batch_id, entries, opts, on_progress)


async def stream_collection_entries(
    api: AsyncFileApi,
    batch_id: BatchId,
    entries: list[CollectionEntry],
    opts: CollectionUploadOptions | None = None,
    on_progress: OnStreamProgress | None = None,
) -> UploadResult:
    """Same as :func:`stream_directory` but for pre-built in-memory entries."""
    total_chunks = sum(total_chunks_for(len(e.data)) for e in entries)
    processed = 0
    semaphore = asyncio.Semaphore(STREAM_CONCURRENCY)

    def bump() -> None:
        nonlocal processed
        processed += 1
        if on_progress is not None:
            on_progress(StreamProgress(total=total_chunks, processed=processed))

    upload_opts: UploadOptions | None = None
    if opts is not None:
        upload_opts = UploadOptions(
            act=opts.act,
            act_history_address=opts.act_history_address,
            pin=opts.pin,
            encrypt=opts.encrypt,
            tag=opts.tag,
            deferred=opts.deferred,
        )

    manifest = MantarayNode()
    has_index_html = False

    for entry in entries:
        if not entry.data:
            raise BeeArgumentError(f"empty file: {entry.path!r}")
        root_ref, sealed = _seal_entry(entry.data)
        await _upload_chunks_bounded(
            api, batch_id, sealed, upload_opts, semaphore, bump
        )
        manifest.add_fork(entry.path.encode("utf-8"), root_ref, None)
        if entry.path == "index.html":
            has_index_html = True

    # Apply index_document / error_document metadata on the root fork.
    index_doc = opts.index_document if opts else None
    error_doc = opts.error_document if opts else None
    if has_index_html or index_doc is not None or error_doc is not None:
        metadata: dict[str, str] = {}
        if index_doc is not None:
            metadata["website-index-document"] = index_doc
        elif has_index_html:
            metadata["website-index-document"] = "index.html"
        if error_doc is not None:
            metadata["website-error-document"] = error_doc
        manifest.add_fork(b"/", None, metadata)

    return await save_manifest_recursively(api, manifest, batch_id, upload_opts)


__all__ = [
    "STREAM_CONCURRENCY",
    "OnStreamProgress",
    "StreamProgress",
    "save_manifest_recursively",
    "stream_collection_entries",
    "stream_directory",
    "total_chunks_for",
]
