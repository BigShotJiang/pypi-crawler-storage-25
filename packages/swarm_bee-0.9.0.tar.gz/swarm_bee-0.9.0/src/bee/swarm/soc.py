"""Single Owner Chunks (SOC).

Mirrors bee-rs ``swarm::soc`` and bee-go ``pkg/swarm/soc.go``.

A SOC is a chunk addressed by ``keccak256(identifier || ownerAddress)``
rather than by content hash. The owner signs ``identifier ||
cacAddress`` (the BMT address of ``span || payload``) using the
Ethereum signed-message scheme — bee-go's first cut used raw keccak
with ``V ∈ {0, 1}`` and every SOC upload returned 401, so this is one
of the spots that *will* break against a live node if you get it
wrong.
"""

from __future__ import annotations

from dataclasses import dataclass

from .bmt import MAX_PAYLOAD_SIZE, calculate_chunk_address, keccak256
from .errors import BeeArgumentError
from .keys import PrivateKey, recover_public_key
from .typed_bytes import (
    IDENTIFIER_LENGTH,
    SIGNATURE_LENGTH,
    SPAN_LENGTH,
    EthAddress,
    Identifier,
    Reference,
    Signature,
    Span,
)


@dataclass(frozen=True, slots=True)
class SingleOwnerChunk:
    """A single-owner chunk.

    The signature commits to ``identifier || cacAddress``, where
    ``cacAddress`` is the BMT address of ``span || payload``.
    """

    #: SOC identifier.
    identifier: Identifier
    #: 65-byte signature over ``identifier || cacAddress``.
    signature: Signature
    #: Recovered owner address (last 20 bytes of ``keccak(pubkey)``).
    owner: EthAddress
    #: 8-byte little-endian span.
    span: Span
    #: Raw payload (≤ 4096 bytes).
    payload: bytes

    def address(self) -> Reference:
        """Compute this SOC's address: ``keccak256(identifier || owner)``."""
        return calculate_single_owner_chunk_address(self.identifier, self.owner)

    def data(self) -> bytes:
        """Wire form: ``identifier(32) || signature(65) || span(8) ||
        payload``. Suitable as the body of ``POST /soc/{owner}/{id}``
        (with ``cacAddress`` derived from `span || payload`)."""
        return (
            self.identifier.as_bytes()
            + self.signature.as_bytes()
            + self.span.as_bytes()
            + self.payload
        )


def calculate_single_owner_chunk_address(identifier: Identifier, owner: EthAddress) -> Reference:
    """SOC address = ``keccak256(identifier || owner)``.

    Mirrors bee-js ``calculateSingleOwnerChunkAddress``.
    """
    return Reference(keccak256(identifier.as_bytes() + owner.as_bytes()))


def make_single_owner_chunk(
    identifier: Identifier, payload: bytes, signer: PrivateKey
) -> SingleOwnerChunk:
    """Build a SOC for ``(identifier, payload)``, signed by ``signer``.

    Mirrors bee-js ``makeSingleOwnerChunk`` and bee-go ``CreateSOC`` /
    ``MakeSingleOwnerChunk``.
    """
    if len(payload) > MAX_PAYLOAD_SIZE:
        raise BeeArgumentError(f"SOC payload too large: {len(payload)}")

    span = Span.from_int(len(payload))
    cac_addr = calculate_chunk_address(span.as_bytes() + payload)
    signature = signer.sign(identifier.as_bytes() + cac_addr)
    owner = signer.public_key().address()
    return SingleOwnerChunk(
        identifier=identifier,
        signature=signature,
        owner=owner,
        span=span,
        payload=payload,
    )


def unmarshal_single_owner_chunk(data: bytes, expected_address: Reference) -> SingleOwnerChunk:
    """Parse the wire form of a SOC chunk
    (``identifier(32) || signature(65) || span(8) || payload(≤4096)``)
    and verify it matches ``expected_address``.

    The owner is recovered from the signature using the
    eth-signed-message scheme; this is then used to recompute the SOC
    address and compare to ``expected_address``.
    """
    min_len = IDENTIFIER_LENGTH + SIGNATURE_LENGTH + SPAN_LENGTH
    if len(data) < min_len:
        raise BeeArgumentError(f"SOC data too short: {len(data)}")

    identifier = Identifier(data[:IDENTIFIER_LENGTH])
    sig_start = IDENTIFIER_LENGTH
    span_start = sig_start + SIGNATURE_LENGTH
    payload_start = span_start + SPAN_LENGTH

    signature = Signature(data[sig_start:span_start])
    span = Span(data[span_start:payload_start])
    payload = data[payload_start:]

    cac_addr = calculate_chunk_address(span.as_bytes() + payload)
    pub_key = recover_public_key(signature, identifier.as_bytes() + cac_addr)
    owner = pub_key.address()

    computed = keccak256(identifier.as_bytes() + owner.as_bytes())
    if computed != expected_address.as_bytes():
        raise BeeArgumentError("SOC data does not match expected address")

    return SingleOwnerChunk(
        identifier=identifier,
        signature=signature,
        owner=owner,
        span=span,
        payload=payload,
    )


__all__ = [
    "SingleOwnerChunk",
    "calculate_single_owner_chunk_address",
    "make_single_owner_chunk",
    "unmarshal_single_owner_chunk",
]
