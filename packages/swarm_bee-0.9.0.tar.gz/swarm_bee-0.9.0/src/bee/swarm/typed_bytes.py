"""Typed byte newtypes for the Swarm protocol.

Mirrors bee-rs's ``swarm::typed_bytes`` and bee-go's
``pkg/swarm/typed_bytes.go`` (which itself mirrors bee-js's
``src/utils/typed-bytes.ts``). Each type wraps a fixed-size byte
sequence; on the wire each is encoded as lowercase hex without the
``0x`` prefix.
"""

from __future__ import annotations

from typing import ClassVar

from eth_hash.auto import keccak
from typing_extensions import Self

from ._hex import decode_hex, encode_hex
from .errors import BeeLengthMismatchError

# ---- length constants -----------------------------------------------------

REFERENCE_LENGTH: int = 32
ENCRYPTED_REFERENCE_LENGTH: int = 64
BATCH_ID_LENGTH: int = 32
TRANSACTION_ID_LENGTH: int = 32
PEER_ADDRESS_LENGTH: int = 32
IDENTIFIER_LENGTH: int = 32
TOPIC_LENGTH: int = 32
ETH_ADDRESS_LENGTH: int = 20
PRIVATE_KEY_LENGTH: int = 32
PUBLIC_KEY_LENGTH: int = 64
SIGNATURE_LENGTH: int = 65
SPAN_LENGTH: int = 8
FEED_INDEX_LENGTH: int = 8


# ---- base class for fixed-length typed bytes ------------------------------


class _TypedBytes:
    """Base class for fixed-length typed-byte newtypes.

    Subclasses set :attr:`LENGTH` (in bytes) and :attr:`_KIND` (a
    short identifier used in error messages).
    """

    LENGTH: ClassVar[int]
    _KIND: ClassVar[str]

    __slots__ = ("_bytes",)

    def __init__(self, b: bytes) -> None:
        if len(b) != self.LENGTH:
            raise BeeLengthMismatchError(self._KIND, [self.LENGTH], len(b))
        # Take a defensive copy so callers can't mutate via a passed
        # bytearray.
        self._bytes: bytes = bytes(b)

    @classmethod
    def from_hex(cls, s: str) -> Self:
        """Parse from hex (with or without the ``0x`` prefix)."""
        return cls(decode_hex(s))

    def as_bytes(self) -> bytes:
        """Return the raw bytes."""
        return self._bytes

    def to_hex(self) -> str:
        """Encode as lowercase hex, no ``0x`` prefix."""
        return encode_hex(self._bytes)

    def __bytes__(self) -> bytes:
        return self._bytes

    def __eq__(self, other: object) -> bool:
        if type(self) is not type(other):
            return NotImplemented
        return self._bytes == other._bytes

    def __hash__(self) -> int:
        return hash((type(self).__name__, self._bytes))

    def __str__(self) -> str:
        return self.to_hex()

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.to_hex()})"


# ---- 32-byte identifiers --------------------------------------------------


class BatchId(_TypedBytes):
    """Postage batch identifier (32 bytes)."""

    LENGTH = BATCH_ID_LENGTH
    _KIND = "BatchId"


class TransactionId(_TypedBytes):
    """Ethereum transaction hash (32 bytes)."""

    LENGTH = TRANSACTION_ID_LENGTH
    _KIND = "TransactionId"


class PeerAddress(_TypedBytes):
    """Peer overlay address (32 bytes)."""

    LENGTH = PEER_ADDRESS_LENGTH
    _KIND = "PeerAddress"


class Identifier(_TypedBytes):
    """Arbitrary 32-byte identifier (SOC / GSOC).

    Use :meth:`from_string` for the keccak256-of-utf8 variant.
    """

    LENGTH = IDENTIFIER_LENGTH
    _KIND = "Identifier"

    @classmethod
    def from_string(cls, s: str) -> Identifier:
        """``keccak256(utf8(s))`` as an identifier.

        Mirrors bee-js ``Identifier.fromString``.
        """
        return cls(keccak(s.encode("utf-8")))


class Topic(_TypedBytes):
    """Feed / PSS topic (32 bytes).

    Use :meth:`from_string` for the keccak256-of-utf8 variant.
    """

    LENGTH = TOPIC_LENGTH
    _KIND = "Topic"

    @classmethod
    def from_string(cls, s: str) -> Topic:
        """``keccak256(utf8(s))`` as a topic.

        Mirrors bee-js ``Topic.fromString``.
        """
        return cls(keccak(s.encode("utf-8")))


# ---- EthAddress with EIP-55 checksum --------------------------------------


class EthAddress(_TypedBytes):
    """Ethereum address (20 bytes).

    :meth:`to_checksum` returns the EIP-55 mixed-case representation
    with ``0x`` prefix.
    """

    LENGTH = ETH_ADDRESS_LENGTH
    _KIND = "EthAddress"

    def to_checksum(self) -> str:
        """EIP-55 checksum representation, ``0x``-prefixed."""
        lower = self.to_hex()
        digest = keccak(lower.encode("ascii"))
        out = ["0x"]
        for i, c in enumerate(lower):
            if c.isdigit():
                out.append(c)
                continue
            nibble = (digest[i // 2] >> 4) if i % 2 == 0 else (digest[i // 2] & 0x0F)
            out.append(c.upper() if nibble >= 8 else c)
        return "".join(out)


# ---- Span (8 bytes, little-endian u64) ------------------------------------


class Span(_TypedBytes):
    """Chunk span: 8 bytes, little-endian ``u64``."""

    LENGTH = SPAN_LENGTH
    _KIND = "Span"

    @classmethod
    def from_int(cls, n: int) -> Span:
        """Encode ``n`` as a little-endian span. Raises if out of range."""
        if not 0 <= n < (1 << 64):
            raise OverflowError(f"span out of range for u64: {n}")
        return cls(n.to_bytes(SPAN_LENGTH, "little"))

    def to_int(self) -> int:
        """Decode the little-endian ``u64``."""
        return int.from_bytes(self._bytes, "little")


# ---- FeedIndex (8 bytes, big-endian u64) ----------------------------------


class FeedIndex(_TypedBytes):
    """Feed index: 8 bytes, big-endian ``u64``.

    The all-``0xff`` value is a "before first" sentinel matching bee-js
    ``FeedIndex.MINUS_ONE``.
    """

    LENGTH = FEED_INDEX_LENGTH
    _KIND = "FeedIndex"
    #: All-``0xff`` "before first" / wraparound sentinel. Populated below
    #: the class definition once the type is fully constructed.
    MINUS_ONE: ClassVar[FeedIndex]

    @classmethod
    def from_int(cls, n: int) -> FeedIndex:
        """Encode ``n`` as a big-endian feed index. Raises if out of range."""
        if not 0 <= n < (1 << 64):
            raise OverflowError(f"feed index out of range for u64: {n}")
        return cls(n.to_bytes(FEED_INDEX_LENGTH, "big"))

    def to_int(self) -> int:
        """Decode the big-endian ``u64``."""
        return int.from_bytes(self._bytes, "big")

    def next(self) -> FeedIndex:
        """Successor index. The :attr:`MINUS_ONE` sentinel wraps to ``0``."""
        if self == self.MINUS_ONE:
            return FeedIndex.from_int(0)
        return FeedIndex.from_int(self.to_int() + 1)

    # Defined below the class so the class is fully constructed.


FeedIndex.MINUS_ONE = FeedIndex(b"\xff" * FEED_INDEX_LENGTH)


# ---- Signature (65 bytes, R || S || V) ------------------------------------


class Signature(_TypedBytes):
    """Ethereum signed-message signature: ``R || S || V`` with V
    normalized to ``{27, 28}`` on the wire, matching bee-js."""

    LENGTH = SIGNATURE_LENGTH
    _KIND = "Signature"


# ---- Reference (32 OR 64 bytes) -------------------------------------------


class Reference:
    """Swarm content reference.

    32 bytes for a plain CAC reference, 64 bytes for an encrypted
    reference (CAC address || encryption key).
    """

    ALLOWED_LENGTHS: ClassVar[tuple[int, ...]] = (
        REFERENCE_LENGTH,
        ENCRYPTED_REFERENCE_LENGTH,
    )

    __slots__ = ("_bytes",)

    def __init__(self, b: bytes) -> None:
        if len(b) not in self.ALLOWED_LENGTHS:
            raise BeeLengthMismatchError("Reference", self.ALLOWED_LENGTHS, len(b))
        self._bytes: bytes = bytes(b)

    @classmethod
    def from_hex(cls, s: str) -> Reference:
        """Parse from hex (with or without the ``0x`` prefix)."""
        return cls(decode_hex(s))

    def as_bytes(self) -> bytes:
        """Return the raw bytes (32 or 64)."""
        return self._bytes

    def to_hex(self) -> str:
        """Encode as lowercase hex, no ``0x`` prefix."""
        return encode_hex(self._bytes)

    def is_encrypted(self) -> bool:
        """True for the 64-byte encrypted variant."""
        return len(self._bytes) == ENCRYPTED_REFERENCE_LENGTH

    def __len__(self) -> int:
        return len(self._bytes)

    def __bytes__(self) -> bytes:
        return self._bytes

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Reference):
            return NotImplemented
        return self._bytes == other._bytes

    def __hash__(self) -> int:
        return hash(("Reference", self._bytes))

    def __str__(self) -> str:
        return self.to_hex()

    def __repr__(self) -> str:
        return f"Reference({self.to_hex()})"


__all__ = [
    "BATCH_ID_LENGTH",
    "ENCRYPTED_REFERENCE_LENGTH",
    "ETH_ADDRESS_LENGTH",
    "FEED_INDEX_LENGTH",
    "IDENTIFIER_LENGTH",
    "PEER_ADDRESS_LENGTH",
    "PRIVATE_KEY_LENGTH",
    "PUBLIC_KEY_LENGTH",
    "REFERENCE_LENGTH",
    "SIGNATURE_LENGTH",
    "SPAN_LENGTH",
    "TOPIC_LENGTH",
    "TRANSACTION_ID_LENGTH",
    "BatchId",
    "EthAddress",
    "FeedIndex",
    "Identifier",
    "PeerAddress",
    "Reference",
    "Signature",
    "Span",
    "Topic",
    "TransactionId",
]
