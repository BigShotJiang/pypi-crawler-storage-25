"""Decimal-base file size type.

Mirrors bee-rs ``swarm::size`` and bee-go ``pkg/swarm/size.go``: all
conversions use ``1000`` as the base so they stay aligned with the
Swarm theoretical / effective storage tables.

Constructors round fractional inputs up; negative or NaN inputs raise
:class:`BeeArgumentError`.
"""

from __future__ import annotations

import math
import re

from typing_extensions import Self

from .errors import BeeArgumentError

KB: int = 1_000
MB: int = KB * 1_000
GB: int = MB * 1_000
TB: int = GB * 1_000


_UNIT_TOKEN_RE = re.compile(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]+)")


def _ceil_or_raise(b: float) -> int:
    if math.isnan(b):
        raise BeeArgumentError("size is NaN")
    if b < 0.0:
        raise BeeArgumentError("size must be at least 0")
    return math.ceil(b)


def _unit_to_bytes(unit: str) -> float:
    u = unit.lower()
    if u in ("b", "byte", "bytes"):
        return 1.0
    if u in ("kb", "kilobyte", "kilobytes"):
        return float(KB)
    if u in ("mb", "megabyte", "megabytes"):
        return float(MB)
    if u in ("gb", "gigabyte", "gigabytes"):
        return float(GB)
    if u in ("tb", "terabyte", "terabytes"):
        return float(TB)
    raise BeeArgumentError(f"unsupported size unit: {unit}")


class Size:
    """Non-negative size in bytes."""

    __slots__ = ("_bytes",)

    def __init__(self, bytes_: int) -> None:
        if bytes_ < 0:
            raise BeeArgumentError("size must be at least 0")
        self._bytes = int(bytes_)

    # ---- constructors ---------------------------------------------------

    @classmethod
    def from_bytes(cls, b: float) -> Self:
        return cls(_ceil_or_raise(b))

    @classmethod
    def from_kilobytes(cls, k: float) -> Self:
        return cls(_ceil_or_raise(k * KB))

    @classmethod
    def from_megabytes(cls, m: float) -> Self:
        return cls(_ceil_or_raise(m * MB))

    @classmethod
    def from_gigabytes(cls, g: float) -> Self:
        return cls(_ceil_or_raise(g * GB))

    @classmethod
    def from_terabytes(cls, t: float) -> Self:
        return cls(_ceil_or_raise(t * TB))

    @classmethod
    def parse(cls, s: str) -> Self:
        """Parse strings like ``"28MB"``, ``"1gb"``, ``"512 kb"``,
        ``"2megabytes"``. Case-insensitive, whitespace-tolerant.
        Accepts decimals (``"1.5gb"``) and concatenated parts
        (``"1gb 256mb"``).
        """
        clean = re.sub(r"\s+", "", s)
        if not clean:
            raise BeeArgumentError("empty size string")
        total = 0.0
        pos = 0
        found = False
        while pos < len(clean):
            match = _UNIT_TOKEN_RE.match(clean, pos)
            if match is None:
                raise BeeArgumentError(f"unrecognized size string: {s}")
            try:
                value = float(match.group(1))
            except ValueError as e:
                raise BeeArgumentError(
                    f"invalid size number: {match.group(1)}"
                ) from e
            total += value * _unit_to_bytes(match.group(2))
            pos = match.end()
            found = True
        if not found:
            raise BeeArgumentError(f"unrecognized size string: {s}")
        return cls(_ceil_or_raise(total))

    # ---- accessors ------------------------------------------------------

    def to_bytes(self) -> int:
        return self._bytes

    def to_kilobytes(self) -> float:
        return self._bytes / KB

    def to_megabytes(self) -> float:
        return self._bytes / MB

    def to_gigabytes(self) -> float:
        return self._bytes / GB

    def to_terabytes(self) -> float:
        return self._bytes / TB

    # ---- protocol -------------------------------------------------------

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Size):
            return self._bytes == other._bytes
        return NotImplemented

    def __lt__(self, other: Size) -> bool:
        if not isinstance(other, Size):
            return NotImplemented
        return self._bytes < other._bytes

    def __le__(self, other: Size) -> bool:
        if not isinstance(other, Size):
            return NotImplemented
        return self._bytes <= other._bytes

    def __gt__(self, other: Size) -> bool:
        if not isinstance(other, Size):
            return NotImplemented
        return self._bytes > other._bytes

    def __ge__(self, other: Size) -> bool:
        if not isinstance(other, Size):
            return NotImplemented
        return self._bytes >= other._bytes

    def __hash__(self) -> int:
        return hash(("Size", self._bytes))

    def __str__(self) -> str:
        """Auto-scaled human-readable rendering (e.g. ``"1.50 GB"``)."""
        if self._bytes >= TB:
            return f"{self.to_terabytes():.2f} TB"
        if self._bytes >= GB:
            return f"{self.to_gigabytes():.2f} GB"
        if self._bytes >= MB:
            return f"{self.to_megabytes():.2f} MB"
        if self._bytes >= KB:
            return f"{self.to_kilobytes():.2f} kB"
        return f"{self._bytes} B"

    def __repr__(self) -> str:
        return f"Size({self._bytes})"


__all__ = ["GB", "KB", "MB", "TB", "Size"]
