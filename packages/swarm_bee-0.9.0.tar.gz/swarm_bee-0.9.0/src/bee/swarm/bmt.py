"""Binary Merkle Tree (BMT) chunk addressing.

Mirrors bee-rs ``swarm::bmt`` and bee-go ``pkg/swarm/bmt.go`` /
``pkg/swarm/chunk.go``.

A Swarm chunk is ``span (8 bytes, little-endian u64) || payload (≤ 4096
bytes)``. The chunk address is
``keccak256(span || bmt_root(zero_padded_payload))``, where the BMT root
is computed by recursively hashing 32-byte segment pairs over the full
4096-byte payload region.
"""

from __future__ import annotations

from dataclasses import dataclass

from eth_hash.auto import keccak as _keccak

from .errors import BeeArgumentError
from .typed_bytes import SPAN_LENGTH, Reference, Span

#: Maximum chunk payload size.
CHUNK_SIZE: int = 4096
#: BMT segment size.
SEGMENT_SIZE: int = 32
#: Number of leaf segments in the BMT.
SEGMENTS_COUNT: int = CHUNK_SIZE // SEGMENT_SIZE

#: Minimum CAC payload (must be at least one byte).
MIN_PAYLOAD_SIZE: int = 1
#: Maximum CAC payload (chunk size).
MAX_PAYLOAD_SIZE: int = CHUNK_SIZE


def keccak256(data: bytes) -> bytes:
    """Return ``keccak256(data)`` as a 32-byte ``bytes`` value."""
    return bytes(_keccak(data))


def _bmt_root(payload: bytes) -> bytes:
    """BMT root over a zero-padded ``CHUNK_SIZE``-byte payload region.

    Each leaf is a raw 32-byte segment; we keccak-pair-reduce until one
    32-byte root remains.
    """
    if len(payload) != CHUNK_SIZE:
        raise BeeArgumentError(
            f"BMT payload must be exactly {CHUNK_SIZE} bytes, got {len(payload)}"
        )
    level: list[bytes] = [
        payload[i * SEGMENT_SIZE : (i + 1) * SEGMENT_SIZE] for i in range(SEGMENTS_COUNT)
    ]
    while len(level) > 1:
        level = [keccak256(level[i] + level[i + 1]) for i in range(0, len(level), 2)]
    return level[0]


def calculate_chunk_address(data: bytes) -> bytes:
    """Compute the BMT chunk address for a full chunk (``span || payload``).

    Returns the raw 32-byte address. Raises :class:`BeeArgumentError`
    if ``data`` is shorter than the span or the payload exceeds
    :data:`CHUNK_SIZE`.
    """
    if len(data) < SPAN_LENGTH:
        raise BeeArgumentError("chunk data shorter than span")
    span = data[:SPAN_LENGTH]
    payload = data[SPAN_LENGTH:]
    if len(payload) > CHUNK_SIZE:
        raise BeeArgumentError("chunk payload exceeds CHUNK_SIZE")

    padded = payload + b"\x00" * (CHUNK_SIZE - len(payload))
    root = _bmt_root(padded)
    return keccak256(span + root)


@dataclass(frozen=True, slots=True)
class Chunk:
    """Content-addressed chunk: a span + payload pair whose address is
    the BMT root over the chunk. Mirrors bee-js ``Chunk`` (``cac.ts``).
    """

    #: BMT chunk address.
    address: Reference
    #: Span (8-byte little-endian payload length).
    span: Span
    #: Raw payload (1..=4096 bytes).
    payload: bytes

    def data(self) -> bytes:
        """Wire form: ``span (8 bytes) || payload``. Suitable as the
        body of ``POST /chunks/{addr}``.
        """
        return self.span.as_bytes() + self.payload


def make_content_addressed_chunk(payload: bytes) -> Chunk:
    """Build a content-addressed chunk: encode the span, compute the
    BMT address, return the typed :class:`Chunk`. Mirrors bee-js
    ``makeContentAddressedChunk``.
    """
    if len(payload) < MIN_PAYLOAD_SIZE or len(payload) > MAX_PAYLOAD_SIZE:
        raise BeeArgumentError(f"payload size out of bounds: {len(payload)}")
    span = Span.from_int(len(payload))
    addr_bytes = calculate_chunk_address(span.as_bytes() + payload)
    return Chunk(address=Reference(addr_bytes), span=span, payload=payload)


__all__ = [
    "CHUNK_SIZE",
    "MAX_PAYLOAD_SIZE",
    "MIN_PAYLOAD_SIZE",
    "SEGMENTS_COUNT",
    "SEGMENT_SIZE",
    "Chunk",
    "calculate_chunk_address",
    "keccak256",
    "make_content_addressed_chunk",
]
