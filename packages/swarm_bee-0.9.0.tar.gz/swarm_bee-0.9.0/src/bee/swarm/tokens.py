"""BZZ / DAI fixed-point token math.

Mirrors bee-rs ``swarm::tokens`` and bee-go ``pkg/swarm/tokens.go``.
:class:`Bzz` stores amounts as PLUR (``1 BZZ = 10^16 PLUR``);
:class:`Dai` stores amounts as wei (``1 DAI = 10^18 wei``). Both wrap
a Python ``int`` (arbitrary precision) so all arithmetic is exact.

Construction is via:

- :meth:`from_base_units` — raw ``int`` in PLUR / wei.
- :meth:`from_base_units_str` — base-unit decimal string.
- :meth:`from_decimal_str` — human-readable ``"1.5"``; extra
  fractional digits beyond the token's precision are silently
  truncated (matches bee-js / bee-go).
- :meth:`from_float` — lossy from ``float``.
"""

from __future__ import annotations

import math
from typing import ClassVar

from typing_extensions import Self

from .errors import BeeArgumentError

#: Decimal digits used by the BZZ token.
BZZ_DIGITS: int = 16
#: Decimal digits used by the DAI / native token.
DAI_DIGITS: int = 18


def _decimal_to_base_units(s: str, digits: int) -> int:
    """Decode a decimal string into base units (BigInt-style int).

    Mirrors bee-rs ``decimal_to_base_units``: empty input is rejected,
    optional leading ``+`` / ``-`` is honored, fractional digits beyond
    ``digits`` are truncated (not rounded), missing fractional digits
    are right-padded with zeros.
    """
    if not s:
        raise BeeArgumentError("empty decimal string")
    negative = False
    rest = s
    if rest[0] == "-":
        negative = True
        rest = rest[1:]
    elif rest[0] == "+":
        rest = rest[1:]
    if "." in rest:
        int_part, frac_part = rest.split(".", 1)
    else:
        int_part, frac_part = rest, ""
    if not int_part:
        int_part = "0"
    frac_truncated = frac_part[:digits]
    combined = int_part + frac_truncated + "0" * (digits - len(frac_truncated))
    try:
        v = int(combined, 10)
    except ValueError as e:
        raise BeeArgumentError(f"invalid decimal string {s!r}: {e}") from e
    return -v if negative else v


def _base_units_to_decimal(v: int, digits: int) -> str:
    """Render ``v`` base units as a fixed-precision decimal string.

    Always emits exactly ``digits`` fractional digits so the format
    is stable for sorting / display.
    """
    negative = v < 0
    abs_v = -v if negative else v
    denom = 10**digits
    int_part = abs_v // denom
    frac_part = abs_v % denom
    frac_str = str(frac_part).zfill(digits)
    sign = "-" if negative else ""
    return f"{sign}{int_part}.{frac_str}"


def _truncate_decimal(s: str, digits: int) -> str:
    """Truncate a decimal string to ``digits`` fractional digits.

    bee-go parity: ``digits=0`` keeps the trailing dot.
    """
    dot = s.find(".")
    if dot == -1:
        return s
    end = min(dot + 1 + digits, len(s))
    return s[:end]


def _trim_trailing_decimal_zeros(s: str) -> str:
    if "." not in s:
        return s
    return s.rstrip("0").rstrip(".")


class _FixedPointToken:
    """Base class for fixed-point token amounts.

    Subclasses set :attr:`DIGITS`. The base unit is always a Python
    ``int``; equality / ordering / hashing are by base unit.
    """

    __slots__ = ("_base_units",)

    DIGITS: ClassVar[int] = 0

    def __init__(self, base_units: int) -> None:
        self._base_units = int(base_units)

    # ---- constructors ----------------------------------------------------

    @classmethod
    def from_base_units(cls, v: int) -> Self:
        """Build from raw base units (PLUR for BZZ, wei for DAI)."""
        return cls(int(v))

    @classmethod
    def from_base_units_str(cls, s: str) -> Self:
        try:
            v = int(s, 10)
        except ValueError as e:
            raise BeeArgumentError(f"invalid base-units string {s!r}: {e}") from e
        return cls(v)

    @classmethod
    def from_decimal_str(cls, s: str) -> Self:
        return cls(_decimal_to_base_units(s, cls.DIGITS))

    @classmethod
    def from_float(cls, f: float) -> Self:
        if not math.isfinite(f):
            raise BeeArgumentError(f"non-finite float: {f}")
        rendered = f"{f:.{cls.DIGITS}f}"
        return cls.from_decimal_str(_trim_trailing_decimal_zeros(rendered))

    # ---- accessors -------------------------------------------------------

    def as_base_units(self) -> int:
        """Return the raw base-unit value."""
        return self._base_units

    def to_base_units(self) -> int:
        """Alias of :meth:`as_base_units` for parity with bee-rs."""
        return self._base_units

    def to_base_units_string(self) -> str:
        """Render the base-unit value as a base-10 integer string."""
        return str(self._base_units)

    def to_decimal_string(self) -> str:
        """Render with exactly :attr:`DIGITS` fractional digits."""
        return _base_units_to_decimal(self._base_units, self.DIGITS)

    def to_significant_digits(self, digits: int) -> str:
        """Truncate :meth:`to_decimal_string` to ``digits`` fractional digits."""
        return _truncate_decimal(self.to_decimal_string(), digits)

    def to_float(self) -> float:
        """Lossy conversion to ``float``."""
        return float(self._base_units) / float(10**self.DIGITS)

    def is_zero(self) -> bool:
        return self._base_units == 0

    # ---- arithmetic ------------------------------------------------------

    def __add__(self, other: Self) -> Self:
        if not isinstance(other, type(self)):
            return NotImplemented
        return type(self)(self._base_units + other._base_units)

    def __sub__(self, other: Self) -> Self:
        if not isinstance(other, type(self)):
            return NotImplemented
        return type(self)(self._base_units - other._base_units)

    def __neg__(self) -> Self:
        return type(self)(-self._base_units)

    def divide(self, divisor: int) -> Self:
        """Integer division by a positive integer."""
        return type(self)(self._base_units // int(divisor))

    def times(self, factor: int) -> Self:
        """Multiplication by an unsigned integer."""
        return type(self)(self._base_units * int(factor))

    # ---- protocol --------------------------------------------------------

    def __eq__(self, other: object) -> bool:
        if isinstance(other, type(self)):
            return self._base_units == other._base_units
        return NotImplemented

    def __lt__(self, other: Self) -> bool:
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._base_units < other._base_units

    def __le__(self, other: Self) -> bool:
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._base_units <= other._base_units

    def __gt__(self, other: Self) -> bool:
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._base_units > other._base_units

    def __ge__(self, other: Self) -> bool:
        if not isinstance(other, type(self)):
            return NotImplemented
        return self._base_units >= other._base_units

    def __hash__(self) -> int:
        return hash((type(self).__name__, self._base_units))

    def __str__(self) -> str:
        return self.to_decimal_string()

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self._base_units})"


class Bzz(_FixedPointToken):
    """BZZ token amount stored as PLUR base units (``1 BZZ = 10^16 PLUR``)."""

    DIGITS = BZZ_DIGITS

    def exchange_to_dai(self, dai_per_bzz: Dai) -> Dai:
        """Convert to :class:`Dai` given a rate expressed as DAI per 1 BZZ.

        ``dai_wei = (plur * dai_per_bzz.wei) // 10**BZZ_DIGITS``
        """
        num = self._base_units * dai_per_bzz._base_units
        return Dai(num // (10**BZZ_DIGITS))


class Dai(_FixedPointToken):
    """DAI / native-token amount stored as wei (``1 DAI = 10^18 wei``)."""

    DIGITS = DAI_DIGITS

    def exchange_to_bzz(self, dai_per_bzz: Dai) -> Bzz:
        """Convert to :class:`Bzz` given a rate expressed as DAI per 1 BZZ.

        ``bzz_plur = (wei * 10**BZZ_DIGITS) // dai_per_bzz.wei``
        """
        if dai_per_bzz._base_units == 0:
            raise BeeArgumentError("dai_per_bzz rate is zero")
        num = self._base_units * (10**BZZ_DIGITS)
        return Bzz(num // dai_per_bzz._base_units)


__all__ = [
    "BZZ_DIGITS",
    "DAI_DIGITS",
    "Bzz",
    "Dai",
]
