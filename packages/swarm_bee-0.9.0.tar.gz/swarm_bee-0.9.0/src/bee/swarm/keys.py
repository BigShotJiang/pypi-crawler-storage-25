"""``PrivateKey`` / ``PublicKey`` and the Ethereum signed-message
signer.

Mirrors bee-rs ``swarm::keys`` and bee-go's
``pkg/swarm/typed_bytes.go`` crypto block. ECDSA is provided by
:mod:`coincurve`, which wraps the same libsecp256k1 C library that
Bitcoin Core, alloy, ethers, and reth use — chosen for the same
performance reason bee-rs swapped k256 -> secp256k1 (~4x faster
signing). libsecp256k1 returns low-S signatures by default, so no
manual S normalization is needed.

The scheme matches bee-js:

.. code-block:: text

    digest = keccak256("\\x19Ethereum Signed Message:\\n32" || keccak256(data))

and signatures are stored with ``V ∈ {27, 28}`` on the wire (v0 / v1
recovery IDs are normalized on the way out, denormalized on the way
in).

.. note::
   Python ``bytes`` is immutable, so ``PrivateKey`` cannot truly
   "zeroize" its backing storage the way bee-rs does. We do best-effort
   scrubbing in :meth:`PrivateKey.zeroize` (overwrite a ``bytearray``)
   and avoid leaking secret material via ``repr`` / ``str``. For
   stricter guarantees, sign within a hardware module instead of
   loading the key into Python memory.
"""

from __future__ import annotations

import hmac

from coincurve import PrivateKey as _CCPrivate
from coincurve import PublicKey as _CCPublic

from ._hex import decode_hex, encode_hex
from .bmt import keccak256
from .errors import BeeArgumentError, BeeCryptoError, BeeLengthMismatchError
from .typed_bytes import (
    ETH_ADDRESS_LENGTH,
    PRIVATE_KEY_LENGTH,
    PUBLIC_KEY_LENGTH,
    SIGNATURE_LENGTH,
    EthAddress,
    Signature,
)


def eth_signed_message_digest(data: bytes) -> bytes:
    """``keccak256("\\x19Ethereum Signed Message:\\n32" || keccak256(data))``.

    The exact digest Bee verifies SOC and feed signatures against.
    """
    inner = keccak256(data)
    return keccak256(b"\x19Ethereum Signed Message:\n32" + inner)


# ---- PrivateKey -----------------------------------------------------------


class PrivateKey:
    """secp256k1 private key (32 bytes).

    Equality is constant-time. ``repr`` / ``str`` redact the bytes.
    Stored in a :class:`bytearray` so :meth:`zeroize` can overwrite it
    in place — best-effort given Python's GC, see the module docstring.
    """

    __slots__ = ("_bytes",)

    LENGTH: int = PRIVATE_KEY_LENGTH

    def __init__(self, b: bytes) -> None:
        if len(b) != PRIVATE_KEY_LENGTH:
            raise BeeLengthMismatchError("PrivateKey", [PRIVATE_KEY_LENGTH], len(b))
        self._bytes: bytearray = bytearray(b)

    @classmethod
    def from_hex(cls, s: str) -> PrivateKey:
        """Parse from hex (with or without the ``0x`` prefix)."""
        return cls(decode_hex(s))

    def as_bytes(self) -> bytes:
        """Return an immutable copy of the raw 32 bytes."""
        return bytes(self._bytes)

    def to_hex(self) -> str:
        """Lowercase hex of the raw bytes, no ``0x`` prefix."""
        return encode_hex(bytes(self._bytes))

    def public_key(self) -> PublicKey:
        """Derive the uncompressed (64-byte ``X || Y``) public key."""
        try:
            sk = _CCPrivate(bytes(self._bytes))
        except Exception as e:
            raise BeeCryptoError(f"invalid private key scalar: {e}") from e
        # coincurve returns 65-byte 0x04 || X || Y; strip the prefix.
        return PublicKey(sk.public_key.format(compressed=False)[1:])

    def sign(self, data: bytes) -> Signature:
        """Sign ``data`` using the Ethereum signed-message scheme.

        Returns a 65-byte ``R || S || V`` signature with
        ``V ∈ {27, 28}``.
        """
        digest = eth_signed_message_digest(data)
        try:
            sk = _CCPrivate(bytes(self._bytes))
            # `hasher=None` means "treat msg as the digest directly".
            sig = sk.sign_recoverable(digest, hasher=None)
        except Exception as e:
            raise BeeCryptoError(f"sign failed: {e}") from e
        # coincurve emits V in {0, 1}; bee-js wire format wants {27, 28}.
        out = bytearray(sig)
        out[64] = out[64] + 27
        return Signature(bytes(out))

    def zeroize(self) -> None:
        """Overwrite the backing :class:`bytearray` with zeros.

        Best-effort — see the module docstring for caveats.
        """
        for i in range(len(self._bytes)):
            self._bytes[i] = 0

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, PrivateKey):
            return NotImplemented
        return hmac.compare_digest(bytes(self._bytes), bytes(other._bytes))

    def __hash__(self) -> int:
        # Don't hash on the secret; a fixed hash forces fallback to
        # __eq__ for set / dict lookups, which is constant-time.
        return 0

    def __repr__(self) -> str:
        return "PrivateKey(<redacted>)"

    def __str__(self) -> str:  # pragma: no cover — same as repr
        return self.__repr__()


# ---- PublicKey ------------------------------------------------------------


class PublicKey:
    """Uncompressed secp256k1 public key (``X || Y``, 64 bytes).

    Constructors accept the 33-byte SEC1-compressed encoding too.
    """

    __slots__ = ("_bytes",)

    LENGTH: int = PUBLIC_KEY_LENGTH

    def __init__(self, b: bytes) -> None:
        if len(b) == PUBLIC_KEY_LENGTH:
            self._bytes: bytes = bytes(b)
        elif len(b) == 33:
            try:
                pk = _CCPublic(bytes(b))
            except Exception as e:
                raise BeeCryptoError(f"invalid compressed public key: {e}") from e
            self._bytes = pk.format(compressed=False)[1:]
        else:
            raise BeeLengthMismatchError("PublicKey", [33, PUBLIC_KEY_LENGTH], len(b))

    @classmethod
    def from_hex(cls, s: str) -> PublicKey:
        """Parse from hex. Length must be 33 (compressed) or 64
        (uncompressed)."""
        return cls(decode_hex(s))

    def as_bytes(self) -> bytes:
        """Borrow the raw 64-byte uncompressed encoding."""
        return self._bytes

    def to_hex(self) -> str:
        """Lowercase hex of the uncompressed encoding, no ``0x`` prefix."""
        return encode_hex(self._bytes)

    def address(self) -> EthAddress:
        """Ethereum address: last 20 bytes of ``keccak256(X || Y)``."""
        digest = keccak256(self._bytes)
        return EthAddress(digest[-ETH_ADDRESS_LENGTH:])

    def compressed_bytes(self) -> bytes:
        """33-byte SEC1-compressed encoding."""
        try:
            pk = _CCPublic(b"\x04" + self._bytes)
        except Exception as e:
            raise BeeCryptoError(f"invalid public key: {e}") from e
        return pk.format(compressed=True)

    def compressed_hex(self) -> str:
        """Lowercase hex of the compressed encoding, no ``0x`` prefix."""
        return encode_hex(self.compressed_bytes())

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, PublicKey):
            return NotImplemented
        return self._bytes == other._bytes

    def __hash__(self) -> int:
        return hash(("PublicKey", self._bytes))

    def __str__(self) -> str:
        return self.to_hex()

    def __repr__(self) -> str:
        return f"PublicKey({self.to_hex()})"


# ---- Signature recovery (free functions) ---------------------------------


def recover_public_key(signature: Signature, data: bytes) -> PublicKey:
    """Recover the public key that produced ``signature`` for ``data``,
    using the Ethereum signed-message scheme.
    """
    raw = signature.as_bytes()
    if len(raw) != SIGNATURE_LENGTH:
        raise BeeArgumentError(f"signature must be {SIGNATURE_LENGTH} bytes")
    v = raw[64]
    recovery = v - 27 if v >= 27 else v
    if recovery not in (0, 1):
        raise BeeCryptoError(f"invalid V byte: {v}")
    digest = eth_signed_message_digest(data)
    sig_bytes = raw[:64] + bytes([recovery])
    try:
        pk = _CCPublic.from_signature_and_message(sig_bytes, digest, hasher=None)
    except Exception as e:
        raise BeeCryptoError(f"recover failed: {e}") from e
    return PublicKey(pk.format(compressed=False)[1:])


def verify_signature(signature: Signature, data: bytes, expected: EthAddress) -> bool:
    """True iff ``signature`` is valid against ``data`` and the recovered
    signer matches ``expected``.
    """
    try:
        return recover_public_key(signature, data).address() == expected
    except BeeCryptoError:
        return False


__all__ = [
    "PrivateKey",
    "PublicKey",
    "eth_signed_message_digest",
    "recover_public_key",
    "verify_signature",
]
