"""Streaming Swarm content-addressed chunker.

Mirrors bee-rs ``swarm::file_chunker`` and bee-go's
``pkg/swarm/file_chunker.go``. Turns an arbitrary byte stream into a
tree of 4-KiB content-addressed chunks (CACs):

- Leaves carry the raw payload (≤ 4096 bytes).
- Intermediate chunks carry a flat list of child addresses
  (32 bytes each).
- Fan-out at every level is :data:`MAX_BRANCHES` =
  ``CHUNK_SIZE / SEGMENT_SIZE`` = 128.

Stream input via :meth:`FileChunker.write` and finish with
:meth:`FileChunker.finalize`, which returns the root chunk address
and span (total bytes covered by the tree). Pass an ``on_chunk``
callback to :class:`FileChunker` to be notified as each chunk
is sealed — useful for piping to streamed uploads.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from .bmt import CHUNK_SIZE, SEGMENT_SIZE, calculate_chunk_address
from .errors import BeeArgumentError
from .typed_bytes import Reference, Span

#: Fan-out at every intermediate level (4096 / 32 = 128).
MAX_BRANCHES: int = CHUNK_SIZE // SEGMENT_SIZE


@dataclass(frozen=True, slots=True)
class SealedChunk:
    """Snapshot of a sealed chunk passed to the ``on_chunk`` callback."""

    address: Reference
    span: Span
    payload: bytes

    def data(self) -> bytes:
        """Wire form: ``span (8) || payload``."""
        return self.span.as_bytes() + self.payload


@dataclass(frozen=True, slots=True)
class ChunkerRoot:
    """Root of a chunked stream — address plus total bytes covered."""

    address: Reference
    span: Span


@dataclass(slots=True)
class _LevelRef:
    addr: bytes
    span: int  # bytes covered by the subtree under this ref


OnChunk = Callable[[SealedChunk], None]


class FileChunker:
    """Streaming content-addressed chunker.

    Construct via ``FileChunker()``, push bytes with
    :meth:`write`, and call :meth:`finalize` to get the root
    address. Pass ``on_chunk=`` to be notified as each leaf or
    intermediate chunk is sealed.
    """

    __slots__ = ("_finalized", "_leaf_buf", "_levels", "_on_chunk")

    def __init__(self, on_chunk: OnChunk | None = None) -> None:
        self._on_chunk: OnChunk | None = on_chunk
        self._leaf_buf = bytearray()
        self._levels: list[list[_LevelRef]] = []
        self._finalized = False

    def write(self, data: bytes) -> int:
        """Append bytes to the input stream.

        As each leaf reaches :data:`CHUNK_SIZE` it is sealed and
        propagated up the level stack. Returns the number of bytes
        accepted (always ``len(data)`` — there is no back-pressure).
        """
        if self._finalized:
            raise BeeArgumentError("FileChunker: write after finalize")
        if not data:
            return 0
        view = memoryview(data)
        written = 0
        while view:
            room = CHUNK_SIZE - len(self._leaf_buf)
            take = min(len(view), room)
            self._leaf_buf.extend(view[:take])
            view = view[take:]
            written += take
            if len(self._leaf_buf) == CHUNK_SIZE:
                self._flush_leaf()
        return written

    def finalize(self) -> ChunkerRoot:
        """Seal any trailing partial leaf, collapse the level stack,
        and return the root chunk's address + span.

        Raises :class:`BeeArgumentError` if no bytes have been
        written. The chunker may not be reused after :meth:`finalize`.
        """
        if self._finalized:
            raise BeeArgumentError("FileChunker: already finalized")
        self._finalized = True

        if not self._levels and not self._leaf_buf:
            raise BeeArgumentError("FileChunker: no input")
        if self._leaf_buf:
            self._flush_leaf()

        # Collapse from the bottom up. Skip levels that are already
        # empty; at the highest level, a single ref is the root.
        level = 0
        while level < len(self._levels):
            if level == len(self._levels) - 1 and len(self._levels[level]) == 1:
                break
            if self._levels[level]:
                self._collapse_level(level)
            level += 1

        root_level = len(self._levels) - 1
        root = self._levels[root_level][0]
        return ChunkerRoot(
            address=Reference(root.addr), span=Span.from_int(root.span)
        )

    def _emit(self, sealed: SealedChunk) -> None:
        if self._on_chunk is not None:
            self._on_chunk(sealed)

    def _flush_leaf(self) -> None:
        payload = bytes(self._leaf_buf)
        self._leaf_buf.clear()
        if not payload:
            return
        span = Span.from_int(len(payload))
        addr = calculate_chunk_address(span.as_bytes() + payload)

        self._emit(SealedChunk(address=Reference(addr), span=span, payload=payload))

        if not self._levels:
            self._levels.append([])
        self._levels[0].append(_LevelRef(addr=addr, span=len(payload)))
        if len(self._levels[0]) == MAX_BRANCHES:
            self._collapse_level(0)

    def _collapse_level(self, level: int) -> None:
        refs = self._levels[level]
        self._levels[level] = []
        if not refs:
            return

        payload = bytearray(len(refs) * SEGMENT_SIZE)
        total_span = 0
        for i, r in enumerate(refs):
            payload[i * SEGMENT_SIZE : (i + 1) * SEGMENT_SIZE] = r.addr
            total_span += r.span
        payload_bytes = bytes(payload)
        span = Span.from_int(total_span)
        addr = calculate_chunk_address(span.as_bytes() + payload_bytes)

        self._emit(
            SealedChunk(address=Reference(addr), span=span, payload=payload_bytes)
        )

        if level + 1 >= len(self._levels):
            self._levels.append([])
        self._levels[level + 1].append(_LevelRef(addr=addr, span=total_span))
        if len(self._levels[level + 1]) == MAX_BRANCHES:
            self._collapse_level(level + 1)


def chunk_file(data: bytes, on_chunk: OnChunk | None = None) -> ChunkerRoot:
    """One-shot convenience: chunk ``data`` and return the root.

    Equivalent to:

    .. code:: python

        c = FileChunker(on_chunk)
        c.write(data)
        return c.finalize()
    """
    chunker = FileChunker(on_chunk)
    chunker.write(data)
    return chunker.finalize()


__all__ = [
    "MAX_BRANCHES",
    "ChunkerRoot",
    "FileChunker",
    "SealedChunk",
    "chunk_file",
]
