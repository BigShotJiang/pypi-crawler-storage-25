"""GSOC (Graffiti SOC) mining primitives.

Mirrors bee-rs ``swarm::gsoc`` and bee-go ``pkg/swarm/gsoc.go``. GSOC
piggy-backs on the SOC primitive: a signer is mined so the SOC address
``keccak256(identifier || owner)`` lands inside a target node's
neighbourhood. Subscribers listen at ``/gsoc/subscribe/{soc_address}``
and receive any chunk that hashes to that address.

The mining search space is ``[0xb33, 0xb33 + 0xffff]``, matching
bee-js exactly.
"""

from __future__ import annotations

from .bmt import keccak256
from .errors import BeeArgumentError, BeeCryptoError
from .keys import PrivateKey
from .typed_bytes import Identifier

#: bee-js mining start offset.
GSOC_MINE_START: int = 0xB33
#: Default proximity target (matches bee-js).
GSOC_DEFAULT_PROXIMITY: int = 12


def proximity(a: bytes, b: bytes) -> int:
    """Number of leading common bits between two equal-length byte
    sequences.

    Mirrors bee-go ``swarm.Proximity``. Returns ``0`` when lengths
    differ.
    """
    if len(a) != len(b):
        return 0
    po = 0
    for i in range(len(a)):
        x = a[i] ^ b[i]
        if x == 0:
            po += 8
            continue
        for j in range(8):
            if (x & (0x80 >> j)) == 0:
                po += 1
            else:
                return po
        return po
    return po


def gsoc_mine(
    target: bytes,
    identifier: Identifier,
    target_proximity: int = GSOC_DEFAULT_PROXIMITY,
) -> PrivateKey:
    """Find a private key whose ``(identifier, owner_address)`` SOC
    address has at least ``target_proximity`` leading bits in common
    with ``target`` (a 32-byte overlay address).

    Raises :class:`BeeArgumentError` if no key is found within the
    bee-js search window.
    """
    if len(target) != 32:
        raise BeeArgumentError(
            f"target overlay must be 32 bytes, got {len(target)}"
        )

    for i in range(0xFFFF):
        val = GSOC_MINE_START + i
        key_bytes = bytearray(32)
        key_bytes[24:] = val.to_bytes(8, "big")

        priv_key = PrivateKey(bytes(key_bytes))
        try:
            owner = priv_key.public_key().address()
        except BeeCryptoError:
            continue

        soc_addr = keccak256(identifier.as_bytes() + owner.as_bytes())
        if proximity(soc_addr, target) >= target_proximity:
            return priv_key

    raise BeeArgumentError("could not mine a valid GSOC signer")


__all__ = [
    "GSOC_DEFAULT_PROXIMITY",
    "GSOC_MINE_START",
    "gsoc_mine",
    "proximity",
]
