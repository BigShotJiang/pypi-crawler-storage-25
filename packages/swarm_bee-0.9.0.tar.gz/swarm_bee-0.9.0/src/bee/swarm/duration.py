"""Bee-flavored :class:`Duration` — non-negative whole-second duration.

Mirrors bee-rs ``swarm::duration`` and bee-go ``pkg/swarm/duration.go``.
Negative inputs and NaN clamp to zero; fractional seconds round up.

The type wraps an ``int`` seconds count and is hashable / orderable.
Use :meth:`to_timedelta` to convert to :class:`datetime.timedelta`.
"""

from __future__ import annotations

import datetime
import math
import re

from typing_extensions import Self

from .errors import BeeArgumentError

SECONDS_IN_MINUTE: int = 60
SECONDS_IN_HOUR: int = 60 * SECONDS_IN_MINUTE
SECONDS_IN_DAY: int = 24 * SECONDS_IN_HOUR
SECONDS_IN_WEEK: int = 7 * SECONDS_IN_DAY
SECONDS_IN_MONTH: int = 30 * SECONDS_IN_DAY
SECONDS_IN_YEAR: int = 365 * SECONDS_IN_DAY


def _clamp_ceil(seconds: float) -> int:
    """Ceil-round; clamp negatives / NaN to zero."""
    if math.isnan(seconds) or seconds < 0.0:
        return 0
    return math.ceil(seconds)


_UNIT_TOKEN_RE = re.compile(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]+)")


def _unit_to_seconds(unit: str) -> float:
    u = unit.lower()
    if u in ("ms", "milli", "millis", "millisecond", "milliseconds"):
        return 0.001
    if u in ("s", "sec", "second", "seconds"):
        return 1.0
    if u in ("m", "min", "minute", "minutes"):
        return float(SECONDS_IN_MINUTE)
    if u in ("h", "hour", "hours"):
        return float(SECONDS_IN_HOUR)
    if u in ("d", "day", "days"):
        return float(SECONDS_IN_DAY)
    if u in ("w", "week", "weeks"):
        return float(SECONDS_IN_WEEK)
    if u in ("month", "months"):
        return float(SECONDS_IN_MONTH)
    if u in ("y", "year", "years"):
        return float(SECONDS_IN_YEAR)
    raise BeeArgumentError(f"unsupported duration unit: {unit}")


class Duration:
    """Non-negative whole-second duration."""

    __slots__ = ("_seconds",)

    def __init__(self, seconds: int) -> None:
        if seconds < 0:
            seconds = 0
        self._seconds = int(seconds)

    # ---- constructors ---------------------------------------------------

    @classmethod
    def zero(cls) -> Self:
        return cls(0)

    @classmethod
    def from_seconds(cls, s: float) -> Self:
        return cls(_clamp_ceil(s))

    @classmethod
    def from_milliseconds(cls, ms: float) -> Self:
        return cls(_clamp_ceil(ms / 1000.0))

    @classmethod
    def from_minutes(cls, m: float) -> Self:
        return cls(_clamp_ceil(m * SECONDS_IN_MINUTE))

    @classmethod
    def from_hours(cls, h: float) -> Self:
        return cls(_clamp_ceil(h * SECONDS_IN_HOUR))

    @classmethod
    def from_days(cls, d: float) -> Self:
        return cls(_clamp_ceil(d * SECONDS_IN_DAY))

    @classmethod
    def from_weeks(cls, w: float) -> Self:
        return cls(_clamp_ceil(w * SECONDS_IN_WEEK))

    @classmethod
    def from_months(cls, m: float) -> Self:
        """30-day months."""
        return cls(_clamp_ceil(m * SECONDS_IN_MONTH))

    @classmethod
    def from_years(cls, y: float) -> Self:
        """365-day years."""
        return cls(_clamp_ceil(y * SECONDS_IN_YEAR))

    @classmethod
    def from_timedelta(cls, td: datetime.timedelta) -> Self:
        return cls(_clamp_ceil(td.total_seconds()))

    @classmethod
    def parse(cls, s: str) -> Self:
        """Parse strings like ``"1.5h"``, ``"5 d"``, ``"2weeks"``,
        ``"30s"``, ``"1d 4h 5m 30s"``. Case-insensitive,
        whitespace-tolerant.
        """
        clean = re.sub(r"\s+", "", s)
        if not clean:
            raise BeeArgumentError("empty duration string")
        # Walk pairs of (number, unit) — anything else fails.
        total = 0.0
        pos = 0
        found = False
        while pos < len(clean):
            match = _UNIT_TOKEN_RE.match(clean, pos)
            if match is None:
                raise BeeArgumentError(f"unrecognized duration string: {s}")
            try:
                value = float(match.group(1))
            except ValueError as e:
                raise BeeArgumentError(
                    f"invalid duration number: {match.group(1)}"
                ) from e
            total += value * _unit_to_seconds(match.group(2))
            pos = match.end()
            found = True
        if not found:
            raise BeeArgumentError(f"unrecognized duration string: {s}")
        return cls(_clamp_ceil(total))

    # ---- accessors ------------------------------------------------------

    def to_seconds(self) -> int:
        return self._seconds

    def to_milliseconds(self) -> int:
        return self._seconds * 1000

    def to_minutes(self) -> float:
        return self._seconds / SECONDS_IN_MINUTE

    def to_hours(self) -> float:
        return self._seconds / SECONDS_IN_HOUR

    def to_days(self) -> float:
        return self._seconds / SECONDS_IN_DAY

    def to_weeks(self) -> float:
        return self._seconds / SECONDS_IN_WEEK

    def to_years(self) -> float:
        return self._seconds / SECONDS_IN_YEAR

    def to_timedelta(self) -> datetime.timedelta:
        return datetime.timedelta(seconds=self._seconds)

    def is_zero(self) -> bool:
        return self._seconds == 0

    # ---- protocol -------------------------------------------------------

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Duration):
            return self._seconds == other._seconds
        return NotImplemented

    def __lt__(self, other: Duration) -> bool:
        if not isinstance(other, Duration):
            return NotImplemented
        return self._seconds < other._seconds

    def __le__(self, other: Duration) -> bool:
        if not isinstance(other, Duration):
            return NotImplemented
        return self._seconds <= other._seconds

    def __gt__(self, other: Duration) -> bool:
        if not isinstance(other, Duration):
            return NotImplemented
        return self._seconds > other._seconds

    def __ge__(self, other: Duration) -> bool:
        if not isinstance(other, Duration):
            return NotImplemented
        return self._seconds >= other._seconds

    def __hash__(self) -> int:
        return hash(("Duration", self._seconds))

    def __str__(self) -> str:
        """Render as ``"1y 4w 2d 3h 5m 30s"`` (only non-zero parts;
        zero renders as ``"0s"``).
        """
        if self._seconds == 0:
            return "0s"
        parts = (
            ("y", SECONDS_IN_YEAR),
            ("w", SECONDS_IN_WEEK),
            ("d", SECONDS_IN_DAY),
            ("h", SECONDS_IN_HOUR),
            ("m", SECONDS_IN_MINUTE),
            ("s", 1),
        )
        remaining = self._seconds
        out: list[str] = []
        for unit, size in parts:
            if remaining >= size:
                n = remaining // size
                remaining -= n * size
                out.append(f"{n}{unit}")
        return " ".join(out)

    def __repr__(self) -> str:
        return f"Duration({self._seconds})"


__all__ = [
    "SECONDS_IN_DAY",
    "SECONDS_IN_HOUR",
    "SECONDS_IN_MINUTE",
    "SECONDS_IN_MONTH",
    "SECONDS_IN_WEEK",
    "SECONDS_IN_YEAR",
    "Duration",
]
