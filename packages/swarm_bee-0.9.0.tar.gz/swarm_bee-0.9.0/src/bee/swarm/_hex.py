"""Hex encode/decode helpers shared by typed-byte primitives."""

from __future__ import annotations

from .errors import BeeHexError


def decode_hex(s: str) -> bytes:
    """Decode lowercase hex with or without the ``0x`` prefix.

    Mirrors ``bee::swarm::bytes::decode_hex`` in bee-rs.
    """
    if s.startswith(("0x", "0X")):
        s = s[2:]
    if len(s) % 2 != 0:
        raise BeeHexError(f"odd-length hex string: {len(s)} chars")
    try:
        return bytes.fromhex(s)
    except ValueError as e:
        raise BeeHexError(str(e)) from e


def encode_hex(b: bytes) -> str:
    """Encode bytes as lowercase hex without the ``0x`` prefix."""
    return b.hex()
