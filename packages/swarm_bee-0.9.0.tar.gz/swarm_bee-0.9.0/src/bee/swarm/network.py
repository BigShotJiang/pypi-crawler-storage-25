"""Block-time aware network selector.

Mirrors bee-rs ``swarm::network`` and bee-js ``Network``. Used by stamp
duration math — Bee mainnet is on Ethereum (15-second blocks); Gnosis
Chain is the production Swarm settlement chain (~5-second blocks).
"""

from __future__ import annotations

from enum import Enum


class Network(Enum):
    """Settlement chain selector for stamp duration calculations."""

    #: Ethereum mainnet — 15-second average block time.
    MAINNET = "mainnet"
    #: Gnosis Chain — 5-second average block time. Default for Swarm.
    GNOSIS = "gnosis"

    def block_time_seconds(self) -> int:
        """Average block time in seconds."""
        return 15 if self is Network.MAINNET else 5

    def seconds_to_blocks(self, seconds: int) -> int:
        """Number of blocks in ``seconds``, rounded up."""
        bt = self.block_time_seconds()
        return -(-seconds // bt)  # ceil division

    def blocks_to_seconds(self, blocks: int) -> int:
        """Wall-clock seconds covered by ``blocks`` blocks."""
        return blocks * self.block_time_seconds()


__all__ = ["Network"]
