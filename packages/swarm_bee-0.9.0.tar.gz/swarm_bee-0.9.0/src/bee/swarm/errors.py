"""Crate-level exception hierarchy.

Mirrors bee-rs's ``Error`` enum / bee-go's ``BeeError`` family. Every
fallible bee-py call raises a subclass of :class:`BeeError`, so callers
can catch the base class for "anything went wrong with the Bee
client" or match on a specific subclass.
"""

from __future__ import annotations

from collections.abc import Sequence

#: Cap on captured response bodies so a huge error page can't OOM.
RESPONSE_BODY_CAP: int = 4096


class BeeError(Exception):
    """Base class for all bee-py errors."""


class BeeArgumentError(BeeError):
    """Caller passed an invalid argument.

    Mirrors bee-js / bee-go ``BeeArgumentError`` and bee-rs
    ``Error::Argument``.
    """


class BeeResponseError(BeeError):
    """Bee returned a non-2xx HTTP response.

    Mirrors bee-js / bee-go ``BeeResponseError`` and bee-rs
    ``Error::Response``. The first ``RESPONSE_BODY_CAP`` bytes of the
    body are captured for diagnostics.
    """

    def __init__(
        self,
        method: str,
        url: str,
        status: int,
        status_text: str,
        body: bytes,
    ) -> None:
        self.method = method
        self.url = url
        self.status = status
        self.status_text = status_text
        self.body = body[:RESPONSE_BODY_CAP]
        super().__init__(f"{method} {url}: {status} {status_text}")


class BeeLengthMismatchError(BeeArgumentError):
    """Typed-byte constructor rejected a value with the wrong length."""

    def __init__(self, kind: str, expected: Sequence[int], got: int) -> None:
        self.kind = kind
        self.expected = tuple(expected)
        self.got = got
        super().__init__(f"invalid {kind} length: got {got}, expected {list(self.expected)}")


class BeeHexError(BeeArgumentError):
    """Hex decoding failed."""


class BeeCryptoError(BeeError):
    """secp256k1 / keccak operation failed."""


class BeeJsonError(BeeError):
    """JSON encode/decode failed against an expected wire format."""


class BeeTransportError(BeeError):
    """Transport-level error (TCP / TLS / DNS / connection refused)."""


__all__ = [
    "RESPONSE_BODY_CAP",
    "BeeArgumentError",
    "BeeCryptoError",
    "BeeError",
    "BeeHexError",
    "BeeJsonError",
    "BeeLengthMismatchError",
    "BeeResponseError",
    "BeeTransportError",
]
