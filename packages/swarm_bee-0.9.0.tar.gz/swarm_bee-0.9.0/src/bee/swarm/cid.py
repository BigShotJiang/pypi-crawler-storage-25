"""Swarm reference ↔ CID conversion (manifest and feed codecs).

Mirrors bee-rs ``swarm::cid``, bee-go ``pkg/swarm/cid.go``, and
bee-js ``src/utils/cid.ts``. The encoding is base32 (RFC 4648, no
padding), lowercased, prefixed with ``b`` per the multibase spec.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .errors import BeeArgumentError
from .typed_bytes import Reference

#: Multicodec for the Swarm manifest CID type.
MANIFEST_CODEC: int = 0xFA
#: Multicodec for the Swarm feed CID type.
FEED_CODEC: int = 0xFB

_B32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
_B32_DECODE_MAP = {c: i for i, c in enumerate(_B32_ALPHABET)}


def _b32_encode(data: bytes) -> str:
    """RFC 4648 base32 encode, no padding."""
    out: list[str] = []
    buf = 0
    bits = 0
    for b in data:
        buf = (buf << 8) | b
        bits += 8
        while bits >= 5:
            bits -= 5
            out.append(_B32_ALPHABET[(buf >> bits) & 0x1F])
    if bits > 0:
        out.append(_B32_ALPHABET[(buf << (5 - bits)) & 0x1F])
    return "".join(out)


def _b32_decode(s: str) -> bytes:
    """RFC 4648 base32 decode, accepting upper-case input only."""
    out = bytearray()
    buf = 0
    bits = 0
    for c in s:
        v = _B32_DECODE_MAP.get(c)
        if v is None:
            raise BeeArgumentError(f"invalid base32 character: {c!r}")
        buf = (buf << 5) | v
        bits += 5
        if bits >= 8:
            bits -= 8
            out.append((buf >> bits) & 0xFF)
    return bytes(out)


class CidType(Enum):
    """CID-encoded reference type."""

    MANIFEST = MANIFEST_CODEC
    FEED = FEED_CODEC

    @classmethod
    def from_codec(cls, codec: int) -> CidType:
        try:
            return cls(codec)
        except ValueError as e:
            raise BeeArgumentError(f"unknown CID codec: 0x{codec:02x}") from e


@dataclass(frozen=True, slots=True)
class DecodedCid:
    """Decoded CID payload returned by :func:`convert_cid_to_reference`."""

    kind: CidType
    reference: Reference


def convert_reference_to_cid(reference: Reference, kind: CidType) -> str:
    """Encode a 32-byte Swarm reference as a CID string.

    Output is ``"b" + base32(header + reference)`` lowercased, where
    ``header = [version=1, codec, _=1, sha256=0x1b, size=32]``.
    Encrypted (64-byte) references are rejected.
    """
    if len(reference.as_bytes()) != 32:
        raise BeeArgumentError(
            "encrypted references (64 bytes) cannot be encoded as a CID"
        )
    header = bytes([1, kind.value, 1, 0x1B, 32])
    encoded = _b32_encode(header + reference.as_bytes()).lower()
    return f"b{encoded}"


def convert_cid_to_reference(cid: str) -> DecodedCid:
    """Decode a CID string into its codec type + Swarm reference.

    Raises :class:`BeeArgumentError` for unknown codecs, missing
    multibase prefix, or short inputs.
    """
    if not cid.startswith("b"):
        raise BeeArgumentError("CID must start with multibase prefix 'b'")
    body = cid[1:].upper()
    raw = _b32_decode(body)
    if len(raw) < 32:
        raise BeeArgumentError(f"decoded CID too short: {len(raw)} bytes")
    # bee-js / bee-go convention: codec is byte index 1; reference is
    # the last 32 bytes.
    kind = CidType.from_codec(raw[1])
    ref_bytes = raw[-32:]
    return DecodedCid(kind=kind, reference=Reference(ref_bytes))


__all__ = [
    "FEED_CODEC",
    "MANIFEST_CODEC",
    "CidType",
    "DecodedCid",
    "convert_cid_to_reference",
    "convert_reference_to_cid",
]
