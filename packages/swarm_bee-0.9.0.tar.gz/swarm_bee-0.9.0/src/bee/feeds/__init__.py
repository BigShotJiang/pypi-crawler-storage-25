"""Swarm feeds — sequential SOC streams keyed on ``(owner, topic)``.

Mirrors bee-rs ``file::feeds`` and bee-go ``pkg/file/feed.go``. A feed
is a sequence of Single Owner Chunks under a fixed ``(owner, topic)``
pair. Each update has a 64-bit big-endian index and is signed by the
owner. The chunk identifier is ``keccak256(topic || BE-uint64(index))``;
the chunk payload is ``BE-uint64(timestamp) || data``.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import httpx

from .._inner import _AsyncInner, _decode_json, _SyncInner
from ..api.options import DownloadOptions, prepare_download_headers
from ..api.result import UploadResult
from ..swarm.bmt import keccak256
from ..swarm.errors import BeeArgumentError, BeeJsonError, BeeResponseError
from ..swarm.keys import PrivateKey
from ..swarm.soc import make_single_owner_chunk
from ..swarm.typed_bytes import (
    BatchId,
    EthAddress,
    Identifier,
    Reference,
    Topic,
)


@dataclass(frozen=True, slots=True)
class FeedUpdate:
    """Result of a feed lookup.

    The payload is the raw chunk body — ``timestamp(8) || data``;
    ``index`` is the index of the returned update; ``index_next`` is
    where the next sequential update should be written
    (``index + 1``). Mirrors bee-js ``FeedPayloadResult``.
    """

    payload: bytes
    index: int
    index_next: int


def make_feed_identifier(topic: Topic, index: int) -> Identifier:
    """Compute the SOC identifier for a feed update.

    ``keccak256(topic || BE-uint64(index))`` — matches bee-go /
    bee-js / bee-rs.
    """
    if not 0 <= index < (1 << 64):
        raise OverflowError(f"feed index out of range for u64: {index}")
    return Identifier(keccak256(topic.as_bytes() + index.to_bytes(8, "big")))


def feed_update_chunk_address(owner: EthAddress, topic: Topic, index: int) -> Reference:
    """Compute the SOC chunk address for a feed update.

    ``keccak256(identifier || owner)`` — same as any SOC. Useful for
    direct ``GET /chunks/{addr}`` retrievability checks.
    """
    identifier = make_feed_identifier(topic, index)
    return Reference(keccak256(identifier.as_bytes() + owner.as_bytes()))


def _decode_feed_index_header(headers: httpx.Headers, name: str) -> int:
    """Pull a ``swarm-feed-index*`` header (8-byte BE hex) and decode."""
    value = headers.get(name)
    if not value:
        raise BeeArgumentError(f"missing {name} header")
    raw = bytes.fromhex(value)
    if len(raw) != 8:
        raise BeeArgumentError(f"{name}: expected 8 bytes, got {len(raw)}")
    return int.from_bytes(raw, "big")


def _parse_reference(payload: object) -> Reference:
    if not isinstance(payload, dict) or "reference" not in payload:
        raise BeeJsonError(f"missing 'reference' in feed response: {payload!r}")
    ref = payload["reference"]
    if not isinstance(ref, str):
        raise BeeJsonError(f"'reference' is not a string: {ref!r}")
    return Reference.from_hex(ref)


def _build_payload(data: bytes, *, timestamp: int | None = None) -> bytes:
    ts = timestamp if timestamp is not None else int(time.time())
    if not 0 <= ts < (1 << 64):
        raise OverflowError(f"timestamp out of range for u64: {ts}")
    return ts.to_bytes(8, "big") + data


# ---- Async surface -------------------------------------------------------


class AsyncFeedApi:
    """Async feed-domain handle. Reachable as :attr:`bee.AsyncBee.feeds`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _AsyncInner) -> None:
        self._inner = inner

    async def create_feed_manifest(
        self, batch_id: BatchId, owner: EthAddress, topic: Topic
    ) -> Reference:
        """``POST /feeds/{owner}/{topic}`` — create a feed manifest."""
        path = f"feeds/{owner.to_hex()}/{topic.to_hex()}"
        response = await self._inner.send(
            "POST",
            path,
            headers=[("Swarm-Postage-Batch-Id", batch_id.to_hex())],
        )
        return _parse_reference(_decode_json(response.content))

    async def get_feed_lookup(self, owner: EthAddress, topic: Topic) -> Reference:
        """``GET /feeds/{owner}/{topic}`` — return the feed-manifest reference."""
        path = f"feeds/{owner.to_hex()}/{topic.to_hex()}"
        response = await self._inner.send("GET", path)
        return _parse_reference(_decode_json(response.content))

    async def fetch_latest(self, owner: EthAddress, topic: Topic) -> FeedUpdate:
        """Fetch the most recent feed update.

        Body is the wrapped chunk payload (``timestamp(8) || data``);
        the ``swarm-feed-index`` and ``swarm-feed-index-next`` headers
        carry the indexes as 8-byte big-endian hex.
        """
        path = f"feeds/{owner.to_hex()}/{topic.to_hex()}"
        response = await self._inner.send("GET", path)
        index = _decode_feed_index_header(response.headers, "swarm-feed-index")
        index_next = _decode_feed_index_header(response.headers, "swarm-feed-index-next")
        return FeedUpdate(payload=response.content, index=index, index_next=index_next)

    async def find_next_index(self, owner: EthAddress, topic: Topic) -> int:
        """Index where the next update should be written. Empty feed → ``0``."""
        try:
            update = await self.fetch_latest(owner, topic)
        except BeeResponseError as e:
            if e.status in (404, 500):
                return 0
            raise
        return update.index_next

    async def update_feed_with_index(
        self,
        batch_id: BatchId,
        signer: PrivateKey,
        topic: Topic,
        index: int,
        data: bytes,
    ) -> UploadResult:
        """Update the feed at a specific index. SOC under
        ``keccak256(topic || BE-u64(index))`` with payload
        ``BE-u64(now) || data``.
        """
        identifier = make_feed_identifier(topic, index)
        payload = _build_payload(data)
        soc = make_single_owner_chunk(identifier, payload, signer)
        body = soc.span.as_bytes() + soc.payload
        # `client.feeds` doesn't import `client.file`; we POST directly.
        path = f"soc/{soc.owner.to_hex()}/{identifier.to_hex()}"
        response = await self._inner.send(
            "POST",
            path,
            content=body,
            headers=[
                ("Swarm-Postage-Batch-Id", batch_id.to_hex()),
                ("Content-Type", "application/octet-stream"),
            ],
            params={"sig": soc.signature.to_hex()},
        )
        decoded = _decode_json(response.content)
        if not isinstance(decoded, dict) or "reference" not in decoded:
            raise BeeJsonError(f"missing 'reference' in SOC response: {decoded!r}")
        ref = decoded["reference"]
        if not isinstance(ref, str):
            raise BeeJsonError(f"'reference' is not a string: {ref!r}")
        return UploadResult.from_response(ref, response.headers)

    async def update_feed(
        self,
        batch_id: BatchId,
        signer: PrivateKey,
        topic: Topic,
        data: bytes,
    ) -> UploadResult:
        """Update the feed at the next available index."""
        owner = signer.public_key().address()
        index = await self.find_next_index(owner, topic)
        return await self.update_feed_with_index(batch_id, signer, topic, index, data)

    async def update_feed_with_reference(
        self,
        batch_id: BatchId,
        signer: PrivateKey,
        topic: Topic,
        reference: Reference,
        index: int | None = None,
    ) -> UploadResult:
        """Update the feed to point at ``reference`` (32 or 64 bytes)."""
        owner = signer.public_key().address()
        idx = index if index is not None else await self.find_next_index(owner, topic)
        return await self.update_feed_with_index(
            batch_id, signer, topic, idx, reference.as_bytes()
        )

    async def is_feed_retrievable(
        self,
        owner: EthAddress,
        topic: Topic,
        index: int | None = None,
        opts: DownloadOptions | None = None,
    ) -> bool:
        """True iff the feed currently resolves on the network.

        ``index=None`` checks only the latest; otherwise every chunk
        from ``0`` through ``index`` (inclusive) is checked.
        """
        if index is not None:
            return await self._all_sequential_retrievable(owner, topic, index, opts)
        try:
            await self.fetch_latest(owner, topic)
        except BeeResponseError as e:
            if e.status in (404, 500):
                return False
            raise
        return True

    async def _all_sequential_retrievable(
        self,
        owner: EthAddress,
        topic: Topic,
        index: int,
        opts: DownloadOptions | None,
    ) -> bool:
        headers = prepare_download_headers(opts)
        for i in range(index + 1):
            addr = feed_update_chunk_address(owner, topic, i)
            try:
                await self._inner.send("GET", f"chunks/{addr.to_hex()}", headers=headers)
            except BeeResponseError as e:
                if e.status in (404, 500):
                    return False
                raise
        return True

    def make_reader(self, owner: EthAddress, topic: Topic) -> AsyncFeedReader:
        """Bind a reader to ``(owner, topic)``."""
        return AsyncFeedReader(self, owner, topic)

    def make_writer(self, signer: PrivateKey, topic: Topic) -> AsyncFeedWriter:
        """Bind a writer to ``(signer, topic)`` — owner is derived."""
        owner = signer.public_key().address()
        return AsyncFeedWriter(self, signer, owner, topic)


class AsyncFeedReader:
    """Read-side handle for a fixed ``(owner, topic)`` pair."""

    __slots__ = ("_api", "owner", "topic")

    def __init__(self, api: AsyncFeedApi, owner: EthAddress, topic: Topic) -> None:
        self._api = api
        self.owner = owner
        self.topic = topic

    async def download(self) -> FeedUpdate:
        return await self._api.fetch_latest(self.owner, self.topic)

    async def lookup(self) -> Reference:
        return await self._api.get_feed_lookup(self.owner, self.topic)

    async def next_index(self) -> int:
        return await self._api.find_next_index(self.owner, self.topic)

    async def is_retrievable(
        self, index: int | None = None, opts: DownloadOptions | None = None
    ) -> bool:
        return await self._api.is_feed_retrievable(self.owner, self.topic, index, opts)


class AsyncFeedWriter:
    """Write-side handle for a fixed ``(signer, topic)`` pair."""

    __slots__ = ("_api", "_signer", "owner", "topic")

    def __init__(
        self,
        api: AsyncFeedApi,
        signer: PrivateKey,
        owner: EthAddress,
        topic: Topic,
    ) -> None:
        self._api = api
        self._signer = signer
        self.owner = owner
        self.topic = topic

    async def upload_payload(self, batch_id: BatchId, data: bytes) -> UploadResult:
        return await self._api.update_feed(batch_id, self._signer, self.topic, data)

    async def upload_payload_at(
        self, batch_id: BatchId, index: int, data: bytes
    ) -> UploadResult:
        return await self._api.update_feed_with_index(
            batch_id, self._signer, self.topic, index, data
        )

    async def upload_reference(
        self,
        batch_id: BatchId,
        reference: Reference,
        index: int | None = None,
    ) -> UploadResult:
        return await self._api.update_feed_with_reference(
            batch_id, self._signer, self.topic, reference, index
        )


# ---- Sync surface --------------------------------------------------------


class FeedApi:
    """Sync feed-domain handle. Reachable as :attr:`bee.Bee.feeds`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _SyncInner) -> None:
        self._inner = inner

    def create_feed_manifest(
        self, batch_id: BatchId, owner: EthAddress, topic: Topic
    ) -> Reference:
        path = f"feeds/{owner.to_hex()}/{topic.to_hex()}"
        response = self._inner.send(
            "POST", path, headers=[("Swarm-Postage-Batch-Id", batch_id.to_hex())]
        )
        return _parse_reference(_decode_json(response.content))

    def get_feed_lookup(self, owner: EthAddress, topic: Topic) -> Reference:
        path = f"feeds/{owner.to_hex()}/{topic.to_hex()}"
        response = self._inner.send("GET", path)
        return _parse_reference(_decode_json(response.content))

    def fetch_latest(self, owner: EthAddress, topic: Topic) -> FeedUpdate:
        path = f"feeds/{owner.to_hex()}/{topic.to_hex()}"
        response = self._inner.send("GET", path)
        index = _decode_feed_index_header(response.headers, "swarm-feed-index")
        index_next = _decode_feed_index_header(response.headers, "swarm-feed-index-next")
        return FeedUpdate(payload=response.content, index=index, index_next=index_next)

    def find_next_index(self, owner: EthAddress, topic: Topic) -> int:
        try:
            update = self.fetch_latest(owner, topic)
        except BeeResponseError as e:
            if e.status in (404, 500):
                return 0
            raise
        return update.index_next

    def update_feed_with_index(
        self,
        batch_id: BatchId,
        signer: PrivateKey,
        topic: Topic,
        index: int,
        data: bytes,
    ) -> UploadResult:
        identifier = make_feed_identifier(topic, index)
        payload = _build_payload(data)
        soc = make_single_owner_chunk(identifier, payload, signer)
        body = soc.span.as_bytes() + soc.payload
        path = f"soc/{soc.owner.to_hex()}/{identifier.to_hex()}"
        response = self._inner.send(
            "POST",
            path,
            content=body,
            headers=[
                ("Swarm-Postage-Batch-Id", batch_id.to_hex()),
                ("Content-Type", "application/octet-stream"),
            ],
            params={"sig": soc.signature.to_hex()},
        )
        decoded = _decode_json(response.content)
        if not isinstance(decoded, dict) or "reference" not in decoded:
            raise BeeJsonError(f"missing 'reference' in SOC response: {decoded!r}")
        ref = decoded["reference"]
        if not isinstance(ref, str):
            raise BeeJsonError(f"'reference' is not a string: {ref!r}")
        return UploadResult.from_response(ref, response.headers)

    def update_feed(
        self, batch_id: BatchId, signer: PrivateKey, topic: Topic, data: bytes
    ) -> UploadResult:
        owner = signer.public_key().address()
        index = self.find_next_index(owner, topic)
        return self.update_feed_with_index(batch_id, signer, topic, index, data)

    def update_feed_with_reference(
        self,
        batch_id: BatchId,
        signer: PrivateKey,
        topic: Topic,
        reference: Reference,
        index: int | None = None,
    ) -> UploadResult:
        owner = signer.public_key().address()
        idx = index if index is not None else self.find_next_index(owner, topic)
        return self.update_feed_with_index(
            batch_id, signer, topic, idx, reference.as_bytes()
        )

    def is_feed_retrievable(
        self,
        owner: EthAddress,
        topic: Topic,
        index: int | None = None,
        opts: DownloadOptions | None = None,
    ) -> bool:
        if index is not None:
            return self._all_sequential_retrievable(owner, topic, index, opts)
        try:
            self.fetch_latest(owner, topic)
        except BeeResponseError as e:
            if e.status in (404, 500):
                return False
            raise
        return True

    def _all_sequential_retrievable(
        self,
        owner: EthAddress,
        topic: Topic,
        index: int,
        opts: DownloadOptions | None,
    ) -> bool:
        headers = prepare_download_headers(opts)
        for i in range(index + 1):
            addr = feed_update_chunk_address(owner, topic, i)
            try:
                self._inner.send("GET", f"chunks/{addr.to_hex()}", headers=headers)
            except BeeResponseError as e:
                if e.status in (404, 500):
                    return False
                raise
        return True

    def make_reader(self, owner: EthAddress, topic: Topic) -> FeedReader:
        return FeedReader(self, owner, topic)

    def make_writer(self, signer: PrivateKey, topic: Topic) -> FeedWriter:
        owner = signer.public_key().address()
        return FeedWriter(self, signer, owner, topic)


class FeedReader:
    """Sync read-side handle for a fixed ``(owner, topic)`` pair."""

    __slots__ = ("_api", "owner", "topic")

    def __init__(self, api: FeedApi, owner: EthAddress, topic: Topic) -> None:
        self._api = api
        self.owner = owner
        self.topic = topic

    def download(self) -> FeedUpdate:
        return self._api.fetch_latest(self.owner, self.topic)

    def lookup(self) -> Reference:
        return self._api.get_feed_lookup(self.owner, self.topic)

    def next_index(self) -> int:
        return self._api.find_next_index(self.owner, self.topic)

    def is_retrievable(
        self, index: int | None = None, opts: DownloadOptions | None = None
    ) -> bool:
        return self._api.is_feed_retrievable(self.owner, self.topic, index, opts)


class FeedWriter:
    """Sync write-side handle for a fixed ``(signer, topic)`` pair."""

    __slots__ = ("_api", "_signer", "owner", "topic")

    def __init__(
        self, api: FeedApi, signer: PrivateKey, owner: EthAddress, topic: Topic
    ) -> None:
        self._api = api
        self._signer = signer
        self.owner = owner
        self.topic = topic

    def upload_payload(self, batch_id: BatchId, data: bytes) -> UploadResult:
        return self._api.update_feed(batch_id, self._signer, self.topic, data)

    def upload_payload_at(
        self, batch_id: BatchId, index: int, data: bytes
    ) -> UploadResult:
        return self._api.update_feed_with_index(
            batch_id, self._signer, self.topic, index, data
        )

    def upload_reference(
        self,
        batch_id: BatchId,
        reference: Reference,
        index: int | None = None,
    ) -> UploadResult:
        return self._api.update_feed_with_reference(
            batch_id, self._signer, self.topic, reference, index
        )


__all__ = [
    "AsyncFeedApi",
    "AsyncFeedReader",
    "AsyncFeedWriter",
    "FeedApi",
    "FeedReader",
    "FeedUpdate",
    "FeedWriter",
    "feed_update_chunk_address",
    "make_feed_identifier",
]
