"""Mantaray v0.2 wire format.

Mirrors bee-rs ``manifest::wire`` and bee-go's
``pkg/manifest/manifest.go`` Marshal / Unmarshal block.

Layout (after the 32-byte obfuscation key, body XORed with the key)::

    key (32) | versionHash (31) | targetLen (1) | target (targetLen)
            | forkBitmap (32)
            | for each set bit i in 0..256:
                  type (1) | prefixLen (1) | prefix (30, 0-padded)
                          | childAddr (selfAddrLen)
                          | if type & WITH_METADATA:
                                metaLen (2 BE) | metaJson (metaLen, 0x0a-padded to /32)

.. note::
   ``calculate_self_address`` currently expects manifests that fit in
   a single 4096-byte chunk (the typical case for collections of up
   to ~30 entries with light metadata). Multi-chunk Mantaray
   addressing (`FileChunker`-style multi-level BMT) lands in a later
   milestone.
"""

from __future__ import annotations

import json

from ..swarm.bmt import CHUNK_SIZE, calculate_chunk_address
from ..swarm.errors import BeeArgumentError, BeeJsonError
from ..swarm.typed_bytes import REFERENCE_LENGTH, SPAN_LENGTH, Span
from ._helpers import (
    Reader,
    get_bit_le,
    has_type,
    pad_end_to_multiple,
    set_bit_le,
    xor_in_place,
)
from .node import (
    MAX_PREFIX_LENGTH,
    NULL_ADDRESS,
    PATH_SEPARATOR,
    TYPE_WITH_METADATA,
    Fork,
    MantarayNode,
    is_null_address,
)

#: Hex string of the v0.2 version hash. Only the first 31 bytes are
#: written into the marshaled header; the 32nd byte slot is reused as
#: the target-address length.
VERSION_02_HASH_HEX: str = "5768b3b6a7db56d21d1abff40d41cebfc83448fed8d7e9b06ec0d3b073f28f7b"
_VERSION_02_HASH: bytes = bytes.fromhex(VERSION_02_HASH_HEX)


# ---- marshal -------------------------------------------------------------


def marshal(node: MantarayNode) -> bytes:
    """Serialize ``node`` (and the references to its children) using the
    v0.2 wire format. Children must already have ``self_address``
    populated; pass through :func:`populate_self_addresses` first.
    """
    for fork in node.forks.values():
        if fork.node.self_address is None:
            raise BeeArgumentError(
                "marshal: child self_address not populated; call populate_self_addresses first"
            )

    # Header: 31 bytes of v02 hash + 1 byte for target-address length.
    path_is_root_dir = len(node.path) == 1 and node.path[0] == PATH_SEPARATOR
    root_dir_node = is_null_address(node.target_address) and path_is_root_dir
    header = bytearray(32)
    header[:31] = _VERSION_02_HASH[:31]
    header[31] = 0 if root_dir_node else len(node.target_address)

    # Fork bitmap.
    fork_bitmap = bytearray(32)
    for k in node.forks:
        set_bit_le(fork_bitmap, k)

    body = bytearray()
    body.extend(header)
    if not root_dir_node:
        body.extend(node.target_address)
    body.extend(fork_bitmap)

    # Forks emitted in ascending bitmap order so encoders agree.
    for i in sorted(node.forks):
        body.extend(_marshal_fork(node.forks[i]))

    xor_in_place(body, node.obfuscation_key)

    return bytes(node.obfuscation_key) + bytes(body)


def _marshal_fork(f: Fork) -> bytes:
    if f.node.self_address is None:
        raise BeeArgumentError("_marshal_fork: child self_address not populated")
    if len(f.prefix) > MAX_PREFIX_LENGTH:
        raise BeeArgumentError(
            f"_marshal_fork: prefix length {len(f.prefix)} exceeds max {MAX_PREFIX_LENGTH}"
        )

    out = bytearray()
    out.append(f.node.determine_type())
    out.append(len(f.prefix))
    out.extend(f.prefix)
    if len(f.prefix) < MAX_PREFIX_LENGTH:
        out.extend(b"\x00" * (MAX_PREFIX_LENGTH - len(f.prefix)))
    out.extend(f.node.self_address)

    if f.node.metadata is not None:
        # Metadata layout: 2-byte BE length of (json + padding) +
        # json + 0x0a padding to 32-byte multiple. The 2-byte length
        # value covers (json + padding), excluding itself.
        # bee-go uses sorted keys for determinism.
        meta_json = json.dumps(f.node.metadata, separators=(",", ":"), sort_keys=True).encode(
            "utf-8"
        )
        body = bytearray(2)  # placeholder for length
        body.extend(meta_json)
        padded = bytearray(pad_end_to_multiple(bytes(body), 32, 0x0A))
        # Now write the actual length (padded.len() - 2).
        total = len(padded) - 2
        if total > 0xFFFF:
            raise BeeArgumentError(f"_marshal_fork: metadata too large: {total}")
        padded[0] = (total >> 8) & 0xFF
        padded[1] = total & 0xFF
        out.extend(padded)

    return bytes(out)


# ---- unmarshal -----------------------------------------------------------


def unmarshal(data: bytes, self_address: bytes) -> MantarayNode:
    """Parse a marshaled node.

    ``self_address`` is the chunk address that produced ``data``; it
    determines the per-fork child address length (32 bytes for
    standard Swarm references). Children are referenced by
    ``self_address`` only and remain unloaded (no recursive walk).
    """
    if len(data) < 32:
        raise BeeArgumentError("mantaray: data too short")
    obfuscation_key = bytes(data[:32])
    body = bytearray(data[32:])
    xor_in_place(body, obfuscation_key)

    r = Reader(bytes(body))
    version_hash = r.read(31)
    if version_hash is None:
        raise BeeArgumentError("mantaray: short version hash")
    if version_hash != _VERSION_02_HASH[:31]:
        raise BeeArgumentError("mantaray: invalid version hash")

    target_length = r.read_byte()
    if target_length is None:
        raise BeeArgumentError("mantaray: missing target length")

    target = bytearray(NULL_ADDRESS)
    if target_length > 0:
        raw = r.read(target_length)
        if raw is None:
            raise BeeArgumentError("mantaray: short target")
        n = min(len(raw), REFERENCE_LENGTH)
        target[:n] = raw[:n]

    fork_bitmap = r.read(32)
    if fork_bitmap is None:
        raise BeeArgumentError("mantaray: short fork bitmap")

    self_address_arr = bytearray(REFERENCE_LENGTH)
    take = min(len(self_address), REFERENCE_LENGTH)
    self_address_arr[:take] = self_address[:take]

    node = MantarayNode(
        obfuscation_key=obfuscation_key,
        self_address=bytes(self_address_arr),
        target_address=bytes(target),
        metadata=None,
        path=b"",
        forks={},
    )

    address_length = len(self_address)
    for i in range(256):
        if not get_bit_le(fork_bitmap, i):
            continue
        try:
            fork = _unmarshal_fork(r, address_length)
        except BeeArgumentError as e:
            raise BeeArgumentError(f"mantaray fork {i}: {e}") from e
        node.forks[i] = fork

    return node


def _unmarshal_fork(r: Reader, address_length: int) -> Fork:
    t = r.read_byte()
    if t is None:
        raise BeeArgumentError("fork: missing type")
    prefix_length = r.read_byte()
    if prefix_length is None:
        raise BeeArgumentError("fork: missing prefix length")
    prefix = r.read(prefix_length)
    if prefix is None:
        raise BeeArgumentError("fork: short prefix")
    if prefix_length < MAX_PREFIX_LENGTH and r.read(MAX_PREFIX_LENGTH - prefix_length) is None:
        raise BeeArgumentError("fork: short prefix padding")

    self_addr = r.read(address_length)
    if self_addr is None:
        raise BeeArgumentError("fork: short child address")
    self_addr_arr = bytearray(REFERENCE_LENGTH)
    take = min(len(self_addr), REFERENCE_LENGTH)
    self_addr_arr[:take] = self_addr[:take]

    metadata: dict[str, str] | None = None
    if has_type(t, TYPE_WITH_METADATA):
        len_bytes = r.read(2)
        if len_bytes is None:
            raise BeeArgumentError("fork: short metadata length")
        mlen = (len_bytes[0] << 8) | len_bytes[1]
        meta_bytes = r.read(mlen)
        if meta_bytes is None:
            raise BeeArgumentError("fork: short metadata")
        trimmed = _trim_right(meta_bytes, 0x0A)
        if not trimmed:
            metadata = {}
        else:
            try:
                parsed = json.loads(trimmed)
            except json.JSONDecodeError as e:
                raise BeeJsonError(f"fork: invalid metadata JSON: {e}") from e
            if not isinstance(parsed, dict):
                raise BeeJsonError(f"fork: metadata is not an object: {parsed!r}")
            metadata = {str(k): str(v) for k, v in parsed.items()}

    return Fork(
        prefix=bytes(prefix),
        node=MantarayNode(
            obfuscation_key=bytes(32),
            self_address=bytes(self_addr_arr),
            target_address=NULL_ADDRESS,
            metadata=metadata,
            path=bytes(prefix),
            forks={},
        ),
    )


def _trim_right(data: bytes, byte: int) -> bytes:
    end = len(data)
    while end > 0 and data[end - 1] == byte:
        end -= 1
    return data[:end]


# ---- self-address calculation -------------------------------------------


def calculate_self_address(node: MantarayNode) -> bytes:
    """Return ``node``'s chunk address as 32 bytes.

    If ``node.self_address`` is already populated it is returned
    unchanged. Otherwise the marshaled body is content-addressed via
    BMT.

    .. note::
       Only single-chunk manifests (≤ 4096 bytes after marshaling)
       are supported in 0.4. Multi-level BMT for larger manifests
       lands later.
    """
    if node.self_address is not None:
        return node.self_address
    data = marshal(node)
    if len(data) > CHUNK_SIZE:
        raise BeeArgumentError(
            f"calculate_self_address: marshaled node is {len(data)} bytes "
            f"(> {CHUNK_SIZE}); multi-chunk Mantaray is not yet supported"
        )
    span = Span.from_int(len(data)).as_bytes()
    return calculate_chunk_address(span + data)


def populate_self_addresses(node: MantarayNode) -> bytes:
    """Recursively populate ``self_address`` on ``node`` and every
    child. Mirrors bee-go's pre-marshal walk. Returns the root's
    self-address.
    """
    if node.self_address is not None:
        return node.self_address
    for fork in node.forks.values():
        child_addr = populate_self_addresses(fork.node)
        fork.node.self_address = child_addr
    addr = calculate_self_address(node)
    node.self_address = addr
    return addr


__all__ = [
    "VERSION_02_HASH_HEX",
    "calculate_self_address",
    "marshal",
    "populate_self_addresses",
    "unmarshal",
]


# Silence ruff: SPAN_LENGTH is imported for type alignment with the
# bee-rs port even though we don't reference it directly in the body.
_ = SPAN_LENGTH
