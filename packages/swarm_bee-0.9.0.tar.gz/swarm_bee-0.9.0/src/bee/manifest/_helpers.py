"""Internal helpers for the Mantaray wire format and trie operations."""

from __future__ import annotations


def xor_in_place(dst: bytearray, key: bytes) -> None:
    """XOR ``dst`` byte-by-byte with ``key``, repeating ``key`` as
    needed. Empty ``key`` is a no-op (matches bee-js ``xorCypher``).
    """
    if not key:
        return
    klen = len(key)
    for i in range(len(dst)):
        dst[i] ^= key[i % klen]


def set_bit_le(buf: bytearray, idx: int) -> None:
    """Set bit ``idx`` in ``buf`` using LSB-first packing within each
    byte (``bit i`` lives at ``byte (i>>3)``, ``mask 1 << (i & 7)``).
    """
    buf[idx >> 3] |= 1 << (idx & 7)


def get_bit_le(buf: bytes | bytearray, idx: int) -> bool:
    """Read bit ``idx`` from ``buf`` using LSB-first packing."""
    return (buf[idx >> 3] & (1 << (idx & 7))) != 0


def has_type(t: int, mask: int) -> bool:
    """True iff ``t`` has every bit of ``mask`` set."""
    return (t & mask) == mask


def common_prefix(a: bytes, b: bytes) -> bytes:
    """Longest common prefix of ``a`` and ``b``."""
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return a[:i]
    return a[:n]


def pad_end_to_multiple(buf: bytes, m: int, pad: int) -> bytes:
    """Right-pad ``buf`` with ``pad`` bytes so its length is a multiple
    of ``m``. If ``buf`` is already aligned, returns ``buf`` unchanged.
    """
    r = len(buf) % m
    if r == 0:
        return buf
    return buf + bytes([pad]) * (m - r)


class Reader:
    """Tiny binary cursor with a single error path."""

    __slots__ = ("_buf", "_pos")

    def __init__(self, buf: bytes) -> None:
        self._buf: bytes = buf
        self._pos: int = 0

    def read(self, n: int) -> bytes | None:
        """Read ``n`` bytes and advance the cursor. Returns ``None`` if
        the buffer doesn't have enough remaining bytes.
        """
        end = self._pos + n
        if end > len(self._buf):
            return None
        out = self._buf[self._pos : end]
        self._pos = end
        return out

    def read_byte(self) -> int | None:
        """Read one byte. Returns ``None`` if at end-of-buffer."""
        chunk = self.read(1)
        if chunk is None:
            return None
        return chunk[0]

    @property
    def pos(self) -> int:
        return self._pos


__all__ = [
    "Reader",
    "common_prefix",
    "get_bit_le",
    "has_type",
    "pad_end_to_multiple",
    "set_bit_le",
    "xor_in_place",
]
