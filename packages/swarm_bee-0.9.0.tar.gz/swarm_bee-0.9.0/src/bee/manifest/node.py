"""``MantarayNode``, ``Fork``, and the trie operations.

Mirrors bee-rs ``manifest::node`` and bee-go ``pkg/manifest/manifest.go`` /
bee-js ``mantaray-js``. The marshal / unmarshal pair lives in
:mod:`bee.manifest.wire`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..swarm.errors import BeeArgumentError
from ..swarm.typed_bytes import REFERENCE_LENGTH, Reference
from ._helpers import common_prefix

# ---- type bitfield (used by the wire format) -----------------------------

#: Type bit: this node has a non-null target address.
TYPE_VALUE: int = 2
#: Type bit: this node has child forks.
TYPE_EDGE: int = 4
#: Type bit: this node's path contains a non-leading ``/``.
TYPE_WITH_PATH_SEPARATOR: int = 8
#: Type bit: this fork carries metadata.
TYPE_WITH_METADATA: int = 16

#: Path separator byte.
PATH_SEPARATOR: int = ord("/")

#: Per-fork prefix length cap. Longer paths split into chained nodes
#: with prefixes ≤ :data:`MAX_PREFIX_LENGTH` each.
MAX_PREFIX_LENGTH: int = 30

#: All-zero 32-byte target address — the canonical "no target" value.
NULL_ADDRESS: bytes = b"\x00" * REFERENCE_LENGTH


def is_null_address(b: bytes) -> bool:
    """True iff ``b`` is empty or all zeros (the canonical null target)."""
    return len(b) == 0 or all(x == 0 for x in b)


# ---- Fork + MantarayNode -------------------------------------------------


@dataclass
class Fork:
    """One edge of the trie. ``prefix`` is the path bytes that select
    this child; ``node`` is the child node.
    """

    #: Path bytes selecting this child.
    prefix: bytes
    #: Child node.
    node: MantarayNode


@dataclass
class MantarayNode:
    """One node of the Mantaray trie. Field names mirror bee-js / bee-go.

    - ``obfuscation_key``: 32-byte XOR mask used when serializing this
      node. Freshly-constructed nodes use a zero key.
    - ``self_address``: chunk address of the marshaled node, populated
      after :func:`bee.manifest.wire.calculate_self_address` /
      :func:`populate_self_addresses`. ``None`` means "not computed".
    - ``target_address``: 32-byte file reference at this node, or
      :data:`NULL_ADDRESS` for pure directory nodes.
    - ``path``: edge label inherited from the parent fork's prefix; the
      root has an empty path.
    - ``forks``: child edges keyed by first prefix byte. Iteration order
      is sorted by key for deterministic marshal output.
    - ``metadata``: optional key/value annotations carried in the wire
      format.
    """

    obfuscation_key: bytes = field(default_factory=lambda: bytes(32))
    self_address: bytes | None = None
    target_address: bytes = field(default_factory=lambda: NULL_ADDRESS)
    metadata: dict[str, str] | None = None
    path: bytes = b""
    forks: dict[int, Fork] = field(default_factory=dict)

    def is_null_target(self) -> bool:
        """True iff this node's ``target_address`` is the null address."""
        return is_null_address(self.target_address)

    def determine_type(self) -> int:
        """Pack the type bitfield used in this node's outgoing fork
        record. Mirrors bee-rs ``MantarayNode::determine_type``.
        """
        t = 0
        path_is_root_dir = len(self.path) == 1 and self.path[0] == PATH_SEPARATOR

        if not self.is_null_target() or path_is_root_dir:
            t |= TYPE_VALUE
        if self.forks:
            t |= TYPE_EDGE
        if PATH_SEPARATOR in self.path and not path_is_root_dir:
            t |= TYPE_WITH_PATH_SEPARATOR
        if self.metadata is not None:
            t |= TYPE_WITH_METADATA
        return t

    # ---- trie traversal --------------------------------------------------

    def find_closest(self, path: bytes) -> tuple[MantarayNode, bytes]:
        """Walk down forks while ``path`` matches.

        Returns the deepest node reached and the bytes of ``path``
        matched along the way.
        """
        cur: MantarayNode = self
        matched = bytearray()
        remaining = path
        while True:
            if not remaining:
                return cur, bytes(matched)
            fork = cur.forks.get(remaining[0])
            if fork is None:
                return cur, bytes(matched)
            common = common_prefix(fork.prefix, remaining)
            if len(common) == len(fork.prefix):
                matched.extend(fork.prefix)
                remaining = remaining[len(fork.prefix) :]
                cur = fork.node
                continue
            return cur, bytes(matched)

    def find(self, path: bytes) -> MantarayNode | None:
        """Return the node whose full path equals ``path``, or ``None``."""
        closest, matched = self.find_closest(path)
        return closest if len(matched) == len(path) else None

    # ---- collect helpers -------------------------------------------------

    def collect(self) -> list[tuple[bytes, MantarayNode]]:
        """All descendants whose ``target_address`` is non-null, with
        their full paths. The path is the concatenation of every fork
        prefix from the root down to the node.
        """
        out: list[tuple[bytes, MantarayNode]] = []
        self._collect_into(b"", out)
        return out

    def _collect_into(self, prefix: bytes, out: list[tuple[bytes, MantarayNode]]) -> None:
        for key in sorted(self.forks):
            fork = self.forks[key]
            full = prefix + fork.prefix
            if not fork.node.is_null_target():
                out.append((full, fork.node))
            fork.node._collect_into(full, out)

    def collect_and_map(self) -> dict[str, Reference]:
        """``{full_path: reference}`` for every leaf with a valid
        reference. Mirrors bee-go ``CollectAndMap``.
        """
        out: dict[str, Reference] = {}
        for path, node in self.collect():
            try:
                out[path.decode("utf-8", errors="replace")] = Reference(node.target_address)
            except Exception:
                continue
        return out

    # ---- mutation: add_fork ---------------------------------------------

    def add_fork(
        self,
        path: bytes,
        target: Reference | None = None,
        metadata: dict[str, str] | None = None,
    ) -> None:
        """Insert a ``(path, target, metadata)`` entry.

        Long paths are chunked into chained nodes of up to
        :data:`MAX_PREFIX_LENGTH` bytes each. Metadata is attached to
        the terminal node only.

        Invalidates ``self_address`` on every node touched along the
        way; call :func:`bee.manifest.wire.calculate_self_address`
        (or :func:`populate_self_addresses`) before marshaling.
        """
        self.self_address = None
        self._add_fork_inner(path, target, metadata)

    def _add_fork_inner(
        self,
        path: bytes,
        target: Reference | None,
        metadata: dict[str, str] | None,
    ) -> None:
        if not path:
            # Empty path: setting target/metadata on this node directly.
            if target is not None:
                self.target_address = _truncate_or_pad_to_target(target.as_bytes())
            if metadata is not None:
                self.metadata = dict(metadata)
            return

        chunk_len = min(len(path), MAX_PREFIX_LENGTH)
        chunk = path[:chunk_len]
        after = path[chunk_len:]
        is_last = not after
        key = chunk[0]

        existing = self.forks.get(key)
        if existing is not None:
            common = common_prefix(existing.prefix, chunk)
            if len(common) == len(existing.prefix):
                # Existing fork's prefix is a prefix of (or equals) chunk;
                # descend.
                next_path = chunk[len(common) :] + after
                existing.node.self_address = None
                existing.node._add_fork_inner(next_path, target, metadata)
                return
            # Split: common < existing.prefix.
            existing_fork = self.forks.pop(key)
            new_node = _make_subtree_node_for_chunk(chunk, is_last, target, metadata)
            new_fork = Fork(prefix=chunk, node=new_node)
            merged = _split_forks(new_fork, existing_fork)
            self.forks[key] = merged

            if not is_last:
                merged_ref = self.forks[key]
                if merged_ref.prefix == chunk:
                    # Case 1: chunk became parent of the existing fork.
                    merged_ref.node._add_fork_inner(after, target, metadata)
                else:
                    # Case 3: branching node became parent; chunk's node
                    # sits one level below, keyed by the next byte.
                    descend_byte = chunk[len(merged_ref.prefix)]
                    chunk_fork = merged_ref.node.forks[descend_byte]
                    chunk_fork.node._add_fork_inner(after, target, metadata)
            return

        # No existing fork at this key — insert a fresh one and recurse
        # if there's still more path left.
        new_node = _make_subtree_node_for_chunk(chunk, is_last, target, metadata)
        self.forks[key] = Fork(prefix=chunk, node=new_node)
        if not is_last:
            self.forks[key].node._add_fork_inner(after, target, metadata)

    # ---- mutation: remove_fork ------------------------------------------

    def remove_fork(self, path: bytes) -> None:
        """Delete the fork rooted at ``path``.

        If the removed node had children, they are re-inserted under
        the parent so the trie stays consistent.
        """
        if not path:
            raise BeeArgumentError("remove_fork: path cannot be empty")
        if self.find(path) is None:
            raise BeeArgumentError("remove_fork: not found")
        self.self_address = None

        # Walk down recording the chain of fork keys.
        chain: list[int] = []
        cur: MantarayNode = self
        remaining = path
        while remaining:
            key = remaining[0]
            fork = cur.forks.get(key)
            if fork is None:
                raise BeeArgumentError("remove_fork: chain broken")
            chain.append(key)
            remaining = remaining[len(fork.prefix) :]
            cur = fork.node

        last_key = chain[-1]
        # Climb back down to the parent of the target.
        parent: MantarayNode = self
        for key in chain[:-1]:
            parent = parent.forks[key].node
        removed = parent.forks.pop(last_key)
        parent.self_address = None

        # Re-insert each grandchild under self (root) using the
        # original full path of the removed node + each grandchild's prefix.
        for fork in removed.node.forks.values():
            _reinsert_subtree(self, path, fork.prefix, fork.node)


# ---- helpers used by add_fork / remove_fork ------------------------------


def _truncate_or_pad_to_target(b: bytes) -> bytes:
    n = min(len(b), REFERENCE_LENGTH)
    return b[:n] + b"\x00" * (REFERENCE_LENGTH - n)


def _make_subtree_node_for_chunk(
    chunk: bytes,
    is_last: bool,
    target: Reference | None,
    metadata: dict[str, str] | None,
) -> MantarayNode:
    n = MantarayNode(path=chunk)
    if is_last:
        if target is not None:
            n.target_address = _truncate_or_pad_to_target(target.as_bytes())
        if metadata is not None:
            n.metadata = dict(metadata)
    return n


def _reinsert_subtree(
    root: MantarayNode,
    path_prefix_under_root: bytes,
    subtree_prefix: bytes,
    subtree: MantarayNode,
) -> None:
    """Re-insert ``subtree`` into ``root`` under the path
    ``path_prefix_under_root || subtree_prefix``."""
    full_path = path_prefix_under_root + subtree_prefix

    if not subtree.is_null_target():
        try:
            target: Reference | None = Reference(subtree.target_address)
        except Exception:
            target = None
        root.add_fork(full_path, target, subtree.metadata)
    elif subtree.metadata is not None:
        root.add_fork(full_path, None, subtree.metadata)

    for fork in subtree.forks.values():
        _reinsert_subtree(root, full_path, fork.prefix, fork.node)


def _split_forks(a: Fork, b: Fork) -> Fork:
    """Resolve a prefix collision between two forks at the same first
    byte. Returns the fork the parent should store, reshuffling node
    paths as needed to keep the patricia invariant. Mirrors bee-js
    ``Fork.split``.
    """
    common = common_prefix(a.prefix, b.prefix)

    if len(common) == len(a.prefix):
        # b lives under a.
        remaining = b.prefix[len(common) :]
        b.node.path = remaining
        b.prefix = remaining
        a.node.forks[b.prefix[0]] = b
        return a
    if len(common) == len(b.prefix):
        # a lives under b.
        remaining = a.prefix[len(common) :]
        a.node.path = remaining
        a.prefix = remaining
        b.node.forks[a.prefix[0]] = a
        return b

    # Neither contains the other: insert a branching node.
    branch = MantarayNode(path=common)
    a_remaining = a.prefix[len(common) :]
    b_remaining = b.prefix[len(common) :]
    a.node.path = a_remaining
    b.node.path = b_remaining
    a.prefix = a_remaining
    b.prefix = b_remaining
    branch.forks[a.prefix[0]] = a
    branch.forks[b.prefix[0]] = b
    return Fork(prefix=common, node=branch)


__all__ = [
    "MAX_PREFIX_LENGTH",
    "NULL_ADDRESS",
    "PATH_SEPARATOR",
    "TYPE_EDGE",
    "TYPE_VALUE",
    "TYPE_WITH_METADATA",
    "TYPE_WITH_PATH_SEPARATOR",
    "Fork",
    "MantarayNode",
    "is_null_address",
]
