""":class:`ResourceLocator` — a ``Reference`` or ENS-name wrapper used
as the path segment of ``/bzz/{ref}`` and ``/bytes/{ref}``.

Mirrors bee-rs ``manifest::locator`` and bee-js ``ResourceLocator``.

Also defines :func:`resolve_path`, an offline manifest path-resolution
helper: given an unmarshaled :class:`MantarayNode` and a slash-delimited
path, return the chunk reference of the target leaf.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..swarm.errors import BeeArgumentError
from ..swarm.typed_bytes import Reference
from .node import MantarayNode, is_null_address


@dataclass(frozen=True, slots=True)
class ResourceLocator:
    """Either a content reference or an ENS name.

    Use :meth:`from_reference`, :meth:`from_ens`, or :meth:`parse` to
    construct. Either form is valid as the ``{ref}`` segment in Bee
    URLs; ENS resolution happens server-side.
    """

    #: A content reference (32 or 64 bytes), or ``None`` for an ENS name.
    reference: Reference | None
    #: An ENS name (e.g. ``"hello.eth"``), or ``None`` for a reference.
    ens: str | None

    @classmethod
    def parse(cls, input: str) -> ResourceLocator:
        """Build from any input. Strings containing ``.eth`` are
        treated as ENS names; otherwise the input is parsed as a hex
        reference. Mirrors bee-js ``new ResourceLocator(...)``.
        """
        if ".eth" in input:
            return cls(reference=None, ens=input)
        return cls(reference=Reference.from_hex(input), ens=None)

    @classmethod
    def from_reference(cls, r: Reference) -> ResourceLocator:
        """Build from an existing reference."""
        return cls(reference=r, ens=None)

    @classmethod
    def from_ens(cls, name: str) -> ResourceLocator:
        """Build from a string assumed to be an ENS name. Empty input
        raises :class:`BeeArgumentError`; deeper validation is left to
        Bee.
        """
        if not name:
            raise BeeArgumentError("empty ENS name")
        return cls(reference=None, ens=name)

    def is_reference(self) -> bool:
        """True iff this locator wraps a content reference."""
        return self.reference is not None

    def is_ens(self) -> bool:
        """True iff this locator wraps an ENS name."""
        return self.ens is not None

    def __str__(self) -> str:
        """Path-segment form: hex for a reference, raw label for ENS."""
        if self.reference is not None:
            return self.reference.to_hex()
        if self.ens is not None:
            return self.ens
        # Defensive — should be unreachable for properly-constructed values.
        raise BeeArgumentError("ResourceLocator has neither reference nor ens")


def resolve_path(manifest: MantarayNode, path: str) -> Reference:
    """Offline manifest path resolution.

    Walks ``manifest`` and returns the target :class:`Reference` for
    ``path`` (a slash-delimited UTF-8 string; a leading ``/`` is
    allowed and ignored). Mirrors Bee's server-side behavior for
    ``GET /bzz/{ref}/{path}``.

    Raises :class:`BeeArgumentError` when no fork matches the path or
    when the matched node has no target.
    """
    trimmed = path.lstrip("/")
    node = manifest.find(trimmed.encode("utf-8"))
    if node is None:
        raise BeeArgumentError(f"no manifest entry for path {path!r}")
    target = target_reference(node)
    if target is None:
        raise BeeArgumentError(f"manifest entry for {path!r} has no target")
    return target


def target_reference(node: MantarayNode) -> Reference | None:
    """The fork target of ``node`` as a :class:`Reference`, or
    ``None`` for branch-only nodes (NULL_ADDRESS).
    """
    if is_null_address(node.target_address):
        return None
    try:
        return Reference(node.target_address)
    except Exception:
        return None


__all__ = [
    "ResourceLocator",
    "resolve_path",
    "target_reference",
]
