"""Mantaray manifest trie.

Mirrors ``pkg/manifest`` in bee-go and ``manifest`` in bee-rs.

Construct an empty manifest with :class:`MantarayNode`; insert
``(path, target, metadata)`` entries with :meth:`MantarayNode.add_fork`;
serialize with :func:`bee.manifest.wire.marshal` (after
:func:`bee.manifest.wire.populate_self_addresses`); parse a chunk back
with :func:`bee.manifest.wire.unmarshal`.

0.4.x ships the trie + v0.2 wire format + ResourceLocator.
"""

from .locator import (
    ResourceLocator,
    resolve_path,
    target_reference,
)
from .node import (
    MAX_PREFIX_LENGTH,
    NULL_ADDRESS,
    PATH_SEPARATOR,
    TYPE_EDGE,
    TYPE_VALUE,
    TYPE_WITH_METADATA,
    TYPE_WITH_PATH_SEPARATOR,
    Fork,
    MantarayNode,
    is_null_address,
)
from .wire import (
    VERSION_02_HASH_HEX,
    calculate_self_address,
    marshal,
    populate_self_addresses,
    unmarshal,
)

__all__ = [
    "MAX_PREFIX_LENGTH",
    "NULL_ADDRESS",
    "PATH_SEPARATOR",
    "TYPE_EDGE",
    "TYPE_VALUE",
    "TYPE_WITH_METADATA",
    "TYPE_WITH_PATH_SEPARATOR",
    "VERSION_02_HASH_HEX",
    "Fork",
    "MantarayNode",
    "ResourceLocator",
    "calculate_self_address",
    "is_null_address",
    "marshal",
    "populate_self_addresses",
    "resolve_path",
    "target_reference",
    "unmarshal",
]
