"""PSS send / subscribe / receive.

Mirrors bee-rs ``pss`` and bee-go ``pkg/pss``. PSS messages are
delivered along the Swarm overlay and surfaced to subscribers through
``GET /pss/subscribe/{topic}`` (WebSocket).

Get a handle via :attr:`bee.AsyncBee.pss` (full surface) or
:attr:`bee.Bee.pss` (HTTP-only — subscribe is async).
"""

from __future__ import annotations

import asyncio

from .._inner import _AsyncInner, _SyncInner
from .._ws import AsyncSubscription
from ..swarm.errors import BeeArgumentError
from ..swarm.keys import PublicKey
from ..swarm.typed_bytes import BatchId, Topic


class AsyncPssApi:
    """Async PSS handle. Reachable as :attr:`bee.AsyncBee.pss`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _AsyncInner) -> None:
        self._inner = inner

    async def send(
        self,
        batch_id: BatchId,
        topic: Topic,
        target: str,
        data: bytes,
        recipient: PublicKey | None = None,
    ) -> None:
        """``POST /pss/send/{topic}/{target}`` — send a PSS message.

        - ``target`` is a routing prefix as hex (e.g. ``"1234"``), not
          a full overlay address.
        - ``recipient`` is optional; when supplied, the message is
          end-to-end encrypted with the recipient's public key. Bee
          accepts the SEC1-compressed encoding (33 bytes hex).
        """
        path = f"pss/send/{topic.to_hex()}/{target}"
        params: dict[str, str] | None = None
        if recipient is not None:
            params = {"recipient": recipient.compressed_hex()}
        await self._inner.send(
            "POST",
            path,
            content=data,
            headers=[("Swarm-Postage-Batch-Id", batch_id.to_hex())],
            params=params,
        )

    async def subscribe(self, topic: Topic) -> AsyncSubscription:
        """Open a WebSocket at ``/pss/subscribe/{topic}``."""
        return await AsyncSubscription.open(
            self._inner.base_url, f"pss/subscribe/{topic.to_hex()}"
        )

    async def receive(self, topic: Topic, timeout: float) -> bytes:
        """One-shot helper: subscribe, wait for the next message
        (with ``timeout`` seconds), close, return the bytes.
        """
        sub = await self.subscribe(topic)
        try:
            return await asyncio.wait_for(sub.recv(), timeout=timeout)
        except asyncio.TimeoutError as e:
            raise BeeArgumentError("pss receive timed out") from e
        finally:
            await sub.close()


class PssApi:
    """Sync PSS handle. Reachable as :attr:`bee.Bee.pss`.

    Subscribe / receive are async-only. Sync code can ``send``;
    long-lived listeners need :class:`bee.AsyncBee`.
    """

    __slots__ = ("_inner",)

    def __init__(self, inner: _SyncInner) -> None:
        self._inner = inner

    def send(
        self,
        batch_id: BatchId,
        topic: Topic,
        target: str,
        data: bytes,
        recipient: PublicKey | None = None,
    ) -> None:
        """``POST /pss/send/{topic}/{target}``."""
        path = f"pss/send/{topic.to_hex()}/{target}"
        params: dict[str, str] | None = None
        if recipient is not None:
            params = {"recipient": recipient.compressed_hex()}
        self._inner.send(
            "POST",
            path,
            content=data,
            headers=[("Swarm-Postage-Batch-Id", batch_id.to_hex())],
            params=params,
        )


__all__ = [
    "AsyncPssApi",
    "PssApi",
]
