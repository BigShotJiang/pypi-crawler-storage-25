"""Generic ``/api/*`` endpoint helpers: option structs, header
preparation, and rich return types.

Mirrors ``pkg/api`` in bee-go and ``api`` in bee-rs.
"""

from .endpoints import (
    ApiService,
    AsyncApiService,
    EnvelopeResponse,
    GranteeResponse,
    Tag,
)
from .options import (
    CollectionUploadOptions,
    DownloadOptions,
    FileUploadOptions,
    HeaderPairs,
    PostageBatchOptions,
    RedundancyLevel,
    RedundancyStrategy,
    RedundantUploadOptions,
    UploadOptions,
    prepare_collection_upload_headers,
    prepare_download_headers,
    prepare_file_upload_headers,
    prepare_redundant_upload_headers,
    prepare_upload_headers,
)
from .result import (
    FileHeaders,
    HeadersLike,
    ReferenceInformation,
    UploadResult,
    parse_content_disposition_filename,
)

__all__ = [
    "ApiService",
    "AsyncApiService",
    "CollectionUploadOptions",
    "DownloadOptions",
    "EnvelopeResponse",
    "FileHeaders",
    "FileUploadOptions",
    "GranteeResponse",
    "HeaderPairs",
    "HeadersLike",
    "PostageBatchOptions",
    "RedundancyLevel",
    "RedundancyStrategy",
    "RedundantUploadOptions",
    "ReferenceInformation",
    "Tag",
    "UploadOptions",
    "UploadResult",
    "parse_content_disposition_filename",
    "prepare_collection_upload_headers",
    "prepare_download_headers",
    "prepare_file_upload_headers",
    "prepare_redundant_upload_headers",
    "prepare_upload_headers",
]
