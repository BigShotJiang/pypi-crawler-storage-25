"""Generic ``/api/*`` endpoints: pin, tag, stewardship, grantee, envelope.

Mirrors bee-rs ``api::endpoints`` and bee-go ``pkg/api/{pin,tag,stewardship}.go``.
Reachable as :attr:`bee.AsyncBee.api` and :attr:`bee.Bee.api`.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from .._inner import _AsyncInner, _SyncInner
from ..swarm.errors import BeeJsonError, BeeResponseError
from ..swarm.typed_bytes import BatchId, Reference

_JSON_CONTENT_TYPE = "application/json"


@dataclass(frozen=True, slots=True)
class Tag:
    """A Swarm tag — tracks sync progress for an upload.

    Mirrors bee-go ``pkg/api.tagResponse``. All numeric fields default
    to ``0`` and string fields to ``""`` since Bee occasionally omits
    them on freshly-created tags.
    """

    uid: int = 0
    name: str = ""
    total: int = 0
    split: int = 0
    seen: int = 0
    stored: int = 0
    sent: int = 0
    synced: int = 0
    address: str = ""
    started_at: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Tag:
        return cls(
            uid=int(d.get("uid", 0)),
            name=str(d.get("name", "")),
            total=int(d.get("total", 0)),
            split=int(d.get("split", 0)),
            seen=int(d.get("seen", 0)),
            stored=int(d.get("stored", 0)),
            sent=int(d.get("sent", 0)),
            synced=int(d.get("synced", 0)),
            address=str(d.get("address", "")),
            started_at=str(d.get("startedAt", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Wire form (camelCase ``startedAt``)."""
        return {
            "uid": self.uid,
            "name": self.name,
            "total": self.total,
            "split": self.split,
            "seen": self.seen,
            "stored": self.stored,
            "sent": self.sent,
            "synced": self.synced,
            "address": self.address,
            "startedAt": self.started_at,
        }


@dataclass(frozen=True, slots=True)
class GranteeResponse:
    """Response from ``POST /grantee`` and ``PATCH /grantee/{ref}``.

    ``reference`` is the new grantee-set ref; ``history_reference`` is
    the ACT history root.
    """

    reference: str
    history_reference: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> GranteeResponse:
        ref = d.get("ref")
        hist = d.get("historyref")
        if not isinstance(ref, str) or not isinstance(hist, str):
            raise BeeJsonError(f"unexpected grantee response shape: {d!r}")
        return cls(reference=ref, history_reference=hist)


@dataclass(frozen=True, slots=True)
class EnvelopeResponse:
    """Response from ``POST /envelope/{ref}`` — the postage stamp
    quadruple Bee signed for the supplied reference.
    """

    issuer: str
    index: str
    timestamp: str
    signature: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> EnvelopeResponse:
        try:
            return cls(
                issuer=str(d["issuer"]),
                index=str(d["index"]),
                timestamp=str(d["timestamp"]),
                signature=str(d["signature"]),
            )
        except KeyError as e:
            raise BeeJsonError(f"missing key in envelope response: {e}") from e


def _parse_tag(payload: object) -> Tag:
    if not isinstance(payload, dict):
        raise BeeJsonError(f"unexpected tag response: {payload!r}")
    return Tag.from_dict(payload)


def _parse_pins_list(payload: object) -> list[Reference]:
    if not isinstance(payload, dict) or "references" not in payload:
        raise BeeJsonError(f"unexpected /pins response: {payload!r}")
    refs = payload["references"]
    if not isinstance(refs, list):
        raise BeeJsonError(f"'references' is not a list: {refs!r}")
    return [Reference.from_hex(r) for r in refs]


def _parse_tags_list(payload: object) -> list[Tag]:
    if not isinstance(payload, dict) or "tags" not in payload:
        raise BeeJsonError(f"unexpected /tags response: {payload!r}")
    tags = payload["tags"]
    if not isinstance(tags, list):
        raise BeeJsonError(f"'tags' is not a list: {tags!r}")
    return [Tag.from_dict(t) for t in tags]


def _parse_is_retrievable(payload: object) -> bool:
    """Accept either ``isRetrievable`` (camelCase) or
    ``is_retrievable`` (snake_case).
    """
    if not isinstance(payload, dict):
        raise BeeJsonError(f"unexpected stewardship response: {payload!r}")
    if "isRetrievable" in payload:
        return bool(payload["isRetrievable"])
    if "is_retrievable" in payload:
        return bool(payload["is_retrievable"])
    raise BeeJsonError(f"missing is_retrievable in stewardship response: {payload!r}")


def _grantee_patch_body(add: list[str], revoke: list[str]) -> bytes:
    body: dict[str, list[str]] = {}
    if add:
        body["add"] = add
    if revoke:
        body["revoke"] = revoke
    return json.dumps(body).encode("utf-8")


# ---- Async surface -------------------------------------------------------


class AsyncApiService:
    """Async ``/api/*`` handle. Reachable as :attr:`bee.AsyncBee.api`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _AsyncInner) -> None:
        self._inner = inner

    # ---- pins ------------------------------------------------------------

    async def pin(self, reference: Reference) -> None:
        """``POST /pins/{ref}``."""
        await self._inner.send("POST", f"pins/{reference.to_hex()}")

    async def unpin(self, reference: Reference) -> None:
        """``DELETE /pins/{ref}``."""
        await self._inner.send("DELETE", f"pins/{reference.to_hex()}")

    async def get_pin(self, reference: Reference) -> bool:
        """``GET /pins/{ref}`` — ``True`` on 200, ``False`` on 404."""
        try:
            await self._inner.send("GET", f"pins/{reference.to_hex()}")
        except BeeResponseError as e:
            if e.status == 404:
                return False
            raise
        return True

    async def list_pins(self) -> list[Reference]:
        """``GET /pins`` — every pinned reference."""
        return _parse_pins_list(await self._inner.send_json("GET", "pins"))

    # ---- tags ------------------------------------------------------------

    async def create_tag(self) -> Tag:
        """``POST /tags`` — fresh tag UID."""
        return _parse_tag(await self._inner.send_json("POST", "tags"))

    async def get_tag(self, uid: int) -> Tag:
        """``GET /tags/{uid}``."""
        return _parse_tag(await self._inner.send_json("GET", f"tags/{uid}"))

    async def list_tags(
        self, offset: int | None = None, limit: int | None = None
    ) -> list[Tag]:
        """``GET /tags`` with optional ``offset`` / ``limit``."""
        params: dict[str, str] = {}
        if offset is not None and offset > 0:
            params["offset"] = str(offset)
        if limit is not None and limit > 0:
            params["limit"] = str(limit)
        return _parse_tags_list(
            await self._inner.send_json("GET", "tags", params=params or None)
        )

    async def delete_tag(self, uid: int) -> None:
        """``DELETE /tags/{uid}``."""
        await self._inner.send("DELETE", f"tags/{uid}")

    async def update_tag(self, uid: int, tag: Tag) -> None:
        """``PATCH /tags/{uid}``."""
        body = json.dumps(tag.to_dict()).encode("utf-8")
        await self._inner.send(
            "PATCH",
            f"tags/{uid}",
            content=body,
            headers=[("Content-Type", _JSON_CONTENT_TYPE)],
        )

    # ---- stewardship -----------------------------------------------------

    async def reupload(self, reference: Reference, batch_id: BatchId) -> None:
        """``PUT /stewardship/{ref}`` — re-upload locally pinned data."""
        await self._inner.send(
            "PUT",
            f"stewardship/{reference.to_hex()}",
            headers=[("Swarm-Postage-Batch-Id", batch_id.to_hex())],
        )

    async def is_retrievable(self, reference: Reference) -> bool:
        """``GET /stewardship/{ref}`` — accepts ``isRetrievable`` or
        ``is_retrievable``.
        """
        return _parse_is_retrievable(
            await self._inner.send_json("GET", f"stewardship/{reference.to_hex()}")
        )

    # ---- grantees --------------------------------------------------------

    async def get_grantees(self, reference: Reference) -> list[str]:
        """``GET /grantee/{ref}`` — bare JSON array of pubkeys (hex)."""
        payload = await self._inner.send_json("GET", f"grantee/{reference.to_hex()}")
        if not isinstance(payload, list):
            raise BeeJsonError(f"unexpected grantee list response: {payload!r}")
        return [str(p) for p in payload]

    async def create_grantees(
        self, batch_id: BatchId, grantees: list[str]
    ) -> GranteeResponse:
        """``POST /grantee`` — register a fresh grantee list."""
        body = json.dumps({"grantees": grantees}).encode("utf-8")
        decoded = await self._inner.send_json(
            "POST",
            "grantee",
            content=body,
            headers=[
                ("Content-Type", _JSON_CONTENT_TYPE),
                ("Swarm-Postage-Batch-Id", batch_id.to_hex()),
            ],
        )
        if not isinstance(decoded, dict):
            raise BeeJsonError(f"unexpected grantee response: {decoded!r}")
        return GranteeResponse.from_dict(decoded)

    async def patch_grantees(
        self,
        batch_id: BatchId,
        reference: Reference,
        history_address: Reference,
        add: list[str] | None = None,
        revoke: list[str] | None = None,
    ) -> GranteeResponse:
        """``PATCH /grantee/{ref}`` — add / revoke pubkeys."""
        body = _grantee_patch_body(add or [], revoke or [])
        decoded = await self._inner.send_json(
            "PATCH",
            f"grantee/{reference.to_hex()}",
            content=body,
            headers=[
                ("Content-Type", _JSON_CONTENT_TYPE),
                ("Swarm-Postage-Batch-Id", batch_id.to_hex()),
                ("Swarm-Act-History-Address", history_address.to_hex()),
            ],
        )
        if not isinstance(decoded, dict):
            raise BeeJsonError(f"unexpected grantee response: {decoded!r}")
        return GranteeResponse.from_dict(decoded)

    # ---- envelope --------------------------------------------------------

    async def post_envelope(
        self, batch_id: BatchId, reference: Reference
    ) -> EnvelopeResponse:
        """``POST /envelope/{ref}`` — issuer / index / timestamp / signature."""
        decoded = await self._inner.send_json(
            "POST",
            f"envelope/{reference.to_hex()}",
            headers=[("Swarm-Postage-Batch-Id", batch_id.to_hex())],
        )
        if not isinstance(decoded, dict):
            raise BeeJsonError(f"unexpected envelope response: {decoded!r}")
        return EnvelopeResponse.from_dict(decoded)


# ---- Sync surface --------------------------------------------------------


class ApiService:
    """Sync ``/api/*`` handle. Reachable as :attr:`bee.Bee.api`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _SyncInner) -> None:
        self._inner = inner

    # pins ---------------------------------------------------------------

    def pin(self, reference: Reference) -> None:
        self._inner.send("POST", f"pins/{reference.to_hex()}")

    def unpin(self, reference: Reference) -> None:
        self._inner.send("DELETE", f"pins/{reference.to_hex()}")

    def get_pin(self, reference: Reference) -> bool:
        try:
            self._inner.send("GET", f"pins/{reference.to_hex()}")
        except BeeResponseError as e:
            if e.status == 404:
                return False
            raise
        return True

    def list_pins(self) -> list[Reference]:
        return _parse_pins_list(self._inner.send_json("GET", "pins"))

    # tags ---------------------------------------------------------------

    def create_tag(self) -> Tag:
        return _parse_tag(self._inner.send_json("POST", "tags"))

    def get_tag(self, uid: int) -> Tag:
        return _parse_tag(self._inner.send_json("GET", f"tags/{uid}"))

    def list_tags(
        self, offset: int | None = None, limit: int | None = None
    ) -> list[Tag]:
        params: dict[str, str] = {}
        if offset is not None and offset > 0:
            params["offset"] = str(offset)
        if limit is not None and limit > 0:
            params["limit"] = str(limit)
        return _parse_tags_list(
            self._inner.send_json("GET", "tags", params=params or None)
        )

    def delete_tag(self, uid: int) -> None:
        self._inner.send("DELETE", f"tags/{uid}")

    def update_tag(self, uid: int, tag: Tag) -> None:
        body = json.dumps(tag.to_dict()).encode("utf-8")
        self._inner.send(
            "PATCH",
            f"tags/{uid}",
            content=body,
            headers=[("Content-Type", _JSON_CONTENT_TYPE)],
        )

    # stewardship --------------------------------------------------------

    def reupload(self, reference: Reference, batch_id: BatchId) -> None:
        self._inner.send(
            "PUT",
            f"stewardship/{reference.to_hex()}",
            headers=[("Swarm-Postage-Batch-Id", batch_id.to_hex())],
        )

    def is_retrievable(self, reference: Reference) -> bool:
        return _parse_is_retrievable(
            self._inner.send_json("GET", f"stewardship/{reference.to_hex()}")
        )

    # grantees -----------------------------------------------------------

    def get_grantees(self, reference: Reference) -> list[str]:
        payload = self._inner.send_json("GET", f"grantee/{reference.to_hex()}")
        if not isinstance(payload, list):
            raise BeeJsonError(f"unexpected grantee list response: {payload!r}")
        return [str(p) for p in payload]

    def create_grantees(self, batch_id: BatchId, grantees: list[str]) -> GranteeResponse:
        body = json.dumps({"grantees": grantees}).encode("utf-8")
        decoded = self._inner.send_json(
            "POST",
            "grantee",
            content=body,
            headers=[
                ("Content-Type", _JSON_CONTENT_TYPE),
                ("Swarm-Postage-Batch-Id", batch_id.to_hex()),
            ],
        )
        if not isinstance(decoded, dict):
            raise BeeJsonError(f"unexpected grantee response: {decoded!r}")
        return GranteeResponse.from_dict(decoded)

    def patch_grantees(
        self,
        batch_id: BatchId,
        reference: Reference,
        history_address: Reference,
        add: list[str] | None = None,
        revoke: list[str] | None = None,
    ) -> GranteeResponse:
        body = _grantee_patch_body(add or [], revoke or [])
        decoded = self._inner.send_json(
            "PATCH",
            f"grantee/{reference.to_hex()}",
            content=body,
            headers=[
                ("Content-Type", _JSON_CONTENT_TYPE),
                ("Swarm-Postage-Batch-Id", batch_id.to_hex()),
                ("Swarm-Act-History-Address", history_address.to_hex()),
            ],
        )
        if not isinstance(decoded, dict):
            raise BeeJsonError(f"unexpected grantee response: {decoded!r}")
        return GranteeResponse.from_dict(decoded)

    # envelope -----------------------------------------------------------

    def post_envelope(self, batch_id: BatchId, reference: Reference) -> EnvelopeResponse:
        decoded = self._inner.send_json(
            "POST",
            f"envelope/{reference.to_hex()}",
            headers=[("Swarm-Postage-Batch-Id", batch_id.to_hex())],
        )
        if not isinstance(decoded, dict):
            raise BeeJsonError(f"unexpected envelope response: {decoded!r}")
        return EnvelopeResponse.from_dict(decoded)


__all__ = [
    "ApiService",
    "AsyncApiService",
    "EnvelopeResponse",
    "GranteeResponse",
    "Tag",
]
