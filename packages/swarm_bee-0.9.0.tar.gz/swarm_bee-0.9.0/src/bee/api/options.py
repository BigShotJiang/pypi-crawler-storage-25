"""Upload / download options and header preparation.

Mirrors bee-go ``pkg/api/options.go`` and bee-rs ``api::options``.
Boolean fields use ``bool | None`` to distinguish "unset" from
"explicitly false" — matching bee-go's ``*bool`` semantics. ``None``
omits the header; ``False`` sends the literal string ``"false"``.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum

from ..swarm.typed_bytes import BatchId, Reference

#: Header pairs as a list of ``(name, value)`` tuples. Order is
#: preserved so callers can reproduce bee-rs's header layout in tests.
HeaderPairs = list[tuple[str, str]]


class RedundancyLevel(IntEnum):
    """Data redundancy applied at upload time. Mirrors bee-js
    ``RedundancyLevel``."""

    OFF = 0
    MEDIUM = 1
    STRONG = 2
    INSANE = 3
    PARANOID = 4


class RedundancyStrategy(IntEnum):
    """Chunk-prefetch policy for downloading erasure-coded data.
    Mirrors bee-js ``RedundancyStrategy``."""

    NONE = 0
    DATA = 1
    PROXIMITY = 2
    RACE = 3


@dataclass(slots=True)
class UploadOptions:
    """Base set of options accepted by every upload endpoint.

    Mirrors bee-js / bee-go ``UploadOptions``.
    """

    #: Wrap the upload in an Access Control Trie (ACT). Returned history
    #: root is exposed via ``UploadResult.history_address``.
    act: bool | None = None
    #: Existing ACT history root for re-upload under the same access
    #: policy.
    act_history_address: Reference | None = None
    #: Pin the uploaded data on the local Bee node.
    pin: bool | None = None
    #: Encrypt chunks; the returned reference is 64 bytes
    #: (CAC || encryption key).
    encrypt: bool | None = None
    #: Existing tag UID to attach for sync tracking. ``0`` omits the
    #: header (matching bee-go's ``uint32(0)`` zero-value semantics).
    tag: int = 0
    #: ``False`` means "Bee waits for full sync", ``True`` (Bee default)
    #: means "Bee accepts and syncs in background".
    deferred: bool | None = None


@dataclass(slots=True)
class RedundantUploadOptions(UploadOptions):
    """:class:`UploadOptions` plus a redundancy level. Mirrors bee-go
    ``RedundantUploadOptions``."""

    redundancy_level: RedundancyLevel | None = None


@dataclass(slots=True)
class FileUploadOptions(UploadOptions):
    """File-specific upload options for ``POST /bzz``. Mirrors bee-go
    ``FileUploadOptions``."""

    #: Explicit ``Content-Length`` (use when uploading from a stream of
    #: unknown length).
    size: int | None = None
    #: Explicit ``Content-Type``.
    content_type: str | None = None
    #: Redundancy level (``OFF`` omits the header).
    redundancy_level: RedundancyLevel | None = None


@dataclass(slots=True)
class CollectionUploadOptions(UploadOptions):
    """Collection upload options for tar ``POST /bzz``. Mirrors bee-go
    ``CollectionUploadOptions``."""

    index_document: str | None = None
    error_document: str | None = None
    redundancy_level: RedundancyLevel | None = None


@dataclass(slots=True)
class DownloadOptions:
    """Download options. All fields are optional; the default keeps Bee
    defaults. Mirrors bee-go ``DownloadOptions``.

    Setting any of ``act_history_address`` or ``act_timestamp``
    implicitly turns the ``Swarm-Act`` header on.

    .. note::
       ``act_publisher`` (a public key) is not yet exposed — it lands
       once :mod:`bee.swarm.keys` is ported.
    """

    redundancy_strategy: RedundancyStrategy | None = None
    #: Allow strategy fallback. Bee default is ``True``.
    fallback: bool | None = None
    #: Per-chunk retrieval timeout in milliseconds.
    timeout_ms: int | None = None
    #: ACT history root for permission resolution.
    act_history_address: Reference | None = None
    #: Unix timestamp at which to evaluate ACT permissions.
    act_timestamp: int | None = None


@dataclass(slots=True)
class PostageBatchOptions:
    """Postage stamp creation options. Mirrors bee-js / bee-go
    ``PostageBatchOptions``."""

    label: str | None = None
    immutable: bool | None = None
    gas_price: str | None = None
    gas_limit: str | None = None


# ---- header preparation ---------------------------------------------------


def _bool_str(b: bool) -> str:
    return "true" if b else "false"


def _push_upload_options(out: HeaderPairs, opts: UploadOptions) -> None:
    if opts.pin is not None:
        out.append(("Swarm-Pin", _bool_str(opts.pin)))
    if opts.encrypt is not None:
        out.append(("Swarm-Encrypt", _bool_str(opts.encrypt)))
    if opts.tag > 0:
        out.append(("Swarm-Tag", str(opts.tag)))
    if opts.deferred is not None:
        out.append(("Swarm-Deferred-Upload", _bool_str(opts.deferred)))
    if opts.act is not None:
        out.append(("Swarm-Act", _bool_str(opts.act)))
    if opts.act_history_address is not None:
        out.append(("Swarm-Act-History-Address", opts.act_history_address.to_hex()))


def prepare_upload_headers(batch_id: BatchId, opts: UploadOptions | None = None) -> HeaderPairs:
    """Build the header set for a base upload. The batch is required."""
    out: HeaderPairs = [("Swarm-Postage-Batch-Id", batch_id.to_hex())]
    if opts is not None:
        _push_upload_options(out, opts)
    return out


def prepare_redundant_upload_headers(
    batch_id: BatchId, opts: RedundantUploadOptions | None = None
) -> HeaderPairs:
    """Build the header set for a redundant upload."""
    if opts is None:
        return prepare_upload_headers(batch_id)
    out = prepare_upload_headers(batch_id, opts)
    if opts.redundancy_level is not None and opts.redundancy_level != RedundancyLevel.OFF:
        out.append(("Swarm-Redundancy-Level", str(opts.redundancy_level.value)))
    return out


def prepare_file_upload_headers(
    batch_id: BatchId, opts: FileUploadOptions | None = None
) -> HeaderPairs:
    """Build the header set for a ``POST /bzz`` file upload."""
    if opts is None:
        return prepare_upload_headers(batch_id)
    out = prepare_upload_headers(batch_id, opts)
    if opts.size is not None:
        out.append(("Content-Length", str(opts.size)))
    if opts.content_type is not None:
        out.append(("Content-Type", opts.content_type))
    if opts.redundancy_level is not None and opts.redundancy_level != RedundancyLevel.OFF:
        out.append(("Swarm-Redundancy-Level", str(opts.redundancy_level.value)))
    return out


def prepare_collection_upload_headers(
    batch_id: BatchId, opts: CollectionUploadOptions | None = None
) -> HeaderPairs:
    """Build the header set for a tar ``POST /bzz`` collection upload."""
    if opts is None:
        return prepare_upload_headers(batch_id)
    out = prepare_upload_headers(batch_id, opts)
    if opts.index_document is not None:
        out.append(("Swarm-Index-Document", opts.index_document))
    if opts.error_document is not None:
        out.append(("Swarm-Error-Document", opts.error_document))
    if opts.redundancy_level is not None and opts.redundancy_level != RedundancyLevel.OFF:
        out.append(("Swarm-Redundancy-Level", str(opts.redundancy_level.value)))
    return out


def prepare_download_headers(opts: DownloadOptions | None = None) -> HeaderPairs:
    """Build the header set for a download. Setting any of the ACT
    fields implicitly turns ``Swarm-Act`` on."""
    out: HeaderPairs = []
    if opts is None:
        return out
    if opts.redundancy_strategy is not None:
        out.append(("Swarm-Redundancy-Strategy", str(opts.redundancy_strategy.value)))
    if opts.fallback is not None:
        out.append(("Swarm-Redundancy-Fallback-Mode", _bool_str(opts.fallback)))
    if opts.timeout_ms is not None and opts.timeout_ms > 0:
        out.append(("Swarm-Chunk-Retrieval-Timeout", str(opts.timeout_ms)))
    act = False
    if opts.act_history_address is not None:
        out.append(("Swarm-Act-History-Address", opts.act_history_address.to_hex()))
        act = True
    if opts.act_timestamp is not None and opts.act_timestamp > 0:
        out.append(("Swarm-Act-Timestamp", str(opts.act_timestamp)))
        act = True
    if act:
        out.append(("Swarm-Act", "true"))
    return out


__all__ = [
    "CollectionUploadOptions",
    "DownloadOptions",
    "FileUploadOptions",
    "HeaderPairs",
    "PostageBatchOptions",
    "RedundancyLevel",
    "RedundancyStrategy",
    "RedundantUploadOptions",
    "UploadOptions",
    "prepare_collection_upload_headers",
    "prepare_download_headers",
    "prepare_file_upload_headers",
    "prepare_redundant_upload_headers",
    "prepare_upload_headers",
]
