"""Rich return types for upload + download.

Mirrors bee-go ``pkg/api/result.go`` and bee-rs ``api::result``.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from ..swarm.errors import BeeJsonError
from ..swarm.typed_bytes import Reference

#: A response-headers mapping. Both :class:`httpx.Headers` and a plain
#: ``dict[str, str]`` satisfy this protocol.
HeadersLike = Mapping[str, str]


def _header(headers: HeadersLike, name: str) -> str | None:
    """Case-insensitive header lookup. ``httpx.Headers`` is already
    case-insensitive; for a plain dict we fall back to a manual scan.
    """
    if hasattr(headers, "get"):
        # httpx.Headers, dict, both have .get; httpx is case-insensitive.
        v = headers.get(name)
        if v is not None:
            return v
        v = headers.get(name.lower())
        if v is not None:
            return v
        v = headers.get(name.title())
        if v is not None:
            return v
    target = name.lower()
    for k, v in headers.items():
        if k.lower() == target:
            return v
    return None


@dataclass(frozen=True, slots=True)
class UploadResult:
    """Standardized return shape for every upload endpoint.

    Mirrors bee-js / bee-go ``UploadResult``.
    """

    #: Reference returned by Bee in the JSON body.
    reference: Reference
    #: Tag UID parsed from the ``Swarm-Tag`` response header. ``None``
    #: when Bee did not return one.
    tag_uid: int | None = None
    #: ACT history root parsed from ``Swarm-Act-History-Address``.
    history_address: Reference | None = None

    @classmethod
    def from_response(cls, ref_hex: str, headers: HeadersLike) -> UploadResult:
        """Parse from the JSON-decoded reference hex plus the response
        headers. Mirrors bee-go ``ReadUploadResult``.
        """
        try:
            reference = Reference.from_hex(ref_hex)
        except Exception as e:
            raise BeeJsonError(f"invalid reference in upload response: {e}") from e

        tag_uid: int | None = None
        tag_str = _header(headers, "swarm-tag")
        if tag_str is not None:
            try:
                tag_uid = int(tag_str)
            except ValueError:
                tag_uid = None

        history_address: Reference | None = None
        hist_str = _header(headers, "swarm-act-history-address")
        if hist_str is not None:
            try:
                history_address = Reference.from_hex(hist_str)
            except Exception:
                history_address = None

        return cls(
            reference=reference,
            tag_uid=tag_uid,
            history_address=history_address,
        )


@dataclass(frozen=True, slots=True)
class FileHeaders:
    """Parsed file-download response headers. Mirrors bee-go
    ``FileHeaders``."""

    name: str | None = None
    tag_uid: int | None = None
    content_type: str | None = None

    @classmethod
    def from_response(cls, headers: HeadersLike) -> FileHeaders:
        """Extract the file metadata Bee places on download responses.
        Missing or malformed headers fall through silently.
        """
        ct = _header(headers, "content-type")
        cd = _header(headers, "content-disposition")
        tag_str = _header(headers, "swarm-tag-uid")

        tag_uid: int | None = None
        if tag_str is not None:
            try:
                tag_uid = int(tag_str)
            except ValueError:
                tag_uid = None

        return cls(
            name=parse_content_disposition_filename(cd) if cd is not None else None,
            content_type=ct,
            tag_uid=tag_uid,
        )


@dataclass(frozen=True, slots=True)
class ReferenceInformation:
    """Result of a ``HEAD /bytes/{ref}`` probe: the size of the data
    behind a reference. Mirrors bee-rs ``ReferenceInformation``."""

    content_length: int


def parse_content_disposition_filename(header: str) -> str | None:
    """Extract the filename from a ``Content-Disposition`` header.

    Handles both ``filename="…"`` and ``filename*=UTF-8''…`` forms;
    returns ``None`` if neither is present. Mirrors bee-js's permissive
    parser.
    """
    for raw_part in header.split(";"):
        part = raw_part.strip()
        lower = part.lower()
        if not (lower.startswith("filename=") or lower.startswith("filename*=")):
            continue
        eq = part.find("=")
        if eq < 0:
            return None
        value = part[eq + 1 :]
        # filename*=UTF-8''actual-name
        idx = value.find("''")
        if idx >= 0:
            value = value[idx + 2 :]
        if len(value) >= 2 and value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        return value
    return None


__all__ = [
    "FileHeaders",
    "HeadersLike",
    "ReferenceInformation",
    "UploadResult",
    "parse_content_disposition_filename",
]
