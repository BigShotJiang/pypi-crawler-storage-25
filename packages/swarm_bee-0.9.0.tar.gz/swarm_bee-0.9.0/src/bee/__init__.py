"""bee-py — Python client for the Swarm Bee API.

Functional parity target with `bee-js`_ (canonical TypeScript client),
`bee-go`_ (typed Go port), and `bee-rs`_ (Rust port). bee-go is the
primary reference for shape and behavior; bee-js is the source of
truth for wire-format edge cases.

Quick start (async):

.. code:: python

    import asyncio
    from bee import AsyncBee

    async def main() -> None:
        async with AsyncBee("http://localhost:1633") as client:
            health = await client.debug.health()
            print(f"bee {health.version} api {health.api_version}")

    asyncio.run(main())

Quick start (sync):

.. code:: python

    from bee import Bee

    with Bee("http://localhost:1633") as client:
        print(client.debug.health())

.. _bee-js: https://github.com/ethersphere/bee-js
.. _bee-go: https://github.com/ethswarm-tools/bee-go
.. _bee-rs: https://github.com/ethswarm-tools/bee-rs
"""

from __future__ import annotations

from types import TracebackType

import httpx
from typing_extensions import Self

from ._inner import _AsyncInner, _SyncInner
from .api import (
    ApiService,
    AsyncApiService,
    CollectionUploadOptions,
    DownloadOptions,
    EnvelopeResponse,
    FileHeaders,
    FileUploadOptions,
    GranteeResponse,
    PostageBatchOptions,
    RedundancyLevel,
    RedundancyStrategy,
    RedundantUploadOptions,
    ReferenceInformation,
    Tag,
    UploadOptions,
    UploadResult,
)
from .debug import AsyncDebugApi, DebugApi
from .feeds import AsyncFeedApi, FeedApi
from .file import AsyncFileApi, CollectionEntry, FileApi
from .gsoc import AsyncGsocApi, GsocApi
from .postage import (
    AsyncPostageApi,
    BatchBucket,
    GlobalPostageBatch,
    PostageApi,
    PostageBatch,
    PostageBatchBuckets,
)
from .pss import AsyncPssApi, PssApi
from .swarm.errors import (
    BeeArgumentError,
    BeeCryptoError,
    BeeError,
    BeeHexError,
    BeeJsonError,
    BeeLengthMismatchError,
    BeeResponseError,
    BeeTransportError,
)

__version__ = "0.9.0"


class AsyncBee:
    """Async-first Bee client.

    Construct with a base URL pointing at a Bee HTTP API
    (typically ``http://localhost:1633``). Pass a pre-built
    :class:`httpx.AsyncClient` via ``http=`` for custom timeouts,
    auth headers, or proxy settings.

    The client is an async context manager — ``async with AsyncBee(...)
    as client`` will close the underlying HTTP client on exit.
    """

    __slots__ = ("_inner", "api", "debug", "feeds", "file", "gsoc", "postage", "pss")

    def __init__(
        self,
        url: str = "http://localhost:1633",
        *,
        http: httpx.AsyncClient | None = None,
    ) -> None:
        self._inner = _AsyncInner(url, http)
        #: Generic ``/api/*`` endpoints — pin, tag, stewardship, grantee, envelope.
        self.api = AsyncApiService(self._inner)
        #: Debug / operator endpoints (``GET /health``, ``/versions``, …).
        self.debug = AsyncDebugApi(self._inner)
        #: File / bytes endpoints (``POST /bytes``, ``GET /bytes/{ref}``, …).
        self.file = AsyncFileApi(self._inner)
        #: Feed read / write helpers (``/feeds/{owner}/{topic}``).
        self.feeds = AsyncFeedApi(self._inner)
        #: GSOC send / subscribe (``POST /soc/...`` + ``GET /gsoc/subscribe/{addr}`` WS).
        self.gsoc = AsyncGsocApi(self._inner)
        #: Postage-batch CRUD (``GET /stamps``, ``POST /stamps/{amount}/{depth}``, …).
        self.postage = AsyncPostageApi(self._inner)
        #: PSS send / subscribe / receive (``/pss/send/...`` + ``/pss/subscribe/{topic}`` WS).
        self.pss = AsyncPssApi(self._inner)

    @property
    def base_url(self) -> str:
        """Normalized base URL of the configured Bee node."""
        return self._inner.base_url

    async def aclose(self) -> None:
        """Close the underlying HTTP client if owned by this instance."""
        await self._inner.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()


class Bee:
    """Sync Bee client.

    Mirrors :class:`AsyncBee` but drives :class:`httpx.Client` instead
    of :class:`httpx.AsyncClient`. Use this from synchronous code (Jupyter,
    Django views before async support, scripts).
    """

    __slots__ = ("_inner", "api", "debug", "feeds", "file", "gsoc", "postage", "pss")

    def __init__(
        self,
        url: str = "http://localhost:1633",
        *,
        http: httpx.Client | None = None,
    ) -> None:
        self._inner = _SyncInner(url, http)
        #: Generic ``/api/*`` endpoints — pin, tag, stewardship, grantee, envelope.
        self.api = ApiService(self._inner)
        #: Debug / operator endpoints (``GET /health``, ``/versions``, …).
        self.debug = DebugApi(self._inner)
        #: File / bytes endpoints (``POST /bytes``, ``GET /bytes/{ref}``, …).
        self.file = FileApi(self._inner)
        #: Feed read / write helpers (``/feeds/{owner}/{topic}``).
        self.feeds = FeedApi(self._inner)
        #: GSOC send (``POST /soc/...``). Subscribe is async-only.
        self.gsoc = GsocApi(self._inner)
        #: Postage-batch CRUD (``GET /stamps``, ``POST /stamps/{amount}/{depth}``, …).
        self.postage = PostageApi(self._inner)
        #: PSS send (``POST /pss/send/...``). Subscribe / receive are async-only.
        self.pss = PssApi(self._inner)

    @property
    def base_url(self) -> str:
        """Normalized base URL of the configured Bee node."""
        return self._inner.base_url

    def close(self) -> None:
        """Close the underlying HTTP client if owned by this instance."""
        self._inner.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()


__all__ = [
    "AsyncBee",
    "BatchBucket",
    "Bee",
    "BeeArgumentError",
    "BeeCryptoError",
    "BeeError",
    "BeeHexError",
    "BeeJsonError",
    "BeeLengthMismatchError",
    "BeeResponseError",
    "BeeTransportError",
    "CollectionEntry",
    "CollectionUploadOptions",
    "DownloadOptions",
    "EnvelopeResponse",
    "FileHeaders",
    "FileUploadOptions",
    "GlobalPostageBatch",
    "GranteeResponse",
    "PostageBatch",
    "PostageBatchBuckets",
    "PostageBatchOptions",
    "RedundancyLevel",
    "RedundancyStrategy",
    "RedundantUploadOptions",
    "ReferenceInformation",
    "Tag",
    "UploadOptions",
    "UploadResult",
    "__version__",
]
