"""Shared HTTP plumbing for :class:`bee.Bee` and :class:`bee.AsyncBee`.

Mirrors bee-rs's ``client::Inner``. Two parallel implementations
(:class:`_AsyncInner` driving :class:`httpx.AsyncClient`, and
:class:`_SyncInner` driving :class:`httpx.Client`) share URL building
and error-mapping helpers. Both translate non-2xx responses into
:class:`bee.swarm.BeeResponseError` and capture the first
``RESPONSE_BODY_CAP`` bytes of the body.
"""

from __future__ import annotations

import json
from typing import Any

import httpx

from .swarm.errors import (
    RESPONSE_BODY_CAP,
    BeeArgumentError,
    BeeJsonError,
    BeeResponseError,
    BeeTransportError,
)


def _normalize_base_url(url: str) -> str:
    """Trim trailing slashes; we re-add exactly one when joining paths."""
    if not url:
        raise BeeArgumentError("base url must be non-empty")
    return url.rstrip("/")


def _build_url(base_url: str, path: str) -> str:
    """Join ``path`` against ``base_url``. ``path`` is treated as relative."""
    if path.startswith("/"):
        return f"{base_url}{path}"
    return f"{base_url}/{path}"


def _raise_response_error(response: httpx.Response) -> None:
    """Raise :class:`BeeResponseError` from a non-2xx response."""
    body = response.content[:RESPONSE_BODY_CAP] if response.content else b""
    status_text = f"{response.status_code} {response.reason_phrase}".strip()
    raise BeeResponseError(
        method=response.request.method,
        url=str(response.request.url),
        status=response.status_code,
        status_text=status_text,
        body=body,
    )


def _decode_json(content: bytes) -> Any:
    """Decode a JSON body, raising :class:`BeeJsonError` on failure."""
    try:
        return json.loads(content)
    except json.JSONDecodeError as e:
        raise BeeJsonError(f"invalid JSON response: {e}") from e


class _AsyncInner:
    """Async HTTP plumbing shared by :class:`bee.AsyncBee` sub-APIs."""

    __slots__ = ("_http", "_owns_http", "base_url")

    def __init__(self, base_url: str, http: httpx.AsyncClient | None) -> None:
        self.base_url: str = _normalize_base_url(base_url)
        if http is None:
            # follow_redirects=True matches reqwest's default. Bee
            # returns 308 on /bzz/{ref} → /bzz/{ref}/ for collection
            # roots; without this, downloads of those refs would fail.
            self._http: httpx.AsyncClient = httpx.AsyncClient(follow_redirects=True)
            self._owns_http: bool = True
        else:
            self._http = http
            self._owns_http = False

    async def aclose(self) -> None:
        """Close the underlying HTTP client if we own it."""
        if self._owns_http:
            await self._http.aclose()

    def url(self, path: str) -> str:
        return _build_url(self.base_url, path)

    async def send(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Send a request and raise on transport / non-2xx response."""
        try:
            response = await self._http.request(method, self.url(path), **kwargs)
        except httpx.HTTPError as e:
            raise BeeTransportError(str(e)) from e
        if not response.is_success:
            _raise_response_error(response)
        return response

    async def send_json(self, method: str, path: str, **kwargs: Any) -> Any:
        response = await self.send(method, path, **kwargs)
        return _decode_json(response.content)


class _SyncInner:
    """Sync HTTP plumbing shared by :class:`bee.Bee` sub-APIs."""

    __slots__ = ("_http", "_owns_http", "base_url")

    def __init__(self, base_url: str, http: httpx.Client | None) -> None:
        self.base_url: str = _normalize_base_url(base_url)
        if http is None:
            self._http: httpx.Client = httpx.Client(follow_redirects=True)
            self._owns_http: bool = True
        else:
            self._http = http
            self._owns_http = False

    def close(self) -> None:
        """Close the underlying HTTP client if we own it."""
        if self._owns_http:
            self._http.close()

    def url(self, path: str) -> str:
        return _build_url(self.base_url, path)

    def send(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Send a request and raise on transport / non-2xx response."""
        try:
            response = self._http.request(method, self.url(path), **kwargs)
        except httpx.HTTPError as e:
            raise BeeTransportError(str(e)) from e
        if not response.is_success:
            _raise_response_error(response)
        return response

    def send_json(self, method: str, path: str, **kwargs: Any) -> Any:
        response = self.send(method, path, **kwargs)
        return _decode_json(response.content)


__all__ = ["_AsyncInner", "_SyncInner"]
