"""Postage batch data types.

Mirrors bee-rs ``postage::types`` and bee-go ``pkg/postage/postage.go``.

**Wire-format gotchas captured from the bee-rs port:**

- The owner endpoint (``GET /stamps/{id}``) uses ``"amount"`` and
  ``"immutableFlag"``.
- The chain-wide endpoint (``GET /batches``) uses ``"value"`` and
  ``"immutable"``.
- ``BigInt`` values arrive as JSON strings and are parsed to Python
  ``int`` (Python ints are arbitrary precision).
- The batch ID field is ``"batchID"`` (uppercase ID), and the TTL
  field is ``"batchTTL"``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..swarm.errors import BeeJsonError
from ..swarm.typed_bytes import BatchId


def _parse_optional_bigint(s: object) -> int | None:
    """Decode an optional BigInt-as-string. Empty string → None."""
    if s is None or s == "":
        return None
    if isinstance(s, int):
        return s
    if not isinstance(s, str):
        raise BeeJsonError(f"expected bigint string, got {s!r}")
    try:
        return int(s)
    except ValueError as e:
        raise BeeJsonError(f"invalid bigint string {s!r}: {e}") from e


@dataclass(frozen=True, slots=True)
class PostageBatch:
    """Postage batch as returned by ``GET /stamps`` / ``GET /stamps/{id}``
    (owner-only view; includes utilization, label, blockNumber).
    """

    batch_id: BatchId
    depth: int
    bucket_depth: int
    amount: int | None = None
    start: int = 0
    owner: str = ""
    immutable: bool = False
    batch_ttl: int = 0
    utilization: int = 0
    usable: bool = False
    exists: bool = False
    label: str = ""
    block_number: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PostageBatch:
        try:
            return cls(
                batch_id=BatchId.from_hex(data["batchID"]),
                depth=int(data["depth"]),
                bucket_depth=int(data["bucketDepth"]),
                amount=_parse_optional_bigint(data.get("amount")),
                start=int(data.get("start", 0)),
                owner=str(data.get("owner", "")),
                immutable=bool(data.get("immutableFlag", False)),
                batch_ttl=int(data.get("batchTTL", 0)),
                utilization=int(data.get("utilization", 0)),
                usable=bool(data.get("usable", False)),
                exists=bool(data.get("exists", False)),
                label=str(data.get("label", "")),
                block_number=int(data.get("blockNumber", 0)),
            )
        except KeyError as e:
            raise BeeJsonError(f"missing field in PostageBatch: {e}") from e


@dataclass(frozen=True, slots=True)
class GlobalPostageBatch:
    """Postage batch as returned by ``GET /batches`` (chain-wide view;
    drops owner-only fields).

    Note the field-name divergence vs :class:`PostageBatch`: this
    endpoint uses ``"value"`` (not ``"amount"``) and ``"immutable"``
    (not ``"immutableFlag"``).
    """

    batch_id: BatchId
    depth: int
    bucket_depth: int
    value: int | None = None
    start: int = 0
    owner: str = ""
    immutable: bool = False
    batch_ttl: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GlobalPostageBatch:
        try:
            return cls(
                batch_id=BatchId.from_hex(data["batchID"]),
                depth=int(data["depth"]),
                bucket_depth=int(data["bucketDepth"]),
                value=_parse_optional_bigint(data.get("value")),
                start=int(data.get("start", 0)),
                owner=str(data.get("owner", "")),
                immutable=bool(data.get("immutable", False)),
                batch_ttl=int(data.get("batchTTL", 0)),
            )
        except KeyError as e:
            raise BeeJsonError(f"missing field in GlobalPostageBatch: {e}") from e


@dataclass(frozen=True, slots=True)
class BatchBucket:
    """Per-bucket collision count from ``GET /stamps/{id}/buckets``."""

    bucket_id: int
    collisions: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BatchBucket:
        try:
            return cls(
                bucket_id=int(data["bucketID"]),
                collisions=int(data["collisions"]),
            )
        except KeyError as e:
            raise BeeJsonError(f"missing field in BatchBucket: {e}") from e


@dataclass(frozen=True, slots=True)
class PostageBatchBuckets:
    """Aggregated bucket fill stats for one batch."""

    depth: int
    bucket_depth: int
    bucket_upper_bound: int
    buckets: list[BatchBucket] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PostageBatchBuckets:
        try:
            raw_buckets = data.get("buckets") or []
            if not isinstance(raw_buckets, list):
                raise BeeJsonError(f"buckets is not a list: {raw_buckets!r}")
            return cls(
                depth=int(data["depth"]),
                bucket_depth=int(data["bucketDepth"]),
                bucket_upper_bound=int(data["bucketUpperBound"]),
                buckets=[BatchBucket.from_dict(b) for b in raw_buckets],
            )
        except KeyError as e:
            raise BeeJsonError(f"missing field in PostageBatchBuckets: {e}") from e


__all__ = [
    "BatchBucket",
    "GlobalPostageBatch",
    "PostageBatch",
    "PostageBatchBuckets",
]
