"""Client-side postage stamper.

Mirrors bee-rs ``postage::stamper`` and bee-go's
``pkg/postage/stamper.go``. Lets a caller produce a per-chunk
:class:`Envelope` without round-tripping the node — the primitive
needed for ``postEnvelope``-style flows and progressive uploads.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from ..swarm.errors import BeeArgumentError
from ..swarm.keys import PrivateKey
from ..swarm.typed_bytes import BatchId, EthAddress, Signature

#: Number of buckets in a postage batch (``2^16``).
NUM_BUCKETS: int = 1 << 16

#: Bucket-depth floor: stamper depth must be **strictly greater than**
#: this value (matches bee-go and bee-js — both require ``depth > 16``).
MIN_DEPTH: int = 16

#: Wire-format length of a marshaled postage stamp:
#: ``batchID(32) || index(8) || timestamp(8) || signature(65)``.
MARSHALED_STAMP_LENGTH: int = 32 + 8 + 8 + 65


@dataclass(frozen=True, slots=True)
class Envelope:
    """Per-chunk postage envelope returned by :meth:`Stamper.stamp`.

    Mirrors bee-js ``EnvelopeWithBatchId`` and bee-go
    ``postage.Envelope``.
    """

    #: Batch the chunk is stamped against.
    batch_id: BatchId
    #: 8 bytes: ``bucket (BE u32) || height (BE u32)``.
    index: bytes
    #: Issuer (signer's Ethereum address).
    issuer: EthAddress
    #: 65-byte ``R || S || V`` signature with ``V ∈ {27, 28}``.
    signature: Signature
    #: 8 bytes: Unix milliseconds (BE u64), matching bee-js ``Date.now()``.
    timestamp: bytes


class Stamper:
    """Client-side stamper that tracks per-bucket utilisation and signs
    envelopes for individual chunks.

    Construct with :meth:`Stamper.from_blank` for a fresh batch or
    :meth:`Stamper.from_state` to resume from previously-persisted
    bucket counters.
    """

    __slots__ = ("_batch_id", "_buckets", "_depth", "_max_slot", "_signer")

    def __init__(
        self,
        signer: PrivateKey,
        batch_id: BatchId,
        buckets: list[int],
        depth: int,
    ) -> None:
        if depth <= MIN_DEPTH:
            raise BeeArgumentError(f"stamper depth must be > {MIN_DEPTH}, got {depth}")
        if len(buckets) != NUM_BUCKETS:
            raise BeeArgumentError(f"buckets length must be {NUM_BUCKETS}, got {len(buckets)}")
        self._signer: PrivateKey = signer
        self._batch_id: BatchId = batch_id
        self._buckets: list[int] = list(buckets)
        self._depth: int = depth
        self._max_slot: int = 1 << (depth - MIN_DEPTH)

    @classmethod
    def from_blank(cls, signer: PrivateKey, batch_id: BatchId, depth: int) -> Stamper:
        """New stamper with empty buckets."""
        return cls(signer, batch_id, [0] * NUM_BUCKETS, depth)

    @classmethod
    def from_state(
        cls,
        signer: PrivateKey,
        batch_id: BatchId,
        buckets: list[int],
        depth: int,
    ) -> Stamper:
        """Resume a stamper from previously-persisted bucket counters.

        ``buckets`` length must equal :data:`NUM_BUCKETS`.
        """
        return cls(signer, batch_id, buckets, depth)

    def stamp(self, chunk_addr: bytes) -> Envelope:
        """Stamp a chunk address.

        Increments the per-bucket counter and returns a freshly-signed
        :class:`Envelope`. Raises :class:`BeeArgumentError` if the
        bucket is full or the address length is wrong.
        """
        if len(chunk_addr) != 32:
            raise BeeArgumentError(f"chunk address must be 32 bytes, got {len(chunk_addr)}")

        bucket = int.from_bytes(chunk_addr[:2], "big")
        height = self._buckets[bucket]
        if height >= self._max_slot:
            raise BeeArgumentError(
                f"bucket {bucket} is full (height={height}, max_slot={self._max_slot})"
            )
        self._buckets[bucket] = height + 1

        index = bucket.to_bytes(4, "big") + height.to_bytes(4, "big")
        timestamp = (time.time_ns() // 1_000_000).to_bytes(8, "big")

        to_sign = chunk_addr + self._batch_id.as_bytes() + index + timestamp
        signature = self._signer.sign(to_sign)
        issuer = self._signer.public_key().address()

        return Envelope(
            batch_id=self._batch_id,
            index=index,
            issuer=issuer,
            signature=signature,
            timestamp=timestamp,
        )

    def state(self) -> list[int]:
        """Snapshot of the current bucket counters. Useful for
        persisting and resuming via :meth:`from_state`. Returns a
        defensive copy.
        """
        return list(self._buckets)

    @property
    def depth(self) -> int:
        """Configured depth."""
        return self._depth

    @property
    def max_slot(self) -> int:
        """Maximum height per bucket (``2^(depth - 16)``)."""
        return self._max_slot

    @property
    def batch_id(self) -> BatchId:
        """Configured batch ID."""
        return self._batch_id


def marshal_stamp(
    batch_id: BatchId,
    index: bytes,
    timestamp: bytes,
    signature: Signature,
) -> bytes:
    """Concatenate the components of a postage stamp into the wire
    format Bee expects when a stamp travels alongside a chunk:
    ``batchID(32) || index(8) || timestamp(8) || signature(65)`` —
    113 bytes total.

    Mirrors bee-go ``postage.MarshalStamp`` and bee-js ``marshalStamp``.
    """
    if len(index) != 8:
        raise BeeArgumentError(f"invalid index length: {len(index)}")
    if len(timestamp) != 8:
        raise BeeArgumentError(f"invalid timestamp length: {len(timestamp)}")
    return batch_id.as_bytes() + index + timestamp + signature.as_bytes()


def convert_envelope_to_marshaled_stamp(env: Envelope) -> bytes:
    """Marshal an :class:`Envelope` into the 113-byte stamp wire format.

    Thin wrapper over :func:`marshal_stamp`. Mirrors bee-go
    ``ConvertEnvelopeToMarshaledStamp`` / bee-js
    ``convertEnvelopeToMarshaledStamp``.
    """
    return marshal_stamp(env.batch_id, env.index, env.timestamp, env.signature)


__all__ = [
    "MARSHALED_STAMP_LENGTH",
    "MIN_DEPTH",
    "NUM_BUCKETS",
    "Envelope",
    "Stamper",
    "convert_envelope_to_marshaled_stamp",
    "marshal_stamp",
]
