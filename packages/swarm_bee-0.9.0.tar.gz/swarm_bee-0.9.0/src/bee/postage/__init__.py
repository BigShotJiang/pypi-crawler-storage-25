"""Postage batch CRUD + stamp math.

Mirrors ``pkg/postage`` in bee-go and ``postage`` in bee-rs. 0.3.0
ships read endpoints + write endpoints (create, top-up, dilute);
stamp math and the offline ``Stamper`` land in follow-up commits.
"""

from __future__ import annotations

from typing import Any

from .._inner import _AsyncInner, _SyncInner
from ..api.options import PostageBatchOptions
from ..swarm.errors import BeeJsonError
from ..swarm.typed_bytes import BatchId
from ._types import (
    BatchBucket,
    GlobalPostageBatch,
    PostageBatch,
    PostageBatchBuckets,
)
from .stamp_math import (
    EFFECTIVE_SIZE_BREAKPOINTS,
    get_depth_for_size,
    get_stamp_cost,
    get_stamp_effective_bytes,
    get_stamp_theoretical_bytes,
    get_stamp_usage,
)
from .stamper import (
    MARSHALED_STAMP_LENGTH,
    MIN_DEPTH,
    NUM_BUCKETS,
    Envelope,
    Stamper,
    convert_envelope_to_marshaled_stamp,
    marshal_stamp,
)


def _parse_batch_id_response(payload: object) -> BatchId:
    """Pull the ``"batchID"`` field out of a buy response."""
    if not isinstance(payload, dict) or "batchID" not in payload:
        raise BeeJsonError(f"missing 'batchID' in postage response: {payload!r}")
    raw = payload["batchID"]
    if not isinstance(raw, str):
        raise BeeJsonError(f"'batchID' is not a string: {raw!r}")
    return BatchId.from_hex(raw)


def _parse_stamps_list(payload: object) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        raise BeeJsonError(f"expected stamps wrapper object, got {payload!r}")
    items = payload.get("stamps")
    if not isinstance(items, list):
        raise BeeJsonError(f"'stamps' is not a list: {items!r}")
    return items


def _parse_batches_list(payload: object) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        raise BeeJsonError(f"expected batches wrapper object, got {payload!r}")
    items = payload.get("batches")
    if not isinstance(items, list):
        raise BeeJsonError(f"'batches' is not a list: {items!r}")
    return items


def _create_batch_query(opts: PostageBatchOptions | None) -> dict[str, str] | None:
    """Build the query string for POST /stamps/{amount}/{depth}."""
    if opts is None:
        return None
    q: dict[str, str] = {}
    if opts.label is not None:
        q["label"] = opts.label
    if opts.immutable is not None:
        q["immutable"] = "true" if opts.immutable else "false"
    return q or None


def _create_batch_headers(opts: PostageBatchOptions | None) -> list[tuple[str, str]] | None:
    """Build the Gas-Price / Gas-Limit headers for POST /stamps."""
    if opts is None:
        return None
    headers: list[tuple[str, str]] = []
    if opts.gas_price is not None:
        headers.append(("Gas-Price", opts.gas_price))
    if opts.gas_limit is not None:
        headers.append(("Gas-Limit", opts.gas_limit))
    return headers or None


class AsyncPostageApi:
    """Async postage-domain handle. Reachable as :attr:`bee.AsyncBee.postage`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _AsyncInner) -> None:
        self._inner = inner

    async def get_postage_batches(self) -> list[PostageBatch]:
        """Every postage batch owned by this node — ``GET /stamps``."""
        payload = await self._inner.send_json("GET", "stamps")
        return [PostageBatch.from_dict(b) for b in _parse_stamps_list(payload)]

    async def get_postage_batch(self, batch_id: BatchId) -> PostageBatch:
        """Single owned batch by id — ``GET /stamps/{id}``."""
        payload = await self._inner.send_json("GET", f"stamps/{batch_id.to_hex()}")
        if not isinstance(payload, dict):
            raise BeeJsonError(f"expected PostageBatch object, got {payload!r}")
        return PostageBatch.from_dict(payload)

    async def get_postage_batch_buckets(self, batch_id: BatchId) -> PostageBatchBuckets:
        """Per-bucket collision stats — ``GET /stamps/{id}/buckets``."""
        payload = await self._inner.send_json("GET", f"stamps/{batch_id.to_hex()}/buckets")
        if not isinstance(payload, dict):
            raise BeeJsonError(f"expected PostageBatchBuckets object, got {payload!r}")
        return PostageBatchBuckets.from_dict(payload)

    async def get_global_postage_batches(self) -> list[GlobalPostageBatch]:
        """Every chain-visible postage batch — ``GET /batches``."""
        payload = await self._inner.send_json("GET", "batches")
        return [GlobalPostageBatch.from_dict(b) for b in _parse_batches_list(payload)]

    async def create_postage_batch(
        self,
        amount: int,
        depth: int,
        label: str | None = None,
        opts: PostageBatchOptions | None = None,
    ) -> BatchId:
        """Buy a new postage batch — ``POST /stamps/{amount}/{depth}``.

        Returns the freshly-minted :class:`BatchId`. ``label`` is a
        convenience for ``opts.label``; passing both with conflicting
        values raises :class:`BeeJsonError` (caller bug).
        """
        if (
            label is not None
            and opts is not None
            and opts.label is not None
            and opts.label != label
        ):
            raise BeeJsonError(f"label arg ({label!r}) conflicts with opts.label ({opts.label!r})")
        if label is not None and (opts is None or opts.label is None):
            opts = PostageBatchOptions(
                label=label,
                immutable=opts.immutable if opts else None,
                gas_price=opts.gas_price if opts else None,
                gas_limit=opts.gas_limit if opts else None,
            )
        path = f"stamps/{amount}/{depth}"
        payload = await self._inner.send_json(
            "POST",
            path,
            params=_create_batch_query(opts),
            headers=_create_batch_headers(opts),
        )
        return _parse_batch_id_response(payload)

    async def top_up_batch(self, batch_id: BatchId, amount: int) -> None:
        """Top up an existing batch — ``PATCH /stamps/topup/{id}/{amount}``."""
        await self._inner.send("PATCH", f"stamps/topup/{batch_id.to_hex()}/{amount}")

    async def dilute_batch(self, batch_id: BatchId, depth: int) -> None:
        """Increase the depth of an existing batch —
        ``PATCH /stamps/dilute/{id}/{depth}``. Dilute is one-way: depth
        can only grow, never shrink."""
        await self._inner.send("PATCH", f"stamps/dilute/{batch_id.to_hex()}/{depth}")


class PostageApi:
    """Sync postage-domain handle. Reachable as :attr:`bee.Bee.postage`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _SyncInner) -> None:
        self._inner = inner

    def get_postage_batches(self) -> list[PostageBatch]:
        payload = self._inner.send_json("GET", "stamps")
        return [PostageBatch.from_dict(b) for b in _parse_stamps_list(payload)]

    def get_postage_batch(self, batch_id: BatchId) -> PostageBatch:
        payload = self._inner.send_json("GET", f"stamps/{batch_id.to_hex()}")
        if not isinstance(payload, dict):
            raise BeeJsonError(f"expected PostageBatch object, got {payload!r}")
        return PostageBatch.from_dict(payload)

    def get_postage_batch_buckets(self, batch_id: BatchId) -> PostageBatchBuckets:
        payload = self._inner.send_json("GET", f"stamps/{batch_id.to_hex()}/buckets")
        if not isinstance(payload, dict):
            raise BeeJsonError(f"expected PostageBatchBuckets object, got {payload!r}")
        return PostageBatchBuckets.from_dict(payload)

    def get_global_postage_batches(self) -> list[GlobalPostageBatch]:
        payload = self._inner.send_json("GET", "batches")
        return [GlobalPostageBatch.from_dict(b) for b in _parse_batches_list(payload)]

    def create_postage_batch(
        self,
        amount: int,
        depth: int,
        label: str | None = None,
        opts: PostageBatchOptions | None = None,
    ) -> BatchId:
        if (
            label is not None
            and opts is not None
            and opts.label is not None
            and opts.label != label
        ):
            raise BeeJsonError(f"label arg ({label!r}) conflicts with opts.label ({opts.label!r})")
        if label is not None and (opts is None or opts.label is None):
            opts = PostageBatchOptions(
                label=label,
                immutable=opts.immutable if opts else None,
                gas_price=opts.gas_price if opts else None,
                gas_limit=opts.gas_limit if opts else None,
            )
        path = f"stamps/{amount}/{depth}"
        payload = self._inner.send_json(
            "POST",
            path,
            params=_create_batch_query(opts),
            headers=_create_batch_headers(opts),
        )
        return _parse_batch_id_response(payload)

    def top_up_batch(self, batch_id: BatchId, amount: int) -> None:
        self._inner.send("PATCH", f"stamps/topup/{batch_id.to_hex()}/{amount}")

    def dilute_batch(self, batch_id: BatchId, depth: int) -> None:
        self._inner.send("PATCH", f"stamps/dilute/{batch_id.to_hex()}/{depth}")


__all__ = [
    "EFFECTIVE_SIZE_BREAKPOINTS",
    "MARSHALED_STAMP_LENGTH",
    "MIN_DEPTH",
    "NUM_BUCKETS",
    "AsyncPostageApi",
    "BatchBucket",
    "Envelope",
    "GlobalPostageBatch",
    "PostageApi",
    "PostageBatch",
    "PostageBatchBuckets",
    "Stamper",
    "convert_envelope_to_marshaled_stamp",
    "get_depth_for_size",
    "get_stamp_cost",
    "get_stamp_effective_bytes",
    "get_stamp_theoretical_bytes",
    "get_stamp_usage",
    "marshal_stamp",
]
