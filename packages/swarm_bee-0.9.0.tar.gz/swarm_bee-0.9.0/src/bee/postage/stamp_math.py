"""Pure stamp math.

Mirrors bee-rs ``postage::stamp_math``, bee-go's free functions in
``pkg/postage/postage.go``, and bee-js's ``stamps.ts``. No I/O — these
are offline calculators for "how big a batch do I need" / "how much
will it cost".

Python ``int`` is arbitrary-precision so we don't need a separate
BigInt type — bee-rs uses ``num_bigint::BigInt``, we just use ``int``.
"""

from __future__ import annotations

#: Effective-utilisation breakpoints (depth → gigabytes) for encrypted,
#: medium-erasure batches. Values mirror bee-js ``stamps.ts`` exactly.
EFFECTIVE_SIZE_BREAKPOINTS: tuple[tuple[int, float], ...] = (
    (17, 0.00004089),
    (18, 0.00609),
    (19, 0.10249),
    (20, 0.62891),
    (21, 2.38),
    (22, 7.07),
    (23, 18.24),
    (24, 43.04),
    (25, 96.5),
    (26, 208.52),
    (27, 435.98),
    (28, 908.81),
    (29, 1870.0),
    (30, 3810.0),
    (31, 7730.0),
    (32, 15610.0),
    (33, 31430.0),
    (34, 63150.0),
)


def get_stamp_usage(utilization: int, depth: int, bucket_depth: int) -> float:
    """Fractional usage ``[0, 1]`` of a postage batch."""
    denom = 1 << (depth - bucket_depth)
    return utilization / float(denom)


def get_stamp_theoretical_bytes(depth: int) -> int:
    """Theoretical capacity of a batch: ``4096 * 2^depth`` bytes."""
    return 4096 * (1 << depth)


def get_stamp_cost(depth: int, amount: int) -> int:
    """Cost of buying a batch: ``2^depth * amount`` PLUR."""
    return (1 << depth) * amount


def get_stamp_effective_bytes(depth: int) -> int:
    """Practical capacity for ``depth`` using the encrypted-medium
    erasure breakpoints (17..=34). Outside that range falls back to
    ``0.9 * theoretical``; below depth 17 returns ``0``.
    """
    if depth < 17:
        return 0
    for d, gb in EFFECTIVE_SIZE_BREAKPOINTS:
        if d == depth:
            return int(gb * 1_000_000_000.0)
    theoretical = get_stamp_theoretical_bytes(depth)
    return int(theoretical * 0.9)


def get_depth_for_size(num_bytes: int) -> int:
    """Smallest depth whose effective capacity covers ``num_bytes``.
    Falls back to ``35`` for sizes the table doesn't cover.
    """
    for d, gb in EFFECTIVE_SIZE_BREAKPOINTS:
        if num_bytes <= gb * 1_000_000_000.0:
            return d
    return 35


__all__ = [
    "EFFECTIVE_SIZE_BREAKPOINTS",
    "get_depth_for_size",
    "get_stamp_cost",
    "get_stamp_effective_bytes",
    "get_stamp_theoretical_bytes",
    "get_stamp_usage",
]
