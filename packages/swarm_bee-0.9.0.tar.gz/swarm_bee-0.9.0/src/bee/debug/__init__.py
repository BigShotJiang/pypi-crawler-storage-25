"""Debug / operator endpoints.

Mirrors ``pkg/debug`` in bee-go and ``debug`` in bee-rs. Covers:

- Node + chain: ``/health``, ``/node``, ``/chainstate``, ``/status``,
  ``/status/peers``, ``/status/neighborhoods``, ``/readiness``,
  ``/gateway``.
- Accounting + stake: ``/balances``, ``/consumed``, ``/accounting``,
  ``/stake``, ``/redistributionstate``, ``/rchash``.
- Chequebook + settlements + wallet: ``/wallet``,
  ``/wallet/withdraw/{bzz,nativetoken}``, ``/chequebook/*``,
  ``/settlements``, ``/timesettlements``.
- Peers + topology: ``/peers``, ``/blocklist``, ``/pingpong``,
  ``/connect``, ``/addresses``, ``/topology``, ``/reservestate``,
  ``/welcome-message``.
- Transactions: ``/transactions``.
- Loggers: ``/loggers``.

``BigInt`` fields (PLUR balances, gas prices, …) are Python ``int``;
empty strings on the wire decode as ``None`` for optional fields and
``0`` for required ones.
"""

from __future__ import annotations

import base64
import json
from typing import Any

from .._inner import _AsyncInner, _SyncInner
from ..swarm.errors import BeeJsonError, BeeResponseError
from ._types import (
    Addresses,
    Balance,
    BeeVersions,
    BinInfo,
    CashoutResult,
    ChainState,
    Cheque,
    ChequebookBalance,
    ChunkInclusionProof,
    ChunkInclusionProofs,
    Health,
    LastCashoutAction,
    LastCheque,
    Logger,
    LoggerListing,
    MetricSnapshotView,
    Neighborhood,
    NodeInfo,
    Peer,
    PeerAccounting,
    PeerCheques,
    PeerInfo,
    PeerStatus,
    PostageProof,
    RCHashResponse,
    RedistributionState,
    ReserveState,
    Settlement,
    Settlements,
    SocProof,
    Status,
    Topology,
    TransactionInfo,
    Wallet,
)

#: Supported API version this client claims compatibility with.
SUPPORTED_API_VERSION: str = "8.0.0"
#: Supported exact Bee version this client targets.
SUPPORTED_BEE_VERSION_EXACT: str = "2.7.2-rc1-83612d37"

_JSON_CONTENT_TYPE = "application/json"


def _expect_dict(payload: object, ctx: str) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise BeeJsonError(f"{ctx}: expected object, got {payload!r}")
    return payload


def _expect_list(payload: object, ctx: str) -> list[Any]:
    if not isinstance(payload, list):
        raise BeeJsonError(f"{ctx}: expected list, got {payload!r}")
    return payload


def _extract_field(payload: object, key: str, ctx: str) -> Any:
    d = _expect_dict(payload, ctx)
    if key not in d:
        raise BeeJsonError(f"{ctx}: missing {key!r} key")
    return d[key]


def _parse_balances_list(payload: object) -> list[Balance]:
    items = _extract_field(payload, "balances", "/balances")
    return [
        Balance.from_dict(_expect_dict(i, "balance row")) for i in _expect_list(items, "balances")
    ]


def _parse_accounting_map(payload: object) -> dict[str, PeerAccounting]:
    peer_data = _extract_field(payload, "peerData", "/accounting")
    if not isinstance(peer_data, dict):
        raise BeeJsonError(f"/accounting: peerData is not a map: {peer_data!r}")
    return {k: PeerAccounting.from_dict(v) for k, v in peer_data.items() if isinstance(v, dict)}


def _parse_bigint_field(payload: object, key: str, ctx: str) -> int:
    value = _extract_field(payload, key, ctx)
    if not isinstance(value, str):
        raise BeeJsonError(f"{ctx}: {key} is not a string: {value!r}")
    if not value:
        return 0
    try:
        return int(value, 10)
    except ValueError as e:
        raise BeeJsonError(f"{ctx}: invalid {key} bigint {value!r}") from e


def _parse_tx_hash(payload: object) -> str:
    value = _extract_field(payload, "transactionHash", "transaction response")
    if not isinstance(value, str):
        raise BeeJsonError(f"transactionHash is not a string: {value!r}")
    return value


def _parse_stake_tx_hash(payload: object) -> str:
    value = _extract_field(payload, "txHash", "stake response")
    if not isinstance(value, str):
        raise BeeJsonError(f"txHash is not a string: {value!r}")
    return value


def _parse_peer_list(payload: object, ctx: str) -> list[Peer]:
    items = _extract_field(payload, "peers", ctx)
    return [Peer.from_dict(_expect_dict(p, ctx + " row")) for p in _expect_list(items, ctx)]


def _parse_status_peers(payload: object) -> list[PeerStatus]:
    items = _extract_field(payload, "snapshots", "/status/peers")
    return [
        PeerStatus.from_dict(_expect_dict(p, "peer status row"))
        for p in _expect_list(items, "snapshots")
    ]


def _parse_neighborhoods(payload: object) -> list[Neighborhood]:
    items = _extract_field(payload, "neighborhoods", "/status/neighborhoods")
    return [
        Neighborhood.from_dict(_expect_dict(n, "neighborhood row"))
        for n in _expect_list(items, "neighborhoods")
    ]


def _parse_last_cheques(payload: object) -> list[LastCheque]:
    items = _extract_field(payload, "lastcheques", "/chequebook/cheque")
    return [
        LastCheque.from_dict(_expect_dict(c, "lastcheque row"))
        for c in _expect_list(items, "lastcheques")
    ]


def _parse_pending_transactions(payload: object) -> list[TransactionInfo]:
    items = _extract_field(payload, "pendingTransactions", "/transactions")
    return [
        TransactionInfo.from_dict(_expect_dict(t, "transaction row"))
        for t in _expect_list(items, "pendingTransactions")
    ]


def _parse_welcome_message(payload: object) -> str:
    value = _extract_field(payload, "welcomeMessage", "/welcome-message")
    if not isinstance(value, str):
        raise BeeJsonError(f"welcomeMessage is not a string: {value!r}")
    return value


def _parse_rtt(payload: object) -> str:
    value = _extract_field(payload, "rtt", "/pingpong")
    if not isinstance(value, str):
        raise BeeJsonError(f"rtt is not a string: {value!r}")
    return value


def _parse_overlay_address(payload: object) -> str:
    value = _extract_field(payload, "address", "/connect")
    if not isinstance(value, str):
        raise BeeJsonError(f"address is not a string: {value!r}")
    return value


def _parse_gateway(payload: object) -> bool:
    value = _extract_field(payload, "gateway", "/gateway")
    return bool(value)


def _b64(s: str) -> str:
    return base64.b64encode(s.encode("utf-8")).decode("ascii")


# ---- Async surface -------------------------------------------------------


class AsyncDebugApi:
    """Async debug-domain handle. Reachable as :attr:`bee.AsyncBee.debug`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _AsyncInner) -> None:
        self._inner = inner

    # node -----------------------------------------------------------

    async def health(self) -> Health:
        """``GET /health``."""
        return Health.from_dict(
            _expect_dict(await self._inner.send_json("GET", "health"), "/health")
        )

    async def versions(self) -> BeeVersions:
        """Structured version triple from ``/health``."""
        h = await self.health()
        return BeeVersions(
            bee_version=h.version,
            bee_api_version=h.api_version,
            supported_api_version=SUPPORTED_API_VERSION,
            supported_bee_version_exact=SUPPORTED_BEE_VERSION_EXACT,
        )

    async def is_supported_api_version(self) -> bool:
        return (await self.health()).api_version == SUPPORTED_API_VERSION

    async def is_supported_exact_version(self) -> bool:
        return (await self.health()).version == SUPPORTED_BEE_VERSION_EXACT

    async def chain_state(self) -> ChainState:
        """``GET /chainstate``."""
        return ChainState.from_dict(
            _expect_dict(await self._inner.send_json("GET", "chainstate"), "/chainstate")
        )

    async def node_info(self) -> NodeInfo:
        """``GET /node``."""
        return NodeInfo.from_dict(_expect_dict(await self._inner.send_json("GET", "node"), "/node"))

    async def status(self) -> Status:
        """``GET /status``."""
        return Status.from_dict(
            _expect_dict(await self._inner.send_json("GET", "status"), "/status")
        )

    async def status_peers(self) -> list[PeerStatus]:
        """``GET /status/peers``."""
        return _parse_status_peers(await self._inner.send_json("GET", "status/peers"))

    async def status_neighborhoods(self) -> list[Neighborhood]:
        """``GET /status/neighborhoods``."""
        return _parse_neighborhoods(await self._inner.send_json("GET", "status/neighborhoods"))

    async def readiness(self) -> bool:
        """``GET /readiness`` — True on 2xx, False on 404/503."""
        try:
            await self._inner.send("GET", "readiness")
        except BeeResponseError as e:
            if e.status in (404, 503):
                return False
            raise
        return True

    async def is_gateway(self) -> bool:
        """``GET /gateway`` — True iff Bee is in gateway mode (404→False)."""
        try:
            payload = await self._inner.send_json("GET", "gateway")
        except BeeResponseError as e:
            if e.status == 404:
                return False
            raise
        return _parse_gateway(payload)

    async def is_connected(self) -> bool:
        """Ping the base URL — True on any 2xx, False otherwise."""
        try:
            await self._inner.send("GET", "")
        except Exception:
            return False
        return True

    # accounting + stake --------------------------------------------

    async def balances(self) -> list[Balance]:
        return _parse_balances_list(await self._inner.send_json("GET", "balances"))

    async def peer_balance(self, address: str) -> Balance:
        return Balance.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", f"balances/{address}"), "/balances/{addr}"
            )
        )

    async def consumed_balances(self) -> list[Balance]:
        return _parse_balances_list(await self._inner.send_json("GET", "consumed"))

    async def peer_consumed_balance(self, address: str) -> Balance:
        return Balance.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", f"consumed/{address}"), "/consumed/{addr}"
            )
        )

    async def accounting(self) -> dict[str, PeerAccounting]:
        return _parse_accounting_map(await self._inner.send_json("GET", "accounting"))

    async def stake(self) -> int:
        """``GET /stake`` — staked amount in PLUR."""
        return _parse_bigint_field(
            await self._inner.send_json("GET", "stake"), "stakedAmount", "/stake"
        )

    async def deposit_stake(self, amount: int) -> str:
        """``POST /stake/{amount}`` — returns transaction hash."""
        return _parse_stake_tx_hash(await self._inner.send_json("POST", f"stake/{amount}"))

    async def withdrawable_stake(self) -> int:
        return _parse_bigint_field(
            await self._inner.send_json("GET", "stake/withdrawable"),
            "withdrawableAmount",
            "/stake/withdrawable",
        )

    async def withdraw_surplus_stake(self) -> str:
        return _parse_stake_tx_hash(await self._inner.send_json("DELETE", "stake/withdrawable"))

    async def migrate_stake(self) -> str:
        return _parse_stake_tx_hash(await self._inner.send_json("DELETE", "stake"))

    async def redistribution_state(self) -> RedistributionState:
        return RedistributionState.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", "redistributionstate"), "/redistributionstate"
            )
        )

    async def r_chash(self, depth: int, anchor1: str, anchor2: str) -> RCHashResponse:
        return RCHashResponse.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", f"rchash/{depth}/{anchor1}/{anchor2}"),
                "/rchash",
            )
        )

    # wallet + chequebook + settlements ----------------------------

    async def wallet(self) -> Wallet:
        return Wallet.from_dict(
            _expect_dict(await self._inner.send_json("GET", "wallet"), "/wallet")
        )

    async def withdraw_bzz(self, amount: int, address: str) -> str:
        return _parse_tx_hash(
            await self._inner.send_json(
                "POST", "wallet/withdraw/bzz", params={"amount": str(amount), "address": address}
            )
        )

    async def withdraw_native_token(self, amount: int, address: str) -> str:
        return _parse_tx_hash(
            await self._inner.send_json(
                "POST",
                "wallet/withdraw/nativetoken",
                params={"amount": str(amount), "address": address},
            )
        )

    async def chequebook_balance(self) -> ChequebookBalance:
        return ChequebookBalance.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", "chequebook/balance"), "/chequebook/balance"
            )
        )

    async def chequebook_deposit(self, amount: int) -> str:
        return _parse_tx_hash(
            await self._inner.send_json(
                "POST", "chequebook/deposit", params={"amount": str(amount)}
            )
        )

    async def chequebook_withdraw(self, amount: int) -> str:
        return _parse_tx_hash(
            await self._inner.send_json(
                "POST", "chequebook/withdraw", params={"amount": str(amount)}
            )
        )

    async def last_cheques(self) -> list[LastCheque]:
        return _parse_last_cheques(await self._inner.send_json("GET", "chequebook/cheque"))

    async def peer_cheques(self, peer: str) -> PeerCheques:
        return PeerCheques.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", f"chequebook/cheque/{peer}"),
                "/chequebook/cheque/{peer}",
            )
        )

    async def last_cashout_action(self, peer: str) -> LastCashoutAction:
        return LastCashoutAction.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", f"chequebook/cashout/{peer}"),
                "/chequebook/cashout/{peer}",
            )
        )

    async def cashout_last_cheque(self, peer: str, gas_price: int | None = None) -> str:
        headers: list[tuple[str, str]] = []
        if gas_price is not None:
            headers.append(("gas-price", str(gas_price)))
        return _parse_tx_hash(
            await self._inner.send_json(
                "POST", f"chequebook/cashout/{peer}", headers=headers or None
            )
        )

    async def settlements(self) -> Settlements:
        return Settlements.from_dict(
            _expect_dict(await self._inner.send_json("GET", "settlements"), "/settlements")
        )

    async def peer_settlement(self, peer: str) -> Settlement:
        return Settlement.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", f"settlements/{peer}"), "/settlements/{peer}"
            )
        )

    async def time_settlements(self) -> Settlements:
        return Settlements.from_dict(
            _expect_dict(await self._inner.send_json("GET", "timesettlements"), "/timesettlements")
        )

    # peers + topology ---------------------------------------------

    async def peers(self) -> list[Peer]:
        return _parse_peer_list(await self._inner.send_json("GET", "peers"), "/peers")

    async def blocklist(self) -> list[Peer]:
        return _parse_peer_list(await self._inner.send_json("GET", "blocklist"), "/blocklist")

    async def remove_peer(self, address: str) -> None:
        await self._inner.send("DELETE", f"peers/{address}")

    async def ping_peer(self, address: str) -> str:
        return _parse_rtt(await self._inner.send_json("POST", f"pingpong/{address}"))

    async def connect_peer(self, multiaddr: str) -> str:
        return _parse_overlay_address(
            await self._inner.send_json("POST", f"connect/{multiaddr.lstrip('/')}")
        )

    async def addresses(self) -> Addresses:
        return Addresses.from_dict(
            _expect_dict(await self._inner.send_json("GET", "addresses"), "/addresses")
        )

    async def topology(self) -> Topology:
        return Topology.from_dict(
            _expect_dict(await self._inner.send_json("GET", "topology"), "/topology")
        )

    async def reserve_state(self) -> ReserveState:
        return ReserveState.from_dict(
            _expect_dict(await self._inner.send_json("GET", "reservestate"), "/reservestate")
        )

    async def welcome_message(self) -> str:
        return _parse_welcome_message(await self._inner.send_json("GET", "welcome-message"))

    async def set_welcome_message(self, message: str) -> None:
        body = json.dumps({"welcomeMessage": message}).encode("utf-8")
        await self._inner.send(
            "POST",
            "welcome-message",
            content=body,
            headers=[("Content-Type", _JSON_CONTENT_TYPE)],
        )

    # transactions -------------------------------------------------

    async def pending_transactions(self) -> list[TransactionInfo]:
        return _parse_pending_transactions(await self._inner.send_json("GET", "transactions"))

    async def pending_transaction(self, tx_hash: str) -> TransactionInfo:
        return TransactionInfo.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", f"transactions/{tx_hash}"),
                "/transactions/{hash}",
            )
        )

    async def rebroadcast_transaction(self, tx_hash: str) -> str:
        return _parse_tx_hash(await self._inner.send_json("POST", f"transactions/{tx_hash}"))

    async def cancel_transaction(self, tx_hash: str, gas_price: int | None = None) -> str:
        headers: list[tuple[str, str]] = []
        if gas_price is not None:
            headers.append(("gas-price", str(gas_price)))
        return _parse_tx_hash(
            await self._inner.send_json(
                "DELETE", f"transactions/{tx_hash}", headers=headers or None
            )
        )

    # loggers ------------------------------------------------------

    async def loggers(self) -> LoggerListing:
        return LoggerListing.from_dict(
            _expect_dict(await self._inner.send_json("GET", "loggers"), "/loggers")
        )

    async def loggers_by_expression(self, expression: str) -> LoggerListing:
        return LoggerListing.from_dict(
            _expect_dict(
                await self._inner.send_json("GET", f"loggers/{_b64(expression)}"),
                "/loggers/{expr}",
            )
        )

    async def set_logger_verbosity(self, expression: str) -> None:
        await self._inner.send("PUT", f"loggers/{_b64(expression)}")


# ---- Sync surface --------------------------------------------------------


class DebugApi:
    """Sync debug-domain handle. Reachable as :attr:`bee.Bee.debug`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _SyncInner) -> None:
        self._inner = inner

    def health(self) -> Health:
        return Health.from_dict(_expect_dict(self._inner.send_json("GET", "health"), "/health"))

    def versions(self) -> BeeVersions:
        h = self.health()
        return BeeVersions(
            bee_version=h.version,
            bee_api_version=h.api_version,
            supported_api_version=SUPPORTED_API_VERSION,
            supported_bee_version_exact=SUPPORTED_BEE_VERSION_EXACT,
        )

    def is_supported_api_version(self) -> bool:
        return self.health().api_version == SUPPORTED_API_VERSION

    def is_supported_exact_version(self) -> bool:
        return self.health().version == SUPPORTED_BEE_VERSION_EXACT

    def chain_state(self) -> ChainState:
        return ChainState.from_dict(
            _expect_dict(self._inner.send_json("GET", "chainstate"), "/chainstate")
        )

    def node_info(self) -> NodeInfo:
        return NodeInfo.from_dict(_expect_dict(self._inner.send_json("GET", "node"), "/node"))

    def status(self) -> Status:
        return Status.from_dict(_expect_dict(self._inner.send_json("GET", "status"), "/status"))

    def status_peers(self) -> list[PeerStatus]:
        return _parse_status_peers(self._inner.send_json("GET", "status/peers"))

    def status_neighborhoods(self) -> list[Neighborhood]:
        return _parse_neighborhoods(self._inner.send_json("GET", "status/neighborhoods"))

    def readiness(self) -> bool:
        try:
            self._inner.send("GET", "readiness")
        except BeeResponseError as e:
            if e.status in (404, 503):
                return False
            raise
        return True

    def is_gateway(self) -> bool:
        try:
            payload = self._inner.send_json("GET", "gateway")
        except BeeResponseError as e:
            if e.status == 404:
                return False
            raise
        return _parse_gateway(payload)

    def is_connected(self) -> bool:
        try:
            self._inner.send("GET", "")
        except Exception:
            return False
        return True

    def balances(self) -> list[Balance]:
        return _parse_balances_list(self._inner.send_json("GET", "balances"))

    def peer_balance(self, address: str) -> Balance:
        return Balance.from_dict(
            _expect_dict(self._inner.send_json("GET", f"balances/{address}"), "/balances/{addr}")
        )

    def consumed_balances(self) -> list[Balance]:
        return _parse_balances_list(self._inner.send_json("GET", "consumed"))

    def peer_consumed_balance(self, address: str) -> Balance:
        return Balance.from_dict(
            _expect_dict(self._inner.send_json("GET", f"consumed/{address}"), "/consumed/{addr}")
        )

    def accounting(self) -> dict[str, PeerAccounting]:
        return _parse_accounting_map(self._inner.send_json("GET", "accounting"))

    def stake(self) -> int:
        return _parse_bigint_field(self._inner.send_json("GET", "stake"), "stakedAmount", "/stake")

    def deposit_stake(self, amount: int) -> str:
        return _parse_stake_tx_hash(self._inner.send_json("POST", f"stake/{amount}"))

    def withdrawable_stake(self) -> int:
        return _parse_bigint_field(
            self._inner.send_json("GET", "stake/withdrawable"),
            "withdrawableAmount",
            "/stake/withdrawable",
        )

    def withdraw_surplus_stake(self) -> str:
        return _parse_stake_tx_hash(self._inner.send_json("DELETE", "stake/withdrawable"))

    def migrate_stake(self) -> str:
        return _parse_stake_tx_hash(self._inner.send_json("DELETE", "stake"))

    def redistribution_state(self) -> RedistributionState:
        return RedistributionState.from_dict(
            _expect_dict(
                self._inner.send_json("GET", "redistributionstate"), "/redistributionstate"
            )
        )

    def r_chash(self, depth: int, anchor1: str, anchor2: str) -> RCHashResponse:
        return RCHashResponse.from_dict(
            _expect_dict(
                self._inner.send_json("GET", f"rchash/{depth}/{anchor1}/{anchor2}"), "/rchash"
            )
        )

    def wallet(self) -> Wallet:
        return Wallet.from_dict(_expect_dict(self._inner.send_json("GET", "wallet"), "/wallet"))

    def withdraw_bzz(self, amount: int, address: str) -> str:
        return _parse_tx_hash(
            self._inner.send_json(
                "POST", "wallet/withdraw/bzz", params={"amount": str(amount), "address": address}
            )
        )

    def withdraw_native_token(self, amount: int, address: str) -> str:
        return _parse_tx_hash(
            self._inner.send_json(
                "POST",
                "wallet/withdraw/nativetoken",
                params={"amount": str(amount), "address": address},
            )
        )

    def chequebook_balance(self) -> ChequebookBalance:
        return ChequebookBalance.from_dict(
            _expect_dict(self._inner.send_json("GET", "chequebook/balance"), "/chequebook/balance")
        )

    def chequebook_deposit(self, amount: int) -> str:
        return _parse_tx_hash(
            self._inner.send_json("POST", "chequebook/deposit", params={"amount": str(amount)})
        )

    def chequebook_withdraw(self, amount: int) -> str:
        return _parse_tx_hash(
            self._inner.send_json("POST", "chequebook/withdraw", params={"amount": str(amount)})
        )

    def last_cheques(self) -> list[LastCheque]:
        return _parse_last_cheques(self._inner.send_json("GET", "chequebook/cheque"))

    def peer_cheques(self, peer: str) -> PeerCheques:
        return PeerCheques.from_dict(
            _expect_dict(
                self._inner.send_json("GET", f"chequebook/cheque/{peer}"),
                "/chequebook/cheque/{peer}",
            )
        )

    def last_cashout_action(self, peer: str) -> LastCashoutAction:
        return LastCashoutAction.from_dict(
            _expect_dict(
                self._inner.send_json("GET", f"chequebook/cashout/{peer}"),
                "/chequebook/cashout/{peer}",
            )
        )

    def cashout_last_cheque(self, peer: str, gas_price: int | None = None) -> str:
        headers: list[tuple[str, str]] = []
        if gas_price is not None:
            headers.append(("gas-price", str(gas_price)))
        return _parse_tx_hash(
            self._inner.send_json("POST", f"chequebook/cashout/{peer}", headers=headers or None)
        )

    def settlements(self) -> Settlements:
        return Settlements.from_dict(
            _expect_dict(self._inner.send_json("GET", "settlements"), "/settlements")
        )

    def peer_settlement(self, peer: str) -> Settlement:
        return Settlement.from_dict(
            _expect_dict(self._inner.send_json("GET", f"settlements/{peer}"), "/settlements/{peer}")
        )

    def time_settlements(self) -> Settlements:
        return Settlements.from_dict(
            _expect_dict(self._inner.send_json("GET", "timesettlements"), "/timesettlements")
        )

    def peers(self) -> list[Peer]:
        return _parse_peer_list(self._inner.send_json("GET", "peers"), "/peers")

    def blocklist(self) -> list[Peer]:
        return _parse_peer_list(self._inner.send_json("GET", "blocklist"), "/blocklist")

    def remove_peer(self, address: str) -> None:
        self._inner.send("DELETE", f"peers/{address}")

    def ping_peer(self, address: str) -> str:
        return _parse_rtt(self._inner.send_json("POST", f"pingpong/{address}"))

    def connect_peer(self, multiaddr: str) -> str:
        return _parse_overlay_address(
            self._inner.send_json("POST", f"connect/{multiaddr.lstrip('/')}")
        )

    def addresses(self) -> Addresses:
        return Addresses.from_dict(
            _expect_dict(self._inner.send_json("GET", "addresses"), "/addresses")
        )

    def topology(self) -> Topology:
        return Topology.from_dict(
            _expect_dict(self._inner.send_json("GET", "topology"), "/topology")
        )

    def reserve_state(self) -> ReserveState:
        return ReserveState.from_dict(
            _expect_dict(self._inner.send_json("GET", "reservestate"), "/reservestate")
        )

    def welcome_message(self) -> str:
        return _parse_welcome_message(self._inner.send_json("GET", "welcome-message"))

    def set_welcome_message(self, message: str) -> None:
        body = json.dumps({"welcomeMessage": message}).encode("utf-8")
        self._inner.send(
            "POST",
            "welcome-message",
            content=body,
            headers=[("Content-Type", _JSON_CONTENT_TYPE)],
        )

    def pending_transactions(self) -> list[TransactionInfo]:
        return _parse_pending_transactions(self._inner.send_json("GET", "transactions"))

    def pending_transaction(self, tx_hash: str) -> TransactionInfo:
        return TransactionInfo.from_dict(
            _expect_dict(
                self._inner.send_json("GET", f"transactions/{tx_hash}"), "/transactions/{hash}"
            )
        )

    def rebroadcast_transaction(self, tx_hash: str) -> str:
        return _parse_tx_hash(self._inner.send_json("POST", f"transactions/{tx_hash}"))

    def cancel_transaction(self, tx_hash: str, gas_price: int | None = None) -> str:
        headers: list[tuple[str, str]] = []
        if gas_price is not None:
            headers.append(("gas-price", str(gas_price)))
        return _parse_tx_hash(
            self._inner.send_json("DELETE", f"transactions/{tx_hash}", headers=headers or None)
        )

    def loggers(self) -> LoggerListing:
        return LoggerListing.from_dict(
            _expect_dict(self._inner.send_json("GET", "loggers"), "/loggers")
        )

    def loggers_by_expression(self, expression: str) -> LoggerListing:
        return LoggerListing.from_dict(
            _expect_dict(
                self._inner.send_json("GET", f"loggers/{_b64(expression)}"),
                "/loggers/{expr}",
            )
        )

    def set_logger_verbosity(self, expression: str) -> None:
        self._inner.send("PUT", f"loggers/{_b64(expression)}")


__all__ = [
    "SUPPORTED_API_VERSION",
    "SUPPORTED_BEE_VERSION_EXACT",
    "Addresses",
    "AsyncDebugApi",
    "Balance",
    "BeeVersions",
    "BinInfo",
    "CashoutResult",
    "ChainState",
    "Cheque",
    "ChequebookBalance",
    "ChunkInclusionProof",
    "ChunkInclusionProofs",
    "DebugApi",
    "Health",
    "LastCashoutAction",
    "LastCheque",
    "Logger",
    "LoggerListing",
    "MetricSnapshotView",
    "Neighborhood",
    "NodeInfo",
    "Peer",
    "PeerAccounting",
    "PeerCheques",
    "PeerInfo",
    "PeerStatus",
    "PostageProof",
    "RCHashResponse",
    "RedistributionState",
    "ReserveState",
    "Settlement",
    "Settlements",
    "SocProof",
    "Status",
    "Topology",
    "TransactionInfo",
    "Wallet",
]
