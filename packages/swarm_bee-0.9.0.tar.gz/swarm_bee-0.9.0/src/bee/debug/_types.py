"""Dataclasses for the debug-domain endpoints.

Mirrors the response shapes in ``pkg/debug`` (bee-go) and ``debug``
(bee-rs). All ``BigInt`` fields land as Python ``int`` (arbitrary
precision); empty strings on the wire decode as ``None`` for optional
fields and ``0`` for required ones.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..swarm.errors import BeeJsonError


def _opt_bigint(value: object) -> int | None:
    """Decode Bee's bigint-as-string fields. Empty / missing → ``None``."""
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        if not value:
            return None
        try:
            return int(value, 10)
        except ValueError as e:
            raise BeeJsonError(f"invalid bigint string: {value!r}") from e
    raise BeeJsonError(f"unexpected bigint shape: {value!r}")


def _bigint(value: object) -> int:
    """Same as :func:`_opt_bigint` but returns ``0`` for empty input."""
    return _opt_bigint(value) or 0


# ---- node / chainstate ---------------------------------------------------


@dataclass(frozen=True, slots=True)
class Health:
    """``GET /health`` response."""

    status: str
    version: str
    api_version: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Health:
        try:
            return cls(
                status=d["status"], version=d["version"], api_version=d["apiVersion"]
            )
        except KeyError as e:
            raise BeeJsonError(f"missing field in /health response: {e}") from e


@dataclass(frozen=True, slots=True)
class BeeVersions:
    """Structured version triple derived from ``/health``."""

    bee_version: str
    bee_api_version: str
    supported_api_version: str
    supported_bee_version_exact: str


@dataclass(frozen=True, slots=True)
class ChainState:
    """``GET /chainstate``. ``current_price`` and ``total_amount`` are
    bigints (PLUR)."""

    block: int
    chain_tip: int
    current_price: int
    total_amount: int

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ChainState:
        return cls(
            block=int(d.get("block", 0)),
            chain_tip=int(d.get("chainTip", 0)),
            current_price=_bigint(d.get("currentPrice", "")),
            total_amount=_bigint(d.get("totalAmount", "")),
        )


@dataclass(frozen=True, slots=True)
class NodeInfo:
    """``GET /node`` — operator-mode flags."""

    bee_mode: str
    chequebook_enabled: bool
    swap_enabled: bool

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> NodeInfo:
        return cls(
            bee_mode=str(d.get("beeMode", "")),
            chequebook_enabled=bool(d.get("chequebookEnabled", False)),
            swap_enabled=bool(d.get("swapEnabled", False)),
        )


@dataclass(frozen=True, slots=True)
class Status:
    """``GET /status`` — operational snapshot."""

    overlay: str = ""
    proximity: int = 0
    bee_mode: str = ""
    reserve_size: int = 0
    reserve_size_within_radius: int = 0
    pullsync_rate: float = 0.0
    storage_radius: int = 0
    connected_peers: int = 0
    neighborhood_size: int = 0
    batch_commitment: int = 0
    is_reachable: bool = False
    last_synced_block: int = 0
    committed_depth: int = 0
    is_warming_up: bool = False

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Status:
        return cls(
            overlay=str(d.get("overlay", "")),
            proximity=int(d.get("proximity", 0)),
            bee_mode=str(d.get("beeMode", "")),
            reserve_size=int(d.get("reserveSize", 0)),
            reserve_size_within_radius=int(d.get("reserveSizeWithinRadius", 0)),
            pullsync_rate=float(d.get("pullsyncRate", 0.0)),
            storage_radius=int(d.get("storageRadius", 0)),
            connected_peers=int(d.get("connectedPeers", 0)),
            neighborhood_size=int(d.get("neighborhoodSize", 0)),
            batch_commitment=int(d.get("batchCommitment", 0)),
            is_reachable=bool(d.get("isReachable", False)),
            last_synced_block=int(d.get("lastSyncedBlock", 0)),
            committed_depth=int(d.get("committedDepth", 0)),
            is_warming_up=bool(d.get("isWarmingUp", False)),
        )


@dataclass(frozen=True, slots=True)
class PeerStatus:
    """One row of ``GET /status/peers``."""

    status: Status
    request_failed: bool = False

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PeerStatus:
        return cls(
            status=Status.from_dict(d),
            request_failed=bool(d.get("requestFailed", False)),
        )


@dataclass(frozen=True, slots=True)
class Neighborhood:
    """One row of ``GET /status/neighborhoods``."""

    neighborhood: str
    reserve_size_within_radius: int
    proximity: int

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Neighborhood:
        return cls(
            neighborhood=str(d.get("neighborhood", "")),
            reserve_size_within_radius=int(d.get("reserveSizeWithinRadius", 0)),
            proximity=int(d.get("proximity", 0)),
        )


# ---- accounting + stake --------------------------------------------------


@dataclass(frozen=True, slots=True)
class Balance:
    """One settlement balance row from ``/balances`` or ``/consumed``."""

    peer: str
    balance: int

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Balance:
        return cls(
            peer=str(d.get("peer", "")),
            balance=_bigint(d.get("balance", "")),
        )


@dataclass(frozen=True, slots=True)
class PeerAccounting:
    """One row of the ``/accounting`` snapshot. All monetary fields are
    PLUR; ``None`` means Bee omitted the field for this peer.
    """

    balance: int | None = None
    consumed_balance: int | None = None
    threshold_received: int | None = None
    threshold_given: int | None = None
    current_threshold_received: int | None = None
    current_threshold_given: int | None = None
    surplus_balance: int | None = None
    reserved_balance: int | None = None
    shadow_reserved_balance: int | None = None
    ghost_balance: int | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PeerAccounting:
        return cls(
            balance=_opt_bigint(d.get("balance")),
            consumed_balance=_opt_bigint(d.get("consumedBalance")),
            threshold_received=_opt_bigint(d.get("thresholdReceived")),
            threshold_given=_opt_bigint(d.get("thresholdGiven")),
            current_threshold_received=_opt_bigint(d.get("currentThresholdReceived")),
            current_threshold_given=_opt_bigint(d.get("currentThresholdGiven")),
            surplus_balance=_opt_bigint(d.get("surplusBalance")),
            reserved_balance=_opt_bigint(d.get("reservedBalance")),
            shadow_reserved_balance=_opt_bigint(d.get("shadowReservedBalance")),
            ghost_balance=_opt_bigint(d.get("ghostBalance")),
        )


@dataclass(frozen=True, slots=True)
class RedistributionState:
    """``GET /redistributionstate``."""

    minimum_gas_funds: int | None = None
    has_sufficient_funds: bool = False
    is_frozen: bool = False
    is_fully_synced: bool = False
    phase: str = ""
    round: int = 0
    last_won_round: int = 0
    last_played_round: int = 0
    last_frozen_round: int = 0
    last_selected_round: int = 0
    last_sample_duration_seconds: float = 0.0
    block: int = 0
    reward: int | None = None
    fees: int | None = None
    is_healthy: bool = False

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> RedistributionState:
        return cls(
            minimum_gas_funds=_opt_bigint(d.get("minimumGasFunds")),
            has_sufficient_funds=bool(d.get("hasSufficientFunds", False)),
            is_frozen=bool(d.get("isFrozen", False)),
            is_fully_synced=bool(d.get("isFullySynced", False)),
            phase=str(d.get("phase", "")),
            round=int(d.get("round", 0)),
            last_won_round=int(d.get("lastWonRound", 0)),
            last_played_round=int(d.get("lastPlayedRound", 0)),
            last_frozen_round=int(d.get("lastFrozenRound", 0)),
            last_selected_round=int(d.get("lastSelectedRound", 0)),
            last_sample_duration_seconds=float(d.get("lastSampleDurationSeconds", 0.0)),
            block=int(d.get("block", 0)),
            reward=_opt_bigint(d.get("reward")),
            fees=_opt_bigint(d.get("fees")),
            is_healthy=bool(d.get("isHealthy", False)),
        )


@dataclass(frozen=True, slots=True)
class PostageProof:
    index: str = ""
    postage_id: str = ""
    signature: str = ""
    time_stamp: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PostageProof:
        return cls(
            index=str(d.get("index", "")),
            postage_id=str(d.get("postageId", "")),
            signature=str(d.get("signature", "")),
            time_stamp=str(d.get("timeStamp", "")),
        )


@dataclass(frozen=True, slots=True)
class SocProof:
    chunk_addr: str = ""
    identifier: str = ""
    signature: str = ""
    signer: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> SocProof:
        return cls(
            chunk_addr=str(d.get("chunkAddr", "")),
            identifier=str(d.get("identifier", "")),
            signature=str(d.get("signature", "")),
            signer=str(d.get("signer", "")),
        )


@dataclass(frozen=True, slots=True)
class ChunkInclusionProof:
    chunk_span: int = 0
    postage_proof: PostageProof = field(default_factory=PostageProof)
    proof_segments: list[str] | None = None
    proof_segments2: list[str] | None = None
    proof_segments3: list[str] | None = None
    prove_segment: str = ""
    prove_segment2: str = ""
    soc_proof: list[SocProof] | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ChunkInclusionProof:
        ps = d.get("proofSegments")
        ps2 = d.get("proofSegments2")
        ps3 = d.get("proofSegments3")
        soc = d.get("socProof")
        return cls(
            chunk_span=int(d.get("chunkSpan", 0)),
            postage_proof=PostageProof.from_dict(d.get("postageProof") or {}),
            proof_segments=[str(s) for s in ps] if isinstance(ps, list) else None,
            proof_segments2=[str(s) for s in ps2] if isinstance(ps2, list) else None,
            proof_segments3=[str(s) for s in ps3] if isinstance(ps3, list) else None,
            prove_segment=str(d.get("proveSegment", "")),
            prove_segment2=str(d.get("proveSegment2", "")),
            soc_proof=[SocProof.from_dict(s) for s in soc] if isinstance(soc, list) else None,
        )


@dataclass(frozen=True, slots=True)
class ChunkInclusionProofs:
    proof1: ChunkInclusionProof = field(default_factory=ChunkInclusionProof)
    proof2: ChunkInclusionProof = field(default_factory=ChunkInclusionProof)
    proof_last: ChunkInclusionProof = field(default_factory=ChunkInclusionProof)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ChunkInclusionProofs:
        return cls(
            proof1=ChunkInclusionProof.from_dict(d.get("proof1") or {}),
            proof2=ChunkInclusionProof.from_dict(d.get("proof2") or {}),
            proof_last=ChunkInclusionProof.from_dict(d.get("proofLast") or {}),
        )


@dataclass(frozen=True, slots=True)
class RCHashResponse:
    """``GET /rchash/{depth}/{anchor1}/{anchor2}``."""

    duration_seconds: float = 0.0
    hash: str = ""
    proofs: ChunkInclusionProofs = field(default_factory=ChunkInclusionProofs)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> RCHashResponse:
        return cls(
            duration_seconds=float(d.get("durationSeconds", 0.0)),
            hash=str(d.get("hash", "")),
            proofs=ChunkInclusionProofs.from_dict(d.get("proofs") or {}),
        )


# ---- chequebook + settlements + wallet ----------------------------------


@dataclass(frozen=True, slots=True)
class Wallet:
    """``GET /wallet``. Bee 2.7.2 dropped ``bzzAddress`` /
    ``nativeAddress`` and renamed ``chequebook`` →
    ``chequebookContractAddress``; we accept both spellings.
    """

    bzz_address: str | None = None
    native_address: str | None = None
    chequebook_contract_address: str | None = None
    bzz_balance: int | None = None
    native_token_balance: int | None = None
    chain_id: int = 0
    wallet_address: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Wallet:
        return cls(
            bzz_address=d.get("bzzAddress"),
            native_address=d.get("nativeAddress"),
            chequebook_contract_address=(
                d.get("chequebookContractAddress") or d.get("chequebook")
            ),
            bzz_balance=_opt_bigint(d.get("bzzBalance")),
            native_token_balance=_opt_bigint(d.get("nativeTokenBalance")),
            chain_id=int(d.get("chainID", 0)),
            wallet_address=str(d.get("walletAddress", "")),
        )


@dataclass(frozen=True, slots=True)
class ChequebookBalance:
    total_balance: int
    available_balance: int

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ChequebookBalance:
        return cls(
            total_balance=_bigint(d.get("totalBalance", "")),
            available_balance=_bigint(d.get("availableBalance", "")),
        )


@dataclass(frozen=True, slots=True)
class Settlement:
    peer: str
    received: int | None = None
    sent: int | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Settlement:
        return cls(
            peer=str(d.get("peer", "")),
            received=_opt_bigint(d.get("received")),
            sent=_opt_bigint(d.get("sent")),
        )


@dataclass(frozen=True, slots=True)
class Settlements:
    total_received: int | None = None
    total_sent: int | None = None
    settlements: list[Settlement] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Settlements:
        items = d.get("settlements") or []
        return cls(
            total_received=_opt_bigint(d.get("totalReceived")),
            total_sent=_opt_bigint(d.get("totalSent")),
            settlements=[Settlement.from_dict(s) for s in items],
        )


@dataclass(frozen=True, slots=True)
class Cheque:
    beneficiary: str
    chequebook: str
    payout: int | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Cheque:
        return cls(
            beneficiary=str(d.get("beneficiary", "")),
            chequebook=str(d.get("chequebook", "")),
            payout=_opt_bigint(d.get("payout")),
        )


@dataclass(frozen=True, slots=True)
class LastCheque:
    peer: str
    last_received: Cheque | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> LastCheque:
        lr = d.get("lastreceived")
        return cls(
            peer=str(d.get("peer", "")),
            last_received=Cheque.from_dict(lr) if isinstance(lr, dict) else None,
        )


@dataclass(frozen=True, slots=True)
class PeerCheques:
    peer: str
    last_received: Cheque | None = None
    last_sent: Cheque | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PeerCheques:
        lr = d.get("lastreceived")
        ls = d.get("lastsent")
        return cls(
            peer=str(d.get("peer", "")),
            last_received=Cheque.from_dict(lr) if isinstance(lr, dict) else None,
            last_sent=Cheque.from_dict(ls) if isinstance(ls, dict) else None,
        )


@dataclass(frozen=True, slots=True)
class CashoutResult:
    recipient: str
    last_payout: int | None = None
    bounced: bool = False

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> CashoutResult:
        return cls(
            recipient=str(d.get("recipient", "")),
            last_payout=_opt_bigint(d.get("lastPayout")),
            bounced=bool(d.get("bounced", False)),
        )


@dataclass(frozen=True, slots=True)
class LastCashoutAction:
    peer: str
    uncashed_amount: int | None = None
    transaction_hash: str | None = None
    last_cashed_cheque: Cheque | None = None
    result: CashoutResult | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> LastCashoutAction:
        cheque = d.get("lastCashedCheque")
        result = d.get("result")
        return cls(
            peer=str(d.get("peer", "")),
            uncashed_amount=_opt_bigint(d.get("uncashedAmount")),
            transaction_hash=d.get("transactionHash"),
            last_cashed_cheque=Cheque.from_dict(cheque) if isinstance(cheque, dict) else None,
            result=CashoutResult.from_dict(result) if isinstance(result, dict) else None,
        )


# ---- peers / topology ----------------------------------------------------


@dataclass(frozen=True, slots=True)
class Peer:
    address: str
    full_node: bool = False

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Peer:
        return cls(
            address=str(d.get("address", "")),
            full_node=bool(d.get("fullNode", False)),
        )


@dataclass(frozen=True, slots=True)
class Addresses:
    overlay: str
    underlay: list[str]
    ethereum: str
    public_key: str
    pss_public_key: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Addresses:
        underlay = d.get("underlay") or []
        return cls(
            overlay=str(d.get("overlay", "")),
            underlay=[str(u) for u in underlay] if isinstance(underlay, list) else [],
            ethereum=str(d.get("ethereum", "")),
            public_key=str(d.get("publicKey", "")),
            pss_public_key=str(d.get("pssPublicKey", "")),
        )


@dataclass(frozen=True, slots=True)
class MetricSnapshotView:
    last_seen_timestamp: int = 0
    session_connection_retry: int = 0
    connection_total_duration: float = 0.0
    session_connection_duration: float = 0.0
    session_connection_direction: str = ""
    latency_ewma: int = 0
    reachability: str = ""
    healthy: bool = False

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MetricSnapshotView:
        return cls(
            last_seen_timestamp=int(d.get("lastSeenTimestamp", 0)),
            session_connection_retry=int(d.get("sessionConnectionRetry", 0)),
            connection_total_duration=float(d.get("connectionTotalDuration", 0.0)),
            session_connection_duration=float(d.get("sessionConnectionDuration", 0.0)),
            session_connection_direction=str(d.get("sessionConnectionDirection", "")),
            latency_ewma=int(d.get("latencyEWMA", 0)),
            reachability=str(d.get("reachability", "")),
            healthy=bool(d.get("healthy", False)),
        )


@dataclass(frozen=True, slots=True)
class PeerInfo:
    address: str = ""
    metrics: MetricSnapshotView | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PeerInfo:
        m = d.get("metrics")
        return cls(
            address=str(d.get("address", "")),
            metrics=MetricSnapshotView.from_dict(m) if isinstance(m, dict) else None,
        )


@dataclass(frozen=True, slots=True)
class BinInfo:
    population: int = 0
    connected: int = 0
    connected_peers: list[PeerInfo] = field(default_factory=list)
    disconnected_peers: list[PeerInfo] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> BinInfo:
        cp = d.get("connectedPeers") or []
        dp = d.get("disconnectedPeers") or []
        return cls(
            population=int(d.get("population", 0)),
            connected=int(d.get("connected", 0)),
            connected_peers=[PeerInfo.from_dict(p) for p in cp] if isinstance(cp, list) else [],
            disconnected_peers=[PeerInfo.from_dict(p) for p in dp] if isinstance(dp, list) else [],
        )


@dataclass(frozen=True, slots=True)
class Topology:
    """``GET /topology``. The 32 per-bin keys ``bin_0..bin_31`` are
    collapsed into the indexable :attr:`bins` list.
    """

    base_addr: str = ""
    population: int = 0
    connected: int = 0
    timestamp: str = ""
    nn_low_watermark: int = 0
    depth: int = 0
    reachability: str = ""
    network_availability: str = ""
    bins: list[BinInfo] = field(default_factory=list)
    light_nodes: BinInfo = field(default_factory=BinInfo)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Topology:
        bins = [BinInfo.from_dict(d.get(f"bin_{i}") or {}) for i in range(32)]
        light = d.get("lightNodes") or {}
        return cls(
            base_addr=str(d.get("baseAddr", "")),
            population=int(d.get("population", 0)),
            connected=int(d.get("connected", 0)),
            timestamp=str(d.get("timestamp", "")),
            nn_low_watermark=int(d.get("nnLowWatermark", 0)),
            depth=int(d.get("depth", 0)),
            reachability=str(d.get("reachability", "")),
            network_availability=str(d.get("networkAvailability", "")),
            bins=bins,
            light_nodes=BinInfo.from_dict(light) if isinstance(light, dict) else BinInfo(),
        )


@dataclass(frozen=True, slots=True)
class ReserveState:
    radius: int
    storage_radius: int
    commitment: int

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ReserveState:
        return cls(
            radius=int(d.get("radius", 0)),
            storage_radius=int(d.get("storageRadius", 0)),
            commitment=int(d.get("commitment", 0)),
        )


# ---- transactions --------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TransactionInfo:
    """One pending transaction Bee tracks."""

    transaction_hash: str
    to: str
    nonce: int
    gas_price: int | None = None
    gas_limit: int = 0
    gas_tip_boost: int = 0
    gas_tip_cap: int | None = None
    gas_fee_cap: int | None = None
    data: str = ""
    created: str = ""
    description: str = ""
    value: int | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TransactionInfo:
        return cls(
            transaction_hash=str(d.get("transactionHash", "")),
            to=str(d.get("to", "")),
            nonce=int(d.get("nonce", 0)),
            gas_price=_opt_bigint(d.get("gasPrice")),
            gas_limit=int(d.get("gasLimit", 0)),
            gas_tip_boost=int(d.get("gasTipBoost", 0)),
            gas_tip_cap=_opt_bigint(d.get("gasTipCap")),
            gas_fee_cap=_opt_bigint(d.get("gasFeeCap")),
            data=str(d.get("data", "")),
            created=str(d.get("created", "")),
            description=str(d.get("description", "")),
            value=_opt_bigint(d.get("value")),
        )


# ---- loggers -------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Logger:
    logger: str
    verbosity: str
    subsystem: str
    id: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Logger:
        return cls(
            logger=str(d.get("logger", "")),
            verbosity=str(d.get("verbosity", "")),
            subsystem=str(d.get("subsystem", "")),
            id=str(d.get("id", "")),
        )


@dataclass(frozen=True, slots=True)
class LoggerListing:
    """``GET /loggers``. ``tree`` is the recursive logger tree as raw
    JSON (rarely needed); ``loggers`` is the flat list.
    """

    loggers: list[Logger] = field(default_factory=list)
    tree: Any = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> LoggerListing:
        items = d.get("loggers") or []
        return cls(
            loggers=[Logger.from_dict(i) for i in items] if isinstance(items, list) else [],
            tree=d.get("tree"),
        )


__all__ = [
    "Addresses",
    "Balance",
    "BeeVersions",
    "BinInfo",
    "CashoutResult",
    "ChainState",
    "Cheque",
    "ChequebookBalance",
    "ChunkInclusionProof",
    "ChunkInclusionProofs",
    "Health",
    "LastCashoutAction",
    "LastCheque",
    "Logger",
    "LoggerListing",
    "MetricSnapshotView",
    "Neighborhood",
    "NodeInfo",
    "Peer",
    "PeerAccounting",
    "PeerCheques",
    "PeerInfo",
    "PeerStatus",
    "PostageProof",
    "RCHashResponse",
    "RedistributionState",
    "ReserveState",
    "Settlement",
    "Settlements",
    "SocProof",
    "Status",
    "Topology",
    "TransactionInfo",
    "Wallet",
]
