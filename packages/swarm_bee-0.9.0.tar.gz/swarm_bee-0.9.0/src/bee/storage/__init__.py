"""High-level storage helpers built on top of the Bee client.

Mirrors bee-rs ``storage`` and bee-js ``client.buyStorage`` /
``client.getStorageCost``. Wraps the postage-batch lifecycle so callers
can think in terms of ``(size, duration)`` rather than
``(amount, depth)``. The math comes from :mod:`bee.postage.stamp_math`
and :class:`bee.swarm.Network` (block time).

All helpers are free functions that take an :class:`AsyncBee` or
:class:`Bee` client. Async and sync variants are paired
1-to-1 — pick whichever matches your client.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..postage.stamp_math import get_depth_for_size, get_stamp_cost
from ..swarm.duration import Duration
from ..swarm.errors import BeeArgumentError
from ..swarm.network import Network
from ..swarm.size import Size
from ..swarm.typed_bytes import BatchId

if TYPE_CHECKING:
    from .. import AsyncBee, Bee


@dataclass(frozen=True, slots=True)
class StorageOptions:
    """Options for :func:`buy_storage` / :func:`buy_storage_sync`.

    ``network`` shapes the per-block amount math; ``label`` is the
    optional batch label; ``immutable`` selects an immutable batch
    (``None`` keeps Bee's default).
    """

    network: Network = Network.GNOSIS
    label: str | None = None
    immutable: bool | None = None


@dataclass(frozen=True, slots=True)
class StorageCost:
    """Storage-cost preview returned by :func:`get_storage_cost`."""

    #: Stamp depth that covers ``size``.
    depth: int
    #: Per-block amount (PLUR) needed for ``duration``.
    amount_per_chunk: int
    #: Total cost: ``2^depth * amount_per_chunk`` (PLUR).
    total_cost: int
    #: Duration in blocks (``ceil(duration / network.block_time)``).
    blocks: int


def _depth_or_raise(num_bytes: int) -> int:
    depth = get_depth_for_size(num_bytes)
    if depth < 0 or depth > 0xFF:
        raise BeeArgumentError(f"computed depth {depth} out of u8 range")
    return depth


def _cost_for(blocks: int, current_price: int, depth: int) -> tuple[int, int]:
    """Return ``(amount_per_chunk, total_cost)`` for the given inputs."""
    amount_per_chunk = current_price * blocks
    total_cost = get_stamp_cost(depth, amount_per_chunk)
    return amount_per_chunk, total_cost


# ---- Async ---------------------------------------------------------------


async def get_storage_cost(
    client: AsyncBee,
    size: Size,
    duration: Duration,
    network: Network = Network.GNOSIS,
) -> StorageCost:
    """Compute the depth + amount for a ``(size, duration)`` tuple.

    Uses the chain's current ``current_price`` (PLUR / chunk / block)
    as the per-block price floor. Pure preview — no postage batch is
    purchased.
    """
    chain = await client.debug.chain_state()
    blocks = network.seconds_to_blocks(duration.to_seconds())
    depth = _depth_or_raise(size.to_bytes())
    amount_per_chunk, total_cost = _cost_for(blocks, chain.current_price, depth)
    return StorageCost(
        depth=depth,
        amount_per_chunk=amount_per_chunk,
        total_cost=total_cost,
        blocks=blocks,
    )


async def buy_storage(
    client: AsyncBee,
    size: Size,
    duration: Duration,
    opts: StorageOptions | None = None,
) -> BatchId:
    """Preview + buy in one call.

    Computes the cost via :func:`get_storage_cost` and forwards to
    :meth:`AsyncPostageApi.create_postage_batch`. Returns the
    freshly-minted :class:`BatchId`.
    """
    o = opts or StorageOptions()
    cost = await get_storage_cost(client, size, duration, o.network)
    return await client.postage.create_postage_batch(
        cost.amount_per_chunk, cost.depth, label=o.label
    )


async def extend_storage_duration(
    client: AsyncBee,
    batch_id: BatchId,
    duration: Duration,
    network: Network = Network.GNOSIS,
) -> None:
    """Top up an existing batch by ``current_price * blocks(duration)``."""
    chain = await client.debug.chain_state()
    blocks = network.seconds_to_blocks(duration.to_seconds())
    amount = chain.current_price * blocks
    await client.postage.top_up_batch(batch_id, amount)


async def extend_storage_size(
    client: AsyncBee, batch_id: BatchId, new_size: Size
) -> None:
    """Dilute the batch so its effective capacity covers ``new_size``.

    No-op if the batch is already deep enough.
    """
    batch = await client.postage.get_postage_batch(batch_id)
    target = _depth_or_raise(new_size.to_bytes())
    if target <= batch.depth:
        return
    await client.postage.dilute_batch(batch_id, target)


async def get_duration_extension_cost(
    client: AsyncBee,
    batch_id: BatchId,
    duration: Duration,
    network: Network = Network.GNOSIS,
) -> int:
    """Total cost (PLUR) to extend a batch by ``duration``.

    ``current_price * blocks(duration) * 2^current_depth``.
    """
    batch = await client.postage.get_postage_batch(batch_id)
    chain = await client.debug.chain_state()
    blocks = network.seconds_to_blocks(duration.to_seconds())
    amount_per_chunk = chain.current_price * blocks
    return get_stamp_cost(batch.depth, amount_per_chunk)


async def get_size_extension_cost(
    client: AsyncBee, batch_id: BatchId, new_size: Size
) -> int:
    """Cost (PLUR) to grow a batch's effective capacity to ``new_size``.

    Returns ``0`` if the batch is already deep enough. The dilution
    cost is ``(2^new_depth - 2^old_depth) * batch.amount``.
    """
    batch = await client.postage.get_postage_batch(batch_id)
    target = _depth_or_raise(new_size.to_bytes())
    if target <= batch.depth:
        return 0
    if batch.amount is None:
        raise BeeArgumentError("batch missing amount")
    return ((1 << target) - (1 << batch.depth)) * batch.amount


async def calculate_top_up_for_bzz(
    client: AsyncBee, batch_id: BatchId, target_bzz: int
) -> int:
    """Top-up amount (PLUR) needed for the batch to reach
    ``target_bzz`` total spend.

    Returns ``0`` if the batch already exceeds the target.
    """
    batch = await client.postage.get_postage_batch(batch_id)
    if batch.amount is None:
        raise BeeArgumentError("batch missing amount")
    if target_bzz <= batch.amount:
        return 0
    return target_bzz - batch.amount


# ---- Sync ----------------------------------------------------------------


def get_storage_cost_sync(
    client: Bee,
    size: Size,
    duration: Duration,
    network: Network = Network.GNOSIS,
) -> StorageCost:
    """Synchronous version of :func:`get_storage_cost`."""
    chain = client.debug.chain_state()
    blocks = network.seconds_to_blocks(duration.to_seconds())
    depth = _depth_or_raise(size.to_bytes())
    amount_per_chunk, total_cost = _cost_for(blocks, chain.current_price, depth)
    return StorageCost(
        depth=depth,
        amount_per_chunk=amount_per_chunk,
        total_cost=total_cost,
        blocks=blocks,
    )


def buy_storage_sync(
    client: Bee,
    size: Size,
    duration: Duration,
    opts: StorageOptions | None = None,
) -> BatchId:
    """Synchronous version of :func:`buy_storage`."""
    o = opts or StorageOptions()
    cost = get_storage_cost_sync(client, size, duration, o.network)
    return client.postage.create_postage_batch(
        cost.amount_per_chunk, cost.depth, label=o.label
    )


def extend_storage_duration_sync(
    client: Bee,
    batch_id: BatchId,
    duration: Duration,
    network: Network = Network.GNOSIS,
) -> None:
    chain = client.debug.chain_state()
    blocks = network.seconds_to_blocks(duration.to_seconds())
    amount = chain.current_price * blocks
    client.postage.top_up_batch(batch_id, amount)


def extend_storage_size_sync(
    client: Bee, batch_id: BatchId, new_size: Size
) -> None:
    batch = client.postage.get_postage_batch(batch_id)
    target = _depth_or_raise(new_size.to_bytes())
    if target <= batch.depth:
        return
    client.postage.dilute_batch(batch_id, target)


def get_duration_extension_cost_sync(
    client: Bee,
    batch_id: BatchId,
    duration: Duration,
    network: Network = Network.GNOSIS,
) -> int:
    batch = client.postage.get_postage_batch(batch_id)
    chain = client.debug.chain_state()
    blocks = network.seconds_to_blocks(duration.to_seconds())
    amount_per_chunk = chain.current_price * blocks
    return get_stamp_cost(batch.depth, amount_per_chunk)


def get_size_extension_cost_sync(
    client: Bee, batch_id: BatchId, new_size: Size
) -> int:
    batch = client.postage.get_postage_batch(batch_id)
    target = _depth_or_raise(new_size.to_bytes())
    if target <= batch.depth:
        return 0
    if batch.amount is None:
        raise BeeArgumentError("batch missing amount")
    return ((1 << target) - (1 << batch.depth)) * batch.amount


def calculate_top_up_for_bzz_sync(
    client: Bee, batch_id: BatchId, target_bzz: int
) -> int:
    batch = client.postage.get_postage_batch(batch_id)
    if batch.amount is None:
        raise BeeArgumentError("batch missing amount")
    if target_bzz <= batch.amount:
        return 0
    return target_bzz - batch.amount


__all__ = [
    "StorageCost",
    "StorageOptions",
    "buy_storage",
    "buy_storage_sync",
    "calculate_top_up_for_bzz",
    "calculate_top_up_for_bzz_sync",
    "extend_storage_duration",
    "extend_storage_duration_sync",
    "extend_storage_size",
    "extend_storage_size_sync",
    "get_duration_extension_cost",
    "get_duration_extension_cost_sync",
    "get_size_extension_cost",
    "get_size_extension_cost_sync",
    "get_storage_cost",
    "get_storage_cost_sync",
]
