"""GSOC send / subscribe surface.

Mirrors bee-rs ``gsoc`` and bee-go ``pkg/gsoc``. GSOC chunks are SOCs
whose ``(identifier, owner)`` pair has been mined to land in a target
neighbourhood. The target subscribes to
``/gsoc/subscribe/{soc_address}``.

See :func:`bee.swarm.gsoc.gsoc_mine` to derive a signer with the
desired proximity.
"""

from __future__ import annotations

from .._inner import _AsyncInner, _decode_json, _SyncInner
from .._ws import AsyncSubscription
from ..api.options import UploadOptions, prepare_upload_headers
from ..api.result import UploadResult
from ..swarm.errors import BeeJsonError
from ..swarm.keys import PrivateKey
from ..swarm.soc import (
    calculate_single_owner_chunk_address,
    make_single_owner_chunk,
)
from ..swarm.typed_bytes import (
    BatchId,
    EthAddress,
    Identifier,
    Reference,
)


def _parse_upload_response(payload: object) -> str:
    if not isinstance(payload, dict) or "reference" not in payload:
        raise BeeJsonError(f"missing 'reference' in upload response: {payload!r}")
    ref = payload["reference"]
    if not isinstance(ref, str):
        raise BeeJsonError(f"'reference' is not a string: {ref!r}")
    return ref


def soc_address(identifier: Identifier, owner: EthAddress) -> Reference:
    """The address GSOC subscribers listen on:
    ``keccak256(identifier || owner)``. Same as the underlying SOC
    address.
    """
    return calculate_single_owner_chunk_address(identifier, owner)


class AsyncGsocApi:
    """Async GSOC handle. Reachable as :attr:`bee.AsyncBee.gsoc`."""

    __slots__ = ("_inner",)

    def __init__(self, inner: _AsyncInner) -> None:
        self._inner = inner

    async def send(
        self,
        batch_id: BatchId,
        signer: PrivateKey,
        identifier: Identifier,
        data: bytes,
        opts: UploadOptions | None = None,
    ) -> UploadResult:
        """Sign ``(identifier, data)`` as a SOC and upload via
        ``POST /soc/{owner}/{id}``.

        Use :func:`bee.swarm.gsoc.gsoc_mine` to derive ``signer`` so
        the SOC address falls inside the target neighbourhood.
        """
        soc = make_single_owner_chunk(identifier, data, signer)
        body = soc.span.as_bytes() + soc.payload
        path = f"soc/{soc.owner.to_hex()}/{identifier.to_hex()}"
        headers = prepare_upload_headers(batch_id, opts)
        headers.append(("Content-Type", "application/octet-stream"))
        response = await self._inner.send(
            "POST",
            path,
            content=body,
            headers=headers,
            params={"sig": soc.signature.to_hex()},
        )
        ref = _parse_upload_response(_decode_json(response.content))
        return UploadResult.from_response(ref, response.headers)

    async def subscribe(
        self, owner: EthAddress, identifier: Identifier
    ) -> AsyncSubscription:
        """Open a WebSocket subscription at
        ``/gsoc/subscribe/{soc_address}``.
        """
        addr = soc_address(identifier, owner)
        return await AsyncSubscription.open(
            self._inner.base_url, f"gsoc/subscribe/{addr.to_hex()}"
        )

    @staticmethod
    def soc_address(identifier: Identifier, owner: EthAddress) -> Reference:
        """Pure helper — same as module-level :func:`soc_address`."""
        return soc_address(identifier, owner)


class GsocApi:
    """Sync GSOC handle. Reachable as :attr:`bee.Bee.gsoc`.

    Subscribe is async-only (WebSockets); for sync code, only
    :meth:`send` is available.
    """

    __slots__ = ("_inner",)

    def __init__(self, inner: _SyncInner) -> None:
        self._inner = inner

    def send(
        self,
        batch_id: BatchId,
        signer: PrivateKey,
        identifier: Identifier,
        data: bytes,
        opts: UploadOptions | None = None,
    ) -> UploadResult:
        """Sign ``(identifier, data)`` as a SOC and upload via
        ``POST /soc/{owner}/{id}``.
        """
        soc = make_single_owner_chunk(identifier, data, signer)
        body = soc.span.as_bytes() + soc.payload
        path = f"soc/{soc.owner.to_hex()}/{identifier.to_hex()}"
        headers = prepare_upload_headers(batch_id, opts)
        headers.append(("Content-Type", "application/octet-stream"))
        response = self._inner.send(
            "POST",
            path,
            content=body,
            headers=headers,
            params={"sig": soc.signature.to_hex()},
        )
        ref = _parse_upload_response(_decode_json(response.content))
        return UploadResult.from_response(ref, response.headers)

    @staticmethod
    def soc_address(identifier: Identifier, owner: EthAddress) -> Reference:
        return soc_address(identifier, owner)


__all__ = [
    "AsyncGsocApi",
    "GsocApi",
    "soc_address",
]
