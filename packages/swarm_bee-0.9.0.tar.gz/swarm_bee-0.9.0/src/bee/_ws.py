"""Async WebSocket subscription helper used by PSS and GSOC.

Mirrors bee-rs's ``pss::Subscription``: ``open`` upgrades the configured
base URL's scheme (``http`` → ``ws``, ``https`` → ``wss``) and joins the
given path; ``recv`` yields the bytes of each delivered binary or text
frame; ``close`` cancels the underlying connection.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from types import TracebackType
from typing import TYPE_CHECKING

from typing_extensions import Self

from .swarm.errors import BeeArgumentError, BeeTransportError

if TYPE_CHECKING:
    from websockets.asyncio.client import ClientConnection


def _build_ws_url(base_url: str, path: str) -> str:
    """Upgrade scheme on ``base_url`` and join with ``path``."""
    base = base_url.rstrip("/")
    if base.startswith("http://"):
        ws_base = "ws://" + base[len("http://") :]
    elif base.startswith("https://"):
        ws_base = "wss://" + base[len("https://") :]
    elif base.startswith("ws://") or base.startswith("wss://"):
        ws_base = base
    else:
        raise BeeArgumentError(f"unsupported base URL scheme: {base!r}")
    if path.startswith("/"):
        return f"{ws_base}{path}"
    return f"{ws_base}/{path}"


class AsyncSubscription:
    """Active PSS / GSOC subscription. Async context manager."""

    __slots__ = ("_ws",)

    def __init__(self, ws: ClientConnection) -> None:
        self._ws = ws

    @classmethod
    async def open(cls, base_url: str, path: str) -> Self:
        """Open a WebSocket connection at ``base_url + path`` (with
        scheme upgraded ``http`` → ``ws``).
        """
        # Imported here so the package can be imported without
        # `websockets` installed (e.g. for the pure helpers in
        # ``bee.swarm.gsoc``).
        from websockets.asyncio.client import connect
        from websockets.exceptions import WebSocketException

        url = _build_ws_url(base_url, path)
        try:
            ws = await connect(url)
        except (OSError, WebSocketException) as e:
            raise BeeTransportError(f"websocket connect: {e}") from e
        return cls(ws)

    async def recv(self) -> bytes:
        """Wait for the next message and return its bytes.

        Raises :class:`BeeTransportError` when the connection has
        closed cleanly or with an error.
        """
        from websockets.exceptions import ConnectionClosed, WebSocketException

        try:
            msg = await self._ws.recv()
        except ConnectionClosed as e:
            raise BeeTransportError(f"subscription closed: {e}") from e
        except WebSocketException as e:
            raise BeeTransportError(f"websocket error: {e}") from e
        if isinstance(msg, str):
            return msg.encode("utf-8")
        return msg

    async def close(self) -> None:
        """Close the WebSocket. Idempotent."""
        await self._ws.close()

    def __aiter__(self) -> AsyncIterator[bytes]:
        return self._iter()

    async def _iter(self) -> AsyncIterator[bytes]:
        try:
            while True:
                yield await self.recv()
        except BeeTransportError:
            return

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()


__all__ = ["AsyncSubscription"]
