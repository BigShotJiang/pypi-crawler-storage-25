# Changelog

All notable changes to bee-py will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.9.0] - 2026-05-07

High-level glue + bulk-perf milestone. Adds four new surfaces that
together let users think in ``(size, duration)`` terms, stream
directory uploads with progress callbacks, and run bulk uploads
through a single WebSocket session.

### Added
- ``bee.swarm.Network`` — block-time selector enum with
  ``Mainnet`` (15s) and ``Gnosis`` (5s, default).
  ``seconds_to_blocks`` (rounds up) / ``blocks_to_seconds``.
- ``bee.storage`` — high-level wrappers around postage:
  - ``get_storage_cost(client, size, duration, network)`` returns a
    :class:`StorageCost` with ``depth`` / ``amount_per_chunk`` /
    ``total_cost`` / ``blocks``.
  - ``buy_storage`` previews and creates the batch in one call.
  - ``extend_storage_duration`` tops up by
    ``current_price * blocks(duration)``.
  - ``extend_storage_size`` dilutes the batch (no-op if already
    deep enough).
  - ``get_duration_extension_cost`` /
    ``get_size_extension_cost`` /
    ``calculate_top_up_for_bzz`` — pure cost previews.
  - Each helper has an ``_sync`` twin for :class:`Bee`.
- ``bee.file.AsyncChunkStream`` — ``WS /chunks/stream`` session.
  ``send_chunk`` blocks until the server's single-byte ``0x00``
  ack; non-zero bytes or text frames raise :class:`BeeArgumentError`.
  Async context manager; ``close()`` is idempotent.
  ``AsyncFileApi.chunks_stream(batch_id, tag=None)`` opens a session
  with optional ``swarm-tag``.
- ``bee.file.stream_directory(directory, batch_id, opts, on_progress)``
  and ``stream_collection_entries(...)`` — content-address each file
  via :class:`FileChunker`, upload chunks via ``POST /chunks`` with
  bounded concurrency (semaphore, cap = 64), then assemble a
  Mantaray manifest with one fork per file. Progress callback fires
  once per uploaded chunk with ``StreamProgress(total, processed)``.
- ``bee.file.save_manifest_recursively(node, batch_id, opts)`` —
  depth-first persistence of a :class:`MantarayNode` tree. Each
  child is uploaded first (so its ``self_address`` is populated),
  then the node itself.
- ``total_chunks_for(num_bytes)`` — pure helper exposing the
  expected chunker output count (matches bee-js ``totalChunks``).
- Integration check ``stream`` section: streams a 2-entry in-memory
  collection against live Bee and verifies the progress callback
  fires.

## [0.8.0] - 2026-05-07

Value primitives milestone. Five new modules under ``bee.swarm``
that wrap money, time, size, multi-chunk content addresses, and
CID encoding. Closes the single-chunk-only limitation in
``hash_collection_entries``.

### Added

- ``bee.swarm.Bzz`` / ``bee.swarm.Dai`` — fixed-point token amounts
  backed by Python ``int`` (PLUR = ``10^16`` for BZZ,
  wei = ``10^18`` for DAI). ``from_decimal_str("1.5")`` truncates
  past the token's precision (matches bee-js / bee-go); ``from_float``
  trims trailing zeros before parsing. ``exchange_to_dai`` /
  ``exchange_to_bzz`` use integer math against a DAI-per-BZZ rate.
  Arithmetic via ``+`` / ``-`` / ``divide(int)`` / ``times(int)``;
  ordered + hashable.
- ``bee.swarm.Duration`` — non-negative whole-second duration; clamps
  negatives / NaN to zero; ceil-rounds fractional seconds. ``parse()``
  handles ``"1.5h"``, ``"1d 4h 5m 30s"``, ``"  2 Weeks  "``, etc.
  ``to_timedelta`` / ``from_timedelta`` interop with stdlib
  ``datetime.timedelta``.
- ``bee.swarm.Size`` — non-negative byte count with decimal-base
  (1000) conversions, matching the Swarm theoretical / effective
  storage tables. ``parse()`` accepts compound forms like
  ``"1gb 256mb"``; auto-scaled ``str()`` rendering
  (``"1.50 GB"``).
- ``bee.swarm.FileChunker`` — streaming content-addressed chunker
  that builds a tree of 4 KiB CACs with 128-fanout intermediate
  levels. ``write(bytes)`` / ``finalize() -> ChunkerRoot``;
  optional ``on_chunk`` callback fires for every sealed
  ``SealedChunk``. Convenience ``chunk_file(data)`` for one-shot
  use. Closes the single-chunk-only gap — :func:`hash_collection_entries`
  now routes multi-chunk entries through it.
- ``bee.swarm.cid`` — Reference ↔ CID with manifest (``0xfa``) and
  feed (``0xfb``) multicodecs. ``convert_reference_to_cid`` and
  ``convert_cid_to_reference`` round-trip a 32-byte reference
  through a base32 (RFC 4648, no padding) string with multibase
  prefix ``"b"``. Pure-Python encoder / decoder cross-validated
  against the §10 vectors and bee-go's ``TestCID`` fixture.

### Changed
- :func:`bee.file.hash_collection_entries` no longer rejects
  entries larger than 4096 bytes. Each entry is now content-addressed
  via :func:`bee.swarm.chunk_file` (FileChunker) and the resulting
  root reference is inserted into the Mantaray. The manifest itself
  must still fit in a single chunk.

## [0.7.0] - 2026-05-07

Debug-surface milestone. ``bee.debug`` now covers every endpoint
under ``pkg/debug`` in bee-go: accounting, chequebook, peers,
transactions, loggers, plus the rest of the node / chain endpoints.
Mirrors bee-rs ``debug::`` byte-for-byte.

### Added

Node + chain:
- ``client.debug.chain_state`` (``GET /chainstate``) with
  ``current_price`` / ``total_amount`` as Python ``int``.
- ``client.debug.node_info`` (``GET /node``).
- ``client.debug.status``, ``status_peers``, ``status_neighborhoods``.
- ``client.debug.readiness`` (404/503 → False).
- ``client.debug.is_gateway`` (404 → False).
- ``client.debug.is_connected`` — ping the base URL.

Accounting + stake:
- ``balances``, ``peer_balance``, ``consumed_balances``,
  ``peer_consumed_balance``.
- ``accounting`` — full ``peerData`` map with ``PeerAccounting``
  entries (every monetary field is ``int | None``; empty strings
  decode as ``None``).
- ``stake`` / ``deposit_stake`` / ``withdrawable_stake`` /
  ``withdraw_surplus_stake`` / ``migrate_stake``.
  Stake POST/DELETE responses use the ``txHash`` shape (matches
  bee-rs's ``tx_hash_response``).
- ``redistribution_state`` (with the fractional
  ``last_sample_duration_seconds`` Bee actually returns).
- ``r_chash(depth, anchor1, anchor2)`` returning
  ``RCHashResponse`` + ``ChunkInclusionProof[s]`` /
  ``PostageProof`` / ``SocProof`` triples.

Chequebook + settlements + wallet:
- ``wallet`` accepts both ``chequebook`` (Bee ≤ 2.7.1) and
  ``chequebookContractAddress`` (Bee 2.7.2+) — the new key wins.
- ``withdraw_bzz`` / ``withdraw_native_token``.
- ``chequebook_balance`` / ``chequebook_deposit`` /
  ``chequebook_withdraw``.
- ``last_cheques`` / ``peer_cheques`` / ``last_cashout_action``.
- ``cashout_last_cheque`` with optional ``gas_price`` header.
- ``settlements`` / ``peer_settlement`` / ``time_settlements``
  (the time-based ``/timesettlements`` Bee endpoint shipped in
  bee-rs v1.3).

Peers + topology:
- ``peers`` / ``blocklist`` / ``remove_peer``.
- ``ping_peer`` (returns RTT string), ``connect_peer`` (strips
  leading ``/`` on multiaddr).
- ``addresses`` (overlay / underlay / ethereum / publicKey /
  pssPublicKey).
- ``topology`` collapses Bee's flat ``bin_0`` … ``bin_31`` keys
  into a 32-element ``bins`` list (always-32 invariant for
  bounds-free indexing). ``connectedPeers`` / ``disconnectedPeers``
  ``null`` decoded as ``[]`` (matches Go's nil-slice marshal).
- ``reserve_state``.
- ``welcome_message`` / ``set_welcome_message``.

Transactions:
- ``pending_transactions`` / ``pending_transaction``.
- ``rebroadcast_transaction``.
- ``cancel_transaction`` with optional ``gas_price`` header.

Loggers:
- ``loggers`` / ``loggers_by_expression`` / ``set_logger_verbosity``
  with base64-encoded expression in the path (Bee's contract).

### Internal
- New ``bee.debug._types`` holds 33 dataclasses with
  ``from_dict`` parsers — empty bigint strings → ``None``,
  invalid bigint strings → :class:`BeeJsonError`.
- Integration check ``debug`` section sweeps 7 read-only endpoints
  (``node``, ``chainstate``, ``addresses``, ``topology``,
  ``reservestate``, ``wallet``, ``peers``) against live Bee.

## [0.6.0] - 2026-05-07

Generic-API milestone. Five new endpoint families on a single new
surface, ``client.api``: pin / tag / stewardship / grantee / envelope.
Mirrors bee-rs ``api::endpoints`` byte-for-byte.

### Added
- ``bee.api.AsyncApiService`` / ``ApiService`` — wired onto
  ``Bee.api`` / ``AsyncBee.api``.
- Pins: ``pin`` (``POST /pins/{ref}``), ``unpin``
  (``DELETE /pins/{ref}``), ``get_pin``
  (``GET /pins/{ref}``, 404 → False), ``list_pins``
  (``GET /pins``).
- Tags: ``create_tag`` (``POST /tags``), ``get_tag``
  (``GET /tags/{uid}``), ``list_tags`` with optional
  ``offset`` / ``limit`` (zero values are dropped to match
  bee-rs / bee-go), ``delete_tag``, ``update_tag``
  (``PATCH /tags/{uid}``). ``Tag`` dataclass with full Bee fields
  plus camelCase ``startedAt`` on the wire.
- Stewardship: ``reupload`` (``PUT /stewardship/{ref}`` with
  ``Swarm-Postage-Batch-Id`` header) and ``is_retrievable``
  (``GET /stewardship/{ref}``, accepts both ``isRetrievable`` and
  ``is_retrievable`` JSON keys — Bee 2.7 returns the camelCase
  variant in practice).
- Grantees: ``get_grantees`` (``GET /grantee/{ref}`` returns a
  bare JSON array), ``create_grantees`` (``POST /grantee``),
  ``patch_grantees`` (``PATCH /grantee/{ref}`` with empty
  ``add`` / ``revoke`` lists omitted from the body).
  ``GranteeResponse`` dataclass with ``ref`` / ``historyref``
  fields.
- Envelope: ``post_envelope`` (``POST /envelope/{ref}``) returning
  the ``issuer`` / ``index`` / ``timestamp`` / ``signature``
  quadruple as ``EnvelopeResponse``.
- Integration check ``api`` section: uploads a payload, pins +
  unpins it, fetches an envelope (signature non-empty),
  creates + deletes a tag (uid non-zero). Green against live
  Bee 2.7.2-rc1.

## [0.5.0] - 2026-05-07

Pub/sub milestone. Three new surfaces — feeds, GSOC, PSS — that
together cover Swarm's "stream of updates" and "overlay messaging"
primitives, all built on the SOC + chunk plumbing shipped in 0.2.

### Added
- `bee.feeds`: sequential SOC streams keyed on `(owner, topic)`.
  `make_feed_identifier`, `feed_update_chunk_address` (pure
  helpers), `FeedUpdate` dataclass. `AsyncFeedApi` / `FeedApi` with
  `create_feed_manifest` / `get_feed_lookup`, `fetch_latest`,
  `find_next_index` (404/500 → 0), `update_feed{,_with_index,
  _with_reference}`, `is_feed_retrievable`. Convenience
  `AsyncFeedReader` / `AsyncFeedWriter` (and sync counterparts)
  bind a `(owner, topic)` or `(signer, topic)` pair, mirroring
  bee-js `Bee.makeFeedReader` / `makeFeedWriter`.
  Identifier = `keccak256(topic || BE-u64(index))`; payload =
  `BE-u64(now) || data`.
- `bee.swarm.gsoc`: `proximity(a, b)` (leading-common-bits, matches
  bee-go `swarm.Proximity`) and `gsoc_mine(target, identifier,
  target_proximity)` — the offline mining loop that derives a
  signer whose `(identifier, owner)` SOC address falls within
  `target_proximity` bits of `target`. Search window
  `[0xb33, 0xb33 + 0xffff]` matches bee-js exactly.
  `GSOC_MINE_START` / `GSOC_DEFAULT_PROXIMITY = 12` constants.
- `bee.gsoc`: `AsyncGsocApi` / `GsocApi` with `send` (signed-SOC
  upload via `POST /soc/{owner}/{id}`) and `soc_address` helper.
  `AsyncGsocApi.subscribe(owner, identifier)` opens a WebSocket at
  `/gsoc/subscribe/{soc_address}`.
- `bee.pss`: `AsyncPssApi` / `PssApi` with `send(batch_id, topic,
  target, data, recipient=None)` — `POST /pss/send/{topic}/{target}`
  with optional `recipient=` query (encrypts to a `PublicKey`).
  `AsyncPssApi.subscribe(topic)` opens a WebSocket at
  `/pss/subscribe/{topic}`; `receive(topic, timeout)` is a one-shot
  helper that subscribes, waits, returns bytes, then closes.
- `bee._ws.AsyncSubscription`: shared async WebSocket helper used by
  PSS and GSOC. `recv()` returns bytes for binary or text frames;
  the subscription is an async context manager and async iterator.
- New runtime dependency: `websockets>=13.0` (only used by the
  subscribe surface; `send`-only callers don't pay the import cost).
- `Bee.feeds` / `AsyncBee.feeds`, `Bee.gsoc` / `AsyncBee.gsoc`,
  `Bee.pss` / `AsyncBee.pss` accessors. Sync `gsoc` / `pss` expose
  only `send` — `subscribe` requires an event loop and lives on
  `AsyncBee` only.
- Integration check `feeds` section: writes a feed update at
  `find_next_index`, verifies the server's returned reference
  matches `feed_update_chunk_address(owner, topic, index)` computed
  offline (cross-validates the SOC signing path end-to-end).

## [0.4.0] - 2026-05-07

Mantaray milestone. Full v0.2 manifest wire format (marshal /
unmarshal with XOR obfuscation), trie operations on `MantarayNode`,
`ResourceLocator`, and an offline `hash_collection_entries` predictor.
The pieces a client needs to (a) walk an unmarshaled manifest and (b)
predict a manifest's chunk address before talking to a node — both
prerequisites for feeds, ACT, and offline-stamper-style flows.

### Added
- `bee.manifest.MantarayNode` + `Fork` — in-memory trie with
  `add_fork`, `remove_fork` (with chain-walk + grandchild
  reinsertion), `find` / `find_closest`, `collect` /
  `collect_and_map`, `determine_type`. `MAX_PREFIX_LENGTH = 30` and
  the four type bits (`TYPE_VALUE = 2`, `TYPE_EDGE = 4`,
  `TYPE_WITH_PATH_SEPARATOR = 8`, `TYPE_WITH_METADATA = 16`) match
  bee-js / bee-go / bee-rs byte-for-byte.
- `bee.manifest.wire`: `marshal` / `unmarshal` for the v0.2 wire
  format (32-byte version hash
  `5768b3b6a7db56d21d1abff40d41cebfc83448fed8d7e9b06ec0d3b073f28f7b`,
  XOR-obfuscated fork blocks with the leaf address as the key,
  optional metadata block). `calculate_self_address` (single-chunk
  only — raises `BeeArgumentError` for manifests > 4096 B) and
  `populate_self_addresses` for bottom-up address propagation.
  Cross-validated against bee-rs: 192-byte canonical output, address
  `4a108a00…f5c772ac`.
- `bee.manifest.ResourceLocator` — frozen dataclass holding either
  a `Reference` or an ENS name; `parse` accepts either form
  (anything containing `.eth` is treated as ENS, else hex), plus
  `from_reference`, `from_ens`, `is_reference`, `is_ens`. `str()`
  yields the path-segment form for `/bzz/{ref}` and `/bytes/{ref}`.
- `bee.manifest.resolve_path(manifest, path)` — offline manifest
  path resolution mirroring Bee's server-side `GET /bzz/{ref}/{path}`
  behavior (leading slash optional). `target_reference(node)` returns
  the fork target as a `Reference` or `None` for branch-only nodes
  with `NULL_ADDRESS`.
- `bee.file.hash_collection_entries(entries) -> Reference` — offline
  Mantaray manifest address prediction. Each entry's data is
  content-addressed via single-chunk BMT, leaf references are
  inserted into a fresh `MantarayNode`, and the manifest's
  self-address is returned. Single-chunk-per-entry only in 0.4
  (≤ 4096 B); larger files / multi-chunk manifests need
  `FileChunker` (later milestone). Inherits bee-rs's known divergence
  from server-side Mantaray for default-document collections.
- `examples/integration_check.py` adds a `manifest_pred` section that
  compares the offline-predicted address to Bee's returned reference
  and reports MATCH / DIVERGED informationally (does not fail the
  run — diverging is an expected limitation today, mirroring
  bee-rs).

## [0.3.0] - 2026-05-07

Postage milestone. Read + write batch endpoints, the full stamp-math
table, and the offline `Stamper` for client-side envelope signing —
the prerequisites for any "manage your own batches" or
`postEnvelope`-style uploader.

### Added
- `bee.postage.stamp_math`: pure offline helpers for sizing /
  costing batches — `get_stamp_usage`, `get_stamp_theoretical_bytes`,
  `get_stamp_cost`, `get_stamp_effective_bytes`, `get_depth_for_size`.
  `EFFECTIVE_SIZE_BREAKPOINTS` mirrors the bee-js encrypted-medium
  table byte-for-byte. Python `int` carries the role of bee-rs
  `BigInt` since Python ints are arbitrary precision.
- `bee.postage.stamper`: client-side `Stamper` (per-bucket counters,
  signs envelopes for individual chunks without round-tripping the
  node), `Envelope` dataclass, and `marshal_stamp` /
  `convert_envelope_to_marshaled_stamp` for the 113-byte wire format
  (`batchID(32) || index(8) || timestamp(8) || signature(65)`).
  `Stamper.from_blank` / `from_state` for fresh and resumed sessions.
  Bucket routing uses the first 2 bytes of the chunk address as a
  big-endian `u16` (matches bee-go / bee-js).
- `bee.postage` module: `PostageBatch`, `GlobalPostageBatch`,
  `BatchBucket`, `PostageBatchBuckets` dataclasses with `from_dict`
  parsing of Bee's bigint-as-string fields. Captures the
  owner-vs-chain wire-format divergence (owner uses `"amount"` /
  `"immutableFlag"`, chain endpoint uses `"value"` / `"immutable"`).
- `client.postage.get_postage_batches` / `get_postage_batch` /
  `get_postage_batch_buckets` / `get_global_postage_batches` —
  read endpoints. Wired onto both `Bee.postage` and `AsyncBee.postage`.
- `client.postage.create_postage_batch(amount, depth, label=, opts=)`
  — `POST /stamps/{amount}/{depth}` with label / immutable query
  params and Gas-Price / Gas-Limit headers from
  `PostageBatchOptions`. Raises on conflicting `label=` arg vs
  `opts.label`.
- `client.postage.top_up_batch` and `dilute_batch` —
  `PATCH /stamps/topup/{id}/{amount}` and
  `PATCH /stamps/dilute/{id}/{depth}`.
- Integration check `postage` section: reads our existing batch
  and prints `depth / utilization / usable / immutable / label`.
  Verified live: depth=22, util=1, usable=True, immutable=True.

## [0.2.0] - 2026-05-07

First release shipped to PyPI as `swarm-bee` (the natural `bee-py`
collided with PyPI's typosquat rule against the unrelated `beepy`
project — the GitHub repo and import name are unchanged). Targets
Bee `2.7.2-rc1` / API `8.0.0`. Functional parity with bee-js /
bee-go / bee-rs at the "put-bytes-in-get-bytes-out" layer: `/bytes`,
`/chunks`, `/soc`, `/bzz` (file + collection). All four addressing
modes verified end-to-end against a live Bee node via
`examples/integration_check.py`.

### Added
- `client.file.upload_file` (`POST /bzz` with `?name=` query +
  Content-Type), `download_file` and `download_file_path`
  (`GET /bzz/{ref}` and `GET /bzz/{ref}/{path}`, returning
  `(bytes, FileHeaders)`).
- `client.file.upload_collection_entries` (in-memory tar packing for
  `POST /bzz` with `Content-Type: application/x-tar` + `Swarm-Collection: true`)
  and `client.file.upload_collection` (filesystem walker).
- `bee.file.CollectionEntry` (frozen dataclass: `path` + `data`),
  `collection_size`, `build_tar_archive`, `read_directory_entries`.
  Tar uses USTAR format, mode `0o644`, sorted by path so the
  resulting wire bytes are deterministic.
- Integration check sections for `file` and `collection` —
  uploaded a 3-entry collection with `Swarm-Index-Document` set to
  `index.html`, downloaded both `/bzz/{ref}` (root) and
  `/bzz/{ref}/nested/data.bin` (path) cleanly against live Bee.

### Changed
- `_AsyncInner` and `_SyncInner` default httpx clients now have
  `follow_redirects=True`. Bee returns `308 Permanent Redirect`
  on `GET /bzz/{ref}` → `/bzz/{ref}/` for collection roots; without
  this, downloads of those refs would surface as `BeeResponseError`
  with a 308 status. Matches reqwest's default redirect-follow
  behavior in bee-rs.

- `examples/integration_check.py` — live smoke test against a real
  Bee node. Reads `BEE_URL` (default `http://localhost:1633`) and
  `BEE_BATCH_ID` (skipping upload sections cleanly when unset; never
  auto-buys). Validates health, bytes round-trip, chunk round-trip
  with offline BMT verification, and SOC sign+recover. First green
  run against Bee `2.7.2-rc1-d3684560` API `8.0.0` confirms the wire
  format is correct end-to-end.
- `bee.swarm.soc`: `SingleOwnerChunk` dataclass + `make_single_owner_chunk`,
  `calculate_single_owner_chunk_address`, `unmarshal_single_owner_chunk`.
  Round-trip tested: sign with the eth-signed-message scheme, recover
  the owner, verify against `keccak256(identifier || owner)`. Wire
  form is `identifier(32) || signature(65) || span(8) || payload`.
- `client.file.upload_soc` / `download_soc` — `POST /soc/{owner}/{id}?sig=…`
  (body is `span || payload`; identifier and signature live in the
  URL) and verified `GET /chunks/{addr}` for download.
- `bee.swarm.keys`: `PrivateKey` (bytearray-backed best-effort
  zeroize, constant-time eq via `hmac.compare_digest`, redacted repr)
  and `PublicKey` (33-byte compressed or 64-byte uncompressed
  `X || Y`, derives `EthAddress`). `eth_signed_message_digest`,
  `recover_public_key`, and `verify_signature` for the bee-js sign +
  recover wire format (V normalized to {27, 28}). Backed by
  `coincurve` (libsecp256k1 C bindings) — same backend bee-rs adopted
  in v1.2.0 for the ~4x ECDSA speedup.
- `bee.swarm.bmt`: Binary Merkle Tree chunk addressing —
  `keccak256`, `calculate_chunk_address`, `make_content_addressed_chunk`,
  `Chunk` dataclass. Cross-checks against bee-go / bee-rs:
  ``keccak256("hello world")`` BMT address is
  ``92672a47…644b630f``. Constants: ``CHUNK_SIZE = 4096``,
  ``SEGMENT_SIZE = 32``, ``SEGMENTS_COUNT = 128``.
- `client.file.upload_chunk` / `download_chunk` — `POST /chunks`,
  `GET /chunks/{ref}`. Round-trip test: locally-computed BMT address
  matches the reference Bee returns.
- `bee.api` module: `UploadOptions`, `RedundantUploadOptions`,
  `FileUploadOptions`, `CollectionUploadOptions`, `DownloadOptions`,
  `PostageBatchOptions`, `RedundancyLevel` / `RedundancyStrategy`
  enums, plus `prepare_*_headers` helpers that mirror bee-rs's
  `Optional<bool>` "None vs explicit False" header semantics.
- `bee.api.UploadResult` (reference + tag UID + ACT history),
  `FileHeaders` (Content-Disposition filename + Content-Type +
  tag UID), `ReferenceInformation`, plus a permissive
  `parse_content_disposition_filename` accepting both quoted and
  RFC 5987 forms.
- `client.file.upload_data` / `download_data` / `probe_data` —
  `POST /bytes`, `GET /bytes/{ref}`, `HEAD /bytes/{ref}`. Both
  `Bee.file` (sync) and `AsyncBee.file` (async) surfaces.
- Initial repo skeleton: `pyproject.toml` (uv-managed), MIT LICENSE, CI on
  Python 3.10–3.13, ruff + mypy strict, pytest + pytest-asyncio + respx.
- `bee.swarm` typed-bytes primitives (`Reference`, `BatchId`, `TransactionId`,
  `PeerAddress`, `Identifier`, `Topic`, `EthAddress`, `Span`, `FeedIndex`,
  `Signature`) with hex round-trip, EIP-55 checksum, and keccak256-of-utf8
  helpers for `Identifier` / `Topic`.
- `bee.swarm.errors.BeeError` exception hierarchy (Argument, Response,
  LengthMismatch, Hex, Crypto, Json, Transport).
- Async-first `Bee` / `AsyncBee` clients backed by `httpx`. Shared
  internals; both expose `debug.health()`.
- Bee version pinning constants (`SUPPORTED_API_VERSION = "8.0.0"`,
  `SUPPORTED_BEE_VERSION_EXACT = "2.7.2-rc1-83612d37"`).

[Unreleased]: https://github.com/ethswarm-tools/bee-py/compare/v0.9.0...HEAD
[0.9.0]: https://github.com/ethswarm-tools/bee-py/releases/tag/v0.9.0
[0.8.0]: https://github.com/ethswarm-tools/bee-py/releases/tag/v0.8.0
[0.7.0]: https://github.com/ethswarm-tools/bee-py/releases/tag/v0.7.0
[0.6.0]: https://github.com/ethswarm-tools/bee-py/releases/tag/v0.6.0
[0.5.0]: https://github.com/ethswarm-tools/bee-py/releases/tag/v0.5.0
[0.4.0]: https://github.com/ethswarm-tools/bee-py/releases/tag/v0.4.0
[0.3.0]: https://github.com/ethswarm-tools/bee-py/releases/tag/v0.3.0
[0.2.0]: https://github.com/ethswarm-tools/bee-py/releases/tag/v0.2.0
