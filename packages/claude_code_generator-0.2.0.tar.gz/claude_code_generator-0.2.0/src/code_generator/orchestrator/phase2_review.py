"""Phase 2 — Per-issue review with circuit breaker.

Each open issue is reviewed by Opus 4.6 in its own invocation.
If the circuit breaker trips for a specific issue, a ``needs-manual-review``
label is added and processing continues with the next issue.

Non-negotiable #8: model is hard-coded to ``claude-opus-4-6``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator import effort as _effort
from code_generator import gh
from code_generator.logging_setup import log_issue_usage, log_phase_usage, setup_phase_logger
from code_generator.orchestrator._comments import fetch_formatted_comments
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit, retry
from code_generator.runner.options import make_agent_options
from code_generator.runner.types import TokenUsage
from code_generator.state import get_issues, save_state

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, State


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
) -> None:
    """Execute phase 2: per-issue review.

    Iterates open issues and reviews each with a fresh Opus 4.6 session.
    A :class:`~code_generator.runner.retry.CircuitBreaker` with
    ``max_failures=3`` wraps each issue. When the breaker trips, the issue
    is tagged ``needs-manual-review`` and skipped.

    Args:
        state: Root state object.
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
    """
    if logger is None:
        logger = setup_phase_logger("phase2", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"

    issues = get_issues(state, cycle)
    phase_total = TokenUsage()

    for issue in issues:
        if issue.status != "open":
            continue

        logger.info("Phase 2: reviewing issue #%d (agent=%s).", issue.number, issue.agent)

        comments_section = fetch_formatted_comments(issue.number, logger)

        prompt = load_prompt(
            "prompt-phase-2-issue-review.md",
            ISSUE_NUMBER=str(issue.number),
            PRIMARY_AGENT=issue.agent,
            ISSUE_COMMENTS=comments_section,
        )

        effort_level = _effort.resolve_effort(
            phase=2, complexity="", issue_labels=issue.labels, retry_count=0
        )
        _effort.validate_effort(effort_level, "claude-opus-4-6")

        options = make_agent_options(
            model="claude-opus-4-6",
            effort=effort_level,
            allowed_tools=["Read", "Bash", "Glob", "Grep"],
            cwd=str(project_dir),
            max_turns=15,
        )

        breaker = retry.CircuitBreaker(max_failures=3)
        issue_usage = TokenUsage()
        reviewed = True

        try:
            result = await retry.with_backoff(
                lambda p=prompt, o=options: rate_limit.main_loop(  # type: ignore[misc]
                    runner_module,
                    p,
                    o,
                    state_path=state_path,
                    logger=logger,
                ),
                breaker=breaker,
            )
            issue_usage = result.usage if result is not None else TokenUsage()
        except retry.CircuitOpen:
            reviewed = False
            logger.error(
                "Phase 2: circuit breaker opened for issue #%d — tagging for manual review.",
                issue.number,
            )
            try:
                gh.add_label(issue.number, "needs-manual-review")
            except gh.GhError as exc:
                logger.warning(
                    "Could not add needs-manual-review label to #%d: %s",
                    issue.number,
                    exc,
                )

        log_issue_usage(logger, 2, issue.number, issue_usage)
        phase_total += issue_usage

        if reviewed:
            logger.info("Phase 2: issue #%d reviewed.", issue.number)

    target = cycle if cycle is not None else state
    target.token_usage["phase2"] = phase_total
    save_state(state_path, state)
    log_phase_usage(logger, 2, phase_total)
