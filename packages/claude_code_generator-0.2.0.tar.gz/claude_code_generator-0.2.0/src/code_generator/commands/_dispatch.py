"""Dispatch helpers for the generate command.

Handles resolving resume parameters from CLI flags and delegating to the
async orchestration pipeline.  Separated from the Typer command definition
so both layers can be tested in isolation.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import typer

from code_generator.commands._resume import next_start_phase, resolve_continue_multi_cycle

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator import state as state_module

_logger = logging.getLogger(__name__)

__all__ = ["dispatch_async", "dispatch_orchestrator"]


async def _apply_delta_plan(
    st: state_module.State,
    project_dir: Path,
    *,
    runner_module: object,
    delta_hash: str,
    state_path: Path,
    logger: logging.Logger,
) -> int | None:
    """Run Phase 0 and merge new cycles into state for multi-cycle delta planning.

    Atomicity guarantee: state is only mutated after a successful Phase 0
    response.  If Phase 0 fails, a ``RuntimeError`` is raised and neither
    ``state.cycles`` nor ``state.requirements_hash`` is changed.

    Args:
        st: Root state (mutated in place on success).
        project_dir: Project root directory.
        runner_module: Runner module for Phase 0 execution.
        delta_hash: The new requirements hash to store on success.
        state_path: Path to state.json for atomic persistence.
        logger: Phase logger.

    Returns:
        ID of the first newly appended cycle, or ``None`` when the new plan
        contains no scopes that are not already in ``state.cycles``.

    Raises:
        RuntimeError: When Phase 0 returns ``None`` (all retries exhausted).
    """
    from code_generator import state as state_module
    from code_generator.orchestrator import phase0_complexity

    raw_cycles = await phase0_complexity.get_raw_cycle_plan(
        project_dir,
        runner_module=runner_module,  # type: ignore[arg-type]
        logger=logger,
    )

    if raw_cycles is None:
        raise RuntimeError(
            "Phase 0 failed during delta planning; aborting to preserve cycle history."
        )

    new_cycles = state_module.append_new_cycles(st, raw_cycles)

    if not new_cycles:
        logger.info("Delta planning: no new cycles detected.")
        st.requirements_hash = delta_hash
        state_module.save_state(state_path, st)
        return None

    # Extend state atomically: build new list, then assign all at once.
    st.cycles = list(st.cycles) + new_cycles
    st.current_cycle = new_cycles[0].id
    st.requirements_hash = delta_hash
    state_module.save_state(state_path, st)
    return new_cycles[0].id


async def dispatch_async(
    st: state_module.State,
    project_dir: Path,
    *,
    dry_run: bool,
    start_phase: int,
    start_cycle: int | None,
    mode: str,
    delta_hash: str | None = None,
    state_path: Path | None = None,
) -> None:
    """Async entry point for the orchestration pipeline.

    Args:
        st: Root state object.
        project_dir: Project root directory.
        dry_run: When True, only phases 0 and 1 run.
        start_phase: Resume from this phase (1 = full run).
        start_cycle: Resume from this cycle (multi-cycle only).
        mode: ``"auto"``, ``"single"``, or ``"multi-cycle"``.
        delta_hash: When set, triggers delta planning for multi-cycle mode
            with completed cycles (the new requirements hash to persist on
            success).  ``None`` disables delta planning.
        state_path: Path to state.json; required when ``delta_hash`` is set.
    """
    from code_generator.logging_setup import setup_phase_logger
    from code_generator.orchestrator import cycle_loop, phase0_complexity
    from code_generator.runner import get_runner

    runner_module = get_runner()
    logger = setup_phase_logger("generate", project_dir)

    # Phase 0: determine mode when not already known.
    if mode == "auto":
        needs_phase0 = st.mode not in ("single", "multi-cycle")
    else:
        needs_phase0 = False
        # Force the mode from the flag.
        st.mode = mode  # type: ignore[assignment]

    # Delta planning: multi-cycle with completed cycles needs a merge, not a
    # fresh Phase 0 run.  Single-mode delta is handled upstream (mode reset to
    # "unknown" forces Phase 0 to re-run via needs_phase0=True).
    completed = [c for c in st.cycles if c.status == "completed"]
    if delta_hash is not None and st.mode == "multi-cycle" and completed and state_path is not None:
        first_new_id = await _apply_delta_plan(
            st,
            project_dir,
            runner_module=runner_module,
            delta_hash=delta_hash,
            state_path=state_path,
            logger=logger,
        )
        if first_new_id is None:
            return  # No new cycles — nothing to run.
        start_cycle = first_new_id
        start_phase = 1
        needs_phase0 = False

    if needs_phase0:
        await phase0_complexity.run(st, project_dir, runner_module=runner_module, logger=logger)

    # Dry-run: planning only (phase 0 + phase 1).
    if dry_run:
        from code_generator.orchestrator import phase1_plan

        logger.info("--dry-run: running phase 1 (planning only).")
        await phase1_plan.run(st, None, project_dir, runner_module=runner_module, logger=logger)
        return

    # Dispatch to cycle loop.
    if st.mode == "multi-cycle":
        await cycle_loop.run_multi_cycle(
            st,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            start_cycle=start_cycle,
            start_phase=start_phase,
        )
    else:
        await cycle_loop.run_single_mode(
            st,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            start_phase=start_phase,
        )


def dispatch_orchestrator(
    st: state_module.State,
    project_dir: Path,
    *,
    dry_run: bool,
    phase: int | None,
    continue_: bool,
    mode: str,
    cycle: int | None,
    state_path: Path,
    requirements_hash: str | None = None,
) -> None:
    """Resolve resume parameters and dispatch the async orchestrator.

    Args:
        st: Root state.
        project_dir: Project root directory.
        dry_run: When True, only phase 0/1 planning runs.
        phase: Resume from this explicit phase number.
        continue_: Resume from the last completed phase/cycle in state.
        mode: ``"auto"``, ``"single"``, or ``"multi-cycle"``.
        cycle: Resume from this specific cycle (multi-cycle only).
        state_path: Path to state.json, used for atomic hash updates.
        requirements_hash: SHA-256 digest of the current requirements.md, or
            None when the file is absent (detection is skipped).
    """
    from code_generator import state as state_module

    # Re-run detection: only when no explicit resume flags override intent.
    # --continue and --phase N express explicit user intent, so they bypass
    # detection entirely to avoid surprising "nothing to do" responses.
    delta_hash_for_async: str | None = None
    if not continue_ and phase is None and requirements_hash is not None:
        from code_generator.commands._detect import detect_run_mode

        run_mode = detect_run_mode(st, requirements_hash)

        if run_mode == "no-op":
            _logger.info("nothing to do: all cycles complete, requirements unchanged")
            typer.echo("All cycles complete. Nothing to do.")
            return

        if run_mode == "first-run":
            st.requirements_hash = requirements_hash
            state_module.save_state(state_path, st)

        elif run_mode == "delta":
            completed = [c for c in st.cycles if c.status == "completed"]
            if st.mode == "multi-cycle" and completed:
                # Defer hash update to async path — atomicity requires Phase 0
                # to succeed before we store the new hash.
                delta_hash_for_async = requirements_hash
            else:
                # Single mode or no completed cycles: treat as fresh run from Phase 0.
                # Reset mode to "unknown" so Phase 0 re-runs and re-evaluates complexity.
                st.mode = "unknown"  # type: ignore[assignment]
                st.requirements_hash = requirements_hash
                state_module.save_state(state_path, st)

    # Resolve effective mode (honor existing state when --mode auto).
    effective_mode = mode
    if mode == "auto" and st.mode in ("single", "multi-cycle"):
        effective_mode = st.mode

    # Resolve start_phase and start_cycle.
    # Flag precedence (highest → lowest):
    #   1. --continue  → derive start_cycle + start_phase from state (last completed)
    #   2. --phase N   → explicit phase; start_cycle stays None (single-mode default)
    #   3. --cycle N   → overrides any continue-derived start_cycle; start_phase
    #                    defaults to 1 unless --phase N is also given
    #   4. (none)      → fresh run from phase 1, cycle None
    start_phase = 1
    start_cycle: int | None = None

    if continue_:
        # Resume from the *next* phase/cycle after the last completed one.
        if effective_mode == "multi-cycle":
            start_cycle, start_phase = resolve_continue_multi_cycle(st)
        else:
            start_phase = next_start_phase(st)

    elif phase is not None:
        start_phase = phase

    if cycle is not None:
        # --cycle N overrides any continue-derived start_cycle.
        start_cycle = cycle
        start_phase = phase or 1

    asyncio.run(
        dispatch_async(
            st,
            project_dir,
            dry_run=dry_run,
            start_phase=start_phase,
            start_cycle=start_cycle,
            mode=effective_mode,
            delta_hash=delta_hash_for_async,
            state_path=state_path,
        )
    )
