"""Tmuxp tests for plugins."""
