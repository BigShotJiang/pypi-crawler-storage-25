CarbonX is a specialized Python package designed to model the gas-phase synthesis of nanoparticles in flame-assisted chemical vapor deposition (FCCVD) reactors. It supports the simulation of the formation and evolution of a wide range of nanoparticle species, including:

Carbon nanotubes (CNTs)
Graphene layers
Carbide and amorphous carbon structures
Metallic nanoparticles such as Nickel (Ni) [DOI: 10.1021/acs.jpcc.2c07776] and Iron (Fe) [DOI: 10.1016/j.jaerosci.2025.106543], etc.
The package is primarily intended for plug-flow reactor environments, enabling the prediction of nanoparticle dynamics such as surface growth, coagulation, and agglomeration—mechanisms critical to controlling the morphology of carbon-based nanostructures and metallic nanoparticles.

Key Features:

Modular architecture for flexible kinetic and transport modeling
Time- and space-resolved simulation of particle dynamics
Extendable framework to accommodate custom nanoparticle types or reactor designs
Research-oriented design, ideal for both academic and industrial applications


