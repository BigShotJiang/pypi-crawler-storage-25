from collections import defaultdict
from datetime import datetime, timezone
from typing import Optional

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2.credentials import Credentials

from .models import DriveItem, DriveTree, FOLDER_MIME

# Fields fetched per item — size is excluded intentionally (not needed for structure analysis)
_LIST_FIELDS = "nextPageToken, files(id, name, mimeType, modifiedTime, parents)"
_ROOT_FIELDS = "id, name"


class DriveClient:
    def __init__(self, credentials: Credentials) -> None:
        self._service = build("drive", "v3", credentials=credentials)

    def get_folder_tree(self, progress_callback=None) -> DriveTree:
        """
        Fetch all non-trashed Drive items in one paginated sweep, then build
        the folder tree in memory. Typically 1-3 API calls regardless of Drive size.
        """
        root_id = self._get_root_id()
        items = self._fetch_all_items(progress_callback)
        tree = self._build_tree(items, root_id)
        return tree

    def _get_root_id(self) -> str:
        result = self._service.files().get(fileId="root", fields=_ROOT_FIELDS).execute()
        return result["id"]

    def _fetch_all_items(self, progress_callback=None) -> list[dict]:
        all_items = []
        page_token = None
        page = 0

        while True:
            params = {
                "q": "trashed = false",
                "fields": _LIST_FIELDS,
                "pageSize": 1000,
                "spaces": "drive",
                "includeItemsFromAllDrives": False,
            }
            if page_token:
                params["pageToken"] = page_token

            try:
                response = self._service.files().list(**params).execute()
            except HttpError as e:
                raise RuntimeError(f"Drive API error: {e}") from e

            batch = response.get("files", [])
            all_items.extend(batch)
            page += 1

            if progress_callback:
                progress_callback(len(all_items))

            page_token = response.get("nextPageToken")
            if not page_token:
                break

        return all_items

    def _build_tree(self, raw_items: list[dict], root_id: str) -> DriveTree:
        # Index items by id
        by_id: dict[str, DriveItem] = {}
        for raw in raw_items:
            by_id[raw["id"]] = DriveItem(
                id=raw["id"],
                name=raw["name"],
                mime_type=raw["mimeType"],
                modified_time=_parse_time(raw.get("modifiedTime")),
                parent_id=raw["parents"][0] if raw.get("parents") else None,
            )

        # Build parent → children map
        children_map: dict[str, list[str]] = defaultdict(list)
        for item in by_id.values():
            if item.parent_id:
                children_map[item.parent_id].append(item.id)

        # Attach children to each folder
        for parent_id, child_ids in children_map.items():
            if parent_id in by_id:
                parent = by_id[parent_id]
                parent.children = [by_id[cid] for cid in child_ids if cid in by_id]
                # Sort: folders first, then alphabetically
                parent.children.sort(key=lambda x: (not x.is_folder, x.name.lower()))

        # Find or create root node
        if root_id in by_id:
            root = by_id[root_id]
        else:
            # Root itself isn't returned by files.list, reconstruct it
            root = DriveItem(
                id=root_id,
                name="My Drive",
                mime_type=FOLDER_MIME,
                modified_time=None,
                parent_id=None,
                children=[by_id[cid] for cid in children_map.get(root_id, []) if cid in by_id],
            )
            root.children.sort(key=lambda x: (not x.is_folder, x.name.lower()))

        return DriveTree(root=root, total_items=len(by_id))


def _parse_time(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))
