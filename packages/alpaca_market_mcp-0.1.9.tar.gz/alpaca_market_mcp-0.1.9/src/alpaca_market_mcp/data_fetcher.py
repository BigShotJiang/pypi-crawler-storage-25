"""Async client for fetching OHLCV data from Alpaca Market Data API.

Replaces the old _data_fetcher.py (which read JSON files written by Claude).
This module fetches data directly via httpx, so the MCP server is self-contained.
"""

from __future__ import annotations

import asyncio
import re
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx
import pandas as pd

MARKET_DATA_BASE_URL = "https://data.alpaca.markets"

# Default lookback days per timeframe (aligned with the indicators skill)
# Lookback days per timeframe. Must be large enough for SMA 200 to have
# proper warm-up data. 1Hour needs ~365 days to get ~1600+ bars (6.5h/day
# * 252 trading days), which makes SMA 200 reliable and match TradingView.
TIMEFRAME_LOOKBACKS: dict[str, int] = {
    "15Min": 20,
    "1Hour": 365,
    "1Day": 800,
    "1Week": 1500,
    "1Month": 5000,
}

DECISION_TIMEFRAMES = ["15Min", "1Hour", "1Day"]
INFO_TIMEFRAMES = ["1Week", "1Month"]

_TIMEFRAME_ALIASES: dict[str, str] = {
    "1min": "1Min", "5min": "5Min", "15min": "15Min", "30min": "30Min",
    "1hour": "1Hour", "4hour": "4Hour",
    "1day": "1Day", "1week": "1Week", "1month": "1Month",
}

_TIMEFRAME_PATTERN = re.compile(r"^(\d+)(min|hour|day|week|month)$")


def _normalize_timeframe(tf: str) -> str:
    """Map case variants (e.g. '2hour') to API-expected format ('2Hour')."""
    lower = tf.lower().strip()
    alias = _TIMEFRAME_ALIASES.get(lower)
    if alias:
        return alias
    m = _TIMEFRAME_PATTERN.match(lower)
    if m:
        return m.group(1) + m.group(2).capitalize()
    return tf


def _relative_start(days: int) -> str:
    """ISO-8601 timestamp computed as now(UTC) minus the given days."""
    start = datetime.now(timezone.utc) - timedelta(days=days)
    return start.strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_bars(bars_list: list[dict]) -> pd.DataFrame:
    """Parse a list of Alpaca bar dicts into a DataFrame.

    Column mapping: t->timestamp, o->open, h->high, l->low, c->close, v->volume, vw->vwap
    """
    if not bars_list:
        return pd.DataFrame()

    df = pd.DataFrame(bars_list)
    df["t"] = pd.to_datetime(df["t"])
    df = df.rename(columns={
        "t": "timestamp", "o": "open", "h": "high", "l": "low",
        "c": "close", "v": "volume", "vw": "vwap", "n": "trade_count",
    })
    df = df.set_index("timestamp").sort_index()

    cols = [c for c in ["open", "high", "low", "close", "volume", "vwap", "trade_count"]
            if c in df.columns]
    return df[cols]


class AlpacaDataFetcher:
    """Async client for Alpaca Market Data API."""

    def __init__(self, api_key: str, secret_key: str, feed: str = "iex"):
        self.feed = feed
        self.client = httpx.AsyncClient(
            base_url=MARKET_DATA_BASE_URL,
            headers={
                "APCA-API-KEY-ID": api_key,
                "APCA-API-SECRET-KEY": secret_key,
            },
            timeout=30.0,
        )

    async def get_bars(
        self,
        symbol: str,
        timeframe: str = "1Day",
        days: Optional[int] = None,
        limit: int = 10000,
        adjustment: str = "split",
    ) -> pd.DataFrame:
        """Fetch OHLCV bars for a single symbol and return as DataFrame.

        Args:
            symbol: Stock ticker (e.g. "AAPL").
            timeframe: Bar aggregation period.
            days: Lookback days. Defaults to TIMEFRAME_LOOKBACKS[timeframe].
            limit: Max bars to return (1-10000).
            adjustment: Price adjustment - "raw", "split", "dividend", "all".

        Returns:
            DataFrame with OHLCV columns and DatetimeIndex.
        """
        tf = _normalize_timeframe(timeframe)
        if days is None:
            days = TIMEFRAME_LOOKBACKS.get(tf, 30)

        start = _relative_start(days)
        all_bars: list[dict] = []
        next_page_token: Optional[str] = None

        while True:
            params: dict = {
                "symbols": symbol.upper(),
                "timeframe": tf,
                "start": start,
                "limit": min(limit - len(all_bars), 10000),
                "adjustment": adjustment,
                "feed": self.feed,
                "sort": "asc",
            }
            if next_page_token:
                params["page_token"] = next_page_token

            try:
                resp = await self.client.get("/v2/stocks/bars", params=params)
            except httpx.ReadTimeout:
                break
            except httpx.HTTPError:
                break

            if resp.is_error:
                break

            data = resp.json()
            bars_dict = data.get("bars", {})
            sym_key = symbol.upper()
            bars = bars_dict.get(sym_key, [])
            all_bars.extend(bars)

            next_page_token = data.get("next_page_token")
            if not next_page_token or len(all_bars) >= limit:
                break

        return _parse_bars(all_bars)

    async def get_multi_timeframe(
        self,
        symbol: str,
        timeframes: Optional[list[str]] = None,
        include_info: bool = False,
    ) -> dict[str, pd.DataFrame]:
        """Fetch bars for multiple timeframes concurrently.

        Args:
            symbol: Stock ticker.
            timeframes: List of timeframes. Defaults to decision timeframes.
            include_info: Also fetch weekly and monthly (informative) timeframes.

        Returns:
            Dict of timeframe -> DataFrame.
        """
        if timeframes is None:
            timeframes = list(DECISION_TIMEFRAMES)
            if include_info:
                timeframes.extend(INFO_TIMEFRAMES)

        async def _fetch(tf: str) -> tuple[str, pd.DataFrame]:
            df = await self.get_bars(symbol, tf)
            return tf, df

        results = await asyncio.gather(*[_fetch(tf) for tf in timeframes])

        return {tf: df for tf, df in results if not df.empty}

    async def get_option_chain(
        self,
        symbol: str,
        option_type: Optional[str] = None,
        expiration_date: Optional[str] = None,
        expiration_date_gte: Optional[str] = None,
        expiration_date_lte: Optional[str] = None,
        strike_price_gte: Optional[float] = None,
        strike_price_lte: Optional[float] = None,
        limit: int = 1000,
    ) -> tuple[dict, Optional[str]]:
        """Fetch option chain snapshots from Alpaca using the indicative feed (free).

        Args:
            symbol: Underlying ticker (e.g. "AAPL").
            option_type: Filter by "call" or "put". None returns both.
            expiration_date: Exact expiry filter (YYYY-MM-DD).
            expiration_date_gte: Expiry >= this date (YYYY-MM-DD).
            expiration_date_lte: Expiry <= this date (YYYY-MM-DD).
            strike_price_gte: Strike >= this value.
            strike_price_lte: Strike <= this value.
            limit: Max total snapshots to return (max 1000 per page).

        Returns:
            Tuple of (snapshots_dict, error_message). On success, error is None.
        """
        all_snapshots: dict = {}
        next_page_token: Optional[str] = None

        while True:
            params: dict = {
                "feed": "indicative",
                "limit": min(max(1, limit - len(all_snapshots)), 1000),
            }
            if option_type:
                params["type"] = option_type
            if expiration_date:
                params["expiration_date"] = expiration_date
            if expiration_date_gte:
                params["expiration_date_gte"] = expiration_date_gte
            if expiration_date_lte:
                params["expiration_date_lte"] = expiration_date_lte
            if strike_price_gte is not None:
                params["strike_price_gte"] = strike_price_gte
            if strike_price_lte is not None:
                params["strike_price_lte"] = strike_price_lte
            if next_page_token:
                params["page_token"] = next_page_token

            try:
                resp = await self.client.get(
                    f"/v1beta1/options/snapshots/{symbol.upper()}",
                    params=params,
                )
            except httpx.ReadTimeout:
                return all_snapshots, "Timeout fetching option chain"
            except httpx.HTTPError as e:
                return all_snapshots, f"HTTP error: {e}"

            if resp.is_error:
                return all_snapshots, f"API error {resp.status_code}: {resp.text[:200]}"

            data = resp.json()
            snapshots = data.get("snapshots", {})
            all_snapshots.update(snapshots)

            next_page_token = data.get("next_page_token")
            if not next_page_token or len(all_snapshots) >= limit:
                break

        return all_snapshots, None

    async def close(self):
        """Close the underlying httpx client."""
        await self.client.aclose()
