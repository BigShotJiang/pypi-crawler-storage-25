"""Verify conditions for the 11 trading strategies from the options course.

Each strategy checker receives a dict of timeframe -> DataFrame and returns
a list of condition dicts: {name, passed, detail}.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from . import indicators as ind
from .formatters import fmt, fmt_pct


STRATEGY_NAMES = {
    1: "Cambio tendencia al alza (BB Hora)",
    2: "Cambio tendencia a la baja (BB Hora)",
    3: "Rebote punto medio bajista (BB Dia)",
    4: "Rebote punto medio alcista (BB Dia)",
    5: "Salido BB sin volatilidad al alza (15 Min)",
    6: "Efecto iman bajista (MA Hora + BB 15 Min)",
    7: "Efecto iman alcista (MA Hora + BB 15 Min)",
    8: "Cambio tendencia al alza (BB 15 Min)",
    9: "Cambio tendencia a la baja (BB 15 Min)",
    10: "Lateral a alcista mediano plazo (MAs)",
    11: "Lateral a bajista mediano plazo (MAs)",
}

STRATEGY_ACTIONS = {
    1: "CALL", 2: "PUT", 3: "PUT", 4: "CALL",
    5: "PUT", 6: "CALL", 7: "PUT",
    8: "CALL", 9: "PUT", 10: "CALL", 11: "PUT",
}


def _last(series):
    valid = series.dropna()
    return valid.iloc[-1] if not valid.empty else np.nan


def _prev(series):
    valid = series.dropna()
    return valid.iloc[-2] if len(valid) >= 2 else np.nan


def check_strategy_1(data):
    conditions = []
    h = data.get("1Hour")
    m15 = data.get("15Min")

    if h is not None and len(h) > 20:
        bb_h = ind.bollinger_bands(h)
        close = h["close"].iloc[-1]
        mm20 = _last(bb_h["bb_middle"])
        prev_close = h["close"].iloc[-2] if len(h) > 1 else np.nan
        prev_mm20 = _prev(bb_h["bb_middle"])

        crossed_above = (
            (close > mm20) and (prev_close <= prev_mm20)
            if not np.isnan(prev_mm20) else False
        )
        price_above = close > mm20 if not np.isnan(mm20) else False
        conditions.append({
            "name": "Precio rompe MM20 al alza en hora",
            "passed": crossed_above or price_above,
            "detail": f"Close={fmt(close)}, MM20={fmt(mm20)}",
        })

        last_candle = ind.classify_candle(h.iloc[-1])
        is_bullish = last_candle["type"] in ("Alcista", "Muy alcista")
        conditions.append({
            "name": "Vela alcista de confirmacion en hora",
            "passed": is_bullish,
            "detail": f"Vela: {last_candle['type']} ({last_candle['body_size']})",
        })

        bw = _last(bb_h["bb_bandwidth"])
        prev_bw = _prev(bb_h["bb_bandwidth"])
        vol_opening = bw > prev_bw if not (np.isnan(bw) or np.isnan(prev_bw)) else False
        conditions.append({
            "name": "Volatilidad abriendose en hora",
            "passed": vol_opening,
            "detail": f"BW actual={fmt(bw, 4)}, BW anterior={fmt(prev_bw, 4)}",
        })
    else:
        conditions.append({
            "name": "Datos hora disponibles",
            "passed": False,
            "detail": "Datos insuficientes",
        })

    if m15 is not None and len(m15) > 20:
        trend_15 = ind.bb_trend(m15)
        conditions.append({
            "name": "Tendencia alcista en BB 15min",
            "passed": trend_15 == "Alcista",
            "detail": f"Tendencia 15min: {trend_15}",
        })
    else:
        conditions.append({
            "name": "Tendencia 15min",
            "passed": False,
            "detail": "Datos 15min insuficientes",
        })

    return conditions


def check_strategy_2(data):
    conditions = []
    h = data.get("1Hour")
    m15 = data.get("15Min")

    if h is not None and len(h) > 20:
        bb_h = ind.bollinger_bands(h)
        close = h["close"].iloc[-1]
        mm20 = _last(bb_h["bb_middle"])
        prev_close = h["close"].iloc[-2] if len(h) > 1 else np.nan
        prev_mm20 = _prev(bb_h["bb_middle"])

        crossed_below = (
            (close < mm20) and (prev_close >= prev_mm20)
            if not np.isnan(prev_mm20) else False
        )
        price_below = close < mm20 if not np.isnan(mm20) else False
        conditions.append({
            "name": "Precio rompe MM20 a la baja en hora",
            "passed": crossed_below or price_below,
            "detail": f"Close={fmt(close)}, MM20={fmt(mm20)}",
        })

        last_candle = ind.classify_candle(h.iloc[-1])
        is_bearish = last_candle["type"] in ("Bajista", "Muy bajista")
        conditions.append({
            "name": "Vela bajista de confirmacion en hora",
            "passed": is_bearish,
            "detail": f"Vela: {last_candle['type']} ({last_candle['body_size']})",
        })

        bw = _last(bb_h["bb_bandwidth"])
        prev_bw = _prev(bb_h["bb_bandwidth"])
        vol_opening = bw > prev_bw if not (np.isnan(bw) or np.isnan(prev_bw)) else False
        conditions.append({
            "name": "Volatilidad abriendose en hora",
            "passed": vol_opening,
            "detail": f"BW actual={fmt(bw, 4)}, BW anterior={fmt(prev_bw, 4)}",
        })
    else:
        conditions.append({
            "name": "Datos hora disponibles",
            "passed": False,
            "detail": "Datos insuficientes",
        })

    if m15 is not None and len(m15) > 20:
        trend_15 = ind.bb_trend(m15)
        conditions.append({
            "name": "Tendencia bajista en BB 15min",
            "passed": trend_15 == "Bajista",
            "detail": f"Tendencia 15min: {trend_15}",
        })
    else:
        conditions.append({
            "name": "Tendencia 15min",
            "passed": False,
            "detail": "Datos 15min insuficientes",
        })

    return conditions


def check_strategy_3(data):
    conditions = []
    d = data.get("1Day")
    h = data.get("1Hour")
    m15 = data.get("15Min")

    if d is not None and len(d) > 20:
        trend_d = ind.bb_trend(d)
        conditions.append({
            "name": "Tendencia bajista clara en BB dia",
            "passed": trend_d == "Bajista",
            "detail": f"Tendencia dia: {trend_d}",
        })
        bb_d = ind.bollinger_bands(d)
        mm20_d = _last(bb_d["bb_middle"])
        close_d = d["close"].iloc[-1]
        dist = abs(close_d - mm20_d) / mm20_d * 100 if not np.isnan(mm20_d) and mm20_d != 0 else np.nan
        conditions.append({
            "name": "Precio cerca del punto medio diario (MM20)",
            "passed": dist < 2.0 if not np.isnan(dist) else False,
            "detail": f"Distancia: {fmt_pct(dist) if not np.isnan(dist) else '--'}",
        })
        price_respects = close_d <= mm20_d if not np.isnan(mm20_d) else False
        conditions.append({
            "name": "Precio respeta MM20 diario (no cruza al alza)",
            "passed": price_respects,
            "detail": f"Close={fmt(close_d)}, MM20 dia={fmt(mm20_d)}",
        })
    else:
        for n in ["Tendencia bajista BB dia", "Precio cerca MM20 dia", "Precio respeta MM20"]:
            conditions.append({"name": n, "passed": False, "detail": "Datos diarios insuficientes"})

    if h is not None and len(h) > 20:
        trend_h = ind.bb_trend(h)
        conditions.append({
            "name": "Tendencia alcista clara en BB hora",
            "passed": trend_h == "Alcista",
            "detail": f"Tendencia hora: {trend_h}",
        })
        last_candle = ind.classify_candle(h.iloc[-1])
        is_bearish = last_candle["type"] in ("Bajista", "Muy bajista")
        conditions.append({
            "name": "Vela bajista de confirmacion en hora",
            "passed": is_bearish,
            "detail": f"Vela: {last_candle['type']}",
        })
    else:
        conditions.append({"name": "Tendencia hora", "passed": False, "detail": "Datos hora insuficientes"})
        conditions.append({"name": "Vela confirmacion hora", "passed": False, "detail": "Datos hora insuficientes"})

    if m15 is not None and len(m15) > 5:
        recent = m15.tail(3)
        declining = recent["close"].iloc[-1] < recent["close"].iloc[0]
        conditions.append({
            "name": "BB 15min: precio comenzando a rebotar (bajar)",
            "passed": declining,
            "detail": f"Close 3 barras atras={fmt(recent['close'].iloc[0])}, actual={fmt(recent['close'].iloc[-1])}",
        })
    else:
        conditions.append({"name": "Rebote en 15min", "passed": False, "detail": "Datos 15min insuficientes"})

    return conditions


def check_strategy_4(data):
    conditions = []
    d = data.get("1Day")
    h = data.get("1Hour")
    m15 = data.get("15Min")

    if d is not None and len(d) > 20:
        trend_d = ind.bb_trend(d)
        conditions.append({
            "name": "Tendencia alcista clara en BB dia",
            "passed": trend_d == "Alcista",
            "detail": f"Tendencia dia: {trend_d}",
        })
        bb_d = ind.bollinger_bands(d)
        mm20_d = _last(bb_d["bb_middle"])
        close_d = d["close"].iloc[-1]
        dist = abs(close_d - mm20_d) / mm20_d * 100 if not np.isnan(mm20_d) and mm20_d != 0 else np.nan
        conditions.append({
            "name": "Precio cerca del punto medio diario (MM20)",
            "passed": dist < 2.0 if not np.isnan(dist) else False,
            "detail": f"Distancia: {fmt_pct(dist) if not np.isnan(dist) else '--'}",
        })
        price_respects = close_d >= mm20_d if not np.isnan(mm20_d) else False
        conditions.append({
            "name": "Precio respeta MM20 diario (no cruza a la baja)",
            "passed": price_respects,
            "detail": f"Close={fmt(close_d)}, MM20 dia={fmt(mm20_d)}",
        })
    else:
        for n in ["Tendencia alcista BB dia", "Precio cerca MM20 dia", "Precio respeta MM20"]:
            conditions.append({"name": n, "passed": False, "detail": "Datos diarios insuficientes"})

    if h is not None and len(h) > 20:
        trend_h = ind.bb_trend(h)
        conditions.append({
            "name": "Tendencia bajista clara en BB hora",
            "passed": trend_h == "Bajista",
            "detail": f"Tendencia hora: {trend_h}",
        })
        last_candle = ind.classify_candle(h.iloc[-1])
        is_bullish = last_candle["type"] in ("Alcista", "Muy alcista")
        conditions.append({
            "name": "Vela alcista de confirmacion en hora",
            "passed": is_bullish,
            "detail": f"Vela: {last_candle['type']}",
        })
    else:
        conditions.append({"name": "Tendencia hora", "passed": False, "detail": "Datos hora insuficientes"})
        conditions.append({"name": "Vela confirmacion hora", "passed": False, "detail": "Datos hora insuficientes"})

    if m15 is not None and len(m15) > 5:
        recent = m15.tail(3)
        rising = recent["close"].iloc[-1] > recent["close"].iloc[0]
        conditions.append({
            "name": "BB 15min: precio comenzando a rebotar (subir)",
            "passed": rising,
            "detail": f"Close 3 barras atras={fmt(recent['close'].iloc[0])}, actual={fmt(recent['close'].iloc[-1])}",
        })
    else:
        conditions.append({"name": "Rebote en 15min", "passed": False, "detail": "Datos 15min insuficientes"})

    return conditions


def check_strategy_5(data):
    conditions = []
    m15 = data.get("15Min")

    if m15 is not None and len(m15) > 20:
        bb = ind.bollinger_bands(m15)
        pre_gap_bw = bb["bb_bandwidth"].iloc[-10:-1].mean() if len(bb) > 10 else np.nan
        vol_state = ind.classify_volatility(pre_gap_bw) if not np.isnan(pre_gap_bw) else "--"
        low_vol = vol_state in ("Cerrados", "Extremadamente cerrados")
        conditions.append({
            "name": "Tendencia lateral y sin volatilidad en 15min (pre-apertura)",
            "passed": low_vol,
            "detail": f"Volatilidad pre-gap: {vol_state} (BW={fmt(pre_gap_bw, 4)})",
        })

        gaps = ind.detect_gaps(m15)
        last_gap = gaps.iloc[-1] if not gaps.empty else 0
        conditions.append({
            "name": "Gap up en apertura",
            "passed": last_gap > 0.5,
            "detail": f"Gap: {fmt_pct(last_gap)}",
        })

        pct_b = _last(bb["bb_pct_b"])
        conditions.append({
            "name": "Precio por encima de banda superior (%B > 1)",
            "passed": pct_b > 1.0 if not np.isnan(pct_b) else False,
            "detail": f"%B={fmt(pct_b)}",
        })

        if len(m15) >= 3:
            recent = m15["close"].tail(3)
            dropping = recent.iloc[-1] < recent.iloc[-2]
            conditions.append({
                "name": "Precio comienza a bajar",
                "passed": dropping,
                "detail": f"Close anterior={fmt(recent.iloc[-2])}, actual={fmt(recent.iloc[-1])}",
            })
        else:
            conditions.append({"name": "Precio bajando", "passed": False, "detail": "Datos insuficientes"})
    else:
        conditions.append({"name": "Datos 15min", "passed": False, "detail": "Datos 15min insuficientes"})

    return conditions


def check_strategy_6(data):
    conditions = []
    h = data.get("1Hour")
    m15 = data.get("15Min")

    if h is not None and len(h) > 40:
        ma_info = ind.ma_order(h, [20, 40])
        conditions.append({
            "name": "Tendencia bajista clara en MAs hora",
            "passed": ma_info["trend"] == "Bajista",
            "detail": f"Orden MAs: {ma_info['order']}, Tendencia: {ma_info['trend']}",
        })
        gaps = ind.detect_gaps(h)
        last_gap = gaps.iloc[-1] if not gaps.empty else 0
        conditions.append({
            "name": "Gap down fuerte en apertura",
            "passed": last_gap < -1.0,
            "detail": f"Gap: {fmt_pct(last_gap)}",
        })
        dist = ind.price_ma_distance(h, 20)
        last_dist = dist.iloc[-1] if not dist.empty else 0
        conditions.append({
            "name": "Precio muy alejado de MA20 (efecto iman)",
            "passed": last_dist < -2.0,
            "detail": f"Distancia a MA20: {fmt_pct(last_dist)}",
        })
    else:
        for n in ["Tendencia bajista MAs", "Gap down", "Distancia MA20"]:
            conditions.append({"name": n, "passed": False, "detail": "Datos hora insuficientes"})

    if m15 is not None and len(m15) > 20:
        bb = ind.bollinger_bands(m15)
        last_low = m15["low"].iloc[-1]
        last_bb_lower = _last(bb["bb_lower"])
        outside = last_low < last_bb_lower if not np.isnan(last_bb_lower) else False
        conditions.append({
            "name": "Vela completamente fuera de BB inferior en 15min",
            "passed": outside,
            "detail": f"Low={fmt(last_low)}, BB lower={fmt(last_bb_lower)}",
        })
    else:
        conditions.append({"name": "Vela fuera BB 15min", "passed": False, "detail": "Datos 15min insuficientes"})

    return conditions


def check_strategy_7(data):
    conditions = []
    h = data.get("1Hour")
    m15 = data.get("15Min")

    if h is not None and len(h) > 40:
        ma_info = ind.ma_order(h, [20, 40])
        conditions.append({
            "name": "Tendencia alcista clara en MAs hora",
            "passed": ma_info["trend"] == "Alcista",
            "detail": f"Orden MAs: {ma_info['order']}, Tendencia: {ma_info['trend']}",
        })
        gaps = ind.detect_gaps(h)
        last_gap = gaps.iloc[-1] if not gaps.empty else 0
        conditions.append({
            "name": "Gap up fuerte en apertura",
            "passed": last_gap > 1.0,
            "detail": f"Gap: {fmt_pct(last_gap)}",
        })
        dist = ind.price_ma_distance(h, 20)
        last_dist = dist.iloc[-1] if not dist.empty else 0
        conditions.append({
            "name": "Precio muy alejado de MA20 (efecto iman)",
            "passed": last_dist > 2.0,
            "detail": f"Distancia a MA20: {fmt_pct(last_dist)}",
        })
    else:
        for n in ["Tendencia alcista MAs", "Gap up", "Distancia MA20"]:
            conditions.append({"name": n, "passed": False, "detail": "Datos hora insuficientes"})

    if m15 is not None and len(m15) > 20:
        bb = ind.bollinger_bands(m15)
        last_high = m15["high"].iloc[-1]
        last_bb_upper = _last(bb["bb_upper"])
        outside = last_high > last_bb_upper if not np.isnan(last_bb_upper) else False
        conditions.append({
            "name": "Vela completamente fuera de BB superior en 15min",
            "passed": outside,
            "detail": f"High={fmt(last_high)}, BB upper={fmt(last_bb_upper)}",
        })
    else:
        conditions.append({"name": "Vela fuera BB 15min", "passed": False, "detail": "Datos 15min insuficientes"})

    return conditions


def check_strategy_8(data):
    conditions = []
    m15 = data.get("15Min")

    if m15 is not None and len(m15) > 20:
        pre_trend = ind.bb_trend(m15.iloc[:-3]) if len(m15) > 23 else ind.bb_trend(m15)
        conditions.append({
            "name": "Tendencia bajista o lateral pre-gap en 15min",
            "passed": pre_trend in ("Bajista", "Lateral"),
            "detail": f"Tendencia pre-gap: {pre_trend}",
        })
        bb = ind.bollinger_bands(m15)
        mm20 = _last(bb["bb_middle"])
        gaps = ind.detect_gaps(m15)
        last_gap = gaps.iloc[-1] if not gaps.empty else 0
        close = m15["close"].iloc[-1]
        conditions.append({
            "name": "Gap up rompe MM20",
            "passed": last_gap > 0.3 and close > mm20 if not np.isnan(mm20) else False,
            "detail": f"Gap: {fmt_pct(last_gap)}, Close={fmt(close)}, MM20={fmt(mm20)}",
        })
        bw = _last(bb["bb_bandwidth"])
        prev_bw = _prev(bb["bb_bandwidth"])
        vol_opening = bw > prev_bw * 1.1 if not (np.isnan(bw) or np.isnan(prev_bw)) else False
        conditions.append({
            "name": "Volatilidad se abre en 15min",
            "passed": vol_opening,
            "detail": f"BW actual={fmt(bw, 4)}, BW anterior={fmt(prev_bw, 4)}",
        })
    else:
        conditions.append({"name": "Datos 15min", "passed": False, "detail": "Datos insuficientes"})

    return conditions


def check_strategy_9(data):
    conditions = []
    m15 = data.get("15Min")

    if m15 is not None and len(m15) > 20:
        pre_trend = ind.bb_trend(m15.iloc[:-3]) if len(m15) > 23 else ind.bb_trend(m15)
        conditions.append({
            "name": "Tendencia alcista o lateral pre-gap en 15min",
            "passed": pre_trend in ("Alcista", "Lateral"),
            "detail": f"Tendencia pre-gap: {pre_trend}",
        })
        bb = ind.bollinger_bands(m15)
        mm20 = _last(bb["bb_middle"])
        gaps = ind.detect_gaps(m15)
        last_gap = gaps.iloc[-1] if not gaps.empty else 0
        close = m15["close"].iloc[-1]
        conditions.append({
            "name": "Gap down rompe MM20",
            "passed": last_gap < -0.3 and close < mm20 if not np.isnan(mm20) else False,
            "detail": f"Gap: {fmt_pct(last_gap)}, Close={fmt(close)}, MM20={fmt(mm20)}",
        })
        bw = _last(bb["bb_bandwidth"])
        prev_bw = _prev(bb["bb_bandwidth"])
        vol_opening = bw > prev_bw * 1.1 if not (np.isnan(bw) or np.isnan(prev_bw)) else False
        conditions.append({
            "name": "Volatilidad se abre en 15min",
            "passed": vol_opening,
            "detail": f"BW actual={fmt(bw, 4)}, BW anterior={fmt(prev_bw, 4)}",
        })
    else:
        conditions.append({"name": "Datos 15min", "passed": False, "detail": "Datos insuficientes"})

    return conditions


def check_strategy_10(data):
    conditions = []
    d = data.get("1Day")
    h = data.get("1Hour")

    if d is not None and len(d) > 20:
        ma_info = ind.ma_order(d)
        is_lateral = ma_info["trend"] == "Lateral/Entrelazadas" or ma_info["strength"] == "Debil"
        conditions.append({
            "name": "4 MAs laterales o entrelazadas",
            "passed": is_lateral,
            "detail": f"Orden: {ma_info['order']}, Fuerza: {ma_info['strength']}",
        })

        # Measure lateral channel using 10-day rolling price range (high-low / avg).
        # Avoids SMA200 warmup problem and directly reflects price consolidation.
        rolling_high = d["high"].rolling(10).max()
        rolling_low = d["low"].rolling(10).min()
        rolling_avg = d["close"].rolling(10).mean()
        channel_pct = ((rolling_high - rolling_low) / rolling_avg * 100).dropna()
        tight_days = 0
        for val in reversed(channel_pct.values):
            if val < 8.0:
                tight_days += 1
            else:
                break
        conditions.append({
            "name": "Precio en canal lateral 10+ dias (rango 10d < 8%)",
            "passed": tight_days >= 10,
            "detail": f"Dias consecutivos en canal estrecho: {tight_days}",
        })

        last_candle = ind.classify_candle(d.iloc[-1])
        is_bullish = last_candle["type"] in ("Alcista", "Muy alcista")
        conditions.append({
            "name": "Senal alcista (vela de confirmacion)",
            "passed": is_bullish,
            "detail": f"Ultima vela dia: {last_candle['type']}",
        })
        mas = ind.all_smas(d)
        close = d["close"].iloc[-1]
        ma_max = max(mas.iloc[-1].dropna().values) if not mas.iloc[-1].dropna().empty else np.nan
        conditions.append({
            "name": "Precio rompe canal al alza",
            "passed": close > ma_max if not np.isnan(ma_max) else False,
            "detail": f"Close={fmt(close)}, Max MA={fmt(ma_max)}",
        })
    else:
        for n in ["MAs laterales", "Canal 10+ dias", "Senal alcista", "Rompe canal"]:
            conditions.append({"name": n, "passed": False, "detail": "Datos diarios insuficientes"})

    if h is not None and len(h) > 20:
        bb_h = ind.bollinger_bands(h)
        bw = _last(bb_h["bb_bandwidth"])
        vol_state = ind.classify_volatility(bw) if not np.isnan(bw) else "--"
        high_vol = vol_state in ("Abiertos", "Muy abiertos")
        conditions.append({
            "name": "BB hora con alta volatilidad",
            "passed": high_vol,
            "detail": f"Volatilidad hora: {vol_state}",
        })
    else:
        conditions.append({"name": "Volatilidad hora", "passed": False, "detail": "Datos hora insuficientes"})

    return conditions


def check_strategy_11(data):
    conditions = []
    d = data.get("1Day")
    h = data.get("1Hour")

    if d is not None and len(d) > 20:
        ma_info = ind.ma_order(d)
        is_lateral = ma_info["trend"] == "Lateral/Entrelazadas" or ma_info["strength"] == "Debil"
        conditions.append({
            "name": "4 MAs laterales o entrelazadas",
            "passed": is_lateral,
            "detail": f"Orden: {ma_info['order']}, Fuerza: {ma_info['strength']}",
        })

        # Measure lateral channel using 10-day rolling price range (high-low / avg).
        # Avoids SMA200 warmup problem and directly reflects price consolidation.
        rolling_high = d["high"].rolling(10).max()
        rolling_low = d["low"].rolling(10).min()
        rolling_avg = d["close"].rolling(10).mean()
        channel_pct = ((rolling_high - rolling_low) / rolling_avg * 100).dropna()
        tight_days = 0
        for val in reversed(channel_pct.values):
            if val < 8.0:
                tight_days += 1
            else:
                break
        conditions.append({
            "name": "Precio en canal lateral 10+ dias (rango 10d < 8%)",
            "passed": tight_days >= 10,
            "detail": f"Dias consecutivos en canal estrecho: {tight_days}",
        })

        last_candle = ind.classify_candle(d.iloc[-1])
        is_bearish = last_candle["type"] in ("Bajista", "Muy bajista")
        conditions.append({
            "name": "Senal bajista (vela de confirmacion)",
            "passed": is_bearish,
            "detail": f"Ultima vela dia: {last_candle['type']}",
        })
        mas = ind.all_smas(d)
        close = d["close"].iloc[-1]
        ma_min = min(mas.iloc[-1].dropna().values) if not mas.iloc[-1].dropna().empty else np.nan
        conditions.append({
            "name": "Precio rompe canal a la baja",
            "passed": close < ma_min if not np.isnan(ma_min) else False,
            "detail": f"Close={fmt(close)}, Min MA={fmt(ma_min)}",
        })
    else:
        for n in ["MAs laterales", "Canal 10+ dias", "Senal bajista", "Rompe canal"]:
            conditions.append({"name": n, "passed": False, "detail": "Datos diarios insuficientes"})

    if h is not None and len(h) > 20:
        bb_h = ind.bollinger_bands(h)
        bw = _last(bb_h["bb_bandwidth"])
        vol_state = ind.classify_volatility(bw) if not np.isnan(bw) else "--"
        high_vol = vol_state in ("Abiertos", "Muy abiertos")
        conditions.append({
            "name": "BB hora con alta volatilidad",
            "passed": high_vol,
            "detail": f"Volatilidad hora: {vol_state}",
        })
    else:
        conditions.append({"name": "Volatilidad hora", "passed": False, "detail": "Datos hora insuficientes"})

    return conditions


STRATEGY_CHECKERS = {
    1: check_strategy_1, 2: check_strategy_2,
    3: check_strategy_3, 4: check_strategy_4,
    5: check_strategy_5, 6: check_strategy_6,
    7: check_strategy_7, 8: check_strategy_8,
    9: check_strategy_9, 10: check_strategy_10,
    11: check_strategy_11,
}


def check_all_strategies(data: dict[str, pd.DataFrame]) -> list[dict]:
    """Run all 11 strategies and return structured results."""
    results = []
    for num in range(1, 12):
        conditions = STRATEGY_CHECKERS[num](data)
        passed = sum(1 for c in conditions if c["passed"])
        total = len(conditions)
        pct = passed / total if total > 0 else 0
        if pct >= 1.0:
            status = "CUMPLIDA"
        elif pct >= 0.6:
            status = "PARCIAL"
        else:
            status = "NO CUMPLIDA"
        results.append({
            "strategy": num,
            "name": STRATEGY_NAMES[num],
            "action": STRATEGY_ACTIONS[num],
            "status": status,
            "passed": passed,
            "total": total,
            "percentage": round(pct * 100, 1),
            "conditions": conditions,
        })
    return results
