"""Pure calculation functions for all technical indicators.

All functions accept a pandas DataFrame with OHLCV columns and return
Series or DataFrames. No I/O or side effects.

Indicators aligned with the options trading course:
- Bollinger Bands (50% weight) - period 20, std 2.0
- Moving Averages (25% weight) - SMA 20, 40, 100, 200
- Candlestick analysis (15% weight)
- Volume analysis (5% weight)
- Worden Stochastics (5% weight) - K=14, D=3, Smooth=3
"""

from __future__ import annotations

import numpy as np
import pandas as pd


# =============================================================================
# Bollinger Bands (50% weight)
# =============================================================================

def bollinger_bands(df: pd.DataFrame, period: int = 20, num_std: float = 2.0) -> pd.DataFrame:
    """Calculate Bollinger Bands.

    Returns DataFrame with columns:
        bb_middle (SMA), bb_upper, bb_lower, bb_pct_b, bb_bandwidth
    """
    close = df["close"]
    middle = close.rolling(window=period).mean()
    std = close.rolling(window=period).std()
    upper = middle + num_std * std
    lower = middle - num_std * std
    pct_b = (close - lower) / (upper - lower)
    bandwidth = (upper - lower) / middle

    return pd.DataFrame({
        "bb_middle": middle,
        "bb_upper": upper,
        "bb_lower": lower,
        "bb_pct_b": pct_b,
        "bb_bandwidth": bandwidth,
    }, index=df.index)


def classify_volatility(bandwidth: float) -> str:
    """Classify BB bandwidth into volatility state (from course).

    The course defines: Cerrados, Extremadamente cerrados, Abiertos,
    Muy abiertos, Extremadamente abiertos.
    """
    if bandwidth < 0.02:
        return "Extremadamente cerrados"
    elif bandwidth < 0.05:
        return "Cerrados"
    elif bandwidth < 0.10:
        return "Normal"
    elif bandwidth < 0.20:
        return "Abiertos"
    else:
        return "Muy abiertos"


def bb_trend(df: pd.DataFrame, period: int = 20, lookback: int = 5) -> str:
    """Determine trend direction from MM20 slope.

    Uses the slope of the last `lookback` bars of the middle band.
    Returns: "Alcista", "Bajista", or "Lateral".
    """
    middle = df["close"].rolling(window=period).mean()
    recent = middle.dropna().tail(lookback)
    if len(recent) < 2:
        return "Lateral"

    # Linear regression slope
    x = np.arange(len(recent), dtype=float)
    y = recent.values
    slope = np.polyfit(x, y, 1)[0]

    # Normalize slope by price level
    avg_price = y.mean()
    if avg_price == 0:
        return "Lateral"
    norm_slope = slope / avg_price

    if norm_slope > 0.001:
        return "Alcista"
    elif norm_slope < -0.001:
        return "Bajista"
    else:
        return "Lateral"


def price_bb_distance(df: pd.DataFrame, period: int = 20) -> pd.Series:
    """Distance of price to nearest BB band as % of middle band.

    Positive = price above upper, Negative = price below lower, 0 = within bands.
    Useful for detecting "ley de atraccion" (price far from dissipator).
    """
    bb = bollinger_bands(df, period)
    close = df["close"]
    dist = pd.Series(0.0, index=df.index)
    above = close > bb["bb_upper"]
    below = close < bb["bb_lower"]
    dist[above] = ((close[above] - bb["bb_upper"][above]) / bb["bb_middle"][above]) * 100
    dist[below] = ((close[below] - bb["bb_lower"][below]) / bb["bb_middle"][below]) * 100
    return dist


# =============================================================================
# Moving Averages (25% weight) - Course periods: 20, 40, 100, 200
# =============================================================================

def sma(df: pd.DataFrame, period: int, column: str = "close") -> pd.Series:
    """Simple Moving Average."""
    return df[column].rolling(window=period).mean()


def ema(df: pd.DataFrame, period: int, column: str = "close") -> pd.Series:
    """Exponential Moving Average."""
    return df[column].ewm(span=period, adjust=False).mean()


def all_smas(df: pd.DataFrame, periods: list[int] | None = None) -> pd.DataFrame:
    """Calculate all SMA periods from the course.

    Default periods: [20, 40, 100, 200]
    """
    if periods is None:
        periods = [20, 40, 100, 200]
    result = {}
    for p in periods:
        result[f"sma_{p}"] = sma(df, p)
    return pd.DataFrame(result, index=df.index)


def ma_order(df: pd.DataFrame, periods: list[int] | None = None) -> dict:
    """Analyze MA ordering to determine trend (from course).

    Course rules:
    - 20 > 40 > 100 > 200 ascending = Alcista (bullish) long-term
    - 20 < 40 < 100 < 200 descending = Bajista (bearish) long-term
    - Otherwise = Lateral / Entrelazadas

    Returns dict with: order_str, trend, strength
    """
    if periods is None:
        periods = [20, 40, 100, 200]
    mas = all_smas(df, periods)
    last = mas.iloc[-1]
    values = [last[f"sma_{p}"] for p in periods]

    if any(np.isnan(v) for v in values):
        return {"order": "N/A (datos insuficientes)", "trend": "N/A", "strength": "N/A"}

    # Check if all in ascending order (bullish: smaller period MA above larger)
    bullish = all(values[i] > values[i + 1] for i in range(len(values) - 1))
    # Check if all in descending order (bearish: smaller period MA below larger)
    bearish = all(values[i] < values[i + 1] for i in range(len(values) - 1))

    if bullish:
        order_str = ">".join(str(p) for p in periods)
        trend = "Alcista"
    elif bearish:
        order_str = "<".join(str(p) for p in periods)
        trend = "Bajista"
    else:
        # Partial ordering
        sorted_vals = sorted(zip(periods, values), key=lambda x: x[1], reverse=True)
        order_str = ">".join(str(p) for p, _ in sorted_vals)
        trend = "Lateral/Entrelazadas"

    # Strength: based on separation between MAs
    spread = (max(values) - min(values)) / np.mean(values) * 100
    if spread > 10:
        strength = "Muy fuerte"
    elif spread > 5:
        strength = "Fuerte"
    elif spread > 2:
        strength = "Moderada"
    else:
        strength = "Debil"

    return {"order": order_str, "trend": trend, "strength": strength}


def ma_channel(df: pd.DataFrame, period1: int = 20, period2: int = 40, lookback: int = 10) -> str:
    """Detect if two MAs form a channel (ascending/descending/interleaved).

    Course: MAs in ascending channel = bullish, descending = bearish.
    """
    ma1 = sma(df, period1).dropna().tail(lookback)
    ma2 = sma(df, period2).dropna().tail(lookback)
    if len(ma1) < lookback or len(ma2) < lookback:
        return "Datos insuficientes"

    ma1_slope = np.polyfit(np.arange(len(ma1)), ma1.values, 1)[0]
    ma2_slope = np.polyfit(np.arange(len(ma2)), ma2.values, 1)[0]
    above = (ma1.values > ma2.values).all()
    below = (ma1.values < ma2.values).all()

    if above and ma1_slope > 0 and ma2_slope > 0:
        return "Canal alcista"
    elif below and ma1_slope < 0 and ma2_slope < 0:
        return "Canal bajista"
    elif above or below:
        return "Canal lateral"
    else:
        return "Entrelazadas"


def price_ma_distance(df: pd.DataFrame, period: int = 20) -> pd.Series:
    """Percentage distance of price from MA.

    Course: Price never stays far from MA20 - after 2-5 days without touching, return is imminent.
    """
    ma = sma(df, period)
    return ((df["close"] - ma) / ma) * 100


def ma_crossovers(df: pd.DataFrame, fast: int = 20, slow: int = 40) -> pd.Series:
    """Detect MA crossovers.

    Returns Series with values: "Golden cross", "Death cross", or "".
    """
    fast_ma = sma(df, fast)
    slow_ma = sma(df, slow)
    prev_fast = fast_ma.shift(1)
    prev_slow = slow_ma.shift(1)

    golden = (fast_ma > slow_ma) & (prev_fast <= prev_slow)
    death = (fast_ma < slow_ma) & (prev_fast >= prev_slow)

    result = pd.Series("", index=df.index)
    result[golden] = "Golden cross"
    result[death] = "Death cross"
    return result


def days_since_ma_touch(df: pd.DataFrame, period: int = 20, threshold_pct: float = 0.3) -> int:
    """Count bars since price last touched the MA (within threshold %).

    Course: After 2-5 days without touching MA20, return is imminent.
    """
    ma = sma(df, period)
    dist_pct = ((df["close"] - ma) / ma).abs() * 100
    touches = dist_pct < threshold_pct
    if touches.any():
        last_touch_idx = touches[::-1].idxmax()
        return len(df.loc[last_touch_idx:]) - 1
    return len(df)


# =============================================================================
# Candlestick Analysis (15% weight)
# =============================================================================

def classify_candle(row) -> dict:
    """Classify a single OHLC bar into candle type.

    Course types: Muy alcista | Alcista | Neutral | Bajista | Muy bajista
    Based on body-to-range ratio and direction.
    """
    o, h, l, c = row["open"], row["high"], row["low"], row["close"]
    total_range = h - l
    if total_range == 0:
        return {"type": "Neutral", "body_size": "Doji", "upper_wick": 0, "lower_wick": 0}

    body = abs(c - o)
    body_ratio = body / total_range
    is_bullish = c >= o

    upper_wick = (h - max(o, c)) / total_range
    lower_wick = (min(o, c) - l) / total_range

    if body_ratio > 0.7:
        body_size = "Grande"
        candle_type = "Muy alcista" if is_bullish else "Muy bajista"
    elif body_ratio > 0.4:
        body_size = "Mediano"
        candle_type = "Alcista" if is_bullish else "Bajista"
    else:
        body_size = "Pequeno"
        candle_type = "Neutral"

    return {
        "type": candle_type,
        "body_size": body_size,
        "upper_wick": round(upper_wick, 3),
        "lower_wick": round(lower_wick, 3),
    }


def classify_candles(df: pd.DataFrame) -> pd.DataFrame:
    """Classify all candles in a DataFrame."""
    results = df.apply(classify_candle, axis=1, result_type="expand")
    return results


def detect_gaps(df: pd.DataFrame) -> pd.Series:
    """Detect gaps between consecutive bars.

    Gap % = (open_current - close_previous) / close_previous * 100
    Course: Gaps are critical for strategies 5-9.
    """
    prev_close = df["close"].shift(1)
    gap_pct = ((df["open"] - prev_close) / prev_close) * 100
    return gap_pct



# =============================================================================
# Volume Analysis (5% weight)
# =============================================================================

def volume_analysis(df: pd.DataFrame, period: int = 20) -> pd.DataFrame:
    """Analyze volume relative to its moving average.

    Returns DataFrame with: vol_sma, vol_ratio, vol_class
    """
    vol = df["volume"]
    vol_sma_val = vol.rolling(window=period).mean()
    vol_ratio = vol / vol_sma_val

    def classify(ratio):
        if pd.isna(ratio):
            return "--"
        if ratio > 2.0:
            return "Muy alto"
        elif ratio > 1.3:
            return "Alto"
        elif ratio > 0.7:
            return "Normal"
        else:
            return "Bajo"

    vol_class = vol_ratio.map(classify)

    return pd.DataFrame({
        "vol_sma": vol_sma_val,
        "vol_ratio": vol_ratio,
        "vol_class": vol_class,
    }, index=df.index)


# =============================================================================
# Worden Stochastics (5% weight) - Slow Stochastic: K=14, D=3, Smooth=3
# =============================================================================

def stochastic(
    df: pd.DataFrame, k_period: int = 14, d_period: int = 3, smooth_k: int = 3
) -> pd.DataFrame:
    """Calculate Slow Stochastic Oscillator.

    1. raw_k = 100 * (close - lowest_low) / (highest_high - lowest_low)
    2. stoch_k = SMA(raw_k, smooth_k)  [slow stochastic]
    3. stoch_d = SMA(stoch_k, d_period)

    Returns DataFrame with: stoch_k, stoch_d
    """
    low_min = df["low"].rolling(window=k_period).min()
    high_max = df["high"].rolling(window=k_period).max()
    raw_k = 100 * (df["close"] - low_min) / (high_max - low_min)
    stoch_k = raw_k.rolling(window=smooth_k).mean()
    stoch_d = stoch_k.rolling(window=d_period).mean()

    return pd.DataFrame({
        "stoch_k": stoch_k,
        "stoch_d": stoch_d,
    }, index=df.index)


def stochastic_zone(k: float) -> str:
    """Classify stochastic %K into zone."""
    if pd.isna(k):
        return "--"
    if k > 80:
        return "Sobrecompra"
    elif k < 20:
        return "Sobreventa"
    else:
        return "Neutral"


def stochastic_signal(k: float, d: float, prev_k: float, prev_d: float) -> str:
    """Detect stochastic crossover signals.

    Course: %K crossing %D = entry/exit signal.
    """
    if any(pd.isna(v) for v in [k, d, prev_k, prev_d]):
        return "--"
    if prev_k <= prev_d and k > d:
        if k < 20:
            return "Bullish cross (sobreventa)"
        return "Bullish cross"
    elif prev_k >= prev_d and k < d:
        if k > 80:
            return "Bearish cross (sobrecompra)"
        return "Bearish cross"
    return ""


# =============================================================================
# Optional extras (not in course but useful)
# =============================================================================

def rsi(df: pd.DataFrame, period: int = 14, column: str = "close") -> pd.Series:
    """Relative Strength Index using Wilder's smoothing."""
    delta = df[column].diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def macd(
    df: pd.DataFrame, fast: int = 12, slow: int = 26, signal: int = 9, column: str = "close"
) -> pd.DataFrame:
    """MACD (Moving Average Convergence Divergence).

    Returns DataFrame with: macd_line, macd_signal, macd_histogram
    """
    ema_fast = ema(df, fast, column)
    ema_slow = ema(df, slow, column)
    macd_line = ema_fast - ema_slow
    macd_signal = macd_line.ewm(span=signal, adjust=False).mean()
    macd_hist = macd_line - macd_signal

    return pd.DataFrame({
        "macd_line": macd_line,
        "macd_signal": macd_signal,
        "macd_histogram": macd_hist,
    }, index=df.index)


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Average True Range using Wilder's smoothing."""
    high = df["high"]
    low = df["low"]
    prev_close = df["close"].shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
