"""
Alpaca Market Analysis MCP Server

FastMCP server that fetches OHLCV data from Alpaca, computes technical
indicators (BB, MAs, Stochastics, candles, volume), and evaluates the
11 trading strategies from the options course.
"""

from __future__ import annotations

import asyncio
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Optional, Any

import numpy as np
import pandas as pd
from fastmcp import FastMCP

from . import indicators as ind
from .data_fetcher import AlpacaDataFetcher
from .formatters import fmt, fmt_pct, tf_display
from .strategies import (
    STRATEGY_ACTIONS,
    STRATEGY_CHECKERS,
    STRATEGY_NAMES,
    check_all_strategies,
)


def _build_summary(data: dict[str, pd.DataFrame]) -> Any:
    """Build a per-timeframe summary dict."""
    summary = {}
    for tf, df in data.items():
        if df.empty or len(df) < 5:
            continue
        entry: dict = {}

        # BB trend & volatility
        entry["trend_bb"] = ind.bb_trend(df)
        bb = ind.bollinger_bands(df)
        bw = bb["bb_bandwidth"].dropna()
        entry["volatility"] = ind.classify_volatility(bw.iloc[-1]) if not bw.empty else "--"

        # MA order (need at least 40 bars for SMA40)
        if len(df) >= 40:
            available_periods = [p for p in [20, 40, 100, 200] if len(df) >= p]
            if len(available_periods) >= 2:
                info = ind.ma_order(df, available_periods)
                entry["ma_order"] = info["order"]
            else:
                entry["ma_order"] = "--"
        else:
            entry["ma_order"] = "--"

        # Stochastic
        stoch = ind.stochastic(df)
        k = stoch["stoch_k"].dropna()
        entry["stoch_k"] = round(float(k.iloc[-1]), 1) if not k.empty else None

        # Last candle
        last_candle = ind.classify_candle(df.iloc[-1])
        entry["last_candle"] = last_candle["type"]

        summary[tf] = entry
    return summary


def _build_bollinger(data: dict[str, pd.DataFrame], rows: int) -> Any:
    """Build Bollinger Bands section."""
    result = {}
    for tf, df in data.items():
        if df.empty or len(df) < 20:
            continue
        bb = ind.bollinger_bands(df)
        bw_last = bb["bb_bandwidth"].dropna()
        trend = ind.bb_trend(df)
        vol = ind.classify_volatility(float(bw_last.iloc[-1])) if not bw_last.empty else "--"

        current = {
            "close": float(df["close"].iloc[-1]),
            "bb_lower": float(bb["bb_lower"].dropna().iloc[-1]),
            "bb_middle": float(bb["bb_middle"].dropna().iloc[-1]),
            "bb_upper": float(bb["bb_upper"].dropna().iloc[-1]),
            "pct_b": round(float(bb["bb_pct_b"].dropna().iloc[-1]), 3),
            "bandwidth": round(float(bw_last.iloc[-1]), 4),
        }

        # Recent rows
        merged = df[["close"]].join(bb).tail(rows)
        recent = []
        for ts, row in merged.iterrows():
            recent.append(
                {
                    "date": str(ts),
                    "close": round(float(row["close"]), 2),
                    "lower": round(float(row["bb_lower"]), 2)
                    if not np.isnan(row["bb_lower"])
                    else None,
                    "middle": round(float(row["bb_middle"]), 2)
                    if not np.isnan(row["bb_middle"])
                    else None,
                    "upper": round(float(row["bb_upper"]), 2)
                    if not np.isnan(row["bb_upper"])
                    else None,
                    "pct_b": round(float(row["bb_pct_b"]), 3)
                    if not np.isnan(row["bb_pct_b"])
                    else None,
                    "bandwidth": round(float(row["bb_bandwidth"]), 4)
                    if not np.isnan(row["bb_bandwidth"])
                    else None,
                }
            )

        result[tf] = {
            "trend": trend,
            "volatility": vol,
            "current": current,
            "recent": recent,
        }
    return result


def _build_moving_averages(data: dict[str, pd.DataFrame], rows: int) -> Any:
    """Build Moving Averages section (only for 1Hour+ timeframes)."""
    result = {}
    for tf, df in data.items():
        if df.empty or len(df) < 40:
            continue

        available_periods = [p for p in [20, 40, 100, 200] if len(df) >= p]
        if len(available_periods) < 2:
            continue

        mas = ind.all_smas(df, available_periods)
        info = ind.ma_order(df, available_periods)
        channel = ind.ma_channel(df)
        crossovers = ind.ma_crossovers(df)
        dist_ma20 = ind.price_ma_distance(df, 20)
        touch_days = ind.days_since_ma_touch(df)

        # Current values
        current = {}
        for p in available_periods:
            val = mas[f"sma_{p}"].dropna()
            current[f"sma_{p}"] = round(float(val.iloc[-1]), 2) if not val.empty else None

        current["order"] = info["order"]
        current["trend"] = info["trend"]
        current["strength"] = info["strength"]
        current["channel_20_40"] = channel
        current["days_since_ma20_touch"] = touch_days
        current["distance_from_ma20_pct"] = (
            round(float(dist_ma20.iloc[-1]), 2) if not dist_ma20.empty else None
        )

        # Recent crossovers
        recent_cross = crossovers[crossovers != ""]
        cross_list = []
        for ts, signal in recent_cross.tail(3).items():
            cross_list.append({"date": str(ts), "signal": signal})

        # Recent rows
        merged = df[["close"]].join(mas).tail(rows)
        dist_tail = dist_ma20.tail(rows)
        recent = []
        for (ts, row), d in zip(merged.iterrows(), dist_tail):
            entry = {"date": str(ts), "close": round(float(row["close"]), 2)}
            for p in available_periods:
                col = f"sma_{p}"
                entry[col] = round(float(row[col]), 2) if not np.isnan(row[col]) else None
            entry["dist_ma20"] = round(float(d), 2) if not np.isnan(d) else None
            recent.append(entry)

        result[tf] = {
            "current": current,
            "crossovers": cross_list,
            "recent": recent,
        }
    return result


def _build_candles(data: dict[str, pd.DataFrame], rows: int) -> Any:
    """Build candlestick analysis section."""
    result = {}
    for tf, df in data.items():
        if df.empty or len(df) < 3:
            continue
        candles = ind.classify_candles(df)
        gaps = ind.detect_gaps(df)
        last_candle = ind.classify_candle(df.iloc[-1])

        tail_df = df.tail(rows)
        tail_candles = candles.tail(rows)
        tail_gaps = gaps.tail(rows)
        recent = []
        for (ts, row), (_, candle), gap in zip(
            tail_df.iterrows(), tail_candles.iterrows(), tail_gaps
        ):
            recent.append(
                {
                    "date": str(ts),
                    "open": round(float(row["open"]), 2),
                    "close": round(float(row["close"]), 2),
                    "type": candle["type"],
                    "body_size": candle["body_size"],
                    "gap_pct": round(float(gap), 2) if not np.isnan(gap) else None,
                }
            )

        result[tf] = {
            "last": last_candle,
            "recent": recent,
        }
    return result


def _build_stochastics(data: dict[str, pd.DataFrame]) -> Any:
    """Build stochastics section."""
    result = {}
    for tf, df in data.items():
        if df.empty or len(df) < 20:
            continue
        stoch = ind.stochastic(df)
        k_series = stoch["stoch_k"].dropna()
        d_series = stoch["stoch_d"].dropna()
        if k_series.empty:
            continue

        k = float(k_series.iloc[-1])
        d = float(d_series.iloc[-1]) if not d_series.empty else np.nan
        prev_k = float(k_series.iloc[-2]) if len(k_series) >= 2 else np.nan
        prev_d = float(d_series.iloc[-2]) if len(d_series) >= 2 else np.nan

        result[tf] = {
            "k": round(k, 1),
            "d": round(d, 1) if not np.isnan(d) else None,
            "zone": ind.stochastic_zone(k),
            "signal": ind.stochastic_signal(k, d, prev_k, prev_d),
        }
    return result


def _build_volume(data: dict[str, pd.DataFrame]) -> Any:
    """Build volume section (typically only 1Day)."""
    result = {}
    for tf in ["1Day", "1Hour"]:
        df = data.get(tf)
        if df is None or df.empty or len(df) < 20:
            continue
        vol = ind.volume_analysis(df)
        last = vol.iloc[-1]
        result[tf] = {
            "current_volume": int(df["volume"].iloc[-1]),
            "sma_20": int(last["vol_sma"]) if not np.isnan(last["vol_sma"]) else None,
            "ratio": round(float(last["vol_ratio"]), 2)
            if not np.isnan(last["vol_ratio"])
            else None,
            "classification": last["vol_class"],
        }
    return result


def build_server(feed: str = "iex") -> FastMCP:
    """Construct the Alpaca Market Analysis MCP server."""
    api_key = os.environ.get("ALPACA_API_KEY", "")
    secret_key = os.environ.get("ALPACA_SECRET_KEY", "")
    fetcher = AlpacaDataFetcher(api_key, secret_key, feed=feed)

    @asynccontextmanager
    async def lifespan(_server: FastMCP) -> AsyncIterator[dict]:
        try:
            yield {}
        finally:
            await fetcher.close()

    mcp = FastMCP("Alpaca Market Analysis", lifespan=lifespan)

    # ── Tool 1: analyze_ticker ────────────────────────────────────────────

    @mcp.tool(annotations={"title": "Analyze Ticker", "readOnlyHint": True})
    async def analyze_ticker(
        symbol: str,
        include_info: bool = False,
        indicator: Optional[str] = None,
        rows: int = 15,
    ) -> Any:
        """Full multi-timeframe technical analysis for a stock ticker.

        Fetches OHLCV data from Alpaca and computes Bollinger Bands, Moving Averages
        (SMA 20/40/100/200), candlestick patterns, volume analysis, and Stochastics
        across 15-minute, 1-hour, and daily timeframes.

        Args:
            symbol: Stock ticker (e.g. "AAPL", "MSFT").
            include_info: Include weekly and monthly informative timeframes.
            indicator: Show only one indicator: "bb", "ma", "candles", "volume",
                       "stoch", "rsi", "macd". Omit for full analysis.
            rows: Number of recent data points per timeframe (default 15).
        """
        # fetcher is captured via closure from build_server()

        data = await fetcher.get_multi_timeframe(symbol, include_info=include_info)
        if not data:
            return {"error": f"No data found for {symbol}. Check the ticker symbol."}

        result: dict = {"symbol": symbol.upper(), "timeframes_available": list(data.keys())}

        if indicator is None or indicator == "summary":
            result["summary"] = _build_summary(data)

        if indicator is None or indicator == "bb":
            result["bollinger"] = _build_bollinger(data, rows)

        if indicator is None or indicator == "ma":
            result["moving_averages"] = _build_moving_averages(data, rows)

        if indicator is None or indicator == "candles":
            result["candles"] = _build_candles(data, min(rows, 10))

        if indicator is None or indicator == "stoch":
            result["stochastics"] = _build_stochastics(data)

        if indicator is None or indicator == "volume":
            result["volume"] = _build_volume(data)

        if indicator == "rsi":
            rsi_result = {}
            for tf, df in data.items():
                if len(df) >= 14:
                    rsi_series = ind.rsi(df)
                    val = rsi_series.dropna()
                    if not val.empty:
                        v = float(val.iloc[-1])
                        zone = "Sobrecompra" if v > 70 else "Sobreventa" if v < 30 else "Neutral"
                        rsi_result[tf] = {"value": round(v, 1), "zone": zone}
            result["rsi"] = rsi_result

        if indicator == "macd":
            macd_result = {}
            for tf, df in data.items():
                if len(df) >= 26:
                    m = ind.macd(df)
                    last = m.dropna().iloc[-1] if not m.dropna().empty else None
                    if last is not None:
                        macd_result[tf] = {
                            "macd_line": round(float(last["macd_line"]), 3),
                            "signal": round(float(last["macd_signal"]), 3),
                            "histogram": round(float(last["macd_histogram"]), 3),
                        }
            result["macd"] = macd_result

        return result

    # ── Tool 2: check_strategy ────────────────────────────────────────────

    @mcp.tool(annotations={"title": "Check Trading Strategy", "readOnlyHint": True})
    async def check_strategy(
        symbol: str,
        strategy: str = "all",
    ) -> Any:
        """Verify conditions for the 11 options trading strategies.

        Fetches market data and checks whether each strategy's conditions are met.
        Each strategy produces a CUMPLIDA (100%), PARCIAL (60%+), or NO CUMPLIDA result.

        Strategies:
          1: Cambio tendencia al alza (BB Hora) -> CALL
          2: Cambio tendencia a la baja (BB Hora) -> PUT
          3: Rebote punto medio bajista (BB Dia) -> PUT
          4: Rebote punto medio alcista (BB Dia) -> CALL
          5: Salido BB sin volatilidad al alza (15 Min) -> PUT
          6: Efecto iman bajista (MA Hora + BB 15 Min) -> CALL
          7: Efecto iman alcista (MA Hora + BB 15 Min) -> PUT
          8: Cambio tendencia al alza (BB 15 Min) -> CALL
          9: Cambio tendencia a la baja (BB 15 Min) -> PUT
          10: Lateral a alcista mediano plazo (MAs) -> CALL
          11: Lateral a bajista mediano plazo (MAs) -> PUT

        Args:
            symbol: Stock ticker (e.g. "AAPL").
            strategy: Strategy number "1"-"11", or "all" for all strategies.
        """
        # fetcher is captured via closure from build_server()

        data = await fetcher.get_multi_timeframe(symbol)
        if not data:
            return {"error": f"No data found for {symbol}. Check the ticker symbol."}

        if strategy.lower() == "all":
            strategies_result = check_all_strategies(data)
        else:
            try:
                num = int(strategy)
                if num < 1 or num > 11:
                    return {"error": "Strategy number must be 1-11 or 'all'."}
            except ValueError:
                return {"error": "Strategy must be a number (1-11) or 'all'."}

            checker = STRATEGY_CHECKERS[num]
            conditions = checker(data)
            passed = sum(1 for c in conditions if c["passed"])
            total = len(conditions)
            pct = passed / total if total > 0 else 0
            if pct >= 1.0:
                status = "CUMPLIDA"
            elif pct >= 0.6:
                status = "PARCIAL"
            else:
                status = "NO CUMPLIDA"
            strategies_result = [
                {
                    "strategy": num,
                    "name": STRATEGY_NAMES[num],
                    "action": STRATEGY_ACTIONS[num],
                    "status": status,
                    "passed": passed,
                    "total": total,
                    "percentage": round(pct * 100, 1),
                    "conditions": conditions,
                }
            ]

        active = [s for s in strategies_result if s["status"] in ("CUMPLIDA", "PARCIAL")]

        return {
            "symbol": symbol.upper(),
            "strategies": strategies_result,
            "active_strategies": active,
            "summary": f"{len(active)} estrategia(s) activa(s) de {len(strategies_result)} evaluadas",
        }

    # ── Tool 3: get_indicators ────────────────────────────────────────────

    @mcp.tool(annotations={"title": "Get Technical Indicator", "readOnlyHint": True})
    async def get_indicators(
        symbol: str,
        indicator: str,
        timeframe: str = "1Day",
        period: Optional[int] = None,
        rows: int = 20,
    ) -> Any:
        """Get a specific technical indicator for a ticker and timeframe.

        More focused than analyze_ticker - returns one indicator's detailed values.

        Available indicators:
          - "bb": Bollinger Bands (period 20, std 2.0)
          - "sma": Simple Moving Averages (periods 20, 40, 100, 200)
          - "ema": Exponential Moving Average
          - "stoch": Slow Stochastic (K=14, D=3, Smooth=3)
          - "rsi": RSI (period 14)
          - "macd": MACD (12, 26, 9)
          - "atr": Average True Range (period 14)
          - "volume": Volume analysis with SMA ratio
          - "candles": Candlestick classification

        Args:
            symbol: Stock ticker (e.g. "AAPL").
            indicator: Indicator name (see list above).
            timeframe: Bar timeframe - "15Min", "1Hour", "1Day", "1Week", "1Month".
            period: Override the default period for the indicator.
            rows: Number of recent data points to return (default 20).
        """
        # fetcher is captured via closure from build_server()

        df = await fetcher.get_bars(symbol, timeframe)
        if df.empty:
            return {"error": f"No data for {symbol} at {timeframe}."}

        result: dict = {
            "symbol": symbol.upper(),
            "timeframe": timeframe,
            "indicator": indicator,
            "bars_available": len(df),
        }

        if indicator == "bb":
            p = period or 20
            bb = ind.bollinger_bands(df, period=p)
            merged = df[["close"]].join(bb).tail(rows)
            result["period"] = p
            result["trend"] = ind.bb_trend(df, period=p)
            bw = bb["bb_bandwidth"].dropna()
            result["volatility"] = (
                ind.classify_volatility(float(bw.iloc[-1])) if not bw.empty else "--"
            )
            result["data"] = []
            for ts, row in merged.iterrows():
                result["data"].append(
                    {
                        "date": str(ts),
                        "close": round(float(row["close"]), 2),
                        "lower": round(float(row["bb_lower"]), 2)
                        if not np.isnan(row["bb_lower"])
                        else None,
                        "middle": round(float(row["bb_middle"]), 2)
                        if not np.isnan(row["bb_middle"])
                        else None,
                        "upper": round(float(row["bb_upper"]), 2)
                        if not np.isnan(row["bb_upper"])
                        else None,
                        "pct_b": round(float(row["bb_pct_b"]), 3)
                        if not np.isnan(row["bb_pct_b"])
                        else None,
                        "bandwidth": round(float(row["bb_bandwidth"]), 4)
                        if not np.isnan(row["bb_bandwidth"])
                        else None,
                    }
                )

        elif indicator == "sma":
            available = [p for p in [20, 40, 100, 200] if len(df) >= p]
            mas = ind.all_smas(df, available)
            info = ind.ma_order(df, available)
            result["periods"] = available
            result["order"] = info
            result["channel_20_40"] = ind.ma_channel(df) if 40 in available else "--"
            result["days_since_ma20_touch"] = (
                ind.days_since_ma_touch(df) if 20 in available else None
            )
            merged = df[["close"]].join(mas).tail(rows)
            result["data"] = []
            for ts, row in merged.iterrows():
                entry = {"date": str(ts), "close": round(float(row["close"]), 2)}
                for p in available:
                    col = f"sma_{p}"
                    entry[col] = round(float(row[col]), 2) if not np.isnan(row[col]) else None
                result["data"].append(entry)

        elif indicator == "ema":
            p = period or 20
            ema_series = ind.ema(df, p)
            tail = df[["close"]].tail(rows)
            ema_tail = ema_series.tail(rows)
            result["period"] = p
            result["data"] = []
            for (ts, row), e in zip(tail.iterrows(), ema_tail):
                result["data"].append(
                    {
                        "date": str(ts),
                        "close": round(float(row["close"]), 2),
                        f"ema_{p}": round(float(e), 2) if not np.isnan(e) else None,
                    }
                )

        elif indicator == "stoch":
            stoch = ind.stochastic(df, k_period=period or 14)
            tail = stoch.tail(rows)
            result["data"] = []
            prev_k, prev_d = np.nan, np.nan
            for ts, row in tail.iterrows():
                k, d = row["stoch_k"], row["stoch_d"]
                result["data"].append(
                    {
                        "date": str(ts),
                        "k": round(float(k), 1) if not np.isnan(k) else None,
                        "d": round(float(d), 1) if not np.isnan(d) else None,
                        "zone": ind.stochastic_zone(k),
                        "signal": ind.stochastic_signal(k, d, prev_k, prev_d),
                    }
                )
                prev_k, prev_d = k, d

        elif indicator == "rsi":
            p = period or 14
            rsi_series = ind.rsi(df, period=p)
            tail = rsi_series.tail(rows)
            result["period"] = p
            result["data"] = []
            for ts, val in tail.items():
                zone = "--"
                if not np.isnan(val):
                    zone = "Sobrecompra" if val > 70 else "Sobreventa" if val < 30 else "Neutral"
                result["data"].append(
                    {
                        "date": str(ts),
                        "rsi": round(float(val), 1) if not np.isnan(val) else None,
                        "zone": zone,
                    }
                )

        elif indicator == "macd":
            m = ind.macd(df)
            tail = m.tail(rows)
            result["data"] = []
            for ts, row in tail.iterrows():
                result["data"].append(
                    {
                        "date": str(ts),
                        "macd_line": round(float(row["macd_line"]), 3)
                        if not np.isnan(row["macd_line"])
                        else None,
                        "signal": round(float(row["macd_signal"]), 3)
                        if not np.isnan(row["macd_signal"])
                        else None,
                        "histogram": round(float(row["macd_histogram"]), 3)
                        if not np.isnan(row["macd_histogram"])
                        else None,
                    }
                )

        elif indicator == "atr":
            p = period or 14
            atr_series = ind.atr(df, period=p)
            tail = atr_series.tail(rows)
            result["period"] = p
            result["data"] = []
            for ts, val in tail.items():
                result["data"].append(
                    {
                        "date": str(ts),
                        "atr": round(float(val), 2) if not np.isnan(val) else None,
                    }
                )

        elif indicator == "volume":
            vol = ind.volume_analysis(df)
            merged = df[["volume"]].join(vol).tail(rows)
            result["data"] = []
            for ts, row in merged.iterrows():
                result["data"].append(
                    {
                        "date": str(ts),
                        "volume": int(row["volume"]),
                        "sma_20": int(row["vol_sma"]) if not np.isnan(row["vol_sma"]) else None,
                        "ratio": round(float(row["vol_ratio"]), 2)
                        if not np.isnan(row["vol_ratio"])
                        else None,
                        "classification": row["vol_class"],
                    }
                )

        elif indicator == "candles":
            candles = ind.classify_candles(df)
            gaps = ind.detect_gaps(df)
            tail_df = df.tail(rows)
            tail_candles = candles.tail(rows)
            tail_gaps = gaps.tail(rows)
            result["data"] = []
            for (ts, row), (_, candle), gap in zip(
                tail_df.iterrows(), tail_candles.iterrows(), tail_gaps
            ):
                result["data"].append(
                    {
                        "date": str(ts),
                        "open": round(float(row["open"]), 2),
                        "high": round(float(row["high"]), 2),
                        "low": round(float(row["low"]), 2),
                        "close": round(float(row["close"]), 2),
                        "type": candle["type"],
                        "body_size": candle["body_size"],
                        "gap_pct": round(float(gap), 2) if not np.isnan(gap) else None,
                    }
                )
        else:
            return {
                "error": f"Unknown indicator: {indicator}. Use bb, sma, ema, stoch, rsi, macd, atr, volume, candles."
            }

        return result

    # ── Tool 4: scan_tickers ──────────────────────────────────────────────

    @mcp.tool(annotations={"title": "Scan Tickers for Signals", "readOnlyHint": True})
    async def scan_tickers(
        symbols: str,
        strategy: Optional[int] = None,
    ) -> Any:
        """Scan multiple tickers for trading signals and active strategies.

        For each ticker, computes key indicators (BB trend, MA order, Stochastic)
        and checks which of the 11 strategies have conditions met (60%+).

        Args:
            symbols: Comma-separated tickers (e.g. "AAPL,MSFT,GOOG,AMZN").
            strategy: Only check a specific strategy number (1-11). Omit for all.
        """
        # fetcher is captured via closure from build_server()

        ticker_list = [s.strip().upper() for s in symbols.split(",") if s.strip()]
        if not ticker_list:
            return {"error": "No tickers provided."}

        sem = asyncio.Semaphore(3)
        results = []

        async def _scan_one(sym: str) -> dict:
            async with sem:
                data = await fetcher.get_multi_timeframe(sym)
                if not data:
                    return {"symbol": sym, "error": "No data"}

                entry: dict = {"symbol": sym}

                # Price from 1Day or fallback
                for tf in ["1Day", "1Hour", "15Min"]:
                    if tf in data and not data[tf].empty:
                        entry["price"] = round(float(data[tf]["close"].iloc[-1]), 2)
                        break

                # BB trend from 1Day
                if "1Day" in data and len(data["1Day"]) >= 20:
                    entry["trend_bb"] = ind.bb_trend(data["1Day"])
                else:
                    entry["trend_bb"] = "--"

                # MA order from 1Day
                if "1Day" in data and len(data["1Day"]) >= 40:
                    available = [p for p in [20, 40, 100, 200] if len(data["1Day"]) >= p]
                    info = ind.ma_order(data["1Day"], available)
                    entry["ma_order"] = info["order"]
                else:
                    entry["ma_order"] = "--"

                # Stochastic from 1Day
                if "1Day" in data and len(data["1Day"]) >= 20:
                    stoch = ind.stochastic(data["1Day"])
                    k = stoch["stoch_k"].dropna()
                    entry["stoch_k"] = round(float(k.iloc[-1]), 1) if not k.empty else None
                else:
                    entry["stoch_k"] = None

                # Strategy check
                if strategy is not None:
                    if 1 <= strategy <= 11:
                        conditions = STRATEGY_CHECKERS[strategy](data)
                        passed = sum(1 for c in conditions if c["passed"])
                        total = len(conditions)
                        pct = passed / total if total > 0 else 0
                        if pct >= 0.6:
                            action = STRATEGY_ACTIONS[strategy]
                            status = "CUMPLIDA" if pct >= 1.0 else "PARCIAL"
                            entry["active_strategies"] = (
                                f"#{strategy} {action} ({status} {passed}/{total})"
                            )
                        else:
                            entry["active_strategies"] = ""
                else:
                    all_results = check_all_strategies(data)
                    active = [
                        f"#{s['strategy']} {s['action']} ({s['status']} {s['passed']}/{s['total']})"
                        for s in all_results
                        if s["status"] in ("CUMPLIDA", "PARCIAL")
                    ]
                    entry["active_strategies"] = ", ".join(active) if active else ""

                return entry

        tasks = [_scan_one(sym) for sym in ticker_list]
        results = await asyncio.gather(*tasks)

        active_count = sum(1 for r in results if r.get("active_strategies"))
        return {
            "scan_results": results,
            "summary": f"Escaneados {len(results)} tickers. {active_count} con senales activas.",
        }

    # ── Tool 5: get_stock_bars_with_indicators ────────────────────────────

    @mcp.tool(annotations={"title": "Get Stock Bars with Indicators", "readOnlyHint": True})
    async def get_stock_bars_with_indicators(
        symbol: str,
        timeframe: str = "1Day",
        days: int = 30,
        indicators: str = "bb,sma",
        rows: int = 30,
    ) -> Any:
        """Get historical price bars with computed technical indicators.

        Fetches OHLCV data from Alpaca and appends requested indicator columns.
        Returns a table-like structure with both price data and indicators.

        Args:
            symbol: Stock ticker (e.g. "AAPL").
            timeframe: Bar timeframe - "15Min", "1Hour", "1Day".
            days: Number of days to look back (default 30).
            indicators: Comma-separated indicators to include: "bb", "sma", "ema",
                        "stoch", "rsi", "macd", "atr", "volume". Default "bb,sma".
            rows: Number of recent bars to return (default 30).
        """
        # fetcher is captured via closure from build_server()

        df = await fetcher.get_bars(symbol, timeframe, days=days)
        if df.empty:
            return {"error": f"No data for {symbol} at {timeframe}."}

        ind_list = [i.strip().lower() for i in indicators.split(",")]
        combined = df[["open", "high", "low", "close", "volume"]].copy()

        if "bb" in ind_list:
            bb = ind.bollinger_bands(df)
            combined = combined.join(bb)

        if "sma" in ind_list:
            available = [p for p in [20, 40, 100, 200] if len(df) >= p]
            mas = ind.all_smas(df, available)
            combined = combined.join(mas)

        if "ema" in ind_list:
            combined["ema_20"] = ind.ema(df, 20)

        if "stoch" in ind_list:
            stoch = ind.stochastic(df)
            combined = combined.join(stoch)

        if "rsi" in ind_list:
            combined["rsi"] = ind.rsi(df)

        if "macd" in ind_list:
            m = ind.macd(df)
            combined = combined.join(m)

        if "atr" in ind_list:
            combined["atr"] = ind.atr(df)

        if "volume" in ind_list and "vol_ratio" not in combined.columns:
            vol = ind.volume_analysis(df)
            combined = combined.join(vol)

        # Convert to list of dicts
        tail = combined.tail(rows)
        data = []
        for ts, row in tail.iterrows():
            entry = {"date": str(ts)}
            for col in tail.columns:
                val = row[col]
                if isinstance(val, (np.integer,)):
                    entry[col] = int(val)
                elif isinstance(val, (np.floating, float)):
                    entry[col] = round(float(val), 4) if not np.isnan(val) else None
                else:
                    entry[col] = val
            data.append(entry)

        return {
            "symbol": symbol.upper(),
            "timeframe": timeframe,
            "indicators_included": ind_list,
            "bars_total": len(df),
            "bars_returned": len(data),
            "data": data,
        }

    # ── Tool 7: calculate_range ───────────────────────────────────────────

    @mcp.tool(annotations={"title": "Calculate Options Range", "readOnlyHint": True})
    async def calculate_range(
        symbol: str,
        direction: Optional[str] = None,
        expiration: Optional[str] = None,
        strikes: int = 5,
    ) -> Any:
        """Calculate the RANGO (operating price range) for options contracts.

        Replicates the exact methodology from the options trading course:
        1. Takes N strikes near ATM from the nearest expiration
        2. Gets Day's Range (High/Low) for each option contract from dailyBar
        3. Calculates: % = (Day High - Day Low) / Day Low * 100
        4. Top 2 by % = the contracts that valorized the most today
        5. Their Ask prices (x100, rounded to 5) define the RANGO low and high
        6. Divides into 3 zones by day of week (Mon-Tue: low, Wed: mid, Thu-Fri: high)
        7. Finds all OTM contracts within the range and recommends the best

        Uses Alpaca indicative feed (free). dailyBar.h/l provide the Day High/Low
        directly from the snapshot without extra API calls.

        Args:
            symbol: Stock ticker (e.g. "AAPL").
            direction: "CALL", "PUT", or None for both.
            expiration: Specific expiration date (YYYY-MM-DD). Auto-selects nearest if None.
            strikes: Number of strikes to analyze per direction (default 5).
        """
        from datetime import date as _date

        symbol = symbol.upper()
        today = _date.today()
        weekday = today.weekday()  # 0=Mon, 6=Sun

        day_names = {0: "Lunes", 1: "Martes", 2: "Miercoles", 3: "Jueves", 4: "Viernes"}

        # Get current price
        current_price: Optional[float] = None
        try:
            df_price = await fetcher.get_bars(symbol, "1Day", days=5)
            if not df_price.empty:
                current_price = round(float(df_price["close"].iloc[-1]), 2)
        except Exception:
            pass

        if not current_price:
            return {"error": f"Could not fetch current price for {symbol}"}

        tips = []
        if weekday > 4:
            tips.append("Mercado cerrado hoy (fin de semana)")
        elif weekday <= 1:
            tips.append("Lunes/Martes: usar zona BAJA del rango")
        elif weekday == 2:
            tips.append("Miercoles: usar zona MEDIA del rango")
        else:
            tips.append("Jueves/Viernes: usar zona ALTA del rango")

        # Fetch option chain — nearest expiry, strikes within ±15% of price
        exp_filter: dict = {}
        if expiration:
            exp_filter["expiration_date"] = expiration
        else:
            exp_filter["expiration_date_gte"] = today.isoformat()
            # Limit to 45 days out to avoid huge chains
            from datetime import timedelta
            exp_filter["expiration_date_lte"] = (today + timedelta(days=45)).isoformat()

        snapshots, error = await fetcher.get_option_chain(
            symbol=symbol,
            strike_price_gte=round(current_price * 0.85, 2),
            strike_price_lte=round(current_price * 1.15, 2),
            limit=500,
            **exp_filter,
        )

        if error and not snapshots:
            return {"error": error, "symbol": symbol}

        if not snapshots:
            return {"error": "No option contracts found. Market may be closed or symbol invalid.", "symbol": symbol}

        # Parse contract symbols
        import re as _re
        _cpat = _re.compile(r"^([A-Z]+)(\d{2})(\d{2})(\d{2})([CP])(\d{8})$")

        def _parse(sym: str) -> Optional[dict]:
            m = _cpat.match(sym)
            if not m:
                return None
            root, yy, mm, dd, cp, strike_raw = m.groups()
            return {
                "expiry": f"20{yy}-{mm}-{dd}",
                "type": "call" if cp == "C" else "put",
                "strike": round(int(strike_raw) / 1000, 2),
            }

        # Group by expiry to find nearest
        by_expiry: dict[str, list] = {}
        for csym, snap in snapshots.items():
            p = _parse(csym)
            if not p:
                continue
            exp = p["expiry"]
            if exp not in by_expiry:
                by_expiry[exp] = []
            by_expiry[exp].append((csym, p, snap))

        if not by_expiry:
            return {"error": "Could not parse any option contract symbols.", "symbol": symbol}

        # Pick target expiry
        if expiration and expiration in by_expiry:
            target_exp = expiration
        else:
            future_exps = [e for e in sorted(by_expiry.keys()) if e >= today.isoformat()]
            if not future_exps:
                target_exp = sorted(by_expiry.keys())[0]
            else:
                target_exp = future_exps[0]

        exp_contracts = by_expiry[target_exp]
        try:
            from datetime import date as _d2
            exp_date = _d2.fromisoformat(target_exp)
            dte = (exp_date - today).days
        except ValueError:
            dte = None

        # Separate calls and puts
        calls_map: dict[float, dict] = {}
        puts_map: dict[float, dict] = {}
        for csym, p, snap in exp_contracts:
            quote = snap.get("latestQuote") or {}
            daily_bar = snap.get("dailyBar") or {}
            greeks = snap.get("greeks") or {}

            bid = float(quote.get("bp", 0) or 0)
            ask = float(quote.get("ap", 0) or 0)
            bar_high = float(daily_bar.get("h", 0) or 0)
            bar_low = float(daily_bar.get("l", 0) or 0)
            volume = int(daily_bar.get("v", 0) or 0)
            oi = int(snap.get("dailyBar", {}).get("n", 0) or 0) if snap.get("dailyBar") else 0

            pct = None
            if bar_low > 0 and bar_high > 0:
                pct = round((bar_high - bar_low) / bar_low * 100, 2)

            ask_x100 = round(ask * 100) if ask > 0 else None
            spread_pct = round((ask - bid) / ask * 100, 1) if ask > 0 else 100.0
            delta = greeks.get("delta")

            entry = {
                "symbol": csym,
                "strike": p["strike"],
                "bid": round(bid, 2),
                "ask": round(ask, 2),
                "ask_x100": ask_x100,
                "spread_pct": spread_pct,
                "valid_spread": spread_pct <= 10.0,
                "day_high": round(bar_high, 2) if bar_high else None,
                "day_low": round(bar_low, 2) if bar_low else None,
                "pct": pct,
                "volume": volume,
                "delta": round(float(delta), 3) if delta is not None else None,
                "iv": round(float(snap.get("impliedVolatility", 0) or 0), 4),
            }

            if p["type"] == "call":
                calls_map[p["strike"]] = entry
            else:
                puts_map[p["strike"]] = entry

        def _round_to_5(value: float) -> int:
            return max(5, round(value / 5) * 5)

        MIN_ASK = 0.15  # Minimum ask price filter (contracts below $0.15 excluded)

        def _analyze_direction(contracts_map: dict[float, dict], is_call: bool) -> dict:
            # Sort strikes: prioritize OTM first (ask >= MIN_ASK), fill with ITM if needed
            sorted_strikes = sorted(contracts_map.keys())
            if is_call:
                otm_strikes = [s for s in sorted_strikes if s >= current_price and contracts_map[s]["ask"] >= MIN_ASK]
                itm_strikes = [s for s in reversed(sorted_strikes) if s < current_price and contracts_map[s]["ask"] >= MIN_ASK]
                ordered = otm_strikes + itm_strikes
            else:
                otm_strikes = [s for s in reversed(sorted_strikes) if s <= current_price and contracts_map[s]["ask"] >= MIN_ASK]
                itm_strikes = [s for s in sorted_strikes if s > current_price and contracts_map[s]["ask"] >= MIN_ASK]
                ordered = otm_strikes + itm_strikes

            selected = ordered[:strikes]
            strike_data = [contracts_map[s] for s in selected if s in contracts_map]

            # Top 2 by pct (need pct and ask_x100)
            valid = [s for s in strike_data if s.get("pct") is not None and s.get("ask_x100")]
            valid.sort(key=lambda x: x["pct"], reverse=True)
            top_2 = valid[:2]

            if len(top_2) < 2:
                return {
                    "error": "Insufficient daily range data (market may be closed or pre-market). Need at least 2 contracts with dayHigh/dayLow.",
                    "strikes_analyzed": strike_data,
                }

            ask_prices = sorted([s["ask_x100"] for s in top_2])
            range_low = _round_to_5(ask_prices[0])
            range_high = _round_to_5(ask_prices[1])
            if range_low >= range_high:
                range_high = range_low + 5

            spread = range_high - range_low
            third = spread / 3

            if weekday <= 1:
                zone_name, zone_low, zone_high = "BAJA", range_low, _round_to_5(range_low + third)
            elif weekday == 2:
                zone_name = "MEDIA"
                zone_low = _round_to_5(range_low + third)
                zone_high = _round_to_5(range_low + 2 * third)
            else:
                zone_name, zone_low, zone_high = "ALTA", _round_to_5(range_low + 2 * third), range_high

            # All OTM contracts within range
            all_contracts = sorted(contracts_map.values(), key=lambda x: x["strike"])
            otm = [c for c in all_contracts if
                   (is_call and c["strike"] >= current_price) or
                   (not is_call and c["strike"] <= current_price)]

            contracts_in_range = []
            for c in otm:
                ax100 = c.get("ask_x100")
                if ax100 is None:
                    continue
                in_range = range_low <= ax100 <= range_high
                in_zone = zone_low <= ax100 <= zone_high
                if in_range:
                    contracts_in_range.append({**c, "in_zone_today": in_zone})

            valid_today = [c for c in contracts_in_range if c["in_zone_today"] and c["valid_spread"]]
            recommended = None
            if valid_today:
                recommended = max(valid_today, key=lambda x: x["volume"])

            return {
                "range_low": range_low,
                "range_high": range_high,
                "top_2_strikes": [{"strike": s["strike"], "ask_x100": s["ask_x100"], "pct": s["pct"]} for s in top_2],
                "day_of_week": day_names.get(weekday, "?"),
                "zone": zone_name,
                "zone_range": [zone_low, zone_high],
                "strikes_analyzed": strike_data,
                "contracts_in_range": contracts_in_range,
                "recommended_contract": recommended,
            }

        dirs = []
        if direction:
            dirs = [direction.upper()]
        else:
            dirs = ["CALL", "PUT"]

        results_summary = {}
        for dir_ in dirs:
            if dir_ == "CALL":
                results_summary["CALL"] = _analyze_direction(calls_map, is_call=True)
            elif dir_ == "PUT":
                results_summary["PUT"] = _analyze_direction(puts_map, is_call=False)

        result = {
            "symbol": symbol,
            "source": "Alpaca (indicative feed)",
            "price": current_price,
            "expiration": target_exp,
            "days_to_expiry": dte,
            "ranges": results_summary,
        }
        if tips:
            result["tips"] = tips
        if error:
            result["warning"] = error
        return result

    # ── Tool 8: get_option_chain ─────────────────────────────────────────

    @mcp.tool(annotations={"title": "Get Option Chain", "readOnlyHint": True})
    async def get_option_chain(
        symbol: str,
        expiration_date: Optional[str] = None,
        expiration_date_gte: Optional[str] = None,
        expiration_date_lte: Optional[str] = None,
        option_type: Optional[str] = None,
        strike_price_gte: Optional[float] = None,
        strike_price_lte: Optional[float] = None,
        limit: int = 200,
    ) -> Any:
        """Get option chain with quotes, greeks, and implied volatility from Alpaca.

        Uses the free indicative feed (trades delayed, quotes modified).
        Returns contracts grouped by expiration date, with ATM straddle range
        calculation for each expiry. Ideal for price range estimation and
        bid-ask spread validation (course rule: reject if spread > 10%).

        Args:
            symbol: Underlying ticker (e.g. "AAPL").
            expiration_date: Filter by exact expiry (YYYY-MM-DD).
            expiration_date_gte: Filter expiry >= date (YYYY-MM-DD). Defaults to today.
            expiration_date_lte: Filter expiry <= date (YYYY-MM-DD).
            option_type: Filter by "call" or "put". Omit for both.
            strike_price_gte: Filter strike >= value.
            strike_price_lte: Filter strike <= value.
            limit: Max contracts to fetch (default 200, max 1000).
        """
        from datetime import date

        symbol = symbol.upper()

        # Default: only future/current expirations
        if not expiration_date and not expiration_date_gte:
            expiration_date_gte = date.today().isoformat()

        snapshots, error = await fetcher.get_option_chain(
            symbol=symbol,
            option_type=option_type,
            expiration_date=expiration_date,
            expiration_date_gte=expiration_date_gte,
            expiration_date_lte=expiration_date_lte,
            strike_price_gte=strike_price_gte,
            strike_price_lte=strike_price_lte,
            limit=limit,
        )

        if error and not snapshots:
            return {"error": error, "symbol": symbol}

        if not snapshots:
            return {
                "error": "No option contracts found. Check symbol or expiration filters.",
                "symbol": symbol,
            }

        # Get current stock price for ATM calculation
        current_price: Optional[float] = None
        try:
            df_price = await fetcher.get_bars(symbol, "1Day", days=5)
            if not df_price.empty:
                current_price = round(float(df_price["close"].iloc[-1]), 2)
        except Exception:
            pass

        # Parse contract symbol: e.g. AAPL240426C00162500
        # Format: {root}{YY}{MM}{DD}{C/P}{8-digit strike * 1000}
        import re as _re

        _contract_pattern = _re.compile(
            r"^([A-Z]+)(\d{2})(\d{2})(\d{2})([CP])(\d{8})$"
        )

        def _parse_contract(sym: str) -> Optional[dict]:
            m = _contract_pattern.match(sym)
            if not m:
                return None
            root, yy, mm, dd, cp, strike_raw = m.groups()
            return {
                "root": root,
                "expiry": f"20{yy}-{mm}-{dd}",
                "type": "call" if cp == "C" else "put",
                "strike": round(int(strike_raw) / 1000, 2),
            }

        def _spread_pct(bid: float, ask: float) -> Optional[float]:
            mid = (bid + ask) / 2
            if mid <= 0:
                return None
            return round(abs(ask - bid) / mid * 100, 1)

        # Group by expiry
        expirations: dict[str, dict] = {}

        for contract_sym, snap in snapshots.items():
            parsed = _parse_contract(contract_sym)
            if not parsed:
                continue

            expiry = parsed["expiry"]
            ctype = parsed["type"]
            strike = parsed["strike"]

            quote = snap.get("latestQuote") or {}
            greeks = snap.get("greeks") or {}
            trade = snap.get("latestTrade") or {}
            daily_bar = snap.get("dailyBar") or {}

            bid = float(quote.get("bp", 0) or 0)
            ask = float(quote.get("ap", 0) or 0)
            mid = round((bid + ask) / 2, 2)
            spread = _spread_pct(bid, ask)
            iv = snap.get("impliedVolatility")
            volume = int(daily_bar.get("v", 0) or 0)

            contract_data = {
                "symbol": contract_sym,
                "strike": strike,
                "bid": round(bid, 2),
                "ask": round(ask, 2),
                "mid": mid,
                "spread_pct": spread,
                "spread_ok": spread is not None and spread <= 10.0,
                "iv": round(float(iv), 4) if iv else None,
                "delta": round(float(greeks["delta"]), 3) if greeks.get("delta") is not None else None,
                "theta": round(float(greeks["theta"]), 3) if greeks.get("theta") is not None else None,
                "gamma": round(float(greeks["gamma"]), 4) if greeks.get("gamma") is not None else None,
                "vega": round(float(greeks["vega"]), 4) if greeks.get("vega") is not None else None,
                "volume": volume,
                "last_trade": round(float(trade["p"]), 2) if trade.get("p") else None,
            }

            if expiry not in expirations:
                today = date.today()
                try:
                    exp_date = date.fromisoformat(expiry)
                    dte = (exp_date - today).days
                except ValueError:
                    dte = None
                expirations[expiry] = {"dte": dte, "calls": [], "puts": []}

            expirations[expiry][f"{ctype}s"].append(contract_data)

        # Sort contracts by strike, compute ATM straddle range per expiry
        result_expirations = {}
        for expiry in sorted(expirations.keys()):
            exp = expirations[expiry]
            calls = sorted(exp["calls"], key=lambda x: x["strike"])
            puts = sorted(exp["puts"], key=lambda x: x["strike"])

            exp_result: dict = {"dte": exp["dte"], "calls": calls, "puts": puts}

            # ATM straddle range calculation
            if current_price and calls and puts:
                call_strikes = {c["strike"]: c for c in calls}
                put_strikes = {p["strike"]: p for p in puts}
                common_strikes = sorted(set(call_strikes) & set(put_strikes))

                if common_strikes:
                    atm_strike = min(common_strikes, key=lambda s: abs(s - current_price))
                    atm_call = call_strikes[atm_strike]
                    atm_put = put_strikes[atm_strike]

                    call_mid = atm_call["mid"]
                    put_mid = atm_put["mid"]
                    straddle = round(call_mid + put_mid, 2)
                    pct_move = round(straddle / current_price * 100, 2) if current_price > 0 else None

                    exp_result["range"] = {
                        "atm_strike": atm_strike,
                        "straddle_mid": straddle,
                        "upper": round(current_price + straddle, 2),
                        "lower": round(current_price - straddle, 2),
                        "pct_move": pct_move,
                        "atm_call_spread_ok": atm_call["spread_ok"],
                        "atm_put_spread_ok": atm_put["spread_ok"],
                    }

            result_expirations[expiry] = exp_result

        return {
            "symbol": symbol,
            "source": "Alpaca (indicative feed - trades delayed, quotes modified)",
            "current_price": current_price,
            "contracts_total": len(snapshots),
            "expirations_count": len(result_expirations),
            "expirations": result_expirations,
            **({"warning": error} if error else {}),
        }

    # ── MCP Prompt ────────────────────────────────────────────────────────

    @mcp.prompt()
    def trading_analysis_workflow() -> str:
        """Complete guide for performing options trading technical analysis."""
        return """# Options Trading Technical Analysis - Workflow Guide

## Quick Start
1. Use `analyze_ticker(symbol)` for a full multi-timeframe analysis
2. Use `check_strategy(symbol, "all")` to evaluate the 11 trading strategies
3. Use `scan_tickers("AAPL,MSFT,GOOG")` to compare multiple candidates

## Indicator Weights (from course methodology)
| Indicator | Weight | Description |
|-----------|--------|-------------|
| Bollinger Bands | 50% | Volatility state, trend from MM20 slope, %B position |
| Moving Averages | 25% | SMA 20/40/100/200 ordering, channel, crossovers |
| Candlestick Patterns | 15% | Body classification, gap detection |
| Volume | 5% | Relative to 20-period average |
| Worden Stochastics | 5% | Overbought/oversold zones, crossover signals |

## Decision Timeframes
- **15 Min**: Intraday entry signals, volatility detection
- **1 Hour**: Medium-term trend, BB direction
- **1 Day**: Long-term trend, MA ordering

## Informative Timeframes (optional)
- **1 Week**: Multi-week trend context
- **1 Month**: Monthly regime context

## Key Principles
- Price never divorces from the Bollinger dissipator (MM20)
- Higher timeframes carry more weight and power
- Volatility is cyclical: closed -> open -> closed
- Price returns to MA20 within 2-5 days (law of attraction)
- MA ordering (20>40>100>200) confirms trend direction and strength

## Strategy Quick Reference
| # | Name | Action | Key Timeframe |
|---|------|--------|---------------|
| 1 | Cambio tendencia al alza | CALL | BB Hora |
| 2 | Cambio tendencia a la baja | PUT | BB Hora |
| 3 | Rebote punto medio bajista | PUT | BB Dia |
| 4 | Rebote punto medio alcista | CALL | BB Dia |
| 5 | Salido BB sin volatilidad al alza | PUT | BB 15 Min |
| 6 | Efecto iman bajista | CALL | MA Hora + BB 15 Min |
| 7 | Efecto iman alcista | PUT | MA Hora + BB 15 Min |
| 8 | Cambio tendencia al alza | CALL | BB 15 Min |
| 9 | Cambio tendencia a la baja | PUT | BB 15 Min |
| 10 | Lateral a alcista mediano plazo | CALL | MAs Dia |
| 11 | Lateral a bajista mediano plazo | PUT | MAs Dia |

## Strategy Evaluation
- **CUMPLIDA**: 100% of conditions met - strong signal
- **PARCIAL**: 60%+ conditions met - waiting for confirmation
- **NO CUMPLIDA**: <60% - signal not active
"""

    # ── MCP Resources ─────────────────────────────────────────────────────

    @mcp.resource("trading://strategies")
    def strategies_reference() -> str:
        """The 11 trading strategies - conditions and timeframes."""
        lines = ["# 11 Trading Strategies Reference\n"]
        for num in range(1, 12):
            lines.append(f"## Strategy #{num}: {STRATEGY_NAMES[num]}")
            lines.append(f"**Action:** {STRATEGY_ACTIONS[num]}\n")
        return "\n".join(lines)

    @mcp.resource("trading://indicator-weights")
    def indicator_weights_reference() -> str:
        """Technical indicator definitions and weights from the course."""
        return """# Technical Indicator Weights

## Course Methodology
- Bollinger Bands: 50% - BB period 20, std 2.0
- Moving Averages: 25% - SMA periods 20, 40, 100, 200
- Candlestick Patterns: 15% - Body ratio classification
- Volume: 5% - Relative to SMA(20) of volume
- Worden Stochastics: 5% - Slow stochastic K=14, D=3, Smooth=3

## Volatility Classification (Bandwidth)
- < 0.02: Extremadamente cerrados
- 0.02-0.05: Cerrados
- 0.05-0.10: Normal
- 0.10-0.20: Abiertos
- > 0.20: Muy abiertos

## MA Trend Classification
- 20 > 40 > 100 > 200: Alcista
- 20 < 40 < 100 < 200: Bajista
- Mixed: Lateral/Entrelazadas

## Stochastic Zones
- > 80: Sobrecompra (overbought)
- < 20: Sobreventa (oversold)
- 20-80: Neutral
"""

    # ── Tool 6: get_tv_indicators ───────────────────────────────────────

    @mcp.tool(annotations={"title": "Get TradingView Indicators", "readOnlyHint": True})
    async def get_tv_indicators(
        symbol: str,
        include_info: bool = False,
    ) -> Any:
        """Get current technical indicator values directly from TradingView.

        Returns exact values that match TradingView charts (same data source).
        Includes Bollinger Bands, Moving Averages (SMA 20/40/100/200),
        Stochastics, RSI, MACD, and volume across multiple timeframes.

        Also computes course-specific analysis: BB volatility classification,
        MA ordering/trend, candle type, and stochastic zones.

        Note: This returns a current snapshot, not historical data. For
        historical bars and strategy evaluation, use analyze_ticker or
        check_strategy (which use Alpaca data).

        Args:
            symbol: Stock ticker (e.g. "AAPL", "MSFT").
            include_info: Include weekly and monthly informative timeframes.
        """
        from tradingview_screener import Query, col

        symbol = symbol.upper()

        # Define fields per timeframe
        base_fields = [
            "close",
            "open",
            "high",
            "low",
            "volume",
            "BB.upper",
            "BB.lower",
            "BB.basis",
            "SMA20",
            "SMA40",
            "SMA100",
            "SMA200",
            "Stoch.K",
            "Stoch.D",
            "RSI",
            "MACD.macd",
            "MACD.signal",
            "average_volume_10d_calc",
        ]

        # Build timeframe configs: (label, suffix)
        timeframes = [
            ("15Min", "|15"),
            ("1Hour", "|60"),
            ("1Day", ""),
        ]
        if include_info:
            timeframes.append(("1Week", "|1W"))
            timeframes.append(("1Month", "|1M"))

        # Build select fields with timeframe suffixes
        select_fields = ["name", "gap"]
        field_map = {}  # "SMA20|15" -> ("15Min", "SMA20")
        for tf_label, suffix in timeframes:
            for field in base_fields:
                full_field = f"{field}{suffix}"
                select_fields.append(full_field)
                field_map[full_field] = (tf_label, field)

        # Query TradingView
        try:
            _, df = (
                Query()
                .select(*select_fields)
                .where(col("name") == symbol)
                .limit(1)
                .get_scanner_data()
            )
        except Exception as e:
            return {"error": f"TradingView query failed: {e}"}

        if df.empty:
            return {"error": f"No data found for {symbol} on TradingView."}

        row = df.iloc[0]

        # Helper to safely get a value
        def _get(field: str, suffix: str):
            key = f"{field}{suffix}"
            val = row.get(key)
            if val is None or (isinstance(val, float) and np.isnan(val)):
                return None
            return (
                round(float(val), 2)
                if isinstance(val, (int, float, np.floating, np.integer))
                else val
            )

        result = {"symbol": symbol, "source": "TradingView"}

        for tf_label, suffix in timeframes:
            close = _get("close", suffix)
            open_ = _get("open", suffix)
            high = _get("high", suffix)
            low = _get("low", suffix)
            volume = _get("volume", suffix)

            if close is None:
                continue

            tf_data = {"close": close}

            # --- Bollinger Bands (50% weight) ---
            bb_upper = _get("BB.upper", suffix)
            bb_lower = _get("BB.lower", suffix)
            bb_basis = _get("BB.basis", suffix)

            if bb_upper and bb_lower and bb_basis and bb_basis > 0:
                bandwidth = round((bb_upper - bb_lower) / bb_basis, 4)
                bb_range = bb_upper - bb_lower
                pct_b = round((close - bb_lower) / bb_range, 3) if bb_range > 0 else None
                tf_data["bollinger"] = {
                    "upper": bb_upper,
                    "middle": bb_basis,
                    "lower": bb_lower,
                    "bandwidth": bandwidth,
                    "pct_b": pct_b,
                    "volatility": ind.classify_volatility(bandwidth),
                }

            # --- Moving Averages (25% weight) ---
            sma_20 = _get("SMA20", suffix)
            sma_40 = _get("SMA40", suffix)
            sma_100 = _get("SMA100", suffix)
            sma_200 = _get("SMA200", suffix)

            ma_data = {}
            if sma_20 is not None:
                ma_data["sma_20"] = sma_20
            if sma_40 is not None:
                ma_data["sma_40"] = sma_40
            if sma_100 is not None:
                ma_data["sma_100"] = sma_100
            if sma_200 is not None:
                ma_data["sma_200"] = sma_200

            # MA ordering and trend
            available = {
                k: v
                for k, v in [(20, sma_20), (40, sma_40), (100, sma_100), (200, sma_200)]
                if v is not None
            }

            if len(available) >= 2:
                periods = sorted(available.keys())
                values = [available[p] for p in periods]
                bullish = all(values[i] > values[i + 1] for i in range(len(values) - 1))
                bearish = all(values[i] < values[i + 1] for i in range(len(values) - 1))

                if bullish:
                    ma_data["order"] = ">".join(str(p) for p in periods)
                    ma_data["trend"] = "Alcista"
                elif bearish:
                    ma_data["order"] = "<".join(str(p) for p in periods)
                    ma_data["trend"] = "Bajista"
                else:
                    sorted_by_val = sorted(available.items(), key=lambda x: x[1], reverse=True)
                    ma_data["order"] = ">".join(str(p) for p, _ in sorted_by_val)
                    ma_data["trend"] = "Lateral/Entrelazadas"

                spread = (max(values) - min(values)) / np.mean(values) * 100
                if spread > 10:
                    ma_data["strength"] = "Muy fuerte"
                elif spread > 5:
                    ma_data["strength"] = "Fuerte"
                elif spread > 2:
                    ma_data["strength"] = "Moderada"
                else:
                    ma_data["strength"] = "Debil"

                # Distance from MA20
                if sma_20 and sma_20 > 0:
                    ma_data["distance_from_ma20_pct"] = round((close - sma_20) / sma_20 * 100, 2)

            if ma_data:
                tf_data["moving_averages"] = ma_data

            # --- Stochastics (5% weight) ---
            stoch_k = _get("Stoch.K", suffix)
            stoch_d = _get("Stoch.D", suffix)

            if stoch_k is not None:
                tf_data["stochastics"] = {
                    "k": round(stoch_k, 1),
                    "d": round(stoch_d, 1) if stoch_d is not None else None,
                    "zone": ind.stochastic_zone(stoch_k),
                }

            # --- Candle classification (15% weight) ---
            if all(v is not None for v in [open_, high, low, close]):
                candle_row = pd.Series({"open": open_, "high": high, "low": low, "close": close})
                tf_data["candle"] = ind.classify_candle(candle_row)

            # --- Volume (5% weight) ---
            avg_vol = _get("average_volume_10d_calc", suffix)
            if volume is not None:
                vol_data = {"current": int(volume)}
                if avg_vol and avg_vol > 0:
                    ratio = round(volume / avg_vol, 2)
                    vol_data["avg_10d"] = int(avg_vol)
                    vol_data["ratio"] = ratio
                    if ratio > 2.0:
                        vol_data["classification"] = "Muy alto"
                    elif ratio > 1.3:
                        vol_data["classification"] = "Alto"
                    elif ratio > 0.7:
                        vol_data["classification"] = "Normal"
                    else:
                        vol_data["classification"] = "Bajo"
                tf_data["volume"] = vol_data

            # --- Extras ---
            rsi_val = _get("RSI", suffix)
            if rsi_val is not None:
                zone = (
                    "Sobrecompra" if rsi_val > 70 else "Sobreventa" if rsi_val < 30 else "Neutral"
                )
                tf_data["rsi"] = {"value": round(rsi_val, 1), "zone": zone}

            macd_line = _get("MACD.macd", suffix)
            macd_signal = _get("MACD.signal", suffix)
            if macd_line is not None and macd_signal is not None:
                tf_data["macd"] = {
                    "line": round(macd_line, 3),
                    "signal": round(macd_signal, 3),
                    "histogram": round(macd_line - macd_signal, 3),
                }

            result[tf_label] = tf_data

        # --- Gap (top-level daily field from TradingView) ---
        gap_raw = row.get("gap")
        if gap_raw is not None and not (isinstance(gap_raw, float) and np.isnan(gap_raw)):
            gap_pct = round(float(gap_raw), 4)
            if gap_pct >= 0.5:
                gap_type = "alcista"
                gap_significant = True
            elif gap_pct <= -0.5:
                gap_type = "bajista"
                gap_significant = True
            else:
                gap_type = "nulo"
                gap_significant = False
            result["gap"] = {
                "pct": gap_pct,
                "type": gap_type,
                "significant": gap_significant,
                "note": f"gap_pct={gap_pct}% — {'significativo (' + gap_type + ')' if gap_significant else 'sin gap significativo (<0.5%)'}",
            }

        return result

    return mcp
