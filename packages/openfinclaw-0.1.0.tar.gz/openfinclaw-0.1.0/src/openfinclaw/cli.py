#!/usr/bin/env python3
"""OpenFinClaw CLI — Rich interactive terminal client.

Usage:
    openfinclaw-cli                                       # default: production
    openfinclaw-cli --url http://localhost:9008            # local
    openfinclaw-cli --thread <thread-id>                   # resume existing thread

Commands inside the CLI:
    /new          Create a new thread
    /threads      List all threads
    /history      Show message history
    /runs         Show run history
    /cancel       Cancel the active run
    /help         Show available commands
    /quit         Exit
"""

from __future__ import annotations

import argparse
import sys

from .client import OpenFinClawClient
from .exceptions import ConflictError, RateLimitError

DEFAULT_URL = "https://api.openfinclaw.ai/agent"

# Lazy-import Rich to keep SDK lightweight
_console = None


def _get_console():
    global _console
    if _console is None:
        from rich.console import Console

        _console = Console()
    return _console


# ── Styling constants ────────────────────────────────────────────────────────

STATUS_COLORS = {
    "idle": "green",
    "running": "yellow",
    "completed": "green",
    "error": "red",
    "pending": "dim",
    "cancelling": "yellow",
    "cancelled": "dim",
}

ROLE_STYLES = {
    "user": ("bold cyan", "User"),
    "assistant": ("bold green", "Assistant"),
}


# ── Helper functions ─────────────────────────────────────────────────────────


def _format_duration(ms: int | None) -> str:
    if ms is None:
        return "-"
    secs = ms / 1000
    if secs < 60:
        return f"{secs:.1f}s"
    return f"{secs / 60:.1f}m"


def _format_time(iso_str: str | None) -> str:
    if not iso_str:
        return "-"
    if "T" in iso_str:
        return iso_str.split("T")[1][:8]
    return iso_str[:19]


# ── Display functions ────────────────────────────────────────────────────────


def welcome_banner(health: dict, url: str, thread_id: str) -> None:
    from rich.panel import Panel

    console = _get_console()
    info_lines = [
        f"[bold]Server:[/] {url}",
        f"[bold]Skills:[/] {health.get('skills_count', '?')}",
        f"[bold]Thread:[/] {thread_id[:12]}...",
    ]
    if "version" in health:
        info_lines.insert(1, f"[bold]Version:[/] {health['version']}")

    console.print(
        Panel(
            "\n".join(info_lines),
            title="[bold green]OpenFinClaw CLI[/]",
            subtitle="Type [bold]/help[/] for commands",
            border_style="green",
            padding=(1, 2),
        )
    )


def show_threads(client: OpenFinClawClient) -> None:
    from rich.table import Table
    from rich.text import Text

    console = _get_console()
    threads = client.list_threads()
    if not threads:
        console.print("  [dim]No threads found[/]")
        return

    table = Table(title="Threads", border_style="blue", show_lines=False)
    table.add_column("ID", style="cyan", max_width=12)
    table.add_column("Status", justify="center")
    table.add_column("Title", style="white")
    table.add_column("Turns", justify="right", style="dim")
    table.add_column("Created", style="dim", max_width=10)

    for t in threads[:15]:
        color = STATUS_COLORS.get(t.status, "white")
        table.add_row(
            t.id[:12],
            Text(t.status, style=color),
            t.title,
            str(t.total_turns),
            _format_time(t.created_at),
        )
    console.print(table)


def show_history(client: OpenFinClawClient, thread_id: str) -> None:
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.text import Text

    console = _get_console()
    msgs = client.list_messages(thread_id)
    if not msgs:
        console.print("  [dim]No messages in this thread[/]")
        return

    for m in msgs:
        style, label = ROLE_STYLES.get(m.role, ("white", m.role))
        if m.role == "assistant":
            panel_content = Markdown(m.content[:500])
        else:
            panel_content = Text(m.content[:500])
        console.print(
            Panel(
                panel_content,
                title=f"[{style}]{label}[/]",
                title_align="left",
                border_style=style.split()[-1],
                padding=(0, 1),
            )
        )


def show_runs(client: OpenFinClawClient, thread_id: str) -> None:
    from rich.table import Table
    from rich.text import Text

    console = _get_console()
    runs = client.list_runs(thread_id)
    if not runs:
        console.print("  [dim]No runs in this thread[/]")
        return

    table = Table(title="Runs", border_style="blue")
    table.add_column("ID", style="cyan", max_width=12)
    table.add_column("Status", justify="center")
    table.add_column("Duration", justify="right")
    table.add_column("Turns", justify="right")
    table.add_column("Cost", justify="right", style="yellow")
    table.add_column("Time", style="dim", max_width=10)

    for r in runs:
        cost_str = f"${r.cost_usd:.4f}" if r.cost_usd > 0 else "-"
        color = STATUS_COLORS.get(r.status, "white")
        table.add_row(
            r.id[:12],
            Text(r.status, style=color),
            _format_duration(r.duration_ms),
            str(r.num_turns),
            cost_str,
            _format_time(r.created_at),
        )
    console.print(table)


def show_help() -> None:
    from rich.panel import Panel
    from rich.table import Table

    console = _get_console()
    table = Table(border_style="dim", show_header=False, padding=(0, 2))
    table.add_column("Command", style="bold cyan")
    table.add_column("Description")
    table.add_row("/new", "Create a new conversation thread")
    table.add_row("/threads", "List all threads")
    table.add_row("/history", "Show message history for current thread")
    table.add_row("/runs", "Show run history for current thread")
    table.add_row("/cancel", "Cancel any active run")
    table.add_row("/help", "Show this help message")
    table.add_row("/quit", "Exit the CLI")
    console.print(Panel(table, title="[bold]Commands[/]", border_style="blue"))


def send_message(client: OpenFinClawClient, thread_id: str, message: str) -> None:
    from rich.console import Group
    from rich.live import Live
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.rule import Rule
    from rich.text import Text

    console = _get_console()
    text_buffer = ""
    active_tool: str | None = None
    completed_tools: list[str] = []
    handoffs: list[str] = []
    has_error = False
    error_msg = ""

    def _build_display() -> Group:
        parts: list[object] = []
        for agent_name in handoffs:
            parts.append(Rule(f"[bold blue]{agent_name}[/]", style="blue"))
        for name in completed_tools:
            parts.append(Text(f"  {name}", style="green"))
        if active_tool:
            parts.append(Text(f"  Calling: {active_tool}...", style="yellow"))
        if text_buffer:
            border = "red" if has_error else "green"
            parts.append(
                Panel(
                    Markdown(text_buffer),
                    title="[bold green]Assistant[/]",
                    title_align="left",
                    border_style=border,
                    padding=(0, 1),
                )
            )
        elif error_msg:
            parts.append(
                Panel(Text(error_msg, style="red"), title="[bold red]Error[/]", border_style="red")
            )
        elif not parts:
            parts.append(Text("  Thinking...", style="dim italic"))
        return Group(*parts)

    try:
        with Live(
            _build_display(), console=console, refresh_per_second=8, vertical_overflow="visible"
        ) as live:
            for event in client.stream(thread_id, message):
                if event.type == "TEXT_DELTA":
                    text_buffer += event.text
                elif event.type == "TOOL_START":
                    if active_tool:
                        completed_tools.append(active_tool)
                    active_tool = event.tool_name or "unknown"
                elif event.type == "TOOL_DONE":
                    if active_tool:
                        completed_tools.append(active_tool)
                        active_tool = None
                elif event.type == "AGENT_HANDOFF":
                    handoffs.append(event.agent_name or "unknown")
                elif event.type == "ERROR":
                    has_error = True
                    error_msg = event.error or "Unknown error"
                elif event.type == "RUN_FINISHED":
                    if event.is_error:
                        has_error = True
                live.update(_build_display())

        if has_error:
            console.print("[red]Run finished with errors[/]")

    except ConflictError:
        console.print(
            Panel(
                "Thread is already running. Use [bold]/cancel[/] or wait.",
                border_style="yellow",
                title="[yellow]Conflict[/]",
            )
        )
    except RateLimitError as e:
        console.print(Panel(str(e), border_style="red", title="[bold red]Rate Limit[/]"))
    except KeyboardInterrupt:
        console.print("\n  [yellow]Interrupted[/] [dim](server may still be processing)[/]")


def cancel_runs(client: OpenFinClawClient, thread_id: str) -> None:
    console = _get_console()
    runs = client.list_runs(thread_id)
    active = [r for r in runs if r.status == "running"]
    if not active:
        console.print("  [dim]No active runs[/]")
        return
    for r in active:
        ok = client.cancel_run(thread_id, r.id)
        if ok:
            console.print(f"  [green]Cancelled:[/] {r.id[:12]}...")
        else:
            console.print(f"  [red]Failed to cancel:[/] {r.id[:12]}...")


# ── Main ─────────────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser(description="OpenFinClaw CLI")
    parser.add_argument("--url", default=DEFAULT_URL, help="API base URL")
    parser.add_argument("--thread", default=None, help="Resume existing thread ID")
    parser.add_argument("--api-key", default="79a29a66b189ec09", help="API key for authentication")
    args = parser.parse_args()

    console = _get_console()
    client = OpenFinClawClient(api_key=args.api_key, base_url=args.url)

    # Health check
    try:
        health = client.health()
    except Exception as e:
        from rich.panel import Panel

        console.print(
            Panel(
                f"Cannot connect to [bold]{args.url}[/]\n\n{e}",
                title="[bold red]Connection Failed[/]",
                border_style="red",
            )
        )
        sys.exit(1)

    # Thread
    if args.thread:
        thread_id = args.thread
    else:
        thread = client.create_thread()
        thread_id = thread.id
        console.print(f"  [green]Thread created:[/] {thread_id[:12]}...")

    # Welcome
    console.print()
    welcome_banner(health, args.url, thread_id)
    console.print()

    # REPL
    while True:
        try:
            user_input = console.input("[bold cyan]You:[/] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Bye![/]")
            break

        if not user_input:
            continue

        cmd = user_input.lower()
        if cmd == "/quit":
            console.print("[dim]Bye![/]")
            break
        elif cmd == "/new":
            thread = client.create_thread()
            thread_id = thread.id
            console.print(f"  [green]Thread created:[/] {thread_id[:12]}...")
            continue
        elif cmd == "/threads":
            show_threads(client)
            continue
        elif cmd == "/history":
            show_history(client, thread_id)
            continue
        elif cmd == "/runs":
            show_runs(client, thread_id)
            continue
        elif cmd == "/cancel":
            cancel_runs(client, thread_id)
            continue
        elif cmd == "/help":
            show_help()
            continue
        elif user_input.startswith("/"):
            console.print(f"  [red]Unknown command:[/] {user_input}. Type [bold]/help[/]")
            continue

        console.print()
        send_message(client, thread_id, user_input)
        console.print()


if __name__ == "__main__":
    main()
