# SPDX-FileCopyrightText: 2021-present MTS PJSC
# SPDX-License-Identifier: Apache-2.0
from onetl.connection.file_connection.hdfs.connection import HDFS

__all__ = ["HDFS"]
