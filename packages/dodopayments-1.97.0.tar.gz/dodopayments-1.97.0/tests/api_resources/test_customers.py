# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from dodopayments import DodoPayments, AsyncDodoPayments
from dodopayments.types import (
    Customer,
    CustomerListEntitlementsResponse,
    CustomerListCreditEntitlementsResponse,
    CustomerRetrievePaymentMethodsResponse,
)
from dodopayments._utils import parse_datetime
from dodopayments.pagination import SyncDefaultPageNumberPagination, AsyncDefaultPageNumberPagination

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestCustomers:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: DodoPayments) -> None:
        customer = client.customers.create(
            email="email",
            name="name",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: DodoPayments) -> None:
        customer = client.customers.create(
            email="email",
            name="name",
            metadata={"foo": "string"},
            phone_number="phone_number",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: DodoPayments) -> None:
        response = client.customers.with_raw_response.create(
            email="email",
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = response.parse()
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: DodoPayments) -> None:
        with client.customers.with_streaming_response.create(
            email="email",
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = response.parse()
            assert_matches_type(Customer, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: DodoPayments) -> None:
        customer = client.customers.retrieve(
            "customer_id",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: DodoPayments) -> None:
        response = client.customers.with_raw_response.retrieve(
            "customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = response.parse()
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: DodoPayments) -> None:
        with client.customers.with_streaming_response.retrieve(
            "customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = response.parse()
            assert_matches_type(Customer, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: DodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            client.customers.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: DodoPayments) -> None:
        customer = client.customers.update(
            customer_id="customer_id",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: DodoPayments) -> None:
        customer = client.customers.update(
            customer_id="customer_id",
            email="email",
            metadata={"foo": "string"},
            name="name",
            phone_number="phone_number",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: DodoPayments) -> None:
        response = client.customers.with_raw_response.update(
            customer_id="customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = response.parse()
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: DodoPayments) -> None:
        with client.customers.with_streaming_response.update(
            customer_id="customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = response.parse()
            assert_matches_type(Customer, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: DodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            client.customers.with_raw_response.update(
                customer_id="",
            )

    @parametrize
    def test_method_list(self, client: DodoPayments) -> None:
        customer = client.customers.list()
        assert_matches_type(SyncDefaultPageNumberPagination[Customer], customer, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: DodoPayments) -> None:
        customer = client.customers.list(
            created_at_gte=parse_datetime("2019-12-27T18:11:19.117Z"),
            created_at_lte=parse_datetime("2019-12-27T18:11:19.117Z"),
            email="email",
            name="name",
            page_number=0,
            page_size=0,
        )
        assert_matches_type(SyncDefaultPageNumberPagination[Customer], customer, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: DodoPayments) -> None:
        response = client.customers.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = response.parse()
        assert_matches_type(SyncDefaultPageNumberPagination[Customer], customer, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: DodoPayments) -> None:
        with client.customers.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = response.parse()
            assert_matches_type(SyncDefaultPageNumberPagination[Customer], customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_delete_payment_method(self, client: DodoPayments) -> None:
        customer = client.customers.delete_payment_method(
            payment_method_id="payment_method_id",
            customer_id="customer_id",
        )
        assert customer is None

    @parametrize
    def test_raw_response_delete_payment_method(self, client: DodoPayments) -> None:
        response = client.customers.with_raw_response.delete_payment_method(
            payment_method_id="payment_method_id",
            customer_id="customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = response.parse()
        assert customer is None

    @parametrize
    def test_streaming_response_delete_payment_method(self, client: DodoPayments) -> None:
        with client.customers.with_streaming_response.delete_payment_method(
            payment_method_id="payment_method_id",
            customer_id="customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = response.parse()
            assert customer is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete_payment_method(self, client: DodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            client.customers.with_raw_response.delete_payment_method(
                payment_method_id="payment_method_id",
                customer_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payment_method_id` but received ''"):
            client.customers.with_raw_response.delete_payment_method(
                payment_method_id="",
                customer_id="customer_id",
            )

    @parametrize
    def test_method_list_credit_entitlements(self, client: DodoPayments) -> None:
        customer = client.customers.list_credit_entitlements(
            "customer_id",
        )
        assert_matches_type(CustomerListCreditEntitlementsResponse, customer, path=["response"])

    @parametrize
    def test_raw_response_list_credit_entitlements(self, client: DodoPayments) -> None:
        response = client.customers.with_raw_response.list_credit_entitlements(
            "customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = response.parse()
        assert_matches_type(CustomerListCreditEntitlementsResponse, customer, path=["response"])

    @parametrize
    def test_streaming_response_list_credit_entitlements(self, client: DodoPayments) -> None:
        with client.customers.with_streaming_response.list_credit_entitlements(
            "customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = response.parse()
            assert_matches_type(CustomerListCreditEntitlementsResponse, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_credit_entitlements(self, client: DodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            client.customers.with_raw_response.list_credit_entitlements(
                "",
            )

    @parametrize
    def test_method_list_entitlements(self, client: DodoPayments) -> None:
        customer = client.customers.list_entitlements(
            "customer_id",
        )
        assert_matches_type(CustomerListEntitlementsResponse, customer, path=["response"])

    @parametrize
    def test_raw_response_list_entitlements(self, client: DodoPayments) -> None:
        response = client.customers.with_raw_response.list_entitlements(
            "customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = response.parse()
        assert_matches_type(CustomerListEntitlementsResponse, customer, path=["response"])

    @parametrize
    def test_streaming_response_list_entitlements(self, client: DodoPayments) -> None:
        with client.customers.with_streaming_response.list_entitlements(
            "customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = response.parse()
            assert_matches_type(CustomerListEntitlementsResponse, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_entitlements(self, client: DodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            client.customers.with_raw_response.list_entitlements(
                "",
            )

    @parametrize
    def test_method_retrieve_payment_methods(self, client: DodoPayments) -> None:
        customer = client.customers.retrieve_payment_methods(
            "customer_id",
        )
        assert_matches_type(CustomerRetrievePaymentMethodsResponse, customer, path=["response"])

    @parametrize
    def test_raw_response_retrieve_payment_methods(self, client: DodoPayments) -> None:
        response = client.customers.with_raw_response.retrieve_payment_methods(
            "customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = response.parse()
        assert_matches_type(CustomerRetrievePaymentMethodsResponse, customer, path=["response"])

    @parametrize
    def test_streaming_response_retrieve_payment_methods(self, client: DodoPayments) -> None:
        with client.customers.with_streaming_response.retrieve_payment_methods(
            "customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = response.parse()
            assert_matches_type(CustomerRetrievePaymentMethodsResponse, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve_payment_methods(self, client: DodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            client.customers.with_raw_response.retrieve_payment_methods(
                "",
            )


class TestAsyncCustomers:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.create(
            email="email",
            name="name",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.create(
            email="email",
            name="name",
            metadata={"foo": "string"},
            phone_number="phone_number",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncDodoPayments) -> None:
        response = await async_client.customers.with_raw_response.create(
            email="email",
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = await response.parse()
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncDodoPayments) -> None:
        async with async_client.customers.with_streaming_response.create(
            email="email",
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = await response.parse()
            assert_matches_type(Customer, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.retrieve(
            "customer_id",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncDodoPayments) -> None:
        response = await async_client.customers.with_raw_response.retrieve(
            "customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = await response.parse()
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncDodoPayments) -> None:
        async with async_client.customers.with_streaming_response.retrieve(
            "customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = await response.parse()
            assert_matches_type(Customer, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncDodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            await async_client.customers.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.update(
            customer_id="customer_id",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.update(
            customer_id="customer_id",
            email="email",
            metadata={"foo": "string"},
            name="name",
            phone_number="phone_number",
        )
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncDodoPayments) -> None:
        response = await async_client.customers.with_raw_response.update(
            customer_id="customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = await response.parse()
        assert_matches_type(Customer, customer, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncDodoPayments) -> None:
        async with async_client.customers.with_streaming_response.update(
            customer_id="customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = await response.parse()
            assert_matches_type(Customer, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncDodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            await async_client.customers.with_raw_response.update(
                customer_id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.list()
        assert_matches_type(AsyncDefaultPageNumberPagination[Customer], customer, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.list(
            created_at_gte=parse_datetime("2019-12-27T18:11:19.117Z"),
            created_at_lte=parse_datetime("2019-12-27T18:11:19.117Z"),
            email="email",
            name="name",
            page_number=0,
            page_size=0,
        )
        assert_matches_type(AsyncDefaultPageNumberPagination[Customer], customer, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncDodoPayments) -> None:
        response = await async_client.customers.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = await response.parse()
        assert_matches_type(AsyncDefaultPageNumberPagination[Customer], customer, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncDodoPayments) -> None:
        async with async_client.customers.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = await response.parse()
            assert_matches_type(AsyncDefaultPageNumberPagination[Customer], customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_delete_payment_method(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.delete_payment_method(
            payment_method_id="payment_method_id",
            customer_id="customer_id",
        )
        assert customer is None

    @parametrize
    async def test_raw_response_delete_payment_method(self, async_client: AsyncDodoPayments) -> None:
        response = await async_client.customers.with_raw_response.delete_payment_method(
            payment_method_id="payment_method_id",
            customer_id="customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = await response.parse()
        assert customer is None

    @parametrize
    async def test_streaming_response_delete_payment_method(self, async_client: AsyncDodoPayments) -> None:
        async with async_client.customers.with_streaming_response.delete_payment_method(
            payment_method_id="payment_method_id",
            customer_id="customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = await response.parse()
            assert customer is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete_payment_method(self, async_client: AsyncDodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            await async_client.customers.with_raw_response.delete_payment_method(
                payment_method_id="payment_method_id",
                customer_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payment_method_id` but received ''"):
            await async_client.customers.with_raw_response.delete_payment_method(
                payment_method_id="",
                customer_id="customer_id",
            )

    @parametrize
    async def test_method_list_credit_entitlements(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.list_credit_entitlements(
            "customer_id",
        )
        assert_matches_type(CustomerListCreditEntitlementsResponse, customer, path=["response"])

    @parametrize
    async def test_raw_response_list_credit_entitlements(self, async_client: AsyncDodoPayments) -> None:
        response = await async_client.customers.with_raw_response.list_credit_entitlements(
            "customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = await response.parse()
        assert_matches_type(CustomerListCreditEntitlementsResponse, customer, path=["response"])

    @parametrize
    async def test_streaming_response_list_credit_entitlements(self, async_client: AsyncDodoPayments) -> None:
        async with async_client.customers.with_streaming_response.list_credit_entitlements(
            "customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = await response.parse()
            assert_matches_type(CustomerListCreditEntitlementsResponse, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_credit_entitlements(self, async_client: AsyncDodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            await async_client.customers.with_raw_response.list_credit_entitlements(
                "",
            )

    @parametrize
    async def test_method_list_entitlements(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.list_entitlements(
            "customer_id",
        )
        assert_matches_type(CustomerListEntitlementsResponse, customer, path=["response"])

    @parametrize
    async def test_raw_response_list_entitlements(self, async_client: AsyncDodoPayments) -> None:
        response = await async_client.customers.with_raw_response.list_entitlements(
            "customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = await response.parse()
        assert_matches_type(CustomerListEntitlementsResponse, customer, path=["response"])

    @parametrize
    async def test_streaming_response_list_entitlements(self, async_client: AsyncDodoPayments) -> None:
        async with async_client.customers.with_streaming_response.list_entitlements(
            "customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = await response.parse()
            assert_matches_type(CustomerListEntitlementsResponse, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_entitlements(self, async_client: AsyncDodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            await async_client.customers.with_raw_response.list_entitlements(
                "",
            )

    @parametrize
    async def test_method_retrieve_payment_methods(self, async_client: AsyncDodoPayments) -> None:
        customer = await async_client.customers.retrieve_payment_methods(
            "customer_id",
        )
        assert_matches_type(CustomerRetrievePaymentMethodsResponse, customer, path=["response"])

    @parametrize
    async def test_raw_response_retrieve_payment_methods(self, async_client: AsyncDodoPayments) -> None:
        response = await async_client.customers.with_raw_response.retrieve_payment_methods(
            "customer_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        customer = await response.parse()
        assert_matches_type(CustomerRetrievePaymentMethodsResponse, customer, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve_payment_methods(self, async_client: AsyncDodoPayments) -> None:
        async with async_client.customers.with_streaming_response.retrieve_payment_methods(
            "customer_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            customer = await response.parse()
            assert_matches_type(CustomerRetrievePaymentMethodsResponse, customer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve_payment_methods(self, async_client: AsyncDodoPayments) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `customer_id` but received ''"):
            await async_client.customers.with_raw_response.retrieve_payment_methods(
                "",
            )
