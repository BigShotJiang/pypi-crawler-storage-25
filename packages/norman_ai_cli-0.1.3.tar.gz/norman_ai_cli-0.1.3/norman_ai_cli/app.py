"""Norman AI CLI — Agentic accounting & taxes from the terminal.

Entry point and global option handling.
"""

import logging
from typing import Optional

import typer
from rich.console import Console

from norman_ai_cli import __version__
from norman_ai_cli.output import OutputFormatter, set_formatter


BANNER = """[bold]
 ███╗   ██╗ ██████╗ ██████╗ ███╗   ███╗ █████╗ ███╗   ██╗
 ████╗  ██║██╔═══██╗██╔══██╗████╗ ████║██╔══██╗████╗  ██║
 ██╔██╗ ██║██║   ██║██████╔╝██╔████╔██║███████║██╔██╗ ██║
 ██║╚██╗██║██║   ██║██╔══██╗██║╚██╔╝██║██╔══██║██║╚██╗██║
 ██║ ╚████║╚██████╔╝██║  ██║██║ ╚═╝ ██║██║  ██║██║ ╚████║
 ╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝[/bold]
[dim]  v{version} · Agentic accounting & taxes from the terminal[/dim]
"""


def _version_callback(value: bool) -> None:
    if value:
        Console().print(BANNER.format(version=__version__))
        raise typer.Exit()

# Import command groups
from norman_ai_cli import auth as auth_module
from norman_ai_cli.commands import (
    company,
    transactions,
    invoices,
    clients,
    taxes,
    bills,
    documents,
    categories,
    advisor,
    registration,
)

app = typer.Typer(
    name="norman-ai",
    help="Norman AI — Agentic accounting & taxes from the terminal.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# Register command groups
app.add_typer(auth_module.app, name="auth")
app.add_typer(company.app, name="company")
app.add_typer(transactions.app, name="transactions")
app.add_typer(invoices.app, name="invoices")
app.add_typer(clients.app, name="clients")
app.add_typer(taxes.app, name="taxes")
app.add_typer(bills.app, name="bills")
app.add_typer(documents.app, name="documents")
app.add_typer(categories.app, name="categories")
app.add_typer(advisor.app, name="advisor")
app.add_typer(registration.app, name="registration")


# Global state
class State:
    debug: bool = False
    no_input: bool = False
    dry_run: bool = False
    env: Optional[str] = None
    api_url: Optional[str] = None


state = State()


@app.callback()
def main_callback(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", help="Force table output"),
    wide: bool = typer.Option(False, "--wide", help="Show all columns in tables"),
    agent_mode: bool = typer.Option(False, "--agent", help="Machine-readable JSON (auto when piped)"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress progress output"),
    no_input: bool = typer.Option(False, "--no-input", help="Disable interactive prompts"),
    dry_run: bool = typer.Option(False, "--dry-run", "-n", help="Preview without executing"),
    debug: bool = typer.Option(False, "--debug", help="Verbose logging"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="Override API base URL"),
    env: Optional[str] = typer.Option(None, "--env", help="Environment: production/sandbox"),
    version: bool = typer.Option(False, "--version", "-v", help="Show version", callback=_version_callback, is_eager=True),
) -> None:
    """Norman AI — Agentic accounting & taxes from the terminal."""

    # Determine output mode
    mode = None
    if json_output:
        mode = "json"
    elif agent_mode:
        mode = "agent"
    elif table_output:
        mode = "table"
    # else: auto-detect in OutputFormatter (piped → json, tty → table)

    set_formatter(OutputFormatter(mode=mode, wide=wide))

    # Store global state
    state.debug = debug
    state.no_input = no_input
    state.dry_run = dry_run
    state.env = env
    state.api_url = api_url

    if debug:
        logging.basicConfig(level=logging.DEBUG)

    if quiet:
        logging.disable(logging.WARNING)


# ── AI commands ──────────────────────────────────────────────────────────


@app.command()
def ask(
    prompt: str = typer.Argument(..., help="Natural language prompt for the AI agent"),
    model: str = typer.Option("gpt-4.1", "--model", "-m", help="AI model to use"),
) -> None:
    """Ask the AI agent a one-shot question.

    Examples:
      norman-ai ask "What is my company balance?"
      norman-ai ask "Create an invoice for 500 EUR to TestClient"
      norman-ai ask "Show me last month's expenses"
    """
    import asyncio
    from norman_ai_cli.ai.agent import run_one_shot

    Console(stderr=True).print("\n[bold green]norman-ai[/bold green]")
    asyncio.run(run_one_shot(prompt, model=model))


@app.command()
def chat(
    model: str = typer.Option("gpt-4.1", "--model", "-m", help="AI model to use"),
) -> None:
    """Start an interactive AI chat session.

    Type messages to the AI agent. It can search transactions, create invoices,
    check tax reports, and more.

    Commands: /clear (reset), /exit (quit)
    """
    import asyncio
    from norman_ai_cli.ai.chat import run_chat

    asyncio.run(run_chat(model=model))


# ── Smart prompts ────────────────────────────────────────────────────────


@app.command("prompts")
def smart_prompts() -> None:
    """Show available smart prompts for common tasks."""
    from norman_ai_cli.ai.smart_prompts import show_smart_prompts

    show_smart_prompts()


def main() -> None:
    """Entry point for the norman-ai command."""
    app()


if __name__ == "__main__":
    main()
