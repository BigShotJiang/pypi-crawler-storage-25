"""Interactive AI chat REPL — uses Norman's hosted streaming API."""

import json
import uuid
from datetime import datetime

from rich.console import Console
from rich.prompt import Prompt
from rich.rule import Rule

from norman_ai_cli.ai.agent import run_chat_turn
from norman_ai_cli.config import THREADS_DIR, get_token

console = Console()


def _save_thread(thread_id: str, history: list[dict]) -> None:
    """Save chat thread to disk."""
    THREADS_DIR.mkdir(parents=True, exist_ok=True)
    path = THREADS_DIR / f"{thread_id}.json"
    data = {
        "thread_id": thread_id,
        "updated_at": datetime.now().isoformat(),
        "messages": history,
    }
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False))


async def run_chat(model: str = "gpt-4.1") -> None:
    """Run interactive chat session via hosted API."""
    from norman_ai_cli.app import BANNER
    from norman_ai_cli import __version__

    console.print(BANNER.format(version=__version__))
    console.print("  [dim]Commands: /clear /history /exit[/dim]")
    console.print()

    token = get_token()
    if not token:
        console.print("[red]Not authenticated.[/red] Run [bold]norman-ai auth login[/bold] first.")
        return

    thread_id = str(uuid.uuid4())[:8]
    history: list[dict] = []

    while True:
        try:
            console.print()
            user_input = Prompt.ask("[bold cyan]you[/bold cyan]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Bye![/dim]")
            break

        if not user_input.strip():
            continue

        # Handle slash commands
        cmd = user_input.strip().lower()
        if cmd in ("/exit", "/quit", "/q"):
            console.print("[dim]Bye![/dim]")
            break
        elif cmd == "/clear":
            history.clear()
            thread_id = str(uuid.uuid4())[:8]
            console.print("[dim]Conversation cleared.[/dim]")
            continue
        elif cmd == "/history":
            if not history:
                console.print("[dim]No history yet.[/dim]")
            else:
                for msg in history[-10:]:
                    role = "[cyan]you[/cyan]" if msg["role"] == "user" else "[green]norman-ai[/green]"
                    text = msg["content"][:120]
                    console.print(f"  {role}: {text}")
            continue

        # Show norman label before response
        console.print()
        console.print("[bold green]norman-ai[/bold green]")

        try:
            response_text, _ = await run_chat_turn(
                prompt=user_input,
                history=history,
                thread_id=thread_id,
            )

            # Update history
            history.append({"role": "user", "content": user_input})
            if response_text:
                history.append({"role": "assistant", "content": response_text})

            # Keep history manageable
            if len(history) > 40:
                history = history[-40:]

            _save_thread(thread_id, history)

        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            console.print("[dim]Try again or /clear to reset.[/dim]")
