"""
satellite_general.py

This module provides general functions for satellite associated modules

"""


class Preparation:
    def __init__(self,work_path,lat_range,lon_range,time_period):
        """
        Initialize Preparation class

        Args:
            work_path (str): Working directory path
            lat_range (list): Latitude range
            lon_range (list): Longitude range
            time_period (list): Time range
        """
        self.work_path = work_path
        self.lat_range = lat_range
        self.lon_range = lon_range
        self.time_period = time_period

    def generate_time_list(self,time_period=[],time_delta=[],year=[],mon=[],day=[],hour=[],minn=[]):
        """
        Generate time list by two ways

        Args:
          time_period (list): Start time and end time.
          time_delta (list): Time step.
          year, mon, day, hour, minn (list): Specific timestamp arrays.

        Returns:
          total time list
        """
        self.year = year
        self.mon  = mon
        self.day  = day
        self.hour = hour
        self.minn = minn

###  two types for generating the time list
###  one for continuous time range; the other for specific time
        time_period = self.check_list(time_period)
        time_period = self.clean_datetime_string(time_period)
        time_list = []
###  continuous time range
        if len(time_period) > 0:
            self.time_period = time_period
            from datetime import datetime, timedelta
            time_types = self.string_info(time_info=True)
            date_1 = time_period[0]
            date_2 = time_period[1]
###  start time setting
            if len(date_1) < 12 and len(date_1) >= 10:
                s_date = datetime(int(date_1[0:4]),int(date_1[4:6]),int(date_1[6:8]),int(date_1[8:10]),0)
            elif len(date_1) < 10 and len(date_1) >= 8:
                s_date = datetime(int(date_1[0:4]),int(date_1[4:6]),int(date_1[6:8]),0,0)
            else:
                s_date = datetime(int(date_1[0:4]),int(date_1[4:6]),int(date_1[6:8]),int(date_1[8:10]),int(date_1[10:12]))
###  end time setting
            if len(date_2) < 12 and len(date_2) >= 10:
                e_date = datetime(int(date_2[0:4]),int(date_2[4:6]),int(date_2[6:8]),int(date_2[8:10]),0)
            elif len(date_2) < 10 and len(date_2) >= 8:
                e_date = datetime(int(date_2[0:4]),int(date_2[4:6]),int(date_2[6:8]),0,0)
            else:
                e_date = datetime(int(date_2[0:4]),int(date_2[4:6]),int(date_2[6:8]),int(date_2[8:10]),int(date_2[10:12]))
            #print(s_date,e_date)
            delta_value = [0,0,0]
            num = 0
            for t_type in time_types:
                for time_part in time_delta:
                    split_parts = time_part.split('=')
                    if t_type in split_parts:
                        delta_value[num] = int(split_parts[1])
                num = num + 1
            delta = timedelta(days=delta_value[0],hours=delta_value[1],minutes=delta_value[2])
            time_range = []
            #print(delta_value)
            if sum(delta_value)>0:
                while s_date <= e_date:
                    time_range.append(s_date)
                    s_date += delta
            else:
                time_range.append(s_date)

            for date in time_range:
                str_date = str(date)
                time = str_date[0:4] + str_date[5:7] + str_date[8:10] + str_date[11:13] + str_date[14:16]
                time_list.append(time)

###  specific time
        else:
          for YYYY in year:
            for MM in mon:
              for DD in day:
                for HH in hour:
                  for MN in minn:
                    time = YYYY + MM + DD + HH + MN
                    time_list.append(time)
###
        return(time_list)

    def check_list(self,unchecked_var):
        if isinstance(unchecked_var, list):
            unchecked_var = unchecked_var
        else: 
            unchecked_var = [unchecked_var]
        return(unchecked_var)

    def check_data_list(self,unchecked_array):
        if isinstance(unchecked_array, list):
            unchecked_array = unchecked_array
        else:
            unchecked_array = [unchecked_array]
        return(unchecked_array)

    def calculate_julian_date(self, year, month, day):
        from datetime import datetime
        date = datetime(year, month, day)
        julian_date = date.toordinal() + 1721425.5
        return(julian_date)

    def read_nc_boundary(self,file_name,lon_range,lat_range,array_shape):
        import netCDF4 as nc
        local_lon,local_lat = self.lonlat_index(lon_range, lat_range, array_shape=array_shape,lonlat_only=True)
        nc_re = nc.Dataset(file_name[0], 'r',  format='NETCDF4_CLASSIC')
        nclon_s = nc_re.variables['lon'][0]
        nclon_e = nc_re.variables['lon'][-1]
        nclat_s = nc_re.variables['lat'][0]
        nclat_e = nc_re.variables['lat'][-1]
        ## for convert back to lon lat range
        nclon_2 = nc_re.variables['lon'][1]
        nclat_2 = nc_re.variables['lat'][1]
        step = nclon_2 - nclon_s
        nc_lon_range = [nclon_s]
        bot_lon = int((int(round(nclon_s*10000)) - int(round(step*10000)/2))/10000)
        top_lon = int((int(round(nclon_e*10000)) + int(round(step*10000)/2))/10000)
        bot_lat = int((int(round(nclat_s*10000)) - int(round(step*10000)/2))/10000)
        top_lat = int((int(round(nclat_e*10000)) + int(round(step*10000)/2))/10000)
        nc_lon_range = [bot_lon,top_lon]
        nc_lat_range = [bot_lat,top_lat]


        if local_lon[0] >= nclon_s and local_lon[-1] <= nclon_e and local_lat[0] >= nclat_s and local_lat[-1] <= nclat_e:
           domain_flag = True
        else:
           domain_flag = False
        return (domain_flag,nc_lon_range,nc_lat_range)

    def extend_lonlat(self,nc_lon_range,nc_lat_range):
        import numpy as np
        new_lon_range = []
        new_lat_range = []
        lat_min = np.minimum(nc_lat_range[0], self.lat_range[0])
        lon_min = np.minimum(nc_lon_range[0], self.lon_range[0])
        lat_max = np.maximum(nc_lat_range[1], self.lat_range[1])
        lon_max = np.maximum(nc_lon_range[1], self.lon_range[1])
        new_lon_range.append(lon_min) 
        new_lon_range.append(lon_max)      
        new_lat_range.append(lat_min)
        new_lat_range.append(lat_max)
        return(new_lon_range, new_lat_range)

    def lonlat_index(self, lon_range, lat_range, array_shape=[], resolution=[], lonlat_only=False):
        import numpy as np
        resolution = self.check_list(resolution)
        if len(resolution) > 0:
            array_shape = 12000/resolution[0]
        x = np.arange(850024,2050024,50)/10000
        y = np.arange(-599976,600024,50)/10000
##
        ta = lon_range[0]
        diff = np.abs(x-ta)
        index = np.argmin(diff)
        x_dis_bot = np.mod(index,8)
###    lon array start
        lon_s = index - x_dis_bot

        ta = lon_range[1]
        diff = np.abs(x-ta)
        index = np.argmin(diff)
        x_dis_top = np.mod(index,8)
###    lon array end
        if x_dis_top > 0.5:
            lon_e = index + (8 - x_dis_top)
        else:
            lon_e = index
##
        ta = lat_range[0]
        diff = np.abs(y-ta)
        index = np.argmin(diff)
        y_dis_bot = np.mod(index,8)
###    lat array start
        lat_s = index - y_dis_bot

        ta = lat_range[1]
        diff = np.abs(y-ta)
        index = np.argmin(diff)
        y_dis_top = np.mod(index,8)
###    lat array end
        if y_dis_top > 0.5:
            lat_e = index + (8 - y_dis_top)
        else:
            lat_e = index
        scale_factor = int(24000/array_shape)
        resol = 50*scale_factor
        center = resol/2
        xx = np.arange(850000+center,2050000+center,resol)/10000
        yy = np.arange(-600000+center,600000+center,resol)/10000
#        print('lon',xx[0],xx[-1])
#        print('lat',yy[0],yy[-1])

        lon_idx = [int(lon_s/scale_factor),int(lon_e/scale_factor)]
        lat_idx = [int(lat_s/scale_factor),int(lat_e/scale_factor)]
#  print(lon_idx[0],lon_idx[1])
#  print(lat_idx[0],lat_idx[1])
        local_lon=xx[lon_idx[0]:lon_idx[1]]
        local_lat=yy[lat_idx[0]:lat_idx[1]]
#        print(local_lon[0],local_lon[-1])
#        print(local_lat[0],local_lat[-1])
        if lonlat_only:
            return(local_lon,local_lat)
        else:
            return(lon_idx,lat_idx,local_lon,local_lat)

    def band_name_convert(self,band_info,AHI2CEReS=True):
        band_info = self.check_list(band_info)
        band_table, AHI_band_num_table = self.string_info(nc_info=True)
        CEReS_type = []
        CEReS_num = []
        if AHI2CEReS:
            for band in band_info:
                AHI_num = str(band)
                if band < 10:
                   AHI_num = '0' + AHI_num
                pos_idx = AHI_band_num_table.index(AHI_num) 
                band_name = band_table[pos_idx]
                band_type = band_name[0:3].upper()
                band_num = int(band_name[3:5])
                if band_type not in CEReS_type:
                    CEReS_type.append(band_type)
                if band_num not in CEReS_num:
                    CEReS_num.append(band_num)
        return(CEReS_type,sorted(CEReS_num))

    def date_path_generate(self,band_date):
        path_year = band_date[0:4]
        path_mon = band_date[4:6]
        path_day = band_date[6:8]
        if self.data_end_path == 'month':
            date_path = ''+path_year+'/'+path_mon+''
        elif self.data_end_path == 'year':
            date_path = path_year
        else:
            date_path = ''+path_year+'/'+path_mon+'/'+path_day+''
        return(date_path)

    def sub_domain_path_generate(self,date_path,sub_domain_data_folder=[]):
        """
        This function do not modify the pre-define "self.sub_domain_data_folder"
        Only when given the input "sub_domain_data_folder", the sub_domain_path will be generated
        depending on "sub_domain_data_folder" rather than "self.sub_domain_data_folder"
        """
        if len(sub_domain_data_folder) > 0:
            #self.sub_domain_data_folder = sub_domain_data_folder
            nc_data_path = self.data_path + '/' +sub_domain_data_folder + '/'+date_path+''
        else:
            nc_data_path = self.data_path + '/'+self.sub_domain_data_folder+'/'+date_path+''
        return(nc_data_path)

    def clean_datetime_string(self,string_list):
        import re
        string_list = self.check_list(string_list)
        clean_string = []
        for i in range(0,len(string_list)):
            c_string = re.sub(r'\D', '', string_list[i])
            clean_string.append(c_string)
        return(clean_string)

    def string_info(self, binary_info=False, band_info=False, band_num_info=False,nc_info=False,nc_4km_info=False,nc_4km_var_info=False,time_info=False,nc_plotting_list=False):
###
        binary_types = ['geoss', 'bin', 'dat']
        band_types = ['4km','cap', 'ext', 'vis', 'sir', 'tir']
        band_num_types = ['4km','cap', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10']
###    for nc file info
        band_table = ['ext01','vis01','vis02','vis03','sir01','sir02','tir01','tir02',
                      'tir03','tir04','tir05','tir06','tir07','tir08','tir09','tir10']
        AHI_band_num_table = ['03','01','02','04','05','06','13','14',
                              '15','16','07','08','09','10','11','12']
        band_resolution = [24000, 12000, 12000, 12000, 6000, 6000, 6000, 6000,
                           6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000]

        data_type_table_4km = ['sun','sat','lat','lng','grd','cap','rad','rfc','rfy','tbb']
        angle_types = ['azm','zth']
###    for 4km nc var info
        geo_name_table = ['sun.azm','sun.zth','sat.azm','sat.zth','lat','lng',
                                  'grd.time.mjd.hms','cap.flg']
        nc_data_type_table_4km = ['sun_azm','sun_zth','sat_azm','sat_zth','lat','lng',
                                  'grd_time_mjd_hms','cap_flg','rad','rfc','rfy','tbb']
        var_name_table = ['sun_azm','sun_zth','sat_azm','sat_zth','latt','lng',
                          'grd_time_mjd_hms','cap_flg','rad','rfc','rfy','tbb']
        long_name_table = ['Solar azimuth angle (South direction is zero, clockwise rotation)',
                           'Solar zenith angle',
                           'Sensor azimuth angle (South direction is zero, clockwise rotation)',
                           'Sensor zenith angle','Latitude','Longitude',
                           'Scanning time（Normalized 0 to 1, i.e., 12:00 UTC is 0.5)',
                           'Cloud flag (Daytime and over ocean only. More than 1 represents cloud)',
                           'irradiance','spectral reflectance',
                           'spectral reflectance','brightness temperature']
        units_table = ['degree','degree','degree','degree','degree','degree',
                       'None','None','W m-2 sr-1 μm-1','None','%','K']
        missing_value_table = [-99.0,-99.0,-99.0,-99.0,-99.0,-99.0,
                               -99.0,-99.0,-99.0,-99.0,-99.0,-99.0]
        time_types = ['days','hours','minutes']
        if binary_info:
            return(binary_types)
        if band_info:
            return(band_types)
        if band_num_info:
            return(band_num_types)
        if nc_info:
            return(band_table, AHI_band_num_table)
        if nc_4km_info:
            return(band_table, AHI_band_num_table, data_type_table_4km, angle_types)
        if nc_4km_var_info:
            return(nc_data_type_table_4km,var_name_table,long_name_table,units_table,missing_value_table)
        if time_info:
            return(time_types)
        if nc_plotting_list:
            return(band_table, AHI_band_num_table, band_resolution, geo_name_table, nc_data_type_table_4km)


    def information(self, detail=False):
        self.detail = detail
        print('Himawari-8 data strat from 2015/07/07 0200UTC.')
        print('Full disk covered area: 85E – 205E (155W), 60N – 60S')
        print('')
        print('Band data & geo-info data that can be downloaded')
        print('-------------------------------------------------------')
        print('[EXT] 01:Band03')
        print('[VIS] 01:Band01 02:Band02 03:Band04')
        print('[SIR] 01:Band05 02:Band06')
        print('[TIR] 01:Band13 02:Band14 03:Band15 04:Band16 05:Band07')
        print('      06:Band08 07:Band09 08:Band10 09:Band11 10:Band12')
        print('[GEO] Solar azimuth angle(sun.azm) Solar zenith angle(sun.zth)')
        print('      Sensor azimuth angle(sat.azm) Sensor zenith angle(sat.zth)')
        print('-------------------------------------------------------')
        print('')
        print('Download period & data template')
        print('-------------------------------------------------------')
        print('year = [\'2015\']               # Year:   from 2015')
        print('mon  = [\'07\',\'09\']            # Month:  01 02 ... 12')
        print('day  = [\'07\']                 # Day:    01 02 ... 30 31')
        print('hour = [\'02\']                 # Hour:   00 01 ... 23')
        print('minn = [\'00\']                 # Minute: 00 10 20 30 40 50')
        print('Set band type')
        print('band = ['+'EXT'+', '+'VIS'+', '+'SIR'+', '+'TIR'+']   # band: VIS TIR SIR EXT')
        print('band_num = ['+'1,2,3'+']            # band number: 1 2 ... 10')
        print('geo = [\'sun.azm\', \'sun.zth\']  # geo-info: sun.azm sun.zth sat.azm sat.zth ...')
        print('-------------------------------------------------------')
        print('You don\'t need to download a continuous time interval.')
        print('Instead, you can choose a customized time resolution based on your research purpose:')
        print('Such as one entry per hour, one entry per day, ... or even one entry per year.')
        print('-------------------------------------------------------')
        print('')
        print('[EXT], [VIS], [SIR]: albedo [%]; [TIR]: brightness temperature [K]')
        print('')
        print('[EXT] Resolution: 0.005 degree;   array_size: (24000,24000)')
        print('[VIS] Resolution: 0.01 degree;    array_size: (12000,12000)')
        print('[SIR] Resolution: 0.02 degree;    array_size: (6000,6000)')
        print('[TIR] Resolution: 0.02 degree;    array_size: (6000,6000)')
        print('[GEO] Resolution: 0.04 degree;    array_size: (3000,3000)')
        print('')
        print('Reference: http://www.cr.chiba-u.jp/databases/GEO/H8_9/FD/index.html')
        if detail:
            print('')
            print('Extra information')
            print('-------------------------------------------------------')
            print('GrADS control file lat lon format')
            print('[EXT]')
            print('xdef 24000 linear 85.0025  0.005')
            print('ydef 24000 linear -59.9975 0.005')
            print('[VIS]')
            print('xdef 12000 linear 85.005  0.01')
            print('ydef 12000 linear -59.995 0.01')
            print('[SIR] & [TIR]')
            print('xdef 6000 linear 85.01  0.02')
            print('ydef 6000 linear -59.99 0.02')
            print('[GEO]')
            print('xdef 3000 linear 85.02  0.04')
            print('ydef 3000 linear -59.98 0.04')
            print('')
            print('-------------------------------------------------------')
            print('Full geometries dataset include:')
            print('[GEO]')
            print('xdef 3000 linear 85.02  0.04')
            print('ydef 3000 linear -59.98 0.04')
            print('')
            print('-------------------------------------------------------')
            print('Full geometries dataset include:')
            print('[GEO]')
            print('Solar azimuth angle(sun.azm) Solar zenith angle(sun.zth)')
            print('Sensor azimuth angle(sat.azm) Sensor zenith angle(sat.zth)')
            print('Latitude(lat) Longitude(lng)')
            print('Scanning time(grd.time.mjd.hms) Cloud flag(cap)')
            print('')
            print('All band data also provide 0.04degree(4km) resolution physical variables converted data:')
            print('[BAND]')
            print('YYYYMMDDHHMN.xxx.ZZ.rad.fld.4km.bin.bz2 (xxx: ext, vis, sir, tir; ZZ: CEReS gridded data band number) ')
            print('ext, vis, sir, tir irradiance (unit: W m-2 sr-1 μm-1) ')
            print('YYYYMMDDHHMN.xxx.ZZ.rfc.fld.4km.bin.bz2 (xxx: ext, vis, sir; ZZ: CEReS gridded data band number) ')
            print('ext, vis, sir spectral reflectance (dimensionless) ')
            print('YYYYMMDDHHMN.xxx.ZZ.rfy.fld.4km.bin.bz2 (xxx: ext, vis, sir; ZZ: CEReS gridded data band number) ')
            print('ext, vis, sir spectral reflectance (%)')
            print('YYYYMMDDHHMN.tir.ZZ.tbb.fld.4km.bin.bz2 (ZZ: CEReS gridded data band number) ')
            print('tir (only) brightness temperature (Tbb (K)) ')
            print('-------------------------------------------------------')

    """
    CloudSat general function
    """
    def generate_period(self,year_list, ju_day_list, start_end_time_list):
        year_list = self.check_list(year_list)
        ju_day_list = self.check_list(ju_day_list)
        start_end_time_list = self.check_list(start_end_time_list)
        search_period = []
        for yy in range(0,len(year_list)):
            order = 0
            limit = len(ju_day_list[yy])
            ju_day = ju_day_list[yy]
            hour = start_end_time_list[yy]
            file_y = str(year_list[yy])
            for dd in range(0,len(ju_day)):
                file_d = str(ju_day[dd])
                if ju_day[dd] < 100:
                    file_d = '0' + file_d
                if ju_day[dd] < 10:
                    file_d = '0' + file_d
                end_hours = []
                if order == limit-1:
###  period less than one day
                    if order == 0:
                        if int(hour[0][0:4]) == 0 and int(hour[1][0:4]) > 2350:
                            target_time = [file_y  + file_d]
                            search_period.extend(target_time)
                        else:
                            end_hours = list(range(int(hour[0][0:2]),int(hour[1][0:2])))
                            ### time 
                            if int(hour[1][3:4]) > 0:
                                end_10mins = list(range(0,int(hour[1][2:3])+1))
                            else:
                                end_10mins = list(range(0,int(hour[1][2:3])))
                            ### time period within one hour
                            if len(end_hours) == 0:
                                start_hour = int(hour[0][0:2])
                                file_h = str(start_hour)
                                if start_hour < 10:
                                    file_h = '0' + file_h
                                if int(hour[1][3:4]) > 0:
                                    start_10mins = list(range(int(hour[0][2:3]),int(hour[1][2:3])+1))
                                else:
                                    start_10mins = list(range(int(hour[0][2:3]),int(hour[1][2:3])))
                                if len(start_10mins) < 6:
                                    for single_min in start_10mins:
                                        file_m = str(single_min)
                                        target_time = [file_y + file_d + file_h + file_m]
                                        search_period.extend(target_time)
                                else:
                                    target_time = [file_y + file_d + file_h]
                                    search_period.extend(target_time)
                            ### time period > one hour
                            if len(end_hours) > 0:
                                first_hour = 0
                                for single_hour in end_hours:
                                    ### add start 10min
                                    start_10mins = list(range(int(hour[0][2:3]),6))
                                    if int(hour[0][2:3]) > 0 and first_hour == 0:
                                        file_h = str(single_hour)
                                        if single_hour < 10:
                                            file_h = '0' + file_h
                                        for single_min in start_10mins:
                                            file_m = str(single_min)
                                            target_time = [file_y + file_d + file_h + file_m]
                                            search_period.extend(target_time)
                            ###
                                    else:
                                        target_time_ydh = self.target_time_yr_d_hr(file_y, file_d, single_hour)
                                        search_period.extend(target_time_ydh)
                                    first_hour = first_hour +1
                                ###
                            if len(end_10mins) > 0 and len(end_hours) > 0:
                                file_h = str(end_hours[-1]+1)
                                if single_hour < 10:
                                    file_h = '0' + file_h
                                if int(hour[1][2:4]) > 50:
                                    target_time = [file_y + file_d + file_h ]
                                    search_period.extend(target_time)
                                else:
                                    for single_min in end_10mins:
                                        file_m = str(single_min)
                                        target_time = [file_y + file_d + file_h + file_m]
                                        search_period.extend(target_time)
###  period large than one day
###  last day start from 00:00UTC
                    else:
                        if int(hour[1][0:4]) > 2350:
                            target_time = [file_y + file_d]
                            search_period.extend(target_time)
                        else:
                            end_hours = list(range(0,int(hour[1][0:2])))
                            if int(hour[1][3:4]) > 0:
                                end_10mins = list(range(0,int(hour[1][2:3])+1))
                            else:
                                end_10mins = list(range(0,int(hour[1][2:3])))
                            
                            if len(end_hours) > 0:
                                for single_hour in end_hours:
                                    target_time_ydh = self.target_time_yr_d_hr(file_y, file_d, single_hour)
                                    search_period.extend(target_time_ydh)
                            if len(end_10mins) > 0:
                                file_h = str(end_hours[-1]+1)
                                if single_hour < 10:
                                    file_h = '0' + file_h
                                if int(hour[1][2:4]) > 50: 
                                    target_time = [file_y + file_d + file_h ]
                                    search_period.extend(target_time)
                                else:
                                    for single_min in end_10mins:
                                        file_m = str(single_min)
                                        target_time = [file_y + file_d + file_h + file_m]
                                        search_period.extend(target_time)
###  end time else
### start time
### period large than one day
                elif order == 0 and int(hour[0][2:3]) > 0 :
### min range
                    end_10mins = list(range(int(hour[0][2:3]),6))
                    end_hours = list(range(int(hour[0][0:2]),24))
                    if len(end_hours) > 0:
                        first_hour = 0
                        for single_hour in end_hours:
                            ### add start 10min
                            if int(hour[0][2:3]) > 0 and first_hour == 0:
                                file_h = str(single_hour)
                                if single_hour < 10:
                                    file_h = '0' + file_h
                                for single_min in end_10mins:
                                    file_m = str(single_min)
                                    target_time = [file_y + file_d + file_h + file_m]
                                    search_period.extend(target_time)
                            ###
                            else:
                                target_time_ydh = self.target_time_yr_d_hr(file_y, file_d, single_hour)
                                search_period.extend(target_time_ydh)
                            first_hour = first_hour +1
### normal condition
                elif order == 0 and int(hour[0][0:2]) > 0:
                    end_hours = list(range(int(hour[0][0:2]),24))
                    if len(end_hours) > 0:
                        for single_hour in end_hours:
                            target_time_ydh = self.target_time_yr_d_hr(file_y, file_d, single_hour)
                            search_period.extend(target_time_ydh)
                else:
                    target_time = [file_y + file_d]
                    search_period.extend(target_time)
###
                order = order + 1
        return(search_period)

    def convert_input_period(self,time_period,julian=True):
        time_period = self.check_list(time_period)
        time_period = self.clean_datetime_string(time_period)
        year = []
        start_end_time = []
        year.append(time_period[0][0:4])
        #if len()
        #t1 = [time_period[0][8:12],time_period[1][8:12]]
        if year[0] != time_period[1][0:4]:
            year.append(time_period[1][0:4])
        total_period = []
        if len(year) > 1:
            period1 = [time_period[0],year[0]+'12312400']
            period2 = [year[0]+'01010000',time_period[1]]
            total_period.append(period1)
            total_period.append(period2)
        else:
            total_period.append(time_period)
        ju_day = []
        for period in total_period:
            t1_t2 = []
            if len(period[0])<12 and len(period[0])>=10:
                t1_t2.append(period[0][8:10]+'00')
            elif len(period[0])<10 and len(period[0])>=8:
                t1_t2.append('0000')
            else:
                t1_t2.append(period[0][8:12])
            if len(period[1])<12 and len(period[1])>=10:
                t1_t2.append(period[1][8:10]+'00')
            elif len(period[1])<10 and len(period[1])>=8:
                t1_t2.append('0000')
            else:
                t1_t2.append(period[1][8:12])
            #t1_t2 = [period[0][8:10],period[1][8:10]]
            print(period[0],period[1])
            start_end_time.append(t1_t2)
            if julian:
                ju_day.append(self.julian_time_range(period))
            else:
                ju_day.append(self.date_time_range(period))
        return(year, ju_day, start_end_time)

    def julian_time_range(self,time_period):
        from datetime import datetime
        time_period = self.check_list(time_period)
        time_period = self.clean_datetime_string(time_period)
        ju_day = []
        for time in time_period:
            year = int(time[0:4])
            mon = int(time[4:6])
            day = int(time[6:8])
            date = datetime(year, mon, day)
            ju = date.timetuple().tm_yday
            ju_day.append(ju)
        ju_list = list(range(ju_day[0],ju_day[1]+1))
        return(ju_list)
    
    def target_time_yr_d_hr(self, file_year, file_day, single_hr, hr_mn_separate=False):
        file_h = str(single_hr)
        if single_hr < 10:
            file_h = '0' + file_h
        if hr_mn_separate:
            target_time_ydh = [file_year + file_day + 'T' + file_h]
        else:
            target_time_ydh = [file_year + file_day + file_h]
        return(target_time_ydh)

    def fit_era5_lon(self,lon_list):
        import numpy as np
        lon_list = self.check_list(lon_list)
        era5_lon_list = []
        for i in range(0,len(lon_list)):
            lon_array = np.array(lon_list[i])
            lon_array = np.where(lon_array >= 0, lon_array, lon_array+360)
            era5_lon_list.append(lon_array)
        return(era5_lon_list)

    def regional_filter(self, data_lon, data_lat, data_quality=None, extracted_lon_range=[],extracted_lat_range=[], quality_value=0.1):
        import numpy as np
        arr_size=len(data_lon)
        if len(extracted_lon_range)<1 and len(extracted_lat_range)<1:
            lon_s = self.lon_range[0]
            lon_e = self.lon_range[1]
            lat_s = self.lat_range[0]
            lat_e = self.lat_range[1]
        else:
            lon_s = extracted_lon_range[0]
            lon_e = extracted_lon_range[1]
            lat_s = extracted_lat_range[0]
            lat_e = extracted_lat_range[1]

        #print(lon_s,lon_e,lat_s,lat_e)

        lon_list = self.fit_era5_lon([data_lon])
        data_lon = lon_list[0]
        data_lat = np.array(data_lat)
        #print(data_lon.shape)
        #print(data_lat.shape)
        tem_mask = np.zeros((arr_size,1))
        if data_quality == None:
            tem_mask = np.where((data_lon >= lon_s) & (data_lon <= lon_e) & (data_lat >= lat_s) & (data_lat <= lat_e), tem_mask+1, tem_mask)
        else:
            data_quality = np.array(data_quality)
            data_quality = data_quality
            tem_mask = np.where((data_lon >= lon_s) & (data_lon <= lon_e) & (data_lat >= lat_s) & (data_lat <= lat_e) & (data_quality < quality_value), tem_mask+1, tem_mask)

        mask = np.zeros((arr_size,1))
        #print(tem_mask.shape)
        mask[:,:] = tem_mask
        return(mask,data_lon,data_lat)

    def cloudsat_string_info(self,night_time=False):
        color_step = [1,2,3,4,5,1,2,3,4,5,6,7,8,1,2,3,4,5,6,7,8,1,2,3,4]
        local_ref_time_day = ['13','12','11','10','09','08','07',
                              '06','05','04','03','02','01','00',
                              '23','22','21','20','19','18','17',
                              '16','15','14','13']
        local_ref_time_night = ['01','00','23','22','21','20','19',
                                '18','17','16','15','14','13','12',
                                '11','10','09','08','07','06','05',
                                '04','03','02','01']
        if night_time:
            return(color_step,local_ref_time_day,local_ref_time_night)
        else:
            return(color_step,local_ref_time_day)
    """
    EarthCARE general function 
    """
    def generate_date_period(self, year_list, date_day_list, start_end_time_list):
        year_list = self.check_list(year_list)
        date_day_list = self.check_list(date_day_list)
        start_end_time_list = self.check_list(start_end_time_list)
        search_period = []
        for yy in range(0,len(year_list)):
            order = 0
            limit = len(date_day_list[yy])
            date_day = date_day_list[yy]
            hour = start_end_time_list[yy]
            file_y = str(year_list[yy])
            for dd in range(0,len(date_day)):
                file_d = str(date_day[dd])
                end_hours = []
                if order == limit-1:
###  period less than one day
                    if order == 0:
                        if int(hour[0][0:4]) == 0 and int(hour[1][0:4]) > 2350:
                            target_time = [file_y  + file_d + 'T']
                            search_period.extend(target_time)
                        else:
                            end_hours = list(range(int(hour[0][0:2]),int(hour[1][0:2])))
                            ### time
                            if int(hour[1][3:4]) > 0:
                                end_10mins = list(range(0,int(hour[1][2:3])+1))
                            else:
                                end_10mins = list(range(0,int(hour[1][2:3])))
                            ### time period within one hour
                            if len(end_hours) == 0:
                                start_hour = int(hour[0][0:2])
                                file_h = str(start_hour)
                                if start_hour < 10:
                                    file_h = '0' + file_h
                                if int(hour[1][3:4]) > 0:
                                    start_10mins = list(range(int(hour[0][2:3]),int(hour[1][2:3])+1))
                                else:
                                    start_10mins = list(range(int(hour[0][2:3]),int(hour[1][2:3])))
                                if len(start_10mins) < 6:
                                    for single_min in start_10mins:
                                        file_m = str(single_min)
                                        target_time = [file_y + file_d + 'T' + file_h + file_m]
                                        search_period.extend(target_time)
                                else:
                                    target_time = [file_y + file_d + 'T' + file_h]
                                    search_period.extend(target_time)
                            ### time period > one hour
                            if len(end_hours) > 0:
                                first_hour = 0
                                for single_hour in end_hours:
                                    ### add start 10min
                                    start_10mins = list(range(int(hour[0][2:3]),6))
                                    if int(hour[0][2:3]) > 0 and first_hour == 0:
                                        file_h = str(single_hour)
                                        if single_hour < 10:
                                            file_h = '0' + file_h
                                        for single_min in start_10mins:
                                            file_m = str(single_min)
                                            target_time = [file_y + file_d + 'T' + file_h + file_m]
                                            search_period.extend(target_time)
                            ###
                                    else:
                                        target_time_ydh = self.target_time_yr_d_hr(file_y, file_d, single_hour, hr_mn_separate=True)
                                        search_period.extend(target_time_ydh)
                                    first_hour = first_hour +1
                                ###
                            if len(end_10mins) > 0 and len(end_hours) > 0:
                                file_h = str(end_hours[-1]+1)
                                if single_hour < 10:
                                    file_h = '0' + file_h
                                if int(hour[1][2:4]) > 50:
                                    target_time = [file_y + file_d + 'T' + file_h ]
                                    search_period.extend(target_time)
                                else:
                                    for single_min in end_10mins:
                                        file_m = str(single_min)
                                        target_time = [file_y + file_d + 'T' + file_h + file_m]
                                        search_period.extend(target_time)
###  period large than one day
###  last day start from 00:00UTC
                    else:
                        if int(hour[1][0:4]) > 2350:
                            target_time = [file_y + file_d + 'T']
                            search_period.extend(target_time)
                        else:
                            end_hours = list(range(0,int(hour[1][0:2])))
                            if int(hour[1][3:4]) > 0:
                                end_10mins = list(range(0,int(hour[1][2:3])+1))
                            else:
                                end_10mins = list(range(0,int(hour[1][2:3])))

                            if len(end_hours) > 0:
                                for single_hour in end_hours:
                                    target_time_ydh = self.target_time_yr_d_hr(file_y, file_d, single_hour, hr_mn_separate=True)
                                    search_period.extend(target_time_ydh)
                            if len(end_10mins) > 0:
                                file_h = str(end_hours[-1]+1)
                                if single_hour < 10:
                                    file_h = '0' + file_h
                                if int(hour[1][2:4]) > 50:
                                    target_time = [file_y + file_d + 'T' + file_h ]
                                    search_period.extend(target_time)
                                else:
                                    for single_min in end_10mins:
                                        file_m = str(single_min)
                                        target_time = [file_y + file_d + 'T' + file_h + file_m]
                                        search_period.extend(target_time)
###  end time else
### start time
### period large than one day
                elif order == 0 and int(hour[0][2:3]) > 0 :
### min range
                    end_10mins = list(range(int(hour[0][2:3]),6))
                    end_hours = list(range(int(hour[0][0:2]),24))
                    if len(end_hours) > 0:
                        first_hour = 0
                        for single_hour in end_hours:
                            ### add start 10min
                            if int(hour[0][2:3]) > 0 and first_hour == 0:
                                file_h = str(single_hour)
                                if single_hour < 10:
                                    file_h = '0' + file_h
                                for single_min in end_10mins:
                                    file_m = str(single_min)
                                    target_time = [file_y + file_d + 'T' + file_h + file_m]
                                    search_period.extend(target_time)
                            ###
                            else:
                                target_time_ydh = self.target_time_yr_d_hr(file_y, file_d, single_hour, hr_mn_separate=True)
                                search_period.extend(target_time_ydh)
                            first_hour = first_hour +1
### normal condition
                elif order == 0 and int(hour[0][0:2]) > 0:
                    end_hours = list(range(int(hour[0][0:2]),24))
                    if len(end_hours) > 0:
                        for single_hour in end_hours:
                            target_time_ydh = self.target_time_yr_d_hr(file_y, file_d, single_hour, hr_mn_separate=True)
                            search_period.extend(target_time_ydh)
                else:
                    target_time = [file_y + file_d + 'T']
                    search_period.extend(target_time)
###
                order = order + 1
        return(search_period)
     
    def date_time_range(self,time_period):
        from datetime import datetime
        time_period = self.check_list(time_period)
        time_period = self.clean_datetime_string(time_period)
        time_delta = ['days=1','hours=0','minutes=0']
        time_list = self.generate_time_list(time_period=time_period,time_delta=time_delta)
        date_list = []
        for date in time_list:
            date_list.append(date[4:8])
        return(date_list)

    """
    shifting download mode to ftplib
    """

    def process_ftp_path(self,ftp_path_file_list,save_path,log_file):
        """
        Download data from anonymous login FTP
        Call
            self.ftp_connect
            self.retr_get
            self.parse_ftp_path
            self.log_status
        ----------
        host: str
            FTP address
        ftp_dir: str
            Data folder
        filename: str
            Filename
        save_path: str
            Local data folder + local filename
        log_file: str
            Log file name
        """
        host, ftp_dir, filename = self.parse_ftp_path(ftp_path_file_list)
        try:
            ftp = self.ftp_connect(host)
        except Exception as e:
            self.log_status(log_file, filename, 'Connection_Fail', str(e))
            return
        try:
            status = self.retr_get(ftp,ftp_dir,filename,save_path)
            if status != None:
                self.log_status(log_file, filename, status)
        finally:
            try:
                ftp.quit()
            except Exception:
                pass

    def ftp_connect(self,host, re_login=3, timeout=30):
        import socket
        from ftplib import FTP
        import time
        for i in range(0, re_login):
            try:
                ftp = FTP(host, timeout=timeout)
                ftp.login()
                return ftp
            except (socket.timeout, ConnectionRefusedError, OSError) as e:
                if i == re_login - 1:
                    raise
                time.sleep(2 ** i)

    def retr_get(self,ftp,ftp_dir,filename,save_path,retries=3):
        from ftplib import FTP, error_perm, all_errors
        import os
        import time
        # temporary download
        ftp.cwd(ftp_dir)
        tmp_path = save_path + ".part"
        for i in range(retries):
            try:
                with open(tmp_path, 'wb') as f:
                    ftp.retrbinary(f"RETR {filename}", f.write)
                if os.path.getsize(tmp_path) == 0:
                    raise IOError('Downloaded file is empty')
                os.replace(tmp_path, save_path)
                return None
            except error_perm as e:
                # FTP no file message (550)
                if '550' in str(e):
                    if os.path.exists(tmp_path):
                        os.remove(tmp_path)
                    return 'No_File_on_Server'
                else:
                    raise
            except all_errors as e:
                # connection error
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
                if i == retries - 1:
                    return 'Download_Fail'
                # retry time gap
                time.sleep(2 ** i)

    def log_status(self,log_file, filename, status, message=""):
        from datetime import datetime
        ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(log_file, 'a') as f:
            f.write(f"{filename}, {status}, {ts} {message}\n")

    def parse_ftp_path(self,ftp_path_file_list):
        import os
        from urllib.parse import urlparse
        parse = urlparse(ftp_path_file_list)
        host = parse.hostname
        full_path = parse.path
        ftp_dir, filename = os.path.split(full_path)
        return host, ftp_dir, filename

    def cleanup_part_files_recursive(self, storage_path, suffix='.part', dry_run=False):
        """
        Recursively remove *.part files under out_dir
        Parameters
        ----------
        storage_path : str
            Data directory to clean
        suffix : str
            File suffix to remove (default: '.part')
        dry_run : bool
            If True, only print files to be removed
        """
        import os
        removed = 0
        for root, dirs, files in os.walk(storage_path):
            for filename in files:
                if filename.endswith(suffix):
                    path = os.path.join(root, filename)

                    if dry_run:
                        print(f"[DRY-RUN] remove {path}")
                    else:
                        try:
                            os.remove(path)
                            removed += 1
                        except Exception as e:
                            print(f"[WARN] failed to remove {path}: {e}")

        print(f"[CLEANUP] removed {removed} '{suffix}' files under {storage_path}")

    """
    download some data via satellite tool
    """
    def generate_mimic_tpw2_time_list(self,time_period=[],time_delta=[]):
        time_period = self.check_list(time_period)
        time_period = self.clean_datetime_string(time_period)
        date_1 = time_period[0]
        if len(date_1) > 10:
            minn = date_1[10:]
            if int(minn) > 0:
                period_iner = [time_period[0][0:10],time_period[1]]
                time_list = self.generate_time_list(time_period=period_iner,time_delta=time_delta)
                time_list = time_list[1:]
            else:
                time_list = self.generate_time_list(time_period=time_period,time_delta=time_delta)
        else:
            time_list = self.generate_time_list(time_period=time_period,time_delta=time_delta)
        return(time_list)

    def generate_mimic_tpw2_data_list(self, time_list=[],
                                     mimicftp = 'ftp://ftp.ssec.wisc.edu/pub/mtpw2/data'):
        file_list = []
        ftp_path_file_list = []
        for i in range(0,len(time_list)):
            #print(time_list[i])
            year_mm = time_list[i][0:6]
            data_time = time_list[i][0:8]+'.'+ time_list[i][8:10]
            filename = 'comp'+data_time+'0000.nc'
            filelist = mimicftp +'/' + year_mm +'/'+ filename
            file_list.append(filename)
            ftp_path_file_list.append(filelist)
            #print(filelist)
        return(file_list, ftp_path_file_list)

    def download_mimic_tpw2(self,ftp_path_file_list, 
                           mimic_data_path='/data/C.jerryjerry9/MIMIC_TPW2/test', 
                           log_file='/data/C.jerryjerry9/MIMIC_TPW2/mimic_test',
                           download_flag=True,method='ftplib'):
        import os
        import glob
        download_flag=True
        file_path = self.check_list(ftp_path_file_list)
        method = method.lower()
        if method not in ['ftplib']:
            print('Choose download method: ftplib, or data will not be downloaded')
        print('Downloading...')
        for download_file in file_path:
            file_name = os.path.basename(download_file)
            year_mm = file_name[4:10]
            download_path = mimic_data_path + '/' + year_mm
            os.makedirs(download_path, exist_ok=True)
            ###    check file already downloaded or not
            downloaded_file = sorted(glob.glob(download_path+'/'+file_name))
            file_len = len(downloaded_file)
            ###    download file
            if download_flag and file_len < 1:
                print(file_name)
                save_path = os.path.join(download_path, file_name)
                #print(save_path)
                if method == 'ftplib':
                    log_file_full = log_file + '.csv'
                    self.process_ftp_path(download_file,save_path,log_file_full)
            else:
                print(''+file_name+'','Data already exist')
            downloaded_file = sorted(glob.glob(download_path+'/'+file_name))
            file_len = len(downloaded_file)
            if file_len < 1:
                file_path = list(filter(lambda x: file_name not in x, file_path))
        return(file_path)


    """
    read other satellite function
        imerg, MIMIC TPW2 
    read era5 function
    re-grid data to era5 grid
    --
    read ori data
    extract sub domain data (lat-lon dependence)
    preprocess
    """

    def read_imerg(self,file_list,var_name,fit_era5_lon_roll=True,fit_latlon_order=True,fill_nan=True):
        import netCDF4 as nc
        import numpy as np
        file_list  = self.check_list(file_list)
        var_name = self.check_list(var_name)
        var_list = []
        for i in range(0,len(file_list)):
            re = nc.Dataset(file_list[i], 'r',  format='NETCDF4_CLASSIC')
            for var in var_name:
                spatial_array = False
                grid = re.groups['Grid']
                group = self.imerg_group_check(var)
                ## grid vars
                if group[0] == 'Grid':
                    var_loaded = grid.variables[var]
                ## Intermediate vars
                else:
                    intermediate = grid.groups['Intermediate']
                    var_loaded = intermediate.variables[var]
                var_data = np.array(var_loaded)
                if len(var_data.shape) > 2:
                    spatial_array = True
                    fill_value = var_loaded._FillValue
                if fit_era5_lon_roll:
                    if spatial_array:
                        var_data = np.roll(var_data,-1800,axis=1)
                    elif var_data.shape[0]>2000:
                        var_data = np.where(var_data >= 0, var_data, var_data+360)
                        var_data = np.roll(var_data,-1800,axis=0)
                if spatial_array: 
                    if fit_latlon_order:
                        var_data = var_data[0,:,:].T
                    if fill_nan:
                        var_data[var_data==fill_value] = np.nan
            re.close()
            var_data = self.check_list(var_data)
            var_list.append(var_data[0])
        return(var_list)

    def read_airs_l3(self):
        pass
    def read_mimic_tpw2(self,file_list,var_name,fit_era5_lon_roll=True):
        import netCDF4 as nc
        import numpy as np
        file_list  = self.check_list(file_list)
        var_name = self.check_list(var_name)
        var_list = []
        for i in range(0,len(file_list)):
            re = nc.Dataset(file_list[i], 'r',  format='NETCDF4_CLASSIC')
            for var in var_name:
                var_data = np.array(re.variables[var])
                if fit_era5_lon_roll:
                    ### 2d-array variable
                    if len(var_data.shape) > 1:
                        var_data = np.roll(var_data,-720,axis=1)
                    ### 1d-array & array length fit lon length
                    elif var_data.shape[0]>1000:
                        var_data = np.where(var_data >= 0, var_data, var_data+360)
                        var_data = np.roll(var_data,-720,axis=0)
            re.close()
            var_data = self.check_list(var_data)
            var_list.append(var_data[0])
        return(var_list)    

    def sub_domain_extract_imerg(self,var_list,lon_range=[],lat_range=[],sub_domain_lonlat=True):
        """
        this function is for fit-era5-lon rolled data array
        """
        import numpy as np
        var_list = self.check_list(var_list)
        if len(lon_range)<1:
           lon_range = self.lon_range
        if len(lat_range)<1:
           lat_range = self.lat_range
        
        lon_idx,lat_idx,local_lon,local_lat = self.lonlat_index_01km(lon_range,lat_range)
        sub_domain_var_list = []

        for i in range(0, len(var_list)):
            sub_domain_var_list.append(var_list[i][lat_idx[0]:lat_idx[1]+1,lon_idx[0]:lon_idx[1]+1])
        if sub_domain_lonlat:
            return(sub_domain_var_list,local_lon,local_lat)
        else:
            return(sub_domain_var_list)


    def sub_domain_extract_mimic_tpw2(self,var_list,lon_range=[],lat_range=[],sub_domain_lonlat=True):
        """
        this function is for fit-era5-lon rolled data array
        """
        import numpy as np
        var_list = self.check_list(var_list)
        if len(lon_range)<1:
           lon_range = self.lon_range
        if len(lat_range)<1:
           lat_range = self.lat_range
        #print(lon_range) 
        lon_idx,lat_idx,local_lon,local_lat = self.lonlat_index_025km(lon_range,lat_range,era5_lat=False)
        sub_domain_var_list = []
        
        for i in range(0, len(var_list)):
            sub_domain_var_list.append(var_list[i][lat_idx[0]:lat_idx[1]+1,lon_idx[0]:lon_idx[1]+1])
        if sub_domain_lonlat:   
            return(sub_domain_var_list,local_lon,local_lat)
        else:
            return(sub_domain_var_list)

####  hold, not for sure whether it would be apply
    def fit_era5_lon_roll(self, data_array, roll_array = -720, axis=1, roll_info=True):
        import numpy as np
        data_array = self.check_list(data_array)
        if roll_info:
            print('IMERG')
            print('roll = -1800; 2d_axis = ??')
            print('AIRS level 3')
            print('roll = ??; 2d_axis = ??')
            print('MIMIC TPW2')
            print('roll = -720; 2d_axis = 1')
        rolled_data_array = []
        for i in range(0,len(data_array)):
            rolled_data_array.append(np.roll(data_array[i],roll_array,axis=axis))
        return(rolled_data_array)
####
    def era5_lsm(self,load_latlon=False):
        from pathlib import Path
        import numpy as np
        import netCDF4 as nc
        current_dir = Path(__file__).parent
        invar_data_path = str(current_dir / 'era5_invariant_data')
        era5_landsea_file = [''+ invar_data_path+'/era5_landsea_mask_25.nc']
        landsea_re = nc.Dataset(era5_landsea_file[0], 'r',  format='NETCDF4_CLASSIC')
        lsm = np.array(landsea_re.variables['lsm'])[0,:,:]
        
        if load_latlon:
            lat = np.array(landsea_re.variables['latitude'])
            lon = np.array(landsea_re.variables['longitude'])
            landsea_re.close()
            return(lsm,lat,lon)
        else:
            landsea_re.close()
            return(lsm)

    def lonlat_index_025km(self, lon_range, lat_range, era5_lat = False, lonlat_only = False):
        import numpy as np 
###     lon index
        data_lon = np.arange(0,359751,250)/1000
        data_lon_b1 = (np.arange(0,359751,250)-125)/1000
        ### lon array start
        ta = lon_range[0]
        if ta >= 359.875 and ta <= 360:
            lon_index = int(0)
        else:
            lon_index = np.floor((ta- data_lon_b1[0])/0.25)
        lon_array_s = lon_index
        ### lon array end
        ta = lon_range[1]
        if ta >= 359.875 and ta <= 360:
            if lon_array_s == 0 and lon_range[0]>=359.875:
                lon_index = int(0)
            else:
                lon_index = 1439
        else:
            lon_index = np.floor((ta- data_lon_b1[0])/0.25)
        lon_array_e = lon_index 
###     lat index
        data_lat = np.arange(-90000,90001,250)/1000
        data_lat_b1 = (np.arange(-90000,90001,250)-125)/1000
        lat_ta = sorted(lat_range)
        if era5_lat:
            data_lat = np.arange(90000,-90001,-250)/1000
            data_lat_b1 = (np.arange(90000,-90001,-250)+125)/1000
            lat_ta = sorted(lat_range, reverse=True)
        ### lat array start
        ta = lat_ta[0]

        lat_index = np.floor(np.abs(ta - data_lat_b1[0])/0.25)
        lat_array_s = lat_index
        ### lat array end
        ta = lat_ta[1]

        lat_index = np.floor(np.abs(ta - data_lat_b1[0])/0.25)
        lat_array_e = lat_index

        lon_idx = [int(lon_array_s),int(lon_array_e)]
        lat_idx = [int(lat_array_s),int(lat_array_e)]
        local_lon=data_lon[lon_idx[0]:lon_idx[1]+1]
        local_lat=data_lat[lat_idx[0]:lat_idx[1]+1]
        #print(local_lon[0],local_lon[-1])
        #print(local_lat[0],local_lat[-1])
    
        if lonlat_only:
            return(local_lon,local_lat)
        else:
            return(lon_idx,lat_idx,local_lon,local_lat)

    def lonlat_index_01km(self, lon_range, lat_range, lonlat_only = False):
        import numpy as np
        ###     lon index
        data_lon = np.arange(5,35996,10)/100
        data_lon_b1 = (np.arange(5,35996,10)-5)/100
        ta = lon_range[0]
        if ta >= 359.95 and ta < 360:
            lon_index = int(3599)
        elif ta == 360:
            lon_index = int(0)
        else:
            lon_index = np.floor((ta- data_lon_b1[0])/0.1)
        lon_array_s = lon_index
        ###
        ta = lon_range[1]
        if ta >= 359.95 and ta < 360:
            lon_index = int(3599)
        elif ta == 360:
            if lon_array_s == 0 and lon_range[0]>=359.95:
                lon_index = int(0)
            else:
                lon_index = int(3599)
        else:
            lon_index = np.floor((ta- data_lon_b1[0])/0.1)
        lon_array_e = lon_index
        ###     lat index
        data_lat = np.arange(-8995,8996,10)/100
        data_lat_b1 = (np.arange(-8995,8996,10)-5)/100
        lat_ta = sorted(lat_range)
        ### lat array start
        ta = lat_ta[0]
        if ta == 90:
            lat_index = int(1799)
        else:
            lat_index = np.floor(np.abs(ta - data_lat_b1[0])/0.1)
        lat_array_s = lat_index
        ### lat array end
        ta = lat_ta[1]
        if ta == 90:
            lat_index = int(1799)
        else:
            lat_index = np.floor(np.abs(ta - data_lat_b1[0])/0.1)
        lat_array_e = lat_index
        ###
        lon_idx = [int(lon_array_s),int(lon_array_e)]
        lat_idx = [int(lat_array_s),int(lat_array_e)]
        local_lon=data_lon[lon_idx[0]:lon_idx[1]+1]
        local_lat=data_lat[lat_idx[0]:lat_idx[1]+1]
        if lonlat_only:
            return(local_lon,local_lat)
        else:
            return(lon_idx,lat_idx,local_lon,local_lat)


    def imerg_group_check(self,var_list):
        var_list = self.check_list(var_list)
        grid_var = ['time', 'lon', 'lat',
                    'time_bnds', 'lon_bnds', 'lat_bnds',
                    'precipitation', 'randomError',
                    'probabilityLiquidPrecipitation',
                    'precipitationQualityIndex']
        intermedi_var = ['MWprecipitation', 'MWprecipSource', 'MWprecipSource',
                         'IRprecipitation', 'IRinfluence', 'precipitationUncal']
        group = []
        for var in var_list:
            if var in grid_var:
                group.append('Grid')
            if var in intermedi_var:
                group.append('Intermediate')
        return(group)
  
    def gpm_to_025deg_grid(self,pr_list,
                           lat_range = None, lon_range = None,
                           target_grid = 'mimic_tpw2',
                           sub_domain = False):
        from pathlib import Path
        import pickle
        import numpy as np
        import math
        pr_list = self.check_list(pr_list)
        grid_name = target_grid.lower()
        #### This part's target_grid is not associated with the main function's target_grid
        #### This part's target_grid is for the ori satellite product's lat direction
        if sub_domain: 
            idx_lat,idx_lon,sub_lat,sub_lon = self.indices_025deg_grid(lat_range,lon_range,target_grid='era5',sub_latlon=sub_domain)
        else:
            idx_lat,idx_lon = self.indices_025deg_grid(lat_range,lon_range,target_grid='era5')
        ####
        current_dir = Path(__file__).parent
        regrid_path = str(current_dir / 'regrid_tools')
        ## preparation
        with open(''+regrid_path+'/gpm2era_lat_start.pkl', 'rb') as f:
            gpm2era_lat_s = pickle.load(f)
        with open(''+regrid_path+'/gpm2era_lat_len.pkl', 'rb') as f:
            gpm2era_lat_e = pickle.load(f)
        with open(''+regrid_path+'/gpm2era_lon_start.pkl', 'rb') as f:
            gpm2era_lon_s = pickle.load(f)
        with open(''+regrid_path+'/gpm2era_lon_len.pkl', 'rb') as f:
            gpm2era_lon_e = pickle.load(f)
        ref_gpm_lat = np.arange(-8995,8996,10)/100
        lat_weight = np.zeros((1800,3600))
        for de in range(0,1800):
            ttt = math.cos(ref_gpm_lat[de]*math.pi/180)
            lat_weight[de,:] = ttt
        ## regrid process
        era5_pr_list = []
        for f_len in range(0,len(pr_list)):
            single_pr = pr_list[f_len]
            era5_pr = np.zeros((721,1440))
            for g in range(idx_lat[0],idx_lat[1]+1): # 721
                for k in range(idx_lon[0],idx_lon[1]+1): #1440
                #print(era_lat[g],era_lon[k])
                #print(gpm_lat[0][int(gpm2era_lat_s[g]):int(gpm2era_lat_s[g]+gpm2era_lat_e[g])])
                #print(gpm_lon[0][int(gpm2era_lon_s[k]):int(gpm2era_lon_s[k]+gpm2era_lon_e[k])])
                    if k == 0:
                        region_pr = np.zeros((int(gpm2era_lat_e[g]),int(gpm2era_lon_e[k])))
                        region_latw = np.zeros((int(gpm2era_lat_e[g]),int(gpm2era_lon_e[k])))
                        for lon0 in range(0,int(gpm2era_lon_e[k])):
                            region_pr[:,lon0] = single_pr[int(gpm2era_lat_s[g]):int(gpm2era_lat_s[g]+gpm2era_lat_e[g]),(lon0-2)]
                            region_latw[:,lon0] = lat_weight[int(gpm2era_lat_s[g]):int(gpm2era_lat_s[g]+gpm2era_lat_e[g]),(lon0-2)]
                    else:
                        region_pr = single_pr[int(gpm2era_lat_s[g]):int(gpm2era_lat_s[g]+gpm2era_lat_e[g]),int(gpm2era_lon_s[k]):int(gpm2era_lon_s[k]+gpm2era_lon_e[k])]
                        region_latw = lat_weight[int(gpm2era_lat_s[g]):int(gpm2era_lat_s[g]+gpm2era_lat_e[g]),int(gpm2era_lon_s[k]):int(gpm2era_lon_s[k]+gpm2era_lon_e[k])]
                    if int(gpm2era_lat_e[g]) == 3:
                        weight_lat = [3/4,1,3/4]
                    else:
                        weight_lat = [1/4,1,1,1/4]
                    if g == 0:
                        weight_lat = [1/4,1]
                    if g == 720:
                        weight_lat = [1,1/4]
                    if int(gpm2era_lon_e[k]) == 3:
                        weight_lon = [3/4,1,3/4]
                    else:
                        weight_lon = [1/4,1,1,1/4]
                    for lonn in range(0,int(gpm2era_lon_e[k])):
                        region_latw[:,lonn] = region_latw[:,lonn]*weight_lat
                    for latt in range(0,int(gpm2era_lat_e[g])):
                        region_latw[latt,:] = region_latw[latt,:]*weight_lon
                    f_lat_weight = np.where(~np.isnan(region_pr),region_latw ,np.nan)
                    era5_pr[g,k] = np.nansum(region_pr*f_lat_weight)/(np.nansum(f_lat_weight))
            if sub_domain:
               era5_pr = era5_pr[idx_lat[0]:idx_lat[1]+1,idx_lon[0]:idx_lon[1]+1]
            if grid_name == 'mimic_tpw2':
                era5_pr_list.append(era5_pr[::-1])
            if grid_name == 'era5':
                era5_pr_list.append(era5_pr)

        if sub_domain:
            return(era5_pr_list,sub_lat,sub_lon)
        else:
            return(era5_pr_list)

    def oisst_to_025deg_grid(self,sst_list,
                             lat_range = None, lon_range = None,
                             target_grid = 'mimic_tpw2',
                             sub_domain = False):
        from pathlib import Path
        import pickle
        import numpy as np
        import math
        sst_list = self.check_list(sst_list)
        grid_name = target_grid.lower()
        #### This part's target_grid is not associated with the main function's target_grid
        #### This part's target_grid is for the ori satellite product's lat direction
        if sub_domain:
            idx_lat,idx_lon,sub_lat,sub_lon = self.indices_025deg_grid(lat_range,lon_range,target_grid='mimic_tpw2',sub_latlon=sub_domain)
        else:
            idx_lat,idx_lon = self.indices_025deg_grid(lat_range,lon_range,target_grid='mimic_tpw2')
        ####
        grid_name = target_grid.lower()
        sst_list = self.check_list(sst_list)
        current_dir = Path(__file__).parent
        regrid_path = str(current_dir / 'regrid_tools')
        ## preparation
        with open(''+regrid_path+'/oisst_lat.pkl', 'rb') as f:
            sst_lat = pickle.load(f)

        lat_weight = np.zeros((720,1441))
        for de in range(0,720):
            ttt = math.cos(sst_lat[de]*math.pi/180)
            lat_weight[de,:] = ttt
        ## regrid process
        era5_sst_list = []
        for f_len in range(0,len(sst_list)):
            single_sst = np.zeros((720,1441))
            single_sst[:,0] = sst_list[f_len][:,1439]
            single_sst[:,1:1441] = sst_list[f_len][:,:]
            era5_sst = np.zeros((721,1440))
            for g in range(idx_lat[0],idx_lat[1]+1): # 721
                for k in range(idx_lon[0],idx_lon[1]+1): #1440
                    if g == 0:
                        region_sst = np.zeros((1,2))
                        region_latw = np.zeros((1,2))
                        region_sst[:,:] = single_sst[0,k:k+2]
                        region_latw[:,:] = lat_weight[0,k:k+2]
                    elif g == 720:
                        region_sst = np.zeros((1,2))
                        region_latw = np.zeros((1,2))
                        region_sst[:,:] = single_sst[719,k:k+2]
                        region_latw[:,:] = lat_weight[719,k:k+2]
                    else:
                        region_sst = single_sst[g-1:g+1,k:k+2]
                        region_latw = lat_weight[g-1:g+1,k:k+2]
                    weight_lat = [1/2,1/2]
                    if g == 0:
                        weight_lat = [1]
                    if g == 720:
                        weight_lat = [1]
                    weight_lon = [1/2,1/2]
                    #print(k)
                    #print(region_latw.shape)
                    for lonn in range(0,region_sst.shape[1]):
                       
                        region_latw[:,lonn] = region_latw[:,lonn]*weight_lat
                    for latt in range(0,region_sst.shape[0]):
                        region_latw[latt,:] = region_latw[latt,:]*weight_lon
                    f_lat_weight = np.where(~np.isnan(region_sst),region_latw ,np.nan)
                    era5_sst[g,k] = np.nansum(region_sst*f_lat_weight)/(np.nansum(f_lat_weight))
            if sub_domain:
                era5_sst = era5_sst[idx_lat[0]:idx_lat[1]+1,idx_lon[0]:idx_lon[1]+1]
            if grid_name == 'mimic_tpw2':
                era5_sst_list.append(era5_sst)
            if grid_name == 'era5':
                era5_sst_list.append(era5_sst[::-1])

        if sub_domain:
            return(era5_sst_list,sub_lat,sub_lon)
        else:
            return(era5_sst_list)

    def hima_ir_to_025deg_grid(self,band_data_list,hima_lat,hima_lon,
                               lat_range = None, lon_range = None,
                               target_grid = 'mimic_tpw2',
                               sub_domain = False):
        from pathlib import Path
        import pickle
        import numpy as np
        import math
        ## preparation
        if sub_domain:
            idx_lat,idx_lon,sub_lat,sub_lon = self.indices_025deg_grid(lat_range,lon_range,target_grid='mimic_tpw2',sub_latlon=sub_domain)
        else:
            idx_lat,idx_lon = self.indices_025deg_grid(lat_range,lon_range,target_grid='mimic_tpw2')
        grid_name = target_grid.lower()
        band_data_list = self.check_list(band_data_list)

        current_dir = Path(__file__).parent
        regrid_path = str(current_dir / 'regrid_tools')
        ## preparation
        with open(''+regrid_path+'/mimic_lat.pkl', 'rb') as f:
            mimic_lat = pickle.load(f)
        with open(''+regrid_path+'/mimic_lon.pkl', 'rb') as f:
            mimic_lon = pickle.load(f)
        with open(''+regrid_path+'/hima_ir_ERA5grid_weight_lat.pkl', 'rb') as f:
            grid_weight_lat = pickle.load(f)
        with open(''+regrid_path+'/hima_ir_ERA5grid_weight_lon.pkl', 'rb') as f:
            grid_weight_lon = pickle.load(f)


        ### lat weight
        d_shape = band_data_list[0].shape
        lat_weight = np.zeros((d_shape[0],d_shape[1]))
        #print(lat[0],lat[-1])
        for de in range(0,d_shape[0]):
            ttt = math.cos(hima_lat[de]*math.pi/180)
            lat_weight[de,:] = ttt
###
### regrid process
        era5_hima_list = []
        for f_len in range(0,len(band_data_list)):
            single_hima = band_data_list[f_len]
            era5_hima = np.zeros((721,1440))  
### 
            hima_lat_up = hima_lat+0.01
            hima_lat_bo = hima_lat-0.01
            hima_lon_up = hima_lon+0.01
            hima_lon_bo = hima_lon-0.01
            for g in range(idx_lat[0],idx_lat[1]+1):#(260,461):
                lat_up = mimic_lat[g]+0.125
                lat_bo = mimic_lat[g]-0.125
                #print(lat[g],lat_bo,lat_up)
                lat_up_mask_1 = (hima_lat_up>lat_up)
                lat_up_mask_2 = (lat_up>hima_lat_bo)
                lat_bo_mask_1 = (hima_lat_up>lat_bo)
                lat_bo_mask_2 = (lat_bo>hima_lat_bo)
            #print(lat_up)
            #print(lat_bo)
                indices_lat_up = np.where(lat_up_mask_1 & lat_up_mask_2)[0]
                indices_lat_bo = np.where(lat_bo_mask_1 & lat_bo_mask_2)[0]
                weight_lat = grid_weight_lat[g]
                if len(indices_lat_bo) == 0 and len(indices_lat_up) != 0:
                    indices_lat_bo = [0]
                    weight_lat[0] = 1
                if len(indices_lat_up) == 0 and len(indices_lat_bo) != 0:
                    indices_lat_up = [d_shape[0]-1]
                    weight_lat[1] = 1
                for k in range(idx_lon[0],idx_lon[1]+1):#(460,681)
                    lon_up = mimic_lon[k]+0.125
                    lon_bo = mimic_lon[k]-0.125
                        #print(lon[k],lon_bo,lon_up)
                    lon_up_mask_1 = (hima_lon_up>lon_up)
                    lon_up_mask_2 = (lon_up>hima_lon_bo)
                    lon_bo_mask_1 = (hima_lon_up>lon_bo)
                    lon_bo_mask_2 = (lon_bo>hima_lon_bo)
                    indices_lon_up = np.where(lon_up_mask_1 & lon_up_mask_2)[0]
                    indices_lon_bo = np.where(lon_bo_mask_1 & lon_bo_mask_2)[0]
                    weight_lon = grid_weight_lon[k]
                    if len(indices_lon_bo) == 0 and len(indices_lon_up) != 0:
                        indices_lon_bo = [0]
                        weight_lon[0] = 1
                    if len(indices_lon_up) == 0 and len(indices_lon_bo) != 0:
                        indices_lon_up = [d_shape[1]-1]
                        weight_lon[1] = 1 
                        #print(indices_lon_up,hima_lon[indices_lon_up])
                        #print(indices_lon_bo,hima_lon[indices_lon_bo])
                ###
                    region_tb = single_hima[:,indices_lon_bo[0]:indices_lon_up[0]+1]
                    region_tb = region_tb[indices_lat_bo[0]:indices_lat_up[0]+1,:]
                    region_latw = lat_weight[:,indices_lon_bo[0]:indices_lon_up[0]+1]
                    region_latw = region_latw[indices_lat_bo[0]:indices_lat_up[0]+1,:]
                ###
                    region_latw[0,:] = region_latw[0,:]*weight_lat[0]
                    region_latw[-1,:] = region_latw[-1,:]*weight_lat[-1]
                    region_latw[:,0] = region_latw[:,0]*weight_lon[0]
                    region_latw[:,-1] = region_latw[:,-1]*weight_lon[-1]
                    f_lat_weight = np.where(~np.isnan(region_tb),region_latw ,np.nan)
                    era5_hima[g,k] = np.nansum(region_tb*f_lat_weight)/(np.nansum(f_lat_weight))
                ###
            if sub_domain:
                era5_hima = era5_hima[idx_lat[0]:idx_lat[1]+1,idx_lon[0]:idx_lon[1]+1]
            if grid_name == 'mimic_tpw2':
                era5_hima_list.append(era5_hima)
            if grid_name == 'era5':
                era5_hima_list.append(era5_hima[::-1])
###
        if sub_domain:
            return(era5_hima_list,sub_lat,sub_lon)
        else:
            return(era5_hima_list)


    def indices_025deg_grid(self, lat_range = None, lon_range = None,
                            target_grid = 'mimic_tpw2',
                            sub_latlon = False):
        import numpy as np
        ### preparation
        if lat_range is None:
            lat_range = self.lat_range
        if lon_range is None:
            lon_range = self.lon_range
        grid_name = target_grid.lower()
        #print(grid_name)
        mimic_lat = np.arange(-90,90.1,0.25).astype('float32')
        mimic_lon = np.arange(0,360,0.25).astype('float32')
        lat_bo = lat_range[0]
        lat_up = lat_range[1]
        lon_bo = lon_range[0]
        lon_up = lon_range[1]
        if grid_name == 'mimic_tpw2':
            mimic_lat = mimic_lat
        if grid_name == 'era5':
            mimic_lat = mimic_lat[::-1]
        ### lat indices
        mimic_lat_up = mimic_lat+0.125
        mimic_lat_bo = mimic_lat-0.125
        lat_up_mask_1 = (mimic_lat_up>=lat_up)
        lat_up_mask_2 = (lat_up>mimic_lat_bo)
        lat_bo_mask_1 = (mimic_lat_up>=lat_bo)
        lat_bo_mask_2 = (lat_bo>mimic_lat_bo)
        indices_lat_up = np.where(lat_up_mask_1 & lat_up_mask_2)[0]
        indices_lat_bo = np.where(lat_bo_mask_1 & lat_bo_mask_2)[0]
        ### lon indices
        mimic_lon_up = mimic_lon+0.125
        mimic_lon_bo = mimic_lon-0.125
        lon_up_mask_1 = (mimic_lon_up>=lon_up)
        lon_up_mask_2 = (lon_up>mimic_lon_bo)
        lon_bo_mask_1 = (mimic_lon_up>=lon_bo)
        lon_bo_mask_2 = (lon_bo>mimic_lon_bo)
        indices_lon_up = np.where(lon_up_mask_1 & lon_up_mask_2)[0]
        indices_lon_bo = np.where(lon_bo_mask_1 & lon_bo_mask_2)[0]
        if lon_up > 359.875: 
            indices_lon_up = [1439]
        if lon_bo > 359.875:
            indices_lon_bo = [1439]
        indices_lat = sorted([indices_lat_bo[0],indices_lat_up[0]])
        indices_lon = sorted([indices_lon_bo[0],indices_lon_up[0]])
        if sub_latlon:
            sub_lat = mimic_lat[indices_lat[0]:indices_lat[1]+1]
            sub_lon = mimic_lon[indices_lon[0]:indices_lon[1]+1]
            return(indices_lat,indices_lon,sub_lat,sub_lon)
        else:
            return(indices_lat,indices_lon)            
 
    """
    Object Identify
    """ 
    def obejct_identify(self,examining_array,threshold):
        import numpy as np   
        examining_array = np.array(examining_array) 
### output array shape
        ori_arraysize = examining_array.shape
### extend 1D or 2D array into 3D 
        if examining_array.ndim == 1:
            examining_array = np.expand_dims(examining_array, axis=0)
            examining_array = np.expand_dims(examining_array, axis=0)
        elif examining_array.ndim == 2:
            examining_array = np.expand_dims(examining_array, axis=0)      
### object detection
        arraysize = examining_array.shape
        size_mask = np.zeros(arraysize)
        size_num = np.zeros(arraysize)
        obj_num = 1
        for i in range(0, arraysize[0]):
            for j in range(0, arraysize[1]):
                for k in range(0, arraysize[2]):
                    if size_mask[i,j,k]<1 and examining_array[i,j,k] >= threshold:
                        vertical_su, lat_su, lon_su, grid_su = \
                        self.surround_array(i,j,k,arraysize)
                        checked_grid = [[i,j,k]]
                        size_mask[i,j,k] = 1
                        cal_size = 1
                        checked_grid,size_mask,size_num = \
                        self.six_way_connect(examining_array,threshold,
                                             checked_grid,size_mask,size_num,obj_num,
                                             vertical_su,lat_su,lon_su,grid_su,
                                             arraysize,cal_size)
                        obj_num = obj_num+1
### output ori-array size
        if len(ori_arraysize) == 1:
            size_mask = np.squeeze(size_mask, axis=0)
            size_mask = np.squeeze(size_mask, axis=0)
            size_num = np.squeeze(size_num, axis=0)
            size_num = np.squeeze(size_num, axis=0)
        elif len(ori_arraysize) == 2:
            size_mask = np.squeeze(size_mask, axis=0)
            size_num = np.squeeze(size_num, axis=0)
        return(size_num, size_mask)

    def surround_array(self,vertical, lat, lon, array_s):
        vertical_su = []
        lat_su = []
        lon_su = []
        grid_su = 0
        if vertical != 0:
            vertical_su.append(vertical-1)
            lon_su.append(lon)
            lat_su.append(lat)
            grid_su = grid_su + 1 
        if vertical != array_s[0]-1:
            vertical_su.append(vertical+1)
            lon_su.append(lon)
            lat_su.append(lat)
            grid_su = grid_su + 1 
        if lat != 0:
            vertical_su.append(vertical)
            lat_su.append(lat-1)
            lon_su.append(lon)
            grid_su = grid_su + 1 
        if lat != array_s[1]-1:
            vertical_su.append(vertical)
            lat_su.append(lat+1)
            lon_su.append(lon)
            grid_su = grid_su + 1 
        if lon != 0:
            vertical_su.append(vertical)
            lon_su.append(lon-1)
            lat_su.append(lat)
            grid_su = grid_su + 1 
        if lon != array_s[2]-1:
            vertical_su.append(vertical)
            lon_su.append(lon+1)
            lat_su.append(lat)
            grid_su = grid_su + 1 
        return(vertical_su,lat_su,lon_su,grid_su)

    def six_way_connect(self,examining_array,threshold,
                        checked_grid,size_mask,size_num,obj_num,
                        vertical_su,lat_su,lon_su,grid_su,arraysize,
                        cal_size):
        waiting_grid = []
### check first object pixel's surround pixel
        for grid in range(0,grid_su):
            test_grid = examining_array[vertical_su[grid],lat_su[grid],lon_su[grid]]
            mask = size_mask[vertical_su[grid],lat_su[grid],lon_su[grid]]
            if test_grid >= threshold and mask < 1:
                checked_grid.extend([[vertical_su[grid],lat_su[grid],lon_su[grid]]])
                waiting_grid.extend([[vertical_su[grid],lat_su[grid],lon_su[grid]]])
                cal_size = cal_size + 1
                size_mask[vertical_su[grid],lat_su[grid],lon_su[grid]]=1
### check connected pixel
        for wait in waiting_grid:
            vertical_su1,lat_su1,lon_su1,grid_su1 = \
            self.surround_array(wait[0],wait[1],wait[2],arraysize)
            for grid1 in range(0,grid_su1):
                test_grid = examining_array[vertical_su1[grid1],lat_su1[grid1],lon_su1[grid1]]
                mask = size_mask[vertical_su1[grid1],lat_su1[grid1],lon_su1[grid1]]
                if test_grid >= threshold and mask < 1:
                    checked_grid.extend([[vertical_su1[grid1],lat_su1[grid1],lon_su1[grid1]]])
                    waiting_grid.extend([[vertical_su1[grid1],lat_su1[grid1],lon_su1[grid1]]])
                    cal_size = cal_size + 1
                    size_mask[vertical_su1[grid1],lat_su1[grid1],lon_su1[grid1]] = 1
    #print('adj',lat_cosine[lat_su1[grid1]])
    #print('final',np.array(checked_grid).shape)
    #print('size',area[0])
    #print('adj_size',adj_size_mask)
        for che in checked_grid:
            size_mask[che[0],che[1],che[2]] = cal_size
            size_num[che[0],che[1],che[2]] = obj_num
        return(checked_grid, size_mask, size_num)
#####

