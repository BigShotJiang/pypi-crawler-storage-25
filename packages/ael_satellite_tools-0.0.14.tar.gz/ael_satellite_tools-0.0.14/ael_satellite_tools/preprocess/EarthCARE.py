"""
EarthCARE pre-process module

Two offical resources for downloading EarthCARE data:
     1. ESA
     2. JAXA

This module use the second way

Please use following link to Register: https://gportal.jaxa.jp/gpr/user/regist1?lang=en

The web account & password would also be SFTP

"""

from ..satellite_general import Preparation
from ..satellite_plotting import Plotting_tools


class EarthCARE(Preparation,Plotting_tools):
    def __init__(self,work_path=None,lat_range=[-10,50],lon_range=[90,180],
                 time_period=['200606'],data_path=['/data/cloud2025/temporary_data'],
                 sftp_username = [],sftp_password = []):
        from pathlib import Path
        super().__init__(work_path,lat_range,lon_range,time_period)
        if self.work_path == None or self.work_path == []:
            self.work_path = Path().cwd()
        self.data_path = data_path
        self.sftp_username = sftp_username
        self.sftp_password = sftp_password
        if len(sftp_username) < 1 or len(sftp_password) < 1:
            print('Enter your sftp account or password for downloading data.')
            print("If you don't have an sftp account yet, you may register via the following link: ")
            print('https://gportal.jaxa.jp/gpr/user/regist1?lang=en')

    def information(self,product_list=False):
        print('EarthCARE')
        print('onboard sensor: Cloud Profiling Radar (CPR)')
        print('                Atmospheric Lidar (ATLID)')
        print('                Multi-Spectral Imager (MSI)')
        print('                Broad-band Radiometer (BBR)')
        print('Current module foucs on atmosphere profiling data')
        print('CPR, ATLID, 2B-CPR-ATLID are involed')
        if product_list:
            print('---------------------------------------------------')
        self.product_list(print_list=product_list)
        print('---------------------------------------------------')
        print('EarthCARE official website:')
        print('    [JAXA] https://www.eorc.jaxa.jp/EARTHCARE/index.html')
        print('    [ESA]  https://earth.esa.int/eogateway/missions/earthcare')
        print('---------------------------------------------------')
        print('JAXA resource:')
        print('Data download register link: https://gportal.jaxa.jp/gpr/user/regist1?lang=en')
        print('Quick Look:    https://www.eorc.jaxa.jp/EARTHCARE/Quicklook/index.html')
        print('Orbit Tools:   https://www.eorc.jaxa.jp/EARTHCARE/data/orbit_display_tool_e.html')

    def product_list(self,print_list=True):
        if print_list:
            print('CPR & ATLID product')
            print('ESA Product')
            print('[CPR]         2A.CPR_CD;  2A.CPR_CLD; 2A.CPR_FMR;\
                 \n              2A.CPR_TC')
            print('[ATLID]       2A.ATL_AER; 2A.ATL_ALD; 2A.ATL_CTH;\
                 \n              2A.ATL_EBD; 2A.ATL_FM;  2A.ATL_ICE;\
                 \n              2A.ATL_TC')
            print('[CPR + ATLID] 2B.AC_TC')
            print('---------------------------------------------------')
            print('JAXA Product') 
            print('[CPR]         2A.CPR_ECO; 2A.CPR_CLP')
            print('[ATLID]       2A.ATL_CLA')
            print('[CPR + ATLID] 2B.AC_CLP')
            print('---------------------------------------------------')
            print('ESA Product descriptions:') 
            print('https://earthcarehandbook.earth.esa.int/catalogue/index')
            print('JAXA Product descriptions:')
            print('https://www.eorc.jaxa.jp/EARTHCARE/data/L2prd_list_std_e.html')
      
    def generate_list(self,product_name,time_period,lat_region=[],period_output=False,data_ver='latest'):
        import glob as glob
###
        local_path = self.data_path
        if len(lat_region) < 1:
            lat_region = self.lat_range
### function generate
        year_list, date_day_list, start_end_time_list = self.convert_input_period(time_period,julian=False)
        search_period = self.generate_date_period(year_list, date_day_list, start_end_time_list)
        product_name = self.check_list(product_name)
        lat_region = self.check_list(lat_region)
        sensor_type,product_type = self.product_name_split(product_name)
        product_cat = self.product_category(sensor_type)
        range_id = self.frame_ID(lat_region)
###
        full_path_file_list = []
        for p_num in range(0,len(product_name)):
            for h5_time in search_period:
                local_path = f'{self.data_path}/{product_name[p_num]}/{h5_time[0:4]}/{h5_time[4:6]}/{h5_time[6:8]}/'
                if len(range_id) == 8:
                    target_files = [f'*{sensor_type[p_num]}*{product_type[p_num]}*_{h5_time}*_{h5_time[0:2]}*_*_*.h5']
                else:
                    target_files = []
### ABCDEFGH base on lat lon range
                    for frame in range_id:
                         #print(frame)
                        target_files.append(f'*{sensor_type[p_num]}*{product_type[p_num]}*_{h5_time}*_{h5_time[0:2]}*_*{frame}_*.h5')
                #print(target_files)
                for ta_file in target_files:
                    glob_files = f'{local_path}{ta_file}'
                    #print(glob_files)
                    search_files = sorted(glob.glob(glob_files))
                    full_path_file_list.extend(search_files)
        if len(full_path_file_list) < 1:
            print('No .h5 file detected!')
        else:
            if data_ver == 'latest':
                #print('Latest version')
                full_path_file_list = self.get_latest_version(full_path_file_list,
                                                              data_ver='latest')
            elif data_ver == 'oldest':
                print('Give oldest version')
                full_path_file_list = self.get_latest_version(full_path_file_list,
                                                              data_ver='oldest')
            else:
                print('Give full data files')
        if period_output:
            return(full_path_file_list,search_period)
        else:
            return(full_path_file_list)

    def cross_product_match(self,*lists):
        granule_total = []
        for idx, file_list in enumerate(lists):
            file_list = self.check_list(file_list)
            granule_product = []
            for file_name in file_list:
                split_name = file_name.split('/')[-1]
                granule_product.append(split_name.split('_')[-2])
            granule_total.append(granule_product)
            if idx == 1:
                match = sorted(list(set(granule_total[idx-1]) & set(granule_total[idx])))
            elif idx > 1:
                match = sorted(list(set(match) & set(granule_total[idx])))

        match_file_list_total = []
        for idx, file_list in enumerate(lists):
            file_list = self.check_list(file_list)
            match_file_list_product = []
            for i in range(0,len(match)):
                granule_string = '_' + match[i] + '_'
                target_file = list(filter(lambda s: granule_string  in s, file_list))
                match_file_list_product.append(target_file[0])
            match_file_list_total.append(match_file_list_product)
        return(match_file_list_total)

    def sub_domain_check(self,full_path_file_list,extracted_lon_range=[],extracted_lat_range=[],mask_output=False):
        import numpy as np
        full_path_file_list = self.check_list(full_path_file_list)
        region_mask_list = []
        era5_lon_list = []
        era5_lat_list = []
        sub_domain_file_list = []
        if len(full_path_file_list) > 0:
            var_name = ['longitude','latitude','quality_status']
            lon_list = self.read_ori_data(full_path_file_list,var_name[0])
            lat_list = self.read_ori_data(full_path_file_list,var_name[1])
            #qua_list = self.read_ori_data(full_path_file_list,var_name[2])
            print('Check EarthCARE track pass the traget domain')

            for i in range(0,len(lon_list)):
                #data_lon = np.expand_dims(lon_list[i],axis=1)
                #data_lat = np.expand_dims(lat_list[i],axis=1)
                #print(data_lon.shape)
                #print(data_lat.shape)
                region_mask,era5_lon,era5_lat = self.regional_filter(lon_list[i],lat_list[i],None,extracted_lon_range,extracted_lat_range)
                if np.sum(region_mask)>0:
                    region_mask_list.append(region_mask)
                    era5_lon_list.append(era5_lon)
                    era5_lat_list.append(era5_lat)
                    sub_domain_file_list.append(full_path_file_list[i])
            if mask_output:
                return(sub_domain_file_list,region_mask_list)
            else:
                return(sub_domain_file_list)
        else:
            print('No .h5 file input, please revise your time period or download data')
            if mask_output:
                return(sub_domain_file_list,region_mask_list)
            else:
                return(sub_domain_file_list)

    def plot_track(self,file_list,
                   coast_line_color='olive',lonlat_step=5,font_size=24,
                   loc='left',pad=40, figure_title='EarthCARE Track Demo',
                   prefix='earthcare_track_demo',
                   figure_name=[],figure_path=[], dpi=300,
                   ### plot track unit
                   track_color_method=None, track_shadow=True, 
                   track_dir=True, track_dir_pos='edge',
                   arrow_len_scale = 0.065,
                   id_label=True,granule_label=False,date_label=True,
                   ### timezone unit
                   utc_label=True,night_time_label=True,timezone_gradient=True, 
                   ### save fig
                   save_fig=True):
        file_list = self.check_list(file_list)
### call outer function
        sub_domain_file_list,region_mask_list \
        = self.sub_domain_check(file_list,mask_output=True)
###
        plot_lon,plot_lat, hdf_date,hdf_id,hdf_granule,\
        region_start_time,region_end_time \
         = self.read_geometric_info(sub_domain_file_list,
                                    region_mask_list,lonlat_info=True)
### plotting unit
### lon lat info
        lon_s,lon_e,lat_s,lat_e,lon_range,lat_range, \
        lon_step,lat_step = self.plot_lonlat_info(lonlat_step)
### basemap
        ax1,m,fig = self.plot_basemap_unit(lon_s,lon_e,lat_s,lat_e,
                                            lon_range,lat_range,
                                            lon_step,lat_step,
                                            coast_line_color=coast_line_color,
                                            font_size=font_size)
### time zone
        self.plot_timezone_unit(ax1,lon_s,lon_e,lat_s,lat_e,lat_range,
                                utc_label=utc_label,
                                night_time_label=night_time_label,
                                timezone_gradient=timezone_gradient)
### plot track on map
        self.plot_track_unit(ax1,plot_lon,plot_lat,
                             hdf_date,hdf_id,hdf_granule,
                             lon_range,lat_range,
                             font_size=font_size, 
                             track_color_method=track_color_method,
                             track_shadow=track_shadow, track_dir=track_dir,
                             track_dir_pos=track_dir_pos, arrow_len_scale = arrow_len_scale,
                             id_label=id_label,granule_label=granule_label,
                             date_label=date_label) 
### plot title
        if hdf_date[0] == hdf_date[-1]:
            title_date = f'{hdf_date[0].replace('-','/')}'
        else:
            title_date =  f'{hdf_date[0].replace('-','/')} ~ {hdf_date[-1].replace('-','/')}'
        title = f'{figure_title}\n{title_date}'
        self.plot_title_unit(title,loc='left',pad=40,font_size=24)
### save fig
        figure_main = ''+hdf_date[0].replace('-','') +'_'+hdf_date[-1].replace('-','')+''
        self.save_fig_unit(figure_main,figure_name=figure_name,
                           prefix=prefix,
                           dpi=dpi, figure_path=figure_path,save_fig=save_fig)

        if len(file_list) > len(sub_domain_file_list):
            return(sub_domain_file_list)


    def plot_profile(self,masked_ref=[],shading='contourf',
###                  axis
                     x_axis=[],x_step=5,extracted_hei=[],height_range=[0,20],height_step=5,
                     hei_size=5,fig_id=[],axis=[],
###                  color bar
                     color_map='jet',value_range=[-30, 16],
                     bar_pos = 3,bar_ticks=[],bar_label='colorbar var',
###                  title & label
                     hdf_date=[],hdf_granule=[],
                     region_start_time=[],region_end_time=[],
                     x_label='Latitude',y_label='[km]',
                     figure_title='EarthCARE Profile',
###                  plotting switch
                     colorbar_plot=True,
                     start_plot=True,finish_plot=True,time_dir=True,
###                  save fig
                     prefix='earthcare_profile',figure_name=[],
                     figure_path='earthcare_fig',dpi=300,save_fig=True):
        import matplotlib.pyplot as plt
        import matplotlib.colors as mcolors
        import numpy as np
        masked_ref = self.check_list(masked_ref)
        extracted_hei = self.check_list(extracted_hei)
        x_axis = self.check_list(x_axis)
        hdf_date = self.check_list(hdf_date)
        hdf_granule = self.check_list(hdf_granule)
        region_start_time = self.check_list(region_start_time)
        region_end_time = self.check_list(region_end_time)
### profile x axis setting
        x_s = np.around(x_axis[0][0],decimals=1)
        x_e = np.around(x_axis[0][-1],decimals=1)
        x_range = sorted([x_s,x_e])
        x_interval = np.floor((x_range[1] - x_range[0])/(x_step-1))
        if x_interval <1:
           x_interval = 1
        v_shape = extracted_hei[0].shape
### x axis array
### profile y axis setting
### y axis array
        if len(extracted_hei[0].shape) > 1:
            masked_hei = np.ma.masked_equal(extracted_hei[0], -9999)
            #plot_y = np.nanmean(masked_hei,axis=0)/1000 # reference_height
            plot_y = masked_hei/1000
            plot_x = np.tile(x_axis[0].reshape(x_axis[0].shape[0],1),(1,v_shape[1]))
        else:
            masked_hei = np.ma.masked_equal(extracted_hei[0], -9999)
            single_hei = np.zeros((1,v_shape[0]))

            single_hei[0,:] = masked_hei
            #plot_y = np.nanmean(single_hei,axis=0)/1000 # reference_height
            plot_y = single_hei/1000
            plot_x = x_axis[0]
###     
        if start_plot: 
            fig_id,axis = plt.subplots(1,1,figsize=(20,hei_size),tight_layout=True)
        color_extend_ref = 'both'
        prof = self.plot_profile_unit(masked_ref[0],plot_x,plot_y,
                                      shading,color_map,
                                      value_range=[value_range[0],value_range[1]],extend=color_extend_ref,zorder=2)
        plt.axis([x_range[0], x_range[1],
                 height_range[0], height_range[1]])
### color bar unit
        if colorbar_plot:
            bar_x = 0.18*bar_pos 
            cbar_ax = fig_id.add_axes([0.28+bar_x, 1-0.18*(5/hei_size), 0.15, 0.03*(5/hei_size)])
            if len(bar_ticks) < 1:
                bar_intvl = np.floor((value_range[1] - value_range[0])/(5-1))
                bar_ticks = np.arange(value_range[0],value_range[1],bar_intvl)            
            c_ref = plt.colorbar(prof,ticks=bar_ticks,cax=cbar_ax,extend=color_extend_ref,
                                 orientation='horizontal', location='top')
            c_ref.ax.tick_params(labelsize=14)
            c_ref.set_label(label=bar_label, size=12, weight='bold')
### return to figure axis
        plt.sca(axis)
###
        if finish_plot:
### ticks and labels
            plt.xticks(np.arange(x_range[0],x_range[1]+1,x_interval),fontsize=24)
            hei_bot = height_range[0]
            if hei_bot < 0:
                hei_bot = 0
            hei_jump = int(np.floor((height_range[1] - hei_bot)/(height_step-1)))
            if hei_jump == 0:
                hei_jump = 1
            hei_range = list(np.arange(hei_bot,height_range[1]+1,hei_jump))
            hei_ticks = [1]
            hei_ticks.extend(hei_range[1:])
            plt.yticks(hei_ticks,fontsize=24)

            plt.axis([x_range[0],x_range[1],
                     height_range[0], height_range[1]])
            plt.xlabel(x_label,fontsize=24)
            plt.ylabel(y_label,fontsize=24)
            plt.grid(zorder=1)
### title unit
            title_date = ''+hdf_date[0].replace('-','/')
            s_hr = str(region_start_time[0])
            e_hr = str(region_end_time[0])
            if region_start_time[0]<10:
                s_hr = '0'+s_hr
            if region_end_time[0]<10:
                e_hr = '0'+e_hr
            s_mn = str(region_start_time[1])
            e_mn = str(region_end_time[1])
            if region_start_time[1]<10:
                s_mn = '0'+s_mn
            if region_end_time[1]<10:
                e_mn = '0'+e_mn
            if time_dir:
                s_time = ''+s_hr+':'+ s_mn +'UTC'
                e_time = ''+e_hr+':'+ e_mn +'UTC'
                title = ''+figure_title+'  '+title_date+'\nGranule: '+hdf_granule[0]+''
                #text_y = -0.2*(5/hei_size)-0.01*((5-hei_size)/5)
                text_y = -0.2*(5/hei_size)
                
                text_s_pos = x_range.index(x_s)
                text_e_pos = x_range.index(x_e)
                #print(text_s_pos,text_e_pos)
                if text_s_pos > text_e_pos:
                    ha_s = 'right'
                    ha_e = 'left'
                else:
                    ha_s = 'left'
                    ha_e = 'right'

                plt.text(text_s_pos, text_y, s_time, transform=axis.transAxes,
                         c='crimson',fontsize=20, fontweight='bold', ha=ha_s, va='center')
                plt.text(text_e_pos, text_y, e_time, transform=axis.transAxes,
                         c='crimson',fontsize=20, fontweight='bold', ha=ha_e, va='center')
                if text_s_pos > 0.5:
                    arrow_1 = 0.8
                    arrow_2 = 0.09
                    arrow_len = 0.11
                else:
                    arrow_1 = 0.91
                    arrow_2 = 0.2
                    arrow_len = -0.11
                plt.annotate('',xy =(arrow_1,text_y), xytext=(arrow_1+arrow_len,text_y),
                             textcoords='axes fraction',xycoords='axes fraction',
                             arrowprops=dict(color='crimson'),
                             ha='right', va='center')
                plt.annotate('',xy =(arrow_2,text_y), xytext=(arrow_2+arrow_len,text_y),
                             textcoords='axes fraction',xycoords='axes fraction',
                             arrowprops=dict(color='crimson'),
                             ha='left', va='center')
            else:
                s_time = ''+s_hr+':'+ s_mn +''
                e_time = ''+e_hr+':'+ e_mn +'UTC'
                title = ''+figure_title+' '+title_date+'\nGranule: '+hdf_granule[0]+'  Time: '+s_time+' ~ '+e_time+''
            self.plot_title_unit(title,loc='left',pad=12,font_size=24)
### save fig unit
            fig_s_time = ''+s_hr+''+ s_mn +''
            fig_e_time = ''+e_hr+''+ e_mn +''
            figure_main = ''+hdf_date[0].replace('-','') +'_'+fig_s_time+'_'+fig_e_time+'_'+hdf_granule[0]+''
            self.save_fig_unit(figure_main,figure_name=[],
                               prefix=prefix, dpi=dpi,
                               figure_path=figure_path,save_fig=save_fig)
            x_label_pos = axis.xaxis.label.get_position()
            #print(x_label_pos)

        if start_plot:
           return(fig_id, axis)

    def plot_landsea_base(self,combined_elev,combined_landsea,combined_height,
                          x_axis=[], x_step=5,  height_step=5, 
                          hei_size=5, fig_id=[], axis=[],
                          start_plot=True,finish_plot=False,
                          output_type='both',land=False):
        cominbed_elev = self.check_list(combined_elev)
        cominbed_landsea = self.check_list(combined_landsea)
        cominbed_height = self.check_list(combined_height)
        x_axis = self.check_list(x_axis)
        ####
        landsea_color = self.landsea_color()
        topo_mask = self.topo_landsea_array(combined_elev,combined_landsea,
                                            combined_height,output_type=output_type)
        uni_sea,land_topo,uni_height = self.flatten_landsea(topo_mask,
                                                            combined_height,
                                                            land=land)
        plot_height = self.plot_height_generate(combined_height)
        ####
        hei_size = 5
        fig, ax1 = self.plot_profile(uni_sea,'pcolormesh',
                                     x_axis,5,uni_height,[-0.5,20],5,
                                     hei_size,[],[],
                                     landsea_color,[0, 2],
                                     1,[0,1,2],'land sea mask',
                                     colorbar_plot=False,
                                     start_plot=start_plot,finish_plot=False)
###     color bar demo
        if finish_plot:
            colorbar = True
        else:
            colorbar = False
###     flatten land sea plot
        if output_type == 'land sea only' and land:
            plot_y = uni_height
        else:
            plot_y = plot_height
###
        self.plot_profile(land_topo,'pcolormesh',
                          x_axis,5,plot_y,[-0.5,20],5,
                          hei_size,fig,ax1,
                          landsea_color,[0, 2],3,[0,1,2]
                          ,'land sea mask',
                          hdf_date=['No date'],hdf_granule=['0'],
                          region_start_time=[[0,0]],region_end_time=[[0,0]],
                          x_label='Latitude',y_label='[km]',
                          figure_title='Land sea plotting Test ',
                          colorbar_plot=colorbar,
                          start_plot=False,finish_plot=finish_plot,time_dir=False)
        return(fig, ax1)

    def plot_track_unit(self,ax1,plot_lon,plot_lat,
                        hdf_date,hdf_id,hdf_granule,lon_range,lat_range,
                        font_size=24, track_color_method=None,
                        track_shadow=True, track_dir=True, 
                        track_dir_pos='edge',arrow_len_scale = 0.065,
                        id_label=True,granule_label=False,date_label=True):
        import numpy as np
        import matplotlib.pyplot as plt
        from mpl_toolkits.basemap import Basemap
        from matplotlib.collections import LineCollection
        
        plot_lon = self.check_list(plot_lon)
        plot_lat = self.check_list(plot_lat)
        track_num = len(plot_lon)
        ### arrow length
        quiver_len = 0
        if track_dir_pos == 'edge':
            len_scale = arrow_len_scale
        else:
            len_scale = arrow_len_scale*2
        for j in range(0,track_num):
            temp_len = len(plot_lon[j])
            quiver_len = quiver_len +temp_len
        quiver_len= int(quiver_len*len_scale/track_num)
        ### plot track
        for i in range(0,track_num):
            ### 
            points = np.array([plot_lon[i], plot_lat[i]]).T.reshape(-1, 1, 2)
            segments = np.concatenate([points[:-1], points[1:]], axis=1)
            if track_color_method is None:
                track_colors = self.get_track_colors(plot_lat[i])
                track_colors = track_colors[1:]
            elif isinstance(track_color_method, str):
                track_colors = track_color_method.lower()
            elif isinstance(track_color_method, (list, tuple, np.ndarray)):
                track_colors = self.get_track_colors(plot_lat[i],
                                                     track_color_method[0],track_color_method[1],
                                                     track_color_method[2],track_color_method[3],
                                                     track_color_method[4])
                track_colors = track_colors[1:]
            lc = LineCollection(segments,colors=track_colors,
                                linewidth=6,zorder=4, antialiaseds=False)
            ###
            if track_shadow:
                lc_bg = LineCollection(segments, linewidth=10, color='white', alpha=0.3, zorder=4)
                ax1.add_collection(lc_bg)
            ###
            ### add track on map
            ax1.add_collection(lc)
            ### add arrow on map
            if track_dir:
                self.plot_arrow_unit(ax1,plot_lon[i],plot_lat[i],lon_range,lat_range,
                                     quiver_len,track_dir_pos=track_dir_pos)
            ### plot track info
            #   hdf id
            id_pos = int(len(plot_lon[i])/2)
            if id_label:
                if granule_label:
                    ax1.text(plot_lon[i][id_pos],plot_lat[i][id_pos],
                             f'{str(int(hdf_granule[i][0:5]))}',c='darkorange',
                             fontsize=font_size-4, fontweight='bold',
                             ha='center',va='center',
                             bbox=dict(facecolor='ghostwhite', edgecolor='crimson', boxstyle='round,pad=0.1'),zorder=5)
                else:
                    ax1.text(plot_lon[i][id_pos],plot_lat[i][id_pos],
                             f'{str(hdf_id[i])}',c='darkorange',
                             fontsize=font_size-4, fontweight='bold',
                             ha='center', va='center',
                             bbox=dict(facecolor='ghostwhite', edgecolor='crimson', boxstyle='round,pad=0.1'),zorder=5)
#   date
            if date_label:
                date_pos = np.unravel_index(np.argmin(plot_lat[i]), plot_lat[i].shape)
                if date_pos[0]>1:
                    ha='right'
                else:
                    ha='left'
                ax1.text(plot_lon[i][date_pos],plot_lat[i][date_pos],
                         ''+str(int(hdf_date[i][8:10]))+'',c='Navy',
                         fontsize=font_size-6, fontweight='bold',
                         va='top', ha=ha,
                         bbox=dict(facecolor='snow', edgecolor='khaki',
                         boxstyle='round,pad=0.1'),zorder=5)
### illustration
##  illustration position
        if lon_range > lat_range:
            y_pos=0.075
            x_pos=0.033/(lon_range/lat_range)
        else:
            y_pos=0.075/(lat_range/lon_range)
            x_pos=0.033
##  plot illustration
#   hdf id
        if id_label:
            ax1.text(0.63,1+y_pos,'0',c='darkorange',
                     fontsize=font_size, fontweight='bold',
                     va='center_baseline', ha='left',
                     bbox=dict(facecolor='ghostwhite', edgecolor='crimson', boxstyle='round,pad=0.1'),
                     transform=ax1.transAxes,zorder=5)
            ax1.text(0.63+x_pos,1.003+y_pos,'hdf ID',
                     fontsize=font_size-2,
                     va='top', ha='left',
                     transform=ax1.transAxes,zorder=5)
#   date
        if date_label:
            ax1.text(0.85,1+y_pos,'1',c='Navy',
                     fontsize=font_size, fontweight='bold',
                     va='center_baseline', ha='left',
                     bbox=dict(facecolor='snow', edgecolor='khaki', boxstyle='round,pad=0.1'),
                     transform=ax1.transAxes,zorder=5)
            ax1.text(0.85+x_pos,1.003+y_pos,'Date',
                     fontsize=font_size-2,
                     va='top', ha='left',
                     transform=ax1.transAxes,zorder=5)
        
        #print(text.get_zorder())
###

    def read_data(self,full_path_file_list,var_name,region_mask_list,
                  combine_same_track=True,skip_margin=True,fit_era5_lon=True,
                  granule_out=True):
        """
        Merge function for read EarthCARE data
        1. Cut target region data
        2. Shift longitude from -180 ~ 180 to 0 ~ 360 ("fit_era5_lon" switch)
        3. Combine same track data (if target region cross different frames)
        """
        full_path_file_list = self.check_list(full_path_file_list)
        region_mask_list = self.check_list(region_mask_list)
        var_name = self.check_list(var_name)
        var_list = self.read_ori_data(full_path_file_list,var_name,skip_margin=skip_margin)
        region_var_list = self.sub_domain_extract(var_list, region_mask_list)
###     load latitude for combine same track
        lat_list = self.read_ori_data(full_path_file_list,'latitude',skip_margin=skip_margin)
        region_lat_list = self.sub_domain_extract(lat_list, region_mask_list)
###
        if var_name[0].lower() == 'longitude' and fit_era5_lon:
            region_var_list = self.fit_era5_lon(region_var_list)
###     call function for cimbine same track
        if combine_same_track:
            granule_list, frame_list = self.get_granule(full_path_file_list,frame_split=True)
            granule_output, region_var_list = self.combine_same_track(granule_list,frame_list,region_var_list,region_lat_list) 
        else:
            granule_list = self.get_granule(full_path_file_list)
            granule_output = granule_list
###     
        if granule_out:
            return(granule_output, region_var_list)
        else:
            return(region_var_list)

    def read_ori_data(self,full_path_file_list,var_name,skip_margin=True):
        """
        Use netCDF4 module to read EarthCARE data
        Two adjustment when reading data
        1. Skip margin array for ESA data ("skip_mergin" switch)
        2. Add axis to the along track (no height axis) variables 
        Else, no adjustment for the data array, value, and structure
        """
        from netCDF4 import Dataset
        import numpy as np
        full_path_file_list = self.check_list(full_path_file_list)
        var_name = self.check_list(var_name)
        var_list = []
        print('read variable: '+str(var_name[:])+'')
        for file_name in full_path_file_list:
            with Dataset(file_name, 'r') as re:
                ScienceData_ref = re.groups['ScienceData']
                diff_var = []
                for var in var_name:
                    var_data = np.array(ScienceData_ref.variables[var.lower()])
                    if len(var_data.shape) < 2:
                        var_data = np.expand_dims(var_data,axis=1)
                    if skip_margin:
                        lat_data = np.array(ScienceData_ref.variables['latitude'])
                        var_data = self.skip_margin(file_name, var_data, lat_data)
                    var_data = self.check_list(var_data)
                    diff_var.append(var_data[0])
                var_list.append(diff_var[0])
        #if var_name[0].lower() == 'longitude' and fit_era5_lon:
        #    var_list = self.fit_era5_lon(var_list)
        return(var_list)

    def read_geometric_info(self,sub_domain_file_list,region_mask_list,combine_same_track=True,lonlat_info=False,second_info=False):
        from datetime import datetime, timedelta
        import numpy as np
        sub_domain_file_list = self.check_list(sub_domain_file_list)
        region_mask_list = self.check_list(region_mask_list)
        granule, second_time = self.read_data(sub_domain_file_list,'time', 
                                              region_mask_list, 
                                              combine_same_track=combine_same_track)
        if lonlat_info:
            granule, plot_lat = self.read_data(sub_domain_file_list,'latitude', 
                                               region_mask_list, 
                                               combine_same_track=combine_same_track)
            granule, plot_lon = self.read_data(sub_domain_file_list,'longitude', 
                                               region_mask_list, 
                                               combine_same_track=combine_same_track)        
        h5_date = []
        h5_id = []
        region_start_time = []
        region_end_time = []

        base_time = datetime(2000, 1, 1, 0, 0, 0)
### region time
        for i in range(0,len(second_time)):
            h5_id.append(i)
            seconds_start = second_time[i][0]
            seconds_end = second_time[i][-1]
            start_time = base_time + timedelta(seconds=seconds_start[0])
            end_time = base_time + timedelta(seconds=seconds_end[0])
            start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')
            end_time = end_time.strftime('%Y-%m-%d %H:%M:%S')
            h5_date.append(start_time[0:10])
            region_start_time.append([int(start_time[11:13]),int(start_time[14:16])]) 
            region_end_time.append([int(end_time[11:13]),int(end_time[14:16])])
            
        if lonlat_info:
            if second_info:
                return(plot_lon,plot_lat,h5_date,h5_id,granule,region_start_time,region_end_time,UTC_start,plot_second)
            else:
                return(plot_lon,plot_lat,h5_date,h5_id,granule,region_start_time,region_end_time)
        else:
            if second_info:
                return(h5_date,h5_id,hdf_granule,region_start_time,region_end_time,UTC_start,plot_second)
            else:
                return(h5_date,h5_id,hdf_granule,region_start_time,region_end_time)

    def topo_landsea_array(self,surface_elevation=[],land_flag=[],height=[],
                           output_type='both'):
        import numpy as np
        sf_elev = self.check_list(surface_elevation)
        landsea = self.check_list(land_flag)
        height = self.check_list(height)
        topo_mask = []
        if output_type == 'elevation only':
            for prof in range(0,len(height)):
                array_shape = height[prof].shape
                topo_prof = np.zeros((array_shape[0],array_shape[1]))
                for i in range(0,array_shape[0]): 
                    for j in range(0,array_shape[1]):
                        if sf_elev[prof][i] > height[prof][i,j]:
                            topo_prof[i,j] = 1
                topo_prof[topo_prof<1] = np.nan
                topo_mask.append(topo_prof)
        if output_type == 'land sea only':
            for prof in range(0,len(height)):
                array_shape = height[prof].shape
                topo_prof = np.zeros((array_shape[0],array_shape[1]))
                masked_hei = height[0].copy()
                masked_hei[masked_hei<0]= 100000
                masked_hei[masked_hei>90000]= np.nanmin(masked_hei)
                min_pos = np.argmin(masked_hei,axis=1)
                min_idx = np.max(masked_hei)
                sea_flag = landsea[prof]>0.5
                for i in range(0,array_shape[0]):
###        land = 1; sea = 2
                    topo_prof[i,min_pos[i]:] = 2
                    if sea_flag[i,0]: 
                        topo_prof[i,min_pos[i]:] = 1 
                topo_prof[topo_prof<1] = np.nan
                topo_mask.append(topo_prof)
        if output_type == 'both':
            for prof in range(0,len(height)):
                array_shape = height[prof].shape
                topo_prof = np.zeros((array_shape[0],array_shape[1]))
                for i in range(0,array_shape[0]):
                    for j in range(0,array_shape[1]):
                        if sf_elev[prof][i] > height[prof][i,j]:
                            if landsea[prof][i]>0.5: 
###        land = 1; sea = 2 
                                topo_prof[i,j] = 1
                            else:
                                topo_prof[i,j] = 2
                topo_prof[topo_prof<1] = np.nan
                topo_mask.append(topo_prof)
        return(topo_mask)
 
    def plot_height_generate(self,height):
        import numpy as np
        height = self.check_list(height)
        plot_height = []
        for prof in range(0,len(height)):
            masked_hei = height[prof].copy()
            masked_hei[masked_hei>100000] = np.nanmin(masked_hei)
            plot_height.append(masked_hei)
        return(plot_height)

    def flatten_landsea(self,topo_mask,height,sea=True,land=False):
        import numpy as np
        topo_mask = self.check_list(topo_mask)
        height = self.check_list(height)
        unified_sea = []
        land_topo = []
        unified_height = []
        ### build unified height
        for prof in range(0,len(height)):
            array_shape = topo_mask[prof].shape
            masked_hei = height[prof].copy()
            masked_hei[masked_hei>100000] = np.nanmin(masked_hei)
            height_sea = masked_hei[np.nanmax(topo_mask[prof],axis=1)>1.5,:]
            if len(height_sea) > 0:
                mean_height = np.nanmean(height_sea,axis=0)
            else:
                mean_height = np.nanmean(masked_hei,axis=0) 
            height_array = np.tile(mean_height.reshape(1,masked_hei.shape[1]), (array_shape[0],1))
            neg_idx = np.where(mean_height < 0)[0]
            if len(neg_idx) > 0:
                sea_level = neg_idx[np.argmin(np.abs(mean_height[neg_idx]))]
            sea_mask = np.zeros((array_shape[0],array_shape[1]))
            sea_mask[np.nanmax(topo_mask[prof],axis=1)>1.5,sea_level:] = 2
            sea_mask[sea_mask<2] = np.nan
            if land:
                land_mask = np.zeros((array_shape[0],array_shape[1]))
                land_mask[np.nanmax(topo_mask[prof],axis=1)>0.5,sea_level:] = 1
                land_mask[np.nanmax(topo_mask[prof],axis=1)>1.5,sea_level:] = np.nan
            else:
                land_mask = topo_mask[prof].copy()
                land_mask[land_mask>1] = np.nan
            unified_sea.append(sea_mask)
            land_topo.append(land_mask)
            unified_height.append(height_array) 
        return(unified_sea,land_topo,unified_height)

    def skip_margin(self,file_name,var_data,lat_data):
        """
        C    >67.5N
        B, D 22.5N ~ 67.5N
        A, E 22.5S ~ 22.5N
        F, H 22.5S ~ 67.5S
        G    >67.5S
        """
        import numpy as np
        file_name = self.check_list(file_name)
        var_data = self.check_list(var_data)
        lat_data = self.check_list(lat_data)
        skiped_data = []
        for i in range(0,len(var_data)):
            granule = file_name[i].split('_')[-2]
            frame = granule[-1]
            data = var_data[i].copy()
            if frame == 'C':
               temp_data = data[lat_data[i]>=67.5,:]
            if frame == 'B' or frame == 'D':
               temp_data = data[lat_data[i]>=22.5,:]
               temp_lat  = lat_data[i][lat_data[i]>=22.5,]
               temp_data = temp_data[temp_lat<67.5,:]
            if frame == 'A' or frame == 'E':
               temp_data = data[lat_data[i]>=-22.5,:]
               temp_lat  = lat_data[i][lat_data[i]>=-22.5,]
               temp_data = temp_data[temp_lat<22.5,:]
            if frame == 'F' or frame == 'H':
               temp_data = data[lat_data[i]>=-67.5,:]
               temp_lat  = lat_data[i][lat_data[i]>=-67.5,]
               temp_data = temp_data[temp_lat<-22.5,:]
            if frame == 'G':
               temp_data = data[lat_data[i]<-67.5,:]
            skiped_data.append(temp_data)
        return(skiped_data)
   
    def sub_domain_extract(self,var_list,region_mask_list):
        import numpy as np
        var_list = self.check_list(var_list)
        regoion_mask_list = self.check_list(region_mask_list)
        region_var_list = []
        for i in range(0,len(var_list)):
### prevent no need sub-domain extraction condition
            if len(var_list[i]) > 1:
                region_var_list.append(np.array(var_list[i])[region_mask_list[i][:,0]>0,:].copy())
            else:
                region_var_list.append(np.array(var_list[i]))
        return(region_var_list)

    def combine_same_track(self,granule_list,frame_list,region_var_list,region_lat_list):
        import numpy as np
        granule_list = self.check_list(granule_list)
        frame_list = self.check_list(frame_list)
        region_var_list = self.check_list(region_var_list)
        region_lat_list = self.check_list(region_lat_list)
        granule_num, ind, counts = np.unique(granule_list ,
                                             return_index=True,
                                             return_counts=True)
        count_ind = 0
        combined_granule = []
        combined_group=[]
        combined_data = []
        combined_lat = []
        for indx in ind:
            #print(frame_list[indx:(indx + counts[count_ind])])
            temp_group = []
            if counts[count_ind] > 1:
                temp_group = [frame_list[indx]]
                temp_data = region_var_list[indx]
                temp_lat = region_lat_list[indx]
###             gourp step start
                for count in range(indx,indx + counts[count_ind]-1):
                    if ord(frame_list[count+1])-ord(frame_list[count]) == 1 and abs(temp_lat[-1] - region_lat_list[count+1][0]) < 1:
                        temp_group.append(frame_list[count+1])
                        #if abs(temp_lat[-1] - region_lat_list[count+1][0]) < 1:
                        temp_data = np.vstack((temp_data, region_var_list[count+1]))
                        temp_lat = np.vstack((temp_lat, region_lat_list[count+1]))
                    else:
###                     output array
                        combined_group.append(temp_group)
                        combined_data.append(temp_data)
                        combined_lat.append(temp_lat)
                        combined_granule.append(granule_num[count_ind])

                        temp_group = [frame_list[count+1]]
                        temp_data = region_var_list[count+1]
                        temp_lat = region_lat_list[count+1]
            else: 
                temp_group = [frame_list[indx]]
                temp_data = region_var_list[indx]
                temp_lat = region_lat_list[indx]
###         output array
            combined_group.append(temp_group)
            combined_data.append(temp_data)
            combined_lat.append(temp_lat)
            combined_granule.append(granule_num[count_ind])
            count_ind = count_ind +1
###     granule combine information
        for i in range(0,len(combined_granule)):
            for j in range(0,len(combined_group[i])):
                combined_granule[i] = combined_granule[i] + combined_group[i][j]
        return(combined_granule, combined_data)
    
    def get_granule(self,file_list,frame_split=False):
        """
        may extend to get more information from file name
        """
        file_list = self.check_list(file_list)
        if frame_split:
            granule = []
            frame = []
            for i in range(0,len(file_list)):
                single_granule = file_list[i].split('_')[-2]
                granule.append(single_granule[0:5])
                frame.append(single_granule[-1])
            return(granule,frame)
        else:
            granule = []
            for i in range(0,len(file_list)):
                single_granule = file_list[i].split('_')[-2]
                granule.append(single_granule)
            return(granule)

    def var_info(self,file_list,var=[],var_output=True,print_var=True):
        from netCDF4 import Dataset
        file_list = self.check_list(file_list)
        var = self.check_list(var)
        with Dataset(file_list[0], 'r') as re:
            ScienceData_ref = re.groups['ScienceData']
            var_list = ScienceData_ref.variables.keys()
            if print_var:
                if len(var) > 0:
                    for var_name in var:
                        print(ScienceData_ref.variables[var_name])
                else:
                    for var_name in var_list:
                        print(var_name)
        if var_output:
            return(var_list)

    def download_data(self,product_name,time_period,lat_region=[],sftp_download=True):
        import paramiko
        import fnmatch
        import os
        if len(lat_region) < 1:
            lat_region = self.lat_range
### ftp info
        hostname = 'ftp.gportal.jaxa.jp'
        port = 2051
        local_path = self.data_path
### function generate
        year_list, date_day_list, start_end_time_list = self.convert_input_period(time_period,julian=False)
        search_period = self.generate_date_period(year_list, date_day_list, start_end_time_list)
        product_name = self.check_list(product_name)
        lat_region = self.check_list(lat_region)
        sensor_type,product_type = self.product_name_split(product_name)
        product_cat = self.product_category(sensor_type)
        range_id = self.frame_ID(lat_region)
###
### SFTP download
### set ssh connection
        print('sftp login...')
        transport = paramiko.Transport((hostname, port))
        transport.connect(username=self.sftp_username, password=self.sftp_password)
        sftp = paramiko.SFTPClient.from_transport(transport)
###
        file_downloaded_mask = 0
        for p_num in range(0,len(product_name)):
            print(f'Download Product: {product_name[p_num]}')
            check_version_path = f'/standard/EarthCARE/{product_cat[p_num]}/{product_name[p_num]}/'
            #print(check_version_path)
            version_list = sorted(sftp.listdir(check_version_path))
            #print(version_list)
### search file for downloading
### local file comparision
### lat region focus
            for version in version_list:
                print(f'Search Version: {version}')
                for h5_time in search_period:
                    product_path = f'/standard/EarthCARE/{product_cat[p_num]}/{product_name[p_num]}/{version}/{h5_time[0:4]}/{h5_time[4:6]}/{h5_time[6:8]}/'
### local path check & generation
                    local_path = f'{self.data_path}/{product_name[p_num]}/{h5_time[0:4]}/{h5_time[4:6]}/{h5_time[6:8]}/'
                    os.makedirs(local_path, exist_ok=True)
                    existing_files = os.listdir(local_path)
### check remote path exist (mainly due to version changing)
                    path_mask = True
                    try:
                        file_list = sftp.listdir(product_path)
                    except FileNotFoundError:
                       #print('no file path exist')
                        path_mask = False
                    if path_mask:
### file name generate 
                        print(f'Search Period: {h5_time}')
                        if len(range_id) == 8:
                            target_files = [f'*{sensor_type[p_num]}*{product_type[p_num]}*_{h5_time}*_{h5_time[0:2]}*_*_*.h5']
                        else:
                            target_files = []
                            ### ABCDEFGH base on lat lon range
                            for frame in range_id:
                                #print(frame)
                                target_files.append(f'*{sensor_type[p_num]}*{product_type[p_num]}*_{h5_time}*_{h5_time[0:2]}*_*{frame}_*.h5')
### download part
                        #print(target_files)
                        print('Check mathched files on SFTP & skip downloaded files...')
                        for ta_file in target_files:
                            file_list = sftp.listdir(product_path)
                            matched_files = sorted(fnmatch.filter(file_list, ta_file))
                            download_files = [f for f in matched_files if f not in existing_files]
                            if len(matched_files) > 0 and len(download_files) <= 0:
                                file_downloaded_mask = 1
                            if len(matched_files) <= 0:
                                file_downloaded_mask = 2
                            #print(matched_files)
                            #print(download_files)
                            if len(download_files) > 0:
                                for filename in download_files:
                                    remote_file = f"{product_path}/{filename}"
                                    local_file = f"{local_path}{filename}"
                                    #print(local_file)
                                    if sftp_download:
                                        print(f'Downloading: {filename}')
                                        sftp.get(remote_file, local_file)
###
        if file_downloaded_mask == 2:
            print('No file matched your lat range or time period...')
            print('Please refine your region or time selection')
        if file_downloaded_mask == 1:
            print('Data already downloaded')
        sftp.close()
        transport.close()
        print('Download process finished')

    def product_name_split(self,product_name):
        product_name = self.check_list(product_name)
        sensor_type = []
        product_type = []
        for unsplited_name in product_name:
            split_parts = unsplited_name.split('.')
            split_name = split_parts[-1].split('_')
            sensor_type.append(split_name[0])
            product_type.append(split_name[-1])
        return(sensor_type,product_type)

    def get_latest_version(self,full_path_file_list,data_ver='latest'):
        import numpy as np
        """
        Version naming rule: vAb --> vAc --> vAd --> ... --> vBa --> vBb ...
        Currently use sorted() to get latest version files
        Potential failure may occur due to the version naming rule changing
        """
        full_path_file_list = self.check_list(full_path_file_list)
### group different granule data
        granules = []
        for idx in range(0,len(full_path_file_list)):
            split_parts = full_path_file_list[idx].split('_')
            granule = f'_{split_parts[-2]}_'
            version = split_parts[-1].split('.')[0]
            granules.append(granule)

        uni_granules, counts = np.unique(granules,return_counts=True)
###
### get latest version data files
        latest_version_files = []
        for i in range(0,len(uni_granules)):
            target_files = sorted(list(filter(lambda s: uni_granules[i]  in s, full_path_file_list)))
            if counts[i] == 1:
                latest_version_files.append(target_files[0])
            else:
                if data_ver == 'latest':
                    latest_version_files.append(target_files[-1])
                elif data_ver == 'oldest':
                    latest_version_files.append(target_files[0])
        return(latest_version_files)

    def frame_ID(self,lat_range):
        import numpy as np
        """
        A: 22.5°S (Ascending) to 22.5°N (Ascending)
        B: 22.5°N (Ascending) to 67.5°N (Ascending)
        C: 67.5°N (Ascending) to 67.5°N (Descending)
        D: 67.5°N (Descending) to 22.5°N (Descending)
        E: 22.5°N (Descending) to 22.5°S (Descending)
        F: 22.5°S (Descending) to 67.5°S (Descending)
        G: 67.5°S (Descending) to 67.5°S (Ascending)
        H: 67.5°S (Ascending) to 22.5°S (Ascending)
        ----------------------------------------------
        C    >67.5N
        B, D 22.5N ~ 67.5N
        A, E 22.5S ~ 22.5N
        F, H 22.5S ~ 67.5S
        G    >67.5S
        """
        id_thres = [-67.5, -22.5, 22.5, 67.5]
        frame_id = ['G', ['F','H'], ['A','E'], ['D','B'], 'C']
        bound = []
        for i in range(0,len(lat_range)):
            #print((lat_range[i]-(-112.5))/45)
            temp_bound = int(np.floor((lat_range[i]-(-112.5))/45))
            if i == 0:
                if lat_range[i] == -67.5 or lat_range[i] == -22.5 or lat_range[i] == 22.5 or lat_range[i] == 67.5:
                    temp_bound = int(temp_bound-1)
            bound.append(temp_bound)
        intval = np.arange(bound[0],bound[1]+1)
        region_id = []
        for i in intval:
            #print(i)
            region_id.extend(frame_id[i])
        return(sorted(region_id))

    def landsea_color(self):
        import matplotlib.colors as mcolors

        landsea_color = mcolors.LinearSegmentedColormap.from_list(
            "landsea_color", ['#ffffff', '#c79558', '#69adf5'], N=3)
        #land_sea_color.set_under((0.6784, 0.8470, 0.9019, 1))
        #land_sea_color
        return(landsea_color)

    def product_category(self,sensor_type):
        """
        category = ['ATLID','ATLID+MSI','ATLID+MSI+BBR',
                    'Auxiliary',
                    'BBR','BBR+MSI',
                    'CPR','CPR+ATLID','CPR+ATLID+MSI','CPR+ATLID+MSI+BBR',
                    'MSI']
        """
        sensor_type = self.check_list(sensor_type)
        product_cat = []
        for sensor in sensor_type:
            if sensor == 'ATL':
                product_cat.append('ATLID')

            if sensor == 'AM':
                product_cat.append('ATLID+MSI')

            if sensor == 'BMA':
                product_cat.append('ATLID+MSI+BBR')

            if sensor == 'AUX':
                product_cat.append('Auxiliary')

            if sensor == 'BBR':
                product_cat.append('BBR')

            if sensor == 'BM':
                product_cat.append('BBR+MSI')

            if sensor == 'CPR':
                product_cat.append('CPR')

            if sensor == 'AC':
                product_cat.append('CPR+ATLID')

            if sensor == 'ACM':
                product_cat.append('CPR+ATLID+MSI')

            if sensor == 'ALL':
                product_cat.append('CPR+ATLID+MSI+BBR')

            if sensor == 'MSI':
                product_cat.append('MSI')

        return(product_cat)

 
