# ael_satellite_tools

A Python module for downloading and analysis the satellite.

0.0.14 

New satellite support

EarthCARE satellite product now support download data, read data, and quick visualization
	Function name is similar to Cloudsat
	Document and demo coming soon

Function name changing & add feature

hima_plot.generate_rgb_figure() --> hima_plot.generate_band_figure(tbb_range = [180,300], tbb_cmap = 'Greys')
	Add feature: support other Himawari band data plotting

cloudsat.plot_track_w_rgb --> cloudsat.plot_track_w_band(tbb_range = [180,300], tbb_cmap = 'Greys')
	Add feature: support other Himawari band data plotting

Add feature only

Himawari module now support ftplib as new download method
        Download method switch: himawari.download(method = 'ftplib' or 'wget')
	ftplib is more stable than old method and has more clean form for error message

ro.plot_ro_distribution(tbb_range = [180,300], tbb_cmap = 'Greys')
	Add feature: support other Himawari band data plotting

There are some new features added not mention on the README, I will write a new document for those features.


## Installation

```bash
pip install ael_satellite_tools

