from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='vrbase',
    version='1.1.0',
    description='Русская документо-ориентированная база данных — проще чем SQL',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Pantapan1',
    packages=find_packages(),
    py_modules=['vrbase'],
    install_requires=[],
    extras_require={
        'crypto': ['cryptography>=41.0.0'],
    },
    python_requires='>=3.8',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    keywords='база данных, database, json, русский, documents, nosql',
)
