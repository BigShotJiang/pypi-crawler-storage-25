import json
import os
import shutil
import hashlib
import base64
from datetime import datetime
from typing import Any, List, Dict, Optional, Union
try:
    from cryptography.fernet import Fernet
    CRYPTO_OK = True
except ImportError:
    CRYPTO_OK = False


class ОшибкаБазы(Exception):
    pass


class ОшибкаКоробки(Exception):
    pass


class ОшибкаЗапроса(Exception):
    pass


class ОшибкаШифрования(Exception):
    pass


class Шифр:
    @staticmethod
    def создать_ключ(пароль: str) -> bytes:
        хэш = hashlib.sha256(пароль.encode()).digest()
        return base64.urlsafe_b64encode(хэш[:32])

    @staticmethod
    def зашифровать(данные: str, пароль: str) -> bytes:
        ключ = Шифр.создать_ключ(пароль)
        фернет = Fernet(ключ)
        return фернет.encrypt(данные.encode())

    @staticmethod
    def расшифровать(данные: bytes, пароль: str) -> str:
        ключ = Шифр.создать_ключ(пароль)
        фернет = Fernet(ключ)
        return фернет.decrypt(данные).decode()


class Условие:
    def __init__(self):
        self.условия_и = []
        self.условия_или = []
        self.условия_не = []
        self.условия_содержит = []
        self.сортировка = None
        self.обратная_сортировка = False
        self.лимит_значение = None
        self.пропустить_значение = 0

    def где(self, **условия):
        for ключ, значение in условия.items():
            self.условия_и.append((ключ, значение))
        return self

    def и_(self, **условия):
        return self.где(**условия)

    def или(self, **условия):
        for ключ, значение in условия.items():
            self.условия_или.append((ключ, значение))
        return self

    def не_(self, **условия):
        for ключ, значение in условия.items():
            self.условия_не.append((ключ, значение))
        return self

    def содержит(self, **условия):
        for ключ, значение in условия.items():
            self.условия_содержит.append((ключ, значение))
        return self

    def сортировать_по(self, ключ: str, убывание: bool = False):
        self.сортировка = ключ
        self.обратная_сортировка = убывание
        return self

    def лимит(self, n: int):
        self.лимит_значение = n
        return self

    def пропустить(self, n: int):
        self.пропустить_значение = n
        return self

    def обратно(self):
        self.обратная_сортировка = not self.обратная_сортировка
        return self


class Индекс:
    def __init__(self, имя: str, ключ: Union[str, List[str]]):
        self.имя = имя
        self.ключи = [ключ] if isinstance(ключ, str) else ключ
        self.данные = {}

    def добавить(self, ид_документа: int, документ: Dict):
        значения = tuple(self.получить_значение(документ, к) for к in self.ключи)
        if значения not in self.данные:
            self.данные[значения] = set()
        self.данные[значения].add(ид_документа)

    def удалить(self, ид_документа: int, документ: Dict):
        значения = tuple(self.получить_значение(документ, к) for к in self.ключи)
        if значения in self.данные:
            self.данные[значения].discard(ид_документа)
            if not self.данные[значения]:
                del self.данные[значения]

    def найти(self, значение: Any) -> set:
        значения = tuple(значение) if isinstance(значение, (list, tuple)) else (значение,)
        if значения in self.данные:
            return self.данные[значения]
        return set()

    def найти_диапазон(self, от_: Any, до: Any) -> set:
        результат = set()
        for значения, ид in self.данные.items():
            val = значения[0]
            if от_ <= val <= до:
                результат.update(ид)
        return результат

    def получить_значение(self, документ: Dict, ключ: str) -> Any:
        ключи = ключ.split(".")
        значение = документ
        for к in ключи:
            if isinstance(значение, dict):
                значение = значение.get(к)
            else:
                return None
        return значение


class Коробка:
    def __init__(self, имя: str, база):
        self.имя = имя
        self.база = база
        self.документы = []
        self.счетчик = 0
        self.индексы: Dict[str, Индекс] = {}

    def положить(self, документ: Dict) -> int:
        if not isinstance(документ, dict):
            raise ОшибкаКоробки("Документ должен быть словарём")
        ид = self.счетчик
        документ["_id"] = ид
        документ["_создан"] = datetime.now().isoformat()
        self.документы.append(документ)
        for индекс in self.индексы.values():
            индекс.добавить(ид, документ)
        self.счетчик += 1
        return ид

    def положить_много(self, документы: List[Dict]) -> List[int]:
        ид_список = []
        for документ in документы:
            ид_список.append(self.положить(документ))
        return ид_список

    def найти(self, где: Dict = None, содержит: Dict = None, сортировка: str = None, лимит: int = None) -> List[Dict]:
        условие = Условие()
        if где:
            условие.где(**где)
        if содержит:
            условие.содержит(**содержит)
        if сортировка:
            убыв = "убыв" in сортировка or "desc" in сортировка.lower()
            ключ = сортировка.replace(" убыв", "").replace(" desc", "").replace(" возр", "").replace(" asc", "")
            условие.сортировать_по(ключ, убыв)
        if лимит:
            условие.лимит(лимит)
        return self.выполнить(условие)

    def найти_один(self, где: Dict = None, **kwargs) -> Optional[Dict]:
        if где is None and kwargs:
            где = kwargs
        результат = self.найти(где=где, лимит=1)
        return результат[0] if результат else None

    def найти_все(self) -> List[Dict]:
        return self.документы.copy()

    def найти_по_id(self, ид: int) -> Optional[Dict]:
        for документ in self.документы:
            if документ.get("_id") == ид:
                return документ
        return None

    def считать(self, где: Dict = None) -> int:
        if not где:
            return len(self.документы)
        return len(self.найти(где=где))

    def выполнить(self, условие: Условие) -> List[Dict]:
        результат = []

        if условие.условия_и:
            ид_кандидаты = None
            for ключ, значение in условие.условия_и:
                if ключ in self.индексы:
                    ид = self.индексы[ключ].найти(значение)
                    if ид_кандидаты is None:
                        ид_кандидаты = ид
                    else:
                        ид_кандидаты &= ид
            if ид_кандидаты is not None:
                результат = [d for d in self.документы if d["_id"] in ид_кандидаты]
            else:
                результат = self.документы.copy()

            for ключ, значение in условие.условия_и:
                if ид_кандидаты is None:
                    результат = [d for d in результат if self._проверить_условие(d, ключ, значение)]
        else:
            результат = self.документы.copy()

        for ключ, значение in условие.условия_или:
            результат_или = [d for d in self.документы if self._проверить_условие(d, ключ, значение)]
            существующие_ид = {d["_id"] for d in результат}
            for d in результат_или:
                if d["_id"] not in существующие_ид:
                    результат.append(d)
                    существующие_ид.add(d["_id"])

        for ключ, значение in условие.условия_не:
            результат = [d for d in результат if not self._проверить_условие(d, ключ, значение)]

        for ключ, значение in условие.условия_содержит:
            результат = [d for d in результат if self._проверить_содержит(d, ключ, значение)]

        if условие.сортировка:
            результат.sort(key=lambda d: self._получить_ключ(d, условие.сортировка) or 0, reverse=условие.обратная_сортировка)

        if условие.пропустить_значение:
            результат = результат[условие.пропустить_значение:]

        if условие.лимит_значение:
            результат = результат[:условие.лимит_значение]

        return результат

    def обновить(self, где: Dict, данные: Dict) -> int:
        найденные = self.найти(где=где)
        for документ in найденные:
            старый = документ.copy()
            for ключ, значение in данные.items():
                ключи = ключ.split(".")
                цель = документ
                for к in ключи[:-1]:
                    if к not in цель:
                        цель[k] = {}
                    цель = цель[k]
                цель[ключи[-1]] = значение
            for имя, индекс in self.индексы.items():
                индекс.удалить(документ["_id"], старый)
                индекс.добавить(документ["_id"], документ)
        return len(найденные)

    def обновить_по_id(self, ид: int, данные: Dict) -> bool:
        документ = self.найти_по_id(ид)
        if not документ:
            return False
        self.обновить(где={"_id": ид}, данные=данные)
        return True

    def удалить(self, где: Dict = None) -> int:
        if где is None:
            return self.удалить_все()
        найденные = self.найти(где=где)
        for документ in найденные:
            for имя, индекс in self.индексы.items():
                индекс.удалить(документ["_id"], документ)
            self.документы.remove(документ)
        return len(найденные)

    def удалить_по_id(self, ид: int) -> bool:
        документ = self.найти_по_id(ид)
        if not документ:
            return False
        self.удалить(где={"_id": ид})
        return True

    def удалить_все(self) -> int:
        count = len(self.документы)
        self.документы.clear()
        for индекс in self.индексы.values():
            индекс.данные.clear()
        self.счетчик = 0
        return count

    def есть(self, где: Dict) -> bool:
        return len(self.найти(где=где, лимит=1)) > 0

    def создать_индекс(self, ключ: Union[str, List[str]]):
        имя = "_".join(ключ) if isinstance(ключ, list) else ключ
        if имя in self.индексы:
            return self.индексы[имя]
        индекс = Индекс(имя, ключ)
        self.индексы[имя] = индекс
        for документ in self.документы:
            индекс.добавить(документ["_id"], документ)
        return индекс

    def удалить_индекс(self, ключ: str):
        if ключ in self.индексы:
            del self.индексы[ключ]

    def уникальные(self, ключ: str) -> List[Any]:
        значения = set()
        for документ in self.документы:
            val = self._получить_ключ(документ, ключ)
            if val is not None:
                if isinstance(val, list):
                    for v in val:
                        значения.add(v)
                else:
                    значения.add(val)
        return sorted(значения, key=str)

    def ключи(self) -> List[str]:
        все_ключи = set()
        for документ in self.документы:
            все_ключи.update(документ.keys())
        return sorted(все_ключи)

    def размер(self) -> int:
        return len(self.документы)

    def _проверить_условие(self, документ: Dict, ключ: str, значение: Any) -> bool:
        val = self._получить_ключ(документ, ключ)
        if isinstance(значение, str) and val is not None:
            значение_str = str(значение)
            if значение_str.startswith("> "):
                try:
                    return float(val) > float(значение_str[2:])
                except (ValueError, TypeError):
                    return str(val) > значение_str[2:]
            elif значение_str.startswith("< "):
                try:
                    return float(val) < float(значение_str[2:])
                except (ValueError, TypeError):
                    return str(val) < значение_str[2:]
            elif значение_str.startswith(">= "):
                return float(val) >= float(значение_str[3:])
            elif значение_str.startswith("<= "):
                return float(val) <= float(значение_str[3:])
            elif значение_str.startswith("!= "):
                return val != значение_str[3:]
            elif "между" in значение_str and " and " in значение_str:
                parts = значение_str.replace("между ", "").split(" and ")
                try:
                    return float(parts[0]) <= float(val) <= float(parts[1])
                except (ValueError, TypeError):
                    return str(parts[0]) <= str(val) <= str(parts[1])
            elif значение_str.startswith("содержит "):
                search_val = значение_str[9:]
                if isinstance(val, str):
                    return search_val.lower() in val.lower()
                if isinstance(val, list):
                    return search_val in val
                return str(search_val) in str(val)
        return val == значение

    def _проверить_содержит(self, документ: Dict, ключ: str, значение: Any) -> bool:
        val = self._получить_ключ(документ, ключ)
        if isinstance(val, list):
            return значение in val
        if isinstance(val, str):
            return str(значение) in val
        if isinstance(val, dict):
            return значение in val.values()
        return False

    def _получить_ключ(self, документ: Dict, ключ: str) -> Any:
        ключи = ключ.split(".")
        значение = документ
        for к in ключи:
            if isinstance(значение, dict):
                значение = значение.get(к)
            else:
                return None
        return значение

    def экспорт(self) -> List[Dict]:
        return self.документы.copy()

    def импорт(self, данные: List[Dict]):
        for документ in данные:
            if "_id" in документ:
                del документ["_id"]
            if "_создан" in документ:
                del документ["_создан"]
            self.положить(документ)


class База:
    def __init__(self, имя: str, путь: str = None, ключ: str = None):
        self.имя = имя
        self.путь = путь or f"{имя}.json"
        if ключ:
            self.путь = self.путь.replace(".json", ".enc")
        self.ключ = ключ
        self.коробки: Dict[str, Коробка] = {}
        self.загрузить()

    def коробка(self, имя: str) -> Коробка:
        if имя not in self.коробки:
            self.коробки[имя] = Коробка(имя, self)
        return self.коробки[имя]

    def сохранить(self):
        """Сохраняет базу с защитой от повреждения (через .tmp файл)"""
        данные = {}
        for имя, коробка in self.коробки.items():
            данные[имя] = коробка.экспорт()
        
        путь_tmp = self.путь + '.tmp'
        путь_бэкап = self.путь + '.bak'
        
        try:
            if self.ключ:
                json_данные = json.dumps(данные, ensure_ascii=False, indent=2)
                зашифровано = Шифр.зашифровать(json_данные, self.ключ)
                with open(путь_tmp, 'wb') as ф:
                    ф.write(зашифровано)
            else:
                with open(путь_tmp, 'w', encoding='utf-8') as ф:
                    json.dump(данные, ф, ensure_ascii=False, indent=2)
            
            # Атомарная замена: сохраняем старый файл как .bak, переименовываем .tmp в основной
            if os.path.exists(self.путь):
                if os.path.exists(путь_бэкап):
                    os.remove(путь_бэкап)
                os.rename(self.путь, путь_бэкап)
            
            os.rename(путь_tmp, self.путь)
            
            # Удаляем бэкап после успешной замены
            if os.path.exists(путь_бэкап):
                os.remove(путь_бэкап)
                
        except Exception as e:
            raise ОшибкаБазы(f"Ошибка сохранения: {e}")

    
    def автосохранение(self, включить=True, интервал=5):
        """Автоматическое сохранение каждые N операций записи"""
        self._автосохранение = включить
        self._счётчик_операций = 0
        self._интервал = интервал
    
    def _отметить_изменение(self):
        """Вызывается после каждой операции записи"""
        if getattr(self, '_автосохранение', False):
            self._счётчик_операций += 1
            if self._счётчик_операций >= self._интервал:
                self.сохранить()
                self._счётчик_операций = 0

    def загрузить(self):
        if not os.path.exists(self.путь):
            return
        
        try:
            if self.ключ:
                with open(self.путь, 'rb') as ф:
                    зашифровано = ф.read()
                json_данные = Шифр.расшифровать(зашифровано, self.ключ)
                данные = json.loads(json_данные)
            else:
                with open(self.путь, 'r', encoding='utf-8') as ф:
                    данные = json.load(ф)
            
            for имя, документы in данные.items():
                коробка = self.коробка(имя)
                коробка.удалить_все()
                коробка.импорт(документы)
        except Exception as e:
            raise ОшибкаБазы(f"Не удалось загрузить базу: {e}")

    def сохранить_как(self, путь: str):
        старый_путь = self.путь
        self.путь = путь
        self.сохранить()
        self.путь = старый_путь

    def бэкап(self):
        временная_метка = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        имя_бэкапа = self.путь.replace(".json", f"_{временная_метка}.json").replace(".enc", f"_{временная_метка}.enc")
        shutil.copy2(self.путь, имя_бэкапа)
        return имя_бэкапа

    def очистить(self):
        for коробка in self.коробки.values():
            коробка.удалить_все()
        self.коробки.clear()
        if os.path.exists(self.путь):
            os.remove(self.путь)

    def список_коробок(self) -> List[str]:
        return sorted(self.коробки.keys())

    def размер(self) -> int:
        if os.path.exists(self.путь):
            return os.path.getsize(self.путь)
        return 0

    def инфо(self) -> Dict:
        return {
            "имя": self.имя,
            "путь": self.путь,
            "зашифрована": bool(self.ключ),
            "коробок": len(self.коробки),
            "размер_байт": self.размер(),
            "документов": sum(к.размер() for к in self.коробки.values())
        }

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.сохранить()

    def __repr__(self):
        return f"База('{self.имя}', коробок: {len(self.коробки)}, размер: {self.размер()} байт)"


class Версия:
    НОМЕР = "1.0.0"
    НАЗВАНИЕ = "VRBase"
    АВТОР = "Pantapan1 & RuGram Team"

    @staticmethod
    def инфо():
        return f"{Версия.НАЗВАНИЕ} v{Версия.НОМЕР} by {Версия.АВТОР}"


if __name__ == "__main__":
    print(Версия.инфо())