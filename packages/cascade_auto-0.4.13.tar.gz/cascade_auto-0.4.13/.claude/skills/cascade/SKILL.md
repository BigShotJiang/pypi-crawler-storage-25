---
name: cascade
description: Multi-agent task coordination using DAG-based scheduling. Use when multiple Claude Code sessions need to collaborate on tasks with dependencies, or when managing complex multi-step workflows.
allowed-tools: Read Edit Write Bash Grep Glob
---

# Cascade

You are the **orchestrator** — build the DAG, dispatch workers, adapt the graph. Never claim or execute tasks.

!`command -v cascade >/dev/null 2>&1 || echo "⚠ cascade not installed — run: pipx install cascade-auto"`

## Rules

1. **Contracts on edges** — every dependency carries `expectation` + `promise`. Without them, downstream agents hallucinate what upstream delivered.
2. **Forward-only feedback** — rework derives new corrective nodes, never reverses edges. Reversing creates cycles and invalidates downstream work.
3. **ACTIVE protection** — cannot remove/split nodes with active agents. Release or wait first.
4. **Parallelism** — multiple `Agent()` calls in one message run concurrently. The initial DAG is a hypothesis — adapt as reality reveals itself.

## Workflow

```
1. Build DAG        → cascade add-nodes --json '[...]'
2. Dispatch workers → Agent() calls — workers auto-claim, auto-renew lease, auto-release on exit
3. Monitor          → cascade watch — react to COMPLETED / FAILED / stalled
4. Adapt            → split, rework, refine, remove, edit (see table below)
5. Repeat           → until all nodes COMPLETED
```

**Dispatching**: spawn identical workers via `Agent()` — no agent-id, no task-id, no task-specific information in description or prompt. Workers are homogeneous; each auto-claims the highest-priority READY task on startup (SubagentStart hook), auto-renews its lease on every tool call (PreToolUse hook), and auto-releases if it exits without finishing (Stop hook). The worker's only cascade CLI call is `finish-task`. If no READY tasks exist, the worker exits immediately. Never leak task identity into the dispatch — the worker discovers its task from the briefing.

**Monitoring**: prefer `cascade watch` (edge-triggered, silent when idle) over `cascade list-nodes` (re-emits unchanged state). Use `cascade inspect --task <id>` to review a node's briefing and delivered context without claiming it. See [references/watch.md](references/watch.md).

## Adapt

| Signal | Operation | Reference |
|--------|-----------|-----------|
| Task too large / peer 3x slower | `split-node` | [split-node.md](references/split-node.md) |
| Upstream output wrong or incomplete | `rework` | [rework.md](references/rework.md) |
| Hidden dependency discovered | `refine-node` | [refine-node.md](references/refine-node.md) |
| Task no longer needed | `remove-node` | [remove-node.md](references/remove-node.md) |
| Scope change on existing task | `edit-node` | [edit-node.md](references/edit-node.md) |
| Agent stalled (no progress) | `check-timeouts` | [check-timeouts.md](references/check-timeouts.md) |
| Worker completes but output is wrong | `rework` — never edit a completed node's context directly | |
| Worker exits without `finish-task` | No action needed — Stop hook auto-released it back to READY | |
| Graph stuck (nothing READY) | `list-nodes` — look for PENDING cycles or forgotten ACTIVE tasks | |

For the context system, contracts, fencing tokens, and rework model: [references/concepts.md](references/concepts.md)
