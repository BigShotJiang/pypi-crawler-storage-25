#!/usr/bin/env bash
set -uo pipefail

SUBAGENT_ID=$(jq -r '.agent_id // empty')
[ -z "$SUBAGENT_ID" ] && exit 0
CLAIM="${CLAUDE_PROJECT_DIR:-.}/.cascade/claims/${SUBAGENT_ID}.json"

[ ! -f "$CLAIM" ] && exit 0

TASK_ID=$(jq -r '.task_id' "$CLAIM")
TOKEN=$(jq -r '.token' "$CLAIM")
AGENT_ID=$(jq -r '.agent_id' "$CLAIM")

cascade renew-task --task "$TASK_ID" --agent "$AGENT_ID" --token "$TOKEN" >/dev/null 2>&1 || true
exit 0
