#!/usr/bin/env bash
set -euo pipefail

INPUT=$(cat)
SUBAGENT_ID=$(echo "$INPUT" | jq -r '.agent_id')
CASCADE_AGENT=$(head -c 4 /dev/urandom | xxd -p)
CLAIMS_DIR="${CLAUDE_PROJECT_DIR:-.}/.cascade/claims"

BRIEFING=$(cascade get-task --agent "$CASCADE_AGENT" 2>&1) || {
  jq -n --arg ctx "NO_READY_TASKS: $BRIEFING" '{
    hookSpecificOutput: {
      hookEventName: "SubagentStart",
      additionalContext: $ctx
    }
  }'
  exit 0
}

TASK_ID=$(echo "$BRIEFING" | head -1 | sed 's/^Task: //')
TOKEN=$(echo "$BRIEFING" | grep '^fencing_token:' | awk '{print $2}')

mkdir -p "$CLAIMS_DIR"
jq -n \
  --arg task_id "$TASK_ID" \
  --argjson token "$TOKEN" \
  --arg agent_id "$CASCADE_AGENT" \
  '{task_id: $task_id, token: $token, agent_id: $agent_id}' \
  > "${CLAIMS_DIR}/${SUBAGENT_ID}.json"

CONTEXT="${BRIEFING}agent_id: ${CASCADE_AGENT}"

jq -n --arg ctx "$CONTEXT" '{
  hookSpecificOutput: {
    hookEventName: "SubagentStart",
    additionalContext: $ctx
  }
}'
