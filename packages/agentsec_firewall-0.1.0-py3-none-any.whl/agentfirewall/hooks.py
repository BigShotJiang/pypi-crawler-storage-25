"""Claude Code hook integration for agentfirewall.

PreToolUse hook: reads tool call from stdin, checks policy, exits 2 to block.
PostToolUse hook: reads tool result from stdin, logs to audit trail.

Install via: agentfirewall install
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

from agentsec_core.schemas import AuditEvent, PolicyAction

logger = logging.getLogger(__name__)

# Default paths (created by `agentfirewall init`)
DEFAULT_POLICY_PATH = ".agentfirewall/policy.yaml"
DEFAULT_LOG_PATH = ".agentfirewall/audit.jsonl"


def _read_hook_input() -> dict:
    """Read JSON hook input from stdin. Returns empty dict on failure."""
    try:
        raw = sys.stdin.read()
        return json.loads(raw) if raw.strip() else {}
    except (json.JSONDecodeError, OSError):
        return {}


def _parse_json_field(data: dict, field: str) -> dict:
    """Parse a possibly-stringified JSON field."""
    value = data.get(field, "{}")
    if isinstance(value, dict):
        return value
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return {}


def pretool_hook() -> None:
    """PreToolUse hook entry point.

    Reads stdin JSON with tool_name and tool_input.
    Checks against policy. Exits 2 to block, 0 to allow.
    Outputs JSON reason on block.
    """
    if not Path(DEFAULT_POLICY_PATH).exists():
        sys.exit(0)  # No policy = allow all

    from .interceptor import Interceptor

    hook_data = _read_hook_input()
    tool_name = hook_data.get("tool_name", "")
    tool_input = _parse_json_field(hook_data, "tool_input")

    try:
        interceptor = Interceptor(
            policy_path=DEFAULT_POLICY_PATH,
            log_path=DEFAULT_LOG_PATH,
        )
        decision = interceptor.check(tool_name, tool_input)
    except Exception as exc:
        # Fail-open: don't break Claude Code if firewall crashes
        sys.stderr.write(f"agentfirewall: error checking policy: {exc}\n")
        sys.exit(0)

    if decision.action == PolicyAction.DENY:
        reason = decision.reason or "Blocked by agentfirewall policy"
        output = json.dumps({"decision": "block", "reason": reason})
        print(output)  # noqa: T201 — CLI output
        sys.exit(2)

    sys.exit(0)


def posttool_hook() -> None:
    """PostToolUse hook entry point.

    Reads stdin JSON with tool result. Logs to audit trail.
    Always exits 0 (never blocks post-execution).
    """
    if not Path(DEFAULT_LOG_PATH).parent.exists():
        sys.exit(0)

    from agentsec_core.logger import AuditLogger

    hook_data = _read_hook_input()
    tool_name = hook_data.get("tool_name", "")

    try:
        audit_logger = AuditLogger(DEFAULT_LOG_PATH)
        event = AuditEvent(
            event_type="tool_execution",
            tool_name=tool_name,
            action_taken=PolicyAction.LOG,
        )
        audit_logger.log(event)
    except Exception as exc:
        sys.stderr.write(f"agentfirewall: error logging: {exc}\n")

    sys.exit(0)
