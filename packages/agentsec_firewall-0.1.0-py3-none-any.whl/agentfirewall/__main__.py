"""Allow running as python3 -m agentfirewall."""

from .cli import main

main()
