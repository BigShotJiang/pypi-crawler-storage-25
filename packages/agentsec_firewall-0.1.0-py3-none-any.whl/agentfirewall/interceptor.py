"""Tool call interceptor with policy enforcement."""

from __future__ import annotations

import functools
import logging
from pathlib import Path
from typing import Any, Callable

from agentsec_core.alerts import create_alerter
from agentsec_core.logger import AuditLogger
from agentsec_core.policy import evaluate, load_policy
from agentsec_core.schemas import AuditEvent, Policy, PolicyAction, PolicyDecision

logger = logging.getLogger(__name__)


class PolicyViolationError(Exception):
    """Raised when a tool call violates the security policy."""

    def __init__(self, decision: PolicyDecision) -> None:
        self.decision = decision
        super().__init__(f"Policy violation: {decision.reason}")


class Interceptor:
    """Intercepts tool calls and enforces security policies.

    Usage:
        interceptor = Interceptor(policy_path="policy.yaml", log_path="audit.jsonl")
        decision = interceptor.check("Bash", {"command": "rm -rf /"})
        # decision.action == PolicyAction.DENY

        # Or as a decorator:
        @interceptor.wrap("my_tool")
        def dangerous_function(params):
            ...
    """

    def __init__(
        self,
        policy_path: str | Path | None = None,
        policy: Policy | None = None,
        log_path: str | Path = ".agentfirewall/audit.jsonl",
        webhook_url: str | None = None,
    ) -> None:
        """Initialize with either a policy file path or a Policy object."""
        if policy is not None:
            self._policy = policy
        elif policy_path is not None:
            self._policy = load_policy(policy_path)
        else:
            raise ValueError("Either policy_path or policy must be provided")

        self._logger = AuditLogger(log_path)
        self._alerter = create_alerter(webhook_url) if webhook_url else None

    def check(self, tool_name: str, parameters: dict | None = None) -> PolicyDecision:
        """Check a tool call against the policy.

        Returns PolicyDecision. Logs the event. Fires alert on DENY/ALERT.
        Does NOT raise -- caller decides what to do.
        """
        decision = evaluate(self._policy, tool_name, parameters)

        event = AuditEvent(
            event_type="policy_check",
            tool_name=tool_name,
            action_taken=decision.action,
            violations=list(decision.violations) if decision.violations else [],
            parameters=parameters or {},
        )
        self._logger.log(event)

        if decision.action in (PolicyAction.DENY, PolicyAction.ALERT) and self._alerter:
            try:
                self._alerter.send(event)
            except Exception as exc:
                logger.warning("Failed to send alert: %s", exc)

        return decision

    def check_or_raise(
        self, tool_name: str, parameters: dict | None = None
    ) -> PolicyDecision:
        """Like check(), but raises PolicyViolationError on DENY."""
        decision = self.check(tool_name, parameters)
        if decision.action == PolicyAction.DENY:
            raise PolicyViolationError(decision)
        return decision

    def wrap(self, tool_name: str) -> Callable:
        """Decorator that checks policy before executing a function.

        Usage:
            @interceptor.wrap("data_export")
            def export_data(params):
                ...

        Raises PolicyViolationError if denied.
        """
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                self.check_or_raise(tool_name, kwargs or {})
                return func(*args, **kwargs)
            return wrapper
        return decorator

    @property
    def audit_logger(self) -> AuditLogger:
        """Access the underlying audit logger."""
        return self._logger
