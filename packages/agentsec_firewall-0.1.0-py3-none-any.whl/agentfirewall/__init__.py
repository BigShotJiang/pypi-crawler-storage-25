"""agentfirewall: Policy-enforced firewall for AI agent tool calls."""

__version__ = "0.1.0"

from .interceptor import Interceptor, PolicyViolationError
