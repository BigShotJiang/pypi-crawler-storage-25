"""
The setup.py file for PyNUTClient
"""
# Based on https://medium.com/@VersuS_/automate-pypi-releases-with-github-actions-4c5a9cfe947d
# See also .github/workflows/PyNUTClient.yml for active packaging steps

from setuptools import setup, find_packages
import os
import sys

here = os.path.abspath(os.path.dirname(__file__))

HAVE_WARNINGS = False
try:
    import warnings
    warnings.filterwarnings("error")
    HAVE_WARNINGS = True
except Exception as x:
    # sys.stderr.write("WARNING: failed to import warnings or configure them: %s" % str(x))
    pass

try:
    # NOTE: Deprecated as of python3.14
    import codecs
    HAVE_CODECS = True
    fd = None
    try:
        # Open self to test that it works
        fd = codecs.open(os.path.abspath(__file__), mode="r", encoding='utf-8')
        USE_CODECS = True
        # sys.stderr.write("INFO: import codecs went well, and codecs.open() did not raise exceptions\n")
    except DeprecationWarning as x:
        USE_CODECS = False
        # sys.stderr.write("WARNING: import codecs went well, but codecs.open() failed: %s\n" % str(x))
    if fd is not None:
        fd.close()
except Exception as x:
    # sys.stderr.write("WARNING: import codecs failed: %s\n" % str(x))
    HAVE_CODECS = False
    USE_CODECS = False

if HAVE_WARNINGS:
    warnings.resetwarnings()

# README.txt appears from README.adoc during package or CI build
if USE_CODECS:
    with codecs.open(os.path.join(here, "README.txt"), encoding="utf-8") as fh:
        long_description = "\n" + fh.read()
else:
    with open(os.path.join(here, "README.txt"), encoding="utf-8") as fh:
        long_description = "\n" + fh.read()

setup(
    name =	"pynutclient",	### "PyNUTClient" lower-cased due to PEP-0625
    version =	'2.8.5',
    author =	"The Network UPS Tools project",
    license =	"GPL-3.0-or-later",
    license_files =	('LICENSE-GPL3',),
    author_email =	"jimklimov+nut@gmail.com",
    description =	"Python client bindings for NUT",
    url =	"https://github.com/networkupstools/nut/tree/master/scripts/python/module",
    long_description_content_type =	"text/plain",	# NOTE: No asciidoc so far, see https://packaging.python.org/en/latest/specifications/core-metadata/
    long_description =	long_description,
    packages   =	find_packages(),
    #py_modules =	['PyNUT'],
    package_dir =	{'PyNUT': 'PyNUTClient'},
    #data_files =	[('', ['tox.ini'])],
    #scripts    =	['PyNUTClient/test_nutclient.py', 'PyNUTClient/__init__.py'],
    python_requires =	'>=2.6',
    keywords =	['pypi', 'cicd', 'python', 'nut', 'Network UPS Tools'],
    classifiers = [
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Topic :: System :: Monitoring",
        "Topic :: System :: Systems Administration",
        "License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)",
        "Programming Language :: Python :: 2.6",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows"
    ]
)

