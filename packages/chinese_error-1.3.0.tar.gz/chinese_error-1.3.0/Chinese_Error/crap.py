import os
import sys
import traceback
import inspect
import builtins
import re
import json
from pathlib import Path

__version__ = "1.3.0"


try:
    import text_discoloration as tcd
    HAS_TCD = True
except ImportError:
    HAS_TCD = False
    class tcd:
        @staticmethod
        def error(text):
            print(f"\033[91m[ERROR] {text}\033[0m")
        @staticmethod
        def success(text):
            print(f"\033[92m[SUCCESS] {text}\033[0m")
        @staticmethod
        def info(text):
            print(f"\033[94m[INFO] {text}\033[0m")
        @staticmethod
        def warn(text):
            print(f"\033[93m[WARNING] {text}\033[0m")



def _generate_err_msg():
    """自动生成异常中文对照表"""
    core_msg = {
        "NameError": "变量未定义",
        "IndexError": "索引超出范围",
        "SyntaxError": "语法错误",
        "IndentationError": "缩进错误",
        "TypeError": "类型错误",
        "ValueError": "值错误",
        "KeyError": "字典键不存在",
        "AttributeError": "属性不存在",
        "ModuleNotFoundError": "模块未找到",
        "ImportError": "导入失败",
        "FileNotFoundError": "文件不存在",
        "PermissionError": "权限不足",
        "ZeroDivisionError": "除零错误",
        "OverflowError": "数值溢出",
        "RecursionError": "递归深度超限",
        "MemoryError": "内存不足",
        "StopIteration": "迭代终止",
        "NotImplementedError": "方法未实现",
    }
    

    for name, obj in inspect.getmembers(builtins):
        if isinstance(obj, type) and issubclass(obj, BaseException):
            if name not in core_msg:
                core_msg[name] = None
    return core_msg

err_msg = _generate_err_msg()


UNKNOWN_FILE = Path.home() / ".chinese_error_unknown.json"
LEARNED_FILE = Path.home() / ".chinese_error_learned.json"


def _load_learned_translations():
    if LEARNED_FILE.exists():
        try:
            with open(LEARNED_FILE, 'r', encoding='utf-8') as f:
                learned = json.load(f)
            for name, msg in learned.items():
                if msg and isinstance(msg, str):
                    err_msg[name] = msg
        except:
            pass


def _save_learned_translation(exc_name, chinese_msg):
    learned = {}
    if LEARNED_FILE.exists():
        try:
            with open(LEARNED_FILE, 'r', encoding='utf-8') as f:
                learned = json.load(f)
        except:
            pass
    
    learned[exc_name] = chinese_msg
    
    try:
        with open(LEARNED_FILE, 'w', encoding='utf-8') as f:
            json.dump(learned, f, ensure_ascii=False, indent=2)
        return True
    except:
        return False


def record_unknown_exception(exc_name, exc_msg=None, code_line=None):
    unknown = {}
    if UNKNOWN_FILE.exists():
        try:
            with open(UNKNOWN_FILE, 'r', encoding='utf-8') as f:
                unknown = json.load(f)
        except:
            pass
    
    if exc_name not in unknown:
        unknown[exc_name] = {
            "count": 1,
            "example_msg": str(exc_msg)[:500] if exc_msg else None,
            "example_code": code_line
        }
    else:
        unknown[exc_name]["count"] += 1
    
    try:
        with open(UNKNOWN_FILE, 'w', encoding='utf-8') as f:
            json.dump(unknown, f, ensure_ascii=False, indent=2)
    except:
        pass


_load_learned_translations()


original_hook = sys.excepthook
_switch_status = False
_filter_exceptions = None
_only_deep = False


def get_all_causes(exc):
    causes = []
    seen = set()
    
    cur = exc.__cause__
    while cur and id(cur) not in seen:
        seen.add(id(cur))
        causes.append(cur)
        cur = cur.__cause__
    
    cur = exc.__context__
    while cur and id(cur) not in seen:
        seen.add(id(cur))
        causes.append(cur)
        cur = cur.__context__
    
    return causes


def _should_handle(typ):
    if _filter_exceptions is None:
        return True
    return typ.__name__ in _filter_exceptions


def _deep_check(typ, val):
    if _should_handle(typ):
        return True
    
    cur = val.__cause__
    while cur:
        if type(cur).__name__ in (_filter_exceptions or []):
            return True
        cur = cur.__cause__
    
    cur = val.__context__
    while cur:
        if type(cur).__name__ in (_filter_exceptions or []):
            return True
        cur = cur.__context__
    
    return False


def _extract_variable_name(exc_str):
    match = re.search(r"['\"]([^'\"]+)['\"]", exc_str)
    if match:
        return match.group(1)
    

    match = re.search(r"name '([^']+)'", exc_str)
    if match:
        return match.group(1)
    

    words = exc_str.split()
    keywords = {'name', 'is', 'not', 'defined', 'NameError:'}
    for w in reversed(words):
        if w not in keywords and w.strip("'\"").isidentifier():
            return w.strip("'\"")
    return None


def _get_translation(exc_name, exc_val=None, code_line=None):
    """获取异常翻译（只读内置字典，未知异常自动记录）"""

    if exc_name == "NameError" and exc_val is not None:
        var = _extract_variable_name(str(exc_val))
        if var:
            return f"变量 '{var}' 未定义"
        if exc_name in err_msg and err_msg[exc_name] is not None:
            return err_msg[exc_name]
        return "变量未定义"
    

    if exc_name in err_msg and err_msg[exc_name] is not None:
        return err_msg[exc_name]
    

    record_unknown_exception(exc_name, exc_val, code_line)
    

    if HAS_TCD and _switch_status:
        tcd.warn(f"未知异常: {exc_name}")
        tcd.info(f"已记录到 {UNKNOWN_FILE}")
        tcd.info(f"使用 register_translation('{exc_name}', '中文翻译') 添加翻译")
    
    return exc_name


def custom_handle(typ, val, tb):
    """自定义异常处理主函数"""

    if issubclass(typ, (KeyboardInterrupt, SystemExit)):
        original_hook(typ, val, tb)
        return


    if _filter_exceptions is not None:
        if _only_deep:
            if not _deep_check(typ, val):
                original_hook(typ, val, tb)
                return
        else:
            if not _should_handle(typ):
                original_hook(typ, val, tb)
                return

    try:
        causes = get_all_causes(val)
        if causes:
            tcd.error("======== 链式根源异常 ========")
            for c_exc in reversed(causes):
                c_type = type(c_exc)
                c_name = c_type.__name__
                tip = _get_translation(c_name, c_exc)
                tcd.error(f"根源错误：{tip}")


        tb_info = traceback.extract_tb(tb)
        code_line = None
        if tb_info:
            last = tb_info[-1]
            file = last.filename
            line = last.lineno
            code_line = last.line if last.line else "无代码行"
        else:
            file = "未知"
            line = "未知"
            code_line = None


        exc_name = typ.__name__
        tip = _get_translation(exc_name, val, code_line)


        tcd.error(f"报错原因: {tip}")
        tcd.error(f"文件: {file} 行数: {line}")
        if code_line and code_line != "无代码行":
            tcd.error(f"报错代码：{code_line}\n")
        else:
            print()


        traceback.print_exception(typ, val, tb)

    except Exception:
        original_hook(typ, val, tb)


def enable(quiet=False, only=None, deep=False):
    """
    开启中文报错
    
    Args:
        quiet: 是否静默（不打印提示）
        only: 异常白名单，如 only=["NameError", "TypeError"]
        deep: 是否深度匹配链式异常（任一匹配即拦截）
    """
    global _switch_status, _filter_exceptions, _only_deep
    if not _switch_status:
        sys.excepthook = custom_handle
        _switch_status = True
        _filter_exceptions = only
        _only_deep = deep
        if not quiet:
            msg = "中文报错已开启"
            if HAS_TCD:
                tcd.success(msg)
            else:
                print(f"[SUCCESS] {msg}")


def disable(quiet=False):
    """
    关闭中文报错，恢复英文
    
    Args:
        quiet: 是否静默（不打印提示）
    """
    global _switch_status, _filter_exceptions, _only_deep
    if _switch_status:
        sys.excepthook = original_hook
        _switch_status = False
        _filter_exceptions = None
        _only_deep = False
        if not quiet:
            if HAS_TCD:
                tcd.info("中文报错已关闭，恢复英文报错")
            else:
                print("[INFO] 中文报错已关闭，恢复英文报错")


def is_enabled():
    return _switch_status


def get_unknown_exceptions():
    if UNKNOWN_FILE.exists():
        try:
            with open(UNKNOWN_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}


def clear_unknown_exceptions():
    try:
        if UNKNOWN_FILE.exists():
            UNKNOWN_FILE.unlink()
        return True
    except:
        return False


def register_translation(exc_name, chinese_msg, save_to_file=False):
    """
    手动注册异常翻译
    
    Args:
        exc_name: 异常类名（如 "MyCustomError"）
        chinese_msg: 中文翻译
        save_to_file: 是否永久保存（下次启动自动加载）
    """
    global err_msg
    err_msg[exc_name] = chinese_msg
    
    if save_to_file:
        _save_learned_translation(exc_name, chinese_msg)
    
    if HAS_TCD:
        tcd.success(f"已注册翻译: {exc_name} -> {chinese_msg}")
    else:
        print(f"[SUCCESS] 已注册翻译: {exc_name} -> {chinese_msg}")


def load_custom_translations(filepath):
    """
    从 JSON 文件加载自定义翻译
    
    Args:
        filepath: JSON 文件路径，格式如 {"MyError": "我的错误", "AnotherError": "另一个错误"}
    """
    global err_msg
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            custom = json.load(f)
        count = 0
        for exc_name, chinese_msg in custom.items():
            if chinese_msg:
                err_msg[exc_name] = chinese_msg
                count += 1
        if HAS_TCD:
            tcd.success(f"已加载 {count} 个自定义翻译")
        else:
            print(f"[SUCCESS] 已加载 {count} 个自定义翻译")
        return count
    except FileNotFoundError:
        if HAS_TCD:
            tcd.error(f"文件不存在: {filepath}")
        else:
            print(f"[ERROR] 文件不存在: {filepath}")
        return 0
    except json.JSONDecodeError as e:
        if HAS_TCD:
            tcd.error(f"JSON 解析失败: {e}")
        else:
            print(f"[ERROR] JSON 解析失败: {e}")
        return 0


def get_learned_translations():
    if LEARNED_FILE.exists():
        try:
            with open(LEARNED_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}


def clear_learned_translations():
    try:
        if LEARNED_FILE.exists():
            LEARNED_FILE.unlink()
        return True
    except:
        return False


__all__ = [
    "enable", "disable", "is_enabled",
    "get_unknown_exceptions", "clear_unknown_exceptions",
    "register_translation", "load_custom_translations",
    "get_learned_translations", "clear_learned_translations"
]