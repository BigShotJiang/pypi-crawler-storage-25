from .crap import enable, disable, register_translation, load_custom_translations
from .crap import get_unknown_exceptions, clear_unknown_exceptions
from .crap import get_learned_translations, clear_learned_translations
from .crap import is_enabled

__version__ = "1.3.0"

__all__ = [
    "enable", "disable", "is_enabled",
    "get_unknown_exceptions", "clear_unknown_exceptions",
    "register_translation", "load_custom_translations",
    "get_learned_translations", "clear_learned_translations"
]