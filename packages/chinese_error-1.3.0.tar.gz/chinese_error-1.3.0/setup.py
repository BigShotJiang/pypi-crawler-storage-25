from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="chinese-error",
    version="1.3.0",
    author="shiroko",
    author_email="3207774253@qq.com",
    description="将 Python 错误信息翻译成中文",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/shiroko973/chinese-error",
    packages=find_packages(),
    install_requires=[
        "text-discoloration>=2.0.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    license="MIT",
)