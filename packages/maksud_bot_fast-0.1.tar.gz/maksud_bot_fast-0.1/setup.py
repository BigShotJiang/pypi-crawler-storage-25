from setuptools import setup, find_packages

setup(
    # 'package_name' ki jagah apni library ka naam likho
    name='maksud_bot_fast', 
    
    # Aapka naam aur email
    author='Maksud',
    author_email='maksud@example.com',
    
    # Version 0.1 se shuru karein
    version='0.1',
    
    # Ye line sabse zaruri hai, ye folder dhoondti hai
    packages=find_packages(),
    
    # Library ke baare mein choti si jankari
    description='An example of a python package for generating math tables',
    
    # MIT license sabse common hai
    license='MIT',
    
    # Agar aapki library ko kisi aur library ki zarurat ho (abhi khaali chhor do)
    install_requires=[],
)