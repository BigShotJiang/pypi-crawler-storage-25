[![Documentation](https://img.shields.io/badge/API%20Client%20Docs-0020C2)](https://api-client-d69c16.pages.gitlab.dlr.de/)

# QCI Connect API Client

This is a python package to interact with the [QCI Connect](https://connect.qci.dlr.de/) platform of the [German Aerospace Center (DLR)](https://www.dlr.de/). 
It also allows local testing, deployment, and interaction with the platform's compiler stack. 

## Quick Start

The following steps provide a quick start on how to programmatically interact with the QCI Connect platform:

- Run `pip install qciconnect-client`
- Run `jupyter notebook` and navigate to _./docs/examples/example_remote.ipynb_
