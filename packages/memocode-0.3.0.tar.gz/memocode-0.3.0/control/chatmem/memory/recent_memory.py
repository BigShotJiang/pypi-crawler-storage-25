"""
Recent memory: compressed summaries from past compression events.
Only populated when ContextManager triggers a lazy compression event
(context ≥ 50% of model window). Hot-loaded into every context call.

Segments added by ContextManager._compress_old_turns():
  - Each entry = one compression event's LLM summary (1-3 sentences)
"""

import json
import sqlite3
import time
from typing import Any

from ..token_counter import count_tokens
from ..compressor import Compressor


class RecentMemory:
    """
    Stores LLM-compressed summaries from ContextManager compression events.
    Hot-loaded into every context call.
    Populated lazily (only when context threshold is hit).
    """

    TOKEN_BUDGET = 35_000        # hard cap on total stored recent memory tokens
    INJECT_TOKEN_CAP = 4000      # max tokens injected into context per turn (structured summaries are larger)

    def __init__(
        self,
        db_path: str,
        compressor: Compressor,
        inject_token_cap: int | None = None,
        token_budget: int | None = None,
    ):
        self.db_path = db_path
        self.compressor = compressor
        self._inject_token_cap = inject_token_cap or self.INJECT_TOKEN_CAP
        self._token_budget = token_budget or self.TOKEN_BUDGET
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS recent_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    turn_id INTEGER NOT NULL,
                    content TEXT NOT NULL,
                    original_content TEXT,
                    compression_level INTEGER DEFAULT 1,
                    token_count INTEGER NOT NULL,
                    created_at REAL NOT NULL
                )
            """)
            # Add original_content column if upgrading from old schema
            try:
                conn.execute("ALTER TABLE recent_memory ADD COLUMN original_content TEXT")
            except Exception:
                pass
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_turn ON recent_memory(turn_id)"
            )

    def add(self, turn_id: int, compressed_content: str, original_content: str | None = None):
        """
        Add a compressed summary entry (from a ContextManager compression event).
        original_content: verbatim text before compression (for warm session injection).
        If total exceeds TOKEN_BUDGET, compress oldest entries further.
        """
        tokens = count_tokens(compressed_content)
        now = time.time()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO recent_memory
                   (turn_id, content, original_content, compression_level, token_count, created_at)
                   VALUES (?, ?, ?, 1, ?, ?)""",
                (turn_id, compressed_content, original_content, tokens, now),
            )

        # Safety valve: if somehow over budget, compress oldest segment
        if self.total_tokens() >= self._token_budget:
            self._compress_oldest_segment()

    def total_tokens(self) -> int:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT SUM(token_count) FROM recent_memory"
            ).fetchone()
        return row[0] or 0

    def _compress_oldest_segment(self):
        """
        Compress the oldest 10 entries using LLM extreme summarization.
        Replaces them with a single 1-3 sentence conclusion entry.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM recent_memory ORDER BY turn_id ASC LIMIT 10"
            ).fetchall()

        if not rows:
            return

        combined = "\n".join(r["content"] for r in rows)
        summary = self.compressor.compress_for_session_context(combined)
        summary_tokens = count_tokens(summary)

        ids = [r["id"] for r in rows]
        min_turn = rows[0]["turn_id"]

        with self._conn() as conn:
            conn.execute(
                f"DELETE FROM recent_memory WHERE id IN ({','.join('?' * len(ids))})",
                ids,
            )
            conn.execute(
                """INSERT INTO recent_memory
                   (turn_id, content, compression_level, token_count, created_at)
                   VALUES (?, ?, 2, ?, ?)""",
                (min_turn, summary, summary_tokens, time.time()),
            )

    def get_entries_for_context(self) -> list[str]:
        """Return individual recent memory entries, newest-first, up to INJECT_TOKEN_CAP."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content FROM recent_memory ORDER BY turn_id DESC"
            ).fetchall()
        kept = []
        budget = self._inject_token_cap
        for r in rows:
            tok = count_tokens(r["content"])
            if tok <= budget:
                kept.append(r["content"])
                budget -= tok
            if budget <= 0:
                break
        return list(reversed(kept))

    def get_for_context(self) -> str:
        """
        Return recent memory content for context injection, newest-first up to INJECT_TOKEN_CAP.
        Newest sessions are most relevant, so we prioritise them within the token budget.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content FROM recent_memory ORDER BY turn_id DESC"
            ).fetchall()
        if not rows:
            return ""
        kept = []
        budget = self._inject_token_cap
        for r in rows:
            tok = count_tokens(r["content"])
            if tok <= budget:
                kept.append(r["content"])
                budget -= tok
            if budget <= 0:
                break
        # Restore chronological order for the model
        return "\n".join(reversed(kept))

    def search(self, query: str, top_k: int = 5, min_score: float = 0.0) -> list[str]:
        """
        Search recent memory for entries relevant to the query.
        Returns up to top_k entries sorted by relevance (then recency).
        Supports both Chinese (bigram) and English (word) tokenization.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content, turn_id FROM recent_memory ORDER BY turn_id DESC"
            ).fetchall()
        if not rows:
            return []

        query_lower = query.lower()
        # Hybrid: Chinese bigrams + English words (both always applied)
        tokens: set[str] = set()
        if any('\u4e00' <= c <= '\u9fff' for c in query):
            tokens.update(query_lower[i:i+2] for i in range(len(query_lower) - 1))
        tokens.update(w for w in query_lower.split() if len(w) > 2)
        if not tokens:
            return []

        scored = []
        for row in rows:
            content_lower = row["content"].lower()
            hits = sum(1 for t in tokens if t in content_lower)
            if hits > 0:
                scored.append((hits / len(tokens), row["turn_id"], row["content"]))

        scored.sort(key=lambda x: (-x[0], -x[1]))
        return [content for score, _, content in scored[:top_k] if score >= min_score]

    def remove(self, entry_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM recent_memory WHERE id = ?", (entry_id,))
