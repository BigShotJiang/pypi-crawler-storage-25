"""Core sub-package."""
