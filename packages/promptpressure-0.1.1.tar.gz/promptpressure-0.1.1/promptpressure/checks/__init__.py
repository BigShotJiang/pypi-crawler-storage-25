"""Checks sub-package."""
