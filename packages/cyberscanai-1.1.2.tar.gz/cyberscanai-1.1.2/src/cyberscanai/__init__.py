"""CyberScanAI is an open source AI Agent Tool for Penetration Testing and Network Forensics.

CyberScanAI is a MCP (Model Context Protocol) Server connects LLMs to tools and prompts for intelligent AI analyzing Networks.

Included modules:
    - DNS
    - DHCP
    - ICMP
    - TCP
    - SIP

CLI usage::

    $ cyberscanai [--modules MODULES] [--transport {stdio,http}] [--host HOST] [--port PORT]

Example tool calls from an MCP client::

    analyze_dns_packets("PCAP_Files/dns.cap")
    analyze_tcp_connections("PCAP_Files/tcp-con-lost.pcap")
"""

from .CyberScanAI import main

__all__ = ["main"]