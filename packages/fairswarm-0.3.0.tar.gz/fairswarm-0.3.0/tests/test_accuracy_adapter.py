"""
Tests for the accuracy-function adapters (P1-1).

These verify the contract between FairSwarm's coalition-as-indices
abstraction and a user's "train this set of clients" abstraction.
"""

from __future__ import annotations

import numpy as np
import pytest

from fairswarm import Client
from fairswarm.demographics.distribution import DemographicDistribution
from fairswarm.fitness.fairness import AccuracyFairnessFitness
from fairswarm.integrations import make_accuracy_fn, make_flower_accuracy_fn


def _make_clients(n: int = 8, n_groups: int = 4, seed: int = 0) -> list[Client]:
    rng = np.random.default_rng(seed)
    return [
        Client(
            id=f"c_{i}",
            demographics=rng.dirichlet([1.0] * n_groups),
            dataset_size=100 + i,
        )
        for i in range(n)
    ]


class TestMakeAccuracyFn:
    """make_accuracy_fn passes the coalition's selected clients through
    to the user's train+eval callable.
    """

    def test_passes_only_selected_clients(self) -> None:
        clients = _make_clients(n=10)
        received: list[list[str]] = []

        def train(selected: list[Client]) -> float:
            received.append([c.id for c in selected])
            return 0.85

        accuracy_fn = make_accuracy_fn(train)
        coalition = [3, 7, 1]
        score = accuracy_fn(coalition, clients)

        assert score == 0.85
        assert received == [[clients[3].id, clients[7].id, clients[1].id]]

    def test_returns_float(self) -> None:
        clients = _make_clients(n=5)

        def train(_selected: list[Client]) -> float:
            return 1  # int — adapter must coerce to float

        accuracy_fn = make_accuracy_fn(train)
        result = accuracy_fn([0, 1], clients)
        assert isinstance(result, float)
        assert result == 1.0

    def test_empty_coalition_returns_zero_by_default(self) -> None:
        clients = _make_clients(n=5)
        called: list[int] = []

        def train(selected: list[Client]) -> float:
            called.append(len(selected))
            return 0.99

        accuracy_fn = make_accuracy_fn(train)
        assert accuracy_fn([], clients) == 0.0
        # train_and_evaluate should not be invoked on empty coalition
        assert called == []

    def test_empty_coalition_raises_when_configured(self) -> None:
        clients = _make_clients(n=5)
        accuracy_fn = make_accuracy_fn(lambda s: 1.0, raise_on_empty=True)
        with pytest.raises(ValueError, match="empty coalition"):
            accuracy_fn([], clients)

    def test_works_with_accuracy_fairness_fitness(self) -> None:
        """The whole point: drop-in replacement for the dataset-size proxy."""
        clients = _make_clients(n=8)
        target = DemographicDistribution(values=np.array([0.25, 0.25, 0.25, 0.25]))

        def deterministic_accuracy(selected: list[Client]) -> float:
            # Coalition of 1, 2, 3 → accuracy 0.92; otherwise 0.50.
            ids = sorted(c.id for c in selected)
            return 0.92 if ids == [clients[1].id, clients[2].id, clients[3].id] else 0.50

        fitness = AccuracyFairnessFitness(
            target_distribution=target,
            accuracy_fn=make_accuracy_fn(deterministic_accuracy),
            fairness_weight=0.0,  # fairness off → fitness equals accuracy
        )

        good = fitness.evaluate([1, 2, 3], clients)
        bad = fitness.evaluate([0, 4, 5], clients)
        assert good.value == 0.92
        assert bad.value == 0.50


class TestMakeFlowerAccuracyFn:
    """The Flower factory is a thin wrapper that adds a presence-check."""

    def test_returns_callable(self) -> None:
        accuracy_fn = make_flower_accuracy_fn(
            lambda selected: 0.7, require_flower=False
        )
        assert callable(accuracy_fn)

    def test_delegates_to_user_callable(self) -> None:
        clients = _make_clients(n=5)
        received: list[int] = []

        def fake_flower_run(selected: list[Client]) -> float:
            received.append(len(selected))
            return 0.81

        accuracy_fn = make_flower_accuracy_fn(fake_flower_run, require_flower=False)
        score = accuracy_fn([0, 2, 4], clients)
        assert score == 0.81
        assert received == [3]

    def test_raises_helpful_error_when_flower_missing(self) -> None:
        """If the user installs the slim package and forgets `pip install flwr`,
        the misconfiguration must surface at construction time, not deep in
        the optimizer's inner loop.
        """
        from fairswarm.integrations import flower as flower_module

        # Skip if Flower is actually installed; the negative path can't run.
        if flower_module.FLOWER_AVAILABLE:
            pytest.skip("Flower is installed; cannot exercise the missing-Flower path")

        with pytest.raises(ImportError, match="Flower"):
            make_flower_accuracy_fn(lambda selected: 0.5, require_flower=True)
