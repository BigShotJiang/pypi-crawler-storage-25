"""
Tests for explicit zero-mass KL handling (P1-2).

Verifies:
    1. ``mode="clipped"`` (default) reproduces v0.2.x behavior exactly.
    2. ``mode="laplace"`` produces finite KL on zero-on-non-zero inputs
       and is well-calibrated (different from clipped on those inputs).
    3. ``mode="strict"`` returns ``np.inf`` when q has zero mass on a
       group where p is positive.
    4. ``warn_on_zero_mass=True`` surfaces a UserWarning regardless of mode.
    5. Invalid mode raises ValueError.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).
"""

from __future__ import annotations

import math
import warnings

import numpy as np
import pytest

from fairswarm.demographics.divergence import kl_divergence


class TestModeClippedIsBackwardCompatible:
    """Default behavior must equal pre-P1-2 numerics."""

    def test_default_mode_is_clipped(self) -> None:
        p = np.array([0.4, 0.3, 0.2, 0.1])
        q = np.array([0.25, 0.25, 0.25, 0.25])
        # Both signatures must produce identical output
        assert kl_divergence(p, q) == kl_divergence(p, q, mode="clipped")

    def test_clipped_returns_finite_on_zero_mass(self) -> None:
        """Clipped mode must continue to return a finite (bounded) value."""
        p = np.array([0.5, 0.5, 0.0])
        q = np.array([0.4, 0.3, 0.3])
        v = kl_divergence(p, q, mode="clipped")
        assert math.isfinite(v)

    def test_clipped_zero_for_identical(self) -> None:
        p = np.array([0.25, 0.25, 0.25, 0.25])
        v = kl_divergence(p, p, mode="clipped")
        assert v == pytest.approx(0.0, abs=1e-12)


class TestModeStrict:
    """Strict mode must surface zero-on-non-zero as infinity."""

    def test_strict_returns_inf_when_q_zero_on_p_nonzero(self) -> None:
        """KL(p || q) = +∞ when q has zero mass on a group where p > 0."""
        p = np.array([0.5, 0.5])
        q = np.array([1.0, 0.0])  # q has zero mass on group 1
        assert kl_divergence(p, q, mode="strict") == float("inf")

    def test_strict_finite_when_no_zero_mass(self) -> None:
        p = np.array([0.4, 0.3, 0.2, 0.1])
        q = np.array([0.25, 0.25, 0.25, 0.25])
        v = kl_divergence(p, q, mode="strict")
        assert math.isfinite(v)
        assert v > 0

    def test_strict_does_not_inf_on_p_zero_q_nonzero(self) -> None:
        """KL(p || q) is well-defined when p = 0 (the term contributes 0)."""
        p = np.array([0.0, 0.5, 0.5])
        q = np.array([0.4, 0.3, 0.3])
        v = kl_divergence(p, q, mode="strict")
        assert math.isfinite(v)


class TestModeLaplace:
    """Laplace smoothing produces finite, calibrated KL."""

    def test_laplace_returns_finite_on_zero_mass(self) -> None:
        p = np.array([0.5, 0.5, 0.0])
        q = np.array([0.4, 0.3, 0.3])
        v = kl_divergence(p, q, mode="laplace")
        assert math.isfinite(v)
        assert v > 0

    def test_laplace_differs_from_clipped(self) -> None:
        """The two modes should give different numerics on zero-mass inputs."""
        p = np.array([0.5, 0.5, 0.0])
        q = np.array([0.4, 0.3, 0.3])
        clipped = kl_divergence(p, q, mode="clipped")
        laplace = kl_divergence(p, q, mode="laplace")
        # They are both bounded but should be quantitatively different
        assert clipped != pytest.approx(laplace, abs=0.01)

    def test_laplace_alpha_zero_approximates_no_smoothing(self) -> None:
        """alpha=0 reduces the smoothing to nothing; numerically unstable
        with literal zeros, so we test a non-zero-mass case."""
        p = np.array([0.4, 0.3, 0.2, 0.1])
        q = np.array([0.25, 0.25, 0.25, 0.25])
        with_smoothing = kl_divergence(p, q, mode="laplace", laplace_alpha=1.0)
        no_smoothing = kl_divergence(p, q, mode="laplace", laplace_alpha=0.0)
        # No smoothing (and no zero-mass) should yield the unsmoothed KL
        assert math.isfinite(no_smoothing)
        # And they should differ since smoothing biases toward uniform
        assert with_smoothing != no_smoothing


class TestZeroMassWarning:
    """warn_on_zero_mass surfaces a UserWarning regardless of mode."""

    def test_warns_when_q_has_zero_mass_on_p_nonzero(self) -> None:
        p = np.array([0.5, 0.5])
        q = np.array([1.0, 0.0])
        with pytest.warns(UserWarning, match="zero-on-non-zero"):
            kl_divergence(p, q, mode="clipped", warn_on_zero_mass=True)

    def test_warns_when_p_has_zero_mass_on_q_nonzero(self) -> None:
        p = np.array([1.0, 0.0])
        q = np.array([0.5, 0.5])
        with pytest.warns(UserWarning, match="zero-on-non-zero"):
            kl_divergence(p, q, mode="clipped", warn_on_zero_mass=True)

    def test_no_warn_when_no_zero_mass(self) -> None:
        p = np.array([0.4, 0.3, 0.2, 0.1])
        q = np.array([0.25, 0.25, 0.25, 0.25])
        with warnings.catch_warnings():
            warnings.simplefilter("error", UserWarning)
            kl_divergence(p, q, warn_on_zero_mass=True)

    def test_no_warn_by_default_even_with_zero_mass(self) -> None:
        """Backwards compat: default warn_on_zero_mass=False stays silent."""
        p = np.array([0.5, 0.5])
        q = np.array([1.0, 0.0])
        with warnings.catch_warnings():
            warnings.simplefilter("error", UserWarning)
            kl_divergence(p, q, mode="clipped")  # no warn flag → no warning


class TestInvalidMode:
    def test_unknown_mode_raises(self) -> None:
        p = np.array([0.5, 0.5])
        q = np.array([0.5, 0.5])
        with pytest.raises(ValueError, match="mode must be one of"):
            kl_divergence(p, q, mode="exotic")  # type: ignore[arg-type]
