"""
Tests for the shipped benchmark module (P1-4).

Verifies:
    1. The module is importable as ``fairswarm.benchmarks``.
    2. Each baseline returns a coalition of the right size.
    3. ``run_comparison`` produces results for all four shipped baselines.
    4. FairSwarm beats Random on demographic divergence with seed=42
       (the reference seed for the shipped benchmark).
    5. ``python -m fairswarm.benchmarks`` returns 0 with the default args.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

from fairswarm import Client
from fairswarm.benchmarks import (
    BenchmarkResult,
    fairswarm_baseline,
    oort_baseline,
    random_baseline,
    run_comparison,
    standard_pso_baseline,
)
from fairswarm.demographics.distribution import DemographicDistribution


def _clients(n: int = 20, k: int = 4, seed: int = 0) -> list[Client]:
    rng = np.random.default_rng(seed)
    return [
        Client(
            id=f"c_{i}",
            demographics=rng.dirichlet([1.0] * k),
            dataset_size=200 + int(rng.integers(0, 800)),
        )
        for i in range(n)
    ]


def _target(k: int = 4) -> DemographicDistribution:
    return DemographicDistribution(values=np.full(k, 1.0 / k))


class TestBaselines:
    """Each baseline returns a coalition of the right size."""

    @pytest.mark.parametrize(
        "baseline",
        [random_baseline, oort_baseline, standard_pso_baseline, fairswarm_baseline],
    )
    def test_returns_correct_coalition_size(self, baseline) -> None:
        clients = _clients(n=12)
        target = _target()
        coalition = baseline(clients, coalition_size=5, target=target, seed=1)
        assert len(coalition) == 5
        assert len(set(coalition)) == 5  # no duplicates
        assert all(0 <= i < 12 for i in coalition)

    def test_oort_picks_largest_datasets(self) -> None:
        """Oort-simplified is rank-by-dataset_size, so it should pick
        the m clients with the largest sizes deterministically.
        """
        clients = _clients(n=15, seed=99)
        target = _target()
        coalition = oort_baseline(clients, coalition_size=5, target=target, seed=0)
        # Top-5 by dataset_size should match
        ranked = sorted(
            range(len(clients)), key=lambda i: clients[i].dataset_size, reverse=True
        )
        assert sorted(coalition) == sorted(ranked[:5])


class TestRunComparison:
    """run_comparison runs all four baselines and returns BenchmarkResults."""

    def test_returns_all_four_baselines_by_default(self) -> None:
        results = run_comparison(
            n_clients=10, coalition_size=4, n_trials=2, seed=42
        )
        assert set(results.keys()) == {
            "random", "oort_simplified", "standard_pso", "fairswarm",
        }

    def test_results_are_well_formed(self) -> None:
        results = run_comparison(
            n_clients=10, coalition_size=4, n_trials=2, seed=42
        )
        for name, r in results.items():
            assert isinstance(r, BenchmarkResult)
            assert r.baseline_name == name
            assert r.n_trials == 2
            assert r.mean_demographic_divergence >= 0
            assert r.mean_dataset_size > 0
            assert r.mean_wall_clock_seconds >= 0

    def test_fairswarm_beats_random_on_divergence_at_reference_seed(self) -> None:
        """The empirical claim that justifies the algorithm's existence.

        At seed=42 with the default benchmark configuration, FairSwarm
        must produce strictly lower demographic divergence than random
        selection. If this regresses, either the algorithm is broken or
        the reference seed needs reconsideration.
        """
        results = run_comparison(
            n_clients=20, coalition_size=10, n_trials=5, seed=42
        )
        fairswarm_div = results["fairswarm"].mean_demographic_divergence
        random_div = results["random"].mean_demographic_divergence
        assert fairswarm_div < random_div, (
            f"FairSwarm should beat random on demographic divergence at "
            f"the reference seed; got fairswarm={fairswarm_div:.4f}, "
            f"random={random_div:.4f}"
        )

    def test_fairswarm_beats_standard_pso_on_divergence(self) -> None:
        """The fairness gradient should produce lower divergence than
        standard PSO with the same swarm and iteration budget.
        """
        results = run_comparison(
            n_clients=20, coalition_size=10, n_trials=5, seed=42
        )
        fairswarm_div = results["fairswarm"].mean_demographic_divergence
        pso_div = results["standard_pso"].mean_demographic_divergence
        assert fairswarm_div < pso_div, (
            f"FairSwarm should beat standard PSO on demographic divergence; "
            f"got fairswarm={fairswarm_div:.4f}, standard_pso={pso_div:.4f}"
        )


class TestModuleEntryPoint:
    """python -m fairswarm.benchmarks runs to completion."""

    def test_module_main_returns_zero(self) -> None:
        """Smoke test: the entry point completes without error."""
        # Locate the package on sys.path. When fairswarm is pip-installed
        # the test runs without help; when only on pythonpath via pytest
        # config we need to forward that to the subprocess.
        repo_root = Path(__file__).resolve().parent.parent
        env = os.environ.copy()
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = str(repo_root / "src") + os.pathsep + existing

        result = subprocess.run(
            [
                sys.executable, "-m", "fairswarm.benchmarks",
                "--n-clients", "8",
                "--coalition-size", "3",
                "--n-trials", "2",
            ],
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )
        assert result.returncode == 0, (
            f"benchmark exited with code {result.returncode}; stderr:\n{result.stderr}"
        )
        # The summary table should mention every baseline
        for name in ("random", "oort_simplified", "standard_pso", "fairswarm"):
            assert name in result.stdout, f"{name} missing from output"
