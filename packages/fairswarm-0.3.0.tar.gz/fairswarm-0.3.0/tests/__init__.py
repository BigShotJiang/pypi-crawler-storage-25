"""FairSwarm test suite."""
