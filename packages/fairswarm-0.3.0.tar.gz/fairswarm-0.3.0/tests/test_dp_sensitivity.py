"""
Tests for analytical DP sensitivity (P0-2).

Verifies that ``DemographicFitness.sensitivity(m)`` returns a value that
is (a) a valid upper bound on the *empirical* worst-case single-element
swap delta and (b) tighter than the prior 1.5× empirical-margin
heuristic on representative configurations.

Reference:
    K. M. R. Audenaert, "A sharp continuity estimate for the von
    Neumann entropy," J. Phys. A 40 (2007) 8127.
    Berend & Kontorovich, "On the concentration of the missing mass,"
    Electron. Commun. Probab. 18 (2013), gives the classical-entropy
    proof of the bound used here.
"""

from __future__ import annotations

import itertools
import warnings

import numpy as np
import pytest

from fairswarm import Client
from fairswarm.demographics.distribution import DemographicDistribution
from fairswarm.fitness.fairness import DemographicFitness


def _make_clients(
    n: int,
    n_groups: int = 4,
    seed: int = 0,
    concentration: float = 1.0,
) -> list[Client]:
    """Synthetic clients with Dirichlet-distributed demographics."""
    rng = np.random.default_rng(seed)
    return [
        Client(
            id=f"c_{i}",
            demographics=rng.dirichlet([concentration] * n_groups),
            dataset_size=100 + i,
        )
        for i in range(n)
    ]


def _empirical_max_swap_delta(
    fitness: DemographicFitness,
    clients: list[Client],
    coalition_size: int,
    n_random_pairs: int = 2000,
    seed: int = 7,
) -> float:
    """
    Sample many neighboring coalitions and return the worst observed
    fitness delta. Used to verify the analytical bound.

    For coalition_size m and n clients there are
    C(n, m) * m * (n - m) neighboring pairs. We sample randomly when
    that count is large.
    """
    rng = np.random.default_rng(seed)
    n = len(clients)
    max_diff = 0.0

    for _ in range(n_random_pairs):
        coalition = rng.choice(n, size=coalition_size, replace=False).tolist()
        non_members = [i for i in range(n) if i not in coalition]
        if not non_members:
            continue
        swap_idx = int(rng.choice(coalition_size))
        new_member = int(rng.choice(non_members))
        neighbor = coalition.copy()
        neighbor[swap_idx] = new_member

        f1 = fitness.evaluate(coalition, clients).value
        f2 = fitness.evaluate(neighbor, clients).value
        max_diff = max(max_diff, abs(f1 - f2))
    return max_diff


def _exhaustive_max_swap_delta(
    fitness: DemographicFitness,
    clients: list[Client],
    coalition_size: int,
) -> float:
    """
    Exhaustively enumerate every (coalition, swap, new_member) triple.
    Only feasible for small n; used to obtain the true sensitivity for
    the tightness check.
    """
    n = len(clients)
    max_diff = 0.0
    for coalition in itertools.combinations(range(n), coalition_size):
        coalition_list = list(coalition)
        f_base = fitness.evaluate(coalition_list, clients).value
        non_members = [i for i in range(n) if i not in coalition]
        for swap_pos in range(coalition_size):
            for new_member in non_members:
                neighbor = coalition_list.copy()
                neighbor[swap_pos] = new_member
                f_swap = fitness.evaluate(neighbor, clients).value
                max_diff = max(max_diff, abs(f_base - f_swap))
    return max_diff


class TestDemographicFitnessSensitivity:
    """Analytical sensitivity bound is a valid upper bound on observed deltas."""

    def test_returns_float_for_valid_inputs(self) -> None:
        target = DemographicDistribution(values=np.array([0.4, 0.3, 0.2, 0.1]))
        fitness = DemographicFitness(target_distribution=target)
        bound = fitness.sensitivity(coalition_size=10)
        assert isinstance(bound, float)
        assert bound > 0.0
        assert np.isfinite(bound)

    def test_zero_for_single_group_target(self) -> None:
        """A 1-group target has no demographic divergence to optimize."""
        target = DemographicDistribution(values=np.array([1.0]))
        fitness = DemographicFitness(target_distribution=target)
        assert fitness.sensitivity(coalition_size=5) == 0.0

    def test_decreasing_in_coalition_size(self) -> None:
        """Larger coalitions are less sensitive: Δf scales as O(1/m)."""
        target = DemographicDistribution(values=np.array([0.25, 0.25, 0.25, 0.25]))
        fitness = DemographicFitness(target_distribution=target)
        bounds = [fitness.sensitivity(coalition_size=m) for m in (5, 10, 20, 50)]
        assert all(bounds[i] > bounds[i + 1] for i in range(len(bounds) - 1)), (
            f"sensitivity should decrease with m, got {bounds}"
        )

    def test_grows_with_target_skew(self) -> None:
        """Sharply skewed targets have larger log(1/q_min*) and larger Δf."""
        balanced = DemographicDistribution(values=np.array([0.25, 0.25, 0.25, 0.25]))
        skewed = DemographicDistribution(values=np.array([0.97, 0.01, 0.01, 0.01]))
        b_balanced = DemographicFitness(target_distribution=balanced).sensitivity(10)
        b_skewed = DemographicFitness(target_distribution=skewed).sensitivity(10)
        assert b_skewed > b_balanced

    def test_finite_when_target_has_zero_mass(self) -> None:
        """KL_EPS floor keeps the bound finite even when q* has zeros."""
        target = DemographicDistribution(values=np.array([0.5, 0.5, 0.0, 0.0]))
        fitness = DemographicFitness(target_distribution=target)
        bound = fitness.sensitivity(coalition_size=10)
        assert np.isfinite(bound)
        assert bound > 0.0

    def test_invalid_coalition_size_raises(self) -> None:
        target = DemographicDistribution(values=np.array([0.5, 0.5]))
        fitness = DemographicFitness(target_distribution=target)
        with pytest.raises(ValueError, match="coalition_size must be >= 1"):
            fitness.sensitivity(coalition_size=0)


class TestSensitivityIsValidUpperBound:
    """The analytical bound must dominate every observed swap delta."""

    @pytest.mark.parametrize("coalition_size", [3, 5, 8])
    def test_random_sample_within_bound(self, coalition_size: int) -> None:
        target = DemographicDistribution(values=np.array([0.4, 0.3, 0.2, 0.1]))
        fitness = DemographicFitness(target_distribution=target)
        clients = _make_clients(n=20, n_groups=4, seed=42, concentration=1.0)

        bound = fitness.sensitivity(coalition_size=coalition_size)
        observed = _empirical_max_swap_delta(
            fitness=fitness,
            clients=clients,
            coalition_size=coalition_size,
            n_random_pairs=2000,
        )
        # The bound must dominate the worst observed delta.
        assert bound >= observed, (
            f"analytical bound {bound:.4f} < observed max {observed:.4f}"
        )

    def test_exhaustive_small_case_within_bound(self) -> None:
        """On a small problem, exhaustive search confirms the bound holds."""
        target = DemographicDistribution(values=np.array([0.6, 0.3, 0.1]))
        fitness = DemographicFitness(target_distribution=target)
        clients = _make_clients(n=8, n_groups=3, seed=0, concentration=0.5)
        m = 3

        bound = fitness.sensitivity(coalition_size=m)
        true_sensitivity = _exhaustive_max_swap_delta(
            fitness=fitness, clients=clients, coalition_size=m
        )
        assert bound >= true_sensitivity, (
            f"analytical bound {bound:.4f} violated by true "
            f"sensitivity {true_sensitivity:.4f}"
        )

    def test_extreme_dirichlet_clients_within_bound(self) -> None:
        """Even with very skewed client demographics, the bound still holds."""
        target = DemographicDistribution(values=np.array([0.25, 0.25, 0.25, 0.25]))
        fitness = DemographicFitness(target_distribution=target)
        # concentration=0.05 → near-one-hot client demographics
        clients = _make_clients(n=15, n_groups=4, seed=1, concentration=0.05)
        m = 6

        bound = fitness.sensitivity(coalition_size=m)
        observed = _empirical_max_swap_delta(
            fitness=fitness, clients=clients, coalition_size=m, n_random_pairs=2000
        )
        assert bound >= observed


class TestSensitivityWiringInFairSwarmDP:
    """FairSwarmDP._estimate_sensitivity prefers the analytical bound."""

    def test_prefers_analytical_over_empirical(self) -> None:
        from fairswarm import FairSwarmConfig
        from fairswarm.algorithms.fairswarm_dp import (
            DPConfig,
            FairSwarmDP,
        )

        clients = _make_clients(n=12, n_groups=4, seed=0)
        target = DemographicDistribution(values=np.array([0.25, 0.25, 0.25, 0.25]))
        fitness = DemographicFitness(target_distribution=target)
        cfg = FairSwarmConfig(
            swarm_size=4, max_iterations=2, coalition_size=5, seed=42,
            adaptive_fairness=False,
        )
        dp = DPConfig(epsilon=1.0, delta=1e-5)

        opt = FairSwarmDP(
            clients=clients,
            coalition_size=5,
            config=cfg,
            target_distribution=target,
            dp_config=dp,
            seed=42,
        )
        # No warning should be issued because DemographicFitness has a bound.
        # Suppress unrelated PSO warnings (Theorem 2 T_min advisory).
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            warnings.filterwarnings(
                "error", message="No analytical sensitivity", category=UserWarning
            )
            estimated = opt._estimate_sensitivity(fitness)
        # Should match the analytical bound exactly.
        assert estimated == fitness.sensitivity(coalition_size=5, n_clients=12)

    def test_falls_back_with_warning_for_unbounded_fitness(self) -> None:
        """Custom fitness without sensitivity() triggers empirical + warning."""
        from fairswarm import FairSwarmConfig
        from fairswarm.algorithms.fairswarm_dp import DPConfig, FairSwarmDP
        from fairswarm.fitness.base import FitnessFunction, FitnessResult
        from fairswarm.types import Coalition

        class UnboundedFitness(FitnessFunction):
            """Toy fitness with no analytical sensitivity bound."""

            def evaluate(
                self, coalition: Coalition, clients: list[Client]
            ) -> FitnessResult:
                return FitnessResult(value=float(len(coalition)), coalition=coalition)

            def compute_gradient(
                self, position, clients, coalition_size
            ):
                return np.zeros(len(clients))

        clients = _make_clients(n=10, n_groups=3, seed=0)
        target = DemographicDistribution(values=np.array([0.5, 0.3, 0.2]))
        fitness = UnboundedFitness()
        cfg = FairSwarmConfig(
            swarm_size=4, max_iterations=2, coalition_size=4, seed=42,
            adaptive_fairness=False,
        )
        dp = DPConfig(epsilon=1.0, delta=1e-5)

        opt = FairSwarmDP(
            clients=clients,
            coalition_size=4,
            config=cfg,
            target_distribution=target,
            dp_config=dp,
            seed=42,
        )
        with pytest.warns(UserWarning, match="No analytical sensitivity"):
            estimated = opt._estimate_sensitivity(fitness)
        assert estimated > 0
