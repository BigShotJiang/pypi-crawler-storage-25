"""
Tests for unified drift metric in DigitalTwin (P1-3).

Verifies:
    1. Default ``drift_metric="kl"`` so DigitalTwin's drift score is in
       the same units as ``epsilon_fair`` and matches Definition 2.
    2. ``drift_metric="l2"`` reproduces v0.2.x behavior.
    3. Both metrics return 0 for identical physical and virtual states.
    4. Both metrics return positive drift for divergent states, with
       KL > 0 specifically when distributions truly differ.
    5. Invalid drift_metric raises ValueError at construction time.
    6. The metric override argument works on a per-call basis.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).
"""

from __future__ import annotations

import numpy as np
import pytest

from fairswarm import Client, FairSwarmConfig
from fairswarm.demographics.distribution import DemographicDistribution
from fairswarm.digital_twin.twin import DigitalTwin


def _client(demographics: list[float], cid: str = "c") -> Client:
    return Client(
        id=cid,
        demographics=np.array(demographics, dtype=np.float64),
        dataset_size=100,
    )


def _make_twin(
    physical: list[Client],
    drift_metric: str = "kl",
) -> DigitalTwin:
    target = DemographicDistribution(values=np.array([0.25, 0.25, 0.25, 0.25]))
    cfg = FairSwarmConfig(
        swarm_size=4, max_iterations=2, coalition_size=2, seed=0,
        adaptive_fairness=False,
    )
    return DigitalTwin(
        physical_clients=physical,
        target_distribution=target,
        fairswarm_config=cfg,
        coalition_size=2,
        drift_metric=drift_metric,
    )


class TestDriftMetricDefaults:
    def test_default_is_kl(self) -> None:
        twin = _make_twin([_client([0.4, 0.3, 0.2, 0.1])])
        assert twin.drift_metric == "kl"

    def test_invalid_metric_raises(self) -> None:
        with pytest.raises(ValueError, match="drift_metric"):
            _make_twin([_client([1.0, 0.0, 0.0, 0.0])], drift_metric="cosine")


class TestDriftMetricBehavior:
    def test_zero_drift_for_identical_states(self) -> None:
        clients = [_client([0.4, 0.3, 0.2, 0.1], "x")]
        twin = _make_twin(clients, drift_metric="kl")
        # Initialization copies physical -> virtual; drift should be ~0.
        assert twin._compute_drift() < 1e-6

    def test_kl_drift_positive_when_states_differ(self) -> None:
        twin = _make_twin([_client([0.6, 0.3, 0.1, 0.0])])
        # Manually mutate virtual state to diverge from physical
        twin._virtual_state.clients = [_client([0.1, 0.2, 0.3, 0.4])]
        kl_drift = twin._compute_drift(metric="kl")
        l2_drift = twin._compute_drift(metric="l2")
        assert kl_drift > 0
        assert l2_drift > 0

    def test_l2_metric_matches_legacy_norm(self) -> None:
        """When drift_metric='l2', the result equals the v0.2.x norm."""
        twin = _make_twin([_client([0.6, 0.3, 0.1, 0.0])], drift_metric="l2")
        twin._virtual_state.clients = [_client([0.1, 0.2, 0.3, 0.4])]

        physical_mean = np.array([0.6, 0.3, 0.1, 0.0])
        virtual_mean = np.array([0.1, 0.2, 0.3, 0.4])
        expected = float(np.linalg.norm(physical_mean - virtual_mean))

        assert twin._compute_drift() == pytest.approx(expected, abs=1e-9)

    def test_metric_override_argument(self) -> None:
        """Per-call override is honored over self.drift_metric."""
        twin = _make_twin([_client([0.6, 0.3, 0.1, 0.0])], drift_metric="kl")
        twin._virtual_state.clients = [_client([0.1, 0.2, 0.3, 0.4])]
        kl_via_default = twin._compute_drift()
        l2_via_override = twin._compute_drift(metric="l2")
        # KL and L2 are different metrics on the same input
        assert kl_via_default != pytest.approx(l2_via_override, abs=0.01)

    def test_kl_drift_handles_zero_mass_gracefully(self) -> None:
        """Zero-mass cases shouldn't return inf when using clipped mode."""
        twin = _make_twin([_client([1.0, 0.0, 0.0, 0.0])])
        twin._virtual_state.clients = [_client([0.0, 0.0, 1.0, 0.0])]
        kl_drift = twin._compute_drift(metric="kl")
        assert np.isfinite(kl_drift)
        assert kl_drift > 0

    def test_returns_zero_when_either_state_empty(self) -> None:
        # Edge case: build twin then clear states
        twin = _make_twin([_client([0.4, 0.3, 0.2, 0.1])])
        twin._physical_state.clients = []
        assert twin._compute_drift() == 0.0


class TestDriftAndEpsilonFairConsistency:
    """KL drift must be in the same units as epsilon_fair."""

    def test_kl_drift_units_match_epsilon_fair(self) -> None:
        """The threshold check ``drift > drift_threshold`` is meaningful
        because both sides are in nats (KL units). Sanity check: a small
        drift in the same range as a typical epsilon_fair=0.05 value
        should be detectable.
        """
        # Construct two means that differ by a known KL divergence.
        physical = np.array([0.40, 0.30, 0.20, 0.10])
        virtual = np.array([0.35, 0.30, 0.20, 0.15])  # small shift

        twin = _make_twin(
            [_client(list(physical))],
            drift_metric="kl",
        )
        twin._virtual_state.clients = [_client(list(virtual))]

        kl_drift = twin._compute_drift()
        # Both should be in the same order of magnitude as a small KL value;
        # we assert it's positive and bounded above by an obviously larger
        # KL between very different distributions.
        assert 0 < kl_drift < 1.0
