"""
Tests for parallel particle evaluation (P0-1).

Verifies:
    1. Serial mode is bit-exact with prior versions (covered by the rest
       of the test suite running with default config).
    2. Threads mode is reproducible: same seed → same final fitness
       regardless of ``n_workers``.
    3. Processes mode produces the same result as threads mode for the
       same seed (semantic equivalence between parallel backends).
    4. A CPU-bound fitness function actually benefits from processes.
    5. Config validation rejects bad executor settings.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted). Algorithm 1 specifies the inner per-particle update
    that is parallelized here.
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from fairswarm import Client, FairSwarm, FairSwarmConfig
from fairswarm.core.parallel import (
    ParticleExecutor,
    make_particle_seeds,
)
from fairswarm.demographics.distribution import DemographicDistribution
from fairswarm.fitness.fairness import DemographicFitness


def _make_test_clients(n: int = 16, n_groups: int = 4, seed: int = 7) -> list[Client]:
    """Synthetic Dirichlet-distributed clients for reproducible PSO tests."""
    rng = np.random.default_rng(seed)
    return [
        Client(
            id=f"hospital_{i}",
            demographics=rng.dirichlet([1.0] * n_groups),
            dataset_size=500 + i * 50,
        )
        for i in range(n)
    ]


def _run(executor: str, n_workers: int, seed: int = 42) -> float:
    """Run a small FairSwarm optimization and return final fitness."""
    clients = _make_test_clients()
    target = DemographicDistribution(values=np.array([0.25, 0.25, 0.25, 0.25]))
    config = FairSwarmConfig(
        swarm_size=8,
        max_iterations=20,
        coalition_size=4,
        seed=seed,
        executor=executor,  # type: ignore[arg-type]
        n_workers=n_workers,
        adaptive_fairness=False,
    )
    optimizer = FairSwarm(
        clients=clients,
        coalition_size=4,
        config=config,
        target_distribution=target,
        seed=seed,
    )
    fitness = DemographicFitness(target_distribution=target)
    result = optimizer.optimize(fitness, n_iterations=20)
    optimizer._executor.close()
    return result.fitness


class TestExecutorConfig:
    """Validation of FairSwarmConfig executor/n_workers fields."""

    def test_default_is_serial_single_worker(self) -> None:
        cfg = FairSwarmConfig()
        assert cfg.executor == "serial"
        assert cfg.n_workers == 1

    def test_invalid_executor_raises(self) -> None:
        with pytest.raises(ValueError, match="executor must be one of"):
            FairSwarmConfig(executor="cuda")  # type: ignore[arg-type]

    def test_zero_workers_raises(self) -> None:
        with pytest.raises(ValueError, match="n_workers must be >= 1"):
            FairSwarmConfig(n_workers=0)

    def test_serial_with_multiple_workers_warns(self) -> None:
        with pytest.warns(UserWarning, match="n_workers is ignored"):
            FairSwarmConfig(executor="serial", n_workers=4)


class TestParticleExecutor:
    """Direct tests of the ParticleExecutor wrapper."""

    def test_invalid_mode_raises(self) -> None:
        with pytest.raises(ValueError, match="executor mode must be"):
            ParticleExecutor(mode="cuda")  # type: ignore[arg-type]

    def test_zero_workers_raises(self) -> None:
        with pytest.raises(ValueError, match="n_workers must be >= 1"):
            ParticleExecutor(mode="threads", n_workers=0)

    def test_close_is_idempotent(self) -> None:
        ex = ParticleExecutor(mode="threads", n_workers=2)
        ex.close()
        ex.close()  # second call should be a no-op

    def test_context_manager(self) -> None:
        with ParticleExecutor(mode="threads", n_workers=2) as ex:
            assert ex.mode == "threads"
        # pool should be torn down on exit
        assert ex._pool is None


class TestSeedDerivation:
    """Per-particle seeds must be deterministic given (base_seed, iteration)."""

    def test_same_inputs_same_seeds(self) -> None:
        s1 = make_particle_seeds(base_seed=42, iteration=3, n_particles=10)
        s2 = make_particle_seeds(base_seed=42, iteration=3, n_particles=10)
        assert s1 == s2

    def test_different_iterations_different_seeds(self) -> None:
        s1 = make_particle_seeds(base_seed=42, iteration=3, n_particles=10)
        s2 = make_particle_seeds(base_seed=42, iteration=4, n_particles=10)
        assert s1 != s2

    def test_seeds_are_picklable(self) -> None:
        import pickle

        seeds = make_particle_seeds(base_seed=42, iteration=0, n_particles=5)
        roundtrip = pickle.loads(pickle.dumps(seeds))
        assert seeds == roundtrip


class TestParallelReproducibility:
    """Same seed must produce same final fitness across worker counts."""

    def test_threads_reproducible_across_worker_counts(self) -> None:
        """threads(n=1) == threads(n=2) == threads(n=4) for the same seed."""
        f1 = _run("threads", n_workers=1, seed=123)
        f2 = _run("threads", n_workers=2, seed=123)
        f4 = _run("threads", n_workers=4, seed=123)
        # Allow tiny floating-point drift from non-deterministic NumPy
        # reduction order in BLAS, but final fitness should match closely.
        assert math.isclose(f1, f2, abs_tol=1e-9), f"threads(1)={f1}, threads(2)={f2}"
        assert math.isclose(f1, f4, abs_tol=1e-9), f"threads(1)={f1}, threads(4)={f4}"

    def test_processes_match_threads_same_seed(self) -> None:
        """processes(n=2) == threads(n=2) for the same seed."""
        f_threads = _run("threads", n_workers=2, seed=42)
        f_processes = _run("processes", n_workers=2, seed=42)
        assert math.isclose(
            f_threads, f_processes, abs_tol=1e-9
        ), f"threads={f_threads}, processes={f_processes}"

    def test_threads_different_seed_different_result(self) -> None:
        """Different seeds should produce different optimization trajectories."""
        f1 = _run("threads", n_workers=2, seed=1)
        f2 = _run("threads", n_workers=2, seed=2)
        assert f1 != f2


class TestParallelEndToEnd:
    """Smoke tests that the parallel paths produce sensible optimization results."""

    @pytest.mark.parametrize("executor", ["serial", "threads", "processes"])
    def test_finds_better_than_random(self, executor: str) -> None:
        """All executor modes should improve fitness over swarm initialization."""
        f = _run(executor, n_workers=2, seed=42)
        # DemographicFitness returns -KL divergence, so f should be > -inf
        # and typically > -1.0 for well-balanced synthetic clients
        assert f > -10.0, f"{executor}: implausibly bad fitness {f}"


# Speedup measurement is a benchmark, not a unit test. See
# experiments/bench_parallel.py for measured speedups across
# (executor, n_workers, swarm_size, fitness_difficulty) configurations.
