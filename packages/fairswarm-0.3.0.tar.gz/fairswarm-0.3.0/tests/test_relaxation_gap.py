"""
Tests for the continuous-relaxation gap (P0-3).

The fairness gradient is defined on the soft coalition distribution
δ_soft = Σ_i w_i · δ_i (where w_i ∝ position_i), but the actual coalition
is the hard top-k decode. The "relaxation gap" is the discrepancy
between these two views.

These tests verify two things:
    1. Rank margin γ = position_(m) - position_(m+1) for the global best
       grows over iterations — i.e. the swarm converges to positions
       where the soft and hard decisions agree.
    2. As γ grows, decoded coalitions become *stable* under small
       random perturbations of the position vector.

If the gap stayed constant or grew over iterations, the optimization
would be effectively oscillating; this would be a structural problem
worth flagging in the paper. The empirical observation that γ grows
provides direct evidence that the relaxation is benign.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).
"""

from __future__ import annotations

import numpy as np
import pytest

from fairswarm import Client, FairSwarm, FairSwarmConfig
from fairswarm.core.position import decode_coalition
from fairswarm.demographics.distribution import DemographicDistribution
from fairswarm.fitness.fairness import DemographicFitness


def _rank_margin(position: np.ndarray, m: int) -> float:
    """Return γ = position_(m) - position_(m+1) (sorted descending)."""
    sorted_desc = np.sort(position)[::-1]
    if m >= len(sorted_desc):
        return float(sorted_desc[-1])
    return float(sorted_desc[m - 1] - sorted_desc[m])


def _coalition_stability_under_perturbation(
    position: np.ndarray,
    coalition_size: int,
    perturbation_scale: float = 0.01,
    n_trials: int = 50,
    seed: int = 0,
) -> float:
    """
    Fraction of perturbed positions that decode to the same coalition.

    A stability of 1.0 means the relaxation is locally exact — every
    perturbation within ``perturbation_scale`` produces the same hard
    selection. Values below 1.0 indicate the rank margin is small
    relative to the perturbation size.
    """
    rng = np.random.default_rng(seed)
    base_coalition = set(decode_coalition(position, coalition_size))
    same = 0
    for _ in range(n_trials):
        noise = rng.uniform(-perturbation_scale, perturbation_scale, len(position))
        perturbed = np.clip(position + noise, 0.0, 1.0)
        perturbed_coalition = set(decode_coalition(perturbed, coalition_size))
        if perturbed_coalition == base_coalition:
            same += 1
    return same / n_trials


def _make_clients(n: int = 20, n_groups: int = 4, seed: int = 0) -> list[Client]:
    rng = np.random.default_rng(seed)
    return [
        Client(
            id=f"c_{i}",
            demographics=rng.dirichlet([1.0] * n_groups),
            dataset_size=200 + i * 10,
        )
        for i in range(n)
    ]


class TestRelaxationGap:
    """
    Run a real FairSwarm optimization and measure how the relaxation
    gap evolves over iterations. These are not micro-tests; they take a
    couple of seconds because they need enough iterations for the swarm
    to converge meaningfully.
    """

    def test_rank_margin_grows_over_iterations(self) -> None:
        """γ at the end of optimization should exceed γ at the start."""
        clients = _make_clients(n=20, seed=0)
        target = DemographicDistribution(
            values=np.array([0.25, 0.25, 0.25, 0.25])
        )
        config = FairSwarmConfig(
            swarm_size=20,
            max_iterations=80,
            coalition_size=8,
            seed=42,
            adaptive_fairness=False,
        )
        margins: list[float] = []

        def on_iteration(it: int, swarm, _result) -> None:
            if swarm.g_best is not None:
                margins.append(_rank_margin(swarm.g_best, m=8))

        optimizer = FairSwarm(
            clients=clients,
            coalition_size=8,
            config=config,
            target_distribution=target,
            seed=42,
        )
        fitness = DemographicFitness(target_distribution=target)
        optimizer.optimize(fitness, n_iterations=80, callback=on_iteration)
        optimizer._executor.close()

        assert len(margins) >= 20, "callback should fire each iteration"
        early_mean = float(np.mean(margins[: len(margins) // 4]))
        late_mean = float(np.mean(margins[-len(margins) // 4 :]))
        assert late_mean > early_mean, (
            f"rank margin should grow as swarm converges; "
            f"early mean={early_mean:.4f}, late mean={late_mean:.4f}"
        )

    def test_final_coalition_stable_under_small_perturbation(self) -> None:
        """At convergence, γ should be large enough that small perturbations
        of the global-best position decode to the same coalition.
        """
        clients = _make_clients(n=20, seed=0)
        target = DemographicDistribution(
            values=np.array([0.25, 0.25, 0.25, 0.25])
        )
        config = FairSwarmConfig(
            swarm_size=20,
            max_iterations=80,
            coalition_size=8,
            seed=42,
            adaptive_fairness=False,
        )
        optimizer = FairSwarm(
            clients=clients,
            coalition_size=8,
            config=config,
            target_distribution=target,
            seed=42,
        )
        fitness = DemographicFitness(target_distribution=target)
        result = optimizer.optimize(fitness, n_iterations=80)
        optimizer._executor.close()

        stability = _coalition_stability_under_perturbation(
            position=result.position,
            coalition_size=8,
            perturbation_scale=0.01,
            n_trials=100,
            seed=7,
        )
        # At convergence the relaxation should be locally exact for
        # any reasonably small perturbation.
        assert stability >= 0.95, (
            f"converged coalition should be stable under tiny perturbations, "
            f"got stability={stability:.2f}"
        )


class TestRelaxationGapHelpers:
    """Direct tests of the diagnostic helpers themselves."""

    def test_rank_margin_well_separated(self) -> None:
        # Top-2 entries are 0.9, 0.8; rest are 0.1; γ for m=2 is 0.7.
        position = np.array([0.9, 0.8, 0.1, 0.1, 0.1])
        assert _rank_margin(position, m=2) == pytest.approx(0.7)

    def test_rank_margin_no_separation(self) -> None:
        position = np.array([0.5, 0.5, 0.5, 0.5])
        assert _rank_margin(position, m=2) == pytest.approx(0.0)

    def test_stability_full_under_zero_perturbation(self) -> None:
        position = np.array([0.9, 0.8, 0.1, 0.05, 0.05])
        stab = _coalition_stability_under_perturbation(
            position=position, coalition_size=2, perturbation_scale=0.0,
            n_trials=20,
        )
        assert stab == 1.0

    def test_stability_drops_under_large_perturbation(self) -> None:
        # Tight margins → large perturbations should flip the coalition.
        position = np.array([0.51, 0.50, 0.49, 0.48])
        stab = _coalition_stability_under_perturbation(
            position=position, coalition_size=2, perturbation_scale=0.1,
            n_trials=200, seed=0,
        )
        assert stab < 1.0
