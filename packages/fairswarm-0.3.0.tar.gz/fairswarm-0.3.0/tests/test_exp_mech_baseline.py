"""
Test for the ExponentialMechanism coalition-selection baseline (P2-1).

Verifies the experiment script runs end-to-end on a small problem and
produces sensible output. Full benchmark numbers come from running the
script with paper-scale parameters; this is just a smoke test.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def test_exp_mech_baseline_script_runs() -> None:
    """End-to-end smoke test of experiments/exp_mech_baseline.py."""
    repo_root = Path(__file__).resolve().parent.parent
    env = os.environ.copy()
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(repo_root / "src") + os.pathsep + existing

    result = subprocess.run(
        [
            sys.executable,
            str(repo_root / "experiments" / "exp_mech_baseline.py"),
            "--n-clients", "8",
            "--coalition-size", "3",
            "--n-trials", "2",
            "--epsilon", "1.0",
            "--output-dir", "results/exp_mech_test",
        ],
        capture_output=True,
        text=True,
        timeout=120,
        env=env,
        cwd=str(repo_root),
    )
    assert result.returncode == 0, (
        f"experiment script exited {result.returncode}; stderr:\n{result.stderr}"
    )
    # Both methods should appear in the output table
    assert "exponential_mechanism" in result.stdout
    assert "fairswarm_dp" in result.stdout
