"""
Ground-truth Shapley value test (P2-3).

The reviewer's *Overall Assessment* claimed StratifiedShapley's
``/n`` normalization was a double-divide bug. The math is actually
correct — the ``/n`` is the position-weight in the random-permutation
formula, not a redundant averaging step — but the absence of a
canonical-game ground-truth test made the claim plausible. This file
makes the claim impossible to revisit by checking all three Shapley
implementations against analytical values for the standard 3-player
glove game::

    Players: L = {1, 2} (left gloves), R = {3} (right gloves)
    Value:   v(S) = min(|S ∩ L|, |S ∩ R|)

By symmetry of the two left players and the value function, this game
has the closed-form Shapley values::

    φ_1 = 1/6,  φ_2 = 1/6,  φ_3 = 4/6

(Computed by enumerating the 6 permutations of {1, 2, 3} and averaging
each player's marginal contribution; verified against any standard
cooperative-game-theory reference.)

Reference:
    Shapley, "A value for n-person games" (1953).
    Roth, "The Shapley Value: Essays in Honor of Lloyd S. Shapley" (1988).

    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).
"""

from __future__ import annotations

import numpy as np
import pytest

from fairswarm.core.client import Client
from fairswarm.incentives.shapley import (
    ExactShapley,
    MonteCarloShapley,
    StratifiedShapley,
)


# Glove game: players 0 and 1 are left gloves, player 2 is the right glove.
LEFT_GLOVES: set[int] = {0, 1}
RIGHT_GLOVES: set[int] = {2}


def glove_value(coalition: list[int], _clients: list[Client]) -> float:
    """v(S) = min(|S ∩ L|, |S ∩ R|)."""
    s = set(coalition)
    return float(min(len(s & LEFT_GLOVES), len(s & RIGHT_GLOVES)))


def _make_three_players() -> list[Client]:
    """Three throwaway clients; only their indices matter to glove_value."""
    return [
        Client(
            id=f"p{i}",
            demographics=np.array([1.0, 0.0, 0.0, 0.0]),
            dataset_size=100,
        )
        for i in range(3)
    ]


# Analytical ground truth from manual enumeration of 6 permutations.
EXPECTED = np.array([1 / 6, 1 / 6, 4 / 6])


class TestShapleyGroundTruth:
    """All three Shapley implementations must converge to the closed form."""

    def test_exact_shapley_matches_closed_form(self) -> None:
        clients = _make_three_players()
        result = ExactShapley().compute(
            coalition=[0, 1, 2], clients=clients, value_fn=glove_value
        )
        np.testing.assert_allclose(result.values, EXPECTED, atol=1e-10)

    def test_exact_shapley_satisfies_efficiency(self) -> None:
        """Sum of Shapley values = v(N) (efficiency axiom)."""
        clients = _make_three_players()
        result = ExactShapley().compute(
            coalition=[0, 1, 2], clients=clients, value_fn=glove_value
        )
        assert sum(result.values) == pytest.approx(1.0, abs=1e-10)

    def test_monte_carlo_shapley_converges_to_closed_form(self) -> None:
        """Sufficient samples → Monte Carlo estimate is close to truth."""
        clients = _make_three_players()
        result = MonteCarloShapley(n_samples=10000, seed=0).compute(
            coalition=[0, 1, 2], clients=clients, value_fn=glove_value
        )
        np.testing.assert_allclose(result.values, EXPECTED, atol=0.02)

    def test_stratified_shapley_converges_to_closed_form(self) -> None:
        """The reviewer's contested implementation must hit the same answer."""
        clients = _make_three_players()
        result = StratifiedShapley(samples_per_stratum=2000, seed=0).compute(
            coalition=[0, 1, 2], clients=clients, value_fn=glove_value
        )
        np.testing.assert_allclose(result.values, EXPECTED, atol=0.02)

    def test_left_gloves_have_equal_shapley_by_symmetry(self) -> None:
        """The symmetry axiom: players with identical contribution profiles
        get identical Shapley values.
        """
        clients = _make_three_players()
        result = ExactShapley().compute(
            coalition=[0, 1, 2], clients=clients, value_fn=glove_value
        )
        assert result.values[0] == pytest.approx(result.values[1], abs=1e-12)


class TestShapleyAdditiveGame:
    """Sanity-check: in an additive game, Shapley value of player i is v({i})."""

    def test_exact_shapley_additive(self) -> None:
        def v(coalition: list[int], _clients: list[Client]) -> float:
            return float(sum(idx + 1 for idx in coalition))  # v({i}) = i+1

        clients = _make_three_players()
        result = ExactShapley().compute(
            coalition=[0, 1, 2], clients=clients, value_fn=v
        )
        # In an additive game, φ_i = v({i}) = i + 1
        np.testing.assert_allclose(result.values, [1.0, 2.0, 3.0], atol=1e-10)

    def test_stratified_shapley_additive(self) -> None:
        def v(coalition: list[int], _clients: list[Client]) -> float:
            return float(sum(idx + 1 for idx in coalition))

        clients = _make_three_players()
        result = StratifiedShapley(samples_per_stratum=500, seed=0).compute(
            coalition=[0, 1, 2], clients=clients, value_fn=v
        )
        np.testing.assert_allclose(result.values, [1.0, 2.0, 3.0], atol=1e-10)
