"""
Parallel execution backends for FairSwarm particle updates.

Particle updates within a PSO iteration are mutually independent: each
particle reads a snapshot of the global best (frozen for the iteration)
and updates only its own position, velocity, and personal best. This
makes the inner loop embarrassingly parallel.

Backends:
    - ``serial``: in-process loop (default; reference behavior).
    - ``threads``: ``ThreadPoolExecutor``. Useful when fitness evaluation
      releases the GIL (NumPy-heavy linear algebra, BLAS) or is I/O-bound
      (network calls to a federated training round, disk reads).
    - ``processes``: ``ProcessPoolExecutor``. Required when fitness
      evaluation is pure-Python CPU-bound. ``Client`` instances and the
      ``FitnessFunction`` must be picklable; closures over notebook
      locals will fail to ship across the process boundary.

Reproducibility:
    Parallel modes use per-particle ``np.random.SeedSequence`` children
    so the random stream consumed by each particle update at each
    iteration is deterministic regardless of worker count or scheduling.
    The ``serial`` backend continues to draw from the optimizer's master
    RNG to preserve bit-exact behavior with prior versions.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted). Algorithm 1 specifies the inner per-particle update.

Author: Tenicka Norwood
"""

from __future__ import annotations

import logging
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from fairswarm.core.client import Client
    from fairswarm.core.particle import Particle
    from fairswarm.demographics.distribution import DemographicDistribution
    from fairswarm.fitness.base import FitnessFunction

logger = logging.getLogger(__name__)

ExecutorMode = Literal["serial", "threads", "processes"]
VALID_EXECUTOR_MODES: tuple[str, ...] = ("serial", "threads", "processes")


@dataclass
class ParticleUpdateContext:
    """
    Snapshot of all state needed to update one particle at one iteration.

    Bundling everything into one dataclass serves two purposes:
        1. Process workers receive a single picklable object per task.
        2. Thread workers get a frozen snapshot, so any concurrent
           mutation of optimizer state does not affect in-flight updates.

    The g_best snapshot is taken once per iteration in the main thread,
    before any particle update fires. Since gBest is only updated
    *between* iterations (after every particle finishes), this is safe.
    """

    # Static per-iteration shared state
    g_best: NDArray[np.float64] | None
    coalition_size: int
    n_clients: int

    # PSO hyperparameters (snapshot of effective values for this iteration)
    inertia: float
    cognitive: float
    social: float
    velocity_max: float
    effective_fairness_coeff: float

    # Fairness gradient inputs
    target_distribution: DemographicDistribution | None
    clients: list[Client]
    fitness_fn: FitnessFunction

    # Per-particle randomness seed (parallel modes); ignored by serial
    particle_seed: tuple[int, ...]


def update_particle_in_place(
    particle: Particle,
    ctx: ParticleUpdateContext,
    rng: np.random.Generator | None = None,
) -> Particle:
    """
    Apply one FairSwarm velocity-position-fitness update to a particle.

    This is a module-level function (not a method) so it can be pickled
    and shipped to a process worker. It mutates ``particle`` and also
    returns it so the result can be reassembled by the main process when
    using ``ProcessPoolExecutor``.

    Args:
        particle: Particle to update (mutated in place).
        ctx: Frozen iteration context.
        rng: Optional generator. If ``None``, one is constructed from
            ``ctx.particle_seed`` (the parallel-safe path).

    Returns:
        The (mutated) particle.
    """
    # Lazy imports avoid a circular import at module load time. The
    # particle/fitness modules also import from core.parallel via the
    # FairSwarm optimizer, and importing them at module scope would
    # introduce a cycle when this module is first loaded.
    from fairswarm.fitness.fairness import compute_fairness_gradient

    if rng is None:
        rng = np.random.default_rng(np.random.SeedSequence(ctx.particle_seed))

    # Compute fairness gradient (NOVEL contribution)
    if ctx.target_distribution is not None:
        gradient_result = compute_fairness_gradient(
            position=particle.position,
            clients=ctx.clients,
            target_distribution=ctx.target_distribution,
            coalition_size=ctx.coalition_size,
        )
        fairness_gradient = gradient_result.gradient
    else:
        fairness_gradient = np.zeros(ctx.n_clients)

    # Velocity update (Algorithm 1: Lines 554-567)
    particle.apply_velocity_update(
        inertia=ctx.inertia,
        cognitive=ctx.cognitive,
        social=ctx.social,
        fairness_coeff=ctx.effective_fairness_coeff,
        g_best=ctx.g_best,
        fairness_gradient=fairness_gradient,
        velocity_max=ctx.velocity_max,
        rng=rng,
    )

    # Position update (Algorithm 1: Lines 569-571)
    particle.apply_position_update()

    # Decode coalition (Algorithm 1: S_p ← SelectTop(x_p, m))
    coalition = particle.decode(ctx.coalition_size)

    # Evaluate fitness
    result = ctx.fitness_fn.evaluate(coalition, ctx.clients)

    # Update personal best (Algorithm 1: If fit_p > pBestFit_p)
    particle.update_personal_best(result.value, coalition)

    return particle


class ParticleExecutor:
    """
    Pluggable executor for parallel particle updates.

    Lifetime is tied to the optimizer: a single executor is created in
    ``FairSwarm.__init__`` and reused across iterations. Process and
    thread pools are lazily initialized on first ``map`` and torn down
    by ``close()``.

    Example:
        >>> ex = ParticleExecutor(mode="threads", n_workers=4)
        >>> updated = ex.map(update_particle_in_place, particles, contexts)
        >>> ex.close()

    The ``map`` signature mirrors ``concurrent.futures.Executor.map`` but
    accepts the canonical FairSwarm two-argument worker. Workers always
    receive ``(particle, context)`` pairs.
    """

    def __init__(self, mode: ExecutorMode = "serial", n_workers: int = 1):
        if mode not in VALID_EXECUTOR_MODES:
            raise ValueError(
                f"executor mode must be one of {VALID_EXECUTOR_MODES}, "
                f"got {mode!r}"
            )
        if n_workers < 1:
            raise ValueError(f"n_workers must be >= 1, got {n_workers}")

        self.mode: ExecutorMode = mode
        self.n_workers = n_workers
        self._pool: ThreadPoolExecutor | ProcessPoolExecutor | None = None

    def _ensure_pool(self) -> ThreadPoolExecutor | ProcessPoolExecutor:
        """Create the underlying pool on first use."""
        if self._pool is None:
            if self.mode == "threads":
                self._pool = ThreadPoolExecutor(max_workers=self.n_workers)
            elif self.mode == "processes":
                self._pool = ProcessPoolExecutor(max_workers=self.n_workers)
            else:
                raise RuntimeError(
                    "_ensure_pool called for serial mode (programming error)"
                )
        return self._pool

    def map(
        self,
        worker_fn: Any,
        particles: list[Particle],
        contexts: list[ParticleUpdateContext],
        rngs: list[np.random.Generator] | None = None,
    ) -> list[Particle]:
        """
        Apply ``worker_fn(particle, context)`` to each (particle, context)
        pair, returning the updated particles in input order.

        Args:
            worker_fn: Callable; must be picklable for ``processes`` mode.
            particles: Particles to update.
            contexts: Per-particle iteration contexts (same length).
            rngs: Optional per-particle generators. If supplied, the
                ``serial`` and ``threads`` paths use them directly. The
                ``processes`` path always derives RNGs in the worker
                from ``ctx.particle_seed`` because ``Generator`` objects
                cannot be reliably pickled across worker spawn methods.

        Returns:
            List of updated particles in the same order as ``particles``.
        """
        if len(particles) != len(contexts):
            raise ValueError(
                f"particles and contexts must have equal length, "
                f"got {len(particles)} and {len(contexts)}"
            )

        if self.mode == "serial":
            # Sequential reference path. Backward compatible: when rngs
            # is None we leave RNG construction to the worker (which
            # falls back to ctx.particle_seed). When the optimizer
            # passes a master rng for legacy serial behavior, it
            # supplies it via the rngs list (length == n_particles,
            # all entries point at the same generator).
            if rngs is not None:
                return [
                    worker_fn(p, c, rng) for p, c, rng in zip(particles, contexts, rngs)
                ]
            return [worker_fn(p, c) for p, c in zip(particles, contexts)]

        if self.mode == "threads":
            # In-memory; workers mutate the same particle instances.
            # Per-particle RNGs are constructed from particle_seed
            # inside the worker for determinism across thread counts.
            pool = self._ensure_pool()
            futures = [
                pool.submit(worker_fn, p, c) for p, c in zip(particles, contexts)
            ]
            return [f.result() for f in futures]

        if self.mode == "processes":
            # Workers operate on pickled copies; we must collect the
            # returned particles and reassign their state into the
            # original list so the caller sees the updates.
            pool = self._ensure_pool()
            futures = [
                pool.submit(worker_fn, p, c) for p, c in zip(particles, contexts)
            ]
            updated = [f.result() for f in futures]
            for original, new in zip(particles, updated):
                original.position = new.position
                original.velocity = new.velocity
                original.p_best = new.p_best
                original.p_best_fitness = new.p_best_fitness
                original.p_best_coalition = new.p_best_coalition
            return particles

        raise RuntimeError(f"unreachable: unknown mode {self.mode!r}")

    def close(self) -> None:
        """Tear down the underlying pool, if any."""
        if self._pool is not None:
            self._pool.shutdown(wait=True)
            self._pool = None

    def __enter__(self) -> ParticleExecutor:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


def make_particle_seeds(
    base_seed: int | None,
    iteration: int,
    n_particles: int,
) -> list[tuple[int, ...]]:
    """
    Derive deterministic per-particle seed sequences for one iteration.

    Uses ``np.random.SeedSequence.spawn`` so each (base_seed, iteration,
    particle_index) triple maps to an independent random stream. The
    returned tuples are picklable (they contain only Python ints) and
    can be passed across process boundaries.

    Args:
        base_seed: Master seed for the optimizer (None → random).
        iteration: Current PSO iteration index.
        n_particles: Number of particles in the swarm.

    Returns:
        List of seed-state tuples, one per particle, suitable for
        ``np.random.SeedSequence(t)`` reconstruction in a worker.
    """
    # Mix base_seed and iteration into a stable parent seed sequence.
    # When base_seed is None we use a fresh entropy pool so that
    # repeated runs without a seed remain independent.
    if base_seed is None:
        parent = np.random.SeedSequence()
    else:
        parent = np.random.SeedSequence([int(base_seed), int(iteration)])

    children = parent.spawn(n_particles)
    # Serialize each child as a 4-uint32 state vector. ``generate_state``
    # is deterministic and platform-independent, so the tuples reconstruct
    # the same SeedSequence in any worker via ``SeedSequence(list(t))``.
    return [tuple(int(x) for x in child.generate_state(4)) for child in children]
