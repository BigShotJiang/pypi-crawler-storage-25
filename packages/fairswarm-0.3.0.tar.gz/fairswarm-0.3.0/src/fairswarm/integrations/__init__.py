"""
FairSwarm integrations with federated learning frameworks.

This module provides integration with popular FL frameworks:
- Flower (FairSwarmStrategy)
- Future: TensorFlow Federated, PySyft

Author: Tenicka Norwood
"""

from fairswarm.integrations.accuracy import (
    AccuracyFn,
    make_accuracy_fn,
)
from fairswarm.integrations.flower import (
    FairSwarmClient,
    FairSwarmEvaluateConfig,
    FairSwarmFitConfig,
    FairSwarmStrategy,
    make_flower_accuracy_fn,
)

__all__ = [
    "FairSwarmStrategy",
    "FairSwarmClient",
    "FairSwarmFitConfig",
    "FairSwarmEvaluateConfig",
    # Accuracy adapters (P1-1)
    "AccuracyFn",
    "make_accuracy_fn",
    "make_flower_accuracy_fn",
]
