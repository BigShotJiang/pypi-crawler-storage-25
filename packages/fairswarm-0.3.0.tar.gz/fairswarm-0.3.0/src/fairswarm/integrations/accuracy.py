"""
Accuracy-function adapters for AccuracyFairnessFitness (P1-1).

``AccuracyFairnessFitness`` accepts a callable
``accuracy_fn(coalition, clients) -> float`` so callers can plug in a
real federated-training round in place of the dataset-size proxy. This
module provides framework-neutral adapters that turn user-supplied
"train and evaluate" callables into the right shape:

    * ``make_accuracy_fn``: wraps any callable that takes a list of
      coalition members and returns a float metric. Works with sklearn,
      PyTorch, TensorFlow, or anything else.

    * ``make_flower_accuracy_fn`` (in ``fairswarm.integrations.flower``):
      narrower convenience for Flower simulations; raises if Flower is
      not installed.

The adapters are deliberately thin. The expensive work — model
construction, training, evaluation, dataset partitioning — stays in
user code where domain knowledge lives. The library only mediates
between FairSwarm's "coalition is a list of indices" abstraction and
the user's "train this set of participants" abstraction.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).

Author: Tenicka Norwood
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fairswarm.core.client import Client
    from fairswarm.types import Coalition


AccuracyFn = Callable[["Coalition", list["Client"]], float]


def make_accuracy_fn(
    train_and_evaluate: Callable[[list["Client"]], float],
    *,
    raise_on_empty: bool = False,
) -> AccuracyFn:
    """
    Wrap a "train and evaluate" callable as an FairSwarm accuracy_fn.

    The supplied ``train_and_evaluate(selected_clients)`` is invoked
    once per fitness evaluation, receiving only the clients selected
    by the coalition. It must return a single scalar accuracy/quality
    score in [0, 1] (or any range, but FairSwarm's existing
    AccuracyFairnessFitness assumes higher = better).

    Args:
        train_and_evaluate: Callable that takes a list of selected
            clients (subset of the full client list) and returns a
            float metric. Typically this kicks off one or more rounds
            of federated training and evaluates on a held-out set.
        raise_on_empty: If True, an empty coalition raises ValueError
            instead of returning 0.0.

    Returns:
        A callable suitable for ``AccuracyFairnessFitness(accuracy_fn=…)``.

    Example with sklearn::

        from sklearn.linear_model import LogisticRegression

        def train(selected):
            X = np.vstack([c.X for c in selected])
            y = np.concatenate([c.y for c in selected])
            model = LogisticRegression().fit(X, y)
            return model.score(X_holdout, y_holdout)

        accuracy_fn = make_accuracy_fn(train)
        fitness = AccuracyFairnessFitness(
            target_distribution=target,
            accuracy_fn=accuracy_fn,
            fairness_weight=0.3,
        )

    Example with Flower::

        def run_one_round(selected):
            sim = fl.simulation.start_simulation(
                client_fn=lambda cid: client_factory(selected, cid),
                num_clients=len(selected),
                config=fl.server.ServerConfig(num_rounds=1),
                strategy=FedAvg(),
            )
            return sim.metrics_distributed["accuracy"][-1][1]

        accuracy_fn = make_accuracy_fn(run_one_round)
    """

    def accuracy_fn(coalition: "Coalition", clients: list["Client"]) -> float:
        if not coalition:
            if raise_on_empty:
                raise ValueError("Cannot evaluate accuracy on empty coalition")
            return 0.0
        selected = [clients[i] for i in coalition]
        return float(train_and_evaluate(selected))

    return accuracy_fn
