"""
FairSwarm benchmarks (P1-4).

Provides reproducible comparisons against standard coalition-selection
baselines on synthetic Dirichlet-distributed clients. The module ships
inside the wheel so practitioners can verify the paper's empirical
claims with a single command::

    pip install fairswarm
    python -m fairswarm.benchmarks

All baselines are pure-synthetic. The package contains no clinical data
and no PhysioNet artifacts. Users who want to reproduce the paper's
MIMIC numbers must independently obtain credentialed PhysioNet access
and supply their own data via the experiment scripts under
``experiments/``.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).

Author: Tenicka Norwood
"""

from fairswarm.benchmarks.comparison import (
    BenchmarkResult,
    SelectionBaseline,
    fairswarm_baseline,
    oort_baseline,
    random_baseline,
    run_comparison,
    standard_pso_baseline,
)

__all__ = [
    "BenchmarkResult",
    "SelectionBaseline",
    "run_comparison",
    "fairswarm_baseline",
    "oort_baseline",
    "random_baseline",
    "standard_pso_baseline",
]
