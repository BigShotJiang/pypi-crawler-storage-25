"""
``python -m fairswarm.benchmarks`` entry point.

Runs the default benchmark comparison and prints a summary table.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).
"""

from __future__ import annotations

import argparse

from fairswarm.benchmarks.comparison import (
    format_comparison_table,
    run_comparison,
)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="FairSwarm coalition-selection benchmark comparison"
    )
    parser.add_argument("--n-clients", type=int, default=20)
    parser.add_argument("--coalition-size", type=int, default=10)
    parser.add_argument("--n-groups", type=int, default=4)
    parser.add_argument("--n-trials", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    print(
        f"FairSwarm benchmark: n_clients={args.n_clients}, "
        f"coalition_size={args.coalition_size}, n_groups={args.n_groups}, "
        f"n_trials={args.n_trials}, seed={args.seed}\n"
    )
    results = run_comparison(
        n_clients=args.n_clients,
        coalition_size=args.coalition_size,
        n_groups=args.n_groups,
        n_trials=args.n_trials,
        seed=args.seed,
    )
    print(format_comparison_table(results))


if __name__ == "__main__":
    main()
