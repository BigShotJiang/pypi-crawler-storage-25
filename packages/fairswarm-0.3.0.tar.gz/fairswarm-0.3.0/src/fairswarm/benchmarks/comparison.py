"""
Coalition-selection baselines and comparison runner (P1-4).

Baselines
---------
* ``random_baseline``: uniform-random selection of m clients. Hard-floor
  comparison; any reasonable selector should beat random on demographic
  divergence.
* ``oort_baseline``: utility-based greedy selection (clients ranked by
  ``dataset_size``). Simplified Oort-style baseline; the full Oort
  algorithm uses a richer utility function but the ranking-by-utility
  shape is preserved.
* ``standard_pso_baseline``: FairSwarm with the fairness gradient and
  fairness weight set to zero. Equivalent to standard PSO operating on
  the same continuous relaxation as FairSwarm; isolates the contribution
  of the fairness gradient.
* ``fairswarm_baseline``: the full FairSwarm algorithm (Algorithm 1).

Each baseline is a callable returning a list of client indices.

Reference:
    T. Norwood, D. Das, P. Chatterjee, E. Bentley, and U. Ghosh,
    "FairSwarm: Trustworthy Coalition Selection for Fair and Secure
    Federated Intelligence," IEEE Trans. Consum. Electron., 2026
    (Submitted).

Author: Tenicka Norwood
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from fairswarm.core.client import Client
    from fairswarm.demographics.distribution import DemographicDistribution

# Public type alias: any callable taking (clients, coalition_size, target,
# seed) -> coalition is a baseline.
SelectionBaseline = Callable[
    [list["Client"], int, "DemographicDistribution", int],
    list[int],
]


@dataclass
class BenchmarkResult:
    """
    One row of the benchmark comparison table.

    Each baseline produces a (mean, std) over ``n_trials`` for each
    metric. ``coalition_examples`` carries the actual selected
    coalition from the first trial for sanity-checking.
    """

    baseline_name: str
    n_trials: int
    mean_demographic_divergence: float
    std_demographic_divergence: float
    mean_dataset_size: float
    std_dataset_size: float
    mean_wall_clock_seconds: float
    std_wall_clock_seconds: float
    coalition_examples: list[list[int]] = field(default_factory=list)

    def as_dict(self) -> dict[str, object]:
        return {
            "baseline_name": self.baseline_name,
            "n_trials": self.n_trials,
            "mean_demographic_divergence": self.mean_demographic_divergence,
            "std_demographic_divergence": self.std_demographic_divergence,
            "mean_dataset_size": self.mean_dataset_size,
            "std_dataset_size": self.std_dataset_size,
            "mean_wall_clock_seconds": self.mean_wall_clock_seconds,
            "std_wall_clock_seconds": self.std_wall_clock_seconds,
            "coalition_examples": self.coalition_examples,
        }


# ---------------------------------------------------------------------------
# Baselines
# ---------------------------------------------------------------------------


def random_baseline(
    clients: list["Client"],
    coalition_size: int,
    target: "DemographicDistribution",  # noqa: ARG001 — interface conformance
    seed: int = 0,
) -> list[int]:
    """Uniform-random selection without replacement."""
    rng = np.random.default_rng(seed)
    return rng.choice(len(clients), size=coalition_size, replace=False).tolist()


def oort_baseline(
    clients: list["Client"],
    coalition_size: int,
    target: "DemographicDistribution",  # noqa: ARG001 — utility-only
    seed: int = 0,  # noqa: ARG001 — deterministic given clients
) -> list[int]:
    """
    Simplified Oort-style baseline: rank clients by dataset_size utility.

    The full Oort algorithm uses a richer utility involving training
    statistics; this simplified version captures the core
    'rank-by-utility' shape and is the standard simplified baseline in
    coalition-selection benchmarks.
    """
    indexed = sorted(
        range(len(clients)),
        key=lambda i: clients[i].dataset_size,
        reverse=True,
    )
    return indexed[:coalition_size]


def standard_pso_baseline(
    clients: list["Client"],
    coalition_size: int,
    target: "DemographicDistribution",
    seed: int = 0,
) -> list[int]:
    """
    Standard PSO without the fairness gradient.

    Implemented as FairSwarm with ``fairness_coefficient=0`` and
    ``fairness_weight=0``, isolating the contribution of the fairness
    gradient relative to the full algorithm.
    """
    from fairswarm import FairSwarm, FairSwarmConfig
    from fairswarm.fitness.fairness import DemographicFitness

    config = FairSwarmConfig(
        swarm_size=20,
        max_iterations=50,
        coalition_size=coalition_size,
        fairness_coefficient=0.0,  # no fairness gradient
        fairness_weight=0.0,  # no fairness penalty
        adaptive_fairness=False,
        seed=seed,
    )
    optimizer = FairSwarm(
        clients=clients,
        coalition_size=coalition_size,
        config=config,
        target_distribution=target,
        seed=seed,
    )
    fitness = DemographicFitness(
        target_distribution=target, divergence_weight=0.0
    )
    result = optimizer.optimize(fitness, n_iterations=50)
    optimizer._executor.close()
    return list(result.coalition)


def fairswarm_baseline(
    clients: list["Client"],
    coalition_size: int,
    target: "DemographicDistribution",
    seed: int = 0,
) -> list[int]:
    """The full FairSwarm algorithm (Algorithm 1)."""
    from fairswarm import FairSwarm, FairSwarmConfig
    from fairswarm.fitness.fairness import DemographicFitness

    config = FairSwarmConfig(
        swarm_size=20,
        max_iterations=50,
        coalition_size=coalition_size,
        seed=seed,
        adaptive_fairness=False,
    )
    optimizer = FairSwarm(
        clients=clients,
        coalition_size=coalition_size,
        config=config,
        target_distribution=target,
        seed=seed,
    )
    fitness = DemographicFitness(target_distribution=target)
    result = optimizer.optimize(fitness, n_iterations=50)
    optimizer._executor.close()
    return list(result.coalition)


# ---------------------------------------------------------------------------
# Comparison runner
# ---------------------------------------------------------------------------


def _make_synthetic_clients(
    n_clients: int = 20,
    n_groups: int = 4,
    seed: int = 0,
    concentration: float = 0.5,
) -> list["Client"]:
    """Synthetic Dirichlet-distributed clients for reproducible benchmarks."""
    from fairswarm.core.client import Client

    rng = np.random.default_rng(seed)
    return [
        Client(
            id=f"hospital_{i}",
            demographics=rng.dirichlet([concentration] * n_groups),
            dataset_size=int(500 + rng.integers(0, 1000)),
        )
        for i in range(n_clients)
    ]


def _evaluate_coalition(
    coalition: list[int],
    clients: list["Client"],
    target: "DemographicDistribution",
) -> tuple[float, float]:
    """Return (KL divergence, total dataset size) for one coalition."""
    from fairswarm.demographics.divergence import kl_divergence
    from fairswarm.fitness.fairness import compute_coalition_demographics

    if not coalition:
        return float("inf"), 0.0
    demo = compute_coalition_demographics(coalition, clients)
    div = float(kl_divergence(demo, target.as_array()))
    size = float(sum(clients[i].dataset_size for i in coalition))
    return div, size


def run_comparison(
    n_clients: int = 20,
    coalition_size: int = 10,
    n_groups: int = 4,
    n_trials: int = 5,
    seed: int = 42,
    target: "DemographicDistribution | None" = None,
    baselines: dict[str, SelectionBaseline] | None = None,
) -> dict[str, BenchmarkResult]:
    """
    Run the standard FairSwarm benchmark comparison.

    Each baseline is run ``n_trials`` times with seeds derived from
    ``seed``. For each trial we generate a fresh synthetic client
    population (so the comparison is over the full data-generating
    process, not a single sample), select a coalition, and record
    KL divergence to target, total dataset size, and wall-clock time.

    Args:
        n_clients: Total clients per trial.
        coalition_size: Coalition size m.
        n_groups: Number of demographic groups (alphabet size).
        n_trials: Trials per baseline.
        seed: Master seed.
        target: Target demographic distribution; defaults to uniform.
        baselines: Mapping name -> baseline callable. Defaults to all
            four shipped baselines.

    Returns:
        Mapping baseline-name -> BenchmarkResult.
    """
    from fairswarm.demographics.distribution import DemographicDistribution

    if target is None:
        target = DemographicDistribution(values=np.full(n_groups, 1.0 / n_groups))

    if baselines is None:
        baselines = {
            "random": random_baseline,
            "oort_simplified": oort_baseline,
            "standard_pso": standard_pso_baseline,
            "fairswarm": fairswarm_baseline,
        }

    results: dict[str, BenchmarkResult] = {}

    for name, baseline_fn in baselines.items():
        divs: list[float] = []
        sizes: list[float] = []
        wall_clocks: list[float] = []
        examples: list[list[int]] = []

        for trial in range(n_trials):
            trial_seed = seed + trial
            clients = _make_synthetic_clients(
                n_clients=n_clients, n_groups=n_groups, seed=trial_seed
            )
            t0 = time.perf_counter()
            coalition = baseline_fn(clients, coalition_size, target, trial_seed)
            elapsed = time.perf_counter() - t0
            div, size = _evaluate_coalition(coalition, clients, target)
            divs.append(div)
            sizes.append(size)
            wall_clocks.append(elapsed)
            if trial < 3:
                examples.append(sorted(coalition))

        results[name] = BenchmarkResult(
            baseline_name=name,
            n_trials=n_trials,
            mean_demographic_divergence=float(np.mean(divs)),
            std_demographic_divergence=float(np.std(divs, ddof=1) if len(divs) > 1 else 0.0),
            mean_dataset_size=float(np.mean(sizes)),
            std_dataset_size=float(np.std(sizes, ddof=1) if len(sizes) > 1 else 0.0),
            mean_wall_clock_seconds=float(np.mean(wall_clocks)),
            std_wall_clock_seconds=float(np.std(wall_clocks, ddof=1) if len(wall_clocks) > 1 else 0.0),
            coalition_examples=examples,
        )

    return results


def format_comparison_table(results: dict[str, BenchmarkResult]) -> str:
    """Produce a human-readable ASCII table summarizing the comparison."""
    header = (
        f"{'baseline':<18} {'KL divergence':>22} "
        f"{'dataset size':>22} {'wall-clock (s)':>22}"
    )
    sep = "-" * len(header)
    lines = [header, sep]
    for r in results.values():
        kl = f"{r.mean_demographic_divergence:.4f} ± {r.std_demographic_divergence:.4f}"
        ds = f"{r.mean_dataset_size:>10.0f} ± {r.std_dataset_size:.0f}"
        wc = f"{r.mean_wall_clock_seconds:.4f} ± {r.std_wall_clock_seconds:.4f}"
        lines.append(f"{r.baseline_name:<18} {kl:>22} {ds:>22} {wc:>22}")
    return "\n".join(lines)
