"""CLI flag tests for ``claw-forge run`` — push-after-merge plumbing.

The pattern: respx mocks the state-service ``POST /sessions/init`` endpoint
to return zero tasks (so ``run`` exits cleanly after init), and we patch
``claw_forge.cli.GitOps`` with a side_effect that captures construction
kwargs.  This lets us assert the CLI flag → ``GitOps(push_after_merge=...)``
plumbing without spinning up an agent dispatch.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import respx
from httpx import Response
from typer.testing import CliRunner

from claw_forge.cli import app

_runner = CliRunner()


def _yaml(tmp_path: Path, *, push_after_merge: str | None = None) -> Path:
    cfg = tmp_path / "claw-forge.yaml"
    body = (
        "providers: {}\n"
        "git:\n"
        "  enabled: true\n"
        "  merge_strategy: auto\n"
        "  branch_prefix: feat\n"
    )
    if push_after_merge is not None:
        body += f"  push_after_merge: {push_after_merge}\n"
    body += (
        "agent:\n"
        "  default_model: claude-sonnet-4-6\n"
    )
    cfg.write_text(body)
    return cfg


@pytest.fixture()
def project(tmp_path: Path) -> Path:
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.email", "t@x"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=tmp_path, check=True)
    (tmp_path / "f.txt").write_text("seed")
    subprocess.run(["git", "add", "."], cwd=tmp_path, check=True)
    subprocess.run(["git", "commit", "-qm", "init"], cwd=tmp_path, check=True)
    return tmp_path


def _invoke_run(
    cfg_path: Path, project_path: Path, *extra_args: str,
) -> tuple[dict, str, int]:
    """Invoke ``claw-forge run`` with empty-task init and a captured GitOps.

    Returns (captured_kwargs, output, exit_code).
    """
    captured: dict = {}

    def _capture_git_ops(*args: object, **kwargs: object) -> MagicMock:
        captured.update(kwargs)
        # Return a real-looking mock so downstream code doesn't choke
        ops = MagicMock()
        ops.enabled = kwargs.get("enabled", True)
        ops.push_after_merge = kwargs.get("push_after_merge", False)
        return ops

    init_payload = {
        "session_id": "00000000-0000-0000-0000-000000000001",
        "orphans_reset": 0,
        "tasks_adopted": 0,
        "tasks": [],  # empty → run exits cleanly
    }

    base_url = "http://127.0.0.1:8420"
    with (
        respx.mock(base_url=base_url, assert_all_called=False) as mock,
        patch("claw_forge.cli._ensure_state_service", return_value=8420),
        patch("claw_forge.git.GitOps", side_effect=_capture_git_ops),
    ):
        mock.post("/sessions/init").mock(return_value=Response(200, json=init_payload))
        result = _runner.invoke(
            app,
            ["run", "--config", str(cfg_path), "--project", str(project_path),
             *extra_args],
        )

    return captured, result.output, result.exit_code


class TestPushAfterMergeFlags:
    def test_default_push_after_merge_off(self, project: Path) -> None:
        cfg = _yaml(project)
        captured, output, code = _invoke_run(cfg, project)
        assert code == 0, output
        assert captured.get("push_after_merge") is False

    def test_flag_enables_push_after_merge(self, project: Path) -> None:
        cfg = _yaml(project)
        captured, output, code = _invoke_run(
            cfg, project, "--push-after-merge",
        )
        assert code == 0, output
        assert captured.get("push_after_merge") is True

    def test_push_remote_overrides_default_origin(self, project: Path) -> None:
        cfg = _yaml(project)
        captured, output, code = _invoke_run(
            cfg, project, "--push-after-merge", "--push-remote", "upstream",
        )
        assert code == 0, output
        assert captured.get("push_after_merge") == "upstream"

    def test_config_bool_true_enables(self, project: Path) -> None:
        cfg = _yaml(project, push_after_merge="true")
        captured, output, code = _invoke_run(cfg, project)
        assert code == 0, output
        assert captured.get("push_after_merge") is True

    def test_config_string_remote_passes_through(self, project: Path) -> None:
        cfg = _yaml(project, push_after_merge='"upstream"')
        captured, output, code = _invoke_run(cfg, project)
        assert code == 0, output
        assert captured.get("push_after_merge") == "upstream"

    def test_cli_flag_overrides_config_false(self, project: Path) -> None:
        cfg = _yaml(project, push_after_merge="false")
        captured, output, code = _invoke_run(
            cfg, project, "--push-after-merge",
        )
        assert code == 0, output
        assert captured.get("push_after_merge") is True
