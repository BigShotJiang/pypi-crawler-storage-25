from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from functools import lru_cache
import os
from pathlib import Path
import signal
import sys
from typing import ClassVar, Literal, final

from pydantic import BaseModel, Field
from tree_sitter import Language, Node, Parser
import tree_sitter_bash as tsbash

from drydock.core.tools.base import (
    BaseTool,
    BaseToolConfig,
    BaseToolState,
    InvokeContext,
    ToolError,
    ToolPermission,
)
from drydock.core.tools.ui import ToolCallDisplay, ToolResultDisplay, ToolUIData
from drydock.core.types import ToolResultEvent, ToolStreamEvent
from drydock.core.utils import is_windows


@lru_cache(maxsize=1)
def _get_parser() -> Parser:
    return Parser(Language(tsbash.language()))


def _extract_commands(command: str) -> list[str]:
    parser = _get_parser()
    tree = parser.parse(command.encode("utf-8"))

    commands: list[str] = []

    def find_commands(node: Node) -> None:
        if node.type == "command":
            parts = []
            for child in node.children:
                if (
                    child.type
                    in {"command_name", "word", "string", "raw_string", "concatenation"}
                    and child.text is not None
                ):
                    parts.append(child.text.decode("utf-8"))
            if parts:
                commands.append(" ".join(parts))

        for child in node.children:
            find_commands(child)

    find_commands(tree.root_node)
    return commands


def _get_subprocess_encoding() -> str:
    if sys.platform == "win32":
        # Windows console uses OEM code page (e.g., cp850, cp1252)
        import ctypes

        return f"cp{ctypes.windll.kernel32.GetOEMCP()}"
    return "utf-8"


def _get_shell_executable() -> str | None:
    if is_windows():
        return None
    return os.environ.get("SHELL")


def _get_conda_setup_script() -> str | None:
    """Find conda's shell setup script so conda activate works in non-interactive shells."""
    # Check common conda installation paths
    conda_exe = os.environ.get("CONDA_EXE")
    if conda_exe:
        conda_dir = Path(conda_exe).parent.parent
        setup = conda_dir / "etc" / "profile.d" / "conda.sh"
        if setup.exists():
            return str(setup)

    for candidate in [
        Path.home() / "miniconda3" / "etc" / "profile.d" / "conda.sh",
        Path.home() / "anaconda3" / "etc" / "profile.d" / "conda.sh",
        Path.home() / "miniforge3" / "etc" / "profile.d" / "conda.sh",
        Path("/opt/conda/etc/profile.d/conda.sh"),
        Path("/usr/local/conda/etc/profile.d/conda.sh"),
    ]:
        if candidate.exists():
            return str(candidate)
    return None


def _get_base_env() -> dict[str, str]:
    base_env = {**os.environ, "CI": "true", "NONINTERACTIVE": "1", "NO_TTY": "1"}

    if is_windows():
        base_env["GIT_PAGER"] = "more"
        base_env["PAGER"] = "more"
    else:
        base_env["TERM"] = "dumb"
        base_env["DEBIAN_FRONTEND"] = "noninteractive"
        base_env["GIT_PAGER"] = "cat"
        base_env["PAGER"] = "cat"
        base_env["LESS"] = "-FX"
        base_env["LC_ALL"] = "en_US.UTF-8"

        # Enable conda in non-interactive shells by setting BASH_ENV
        # to source conda's setup script. Without this, `conda activate`
        # fails because it's a shell function defined in .bashrc.
        #
        # IMPORTANT: We also preserve the user's active conda env to avoid
        # interfering with other environments and losing their aliases.
        conda_sh = _get_conda_setup_script()
        if conda_sh:
            # Create a wrapper that sources conda.sh then re-activates the user's env
            active_env = os.environ.get("CONDA_DEFAULT_ENV", "")
            if active_env and active_env != "base":
                # Write a temp script that initializes conda AND activates the user's env
                import tempfile
                wrapper = tempfile.NamedTemporaryFile(
                    mode="w", suffix=".sh", delete=False, prefix="drydock_conda_"
                )
                wrapper.write(f'source "{conda_sh}"\nconda activate "{active_env}" 2>/dev/null\n')
                wrapper.close()
                base_env["BASH_ENV"] = wrapper.name
            else:
                base_env["BASH_ENV"] = conda_sh

    return base_env


async def _kill_process_tree(proc: asyncio.subprocess.Process) -> None:
    if proc.returncode is not None:
        return

    try:
        if sys.platform == "win32":
            try:
                subprocess_proc = await asyncio.create_subprocess_exec(
                    "taskkill",
                    "/F",
                    "/T",
                    "/PID",
                    str(proc.pid),
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
                await subprocess_proc.wait()
            except (FileNotFoundError, OSError):
                proc.terminate()
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)

        await proc.wait()
    except (ProcessLookupError, PermissionError, OSError):
        pass


def _get_default_allowlist() -> list[str]:
    common = [
        "echo", "find", "git diff", "git log", "git status", "tree", "whoami",
        # Python project management — safe read/install operations
        "pip install", "pip list", "pip show", "pip freeze", "pip check",
        "pip install -e", "pip install -r",
        "conda install -y", "conda list", "conda info", "conda env list",
        "conda run", "conda create -y",
        "python -m pip", "python3 -m pip",
        "python -m pytest", "python3 -m pytest",
        "python -c", "python3 -c",
        "pytest", "make", "tox",
    ]

    if is_windows():
        return common + ["dir", "findstr", "more", "type", "ver", "where"]
    else:
        return common + [
            "cat",
            "file",
            "head",
            "ls",
            "pwd",
            "stat",
            "tail",
            "uname",
            "wc",
            "which",
        ]


def _get_default_denylist() -> list[str]:
    common = ["gdb", "pdb", "passwd"]

    if is_windows():
        return common + ["cmd /k", "powershell -NoExit", "pwsh -NoExit", "notepad"]
    else:
        return common + [
            "nano",
            "vim",
            "vi",
            "emacs",
            "bash -i",
            "sh -i",
            "zsh -i",
            "fish -i",
            "dash -i",
            "screen",
            "tmux",
        ]


def _get_default_denylist_standalone() -> list[str]:
    common = ["python", "python3", "ipython"]

    if is_windows():
        return common + ["cmd", "powershell", "pwsh", "notepad"]
    else:
        return common + ["bash", "sh", "nohup", "vi", "vim", "emacs", "nano", "su"]


class BashToolConfig(BaseToolConfig):
    permission: ToolPermission = ToolPermission.ASK
    max_output_bytes: int = Field(
        default=16_000, description="Maximum bytes to capture from stdout and stderr."
    )
    default_timeout: int = Field(
        default=300, description="Default timeout for commands in seconds."
    )
    allowlist: list[str] = Field(
        default_factory=_get_default_allowlist,
        description="Command prefixes that are automatically allowed",
    )
    denylist: list[str] = Field(
        default_factory=_get_default_denylist,
        description="Command prefixes that are automatically denied",
    )
    denylist_standalone: list[str] = Field(
        default_factory=_get_default_denylist_standalone,
        description="Commands that are denied only when run without arguments",
    )


class BashArgs(BaseModel):
    command: str
    timeout: int | None = Field(
        default=None, description="Override the default command timeout."
    )


class BashResult(BaseModel):
    command: str
    stdout: str
    stderr: str
    returncode: int


class Bash(
    BaseTool[BashArgs, BashResult, BashToolConfig, BaseToolState],
    ToolUIData[BashArgs, BashResult],
):
    description: ClassVar[str] = "Run a one-off bash command and capture its output."

    @classmethod
    def format_call_display(cls, args: BashArgs) -> ToolCallDisplay:
        return ToolCallDisplay(summary=f"bash: {args.command}")

    @classmethod
    def get_result_display(cls, event: ToolResultEvent) -> ToolResultDisplay:
        if not isinstance(event.result, BashResult):
            return ToolResultDisplay(
                success=False, message=event.error or event.skip_reason or "No result"
            )

        return ToolResultDisplay(success=True, message=f"Ran {event.result.command}")

    @classmethod
    def get_status_text(cls) -> str:
        return "Running command"

    def resolve_permission(self, args: BashArgs) -> ToolPermission | None:
        if is_windows():
            return None

        command_parts = _extract_commands(args.command)
        if not command_parts:
            return None

        def is_denylisted(command: str) -> bool:
            return any(command.startswith(pattern) for pattern in self.config.denylist)

        def is_standalone_denylisted(command: str) -> bool:
            parts = command.split()
            if not parts:
                return False

            base_command = parts[0]
            has_args = len(parts) > 1

            if not has_args:
                command_name = os.path.basename(base_command)
                if command_name in self.config.denylist_standalone:
                    return True
                if base_command in self.config.denylist_standalone:
                    return True

            return False

        def is_allowlisted(command: str) -> bool:
            return any(command.startswith(pattern) for pattern in self.config.allowlist)

        for part in command_parts:
            if is_denylisted(part):
                return ToolPermission.NEVER
            if is_standalone_denylisted(part):
                return ToolPermission.NEVER

        if all(is_allowlisted(part) for part in command_parts):
            return ToolPermission.ALWAYS

        return None

    @final
    def _build_timeout_error(self, command: str, timeout: int) -> ToolError:
        return ToolError(f"Command timed out after {timeout}s: {command!r}")

    @final
    def _build_result(
        self, *, command: str, stdout: str, stderr: str, returncode: int
    ) -> BashResult:
        if returncode != 0:
            error_msg = f"Command failed: {command!r}\n"
            error_msg += f"Return code: {returncode}"
            if stderr:
                error_msg += f"\nStderr: {stderr}"
            if stdout:
                error_msg += f"\nStdout: {stdout}"
            raise ToolError(error_msg.strip())

        return BashResult(
            command=command, stdout=stdout, stderr=stderr, returncode=returncode
        )

    async def run(
        self, args: BashArgs, ctx: InvokeContext | None = None
    ) -> AsyncGenerator[ToolStreamEvent | BashResult, None]:
        timeout = args.timeout or self.config.default_timeout
        max_bytes = self.config.max_output_bytes

        proc = None
        try:
            # start_new_session is Unix-only, on Windows it's ignored
            kwargs: dict[Literal["start_new_session"], bool] = (
                {} if is_windows() else {"start_new_session": True}
            )

            proc = await asyncio.create_subprocess_shell(
                args.command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.DEVNULL,
                env=_get_base_env(),
                executable=_get_shell_executable(),
                **kwargs,
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(), timeout=timeout
                )
            except TimeoutError:
                await _kill_process_tree(proc)
                raise self._build_timeout_error(args.command, timeout)

            encoding = _get_subprocess_encoding()
            stdout = (
                stdout_bytes.decode(encoding, errors="replace")[:max_bytes]
                if stdout_bytes
                else ""
            )
            stderr = (
                stderr_bytes.decode(encoding, errors="replace")[:max_bytes]
                if stderr_bytes
                else ""
            )

            returncode = proc.returncode or 0

            # Mechanical loop-breaker.
            # Tier 1 (3rd identical call): collapse body to short notice.
            # Tier 2 (5th identical call): raise ToolError. Notice-in-
            # tool-result was being ignored 75/75 times by Gemma 4
            # (session 20260414_003629 had 99 bash calls, 75 were NOTICE
            # re-runs). ToolError goes through the error-handling path
            # and the model visibly reacts to those.
            state = self.state.__dict__.setdefault("_bash_history", {})
            combined = stdout + "\n---STDERR---\n" + stderr
            out_hash = hash((combined, returncode))
            entry = state.get(args.command)
            if entry and entry["hash"] == out_hash:
                entry["count"] += 1
                if entry["count"] >= 5:
                    raise ToolError(
                        f"REFUSED: `{args.command[:80]}` has run "
                        f"{entry['count']} times with IDENTICAL output "
                        f"(rc={returncode}). Re-running will NOT change "
                        f"anything. You MUST do something DIFFERENT: "
                        f"edit source files, write tests, read a DIFFERENT "
                        f"file, or move on. This exact command is blocked "
                        f"until you take a different action. Last stdout "
                        f"(first 300): {stdout[:300]!r}"
                    )
                if entry["count"] >= 3:
                    notice = (
                        f"[NOTICE: this is the #{entry['count']} identical "
                        f"run of `{args.command[:80]}` with byte-identical "
                        f"output and rc={returncode}. Re-running will not "
                        f"change anything — you must EDIT SOURCE CODE to "
                        f"change this output. Previous stdout first 300 "
                        f"chars:\n{stdout[:300]}]"
                    )
                    yield self._build_result(
                        command=args.command,
                        stdout=notice,
                        stderr="",
                        returncode=returncode,
                    )
                    return
            else:
                state[args.command] = {"hash": out_hash, "count": 1}

            yield self._build_result(
                command=args.command,
                stdout=stdout,
                stderr=stderr,
                returncode=returncode,
            )

        except (ToolError, asyncio.CancelledError):
            raise
        except Exception as exc:
            raise ToolError(f"Error running command {args.command!r}: {exc}") from exc
        finally:
            if proc is not None:
                await _kill_process_tree(proc)
