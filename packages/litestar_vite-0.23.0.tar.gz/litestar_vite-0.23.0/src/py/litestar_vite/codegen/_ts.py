"""TypeScript conversion helpers for code generation."""

import re
from pathlib import PurePosixPath
from typing import Any, cast

_PATH_PARAM_TYPE_PATTERN = re.compile(r"\{([^:}]+):[^}]+\}")

_OPENAPI_STRING_FORMAT_TO_TS_ALIAS: dict[str, str] = {
    "uuid": "UUID",
    "date-time": "DateTime",
    "date": "DateOnly",
    "time": "TimeOnly",
    "duration": "Duration",
    "email": "Email",
    "idn-email": "Email",
    "uri": "URI",
    "url": "URI",
    "iri": "URI",
    "iri-reference": "URI",
    "uri-reference": "URI",
    "uri-template": "URI",
    "ipv4": "IPv4",
    "ipv6": "IPv6",
}


def normalize_path(path: str) -> str:
    """Normalize route path to use {param} syntax.

    Returns:
        Normalized path string.
    """
    if not path or path == "/":
        return path
    return _PATH_PARAM_TYPE_PATTERN.sub(r"{\1}", str(PurePosixPath(path)))


def _extract_schema_ref_name(ref: str) -> str | None:
    """Return the schema name from a ``#/components/schemas/<name>`` ref or None.

    Returns:
        The trailing schema name when ``ref`` is a components-schemas pointer; None otherwise.
    """
    prefix = "#/components/schemas/"
    if ref.startswith(prefix):
        return ref[len(prefix) :]
    return None


def _resolve_component_schema_name(name: str, components_schemas: dict[str, Any]) -> str | None:
    """Resolve Litestar's mangled schema names back to a key in ``components.schemas``.

    Litestar emits fully-qualified module paths in ``$ref`` targets (e.g.
    ``app_domain_insight_schemas__base_Granularity``) when nested types collide,
    but ``components.schemas`` is keyed on the short name (``Granularity``).
    Strip leading underscore-separated segments until a matching key is found.

    Returns:
        The resolved key from ``components_schemas``, or None when no match is found.
    """
    if name in components_schemas:
        return name

    if "_" not in name:
        return None

    parts = name.split("_")
    for i in range(len(parts)):
        candidate = "_".join(parts[i:])
        if candidate in components_schemas:
            return candidate
    return None


def ts_type_from_openapi(schema_dict: dict[str, Any], components_schemas: dict[str, Any] | None = None) -> str:
    """Convert an OpenAPI schema dict to a TypeScript type string.

    This function is intentionally lightweight and mirrors the historical
    behavior used in this project's unit tests (OpenAPI 3.1 union types,
    oneOf nullable patterns, etc.). It is not a full OpenAPI-to-TypeScript
    compiler.

    Args:
        schema_dict: The OpenAPI schema fragment to convert.
        components_schemas: Optional ``components.schemas`` map used to resolve
            ``$ref`` targets, including Litestar's name-mangled refs. When a
            ref resolves to a schema with ``enum``, the value expands to a TS
            literal union so the type is self-contained.

    Returns:
        A TypeScript type expression string.
    """
    if not schema_dict:
        return "any"

    ref = schema_dict.get("$ref")
    if isinstance(ref, str) and ref:
        ref_name = _extract_schema_ref_name(ref)
        if ref_name is None:
            return ref.split("/")[-1]

        resolved_type = ref_name
        if components_schemas:
            resolved_name = _resolve_component_schema_name(ref_name, components_schemas) or ref_name
            resolved_schema = components_schemas.get(resolved_name)
            if isinstance(resolved_schema, dict):
                resolved_schema_t = cast("dict[str, Any]", resolved_schema)
                enum_values = resolved_schema_t.get("enum")
                if isinstance(enum_values, list) and enum_values:
                    enum_values_t = cast("list[Any]", enum_values)
                    resolved_type = " | ".join(ts_literal(v) for v in enum_values_t)
                else:
                    resolved_type = resolved_name
            else:
                resolved_type = resolved_name
        return resolved_type

    if "anyOf" in schema_dict and isinstance(schema_dict["anyOf"], list) and schema_dict["anyOf"]:
        schemas = cast("list[Any]", schema_dict["anyOf"])
        union = {ts_type_from_subschema(s, components_schemas=components_schemas) for s in schemas}
        return join_union(union)

    result = "any"
    match schema_dict:
        case {"const": const} if const is not None:
            result = "any" if const is False else ts_literal(const)
        case {"enum": enum} if isinstance(enum, list) and enum:
            enum_values = cast("list[Any]", enum)
            result = " | ".join(ts_literal(v) for v in enum_values)
        case {"oneOf": one_of} if isinstance(one_of, list) and one_of:
            schemas = cast("list[Any]", one_of)
            union = {ts_type_from_subschema(s, components_schemas=components_schemas) for s in schemas}
            result = join_union(union)
        case {"allOf": all_of} if isinstance(all_of, list) and all_of:
            schemas = cast("list[Any]", all_of)
            parts = [
                wrap_union_for_intersection(ts_type_from_subschema(s, components_schemas=components_schemas))
                for s in schemas
            ]
            parts = [p for p in parts if p and p != "any"]
            result = " & ".join(parts) if parts else "any"
        case {"type": list()}:
            type_entries_list: list[Any] = schema_dict["type"]
            parts = [
                ts_type_from_openapi_type_entry(t, schema_dict, components_schemas=components_schemas)
                for t in type_entries_list
                if isinstance(t, str)
            ]
            result = join_union(set(parts)) if parts else "any"
        case {"type": str() as schema_type}:
            result = ts_type_from_openapi_type_entry(schema_type, schema_dict, components_schemas=components_schemas)
        case _:
            pass

    return result


def python_type_to_typescript(py_type: str, *, fallback: str = "unknown") -> tuple[str, bool]:
    """Convert a Python typing string representation into a TS type and optionality flag.

    Returns:
        A tuple of the TypeScript type string and a boolean indicating if the type is optional.
    """
    if not py_type:
        return fallback, False

    normalized = py_type.replace("typing.", "").replace("types.", "")
    optional = "None" in normalized or "NoneType" in normalized or "Optional[" in normalized

    normalized = normalized.replace("NoneType", "None").replace("None", "null")

    mapping: dict[str, str] = {
        "str": "string",
        "int": "number",
        "float": "number",
        "bool": "boolean",
        "dict": "Record<string, unknown>",
        "Dict": "Record<string, unknown>",
        "list": f"{fallback}[]",
        "List": f"{fallback}[]",
        "tuple": f"{fallback}[]",
        "Tuple": f"{fallback}[]",
        "set": f"{fallback}[]",
        "Set": f"{fallback}[]",
        "Any": fallback,
        "unknown": "unknown",
        "null": "null",
    }

    for k, v in mapping.items():
        if normalized == k:
            return v, optional

    return normalized, optional


def collect_ref_names(schema_dict: Any) -> set[str]:
    """Collect referenced component names from an OpenAPI schema dict.

    Returns:
        A set of referenced component names.
    """
    refs: set[str] = set()
    if isinstance(schema_dict, dict):
        schema_dict_t = cast("dict[str, Any]", schema_dict)
        ref_any = schema_dict_t.get("$ref")
        if isinstance(ref_any, str) and ref_any.startswith("#/components/schemas/"):
            refs.add(ref_any.split("/")[-1])
        for v in schema_dict_t.values():
            refs.update(collect_ref_names(v))
    elif isinstance(schema_dict, list):
        for item in cast("list[Any]", schema_dict):
            refs.update(collect_ref_names(item))
    return refs


def ts_type_from_subschema(schema: Any, components_schemas: dict[str, Any] | None = None) -> str:
    if isinstance(schema, dict):
        return ts_type_from_openapi(cast("dict[str, Any]", schema), components_schemas=components_schemas)
    return "any"


def ts_type_from_openapi_type_entry(
    type_name: str, schema_dict: dict[str, Any], components_schemas: dict[str, Any] | None = None
) -> str:
    primitive_types: dict[str, str] = {
        "string": "string",
        "integer": "number",
        "number": "number",
        "boolean": "boolean",
        "null": "null",
    }

    result = primitive_types.get(type_name, "any")
    if type_name == "string":
        fmt = schema_dict.get("format")
        if isinstance(fmt, str) and fmt:
            result = _OPENAPI_STRING_FORMAT_TO_TS_ALIAS.get(fmt, result)
    if type_name == "array":
        items = schema_dict.get("items")
        item_type = (
            ts_type_from_subschema(items, components_schemas=components_schemas)
            if isinstance(items, dict)
            else "unknown"
        )
        result = f"{wrap_for_array(item_type)}[]"
    elif type_name == "object":
        properties = schema_dict.get("properties")
        if not isinstance(properties, dict) or not properties:
            result = "{}"
        else:
            required_list = schema_dict.get("required")
            required: set[str] = set()
            if isinstance(required_list, list):
                required = {v for v in cast("list[Any]", required_list) if isinstance(v, str)}

            lines: list[str] = ["{"]
            for name, prop_schema in cast("dict[str, Any]", properties).items():
                ts_type = ts_type_from_subschema(prop_schema, components_schemas=components_schemas)
                optional = "" if name in required else "?"
                lines.append(f"  {name}{optional}: {ts_type};")
            lines.append("}")
            result = "\n".join(lines)

    return result


def wrap_for_array(type_expr: str) -> str:
    expr = type_expr.strip()
    if not expr:
        return "unknown"
    if expr.startswith("(") and expr.endswith(")"):
        return expr
    # Parenthesize unions/intersections so `(A | B)[]` / `(A & B)[]` is emitted correctly.
    if " | " in expr or (" & " in expr and not expr.startswith("{")):
        return f"({expr})"
    return expr


def wrap_union_for_intersection(type_expr: str) -> str:
    expr = type_expr.strip()
    if not expr:
        return "any"
    if expr.startswith("(") and expr.endswith(")"):
        return expr
    if " | " in expr:
        return f"({expr})"
    return expr


def join_union(types: set[str]) -> str:
    if not types:
        return "any"
    if len(types) == 1:
        return next(iter(types))
    return " | ".join(sorted(types))


def ts_literal(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int | float):
        return str(value)
    if isinstance(value, str):
        escaped = value.replace("\\\\", "\\\\\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    return "any"
