"""
Registry of rule types that can be imported/exported — maps a short
rule-type ident to its (module_path, model_class_name).
"""
rules = {
    'ansible_customvars': ('application.plugins.ansible.models', 'AnsibleCustomVariablesRule'),
    'ansible_filter': ('application.plugins.ansible.models', 'AnsibleFilterRule'),
    'ansible_rewrite': ('application.plugins.ansible.models', 'AnsibleRewriteAttributesRule'),
    'custom_attributes': ('application.modules.custom_attributes.models', 'CustomAttributeRule'),
    'cmk_tags': ('application.plugins.checkmk.models', 'CheckmkTagMngmt'),
    'cmk_filter': ('application.plugins.checkmk.models', 'CheckmkFilterRule'),
    'cmk_inventory': ('application.plugins.checkmk.models', 'CheckmkInventorizeAttributes'),
    'cmk_export_rules': ('application.plugins.checkmk.models', 'CheckmkRule'),
    'cmk_rules': ('application.plugins.checkmk.models', 'CheckmkRuleMngmt'),
    'cmk_groups': ('application.plugins.checkmk.models', 'CheckmkGroupRule'),
    'cmk_user': ('application.plugins.checkmk.models', 'CheckmkUserMngmt'),
    'cmk_rewrite': ('application.plugins.checkmk.models', 'CheckmkRewriteAttributeRule'),
    'cmk_sites': ('application.plugins.checkmk.models', 'CheckmkSite'),
    'cmk_site_settings': ('application.plugins.checkmk.models', 'CheckmkSettings'),
    'cmk_bi_aggregation': ('application.plugins.checkmk.models', 'CheckmkBiAggregation'),
    'cmk_bi_rule': ('application.plugins.checkmk.models', 'CheckmkBiRule'),
    'cmk_downtimes': ('application.plugins.checkmk.models', 'CheckmkDowntimeRule'),
    'cmk_dcd_rules': ('application.plugins.checkmk.models', 'CheckmkDCDRule'),
    'cmk_folder_pool': ('application.plugins.checkmk.models', 'CheckmkFolderPool'),
    'host_objects': ('application.models.host', 'Host'),
    'accounts': ('application.models.account', 'Account'),
    'users': ('application.models.user', 'User'),
    'idoit_rules': ('application.plugins.idoit.models', 'IdoitCustomAttributes'),
    'idoit_rewrite': ('application.plugins.idoit.models', 'IdoitRewriteAttributeRule'),
    'netbox_dcim_interfaces': ('application.plugins.netbox.models',
                                'NetboxDcimInterfaceAttributes'),
    'netbox_virtual_interfaces': ('application.plugins.netbox.models',
                                  'NetboxVirtualizationInterfaceAttributes'),
    'netbox_devices': ('application.plugins.netbox.models', 'NetboxCustomAttributes'),
    'netbox_ips': ('application.plugins.netbox.models', 'NetboxIpamIpaddressattributes'),
    'netbox_prefixes': ('application.plugins.netbox.models', 'NetboxIpamPrefixAttributes'),
    'netbox_vms': ('application.plugins.netbox.models', 'NetboxVirtualMachineAttributes'),
    'netbox_cluster': ('application.plugins.netbox.models', 'NetboxClusterAttributes'),
    'netbox_contacts': ('application.plugins.netbox.models', 'NetboxContactAttributes'),
    'netbox_dataflow_models': ('application.plugins.netbox.models', 'NetboxDataflowModels'),
    'netbox_dataflow_fields': ('application.plugins.netbox.models', 'NetboxDataflowAttributes'),
    'netbox_rewrites': ('application.plugins.netbox.models', 'NetboxRewriteAttributeRule'),
    'vmware_custom_attributes': ('application.plugins.vmware.models', 'VMwareCustomAttributes'),
    'vmware_rewrite_attributes': ('application.plugins.vmware.models', 'VMwareRewriteAttributes'),
    'syncer_rule_automation': ('application.plugins.rules.models', 'SyncerRuleAutomation'),
}


rule_names = [(x, y[1]) for x, y in rules.items()]
