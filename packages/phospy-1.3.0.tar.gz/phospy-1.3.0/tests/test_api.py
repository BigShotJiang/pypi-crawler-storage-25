from __future__ import annotations

from pathlib import Path

from phospy import (
    KinaseWorkflow,
    PredMatWorkflow,
    SignalomeWorkflow,
    SimpleKinaseWorkflow,
)
from phospy.api.workflow_results import (
    KinaseWorkflowResult,
    PredMatWorkflowResult,
    SimpleKinaseWorkflowResult,
)


def test_public_workflows_are_defined_under_owning_api_modules() -> None:
    assert KinaseWorkflow.__module__ == "phospy.api.kinase_workflows"
    assert PredMatWorkflow.__module__ == "phospy.api.kinase_workflows"
    assert SignalomeWorkflow.__module__ == "phospy.api.signalome_workflows"
    assert SimpleKinaseWorkflow.__module__ == "phospy.api.simple_workflows"
    assert KinaseWorkflowResult.__module__ == "phospy.api.workflow_results"
    assert PredMatWorkflowResult.__module__ == "phospy.api.workflow_results"
    assert SimpleKinaseWorkflowResult.__module__ == "phospy.api.workflow_results"


def test_legacy_workflow_module_has_been_removed() -> None:
    workflow_module = (
        Path(__file__).resolve().parents[1] / "src" / "phospy" / "workflow.py"
    )
    assert not workflow_module.exists()


def test_api_package_exports_only_supported_workflows() -> None:
    import phospy.api as api

    assert set(api.__all__) == {
        "KinaseWorkflow",
        "PredMatWorkflow",
        "SignalomeWorkflow",
        "SimpleKinaseWorkflow",
    }
    assert not hasattr(api, "KinaseWorkflowResult")
    assert not hasattr(api, "PredMatWorkflowResult")
    assert not hasattr(api, "SimpleKinaseWorkflowResult")


def test_signalomes_package_does_not_export_trusted_execution_helper() -> None:
    import phospy.signalomes as signalomes

    assert not hasattr(signalomes, "execute_signalome_inputs")
