"""
Standalone wrappers — each call creates its own session and commits.

Replaces ``db_manager`` pattern: one function call = one session = one transaction.

Setup::

    import sqlmodel_object_helpers as soh

    soh.configure(async_session_factory)

Usage::

    import sqlmodel_object_helpers.standalone as soh

    user = await soh.get_object(User, pk={"id": 1})
    new_user = await soh.add_object(User(name="Ivan"))
    await soh.delete_object(User, pk={"id": 1})

Migration to DI sessions later::

    import sqlmodel_object_helpers as soh

    user = await soh.get_object(session, User, pk={"id": 1})

"""

import logging
from typing import Any

from pydantic import BaseModel
from sqlmodel import SQLModel

from . import mutations as _m
from . import query as _q
from .dynamic_meta import ColumnEntry
from .dynamic_meta import build_dynamic_meta as _build_dynamic_meta
from .session import auto_session
from .types.columns import ColumnMeta, TableMeta
from .types.filters import TimeFilter
from .types.pagination import GetAllPagination, Pagination
from .types.projections import ColumnSpec

logger = logging.getLogger("sqlmodel_object_helpers")


# ---------------------------------------------------------------------------
# Query wrappers
# ---------------------------------------------------------------------------


async def get_object[T: SQLModel](
    model: type[T],
    pk: dict[str, Any] | None = None,
    filters: BaseModel | dict[str, Any] | None = None,
    load_paths: list[str | tuple[str, ...]] | None = None,
    *,
    suspend_error: bool = False,
    order_by: Any | None = None,
    columns: list[Any] | None = None,
    extra_joins: list[tuple[Any, ...]] | None = None,
    limit_one: bool = True,
    for_update: bool = False,
) -> list[dict[str, Any]] | T | None:
    """Fetch a single object. Auto-creates session and commits."""
    logger.debug("standalone.get_object(%s, pk=%s)", model.__name__, pk)
    async with auto_session() as s:
        return await _q.get_object(
            s, model, pk, filters, load_paths,
            suspend_error=suspend_error, order_by=order_by,
            columns=columns, extra_joins=extra_joins,
            limit_one=limit_one, for_update=for_update,
        )


async def get_objects[T: SQLModel](
    model: type[T],
    filters: dict[str, Any | list[Any]] | BaseModel | None = None,
    load_paths: list[str | list[str]] | None = None,
    logical_operator: str = "AND",
    *,
    suspend_error: bool = False,
    pagination: Pagination | None = None,
    order_by: Any | None = None,
    time_filter: TimeFilter | None = None,
    columns: list[Any] | None = None,
    extra_joins: list[tuple[Any, ...]] | None = None,
) -> list[T] | list[dict[str, Any]] | GetAllPagination[T] | GetAllPagination[dict[str, Any]]:
    """Fetch multiple objects. Auto-creates session and commits."""
    logger.debug("standalone.get_objects(%s)", model.__name__)
    async with auto_session() as s:
        return await _q.get_objects(
            s, model, filters, load_paths, logical_operator,
            suspend_error=suspend_error, pagination=pagination,
            order_by=order_by, time_filter=time_filter,
            columns=columns, extra_joins=extra_joins,
        )


async def count_objects[T: SQLModel](
    model: type[T],
    filters: dict[str, Any | list[Any]] | BaseModel | None = None,
    logical_operator: str = "AND",
    *,
    suspend_error: bool = False,
    extra_joins: list[tuple[Any, ...]] | None = None,
    time_filter: TimeFilter | None = None,
) -> int:
    """Count records matching filters. Auto-creates session and commits."""
    logger.debug("standalone.count_objects(%s)", model.__name__)
    async with auto_session() as s:
        return await _q.count_objects(
            s, model, filters, logical_operator,
            suspend_error=suspend_error, extra_joins=extra_joins,
            time_filter=time_filter,
        )


async def exists_object[T: SQLModel](
    model: type[T],
    pk: dict[str, Any] | None = None,
    filters: dict[str, Any | list[Any]] | BaseModel | None = None,
    *,
    suspend_error: bool = False,
) -> bool:
    """Check if a record exists. Auto-creates session and commits."""
    logger.debug("standalone.exists_object(%s, pk=%s)", model.__name__, pk)
    async with auto_session() as s:
        return await _q.exists_object(
            s, model, pk, filters,
            suspend_error=suspend_error,
        )


async def get_projection[T: SQLModel](
    model: type[T],
    columns: list[ColumnSpec],
    pk: dict[str, Any] | None = None,
    filters: BaseModel | dict[str, Any] | None = None,
    outer_joins: list[str] | None = None,
    *,
    suspend_error: bool = False,
    order_by: Any | None = None,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    """Fetch specific columns via projection. Auto-creates session and commits."""
    logger.debug("standalone.get_projection(%s)", model.__name__)
    async with auto_session() as s:
        return await _q.get_projection(
            s, model, columns, pk, filters, outer_joins,
            suspend_error=suspend_error, order_by=order_by, limit=limit,
        )


# ---------------------------------------------------------------------------
# Mutation wrappers
# ---------------------------------------------------------------------------


async def add_object[T: SQLModel](instance: T) -> T:
    """Add a single object. Auto-creates session, commits on success."""
    logger.debug("standalone.add_object(%s)", type(instance).__name__)
    async with auto_session() as s:
        return await _m.add_object(s, instance)


async def add_objects[T: SQLModel](instances: list[T]) -> list[T]:
    """Add multiple objects. Auto-creates session, commits on success."""
    model_name = type(instances[0]).__name__ if instances else "?"
    logger.debug("standalone.add_objects(%s, count=%d)", model_name, len(instances))
    async with auto_session() as s:
        return await _m.add_objects(s, instances)


async def update_object[T: SQLModel](instance: T, data: dict[str, Any]) -> T:
    """Update an object. Auto-creates session, commits on success."""
    logger.debug("standalone.update_object(%s)", type(instance).__name__)
    async with auto_session() as s:
        return await _m.update_object(s, instance, data)


async def update_objects[T: SQLModel](
    model: type[T],
    data: dict[str, Any],
    filters: dict[str, Any | list[Any]] | None = None,
    logical_operator: str = "AND",
) -> int:
    """Bulk-update records matching filters. Auto-creates session, commits on success."""
    logger.debug("standalone.update_objects(%s)", model.__name__)
    async with auto_session() as s:
        return await _m.update_objects(s, model, data, filters, logical_operator)


async def delete_object[T: SQLModel](
    model: type[T],
    *,
    instance: T | None = None,
    pk: dict[str, Any] | None = None,
) -> None:
    """Delete a single object. Auto-creates session, commits on success."""
    logger.debug("standalone.delete_object(%s, pk=%s)", model.__name__, pk)
    async with auto_session() as s:
        return await _m.delete_object(s, model, instance=instance, pk=pk)


async def delete_objects[T: SQLModel](
    model: type[T],
    filters: dict[str, Any | list[Any]] | None = None,
    logical_operator: str = "AND",
) -> int:
    """Bulk-delete records matching filters. Auto-creates session, commits on success."""
    logger.debug("standalone.delete_objects(%s)", model.__name__)
    async with auto_session() as s:
        return await _m.delete_objects(s, model, filters, logical_operator)


async def check_for_related_records[T: SQLModel](
    model: type[T],
    pk: dict[str, Any],
) -> list[str] | None:
    """Check for dependent child records. Auto-creates session."""
    logger.debug("standalone.check_for_related_records(%s, pk=%s)", model.__name__, pk)
    async with auto_session() as s:
        return await _m.check_for_related_records(s, model, pk)


# ---------------------------------------------------------------------------
# Dynamic UI metadata wrapper
# ---------------------------------------------------------------------------


async def build_dynamic_meta[T: SQLModel](
    model: type[T],
    *,
    name: str,
    columns: list[ColumnEntry],
    header: str | None = None,
    row_link: str | None = None,
    role_type: str | None = None,
) -> tuple[TableMeta, list[ColumnMeta]]:
    """Build TableMeta + list[ColumnMeta] from model + pg_description.

    Standalone wrapper around ``dynamic_meta.build_dynamic_meta`` — auto-creates
    a session for the pg_description query. See ``dynamic_meta.build_dynamic_meta``
    for full semantics, source-of-truth precedence, and examples.
    """
    logger.debug("standalone.build_dynamic_meta(%s)", model.__name__)
    async with auto_session() as s:
        return await _build_dynamic_meta(
            s, model,
            name=name,
            columns=columns,
            header=header,
            row_link=row_link,
            role_type=role_type,
        )
