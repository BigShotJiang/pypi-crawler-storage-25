from datetime import date, datetime, timedelta, timezone
from typing import Any, Self

from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from ..constants import settings
from .datetime import UTCDatetime


def _parse_range_part(s: str) -> datetime:
    """Parse a single date/datetime from a range string part.

    Accepts ISO formats (``2026-04-01``, ``2026-04-01T00:00:00``,
    ``2026-04-01T00:00:00.000Z``) and display format (``01.04.2026 00:00``).
    """
    s = s.strip()
    if not s:
        msg = "Empty date string"
        raise ValueError(msg)

    # ISO formats: 2026-04-01, 2026-04-01T00:00:00, 2026-04-01T00:00:00.000Z, +03:00 etc.
    try:
        normalized = s.removesuffix("Z") + "+00:00" if s.endswith("Z") else s
        return datetime.fromisoformat(normalized)
    except ValueError:
        pass

    # Display formats: DD.MM.YYYY, DD.MM.YYYY HH:MM, DD.MM.YYYY HH:MM:SS
    for fmt in ("%d.%m.%Y %H:%M", "%d.%m.%Y %H:%M:%S", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, fmt)  # noqa: DTZ007
        except ValueError:
            continue

    msg = (
        f"Invalid date format: {s!r}. "
        "Expected YYYY-MM-DD, ISO datetime, or DD.MM.YYYY HH:MM"
    )
    raise ValueError(msg)


class FilterInt(BaseModel):
    eq: int | None = None
    ne: int | None = None
    gt: int | None = None
    lt: int | None = None
    ge: int | None = None
    le: int | None = None
    in_: list[int] | None = None

    @field_validator("eq", "ne", "gt", "lt", "ge", "le", mode="before")
    @classmethod
    def validate_int(cls, v: Any) -> Any:
        if isinstance(v, str):
            try:
                return int(v)
            except (ValueError, TypeError) as err:
                msg = "Value must be a number or a numeric string"
                raise ValueError(msg) from err
        return v

    @field_validator("in_", mode="before")
    @classmethod
    def validate_in_list(cls, v: Any) -> Any:
        if v is None:
            return v
        if not isinstance(v, list):
            msg = "in_ must be a list"
            raise ValueError(msg)
        if len(v) > settings.max_in_list_size:
            msg = f"in_ cannot contain more than {settings.max_in_list_size} elements"
            raise ValueError(msg)
        result: list[int] = []
        for item in v:
            if isinstance(item, int):
                result.append(item)
            elif isinstance(item, str):
                try:
                    result.append(int(item))
                except (ValueError, TypeError) as err:
                    msg = f"in_ list item must be a number, got: {item!r}"
                    raise ValueError(msg) from err
            else:
                msg = f"in_ list item must be a number, got: {item!r}"
                raise ValueError(msg)
        return result


class FilterStr(BaseModel):
    eq: str | None = None
    ne: str | None = None
    like: str | None = None
    ilike: str | None = None


class FilterDate(BaseModel):
    eq: date | None = None
    ne: date | None = None
    gt: date | None = None
    lt: date | None = None
    ge: date | None = None
    le: date | None = None


class FilterNaiveDatetime(BaseModel):
    """Filter for TIMESTAMP WITHOUT TIME ZONE columns.

    Timezone-aware input is **rejected** (raises ``ValueError`` → HTTP 422)
    because silently stripping timezone info hides conversion bugs on the caller side.
    """

    eq: datetime | None = None
    ne: datetime | None = None
    gt: datetime | None = None
    lt: datetime | None = None
    ge: datetime | None = None
    le: datetime | None = None

    @field_validator("eq", "ne", "gt", "lt", "ge", "le", mode="after")
    @classmethod
    def reject_timezone(cls, v: datetime | None) -> datetime | None:
        if v is not None and v.tzinfo is not None:
            msg = (
                "Timezone-aware datetime is not allowed for naive datetime filters. "
                "Send a naive datetime (without timezone offset), e.g. '2026-03-19T00:00:00'"
            )
            raise ValueError(msg)
        return v


class FilterDatetime(BaseModel):
    eq: UTCDatetime | None = None
    ne: UTCDatetime | None = None
    gt: UTCDatetime | None = None
    lt: UTCDatetime | None = None
    ge: UTCDatetime | None = None
    le: UTCDatetime | None = None


class FilterTimedelta(BaseModel):
    eq: timedelta | None = None
    ne: timedelta | None = None
    gt: timedelta | None = None
    lt: timedelta | None = None
    ge: timedelta | None = None
    le: timedelta | None = None


def _split_range(range_str: str) -> tuple[str, str]:
    """Split a range string by comma into (left, right) parts.

    Returns stripped parts; either side may be empty for open-ended ranges.
    """
    if "," not in range_str:
        msg = f"Invalid range format: {range_str!r}. Expected 'FROM,TO', 'FROM,', or ',TO'"
        raise ValueError(msg)
    left, right = range_str.split(",", maxsplit=1)
    return left.strip(), right.strip()


def _make_utc(dt: datetime) -> datetime:
    """Ensure a datetime is UTC-aware. Naive datetimes are assumed UTC."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class FilterDatetimeRange(BaseModel):
    """
    Range filter for datetime fields, parsed from a comma-separated string.

    Supported string formats (separator is ``,``)::

        "2026-04-01,2026-04-30"     — full range  (gt + lt)
        "2026-04-01,"               — from date   (gt only, open end)
        ",2026-04-30"               — to date     (lt only, open start)

    Each date part accepts ISO (``2026-04-01``, ``2026-04-01T00:00:00Z``)
    and display format (``01.04.2026 00:00``).

    After validation the model contains UTC-aware ``gt`` and/or ``lt`` fields
    that map directly to SQLAlchemy operators via ``model_dump(exclude_none=True)``.
    """

    gt: UTCDatetime | None = None
    lt: UTCDatetime | None = None

    @model_validator(mode="before")
    @classmethod
    def parse_range_string(cls, data: Any) -> Any:
        if isinstance(data, str):
            return cls._parse_range(data)
        return data

    @staticmethod
    def _parse_range(range_str: str) -> dict[str, datetime]:
        range_str = range_str.strip()
        if not range_str:
            msg = "Range string must not be empty"
            raise ValueError(msg)

        left, right = _split_range(range_str)
        result: dict[str, datetime] = {}

        if left:
            result["gt"] = _make_utc(_parse_range_part(left))
        if right:
            result["lt"] = _make_utc(_parse_range_part(right))

        return result

    @model_validator(mode="after")
    def validate_range(self) -> Self:
        if self.gt is None and self.lt is None:
            msg = "At least one of gt or lt must be set"
            raise ValueError(msg)
        if self.gt is not None and self.lt is not None and self.gt > self.lt:
            msg = "Range start (gt) must not be after range end (lt)"
            raise ValueError(msg)
        return self


class FilterNaiveDatetimeRange(BaseModel):
    """
    Same as :class:`FilterDatetimeRange` but produces **naive** (timezone-unaware) datetimes.

    Timezone-aware input is **rejected** (raises ``ValueError`` → HTTP 422)
    because silently stripping timezone info hides conversion bugs on the caller side.
    """

    gt: datetime | None = None
    lt: datetime | None = None

    @model_validator(mode="before")
    @classmethod
    def parse_range_string(cls, data: Any) -> Any:
        if isinstance(data, str):
            return cls._parse_range(data)
        return data

    @field_validator("gt", "lt", mode="after")
    @classmethod
    def reject_timezone(cls, v: datetime | None) -> datetime | None:
        if v is not None and v.tzinfo is not None:
            msg = (
                "Timezone-aware datetime is not allowed for naive datetime range filters. "
                "Send a naive datetime (without timezone offset), e.g. '2026-03-19T00:00:00'"
            )
            raise ValueError(msg)
        return v

    @staticmethod
    def _parse_range(range_str: str) -> dict[str, datetime]:
        range_str = range_str.strip()
        if not range_str:
            msg = "Range string must not be empty"
            raise ValueError(msg)

        left, right = _split_range(range_str)
        result: dict[str, datetime] = {}

        if left:
            result["gt"] = _parse_range_part(left)
        if right:
            result["lt"] = _parse_range_part(right)

        return result

    @model_validator(mode="after")
    def validate_range(self) -> Self:
        if self.gt is None and self.lt is None:
            msg = "At least one of gt or lt must be set"
            raise ValueError(msg)
        if self.gt is not None and self.lt is not None and self.gt > self.lt:
            msg = "Range start (gt) must not be after range end (lt)"
            raise ValueError(msg)
        return self


class FilterBool(BaseModel):
    eq: bool | None = None
    ne: bool | None = None


class FilterExists(BaseModel):
    exists: bool


class OrderAsc(BaseModel):
    asc: str | None = None


class OrderDesc(BaseModel):
    desc: str | None = None


class OrderBy(BaseModel):
    sorts: list[OrderAsc | OrderDesc] = []


class LogicalFilter(BaseModel):
    model_config = ConfigDict(extra="forbid")

    AND: list[LogicalFilter] | None = None
    OR: list[LogicalFilter] | None = None
    condition: dict[str, Any] | None = None

    @model_validator(mode="after")
    def validate_single_key(self) -> Self:
        set_fields = sum(
            1 for f in ("AND", "OR", "condition") if getattr(self, f) is not None
        )
        if set_fields != 1:
            msg = "Exactly one of AND, OR, or condition must be set"
            raise ValueError(msg)
        return self


class TimeFilter(BaseModel):
    """
    Filter by created_at / updated_at datetime ranges.

    All fields are optional — only set fields are applied.
    """

    model_config = ConfigDict(extra="forbid")

    created_after: UTCDatetime | None = None
    created_before: UTCDatetime | None = None
    updated_after: UTCDatetime | None = None
    updated_before: UTCDatetime | None = None

    @model_validator(mode="after")
    def validate_ranges(self) -> Self:
        if (
            self.created_after is not None
            and self.created_before is not None
            and self.created_after >= self.created_before
        ):
            msg = "created_after must be before created_before"
            raise ValueError(msg)
        if (
            self.updated_after is not None
            and self.updated_before is not None
            and self.updated_after >= self.updated_before
        ):
            msg = "updated_after must be before updated_before"
            raise ValueError(msg)
        if (
            self.created_after is not None
            and self.updated_before is not None
            and self.created_after >= self.updated_before
        ):
            msg = (
                "created_after cannot be >= updated_before "
                "(a record's update time cannot be earlier than its creation time)"
            )
            raise ValueError(msg)
        return self
