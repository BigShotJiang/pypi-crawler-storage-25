"""Column and table metadata for dynamic frontend table rendering."""

from enum import StrEnum

from pydantic import BaseModel, ConfigDict


class ColumnType(StrEnum):
    """Data type of a table column — determines how the frontend renders and filters it."""

    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    DATE = "date"
    DATETIME = "datetime"


class BoolLabels(BaseModel):
    """Display labels for boolean columns.

    Source: PostgreSQL domain comments, e.g.
    ``COMMENT ON DOMAIN is_paid_domain IS 'Оплачено|Не оплачено'``
    """

    model_config = ConfigDict(extra="forbid")

    true_label: str
    false_label: str


class TableMeta(BaseModel):
    """Table-level metadata.

    Attributes:
        name: Stable identifier used as a key for saving user settings
            (e.g. ``"attempts"``).
        header: Human-readable table title for the UI
            (e.g. ``"Реестр попыток"``).
        row_link: Optional URL template that makes each row clickable.
            Uses ``$id`` as placeholder for the row identifier
            (e.g. ``"/lead/$id"``, ``"/mail-template-lead/$id/edit"``).
    """

    model_config = ConfigDict(extra="forbid")

    name: str
    header: str
    row_link: str | None = None


class ColumnMeta(BaseModel):
    """Metadata for a single table column sent to the frontend.

    Attributes:
        json_path: Dot-notation path to the value inside each ``data`` item
            (e.g. ``"application.applicant.full_name"``).  Also serves as
            the column identifier.
        label: Human-readable column header (Russian name for the UI).
        type: Data type — drives the filter widget and cell renderer on the
            frontend.
        lookup_dict: Optional name of the LKP dictionary the frontend
            already has cached (e.g. ``"statuses"``).  When present the
            frontend renders a ``<select>`` filter instead of free text.
        lookup_path: Optional dot-notation path to the ID field used for
            filtering when ``lookup_dict`` is set.  The frontend displays
            ``json_path`` but sends ``lookup_path`` in filter requests.
        bool_labels: Optional display labels for boolean values
            (e.g. ``"Оплачено"`` / ``"Не оплачено"``).
    """

    model_config = ConfigDict(extra="forbid")

    json_path: str
    label: str
    type: ColumnType = ColumnType.STRING
    lookup_dict: str | None = None
    lookup_path: str | None = None
    bool_labels: BoolLabels | None = None
