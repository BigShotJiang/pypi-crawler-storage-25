from pydantic import BaseModel, ConfigDict, Field

from .columns import ColumnMeta, TableMeta


class Pagination(BaseModel):
    page: int | None = Field(default=1, ge=1)
    per_page: int | None = Field(default=10, ge=1)


class PaginationR(Pagination):
    total: int


class GetAllPagination[T](BaseModel):
    table: TableMeta | None = None
    columns: list[ColumnMeta] | None = None
    data: list[T]
    pagination: PaginationR | None = None


class LookupMeta(BaseModel):
    """Metadata for a lookup dictionary response.

    Attributes:
        name: Stable identifier used as the cache key on the frontend
            (e.g. ``"lead_email_types"``). Must match
            ``ColumnMeta.lookup_dict`` values.
    """

    model_config = ConfigDict(extra="forbid")

    name: str


class LookupResponse[T](BaseModel):
    """Standard response wrapper for lookup (``_lkp``) endpoints.

    Mirrors the ``{meta, data}`` pattern the frontend uses for caching::

        store.lookups["lead_email_types"] = {meta: {name: "lead_email_types"}, data: [...]}

    Attributes:
        meta: Lookup metadata (name used as cache key).
        data: List of lookup records.
    """

    meta: LookupMeta
    data: list[T]
