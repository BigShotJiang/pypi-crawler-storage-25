"""Dynamic UI metadata: read pg_description with model fallback at runtime.

Architecture:
    Two sources of truth for ColumnMeta.label / TableMeta.header, with
    explicit precedence (highest → lowest):

        1. pg_description    — DBA edit via COMMENT ON COLUMN/TABLE
                               (TTL-cached, supports per-role || format)
        2. model.col.comment — Python-side default from Column(comment=...)

    If both are None for a physical column → ValueError (fail loud).

    For virtual columns (json_paths with `.` traversing relationships,
    e.g. "last_editor.user_name"), there is no physical column to introspect.
    Pass a fully-specified ``ColumnMeta`` instance directly in the ``columns``
    list — it is used as-is, no derivation.

    No sync block, no schema migrations introduced. The application's db.py
    is not touched. pg_description and the model exist independently;
    build_dynamic_meta reads both at runtime and applies precedence per request.

    Per-role overrides via extended ``||`` format in pg_description:

        COMMENT ON COLUMN table.col IS 'Default||operator=Operator label||buh=Buh label';
        COMMENT ON TABLE  table     IS 'Default header||row_link=/x||row_link.operator=/op/x';

Note:
    ``load_pg_comments`` queries PostgreSQL pg_catalog (``obj_description``,
    ``col_description``). It will not work on other databases.

Thread safety:
    ``_meta_cache`` is a process-local plain ``dict`` without locking. Under
    uvicorn (single event loop per worker) this is fine — no race possible.
    Under multi-threaded sync workers (e.g. gunicorn ``sync`` workers with
    ``threads > 1``), the read-modify-write pattern in ``load_pg_comments``
    can race on cache miss: two threads may both query pg_catalog and write
    to the cache. The result is correct (both threads write the same value,
    last write wins) — only redundant DB queries are wasted, never wrong data.
"""

import time
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    Date,
    DateTime,
    Enum,
    Float,
    Integer,
    Interval,
    Numeric,
    SmallInteger,
    String,
    Text,
    text,
)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.types import ARRAY, Uuid
from sqlmodel import SQLModel

from .types.columns import ColumnMeta, ColumnType, TableMeta


# ─────────────────────────────────────────────────────────────────────────────
# TTL cache (process-local)
# ─────────────────────────────────────────────────────────────────────────────

_DEFAULT_CACHE_TTL: int = 60   # seconds
_meta_cache: dict[tuple[str, str], tuple[float, str | None, dict[str, str]]] = {}


def configure_meta_cache_ttl(seconds: int) -> None:
    """Override default pg_description cache TTL (default: 60 seconds).

    Affects all subsequent calls to ``load_pg_comments`` and ``build_dynamic_meta``.
    Process-local — each uvicorn worker has its own cache and TTL setting.
    """
    global _DEFAULT_CACHE_TTL
    _DEFAULT_CACHE_TTL = seconds


def invalidate_meta_cache(schema: str | None = None, table: str | None = None) -> None:
    """Manually invalidate the pg_description cache.

    Args:
        schema: Optional schema name. If only ``schema`` is given (without
            ``table``), drops **all** cached entries belonging to that schema.
        table: Optional table name. Must be paired with ``schema``.

    Behavior:
        - ``invalidate_meta_cache()`` — clears the entire cache.
        - ``invalidate_meta_cache(schema="lead")`` — clears all entries for
          schema ``"lead"``.
        - ``invalidate_meta_cache(schema="lead", table="emails_messages")``
          — clears one specific entry.
        - ``invalidate_meta_cache(table="x")`` without ``schema`` — raises
          ``ValueError`` (ambiguous: which schema?).
    """
    if schema is None and table is None:
        _meta_cache.clear()
        return
    if schema is None:
        msg = "invalidate_meta_cache: cannot pass `table` without `schema`"
        raise ValueError(msg)
    if table is None:
        # Clear all entries for this schema (collect keys first to avoid mutation during iteration)
        for k in [k for k in _meta_cache if k[0] == schema]:
            del _meta_cache[k]
        return
    _meta_cache.pop((schema, table), None)


# ─────────────────────────────────────────────────────────────────────────────
# pg_description loader
# ─────────────────────────────────────────────────────────────────────────────

_PG_META_SQL = text("""
    SELECT
        obj_description(c.oid, 'pg_class') AS table_comment,
        COALESCE(
            jsonb_object_agg(a.attname, d.comment)
              FILTER (WHERE d.comment IS NOT NULL),
            '{}'::jsonb
        ) AS column_comments
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    LEFT JOIN pg_attribute a ON a.attrelid = c.oid
                              AND a.attnum > 0 AND NOT a.attisdropped
    LEFT JOIN LATERAL (
        SELECT col_description(c.oid, a.attnum) AS comment
    ) d ON true
    WHERE n.nspname = :schema
      AND c.relname = :table
      AND c.relkind IN ('r', 'p')
    GROUP BY c.oid
""")


async def load_pg_comments(
    session: AsyncSession,
    schema: str,
    table: str,
) -> tuple[str | None, dict[str, str]]:
    """Read (table_comment, {column_name: column_comment}) from pg_description.

    Issues a single SELECT against PostgreSQL system catalog (pg_class /
    pg_attribute / pg_description). Process-local TTL cache by ``(schema, table)``.

    Args:
        session: Async SQLAlchemy session connected to PostgreSQL.
        schema: PostgreSQL schema name (e.g. ``"lead"``).
        table: Table name (e.g. ``"emails_messages"``).

    Returns:
        Tuple ``(table_comment, column_comments_dict)``. ``table_comment``
        is ``None`` if no ``COMMENT ON TABLE`` was set. The dict only
        contains entries for columns that have a non-null comment.

    Raises:
        ValueError: If the table is not found in ``pg_catalog``
            (relkind 'r' or 'p'). This is fail-loud on purpose — silent
            ``(None, {})`` would mask configuration bugs (typos in
            ``__tablename__``, missing migrations, wrong schema).
    """
    key = (schema, table)
    now = time.monotonic()
    cached = _meta_cache.get(key)
    if cached and (now - cached[0]) < _DEFAULT_CACHE_TTL:
        return cached[1], cached[2]

    row = (
        await session.execute(_PG_META_SQL, {"schema": schema, "table": table})
    ).mappings().first()
    if row is None:
        msg = (
            f"Table {schema}.{table} not found in pg_catalog "
            f"(check __tablename__, schema, and migrations)"
        )
        raise ValueError(msg)

    table_comment = row["table_comment"]
    column_comments = dict(row["column_comments"] or {})
    _meta_cache[key] = (now, table_comment, column_comments)
    return table_comment, column_comments


# ─────────────────────────────────────────────────────────────────────────────
# SA type / FK derivation
# ─────────────────────────────────────────────────────────────────────────────

# SA column type → frontend ColumnType mapping.
# Order matters: Boolean must come BEFORE Integer because Python's `bool`
# is a subclass of `int` and SA's Boolean would otherwise match Integer first.
# Unknown types fall back to ColumnType.STRING in _resolve_column_type().
SA_TYPE_MAP: list[tuple[type | tuple[type, ...], ColumnType]] = [
    (Boolean, ColumnType.BOOLEAN),
    (DateTime, ColumnType.DATETIME),
    (Date, ColumnType.DATE),
    ((Integer, BigInteger, SmallInteger), ColumnType.INTEGER),
    ((Numeric, Float), ColumnType.FLOAT),
    ((String, Text, Enum, Interval, ARRAY, Uuid), ColumnType.STRING),
]


def _resolve_column_type(sa_type: Any) -> ColumnType:
    """Map a SQLAlchemy column type to a UI ``ColumnType``.

    Falls back to ``ColumnType.STRING`` for unknown types (forward compatible
    with custom types — frontend treats them as plain text).
    """
    for sa_types, ct in SA_TYPE_MAP:
        if isinstance(sa_type, sa_types):
            return ct
    return ColumnType.STRING


def _resolve_lookup(sa_column: Any) -> tuple[str | None, str | None]:
    """Derive ``(lookup_dict, lookup_path)`` from a FK on a ``*_lkp`` table.

    Convention: ``lookup_dict = {target_schema}_{target_table_name minus _lkp suffix}``.
    Example: FK on ``lead.email_types_lkp.id`` → ``("lead_email_types", <fk_col_name>)``.

    Returns ``(None, None)`` if the column has no FK to a ``*_lkp`` table —
    so callers can always use plain tuple unpacking.
    """
    for fk in sa_column.foreign_keys:
        target = fk.column.table
        if target.name.endswith("_lkp"):
            base = target.name.removesuffix("_lkp")
            schema = target.schema or ""
            return f"{schema}_{base}" if schema else base, sa_column.name
    return None, None


# ─────────────────────────────────────────────────────────────────────────────
# Extended pg_description format parser (per-role overrides)
# See column-meta-report.md section 12 for full grammar.
# ─────────────────────────────────────────────────────────────────────────────

def _parse_extended_comment(comment: str | None) -> dict[str, str]:
    """Parse extended pg_description format with ``||`` separator.

    Format::

        default[||key=value][||key=value]...

    Examples::

        'Тип письма'                                  → {'default': 'Тип письма'}
        'Тип письма||operator=Категория'              → {'default': 'Тип письма',
                                                          'operator': 'Категория'}
        'Шаблоны||row_link=/x||row_link.operator=/y'  → {'default': 'Шаблоны',
                                                          'row_link': '/x',
                                                          'row_link.operator': '/y'}

    Args:
        comment: Raw comment string from ``pg_description``, or ``None``.

    Returns:
        Dict with always-present ``'default'`` key (may be empty string)
        and arbitrary other keys from ``key=value`` overrides.

    Raises:
        ValueError: If an override segment after ``||`` does not contain ``=``.
    """
    if not comment:
        return {"default": ""}
    parts = comment.split("||")
    result: dict[str, str] = {"default": parts[0]}
    for part in parts[1:]:
        if "=" not in part:
            msg = (
                f"Invalid override {part!r} in pg_description: "
                f"expected 'key=value' form"
            )
            raise ValueError(msg)
        key, value = part.split("=", 1)
        result[key] = value
    return result


def _resolve_label_with_role(comment: str | None, role_type: str | None) -> str | None:
    """Pick a label from an extended comment, applying per-role override if matching.

    If ``role_type`` is set and the parsed comment has a key equal to ``role_type``,
    its value wins. Otherwise the default segment is returned (or ``None`` if empty).
    """
    parsed = _parse_extended_comment(comment)
    if role_type and role_type in parsed:
        return parsed[role_type]
    return parsed["default"] or None


def _resolve_row_link_with_role(table_comment: str | None, role_type: str | None) -> str | None:
    """Extract ``row_link`` from a table comment, with per-role override support.

    Looks up ``row_link.<role_type>`` first (if ``role_type`` is set), then falls
    back to the plain ``row_link`` key. Returns ``None`` if neither is present.
    """
    parsed = _parse_extended_comment(table_comment)
    if role_type:
        per_role_key = f"row_link.{role_type}"
        if per_role_key in parsed:
            return parsed[per_role_key]
    return parsed.get("row_link")


# ─────────────────────────────────────────────────────────────────────────────
# High-level builder
# ─────────────────────────────────────────────────────────────────────────────

type ColumnEntry = str | ColumnMeta


async def build_dynamic_meta[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    *,
    name: str,
    columns: list[ColumnEntry],
    header: str | None = None,
    row_link: str | None = None,
    role_type: str | None = None,
) -> tuple[TableMeta, list[ColumnMeta]]:
    """Build ``TableMeta`` + ``list[ColumnMeta]`` for a SQLModel-backed list endpoint.

    Each entry in ``columns`` is either:

    - **A plain string** — physical column name. Everything (``label``, ``type``,
      ``lookup_dict``, ``lookup_path``) is derived from the model and pg_description.
      ``label`` precedence: ``pg_description`` > ``model.col.comment`` >
      ``ValueError``. ``type`` derived from SA column type. ``lookup_dict`` /
      ``lookup_path`` derived from FK on a ``*_lkp`` table by convention.

    - **A fully-specified** ``ColumnMeta`` **instance** — used as-is, nothing
      derived. Required for **virtual columns** (paths with ``.`` traversing
      relationships, e.g. ``"last_editor.user_name"``) since there's no physical
      column to introspect. Also useful for fully overriding a physical column.

    Header precedence (high → low):
        1. ``header`` argument (explicit code-side override)
        2. ``pg_description`` (DBA edit via ``COMMENT ON TABLE``, with per-role
           ``||`` format support)
        3. ``model.__table__.comment`` (from ``__table_args__["comment"]``)
        4. ``ValueError`` if all are missing

    row_link precedence (high → low):
        1. ``row_link`` argument
        2. Extended ``COMMENT ON TABLE`` format (key ``row_link`` or
           ``row_link.<role_type>``)
        3. ``None`` (no link)

    Args:
        session: Async SQLAlchemy session for the pg_description query.
        model: SQLModel class backing the table. Must have explicit
            ``__table_args__`` with a ``schema`` set.
        name: API contract identifier (frontend localStorage key for user
            settings). Required, no auto-derive.
        columns: Ordered list of column entries (str or ``ColumnMeta``).
        header: Optional explicit header text. If ``None``, falls back to
            pg_description and then to model's table comment.
        row_link: Optional explicit frontend SPA route template like
            ``"/lead/$id"``. If ``None``, falls back to extended
            ``COMMENT ON TABLE`` format.
        role_type: Optional role identifier (e.g. ``"operator"``, ``"buh"``).
            When set, extended ``||`` overrides for the matching role take effect.

    Returns:
        Tuple of ``(TableMeta, list[ColumnMeta])`` ready to assign to a
        ``GetAllPagination[T]`` response.

    Raises:
        ValueError: If the model has no explicit schema in ``__table_args__``,
            if the table is not found in pg_catalog, if a physical column has
            no label in any source, if a physical column name is not found in
            the model (likely a typo), if header is missing in all sources,
            or if an extended-format override segment is malformed.
    """
    table = model.__table__
    schema = table.schema

    if schema is None:
        msg = (
            f"{model.__name__}: model has no explicit schema — "
            f"set __table_args__ = {{'schema': '...', ...}} on the model. "
            f"build_dynamic_meta needs schema to query pg_catalog."
        )
        raise ValueError(msg)

    pg_table_comment, pg_column_comments = await load_pg_comments(session, schema, table.name)

    # Header: explicit arg > pg_description (with optional per-role parsing) > model fallback
    final_header = (
        header
        or _resolve_label_with_role(pg_table_comment, role_type)
        or table.comment
    )
    if final_header is None:
        msg = (
            f"{model.__name__}: header is missing — pass header=... explicitly, "
            f"or set pg_description on {schema}.{table.name} via COMMENT ON TABLE, "
            f"or set __table_args__['comment'] in the model"
        )
        raise ValueError(msg)

    table_meta = TableMeta(
        name=name,
        header=final_header,
        # row_link: explicit arg > extended COMMENT ON TABLE format > None
        row_link=row_link or _resolve_row_link_with_role(pg_table_comment, role_type),
    )

    sa_columns = {c.name: c for c in table.columns}
    out: list[ColumnMeta] = []

    for entry in columns:
        if isinstance(entry, ColumnMeta):
            # Fully-specified ColumnMeta — used as-is. Required for virtual
            # columns (relationship traversal) and full overrides.
            out.append(entry)
            continue

        # str entry — physical column, derive everything
        json_path = entry
        sa_col = sa_columns.get(json_path)

        if sa_col is None:
            # Distinguish typo from "needs to be a ColumnMeta"
            if "." in json_path:
                raise ValueError(
                    f"{model.__name__}: virtual column {json_path!r} cannot be "
                    f"a plain string in `columns`. Pass a fully-specified "
                    f"ColumnMeta(json_path=..., label=..., type=...) instead."
                )
            raise ValueError(
                f"{model.__name__}: physical column {json_path!r} not found "
                f"in {schema}.{table.name}. Available columns: "
                f"{', '.join(sa_columns.keys())}. "
                f"For virtual columns (through relationships), use a "
                f"fully-specified ColumnMeta with dot-notation json_path."
            )

        # 2-level precedence for physical column label
        label = (
            _resolve_label_with_role(pg_column_comments.get(json_path), role_type)
            or sa_col.comment
        )
        if not label:
            raise ValueError(
                f"{model.__name__}.{json_path}: label is missing — "
                f"set COMMENT ON COLUMN via SQL, or Column(comment=...) in the "
                f"model, or pass a fully-specified ColumnMeta in `columns`"
            )

        lookup_dict, lookup_path = _resolve_lookup(sa_col)
        out.append(
            ColumnMeta(
                json_path=json_path,
                label=label,
                type=_resolve_column_type(sa_col.type),
                lookup_dict=lookup_dict,
                lookup_path=lookup_path,
            )
        )

    return table_meta, out
