"""Tests for FilterDatetimeRange and FilterNaiveDatetimeRange."""

from datetime import datetime, UTC

import pytest
from pydantic import ValidationError

import sqlmodel_object_helpers as soh


# =============================================================================
# FilterDatetimeRange — string parsing
# =============================================================================


class TestFilterDatetimeRangeFromString:
    """Test parsing range strings into FilterDatetimeRange."""

    def test_full_range_iso(self):
        """'FROM,TO' in ISO format produces gt + lt."""
        f = soh.FilterDatetimeRange.model_validate("2026-01-01,2026-01-31")
        assert f.gt == datetime(2026, 1, 1, 0, 0, tzinfo=UTC)
        assert f.lt == datetime(2026, 1, 31, 0, 0, tzinfo=UTC)

    def test_open_end(self):
        """'FROM,' produces gt only."""
        f = soh.FilterDatetimeRange.model_validate("2026-01-01,")
        assert f.gt == datetime(2026, 1, 1, 0, 0, tzinfo=UTC)
        assert f.lt is None

    def test_open_start(self):
        """',TO' produces lt only."""
        f = soh.FilterDatetimeRange.model_validate(",2026-01-01")
        assert f.gt is None
        assert f.lt == datetime(2026, 1, 1, 0, 0, tzinfo=UTC)

    def test_iso_datetime_with_tz(self):
        """ISO datetime with timezone is parsed and converted to UTC."""
        f = soh.FilterDatetimeRange.model_validate(
            "2026-04-01T00:00:00.000Z,2026-04-02T00:00:00.000Z"
        )
        assert f.gt == datetime(2026, 4, 1, 0, 0, tzinfo=UTC)
        assert f.lt == datetime(2026, 4, 2, 0, 0, tzinfo=UTC)

    def test_iso_datetime_with_offset(self):
        """ISO datetime with +03:00 offset is converted to UTC."""
        f = soh.FilterDatetimeRange.model_validate(
            "2026-04-01T03:00:00+03:00,"
        )
        assert f.gt == datetime(2026, 4, 1, 0, 0, tzinfo=UTC)

    def test_display_format(self):
        """Russian display format DD.MM.YYYY HH:MM is accepted."""
        f = soh.FilterDatetimeRange.model_validate("01.01.2026 00:00,31.01.2026 00:00")
        assert f.gt == datetime(2026, 1, 1, 0, 0, tzinfo=UTC)
        assert f.lt == datetime(2026, 1, 31, 0, 0, tzinfo=UTC)

    def test_display_format_with_seconds(self):
        """DD.MM.YYYY HH:MM:SS is accepted."""
        f = soh.FilterDatetimeRange.model_validate("01.01.2026 00:00:00,31.01.2026 23:59:59")
        assert f.gt == datetime(2026, 1, 1, 0, 0, 0, tzinfo=UTC)
        assert f.lt == datetime(2026, 1, 31, 23, 59, 59, tzinfo=UTC)

    def test_date_only_format(self):
        """DD.MM.YYYY without time is accepted."""
        f = soh.FilterDatetimeRange.model_validate("01.04.2026,30.04.2026")
        assert f.gt == datetime(2026, 4, 1, 0, 0, tzinfo=UTC)
        assert f.lt == datetime(2026, 4, 30, 0, 0, tzinfo=UTC)

    def test_whitespace_trimmed(self):
        """Leading/trailing whitespace is stripped."""
        f = soh.FilterDatetimeRange.model_validate("  2026-01-01 , 2026-02-01  ")
        assert f.gt == datetime(2026, 1, 1, 0, 0, tzinfo=UTC)
        assert f.lt == datetime(2026, 2, 1, 0, 0, tzinfo=UTC)

    def test_results_are_utc(self):
        """Parsed datetimes have UTC timezone."""
        f = soh.FilterDatetimeRange.model_validate("2026-06-15,")
        assert f.gt.tzinfo == UTC

    def test_real_frontend_payload(self):
        """Exact format from the frontend screenshot — same date both sides."""
        f = soh.FilterDatetimeRange.model_validate("2026-04-01,2026-04-01")
        assert f.gt == datetime(2026, 4, 1, 0, 0, tzinfo=UTC)
        assert f.lt == datetime(2026, 4, 1, 0, 0, tzinfo=UTC)


class TestTeamLeadCases:
    """
    Three exact cases from team lead:
        1) 01.01.2026 00:00-   → ray to +∞ (gt only)
        2) -01.01.2026 00:00   → ray to -∞ (lt only)
        3) 01.01.2026 00:00-31.01.2026 00:00 → full range (gt + lt)

    In soh the separator is comma, so:
        1) "01.01.2026 00:00,"
        2) ",01.01.2026 00:00"
        3) "01.01.2026 00:00,31.01.2026 00:00"
    """

    def test_case1_ray_to_infinity(self):
        """01.01.2026 00:00- → gt only, open end."""
        f = soh.FilterDatetimeRange.model_validate("01.01.2026 00:00,")
        assert f.gt == datetime(2026, 1, 1, 0, 0, tzinfo=UTC)
        assert f.lt is None

        d = f.model_dump(exclude_none=True)
        assert d == {"gt": datetime(2026, 1, 1, 0, 0, tzinfo=UTC)}

    def test_case2_reverse_ray_to_infinity(self):
        """-01.01.2026 00:00 → lt only, open start."""
        f = soh.FilterDatetimeRange.model_validate(",01.01.2026 00:00")
        assert f.gt is None
        assert f.lt == datetime(2026, 1, 1, 0, 0, tzinfo=UTC)

        d = f.model_dump(exclude_none=True)
        assert d == {"lt": datetime(2026, 1, 1, 0, 0, tzinfo=UTC)}

    def test_case3_full_range(self):
        """01.01.2026 00:00-31.01.2026 00:00 → gt + lt."""
        f = soh.FilterDatetimeRange.model_validate("01.01.2026 00:00,31.01.2026 00:00")
        assert f.gt == datetime(2026, 1, 1, 0, 0, tzinfo=UTC)
        assert f.lt == datetime(2026, 1, 31, 0, 0, tzinfo=UTC)

        d = f.model_dump(exclude_none=True)
        assert d == {
            "gt": datetime(2026, 1, 1, 0, 0, tzinfo=UTC),
            "lt": datetime(2026, 1, 31, 0, 0, tzinfo=UTC),
        }

    def test_case1_naive_variant(self):
        """Same as case 1 but with FilterNaiveDatetimeRange."""
        f = soh.FilterNaiveDatetimeRange.model_validate("01.01.2026 00:00,")
        assert f.gt == datetime(2026, 1, 1, 0, 0)
        assert f.gt.tzinfo is None
        assert f.lt is None

    def test_case2_naive_variant(self):
        """Same as case 2 but with FilterNaiveDatetimeRange."""
        f = soh.FilterNaiveDatetimeRange.model_validate(",01.01.2026 00:00")
        assert f.gt is None
        assert f.lt == datetime(2026, 1, 1, 0, 0)
        assert f.lt.tzinfo is None

    def test_case3_naive_variant(self):
        """Same as case 3 but with FilterNaiveDatetimeRange."""
        f = soh.FilterNaiveDatetimeRange.model_validate("01.01.2026 00:00,31.01.2026 00:00")
        assert f.gt == datetime(2026, 1, 1, 0, 0)
        assert f.lt == datetime(2026, 1, 31, 0, 0)
        assert f.gt.tzinfo is None
        assert f.lt.tzinfo is None


class TestFilterDatetimeRangeFromDict:
    """Test creating FilterDatetimeRange from dict — the real frontend JSON path."""

    def test_gt_and_lt(self):
        """Dict with gt + lt ISO strings (frontend JSON payload)."""
        f = soh.FilterDatetimeRange.model_validate(
            {"gt": "2026-01-01T00:00:00Z", "lt": "2026-02-01T00:00:00Z"},
        )
        assert f.gt == datetime(2026, 1, 1, tzinfo=UTC)
        assert f.lt == datetime(2026, 2, 1, tzinfo=UTC)

    def test_gt_only(self):
        f = soh.FilterDatetimeRange.model_validate(
            {"gt": "2026-01-01T00:00:00Z"},
        )
        assert f.gt == datetime(2026, 1, 1, tzinfo=UTC)
        assert f.lt is None

    def test_lt_only(self):
        f = soh.FilterDatetimeRange.model_validate(
            {"lt": "2026-12-31T00:00:00Z"},
        )
        assert f.gt is None
        assert f.lt == datetime(2026, 12, 31, tzinfo=UTC)


class TestFilterDatetimeRangeValidation:
    """Test validation rules."""

    def test_empty_string_rejected(self):
        with pytest.raises(ValidationError):
            soh.FilterDatetimeRange.model_validate("")

    def test_no_comma_rejected(self):
        """String without comma separator is rejected."""
        with pytest.raises(ValidationError):
            soh.FilterDatetimeRange.model_validate("2026-04-01")

    def test_invalid_format_rejected(self):
        with pytest.raises(ValidationError):
            soh.FilterDatetimeRange.model_validate("not-a-date,also-not")

    def test_equal_gt_lt_allowed(self):
        """gt == lt is allowed (single-day selection from frontend)."""
        f = soh.FilterDatetimeRange(
            gt=datetime(2026, 4, 1, tzinfo=UTC),
            lt=datetime(2026, 4, 1, tzinfo=UTC),
        )
        assert f.gt == f.lt

    def test_gt_after_lt_rejected(self):
        with pytest.raises(ValidationError, match="after"):
            soh.FilterDatetimeRange(
                gt=datetime(2026, 12, 31, tzinfo=UTC),
                lt=datetime(2026, 1, 1, tzinfo=UTC),
            )

    def test_both_none_rejected(self):
        """Both sides empty ',' raises ValidationError."""
        with pytest.raises(ValidationError, match="At least one"):
            soh.FilterDatetimeRange.model_validate(",")

    def test_inverted_range_string_rejected(self):
        with pytest.raises(ValidationError, match="after"):
            soh.FilterDatetimeRange.model_validate("2026-12-31,2026-01-01")

    def test_rejects_naive_datetime_in_dict(self):
        with pytest.raises(ValidationError, match="Naive datetime"):
            soh.FilterDatetimeRange(gt=datetime(2026, 1, 1))  # noqa: DTZ001


class TestFilterDatetimeRangeModelDump:
    """Test that model_dump produces operator-compatible dicts."""

    def test_full_range_dump(self):
        f = soh.FilterDatetimeRange.model_validate("2026-01-01,2026-01-31")
        d = f.model_dump(exclude_none=True)
        assert "gt" in d
        assert "lt" in d
        assert len(d) == 2

    def test_open_end_dump(self):
        f = soh.FilterDatetimeRange.model_validate("2026-01-01,")
        d = f.model_dump(exclude_none=True)
        assert "gt" in d
        assert "lt" not in d

    def test_open_start_dump(self):
        f = soh.FilterDatetimeRange.model_validate(",2026-01-01")
        d = f.model_dump(exclude_none=True)
        assert "lt" in d
        assert "gt" not in d


# =============================================================================
# FilterNaiveDatetimeRange
# =============================================================================


class TestFilterNaiveDatetimeRange:
    """Tests for the naive (timezone-unaware) variant."""

    def test_full_range(self):
        f = soh.FilterNaiveDatetimeRange.model_validate("2026-01-01,2026-01-31")
        assert f.gt == datetime(2026, 1, 1, 0, 0)
        assert f.lt == datetime(2026, 1, 31, 0, 0)
        assert f.gt.tzinfo is None
        assert f.lt.tzinfo is None

    def test_open_end(self):
        f = soh.FilterNaiveDatetimeRange.model_validate("2026-01-01,")
        assert f.gt == datetime(2026, 1, 1, 0, 0)
        assert f.lt is None

    def test_open_start(self):
        f = soh.FilterNaiveDatetimeRange.model_validate(",2026-01-01")
        assert f.gt is None
        assert f.lt == datetime(2026, 1, 1, 0, 0)

    def test_display_format(self):
        f = soh.FilterNaiveDatetimeRange.model_validate("01.01.2026 00:00,31.01.2026 23:59:59")
        assert f.gt == datetime(2026, 1, 1, 0, 0)
        assert f.lt == datetime(2026, 1, 31, 23, 59, 59)

    def test_inverted_range_rejected(self):
        with pytest.raises(ValidationError, match="after"):
            soh.FilterNaiveDatetimeRange.model_validate("2026-12-31,2026-01-01")

    def test_model_dump_operators(self):
        f = soh.FilterNaiveDatetimeRange.model_validate("2026-01-01,2026-01-31")
        d = f.model_dump(exclude_none=True)
        assert set(d.keys()) == {"gt", "lt"}

    def test_accepts_dict_input(self):
        """Dict with ISO strings (frontend JSON payload) produces naive datetimes."""
        f = soh.FilterNaiveDatetimeRange.model_validate(
            {"gt": "2026-01-01", "lt": "2026-02-01"},
        )
        assert f.gt == datetime(2026, 1, 1)
        assert f.lt == datetime(2026, 2, 1)
        assert f.gt.tzinfo is None
        assert f.lt.tzinfo is None

    def test_rejects_tz_in_dict_input(self):
        """Dict with timezone-aware ISO strings is rejected (was the 500 bug)."""
        with pytest.raises(ValidationError, match="Timezone-aware datetime is not allowed"):
            soh.FilterNaiveDatetimeRange.model_validate(
                {"gt": "2026-03-20T12:24:00.000+03:00", "lt": "2026-03-20T23:59:59.999+03:00"},
            )

    def test_rejects_tz_in_dict_gt_only(self):
        """Single gt with timezone in dict is rejected."""
        with pytest.raises(ValidationError, match="Timezone-aware datetime is not allowed"):
            soh.FilterNaiveDatetimeRange.model_validate(
                {"gt": "2026-01-01T00:00:00+00:00"},
            )

    def test_rejects_tz_in_string_input(self):
        """String range with timezone offset is rejected."""
        with pytest.raises(ValidationError, match="Timezone-aware datetime is not allowed"):
            soh.FilterNaiveDatetimeRange.model_validate(
                "2026-04-01T03:00:00+03:00,2026-04-02T03:00:00+03:00"
            )

    def test_rejects_z_suffix_in_string_input(self):
        """Z suffix means UTC (timezone-aware) — must be rejected for naive range."""
        with pytest.raises(ValidationError, match="Timezone-aware datetime is not allowed"):
            soh.FilterNaiveDatetimeRange.model_validate(
                "2026-04-01T00:00:00Z,2026-04-02T00:00:00Z"
            )
