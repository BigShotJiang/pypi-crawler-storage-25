"""
Tests for SADataError → InvalidFilterError handling in query.py.

SQLite does not raise sqlalchemy.exc.DataError, so we mock session methods
to simulate the asyncpg DataError that occurs when e.g. a timezone-aware
datetime is sent to a TIMESTAMP WITHOUT TIME ZONE column.

Covers all query entry points: get_objects, count_objects, exists_object, get_projection.
"""

from unittest.mock import AsyncMock, patch

import pytest
from sqlalchemy.exc import DataError as SADataError

import sqlmodel_object_helpers as soh

from conftest import Applicant


pytestmark = pytest.mark.asyncio


def _make_sa_data_error() -> SADataError:
    """Build a realistic SADataError matching the asyncpg timezone mismatch."""
    return SADataError(
        statement="SELECT ... WHERE gp_payment_date = $1::TIMESTAMP WITHOUT TIME ZONE",
        params=(None,),
        orig=Exception(
            "can't subtract offset-naive and offset-aware datetimes"
        ),
    )


# =============================================================================
# get_objects — SADataError → InvalidFilterError(400)
# =============================================================================


async def test_get_objects_data_error_raises_invalid_filter(session):
    """SADataError from DB must be re-raised as InvalidFilterError, not DatabaseError."""
    with patch.object(session, "execute", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        with pytest.raises(soh.InvalidFilterError) as exc_info:
            await soh.get_objects(session, Applicant)

        assert exc_info.value.status_code == 400
        assert "offset-naive and offset-aware" in exc_info.value.message


async def test_get_objects_data_error_suspend_returns_empty(session):
    """SADataError with suspend_error=True returns empty list, not raises."""
    with patch.object(session, "execute", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        result = await soh.get_objects(session, Applicant, suspend_error=True)

    assert result == []


async def test_get_objects_data_error_not_database_error(session):
    """SADataError must NOT become DatabaseError(500)."""
    with patch.object(session, "execute", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        with pytest.raises(soh.InvalidFilterError):
            await soh.get_objects(session, Applicant)

        # Verify it's NOT DatabaseError
        try:
            await soh.get_objects(session, Applicant)
        except soh.DatabaseError:
            pytest.fail("SADataError was incorrectly wrapped as DatabaseError(500)")
        except soh.InvalidFilterError:
            pass  # correct behavior


# =============================================================================
# count_objects — SADataError → InvalidFilterError(400)
# =============================================================================


async def test_count_objects_data_error_raises_invalid_filter(session):
    """SADataError in count_objects must raise InvalidFilterError."""
    with patch.object(session, "scalar", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        with pytest.raises(soh.InvalidFilterError) as exc_info:
            await soh.count_objects(session, Applicant)

        assert exc_info.value.status_code == 400


async def test_count_objects_data_error_suspend_returns_zero(session):
    """SADataError in count_objects with suspend_error=True returns 0."""
    with patch.object(session, "scalar", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        result = await soh.count_objects(session, Applicant, suspend_error=True)

    assert result == 0


# =============================================================================
# exists_object — SADataError → InvalidFilterError(400)
# =============================================================================


async def test_exists_object_data_error_raises_invalid_filter(session):
    """SADataError in exists_object must raise InvalidFilterError."""
    with patch.object(session, "scalar", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        with pytest.raises(soh.InvalidFilterError) as exc_info:
            await soh.exists_object(session, Applicant)

        assert exc_info.value.status_code == 400


async def test_exists_object_data_error_suspend_returns_false(session):
    """SADataError in exists_object with suspend_error=True returns False."""
    with patch.object(session, "scalar", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        result = await soh.exists_object(session, Applicant, suspend_error=True)

    assert result is False


# =============================================================================
# get_projection — SADataError → InvalidFilterError(400)
# =============================================================================


async def test_get_projection_data_error_raises_invalid_filter(session):
    """SADataError in get_projection must raise InvalidFilterError."""
    with patch.object(session, "execute", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        with pytest.raises(soh.InvalidFilterError) as exc_info:
            await soh.get_projection(session, Applicant, columns=["id", "last_name"])

        assert exc_info.value.status_code == 400


async def test_get_projection_data_error_suspend_returns_empty(session):
    """SADataError in get_projection with suspend_error=True returns []."""
    with patch.object(session, "execute", new_callable=AsyncMock, side_effect=_make_sa_data_error()):
        result = await soh.get_projection(
            session, Applicant, columns=["id", "last_name"], suspend_error=True,
        )

    assert result == []


# =============================================================================
# Contrast: non-DataError exceptions still become DatabaseError(500)
# =============================================================================


async def test_generic_exception_still_raises_database_error(session):
    """Non-DataError exceptions must still become DatabaseError(500)."""
    with patch.object(session, "execute", new_callable=AsyncMock, side_effect=RuntimeError("connection lost")):
        with pytest.raises(soh.DatabaseError) as exc_info:
            await soh.get_objects(session, Applicant)

        assert exc_info.value.status_code == 500
        assert "connection lost" in exc_info.value.message
