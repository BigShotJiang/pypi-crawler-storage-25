"""Tests for dynamic_meta: build_dynamic_meta, parsers, type/FK derivation, cache.

Coverage:
- _resolve_column_type: SA types → ColumnType, fallback to STRING
- _resolve_lookup: FK on *_lkp → derived (lookup_dict, lookup_path); non-lkp → (None, None)
- _parse_extended_comment: default only, overrides, edge cases, errors
- _resolve_label_with_role: precedence and fallback semantics
- _resolve_row_link_with_role: row_link / row_link.<role> resolution
- TTL cache: hit/miss/invalidate (full / by-schema / by-table) / configure_ttl
- build_dynamic_meta:
    - 2-level precedence for label (pg_description > model)
    - explicit header / row_link arguments
    - virtual columns via fully-specified ColumnMeta
    - fail-loud on missing label / header / schema / unknown column
    - typo distinction (no dot in path → "did you mean")
    - per-role overrides via || format
    - column ordering preserved
- Compatibility: derived lookup_dict matches existing LookupResponse contract
- load_pg_comments: fail-loud on missing table (raises ValueError)

load_pg_comments against actual PostgreSQL is NOT tested directly here because
the test fixture uses SQLite. Instead, build_dynamic_meta is tested by
monkeypatching load_pg_comments to return controlled values.
"""

import time
from datetime import datetime

import pytest
from sqlalchemy import (
    BigInteger,
    Boolean,
    Date,
    DateTime,
    Enum,
    Float,
    Integer,
    Interval,
    Numeric,
    SmallInteger,
    String,
    Text,
)
from sqlalchemy.types import ARRAY, Uuid
from sqlmodel import Column, Field, SQLModel

import sqlmodel_object_helpers as soh
from sqlmodel_object_helpers import dynamic_meta


_async = pytest.mark.asyncio


# ─────────────────────────────────────────────────────────────────────────────
# _resolve_column_type
# ─────────────────────────────────────────────────────────────────────────────


def test_resolve_column_type_integer():
    assert dynamic_meta._resolve_column_type(Integer()) == soh.ColumnType.INTEGER


def test_resolve_column_type_big_integer():
    assert dynamic_meta._resolve_column_type(BigInteger()) == soh.ColumnType.INTEGER


def test_resolve_column_type_small_integer():
    assert dynamic_meta._resolve_column_type(SmallInteger()) == soh.ColumnType.INTEGER


def test_resolve_column_type_float():
    assert dynamic_meta._resolve_column_type(Float()) == soh.ColumnType.FLOAT


def test_resolve_column_type_numeric():
    assert dynamic_meta._resolve_column_type(Numeric()) == soh.ColumnType.FLOAT


def test_resolve_column_type_boolean():
    assert dynamic_meta._resolve_column_type(Boolean()) == soh.ColumnType.BOOLEAN


def test_resolve_column_type_date():
    assert dynamic_meta._resolve_column_type(Date()) == soh.ColumnType.DATE


def test_resolve_column_type_datetime():
    assert dynamic_meta._resolve_column_type(DateTime()) == soh.ColumnType.DATETIME


def test_resolve_column_type_datetime_with_tz():
    assert dynamic_meta._resolve_column_type(DateTime(timezone=True)) == soh.ColumnType.DATETIME


def test_resolve_column_type_string():
    assert dynamic_meta._resolve_column_type(String()) == soh.ColumnType.STRING


def test_resolve_column_type_text():
    assert dynamic_meta._resolve_column_type(Text()) == soh.ColumnType.STRING


def test_resolve_column_type_enum():
    assert dynamic_meta._resolve_column_type(Enum("a", "b")) == soh.ColumnType.STRING


def test_resolve_column_type_interval():
    assert dynamic_meta._resolve_column_type(Interval()) == soh.ColumnType.STRING


def test_resolve_column_type_array():
    assert dynamic_meta._resolve_column_type(ARRAY(Integer)) == soh.ColumnType.STRING


def test_resolve_column_type_uuid():
    assert dynamic_meta._resolve_column_type(Uuid()) == soh.ColumnType.STRING


def test_resolve_column_type_unknown_falls_back_to_string():
    class CustomType:
        pass

    assert dynamic_meta._resolve_column_type(CustomType()) == soh.ColumnType.STRING


# ─────────────────────────────────────────────────────────────────────────────
# _resolve_lookup
# ─────────────────────────────────────────────────────────────────────────────


class _StatusesLkp(SQLModel, table=True):
    __tablename__ = "statuses_lkp"
    id: int | None = Field(default=None, primary_key=True)
    name: str | None = None


class _UsersForLookupTest(SQLModel, table=True):
    __tablename__ = "users_for_lookup_test"
    id: int | None = Field(default=None, primary_key=True)


class _EmailTypesLkpWithSchema(SQLModel, table=True):
    """Lkp table WITH explicit schema — exercises the `{schema}_{base}` branch.

    This mirrors the production case `lead.email_types_lkp → lead_email_types`
    that drives the entire convention in column-meta-report.md §3.5.
    """

    __tablename__ = "email_types_lkp"
    __table_args__ = {"schema": "lead"}
    id: int | None = Field(default=None, primary_key=True)
    name: str | None = None


class _ModelWithFKs(SQLModel, table=True):
    __tablename__ = "model_with_fks"
    id: int | None = Field(default=None, primary_key=True)
    status_id: int | None = Field(default=None, foreign_key="statuses_lkp.id")
    user_id: int | None = Field(default=None, foreign_key="users_for_lookup_test.id")
    email_type_id: int | None = Field(default=None, foreign_key="lead.email_types_lkp.id")
    plain_int: int | None = None


def test_resolve_lookup_lkp_no_schema():
    col = _ModelWithFKs.__table__.columns["status_id"]
    result = dynamic_meta._resolve_lookup(col)
    assert result == ("statuses", "status_id")


def test_resolve_lookup_non_lkp_fk_returns_none_tuple():
    """FK on a non-lkp table → (None, None) so callers can always tuple-unpack."""
    col = _ModelWithFKs.__table__.columns["user_id"]
    assert dynamic_meta._resolve_lookup(col) == (None, None)


def test_resolve_lookup_no_fk_returns_none_tuple():
    """Column without any FK → (None, None) so callers can always tuple-unpack."""
    col = _ModelWithFKs.__table__.columns["plain_int"]
    assert dynamic_meta._resolve_lookup(col) == (None, None)


def test_resolve_lookup_lkp_with_schema():
    """FK on a *_lkp table with explicit schema → `{schema}_{base}` convention.

    This is the production case for ExamCRM: FK on `lead.email_types_lkp`
    must derive `lookup_dict="lead_email_types"` so it matches what
    `LookupResponse[T].meta.name` returns from the corresponding `/types/`
    endpoint (column-meta-report.md §3.5, "Жёсткий контракт").
    """
    col = _ModelWithFKs.__table__.columns["email_type_id"]
    result = dynamic_meta._resolve_lookup(col)
    assert result == ("lead_email_types", "email_type_id")


# ─────────────────────────────────────────────────────────────────────────────
# _parse_extended_comment
# ─────────────────────────────────────────────────────────────────────────────


def test_parse_default_only():
    assert dynamic_meta._parse_extended_comment("Тип письма") == {"default": "Тип письма"}


def test_parse_default_with_one_override():
    result = dynamic_meta._parse_extended_comment("Тип письма||operator=Категория")
    assert result == {"default": "Тип письма", "operator": "Категория"}


def test_parse_default_with_multiple_overrides():
    result = dynamic_meta._parse_extended_comment("Тип письма||a=1||b=2||c=3")
    assert result == {"default": "Тип письма", "a": "1", "b": "2", "c": "3"}


def test_parse_value_with_single_pipe_inside():
    """Single | is allowed inside values; only || is the separator."""
    result = dynamic_meta._parse_extended_comment("Статус||operator=Активный | приостановлен")
    assert result == {"default": "Статус", "operator": "Активный | приостановлен"}


def test_parse_empty_default():
    """Comment starting with || has empty default."""
    result = dynamic_meta._parse_extended_comment("||operator=X")
    assert result == {"default": "", "operator": "X"}


def test_parse_empty_value():
    """Empty override value is allowed."""
    result = dynamic_meta._parse_extended_comment("X||operator=")
    assert result == {"default": "X", "operator": ""}


def test_parse_override_without_equals_raises():
    with pytest.raises(ValueError, match="expected 'key=value'"):
        dynamic_meta._parse_extended_comment("X||malformed")


def test_parse_trailing_double_pipe_raises():
    """`'X||'` → ['X', ''], empty segment has no `=` → ValueError.

    This catches a typo where someone leaves a dangling `||` at the end
    of a comment, which would otherwise silently produce a confusing parse.
    """
    with pytest.raises(ValueError, match="expected 'key=value'"):
        dynamic_meta._parse_extended_comment("X||")


def test_parse_multiple_consecutive_double_pipes_raises():
    """`'X||||operator=Y'` → ['X', '', 'operator=Y'], empty middle segment raises."""
    with pytest.raises(ValueError, match="expected 'key=value'"):
        dynamic_meta._parse_extended_comment("X||||operator=Y")


def test_parse_value_with_equals_inside():
    """Override value can contain = (split only on first)."""
    result = dynamic_meta._parse_extended_comment("X||key=a=b=c")
    assert result == {"default": "X", "key": "a=b=c"}


def test_parse_none_comment():
    assert dynamic_meta._parse_extended_comment(None) == {"default": ""}


def test_parse_empty_string_comment():
    assert dynamic_meta._parse_extended_comment("") == {"default": ""}


def test_parse_row_link_with_dot_in_key():
    """Per-role row_link uses dot notation: row_link.<role>."""
    result = dynamic_meta._parse_extended_comment(
        "Header||row_link=/x||row_link.operator=/y||row_link.buh=/z"
    )
    assert result == {
        "default": "Header",
        "row_link": "/x",
        "row_link.operator": "/y",
        "row_link.buh": "/z",
    }


# ─────────────────────────────────────────────────────────────────────────────
# _resolve_label_with_role
# ─────────────────────────────────────────────────────────────────────────────


def test_resolve_label_default_no_role():
    assert dynamic_meta._resolve_label_with_role("Тип письма", None) == "Тип письма"


def test_resolve_label_default_with_unknown_role():
    """Unknown role falls back to default."""
    assert dynamic_meta._resolve_label_with_role("Тип письма", "unknown") == "Тип письма"


def test_resolve_label_role_override_matches():
    result = dynamic_meta._resolve_label_with_role(
        "Тип письма||operator=Категория", "operator"
    )
    assert result == "Категория"


def test_resolve_label_role_override_doesnt_match_falls_to_default():
    result = dynamic_meta._resolve_label_with_role(
        "Тип письма||operator=Категория", "buh"
    )
    assert result == "Тип письма"


def test_resolve_label_empty_default_returns_none():
    """Empty default → None (so caller can fall back to model)."""
    assert dynamic_meta._resolve_label_with_role("||operator=X", None) is None
    assert dynamic_meta._resolve_label_with_role("||operator=X", "buh") is None


def test_resolve_label_empty_default_with_matching_role():
    """Empty default but matching role → role value."""
    assert dynamic_meta._resolve_label_with_role("||operator=X", "operator") == "X"


def test_resolve_label_none_comment():
    assert dynamic_meta._resolve_label_with_role(None, None) is None
    assert dynamic_meta._resolve_label_with_role(None, "operator") is None


# ─────────────────────────────────────────────────────────────────────────────
# _resolve_row_link_with_role
# ─────────────────────────────────────────────────────────────────────────────


def test_resolve_row_link_default():
    result = dynamic_meta._resolve_row_link_with_role("Header||row_link=/x", None)
    assert result == "/x"


def test_resolve_row_link_per_role_override():
    result = dynamic_meta._resolve_row_link_with_role(
        "Header||row_link=/x||row_link.operator=/op", "operator"
    )
    assert result == "/op"


def test_resolve_row_link_per_role_unknown_role_falls_to_default():
    result = dynamic_meta._resolve_row_link_with_role(
        "Header||row_link=/x||row_link.operator=/op", "buh"
    )
    assert result == "/x"


def test_resolve_row_link_no_row_link_in_comment():
    assert dynamic_meta._resolve_row_link_with_role("Header", None) is None


def test_resolve_row_link_none_comment():
    assert dynamic_meta._resolve_row_link_with_role(None, None) is None


# ─────────────────────────────────────────────────────────────────────────────
# TTL cache
# ─────────────────────────────────────────────────────────────────────────────


def setup_function():
    """Reset cache and TTL between tests."""
    dynamic_meta.invalidate_meta_cache()
    dynamic_meta.configure_meta_cache_ttl(60)


def test_invalidate_cache_full_clear():
    dynamic_meta._meta_cache[("s1", "t1")] = (time.monotonic(), "h1", {"a": "1"})
    dynamic_meta._meta_cache[("s2", "t2")] = (time.monotonic(), "h2", {"b": "2"})
    dynamic_meta.invalidate_meta_cache()
    assert dynamic_meta._meta_cache == {}


def test_invalidate_cache_single_entry():
    dynamic_meta._meta_cache[("s1", "t1")] = (time.monotonic(), "h1", {})
    dynamic_meta._meta_cache[("s2", "t2")] = (time.monotonic(), "h2", {})
    dynamic_meta.invalidate_meta_cache("s1", "t1")
    assert ("s1", "t1") not in dynamic_meta._meta_cache
    assert ("s2", "t2") in dynamic_meta._meta_cache


def test_invalidate_cache_by_schema_drops_all_entries_in_schema():
    dynamic_meta._meta_cache[("lead", "t1")] = (time.monotonic(), "h", {})
    dynamic_meta._meta_cache[("lead", "t2")] = (time.monotonic(), "h", {})
    dynamic_meta._meta_cache[("main", "t3")] = (time.monotonic(), "h", {})
    dynamic_meta.invalidate_meta_cache(schema="lead")
    assert ("lead", "t1") not in dynamic_meta._meta_cache
    assert ("lead", "t2") not in dynamic_meta._meta_cache
    assert ("main", "t3") in dynamic_meta._meta_cache


def test_invalidate_cache_table_without_schema_raises():
    """Passing only `table` is ambiguous (which schema?) → ValueError."""
    with pytest.raises(ValueError, match="cannot pass `table` without `schema`"):
        dynamic_meta.invalidate_meta_cache(table="t1")


def test_invalidate_cache_nonexistent_entry_no_error():
    dynamic_meta.invalidate_meta_cache("nonexistent", "table")  # should not raise


def test_invalidate_cache_by_schema_no_entries_no_error():
    dynamic_meta.invalidate_meta_cache(schema="empty_schema")  # should not raise


def test_configure_meta_cache_ttl_changes_default():
    dynamic_meta.configure_meta_cache_ttl(30)
    assert dynamic_meta._DEFAULT_CACHE_TTL == 30
    dynamic_meta.configure_meta_cache_ttl(120)
    assert dynamic_meta._DEFAULT_CACHE_TTL == 120


# ─────────────────────────────────────────────────────────────────────────────
# load_pg_comments — TTL cache behavior
#
# load_pg_comments cannot be tested against real PostgreSQL here (the test
# fixture uses SQLite). Instead, we use a fake AsyncSession that records SQL
# calls, returns controllable mappings, and lets us manipulate `time.monotonic`
# to simulate TTL expiry. This exercises the actual cache-check / cache-miss
# branches in the real function (not a monkeypatched stub).
# ─────────────────────────────────────────────────────────────────────────────


class _FakeRow:
    def __init__(self, mapping: dict | None) -> None:
        self._mapping = mapping

    def mappings(self):
        return self

    def first(self):
        return self._mapping


class _FakeRecordingSession:
    """Fake AsyncSession that counts execute() calls and returns canned rows."""

    def __init__(self, mapping: dict | None) -> None:
        self.mapping = mapping
        self.execute_count = 0

    async def execute(self, sql, params):  # noqa: ARG002 — match real signature
        self.execute_count += 1
        return _FakeRow(self.mapping)


@_async
async def test_load_pg_comments_cache_hit_short_circuits_sql(monkeypatch):
    """Within TTL, a second call must NOT execute SQL — pure cache hit."""
    session = _FakeRecordingSession(
        mapping={"table_comment": "Header", "column_comments": {"id": "ID"}},
    )

    # First call — cache miss, hits SQL
    table_comment, cols = await dynamic_meta.load_pg_comments(session, "s", "t")
    assert session.execute_count == 1
    assert table_comment == "Header"
    assert cols == {"id": "ID"}

    # Second call — should be served from cache, no SQL
    table_comment2, cols2 = await dynamic_meta.load_pg_comments(session, "s", "t")
    assert session.execute_count == 1  # unchanged
    assert table_comment2 == "Header"
    assert cols2 == {"id": "ID"}


@_async
async def test_load_pg_comments_cache_expiry_refetches(monkeypatch):
    """After TTL expiry, the next call must re-execute SQL."""
    session = _FakeRecordingSession(
        mapping={"table_comment": "Header", "column_comments": {"id": "ID"}},
    )

    # Pin time. Each subsequent call returns the value of `current[0]`.
    current = [1000.0]
    monkeypatch.setattr(dynamic_meta.time, "monotonic", lambda: current[0])
    dynamic_meta.configure_meta_cache_ttl(60)

    # t=1000: cache miss → SQL
    await dynamic_meta.load_pg_comments(session, "s", "t")
    assert session.execute_count == 1

    # t=1030 (within TTL): cache hit → no SQL
    current[0] = 1030.0
    await dynamic_meta.load_pg_comments(session, "s", "t")
    assert session.execute_count == 1

    # t=1061 (just past TTL): cache miss → SQL again
    current[0] = 1061.0
    await dynamic_meta.load_pg_comments(session, "s", "t")
    assert session.execute_count == 2


@_async
async def test_load_pg_comments_cache_per_key_isolation():
    """Different (schema, table) keys must not share cache entries."""
    session_a = _FakeRecordingSession(
        mapping={"table_comment": "A", "column_comments": {}},
    )
    session_b = _FakeRecordingSession(
        mapping={"table_comment": "B", "column_comments": {}},
    )

    a, _ = await dynamic_meta.load_pg_comments(session_a, "s1", "t1")
    b, _ = await dynamic_meta.load_pg_comments(session_b, "s2", "t2")
    assert a == "A"
    assert b == "B"
    assert session_a.execute_count == 1
    assert session_b.execute_count == 1


@_async
async def test_load_pg_comments_invalidate_forces_refetch():
    """invalidate_meta_cache() between calls forces a fresh SQL execution."""
    session = _FakeRecordingSession(
        mapping={"table_comment": "Header", "column_comments": {}},
    )
    await dynamic_meta.load_pg_comments(session, "s", "t")
    assert session.execute_count == 1

    dynamic_meta.invalidate_meta_cache("s", "t")

    await dynamic_meta.load_pg_comments(session, "s", "t")
    assert session.execute_count == 2


@_async
async def test_load_pg_comments_table_not_found_raises():
    """Real fail-loud path: SQL returns no row → ValueError, not silent (None, {})."""
    session = _FakeRecordingSession(mapping=None)  # SELECT returns no row

    with pytest.raises(ValueError, match="not found in pg_catalog"):
        await dynamic_meta.load_pg_comments(session, "missing_schema", "missing_table")


@_async
async def test_load_pg_comments_handles_null_column_comments_jsonb():
    """SQL COALESCEs NULL → '{}'::jsonb. Verify dict() conversion still works."""
    session = _FakeRecordingSession(
        mapping={"table_comment": None, "column_comments": None},
    )
    table_comment, cols = await dynamic_meta.load_pg_comments(session, "s", "t")
    assert table_comment is None
    assert cols == {}


# ─────────────────────────────────────────────────────────────────────────────
# build_dynamic_meta — using monkeypatched load_pg_comments
# ─────────────────────────────────────────────────────────────────────────────


class _BuildTestModel(SQLModel, table=True):
    __tablename__ = "build_test_model"
    __table_args__ = {"schema": "test_schema", "comment": "Тестовая таблица"}

    id: int | None = Field(
        default=None, primary_key=True,
        sa_column_kwargs={"comment": "ID"},
    )
    status_id: int | None = Field(
        default=None,
        foreign_key="statuses_lkp.id",
        sa_column_kwargs={"comment": "Статус"},
    )
    name: str | None = Field(default=None, sa_column_kwargs={"comment": "Имя"})
    is_active: bool | None = Field(default=None, sa_column_kwargs={"comment": "Активен"})
    created_at: datetime | None = Field(
        default=None,
        sa_column=Column(DateTime(timezone=True), comment="Создано"),
    )
    raw_no_comment: str | None = None  # NO comment in model — for fail-loud test


class _NoSchemaModel(SQLModel, table=True):
    __tablename__ = "no_schema_model"
    # NO __table_args__ — to test schema-guard
    id: int | None = Field(default=None, primary_key=True, sa_column_kwargs={"comment": "ID"})


class _NoHeaderModel(SQLModel, table=True):
    __tablename__ = "no_header_model"
    __table_args__ = {"schema": "test_schema"}
    # NO comment in __table_args__ — to test header-missing fail-loud
    id: int | None = Field(default=None, primary_key=True, sa_column_kwargs={"comment": "ID"})


class _FakeSession:
    """Minimal fake session that satisfies the AsyncSession interface used."""


def _patch_load_pg_comments(
    monkeypatch,
    table_comment=None,
    column_comments=None,
    raise_value_error: bool = False,
):
    """Replace load_pg_comments with a controlled coroutine for tests."""

    async def fake_load(session, schema, table):
        if raise_value_error:
            raise ValueError(f"Table {schema}.{table} not found in pg_catalog")
        return table_comment, dict(column_comments or {})

    monkeypatch.setattr(dynamic_meta, "load_pg_comments", fake_load)


@_async
async def test_build_meta_all_from_model_fallback(monkeypatch):
    """pg_description пуст для всех колонок и таблицы → fallback на model."""
    _patch_load_pg_comments(monkeypatch, table_comment=None, column_comments={})

    table_meta, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="build_test",
        columns=["id", "status_id", "name", "is_active", "created_at"],
    )

    assert table_meta.name == "build_test"
    assert table_meta.header == "Тестовая таблица"  # from __table_args__
    assert table_meta.row_link is None

    labels = {c.json_path: c.label for c in columns}
    assert labels == {
        "id": "ID",
        "status_id": "Статус",
        "name": "Имя",
        "is_active": "Активен",
        "created_at": "Создано",
    }


@_async
async def test_build_meta_pg_description_overrides_model(monkeypatch):
    """pg_description значения побеждают model defaults."""
    _patch_load_pg_comments(
        monkeypatch,
        table_comment="Header from DB",
        column_comments={
            "id": "ID from DB",
            "name": "Name from DB",
        },
    )

    table_meta, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["id", "status_id", "name"],
    )

    assert table_meta.header == "Header from DB"
    labels = {c.json_path: c.label for c in columns}
    assert labels["id"] == "ID from DB"
    assert labels["status_id"] == "Статус"  # not in DB → falls back to model
    assert labels["name"] == "Name from DB"


@_async
async def test_build_meta_explicit_header_argument_wins(monkeypatch):
    """header= аргумент побеждает и pg_description, и model.__table__.comment."""
    _patch_load_pg_comments(
        monkeypatch,
        table_comment="Header from DB",
    )

    table_meta, _ = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["id"],
        header="Header from arg",
    )
    assert table_meta.header == "Header from arg"


@_async
async def test_build_meta_full_column_meta_used_as_is(monkeypatch):
    """Полностью описанная ColumnMeta в columns добавляется как есть, ничего не deriv'ится."""
    _patch_load_pg_comments(
        monkeypatch,
        column_comments={"id": "ID from DB"},
    )

    custom = soh.ColumnMeta(
        json_path="id",
        label="Override label",
        type=soh.ColumnType.STRING,  # intentionally wrong type — should NOT be re-derived
        lookup_dict="custom",
        lookup_path="custom_id",
    )
    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=[custom],
    )
    # Used verbatim
    assert columns[0] is custom
    assert columns[0].label == "Override label"
    assert columns[0].type == soh.ColumnType.STRING
    assert columns[0].lookup_dict == "custom"


@_async
async def test_build_meta_type_derived_from_sa(monkeypatch):
    _patch_load_pg_comments(monkeypatch)

    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["id", "name", "is_active", "created_at"],
    )
    types = {c.json_path: c.type for c in columns}
    assert types["id"] == soh.ColumnType.INTEGER
    assert types["name"] == soh.ColumnType.STRING
    assert types["is_active"] == soh.ColumnType.BOOLEAN
    assert types["created_at"] == soh.ColumnType.DATETIME


@_async
async def test_build_meta_lookup_derived_from_fk(monkeypatch):
    _patch_load_pg_comments(monkeypatch)

    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["status_id"],
    )
    by_path = {c.json_path: c for c in columns}
    assert by_path["status_id"].lookup_dict == "statuses"
    assert by_path["status_id"].lookup_path == "status_id"


@_async
async def test_build_meta_virtual_column_via_full_column_meta(monkeypatch):
    """Виртуальная колонка через ColumnMeta — обязательно полностью описана."""
    _patch_load_pg_comments(monkeypatch)

    virtual = soh.ColumnMeta(
        json_path="last_editor.user_name",
        label="Редактор",
        type=soh.ColumnType.STRING,
    )
    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["id", virtual, "name"],
    )
    assert len(columns) == 3
    assert columns[1].json_path == "last_editor.user_name"
    assert columns[1].label == "Редактор"
    assert columns[1].type == soh.ColumnType.STRING


@_async
async def test_build_meta_virtual_column_as_string_raises_helpful_error(monkeypatch):
    """Виртуальная колонка (с точкой) переданная строкой → понятное сообщение."""
    _patch_load_pg_comments(monkeypatch)

    with pytest.raises(ValueError, match="virtual column .* cannot be a plain string"):
        await dynamic_meta.build_dynamic_meta(
            _FakeSession(),
            _BuildTestModel,
            name="x",
            columns=["last_editor.user_name"],
        )


@_async
async def test_build_meta_typo_in_physical_column_raises_helpful_error(monkeypatch):
    """Опечатка в имени физической колонки → отдельное сообщение с available list."""
    _patch_load_pg_comments(monkeypatch)

    with pytest.raises(ValueError, match="not found.*Available columns"):
        await dynamic_meta.build_dynamic_meta(
            _FakeSession(),
            _BuildTestModel,
            name="x",
            columns=["nme"],  # опечатка: должно быть "name"
        )


@_async
async def test_build_meta_physical_column_no_label_anywhere_raises(monkeypatch):
    """Физическая колонка без comment в модели и в pg_description → ValueError."""
    _patch_load_pg_comments(monkeypatch)

    with pytest.raises(ValueError, match="label is missing"):
        await dynamic_meta.build_dynamic_meta(
            _FakeSession(),
            _BuildTestModel,
            name="x",
            columns=["raw_no_comment"],
        )


@_async
async def test_build_meta_header_missing_raises(monkeypatch):
    """Если в pg_description нет header И __table_args__['comment'] не задан → ValueError."""
    _patch_load_pg_comments(monkeypatch)

    with pytest.raises(ValueError, match="header is missing"):
        await dynamic_meta.build_dynamic_meta(
            _FakeSession(),
            _NoHeaderModel,
            name="x",
            columns=["id"],
        )


@_async
async def test_build_meta_no_schema_raises(monkeypatch):
    """Модель без явной схемы → ValueError с подсказкой про __table_args__."""
    _patch_load_pg_comments(monkeypatch)

    with pytest.raises(ValueError, match="model has no explicit schema"):
        await dynamic_meta.build_dynamic_meta(
            _FakeSession(),
            _NoSchemaModel,
            name="x",
            columns=["id"],
        )


@_async
async def test_build_meta_per_role_label_override(monkeypatch):
    """Per-role override в pg_description через || формат."""
    _patch_load_pg_comments(
        monkeypatch,
        column_comments={"name": "Имя||operator=Логин||buh=Реквизит"},
    )

    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["name"],
        role_type="operator",
    )
    assert columns[0].label == "Логин"

    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["name"],
        role_type="buh",
    )
    assert columns[0].label == "Реквизит"

    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["name"],
        role_type="admin",  # not in overrides → default
    )
    assert columns[0].label == "Имя"


@_async
async def test_build_meta_per_role_row_link(monkeypatch):
    _patch_load_pg_comments(
        monkeypatch,
        table_comment="Заявки||row_link=/app/$id||row_link.operator=/op/$id||row_link.buh=/buh/$id",
    )

    table_meta, _ = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["id"],
        role_type="operator",
    )
    assert table_meta.row_link == "/op/$id"

    table_meta, _ = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["id"],
        role_type=None,
    )
    assert table_meta.row_link == "/app/$id"


@_async
async def test_build_meta_explicit_row_link_arg_wins_over_pg_description(monkeypatch):
    """Явный row_link= аргумент побеждает значение из COMMENT ON TABLE."""
    _patch_load_pg_comments(
        monkeypatch,
        table_comment="Header||row_link=/from-db",
    )

    table_meta, _ = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["id"],
        row_link="/from-arg",
    )
    assert table_meta.row_link == "/from-arg"


@_async
async def test_build_meta_preserves_column_order(monkeypatch):
    _patch_load_pg_comments(monkeypatch)

    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["created_at", "name", "id", "is_active"],
    )
    assert [c.json_path for c in columns] == ["created_at", "name", "id", "is_active"]


@_async
async def test_build_meta_load_pg_comments_propagates_value_error(monkeypatch):
    """Если load_pg_comments raises (table not in pg_catalog), ошибка пробрасывается."""
    _patch_load_pg_comments(monkeypatch, raise_value_error=True)

    with pytest.raises(ValueError, match="not found in pg_catalog"):
        await dynamic_meta.build_dynamic_meta(
            _FakeSession(),
            _BuildTestModel,
            name="x",
            columns=["id"],
        )


# ─────────────────────────────────────────────────────────────────────────────
# Compatibility test: derived lookup_dict matches LookupResponse contract
# ─────────────────────────────────────────────────────────────────────────────


@_async
async def test_lookup_convention_matches_existing_lookup_response(monkeypatch):
    """Convention check: derived lookup_dict from FK on `*_lkp` table
    matches the name used by LookupResponse[T] / LookupMeta in client routers.

    For a FK on ``statuses_lkp.id`` (no schema), derived value should be
    ``"statuses"`` — matches the convention enforced by
    ``test_lookup_response_meta_matches_column_meta_lookup_dict`` in v0.0.5.
    """
    _patch_load_pg_comments(monkeypatch)

    _, columns = await dynamic_meta.build_dynamic_meta(
        _FakeSession(),
        _BuildTestModel,
        name="x",
        columns=["status_id"],
    )
    derived = columns[0].lookup_dict

    # In v0.0.5 test_column_meta.py:498-511 enforces that
    # ColumnMeta.lookup_dict == LookupResponse.meta.name. The convention
    # `{schema}_{base_without_lkp}` (or just `{base}` when no schema)
    # must produce the same string.
    expected = "statuses"
    assert derived == expected


# ─────────────────────────────────────────────────────────────────────────────
# standalone.build_dynamic_meta — auto-session wrapper
#
# This is the path actually used by routers (e.g. exam-crm-core's r_emails.py):
#     soh_sa.build_dynamic_meta(EmailLeadMessage, name="...", columns=[...])
# It opens its own session via auto_session() instead of taking one as an arg.
# ─────────────────────────────────────────────────────────────────────────────


@_async
async def test_standalone_build_dynamic_meta_uses_auto_session(monkeypatch):
    """soh_sa.build_dynamic_meta opens its own session and delegates to the core."""
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    import sqlmodel_object_helpers as soh_pkg
    import sqlmodel_object_helpers.standalone as soh_sa

    # Need a real (but cheap) session factory so auto_session() can open one.
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    factory = async_sessionmaker(engine, expire_on_commit=False)
    soh_pkg.configure(factory)

    try:
        # Replace pg_description loader (SQLite has no pg_catalog) — the
        # standalone wrapper still owns the session lifecycle, we just don't
        # want it to actually issue the pg_catalog SELECT.
        _patch_load_pg_comments(
            monkeypatch,
            table_comment="Standalone header",
            column_comments={"id": "Standalone ID"},
        )

        table_meta, columns = await soh_sa.build_dynamic_meta(
            _BuildTestModel,
            name="standalone_test",
            columns=["id"],
        )

        assert table_meta.name == "standalone_test"
        assert table_meta.header == "Standalone header"
        assert columns[0].label == "Standalone ID"
        assert columns[0].type == soh.ColumnType.INTEGER
    finally:
        soh_pkg.settings.session_factory = None
        await engine.dispose()


@_async
async def test_standalone_build_dynamic_meta_propagates_value_error(monkeypatch):
    """Errors raised inside build_dynamic_meta surface through the standalone wrapper."""
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    import sqlmodel_object_helpers as soh_pkg
    import sqlmodel_object_helpers.standalone as soh_sa

    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    factory = async_sessionmaker(engine, expire_on_commit=False)
    soh_pkg.configure(factory)

    try:
        _patch_load_pg_comments(monkeypatch)
        with pytest.raises(ValueError, match="label is missing"):
            await soh_sa.build_dynamic_meta(
                _BuildTestModel,
                name="x",
                columns=["raw_no_comment"],  # no comment in any source
            )
    finally:
        soh_pkg.settings.session_factory = None
        await engine.dispose()
