"""Tests for column and table metadata types (columns.py, pagination.py).

Tests cover:
- ColumnType enum values
- BoolLabels creation and validation
- TableMeta creation and validation
- ColumnMeta with all fields (json_path, label, type, lookup_dict, lookup_path, bool_labels)
- GetAllPagination integration with table/columns metadata
- LookupMeta and LookupResponse for lookup endpoint responses
- JSON serialization round-trips
"""

import pytest
from pydantic import ValidationError

import sqlmodel_object_helpers as soh


# =============================================================================
# ColumnType Tests
# =============================================================================


def test_column_type_values():
    """ColumnType enum has all expected data types."""
    assert soh.ColumnType.STRING == "string"
    assert soh.ColumnType.INTEGER == "integer"
    assert soh.ColumnType.FLOAT == "float"
    assert soh.ColumnType.BOOLEAN == "boolean"
    assert soh.ColumnType.DATE == "date"
    assert soh.ColumnType.DATETIME == "datetime"


def test_column_type_is_str_enum():
    """ColumnType values are strings (StrEnum)."""
    for ct in soh.ColumnType:
        assert isinstance(ct, str)
        assert ct == ct.value


def test_column_type_member_count():
    """ColumnType has exactly 6 members."""
    assert len(soh.ColumnType) == 6


# =============================================================================
# BoolLabels Tests
# =============================================================================


def test_bool_labels_creation():
    """BoolLabels accepts true_label and false_label."""
    bl = soh.BoolLabels(true_label="Оплачено", false_label="Не оплачено")
    assert bl.true_label == "Оплачено"
    assert bl.false_label == "Не оплачено"


def test_bool_labels_required_fields():
    """BoolLabels requires both fields."""
    with pytest.raises(ValidationError):
        soh.BoolLabels(true_label="Да")
    with pytest.raises(ValidationError):
        soh.BoolLabels(false_label="Нет")
    with pytest.raises(ValidationError):
        soh.BoolLabels()


def test_bool_labels_forbids_extra():
    """BoolLabels rejects extra fields (extra='forbid')."""
    with pytest.raises(ValidationError):
        soh.BoolLabels(true_label="Да", false_label="Нет", extra="bad")


def test_bool_labels_serialization():
    """BoolLabels serializes and deserializes correctly."""
    bl = soh.BoolLabels(true_label="Активен", false_label="Заблокирован")
    dumped = bl.model_dump()
    assert dumped == {"true_label": "Активен", "false_label": "Заблокирован"}
    restored = soh.BoolLabels.model_validate(dumped)
    assert restored == bl


# =============================================================================
# TableMeta Tests
# =============================================================================


def test_table_meta_creation():
    """TableMeta accepts name and header."""
    tm = soh.TableMeta(name="attempts", header="Реестр попыток")
    assert tm.name == "attempts"
    assert tm.header == "Реестр попыток"
    assert tm.row_link is None


def test_table_meta_with_row_link():
    """TableMeta accepts row_link for clickable rows."""
    tm = soh.TableMeta(
        name="leads",
        header="Лиды",
        row_link="/lead/$id",
    )
    assert tm.row_link == "/lead/$id"


def test_table_meta_row_link_with_nested_path():
    """TableMeta row_link supports edit routes."""
    tm = soh.TableMeta(
        name="mail_template_lead",
        header="Шаблоны email лидов",
        row_link="/mail-template-lead/$id/edit",
    )
    assert tm.row_link == "/mail-template-lead/$id/edit"


def test_table_meta_row_link_none_by_default():
    """TableMeta row_link defaults to None (non-clickable table)."""
    tm = soh.TableMeta(name="billings", header="Счета")
    assert tm.row_link is None


def test_table_meta_required_fields():
    """TableMeta requires both name and header."""
    with pytest.raises(ValidationError):
        soh.TableMeta(name="attempts")
    with pytest.raises(ValidationError):
        soh.TableMeta(header="Реестр")
    with pytest.raises(ValidationError):
        soh.TableMeta()


def test_table_meta_forbids_extra():
    """TableMeta rejects extra fields."""
    with pytest.raises(ValidationError):
        soh.TableMeta(name="x", header="y", description="extra")


def test_table_meta_serialization():
    """TableMeta serializes and deserializes correctly."""
    tm = soh.TableMeta(name="leads", header="Лиды", row_link="/lead/$id")
    dumped = tm.model_dump()
    assert dumped == {"name": "leads", "header": "Лиды", "row_link": "/lead/$id"}
    restored = soh.TableMeta.model_validate(dumped)
    assert restored == tm


def test_table_meta_serialization_without_row_link():
    """TableMeta without row_link serializes correctly."""
    tm = soh.TableMeta(name="billings", header="Счета")
    dumped = tm.model_dump()
    assert dumped == {"name": "billings", "header": "Счета", "row_link": None}
    restored = soh.TableMeta.model_validate(dumped)
    assert restored == tm


# =============================================================================
# ColumnMeta — basic fields
# =============================================================================


def test_column_meta_minimal():
    """ColumnMeta requires only json_path and label; rest has defaults."""
    cm = soh.ColumnMeta(json_path="id", label="ID")
    assert cm.json_path == "id"
    assert cm.label == "ID"
    assert cm.type == soh.ColumnType.STRING
    assert cm.lookup_dict is None
    assert cm.lookup_path is None
    assert cm.bool_labels is None


def test_column_meta_all_fields():
    """ColumnMeta accepts all fields."""
    cm = soh.ColumnMeta(
        json_path="status.name",
        label="Статус",
        type=soh.ColumnType.STRING,
        lookup_dict="statuses",
        lookup_path="status_id",
    )
    assert cm.lookup_dict == "statuses"
    assert cm.lookup_path == "status_id"


def test_column_meta_required_fields():
    """ColumnMeta requires json_path and label."""
    with pytest.raises(ValidationError):
        soh.ColumnMeta(json_path="id")
    with pytest.raises(ValidationError):
        soh.ColumnMeta(label="ID")


def test_column_meta_forbids_extra():
    """ColumnMeta rejects extra fields."""
    with pytest.raises(ValidationError):
        soh.ColumnMeta(json_path="id", label="ID", width=100)


def test_column_meta_forbids_colors():
    """ColumnMeta does not accept colors — colors belong in _lkp tables."""
    with pytest.raises(ValidationError):
        soh.ColumnMeta(json_path="id", label="ID", colors={"true": "#66BB6A"})


def test_column_meta_forbids_link_template():
    """ColumnMeta does not accept link_template — row links belong in TableMeta."""
    with pytest.raises(ValidationError):
        soh.ColumnMeta(json_path="id", label="ID", link_template="/apps/{id}")


def test_column_meta_forbids_sortable():
    """ColumnMeta does not accept sortable — under discussion."""
    with pytest.raises(ValidationError):
        soh.ColumnMeta(json_path="id", label="ID", sortable=True)


# =============================================================================
# ColumnMeta — bool_labels
# =============================================================================


def test_column_meta_bool_labels():
    """ColumnMeta accepts bool_labels for boolean column display."""
    cm = soh.ColumnMeta(
        json_path="is_paid",
        label="Оплата",
        type=soh.ColumnType.BOOLEAN,
        bool_labels=soh.BoolLabels(true_label="Оплачено", false_label="Не оплачено"),
    )
    assert cm.bool_labels is not None
    assert cm.bool_labels.true_label == "Оплачено"
    assert cm.bool_labels.false_label == "Не оплачено"


def test_column_meta_bool_labels_from_dict():
    """ColumnMeta accepts bool_labels as a raw dict (Pydantic coercion)."""
    cm = soh.ColumnMeta(
        json_path="is_active",
        label="Активен",
        type=soh.ColumnType.BOOLEAN,
        bool_labels={"true_label": "Да", "false_label": "Нет"},
    )
    assert isinstance(cm.bool_labels, soh.BoolLabels)
    assert cm.bool_labels.true_label == "Да"


def test_column_meta_bool_labels_none_by_default():
    """bool_labels defaults to None."""
    cm = soh.ColumnMeta(json_path="id", label="ID")
    assert cm.bool_labels is None


# =============================================================================
# ColumnMeta — realistic examples
# =============================================================================


def test_column_meta_boolean_example():
    """ColumnMeta for a boolean column with labels."""
    cm = soh.ColumnMeta(
        json_path="is_paid",
        label="Оплата",
        type=soh.ColumnType.BOOLEAN,
        bool_labels=soh.BoolLabels(true_label="Оплачено", false_label="Не оплачено"),
    )
    dumped = cm.model_dump()
    assert dumped["json_path"] == "is_paid"
    assert dumped["bool_labels"]["true_label"] == "Оплачено"


def test_column_meta_lookup_example():
    """ColumnMeta for a lookup column — colors come from _lkp, not ColumnMeta."""
    cm = soh.ColumnMeta(
        json_path="email_type_id",
        label="Тип письма",
        type=soh.ColumnType.INTEGER,
        lookup_dict="lead_email_types",
        lookup_path="email_type_id",
    )
    dumped = cm.model_dump()
    assert dumped["lookup_dict"] == "lead_email_types"
    assert dumped["lookup_path"] == "email_type_id"
    assert "colors" not in dumped


# =============================================================================
# ColumnMeta — serialization round-trip
# =============================================================================


def test_column_meta_serialization_roundtrip():
    """ColumnMeta survives model_dump → model_validate round-trip."""
    original = soh.ColumnMeta(
        json_path="status.name",
        label="Статус",
        type=soh.ColumnType.STRING,
        lookup_dict="statuses",
        lookup_path="status_id",
        bool_labels=None,
    )
    dumped = original.model_dump()
    restored = soh.ColumnMeta.model_validate(dumped)
    assert restored == original


def test_column_meta_json_roundtrip():
    """ColumnMeta survives model_dump_json → model_validate_json round-trip."""
    original = soh.ColumnMeta(
        json_path="is_active",
        label="Активен",
        type=soh.ColumnType.BOOLEAN,
        bool_labels=soh.BoolLabels(true_label="Активен", false_label="Заблокирован"),
    )
    json_str = original.model_dump_json()
    restored = soh.ColumnMeta.model_validate_json(json_str)
    assert restored == original


# =============================================================================
# GetAllPagination — integration with table/columns metadata
# =============================================================================


def test_get_all_pagination_with_table_meta():
    """GetAllPagination includes TableMeta."""
    gap = soh.GetAllPagination[dict](
        table=soh.TableMeta(name="attempts", header="Реестр попыток"),
        data=[{"id": 1}],
        pagination=soh.PaginationR(page=1, per_page=10, total=1),
    )
    assert gap.table is not None
    assert gap.table.name == "attempts"
    assert gap.table.header == "Реестр попыток"


def test_get_all_pagination_with_columns():
    """GetAllPagination includes list of ColumnMeta."""
    columns = [
        soh.ColumnMeta(json_path="id", label="ID", type=soh.ColumnType.INTEGER),
        soh.ColumnMeta(
            json_path="is_paid",
            label="Оплата",
            type=soh.ColumnType.BOOLEAN,
            bool_labels=soh.BoolLabels(true_label="Да", false_label="Нет"),
        ),
    ]
    gap = soh.GetAllPagination[dict](
        table=soh.TableMeta(name="billings", header="Счета"),
        columns=columns,
        data=[],
    )
    assert len(gap.columns) == 2
    assert gap.columns[1].bool_labels.true_label == "Да"


def test_get_all_pagination_without_metadata():
    """GetAllPagination works without table and columns (subsequent pages)."""
    gap = soh.GetAllPagination[dict](
        data=[{"id": 1}, {"id": 2}],
        pagination=soh.PaginationR(page=2, per_page=10, total=20),
    )
    assert gap.table is None
    assert gap.columns is None
    assert len(gap.data) == 2


def test_get_all_pagination_full_serialization():
    """Full GetAllPagination with metadata serializes correctly."""
    gap = soh.GetAllPagination[dict](
        table=soh.TableMeta(name="attempts", header="Попытки"),
        columns=[
            soh.ColumnMeta(
                json_path="status.name",
                label="Статус",
                lookup_dict="statuses",
                lookup_path="status_id",
            ),
        ],
        data=[{"id": 1, "status": {"name": "Экзамен пройден"}}],
        pagination=soh.PaginationR(page=1, per_page=10, total=1),
    )
    dumped = gap.model_dump()
    assert dumped["table"]["name"] == "attempts"
    assert dumped["columns"][0]["lookup_dict"] == "statuses"
    assert dumped["data"][0]["status"]["name"] == "Экзамен пройден"
    assert dumped["pagination"]["total"] == 1


# =============================================================================
# LookupMeta Tests
# =============================================================================


def test_lookup_meta_creation():
    """LookupMeta accepts name."""
    lm = soh.LookupMeta(name="lead_email_types")
    assert lm.name == "lead_email_types"


def test_lookup_meta_required_name():
    """LookupMeta requires name."""
    with pytest.raises(ValidationError):
        soh.LookupMeta()


def test_lookup_meta_forbids_extra():
    """LookupMeta rejects extra fields."""
    with pytest.raises(ValidationError):
        soh.LookupMeta(name="statuses", header="Статусы")


def test_lookup_meta_serialization():
    """LookupMeta serializes and deserializes correctly."""
    lm = soh.LookupMeta(name="statuses")
    dumped = lm.model_dump()
    assert dumped == {"name": "statuses"}
    restored = soh.LookupMeta.model_validate(dumped)
    assert restored == lm


# =============================================================================
# LookupResponse Tests
# =============================================================================


def test_lookup_response_creation():
    """LookupResponse wraps meta + data."""
    lr = soh.LookupResponse[dict](
        meta=soh.LookupMeta(name="lead_email_types"),
        data=[
            {"id": 1, "name": "Создан новый лид"},
            {"id": 2, "name": "Назначен ответственный лид"},
        ],
    )
    assert lr.meta.name == "lead_email_types"
    assert len(lr.data) == 2
    assert lr.data[0]["name"] == "Создан новый лид"


def test_lookup_response_empty_data():
    """LookupResponse accepts empty data list."""
    lr = soh.LookupResponse[dict](
        meta=soh.LookupMeta(name="empty_lkp"),
        data=[],
    )
    assert lr.data == []


def test_lookup_response_requires_meta():
    """LookupResponse requires meta."""
    with pytest.raises(ValidationError):
        soh.LookupResponse[dict](data=[{"id": 1}])


def test_lookup_response_requires_data():
    """LookupResponse requires data."""
    with pytest.raises(ValidationError):
        soh.LookupResponse[dict](meta=soh.LookupMeta(name="x"))


def test_lookup_response_with_color():
    """LookupResponse works with lookup records that include color."""
    lr = soh.LookupResponse[dict](
        meta=soh.LookupMeta(name="lead_email_types"),
        data=[
            {"id": 1, "name": "Создан новый лид", "color": "#66BB6A"},
            {"id": 3, "name": "Нарушение лида", "color": "#E57373"},
        ],
    )
    assert lr.data[0]["color"] == "#66BB6A"
    assert lr.data[1]["color"] == "#E57373"


def test_lookup_response_serialization_roundtrip():
    """LookupResponse survives model_dump → model_validate round-trip."""
    original = soh.LookupResponse[dict](
        meta=soh.LookupMeta(name="statuses"),
        data=[{"id": 120, "name": "Экзамен пройден", "color": "#66BB6A"}],
    )
    dumped = original.model_dump()
    assert dumped["meta"]["name"] == "statuses"
    assert dumped["data"][0]["color"] == "#66BB6A"
    restored = soh.LookupResponse[dict].model_validate(dumped)
    assert restored == original


def test_lookup_response_json_roundtrip():
    """LookupResponse survives JSON round-trip."""
    original = soh.LookupResponse[dict](
        meta=soh.LookupMeta(name="lead_email_types"),
        data=[{"id": 1, "name": "Создан новый лид"}],
    )
    json_str = original.model_dump_json()
    restored = soh.LookupResponse[dict].model_validate_json(json_str)
    assert restored == original


def test_lookup_response_meta_matches_column_meta_lookup_dict():
    """LookupResponse.meta.name should match ColumnMeta.lookup_dict."""
    column = soh.ColumnMeta(
        json_path="email_type_id",
        label="Тип письма",
        type=soh.ColumnType.INTEGER,
        lookup_dict="lead_email_types",
        lookup_path="email_type_id",
    )
    lookup = soh.LookupResponse[dict](
        meta=soh.LookupMeta(name="lead_email_types"),
        data=[{"id": 1, "name": "Создан новый лид"}],
    )
    assert column.lookup_dict == lookup.meta.name
