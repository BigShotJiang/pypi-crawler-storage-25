"""Token-based authentication middleware.

If MASC_AUTH_TOKEN is set, all routes require authentication via:
- Authorization: Bearer <token> header, OR
- masc_token cookie

If MASC_AUTH_TOKEN is not set, no authentication is required (backward compatible).
"""

import os
import logging

from fastapi import Request
from fastapi.responses import RedirectResponse, JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger("masc.auth")

AUTH_TOKEN = os.environ.get("MASC_AUTH_TOKEN")

# Paths that don't require authentication
_PUBLIC_PATHS_EXACT = {"/login"}
_PUBLIC_PATHS_PREFIX = {"/static/"}


def auth_enabled() -> bool:
    """Check if authentication is enabled."""
    return bool(AUTH_TOKEN)


def verify_token(token: str) -> bool:
    """Verify a token against the configured auth token."""
    return AUTH_TOKEN is not None and token == AUTH_TOKEN


class AuthMiddleware(BaseHTTPMiddleware):
    """Middleware that enforces token authentication when MASC_AUTH_TOKEN is set."""

    async def dispatch(self, request: Request, call_next):
        if not AUTH_TOKEN:
            return await call_next(request)

        path = request.url.path

        # Allow public paths
        if path in _PUBLIC_PATHS_EXACT or any(path.startswith(p) for p in _PUBLIC_PATHS_PREFIX):
            return await call_next(request)

        # Check Authorization header
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer ") and verify_token(auth_header[7:]):
            return await call_next(request)

        # Check cookie
        cookie_token = request.cookies.get("masc_token")
        if cookie_token and verify_token(cookie_token):
            return await call_next(request)

        # Not authenticated
        if "text/html" in request.headers.get("Accept", ""):
            return RedirectResponse(url="/login", status_code=302)
        return JSONResponse(status_code=401, content={"detail": "Unauthorized"})
