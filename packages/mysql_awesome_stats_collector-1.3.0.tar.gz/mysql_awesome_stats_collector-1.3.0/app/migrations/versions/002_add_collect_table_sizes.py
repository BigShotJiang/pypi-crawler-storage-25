"""Add collect_table_sizes column to cron_jobs.

Revision ID: 002
Revises: 001
Create Date: 2026-04-15

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "002"
down_revision: Union[str, None] = "001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("cron_jobs") as batch_op:
        batch_op.add_column(sa.Column("collect_table_sizes", sa.Boolean(), default=False))


def downgrade() -> None:
    with op.batch_alter_table("cron_jobs") as batch_op:
        batch_op.drop_column("collect_table_sizes")
