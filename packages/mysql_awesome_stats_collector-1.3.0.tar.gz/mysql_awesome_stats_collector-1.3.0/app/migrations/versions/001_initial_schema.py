"""Initial schema — all 5 tables with full current schema.

Revision ID: 001
Revises: None
Create Date: 2026-04-15

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- cron_jobs ---
    op.create_table(
        "cron_jobs",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("host_ids", sa.Text(), nullable=False),
        sa.Column("interval_minutes", sa.Integer(), nullable=False, server_default="60"),
        sa.Column("collect_hot_tables", sa.Boolean(), default=False),
        sa.Column("enabled", sa.Boolean(), default=True),
        sa.Column("last_run_at", sa.DateTime(), nullable=True),
        sa.Column("last_job_id", sa.String(), nullable=True),
        sa.Column("next_run_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("run_count", sa.Integer(), default=0),
        sa.PrimaryKeyConstraint("id"),
    )

    # --- db_groups ---
    op.create_table(
        "db_groups",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("color", sa.String(), nullable=True, server_default="ocean"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )

    # --- jobs ---
    op.create_table(
        "jobs",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("status", sa.Enum("pending", "running", "completed", "failed", name="jobstatus"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_jobs_created_at", "jobs", ["created_at"])
    op.create_index("ix_jobs_status", "jobs", ["status"])

    # --- hosts ---
    op.create_table(
        "hosts",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("label", sa.String(), nullable=False),
        sa.Column("host", sa.String(), nullable=False),
        sa.Column("port", sa.Integer(), nullable=False, server_default="3306"),
        sa.Column("user", sa.String(), nullable=False),
        sa.Column("password", sa.String(), nullable=False),
        sa.Column("group_id", sa.String(), sa.ForeignKey("db_groups.id"), nullable=True),
        sa.Column("enabled", sa.Boolean(), default=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("last_test_at", sa.DateTime(), nullable=True),
        sa.Column("last_test_success", sa.Boolean(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )

    # --- job_hosts ---
    op.create_table(
        "job_hosts",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("job_id", sa.String(), sa.ForeignKey("jobs.id"), nullable=False),
        sa.Column("host_id", sa.String(), nullable=False),
        sa.Column("status", sa.Enum("pending", "running", "completed", "failed", name="hostjobstatus"), nullable=False),
        sa.Column("started_at", sa.DateTime(), nullable=True),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
        sa.Column("mysql_version", sa.String(), nullable=True),
        sa.Column("error_message", sa.String(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_job_hosts_job_id", "job_hosts", ["job_id"])
    op.create_index("ix_job_hosts_host_id", "job_hosts", ["host_id"])


def downgrade() -> None:
    op.drop_table("job_hosts")
    op.drop_table("hosts")
    op.drop_table("jobs")
    op.drop_table("db_groups")
    op.drop_table("cron_jobs")
