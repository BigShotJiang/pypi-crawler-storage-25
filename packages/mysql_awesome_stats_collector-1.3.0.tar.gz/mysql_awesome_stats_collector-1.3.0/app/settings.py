"""Shared settings — importable without triggering app bootstrap."""

import os
from pathlib import Path

# Data directory: MASC_DATA_DIR env var or project root
_data_dir = os.environ.get("MASC_DATA_DIR")
if _data_dir:
    DATA_DIR = Path(_data_dir)
else:
    DATA_DIR = Path(__file__).parent.parent

# Database file path
DB_PATH = DATA_DIR / "observer.db"
DATABASE_URL = f"sqlite:///{DB_PATH}"
