"""Database connection and session management."""

import logging
from pathlib import Path
from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import sessionmaker, Session
from contextlib import contextmanager
from typing import Generator

from .models import Base
from .settings import DATABASE_URL

logger = logging.getLogger("masc.db")

# Create engine with check_same_thread=False for SQLite
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Expected tables, columns, and indexes for legacy schema verification
_EXPECTED_TABLES = {"jobs", "job_hosts", "cron_jobs", "db_groups", "hosts"}
_EXPECTED_COLUMNS = {
    "hosts": {"group_id"},
    "job_hosts": {"mysql_version"},
}
_EXPECTED_INDEXES = {
    "jobs": {"ix_jobs_created_at", "ix_jobs_status"},
    "job_hosts": {"ix_job_hosts_job_id", "ix_job_hosts_host_id"},
}


def _get_alembic_cfg():
    """Build Alembic Config programmatically (no cwd dependency)."""
    from alembic.config import Config

    cfg = Config()
    cfg.set_main_option("script_location", str(Path(__file__).parent / "migrations"))
    cfg.set_main_option("sqlalchemy.url", DATABASE_URL)
    return cfg


def _is_legacy_db_current() -> bool:
    """Check if a pre-Alembic DB has the full expected schema."""
    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())

    if not _EXPECTED_TABLES.issubset(existing_tables):
        return False

    for table, required_cols in _EXPECTED_COLUMNS.items():
        columns = {col["name"] for col in inspector.get_columns(table)}
        if not required_cols.issubset(columns):
            return False

    for table, required_indexes in _EXPECTED_INDEXES.items():
        indexes = {idx["name"] for idx in inspector.get_indexes(table) if idx.get("name")}
        if not required_indexes.issubset(indexes):
            return False

    return True


def init_db() -> None:
    """Initialize database using Alembic migrations."""
    from alembic import command

    alembic_cfg = _get_alembic_cfg()
    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())

    if existing_tables & _EXPECTED_TABLES and "alembic_version" not in existing_tables:
        # Pre-Alembic DB detected
        if _is_legacy_db_current():
            logger.info("Legacy DB detected with current schema — stamping Alembic baseline")
            command.stamp(alembic_cfg, "001")
        else:
            logger.error(
                "Legacy DB detected but schema is incomplete. "
                "Please upgrade to the latest non-Alembic version first, "
                "or delete observer.db to start fresh."
            )
            raise RuntimeError("Incomplete legacy database schema")

    # Run all pending migrations (creates tables on fresh DB, no-op if current)
    command.upgrade(alembic_cfg, "head")
    logger.info("Database ready")


def get_db() -> Generator[Session, None, None]:
    """Dependency for getting database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def get_db_context() -> Generator[Session, None, None]:
    """Context manager for database session (for background tasks)."""
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
