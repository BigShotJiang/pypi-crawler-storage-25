"""Password encryption for MySQL host credentials using Fernet symmetric encryption."""

import logging
import os
from pathlib import Path
from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger("masc.crypto")

_fernet = None

# Fernet tokens always start with 'gAAAAA'
_FERNET_PREFIX = "gAAAAA"

# Key file location
_KEY_DIR = Path.home() / ".masc"
_KEY_FILE = _KEY_DIR / "secret.key"


def _get_fernet() -> Fernet:
    """Get or create a cached Fernet instance."""
    global _fernet
    if _fernet is not None:
        return _fernet

    key = os.environ.get("MASC_SECRET_KEY")

    if key:
        # Use env var (expected to be a valid Fernet key, base64-encoded)
        logger.debug("Using encryption key from MASC_SECRET_KEY env var")
    elif _KEY_FILE.exists():
        key = _KEY_FILE.read_text().strip()
        logger.debug(f"Using encryption key from {_KEY_FILE}")
    else:
        # Auto-generate and persist
        key = Fernet.generate_key().decode()
        _KEY_DIR.mkdir(parents=True, exist_ok=True)
        _KEY_FILE.write_text(key)
        _KEY_FILE.chmod(0o600)
        logger.warning(
            f"Auto-generated encryption key saved to {_KEY_FILE}. "
            "Set MASC_SECRET_KEY env var for production use."
        )

    _fernet = Fernet(key.encode() if isinstance(key, str) else key)
    return _fernet


def encrypt_password(plain: str) -> str:
    """Encrypt a plain-text password. Returns a Fernet token string."""
    f = _get_fernet()
    return f.encrypt(plain.encode()).decode()


def decrypt_password(stored: str) -> str:
    """
    Decrypt a stored password.

    If the value doesn't look like a Fernet token (legacy plain-text),
    returns it as-is for backward compatibility during migration.
    """
    if not stored or not stored.startswith(_FERNET_PREFIX):
        return stored

    f = _get_fernet()
    try:
        return f.decrypt(stored.encode()).decode()
    except InvalidToken:
        logger.warning("Failed to decrypt password — returning as-is")
        return stored


def is_encrypted(value: str) -> bool:
    """Check if a stored value looks like a Fernet-encrypted token."""
    return bool(value and value.startswith(_FERNET_PREFIX))
