"""Context-agnostic filter specification parsing."""

import json

from pydantic import ValidationError

from alloy_runtime_types.dtos.structured_filter import ConditionSpec, LogicalSpec


class FilterParseError(Exception):
    """Raised when filter JSON parsing or validation fails."""

    def __init__(self, message: str, field_path: str | None = None):
        self.message = message
        self.field_path = field_path
        super().__init__(message)


def parse_filter_spec(
    filter_json: str | None,
) -> ConditionSpec | LogicalSpec | None:
    """Parse JSON string into a filter spec.

    Args:
        filter_json: JSON string to parse, or None

    Returns:
        Validated ConditionSpec or LogicalSpec, or None if filter_json is None

    Raises:
        FilterParseError: If JSON is invalid or doesn't match spec schema
    """
    if filter_json is None:
        return None

    try:
        spec_dict = json.loads(filter_json)
    except json.JSONDecodeError as e:
        raise FilterParseError(f"Invalid JSON: {e}") from e

    try:
        if "conditions" in spec_dict:
            return LogicalSpec(**spec_dict)
        return ConditionSpec(**spec_dict)
    except ValidationError as e:
        first_error = e.errors()[0]
        loc = first_error.get("loc")
        msg = f"{loc}: {first_error['msg']}" if loc else first_error["msg"]
        raise FilterParseError(msg, field_path=str(loc) if loc else None) from e
