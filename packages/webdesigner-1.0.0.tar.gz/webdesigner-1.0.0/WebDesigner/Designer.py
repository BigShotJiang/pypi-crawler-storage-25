def main():
    from WebDesigner.Program.Main import Designer
    
if __name__=='__main__':
    from Program.Main import Designer