################################################################################################################################
#Configure
################################################################################################################################
#Default Libraries
import inspect

#Program
from .N_Configure_Popup import Configure_Popup
from .N_Configure_Frame import Configure_Frame
from .N_Configure_Label import Configure_Label
from .N_Configure_Bar import Configure_Bar
from .N_Configure_Button import Configure_Button
from .N_Configure_Compound import Configure_Compound
from .N_Configure_Image import Configure_Image
from .N_Configure_Line import Configure_Line
from .N_Configure_Entry import Configure_Entry
from .N_Configure_List import Configure_List
from .N_Configure_Select import Configure_Select
from .N_Configure_Scale import Configure_Scale
from .N_Configure_Check import Configure_Check
from .N_Configure_Radio import Configure_Radio
from .N_Configure_Switch import Configure_Switch
from .N_Configure_Text import Configure_Text
from .N_Configure_Tree import Configure_Tree
from .N_Configure_Flowchart import Configure_Flowchart
from .N_Configure_Table import Configure_Table
from .N_Configure_Knob import Configure_Knob
from .N_Configure_Circular import Configure_Circular
from .N_Configure_Code import Configure_Code
from .N_Configure_Scene import Configure_Scene

class Configure:
    def __init__(self, Global, Design):
        try:
            self.Global = Global
            self.Design = Design
            self.Widget= []
            self.Current = False
            
            #Frame
            Fixture = self.Design.Frame.Locate(40, 90, 60, 10)
            self.Frame = self.Global['Gluonix'].Frame(self.Design.Frame)
            self.Frame.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Frame.Config(Background='#FFFFFF', Border_Size=0, Display=True)
            self.Frame.Config(Resize=True, Move=True)
            self.Frame.Create()
            self.Design.Widget.append(self.Frame)
            
            #Label
            Fixture = self.Frame.Locate(100, 3, 0, 1)
            self.Label = self.Global['Gluonix'].Label(self.Frame)
            self.Label.Config(Width=Fixture[0], Height=Fixture[1], Left=Fixture[2], Top=Fixture[3])
            self.Label.Config(Background='#FFFFFF', Border_Size=0, Display=True)
            self.Label.Config(Foreground='#000000', Font_Size=16, Font_Weight='normal', Align='w')
            self.Label.Config(Resize=True, Move=True)
            self.Label.Set(' CONFIGURE')
            self.Label.Create()
            
            #Configure Frame
            self.Configure_Popup = Configure_Popup(self.Global, self)
            
            #Configure Frame
            self.Configure_Frame = Configure_Frame(self.Global, self)
            
            #Configure Label
            self.Configure_Label = Configure_Label(self.Global, self)
            
            #Configure Bar
            self.Configure_Bar = Configure_Bar(self.Global, self)
            
            #Configure Button
            self.Configure_Button = Configure_Button(self.Global, self)
            
            #Configure Compound
            self.Configure_Compound = Configure_Compound(self.Global, self)
            
            #Configure Image
            self.Configure_Image = Configure_Image(self.Global, self)
            
            #Configure Line
            self.Configure_Line = Configure_Line(self.Global, self)
            
            #Configure Entry
            self.Configure_Entry = Configure_Entry(self.Global, self)
            
            #Configure List
            self.Configure_List = Configure_List(self.Global, self)
            
            #Configure Select
            self.Configure_Select = Configure_Select(self.Global, self)
            
            #Configure Scale
            self.Configure_Scale = Configure_Scale(self.Global, self)
            
            #Configure Check
            self.Configure_Check = Configure_Check(self.Global, self)
            
            #Configure Radio
            self.Configure_Radio = Configure_Radio(self.Global, self)
            
            #Configure Switch
            self.Configure_Switch = Configure_Switch(self.Global, self)
            
            #Configure Text
            self.Configure_Text = Configure_Text(self.Global, self)
            
            #Configure Tree
            self.Configure_Tree = Configure_Tree(self.Global, self)
            
            #Configure Flowchart
            self.Configure_Flowchart = Configure_Flowchart(self.Global, self)
            
            #Configure Table
            self.Configure_Table = Configure_Table(self.Global, self)
            
            #Configure Knob
            self.Configure_Knob = Configure_Knob(self.Global, self)
            
            #Configure Circular
            self.Configure_Circular = Configure_Circular(self.Global, self)
            
            #Configure Code
            self.Configure_Code = Configure_Code(self.Global, self)
            
            #Configure Scene
            self.Configure_Scene = Configure_Scene(self.Global, self)
            
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))
            
    def Hide_All(self):
        try:
            self.Current = False
            for Each in self.Widget:
                Each.Frame.Top()
                Each.Frame.Hide()
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))
            
    def Reset_All(self):
        try:
            for Each in self.Widget:
                Each.ID = False
                Each.Root = False
                Each.Root_ID = False
                Each.Element = False
        except Exception as E:
            self.Global['Error'](__class__.__name__+" -> "+inspect.currentframe().f_code.co_name+" -> "+str(E))