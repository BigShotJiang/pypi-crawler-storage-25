from setuptools import setup, find_packages

setup(
    name="WebDesigner",
    version="1.0.0",
    description="A Web GUI Designer with drag-and-drop features.",
    author="Nucleon Automation",
    author_email="jagroop@nucleonautomation.com",
    packages=find_packages(),
    python_requires=">=3.6",
    install_requires=[
        "pillow>=6.0.0",
        "nicegui>=3.10.0"
    ],
    entry_points={
        "console_scripts": [
            "WebDesigner = WebDesigner.Designer:main",
            "Wavionix = WebDesigner.Designer:main"
        ]
    },
    include_package_data=True,
    package_data={
        "WebDesigner": ["Data/**/*"],
    },
)

'''
python -m build --sdist
twine upload dist/*
pip install dist/webdesigner-1.0.0.tar.gz
WebDesigner
'''