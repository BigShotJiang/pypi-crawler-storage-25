# Web Designer V(1.0.0)
- Web Designer is a GUI design tool for Python applications that simplifies the process of creating web app user interfaces using a drag-and-drop approach. This tool is aimed at developers who want to quickly prototype or build Python Web GUIs without extensive manual coding.

## Feedback
- We hope you find Web Designer helpful and easy to use. If you have any thoughts or suggestions, we’d love to hear from you at feedback@nucleonautomation.com. Your feedback is invaluable in helping us improve and enhance the tool.

## Features
- Drag-and-Drop Interface: Design your GUI by dragging and dropping components onto a canvas.
- Python Code Generation: Automatically generates Python code based on your GUI design.
- Component Library: Includes a variety of pre-built components such as buttons, labels, input fields, etc.
- Customization: Customize properties and behaviors of components directly through the interface.
- Export to Python: Export your designed GUI to a Python script that can be integrated into your Python project.

## Installation Pypi
```
# Requires Python >=3.6
pip install WebDesigner

# Start Application
Wavionix
#or
WebDesigner
```

## Installation Git
```
# Requires Python >=3.6
git clone https://github.com/nucleonautomation/Web-Designer.git

# Start Application
cd Web-Designer
python Designer.py
```

## Requirements
```
pip install -r requirements.txt
```

## License
- This project is licensed under BSD 4-Clause License. See the [LICENSE](https://github.com/nucleonautomation/Web-Designer/blob/main/LICENSE.md) file for details.

## Change Log
- See the [LOG](https://github.com/nucleonautomation/Web-Designer/blob/main/LOG.md) file for details.
