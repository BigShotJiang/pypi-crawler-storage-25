"""
Constants and configuration values for Fetchtastic.

This module contains all hardcoded values, URLs, timeouts, and other constants
used throughout the application.
"""

# GitHub API URLs
GITHUB_API_BASE = "https://api.github.com/repos"
MESHTASTIC_ANDROID_RELEASES_URL = (
    f"{GITHUB_API_BASE}/meshtastic/Meshtastic-Android/releases"
)
# Client app assets (Android APKs and Desktop installers) are published in the
# Meshtastic-Android release feed.
MESHTASTIC_CLIENT_APP_RELEASES_URL = MESHTASTIC_ANDROID_RELEASES_URL
MESHTASTIC_FIRMWARE_RELEASES_URL = f"{GITHUB_API_BASE}/meshtastic/firmware/releases"
# Desktop assets are currently published in the Android releases feed.
MESHTASTIC_DESKTOP_RELEASES_URL = MESHTASTIC_ANDROID_RELEASES_URL
MESHTASTIC_GITHUB_IO_CONTENTS_URL = (
    f"{GITHUB_API_BASE}/meshtastic/meshtastic.github.io/contents"
)
MESHTASTIC_REPO_URL = "https://meshtastic.github.io"

# Network timeouts and delays (in seconds)
GITHUB_API_TIMEOUT = 10
NTFY_REQUEST_TIMEOUT = 10
PRERELEASE_REQUEST_TIMEOUT = 30
CRON_COMMAND_TIMEOUT_SECONDS = 30

API_CALL_DELAY = 0.1  # Small delay to be respectful to GitHub API
GITHUB_MAX_PER_PAGE = 100
# Download and retry settings
RELEASE_SCAN_COUNT = 10


# Windows-specific retry settings
WINDOWS_MAX_REPLACE_RETRIES = 3
WINDOWS_INITIAL_RETRY_DELAY = 1.0  # seconds

# File and directory names
REPO_DOWNLOADS_DIR = "repo-dls"
FIRMWARE_PRERELEASES_DIR_NAME = "prerelease"
APK_PRERELEASES_DIR_NAME = "prerelease"
DESKTOP_PRERELEASES_DIR_NAME = "prerelease"
FIRMWARE_DIR_PREFIX = "firmware-"
FIRMWARE_DIR_NAME = "firmware"
APKS_DIR_NAME = "apks"
APP_DIR_NAME = "app"
# Compatibility-only aliases: legacy Android/Desktop references map to unified
# app storage. They are NOT used to drive new storage logic. The primary
# client-app storage layout is app/<version>/ and app/prerelease/<version>/
# with no platform subdirectories.
ANDROID_DIR_NAME = APP_DIR_NAME
DESKTOP_DIR_NAME = APP_DIR_NAME
LATEST_ANDROID_RELEASE_JSON_FILE = "latest_android_release.json"
LATEST_ANDROID_PRERELEASE_JSON_FILE = "latest_android_prerelease.json"
LATEST_FIRMWARE_PRERELEASE_JSON_FILE = "latest_firmware_prerelease.json"
LATEST_FIRMWARE_RELEASE_JSON_FILE = "latest_firmware_release.json"
LATEST_DESKTOP_RELEASE_JSON_FILE = "latest_desktop_release.json"
LATEST_DESKTOP_PRERELEASE_JSON_FILE = "latest_desktop_prerelease.json"
LATEST_CLIENT_APP_RELEASE_JSON_FILE = "latest_client_app_release.json"
LATEST_CLIENT_APP_PRERELEASE_JSON_FILE = "latest_client_app_prerelease.json"
DESKTOP_RELEASE_HISTORY_JSON_FILE = "desktop_release_history.json"
ANDROID_RELEASE_HISTORY_JSON_FILE = "android_release_history.json"
CLIENT_APP_RELEASE_HISTORY_JSON_FILE = "client_app_release_history.json"
FIRMWARE_RELEASE_HISTORY_JSON_FILE = "firmware_release_history.json"
PRERELEASE_TRACKING_JSON_FILE = "prerelease_tracking.json"
PRERELEASE_COMMITS_CACHE_FILE = "prerelease_commits_cache.json"
PRERELEASE_COMMIT_HISTORY_FILE = "prerelease_commit_history.json"
WINDOWS_SHORTCUT_FILE = "fetchtastic_yaml.lnk"

# Regex patterns for parsing prerelease commit messages
PRERELEASE_ADD_COMMIT_PATTERN = (
    r"^(\d+\.\d+\.\d+)\.([a-f0-9]{6,})\s+meshtastic/firmware@(?:[a-f0-9]{6,})"
)
PRERELEASE_DELETE_COMMIT_PATTERN = (
    r"^Delete firmware-(\d+\.\d+\.\d+)\.([a-f0-9]{6,})\s+directory"
)

# Default values for prerelease entries
DEFAULT_PRERELEASE_ACTIVE = False
DEFAULT_PRERELEASE_STATUS = "unknown"
DEFAULT_PRERELEASE_COMMITS_TO_FETCH = 40
DEFAULT_FIRMWARE_VERSIONS_TO_KEEP = 2
DEFAULT_ANDROID_VERSIONS_TO_KEEP = 2
DEFAULT_APP_VERSIONS_TO_KEEP = 2
DEFAULT_KEEP_LAST_BETA = False
DEFAULT_CHECK_APK_PRERELEASES = True
DEFAULT_CHECK_DESKTOP_PRERELEASES = True
DEFAULT_CHECK_APP_PRERELEASES = True
DEFAULT_DESKTOP_VERSIONS_TO_KEEP = 2
DEFAULT_ADD_CHANNEL_SUFFIXES_TO_DIRECTORIES = True
DEFAULT_PRESERVE_LEGACY_FIRMWARE_BASE_DIRS = True
DEFAULT_FILTER_REVOKED_RELEASES = True
STORAGE_CHANNEL_SUFFIXES = frozenset({"alpha", "beta", "rc"})
MAX_RETRY_DELAY = 60  # Cap exponential backoff at 60 seconds
EXECUTABLE_PERMISSIONS = 0o755

# Download configuration defaults
DEFAULT_CONNECT_RETRIES = 5
DEFAULT_BACKOFF_FACTOR = 0.3
DEFAULT_REQUEST_TIMEOUT = 30
DEFAULT_CHUNK_SIZE = 8192

# HTTP status code thresholds
HTTP_STATUS_ERROR_THRESHOLD = 400  # Client/server error boundary
HTTP_STATUS_RETRY_THRESHOLD = 500  # Server errors are retryable

# File size constants
BYTES_PER_MEGABYTE = 1024 * 1024  # 1 MB = 1,048,576 bytes
FILE_SIZE_MB_LOGGING_THRESHOLD = 1.0  # Log in MB if >= this value

# Rate limit defaults
RATE_LIMIT_REMAINING_DEFAULT = 60  # GitHub default for unauthenticated


# Directories that Fetchtastic manages and can safely clean
MANAGED_DIRECTORIES = (
    REPO_DOWNLOADS_DIR,
    FIRMWARE_DIR_NAME,
    APKS_DIR_NAME,
    APP_DIR_NAME,
)

# Default configuration values


# File extensions and patterns
APK_EXTENSION = ".apk"
DESKTOP_EXTENSIONS = (".dmg", ".msi", ".exe", ".deb", ".rpm", ".appimage")
ZIP_EXTENSION = ".zip"
SHELL_SCRIPT_EXTENSION = ".sh"
FIRMWARE_MANIFEST_EXTENSION = ".mt.json"

# Clean operation messages
MSG_REMOVED_MANAGED_DIR = "Removed managed directory: {path}"
MSG_REMOVED_MANAGED_FILE = "Removed managed file: {path}"
MSG_FAILED_DELETE_MANAGED_FILE = "Failed to delete managed file {path}. Reason: {error}"
MSG_FAILED_DELETE_MANAGED_DIR = (
    "Failed to delete managed directory {path}. Reason: {error}"
)
MSG_CLEANED_MANAGED_DIRS = "Cleaned managed directories from: {path}"
MSG_PRESERVE_OTHER_FILES = "Note: Only Fetchtastic-managed directories were removed. Other files were preserved."

# Logging configuration
LOGGER_NAME = "fetchtastic"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
INFO_LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
DEBUG_LOG_FORMAT = "%(asctime)s - %(levelname)s - %(name)s: %(message)s"
LOG_FILE_MAX_BYTES = 10 * 1024 * 1024  # 10 MB
LOG_FILE_BACKUP_COUNT = 5

# Version validation regex - supports semantic versions with optional prerelease and build metadata
VERSION_REGEX_PATTERN = (
    r"^\d+\.\d+\.\d+"  # core version (major.minor.patch)
    r"(?:\.[a-f0-9]+)?"  # optional hex hash (e.g., .f93d031)
    r"(?:[-\.]?(?:rc|dev|b|beta|alpha)\d+)?"  # optional prerelease (rc1, dev1, b1, beta1, alpha1)
    r"(?:\+[0-9A-Za-z]+)?"  # optional local/build metadata (e.g., +local)
    r"$"
)

# Default extraction patterns (examples for documentation)
DEFAULT_EXTRACTION_PATTERNS = [
    "rak4631-",
    "tbeam",
    "t1000-e-",
    "tlora-v2-1-1_6-",
    "device-",
    "littlefs-",
    "bleota",
]

# Configuration file names
CONFIG_FILE_NAME = "fetchtastic.yaml"
MESHTASTIC_DIR_NAME = "Meshtastic"

# Files that Fetchtastic manages and can safely clean
# Note: CONFIG_FILE_NAME is included for safety, though it's typically in CONFIG_DIR
MANAGED_FILES = (
    CONFIG_FILE_NAME,
    WINDOWS_SHORTCUT_FILE,
)

# Environment variable names
LOG_LEVEL_ENV_VAR = "FETCHTASTIC_LOG_LEVEL"

# Device Hardware API Configuration
DEVICE_HARDWARE_API_URL = "https://api.meshtastic.org/resource/deviceHardware"
DEVICE_HARDWARE_CACHE_HOURS = 24

# Cache configuration
COMMIT_TIMESTAMP_CACHE_EXPIRY_HOURS = 24

# Cache schema versions - bump when cache format changes

# GitHub Releases API cache schema version
#
# Used by:
# - FirmwareDownloader (meshtastic/firmware/releases)
# - MeshtasticAndroidAppDownloader (meshtastic/Meshtastic-Android/releases)
#
# Both downloaders share the same cache file (releases.json) and data format
# because they query the same GitHub API endpoint structure. Schema validates:
# - tag_name: string, required
# - prerelease: boolean, required
# - published_at: ISO-8601 string or null, optional
#
# Schema versioning:
# - Entries with mismatched schema_version are rejected (cache miss).
# - No migration is performed; fresh data is automatically fetched from GitHub API.
# - Given the short cache expiry, users will transparently upgrade.
# - When bumping version: update this constant and mention in release notes.
GITHUB_RELEASES_CACHE_SCHEMA_VERSION = "1.0"

# Releases API responses are cached for 10 minutes to balance API rate limiting
# with reasonably fresh data. Users can use --force-download to bypass cache.
RELEASES_CACHE_EXPIRY_HOURS = 10 / 60  # 10 minutes (in hours)
# Prerelease contents rarely change once a commit is published, so cache for a longer duration.
FIRMWARE_PRERELEASE_DIR_CACHE_EXPIRY_SECONDS = 24 * 60 * 60  # 24 hours
# Keep prerelease commit history fresh for a typical download run (5 minutes)
PRERELEASE_COMMITS_CACHE_EXPIRY_SECONDS = 5 * 60  # 5 minutes

# File Type Patterns (non-device-specific patterns)
FILE_TYPE_PREFIXES = {
    "device-",  # device-install.sh, device-update.sh
    "bleota",  # bleota.bin, bleota-c3.bin, bleota-s3.bin
}

# Standard file type identifiers used across download results
FILE_TYPE_ANDROID = "android"
FILE_TYPE_ANDROID_PRERELEASE = "android_prerelease"
FILE_TYPE_CLIENT_APP = "client_app"
FILE_TYPE_CLIENT_APP_PRERELEASE = "client_app_prerelease"
FILE_TYPE_FIRMWARE = "firmware"
FILE_TYPE_FIRMWARE_PRERELEASE = "firmware_prerelease"
FILE_TYPE_FIRMWARE_PRERELEASE_REPO = "firmware_prerelease_repo"
FILE_TYPE_FIRMWARE_MANIFEST = "firmware_manifest"
FILE_TYPE_DESKTOP = "desktop"
FILE_TYPE_DESKTOP_PRERELEASE = "desktop_prerelease"
FILE_TYPE_REPOSITORY = "repository"
FILE_TYPE_UNKNOWN = "unknown"

# Standard error type identifiers used across download results
ERROR_TYPE_NETWORK = "network_error"
ERROR_TYPE_VALIDATION = "validation_error"
ERROR_TYPE_FILESYSTEM = "filesystem_error"
ERROR_TYPE_EXTRACTION = "extraction_error"
ERROR_TYPE_RETRY_FAILURE = "retry_failure"
ERROR_TYPE_UNKNOWN = "unknown_error"

# File type sets for efficient categorization (defined once for performance)
FIRMWARE_FILE_TYPES = {
    FILE_TYPE_FIRMWARE,
    FILE_TYPE_FIRMWARE_PRERELEASE,
    FILE_TYPE_FIRMWARE_PRERELEASE_REPO,
    FILE_TYPE_FIRMWARE_MANIFEST,
}
ANDROID_FILE_TYPES = {
    FILE_TYPE_ANDROID,
    FILE_TYPE_ANDROID_PRERELEASE,
}
CLIENT_APP_FILE_TYPES = {
    FILE_TYPE_CLIENT_APP,
    FILE_TYPE_CLIENT_APP_PRERELEASE,
}
DESKTOP_FILE_TYPES = {
    FILE_TYPE_DESKTOP,
    FILE_TYPE_DESKTOP_PRERELEASE,
}

ANDROID_ARCHITECTURES = {
    "arm64": "arm64-v8a",
    "armv7": "armeabi-v7a",
    "x86_64": "x86_64",
    "universal": "universal",
}

DEFAULT_ARCH_PREFERENCE = "universal"
