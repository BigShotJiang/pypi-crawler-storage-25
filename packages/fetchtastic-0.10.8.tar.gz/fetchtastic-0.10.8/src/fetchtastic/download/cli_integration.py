"""
CLI Integration for New Download Subsystem

This module provides integration between the new download subsystem and the existing CLI.
"""

import os
import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union, cast

if TYPE_CHECKING:
    from .version import VersionManager

import requests  # type: ignore[import-untyped]

from fetchtastic.client_release_discovery import (
    is_android_asset_name,
    is_desktop_asset_name,
)
from fetchtastic.constants import (
    ANDROID_FILE_TYPES,
    CLIENT_APP_FILE_TYPES,
    DESKTOP_FILE_TYPES,
    FILE_TYPE_ANDROID,
    FILE_TYPE_ANDROID_PRERELEASE,
    FILE_TYPE_CLIENT_APP,
    FILE_TYPE_CLIENT_APP_PRERELEASE,
    FILE_TYPE_DESKTOP,
    FILE_TYPE_DESKTOP_PRERELEASE,
    FILE_TYPE_FIRMWARE,
    FILE_TYPE_FIRMWARE_MANIFEST,
    FILE_TYPE_FIRMWARE_PRERELEASE,
    FILE_TYPE_FIRMWARE_PRERELEASE_REPO,
    FILE_TYPE_REPOSITORY,
    FIRMWARE_DIR_PREFIX,
    FIRMWARE_FILE_TYPES,
)
from fetchtastic.log_utils import logger
from fetchtastic.notifications import (
    send_download_completion_notification,
    send_new_releases_available_notification,
    send_up_to_date_notification,
)
from fetchtastic.utils import (
    format_api_summary,
    get_api_request_summary,
    get_effective_github_token,
)

from .android import MeshtasticAndroidAppDownloader
from .desktop import MeshtasticDesktopDownloader
from .firmware import FirmwareReleaseDownloader
from .orchestrator import DownloadOrchestrator


class DownloadCLIIntegration:
    """
    Integrates the new download subsystem with the existing CLI.

    This class provides:
    - Compatibility with existing CLI interface
    - Translation between CLI parameters and new architecture
    - Error handling and reporting
    - Progress reporting
    """

    def __init__(self) -> None:
        """
        Initialize a DownloadCLIIntegration instance and set initial internal state.

        Sets attributes used to connect CLI to download subsystem:
        - orchestrator: Orchestrator instance or None until initialized.
        - android_downloader: Android downloader instance or None until initialized.
        - firmware_downloader: Firmware downloader instance or None until initialized.
        - config: Configuration mapping or None until provided.
        """
        self.orchestrator: Optional[DownloadOrchestrator] = None
        self.android_downloader: Optional[MeshtasticAndroidAppDownloader] = None
        self.desktop_downloader: Optional[MeshtasticDesktopDownloader] = None
        self.firmware_downloader: Optional[FirmwareReleaseDownloader] = None
        self.config: Optional[Dict[str, Any]] = None

    def _empty_cli_integration_result(self, include_desktop: bool) -> Union[
        Tuple[list, list, list, list, list, list, list, str, str],
        Tuple[
            list,
            list,
            list,
            list,
            list,
            list,
            list,
            list,
            list,
            list,
            str,
            str,
            str,
        ],
    ]:
        """
        Return an empty CLI integration result tuple of the appropriate shape.

        Parameters:
            include_desktop (bool): If True, return a 13-item tuple with desktop fields;
                otherwise return a 9-item tuple.

        Returns:
            Union[Tuple[...], Tuple[...]]: Empty tuple matching the expected return shape.
        """
        if include_desktop:
            return ([], [], [], [], [], [], [], [], [], [], "", "", "")
        else:
            return ([], [], [], [], [], [], [], "", "")

    def _initialize_components(self, config: Dict[str, Any]) -> None:
        """
        Set up the DownloadOrchestrator and expose its downloaders on the integration instance.

        Stores the provided configuration on self, constructs a DownloadOrchestrator using that configuration, and assigns the orchestrator's android_downloader and firmware_downloader to instance attributes for shared state and caches.

        Parameters:
            config (Dict[str, Any]): Configuration used to initialize the orchestrator and downloaders.
        """
        self.config = config
        self.orchestrator = DownloadOrchestrator(config)
        # Reuse the orchestrator's downloaders so state and caches stay unified
        self.android_downloader = self.orchestrator.android_downloader
        self.desktop_downloader = self.orchestrator.desktop_downloader
        self.firmware_downloader = self.orchestrator.firmware_downloader

    def run_download(
        self,
        config: Dict[str, Any],
        force_refresh: bool = False,
        include_desktop: bool = False,
    ) -> Union[
        Tuple[
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[Dict[str, Any]],
            str,
            str,
        ],  # Legacy 9-item tuple
        Tuple[
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[Dict[str, Any]],
            str,
            str,
            str,
        ],  # Extended 13-item tuple with desktop
    ]:
        """
        Run the download pipeline using the provided configuration and return results formatted for the legacy CLI.

        Initializes the orchestrator and downloaders from `config`, optionally clears downloader caches when `force_refresh` is True, executes the download pipeline, performs cleanup and version tracking, and collects failed download records.

        Parameters:
            config (Dict[str, Any]): Configuration used to initialize the orchestrator and downloaders.
            force_refresh (bool): If True, clear downloader caches before running the pipeline.
            include_desktop (bool): If True, include desktop download results. When True, the return tuple will be extended with 4 additional fields: downloaded_desktop, new_desktop_versions, downloaded_desktop_prereleases, and latest_desktop_version.

        Returns:
            Tuple containing (by default, 9 items):
                - downloaded_firmwares: Paths or identifiers of firmware files that were downloaded.
                - new_firmware_versions: Firmware release tags that are newer than the currently tracked firmware.
                - downloaded_apks: Paths or identifiers of Android APK files that were downloaded.
                - new_apk_versions: Android release tags that are newer than the currently tracked Android version.
                - downloaded_firmware_prereleases: Paths or identifiers of firmware prerelease files that were downloaded.
                - downloaded_apk_prereleases: Paths or identifiers of Android APK prerelease files that were downloaded.
                - failed_downloads: List of failure records; each record includes keys such as `file_name`, `release_tag`, `url`, `type`, `path_to_download`, `error`, `retryable`, and `http_status`.
                - latest_firmware_version: Latest known firmware version (empty string if unavailable).
                - latest_apk_version: Latest known Android APK version (empty string if unavailable).

            When include_desktop=True, the tuple is extended with 4 additional fields (13 items total):
                - downloaded_desktop: Paths or identifiers of desktop files that were downloaded.
                - new_desktop_versions: Desktop release tags that are newer than the currently tracked desktop version.
                - downloaded_desktop_prereleases: Paths or identifiers of desktop prerelease files that were downloaded.
                - latest_desktop_version: Latest known desktop version (empty string if unavailable).
        """
        try:
            self._initialize_components(config)
            # _initialize_components guarantees orchestrator is set
            if self.orchestrator is None:
                raise RuntimeError("Failed to initialize download orchestrator")
            orchestrator = self.orchestrator

            tracked_versions = (
                self._get_tracked_desktop_versions() if include_desktop else None
            )

            # Clear caches if force refresh is requested
            if force_refresh and not self._clear_caches():
                raise OSError("Failed to clear downloader caches for force refresh")

            # Run the download pipeline
            success_results, _failed_results = orchestrator.run_download_pipeline()

            # Convert results to legacy format
            (
                downloaded_firmwares,
                new_firmware_versions,
                downloaded_apks,
                new_apk_versions,
                downloaded_desktop,
                new_desktop_versions,
                downloaded_firmware_prereleases,
                downloaded_apk_prereleases,
                downloaded_desktop_prereleases,
            ) = self._convert_results_to_legacy_format(
                success_results,
                tracked_versions=tracked_versions,
            )

            # Handle cleanup
            orchestrator.cleanup_old_versions()

            # Update version tracking
            orchestrator.update_version_tracking()

            # Get failed downloads
            failed_downloads = self.get_failed_downloads()

            # Get latest versions
            latest_versions = (
                self.orchestrator.get_latest_versions() if self.orchestrator else {}
            )
            latest_firmware_version = latest_versions.get("firmware", "") or ""
            latest_apk_version = latest_versions.get("android", "") or ""
            latest_desktop_version = latest_versions.get("desktop", "") or ""

            # Return legacy 9-item tuple by default, or extended 13-item tuple if include_desktop=True
            if include_desktop:
                return (
                    downloaded_firmwares,
                    new_firmware_versions,
                    downloaded_apks,
                    new_apk_versions,
                    downloaded_desktop,
                    new_desktop_versions,
                    downloaded_firmware_prereleases,
                    downloaded_apk_prereleases,
                    downloaded_desktop_prereleases,
                    failed_downloads,
                    latest_firmware_version,
                    latest_apk_version,
                    latest_desktop_version,
                )
            else:
                return (
                    downloaded_firmwares,
                    new_firmware_versions,
                    downloaded_apks,
                    new_apk_versions,
                    downloaded_firmware_prereleases,
                    downloaded_apk_prereleases,
                    failed_downloads,
                    latest_firmware_version,
                    latest_apk_version,
                )

        except (
            requests.RequestException,
            OSError,
            ValueError,
            TypeError,
            KeyError,
        ) as e:
            logger.exception("Error in CLI integration: %s", e)
            # Return empty tuple with appropriate shape based on include_desktop
            return self._empty_cli_integration_result(include_desktop)

    def _get_tracked_desktop_versions(self) -> Dict[str, Optional[str]]:
        """
        Return desktop tracking versions from local tracking files before a pipeline run.

        Returns:
            Dict[str, Optional[str]]: Mapping with keys `current` and
                `prerelease` representing locally tracked versions.
        """
        tracked_desktop: Optional[str] = None
        tracked_desktop_prerelease: Optional[str] = None

        if self.desktop_downloader:
            try:
                tracked_desktop = self.desktop_downloader.get_latest_release_tag()
            except (OSError, ValueError, TypeError):
                tracked_desktop = None

            try:
                tracking_file = self.desktop_downloader.get_prerelease_tracking_file()
                if (
                    isinstance(tracking_file, str)
                    and tracking_file
                    and os.path.exists(tracking_file)
                ):
                    tracking_data = (
                        self.desktop_downloader.cache_manager.read_json(tracking_file)
                        or {}
                    )
                    if isinstance(tracking_data, dict):
                        tracked_value = tracking_data.get("latest_version")
                        if isinstance(tracked_value, str):
                            tracked_desktop_prerelease = tracked_value
            except (OSError, ValueError, TypeError, KeyError):
                tracked_desktop_prerelease = None

        if not isinstance(tracked_desktop, str):
            tracked_desktop = None
        if not isinstance(tracked_desktop_prerelease, str):
            tracked_desktop_prerelease = None

        return {
            "current": tracked_desktop,
            "prerelease": tracked_desktop_prerelease,
        }

    def _clear_caches(self) -> bool:
        """
        Clear downloader caches managed by this integration.

        This calls the Android downloader's cache manager to remove all cached data; exceptions raised during the clear operation (e.g., OSError, ValueError) are caught and logged and are not propagated.

        Returns:
            bool: True if cache was cleared successfully, False otherwise.
        """
        try:
            # Clear shared cache manager (same instance used by all downloaders)
            success = True
            if self.android_downloader:
                if not self.android_downloader.clear_cache():
                    logger.warning("Failed to clear cache for Android downloader")
                    success = False

            if success:
                logger.info("All caches cleared")
            return success

        except (OSError, ValueError) as e:
            logger.warning(f"Error clearing caches: {e}")
            return False

    def log_download_results_summary(
        self,
        *,
        logger_override: Any = None,
        elapsed_seconds: float,
        downloaded_firmwares: List[str],
        downloaded_apks: List[str],
        downloaded_firmware_prereleases: Optional[List[str]] = None,
        downloaded_apk_prereleases: Optional[List[str]] = None,
        downloaded_desktop: Optional[List[str]] = None,
        downloaded_desktop_prereleases: Optional[List[str]] = None,
        failed_downloads: List[Dict[str, Any]],
        latest_firmware_version: str,
        latest_apk_version: str,
        latest_desktop_version: str = "",
        new_firmware_versions: Optional[List[str]] = None,
        new_apk_versions: Optional[List[str]] = None,
        new_desktop_versions: Optional[List[str]] = None,
    ) -> None:
        """
        Emit a legacy-style summary of download results to the provided logger.

        Logs elapsed time, counts of downloaded assets, latest release and prerelease tags, detailed information about any failed downloads, and a GitHub API usage summary. If no downloads or failures occurred, logs an up-to-date timestamp. If this instance has a configured `config`, sends notifications for completion or up-to-date state.

        Parameters:
            logger_override (logging-like, optional): Logger to use instead of the module logger.
            elapsed_seconds (float): Total time elapsed for the download run.
            downloaded_firmwares (List[str]): Downloaded firmware filenames or tags.
            downloaded_apks (List[str]): Downloaded APK filenames or tags.
            downloaded_firmware_prereleases (Optional[List[str]]): Downloaded firmware prerelease tags, if any.
            downloaded_apk_prereleases (Optional[List[str]]): Downloaded APK prerelease tags, if any.
            downloaded_desktop (Optional[List[str]]): Downloaded desktop filenames or tags.
            downloaded_desktop_prereleases (Optional[List[str]]): Downloaded desktop prerelease tags, if any.
            latest_desktop_version (str): Reported latest desktop release tag (empty string if none).
            new_firmware_versions (List[str]): Retained for backward compatibility; not used by this method.
            new_apk_versions (List[str]): Retained for backward compatibility; not used by this method.
            new_desktop_versions (List[str]): Retained for backward compatibility; not used by this method.
        """
        log = logger_override or logger

        if self.orchestrator:
            self.orchestrator.log_firmware_release_history_summary()

        log.info(f"\nCompleted in {elapsed_seconds:.1f}s")

        downloaded_firmware_prereleases = downloaded_firmware_prereleases or []
        downloaded_apk_prereleases = downloaded_apk_prereleases or []
        downloaded_desktop = downloaded_desktop or []
        downloaded_desktop_prereleases = downloaded_desktop_prereleases or []
        downloaded_count = (
            len(downloaded_firmwares)
            + len(downloaded_apks)
            + len(downloaded_desktop)
            + len(downloaded_firmware_prereleases)
            + len(downloaded_apk_prereleases)
            + len(downloaded_desktop_prereleases)
        )
        if downloaded_count > 0:
            log.info(f"Downloaded {downloaded_count} new versions")

        latest_versions = self.get_latest_versions()
        latest_firmware_prerelease = latest_versions.get("firmware_prerelease")
        # Prefer the unified client app key; fall back to legacy APK/Desktop
        # values while older result summaries and config files are transitioning.
        latest_client_app = (
            latest_versions.get("client_app")
            or latest_apk_version
            or latest_desktop_version
        )
        # Same compatibility fallback for the unified prerelease line.
        latest_client_app_prerelease = (
            latest_versions.get("client_app_prerelease")
            or latest_versions.get("android_prerelease")
            or latest_versions.get("desktop_prerelease")
        )

        if latest_firmware_version:
            log.info(f"Latest firmware: {latest_firmware_version}")
        if latest_firmware_prerelease:
            log.info(f"Latest firmware prerelease: {latest_firmware_prerelease}")
        else:
            log.info("Latest firmware prerelease: none")

        if latest_client_app:
            log.info("Latest Meshtastic Client release: %s", latest_client_app)
        if latest_client_app_prerelease:
            log.info(
                "Latest Meshtastic Client prerelease: %s",
                latest_client_app_prerelease,
            )
        else:
            log.info("Latest Meshtastic Client prerelease: none")

        if failed_downloads:
            log.info(f"{len(failed_downloads)} downloads failed:")
            for failure in failed_downloads:
                url = failure.get("url", "unknown")
                retryable = failure.get("retryable")
                http_status = failure.get("http_status")
                error = failure.get("error", "")
                log.info(
                    f"- {failure.get('type', 'Unknown')} {failure.get('release_tag', '')}: "
                    f"{failure.get('file_name', 'unknown')} "
                    f"URL={url} retryable={retryable} http_status={http_status} error={error}"
                )

        if downloaded_count == 0 and not failed_downloads:
            log.info(
                "All assets are up to date.\n%s",
                time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            )
        elif downloaded_count == 0 and failed_downloads:
            log.info("All attempted downloads failed; check logs for details.")

        new_versions_available = bool(
            (new_firmware_versions or [])
            or (new_apk_versions or [])
            or (new_desktop_versions or [])
        )

        # Send notifications based on download results
        if self.config:
            if downloaded_count > 0:
                send_download_completion_notification(
                    self.config,
                    downloaded_firmwares,
                    downloaded_apks,
                    downloaded_firmware_prereleases,
                    downloaded_apk_prereleases,
                    downloaded_desktop,
                    downloaded_desktop_prereleases,
                )
            elif self.orchestrator and self.orchestrator.wifi_skipped:
                send_new_releases_available_notification(
                    self.config,
                    self.orchestrator.available_new_firmware_versions,
                    self.orchestrator.available_new_apk_versions,
                    downloads_skipped_reason="Downloads skipped: not connected to Wi-Fi.",
                )
            elif not failed_downloads and not new_versions_available:
                send_up_to_date_notification(self.config)

        summary = get_api_request_summary()
        if summary.get("total_requests", 0) > 0:
            log.debug(format_api_summary(summary))
        else:
            log.debug(
                "📊 GitHub API Summary: No API requests made (all data served from cache)"
            )

    def _convert_results_to_legacy_format(
        self,
        success_results: List[Any],
        tracked_versions: Optional[Dict[str, Optional[str]]] = None,
    ) -> Tuple[
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
    ]:
        """
        Translate new-architecture successful download results into legacy CLI lists.

        Parameters:
            success_results (List[Any]): Iterable of result objects from the orchestrator; each object may have attributes `release_tag`, `file_path`, and `was_skipped`.
            tracked_versions (Optional[Dict[str, Optional[str]]]): Optional local
                tracking values to prefer over remote/latest release tags for
                version comparison.

        Returns:
            Tuple containing:
                - downloaded_firmwares: Unique firmware release tags that were downloaded (excludes skipped results).
                - new_firmware_versions: Firmware release tags from `downloaded_firmwares` that are newer than the currently known firmware version.
                - downloaded_apks: Unique Android (APK) release tags that were downloaded (excludes skipped results).
                - new_apk_versions: Android release tags from `downloaded_apks` that are newer than the currently known Android version.
                - downloaded_desktop: Unique desktop release tags that were downloaded (excludes skipped results).
                - new_desktop_versions: Desktop release tags that are newer than the currently known desktop version.
                - downloaded_firmware_prereleases: Unique firmware prerelease release tags that were downloaded (excludes skipped results).
                - downloaded_apk_prereleases: Unique Android (APK) prerelease release tags that were downloaded (excludes skipped results).
                - downloaded_desktop_prereleases: Unique desktop prerelease release tags that were downloaded (excludes skipped results).
        """
        downloaded_firmwares: list[str] = []
        new_firmware_versions: list[str] = []
        downloaded_apks: list[str] = []
        new_apk_versions: list[str] = []
        downloaded_desktop: list[str] = []
        new_desktop_versions: list[str] = []
        downloaded_firmware_prereleases: list[str] = []
        downloaded_apk_prereleases: list[str] = []
        downloaded_desktop_prereleases: list[str] = []
        downloaded_firmware_set: set[str] = set()
        downloaded_apk_set: set[str] = set()
        downloaded_desktop_set: set[str] = set()
        downloaded_firmware_prerelease_set: set[str] = set()
        downloaded_apk_prerelease_set: set[str] = set()
        downloaded_desktop_prerelease_set: set[str] = set()
        new_firmware_set: set[str] = set()
        new_apk_set: set[str] = set()
        new_desktop_set: set[str] = set()

        latest_versions: Dict[str, Optional[str]] = {}
        if self.orchestrator:
            latest_versions = cast(
                Dict[str, Optional[str]],
                self.orchestrator.get_latest_versions(),
            )
        if tracked_versions:
            # Map tracked version keys to expected latest_versions keys
            if tracked_versions.get("current"):
                latest_versions["desktop"] = tracked_versions["current"]
            if tracked_versions.get("prerelease"):
                latest_versions["desktop_prerelease"] = tracked_versions["prerelease"]

        current_android = latest_versions.get("android")
        current_firmware = latest_versions.get("firmware")
        current_android_prerelease = latest_versions.get("android_prerelease")
        current_firmware_prerelease = latest_versions.get("firmware_prerelease")
        current_desktop = latest_versions.get("desktop")
        current_desktop_prerelease = latest_versions.get("desktop_prerelease")

        for result in success_results:
            release_tag = result.release_tag
            if not release_tag:
                continue

            file_type = result.file_type
            is_firmware_manifest = file_type == FILE_TYPE_FIRMWARE_MANIFEST
            is_firmware = file_type in FIRMWARE_FILE_TYPES and not is_firmware_manifest
            is_android = file_type in ANDROID_FILE_TYPES
            is_desktop = file_type in DESKTOP_FILE_TYPES
            is_client_app = file_type in CLIENT_APP_FILE_TYPES
            is_client_app_prerelease = file_type == FILE_TYPE_CLIENT_APP_PRERELEASE
            if is_client_app:
                file_path = getattr(result, "file_path", None)
                download_url = getattr(result, "download_url", None)
                file_name = (
                    os.path.basename(str(file_path))
                    if file_path
                    else os.path.basename(str(download_url)) if download_url else ""
                )
                is_android = is_android or is_android_asset_name(file_name)
                is_desktop = is_desktop or is_desktop_asset_name(file_name)
                if not is_android and not is_desktop:
                    logger.debug("Unclassified client app asset, defaulting to Android")
                    is_android = True
            is_android_prerelease = file_type == FILE_TYPE_ANDROID_PRERELEASE or (
                is_client_app_prerelease and is_android
            )
            is_desktop_prerelease = file_type == FILE_TYPE_DESKTOP_PRERELEASE or (
                is_client_app_prerelease and is_desktop
            )
            was_skipped = getattr(result, "was_skipped", False)

            # Legacy parity: only mark new versions when a download actually occurred.
            if was_skipped:
                continue

            if is_firmware:
                compare_current = current_firmware
                compare_release_tag = None
                if file_type in {
                    FILE_TYPE_FIRMWARE_PRERELEASE,
                    FILE_TYPE_FIRMWARE_PRERELEASE_REPO,
                }:
                    compare_release_tag = self._normalize_firmware_prerelease_tag(
                        release_tag
                    )
                    compare_current = self._normalize_firmware_prerelease_tag(
                        current_firmware_prerelease or current_firmware
                    )
                self._update_new_versions(
                    release_tag,
                    compare_current,
                    new_firmware_versions,
                    new_firmware_set,
                    comparison_release_tag=compare_release_tag,
                )
            if is_android:
                compare_current = current_android
                if is_android_prerelease:
                    compare_current = current_android_prerelease or current_android
                self._update_new_versions(
                    release_tag,
                    compare_current,
                    new_apk_versions,
                    new_apk_set,
                )
            if is_desktop:
                compare_current = current_desktop
                if is_desktop_prerelease:
                    compare_current = current_desktop_prerelease or current_desktop
                self._update_new_versions(
                    release_tag,
                    compare_current,
                    new_desktop_versions,
                    new_desktop_set,
                )

            if is_firmware:
                if file_type in {
                    FILE_TYPE_FIRMWARE_PRERELEASE,
                    FILE_TYPE_FIRMWARE_PRERELEASE_REPO,
                }:
                    if release_tag not in downloaded_firmware_prerelease_set:
                        downloaded_firmware_prereleases.append(release_tag)
                        downloaded_firmware_prerelease_set.add(release_tag)
                else:
                    self._add_downloaded_asset(
                        release_tag, downloaded_firmwares, downloaded_firmware_set
                    )
            if is_android:
                if is_android_prerelease:
                    if release_tag not in downloaded_apk_prerelease_set:
                        downloaded_apk_prereleases.append(release_tag)
                        downloaded_apk_prerelease_set.add(release_tag)
                else:
                    self._add_downloaded_asset(
                        release_tag, downloaded_apks, downloaded_apk_set
                    )
            if is_desktop:
                if is_desktop_prerelease:
                    if release_tag not in downloaded_desktop_prerelease_set:
                        downloaded_desktop_prereleases.append(release_tag)
                        downloaded_desktop_prerelease_set.add(release_tag)
                else:
                    self._add_downloaded_asset(
                        release_tag, downloaded_desktop, downloaded_desktop_set
                    )

        return (
            downloaded_firmwares,
            new_firmware_versions,
            downloaded_apks,
            new_apk_versions,
            downloaded_desktop,
            new_desktop_versions,
            downloaded_firmware_prereleases,
            downloaded_apk_prereleases,
            downloaded_desktop_prereleases,
        )

    def _update_new_versions(
        self,
        release_tag: str,
        current_version: Optional[str],
        new_versions_list: List[str],
        new_versions_set: set[str],
        *,
        comparison_release_tag: Optional[str] = None,
    ) -> None:
        """
        Add release_tag to new_versions_list and new_versions_set if it is not already present and is newer than current_version.

        Parameters:
            release_tag (str): The release tag to consider for recording.
            current_version (Optional[str]): The existing version to compare against; if None, release_tag is treated as newer.
            new_versions_list (List[str]): Mutable list to append the release_tag to when it is new.
            new_versions_set (set[str]): Mutable set used to ensure uniqueness of recorded versions.
            comparison_release_tag (Optional[str]): If provided, this tag is used for version comparison instead of release_tag.
        """
        compare_tag = comparison_release_tag or release_tag
        if release_tag not in new_versions_set and (
            not current_version or self._is_newer_version(compare_tag, current_version)
        ):
            new_versions_list.append(release_tag)
            new_versions_set.add(release_tag)

    def _normalize_firmware_prerelease_tag(self, tag: Optional[str]) -> Optional[str]:
        """
        Normalize a firmware prerelease tag by removing the configured firmware directory prefix if present.

        Parameters:
            tag (Optional[str]): A prerelease tag that may be prefixed with FIRMWARE_DIR_PREFIX.

        Returns:
            normalized_tag (Optional[str]): The tag with FIRMWARE_DIR_PREFIX stripped if it was present;
                otherwise the original tag (or None/empty unchanged).
        """
        if not tag:
            return tag
        return tag.removeprefix(FIRMWARE_DIR_PREFIX)

    def _add_downloaded_asset(
        self,
        release_tag: str,
        downloaded_list: List[str],
        downloaded_set: set[str],
    ) -> None:
        """
        Add a release tag to the downloaded list while ensuring uniqueness via the downloaded set.

        Parameters:
            release_tag: The release tag to record.
            downloaded_list: Ordered list of recorded release tags; the tag is appended if not already recorded.
            downloaded_set: Set used to track recorded tags for fast membership checks and to prevent duplicates.
        """
        if release_tag not in downloaded_set:
            downloaded_list.append(release_tag)
            downloaded_set.add(release_tag)

    def _is_newer_version(self, version1: str, version2: str) -> bool:
        """
        Determine whether `version1` represents a newer version than `version2`.

        Parameters:
            version1 (str): Version string to compare.
            version2 (str): Version string to compare against.

        Returns:
            bool: `True` if `version1` represents a newer version than `version2`, `False` otherwise.
        """
        version_manager = self._get_version_manager()
        comparison = (
            version_manager.compare_versions(version1, version2)
            if version_manager
            else 0
        )
        return comparison > 0

    def _get_version_manager(self) -> Optional["VersionManager"]:
        """
        Acquire version manager exposed by Android downloader.
        """
        if not self.android_downloader:
            return None
        # Check for method first (for backward compatibility and mocks),
        # then fall back to direct attribute access
        getter = getattr(self.android_downloader, "get_version_manager", None)
        if callable(getter):
            result = getter()
            return cast(Optional["VersionManager"], result)
        result = getattr(self.android_downloader, "version_manager", None)
        return cast(Optional["VersionManager"], result)

    def get_failed_downloads(self) -> List[Dict[str, Any]]:
        """
        Builds a legacy-formatted list describing failed downloads.

        Each item is a dict with the following keys:
            file_name: Base filename of the intended download or "unknown".
            release_tag: Associated release tag or "unknown".
            url: Download URL or "unknown".
            type: Human-readable file type (e.g., "Firmware", "Android APK", "Repository", "Firmware Prerelease", "Android APK Prerelease", or "Unknown").
            path_to_download: Full path where the file was to be saved, or "unknown".
            error: Error message for the failure, or empty string if none.
            retryable: Whether the failure is considered retryable.
            http_status: HTTP status code associated with the failure, or None if not applicable.

        Returns:
            List[Dict[str, Any]]: The list of failed download records. Returns an empty list if the integration is not initialized or there are no failures.
        """
        if not self.orchestrator:
            return []

        failed_downloads = []

        file_type_map = {
            FILE_TYPE_FIRMWARE: "Firmware",
            FILE_TYPE_FIRMWARE_MANIFEST: "Firmware Manifest",
            FILE_TYPE_ANDROID: "Android APK",
            FILE_TYPE_FIRMWARE_PRERELEASE: "Firmware Prerelease",
            FILE_TYPE_FIRMWARE_PRERELEASE_REPO: "Firmware Prerelease",
            FILE_TYPE_REPOSITORY: "Repository",
            FILE_TYPE_ANDROID_PRERELEASE: "Android APK Prerelease",
            FILE_TYPE_DESKTOP: "Desktop",
            FILE_TYPE_DESKTOP_PRERELEASE: "Desktop Prerelease",
            FILE_TYPE_CLIENT_APP: "Client App",
            FILE_TYPE_CLIENT_APP_PRERELEASE: "Client App Prerelease",
        }

        for result in self.orchestrator.failed_downloads:
            failure_type = (
                file_type_map.get(result.file_type, "Unknown")
                if result.file_type
                else "Unknown"
            )
            failed_downloads.append(
                {
                    "file_name": (
                        os.path.basename(str(result.file_path))
                        if result.file_path
                        else "unknown"
                    ),
                    "release_tag": result.release_tag or "unknown",
                    "url": result.download_url or "unknown",
                    "type": failure_type,
                    "path_to_download": (
                        str(result.file_path) if result.file_path else "unknown"
                    ),
                    "error": result.error_message or "",
                    "retryable": result.is_retryable,
                    "http_status": result.http_status_code,
                }
            )

        return failed_downloads

    def main(
        self,
        config: Dict[str, Any],
        force_refresh: bool = False,
        include_desktop: bool = False,
    ) -> Union[
        Tuple[
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[Dict[str, Any]],
            str,
            str,
        ],  # Legacy 9-item tuple
        Tuple[
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[str],
            List[Dict[str, Any]],
            str,
            str,
            str,
        ],  # Extended 13-item tuple with desktop
    ]:
        """
        Entry point for CLI commands that uses a provided configuration, normalizes tokens, and runs the download workflow to produce legacy-compatible results.

         Parameters:
            config (Dict[str, Any]): Configuration mapping for the download run. Must not be None; passing None raises TypeError.
            force_refresh (bool): When True, forces refresh behavior for downloaders (e.g., clears caches) for this run.
            include_desktop (bool): If True, include desktop download results. When True, the return tuple will be extended with 4 additional fields: downloaded_desktop, new_desktop_versions, downloaded_desktop_prereleases, and latest_desktop_version.

        Returns:
            Tuple containing (by default, 9 items):
                downloaded_firmwares (List[str]): List of firmware release tags or identifiers that were downloaded during the run.
                new_firmware_versions (List[str]): Subset of downloaded_firmwares that are newer than previously known firmware versions.
                downloaded_apks (List[str]): List of Android APK release tags or identifiers that were downloaded during the run.
                new_apk_versions (List[str]): Subset of downloaded_apks that are newer than previously known APK versions.
                downloaded_firmware_prereleases (List[str]): List of firmware prerelease release tags or identifiers that were downloaded during the run.
                downloaded_apk_prereleases (List[str]): List of Android APK prerelease release tags or identifiers that were downloaded during the run.
                failed_downloads (List[Dict[str, Any]]): List of failure records formatted for legacy CLI consumption; each record includes keys like file_name, release_tag, url, type, path_to_download, error, retryable, and http_status.
                latest_firmware_version (str): The latest known firmware version after the run (empty string if unknown).
                latest_apk_version (str): The latest known Android APK version after the run (empty string if unknown).

            When include_desktop=True, the tuple is extended with 4 additional fields (13 items total):
                downloaded_desktop (List[str]): List of desktop release tags or identifiers that were downloaded during the run.
                new_desktop_versions (List[str]): Subset of downloaded_desktop that are newer than previously known desktop versions.
                downloaded_desktop_prereleases (List[str]): List of desktop prerelease release tags or identifiers that were downloaded during the run.
                latest_desktop_version (str): The latest known desktop version after the run (empty string if unknown).
        """
        if config is None:
            raise TypeError("config must be provided to the download integration.")

        try:
            # Normalize token once for the run so all downstream call sites see the
            # same effective value (config token preferred, env token fallback).
            config_token = get_effective_github_token(
                config.get("GITHUB_TOKEN"),
                allow_env_token=config.get("ALLOW_ENV_TOKEN", True),
            )
            if config_token:
                config["GITHUB_TOKEN"] = config_token
            else:
                config.pop("GITHUB_TOKEN", None)

            results = self.run_download(config, force_refresh, include_desktop)
            return results

        except (
            requests.RequestException,
            OSError,
            ValueError,
            TypeError,
            KeyError,
        ) as error:
            self.handle_cli_error(error)
            # Return empty tuple with appropriate shape based on include_desktop
            return self._empty_cli_integration_result(include_desktop)

    def clear_cache(self, config: Dict[str, Any]) -> bool:
        """
        Clear all download caches without running the download pipeline.

        Parameters:
            config (Dict[str, Any]): Configuration mapping for cache clear.

        Returns:
            bool: True if caches were cleared successfully, False otherwise.
        """
        try:
            self._initialize_components(config)
            return self._clear_caches()

        except (
            requests.RequestException,
            OSError,
            ValueError,
            TypeError,
            KeyError,
        ) as error:
            self.handle_cli_error(error)
            return False

    def get_download_statistics(self) -> Dict[str, Any]:
        """
        Summarizes download attempts and outcomes for the current run.

        Returns:
            dict: Mapping with the following keys:
                - "total_downloads": number of attempted downloads (excludes skipped results).
                - "successful_downloads": number of completed, non-skipped downloads.
                - "skipped_downloads": number of downloads marked as skipped.
                - "failed_downloads": number of failed downloads.
                - "success_rate": overall success percentage as a float (0-100).
                - "client_app_downloads": count of successful client app artifact downloads.
                - "firmware_downloads": count of successful firmware artifact downloads.
                - "android_downloads": legacy compat — count of client app downloads with Android-compatible filenames.
                - "desktop_downloads": legacy compat — count of client app downloads with Desktop-compatible filenames.
                - "repository_downloads": count of repository downloads (always 0 for automatic pipeline).
        """
        if self.orchestrator:
            return self.orchestrator.get_download_statistics()
        return {
            "total_downloads": 0,
            "successful_downloads": 0,
            "skipped_downloads": 0,
            "failed_downloads": 0,
            "success_rate": 0.0,
            "client_app_downloads": 0,
            "firmware_downloads": 0,
            "android_downloads": 0,
            "desktop_downloads": 0,
            "repository_downloads": 0,
        }

    def get_latest_versions(self) -> Dict[str, str]:
        """
        Get the latest known version strings for each artifact type.

        Returns:
            dict: Mapping with keys 'android', 'firmware', 'firmware_prerelease', 'android_prerelease', 'desktop', and 'desktop_prerelease' to the latest version string for each; an empty string indicates the version is not available.
        """
        versions: Dict[str, Any] = {
            "android": "",
            "firmware": "",
            "firmware_prerelease": "",
            "android_prerelease": "",
            "desktop": "",
            "desktop_prerelease": "",
            "client_app": "",
            "client_app_prerelease": "",
        }
        if self.orchestrator:
            versions.update(self.orchestrator.get_latest_versions())
        # Convert Optional[str] to str for compatibility
        return {k: v or "" for k, v in versions.items()}

    def handle_cli_error(self, error: Exception) -> None:
        logger.error(f"CLI Error: {error!s}")

        if isinstance(error, ImportError):
            logger.error(
                "Import error - please check your Python environment and dependencies"
            )
        elif isinstance(error, FileNotFoundError):
            logger.error("File not found - please check your configuration and paths")
        elif isinstance(error, PermissionError):
            logger.error("Permission error - please check file system permissions")
        elif isinstance(
            error, (requests.ConnectionError, requests.Timeout, ConnectionError)
        ):
            logger.error(
                "Network connection error - please check your internet connection"
            )
        else:
            logger.error("An unexpected error occurred - please check logs for details")
