"""
Base Downloader Implementation

This module provides the base implementation of the Downloader interface
that can be extended by specific artifact downloaders.

Supports both synchronous and asynchronous download operations:
- download(): Synchronous file download
- async_download(): Asynchronous file download with progress tracking
"""

import asyncio
import fnmatch
import os
import zipfile
from abc import ABC
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, cast

from requests.exceptions import RequestException  # type: ignore[import-untyped]

from fetchtastic import utils
from fetchtastic.log_utils import logger
from fetchtastic.utils import load_file_hash, matches_selected_patterns

from .async_core import AsyncDownloadCoreMixin
from .cache import CacheManager
from .files import (
    FileOperations,
    _sanitize_path_component,
    is_zip_intact,
    strip_unwanted_chars,
)
from .interfaces import Asset, Downloader, DownloadResult, Pathish
from .version import VersionManager

if TYPE_CHECKING:
    from .interfaces import Release

# Type alias for async progress callbacks
AsyncProgressCallback = Callable[[int, Optional[int], str], Any]


_MISSING_HISTORY_MANAGER_MSG = (
    "{cls} does not have a release_history_manager and cannot check revoked status"
)


class BaseDownloader(AsyncDownloadCoreMixin, Downloader, ABC):
    """
    Base implementation of the Downloader interface.

    This class provides common functionality that can be used by all
    specific downloaders (Android, Firmware, etc.).
    """

    def __init__(
        self, config: Dict[str, Any], cache_manager: Optional[CacheManager] = None
    ):
        """
        Initialize the downloader with configuration and an optional cache manager.

        Parameters:
            config (Dict[str, Any]): Downloader configuration. Recognized keys include "DOWNLOAD_DIR" (path to store downloads, defaults to "~/meshtastic") and "VERSIONS_TO_KEEP" (number of release versions to retain, defaults to 5).
            cache_manager (Optional[CacheManager]): Cache manager to use; if omitted a new CacheManager is created and used.

        Initializes internal helpers including a VersionManager, FileOperations, and the cache manager, and normalizes the configured download directory and versions-to-keep value.
        """
        self.config = config
        self.version_manager = VersionManager()
        if cache_manager is None:
            cache_manager = CacheManager()
        self.cache_manager: CacheManager = cache_manager
        self.file_operations = FileOperations()

        # Initialize common configuration with normalized paths
        self.download_dir = str(Path(self.get_download_dir()))
        self.versions_to_keep = self._get_versions_to_keep()

        # Semaphore for concurrent download control (lazy-initialized)
        self._semaphore: Optional[asyncio.Semaphore] = None
        # Shared aiohttp session for async downloads (lazy-initialized)
        self._session: Optional[Any] = None

    def get_download_dir(self) -> str:
        """
        Get the configured download directory.

        If the configuration does not provide "DOWNLOAD_DIR", returns the default path "~/meshtastic".

        Returns:
            The resolved download directory path as a string.
        """
        return cast(
            str, self.config.get("DOWNLOAD_DIR", os.path.expanduser("~/meshtastic"))
        )

    def _get_versions_to_keep(self) -> int:
        """
        Get the number of release versions to retain.

        Reads the 'VERSIONS_TO_KEEP' configuration value and returns it as an int; defaults to 5 if unset.

        Returns:
            int: Number of versions to keep.
        """
        return int(self.config.get("VERSIONS_TO_KEEP", 5))

    def clear_cache(self) -> bool:
        """
        Clear all cached data in the shared downloader cache manager.

        This delegates to the shared cache manager instance to remove cached API
        responses, release listings, and related cache files used across downloader
        instances that share the same cache directory.

        Returns:
            bool: True if cache was cleared successfully, False otherwise.
        """
        return self.cache_manager.clear_all_caches()

    def clear_all_caches(self) -> bool:
        """
        Clear the shared downloader cache manager.

        This explicit alias mirrors :meth:`clear_cache` and makes the cross-downloader
        scope of this operation clearer at call sites.
        """
        return self.clear_cache()

    async def _ensure_async_session(self, aiohttp_module: Optional[Any] = None) -> Any:
        """
        Backward-compatible alias to shared session creation.

        Parameters:
            aiohttp_module (Optional[Any]): Optional imported aiohttp module to reuse.

        Returns:
            Any: Active aiohttp ClientSession instance.
        """
        return await self._ensure_session(aiohttp_module)

    def _sync_download_fallback(self, url: str, target_path: Pathish) -> Optional[bool]:
        """
        Calls the synchronous downloader when async support is unavailable.

        Returns:
            `True` if the download succeeded, `False` otherwise.
        """
        logger.warning("Async libraries not available, falling back to sync download")
        return self.download(url, target_path)

    def download(self, url: str, target_path: Pathish) -> bool:
        """
        Download a file from the given URL into the specified target path, creating parent directories if needed.

        Parameters:
            url (str): The source URL of the file to download.
            target_path (Pathish): Filesystem path where the downloaded file will be saved.

        Returns:
            bool: `True` if the file was downloaded and saved successfully, `False` otherwise.
        """
        try:
            # Ensure target directory exists using pathlib
            target = Path(target_path)
            target.parent.mkdir(parents=True, exist_ok=True)

            # Use the existing robust download utility
            success = utils.download_file_with_retry(url, str(target))

            if success:
                logger.info(f"Successfully downloaded {target.name}")
            else:
                logger.error(f"Failed to download {url}")

            return success
        except (OSError, RequestException, ValueError) as e:
            logger.exception("Error downloading %s: %s", url, e)
            return False

    async def async_download(
        self,
        url: str,
        target_path: Pathish,
        progress_callback: Optional[AsyncProgressCallback] = None,
    ) -> bool:
        """
        Download a file to the specified target path with optional progress reporting.

        Parameters:
            url (str): Source URL of the file.
            target_path (Pathish): Local path where the file will be saved.
            progress_callback (Optional[AsyncProgressCallback]): Optional callback invoked with
                (downloaded_bytes, total_bytes, filename) to report progress.

        Returns:
            `True` if the download succeeded, `False` otherwise.
        """
        return await super().async_download(
            url, target_path, progress_callback=progress_callback
        )

    async def _async_verify_file(self, file_path: Path) -> bool:
        """
        Verify that a file's contents are intact; for ZIP files, perform an archive integrity check before the general integrity verification.

        Returns:
            True if the file is intact and passes integrity checks, False otherwise.
        """
        try:
            loop = asyncio.get_running_loop()
            if file_path.suffix.lower() == ".zip":
                if not await loop.run_in_executor(None, is_zip_intact, str(file_path)):
                    return False

            # Require a trusted hash before considering the file verified.
            # Files without a stored hash (e.g., manually copied or stale files)
            # must be re-downloaded to ensure correctness.
            stored_hash = await loop.run_in_executor(
                None, load_file_hash, str(file_path)
            )
            if not stored_hash:
                logger.debug("No stored hash for %s; treating as unverified", file_path)
                return False

            # Verify file integrity using existing sync utility
            return await loop.run_in_executor(
                None, utils.verify_file_integrity, str(file_path)
            )

        except (OSError, zipfile.BadZipFile) as e:
            logger.debug("File verification failed for %s: %s", file_path, e)
            return False

    async def _async_save_hash(self, file_path: Path) -> None:
        """
        Compute and persist the SHA-256 hash for a file.

        If hashing succeeds, the hash is saved alongside the file (to the file's associated hash storage).
        Parameters:
            file_path (Path): Path to the file whose SHA-256 hash will be computed and saved.
        """
        loop = asyncio.get_running_loop()

        def _compute_and_save() -> None:
            """
            Compute and persist the SHA-256 hash for the file referenced by the enclosing `file_path` variable.

            If the hash is successfully computed, it is saved to the file's associated hash storage; otherwise no action is taken.
            """
            hash_value = utils.calculate_sha256(str(file_path))
            if hash_value:
                utils.save_file_hash(str(file_path), hash_value)

        await loop.run_in_executor(None, _compute_and_save)

    async def _async_verify_existing_file(self, file_path: Path) -> bool:
        """
        Verify the integrity of the existing file at the given path.

        Returns:
            `True` if the file is valid, `False` otherwise.
        """
        return await self._async_verify_file(file_path)

    async def _async_save_file_hash(self, file_path: Path) -> None:
        """
        Compute and persist the SHA-256 hash of the specified file.

        Parameters:
            file_path (Path): Path to the file whose SHA-256 hash will be calculated and saved.
        """
        await self._async_save_hash(file_path)

    async def async_download_with_retry(
        self,
        url: str,
        target_path: Pathish,
        max_retries: Optional[int] = None,
        retry_delay: Optional[float] = None,
        backoff_factor: float = 2.0,
        progress_callback: Optional[AsyncProgressCallback] = None,
    ) -> bool:
        """
        Download a file with retry logic and exponential backoff.

        Parameters:
            url (str): URL to download from.
            target_path (Pathish): Local path to save the file.
            max_retries (Optional[int]): Maximum retry attempts; `None` defers to configured/default value.
            retry_delay (Optional[float]): Initial delay between retries in seconds; `None` defers to configured/default value.
            backoff_factor (float): Multiplier applied to the delay after each retry (default: 2.0).
            progress_callback (Optional[AsyncProgressCallback]): Optional callback for progress updates.

        Returns:
            bool: `True` if the download succeeded, `False` otherwise.
        """
        return await super().async_download_with_retry(
            url,
            target_path,
            max_retries=max_retries,
            retry_delay=retry_delay,
            backoff_factor=backoff_factor,
            progress_callback=progress_callback,
        )

    def verify(self, file_path: Pathish, expected_hash: Optional[str] = None) -> bool:
        """
        Verify the integrity of a downloaded file.

        If `expected_hash` is provided, verifies the file's hash against it; otherwise performs a general integrity check.

        Parameters:
            file_path (Pathish): Path to the file to verify.
            expected_hash (Optional[str]): Expected hash to validate against; if omitted, a broader integrity check is used.

        Returns:
            bool: `True` if the file passes verification, `False` otherwise.
        """
        if expected_hash:
            return self.file_operations.verify_file_hash(str(file_path), expected_hash)
        return utils.verify_file_integrity(str(file_path))

    def cleanup_old_versions(
        self,
        keep_limit: int,
        cached_releases: Optional[List["Release"]] = None,
        keep_last_beta: bool = False,
    ) -> None:
        """
        Remove older downloaded versions so that at most `keep_limit` version directories remain.

        Parameters:
            keep_limit (int): Maximum number of version entries to retain; older versions beyond this limit should be removed.
            cached_releases (Optional[List[Release]]): Optional list of releases to consult instead of performing fresh lookups.
            keep_last_beta (bool): If true and supported by the downloader, preserve the most recent beta release in addition to the retained releases.
        """
        # This will be implemented by specific downloaders
        pass

    def get_version_manager(self) -> VersionManager:
        """
        Get the VersionManager associated with this downloader.

        Returns:
            VersionManager: The VersionManager instance associated with this downloader.
        """
        return self.version_manager

    def get_cache_manager(self) -> CacheManager:
        """
        Retrieve the cache manager used by this downloader.

        Returns:
            CacheManager: The cache manager instance.
        """
        return self.cache_manager

    def get_target_path_for_release(self, release_tag: str, file_name: str) -> str:
        """
        Get the target path for a release file.

        Args:
            release_tag: The release tag/version
            file_name: The filename of the asset

        Returns:
            str: Full path where the file should be saved
        """
        safe_release = self._sanitize_required(release_tag, "release tag")
        safe_name = self._sanitize_required(file_name, "file name")

        # Create version-specific directory
        version_dir = os.path.join(self.download_dir, safe_release)
        os.makedirs(version_dir, exist_ok=True)

        return os.path.join(version_dir, safe_name)

    def should_download_release(self, _release_tag: str, asset_name: str) -> bool:
        """
        Decide whether an asset should be downloaded based on configured selection and exclusion patterns.

        The asset is eligible only if it matches at least one configured selected pattern (when any are defined)
        and does not match any configured exclude pattern.

        Parameters:
            asset_name (str): Name of the asset (filename) to evaluate.

        Returns:
            True if the asset should be downloaded, False otherwise.
        """
        # Get selection patterns from config
        selected_patterns = self._get_selected_patterns()
        exclude_patterns = self._get_exclude_patterns()

        # Check if asset matches selected patterns
        if selected_patterns and not self._matches_selected_patterns(
            asset_name, selected_patterns
        ):
            logger.debug(f"Skipping {asset_name} - doesn't match selected patterns")
            return False

        # Check if asset matches exclude patterns
        if exclude_patterns and self._matches_exclude_patterns(
            asset_name, exclude_patterns
        ):
            logger.debug(f"Skipping {asset_name} - matches exclude patterns")
            return False

        return True

    def _get_selected_patterns(self) -> List[str]:
        """
        Retrieve asset selection patterns from configuration, falling back to legacy keys if necessary.

        Checks "SELECTED_PATTERNS" and, if not present, attempts "SELECTED_FIRMWARE_ASSETS", "SELECTED_PRERELEASE_ASSETS", and "SELECTED_APK_ASSETS". Normalizes a single string into a one-element list.

        Returns:
            List[str]: Selection patterns from configuration, or an empty list if none are configured.
        """
        patterns = self.config.get("SELECTED_PATTERNS")

        # Backward compatibility with existing config keys
        if not patterns:
            patterns = self.config.get("SELECTED_FIRMWARE_ASSETS")
        if not patterns:
            patterns = self.config.get("SELECTED_PRERELEASE_ASSETS")
        if not patterns:
            patterns = self.config.get("SELECTED_APK_ASSETS")

        patterns = patterns or []
        return patterns if isinstance(patterns, list) else [patterns]

    def _get_exclude_patterns(self) -> List[str]:
        """
        Retrieve exclude filename patterns from the configuration.

        Returns:
            patterns (List[str]): A list of exclude pattern strings. If the config value is a single string it is wrapped into a one-element list; missing value yields an empty list.
        """
        patterns = self.config.get("EXCLUDE_PATTERNS", [])
        return patterns if isinstance(patterns, list) else [patterns]

    def _matches_selected_patterns(self, filename: str, patterns: List[str]) -> bool:
        """
        Check if a filename matches any of the selected patterns.

        Args:
            filename: The filename to check
            patterns: List of patterns to match against

        Returns:
            bool: True if filename matches any pattern, False otherwise
        """
        return matches_selected_patterns(filename, patterns)

    def _matches_exclude_patterns(self, filename: str, patterns: List[str]) -> bool:
        """
        Check whether the filename matches any exclude pattern, using case-insensitive shell-style wildcard matching.

        Parameters:
            filename: The filename to test.
            patterns: Iterable of shell-style patterns (e.g., '*.zip'); matching is case-insensitive.

        Returns:
            True if the filename matches any exclude pattern, False otherwise.
        """
        if not patterns:
            return False  # No exclude patterns means don't exclude anything

        filename_lower = filename.lower()
        return any(
            fnmatch.fnmatch(filename_lower, pattern.lower()) for pattern in patterns
        )

    def _sanitize_required(self, component: str, label: str) -> str:
        """
        Ensure a path component is safe for use and return the sanitized value.

        Parameters:
            component (str): The path component to sanitize.
            label (str): Human-readable label used in the error message if sanitization fails.

        Returns:
            sanitized (str): The sanitized path component.

        Raises:
            ValueError: If the component cannot be safely sanitized (to prevent path traversal).
        """
        safe = _sanitize_path_component(component)
        if safe is None:
            raise ValueError(
                f"Unsafe {label} provided; aborting to avoid path traversal"
            )
        return safe

    def create_download_result(
        self,
        success: bool,
        release_tag: str,
        file_path: str,
        error_message: Optional[str] = None,
        *,
        extracted_files: Optional[List[Pathish]] = None,
        download_url: Optional[str] = None,
        file_size: Optional[int] = None,
        file_type: Optional[str] = None,
        is_retryable: bool = False,
        error_type: Optional[str] = None,
        error_details: Optional[Dict[str, Any]] = None,
        http_status_code: Optional[int] = None,
        was_skipped: bool = False,
    ) -> DownloadResult:
        """
        Create a DownloadResult that encapsulates the outcome and metadata of a release asset download attempt.

        Parameters:
            success (bool): Whether the download succeeded.
            release_tag (str): Release identifier associated with the asset.
            file_path (str): File system path to the asset; converted to a Path on the result.
            error_message (Optional[str]): Human-readable error message, if any.
            extracted_files (Optional[List[Pathish]]): Paths of files extracted from an archive, if applicable.
            download_url (Optional[str]): URL used to fetch the asset.
            file_size (Optional[int]): Size of the asset in bytes, when known.
            file_type (Optional[str]): Asset type hint (for example, "android", "firmware", or "repository").
            is_retryable (bool): Whether a failed download is safe to retry.
            error_type (Optional[str]): Machine-readable classification of the error.
            error_details (Optional[Dict[str, Any]]): Additional structured information about the error.
            http_status_code (Optional[int]): HTTP status code returned by the request, if applicable.
            was_skipped (bool): Whether the asset was intentionally skipped (not attempted).

        Returns:
            DownloadResult: Object containing the result fields and normalized Path for the file.
        """
        return DownloadResult(
            success=success,
            release_tag=release_tag,
            file_path=Path(file_path),
            error_message=error_message,
            extracted_files=extracted_files,
            download_url=download_url,
            file_size=file_size,
            file_type=file_type,
            is_retryable=is_retryable,
            error_type=error_type,
            error_details=error_details,
            http_status_code=http_status_code,
            was_skipped=was_skipped,
        )

    def cleanup_file(self, file_path: str) -> bool:
        """
        Delete the file at the given path if present.

        Parameters:
            file_path (str): Path to the file to remove.

        Returns:
            bool: `True` if the file was removed, `False` otherwise.
        """
        return self.file_operations.cleanup_file(file_path)

    def _write_release_notes(
        self,
        *,
        release_dir: str,
        release_tag: str,
        body: Optional[str],
        base_dir: str,
        notes_prefix: Optional[str] = None,
    ) -> Optional[str]:
        """
        Write sanitized release notes to a markdown file within the given release directory if not already present.

        Validates and sanitizes the provided release_tag; skips writing if the tag is unsafe. Ensures the target notes path is located inside base_dir (prevents path escape), creates release_dir as needed, strips unwanted characters from body, and writes the file atomically via the downloader's cache_manager. If the notes file already exists, returns its path without modifying it.

        Parameters:
                release_dir (str): Directory where the release notes file should be placed.
                release_tag (str): Tag used to derive a safe filename component; will be sanitized.
                body (Optional[str]): Release notes content; nothing is written if empty or whitespace after sanitization.
                base_dir (str): Base download directory used to verify the notes path does not escape the allowed location.

        Returns:
                notes_path (Optional[str]): Path to the release notes file if written or already present, `None` otherwise.
        """
        if not body:
            return None

        safe_tag = _sanitize_path_component(release_tag)
        if safe_tag is None:
            logger.warning("Skipping release notes for unsafe tag: %s", release_tag)
            return None

        safe_prefix = None
        if notes_prefix:
            safe_prefix = _sanitize_path_component(notes_prefix)
            if safe_prefix is None:
                logger.warning(
                    "Skipping unsafe notes_prefix for release notes: %s", notes_prefix
                )
                return None
        prefix_part = f"{safe_prefix}-" if safe_prefix else ""
        notes_path = os.path.join(
            release_dir, f"release_notes-{prefix_part}{safe_tag}.md"
        )

        real_base = os.path.realpath(base_dir)
        try:
            real_release_dir = os.path.realpath(release_dir)
            release_dir_common = os.path.commonpath([real_base, real_release_dir])
        except ValueError:
            release_dir_common = None

        if release_dir_common != real_base:
            logger.warning(
                "Skipping write of release notes for %s: release directory path escapes download base",
                release_tag,
            )
            return None

        if os.path.lexists(notes_path):
            if os.path.islink(notes_path):
                logger.warning(
                    "Refusing to use existing symlink for release notes: %s",
                    notes_path,
                )
                return None
            return notes_path

        os.makedirs(release_dir, exist_ok=True)

        try:
            real_notes = os.path.realpath(notes_path)
            notes_common = os.path.commonpath([real_base, real_notes])
        except ValueError:
            notes_common = None

        if notes_common != real_base:
            logger.warning(
                "Skipping write of release notes for %s: path escapes download base",
                release_tag,
            )
            return None

        notes_content = strip_unwanted_chars(body)
        if not notes_content.strip():
            return None

        if self.cache_manager.atomic_write_text(notes_path, notes_content):
            logger.debug("Saved release notes to %s", notes_path)
            return notes_path

        logger.warning("Could not atomically write release notes to %s", notes_path)
        return None

    def _is_zip_intact(self, file_path: str) -> bool:
        """
        Perform a quick integrity check of a ZIP archive.

        Parameters:
            file_path (str): Path to the ZIP file to inspect.

        Returns:
            bool: `True` if the archive contains no corrupt members, `False` otherwise.
        """
        return is_zip_intact(file_path)

    def is_asset_complete(self, release_tag: str, asset: Asset) -> bool:
        """
        Determine whether the local file for a release asset exists and is valid.

        Performs these checks when applicable: file existence, file size matches the asset's declared size, file hash verification against stored records, and ZIP integrity for .zip files.

        Returns:
            True if the asset file exists and passes size, hash, and ZIP integrity checks, False otherwise.
        """
        target_path = self.get_target_path_for_release(release_tag, asset.name)
        if not os.path.exists(target_path):
            return False

        # Size check
        if asset.size and self.file_operations.get_file_size(target_path) != asset.size:
            return False

        # Hash/verify (uses cached hash records)
        if not self.verify(target_path):
            return False

        # Zip integrity check
        if target_path.lower().endswith(".zip") and not self._is_zip_intact(
            target_path
        ):
            return False

        return True

    def is_release_revoked(self, release: "Release") -> bool:
        """
        Determine whether the given release is recorded as revoked in release history.

        This method is only available in downloaders that have a release_history_manager
        (e.g., FirmwareReleaseDownloader, MeshtasticAndroidAppDownloader).

        Parameters:
            release (Release): The release to check.

        Returns:
            bool: `True` if the release is revoked, `False` otherwise.

        Raises:
            AttributeError: If the downloader does not have a release_history_manager.
        """
        manager = getattr(self, "release_history_manager", None)
        if manager is None:
            raise AttributeError(
                _MISSING_HISTORY_MANAGER_MSG.format(cls=self.__class__.__name__)
            )
        is_release_revoked = getattr(manager, "is_release_revoked", None)
        if not callable(is_release_revoked):
            raise AttributeError(
                _MISSING_HISTORY_MANAGER_MSG.format(cls=self.__class__.__name__)
            )
        return bool(is_release_revoked(release))
