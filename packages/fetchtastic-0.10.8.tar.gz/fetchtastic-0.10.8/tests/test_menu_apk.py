import json

import pytest

from fetchtastic import menu_apk

pytestmark = [pytest.mark.user_interface]


@pytest.fixture
def mock_apk_assets():
    """
    Provide a list of dictionaries representing release assets for tests.

    Each dictionary contains a "name" key with a filename. The returned list includes three APK filenames and one non-APK file to exercise asset filtering in tests.

    Returns:
        assets (list[dict]): List of asset dictionaries, e.g.:
            [
                {"name": "meshtastic-app-release-2.7.4.apk"},
                {"name": "meshtastic-app-debug-2.7.4.apk"},
                {"name": "nRF_Connect_Device_Manager-release-2.7.4.apk"},
                {"name": "some-other-file.txt"},
            ]
    """
    return [
        {"name": "meshtastic-app-release-2.7.4.apk"},
        {"name": "meshtastic-app-debug-2.7.4.apk"},
        {"name": "nRF_Connect_Device_Manager-release-2.7.4.apk"},
        {"name": "some-other-file.txt"},
    ]


@pytest.fixture
def mock_apk_assets_mixed_case():
    """
    Provide mock release assets including APK filenames with mixed-case extensions for testing.

    Returns:
        list[dict]: A list of asset dictionaries with a 'name' key. Includes APK filenames with lowercase, uppercase, and mixed-case extensions, plus a non-APK file.
    """
    return [
        {"name": "meshtastic-app-release-2.7.4.apk"},
        {"name": "meshtastic-app-debug-2.7.4.APK"},  # Uppercase extension
        {"name": "meshtastic-app-beta-2.7.4.Apk"},  # Mixed case extension
        {"name": "some-other-file.txt"},
    ]


@pytest.mark.unit
@pytest.mark.core_downloads
def test_fetch_apk_assets(mocker, mock_apk_assets):
    """Test fetching APK assets from GitHub."""
    mock_response = mocker.MagicMock()
    mock_response.json.return_value = [{"assets": mock_apk_assets}]
    mock_make_request = mocker.patch("fetchtastic.menu_apk.make_github_api_request")
    mock_make_request.return_value = mock_response

    assets = menu_apk.fetch_apk_assets()
    asset_names = [asset["name"] for asset in assets]

    assert len(assets) == 3
    assert "meshtastic-app-release-2.7.4.apk" in asset_names
    assert "meshtastic-app-debug-2.7.4.apk" in asset_names
    assert "nRF_Connect_Device_Manager-release-2.7.4.apk" in asset_names
    # Check sorting
    assert assets[0]["name"] == "meshtastic-app-debug-2.7.4.apk"


@pytest.mark.unit
@pytest.mark.core_downloads
def test_fetch_apk_assets_case_insensitive(mocker, mock_apk_assets_mixed_case):
    """Test fetching APK assets with case-insensitive extension matching."""
    mock_response = mocker.MagicMock()
    mock_response.json.return_value = [{"assets": mock_apk_assets_mixed_case}]
    mock_make_request = mocker.patch("fetchtastic.menu_apk.make_github_api_request")
    mock_make_request.return_value = mock_response

    assets = menu_apk.fetch_apk_assets()
    asset_names = [asset["name"] for asset in assets]

    assert len(assets) == 3
    assert "meshtastic-app-release-2.7.4.apk" in asset_names
    assert "meshtastic-app-debug-2.7.4.APK" in asset_names
    assert "meshtastic-app-beta-2.7.4.Apk" in asset_names
    assert "some-other-file.txt" not in asset_names


@pytest.mark.unit
@pytest.mark.core_downloads
def test_fetch_apk_assets_prefers_stable_release_with_apk_assets(mocker):
    """When both prerelease and stable have APK assets, stable should be preferred."""
    mock_response = mocker.MagicMock()
    mock_response.json.return_value = [
        {
            "tag_name": "v2.8.0-open.1",
            "prerelease": True,
            "assets": [{"name": "meshtastic-prerelease.apk", "size": 1}],
        },
        {
            "tag_name": "v2.7.20",
            "prerelease": False,
            "assets": [{"name": "meshtastic-stable.apk", "size": 2}],
        },
    ]
    mock_make_request = mocker.patch("fetchtastic.menu_apk.make_github_api_request")
    mock_make_request.return_value = mock_response

    assets = menu_apk.fetch_apk_assets()

    assert assets == [{"name": "meshtastic-stable.apk", "size": 2}]


@pytest.mark.unit
@pytest.mark.core_downloads
def test_fetch_apk_assets_scans_past_non_apk_first_release(mocker):
    """Release selection should skip entries without APK assets."""
    mock_response = mocker.MagicMock()
    mock_response.json.return_value = [
        {
            "tag_name": "v2.7.21",
            "prerelease": False,
            "assets": [{"name": "notes.txt", "size": 10}],
        },
        {
            "tag_name": "v2.7.20",
            "prerelease": False,
            "assets": [{"name": "meshtastic.apk", "size": 20}],
        },
    ]
    mock_make_request = mocker.patch("fetchtastic.menu_apk.make_github_api_request")
    mock_make_request.return_value = mock_response

    assets = menu_apk.fetch_apk_assets()

    assert assets == [{"name": "meshtastic.apk", "size": 20}]


@pytest.mark.unit
@pytest.mark.core_downloads
def test_normalize_apk_assets_ignores_non_string_names():
    """Normalization should drop entries with non-string names."""
    normalized = menu_apk._normalize_apk_assets(
        [
            {"name": 123, "size": 10},
            {"name": "valid.apk", "size": "bad-size"},
        ]
    )

    assert normalized == [{"name": "valid.apk", "size": 0}]


@pytest.mark.parametrize(
    "filename, expected",
    [
        ("meshtastic-app-release-2.3.2.apk", "meshtastic-app-release.apk"),
        ("app-debug-1.0.0.apk", "app-debug.apk"),
    ],
)
def test_extract_base_name(filename, expected):
    """Test the base name extraction logic."""
    assert menu_apk.extract_base_name(filename) == expected


def test_select_assets(mocker):
    """Test the user asset selection logic."""
    mock_pick = mocker.patch("fetchtastic.menu_apk.pick")
    assets = ["meshtastic-app-release-2.3.2.apk", "meshtastic-app-debug-2.3.2.apk"]

    # 1. User selects one asset
    mock_pick.return_value = [("meshtastic-app-release-2.3.2.apk", 0)]
    selected = menu_apk.select_assets(assets)
    assert selected == {"selected_assets": ["meshtastic-app-release.apk"]}

    # 2. User selects nothing
    mock_pick.return_value = []
    selected = menu_apk.select_assets(assets)
    assert selected is None


@pytest.mark.unit
@pytest.mark.core_downloads
def test_run_menu(mocker):
    """Test the main menu orchestration."""
    mock_fetch = mocker.patch(
        "fetchtastic.menu_apk.fetch_apk_assets",
        return_value=[{"name": "asset1.apk", "size": 123}],
    )
    mock_select = mocker.patch(
        "fetchtastic.menu_apk.select_assets",
        return_value={"selected_assets": ["base-pattern"]},
    )

    # 1. Successful flow
    result = menu_apk.run_menu()
    assert result == {"selected_assets": ["base-pattern"]}
    mock_fetch.assert_called_once()
    mock_select.assert_called_once_with([{"name": "asset1.apk", "size": 123}])

    # 2. User selects nothing
    mock_select.return_value = None
    result = menu_apk.run_menu()
    assert result is None


@pytest.mark.unit
@pytest.mark.core_downloads
def test_run_menu_empty_assets_returns_none(mocker):
    """run_menu should return None without calling select_assets when no assets exist."""
    mock_fetch = mocker.patch("fetchtastic.menu_apk.fetch_apk_assets", return_value=[])
    mock_select = mocker.patch("fetchtastic.menu_apk.select_assets")

    result = menu_apk.run_menu()

    assert result is None
    mock_fetch.assert_called_once()
    mock_select.assert_not_called()


def test_fetch_apk_assets_error_handling(mocker):
    """Test error handling in fetch_apk_assets."""
    # Test JSON decode error
    mock_response = mocker.MagicMock()
    mock_response.json.side_effect = json.JSONDecodeError("Invalid JSON", "", 0)
    mock_make_request = mocker.patch("fetchtastic.menu_apk.make_github_api_request")
    mock_make_request.return_value = mock_response

    assets = menu_apk.fetch_apk_assets()
    assert assets == []

    # Test non-list response
    mock_response.json.return_value = {"not": "a list"}
    mock_make_request.return_value = mock_response

    assets = menu_apk.fetch_apk_assets()
    assert assets == []

    # Test empty releases list
    mock_response.json.return_value = []
    mock_make_request.return_value = mock_response

    assets = menu_apk.fetch_apk_assets()
    assert assets == []


def test_run_menu_exception_handling(mocker):
    """Test exception handling in run_menu."""
    # Test exception during fetch
    mocker.patch(
        "fetchtastic.menu_apk.fetch_apk_assets", side_effect=Exception("Network error")
    )

    result = menu_apk.run_menu()
    assert result is None


def test_fetch_apk_assets_debug_logging(mocker, mock_apk_assets):
    """Test debug logging in fetch_apk_assets."""
    mock_api_request = mocker.patch("fetchtastic.menu_apk.make_github_api_request")
    mock_response = mocker.MagicMock()
    mock_response.json.return_value = [{"assets": mock_apk_assets}]
    mock_api_request.return_value = mock_response
    mock_logger = mocker.patch("fetchtastic.menu_apk.logger")

    assets = menu_apk.fetch_apk_assets()
    asset_names = [asset["name"] for asset in assets]

    # Should log debug message about fetched releases
    mock_logger.debug.assert_called_with("Fetched 1 Android releases from GitHub API")
    assert len(assets) == 3
    assert "meshtastic-app-release-2.7.4.apk" in asset_names


def test_fetch_apk_assets_debug_logging_no_list_response(mocker):
    """Test debug logging in fetch_apk_assets when response is not a list."""
    mock_api_request = mocker.patch("fetchtastic.menu_apk.make_github_api_request")
    mock_response = mocker.MagicMock()
    mock_response.json.return_value = {"not": "a list"}
    mock_api_request.return_value = mock_response
    mock_logger = mocker.patch("fetchtastic.menu_apk.logger")

    assets = menu_apk.fetch_apk_assets()

    # Should not log debug message since response is not a list
    mock_logger.debug.assert_not_called()
    assert assets == []
