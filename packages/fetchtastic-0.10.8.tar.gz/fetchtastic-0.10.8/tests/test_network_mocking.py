"""Tests for global network blocking behavior in the test environment."""

import pytest
import requests

pytestmark = [pytest.mark.infrastructure, pytest.mark.unit]


def test_requests_request_blocked():
    """Top-level requests.request should be blocked unless a test mocks it."""
    with pytest.raises(RuntimeError, match="Network access is blocked during tests"):
        requests.request("GET", "https://example.com")


def test_requests_session_send_blocked():
    """Session.send should be blocked to prevent bypassing Session.request patches."""
    prepared = requests.Request("GET", "https://example.com").prepare()
    with pytest.raises(RuntimeError, match="Network access is blocked during tests"):
        requests.Session().send(prepared)


@pytest.mark.asyncio
async def test_aiohttp_request_blocked_async_with():
    """aiohttp.request async context-manager usage should be blocked."""
    aiohttp = pytest.importorskip("aiohttp")
    with pytest.raises(
        RuntimeError, match="Async network access is blocked during tests"
    ):
        async with aiohttp.request("GET", "https://example.com"):
            pass


@pytest.mark.asyncio
async def test_aiohttp_request_blocked_await():
    """aiohttp.request await usage should be blocked."""
    aiohttp = pytest.importorskip("aiohttp")
    with pytest.raises(
        RuntimeError, match="Async network access is blocked during tests"
    ):
        await aiohttp.request("GET", "https://example.com")
