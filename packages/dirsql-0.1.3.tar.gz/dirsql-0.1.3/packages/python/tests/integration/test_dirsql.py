"""Integration tests for the DirSQL Python SDK."""

import json
import os

import pytest

from dirsql import DirSQL, Table


def describe_DirSQL():
    def describe_init():
        @pytest.mark.asyncio
        async def it_creates_instance_with_tables(jsonl_dir):
            """DirSQL can be initialized with a root path and table definitions."""
            db = DirSQL(
                jsonl_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE comments (id TEXT, body TEXT, author TEXT)",
                        glob="comments/**/index.jsonl",
                        extract=lambda path, content: [
                            {
                                "id": os.path.basename(os.path.dirname(path)),
                                "body": row["body"],
                                "author": row["author"],
                            }
                            for line in content.splitlines()
                            for row in [json.loads(line)]
                        ],
                    ),
                ],
            )
            assert db is not None

        @pytest.mark.asyncio
        async def it_accepts_ignore_patterns(jsonl_dir):
            """DirSQL accepts an ignore list to skip matching paths."""
            db = DirSQL(
                jsonl_dir,
                ignore=["**/def/**"],
                tables=[
                    Table(
                        ddl="CREATE TABLE comments (id TEXT, body TEXT, author TEXT)",
                        glob="comments/**/index.jsonl",
                        extract=lambda path, content: [
                            {
                                "id": os.path.basename(os.path.dirname(path)),
                                "body": row["body"],
                                "author": row["author"],
                            }
                            for line in content.splitlines()
                            for row in [json.loads(line)]
                        ],
                    ),
                ],
            )
            await db.ready()
            # Only the "abc" directory should be indexed, not "def"
            results = await db.query("SELECT DISTINCT id FROM comments")
            ids = {r["id"] for r in results}
            assert ids == {"abc"}

    def describe_query():
        @pytest.mark.asyncio
        async def it_returns_all_rows(jsonl_dir):
            """query returns all indexed rows when no WHERE clause."""
            db = DirSQL(
                jsonl_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE comments (id TEXT, body TEXT, author TEXT)",
                        glob="comments/**/index.jsonl",
                        extract=lambda path, content: [
                            {
                                "id": os.path.basename(os.path.dirname(path)),
                                "body": row["body"],
                                "author": row["author"],
                            }
                            for line in content.splitlines()
                            for row in [json.loads(line)]
                        ],
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM comments")
            assert len(results) == 3

        @pytest.mark.asyncio
        async def it_returns_dicts_with_column_names(jsonl_dir):
            """Each result row is a dict keyed by column name."""
            db = DirSQL(
                jsonl_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE comments (id TEXT, body TEXT, author TEXT)",
                        glob="comments/**/index.jsonl",
                        extract=lambda path, content: [
                            {
                                "id": os.path.basename(os.path.dirname(path)),
                                "body": row["body"],
                                "author": row["author"],
                            }
                            for line in content.splitlines()
                            for row in [json.loads(line)]
                        ],
                    ),
                ],
            )
            await db.ready()
            results = await db.query(
                "SELECT author FROM comments WHERE body = 'first comment'"
            )
            assert len(results) == 1
            assert results[0]["author"] == "alice"

        @pytest.mark.asyncio
        async def it_filters_with_where_clause(jsonl_dir):
            """SQL WHERE clauses work correctly on indexed data."""
            db = DirSQL(
                jsonl_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE comments (id TEXT, body TEXT, author TEXT)",
                        glob="comments/**/index.jsonl",
                        extract=lambda path, content: [
                            {
                                "id": os.path.basename(os.path.dirname(path)),
                                "body": row["body"],
                                "author": row["author"],
                            }
                            for line in content.splitlines()
                            for row in [json.loads(line)]
                        ],
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM comments WHERE id = 'abc'")
            assert len(results) == 2
            assert all(r["id"] == "abc" for r in results)

        @pytest.mark.asyncio
        async def it_excludes_internal_tracking_columns(jsonl_dir):
            """Internal _dirsql_* columns are not exposed in query results."""
            db = DirSQL(
                jsonl_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE comments (id TEXT, body TEXT, author TEXT)",
                        glob="comments/**/index.jsonl",
                        extract=lambda path, content: [
                            {
                                "id": os.path.basename(os.path.dirname(path)),
                                "body": row["body"],
                                "author": row["author"],
                            }
                            for line in content.splitlines()
                            for row in [json.loads(line)]
                        ],
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM comments LIMIT 1")
            assert len(results) == 1
            row = results[0]
            assert "_dirsql_file_path" not in row
            assert "_dirsql_row_index" not in row

        @pytest.mark.asyncio
        async def it_handles_integer_values(tmp_dir):
            """Integer values in extracted data are preserved correctly."""
            os.makedirs(os.path.join(tmp_dir, "data"), exist_ok=True)
            with open(os.path.join(tmp_dir, "data", "counts.json"), "w") as f:
                json.dump({"name": "apples", "count": 42}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE items (name TEXT, count INTEGER)",
                        glob="data/*.json",
                        extract=lambda path, content: [json.loads(content)],
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM items")
            assert len(results) == 1
            assert results[0]["name"] == "apples"
            assert results[0]["count"] == 42

    def describe_multiple_tables():
        @pytest.mark.asyncio
        async def it_supports_multiple_table_definitions(tmp_dir):
            """Multiple tables can be defined with different globs and extractors."""
            os.makedirs(os.path.join(tmp_dir, "posts"), exist_ok=True)
            os.makedirs(os.path.join(tmp_dir, "authors"), exist_ok=True)

            with open(os.path.join(tmp_dir, "posts", "hello.json"), "w") as f:
                json.dump({"title": "Hello World", "author_id": "1"}, f)

            with open(os.path.join(tmp_dir, "authors", "alice.json"), "w") as f:
                json.dump({"id": "1", "name": "Alice"}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE posts (title TEXT, author_id TEXT)",
                        glob="posts/*.json",
                        extract=lambda path, content: [json.loads(content)],
                    ),
                    Table(
                        ddl="CREATE TABLE authors (id TEXT, name TEXT)",
                        glob="authors/*.json",
                        extract=lambda path, content: [json.loads(content)],
                    ),
                ],
            )
            await db.ready()
            posts = await db.query("SELECT * FROM posts")
            authors = await db.query("SELECT * FROM authors")
            assert len(posts) == 1
            assert len(authors) == 1
            assert posts[0]["title"] == "Hello World"
            assert authors[0]["name"] == "Alice"

        @pytest.mark.asyncio
        async def it_supports_joins_across_tables(tmp_dir):
            """SQL JOINs work across different tables."""
            os.makedirs(os.path.join(tmp_dir, "posts"), exist_ok=True)
            os.makedirs(os.path.join(tmp_dir, "authors"), exist_ok=True)

            with open(os.path.join(tmp_dir, "posts", "hello.json"), "w") as f:
                json.dump({"title": "Hello World", "author_id": "1"}, f)

            with open(os.path.join(tmp_dir, "authors", "alice.json"), "w") as f:
                json.dump({"id": "1", "name": "Alice"}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE posts (title TEXT, author_id TEXT)",
                        glob="posts/*.json",
                        extract=lambda path, content: [json.loads(content)],
                    ),
                    Table(
                        ddl="CREATE TABLE authors (id TEXT, name TEXT)",
                        glob="authors/*.json",
                        extract=lambda path, content: [json.loads(content)],
                    ),
                ],
            )
            await db.ready()
            results = await db.query(
                "SELECT posts.title, authors.name "
                "FROM posts JOIN authors ON posts.author_id = authors.id"
            )
            assert len(results) == 1
            assert results[0]["title"] == "Hello World"
            assert results[0]["name"] == "Alice"

    def describe_error_handling():
        @pytest.mark.asyncio
        async def it_raises_on_invalid_sql(jsonl_dir):
            """Invalid SQL raises an exception."""
            db = DirSQL(
                jsonl_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE comments (id TEXT, body TEXT, author TEXT)",
                        glob="comments/**/index.jsonl",
                        extract=lambda path, content: [
                            {
                                "id": os.path.basename(os.path.dirname(path)),
                                "body": row["body"],
                                "author": row["author"],
                            }
                            for line in content.splitlines()
                            for row in [json.loads(line)]
                        ],
                    ),
                ],
            )
            await db.ready()
            with pytest.raises(Exception):
                await db.query("NOT VALID SQL")

        @pytest.mark.asyncio
        async def it_raises_on_invalid_ddl(tmp_dir):
            """Invalid DDL raises an exception during init."""
            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="NOT A CREATE TABLE",
                        glob="*.json",
                        extract=lambda path, content: [],
                    ),
                ],
            )
            with pytest.raises(Exception):
                await db.ready()

        @pytest.mark.asyncio
        async def it_handles_empty_directory(tmp_dir):
            """An empty directory produces zero rows."""
            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE items (name TEXT)",
                        glob="**/*.json",
                        extract=lambda path, content: [json.loads(content)],
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM items")
            assert len(results) == 0

        @pytest.mark.asyncio
        async def it_handles_extract_returning_empty_list(tmp_dir):
            """Extract function returning [] produces no rows for that file."""
            with open(os.path.join(tmp_dir, "skip.json"), "w") as f:
                json.dump({"ignore": True}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE items (name TEXT)",
                        glob="**/*.json",
                        extract=lambda path, content: [],
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM items")
            assert len(results) == 0

    def describe_extract_receives_path_and_content():
        @pytest.mark.asyncio
        async def it_passes_relative_path_and_string_content(tmp_dir):
            """Extract receives the file path (relative to root) and content as string."""
            with open(os.path.join(tmp_dir, "test.json"), "w") as f:
                json.dump({"val": 1}, f)

            captured = {}

            def extract(path, content):
                captured["path"] = path
                captured["content"] = content
                return [{"val": 1}]

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE t (val INTEGER)",
                        glob="*.json",
                        extract=extract,
                    ),
                ],
            )
            await db.ready()
            await db.query("SELECT * FROM t")
            assert captured["path"] == "test.json"
            assert '"val"' in captured["content"]

    def describe_relaxed_schema():
        @pytest.mark.asyncio
        async def it_ignores_extra_keys_by_default(tmp_dir):
            """Extra keys returned by extract are silently dropped."""
            with open(os.path.join(tmp_dir, "item.json"), "w") as f:
                json.dump({"name": "apple", "color": "red", "weight": 150}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE items (name TEXT)",
                        glob="*.json",
                        extract=lambda path, content: [json.loads(content)],
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM items")
            assert len(results) == 1
            assert results[0]["name"] == "apple"
            assert "color" not in results[0]
            assert "weight" not in results[0]

        @pytest.mark.asyncio
        async def it_fills_missing_keys_with_null(tmp_dir):
            """Missing keys become NULL in the database."""
            with open(os.path.join(tmp_dir, "item.json"), "w") as f:
                json.dump({"name": "apple"}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE items (name TEXT, color TEXT, count INTEGER)",
                        glob="*.json",
                        extract=lambda path, content: [json.loads(content)],
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM items")
            assert len(results) == 1
            assert results[0]["name"] == "apple"
            assert results[0]["color"] is None
            assert results[0]["count"] is None

        @pytest.mark.asyncio
        async def it_raises_on_extra_keys_in_strict_mode(tmp_dir):
            """Strict mode raises when extract returns keys not in the DDL."""
            with open(os.path.join(tmp_dir, "item.json"), "w") as f:
                json.dump({"name": "apple", "color": "red"}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE items (name TEXT)",
                        glob="*.json",
                        extract=lambda path, content: [json.loads(content)],
                        strict=True,
                    ),
                ],
            )
            with pytest.raises(Exception):
                await db.ready()

        @pytest.mark.asyncio
        async def it_raises_on_missing_keys_in_strict_mode(tmp_dir):
            """Strict mode raises when extract is missing declared columns."""
            with open(os.path.join(tmp_dir, "item.json"), "w") as f:
                json.dump({"name": "apple"}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE items (name TEXT, color TEXT)",
                        glob="*.json",
                        extract=lambda path, content: [json.loads(content)],
                        strict=True,
                    ),
                ],
            )
            with pytest.raises(Exception):
                await db.ready()

        @pytest.mark.asyncio
        async def it_allows_exact_match_in_strict_mode(tmp_dir):
            """Strict mode works when keys exactly match DDL columns."""
            with open(os.path.join(tmp_dir, "item.json"), "w") as f:
                json.dump({"name": "apple", "color": "red"}, f)

            db = DirSQL(
                tmp_dir,
                tables=[
                    Table(
                        ddl="CREATE TABLE items (name TEXT, color TEXT)",
                        glob="*.json",
                        extract=lambda path, content: [json.loads(content)],
                        strict=True,
                    ),
                ],
            )
            await db.ready()
            results = await db.query("SELECT * FROM items")
            assert len(results) == 1
            assert results[0]["name"] == "apple"
            assert results[0]["color"] == "red"
