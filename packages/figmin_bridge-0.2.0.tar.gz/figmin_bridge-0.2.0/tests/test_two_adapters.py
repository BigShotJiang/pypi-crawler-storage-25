"""§10.3 — two adapters connect simultaneously; no command cross-talk.

This is the regression test justifying the whole refactor. Before the split,
multiple MCP processes had to coordinate via the primary/proxy protocol with
string-prefixed request IDs. Now every adapter is symmetric and the daemon
keys its routing by connection object, not by id prefix.
"""
from __future__ import annotations

import asyncio
import json

from figmin_bridge import protocol

from conftest import connect_and_hello


async def test_two_adapters_no_cross_talk(daemon):
    state, _srv = daemon
    ws_a, _ack_a = await connect_and_hello(state, adapter_id="adapter-A")
    ws_b, _ack_b = await connect_and_hello(state, adapter_id="adapter-B")
    try:
        # Both adapters fire command id=1 simultaneously. Without proper routing
        # keyed by connection, they'd collide or swap responses.
        await ws_a.send(json.dumps({
            "type": protocol.MSG_COMMAND,
            "id": 1,
            "command": "execute_script",
            "params": {"code": "console.log('from A')"},
        }))
        await ws_b.send(json.dumps({
            "type": protocol.MSG_COMMAND,
            "id": 1,
            "command": "execute_script",
            "params": {"code": "console.log('from B')"},
        }))

        resp_a = json.loads(await asyncio.wait_for(ws_a.recv(), timeout=5.0))
        resp_b = json.loads(await asyncio.wait_for(ws_b.recv(), timeout=5.0))

        # Figmin XR isn't connected in the test environment, so commands fail
        # with a clear error. The critical regression-test property is that
        # each adapter receives exactly one response, matched to its own id,
        # and neither hangs or crosses.
        assert resp_a["type"] == protocol.MSG_RESPONSE and resp_a["id"] == 1
        assert resp_b["type"] == protocol.MSG_RESPONSE and resp_b["id"] == 1
        assert resp_a["ok"] is False
        assert resp_b["ok"] is False
        assert "Figmin XR is not connected" in resp_a["error"]
        assert "Figmin XR is not connected" in resp_b["error"]

        # Daemon status should list both adapters.
        await ws_a.send(json.dumps({
            "type": protocol.MSG_BRIDGE_CONTROL,
            "id": 2,
            "action": protocol.BC_STATUS,
        }))
        status = json.loads(await ws_a.recv())
        adapter_ids = {a["adapter_id"] for a in status["result"]["adapters"]}
        assert adapter_ids == {"adapter-A", "adapter-B"}
    finally:
        await ws_a.close()
        await ws_b.close()


async def test_adapter_b_unaffected_when_a_disconnects(daemon):
    state, _srv = daemon
    ws_a, _ = await connect_and_hello(state, adapter_id="adapter-A")
    ws_b, _ = await connect_and_hello(state, adapter_id="adapter-B")
    try:
        await ws_a.close()
        # Small grace period so daemon observes close and runs cleanup
        await asyncio.sleep(0.1)

        # adapter-B must still be fully functional
        await ws_b.send(json.dumps({
            "type": protocol.MSG_BRIDGE_CONTROL,
            "id": 1,
            "action": protocol.BC_STATUS,
        }))
        resp = json.loads(await asyncio.wait_for(ws_b.recv(), timeout=5.0))
        adapters = resp["result"]["adapters"]
        assert [a["adapter_id"] for a in adapters] == ["adapter-B"], \
            f"A should have been cleaned up; adapters={adapters}"
    finally:
        await ws_b.close()
