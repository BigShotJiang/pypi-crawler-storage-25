"""§10.5 — 100 connect/disconnect cycles leave no leaked state.

Guards against the "add to dict / forget to remove" bug class. The only
bookkeeping to verify for now is `state.adapters` (the connection registry)
and `state.figmin_pending` (the figmin-id routing table). More tables may
be added in step 5; extend the asserts then.
"""
from __future__ import annotations

from figmin_bridge import protocol

from conftest import connect_and_hello

import asyncio


async def test_no_state_leak_after_many_cycles(daemon):
    state, _srv = daemon
    for _ in range(100):
        ws, _ = await connect_and_hello(state, adapter_id="cycle-test")
        await ws.close()

    # Give the daemon a moment to run finally-blocks on the closed connections
    await asyncio.sleep(0.2)

    assert state.adapters == {}, f"leaked {len(state.adapters)} adapter entries"
    assert state.figmin_pending == {}, f"leaked {len(state.figmin_pending)} figmin_pending entries"
