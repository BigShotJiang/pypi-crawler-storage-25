"""End-to-end routing: adapter -> daemon -> Figmin XR -> daemon -> adapter.

Stands up a full daemon in-process and a mock Figmin XR client. Verifies
that commands flow through correctly, responses route back to the right
adapter, and figmin_pending cleans up.

This is the regression test for step 5 (FigminBridge lift).
"""
from __future__ import annotations

import asyncio
import json

import pytest
import websockets

from figmin_bridge import adapter_server, figmin_server, protocol, ssl_cert, config
from figmin_bridge.state import DaemonState


async def _full_daemon():
    """Start a full daemon (adapter port + figmin ws port) on random ports."""
    state = DaemonState()
    state.adapter_ws_port = 0
    state.figmin_ws_port = 0
    state.figmin_wss_port = 0

    bridge = figmin_server.FigminBridge(
        state=state,
        broadcast_figmin_status=adapter_server.broadcast_figmin_status,
        broadcast_readiness=adapter_server.broadcast_readiness,
    )
    state.figmin_bridge = bridge

    adapter_srv = await adapter_server.start_adapter_server(
        state, protocol.DEFAULT_WS_MAX_SIZE
    )
    ws_srv, _wss = await figmin_server.start_figmin_servers(
        state, bridge, ws_host="127.0.0.1",
        max_size=protocol.DEFAULT_WS_MAX_SIZE,
        ssl_ctx=None,
    )
    return state, (adapter_srv, ws_srv)


async def _stop_daemon(srvs):
    for s in srvs:
        s.close()
        await s.wait_closed()


async def test_command_round_trip_through_figmin():
    state, srvs = await _full_daemon()
    try:
        # 1. Connect mock Figmin XR
        figmin_ws = await websockets.connect(
            f"ws://127.0.0.1:{state.figmin_ws_port}",
            max_size=protocol.DEFAULT_WS_MAX_SIZE,
        )
        # 2. Consume the tts_status hello-message the daemon pushes on connect
        #    (it happens in a background task — give it a brief moment)
        try:
            hello_raw = await asyncio.wait_for(figmin_ws.recv(), timeout=1.0)
            hello = json.loads(hello_raw)
            assert hello["type"] == "tts_status"
        except asyncio.TimeoutError:
            pytest.fail("expected tts_status from daemon on connect")

        # Wait until the daemon has registered Figmin as connected
        for _ in range(20):
            if state.figmin_connected:
                break
            await asyncio.sleep(0.05)
        assert state.figmin_connected

        # 3. Connect adapter and handshake
        adapter_ws = await websockets.connect(
            f"ws://127.0.0.1:{state.adapter_ws_port}",
            max_size=protocol.DEFAULT_WS_MAX_SIZE,
        )
        await adapter_ws.send(json.dumps({
            "type": protocol.MSG_HELLO,
            "adapter_id": "routing-test",
            "protocol_version": protocol.PROTOCOL_VERSION,
        }))
        ack = json.loads(await adapter_ws.recv())
        assert ack["type"] == protocol.MSG_HELLO_ACK
        assert ack["figmin_connected"] is True

        # 4. Adapter sends command with id=42
        await adapter_ws.send(json.dumps({
            "type": protocol.MSG_COMMAND,
            "id": 42,
            "command": "execute_script",
            "params": {"code": "console.log('hi')"},
        }))

        # 5. Mock Figmin receives the forwarded command
        figmin_cmd_raw = await asyncio.wait_for(figmin_ws.recv(), timeout=2.0)
        figmin_cmd = json.loads(figmin_cmd_raw)
        assert figmin_cmd["command"] == "execute_script"
        assert figmin_cmd["params"]["code"] == "console.log('hi')"
        figmin_id = figmin_cmd["id"]
        assert isinstance(figmin_id, int)
        # The daemon must generate its own id, NOT pass through the adapter's 42
        assert figmin_id != 42, "daemon must rewrite adapter id to its own figmin_id"

        # 6. Mock Figmin replies with matching id
        await figmin_ws.send(json.dumps({
            "id": figmin_id,
            "text": '{"ok":true,"logs":[{"msg":"hi","level":"log"}],"images":[],"pendingChat":0}',
            "logs": [{"msg": "hi", "level": "log"}],
            "images": [],
        }))

        # 7. Adapter receives the response keyed by its original id (42)
        resp_raw = await asyncio.wait_for(adapter_ws.recv(), timeout=2.0)
        resp = json.loads(resp_raw)
        assert resp["type"] == protocol.MSG_RESPONSE
        assert resp["id"] == 42
        assert resp["ok"] is True
        assert "text" in resp["result"]

        # 8. figmin_pending should be empty after response flows
        assert figmin_id not in state.figmin_pending, \
            f"figmin_pending not drained: {state.figmin_pending}"

        await adapter_ws.close()
        await figmin_ws.close()
    finally:
        await _stop_daemon(srvs)


async def test_figmin_disconnect_fails_pending_commands():
    state, srvs = await _full_daemon()
    try:
        figmin_ws = await websockets.connect(
            f"ws://127.0.0.1:{state.figmin_ws_port}",
            max_size=protocol.DEFAULT_WS_MAX_SIZE,
        )
        # Swallow the tts_status hello
        await asyncio.wait_for(figmin_ws.recv(), timeout=1.0)

        for _ in range(20):
            if state.figmin_connected:
                break
            await asyncio.sleep(0.05)
        assert state.figmin_connected

        adapter_ws = await websockets.connect(
            f"ws://127.0.0.1:{state.adapter_ws_port}",
            max_size=protocol.DEFAULT_WS_MAX_SIZE,
        )
        await adapter_ws.send(json.dumps({
            "type": protocol.MSG_HELLO,
            "adapter_id": "disconnect-test",
            "protocol_version": protocol.PROTOCOL_VERSION,
        }))
        await adapter_ws.recv()  # hello_ack

        # Adapter sends a command
        await adapter_ws.send(json.dumps({
            "type": protocol.MSG_COMMAND,
            "id": 7,
            "command": "execute_script",
            "params": {"code": "figmin.doThing()"},
        }))
        # Figmin receives it (and will NOT reply)
        await asyncio.wait_for(figmin_ws.recv(), timeout=2.0)

        # Now Figmin disconnects without responding
        await figmin_ws.close()

        # Adapter should eventually get an error response for command id=7.
        # It will also receive a figmin_status push — drain until we find the
        # response.
        resp = None
        for _ in range(5):
            msg = json.loads(await asyncio.wait_for(adapter_ws.recv(), timeout=3.0))
            if msg.get("type") == protocol.MSG_RESPONSE and msg.get("id") == 7:
                resp = msg
                break
        assert resp is not None, "never received response for command id=7"
        assert resp["ok"] is False
        assert "disconnected" in resp["error"].lower()

        # figmin_pending must be cleaned up
        assert state.figmin_pending == {}

        await adapter_ws.close()
    finally:
        await _stop_daemon(srvs)
