"""Shared fixtures for figmin-bridge tests.

All tests use OS-assigned random ports (state.adapter_ws_port = 0) to avoid
conflicts with the production figmin-mcp daemon that may be running on the
same machine during development.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator

import pytest_asyncio
import websockets

from figmin_bridge import adapter_server, protocol
from figmin_bridge.state import DaemonState


@pytest_asyncio.fixture
async def daemon() -> AsyncIterator[tuple[DaemonState, Any]]:
    """Start an in-process daemon bound to a random loopback port."""
    state = DaemonState()
    state.adapter_ws_port = 0
    srv = await adapter_server.start_adapter_server(
        state, max_size=protocol.DEFAULT_WS_MAX_SIZE
    )
    try:
        yield state, srv
    finally:
        srv.close()
        await srv.wait_closed()


def adapter_url(state: DaemonState) -> str:
    return f"ws://{protocol.ADAPTER_HOST}:{state.adapter_ws_port}"


async def connect_and_hello(state: DaemonState, adapter_id: str = "test-adapter",
                              protocol_version: int = protocol.PROTOCOL_VERSION):
    """Open a WebSocket, send hello, return (ws, hello_ack dict)."""
    ws = await websockets.connect(
        adapter_url(state), max_size=protocol.DEFAULT_WS_MAX_SIZE
    )
    await ws.send(json.dumps({
        "type": protocol.MSG_HELLO,
        "adapter_id": adapter_id,
        "protocol_version": protocol_version,
    }))
    raw = await asyncio.wait_for(ws.recv(), timeout=5.0)
    return ws, json.loads(raw)
