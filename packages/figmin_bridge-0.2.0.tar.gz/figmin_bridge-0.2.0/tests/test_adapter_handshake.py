"""§10.2 — adapter connects, gets hello_ack with expected fields."""
from __future__ import annotations

import json

from figmin_bridge import __version__, protocol

from conftest import connect_and_hello


async def test_hello_ack_contains_expected_fields(daemon):
    state, _srv = daemon
    ws, ack = await connect_and_hello(state, adapter_id="test-42")
    try:
        assert ack["type"] == protocol.MSG_HELLO_ACK
        assert ack["daemon_version"] == __version__
        assert isinstance(ack["daemon_pid"], int) and ack["daemon_pid"] > 0
        assert ack["figmin_connected"] is False
        assert "readiness" in ack and "stt" in ack["readiness"] and "tts" in ack["readiness"]
    finally:
        await ws.close()


async def test_protocol_version_mismatch_returns_error(daemon):
    state, _srv = daemon
    import websockets
    ws = await websockets.connect(
        f"ws://{protocol.ADAPTER_HOST}:{state.adapter_ws_port}",
        max_size=protocol.DEFAULT_WS_MAX_SIZE,
    )
    try:
        await ws.send(json.dumps({
            "type": protocol.MSG_HELLO,
            "adapter_id": "mismatch-test",
            "protocol_version": 999,
        }))
        raw = await ws.recv()
        msg = json.loads(raw)
        assert msg["type"] == protocol.MSG_ERROR
        assert msg["code"] == protocol.ERR_PROTOCOL_MISMATCH
    finally:
        await ws.close()


async def test_status_bridge_control_after_hello(daemon):
    state, _srv = daemon
    ws, _ack = await connect_and_hello(state, adapter_id="status-test")
    try:
        await ws.send(json.dumps({
            "type": protocol.MSG_BRIDGE_CONTROL,
            "id": 1,
            "action": protocol.BC_STATUS,
        }))
        resp = json.loads(await ws.recv())
        assert resp["type"] == protocol.MSG_RESPONSE
        assert resp["id"] == 1
        assert resp["ok"] is True
        snap = resp["result"]
        assert snap["daemon_version"] == __version__
        assert snap["daemon_pid"] > 0
        assert "adapters" in snap and len(snap["adapters"]) == 1
        assert snap["adapters"][0]["adapter_id"] == "status-test"
        assert "ports" in snap and snap["ports"]["adapter_ws"] == state.adapter_ws_port
    finally:
        await ws.close()
