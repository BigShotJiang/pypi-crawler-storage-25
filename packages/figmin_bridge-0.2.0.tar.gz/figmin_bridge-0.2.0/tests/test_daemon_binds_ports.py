"""§10.1 — daemon binds its listening ports and releases them on shutdown."""
from __future__ import annotations

import socket

from figmin_bridge import adapter_server, figmin_server, protocol, ssl_cert, config
from figmin_bridge.state import DaemonState


def _port_is_bound(host: str, port: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.5)
    try:
        s.bind((host, port))
        return False
    except OSError:
        return True
    finally:
        s.close()


async def test_adapter_port_binds_and_releases():
    state = DaemonState()
    state.adapter_ws_port = 0
    srv = await adapter_server.start_adapter_server(state, max_size=protocol.DEFAULT_WS_MAX_SIZE)
    try:
        assert state.adapter_ws_port > 0, "server should update port with OS-assigned value"
        assert _port_is_bound(protocol.ADAPTER_HOST, state.adapter_ws_port)
    finally:
        srv.close()
        await srv.wait_closed()

    assert not _port_is_bound(protocol.ADAPTER_HOST, state.adapter_ws_port), \
        "port must be released after server close"


async def test_figmin_ports_bind_and_release():
    state = DaemonState()
    state.figmin_ws_port = 0
    state.figmin_wss_port = 0
    bridge = figmin_server.FigminBridge(
        state=state,
        broadcast_figmin_status=adapter_server.broadcast_figmin_status,
        broadcast_readiness=adapter_server.broadcast_readiness,
    )
    state.figmin_bridge = bridge

    ssl_ctx = ssl_cert.ensure_ssl_cert(config.cache_dir())
    ws_srv, wss_srv = await figmin_server.start_figmin_servers(
        state, bridge,
        ws_host="127.0.0.1",
        max_size=protocol.DEFAULT_WS_MAX_SIZE,
        ssl_ctx=ssl_ctx,
    )
    try:
        assert state.figmin_ws_port > 0
        assert _port_is_bound("127.0.0.1", state.figmin_ws_port)
        if wss_srv is not None:
            assert state.figmin_wss_port > 0
            assert _port_is_bound("127.0.0.1", state.figmin_wss_port)
    finally:
        ws_srv.close()
        await ws_srv.wait_closed()
        if wss_srv is not None:
            wss_srv.close()
            await wss_srv.wait_closed()

    assert not _port_is_bound("127.0.0.1", state.figmin_ws_port)
