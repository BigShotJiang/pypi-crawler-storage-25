"""§10.4 — adapter survives daemon restart.

Uses the DaemonClient from figmin-mcp via direct import. Both packages live
side by side during dev; the import hygiene test (§10.7) in the figmin-mcp
suite enforces that the adapter package itself never imports figmin_bridge.

For this test we start/stop the daemon server in-process and verify the
client's reconnect state machine.
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest

from figmin_bridge import adapter_server, protocol
from figmin_bridge.state import DaemonState


def _import_adapter_client():
    here = Path(__file__).resolve()
    adapter_src = here.parent.parent.parent / "figmin-mcp" / "src"
    if not adapter_src.is_dir():
        pytest.skip(f"adapter sources not found at {adapter_src}")
    if str(adapter_src) not in sys.path:
        sys.path.insert(0, str(adapter_src))
    import figmin_mcp.client as mod
    return mod


async def test_client_reconnects_after_daemon_restart():
    client_mod = _import_adapter_client()

    state = DaemonState()
    state.adapter_ws_port = 0
    srv = await adapter_server.start_adapter_server(state, protocol.DEFAULT_WS_MAX_SIZE)

    client = client_mod.DaemonClient(
        adapter_id="reconnect-test",
        daemon_url=f"ws://{protocol.ADAPTER_HOST}:{state.adapter_ws_port}",
        max_size=protocol.DEFAULT_WS_MAX_SIZE,
        initial_connect_timeout=2.0,
    )
    await client.start()

    try:
        for _ in range(50):
            if client.is_connected():
                break
            await asyncio.sleep(0.05)
        assert client.is_connected(), \
            f"client never connected; last_error={client.reconnect.last_error}"

        result = await client.bridge_control(protocol.BC_STATUS)
        assert result["daemon_pid"] == state.daemon_pid

        srv.close()
        await srv.wait_closed()

        await asyncio.sleep(0.15)
        with pytest.raises(RuntimeError) as ei:
            await client.bridge_control(protocol.BC_STATUS)
        err = str(ei.value).lower()
        assert "reconnect" in err or "shutting" in err or "not running" in err, \
            f"unexpected error: {err}"

        state2 = DaemonState()
        state2.adapter_ws_port = state.adapter_ws_port
        srv2 = await adapter_server.start_adapter_server(state2, protocol.DEFAULT_WS_MAX_SIZE)

        for _ in range(300):
            if client.is_connected():
                break
            await asyncio.sleep(0.05)
        assert client.is_connected(), \
            f"client did not reconnect; last_error={client.reconnect.last_error}"

        result = await client.bridge_control(protocol.BC_STATUS)
        assert result["daemon_pid"] == state2.daemon_pid

        srv2.close()
        await srv2.wait_closed()
    finally:
        await client.stop()
