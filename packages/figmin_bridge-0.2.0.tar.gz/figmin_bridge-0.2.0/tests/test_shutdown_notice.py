"""§10.9 — on daemon shutdown, all adapters receive a `shutdown` message
before the socket closes.

This is an in-process test: we don't actually send SIGTERM. We call
`broadcast_shutdown` + close the server, which is exactly what main.py does
on Ctrl-C / SIGTERM.
"""
from __future__ import annotations

import asyncio
import json

from figmin_bridge import adapter_server, protocol

from conftest import connect_and_hello


async def test_all_adapters_receive_shutdown_notice(daemon):
    state, srv = daemon
    ws_a, _ = await connect_and_hello(state, adapter_id="notice-A")
    ws_b, _ = await connect_and_hello(state, adapter_id="notice-B")
    try:
        # Simulate what main.py does on Ctrl-C
        await adapter_server.broadcast_shutdown(state, "test shutdown")

        # Both adapters should receive the notice
        msg_a = json.loads(await asyncio.wait_for(ws_a.recv(), timeout=2.0))
        msg_b = json.loads(await asyncio.wait_for(ws_b.recv(), timeout=2.0))

        assert msg_a["type"] == protocol.MSG_SHUTDOWN
        assert msg_a["reason"] == "test shutdown"
        assert msg_b["type"] == protocol.MSG_SHUTDOWN
        assert msg_b["reason"] == "test shutdown"
    finally:
        await ws_a.close()
        await ws_b.close()
