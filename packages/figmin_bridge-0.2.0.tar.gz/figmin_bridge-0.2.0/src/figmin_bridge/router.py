"""Dispatch adapter messages to the right backend.

Two message types from adapters reach here:

  - MSG_COMMAND         forwarded to Figmin XR via state.figmin_bridge.
                        Response flows back asynchronously via the FigminBridge's
                        receive loop (it writes directly to adapter_ws — router
                        is not in that path).
  - MSG_BRIDGE_CONTROL  handled locally. `status` returns state.status_snapshot().
                        `list_voices` returns the Kokoro catalog + current voice.
                        `set_voice` persists to ~/figmin-mcp/config.json.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from figmin_bridge import config, protocol, tts
from figmin_bridge.state import DaemonState

logger = logging.getLogger(__name__)


async def handle_command(state: DaemonState, adapter_ws: Any, msg: dict) -> None:
    adapter_request_id = msg.get("id")
    command = msg.get("command")
    params = msg.get("params") or {}

    bridge = state.figmin_bridge
    if bridge is None or not state.figmin_connected:
        await _send_response(
            adapter_ws, adapter_request_id, ok=False,
            error="Figmin XR is not connected. "
                  "Open the MCP Agent app in Figmin XR and click Connect.",
        )
        return

    try:
        await bridge.forward_command(command, params, adapter_ws, adapter_request_id)
    except ConnectionError as e:
        await _send_response(adapter_ws, adapter_request_id, ok=False, error=str(e))
    except Exception as e:
        logger.exception("failed to forward command %r", command)
        await _send_response(
            adapter_ws, adapter_request_id, ok=False, error=f"Bridge error: {e}",
        )


async def handle_bridge_control(state: DaemonState, adapter_ws: Any, msg: dict) -> None:
    adapter_request_id = msg.get("id")
    action = msg.get("action")

    if action == protocol.BC_STATUS:
        await _send_response(adapter_ws, adapter_request_id, ok=True,
                             result=state.status_snapshot())
        return

    if action == protocol.BC_LIST_VOICES:
        await _send_response(adapter_ws, adapter_request_id, ok=True, result={
            "voices": list(tts.KOKORO_VOICES),
            "current": config.get_tts_voice(),
        })
        return

    if action == protocol.BC_SET_VOICE:
        voice_id = str(msg.get("voice_id") or "").strip()
        if not voice_id:
            await _send_response(adapter_ws, adapter_request_id, ok=False,
                                 error='voice_id is required. Use bridge_control list_voices to see options.')
            return
        if not any(v["id"] == voice_id for v in tts.KOKORO_VOICES):
            await _send_response(adapter_ws, adapter_request_id, ok=False,
                                 error=f'Unknown voice: {voice_id!r}')
            return
        config.save_tts_voice(voice_id)
        state.tts_voice = voice_id
        name = tts.voice_name(voice_id) or ""
        await _send_response(adapter_ws, adapter_request_id, ok=True, result={
            "voice": voice_id,
            "name": name,
        })
        return

    await _send_response(adapter_ws, adapter_request_id, ok=False,
                         error=f"unknown action: {action!r}")


async def _send_response(adapter_ws: Any, adapter_request_id: Any, *,
                          ok: bool, result: dict | None = None,
                          error: str | None = None) -> None:
    payload: dict = {
        "type": protocol.MSG_RESPONSE,
        "id": adapter_request_id,
        "ok": ok,
    }
    if ok:
        payload["result"] = result or {}
    else:
        payload["error"] = error or "unknown error"
    try:
        await adapter_ws.send(json.dumps(payload))
    except Exception:
        logger.exception("failed to send response id=%r", adapter_request_id)
