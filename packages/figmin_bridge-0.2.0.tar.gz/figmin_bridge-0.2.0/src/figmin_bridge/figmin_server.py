"""Hop-3 server: accepts the Figmin XR agent's WebSocket connections.

Lifted from old_mcp/server.py:1002-1493 (FigminBridge class) with these
structural changes:

  - Proxy mode is deleted. No `_proxies`, no `handle_proxy_connection`,
    no `_notify_proxies_figmin_status`.
  - Response routing goes through `DaemonState.figmin_pending`, not a
    local `_pending` dict, so multiple adapters can multiplex commands
    via per-connection id keying (§4.4 of the design).
  - `send_command` is replaced with `forward_command(command, params,
    adapter_ws, adapter_request_id)` — fire-and-forget; responses flow
    asynchronously via the receive loop.
  - STT/TTS backends go through stt.py / tts.py stubs until steps 6/7.

The wire format on hop 3 (daemon <-> Figmin XR) is unchanged (§9d).
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine, Optional

import websockets

from figmin_bridge import config, protocol, stt, tts
from figmin_bridge.state import DaemonState

logger = logging.getLogger(__name__)

COMMAND_TIMEOUT = float(os.environ.get("FIGMIN_TIMEOUT", "300"))

# Partial-transcription threshold. 1 second of 16 kHz Int16 = 32 000 bytes.
_PARTIAL_MIN_BYTES = 16000 * 1 * 2

BroadcastCoro = Callable[..., Coroutine[Any, Any, None]]


@dataclass
class FigminBridge:
    state: DaemonState
    broadcast_figmin_status: BroadcastCoro  # (state, connected: bool) -> awaitable
    broadcast_readiness: BroadcastCoro      # (state) -> awaitable

    _client: Any = field(default=None, init=False)
    _audio_buffer: list = field(default_factory=list, init=False)
    _partial_running: bool = field(default=False, init=False)

    # ------------------------------------------------------------------
    # Public: command forwarding (called by router)

    async def forward_command(self, command: str, params: dict,
                                adapter_ws: Any, adapter_request_id: int) -> None:
        if self._client is None:
            raise ConnectionError("Figmin XR is not connected")

        figmin_id = self.state.next_figmin_id()
        self.state.figmin_pending[figmin_id] = (adapter_ws, adapter_request_id)
        msg = {"id": figmin_id, "command": command, "params": params or {}}

        try:
            await self._client.send(json.dumps(msg))
        except Exception:
            self.state.figmin_pending.pop(figmin_id, None)
            raise

        asyncio.create_task(
            self._timeout_command(figmin_id, COMMAND_TIMEOUT),
            name=f"figmin-timeout-{figmin_id}",
        )

    async def _timeout_command(self, figmin_id: int, timeout: float) -> None:
        await asyncio.sleep(timeout)
        pending = self.state.figmin_pending.pop(figmin_id, None)
        if pending is None:
            return
        adapter_ws, adapter_request_id = pending
        await _safe_send_error(
            adapter_ws,
            adapter_request_id,
            f"Figmin XR did not respond within {timeout:.0f}s",
        )

    # ------------------------------------------------------------------
    # Server handler

    async def handle_connection(self, websocket: Any) -> None:
        logger.info("Figmin XR agent connected")
        self._client = websocket
        self._audio_buffer = []
        self._partial_running = False

        peer = _format_peer(websocket)
        self.state.figmin_connected = True
        self.state.figmin_peer = peer
        try:
            await self.broadcast_figmin_status(self.state, True)
        except Exception:
            logger.exception("failed broadcasting figmin_status=true")

        asyncio.create_task(self._send_tts_status(websocket), name="tts-status-hello")

        try:
            async for raw in websocket:
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    logger.warning("Invalid JSON from Figmin: %.200s", raw)
                    continue

                msg_type = msg.get("type")

                if msg_type == "audio_chunk":
                    await self._on_audio_chunk(msg, websocket)
                    continue
                if msg_type == "audio_cancel":
                    self._audio_buffer = []
                    self._partial_running = False
                    continue
                if msg_type == "voice_models_request":
                    await self._send_voice_models(websocket)
                    continue
                if msg_type == "voice_model_download":
                    asyncio.create_task(
                        self._handle_voice_model_download(msg, websocket),
                        name="stt-download",
                    )
                    continue
                if msg_type == "voice_model_select":
                    asyncio.create_task(
                        self._handle_voice_model_select(msg, websocket),
                        name="stt-select",
                    )
                    continue
                if msg_type == "tts_request":
                    asyncio.create_task(
                        self._handle_tts_request(msg, websocket),
                        name="tts-request",
                    )
                    continue
                if msg_type == "tts_download":
                    asyncio.create_task(
                        self._handle_tts_download(websocket),
                        name="tts-download",
                    )
                    continue

                # Routed command response
                msg_id = msg.get("id")
                if msg_id is not None:
                    await self._route_response(msg_id, msg)
        except websockets.ConnectionClosed:
            logger.info("Figmin XR agent disconnected")
        finally:
            if self._client is websocket:
                self._client = None
                self._audio_buffer = []
                self.state.figmin_connected = False
                self.state.figmin_peer = None
                try:
                    await self.broadcast_figmin_status(self.state, False)
                except Exception:
                    logger.exception("failed broadcasting figmin_status=false")
                await self._fail_all_pending("Figmin XR disconnected")

    # ------------------------------------------------------------------
    # Internal

    async def _route_response(self, figmin_id: Any, msg: dict) -> None:
        pending = self.state.figmin_pending.pop(figmin_id, None) if isinstance(figmin_id, int) else None
        if pending is None:
            logger.debug("orphan response figmin_id=%r dropped", figmin_id)
            return
        adapter_ws, adapter_request_id = pending
        figmin_result = {k: v for k, v in msg.items() if k != "id"}
        response = {
            "type": protocol.MSG_RESPONSE,
            "id": adapter_request_id,
            "ok": True,
            "result": figmin_result,
        }
        try:
            await adapter_ws.send(json.dumps(response))
        except Exception:
            logger.debug("adapter closed before response delivery (id=%r)", adapter_request_id)

    async def _fail_all_pending(self, error: str) -> None:
        for figmin_id, (adapter_ws, adapter_request_id) in list(self.state.figmin_pending.items()):
            await _safe_send_error(adapter_ws, adapter_request_id, error)
        self.state.figmin_pending.clear()

    # ------------------------------------------------------------------
    # Audio intercepts (STT)

    async def _on_audio_chunk(self, msg: dict, websocket: Any) -> None:
        audio_bytes = base64.b64decode(msg.get("data", ""))
        self._audio_buffer.append(audio_bytes)
        if msg.get("final", False):
            buf = self._audio_buffer
            self._audio_buffer = []
            self._partial_running = False
            asyncio.create_task(
                self._transcribe_and_respond(buf, websocket, partial=False),
                name="stt-final",
            )
        elif not self._partial_running:
            total = sum(len(b) for b in self._audio_buffer)
            if total >= _PARTIAL_MIN_BYTES:
                self._partial_running = True
                snapshot = list(self._audio_buffer)
                asyncio.create_task(
                    self._transcribe_and_respond(snapshot, websocket, partial=True),
                    name="stt-partial",
                )

    async def _transcribe_and_respond(self, buffer: list[bytes], websocket: Any,
                                        partial: bool = False) -> None:
        all_bytes = b"".join(buffer)
        tag = "partial" if partial else "final"
        if not all_bytes:
            if not partial:
                await _safe_ws_send(websocket, {
                    "type": "transcription",
                    "text": "",
                    "partial": False,
                    "error": "No audio received",
                })
            return

        try:
            loop = asyncio.get_event_loop()
            text = await loop.run_in_executor(None, stt.decode_and_transcribe, all_bytes)
            await _safe_ws_send(websocket, {
                "type": "transcription",
                "text": text,
                "partial": partial,
            })
        except NotImplementedError:
            if not partial:
                await _safe_ws_send(websocket, {
                    "type": "transcription",
                    "text": "",
                    "partial": False,
                    "error": "Voice requires faster-whisper. Install the daemon with figmin-bridge-gpu.",
                })
        except Exception as e:
            logger.error("Transcription error (%s): %s", tag, e, exc_info=True)
            if not partial:
                await _safe_ws_send(websocket, {
                    "type": "transcription",
                    "text": "",
                    "partial": False,
                    "error": f"Transcription failed: {e}",
                })
        finally:
            if partial:
                self._partial_running = False

    async def _send_voice_models(self, websocket: Any) -> None:
        available = stt.stt_available()
        models = []
        for m in stt.WHISPER_MODELS:
            models.append({**m, "downloaded": stt.is_model_cached(m["id"]) if available else False})
        await _safe_ws_send(websocket, {
            "type": "voice_models",
            "available": available,
            "models": models,
            "default": config.get_preferred_whisper_model(),
            "current": stt.current_model_id(),
        })

    async def _handle_voice_model_download(self, msg: dict, websocket: Any) -> None:
        model_id = msg.get("model_id")
        if not model_id:
            return
        loop = asyncio.get_event_loop()
        try:
            await _safe_ws_send(websocket, {
                "type": "voice_model_progress",
                "model_id": model_id,
                "status": "downloading",
                "progress": 0.1,
            })
            await loop.run_in_executor(None, stt.download_model, model_id)
            await _safe_ws_send(websocket, {
                "type": "voice_model_progress",
                "model_id": model_id,
                "status": "ready",
                "progress": 1.0,
            })
            await self._send_voice_models(websocket)
        except Exception as e:
            logger.error("Model download error: %s", e)
            await _safe_ws_send(websocket, {
                "type": "voice_model_progress",
                "model_id": model_id,
                "status": "error",
                "error": str(e),
                "progress": 0,
            })

    async def _handle_voice_model_select(self, msg: dict, websocket: Any) -> None:
        model_id = msg.get("model_id")
        if not model_id:
            return
        loop = asyncio.get_event_loop()
        try:
            await _safe_ws_send(websocket, {
                "type": "voice_model_progress",
                "model_id": model_id,
                "status": "loading",
                "progress": 0.5,
            })
            await loop.run_in_executor(None, stt.load_model, model_id)
            await _safe_ws_send(websocket, {
                "type": "voice_model_progress",
                "model_id": model_id,
                "status": "ready",
                "progress": 1.0,
            })
            await self._send_voice_models(websocket)
        except Exception as e:
            logger.error("Model select error: %s", e)
            await _safe_ws_send(websocket, {
                "type": "voice_model_progress",
                "model_id": model_id,
                "status": "error",
                "error": str(e),
                "progress": 0,
            })

    # ------------------------------------------------------------------
    # TTS intercepts

    async def _send_tts_status(self, websocket: Any) -> None:
        available = tts.tts_available()
        cached = tts.kokoro_is_cached() if available else False
        provider = tts.current_provider() if (available and cached) else None
        await _safe_ws_send(websocket, {
            "type": "tts_status",
            "available": available,
            "ready": available and cached,
            "provider": provider,
        })

    async def _handle_tts_request(self, msg: dict, websocket: Any) -> None:
        text = (msg.get("text") or "").strip()
        voice = config.get_tts_voice()
        msg_id = msg.get("id", "")
        speed = msg.get("speed", 1.0)

        if not text:
            return

        if not tts.tts_available():
            await _safe_ws_send(websocket, {
                "type": "tts_audio",
                "id": msg_id,
                "error": "TTS dependencies not installed. Install figmin-bridge-gpu for CUDA acceleration.",
            })
            return

        try:
            chunk_count = 0
            async for audio_b64, chunk_idx in tts.generate_tts_stream(text, voice, speed):
                await _safe_ws_send(websocket, {
                    "type": "tts_audio_chunk",
                    "audio": audio_b64,
                    "id": msg_id,
                    "chunk": chunk_idx,
                    "final": False,
                })
                chunk_count += 1
            await _safe_ws_send(websocket, {
                "type": "tts_audio_chunk",
                "id": msg_id,
                "chunk": chunk_count,
                "final": True,
            })
        except NotImplementedError:
            await _safe_ws_send(websocket, {
                "type": "tts_audio",
                "id": msg_id,
                "error": "TTS not yet available — daemon is still loading or TTS is disabled.",
            })
        except Exception as e:
            logger.error("TTS generation error: %s", e, exc_info=True)
            await _safe_ws_send(websocket, {
                "type": "tts_audio",
                "id": msg_id,
                "error": f"TTS failed: {e}",
            })

    async def _handle_tts_download(self, websocket: Any) -> None:
        loop = asyncio.get_event_loop()
        try:
            await _safe_ws_send(websocket, {
                "type": "tts_download_progress",
                "status": "downloading",
                "progress": 0.1,
            })
            await loop.run_in_executor(None, tts.download_model)
            await loop.run_in_executor(None, tts.load_model)
            await _safe_ws_send(websocket, {
                "type": "tts_download_progress",
                "status": "ready",
                "progress": 1.0,
            })
            await self._send_tts_status(websocket)
        except Exception as e:
            logger.error("TTS download error: %s", e, exc_info=True)
            await _safe_ws_send(websocket, {
                "type": "tts_download_progress",
                "status": "error",
                "error": str(e),
                "progress": 0,
            })

    @property
    def is_connected(self) -> bool:
        return self._client is not None


# ---------------------------------------------------------------------------
# Server startup helpers

async def start_figmin_servers(
    state: DaemonState,
    bridge: FigminBridge,
    *,
    ws_host: str,
    max_size: int,
    ssl_ctx: Optional[Any],
):
    """Bind plain ws:// and (if cert loads) wss:// on 39571/39572 respectively.

    Returns (ws_server, wss_server_or_None).
    """
    ws_server = await websockets.serve(
        bridge.handle_connection,
        ws_host,
        state.figmin_ws_port,
        ping_interval=30,
        ping_timeout=COMMAND_TIMEOUT,
        max_size=max_size,
    )
    if state.figmin_ws_port == 0 and ws_server.sockets:
        state.figmin_ws_port = ws_server.sockets[0].getsockname()[1]
    logger.info("Figmin WS server listening on ws://%s:%d", ws_host, state.figmin_ws_port)

    wss_server = None
    if ssl_ctx is not None:
        try:
            wss_server = await websockets.serve(
                bridge.handle_connection,
                ws_host,
                state.figmin_wss_port,
                ssl=ssl_ctx,
                ping_interval=30,
                ping_timeout=COMMAND_TIMEOUT,
                max_size=max_size,
            )
            if state.figmin_wss_port == 0 and wss_server.sockets:
                state.figmin_wss_port = wss_server.sockets[0].getsockname()[1]
            logger.info("Figmin WSS server listening on wss://%s:%d",
                        ws_host, state.figmin_wss_port)
        except Exception as e:
            logger.warning("WSS server not started: %s", e)
    else:
        logger.warning("WSS server not started — HTTPS pages will need ws:// (may fail on mixed content)")

    return ws_server, wss_server


# ---------------------------------------------------------------------------
# Helpers

def _format_peer(ws: Any) -> str:
    try:
        ip, port = ws.remote_address[:2]
        return f"{ip}:{port}"
    except Exception:
        return "?"


async def _safe_send_error(adapter_ws: Any, adapter_request_id: Any, error: str) -> None:
    try:
        await adapter_ws.send(json.dumps({
            "type": protocol.MSG_RESPONSE,
            "id": adapter_request_id,
            "ok": False,
            "error": error,
        }))
    except Exception:
        pass


async def _safe_ws_send(ws: Any, obj: dict) -> bool:
    try:
        await ws.send(json.dumps(obj))
        return True
    except Exception:
        return False
