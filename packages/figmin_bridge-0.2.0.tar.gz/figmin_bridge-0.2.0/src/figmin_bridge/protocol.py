"""Hop-2 protocol constants (daemon <-> adapter).

WebSocket JSON messages on ws://127.0.0.1:39573. One message per frame.

NOTE: Keep in sync with figmin-mcp/src/figmin_mcp/protocol.py. This file is
INTENTIONALLY DUPLICATED in both projects so the adapter can be installed
independently of the daemon. The two packages never import each other;
protocol.py is the shared wire contract, duplicated by design.

If you change anything in this file, change it in the other copy too.
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# Wire constants

PROTOCOL_VERSION = 1

# Loopback only. Adapters and daemon always run on the same machine.
ADAPTER_HOST = "127.0.0.1"
ADAPTER_PORT = 39573

# Figmin XR ports. Honor FIGMIN_WS_HOST in the daemon; the adapter never
# binds or connects to these.
FIGMIN_WS_PORT = 39571
FIGMIN_WSS_PORT = 39572

# websockets default max_size is 1 MiB, which is too small for our image /
# TTS payloads. 16 MiB is the project-wide default; override via env
# FIGMIN_WS_MAX_SIZE (same env on daemon and adapter).
DEFAULT_WS_MAX_SIZE = 16 * 1024 * 1024  # 16 MiB


# ---------------------------------------------------------------------------
# Message type constants
#
# Every message is a JSON object with a "type" field set to one of these.

# Adapter -> daemon
MSG_HELLO = "hello"                    # handshake: adapter_id, protocol_version
MSG_COMMAND = "command"                # execute a Figmin command: id, command, params
MSG_BRIDGE_CONTROL = "bridge_control"  # daemon-local query/mutate: id, action, ...

# Daemon -> adapter
MSG_HELLO_ACK = "hello_ack"            # handshake reply: figmin_connected, readiness, daemon_version, daemon_pid
MSG_RESPONSE = "response"              # reply to command/bridge_control: id, ok, result | error
MSG_FIGMIN_STATUS = "figmin_status"    # push: connected (bool)
MSG_READINESS = "readiness"            # push: stt, tts status strings
MSG_SHUTDOWN = "shutdown"              # push: reason — daemon is going away
MSG_ERROR = "error"                    # handshake failure (e.g. protocol_mismatch)


# ---------------------------------------------------------------------------
# Error codes used in MSG_ERROR

ERR_PROTOCOL_MISMATCH = "protocol_mismatch"


# ---------------------------------------------------------------------------
# Readiness values (for hello_ack.readiness and MSG_READINESS pushes)

READY_LOADING = "loading"
READY_DOWNLOADING = "downloading"
READY_READY = "ready"
READY_ERROR = "error"
READY_DISABLED = "disabled"


# ---------------------------------------------------------------------------
# bridge_control actions

BC_STATUS = "status"
BC_LIST_VOICES = "list_voices"
BC_SET_VOICE = "set_voice"


# ---------------------------------------------------------------------------
# Message shapes (documentation only — not enforced)
#
# hello (adapter -> daemon):
#   { "type": "hello", "adapter_id": "codex-12345", "protocol_version": 1 }
#
# hello_ack (daemon -> adapter):
#   { "type": "hello_ack",
#     "figmin_connected": true|false,
#     "readiness": {"stt": "ready", "tts": "loading"},
#     "daemon_version": "0.5.0",
#     "daemon_pid": 12345 }
#
# command (adapter -> daemon):
#   { "type": "command", "id": 1, "command": "execute_script", "params": {...} }
#
# bridge_control (adapter -> daemon):
#   { "type": "bridge_control", "id": 1, "action": "status" }
#   { "type": "bridge_control", "id": 2, "action": "list_voices" }
#   { "type": "bridge_control", "id": 3, "action": "set_voice", "voice_id": "am_adam" }
#
# response (daemon -> adapter) — success:
#   { "type": "response", "id": 1, "ok": true, "result": {...} }
# response (daemon -> adapter) — failure:
#   { "type": "response", "id": 1, "ok": false, "error": "Figmin XR disconnected" }
#
# figmin_status (daemon -> adapter, pushed):
#   { "type": "figmin_status", "connected": false }
#
# readiness (daemon -> adapter, pushed):
#   { "type": "readiness", "stt": "ready", "tts": "ready" }
#
# shutdown (daemon -> adapter, pushed before close):
#   { "type": "shutdown", "reason": "daemon shutting down" }
#
# error (daemon -> adapter, handshake failure):
#   { "type": "error", "code": "protocol_mismatch", "daemon_version": "0.5.0" }
