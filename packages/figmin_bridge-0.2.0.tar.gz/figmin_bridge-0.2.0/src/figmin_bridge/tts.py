"""Text-to-speech (vendored Kokoro).

Lifted from old_mcp/server.py — specifically:

  - _suppress_cuda_stderr            old_mcp/server.py:655-666
  - _kokoro_is_cached                old_mcp/server.py:744-749
  - _download_file                   old_mcp/server.py:752-765
  - _download_kokoro_model           old_mcp/server.py:768-785
  - _get_kokoro_model                old_mcp/server.py:788-914
  - _infer_lang_from_voice           old_mcp/server.py:917-921
  - _generate_tts_audio              old_mcp/server.py:924-944
  - _generate_tts_stream             old_mcp/server.py:947-984
  - _tts_available                   old_mcp/server.py:987-995
  - KOKORO_VOICES                    old_mcp/server.py:677-734
  - _VOICE_LANG_MAP                  old_mcp/server.py:737-741

The Kokoro import path changes from `figmin_mcp.vendor.kokoro.kokoro` to
`figmin_bridge.vendor.kokoro.kokoro` — other than that, preserved verbatim
per design §9c (GPU preservation). DO NOT:
  - replace vendored Kokoro with upstream kokoro-onnx
  - remove the stderr suppression
  - skip the cuDNN DLL pre-check (ORT hard-crashes the process otherwise)
  - "fix" the rt.set_default_logger_severity(3) suppression
  - consolidate CUDA init with stt.py — failure modes differ

CUDA DLL discovery (_register_cuda_dll_directories, _find_nvidia_pip_dll_dirs)
is imported from stt.py to avoid duplication. Both modules load the same
nvidia pip packages at process start; calling either is idempotent.
"""
from __future__ import annotations

import base64
import logging
import os
import threading
import urllib.error
import urllib.request
from contextlib import contextmanager
from pathlib import Path
from typing import AsyncIterator, Optional

from figmin_bridge import config
from figmin_bridge.stt import _find_nvidia_pip_dll_dirs, _register_cuda_dll_directories

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Module-level state (lifted verbatim from old_mcp/server.py:647-648, 667-674)

_kokoro_model = None
_kokoro_lock = threading.RLock()
_KOKORO_CACHE = config.cache_dir() / "kokoro"

_KOKORO_MODEL_FILE = "kokoro-v1.0.fp16.onnx"
_KOKORO_VOICES_FILE = "voices-v1.0.bin"
_KOKORO_LICENSE_FILE = "LICENSE"

_KOKORO_MODEL_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.fp16.onnx"
_KOKORO_VOICES_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin"
_KOKORO_LICENSE_URL = "https://huggingface.co/hexgrad/Kokoro-82M/raw/main/LICENSE"


# Voice catalog — all Kokoro v1.0 voices. Same list as old_mcp/server.py:677-734.
KOKORO_VOICES = [
    # American English
    {"id": "af_heart",   "name": "Heart",    "lang": "en-us", "gender": "female"},
    {"id": "af_alloy",   "name": "Alloy",    "lang": "en-us", "gender": "female"},
    {"id": "af_aoede",   "name": "Aoede",    "lang": "en-us", "gender": "female"},
    {"id": "af_bella",   "name": "Bella",    "lang": "en-us", "gender": "female"},
    {"id": "af_jessica", "name": "Jessica",  "lang": "en-us", "gender": "female"},
    {"id": "af_kore",    "name": "Kore",     "lang": "en-us", "gender": "female"},
    {"id": "af_nicole",  "name": "Nicole",   "lang": "en-us", "gender": "female"},
    {"id": "af_nova",    "name": "Nova",     "lang": "en-us", "gender": "female"},
    {"id": "af_river",   "name": "River",    "lang": "en-us", "gender": "female"},
    {"id": "af_sarah",   "name": "Sarah",    "lang": "en-us", "gender": "female"},
    {"id": "af_sky",     "name": "Sky",      "lang": "en-us", "gender": "female"},
    {"id": "am_adam",    "name": "Adam",     "lang": "en-us", "gender": "male"},
    {"id": "am_echo",    "name": "Echo",     "lang": "en-us", "gender": "male"},
    {"id": "am_eric",    "name": "Eric",     "lang": "en-us", "gender": "male"},
    {"id": "am_liam",    "name": "Liam",     "lang": "en-us", "gender": "male"},
    {"id": "am_michael", "name": "Michael",  "lang": "en-us", "gender": "male"},
    {"id": "am_onyx",    "name": "Onyx",     "lang": "en-us", "gender": "male"},
    # British English
    {"id": "bf_emma",    "name": "Emma",     "lang": "en-gb", "gender": "female"},
    {"id": "bf_isabella","name": "Isabella", "lang": "en-gb", "gender": "female"},
    {"id": "bm_george",  "name": "George",   "lang": "en-gb", "gender": "male"},
    {"id": "bm_lewis",   "name": "Lewis",    "lang": "en-gb", "gender": "male"},
    # Spanish
    {"id": "ef_dora",    "name": "Dora",     "lang": "es",    "gender": "female"},
    {"id": "em_alex",    "name": "Alex",     "lang": "es",    "gender": "male"},
    # French
    {"id": "ff_siwis",   "name": "Siwis",    "lang": "fr-fr", "gender": "female"},
    # Japanese
    {"id": "jf_alpha",   "name": "Alpha",    "lang": "ja",    "gender": "female"},
    {"id": "jf_gongitsune", "name": "Gongitsune", "lang": "ja", "gender": "female"},
    {"id": "jm_kumo",    "name": "Kumo",     "lang": "ja",    "gender": "male"},
    # Hindi
    {"id": "hf_alpha",   "name": "Alpha",    "lang": "hi",    "gender": "female"},
    {"id": "hf_beta",    "name": "Beta",     "lang": "hi",    "gender": "female"},
    {"id": "hm_omega",   "name": "Omega",    "lang": "hi",    "gender": "male"},
    {"id": "hm_psi",     "name": "Psi",      "lang": "hi",    "gender": "male"},
    # Italian
    {"id": "if_sara",    "name": "Sara",     "lang": "it",    "gender": "female"},
    {"id": "im_nicola",  "name": "Nicola",   "lang": "it",    "gender": "male"},
    # Brazilian Portuguese
    {"id": "pf_dora",    "name": "Dora",     "lang": "pt-br", "gender": "female"},
    {"id": "pm_alex",    "name": "Alex",     "lang": "pt-br", "gender": "male"},
    {"id": "pm_santa",   "name": "Santa",    "lang": "pt-br", "gender": "male"},
    # Mandarin Chinese
    {"id": "zf_xiaobei", "name": "Xiaobei",  "lang": "cmn",   "gender": "female"},
    {"id": "zf_xiaoni",  "name": "Xiaoni",   "lang": "cmn",   "gender": "female"},
    {"id": "zf_xiaoxiao","name": "Xiaoxiao", "lang": "cmn",   "gender": "female"},
    {"id": "zf_xiaoyi",  "name": "Xiaoyi",   "lang": "cmn",   "gender": "female"},
    {"id": "zm_yunjian", "name": "Yunjian",  "lang": "cmn",   "gender": "male"},
    {"id": "zm_yunxi",   "name": "Yunxi",    "lang": "cmn",   "gender": "male"},
    {"id": "zm_yunxia",  "name": "Yunxia",   "lang": "cmn",   "gender": "male"},
    {"id": "zm_yunyang", "name": "Yunyang",  "lang": "cmn",   "gender": "male"},
    # Korean
    {"id": "kf_sarah",   "name": "Sarah",    "lang": "ko",    "gender": "female"},
    {"id": "km_chul",    "name": "Chul",     "lang": "ko",    "gender": "male"},
]

# Language inference from voice prefix (lifted from server.py:737-741)
_VOICE_LANG_MAP = {
    "a": "en-us", "b": "en-gb", "e": "es", "f": "fr-fr",
    "j": "ja", "h": "hi", "i": "it", "p": "pt-br",
    "z": "cmn", "k": "ko",
}


# ---------------------------------------------------------------------------
# stderr suppression (verbatim from server.py:655-666)

# Suppress "Could not locate nvrtc64_120_0.dll" stderr spam from NVIDIA's CUDA
# runtime.  Without nvidia-cuda-nvrtc-cu12 (~200 MB), ORT can't JIT-compile
# optimised kernels and prints this warning on every TTS inference.  Performance
# is unaffected (~0.5-0.75s) so we skip the package and mute the noise.
# To install instead: add "--with nvidia-cuda-nvrtc-cu12" to the uv config.
@contextmanager
def _suppress_cuda_stderr():
    """Temporarily redirect stderr to devnull to silence nvrtc DLL warnings."""
    try:
        devnull = os.open(os.devnull, os.O_WRONLY)
        old_stderr = os.dup(2)
        os.dup2(devnull, 2)
        os.close(devnull)
        yield
    finally:
        os.dup2(old_stderr, 2)
        os.close(old_stderr)


# ---------------------------------------------------------------------------
# Download + load (verbatim from server.py:744-914)

def _kokoro_is_cached() -> bool:
    """Check if Kokoro model files are already downloaded."""
    return (
        (_KOKORO_CACHE / _KOKORO_MODEL_FILE).exists()
        and (_KOKORO_CACHE / _KOKORO_VOICES_FILE).exists()
    )


def _download_file(url: str, dest: Path, label: str = "") -> None:
    """Download a file with urllib (no dependencies)."""
    logger.info(f"Downloading {label or url} → {dest}")
    req = urllib.request.Request(url, method="GET")
    req.add_header("User-Agent", "figmin-xr-mcp/1.0")
    with urllib.request.urlopen(req, timeout=120) as resp:
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "wb") as f:
            while True:
                chunk = resp.read(1024 * 64)
                if not chunk:
                    break
                f.write(chunk)
    logger.info(f"Downloaded {label or url} ({dest.stat().st_size / 1024 / 1024:.1f} MB)")


def _download_kokoro_model() -> None:
    """Download Kokoro model files + LICENSE. Called from thread pool."""
    _KOKORO_CACHE.mkdir(parents=True, exist_ok=True)

    model_path = _KOKORO_CACHE / _KOKORO_MODEL_FILE
    voices_path = _KOKORO_CACHE / _KOKORO_VOICES_FILE
    license_path = _KOKORO_CACHE / _KOKORO_LICENSE_FILE

    if not model_path.exists():
        _download_file(_KOKORO_MODEL_URL, model_path, "Kokoro model (fp16)")
    if not voices_path.exists():
        _download_file(_KOKORO_VOICES_URL, voices_path, "Kokoro voices")
    if not license_path.exists():
        try:
            _download_file(_KOKORO_LICENSE_URL, license_path, "Kokoro LICENSE (Apache 2.0)")
        except Exception as e:
            # LICENSE download is best-effort — don't block TTS on it
            logger.warning(f"Could not download LICENSE: {e}")


def _get_kokoro_model():
    """Lazy-load Kokoro with optimized ONNX session. Thread-safe for init."""
    global _kokoro_model
    if _kokoro_model is not None:
        return _kokoro_model

    with _kokoro_lock:
        if _kokoro_model is not None:
            return _kokoro_model

        import onnxruntime as rt
        # Suppress ORT warnings about Conv ops "running in Fallback mode" caused by
        # missing nvidia-cuda-nvrtc-cu12 (NVIDIA Runtime Compiler).  Without NVRTC,
        # ORT can't JIT-compile optimised CUDA kernels for Kokoro's conv layers and
        # falls back to generic implementations.  Performance is still fine (~0.5-0.75s)
        # so we skip the ~200 MB nvrtc package and just silence the warnings.
        rt.set_default_logger_severity(3)  # 3 = ERROR only (suppresses WARNING)
        _register_cuda_dll_directories()
        from figmin_bridge.vendor.kokoro.kokoro import Kokoro

        model_path = _KOKORO_CACHE / _KOKORO_MODEL_FILE
        voices_path = _KOKORO_CACHE / _KOKORO_VOICES_FILE

        if not model_path.exists() or not voices_path.exists():
            _download_kokoro_model()

        # Build optimized session options
        sess_opts = rt.SessionOptions()
        sess_opts.graph_optimization_level = rt.GraphOptimizationLevel.ORT_ENABLE_ALL
        sess_opts.execution_mode = rt.ExecutionMode.ORT_SEQUENTIAL
        # Use all available CPU cores for intra-op parallelism (0 = auto-detect)
        sess_opts.intra_op_num_threads = 0
        # Enable memory optimizations
        sess_opts.enable_mem_pattern = True
        sess_opts.enable_cpu_mem_arena = True
        # Allow threads to spin-wait for lower latency (trades CPU for speed)
        sess_opts.add_session_config_entry("session.intra_op.allow_spinning", "1")
        # Dynamic block sizing for better load balancing
        sess_opts.add_session_config_entry("session.dynamic_block_base", "4")
        # Save optimized model so subsequent loads are faster
        optimized_path = _KOKORO_CACHE / _KOKORO_MODEL_FILE.replace(".onnx", ".optimized.onnx")
        if optimized_path.exists():
            logger.info(f"Loading pre-optimized Kokoro model...")
            model_to_load = str(optimized_path)
        else:
            logger.info(f"Loading Kokoro TTS model (will optimize on first load)...")
            sess_opts.optimized_model_filepath = str(optimized_path)
            model_to_load = str(model_path)

        # Detect providers — prefer CUDA with optimizations, fall back to CPU
        available = rt.get_available_providers()
        logger.info(f"ONNX Runtime available providers: {available}")

        use_cuda = False
        all_search_dirs: list[str] = []
        if "CUDAExecutionProvider" in available:
            # Pre-check: verify cuDNN DLLs exist before attempting CUDA session.
            # Without this, ONNX Runtime hard-crashes (not a Python exception) if cuDNN is missing.
            import platform, os
            if platform.system() == "Windows":
                # Gather all directories to search: PATH + nvidia pip package dirs
                path_dirs = os.environ.get("PATH", "").split(os.pathsep)
                pip_dirs = _find_nvidia_pip_dll_dirs()
                all_search_dirs = path_dirs + pip_dirs

                cudnn_in_path = [p for p in path_dirs if "cudnn" in p.lower()]
                logger.info(f"cuDNN-related PATH entries: {cudnn_in_path or 'NONE'}")
                if pip_dirs:
                    logger.info(f"nvidia pip DLL dirs: {pip_dirs}")

                cudnn_dlls = ["cudnn64_9.dll", "cudnn_graph64_9.dll"]
                all_found = True
                for dll_name in cudnn_dlls:
                    found_in_path = False
                    for p in all_search_dirs:
                        candidate = os.path.join(p, dll_name)
                        if os.path.isfile(candidate):
                            logger.info(f"cuDNN DLL found: {candidate}")
                            found_in_path = True
                            break
                    if not found_in_path:
                        logger.warning(f"cuDNN DLL not found in PATH or pip packages: {dll_name}")
                        all_found = False
                if all_found:
                    use_cuda = True
                else:
                    logger.warning(
                        "CUDA provider available but cuDNN 9 DLLs missing from PATH. "
                        "Install cuDNN 9.x for CUDA 12 and ensure its bin directory is in PATH. "
                        "Falling back to CPU."
                    )
            else:
                # On Linux, trust the provider list — cuDNN is usually in LD_LIBRARY_PATH
                use_cuda = True

        if use_cuda:
            # On Windows, register CUDA/cuDNN directories for DLL loading
            import platform, os
            if platform.system() == "Windows":
                for p in all_search_dirs:
                    if os.path.isdir(p) and ("cuda" in p.lower() or "cudnn" in p.lower() or "nvidia" in p.lower()):
                        try:
                            os.add_dll_directory(p)
                            logger.info(f"Added DLL directory for ONNX: {p}")
                        except OSError:
                            pass
            providers = [
                ("CUDAExecutionProvider", {"cudnn_conv_algo_search": "DEFAULT"}),
                "CPUExecutionProvider",
            ]
            logger.info("CUDA + cuDNN verified — using GPU acceleration for TTS")
        else:
            providers = ["CPUExecutionProvider"]
            if "CUDAExecutionProvider" not in available:
                logger.info("No GPU provider found — using CPU for TTS")

        with _suppress_cuda_stderr():
            try:
                session = rt.InferenceSession(model_to_load, sess_opts, providers=providers)
            except Exception as e:
                # Safety net — if CUDA session still fails, fall back to CPU
                if use_cuda:
                    logger.warning(f"CUDA session failed ({e}), falling back to CPU")
                    providers = ["CPUExecutionProvider"]
                    session = rt.InferenceSession(model_to_load, sess_opts, providers=providers)
                else:
                    raise

        active = session.get_providers()
        logger.info(f"Kokoro TTS session active providers: {active}")
        _kokoro_model = Kokoro.from_session(session, str(voices_path))
        logger.info("Kokoro TTS model ready")
        return _kokoro_model


def _infer_lang_from_voice(voice_id: str) -> str:
    """Infer the Kokoro language code from a voice ID prefix."""
    if voice_id and len(voice_id) >= 1:
        return _VOICE_LANG_MAP.get(voice_id[0], "en-us")
    return "en-us"


def _generate_tts_audio(text: str, voice: str = "", speed: float = 1.0) -> str:
    """Generate TTS audio and return base64-encoded WAV. Runs in thread pool."""
    import io
    import soundfile as sf

    voice = voice or config.get_tts_voice()

    kokoro = _get_kokoro_model()
    lang = _infer_lang_from_voice(voice)
    logger.info(f"TTS generating: voice={voice}, lang={lang}, text={text[:80]}...")

    with _suppress_cuda_stderr():
        samples, sample_rate = kokoro.create(text, voice=voice, speed=speed, lang=lang)

    buf = io.BytesIO()
    sf.write(buf, samples, sample_rate, format="WAV", subtype="PCM_16")
    audio_b64 = base64.b64encode(buf.getvalue()).decode()

    duration = len(samples) / sample_rate
    logger.info(f"TTS generated: {duration:.1f}s audio, {len(audio_b64)} base64 chars")
    return audio_b64


async def _generate_tts_stream(text: str, voice: str = "", speed: float = 1.0):
    """Async generator: yields (base64_wav, chunk_index) using kokoro.create_stream().

    Kokoro handles text splitting internally, preserving prosody across sentences.
    Each chunk is sent as soon as it's generated.
    """
    import io
    import time
    import soundfile as sf

    voice = voice or config.get_tts_voice()

    kokoro = _get_kokoro_model()
    lang = _infer_lang_from_voice(voice)
    logger.info(f"TTS streaming: voice={voice}, lang={lang}, text={text[:80]}...")

    t_start = time.monotonic()

    chunk_idx = 0
    with _suppress_cuda_stderr():
        stream = kokoro.create_stream(text, voice=voice, speed=speed, lang=lang)
        async for samples, sample_rate in stream:
            t_chunk = time.monotonic()
            buf = io.BytesIO()
            sf.write(buf, samples, sample_rate, format="WAV", subtype="PCM_16")
            audio_b64 = base64.b64encode(buf.getvalue()).decode()

            duration = len(samples) / sample_rate
            elapsed = t_chunk - t_start
            logger.info(
                f"TTS chunk {chunk_idx}: {duration:.1f}s audio, "
                f"{len(audio_b64)} base64 chars, elapsed={elapsed:.2f}s"
            )
            yield audio_b64, chunk_idx
            chunk_idx += 1

    total = time.monotonic() - t_start
    logger.info(f"TTS streaming done: {chunk_idx} chunks in {total:.2f}s")


def _tts_available() -> bool:
    """Check if vendored Kokoro + runtime deps are importable."""
    try:
        import soundfile  # noqa: F401
        import onnxruntime  # noqa: F401
        from figmin_bridge.vendor.kokoro.kokoro import Kokoro  # noqa: F401
        return True
    except ImportError:
        return False


# ---------------------------------------------------------------------------
# Public API (what figmin_server.py, router.py, and main.py call)

def tts_available() -> bool:
    return _tts_available()


def kokoro_is_cached() -> bool:
    return _kokoro_is_cached()


def current_provider() -> str:
    """Return the active ORT provider name (e.g. CUDAExecutionProvider).

    Empty string if the model has not been loaded yet.
    """
    if _kokoro_model is None:
        return ""
    try:
        active = _kokoro_model.sess.get_providers()
        return active[0] if active else ""
    except Exception:
        return ""


def preload() -> None:
    """Preload Kokoro in a daemon thread. Called from main at startup.

    Safe even when TTS deps aren't installed — logs a warning and returns.
    """
    try:
        if not _tts_available():
            logger.info("Vendored Kokoro deps not installed, TTS disabled")
            return
        if not _kokoro_is_cached():
            logger.info("Kokoro model not cached — downloading...")
            _download_kokoro_model()
        logger.info("Pre-loading Kokoro TTS model...")
        _get_kokoro_model()
        logger.info("Kokoro TTS model pre-loaded and ready")
    except Exception as e:
        logger.warning(f"Kokoro pre-load failed: {e}")


def download_model() -> None:
    """Download Kokoro model files. Runs in a thread pool."""
    _download_kokoro_model()


def load_model() -> None:
    """Load Kokoro model (downloads first if needed). Runs in a thread pool."""
    _get_kokoro_model()


async def generate_tts_stream(text: str, voice: str, speed: float) -> AsyncIterator[tuple[str, int]]:
    async for audio_b64, chunk_idx in _generate_tts_stream(text, voice, speed):
        yield audio_b64, chunk_idx


def voice_name(voice_id: str) -> Optional[str]:
    """Look up a voice's display name, or None if unknown."""
    for v in KOKORO_VOICES:
        if v["id"] == voice_id:
            return str(v.get("name"))
    return None
