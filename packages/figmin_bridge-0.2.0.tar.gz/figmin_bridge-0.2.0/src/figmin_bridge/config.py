"""Daemon-side config persistence: whisper model + TTS voice.

Lives at ~/figmin-mcp/config.json (same path and schema as old_mcp/server.py).
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_WHISPER_MODEL = os.environ.get("FIGMIN_WHISPER_MODEL", "base.en")
DEFAULT_TTS_VOICE = "am_adam"


def cache_dir() -> Path:
    return Path(os.environ.get("FIGMIN_CACHE_DIR", Path.home() / "figmin-mcp"))


def _config_file() -> Path:
    return cache_dir() / "config.json"


def get_config() -> dict:
    try:
        return json.loads(_config_file().read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {"whisper_model": DEFAULT_WHISPER_MODEL, "tts_voice": DEFAULT_TTS_VOICE}


def save_config(config: dict) -> None:
    try:
        cache_dir().mkdir(parents=True, exist_ok=True)
        _config_file().write_text(json.dumps(config, indent=2))
    except Exception as e:
        logger.warning("Could not save config: %s", e)


def get_tts_voice() -> str:
    return get_config().get("tts_voice", DEFAULT_TTS_VOICE)


def save_tts_voice(voice_id: str) -> None:
    config = get_config()
    config["tts_voice"] = voice_id
    save_config(config)


def get_preferred_whisper_model() -> str | None:
    from figmin_bridge.stt import WHISPER_MODELS
    model = get_config().get("whisper_model")
    if model and any(m["id"] == model for m in WHISPER_MODELS):
        return model
    return None


def save_preferred_whisper_model(model_id: str) -> None:
    config = get_config()
    config["whisper_model"] = model_id
    save_config(config)
