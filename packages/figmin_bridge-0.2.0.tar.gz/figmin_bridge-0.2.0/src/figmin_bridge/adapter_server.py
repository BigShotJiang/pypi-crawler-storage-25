"""Hop-2 server: accepts MCP adapter connections on 127.0.0.1:39573."""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

import websockets
from websockets.exceptions import ConnectionClosed

from figmin_bridge import __version__, protocol, router
from figmin_bridge.state import DaemonState

logger = logging.getLogger(__name__)

HELLO_TIMEOUT = 5.0


async def handle_adapter(ws: Any, state: DaemonState) -> None:
    adapter_id = "unknown"
    registered = False
    try:
        try:
            hello_raw = await asyncio.wait_for(ws.recv(), timeout=HELLO_TIMEOUT)
        except asyncio.TimeoutError:
            logger.warning("adapter did not send hello within %.1fs; closing", HELLO_TIMEOUT)
            return

        try:
            hello = json.loads(hello_raw)
        except json.JSONDecodeError:
            logger.warning("adapter hello was not JSON: %r", hello_raw)
            return

        if hello.get("type") != protocol.MSG_HELLO:
            logger.warning("expected %r, got %r", protocol.MSG_HELLO, hello.get("type"))
            return

        if hello.get("protocol_version") != protocol.PROTOCOL_VERSION:
            await _safe_send(ws, {
                "type": protocol.MSG_ERROR,
                "code": protocol.ERR_PROTOCOL_MISMATCH,
                "daemon_version": __version__,
            })
            return

        adapter_id = str(hello.get("adapter_id") or f"unknown-{id(ws)}")
        state.add_adapter(ws, adapter_id)
        registered = True
        logger.info("adapter connected: %s", adapter_id)

        await _safe_send(ws, {
            "type": protocol.MSG_HELLO_ACK,
            "figmin_connected": state.figmin_connected,
            "readiness": state.readiness_snapshot(),
            "daemon_version": __version__,
            "daemon_pid": state.daemon_pid,
        })

        async for raw in ws:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                logger.warning("adapter %s sent non-JSON: %r", adapter_id, raw)
                continue
            mtype = msg.get("type")
            if mtype == protocol.MSG_COMMAND:
                await router.handle_command(state, ws, msg)
            elif mtype == protocol.MSG_BRIDGE_CONTROL:
                await router.handle_bridge_control(state, ws, msg)
            else:
                logger.warning("adapter %s sent unknown type: %r", adapter_id, mtype)
    except ConnectionClosed:
        pass
    except Exception:
        logger.exception("error handling adapter %s", adapter_id)
    finally:
        if registered:
            _remove_adapter(state, ws, adapter_id)


def _remove_adapter(state: DaemonState, ws: Any, adapter_id: str) -> None:
    info = state.remove_adapter(ws)
    if info is not None:
        logger.info("adapter disconnected: %s", adapter_id)


async def _safe_send(ws: Any, obj: dict) -> bool:
    try:
        await ws.send(json.dumps(obj))
        return True
    except Exception:
        return False


async def start_adapter_server(state: DaemonState, max_size: int):
    """Bind the adapter-facing WebSocket server on 127.0.0.1:<state.adapter_ws_port>.

    Pass `state.adapter_ws_port = 0` to let the OS assign a port; the actual
    bound port is written back to `state.adapter_ws_port` so callers (and the
    status snapshot) see the real value.
    """
    async def wrapper(ws):
        await handle_adapter(ws, state)

    srv = await websockets.serve(
        wrapper,
        protocol.ADAPTER_HOST,
        state.adapter_ws_port,
        max_size=max_size,
    )
    if state.adapter_ws_port == 0 and srv.sockets:
        state.adapter_ws_port = srv.sockets[0].getsockname()[1]
    return srv


async def broadcast_shutdown(state: DaemonState, reason: str) -> None:
    msg = json.dumps({"type": protocol.MSG_SHUTDOWN, "reason": reason})
    for ws in list(state.adapters.keys()):
        try:
            await ws.send(msg)
        except Exception:
            pass


async def broadcast_figmin_status(state: DaemonState, connected: bool) -> None:
    msg = json.dumps({"type": protocol.MSG_FIGMIN_STATUS, "connected": connected})
    for ws in list(state.adapters.keys()):
        try:
            await ws.send(msg)
        except Exception:
            pass


async def broadcast_readiness(state: DaemonState) -> None:
    payload = {"type": protocol.MSG_READINESS, **state.readiness_snapshot()}
    msg = json.dumps(payload)
    for ws in list(state.adapters.keys()):
        try:
            await ws.send(msg)
        except Exception:
            pass
