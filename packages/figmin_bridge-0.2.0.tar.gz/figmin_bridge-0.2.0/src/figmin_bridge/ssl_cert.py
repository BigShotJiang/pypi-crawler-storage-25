"""Embedded self-signed certificate for the WSS server on port 39572.

Exists solely to satisfy browser mixed-content policy — HTTPS pages can only
connect to wss://, not ws://. The cert just needs to be *present* for TLS
to handshake; no identity validation happens.

Lifted verbatim from old_mcp/server.py:233-318.
"""
from __future__ import annotations

import logging
import ssl
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_EMBEDDED_CERT = """\
-----BEGIN CERTIFICATE-----
MIIDGTCCAgGgAwIBAgIUV064THjFuDmTnMACDfchZd8+znQwDQYJKoZIhvcNAQEL
BQAwHDEaMBgGA1UEAwwRZmlnbWluLW1jcC1icmlkZ2UwHhcNMjYwMjI2MDAwMTM1
WhcNMzYwMjI0MDAwMTM1WjAcMRowGAYDVQQDDBFmaWdtaW4tbWNwLWJyaWRnZTCC
ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKG30oYwPlxMS0e12/wsVQJg
G9ZBSorgY+nS/6yAi9PYeJ38VghMUbY54a65NCpoNTQ0HChIO4sqGDbp4fcu3hC5
Qo8Oga9UxkJfBwsXDU2hlN0ZjCm28kYZOky0a00Ck4SMoRBuXPyljJZCqgwTahFE
at/L/OZpxw1T+6rGOQSCqCMBv16x3sW/d9DWkNlnzVfw2nACRj9ogTPg8pZ65hud
9gErEJy/oCtng1bS1lAfwsxjyl9lD+YQP7ZtaK3mFZ8Iq8pkV2lelYYh3VV220oC
ZIAVpvX0/B6MKd/GF7C9OME1k+714Hqh3k5PIkVfIWPUuy+LW4vcJ2cR0feT3+MC
AwEAAaNTMFEwHQYDVR0OBBYEFAn93WYaIq76IFrr460Zum0omq3QMB8GA1UdIwQY
MBaAFAn93WYaIq76IFrr460Zum0omq3QMA8GA1UdEwEB/wQFMAMBAf8wDQYJKoZI
hvcNAQELBQADggEBAJJqZg9Qqlt9Xy1umaFnqGf4PSmVY27CQAzX3Qqdu0VPy3FC
GiJXeUxnhkAbbWFDGnPjeHBVdKW+jGCptUGQEopClD6S7h5l1y3wda8cPz3yindN
ZbJRUEcckv0vbjMARrqaOaRtmzG/V3i25y6Jm9QSKPSM9FwOFtkDnAQsbGzQlzf4
D/yB1XE+Fof3J0Z8YfYA28OVf+z7GLO+/GbXXGPNVBb6ZO2i0Bo0TcnTm4tbUAM+
tWsHKTxRA5Xk3wLOSSVdf0PEx8rDkYfwJKF6L7oyVJN4uMwdgt1iqM1AKawCkXZU
4uobYQQcu7jZDZ/RZl6KZcaNhFmusD7mpA0mB6M=
-----END CERTIFICATE-----
"""

_EMBEDDED_KEY = """\
-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCht9KGMD5cTEtH
tdv8LFUCYBvWQUqK4GPp0v+sgIvT2Hid/FYITFG2OeGuuTQqaDU0NBwoSDuLKhg2
6eH3Lt4QuUKPDoGvVMZCXwcLFw1NoZTdGYwptvJGGTpMtGtNApOEjKEQblz8pYyW
QqoME2oRRGrfy/zmaccNU/uqxjkEgqgjAb9esd7Fv3fQ1pDZZ81X8NpwAkY/aIEz
4PKWeuYbnfYBKxCcv6ArZ4NW0tZQH8LMY8pfZQ/mED+2bWit5hWfCKvKZFdpXpWG
Id1VdttKAmSAFab19PwejCnfxhewvTjBNZPu9eB6od5OTyJFXyFj1Lsvi1uL3Cdn
EdH3k9/jAgMBAAECggEAMV8VfrIr17HTKclzp8FBEsCUvwyf3VY0KqaoN9nm1n44
FMN84HusVp3FMLqKGohF9fISxpmG1C29xsYQno5IbYKht1sObKDNBmZMmC4peZHj
CL1L9VBNFumMyu4p9BDdSJJGeeW3rco86YLgt18V+r+QgVKdmxqgEomZQ8HQlndw
MvEwCazweDtMcgrexWn2XDGj8P3tZY5Vblkv1qBV3xclT5F4tN/mYiaQNuuv554n
u2PbrNr06Rrb01rRFCCHWy5/sp1jjRd26ij0m1vMfARuuVslhBZyOFJIo7ektY3t
pNIfq91YozFnYDIp5mbxFJpFOdhUTDoxwjYGvSBdAQKBgQDi8QX1aB5UISjZJ6ma
HAqtz6m0N8UcbvaP4aOa35NZGXxjL2s7cV1rF/B4SRNb2H8r+ym1fDflTnm6a6C0
7dg5ZHxKnse6NC/0JQ3qQOYD/TuRgakhmV+CPZ+y10sMMeuWfYh18NhR8nkR6wnv
n4Ctcq9M7EKnYCE7aYCvdJqGEQKBgQC2bNKABfgH3T8/ZglvUKYoxKt1nduIjd0t
PmZPOJdYm5sEdE+kxlj0DUKa5n6ZB8YPlMoCqIrNZLft0tooJV55gdFVLhsNDfCm
4sS9SWC7+O7PvyRfSzwJMnI8aC7ILdGx/hM2yg2H+VelXlZeCnoly/JuuNLPVwwe
S3cFZrwCswKBgATx44NZZW/H2TACITvuaH0pDTWUEYNxF4ZDEGGLhZZna8JtghSl
f7eZqe+1B+r0aLD4pAwETON+NkDNn47Rr+hwPBUUKJ3yDSlwtUDpcRmdJvMgtCK7
SM15skUfU89MNynsSlDnko8WjXTKfkjuXMtquE8gxsMG4TJ+NgOcstFBAoGANRq8
tHQIXhG0BbqoaHUryZZm61hGvhu+FRujINCyjiLOH5/UR31OC82IZBtRIy82IvcH
T3rM3TnCqULGKwWl2O1HiOphCY3TTmGZMBkaRd4TdvqHlg4Krgq3YopZhACCmLQD
1+E9yyV0tDkgH0Qhhrs2GbFH/P+0EWWagkID3S0CgYEAz7nBH4tn45lAPcPBj3Lk
roZ/pu1KgR934s5m/GjShE/fcHNBExi8lJfqxHnlf0GMGfj5zYepACbtJB6iUzwx
ZNBEoKb3dkHNsE3ylagx/fZLPSUSCK2xP0cOya/8QWttfRIMFPHn7/wQ7SwSAQeN
91oSQTg0gdZ5GEGii831Lws=
-----END PRIVATE KEY-----
"""


def ensure_ssl_cert(cache_dir: Path) -> Optional[ssl.SSLContext]:
    """Write the embedded certificate to disk (if needed) and return an SSLContext."""
    cert_file = cache_dir / "bridge-cert.pem"
    key_file = cache_dir / "bridge-key.pem"

    cache_dir.mkdir(parents=True, exist_ok=True)

    if not cert_file.exists():
        cert_file.write_text(_EMBEDDED_CERT)
        logger.info("Wrote TLS certificate: %s", cert_file)
    if not key_file.exists():
        key_file.write_text(_EMBEDDED_KEY)
        logger.info("Wrote TLS key: %s", key_file)

    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(str(cert_file), str(key_file))
        return ctx
    except Exception as e:
        logger.warning("Failed to load TLS certificate: %s", e)
        return None
