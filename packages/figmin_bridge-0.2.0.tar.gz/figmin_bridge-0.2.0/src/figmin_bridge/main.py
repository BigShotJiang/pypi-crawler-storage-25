"""Entry point for the figmin-bridge daemon.

Binds:
  - 127.0.0.1:39573          adapter-facing WebSocket (loopback only)
  - ${FIGMIN_WS_HOST}:39571  Figmin XR plain WebSocket
  - ${FIGMIN_WS_HOST}:39572  Figmin XR WSS WebSocket (self-signed cert)

Runs the asyncio event loop until Ctrl-C / SIGTERM. On shutdown, broadcasts
a `shutdown` notice to all connected adapters before closing sockets.
"""
from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
import threading
from pathlib import Path

from figmin_bridge import (
    __version__,
    adapter_server,
    config,
    figmin_server,
    protocol,
    ssl_cert,
    stt,
    tts,
)
from figmin_bridge.state import DaemonState

logger = logging.getLogger("figmin-bridge")


def _setup_logging(cache_dir: Path) -> None:
    cache_dir.mkdir(parents=True, exist_ok=True)
    log_path = cache_dir / "bridge.log"

    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    fh = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    fh.setFormatter(fmt)
    sh = logging.StreamHandler(sys.stderr)
    sh.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(fh)
    root.addHandler(sh)


def _max_size() -> int:
    raw = os.environ.get("FIGMIN_WS_MAX_SIZE")
    if raw is None:
        return protocol.DEFAULT_WS_MAX_SIZE
    try:
        return int(raw)
    except ValueError:
        logger.warning("FIGMIN_WS_MAX_SIZE is not an int: %r; using default %d",
                       raw, protocol.DEFAULT_WS_MAX_SIZE)
        return protocol.DEFAULT_WS_MAX_SIZE


def _seed_state_from_config(state: DaemonState) -> None:
    state.tts_voice = config.get_tts_voice()


def _detect_distribution_name() -> str:
    """Return whichever of figmin-bridge-gpu / figmin-bridge is installed.

    Both distributions ship the same `figmin_bridge` Python package, so the
    only way to tell them apart at runtime is via PyPI metadata. GPU takes
    priority when both are somehow present (shouldn't happen in practice,
    but it's the more useful default for dev).
    """
    import importlib.metadata as md
    for name in ("figmin-bridge-gpu", "figmin-bridge"):
        try:
            md.version(name)
            return name
        except md.PackageNotFoundError:
            continue
    return "figmin-bridge"


def _print_banner(state: DaemonState, ws_host: str, wss_started: bool) -> None:
    print(f"{_detect_distribution_name()} {__version__}", file=sys.stderr)
    wss_str = f"wss://{ws_host}:{state.figmin_wss_port}" if wss_started else "(WSS disabled — cert failed to load)"
    print(f"  Figmin XR: ws://{ws_host}:{state.figmin_ws_port}, {wss_str}", file=sys.stderr)
    print(f"  Adapters:  ws://{protocol.ADAPTER_HOST}:{state.adapter_ws_port}", file=sys.stderr)
    print(f"  STT: {state.stt_status} (model={state.stt_model or '-'}, device={state.stt_device or '-'})",
          file=sys.stderr)
    print(f"  TTS: {state.tts_status} (voice={state.tts_voice or '-'}, provider={state.tts_provider or '-'})",
          file=sys.stderr)
    print("Ready. Keep this window open while using Figmin XR.", file=sys.stderr)
    print("Press Ctrl-C to stop.", file=sys.stderr)


def _start_preloads(state: DaemonState, loop: asyncio.AbstractEventLoop) -> None:
    """Preload STT and TTS models in background threads and update state.

    Background threads update state.stt_status/tts_status atomically (single
    attribute writes — Python's GIL guarantees this is safe). After preload
    completes, we broadcast a readiness message to all connected adapters
    via loop.call_soon_threadsafe.
    """
    def _broadcast_readiness():
        loop.call_soon_threadsafe(
            lambda: asyncio.ensure_future(adapter_server.broadcast_readiness(state))
        )

    def _preload_stt():
        state.stt_status = protocol.READY_LOADING
        try:
            stt.preload()
        except Exception:
            logger.exception("STT preload crashed")
            state.stt_status = protocol.READY_ERROR
            _broadcast_readiness()
            return
        if stt.stt_available() and stt.current_model_id():
            state.stt_status = protocol.READY_READY
            state.stt_model = stt.current_model_id() or ""
            state.stt_device = stt.current_device()
        elif stt.stt_available():
            # Library importable but no model loaded yet (user will pick)
            state.stt_status = protocol.READY_READY
            state.stt_model = ""
            state.stt_device = ""
        else:
            state.stt_status = protocol.READY_DISABLED
        _broadcast_readiness()

    def _preload_tts():
        state.tts_status = protocol.READY_LOADING
        try:
            tts.preload()
        except Exception:
            logger.exception("TTS preload crashed")
            state.tts_status = protocol.READY_ERROR
            _broadcast_readiness()
            return
        if tts.tts_available() and tts.kokoro_is_cached():
            state.tts_status = protocol.READY_READY
            state.tts_provider = tts.current_provider()
        elif tts.tts_available():
            state.tts_status = protocol.READY_DOWNLOADING
            state.tts_provider = ""
        else:
            state.tts_status = protocol.READY_DISABLED
        _broadcast_readiness()

    # Run STT preload FIRST, then TTS, on a single worker thread. STT's
    # ctypes.cdll.LoadLibrary("cublas64_12.dll") preloads the cublas DLL
    # into the process; without this, Kokoro's ORT CUDA session creation
    # fails to resolve cublas64_12.dll and silently falls back to CPU.
    # Parallel threads race and sometimes skip the GPU path (see logs from
    # v0.5.0 smoke tests — TTS session showed CPUExecutionProvider only
    # when STT and TTS preloads overlapped).
    def _preload_sequence():
        _preload_stt()
        _preload_tts()

    threading.Thread(target=_preload_sequence, daemon=True, name="stt-tts-preload").start()


async def _amain() -> None:
    cache_dir = config.cache_dir()
    _setup_logging(cache_dir)

    state = DaemonState()
    _seed_state_from_config(state)
    max_size = _max_size()
    ws_host = os.environ.get("FIGMIN_WS_HOST", "0.0.0.0")

    bridge = figmin_server.FigminBridge(
        state=state,
        broadcast_figmin_status=adapter_server.broadcast_figmin_status,
        broadcast_readiness=adapter_server.broadcast_readiness,
    )
    state.figmin_bridge = bridge

    try:
        adapter_srv = await adapter_server.start_adapter_server(state, max_size)
    except OSError as exc:
        logger.error("Failed to bind adapter port %d: %s", state.adapter_ws_port, exc)
        logger.error("Is another figmin-bridge daemon already running? Kill it and retry.")
        sys.exit(1)

    ssl_ctx = ssl_cert.ensure_ssl_cert(cache_dir)

    try:
        figmin_ws_srv, figmin_wss_srv = await figmin_server.start_figmin_servers(
            state, bridge, ws_host=ws_host, max_size=max_size, ssl_ctx=ssl_ctx,
        )
    except OSError as exc:
        logger.error("Failed to bind Figmin port: %s", exc)
        adapter_srv.close()
        await adapter_srv.wait_closed()
        sys.exit(1)

    _start_preloads(state, asyncio.get_running_loop())
    _print_banner(state, ws_host, wss_started=figmin_wss_srv is not None)

    shutdown_event = asyncio.Event()
    if sys.platform != "win32":
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, shutdown_event.set)
            except NotImplementedError:
                pass

    try:
        await shutdown_event.wait()
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass

    logger.info("shutting down: notifying adapters")
    try:
        await adapter_server.broadcast_shutdown(state, "daemon shutting down")
    except Exception:
        logger.exception("error broadcasting shutdown")

    for srv in (adapter_srv, figmin_ws_srv, figmin_wss_srv):
        if srv is None:
            continue
        srv.close()
        try:
            await srv.wait_closed()
        except Exception:
            pass

    logger.info("shutdown complete")


def run() -> None:
    try:
        asyncio.run(_amain())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    run()
