"""Daemon runtime state.

Single mutable container passed around by reference. All mutations happen on
the asyncio event loop (no locks needed). STT/TTS status fields are updated
by background threads via `loop.call_soon_threadsafe` — see stt.py/tts.py.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

from figmin_bridge import __version__, protocol


@dataclass
class AdapterInfo:
    adapter_id: str
    connected_at: float
    websocket: Any


@dataclass
class DaemonState:
    daemon_version: str = __version__
    daemon_pid: int = field(default_factory=os.getpid)
    start_time: float = field(default_factory=time.time)

    figmin_connected: bool = False
    figmin_peer: Optional[str] = None

    adapters: Dict[Any, AdapterInfo] = field(default_factory=dict)

    stt_status: str = protocol.READY_DISABLED
    stt_model: str = ""
    stt_device: str = ""
    tts_status: str = protocol.READY_DISABLED
    tts_voice: str = ""
    tts_provider: str = ""

    figmin_ws_port: int = protocol.FIGMIN_WS_PORT
    figmin_wss_port: int = protocol.FIGMIN_WSS_PORT
    adapter_ws_port: int = protocol.ADAPTER_PORT

    # figmin_id -> (adapter_ws, adapter_request_id). Populated at command-dispatch
    # time when a command is forwarded to Figmin XR; drained when Figmin replies.
    figmin_pending: Dict[int, Tuple[Any, int]] = field(default_factory=dict)
    _next_figmin_id: int = 1

    # FigminBridge instance, set by main.py during startup. Router reads it.
    # Typed as Any to avoid a circular import with figmin_server.
    figmin_bridge: Any = None

    def next_figmin_id(self) -> int:
        i = self._next_figmin_id
        self._next_figmin_id += 1
        return i

    def add_adapter(self, ws: Any, adapter_id: str) -> AdapterInfo:
        info = AdapterInfo(adapter_id=adapter_id, connected_at=time.time(), websocket=ws)
        self.adapters[ws] = info
        return info

    def remove_adapter(self, ws: Any) -> Optional[AdapterInfo]:
        info = self.adapters.pop(ws, None)
        if info is None:
            return None
        stale = [fid for fid, (conn, _) in self.figmin_pending.items() if conn is ws]
        for fid in stale:
            self.figmin_pending.pop(fid, None)
        return info

    def uptime_seconds(self) -> float:
        return time.time() - self.start_time

    def status_snapshot(self) -> dict:
        return {
            "daemon_version": self.daemon_version,
            "daemon_pid": self.daemon_pid,
            "uptime_seconds": int(self.uptime_seconds()),
            "figmin_connected": self.figmin_connected,
            "figmin_peer": self.figmin_peer,
            "adapters": [
                {"adapter_id": a.adapter_id, "connected_at": int(a.connected_at)}
                for a in self.adapters.values()
            ],
            "stt": {
                "status": self.stt_status,
                "model": self.stt_model,
                "device": self.stt_device,
            },
            "tts": {
                "status": self.tts_status,
                "voice": self.tts_voice,
                "provider": self.tts_provider,
            },
            "ports": {
                "figmin_ws": self.figmin_ws_port,
                "figmin_wss": self.figmin_wss_port,
                "adapter_ws": self.adapter_ws_port,
            },
        }

    def readiness_snapshot(self) -> dict:
        return {"stt": self.stt_status, "tts": self.tts_status}
