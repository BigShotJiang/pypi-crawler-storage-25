"""Speech-to-text (faster-whisper).

Lifted from old_mcp/server.py — specifically:

  - _find_nvidia_pip_dll_dirs        old_mcp/server.py:406-468
  - _register_cuda_dll_directories   old_mcp/server.py:471-512
  - _get_whisper_model               old_mcp/server.py:515-603
  - _transcribe                      old_mcp/server.py:606-626
  - _decode_and_transcribe           old_mcp/server.py:629-641

Preserved verbatim per design §9c (GPU preservation). DO NOT:
  - reorder imports
  - remove the ctypes.cdll.LoadLibrary("cublas64_12.dll") probe before
    `from faster_whisper import WhisperModel`
  - "fix" the _stale destructor leak (CTranslate2 CUDA destructor segfaults)
  - consolidate CUDA init with tts.py (different failure modes)
  - upgrade faster-whisper, onnxruntime, or nvidia-* package versions

Public interface (used by figmin_server.py and main.py):
  WHISPER_MODELS
  stt_available() -> bool
  is_model_cached(model_id) -> bool
  current_model_id() -> str | None
  current_device() -> str
  preload() -> None            (called from a daemon thread)
  download_model(model_id)     (blocking; run in executor)
  load_model(model_id)         (blocking; run in executor)
  decode_and_transcribe(bytes) -> str   (blocking; run in executor)
"""
from __future__ import annotations

import logging
import os
import threading
from typing import Optional

from figmin_bridge import config

logger = logging.getLogger(__name__)

# Available models — exposed to agent.html for model picker.
# Same list as old_mcp/server.py:333-338, do not reorder.
WHISPER_MODELS = [
    {"id": "base.en",  "name": "English – Fast",              "size": "~150 MB"},
    {"id": "small.en", "name": "English – Advanced",           "size": "~460 MB"},
    {"id": "base",     "name": "Multilingual – Fast",          "size": "~150 MB"},
    {"id": "small",    "name": "Multilingual – Advanced",      "size": "~460 MB"},
]

# ---------------------------------------------------------------------------
# Module-level state (lifted verbatim from old_mcp/server.py:324-330, 402-403)

_whisper_model = None
_whisper_model_id: Optional[str] = None
_whisper_lock = threading.RLock()
_whisper_device: str = ""

_WHISPER_CACHE = config.cache_dir() / "whisper"
os.environ["HF_HOME"] = str(_WHISPER_CACHE)

_cuda_dll_dirs_registered = False
_nvidia_pip_dll_dirs: list[str] = []


# ---------------------------------------------------------------------------
# CUDA DLL discovery and registration (verbatim from server.py:406-512)

def _find_nvidia_pip_dll_dirs() -> list[str]:
    """Discover DLL directories from nvidia pip packages (nvidia-cuda-runtime-cu12, nvidia-cudnn-cu12, etc.).

    These packages install DLLs under site-packages/nvidia/*/bin/ on Windows
    and site-packages/nvidia/*/lib/ on Linux.  Returns a list of existing
    directories.  Safe to call when the packages are not installed.
    """
    global _nvidia_pip_dll_dirs
    if _nvidia_pip_dll_dirs:
        return _nvidia_pip_dll_dirs

    import importlib.util, os, platform
    dirs: list[str] = []

    try:
        import onnxruntime as _ort
        if hasattr(_ort, "preload_dlls"):
            _ort.preload_dlls(directory="")
            logger.info("Called onnxruntime.preload_dlls(directory='') — ORT 1.21+ nvidia site-packages search")
    except Exception as e:
        logger.debug(f"onnxruntime.preload_dlls() not available or failed: {e}")

    try:
        import nvidia  # type: ignore
        nvidia_root = os.path.dirname(nvidia.__path__[0] if hasattr(nvidia, '__path__') else nvidia.__file__)
        nvidia_pkg_dir = os.path.join(nvidia_root, "nvidia")
        if os.path.isdir(nvidia_pkg_dir):
            is_win = platform.system() == "Windows"
            sub = "bin" if is_win else "lib"
            for entry in os.listdir(nvidia_pkg_dir):
                candidate = os.path.join(nvidia_pkg_dir, entry, sub)
                if os.path.isdir(candidate):
                    dirs.append(candidate)
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"nvidia pip package discovery error: {e}")

    try:
        import site
        for sp in site.getsitepackages() + [site.getusersitepackages()]:
            nv = os.path.join(sp, "nvidia")
            if os.path.isdir(nv):
                is_win = platform.system() == "Windows"
                sub = "bin" if is_win else "lib"
                for entry in os.listdir(nv):
                    candidate = os.path.join(nv, entry, sub)
                    if os.path.isdir(candidate) and candidate not in dirs:
                        dirs.append(candidate)
    except Exception:
        pass

    _nvidia_pip_dll_dirs = dirs
    if dirs:
        logger.info(f"Found nvidia pip package DLL dirs: {dirs}")
    return dirs


def _register_cuda_dll_directories():
    """Register CUDA/cuDNN directories for DLL loading on Windows.

    Python 3.8+ changed DLL loading to not search PATH by default.
    This must be called early, before any library tries to load CUDA DLLs.

    Two mechanisms:
      - `os.add_dll_directory(p)` — makes the dir searchable for ctypes and
        Python-initiated LoadLibrary calls.
      - `os.environ["PATH"]` prepend — makes the dir searchable for DLL
        dependency resolution. ORT's onnxruntime_providers_cuda.dll has
        imports (cublas, cufft, cudart, cudnn*) that Windows resolves at
        provider-load time using the *process* PATH, not the path list from
        os.add_dll_directory. Without this, ORT silently drops the
        CUDAExecutionProvider and falls back to CPU. This is the fix for
        the "Kokoro TTS session active providers: ['CPUExecutionProvider']"
        regression we hit during the v0.5.0 refactor.

    Searches both PATH (system installs) and nvidia pip packages.
    """
    global _cuda_dll_dirs_registered
    if _cuda_dll_dirs_registered:
        return
    _cuda_dll_dirs_registered = True

    import os, platform
    if platform.system() != "Windows":
        return

    registered: list[str] = []

    for p in os.environ.get("PATH", "").split(os.pathsep):
        p_lower = p.lower()
        if os.path.isdir(p) and ("cuda" in p_lower or "cudnn" in p_lower or "nvidia" in p_lower):
            try:
                os.add_dll_directory(p)
                registered.append(p)
            except OSError:
                pass

    for p in _find_nvidia_pip_dll_dirs():
        if p not in registered:
            try:
                os.add_dll_directory(p)
                registered.append(p)
            except OSError:
                pass

    # Also prepend the nvidia pip dll dirs to PATH so Windows DLL dependency
    # resolution can find cublas / cufft / cudnn when ORT loads its providers.
    pip_dirs = _find_nvidia_pip_dll_dirs()
    if pip_dirs:
        current_path = os.environ.get("PATH", "")
        current_parts = current_path.split(os.pathsep) if current_path else []
        current_set = {p.lower() for p in current_parts}
        added = [p for p in pip_dirs if p.lower() not in current_set]
        if added:
            os.environ["PATH"] = os.pathsep.join(added + current_parts)
            logger.info(f"Prepended nvidia pip DLL dirs to PATH: {added}")

    if registered:
        logger.info(f"Registered CUDA DLL directories: {registered}")
    else:
        logger.info("No CUDA/cuDNN directories found in PATH or pip packages")


# ---------------------------------------------------------------------------
# Whisper model load / transcribe (verbatim from server.py:515-641)

def _get_whisper_model(model_id: Optional[str] = None, save_pref: bool = True):
    """Lazy-load a faster-whisper model. Downloads from HuggingFace on first use."""
    global _whisper_model, _whisper_model_id, _whisper_device

    model_id = (
        model_id
        or _whisper_model_id
        or config.get_preferred_whisper_model()
        or config.DEFAULT_WHISPER_MODEL
    )

    if _whisper_model is not None and _whisper_model_id == model_id:
        return _whisper_model

    with _whisper_lock:
        if _whisper_model is not None and _whisper_model_id == model_id:
            return _whisper_model

        # ── Detect CUDA BEFORE importing faster_whisper ──────────────
        # ctranslate2 (faster-whisper's backend) loads native DLLs at
        # import time.  On Windows, if CUDA DLLs are partially present
        # the import can hang or crash the thread.  Register DLL dirs
        # and probe CUDA first so we know what device to target.
        import ctypes, os, platform
        _register_cuda_dll_directories()

        device = "cpu"
        compute = "int8"
        try:
            if platform.system() == "Windows":
                try:
                    ctypes.cdll.LoadLibrary("cublas64_12.dll")
                except OSError:
                    search_dirs = os.environ.get("PATH", "").split(os.pathsep) + _find_nvidia_pip_dll_dirs()
                    found = False
                    for p in search_dirs:
                        candidate = os.path.join(p, "cublas64_12.dll")
                        if os.path.isfile(candidate):
                            logger.info(f"Loading cublas via full path: {candidate}")
                            ctypes.cdll.LoadLibrary(candidate)
                            found = True
                            break
                    if not found:
                        raise FileNotFoundError("cublas64_12.dll not found in any PATH directory or nvidia pip packages")
            else:
                ctypes.cdll.LoadLibrary("libcublas.so.12")
            device = "cuda"
            compute = "float16"
            logger.info("CUDA runtime available — Whisper will use GPU")
        except (OSError, Exception) as e:
            logger.info(f"CUDA runtime not available ({e}), Whisper will use CPU")

        # ── Import faster_whisper (triggers ctranslate2 native load) ─
        try:
            from faster_whisper import WhisperModel
        except Exception as e:
            logger.error(f"Failed to import faster_whisper: {e}")
            raise
        logging.getLogger("faster_whisper").setLevel(logging.WARNING)

        # Unload old model first to free GPU VRAM
        # NOTE: We stash the old model reference instead of destroying it
        # immediately. CTranslate2's CUDA destructor can segfault the process.
        # The stashed reference keeps the model alive; VRAM is freed when
        # the new model loads and Python eventually GCs the old one.
        if _whisper_model is not None:
            old_id = _whisper_model_id
            logger.info(f"Switching Whisper model from '{old_id}' to '{model_id}' ...")
            if not hasattr(_get_whisper_model, '_stale'):
                _get_whisper_model._stale = []
            _get_whisper_model._stale.append(_whisper_model)
            _whisper_model = None
            _whisper_model_id = None
            logger.info(f"Whisper model '{old_id}' replaced (old ref stashed)")

        logger.info(f"Loading Whisper model: {model_id} (device={device}, compute={compute}) ...")
        try:
            loaded = WhisperModel(model_id, device=device, compute_type=compute)
        except Exception as e:
            if device == "cuda":
                logger.warning(f"Failed to load Whisper on GPU ({e}), falling back to CPU")
                device = "cpu"
                compute = "int8"
                loaded = WhisperModel(model_id, device=device, compute_type=compute)
            else:
                raise
        logger.info(f"Whisper model '{model_id}' ready on {device}")
        _whisper_model = loaded
        _whisper_model_id = model_id
        _whisper_device = device
        if save_pref:
            config.save_preferred_whisper_model(model_id)
        return _whisper_model


def _transcribe(audio_float32, model_id: Optional[str] = None) -> str:
    """Run Whisper transcription on a float32 numpy array (16 kHz mono)."""
    with _whisper_lock:
        model = _get_whisper_model(model_id)

        effective_id = (
            model_id
            or _whisper_model_id
            or config.get_preferred_whisper_model()
            or config.DEFAULT_WHISPER_MODEL
        )
        lang = "en" if effective_id.endswith(".en") else None
        logger.debug(f"Transcribing with model={effective_id}, language={lang or 'auto-detect'}")
        segments, _ = model.transcribe(audio_float32, language=lang, beam_size=1)
        text = " ".join(seg.text.strip() for seg in segments)

    lower = text.lower().strip()
    if not lower or lower in (
        "[blank_audio]", "(blank audio)", "[silence]", "you",
        "thank you.", "thanks for watching!", "bye.",
    ):
        return ""

    return text.strip()


def _decode_and_transcribe(all_bytes: bytes, model_id: Optional[str] = None) -> str:
    """Decode Int16 PCM bytes and run Whisper. Runs entirely in a thread pool.

    This does all blocking work (numpy import, audio conversion, model loading,
    transcription) in one function so the async event loop is never blocked.
    """
    import numpy as np

    audio_int16 = np.frombuffer(all_bytes, dtype=np.int16)
    audio_float = audio_int16.astype(np.float32) / 32768.0
    logger.debug(f"Audio decoded: {len(audio_int16)} samples, {len(audio_int16)/16000:.1f}s")

    return _transcribe(audio_float, model_id)


# ---------------------------------------------------------------------------
# Public API (what figmin_server.py and main.py call)

def stt_available() -> bool:
    """True if faster-whisper is importable. Does not trigger a model load."""
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:
        return False


def is_model_cached(model_id: str) -> bool:
    model_dir = _WHISPER_CACHE / "hub" / f"models--Systran--faster-whisper-{model_id}"
    return model_dir.exists()


def current_model_id() -> Optional[str]:
    return _whisper_model_id


def current_device() -> str:
    return _whisper_device


def preload() -> None:
    """Preload the preferred whisper model. Called from a daemon thread.

    No-op if faster-whisper is not importable or no model preference exists.
    The user can still pick a model via the agent.html UI.
    """
    try:
        try:
            import faster_whisper  # noqa: F401
            logger.info("faster-whisper import OK")
        except Exception as e:
            logger.warning(f"faster-whisper not importable ({e}), STT disabled")
            return

        if _whisper_model is not None:
            logger.info("Whisper model already loaded, skipping pre-load")
            return
        preferred = config.get_preferred_whisper_model()
        if not preferred:
            logger.info(
                "No model preference saved, skipping pre-load "
                "(user will pick on first use)"
            )
            return
        logger.info(f"Pre-loading preferred model: {preferred}")
        _get_whisper_model(preferred, save_pref=False)
        logger.info("Whisper model pre-loaded and ready")
    except BaseException as e:
        # BaseException catches SystemExit, KeyboardInterrupt, and
        # any native-level failures that bypass Exception.
        logger.warning(f"Whisper pre-load skipped: {type(e).__name__}: {e}")


def download_model(model_id: str) -> None:
    """Download and load a Whisper model. Runs in a thread pool."""
    logger.info(f"Downloading Whisper model: {model_id}")
    _get_whisper_model(model_id)
    logger.info(f"Model '{model_id}' downloaded and loaded")


def load_model(model_id: str) -> None:
    """Switch the active Whisper model (must already be downloaded)."""
    _get_whisper_model(model_id)


def decode_and_transcribe(audio_bytes: bytes) -> str:
    return _decode_and_transcribe(audio_bytes)
