# figmin-bridge

Figmin XR bridge daemon. Owns WebSocket ports for Figmin XR (39571/39572) and
for MCP adapters (39573 on loopback). Loads Whisper (STT) and Kokoro (TTS)
models once at startup; adapters come and go without losing Figmin state.

See the design doc and `C:\workspace\claude\mcp_refactor\old_mcp\` for
reference. This is a fresh package — the old combined `server.py` is being
split into this daemon plus the thin `figmin-mcp` adapter.

## Dev

```
uv run --project C:\workspace\claude\mcp_refactor\figmin-bridge figmin-bridge-gpu
```

## Users (GPU, recommended)

```
uvx figmin-bridge-gpu
```
