import asyncio
import shlex
from pathlib import Path

from crackerjack.core.console import CrackerjackConsole
from crackerjack.core.workflow_orchestrator import WorkflowPipeline
from crackerjack.models.protocols import ConsoleInterface, OptionsProtocol

VALID_COMMANDS = {"test", "lint", "check", "format", "security", "complexity", "all"}


def validate_command(
    command: str | None,
    args: str | None = None,
) -> tuple[str, list[str]]:
    if command is None:
        msg = "Command cannot be None"
        raise ValueError(msg)

    if command.startswith(("--", "-")):
        msg = (
            f"Invalid command: {command!r}\n"
            f"Commands should be semantic (e.g., 'test', 'lint', 'check')\n"
            f"Use ai_agent_mode=True parameter for auto-fix, not --ai-fix in command"
        )
        raise ValueError(
            msg,
        )

    if command not in VALID_COMMANDS:
        msg = (
            f"Unknown command: {command!r}\n"
            f"Valid commands: {', '.join(sorted(VALID_COMMANDS))}"
        )
        raise ValueError(
            msg,
        )

    args_str = args if args is not None else ""

    parsed_args = shlex.split(args_str) if args_str else []
    if "--ai-fix" in parsed_args:
        msg = (
            "Do not pass --ai-fix in args parameter\n"
            "Use ai_agent_mode=True parameter instead"
        )
        raise ValueError(
            msg,
        )

    return command, parsed_args


class CrackerjackCLIFacade:
    def __init__(
        self,
        console: ConsoleInterface | None = None,
        pkg_path: Path | None = None,
    ) -> None:
        self.console = console or CrackerjackConsole()
        self.pkg_path = pkg_path or Path.cwd()

    def process(self, options: OptionsProtocol) -> None:
        try:
            if self._should_handle_special_mode(options):
                self._handle_special_modes(options)
                return
            enable_hooks = getattr(options, "enable_hooks", None)
            pipeline = WorkflowPipeline(
                console=self.console,
                pkg_path=self.pkg_path,
                enable_hooks=enable_hooks,
            )
            success = pipeline.run_complete_workflow_sync(options)
            if not success:
                raise SystemExit(1)
        except KeyboardInterrupt:
            self.console.print("\n[yellow]⏹️ Operation cancelled by user[/ yellow]")
            raise SystemExit(130)
        except Exception as e:
            self.console.print(f"[red]💥 Unexpected error: {e}[/ red]")
            if options.verbose:
                import traceback

                self.console.print(f"[dim]{traceback.format_exc()}[/ dim]")
            raise SystemExit(1)

    async def process_async(self, options: OptionsProtocol) -> None:
        await asyncio.to_thread(self.process, options)

    def _should_handle_special_mode(self, options: OptionsProtocol) -> bool:
        return (
            getattr(options, "start_mcp_server", False)
            or getattr(options, "advanced_batch", False)
            or getattr(options, "monitor_dashboard", False)
        )

    def _handle_special_modes(self, options: OptionsProtocol) -> None:
        if getattr(options, "start_mcp_server", False):
            self._start_mcp_server()
        elif getattr(options, "advanced_batch", False):
            self._handle_advanced_batch(options)

    def _start_mcp_server(self) -> None:
        try:
            from crackerjack.mcp.server_core import main as start_mcp_main

            self.console.print(
                "[bold cyan]🤖 Starting Crackerjack MCP Server...[/ bold cyan]",
            )
            start_mcp_main(str(self.pkg_path))
        except ImportError:
            self.console.print(
                "[red]❌ MCP server requires additional dependencies[/ red]",
            )
            self.console.print("[yellow]Install with: uv sync --group mcp[/ yellow]")
            raise SystemExit(1)
        except Exception as e:
            self.console.print(f"[red]❌ Failed to start MCP server: {e}[/ red]")
            raise SystemExit(1)

    def _handle_advanced_batch(self, options: OptionsProtocol) -> None:
        self.console.print(
            "[red]❌ Advanced batch processing is not yet implemented[/ red]",
        )
        raise SystemExit(1)


def create_crackerjack_runner(
    console: ConsoleInterface | None = None,
    pkg_path: Path | None = None,
) -> CrackerjackCLIFacade:
    return CrackerjackCLIFacade(console=console, pkg_path=pkg_path)


CrackerjackRunner = CrackerjackCLIFacade
