"""Generate Mermaid Gantt syntax from mapped tasks."""

from __future__ import annotations

from collections import OrderedDict
import re
from typing import Dict, Iterable, List, Optional

from .models import GanttTask


ALLOWED_MODIFIERS = {"done", "active", "crit"}

# Horizontal scroll / useWidth (see html_renderer + AT-001-12).
# ~52px/day keeps daily axis labels readable when tickInterval is 1day (was 25; still too cramped).
GANTT_PIXELS_PER_DAY = 52
GANTT_MIN_USE_WIDTH = 960


def gantt_date_span_days(tasks: List[GanttTask]) -> int:
    """Inclusive calendar days from earliest task start to latest task end."""
    if not tasks:
        return 1
    min_start = min(t.start_date for t in tasks)
    max_end = max(t.end_date for t in tasks)
    return (max_end - min_start).days + 1


def compute_gantt_use_width(
    total_days: int,
    *,
    pixels_per_day: int = GANTT_PIXELS_PER_DAY,
    min_width: int = GANTT_MIN_USE_WIDTH,
) -> int:
    """Mermaid gantt ``useWidth`` so bars are not compressed; short ranges get a floor width."""
    span = max(1, total_days)
    return max(min_width, span * pixels_per_day)
SECTION_PRIORITY = {
    "done": 0,
    "doing": 1,
    "in progress": 1,
    "to do": 2,
    "todo": 2,
    "backlog": 3,
}


def _format_date(value) -> str:
    return value.isoformat()


def _format_task_date_range(task: GanttTask) -> str:
    start = task.start_date
    end = task.end_date
    if start.year == end.year and start.month == end.month:
        return f"{start.strftime('%b %d')} - {end.strftime('%d')}"
    return f"{start.strftime('%b %d')} - {end.strftime('%b %d')}"


def _status_modifiers(status: Optional[str]) -> List[str]:
    """Split comma-separated Mermaid modifiers (e.g. active,crit for blocked)."""
    if not status:
        return []
    out: List[str] = []
    for raw in status.split(","):
        token = raw.strip().lower()
        if token in ALLOWED_MODIFIERS:
            out.append(token)
    return out


def format_task_line(task: GanttTask) -> str:
    """Format one GanttTask as a Mermaid Gantt task line."""
    parts: List[str] = []
    title = task.name
    if task.assignee:
        title = f"{title} [{task.assignee}]"
    title = f"{title} ({task.progress}%)"
    display_name = f"{_format_task_date_range(task)} | {title}"

    for modifier in _status_modifiers(task.status):
        parts.append(modifier)

    parts.append(task.task_id)

    if task.dependencies:
        deps = " ".join(dep for dep in task.dependencies if dep)
        if deps:
            parts.append(f"after {deps}")
            parts.append(_format_date(task.end_date))
        else:
            parts.append(_format_date(task.start_date))
            parts.append(_format_date(task.end_date))
    else:
        parts.append(_format_date(task.start_date))
        parts.append(_format_date(task.end_date))

    metadata = ", ".join(parts)
    return f"    {display_name} :{metadata}"


def _group_tasks_by_section(tasks: Iterable[GanttTask]) -> Dict[str, List[GanttTask]]:
    grouped: "OrderedDict[str, List[GanttTask]]" = OrderedDict()
    for task in tasks:
        section = (task.section or "").strip()
        if not section:
            continue
        grouped.setdefault(section, []).append(task)
    return grouped


def _ordered_sections(grouped: Dict[str, List[GanttTask]]) -> List[str]:
    """Return sections ordered by execution progress semantics."""

    def _section_sort_key(section_name: str) -> tuple[int, str]:
        normalized = section_name.strip().casefold()
        milestone_match = re.fullmatch(r"milestone\s+(\d+)", normalized)
        if milestone_match:
            return (-1, f"{int(milestone_match.group(1)):04d}")
        # After Milestone 1..N, before list-based legacy sections (if any)
        if normalized == "no milestone":
            return (0, "")
        return (SECTION_PRIORITY.get(normalized, 99), normalized)

    return sorted(grouped.keys(), key=_section_sort_key)


def _sort_tasks_within_section(tasks: List[GanttTask]) -> List[GanttTask]:
    """Sort tasks in ascending chronological order within a section."""
    return sorted(
        tasks,
        key=lambda task: (task.end_date, task.start_date, task.name.casefold()),
    )


def generate_mermaid_gantt(tasks: List[GanttTask], title: str = "Project Gantt Chart") -> str:
    """Generate complete Mermaid Gantt block."""
    # Day ticks + no weekend exclusion so the axis matches calendar days when scrolling (AT-001-12).
    lines: List[str] = [
        "gantt",
        f"    title {title}",
        "    dateFormat YYYY-MM-DD",
        "    axisFormat %d %b",
        "    tickInterval 1day",
    ]

    grouped = _group_tasks_by_section(tasks)
    for section_name in _ordered_sections(grouped):
        section_tasks = _sort_tasks_within_section(grouped[section_name])
        if not section_tasks:
            continue
        lines.append("")
        lines.append(f"    section {section_name}")
        for task in section_tasks:
            lines.append(format_task_line(task))

    return "\n".join(lines)

