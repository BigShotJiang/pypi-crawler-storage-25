"""Gantt chart generation package."""

