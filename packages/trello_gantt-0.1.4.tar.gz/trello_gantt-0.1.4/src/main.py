"""CLI entry point for Trello -> Mermaid -> HTML pipeline."""

from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import List

from dotenv import load_dotenv

from .field_mapper import map_cards_to_gantt_tasks
from .html_renderer import render_html, save_html
from .mermaid_generator import generate_mermaid_gantt, gantt_date_span_days
from .trello_data import (
    TrelloAuthError,
    TrelloBoardNotFoundError,
    TrelloDataError,
    get_board_name,
    get_cards_for_lists,
    parse_board_id,
)
from .validator import format_validation_report, validate_tasks


def _parse_lists_argument(raw_lists: str | None) -> List[str]:
    if not raw_lists:
        return []
    return [item.strip() for item in raw_lists.split(",") if item.strip()]


def _env(key: str, default: str = "") -> str:
    """Read a value from environment (already loaded from .env by this point)."""
    return os.getenv(key, default)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate a Mermaid Gantt HTML file from Trello board data.",
    )
    parser.add_argument(
        "--board-id",
        default=_env("GANTT_BOARD_ID"),
        help="Trello board ID. Env: GANTT_BOARD_ID",
    )
    parser.add_argument(
        "--lists",
        default=_env("GANTT_LISTS"),
        help='Comma-separated list names. Env: GANTT_LISTS',
    )
    parser.add_argument(
        "--output",
        default=_env("GANTT_OUTPUT", "gantt.html"),
        help="Output HTML path. Env: GANTT_OUTPUT. Default: gantt.html",
    )
    parser.add_argument(
        "--title",
        default=_env("GANTT_TITLE", "Project Gantt Chart"),
        help="Gantt chart title. Env: GANTT_TITLE",
    )
    parser.add_argument(
        "--milestone-list",
        default=_env("GANTT_MILESTONE_LISTS"),
        help='Comma-separated list names to render as milestones. Env: GANTT_MILESTONE_LISTS',
    )
    return parser


def run_pipeline(args: argparse.Namespace) -> int:
    list_names = _parse_lists_argument(args.lists)
    milestone_lists = _parse_lists_argument(args.milestone_list)

    fetch_result = get_cards_for_lists(args.board_id, list_names)
    tasks, mapping_warnings, stats, assignee_legend = map_cards_to_gantt_tasks(
        fetch_result.cards_by_list,
        milestone_lists=milestone_lists,
    )

    all_mapping_warnings = [*fetch_result.warnings, *mapping_warnings]
    report = validate_tasks(tasks, all_mapping_warnings, stats=stats)

    if report.has_errors:
        print("Validation failed. HTML was not generated.", file=sys.stderr)
        print(format_validation_report(report), file=sys.stderr)
        return 1

    try:
        board_display_name = get_board_name(args.board_id)
    except TrelloDataError:
        board_display_name = args.board_id

    mermaid_syntax = generate_mermaid_gantt(tasks, title=args.title)
    metadata = {
        "title": args.title,
        "board_id": args.board_id,
        "board_name": board_display_name,
        "lists_used": [item["name"] for item in fetch_result.matched_lists],
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "assignee_legend": assignee_legend,
        "gantt_total_days": gantt_date_span_days(tasks),
    }
    html = render_html(mermaid_syntax, report, metadata, tasks=tasks)
    output_path = save_html(html, args.output)

    print("Gantt generation completed successfully.")
    print(f"Output: {output_path}")
    print(
        "Summary: "
        f"{stats.get('total_cards', 0)} cards processed, "
        f"{stats.get('mapped_tasks', 0)} tasks generated, "
        f"{len(report.warnings)} warnings, "
        f"{len(report.errors)} errors."
    )
    return 0


def main() -> int:
    # Load .env: CWD first, then global config as fallback
    load_dotenv(Path.cwd() / ".env")
    load_dotenv(Path.home() / ".config" / "trello-gantt" / ".env")

    parser = build_parser()
    args = parser.parse_args()

    if not args.board_id:
        parser.error("--board-id is required (or set GANTT_BOARD_ID in .env)")

    args.board_id = parse_board_id(args.board_id)

    try:
        return run_pipeline(args)
    except TrelloAuthError as exc:
        print(f"Authentication error: {exc}", file=sys.stderr)
        return 1
    except TrelloBoardNotFoundError as exc:
        print(f"Board error: {exc}", file=sys.stderr)
        return 1
    except TrelloDataError as exc:
        print(f"Trello error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001
        print(f"Unexpected error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

