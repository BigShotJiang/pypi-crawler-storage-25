"""Render standalone HTML with Mermaid Gantt and validation details."""

from __future__ import annotations

from datetime import datetime
from html import escape
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import json

from .mermaid_generator import compute_gantt_use_width
from .models import GanttTask, ValidationItem, ValidationReport


def _render_items(items: Iterable[ValidationItem], css_class: str) -> str:
    rows: List[str] = []
    for item in items:
        ref = f" <code>{escape(item.card_reference)}</code>" if item.card_reference else ""
        rows.append(f'<li class="alert {css_class}">{escape(item.message)}{ref}</li>')
    return "".join(rows) if rows else '<li class="alert ok">No issues found.</li>'


def _render_metadata(metadata: Dict[str, Any]) -> str:
    board_id = escape(str(metadata.get("board_id", "N/A")))
    board_name = escape(str(metadata.get("board_name", "N/A")))
    lists_used = metadata.get("lists_used", [])
    if isinstance(lists_used, list):
        lists_text = ", ".join(str(item) for item in lists_used) if lists_used else "(all open lists)"
    else:
        lists_text = str(lists_used)
    generated_at = metadata.get("generated_at") or datetime.now().isoformat(timespec="seconds")

    return (
        '<div class="header-info">'
        f"<p><strong>Board:</strong> {board_name} (<code>{board_id}</code>)</p>"
        f"<p><strong>Lists:</strong> {escape(lists_text)}</p>"
        f"<p><strong>Generated:</strong> {escape(str(generated_at))}</p>"
        "</div>"
    )


def _render_legend() -> str:
    """Color swatches matching pastel Mermaid overrides (Trello column semantics)."""
    items = [
        ("#e2e8f0", "#94a3b8", "Backlog"),
        ("#fef3c7", "#fde047", "To Do"),
        ("#bae6fd", "#7dd3fc", "Doing"),
        ("#fecaca", "#fca5a5", "Blocked"),
        ("#bbf7d0", "#4ade80", "Done"),
    ]
    rows: List[str] = []
    for fill, stroke, label in items:
        rows.append(
            '<div class="legend-item">'
            f'<span class="legend-swatch" style="background:{fill};border:1px solid {stroke}"></span>'
            f'<span style="color:var(--text-main)">{escape(label)}</span>'
            "</div>"
        )
    body = "".join(rows)
    return (
        "<div>"
        '<h3 class="legend-heading">Status (Lists)</h3>'
        f'<div class="legend-row">{body}</div>'
        "</div>"
    )


def _render_assignee_legend(entries: Sequence[Tuple[str, str]]) -> str:
    """Map initials → Trello display name (e.g. [YA] - Yasman Martínez)."""
    if not entries:
        return ""
    items: List[str] = []
    for initials, display_name in entries:
        items.append(
            f"<li><strong>{escape('[' + initials + ']')}</strong>"
            f" &nbsp; {escape(display_name)}</li>"
        )
    body = "".join(items)
    return (
        '<div style="margin-top:8px">'
        '<h3 class="legend-heading">Assignees</h3>'
        f'<ul class="assignee-legend">{body}</ul>'
        "</div>"
    )


def _serialize_tasks_for_js(tasks: List[GanttTask]) -> str:
    """Serialize tasks to JSON for client-side filtering."""
    items = []
    for t in tasks:
        items.append({
            "task_id": t.task_id,
            "name": t.name,
            "section": t.section,
            "start_date": t.start_date.isoformat(),
            "end_date": t.end_date.isoformat(),
            "status": t.status,
            "dependencies": t.dependencies,
            "assignee": t.assignee,
            "progress": t.progress,
        })
    return json.dumps(items, ensure_ascii=False)


def render_html(
    mermaid_syntax: str,
    validation_report: ValidationReport,
    metadata: Dict[str, Any],
    tasks: Optional[List[GanttTask]] = None,
) -> str:
    """Build a standalone HTML document."""
    page_title = escape(str(metadata.get("title", "Gantt Chart")))
    metadata_html = _render_metadata(metadata)
    assignee_legend = metadata.get("assignee_legend") or []
    if not isinstance(assignee_legend, list):
        assignee_legend = []
    assignee_legend_html = _render_assignee_legend(assignee_legend)
    tasks_json = _serialize_tasks_for_js(tasks) if tasks else "[]"
    assignee_legend_json = json.dumps(
        {initials: name for initials, name in assignee_legend},
        ensure_ascii=False,
    )

    errors_html = _render_items(validation_report.errors, "error")
    warnings_html = _render_items(validation_report.warnings, "warning")

    raw_days = metadata.get("gantt_total_days")
    try:
        total_days = max(1, int(raw_days)) if raw_days is not None else 1
    except (TypeError, ValueError):
        total_days = 1
    gantt_use_width = compute_gantt_use_width(total_days)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{page_title}</title>
  <style>
    :root {{
      --bg-body: #f8fafc;
      --bg-card: #ffffff;
      --bg-alt: #f1f5f9;
      --text-main: #0f172a;
      --text-muted: #64748b;
      --border-color: #e2e8f0;
      --primary: #3b82f6;
      --shadow-sm: 0 1px 2px 0 rgba(0,0,0,0.05);
      --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
      --radius: 12px;
      --err-bg: #fef2f2; --err-text: #991b1b; --err-border: #f87171;
      --warn-bg: #fff7ed; --warn-text: #9a3412; --warn-border: #fdba74;
      --ok-bg: #f0fdf4; --ok-text: #166534; --ok-border: #86efac;
      --assignee-bg: #e0f2fe; --assignee-text: #0369a1;
    }}
    body.dark-mode {{
      --bg-body: #0f172a; --bg-card: #1e293b; --bg-alt: #334155;
      --text-main: #f8fafc; --text-muted: #cbd5e1; --border-color: #475569;
      --shadow-sm: 0 1px 2px 0 rgba(0,0,0,0.5);
      --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.6);
      --err-bg: #450a0a; --err-text: #fecaca; --err-border: #ef4444;
      --warn-bg: #431407; --warn-text: #fed7aa; --warn-border: #f97316;
      --ok-bg: #052e16; --ok-text: #bbf7d0; --ok-border: #22c55e;
      --assignee-bg: #0c4a6e; --assignee-text: #38bdf8;
    }}
    body {{
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: var(--bg-body);
      margin: 0; padding: 0;
      color: var(--text-main); line-height: 1.5;
      transition: background-color 0.3s ease, color 0.3s ease;
    }}
    .page-layout {{ display: flex; min-height: 100vh; }}
    .sidebar {{
      position: fixed; top: 0; left: 0; height: 100vh; width: 220px;
      background: var(--bg-card); border-right: 1px solid var(--border-color);
      padding: 24px 0; overflow-y: auto; display: flex; flex-direction: column;
      transition: background-color 0.3s ease, border-color 0.3s ease;
      z-index: 10;
    }}
    .sidebar-title {{
      font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.08em;
      color: var(--text-muted); font-weight: 700; padding: 0 20px; margin: 0 0 12px 0;
    }}
    .sidebar nav {{ display: flex; flex-direction: column; gap: 2px; }}
    .sidebar nav a {{
      display: flex; align-items: center; gap: 10px;
      padding: 10px 20px; color: var(--text-muted); text-decoration: none;
      font-size: 0.9rem; font-weight: 500; border-left: 3px solid transparent;
      transition: all 0.15s ease;
    }}
    .sidebar nav a:hover {{ color: var(--text-main); background: var(--bg-alt); }}
    .sidebar nav a.active {{
      color: var(--primary); border-left-color: var(--primary);
      background: rgba(59,130,246,0.06); font-weight: 600;
    }}
    .sidebar nav a .nav-icon {{ font-size: 1.1rem; width: 20px; text-align: center; }}
    .sidebar-header {{
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 20px; margin-bottom: 16px;
    }}
    .theme-toggle {{
      background: var(--bg-alt); color: var(--text-main);
      border: 1px solid var(--border-color); width: 36px; height: 36px;
      border-radius: 50%; cursor: pointer; font-size: 1.1rem;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.2s; padding: 0;
    }}
    .theme-toggle:hover {{ background: var(--border-color); }}
    .main-content {{ flex: 1; min-width: 0; padding: 32px 24px; margin-left: 220px; }}
    .container {{ max-width: 1400px; margin: 0 auto; display: flex; flex-direction: column; gap: 24px; }}
    .section {{ display: none; }}
    .section.active {{ display: block; }}
    @media (max-width: 768px) {{
      .sidebar {{ display: none; }}
      .main-content {{ padding: 16px; margin-left: 0; }}
      .section {{ display: block !important; }}
    }}
    .card {{
      background: var(--bg-card); border: 1px solid var(--border-color);
      border-radius: var(--radius); padding: 24px;
      box-shadow: var(--shadow-sm);
      transition: box-shadow 0.2s ease, background-color 0.3s ease, border-color 0.3s ease;
    }}
    .card:hover {{ box-shadow: var(--shadow-md); }}
    .header-top {{
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 12px; flex-wrap: wrap; gap: 16px;
    }}
    h1, h2, h3 {{ margin-top: 0; color: var(--text-main); }}
    h1 {{ font-size: 1.5rem; font-weight: 700; margin: 0; }}
    h2 {{ font-size: 1.25rem; font-weight: 600; margin-bottom: 20px; border-bottom: 1px solid var(--border-color); padding-bottom: 12px; }}
    .header-info {{
      display: flex; flex-wrap: wrap; gap: 16px;
      color: var(--text-muted); font-size: 0.9rem;
    }}
    .header-info p {{
      margin: 0; background: var(--bg-alt); padding: 6px 12px;
      border-radius: 6px; border: 1px solid var(--border-color);
    }}
    .header-info strong {{ color: var(--text-main); }}
    .controls-grid {{
      display: grid; grid-template-columns: 1fr; gap: 20px; margin-bottom: 24px;
      background: var(--bg-alt); padding: 16px; border-radius: 8px;
      border: 1px solid var(--border-color);
    }}
    @media (min-width: 768px) {{ .controls-grid {{ grid-template-columns: 2fr 1fr; align-items: end; }} }}
    .legend-group {{ display: flex; flex-direction: column; gap: 12px; }}
    .legend-heading {{
      margin: 0; font-size: 0.85rem; text-transform: uppercase;
      letter-spacing: 0.05em; color: var(--text-muted); font-weight: 700;
    }}
    .legend-row, .assignee-legend {{
      display: flex; flex-wrap: wrap; gap: 12px;
      list-style: none; padding: 0; margin: 0;
    }}
    .legend-item {{
      display: inline-flex; align-items: center; gap: 8px; font-size: 0.85rem;
      background: var(--bg-card); padding: 4px 10px; border-radius: 20px;
      border: 1px solid var(--border-color); box-shadow: 0 1px 2px rgba(0,0,0,0.02);
      font-weight: 500;
    }}
    .legend-swatch {{ width: 14px; height: 14px; border-radius: 50%; flex-shrink: 0; }}
    .assignee-legend li {{
      display: inline-flex; align-items: center;
      background: var(--assignee-bg); color: var(--assignee-text);
      padding: 4px 10px; border-radius: 6px; font-size: 0.85rem; font-weight: 500;
    }}
    .filter-wrapper {{ display: flex; flex-direction: column; gap: 8px; }}
    .filter-wrapper label {{
      font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.05em;
      color: var(--text-muted); font-weight: 700;
    }}
    .filter-wrapper select {{
      padding: 10px 14px; border: 1px solid var(--border-color); border-radius: 8px;
      font-size: 0.95rem; background: var(--bg-card); color: var(--text-main);
      cursor: pointer; outline: none; transition: border-color 0.2s; width: 100%;
    }}
    .filter-wrapper select:focus {{
      border-color: var(--primary); box-shadow: 0 0 0 3px rgba(59,130,246,0.1);
    }}
    .gantt-scroll-container {{
      width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;
      border: 1px solid var(--border-color); border-radius: 8px;
      background: var(--bg-card); box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);
    }}
    .gantt-scroll-container::-webkit-scrollbar {{ height: 10px; }}
    .gantt-scroll-container::-webkit-scrollbar-track {{ background: var(--bg-alt); border-radius: 0 0 8px 8px; }}
    .gantt-scroll-container::-webkit-scrollbar-thumb {{ background: var(--border-color); border-radius: 8px; }}
    .gantt-scroll-container::-webkit-scrollbar-thumb:hover {{ background: var(--text-muted); }}
    .gantt-inner {{ display: inline-block; vertical-align: top; box-sizing: border-box; padding: 16px; }}
    .gantt-scroll-container .gantt-inner svg {{ max-width: none !important; }}
    .validation-section h3 {{ font-size: 1rem; margin-top: 24px; margin-bottom: 12px; color: var(--text-main); }}
    .validation-list {{ list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 8px; }}
    .alert {{
      padding: 12px 16px; border-radius: 8px; font-size: 0.9rem;
      display: flex; align-items: flex-start; border: 1px solid transparent;
    }}
    .error {{ color: var(--err-text); background: var(--err-bg); border-color: var(--err-border); }}
    .warning {{ color: var(--warn-text); background: var(--warn-bg); border-color: var(--warn-border); }}
    .ok {{ color: var(--ok-text); background: var(--ok-bg); border-color: var(--ok-border); }}
    .alert code {{
      background: rgba(0,0,0,0.1); padding: 2px 6px; border-radius: 4px;
      font-family: monospace; font-size: 0.85em; color: var(--text-main);
    }}
    /* Pastel Mermaid overrides */
    .mermaid .task0, .mermaid .task1, .mermaid .task2, .mermaid .task3 {{ fill: #e2e8f0 !important; stroke: #94a3b8 !important; }}
    .mermaid .taskText0, .mermaid .taskText1, .mermaid .taskText2, .mermaid .taskText3 {{ fill: #1e293b !important; font-weight: 500 !important; }}
    .mermaid .done0, .mermaid .done1, .mermaid .done2, .mermaid .done3 {{ fill: #bbf7d0 !important; stroke: #4ade80 !important; }}
    .mermaid .doneText0, .mermaid .doneText1, .mermaid .doneText2, .mermaid .doneText3 {{ fill: #14532d !important; font-weight: 500 !important; }}
    .mermaid .active0, .mermaid .active1, .mermaid .active2, .mermaid .active3 {{ fill: #bae6fd !important; stroke: #7dd3fc !important; }}
    .mermaid .activeText0, .mermaid .activeText1, .mermaid .activeText2, .mermaid .activeText3 {{ fill: #0c4a6e !important; font-weight: 500 !important; }}
    .mermaid .crit0, .mermaid .crit1, .mermaid .crit2, .mermaid .crit3 {{ fill: #fef3c7 !important; stroke: #fde047 !important; }}
    .mermaid .critText0, .mermaid .critText1, .mermaid .critText2, .mermaid .critText3 {{ fill: #713f12 !important; font-weight: 500 !important; }}
    .mermaid .activeCrit0, .mermaid .activeCrit1, .mermaid .activeCrit2, .mermaid .activeCrit3 {{ fill: #fecaca !important; stroke: #fca5a5 !important; }}
    .mermaid .activeCritText0, .mermaid .activeCritText1, .mermaid .activeCritText2, .mermaid .activeCritText3 {{ fill: #7f1d1d !important; font-weight: 500 !important; }}
    /* Dark mode Mermaid corrections are injected into SVG <style> via JS (patchSvgDarkMode) */
  </style>
</head>
<body>
  <div class="page-layout">
    <aside class="sidebar">
      <div class="sidebar-header">
        <p class="sidebar-title" style="margin:0">Navigation</p>
        <button id="theme-toggle" class="theme-toggle" aria-label="Toggle Theme">&#9790;</button>
      </div>
      <nav>
        <a href="#" data-section="section-gantt" class="active"><span class="nav-icon">&#9866;</span> Gantt Chart</a>
        <a href="#" data-section="section-validation"><span class="nav-icon">&#9888;</span> Validation</a>
      </nav>
    </aside>
    <div class="main-content">
    <div class="container">
    <div class="card">
      <div class="header-top">
        <h1>{page_title}</h1>
      </div>
      {metadata_html}
    </div>
    <div id="section-gantt" class="section active card">
      <h2>Gantt Chart</h2>
      <div class="controls-grid">
        <div class="legend-group">
          {_render_legend()}
          {assignee_legend_html}
        </div>
        <div class="filter-wrapper">
          <label for="assignee-filter">Filter by Assignee</label>
          <select id="assignee-filter">
            <option value="">Show All</option>
          </select>
        </div>
      </div>
      <div class="gantt-scroll-container">
        <div class="gantt-inner" style="min-width: {gantt_use_width}px;">
          <pre class="mermaid">{escape(mermaid_syntax)}</pre>
        </div>
      </div>
    </div>
    <div id="section-validation" class="section card validation-section">
      <h2>Validation Report</h2>
      <h3>Errors ({len(validation_report.errors)})</h3>
      <ul class="validation-list">{errors_html}</ul>
      <h3>Warnings ({len(validation_report.warnings)})</h3>
      <ul class="validation-list">{warnings_html}</ul>
    </div>
  </div>
  </div>
  </div>
  <script id="gantt-tasks-data" type="application/json">{tasks_json}</script>
  <script id="assignee-legend-data" type="application/json">{assignee_legend_json}</script>
  <script>
    const themeToggleBtn = document.getElementById('theme-toggle');
    const savedTheme = localStorage.getItem('dspot-theme') || 'light';
    if (savedTheme === 'dark') {{
      document.body.classList.add('dark-mode');
      themeToggleBtn.innerHTML = '&#9788;';
    }}
    themeToggleBtn.addEventListener('click', () => {{
      document.body.classList.toggle('dark-mode');
      const isDark = document.body.classList.contains('dark-mode');
      themeToggleBtn.innerHTML = isDark ? '&#9788;' : '&#9790;';
      localStorage.setItem('dspot-theme', isDark ? 'dark' : 'light');
    }});
    // Menu section switching
    const navLinks = document.querySelectorAll('.sidebar nav a[data-section]');
    navLinks.forEach(link => {{
      link.addEventListener('click', (e) => {{
        e.preventDefault();
        const targetId = link.dataset.section;
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.getElementById(targetId).classList.add('active');
        navLinks.forEach(a => a.classList.remove('active'));
        link.classList.add('active');
        window.scrollTo(0, 0);
      }});
    }});
  </script>
  <script type="module">
    import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs';

    const GANTT_USE_WIDTH = {gantt_use_width};
    const GANTT_TITLE = {json.dumps(str(metadata.get("title", "Project Gantt Chart")))};

    mermaid.initialize({{
      startOnLoad: false,
      theme: 'default',
      securityLevel: 'loose',
      useMaxWidth: false,
      gantt: {{ useWidth: GANTT_USE_WIDTH }}
    }});

    const allTasks = JSON.parse(document.getElementById('gantt-tasks-data').textContent);
    const mermaidEl = document.querySelector('.mermaid');
    const ganttInner = document.querySelector('.gantt-inner');
    const originalSyntax = mermaidEl.textContent;

    const select = document.getElementById('assignee-filter');
    const legendMap = JSON.parse(document.getElementById('assignee-legend-data').textContent);
    const assignees = [...new Set(allTasks.map(t => t.assignee).filter(Boolean))].sort();
    assignees.forEach(a => {{
      const opt = document.createElement('option');
      opt.value = a;
      const displayName = legendMap[a] || a;
      opt.textContent = '[' + a + '] ' + displayName;
      select.appendChild(opt);
    }});

    function formatDateRange(startStr, endStr) {{
      const s = new Date(startStr + 'T00:00:00');
      const e = new Date(endStr + 'T00:00:00');
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      if (s.getFullYear() === e.getFullYear() && s.getMonth() === e.getMonth()) {{
        return months[s.getMonth()] + ' ' + String(s.getDate()).padStart(2,'0') + ' - ' + String(e.getDate()).padStart(2,'0');
      }}
      return months[s.getMonth()] + ' ' + String(s.getDate()).padStart(2,'0') + ' - ' + months[e.getMonth()] + ' ' + String(e.getDate()).padStart(2,'0');
    }}

    function buildMermaid(tasks) {{
      const lines = [
        'gantt',
        '    title ' + GANTT_TITLE,
        '    dateFormat YYYY-MM-DD',
        '    axisFormat %d %b',
        '    tickInterval 1day',
      ];
      const grouped = {{}};
      tasks.forEach(t => {{
        if (!grouped[t.section]) grouped[t.section] = [];
        grouped[t.section].push(t);
      }});
      for (const section of Object.keys(grouped)) {{
        const sectionTasks = grouped[section].sort((a, b) => a.end_date.localeCompare(b.end_date) || a.start_date.localeCompare(b.start_date));
        lines.push('');
        lines.push('    section ' + section);
        for (const t of sectionTasks) {{
          let title = formatDateRange(t.start_date, t.end_date) + ' | ' + t.name;
          if (t.assignee) title += ' [' + t.assignee + ']';
          title += ' (' + t.progress + '%)';
          const parts = [];
          if (t.status) {{
            t.status.split(',').forEach(s => {{
              const mod = s.trim().toLowerCase();
              if (['done','active','crit'].includes(mod)) parts.push(mod);
            }});
          }}
          parts.push(t.task_id);
          parts.push(t.start_date);
          parts.push(t.end_date);
          lines.push('    ' + title + ' :' + parts.join(', '));
        }}
      }}
      return lines.join('\\n');
    }}

    function patchSvgDarkMode() {{
      const svgStyle = mermaidEl.querySelector('svg style');
      if (!svgStyle) return;
      const marker = '/* dark-mode-patch */';
      if (svgStyle.textContent.includes(marker)) return;
      const svgEl = mermaidEl.querySelector('svg');
      const svgId = svgEl ? svgEl.id : '';
      const prefix = svgId ? '#' + svgId + ' ' : '';
      const rules = [marker];
      rules.push('body.dark-mode ' + prefix + 'text{{fill:#f8fafc!important;}}');
      rules.push('body.dark-mode ' + prefix + '.grid .tick line,body.dark-mode ' + prefix + '.grid path{{stroke:#475569!important;}}');
      rules.push('body.dark-mode ' + prefix + '.taskTextOutsideRight,body.dark-mode ' + prefix + '.taskTextOutsideLeft{{fill:#f8fafc!important;}}');
      rules.push('body.dark-mode ' + prefix + '.todayMarker{{stroke:#3b82f6!important;}}');
      svgStyle.textContent += rules.join('\\n');
    }}

    let renderCounter = 0;

    async function renderGantt(syntax) {{
      renderCounter++;
      const id = 'gantt-render-' + renderCounter;
      try {{
        const {{ svg }} = await mermaid.render(id, syntax);
        mermaidEl.innerHTML = svg;
        patchSvgDarkMode();
      }} catch (err) {{
        mermaidEl.innerHTML = '<p style="color:var(--err-text);">Render error: ' + err.message + '</p>';
      }}
    }}

    await renderGantt(originalSyntax);

    select.addEventListener('change', async () => {{
      const val = select.value;
      if (!val) {{
        await renderGantt(originalSyntax);
        return;
      }}
      const filtered = allTasks.filter(t => t.assignee && t.assignee.split('/').includes(val));
      if (!filtered.length) {{
        mermaidEl.innerHTML = '<p style="padding:16px;color:var(--text-main);">No tasks for this assignee.</p>';
        return;
      }}
      const syntax = buildMermaid(filtered);
      await renderGantt(syntax);
    }});
  </script>
</body>
</html>
"""


def save_html(html_content: str, output_path: str) -> Path:
    """Persist rendered HTML to disk and return resolved path."""
    output = Path(output_path).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_content, encoding="utf-8")
    return output

