"""Shared data models for Trello -> Gantt pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional


@dataclass
class ValidationItem:
    """Single validation message with context."""

    severity: str  # "error" | "warning"
    message: str
    card_reference: Optional[str] = None


@dataclass
class GanttTask:
    """Canonical task model consumed by downstream generators."""

    task_id: str
    name: str
    section: str
    start_date: date
    end_date: date
    status: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)
    source_card_id: str = ""
    source_list_id: str = ""
    source_url: Optional[str] = None
    assignee: Optional[str] = None
    progress: int = 0
    used_due_fallback: bool = False
    was_name_truncated: bool = False
    warnings: List[str] = field(default_factory=list)


@dataclass
class ValidationReport:
    """Validation output for mapped tasks."""

    errors: List[ValidationItem] = field(default_factory=list)
    warnings: List[ValidationItem] = field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        return len(self.errors) > 0

