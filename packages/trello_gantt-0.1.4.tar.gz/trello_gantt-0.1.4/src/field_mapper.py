"""Map Trello cards into GanttTask models."""

from __future__ import annotations

import re
from collections import OrderedDict
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .models import GanttTask


SECTION_NO_MILESTONE = "No Milestone"

MERMAID_RESERVED_KEYWORDS = {
    "gantt",
    "section",
    "title",
    "dateformat",
    "axisformat",
    "tickinterval",
    "excludes",
    "includes",
    "todaymarker",
    "click",
    "topaxis",
    "inclusiveenddates",
    "acctitle",
    "accdescr",
    "vert",
    "weekend",
}


def _parse_iso_date(value: Optional[str]) -> Optional[date]:
    if not value:
        return None
    normalized = value.strip().replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized).date()
    except ValueError:
        return None


def _sanitize_mermaid_base(text: str) -> str:
    """Shared character cleanup for task/section names (Mermaid-safe)."""
    result = re.sub(r"[\n\r\t]", " ", text)
    result = result.replace(":", "-")
    result = result.replace(",", " ")
    result = result.replace('"', "'")
    result = result.replace(";", "")
    result = result.replace("#", "")
    return re.sub(r"  +", " ", result).strip()


def sanitize_task_name(name: str, max_length: int = 80) -> Tuple[str, bool]:
    """Sanitize Trello card title for Mermaid task names."""
    if not name:
        return "Untitled", False

    result = _sanitize_mermaid_base(name)

    truncated = False
    if len(result) > max_length:
        result = result[: max_length - 3].rstrip() + "..."
        truncated = True

    if not result:
        result = "Untitled"

    first = result.split()[0].casefold() if result.split() else ""
    if first in MERMAID_RESERVED_KEYWORDS:
        result = f'"{result}"'

    return result, truncated


def sanitize_section_name(name: str, max_length: int = 50) -> str:
    if not name:
        return "Untitled section"
    result = _sanitize_mermaid_base(name)
    if len(result) > max_length:
        result = result[: max_length - 3].rstrip() + "..."
    return result or "Untitled section"


def generate_task_id(card: Dict[str, Any], fallback_index: int = 0) -> str:
    raw = (
        card.get("shortLink")
        or card.get("id")
        or card.get("shortUrl")
        or f"idx-{fallback_index}"
    )
    safe = re.sub(r"[^a-zA-Z0-9_-]", "", str(raw))
    if not safe:
        safe = f"idx{fallback_index}"
    if not safe[0].isalpha():
        safe = f"t{safe}"
    return safe[:24]


def _derive_start_date(card: Dict[str, Any], end_date: date, processing_date: date) -> date:
    explicit_start = _parse_iso_date(card.get("start"))
    if explicit_start:
        return explicit_start

    return end_date - timedelta(days=1)


def _status_from_section(trello_list_name: str) -> Optional[str]:
    """Map Trello column to Mermaid status for bar color (see html_renderer palette)."""
    normalized = trello_list_name.strip().casefold()
    if normalized in {"done"}:
        return "done"  # green
    if normalized in {"doing", "in progress"}:
        return "active"  # blue
    if normalized in {"to do", "todo"}:
        return "crit"  # styled white in HTML (To Do)
    if normalized in {"blocked", "impedido", "on hold"}:
        # Mermaid has no "blocked" tag; active+crit → .activeCrit* in SVG, styled in HTML
        return "active,crit"
    # Backlog: no modifier -> default bar, styled gray in HTML
    if normalized in {"backlog"}:
        return None
    return None


def _initials_from_member(member: Dict[str, Any]) -> str:
    """Best-effort initials for a single member (no global uniqueness).

    Used when mapping one card without a board-level initials registry.
    """
    for cand in _initial_candidates(member):
        return cand[:4]
    return ""


def _initial_candidates(member: Dict[str, Any]) -> List[str]:
    """Ordered candidate codes; first free one wins in global assignment."""
    out: List[str] = []
    seen: set[str] = set()

    def add(raw: str) -> None:
        if not raw:
            return
        cleaned = re.sub(r"[^A-Za-z0-9]", "", raw)
        if not cleaned:
            return
        u = cleaned.upper()[:4]
        if u not in seen:
            seen.add(u)
            out.append(u)

    full = str(member.get("fullName") or "").strip()
    trello = str(member.get("initials") or "").strip()
    if full:
        parts = full.split()
        if len(parts) >= 2:
            add(parts[0][0] + parts[-1][0])
        else:
            token = parts[0]
            if len(token) >= 2:
                add(token[0] + token[-1])
                add(token[:2])
            else:
                add(token)
    uname = re.sub(r"[^a-zA-Z0-9]", "", str(member.get("username") or ""))
    if len(uname) >= 2:
        add(uname[:2])
    if trello:
        add(trello)
    return out


def _collect_members_from_cards(
    cards_by_list: Dict[str, Sequence[Dict[str, Any]]],
) -> "OrderedDict[str, Dict[str, Any]]":
    """All Trello members referenced on any card (id -> member dict, stable last-wins)."""
    out: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
    for cards in cards_by_list.values():
        for card in cards:
            members_raw = card.get("members")
            if not members_raw:
                continue
            for m in members_raw:
                if isinstance(m, dict) and m.get("id"):
                    out[str(m["id"])] = m
    return out


def _assign_initials_globally(member_by_id: Dict[str, Dict[str, Any]]) -> Dict[str, str]:
    """Pick a unique short code per member (avoids e.g. Yasman vs yania both as YA)."""
    if not member_by_id:
        return {}
    order = sorted(
        member_by_id.keys(),
        key=lambda mid: _display_name_from_member(member_by_id[mid]).casefold(),
    )
    used: set[str] = set()
    result: Dict[str, str] = {}

    for mid in order:
        chosen = ""
        for cand in _initial_candidates(member_by_id[mid]):
            if cand not in used:
                used.add(cand)
                chosen = cand
                break
        if not chosen:
            tail = re.sub(r"[^A-Z0-9]", "", mid.upper())[-3:] or "MBR"
            n = 0
            while True:
                suffix = f"{tail}{n}" if n else tail
                cu = suffix[-4:].upper()
                if cu not in used:
                    used.add(cu)
                    chosen = cu
                    break
                n += 1
        result[mid] = chosen
    return result


def _assignee_initials_from_card(
    card: Dict[str, Any],
    initials_by_id: Optional[Dict[str, str]] = None,
) -> Optional[str]:
    """Build assignee label like JG or JG/YN from Trello members (idMembers order)."""
    members_raw = card.get("members")
    if not members_raw:
        return None
    members_list = [m for m in members_raw if isinstance(m, dict)]
    if not members_list:
        return None

    by_id = {str(m.get("id", "")): m for m in members_list if m.get("id")}
    initials_list: List[str] = []
    id_order = [str(x) for x in (card.get("idMembers") or []) if x]
    if id_order:
        for mid in id_order:
            m = by_id.get(mid)
            if not m:
                continue
            ini = (initials_by_id or {}).get(mid) or _initials_from_member(m)
            if ini:
                initials_list.append(ini)
    else:
        for m in members_list:
            mid = str(m.get("id", ""))
            ini = (initials_by_id or {}).get(mid) if mid else ""
            if not ini:
                ini = _initials_from_member(m)
            if ini:
                initials_list.append(ini)

    if not initials_list:
        return None
    return "/".join(initials_list)


def _display_name_from_member(member: Dict[str, Any]) -> str:
    """Label for HTML legend (prefer Trello full name)."""
    full = str(member.get("fullName") or "").strip()
    if full:
        return full
    uname = str(member.get("username") or "").strip()
    if uname:
        return uname
    return "Member"


def parse_progress_from_description(desc: str) -> int:
    """Extract progress percentage from a ``## Progress`` section in the card description.

    Rules:
    - No section found → 0
    - Valid number (with or without '%') clamped to [0, 100]
    - Any non-numeric value → 0
    """
    if not desc:
        return 0
    match = re.search(r"^##\s+Progress\s*\n+(.+)", desc, re.MULTILINE | re.IGNORECASE)
    if not match:
        return 0
    raw = match.group(1).strip().rstrip("%").strip()
    try:
        value = int(raw)
    except ValueError:
        return 0
    if value < 0:
        return 0
    return min(value, 100)


def _extract_milestone_group(card: Dict[str, Any]) -> Optional[str]:
    """Return canonical milestone section name from labels, e.g. 'Milestone 2'."""
    labels = card.get("labels") or []
    for label in labels:
        name = str(label.get("name", "")).strip()
        match = re.search(r"milestone\s*(\d+)", name, flags=re.IGNORECASE)
        if match:
            return f"Milestone {match.group(1)}"
    return None


def map_card_to_gantt_task(
    card: Dict[str, Any],
    list_name: str,
    *,
    fallback_index: int = 0,
    processing_date: Optional[date] = None,
    force_milestone: bool = False,
    initials_by_id: Optional[Dict[str, str]] = None,
) -> Tuple[GanttTask, List[str]]:
    """Map one Trello card to GanttTask. Returns task + per-card warnings."""
    warnings: List[str] = []
    processing = processing_date or date.today()

    used_due_fallback = False
    due_date = _parse_iso_date(card.get("due"))
    if due_date is None:
        warnings.append(
            f"Card '{card.get('name', 'Untitled')}' has no due date; "
            "using next-day window from processing date for the chart."
        )
        due_date = processing + timedelta(days=1)
        used_due_fallback = True

    assignee = _assignee_initials_from_card(card, initials_by_id=initials_by_id)
    assignee_display_suffix = f" [{assignee}]" if assignee else ""
    name_max = 80 - len(assignee_display_suffix) if assignee else 80
    task_name, was_truncated = sanitize_task_name(
        card.get("name", "Untitled"), max_length=max(1, name_max)
    )
    milestone_group = _extract_milestone_group(card)
    section = sanitize_section_name(
        milestone_group if milestone_group else SECTION_NO_MILESTONE
    )
    task_id = generate_task_id(card, fallback_index=fallback_index)

    start = _derive_start_date(card, due_date, processing)
    if start > due_date:
        due_date = start + timedelta(days=1)
        warnings.append(
            f"Card '{card.get('name', 'Untitled')}' start after implied end; "
            "extended end date to keep a valid range."
        )

    progress = parse_progress_from_description(card.get("desc", ""))
    section_status = _status_from_section(list_name)
    status = "done" if bool(card.get("dueComplete")) else section_status

    task = GanttTask(
        task_id=task_id,
        name=task_name,
        section=section,
        start_date=start,
        end_date=due_date,
        status=status,
        dependencies=[],
        source_card_id=str(card.get("id", "")),
        source_list_id=str(card.get("idList", "")),
        source_url=card.get("shortUrl"),
        assignee=assignee,
        progress=progress,
        used_due_fallback=used_due_fallback,
        was_name_truncated=was_truncated,
        warnings=[],
    )

    if was_truncated:
        warnings.append(f"Task name was truncated for card '{card.get('name', 'Untitled')}'.")

    return task, warnings


def map_cards_to_gantt_tasks(
    cards_by_list: Dict[str, Sequence[Dict[str, Any]]],
    *,
    processing_date: Optional[date] = None,
    milestone_lists: Optional[Sequence[str]] = None,
) -> Tuple[List[GanttTask], List[str], Dict[str, int], List[Tuple[str, str]]]:
    """Map cards grouped by list into tasks, warnings, stats, and assignee legend rows.

    Legend rows are ``(initials, display_name)`` sorted by initials, one row per member
    that appears on at least one mapped card (deduped by Trello member id).
    """
    tasks: List[GanttTask] = []
    warnings: List[str] = []
    total_cards = 0
    missing_due = 0

    board_members = _collect_members_from_cards(cards_by_list)
    initials_by_id = _assign_initials_globally(board_members)
    assignee_legend = sorted(
        (
            (initials_by_id[mid], _display_name_from_member(m))
            for mid, m in board_members.items()
            if mid in initials_by_id
        ),
        key=lambda pair: (pair[0].lower(), pair[1].lower()),
    )

    milestone_lookup = {name.strip().casefold() for name in (milestone_lists or []) if name.strip()}
    idx = 1
    for list_name, cards in cards_by_list.items():
        is_milestone_list = list_name.strip().casefold() in milestone_lookup
        for card in cards:
            total_cards += 1
            task, card_warnings = map_card_to_gantt_task(
                card,
                list_name,
                fallback_index=idx,
                processing_date=processing_date,
                force_milestone=is_milestone_list,
                initials_by_id=initials_by_id,
            )
            idx += 1

            tasks.append(task)
            if task.used_due_fallback:
                missing_due += 1
            warnings.extend(card_warnings)

    stats = {
        "total_cards": total_cards,
        "mapped_tasks": len(tasks),
        "missing_due_cards": missing_due,
    }
    return tasks, warnings, stats, assignee_legend

