"""Validation utilities for mapped Gantt tasks."""

from __future__ import annotations

from typing import Dict, List, Optional

from .models import GanttTask, ValidationItem, ValidationReport


def validate_tasks(
    tasks: List[GanttTask],
    warnings_from_mapping: Optional[List[str]] = None,
    *,
    stats: Optional[Dict[str, int]] = None,
) -> ValidationReport:
    """Validate mapped tasks and produce categorized report."""
    report = ValidationReport()
    mapping_warnings = warnings_from_mapping or []
    stats = stats or {}

    for warning in mapping_warnings:
        report.warnings.append(ValidationItem(severity="warning", message=warning))

    if not tasks:
        report.errors.append(
            ValidationItem(
                severity="error",
                message="0 tasks with valid dates after mapping. Cannot generate Gantt.",
            )
        )
        return report

    seen_ids = set()
    for task in tasks:
        if task.end_date < task.start_date:
            report.errors.append(
                ValidationItem(
                    severity="error",
                    message=(
                        f"Task '{task.name}' has end_date earlier than start_date "
                        f"({task.start_date} > {task.end_date})."
                    ),
                    card_reference=task.source_card_id or task.task_id,
                )
            )

        if task.task_id in seen_ids:
            report.errors.append(
                ValidationItem(
                    severity="error",
                    message=f"Duplicate task_id detected: {task.task_id}.",
                    card_reference=task.source_card_id or task.task_id,
                )
            )
        seen_ids.add(task.task_id)

        if not task.assignee:
            report.warnings.append(
                ValidationItem(
                    severity="warning",
                    message=f"Card has no assignee: {task.name}",
                    card_reference=task.source_card_id or task.task_id,
                )
            )

        if task.was_name_truncated:
            report.warnings.append(
                ValidationItem(
                    severity="warning",
                    message=f"Task name was truncated: {task.name}",
                    card_reference=task.source_card_id or task.task_id,
                )
            )

    total_cards = int(stats.get("total_cards", 0))
    missing_due = int(stats.get("missing_due_cards", 0))
    if total_cards > 0:
        missing_ratio = missing_due / total_cards
        if missing_ratio > 0.5:
            report.warnings.append(
                ValidationItem(
                    severity="warning",
                    message=(
                        "Prominent warning: more than 50% of cards are missing due date "
                        f"({missing_due}/{total_cards})."
                    ),
                )
            )

    return report


def format_validation_report(report: ValidationReport) -> str:
    """Render ValidationReport as human-readable text."""
    lines: List[str] = []
    lines.append("Validation Report")
    lines.append("=================")
    lines.append(f"Errors: {len(report.errors)}")
    lines.append(f"Warnings: {len(report.warnings)}")

    if report.errors:
        lines.append("")
        lines.append("Errors")
        lines.append("------")
        for item in report.errors:
            ref = f" [{item.card_reference}]" if item.card_reference else ""
            lines.append(f"- {item.message}{ref}")

    if report.warnings:
        lines.append("")
        lines.append("Warnings")
        lines.append("--------")
        for item in report.warnings:
            ref = f" [{item.card_reference}]" if item.card_reference else ""
            lines.append(f"- {item.message}{ref}")

    return "\n".join(lines)

