"""Trello data extraction and list filtering utilities.

Self-contained module for AT-001-04:
- reads credentials from environment,
- fetches board lists/cards via Trello REST API,
- filters cards by user list names (case-insensitive),
- returns structured warnings instead of failing on recoverable issues.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import requests


TRELLO_BASE_URL = "https://api.trello.com/1"

_TRELLO_URL_PATTERN = re.compile(r"trello\.com/b/([a-zA-Z0-9]+)")


def parse_board_id(value: str) -> str:
    """Extract board short ID from a Trello URL or return the value as-is.

    Accepts:
      - https://trello.com/b/abc123/board-name
      - trello.com/b/abc123
      - abc123 (raw ID, returned unchanged)
    """
    value = value.strip()
    match = _TRELLO_URL_PATTERN.search(value)
    if match:
        return match.group(1)
    return value
REQUEST_TIMEOUT_SECONDS = 30


class TrelloDataError(Exception):
    """Base error for Trello data extraction failures."""


class TrelloAuthError(TrelloDataError):
    """Raised when Trello authentication fails."""


class TrelloBoardNotFoundError(TrelloDataError):
    """Raised when the requested board does not exist or is inaccessible."""


class TrelloApiError(TrelloDataError):
    """Raised for non-auth, non-not-found Trello API failures."""


@dataclass
class TrelloFetchResult:
    """Result object for cards extraction plus diagnostics."""

    cards_by_list: Dict[str, List[Dict[str, Any]]]
    matched_lists: List[Dict[str, str]]
    warnings: List[str] = field(default_factory=list)
    available_lists: List[str] = field(default_factory=list)


def _get_credentials(
    api_key: Optional[str] = None,
    api_token: Optional[str] = None,
) -> Tuple[str, str]:
    """Resolve credentials from args or environment."""
    resolved_key = api_key or os.getenv("TRELLO_API_KEY")
    resolved_token = api_token or os.getenv("TRELLO_API_TOKEN")

    if not resolved_key or not resolved_token:
        raise TrelloAuthError(
            "Missing Trello credentials. Set TRELLO_API_KEY and TRELLO_API_TOKEN."
        )
    return resolved_key, resolved_token


def _auth_params(api_key: str, api_token: str) -> Dict[str, str]:
    return {"key": api_key, "token": api_token}


def _parse_trello_error(response: requests.Response) -> TrelloDataError:
    """Map Trello HTTP responses to domain-specific errors."""
    status = response.status_code
    body = response.text.strip()
    body_lower = body.lower()

    if status in (401, 403):
        return TrelloAuthError("Trello authentication failed. Verify API key/token.")

    if status == 404:
        return TrelloBoardNotFoundError("Board not found or not accessible.")

    if status >= 400 and ("invalid key" in body_lower or "unauthorized" in body_lower):
        return TrelloAuthError("Trello authentication failed. Verify API key/token.")

    return TrelloApiError(f"Trello API request failed ({status}): {body or 'no details'}")


def _get(endpoint: str, params: Dict[str, Any]) -> Any:
    url = f"{TRELLO_BASE_URL}{endpoint}"
    try:
        response = requests.get(url, params=params, timeout=REQUEST_TIMEOUT_SECONDS)
    except requests.Timeout as exc:
        raise TrelloApiError("Trello API timeout after 30 seconds.") from exc
    except requests.RequestException as exc:
        raise TrelloApiError(f"Failed to reach Trello API: {exc}") from exc

    if response.ok:
        return response.json()

    raise _parse_trello_error(response)


def get_board_lists(
    board_id: str,
    *,
    api_key: Optional[str] = None,
    api_token: Optional[str] = None,
) -> List[Dict[str, str]]:
    """Return board open lists as [{'id': str, 'name': str}, ...]."""
    if not board_id:
        raise TrelloDataError("board_id is required.")

    key, token = _get_credentials(api_key, api_token)
    data = _get(
        f"/boards/{board_id}/lists",
        {**_auth_params(key, token), "fields": "id,name,closed", "filter": "open"},
    )

    return [{"id": item["id"], "name": item["name"]} for item in data if not item.get("closed")]


def get_board_name(
    board_id: str,
    *,
    api_key: Optional[str] = None,
    api_token: Optional[str] = None,
) -> str:
    """Return the board display name, or ``board_id`` if the API returns no name."""
    if not board_id:
        raise TrelloDataError("board_id is required.")

    key, token = _get_credentials(api_key, api_token)
    data = _get(
        f"/boards/{board_id}",
        {**_auth_params(key, token), "fields": "name"},
    )
    name = data.get("name")
    return str(name).strip() if name else board_id


def _normalize_name(value: str) -> str:
    return value.strip().casefold()


def _build_lists_lookup(board_lists: Sequence[Dict[str, str]]) -> Dict[str, Dict[str, str]]:
    """Build normalized-name -> list metadata lookup."""
    lookup: Dict[str, Dict[str, str]] = {}
    for item in board_lists:
        name = item.get("name", "")
        if name:
            lookup[_normalize_name(name)] = {"id": item["id"], "name": name}
    return lookup


def get_cards_for_lists(
    board_id: str,
    list_names: Optional[Sequence[str]] = None,
    *,
    api_key: Optional[str] = None,
    api_token: Optional[str] = None,
) -> TrelloFetchResult:
    """Fetch cards grouped by list name, optionally filtered by list_names."""
    if not board_id:
        raise TrelloDataError("board_id is required.")

    board_lists = get_board_lists(board_id, api_key=api_key, api_token=api_token)

    if not board_lists:
        return TrelloFetchResult(
            cards_by_list={},
            matched_lists=[],
            warnings=["Board has no open lists."],
            available_lists=[],
        )

    available_list_names = [item["name"] for item in board_lists]
    lookup = _build_lists_lookup(board_lists)
    warnings: List[str] = []

    requested = [name for name in (list_names or []) if name and name.strip()]
    if requested:
        matched_lists: List[Dict[str, str]] = []
        missing: List[str] = []
        for name in requested:
            found = lookup.get(_normalize_name(name))
            if found:
                matched_lists.append(found)
            else:
                missing.append(name)

        if missing:
            warnings.append(
                "Requested lists not found: "
                + ", ".join(sorted(set(missing)))
                + ". Available lists: "
                + ", ".join(available_list_names)
            )
    else:
        matched_lists = board_lists

    if not matched_lists:
        return TrelloFetchResult(
            cards_by_list={},
            matched_lists=[],
            warnings=warnings,
            available_lists=available_list_names,
        )

    key, token = _get_credentials(api_key, api_token)
    cards = _get(
        f"/boards/{board_id}/cards",
        {
            **_auth_params(key, token),
            "filter": "open",
            "fields": "id,name,idList,idMembers,shortUrl,start,due,dueComplete,dateLastActivity,labels,pos,desc",
            "members": "true",
            "member_fields": "initials,fullName",
        },
    )

    allowed_list_ids = {item["id"] for item in matched_lists}
    grouped: Dict[str, List[Dict[str, Any]]] = {item["name"]: [] for item in matched_lists}
    list_name_by_id = {item["id"]: item["name"] for item in matched_lists}

    for card in cards:
        list_id = card.get("idList")
        if list_id in allowed_list_ids:
            grouped[list_name_by_id[list_id]].append(card)

    empty_lists = [name for name, cards_in_list in grouped.items() if not cards_in_list]
    if empty_lists:
        warnings.append("Lists with zero cards: " + ", ".join(empty_lists))

    if not any(grouped.values()):
        warnings.append("No cards found for selected lists.")

    return TrelloFetchResult(
        cards_by_list=grouped,
        matched_lists=matched_lists,
        warnings=warnings,
        available_lists=available_list_names,
    )

