"""Layout detection utilities.

"""

