"""Tests for utility functions."""

from pathlib import Path

import pytest

from audio_transcode_watcher.utils import (
    appears_empty_dir,
    get_output_file_path,
    get_output_filename,
    get_rel_stem,
    has_audio_extension,
    has_sidecar_extension,
    is_audio_file,
    is_lossless,
    is_mp3,
    nfc,
    nfc_path,
    remove_empty_dirs,
    walk_audio_files,
)


class TestNfc:
    """Tests for NFC normalization."""
    
    def test_normalizes_to_nfc(self):
        """Test that strings are normalized to NFC."""
        # NFD representation of "é" (e + combining acute accent)
        nfd_string = "e\u0301"
        # NFC representation of "é" (single character)
        nfc_string = "é"
        
        assert nfc(nfd_string) == nfc_string
    
    def test_already_nfc_unchanged(self):
        """Test that NFC strings are unchanged."""
        nfc_string = "Sigur Rós"
        assert nfc(nfc_string) == nfc_string
    
    def test_ascii_unchanged(self):
        """Test that ASCII strings are unchanged."""
        ascii_string = "Artist - Song"
        assert nfc(ascii_string) == ascii_string


class TestNfcPath:
    """Tests for NFC path normalization."""
    
    def test_normalizes_path_components(self):
        """Test that path components are normalized."""
        # Path with NFD filename
        nfd_path = "/music/Sigur Ro\u0301s/song.flac"
        result = nfc_path(nfd_path)
        
        # Should be NFC normalized
        assert "Sigur Rós" in result
    
    def test_preserves_absolute_path(self):
        """Test that absolute paths remain absolute."""
        path = "/music/artist/song.flac"
        result = nfc_path(path)
        assert result.startswith("/")
    
    def test_handles_empty_path(self):
        """Test handling of empty path."""
        assert nfc_path("") == ""


class TestHasAudioExtension:
    """Tests for has_audio_extension function (no file existence check)."""
    
    def test_flac_extension(self):
        """Test that .flac extension is recognized."""
        assert has_audio_extension("/music/Artist - Song.flac") is True
    
    def test_mp3_extension(self):
        """Test that .mp3 extension is recognized."""
        assert has_audio_extension("/music/Artist - Song.mp3") is True
    
    def test_m4a_extension(self):
        """Test that .m4a extension is recognized."""
        assert has_audio_extension("/music/Artist - Song.m4a") is True
    
    def test_nonexistent_file_still_recognized(self):
        """Test that a nonexistent path with audio extension returns True."""
        assert has_audio_extension("/nonexistent/path/Song.flac") is True
    
    def test_txt_extension_not_audio(self):
        """Test that .txt extension is not recognized."""
        assert has_audio_extension("/music/readme.txt") is False
    
    def test_case_insensitive(self):
        """Test that extension matching is case-insensitive."""
        assert has_audio_extension("/music/Song.FLAC") is True
    
    def test_no_extension(self):
        """Test that path without extension is not recognized."""
        assert has_audio_extension("/music/noext") is False


class TestHasSidecarExtension:
    """Tests for has_sidecar_extension function."""

    def test_lrc_is_sidecar(self):
        """Test that .lrc extension is recognized."""
        assert has_sidecar_extension("/music/Artist - Song.lrc") is True

    def test_flac_is_not_sidecar(self):
        """Test that .flac extension is not a sidecar."""
        assert has_sidecar_extension("/music/Artist - Song.flac") is False

    def test_txt_is_not_sidecar(self):
        """Test that .txt is not a sidecar."""
        assert has_sidecar_extension("/music/notes.txt") is False

    def test_case_insensitive(self):
        """Test that extension matching is case-insensitive."""
        assert has_sidecar_extension("/music/Song.LRC") is True

    def test_nonexistent_path(self):
        """Test works on nonexistent paths."""
        assert has_sidecar_extension("/nonexistent/Song.lrc") is True


class TestIsAudioFile:
    """Tests for is_audio_file function."""
    
    def test_flac_is_audio(self, temp_dir):
        """Test that FLAC files are recognized."""
        flac = Path(temp_dir) / "test.flac"
        flac.touch()
        assert is_audio_file(str(flac)) is True
    
    def test_mp3_is_audio(self, temp_dir):
        """Test that MP3 files are recognized."""
        mp3 = Path(temp_dir) / "test.mp3"
        mp3.touch()
        assert is_audio_file(str(mp3)) is True
    
    def test_m4a_is_audio(self, temp_dir):
        """Test that M4A files are recognized."""
        m4a = Path(temp_dir) / "test.m4a"
        m4a.touch()
        assert is_audio_file(str(m4a)) is True
    
    def test_txt_is_not_audio(self, temp_dir):
        """Test that TXT files are not recognized."""
        txt = Path(temp_dir) / "test.txt"
        txt.touch()
        assert is_audio_file(str(txt)) is False
    
    def test_nonexistent_is_not_audio(self, temp_dir):
        """Test that nonexistent files are not recognized."""
        assert is_audio_file(str(Path(temp_dir) / "nonexistent.flac")) is False
    
    def test_case_insensitive(self, temp_dir):
        """Test that extension matching is case-insensitive."""
        flac = Path(temp_dir) / "test.FLAC"
        flac.touch()
        assert is_audio_file(str(flac)) is True


class TestIsLossless:
    """Tests for is_lossless function."""
    
    def test_flac_is_lossless(self):
        """Test that FLAC is recognized as lossless."""
        assert is_lossless("song.flac") is True
    
    def test_wav_is_lossless(self):
        """Test that WAV is recognized as lossless."""
        assert is_lossless("song.wav") is True
    
    def test_ape_is_lossless(self):
        """Test that APE is recognized as lossless."""
        assert is_lossless("song.ape") is True
    
    def test_mp3_is_not_lossless(self):
        """Test that MP3 is not recognized as lossless."""
        assert is_lossless("song.mp3") is False


class TestIsMp3:
    """Tests for is_mp3 function."""
    
    def test_mp3_is_mp3(self):
        """Test that .mp3 is recognized."""
        assert is_mp3("song.mp3") is True
    
    def test_mp3_case_insensitive(self):
        """Test that extension is case-insensitive."""
        assert is_mp3("song.MP3") is True
    
    def test_flac_is_not_mp3(self):
        """Test that FLAC is not recognized as MP3."""
        assert is_mp3("song.flac") is False


class TestAppearsEmptyDir:
    """Tests for appears_empty_dir function."""
    
    def test_empty_dir_is_empty(self, temp_dir):
        """Test that empty directory appears empty."""
        empty = Path(temp_dir) / "empty"
        empty.mkdir()
        assert appears_empty_dir(str(empty)) is True
    
    def test_dir_with_files_not_empty(self, temp_dir):
        """Test that directory with files doesn't appear empty."""
        with_files = Path(temp_dir) / "with_files"
        with_files.mkdir()
        (with_files / "file.txt").touch()
        assert appears_empty_dir(str(with_files)) is False
    
    def test_dir_with_hidden_only_is_empty(self, temp_dir):
        """Test that directory with only hidden files appears empty."""
        hidden_only = Path(temp_dir) / "hidden_only"
        hidden_only.mkdir()
        (hidden_only / ".hidden").touch()
        assert appears_empty_dir(str(hidden_only)) is True
    
    def test_nonexistent_dir_is_empty(self, temp_dir):
        """Test that nonexistent directory appears empty."""
        assert appears_empty_dir(str(Path(temp_dir) / "nonexistent")) is True


class TestGetOutputFilename:
    """Tests for get_output_filename function."""
    
    def test_replaces_extension(self):
        """Test that extension is replaced."""
        result = get_output_filename("Artist - Song.flac", ".m4a")
        assert result == "Artist - Song.m4a"
    
    def test_handles_unicode(self):
        """Test handling of Unicode filenames."""
        result = get_output_filename("Sigur Rós - Hoppípolla.flac", ".mp3")
        assert "Sigur Rós - Hoppípolla" in result
        assert result.endswith(".mp3")
    
    def test_normalizes_to_nfc(self):
        """Test that output filename is NFC normalized."""
        # NFD input
        nfd_name = "Cafe\u0301 Song.flac"
        result = get_output_filename(nfd_name, ".m4a")
        # Should be NFC
        assert result == "Café Song.m4a"


class TestGetOutputFilePath:
    """Tests for get_output_file_path function."""

    def test_flat_directory(self):
        """Test flat dir returns output_root/filename."""
        result = get_output_file_path(
            "/music/flac/song.flac", "/music/flac", "/music/mp3", "song.mp3",
        )
        assert result == "/music/mp3/song.mp3"

    def test_nested_directory(self):
        """Test nested dir preserves relative structure."""
        result = get_output_file_path(
            "/music/flac/album1/song.flac", "/music/flac", "/music/mp3", "song.mp3",
        )
        assert result == "/music/mp3/album1/song.mp3"

    def test_deeply_nested(self):
        """Test deeply nested structure."""
        result = get_output_file_path(
            "/music/flac/artist/album/song.flac",
            "/music/flac",
            "/music/mp3",
            "song.mp3",
        )
        assert result == "/music/mp3/artist/album/song.mp3"


class TestGetRelStem:
    """Tests for get_rel_stem function."""

    def test_flat(self):
        """Flat file returns just the stem."""
        assert get_rel_stem("/music/flac/song.flac", "/music/flac") == "song"

    def test_nested(self):
        """Nested file returns rel_dir/stem."""
        result = get_rel_stem("/music/flac/album1/song.flac", "/music/flac")
        assert result == "album1/song"

    def test_unicode_normalized(self):
        """Unicode stems are NFC-normalized."""
        result = get_rel_stem("/music/Cafe\u0301.flac", "/music")
        assert result == "Café"


class TestWalkAudioFiles:
    """Tests for walk_audio_files function."""

    def test_flat(self, temp_dir):
        """Finds files in flat directory."""
        (Path(temp_dir) / "a.flac").touch()
        (Path(temp_dir) / "b.mp3").touch()
        (Path(temp_dir) / "readme.txt").touch()
        result = walk_audio_files(temp_dir)
        assert len(result) == 2

    def test_recursive(self, temp_dir):
        """Finds files in nested directories."""
        sub = Path(temp_dir) / "album"
        sub.mkdir()
        (sub / "a.flac").touch()
        (Path(temp_dir) / "b.flac").touch()
        result = walk_audio_files(temp_dir)
        assert len(result) == 2

    def test_empty(self, temp_dir):
        """Returns empty list for empty directory."""
        assert walk_audio_files(temp_dir) == []


class TestRemoveEmptyDirs:
    """Tests for remove_empty_dirs function."""

    def test_removes_empty_subdirs(self, temp_dir):
        """Removes empty subdirectories."""
        sub = Path(temp_dir) / "empty"
        sub.mkdir()
        remove_empty_dirs(temp_dir)
        assert not sub.exists()

    def test_keeps_root(self, temp_dir):
        """Never removes root itself."""
        remove_empty_dirs(temp_dir)
        assert Path(temp_dir).exists()

    def test_keeps_non_empty_subdirs(self, temp_dir):
        """Keeps subdirectories that contain files."""
        sub = Path(temp_dir) / "has_files"
        sub.mkdir()
        (sub / "file.txt").touch()
        remove_empty_dirs(temp_dir)
        assert sub.exists()

    def test_nested_empty_cleanup(self, temp_dir):
        """Removes nested empty dirs bottom-up."""
        deep = Path(temp_dir) / "a" / "b" / "c"
        deep.mkdir(parents=True)
        remove_empty_dirs(temp_dir)
        assert not (Path(temp_dir) / "a").exists()
