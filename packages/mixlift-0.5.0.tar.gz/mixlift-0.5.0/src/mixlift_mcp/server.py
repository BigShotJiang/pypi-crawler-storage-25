"""MixLift MCP Server — Marketing Mix Modeling for AI assistants.

Provides a single tool `mixlift_analyze` that runs full Bayesian MMM analysis
on marketing CSV data and returns ROAS, budget optimization, and saturation curves.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path

import pandas as pd
from mcp.server.fastmcp import Context, FastMCP

from mixlift_mcp.license import LicenseStatus, free_tier, validate_license

logger = logging.getLogger(__name__)

DEMO_CSV_PATH = Path(__file__).parent / "data" / "demo.csv"

mcp = FastMCP("mixlift")

# ---------------------------------------------------------------------------
# Model cache — persists fitted models within an MCP session for forecast/reuse
# ---------------------------------------------------------------------------

_MODEL_CACHE: dict[str, dict] = {}
# fingerprint -> {"mmm": MMM, "X": DataFrame, "channel_columns": list,
#                 "model_results": ModelResults, "result": dict}

# ---------------------------------------------------------------------------
# Path validation guardrails
# ---------------------------------------------------------------------------

#: File extensions that are allowed as CSV inputs.
_ALLOWED_EXTENSIONS = {".csv", ".tsv", ".txt"}

#: Path components that indicate sensitive locations. Checked against every
#: part of the resolved path (case-insensitive) so that tricks like
#: ``../../.ssh/id_rsa`` are caught after resolution.
_BLOCKED_PATH_FRAGMENTS = {
    ".ssh",
    ".env",
    ".git",
    "credentials",
    "secrets",
    ".aws",
    ".config",
    ".gnupg",
    ".gpg",
    "keychain",
    "id_rsa",
    "id_ed25519",
    "id_ecdsa",
    "id_dsa",
    "authorized_keys",
    "known_hosts",
}


def _validate_csv_path(csv_path: str) -> tuple[Path, str | None]:
    """Validate and resolve a user-supplied CSV path.

    Returns ``(resolved_path, None)`` on success, or ``(Path(), error_message)``
    on failure.

    Guardrails applied (in order):
    1. Extension must be in ``_ALLOWED_EXTENSIONS``.
    2. Resolved absolute path must not contain any ``_BLOCKED_PATH_FRAGMENTS``.
    3. If the environment variable ``MIXLIFT_ALLOWED_DIRS`` is set (colon-separated
       list of directories), the resolved path must fall within one of them.
    """
    resolved = Path(csv_path).expanduser().resolve()

    # 1. Extension check
    if resolved.suffix.lower() not in _ALLOWED_EXTENSIONS:
        return Path(), (
            f"Invalid file extension '{resolved.suffix}'. "
            f"Only {', '.join(sorted(_ALLOWED_EXTENSIONS))} files are allowed."
        )

    # 2. Sensitive-path check — inspect every part of the resolved path
    path_str_lower = str(resolved).lower()
    for fragment in _BLOCKED_PATH_FRAGMENTS:
        if fragment in path_str_lower:
            logger.warning("Blocked sensitive path access attempt: %s", resolved)
            return Path(), (
                f"Access denied: the path contains a restricted component ('{fragment}'). "
                "Please use a file outside sensitive system directories."
            )

    # 3. Allowed-directories check (opt-in via environment variable)
    allowed_dirs_env = os.environ.get("MIXLIFT_ALLOWED_DIRS", "").strip()
    if allowed_dirs_env:
        allowed_dirs = [
            Path(d).expanduser().resolve()
            for d in allowed_dirs_env.split(":")
            if d.strip()
        ]
        if not any(
            resolved == allowed or allowed in resolved.parents
            for allowed in allowed_dirs
        ):
            allowed_display = ", ".join(str(d) for d in allowed_dirs)
            logger.warning(
                "Blocked path outside allowed directories: %s (allowed: %s)",
                resolved,
                allowed_display,
            )
            return Path(), (
                f"Access denied: '{resolved}' is not inside an allowed directory. "
                f"Allowed directories: {allowed_display}"
            )

    logger.info("Resolved CSV path: %s", resolved)
    return resolved, None


# ---------------------------------------------------------------------------
# CSV loading helpers — canonical implementations live in mixlift.ingest.loader;
# private aliases kept here for backward compatibility within the MCP server.
# ---------------------------------------------------------------------------
from mixlift.ingest.loader import (
    detect_csv_format as _detect_csv_format,
    validate_wide_format as _validate_wide_format,
    check_date_range_warnings as _check_date_range_warnings,
    load_wide_format as _load_wide_format,
    load_platform_csv as _load_platform_csv,
)


def _enforce_tier_limits(
    license_status: LicenseStatus,
    n_channels: int,
    n_rows: int,
) -> list[str]:
    """Raise ValueError if data exceeds tier limits.

    Returns a list of warning strings (e.g. high channel count for Pro tier).
    """
    tier_name = "Pro" if license_status.is_pro else "Free"
    warnings: list[str] = []

    if n_channels > license_status.max_channels:
        raise ValueError(
            f"{tier_name} tier allows up to {license_status.max_channels} channels, "
            f"but your data has {n_channels}. "
            f"Upgrade to Growth ($299/mo) at https://mixlift.io/pricing"
        )
    if n_rows > license_status.max_rows:
        raise ValueError(
            f"{tier_name} tier allows up to {license_status.max_rows} rows, "
            f"but your data has {n_rows}. "
            f"Upgrade to Growth ($299/mo) at https://mixlift.io/pricing"
        )

    # A4: Soft warning for Pro tier with many channels
    if n_channels > 15:
        msg = (
            f"Your data has {n_channels} channels. Models with >15 channels "
            f"may produce less precise estimates with default MCMC settings. "
            f"Consider increasing draws/tune for better posterior quality."
        )
        logger.warning(msg)
        warnings.append(msg)

    return warnings


def _compute_saturation_traffic_lights(
    saturation_curves: dict,
    optimization: dict,
) -> dict:
    """Compute per-channel saturation percentage and traffic light status.

    Uses the saturation curve: at current spend, how far along the curve are we?
    - Green (< 50%): Room to scale
    - Yellow (50-75%): Approaching saturation
    - Red (> 75%): Diminishing returns
    """
    lights = {}
    current = optimization.get("current_allocation", {})

    for channel, curve_data in saturation_curves.items():
        spend_points = curve_data.get("spend", [])
        response_points = curve_data.get("response", [])
        if not spend_points or not response_points:
            continue

        current_spend = current.get(channel, 0)
        max_response = max(response_points) if response_points else 1.0

        # Find response at current spend by interpolation
        import bisect
        idx = bisect.bisect_left(spend_points, current_spend)
        if idx >= len(response_points):
            current_response = response_points[-1]
        elif idx == 0:
            current_response = response_points[0]
        else:
            # Linear interpolation
            x0, x1 = spend_points[idx - 1], spend_points[idx]
            y0, y1 = response_points[idx - 1], response_points[idx]
            t = (current_spend - x0) / (x1 - x0) if x1 != x0 else 0
            current_response = y0 + t * (y1 - y0)

        saturation_pct = round((current_response / max_response) * 100, 0) if max_response > 0 else 0

        if saturation_pct < 50:
            status = "green"
            label = f"{channel} has {100 - saturation_pct:.0f}% headroom (room to scale)"
        elif saturation_pct < 75:
            status = "yellow"
            label = f"{channel} is {saturation_pct:.0f}% saturated (approaching diminishing returns)"
        else:
            status = "red"
            label = f"{channel} is {saturation_pct:.0f}% saturated (diminishing returns)"

        lights[channel] = {
            "saturation_pct": saturation_pct,
            "status": status,
            "label": label,
        }

    return lights


def _redact_dollars(text: str) -> str:
    """Strip dollar amounts from text for free-tier output."""
    import re
    return re.sub(r'\$[\d,]+(?:\.\d+)?(?:/week)?', '$XXX', text)


def _compute_dollar_headline(optimization: dict) -> dict:
    """Compute the dollar-value headline from budget optimization results.

    Returns headline data. Dollar values only shown to paid tier.
    """
    current = optimization.get("current_allocation", {})
    optimal = optimization.get("optimal_allocation", {})
    lift_pct = optimization.get("expected_lift_pct", 0)
    total_budget = optimization.get("total_budget", 0)

    # Total dollar opportunity = lift percentage applied to total budget
    dollar_opportunity = round(total_budget * abs(lift_pct) / 100, 0)

    # Per-channel reallocation in dollars and percentages
    reallocations = []
    for channel in current:
        curr = current.get(channel, 0)
        opt = optimal.get(channel, 0)
        delta = opt - curr
        if abs(delta) > 1:  # Ignore trivial changes
            pct_change = round((delta / curr) * 100, 1) if curr > 0 else 0
            action = "Increase" if delta > 0 else "Decrease"
            reallocations.append({
                "channel": channel,
                "action": action,
                "current_spend": round(curr, 0),
                "optimal_spend": round(opt, 0),
                "change_dollars": round(abs(delta), 0),
                "change_pct": abs(pct_change),
                "label": f"{action} {channel} by ${abs(delta):,.0f}/week ({abs(pct_change):.0f}%)",
            })

    reallocations.sort(key=lambda x: x["change_dollars"], reverse=True)

    return {
        "dollar_opportunity": dollar_opportunity,
        "lift_pct": lift_pct,
        "headline": f"MixLift found ${dollar_opportunity:,.0f}/week in budget optimization opportunity ({lift_pct:+.1f}% expected lift)",
        "reallocations": reallocations,
    }


def _compute_confidence_summary(model_results) -> dict:
    """Generate plain-English confidence summary."""
    ci_widths = {}
    for channel, ci in model_results.roas_ci.items():
        width = ci[1] - ci[0]
        mean = model_results.roas_estimates.get(channel, 1)
        relative_width = width / mean if mean > 0 else float("inf")
        ci_widths[channel] = relative_width

    summaries = {}
    for channel, rel_width in ci_widths.items():
        if rel_width < 0.5:
            summaries[channel] = {
                "confidence": "high",
                "label": f"{channel}: High confidence (tight uncertainty bounds)",
            }
        elif rel_width < 1.0:
            summaries[channel] = {
                "confidence": "moderate",
                "label": f"{channel}: Moderate confidence (consider more data for precision)",
            }
        else:
            summaries[channel] = {
                "confidence": "low",
                "label": f"{channel}: Use with caution (wide uncertainty — more data recommended)",
            }

    return summaries


def _compute_model_fit(model_results) -> dict:
    """Compute model fit summary: R-squared and MAPE equivalent."""
    import numpy as np

    try:
        mmm = model_results.mmm
        idata = mmm.idata

        # Posterior predictive mean
        if hasattr(idata, "posterior_predictive"):
            pp = idata.posterior_predictive
            # Get the target variable name
            var_names = list(pp.data_vars)
            if var_names:
                y_pred = pp[var_names[0]].mean(dim=["chain", "draw"]).values
                y_actual = mmm.y.values if hasattr(mmm, "y") else None

                if y_actual is not None and len(y_pred) == len(y_actual):
                    ss_res = np.sum((y_actual - y_pred) ** 2)
                    ss_tot = np.sum((y_actual - np.mean(y_actual)) ** 2)
                    r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0

                    mape = np.mean(np.abs((y_actual - y_pred) / y_actual)) * 100 if np.all(y_actual != 0) else None

                    r2_pct = round(r_squared * 100, 0)
                    return {
                        "r_squared": round(r_squared, 3),
                        "mape": round(mape, 1) if mape is not None else None,
                        "label": f"This model explains {r2_pct:.0f}% of your revenue variation.",
                    }
    except Exception:
        pass

    return {"label": "Model fit metrics not available for this run."}


def _build_tiered_response(result: dict) -> dict:
    """Build a tiered response for Claude: summary + structured_data.

    The summary tier (~2-4K chars) contains everything Claude needs to
    start an intelligent conversation. The structured_data tier contains
    full details Claude can reference on demand.
    """
    roas = result.get("roas", {})
    roas_estimates = roas.get("estimates", {})
    saturation = result.get("saturation_analysis", {})
    confidence = result.get("confidence_summary", {})
    budget_opt = result.get("budget_optimization", {})
    recommendations = result.get("recommendations", {})
    actions = recommendations.get("actions", [])

    # Build per-channel overview for summary (condensed)
    channel_overview = {}
    for ch in result.get("data", {}).get("channels", []):
        entry: dict = {}
        if ch in roas_estimates:
            entry["roas"] = round(roas_estimates[ch], 2)
        sat_info = saturation.get(ch, {})
        if sat_info:
            entry["saturation"] = sat_info.get("status", "unknown")
        conf_info = confidence.get(ch, {})
        if conf_info:
            entry["confidence"] = conf_info.get("confidence", "unknown")
        channel_overview[ch] = entry

    return {
        "status": result.get("status", "success"),
        "model_fingerprint": result.get("model_fingerprint", ""),
        "summary": {
            "headline": result.get("headline", ""),
            "top_actions": actions[:3],
            "channel_overview": channel_overview,
            "model_fit": result.get("model_fit", {}),
            "expected_lift_pct": budget_opt.get("expected_lift_pct", 0),
            "total_budget": budget_opt.get("total_budget", 0),
            "n_channels": result.get("data", {}).get("n_channels", 0),
            "data_weeks": result.get("model_info", {}).get("data_window", {}).get("weeks"),
            "analysis_badge": result.get("analysis_badge"),
            "memory": result.get("memory"),
            "next_actions": [
                {
                    "tool": "mixlift_scenario",
                    "description": "Test a what-if budget change (e.g., 'cut Meta by 20%')",
                    "params": {"model_fingerprint": result.get("model_fingerprint", "")},
                },
                {
                    "tool": "mixlift_forecast",
                    "description": "Project revenue over next 12 weeks (current vs optimized)",
                    "params": {"model_fingerprint": result.get("model_fingerprint", "")},
                },
                {
                    "tool": "mixlift_readout",
                    "description": "Generate executive deliverables (budget memo, scorecard)",
                    "params": {"model_fingerprint": result.get("model_fingerprint", "")},
                },
            ],
            "intake_questions": [
                "What budget decision are you trying to make right now?",
                "Which channel is your biggest bet — and are you confident in it?",
                "Are you looking to scale up spend or find waste to cut?",
            ],
        },
        "structured_data": {
            "roas": roas,
            "saturation_analysis": saturation,
            "budget_optimization": budget_opt,
            "channel_contributions": result.get("channel_contributions", {}),
            "marginal_roas": result.get("marginal_roas", {}),
            "recommendations": recommendations,
            "confidence_summary": confidence,
            "scenario": result.get("scenario"),
        },
        "license": result.get("license", {}),
        "model_info": result.get("model_info", {}),
        "data": result.get("data", {}),
    }


def _build_result(
    model_results,
    optimization: dict,
    saturation_curves: dict,
    channel_columns: list[str],
    license_status: LicenseStatus,
    csv_format: str,
    tier_warnings: list[str] | None = None,
    data_weeks: float = 52,
) -> dict:
    """Build the final result dictionary."""
    from mixlift.modeling.recommendations import (
        generate_recommendations,
        format_all_recommendations,
    )

    # Generate recommendations
    recommendations, summary = generate_recommendations(
        current_allocation=optimization["current_allocation"],
        optimal_allocation=optimization["optimal_allocation"],
        roas_estimates=model_results.roas_estimates,
        expected_lift_pct=optimization["expected_lift_pct"],
    )

    # Compute new output features
    dollar_headline = _compute_dollar_headline(optimization)
    saturation_lights = _compute_saturation_traffic_lights(saturation_curves, optimization)
    confidence_summary = _compute_confidence_summary(model_results)
    model_fit = _compute_model_fit(model_results)

    # Exploratory analysis badge for short datasets
    analysis_badge = None
    if 0 < data_weeks < 26:
        analysis_badge = {
            "type": "exploratory",
            "label": "Exploratory Analysis",
            "note": (
                f"This analysis covers {data_weeks:.0f} weeks of data. "
                f"MixLift recommends at least 26 weeks for production-grade estimates. "
                f"Results with shorter datasets are influenced more by prior assumptions "
                f"than by your data. Treat ROAS estimates as directional, not precise."
            ),
        }

    is_paid = license_status.is_pro

    result = {
        "status": "success",
        "license": {
            "tier": "pro" if is_paid else "free",
            "message": license_status.message,
        },
        # --- HEADLINE (the most important field) ---
        "headline": dollar_headline["headline"] if is_paid else (
            f"MixLift found a {dollar_headline['lift_pct']:+.1f}% budget optimization opportunity. "
            f"Upgrade to Growth ($299/mo) to see exact dollar values."
        ),
        "data": {
            "format_detected": csv_format,
            "channels": list(model_results.roas_estimates.keys()),
            "n_channels": len(channel_columns),
        },
        "roas": {
            "estimates": model_results.roas_estimates,
            "confidence_intervals": {
                k: {"low": v[0], "high": v[1]}
                for k, v in model_results.roas_ci.items()
            },
        },
        "confidence_summary": confidence_summary,
        "channel_contributions": {
            "estimates": model_results.channel_contributions,
            "confidence_intervals": {
                k: {"low": v[0], "high": v[1]}
                for k, v in model_results.channel_contributions_ci.items()
            },
        },
        "saturation_analysis": saturation_lights,
        "budget_optimization": {
            "current_allocation": optimization["current_allocation"] if is_paid else "Upgrade to Growth ($299/mo) to see dollar allocations",
            "optimal_allocation": optimization["optimal_allocation"] if is_paid else "Upgrade to Growth ($299/mo) to see dollar allocations",
            "total_budget": optimization["total_budget"] if is_paid else "Upgrade to Growth ($299/mo) to see dollar allocations",
            "expected_lift_pct": optimization["expected_lift_pct"],
        },
        "recommendations": {
            "summary": summary if is_paid else _redact_dollars(summary),
            "actions": [
                {
                    "rank": r.rank,
                    "action": r.action,
                    "channel": r.channel,
                    "change_amount": r.change_amount if is_paid else "Upgrade to Growth ($299/mo)",
                    "current_spend": r.current_spend if is_paid else "Upgrade to Growth ($299/mo)",
                    "optimal_spend": r.optimal_spend if is_paid else "Upgrade to Growth ($299/mo)",
                    "roas": r.roas,
                    "reason": r.reason if is_paid else _redact_dollars(r.reason),
                }
                for r in recommendations
            ],
        },
        "marginal_roas": {
            "estimates": model_results.marginal_roas_estimates,
            "confidence_intervals": {
                k: {"low": v[0], "high": v[1]}
                for k, v in model_results.marginal_roas_ci.items()
            },
        },
        "diagnostics": {
            "convergence_warnings": model_results.convergence_warnings,
            "tier_warnings": tier_warnings or [],
        },
        "model_fit": model_fit,
        "analysis_badge": analysis_badge,
        "model_info": {
            "duration_secs": round(model_results.duration_secs, 1),
            "total_spend": model_results.total_spend if is_paid else "Upgrade to Growth ($299/mo)",
            "data_window": {"weeks": round(data_weeks, 1)},
        },
    }

    # MCMC configuration for traceability
    from mixlift.modeling.defaults import MCP_CONFIG
    result["model_info"]["mcmc_config"] = MCP_CONFIG

    # LOO-CV model validation (available to all tiers as a trust signal)
    if model_results.loo_cv:
        result["loo_cv"] = model_results.loo_cv

    # Intercept decomposition: baseline/organic revenue (paid tier only for dollar values)
    if model_results.intercept_decomposition:
        intercept = model_results.intercept_decomposition
        if "error" not in intercept:
            if is_paid:
                result["organic_revenue"] = intercept
            else:
                result["organic_revenue"] = {
                    "label": "Organic/baseline revenue estimate available on Growth plan ($299/mo).",
                    "note": "Your model includes baseline revenue from non-paid sources.",
                }
        else:
            result["organic_revenue"] = intercept

    # Dollar-value details only for paid tier
    if is_paid:
        result["dollar_value_analysis"] = dollar_headline
    else:
        result["dollar_value_analysis"] = {
            "headline": result["headline"],
            "note": "Dollar values are available on the Growth plan ($299/mo)."
                    "Free tier shows percentage-based insights.",
        }

    # Raw saturation curves stripped from MCP output (Claude cannot render charts;
    # traffic lights in saturation_analysis provide the actionable summary).
    # Headless API users can access curves via the modeling engine directly.

    return result


def _run_pipeline(X, y, channel_columns):
    """Wrapper for run_full_pipeline (enables easy mocking in tests).

    Uses MCP_CONFIG (2 chains, 500 tune, 250 draws) for balanced
    convergence quality with ~30-60s response time.
    """
    from mixlift.modeling.defaults import MCP_CONFIG
    from mixlift.modeling.engine import run_full_pipeline

    return run_full_pipeline(X, y, channel_columns, mcmc_config=MCP_CONFIG)


def _run_optimizer(mmm, X, channel_columns, contributions=None):
    """Wrapper for optimize_budget (enables easy mocking in tests)."""
    from mixlift.modeling.optimizer import optimize_budget

    return optimize_budget(mmm, X, channel_columns, contributions=contributions)


def _run_saturation(mmm, X, channel_columns):
    """Wrapper for extract_saturation_curves (enables easy mocking in tests)."""
    from mixlift.modeling.engine import extract_saturation_curves

    return extract_saturation_curves(mmm, X, channel_columns)


@mcp.tool()
async def mixlift_analyze(
    csv_path: str = "",
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Run full Bayesian Marketing Mix Model analysis on marketing spend data.

    Accepts a CSV file path with marketing data (Meta Ads, Google Ads, TikTok Ads,
    or generic format). Auto-detects the CSV format. If no path is provided, uses
    a bundled demo dataset.

    The response is structured in two tiers:
    - `summary`: headline, top actions, channel overview, model quality — enough
      to start an intelligent conversation (~2-4K chars)
    - `structured_data`: full ROAS with CIs, saturation analysis, budget details —
      reference on demand when the user asks for specifics

    Use your judgment to present findings conversationally. Lead with the headline
    and top actions. Surface details from structured_data only when relevant.
    After presenting key findings, ask one intake question from `intake_questions`
    to understand the user's context and tailor follow-up analysis.

    Args:
        csv_path: Path to a CSV file with marketing data. Leave empty to use demo data.
        license_key: Optional MixLift Growth license key. Free tier: 2 channels, 2,000 rows.
    """
    import time as _time

    _step = 0

    async def _log(msg: str) -> None:
        """Send progress to client and log locally."""
        nonlocal _step
        _step += 1
        logger.info(msg)
        if ctx:
            try:
                await ctx.report_progress(_step, 7, msg)
            except Exception:
                pass  # Progress reporting is best-effort

    t0 = _time.monotonic()

    await _log("Validating license...")
    # Validate license
    license_status = await validate_license(license_key if license_key else None)

    # Usage metering for free tier (local run counter)
    if not license_status.is_pro:
        from mixlift_mcp.metering import check_and_increment
        allowed, meter_msg = check_and_increment()
        if not allowed:
            return json.dumps({"status": "error", "message": meter_msg})
        await _log(meter_msg)

    # Load data
    use_demo = not csv_path
    if use_demo:
        if not DEMO_CSV_PATH.exists():
            return json.dumps(
                {"status": "error", "message": "Demo data not found. Please provide a csv_path."}
            )
        csv_file = DEMO_CSV_PATH
    else:
        csv_file, validation_error = _validate_csv_path(csv_path)
        if validation_error:
            return json.dumps({"status": "error", "message": validation_error})
        if not csv_file.exists():
            return json.dumps(
                {"status": "error", "message": f"File not found: {csv_file}"}
            )

    try:
        df = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps(
            {"status": "error", "message": f"Failed to read CSV: {e}"}
        )

    await _log(f"CSV loaded ({len(df)} rows). Detecting format...")
    # Detect format and load
    csv_format = _detect_csv_format(df)

    try:
        if csv_format == "wide":
            X, y, channel_columns = _load_wide_format(df)
        else:
            X, y, channel_columns = _load_platform_csv(df, csv_format)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    # Check date range warnings (90-179 days: warn but proceed)
    date_range_warnings = _check_date_range_warnings(df)
    for w in date_range_warnings:
        logger.warning(w)
        await _log(w)

    # Compute data length for exploratory badge
    try:
        _dates = pd.to_datetime(df["date"])
        _data_weeks = (_dates.max() - _dates.min()).days / 7
    except Exception:
        _data_weeks = 52  # Default to safe value

    # Enforce tier limits
    n_channels = len(channel_columns)
    n_rows = len(X)
    try:
        tier_warnings = _enforce_tier_limits(license_status, n_channels, n_rows)
        tier_warnings.extend(date_range_warnings)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    # Run the modeling pipeline
    try:
        await _log(
            f"Starting MMM: {n_channels} channels, {n_rows} rows, "
            f"format={csv_format}, tier={'pro' if license_status.is_pro else 'free'}"
        )

        # Run CPU-bound MCMC sampling in a thread to avoid blocking the
        # MCP server's async event loop (which would make it appear hung).
        await _log(
            "Fitting Bayesian model via MCMC sampling (~30-60s)... "
            "Building a statistical model of how each channel drives revenue."
        )
        model_results = await asyncio.to_thread(
            _run_pipeline, X, y, channel_columns
        )
        elapsed = _time.monotonic() - t0
        await _log(
            f"MCMC complete in {elapsed:.1f}s. "
            "Optimizing budget allocation — finding the spend mix that maximizes revenue..."
        )

        optimization = await asyncio.to_thread(
            _run_optimizer, model_results.mmm, X, channel_columns,
            contributions=model_results.raw_contributions,
        )
        await _log(
            "Analyzing saturation curves — checking which channels have room to scale "
            "and which are hitting diminishing returns..."
        )

        saturation_curves = await asyncio.to_thread(
            _run_saturation, model_results.mmm, X, channel_columns
        )
        total = _time.monotonic() - t0
        await _log(f"Analysis complete in {total:.1f}s. Building results...")

        result = _build_result(
            model_results=model_results,
            optimization=optimization,
            saturation_curves=saturation_curves,
            channel_columns=channel_columns,
            license_status=license_status,
            csv_format=csv_format,
            tier_warnings=tier_warnings,
            data_weeks=_data_weeks,
        )

        # Include saturation curves for the readout pipeline (diminishing returns)
        if license_status.is_pro:
            result["saturation_curves"] = saturation_curves

        # Contextual memory: compare to previous analysis on same dataset
        fp = None
        try:
            from mixlift_mcp.memory import (
                build_summary,
                compute_deltas,
                compute_fingerprint,
                load_previous,
                save_analysis,
            )

            channel_names = list(model_results.roas_estimates.keys())
            fp = compute_fingerprint(channel_names, str(csv_file))
            saturation_lights = result.get("saturation_analysis", {})

            mem_summary = build_summary(
                roas_estimates=model_results.roas_estimates,
                roas_ci=model_results.roas_ci,
                saturation_lights=saturation_lights,
                optimization=optimization,
                channel_contributions=model_results.channel_contributions,
                model_fit=result.get("model_fit", {}),
                data_weeks=_data_weeks,
                analysis_badge=result.get("analysis_badge"),
            )

            previous = load_previous(fp)
            if previous:
                deltas = compute_deltas(mem_summary, previous)
                result["memory"] = deltas
            else:
                result["memory"] = {
                    "note": "First analysis for this dataset. Future runs will show trends.",
                }

            save_analysis(fp, str(csv_file), mem_summary)

            # Cache the fitted model for forecast/reuse within this session
            _MODEL_CACHE[fp] = {
                "mmm": model_results.mmm,
                "X": X,
                "channel_columns": channel_columns,
                "model_results": model_results,
            }
            # Evict oldest entries if cache exceeds 3 models
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]
            result["model_fingerprint"] = fp
        except Exception as e:
            logger.warning(f"Memory system error (non-fatal): {e}")

        # Back-fill the complete result into the model cache
        if fp and fp in _MODEL_CACHE:
            _MODEL_CACHE[fp]["result"] = result

        # Return tiered response (summary + structured_data) to Claude
        return json.dumps(
            _build_tiered_response(result), indent=2, default=str
        )

    except Exception as e:
        logger.exception("MMM analysis failed")
        return json.dumps(
            {"status": "error", "message": f"Analysis failed: {e}"}
        )


def _parse_scenario(scenario: str, current_allocation: dict) -> dict | None:
    """Parse a natural-language budget scenario into allocation changes.

    Supports patterns like:
    - "cut Meta by 20%"
    - "increase Google by $5000"
    - "move $3000 from Meta to Google"

    Returns modified allocation dict, or None if unparseable.
    """
    import re

    scenario_lower = scenario.lower().strip()
    modified = dict(current_allocation)
    channels_lower = {k.lower(): k for k in current_allocation}

    def _find_channel(text: str) -> str | None:
        # Exact match first, then substring (text in key, not key in text)
        for key, name in channels_lower.items():
            if key == text:
                return name
        for key, name in channels_lower.items():
            if text in key:
                return name
        return None

    # Pattern: "cut/reduce/decrease X by Y%"
    m = re.search(r'(?:cut|reduce|decrease)\s+(\w+)\s+by\s+(\d+)%', scenario_lower)
    if m:
        ch = _find_channel(m.group(1))
        pct = float(m.group(2)) / 100
        if ch and ch in modified:
            modified[ch] = round(modified[ch] * (1 - pct), 2)
            return modified

    # Pattern: "increase/boost X by Y%"
    m = re.search(r'(?:increase|boost|raise)\s+(\w+)\s+by\s+(\d+)%', scenario_lower)
    if m:
        ch = _find_channel(m.group(1))
        pct = float(m.group(2)) / 100
        if ch and ch in modified:
            modified[ch] = round(modified[ch] * (1 + pct), 2)
            return modified

    # Pattern: "cut/reduce X by $Y"
    m = re.search(r'(?:cut|reduce|decrease)\s+(\w+)\s+by\s+\$?([\d,]+)', scenario_lower)
    if m:
        ch = _find_channel(m.group(1))
        amount = float(m.group(2).replace(",", ""))
        if ch and ch in modified:
            modified[ch] = round(max(0, modified[ch] - amount), 2)
            return modified

    # Pattern: "increase X by $Y"
    m = re.search(r'(?:increase|boost|raise)\s+(\w+)\s+by\s+\$?([\d,]+)', scenario_lower)
    if m:
        ch = _find_channel(m.group(1))
        amount = float(m.group(2).replace(",", ""))
        if ch and ch in modified:
            modified[ch] = round(modified[ch] + amount, 2)
            return modified

    # Pattern: "move $Y from X to Z"
    m = re.search(r'move\s+\$?([\d,]+)\s+from\s+(\w+)\s+to\s+(\w+)', scenario_lower)
    if m:
        amount = float(m.group(1).replace(",", ""))
        from_ch = _find_channel(m.group(2))
        to_ch = _find_channel(m.group(3))
        if from_ch and to_ch and from_ch in modified and to_ch in modified:
            modified[from_ch] = round(max(0, modified[from_ch] - amount), 2)
            modified[to_ch] = round(modified[to_ch] + amount, 2)
            return modified

    return None


def _run_scenario(
    scenario: str,
    optimization: dict,
    model_results,
    X,
    channel_columns: list[str],
) -> dict | None:
    """Run a what-if scenario and project impact with confidence intervals."""
    import numpy as np

    from mixlift.modeling.optimizer import (
        _estimate_response,
        estimate_scenario_impact_samples,
    )

    current = optimization["current_allocation"]
    modified = _parse_scenario(scenario, current)

    if modified is None:
        return {
            "error": f"Could not parse scenario: '{scenario}'. "
                     f"Try: 'cut Meta by 20%', 'increase Google by $5000', "
                     f"or 'move $3000 from Meta to Google'."
        }

    # Point estimate (backward-compatible)
    current_response = _estimate_response(
        model_results.mmm, X, channel_columns, current
    )
    modified_response = _estimate_response(
        model_results.mmm, X, channel_columns, modified
    )

    if current_response > 0:
        impact_pct = ((modified_response - current_response) / current_response) * 100
    else:
        impact_pct = 0.0

    # Confidence intervals via posterior sampling
    ci_data = {}
    try:
        samples = estimate_scenario_impact_samples(
            model_results.mmm, X, channel_columns, current, modified
        )
        if len(samples) > 0:
            median = float(np.median(samples))
            ci_low = float(np.percentile(samples, 10))
            ci_high = float(np.percentile(samples, 90))
            impact_pct = median  # Use median instead of point estimate

            ci_data = {
                "impact_ci_80": {"low": round(ci_low, 1), "high": round(ci_high, 1)},
                "confidence_note": "80% credible interval from Bayesian posterior",
            }

            # Direction confidence language
            if ci_low > 0:
                direction_note = (
                    f"This would almost certainly increase revenue, "
                    f"likely by {ci_low:+.1f}% to {ci_high:+.1f}%."
                )
            elif ci_high < 0:
                direction_note = (
                    f"This would almost certainly reduce revenue, "
                    f"likely by {ci_high:.1f}% to {ci_low:.1f}%."
                )
            elif abs(median) > abs(ci_high - ci_low) * 0.1:
                word = "increase" if median > 0 else "reduce"
                direction_note = (
                    f"This would probably {word} revenue (median {median:+.1f}%), "
                    f"but there's a chance it could go either way."
                )
            else:
                direction_note = (
                    "The impact is uncertain — it could go either way. "
                    "Not enough signal to recommend this change."
                )
            ci_data["direction_note"] = direction_note
    except Exception as e:
        logger.warning(f"Could not compute scenario CIs: {e}")

    total_current = sum(current.values())
    total_modified = sum(modified.values())

    changes = []
    for ch in current:
        delta = modified.get(ch, 0) - current.get(ch, 0)
        if abs(delta) > 1:
            changes.append({
                "channel": ch,
                "current": round(current[ch], 0),
                "modified": round(modified.get(ch, 0), 0),
                "change": round(delta, 0),
            })

    result = {
        "scenario_input": scenario,
        "current_budget": round(total_current, 0),
        "modified_budget": round(total_modified, 0),
        "projected_impact_pct": round(impact_pct, 2),
        "headline": (
            f"Scenario: '{scenario}' would result in a {impact_pct:+.1f}% change "
            f"in projected revenue."
        ),
        "changes": changes,
        "modified_allocation": {k: round(v, 0) for k, v in modified.items()},
    }
    result.update(ci_data)
    return result


def _validate_output_dir(output_dir: str) -> tuple[Path, str | None]:
    """Validate and resolve the output directory path.

    Returns (resolved_path, error_message). error_message is None if valid.
    """
    if not output_dir:
        return Path.cwd(), None

    resolved = Path(output_dir).expanduser().resolve()
    path_str = str(resolved).lower()

    # Reuse the same blocked fragments from _validate_csv_path
    blocked = [
        "/etc/", "/var/", "/usr/", "/bin/", "/sbin/",
        "/system/", "/library/", "/.ssh/", "/.gnupg/",
        "/.aws/", "/.config/", "/windows/", "/program files/",
    ]
    for frag in blocked:
        if frag in path_str:
            return resolved, f"Output directory blocked for safety: {resolved}"

    return resolved, None


@mcp.tool()
async def mixlift_readout(
    model_fingerprint: str,
    output_dir: str = "",
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Export MMM analysis results as Obsidian-flavored markdown deliverables.

    Takes the model fingerprint from mixlift_analyze and generates executive-ready
    deliverables with full traceability:
    - Budget Memo: reallocation recommendations for CFO
    - Channel Scorecard: ROAS, saturation, trends at a glance
    - Scenario Brief: what-if impact projection (if scenario was run)
    - Sources: every claim traced to a model output

    Files are written to {output_dir}/MixLift/{date}/ as .md files
    compatible with Obsidian (wiki-links, frontmatter, callouts).

    Requires Growth plan ($299/mo). Present deliverables to the user
    after generation — they are the canonical output format.

    Args:
        model_fingerprint: The model fingerprint returned by mixlift_analyze.
        output_dir: Directory to write deliverables. Defaults to current directory.
        license_key: MixLift Growth license key. Required — free tier cannot generate deliverables.
    """
    # Validate license (paid tier gate)
    license_status = await validate_license(license_key if license_key else None)
    if not license_status.is_pro:
        return json.dumps({
            "status": "error",
            "message": (
                "Deliverable export requires a Growth plan ($299/mo). "
                "Upgrade at https://mixlift.io/pricing to generate "
                "executive-ready budget memos, channel scorecards, and scenario briefs."
            ),
        })

    if not model_fingerprint or model_fingerprint not in _MODEL_CACHE:
        return json.dumps({
            "status": "error",
            "message": (
                "Analysis result not found in session cache. "
                "Run mixlift_analyze first, then call mixlift_readout."
            ),
        })

    result = _MODEL_CACHE[model_fingerprint]["result"]

    if result.get("status") != "success":
        return json.dumps({
            "status": "error",
            "message": (
                "Cannot generate deliverables from a failed analysis. "
                "Run mixlift_analyze first."
            ),
        })

    # Validate output directory
    output_path, dir_error = _validate_output_dir(output_dir)
    if dir_error:
        return json.dumps({"status": "error", "message": dir_error})

    # Generate deliverables
    try:
        from mixlift_mcp.readout import generate_readout

        summary = await asyncio.to_thread(generate_readout, result, str(output_path))
        summary["next_actions"] = [
            {
                "tool": "mixlift_scenario",
                "description": "Test a what-if budget change",
                "params": {"model_fingerprint": model_fingerprint},
            },
            {
                "tool": "mixlift_forecast",
                "description": "Project revenue over the next 12 weeks",
                "params": {"model_fingerprint": model_fingerprint},
            },
        ]
        return json.dumps(summary, indent=2, default=str)
    except Exception as e:
        logger.exception("Deliverable generation failed")
        return json.dumps({
            "status": "error",
            "message": f"Deliverable generation failed: {e}",
        })


@mcp.tool()
async def mixlift_scenario(
    model_fingerprint: str,
    scenario: str,
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Run a what-if budget scenario using a previously fitted model.

    Reuses the model from mixlift_analyze (no MCMC re-run needed) to project
    the revenue impact of budget changes. Supports natural-language scenarios:
    - "cut Meta by 20%"
    - "increase Google by $5000"
    - "move $3000 from Meta to Google"

    The scenario result is also stored in the session cache so that
    mixlift_readout can include a scenario brief in deliverables.

    Requires Growth plan ($299/mo).

    Args:
        model_fingerprint: The model fingerprint returned by mixlift_analyze.
        scenario: Natural-language budget scenario description.
        license_key: MixLift Growth license key.
    """
    # Validate license
    license_status = await validate_license(license_key if license_key else None)
    if not license_status.is_pro:
        return json.dumps({
            "status": "error",
            "message": (
                "Scenario analysis requires a Growth plan ($299/mo). "
                "Upgrade at https://mixlift.io/pricing"
            ),
        })

    if not model_fingerprint or model_fingerprint not in _MODEL_CACHE:
        return json.dumps({
            "status": "error",
            "message": (
                "Fitted model not found in session cache. "
                "Run mixlift_analyze first, then call mixlift_scenario."
            ),
        })

    cache = _MODEL_CACHE[model_fingerprint]
    result = cache["result"]
    model_results = cache["model_results"]
    X = cache["X"]
    channel_columns = cache["channel_columns"]

    optimization = result.get("budget_optimization", {})
    if not optimization.get("current_allocation"):
        return json.dumps({
            "status": "error",
            "message": "No budget allocation found. Run mixlift_analyze first.",
        })

    # Run scenario using cached model (no MCMC needed)
    scenario_result = await asyncio.to_thread(
        _run_scenario, scenario, optimization, model_results, X, channel_columns
    )

    if scenario_result is None:
        return json.dumps({
            "status": "error",
            "message": f"Could not parse scenario: '{scenario}'.",
        })

    # Inject into cached result so readout can include scenario-brief
    result["scenario"] = scenario_result

    scenario_result["status"] = "success"
    scenario_result["model_fingerprint"] = model_fingerprint
    scenario_result["next_actions"] = [
        {
            "tool": "mixlift_scenario",
            "description": "Try another what-if scenario",
            "params": {"model_fingerprint": model_fingerprint},
        },
        {
            "tool": "mixlift_forecast",
            "description": "Project revenue over the next 12 weeks",
            "params": {"model_fingerprint": model_fingerprint},
        },
        {
            "tool": "mixlift_readout",
            "description": "Generate deliverables (includes scenario brief)",
            "params": {"model_fingerprint": model_fingerprint},
        },
    ]
    return json.dumps(scenario_result, indent=2, default=str)


@mcp.tool()
async def mixlift_connect(
    platform: str,
    access_token: str,
    account_id: str,
    date_range: str = "",
    granularity: str = "platform",
    output_dir: str = "",
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Pull marketing data from an ad platform API and save as CSV.

    Connects directly to Meta, Google, or TikTok Ads APIs to pull
    spend + revenue data. Saves a wide-format CSV that can be passed
    directly to mixlift_analyze.

    Supported platforms: meta, google, tiktok

    After connecting, pass the returned output_path to mixlift_analyze.

    Requires Growth plan ($299/mo).

    Args:
        platform: Ad platform — "meta", "google", or "tiktok".
        access_token: Platform API access token.
            - Meta: User or system user access token.
            - Google: JSON string with developer_token, client_id, client_secret, refresh_token.
            - TikTok: Marketing API access token.
        account_id: Platform ad account identifier.
            - Meta: Ad account ID (with or without "act_" prefix).
            - Google: Customer ID (with or without dashes).
            - TikTok: Advertiser ID.
        date_range: Date range to pull. "last_90_days", "last_180_days",
                    "YYYY-MM-DD:YYYY-MM-DD", or empty for last 180 days.
        granularity: "platform" (one channel per platform) or "campaign"
                     (each campaign becomes a separate channel).
        output_dir: Directory to save the CSV. Defaults to current directory.
        license_key: MixLift Growth license key. Required.
    """
    # Validate license
    license_status = await validate_license(license_key if license_key else None)
    if not license_status.is_pro:
        return json.dumps({
            "status": "error",
            "message": (
                "API data connectors require a Growth plan ($299/mo). "
                "Upgrade at https://mixlift.io/pricing"
            ),
        })

    # Validate platform
    platform = platform.strip().lower()
    if platform not in ("meta", "google", "tiktok"):
        return json.dumps({
            "status": "error",
            "message": f"Unsupported platform: '{platform}'. Use 'meta', 'google', or 'tiktok'.",
        })

    # Validate output dir
    output_path, dir_error = _validate_output_dir(output_dir)
    if dir_error:
        return json.dumps({"status": "error", "message": dir_error})

    try:
        from mixlift_mcp.connectors.base import DateRange, to_wide_format, save_wide_csv

        dr = DateRange.from_spec(date_range)

        # Get the right connector
        if platform == "meta":
            from mixlift_mcp.connectors.meta import MetaConnector
            connector = MetaConnector(access_token)
        elif platform == "google":
            from mixlift_mcp.connectors.google import GoogleConnector
            connector = GoogleConnector(access_token)
        else:
            from mixlift_mcp.connectors.tiktok import TikTokConnector
            connector = TikTokConnector(access_token)

        if ctx:
            try:
                await ctx.report_progress(1, 3, f"Connecting to {platform}...")
            except Exception:
                pass

        result = await connector.pull(account_id, dr, granularity)

        if result.row_count == 0:
            return json.dumps({
                "status": "error",
                "message": (
                    f"No data returned from {platform} API. "
                    "Check account_id and date_range."
                ),
            })

        if ctx:
            try:
                await ctx.report_progress(2, 3, f"Pulled {result.row_count} rows. Saving CSV...")
            except Exception:
                pass

        wide_df = to_wide_format([result])
        csv_path = save_wide_csv(wide_df, str(output_path), label=platform)

        if ctx:
            try:
                await ctx.report_progress(3, 3, "Done.")
            except Exception:
                pass

        return json.dumps({
            "status": "success",
            "platform": platform,
            "output_path": str(csv_path),
            "channels": result.channels_found,
            "row_count": result.row_count,
            "date_range": {"start": dr.start.isoformat(), "end": dr.end.isoformat()},
            "message": (
                f"Pulled {result.row_count} rows from {platform}. "
                f"Pass output_path to mixlift_analyze to run MMM."
            ),
            "next_actions": [
                {
                    "tool": "mixlift_analyze",
                    "description": "Run MMM analysis on the connected data",
                    "params": {"csv_path": str(csv_path)},
                },
            ],
        }, indent=2, default=str)

    except ImportError as e:
        return json.dumps({
            "status": "error",
            "message": str(e),
        })
    except Exception as e:
        logger.exception("Connector failed: %s", platform)
        return json.dumps({
            "status": "error",
            "message": f"{platform} connector failed: {e}",
        })


@mcp.tool()
async def mixlift_connect_multi(
    connections: str,
    date_range: str = "",
    granularity: str = "platform",
    output_dir: str = "",
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Pull data from multiple ad platforms and merge into a single CSV.

    Pulls from Meta, Google, and/or TikTok in parallel, merges into one
    wide-format CSV with columns like: date, meta_spend, google_spend, revenue.

    Requires Growth plan ($299/mo).

    Args:
        connections: JSON array of connection specs. Each spec:
            {"platform": "meta", "access_token": "...", "account_id": "..."}
        date_range: Shared date range for all platforms.
        granularity: "platform" or "campaign" (applied to all platforms).
        output_dir: Directory to save the merged CSV. Defaults to current directory.
        license_key: MixLift Growth license key. Required.
    """
    # Validate license
    license_status = await validate_license(license_key if license_key else None)
    if not license_status.is_pro:
        return json.dumps({
            "status": "error",
            "message": (
                "API data connectors require a Growth plan ($299/mo). "
                "Upgrade at https://mixlift.io/pricing"
            ),
        })

    # Parse connections
    try:
        conn_list = json.loads(connections)
        if not isinstance(conn_list, list) or len(conn_list) == 0:
            raise ValueError("connections must be a non-empty JSON array")
    except (json.JSONDecodeError, TypeError, ValueError) as e:
        return json.dumps({
            "status": "error",
            "message": f"Invalid connections JSON: {e}",
        })

    # Validate output dir
    output_path, dir_error = _validate_output_dir(output_dir)
    if dir_error:
        return json.dumps({"status": "error", "message": dir_error})

    try:
        from mixlift_mcp.connectors.base import DateRange, to_wide_format, save_wide_csv

        dr = DateRange.from_spec(date_range)
        results = []
        errors = []

        for i, conn in enumerate(conn_list):
            plat = conn.get("platform", "").strip().lower()
            token = conn.get("access_token", "")
            acct = conn.get("account_id", "")

            if not plat or not token or not acct:
                errors.append(f"Connection {i}: missing platform, access_token, or account_id")
                continue

            if ctx:
                try:
                    await ctx.report_progress(
                        i + 1, len(conn_list) + 1,
                        f"Pulling from {plat}..."
                    )
                except Exception:
                    pass

            try:
                if plat == "meta":
                    from mixlift_mcp.connectors.meta import MetaConnector
                    connector = MetaConnector(token)
                elif plat == "google":
                    from mixlift_mcp.connectors.google import GoogleConnector
                    connector = GoogleConnector(token)
                elif plat == "tiktok":
                    from mixlift_mcp.connectors.tiktok import TikTokConnector
                    connector = TikTokConnector(token)
                else:
                    errors.append(f"Connection {i}: unsupported platform '{plat}'")
                    continue

                result = await connector.pull(acct, dr, granularity)
                if result.row_count > 0:
                    results.append(result)
                else:
                    errors.append(f"{plat}: no data returned")
            except Exception as e:
                errors.append(f"{plat}: {e}")

        if not results:
            return json.dumps({
                "status": "error",
                "message": "No data pulled from any platform.",
                "errors": errors,
            })

        if ctx:
            try:
                await ctx.report_progress(
                    len(conn_list) + 1, len(conn_list) + 1,
                    "Merging and saving CSV..."
                )
            except Exception:
                pass

        wide_df = to_wide_format(results)
        platforms = [r.platform for r in results]
        csv_path = save_wide_csv(
            wide_df, str(output_path), label="_".join(platforms)
        )

        all_channels = []
        total_rows = 0
        for r in results:
            all_channels.extend(r.channels_found)
            total_rows += r.row_count

        summary = {
            "status": "success",
            "platforms": platforms,
            "output_path": str(csv_path),
            "channels": all_channels,
            "total_rows": total_rows,
            "date_range": {
                "start": dr.start.isoformat(),
                "end": dr.end.isoformat(),
            },
            "message": (
                f"Pulled from {len(results)} platform(s): {', '.join(platforms)}. "
                f"{total_rows} total rows. "
                f"Pass output_path to mixlift_analyze to run MMM."
            ),
        }
        if errors:
            summary["warnings"] = errors

        summary["next_actions"] = [
            {
                "tool": "mixlift_analyze",
                "description": "Run MMM analysis on the combined data",
                "params": {"csv_path": str(csv_path)},
            },
        ]

        return json.dumps(summary, indent=2, default=str)

    except ImportError as e:
        return json.dumps({"status": "error", "message": str(e)})
    except Exception as e:
        logger.exception("Multi-connector failed")
        return json.dumps({
            "status": "error",
            "message": f"Multi-connector failed: {e}",
        })


@mcp.tool()
async def mixlift_forecast(
    model_fingerprint: str,
    horizon_weeks: int = 12,
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Forecast revenue under current vs optimized budget allocation.

    Uses the fitted MMM model from the most recent mixlift_analyze run
    to project weekly revenue for the next N weeks. Shows the gap between
    current allocation and the optimal allocation recommended by MixLift.

    Must be called after mixlift_analyze in the same session (the fitted
    model is cached in memory).

    Requires Growth plan ($299/mo).

    Args:
        model_fingerprint: The model fingerprint returned by mixlift_analyze.
        horizon_weeks: Number of weeks to forecast (default: 12).
        license_key: MixLift Growth license key.
    """
    import numpy as np

    # Validate license
    license_status = await validate_license(license_key if license_key else None)
    if not license_status.is_pro:
        return json.dumps({
            "status": "error",
            "message": (
                "Forecasting requires a Growth plan ($299/mo). "
                "Upgrade at https://mixlift.io/pricing"
            ),
        })

    # Get model from cache
    if not model_fingerprint or model_fingerprint not in _MODEL_CACHE:
        return json.dumps({
            "status": "error",
            "message": (
                "Fitted model not found in session cache. "
                "Run mixlift_analyze first, then call mixlift_forecast."
            ),
        })

    cache = _MODEL_CACHE[model_fingerprint]
    result = cache["result"]
    mmm = cache["mmm"]
    X = cache["X"]
    channel_columns = cache["channel_columns"]

    # Clamp horizon
    horizon_weeks = max(1, min(horizon_weeks, 52))

    try:
        from mixlift.modeling.optimizer import (
            _estimate_response,
            estimate_scenario_impact_samples,
        )

        if ctx:
            try:
                await ctx.report_progress(1, 3, "Computing baseline forecast...")
            except Exception:
                pass

        # Get allocations from the result
        budget_opt = result.get("budget_optimization", {})
        current_alloc = budget_opt.get("current_allocation", {})
        optimal_alloc = budget_opt.get("optimal_allocation", {})

        if not current_alloc or not isinstance(current_alloc, dict):
            return json.dumps({
                "status": "error",
                "message": (
                    "No budget allocation found in result. "
                    "Run mixlift_analyze first."
                ),
            })

        # Point estimate: weekly revenue at current allocation
        current_weekly = await asyncio.to_thread(
            _estimate_response, mmm, X, channel_columns, current_alloc
        )

        if ctx:
            try:
                await ctx.report_progress(2, 3, "Computing forecast uncertainty...")
            except Exception:
                pass

        # Get impact distribution from posterior
        impact_samples = await asyncio.to_thread(
            estimate_scenario_impact_samples,
            mmm, X, channel_columns, current_alloc, optimal_alloc,
        )

        # Compute stats
        if len(impact_samples) > 0:
            impact_median = float(np.median(impact_samples))
            impact_ci_low = float(np.percentile(impact_samples, 10))
            impact_ci_high = float(np.percentile(impact_samples, 90))
        else:
            impact_median = 0.0
            impact_ci_low = 0.0
            impact_ci_high = 0.0

        # Optimal weekly = current * (1 + impact/100)
        optimal_weekly_from_impact = current_weekly * (1 + impact_median / 100)

        # Build weekly projections
        weekly_delta = optimal_weekly_from_impact - current_weekly
        weeks = []
        cumulative_current = 0.0
        cumulative_optimal = 0.0
        cumulative_delta = 0.0

        for w in range(1, horizon_weeks + 1):
            cumulative_current += current_weekly
            cumulative_optimal += optimal_weekly_from_impact
            cumulative_delta += weekly_delta
            weeks.append({
                "week": w,
                "current_revenue": round(current_weekly, 0),
                "optimized_revenue": round(optimal_weekly_from_impact, 0),
                "weekly_delta": round(weekly_delta, 0),
                "cumulative_current": round(cumulative_current, 0),
                "cumulative_optimized": round(cumulative_optimal, 0),
                "cumulative_delta": round(cumulative_delta, 0),
            })

        if ctx:
            try:
                await ctx.report_progress(3, 3, "Done.")
            except Exception:
                pass

        total_current = round(current_weekly * horizon_weeks, 0)
        total_optimal = round(optimal_weekly_from_impact * horizon_weeks, 0)
        total_delta = round(weekly_delta * horizon_weeks, 0)

        forecast_result = {
            "status": "success",
            "analysis_type": "forecast",
            "horizon_weeks": horizon_weeks,
            "summary": {
                "current_weekly_revenue": round(current_weekly, 0),
                "optimized_weekly_revenue": round(optimal_weekly_from_impact, 0),
                "weekly_delta": round(weekly_delta, 0),
                "total_current_revenue": total_current,
                "total_optimized_revenue": total_optimal,
                "total_delta": total_delta,
                "impact_pct": round(impact_median, 1),
                "impact_ci_80": {
                    "low": round(impact_ci_low, 1),
                    "high": round(impact_ci_high, 1),
                },
            },
            "weekly_projections": weeks,
            "current_allocation": current_alloc,
            "optimal_allocation": optimal_alloc,
            "headline": (
                f"Over {horizon_weeks} weeks, optimizing your budget would generate "
                f"an estimated ${total_delta:,.0f} in additional revenue "
                f"({impact_median:+.1f}% weekly, "
                f"80% CI: {impact_ci_low:+.1f}% to {impact_ci_high:+.1f}%)."
            ),
            "model_fingerprint": model_fingerprint,
            "model_info": result.get("model_info", {}),
            "data": result.get("data", {}),
            "license": result.get("license", {}),
        }

        forecast_result["next_actions"] = [
            {
                "tool": "mixlift_readout",
                "description": "Generate executive deliverables",
                "params": {"model_fingerprint": model_fingerprint},
            },
            {
                "tool": "mixlift_scenario",
                "description": "Test a what-if budget change",
                "params": {"model_fingerprint": model_fingerprint},
            },
        ]

        return json.dumps(forecast_result, indent=2, default=str)

    except Exception as e:
        logger.exception("Forecasting failed")
        return json.dumps({
            "status": "error",
            "message": f"Forecasting failed: {e}",
        })


@mcp.tool()
async def mixlift_prepare(
    csv_path: str,
    date_col: str = "",
    channel_col: str = "",
    spend_col: str = "",
    revenue_col: str = "",
    ctx: Context | None = None,
) -> str:
    """Prepare any marketing CSV into the wide format that mixlift_analyze expects.

    Use this tool BEFORE mixlift_analyze when the user's CSV is not already in
    MixLift wide format. Wide format has columns: date, {channel}_spend, revenue.

    Common input formats this handles:
    - Campaign-level rows (one row per campaign/ad with a channel column)
    - Long/tidy format (one row per date × channel)
    - Platform exports with non-standard column names

    The tool auto-detects columns by name heuristics but you can override with
    explicit column name parameters if auto-detection fails.

    After preparing, pass the returned output_path to mixlift_analyze.

    Args:
        csv_path: Path to the raw CSV file.
        date_col: Override for the date column name. Auto-detected if empty.
        channel_col: Override for the channel/platform column name. Auto-detected if empty.
        spend_col: Override for the spend/cost column name. Auto-detected if empty.
        revenue_col: Override for the revenue/sales/target column name. Auto-detected if empty.
    """
    # Validate path
    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

    try:
        df = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    cols = list(df.columns)
    cols_lower = {c.lower(): c for c in cols}

    if ctx:
        try:
            await ctx.report_progress(1, 4, f"Loaded CSV: {len(df)} rows, {len(cols)} columns")
        except Exception:
            pass

    # --- Check if already in wide format ---
    spend_cols_existing = [c for c in cols if c.lower().endswith("_spend")]
    has_revenue = any(c in cols_lower for c in ("revenue", "target", "sales"))
    if len(spend_cols_existing) >= 2 and has_revenue:
        return json.dumps({
            "status": "already_wide",
            "message": "This CSV is already in MixLift wide format. Pass it directly to mixlift_analyze.",
            "output_path": str(csv_file),
            "channels": [c.replace("_spend", "") for c in spend_cols_existing],
            "next_actions": [
                {
                    "tool": "mixlift_analyze",
                    "description": "Run MMM analysis on this data",
                    "params": {"csv_path": csv_path},
                },
            ],
        })

    # --- Auto-detect columns ---
    def _find_col(candidates: list[str], override: str = "") -> str | None:
        if override:
            # Exact or case-insensitive match
            if override in cols:
                return override
            for c in cols:
                if c.lower() == override.lower():
                    return c
            return None
        for candidate in candidates:
            for c in cols:
                if c.lower() == candidate.lower():
                    return c
        # Substring fallback
        for candidate in candidates:
            for c in cols:
                if candidate.lower() in c.lower():
                    return c
        return None

    detected_date = _find_col(
        ["date", "day", "week", "month", "period", "report_date", "campaign_date"],
        override=date_col,
    )
    detected_channel = _find_col(
        ["channel", "channel_used", "platform", "source", "medium",
         "campaign_type", "ad_channel", "traffic_source", "utm_source",
         "network", "publisher"],
        override=channel_col,
    )
    detected_spend = _find_col(
        ["spend", "cost", "acquisition_cost", "ad_spend", "media_spend",
         "amount_spent", "total_cost", "budget", "investment"],
        override=spend_col,
    )
    detected_revenue = _find_col(
        ["revenue", "sales", "target", "income", "conversion_value",
         "total_revenue", "value", "gmv", "roi"],
        override=revenue_col,
    )

    errors = []
    if not detected_date:
        errors.append("Could not detect a date column. Provide date_col parameter.")
    if not detected_channel:
        errors.append("Could not detect a channel/platform column. Provide channel_col parameter.")
    if not detected_spend:
        errors.append("Could not detect a spend/cost column. Provide spend_col parameter.")

    if errors:
        return json.dumps({
            "status": "error",
            "message": "Column auto-detection failed:\n" + "\n".join(f"  - {e}" for e in errors),
            "columns_found": cols,
            "hint": "Re-run with explicit date_col, channel_col, and spend_col parameters.",
        })

    if ctx:
        try:
            await ctx.report_progress(2, 4,
                f"Detected: date={detected_date}, channel={detected_channel}, "
                f"spend={detected_spend}, revenue={detected_revenue or 'none'}")
        except Exception:
            pass

    # --- Transform to wide format ---
    work = df.copy()

    # Parse dates
    try:
        work["_date"] = pd.to_datetime(work[detected_date])
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Could not parse dates in '{detected_date}': {e}"})

    # Parse spend (handle currency strings like "$16,174.00")
    try:
        spend_series = work[detected_spend]
        if spend_series.dtype == object:
            spend_series = spend_series.str.replace(r'[$,€£¥]', '', regex=True)
        work["_spend"] = pd.to_numeric(spend_series, errors="coerce").fillna(0)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Could not parse spend in '{detected_spend}': {e}"})

    # Parse revenue if available, otherwise derive from ROI if possible
    has_direct_revenue = False
    if detected_revenue:
        rev_col_lower = detected_revenue.lower()
        if rev_col_lower == "roi":
            # ROI column — derive revenue as spend * ROI
            try:
                work["_revenue"] = work["_spend"] * pd.to_numeric(work[detected_revenue], errors="coerce").fillna(0)
                has_direct_revenue = True
            except Exception:
                pass
        else:
            try:
                rev_series = work[detected_revenue]
                if rev_series.dtype == object:
                    rev_series = rev_series.str.replace(r'[$,€£¥]', '', regex=True)
                work["_revenue"] = pd.to_numeric(rev_series, errors="coerce").fillna(0)
                has_direct_revenue = True
            except Exception:
                pass

    if not has_direct_revenue:
        # Check if there's an ROI column we can use as fallback
        roi_col = _find_col(["roi", "roas", "return_on_investment"])
        if roi_col and roi_col != detected_revenue:
            work["_revenue"] = work["_spend"] * pd.to_numeric(work[roi_col], errors="coerce").fillna(0)
            has_direct_revenue = True

    if not has_direct_revenue:
        return json.dumps({
            "status": "error",
            "message": "Could not detect or compute a revenue column. "
                       "Provide revenue_col (e.g. 'revenue', 'sales') or ensure an ROI column exists.",
            "columns_found": cols,
        })

    # Aggregate to weekly by channel
    work["_week"] = work["_date"].dt.to_period("W").dt.start_time
    channel_series = work[detected_channel].astype(str).str.strip()

    # Clean channel names for column headers
    def _clean_channel_name(name: str) -> str:
        import re
        clean = re.sub(r'[^a-z0-9]+', '_', name.lower()).strip('_')
        return clean

    work["_channel_clean"] = channel_series.apply(_clean_channel_name)

    # Pivot spend by channel
    weekly_spend = (
        work.groupby(["_week", "_channel_clean"])["_spend"]
        .sum()
        .reset_index()
    )
    wide_spend = weekly_spend.pivot(index="_week", columns="_channel_clean", values="_spend").fillna(0)
    wide_spend.columns = [f"{c}_spend" for c in wide_spend.columns]

    # Aggregate revenue by week (sum across all rows, not just paid channels)
    weekly_revenue = work.groupby("_week")["_revenue"].sum().reset_index()
    weekly_revenue.columns = ["_week", "revenue"]

    result_df = wide_spend.reset_index().merge(weekly_revenue, on="_week")
    result_df = result_df.rename(columns={"_week": "date"})

    # Sort by date
    result_df = result_df.sort_values("date").reset_index(drop=True)

    if ctx:
        try:
            await ctx.report_progress(3, 4,
                f"Transformed: {len(result_df)} weeks, "
                f"{len(wide_spend.columns)} channels")
        except Exception:
            pass

    # Drop channels with zero total spend
    spend_columns = [c for c in result_df.columns if c.endswith("_spend")]
    zero_channels = [c for c in spend_columns if result_df[c].sum() == 0]
    if zero_channels:
        result_df = result_df.drop(columns=zero_channels)
        spend_columns = [c for c in spend_columns if c not in zero_channels]

    # Validate minimum requirements
    if len(spend_columns) < 2:
        return json.dumps({
            "status": "error",
            "message": f"Only {len(spend_columns)} channel(s) found after aggregation. "
                       f"MixLift requires at least 2 channels.",
            "channels": [c.replace("_spend", "") for c in spend_columns],
        })

    if len(result_df) < 13:
        return json.dumps({
            "status": "error",
            "message": f"Only {len(result_df)} weeks of data after aggregation. "
                       f"MixLift requires at least 13 weeks (90 days).",
        })

    # Save output
    out_path = csv_file.parent / f"{csv_file.stem}_mixlift_ready.csv"
    result_df.to_csv(out_path, index=False)

    channels = [c.replace("_spend", "") for c in spend_columns]

    if ctx:
        try:
            await ctx.report_progress(4, 4, "Preparation complete")
        except Exception:
            pass

    return json.dumps({
        "status": "success",
        "output_path": str(out_path),
        "message": f"Prepared {len(result_df)} weeks of data with {len(channels)} channels. "
                   f"Pass output_path to mixlift_analyze.",
        "channels": channels,
        "date_range": f"{result_df['date'].min()} to {result_df['date'].max()}",
        "rows": len(result_df),
        "columns_detected": {
            "date": detected_date,
            "channel": detected_channel,
            "spend": detected_spend,
            "revenue": detected_revenue,
        },
        "next_actions": [
            {
                "tool": "mixlift_analyze",
                "description": "Run MMM analysis on the prepared data",
                "params": {"csv_path": str(out_path)},
            },
        ],
    })


def main():
    """Entry point for the MixLift MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
