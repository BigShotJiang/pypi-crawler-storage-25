"""Expected column mappings per ad platform."""

# Column name patterns for auto-detection (lowercase).
# Each platform has required columns and their possible aliases.

PLATFORM_SIGNATURES = {
    "meta": {
        "identifiers": ["campaign name", "ad set name", "campaign_name", "adset_name"],
        "columns": {
            "date": ["date", "day", "reporting starts", "reporting_starts"],
            "spend": ["amount spent (usd)", "amount spent", "spend", "cost"],
            "impressions": ["impressions", "impr"],
            "clicks": ["link clicks", "clicks", "outbound clicks"],
            "conversions": [
                "purchases",
                "results",
                "conversions",
                "purchase roas",
                "website purchases",
            ],
            "campaign": ["campaign name", "campaign_name"],
        },
    },
    "google": {
        "identifiers": ["campaign", "ad group", "campaign type", "campaign_type"],
        "columns": {
            "date": ["date", "day", "segment.date"],
            "spend": ["cost", "cost / conv.", "amount spent", "spend"],
            "impressions": ["impressions", "impr.", "impr"],
            "clicks": ["clicks"],
            "conversions": ["conversions", "conv.", "all conv."],
            "campaign": ["campaign", "campaign name"],
        },
    },
    "tiktok": {
        "identifiers": ["campaign name", "objective type", "campaign id"],
        "columns": {
            "date": ["date", "day"],
            "spend": ["cost", "total cost", "spend"],
            "impressions": ["impression", "impressions"],
            "clicks": ["clicks", "click"],
            "conversions": [
                "conversion",
                "conversions",
                "complete payment",
                "total complete payment",
            ],
            "campaign": ["campaign name", "campaign"],
        },
    },
}

# Canonical output schema
CANONICAL_COLUMNS = ["date", "channel", "spend", "impressions", "clicks", "conversions"]
