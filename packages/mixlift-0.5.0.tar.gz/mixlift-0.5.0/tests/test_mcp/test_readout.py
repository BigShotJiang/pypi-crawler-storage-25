"""Tests for mixlift_mcp.readout — Obsidian deliverables pipeline."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from mixlift_mcp.readout import (
    SourceCollector,
    SourceRef,
    generate_readout,
    render_budget_memo,
    render_channel_scorecard,
    render_diminishing_returns,
    render_forecast_brief,
    render_scenario_brief,
    render_sources,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_result():
    """A complete MMM result dict matching _build_result() output."""
    return {
        "status": "success",
        "license": {"tier": "pro", "message": "Valid"},
        "headline": "MixLift found a +12.5% budget optimization opportunity worth $1,250/week.",
        "data": {
            "format_detected": "wide",
            "channels": ["Meta", "Google", "TikTok"],
            "n_channels": 3,
        },
        "roas": {
            "estimates": {"Meta": 2.45, "Google": 3.10, "TikTok": 1.80},
            "confidence_intervals": {
                "Meta": {"low": 1.90, "high": 3.00},
                "Google": {"low": 2.50, "high": 3.70},
                "TikTok": {"low": 1.20, "high": 2.40},
            },
        },
        "confidence_summary": {},
        "channel_contributions": {
            "estimates": {"Meta": 15000.0, "Google": 18000.0, "TikTok": 8000.0},
            "confidence_intervals": {
                "Meta": {"low": 12000, "high": 18000},
                "Google": {"low": 15000, "high": 21000},
                "TikTok": {"low": 5000, "high": 11000},
            },
        },
        "saturation_analysis": {
            "Meta": {
                "status": "yellow",
                "label": "Meta approaching saturation",
                "saturation_pct": 62,
            },
            "Google": {
                "status": "green",
                "label": "Google not saturated",
                "saturation_pct": 35,
            },
            "TikTok": {
                "status": "red",
                "label": "TikTok heavily saturated",
                "saturation_pct": 88,
            },
        },
        "budget_optimization": {
            "current_allocation": {"Meta": 5000, "Google": 3000, "TikTok": 2000},
            "optimal_allocation": {"Meta": 4000, "Google": 4200, "TikTok": 1800},
            "total_budget": 10000,
            "expected_lift_pct": 12.5,
        },
        "recommendations": {
            "summary": "Reallocating your budget could improve results by approximately 12.5%.",
            "actions": [
                {
                    "rank": 1,
                    "action": "INCREASE",
                    "channel": "Google",
                    "change_amount": 1200.0,
                    "current_spend": 3000.0,
                    "optimal_spend": 4200.0,
                    "roas": 3.10,
                    "reason": "Strong ROAS (3.1x) with headroom before saturation.",
                },
                {
                    "rank": 2,
                    "action": "DECREASE",
                    "channel": "Meta",
                    "change_amount": 1000.0,
                    "current_spend": 5000.0,
                    "optimal_spend": 4000.0,
                    "roas": 2.45,
                    "reason": "Approaching saturation at current spend levels.",
                },
            ],
        },
        "marginal_roas": {
            "estimates": {"Meta": 1.80, "Google": 2.90, "TikTok": 0.95},
            "confidence_intervals": {
                "Meta": {"low": 1.20, "high": 2.40},
                "Google": {"low": 2.30, "high": 3.50},
                "TikTok": {"low": 0.50, "high": 1.40},
            },
        },
        "diagnostics": {
            "convergence_warnings": [],
            "tier_warnings": [],
        },
        "model_fit": {
            "label": "Strong (R² = 0.92)",
            "r_squared": 0.92,
            "mape": 8.5,
        },
        "analysis_badge": None,
        "model_info": {
            "duration_secs": 45.3,
            "total_spend": {"Meta": 50000, "Google": 30000, "TikTok": 20000},
            "data_window": {"weeks": 52.0},
            "mcmc_config": {"chains": 2, "tune": 500, "draws": 250, "target_accept": 0.90},
        },
        "loo_cv": {"interpretation_label": "Good"},
        "memory": {
            "previous_analysis": "2026-04-05T10:30:00",
            "changes": {
                "Meta": {
                    "status": "stable",
                    "change_pct": 2.1,
                    "roas_previous": 2.40,
                    "roas_current": 2.45,
                },
                "Google": {
                    "status": "changed",
                    "change_pct": 15.2,
                    "roas_previous": 2.69,
                    "roas_current": 3.10,
                    "confidence": "high",
                },
                "TikTok": {"status": "new", "narrative": "New channel"},
            },
        },
    }


@pytest.fixture
def mock_result_with_scenario(mock_result):
    """Result dict with scenario analysis included."""
    mock_result["scenario"] = {
        "scenario_input": "cut Meta by 20%",
        "current_budget": 10000,
        "modified_budget": 9000,
        "projected_impact_pct": -8.5,
        "headline": (
            "Scenario: 'cut Meta by 20%' would result in a -8.5% change in projected revenue."
        ),
        "changes": [
            {"channel": "Meta", "current": 5000, "modified": 4000, "change": -1000},
        ],
        "modified_allocation": {"Meta": 4000, "Google": 3000, "TikTok": 2000},
        "impact_ci_80": {"low": -12.1, "high": -4.2},
        "direction_note": "This would almost certainly reduce revenue, likely by -12.1% to -4.2%.",
    }
    return mock_result


# ---------------------------------------------------------------------------
# TestSourceCollector
# ---------------------------------------------------------------------------


class TestSourceCollector:
    def test_cite_returns_wikilink(self):
        collector = SourceCollector()
        result = collector.cite(
            anchor_id="roas-meta",
            field_path="roas.estimates.Meta",
            value="2.45x",
        )
        assert result == "[[sources#roas-meta]]"

    def test_cite_registers_ref(self):
        collector = SourceCollector()
        collector.cite(
            anchor_id="roas-meta",
            field_path="roas.estimates.Meta",
            value="2.45x",
            ci="1.90 – 3.00 (90% CI)",
            data_window="52 weeks",
            mcmc_config="2 chains, 500 tune",
        )
        ref = collector.refs["roas-meta"]
        assert isinstance(ref, SourceRef)
        assert ref.anchor_id == "roas-meta"
        assert ref.field_path == "roas.estimates.Meta"
        assert ref.value == "2.45x"
        assert ref.credible_interval == "1.90 – 3.00 (90% CI)"
        assert ref.data_window == "52 weeks"
        assert ref.mcmc_config == "2 chains, 500 tune"

    def test_duplicate_anchor_overwrites(self):
        collector = SourceCollector()
        collector.cite(anchor_id="roas-meta", field_path="old.path", value="1.00x")
        collector.cite(anchor_id="roas-meta", field_path="new.path", value="2.45x")
        assert collector.refs["roas-meta"].field_path == "new.path"
        assert collector.refs["roas-meta"].value == "2.45x"
        # Only one entry should exist
        assert len([k for k in collector.refs if k == "roas-meta"]) == 1


# ---------------------------------------------------------------------------
# TestRenderBudgetMemo
# ---------------------------------------------------------------------------


class TestRenderBudgetMemo:
    def test_contains_yaml_frontmatter(self, mock_result):
        collector = SourceCollector()
        output = render_budget_memo(mock_result, collector)
        assert output.startswith("---\n")

    def test_contains_recommendations_table(self, mock_result):
        collector = SourceCollector()
        output = render_budget_memo(mock_result, collector)
        assert "| Priority |" in output

    def test_contains_dollar_amounts(self, mock_result):
        collector = SourceCollector()
        output = render_budget_memo(mock_result, collector)
        # Google change_amount = 1200
        assert "$1,200" in output
        # Google current_spend = 3000
        assert "$3,000" in output

    def test_contains_citations(self, mock_result):
        collector = SourceCollector()
        output = render_budget_memo(mock_result, collector)
        assert "[[sources#" in output

    def test_exploratory_badge_callout(self, mock_result):
        mock_result["analysis_badge"] = {
            "type": "exploratory",
            "label": "Exploratory Analysis",
            "note": "12 weeks of data",
        }
        collector = SourceCollector()
        output = render_budget_memo(mock_result, collector)
        assert "> [!warning]" in output


# ---------------------------------------------------------------------------
# TestRenderChannelScorecard
# ---------------------------------------------------------------------------


class TestRenderChannelScorecard:
    def test_contains_all_channels(self, mock_result):
        collector = SourceCollector()
        output = render_channel_scorecard(mock_result, collector)
        assert "Meta" in output
        assert "Google" in output
        assert "TikTok" in output

    def test_saturation_traffic_lights(self, mock_result):
        collector = SourceCollector()
        output = render_channel_scorecard(mock_result, collector)
        assert "Green" in output
        assert "Yellow" in output
        assert "Red" in output

    def test_trend_with_deltas(self, mock_result):
        collector = SourceCollector()
        output = render_channel_scorecard(mock_result, collector)
        # Google has status="changed", change_pct=15.2 → "↑ +15.2%"
        assert "↑ +15.2%" in output

    def test_trend_first_run(self, mock_result):
        # Remove "changes" key to simulate first-run (no memory deltas)
        mock_result["memory"] = {"note": "First analysis"}
        collector = SourceCollector()
        output = render_channel_scorecard(mock_result, collector)
        # All channels should show "—" when there are no memory changes
        assert "—" in output

    def test_marginal_roas_present(self, mock_result):
        collector = SourceCollector()
        output = render_channel_scorecard(mock_result, collector)
        # Google marginal ROAS = 2.90
        assert "2.90" in output


# ---------------------------------------------------------------------------
# TestRenderScenarioBrief
# ---------------------------------------------------------------------------


class TestRenderScenarioBrief:
    def test_returns_none_when_no_scenario(self, mock_result):
        collector = SourceCollector()
        result = render_scenario_brief(mock_result, collector)
        assert result is None

    def test_contains_impact_ci(self, mock_result_with_scenario):
        collector = SourceCollector()
        output = render_scenario_brief(mock_result_with_scenario, collector)
        assert output is not None
        assert "-12.1" in output
        assert "-4.2" in output

    def test_contains_direction_note(self, mock_result_with_scenario):
        collector = SourceCollector()
        output = render_scenario_brief(mock_result_with_scenario, collector)
        assert output is not None
        assert "almost certainly reduce" in output


# ---------------------------------------------------------------------------
# TestRenderSources
# ---------------------------------------------------------------------------


class TestRenderSources:
    def test_all_refs_appear(self, mock_result):
        collector = SourceCollector()
        render_budget_memo(mock_result, collector)
        render_channel_scorecard(mock_result, collector)
        sources_output = render_sources(collector)
        for anchor_id in collector.refs:
            assert anchor_id in sources_output

    def test_block_ids_present(self, mock_result):
        collector = SourceCollector()
        render_budget_memo(mock_result, collector)
        render_channel_scorecard(mock_result, collector)
        sources_output = render_sources(collector)
        # sources.md.j2 emits ^{anchor_id} block IDs
        assert "^roas-meta" in sources_output


# ---------------------------------------------------------------------------
# TestGenerateReadout
# ---------------------------------------------------------------------------


class TestGenerateReadout:
    def test_creates_output_directory(self, tmp_path, mock_result):
        from datetime import date

        generate_readout(mock_result, str(tmp_path))
        run_dir = tmp_path / "MixLift" / date.today().isoformat()
        assert run_dir.is_dir()

    def test_writes_all_files(self, tmp_path, mock_result):
        from datetime import date

        generate_readout(mock_result, str(tmp_path))
        run_dir = tmp_path / "MixLift" / date.today().isoformat()
        assert (run_dir / "budget-memo.md").exists()
        assert (run_dir / "channel-scorecard.md").exists()
        assert (run_dir / "sources.md").exists()

    def test_scenario_file_conditional(self, tmp_path, mock_result_with_scenario):
        import copy
        from datetime import date

        # Build a result without scenario from the scenario fixture (deep copy, drop "scenario")
        no_scenario = copy.deepcopy(mock_result_with_scenario)
        del no_scenario["scenario"]

        # Without scenario: scenario-brief.md must NOT be written
        no_scenario_dir = tmp_path / "no_scenario"
        generate_readout(no_scenario, str(no_scenario_dir))
        run_dir = no_scenario_dir / "MixLift" / date.today().isoformat()
        assert not (run_dir / "scenario-brief.md").exists()

        # With scenario: scenario-brief.md MUST be written
        scenario_dir = tmp_path / "with_scenario"
        generate_readout(mock_result_with_scenario, str(scenario_dir))
        scenario_run_dir = scenario_dir / "MixLift" / date.today().isoformat()
        assert (scenario_run_dir / "scenario-brief.md").exists()

    def test_returns_summary(self, tmp_path, mock_result):
        summary = generate_readout(mock_result, str(tmp_path))
        assert summary["status"] == "success"
        assert isinstance(summary["files_written"], list)
        assert len(summary["files_written"]) > 0


@pytest.fixture
def mock_result_with_saturation_curves(mock_result):
    """Result dict with saturation_curves for diminishing-returns rendering."""
    import numpy as np

    channels = ["Meta", "Google", "TikTok"]
    curves = {}
    for ch in channels:
        spends = np.linspace(0, 20000, 100).tolist()
        # Simple concave response: sqrt-like saturation
        responses = [float(5000 * (s / 20000) ** 0.5) for s in spends]
        curves[ch] = {"spend": spends, "response": responses}
    mock_result["saturation_curves"] = curves
    return mock_result


@pytest.fixture
def mock_forecast_result():
    """A forecast-type result dict."""
    return {
        "status": "success",
        "analysis_type": "forecast",
        "headline": "Optimized allocation adds $6,200 over 4 weeks.",
        "license": {"tier": "pro"},
        "data": {"channels": ["Meta", "Google"], "n_channels": 2},
        "model_info": {
            "data_window": {"weeks": 52},
            "mcmc_config": {"chains": 2, "tune": 500, "draws": 250, "target_accept": 0.90},
        },
        "analysis_badge": None,
        "model_fit": {"r_squared": 0.91},
        "horizon_weeks": 4,
        "summary": {
            "total_current_revenue": 40000,
            "total_optimized_revenue": 46200,
            "total_delta": 6200,
            "current_weekly_revenue": 10000,
            "optimized_weekly_revenue": 11550,
            "weekly_delta": 1550,
            "impact_pct": 15.5,
            "impact_ci_80": {"low": 10.2, "high": 20.8},
        },
        "weekly_projections": [
            {
                "week": 1,
                "current_revenue": 10000,
                "optimized_revenue": 11200,
                "weekly_delta": 1200,
                "cumulative_delta": 1200,
            },
            {
                "week": 2,
                "current_revenue": 10000,
                "optimized_revenue": 11400,
                "weekly_delta": 1400,
                "cumulative_delta": 2600,
            },
            {
                "week": 3,
                "current_revenue": 10000,
                "optimized_revenue": 11800,
                "weekly_delta": 1800,
                "cumulative_delta": 4400,
            },
            {
                "week": 4,
                "current_revenue": 10000,
                "optimized_revenue": 11800,
                "weekly_delta": 1800,
                "cumulative_delta": 6200,
            },
        ],
        "budget_optimization": {
            "current_allocation": {"Meta": 5000, "Google": 3000},
            "optimal_allocation": {"Meta": 4000, "Google": 4000},
        },
    }


# ---------------------------------------------------------------------------
# TestRenderDiminishingReturns
# ---------------------------------------------------------------------------


class TestRenderDiminishingReturns:
    def test_returns_none_without_curves(self, mock_result):
        collector = SourceCollector()
        result = render_diminishing_returns(mock_result, collector)
        assert result is None

    def test_renders_with_curves(self, mock_result_with_saturation_curves):
        collector = SourceCollector()
        output = render_diminishing_returns(mock_result_with_saturation_curves, collector)
        assert output is not None
        assert output.startswith("---\n")

    def test_contains_all_channels(self, mock_result_with_saturation_curves):
        collector = SourceCollector()
        output = render_diminishing_returns(mock_result_with_saturation_curves, collector)
        assert output is not None
        assert "Meta" in output
        assert "Google" in output
        assert "TikTok" in output

    def test_contains_saturation_status(self, mock_result_with_saturation_curves):
        collector = SourceCollector()
        output = render_diminishing_returns(mock_result_with_saturation_curves, collector)
        assert output is not None
        # saturation_analysis has Yellow for Meta
        assert "Yellow" in output

    def test_contains_current_marker(self, mock_result_with_saturation_curves):
        collector = SourceCollector()
        output = render_diminishing_returns(mock_result_with_saturation_curves, collector)
        assert output is not None
        assert "← current" in output

    def test_contains_spend_table(self, mock_result_with_saturation_curves):
        collector = SourceCollector()
        output = render_diminishing_returns(mock_result_with_saturation_curves, collector)
        assert output is not None
        assert "| Weekly Spend |" in output

    def test_cites_saturation_status(self, mock_result_with_saturation_curves):
        collector = SourceCollector()
        render_diminishing_returns(mock_result_with_saturation_curves, collector)
        assert "dr-sat-meta" in collector.refs

    def test_generate_readout_writes_diminishing_returns(
        self, tmp_path, mock_result_with_saturation_curves
    ):
        from datetime import date

        generate_readout(mock_result_with_saturation_curves, str(tmp_path))
        run_dir = tmp_path / "MixLift" / date.today().isoformat()
        assert (run_dir / "diminishing-returns.md").exists()

    def test_generate_readout_skips_without_curves(self, tmp_path, mock_result):
        from datetime import date

        generate_readout(mock_result, str(tmp_path))
        run_dir = tmp_path / "MixLift" / date.today().isoformat()
        assert not (run_dir / "diminishing-returns.md").exists()


# ---------------------------------------------------------------------------
# TestRenderForecastBrief
# ---------------------------------------------------------------------------


class TestRenderForecastBrief:
    def test_returns_none_for_mmm_result(self, mock_result):
        collector = SourceCollector()
        result = render_forecast_brief(mock_result, collector)
        assert result is None

    def test_renders_forecast_result(self, mock_forecast_result):
        collector = SourceCollector()
        output = render_forecast_brief(mock_forecast_result, collector)
        assert output is not None
        assert output.startswith("---\n")

    def test_contains_weekly_table(self, mock_forecast_result):
        collector = SourceCollector()
        output = render_forecast_brief(mock_forecast_result, collector)
        assert output is not None
        assert "| Week |" in output

    def test_contains_summary_table(self, mock_forecast_result):
        collector = SourceCollector()
        output = render_forecast_brief(mock_forecast_result, collector)
        assert output is not None
        assert "| Total Revenue" in output

    def test_contains_allocation_comparison(self, mock_forecast_result):
        collector = SourceCollector()
        output = render_forecast_brief(mock_forecast_result, collector)
        assert output is not None
        assert "Meta" in output
        assert "Google" in output

    def test_contains_total_delta(self, mock_forecast_result):
        collector = SourceCollector()
        output = render_forecast_brief(mock_forecast_result, collector)
        assert output is not None
        # total_delta = 6200
        assert "$6,200" in output

    def test_contains_impact_ci(self, mock_forecast_result):
        collector = SourceCollector()
        output = render_forecast_brief(mock_forecast_result, collector)
        assert output is not None
        assert "10.2%" in output
        assert "20.8%" in output

    def test_cites_total_delta(self, mock_forecast_result):
        collector = SourceCollector()
        render_forecast_brief(mock_forecast_result, collector)
        assert "forecast-total-delta" in collector.refs

    def test_generate_readout_forecast_dispatch(self, tmp_path, mock_forecast_result):
        from datetime import date

        generate_readout(mock_forecast_result, str(tmp_path))
        run_dir = tmp_path / "MixLift" / date.today().isoformat()
        assert (run_dir / "forecast-brief.md").exists()
        # Standard MMM deliverables must NOT be written for forecast
        assert not (run_dir / "budget-memo.md").exists()
        assert not (run_dir / "channel-scorecard.md").exists()

    def test_generate_readout_mmm_no_forecast(self, tmp_path, mock_result):
        from datetime import date

        generate_readout(mock_result, str(tmp_path))
        run_dir = tmp_path / "MixLift" / date.today().isoformat()
        assert not (run_dir / "forecast-brief.md").exists()
        assert (run_dir / "budget-memo.md").exists()


# ---------------------------------------------------------------------------
# TestMixliftReadoutTool
# ---------------------------------------------------------------------------


class TestMixliftReadoutTool:
    async def test_free_tier_rejected(self, tmp_path, mock_result):
        from mixlift_mcp.license import free_tier
        from mixlift_mcp.server import mixlift_readout

        with patch(
            "mixlift_mcp.server.validate_license",
            new=AsyncMock(return_value=free_tier("Free tier")),
        ):
            response = await mixlift_readout(
                model_fingerprint="any_string",
                output_dir=str(tmp_path),
                license_key="",
            )

        parsed = json.loads(response)
        assert parsed["status"] == "error"
        assert "Growth plan" in parsed["message"]

    async def test_paid_tier_generates_files(self, tmp_path, mock_result):
        from datetime import date
        from pathlib import Path

        from mixlift_mcp.license import LicenseStatus
        from mixlift_mcp.server import _MODEL_CACHE, mixlift_readout

        test_fp = "test_fingerprint_02"
        _MODEL_CACHE[test_fp] = {"result": mock_result}

        pro_status = LicenseStatus(
            is_pro=True,
            max_channels=20,
            max_rows=100_000,
            message="Valid pro license",
        )

        with (
            patch(
                "mixlift_mcp.server.validate_license",
                new=AsyncMock(return_value=pro_status),
            ),
            patch(
                "mixlift_mcp.server._validate_output_dir",
                return_value=(Path(tmp_path), None),
            ),
        ):
            response = await mixlift_readout(
                model_fingerprint=test_fp,
                output_dir=str(tmp_path),
                license_key="pro-key-123",
            )

        del _MODEL_CACHE[test_fp]

        parsed = json.loads(response)
        assert parsed["status"] == "success"
        assert len(parsed["files_written"]) > 0

        run_dir = tmp_path / "MixLift" / date.today().isoformat()
        assert (run_dir / "budget-memo.md").exists()
        assert (run_dir / "channel-scorecard.md").exists()
        assert (run_dir / "sources.md").exists()
