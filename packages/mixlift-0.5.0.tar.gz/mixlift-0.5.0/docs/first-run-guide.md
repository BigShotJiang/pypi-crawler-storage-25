# MixLift First-Run Guide

**Get your first marketing mix analysis in under 10 minutes.**

---

## What You Are About to Analyze

MixLift ships with a sample dataset modeled on **GlowHaus**, a fictional DTC beauty brand doing roughly $5.5M in annual revenue. GlowHaus spends $30K-$80K per month across eight marketing channels:

| Channel | Typical Weekly Spend | Role |
|---|---|---|
| Google Search | $4,200 - $6,400 | Core performance channel, heavy investment |
| Meta Prospecting | $3,800 - $6,100 | Cold audience acquisition on Facebook/Instagram |
| Meta Retargeting | $1,500 - $2,500 | Warm audience retargeting (site visitors, cart abandons) |
| TikTok | $650 - $1,500 | Newer channel, still scaling |
| YouTube | $1,200 - $2,200 | Brand awareness + mid-funnel |
| Email | $410 - $680 | Owned channel, low cost |
| Affiliate | $860 - $1,280 | Commission-based partner revenue |
| Direct Mail | $0 - $2,500 | Seasonal only (catalogs in Q4) |

The data covers 52 weeks (all of 2025) and includes a Q4 holiday season spending surge in October through December -- just like a real DTC brand would have.

---

## How to Run It

### Step 1: Open your MCP-compatible AI assistant

This works in Claude Desktop, Cursor, or any client that supports MCP tools.

### Step 2: Paste this prompt

```
Run mixlift_analyze on /Users/felix/software-projects/mixlift/data/sample_8channel.csv
```

Replace the path with wherever the file lives on your machine. If you installed MixLift via pip, you can also point it at any CSV on your computer that has spend columns and a revenue column.

### Step 3: Wait for the analysis

MixLift runs a Bayesian Marketing Mix Model on your data. This takes 2-5 minutes depending on your machine. You will see a progress indicator. The model is fitting thousands of statistical samples to determine what is actually driving your revenue -- not just what correlates with it.

---

## How to Read the Results

MixLift returns several sections. Here is what each one means in plain language.

### Dollar Headline

The very first line tells you the bottom line:

> "MixLift found $X/week in budget optimization opportunity."

This is the estimated weekly revenue increase if you shift budget from over-saturated channels to under-invested ones. With the GlowHaus sample data, expect to see an opportunity in the range of $8,000-$15,000 per week.

### Channel ROAS (Return on Ad Spend)

Each channel gets a ROAS number. ROAS of 3.0x means: for every $1 you spend on that channel, you get $3 back in revenue.

What to look for:

- **High ROAS (above 3x):** This channel is efficient. Consider increasing spend if saturation allows.
- **ROAS around 1.5-2.5x:** Healthy, normal range for most paid channels.
- **ROAS below 1x:** You are losing money on this channel. Every dollar spent returns less than a dollar.

In the GlowHaus data, you should see that TikTok and Email have strong ROAS relative to their spend levels, while Google Search shows lower marginal returns because of how much budget is already allocated there.

### Saturation Traffic Lights

Each channel gets a color-coded saturation indicator:

- **Green:** Room to grow. Increasing spend will likely produce proportional returns.
- **Yellow:** Approaching saturation. Returns are starting to diminish. Spend increases will yield less than linear returns.
- **Red:** Saturated. Additional spend will produce very little additional revenue. Consider cutting or reallocating.

In the GlowHaus data, expect Google Search and Meta Prospecting to show yellow or red (they receive the most budget), while TikTok and YouTube should show green (under-invested).

### Budget Reallocation

MixLift shows you exactly how to shift budget for better results:

- Which channels to **increase** (with a dollar amount)
- Which channels to **decrease** (with a dollar amount)
- The projected **revenue lift** from the reallocation

The optimizer holds your total budget constant -- it does not tell you to spend more overall. It tells you how to spend the same amount more effectively.

### Confidence Level

Each channel's estimates come with a confidence indicator (high, moderate, or low). This tells you how certain the model is about that channel's contribution:

- **High confidence:** The model has strong evidence. Act on this.
- **Moderate confidence:** Directionally reliable, but the exact numbers could shift with more data.
- **Low confidence:** Not enough data or too much noise to be sure. Treat as a hypothesis, not a recommendation.

Channels with low spend or high spend variability tend to have lower confidence.

### Model Fit Summary

A quick health check on the analysis itself. Look for:

- **R-squared:** How much of your revenue variation the model explains. Above 0.85 is good. Below 0.70 means there are major revenue drivers not captured in your spend data (promotions, PR, seasonality effects, etc.).
- **Convergence:** Should say "converged" or show no warnings. If you see convergence warnings, the results may be less reliable.

---

## What to Do Next

After reviewing the GlowHaus sample results:

1. **Try it on your own data.** Export your marketing spend by channel (weekly or daily) into a CSV with columns ending in `_spend` and a `revenue` column. MixLift auto-detects the format.

2. **Run a scenario.** Ask: "What happens if I cut Google Search spend by 20% and move it to TikTok?" MixLift's scenario mode will project the revenue impact.

3. **Compare over time.** Run MixLift monthly. It remembers your previous analyses and shows you what changed -- which channels improved, which declined, and whether your reallocations are working.

---

## Troubleshooting

**"Analysis is taking more than 5 minutes"** -- Normal for 8 channels on a laptop. The Bayesian model is fitting 4 parallel chains. Let it finish.

**"Data validation failed"** -- Check that your CSV has a `date` column, at least 2 columns ending in `_spend`, and a `revenue` column. Dates must span at least 90 days.

**"Model fit metrics not available"** -- This can happen with very noisy data. The analysis still produces ROAS and optimization results; the fit metrics are a bonus diagnostic.

**Need help?** Email support@mixlift.io or ask your AI assistant to help troubleshoot the error message.
