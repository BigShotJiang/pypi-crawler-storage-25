# MixLift Data Science Roadmap

**Staff Data Scientist | March 7, 2026 | Confidential**

*Modeling pipeline audit, validation framework, and phased DS roadmap aligned with product priorities.*

---

## 1. Current Model Assessment

### What's Good

- **Correct Bayesian pipeline.** PyMC-Marketing NUTS sampler with 4 chains, GeometricAdstock + LogisticSaturation, posterior-based uncertainty quantification. No fixed random seeds -- R-hat is actually diagnostic.
- **Marginal ROAS via finite difference.** `extract_marginal_roas()` bumps spend by 1% and measures contribution delta. Right approach for diminishing-returns curves.
- **LOO-CV implementation.** PSIS-LOO via ArviZ with Pareto-k diagnostics and three-tier interpretation (good/fair/poor). More validation than most competitors surface.
- **Convergence diagnostics.** R-hat > 1.05 and divergence checks. 4-chain default makes R-hat reliable.
- **Posterior predictive checks.** `sample_posterior_predictive()` called during fitting, enabling R-squared and MAPE.
- **Output quality.** Dollar headlines, saturation traffic lights, confidence summaries -- genuinely differentiated from Robyn/Meridian raw output.

### What's Fragile

| Issue | Risk | Detail |
|---|---|---|
| **Priors 100% from PyMC-Marketing defaults** | Medium | `Gamma(3,1)` on saturation_lam, `Beta(1,3)` on adstock_alpha. Fine for DTC digital but wrong for offline channels or very high/low spend levels. |
| **No ESS diagnostics** | High | R-hat can pass while ESS is dangerously low. Need ESS_bulk > 400, ESS_tail > 100 per Vehtari et al. (2021). |
| **Optimizer uses point estimates** | Medium-High | `_optimize_gradient()` uses posterior mean parameters. Ignores uncertainty. Can over-allocate to noisy channels. |
| **Rigid seasonality** | Low-Medium | 6 hardcoded Fourier terms + Q4 indicator. Not data-adaptive. No weekly seasonality or weighted holiday effects. |
| **No control variable validation** | Medium | No multicollinearity check between controls and channel spend. No mechanism for user-provided controls (price, promotions, competitor spend). |

### What's Missing

| Gap | Impact | Competitor Status |
|---|---|---|
| Time-varying parameters | Stationary model can't capture iOS 14.5-type shifts | Meridian has it (GP priors) |
| Geo-level modeling | No geographic variation for causal identification | Meridian, Robyn, Recast support it |
| Experiment calibration priors | Can't incorporate geo-lift or holdout test results | Meridian, Recast, Paramark support it |
| Automated model selection | Hardcoded to Geometric + Logistic with l_max=8 | Robyn does automated hyperparameter tuning |
| Time-series cross-validation | LOO-CV can be unreliable for non-exchangeable time series | Standard in academic MMM |

---

## 2. Phased Modeling Roadmap

### Phase 1: Trust Infrastructure (Weeks 4-8)

Directly addresses the "I don't trust the model" objection. Minimal architecture changes.

| # | Item | Effort | Impact | Detail |
|---|---|---|---|---|
| P1.1 | **ESS diagnostics** | 1 day | High | Add `az.ess()` bulk + tail checks to `check_convergence()`. Warn if ESS < 400/100. |
| P1.2 | **Uncertainty-aware optimizer** | 3-5 days | High | Run optimization N times sampling different posterior draws. Return median allocation + 90% CI. Infrastructure exists in `estimate_scenario_impact_samples()`. |
| P1.3 | **Time-series cross-validation** | 3 days | High | Expanding-window CV: fit on first K weeks, predict next H weeks. Report MAPE and 90% PI coverage. |
| P1.4 | **ROAS plausibility checks** | 1 day | High | Flag negative ROAS, > 20x ROAS, negative intercept. Catches misspecification better than convergence diagnostics. |

### Phase 2: Model Quality (Weeks 8-12)

| # | Item | Effort | Impact | Detail |
|---|---|---|---|---|
| P2.1 | **Experiment calibration priors** | 1-2 wks | Very High | Accept `calibration_priors` dict mapping channels to ROAS estimates from experiments. Convert to informative priors on `saturation_beta`. Single highest-impact accuracy improvement. |
| P2.2 | **Adaptive adstock lag selection** | 3-5 days | Medium | Compare l_max in {4, 8, 12} by LOO-CV. Auto-select best. Report decision. |
| P2.3 | **Weibull adstock option** | 3-5 days | Medium | Two-parameter adstock for delayed peak effects (YouTube, podcasts). Auto-select when model detects long-lag channels. |
| P2.4 | **Custom control variables** | 3-5 days | Medium-High | Auto-detect non-channel, non-reserved CSV columns as controls. Addresses omitted variable bias. |

### Phase 3: Differentiation (Weeks 12-20)

| # | Item | Effort | Impact | Detail |
|---|---|---|---|---|
| P3.1 | **Time-varying coefficients** | 2-4 wks | Very High | Random-walk priors on intercept (v1), then channel coefficients (v2). Captures how channel effectiveness changes over time. |
| P3.2 | **Geo-level MMM** | 3-4 wks | Very High | Hierarchical Bayesian model with DMA/state-level data. Geographic spend variation provides strongest causal identification. Gold standard. |
| P3.3 | **Incrementality test integration** | 2-3 wks | High | Use MMM to design geo-lift experiments, then use results to calibrate model. Virtuous cycle. |
| P3.4 | **Automated model selection** | 2 wks | High | Parallel model specs (adstock type, lag length, saturation function). Select by LOO-CV. Eliminates "wrong model" objection. |

### Phase 4: Scale (Weeks 20+)

| # | Item | Effort | Impact | Detail |
|---|---|---|---|---|
| P4.1 | **Approximate inference** | 2 wks | Medium | ADVI or Pathfinder for fast MCP path. Full MCMC as gold standard mode. Minutes to seconds. |
| P4.2 | **Vertical benchmarks** | Ongoing | Very High | Aggregated anonymized posteriors as category-level priors. "DTC beauty Meta ROAS is typically 2-4x." Data moat. |
| P4.3 | **Causal discovery layer** | 3 wks | Medium | Granger causality / structural causal models for cross-channel interaction detection. |

---

## 3. Validation & Trust Framework

### User-Facing Model Report Card

| Signal | Implementation | User Language |
|---|---|---|
| R-hat < 1.05, no divergences, ESS > 400 | `check_convergence()` + ESS | "Model converged successfully" |
| R-squared > 80% | `_compute_model_fit()` | "Explains X% of your revenue variation" |
| LOO-CV = "good" | `compute_loo_cv()` | "Validates well on held-out data" |
| Time-series CV MAPE < 15% | New | "Would have predicted last month within X%" |
| No ROAS plausibility flags | New | "All channel estimates are within normal ranges" |
| 26+ weeks of data | Existing badge | "Sufficient data for reliable estimates" |

Combine into a single traffic light: Green (all pass), Yellow (some warnings), Red (major concerns).

### Handling "I Don't Trust the Model"

1. **"Numbers don't match my gut."** Show backtest. If model predicted accurately, data wins. If not, acknowledge and suggest more data or calibration.
2. **"I ran an experiment and got different results."** Incorporate as calibration prior (P2.1). Convert skeptic to advocate.
3. **"My last agency said something different."** Show LOO-CV comparison. Transparency builds trust.

### What Should Be Invisible

- MCMC trace plots (debug mode only)
- Raw posterior distributions
- Pareto-k values per observation (summarize as "X observations are influential")
- ELPD absolute values (only useful for model comparison)
- Adstock type / lag selection / MCMC tuning parameters

---

## 4. Communicating Uncertainty to Non-Technical Users

1. **Verbal confidence labels.** Extend `_compute_confidence_summary()` to optimizer: "We're 90% confident shifting $5K from TikTok to Meta would improve revenue by $2K-$8K/week."
2. **Scenario framing.** "Conservative: shift $3K. Optimistic: shift $8K. Best estimate: $5K." Maps to how executives decide (base/bear/bull).
3. **Relative confidence.** "We're more confident about Meta's ROAS (tight bounds) than TikTok's (wide bounds). Act on Meta first."

---

## 5. Priority Stack Rank

| Rank | Item | Impact | Effort | Rationale |
|---|---|---|---|---|
| 1 | ESS diagnostics | High | S | Prevents silently bad results. 1 day. |
| 2 | ROAS plausibility checks | High | S | Catches obviously wrong models. 1 day. |
| 3 | Uncertainty-aware optimizer | High | M | Directly improves the money recommendation. |
| 4 | Time-series CV | High | M | Most convincing validation for marketers. |
| 5 | Experiment calibration priors | Very High | L | Single biggest accuracy improvement. Differentiates from Robyn. |
| 6 | Custom control variables | Medium-High | M | Addresses omitted variable bias objection. |
| 7 | Adaptive lag selection | Medium | M | Better defaults without user effort. |
| 8 | Weibull adstock | Medium | M | Enables offline/long-cycle channels. |
| 9 | Time-varying coefficients | Very High | XL | Major quality leap. Differentiates from Robyn. |
| 10 | Geo-level MMM | Very High | XL | Gold standard. Differentiates from everything except Meridian. |

Items 1-4 ship before/alongside first 10 paying customers. Items 5-8 ship informed by customer feedback (Weeks 9-12). Items 9-10 triggered by retention data.

---

*Last updated: March 7, 2026*
*Next review: April 7, 2026*
