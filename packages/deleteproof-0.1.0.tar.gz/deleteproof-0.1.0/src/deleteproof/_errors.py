"""Exception hierarchy for the DeleteProof SDK.

Maps HTTP status codes and API error codes to typed exceptions.
Every exception includes enough context for log correlation.
"""

from __future__ import annotations


class DeleteProofError(Exception):
    """Base exception for all SDK errors."""


class APIError(DeleteProofError):
    """An error response from the DeleteProof API."""

    def __init__(
        self,
        *,
        code: str,
        message: str,
        request_id: str,
        status_code: int,
    ) -> None:
        self.code = code
        self.message = message
        self.request_id = request_id
        self.status_code = status_code
        super().__init__(f"[{status_code}] {code}: {message} (request_id={request_id})")


class AuthenticationError(APIError):
    """401 — invalid or missing API key."""


class NotFoundError(APIError):
    """404 — resource does not exist."""


class RateLimitError(APIError):
    """429 — too many requests."""

    def __init__(
        self,
        *,
        code: str,
        message: str,
        request_id: str,
        status_code: int,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(
            code=code, message=message, request_id=request_id, status_code=status_code
        )
        self.retry_after = retry_after


class ConflictError(APIError):
    """409 — resource conflict (duplicate name, concurrent update)."""


class ValidationError(APIError):
    """422 — request body failed server-side validation."""


class ServerError(APIError):
    """5xx — server-side failure."""


class TimeoutError(DeleteProofError):
    """Polling deadline exceeded."""

    def __init__(self, operation: str, elapsed: float) -> None:
        self.operation = operation
        self.elapsed = elapsed
        super().__init__(f"{operation}: timed out after {elapsed:.1f}s")


class VerificationError(DeleteProofError):
    """Offline certificate or transparency verification failed."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


_STATUS_TO_CLASS: dict[int, type[APIError]] = {
    401: AuthenticationError,
    404: NotFoundError,
    409: ConflictError,
    422: ValidationError,
    429: RateLimitError,
}


def _raise_for_error(status_code: int, body: dict, retry_after: float | None = None) -> None:
    """Parse an API error envelope and raise the appropriate exception.

    Expects ``body`` to be the parsed JSON with an ``"error"`` key.
    """
    err = body.get("error", {})
    code = err.get("code", "UNKNOWN")
    message = err.get("message", "")
    request_id = err.get("request_id", "")

    cls = _STATUS_TO_CLASS.get(status_code)
    if cls is None:
        cls = ServerError if status_code >= 500 else APIError

    if cls is RateLimitError:
        raise RateLimitError(
            code=code,
            message=message,
            request_id=request_id,
            status_code=status_code,
            retry_after=retry_after,
        )

    raise cls(
        code=code,
        message=message,
        request_id=request_id,
        status_code=status_code,
    )
