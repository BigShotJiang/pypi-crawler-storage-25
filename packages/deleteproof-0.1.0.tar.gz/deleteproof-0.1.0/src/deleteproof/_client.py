"""Sync and async clients for the DeleteProof API.

``DeleteProof`` (sync) and ``AsyncDeleteProof`` (async) share request-building
logic through ``_BaseClient``. Each method is thin: build params, call transport,
parse response.
"""

from __future__ import annotations

import asyncio
import pathlib
import time
from typing import Any

from deleteproof._errors import RateLimitError, TimeoutError
from deleteproof._http import AsyncTransport, SyncTransport
from deleteproof._models import (
    Attestation,
    CertificateResponse,
    ConsistencyProof,
    InclusionProof,
    LogEntry,
    RevocationStatus,
    SignedTreeHead,
    System,
    VerifyResult,
    Webhook,
    _parse_attestation,
    _parse_certificate_response,
    _parse_consistency_proof,
    _parse_inclusion_proof,
    _parse_log_entry,
    _parse_revocation_status,
    _parse_signed_tree_head,
    _parse_system,
    _parse_verify_result,
    _parse_webhook,
)
from deleteproof._pagination import AsyncPaginator, SyncPaginator


# ---------------------------------------------------------------------------
# Shared request-building helpers
# ---------------------------------------------------------------------------

class _BaseClient:
    """Shared logic for building request bodies and parsing responses."""

    @staticmethod
    def _build_register_body(
        *,
        name: str,
        connector_type: str,
        connection_config: dict[str, Any] | None = None,
        subject_query: str,
        hash_scope: str = "existence",
        max_records: int = 1_000_000,
        max_bytes: int = 10 * 1024 * 1024 * 1024,
        query_timeout: str = "30s",
        dsn: str | None = None,
        uri: str | None = None,
    ) -> dict[str, Any]:
        config = _resolve_connection_config(
            connection_config=connection_config, dsn=dsn, uri=uri
        )
        return {
            "name": name,
            "connector_type": connector_type,
            "connection_config": config,
            "subject_query": subject_query,
            "hash_scope": hash_scope,
            "max_records": max_records,
            "max_bytes": max_bytes,
            "query_timeout": query_timeout,
        }

    @staticmethod
    def _build_attest_body(
        subject_identifier: str,
        *,
        system_ids: list[str] | None = None,
        proof_mode: str = "count",
        expires_in: str = "72h",
        webhook_url: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "subject_identifier": subject_identifier,
            "proof_mode": proof_mode,
            "expires_in": expires_in,
        }
        if system_ids is not None:
            body["system_ids"] = system_ids
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        return body

    @staticmethod
    def _build_verify_body(subject_identifier: str) -> dict[str, Any]:
        return {"subject_identifier": subject_identifier}


# ---------------------------------------------------------------------------
# Sync client
# ---------------------------------------------------------------------------

class DeleteProof(_BaseClient):
    """Synchronous DeleteProof API client.

    Usage::

        with DeleteProof(api_key="dp_...") as dp:
            att = dp.attest("user@example.com", system_ids=["..."])
            result = dp.verify(att.id, "user@example.com", timeout=60)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.deleteproof.com",
        timeout: float = 30.0,
        max_retries: int = 2,
    ) -> None:
        self._transport = SyncTransport(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
        )

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> DeleteProof:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # --- Systems ---

    def register_system(
        self,
        *,
        name: str,
        connector_type: str,
        connection_config: dict[str, Any] | None = None,
        subject_query: str,
        hash_scope: str = "existence",
        max_records: int = 1_000_000,
        max_bytes: int = 10 * 1024 * 1024 * 1024,
        query_timeout: str = "30s",
        dsn: str | None = None,
        uri: str | None = None,
    ) -> System:
        body = self._build_register_body(
            name=name,
            connector_type=connector_type,
            connection_config=connection_config,
            subject_query=subject_query,
            hash_scope=hash_scope,
            max_records=max_records,
            max_bytes=max_bytes,
            query_timeout=query_timeout,
            dsn=dsn,
            uri=uri,
        )
        data = self._transport.request("POST", "/v1/systems", json=body)
        return _parse_system(data)

    def get_system(self, system_id: str) -> System:
        data = self._transport.request("GET", f"/v1/systems/{system_id}")
        return _parse_system(data)

    def list_systems(self, *, limit: int = 25) -> SyncPaginator[System]:
        return SyncPaginator(
            self._transport,
            "/v1/systems",
            _parse_system,
            params={"limit": limit},
        )

    def deregister_system(self, system_id: str) -> None:
        self._transport.request("DELETE", f"/v1/systems/{system_id}")

    def health_check(self, system_id: str) -> System:
        data = self._transport.request("POST", f"/v1/systems/{system_id}/health-check")
        return _parse_system(data)

    # --- Attestations ---

    def attest(
        self,
        subject_identifier: str,
        *,
        system_ids: list[str] | None = None,
        proof_mode: str = "count",
        expires_in: str = "72h",
        webhook_url: str | None = None,
    ) -> Attestation:
        body = self._build_attest_body(
            subject_identifier,
            system_ids=system_ids,
            proof_mode=proof_mode,
            expires_in=expires_in,
            webhook_url=webhook_url,
        )
        data = self._transport.request("POST", "/v1/attestations", json=body)
        return _parse_attestation(data)

    def get_attestation(self, attestation_id: str) -> Attestation:
        data = self._transport.request("GET", f"/v1/attestations/{attestation_id}")
        return _parse_attestation(data)

    def wait_for(
        self,
        attestation_id: str,
        *,
        timeout: float = 60.0,
        poll_interval: float = 2.0,
    ) -> Attestation:
        """Poll until attestation status is no longer PENDING_VERIFICATION."""
        return _poll_sync(
            fetch=lambda: self.get_attestation(attestation_id),
            done=lambda att: att.status.value != "PENDING_VERIFICATION",
            operation=f"wait_for({attestation_id})",
            timeout=timeout,
            poll_interval=poll_interval,
        )

    def verify(
        self,
        attestation_id: str,
        subject_identifier: str,
        *,
        timeout: float = 0.0,
        poll_interval: float = 2.0,
    ) -> VerifyResult:
        body = self._build_verify_body(subject_identifier)
        data = self._transport.request(
            "POST", f"/v1/attestations/{attestation_id}/verify", json=body
        )
        result = _parse_verify_result(data)

        if timeout <= 0 or result.status.value == "CERTIFIED":
            return result

        return _poll_sync(
            fetch=lambda: _parse_verify_result(
                self._transport.request(
                    "POST", f"/v1/attestations/{attestation_id}/verify", json=body
                )
            ),
            done=lambda r: r.status.value == "CERTIFIED",
            operation=f"verify({attestation_id})",
            timeout=timeout,
            poll_interval=poll_interval,
        )

    # --- Certificates ---

    def get_certificate(self, certificate_id: str) -> CertificateResponse:
        data = self._transport.request("GET", f"/v1/certificates/{certificate_id}")
        return _parse_certificate_response(data)

    def list_certificates(self, *, limit: int = 25) -> SyncPaginator[CertificateResponse]:
        return SyncPaginator(
            self._transport,
            "/v1/certificates",
            _parse_certificate_response,
            params={"limit": limit},
        )

    def download_pdf(self, certificate_id: str) -> bytes:
        return self._transport.request_bytes(
            "GET", f"/v1/certificates/{certificate_id}/pdf"
        )

    def save_pdf(self, certificate_id: str, path: str | pathlib.Path) -> None:
        pdf_bytes = self.download_pdf(certificate_id)
        pathlib.Path(path).write_bytes(pdf_bytes)

    def get_revocation_status(self, certificate_id: str) -> RevocationStatus:
        data = self._transport.request(
            "GET", f"/v1/certificates/{certificate_id}/revocation-status"
        )
        return _parse_revocation_status(data)

    def revoke_certificate(self, certificate_id: str, *, reason: str) -> CertificateResponse:
        data = self._transport.request(
            "POST",
            f"/v1/certificates/{certificate_id}/revoke",
            json={"reason": reason},
        )
        return _parse_certificate_response(data)

    # --- Webhooks ---

    def register_webhook(self, *, url: str) -> Webhook:
        data = self._transport.request("POST", "/v1/webhooks", json={"url": url})
        return _parse_webhook(data)

    def list_webhooks(self, *, limit: int = 25) -> SyncPaginator[Webhook]:
        return SyncPaginator(
            self._transport,
            "/v1/webhooks",
            _parse_webhook,
            params={"limit": limit},
        )

    def delete_webhook(self, webhook_id: str) -> None:
        self._transport.request("DELETE", f"/v1/webhooks/{webhook_id}")

    # --- Transparency log (public, no auth) ---

    def get_log_head(self) -> SignedTreeHead:
        data = self._transport.request(
            "GET", "/v1/log/head", authenticated=False
        )
        return _parse_signed_tree_head(data)

    def get_log_entry(self, index: int) -> LogEntry:
        data = self._transport.request(
            "GET", f"/v1/log/entry/{index}", authenticated=False
        )
        return _parse_log_entry(data)

    def get_log_entries(self, *, start: int, end: int) -> list[LogEntry]:
        data = self._transport.request(
            "GET",
            "/v1/log/entries",
            params={"start": start, "end": end},
            authenticated=False,
        )
        return [_parse_log_entry(e) for e in data]

    def get_inclusion_proof(self, *, index: int, tree_size: int) -> InclusionProof:
        data = self._transport.request(
            "GET",
            "/v1/log/proof/inclusion",
            params={"index": index, "tree_size": tree_size},
            authenticated=False,
        )
        return _parse_inclusion_proof(data)

    def get_consistency_proof(self, *, old_size: int, new_size: int) -> ConsistencyProof:
        data = self._transport.request(
            "GET",
            "/v1/log/proof/consistency",
            params={"old_size": old_size, "new_size": new_size},
            authenticated=False,
        )
        return _parse_consistency_proof(data)


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------

class AsyncDeleteProof(_BaseClient):
    """Asynchronous DeleteProof API client.

    Usage::

        async with AsyncDeleteProof(api_key="dp_...") as dp:
            att = await dp.attest("user@example.com", system_ids=["..."])
            result = await dp.verify(att.id, "user@example.com", timeout=60)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.deleteproof.com",
        timeout: float = 30.0,
        max_retries: int = 2,
    ) -> None:
        self._transport = AsyncTransport(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
        )

    async def close(self) -> None:
        await self._transport.close()

    async def __aenter__(self) -> AsyncDeleteProof:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    # --- Systems ---

    async def register_system(
        self,
        *,
        name: str,
        connector_type: str,
        connection_config: dict[str, Any] | None = None,
        subject_query: str,
        hash_scope: str = "existence",
        max_records: int = 1_000_000,
        max_bytes: int = 10 * 1024 * 1024 * 1024,
        query_timeout: str = "30s",
        dsn: str | None = None,
        uri: str | None = None,
    ) -> System:
        body = self._build_register_body(
            name=name,
            connector_type=connector_type,
            connection_config=connection_config,
            subject_query=subject_query,
            hash_scope=hash_scope,
            max_records=max_records,
            max_bytes=max_bytes,
            query_timeout=query_timeout,
            dsn=dsn,
            uri=uri,
        )
        data = await self._transport.request("POST", "/v1/systems", json=body)
        return _parse_system(data)

    async def get_system(self, system_id: str) -> System:
        data = await self._transport.request("GET", f"/v1/systems/{system_id}")
        return _parse_system(data)

    def list_systems(self, *, limit: int = 25) -> AsyncPaginator[System]:
        return AsyncPaginator(
            self._transport,
            "/v1/systems",
            _parse_system,
            params={"limit": limit},
        )

    async def deregister_system(self, system_id: str) -> None:
        await self._transport.request("DELETE", f"/v1/systems/{system_id}")

    async def health_check(self, system_id: str) -> System:
        data = await self._transport.request(
            "POST", f"/v1/systems/{system_id}/health-check"
        )
        return _parse_system(data)

    # --- Attestations ---

    async def attest(
        self,
        subject_identifier: str,
        *,
        system_ids: list[str] | None = None,
        proof_mode: str = "count",
        expires_in: str = "72h",
        webhook_url: str | None = None,
    ) -> Attestation:
        body = self._build_attest_body(
            subject_identifier,
            system_ids=system_ids,
            proof_mode=proof_mode,
            expires_in=expires_in,
            webhook_url=webhook_url,
        )
        data = await self._transport.request("POST", "/v1/attestations", json=body)
        return _parse_attestation(data)

    async def get_attestation(self, attestation_id: str) -> Attestation:
        data = await self._transport.request(
            "GET", f"/v1/attestations/{attestation_id}"
        )
        return _parse_attestation(data)

    async def wait_for(
        self,
        attestation_id: str,
        *,
        timeout: float = 60.0,
        poll_interval: float = 2.0,
    ) -> Attestation:
        """Poll until attestation status is no longer PENDING_VERIFICATION."""
        return await _poll_async(
            fetch=lambda: self.get_attestation(attestation_id),
            done=lambda att: att.status.value != "PENDING_VERIFICATION",
            operation=f"wait_for({attestation_id})",
            timeout=timeout,
            poll_interval=poll_interval,
        )

    async def verify(
        self,
        attestation_id: str,
        subject_identifier: str,
        *,
        timeout: float = 0.0,
        poll_interval: float = 2.0,
    ) -> VerifyResult:
        body = self._build_verify_body(subject_identifier)
        data = await self._transport.request(
            "POST", f"/v1/attestations/{attestation_id}/verify", json=body
        )
        result = _parse_verify_result(data)

        if timeout <= 0 or result.status.value == "CERTIFIED":
            return result

        return await _poll_async(
            fetch=lambda: self._transport.request(
                "POST", f"/v1/attestations/{attestation_id}/verify", json=body
            ),
            done=lambda r: r.status.value == "CERTIFIED",
            operation=f"verify({attestation_id})",
            timeout=timeout,
            poll_interval=poll_interval,
            parse=_parse_verify_result,
        )

    # --- Certificates ---

    async def get_certificate(self, certificate_id: str) -> CertificateResponse:
        data = await self._transport.request(
            "GET", f"/v1/certificates/{certificate_id}"
        )
        return _parse_certificate_response(data)

    def list_certificates(self, *, limit: int = 25) -> AsyncPaginator[CertificateResponse]:
        return AsyncPaginator(
            self._transport,
            "/v1/certificates",
            _parse_certificate_response,
            params={"limit": limit},
        )

    async def download_pdf(self, certificate_id: str) -> bytes:
        return await self._transport.request_bytes(
            "GET", f"/v1/certificates/{certificate_id}/pdf"
        )

    async def save_pdf(self, certificate_id: str, path: str | pathlib.Path) -> None:
        pdf_bytes = await self.download_pdf(certificate_id)
        pathlib.Path(path).write_bytes(pdf_bytes)

    async def get_revocation_status(self, certificate_id: str) -> RevocationStatus:
        data = await self._transport.request(
            "GET", f"/v1/certificates/{certificate_id}/revocation-status"
        )
        return _parse_revocation_status(data)

    async def revoke_certificate(
        self, certificate_id: str, *, reason: str
    ) -> CertificateResponse:
        data = await self._transport.request(
            "POST",
            f"/v1/certificates/{certificate_id}/revoke",
            json={"reason": reason},
        )
        return _parse_certificate_response(data)

    # --- Webhooks ---

    async def register_webhook(self, *, url: str) -> Webhook:
        data = await self._transport.request(
            "POST", "/v1/webhooks", json={"url": url}
        )
        return _parse_webhook(data)

    def list_webhooks(self, *, limit: int = 25) -> AsyncPaginator[Webhook]:
        return AsyncPaginator(
            self._transport,
            "/v1/webhooks",
            _parse_webhook,
            params={"limit": limit},
        )

    async def delete_webhook(self, webhook_id: str) -> None:
        await self._transport.request("DELETE", f"/v1/webhooks/{webhook_id}")

    # --- Transparency log (public, no auth) ---

    async def get_log_head(self) -> SignedTreeHead:
        data = await self._transport.request(
            "GET", "/v1/log/head", authenticated=False
        )
        return _parse_signed_tree_head(data)

    async def get_log_entry(self, index: int) -> LogEntry:
        data = await self._transport.request(
            "GET", f"/v1/log/entry/{index}", authenticated=False
        )
        return _parse_log_entry(data)

    async def get_log_entries(self, *, start: int, end: int) -> list[LogEntry]:
        data = await self._transport.request(
            "GET",
            "/v1/log/entries",
            params={"start": start, "end": end},
            authenticated=False,
        )
        return [_parse_log_entry(e) for e in data]

    async def get_inclusion_proof(
        self, *, index: int, tree_size: int
    ) -> InclusionProof:
        data = await self._transport.request(
            "GET",
            "/v1/log/proof/inclusion",
            params={"index": index, "tree_size": tree_size},
            authenticated=False,
        )
        return _parse_inclusion_proof(data)

    async def get_consistency_proof(
        self, *, old_size: int, new_size: int
    ) -> ConsistencyProof:
        data = await self._transport.request(
            "GET",
            "/v1/log/proof/consistency",
            params={"old_size": old_size, "new_size": new_size},
            authenticated=False,
        )
        return _parse_consistency_proof(data)


# ---------------------------------------------------------------------------
# Polling helpers
# ---------------------------------------------------------------------------

def _poll_sync(
    *,
    fetch,
    done,
    operation: str,
    timeout: float,
    poll_interval: float,
) -> Any:
    """Poll ``fetch()`` until ``done(result)`` returns True or timeout expires."""
    deadline = time.monotonic() + timeout
    interval = poll_interval

    while True:
        elapsed = time.monotonic() - (deadline - timeout)
        if time.monotonic() >= deadline:
            raise TimeoutError(operation, elapsed)

        try:
            result = fetch()
        except RateLimitError as exc:
            if exc.retry_after is not None:
                time.sleep(exc.retry_after)
                continue
            raise

        if done(result):
            return result

        remaining = deadline - time.monotonic()
        sleep_time = min(interval, remaining)
        if sleep_time <= 0:
            raise TimeoutError(operation, elapsed)
        time.sleep(sleep_time)
        interval = min(interval * 1.5, 30.0)


async def _poll_async(
    *,
    fetch,
    done,
    operation: str,
    timeout: float,
    poll_interval: float,
    parse=None,
) -> Any:
    """Async version of ``_poll_sync``."""
    deadline = time.monotonic() + timeout
    interval = poll_interval

    while True:
        elapsed = time.monotonic() - (deadline - timeout)
        if time.monotonic() >= deadline:
            raise TimeoutError(operation, elapsed)

        try:
            raw = await fetch()
            result = parse(raw) if parse is not None else raw
        except RateLimitError as exc:
            if exc.retry_after is not None:
                await asyncio.sleep(exc.retry_after)
                continue
            raise

        if done(result):
            return result

        remaining = deadline - time.monotonic()
        sleep_time = min(interval, remaining)
        if sleep_time <= 0:
            raise TimeoutError(operation, elapsed)
        await asyncio.sleep(sleep_time)
        interval = min(interval * 1.5, 30.0)


# ---------------------------------------------------------------------------
# Connection config resolution
# ---------------------------------------------------------------------------

def _resolve_connection_config(
    *,
    connection_config: dict[str, Any] | None,
    dsn: str | None,
    uri: str | None,
) -> dict[str, Any]:
    """Resolve convenience kwargs into a connection_config dict.

    Raises ValueError if both a convenience kwarg and connection_config
    are provided.
    """
    convenience = (dsn is not None) + (uri is not None)
    if convenience > 0 and connection_config is not None:
        raise ValueError(
            "Cannot provide both connection_config and a convenience kwarg (dsn/uri). "
            "Use one or the other."
        )
    if convenience > 1:
        raise ValueError("Cannot provide both dsn and uri.")

    if dsn is not None:
        return {"dsn": dsn}
    if uri is not None:
        return {"uri": uri}
    if connection_config is not None:
        return connection_config
    return {}
