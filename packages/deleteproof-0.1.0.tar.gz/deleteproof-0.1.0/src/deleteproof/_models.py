"""Frozen dataclasses and enums for all DeleteProof API types.

Every type is immutable (frozen=True, slots=True). Parse functions are pure
and deterministic — they convert raw API dicts into typed objects with no I/O.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ProofMode(str, Enum):
    COUNT = "count"
    MERKLE = "merkle"


class AttestationStatus(str, Enum):
    PENDING_VERIFICATION = "PENDING_VERIFICATION"
    VERIFICATION_FAILED = "VERIFICATION_FAILED"
    CERTIFIED = "CERTIFIED"


class CertificateStatus(str, Enum):
    ACTIVE = "ACTIVE"
    REVOKED = "REVOKED"


class TransparencyStatus(str, Enum):
    INCLUDED = "INCLUDED"
    PENDING = "PENDING"
    FAILED = "FAILED"


class HealthStatus(str, Enum):
    HEALTHY = "HEALTHY"
    UNHEALTHY = "UNHEALTHY"
    UNKNOWN = "UNKNOWN"


class ConnectorType(str, Enum):
    POSTGRESQL = "postgresql"
    MONGODB = "mongodb"
    S3 = "s3"
    REDIS = "redis"
    ELASTICSEARCH = "elasticsearch"
    CUSTOM = "custom"


class HashScope(str, Enum):
    FULL = "full"
    EXISTENCE = "existence"


class VerificationResult(str, Enum):
    VALID = "VALID"
    INVALID = "INVALID"


class TransparencyResult(str, Enum):
    INCLUDED = "INCLUDED"
    INVALID = "INVALID"
    NOT_AVAILABLE = "NOT_AVAILABLE"


class LogEntryType(str, Enum):
    CERTIFICATE = "CERTIFICATE"
    REVOCATION = "REVOCATION"


# ---------------------------------------------------------------------------
# Timestamp parsing
# ---------------------------------------------------------------------------

def _parse_dt(raw: str) -> datetime:
    """Parse an RFC 3339 timestamp from the API.

    The server emits second-precision UTC (``2006-01-02T15:04:05Z``) for most
    fields, and nanosecond-precision for log timestamps. Python's fromisoformat
    handles both since 3.11; we strip trailing ``Z`` and replace with ``+00:00``.
    """
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    return datetime.fromisoformat(raw)


def _parse_dt_opt(raw: str | None) -> datetime | None:
    if raw is None:
        return None
    return _parse_dt(raw)


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class System:
    id: str
    name: str
    connector_type: ConnectorType
    subject_query: str
    hash_scope: HashScope
    max_records: int
    max_bytes: int
    query_timeout: str
    created_at: datetime
    health_status: HealthStatus
    health_checked_at: datetime | None
    health_error: str | None


@dataclass(frozen=True, slots=True)
class SystemAttestation:
    system_id: str
    system_name: str
    record_count: int
    hash_scope: HashScope
    observed_at: datetime


@dataclass(frozen=True, slots=True)
class Attestation:
    id: str
    subject_hash: str
    proof_mode: ProofMode
    status: AttestationStatus
    systems: tuple[SystemAttestation, ...]
    attested_at: datetime
    expires_at: datetime
    certificate_id: str | None


@dataclass(frozen=True, slots=True)
class VerificationSystem:
    system_id: str
    system_name: str
    record_count: int


@dataclass(frozen=True, slots=True)
class VerifyResult:
    attestation_id: str
    status: AttestationStatus
    systems: tuple[VerificationSystem, ...]
    certificate: CertificateResponse | None


@dataclass(frozen=True, slots=True)
class CertificateResponse:
    id: str
    attestation_id: str
    format_version: str
    issued_at: datetime
    status: CertificateStatus
    transparency_status: TransparencyStatus
    revoked_at: datetime | None
    revocation_reason: str | None
    certificate: dict  # raw DeletionCertificate JSON for offline verification


@dataclass(frozen=True, slots=True)
class RevocationStatus:
    certificate_id: str
    status: CertificateStatus
    revoked_at: datetime | None
    reason: str | None


@dataclass(frozen=True, slots=True)
class Webhook:
    id: str
    url: str
    secret: str | None
    created_at: datetime


@dataclass(frozen=True, slots=True)
class SignedTreeHead:
    tree_size: int
    root_hash: str
    timestamp: datetime
    signature: str


@dataclass(frozen=True, slots=True)
class LogEntry:
    index: int
    entry_type: LogEntryType
    certificate_id: str
    hash: str
    appended_at: datetime


@dataclass(frozen=True, slots=True)
class InclusionProof:
    index: int
    tree_size: int
    inclusion_proof: tuple[str, ...]
    signed_tree_head: SignedTreeHead


@dataclass(frozen=True, slots=True)
class ConsistencyProof:
    old_size: int
    new_size: int
    proof: tuple[str, ...]


# ---------------------------------------------------------------------------
# Parsers — one per type, pure dict → dataclass
# ---------------------------------------------------------------------------

def _parse_system(d: dict) -> System:
    return System(
        id=d["id"],
        name=d["name"],
        connector_type=ConnectorType(d["connector_type"]),
        subject_query=d["subject_query"],
        hash_scope=HashScope(d["hash_scope"]),
        max_records=d["max_records"],
        max_bytes=d["max_bytes"],
        query_timeout=d["query_timeout"],
        created_at=_parse_dt(d["created_at"]),
        health_status=HealthStatus(d.get("health_status", "UNKNOWN")),
        health_checked_at=_parse_dt_opt(d.get("health_checked_at")),
        health_error=d.get("health_error"),
    )


def _parse_system_attestation(d: dict) -> SystemAttestation:
    return SystemAttestation(
        system_id=d["system_id"],
        system_name=d["system_name"],
        record_count=d["record_count"],
        hash_scope=HashScope(d["hash_scope"]),
        observed_at=_parse_dt(d["observed_at"]),
    )


def _parse_attestation(d: dict) -> Attestation:
    return Attestation(
        id=d["id"],
        subject_hash=d["subject_hash"],
        proof_mode=ProofMode(d["proof_mode"]),
        status=AttestationStatus(d["status"]),
        systems=tuple(_parse_system_attestation(s) for s in d.get("systems", [])),
        attested_at=_parse_dt(d["attested_at"]),
        expires_at=_parse_dt(d["expires_at"]),
        certificate_id=d.get("certificate_id"),
    )


def _parse_verification_system(d: dict) -> VerificationSystem:
    return VerificationSystem(
        system_id=d["system_id"],
        system_name=d["system_name"],
        record_count=d["record_count"],
    )


def _parse_verify_result(d: dict) -> VerifyResult:
    cert_data = d.get("certificate")
    return VerifyResult(
        attestation_id=d["attestation_id"],
        status=AttestationStatus(d["status"]),
        systems=tuple(_parse_verification_system(s) for s in d.get("systems", [])),
        certificate=_parse_certificate_response(cert_data) if cert_data else None,
    )


def _parse_certificate_response(d: dict) -> CertificateResponse:
    return CertificateResponse(
        id=d["id"],
        attestation_id=d["attestation_id"],
        format_version=d["format_version"],
        issued_at=_parse_dt(d["issued_at"]),
        status=CertificateStatus(d["status"]),
        transparency_status=TransparencyStatus(d["transparency_status"]),
        revoked_at=_parse_dt_opt(d.get("revoked_at")),
        revocation_reason=d.get("revocation_reason"),
        certificate=d["certificate"],
    )


def _parse_revocation_status(d: dict) -> RevocationStatus:
    return RevocationStatus(
        certificate_id=d["certificate_id"],
        status=CertificateStatus(d["status"]),
        revoked_at=_parse_dt_opt(d.get("revoked_at")),
        reason=d.get("reason"),
    )


def _parse_webhook(d: dict) -> Webhook:
    return Webhook(
        id=d["id"],
        url=d["url"],
        secret=d.get("secret"),
        created_at=_parse_dt(d["created_at"]),
    )


def _parse_signed_tree_head(d: dict) -> SignedTreeHead:
    return SignedTreeHead(
        tree_size=d["tree_size"],
        root_hash=d["root_hash"],
        timestamp=_parse_dt(d["timestamp"]),
        signature=d["signature"],
    )


def _parse_log_entry(d: dict) -> LogEntry:
    return LogEntry(
        index=d["index"],
        entry_type=LogEntryType(d["entry_type"]),
        certificate_id=d["certificate_id"],
        hash=d["hash"],
        appended_at=_parse_dt(d["appended_at"]),
    )


def _parse_inclusion_proof(d: dict) -> InclusionProof:
    return InclusionProof(
        index=d["index"],
        tree_size=d["tree_size"],
        inclusion_proof=tuple(d.get("inclusion_proof", [])),
        signed_tree_head=_parse_signed_tree_head(d["signed_tree_head"]),
    )


def _parse_consistency_proof(d: dict) -> ConsistencyProof:
    return ConsistencyProof(
        old_size=d["old_size"],
        new_size=d["new_size"],
        proof=tuple(d.get("proof", [])),
    )
