"""Cursor-based auto-pagination for sync and async iteration.

Lazily fetches pages on first iteration and follows ``next_cursor``
until the server omits it.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import Any, Callable, TypeVar

from deleteproof._http import AsyncTransport, SyncTransport

T = TypeVar("T")


class SyncPaginator(Iterator[T]):
    """Lazily paginates a list endpoint.

    Usage::

        for system in client.list_systems():
            print(system.name)
    """

    def __init__(
        self,
        transport: SyncTransport,
        path: str,
        parser: Callable[[dict], T],
        *,
        params: dict[str, Any],
        authenticated: bool = True,
    ) -> None:
        self._transport = transport
        self._path = path
        self._parser = parser
        self._params = params
        self._authenticated = authenticated
        self._buffer: list[T] = []
        self._cursor: str | None = None
        self._exhausted = False
        self._started = False

    def __iter__(self) -> SyncPaginator[T]:
        return self

    def __next__(self) -> T:
        if self._buffer:
            return self._buffer.pop(0)
        if self._exhausted:
            raise StopIteration
        self._fetch_page()
        if not self._buffer:
            raise StopIteration
        return self._buffer.pop(0)

    def _fetch_page(self) -> None:
        params = dict(self._params)
        if self._cursor is not None:
            params["cursor"] = self._cursor
        elif self._started:
            self._exhausted = True
            return

        envelope = self._transport.request_raw(
            "GET", self._path, params=params, authenticated=self._authenticated
        )
        items = envelope.get("data", [])
        self._buffer = [self._parser(item) for item in items]
        self._cursor = envelope.get("next_cursor")
        self._started = True
        if self._cursor is None:
            self._exhausted = True


class AsyncPaginator(AsyncIterator[T]):
    """Async version of :class:`SyncPaginator`.

    Usage::

        async for system in client.list_systems():
            print(system.name)
    """

    def __init__(
        self,
        transport: AsyncTransport,
        path: str,
        parser: Callable[[dict], T],
        *,
        params: dict[str, Any],
        authenticated: bool = True,
    ) -> None:
        self._transport = transport
        self._path = path
        self._parser = parser
        self._params = params
        self._authenticated = authenticated
        self._buffer: list[T] = []
        self._cursor: str | None = None
        self._exhausted = False
        self._started = False

    def __aiter__(self) -> AsyncPaginator[T]:
        return self

    async def __anext__(self) -> T:
        if self._buffer:
            return self._buffer.pop(0)
        if self._exhausted:
            raise StopAsyncIteration
        await self._fetch_page()
        if not self._buffer:
            raise StopAsyncIteration
        return self._buffer.pop(0)

    async def _fetch_page(self) -> None:
        params = dict(self._params)
        if self._cursor is not None:
            params["cursor"] = self._cursor
        elif self._started:
            self._exhausted = True
            return

        envelope = await self._transport.request_raw(
            "GET", self._path, params=params, authenticated=self._authenticated
        )
        items = envelope.get("data", [])
        self._buffer = [self._parser(item) for item in items]
        self._cursor = envelope.get("next_cursor")
        self._started = True
        if self._cursor is None:
            self._exhausted = True
