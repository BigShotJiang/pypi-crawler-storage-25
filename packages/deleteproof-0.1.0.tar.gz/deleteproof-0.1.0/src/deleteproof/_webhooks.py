"""Webhook signature verification for incoming DeleteProof events.

The server signs webhook payloads with HMAC-SHA256 using the webhook secret.
The signature is sent in the X-DeleteProof-Signature header as a hex string.
"""

from __future__ import annotations

import hashlib
import hmac


def verify_webhook_signature(
    secret: str,
    body: bytes | str,
    signature: str,
) -> bool:
    """Verify that a webhook payload was signed by the expected secret.

    Args:
        secret: The webhook secret (raw UTF-8, as returned by the API).
        body: The raw request body bytes (or string).
        signature: The hex-encoded HMAC-SHA256 signature from X-DeleteProof-Signature.

    Returns:
        True if the signature is valid.
    """
    if not secret or not signature:
        return False

    body_bytes = body.encode("utf-8") if isinstance(body, str) else body
    expected = hmac.new(
        secret.encode("utf-8"), body_bytes, hashlib.sha256
    ).digest()

    try:
        received = bytes.fromhex(signature)
    except ValueError:
        return False

    return hmac.compare_digest(expected, received)
