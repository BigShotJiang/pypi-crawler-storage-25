"""HTTP transport layer wrapping httpx for sync and async usage.

Handles: Bearer auth, response envelope unwrapping, retry on 5xx/transport
errors, Retry-After respect on 429, and raw byte streaming for PDFs.
"""

from __future__ import annotations

import time
from typing import Any

import httpx

from deleteproof._errors import RateLimitError, _raise_for_error


class SyncTransport:
    """Synchronous HTTP transport backed by ``httpx.Client``."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout: float,
        max_retries: int,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._max_retries = max_retries
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers={"Accept": "application/json"},
        )

    def close(self) -> None:
        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        authenticated: bool = True,
    ) -> Any:
        """Make a request and return the unwrapped ``data`` field."""
        envelope = self.request_raw(
            method, path, json=json, params=params, authenticated=authenticated
        )
        return envelope.get("data")

    def request_raw(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        authenticated: bool = True,
    ) -> dict:
        """Make a request and return the full response envelope (for pagination)."""
        headers = self._auth_headers() if authenticated else {}
        last_exc: Exception | None = None

        for attempt in range(1 + self._max_retries):
            if attempt > 0:
                time.sleep(0.5 * (2 ** (attempt - 1)))

            try:
                resp = self._client.request(
                    method, path, json=json, params=params, headers=headers
                )
            except httpx.TransportError as exc:
                last_exc = exc
                continue

            if resp.status_code == 204:
                return {}

            if resp.status_code == 429:
                retry_after = _parse_retry_after(resp)
                body = _safe_json(resp)
                _raise_for_error(resp.status_code, body, retry_after=retry_after)

            if resp.status_code >= 500 and attempt < self._max_retries:
                last_exc = httpx.HTTPStatusError(
                    f"Server error {resp.status_code}",
                    request=resp.request,
                    response=resp,
                )
                continue

            if resp.status_code >= 400:
                body = _safe_json(resp)
                _raise_for_error(resp.status_code, body)

            return resp.json()

        raise httpx.TransportError(f"Request failed after {self._max_retries + 1} attempts") from last_exc

    def request_bytes(
        self,
        method: str,
        path: str,
        *,
        authenticated: bool = True,
    ) -> bytes:
        """Make a request and return raw bytes (for PDF downloads)."""
        headers = self._auth_headers() if authenticated else {}
        resp = self._client.request(method, path, headers=headers)
        if resp.status_code >= 400:
            body = _safe_json(resp)
            _raise_for_error(resp.status_code, body)
        return resp.content

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._api_key}"}


class AsyncTransport:
    """Asynchronous HTTP transport backed by ``httpx.AsyncClient``."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout: float,
        max_retries: int,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=timeout,
            headers={"Accept": "application/json"},
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        authenticated: bool = True,
    ) -> Any:
        """Make a request and return the unwrapped ``data`` field."""
        envelope = await self.request_raw(
            method, path, json=json, params=params, authenticated=authenticated
        )
        return envelope.get("data")

    async def request_raw(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        authenticated: bool = True,
    ) -> dict:
        """Make a request and return the full response envelope."""
        headers = self._auth_headers() if authenticated else {}
        last_exc: Exception | None = None

        for attempt in range(1 + self._max_retries):
            if attempt > 0:
                import asyncio
                await asyncio.sleep(0.5 * (2 ** (attempt - 1)))

            try:
                resp = await self._client.request(
                    method, path, json=json, params=params, headers=headers
                )
            except httpx.TransportError as exc:
                last_exc = exc
                continue

            if resp.status_code == 204:
                return {}

            if resp.status_code == 429:
                retry_after = _parse_retry_after(resp)
                body = _safe_json(resp)
                _raise_for_error(resp.status_code, body, retry_after=retry_after)

            if resp.status_code >= 500 and attempt < self._max_retries:
                last_exc = httpx.HTTPStatusError(
                    f"Server error {resp.status_code}",
                    request=resp.request,
                    response=resp,
                )
                continue

            if resp.status_code >= 400:
                body = _safe_json(resp)
                _raise_for_error(resp.status_code, body)

            return resp.json()

        raise httpx.TransportError(f"Request failed after {self._max_retries + 1} attempts") from last_exc

    async def request_bytes(
        self,
        method: str,
        path: str,
        *,
        authenticated: bool = True,
    ) -> bytes:
        """Make a request and return raw bytes (for PDF downloads)."""
        headers = self._auth_headers() if authenticated else {}
        resp = await self._client.request(method, path, headers=headers)
        if resp.status_code >= 400:
            body = _safe_json(resp)
            _raise_for_error(resp.status_code, body)
        return resp.content

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._api_key}"}


def _parse_retry_after(resp: httpx.Response) -> float | None:
    raw = resp.headers.get("Retry-After")
    if raw is None:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


def _safe_json(resp: httpx.Response) -> dict:
    try:
        return resp.json()
    except Exception:
        return {"error": {"code": "UNKNOWN", "message": resp.text, "request_id": ""}}
