"""Offline certificate and transparency verification.

Ports the Go signing payload builders (core/payload.go) and Merkle tree
verification (core/merkle.go) to Python. All functions are pure — no I/O.

Critical encoding details:
  - Go's json.Marshal encodes []byte as base64, [N]byte as number arrays.
  - The payload builders normalize both formats to lowercase hex strings.
  - Timestamps in payloads use second-precision UTC: "2006-01-02T15:04:05Z".
  - RFC 8785 canonical JSON: sorted keys recursively, no whitespace.
  - Transparency leaf = SHA-256(0x00 || issuance_bytes(cert)), NOT the
    certificate signing payload. issuance_bytes reconstructs json.Marshal
    output at issuance time (transparency_status=PENDING, no transparency).
"""

from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from deleteproof._errors import VerificationError
from deleteproof._models import VerificationResult, TransparencyResult


# ---------------------------------------------------------------------------
# Public key info
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class PublicKeyInfo:
    """Public key metadata for offline verification.

    ``key_bytes`` is the raw 32-byte Ed25519 public key.
    ``key_id`` is ``"dp_k_" + hex(SHA-256(key_bytes))``.
    """
    key_bytes: bytes
    key_id: str
    revoked: bool = False

    @classmethod
    def from_hex(cls, hex_key: str, *, revoked: bool = False) -> PublicKeyInfo:
        raw = bytes.fromhex(hex_key)
        key_id = "dp_k_" + hashlib.sha256(raw).hexdigest()
        return cls(key_bytes=raw, key_id=key_id, revoked=revoked)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def verify_certificate(
    certificate: dict,
    public_keys: dict[str, PublicKeyInfo],
) -> VerificationResult:
    """Verify all signatures on a deletion certificate offline.

    Checks (in order):
      1. Issuer key is known and not revoked.
      2. Attestation signature is valid.
      3. Verification signature is valid.
      4. Certificate signature is valid.

    Returns ``VerificationResult.VALID`` on success.
    Raises ``VerificationError`` with a specific reason on failure.
    """
    issuer = certificate["issuer"]
    key_id = issuer["key_id"]

    pki = public_keys.get(key_id)
    if pki is None:
        raise VerificationError(f"unknown issuer key: {key_id}")
    if pki.revoked:
        raise VerificationError(f"issuer key is revoked: {key_id}")

    pub = Ed25519PublicKey.from_public_bytes(pki.key_bytes)

    # 1. Attestation signature
    att_payload = _build_attestation_payload(certificate["subject"], certificate["attestation"])
    att_sig = _decode_signature(certificate["attestation"]["attestation_signature"])
    if not _verify_ed25519(pub, att_payload, att_sig):
        raise VerificationError("attestation signature is invalid")

    # 2. Verification signature
    ver_payload = _build_verification_payload(
        certificate["attestation_id"], certificate["verification"]
    )
    ver_sig = _decode_signature(certificate["verification"]["verification_signature"])
    if not _verify_ed25519(pub, ver_payload, ver_sig):
        raise VerificationError("verification signature is invalid")

    # 3. Certificate signature
    cert_payload = _build_certificate_payload(certificate)
    cert_sig = _decode_signature(certificate["certificate_signature"])
    if not _verify_ed25519(pub, cert_payload, cert_sig):
        raise VerificationError("certificate signature is invalid")

    return VerificationResult.VALID


def verify_transparency(
    certificate: dict,
    public_keys: dict[str, PublicKeyInfo],
) -> TransparencyResult:
    """Verify the transparency proof embedded in a certificate.

    Checks:
      1. Tree head signature is valid.
      2. Merkle inclusion proof is valid.

    Returns ``TransparencyResult.INCLUDED`` on success.
    Returns ``TransparencyResult.NOT_AVAILABLE`` if no transparency proof exists.
    Raises ``VerificationError`` on invalid proof.
    """
    transparency = certificate.get("transparency")
    if transparency is None:
        return TransparencyResult.NOT_AVAILABLE

    sth = transparency["signed_tree_head"]
    issuer = certificate["issuer"]
    key_id = issuer["key_id"]

    pki = public_keys.get(key_id)
    if pki is None:
        raise VerificationError(f"unknown issuer key: {key_id}")
    if pki.revoked:
        raise VerificationError(f"issuer key is revoked: {key_id}")

    pub = Ed25519PublicKey.from_public_bytes(pki.key_bytes)

    # 1. Tree head signature
    head_payload = _build_tree_head_payload(sth)
    head_sig = _decode_signature(sth["signature"])
    if not _verify_ed25519(pub, head_payload, head_sig):
        raise VerificationError("tree head signature is invalid")

    # 2. Merkle inclusion proof — leaf is hash of issuance-time certificate JSON,
    # NOT the canonical signing payload. Matches Go's core.IssuanceBytes(cert).
    issuance_data = issuance_bytes(certificate)
    leaf = _hash_leaf(issuance_data)

    proof_hashes = [_decode_bytes(h) for h in transparency.get("inclusion_proof", [])]
    root = _decode_bytes(sth["root_hash"])
    index = transparency["entry_index"]
    tree_size = sth["tree_size"]

    if not _verify_inclusion(leaf, index, tree_size, proof_hashes, root):
        raise VerificationError("merkle inclusion proof is invalid")

    return TransparencyResult.INCLUDED


# ---------------------------------------------------------------------------
# Issuance bytes — matches Go's core.IssuanceBytes(cert)
# ---------------------------------------------------------------------------

def issuance_bytes(certificate: dict) -> bytes:
    """Reconstruct the certificate JSON as it existed at issuance time.

    At issuance: transparency_status = "PENDING", transparency = nil (omitted).
    Go uses json.Marshal(cert) which preserves struct field order. json.loads
    preserves key insertion order from the Go JSON, so json.dumps reproduces
    the same bytes (with separators=(',', ':') to match Go's compact output).
    """
    import copy
    clone = copy.deepcopy(certificate)
    clone["transparency_status"] = "PENDING"
    clone.pop("transparency", None)
    return json.dumps(clone, separators=(",", ":")).encode("utf-8")


# ---------------------------------------------------------------------------
# RFC 8785 Canonical JSON
# ---------------------------------------------------------------------------

def _canonical_json(obj: object) -> bytes:
    """Serialize to RFC 8785 canonical JSON: sorted keys, no whitespace."""
    return json.dumps(
        obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


# ---------------------------------------------------------------------------
# Byte encoding helpers
# ---------------------------------------------------------------------------

def _to_hex(value: str | list[int]) -> str:
    """Convert a byte field to lowercase hex. Handles:
    - hex string (from hand-crafted test data)
    - base64 string (from Go's json.Marshal of []byte slices)
    - list[int] (from Go's json.Marshal of [N]byte fixed arrays)
    """
    if isinstance(value, list):
        return bytes(value).hex()
    try:
        bytes.fromhex(value)
        return value.lower()
    except ValueError:
        return base64.b64decode(value).hex()


def _decode_signature(value: str | list[int]) -> bytes:
    """Decode a signature field to raw bytes. Same format handling as _to_hex."""
    if isinstance(value, list):
        return bytes(value)
    try:
        raw = bytes.fromhex(value)
        if len(raw) == 64:
            return raw
    except ValueError:
        pass
    return base64.b64decode(value)


def _decode_bytes(value: str | list[int]) -> bytes:
    """Decode a hash/bytes field to raw bytes. Same format handling as _to_hex."""
    if isinstance(value, list):
        return bytes(value)
    try:
        return bytes.fromhex(value)
    except ValueError:
        return base64.b64decode(value)


def _format_timestamp(ts: str) -> str:
    """Normalize a timestamp to second-precision UTC format for payloads.

    The payload format is always ``YYYY-MM-DDTHH:MM:SSZ`` (no fractional seconds).
    """
    # Strip fractional seconds and timezone offset, replace with Z
    if "." in ts:
        ts = ts[:ts.index(".")]
    if ts.endswith("Z"):
        return ts
    if "+" in ts:
        ts = ts[:ts.index("+")]
    elif ts.count("-") == 3:
        # Handles -HH:MM offset
        ts = ts[:ts.rindex("-")]
    return ts + "Z"


# ---------------------------------------------------------------------------
# Payload builders — exact ports of core/payload.go
# ---------------------------------------------------------------------------

def _build_attestation_payload(subject: dict, att: dict) -> bytes:
    """Port of Go's BuildAttestationPayload."""
    attested_at = _format_timestamp(att["attested_at"])

    systems = []
    for s in att["systems"]:
        sys: dict = {
            "canonical_version": s.get("canonical_version"),
            "connector_type": s["connector_type"],
            "hash_scope": s["hash_scope"],
            "merkle_root": _to_hex(s["merkle_root"]) if s.get("merkle_root") else None,
            "observed_at": attested_at,
            "record_count": s["record_count"],
            "system_id": s["system_name"],
        }
        systems.append(sys)

    payload = {
        "attested_at": attested_at,
        "proof_mode": att["proof_mode"],
        "subject_hash": _to_hex(subject["identifier_hash"]),
        "systems": systems,
    }
    return _canonical_json(payload)


def _build_verification_payload(attestation_id: str, ver: dict) -> bytes:
    """Port of Go's BuildVerificationPayload."""
    verified_at = _format_timestamp(ver["verified_at"])

    systems = []
    for s in ver["systems"]:
        sys: dict = {
            "observed_at": verified_at,
            "record_count": s["record_count"],
            "system_id": s["system_name"],
        }
        systems.append(sys)

    payload = {
        "attestation_id": attestation_id,
        "systems": systems,
        "verified_at": verified_at,
    }
    return _canonical_json(payload)


def _build_certificate_payload(cert: dict) -> bytes:
    """Port of Go's BuildCertificatePayload.

    Excludes: certificate_signature, transparency_status, transparency.
    """
    att = cert["attestation"]
    ver = cert["verification"]
    issuer = cert["issuer"]
    subject = cert["subject"]

    # Attestation systems — uses "system_name" field name
    att_systems = []
    for s in att["systems"]:
        sys: dict = {
            "canonical_version": s.get("canonical_version"),
            "connector_type": s["connector_type"],
            "hash_scope": s["hash_scope"],
            "merkle_root": _to_hex(s["merkle_root"]) if s.get("merkle_root") else None,
            "record_count": s["record_count"],
            "system_name": s["system_name"],
        }
        att_systems.append(sys)

    att_obj = {
        "attestation_signature": _to_hex(att["attestation_signature"]),
        "attested_at": _format_timestamp(att["attested_at"]),
        "proof_mode": att["proof_mode"],
        "systems": att_systems,
    }

    # Verification systems — uses "system_name" field name
    ver_systems = []
    for s in ver["systems"]:
        sys = {
            "connector_type": s["connector_type"],
            "record_count": s["record_count"],
            "system_name": s["system_name"],
        }
        ver_systems.append(sys)

    ver_obj = {
        "systems": ver_systems,
        "verification_signature": _to_hex(ver["verification_signature"]),
        "verified_at": _format_timestamp(ver["verified_at"]),
    }

    issuer_obj = {
        "key_id": issuer["key_id"],
        "name": issuer["name"],
        "public_key": _to_hex(issuer["public_key"]),
    }

    subject_obj = {
        "identifier_hash": _to_hex(subject["identifier_hash"]),
        "identifier_type_hint": subject["identifier_type_hint"],
    }

    # Revocation
    revocation: dict | None = None
    if cert.get("revocation") is not None:
        rev = cert["revocation"]
        revocation = {
            "reason": rev["reason"],
            "replacement_certificate_id": rev.get("replacement_certificate_id"),
            "revoked_at": _format_timestamp(rev["revoked_at"]),
        }

    payload = {
        "attestation": att_obj,
        "attestation_id": cert["attestation_id"],
        "certificate_format_version": cert["certificate_format_version"],
        "certificate_id": cert["certificate_id"],
        "issued_at": _format_timestamp(cert["issued_at"]),
        "issuer": issuer_obj,
        "revocation": revocation,
        "status": cert["status"],
        "subject": subject_obj,
        "verification": ver_obj,
    }
    return _canonical_json(payload)


def _build_tree_head_payload(head: dict) -> bytes:
    """Port of Go's BuildTreeHeadPayload."""
    payload = {
        "root_hash": _to_hex(head["root_hash"]),
        "timestamp": _format_timestamp(head["timestamp"]),
        "tree_size": head["tree_size"],
    }
    return _canonical_json(payload)


# ---------------------------------------------------------------------------
# Ed25519 verification
# ---------------------------------------------------------------------------

def _verify_ed25519(pub: Ed25519PublicKey, payload: bytes, signature: bytes) -> bool:
    """Verify an Ed25519 signature. Returns False on failure instead of raising."""
    try:
        pub.verify(signature, payload)
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Merkle tree (RFC 6962) — ports of core/merkle.go
# ---------------------------------------------------------------------------

def _hash_leaf(data: bytes) -> bytes:
    """SHA-256(0x00 || data) — RFC 6962 leaf hash."""
    h = hashlib.sha256()
    h.update(b"\x00")
    h.update(data)
    return h.digest()


def _hash_node(left: bytes, right: bytes) -> bytes:
    """SHA-256(0x01 || left || right) — RFC 6962 interior node hash."""
    h = hashlib.sha256()
    h.update(b"\x01")
    h.update(left)
    h.update(right)
    return h.digest()


def _split_point(n: int) -> int:
    """Largest power of 2 strictly less than n."""
    k = 1
    while k * 2 < n:
        k *= 2
    return k


def _verify_inclusion(
    leaf: bytes,
    index: int,
    size: int,
    proof: list[bytes],
    root: bytes,
) -> bool:
    """Verify a Merkle inclusion proof (RFC 6962).

    Port of Go's VerifyInclusion.
    """
    if size == 0 or index >= size:
        return False
    if size == 1:
        return len(proof) == 0 and leaf == root

    computed, consumed = _chain_inclusion(leaf, index, size, proof)
    return consumed == len(proof) and computed == root


def _chain_inclusion(
    leaf: bytes,
    index: int,
    n: int,
    proof: list[bytes],
) -> tuple[bytes, int]:
    """Rebuild root from leaf and proof elements.

    Port of Go's chainInclusion.
    """
    if n == 1:
        return leaf, 0

    k = _split_point(n)
    if index < k:
        inner, used = _chain_inclusion(leaf, index, k, proof)
        if used >= len(proof):
            return inner, used + 1
        return _hash_node(inner, proof[used]), used + 1
    else:
        inner, used = _chain_inclusion(leaf, index - k, n - k, proof)
        if used >= len(proof):
            return inner, used + 1
        return _hash_node(proof[used], inner), used + 1


def _verify_consistency(
    old_size: int,
    new_size: int,
    old_root: bytes,
    new_root: bytes,
    proof: list[bytes],
) -> bool:
    """Verify a Merkle consistency proof (RFC 6962 Section 2.1.4).

    Port of Go's VerifyConsistency.
    """
    if old_size == 0 or new_size == 0 or old_size > new_size:
        return False
    if old_size == new_size:
        return len(proof) == 0 and old_root == new_root

    p_idx = 0

    if _is_pow2(old_size):
        fr = old_root
        sr = old_root
    else:
        if p_idx >= len(proof):
            return False
        fr = proof[p_idx]
        sr = proof[p_idx]
        p_idx += 1

    fn = old_size - 1
    sn = new_size - 1

    while fn & 1 == 1:
        fn >>= 1
        sn >>= 1

    while p_idx < len(proof):
        c = proof[p_idx]
        p_idx += 1

        if fn & 1 == 1 or fn == sn:
            fr = _hash_node(c, fr)
            sr = _hash_node(c, sr)
            while fn != 0 and fn & 1 == 0:
                fn >>= 1
                sn >>= 1
        else:
            sr = _hash_node(sr, c)

        fn >>= 1
        sn >>= 1

    return sn == 0 and fr == old_root and sr == new_root


def _is_pow2(n: int) -> bool:
    return n > 0 and (n & (n - 1)) == 0
