"""DeleteProof Python SDK.

Usage::

    from deleteproof import DeleteProof

    with DeleteProof(api_key="dp_...") as dp:
        att = dp.attest("user@example.com", system_ids=["..."])
        result = dp.verify(att.id, "user@example.com", timeout=60)
        cert = dp.get_certificate(result.certificate.id)
"""

from deleteproof._client import AsyncDeleteProof, DeleteProof
from deleteproof._errors import (
    APIError,
    AuthenticationError,
    ConflictError,
    DeleteProofError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
    VerificationError,
)
from deleteproof._models import (
    Attestation,
    AttestationStatus,
    CertificateResponse,
    CertificateStatus,
    ConnectorType,
    ConsistencyProof,
    HashScope,
    HealthStatus,
    InclusionProof,
    LogEntry,
    LogEntryType,
    ProofMode,
    RevocationStatus,
    SignedTreeHead,
    System,
    SystemAttestation,
    TransparencyResult,
    TransparencyStatus,
    VerificationResult,
    VerificationSystem,
    VerifyResult,
    Webhook,
)
from deleteproof._pagination import AsyncPaginator, SyncPaginator
from deleteproof._verify import PublicKeyInfo, issuance_bytes, verify_certificate, verify_transparency
from deleteproof._webhooks import verify_webhook_signature

__all__ = [
    # Clients
    "DeleteProof",
    "AsyncDeleteProof",
    # Verification
    "verify_certificate",
    "verify_transparency",
    "issuance_bytes",
    "verify_webhook_signature",
    "PublicKeyInfo",
    # Models
    "Attestation",
    "CertificateResponse",
    "ConsistencyProof",
    "InclusionProof",
    "LogEntry",
    "RevocationStatus",
    "SignedTreeHead",
    "System",
    "SystemAttestation",
    "VerificationSystem",
    "VerifyResult",
    "Webhook",
    # Enums
    "AttestationStatus",
    "CertificateStatus",
    "ConnectorType",
    "HashScope",
    "HealthStatus",
    "LogEntryType",
    "ProofMode",
    "TransparencyResult",
    "TransparencyStatus",
    "VerificationResult",
    # Pagination
    "AsyncPaginator",
    "SyncPaginator",
    # Errors
    "APIError",
    "AuthenticationError",
    "ConflictError",
    "DeleteProofError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimeoutError",
    "ValidationError",
    "VerificationError",
]
