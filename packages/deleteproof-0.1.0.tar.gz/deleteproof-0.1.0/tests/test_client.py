"""Tests for the synchronous DeleteProof client."""

from __future__ import annotations

import httpx
import pytest
import respx

from deleteproof import (
    AttestationStatus,
    AuthenticationError,
    DeleteProof,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from tests.conftest import (
    API_KEY,
    BASE_URL,
    SAMPLE_ATTESTATION,
    SAMPLE_CERTIFICATE,
    SAMPLE_CONSISTENCY_PROOF,
    SAMPLE_INCLUSION_PROOF,
    SAMPLE_LOG_ENTRY,
    SAMPLE_REVOCATION_STATUS,
    SAMPLE_SIGNED_TREE_HEAD,
    SAMPLE_SYSTEM,
    SAMPLE_VERIFY_RESULT,
    SAMPLE_WEBHOOK,
    data_response,
    error_response,
    list_response,
    no_content_response,
)


class TestSystemMethods:
    def test_register_system(self, mock_api, client) -> None:
        mock_api.post("/v1/systems").mock(return_value=data_response(SAMPLE_SYSTEM, 201))
        sys = client.register_system(
            name="users-db",
            connector_type="postgresql",
            dsn="postgres://localhost/test",
            subject_query="SELECT 1",
        )
        assert sys.name == "users-db"
        assert sys.connector_type.value == "postgresql"

    def test_register_system_rejects_both_dsn_and_config(self, client) -> None:
        with pytest.raises(ValueError, match="Cannot provide both"):
            client.register_system(
                name="x",
                connector_type="postgresql",
                dsn="postgres://...",
                connection_config={"dsn": "..."},
                subject_query="SELECT 1",
            )

    def test_get_system(self, mock_api, client) -> None:
        mock_api.get("/v1/systems/sys-001").mock(return_value=data_response(SAMPLE_SYSTEM))
        sys = client.get_system("sys-001")
        assert sys.id == "sys-001"

    def test_list_systems(self, mock_api, client) -> None:
        mock_api.get("/v1/systems").mock(return_value=list_response([SAMPLE_SYSTEM]))
        systems = list(client.list_systems())
        assert len(systems) == 1
        assert systems[0].name == "users-db"

    def test_deregister_system(self, mock_api, client) -> None:
        mock_api.delete("/v1/systems/sys-001").mock(return_value=no_content_response())
        client.deregister_system("sys-001")

    def test_health_check(self, mock_api, client) -> None:
        mock_api.post("/v1/systems/sys-001/health-check").mock(
            return_value=data_response(SAMPLE_SYSTEM)
        )
        sys = client.health_check("sys-001")
        assert sys.health_status.value == "HEALTHY"


class TestAttestationMethods:
    def test_attest(self, mock_api, client) -> None:
        mock_api.post("/v1/attestations").mock(
            return_value=data_response(SAMPLE_ATTESTATION, 201)
        )
        att = client.attest("user@example.com", system_ids=["sys-001"])
        assert att.status == AttestationStatus.PENDING_VERIFICATION

    def test_get_attestation(self, mock_api, client) -> None:
        mock_api.get("/v1/attestations/att-001").mock(
            return_value=data_response(SAMPLE_ATTESTATION)
        )
        att = client.get_attestation("att-001")
        assert att.id == "att-001"

    def test_verify(self, mock_api, client) -> None:
        mock_api.post("/v1/attestations/att-001/verify").mock(
            return_value=data_response(SAMPLE_VERIFY_RESULT)
        )
        result = client.verify("att-001", "user@example.com")
        assert result.status == AttestationStatus.CERTIFIED
        assert result.certificate is not None


class TestCertificateMethods:
    def test_get_certificate(self, mock_api, client) -> None:
        mock_api.get("/v1/certificates/cert-001").mock(
            return_value=data_response(SAMPLE_CERTIFICATE)
        )
        cert = client.get_certificate("cert-001")
        assert cert.id == "cert-001"

    def test_download_pdf(self, mock_api, client) -> None:
        mock_api.get("/v1/certificates/cert-001/pdf").mock(
            return_value=httpx.Response(200, content=b"%PDF-1.4 fake")
        )
        pdf = client.download_pdf("cert-001")
        assert pdf.startswith(b"%PDF")

    def test_get_revocation_status(self, mock_api, client) -> None:
        mock_api.get("/v1/certificates/cert-001/revocation-status").mock(
            return_value=data_response(SAMPLE_REVOCATION_STATUS)
        )
        status = client.get_revocation_status("cert-001")
        assert status.status.value == "ACTIVE"

    def test_revoke_certificate(self, mock_api, client) -> None:
        revoked = dict(SAMPLE_CERTIFICATE, status="REVOKED")
        mock_api.post("/v1/certificates/cert-001/revoke").mock(
            return_value=data_response(revoked)
        )
        cert = client.revoke_certificate("cert-001", reason="GDPR request")
        assert cert.status.value == "REVOKED"


class TestWebhookMethods:
    def test_register_webhook(self, mock_api, client) -> None:
        mock_api.post("/v1/webhooks").mock(
            return_value=data_response(SAMPLE_WEBHOOK, 201)
        )
        wh = client.register_webhook(url="https://example.com/webhook")
        assert wh.secret == "abc123"

    def test_list_webhooks(self, mock_api, client) -> None:
        mock_api.get("/v1/webhooks").mock(return_value=list_response([SAMPLE_WEBHOOK]))
        webhooks = list(client.list_webhooks())
        assert len(webhooks) == 1

    def test_delete_webhook(self, mock_api, client) -> None:
        mock_api.delete("/v1/webhooks/wh-001").mock(return_value=no_content_response())
        client.delete_webhook("wh-001")


class TestTransparencyLogMethods:
    def test_get_log_head(self, mock_api, client) -> None:
        mock_api.get("/v1/log/head").mock(
            return_value=data_response(SAMPLE_SIGNED_TREE_HEAD)
        )
        head = client.get_log_head()
        assert head.tree_size == 42

    def test_get_log_entry(self, mock_api, client) -> None:
        mock_api.get("/v1/log/entry/0").mock(
            return_value=data_response(SAMPLE_LOG_ENTRY)
        )
        entry = client.get_log_entry(0)
        assert entry.entry_type.value == "CERTIFICATE"

    def test_get_log_entries(self, mock_api, client) -> None:
        mock_api.get("/v1/log/entries").mock(
            return_value=data_response([SAMPLE_LOG_ENTRY])
        )
        entries = client.get_log_entries(start=0, end=1)
        assert len(entries) == 1

    def test_get_inclusion_proof(self, mock_api, client) -> None:
        mock_api.get("/v1/log/proof/inclusion").mock(
            return_value=data_response(SAMPLE_INCLUSION_PROOF)
        )
        proof = client.get_inclusion_proof(index=0, tree_size=4)
        assert len(proof.inclusion_proof) == 2

    def test_get_consistency_proof(self, mock_api, client) -> None:
        mock_api.get("/v1/log/proof/consistency").mock(
            return_value=data_response(SAMPLE_CONSISTENCY_PROOF)
        )
        proof = client.get_consistency_proof(old_size=2, new_size=4)
        assert len(proof.proof) == 1


class TestErrorMapping:
    def test_401_raises_authentication_error(self, mock_api, client) -> None:
        mock_api.get("/v1/systems/x").mock(
            return_value=error_response(401, "UNAUTHORIZED", "bad key")
        )
        with pytest.raises(AuthenticationError) as exc_info:
            client.get_system("x")
        assert exc_info.value.status_code == 401

    def test_404_raises_not_found(self, mock_api, client) -> None:
        mock_api.get("/v1/systems/x").mock(
            return_value=error_response(404, "NOT_FOUND", "no such system")
        )
        with pytest.raises(NotFoundError):
            client.get_system("x")

    def test_422_raises_validation_error(self, mock_api, client) -> None:
        mock_api.post("/v1/systems").mock(
            return_value=error_response(422, "VALIDATION_ERROR", "name required")
        )
        with pytest.raises(ValidationError):
            client.register_system(
                name="", connector_type="postgresql",
                subject_query="SELECT 1",
            )

    def test_429_raises_rate_limit_error(self, mock_api, client) -> None:
        mock_api.get("/v1/systems/x").mock(
            return_value=httpx.Response(
                429,
                json={"error": {"code": "RATE_LIMITED", "message": "slow down", "request_id": "r1"}},
                headers={"Retry-After": "5"},
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            client.get_system("x")
        assert exc_info.value.retry_after == 5.0

    def test_500_raises_server_error(self, mock_api, client) -> None:
        mock_api.get("/v1/systems/x").mock(
            return_value=error_response(500, "INTERNAL", "oops")
        )
        with pytest.raises(ServerError):
            client.get_system("x")


class TestContextManager:
    def test_sync_context_manager(self, mock_api) -> None:
        mock_api.get("/v1/log/head").mock(
            return_value=data_response(SAMPLE_SIGNED_TREE_HEAD)
        )
        with DeleteProof(api_key=API_KEY, base_url=BASE_URL, max_retries=0) as dp:
            head = dp.get_log_head()
            assert head.tree_size == 42
