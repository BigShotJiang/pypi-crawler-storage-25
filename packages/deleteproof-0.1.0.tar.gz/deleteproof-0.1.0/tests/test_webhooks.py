"""Tests for webhook signature verification."""

from __future__ import annotations

import hashlib
import hmac

from deleteproof._webhooks import verify_webhook_signature


def _sign(secret: str, body: str) -> str:
    return hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()


class TestVerifyWebhookSignature:
    SECRET = "whsec_test_secret_value"
    BODY = '{"event":"certificate.issued","certificate_id":"cert-001"}'

    def test_valid_signature(self) -> None:
        sig = _sign(self.SECRET, self.BODY)
        assert verify_webhook_signature(self.SECRET, self.BODY, sig) is True

    def test_bytes_body(self) -> None:
        sig = _sign(self.SECRET, self.BODY)
        assert verify_webhook_signature(self.SECRET, self.BODY.encode(), sig) is True

    def test_wrong_secret(self) -> None:
        sig = _sign("wrong_secret", self.BODY)
        assert verify_webhook_signature(self.SECRET, self.BODY, sig) is False

    def test_tampered_body(self) -> None:
        sig = _sign(self.SECRET, self.BODY)
        tampered = self.BODY.replace("cert-001", "cert-999")
        assert verify_webhook_signature(self.SECRET, tampered, sig) is False

    def test_empty_signature(self) -> None:
        assert verify_webhook_signature(self.SECRET, self.BODY, "") is False

    def test_empty_secret(self) -> None:
        sig = _sign(self.SECRET, self.BODY)
        assert verify_webhook_signature("", self.BODY, sig) is False

    def test_invalid_hex_signature(self) -> None:
        assert verify_webhook_signature(self.SECRET, self.BODY, "not-hex!!") is False
