"""Tests for offline certificate and transparency verification.

These tests generate real Ed25519 signatures using the same payload format
as the Go server, then verify them with the Python SDK.
"""

from __future__ import annotations

import hashlib
import json

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from deleteproof._models import VerificationResult, TransparencyResult
from deleteproof._verify import (
    PublicKeyInfo,
    issuance_bytes,
    _build_attestation_payload,
    _build_certificate_payload,
    _build_tree_head_payload,
    _build_verification_payload,
    _canonical_json,
    _hash_leaf,
    _hash_node,
    _is_pow2,
    _split_point,
    _verify_consistency,
    _verify_ed25519,
    _verify_inclusion,
    verify_certificate,
    verify_transparency,
)
from deleteproof._errors import VerificationError
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _gen_keypair() -> tuple[Ed25519PrivateKey, bytes, str]:
    """Generate an Ed25519 keypair and return (private, public_bytes, key_id)."""
    priv = Ed25519PrivateKey.generate()
    pub_bytes = priv.public_key().public_bytes_raw()
    key_id = "dp_k_" + hashlib.sha256(pub_bytes).hexdigest()
    return priv, pub_bytes, key_id


def _sign(priv: Ed25519PrivateKey, data: bytes) -> str:
    """Sign data and return hex-encoded signature."""
    return priv.sign(data).hex()


def _make_certificate(priv: Ed25519PrivateKey, pub_bytes: bytes, key_id: str) -> dict:
    """Build a minimal valid DeletionCertificate dict with real signatures."""
    subject = {
        "identifier_hash": hashlib.sha256(b"user@example.com").hexdigest(),
        "identifier_type_hint": "email",
    }

    att_systems = [
        {
            "system_name": "users-db",
            "connector_type": "postgresql",
            "hash_scope": "existence",
            "record_count": 0,
            "merkle_root": None,
            "canonical_version": None,
        }
    ]

    attestation = {
        "proof_mode": "count",
        "attested_at": "2025-01-15T12:00:00Z",
        "systems": att_systems,
    }

    # Sign attestation
    att_payload = _build_attestation_payload(subject, attestation)
    attestation["attestation_signature"] = _sign(priv, att_payload)

    ver_systems = [
        {
            "system_name": "users-db",
            "connector_type": "postgresql",
            "record_count": 0,
        }
    ]

    verification = {
        "verified_at": "2025-01-15T12:05:00Z",
        "systems": ver_systems,
    }

    attestation_id = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

    # Sign verification
    ver_payload = _build_verification_payload(attestation_id, verification)
    verification["verification_signature"] = _sign(priv, ver_payload)

    cert = {
        "certificate_format_version": "1.0",
        "certificate_id": "11111111-2222-3333-4444-555555555555",
        "attestation_id": attestation_id,
        "issued_at": "2025-01-15T12:05:00Z",
        "status": "ACTIVE",
        "revocation": None,
        "issuer": {
            "name": "DeleteProof",
            "public_key": pub_bytes.hex(),
            "key_id": key_id,
        },
        "subject": subject,
        "attestation": attestation,
        "verification": verification,
    }

    # Sign certificate
    cert_payload = _build_certificate_payload(cert)
    cert["certificate_signature"] = _sign(priv, cert_payload)

    # Excluded from payload but present in the full cert
    cert["transparency_status"] = "PENDING"

    return cert


# ---------------------------------------------------------------------------
# RFC 8785 Canonical JSON
# ---------------------------------------------------------------------------

class TestCanonicalJSON:
    def test_sorts_keys(self) -> None:
        result = _canonical_json({"b": 1, "a": 2})
        assert result == b'{"a":2,"b":1}'

    def test_nested_sort(self) -> None:
        result = _canonical_json({"z": {"b": 1, "a": 2}})
        assert result == b'{"z":{"a":2,"b":1}}'

    def test_null_value(self) -> None:
        result = _canonical_json({"a": None, "b": 1})
        assert result == b'{"a":null,"b":1}'

    def test_array(self) -> None:
        result = _canonical_json({"items": [{"b": 1}, {"a": 2}]})
        assert result == b'{"items":[{"b":1},{"a":2}]}'

    def test_no_whitespace(self) -> None:
        result = _canonical_json({"key": "value"})
        assert b" " not in result
        assert b"\n" not in result


# ---------------------------------------------------------------------------
# Payload builders
# ---------------------------------------------------------------------------

class TestAttestationPayload:
    def test_field_order_and_system_id_mapping(self) -> None:
        subject = {"identifier_hash": "ab" * 16, "identifier_type_hint": "email"}
        att = {
            "proof_mode": "count",
            "attested_at": "2025-01-15T12:00:00Z",
            "systems": [
                {
                    "system_name": "users-db",
                    "connector_type": "postgresql",
                    "hash_scope": "existence",
                    "record_count": 0,
                    "merkle_root": None,
                    "canonical_version": None,
                }
            ],
        }
        payload = _build_attestation_payload(subject, att)
        parsed = json.loads(payload)

        # Top-level keys must be sorted
        assert list(parsed.keys()) == ["attested_at", "proof_mode", "subject_hash", "systems"]
        # system_id is mapped from system_name
        assert parsed["systems"][0]["system_id"] == "users-db"
        # observed_at is set to attested_at
        assert parsed["systems"][0]["observed_at"] == "2025-01-15T12:00:00Z"


class TestVerificationPayload:
    def test_field_order(self) -> None:
        ver = {
            "verified_at": "2025-01-15T12:05:00Z",
            "systems": [
                {"system_name": "users-db", "record_count": 0}
            ],
        }
        payload = _build_verification_payload("att-id", ver)
        parsed = json.loads(payload)

        assert list(parsed.keys()) == ["attestation_id", "systems", "verified_at"]
        assert parsed["systems"][0]["system_id"] == "users-db"


class TestCertificatePayload:
    def test_excludes_signature_and_transparency(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)
        payload = _build_certificate_payload(cert)
        parsed = json.loads(payload)

        assert "certificate_signature" not in parsed
        assert "transparency_status" not in parsed
        assert "transparency" not in parsed

    def test_attestation_uses_system_name(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)
        payload = _build_certificate_payload(cert)
        parsed = json.loads(payload)

        att_sys = parsed["attestation"]["systems"][0]
        assert "system_name" in att_sys
        assert "system_id" not in att_sys


class TestTreeHeadPayload:
    def test_field_order(self) -> None:
        head = {
            "tree_size": 42,
            "root_hash": "aa" * 32,
            "timestamp": "2025-01-15T13:00:00Z",
            "signature": "bb" * 64,
        }
        payload = _build_tree_head_payload(head)
        parsed = json.loads(payload)

        assert list(parsed.keys()) == ["root_hash", "timestamp", "tree_size"]


# ---------------------------------------------------------------------------
# Merkle tree
# ---------------------------------------------------------------------------

class TestMerkle:
    def test_hash_leaf(self) -> None:
        h = _hash_leaf(b"hello")
        assert len(h) == 32
        # Verify domain separation: different from plain SHA-256
        assert h != hashlib.sha256(b"hello").digest()

    def test_hash_node(self) -> None:
        left = b"\x00" * 32
        right = b"\x01" * 32
        h = _hash_node(left, right)
        assert len(h) == 32

    def test_split_point(self) -> None:
        assert _split_point(2) == 1
        assert _split_point(3) == 2
        assert _split_point(4) == 2
        assert _split_point(5) == 4
        assert _split_point(8) == 4
        assert _split_point(9) == 8

    def test_is_pow2(self) -> None:
        assert _is_pow2(1)
        assert _is_pow2(2)
        assert _is_pow2(4)
        assert not _is_pow2(3)
        assert not _is_pow2(0)


class TestVerifyInclusion:
    def _build_tree(self, n: int) -> tuple[list[bytes], bytes]:
        """Build a tree with n leaves and return (leaves, root)."""
        leaves = [_hash_leaf(str(i).encode()) for i in range(n)]
        root = self._tree_root(leaves)
        return leaves, root

    def _tree_root(self, leaves: list[bytes]) -> bytes:
        if len(leaves) == 1:
            return leaves[0]
        k = _split_point(len(leaves))
        left = self._tree_root(leaves[:k])
        right = self._tree_root(leaves[k:])
        return _hash_node(left, right)

    def _inclusion_proof(self, index: int, leaves: list[bytes]) -> list[bytes]:
        n = len(leaves)
        if n == 1:
            return []
        k = _split_point(n)
        if index < k:
            path = self._inclusion_proof(index, leaves[:k])
            return path + [self._tree_root(leaves[k:])]
        else:
            path = self._inclusion_proof(index - k, leaves[k:])
            return path + [self._tree_root(leaves[:k])]

    def test_single_leaf(self) -> None:
        leaves, root = self._build_tree(1)
        assert _verify_inclusion(leaves[0], 0, 1, [], root)

    def test_two_leaves(self) -> None:
        leaves, root = self._build_tree(2)
        proof = self._inclusion_proof(0, leaves)
        assert _verify_inclusion(leaves[0], 0, 2, proof, root)

        proof = self._inclusion_proof(1, leaves)
        assert _verify_inclusion(leaves[1], 1, 2, proof, root)

    def test_eight_leaves(self) -> None:
        leaves, root = self._build_tree(8)
        for i in range(8):
            proof = self._inclusion_proof(i, leaves)
            assert _verify_inclusion(leaves[i], i, 8, proof, root)

    def test_wrong_leaf_fails(self) -> None:
        leaves, root = self._build_tree(4)
        proof = self._inclusion_proof(0, leaves)
        wrong_leaf = _hash_leaf(b"wrong")
        assert not _verify_inclusion(wrong_leaf, 0, 4, proof, root)

    def test_wrong_root_fails(self) -> None:
        leaves, root = self._build_tree(4)
        proof = self._inclusion_proof(0, leaves)
        wrong_root = b"\xff" * 32
        assert not _verify_inclusion(leaves[0], 0, 4, proof, wrong_root)

    def test_index_out_of_range(self) -> None:
        leaves, root = self._build_tree(4)
        assert not _verify_inclusion(leaves[0], 4, 4, [], root)

    def test_empty_tree(self) -> None:
        assert not _verify_inclusion(b"\x00" * 32, 0, 0, [], b"\x00" * 32)


class TestVerifyConsistency:
    def _build_tree(self, n: int) -> tuple[list[bytes], bytes]:
        leaves = [_hash_leaf(str(i).encode()) for i in range(n)]
        root = self._tree_root(leaves)
        return leaves, root

    def _tree_root(self, leaves: list[bytes]) -> bytes:
        if len(leaves) == 1:
            return leaves[0]
        k = _split_point(len(leaves))
        left = self._tree_root(leaves[:k])
        right = self._tree_root(leaves[k:])
        return _hash_node(left, right)

    def _subproof(self, m: int, leaves: list[bytes], start_from_old: bool) -> list[bytes]:
        n = len(leaves)
        if m == n:
            if not start_from_old:
                return [self._tree_root(leaves)]
            return []
        k = _split_point(n)
        if m <= k:
            path = self._subproof(m, leaves[:k], start_from_old)
            return path + [self._tree_root(leaves[k:])]
        else:
            path = self._subproof(m - k, leaves[k:], False)
            return path + [self._tree_root(leaves[:k])]

    def test_same_size(self) -> None:
        leaves, root = self._build_tree(4)
        assert _verify_consistency(4, 4, root, root, [])

    def test_two_to_four(self) -> None:
        all_leaves = [_hash_leaf(str(i).encode()) for i in range(4)]
        old_root = self._tree_root(all_leaves[:2])
        new_root = self._tree_root(all_leaves)
        proof = self._subproof(2, all_leaves, True)
        assert _verify_consistency(2, 4, old_root, new_root, proof)

    def test_three_to_seven(self) -> None:
        all_leaves = [_hash_leaf(str(i).encode()) for i in range(7)]
        old_root = self._tree_root(all_leaves[:3])
        new_root = self._tree_root(all_leaves)
        proof = self._subproof(3, all_leaves, True)
        assert _verify_consistency(3, 7, old_root, new_root, proof)

    def test_wrong_root_fails(self) -> None:
        all_leaves = [_hash_leaf(str(i).encode()) for i in range(4)]
        old_root = self._tree_root(all_leaves[:2])
        new_root = self._tree_root(all_leaves)
        proof = self._subproof(2, all_leaves, True)
        assert not _verify_consistency(2, 4, old_root, b"\xff" * 32, proof)


# ---------------------------------------------------------------------------
# Full certificate verification
# ---------------------------------------------------------------------------

class TestVerifyCertificate:
    def test_valid_certificate(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)

        pki = PublicKeyInfo(key_bytes=pub_bytes, key_id=key_id)
        result = verify_certificate(cert, {key_id: pki})
        assert result == VerificationResult.VALID

    def test_unknown_key(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)

        with pytest.raises(VerificationError, match="unknown issuer key"):
            verify_certificate(cert, {})

    def test_revoked_key(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)

        pki = PublicKeyInfo(key_bytes=pub_bytes, key_id=key_id, revoked=True)
        with pytest.raises(VerificationError, match="revoked"):
            verify_certificate(cert, {key_id: pki})

    def test_tampered_attestation_signature(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)
        cert["attestation"]["attestation_signature"] = "00" * 64

        pki = PublicKeyInfo(key_bytes=pub_bytes, key_id=key_id)
        with pytest.raises(VerificationError, match="attestation signature"):
            verify_certificate(cert, {key_id: pki})

    def test_tampered_verification_signature(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)
        cert["verification"]["verification_signature"] = "00" * 64

        pki = PublicKeyInfo(key_bytes=pub_bytes, key_id=key_id)
        with pytest.raises(VerificationError, match="verification signature"):
            verify_certificate(cert, {key_id: pki})

    def test_tampered_certificate_signature(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)
        cert["certificate_signature"] = "00" * 64

        pki = PublicKeyInfo(key_bytes=pub_bytes, key_id=key_id)
        with pytest.raises(VerificationError, match="certificate signature"):
            verify_certificate(cert, {key_id: pki})

    def test_from_hex_constructor(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)

        pki = PublicKeyInfo.from_hex(pub_bytes.hex())
        result = verify_certificate(cert, {pki.key_id: pki})
        assert result == VerificationResult.VALID


class TestVerifyTransparency:
    def test_no_transparency_returns_not_available(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)
        # No transparency field
        cert.pop("transparency", None)

        pki = PublicKeyInfo(key_bytes=pub_bytes, key_id=key_id)
        result = verify_transparency(cert, {key_id: pki})
        assert result == TransparencyResult.NOT_AVAILABLE

    def test_valid_transparency(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)
        pki = PublicKeyInfo(key_bytes=pub_bytes, key_id=key_id)

        # Build a real transparency proof using issuance_bytes
        issuance_data = issuance_bytes(cert)
        leaf = _hash_leaf(issuance_data)

        # Simple 1-element tree: root = leaf, no proof nodes
        root = leaf

        # Sign tree head
        head = {
            "tree_size": 1,
            "root_hash": root.hex(),
            "timestamp": "2025-01-15T13:00:00Z",
        }
        head_payload = _build_tree_head_payload(head)
        head["signature"] = _sign(priv, head_payload)

        cert["transparency"] = {
            "entry_index": 0,
            "tree_size": 1,
            "inclusion_proof": [],
            "signed_tree_head": head,
        }

        result = verify_transparency(cert, {key_id: pki})
        assert result == TransparencyResult.INCLUDED

    def test_invalid_tree_head_signature(self) -> None:
        priv, pub_bytes, key_id = _gen_keypair()
        cert = _make_certificate(priv, pub_bytes, key_id)
        pki = PublicKeyInfo(key_bytes=pub_bytes, key_id=key_id)

        issuance_data = issuance_bytes(cert)
        leaf = _hash_leaf(issuance_data)

        cert["transparency"] = {
            "entry_index": 0,
            "tree_size": 1,
            "inclusion_proof": [],
            "signed_tree_head": {
                "tree_size": 1,
                "root_hash": leaf.hex(),
                "timestamp": "2025-01-15T13:00:00Z",
                "signature": "00" * 64,
            },
        }

        with pytest.raises(VerificationError, match="tree head signature"):
            verify_transparency(cert, {key_id: pki})
