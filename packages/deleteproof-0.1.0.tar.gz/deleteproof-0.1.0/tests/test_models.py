"""Tests for model parsing — pure dict → dataclass conversion."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from deleteproof._models import (
    AttestationStatus,
    CertificateStatus,
    ConnectorType,
    HashScope,
    HealthStatus,
    LogEntryType,
    ProofMode,
    TransparencyStatus,
    _parse_attestation,
    _parse_certificate_response,
    _parse_consistency_proof,
    _parse_dt,
    _parse_inclusion_proof,
    _parse_log_entry,
    _parse_revocation_status,
    _parse_signed_tree_head,
    _parse_system,
    _parse_verify_result,
    _parse_webhook,
)


class TestTimestampParsing:
    def test_parse_utc_z(self) -> None:
        dt = _parse_dt("2025-01-15T10:30:00Z")
        assert dt == datetime(2025, 1, 15, 10, 30, 0, tzinfo=timezone.utc)

    def test_parse_with_fractional_seconds(self) -> None:
        dt = _parse_dt("2025-01-15T10:30:00.123456789Z")
        assert dt.year == 2025
        assert dt.tzinfo is not None


class TestParseSystem:
    def test_all_fields(self) -> None:
        raw = {
            "id": "sys-001",
            "name": "users-db",
            "connector_type": "postgresql",
            "subject_query": "SELECT 1",
            "hash_scope": "full",
            "max_records": 500,
            "max_bytes": 1024,
            "query_timeout": "10s",
            "created_at": "2025-01-01T00:00:00Z",
            "health_status": "HEALTHY",
            "health_checked_at": "2025-01-01T01:00:00Z",
            "health_error": None,
        }
        sys = _parse_system(raw)
        assert sys.id == "sys-001"
        assert sys.name == "users-db"
        assert sys.connector_type == ConnectorType.POSTGRESQL
        assert sys.hash_scope == HashScope.FULL
        assert sys.health_status == HealthStatus.HEALTHY
        assert sys.health_checked_at is not None
        assert sys.health_error is None

    def test_frozen(self) -> None:
        raw = {
            "id": "x", "name": "x", "connector_type": "s3",
            "subject_query": "x", "hash_scope": "existence",
            "max_records": 0, "max_bytes": 0, "query_timeout": "1s",
            "created_at": "2025-01-01T00:00:00Z",
        }
        sys = _parse_system(raw)
        with pytest.raises(AttributeError):
            sys.name = "y"  # type: ignore[misc]

    def test_optional_health_fields(self) -> None:
        raw = {
            "id": "x", "name": "x", "connector_type": "mongodb",
            "subject_query": "x", "hash_scope": "existence",
            "max_records": 0, "max_bytes": 0, "query_timeout": "1s",
            "created_at": "2025-01-01T00:00:00Z",
        }
        sys = _parse_system(raw)
        assert sys.health_status == HealthStatus.UNKNOWN
        assert sys.health_checked_at is None


class TestParseAttestation:
    def test_with_systems(self) -> None:
        raw = {
            "id": "att-1",
            "subject_hash": "abcd",
            "proof_mode": "merkle",
            "status": "CERTIFIED",
            "systems": [
                {
                    "system_id": "s1",
                    "system_name": "db",
                    "record_count": 5,
                    "hash_scope": "full",
                    "observed_at": "2025-01-01T00:00:00Z",
                }
            ],
            "attested_at": "2025-01-01T00:00:00Z",
            "expires_at": "2025-01-04T00:00:00Z",
            "certificate_id": "cert-1",
        }
        att = _parse_attestation(raw)
        assert att.proof_mode == ProofMode.MERKLE
        assert att.status == AttestationStatus.CERTIFIED
        assert len(att.systems) == 1
        assert att.systems[0].system_name == "db"
        assert att.certificate_id == "cert-1"

    def test_systems_is_tuple(self) -> None:
        raw = {
            "id": "a", "subject_hash": "x", "proof_mode": "count",
            "status": "PENDING_VERIFICATION", "systems": [],
            "attested_at": "2025-01-01T00:00:00Z",
            "expires_at": "2025-01-04T00:00:00Z",
        }
        att = _parse_attestation(raw)
        assert isinstance(att.systems, tuple)


class TestParseCertificate:
    def test_active(self) -> None:
        raw = {
            "id": "c1", "attestation_id": "a1", "format_version": "1.0",
            "issued_at": "2025-01-01T00:00:00Z", "status": "ACTIVE",
            "transparency_status": "INCLUDED", "certificate": {"key": "val"},
        }
        cert = _parse_certificate_response(raw)
        assert cert.status == CertificateStatus.ACTIVE
        assert cert.transparency_status == TransparencyStatus.INCLUDED
        assert cert.revoked_at is None

    def test_revoked(self) -> None:
        raw = {
            "id": "c1", "attestation_id": "a1", "format_version": "1.0",
            "issued_at": "2025-01-01T00:00:00Z", "status": "REVOKED",
            "transparency_status": "INCLUDED", "certificate": {},
            "revoked_at": "2025-02-01T00:00:00Z", "revocation_reason": "test",
        }
        cert = _parse_certificate_response(raw)
        assert cert.status == CertificateStatus.REVOKED
        assert cert.revoked_at is not None
        assert cert.revocation_reason == "test"


class TestParseVerifyResult:
    def test_with_certificate(self) -> None:
        raw = {
            "attestation_id": "a1", "status": "CERTIFIED",
            "systems": [
                {"system_id": "s1", "system_name": "db", "record_count": 0}
            ],
            "certificate": {
                "id": "c1", "attestation_id": "a1", "format_version": "1.0",
                "issued_at": "2025-01-01T00:00:00Z", "status": "ACTIVE",
                "transparency_status": "PENDING", "certificate": {},
            },
        }
        result = _parse_verify_result(raw)
        assert result.certificate is not None
        assert result.certificate.id == "c1"

    def test_without_certificate(self) -> None:
        raw = {
            "attestation_id": "a1", "status": "PENDING_VERIFICATION",
            "systems": [],
        }
        result = _parse_verify_result(raw)
        assert result.certificate is None


class TestParseLogTypes:
    def test_signed_tree_head(self) -> None:
        raw = {
            "tree_size": 100, "root_hash": "aa" * 32,
            "timestamp": "2025-01-01T00:00:00Z", "signature": "bb" * 64,
        }
        sth = _parse_signed_tree_head(raw)
        assert sth.tree_size == 100

    def test_log_entry(self) -> None:
        raw = {
            "index": 7, "entry_type": "REVOCATION",
            "certificate_id": "c1", "hash": "cc" * 32,
            "appended_at": "2025-01-01T00:00:00Z",
        }
        entry = _parse_log_entry(raw)
        assert entry.entry_type == LogEntryType.REVOCATION
        assert entry.index == 7

    def test_inclusion_proof(self) -> None:
        raw = {
            "index": 3, "tree_size": 8,
            "inclusion_proof": ["aa" * 32, "bb" * 32],
            "signed_tree_head": {
                "tree_size": 8, "root_hash": "cc" * 32,
                "timestamp": "2025-01-01T00:00:00Z", "signature": "dd" * 64,
            },
        }
        proof = _parse_inclusion_proof(raw)
        assert len(proof.inclusion_proof) == 2
        assert isinstance(proof.inclusion_proof, tuple)

    def test_consistency_proof(self) -> None:
        raw = {"old_size": 4, "new_size": 8, "proof": ["ee" * 32]}
        proof = _parse_consistency_proof(raw)
        assert proof.old_size == 4
        assert len(proof.proof) == 1


class TestParseWebhook:
    def test_with_secret(self) -> None:
        raw = {
            "id": "w1", "url": "https://example.com",
            "secret": "s3cr3t", "created_at": "2025-01-01T00:00:00Z",
        }
        wh = _parse_webhook(raw)
        assert wh.secret == "s3cr3t"

    def test_without_secret(self) -> None:
        raw = {
            "id": "w1", "url": "https://example.com",
            "created_at": "2025-01-01T00:00:00Z",
        }
        wh = _parse_webhook(raw)
        assert wh.secret is None


class TestParseRevocationStatus:
    def test_active(self) -> None:
        raw = {"certificate_id": "c1", "status": "ACTIVE"}
        rs = _parse_revocation_status(raw)
        assert rs.status == CertificateStatus.ACTIVE
        assert rs.revoked_at is None
        assert rs.reason is None
