"""Tests for the asynchronous AsyncDeleteProof client."""

from __future__ import annotations

import httpx
import pytest
import respx

from deleteproof import AsyncDeleteProof, AttestationStatus
from tests.conftest import (
    API_KEY,
    BASE_URL,
    SAMPLE_ATTESTATION,
    SAMPLE_CERTIFICATE,
    SAMPLE_SIGNED_TREE_HEAD,
    SAMPLE_SYSTEM,
    SAMPLE_VERIFY_RESULT,
    SAMPLE_WEBHOOK,
    data_response,
    list_response,
    no_content_response,
)


pytestmark = pytest.mark.asyncio


class TestAsyncSystemMethods:
    async def test_register_system(self, mock_api, async_client) -> None:
        mock_api.post("/v1/systems").mock(return_value=data_response(SAMPLE_SYSTEM, 201))
        sys = await async_client.register_system(
            name="users-db",
            connector_type="postgresql",
            uri="mongodb://localhost/test",
            subject_query="SELECT 1",
        )
        assert sys.name == "users-db"

    async def test_get_system(self, mock_api, async_client) -> None:
        mock_api.get("/v1/systems/sys-001").mock(return_value=data_response(SAMPLE_SYSTEM))
        sys = await async_client.get_system("sys-001")
        assert sys.id == "sys-001"

    async def test_list_systems(self, mock_api, async_client) -> None:
        mock_api.get("/v1/systems").mock(return_value=list_response([SAMPLE_SYSTEM]))
        systems = []
        async for s in async_client.list_systems():
            systems.append(s)
        assert len(systems) == 1

    async def test_deregister_system(self, mock_api, async_client) -> None:
        mock_api.delete("/v1/systems/sys-001").mock(return_value=no_content_response())
        await async_client.deregister_system("sys-001")


class TestAsyncAttestationMethods:
    async def test_attest(self, mock_api, async_client) -> None:
        mock_api.post("/v1/attestations").mock(
            return_value=data_response(SAMPLE_ATTESTATION, 201)
        )
        att = await async_client.attest("user@example.com")
        assert att.status == AttestationStatus.PENDING_VERIFICATION

    async def test_verify(self, mock_api, async_client) -> None:
        mock_api.post("/v1/attestations/att-001/verify").mock(
            return_value=data_response(SAMPLE_VERIFY_RESULT)
        )
        result = await async_client.verify("att-001", "user@example.com")
        assert result.status == AttestationStatus.CERTIFIED


class TestAsyncCertificateMethods:
    async def test_get_certificate(self, mock_api, async_client) -> None:
        mock_api.get("/v1/certificates/cert-001").mock(
            return_value=data_response(SAMPLE_CERTIFICATE)
        )
        cert = await async_client.get_certificate("cert-001")
        assert cert.id == "cert-001"

    async def test_download_pdf(self, mock_api, async_client) -> None:
        mock_api.get("/v1/certificates/cert-001/pdf").mock(
            return_value=httpx.Response(200, content=b"%PDF-1.4 fake")
        )
        pdf = await async_client.download_pdf("cert-001")
        assert pdf.startswith(b"%PDF")


class TestAsyncWebhookMethods:
    async def test_register_webhook(self, mock_api, async_client) -> None:
        mock_api.post("/v1/webhooks").mock(
            return_value=data_response(SAMPLE_WEBHOOK, 201)
        )
        wh = await async_client.register_webhook(url="https://example.com/webhook")
        assert wh.secret == "abc123"

    async def test_delete_webhook(self, mock_api, async_client) -> None:
        mock_api.delete("/v1/webhooks/wh-001").mock(return_value=no_content_response())
        await async_client.delete_webhook("wh-001")


class TestAsyncTransparencyLog:
    async def test_get_log_head(self, mock_api, async_client) -> None:
        mock_api.get("/v1/log/head").mock(
            return_value=data_response(SAMPLE_SIGNED_TREE_HEAD)
        )
        head = await async_client.get_log_head()
        assert head.tree_size == 42


class TestAsyncContextManager:
    async def test_async_context_manager(self, mock_api) -> None:
        mock_api.get("/v1/log/head").mock(
            return_value=data_response(SAMPLE_SIGNED_TREE_HEAD)
        )
        async with AsyncDeleteProof(api_key=API_KEY, base_url=BASE_URL, max_retries=0) as dp:
            head = await dp.get_log_head()
            assert head.tree_size == 42
