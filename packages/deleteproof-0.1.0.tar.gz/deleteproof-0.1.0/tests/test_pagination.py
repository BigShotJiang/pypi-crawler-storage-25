"""Tests for cursor-based auto-pagination."""

from __future__ import annotations

import pytest
import respx

from deleteproof import DeleteProof, AsyncDeleteProof
from tests.conftest import (
    API_KEY,
    BASE_URL,
    SAMPLE_SYSTEM,
    list_response,
)


class TestSyncPagination:
    def test_single_page(self, mock_api, client) -> None:
        mock_api.get("/v1/systems").mock(
            return_value=list_response([SAMPLE_SYSTEM])
        )
        systems = list(client.list_systems())
        assert len(systems) == 1

    def test_multi_page(self, mock_api, client) -> None:
        sys2 = dict(SAMPLE_SYSTEM, id="sys-002", name="orders-db")
        mock_api.get("/v1/systems").mock(
            side_effect=[
                list_response([SAMPLE_SYSTEM], next_cursor="cursor-1"),
                list_response([sys2]),
            ]
        )
        systems = list(client.list_systems())
        assert len(systems) == 2
        assert systems[0].id == "sys-001"
        assert systems[1].id == "sys-002"

    def test_empty_page(self, mock_api, client) -> None:
        mock_api.get("/v1/systems").mock(return_value=list_response([]))
        systems = list(client.list_systems())
        assert len(systems) == 0

    def test_lazy_no_request_until_iterated(self, mock_api, client) -> None:
        """Paginator should not make any request until iterated."""
        paginator = client.list_systems()
        # No route mocked — would fail if a request was made
        assert paginator is not None


@pytest.mark.asyncio
class TestAsyncPagination:
    async def test_single_page(self, mock_api, async_client) -> None:
        mock_api.get("/v1/systems").mock(
            return_value=list_response([SAMPLE_SYSTEM])
        )
        systems = []
        async for s in async_client.list_systems():
            systems.append(s)
        assert len(systems) == 1

    async def test_multi_page(self, mock_api, async_client) -> None:
        sys2 = dict(SAMPLE_SYSTEM, id="sys-002", name="orders-db")
        mock_api.get("/v1/systems").mock(
            side_effect=[
                list_response([SAMPLE_SYSTEM], next_cursor="cursor-1"),
                list_response([sys2]),
            ]
        )
        systems = []
        async for s in async_client.list_systems():
            systems.append(s)
        assert len(systems) == 2
