# Layout as a user-editable Python module in the synced folder

> **RETIRED** by ADR-0042. `layout.py`, the `Layout` dataclass, the placeholder vocabulary, and the `str.format_map` plumbing are all gone — Card structure is hardcoded in the Renderer, Header content is LLM-authored at classify time (ADR-0041). Previously partially superseded by ADR-0011 amendment ("no path override knobs").

`settings/layout.py` lives alongside `config.py` in the synced folder (see ADR-0011). Plain Python: named placeholder groups, full `CARD_TEMPLATE` / `HEADLINE_TEMPLATE`. Loaded at runtime by the same `load_user_module` machinery as **Config**, validated into a frozen `Layout` dataclass, consumed by a pure **Renderer** via `str.format_map`.

When `LAYOUT` is unset, the loader defaults to `"layout.py"` next to `config.py` and **errors if missing** — matching how `USER_INFO_DIR` resolves. An explicit `LAYOUT = None` selects the built-in `layout.default()` stub (reserved for tests).

## Why

- **User iterates on layout often, package code rarely.** Field tweaks, emoji swaps, visual hierarchy — should not require editing `src/`. Co-location with `config.py` matches the edit-restart-see workflow.
- **`str.format_map` + Python constants is the lightest tool.** No Jinja, no DSL. Named placeholder groups (`PLACEHOLDER_GROUPS = {"meta": (" · ", ["location", "url"])}`) handle the dangling-separator problem.
- **Loader plumbing already exists.** `load_user_module` (extracted from Config Loader) handles `importlib.util`, missing-attr checks, typed errors. `LayoutError` and `ConfigError` share `UserSettingsError`.
- **Renderer stays pure.** Layout passed in explicitly (`render(position, verdict, layout)`); no module-level state.
- **Auto-discovery footgun closure.** A user with a valid `layout.py` who forgot to add `LAYOUT = "layout.py"` would silently get the stub. Pattern-symmetry with `USER_INFO_DIR` + fail-loud on missing closes the gap. Explicit `LAYOUT = None` keeps the stub reachable.

## Consequences

- Renderer takes a `Layout` argument; orchestrator loads once at startup and threads it through.
- `LayoutError` joins `ConfigError` under `UserSettingsError`.
- Typo in placeholder name raises `KeyError` from `str.format_map` at render time — fail-loud is intentional.
- Validation at startup: `layout_loader` checks every `placeholder_groups` entry references a known field; missing/invalid `layout.py` fails before the first fetch.
- **Null-policy** (2026-05-20): a None scalar or empty list renders as `""`; inside a group, None entries are dropped and the group collapses to `""` if all members are None. Section-level omission (drop a whole `## Section` block when its value is empty) is **not** a renderer concern — users handle it via groups or accept the empty render. Trades off the pre-ADR hardcoded renderer's nicer None-handling for genuinely template-driven output, which the previous renderer claimed to do but did not.
- **Groupable fields** include the raw Position/Verdict fields (`title, company, location, url, source, salary, contract_type, employment_type, work_model, posted_date, deadline, matched, missing`) plus the renderer-derived `location_segment` (location + Hybrid/Remote suffix per **Card**'s placeholder vocab).
