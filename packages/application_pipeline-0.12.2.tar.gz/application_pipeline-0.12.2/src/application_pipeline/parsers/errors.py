class ParserError(Exception):
    pass
