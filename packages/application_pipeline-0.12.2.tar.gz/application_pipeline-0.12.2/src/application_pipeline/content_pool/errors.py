class ContentPoolError(Exception):
    pass
