class DedupStoreError(Exception):
    pass
