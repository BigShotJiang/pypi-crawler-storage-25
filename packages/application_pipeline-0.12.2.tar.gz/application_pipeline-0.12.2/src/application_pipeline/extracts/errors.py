class ExtractStoreError(Exception):
    pass
