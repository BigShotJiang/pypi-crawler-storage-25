class ResultsFileError(Exception):
    pass
