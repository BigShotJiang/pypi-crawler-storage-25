from __future__ import annotations

from anusara._registry.loaders.python_loader import load_python_agent_factory
from anusara._registry.registration_spec import AgentRegistrationSpec
from anusara._registry.resolved_definition import ResolvedAgentDefinition
from anusara._registry.validation import validate_agent_id


def resolve_registration_spec(
    spec: AgentRegistrationSpec,
) -> ResolvedAgentDefinition:
    """
    Resolve a durable agent registration spec into a runtime-authoritative
    resolved definition.

    Raises:
        ValueError: if spec fields are invalid
        ImportError: if module import fails
        AttributeError: if symbol is missing
        TypeError: if resolved symbol is not a supported Agent class
    """
    validate_agent_id(spec.agent_id)

    if spec.namespace is not None:
        if not isinstance(spec.namespace, str) or not spec.namespace:
            raise ValueError("namespace must be a non-empty string when provided.")

    if spec.version is not None:
        if not isinstance(spec.version, str) or not spec.version:
            raise ValueError("version must be a non-empty string when provided.")

    factory, source_kind, source_ref = load_python_agent_factory(spec.source)

    return ResolvedAgentDefinition(
        agent_id=spec.agent_id,
        factory=factory,
        namespace=spec.namespace,
        version=spec.version,
        is_builtin=spec.is_builtin,
        source_kind=source_kind,
        source_ref=source_ref,
    )


__all__ = ["resolve_registration_spec"]
