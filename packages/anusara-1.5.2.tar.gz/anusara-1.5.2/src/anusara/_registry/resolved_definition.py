from __future__ import annotations

from dataclasses import dataclass

from anusara._registry.factory_protocol import AgentFactory


@dataclass(frozen=True)
class ResolvedAgentDefinition:
    """
    Runtime-authoritative agent registration record.

    This is the validated form stored in the registry after registration
    input has been normalized and resolved into executable factory-backed
    metadata.

    Fields:
    - agent_id: stable identifier used in workflow definitions and execution
    - factory: validated runtime factory used to create the agent
    - namespace: optional logical namespace (for example: "core", "nirvaha")
    - version: optional version metadata for audit/debugging/replay visibility
    - is_builtin: whether the agent is owned/shipped by Anusara
    - source_kind: resolution source category (for example: "instance",
      "class", "python_import")
    - source_ref: human-readable resolution reference explaining how the
      agent was resolved
    """

    agent_id: str
    factory: AgentFactory
    namespace: str | None = None
    version: str | None = None
    is_builtin: bool = False
    source_kind: str = "unknown"
    source_ref: str = ""


__all__ = ["ResolvedAgentDefinition"]
