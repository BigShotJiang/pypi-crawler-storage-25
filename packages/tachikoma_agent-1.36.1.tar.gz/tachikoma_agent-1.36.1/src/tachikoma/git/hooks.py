"""Bootstrap hook for git repository initialization and workspace sync.

Initializes the workspace as a git repo on first run (idempotent),
then syncs with the origin remote if configured. After a successful
sync, rebuilds the DB from diffable dump files if they changed.
"""

from pathlib import Path

from loguru import logger

from tachikoma.agent_defaults import agent_defaults_from_settings
from tachikoma.bootstrap import BootstrapContext
from tachikoma.git.db_sync import restore_database
from tachikoma.git.sync import SYNC_RESULT, run_git, smart_pull

_log = logger.bind(component="git")

# Fixed committer identity for all git commits
_COMMITTER_NAME = "Tachikoma"
_COMMITTER_EMAIL = "tachikoma@local"

# DB binary pattern added to .gitignore on fresh init
_DB_GITIGNORE_LINE = ".tachikoma/*.db\n"

# Dump directory path relative to workspace root
_DUMP_DIR_RELATIVE = ".tachikoma/db-dump"


async def git_hook(ctx: BootstrapContext) -> None:
    """Bootstrap hook: initialize workspace as a git repo and sync with remote.

    Creates a git repository with repo-local identity configuration.
    Idempotent — safe to call on every launch.
    After initialization, syncs the workspace with the origin remote.

    Args:
        ctx: Bootstrap context with settings manager.

    Raises:
        RuntimeError: If any git command fails during initialization.
    """
    workspace_path = ctx.settings_manager.settings.workspace.path
    git_dir = workspace_path / ".git"

    # Init block: only runs if .git doesn't exist
    if not git_dir.exists():
        _log.info("Initializing git repo: path={path}", path=str(workspace_path))

        await run_git("init", cwd=workspace_path)
        await run_git("config", "user.name", _COMMITTER_NAME, cwd=workspace_path)
        await run_git("config", "user.email", _COMMITTER_EMAIL, cwd=workspace_path)
        await run_git("commit", "--allow-empty", "-m", "Initial commit", cwd=workspace_path)

        await _create_gitignore(workspace_path)

        _log.info("Git repo initialized successfully")

    # Sync block: always runs after init check
    await _sync_workspace(workspace_path, ctx.settings_manager.settings)


async def _create_gitignore(workspace_path: Path) -> None:
    """Create .gitignore with DB binary exclusion on fresh init.

    Writes the gitignore line, appends if the file already exists,
    and commits the .gitignore as a second commit after the initial
    empty one.
    """
    gitignore_path = workspace_path / ".gitignore"
    existing = gitignore_path.read_text() if gitignore_path.exists() else ""

    if _DB_GITIGNORE_LINE not in existing:
        separator = "" if not existing or existing.endswith("\n") else "\n"
        gitignore_path.write_text(existing + separator + _DB_GITIGNORE_LINE)

    await run_git("add", ".gitignore", cwd=workspace_path)
    await run_git("commit", "-m", "Add gitignore for database binary", cwd=workspace_path)


async def _sync_workspace(workspace_path: Path, settings) -> None:
    """Sync workspace with origin remote using smart_pull.

    After a successful pull, checks if DB dump files changed and
    rebuilds the DB if needed. Non-blocking — all errors are caught
    and logged so startup continues.

    Args:
        workspace_path: Path to the workspace git repository.
        settings: Application settings for building agent defaults.
    """
    try:
        # Check if origin remote is configured
        try:
            await run_git("remote", "get-url", "origin", cwd=workspace_path)
        except RuntimeError:
            _log.debug("No origin remote configured, skipping sync")
            return

        # Build agent defaults following the same pattern as __main__.py
        agent_defaults = agent_defaults_from_settings(settings)

        result, changed_files = await smart_pull(workspace_path, "origin", "HEAD", agent_defaults)

        # Log result
        if result == SYNC_RESULT["DIRTY_SKIPPED"]:
            _log.warning("Workspace has uncommitted changes, skipping sync")
        elif result == SYNC_RESULT["UP_TO_DATE"]:
            _log.debug("Workspace already up to date")
        elif result in (
            SYNC_RESULT["FAST_FORWARDED"],
            SYNC_RESULT["REBASE_SUCCEEDED"],
            SYNC_RESULT["AGENT_RESOLVED"],
        ):
            _log.info("Workspace synced: result={result}", result=result)

            # Restore DB if dump files changed
            dump_changed = any(
                f == _DUMP_DIR_RELATIVE or f.startswith(f"{_DUMP_DIR_RELATIVE}/")
                for f in changed_files
            )
            if dump_changed:
                await _restore_db_if_possible(workspace_path)
        elif result == SYNC_RESULT["SYNC_FAILED"]:
            _log.warning("Workspace sync failed, continuing with local state")

    except Exception as e:
        _log.warning("Workspace sync failed: err={err}", err=str(e))


async def _restore_db_if_possible(workspace_path: Path) -> None:
    """Restore DB from dump files after a successful sync.

    Non-fatal — if restore fails, logs a warning and continues.
    database_hook will create a fresh empty DB via create_all().

    Args:
        workspace_path: Path to the workspace git repository.
    """
    db_path = workspace_path / ".tachikoma" / "tachikoma.db"
    dump_dir = workspace_path / _DUMP_DIR_RELATIVE

    if not dump_dir.exists() or not any(dump_dir.iterdir()):
        return

    try:
        await restore_database(db_path, dump_dir)
    except Exception as e:
        _log.warning(
            "DB restore failed, database_hook will create a fresh DB: err={err}",
            err=str(e),
        )
