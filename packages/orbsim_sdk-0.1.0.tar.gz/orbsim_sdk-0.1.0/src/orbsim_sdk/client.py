from __future__ import annotations

from datetime import datetime
from typing import Any, TypeVar

import httpx
from pydantic import BaseModel

from .exceptions import OrbsimAPIError
from .models import (
    AdminDashboard,
    AdminProjectInfo,
    AttitudeSample,
    AuthTokenResponse,
    BootstrapAdminRequest,
    Constellation,
    ConstellationCreate,
    ConstellationDesignCreate,
    ConstellationDesignResponse,
    ContactInterval,
    GroundStation,
    GroundStationCreate,
    HealthResponse,
    LinkBudgetRequest,
    LinkBudgetResponse,
    LoginRequest,
    NetworkResponse,
    OrbitalStateResponse,
    Project,
    ProjectCreate,
    PublicContactQuery,
    PublicSatelliteQuery,
    PublicTLE,
    RegisterRequest,
    Satellite,
    SatelliteCreate,
    SatelliteSubsystemState,
    TimeRangeQuery,
    TokenCreateRequest,
    TokenCreateResponse,
    TokenInfo,
    UserProfile,
)

ModelT = TypeVar("ModelT", bound=BaseModel)


class _OrbsimClientBase:
    def _model(self, model_type: type[ModelT], data: Any) -> ModelT:
        return model_type.model_validate(data)

    def _models(self, model_type: type[ModelT], data: list[Any]) -> list[ModelT]:
        return [self._model(model_type, item) for item in data]


class OrbsimClient(_OrbsimClientBase):
    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        timeout: float = 30.0,
        client: httpx.Client | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._client = client or httpx.Client(base_url=self.base_url, timeout=timeout)
        self._owns_client = client is None
        if token:
            self.set_token(token)

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "OrbsimClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @property
    def token(self) -> str | None:
        auth = self._client.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return auth.removeprefix("Bearer ")
        return None

    def set_token(self, token: str | None) -> None:
        if token:
            self._client.headers["Authorization"] = f"Bearer {token}"
        else:
            self._client.headers.pop("Authorization", None)

    def _request(self, method: str, path: str, *, params: dict[str, Any] | None = None, payload: BaseModel | dict[str, Any] | None = None) -> Any:
        json_payload: dict[str, Any] | None = None
        if payload is not None:
            json_payload = payload.model_dump(mode="json", exclude_none=True) if isinstance(payload, BaseModel) else payload
        response = self._client.request(method, path, params=params, json=json_payload)
        if response.is_error:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise OrbsimAPIError(response.status_code, detail)
        if not response.content:
            return None
        return response.json()

    def bootstrap_admin(self, email: str, password: str, full_name: str) -> AuthTokenResponse:
        result = self._model(AuthTokenResponse, self._request("POST", "/auth/bootstrap-admin", payload=BootstrapAdminRequest(email=email, password=password, full_name=full_name)))
        self.set_token(result.token)
        return result

    def register(self, email: str, password: str, full_name: str) -> AuthTokenResponse:
        result = self._model(AuthTokenResponse, self._request("POST", "/auth/register", payload=RegisterRequest(email=email, password=password, full_name=full_name)))
        self.set_token(result.token)
        return result

    def login(self, email: str, password: str, token_name: str = "Default API Token") -> AuthTokenResponse:
        result = self._model(AuthTokenResponse, self._request("POST", "/auth/login", payload=LoginRequest(email=email, password=password, token_name=token_name)))
        self.set_token(result.token)
        return result

    def me(self) -> UserProfile:
        return self._model(UserProfile, self._request("GET", "/auth/me"))

    def list_tokens(self) -> list[TokenInfo]:
        return self._models(TokenInfo, self._request("GET", "/auth/tokens"))

    def create_token(self, name: str) -> TokenCreateResponse:
        return self._model(TokenCreateResponse, self._request("POST", "/auth/tokens", payload=TokenCreateRequest(name=name)))

    def revoke_own_token(self, token_id: str) -> TokenInfo:
        return self._model(TokenInfo, self._request("DELETE", f"/auth/tokens/{token_id}"))

    def health(self) -> HealthResponse:
        return self._model(HealthResponse, self._request("GET", "/health"))

    def get_public_tle(self, query: PublicSatelliteQuery) -> PublicTLE:
        return self._model(PublicTLE, self._request("POST", "/public/tle", payload=query))

    def get_public_state(self, query: PublicSatelliteQuery, timestamp: datetime | str) -> OrbitalStateResponse:
        return self._model(OrbitalStateResponse, self._request("POST", "/public/state", params={"timestamp": timestamp}, payload=query))

    def get_public_contacts(self, query: PublicContactQuery) -> list[ContactInterval]:
        return self._models(ContactInterval, self._request("POST", "/public/contacts", payload=query))

    def create_project(self, payload: ProjectCreate) -> Project:
        return self._model(Project, self._request("POST", "/projects", payload=payload))

    def list_projects(self) -> list[Project]:
        return self._models(Project, self._request("GET", "/projects"))

    def delete_project(self, project_id: str) -> Project:
        return self._model(Project, self._request("DELETE", f"/projects/{project_id}"))

    def create_satellite(self, project_id: str, payload: SatelliteCreate) -> Satellite:
        return self._model(Satellite, self._request("POST", f"/projects/{project_id}/satellites", payload=payload))

    def list_satellites(self, project_id: str) -> list[Satellite]:
        return self._models(Satellite, self._request("GET", f"/projects/{project_id}/satellites"))

    def delete_satellite(self, project_id: str, satellite_id: str) -> Satellite:
        return self._model(Satellite, self._request("DELETE", f"/projects/{project_id}/satellites/{satellite_id}"))

    def create_groundstation(self, project_id: str, payload: GroundStationCreate) -> GroundStation:
        return self._model(GroundStation, self._request("POST", f"/projects/{project_id}/groundstations", payload=payload))

    def list_groundstations(self, project_id: str) -> list[GroundStation]:
        return self._models(GroundStation, self._request("GET", f"/projects/{project_id}/groundstations"))

    def delete_groundstation(self, project_id: str, groundstation_id: str) -> GroundStation:
        return self._model(GroundStation, self._request("DELETE", f"/projects/{project_id}/groundstations/{groundstation_id}"))

    def get_satellite_state(self, project_id: str, satellite_id: str, timestamp: datetime | str) -> OrbitalStateResponse:
        return self._model(OrbitalStateResponse, self._request("POST", f"/projects/{project_id}/satellites/{satellite_id}/state", params={"timestamp": timestamp}))

    def get_satellite_states(self, project_id: str, satellite_id: str, payload: TimeRangeQuery) -> list[OrbitalStateResponse]:
        return self._models(OrbitalStateResponse, self._request("POST", f"/projects/{project_id}/satellites/{satellite_id}/states", payload=payload))

    def get_satellite_attitude(self, project_id: str, satellite_id: str, timestamp: datetime | str) -> AttitudeSample:
        return self._model(AttitudeSample, self._request("POST", f"/projects/{project_id}/satellites/{satellite_id}/attitude", params={"timestamp": timestamp}))

    def get_satellite_subsystems(self, project_id: str, satellite_id: str, timestamp: datetime | str) -> SatelliteSubsystemState:
        return self._model(SatelliteSubsystemState, self._request("POST", f"/projects/{project_id}/satellites/{satellite_id}/subsystems", params={"timestamp": timestamp}))

    def get_contacts(self, project_id: str, satellite_id: str, groundstation_id: str, payload: TimeRangeQuery) -> list[ContactInterval]:
        return self._models(ContactInterval, self._request("POST", f"/projects/{project_id}/contacts/{satellite_id}/{groundstation_id}", payload=payload))

    def get_link_budget(self, project_id: str, payload: LinkBudgetRequest) -> LinkBudgetResponse:
        return self._model(LinkBudgetResponse, self._request("POST", f"/projects/{project_id}/links/budget", payload=payload))

    def create_constellation(self, project_id: str, payload: ConstellationCreate) -> Constellation:
        return self._model(Constellation, self._request("POST", f"/projects/{project_id}/constellations", payload=payload))

    def design_constellation(self, project_id: str, payload: ConstellationDesignCreate) -> ConstellationDesignResponse:
        return self._model(ConstellationDesignResponse, self._request("POST", f"/projects/{project_id}/constellations/design", payload=payload))

    def list_constellations(self, project_id: str) -> list[Constellation]:
        return self._models(Constellation, self._request("GET", f"/projects/{project_id}/constellations"))

    def delete_constellation(self, project_id: str, constellation_id: str) -> Constellation:
        return self._model(Constellation, self._request("DELETE", f"/projects/{project_id}/constellations/{constellation_id}"))

    def get_constellation_network(self, project_id: str, constellation_id: str, timestamp: datetime | str, kind: str = "rf") -> NetworkResponse:
        return self._model(NetworkResponse, self._request("POST", f"/projects/{project_id}/constellations/{constellation_id}/network", params={"timestamp": timestamp, "kind": kind}))

    def admin_dashboard(self) -> AdminDashboard:
        return self._model(AdminDashboard, self._request("GET", "/admin/dashboard"))

    def admin_list_users(self) -> list[UserProfile]:
        return self._models(UserProfile, self._request("GET", "/admin/users"))

    def admin_list_projects(self) -> list[AdminProjectInfo]:
        return self._models(AdminProjectInfo, self._request("GET", "/admin/projects"))

    def admin_user_tokens(self, user_id: str) -> list[TokenInfo]:
        return self._models(TokenInfo, self._request("GET", f"/admin/users/{user_id}/tokens"))

    def admin_toggle_admin(self, user_id: str) -> UserProfile:
        return self._model(UserProfile, self._request("POST", f"/admin/users/{user_id}/toggle-admin"))

    def admin_revoke_token(self, token_id: str) -> TokenInfo:
        return self._model(TokenInfo, self._request("POST", f"/admin/tokens/{token_id}/revoke"))


class AsyncOrbsimClient(_OrbsimClientBase):
    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        timeout: float = 30.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._client = client or httpx.AsyncClient(base_url=self.base_url, timeout=timeout)
        self._owns_client = client is None
        if token:
            self.set_token(token)

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> "AsyncOrbsimClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    @property
    def token(self) -> str | None:
        auth = self._client.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return auth.removeprefix("Bearer ")
        return None

    def set_token(self, token: str | None) -> None:
        if token:
            self._client.headers["Authorization"] = f"Bearer {token}"
        else:
            self._client.headers.pop("Authorization", None)

    async def _request(self, method: str, path: str, *, params: dict[str, Any] | None = None, payload: BaseModel | dict[str, Any] | None = None) -> Any:
        json_payload: dict[str, Any] | None = None
        if payload is not None:
            json_payload = payload.model_dump(mode="json", exclude_none=True) if isinstance(payload, BaseModel) else payload
        response = await self._client.request(method, path, params=params, json=json_payload)
        if response.is_error:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise OrbsimAPIError(response.status_code, detail)
        if not response.content:
            return None
        return response.json()

    async def bootstrap_admin(self, email: str, password: str, full_name: str) -> AuthTokenResponse:
        result = self._model(AuthTokenResponse, await self._request("POST", "/auth/bootstrap-admin", payload=BootstrapAdminRequest(email=email, password=password, full_name=full_name)))
        self.set_token(result.token)
        return result

    async def register(self, email: str, password: str, full_name: str) -> AuthTokenResponse:
        result = self._model(AuthTokenResponse, await self._request("POST", "/auth/register", payload=RegisterRequest(email=email, password=password, full_name=full_name)))
        self.set_token(result.token)
        return result

    async def login(self, email: str, password: str, token_name: str = "Default API Token") -> AuthTokenResponse:
        result = self._model(AuthTokenResponse, await self._request("POST", "/auth/login", payload=LoginRequest(email=email, password=password, token_name=token_name)))
        self.set_token(result.token)
        return result

    async def me(self) -> UserProfile:
        return self._model(UserProfile, await self._request("GET", "/auth/me"))

    async def list_tokens(self) -> list[TokenInfo]:
        return self._models(TokenInfo, await self._request("GET", "/auth/tokens"))

    async def create_token(self, name: str) -> TokenCreateResponse:
        return self._model(TokenCreateResponse, await self._request("POST", "/auth/tokens", payload=TokenCreateRequest(name=name)))

    async def revoke_own_token(self, token_id: str) -> TokenInfo:
        return self._model(TokenInfo, await self._request("DELETE", f"/auth/tokens/{token_id}"))

    async def health(self) -> HealthResponse:
        return self._model(HealthResponse, await self._request("GET", "/health"))

    async def get_public_tle(self, query: PublicSatelliteQuery) -> PublicTLE:
        return self._model(PublicTLE, await self._request("POST", "/public/tle", payload=query))

    async def get_public_state(self, query: PublicSatelliteQuery, timestamp: datetime | str) -> OrbitalStateResponse:
        return self._model(OrbitalStateResponse, await self._request("POST", "/public/state", params={"timestamp": timestamp}, payload=query))

    async def get_public_contacts(self, query: PublicContactQuery) -> list[ContactInterval]:
        return self._models(ContactInterval, await self._request("POST", "/public/contacts", payload=query))

    async def create_project(self, payload: ProjectCreate) -> Project:
        return self._model(Project, await self._request("POST", "/projects", payload=payload))

    async def list_projects(self) -> list[Project]:
        return self._models(Project, await self._request("GET", "/projects"))

    async def delete_project(self, project_id: str) -> Project:
        return self._model(Project, await self._request("DELETE", f"/projects/{project_id}"))

    async def create_satellite(self, project_id: str, payload: SatelliteCreate) -> Satellite:
        return self._model(Satellite, await self._request("POST", f"/projects/{project_id}/satellites", payload=payload))

    async def list_satellites(self, project_id: str) -> list[Satellite]:
        return self._models(Satellite, await self._request("GET", f"/projects/{project_id}/satellites"))

    async def delete_satellite(self, project_id: str, satellite_id: str) -> Satellite:
        return self._model(Satellite, await self._request("DELETE", f"/projects/{project_id}/satellites/{satellite_id}"))

    async def create_groundstation(self, project_id: str, payload: GroundStationCreate) -> GroundStation:
        return self._model(GroundStation, await self._request("POST", f"/projects/{project_id}/groundstations", payload=payload))

    async def list_groundstations(self, project_id: str) -> list[GroundStation]:
        return self._models(GroundStation, await self._request("GET", f"/projects/{project_id}/groundstations"))

    async def delete_groundstation(self, project_id: str, groundstation_id: str) -> GroundStation:
        return self._model(GroundStation, await self._request("DELETE", f"/projects/{project_id}/groundstations/{groundstation_id}"))

    async def get_satellite_state(self, project_id: str, satellite_id: str, timestamp: datetime | str) -> OrbitalStateResponse:
        return self._model(OrbitalStateResponse, await self._request("POST", f"/projects/{project_id}/satellites/{satellite_id}/state", params={"timestamp": timestamp}))

    async def get_satellite_states(self, project_id: str, satellite_id: str, payload: TimeRangeQuery) -> list[OrbitalStateResponse]:
        return self._models(OrbitalStateResponse, await self._request("POST", f"/projects/{project_id}/satellites/{satellite_id}/states", payload=payload))

    async def get_satellite_attitude(self, project_id: str, satellite_id: str, timestamp: datetime | str) -> AttitudeSample:
        return self._model(AttitudeSample, await self._request("POST", f"/projects/{project_id}/satellites/{satellite_id}/attitude", params={"timestamp": timestamp}))

    async def get_satellite_subsystems(self, project_id: str, satellite_id: str, timestamp: datetime | str) -> SatelliteSubsystemState:
        return self._model(SatelliteSubsystemState, await self._request("POST", f"/projects/{project_id}/satellites/{satellite_id}/subsystems", params={"timestamp": timestamp}))

    async def get_contacts(self, project_id: str, satellite_id: str, groundstation_id: str, payload: TimeRangeQuery) -> list[ContactInterval]:
        return self._models(ContactInterval, await self._request("POST", f"/projects/{project_id}/contacts/{satellite_id}/{groundstation_id}", payload=payload))

    async def get_link_budget(self, project_id: str, payload: LinkBudgetRequest) -> LinkBudgetResponse:
        return self._model(LinkBudgetResponse, await self._request("POST", f"/projects/{project_id}/links/budget", payload=payload))

    async def create_constellation(self, project_id: str, payload: ConstellationCreate) -> Constellation:
        return self._model(Constellation, await self._request("POST", f"/projects/{project_id}/constellations", payload=payload))

    async def design_constellation(self, project_id: str, payload: ConstellationDesignCreate) -> ConstellationDesignResponse:
        return self._model(ConstellationDesignResponse, await self._request("POST", f"/projects/{project_id}/constellations/design", payload=payload))

    async def list_constellations(self, project_id: str) -> list[Constellation]:
        return self._models(Constellation, await self._request("GET", f"/projects/{project_id}/constellations"))

    async def delete_constellation(self, project_id: str, constellation_id: str) -> Constellation:
        return self._model(Constellation, await self._request("DELETE", f"/projects/{project_id}/constellations/{constellation_id}"))

    async def get_constellation_network(self, project_id: str, constellation_id: str, timestamp: datetime | str, kind: str = "rf") -> NetworkResponse:
        return self._model(NetworkResponse, await self._request("POST", f"/projects/{project_id}/constellations/{constellation_id}/network", params={"timestamp": timestamp, "kind": kind}))

    async def admin_dashboard(self) -> AdminDashboard:
        return self._model(AdminDashboard, await self._request("GET", "/admin/dashboard"))

    async def admin_list_users(self) -> list[UserProfile]:
        return self._models(UserProfile, await self._request("GET", "/admin/users"))

    async def admin_list_projects(self) -> list[AdminProjectInfo]:
        return self._models(AdminProjectInfo, await self._request("GET", "/admin/projects"))

    async def admin_user_tokens(self, user_id: str) -> list[TokenInfo]:
        return self._models(TokenInfo, await self._request("GET", f"/admin/users/{user_id}/tokens"))

    async def admin_toggle_admin(self, user_id: str) -> UserProfile:
        return self._model(UserProfile, await self._request("POST", f"/admin/users/{user_id}/toggle-admin"))

    async def admin_revoke_token(self, token_id: str) -> TokenInfo:
        return self._model(TokenInfo, await self._request("POST", f"/admin/tokens/{token_id}/revoke"))
