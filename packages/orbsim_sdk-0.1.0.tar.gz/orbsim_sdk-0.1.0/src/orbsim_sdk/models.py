from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, HttpUrl


class OrbitSource(str, Enum):
    TLE = "tle"
    EPHEMERIS = "ephemeris"
    KEPLERIAN = "keplerian"


class AnomalyKind(str, Enum):
    TRUE = "true"
    MEAN = "mean"
    ECCENTRIC = "eccentric"


class AttitudeMode(str, Enum):
    LVLH = "lvlh"
    NADIR = "nadir"
    SUN_POINTING = "sun_pointing"
    INERTIAL = "inertial"


class LinkKind(str, Enum):
    RF = "rf"
    OPTICAL = "optical"


class ConstellationDesignType(str, Enum):
    WALKER_DELTA = "walker_delta"


class LoginRequest(BaseModel):
    email: str
    password: str
    token_name: str = "Default API Token"


class RegisterRequest(BaseModel):
    email: str
    password: str
    full_name: str


class BootstrapAdminRequest(RegisterRequest):
    pass


class UserProfile(BaseModel):
    id: str
    email: str
    full_name: str
    is_admin: bool
    is_active: bool
    created_at: datetime


class AuthTokenResponse(BaseModel):
    token: str
    token_type: Literal["bearer"] = "bearer"
    user: UserProfile


class TokenCreateRequest(BaseModel):
    name: str


class TokenInfo(BaseModel):
    id: str
    name: str
    token_prefix: str
    created_at: datetime
    last_used_at: datetime | None = None
    revoked_at: datetime | None = None


class TokenCreateResponse(BaseModel):
    token: str
    token_info: TokenInfo


class ProjectCreate(BaseModel):
    name: str
    description: str | None = None


class Project(BaseModel):
    id: str
    name: str
    description: str | None = None
    created_at: datetime


class CartesianState(BaseModel):
    timestamp: datetime
    position_m: list[float] = Field(min_length=3, max_length=3)
    velocity_mps: list[float] = Field(min_length=3, max_length=3)


class TLEDefinition(BaseModel):
    line1: str
    line2: str


class KeplerianDefinition(BaseModel):
    semi_major_axis_m: float
    eccentricity: float
    inclination_deg: float
    raan_deg: float
    arg_perigee_deg: float
    anomaly_deg: float
    anomaly_kind: AnomalyKind = AnomalyKind.TRUE
    epoch: datetime


class SatelliteSubsystemState(BaseModel):
    power_w: float = 0.0
    battery_soc: float = 1.0
    thermal_c: float = 20.0
    payload_active: bool = False
    comms_margin_db: float = 0.0


class SatelliteCreate(BaseModel):
    name: str
    source: OrbitSource
    tle: TLEDefinition | None = None
    ephemeris: list[CartesianState] | None = None
    keplerian: KeplerianDefinition | None = None
    attitude_mode: AttitudeMode = AttitudeMode.NADIR
    dry_mass_kg: float = 100.0
    subsystems: SatelliteSubsystemState = Field(default_factory=SatelliteSubsystemState)


class Satellite(BaseModel):
    id: str
    name: str
    source: OrbitSource
    tle: TLEDefinition | None = None
    ephemeris: list[CartesianState] | None = None
    keplerian: KeplerianDefinition | None = None
    attitude_mode: AttitudeMode
    dry_mass_kg: float
    subsystems: SatelliteSubsystemState


class GroundStationCreate(BaseModel):
    name: str
    latitude_deg: float
    longitude_deg: float
    altitude_m: float = 0.0
    min_elevation_deg: float = 5.0


class GroundStation(BaseModel):
    id: str
    name: str
    latitude_deg: float
    longitude_deg: float
    altitude_m: float = 0.0
    min_elevation_deg: float = 5.0


class TimeRangeQuery(BaseModel):
    start: datetime
    end: datetime
    step_seconds: int = 60


class AttitudeSample(BaseModel):
    timestamp: datetime
    quaternion_xyzw: list[float]
    euler_deg: list[float]
    mode: AttitudeMode


class OrbitalStateResponse(BaseModel):
    satellite_id: str
    timestamp: datetime
    position_m: list[float]
    velocity_mps: list[float]
    inertial_position_m: list[float] | None = None
    inertial_velocity_mps: list[float] | None = None
    altitude_m: float
    latitude_deg: float
    longitude_deg: float


class ContactInterval(BaseModel):
    start: datetime
    end: datetime
    max_elevation_deg: float
    satellite_id: str
    groundstation_id: str


class LinkBudgetRequest(BaseModel):
    source_satellite_id: str
    target_satellite_id: str | None = None
    groundstation_id: str | None = None
    kind: LinkKind
    timestamp: datetime
    frequency_hz: float = 8.2e9
    tx_power_dbw: float = 10.0
    tx_gain_dbi: float = 25.0
    rx_gain_dbi: float = 25.0
    bandwidth_hz: float = 1e6
    system_temperature_k: float = 500.0
    optical_wavelength_nm: float = 1550.0
    aperture_m: float = 0.12


class LinkBudgetResponse(BaseModel):
    kind: LinkKind
    range_m: float
    free_space_loss_db: float
    rx_power_dbw: float
    snr_db: float
    visible: bool


class ConstellationCreate(BaseModel):
    name: str
    satellite_ids: list[str]
    isl_max_range_m: float = 3_500_000.0
    max_degree: int = 4


class WalkerDeltaDefinition(BaseModel):
    total_satellites: int
    plane_count: int
    relative_spacing: int
    semi_major_axis_m: float
    eccentricity: float
    inclination_deg: float
    arg_perigee_deg: float = 0.0
    start_raan_deg: float = 0.0
    start_anomaly_deg: float = 0.0
    anomaly_kind: AnomalyKind = AnomalyKind.MEAN
    satellite_name_prefix: str | None = None
    attitude_mode: AttitudeMode = AttitudeMode.NADIR
    dry_mass_kg: float = 100.0
    subsystems: SatelliteSubsystemState = Field(default_factory=SatelliteSubsystemState)


class ConstellationDesignCreate(BaseModel):
    name: str
    type: ConstellationDesignType
    walker_delta: WalkerDeltaDefinition | None = None
    isl_max_range_m: float = 3_500_000.0
    max_degree: int = 4


class Constellation(BaseModel):
    id: str
    name: str
    satellite_ids: list[str]
    isl_max_range_m: float
    max_degree: int


class ConstellationDesignResponse(BaseModel):
    constellation: Constellation
    satellites: list[Satellite]


class PublicSatelliteQuery(BaseModel):
    norad_id: str | None = None
    name: str | None = None
    source_url: HttpUrl | None = None


class PublicTLE(BaseModel):
    name: str
    line1: str
    line2: str
    source: str


class PublicContactQuery(BaseModel):
    satellite: PublicSatelliteQuery
    groundstation: GroundStationCreate
    start: datetime
    end: datetime
    step_seconds: int = 60


class AdminDashboard(BaseModel):
    user_count: int
    project_count: int
    token_count: int
    active_token_count: int


class HealthResponse(BaseModel):
    status: Literal["ok"]
    orekit_available: bool


class AdminProjectInfo(BaseModel):
    id: str
    name: str
    description: str | None = None
    created_at: datetime
    owner_email: str


class NetworkResponse(BaseModel):
    timestamp: datetime
    kind: str
    nodes: dict[str, OrbitalStateResponse]
    adjacency: dict[str, list[dict[str, Any]]]
