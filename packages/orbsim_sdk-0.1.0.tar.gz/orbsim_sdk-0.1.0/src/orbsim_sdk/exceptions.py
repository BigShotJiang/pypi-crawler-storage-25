class OrbsimSDKError(Exception):
    """Base SDK exception."""


class OrbsimAPIError(OrbsimSDKError):
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"OrbSim API error {status_code}: {detail}")
