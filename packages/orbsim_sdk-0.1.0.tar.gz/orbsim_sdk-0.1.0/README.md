# OrbSim SDK

Typed Python client for the OrbSim API.

## Install

```bash
pip install /path/to/orbsim/sdk
```

## Quick Start

```python
from orbsim_sdk import OrbitSource, OrbsimClient, SatelliteCreate, TLEDefinition

client = OrbsimClient("http://127.0.0.1:8000/api")
auth = client.login("admin@example.com", "supersecret123", token_name="SDK Session")
projects = client.list_projects()

satellite = client.create_satellite(
    projects[0].id,
    SatelliteCreate(
        name="ISS Copy",
        source=OrbitSource.TLE,
        tle=TLEDefinition(
            line1="1 25544U 98067A   26099.50000000  .00016717  00000+0  30747-3 0  9991",
            line2="2 25544  51.6400  54.1200 0003870 123.4567 321.6543 15.50000000123456",
        ),
    ),
)

state = client.get_satellite_state(projects[0].id, satellite.id, "2026-04-09T12:00:00Z")
print(state.latitude_deg, state.longitude_deg, state.altitude_m)
```

## Async Quick Start

```python
import asyncio

from orbsim_sdk import AsyncOrbsimClient


async def main():
    async with AsyncOrbsimClient("http://127.0.0.1:8000/api") as client:
        await client.login("admin@example.com", "supersecret123", token_name="Async SDK Session")
        projects = await client.list_projects()
        print([project.name for project in projects])


asyncio.run(main())
```
