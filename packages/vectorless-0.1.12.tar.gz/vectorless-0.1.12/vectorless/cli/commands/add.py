"""add command — compile documents (maps to engine.compile)."""

import asyncio
import os
from pathlib import Path
from typing import Optional

import click

from vectorless.cli.workspace import get_workspace_path
from vectorless.cli.output import format_json


def _create_engine(workspace_dir: str):
    """Create an Engine from workspace config.

    Args:
        workspace_dir: Path to .vectorless/ directory.

    Returns:
        Configured Engine instance.
    """
    from vectorless.engine import Engine

    config_path = os.path.join(workspace_dir, "config.toml")
    if os.path.exists(config_path):
        return Engine.from_config_file(config_path)
    return Engine.from_env()


def add_cmd(
    path: str,
    *,
    recursive: bool = False,
    fmt: Optional[str] = None,
    force: bool = False,
    jobs: int = 1,
    verbose: bool = False,
) -> None:
    """Compile a document or directory.

    Args:
        path: File or directory path.
        recursive: Compile directory recursively.
        fmt: Force format ("markdown" | "pdf" | None for auto-detect).
        force: Force re-compile existing documents.
        jobs: Number of parallel compile jobs.
        verbose: Show detailed progress.
    """
    workspace = get_workspace_path()

    try:
        session = _create_engine(workspace)
    except Exception as e:
        raise click.ClickException(f"Failed to create engine: {e}") from e

    target = Path(path).resolve()
    format_hint = fmt or "markdown"

    async def _run():
        if target.is_dir():
            if recursive:
                # Collect all matching files in directory
                extensions = {".md", ".pdf", ".markdown"}
                file_paths = [
                    str(f)
                    for f in target.rglob("*")
                    if f.suffix.lower() in extensions and f.is_file()
                ]
            else:
                extensions = {".md", ".pdf", ".markdown"}
                file_paths = [
                    str(f)
                    for f in target.iterdir()
                    if f.suffix.lower() in extensions and f.is_file()
                ]

            if not file_paths:
                raise click.ClickException(
                    f"No supported documents found in {target}"
                )

            if verbose:
                click.echo(f"Found {len(file_paths)} document(s) to compile")

            results = await session.compile_batch(
                file_paths, mode="force" if force else "default", jobs=jobs
            )

            succeeded = [r for r in results if not r.has_failures()]
            failed = [r for r in results if r.has_failures()]

            click.echo(f"Compiled {len(succeeded)}/{len(results)} document(s) successfully")
            if failed:
                click.echo(f"Failed: {len(failed)} document(s)")
                for f_result in failed:
                    for item in f_result.failed:
                        click.echo(f"  {item.source}: {item.error}")

            if verbose:
                for r in succeeded:
                    for item in r.items:
                        click.echo(f"  {item.name} ({item.doc_id})")
        else:
            result = await session.compile(
                path=str(target),
                format=format_hint,
                mode="force" if force else "default",
            )

            if result.doc_id:
                click.echo(f"Compiled: {result.doc_id}")
            else:
                # Batch result from single file
                for item in result.items:
                    click.echo(f"Compiled: {item.name} ({item.doc_id})")

            if result.has_failures():
                for item in result.failed:
                    click.echo(f"Failed: {item.source}: {item.error}")

            if verbose and result.items:
                for item in result.items:
                    if item.metrics:
                        m = item.metrics
                        click.echo(
                            f"  Nodes: {m.nodes_processed}, "
                            f"Summaries: {m.summaries_generated}, "
                            f"LLM calls: {m.llm_calls}, "
                            f"Time: {m.total_time_ms}ms"
                        )

    try:
        asyncio.run(_run())
    except click.ClickException:
        raise
    except Exception as e:
        raise click.ClickException(f"Compile failed: {e}") from e
