import types

import httpx


class ConflictError(Exception):
    """
    There was a conflict in a multipart operation.
    """


# FIXME: Subclassing httpx.HTTPStatusError would be more appropriate
# Or maybe just not subclassing any error

class S3Error(httpx.HTTPError):
    """
    Parent class for errors reported by the server
    """
    request: httpx.Request
    response: httpx.Response

    def __init__(self, message, resource: str|None = None, request_id: str|None = None, **props):
        super().__init__(message)
        self.resource = resource
        self.request_id = request_id
        vars(self).update(props)

        if resource:
            self.add_note(f"resource: {resource}")
        if request_id:
            self.add_note(f"request_id: {request_id}")

        for name, value in sorted(props.items()):
            self.add_note(f"{name}: {value}")


def __getattr__(name):
    """
    Generate an exception for the error returned by the server.
    """
    if name in ('AwsError', 'AwsUploadError', 'AwsDownloadError'):
        raise AttributeError(f"Exception {name} has been removed")

    def body(ns):
        ns['__module__'] = __name__
        ns['__qualname__'] = name

    cls = types.new_class(
        name,
        (S3Error,),
        {},
        body
    )
    globals()[name] = cls
    return cls
