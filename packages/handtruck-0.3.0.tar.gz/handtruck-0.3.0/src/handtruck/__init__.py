from .client import S3Client
from .version import __version__, version_info
from ._xml import AwsObjectMeta
from .exceptions import S3Error, ConflictError


__all__ = (
    "__version__",
    "version_info",
    "AwsObjectMeta",
    "S3Client",
    "S3Error",
    "ConflictError",
)
