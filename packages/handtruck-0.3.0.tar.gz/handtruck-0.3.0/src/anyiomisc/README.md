A partial port of aiomisc to anyio.

This folder only under MIT.