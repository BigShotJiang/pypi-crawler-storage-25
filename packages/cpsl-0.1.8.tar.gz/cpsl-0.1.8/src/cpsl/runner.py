"""Internal runner — started by Capsule inside the user's app instance.

Connects to the gateway via gRPC (RunnerService.Connect), receives inbound
messages, dispatches to the @message() handler, and streams response chunks
back. Session state is persisted via SessionService (S2-backed).
"""

from __future__ import annotations

import asyncio
import importlib
import json
import os
import queue
import signal
import sys
import threading
from typing import Any

import betterproto
from aiohttp import web

from .channel import Channel as GrpcChannel
from .channels import Channel
from .clients.capsule import (
    GatewayMessage,
    GetSessionRequest,
    InboundMessage,
    ResponseChunk,
    RunnerMessage,
    RunnerRegister,
    RunnerServiceStub,
    SaveSessionDataRequest,
    SessionServiceStub,
    UpdateCommand,
)
from .decorators import _BOOT_ATTR, _SHUTDOWN_ATTR, _ENTER_ATTR, _EXIT_ATTR, _MESSAGE_ATTR
from .msg import Message
from .session import Session, UserInfo

LISTEN_PORT = 8080


def _find_decorated(instance: object, attr: str):
    for name in dir(instance):
        method = getattr(instance, name, None)
        if callable(method) and getattr(method, attr, False):
            return method
    return None


def _load_class(module_path: str, class_name: str) -> type:
    mod = importlib.import_module(module_path)
    return getattr(mod, class_name)


class Runner:
    def __init__(self, module_path: str, class_name: str) -> None:
        self.module_path = module_path
        self.class_name = class_name
        self.app_cls = _load_class(module_path, class_name)
        self.instance: Any = None
        self.sessions: dict[str, Session] = {}
        self._boot_fn = None
        self._shutdown_fn = None
        self._enter_fn = None
        self._exit_fn = None
        self._message_fn = None
        self._send_queue: queue.Queue[RunnerMessage | None] = queue.Queue()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._session_stub: SessionServiceStub | None = None

    async def boot(self) -> None:
        self.instance = self.app_cls()
        self._boot_fn = _find_decorated(self.instance, _BOOT_ATTR)
        self._shutdown_fn = _find_decorated(self.instance, _SHUTDOWN_ATTR)
        self._enter_fn = _find_decorated(self.instance, _ENTER_ATTR)
        self._exit_fn = _find_decorated(self.instance, _EXIT_ATTR)
        self._message_fn = _find_decorated(self.instance, _MESSAGE_ATTR)

        if self._boot_fn:
            result = self._boot_fn()
            if asyncio.iscoroutine(result):
                await result

    async def shutdown(self) -> None:
        if self._shutdown_fn:
            result = self._shutdown_fn()
            if asyncio.iscoroutine(result):
                await result

    async def _get_or_create_session(
        self, session_id: str, user_info: dict, channel_info: dict
    ) -> tuple[Session, bool]:
        """Returns (session, is_new). Rehydrates from SessionService on cache miss."""
        if session_id in self.sessions:
            return self.sessions[session_id], False

        history: list[Message] = []
        data: dict[str, Any] = {}
        user = UserInfo(id=user_info["id"], email=user_info.get("email"))
        channel_type = channel_info.get("type", "chat")

        if self._session_stub is not None:
            try:
                loop = asyncio.get_event_loop()
                resp = await loop.run_in_executor(
                    None,
                    self._session_stub.get_session,
                    GetSessionRequest(session_id=session_id, history_count=50),
                )
                if resp.user_id:
                    user = UserInfo(id=resp.user_id, email=resp.user_email or None)
                if resp.channel_type:
                    channel_type = resp.channel_type
                if resp.data_json:
                    try:
                        data = json.loads(resp.data_json)
                    except json.JSONDecodeError:
                        pass
                for entry in resp.history:
                    history.append(
                        Message(
                            text=entry.text,
                            sender=entry.sender,
                            channel_type=entry.channel_type,
                        )
                    )
            except Exception as e:
                print(f"[runner] SessionService.GetSession failed: {e}", file=sys.stderr)

        channel = Channel(type=channel_type)
        session = Session(
            id=session_id, user=user, channel=channel, history=history, data=data
        )
        self.sessions[session_id] = session
        return session, True

    async def _save_session_data(self, session_id: str, data: dict[str, Any]) -> None:
        if self._session_stub is None:
            return
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                self._session_stub.save_session_data,
                SaveSessionDataRequest(
                    session_id=session_id, data_json=json.dumps(data)
                ),
            )
        except Exception as e:
            print(f"[runner] SessionService.SaveSessionData failed: {e}", file=sys.stderr)

    def _send_chunk(self, request_id: str, text: str, done: bool = False) -> None:
        self._send_queue.put(
            RunnerMessage(
                chunk=ResponseChunk(request_id=request_id, text=text, done=done)
            )
        )

    async def handle_inbound(self, msg: InboundMessage) -> None:
        print(f"[runner] handling message request_id={msg.request_id} session_id={msg.session_id}", file=sys.stderr)
        session, is_new = await self._get_or_create_session(
            session_id=msg.session_id,
            user_info={"id": msg.user_id, "email": msg.user_email},
            channel_info={"type": msg.channel_type},
        )

        if is_new and self._enter_fn:
            result = self._enter_fn(session)
            if asyncio.iscoroutine(result):
                await result

        user_msg = Message(
            text=msg.text,
            sender="user",
            channel_type=session.channel.type,
        )
        session.history.append(user_msg)

        request_id = msg.request_id

        async def on_reply(m: Message) -> None:
            self._send_chunk(request_id, m.text, done=False)

        async def on_stream(chunks) -> None:
            async for chunk_text in chunks:
                self._send_chunk(request_id, chunk_text, done=False)

        session._reply_callback = on_reply
        session._stream_callback = on_stream

        if self._message_fn:
            result = self._message_fn(session, user_msg)
            if asyncio.iscoroutine(result):
                await result

        self._send_chunk(request_id, "", done=True)
        await self._save_session_data(session.id, session.data)

    def _outbound_iterator(self):
        """Yields RunnerMessages for the gRPC stream. Blocks on the queue."""
        while True:
            msg = self._send_queue.get()
            if msg is None:
                return
            yield msg

    def _grpc_recv_loop(self, response_iter, loop: asyncio.AbstractEventLoop) -> None:
        """Runs in a background thread, receives GatewayMessages and schedules
        async handling on the event loop."""
        try:
            for gw_msg in response_iter:
                field_name, value = betterproto.which_one_of(gw_msg, "payload")

                if field_name == "message" and value and value.request_id:
                    asyncio.run_coroutine_threadsafe(
                        self.handle_inbound(value), loop
                    )
                elif field_name == "update" and value and value.sdk_version:
                    self._handle_update(value)
        except Exception as e:
            print(f"[runner] gRPC recv error: {e}, restarting...", file=sys.stderr)
            entrypoint = f"{self.module_path}:{self.class_name}"
            os.execv(sys.executable, [sys.executable, "-m", "cpsl.runner", entrypoint])

    def _handle_update(self, cmd: UpdateCommand) -> None:
        """Handle SDK hot-update: pip install new version and restart."""
        import subprocess
        version = cmd.sdk_version
        print(f"[runner] updating SDK to {version}", file=sys.stderr)
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", f"cpsl=={version}"],
                stdout=sys.stderr,
                stderr=sys.stderr,
            )
            entrypoint = f"{self.module_path}:{self.class_name}"
            os.execv(
                sys.executable,
                [sys.executable, "-m", "cpsl.runner", entrypoint],
            )
        except Exception as e:
            print(f"[runner] update failed: {e}", file=sys.stderr)

    async def serve(self) -> None:
        self._loop = asyncio.get_event_loop()

        gateway_host = os.environ.get("CAPSULE_GATEWAY_HOST", "localhost:1980")
        app_id = os.environ.get("CAPSULE_APP_ID", "")
        version_id = os.environ.get("CAPSULE_VERSION_ID", "")
        runner_token = os.environ.get("CAPSULE_RUNNER_TOKEN", "")

        print(f"[runner] connecting to gateway at {gateway_host}", file=sys.stderr)

        channel = GrpcChannel(addr=gateway_host, token=runner_token or None)
        session_channel = GrpcChannel(addr=gateway_host, token=runner_token or None)
        stub = RunnerServiceStub(channel)
        self._session_stub = SessionServiceStub(session_channel)

        self._send_queue.put(
            RunnerMessage(
                register=RunnerRegister(app_id=app_id, version_id=version_id)
            )
        )

        response_iter = stub.connect(self._outbound_iterator())

        recv_thread = threading.Thread(
            target=self._grpc_recv_loop,
            args=(response_iter, self._loop),
            daemon=True,
        )
        recv_thread.start()

        print(f"[runner] connected, app_id={app_id}", file=sys.stderr)

        health_app = web.Application()
        health_app.router.add_get("/health", self._handle_health)
        health_runner = web.AppRunner(health_app)
        await health_runner.setup()
        site = web.TCPSite(health_runner, "0.0.0.0", LISTEN_PORT)
        await site.start()

        stop = asyncio.Event()
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stop.set)

        await stop.wait()
        self._send_queue.put(None)
        await self.shutdown()
        await health_runner.cleanup()
        channel.close()
        session_channel.close()

    async def _handle_health(self, _request: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})


async def _main(module_path: str, class_name: str) -> None:
    r = Runner(module_path, class_name)
    await r.boot()
    await r.serve()


def main() -> None:
    if len(sys.argv) != 2 or ":" not in sys.argv[1]:
        print("Usage: python -m cpsl.runner <module>:<ClassName>", file=sys.stderr)
        sys.exit(1)

    module_path, class_name = sys.argv[1].rsplit(":", 1)
    asyncio.run(_main(module_path, class_name))


if __name__ == "__main__":
    main()
