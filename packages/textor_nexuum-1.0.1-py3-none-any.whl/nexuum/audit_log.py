"""Append-only audit log for write operations."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

LOG_NAME = "nexuum.log"


def append_audit(
    issue_number: int,
    action: str,
    result: str,
    log_path: Path | None = None,
) -> None:
    """Append one ISO8601 line: issue, action, result."""
    path = log_path or (Path.cwd() / LOG_NAME)
    ts = datetime.now(UTC).isoformat()
    line = f"{ts} issue=#{issue_number} action={action} result={result}\n"
    path.open("a", encoding="utf-8").write(line)
