"""Single source of truth for distribution version."""

VERSION = "0.1.0"
