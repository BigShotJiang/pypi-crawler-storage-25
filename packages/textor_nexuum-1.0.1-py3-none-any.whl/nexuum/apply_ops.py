"""Apply triage results to GitHub (labels + comments)."""

from __future__ import annotations

import time

import typer
from rich.console import Console
from rich.panel import Panel

from .audit_log import append_audit
from .github_client import GitHubClient
from .models import TriageResult

console = Console()


def dry_run_summary(results: list[TriageResult], owner: str, repo: str) -> None:
    msg = "[yellow]Dry-run summary - the following would be written to GitHub:[/yellow]"
    console.print(msg)
    for r in results:
        line = (
            f"  [bold]#{r.issue_number}[/bold] labels={r.suggested_labels!r} "
            f"comment_len={len(r.draft_response)}"
        )
        console.print(line)
    console.print(f"[dim]repo {owner}/{repo}[/dim]")


def format_apply_preview(r: TriageResult) -> str:
    lines = (
        r.draft_response,
        "",
        f"Labels: {', '.join(r.suggested_labels)}",
        f"Reason: {r.reasoning}",
    )
    return "\n".join(lines)


def apply_triage(
    results: list[TriageResult],
    gh: GitHubClient,
    owner: str,
    repo: str,
    yes: bool = False,
) -> None:
    _require_live_token(gh)
    dry_run_summary(results, owner, repo)
    _enforce_batch_rules(len(results), yes)
    for r in results:
        _apply_single(r, gh, owner, repo, yes)


def _require_live_token(gh: GitHubClient) -> None:
    if gh.token and not gh.mock:
        return
    console.print("[red]GITHUB_TOKEN required for --apply[/red]")
    raise typer.Exit(code=1)


def _enforce_batch_rules(n: int, yes: bool) -> None:
    if n > 10 and not yes:
        tip = "[red]More than 10 issues require --yes (and an extra confirm).[/red]"
        console.print(tip)
        raise typer.Exit(code=1)
    if n <= 10:
        return
    if not typer.confirm(f"This will modify {n} issues. Continue?"):
        raise typer.Abort()


def _user_ok_for_issue(r: TriageResult, yes: bool) -> bool:
    if yes:
        return True
    return typer.confirm(f"Apply to #{r.issue_number}?", default=False)


def _apply_single(
    r: TriageResult,
    gh: GitHubClient,
    owner: str,
    repo: str,
    yes: bool,
) -> None:
    console.print(Panel(format_apply_preview(r), title=f"Issue #{r.issue_number}", expand=False))
    if not _user_ok_for_issue(r, yes):
        console.print(f"[yellow]Skipped #{r.issue_number}[/yellow]")
        return
    ok_l, ok_c = _github_writes(gh, owner, repo, r)
    _print_apply_outcome(r, ok_l, ok_c)


def _github_writes(
    gh: GitHubClient,
    owner: str,
    repo: str,
    r: TriageResult,
) -> tuple[bool, bool]:
    ok_l = gh.add_labels(owner, repo, r.issue_number, r.suggested_labels)
    append_audit(r.issue_number, "add_labels", "ok" if ok_l else "fail")
    time.sleep(1.0)
    ok_c = gh.post_comment(owner, repo, r.issue_number, r.draft_response)
    append_audit(r.issue_number, "post_comment", "ok" if ok_c else "fail")
    time.sleep(1.0)
    return ok_l, ok_c


def _print_apply_outcome(r: TriageResult, ok_labels: bool, ok_comment: bool) -> None:
    if ok_labels and ok_comment:
        msg = f"[green]Applied to #{r.issue_number} (see nexuum.log).[/green]"
        console.print(msg)
        return
    console.print(f"[red]Partial failure on #{r.issue_number}[/red]")
