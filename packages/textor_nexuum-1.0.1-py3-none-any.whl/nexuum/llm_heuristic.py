"""Heuristic triage when no LLM key is configured."""

from __future__ import annotations

from difflib import SequenceMatcher

from .models import Issue, TriageResult


def _similarity_score(issue: Issue, other: Issue) -> float:
    title_score = SequenceMatcher(None, issue.title.lower(), other.title.lower()).ratio()
    issue_body = issue.body[:200].lower()
    other_body = other.body[:200].lower()
    body_score = SequenceMatcher(None, issue_body, other_body).ratio()
    return (0.7 * title_score) + (0.3 * body_score)


def find_duplicate_candidate(
    issue: Issue,
    recent: list[Issue],
    threshold: float = 0.82,
) -> tuple[Issue | None, float]:
    best_issue: Issue | None = None
    best_score = 0.0
    for other in recent:
        if other.number == issue.number:
            continue
        score = _similarity_score(issue, other)
        if score > best_score:
            best_issue = other
            best_score = score
    if best_issue is None or best_score <= threshold:
        return None, best_score
    return best_issue, best_score


def find_title_duplicate(
    issue: Issue,
    recent: list[Issue],
    threshold: float = 0.82,
) -> Issue | None:
    """Backward-compatible duplicate finder returning only the issue."""
    other, _score = find_duplicate_candidate(issue, recent, threshold=threshold)
    return other


def mock_invalid(issue: Issue) -> TriageResult:
    return _mk(
        issue.number,
        "invalid",
        0.1,
        ["invalid"],
        "P3-low",
        (
            "Thanks for reaching out - this does not look like a project issue. "
            "Please open a new ticket with a minimal repro if you hit a real bug."
        ),
        "Spam or off-topic content detected; closing pattern.",
    )


def mock_duplicate(issue: Issue, dup: Issue, confidence: float) -> TriageResult:
    return _mk(
        issue.number,
        "duplicate",
        0.55,
        ["duplicate"],
        "P3-low",
        f"Thanks! This looks related to #{dup.number}. "
        "I will close this as duplicate; please follow that thread for updates.",
        "Strong title similarity to a recent issue.",
        dup_of=dup.number,
        is_dup=True,
        dup_conf=confidence,
    )


def mock_feature(issue: Issue) -> TriageResult:  # noqa: ARG001 - API symmetry
    return _mk(
        issue.number,
        "feature",
        0.72,
        ["feature", "enhancement"],
        "P2-medium",
        (
            "Thanks for the clear API sketch - could you confirm expected row schema "
            "and pagination? I will scope once we have that."
        ),
        "Structured feature request with partial API detail.",
    )


def mock_bug(issue: Issue) -> TriageResult:  # noqa: ARG001
    return _mk(
        issue.number,
        "bug",
        0.88,
        ["bug"],
        "P1-high",
        (
            "Thanks for the repro - can you attach a crash log symbolicated trace? "
            "We will verify on iOS 17.x shortly."
        ),
        "Repro steps and environment included.",
        review=False,
    )


def mock_question(issue: Issue) -> TriageResult:  # noqa: ARG001
    return _mk(
        issue.number,
        "question",
        0.45,
        ["question"],
        "P3-low",
        (
            "Thanks for filing - could you share minimal repro steps and expected behavior? "
            "That will help us respond quickly."
        ),
        "Insufficient detail for confident classification.",
    )


def _mk(
    num: int,
    classification: str,
    quality: float,
    labels: list[str],
    priority: str,
    draft: str,
    reasoning: str,
    *,
    dup_of: int | None = None,
    dup_conf: float | None = None,
    is_dup: bool = False,
    review: bool = True,
) -> TriageResult:
    return TriageResult(
        issue_number=num,
        classification=classification,
        quality_score=quality,
        is_duplicate=is_dup,
        duplicate_of=dup_of,
        duplicate_confidence=dup_conf,
        suggested_labels=labels,
        priority=priority,
        draft_response=draft,
        reasoning=reasoning,
        needs_human_review=review,
    )


def heuristic_triage(
    issue: Issue,
    recent: list[Issue],
    duplicate_threshold: float = 0.82,
) -> TriageResult:
    """Rule-based triage used when the LLM is unavailable."""
    low = issue.title.lower()
    if "money fast" in low or "spam" in low:
        return mock_invalid(issue)
    dup, confidence = find_duplicate_candidate(issue, recent, threshold=duplicate_threshold)
    if dup:
        return mock_duplicate(issue, dup, confidence)
    if "csv" in low or "export" in low:
        return mock_feature(issue)
    if "crash" in low and "dark" in low:
        return mock_bug(issue)
    return mock_question(issue)
