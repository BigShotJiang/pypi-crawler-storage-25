"""Rich tables and export formats."""

from __future__ import annotations

import json
from collections.abc import Iterable
from datetime import UTC, datetime
from pathlib import Path

from rich import box
from rich.panel import Panel
from rich.table import Table

from .models import Issue, TriageResult


def summary_counts(results: list[TriageResult]) -> tuple[int, int, int]:
    high = sum(1 for r in results if r.quality_score >= 0.75 and not r.needs_human_review)
    review = sum(1 for r in results if r.needs_human_review)
    dups = sum(1 for r in results if r.is_duplicate)
    return high, review, dups


def render_summary_panel(results: list[TriageResult]) -> Panel:
    high, review, dups = summary_counts(results)
    text = (
        f"[green]OK high quality (auto-friendly): {high}[/green] | "
        f"[yellow]! needs review: {review}[/yellow] | "
        f"[cyan]~ duplicates flagged: {dups}[/cyan]"
    )
    return Panel(text, title="Textor Nexuum Summary", expand=False)


def _draft_cell(r: TriageResult, titles: dict[int, str]) -> str:
    draft = r.draft_response.replace("\n", " ")
    if len(draft) > 70:
        draft = draft[:67] + "..."
    title = titles.get(r.issue_number, "")
    if title:
        return f"[dim]{title[:40]}[/dim] | {draft}"
    return draft


def _row_values(r: TriageResult, titles: dict[int, str]) -> tuple[str, ...]:
    dup = f"of #{r.duplicate_of}" if r.is_duplicate and r.duplicate_of else "-"
    dup_conf = f"{r.duplicate_confidence:.2f}" if r.duplicate_confidence is not None else "-"
    labels = ", ".join(r.suggested_labels) or "-"
    review = "!" if r.needs_human_review else "+"
    draft = _draft_cell(r, titles)
    return (
        str(r.issue_number),
        r.classification,
        f"{r.quality_score:.2f}",
        r.priority,
        dup,
        dup_conf,
        labels,
        review,
        draft,
    )


def render_issues_table(results: list[TriageResult], titles: dict[int, str]) -> Table:
    table = Table(title="Textor Nexuum Report", box=box.SIMPLE_HEAVY)
    table.add_column("#", justify="right")
    table.add_column("Class")
    table.add_column("Quality", justify="right")
    table.add_column("Priority")
    table.add_column("Dup")
    table.add_column("DupConf", justify="right")
    table.add_column("Labels")
    table.add_column("Review?")
    table.add_column("Draft (trimmed)")
    for r in results:
        table.add_row(*_row_values(r, titles))
    return table


def _frontmatter_yaml_block(owner: str, repo: str, results: list[TriageResult]) -> str:
    when = datetime.now(UTC).date().isoformat()
    high, review, dups = summary_counts(results)
    lines = (
        "---",
        "generator: textor-nexuum",
        f"date: {when}",
        f"repo: {owner}/{repo}",
        f"issues: {len(results)}",
        f"high_quality: {high}",
        f"needs_review: {review}",
        f"duplicates: {dups}",
        "---",
        "",
    )
    return "\n".join(lines)


def _frontmatter_markdown_intro() -> str:
    return (
        "## Recommended next actions\n\n"
        "- Review flagged rows first; confirm duplicate links before closing.\n"
        "- Apply labels only after human spot-check unless you passed `--yes`.\n\n"
        "## Triage details\n\n"
    )


def _frontmatter(owner: str, repo: str, results: list[TriageResult]) -> str:
    return _frontmatter_yaml_block(owner, repo, results) + _frontmatter_markdown_intro()


def _issue_sections(results: list[TriageResult], title_by_num: dict[int, str]) -> str:
    chunks: list[str] = []
    for r in results:
        t = title_by_num.get(r.issue_number, "")
        chunks.append(f"### #{r.issue_number} - {t}\n")
        chunks.append(f"- **classification**: {r.classification}\n")
        chunks.append(f"- **priority**: {r.priority}\n")
        chunks.append(f"- **quality**: {r.quality_score:.2f}\n")
        chunks.append(f"- **duplicate**: {r.is_duplicate} {r.duplicate_of or ''}\n")
        chunks.append(f"- **duplicate confidence**: {r.duplicate_confidence}\n")
        chunks.append(f"- **labels**: {', '.join(r.suggested_labels)}\n")
        chunks.append(f"- **needs review**: {r.needs_human_review}\n")
        chunks.append(f"- **reasoning**: {r.reasoning}\n\n")
        chunks.append(f"{r.draft_response}\n\n")
    return "".join(chunks)


def save_markdown(
    path: Path,
    owner: str,
    repo: str,
    issues: Iterable[Issue],
    results: list[TriageResult],
) -> None:
    title_by_num = {i.number: i.title for i in issues}
    body = _frontmatter(owner, repo, results) + _issue_sections(results, title_by_num)
    path.write_text(body, encoding="utf-8")


def save_json(
    path: Path,
    issues: Iterable[Issue],
    results: list[TriageResult],
) -> None:
    title_by_num = {i.number: i.title for i in issues}
    payload: list[dict[str, object]] = []
    for r in results:
        row: dict[str, object] = r.model_dump()
        row["original_title"] = title_by_num.get(r.issue_number, "")
        payload.append(row)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
