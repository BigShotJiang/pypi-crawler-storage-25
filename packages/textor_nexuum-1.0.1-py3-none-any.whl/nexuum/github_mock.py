"""Deterministic sample issues for offline / unauthenticated use."""

from __future__ import annotations

from .models import Issue

MOCK_ISSUES: list[Issue] = [
    Issue(
        number=101,
        title="App crashes on startup when Dark Mode is enabled",
        body=(
            "Steps: 1) Enable Dark Mode 2) Relaunch app\n"
            "Expected: app opens\n"
            "Actual: crash. iOS 17.2, v1.4.0"
        ),
        user="alice",
        created_at="2024-01-10T10:00:00Z",
        labels=[],
    ),
    Issue(
        number=102,
        title="App crashes on startup when Dark Mode enabled",
        body="Same crash as others with dark theme.",
        user="bob",
        created_at="2024-01-11T10:00:00Z",
        labels=[],
    ),
    Issue(
        number=103,
        title="Add CSV export for billing dashboard",
        body=(
            "We need export of the billing table to CSV for finance.\n"
            "API shape: GET /exports/billing.csv with date range query params."
        ),
        user="carol",
        created_at="2024-01-12T10:00:00Z",
        labels=[],
    ),
    Issue(
        number=104,
        title="MAKE MONEY FAST click here",
        body="Spam spam spam buy now",
        user="spammer",
        created_at="2024-01-13T10:00:00Z",
        labels=[],
    ),
]


def mock_slice(limit: int) -> list[Issue]:
    """Return up to ``limit`` mock issues."""
    return MOCK_ISSUES[:limit]


def mock_by_number(issue_number: int) -> Issue | None:
    """Return a mock issue with ``issue_number`` if present."""
    for issue in MOCK_ISSUES:
        if issue.number == issue_number:
            return issue
    return None
