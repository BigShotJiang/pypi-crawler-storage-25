"""Normalize GitHub REST payloads into ``Issue`` models."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .models import Issue


def _label_names(labels_raw: object) -> list[str]:
    if not isinstance(labels_raw, list):
        return []
    names: list[str] = []
    for label in labels_raw:
        if isinstance(label, dict) and "name" in label:
            names.append(str(label["name"]))
    return names


def _login(user_raw: object) -> str:
    if isinstance(user_raw, dict):
        return str(user_raw.get("login", "unknown"))
    return "unknown"


def parse_github_issue(item: Mapping[str, Any]) -> Issue | None:
    """Parse a GitHub issue JSON object; return ``None`` if invalid."""
    num = item.get("number")
    if not isinstance(num, int):
        return None
    title = item.get("title", "")
    body_val = item.get("body") or ""
    created = item.get("created_at", "")
    return Issue(
        number=num,
        title=str(title),
        body=str(body_val),
        user=_login(item.get("user")),
        created_at=str(created),
        labels=_label_names(item.get("labels", [])),
    )
