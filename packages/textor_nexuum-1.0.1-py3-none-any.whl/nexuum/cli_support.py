"""Shared CLI helpers (parsing, triage loop, exports)."""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.progress import track

from .analyzer import TriageAnalyzer
from .github_client import GitHubClient
from .models import Issue, NexuumConfig, TriageResult
from .reporting import render_issues_table, render_summary_panel, save_json, save_markdown


def parse_repo(spec: str, console: Console) -> tuple[str, str]:
    pat = r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$"
    if not re.match(pat, spec):
        console.print(
            "[red]Invalid repo format.[/red] Use [bold]owner/repo[/bold] "
            "(alphanumeric, dots, hyphens)."
        )
        raise typer.Exit(code=2)
    owner, name = spec.split("/", 1)
    return owner, name


def merge_config(
    base: NexuumConfig,
    model: str | None,
    base_url: str | None,
) -> NexuumConfig:
    data = base.model_dump()
    if model:
        data["llm_model"] = model
    if base_url:
        data["base_url"] = base_url
    return NexuumConfig.model_validate(data)


def resolve_output_path(out: Path | None, fmt: str) -> Path | None:
    if out is None:
        return None
    if out.suffix:
        return out
    ext = ".md" if fmt == "md" else ".json" if fmt == "json" else ".md"
    return out.with_suffix(ext)


def infer_format_from_path(path: Path) -> str:
    if path.suffix.lower() == ".json":
        return "json"
    return "md"


def json_payload(issues: list[Issue], results: list[TriageResult]) -> list[dict[str, Any]]:
    title_by_num = {i.number: i.title for i in issues}
    rows: list[dict[str, Any]] = []
    for r in results:
        row = r.model_dump()
        row["original_title"] = title_by_num.get(r.issue_number, "")
        rows.append(row)
    return rows


def run_triages(
    gh: GitHubClient,
    owner: str,
    name: str,
    issue_num: int | None,
    lim: int,
    analyzer: TriageAnalyzer,
    console: Console,
) -> tuple[list[Issue], list[TriageResult]]:
    if issue_num is not None:
        return _triages_single(gh, owner, name, issue_num, lim, analyzer, console)
    return _triages_bulk(gh, owner, name, lim, analyzer)


def _triages_single(
    gh: GitHubClient,
    owner: str,
    name: str,
    issue_num: int,
    lim: int,
    analyzer: TriageAnalyzer,
    console: Console,
) -> tuple[list[Issue], list[TriageResult]]:
    primary = gh.get_issue(owner, name, issue_num)
    if primary is None:
        console.print(f"[red]Issue #{issue_num} not found[/red]")
        raise typer.Exit(code=1)
    recent_src = gh.get_issues(owner, name, limit=max(lim, 30))
    recent = [i for i in recent_src if i.number != issue_num][:30]
    res = analyzer.analyze(primary, recent)
    return [primary], [res]


def _triages_bulk(
    gh: GitHubClient,
    owner: str,
    name: str,
    lim: int,
    analyzer: TriageAnalyzer,
) -> tuple[list[Issue], list[TriageResult]]:
    all_issues = gh.get_issues(owner, name, limit=lim)
    results: list[TriageResult] = []
    for issue in track(all_issues, description="Triage"):
        recent = [i for i in all_issues if i.number != issue.number]
        results.append(analyzer.analyze(issue, recent))
    return all_issues, results


def output_format_for_write(
    output: Path | None,
    out_path: Path | None,
    fmt: str,
) -> str:
    if out_path is None or output is None:
        return fmt
    if output.suffix:
        return infer_format_from_path(out_path)
    if fmt in ("md", "json"):
        return fmt
    return "md"


def write_and_print_reports(
    *,
    fmt: str,
    output: Path | None,
    out_path: Path | None,
    out_fmt: str,
    owner: str,
    name: str,
    issues: list[Issue],
    results: list[TriageResult],
    titles: dict[int, str],
    console: Console,
) -> None:
    if out_path:
        _write_disk(out_path, out_fmt, owner, name, issues, results, console)
    if fmt == "json" and output is None:
        console.print(json.dumps(json_payload(issues, results), indent=2))
    if fmt in ("table", "md"):
        console.print(render_summary_panel(results))
        console.print(render_issues_table(results, titles))


def _write_disk(
    path: Path,
    out_fmt: str,
    owner: str,
    name: str,
    issues: list[Issue],
    results: list[TriageResult],
    console: Console,
) -> None:
    if out_fmt == "json":
        save_json(path, issues, results)
    else:
        save_markdown(path, owner, name, issues, results)
    console.print(f"[green]Wrote {path}[/green]")


def build_runtime(
    cfg: NexuumConfig,
    model: str | None,
    base_url: str | None,
    api_key: str | None,
) -> tuple[NexuumConfig, TriageAnalyzer, GitHubClient]:
    merged = merge_config(cfg, model, base_url)
    key = api_key or os.environ.get("GROK_API_KEY") or os.environ.get("OPENAI_API_KEY")
    analyzer = TriageAnalyzer(merged, api_key=key)
    token = os.environ.get("GITHUB_TOKEN", "")
    gh = GitHubClient(token=token, config=merged)
    return merged, analyzer, gh
