"""GitHub REST client using requests only."""

from __future__ import annotations

import os
import time
from typing import Any

import requests

from .github_mock import mock_by_number, mock_slice
from .github_parse import parse_github_issue
from .models import Issue, NexuumConfig

USER_AGENT = "Textor Nexuum/0.1 (+https://github.com/FratresMedAI/TextorNexuum)"
API_VERSION = "2022-11-28"


class GitHubClient:
    def __init__(
        self,
        token: str | None = None,
        mock: bool = False,
        config: NexuumConfig | None = None,
    ) -> None:
        self.token = token or os.environ.get("GITHUB_TOKEN", "")
        self.mock = mock or not self.token
        self.config = config
        self.base_url = "https://api.github.com"
        self.headers = self._build_headers()

    def _build_headers(self) -> dict[str, str]:
        hdrs = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": API_VERSION,
            "User-Agent": USER_AGENT,
        }
        if self.token and not self.mock:
            hdrs["Authorization"] = f"Bearer {self.token}"
        return hdrs

    def get_issues(self, owner: str, repo: str, limit: int = 30) -> list[Issue]:
        if self.mock:
            return mock_slice(limit)
        return self._fetch_issues_live(owner, repo, limit)

    def _fetch_issues_live(self, owner: str, repo: str, limit: int) -> list[Issue]:
        url = f"{self.base_url}/repos/{owner}/{repo}/issues"
        params = {"state": "open", "per_page": str(min(limit, 100))}
        resp = requests.get(url, headers=self.headers, params=params, timeout=15)
        if resp.status_code != 200:
            return mock_slice(limit)
        parsed = self._parse_issue_list(resp.json(), limit)
        time.sleep(0.2)
        return parsed

    def _parse_issue_list(self, body: object, limit: int) -> list[Issue]:
        raw_items = body if isinstance(body, list) else []
        out: list[Issue] = []
        for item in raw_items:
            if not isinstance(item, dict) or "pull_request" in item:
                continue
            issue = parse_github_issue(item)
            if issue is not None:
                out.append(issue)
            if len(out) >= limit:
                break
        return out

    def get_issue(self, owner: str, repo: str, issue_number: int) -> Issue | None:
        if self.mock:
            return mock_by_number(issue_number)
        return self._fetch_issue_live(owner, repo, issue_number)

    def _fetch_issue_live(self, owner: str, repo: str, issue_number: int) -> Issue | None:
        url = f"{self.base_url}/repos/{owner}/{repo}/issues/{issue_number}"
        resp = requests.get(url, headers=self.headers, timeout=15)
        if resp.status_code != 200:
            return None
        time.sleep(0.2)
        data = resp.json()
        if not isinstance(data, dict):
            return None
        return parse_github_issue(data)

    def add_labels(self, owner: str, repo: str, issue_number: int, labels: list[str]) -> bool:
        url = f"{self.base_url}/repos/{owner}/{repo}/issues/{issue_number}/labels"
        try:
            r = requests.post(url, headers=self.headers, json={"labels": labels}, timeout=10)
            return r.status_code == 200
        except OSError:
            return False

    def post_comment(self, owner: str, repo: str, issue_number: int, body: str) -> bool:
        url = f"{self.base_url}/repos/{owner}/{repo}/issues/{issue_number}/comments"
        try:
            r = requests.post(url, headers=self.headers, json={"body": body}, timeout=10)
            return r.status_code == 201
        except OSError:
            return False

    def get_repo_info(self, owner: str, repo: str) -> dict[str, Any]:
        if self.mock:
            return {"stargazers_count": 42, "open_issues_count": 3, "description": "Mock repo"}
        url = f"{self.base_url}/repos/{owner}/{repo}"
        r = requests.get(url, headers=self.headers, timeout=15)
        if r.status_code != 200:
            return {}
        data = r.json()
        time.sleep(0.2)
        if not isinstance(data, dict):
            return {}
        return {
            "stargazers_count": data.get("stargazers_count"),
            "open_issues_count": data.get("open_issues_count"),
            "description": str(data.get("description") or ""),
        }
