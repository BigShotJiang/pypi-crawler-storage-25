"""Textor Nexuum - AI-assisted GitHub issue triage (CLI: nexuum)."""

from __future__ import annotations

import importlib.metadata

from .version_info import VERSION

__all__ = ["__version__", "package_version"]

try:
    __version__: str = importlib.metadata.version("textor-nexuum")
except importlib.metadata.PackageNotFoundError:
    __version__ = VERSION


def package_version() -> str:
    """Return the installed package version, or the embedded fallback."""
    return __version__
