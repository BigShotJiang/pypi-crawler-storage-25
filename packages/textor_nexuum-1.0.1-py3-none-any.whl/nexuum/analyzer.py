"""Thin analyzer facade over LLM client."""

from __future__ import annotations

from .llm_client import LLMClient
from .models import Issue, NexuumConfig, TriageResult


class TriageAnalyzer:
    def __init__(self, config: NexuumConfig, api_key: str | None = None) -> None:
        self.config = config
        self.llm = LLMClient(
            api_key=api_key,
            model=config.llm_model,
            base_url=config.base_url,
        )

    def analyze(self, issue: Issue, recent: list[Issue]) -> TriageResult:
        return self.llm.triage_issue(issue, recent, self.config)
