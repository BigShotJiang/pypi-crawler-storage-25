"""Pydantic models for issues, triage output, and configuration."""

from __future__ import annotations

from urllib.parse import urlparse

from pydantic import BaseModel, ConfigDict, Field, field_validator


class Issue(BaseModel):
    number: int
    title: str
    body: str = ""
    user: str = "unknown"
    created_at: str = ""
    labels: list[str] = Field(default_factory=list)


class TriageResult(BaseModel):
    issue_number: int
    classification: str = Field(
        ...,
        pattern="^(bug|feature|question|documentation|enhancement|invalid|duplicate)$",
    )
    quality_score: float = Field(..., ge=0.0, le=1.0)
    is_duplicate: bool = False
    duplicate_of: int | None = None
    duplicate_confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    suggested_labels: list[str] = Field(default_factory=list)
    priority: str = Field(..., pattern="^P[0-3]-(critical|high|medium|low)$")
    draft_response: str = Field(..., min_length=10, max_length=600)
    reasoning: str = Field(..., min_length=5, max_length=300)
    needs_human_review: bool = True
    token_usage: dict[str, int] | None = None

    @property
    def prompt_tokens(self) -> int:
        return int((self.token_usage or {}).get("prompt_tokens", 0))

    @property
    def completion_tokens(self) -> int:
        return int((self.token_usage or {}).get("completion_tokens", 0))

    @field_validator("suggested_labels")
    @classmethod
    def clean_labels(cls, v: list[str]) -> list[str]:
        return [label.lower().strip() for label in v if label][:5]


class NexuumConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    llm_model: str = Field(default="grok-4.1-fast", alias="model")
    base_url: str = "https://api.x.ai/v1"
    max_issues: int = 30
    duplicate_threshold: float = 0.82
    custom_labels: list[str] = Field(default_factory=lambda: ["needs-triage", "good-first-issue"])
    allowed_labels: list[str] = Field(
        default_factory=lambda: ["bug", "feature", "documentation", "question", "enhancement"]
    )
    prompt_additions: str = ""

    @property
    def model(self) -> str:
        return self.llm_model

    @field_validator("max_issues")
    @classmethod
    def validate_max_issues(cls, v: int) -> int:
        if 1 <= v <= 500:
            return v
        raise ValueError("max_issues must be between 1 and 500")

    @field_validator("base_url")
    @classmethod
    def validate_base_url(cls, v: str) -> str:
        parsed = urlparse(v.rstrip("/"))
        if parsed.scheme in {"http", "https"} and parsed.netloc:
            return v.rstrip("/")
        raise ValueError("base_url must be a valid http(s) URL")

    @field_validator("allowed_labels", "custom_labels")
    @classmethod
    def normalize_labels(cls, labels: list[str]) -> list[str]:
        cleaned = [label.lower().strip() for label in labels if label.strip()]
        return list(dict.fromkeys(cleaned))

    @field_validator("duplicate_threshold")
    @classmethod
    def validate_duplicate_threshold(cls, v: float) -> float:
        if 0.5 <= v <= 0.99:
            return v
        raise ValueError("duplicate_threshold must be between 0.5 and 0.99")


TextorConfig = NexuumConfig
