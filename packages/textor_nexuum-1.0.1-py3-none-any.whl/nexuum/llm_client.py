"""OpenAI-compatible LLM client for triage."""

from __future__ import annotations

import difflib
import json
import os
import time
from typing import Any

import requests
from rich.console import Console

from .llm_heuristic import find_duplicate_candidate, heuristic_triage
from .models import Issue, NexuumConfig, TriageResult
from .prompts import PROMPT_VERSION, SYSTEM_TRIAGE, user_triage_prompt

console = Console(stderr=True)


class LLMClient:
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "grok-4.1-fast",
        base_url: str = "https://api.x.ai/v1",
    ) -> None:
        self.api_key = api_key or os.environ.get("GROK_API_KEY") or os.environ.get("OPENAI_API_KEY")
        self.model = model
        self.base_url = base_url.rstrip("/")

    def triage_issue(
        self,
        issue: Issue,
        recent_issues: list[Issue],
        config: NexuumConfig,
    ) -> TriageResult:
        if not self.api_key:
            return self._mock_with_config(issue, recent_issues, config)
        live = self._live_triage(issue, recent_issues, config)
        if live is None:
            self._warn_fallback()
            return heuristic_triage(
                issue,
                recent_issues,
                duplicate_threshold=config.duplicate_threshold,
            )
        return self._adjust_duplicates(issue, recent_issues, live, config)

    def _warn_fallback(self) -> None:
        console.print("[yellow]LLM parse failed; using heuristic triage.[/yellow]")

    def _mock_with_config(
        self,
        issue: Issue,
        recents: list[Issue],
        config: NexuumConfig,
    ) -> TriageResult:
        base = self._mock_triage(issue, recents)
        other, confidence = find_duplicate_candidate(
            issue,
            recents,
            threshold=config.duplicate_threshold,
        )
        if other is None:
            if base.is_duplicate:
                return self._mock_triage(issue, [])
            return base
        data = base.model_dump()
        data["is_duplicate"] = True
        data["duplicate_of"] = other.number
        data["duplicate_confidence"] = confidence
        data["classification"] = "duplicate"
        data["priority"] = "P3-low"
        data["needs_human_review"] = True
        data["suggested_labels"] = ["duplicate"]
        return TriageResult.model_validate(data)

    def _mock_triage(self, issue: Issue, recents: list[Issue]) -> TriageResult:
        title_l = issue.title.lower()
        body_l = issue.body.lower()
        has_repro = any(
            k in body_l for k in ["step", "reproduce", "expect", "actual", "error", "crash"]
        )
        quality = (
            0.92
            if len(issue.body) > 180 and has_repro
            else 0.78
            if len(issue.body) > 100 and has_repro
            else 0.55
            if len(issue.body) > 60
            else 0.38
        )
        if any(k in title_l for k in ["crash", "broken", "error", "fail", "bug"]):
            cls, prio = "bug", "P1-high"
        elif any(k in title_l for k in ["add", "support", "feature", "request", "implement"]):
            cls, prio = "feature", "P2-medium"
        elif any(k in title_l for k in ["doc", "documentation", "readme", "example"]):
            cls, prio = "documentation", "P3-low"
        elif len(issue.body) < 35 or any(
            k in body_l for k in ["pls", "please fix", "help me", "wtf"]
        ):
            cls, prio = "invalid", "P3-low"
        else:
            cls, prio = "question", "P2-medium"
        dup_of = None
        for r in recents:
            if r.number != issue.number:
                ratio = difflib.SequenceMatcher(None, title_l, r.title.lower()).ratio()
                if ratio > 0.78:
                    dup_of = r.number
                    cls = "duplicate"
                    prio = "P3-low"
                    break
        if cls == "bug":
            draft = "Thanks for reporting this! Attach the full error log + steps to reproduce."
        elif cls == "feature":
            draft = "Solid idea. Would you open a PR or discuss the design?"
        elif cls == "documentation":
            draft = "Good catch. We'll improve the docs."
        elif cls == "duplicate":
            draft = f"Thanks — duplicate of #{dup_of}. Closing."
        else:
            draft = "Thanks. We've answered similar questions in the FAQ."
        prompt_tokens = 420 + len(issue.body) // 3
        completion_tokens = 180 + (40 if cls == "bug" else 25)
        reasoning = (
            "High quality report with clear reproduction steps."
            if quality > 0.85
            else "Good detail but missing environment info."
            if quality > 0.65
            else "Low detail — needs more information from reporter."
        )
        return TriageResult(
            issue_number=issue.number,
            classification=cls,
            quality_score=round(quality, 2),
            is_duplicate=bool(dup_of),
            duplicate_of=dup_of,
            suggested_labels=[cls, "needs-triage"] if cls != "duplicate" else ["duplicate"],
            priority=prio,
            draft_response=draft,
            reasoning=reasoning,
            needs_human_review=quality < 0.70 or bool(dup_of),
            token_usage={
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            },
        )

    def _live_triage(
        self,
        issue: Issue,
        recent_issues: list[Issue],
        config: NexuumConfig,
    ) -> TriageResult | None:
        url, headers, payload = self._request_parts(issue, recent_issues, config)
        try:
            return self._post_and_parse(url, headers, payload, issue.number)
        except (
            OSError,
            requests.RequestException,
            ValueError,
            json.JSONDecodeError,
            KeyError,
            IndexError,
        ):
            return None

    def _request_parts(
        self,
        issue: Issue,
        recent_issues: list[Issue],
        config: NexuumConfig,
    ) -> tuple[str, dict[str, str], dict[str, Any]]:
        if self._is_anthropic():
            return self._anthropic_parts(issue, recent_issues, config)
        elif "ollama" in self.base_url.lower() or "localhost" in self.base_url.lower():
            # Ollama / local LLM support (OpenAI-compatible format)
            url = f"{self.base_url}/chat/completions"
            SYSTEM_PROMPT = SYSTEM_TRIAGE
            user_prompt = self._user_content(issue, recent_issues, config)
            headers = {"Content-Type": "application/json"}
            payload = {
                "model": self.model,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                "temperature": 0.05,
                "max_tokens": 700,
                "response_format": {"type": "json_object"},
            }
            return url, headers, payload
        return self._openai_parts(issue, recent_issues, config)

    def _is_anthropic(self) -> bool:
        return "anthropic" in self.base_url.lower()

    def _openai_parts(
        self,
        issue: Issue,
        recent_issues: list[Issue],
        config: NexuumConfig,
    ) -> tuple[str, dict[str, str], dict[str, Any]]:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = self._chat_payload(issue, recent_issues, config)
        return url, headers, payload

    def _anthropic_parts(
        self,
        issue: Issue,
        recent_issues: list[Issue],
        config: NexuumConfig,
    ) -> tuple[str, dict[str, str], dict[str, Any]]:
        url = f"{self.base_url}/messages"
        headers = {
            "x-api-key": str(self.api_key),
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = self._anthropic_payload(issue, recent_issues, config)
        return url, headers, payload

    def _chat_payload(
        self,
        issue: Issue,
        recent: list[Issue],
        config: NexuumConfig,
    ) -> dict[str, Any]:
        return {
            "model": self.model,
            "temperature": 0.05,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": SYSTEM_TRIAGE},
                {"role": "user", "content": self._user_content(issue, recent, config)},
            ],
        }

    def _anthropic_payload(
        self,
        issue: Issue,
        recent: list[Issue],
        config: NexuumConfig,
    ) -> dict[str, Any]:
        return {
            "model": self.model,
            "max_tokens": 1000,
            "temperature": 0.05,
            "system": SYSTEM_TRIAGE,
            "messages": [
                {
                    "role": "user",
                    "content": self._user_content(issue, recent, config),
                }
            ],
        }

    def _post_and_parse(
        self,
        url: str,
        headers: dict[str, str],
        payload: dict[str, Any],
        issue_number: int,
    ) -> TriageResult | None:
        resp = self._post_with_retries(url, headers, payload)
        resp.raise_for_status()
        data = resp.json()
        if not isinstance(data, dict):
            return None
        content = self._extract_content(data)
        if not content:
            return None
        parsed_obj = json.loads(content)
        if not isinstance(parsed_obj, dict):
            return None
        usage = self._extract_usage(data)
        if usage:
            parsed_obj["token_usage"] = usage
        time.sleep(1.0)
        return self._parse_result(issue_number, parsed_obj)

    def _post_with_retries(
        self,
        url: str,
        headers: dict[str, str],
        payload: dict[str, Any],
    ) -> requests.Response:
        attempts = 3
        for attempt in range(attempts):
            try:
                return requests.post(url, headers=headers, json=payload, timeout=60)
            except requests.RequestException as exc:
                if attempt == attempts - 1:
                    msg = f"[red]LLM API request failed after {attempts} retries: {exc}[/red]"
                    console.print(msg)
                    raise
                time.sleep(2**attempt)
        raise RuntimeError("unreachable")

    def _extract_content(self, data: dict[str, Any]) -> str | None:
        if self._is_anthropic():
            return self._extract_anthropic_content(data)
        return self._extract_openai_content(data)

    def _extract_openai_content(self, data: dict[str, Any]) -> str | None:
        raw = data.get("choices", [])
        if not isinstance(raw, list) or not raw:
            return None
        first = raw[0]
        if not isinstance(first, dict):
            return None
        msg = first.get("message", {})
        if not isinstance(msg, dict):
            return None
        return str(msg.get("content", ""))

    def _extract_anthropic_content(self, data: dict[str, Any]) -> str | None:
        raw = data.get("content", [])
        if not isinstance(raw, list) or not raw:
            return None
        first = raw[0]
        if not isinstance(first, dict):
            return None
        return str(first.get("text", ""))

    def _extract_usage(self, data: dict[str, Any]) -> dict[str, int] | None:
        raw = data.get("usage")
        if not isinstance(raw, dict):
            return None
        if self._is_anthropic():
            return self._normalize_anthropic_usage(raw)
        return self._normalize_openai_usage(raw)

    def _normalize_openai_usage(self, raw: dict[str, Any]) -> dict[str, int]:
        prompt = int(raw.get("prompt_tokens", 0))
        completion = int(raw.get("completion_tokens", 0))
        total = int(raw.get("total_tokens", prompt + completion))
        return {
            "prompt_tokens": prompt,
            "completion_tokens": completion,
            "total_tokens": total,
        }

    def _normalize_anthropic_usage(self, raw: dict[str, Any]) -> dict[str, int]:
        prompt = int(raw.get("input_tokens", 0))
        completion = int(raw.get("output_tokens", 0))
        total = prompt + completion
        return {
            "prompt_tokens": prompt,
            "completion_tokens": completion,
            "total_tokens": total,
        }

    def _user_content(self, issue: Issue, recent: list[Issue], config: NexuumConfig) -> str:
        allowed = sorted(set(config.allowed_labels + config.custom_labels))
        allowed_str = ", ".join(allowed)
        recent_summaries = self._build_recent_summaries(recent)
        return user_triage_prompt(
            issue.number,
            issue.title,
            issue.user,
            issue.created_at,
            issue.body,
            recent_summaries,
            allowed_str,
            config.prompt_additions or "",
        )

    def _build_recent_summaries(self, issues: list[Issue]) -> str:
        lines = [f"#{i.number}: {i.title}" for i in issues]
        return "\n".join(lines) if lines else "(none)"

    def _parse_result(self, issue_number: int, payload: dict[str, Any]) -> TriageResult | None:
        try:
            merged = dict(payload)
            merged["issue_number"] = issue_number
            return TriageResult.model_validate(merged)
        except Exception:
            return None

    def _adjust_duplicates(
        self,
        issue: Issue,
        recent: list[Issue],
        result: TriageResult,
        config: NexuumConfig,
    ) -> TriageResult:
        if result.is_duplicate:
            return result
        other, confidence = find_duplicate_candidate(
            issue,
            recent,
            threshold=config.duplicate_threshold,
        )
        if other is None:
            return result
        data = result.model_dump()
        data["is_duplicate"] = True
        data["duplicate_of"] = other.number
        data["duplicate_confidence"] = confidence
        data["classification"] = "duplicate"
        data["needs_human_review"] = True
        return TriageResult.model_validate(data)


def prompt_version() -> str:
    return PROMPT_VERSION
