"""Typer CLI entrypoint for Textor Nexuum (command: nexuum)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel

from . import package_version
from .apply_ops import apply_triage
from .cli_support import (
    build_runtime,
    output_format_for_write,
    parse_repo,
    resolve_output_path,
    run_triages,
    write_and_print_reports,
)
from .config import PRIMARY_DOTFILE, load_config
from .github_client import GitHubClient
from .llm_client import prompt_version
from .models import Issue, NexuumConfig, TriageResult

app = typer.Typer(
    name="nexuum",
    help="Textor Nexuum - weave AI clarity into GitHub issues (Grok / OpenAI-compatible).",
    invoke_without_command=True,
)
console = Console()

_STARTER_NEXUUM_YAML = (
    "# Textor Nexuum - https://github.com/FratresMedAI/TextorNexuum\n"
    "# Legacy config filename `.weaver.yaml` is still supported if you prefer it.\n"
    "model: grok-4.1-fast\n"
    "base_url: https://api.x.ai/v1\n"
    "max_issues: 30\n"
    "duplicate_threshold: 0.82\n"
    "allowed_labels:\n"
    "  - bug\n"
    "  - feature\n"
    "  - documentation\n"
    "  - question\n"
    "  - enhancement\n"
    "custom_labels:\n"
    "  - needs-triage\n"
    "  - good-first-issue\n"
    'prompt_additions: ""\n'
)


@app.callback()
def _root(
    ctx: typer.Context,
    show_version: bool = typer.Option(
        False,
        "--version",
        help="Print the installed version and exit.",
        is_eager=True,
    ),
) -> None:
    if show_version:
        typer.echo(package_version())
        raise typer.Exit(0)
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)


def _starter_nexuum_yaml() -> str:
    return _STARTER_NEXUUM_YAML


def _run_analyze_core(
    repo: str,
    limit: int | None,
    issue: int | None,
    model: str | None,
    api_key: str | None,
    base_url: str | None,
    config_path: Path | None,
) -> tuple[GitHubClient, str, str, list[Issue], list[TriageResult], NexuumConfig]:
    cfg = load_config(config_path)
    merged, analyzer, gh = build_runtime(cfg, model, base_url, api_key)
    lim = limit if limit is not None else merged.max_issues
    owner, name = parse_repo(repo, console)
    issues, results = run_triages(gh, owner, name, issue, lim, analyzer, console)
    return gh, owner, name, issues, results, merged


def _emit_analyze_reports(
    issues: list[Issue],
    results: list[TriageResult],
    owner: str,
    name: str,
    output: Path | None,
    fmt: str,
) -> None:
    titles = {i.number: i.title for i in issues}
    out_path = resolve_output_path(output, fmt)
    out_fmt = output_format_for_write(output, out_path, fmt)
    write_and_print_reports(
        fmt=fmt,
        output=output,
        out_path=out_path,
        out_fmt=out_fmt,
        owner=owner,
        name=name,
        issues=issues,
        results=results,
        titles=titles,
        console=console,
    )


def _emit_verbose_details(results: list[TriageResult]) -> None:
    for r in results:
        usage = r.token_usage or {}
        usage_line = (
            f"prompt={usage.get('prompt_tokens', 0)} "
            f"completion={usage.get('completion_tokens', 0)} "
            f"total={usage.get('total_tokens', 0)}"
        )
        body = f"Reasoning: {r.reasoning}\nToken usage: {usage_line}"
        console.print(Panel(body, title=f"Verbose Issue #{r.issue_number}", expand=False))


@app.command()
def analyze(
    repo: Annotated[str, typer.Argument(help="GitHub repository as owner/repo")],
    limit: Annotated[
        int | None,
        typer.Option("--limit", "-l", help="Max open issues to triage"),
    ] = None,
    issue: Annotated[
        int | None,
        typer.Option("--issue", "-i", help="Triage only this issue number"),
    ] = None,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write report to this path"),
    ] = None,
    fmt: Annotated[
        str,
        typer.Option("--format", "-f", help="Output format: table, md, json"),
    ] = "table",
    apply_flag: Annotated[bool, typer.Option("--apply", help="Apply labels + comment")] = False,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmations (careful)"),
    ] = False,
    model: Annotated[str | None, typer.Option("--model")] = None,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url")] = None,
    config_path: Annotated[Path | None, typer.Option("--config")] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", help="Show reasoning and token usage"),
    ] = False,
) -> None:
    """Fetch issues, triage with the LLM (or heuristics), render output, optional apply."""
    gh, owner, name, issues, results, cfg = _run_analyze_core(
        repo, limit, issue, model, api_key, base_url, config_path
    )
    _emit_analyze_reports(issues, results, owner, name, output, fmt)
    # Summary stats
    total = len(results)
    avg_quality = sum(r.quality_score for r in results) / total if total > 0 else 0
    needs_review = sum(1 for r in results if r.needs_human_review)
    duplicates = sum(1 for r in results if r.is_duplicate)
    console.print(
        Panel.fit(
            f"[bold]Summary:[/bold] {total} issues | Avg Quality: {avg_quality:.2f} | "
            f"Needs Review: {needs_review} | Duplicates: {duplicates}",
            border_style="green",
        )
    )
    if verbose:
        console.print(f"[dim]Using model: {cfg.model} @ {cfg.base_url}[/dim]")
        for res in results:
            total_tokens = getattr(res, "prompt_tokens", 0) + getattr(
                res,
                "completion_tokens",
                0,
            )
            console.print(
                Panel.fit(
                    f"[bold]Reasoning:[/bold] {res.reasoning}\n"
                    f"[bold]Token usage:[/bold] prompt={getattr(res, 'prompt_tokens', 0)} "
                    f"completion={getattr(res, 'completion_tokens', 0)} "
                    f"total={total_tokens}",
                    title=f"Verbose Issue #{res.issue_number}",
                    border_style="dim",
                )
            )
    if apply_flag:
        apply_triage(results, gh, owner, name, yes=yes)


config_app = typer.Typer(help="Manage Textor Nexuum configuration files.")


@config_app.command("init")
def config_init(
    force: Annotated[bool, typer.Option("--force")] = False,
) -> None:
    """Write a starter .nexuum.yaml in the working directory."""
    target = Path.cwd() / PRIMARY_DOTFILE
    if target.exists() and not force:
        console.print(f"[yellow]{target} exists. Use --force to overwrite.[/yellow]")
        raise typer.Exit(code=1)
    target.write_text(_starter_nexuum_yaml(), encoding="utf-8")
    console.print(f"[green]Wrote {target}[/green]")


app.add_typer(config_app, name="config")


@app.command("version")
def show_version() -> None:
    """Print CLI package version plus prompt bundle id."""
    payload = {"nexuum": package_version(), "prompts": prompt_version()}
    console.print(json.dumps(payload, indent=2))


def main() -> None:
    app()


if __name__ == "__main__":
    main()
