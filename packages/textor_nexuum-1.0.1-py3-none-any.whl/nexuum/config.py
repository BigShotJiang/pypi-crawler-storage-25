"""Load Textor Nexuum YAML configuration."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .models import NexuumConfig

PRIMARY_DOTFILE = ".nexuum.yaml"
LEGACY_DOTFILE = ".weaver.yaml"
XDG_DIR = Path.home() / ".config" / "nexuum"
XDG_FILE = XDG_DIR / "config.yaml"


def load_config(explicit_path: Path | None = None) -> NexuumConfig:
    """Load config: explicit path, then CWD dotfiles, then XDG."""
    data = _load_raw(explicit_path)
    if not data:
        return NexuumConfig()
    return NexuumConfig.model_validate(data)


def _load_raw(explicit_path: Path | None) -> dict[str, Any]:
    if explicit_path and explicit_path.is_file():
        return _read_yaml(explicit_path)
    cwd_primary = Path.cwd() / PRIMARY_DOTFILE
    if cwd_primary.is_file():
        return _read_yaml(cwd_primary)
    cwd_legacy = Path.cwd() / LEGACY_DOTFILE
    if cwd_legacy.is_file():
        return _read_yaml(cwd_legacy)
    if XDG_FILE.is_file():
        return _read_yaml(XDG_FILE)
    return {}


def _read_yaml(path: Path) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8")
    loaded = yaml.safe_load(raw)
    if loaded is None:
        return {}
    if not isinstance(loaded, dict):
        return {}
    return loaded


def default_init_filename() -> str:
    """Primary filename written by ``nexuum config init``."""
    return PRIMARY_DOTFILE
