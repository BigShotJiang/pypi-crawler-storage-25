from fastapi import FastAPI
from pydantic import BaseModel
from agents.score_agent import score_scene

app = FastAPI(title="NEURIA Sense Agent API")


class SceneParams(BaseModel):
    template: str
    has_3d_object: bool = False
    has_shader: bool = True
    dark_theme: bool = True
    industry: str = "tech"
    has_bloom: bool = False
    camera_fov: float = 55
    animation_speed: str = "slow"
    polygon_count: int = 0


@app.post("/score")
async def score_endpoint(params: SceneParams):
    """シーンスコアリング"""
    result = score_scene(params.model_dump())
    return result


@app.get("/health")
async def health():
    return {"status": "ok"}
