"""
NEURIAの感情パラメータをW3C Design Tokens Community Group (DTCG)
形式のJSONに変換する。

W3C DTCG仕様 (2025.10 Stable):
- $value: トークンの値
- $type: トークンの型（color, dimension, fontFamily, etc.）
- $description: 説明

References:
- https://design-tokens.github.io/community-group/format/
- https://www.w3.org/community/design-tokens/
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from lib.context import EMOTION_PARAMS


def generate_dtcg_tokens(emotion: str) -> dict:
    """感情パラメータをW3C DTCG形式のJSONに変換"""
    p = EMOTION_PARAMS.get(emotion)
    if not p:
        return {}

    return {
        "$description": f"NEURIA Emotion Design Tokens — {emotion}",
        "$extensions": {
            "neuria": {
                "emotion": emotion,
                "emotion_vector": p.get("emotion_vector", []),
                "version": "2.0.0",
            }
        },
        "color": {
            "background": {
                "$value": p["bg"],
                "$type": "color",
                "$description": "Primary background color",
            },
            "surface": {
                "$value": p["surface"],
                "$type": "color",
                "$description": "Surface/card background color",
            },
            "text": {
                "primary": {
                    "$value": p["text_primary"],
                    "$type": "color",
                    "$description": "Primary text color",
                },
                "secondary": {
                    "$value": p["text_secondary"],
                    "$type": "color",
                    "$description": "Secondary/muted text color",
                },
            },
            "accent": {
                "$value": p["accent"],
                "$type": "color",
                "$description": "Accent/brand color",
            },
            "accent-glow": {
                "$value": p["accent_glow"],
                "$type": "color",
                "$description": "Accent glow (rgba for shadows/glows)",
            },
            "border": {
                "default": {
                    "$value": p["card_border"].split("solid ")[-1] if "solid" in p["card_border"] else "rgba(255,255,255,0.06)",
                    "$type": "color",
                    "$description": "Default border color",
                },
            },
            "glow": {
                "primary": {
                    "$value": p["glow_orb_color"],
                    "$type": "color",
                    "$description": "Primary glow orb color",
                },
                "secondary": {
                    "$value": p["glow_orb_color_2"],
                    "$type": "color",
                    "$description": "Secondary glow orb color",
                },
            },
        },
        "typography": {
            "font-family": {
                "heading": {
                    "$value": p["font_families"][0] if p.get("font_families") else "Inter",
                    "$type": "fontFamily",
                    "$description": "Heading font family",
                },
                "body": {
                    "$value": p["font_families"][0] if p.get("font_families") else "Inter",
                    "$type": "fontFamily",
                    "$description": "Body font family",
                },
            },
            "font-weight": {
                "heading": {
                    "$value": p.get("heading_weight", [500, 600])[0],
                    "$type": "fontWeight",
                    "$description": "Heading font weight",
                },
                "body": {
                    "$value": p.get("body_weight", 400),
                    "$type": "fontWeight",
                    "$description": "Body font weight",
                },
            },
            "line-height": {
                "$value": str(p.get("line_height", 1.8)),
                "$type": "number",
                "$description": "Base line height",
            },
            "letter-spacing": {
                "$value": p.get("letter_spacing", "0em"),
                "$type": "dimension",
                "$description": "Base letter spacing",
            },
            "heading-scale": {
                "$value": p.get("heading_scale", "clamp(2.5rem, 6vw, 4.5rem)"),
                "$type": "dimension",
                "$description": "Heading font size scale",
            },
        },
        "spacing": {
            "section-padding": {
                "$value": p.get("section_padding", "clamp(4rem, 8vh, 6rem)"),
                "$type": "dimension",
                "$description": "Section vertical padding",
            },
            "card-padding": {
                "$value": p.get("card_padding", "2rem"),
                "$type": "dimension",
                "$description": "Card internal padding",
            },
        },
        "shape": {
            "border-radius": {
                "$value": p.get("border_radius", "8px"),
                "$type": "dimension",
                "$description": "Default border radius",
            },
        },
        "motion": {
            "transition-duration": {
                "$value": p.get("transition_duration", "0.3s"),
                "$type": "duration",
                "$description": "Default transition duration",
            },
            "easing": {
                "$value": p.get("easing", "cubic-bezier(0.4, 0, 0.2, 1)"),
                "$type": "cubicBezier",
                "$description": "Default easing curve",
            },
            "scroll-lerp": {
                "$value": p.get("scroll_lerp", 0.08),
                "$type": "number",
                "$description": "Smooth scroll interpolation factor",
            },
            "hover-lift": {
                "$value": p.get("hover_lift", "2px"),
                "$type": "dimension",
                "$description": "Hover translateY distance",
            },
            "glow-speed": {
                "$value": p.get("glow_orb_speed", "20s"),
                "$type": "duration",
                "$description": "Glow orb animation duration",
            },
        },
        "effect": {
            "bloom": {
                "intensity": {
                    "$value": p.get("bloom_intensity", 0.8),
                    "$type": "number",
                    "$description": "Three.js bloom pass intensity",
                },
                "threshold": {
                    "$value": p.get("bloom_threshold", 0.5),
                    "$type": "number",
                    "$description": "Three.js bloom threshold",
                },
                "radius": {
                    "$value": p.get("bloom_radius", 0.6),
                    "$type": "number",
                    "$description": "Three.js bloom radius",
                },
            },
            "chromatic-aberration": {
                "$value": p.get("chromatic_aberration", 0.0),
                "$type": "number",
                "$description": "Chromatic aberration strength (0 = off)",
            },
            "grain-opacity": {
                "$value": p.get("grain_opacity", 0.04),
                "$type": "number",
                "$description": "Film grain overlay opacity",
            },
            "vignette": {
                "offset": {
                    "$value": p.get("vignette_offset", 0.3),
                    "$type": "number",
                    "$description": "Vignette offset",
                },
                "darkness": {
                    "$value": p.get("vignette_darkness", 0.5),
                    "$type": "number",
                    "$description": "Vignette darkness",
                },
            },
            "card-blur": {
                "$value": p.get("card_blur", "12px"),
                "$type": "dimension",
                "$description": "Glassmorphism backdrop blur",
            },
        },
    }


def generate_css_variables(emotion: str) -> str:
    """感情パラメータをCSS変数として出力"""
    from lib.context import get_css_theme
    return get_css_theme(emotion)


def generate_tailwind_theme(emotion: str) -> str:
    """感情パラメータをTailwind v4 @theme形式で出力"""
    p = EMOTION_PARAMS.get(emotion)
    if not p:
        return ""

    font = p["font_families"][0] if p.get("font_families") else "Inter"

    return f"""@theme {{
  /* NEURIA Emotion: {emotion} */
  --color-bg: {p['bg']};
  --color-surface: {p['surface']};
  --color-text-primary: {p['text_primary']};
  --color-text-secondary: {p['text_secondary']};
  --color-accent: {p['accent']};
  --color-accent-glow: {p['accent_glow']};
  --color-glow-1: {p['glow_orb_color']};
  --color-glow-2: {p['glow_orb_color_2']};

  --font-heading: '{font}', system-ui, sans-serif;
  --font-body: '{font}', system-ui, sans-serif;
  --font-weight-heading: {p.get('heading_weight', [500])[0]};
  --font-weight-body: {p.get('body_weight', 400)};
  --leading-base: {p.get('line_height', 1.8)};
  --tracking-base: {p.get('letter_spacing', '0em')};

  --radius-default: {p.get('border_radius', '8px')};
  --spacing-section: {p.get('section_padding', 'clamp(4rem, 8vh, 6rem)')};
  --spacing-card: {p.get('card_padding', '2rem')};

  --duration-default: {p.get('transition_duration', '0.3s')};
  --ease-default: {p.get('easing', 'cubic-bezier(0.4, 0, 0.2, 1)')};
  --hover-lift: {p.get('hover_lift', '2px')};

  --blur-card: {p.get('card_blur', '12px')};
  --grain-opacity: {p.get('grain_opacity', 0.04)};
}}
"""


def generate_typescript_module(emotion: str) -> str:
    """感情パラメータをTypeScriptモジュールとして出力"""
    p = EMOTION_PARAMS.get(emotion)
    if not p:
        return ""

    font = p["font_families"][0] if p.get("font_families") else "Inter"

    return f"""// NEURIA Emotion Design Tokens — {emotion}
// Auto-generated. Do not edit manually.

export const {emotion}Tokens = {{
  color: {{
    bg: '{p['bg']}',
    surface: '{p['surface']}',
    textPrimary: '{p['text_primary']}',
    textSecondary: '{p['text_secondary']}',
    accent: '{p['accent']}',
    accentGlow: '{p['accent_glow']}',
    glow1: '{p['glow_orb_color']}',
    glow2: '{p['glow_orb_color_2']}',
  }},
  typography: {{
    headingFont: '{font}',
    bodyFont: '{font}',
    headingWeight: {p.get('heading_weight', [500])[0]},
    bodyWeight: {p.get('body_weight', 400)},
    lineHeight: {p.get('line_height', 1.8)},
    letterSpacing: '{p.get('letter_spacing', '0em')}',
    headingScale: '{p.get('heading_scale', 'clamp(2.5rem, 6vw, 4.5rem)')}',
  }},
  shape: {{
    borderRadius: '{p.get('border_radius', '8px')}',
  }},
  spacing: {{
    sectionPadding: '{p.get('section_padding', 'clamp(4rem, 8vh, 6rem)')}',
    cardPadding: '{p.get('card_padding', '2rem')}',
  }},
  motion: {{
    transitionDuration: '{p.get('transition_duration', '0.3s')}',
    easing: '{p.get('easing', 'cubic-bezier(0.4, 0, 0.2, 1)')}',
    scrollLerp: {p.get('scroll_lerp', 0.08)},
    hoverLift: '{p.get('hover_lift', '2px')}',
    glowSpeed: '{p.get('glow_orb_speed', '20s')}',
  }},
  effect: {{
    bloom: {{ intensity: {p.get('bloom_intensity', 0.8)}, threshold: {p.get('bloom_threshold', 0.5)}, radius: {p.get('bloom_radius', 0.6)} }},
    chromaticAberration: {p.get('chromatic_aberration', 0.0)},
    grainOpacity: {p.get('grain_opacity', 0.04)},
    vignette: {{ offset: {p.get('vignette_offset', 0.3)}, darkness: {p.get('vignette_darkness', 0.5)} }},
    cardBlur: '{p.get('card_blur', '12px')}',
  }},
  emotionVector: {p.get('emotion_vector', [])},
}} as const;

export type NeuriaTokens = typeof {emotion}Tokens;
"""


def generate_all_formats(emotion: str) -> dict:
    """全フォーマットを一括生成"""
    return {
        "dtcg": generate_dtcg_tokens(emotion),
        "css": generate_css_variables(emotion),
        "tailwind": generate_tailwind_theme(emotion),
        "typescript": generate_typescript_module(emotion),
    }


def build_all_tokens():
    """全6感情のトークンファイルを生成してtokens/ディレクトリに保存"""
    emotions = ["trust", "excitement", "calm", "luxury", "innovation", "energy"]

    output_dir = os.path.join(os.path.dirname(__file__), "output")
    os.makedirs(output_dir, exist_ok=True)

    for emotion in emotions:
        # DTCG JSON
        dtcg = generate_dtcg_tokens(emotion)
        with open(os.path.join(output_dir, f"{emotion}.tokens.json"), "w") as f:
            json.dump(dtcg, f, indent=2, ensure_ascii=False)

        # CSS変数
        css = generate_css_variables(emotion)
        with open(os.path.join(output_dir, f"{emotion}.css"), "w") as f:
            f.write(css)

        # Tailwind
        tw = generate_tailwind_theme(emotion)
        with open(os.path.join(output_dir, f"{emotion}.tailwind.css"), "w") as f:
            f.write(tw)

        # TypeScript
        ts = generate_typescript_module(emotion)
        with open(os.path.join(output_dir, f"{emotion}.tokens.ts"), "w") as f:
            f.write(ts)

        print(f"Generated: {emotion} (4 formats)")

    # インデックスファイル
    index_ts = "// NEURIA Emotion Design Tokens\n"
    index_ts += "// Auto-generated. Do not edit manually.\n\n"
    for e in emotions:
        index_ts += f"export {{ {e}Tokens }} from './{e}.tokens';\n"
    index_ts += "\nimport type { NeuriaTokens } from './trust.tokens';\n"
    index_ts += "export type { NeuriaTokens };\n\n"
    index_ts += f"export const emotions = {json.dumps(emotions)} as const;\n"
    index_ts += "export type Emotion = typeof emotions[number];\n"

    with open(os.path.join(output_dir, "index.ts"), "w") as f:
        f.write(index_ts)

    print(f"\nAll tokens generated in {output_dir}/")
    return output_dir


if __name__ == "__main__":
    build_all_tokens()
