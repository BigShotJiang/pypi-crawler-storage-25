"""
NEURIA MCP Server — Emotion Design Intelligence

10 tools for AI-assisted emotion-driven design:
  1. get_emotion_tokens      — CSS variables for 6 emotions
  2. search_similar_designs  — pgvector similarity search
  3. get_color_palette       — Emotion x industry palette + The Color API schemes
  4. get_typography          — Font / size / line-height sets
  5. score_html              — Score HTML via /api/score + accessibility audit
  6. generate_hero_image     — Generate hero background via 3D AI Studio
  7. analyze_reference_url   — Extract design properties & emotion from any URL (W3C DTCG)
  8. get_animation_tokens    — GSAP / CSS / Spring animation parameters per emotion
  9. analyze_visual_design   — ScreenshotOne + Imagga visual color analysis
 10. analyze_brand_voice     — Hume AI text emotion analysis → NEURIA mapping
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from pathlib import Path
from typing import Optional

import httpx
from dotenv import load_dotenv
from fastmcp import FastMCP

# Load .env from project root (two levels up from this file)
_project_root = Path(__file__).resolve().parent.parent.parent
load_dotenv(_project_root / ".env")

mcp = FastMCP("neuria")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
API_BASE = os.getenv("NEURIA_API_BASE", "http://localhost:8000")
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_KEY", "")
THREEDAI_BASE = "https://api.3daistudio.com"
THREEDAI_API_KEY = os.getenv("THREEDAI_API_KEY", "")
FIRECRAWL_API_KEY = os.getenv("FIRECRAWL_API_KEY", "")
SCREENSHOTONE_API_KEY = os.getenv("SCREENSHOTONE_API_KEY", "")
IMAGGA_API_KEY = os.getenv("IMAGGA_API_KEY", "")
IMAGGA_API_SECRET = os.getenv("IMAGGA_API_SECRET", "")
HUME_API_KEY = os.getenv("HUME_API_KEY", "")
WAVE_API_KEY = os.getenv("WAVE_API_KEY", "")

# Emotion → The Color API scheme type mapping
EMOTION_COLOR_SCHEMES = {
    "trust": "analogic",
    "excitement": "triad",
    "calm": "analogic",
    "luxury": "complement",
    "innovation": "triad",
    "energy": "complement",
}

# ---------------------------------------------------------------------------
# Embedded emotion data (from pipeline/api_server.py + lib/context.py)
# ---------------------------------------------------------------------------
EMOTION_TOKENS = {
    "trust": {
        "bg": "#0a1628", "bgCard": "#111f3a", "accent": "#3b82f6",
        "text": "#e2e8f0", "textMuted": "#94a3b8",
        "font": "Inter", "radius": 8, "lineHeight": 1.8,
    },
    "excitement": {
        "bg": "#0d0907", "bgCard": "#1f1008", "accent": "#ef4444",
        "text": "#fff1f0", "textMuted": "#fca5a5",
        "font": "Clash Display", "radius": 12, "lineHeight": 1.6,
    },
    "calm": {
        "bg": "#0a1a14", "bgCard": "#112b1e", "accent": "#10b981",
        "text": "#f0fdf4", "textMuted": "#6ee7b7",
        "font": "Inter", "radius": 16, "lineHeight": 1.9,
    },
    "luxury": {
        "bg": "#0c0a12", "bgCard": "#1a1520", "accent": "#d4a574",
        "text": "#faf5eb", "textMuted": "#c4a882",
        "font": "Playfair Display", "radius": 2, "lineHeight": 1.7,
    },
    "innovation": {
        "bg": "#0c0c1d", "bgCard": "#141430", "accent": "#7b61ff",
        "text": "#f5f3ff", "textMuted": "#a78bfa",
        "font": "Space Grotesk", "radius": 4, "lineHeight": 1.75,
    },
    "energy": {
        "bg": "#120d07", "bgCard": "#221508", "accent": "#f97316",
        "text": "#fff7ed", "textMuted": "#fb923c",
        "font": "Archivo Black", "radius": 999, "lineHeight": 1.5,
    },
}

TYPOGRAPHY = {
    "trust": {
        "font_families": ["Inter", "DM Sans", "Roboto"],
        "font_style": "clean_sans",
        "heading_weight": [500, 600], "body_weight": 400,
        "line_height": 1.8, "letter_spacing": "0em",
        "heading_scale": "clamp(2.5rem, 6vw, 4.5rem)",
    },
    "excitement": {
        "font_families": ["Clash Display", "Unbounded", "Montserrat"],
        "font_style": "bold_sans",
        "heading_weight": [700, 900], "body_weight": 400,
        "line_height": 1.6, "letter_spacing": "-0.02em",
        "heading_scale": "clamp(3rem, 10vw, 7rem)",
    },
    "calm": {
        "font_families": ["Inter", "Outfit", "Nunito"],
        "font_style": "light_sans",
        "heading_weight": [300, 500], "body_weight": 400,
        "line_height": 2.0, "letter_spacing": "0.02em",
        "heading_scale": "clamp(2rem, 5vw, 3.5rem)",
    },
    "luxury": {
        "font_families": ["Playfair Display", "Cormorant Garamond", "EB Garamond"],
        "font_style": "thin_serif",
        "heading_weight": [200, 400], "body_weight": 300,
        "line_height": 1.9, "letter_spacing": "0.08em",
        "heading_scale": "clamp(2.5rem, 7vw, 5rem)",
    },
    "innovation": {
        "font_families": ["Space Grotesk", "Syne", "JetBrains Mono"],
        "font_style": "geometric_sans",
        "heading_weight": [500, 700], "body_weight": 400,
        "line_height": 1.7, "letter_spacing": "-0.01em",
        "heading_scale": "clamp(2.5rem, 8vw, 5.5rem)",
    },
    "energy": {
        "font_families": ["Archivo Black", "Bebas Neue", "Oswald"],
        "font_style": "bold_display",
        "heading_weight": [800, 900], "body_weight": 500,
        "line_height": 1.5, "letter_spacing": "-0.03em",
        "heading_scale": "clamp(3rem, 12vw, 8rem)",
    },
}

EMOTION_VECTORS = {
    "trust":      [0.95, 0.10, 0.70, 0.30, 0.40, 0.20],
    "excitement": [0.10, 0.95, 0.05, 0.10, 0.50, 0.90],
    "calm":       [0.60, 0.05, 0.95, 0.40, 0.20, 0.10],
    "luxury":     [0.30, 0.10, 0.70, 0.95, 0.40, 0.15],
    "innovation": [0.40, 0.50, 0.20, 0.30, 0.95, 0.60],
    "energy":     [0.20, 0.80, 0.05, 0.10, 0.50, 0.95],
}

INDUSTRY_PALETTE_SHIFTS = {
    "fintech":    {"accent_shift": 0,   "saturation_mod": -5},
    "healthcare": {"accent_shift": 10,  "saturation_mod": -10},
    "ecommerce":  {"accent_shift": -10, "saturation_mod": 5},
    "education":  {"accent_shift": 15,  "saturation_mod": -5},
    "saas":       {"accent_shift": 0,   "saturation_mod": 0},
    "media":      {"accent_shift": -15, "saturation_mod": 10},
    "gaming":     {"accent_shift": -20, "saturation_mod": 15},
}

VALID_EMOTIONS = list(EMOTION_TOKENS.keys())


def _validate_emotion(emotion: str) -> str | None:
    if emotion not in VALID_EMOTIONS:
        return f"Unknown emotion '{emotion}'. Available: {VALID_EMOTIONS}"
    return None


def _hex_to_rgb(h: str) -> tuple[int, int, int]:
    h = h.strip().lstrip("#")
    if len(h) < 6:
        # Handle short hex (#abc → aabbcc) or invalid input
        if len(h) == 3:
            h = h[0] * 2 + h[1] * 2 + h[2] * 2
        else:
            h = "333333"  # safe fallback for malformed hex
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _rgb_to_hex(r: int, g: int, b: int) -> str:
    return f"#{max(0,min(255,r)):02x}{max(0,min(255,g)):02x}{max(0,min(255,b)):02x}"


def _build_font_css(tokens: dict, typo: dict, spec: dict) -> str:
    fallbacks = ", ".join(f"'{f}'" for f in typo["font_families"][1:])
    lines = [
        f"font-family: '{tokens['font']}', {fallbacks}, sans-serif;",
        f"font-size: {spec['size']};",
        f"font-weight: {spec['weight']};",
        f"line-height: {typo['line_height']};",
        f"letter-spacing: {typo['letter_spacing']};",
    ]
    return "\n".join(lines)


def _shift_color(hex_color: str, hue_shift: int, sat_mod: int) -> str:
    """Simple hue/saturation shift via RGB manipulation."""
    r, g, b = _hex_to_rgb(hex_color)
    # Approximate shift by rotating channel weights
    if hue_shift > 0:
        r = int(r * 0.95 + hue_shift * 0.3)
        b = int(b * 1.05)
    elif hue_shift < 0:
        r = int(r * 1.05)
        b = int(b * 0.95 + abs(hue_shift) * 0.3)
    # Saturation modification
    avg = (r + g + b) // 3
    factor = 1 + sat_mod / 100
    r = int(avg + (r - avg) * factor)
    g = int(avg + (g - avg) * factor)
    b = int(avg + (b - avg) * factor)
    return _rgb_to_hex(r, g, b)


# ---------------------------------------------------------------------------
# Shared helpers: Firecrawl & The Color API
# ---------------------------------------------------------------------------
_FIRECRAWL_EXTRACT_SCHEMA = {
    "type": "object",
    "properties": {
        "primary_color":        {"type": "string", "description": "Primary brand color in hex format (e.g. #3b82f6)"},
        "secondary_color":      {"type": "string", "description": "Secondary color in hex format"},
        "accent_color":         {"type": "string", "description": "Accent/CTA color in hex format"},
        "background_color":     {"type": "string", "description": "Main background color in hex format"},
        "font_family_heading":  {"type": "string", "description": "Heading font family name"},
        "font_family_body":     {"type": "string", "description": "Body text font family name"},
        "border_radius_style":  {"type": "string", "enum": ["sharp", "medium", "rounded"], "description": "Overall border radius style"},
        "spacing_density":      {"type": "string", "enum": ["compact", "balanced", "spacious"], "description": "Layout spacing density"},
        "overall_tone":         {"type": "string", "enum": ["dark", "light", "neutral"], "description": "Overall visual tone"},
    },
    "required": [
        "primary_color", "secondary_color", "accent_color",
        "background_color", "font_family_heading", "font_family_body",
        "border_radius_style", "spacing_density", "overall_tone",
    ],
}


async def _firecrawl_extract(url: str) -> dict:
    """Call Firecrawl extract API and return the extracted design properties dict.

    Raises ``RuntimeError`` with a user-friendly message on failure.
    """
    if not FIRECRAWL_API_KEY:
        raise RuntimeError("FIRECRAWL_API_KEY not configured. Add FIRECRAWL_API_KEY=fc-... to your .env file")

    headers = {
        "Authorization": f"Bearer {FIRECRAWL_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "url": url,
        "formats": ["extract"],
        "extract": {"schema": _FIRECRAWL_EXTRACT_SCHEMA},
    }

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            "https://api.firecrawl.dev/v1/scrape",
            headers=headers,
            json=payload,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"Firecrawl API returned {resp.status_code}: {resp.text[:500]}")

        data = resp.json()
        extracted = data.get("data", {}).get("extract", {})
        if not extracted:
            raise RuntimeError(f"Firecrawl returned no extracted data: {json.dumps(data)[:500]}")
        return extracted


async def _firecrawl_markdown(url: str) -> str:
    """Call Firecrawl scrape API and return the page content as markdown.

    Raises ``RuntimeError`` with a user-friendly message on failure.
    """
    if not FIRECRAWL_API_KEY:
        raise RuntimeError("FIRECRAWL_API_KEY not configured. Add FIRECRAWL_API_KEY=fc-... to your .env file")

    headers = {
        "Authorization": f"Bearer {FIRECRAWL_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "url": url,
        "formats": ["markdown"],
    }

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            "https://api.firecrawl.dev/v1/scrape",
            headers=headers,
            json=payload,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"Firecrawl API returned {resp.status_code}: {resp.text[:500]}")

        data = resp.json()
        markdown = data.get("data", {}).get("markdown", "")
        if not markdown:
            raise RuntimeError("Firecrawl returned no markdown content")
        return markdown


async def _color_api_scheme(hex_color: str, scheme_mode: str, count: int = 5) -> list[str]:
    """Fetch a color scheme from The Color API. Returns list of hex strings.

    Falls back to an empty list on any error.
    """
    hex_clean = hex_color.lstrip("#")
    url = (
        f"https://www.thecolorapi.com/scheme"
        f"?hex={hex_clean}&mode={scheme_mode}&count={count}"
    )
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(url)
            if resp.status_code != 200:
                return []
            data = resp.json()
            return [c["hex"]["value"] for c in data.get("colors", [])]
    except Exception:
        return []


def _contrast_ratio(hex1: str, hex2: str) -> float:
    """Calculate WCAG contrast ratio between two hex colors."""
    def _relative_luminance(hex_color: str) -> float:
        r, g, b = _hex_to_rgb(hex_color)
        rs, gs, bs = r / 255, g / 255, b / 255
        r_lin = rs / 12.92 if rs <= 0.04045 else ((rs + 0.055) / 1.055) ** 2.4
        g_lin = gs / 12.92 if gs <= 0.04045 else ((gs + 0.055) / 1.055) ** 2.4
        b_lin = bs / 12.92 if bs <= 0.04045 else ((bs + 0.055) / 1.055) ** 2.4
        return 0.2126 * r_lin + 0.7152 * g_lin + 0.0722 * b_lin

    l1 = _relative_luminance(hex1)
    l2 = _relative_luminance(hex2)
    lighter = max(l1, l2)
    darker = min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)


# ---------------------------------------------------------------------------
# Tool 1: get_emotion_tokens
# ---------------------------------------------------------------------------
@mcp.tool()
async def get_emotion_tokens(
    emotion: str,
    category: str = "all",
) -> str:
    """Get NEURIA emotion design tokens as CSS variables.

    Args:
        emotion: One of trust, excitement, calm, luxury, innovation, energy.
        category: Filter category — "all", "color", "typography", "spacing".

    Returns:
        CSS custom properties (:root block) for the requested emotion.
    """
    err = _validate_emotion(emotion)
    if err:
        return err

    tokens = EMOTION_TOKENS[emotion]
    typo = TYPOGRAPHY[emotion]

    lines = [f"/* NEURIA Design Tokens — {emotion} */", ":root {"]

    if category in ("all", "color"):
        lines += [
            f"  --neuria-bg: {tokens['bg']};",
            f"  --neuria-bg-card: {tokens['bgCard']};",
            f"  --neuria-accent: {tokens['accent']};",
            f"  --neuria-text: {tokens['text']};",
            f"  --neuria-text-muted: {tokens['textMuted']};",
        ]

    if category in ("all", "typography"):
        lines += [
            f"  --neuria-font: '{tokens['font']}', sans-serif;",
            f"  --neuria-line-height: {tokens['lineHeight']};",
            f"  --neuria-letter-spacing: {typo['letter_spacing']};",
            f"  --neuria-heading-scale: {typo['heading_scale']};",
            f"  --neuria-heading-weight: {typo['heading_weight'][1]};",
            f"  --neuria-body-weight: {typo['body_weight']};",
        ]

    if category in ("all", "spacing"):
        lines += [
            f"  --neuria-radius: {tokens['radius']}px;",
        ]

    lines.append("}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool 2: search_similar_designs
# ---------------------------------------------------------------------------
@mcp.tool()
async def search_similar_designs(
    query: str,
    mood: Optional[str] = None,
    component_type: Optional[str] = None,
    limit: int = 5,
) -> str:
    """Search similar designs via Supabase pgvector cosine similarity.

    Args:
        query: Search query describing the desired design.
        mood: Optional emotion filter (trust, excitement, calm, luxury, innovation, energy).
        component_type: Optional component type filter (hero, card, cta, nav, footer).
        limit: Max results (default 5).

    Returns:
        JSON array of similar designs with scores and parameters.
    """
    if not SUPABASE_URL or not SUPABASE_KEY:
        # Fallback: use emotion vector similarity from local data
        target_emotion = mood or "trust"
        err = _validate_emotion(target_emotion)
        if err:
            return err

        target_vec = EMOTION_VECTORS[target_emotion]
        results = []
        for emo, vec in EMOTION_VECTORS.items():
            if emo == target_emotion:
                continue
            dot = sum(a * b for a, b in zip(target_vec, vec))
            mag_a = sum(a * a for a in target_vec) ** 0.5
            mag_b = sum(b * b for b in vec) ** 0.5
            similarity = dot / (mag_a * mag_b) if mag_a and mag_b else 0
            results.append({
                "emotion": emo,
                "similarity": round(similarity, 4),
                "tokens": EMOTION_TOKENS[emo],
            })
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return json.dumps({
            "query": query,
            "target_emotion": target_emotion,
            "source": "local_fallback",
            "results": results[:limit],
        }, ensure_ascii=False, indent=2)

    # Supabase pgvector search
    emotion_vector = EMOTION_VECTORS.get(mood, [0.5, 0.5, 0.5, 0.5, 0.5, 0.5])
    rpc_payload = {
        "query_vector": emotion_vector,
        "match_count": limit,
    }

    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(
            f"{SUPABASE_URL}/rest/v1/rpc/match_designs_by_emotion",
            json=rpc_payload,
            headers=headers,
        )
        if resp.status_code != 200:
            return json.dumps({
                "error": f"Supabase returned {resp.status_code}",
                "detail": resp.text,
            })

        rows = resp.json()
        results = []
        for row in rows:
            item = {
                "id": row.get("id"),
                "industry": row.get("industry"),
                "emotion_target": row.get("emotion_target"),
                "total_score": row.get("total_score"),
                "similarity": row.get("similarity"),
                "parameters": row.get("parameters"),
            }
            if component_type:
                params = row.get("parameters", {})
                if params.get("component_type") != component_type:
                    continue
            results.append(item)

        return json.dumps({
            "query": query,
            "mood": mood,
            "source": "supabase_pgvector",
            "results": results[:limit],
        }, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Tool 3: get_color_palette
# ---------------------------------------------------------------------------
@mcp.tool()
async def get_color_palette(
    emotion: str,
    industry: Optional[str] = None,
) -> str:
    """Get a 5-color palette for an emotion, optionally adjusted by industry.

    Args:
        emotion: One of trust, excitement, calm, luxury, innovation, energy.
        industry: Optional industry for palette adjustment (fintech, healthcare, ecommerce, education, saas, media, gaming).

    Returns:
        JSON with 5 named colors: background, surface, accent, text_primary, text_secondary.
    """
    err = _validate_emotion(emotion)
    if err:
        return err

    tokens = EMOTION_TOKENS[emotion]
    palette = {
        "background":     tokens["bg"],
        "surface":        tokens["bgCard"],
        "accent":         tokens["accent"],
        "text_primary":   tokens["text"],
        "text_secondary": tokens["textMuted"],
    }

    if industry and industry in INDUSTRY_PALETTE_SHIFTS:
        shift = INDUSTRY_PALETTE_SHIFTS[industry]
        palette["accent"] = _shift_color(
            palette["accent"],
            shift["accent_shift"],
            shift["saturation_mod"],
        )

    # Fetch extended color scheme from The Color API
    scheme_mode = EMOTION_COLOR_SCHEMES.get(emotion, "analogic")
    api_colors = await _color_api_scheme(palette["accent"], scheme_mode, count=5)

    result: dict = {
        "emotion": emotion,
        "industry": industry,
        "palette": palette,
        "css_snippet": "\n".join([
            f"--color-bg: {palette['background']};",
            f"--color-surface: {palette['surface']};",
            f"--color-accent: {palette['accent']};",
            f"--color-text: {palette['text_primary']};",
            f"--color-text-muted: {palette['text_secondary']};",
        ]),
        "emotion_vector": EMOTION_VECTORS[emotion],
    }

    if api_colors:
        result["color_scheme"] = {
            "mode": scheme_mode,
            "source": "thecolorapi.com",
            "colors": api_colors,
            "css_snippet": "\n".join(
                f"--scheme-{i}: {c};" for i, c in enumerate(api_colors)
            ),
        }

    return json.dumps(result, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Tool 4: get_typography
# ---------------------------------------------------------------------------
@mcp.tool()
async def get_typography(
    emotion: str,
    use_case: str = "body",
) -> str:
    """Get typography settings for an emotion and use case.

    Args:
        emotion: One of trust, excitement, calm, luxury, innovation, energy.
        use_case: Typography context — "heading", "body", "caption", "cta".

    Returns:
        JSON with font-family, font-size, font-weight, line-height, letter-spacing.
    """
    err = _validate_emotion(emotion)
    if err:
        return err

    typo = TYPOGRAPHY[emotion]
    tokens = EMOTION_TOKENS[emotion]

    size_map = {
        "heading": {"size": typo["heading_scale"], "weight": typo["heading_weight"][1]},
        "body":    {"size": "1rem",                 "weight": typo["body_weight"]},
        "caption": {"size": "0.875rem",             "weight": typo["body_weight"]},
        "cta":     {"size": "1.125rem",             "weight": typo["heading_weight"][0]},
    }

    if use_case not in size_map:
        return f"Unknown use_case '{use_case}'. Available: {list(size_map.keys())}"

    spec = size_map[use_case]
    result = {
        "emotion": emotion,
        "use_case": use_case,
        "font_family": typo["font_families"],
        "font_style": typo["font_style"],
        "font_size": spec["size"],
        "font_weight": spec["weight"],
        "line_height": typo["line_height"],
        "letter_spacing": typo["letter_spacing"],
        "css_snippet": _build_font_css(tokens, typo, spec),
    }
    return json.dumps(result, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Tool 5: score_html
# ---------------------------------------------------------------------------
def _check_accessibility(html: str) -> dict:
    """Run local accessibility checks on raw HTML and return audit results."""
    issues: list[str] = []
    warnings: list[str] = []
    score = 100  # start perfect, deduct

    html_lower = html.lower()

    # 1. lang attribute on <html>
    if "<html" in html_lower and 'lang=' not in html_lower.split("</head")[0]:
        issues.append("Missing lang attribute on <html> element")
        score -= 10

    # 2. img alt attributes
    img_tags = re.findall(r'<img\b[^>]*>', html, re.IGNORECASE)
    imgs_missing_alt = [t for t in img_tags if 'alt=' not in t.lower()]
    if imgs_missing_alt:
        issues.append(f"{len(imgs_missing_alt)} <img> tag(s) missing alt attribute")
        score -= min(20, len(imgs_missing_alt) * 5)

    # 3. Heading hierarchy — check h1 exists
    if '<h1' not in html_lower:
        warnings.append("No <h1> element found — recommend adding a main heading")
        score -= 5

    # Check heading order (no skipping levels)
    heading_levels = [int(m) for m in re.findall(r'<h([1-6])\b', html_lower)]
    for i in range(1, len(heading_levels)):
        if heading_levels[i] > heading_levels[i - 1] + 1:
            warnings.append(f"Heading level skipped: h{heading_levels[i-1]} → h{heading_levels[i]}")
            score -= 3
            break

    # 4. Form labels — inputs should have associated labels or aria-label
    inputs = re.findall(r'<input\b[^>]*>', html, re.IGNORECASE)
    for inp in inputs:
        inp_lower = inp.lower()
        if 'type="hidden"' in inp_lower or 'type="submit"' in inp_lower:
            continue
        if 'aria-label' not in inp_lower and 'id=' not in inp_lower:
            warnings.append("Form input without aria-label or associated label")
            score -= 3
            break

    # 5. Interactive elements — buttons/links should have accessible text
    empty_buttons = re.findall(r'<button[^>]*>\s*</button>', html, re.IGNORECASE)
    if empty_buttons:
        issues.append(f"{len(empty_buttons)} empty <button> element(s) — add text or aria-label")
        score -= 5

    # 6. Color contrast — check inline style pairs if present
    # Extract pairs of NEURIA CSS vars for known text/bg combos
    contrast_warnings = []
    for emo, tokens in EMOTION_TOKENS.items():
        if tokens["bg"] in html and tokens["text"] in html:
            ratio = _contrast_ratio(tokens["bg"], tokens["text"])
            if ratio < 4.5:
                contrast_warnings.append(
                    f"{emo} bg/text contrast {ratio:.1f}:1 < 4.5:1 (WCAG AA)"
                )
    if contrast_warnings:
        warnings.extend(contrast_warnings)
        score -= len(contrast_warnings) * 5

    # 7. Viewport meta tag (mobile-first)
    if 'viewport' not in html_lower:
        warnings.append("Missing <meta name=\"viewport\"> — required for mobile responsiveness")
        score -= 5

    score = max(0, min(100, score))
    return {
        "accessibility_score": score,
        "issues": issues,
        "warnings": warnings,
        "checks_run": [
            "lang_attribute", "img_alt", "heading_hierarchy",
            "form_labels", "empty_buttons", "color_contrast", "viewport_meta",
        ],
    }


@mcp.tool()
async def score_html(
    html_content: str,
    target_emotion: Optional[str] = None,
    url: Optional[str] = None,
) -> str:
    """Score HTML against NEURIA emotion design standards via /api/score.

    Args:
        html_content: The HTML string to evaluate.
        target_emotion: Optional target emotion for scoring context.
        url: Optional public URL for WAVE API accessibility check (requires WAVE_API_KEY).

    Returns:
        JSON with aesthetic_score, technical_score, emotion_score, composite_score,
        deductions list, and improvement suggestions.
    """
    payload: dict = {"html": html_content}

    api_keys = {}
    anthropic_key = os.getenv("ANTHROPIC_API_KEY", "")
    openrouter_key = os.getenv("OPENROUTER_API_KEY", "")
    if anthropic_key:
        api_keys["anthropic"] = anthropic_key
    if openrouter_key:
        api_keys["openrouter"] = openrouter_key
    payload["api_keys"] = api_keys

    if target_emotion:
        payload["params"] = {"mood": target_emotion}

    # Run local accessibility check in parallel with API call
    a11y = _check_accessibility(html_content)

    # Optional: WAVE API if key and URL are provided
    wave_result = None
    if WAVE_API_KEY and url:
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                wave_resp = await client.get(
                    "https://wave.webaim.org/api/request",
                    params={"key": WAVE_API_KEY, "url": url, "reporttype": "2"},
                )
                if wave_resp.status_code == 200:
                    wave_result = wave_resp.json()
        except Exception:
            pass  # WAVE is supplementary, don't fail

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(f"{API_BASE}/api/score", json=payload)

            if resp.status_code != 200:
                return json.dumps({
                    "error": f"Score API returned {resp.status_code}",
                    "detail": resp.text[:500],
                })

            data = resp.json()

            # Reweight scores: aesthetic(35%) + technical(15%) + emotion(35%) + accessibility(15%)
            aesthetic = data.get("aesthetic_score") or 0
            technical = data.get("technical_score") or 0
            emotion = data.get("emotion_score") or 0
            accessibility = a11y["accessibility_score"]

            composite = round(
                aesthetic * 0.35
                + technical * 0.15
                + emotion * 0.35
                + accessibility * 0.15,
                1,
            )

            result: dict = {
                "composite_score": composite,
                "aesthetic_score": aesthetic,
                "technical_score": technical,
                "emotion_score": emotion,
                "accessibility_score": accessibility,
                "accessibility_issues": a11y["issues"],
                "accessibility_warnings": a11y["warnings"],
                "deductions": data.get("deductions", []),
                "suggestions": data.get("suggestions", []),
                "target_emotion": target_emotion,
                "pass": composite >= 85,
                "score_weights": "aesthetic(35%) + technical(15%) + emotion(35%) + accessibility(15%)",
            }

            if wave_result:
                categories = wave_result.get("categories", {})
                result["wave_summary"] = {
                    "errors": categories.get("error", {}).get("count", 0),
                    "alerts": categories.get("alert", {}).get("count", 0),
                    "features": categories.get("feature", {}).get("count", 0),
                    "structural": categories.get("structure", {}).get("count", 0),
                    "aria": categories.get("aria", {}).get("count", 0),
                }

            return json.dumps(result, ensure_ascii=False, indent=2)

    except httpx.ConnectError:
        # Even if API is down, return accessibility results
        return json.dumps({
            "error": "Cannot connect to NEURIA API",
            "detail": f"Ensure the API server is running at {API_BASE}",
            "hint": "Run: cd pipeline && python api_server.py",
            "accessibility_score": a11y["accessibility_score"],
            "accessibility_issues": a11y["issues"],
            "accessibility_warnings": a11y["warnings"],
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


# ---------------------------------------------------------------------------
# Tool 6: generate_hero_image
# ---------------------------------------------------------------------------
EMOTION_VISUAL_PROMPTS = {
    "trust":      "corporate blue digital network, clean minimal, professional",
    "excitement": "dynamic red energy burst, bold striking, high contrast",
    "calm":       "serene green nature abstract, soft peaceful, breathing",
    "luxury":     "gold black premium texture, exclusive elegant, dark glamour",
    "innovation": "purple futuristic geometry, tech abstract, neon grid",
    "energy":     "orange power explosion, vibrant motion blur, intense",
}


@mcp.tool()
async def generate_hero_image(
    prompt: str,
    emotion: str = "trust",
    style: str = "3d",
) -> str:
    """Generate an emotion-matched hero image / background via 3D AI Studio.

    Use the returned image URL as the hero section background in HTML generation.

    Args:
        prompt: Subject description (e.g. "cybersecurity enterprise SaaS platform").
        emotion: One of trust, excitement, calm, luxury, innovation, energy.
        style: Visual style hint (e.g. "3d", "photorealistic", "abstract").

    Returns:
        JSON with image_url, prompt_used, emotion, and style.
    """
    api_key = THREEDAI_API_KEY
    if not api_key:
        return json.dumps({
            "error": "THREEDAI_API_KEY not configured",
            "hint": "Set THREEDAI_API_KEY in your .env file",
        })

    err = _validate_emotion(emotion)
    if err:
        return err

    emotion_hint = EMOTION_VISUAL_PROMPTS.get(emotion, "")
    full_prompt = (
        f"{prompt}, {emotion_hint}, {style} aesthetic, "
        "hero background, wide cinematic, no text, no watermark, no UI elements"
    )

    headers = {"Authorization": f"Bearer {api_key}"}

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            # Step 1: Submit generation request
            resp = await client.post(
                f"{THREEDAI_BASE}/v1/images/gemini/3.1/flash/generate/",
                headers=headers,
                json={
                    "prompt": full_prompt,
                    "output_format": "png",
                    "aspect_ratio": "16:9",
                    "resolution": "1K",
                    "num_images": 1,
                },
            )

            if resp.status_code != 200:
                return json.dumps({
                    "error": f"3D AI Studio API returned {resp.status_code}",
                    "detail": resp.text[:500],
                })

            task_id = resp.json().get("task_id")
            if not task_id:
                return json.dumps({
                    "error": "No task_id returned from API",
                    "response": resp.text[:500],
                })

        # Step 2: Poll for completion (max 90 seconds)
        async with httpx.AsyncClient(timeout=15) as client:
            for _ in range(18):
                await asyncio.sleep(5)
                poll = await client.get(
                    f"{THREEDAI_BASE}/v1/generation-request/{task_id}/status/",
                    headers=headers,
                )
                data = poll.json()
                status = data.get("status", "UNKNOWN")

                if status == "FINISHED":
                    results = data.get("results", [])
                    if results:
                        image_url = results[0].get("asset")
                        return json.dumps({
                            "image_url": image_url,
                            "prompt_used": full_prompt,
                            "emotion": emotion,
                            "style": style,
                        }, ensure_ascii=False, indent=2)
                    return json.dumps({"error": "No results in finished task"})

                if status == "FAILED":
                    return json.dumps({
                        "error": "Image generation failed",
                        "reason": data.get("failure_reason", "unknown"),
                    })

        return json.dumps({"error": "Timeout after 90 seconds"})

    except Exception as e:
        return json.dumps({"error": str(e)})


# ---------------------------------------------------------------------------
# Tool 7: analyze_reference_url
# ---------------------------------------------------------------------------
# Known sites that match specific emotions (for similar_references)
EMOTION_REFERENCE_SITES = {
    "trust": ["Stripe", "Linear", "Notion", "IBM", "Salesforce"],
    "excitement": ["Nike", "Red Bull", "Spotify", "Discord", "Figma"],
    "calm": ["Headspace", "Muji", "Aesop", "Kinfolk", "Medium"],
    "luxury": ["Bottega Veneta", "NET-A-PORTER", "Rolex", "Chanel", "Hermès"],
    "innovation": ["OpenAI", "Vercel", "GitHub", "Tesla", "Neuralink"],
    "energy": ["Monster Energy", "Gatorade", "GoPro", "CrossFit", "Redbull"],
}


def _hex_brightness(hex_color: str) -> int:
    """Return perceived brightness (0-255) of a hex color."""
    r, g, b = _hex_to_rgb(hex_color)
    return int(0.299 * r + 0.587 * g + 0.114 * b)


def _hex_to_hsl(hex_color: str) -> tuple[float, float, float]:
    """Convert hex to HSL (hue 0-360, sat 0-100, light 0-100)."""
    r, g, b = _hex_to_rgb(hex_color)
    r, g, b = r / 255, g / 255, b / 255
    mx, mn = max(r, g, b), min(r, g, b)
    l = (mx + mn) / 2

    if mx == mn:
        h = s = 0.0
    else:
        d = mx - mn
        s = d / (2 - mx - mn) if l > 0.5 else d / (mx + mn)
        if mx == r:
            h = (g - b) / d + (6 if g < b else 0)
        elif mx == g:
            h = (b - r) / d + 2
        else:
            h = (r - g) / d + 4
        h /= 6

    return h * 360, s * 100, l * 100


def _compute_emotion_scores(
    primary_color: str,
    secondary_color: str,
    accent_color: str,
    background_color: str,
    border_radius_style: str,
    spacing_density: str,
    overall_tone: str,
) -> dict[str, int]:
    """Compute emotion scores (0-100) from extracted design properties."""
    scores = {
        "trust": 40, "excitement": 25, "calm": 30,
        "luxury": 25, "innovation": 30, "energy": 25,
    }

    # --- Background darkness ---
    bg_brightness = _hex_brightness(background_color)
    if bg_brightness < 51:  # < #333333
        scores["luxury"] += 20
        scores["trust"] += 10
        scores["innovation"] += 10
    elif bg_brightness > 200:
        scores["calm"] += 10
        scores["trust"] += 5

    # --- Overall tone ---
    if overall_tone == "dark":
        scores["luxury"] += 10
        scores["innovation"] += 8
    elif overall_tone == "light":
        scores["calm"] += 10
        scores["trust"] += 5

    # --- Analyze hues of primary and accent colors ---
    for color in [primary_color, accent_color]:
        if not color or color == "N/A":
            continue
        try:
            hue, sat, _ = _hex_to_hsl(color)
        except (ValueError, IndexError):
            continue

        # Warm hues (red/orange: 0-60, 330-360)
        if hue < 60 or hue > 330:
            scores["excitement"] += 12
            scores["energy"] += 12
        # Cool hues (blue: 200-260)
        elif 200 <= hue <= 260:
            scores["trust"] += 12
            scores["innovation"] += 8
        # Purple (260-330)
        elif 260 < hue <= 330:
            scores["innovation"] += 12
            scores["luxury"] += 8
        # Green (90-170)
        elif 90 <= hue <= 170:
            scores["calm"] += 12
            scores["trust"] += 5
        # Yellow/gold (40-65)
        elif 40 <= hue <= 65:
            scores["luxury"] += 10
            scores["energy"] += 8

        # Low saturation → luxury/calm
        if sat < 20:
            scores["luxury"] += 5
            scores["calm"] += 5

    # --- Border radius ---
    if border_radius_style == "rounded":
        scores["calm"] += 10
        scores["excitement"] += 5
    elif border_radius_style == "sharp":
        scores["luxury"] += 10
        scores["innovation"] += 8
    elif border_radius_style == "medium":
        scores["trust"] += 5

    # --- Spacing density ---
    if spacing_density == "spacious":
        scores["calm"] += 10
        scores["luxury"] += 10
    elif spacing_density == "compact":
        scores["energy"] += 10
        scores["innovation"] += 8
    elif spacing_density == "balanced":
        scores["trust"] += 5

    # Clamp to 0-100
    for k in scores:
        scores[k] = max(0, min(100, scores[k]))

    return scores


@mcp.tool()
async def analyze_reference_url(url: str) -> str:
    """Analyze a reference URL to extract design properties and determine dominant emotion.

    Uses Firecrawl API to scrape the URL and extract colors, typography, spacing,
    and other design attributes. Enhances analysis with The Color API for hue-family
    scoring. Returns W3C DTCG format design tokens.

    Args:
        url: The URL to analyze (e.g. "https://linear.app").

    Returns:
        JSON with dominant_emotion, emotion_scores, design_tokens (W3C DTCG JSON),
        rationale, and similar_references.
    """
    try:
        extracted = await _firecrawl_extract(url)
    except RuntimeError as e:
        return json.dumps({"error": str(e)})
    except httpx.ConnectError:
        return json.dumps({
            "error": "Cannot connect to Firecrawl API",
            "hint": "Check network connectivity and FIRECRAWL_API_KEY",
        })
    except Exception as e:
        return json.dumps({"error": str(e)})

    try:
        # Step 2: Compute emotion scores
        primary   = extracted.get("primary_color", "#333333")
        secondary = extracted.get("secondary_color", "#666666")
        accent    = extracted.get("accent_color", "#3b82f6")
        bg        = extracted.get("background_color", "#ffffff")
        radius    = extracted.get("border_radius_style", "medium")
        spacing   = extracted.get("spacing_density", "balanced")
        tone      = extracted.get("overall_tone", "neutral")

        scores = _compute_emotion_scores(
            primary_color=primary,
            secondary_color=secondary,
            accent_color=accent,
            background_color=bg,
            border_radius_style=radius,
            spacing_density=spacing,
            overall_tone=tone,
        )

        # Step 2b: Enhance scores with The Color API analogic palette hue analysis
        analogic_colors = await _color_api_scheme(primary, "analogic", count=5)
        if analogic_colors:
            for ac in analogic_colors:
                try:
                    hue, sat, _ = _hex_to_hsl(ac)
                    if hue < 60 or hue > 330:
                        scores["excitement"] += 2
                        scores["energy"] += 2
                    elif 200 <= hue <= 260:
                        scores["trust"] += 2
                        scores["innovation"] += 1
                    elif 260 < hue <= 330:
                        scores["innovation"] += 2
                        scores["luxury"] += 1
                    elif 90 <= hue <= 170:
                        scores["calm"] += 2
                        scores["trust"] += 1
                except (ValueError, IndexError):
                    pass
            # Re-clamp
            for k in scores:
                scores[k] = max(0, min(100, scores[k]))

        # Step 3: Determine dominant emotion
        dominant = max(scores, key=scores.get)

        # Step 4: Build W3C DTCG format design tokens
        tokens = EMOTION_TOKENS[dominant]
        typo = TYPOGRAPHY[dominant]

        design_tokens_dtcg = {
            "neuria": {
                "$description": f"NEURIA tokens matched to {url} — {dominant}",
                "color": {
                    "bg":        {"$type": "color", "$value": tokens["bg"]},
                    "bg-card":   {"$type": "color", "$value": tokens["bgCard"]},
                    "accent":    {"$type": "color", "$value": tokens["accent"]},
                    "text":      {"$type": "color", "$value": tokens["text"]},
                    "text-muted": {"$type": "color", "$value": tokens["textMuted"]},
                },
                "typography": {
                    "font-family": {"$type": "fontFamily", "$value": [tokens["font"], "sans-serif"]},
                    "line-height": {"$type": "number", "$value": tokens["lineHeight"]},
                    "heading-weight": {"$type": "number", "$value": typo["heading_weight"][1]},
                    "body-weight": {"$type": "number", "$value": typo["body_weight"]},
                    "letter-spacing": {"$type": "dimension", "$value": typo["letter_spacing"]},
                },
                "spacing": {
                    "radius": {"$type": "dimension", "$value": f"{tokens['radius']}px"},
                },
                "source": {
                    "primary":    {"$type": "color", "$value": primary},
                    "secondary":  {"$type": "color", "$value": secondary},
                    "accent":     {"$type": "color", "$value": accent},
                    "background": {"$type": "color", "$value": bg},
                },
            },
        }

        # Step 5: Build rationale
        rationale_parts = []
        bg_brightness = _hex_brightness(bg)
        if bg_brightness < 51:
            rationale_parts.append("ダークな背景色")
        elif bg_brightness > 200:
            rationale_parts.append("明るい背景色")

        if tone == "dark":
            rationale_parts.append("全体的にダークトーン")
        elif tone == "light":
            rationale_parts.append("全体的にライトトーン")

        for label, color in [("プライマリ", primary), ("アクセント", accent)]:
            try:
                hue, _, _ = _hex_to_hsl(color)
                if hue < 60 or hue > 330:
                    rationale_parts.append(f"{label}色が暖色系")
                elif 200 <= hue <= 260:
                    rationale_parts.append(f"{label}色が寒色系（ブルー）")
                elif 260 < hue <= 330:
                    rationale_parts.append(f"{label}色がパープル系")
                elif 90 <= hue <= 170:
                    rationale_parts.append(f"{label}色がグリーン系")
            except (ValueError, IndexError):
                pass

        if radius == "rounded":
            rationale_parts.append("丸みのあるボーダー")
        elif radius == "sharp":
            rationale_parts.append("シャープなボーダー")

        if spacing == "spacious":
            rationale_parts.append("広めのスペーシング")
        elif spacing == "compact":
            rationale_parts.append("コンパクトなレイアウト")

        if analogic_colors:
            rationale_parts.append("The Color APIの類似色分析を加味")

        features_str = "、".join(rationale_parts) if rationale_parts else "総合的な分析"
        rationale = f"このサイトは{features_str}の特徴から {dominant} と判定されました"

        # Similar reference sites
        similar = EMOTION_REFERENCE_SITES.get(dominant, [])[:3]

        result = {
            "url": url,
            "extracted": {
                "primary_color": primary,
                "secondary_color": secondary,
                "accent_color": accent,
                "background_color": bg,
                "font_family_heading": extracted.get("font_family_heading", "N/A"),
                "font_family_body": extracted.get("font_family_body", "N/A"),
                "border_radius_style": radius,
                "spacing_density": spacing,
                "overall_tone": tone,
            },
            "dominant_emotion": dominant,
            "emotion_scores": scores,
            "design_tokens": design_tokens_dtcg,
            "rationale": rationale,
            "similar_references": similar,
        }

        if analogic_colors:
            result["color_api_palette"] = analogic_colors

        return json.dumps(result, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({"error": str(e)})


# ---------------------------------------------------------------------------
# Tool 8: get_animation_tokens
# ---------------------------------------------------------------------------
ANIMATION_DATA = {
    "trust": {
        "page_load": {
            "gsap": {"ease": "power2.out", "duration": 0.8, "stagger": 0.12, "scrollTrigger": {"start": "top 80%", "toggleActions": "play none none none"}},
            "css": {"transition": "all 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94)", "timing_function": "cubic-bezier(0.25, 0.46, 0.45, 0.94)"},
            "spring": {"response": 0.6, "dampingFraction": 0.82, "bounce": 0.1},
            "rationale": "信頼感を生む滑らかで予測可能なイージング。急なモーションを避け、安定感を演出",
        },
        "scroll_reveal": {
            "gsap": {"ease": "power1.out", "duration": 0.7, "stagger": 0.1, "scrollTrigger": {"start": "top 85%", "toggleActions": "play none none reverse"}},
            "css": {"transition": "opacity 0.7s ease-out, transform 0.7s ease-out", "timing_function": "ease-out"},
            "spring": {"response": 0.5, "dampingFraction": 0.85, "bounce": 0.05},
            "rationale": "控えめなフェードイン。ユーザーの注意を自然に誘導",
        },
        "hover": {
            "gsap": {"ease": "power1.inOut", "duration": 0.3},
            "css": {"transition": "all 0.3s ease-in-out", "timing_function": "ease-in-out"},
            "spring": {"response": 0.3, "dampingFraction": 0.9, "bounce": 0.0},
            "rationale": "微細で即応的なホバー。操作の確実さを伝達",
        },
        "exit": {
            "gsap": {"ease": "power2.in", "duration": 0.5},
            "css": {"transition": "opacity 0.5s ease-in", "timing_function": "ease-in"},
            "spring": {"response": 0.4, "dampingFraction": 0.95, "bounce": 0.0},
            "rationale": "素早く静かな退場。ユーザーフローを妨げない",
        },
    },
    "excitement": {
        "page_load": {
            "gsap": {"ease": "back.out(1.7)", "duration": 0.6, "stagger": 0.08, "scrollTrigger": {"start": "top 75%", "toggleActions": "play none none none"}},
            "css": {"transition": "all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)", "timing_function": "cubic-bezier(0.34, 1.56, 0.64, 1)"},
            "spring": {"response": 0.4, "dampingFraction": 0.6, "bounce": 0.35},
            "rationale": "弾むようなオーバーシュートで興奮感を演出。大胆で記憶に残る動き",
        },
        "scroll_reveal": {
            "gsap": {"ease": "elastic.out(1, 0.5)", "duration": 1.0, "stagger": 0.06, "scrollTrigger": {"start": "top 70%", "toggleActions": "play none none reverse"}},
            "css": {"transition": "all 1.0s cubic-bezier(0.68, -0.55, 0.265, 1.55)", "timing_function": "cubic-bezier(0.68, -0.55, 0.265, 1.55)"},
            "spring": {"response": 0.5, "dampingFraction": 0.55, "bounce": 0.4},
            "rationale": "弾性のあるスクロール表示。発見の瞬間を強調",
        },
        "hover": {
            "gsap": {"ease": "back.out(2)", "duration": 0.25},
            "css": {"transition": "transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1)", "timing_function": "cubic-bezier(0.34, 1.56, 0.64, 1)"},
            "spring": {"response": 0.2, "dampingFraction": 0.5, "bounce": 0.3},
            "rationale": "ポップな反応。インタラクションへの期待感を生成",
        },
        "exit": {
            "gsap": {"ease": "power3.in", "duration": 0.3},
            "css": {"transition": "all 0.3s cubic-bezier(0.55, 0.085, 0.68, 0.53)", "timing_function": "cubic-bezier(0.55, 0.085, 0.68, 0.53)"},
            "spring": {"response": 0.25, "dampingFraction": 0.8, "bounce": 0.1},
            "rationale": "スピーディーな退場。次のアクションへの勢いを維持",
        },
    },
    "calm": {
        "page_load": {
            "gsap": {"ease": "sine.out", "duration": 1.2, "stagger": 0.2, "scrollTrigger": {"start": "top 85%", "toggleActions": "play none none none"}},
            "css": {"transition": "all 1.2s cubic-bezier(0.39, 0.575, 0.565, 1)", "timing_function": "cubic-bezier(0.39, 0.575, 0.565, 1)"},
            "spring": {"response": 0.8, "dampingFraction": 0.9, "bounce": 0.0},
            "rationale": "呼吸のようにゆったりとしたイージング。穏やかさと安心感を表現",
        },
        "scroll_reveal": {
            "gsap": {"ease": "sine.inOut", "duration": 1.0, "stagger": 0.15, "scrollTrigger": {"start": "top 90%", "toggleActions": "play none none reverse"}},
            "css": {"transition": "opacity 1.0s ease, transform 1.0s ease", "timing_function": "ease"},
            "spring": {"response": 0.7, "dampingFraction": 0.92, "bounce": 0.0},
            "rationale": "静かに現れるコンテンツ。瞑想的なブラウジング体験",
        },
        "hover": {
            "gsap": {"ease": "sine.inOut", "duration": 0.4},
            "css": {"transition": "all 0.4s ease", "timing_function": "ease"},
            "spring": {"response": 0.35, "dampingFraction": 0.95, "bounce": 0.0},
            "rationale": "ゆったりとしたホバー。急かされない操作感",
        },
        "exit": {
            "gsap": {"ease": "sine.in", "duration": 0.8},
            "css": {"transition": "opacity 0.8s ease-in", "timing_function": "ease-in"},
            "spring": {"response": 0.6, "dampingFraction": 0.95, "bounce": 0.0},
            "rationale": "フェードアウトするような穏やかな退場",
        },
    },
    "luxury": {
        "page_load": {
            "gsap": {"ease": "expo.out", "duration": 1.4, "stagger": 0.15, "scrollTrigger": {"start": "top 80%", "toggleActions": "play none none none"}},
            "css": {"transition": "all 1.4s cubic-bezier(0.16, 1, 0.3, 1)", "timing_function": "cubic-bezier(0.16, 1, 0.3, 1)"},
            "spring": {"response": 0.9, "dampingFraction": 0.88, "bounce": 0.05},
            "rationale": "ゆっくりと優雅に展開。高級感のある緩やかな減速",
        },
        "scroll_reveal": {
            "gsap": {"ease": "expo.out", "duration": 1.2, "stagger": 0.12, "scrollTrigger": {"start": "top 80%", "toggleActions": "play none none reverse"}},
            "css": {"transition": "all 1.2s cubic-bezier(0.16, 1, 0.3, 1)", "timing_function": "cubic-bezier(0.16, 1, 0.3, 1)"},
            "spring": {"response": 0.8, "dampingFraction": 0.85, "bounce": 0.08},
            "rationale": "劇場の幕が開くような演出。コンテンツの価値を高める",
        },
        "hover": {
            "gsap": {"ease": "power2.out", "duration": 0.5},
            "css": {"transition": "all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)", "timing_function": "cubic-bezier(0.25, 0.46, 0.45, 0.94)"},
            "spring": {"response": 0.4, "dampingFraction": 0.85, "bounce": 0.05},
            "rationale": "洗練されたゆったりホバー。余裕のあるインタラクション",
        },
        "exit": {
            "gsap": {"ease": "expo.in", "duration": 0.8},
            "css": {"transition": "opacity 0.8s cubic-bezier(0.7, 0, 0.84, 0)", "timing_function": "cubic-bezier(0.7, 0, 0.84, 0)"},
            "spring": {"response": 0.6, "dampingFraction": 0.9, "bounce": 0.0},
            "rationale": "優雅にフェードする退場。品位を保つ",
        },
    },
    "innovation": {
        "page_load": {
            "gsap": {"ease": "power4.out", "duration": 0.7, "stagger": 0.05, "scrollTrigger": {"start": "top 75%", "toggleActions": "play none none none"}},
            "css": {"transition": "all 0.7s cubic-bezier(0.22, 1, 0.36, 1)", "timing_function": "cubic-bezier(0.22, 1, 0.36, 1)"},
            "spring": {"response": 0.35, "dampingFraction": 0.7, "bounce": 0.2},
            "rationale": "シャープで先進的なモーション。テクノロジーの精密さを表現",
        },
        "scroll_reveal": {
            "gsap": {"ease": "power3.out", "duration": 0.6, "stagger": 0.04, "scrollTrigger": {"start": "top 70%", "toggleActions": "play none none reverse"}},
            "css": {"transition": "all 0.6s cubic-bezier(0.22, 1, 0.36, 1)", "timing_function": "cubic-bezier(0.22, 1, 0.36, 1)"},
            "spring": {"response": 0.3, "dampingFraction": 0.72, "bounce": 0.18},
            "rationale": "高速でクリスプなスクロール表示。デジタルネイティブ感",
        },
        "hover": {
            "gsap": {"ease": "power3.out", "duration": 0.2},
            "css": {"transition": "all 0.2s cubic-bezier(0.22, 1, 0.36, 1)", "timing_function": "cubic-bezier(0.22, 1, 0.36, 1)"},
            "spring": {"response": 0.15, "dampingFraction": 0.7, "bounce": 0.15},
            "rationale": "即座に応答するホバー。技術的な精度と速度",
        },
        "exit": {
            "gsap": {"ease": "power4.in", "duration": 0.4},
            "css": {"transition": "all 0.4s cubic-bezier(0.64, 0, 0.78, 0)", "timing_function": "cubic-bezier(0.64, 0, 0.78, 0)"},
            "spring": {"response": 0.3, "dampingFraction": 0.85, "bounce": 0.05},
            "rationale": "クリーンで素早い退場。効率的な遷移",
        },
    },
    "energy": {
        "page_load": {
            "gsap": {"ease": "back.out(2.5)", "duration": 0.5, "stagger": 0.04, "scrollTrigger": {"start": "top 70%", "toggleActions": "play none none none"}},
            "css": {"transition": "all 0.5s cubic-bezier(0.34, 2, 0.64, 1)", "timing_function": "cubic-bezier(0.34, 2, 0.64, 1)"},
            "spring": {"response": 0.3, "dampingFraction": 0.45, "bounce": 0.5},
            "rationale": "爆発的なエネルギーで飛び出す登場。強烈なインパクト",
        },
        "scroll_reveal": {
            "gsap": {"ease": "elastic.out(1.2, 0.4)", "duration": 0.8, "stagger": 0.03, "scrollTrigger": {"start": "top 65%", "toggleActions": "play none none reverse"}},
            "css": {"transition": "all 0.8s cubic-bezier(0.68, -0.6, 0.32, 1.6)", "timing_function": "cubic-bezier(0.68, -0.6, 0.32, 1.6)"},
            "spring": {"response": 0.35, "dampingFraction": 0.4, "bounce": 0.55},
            "rationale": "弾力のあるスクロール表示。アドレナリン駆動の体験",
        },
        "hover": {
            "gsap": {"ease": "back.out(3)", "duration": 0.2},
            "css": {"transition": "transform 0.2s cubic-bezier(0.34, 2, 0.64, 1)", "timing_function": "cubic-bezier(0.34, 2, 0.64, 1)"},
            "spring": {"response": 0.15, "dampingFraction": 0.4, "bounce": 0.45},
            "rationale": "パンチのあるホバー。即座に力強いフィードバック",
        },
        "exit": {
            "gsap": {"ease": "power4.in", "duration": 0.25},
            "css": {"transition": "all 0.25s cubic-bezier(0.55, 0.085, 0.68, 0.53)", "timing_function": "cubic-bezier(0.55, 0.085, 0.68, 0.53)"},
            "spring": {"response": 0.2, "dampingFraction": 0.7, "bounce": 0.15},
            "rationale": "電光石火の退場。エネルギーの余韻を残す",
        },
    },
}


@mcp.tool()
async def get_animation_tokens(
    emotion: str,
    context: str = "page_load",
) -> str:
    """Get animation / motion design tokens for an emotion and context.

    Returns GSAP, CSS animation, and Spring physics parameters tuned to evoke
    the target emotion.

    Args:
        emotion: One of trust, excitement, calm, luxury, innovation, energy.
        context: Animation context — "page_load", "scroll_reveal", "hover", "exit".

    Returns:
        JSON with gsap, css, spring parameters and rationale.
    """
    err = _validate_emotion(emotion)
    if err:
        return err

    valid_contexts = ["page_load", "scroll_reveal", "hover", "exit"]
    if context not in valid_contexts:
        return f"Unknown context '{context}'. Available: {valid_contexts}"

    data = ANIMATION_DATA[emotion][context]

    return json.dumps({
        "emotion": emotion,
        "context": context,
        "gsap": data["gsap"],
        "css": data["css"],
        "spring": data["spring"],
        "rationale": data["rationale"],
    }, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Tool 9: analyze_visual_design
# ---------------------------------------------------------------------------
@mcp.tool()
async def analyze_visual_design(url: str) -> str:
    """Analyze the visual design of a URL using screenshot color extraction and CSS analysis.

    Combines ScreenshotOne (visual capture) + Imagga (dominant color extraction) with
    Firecrawl (CSS analysis) for a dual-analysis emotion assessment with confidence score.

    Args:
        url: The URL to analyze (e.g. "https://linear.app").

    Returns:
        JSON with visual_colors, css_colors, emotion_scores, confidence, and design_tokens.
    """
    # Validate API keys
    missing = []
    if not SCREENSHOTONE_API_KEY:
        missing.append("SCREENSHOTONE_API_KEY")
    if not IMAGGA_API_KEY or not IMAGGA_API_SECRET:
        missing.append("IMAGGA_API_KEY / IMAGGA_API_SECRET")
    if missing:
        return json.dumps({
            "error": f"Missing API keys: {', '.join(missing)}",
            "hint": "Add these to your .env file to enable visual design analysis",
            "required_keys": missing,
        })

    try:
        # Step 1: Get screenshot via ScreenshotOne
        screenshot_url = (
            f"https://api.screenshotone.com/take"
            f"?access_key={SCREENSHOTONE_API_KEY}"
            f"&url={url}"
            f"&full_page=false"
            f"&block_ads=true"
            f"&format=png"
            f"&viewport_width=1440"
            f"&viewport_height=900"
        )

        # Step 2: Send screenshot URL to Imagga for color extraction
        async with httpx.AsyncClient(timeout=30) as client:
            imagga_resp = await client.get(
                "https://api.imagga.com/v2/colors",
                params={"image_url": screenshot_url},
                auth=(IMAGGA_API_KEY, IMAGGA_API_SECRET),
            )

        visual_colors: list[dict] = []
        if imagga_resp.status_code == 200:
            imagga_data = imagga_resp.json()
            color_info = imagga_data.get("result", {}).get("colors", {})
            for color_group in ["foreground_colors", "background_colors"]:
                for c in color_info.get(color_group, []):
                    visual_colors.append({
                        "hex": f"#{c.get('html_code', '000000').lstrip('#')}",
                        "percentage": c.get("percentage", 0),
                        "name": c.get("closest_palette_color", ""),
                        "group": color_group.replace("_colors", ""),
                    })

        # Step 3: Firecrawl CSS analysis (reuse shared helper)
        try:
            extracted = await _firecrawl_extract(url)
        except RuntimeError:
            extracted = {}

        primary   = extracted.get("primary_color", "#333333")
        secondary = extracted.get("secondary_color", "#666666")
        accent    = extracted.get("accent_color", "#3b82f6")
        bg        = extracted.get("background_color", "#ffffff")
        radius    = extracted.get("border_radius_style", "medium")
        spacing   = extracted.get("spacing_density", "balanced")
        tone      = extracted.get("overall_tone", "neutral")

        # Step 4: Compute CSS-based emotion scores
        css_scores = _compute_emotion_scores(
            primary_color=primary,
            secondary_color=secondary,
            accent_color=accent,
            background_color=bg,
            border_radius_style=radius,
            spacing_density=spacing,
            overall_tone=tone,
        )

        # Compute visual-based emotion scores from Imagga colors
        visual_scores = {
            "trust": 30, "excitement": 25, "calm": 30,
            "luxury": 25, "innovation": 30, "energy": 25,
        }
        for vc in visual_colors:
            try:
                hue, sat, lum = _hex_to_hsl(vc["hex"])
                pct_weight = vc["percentage"] / 100

                if hue < 60 or hue > 330:
                    visual_scores["excitement"] += int(10 * pct_weight)
                    visual_scores["energy"] += int(10 * pct_weight)
                elif 200 <= hue <= 260:
                    visual_scores["trust"] += int(10 * pct_weight)
                    visual_scores["innovation"] += int(6 * pct_weight)
                elif 260 < hue <= 330:
                    visual_scores["innovation"] += int(10 * pct_weight)
                    visual_scores["luxury"] += int(6 * pct_weight)
                elif 90 <= hue <= 170:
                    visual_scores["calm"] += int(10 * pct_weight)

                if lum < 20:
                    visual_scores["luxury"] += int(5 * pct_weight)
                if sat < 15:
                    visual_scores["luxury"] += int(3 * pct_weight)
                    visual_scores["calm"] += int(3 * pct_weight)
            except (ValueError, IndexError):
                pass

        for k in visual_scores:
            visual_scores[k] = max(0, min(100, visual_scores[k]))

        # Step 5: Merge scores (60% CSS + 40% visual)
        merged = {}
        for emo in VALID_EMOTIONS:
            merged[emo] = round(css_scores.get(emo, 0) * 0.6 + visual_scores.get(emo, 0) * 0.4)

        dominant = max(merged, key=merged.get)

        # Step 6: Confidence = agreement between CSS and visual dominant
        css_dominant = max(css_scores, key=css_scores.get)
        visual_dominant = max(visual_scores, key=visual_scores.get)
        if css_dominant == visual_dominant:
            confidence = 0.9
        elif css_dominant == dominant or visual_dominant == dominant:
            confidence = 0.7
        else:
            confidence = 0.5

        # Adjust confidence by score margin
        sorted_merged = sorted(merged.values(), reverse=True)
        if len(sorted_merged) >= 2 and sorted_merged[0] > 0:
            margin = (sorted_merged[0] - sorted_merged[1]) / sorted_merged[0]
            confidence = min(1.0, confidence + margin * 0.1)

        tokens = EMOTION_TOKENS[dominant]
        result = {
            "url": url,
            "dominant_emotion": dominant,
            "confidence": round(confidence, 2),
            "emotion_scores": merged,
            "analysis": {
                "css_dominant": css_dominant,
                "css_scores": css_scores,
                "visual_dominant": visual_dominant,
                "visual_scores": visual_scores,
                "merge_weight": "css(60%) + visual(40%)",
            },
            "visual_colors": visual_colors[:10],
            "design_tokens": {
                "neuria": {
                    "color": {
                        "bg":        {"$type": "color", "$value": tokens["bg"]},
                        "accent":    {"$type": "color", "$value": tokens["accent"]},
                        "text":      {"$type": "color", "$value": tokens["text"]},
                    },
                },
            },
            "similar_references": EMOTION_REFERENCE_SITES.get(dominant, [])[:3],
        }

        return json.dumps(result, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({"error": str(e)})


# ---------------------------------------------------------------------------
# Tool 10: analyze_brand_voice
# ---------------------------------------------------------------------------
# Hume AI 53 emotions → NEURIA 6 emotions mapping
HUME_TO_NEURIA = {
    "trust":      ["Admiration", "Calmness", "Satisfaction", "Realization"],
    "excitement": ["Excitement", "Ecstasy", "Surprise (positive)", "Thrill"],
    "calm":       ["Calmness", "Contentment", "Serenity", "Relief"],
    "luxury":     ["Admiration", "Desire", "Aesthetic Appreciation"],
    "innovation": ["Awe", "Interest", "Curiosity", "Realization"],
    "energy":     ["Excitement", "Determination", "Enthusiasm", "Joy"],
}


@mcp.tool()
async def analyze_brand_voice(
    text: Optional[str] = None,
    url: Optional[str] = None,
) -> str:
    """Analyze brand voice / text emotion using Hume AI Expression API.

    Maps Hume's 53-dimensional emotion scores to NEURIA's 6 emotion categories
    for brand voice alignment.

    Args:
        text: Direct text to analyze (e.g. "Think different").
        url: URL to extract text from via Firecrawl, then analyze.

    Returns:
        JSON with neuria_emotions, dominant_emotion, hume_top_emotions, and rationale.
    """
    if not text and not url:
        return json.dumps({
            "error": "Provide either 'text' or 'url' parameter",
        })

    if not HUME_API_KEY:
        return json.dumps({
            "error": "HUME_API_KEY not configured",
            "hint": "Add HUME_API_KEY=... to your .env file to enable brand voice analysis",
        })

    # Step 1: Get text content
    content = text or ""
    if url and not text:
        try:
            content = await _firecrawl_markdown(url)
            # Truncate to reasonable size for Hume API
            content = content[:5000]
        except RuntimeError as e:
            return json.dumps({"error": str(e)})
        except Exception as e:
            return json.dumps({"error": f"Failed to extract text from URL: {e}"})

    if not content.strip():
        return json.dumps({"error": "No text content to analyze"})

    try:
        # Step 2: Submit to Hume AI batch API
        headers = {
            "X-Hume-Api-Key": HUME_API_KEY,
            "Content-Type": "application/json",
        }

        job_payload = {
            "models": {
                "language": {},
            },
            "text": [content[:5000]],
        }

        async with httpx.AsyncClient(timeout=30) as client:
            submit_resp = await client.post(
                "https://api.hume.ai/v0/batch/jobs",
                headers=headers,
                json=job_payload,
            )

            if submit_resp.status_code not in (200, 201):
                return json.dumps({
                    "error": f"Hume AI API returned {submit_resp.status_code}",
                    "detail": submit_resp.text[:500],
                })

            job_data = submit_resp.json()
            job_id = job_data.get("job_id")
            if not job_id:
                return json.dumps({
                    "error": "No job_id returned from Hume AI",
                    "response": submit_resp.text[:500],
                })

        # Step 3: Poll for completion (max 60 seconds)
        hume_emotions: dict[str, float] = {}
        async with httpx.AsyncClient(timeout=15) as client:
            for _ in range(12):
                await asyncio.sleep(5)
                poll_resp = await client.get(
                    f"https://api.hume.ai/v0/batch/jobs/{job_id}/predictions",
                    headers={"X-Hume-Api-Key": HUME_API_KEY},
                )

                if poll_resp.status_code == 200:
                    pred_data = poll_resp.json()
                    # Navigate the response structure
                    sources = pred_data if isinstance(pred_data, list) else [pred_data]
                    for source in sources:
                        results = source.get("results", {})
                        predictions = results.get("predictions", [])
                        for pred in predictions:
                            models = pred.get("models", {})
                            lang = models.get("language", {})
                            grouped = lang.get("grouped_predictions", [])
                            for group in grouped:
                                for item in group.get("predictions", []):
                                    for emo in item.get("emotions", []):
                                        name = emo.get("name", "")
                                        score = emo.get("score", 0)
                                        hume_emotions[name] = max(
                                            hume_emotions.get(name, 0), score
                                        )
                    if hume_emotions:
                        break
                elif poll_resp.status_code == 400:
                    # Job still processing
                    continue

        if not hume_emotions:
            return json.dumps({
                "error": "Hume AI job timed out or returned no predictions",
                "job_id": job_id,
            })

        # Step 4: Map Hume emotions to NEURIA 6 emotions
        neuria_scores: dict[str, float] = {}
        for neuria_emo, hume_names in HUME_TO_NEURIA.items():
            mapped_scores = [hume_emotions.get(h, 0) for h in hume_names]
            neuria_scores[neuria_emo] = round(
                sum(mapped_scores) / len(mapped_scores) * 100, 1
            ) if mapped_scores else 0

        dominant = max(neuria_scores, key=neuria_scores.get)

        # Top Hume emotions for context
        top_hume = sorted(
            hume_emotions.items(), key=lambda x: x[1], reverse=True
        )[:8]

        # Rationale
        top_3_hume_names = [h[0] for h in top_hume[:3]]
        mapped_neuria = [
            n for n, humes in HUME_TO_NEURIA.items()
            if any(h in top_3_hume_names for h in humes)
        ]

        rationale = (
            f"テキストの主要感情は {', '.join(top_3_hume_names)} で、"
            f"NEURIA感情 {dominant} に最も強くマッピング。"
        )
        if len(mapped_neuria) > 1:
            rationale += f" 副次感情: {', '.join(e for e in mapped_neuria if e != dominant)}"

        result = {
            "dominant_emotion": dominant,
            "neuria_emotions": neuria_scores,
            "hume_top_emotions": [
                {"name": name, "score": round(score, 4)} for name, score in top_hume
            ],
            "text_preview": content[:200] + ("..." if len(content) > 200 else ""),
            "source": "url" if url and not text else "direct_text",
            "rationale": rationale,
            "design_tokens": EMOTION_TOKENS[dominant],
        }

        return json.dumps(result, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({"error": str(e)})


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    mcp.run(transport="sse")
