"""
Constitutional AI for Emotional Design Evaluation
各感情の「憲法」= 評価基準の厳密な定義

References:
- Constitutional AI (Bai et al., 2022)
- NEURIAの科学的感情パラメータv2.0 (lib/context.py)
"""

EMOTION_CONSTITUTIONS = {
    "trust": {
        "name": "Trust（信頼）",
        "principles": [
            "青/紺を基調色として使用している（hue 190-260°）",
            "清潔なサンセリフ体（Inter, DM Sans, Roboto等）を使用している",
            "行間が1.7以上で読みやすい",
            "余白がビューポートの30%以上を占めている",
            "カラーパレットが3色以内に抑えられている",
            "アニメーション速度が250-400ms（速すぎず遅すぎない）",
            "角丸が中程度（6-12px）で親しみやすい",
            "コントラスト比がWCAG AA以上（4.5:1）",
            "レイアウトが左右対称で安定感がある",
            "数字や実績データが目立つ位置にある",
        ],
        "anti_principles": [
            "赤やオレンジなど暖色が支配的",
            "非対称や斜めの要素が多い",
            "フォントウェイトが極端（100以下または900以上）",
            "余白がほとんどない密集レイアウト",
            "派手なアニメーションやグリッチエフェクト",
        ],
        "scoring_rubric": """
        9-10: 全原則を満たし、見た瞬間に「信頼できる」と感じる
        7-8: 大半の原則を満たし、プロフェッショナルに見える
        5-6: いくつかの原則を満たすが、信頼感が不十分
        3-4: anti_principlesに該当する要素がある
        1-2: 信頼感がなく、不安を感じる
        """,
    },

    "excitement": {
        "name": "Excitement（興奮）",
        "principles": [
            "赤/オレンジなど暖色高彩度が使われている（hue 0-15° or 330-360°）",
            "高コントラスト（明暗の差が大きい）",
            "大胆なタイポグラフィ（font-weight 700-900、clamp(3rem, 10vw, 7rem)以上）",
            "動的な要素（斜め線、非対称レイアウト、動きの示唆）",
            "アニメーション速度が速い（100-250ms）",
            "ホバーエフェクトが顕著（6px以上のlift、色変化）",
            "3Dオブジェクトが大きく目立つ",
            "letter-spacingがタイト（-0.02em以下）",
        ],
        "anti_principles": [
            "パステルカラーや低彩度の色",
            "小さく控えめなテキスト",
            "過度に均整の取れた静的レイアウト",
            "ゆっくりとしたアニメーション（500ms以上）",
        ],
        "scoring_rubric": """
        9-10: 全原則を満たし、見た瞬間にエネルギーを感じる
        7-8: 動的でインパクトがあるが、一部控えめ
        5-6: 普通のデザイン。特にエキサイティングではない
        3-4: 静的で退屈。anti_principlesに該当
        1-2: 眠くなるようなデザイン
        """,
    },

    "calm": {
        "name": "Calm（穏やか）",
        "principles": [
            "緑/シアン系の穏やかな色相（hue 90-190°）",
            "低彩度（20-40%）で目に優しい",
            "高明度（70-90%）で開放感がある",
            "余白が非常に多い（セクション間padding 6rem以上）",
            "アニメーション速度がゆっくり（400-800ms）",
            "角丸が大きい（16px以上）で柔らかい印象",
            "フォントウェイトが細め（300-500）",
            "行間が広い（line-height 2.0以上）",
            "要素数が少なく、情報密度が低い",
            "グラデーションが滑らかで自然",
        ],
        "anti_principles": [
            "鮮やかな赤や高彩度の色",
            "密集したレイアウト",
            "速いアニメーションや点滅",
            "太い大文字テキスト",
            "シャープな角（border-radius: 0）",
        ],
        "scoring_rubric": """
        9-10: 全原則を満たし、深呼吸したくなるような安らぎ
        7-8: 穏やかで心地よい。リラックスできる
        5-6: 特に穏やかでもなく、うるさくもない
        3-4: 少し落ち着かない要素がある
        1-2: ストレスを感じるデザイン
        """,
    },

    "luxury": {
        "name": "Luxury（高級）",
        "principles": [
            "ダークテーマ（背景の明度10-30%）",
            "紫/ゴールドのアクセントカラー（hue 270-330° + 40-50°）",
            "細いフォントウェイト（200-400）のセリフ体",
            "letter-spacingが広い（0.05em以上）",
            "余白が最も多い（セクション間padding 8rem以上）",
            "要素数が最小限（ミニマル）",
            "角丸がほぼゼロ（2-4px）で洗練された印象",
            "微細なボーダー（1px、低不透明度）",
            "ビネット効果が強い（没入感）",
            "テキストサイズの緩急が大きい（見出し5rem+、本文1rem）",
        ],
        "anti_principles": [
            "明るい背景（白ベース）",
            "太いフォント（700以上）",
            "丸い角（border-radius 12px以上）",
            "密集したカードグリッド",
            "鮮やかなネオンカラー",
            "カジュアルなサンセリフ体",
        ],
        "scoring_rubric": """
        9-10: ブランドショップのようなプレミアム感。価格が10倍に見える
        7-8: 高級感があり、洗練されている
        5-6: 普通。特に高級でも安っぽくもない
        3-4: やや安っぽい要素がある
        1-2: 完全にチープ
        """,
    },

    "innovation": {
        "name": "Innovation（革新）",
        "principles": [
            "青紫/シアンのアクセント（hue 250-290° + 170-190°）",
            "幾何学的な要素（3Dオブジェクト、グリッド構造）",
            "モノスペースやジオメトリックフォント（Space Grotesk, JetBrains Mono）",
            "3D WebGLが主役として目立つ",
            "色収差やグリッチ風のポストプロセス効果",
            "コードやターミナル風のUI要素",
            "角丸が小さい（4px）でシャープ",
            "アニメーション速度が中程度（200-350ms）",
            "グラデーションテキスト（gradient-text）",
        ],
        "anti_principles": [
            "伝統的なセリフ体",
            "暖色系カラーパレット",
            "写真中心のレイアウト（3Dではなく）",
            "丸みを帯びた「かわいい」デザイン",
        ],
        "scoring_rubric": """
        9-10: SF映画のインターフェースのよう。未来を感じる
        7-8: テクノロジー企業らしい先進性がある
        5-6: モダンだが特に革新的ではない
        3-4: やや古い印象
        1-2: 旧時代のWebデザイン
        """,
    },

    "energy": {
        "name": "Energy（活力）",
        "principles": [
            "オレンジ/黄色の高彩度カラー（hue 15-65°、saturation 80%+）",
            "最も太いフォント（weight 800-900）",
            "最大のタイポグラフィ（clamp(3rem, 12vw, 8rem)）",
            "letter-spacingがタイト（-0.03em）",
            "アニメーションが最速（80-200ms）",
            "ホバーエフェクトが大きい（8px lift）",
            "フルラウンドの角丸（border-radius: 999px）",
            "密なレイアウト（情報量が多い）",
            "バウンスやスプリングのeasing",
            "3DオブジェクトにAdditiveBlendingのグロー効果",
        ],
        "anti_principles": [
            "低彩度・パステルカラー",
            "細いフォント、広い余白",
            "ゆっくりとしたアニメーション",
            "ミニマルデザイン",
            "寒色系カラーパレット",
        ],
        "scoring_rubric": """
        9-10: 見た瞬間に「やるぞ！」と思わせるパワー
        7-8: 活力があり、ポジティブなエネルギーを感じる
        5-6: 普通のエネルギー感
        3-4: やや元気がない
        1-2: 眠い、無気力
        """,
    },
}


def get_constitution(emotion: str) -> dict:
    """感情タイプの憲法（原則セット）を返す"""
    return EMOTION_CONSTITUTIONS.get(emotion, EMOTION_CONSTITUTIONS["innovation"])


def get_scoring_prompt(emotion: str) -> str:
    """Claude Vision用の感情スコアリングプロンプトを生成"""
    c = get_constitution(emotion)
    principles_text = "\n".join(f"  - {p}" for p in c["principles"])
    anti_text = "\n".join(f"  - {p}" for p in c["anti_principles"])

    return f"""Analyze this website screenshot for {c['name']} emotional alignment.

PRINCIPLES (should be present):
{principles_text}

ANTI-PRINCIPLES (should NOT be present):
{anti_text}

SCORING RUBRIC:
{c['scoring_rubric']}

Rate this design:
1. emotion_score: 0-10 (one decimal) based on the rubric above
2. principles_met: list of principle indices (0-based) that are met
3. anti_principles_violated: list of anti-principle indices that are violated
4. confidence: 0.0-1.0
5. reasoning: 1-2 sentences explaining the score
6. improvement_suggestions: 2-3 specific CSS changes to improve the score

Return ONLY valid JSON."""


def get_full_vision_prompt() -> str:
    """全6感情を同時にスコアリングするClaude Visionプロンプト"""
    return """Analyze this website screenshot. Rate each emotional dimension.

For each emotion, provide: score (0-10, one decimal), confidence (0.0-1.0), reasoning (1 sentence).

1. TRUST: Reliable, professional, credible
   Look for: blue tones, clean sans-serif, consistent spacing, high contrast, symmetric layout

2. EXCITEMENT: Dynamic, energetic, bold
   Look for: warm high-saturation colors, bold typography, diagonal/asymmetric elements, fast motion cues

3. CALM: Peaceful, serene, relaxing
   Look for: green/cyan soft colors, generous whitespace, slow animations, rounded shapes, thin fonts

4. LUXURY: Premium, exclusive, sophisticated
   Look for: dark theme, gold/purple accents, thin serif fonts, wide letter-spacing, minimal elements

5. INNOVATION: Cutting-edge, futuristic, tech
   Look for: blue-purple palette, 3D elements, geometric shapes, monospace fonts, chromatic effects

6. ENERGY: Vibrant, lively, powerful
   Look for: orange/yellow saturated colors, extra-bold fonts, tight spacing, bouncy animations

Also provide:
- overall_quality: 0-10
- dominant_colors: top 3 hex codes
- typography_style: serif/sans-serif/mono/display
- layout_density: minimal/balanced/dense
- dominant_emotion: which of the 6 is strongest

Return ONLY valid JSON."""
