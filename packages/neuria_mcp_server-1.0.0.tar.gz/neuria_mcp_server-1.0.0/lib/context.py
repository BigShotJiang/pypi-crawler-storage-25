"""
Scientific Emotion Design Parameters v2.0 + Environment Context

References:
- Valdez & Mehrabian (1994): PAD model — Pleasure = .69*Brightness + .22*Saturation
- Wilms & Oberfeld (2018): Hue, saturation, brightness effects on emotion
- Jonauskaite et al. (2020): Cross-cultural color-emotion associations (N=4,598)
- Bar & Neta (2006): Amygdala response to angular vs curved shapes (fMRI)
- Shaikh, Chaparro & Fox (2006): Font personality traits (N=561)
- Pracejus, Olsen & O'Guinn (2006): Whitespace and perceived value (+300%)
- Iseki (2025): White space x typeface x luxury perception
- Card, Moran & Newell (1983): Perceptual thresholds
- Material Design 3: Duration tokens
- Koch (2011): Typeface connotations
"""
from datetime import datetime


# ================================================================
# EMOTION_PARAMS — 6 emotions x 15+ scientific parameters
# ================================================================
EMOTION_PARAMS = {
    "trust": {
        # Jonauskaite: blue = 47.5% calm/relaxation; Valdez: high brightness = pleasure
        "hue_range": [190, 260],
        "saturation": [40, 60],
        "lightness": [60, 80],
        "accent_hue": [200, 230],

        # Shaikh: Sans-serif = modern/clean
        "font_style": "clean_sans",
        "font_families": ["Inter", "DM Sans", "Roboto"],
        "heading_weight": [500, 600],
        "body_weight": 400,
        "line_height": 1.8,
        "letter_spacing": "0em",
        "heading_scale": "clamp(2.5rem, 6vw, 4.5rem)",

        # Pracejus: whitespace = perceived value +300%
        "section_padding": "clamp(4rem, 8vh, 6rem)",
        "card_padding": "2rem",
        "layout_density": "balanced",

        # Bar & Neta: curves = approach response
        "border_radius": "8px",
        "card_border": "1px solid rgba(255,255,255,0.08)",

        # Card: 200-300ms = natural/comfortable
        "animation_ms": [250, 400],
        "transition_duration": "0.3s",
        "easing": "cubic-bezier(0.4, 0, 0.2, 1)",
        "scroll_lerp": 0.06,
        "hover_lift": "2px",

        # Three.js post-processing
        "bloom_intensity": 0.3,
        "bloom_threshold": 0.8,
        "bloom_radius": 0.4,
        "chromatic_aberration": 0.0,
        "grain_opacity": 0.02,
        "vignette_offset": 0.3,
        "vignette_darkness": 0.4,
        "noise_type": "perlin",
        "fractal_d": 1.3,

        # CSS effects
        "glow_orb_color": "rgba(30, 64, 175, 0.2)",
        "glow_orb_color_2": "rgba(59, 130, 246, 0.1)",
        "glow_orb_speed": "25s",
        "card_blur": "12px",
        "card_bg_opacity": 0.04,

        # Color palette
        "bg": "#0a1628",
        "surface": "#162036",
        "text_primary": "#ebebeb",
        "text_secondary": "#8b9cb5",
        "accent": "#3b82f6",
        "accent_glow": "rgba(59, 130, 246, 0.15)",

        # 6D emotion vector [trust, excitement, calm, luxury, innovation, energy]
        "emotion_vector": [0.95, 0.1, 0.7, 0.3, 0.4, 0.2],
    },

    "excitement": {
        # Red = strongest arousal; Arousal = .60 * Saturation
        "hue_range": [0, 15],
        "saturation": [70, 100],
        "lightness": [45, 65],
        "accent_hue": [340, 360],

        "font_style": "bold_sans",
        "font_families": ["Clash Display", "Unbounded", "Montserrat"],
        "heading_weight": [700, 900],
        "body_weight": 400,
        "line_height": 1.6,
        "letter_spacing": "-0.02em",
        "heading_scale": "clamp(3rem, 10vw, 7rem)",

        "section_padding": "clamp(3rem, 6vh, 5rem)",
        "card_padding": "1.5rem",
        "layout_density": "dynamic",

        "border_radius": "12px",
        "card_border": "1px solid rgba(255,255,255,0.1)",

        # <100ms = instant/reflexive
        "animation_ms": [100, 250],
        "transition_duration": "0.2s",
        "easing": "cubic-bezier(0.0, 0, 0.2, 1)",
        "scroll_lerp": 0.12,
        "hover_lift": "6px",

        "bloom_intensity": 1.8,
        "bloom_threshold": 0.2,
        "bloom_radius": 0.8,
        "chromatic_aberration": 0.003,
        "grain_opacity": 0.08,
        "vignette_offset": 0.2,
        "vignette_darkness": 0.7,
        "noise_type": "worley",
        "fractal_d": 1.5,

        "glow_orb_color": "rgba(220, 38, 38, 0.3)",
        "glow_orb_color_2": "rgba(251, 146, 60, 0.2)",
        "glow_orb_speed": "12s",
        "card_blur": "8px",
        "card_bg_opacity": 0.06,

        "bg": "#0d0907",
        "surface": "#1c1210",
        "text_primary": "#f5f5f5",
        "text_secondary": "#b5978a",
        "accent": "#ef4444",
        "accent_glow": "rgba(239, 68, 68, 0.2)",

        "emotion_vector": [0.1, 0.95, 0.05, 0.1, 0.5, 0.9],
    },

    "calm": {
        # Green-cyan; low saturation = low arousal
        "hue_range": [120, 180],
        "saturation": [20, 40],
        "lightness": [70, 90],
        "accent_hue": [150, 170],

        "font_style": "light_sans",
        "font_families": ["Inter", "Outfit", "Nunito"],
        "heading_weight": [300, 500],
        "body_weight": 400,
        "line_height": 2.0,
        "letter_spacing": "0.02em",
        "heading_scale": "clamp(2rem, 5vw, 3.5rem)",

        "section_padding": "clamp(5rem, 12vh, 8rem)",
        "card_padding": "2.5rem",
        "layout_density": "spacious",

        "border_radius": "16px",
        "card_border": "1px solid rgba(255,255,255,0.05)",

        # 500-800ms = dramatic/emphasis
        "animation_ms": [400, 800],
        "transition_duration": "0.5s",
        "easing": "cubic-bezier(0.25, 0.1, 0.25, 1.0)",
        "scroll_lerp": 0.04,
        "hover_lift": "1px",

        "bloom_intensity": 0.5,
        "bloom_threshold": 0.6,
        "bloom_radius": 1.0,
        "chromatic_aberration": 0.0,
        "grain_opacity": 0.0,
        "vignette_offset": 0.5,
        "vignette_darkness": 0.3,
        "noise_type": "simplex",
        "fractal_d": 1.3,

        "glow_orb_color": "rgba(16, 185, 129, 0.15)",
        "glow_orb_color_2": "rgba(45, 212, 191, 0.1)",
        "glow_orb_speed": "30s",
        "card_blur": "16px",
        "card_bg_opacity": 0.03,

        "bg": "#0a1a14",
        "surface": "#142820",
        "text_primary": "#e8f0ec",
        "text_secondary": "#8bb5a0",
        "accent": "#10b981",
        "accent_glow": "rgba(16, 185, 129, 0.12)",

        "emotion_vector": [0.6, 0.05, 0.95, 0.4, 0.2, 0.1],
    },

    "luxury": {
        # Purple; Iseki 2025: whitespace x typeface = luxury perception
        "hue_range": [270, 310],
        "saturation": [50, 70],
        "lightness": [10, 30],
        "accent_hue": [40, 50],

        # Koch: Serif = stable/trustworthy; Weight 100-300 = delicate/elegant
        "font_style": "thin_serif",
        "font_families": ["Playfair Display", "Cormorant Garamond", "EB Garamond"],
        "heading_weight": [200, 400],
        "body_weight": 300,
        "line_height": 1.9,
        "letter_spacing": "0.08em",
        "heading_scale": "clamp(2.5rem, 7vw, 5rem)",

        # Maximum whitespace (Pracejus)
        "section_padding": "clamp(6rem, 14vh, 10rem)",
        "card_padding": "3rem",
        "layout_density": "minimal",

        # Near-zero radius = refined/sharp
        "border_radius": "2px",
        "card_border": "1px solid rgba(212, 165, 116, 0.15)",

        "animation_ms": [400, 700],
        "transition_duration": "0.4s",
        "easing": "cubic-bezier(0.16, 1, 0.3, 1)",
        "scroll_lerp": 0.05,
        "hover_lift": "3px",

        "bloom_intensity": 0.8,
        "bloom_threshold": 0.5,
        "bloom_radius": 0.6,
        "chromatic_aberration": 0.001,
        "grain_opacity": 0.04,
        "vignette_offset": 0.15,
        "vignette_darkness": 0.85,
        "noise_type": "perlin",
        "fractal_d": 1.35,

        "glow_orb_color": "rgba(147, 51, 234, 0.2)",
        "glow_orb_color_2": "rgba(212, 165, 116, 0.12)",
        "glow_orb_speed": "20s",
        "card_blur": "10px",
        "card_bg_opacity": 0.05,

        "bg": "#0c0a12",
        "surface": "#1a1525",
        "text_primary": "#e8e4f0",
        "text_secondary": "#9b8fb5",
        "accent": "#d4a574",
        "accent_glow": "rgba(212, 165, 116, 0.15)",

        "emotion_vector": [0.3, 0.1, 0.7, 0.95, 0.4, 0.15],
    },

    "innovation": {
        # Blue-violet; Labrecque & Milne 2012: purple = creativity
        "hue_range": [250, 280],
        "saturation": [60, 85],
        "lightness": [40, 60],
        "accent_hue": [170, 190],

        # Shaikh: Geometric sans = modern/techy
        "font_style": "geometric_sans",
        "font_families": ["Space Grotesk", "Syne", "JetBrains Mono"],
        "heading_weight": [500, 700],
        "body_weight": 400,
        "line_height": 1.7,
        "letter_spacing": "-0.01em",
        "heading_scale": "clamp(2.5rem, 8vw, 5.5rem)",

        "section_padding": "clamp(4rem, 10vh, 7rem)",
        "card_padding": "2rem",
        "layout_density": "structured",

        "border_radius": "4px",
        "card_border": "1px solid rgba(255,255,255,0.06)",

        "animation_ms": [200, 350],
        "transition_duration": "0.25s",
        "easing": "cubic-bezier(0.0, 0, 0.2, 1)",
        "scroll_lerp": 0.08,
        "hover_lift": "4px",

        "bloom_intensity": 1.5,
        "bloom_threshold": 0.3,
        "bloom_radius": 0.7,
        "chromatic_aberration": 0.005,
        "grain_opacity": 0.06,
        "vignette_offset": 0.3,
        "vignette_darkness": 0.5,
        "noise_type": "simplex",
        "fractal_d": 1.4,

        "glow_orb_color": "rgba(123, 97, 255, 0.25)",
        "glow_orb_color_2": "rgba(0, 212, 255, 0.15)",
        "glow_orb_speed": "18s",
        "card_blur": "12px",
        "card_bg_opacity": 0.04,

        "bg": "#0c0c1d",
        "surface": "#16163a",
        "text_primary": "#ebebeb",
        "text_secondary": "#8b8bb5",
        "accent": "#7b61ff",
        "accent_glow": "rgba(123, 97, 255, 0.15)",

        "emotion_vector": [0.4, 0.5, 0.2, 0.3, 0.95, 0.6],
    },

    "energy": {
        # Orange-yellow; Arousal = .60*Saturation (highest)
        "hue_range": [15, 50],
        "saturation": [80, 100],
        "lightness": [50, 70],
        "accent_hue": [30, 45],

        "font_style": "bold_display",
        "font_families": ["Archivo Black", "Bebas Neue", "Oswald"],
        "heading_weight": [800, 900],
        "body_weight": 500,
        "line_height": 1.5,
        "letter_spacing": "-0.03em",
        "heading_scale": "clamp(3rem, 12vw, 8rem)",

        "section_padding": "clamp(3rem, 6vh, 5rem)",
        "card_padding": "1.5rem",
        "layout_density": "dense",

        # Full-round = playful
        "border_radius": "999px",
        "card_border": "2px solid rgba(255,255,255,0.1)",

        # <100ms = instant/reflexive
        "animation_ms": [80, 200],
        "transition_duration": "0.15s",
        "easing": "cubic-bezier(0.34, 1.56, 0.64, 1)",
        "scroll_lerp": 0.14,
        "hover_lift": "8px",

        "bloom_intensity": 1.2,
        "bloom_threshold": 0.4,
        "bloom_radius": 0.5,
        "chromatic_aberration": 0.002,
        "grain_opacity": 0.05,
        "vignette_offset": 0.4,
        "vignette_darkness": 0.4,
        "noise_type": "worley",
        "fractal_d": 1.5,

        "glow_orb_color": "rgba(249, 115, 22, 0.3)",
        "glow_orb_color_2": "rgba(250, 204, 21, 0.2)",
        "glow_orb_speed": "10s",
        "card_blur": "6px",
        "card_bg_opacity": 0.08,

        "bg": "#120d07",
        "surface": "#1f1508",
        "text_primary": "#fef3e2",
        "text_secondary": "#c4a06b",
        "accent": "#f97316",
        "accent_glow": "rgba(249, 115, 22, 0.2)",

        "emotion_vector": [0.2, 0.8, 0.05, 0.1, 0.5, 0.95],
    },
}


# Mood name -> EMOTION_PARAMS key mapping
_MOOD_ALIAS = {
    # English aliases
    "trustworthy": "trust",
    "innovative": "innovation",
    "stability": "trust",
    "precision": "trust",
    "warmth": "calm",
    "creativity": "energy",
    "dynamic": "excitement",
    "futuristic": "innovation",
    "organic": "calm",
    "transformation": "innovation",
    "elegant": "luxury",
    "playful": "excitement",
    # Backward compat (old keys -> new keys)
    "bold": "excitement",
    "premium": "luxury",
    "care": "calm",
}


# ================================================================
# Season Parameters
# ================================================================
SEASON_PARAMS = {
    "spring": {
        "color_temp_shift": +5,
        "saturation_boost": +10,
        "particle_density": 1.2,
        "ambient_note": "桜・新緑の雰囲気。明るく軽やか。",
    },
    "summer": {
        "color_temp_shift": +10,
        "saturation_boost": +15,
        "particle_density": 1.0,
        "ambient_note": "強い光・コントラスト。ビビッドな色彩。",
    },
    "autumn": {
        "color_temp_shift": +15,
        "saturation_boost": -5,
        "particle_density": 0.8,
        "ambient_note": "落ち着いた暖色。深み・成熟した印象。",
    },
    "winter": {
        "color_temp_shift": -10,
        "saturation_boost": -10,
        "particle_density": 0.6,
        "ambient_note": "冷たく静謐。ミニマル・洗練された印象。",
    },
}


# ================================================================
# Time-of-day Parameters
# ================================================================
TIME_PARAMS = {
    "dawn": {
        "hours": (5, 7),
        "brightness_shift": -10,
        "color_temp": "warm_dim",
        "ambient_note": "柔らかい暖光。グラデーション豊か。",
    },
    "morning": {
        "hours": (7, 12),
        "brightness_shift": +5,
        "color_temp": "neutral",
        "ambient_note": "クリアで明るい。標準的な表示。",
    },
    "afternoon": {
        "hours": (12, 17),
        "brightness_shift": 0,
        "color_temp": "slightly_warm",
        "ambient_note": "やや暖色。活動的な印象。",
    },
    "evening": {
        "hours": (17, 21),
        "brightness_shift": -5,
        "color_temp": "warm",
        "ambient_note": "ゴールデンアワー。暖かみのある光。",
    },
    "night": {
        "hours": (21, 5),
        "brightness_shift": -15,
        "color_temp": "cool_dim",
        "ambient_note": "ダークモードに最適。目に優しい低コントラスト。",
    },
}


# ================================================================
# Device Tier Parameters
# ================================================================
DEVICE_PARAMS = {
    "high": {
        "max_particles": 5000,
        "bloom_enabled": True,
        "shader_complexity": "full",
        "pixel_ratio_cap": 2,
        "ambient_note": "フルエフェクト。シェーダー・パーティクル制限なし。",
    },
    "mid": {
        "max_particles": 2000,
        "bloom_enabled": True,
        "shader_complexity": "medium",
        "pixel_ratio_cap": 1.5,
        "ambient_note": "ブルームあり。パーティクルやや制限。",
    },
    "low": {
        "max_particles": 500,
        "bloom_enabled": False,
        "shader_complexity": "basic",
        "pixel_ratio_cap": 1,
        "ambient_note": "ブルームなし。基本シェーダーのみ。パフォーマンス優先。",
    },
}


# ================================================================
# Public API
# ================================================================
def _resolve_mood(mood_input) -> str:
    """Normalize mood input to EMOTION_PARAMS key."""
    if isinstance(mood_input, list):
        mood_input = mood_input[0] if mood_input else "innovation"
    mood = str(mood_input).lower().strip()
    if mood in EMOTION_PARAMS:
        return mood
    if mood in _MOOD_ALIAS:
        return _MOOD_ALIAS[mood]
    return "innovation"


def _get_current_season() -> str:
    month = datetime.now().month
    if month in (3, 4, 5):
        return "spring"
    elif month in (6, 7, 8):
        return "summer"
    elif month in (9, 10, 11):
        return "autumn"
    else:
        return "winter"


def _get_time_of_day() -> str:
    hour = datetime.now().hour
    if 5 <= hour < 7:
        return "dawn"
    elif 7 <= hour < 12:
        return "morning"
    elif 12 <= hour < 17:
        return "afternoon"
    elif 17 <= hour < 21:
        return "evening"
    else:
        return "night"


def get_emotion_params(mood: str) -> dict:
    """Return emotion design parameters for the given mood."""
    key = _resolve_mood(mood)
    return EMOTION_PARAMS.get(key, EMOTION_PARAMS["innovation"])


def get_emotion_vector(emotion: str) -> list:
    """Return 6D emotion vector [trust, excitement, calm, luxury, innovation, energy]."""
    params = get_emotion_params(emotion)
    return params.get("emotion_vector", [0.2, 0.2, 0.2, 0.2, 0.2, 0.2])


def get_css_theme(emotion: str) -> str:
    """Return CSS custom properties + font override for the given emotion."""
    p = get_emotion_params(emotion)
    border_val = p["card_border"].split("solid ")[-1] if "solid" in p["card_border"] else "rgba(255,255,255,0.06)"
    heading_font = p["font_families"][0] if p.get("font_families") else "Space Grotesk"
    body_font = p["font_families"][1] if len(p.get("font_families", [])) > 1 else heading_font
    heading_w = p.get("heading_weight", [600, 800])
    heading_w_val = heading_w[0] if isinstance(heading_w, list) else heading_w
    body_w = p.get("body_weight", 400)
    return f"""\n/* Emotion Theme: {emotion} — DO NOT OVERRIDE */
:root {{
  --bg: {p['bg']}; --surface: {p['surface']};
  --text-primary: {p['text_primary']}; --text-secondary: {p['text_secondary']};
  --accent: {p['accent']}; --accent-glow: {p['accent_glow']};
  --border: {border_val};
  --border-hover: rgba(255,255,255,0.12);
  --card-blur: {p['card_blur']}; --card-bg: rgba(255,255,255,{p['card_bg_opacity']});
  --radius: {p['border_radius']};
  --transition: {p['transition_duration']} {p['easing']};
  --section-padding: {p['section_padding']};
  --card-padding: {p['card_padding']};
  --heading-scale: {p['heading_scale']};
  --line-height: {p['line_height']};
  --letter-spacing: {p['letter_spacing']};
  --hover-lift: {p['hover_lift']};
  --glow-1: {p['glow_orb_color']}; --glow-2: {p['glow_orb_color_2']};
  --glow-speed: {p['glow_orb_speed']};
  --grain: {p['grain_opacity']};
  --heading-font: '{heading_font}', serif;
  --body-font: '{body_font}', sans-serif;
  --heading-weight: {heading_w_val};
  --body-weight: {body_w};
}}
body {{ background: var(--bg) !important; color: var(--text-primary) !important; font-family: var(--body-font) !important; font-weight: var(--body-weight) !important; line-height: var(--line-height) !important; letter-spacing: var(--letter-spacing) !important; }}
h1, h2, h3, h4, h5, h6 {{ font-family: var(--heading-font) !important; font-weight: var(--heading-weight) !important; }}
section {{ padding: var(--section-padding) 5% !important; }}
.glass-card {{ border-radius: var(--radius) !important; border: 1px solid var(--border) !important; }}
"""


def get_threejs_preset(emotion: str) -> dict:
    """Return Three.js post-processing preset for the given emotion."""
    p = get_emotion_params(emotion)
    return {
        "bloom": {
            "intensity": p["bloom_intensity"],
            "threshold": p["bloom_threshold"],
            "radius": p["bloom_radius"],
        },
        "chromatic_aberration": p["chromatic_aberration"],
        "grain_opacity": p["grain_opacity"],
        "vignette": {
            "offset": p["vignette_offset"],
            "darkness": p["vignette_darkness"],
        },
    }


def get_season_params(season: str = None) -> dict:
    if season is None:
        season = _get_current_season()
    return SEASON_PARAMS.get(season, SEASON_PARAMS["spring"])


def get_time_params(time_of_day: str = None) -> dict:
    if time_of_day is None:
        time_of_day = _get_time_of_day()
    return TIME_PARAMS.get(time_of_day, TIME_PARAMS["morning"])


def get_device_params(tier: str = "high") -> dict:
    return DEVICE_PARAMS.get(tier, DEVICE_PARAMS["high"])


def build_context(form_data: dict) -> dict:
    """Build full context from form data + environment for agent prompts."""
    mood = form_data.get("mood", form_data.get("emotions", "innovation"))
    emotion_target = _resolve_mood(mood)
    season = _get_current_season()
    time_of_day = _get_time_of_day()
    device_tier = form_data.get("device_tier", "high")

    return {
        "emotion_target": emotion_target,
        "emotion_params": get_emotion_params(emotion_target),
        "season": season,
        "season_params": get_season_params(season),
        "time_of_day": time_of_day,
        "time_params": get_time_params(time_of_day),
        "device_tier": device_tier,
        "device_params": get_device_params(device_tier),
    }
