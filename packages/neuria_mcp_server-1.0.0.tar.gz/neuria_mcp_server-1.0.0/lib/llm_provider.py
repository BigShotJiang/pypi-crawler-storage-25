"""
BYOK方式: ユーザーのAPIキーで各プロバイダーを呼ぶ統一インターフェース
用途別モデル選択: generate=gpt-4o, score=haiku, vision=haiku
"""

import requests
import json
import time
from typing import Optional

# Anthropic model max output tokens
_ANTHROPIC_MAX_OUTPUT = 8192

# 用途別デフォルトモデル
DEFAULT_MODELS = {
    "openrouter": {
        "generate": "openai/gpt-4o",
        "score": "anthropic/claude-haiku-4-5-20251001",
        "vision": "anthropic/claude-haiku-4-5-20251001",
    },
    "openai": {
        "generate": "gpt-4o",
        "score": "gpt-4o-mini",
        "vision": "gpt-4o",
    },
    "anthropic": {
        "generate": "claude-sonnet-4-20250514",
        "score": "claude-haiku-4-5-20251001",
        "vision": "claude-haiku-4-5-20251001",
    },
}


def get_default_model(provider: str, purpose: str = "generate") -> str:
    """用途に応じたデフォルトモデルを返す"""
    models = DEFAULT_MODELS.get(provider, {})
    return models.get(purpose, models.get("generate", "gpt-4o"))


def call_llm(
    system_prompt: str,
    user_prompt: str,
    api_key: str,
    provider: str = "openrouter",
    model: Optional[str] = None,
    purpose: str = "generate",
    max_tokens: int = 16000,
    images: list = None,
    max_retries: int = 2,
) -> str:
    """ユーザーのAPIキーでLLMを呼ぶ統一インターフェース（リトライ付き）"""
    if model is None:
        model = get_default_model(provider, purpose)

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            if provider == "openrouter":
                return _call_openrouter(system_prompt, user_prompt, api_key, model, max_tokens, images)
            elif provider == "anthropic":
                return _call_anthropic(system_prompt, user_prompt, api_key, model, max_tokens, images)
            elif provider == "openai":
                return _call_openai(system_prompt, user_prompt, api_key, model, max_tokens, images)
            else:
                raise ValueError(f"Unknown provider: {provider}")
        except RuntimeError as e:
            last_error = e
            err_str = str(e)
            # リトライ可能なエラー: 429 (rate limit), 529 (overloaded), 500 (server error)
            if any(code in err_str for code in ["429", "529", "500", "overloaded", "rate_limit"]):
                wait = (attempt + 1) * 5  # 5s, 10s
                time.sleep(wait)
                continue
            # 400 invalid_request_error もリトライ（max_tokens調整後）
            if "400" in err_str and attempt < max_retries:
                if provider == "anthropic" and max_tokens > 4096:
                    max_tokens = min(max_tokens, 4096)
                    time.sleep(2)
                    continue
            raise
    raise last_error


def _call_openrouter(system, user, api_key, model, max_tokens, images):
    messages = [{"role": "system", "content": system}]

    if images:
        content = [{"type": "text", "text": user}]
        for img_b64 in images:
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/png;base64,{img_b64}"}
            })
        messages.append({"role": "user", "content": content})
    else:
        messages.append({"role": "user", "content": user})

    resp = requests.post(
        "https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://neuria.ai",
            "X-Title": "NEURIA",
        },
        json={
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
        },
        timeout=300,
    )

    if resp.status_code != 200:
        raise RuntimeError(f"OpenRouter API error: {resp.status_code} {resp.text[:300]}")

    data = resp.json()
    return data["choices"][0]["message"]["content"]


def _call_anthropic(system, user, api_key, model, max_tokens, images):
    # max_tokens を安全な範囲にクランプ
    max_tokens = min(max_tokens, _ANTHROPIC_MAX_OUTPUT)

    messages = []
    if images:
        content = [{"type": "text", "text": user}]
        for img_b64 in images:
            content.append({
                "type": "image",
                "source": {"type": "base64", "media_type": "image/png", "data": img_b64}
            })
        messages.append({"role": "user", "content": content})
    else:
        messages.append({"role": "user", "content": user})

    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        },
        json={
            "model": model,
            "system": system,
            "messages": messages,
            "max_tokens": max_tokens,
        },
        timeout=300,
    )

    if resp.status_code != 200:
        raise RuntimeError(f"Anthropic API error: {resp.status_code} {resp.text[:500]}")

    data = resp.json()
    return data["content"][0]["text"]


def _call_openai(system, user, api_key, model, max_tokens, images):
    messages = [{"role": "system", "content": system}]

    if images:
        content = [{"type": "text", "text": user}]
        for img_b64 in images:
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/png;base64,{img_b64}"}
            })
        messages.append({"role": "user", "content": content})
    else:
        messages.append({"role": "user", "content": user})

    resp = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
        },
        timeout=300,
    )

    if resp.status_code != 200:
        raise RuntimeError(f"OpenAI API error: {resp.status_code} {resp.text[:300]}")

    data = resp.json()
    return data["choices"][0]["message"]["content"]
