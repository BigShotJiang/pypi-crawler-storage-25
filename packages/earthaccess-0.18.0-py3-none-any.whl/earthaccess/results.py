import json
import uuid
import warnings
from functools import cache
from typing import Any

import requests

import earthaccess

from .formatters import _repr_granule_html
from .services import DataServices


@cache
def _citation(*, doi: str, format_: str, language: str) -> str:
    response = requests.get(
        "https://citation.doi.org/format",
        params={"doi": doi, "style": format_, "lang": language},
    )
    response.raise_for_status()
    return response.text


class CustomDict(dict):
    _basic_umm_fields_: list = []
    _basic_meta_fields_: list = []

    def __init__(
        self,
        collection: dict[str, Any],
        fields: list[str] | None = None,
        cloud_hosted: bool = False,
    ):
        super().__init__(collection)
        self.cloud_hosted = cloud_hosted
        self.uuid = str(uuid.uuid4())

        self.render_dict: Any
        if fields is None:
            self.render_dict = self
        elif fields[0] == "basic":
            self.render_dict = self._filter_fields_(self._basic_umm_fields_)
        else:
            self.render_dict = self._filter_fields_(fields)

    def _filter_fields_(self, fields: list[str]) -> dict[str, Any]:
        filtered_dict = {
            "umm": {
                (field, self["umm"][field]) for field in fields if field in self["umm"]
            },
        }
        basic_dict = {
            "meta": {
                (field, self["meta"][field])
                for field in self._basic_meta_fields_
                if field in self["meta"]
            },
        }
        basic_dict.update(filtered_dict)
        return basic_dict

    def _filter_related_links(self, link_type: str) -> list[str]:
        """Filter RelatedUrls from the UMM fields on CMR."""
        return [
            link["URL"]
            for link in self["umm"].get("RelatedUrls", [])
            if link.get("Type") == link_type
        ]


class DataCollection(CustomDict):
    """Dictionary-like object to represent a data collection from CMR."""

    _basic_meta_fields_ = [
        "concept-id",
        "granule-count",
        "provider-id",
    ]

    _basic_umm_fields_ = [
        "ShortName",
        "Abstract",
        "SpatialExtent",
        "TemporalExtents",
        "DataCenters",
        "RelatedUrls",
        "ArchiveAndDistributionInformation",
        "DirectDistributionInformation",
    ]

    def summary(self) -> dict[str, Any]:
        """Summary containing short_name, concept-id, file-type, and cloud-info (if cloud-hosted).

        Returns:
            A summary of the collection metadata.
        """
        # we can print only the concept-id

        warnings.warn(
            "As of version 1.0, `DataCollection.summary` will be accessed as an "
            "attribute; e.g. use `DataCollection.summary` **not** "
            "`DataCollection.summary()`",
            category=FutureWarning,
            stacklevel=2,
        )

        # Only issue a single FutureWarning
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=FutureWarning)

            summary_dict: dict[str, Any]
            summary_dict = {
                "short-name": self.get_umm("ShortName"),
                "concept-id": self.concept_id(),
                "version": self.version(),
                "file-type": self.data_type(),
                "get-data": self.get_data(),
            }
            if "Region" in self.s3_bucket():
                summary_dict["cloud-info"] = self.s3_bucket()

        return summary_dict

    def get_umm(self, umm_field: str) -> str | dict[str, Any]:
        """Return a field value from the collection UMM record.

        Parameters:
            umm_field: Valid UMM item, i.e. `TemporalExtent`.

        Returns:
            The value of a given field inside the UMM (Unified Metadata Model).
        """
        return self["umm"].get(umm_field, "")

    def doi(self) -> str | None:
        """Retrieve the Digital Object Identifier (DOI) for this collection.

        Returns:
            This collection's DOI information, or `None`, if it has none.
        """
        warnings.warn(
            "As of version 1.0, `DataCollection.doi` will be accessed as an "
            "attribute; e.g. use `DataCollection.doi` **not** "
            "`DataCollection.doi()`",
            category=FutureWarning,
            stacklevel=2,
        )

        doi = self["umm"].get("DOI", {})
        if isinstance(doi, dict):
            return doi.get("DOI", None)
        return None

    def citation(self, *, format: str, language: str) -> str | None:  # noqa:A002
        """Fetch a formatted citation for this collection using its DOI.

        Parameters:
            format: Citation format style (e.g., 'apa', 'bibtex', 'ris').
                 For a full list of valid formats, visit <https://citation.doi.org/>
            language: Language code (e.g., 'en-US').
                 For a full list of valid language codes, visit <https://citation.doi.org/>

        Returns:
             The formatted citation as a string, or `None`, if this collection does not have a DOI.

        Raises:
             requests.RequestException: if fetching citation information from citations.doi.org failed.
        """
        return (
            None
            if not (doi := self.doi())
            else _citation(doi=doi, format_=format, language=language)
        )

    def concept_id(self) -> str:
        """Return the collection concept ID.

        Returns:
            A collection's `concept_id`.This id is the most relevant search field on granule queries.
        """
        warnings.warn(
            "As of version 1.0, `DataCollection.concept_id` will be accessed as an "
            "attribute; e.g. use `DataCollection.concept_id` **not** "
            "`DataCollection.concept_id()`",
            category=FutureWarning,
            stacklevel=2,
        )

        return self["meta"]["concept-id"]

    def data_type(self) -> str:
        """Return the collection file distribution type.

        Returns:
            The collection data type, i.e. HDF5, CSV etc., if available.
        """
        warnings.warn(
            "As of version 1.0, `DataCollection.data_type` will be accessed as an "
            "attribute; e.g. use `DataCollection.data_type` **not** "
            "`DataCollection.data_type()`",
            category=FutureWarning,
            stacklevel=2,
        )

        return str(
            self["umm"]
            .get("ArchiveAndDistributionInformation", {})
            .get("FileDistributionInformation", ""),
        )

    def version(self) -> str:
        """Return the collection version.

        Returns:
            The collection's version.
        """
        warnings.warn(
            "As of version 1.0, `DataCollection.version` will be accessed as an "
            "attribute; e.g. use `DataCollection.version` **not** "
            "`DataCollection.version()`",
            category=FutureWarning,
            stacklevel=2,
        )

        return self["umm"].get("Version", "")

    def abstract(self) -> str:
        """Return the collection abstract.

        Returns:
            The abstract of a collection.
        """
        warnings.warn(
            "As of version 1.0, `DataCollection.abstract` will be accessed as an "
            "attribute; e.g. use `DataCollection.abstract` **not** "
            "`DataCollection.abstract()`",
            category=FutureWarning,
            stacklevel=2,
        )

        return self["umm"].get("Abstract", "")

    def landing_page(self) -> str:
        """Return the first landing page link for the collection.

        Returns:
            The first landing page for the collection (can be many), if available.
        """
        warnings.warn(
            "As of version 1.0, `DataCollection.landing_page` will be accessed as an "
            "attribute; e.g. use `DataCollection.landing_page` **not** "
            "`DataCollection.landing_page()`",
            category=FutureWarning,
            stacklevel=2,
        )

        links = self._filter_related_links("LANDING PAGE")
        return links[0] if len(links) > 0 else ""

    def get_data(self) -> list[str]:
        """Return the collection GET DATA links.

        Returns:
            The GET DATA links (usually a landing page link, a DAAC portal, or an FTP location).
        """
        warnings.warn(
            "As of version 1.0, `DataCollection.get_data` will be accessed as an "
            "attribute; e.g. use `DataCollection.get_data` **not** "
            "`DataCollection.get_data()`",
            category=FutureWarning,
            stacklevel=2,
        )

        return self._filter_related_links("GET DATA")

    def s3_bucket(self) -> dict[str, Any]:
        """Return the collection direct distribution information.

        Returns:
            The S3 bucket information if the collection has it (**cloud hosted collections only**).
        """
        warnings.warn(
            "As of version 1.0, `DataCollection.s3_bucket` will be accessed as an "
            "attribute; e.g. use `DataCollection.s3_bucket` **not** "
            "`DataCollection.s3_bucket()`",
            category=FutureWarning,
            stacklevel=2,
        )

        return self["umm"].get("DirectDistributionInformation", {})

    def services(self) -> dict[Any, list[dict[str, Any]]]:
        """Return list of services available for this collection."""
        warnings.warn(
            "As of version 1.0, `DataCollection.services` will be accessed as an "
            "attribute; e.g. use `DataCollection.services` **not** "
            "`DataCollection.services()`",
            category=FutureWarning,
            stacklevel=2,
        )

        services = self.get("meta", {}).get("associations", {}).get("services", [])
        queries = (
            DataServices(auth=earthaccess.__auth__).parameters(concept_id=service)
            for service in services
        )

        return {
            service: query.get_all()
            for service, query in zip(services, queries, strict=False)
        }

    def __repr__(self) -> str:
        return json.dumps(
            self.render_dict,
            sort_keys=False,
            indent=2,
            separators=(",", ": "),
        )


class DataGranule(CustomDict):
    """Dictionary-like object to represent a granule from CMR."""

    _basic_meta_fields_ = [
        "concept-id",
        "provider-id",
    ]

    _basic_umm_fields_ = [
        "GranuleUR",
        "SpatialExtent",
        "TemporalExtent",
        "RelatedUrls",
        "DataGranule",
    ]

    def __init__(
        self,
        collection: dict[str, Any],
        fields: list[str] | None = None,
        cloud_hosted: bool = False,
    ):
        super().__init__(collection)
        self.cloud_hosted = cloud_hosted
        # TODO: maybe add area, start date and all that as an instance value
        self["size"] = self.size()
        self.uuid = str(uuid.uuid4())
        self.render_dict: Any
        if fields is None:
            self.render_dict = self
        elif fields[0] == "basic":
            self.render_dict = self._filter_fields_(self._basic_umm_fields_)
        else:
            self.render_dict = self._filter_fields_(fields)

    def __repr__(self) -> str:
        """Return a basic string representation of the granule.

        Returns:
            A basic representation of a data granule.
        """
        data_links = list(self.data_links())

        # Not all granules have spatial coverage, set to None if missing
        # TODO: We should have a granule metadata validator method
        if "SpatialExtent" not in self["umm"]:
            self["umm"]["SpatialExtent"] = None

        return f"""
        Collection: {self["umm"]["CollectionReference"]}
        Spatial coverage: {self["umm"]["SpatialExtent"]}
        Temporal coverage: {self["umm"]["TemporalExtent"]}
        Size(MB): {self.size()}
        Data: {data_links}\n\n
        """.strip().replace("  ", "")

    def _repr_html_(self) -> str:
        """Return an HTML representation of the granule.

        Returns:
            A rich representation for a data granule if we are in a Jupyter notebook.
        """
        return _repr_granule_html(self)

    def __hash__(self) -> int:  # type: ignore[override]
        return hash(self["meta"]["concept-id"])

    def get_s3_credentials_endpoint(self) -> str | None:
        for link in self["umm"]["RelatedUrls"]:
            if "/s3credentials" in link["URL"]:
                return link["URL"]
        return None

    def size(self) -> float:
        """Return the total granule size in MB.

        Returns:
            The total size for the granule in MB.
        """
        warnings.warn(
            "As of version 1.0, `DataGranule.size` will be accessed as an "
            "attribute; e.g. use `DataCollection.size` **not** "
            "`DataCollection.size()`",
            category=FutureWarning,
            stacklevel=2,
        )

        try:
            data_granule = self["umm"]["DataGranule"]
            total_size = sum(
                [
                    float(s["Size"])
                    for s in data_granule["ArchiveAndDistributionInformation"]
                    if "ArchiveAndDistributionInformation" in data_granule
                ],
            )
        except Exception:
            try:
                data_granule = self["umm"]["DataGranule"]
                total_size = sum(
                    [
                        float(s["SizeInBytes"])
                        for s in data_granule["ArchiveAndDistributionInformation"]
                        if "ArchiveAndDistributionInformation" in data_granule
                    ],
                ) / (1024 * 1024)
            except Exception:
                total_size = 0
        return total_size

    def _derive_s3_link(self, links: list[str]) -> list[str]:
        s3_links = []
        for link in links:
            if link.startswith("s3"):
                s3_links.append(link)
            elif link.startswith("https://") and (
                "cumulus" in link or "protected" in link
            ):
                s3_links.append(f"s3://{links[0].split('nasa.gov/')[1]}")
        return s3_links

    def data_links(
        self,
        access: str | None = None,
        in_region: bool = False,
    ) -> list[str]:
        """Return data links for the requested granule access mode.

        Returns the data links from a granule.

        Parameters:
            access: direct or external.
                Direct means in-region access for cloud-hosted collections.
            in_region: True if we are running in us-west-2.
                It is meant for the store class.

        Returns:
            The data links for the requested access type.
        """
        https_links = self._filter_related_links("GET DATA")
        s3_links = self._filter_related_links("GET DATA VIA DIRECT ACCESS")
        if in_region:
            # we are in us-west-2
            if self.cloud_hosted and access in (None, "direct"):
                # this is a cloud collection, and we didn't specify the access type
                # default to S3 links
                if len(s3_links) == 0 and len(https_links) > 0:
                    # This is guessing the S3 links for some cloud collections that for
                    # some reason only offered HTTPS links
                    return self._derive_s3_link(https_links)
                # we have the s3 links so we return those
                return s3_links
            # Even though we are in us-west-2, the user wants the HTTPS links used in-region.
            # They are S3 signed links from TEA.
            # <https://github.com/asfadmin/thin-egress-app>
            return https_links
        # we are not in-region
        if access == "direct":
            # maybe the user wants to collect S3 links and use them later
            # from the cloud
            return s3_links
        # we are not in us-west-2, even cloud collections have HTTPS links
        return https_links

    def dataviz_links(self) -> list[str]:
        """Return related visualization links for the granule.

        Returns:
            The data visualization links, usually the browse images.
        """
        return self._filter_related_links("GET RELATED VISUALIZATION")

    @property
    def __geo_interface__(self) -> dict[str, object]:
        """A GeoJSON representation of this granule.

        This granule must contain a `dict` value at the path
        `self["umm"]["SpatialExtent"]["HorizontalSpatialDomain"]["Geometry"]`.
        It is assumed that the `dict` contains only a single key-value pair,
        and this property is the result of converting the value of that pair
        into an equivalent GeoJSON structure, depending on the key, as follows:

        |Key                   |Value converted to GeoJSON|
        |:---------------------|:-------------------------|
        |`"Lines"`             |`"MultiLineString"`       |
        |`"Points"`            |`"MultiPoint"`            |
        |`"BoundingRectangles"`|`"MultiPolygon"`          |
        |`"GPolygons"`         |`"MultiPolygon"`          |

        Raises:
            ValueError: If this granule does not contain a value at the path
                `self["umm"]["SpatialExtent"]["HorizontalSpatialDomain"]["Geometry"]`,
                or the value there is not a `dict` containing a value for one of
                `"Points"`, `"Lines"`, `"BoundingRectangles"`, or `"GPolygons"`.

        See Also:
            - [`__geo_interface__` Specification](https://gist.github.com/sgillies/2217756)
            - [NASA UMM-G JSON Schema](https://git.earthdata.nasa.gov/projects/EMFD/repos/unified-metadata-model/browse/granule/v1.6.6/umm-g-json-schema.json)
            - [The GeoJSON Format](https://datatracker.ietf.org/doc/html/rfc7946)
        """
        try:
            geometry = self["umm"]["SpatialExtent"]["HorizontalSpatialDomain"][
                "Geometry"
            ]
        except KeyError:
            raise ValueError("Granule has no horizontal spatial extent") from None

        if "GPolygons" in geometry:
            return {
                "type": "MultiPolygon",
                "coordinates": [
                    [
                        # Outer ring (counterclockwise)
                        [
                            [point["Longitude"], point["Latitude"]]
                            for point in poly["Boundary"]["Points"]
                        ],
                        # Inner rings (clockwise)
                        *(
                            [
                                [point["Longitude"], point["Latitude"]]
                                # In UMM-G, boundary points are always counterclockwise,
                                # but GeoJSON wants inner rings to be clockwise, so we
                                # must reverse the points in ExclusiveZone Boundaries.
                                for point in reversed(boundary["Points"])
                            ]
                            # In UMM-G, ExclusiveZone is optional.
                            for boundary in poly.get("ExclusiveZone", {}).get(
                                "Boundaries",
                                [],
                            )
                        ),
                    ]
                    for poly in geometry["GPolygons"]
                ],
            }

        if "BoundingRectangles" in geometry:
            return {
                "type": "MultiPolygon",
                "coordinates": [
                    [
                        [
                            [
                                rect["WestBoundingCoordinate"],
                                rect["SouthBoundingCoordinate"],
                            ],
                            [
                                rect["EastBoundingCoordinate"],
                                rect["SouthBoundingCoordinate"],
                            ],
                            [
                                rect["EastBoundingCoordinate"],
                                rect["NorthBoundingCoordinate"],
                            ],
                            [
                                rect["WestBoundingCoordinate"],
                                rect["NorthBoundingCoordinate"],
                            ],
                            [
                                rect["WestBoundingCoordinate"],
                                rect["SouthBoundingCoordinate"],
                            ],
                        ],
                    ]
                    for rect in geometry["BoundingRectangles"]
                ],
            }

        if "Points" in geometry:
            return {
                "type": "MultiPoint",
                "coordinates": [
                    [p["Longitude"], p["Latitude"]] for p in geometry["Points"]
                ],
            }

        if "Lines" in geometry:
            return {
                "type": "MultiLineString",
                "coordinates": [
                    [[p["Longitude"], p["Latitude"]] for p in line["Points"]]
                    for line in geometry["Lines"]
                ],
            }

        msg = f"Invalid Geometry in granule's horizontal spatial extent: {geometry}"
        raise ValueError(msg)
