class LoginStrategyUnavailable(Exception):  # noqa: N818
    """The selected login strategy was skipped.

    This should be raised when a login strategy can't be attempted, for example because
    "environment" was selected but the envvars are not populated.

    DO NOT raise this exception when a login strategy is attempted and fails. For
    example, this exception would not be thrown when credentials were rejected;
    a `LoginAttemptFailure` should be thrown instead.
    """


class LoginAttemptFailure(Exception):  # noqa: N818
    """The login attempt failed.

    This should be raised when a login attempt fails, for example, because
    the user's credentials were rejected.

    DO NOT raise this exception when a login strategy can't be attempted. For
    example, this exception would not be thrown when "environment" was selected
    but the envvars are not populated; a `LoginStrategyUnavailable` should be
    thrown instead.
    """


class DownloadFailure(Exception):  # noqa: N818
    """The download attempt failed.

    This should be raised when a download attempt fails, for example, because
    the file could not be retrieved or the download process was interrupted.
    """


class ServiceOutage(Exception):  # noqa: N818
    """A service outage has been detected.

    This should be raised when Earthdata services are unavailable or experiencing
    outages that prevent normal operations.
    """


class EulaNotAccepted(DownloadFailure):
    """The user has not accepted the EULA.

    This should be raised when a user attempts to access data that requires
    EULA acceptance, but they have not accepted the EULA.
    """
