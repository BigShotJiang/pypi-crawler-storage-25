# 直接测试修改后的模块文件

# 导入模块文件
import sys
sys.path.insert(0, '.')

# 直接导入模块
from logger_main import logger, log__init__, DEBUG, INFO, WARNING, ERROR, CRITICAL
from object_constants import ObjectStateConstant

# 测试基本功能
print("Testing TrimLog modules directly...")

# 实例化 OSC
osc = ObjectStateConstant()
osc.project_name = "Test Project"
osc.version = "v0.1.2334"

# 初始化 logger
log__init__(osc)

# 测试日志输出
logger.info("This is an info message")
logger.warning("This is a warning message")
logger.error("This is an error message")

# 测试 baseinfo_shower
logger.include_release_info = True
logger.baseinfo_shower()

print("Test completed successfully!")
