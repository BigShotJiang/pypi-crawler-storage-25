# 测试本地修改后的 TrimLog 模块

# 添加当前目录到 Python 路径
import sys
sys.path.insert(0, '.')

# 导入本地 TrimLog 模块
import TrimLog
from TrimLog import object_constants
from TrimLog import log__init__, logger

# 测试基本功能
print("Testing TrimLog...")

# 实例化 OSC
osc = object_constants.ObjectStateConstant()
osc.project_name = "Test Project"
osc.version = "v0.1.2334"

# 初始化 logger
log__init__(osc)

# 测试日志输出
logger.info("This is an info message")
logger.warning("This is a warning message")
logger.error("This is an error message")

# 测试 baseinfo_shower
logger.include_release_info = True
logger.baseinfo_shower()

print("Test completed successfully!")
