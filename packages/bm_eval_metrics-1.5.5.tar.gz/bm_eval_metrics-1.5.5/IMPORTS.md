# Imports Guide

Below are the same import patterns grouped package-wise.

## 1) bm_preprocessing

```python
# Top-level section access
from bm_preprocessing import DM
from bm_preprocessing import IR
from bm_preprocessing import PY
from bm_preprocessing import Finals
from bm_preprocessing import KALKI

# Finals exports
from bm_preprocessing.Finals import kaadhal
from bm_preprocessing.Finals import raaka
from bm_preprocessing.Finals import seedan
from bm_preprocessing.Finals import vikram

# DM exports
from bm_preprocessing.DM import agg
from bm_preprocessing.DM import dbscan
from bm_preprocessing.DM import finals
from bm_preprocessing.DM import gsp
from bm_preprocessing.DM import test

# IR exports
from bm_preprocessing.IR import finals
from bm_preprocessing.IR import pagerank
from bm_preprocessing.IR import recommenders_pca
from bm_preprocessing.IR import test

# PY exports
from bm_preprocessing.PY import lib_doc
from bm_preprocessing.PY import python_doc

# KALKI exports
from bm_preprocessing.KALKI import collaborative_filtering
from bm_preprocessing.KALKI import content_based_filtering
from bm_preprocessing.KALKI import pagerank
from bm_preprocessing.KALKI import pca
from bm_preprocessing.KALKI import pca_svd
from bm_preprocessing.KALKI import svd

# Importer-layer access
from bm_preprocessing.importer.DM import agg, dbscan, finals, gsp, test
from bm_preprocessing.importer.IR import finals, pagerank, recommenders_pca, test
from bm_preprocessing.importer.PY import lib_doc, python_doc
from bm_preprocessing.importer.Finals import kaadhal, raaka, seedan, vikram
from bm_preprocessing.importer.KALKI import collaborative_filtering, content_based_filtering, pagerank, pca, pca_svd, svd
```

## 2) bm_eval_metrics

```python
# Top-level section access
from bm_eval_metrics import DM
from bm_eval_metrics import IR
from bm_eval_metrics import PY
from bm_eval_metrics import Finals
from bm_eval_metrics import KALKI

# Finals exports
from bm_eval_metrics.Finals import kaadhal
from bm_eval_metrics.Finals import raaka
from bm_eval_metrics.Finals import seedan
from bm_eval_metrics.Finals import vikram

# DM exports
from bm_eval_metrics.DM import agg
from bm_eval_metrics.DM import dbscan
from bm_eval_metrics.DM import finals
from bm_eval_metrics.DM import gsp
from bm_eval_metrics.DM import test

# IR exports
from bm_eval_metrics.IR import finals
from bm_eval_metrics.IR import pagerank
from bm_eval_metrics.IR import recommenders_pca
from bm_eval_metrics.IR import test

# PY exports
from bm_eval_metrics.PY import lib_doc
from bm_eval_metrics.PY import python_doc

# KALKI exports
from bm_eval_metrics.KALKI import collaborative_filtering
from bm_eval_metrics.KALKI import content_based_filtering
from bm_eval_metrics.KALKI import pagerank
from bm_eval_metrics.KALKI import pca
from bm_eval_metrics.KALKI import pca_svd
from bm_eval_metrics.KALKI import svd

# Importer-layer access
from bm_eval_metrics.importer.DM import agg, dbscan, finals, gsp, test
from bm_eval_metrics.importer.IR import finals, pagerank, recommenders_pca, test
from bm_eval_metrics.importer.PY import lib_doc, python_doc
from bm_eval_metrics.importer.Finals import kaadhal, raaka, seedan, vikram
from bm_eval_metrics.importer.KALKI import collaborative_filtering, content_based_filtering, pagerank, pca, pca_svd, svd
```

## 3) itertoolkit

```python
# Top-level section access
from itertoolkit import DM
from itertoolkit import IR
from itertoolkit import PY
from itertoolkit import Finals
from itertoolkit import KALKI

# Finals exports
from itertoolkit.Finals import kaadhal
from itertoolkit.Finals import raaka
from itertoolkit.Finals import seedan
from itertoolkit.Finals import vikram

# DM exports
from itertoolkit.DM import agg
from itertoolkit.DM import dbscan
from itertoolkit.DM import finals
from itertoolkit.DM import gsp
from itertoolkit.DM import test

# IR exports
from itertoolkit.IR import finals
from itertoolkit.IR import pagerank
from itertoolkit.IR import recommenders_pca
from itertoolkit.IR import test

# PY exports
from itertoolkit.PY import lib_doc
from itertoolkit.PY import python_doc

# KALKI exports
from itertoolkit.KALKI import collaborative_filtering
from itertoolkit.KALKI import content_based_filtering
from itertoolkit.KALKI import pagerank
from itertoolkit.KALKI import pca
from itertoolkit.KALKI import pca_svd
from itertoolkit.KALKI import svd

# Importer-layer access
from itertoolkit.importer.DM import agg, dbscan, finals, gsp, test
from itertoolkit.importer.IR import finals, pagerank, recommenders_pca, test
from itertoolkit.importer.PY import lib_doc, python_doc
from itertoolkit.importer.Finals import kaadhal, raaka, seedan, vikram
from itertoolkit.importer.KALKI import collaborative_filtering, content_based_filtering, pagerank, pca, pca_svd, svd
```

Example:

```python
from bm_preprocessing.Finals import raaka
```