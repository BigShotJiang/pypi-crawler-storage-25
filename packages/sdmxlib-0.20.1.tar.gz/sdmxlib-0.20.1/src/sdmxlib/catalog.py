"""FederatedCatalog — orchestrate structural metadata + bindings + data.

The headline of #47. A :class:`FederatedCatalog` composes three roles
into one query interface:

- ``structural`` — a :class:`~sdmxlib.model.registry.Registry` for DSDs,
  codelists, concept schemes (typically a federation chain spanning
  remote registries plus local cache).
- ``bindings`` — a :class:`Registry` holding
  :class:`~sdmxlib.model.binding.DataflowBinding` artefacts. Usually the
  same local store that caches structural artefacts; conceptually
  separate so users can split them.
- ``data`` — a :class:`~sdmxlib.data_store.DataStore` for observation
  rows.

The catalog runs the five-stage lifecycle from #47:

1. **Binding lookup** — derive the binding's URN from the dataflow URN
   and read it from ``bindings``.
2. **Structural resolve** — pull the dataflow (and its DSD) from
   ``structural``, used for result annotation.
3. **Filter translation** — pass user-supplied WHERE clauses through
   to the data store. (v1 uses identity column mapping; richer
   translation hooks live on the binding.)
4. **Data scan** — execute against the binding's table.
5. **Result annotation** — apply ``slpl.label`` if requested, using the
   resolved DSD to turn code columns into labels in the requested
   language.

Example:
    catalog = sl.FederatedCatalog(
        structural=fed,           # FederatedRegistry from Phase D
        bindings=local,           # holds DataflowBinding artefacts
        data=DuckDBDataStore(local, attach={"lake": "..."}),
    )
    df = catalog.query(
        sl.Dataflow.urn(agency="STATCAN", id="CENSUS_PROFILE", version="2021"),
        where=["REF_AREA = ?"],
        params=["CA"],
        lang="en",
    )
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING

import polars as pl
from attrs import frozen

from sdmxlib.model.binding import DataflowBinding
from sdmxlib.model.dataflow import Dataflow
from sdmxlib.model.datastructure import DataStructure
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.ref import Ref

if TYPE_CHECKING:
    import pyarrow as pa

    from sdmxlib.data_store import DataStore
    from sdmxlib.model.registry import Registry
    from sdmxlib.model.urn import SdmxUrn
    from sdmxlib.rest import ComponentFilter


@frozen
class DataflowEntry:
    """One row of a :meth:`FederatedCatalog.browse` result.

    Attributes:
        dataflow_urn: URN of the bound dataflow.
        binding: The :class:`DataflowBinding` that links the dataflow to
            its observation table. Always present for v1 (browse only
            enumerates locally-bound dataflows).
        name: The dataflow's :class:`InternationalString` name when the
            structural side resolves the dataflow; ``None`` otherwise.
        source_registry: Provenance label from the binding —
            ``"local"`` for locally-authored, ``"ESTAT"`` /
            ``"ECB"`` / ... for remote-cached.
    """

    dataflow_urn: SdmxUrn[Dataflow]
    binding: DataflowBinding
    name: InternationalString | None
    source_registry: str | None


class FederatedCatalog:
    """Orchestrator that ties structural metadata + bindings + data together.

    Users see a single ``query(dataflow_urn, ...)`` entry point; the
    catalog does the binding lookup, DSD resolution, scan, and labelling
    behind the scenes.

    Args:
        structural: Registry that resolves DSDs, codelists, and the
            dataflow itself.
        bindings: Registry that holds :class:`DataflowBinding` artefacts.
            May be the same instance as ``structural`` (common: a local
            DuckDB store hosts both).
        data: :class:`DataStore` for the observation plane.
    """

    def __init__(
        self,
        *,
        structural: Registry,
        bindings: Registry,
        data: DataStore,
    ) -> None:
        self._structural = structural
        self._bindings = bindings
        self._data = data

    @property
    def structural(self) -> Registry:
        """The structural-side registry (DSDs, codelists, dataflows)."""
        return self._structural

    @property
    def bindings(self) -> Registry:
        """The registry holding :class:`DataflowBinding` artefacts."""
        return self._bindings

    @property
    def data(self) -> DataStore:
        """The data plane."""
        return self._data

    # ── Query lifecycle ──────────────────────────────────────────────────

    def query(
        self,
        dataflow_urn: SdmxUrn[Dataflow],
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        limit: int | None = None,
        with_labels: bool = False,
        lang: str | None = None,
    ) -> pl.DataFrame:
        """Run the five-stage query lifecycle for ``dataflow_urn``.

        Args:
            dataflow_urn: The dataflow whose observations to read. The
                catalog derives the binding URN from this and reads it
                from ``bindings``.
            where: Optional list of SQL WHERE-clause fragments.
            params: Positional parameters for the WHERE clauses.
            component_filter: Optional :class:`~sdmxlib.rest.ComponentFilter`
                parsed from an SDMX REST dotted key plus ``c[...]=...``
                query params. ANDed with ``where`` after translation via
                the binding's dimension and attribute column maps.
            columns: Optional column projection.
            order_by: Optional SQL ORDER BY clause.
            limit: Optional row cap.
            with_labels: When ``True``, attach human-readable label
                columns to enumerated dimensions/attributes via
                ``slpl.label``. Requires ``lang``.
            lang: BCP47 tag for label localisation. Required when
                ``with_labels=True``; otherwise ignored.

        Returns:
            A Polars DataFrame, optionally label-augmented.

        Raises:
            KeyError: If no binding exists for ``dataflow_urn``.
            TypeError: If ``with_labels=True`` but ``lang`` is missing.
        """
        # Stage 1 — Binding lookup
        binding_urn = DataflowBinding.urn(
            agency=dataflow_urn.agency,
            id=dataflow_urn.id,
            version=dataflow_urn.version,
        )
        binding = self._bindings.get(binding_urn)
        if binding is None:
            err = f"No DataflowBinding found for {dataflow_urn}. Add a binding to the bindings registry first."
            raise KeyError(err)
        if not isinstance(binding, DataflowBinding):
            err = f"Expected DataflowBinding for {binding_urn}, got {type(binding).__name__}"
            raise TypeError(err)

        # Stage 2 — Structural resolve (only needed for labelling)
        dsd: DataStructure | None = None
        if with_labels:
            if lang is None:
                err = "lang is required when with_labels=True — there is no default."
                raise TypeError(err)
            dsd = self._resolve_dsd(dataflow_urn, binding)

        # Stages 3 & 4 — Data scan
        df = self._data.query(
            binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            limit=limit,
        )

        # Stage 5 — Result annotation
        if with_labels and dsd is not None and len(df) > 0:
            from sdmxlib import polars as slpl  # noqa: PLC0415  # lazy: only when labelling

            # Narrow: ``lang`` is non-None here — guarded by the with_labels
            # branch above, which raises TypeError when lang is missing.
            assert lang is not None  # noqa: S101
            df = slpl.label(df.lazy(), dsd, lang=lang).collect()

        return df

    def query_stream(
        self,
        dataflow_urn: SdmxUrn[Dataflow],
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        chunk_rows: int = 10_000,
    ) -> Iterator[pa.RecordBatch]:
        """Stream observations as Arrow record batches.

        Mirrors :meth:`query` (binding lookup → scan) but skips the
        labelling step — labels are a DataFrame transform that doesn't
        compose cleanly with streaming. Callers that need labelled
        streaming output should join codelists themselves on the way to
        their sink.

        Args:
            dataflow_urn: As :meth:`query`.
            where: As :meth:`query`.
            params: As :meth:`query`.
            component_filter: As :meth:`query`.
            columns: As :meth:`query`.
            order_by: As :meth:`query`.
            chunk_rows: Target rows per emitted record batch.

        Yields:
            One :class:`pyarrow.RecordBatch` at a time, in scan order.

        Raises:
            KeyError: If no binding exists for ``dataflow_urn``.
        """
        binding_urn = DataflowBinding.urn(
            agency=dataflow_urn.agency,
            id=dataflow_urn.id,
            version=dataflow_urn.version,
        )
        binding = self._bindings.get(binding_urn)
        if binding is None:
            err = f"No DataflowBinding found for {dataflow_urn}. Add a binding to the bindings registry first."
            raise KeyError(err)
        if not isinstance(binding, DataflowBinding):
            err = f"Expected DataflowBinding for {binding_urn}, got {type(binding).__name__}"
            raise TypeError(err)
        yield from self._data.query_stream(
            binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            chunk_rows=chunk_rows,
        )

    def browse(self) -> list[DataflowEntry]:
        """Enumerate every locally-bound dataflow with provenance annotations.

        v1 lists dataflows that have a :class:`DataflowBinding` in
        ``bindings``. Each entry carries the binding plus the dataflow's
        resolved ``name`` if the structural side knows it. Remote-only
        dataflows (registered upstream but not bound locally) are not
        listed in v1 — that requires a richer Registry-protocol API for
        cross-source enumeration; deferred.

        Returns:
            One :class:`DataflowEntry` per binding, sorted by dataflow URN.

        Raises:
            TypeError: If the ``bindings`` registry doesn't support
                enumeration (no ``get_all`` method). All built-in
                registries do.
        """
        get_all = getattr(self._bindings, "get_all", None)
        if get_all is None:
            err = (
                f"bindings registry {type(self._bindings).__name__} does not "
                "support enumeration via get_all(DataflowBinding); browse() "
                "needs a registry that can list its DataflowBindings."
            )
            raise TypeError(err)
        bindings: list[DataflowBinding] = list(get_all(DataflowBinding))

        entries: list[DataflowEntry] = []
        for binding in bindings:
            flow = self._structural.get(binding.dataflow.urn)
            name = flow.name if isinstance(flow, Dataflow) else None
            entries.append(
                DataflowEntry(
                    dataflow_urn=binding.dataflow.urn,
                    binding=binding,
                    name=name,
                    source_registry=binding.source_registry,
                ),
            )
        entries.sort(key=lambda e: str(e.dataflow_urn))
        return entries

    def binding_for(self, dataflow_urn: SdmxUrn[Dataflow]) -> DataflowBinding | None:
        """Look up the binding associated with ``dataflow_urn``, or ``None``."""
        binding_urn = DataflowBinding.urn(
            agency=dataflow_urn.agency,
            id=dataflow_urn.id,
            version=dataflow_urn.version,
        )
        binding = self._bindings.get(binding_urn)
        return binding if isinstance(binding, DataflowBinding) else None

    # ── Internals ────────────────────────────────────────────────────────

    def _resolve_dsd(
        self,
        dataflow_urn: SdmxUrn[Dataflow],
        binding: DataflowBinding,
    ) -> DataStructure | None:
        """Best-effort resolution of the DSD for label annotation.

        Fetches the dataflow to learn the DSD URN, then fetches the DSD
        by URN directly. This second lookup is important: it triggers
        the registry's nested-Ref resolver on the DSD itself so that
        each dimension's ``representation: Ref[Codelist]`` is resolved
        — without that, ``slpl.label`` skips the column.

        Returns ``None`` if the DSD can't be resolved; the caller treats
        that as "labelling unavailable" rather than a hard error.
        """
        del binding  # may carry version hints in future; unused in v1
        flow = self._structural.get(dataflow_urn)
        if flow is None or not isinstance(flow, Dataflow) or flow.structure is None:
            return None
        structure_ref = flow.structure
        if not isinstance(structure_ref, Ref):
            return None
        # Fetch the DSD by URN so its nested Refs (codelist representations,
        # concept identities) get resolved by the registry's walker.
        dsd = self._structural.get(structure_ref.urn)
        return dsd if isinstance(dsd, DataStructure) else None

    def __repr__(self) -> str:
        return (
            f"FederatedCatalog(structural={type(self._structural).__name__}, "
            f"bindings={type(self._bindings).__name__}, "
            f"data={type(self._data).__name__})"
        )


__all__ = ["DataflowEntry", "FederatedCatalog"]
