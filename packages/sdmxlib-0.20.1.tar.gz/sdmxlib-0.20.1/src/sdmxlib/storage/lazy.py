"""LazyCodelist — DuckDB-backed lazy code access.

Codes are exposed via :class:`sdmxlib.model.code_query.CodeQuery`, a
lazy SKOS/XKOS-aligned query type. Hierarchy navigation
(``roots``, ``leaves``, ``narrower``, ``narrower_transitive``,
``broader``, ``broader_transitive``, ``depth_of``) compiles to a single
SQL statement against ``sdmx.code``.
"""

import duckdb

from sdmxlib.model.code_query import (
    CodeQuery,
    _HasAncestor,
    _HasNoNarrower,
    _IsAncestorOf,
    code,
)
from sdmxlib.model.codelist import Code, Codelist
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency


def _map_to_istring(m: dict[str, str] | None) -> InternationalString:
    if not m:
        return InternationalString()
    return InternationalString.of(m)


class LazyCodelist:
    """Codelist facade backed by DuckDB.

    Duck-types as ``Codelist`` for read operations. ``codes`` returns a
    :class:`CodeQuery` for SQL-pushed filtering and hierarchy navigation.
    """

    __slots__ = (
        "__weakref__",  # required so slpl.label's per-codelist cache can hold a weakref
        "_agency",
        "_conn",
        "_description",
        "_id",
        "_is_final",
        "_name",
        "_urn",
        "_version",
    )

    def __init__(
        self,
        *,
        urn: str,
        conn: duckdb.DuckDBPyConnection,
        id: str,  # noqa: A002
        agency: Agency,
        version: str,
        name: InternationalString,
        description: InternationalString,
        is_final: bool,
    ) -> None:
        self._urn = urn
        self._conn = conn
        self._id = id
        self._agency = agency
        self._version = version
        self._name = name
        self._description = description
        self._is_final = is_final

    # ── MaintainableArtefact-compatible properties ────────────────────────

    @property
    def id(self) -> str:  # noqa: D102
        return self._id

    @property
    def maintainer(self) -> Agency:  # noqa: D102
        return self._agency

    @property
    def agency_id(self) -> str:  # noqa: D102
        return self._agency.id

    @property
    def version(self) -> str:  # noqa: D102
        return self._version

    @property
    def name(self) -> InternationalString:  # noqa: D102
        return self._name

    @property
    def description(self) -> InternationalString:  # noqa: D102
        return self._description

    @property
    def is_final(self) -> bool:  # noqa: D102
        return self._is_final

    # ── SDMX class vars ──────────────────────────────────────────────────

    sdmx_package = "codelist"
    sdmx_class = "Codelist"

    # ── Code access (Layer 2: CodeQuery-returning) ───────────────────────

    @property
    def codes(self) -> CodeQuery:
        """All codes as a lazy :class:`CodeQuery`."""
        return CodeQuery(codelist_urn=self._urn, conn=self._conn)

    def __len__(self) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM sdmx.code WHERE codelist_urn = ?",
            [self._urn],
        ).fetchone()
        return row[0] if row else 0  # type: ignore[index]

    def __contains__(self, key: object) -> bool:
        return key in self.codes

    def __getitem__(self, key: str | int) -> Code:
        return self.codes[key]

    # ── SKOS/XKOS hierarchy navigation ──────────────────────────────────

    def roots(self) -> CodeQuery:
        """Top-level codes (``broader IS NULL``)."""
        return self.codes.filter(code.parent_id.is_null())

    def leaves(self) -> CodeQuery:
        """Codes that no other code names as parent."""
        return self.codes.filter(_HasNoNarrower())

    def narrower(self, code_id: str) -> CodeQuery:
        """Direct children of ``code_id``."""
        return self.codes.filter(code.parent_id == code_id)

    def broader(self, code_id: str) -> Code | None:
        """Direct parent of ``code_id`` — at most one. Returns ``None`` for roots."""
        row = self._conn.execute(
            """
            SELECT parent.code_id, parent.parent_id, parent.depth, parent.name,
                   parent.code_urn, parent.description
            FROM sdmx.code child
            LEFT JOIN sdmx.code parent
              ON parent.codelist_urn = child.codelist_urn
             AND parent.code_id = child.parent_id
            WHERE child.codelist_urn = ?
              AND child.code_id = ?
            """,
            [self._urn, code_id],
        ).fetchone()
        if row is None or row[0] is None:
            return None
        from sdmxlib.model.annotations import Annotations  # noqa: PLC0415
        from sdmxlib.model.code_query import _fetch_annotations_for, _row_to_code  # noqa: PLC0415

        anns = _fetch_annotations_for(self._conn, [row[4]]).get(row[4], Annotations())
        return _row_to_code(row, anns)

    def narrower_transitive(self, code_id: str, *, depth: int | None = None) -> CodeQuery:
        """All descendants of ``code_id``.

        When ``depth`` is set, the query is bounded to ``depth`` hops; the
        starting code's absolute depth is fetched once so the SQL becomes
        a literal-int comparison.
        """
        max_absolute = None
        if depth is not None:
            max_absolute = self.depth_of(code_id) + depth
        return self.codes.filter(_HasAncestor(ancestor_id=code_id, max_absolute_depth=max_absolute))

    def broader_transitive(self, code_id: str, *, depth: int | None = None) -> CodeQuery:
        """All ancestors of ``code_id``.

        When ``depth`` is set, the query is bounded to ``depth`` hops.
        """
        min_absolute = None
        if depth is not None:
            min_absolute = self.depth_of(code_id) - depth
        return self.codes.filter(_IsAncestorOf(descendant_id=code_id, min_absolute_depth=min_absolute))

    def depth_of(self, code_id: str) -> int:
        """Depth of ``code_id`` in the codelist hierarchy (root = 0)."""
        row = self._conn.execute(
            "SELECT depth FROM sdmx.code WHERE codelist_urn = ? AND code_id = ?",
            [self._urn, code_id],
        ).fetchone()
        if row is None:
            msg = f"Code {code_id!r} not found in codelist {self._urn!r}"
            raise KeyError(msg)
        return int(row[0]) if row[0] is not None else 0

    # ── Direct SQL helpers ───────────────────────────────────────────────

    def code_map(self, *, lang: str) -> dict[str, str]:
        """Direct SQL: ``{code_id: label}`` without creating Code objects."""
        from sdmxlib.storage.readers import code_map  # noqa: PLC0415

        return code_map(self._conn, self._urn, lang=lang)

    def materialize(self) -> Codelist:
        """Load all codes and return a real :class:`Codelist`."""
        codes = self.codes.collect()
        return Codelist(
            id=self._id,
            maintainer=self._agency,
            version=self._version,
            name=self._name,
            description=self._description,
            is_final=self._is_final,
            codes=codes,
        )

    def __repr__(self) -> str:
        return f"LazyCodelist(id={self._id!r}, agency={self.agency_id!r}, codes=~{len(self)})"


__all__ = ["LazyCodelist"]
