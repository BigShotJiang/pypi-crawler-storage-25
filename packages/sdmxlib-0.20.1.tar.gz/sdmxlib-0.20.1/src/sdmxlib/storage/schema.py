"""DuckDB schema for SDMX structural metadata (v2 — pure relational).

All tables live in the ``sdmx`` DuckDB schema.  Item tables use
``MAP(VARCHAR, VARCHAR)`` columns for multilingual labels — no upfront
language config, no DDL migration.  Artefact-level text uses a
``localized_text`` table.

Example::

    import duckdb
    from sdmxlib.storage.schema import create_schema

    conn = duckdb.connect("store.duckdb")
    cursor = create_schema(conn)
    # cursor has search_path = 'sdmx'
"""

import duckdb

SCHEMA_VERSION = "2.0"


# ── DDL ─────────────────────────────────────────────────────────────────

_DDL = """\
-- Schema creation
CREATE SCHEMA IF NOT EXISTS sdmx;
SET search_path = 'sdmx';

-- Schema version tracking
CREATE TABLE IF NOT EXISTS _meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- ── Layer 1: Catalogue spine ────────────────────────────────────────

CREATE TABLE IF NOT EXISTS artefact (
    urn             TEXT PRIMARY KEY,
    artefact_type   TEXT NOT NULL,
    agency_id       TEXT NOT NULL,
    resource_id     TEXT NOT NULL,
    version         TEXT NOT NULL DEFAULT '1.0',
    is_final        BOOLEAN NOT NULL DEFAULT FALSE,
    is_external_ref BOOLEAN NOT NULL DEFAULT FALSE,
    valid_from      TIMESTAMP,
    valid_to        TIMESTAMP,
    source_registry TEXT,
    fetched_at      TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_artefact_type
    ON artefact(artefact_type);
CREATE INDEX IF NOT EXISTS idx_artefact_agency_id
    ON artefact(agency_id, resource_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_artefact_identity
    ON artefact(artefact_type, agency_id, resource_id, version);

-- ── Layer 2: Multilingual text ──────────────────────────────────────

CREATE TABLE IF NOT EXISTS localized_text (
    owner_urn   TEXT NOT NULL,
    field       TEXT NOT NULL,
    lang        TEXT NOT NULL,
    text        TEXT NOT NULL,
    PRIMARY KEY (owner_urn, field, lang)
);

CREATE INDEX IF NOT EXISTS idx_lt_owner ON localized_text(owner_urn);

-- ── Layer 3: Annotations ────────────────────────────────────────────

CREATE SEQUENCE IF NOT EXISTS annotation_id_seq;

CREATE TABLE IF NOT EXISTS annotation (
    id              BIGINT PRIMARY KEY DEFAULT nextval('annotation_id_seq'),
    owner_urn       TEXT NOT NULL,
    ordinal         INT NOT NULL,
    annotation_id   TEXT,
    title           TEXT,
    annotation_type TEXT,
    url             TEXT
);

CREATE INDEX IF NOT EXISTS idx_ann_owner ON annotation(owner_urn);
CREATE INDEX IF NOT EXISTS idx_ann_type ON annotation(annotation_type);
CREATE INDEX IF NOT EXISTS idx_ann_type_owner
    ON annotation(annotation_type, owner_urn);

CREATE TABLE IF NOT EXISTS annotation_text (
    annotation_id   BIGINT NOT NULL,
    lang            TEXT NOT NULL,
    text            TEXT NOT NULL,
    PRIMARY KEY (annotation_id, lang)
);

-- ── Layer 4: Reference graph ────────────────────────────────────────

CREATE TABLE IF NOT EXISTS artefact_ref (
    source_urn   TEXT NOT NULL,
    target_urn   TEXT NOT NULL,
    role         TEXT NOT NULL,
    ordinal      INT,
    PRIMARY KEY (source_urn, target_urn, role)
);

CREATE INDEX IF NOT EXISTS idx_ref_target ON artefact_ref(target_urn);
CREATE INDEX IF NOT EXISTS idx_ref_role ON artefact_ref(role);

-- ── Layer 5: Item tables (columnar) ─────────────────────────────────

CREATE TABLE IF NOT EXISTS code (
    code_urn        TEXT PRIMARY KEY,
    codelist_urn    TEXT NOT NULL,
    code_id         TEXT NOT NULL,
    parent_id       TEXT,
    position        INT,
    name            MAP(VARCHAR, VARCHAR),
    description     MAP(VARCHAR, VARCHAR),
    depth           SMALLINT NOT NULL DEFAULT 0,
    ancestor_ids    TEXT[],
    UNIQUE (codelist_urn, code_id)
);

CREATE INDEX IF NOT EXISTS idx_code_codelist ON code(codelist_urn);
CREATE INDEX IF NOT EXISTS idx_code_parent ON code(codelist_urn, parent_id);

CREATE TABLE IF NOT EXISTS concept (
    concept_urn     TEXT PRIMARY KEY,
    scheme_urn      TEXT NOT NULL,
    concept_id      TEXT NOT NULL,
    parent_id       TEXT,
    position        INT,
    name            MAP(VARCHAR, VARCHAR),
    description     MAP(VARCHAR, VARCHAR),
    repr_kind       TEXT,
    repr_codelist_urn TEXT,
    repr_text_type  TEXT,
    repr_min_length INT,
    repr_max_length INT,
    UNIQUE (scheme_urn, concept_id)
);

CREATE INDEX IF NOT EXISTS idx_concept_scheme ON concept(scheme_urn);

CREATE TABLE IF NOT EXISTS category (
    category_urn    TEXT PRIMARY KEY,
    scheme_urn      TEXT NOT NULL,
    category_id     TEXT NOT NULL,
    parent_id       TEXT,
    position        INT,
    name            MAP(VARCHAR, VARCHAR),
    description     MAP(VARCHAR, VARCHAR),
    depth           SMALLINT NOT NULL DEFAULT 0,
    ancestor_ids    TEXT[],
    UNIQUE (scheme_urn, category_id)
);

CREATE INDEX IF NOT EXISTS idx_category_scheme ON category(scheme_urn);

CREATE TABLE IF NOT EXISTS agency (
    agency_urn      TEXT PRIMARY KEY,
    scheme_urn      TEXT NOT NULL,
    agency_id       TEXT NOT NULL,
    parent_id       TEXT,
    name            MAP(VARCHAR, VARCHAR),
    description     MAP(VARCHAR, VARCHAR),
    UNIQUE (scheme_urn, agency_id)
);

CREATE INDEX IF NOT EXISTS idx_agency_scheme ON agency(scheme_urn);

CREATE SEQUENCE IF NOT EXISTS agency_contact_id_seq;

CREATE TABLE IF NOT EXISTS agency_contact (
    id              BIGINT PRIMARY KEY DEFAULT nextval('agency_contact_id_seq'),
    agency_urn      TEXT NOT NULL,
    ordinal         INT NOT NULL,
    contact_name    MAP(VARCHAR, VARCHAR),
    department      MAP(VARCHAR, VARCHAR),
    role            MAP(VARCHAR, VARCHAR),
    phones          TEXT[],
    uris            TEXT[],
    emails          TEXT[]
);

CREATE INDEX IF NOT EXISTS idx_contact_agency ON agency_contact(agency_urn);

CREATE TABLE IF NOT EXISTS data_provider (
    provider_urn    TEXT PRIMARY KEY,
    scheme_urn      TEXT NOT NULL,
    provider_id     TEXT NOT NULL,
    name            MAP(VARCHAR, VARCHAR),
    description     MAP(VARCHAR, VARCHAR),
    UNIQUE (scheme_urn, provider_id)
);

CREATE INDEX IF NOT EXISTS idx_provider_scheme ON data_provider(scheme_urn);

-- ── Layer 6: Snowflake arms (structure tables) ──────────────────────

CREATE TABLE IF NOT EXISTS dsd_component (
    dsd_urn          TEXT NOT NULL,
    component_id     TEXT NOT NULL,
    component_type   TEXT NOT NULL,
    position         INT,
    concept_urn      TEXT,
    repr_kind        TEXT,
    codelist_urn     TEXT,
    text_type        TEXT,
    min_length       INT,
    max_length       INT,
    min_value        DOUBLE,
    max_value        DOUBLE,
    decimals         SMALLINT,
    pattern          TEXT,
    is_sequence      BOOLEAN,
    start_value      DOUBLE,
    end_value        DOUBLE,
    usage_status     TEXT,
    attachment_level TEXT,
    attachment_group TEXT,
    measure_usage    TEXT,
    PRIMARY KEY (dsd_urn, component_id)
);

CREATE INDEX IF NOT EXISTS idx_dsd_comp_codelist
    ON dsd_component(codelist_urn);

CREATE TABLE IF NOT EXISTS dsd_group (
    dsd_urn     TEXT NOT NULL,
    group_id    TEXT NOT NULL,
    PRIMARY KEY (dsd_urn, group_id)
);

CREATE TABLE IF NOT EXISTS group_dimension (
    dsd_urn      TEXT NOT NULL,
    group_id     TEXT NOT NULL,
    dimension_id TEXT NOT NULL,
    PRIMARY KEY (dsd_urn, group_id, dimension_id)
);

-- ── Layer 7: Type extension tables ──────────────────────────────────

CREATE TABLE IF NOT EXISTS dataflow (
    urn         TEXT PRIMARY KEY,
    dsd_urn     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS provision_agreement (
    urn              TEXT PRIMARY KEY,
    dataflow_urn     TEXT NOT NULL,
    data_provider_urn TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS categorisation (
    urn             TEXT PRIMARY KEY,
    source_urn      TEXT NOT NULL,
    target_urn      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS hierarchy_meta (
    urn             TEXT PRIMARY KEY,
    is_leveled      BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS hierarchy_level (
    hierarchy_urn   TEXT NOT NULL,
    level_id        TEXT NOT NULL,
    level_idx       SMALLINT NOT NULL,
    name            MAP(VARCHAR, VARCHAR),
    description     MAP(VARCHAR, VARCHAR),
    PRIMARY KEY (hierarchy_urn, level_id)
);

CREATE TABLE IF NOT EXISTS hierarchy_node (
    node_urn        TEXT PRIMARY KEY,
    hierarchy_urn   TEXT NOT NULL,
    node_id         TEXT NOT NULL,
    parent_node_id  TEXT,
    code_urn        TEXT,
    level_id        TEXT,
    name            MAP(VARCHAR, VARCHAR),
    description     MAP(VARCHAR, VARCHAR),
    valid_from      TIMESTAMP,
    valid_to        TIMESTAMP,
    depth           SMALLINT NOT NULL DEFAULT 0,
    ancestor_ids    TEXT[],
    UNIQUE (hierarchy_urn, node_id)
);

CREATE INDEX IF NOT EXISTS idx_hnode_hierarchy
    ON hierarchy_node(hierarchy_urn);
CREATE INDEX IF NOT EXISTS idx_hnode_parent
    ON hierarchy_node(hierarchy_urn, parent_node_id);

-- ── Layer 7b: Metadata Structure (MSD) tables ───────────────────────

CREATE TABLE IF NOT EXISTS metadata_structure (
    urn TEXT PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS metadata_attribute (
    attribute_urn        TEXT PRIMARY KEY,
    msd_urn              TEXT NOT NULL,
    attribute_id         TEXT NOT NULL,
    parent_attribute_id  TEXT,
    position             INT,
    concept_urn          TEXT,
    repr_kind            TEXT,
    codelist_urn         TEXT,
    text_type            TEXT,
    min_length           INT,
    max_length           INT,
    min_value            DOUBLE,
    max_value            DOUBLE,
    decimals             SMALLINT,
    pattern              TEXT,
    is_sequence          BOOLEAN,
    start_value          DOUBLE,
    end_value            DOUBLE,
    min_occurs           INT NOT NULL DEFAULT 0,
    max_occurs           INT,
    is_presentational    BOOLEAN NOT NULL DEFAULT FALSE,
    depth                SMALLINT NOT NULL DEFAULT 0,
    ancestor_ids         TEXT[],
    UNIQUE (msd_urn, attribute_id)
);

CREATE INDEX IF NOT EXISTS idx_md_attr_msd ON metadata_attribute(msd_urn);
CREATE INDEX IF NOT EXISTS idx_md_attr_parent
    ON metadata_attribute(msd_urn, parent_attribute_id);

CREATE TABLE IF NOT EXISTS metadataflow (
    urn      TEXT PRIMARY KEY,
    msd_urn  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS metadata_set (
    urn            TEXT PRIMARY KEY,
    structure_urn  TEXT NOT NULL,
    structure_kind TEXT NOT NULL DEFAULT 'MetadataStructure'
);

CREATE TABLE IF NOT EXISTS metadata_target (
    set_urn     TEXT NOT NULL,
    ordinal     INT NOT NULL,
    target_urn  TEXT NOT NULL,
    PRIMARY KEY (set_urn, ordinal)
);

CREATE INDEX IF NOT EXISTS idx_md_target_set ON metadata_target(set_urn);
CREATE INDEX IF NOT EXISTS idx_md_target_urn ON metadata_target(target_urn);

-- ── Layer 7c: DataflowBinding (Parquet/DuckLake binding artefact) ───
--
-- One row per binding; the binding's URN mirrors the bound dataflow's
-- identity (one binding per dataflow per version, v1).

CREATE TABLE IF NOT EXISTS dataflow_binding (
    urn                          TEXT PRIMARY KEY,
    dataflow_urn                 TEXT NOT NULL,
    table_location               TEXT NOT NULL,
    partition_layout             TEXT[],
    dimension_column_map         MAP(VARCHAR, VARCHAR),
    measure_column_map           MAP(VARCHAR, VARCHAR),
    attribute_column_map         MAP(VARCHAR, VARCHAR),
    structural_version           TEXT NOT NULL,
    binding_source_registry      TEXT NOT NULL,
    -- TIMESTAMPs are stored naive; convention is UTC (matches the spine
    -- valid_from / valid_to columns; using TIMESTAMPTZ would force pytz
    -- as a hard dependency).
    materialized_at              TIMESTAMP NOT NULL,
    bound_at                     TIMESTAMP NOT NULL,
    series_attributes_location   TEXT
);

CREATE INDEX IF NOT EXISTS idx_binding_dataflow
    ON dataflow_binding(dataflow_urn);

CREATE TABLE IF NOT EXISTS metadata_value (
    -- One row per (set, attribute_path, sibling_index).
    -- attribute_path is the dotted hierarchical attribute id (e.g.
    -- "QUALITY.COVERAGE"); sibling_index disambiguates repeated
    -- ReportedAttributes with the same id (max_occurs > 1 in the MSD).
    -- value_kind is 'scalar' | 'i18n' (XHTML is i18n with HTML markup,
    -- distinguished only by the MSD's data type at the application layer).
    set_urn         TEXT NOT NULL,
    attribute_path  TEXT NOT NULL,
    sibling_index   INT NOT NULL,
    value_kind      TEXT,
    scalar          TEXT,
    i18n            MAP(VARCHAR, VARCHAR),
    PRIMARY KEY (set_urn, attribute_path, sibling_index)
);

CREATE INDEX IF NOT EXISTS idx_md_value_set ON metadata_value(set_urn);

-- ── Layer 8: Constraint tables ──────────────────────────────────────

CREATE TABLE IF NOT EXISTS data_constraint (
    urn              TEXT PRIMARY KEY,
    constraint_type  TEXT NOT NULL DEFAULT 'Allowed'
);

CREATE TABLE IF NOT EXISTS cube_region (
    constraint_urn  TEXT NOT NULL,
    region_idx      INT NOT NULL,
    is_included     BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (constraint_urn, region_idx)
);

CREATE TABLE IF NOT EXISTS region_key_value (
    constraint_urn  TEXT NOT NULL,
    region_idx      INT NOT NULL,
    component_id    TEXT NOT NULL,
    value           TEXT NOT NULL,
    PRIMARY KEY (constraint_urn, region_idx, component_id, value)
);

CREATE INDEX IF NOT EXISTS idx_rkv_component
    ON region_key_value(component_id);

-- ── Layer 9: Mapping tables ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS structure_set (
    urn             TEXT PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS codelist_map (
    id                  TEXT NOT NULL,
    structure_set_urn   TEXT NOT NULL,
    source_codelist_urn TEXT NOT NULL,
    target_codelist_urn TEXT NOT NULL,
    PRIMARY KEY (structure_set_urn, id)
);

CREATE TABLE IF NOT EXISTS code_map_entry (
    structure_set_urn TEXT NOT NULL,
    map_id            TEXT NOT NULL,
    source_code_id    TEXT NOT NULL,
    target_code_id    TEXT NOT NULL,
    PRIMARY KEY (structure_set_urn, map_id, source_code_id, target_code_id)
);

CREATE INDEX IF NOT EXISTS idx_cme_source ON code_map_entry(source_code_id);
"""


# ── All table names (for introspection / testing) ───────────────────

ALL_TABLES: frozenset[str] = frozenset(
    {
        "_meta",
        "artefact",
        "localized_text",
        "annotation",
        "annotation_text",
        "artefact_ref",
        "code",
        "concept",
        "category",
        "agency",
        "agency_contact",
        "data_provider",
        "dsd_component",
        "dsd_group",
        "group_dimension",
        "dataflow",
        "provision_agreement",
        "categorisation",
        "hierarchy_meta",
        "hierarchy_level",
        "hierarchy_node",
        "data_constraint",
        "cube_region",
        "region_key_value",
        "structure_set",
        "codelist_map",
        "code_map_entry",
        "metadata_structure",
        "metadata_attribute",
        "metadataflow",
        "metadata_set",
        "metadata_target",
        "metadata_value",
        "dataflow_binding",
    }
)


# ── Public API ──────────────────────────────────────────────────────


def create_schema(conn: duckdb.DuckDBPyConnection) -> duckdb.DuckDBPyConnection:
    """Create the ``sdmx`` schema and all tables.

    Returns a **cursor** with ``search_path = 'sdmx'`` set.  All
    subsequent SQL on this cursor resolves to ``sdmx.*`` without
    explicit schema qualification.

    Idempotent — safe to call on an already-initialised database.
    """
    cursor = conn.cursor()
    cursor.execute("CREATE SCHEMA IF NOT EXISTS sdmx")
    cursor.execute("SET search_path = 'sdmx'")

    # Execute DDL — strip SQL comments before splitting on semicolons
    cleaned = "\n".join(line for line in _DDL.splitlines() if not line.lstrip().startswith("--"))
    for stmt in cleaned.split(";"):
        stripped = stmt.strip()
        if stripped:
            cursor.execute(stripped)

    # Upsert schema version
    cursor.execute(
        """
        INSERT OR REPLACE INTO _meta (key, value)
        VALUES ('schema_version', $ver)
    """,
        {"ver": SCHEMA_VERSION},
    )

    return cursor


def schema_exists(conn: duckdb.DuckDBPyConnection) -> bool:
    """Check whether the ``sdmx`` schema has been created."""
    try:
        conn.execute("SELECT 1 FROM sdmx._meta LIMIT 1")
    except duckdb.CatalogException:
        return False
    else:
        return True


def get_schema_version(conn: duckdb.DuckDBPyConnection) -> str | None:
    """Read the schema version from ``sdmx._meta``.

    Returns ``None`` if the schema doesn't exist or the version key
    is missing.
    """
    try:
        row = conn.execute("""
            SELECT value FROM sdmx._meta WHERE key = 'schema_version'
        """).fetchone()
    except duckdb.CatalogException:
        return None
    return row[0] if row else None


def migrate(conn: duckdb.DuckDBPyConnection) -> duckdb.DuckDBPyConnection:
    """Drop and rebuild the ``sdmx`` schema.

    This is a cache — the migration strategy is *drop and rebuild*.
    Users repopulate from remote registries.

    Returns a fresh cursor with ``search_path = 'sdmx'``.
    """
    conn.execute("DROP SCHEMA IF EXISTS sdmx CASCADE")
    return create_schema(conn)
