"""DuckDBDataStore — DuckDB-backed implementation of :class:`DataStore`.

Wraps a :class:`~sdmxlib.local.LocalRegistry`'s connection so the SDMX
structural side and the data side share a single DuckDB session.
External catalogs (DuckLake, raw Parquet, S3 via httpfs) can be
``ATTACH``-ed at construction so cross-database joins work without
file-handle juggling.

Generalises the cenprof-ai
``census/query/connection.py:query_session`` +
``census/query/engine.py:execute_observation_query`` pattern. Once
this lands, cenprof's bespoke engine becomes a 4-line catalog setup.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING

import polars as pl

from sdmxlib.model.binding import DataflowBinding

if TYPE_CHECKING:
    import duckdb
    import pyarrow as pa

    from sdmxlib.local._registry import LocalRegistry
    from sdmxlib.rest import ComponentFilter


class DuckDBDataStore:
    """A :class:`~sdmxlib.data_store.DataStore` backed by DuckDB.

    Shares its connection with a :class:`LocalRegistry` so the SDMX
    structural side and the observation side both live in the same
    DuckDB session — lazy codelists keep working across queries, and
    queries can join across the two without cross-connection plumbing.

    Args:
        registry: The :class:`LocalRegistry` whose connection to share.
            The registry owns the connection's lifecycle; this store
            does not close it.
        attach: Optional mapping of ``alias → DuckDB ATTACH spec``. Each
            entry is executed as ``ATTACH <spec> AS <alias>``. Useful for
            DuckLake catalogs, raw Parquet directories, or S3-backed
            httpfs. Specs are inserted as SQL literals after escaping —
            do not pass user-provided strings.
        extensions: Optional list of DuckDB extensions to ``INSTALL`` and
            ``LOAD`` before any ``ATTACH``. Common values: ``"ducklake"``,
            ``"httpfs"``, ``"iceberg"``.

    Example:
        local = sl.LocalRegistry("sdmx.duckdb")
        store = sl.DuckDBDataStore(
            local,
            attach={"lake": "ducklake:'/path/to/catalog.duckdb' (READ_ONLY)"},
            extensions=["ducklake"],
        )
        df = store.query(binding, where=["REF_AREA = ?"], params=["CA"])
    """

    def __init__(
        self,
        registry: LocalRegistry,
        *,
        attach: dict[str, str] | None = None,
        extensions: list[str] | None = None,
    ) -> None:
        self._registry = registry
        self._conn: duckdb.DuckDBPyConnection = registry.connection

        if extensions:
            for ext in extensions:
                self._conn.execute(f"INSTALL {_sql_identifier(ext)}")
                self._conn.execute(f"LOAD {_sql_identifier(ext)}")
            # Loading extensions can change the search_path; reset to
            # ``sdmx`` so LocalRegistry's internal queries stay clean.
            self._conn.execute("SET search_path = 'sdmx'")

        if attach:
            for alias, spec in attach.items():
                self._conn.execute(f"ATTACH {spec} AS {_sql_identifier(alias)}")
            self._conn.execute("SET search_path = 'sdmx'")

    @property
    def connection(self) -> duckdb.DuckDBPyConnection:
        """The shared DuckDB connection."""
        return self._conn

    @property
    def registry(self) -> LocalRegistry:
        """The :class:`LocalRegistry` whose connection is shared."""
        return self._registry

    # ── DataStore protocol ───────────────────────────────────────────────

    def query(
        self,
        binding: DataflowBinding,
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        limit: int | None = None,
    ) -> pl.DataFrame:
        """Run a SELECT against ``binding.table_location``.

        Filter clauses use SDMX dimension/measure ids; the binding's
        column maps determine the physical column names. For v1 we
        assume identity mapping (SDMX id == physical column) — when
        non-identity mappings are needed, this method is the seam to
        wire in the rename.

        When ``binding.series_attributes_location`` is set, the sidecar
        table is LEFT JOINed on the columns common to both tables (found
        via DuckDB ``DESCRIBE``). This is what makes
        ``binding.attribute_column_map`` columns reachable when the
        attributes live on a sibling table rather than denormalised into
        the fact table.
        """
        sql, sql_params = _build_query(
            conn=self._conn,
            binding=binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            limit=limit,
        )
        cur = self._conn.execute(sql, sql_params)
        col_names = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchall()
        if not rows:
            return pl.DataFrame(schema=col_names)
        return pl.from_records(rows, schema=col_names, orient="row")

    def query_stream(
        self,
        binding: DataflowBinding,
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        chunk_rows: int = 10_000,
    ) -> Iterator[pa.RecordBatch]:
        """Stream the same scan as :meth:`query` as Arrow record batches.

        Uses DuckDB's Arrow integration (``to_arrow_reader``) so peak
        memory stays roughly proportional to ``chunk_rows`` rather than
        the full result size. See :meth:`sdmxlib.DataStore.query_stream`.
        """
        sql, sql_params = _build_query(
            conn=self._conn,
            binding=binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            limit=None,
        )
        reader = self._conn.execute(sql, sql_params).to_arrow_reader(chunk_rows)
        yield from reader


# ── SQL helpers ─────────────────────────────────────────────────────────


def _build_query(
    *,
    conn: duckdb.DuckDBPyConnection,
    binding: DataflowBinding,
    where: list[str] | None,
    params: list[object] | None,
    component_filter: ComponentFilter | None,
    columns: list[str] | None,
    order_by: str | None,
    limit: int | None,
) -> tuple[str, list[object]]:
    """Build a parameterised SELECT + parameter list against the binding's table(s).

    Table names come from the binding (sdmxlib-controlled artefact) and
    are interpolated as-is. WHERE clauses are interpolated as-is too
    (callers compose them) but their values must be passed via ``params``
    for parameterisation — never f-stringed.

    When ``binding.series_attributes_location`` is set, the sidecar table
    is LEFT JOINed on the columns common to both tables. When
    ``component_filter`` is provided, it is translated to additional
    ``col IN (?, ?, ...)`` fragments via the binding's dimension and
    attribute column maps and ANDed in.
    """
    cols_sql = ", ".join(columns) if columns else "*"
    main = binding.table_location
    sidecar = binding.series_attributes_location
    if sidecar is None:
        sql = f"SELECT {cols_sql} FROM {main}"
    else:
        join_keys = _shared_columns(conn, main, sidecar)
        if not join_keys:
            msg = (
                f"DataflowBinding.series_attributes_location {sidecar!r} "
                f"shares no columns with {main!r}; cannot derive JOIN keys"
            )
            raise ValueError(msg)
        keys_sql = ", ".join(join_keys)
        sql = f"SELECT {cols_sql} FROM {main} LEFT JOIN {sidecar} USING ({keys_sql})"

    fragments = list(where or [])
    sql_params: list[object] = list(params or [])
    if component_filter is not None:
        cf_fragments, cf_params = component_filter.to_where_clauses(
            binding.dimension_column_map,
            binding.attribute_column_map,
        )
        fragments.extend(cf_fragments)
        sql_params.extend(cf_params)

    if fragments:
        sql += " WHERE " + " AND ".join(fragments)
    if order_by:
        sql += f" ORDER BY {order_by}"
    if limit is not None:
        sql += f" LIMIT {int(limit)}"
    return sql, sql_params


def _describe_columns(conn: duckdb.DuckDBPyConnection, table: str) -> list[str]:
    """Return column names for ``table`` via DuckDB ``DESCRIBE``."""
    rows = conn.execute(f"DESCRIBE {table}").fetchall()
    return [str(r[0]) for r in rows]


def _shared_columns(conn: duckdb.DuckDBPyConnection, table_a: str, table_b: str) -> list[str]:
    """Columns present in both tables, in ``table_a`` order."""
    cols_b = set(_describe_columns(conn, table_b))
    return [c for c in _describe_columns(conn, table_a) if c in cols_b]


def _sql_identifier(name: str) -> str:
    """Escape a SQL identifier (extension name, ATTACH alias).

    DuckDB identifiers are case-insensitive and may contain alphanumerics
    and underscores. Reject anything else to avoid SQL injection through
    extension/alias names.
    """
    if not name or not all(c.isalnum() or c == "_" for c in name):
        msg = f"Invalid SQL identifier: {name!r}"
        raise ValueError(msg)
    return name
