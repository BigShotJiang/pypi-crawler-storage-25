"""Codelist and Code — enumerated value sets."""

from datetime import datetime
from typing import ClassVar

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.collections import ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring


def _to_codes(v: "ItemList[Code] | list[Code]") -> "ItemList[Code]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class Code:
    """A single code within a Codelist."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    parent_id: str | None = None
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


@define
class Codelist(MaintainableArtefact):
    """A finite set of valid codes for an enumerated component.

    Constructor accepts convenient Python types alongside the strict stored
    types — ``dict[str, str]`` for name/description, ``list[Code]`` for
    codes. After construction the stored types are always strict.

    Example:
        cl = Codelist(
            id="CL_FREQ", maintainer="SDMX",
            name={"en": "Frequency"},
            codes=[Code(id="A", name={"en": "Annual"})],
        )
        cl.codes["A"]      # Code by id
        cl.roots()         # top-level codes
        cl.narrower("A")   # direct children of code A (SKOS-aligned)
    """

    sdmx_package: ClassVar[str] = "codelist"
    sdmx_class: ClassVar[str] = "Codelist"
    msg_field: ClassVar[str] = "codelists"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    codes: ItemList[Code] = field(factory=ItemList, converter=_to_codes)

    # ── SKOS/XKOS hierarchy navigation ────────────────────────────────────

    def roots(self) -> ItemList[Code]:
        """Top-level codes (``broader IS NULL``)."""
        return self.codes.filter(lambda c: c.parent_id is None)

    def leaves(self) -> ItemList[Code]:
        """Codes that no other code names as parent."""
        parents = {c.parent_id for c in self.codes if c.parent_id is not None}
        return self.codes.filter(lambda c: c.id not in parents)

    def narrower(self, code_id: str) -> ItemList[Code]:
        """Direct children (SKOS narrower) of ``code_id``."""
        return self.codes.filter(lambda c: c.parent_id == code_id)

    def broader(self, code_id: str) -> Code | None:
        """Direct parent (SKOS broader) of ``code_id``. ``None`` for roots."""
        target = self.codes.get(code_id)
        if target is None or target.parent_id is None:
            return None
        return self.codes.get(target.parent_id)

    def narrower_transitive(self, code_id: str, *, depth: int | None = None) -> ItemList[Code]:
        """All descendants of ``code_id``. ``depth`` bounds the hop count."""
        result: list[Code] = []
        frontier: list[tuple[str, int]] = [(code_id, 0)]
        seen: set[str] = {code_id}
        by_parent: dict[str, list[Code]] = {}
        for c in self.codes:
            if c.parent_id is not None:
                by_parent.setdefault(c.parent_id, []).append(c)
        while frontier:
            current, hops = frontier.pop(0)
            if depth is not None and hops >= depth:
                continue
            for child in by_parent.get(current, []):
                if child.id in seen:
                    continue
                seen.add(child.id)
                result.append(child)
                frontier.append((child.id, hops + 1))
        return ItemList(result)

    def broader_transitive(self, code_id: str, *, depth: int | None = None) -> ItemList[Code]:
        """All ancestors of ``code_id``. ``depth`` bounds the hop count."""
        result: list[Code] = []
        current = self.codes.get(code_id)
        if current is None:
            return ItemList(result)
        hops = 0
        while current is not None and current.parent_id is not None:
            if depth is not None and hops >= depth:
                break
            parent = self.codes.get(current.parent_id)
            if parent is None:
                break
            result.append(parent)
            current = parent
            hops += 1
        return ItemList(result)

    def depth_of(self, code_id: str) -> int:
        """Depth of ``code_id`` in the hierarchy (root = 0)."""
        current = self.codes.get(code_id)
        if current is None:
            msg = f"Code {code_id!r} not in codelist {self.id!r}"
            raise KeyError(msg)
        depth = 0
        while current.parent_id is not None:
            parent = self.codes.get(current.parent_id)
            if parent is None:
                break
            current = parent
            depth += 1
        return depth

    def add(self, codes: "Code | list[Code]") -> "Codelist":
        """Return a new Codelist with *codes* added.

        Accepts a single Code or a list of Codes.
        """
        new = [codes] if isinstance(codes, Code) else list(codes)
        return evolve(self, codes=[*self.codes, *new])

    def drop(self, code_ids: str | list[str]) -> "Codelist":
        """Return a new Codelist with the given code(s) removed.

        Accepts a single id string or a list of id strings.
        Raises KeyError if any id is not present.
        """
        ids = [code_ids] if isinstance(code_ids, str) else list(code_ids)
        missing = [i for i in ids if i not in self.codes]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(self, codes=[c for c in self.codes if c.id not in id_set])
