"""StructureSet, CodelistMap, and CodeMap — SDMX structural mapping types."""

from datetime import datetime
from typing import ClassVar

from attrs import define, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import AnyRef


@define
class CodeMap:
    """Single code-level mapping: source code id → target code id."""

    source_id: str
    target_id: str


@define
class CodelistMap:
    """Maps one codelist onto another, code by code."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    source: AnyRef | None = None
    target: AnyRef | None = None
    maps: tuple[CodeMap, ...] = ()

    def translate(self, source_code: str) -> str | None:
        """Return the target code id for a source code id, or None if unmapped."""
        for m in self.maps:
            if m.source_id == source_code:
                return m.target_id
        return None


@define
class ConceptMap:
    """Single concept-level mapping: source concept id → target concept id."""

    source_id: str
    target_id: str


@define
class ConceptSchemeMap:
    """Maps one concept scheme onto another, concept by concept."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    source: AnyRef | None = None
    target: AnyRef | None = None
    maps: tuple[ConceptMap, ...] = ()


@define
class CategoryMap:
    """Single category-level mapping: source category id → target category id."""

    source_id: str
    target_id: str


@define
class CategorySchemeMap:
    """Maps one category scheme onto another, category by category."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    source: AnyRef | None = None
    target: AnyRef | None = None
    maps: tuple[CategoryMap, ...] = ()


@define
class ComponentMap:
    """Single component-level mapping: source component id → target component id."""

    source_id: str
    target_id: str


@define
class DataStructureMap:
    """Maps one DSD onto another, component by component."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    source: AnyRef | None = None
    target: AnyRef | None = None
    maps: tuple[ComponentMap, ...] = ()


@define
class DataflowMap:
    """Maps one dataflow onto another (artefact-level only, no item maps)."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    source: AnyRef | None = None
    target: AnyRef | None = None


@define
class StructureSet(MaintainableArtefact):
    """Maintainable container for structural mappings between artefacts."""

    sdmx_package: ClassVar[str] = "mapping"
    sdmx_class: ClassVar[str] = "StructureSet"
    msg_field: ClassVar[str] = "structure_sets"

    id: str = ""
    maintainer: Agency = field(factory=lambda: Agency(id=""), converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    codelist_maps: tuple[CodelistMap, ...] = ()
    concept_scheme_maps: tuple[ConceptSchemeMap, ...] = ()
    category_scheme_maps: tuple[CategorySchemeMap, ...] = ()
    data_structure_maps: tuple[DataStructureMap, ...] = ()
    dataflow_maps: tuple[DataflowMap, ...] = ()
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
