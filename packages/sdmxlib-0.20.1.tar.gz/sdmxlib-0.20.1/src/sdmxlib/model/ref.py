"""Ref[T], HasUrn, UnresolvedRef, SdmxRef — SDMX reference abstraction."""

from typing import Any, ClassVar, Protocol, runtime_checkable

from attrs import define, field, frozen

from sdmxlib.model.urn import SdmxUrn


@runtime_checkable
class HasUrn(Protocol):
    """Protocol for SDMX artefacts that can be referenced by URN.

    Any MaintainableArtefact satisfies this protocol. Accepts anywhere
    a Ref target is needed — allows ``Ref(cl_freq)`` instead of
    ``Ref.unresolved(cl_freq.urn)``.
    """

    sdmx_package: ClassVar[str]
    sdmx_class: ClassVar[str]
    agency_id: str
    id: str
    version: str


@define
class Ref[T]:
    """A reference to an SDMX artefact.

    Always carries the URN. May also carry the resolved object once
    the artefact has been added to a Registry.

    ``None`` on a parent field means "no reference exists."
    ``Ref[T]`` means "a reference exists, resolved or not."

    Access tiers:

    - ``ref.urn``, ``ref.id``, ``ref.agency`` — URN metadata, always available
    - ``ref.resolved`` — bool check
    - ``ref.codes``, ``ref.name`` etc — proxy to resolved object, raises
      ``UnresolvedRef`` if not yet resolved

    Construction:

        Ref(cl_freq)                      # from domain object — resolved
        Ref(cl_freq.urn)                  # from SdmxUrn — unresolved
        Ref.unresolved(urn)               # explicit unresolved factory
        Ref.of(urn, obj)                  # explicit resolved factory

    Example:
        ref = Ref(cl_freq_urn)
        ref.id       # "CL_FREQ"
        ref.resolved  # False
        ref.codes    # raises UnresolvedRef

        reg.add(cl_freq)
        ref.resolved  # True (if interned through registry)
        ref.codes    # ItemList[Code]
    """

    urn: SdmxUrn[T]
    _resolved: T | None = field(default=None, repr=False, alias="_resolved")

    def __attrs_post_init__(self) -> None:
        # Allow passing a HasUrn (MaintainableArtefact) directly
        if not isinstance(self.urn, SdmxUrn):
            obj = self.urn  # type: ignore[assignment]
            self.urn = SdmxUrn.make(  # type: ignore[assignment]
                type(obj),
                package=obj.sdmx_package,  # type: ignore[union-attr]
                artefact_class=obj.sdmx_class,  # type: ignore[union-attr]
                agency=obj.agency_id,  # type: ignore[union-attr]
                id=obj.id,  # type: ignore[union-attr]
                version=obj.version,  # type: ignore[union-attr]
            )
            if self._resolved is None:
                self._resolved = obj  # type: ignore[assignment]

    # ── Resolution ────────────────────────────────────────────────────────

    @property
    def resolved(self) -> bool:
        """True if the referenced object has been resolved."""
        return self._resolved is not None

    def __call__(self) -> T:
        """Unwrap to the resolved object. Raises UnresolvedRef if not resolved."""
        if self._resolved is None:
            raise UnresolvedRef(self.urn)
        return self._resolved

    def __getattr__(self, name: str) -> Any:
        """Proxy attribute access to the resolved object.

        Allows ``ref.codes`` instead of unwrapping manually.
        Raises ``UnresolvedRef`` if the ref has not been resolved.
        """
        try:
            resolved = self._resolved
        except AttributeError:
            raise AttributeError(name) from None
        if resolved is None:
            raise UnresolvedRef(self.urn)
        return getattr(resolved, name)

    # ── URN metadata ──────────────────────────────────────────────────────

    @property
    def id(self) -> str:
        """Artefact id from the URN."""
        return self.urn.id

    @property
    def agency(self) -> str:
        """Agency id from the URN."""
        return self.urn.agency

    @property
    def version(self) -> str:
        """Version from the URN."""
        return self.urn.version

    @property
    def item_id(self) -> str | None:
        """Item id from the URN (e.g. the concept id within a ConceptScheme)."""
        return self.urn.item_id

    # ── Factories ─────────────────────────────────────────────────────────

    @classmethod
    def unresolved(cls, urn: SdmxUrn[T]) -> "Ref[T]":
        """Create an unresolved Ref carrying the URN only."""
        return cls(urn=urn)

    @classmethod
    def of(cls, urn: SdmxUrn[T], obj: T) -> "Ref[T]":
        """Create a resolved Ref. Useful in tests and format readers."""
        return cls(urn=urn, _resolved=obj)

    @classmethod
    def to(cls, obj: T) -> "Ref[T]":
        """Create a resolved Ref from a MaintainableArtefact instance.

        The object must satisfy HasUrn — it needs ``agency_id``, ``id``,
        ``version``, ``sdmx_package``, and ``sdmx_class`` attributes.

        Example:
            cl = Codelist(id="CL_FREQ", maintainer="SDMX", version="1.0", ...)
            ref = Ref.to(cl)
            ref.resolved   # True
        """
        return cls(urn=obj)  # type: ignore[arg-type]  # delegates to __post_init__

    # ── Boolean ───────────────────────────────────────────────────────────

    def __bool__(self) -> bool:
        """Always True — the Ref exists (use .resolved to check resolution)."""
        return True

    # ── Repr ──────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        if self._resolved is not None:
            return f"Ref({self.urn.id} → resolved)"
        return f"Ref({self.urn.id} [unresolved])"


class UnresolvedRef(Exception):  # noqa: N818
    """Raised when accessing an unresolved Ref."""

    def __init__(self, urn: SdmxUrn[Any]) -> None:
        self.urn = urn
        super().__init__(f"{urn} has not been resolved — add the artefact to a Registry first.")


@frozen
class SdmxRef:
    """Partial artefact identity for filtering and lookup.

    All fields optional. ``None`` means "match any."
    Used as ``ArtefactList`` key and in ``Query``.

    Example:
        SdmxRef(agency="SDMX", id="CL_FREQ")
        SdmxRef(id="CL_FREQ", version="1.0")
    """

    agency: str | None = None
    id: str | None = None
    version: str | None = None


# Type alias for Ref[Any] — used in format layers and internal code where the
# specific artefact type is not yet known or not relevant.
AnyRef = Ref[Any]
