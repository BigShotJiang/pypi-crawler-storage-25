"""MetadataSet and ReportedAttribute — populated reference metadata.

A MetadataSet binds an MSD (or Metadataflow) to a list of target artefacts
and a tree of populated attribute values. All attributes apply to all
targets in the set — this is the canonical SDMX 3.0 shape (the v2.1
``MetadataReport`` layer was dropped in 3.0).

Repetition (when the corresponding MetadataAttribute has ``max_occurs > 1``)
is expressed by multiple sibling ReportedAttributes with the same id, not
by a values list on the leaf — again matching the wire formats.

Values are scalars (str, int, float, bool) or InternationalString for
multilingual / XHTML content. The MSD declares whether a string scalar is
a code id or free text; the wire format does not distinguish them, so
neither does the model.
"""

from collections.abc import Sequence
from datetime import datetime
from typing import Any, ClassVar, cast

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.collections import ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.metadataflow import Metadataflow
from sdmxlib.model.metadatastructure import MetadataStructure
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import AnyRef, Ref
from sdmxlib.model.urn import SdmxUrn

# A populated reported value. Scalar types map to JSON primitives and to
# the text content of XML <Value>; InternationalString maps to a JSON
# localisedText dict and to one or more <com:Text> / <com:StructuredText>
# (XHTML) sibling elements.
type ReportedAttributeValue = str | int | float | bool | InternationalString


def _to_value(
    v: ReportedAttributeValue | dict[str, str] | None,
) -> ReportedAttributeValue | None:
    """Coerce a dict to InternationalString; pass scalars through."""
    if isinstance(v, dict):
        return InternationalString.of(v)
    return v


def _to_reported_children(
    v: "ItemList[ReportedAttribute] | list[ReportedAttribute]",
) -> "ItemList[ReportedAttribute]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class ReportedAttribute:
    """One populated metadata attribute within a MetadataSet.

    The id field references a MetadataAttribute in the MSD. Either the
    value is set (leaf) or children is non-empty (presentational
    container). Repetition is handled by multiple sibling instances with
    the same id.

    Example:
        sl.ReportedAttribute(id="FOOTNOTE_TEXT", value={"en": "..."})
        sl.ReportedAttribute(id="FREQ", value="A")
        sl.ReportedAttribute(id="QUALITY", children=[
            sl.ReportedAttribute(id="COVERAGE", value="full"),
        ])
    """

    id: str
    value: ReportedAttributeValue | None = field(default=None, converter=_to_value)
    children: "ItemList[ReportedAttribute]" = field(factory=ItemList, converter=_to_reported_children)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


# ── MetadataSet ──────────────────────────────────────────────────────────


def _to_structure_ref(
    v: "Ref[MetadataStructure] | Ref[Metadataflow] | SdmxUrn[MetadataStructure] | SdmxUrn[Metadataflow] | MetadataStructure | Metadataflow",  # noqa: E501
) -> "Ref[MetadataStructure] | Ref[Metadataflow]":
    if isinstance(v, SdmxUrn):
        if v.artefact_class == "Metadataflow":
            return Ref[Metadataflow].unresolved(cast("SdmxUrn[Metadataflow]", v))
        return Ref[MetadataStructure].unresolved(cast("SdmxUrn[MetadataStructure]", v))
    if isinstance(v, MetadataStructure):
        return Ref.to(v)
    if isinstance(v, Metadataflow):
        return Ref.to(v)
    return v


def _to_target_refs(
    v: "Sequence[Ref[Any] | SdmxUrn[Any]]",
) -> "list[AnyRef]":
    """Coerce a sequence of URNs / Refs to a list of Refs."""
    out: list[AnyRef] = []
    for item in v:
        if isinstance(item, SdmxUrn):
            out.append(Ref[Any].unresolved(item))
        else:
            out.append(item)
    return out


def _to_attributes(
    v: "ItemList[ReportedAttribute] | list[ReportedAttribute]",
) -> "ItemList[ReportedAttribute]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class MetadataSet(MaintainableArtefact):
    """A populated reference-metadata payload describing a list of targets.

    All attributes apply to all targets — there is no per-target scoping.
    This matches the SDMX 3.0 information model, which collapsed v2.1's
    MetadataReport layer.

    The ``structure`` field references either the MetadataStructure
    directly or a Metadataflow that wraps one.

    Note that MetadataSet does NOT belong in a Structure message envelope —
    it is carried in a GenericMetadata message (``<mes:GenericMetadata>`` in
    SDMX-ML 3.0; ``data.metadataSets`` keyed on the metadata-schema $schema
    in SDMX-JSON 2.0). Use a ``MetadataMessage`` to serialise it.

    Example:
        ms = sl.MetadataSet(
            id="FOOTNOTE_A", maintainer="STC_CP",
            structure=mdf,
            targets=[char_1_urn, char_5_urn, char_12_urn],
            attributes=[sl.ReportedAttribute(id="FOOTNOTE_TEXT",
                                             value={"en": "..."})],
        )
    """

    sdmx_package: ClassVar[str] = "metadatastructure"
    sdmx_class: ClassVar[str] = "MetadataSet"
    msg_field: ClassVar[str] = "metadata_sets"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    structure: Ref[MetadataStructure] | Ref[Metadataflow] = field(converter=_to_structure_ref)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    targets: list[AnyRef] = field(factory=list, converter=_to_target_refs)
    attributes: ItemList[ReportedAttribute] = field(factory=ItemList, converter=_to_attributes)

    def add_target(self, target: "Ref[Any] | SdmxUrn[Any]") -> "MetadataSet":
        """Return a new MetadataSet with *target* appended to targets."""
        new_target = Ref[Any].unresolved(target) if isinstance(target, SdmxUrn) else target
        return evolve(self, targets=[*self.targets, new_target])

    def add_attribute(self, attribute: ReportedAttribute) -> "MetadataSet":
        """Return a new MetadataSet with *attribute* appended to attributes."""
        return evolve(self, attributes=[*self.attributes, attribute])
