"""InMemoryRegistry — pure-domain SDMX artefact store.

The in-memory Registry is the SDMX Information Model concept of a local
artefact graph: a URN-keyed store that connects artefacts through interned
``Ref`` objects.

Key behaviours:

- **One Ref per URN** — interning means every holder of a given Ref shares
  the same object. Resolving it once propagates everywhere automatically.
- **Eager accept, lazy resolve** — add artefacts in any order; Refs get
  resolved as their targets arrive.
- **Pure domain** — no network, no HTTP, no serialisation.

Example::

    reg = InMemoryRegistry()
    reg.add(cl_freq)
    reg.add(dsd)  # Refs to cl_freq resolve here
    dsd.dimensions["FREQ"].codelist()  # Codelist — no fetch needed
"""

from collections.abc import Iterable
from typing import Any

import attrs

from sdmxlib.model.collections import ItemList
from sdmxlib.model.ref import AnyRef, HasUrn, Ref
from sdmxlib.model.urn import SdmxUrn


class InMemoryRegistry:
    """In-memory SDMX artefact store with URN identity and Ref interning.

    Satisfies the :class:`Registry` Protocol via ``get(urn)`` and
    ``__contains__(urn)``.

    Example::

        reg = InMemoryRegistry()
        reg.add_all([cl_freq, concept_scheme, dsd])

        dsd = reg.get(DataStructure.urn(agency="ESTAT", id="CPI", version="1.0"))
        dims = reg.get_all(Dimension)  # not typically used; prefer dsd.dimensions
    """

    def __init__(self) -> None:
        self._store: dict[str, Any] = {}  # str(urn) → artefact
        self._refs: dict[str, AnyRef] = {}  # str(urn) → canonical Ref
        self._by_type: dict[type, list[Any]] = {}  # Python type → [artefact, ...]

    # ── Public API ────────────────────────────────────────────────────────

    def add(self, artefact: Any) -> None:
        """Add an artefact to the registry.

        - Interns the artefact under its URN.
        - Resolves the canonical ``Ref`` for this URN so all existing
          holders see the artefact immediately.
        - Walks all outgoing ``Ref`` fields, replaces them with canonical
          interned Refs, and resolves any that point to artefacts already
          present.

        Raises ``TypeError`` if the artefact does not satisfy ``HasUrn``.
        """
        if not isinstance(artefact, HasUrn):
            msg = (
                f"{type(artefact).__name__} does not satisfy HasUrn — "
                "it needs sdmx_package, sdmx_class, agency_id, id, version"
            )
            raise TypeError(msg)

        urn = artefact_urn(artefact)
        urn_str = str(urn)

        # Store under exact URN
        self._store[urn_str] = artefact

        # Track by Python type for get_all()
        t = type(artefact)
        if t not in self._by_type:
            self._by_type[t] = []
        if artefact not in self._by_type[t]:
            self._by_type[t].append(artefact)

        # Resolve the canonical Ref for this artefact (propagates to all holders)
        canonical = self._canonical_ref(urn)
        canonical._resolved = artefact  # noqa: SLF001

        # Walk outgoing Refs on the artefact and intern them
        self._walk_refs(artefact, set())

    def add_all(self, artefacts: Iterable[Any]) -> None:
        """Add multiple artefacts in any order."""
        for artefact in artefacts:
            self.add(artefact)

    def get[T](self, urn: "SdmxUrn[T]") -> "T | None":
        """Look up an artefact by exact URN. Returns ``None`` if absent."""
        return self._store.get(str(urn))  # type: ignore[return-value]

    def get_all[T](self, artefact_type: "type[T]") -> "list[T]":
        """All artefacts of the given Python type (exact match, not subclasses)."""
        return list(self._by_type.get(artefact_type, []))  # type: ignore[return-value]

    def ref[T](self, urn: "SdmxUrn[T]") -> "Ref[T]":
        """Return the canonical interned Ref for this URN.

        Creates an unresolved Ref if this URN has not been seen before.
        If the target artefact is already in the registry, the returned
        Ref will be resolved.
        """
        return self._canonical_ref(urn)  # type: ignore[return-value]

    def __contains__(self, urn: object) -> bool:
        """True if an artefact with this URN is stored."""
        if isinstance(urn, SdmxUrn):
            return str(urn) in self._store
        return False

    def __len__(self) -> int:
        """Number of artefacts stored."""
        return len(self._store)

    def __repr__(self) -> str:
        counts = ", ".join(f"{t.__name__}={len(v)}" for t, v in self._by_type.items())
        return f"InMemoryRegistry({counts or 'empty'})"

    # ── Internals ─────────────────────────────────────────────────────────

    def _canonical_ref(self, urn: "SdmxUrn[Any]") -> AnyRef:
        """Get or create the canonical (interned) Ref for a URN."""
        urn_str = str(urn)
        if urn_str not in self._refs:
            new_ref: AnyRef = Ref.unresolved(urn)
            self._refs[urn_str] = new_ref
            # Resolve immediately if the target is already stored
            artefact = self._store.get(urn_str)
            if artefact is not None:
                new_ref._resolved = artefact  # noqa: SLF001
        return self._refs[urn_str]

    def _walk_refs(self, obj: Any, visited: set[int]) -> None:
        """Walk dataclass fields of *obj*, interning every ``Ref`` found.

        Recurses into ``ItemList`` items and nested dataclass fields.
        The *visited* set prevents cycles.
        """
        if not attrs.has(type(obj)) or isinstance(obj, type):
            return
        oid = id(obj)
        if oid in visited:
            return
        visited.add(oid)

        for f in attrs.fields(type(obj)):
            self._process_field(obj, f.name, getattr(obj, f.name, None), visited)

    def _process_field(self, obj: Any, name: str, value: Any, visited: set[int]) -> None:
        """Intern a single field value; recurse if it contains more Refs."""
        if value is None:
            return
        if isinstance(value, Ref):
            self._intern_ref_field(obj, name, value)
        elif isinstance(value, ItemList):
            for item in value:
                self._walk_refs(item, visited)
        elif attrs.has(type(value)) and not isinstance(value, type):
            self._walk_refs(value, visited)

    def _intern_ref_field(self, obj: Any, name: str, ref: AnyRef) -> None:
        """Replace *ref* on *obj.name* with the canonical interned Ref."""
        interned = self._canonical_ref(ref.urn)
        # Transfer resolution from incoming ref to canonical if needed
        if ref._resolved is not None and interned._resolved is None:  # noqa: SLF001
            interned._resolved = ref._resolved  # noqa: SLF001
        if interned is not ref:
            setattr(obj, name, interned)


# ── Module-level helper ────────────────────────────────────────────────────


def artefact_urn(artefact: Any) -> "SdmxUrn[Any]":
    """Canonical :class:`SdmxUrn` for a maintainable artefact.

    The returned URN matches the primary key written by
    :mod:`sdmxlib.storage.writers`, so external code sharing the same
    DuckDB connection can compute foreign keys without re-implementing
    the URN convention.

    Example:
        >>> str(artefact_urn(codelist))
        'urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_FREQ(1.0)'
    """
    return SdmxUrn.make(
        type(artefact),
        package=artefact.sdmx_package,
        artefact_class=artefact.sdmx_class,
        agency=artefact.agency_id,
        id=artefact.id,
        version=artefact.version,
    )
