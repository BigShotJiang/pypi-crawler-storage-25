"""CategoryScheme, Category, Categorisation — classification of artefacts."""

from datetime import datetime
from typing import ClassVar

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.collections import ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import AnyRef


def _to_categories(v: "ItemList[Category] | list[Category]") -> "ItemList[Category]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class Category:
    """A node in a classification hierarchy."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    categories: "ItemList[Category]" = field(factory=ItemList, converter=_to_categories)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


@define
class CategoryScheme(MaintainableArtefact):
    """A hierarchical classification scheme."""

    sdmx_package: ClassVar[str] = "categoryscheme"
    sdmx_class: ClassVar[str] = "CategoryScheme"
    msg_field: ClassVar[str] = "category_schemes"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    categories: ItemList[Category] = field(factory=ItemList, converter=_to_categories)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None

    def add(self, categories: "Category | list[Category]") -> "CategoryScheme":
        """Return a new CategoryScheme with *categories* added.

        Accepts a single Category or a list of Categories.
        """
        new = [categories] if isinstance(categories, Category) else list(categories)
        return evolve(self, categories=[*self.categories, *new])

    def drop(self, category_ids: str | list[str]) -> "CategoryScheme":
        """Return a new CategoryScheme with the given category(ies) removed.

        Accepts a single id string or a list of id strings.
        Raises KeyError if any id is not present.
        """
        ids = [category_ids] if isinstance(category_ids, str) else list(category_ids)
        missing = [i for i in ids if i not in self.categories]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(self, categories=[c for c in self.categories if c.id not in id_set])


@define
class Categorisation(MaintainableArtefact):
    """Links an artefact (source) to a Category (target)."""

    sdmx_package: ClassVar[str] = "categoryscheme"
    sdmx_class: ClassVar[str] = "Categorisation"
    msg_field: ClassVar[str] = "categorisations"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    source: AnyRef | None = None
    target: AnyRef | None = None
