"""ItemList[T] and ArtefactList[T] — SDMX collection types.

- ``ItemList[T]``: child artefacts (codes, dimensions, concepts).
  Lookup by bare id only.
- ``ArtefactList[T]``: maintainable artefacts (codelists, DSDs, etc.).
  Lookup by bare id, agency-qualified key, fully-qualified key,
  SdmxUrn, or SdmxRef.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Any, Protocol, cast, overload, runtime_checkable

from sdmxlib.model.ref import SdmxRef
from sdmxlib.model.urn import SdmxUrn

if TYPE_CHECKING:
    from collections.abc import Iterator


# ── Maintainable protocol ──────────────────────────────────────────────────


@runtime_checkable
class Maintainable(Protocol):
    """Protocol for top-level SDMX artefacts (have agency_id and version)."""

    @property
    def id(self) -> str:
        """Artefact identifier."""
        ...

    @property
    def agency_id(self) -> str:
        """Maintainer agency identifier."""
        ...

    @property
    def version(self) -> str:
        """Semantic version string."""
        ...


# ── ItemList[T] ────────────────────────────────────────────────────────────


class ItemList[T](Sequence[T]):
    """Ordered collection of child artefacts (codes, dimensions, etc.).

    Items are expected to have an ``id`` attribute. Lookup is by bare id.

    Example:
        dims["FREQ"]  # by id
        dims.filter(lambda d: d.is_enumerated)   # lambda predicate
        dims.filter(item("is_enumerated"))        # expression predicate
        dims.sort_by(lambda d: d.id)  # sort → new ItemList
        dims.ids()  # ["FREQ", "REF_AREA", ...]
    """

    __slots__ = ("_by_id", "_items")

    def __init__(self, items: list[T] | None = None) -> None:
        self._items: tuple[T, ...] = tuple(items or [])
        self._by_id: dict[str, T] = {}
        for item in self._items:
            item_id = getattr(item, "id", None)
            if item_id is not None:
                self._by_id[item_id] = item

    # ── Sequence ──────────────────────────────────────────────────────────

    @overload
    def __getitem__(self, index: int) -> T: ...

    @overload
    def __getitem__(self, index: slice) -> ItemList[T]: ...

    @overload
    def __getitem__(self, index: str) -> T: ...

    def __getitem__(self, index: int | str | slice) -> T | ItemList[T]:
        if isinstance(index, int):
            return self._items[index]
        if isinstance(index, slice):
            return ItemList(list(self._items[index]))
        try:
            return self._by_id[index]
        except KeyError:
            msg = f"No item with id {index!r}"
            raise KeyError(msg) from None

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self) -> Iterator[T]:
        return iter(self._items)

    def __bool__(self) -> bool:
        return bool(self._items)

    def __contains__(self, key: object) -> bool:
        if isinstance(key, str):
            return key in self._by_id
        return key in self._items

    # ── Lookup ────────────────────────────────────────────────────────────

    def get(self, id: str) -> T | None:  # noqa: A002
        """Return item by id, or None if not found."""
        return self._by_id.get(id)

    def ids(self) -> list[str]:
        """List of all item ids in order."""
        return [cast("str", item.id) for item in self._items]  # pyright: ignore[reportAttributeAccessIssue]

    # ── Filtering ─────────────────────────────────────────────────────────

    def filter(self, predicate: Callable[[T], bool]) -> ItemList[T]:
        """Return new ItemList with items satisfying predicate.

        Accepts a lambda or an item() expression:
            dims.filter(lambda d: d.id == "FREQ")
            dims.filter(item("id") == "FREQ")
            dims.filter(item("is_enumerated"))
            dims.filter(~item("is_enumerated"))
        """
        return ItemList([x for x in self._items if predicate(x)])

    def first_where(self, predicate: Callable[[T], bool]) -> T | None:
        """Return first item satisfying the predicate, or None."""
        for x in self._items:
            if predicate(x):
                return x
        return None

    def partition(self, predicate: Callable[[T], bool]) -> tuple[ItemList[T], ItemList[T]]:
        """Split into (matching, non-matching) ItemLists."""
        yes: list[T] = []
        no: list[T] = []
        for item in self._items:
            (yes if predicate(item) else no).append(item)
        return ItemList(yes), ItemList(no)

    # ── Ordering ──────────────────────────────────────────────────────────

    def sort_by(
        self,
        key: Callable[[T], Any],
        *,
        descending: bool = False,
    ) -> ItemList[T]:
        """Return new ItemList sorted by key function."""
        return ItemList(sorted(self._items, key=key, reverse=descending))

    # ── Conversion ────────────────────────────────────────────────────────

    def to_dict(self, key: str | Callable[[T], Any] = "id") -> dict[Any, T]:
        """Convert to dict keyed by attribute name or key function."""
        if isinstance(key, str):
            attr = key
            return {getattr(item, attr): item for item in self._items}
        return {key(item): item for item in self._items}

    # ── Equality & repr ───────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ItemList):
            return self._items == other._items  # pyright: ignore[reportUnknownMemberType]
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._items)

    def __repr__(self) -> str:
        ids = [getattr(item, "id", repr(item)) for item in self._items]
        return f"ItemList([{', '.join(repr(i) for i in ids)}])"


# ── ArtefactList[T] ────────────────────────────────────────────────────────


class ArtefactList[T: Maintainable](Sequence[T]):
    """Ordered collection of maintainable SDMX artefacts.

    Supports multiple key formats for lookup:

    - ``"CL_FREQ"`` — bare id (KeyError if ambiguous)
    - ``"SDMX:CL_FREQ"`` — agency-qualified
    - ``"SDMX:CL_FREQ(1.0)"`` — fully qualified
    - ``SdmxUrn[T]`` — typed URN (``version="latest"`` matches any)
    - ``SdmxRef(...)`` — partial identity match

    Example:
        msg.codelists["CL_FREQ"]  # bare id
        msg.codelists["SDMX:CL_FREQ"]  # agency-qualified
        msg.codelists["SDMX:CL_FREQ(1.0)"]  # fully qualified
        msg.codelists[dim.codelist.urn]  # SdmxUrn
        msg.codelists.ids(qualified=True)  # ["SDMX:CL_FREQ", ...]
    """

    __slots__ = ("_by_agency_id", "_by_fqn", "_by_id", "_items")

    def __init__(self, items: list[T] | None = None) -> None:
        self._items: tuple[T, ...] = tuple(items or [])
        self._by_id: dict[str, list[T]] = {}
        self._by_agency_id: dict[str, list[T]] = {}
        self._by_fqn: dict[str, T] = {}
        for item in self._items:
            self._by_id.setdefault(item.id, []).append(item)
            ak = f"{item.agency_id}:{item.id}"
            self._by_agency_id.setdefault(ak, []).append(item)
            self._by_fqn[f"{ak}({item.version})"] = item

    # ── Sequence ──────────────────────────────────────────────────────────

    @overload
    def __getitem__(self, index: int) -> T: ...

    @overload
    def __getitem__(self, index: slice) -> ArtefactList[T]: ...

    @overload
    def __getitem__(self, index: str | SdmxUrn[T] | SdmxRef) -> T: ...

    def __getitem__(self, index: int | str | SdmxUrn[T] | SdmxRef | slice) -> T | ArtefactList[T]:
        if isinstance(index, int):
            return self._items[index]
        if isinstance(index, slice):
            return ArtefactList(list(self._items[index]))
        result = self._lookup(index)
        if result is None:
            msg = f"No artefact matching {index!r}"
            raise KeyError(msg)
        return result

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self) -> Iterator[T]:
        return iter(self._items)

    def __bool__(self) -> bool:
        return bool(self._items)

    def __contains__(self, key: object) -> bool:
        if isinstance(key, (str, SdmxUrn, SdmxRef)):
            return self._lookup(cast("str | SdmxUrn[T] | SdmxRef", key)) is not None
        return key in self._items

    # ── Lookup helpers ────────────────────────────────────────────────────

    def _lookup(self, key: str | SdmxUrn[T] | SdmxRef) -> T | None:
        """Core lookup — returns None on miss, raises KeyError on ambiguity."""
        if isinstance(key, SdmxUrn):
            return self._lookup_urn(key)
        if isinstance(key, SdmxRef):
            return self._lookup_ref(key)
        # string key
        return self._lookup_str(str(key))

    def _lookup_str(self, key: str) -> T | None:
        # "AGENCY:ID(version)"
        if "(" in key and key.endswith(")"):
            q, rest = key.split("(", 1)
            version = rest[:-1]
            if ":" not in q:
                msg = f"Malformed key {key!r}: expected AGENCY:ID(version)"
                raise KeyError(msg)
            fqn = f"{q}({version})"
            return self._by_fqn.get(fqn)
        if ":" in key:
            matches = self._by_agency_id.get(key, [])
        else:
            # bare id — must be unambiguous
            matches = self._by_id.get(key, [])
            if len(matches) > 1:
                qualified = [f"{m.agency_id}:{m.id}({m.version})" for m in matches]
                msg = (
                    f"Ambiguous id {key!r} matches {len(matches)} artefacts: "
                    f"{', '.join(qualified)}. Use a qualified key."
                )
                raise KeyError(msg)

        return matches[0] if matches else None

    def _lookup_urn(self, urn: SdmxUrn[T]) -> T | None:
        ak = f"{urn.agency}:{urn.id}"
        if urn.version not in {"latest", ""}:
            return self._by_fqn.get(f"{ak}({urn.version})")
        matches = self._by_agency_id.get(ak, [])
        return matches[0] if matches else None

    def _lookup_ref(self, ref: SdmxRef) -> T | None:
        matches = [
            item
            for item in self._items
            if (ref.id is None or item.id == ref.id)
            and (ref.agency is None or item.agency_id == ref.agency)
            and (ref.version is None or item.version == ref.version)
        ]
        if len(matches) > 1:
            qualified = [f"{m.agency_id}:{m.id}({m.version})" for m in matches]
            msg = (
                f"Ambiguous SdmxRef {ref!r} matches {len(matches)} artefacts: "
                f"{', '.join(qualified)}. Use a more specific ref."
            )
            raise KeyError(msg)
        return matches[0] if matches else None

    def get(self, key: str | SdmxUrn[T] | SdmxRef) -> T | None:
        """Return artefact by key, or None on miss or ambiguity."""
        try:
            return self._lookup(key)
        except KeyError:
            return None

    def ids(self, *, qualified: bool = False) -> list[str]:
        """List of artefact ids in order."""
        if qualified:
            return [f"{item.agency_id}:{item.id}({item.version})" for item in self._items]
        return [item.id for item in self._items]

    # ── Filtering ─────────────────────────────────────────────────────────

    def filter(self, predicate: Callable[[T], bool]) -> ArtefactList[T]:
        """Return new ArtefactList with items satisfying predicate.

        Accepts a lambda or an item() expression:
            codelists.filter(lambda cl: cl.agency_id == "SDMX")
            codelists.filter(item("agency_id") == "SDMX")
        """
        return ArtefactList([x for x in self._items if predicate(x)])

    def first_where(self, predicate: Callable[[T], bool]) -> T | None:
        """Return first item satisfying the predicate, or None."""
        for x in self._items:
            if predicate(x):
                return x
        return None

    def partition(self, predicate: Callable[[T], bool]) -> tuple[ArtefactList[T], ArtefactList[T]]:
        """Split into (matching, non-matching) ArtefactLists."""
        yes: list[T] = []
        no: list[T] = []
        for item in self._items:
            (yes if predicate(item) else no).append(item)
        return ArtefactList(yes), ArtefactList(no)

    # ── Ordering ──────────────────────────────────────────────────────────

    def sort_by(
        self,
        key: Callable[[T], Any],
        *,
        descending: bool = False,
    ) -> ArtefactList[T]:
        """Return new ArtefactList sorted by key function."""
        return ArtefactList(sorted(self._items, key=key, reverse=descending))

    # ── Conversion ────────────────────────────────────────────────────────

    def to_dict(self, key: str | Callable[[T], Any] = "id") -> dict[Any, T]:
        """Convert to dict keyed by attribute name or key function."""
        if isinstance(key, str):
            attr = key
            return {getattr(item, attr): item for item in self._items}
        return {key(item): item for item in self._items}

    # ── Equality & repr ───────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ArtefactList):
            return self._items == other._items  # pyright: ignore[reportUnknownMemberType]
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._items)

    def __repr__(self) -> str:
        ids = [f"{item.agency_id}:{item.id}({item.version})" for item in self._items]
        return f"ArtefactList([{', '.join(repr(i) for i in ids)}])"
