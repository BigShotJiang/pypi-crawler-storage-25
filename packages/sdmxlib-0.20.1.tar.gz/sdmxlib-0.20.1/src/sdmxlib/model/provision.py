"""ProvisionAgreement — binds a data provider to a dataflow."""

from datetime import datetime
from typing import ClassVar

from attrs import define, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.dataflow import Dataflow
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import AnyRef, Ref


def _to_dataflow_ref(v: "Ref[Dataflow] | Dataflow | None") -> "Ref[Dataflow] | None":
    if isinstance(v, Dataflow):
        return Ref.to(v)
    return v


@define
class ProvisionAgreement(MaintainableArtefact):
    """Binds a data provider to a dataflow.

    Example:
        pa.dataflow()  # Dataflow (if resolved)
        pa.dataflow().structure()  # DataStructure
        pa.dataflow().structure.dimensions  # ItemList[Dimension]
    """

    sdmx_package: ClassVar[str] = "registry"
    sdmx_class: ClassVar[str] = "ProvisionAgreement"
    msg_field: ClassVar[str] = "provision_agreements"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    dataflow: Ref[Dataflow] | None = field(default=None, converter=_to_dataflow_ref)
    data_provider: AnyRef | None = None
