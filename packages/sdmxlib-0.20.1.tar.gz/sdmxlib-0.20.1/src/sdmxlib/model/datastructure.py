"""DataStructure and its components — Dimension, TimeDimension, Attribute, Measure, Group."""

from datetime import datetime
from enum import Enum
from typing import ClassVar

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.codelist import Code, Codelist
from sdmxlib.model.collections import ItemList
from sdmxlib.model.concept import Concept
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import Ref
from sdmxlib.model.representation import Facet
from sdmxlib.model.urn import SdmxUrn


class AttachmentLevel(Enum):
    """Where an attribute attaches within the observation structure."""

    DATASET = "dataset"
    OBSERVATION = "observation"
    SERIES = "series"
    GROUP = "group"


class ConceptIdentityMixin:
    """Typed access to the concept_identity Ref on a DSD component."""

    __slots__ = ()

    # Declared for type checking — concrete subclasses provide via attrs fields
    concept: Ref[Concept] | None

    @property
    def concept_identity(self) -> Concept:
        """The resolved Concept for this component.

        Raises TypeError if no concept reference is set.
        Raises UnresolvedRef if the concept has not been fetched.
        """
        concept = self.concept
        if not isinstance(concept, Ref):
            msg = f"No concept reference set: {concept!r}"
            raise TypeError(msg)
        return concept()


class RepresentationMixin:
    """Typed access to the codelist Ref on a DSD component."""

    __slots__ = ()

    # Declared for type checking — concrete subclasses provide via attrs fields
    concept: Ref[Concept] | None
    representation: Ref[Codelist] | Facet | None

    def __attrs_post_init__(self) -> None:
        if self.representation is None and isinstance(self.concept, Ref) and self.concept.resolved:
            core = self.concept().core_representation
            if core is not None:
                self.representation = core

    @property
    def is_enumerated(self) -> bool:
        """True if this component is constrained to a codelist."""
        return isinstance(self.representation, Ref)

    @property
    def codes(self) -> ItemList[Code] | None:
        """Codes from the resolved codelist, or None if unresolved."""
        if isinstance(self.representation, Ref) and self.representation.resolved:
            return self.representation().codes
        return None

    @property
    def codelist(self) -> Codelist:
        """The resolved Codelist for this component.

        Raises TypeError if the representation is not a codelist reference (e.g. Facet).
        Raises UnresolvedRef if the codelist has not been fetched.
        """
        representation = self.representation
        if not isinstance(representation, Ref):
            msg = f"Representation is not a codelist reference: {type(representation).__name__}"
            raise TypeError(msg)
        return representation()


def _to_concept_ref(v: "Ref[Concept] | SdmxUrn[Concept] | None") -> "Ref[Concept] | None":
    if isinstance(v, SdmxUrn):
        return Ref[Concept].unresolved(v)
    return v


def _to_codelist_ref(
    v: "Ref[Codelist] | SdmxUrn[Codelist] | Codelist | Facet | None",
) -> "Ref[Codelist] | Facet | None":
    if isinstance(v, SdmxUrn):
        return Ref[Codelist].unresolved(v)
    if isinstance(v, Codelist):
        return Ref.to(v)
    return v


def _to_dimensions(v: "ItemList[Dimension] | list[Dimension]") -> "ItemList[Dimension]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _to_attributes(v: "ItemList[Attribute] | list[Attribute]") -> "ItemList[Attribute]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _to_measures(v: "ItemList[Measure] | list[Measure]") -> "ItemList[Measure]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _to_groups(v: "ItemList[Group] | list[Group] | None") -> "ItemList[Group] | None":
    if isinstance(v, list):
        return ItemList(v)
    return v


@define
class Dimension(ConceptIdentityMixin, RepresentationMixin):
    """An identifying component of a DataStructure."""

    id: str
    concept: Ref[Concept] | None = field(default=None, converter=_to_concept_ref)
    representation: Ref[Codelist] | Facet | None = field(default=None, converter=_to_codelist_ref)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)

    @property
    def text_type(self) -> str | None:
        """Text type string if representation is Facet, else None."""
        return self.representation.type if isinstance(self.representation, Facet) else None

    @property
    def enumeration_urn(self) -> SdmxUrn[Codelist] | None:
        """URN of the referenced codelist, or None."""
        return self.representation.urn if isinstance(self.representation, Ref) else None


@define
class TimeDimension(ConceptIdentityMixin):
    """The time dimension of a DataStructure (always id=TIME_PERIOD)."""

    id: str = "TIME_PERIOD"
    concept: Ref[Concept] | None = field(default=None, converter=_to_concept_ref)
    representation: Facet | None = None
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)

    @property
    def text_type(self) -> str | None:
        """Text type from the representation, or None."""
        return self.representation.type if self.representation else None


@define
class Attribute(ConceptIdentityMixin, RepresentationMixin):
    """A descriptive component attached to an observation, series, or dataset."""

    id: str
    usage: str | None = None
    attachment: AttachmentLevel | None = None
    related_dimensions: list[str] | None = None
    related_measure: str | None = None
    concept: Ref[Concept] | None = field(default=None, converter=_to_concept_ref)
    representation: Ref[Codelist] | Facet | None = field(default=None, converter=_to_codelist_ref)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


@define
class Measure(ConceptIdentityMixin, RepresentationMixin):
    """An observed value component (PrimaryMeasure in v2.1, Measure in v3.0).

    In SDMX 2.1, a DSD has exactly one measure (``OBS_VALUE``). In SDMX 3.0+,
    a DSD may declare multiple measures — each observation then carries all
    measure values as separate columns. This covers both multi-valued
    observations (e.g. a value with confidence bounds) and wide microdata
    (e.g. census records with many variables per person).
    """

    id: str
    concept: Ref[Concept] | None = field(default=None, converter=_to_concept_ref)
    representation: Ref[Codelist] | Facet | None = field(default=None, converter=_to_codelist_ref)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


@define
class MeasureDimension(ConceptIdentityMixin, RepresentationMixin):
    """The measure dimension in an SDMX 2.1 cross-sectional DSD.

    Acts as a regular dimension whose codes name the measures present in the
    dataset (e.g. EMPLOYMENT, UNEMPLOYMENT for an LFS flow). Its presence is
    the formal SDMX 2.1 signal that data arrives in long format with one
    ``OBS_VALUE`` per row — a pivot on this dimension produces the wide
    (multi-measure) view analysts expect.

    SDMX 3.0 removes MeasureDimension entirely. Multi-measure data is instead
    modelled with multiple :class:`Measure` components in the MeasureDescriptor,
    giving each observation all measure values as columns (wide format). The
    two patterns produce different data shapes: MeasureDimension is long
    (one value per row, pivot to get wide), while 3.0 measures are natively
    columnar.
    """

    id: str
    concept: Ref[Concept] | None = field(default=None, converter=_to_concept_ref)
    representation: Ref[Codelist] | Facet | None = field(default=None, converter=_to_codelist_ref)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


@define
class Group:
    """A dimension grouping (v2.1). None for v3.0 sources."""

    id: str
    dimension_ids: list[str] = field(factory=list)


@define
class DataStructure(MaintainableArtefact):
    """Defines the shape of a dataset — dimensions, attributes, measures.

    Example:
        dsd.dimensions["FREQ"].codes  # ItemList[Code] if resolved
        dsd.code_map(lang="en")  # {dim_id: {code_id: label}}
        dsd.all_codelists  # {dim_id: Codelist}
        dsd.column_labels(lang="en")  # {dim_id: concept label}
        dsd.enumerated_dimensions  # ItemList[Dimension]
    """

    sdmx_package: ClassVar[str] = "datastructure"
    sdmx_class: ClassVar[str] = "DataStructure"
    msg_field: ClassVar[str] = "data_structures"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    dimensions: ItemList[Dimension] = field(factory=ItemList, converter=_to_dimensions)
    time_dimension: TimeDimension | None = None
    measure_dimension: MeasureDimension | None = None
    attributes: ItemList[Attribute] = field(factory=ItemList, converter=_to_attributes)
    measures: ItemList[Measure] = field(factory=ItemList, converter=_to_measures)
    groups: ItemList[Group] | None = field(default=None, converter=_to_groups)

    @property
    def components(self) -> "ItemList[Dimension | MeasureDimension | Attribute | Measure]":
        """All components: dimensions + measure_dimension (if any) + attributes + measures."""
        md: list[MeasureDimension] = [self.measure_dimension] if self.measure_dimension is not None else []
        return ItemList([*self.dimensions, *md, *self.attributes, *self.measures])

    @property
    def key_dimensions(self) -> list[Dimension | TimeDimension]:
        """Dimension components in SDMX-key order — regular dimensions then time.

        This is the canonical ordering for SDMX REST keys (e.g. ``CA+US.M.2021``).
        ``dimensions`` excludes the time dimension; this property includes it.
        """
        dims: list[Dimension | TimeDimension] = list(self.dimensions)
        if self.time_dimension is not None:
            dims.append(self.time_dimension)
        return dims

    @property
    def key_dimension_ids(self) -> list[str]:
        """Component ids in SDMX-key order. See :attr:`key_dimensions`."""
        return [d.id for d in self.key_dimensions]

    @property
    def enumerated_dimensions(self) -> ItemList[Dimension]:
        """Dimensions that are constrained to a codelist."""
        return self.dimensions.filter(lambda d: d.is_enumerated)

    @property
    def free_text_dimensions(self) -> ItemList[Dimension]:
        """Dimensions that are not enumerated."""
        return self.dimensions.filter(lambda d: not d.is_enumerated)

    @property
    def all_codelists(self) -> dict[str, Codelist]:
        """All resolved codelists keyed by component id."""
        result: dict[str, Codelist] = {}
        for comp in [*self.dimensions, *self.attributes, *self.measures]:
            if isinstance(comp.representation, Ref) and comp.representation.resolved:
                result[comp.id] = comp.codelist
        return result

    def code_map(self, *, lang: str) -> dict[str, dict[str, str]]:
        """Build ``{component_id: {code_id: label}}`` for all resolved codelists."""
        return {
            comp_id: {code.id: code.name.get(lang) or code.id for code in cl.codes}
            for comp_id, cl in self.all_codelists.items()
        }

    def column_labels(self, *, lang: str) -> dict[str, str]:
        """Map component ids to human labels from their concepts."""
        result: dict[str, str] = {}
        for comp in [*self.dimensions, *self.attributes, *self.measures]:
            if isinstance(comp.concept, Ref) and comp.concept.resolved:
                result[comp.id] = comp.concept_identity.name.get(lang) or comp.id
            else:
                result[comp.id] = comp.id
        return result

    def add(
        self,
        items: "Dimension | MeasureDimension | Attribute | Measure | list[Dimension | MeasureDimension | Attribute | Measure]",  # noqa: E501
    ) -> "DataStructure":
        """Return a new DataStructure with *items* added to the appropriate list(s).

        Dispatches by type — dimensions go to dimensions, attributes to
        attributes, measures to measures. Accepts a single component or a
        mixed list.

        Example:
            dsd = dsd.add(sl.Dimension(id="PARTNER", representation=cl))
            dsd = dsd.add([sl.Dimension(id="PARTNER", representation=cl),
                           sl.Attribute(id="OBS_STATUS")])
        """
        item_list = [items] if not isinstance(items, list) else items
        dims = list(self.dimensions)
        attrs = list(self.attributes)
        meas = list(self.measures)
        md = self.measure_dimension
        for item in item_list:
            match item:
                case MeasureDimension():
                    md = item
                case Dimension():
                    dims.append(item)
                case Attribute():
                    attrs.append(item)
                case Measure():
                    meas.append(item)
        return evolve(self, dimensions=dims, measure_dimension=md, attributes=attrs, measures=meas)

    def drop(self, component_ids: str | list[str]) -> "DataStructure":
        """Return a new DataStructure with the given component(s) removed.

        Searches dimensions, attributes, and measures by id.
        Accepts a single id string or a list of id strings.
        Raises KeyError if any id is not found in any component list.

        Example:
            dsd = dsd.drop("SECTOR")
            dsd = dsd.drop(["SECTOR", "OBS_STATUS"])
        """
        ids = [component_ids] if isinstance(component_ids, str) else list(component_ids)
        all_ids = {d.id for d in self.dimensions} | {a.id for a in self.attributes} | {m.id for m in self.measures}
        missing = [i for i in ids if i not in all_ids]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(
            self,
            dimensions=[d for d in self.dimensions if d.id not in id_set],
            attributes=[a for a in self.attributes if a.id not in id_set],
            measures=[m for m in self.measures if m.id not in id_set],
        )
