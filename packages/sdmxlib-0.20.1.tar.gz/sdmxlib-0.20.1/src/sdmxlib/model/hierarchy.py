"""Hierarchy, HierarchicalCode, and Level — cross-codelist hierarchical views.

SDMX 3.0 artefact that replaces HierarchicalCodelist from 2.1.
SDMX 3.1 adds Level support for explicit level structures.
The 2.1 reader maps the older structure into this model.
"""

from datetime import datetime
from typing import ClassVar

from attrs import define, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.codelist import Code
from sdmxlib.model.collections import ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn


@define
class Level:
    """A named level in a Hierarchy (SDMX 3.1).

    Hierarchies that declare levels allow each ``HierarchicalCode`` node
    to explicitly state which structural level it belongs to — rather
    than inferring level from tree depth or code ID patterns.

    Example:
        hierarchy.levels["SECTOR"]        # Level lookup by id
        node.level                         # Level | None
    """

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


def _to_levels(v: "ItemList[Level] | list[Level]") -> "ItemList[Level]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _to_hcode_ref(v: "Ref[Code] | SdmxUrn[Code] | None") -> "Ref[Code] | None":
    if isinstance(v, SdmxUrn):
        return Ref[Code].unresolved(v)
    return v


def _to_hcodes(v: "ItemList[HierarchicalCode] | list[HierarchicalCode]") -> "ItemList[HierarchicalCode]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _to_tree(v: "ItemList[HierarchicalCode] | list[HierarchicalCode]") -> "ItemList[HierarchicalCode]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class HierarchicalCode:
    """A node in a Hierarchy tree, referencing a code from a Codelist.

    Provides tree navigation via ``children`` and flat lookup via the
    parent ``Hierarchy.codes`` index.

    Example:
        node = hierarchy.tree["CANADA"]
        node.children["ON"]           # tree navigation
        hierarchy.codes["ON"]          # flat O(1) lookup
        node.code()                    # Ref[Code] unwrap → Code
    """

    id: str
    code: Ref[Code] | None = field(default=None, converter=_to_hcode_ref)
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    children: "ItemList[HierarchicalCode]" = field(factory=ItemList, converter=_to_hcodes)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    level: Level | None = None


def _flatten_nodes(nodes: ItemList["HierarchicalCode"]) -> ItemList["HierarchicalCode"]:
    """Recursively collect all nodes into a flat ItemList."""
    result: list[HierarchicalCode] = []

    def _walk(node: HierarchicalCode) -> None:
        result.append(node)
        for child in node.children:
            _walk(child)

    for node in nodes:
        _walk(node)
    return ItemList(result)


@define
class Hierarchy(MaintainableArtefact):
    """A standalone hierarchy of codes from one or more codelists.

    Provides two access patterns:

    - ``tree``: top-level entry points (roots) with ``children`` navigation
    - ``codes``: flat O(1) index over ALL nodes in the hierarchy

    Example:
        hierarchy.tree["CANADA"].children["ON"]  # tree navigation
        hierarchy.codes["OTTAWA"]                 # flat lookup
        hierarchy.codes["OTTAWA"].code()          # Ref[Code] unwrap → Code
    """

    sdmx_package: ClassVar[str] = "codelist"
    sdmx_class: ClassVar[str] = "Hierarchy"
    msg_field: ClassVar[str] = "hierarchies"

    id: str = ""
    maintainer: Agency = field(factory=lambda: Agency(id=""), converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    levels: ItemList[Level] = field(factory=ItemList, converter=_to_levels)
    tree: ItemList[HierarchicalCode] = field(factory=ItemList, converter=_to_tree)
    _codes: ItemList[HierarchicalCode] = field(init=False, repr=False, factory=ItemList)

    def __attrs_post_init__(self) -> None:
        self._codes = _flatten_nodes(self.tree)

    @property
    def codes(self) -> ItemList[HierarchicalCode]:
        """Flat index of ALL nodes in the hierarchy. O(1) lookup by id."""
        return self._codes

    @property
    def is_leveled(self) -> bool:
        """True if this hierarchy declares explicit levels (SDMX 3.1)."""
        return len(self.levels) > 0
