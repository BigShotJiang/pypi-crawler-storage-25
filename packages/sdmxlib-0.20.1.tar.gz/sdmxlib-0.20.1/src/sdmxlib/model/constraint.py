"""DataConstraint, CubeRegion, and supporting types."""

from datetime import datetime
from typing import ClassVar

from attrs import define, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import AnyRef


@define
class KeyValue:
    """A dimension constraint: the set of allowed values for one dimension."""

    dimension_id: str
    values: frozenset[str] = field(factory=frozenset)


@define
class CubeRegion:
    """A region in the hypercube defined by per-dimension allowed values."""

    include: bool = True
    keys: tuple[KeyValue, ...] = ()

    def allows(self, key: dict[str, str]) -> bool:
        """Return True if *key* is permitted by this region."""
        for kv in self.keys:
            if kv.dimension_id in key and key[kv.dimension_id] not in kv.values:
                return not self.include
        return self.include


@define
class ReferencePeriod:
    """Time period bounds for a constraint's data coverage."""

    start_period: datetime
    end_period: datetime


@define
class ReleaseCalendar:
    """Release schedule information for a constraint.

    All fields are ISO 8601 duration strings (e.g. ``"P1M"``, ``"P1M15D"``).
    """

    periodicity: str
    offset: str
    tolerance: str


@define
class ConstraintAttachment:
    """The artefact(s) to which a DataConstraint is attached."""

    dataflow: AnyRef | None = None
    data_structure: AnyRef | None = None
    provision_agreement: AnyRef | None = None


@define
class DataConstraint(MaintainableArtefact):
    """A constraint that limits the valid key combinations for a dataflow."""

    sdmx_package: ClassVar[str] = "registry"
    sdmx_class: ClassVar[str] = "DataConstraint"
    msg_field: ClassVar[str] = "constraints"

    id: str = ""
    maintainer: Agency = field(factory=lambda: Agency(id=""), converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    constraint_type: str = "Allowed"
    attachment: ConstraintAttachment = field(factory=ConstraintAttachment)
    regions: tuple[CubeRegion, ...] = ()
    reference_period: ReferencePeriod | None = None
    release_calendar: ReleaseCalendar | None = None
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None

    def allows(self, key: dict[str, str]) -> bool:
        """Return True if *key* satisfies all CubeRegions in this constraint."""
        return all(region.allows(key) for region in self.regions)
