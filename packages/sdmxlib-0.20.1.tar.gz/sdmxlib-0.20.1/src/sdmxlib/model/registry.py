"""Registry — Protocol for SDMX artefact sources.

A *Registry* is anything that can produce an SDMX artefact given its URN.
The Protocol is the seam shared by every backend: the in-memory store
(:class:`~sdmxlib.model.in_memory_registry.InMemoryRegistry`), the
DuckDB-backed local store (:class:`~sdmxlib.local.LocalRegistry`), the
HTTP-backed REST client (:class:`~sdmxlib.api.RestRegistry`), and any
future federated dispatcher.

Two methods cover what every consumer needs:

- ``get(urn) → Artefact | None`` — look up by URN, ``None`` on miss.
- ``__contains__(urn) → bool`` — membership check.

Higher-level operations (transitive resolution, bulk fetch, browse) are
specific to particular registries and live on those concrete classes,
not on the Protocol.

Example::

    def lookup(reg: Registry, urn: SdmxUrn) -> Codelist | None:
        return reg.get(urn)


    # Works for any backend:
    lookup(in_memory_reg, urn)
    lookup(local_reg, urn)
    lookup(rest_reg, urn)  # once RestRegistry conforms (Phase C)
"""

from typing import Protocol, runtime_checkable

from sdmxlib.model.in_memory_registry import InMemoryRegistry, artefact_urn
from sdmxlib.model.urn import SdmxUrn


@runtime_checkable
class Registry(Protocol):
    """A URN-keyed source of SDMX artefacts.

    Minimal Protocol — implementations may offer richer APIs (transitive
    resolution, bulk fetch, browse) but every Registry must support these
    two operations so federation dispatchers can compose them uniformly.
    """

    def get[T](self, urn: SdmxUrn[T]) -> T | None:
        """Look up an artefact by URN. Returns ``None`` if absent."""
        ...

    def __contains__(self, urn: object) -> bool:
        """True if an artefact with this URN is available from this source."""
        ...


__all__ = [
    "InMemoryRegistry",
    "Registry",
    "artefact_urn",
]
