"""SdmxUrn[T] — typed artefact identity.

T is a phantom type parameter — no field stores it. It exists so the type
checker can carry the target type through ``reg.fetch(urn) -> T``.
"""

import re
from typing import Any, ClassVar

from attrs import frozen

# urn:sdmx:org.sdmx.infomodel.<package>.<Class>=<AGENCY>:<ID>(<version>)
# optional item suffix: .<item_id>
_URN_RE = re.compile(
    r"urn:sdmx:org\.sdmx\.infomodel\.(?P<package>[^.]+)\.(?P<artefact_class>[^=]+)"
    r"=(?P<agency>[^:]+):(?P<id>[^.(]+)(?:\((?P<version>[^)]+)\))?(?:\.(?P<item_id>.+))?$"
)

# SDMX 2.1 / 3.0 formal type patterns from SDMXCommonReferences.xsd
# IDType:       [A-Za-z0-9_@$-]+
# NestedIDType: [A-Za-z0-9_@$-]+(\.[A-Za-z0-9_@$-]+)*   (dots for agency hierarchy)
_PACKAGE_RE = re.compile(r"^[a-z][a-z_]*$")
_CLASS_RE = re.compile(r"^[A-Z][A-Za-z]+$")
_AGENCY_RE = re.compile(r"^[A-Za-z0-9_@$-]+(\.[A-Za-z0-9_@$-]+)*$")
_ID_RE = re.compile(r"^[A-Za-z0-9_@$-]+$")


@frozen
class SdmxUrn[T]:
    """Globally unique identifier for an SDMX artefact.

    ``T`` is a phantom type — not stored at runtime, used by the type
    checker to propagate the target type through
    ``reg.fetch(urn: SdmxUrn[T]) -> T``.

    Example:
        SdmxUrn.parse("urn:sdmx:org.sdmx.infomodel.codelist.Codelist=SDMX:CL_FREQ(1.0)")
        SdmxUrn.make(
            Codelist,
            package="codelist",
            artefact_class="Codelist",
            agency="SDMX",
            id="CL_FREQ",
            version="1.0",
        )
    """

    _PACKAGE_PREFIX: ClassVar[str] = "urn:sdmx:org.sdmx.infomodel"

    package: str
    artefact_class: str
    agency: str
    id: str
    version: str = "latest"
    item_id: str | None = None

    # ── Factories ─────────────────────────────────────────────────────────

    @classmethod
    def parse(cls, urn: str) -> "SdmxUrn[Any]":
        """Parse a full URN string. Returns unparameterised SdmxUrn."""
        m = _URN_RE.match(urn)
        if not m:
            msg = f"Invalid SDMX URN: {urn!r}"
            raise ValueError(msg)
        return cls(
            package=m.group("package"),
            artefact_class=m.group("artefact_class"),
            agency=m.group("agency"),
            id=m.group("id"),
            version=m.group("version") or "latest",
            item_id=m.group("item_id"),
        )

    @classmethod
    def make[U](
        cls,
        artefact_type: type[U],  # noqa: ARG003  # phantom type witness; unused at runtime
        /,
        *,
        package: str,
        artefact_class: str,
        agency: str,
        id: str,  # noqa: A002
        version: str = "latest",
        item_id: str | None = None,
    ) -> "SdmxUrn[U]":
        """Low-level factory with basic validation.

        ``artefact_type`` is a phantom type witness — unused at runtime,
        used by the type checker to bind ``U`` and propagate the artefact
        type through ``session.get`` and ``session.extract``.
        """
        if not _AGENCY_RE.match(agency):
            msg = f"Invalid agency id: {agency!r}"
            raise ValueError(msg)
        if not _ID_RE.match(id):
            msg = f"Invalid artefact id: {id!r}"
            raise ValueError(msg)
        return cls(  # type: ignore[return-value]
            package=package,
            artefact_class=artefact_class,
            agency=agency,
            id=id,
            version=version,
            item_id=item_id,
        )

    # ── String representation ──────────────────────────────────────────────

    def __str__(self) -> str:
        """Round-trip to full URN string."""
        base = f"{self._PACKAGE_PREFIX}.{self.package}.{self.artefact_class}={self.agency}:{self.id}"
        if self.version and self.version != "latest":
            base = f"{base}({self.version})"
        if self.item_id:
            base = f"{base}.{self.item_id}"
        return base

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def is_latest(self) -> bool:
        """True if version is the sentinel "latest"."""
        return self.version == "latest"

    @property
    def is_item_urn(self) -> bool:
        """True if this URN points to an item within a scheme (e.g. a Code)."""
        return self.item_id is not None
