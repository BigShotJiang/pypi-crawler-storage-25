"""Organisation types — Agency, DataProvider, AgencyScheme, DataProviderScheme."""

from datetime import datetime
from typing import ClassVar

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotation, Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.collections import ItemList
from sdmxlib.model.istring import InternationalString


def _to_istring(v: InternationalString | dict[str, str]) -> InternationalString:
    return InternationalString.of(v) if isinstance(v, dict) else v


def _to_annotations(v: Annotations | list[Annotation]) -> Annotations:
    return Annotations(v) if isinstance(v, list) else v


@define
class Contact:
    """Contact information for an agency or data provider."""

    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    department: InternationalString = field(factory=InternationalString, converter=_to_istring)
    role: InternationalString = field(factory=InternationalString, converter=_to_istring)
    phones: tuple[str, ...] = ()
    faxes: tuple[str, ...] = ()
    uris: tuple[str, ...] = ()
    emails: tuple[str, ...] = ()


@define
class Agency:
    """An organisation that maintains SDMX artefacts."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    contacts: tuple[Contact, ...] = ()
    parent: "Agency | None" = None
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


def _to_agency(v: "Agency | str") -> "Agency":
    return Agency(id=v) if isinstance(v, str) else v


def _to_item_list_agency(v: "ItemList[Agency] | list[Agency]") -> "ItemList[Agency]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _to_item_list_provider(v: "ItemList[DataProvider] | list[DataProvider]") -> "ItemList[DataProvider]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class DataProvider:
    """An organisation that provides data under a ProvisionAgreement."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    contacts: tuple[Contact, ...] = ()
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


@define
class AgencyScheme(MaintainableArtefact):
    """Maintainable container for Agency items."""

    sdmx_package: ClassVar[str] = "base"
    sdmx_class: ClassVar[str] = "AgencyScheme"
    msg_field: ClassVar[str] = "agency_schemes"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    agencies: ItemList[Agency] = field(factory=ItemList, converter=_to_item_list_agency)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None

    def add(self, agencies: "Agency | list[Agency]") -> "AgencyScheme":
        """Return a new AgencyScheme with *agencies* added.

        Accepts a single Agency or a list of Agencies.
        """
        new = [agencies] if isinstance(agencies, Agency) else list(agencies)
        return evolve(self, agencies=[*self.agencies, *new])

    def drop(self, agency_ids: str | list[str]) -> "AgencyScheme":
        """Return a new AgencyScheme with the given agency(ies) removed.

        Accepts a single id string or a list of id strings.
        Raises KeyError if any id is not present.
        """
        ids = [agency_ids] if isinstance(agency_ids, str) else list(agency_ids)
        missing = [i for i in ids if i not in self.agencies]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(self, agencies=[a for a in self.agencies if a.id not in id_set])


@define
class DataProviderScheme(MaintainableArtefact):
    """Maintainable container for DataProvider items."""

    sdmx_package: ClassVar[str] = "base"
    sdmx_class: ClassVar[str] = "DataProviderScheme"
    msg_field: ClassVar[str] = "data_provider_schemes"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    providers: ItemList[DataProvider] = field(factory=ItemList, converter=_to_item_list_provider)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None

    def add(self, providers: "DataProvider | list[DataProvider]") -> "DataProviderScheme":
        """Return a new DataProviderScheme with *providers* added.

        Accepts a single DataProvider or a list of DataProviders.
        """
        new = [providers] if isinstance(providers, DataProvider) else list(providers)
        return evolve(self, providers=[*self.providers, *new])

    def drop(self, provider_ids: str | list[str]) -> "DataProviderScheme":
        """Return a new DataProviderScheme with the given provider(s) removed.

        Accepts a single id string or a list of id strings.
        Raises KeyError if any id is not present.
        """
        ids = [provider_ids] if isinstance(provider_ids, str) else list(provider_ids)
        missing = [i for i in ids if i not in self.providers]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(self, providers=[p for p in self.providers if p.id not in id_set])
