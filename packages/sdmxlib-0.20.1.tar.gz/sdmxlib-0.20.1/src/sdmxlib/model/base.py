"""MaintainableArtefact mixin — provides the .urn() classmethod."""

from typing import TYPE_CHECKING, ClassVar, Self

from sdmxlib.model.urn import SdmxUrn

if TYPE_CHECKING:
    from sdmxlib.model.organisation import Agency


class MaintainableArtefact:
    """Mixin for top-level SDMX artefacts that have a globally unique URN.

    Subclasses must declare ``sdmx_package`` and ``sdmx_class`` as
    class variables. The ``.urn()`` classmethod then constructs a typed
    ``SdmxUrn[Self]`` without repeating the logic in every class.

    NOTE: Subclasses must redeclare the standard fields (id, maintainer,
    version, name, description, is_final, annotations) because slotted
    dataclasses cannot inherit slots from a non-dataclass parent.
    Python requires that all ``__slots__`` are declared on the class that
    uses them.

    Example:
        Codelist.urn(agency="SDMX", id="CL_FREQ")  # SdmxUrn[Codelist]
        DataStructure.urn(agency="ESTAT", id="CPI", version="2.0")
    """

    sdmx_package: ClassVar[str]
    sdmx_class: ClassVar[str]
    msg_field: ClassVar[str]

    # Declared for type checking — concrete subclasses provide via dataclass fields
    maintainer: "Agency | str"

    @property
    def agency_id(self) -> str:
        """Maintainer agency identifier. Derived from the ``maintainer`` field."""
        # After __post_init__, maintainer is always Agency (str is coerced)
        m = self.maintainer
        if isinstance(m, str):
            return m
        return m.id

    @classmethod
    def urn(
        cls,
        *,
        agency: str,
        id: str,  # noqa: A002
        version: str = "latest",
    ) -> SdmxUrn[Self]:
        """Construct a typed SdmxUrn for this artefact class."""
        return SdmxUrn.make(
            cls,
            package=cls.sdmx_package,
            artefact_class=cls.sdmx_class,
            agency=agency,
            id=id,
            version=version,
        )

    @classmethod
    def parse_rest_ref(cls, ref: str) -> SdmxUrn[Self]:
        """Parse an SDMX REST comma-separated artefact reference.

        SDMX REST URLs identify a maintainable artefact as
        ``AGENCY,ID,VERSION``. Symmetric with :meth:`urn`.

        Example:
            Dataflow.parse_rest_ref("ESTAT,STS_INPR_M,1.0")

        Args:
            ref: Comma-separated ``AGENCY,ID,VERSION`` string.

        Returns:
            A typed :class:`SdmxUrn` for this artefact class.

        Raises:
            ValueError: If ``ref`` does not have exactly three
                comma-separated parts.
        """
        parts = ref.split(",")
        if len(parts) != 3:
            msg = f"REST ref {ref!r} must be 'AGENCY,ID,VERSION' (got {len(parts)} parts)"
            raise ValueError(msg)
        agency, id_, version = parts
        return cls.urn(agency=agency, id=id_, version=version)
