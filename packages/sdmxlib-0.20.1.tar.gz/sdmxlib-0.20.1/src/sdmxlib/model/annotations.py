"""Annotation and Annotations — SDMX annotation support."""

from collections.abc import Iterator, Sequence
from typing import overload

from attrs import define, field

from sdmxlib.model.istring import InternationalString


def _to_istring(v: InternationalString | dict[str, str]) -> InternationalString:
    return InternationalString.of(v) if isinstance(v, dict) else v


@define
class Annotation:
    """A single SDMX annotation attached to an artefact or item."""

    id: str | None = None
    title: str | None = None
    type: str | None = None
    url: str | None = None
    text: InternationalString = field(factory=InternationalString, converter=_to_istring)


class Annotations(Sequence[Annotation]):
    """Immutable collection of Annotation with type-based querying.

    Example:
        "DEPRECATED" in annotations  # checks annotation type
        annotations.by_type("CONTACT")  # list[Annotation]
        annotations.first("CONTACT")  # Annotation | None
        annotations.types  # list[str]
    """

    __slots__ = ("_items",)

    def __init__(self, items: list[Annotation] | None = None) -> None:
        self._items: tuple[Annotation, ...] = tuple(items or [])

    # ── Sequence ──────────────────────────────────────────────────────────

    @overload
    def __getitem__(self, index: int) -> Annotation: ...

    @overload
    def __getitem__(self, index: slice) -> "Annotations": ...

    def __getitem__(self, index: int | slice) -> "Annotation | Annotations":
        if isinstance(index, slice):
            return Annotations(list(self._items[index]))
        return self._items[index]

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self) -> Iterator[Annotation]:
        return iter(self._items)

    def __bool__(self) -> bool:
        return bool(self._items)

    # ── Type-based querying ───────────────────────────────────────────────

    def __contains__(self, key: object) -> bool:
        """True if any annotation has type == key."""
        if isinstance(key, str):
            return any(a.type == key for a in self._items)
        return super().__contains__(key)

    def by_type(self, annotation_type: str) -> list[Annotation]:
        """All annotations with the given type."""
        return [a for a in self._items if a.type == annotation_type]

    def first(self, annotation_type: str) -> Annotation | None:
        """First annotation with the given type, or None."""
        for a in self._items:
            if a.type == annotation_type:
                return a
        return None

    @property
    def types(self) -> list[str]:
        """All type values present (deduplicated, order preserved)."""
        seen: set[str] = set()
        result: list[str] = []
        for a in self._items:
            if a.type and a.type not in seen:
                seen.add(a.type)
                result.append(a.type)
        return result

    # ── Equality & repr ───────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Annotations):
            return self._items == other._items
        return NotImplemented

    __hash__ = None  # type: ignore[assignment]  # mutable container, explicitly unhashable

    def __repr__(self) -> str:
        return f"Annotations([{', '.join(repr(a) for a in self._items)}])"
