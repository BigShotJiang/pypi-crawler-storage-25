"""InternationalString — dict-like multilingual string."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterator


class InternationalString:
    """A multilingual string where language access is always explicit.

    Stores key-value pairs of language code → text. Immutable after
    construction (no ``__setitem__``).

    Example:
        s = InternationalString(en="Annual", fr="Annuel")
        s["en"]  # "Annual"
        s.get("de", "en")  # "Annual" (fallback)
        "fr" in s  # True
        s.langs  # ["en", "fr"]
    """

    __slots__ = ("_data",)

    def __init__(self, **kwargs: str) -> None:
        self._data: dict[str, str] = dict(kwargs)

    # ── Construction helpers ───────────────────────────────────────────────

    @classmethod
    def of(cls, pairs: dict[str, str]) -> InternationalString:
        """Build from an existing dict."""
        obj = cls.__new__(cls)
        obj._data = dict(pairs)  # noqa: SLF001
        return obj

    # ── Access ────────────────────────────────────────────────────────────

    def __getitem__(self, lang: str) -> str:
        """Return the string for *lang*, raising KeyError if absent."""
        return self._data[lang]

    def get(self, *langs: str) -> str | None:
        """Return the first available language in priority order, or None."""
        for lang in langs:
            if lang in self._data:
                return self._data[lang]
        return None

    def __contains__(self, lang: object) -> bool:
        return lang in self._data

    def __iter__(self) -> Iterator[str]:
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __bool__(self) -> bool:
        return bool(self._data)

    @property
    def langs(self) -> list[str]:
        """List of available language codes."""
        return list(self._data)

    # ── Equality & repr ───────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if isinstance(other, InternationalString):
            return self._data == other._data
        return NotImplemented

    def __hash__(self) -> int:
        return hash(tuple(sorted(self._data.items())))

    def __repr__(self) -> str:
        pairs = ", ".join(f"{k}={v!r}" for k, v in self._data.items())
        return f"InternationalString({pairs})"
