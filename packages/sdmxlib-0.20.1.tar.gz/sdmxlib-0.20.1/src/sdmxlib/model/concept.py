"""ConceptScheme and Concept — semantic meaning of components."""

from datetime import datetime
from typing import ClassVar

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.collections import ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import Ref
from sdmxlib.model.representation import Representation
from sdmxlib.model.urn import SdmxUrn


def _to_concepts(v: "ItemList[Concept] | list[Concept]") -> "ItemList[Concept]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class Concept:
    """The semantic meaning of a DSD component (e.g. "Frequency", "Reference Area")."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    core_representation: Representation = None
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)

    @classmethod
    def urn(
        cls,
        *,
        agency: str,
        scheme: str,
        id: str,  # noqa: A002
        version: str = "latest",
    ) -> "SdmxUrn[Concept]":
        """Build an item-level URN for a Concept within a ConceptScheme.

        Hides the SDMX package/class internals. Maps the caller's intuitive
        ``scheme`` / ``id`` parameters to the URN's ``id`` / ``item_id`` fields.

        Example:
            Concept.urn(agency="SDMX", scheme="CROSS_DOMAIN_CONCEPTS", id="FREQ")
            # urn:sdmx:org.sdmx.infomodel.conceptscheme.Concept=SDMX:CROSS_DOMAIN_CONCEPTS(latest).FREQ
        """
        return SdmxUrn.make(
            Concept,
            package="conceptscheme",
            artefact_class="Concept",
            agency=agency,
            id=scheme,
            version=version,
            item_id=id,
        )


@define
class ConceptScheme(MaintainableArtefact):
    """An ordered collection of Concepts maintained by an agency."""

    sdmx_package: ClassVar[str] = "conceptscheme"
    sdmx_class: ClassVar[str] = "ConceptScheme"
    msg_field: ClassVar[str] = "concept_schemes"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    concepts: ItemList[Concept] = field(factory=ItemList, converter=_to_concepts)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None

    def add(self, concepts: "Concept | list[Concept]") -> "ConceptScheme":
        """Return a new ConceptScheme with *concepts* added.

        Accepts a single Concept or a list of Concepts.
        """
        new = [concepts] if isinstance(concepts, Concept) else list(concepts)
        return evolve(self, concepts=[*self.concepts, *new])

    def drop(self, concept_ids: str | list[str]) -> "ConceptScheme":
        """Return a new ConceptScheme with the given concept(s) removed.

        Accepts a single id string or a list of id strings.
        Raises KeyError if any id is not present.
        """
        ids = [concept_ids] if isinstance(concept_ids, str) else list(concept_ids)
        missing = [i for i in ids if i not in self.concepts]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(self, concepts=[c for c in self.concepts if c.id not in id_set])

    def ref_to(self, concept_id: str) -> Ref[Concept]:
        """Build a resolved Ref to a concept within this scheme.

        Raises KeyError if concept_id is not present.

        Example:
            cs = ConceptScheme(id="CS_COMMON", maintainer="SDMX", version="1.0",
                               concepts=ItemList([Concept(id="FREQ")]))
            ref = cs.ref_to("FREQ")
            ref()  # Concept(id="FREQ", ...)
        """
        concept = self.concepts[concept_id]
        urn: SdmxUrn[Concept] = SdmxUrn.make(
            Concept,
            package="conceptscheme",
            artefact_class="Concept",
            agency=self.agency_id,
            id=self.id,
            version=self.version,
            item_id=concept_id,
        )
        return Ref[Concept].of(urn, concept)
