"""DataflowBinding — first-class artefact linking a Dataflow to a data table.

A binding records the mapping between a Dataflow's structural definition
(DSD dimensions, measures, attributes) and a concrete data location, plus
provenance for staleness detection. Federated catalogs use bindings to
answer "where do the observations for this dataflow live?" without the
caller needing to know about the underlying storage.

The binding artefact is local-store-owned: a Dataflow may live in a
remote registry (FMR, ESTAT, ECB), but the binding to a Parquet/DuckLake
table lives in the local registry that knows about the data.

Example:
    binding = DataflowBinding(
        dataflow=Ref[Dataflow].unresolved(dataflow_urn),
        table_location="lake.census_2021.observations",
        partition_layout=("GEO_LEVEL",),
        dimension_column_map={"REF_AREA": "REF_AREA", "TIME_PERIOD": "TIME_PERIOD"},
        measure_column_map={"OBS_COUNT": "OBS_COUNT"},
        attribute_column_map={"GEO_NAME": "GEO_NAME"},
        structural_version="STATCAN:CENSUS_DSD(2021)",
        source_registry="local",
        materialized_at=now,
        bound_at=now,
    )
    local.add(binding)
"""

from datetime import datetime
from typing import TYPE_CHECKING, ClassVar, Self

from attrs import define, field, frozen

from sdmxlib.model.dataflow import Dataflow
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn

if TYPE_CHECKING:
    from sdmxlib.model.registry import Registry


@define(kw_only=True)
class DataflowBinding:
    """Binding between an SDMX dataflow and a concrete data table.

    Attributes:
        dataflow: Ref to the bound dataflow (may be remote).
        table_location: Backend-specific table identifier — for DuckLake
            this is ``catalog.schema.table``; for raw Parquet this might
            be a path or URI.
        partition_layout: SDMX dimension ids the table is partitioned on,
            in partition order. Drives partition pruning at query time.
        dimension_column_map: SDMX dimension id → table column name.
            Identity mapping is the common case.
        measure_column_map: SDMX measure id → table column name.
        attribute_column_map: SDMX attribute id → table column name.
        structural_version: ``agency:id(version)`` tag of the DSD/codelists
            the data was written against. Comparing against the live
            registry detects "structural side has moved on, data is stale"
            without re-reading the table.
        source_registry: Provenance label for the structural side
            (e.g. ``"local"``, ``"ESTAT"``, ``"ECB"``).
        materialized_at: When the data was last refreshed.
        bound_at: When this binding record was created.
        series_attributes_location: Optional sidecar table for series-level
            attributes that are constant across (REF_AREA, TIME_PERIOD)
            slices and would otherwise bloat the fact table 5x if
            denormalised in. Same shape as ``table_location``.
    """

    sdmx_package: ClassVar[str] = "binding"
    sdmx_class: ClassVar[str] = "DataflowBinding"

    dataflow: Ref[Dataflow]
    table_location: str
    partition_layout: tuple[str, ...] = field(factory=tuple, converter=tuple)
    dimension_column_map: dict[str, str] = field(factory=dict)
    measure_column_map: dict[str, str] = field(factory=dict)
    attribute_column_map: dict[str, str] = field(factory=dict)
    structural_version: str
    source_registry: str
    materialized_at: datetime
    bound_at: datetime
    series_attributes_location: str | None = None

    # ── HasUrn conformance — derived from the bound dataflow's identity ──

    @property
    def agency_id(self) -> str:
        """Agency of the bound dataflow."""
        return self.dataflow.urn.agency

    @property
    def id(self) -> str:
        """Id of the bound dataflow (the binding shares the dataflow's identity)."""
        return self.dataflow.urn.id

    @property
    def version(self) -> str:
        """Version of the bound dataflow."""
        return self.dataflow.urn.version

    # ── Typed URN helper ─────────────────────────────────────────────────

    @classmethod
    def urn(
        cls,
        *,
        agency: str,
        id: str,  # noqa: A002
        version: str = "1.0",
    ) -> SdmxUrn[Self]:
        """Construct a typed ``SdmxUrn[DataflowBinding]``.

        The binding's URN mirrors the bound dataflow's identity — one
        binding per dataflow per version.
        """
        return SdmxUrn.make(
            cls,
            package=cls.sdmx_package,
            artefact_class=cls.sdmx_class,
            agency=agency,
            id=id,
            version=version,
        )


# ── Drift detection ─────────────────────────────────────────────────────


@frozen
class DriftIssue:
    """A single drift between a binding's pinned structural state and the live registry.

    Attributes:
        kind: Stable identifier for the kind of drift. v1 vocabulary:
            ``"dataflow_missing"`` (the dataflow has disappeared from
            the registry), ``"dsd_unresolvable"`` (the dataflow exists
            but its DSD reference can't be resolved), and
            ``"structural_version_drift"`` (the binding's pinned DSD
            version differs from the current one).
        binding_urn: URN of the binding the issue relates to.
        description: Human-readable explanation including before/after
            values where relevant.
    """

    kind: str
    binding_urn: str
    description: str


def validate_binding(binding: DataflowBinding, registry: "Registry") -> list[DriftIssue]:
    """Check a binding against a structural registry for drift.

    v1 reports three drift kinds (see :class:`DriftIssue`). Detailed
    codelist content diffs (added codes / removed codes / renamed
    labels) are intentionally deferred — the v1 ``structural_version``
    pin is enough to surface the case operationally.

    Args:
        binding: The :class:`DataflowBinding` to validate.
        registry: The structural source. Typically a
            :class:`~sdmxlib.api.federated.FederatedRegistry` or a
            :class:`~sdmxlib.local.LocalRegistry`.

    Returns:
        A list of :class:`DriftIssue` — empty if the pinned structural
        state matches the current registry view.
    """
    binding_urn = str(
        DataflowBinding.urn(
            agency=binding.agency_id,
            id=binding.id,
            version=binding.version,
        ),
    )
    issues: list[DriftIssue] = []

    flow = registry.get(binding.dataflow.urn)
    if flow is None:
        issues.append(
            DriftIssue(
                kind="dataflow_missing",
                binding_urn=binding_urn,
                description=(
                    f"Dataflow {binding.dataflow.urn} not found in the registry. "
                    "The bound dataflow may have been retired or routed to a different source."
                ),
            ),
        )
        return issues

    if not isinstance(flow, Dataflow) or flow.structure is None:
        issues.append(
            DriftIssue(
                kind="dsd_unresolvable",
                binding_urn=binding_urn,
                description=(
                    f"Dataflow {binding.dataflow.urn} has no resolvable DSD reference; cannot validate structural pin."
                ),
            ),
        )
        return issues

    structure_ref = flow.structure
    if not isinstance(structure_ref, Ref):
        issues.append(
            DriftIssue(
                kind="dsd_unresolvable",
                binding_urn=binding_urn,
                description=(
                    f"Dataflow {binding.dataflow.urn} structure is not a Ref; cannot determine the current DSD URN."
                ),
            ),
        )
        return issues

    current_dsd_urn = structure_ref.urn
    current_version = f"{current_dsd_urn.agency}:{current_dsd_urn.id}({current_dsd_urn.version})"

    if current_version != binding.structural_version:
        issues.append(
            DriftIssue(
                kind="structural_version_drift",
                binding_urn=binding_urn,
                description=(
                    f"Binding pinned to {binding.structural_version}, "
                    f"current DSD URN is {current_version}. "
                    "Re-bind against the current DSD or accept stale labels."
                ),
            ),
        )

    return issues
