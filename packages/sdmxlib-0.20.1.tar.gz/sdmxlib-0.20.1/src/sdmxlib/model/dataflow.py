"""Dataflow — a published data product backed by a DataStructure."""

from datetime import datetime
from typing import ClassVar

from attrs import define, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.datastructure import DataStructure
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn


def _to_structure(
    v: "Ref[DataStructure] | DataStructure | SdmxUrn[DataStructure] | None",
) -> "Ref[DataStructure] | None":
    if isinstance(v, SdmxUrn):
        return Ref[DataStructure].unresolved(v)
    if isinstance(v, DataStructure):
        return Ref.to(v)
    return v


@define
class Dataflow(MaintainableArtefact):
    """A published data product backed by a DataStructure.

    Example:
        df.structure  # Ref[DataStructure]
        df.structure()  # DataStructure (if resolved)
        df.structure.dimensions  # convenience via resolved structure
    """

    sdmx_package: ClassVar[str] = "datastructure"
    sdmx_class: ClassVar[str] = "Dataflow"
    msg_field: ClassVar[str] = "dataflows"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    structure: Ref[DataStructure] | None = field(default=None, converter=_to_structure)
