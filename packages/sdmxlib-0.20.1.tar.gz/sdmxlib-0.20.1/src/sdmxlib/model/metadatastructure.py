"""MetadataStructure (MSD) and MetadataAttribute — structural template for reference metadata."""

from datetime import datetime
from typing import ClassVar

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.codelist import Codelist
from sdmxlib.model.collections import ItemList
from sdmxlib.model.concept import Concept
from sdmxlib.model.datastructure import ConceptIdentityMixin, RepresentationMixin
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import Ref
from sdmxlib.model.representation import Facet
from sdmxlib.model.urn import SdmxUrn


def _to_concept_ref(v: "Ref[Concept] | SdmxUrn[Concept] | None") -> "Ref[Concept] | None":
    if isinstance(v, SdmxUrn):
        return Ref[Concept].unresolved(v)
    return v


def _to_codelist_ref(
    v: "Ref[Codelist] | SdmxUrn[Codelist] | Codelist | Facet | None",
) -> "Ref[Codelist] | Facet | None":
    if isinstance(v, SdmxUrn):
        return Ref[Codelist].unresolved(v)
    if isinstance(v, Codelist):
        return Ref.to(v)
    return v


def _to_children(
    v: "ItemList[MetadataAttribute] | list[MetadataAttribute]",
) -> "ItemList[MetadataAttribute]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class MetadataAttribute(ConceptIdentityMixin, RepresentationMixin):
    """A structural component of a MetadataStructure.

    Defines one slot in the metadata schema — what can be reported, with
    which representation (codelist or text), and how often.

    Children form a recursive tree (no parent back-reference). Cardinality
    is expressed via min_occurs and max_occurs (None = unbounded).

    Example:
        sl.MetadataAttribute(
            id="FOOTNOTE_TEXT",
            concept=cs.ref_to("FOOTNOTE_TEXT"),
            representation=Facet(type=DataType.String),
            min_occurs=0,
            max_occurs=1,
        )
    """

    id: str
    concept: Ref[Concept] | None = field(default=None, converter=_to_concept_ref)
    representation: Ref[Codelist] | Facet | None = field(default=None, converter=_to_codelist_ref)
    min_occurs: int = 0
    max_occurs: int | None = 1
    is_presentational: bool = False
    children: "ItemList[MetadataAttribute]" = field(factory=ItemList, converter=_to_children)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


def _to_attributes(
    v: "ItemList[MetadataAttribute] | list[MetadataAttribute]",
) -> "ItemList[MetadataAttribute]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class MetadataStructure(MaintainableArtefact):
    """The structural definition of a reference-metadata schema (SDMX MSD).

    Holds a tree of MetadataAttribute components. Each MetadataAttribute
    declares one reportable slot — a concept, a representation (codelist
    or facet), and cardinality bounds.

    Example:
        msd = sl.MetadataStructure(
            id="MSD_FOOTNOTES", maintainer="STC_CP",
            attributes=[sl.MetadataAttribute(id="FOOTNOTE_TEXT", ...)],
        )
        msd.attributes["FOOTNOTE_TEXT"]  # MetadataAttribute by id
    """

    sdmx_package: ClassVar[str] = "metadatastructure"
    sdmx_class: ClassVar[str] = "MetadataStructure"
    msg_field: ClassVar[str] = "metadata_structures"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    attributes: ItemList[MetadataAttribute] = field(factory=ItemList, converter=_to_attributes)

    def add(self, attributes: "MetadataAttribute | list[MetadataAttribute]") -> "MetadataStructure":
        """Return a new MetadataStructure with *attributes* added."""
        new = [attributes] if isinstance(attributes, MetadataAttribute) else list(attributes)
        return evolve(self, attributes=[*self.attributes, *new])

    def drop(self, attribute_ids: str | list[str]) -> "MetadataStructure":
        """Return a new MetadataStructure with the given attribute(s) removed.

        Searches only the top-level attributes by id (children are not flattened).
        Raises KeyError if any id is not present.
        """
        ids = [attribute_ids] if isinstance(attribute_ids, str) else list(attribute_ids)
        missing = [i for i in ids if i not in self.attributes]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(self, attributes=[a for a in self.attributes if a.id not in id_set])
