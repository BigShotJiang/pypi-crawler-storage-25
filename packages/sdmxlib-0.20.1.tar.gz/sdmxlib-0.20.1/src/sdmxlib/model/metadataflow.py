"""Metadataflow — a published reference-metadata product backed by an MSD."""

from datetime import datetime
from typing import ClassVar

from attrs import define, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.metadatastructure import MetadataStructure
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn


def _to_msd_ref(
    v: "Ref[MetadataStructure] | MetadataStructure | SdmxUrn[MetadataStructure] | None",
) -> "Ref[MetadataStructure] | None":
    if isinstance(v, SdmxUrn):
        return Ref[MetadataStructure].unresolved(v)
    if isinstance(v, MetadataStructure):
        return Ref.to(v)
    return v


@define
class Metadataflow(MaintainableArtefact):
    """A published reference-metadata product backed by a MetadataStructure.

    Mirrors Dataflow: binds a maintained id/version to one MSD so that
    metadata sets can reference the flow rather than the bare structure.

    Example:
        mdf = sl.Metadataflow(
            id="MDF_FOOTNOTES", maintainer="STC_CP",
            structure=msd,
            name={"en": "Footnotes flow"},
        )
    """

    sdmx_package: ClassVar[str] = "metadatastructure"
    sdmx_class: ClassVar[str] = "Metadataflow"
    msg_field: ClassVar[str] = "metadataflows"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    structure: Ref[MetadataStructure] | None = field(default=None, converter=_to_msd_ref)
