"""Representation types — DataType, Facet, Representation alias."""

from enum import StrEnum
from typing import TYPE_CHECKING

from attrs import frozen

if TYPE_CHECKING:
    from sdmxlib.model.codelist import Codelist
    from sdmxlib.model.ref import Ref


class DataType(StrEnum):
    """SDMX data types for non-enumerated representations.

    Values match the SDMX-ML ``textType`` attribute strings exactly, so
    ``DataType.String == "String"`` and existing string-passing code continues
    to work unchanged.

    Example:
        Facet(type=DataType.String, max_length=100)
        Facet(type=DataType.ObservationalTimePeriod)
        Facet(type="String")  # str also accepted
    """

    String = "String"
    Alpha = "Alpha"
    AlphaNumeric = "AlphaNumeric"
    Numeric = "Numeric"
    BigInteger = "BigInteger"
    Integer = "Integer"
    Long = "Long"
    Short = "Short"
    Decimal = "Decimal"
    Float = "Float"
    Double = "Double"
    Boolean = "Boolean"
    URI = "URI"
    URL = "URL"
    Count = "Count"
    InclusiveValueRange = "InclusiveValueRange"
    ExclusiveValueRange = "ExclusiveValueRange"
    Incremental = "Incremental"
    ObservationalTimePeriod = "ObservationalTimePeriod"
    StandardTimePeriod = "StandardTimePeriod"
    BasicTimePeriod = "BasicTimePeriod"
    GregorianTimePeriod = "GregorianTimePeriod"
    GregorianYear = "GregorianYear"
    GregorianYearMonth = "GregorianYearMonth"
    GregorianDay = "GregorianDay"
    ReportingTimePeriod = "ReportingTimePeriod"
    ReportingYear = "ReportingYear"
    ReportingSemester = "ReportingSemester"
    ReportingTrimester = "ReportingTrimester"
    ReportingQuarter = "ReportingQuarter"
    ReportingMonth = "ReportingMonth"
    ReportingWeek = "ReportingWeek"
    ReportingDay = "ReportingDay"
    ReportingHour = "ReportingHour"
    DateTime = "DateTime"
    Time = "Time"
    Duration = "Duration"
    Month = "Month"
    MonthDay = "MonthDay"
    Day = "Day"
    Year = "Year"
    XHTML = "XHTML"
    Attachment = "Attachment"


@frozen
class Facet:
    """Non-enumerated representation with optional constraints.

    ``type`` accepts a :class:`DataType` member or a raw string (for
    non-standard values from registry responses).

    Example:
        Facet(type=DataType.String, max_length=100)
        Facet(type=DataType.ObservationalTimePeriod)
        Facet(type="String")  # str accepted; DataType.String preferred
    """

    type: DataType | str | None = None
    max_length: int | None = None
    min_length: int | None = None
    max_value: float | None = None
    min_value: float | None = None
    decimals: int | None = None
    pattern: str | None = None
    start_value: float | None = None
    end_value: float | None = None
    is_sequence: bool | None = None
    is_multi_lingual: bool | None = None


# Type alias — a component's representation is a codelist ref (enumerated)
# or a facet (free text with optional constraints), or absent.
type Representation = "Ref[Codelist] | Facet | None"
