"""FailurePolicy — how a federated read should behave when a source errors.

Per #46's pitfall list ("Partial failure handling"), there are several
valid behaviours when a routed source is unreachable: hard-fail, return
``None`` (treat as not-found), or fall through to a stale local cache.
The policy is configurable per source or globally on
:class:`~sdmxlib.api.federated.FederatedRegistry`.
"""

from enum import Enum


class FailurePolicy(Enum):
    """How a federated registry handles errors from a routed source.

    Attributes:
        HARD_FAIL: Re-raise the underlying error (default). The caller
            sees the network/HTTP exception unchanged.
        RETURN_NONE: Catch errors that look like "source unreachable"
            and return ``None``. The caller cannot distinguish "agency
            doesn't have this artefact" from "source was down."
    """

    HARD_FAIL = "hard_fail"
    RETURN_NONE = "return_none"


class RegistryUnavailable(Exception):  # noqa: N818  # name matches #46 vocabulary
    """Raised when a routed source cannot be reached and the policy is HARD_FAIL.

    Wraps the underlying httpx / connection error so callers can catch a
    single exception type without depending on the HTTP layer.
    """

    def __init__(self, source_id: str | None, cause: Exception) -> None:
        self.source_id = source_id
        self.cause = cause
        sid = f" (source={source_id!r})" if source_id else ""
        super().__init__(f"Registry unavailable{sid}: {cause}")
