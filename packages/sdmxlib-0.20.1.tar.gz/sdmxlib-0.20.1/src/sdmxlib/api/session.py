"""Session — identity map and artefact construction."""

from typing import Any

from sdmxlib.model.message import StructureMessage
from sdmxlib.model.urn import SdmxUrn


def _version_key(version: str) -> tuple[int, ...]:
    """Parse a version string into a tuple of ints for correct ordering.

    Falls back to ``(0,)`` if the string is not a valid dotted-integer version.
    """
    try:
        return tuple(int(x) for x in version.split("."))
    except (ValueError, AttributeError):
        return (0,)


class Session:
    """Session-scoped identity map for SDMX artefacts.

    Interns artefacts by URN so the same object is returned for the
    same URN within a session. Also merges successive StructureMessages
    into the identity map.

    Four separate indices:
    - ``_map``: versioned URN string → artefact (all ingested)
    - ``_latest``: ``cls:agency:id`` → artefact (latest version, all)
    - ``_resolved_map``: versioned URN string → artefact (resolved-only)
    - ``_resolved_latest``: ``cls:agency:id`` → artefact (latest resolved)

    The resolved indices are populated only when ``ingest(..., resolved=True)``
    is called. This lets ``get_resolved()`` return a cached object only when
    it was fetched with ``references=all``, preventing unresolved objects
    from being returned by named methods or ``resolve()``.
    """

    def __init__(self) -> None:
        self._map: dict[str, Any] = {}
        self._latest: dict[str, Any] = {}
        self._resolved_map: dict[str, Any] = {}
        self._resolved_latest: dict[str, Any] = {}
        self._class_tomsg_field: dict[str, str] = {}

    def ingest(self, msg: StructureMessage, *, resolved: bool = False) -> None:
        """Add all artefacts from a StructureMessage to the identity map.

        Pass ``resolved=True`` when the message was fetched with
        ``references=all`` so that ``get_resolved()`` can return the cached
        object on subsequent calls.
        """
        for artefact in msg.all_artefacts():
            cls_name = type(artefact).__name__
            package = getattr(type(artefact), "sdmx_package", None)
            if package is None:
                continue
            urn = SdmxUrn.make(
                type(artefact),
                package=package,
                artefact_class=cls_name,
                agency=artefact.agency_id,
                id=artefact.id,
                version=artefact.version,
            )
            msg_field = getattr(type(artefact), "msg_field", None)
            if msg_field and cls_name not in self._class_tomsg_field:
                self._class_tomsg_field[cls_name] = msg_field
            key = str(urn)
            self._map[key] = artefact
            latest_key = f"{cls_name}:{artefact.agency_id}:{artefact.id}"
            existing = self._latest.get(latest_key)
            if existing is None or _version_key(artefact.version) > _version_key(existing.version):
                self._latest[latest_key] = artefact
            if resolved:
                self._resolved_map[key] = artefact
                existing_r = self._resolved_latest.get(latest_key)
                if existing_r is None or _version_key(artefact.version) > _version_key(existing_r.version):
                    self._resolved_latest[latest_key] = artefact

    def get[T](self, urn: SdmxUrn[T]) -> T | None:
        """Return a cached artefact by URN, or None if not cached."""
        hit = self._map.get(str(urn))
        if hit is not None:
            return hit  # type: ignore[return-value]
        if urn.version == "latest":
            latest_key = f"{urn.artefact_class}:{urn.agency}:{urn.id}"
            return self._latest.get(latest_key)  # type: ignore[return-value]
        return None

    def get_resolved[T](self, urn: SdmxUrn[T]) -> T | None:
        """Return a cached artefact only if it was ingested as resolved."""
        hit = self._resolved_map.get(str(urn))
        if hit is not None:
            return hit  # type: ignore[return-value]
        if urn.version == "latest":
            latest_key = f"{urn.artefact_class}:{urn.agency}:{urn.id}"
            return self._resolved_latest.get(latest_key)  # type: ignore[return-value]
        return None

    def first_of_class[T](self, artefact_type: type[T]) -> T | None:
        """Return the first cached artefact whose type matches artefact_type."""
        for v in self._map.values():
            if isinstance(v, artefact_type):
                return v
        return None

    def all_of_class[T](self, artefact_type: type[T]) -> list[T]:
        """Return all cached artefacts whose type matches artefact_type."""
        return [v for v in self._map.values() if isinstance(v, artefact_type)]

    def extract[T](self, msg: StructureMessage, urn: SdmxUrn[T]) -> T | None:
        """Pull a specific artefact out of a freshly-parsed message by URN.

        Looks in the StructureMessage collection named by the artefact
        type's ``msg_field`` class attribute.
        """
        field = self._class_tomsg_field.get(urn.artefact_class)
        if field is None:
            return None
        collection = getattr(msg, field, None)
        if collection is None:
            return None
        return collection.get(urn)  # type: ignore[return-value]
