"""SdmxClient — thin httpx wrapper around the SDMX REST API."""

from pathlib import Path
from typing import Self

import httpx

from sdmxlib.formats import parse
from sdmxlib.model.message import StructureMessage

# SDMX REST resource path segments (lowercase endpoint name)
_RESOURCE_PATH: dict[str, str] = {
    "DataStructure": "datastructure",
    "Codelist": "codelist",
    "Dataflow": "dataflow",
    "ConceptScheme": "conceptscheme",
    "ProvisionAgreement": "provisionagreement",
    "CategoryScheme": "categoryscheme",
    "Categorisation": "categorisation",
    "DataConstraint": "dataconstraint",
    "AgencyScheme": "agencyscheme",
    "DataProviderScheme": "dataproviderorganisationscheme",
    "Hierarchy": "hierarchy",
    "StructureSet": "structureset",
}

# Wire parameter presets — (detail, references)
_BROWSE_PARAMS = {"detail": "allstubs", "references": "none"}
_FETCH_PARAMS = {"detail": "full", "references": "none"}
_RESOLVE_PARAMS = {"detail": "referencepartial", "references": "descendants"}
_RESOLVE_FULL = {"detail": "full", "references": "descendants"}


class SdmxClient:
    """Thin httpx wrapper that fetches SDMX REST resources and parses them.

    Handles URL construction, Accept headers, and response parsing.
    Does not cache — caching is the Session's responsibility.

    Args:
        endpoint: Base URL of the SDMX REST endpoint.
        api: SDMX REST API version — ``"2.1"`` (default) or ``"3.0"``.
             Controls URL scheme and response format.
        timeout: HTTP request timeout in seconds.
        headers: Extra HTTP headers merged with defaults.
    """

    def __init__(
        self,
        endpoint: str,
        *,
        api: str = "2.1",
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        **httpx_kwargs: object,
    ) -> None:
        self._endpoint = endpoint.rstrip("/")
        self._api = api
        self._v3 = api.startswith(("3", "2.0"))
        default_headers: dict[str, str]
        if self._v3:
            default_headers = {"Accept": "application/vnd.sdmx.structure+xml;version=3.0"}
        else:
            default_headers = {"Accept": "application/xml"}
        if headers:
            default_headers.update(headers)
        self._client = httpx.Client(
            headers=default_headers,
            timeout=timeout,
            **httpx_kwargs,  # type: ignore[arg-type]
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # ── URL building ──────────────────────────────────────────────────────────

    def _resource_url(
        self,
        resource: str,
        agency: str,
        id: str,  # noqa: A002
        version: str,
    ) -> str:
        """Build the resource URL for the given API version."""
        path = _RESOURCE_PATH.get(resource, resource.lower())
        if self._v3:
            # v2.x: /structure/{resource}/{agency}/{id}/{version}
            # "latest" sentinel becomes "~" on the wire
            ver = "~" if version == "latest" else version
            return f"{self._endpoint}/structure/{path}/{agency}/{id}/{ver}"
        # v1.5: /{resource}/{agency}/{id}/{version}
        return f"{self._endpoint}/{path}/{agency}/{id}/{version}"

    def _collection_url(self, resource: str, agency: str | None) -> str:
        """Build the collection URL (all artefacts of a type)."""
        path = _RESOURCE_PATH.get(resource, resource.lower())
        agency_seg = agency or ("*" if self._v3 else "all")
        if self._v3:
            return f"{self._endpoint}/structure/{path}/{agency_seg}"
        return f"{self._endpoint}/{path}/{agency_seg}"

    # ── Parse version ─────────────────────────────────────────────────────────

    @property
    def _parse_version(self) -> str:
        """Format version string passed to the parser."""
        return "3.0" if self._v3 else "2.1"

    # ── HTTP methods ──────────────────────────────────────────────────────────

    def get_artefact(
        self,
        resource: str,
        agency: str,
        id: str,  # noqa: A002
        version: str = "latest",
        *,
        detail: str = "full",
        references: str = "none",
    ) -> StructureMessage:
        """Fetch a single maintainable artefact."""
        url = self._resource_url(resource, agency, id, version)
        params: dict[str, str] = {"detail": detail}
        if references != "none":
            params["references"] = references
        response = self._client.get(url, params=params)
        response.raise_for_status()
        msg = parse(response.content, version=self._parse_version)
        assert isinstance(msg, StructureMessage)  # noqa: S101  # structure endpoint only
        return msg

    def get_all(
        self,
        resource: str,
        agency: str | None = None,
        *,
        detail: str = "full",
        references: str = "none",
    ) -> StructureMessage:
        """Fetch all artefacts of a type, optionally filtered by agency."""
        url = self._collection_url(resource, agency)
        params: dict[str, str] = {"detail": detail}
        if references != "none":
            params["references"] = references
        response = self._client.get(url, params=params)
        response.raise_for_status()
        msg = parse(response.content, version=self._parse_version)
        assert isinstance(msg, StructureMessage)  # noqa: S101  # structure endpoint only
        return msg

    def _data_url(
        self,
        agency: str,
        id: str,  # noqa: A002
        version: str,
        key: str,
    ) -> str:
        """Build the data URL for the given API version."""
        if self._v3:
            ver = "~" if version == "latest" else version
            return f"{self._endpoint}/data/dataflow/{agency}/{id}/{ver}/{key}"
        return f"{self._endpoint}/data/{agency},{id},{version}/{key}"

    def get_data(
        self,
        agency: str,
        id: str,  # noqa: A002
        version: str = "latest",
        *,
        key: str = "all",
        start_period: str | None = None,
        end_period: str | None = None,
    ) -> bytes:
        """Fetch observation data as SDMX-CSV bytes.

        Args:
            agency: Dataflow maintainer agency id.
            id: Dataflow id.
            version: Dataflow version. Defaults to ``"latest"``.
            key: SDMX key filter string, e.g. ``"M.AT+DE.INDPRO"``.
                 Defaults to ``"all"`` (all observations).
            start_period: ISO period start, e.g. ``"2020-01"``.
            end_period: ISO period end.

        Returns:
            Raw SDMX-CSV bytes.
        """
        url = self._data_url(agency, id, version, key)
        params: dict[str, str] = {}
        if start_period is not None:
            params["startPeriod"] = start_period
        if end_period is not None:
            params["endPeriod"] = end_period
        response = self._client.get(
            url,
            params=params,
            headers={"Accept": "text/csv"},
        )
        response.raise_for_status()
        return response.content

    def stream_data_to(
        self,
        agency: str,
        id: str,  # noqa: A002
        version: str = "latest",
        *,
        path: Path,
        key: str = "all",
        start_period: str | None = None,
        end_period: str | None = None,
    ) -> None:
        """Stream observation data directly to a file.

        Uses httpx chunked streaming — the response is never fully loaded into
        memory. Suitable for multi-GB datasets.

        Args:
            agency: Dataflow maintainer agency id.
            id: Dataflow id.
            version: Dataflow version.
            path: Destination file path.
            key: SDMX key filter string.
            start_period: ISO period start.
            end_period: ISO period end.
        """
        url = self._data_url(agency, id, version, key)
        params: dict[str, str] = {}
        if start_period is not None:
            params["startPeriod"] = start_period
        if end_period is not None:
            params["endPeriod"] = end_period
        with self._client.stream(
            "GET",
            url,
            params=params,
            headers={"Accept": "text/csv"},
        ) as response:
            response.raise_for_status()
            with path.open("wb") as f:
                for chunk in response.iter_bytes():
                    f.write(chunk)
