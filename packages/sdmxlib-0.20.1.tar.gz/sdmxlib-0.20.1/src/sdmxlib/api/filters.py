"""Server-side dimension filter expressions for DataQuery.slice()."""

from __future__ import annotations

from attrs import frozen


@frozen
class DimFilter:
    """A resolved server-side filter on a single dimension.

    Produced by :func:`dim` expressions — not constructed directly.

    Attributes:
        id: DSD dimension id.
        codes: One or more codes to match (OR semantics, ``+``-joined on the wire).
    """

    id: str
    codes: list[str]


class _DimExpr:
    """Builder returned by :func:`dim`. Produces a :class:`DimFilter` via ``==`` or ``.isin()``."""

    def __init__(self, id: str) -> None:  # noqa: A002
        self._id = id

    def __eq__(self, other: object) -> DimFilter:  # type: ignore[override]
        if not isinstance(other, str):
            msg = f"Expected a code string, got {type(other).__name__!r}"
            raise TypeError(msg)
        return DimFilter(id=self._id, codes=[other])

    def isin(self, codes: list[str]) -> DimFilter:
        """Match any of the given codes (server-side OR — ``+``-joined in the key).

        Codes are sorted for stable, deterministic URLs.

        Example:
            sl.dim("REF_AREA").isin(["AT", "DE", "FR"])
        """
        return DimFilter(id=self._id, codes=sorted(codes))

    def __hash__(self) -> int:
        return hash(self._id)

    def __repr__(self) -> str:
        return f"dim({self._id!r})"


def dim(id: str) -> _DimExpr:  # noqa: A002
    """Create a server-side dimension filter expression for :meth:`DataQuery.slice`.

    Use ``==`` for a single code or ``.isin()`` for multiple codes (OR semantics).
    Dimensions not mentioned in any filter become wildcards in the SDMX REST key.

    Example:
        sl.dim("FREQ") == "M"
        sl.dim("REF_AREA").isin(["AT", "DE", "FR"])

        reg.data(flow).slice(
            sl.dim("FREQ") == "M",
            sl.dim("REF_AREA").isin(["AT", "DE"]),
        ).fetch()
    """
    return _DimExpr(id)
