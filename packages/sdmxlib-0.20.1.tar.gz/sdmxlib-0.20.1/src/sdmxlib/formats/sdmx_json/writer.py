"""SDMX-JSON 2.0 writer: domain model → JSON bytes.

Serialises a StructureMessage to a valid SDMX-JSON 2.0 Structure message.

Example:
    from sdmxlib.formats.sdmx_json.writer import write

    json_bytes = write(msg)
    json_bytes = write(msg, pretty_print=True)
"""

import json
from datetime import UTC, datetime
from typing import Any

from sdmxlib.model.category import Categorisation, CategoryScheme
from sdmxlib.model.codelist import Codelist
from sdmxlib.model.concept import ConceptScheme
from sdmxlib.model.constraint import ConstraintAttachment, CubeRegion, DataConstraint
from sdmxlib.model.dataflow import Dataflow
from sdmxlib.model.datastructure import (
    AttachmentLevel,
    Attribute,
    DataStructure,
    Dimension,
    Group,
    Measure,
    TimeDimension,
)
from sdmxlib.model.hierarchy import HierarchicalCode, Hierarchy
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.mapping import (
    CategorySchemeMap,
    CodelistMap,
    ConceptSchemeMap,
    DataflowMap,
    DataStructureMap,
    StructureSet,
)
from sdmxlib.model.message import StructureMessage
from sdmxlib.model.metadataflow import Metadataflow
from sdmxlib.model.metadatastructure import MetadataAttribute, MetadataStructure
from sdmxlib.model.organisation import Agency, AgencyScheme, Contact, DataProvider, DataProviderScheme
from sdmxlib.model.provision import ProvisionAgreement
from sdmxlib.model.ref import AnyRef, Ref
from sdmxlib.model.representation import Facet

# ── Common helpers ────────────────────────────────────────────────────────────


def _istring_dict(s: InternationalString | dict[str, str]) -> dict[str, str]:
    return {lang: s[lang] for lang in s}  # type: ignore[index]


def _urn_str(ref: AnyRef | None) -> str | None:
    if ref is None:
        return None
    return str(ref.urn)


# ── Representation ────────────────────────────────────────────────────────────


def _write_text_format(rep: Facet) -> dict[str, Any] | None:
    """Serialise a Facet to a ``textFormat`` dict, omitting None fields."""
    pairs = [
        ("textType", rep.type),
        ("maxLength", rep.max_length),
        ("minLength", rep.min_length),
        ("maxValue", rep.max_value),
        ("minValue", rep.min_value),
        ("decimals", rep.decimals),
        ("pattern", rep.pattern),
        ("startValue", rep.start_value),
        ("endValue", rep.end_value),
        ("isSequence", rep.is_sequence),
        ("isMultiLingual", rep.is_multi_lingual),
    ]
    tf = {k: v for k, v in pairs if v is not None}
    return {"textFormat": tf} if tf else None


def _write_representation(rep: AnyRef | Facet | None) -> dict[str, Any] | None:
    if rep is None:
        return None
    if isinstance(rep, Ref):
        return {"enumeration": str(rep.urn)}
    return _write_text_format(rep)


# ── OrganisationSchemes ───────────────────────────────────────────────────────


def _write_contact(contact: Contact) -> dict[str, Any]:
    obj: dict[str, Any] = {}
    if contact.name:
        obj["name"] = _istring_dict(contact.name)
    if contact.department:
        obj["department"] = _istring_dict(contact.department)
    if contact.role:
        obj["role"] = _istring_dict(contact.role)
    if contact.phones:
        obj["phones"] = list(contact.phones)
    if contact.faxes:
        obj["faxes"] = list(contact.faxes)
    if contact.uris:
        obj["uris"] = list(contact.uris)
    if contact.emails:
        obj["emails"] = list(contact.emails)
    return obj


def _write_agency(agency: Agency) -> dict[str, Any]:
    obj: dict[str, Any] = {"id": agency.id}
    if agency.name:
        obj["name"] = _istring_dict(agency.name)
    if agency.description:
        obj["description"] = _istring_dict(agency.description)
    if agency.contacts:
        obj["contacts"] = [_write_contact(c) for c in agency.contacts]
    return obj


def _write_agency_scheme(scheme: AgencyScheme) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": scheme.id,
        "agencyID": scheme.agency_id,
        "version": scheme.version,
    }
    if scheme.name:
        obj["name"] = _istring_dict(scheme.name)
    if scheme.description:
        obj["description"] = _istring_dict(scheme.description)
    if scheme.is_final:
        obj["isFinal"] = True
    if scheme.valid_from is not None:
        obj["validFrom"] = scheme.valid_from.isoformat()
    if scheme.valid_to is not None:
        obj["validTo"] = scheme.valid_to.isoformat()
    obj["items"] = [_write_agency(a) for a in scheme.agencies]
    return obj


def _write_data_provider(provider: DataProvider) -> dict[str, Any]:
    obj: dict[str, Any] = {"id": provider.id}
    if provider.name:
        obj["name"] = _istring_dict(provider.name)
    if provider.description:
        obj["description"] = _istring_dict(provider.description)
    if provider.contacts:
        obj["contacts"] = [_write_contact(c) for c in provider.contacts]
    return obj


def _write_data_provider_scheme(scheme: DataProviderScheme) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": scheme.id,
        "agencyID": scheme.agency_id,
        "version": scheme.version,
    }
    if scheme.name:
        obj["name"] = _istring_dict(scheme.name)
    if scheme.description:
        obj["description"] = _istring_dict(scheme.description)
    if scheme.is_final:
        obj["isFinal"] = True
    if scheme.valid_from is not None:
        obj["validFrom"] = scheme.valid_from.isoformat()
    if scheme.valid_to is not None:
        obj["validTo"] = scheme.valid_to.isoformat()
    obj["items"] = [_write_data_provider(p) for p in scheme.providers]
    return obj


# ── Codelists ─────────────────────────────────────────────────────────────────


def _write_codelist(cl: Codelist) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": cl.id,
        "agencyID": cl.agency_id,
        "version": cl.version,
        "name": _istring_dict(cl.name),
    }
    if cl.description:
        obj["description"] = _istring_dict(cl.description)
    if cl.is_final:
        obj["isFinal"] = True
    if cl.valid_from is not None:
        obj["validFrom"] = cl.valid_from.isoformat()
    if cl.valid_to is not None:
        obj["validTo"] = cl.valid_to.isoformat()
    items = []
    for code in cl.codes:
        item: dict[str, Any] = {"id": code.id, "name": _istring_dict(code.name)}
        if code.description:
            item["description"] = _istring_dict(code.description)
        if code.parent_id is not None:
            item["parent"] = code.parent_id
        items.append(item)
    obj["items"] = items
    return obj


# ── ConceptSchemes ────────────────────────────────────────────────────────────


def _write_concept_scheme(cs: ConceptScheme) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": cs.id,
        "agencyID": cs.agency_id,
        "version": cs.version,
        "name": _istring_dict(cs.name),
    }
    if cs.description:
        obj["description"] = _istring_dict(cs.description)
    if cs.valid_from is not None:
        obj["validFrom"] = cs.valid_from.isoformat()
    if cs.valid_to is not None:
        obj["validTo"] = cs.valid_to.isoformat()
    obj["items"] = [
        {
            "id": c.id,
            "name": _istring_dict(c.name),
            **({"description": _istring_dict(c.description)} if c.description else {}),
        }
        for c in cs.concepts
    ]
    return obj


# ── CategorySchemes ───────────────────────────────────────────────────────────


def _write_categories(categories: Any) -> list[dict[str, Any]]:
    result = []
    for cat in categories:
        item: dict[str, Any] = {"id": cat.id, "name": _istring_dict(cat.name)}
        if cat.description:
            item["description"] = _istring_dict(cat.description)
        sub = _write_categories(cat.categories)
        if sub:
            item["items"] = sub
        result.append(item)
    return result


def _write_category_scheme(cs: CategoryScheme) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": cs.id,
        "agencyID": cs.agency_id,
        "version": cs.version,
        "name": _istring_dict(cs.name),
    }
    if cs.description:
        obj["description"] = _istring_dict(cs.description)
    if cs.valid_from is not None:
        obj["validFrom"] = cs.valid_from.isoformat()
    if cs.valid_to is not None:
        obj["validTo"] = cs.valid_to.isoformat()
    obj["items"] = _write_categories(cs.categories)
    return obj


# ── DataStructures ────────────────────────────────────────────────────────────


def _write_attribute_relationship(attr: Attribute) -> dict[str, Any]:
    match attr.attachment:
        case AttachmentLevel.OBSERVATION:
            return {"observation": {}}
        case AttachmentLevel.SERIES:
            return {"dimensions": [{"componentId": d} for d in attr.related_dimensions or []]}
        case AttachmentLevel.GROUP:
            return {"group": {}}
        case _:
            return {"dataSet": {}}


def _write_dimension(dim: Dimension, position: int) -> dict[str, Any]:
    obj: dict[str, Any] = {"id": dim.id, "position": position}
    if isinstance(dim.concept, Ref):
        obj["conceptIdentity"] = str(dim.concept.urn)
    if isinstance(dim.representation, (Ref, Facet)):
        rep = _write_representation(dim.representation)
        if rep is not None:
            obj["localRepresentation"] = rep
    return obj


def _write_time_dimension(td: TimeDimension) -> dict[str, Any]:
    obj: dict[str, Any] = {"id": td.id}
    if isinstance(td.concept, Ref):
        obj["conceptIdentity"] = str(td.concept.urn)
    rep = _write_representation(td.representation)
    if rep is not None:
        obj["localRepresentation"] = rep
    return obj


def _write_attribute(attr: Attribute) -> dict[str, Any]:
    obj: dict[str, Any] = {"id": attr.id}
    if attr.usage is not None:
        obj["usage"] = attr.usage
    if isinstance(attr.concept, Ref):
        obj["conceptIdentity"] = str(attr.concept.urn)
    if isinstance(attr.representation, (Ref, Facet)):
        rep = _write_representation(attr.representation)
        if rep is not None:
            obj["localRepresentation"] = rep
    obj["attributeRelationship"] = _write_attribute_relationship(attr)
    return obj


def _write_measure(meas: Measure) -> dict[str, Any]:
    obj: dict[str, Any] = {"id": meas.id}
    if isinstance(meas.concept, Ref):
        obj["conceptIdentity"] = str(meas.concept.urn)
    if isinstance(meas.representation, (Ref, Facet)):
        rep = _write_representation(meas.representation)
        if rep is not None:
            obj["localRepresentation"] = rep
    return obj


def _write_group(grp: Group) -> dict[str, Any]:
    return {
        "id": grp.id,
        "groupDimensions": [{"componentId": d} for d in grp.dimension_ids],
    }


def _write_data_structure(dsd: DataStructure) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": dsd.id,
        "agencyID": dsd.agency_id,
        "version": dsd.version,
        "name": _istring_dict(dsd.name),
    }
    if dsd.description:
        obj["description"] = _istring_dict(dsd.description)
    if dsd.is_final:
        obj["isFinal"] = True
    if dsd.valid_from is not None:
        obj["validFrom"] = dsd.valid_from.isoformat()
    if dsd.valid_to is not None:
        obj["validTo"] = dsd.valid_to.isoformat()

    components: dict[str, Any] = {}

    dim_list: dict[str, Any] = {
        "dimensions": [_write_dimension(d, i) for i, d in enumerate(dsd.dimensions, start=1)],
    }
    if dsd.time_dimension is not None:
        dim_list["timeDimension"] = _write_time_dimension(dsd.time_dimension)
    components["dimensionList"] = dim_list

    if dsd.attributes:
        components["attributeList"] = {
            "attributes": [_write_attribute(a) for a in dsd.attributes],
        }

    if dsd.measures:
        components["measureList"] = {
            "measures": [_write_measure(m) for m in dsd.measures],
        }

    if dsd.groups:
        components["groups"] = [_write_group(g) for g in dsd.groups]

    obj["dataStructureComponents"] = components
    return obj


# ── Dataflows ─────────────────────────────────────────────────────────────────


def _write_dataflow(df: Dataflow) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": df.id,
        "agencyID": df.agency_id,
        "version": df.version,
        "name": _istring_dict(df.name),
    }
    if df.description:
        obj["description"] = _istring_dict(df.description)
    if df.valid_from is not None:
        obj["validFrom"] = df.valid_from.isoformat()
    if df.valid_to is not None:
        obj["validTo"] = df.valid_to.isoformat()
    if isinstance(df.structure, Ref):
        obj["structure"] = str(df.structure.urn)
    return obj


# ── Categorisations ───────────────────────────────────────────────────────────


def _write_categorisation(cat: Categorisation) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": cat.id,
        "agencyID": cat.agency_id,
        "version": cat.version,
        "name": _istring_dict(cat.name),
    }
    if cat.description:
        obj["description"] = _istring_dict(cat.description)
    if cat.valid_from is not None:
        obj["validFrom"] = cat.valid_from.isoformat()
    if cat.valid_to is not None:
        obj["validTo"] = cat.valid_to.isoformat()
    if cat.source is not None:
        obj["source"] = str(cat.source.urn)
    if cat.target is not None:
        obj["target"] = str(cat.target.urn)
    return obj


# ── ProvisionAgreements ───────────────────────────────────────────────────────


def _write_provision_agreement(pa: ProvisionAgreement) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": pa.id,
        "agencyID": pa.agency_id,
        "version": pa.version,
        "name": _istring_dict(pa.name),
    }
    if pa.description:
        obj["description"] = _istring_dict(pa.description)
    if pa.valid_from is not None:
        obj["validFrom"] = pa.valid_from.isoformat()
    if pa.valid_to is not None:
        obj["validTo"] = pa.valid_to.isoformat()
    if pa.dataflow is not None:
        obj["structureUsage"] = str(pa.dataflow.urn)
    if pa.data_provider is not None:
        obj["dataProvider"] = str(pa.data_provider.urn)
    return obj


# ── Constraints ───────────────────────────────────────────────────────────────


def _write_constraint_attachment(attach: ConstraintAttachment) -> dict[str, Any] | None:
    ca: dict[str, Any] = {}
    if attach.dataflow is not None:
        ca["dataflow"] = str(attach.dataflow.urn)
    elif attach.data_structure is not None:
        ca["dataStructure"] = str(attach.data_structure.urn)
    elif attach.provision_agreement is not None:
        ca["provisionAgreement"] = str(attach.provision_agreement.urn)
    return ca or None


def _write_cube_regions(regions: tuple[CubeRegion, ...]) -> list[dict[str, Any]]:
    return [
        {
            "include": region.include,
            "keyValues": [{"id": kv.dimension_id, "values": sorted(kv.values)} for kv in region.keys],
        }
        for region in regions
    ]


def _write_data_constraint(cc: DataConstraint) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": cc.id,
        "agencyID": cc.agency_id,
        "version": cc.version,
        "type": cc.constraint_type,
        "name": _istring_dict(cc.name),
    }
    if cc.description:
        obj["description"] = _istring_dict(cc.description)
    if cc.is_final:
        obj["isFinal"] = True
    if cc.valid_from is not None:
        obj["validFrom"] = cc.valid_from.isoformat()
    if cc.valid_to is not None:
        obj["validTo"] = cc.valid_to.isoformat()

    ca = _write_constraint_attachment(cc.attachment)
    if ca is not None:
        obj["constraintAttachment"] = ca
    if cc.regions:
        obj["cubeRegions"] = _write_cube_regions(cc.regions)
    if cc.reference_period is not None:
        obj["referencePeriod"] = {
            "startPeriod": cc.reference_period.start_period.isoformat(),
            "endPeriod": cc.reference_period.end_period.isoformat(),
        }
    if cc.release_calendar is not None:
        obj["releaseCalendar"] = {
            "periodicity": cc.release_calendar.periodicity,
            "offset": cc.release_calendar.offset,
            "tolerance": cc.release_calendar.tolerance,
        }
    return obj


# ── StructureSets ─────────────────────────────────────────────────────────────


def _write_codelist_map(cm: CodelistMap) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": cm.id,
        "name": _istring_dict(cm.name),
    }
    if cm.description:
        obj["description"] = _istring_dict(cm.description)
    if cm.source is not None:
        obj["source"] = str(cm.source.urn)
    if cm.target is not None:
        obj["target"] = str(cm.target.urn)
    if cm.maps:
        obj["codeMaps"] = [{"source": m.source_id, "target": m.target_id} for m in cm.maps]
    return obj


def _write_structure_set(ss: StructureSet) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": ss.id,
        "agencyID": ss.agency_id,
        "version": ss.version,
        "name": _istring_dict(ss.name),
    }
    if ss.description:
        obj["description"] = _istring_dict(ss.description)
    if ss.is_final:
        obj["isFinal"] = True
    if ss.valid_from is not None:
        obj["validFrom"] = ss.valid_from.isoformat()
    if ss.valid_to is not None:
        obj["validTo"] = ss.valid_to.isoformat()
    if ss.codelist_maps:
        obj["codelistMaps"] = [_write_codelist_map(cm) for cm in ss.codelist_maps]
    if ss.concept_scheme_maps:
        obj["conceptSchemeMaps"] = [_write_concept_scheme_map(csm) for csm in ss.concept_scheme_maps]
    if ss.category_scheme_maps:
        obj["categorySchemeMaps"] = [_write_category_scheme_map(catm) for catm in ss.category_scheme_maps]
    if ss.data_structure_maps:
        obj["dataStructureMaps"] = [_write_data_structure_map(dsm) for dsm in ss.data_structure_maps]
    if ss.dataflow_maps:
        obj["dataflowMaps"] = [_write_dataflow_map(dfm) for dfm in ss.dataflow_maps]
    return obj


def _write_concept_scheme_map(csm: ConceptSchemeMap) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": csm.id,
        "name": _istring_dict(csm.name),
    }
    if csm.description:
        obj["description"] = _istring_dict(csm.description)
    if csm.source is not None:
        obj["source"] = str(csm.source.urn)
    if csm.target is not None:
        obj["target"] = str(csm.target.urn)
    if csm.maps:
        obj["conceptMaps"] = [{"sourceId": m.source_id, "targetId": m.target_id} for m in csm.maps]
    return obj


def _write_category_scheme_map(catm: CategorySchemeMap) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": catm.id,
        "name": _istring_dict(catm.name),
    }
    if catm.description:
        obj["description"] = _istring_dict(catm.description)
    if catm.source is not None:
        obj["source"] = str(catm.source.urn)
    if catm.target is not None:
        obj["target"] = str(catm.target.urn)
    if catm.maps:
        obj["categoryMaps"] = [{"sourceId": m.source_id, "targetId": m.target_id} for m in catm.maps]
    return obj


def _write_data_structure_map(dsm: DataStructureMap) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": dsm.id,
        "name": _istring_dict(dsm.name),
    }
    if dsm.description:
        obj["description"] = _istring_dict(dsm.description)
    if dsm.source is not None:
        obj["source"] = str(dsm.source.urn)
    if dsm.target is not None:
        obj["target"] = str(dsm.target.urn)
    if dsm.maps:
        obj["componentMaps"] = [{"sourceId": m.source_id, "targetId": m.target_id} for m in dsm.maps]
    return obj


def _write_dataflow_map(dfm: DataflowMap) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": dfm.id,
        "name": _istring_dict(dfm.name),
    }
    if dfm.description:
        obj["description"] = _istring_dict(dfm.description)
    if dfm.source is not None:
        obj["source"] = str(dfm.source.urn)
    if dfm.target is not None:
        obj["target"] = str(dfm.target.urn)
    return obj


# ── Hierarchies ──────────────────────────────────────────────────────────────


def _write_hierarchical_code(hc: HierarchicalCode) -> dict[str, Any]:
    """Recursively serialise a HierarchicalCode to a JSON dict."""
    obj: dict[str, Any] = {"id": hc.id}
    if hc.code is not None:
        code_ref = hc.code
        obj["code"] = str(code_ref.urn if isinstance(code_ref, Ref) else code_ref)
    if hc.name:
        obj["name"] = _istring_dict(hc.name)
    if hc.description:
        obj["description"] = _istring_dict(hc.description)
    # SDMX 3.1: optional level reference
    if hc.level is not None:
        obj["level"] = hc.level.id
    if hc.children:
        obj["hierarchicalCodes"] = [_write_hierarchical_code(child) for child in hc.children]
    return obj


def _write_hierarchy(h: Hierarchy) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": h.id,
        "agencyID": h.agency_id,
        "version": h.version,
    }
    if h.name:
        obj["name"] = _istring_dict(h.name)
    if h.description:
        obj["description"] = _istring_dict(h.description)
    if h.is_final:
        obj["isFinal"] = True
    if h.valid_from is not None:
        obj["validFrom"] = h.valid_from.isoformat()
    if h.valid_to is not None:
        obj["validTo"] = h.valid_to.isoformat()
    # SDMX 3.1: write Level definitions
    if h.levels:
        obj["levels"] = [
            {
                "id": lv.id,
                **({"name": _istring_dict(lv.name)} if lv.name else {}),
                **({"description": _istring_dict(lv.description)} if lv.description else {}),
            }
            for lv in h.levels
        ]
    if h.tree:
        obj["hierarchicalCodes"] = [_write_hierarchical_code(hc) for hc in h.tree]
    return obj


# ── MetadataStructures (MSD) ──────────────────────────────────────────────────


def _write_metadata_attribute(attr: MetadataAttribute) -> dict[str, Any]:
    obj: dict[str, Any] = {"id": attr.id}
    if isinstance(attr.concept, Ref):
        obj["conceptIdentity"] = str(attr.concept.urn)
    if isinstance(attr.representation, (Ref, Facet)):
        rep = _write_representation(attr.representation)
        if rep is not None:
            obj["localRepresentation"] = rep
    if attr.min_occurs != 0:
        obj["minOccurs"] = attr.min_occurs
    if attr.max_occurs != 1:
        obj["maxOccurs"] = attr.max_occurs
    if attr.is_presentational:
        obj["isPresentational"] = True
    if attr.children:
        obj["metadataAttributes"] = [_write_metadata_attribute(c) for c in attr.children]
    return obj


def _write_metadata_structure(msd: MetadataStructure) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": msd.id,
        "agencyID": msd.agency_id,
        "version": msd.version,
        "name": _istring_dict(msd.name),
    }
    if msd.description:
        obj["description"] = _istring_dict(msd.description)
    if msd.is_final:
        obj["isFinal"] = True
    if msd.valid_from is not None:
        obj["validFrom"] = msd.valid_from.isoformat()
    if msd.valid_to is not None:
        obj["validTo"] = msd.valid_to.isoformat()
    obj["metadataStructureComponents"] = {
        "metadataAttributeList": {
            "id": "MetadataAttributeDescriptor",
            "metadataAttributes": [_write_metadata_attribute(a) for a in msd.attributes],
        }
    }
    return obj


# ── Metadataflows ─────────────────────────────────────────────────────────────


def _write_metadataflow(mdf: Metadataflow) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": mdf.id,
        "agencyID": mdf.agency_id,
        "version": mdf.version,
        "name": _istring_dict(mdf.name),
    }
    if mdf.description:
        obj["description"] = _istring_dict(mdf.description)
    if mdf.is_final:
        obj["isFinal"] = True
    if mdf.valid_from is not None:
        obj["validFrom"] = mdf.valid_from.isoformat()
    if mdf.valid_to is not None:
        obj["validTo"] = mdf.valid_to.isoformat()
    if isinstance(mdf.structure, Ref):
        obj["structure"] = str(mdf.structure.urn)
    return obj


# ── Entry point ───────────────────────────────────────────────────────────────


def write(msg: StructureMessage, *, pretty_print: bool = False) -> bytes:  # noqa: C901, PLR0912
    """Serialise a StructureMessage to SDMX-JSON 2.0 bytes.

    Args:
        msg: The StructureMessage to serialise.
        pretty_print: If True, indent the output with 2-space indentation.

    Returns:
        UTF-8 encoded JSON bytes of a valid SDMX-JSON 2.0 Structure message.
    """
    data: dict[str, Any] = {}

    if msg.agency_schemes:
        data["agencySchemes"] = [_write_agency_scheme(s) for s in msg.agency_schemes]
    if msg.data_provider_schemes:
        data["dataProviderSchemes"] = [_write_data_provider_scheme(s) for s in msg.data_provider_schemes]
    if msg.codelists:
        data["codelists"] = [_write_codelist(cl) for cl in msg.codelists]
    if msg.concept_schemes:
        data["conceptSchemes"] = [_write_concept_scheme(cs) for cs in msg.concept_schemes]
    if msg.category_schemes:
        data["categorySchemes"] = [_write_category_scheme(cs) for cs in msg.category_schemes]
    if msg.data_structures:
        data["dataStructures"] = [_write_data_structure(dsd) for dsd in msg.data_structures]
    if msg.dataflows:
        data["dataflows"] = [_write_dataflow(df) for df in msg.dataflows]
    if msg.categorisations:
        data["categorisations"] = [_write_categorisation(cat) for cat in msg.categorisations]
    if msg.provision_agreements:
        data["provisionAgreements"] = [_write_provision_agreement(pa) for pa in msg.provision_agreements]
    if msg.constraints:
        data["dataConstraints"] = [_write_data_constraint(cc) for cc in msg.constraints]
    if msg.structure_sets:
        data["structureSets"] = [_write_structure_set(ss) for ss in msg.structure_sets]
    if msg.hierarchies:
        data["hierarchies"] = [_write_hierarchy(h) for h in msg.hierarchies]
    if msg.metadata_structures:
        data["metadataStructures"] = [_write_metadata_structure(m) for m in msg.metadata_structures]
    if msg.metadataflows:
        data["metadataflows"] = [_write_metadataflow(mdf) for mdf in msg.metadataflows]

    doc: dict[str, Any] = {
        "meta": {
            "id": "SDMXLIB",
            "prepared": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S"),
            "sender": {"id": "SDMXLIB"},
        },
        "data": data,
    }

    indent = 2 if pretty_print else None
    return json.dumps(doc, ensure_ascii=False, indent=indent).encode("utf-8")
