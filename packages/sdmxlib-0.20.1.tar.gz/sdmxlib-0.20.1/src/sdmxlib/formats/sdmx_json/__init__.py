"""sdmxlib.formats.sdmx_json — SDMX-JSON 2.0 structure reader."""
