"""SDMX-JSON 2.0 metadata-message reader and writer.

Handles the GenericMetadata envelope keyed on
``$schema = https://json.sdmx.org/2.1/sdmx-json-metadata-schema.json``.

This is a different message type from the Structure message — it carries
populated MetadataSets, not definitions. The data object has exactly one
top-level field: ``metadataSets``.

Per the official spec, ``ReportedAttribute.value`` is a JSON union:
``integer | number | boolean | string | localisedText | null``. We store
scalars as Python primitives and the localisedText shape as
``InternationalString``. The MSD declares whether a string scalar is a
code id, a date, etc. — the wire format does not.
"""

import json
from datetime import UTC, datetime
from typing import Any, cast

from sdmxlib.model.collections import ArtefactList, ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.message import MetadataMessage
from sdmxlib.model.metadataflow import Metadataflow
from sdmxlib.model.metadataset import (
    MetadataSet,
    ReportedAttribute,
    ReportedAttributeValue,
)
from sdmxlib.model.metadatastructure import MetadataStructure
from sdmxlib.model.organisation import Agency
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn

METADATA_SCHEMA_URL = "https://json.sdmx.org/2.1/sdmx-json-metadata-schema.json"


# ── Helpers ───────────────────────────────────────────────────────────────


def _istring_dict(s: InternationalString) -> dict[str, str]:
    return {lang: s[lang] for lang in s}


def _read_istring(obj: dict[str, Any], key: str) -> InternationalString:
    """Read a multilingual field.

    Accepts dict (the canonical shape), a bare string (single-language
    shorthand used by some samples), or absent.
    """
    val = obj.get(key)
    if val is None:
        val = obj.get(key + "s")
    if isinstance(val, dict):
        return InternationalString.of({k: v for k, v in val.items() if isinstance(v, str)})
    if isinstance(val, str):
        # Bare string — treat as content-language single-locale.
        return InternationalString.of({"en": val})
    return InternationalString()


def _read_value(raw: Any) -> ReportedAttributeValue | None:
    """Coerce a JSON metadata value to its Python type."""
    if raw is None:
        return None
    if isinstance(raw, dict):
        return InternationalString.of({k: v for k, v in raw.items() if isinstance(v, str)})
    if isinstance(raw, (str, int, float, bool)):
        return raw
    msg = f"Unexpected metadata value type: {type(raw).__name__}"
    raise TypeError(msg)


def _write_value(v: ReportedAttributeValue | None) -> Any:
    """Serialise a Python value to its JSON representation."""
    if v is None:
        return None
    if isinstance(v, InternationalString):
        return _istring_dict(v)
    return v


# ── Reader ────────────────────────────────────────────────────────────────


def _read_reported_attribute(obj: dict[str, Any]) -> ReportedAttribute:
    children = [_read_reported_attribute(c) for c in obj.get("attributes") or []]
    return ReportedAttribute(
        id=obj["id"],
        value=_read_value(obj.get("value")),
        children=ItemList(children),
    )


def _read_metadata_set(obj: dict[str, Any]) -> MetadataSet:
    # Either metadataflow URN or metadata structure URN. We don't yet model
    # MetadataProvisionAgreement; if a payload uses it the structure ref is
    # empty and the user must populate it from elsewhere.
    structure_urn_str = obj.get("metadataflow") or obj.get("metadataStructure")
    if not structure_urn_str:
        msg = "MetadataSet JSON has neither metadataflow nor metadataStructure ref"
        raise ValueError(msg)
    parsed_structure_urn = SdmxUrn.parse(structure_urn_str)
    structure_ref: Ref[MetadataStructure] | Ref[Metadataflow] = (
        Ref[Metadataflow].unresolved(cast("SdmxUrn[Metadataflow]", parsed_structure_urn))
        if parsed_structure_urn.artefact_class == "Metadataflow"
        else Ref[MetadataStructure].unresolved(cast("SdmxUrn[MetadataStructure]", parsed_structure_urn))
    )

    targets = [Ref[Any].unresolved(SdmxUrn.parse(t)) for t in obj.get("targets") or []]
    attributes = [_read_reported_attribute(a) for a in obj.get("attributes") or []]

    return MetadataSet(
        id=obj["id"],
        maintainer=Agency(id=obj.get("agencyID", "")),
        structure=structure_ref,
        version=obj.get("version", "1.0"),
        name=_read_istring(obj, "name"),
        description=_read_istring(obj, "description"),
        is_final=bool(obj.get("isFinal", False)),
        targets=targets,
        attributes=ItemList(attributes),
    )


def read(data: bytes) -> MetadataMessage:
    """Parse SDMX-JSON 2.0 metadata-message bytes into a MetadataMessage.

    The caller is expected to have determined this is a metadata message —
    use the top-level ``sdmxlib.parse`` to auto-discriminate by ``$schema``.
    """
    doc = json.loads(data)
    payload: dict[str, Any] = doc.get("data") or {}
    metadata_sets = [_read_metadata_set(ms) for ms in payload.get("metadataSets") or []]
    return MetadataMessage(metadata_sets=ArtefactList(metadata_sets))


# ── Writer ────────────────────────────────────────────────────────────────


def _write_reported_attribute(attr: ReportedAttribute) -> dict[str, Any]:
    obj: dict[str, Any] = {"id": attr.id}
    if attr.value is not None:
        obj["value"] = _write_value(attr.value)
    if attr.children:
        obj["attributes"] = [_write_reported_attribute(c) for c in attr.children]
    return obj


def _write_metadata_set(ms: MetadataSet) -> dict[str, Any]:
    obj: dict[str, Any] = {
        "id": ms.id,
        "agencyID": ms.agency_id,
        "version": ms.version,
    }
    if ms.name:
        obj["name"] = _istring_dict(ms.name)
    if ms.description:
        obj["description"] = _istring_dict(ms.description)
    if ms.is_final:
        obj["isFinal"] = True
    if ms.valid_from is not None:
        obj["validFrom"] = ms.valid_from.isoformat()
    if ms.valid_to is not None:
        obj["validTo"] = ms.valid_to.isoformat()

    # Spec field name varies by ref kind — Metadataflow vs (future) MPA, vs
    # MSD-direct. We emit "metadataflow" for the Metadataflow case and
    # "metadataStructure" otherwise. Readers accept either.
    structure_field = "metadataflow" if ms.structure.urn.artefact_class == "Metadataflow" else "metadataStructure"
    obj[structure_field] = str(ms.structure.urn)

    obj["targets"] = [str(t.urn) for t in ms.targets]
    obj["attributes"] = [_write_reported_attribute(a) for a in ms.attributes]
    return obj


def write(msg: MetadataMessage, *, pretty_print: bool = False) -> bytes:
    """Serialise a MetadataMessage to SDMX-JSON 2.0 metadata-message bytes."""
    doc: dict[str, Any] = {
        "$schema": METADATA_SCHEMA_URL,
        "meta": {
            "id": "SDMXLIB",
            "prepared": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S"),
            "sender": {"id": "SDMXLIB"},
        },
        "data": {
            "metadataSets": [_write_metadata_set(ms) for ms in msg.metadata_sets],
        },
    }
    indent = 2 if pretty_print else None
    return json.dumps(doc, ensure_ascii=False, indent=indent).encode("utf-8")
