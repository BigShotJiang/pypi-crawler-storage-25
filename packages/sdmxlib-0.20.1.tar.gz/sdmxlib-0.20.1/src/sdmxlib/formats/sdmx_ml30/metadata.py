"""SDMX-ML 3.0 GenericMetadata reader and writer.

Handles ``<mes:GenericMetadata>`` envelopes carrying populated MetadataSets.
This is a separate message type from the Structure envelope (handled by
sibling reader.py / writer.py).

Per the official SDMX 3.0 schemas:

- The MSD URN binding lives in the message ``<mes:Header>`` as a
  ``<mes:Structure>`` block whose ``<com:Structure>`` child carries a
  ``<Ref class="MetadataStructure">``.
- Each ``<md:MetadataSet>`` carries one ``<md:Metadataflow>`` (or
  ``<md:MetadataProvisionAgreement>``, not yet modelled), one or more
  ``<md:Target>URN</md:Target>`` elements, and one or more
  ``<md:Attribute id="…">`` elements.
- ``<md:Attribute>`` is recursive (children are nested ``<md:Attribute>``
  elements); the value is one of:
  - ``<Value>scalar</Value>`` (text content; coded ids look the same as
    other scalars on the wire — the MSD declares the type)
  - ``<com:Text xml:lang="…">`` siblings for multilingual free text
  - ``<com:StructuredText xml:lang="…">`` for XHTML
- Repetition of an attribute is via sibling ``<md:Attribute>`` elements
  with the same id, not a values list on a single attribute.
"""

from typing import Any, cast

from lxml import etree

from sdmxlib.model.collections import ArtefactList, ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.message import MetadataMessage
from sdmxlib.model.metadataflow import Metadataflow
from sdmxlib.model.metadataset import (
    MetadataSet,
    ReportedAttribute,
    ReportedAttributeValue,
)
from sdmxlib.model.metadatastructure import MetadataStructure
from sdmxlib.model.organisation import Agency
from sdmxlib.model.ref import AnyRef, Ref
from sdmxlib.model.urn import SdmxUrn

from .namespaces import COM, MD, MES, XML_LANG

_NSMAP: dict[Any, str] = {"mes": MES, "md": MD, "com": COM}


# ── Tag helpers ───────────────────────────────────────────────────────────


def _m(tag: str) -> str:
    return f"{{{MES}}}{tag}"


def _md(tag: str) -> str:
    return f"{{{MD}}}{tag}"


def _c(tag: str) -> str:
    return f"{{{COM}}}{tag}"


# ── Writer ────────────────────────────────────────────────────────────────


def _write_istring_children(
    parent: etree._Element,
    s: InternationalString,
    *,
    tag: str,
    namespace: str,
) -> None:
    for lang in s:
        el = etree.SubElement(parent, f"{{{namespace}}}{tag}")
        el.set(XML_LANG, lang)
        el.text = s[lang]


def _write_attribute_value(parent: etree._Element, value: ReportedAttributeValue | None) -> None:
    if value is None:
        return
    if isinstance(value, InternationalString):
        # Multilingual: one <com:Text> per locale.
        _write_istring_children(parent, value, tag="Text", namespace=COM)
    else:
        v_el = etree.SubElement(parent, "Value")
        v_el.text = str(value)


def _write_attribute(parent: etree._Element, attr: ReportedAttribute) -> None:
    el = etree.SubElement(parent, _md("Attribute"))
    el.set("id", attr.id)
    _write_attribute_value(el, attr.value)
    for child in attr.children:
        _write_attribute(el, child)


def _ref_el_for(parent: etree._Element, urn: SdmxUrn[Any]) -> etree._Element:
    ref = etree.SubElement(parent, "Ref")
    ref.set("agencyID", urn.agency)
    ref.set("id", urn.id)
    if urn.version != "latest":
        ref.set("version", urn.version)
    if urn.item_id is not None:
        ref.set("maintainableParentID", urn.id)
        ref.set("id", urn.item_id)
        ref.set("maintainableParentVersion", urn.version if urn.version != "latest" else "1.0")
    ref.set("class", urn.artefact_class)
    ref.set("package", urn.package)
    return ref


def _write_metadata_set(parent: etree._Element, ms: MetadataSet) -> None:
    el = etree.SubElement(parent, _md("MetadataSet"))
    el.set("agencyID", ms.agency_id)
    el.set("id", ms.id)
    el.set("version", ms.version)
    if ms.is_final:
        el.set("isFinal", "true")
    if ms.valid_from is not None:
        el.set("validFrom", ms.valid_from.isoformat())
    if ms.valid_to is not None:
        el.set("validTo", ms.valid_to.isoformat())

    if ms.name:
        _write_istring_children(el, ms.name, tag="Name", namespace=COM)
    if ms.description:
        _write_istring_children(el, ms.description, tag="Description", namespace=COM)

    # Structure binding: <md:Metadataflow> with a Ref, OR <md:MetadataStructure>
    # if the set was authored against the bare MSD.
    structure_tag = "Metadataflow" if ms.structure.urn.artefact_class == "Metadataflow" else "MetadataStructure"
    struct_el = etree.SubElement(el, _md(structure_tag))
    _ref_el_for(struct_el, ms.structure.urn)

    for target in ms.targets:
        target_el = etree.SubElement(el, _md("Target"))
        target_el.text = str(target.urn)

    for attr in ms.attributes:
        _write_attribute(el, attr)


def _write_header(root: etree._Element, msg: MetadataMessage) -> None:
    header = etree.SubElement(root, _m("Header"))
    etree.SubElement(header, _m("ID")).text = "SDMX_MSG"
    etree.SubElement(header, _m("Test")).text = "false"
    etree.SubElement(header, _m("Prepared")).text = "2000-01-01T00:00:00"
    sender = etree.SubElement(header, _m("Sender"))
    sender.set("id", "sdmxlib")

    # One <mes:Structure> per distinct MSD referenced in the message.
    seen: dict[str, SdmxUrn[Any]] = {}
    for ms in msg.metadata_sets:
        urn = ms.structure.urn
        # Resolve to MSD URN even if the structure ref points at a Metadataflow,
        # provided the flow is resolved in memory.
        if urn.artefact_class == "Metadataflow" and ms.structure.resolved:
            mdf = cast("Metadataflow", ms.structure())
            if mdf.structure is not None:
                urn = mdf.structure.urn
        seen.setdefault(str(urn), urn)

    for idx, urn in enumerate(seen.values(), start=1):
        struct_el = etree.SubElement(header, _m("Structure"))
        struct_el.set("structureID", f"MDS{idx}")
        struct_el.set("namespace", "")
        struct_el.set("dimensionAtObservation", "AllDimensions")
        common_struct = etree.SubElement(struct_el, _c("Structure"))
        _ref_el_for(common_struct, urn)


def write(msg: MetadataMessage, *, pretty_print: bool = False) -> bytes:
    """Serialise a MetadataMessage to SDMX-ML 3.0 GenericMetadata bytes.

    Args:
        msg: The MetadataMessage to serialise.
        pretty_print: If True, indent the XML output.

    Returns:
        UTF-8 encoded XML bytes of a ``<mes:GenericMetadata>`` document.
    """
    root = etree.Element(_m("GenericMetadata"), nsmap=_NSMAP)
    _write_header(root, msg)
    for ms in msg.metadata_sets:
        _write_metadata_set(root, ms)
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", pretty_print=pretty_print)


# ── Reader ────────────────────────────────────────────────────────────────


def _read_istring(parent: etree._Element, *, tag: str, namespace: str = COM) -> InternationalString:
    langs: dict[str, str] = {}
    for child in parent.findall(f"{{{namespace}}}{tag}"):
        lang = child.get(XML_LANG, "")
        if lang and child.text:
            langs[lang] = child.text
    return InternationalString(**langs)


def _read_attribute_value(el: etree._Element) -> ReportedAttributeValue | None:
    # Multilingual <com:Text> children take precedence.
    text_children = el.findall(_c("Text"))
    if text_children:
        langs: dict[str, str] = {}
        for child in text_children:
            lang = child.get(XML_LANG, "")
            if lang and child.text:
                langs[lang] = child.text
        return InternationalString(**langs)
    # XHTML <com:StructuredText> — collected as InternationalString too;
    # the inner XHTML markup is preserved as the text content of each locale.
    structured_children = el.findall(_c("StructuredText"))
    if structured_children:
        langs = {}
        for child in structured_children:
            lang = child.get(XML_LANG, "")
            # Reconstitute inner content (may include XHTML markup).
            inner = etree.tostring(child, encoding="unicode", with_tail=False)
            # Strip the outer <StructuredText> wrapper to keep just the markup.
            opening_close = inner.find(">")
            closing_open = inner.rfind("<")
            content = inner[opening_close + 1 : closing_open] if opening_close != -1 and closing_open != -1 else ""
            if lang:
                langs[lang] = content
        return InternationalString(**langs)
    # Scalar <Value>.
    v_el = el.find("Value")
    if v_el is not None and v_el.text is not None:
        return v_el.text
    return None


def _read_attribute(el: etree._Element) -> ReportedAttribute:
    children = [_read_attribute(c) for c in el.findall(_md("Attribute"))]
    return ReportedAttribute(
        id=el.get("id", ""),
        value=_read_attribute_value(el),
        children=ItemList(children),
    )


def _ref_el_to_urn(ref_el: etree._Element) -> SdmxUrn[Any]:
    if urn_str := ref_el.get("urn"):
        return SdmxUrn.parse(urn_str)
    agency = ref_el.get("agencyID", "")
    id_ = ref_el.get("id", "")
    version = ref_el.get("version", "latest")
    package = ref_el.get("package", "")
    cls = ref_el.get("class", "")
    parent_id = ref_el.get("maintainableParentID")
    parent_version = ref_el.get("maintainableParentVersion", "latest")
    if parent_id:
        return SdmxUrn.make(
            object,
            package=package,
            artefact_class=cls,
            agency=agency,
            id=parent_id,
            version=parent_version,
            item_id=id_,
        )
    return SdmxUrn.make(
        object,
        package=package,
        artefact_class=cls,
        agency=agency,
        id=id_,
        version=version,
    )


def _read_metadata_set(el: etree._Element) -> MetadataSet:
    # Either <md:Metadataflow> or <md:MetadataStructure> child.
    structure_urn: SdmxUrn[Any] | None = None
    for tag in ("Metadataflow", "MetadataStructure"):
        struct_el = el.find(_md(tag))
        if struct_el is not None:
            ref_el = struct_el.find("Ref")
            if ref_el is not None:
                structure_urn = _ref_el_to_urn(ref_el)
                break
    if structure_urn is None:
        msg = "MetadataSet missing Metadataflow or MetadataStructure ref"
        raise ValueError(msg)

    structure_ref: Ref[MetadataStructure] | Ref[Metadataflow] = (
        Ref[Metadataflow].unresolved(cast("SdmxUrn[Metadataflow]", structure_urn))
        if structure_urn.artefact_class == "Metadataflow"
        else Ref[MetadataStructure].unresolved(cast("SdmxUrn[MetadataStructure]", structure_urn))
    )

    targets: list[AnyRef] = [
        Ref[Any].unresolved(SdmxUrn.parse(target_el.text.strip()))
        for target_el in el.findall(_md("Target"))
        if target_el.text
    ]

    attributes = [_read_attribute(a) for a in el.findall(_md("Attribute"))]

    return MetadataSet(
        id=el.get("id", ""),
        maintainer=Agency(id=el.get("agencyID", "")),
        structure=structure_ref,
        version=el.get("version", "1.0"),
        name=_read_istring(el, tag="Name"),
        description=_read_istring(el, tag="Description"),
        is_final=el.get("isFinal", "false").lower() == "true",
        targets=targets,
        attributes=ItemList(attributes),
    )


def read(data: bytes) -> MetadataMessage:
    """Parse SDMX-ML 3.0 ``<mes:GenericMetadata>`` bytes into a MetadataMessage."""
    root = etree.fromstring(data)
    sets = [_read_metadata_set(el) for el in root.findall(_md("MetadataSet"))]
    return MetadataMessage(metadata_sets=ArtefactList(sets))
