"""sdmxlib.formats — SDMX wire format readers and writers.

Two distinct message envelopes:

- ``StructureMessage`` — definitions (Codelists, DSDs, MSDs, Metadataflows…)
  carried in ``<mes:Structure>`` (XML) or the structure ``$schema`` (JSON).
- ``MetadataMessage`` — populated reference metadata carried in
  ``<mes:GenericMetadata>`` (XML) or the metadata ``$schema`` (JSON).

The top-level ``parse`` and ``serialize`` entry points auto-discriminate
inbound messages and dispatch outbound writes on the message type.

Example::

    from sdmxlib.formats import read, parse, to_xml, to_json

    msg = read("path/to/file.xml")  # StructureMessage or MetadataMessage
    msg = read(json_bytes)

    xml_bytes = to_xml(msg)  # version="2.1" (default) or "3.0"
    json_bytes = to_json(msg)
"""

from pathlib import Path

from sdmxlib.formats.sdmx_json.metadata import (
    METADATA_SCHEMA_URL as _METADATA_JSON_SCHEMA,
)
from sdmxlib.formats.sdmx_json.metadata import (
    read as _read_metadata_json,
)
from sdmxlib.formats.sdmx_json.metadata import (
    write as _write_metadata_json,
)
from sdmxlib.formats.sdmx_json.reader import read as _read_json
from sdmxlib.formats.sdmx_json.writer import write as _write_json
from sdmxlib.formats.sdmx_ml21.namespaces import MES as _MES_21
from sdmxlib.formats.sdmx_ml21.reader import read as _read_21
from sdmxlib.formats.sdmx_ml21.writer import write as _write_21
from sdmxlib.formats.sdmx_ml30.metadata import read as _read_metadata_30
from sdmxlib.formats.sdmx_ml30.metadata import write as _write_metadata_30
from sdmxlib.formats.sdmx_ml30.namespaces import MES as _MES_30
from sdmxlib.formats.sdmx_ml30.reader import read as _read_30
from sdmxlib.formats.sdmx_ml30.writer import write as _write_30
from sdmxlib.model.message import MetadataMessage, StructureMessage
from sdmxlib.model.registry import InMemoryRegistry


def read(
    source: "str | Path | bytes",
    *,
    version: str | None = None,
    registry: InMemoryRegistry | None = None,
) -> "StructureMessage | MetadataMessage":
    """Read an SDMX file (or raw bytes) into a Structure or Metadata message.

    Format and message type are auto-detected. The result is a
    ``StructureMessage`` for definitions or a ``MetadataMessage`` for
    populated reference-metadata payloads.

    Args:
        source: File path (``str`` or ``Path``) or raw bytes.
        version: Optional format hint: ``"json"``, ``"2.1"``, or ``"3.0"``.
            Auto-detected if omitted.
        registry: Optional Registry to intern artefacts into after parsing.
            Only honoured for StructureMessages — MetadataMessages do not
            interact with the registry today.
    """
    data = Path(source).read_bytes() if isinstance(source, (str, Path)) else source
    return parse(data, version=version, registry=registry)


def parse(
    data: bytes,
    *,
    version: str | None = None,
    registry: InMemoryRegistry | None = None,
) -> "StructureMessage | MetadataMessage":
    """Parse SDMX bytes into a StructureMessage or MetadataMessage.

    Auto-detects the format and message type from the payload:

    - JSON envelopes are routed by ``$schema`` URL.
    - XML envelopes are routed by root element (``<mes:Structure>`` vs
      ``<mes:GenericMetadata>``).

    Args:
        data: Raw bytes — JSON or XML.
        version: Optional hint: ``"json"``, ``"2.1"``, or ``"3.0"``.
            Auto-detected if omitted.
        registry: Optional Registry to intern artefacts into. Honoured only
            for StructureMessages.

    Raises:
        ValueError: If the format cannot be detected or is not supported.
    """
    detected = version or _detect_version(data)
    kind = _detect_message_kind(data, detected)

    if kind == "metadata":
        if detected == "json":
            return _read_metadata_json(data)
        if detected == "3.0":
            return _read_metadata_30(data)
        msg = f"Metadata messages are not supported for {detected!r}"
        raise ValueError(msg)

    # Structure message
    if detected == "json":
        return _read_json(data, registry=registry)
    if detected == "2.1":
        return _read_21(data, registry=registry)
    if detected == "3.0":
        return _read_30(data, registry=registry)
    msg = f"Unsupported format: {detected!r}"
    raise ValueError(msg)


def serialize(
    msg: "StructureMessage | MetadataMessage",
    *,
    version: str = "2.1",
    pretty_print: bool = False,
) -> bytes:
    """Serialise a Structure or Metadata message to bytes.

    Dispatches on the message type:

    - ``StructureMessage`` → ``<mes:Structure>`` envelope (XML) or structure
      ``$schema`` (JSON).
    - ``MetadataMessage`` → ``<mes:GenericMetadata>`` envelope (XML) or
      metadata ``$schema`` (JSON).

    Args:
        msg: The message to serialise.
        version: Wire format — ``"2.1"`` (default), ``"3.0"`` (SDMX-ML XML),
            or ``"json"`` (SDMX-JSON 2.0). MetadataMessage requires ``"3.0"``
            or ``"json"`` (SDMX-ML 2.1 GenericMetadata is out of scope).
        pretty_print: If True, indent the output.
    """
    if isinstance(msg, MetadataMessage):
        if version == "json":
            return _write_metadata_json(msg, pretty_print=pretty_print)
        if version == "3.0":
            return _write_metadata_30(msg, pretty_print=pretty_print)
        err = f"MetadataMessage cannot be serialised as {version!r} (use '3.0' or 'json')"
        raise ValueError(err)

    if version == "json":
        return _write_json(msg, pretty_print=pretty_print)
    if version == "2.1":
        return _write_21(msg, pretty_print=pretty_print)
    if version == "3.0":
        return _write_30(msg, pretty_print=pretty_print)
    err = f"Unsupported format for writing: {version!r}"
    raise ValueError(err)


def to_xml(msg: "StructureMessage | MetadataMessage", *, version: str = "2.1", pretty_print: bool = False) -> bytes:
    """Serialise a Structure or Metadata message to SDMX-ML XML bytes.

    MetadataMessage requires ``version="3.0"`` (SDMX-ML 2.1 GenericMetadata
    is intentionally not supported).
    """
    if isinstance(msg, MetadataMessage) and version != "3.0":
        version = "3.0"
    return serialize(msg, version=version, pretty_print=pretty_print)


def to_json(msg: "StructureMessage | MetadataMessage", *, pretty_print: bool = False) -> bytes:
    """Serialise a Structure or Metadata message to SDMX-JSON 2.0 bytes."""
    return serialize(msg, version="json", pretty_print=pretty_print)


def _detect_version(data: bytes) -> str:
    """Detect the wire format from the first bytes of the payload."""
    chunk = data[:2048]
    stripped = chunk.lstrip()
    if stripped and stripped[0:1] == b"{":
        return "json"
    text = chunk.decode("utf-8", errors="replace")
    if _MES_30 in text:
        return "3.0"
    if _MES_21 in text:
        return "2.1"
    msg = "Cannot detect format: not JSON and no recognised SDMX-ML namespace"
    raise ValueError(msg)


def _detect_message_kind(data: bytes, version: str) -> str:
    """Return ``"structure"`` or ``"metadata"`` based on the message envelope."""
    if version == "json":
        # Discriminate by signal in the first chunk:
        # - the canonical $schema URL (json.sdmx.org/.../metadata-schema.json)
        # - or meta.schema URL containing "metadata-schema" (IMF and others use
        #   the raw GitHub URL instead of the canonical one)
        # - or the presence of a metadataSets array (last-resort heuristic)
        chunk = data[:4096]
        if _METADATA_JSON_SCHEMA.encode("utf-8") in chunk:
            return "metadata"
        if b"metadata-schema" in chunk:
            return "metadata"
        if b'"metadataSets"' in chunk:
            return "metadata"
        return "structure"
    # XML: root element wins. <mes:GenericMetadata> = metadata; everything
    # else (Structure, StructureSpecificMetadata, …) routes to structure.
    chunk = data[:4096].decode("utf-8", errors="replace")
    if "GenericMetadata" in chunk:
        return "metadata"
    return "structure"
