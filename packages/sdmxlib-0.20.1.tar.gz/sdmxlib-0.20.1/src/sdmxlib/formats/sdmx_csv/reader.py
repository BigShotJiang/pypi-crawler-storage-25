"""SDMX-CSV data reader.

Parses SDMX-CSV messages into :class:`~sdmxlib.model.dataset.Dataset` objects.

SDMX-CSV format::

    DATAFLOW,FREQ,REF_AREA,INDICATOR,TIME_PERIOD,OBS_VALUE,OBS_STATUS
    ESTAT:STS_INPR_M(1.0),M,AT,INDPRO,2024-01,98.5,A

The ``DATAFLOW`` column identifies the dataflow but is not a DSD component.
It is extracted and then dropped; the remaining columns are parsed using the
DSD schema.
"""

import csv
import io
import re
from pathlib import Path
from typing import TYPE_CHECKING

import polars as pl

import sdmxlib.polars as slpl
from sdmxlib.model.dataflow import Dataflow
from sdmxlib.model.dataset import Dataset
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn

if TYPE_CHECKING:
    from sdmxlib.model.datastructure import DataStructure

_DATAFLOW_COL = "DATAFLOW"
_KEY_COL = "KEY"
# SDMX-CSV 2.0.0 envelope columns — not DSD components, dropped on read.
_STRUCTURE_COL = "STRUCTURE"
_STRUCTURE_ID_COL = "STRUCTURE_ID"
_ACTION_COL = "ACTION"
_DATAFLOW_RE = re.compile(r"^([^:]+):([^(]+)\(([^)]+)\)$")


def parse_dataflow_id(dataflow_id: str) -> tuple[str, str, str]:
    """Parse an SDMX-CSV DATAFLOW value into ``(agency, id, version)``.

    Example:
        parse_dataflow_id("ESTAT:STS_INPR_M(1.0)")  # ("ESTAT", "STS_INPR_M", "1.0")
    """
    m = _DATAFLOW_RE.match(dataflow_id)
    if m is None:
        msg = f"Cannot parse DATAFLOW value {dataflow_id!r} — expected 'AGENCY:ID(VERSION)'"
        raise ValueError(msg)
    return m.group(1), m.group(2), m.group(3)


def _peek_dataflow_id(source: "str | Path | bytes") -> str | None:
    """Extract the DATAFLOW value from the first data row without reading the whole file."""
    if isinstance(source, (str, Path)):
        with Path(source).open(newline="", encoding="utf-8") as f:
            head = f.read(4096)
    else:
        head = source[:4096].decode("utf-8", errors="replace")

    reader = csv.reader(io.StringIO(head))
    try:
        header = next(reader)
    except StopIteration:
        return None
    df_idx: int | None = None
    for col in (_DATAFLOW_COL, _STRUCTURE_ID_COL):
        if col in header:
            df_idx = header.index(col)
            break
    if df_idx is None:
        return None
    try:
        first_row = next(reader)
    except StopIteration:
        return None
    return first_row[df_idx] if df_idx < len(first_row) else None


def _dataflow_ref(dataflow_str: str) -> "Ref[Dataflow]":
    """Build an unresolved Ref[Dataflow] from an SDMX-CSV DATAFLOW column value."""
    agency, id_, version = parse_dataflow_id(dataflow_str)
    urn = SdmxUrn.make(
        Dataflow,
        package="datastructure",
        artefact_class="Dataflow",
        agency=agency,
        id=id_,
        version=version,
    )
    return Ref[Dataflow].unresolved(urn)


def scan_csv(
    source: "str | Path | bytes",
    structure: "DataStructure",
    *,
    infer_schema_length: "int | None" = 0,
    dataflow: "Ref[Dataflow] | None" = None,
) -> Dataset:
    """Parse an SDMX-CSV message into a :class:`~sdmxlib.model.dataset.Dataset`.

    File paths are scanned lazily via ``pl.scan_csv``; bytes (e.g. from an
    HTTP response) are read eagerly and wrapped in a ``LazyFrame``. Either
    way the returned ``Dataset.data`` is always a ``pl.LazyFrame``.

    Args:
        source: File path or raw bytes from an SDMX-CSV response.
        structure: Fully resolved :class:`~sdmxlib.model.datastructure.DataStructure`.
                   Codelists should be resolved for ``pl.Enum`` typing.
        infer_schema_length: Passed to Polars. ``0`` (default) means
                             schema is fully DSD-driven with no row sampling,
                             which is required for true streaming on paths.
        dataflow: Optional resolved :class:`~sdmxlib.model.dataflow.Dataflow` ref.
                  When ``None`` and a ``DATAFLOW`` column is present, an
                  unresolved ref is built from the column value.

    Returns:
        A :class:`~sdmxlib.model.dataset.Dataset` with a lazy ``data`` frame.

    Example:
        import sdmxlib.polars as slpl

        ds = slpl.scan_csv("data.csv", dsd)
        df = ds.collect(with_labels=True, lang="en")
    """
    dataflow_str = _peek_dataflow_id(source)
    dataflow_ref = dataflow
    if dataflow_ref is None and dataflow_str is not None:
        dataflow_ref = _dataflow_ref(dataflow_str)

    schema_overrides = slpl.schema(structure)

    if isinstance(source, (str, Path)):
        lf = pl.scan_csv(
            source,
            schema_overrides=schema_overrides,
            infer_schema_length=infer_schema_length,
        )
    else:
        lf = pl.read_csv(
            io.BytesIO(source),
            schema_overrides=schema_overrides,
            infer_schema_length=infer_schema_length,
        ).lazy()

    # Drop metadata columns that are not DSD components. Covers both
    # SDMX-CSV 1.0 (DATAFLOW, KEY) and 2.0 (STRUCTURE, STRUCTURE_ID, ACTION).
    col_names = lf.collect_schema().names()
    envelope_cols = (
        _DATAFLOW_COL,
        _KEY_COL,
        _STRUCTURE_COL,
        _STRUCTURE_ID_COL,
        _ACTION_COL,
    )
    to_drop = [c for c in envelope_cols if c in col_names]
    if to_drop:
        lf = lf.drop(to_drop)

    return Dataset(structure=structure, data=lf, dataflow=dataflow_ref)
