"""SDMX-CSV 2.0.0 data writer (streaming).

Consumes an iterator of Arrow record batches (typically from
:meth:`sdmxlib.DataStore.query_stream`) and emits SDMX-CSV bytes one
chunk at a time. The header is emitted once with the first chunk;
subsequent chunks contain data rows only.

SDMX-CSV 2.0.0 header layout::

    STRUCTURE,STRUCTURE_ID,ACTION,<dim cols>,<measure cols>,<attribute cols>

where:

- ``STRUCTURE`` is the artefact type ("dataflow" / "datastructure" /
  "provisionagreement"). Defaults to ``"dataflow"``.
- ``STRUCTURE_ID`` is ``AGENCY:ID(VERSION)``. The caller passes this
  in — typically derived from the bound dataflow's URN.
- ``ACTION`` is one of ``I`` / ``R`` / ``A`` / ``D`` (Insert / Replace /
  Append / Delete). Defaults to ``"I"``.

Dim/measure/attribute column ordering is taken from the binding's
column maps in their dict-insertion order, which matches the order in
which they were declared on the binding.

Performance: rows are serialised via Polars' Rust CSV writer
(``pl.from_arrow(batch).write_csv``) rather than Python's :mod:`csv`,
which makes the writer fast enough that bulk SDMX-CSV downloads are
network-bound rather than writer-bound (#61).

Example:
    from sdmxlib.formats.sdmx_csv import write_sdmx_csv

    chunks = write_sdmx_csv(
        catalog.query_stream(flow_urn, component_filter=cf),
        binding,
        structure_id="ESTAT:STS_INPR_M(1.0)",
    )
    with open("out.csv", "wb") as f:
        for b in chunks:
            f.write(b)
"""

from __future__ import annotations

import io
from typing import TYPE_CHECKING

import polars as pl

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator

    import pyarrow as pa

    from sdmxlib.model.binding import DataflowBinding


def write_sdmx_csv(
    batches: Iterable[pa.RecordBatch],
    binding: DataflowBinding,
    *,
    structure_id: str,
    structure: str = "dataflow",
    action: str = "I",
) -> Iterator[bytes]:
    """Stream SDMX-CSV 2.0.0 bytes for a sequence of Arrow record batches.

    Args:
        batches: Iterable of :class:`pyarrow.RecordBatch` (e.g. the output
            of :meth:`sdmxlib.FederatedCatalog.query_stream`). Each batch
            must contain every column listed in the binding's column maps.
        binding: The :class:`~sdmxlib.model.binding.DataflowBinding`.
            Determines column order in the output: dimensions, then
            measures, then attributes, each in the binding's
            dict-insertion order.
        structure_id: The ``AGENCY:ID(VERSION)`` identifier emitted in
            the ``STRUCTURE_ID`` column on every row.
        structure: Value emitted in the ``STRUCTURE`` column. SDMX-CSV
            allows ``"dataflow"``, ``"datastructure"``, or
            ``"provisionagreement"``. Defaults to ``"dataflow"``.
        action: Value emitted in the ``ACTION`` column. One of ``I``
            (Insert), ``R`` (Replace), ``A`` (Append), ``D`` (Delete).
            Defaults to ``"I"``.

    Yields:
        UTF-8 bytes — header on the first chunk, data rows on every
        chunk including the first. Each yielded ``bytes`` is one record
        batch's worth of CSV.

    Raises:
        KeyError: If a batch is missing a column the binding declares.
    """
    dim_cols = list(binding.dimension_column_map.values())
    measure_cols = list(binding.measure_column_map.values())
    attr_cols = list(binding.attribute_column_map.values())
    data_cols = [*dim_cols, *measure_cols, *attr_cols]
    out_cols = ["STRUCTURE", "STRUCTURE_ID", "ACTION", *data_cols]

    # Header is plain bytes — one line, never quoted by polars' writer
    # because none of the column names contain commas or newlines.
    header_bytes = (",".join(out_cols) + "\n").encode("utf-8")
    header_emitted = False

    for batch in batches:
        missing = [c for c in data_cols if c not in batch.schema.names]
        if missing:
            msg = (
                f"Record batch is missing column(s) {missing!r} declared by "
                f"the binding. Available columns: {batch.schema.names}"
            )
            raise KeyError(msg)

        df = (
            pl.from_arrow(batch)
            .select(data_cols)  # type: ignore[union-attr]
            .with_columns(
                pl.lit(structure).alias("STRUCTURE"),
                pl.lit(structure_id).alias("STRUCTURE_ID"),
                pl.lit(action).alias("ACTION"),
            )
            .select(out_cols)
        )

        buf = io.BytesIO()
        df.write_csv(buf, include_header=False)
        body = buf.getvalue()

        if not header_emitted:
            yield header_bytes + body
            header_emitted = True
        else:
            yield body

    if not header_emitted:
        # Empty stream — emit just the header so consumers get a valid
        # (if empty) SDMX-CSV file.
        yield header_bytes
