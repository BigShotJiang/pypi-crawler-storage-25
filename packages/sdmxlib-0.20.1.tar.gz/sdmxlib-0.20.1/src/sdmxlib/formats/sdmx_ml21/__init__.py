"""SDMX-ML 2.1 format reader."""

from sdmxlib.formats.sdmx_ml21.reader import read

__all__ = ["read"]
