# mcp-youtube-analytics

透過 YouTube Analytics API 取得頻道數據的 MCP 工具。

## 提供的 MCP Tools

| Tool | 說明 |
|------|------|
| `channel_overview` | 頻道整體 KPI：觀看、時長、訂閱增減、互動數 |
| `top_videos` | 觀看數最高的影片排行（含標題、縮圖等 metadata）|
| `daily_trends` | 每日觀看趨勢，適合找出流量高峰或繪製趨勢圖 |
| `traffic_sources` | 流量來源分佈：搜尋、推薦、外部連結等 |
| `top_countries` | 觀眾來源國家排行 |
| `top_subscriber_sources` | 帶來最多訂閱的影片排行 |
| `video_retention` | 特定影片的觀眾留存率曲線 |
| `playlist_performance` | 各播放清單的流量與觀看表現 |

所有 tools 支援自訂 `start_date` / `end_date`（格式 `YYYY-MM-DD`），預設為最近 30 天。

## 前置設定

### 1. 建立 Google Cloud 專案

1. 前往 [Google Cloud Console](https://console.cloud.google.com)
2. 建立新專案（或選擇既有專案）
3. 在左側選單選擇 **API 和服務 → 程式庫**，啟用以下兩個 API：
   - **YouTube Analytics API**
   - **YouTube Data API v3**

### 2. 設定 OAuth 同意畫面

1. 前往 **API 和服務 → OAuth 同意畫面**
2. 使用者類型選擇 **外部**
3. 填入應用程式名稱等基本資訊後儲存
4. 在 **測試使用者** 頁籤加入自己的 Google 帳號（發布前只有測試使用者可以授權）

### 3. 建立 OAuth 用戶端 ID

1. 前往 **API 和服務 → 憑證**
2. 點選 **建立憑證 → OAuth 用戶端 ID**
3. 應用程式類型選擇 **桌面應用程式**
4. 建立後點選 **下載 JSON**
5. 將下載的檔案重新命名為 `client_secrets.json`，放到專案根目錄

### 4. 安裝依賴並執行

```bash
uv sync
uv run mcp-youtube-analytics
```

第一次執行時會自動開啟瀏覽器進行 Google 授權，完成後 `token.json` 會自動儲存在專案根目錄，之後執行不需再次授權。

## 開發測試

使用內建的 CLI tester 對每個 API 函式單獨測試，結果以 JSON 輸出：

```bash
# 查看所有可用指令
uv run mcp-youtube-analytics-debug --help

# 取得頻道 ID
uv run mcp-youtube-analytics-debug channel-id

# 頻道整體表現（預設最近 30 天）
uv run mcp-youtube-analytics-debug channel-overview

# 自訂日期區間
uv run mcp-youtube-analytics-debug channel-overview --start-date 2026-01-01 --end-date 2026-01-31

# 觀看數最高的前 5 部影片
uv run mcp-youtube-analytics-debug top-videos --max-results 5

# 每日觀看趨勢
uv run mcp-youtube-analytics-debug daily-trends

# 流量來源分佈
uv run mcp-youtube-analytics-debug traffic-sources

# 觀眾來源國家排行
uv run mcp-youtube-analytics-debug top-countries --max-results 10

# 帶來最多訂閱的影片
uv run mcp-youtube-analytics-debug top-subscriber-sources

# 特定影片留存率曲線
uv run mcp-youtube-analytics-debug video-retention --video-id <VIDEO_ID>

# 播放清單流量表現
uv run mcp-youtube-analytics-debug playlist-performance

# 批次取得影片 metadata
uv run mcp-youtube-analytics-debug video-metadata --ids <ID1>,<ID2>
```

## 注意事項

- `client_secrets.json` 與 `token.json` 已加入 `.gitignore`，請勿手動 commit 這兩個檔案


## 注意事項

- `client_secrets.json` 與 `token.json` 已加入 `.gitignore`，請勿手動 commit 這兩個檔案
