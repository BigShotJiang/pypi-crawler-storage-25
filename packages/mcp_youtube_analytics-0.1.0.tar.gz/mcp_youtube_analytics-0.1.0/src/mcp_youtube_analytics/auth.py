import os

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

# YouTube Analytics 唯讀 + 頻道基本資料
SCOPES = [
    "https://www.googleapis.com/auth/yt-analytics.readonly",
    "https://www.googleapis.com/auth/youtube.readonly",
]

TOKEN_FILE = "token.json"
CLIENT_SECRETS_FILE = "client_secrets.json"


def get_credentials() -> Credentials:
    """取得有效的 Google OAuth 憑證。

    第一次執行時會開啟瀏覽器要求授權，之後自動用 refresh_token 更新。
    """
    if not os.path.exists(CLIENT_SECRETS_FILE):
        raise FileNotFoundError(
            f"找不到 {CLIENT_SECRETS_FILE}，請先從 Google Cloud Console 下載 OAuth 憑證。\n"
            "步驟：Cloud Console → 憑證 → 建立 OAuth 用戶端 ID（桌面應用程式）→ 下載 JSON"
        )

    creds = None

    # 嘗試從已存的 token 載入
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)

    # Token 不存在或已過期
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            # 用 refresh_token 靜默更新，不需再次授權
            creds.refresh(Request())
        else:
            # 第一次授權：開啟瀏覽器
            flow = InstalledAppFlow.from_client_secrets_file(
                CLIENT_SECRETS_FILE, SCOPES
            )
            # port=0 讓系統自動選擇可用 port，避免衝突
            creds = flow.run_local_server(port=0)

        # 儲存 token 供下次使用（含 refresh_token）
        with open(TOKEN_FILE, "w") as f:
            f.write(creds.to_json())

    return creds
