from datetime import date

import fastmcp

from mcp_youtube_analytics.auth import get_credentials
from mcp_youtube_analytics.youtube import (
    get_channel_overview,
    get_daily_trends,
    get_playlist_performance,
    get_top_countries,
    get_top_subscriber_sources,
    get_top_videos,
    get_traffic_sources,
    get_video_retention,
)

mcp = fastmcp.FastMCP("YouTube Analytics")


def _parse_date(value: str | None) -> date | None:
    if value is None:
        return None
    return date.fromisoformat(value)


@mcp.tool
def channel_overview(
    start_date: str | None = None,
    end_date: str | None = None,
) -> dict:
    """取得 YouTube 頻道整體表現數據。

    Args:
        start_date: 起始日期，格式 YYYY-MM-DD，預設為 30 天前
        end_date: 結束日期，格式 YYYY-MM-DD，預設為昨天

    Returns:
        包含 views、estimatedMinutesWatched、averageViewDuration、
        averageViewPercentage、subscribersGained、subscribersLost、
        likes、comments、shares 的統計數據
    """
    creds = get_credentials()
    return get_channel_overview(
        creds,
        start_date=_parse_date(start_date),
        end_date=_parse_date(end_date),
    )


@mcp.tool
def top_videos(
    start_date: str | None = None,
    end_date: str | None = None,
    max_results: int = 10,
) -> list[dict]:
    """取得指定期間觀看次數最高的影片列表。

    Args:
        start_date: 起始日期，格式 YYYY-MM-DD，預設為 30 天前
        end_date: 結束日期，格式 YYYY-MM-DD，預設為昨天
        max_results: 最多回傳幾筆，預設 10，最大 50

    Returns:
        影片列表，每筆包含 video（影片 ID）、title（標題）、publishedAt、
        thumbnail、views、estimatedMinutesWatched、averageViewDuration、
        likes、comments
    """
    creds = get_credentials()
    return get_top_videos(
        creds,
        start_date=_parse_date(start_date),
        end_date=_parse_date(end_date),
        max_results=min(max_results, 50),
    )


@mcp.tool
def daily_trends(
    start_date: str | None = None,
    end_date: str | None = None,
) -> list[dict]:
    """取得每日觀看趨勢數據，可用於分析哪天流量最高或繪製趨勢圖。

    Args:
        start_date: 起始日期，格式 YYYY-MM-DD，預設為 30 天前
        end_date: 結束日期，格式 YYYY-MM-DD，預設為昨天

    Returns:
        每日一筆，包含 day、views、estimatedMinutesWatched、
        subscribersGained、subscribersLost
    """
    creds = get_credentials()
    return get_daily_trends(
        creds,
        start_date=_parse_date(start_date),
        end_date=_parse_date(end_date),
    )


@mcp.tool
def traffic_sources(
    start_date: str | None = None,
    end_date: str | None = None,
) -> list[dict]:
    """取得流量來源分佈，了解觀眾從搜尋、推薦、外部連結等哪裡來。

    Args:
        start_date: 起始日期，格式 YYYY-MM-DD，預設為 30 天前
        end_date: 結束日期，格式 YYYY-MM-DD，預設為昨天

    Returns:
        每種來源一筆，包含 insightTrafficSourceType、views、
        estimatedMinutesWatched，依觀看次數降序排列
    """
    creds = get_credentials()
    return get_traffic_sources(
        creds,
        start_date=_parse_date(start_date),
        end_date=_parse_date(end_date),
    )


@mcp.tool
def top_countries(
    start_date: str | None = None,
    end_date: str | None = None,
    max_results: int = 20,
) -> list[dict]:
    """取得觀眾來源國家排行。

    Args:
        start_date: 起始日期，格式 YYYY-MM-DD，預設為 30 天前
        end_date: 結束日期，格式 YYYY-MM-DD，預設為昨天
        max_results: 最多回傳幾個國家，預設 20

    Returns:
        每個國家一筆，包含 country（ISO 3166-1 alpha-2）、views、
        estimatedMinutesWatched，依觀看次數降序排列
    """
    creds = get_credentials()
    return get_top_countries(
        creds,
        start_date=_parse_date(start_date),
        end_date=_parse_date(end_date),
        max_results=min(max_results, 50),
    )


@mcp.tool
def top_subscriber_sources(
    start_date: str | None = None,
    end_date: str | None = None,
    max_results: int = 10,
) -> list[dict]:
    """取得帶來最多訂閱的影片排行，了解哪些內容最能轉化訂閱。

    Args:
        start_date: 起始日期，格式 YYYY-MM-DD，預設為 30 天前
        end_date: 結束日期，格式 YYYY-MM-DD，預設為昨天
        max_results: 最多回傳幾筆，預設 10

    Returns:
        影片列表，每筆包含 video、title、subscribersGained、
        subscribersLost、views，依 subscribersGained 降序排列
    """
    creds = get_credentials()
    return get_top_subscriber_sources(
        creds,
        start_date=_parse_date(start_date),
        end_date=_parse_date(end_date),
        max_results=min(max_results, 50),
    )


@mcp.tool
def video_retention(video_id: str) -> list[dict]:
    """取得特定影片的觀眾留存率曲線，了解觀眾在影片哪個時間點離開。

    Args:
        video_id: YouTube 影片 ID

    Returns:
        每個時間點一筆，包含 elapsedVideoTimeRatio（0−1）、
        audienceWatchRatio、relativeRetentionPerformance
    """
    creds = get_credentials()
    return get_video_retention(creds, video_id)


@mcp.tool
def playlist_performance(
    start_date: str | None = None,
    end_date: str | None = None,
    max_results: int = 20,
) -> list[dict]:
    """取得播放清單流量表現。

    Args:
        start_date: 起始日期，格式 YYYY-MM-DD，預設為 30 天前
        end_date: 結束日期，格式 YYYY-MM-DD，預設為昨天
        max_results: 最多回傳幾個播放清單，預設 20

    Returns:
        每個播放清單一筆，包含 playlist、views、
        estimatedMinutesWatched、playlistStarts、viewsPerPlaylistStart
    """
    creds = get_credentials()
    return get_playlist_performance(
        creds,
        start_date=_parse_date(start_date),
        end_date=_parse_date(end_date),
        max_results=min(max_results, 50),
    )


def main():
    mcp.run()
