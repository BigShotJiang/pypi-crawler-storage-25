from datetime import date, timedelta
from typing import Any

from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials


def build_analytics_client(creds: Credentials):
    return build("youtubeAnalytics", "v2", credentials=creds)


def build_data_client(creds: Credentials):
    return build("youtube", "v3", credentials=creds)


def get_channel_id(creds: Credentials) -> str:
    """取得已授權帳號的頻道 ID。"""
    yt = build_data_client(creds)
    response = yt.channels().list(part="id", mine=True).execute()
    items = response.get("items", [])
    if not items:
        raise RuntimeError("找不到頻道，請確認帳號有關聯的 YouTube 頻道。")
    return items[0]["id"]


def get_channel_overview(
    creds: Credentials,
    start_date: date | None = None,
    end_date: date | None = None,
) -> dict[str, Any]:
    """查詢頻道整體表現數據。

    Args:
        creds: 已授權的 Google 憑證
        start_date: 起始日期，預設為 30 天前
        end_date: 結束日期，預設為昨天

    Returns:
        包含頻道 KPI 的 dict
    """
    if end_date is None:
        end_date = date.today() - timedelta(days=1)
    if start_date is None:
        start_date = end_date - timedelta(days=29)

    channel_id = get_channel_id(creds)
    analytics = build_analytics_client(creds)

    metrics = ",".join([
        "views",
        "estimatedMinutesWatched",
        "averageViewDuration",
        "averageViewPercentage",
        "subscribersGained",
        "subscribersLost",
        "likes",
        "comments",
        "shares",
    ])

    response = (
        analytics.reports()
        .query(
            ids=f"channel=={channel_id}",
            startDate=start_date.isoformat(),
            endDate=end_date.isoformat(),
            metrics=metrics,
        )
        .execute()
    )

    # 將 columnHeaders + rows 轉成易讀的 dict
    headers = [col["name"] for col in response.get("columnHeaders", [])]
    rows = response.get("rows", [])

    if not rows:
        return {h: 0 for h in headers}

    result = dict(zip(headers, rows[0]))

    # 補充查詢 metadata
    result["channelId"] = channel_id
    result["startDate"] = start_date.isoformat()
    result["endDate"] = end_date.isoformat()

    return result


def get_top_videos(
    creds: Credentials,
    start_date: date | None = None,
    end_date: date | None = None,
    max_results: int = 10,
) -> list[dict[str, Any]]:
    """查詢指定期間表現最好的影片（依觀看次數排序）。

    Args:
        creds: 已授權的 Google 憑證
        start_date: 起始日期，預設為 30 天前
        end_date: 結束日期，預設為昨天
        max_results: 最多回傳幾筆，預設 10

    Returns:
        影片列表，每筆包含 videoId 與各項指標
    """
    if end_date is None:
        end_date = date.today() - timedelta(days=1)
    if start_date is None:
        start_date = end_date - timedelta(days=29)

    channel_id = get_channel_id(creds)
    analytics = build_analytics_client(creds)

    metrics = ",".join([
        "views",
        "estimatedMinutesWatched",
        "averageViewDuration",
        "likes",
        "comments",
    ])

    response = (
        analytics.reports()
        .query(
            ids=f"channel=={channel_id}",
            startDate=start_date.isoformat(),
            endDate=end_date.isoformat(),
            metrics=metrics,
            dimensions="video",
            sort="-views",
            maxResults=max_results,
        )
        .execute()
    )

    headers = [col["name"] for col in response.get("columnHeaders", [])]
    rows = response.get("rows", [])
    videos = [dict(zip(headers, row)) for row in rows]

    if not videos:
        return []

    # 撈影片 metadata 並合併
    video_ids = [v["video"] for v in videos]
    metadata = get_video_metadata(creds, video_ids)
    for video in videos:
        meta = metadata.get(video["video"], {})
        video.update(meta)

    return videos


def get_video_metadata(
    creds: Credentials,
    video_ids: list[str],
) -> dict[str, dict[str, Any]]:
    """批次取得影片的 metadata（標題、發布時間、縮圖）。

    Args:
        creds: 已授權的 Google 憑證
        video_ids: 影片 ID 列表，最多 50 筆

    Returns:
        以 video_id 為 key 的 dict，每筆包含 title、publishedAt、thumbnail
    """
    yt = build_data_client(creds)
    response = (
        yt.videos()
        .list(
            part="snippet",
            id=",".join(video_ids[:50]),
        )
        .execute()
    )

    result = {}
    for item in response.get("items", []):
        snippet = item["snippet"]
        result[item["id"]] = {
            "title": snippet["title"],
            "publishedAt": snippet["publishedAt"],
            "thumbnail": snippet.get("thumbnails", {}).get("medium", {}).get("url"),
        }
    return result


def _query_analytics(
    creds: Credentials,
    start_date: date,
    end_date: date,
    metrics: str,
    dimensions: str,
    sort: str | None = None,
    max_results: int | None = None,
) -> list[dict[str, Any]]:
    """共用的 Analytics API 查詢，回傳 list of dict。"""
    channel_id = get_channel_id(creds)
    analytics = build_analytics_client(creds)

    kwargs: dict[str, Any] = dict(
        ids=f"channel=={channel_id}",
        startDate=start_date.isoformat(),
        endDate=end_date.isoformat(),
        metrics=metrics,
        dimensions=dimensions,
    )
    if sort:
        kwargs["sort"] = sort
    if max_results:
        kwargs["maxResults"] = max_results

    response = analytics.reports().query(**kwargs).execute()
    headers = [col["name"] for col in response.get("columnHeaders", [])]
    return [dict(zip(headers, row)) for row in response.get("rows", [])]


def get_daily_trends(
    creds: Credentials,
    start_date: date | None = None,
    end_date: date | None = None,
) -> list[dict[str, Any]]:
    """查詢每日觀看趨勢。

    Args:
        creds: 已授權的 Google 憑證
        start_date: 起始日期，預設為 30 天前
        end_date: 結束日期，預設為昨天

    Returns:
        每日一筆，包含 day、views、estimatedMinutesWatched、
        subscribersGained、subscribersLost
    """
    if end_date is None:
        end_date = date.today() - timedelta(days=1)
    if start_date is None:
        start_date = end_date - timedelta(days=29)

    return _query_analytics(
        creds,
        start_date,
        end_date,
        metrics="views,estimatedMinutesWatched,subscribersGained,subscribersLost",
        dimensions="day",
        sort="day",
    )


def get_traffic_sources(
    creds: Credentials,
    start_date: date | None = None,
    end_date: date | None = None,
) -> list[dict[str, Any]]:
    """查詢流量來源分佈。

    Args:
        creds: 已授權的 Google 憑證
        start_date: 起始日期，預設為 30 天前
        end_date: 結束日期，預設為昨天

    Returns:
        每種來源一筆，包含 insightTrafficSourceType、views、
        estimatedMinutesWatched，依觀看次數降序排列
    """
    if end_date is None:
        end_date = date.today() - timedelta(days=1)
    if start_date is None:
        start_date = end_date - timedelta(days=29)

    return _query_analytics(
        creds,
        start_date,
        end_date,
        metrics="views,estimatedMinutesWatched",
        dimensions="insightTrafficSourceType",
        sort="-views",
    )


def get_top_countries(
    creds: Credentials,
    start_date: date | None = None,
    end_date: date | None = None,
    max_results: int = 20,
) -> list[dict[str, Any]]:
    """查詢觀眾來源國家排行。

    Args:
        creds: 已授權的 Google 憑證
        start_date: 起始日期，預設為 30 天前
        end_date: 結束日期，預設為昨天
        max_results: 最多回傳幾個國家，預設 20

    Returns:
        每個國家一筆，包含 country（ISO 3166-1 alpha-2）、views、
        estimatedMinutesWatched，依觀看次數降序排列
    """
    if end_date is None:
        end_date = date.today() - timedelta(days=1)
    if start_date is None:
        start_date = end_date - timedelta(days=29)

    return _query_analytics(
        creds,
        start_date,
        end_date,
        metrics="views,estimatedMinutesWatched",
        dimensions="country",
        sort="-views",
        max_results=max_results,
    )


def get_top_subscriber_sources(
    creds: Credentials,
    start_date: date | None = None,
    end_date: date | None = None,
    max_results: int = 10,
) -> list[dict[str, Any]]:
    """查詢哪些影片帶來最多訂閱，含影片 metadata。

    Args:
        creds: 已授權的 Google 憑證
        start_date: 起始日期，預設為 30 天前
        end_date: 結束日期，預設為昨天
        max_results: 最多回傳幾筆，預設 10

    Returns:
        影片列表，每筆包含 video、title、subscribersGained、
        subscribersLost、views，依 subscribersGained 降序排列
    """
    if end_date is None:
        end_date = date.today() - timedelta(days=1)
    if start_date is None:
        start_date = end_date - timedelta(days=29)

    videos = _query_analytics(
        creds,
        start_date,
        end_date,
        metrics="subscribersGained,subscribersLost,views",
        dimensions="video",
        sort="-subscribersGained",
        max_results=max_results,
    )

    if not videos:
        return []

    video_ids = [v["video"] for v in videos]
    metadata = get_video_metadata(creds, video_ids)
    for video in videos:
        video.update(metadata.get(video["video"], {}))

    return videos


def get_video_retention(
    creds: Credentials,
    video_id: str,
) -> list[dict[str, Any]]:
    """查詢特定影片的觀眾留存率曲線。

    Args:
        creds: 已授權的 Google 憑證
        video_id: YouTube 影片 ID

    Returns:
        每個時間點一筆，包含 elapsedVideoTimeRatio（0−1）、
        audienceWatchRatio、relativeRetentionPerformance
    """
    channel_id = get_channel_id(creds)
    analytics = build_analytics_client(creds)

    # 留存率 API 不需要日期範圍，但必須指定影片
    response = (
        analytics.reports()
        .query(
            ids=f"channel=={channel_id}",
            startDate="2000-01-01",
            endDate=date.today().isoformat(),
            metrics="audienceWatchRatio,relativeRetentionPerformance",
            dimensions="elapsedVideoTimeRatio",
            filters=f"video=={video_id}",
        )
        .execute()
    )

    headers = [col["name"] for col in response.get("columnHeaders", [])]
    return [dict(zip(headers, row)) for row in response.get("rows", [])]


def get_playlist_performance(
    creds: Credentials,
    start_date: date | None = None,
    end_date: date | None = None,
    max_results: int = 20,
) -> list[dict[str, Any]]:
    """查詢播放清單流量表現。

    Args:
        creds: 已授權的 Google 憑證
        start_date: 起始日期，預設為 30 天前
        end_date: 結束日期，預設為昨天
        max_results: 最多回傳幾個播放清單，預設 20

    Returns:
        每個播放清單一筆，包含 playlist、views、
        estimatedMinutesWatched、playlistStarts、
        viewsPerPlaylistStart，依觀看次數降序排列
    """
    if end_date is None:
        end_date = date.today() - timedelta(days=1)
    if start_date is None:
        start_date = end_date - timedelta(days=29)

    return _query_analytics(
        creds,
        start_date,
        end_date,
        metrics="views,estimatedMinutesWatched,playlistStarts,viewsPerPlaylistStart",
        dimensions="playlist",
        sort="-views",
        max_results=max_results,
    )
