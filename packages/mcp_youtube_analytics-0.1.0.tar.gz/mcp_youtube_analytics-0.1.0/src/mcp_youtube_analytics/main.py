"""
開發用 CLI tester，對每個 youtube.py 方法單獨測試。
用法：uv run mcp-youtube-analytics-debug <command> [options]
"""
import argparse
import json
import os

from mcp_youtube_analytics.auth import get_credentials, TOKEN_FILE
from mcp_youtube_analytics.youtube import (
    get_channel_id,
    get_channel_overview,
    get_daily_trends,
    get_playlist_performance,
    get_top_countries,
    get_top_subscriber_sources,
    get_top_videos,
    get_traffic_sources,
    get_video_metadata,
    get_video_retention,
)


def _print(data: object) -> None:
    print(json.dumps(data, indent=2, ensure_ascii=False))


def _get_creds():
    if os.path.exists(TOKEN_FILE):
        print("[auth] 已找到既有 token，直接使用...", flush=True)
    else:
        print("[auth] 尚無授權 token，即將開啟瀏覽器...", flush=True)
    return get_credentials()


def cmd_channel_id(args) -> None:
    creds = _get_creds()
    _print({"channelId": get_channel_id(creds)})


def cmd_channel_overview(args) -> None:
    from datetime import date
    creds = _get_creds()
    _print(get_channel_overview(
        creds,
        start_date=date.fromisoformat(args.start_date) if args.start_date else None,
        end_date=date.fromisoformat(args.end_date) if args.end_date else None,
    ))


def cmd_top_videos(args) -> None:
    from datetime import date
    creds = _get_creds()
    _print(get_top_videos(
        creds,
        start_date=date.fromisoformat(args.start_date) if args.start_date else None,
        end_date=date.fromisoformat(args.end_date) if args.end_date else None,
        max_results=args.max_results,
    ))


def cmd_video_metadata(args) -> None:
    creds = _get_creds()
    video_ids = [v.strip() for v in args.ids.split(",")]
    _print(get_video_metadata(creds, video_ids))


def cmd_daily_trends(args) -> None:
    from datetime import date
    creds = _get_creds()
    _print(get_daily_trends(
        creds,
        start_date=date.fromisoformat(args.start_date) if args.start_date else None,
        end_date=date.fromisoformat(args.end_date) if args.end_date else None,
    ))


def cmd_traffic_sources(args) -> None:
    from datetime import date
    creds = _get_creds()
    _print(get_traffic_sources(
        creds,
        start_date=date.fromisoformat(args.start_date) if args.start_date else None,
        end_date=date.fromisoformat(args.end_date) if args.end_date else None,
    ))


def cmd_top_countries(args) -> None:
    from datetime import date
    creds = _get_creds()
    _print(get_top_countries(
        creds,
        start_date=date.fromisoformat(args.start_date) if args.start_date else None,
        end_date=date.fromisoformat(args.end_date) if args.end_date else None,
        max_results=args.max_results,
    ))


def cmd_top_subscriber_sources(args) -> None:
    from datetime import date
    creds = _get_creds()
    _print(get_top_subscriber_sources(
        creds,
        start_date=date.fromisoformat(args.start_date) if args.start_date else None,
        end_date=date.fromisoformat(args.end_date) if args.end_date else None,
        max_results=args.max_results,
    ))


def cmd_video_retention(args) -> None:
    creds = _get_creds()
    _print(get_video_retention(creds, args.video_id))


def cmd_playlist_performance(args) -> None:
    from datetime import date
    creds = _get_creds()
    _print(get_playlist_performance(
        creds,
        start_date=date.fromisoformat(args.start_date) if args.start_date else None,
        end_date=date.fromisoformat(args.end_date) if args.end_date else None,
        max_results=args.max_results,
    ))


def main():
    parser = argparse.ArgumentParser(
        prog="mcp-youtube-analytics-debug",
        description="YouTube Analytics API tester",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # channel-id
    sub.add_parser("channel-id", help="取得頻道 ID")

    # channel-overview
    p_overview = sub.add_parser("channel-overview", help="頻道整體表現數據")
    p_overview.add_argument("--start-date", help="起始日期 YYYY-MM-DD")
    p_overview.add_argument("--end-date", help="結束日期 YYYY-MM-DD")

    # top-videos
    p_top = sub.add_parser("top-videos", help="觀看數最高的影片（含 metadata）")
    p_top.add_argument("--start-date", help="起始日期 YYYY-MM-DD")
    p_top.add_argument("--end-date", help="結束日期 YYYY-MM-DD")
    p_top.add_argument("--max-results", type=int, default=10, help="筆數上限（預設 10）")

    # video-metadata
    p_meta = sub.add_parser("video-metadata", help="批次取得影片 metadata")
    p_meta.add_argument("--ids", required=True, help="影片 ID，逗號分隔")

    # daily-trends
    p_daily = sub.add_parser("daily-trends", help="每日觀看趨勢")
    p_daily.add_argument("--start-date", help="起始日期 YYYY-MM-DD")
    p_daily.add_argument("--end-date", help="結束日期 YYYY-MM-DD")

    # traffic-sources
    p_traffic = sub.add_parser("traffic-sources", help="流量來源分佈")
    p_traffic.add_argument("--start-date", help="起始日期 YYYY-MM-DD")
    p_traffic.add_argument("--end-date", help="結束日期 YYYY-MM-DD")

    # top-countries
    p_countries = sub.add_parser("top-countries", help="觀眾來源國家排行")
    p_countries.add_argument("--start-date", help="起始日期 YYYY-MM-DD")
    p_countries.add_argument("--end-date", help="結束日期 YYYY-MM-DD")
    p_countries.add_argument("--max-results", type=int, default=20, help="筆數上限（預設 20）")

    # top-subscriber-sources
    p_subs = sub.add_parser("top-subscriber-sources", help="帶來最多訂閱的影片")
    p_subs.add_argument("--start-date", help="起始日期 YYYY-MM-DD")
    p_subs.add_argument("--end-date", help="結束日期 YYYY-MM-DD")
    p_subs.add_argument("--max-results", type=int, default=10, help="筆數上限（預設 10）")

    # video-retention
    p_retention = sub.add_parser("video-retention", help="特定影片留存率曲線")
    p_retention.add_argument("--video-id", required=True, help="YouTube 影片 ID")

    # playlist-performance
    p_playlist = sub.add_parser("playlist-performance", help="播放清單流量表現")
    p_playlist.add_argument("--start-date", help="起始日期 YYYY-MM-DD")
    p_playlist.add_argument("--end-date", help="結束日期 YYYY-MM-DD")
    p_playlist.add_argument("--max-results", type=int, default=20, help="筆數上限（預設 20）")

    args = parser.parse_args()
    {
        "channel-id": cmd_channel_id,
        "channel-overview": cmd_channel_overview,
        "top-videos": cmd_top_videos,
        "video-metadata": cmd_video_metadata,
        "daily-trends": cmd_daily_trends,
        "traffic-sources": cmd_traffic_sources,
        "top-countries": cmd_top_countries,
        "top-subscriber-sources": cmd_top_subscriber_sources,
        "video-retention": cmd_video_retention,
        "playlist-performance": cmd_playlist_performance,
    }[args.command](args)


if __name__ == "__main__":
    main()
