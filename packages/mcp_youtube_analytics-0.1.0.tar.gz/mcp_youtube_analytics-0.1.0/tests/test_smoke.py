import pytest


def test_smoke():
    pass


@pytest.mark.integration
def test_integration_smoke():
    pass
