from auth import get_credentials


def main():
    print("正在取得 Google OAuth 憑證...")
    creds = get_credentials()
    print(f"授權成功！token 已儲存至 token.json")
    print(f"Scopes: {creds.scopes}")


if __name__ == "__main__":
    main()
