"""
Debug script to test MCP tools with LangChain agent.
Run this to verify tools are properly connected.
"""
import asyncio
import os

# Set your API key
os.environ["OPENAI_API_KEY"] = "your-api-key-here"

from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient


async def test_mcp_tools():
    """Test if MCP tools are properly loaded and working."""

    # First, let's test with a simple tool (no MCP)
    print("=" * 50)
    print("TEST 1: Simple tool (no MCP)")
    print("=" * 50)

    def simple_tool(query: str) -> str:
        """A simple test tool."""
        return f"Simple tool result: {query}"

    llm = ChatOpenAI(model="gpt-4-turbo", temperature=0)
    agent = create_agent(
        model=llm,
        tools=[simple_tool],
        system_prompt="You are a helpful assistant. Use the tool when needed."
    )

    result = await agent.ainvoke(
        {"messages": [("user", "Say 'hello world' using the tool")]}
    )
    print(f"Result: {result}")
    print()

    # Now test with actual MCP tools (simulated)
    print("=" * 50)
    print("TEST 2: Check MCP client (requires running server)")
    print("=" * 50)

    # This will only work if you have an MCP server running
    try:
        # Create a minimal stdio config for testing
        # You'll need to replace this with your actual server config
        client = MultiServerMCPClient({
            # Example: uncomment and configure for your server
            # "browser": {
            #     "transport": "stdio",
            #     "command": "python",
            #     "args": ["-c", "from mcp_arena.presents.browser import BrowserMCPServer; BrowserMCPServer().run()"]
            # }
        })

        tools = await client.get_tools()
        print(f"Loaded {len(tools)} tools: {[t.name for t in tools]}")

        if tools:
            agent_with_mcp = create_agent(
                model=llm,
                tools=tools,
                system_prompt="You are a helpful assistant with MCP tools. Use them when needed."
            )

            result = await agent_with_mcp.ainvoke(
                {"messages": [("user", "Use a tool to test")] if tools else [("user", "Hello")]}
            )
            print(f"MCP Result: {result}")

    except Exception as e:
        print(f"MCP test skipped or failed: {e}")
        print("This is OK if you don't have an MCP server running.")

    print()
    print("=" * 50)
    print("Debug complete!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(test_mcp_tools())
