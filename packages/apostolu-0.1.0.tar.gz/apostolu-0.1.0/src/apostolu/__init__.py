"""apostolu - personal CLI tooling."""

__version__ = "0.1.0"
