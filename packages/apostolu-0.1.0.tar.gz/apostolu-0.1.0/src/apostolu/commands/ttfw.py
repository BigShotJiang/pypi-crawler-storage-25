"""`apostolu ttfw <setup|build|flash>` - TT System Firmware workflows.

These commands are designed to be run from a normal shell (no venv
required). They invoke the workspace venv's binaries directly via their
shebangs, so the venv is "active" for those child processes without ever
modifying the user's shell.

`setup` is the equivalent of running:

    python3.12 -m venv ~/tt-system-firmware-work/.venv
    source ~/tt-system-firmware-work/.venv/bin/activate
    pip install west
    west init -m https://github.com/tenstorrent/tt-system-firmware ~/tt-system-firmware-work
    cd ~/tt-system-firmware-work
    west update
    west packages pip --install
    west sdk install
    west blobs fetch tt-system-firmware
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import List, Optional


WORKSPACE_PATH = Path.home() / "tt-system-firmware-work"
VENV_PATH = WORKSPACE_PATH / ".venv"
DEFAULT_PYTHON = "3.12"
REPO_URL = "https://github.com/tenstorrent/tt-system-firmware"
BLOB_MODULE = "tt-system-firmware"

KNOWN_BOARD_REVISIONS = {
    "p100a",
    "p150a",
    "p150b",
    "p150c",
    "p300a",
    "p300b",
    "p300c",
}
DEFAULT_TARGET = "smc"
VALID_TARGETS = ("smc", "dmc")


# ---------------------------------------------------------------------------
# Subcommand entry points
# ---------------------------------------------------------------------------


def setup(args: argparse.Namespace) -> int:
    """`apostolu ttfw setup` - one-time workspace bootstrap."""
    print("apostolu ttfw setup: bootstrapping TT System Firmware workspace")
    print(f"   workspace: {WORKSPACE_PATH}")
    print(f"   venv:      {VENV_PATH}")
    print()

    uv = _ensure_uv()
    if uv is None:
        print(
            "error: failed to locate or install `uv`. "
            "Install it manually from https://docs.astral.sh/uv/ and re-run.",
            file=sys.stderr,
        )
        return 1

    python_spec: str = args.python or DEFAULT_PYTHON

    steps = [
        (f"install Python {python_spec}", lambda: _step_install_python(uv, python_spec)),
        ("create workspace + venv", lambda: _step_create_venv(uv, python_spec, args.force)),
        ("install west", _step_install_west),
        ("west init", _step_west_init),
        ("west update", _step_west_update),
        ("west packages pip --install", _step_west_packages),
        ("west sdk install", _step_west_sdk),
        (f"west blobs fetch {BLOB_MODULE}", _step_west_blobs),
    ]

    total = len(steps)
    for i, (label, fn) in enumerate(steps, 1):
        print(f"[{i}/{total}] {label}")
        rc = fn()
        if rc != 0:
            print(f"error: step '{label}' failed (rc={rc}).", file=sys.stderr)
            return rc
        print()

    _print_setup_done()
    return 0


def build(args: argparse.Namespace) -> int:
    """`apostolu ttfw build <board>` - run `west build` inside the workspace.

    For a board revision like `p300c`, the canonical TT command is:

        west build --sysbuild -p -b tt_blackhole@p300c/tt_blackhole/smc \\
            app/smc -- -DCONFIG_SHELL=y

    See:
      https://docs.tenstorrent.com/tt-system-firmware/develop/getting_started/index.html
    """
    if not _workspace_ready():
        return 1

    target: str = args.target
    if target not in VALID_TARGETS:
        print(
            f"error: --target must be one of {VALID_TARGETS}, got {target!r}.",
            file=sys.stderr,
        )
        return 2

    board_spec = _resolve_board_spec(args.board, target)
    if board_spec is None:
        return 2

    app_path = f"app/{target}"
    extra = _strip_leading_separator(args.extra or [])

    cmd: List[str] = [str(_venv_bin("west")), "build"]
    if target == "smc":
        cmd += ["--sysbuild", "-p", "-b", board_spec, app_path,
                "--", "-DCONFIG_SHELL=y", *extra]
    else:  # dmc
        cmd += ["-b", board_spec, app_path, *extra]

    return _run(cmd, cwd=WORKSPACE_PATH)


def flash(args: argparse.Namespace) -> int:
    """`apostolu ttfw flash` - run `west flash` inside the workspace.

    Default flow is the TT-recommended SMC flash:

        west flash -r tt_flash --force

    Pass `--target dmc` for the plain `west flash` used for DMC firmware.
    """
    if not _workspace_ready():
        return 1

    target: str = args.target
    if target not in VALID_TARGETS:
        print(
            f"error: --target must be one of {VALID_TARGETS}, got {target!r}.",
            file=sys.stderr,
        )
        return 2

    extra = _strip_leading_separator(args.extra or [])
    cmd: List[str] = [str(_venv_bin("west")), "flash"]
    if target == "smc":
        cmd += ["-r", "tt_flash", "--force"]
    cmd += extra

    return _run(cmd, cwd=WORKSPACE_PATH)


def _resolve_board_spec(board: str, target: str) -> Optional[str]:
    """Expand a short board revision into a full Zephyr board spec.

    - "p300c"                                  -> "tt_blackhole@p300c/tt_blackhole/<target>"
    - "tt_blackhole@p300c/tt_blackhole/smc"    -> passed through verbatim
    """
    if "/" in board or "@" in board:
        return board

    if board not in KNOWN_BOARD_REVISIONS:
        known = ", ".join(sorted(KNOWN_BOARD_REVISIONS))
        print(
            f"warning: '{board}' is not in the known revision list ({known}); "
            f"passing through to west anyway.",
            file=sys.stderr,
        )

    return f"tt_blackhole@{board}/tt_blackhole/{target}"


# ---------------------------------------------------------------------------
# Setup steps
# ---------------------------------------------------------------------------


def _step_install_python(uv: str, python_spec: str) -> int:
    return _run([uv, "python", "install", python_spec])


def _step_create_venv(uv: str, python_spec: str, force: bool) -> int:
    WORKSPACE_PATH.mkdir(parents=True, exist_ok=True)

    if VENV_PATH.exists():
        if force:
            print(f"   -> removing existing {VENV_PATH}")
            shutil.rmtree(VENV_PATH)
        else:
            print(f"   -> {VENV_PATH} already exists; skipping creation")
            return 0

    return _run([uv, "venv", str(VENV_PATH), "--python", python_spec])


def _step_install_west() -> int:
    return _run([str(_venv_python()), "-m", "pip", "install", "--upgrade", "west"])


def _step_west_init() -> int:
    if (WORKSPACE_PATH / ".west").exists():
        print(f"   -> {WORKSPACE_PATH / '.west'} already exists; skipping `west init`")
        return 0
    return _run([str(_venv_bin("west")), "init", "-m", REPO_URL, str(WORKSPACE_PATH)])


def _step_west_update() -> int:
    return _run([str(_venv_bin("west")), "update"], cwd=WORKSPACE_PATH)


def _step_west_packages() -> int:
    return _run(
        [str(_venv_bin("west")), "packages", "pip", "--install"],
        cwd=WORKSPACE_PATH,
    )


def _step_west_sdk() -> int:
    return _run([str(_venv_bin("west")), "sdk", "install"], cwd=WORKSPACE_PATH)


def _step_west_blobs() -> int:
    return _run(
        [str(_venv_bin("west")), "blobs", "fetch", BLOB_MODULE],
        cwd=WORKSPACE_PATH,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _workspace_ready() -> bool:
    """Return True if the workspace + venv exist; otherwise print a hint."""
    west_bin = _venv_bin("west")
    if not west_bin.exists():
        print(
            f"error: workspace not initialized (missing {west_bin}).\n"
            f"       Run `apostolu ttfw setup` first.",
            file=sys.stderr,
        )
        return False
    if not (WORKSPACE_PATH / ".west").exists():
        print(
            f"error: workspace not initialized (missing {WORKSPACE_PATH / '.west'}).\n"
            f"       Run `apostolu ttfw setup` first.",
            file=sys.stderr,
        )
        return False
    return True


def _venv_bin(name: str) -> Path:
    if os.name == "nt":
        return VENV_PATH / "Scripts" / f"{name}.exe"
    return VENV_PATH / "bin" / name


def _venv_python() -> Path:
    return _venv_bin("python")


def _ensure_uv() -> Optional[str]:
    """Return path to a usable `uv` binary, installing it if needed."""
    existing = shutil.which("uv")
    if existing:
        return existing

    print("-> `uv` not found; installing it via pip")
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet", "--upgrade", "uv"],
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        print(f"error: pip install uv failed: {exc}", file=sys.stderr)
        return None

    return shutil.which("uv") or _uv_from_sys_executable()


def _uv_from_sys_executable() -> Optional[str]:
    """Fallback: look for `uv` next to the current Python interpreter."""
    candidates = [
        Path(sys.executable).parent / "uv",
        Path(sys.executable).parent / "Scripts" / "uv.exe",
        Path(sys.executable).parent.parent / "bin" / "uv",
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return None


def _run(cmd: List[str], cwd: Optional[Path] = None) -> int:
    where = f" (in {cwd})" if cwd else ""
    print(f"   $ {' '.join(cmd)}{where}")
    completed = subprocess.run(cmd, cwd=str(cwd) if cwd else None)
    return completed.returncode


def _strip_leading_separator(extra: List[str]) -> List[str]:
    """argparse's REMAINDER can include a leading `--`; drop it if present."""
    if extra and extra[0] == "--":
        return extra[1:]
    return extra


def _print_setup_done() -> None:
    print()
    print("=" * 60)
    print(f"Done. Workspace ready at {WORKSPACE_PATH}")
    print("=" * 60)
    print()
    print("Next steps (no shell activation required):")
    print()
    print("    apostolu ttfw build <board_name>")
    print("    apostolu ttfw flash")
    print()
