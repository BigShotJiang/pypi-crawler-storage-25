"""Command line interface for the apostolu package."""

from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from . import __version__
from .commands import ttfw


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="apostolu",
        description="Personal CLI tooling by aapostolu.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")
    subparsers.required = True

    _add_ttfw_subcommand(subparsers)

    return parser


def _add_ttfw_subcommand(subparsers) -> None:
    ttfw_parser = subparsers.add_parser(
        "ttfw",
        help="Tenstorrent System Firmware workflows.",
        description=(
            "Tenstorrent System Firmware workflows. Each subcommand can be "
            "run from outside any virtual environment; the workspace venv at "
            "~/tt-system-firmware-work/.venv is used internally."
        ),
    )
    ttfw_sub = ttfw_parser.add_subparsers(dest="ttfw_command", metavar="<subcommand>")
    ttfw_sub.required = True

    setup = ttfw_sub.add_parser(
        "setup",
        help="One-time bootstrap of the workspace, venv, west, SDK, and blobs.",
        description=(
            "Bootstrap a complete Tenstorrent System Firmware workspace at "
            "~/tt-system-firmware-work: install Python 3.12, create a venv, "
            "install west, then run `west init/update/packages/sdk/blobs`."
        ),
    )
    setup.add_argument(
        "--python",
        default=None,
        help="Python version to install (default: 3.12).",
    )
    setup.add_argument(
        "--force",
        action="store_true",
        help="Recreate the workspace venv if it already exists.",
    )
    setup.set_defaults(func=ttfw.setup)

    build = ttfw_sub.add_parser(
        "build",
        help="Build firmware for a TT Blackhole board revision (runs `west build`).",
        description=(
            "Build SMC (default) or DMC firmware for a TT Blackhole board "
            "revision. `apostolu ttfw build p300c` expands to:\n\n"
            "  west build --sysbuild -p -b tt_blackhole@p300c/tt_blackhole/smc "
            "app/smc -- -DCONFIG_SHELL=y\n\n"
            "Extra arguments are forwarded to `west build` (for SMC, they "
            "land after `-- -DCONFIG_SHELL=y` as additional CMake args)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    build.add_argument(
        "board",
        help=(
            "Board revision (p100a, p150a/b/c, p300a/b/c) or full board "
            "spec like 'tt_blackhole@p300c/tt_blackhole/smc'."
        ),
    )
    build.add_argument(
        "--target",
        choices=ttfw.VALID_TARGETS,
        default=ttfw.DEFAULT_TARGET,
        help="Firmware target: smc (default) or dmc.",
    )
    build.add_argument(
        "extra",
        nargs=argparse.REMAINDER,
        help="Additional arguments forwarded to `west build`.",
    )
    build.set_defaults(func=ttfw.build)

    flash = ttfw_sub.add_parser(
        "flash",
        help="Flash the built firmware (runs `west flash`).",
        description=(
            "Flash firmware to the board. Default flow is the TT-recommended "
            "SMC flash: `west flash -r tt_flash --force`. Use `--target dmc` "
            "for a plain `west flash` (used for DMC). Extra arguments are "
            "forwarded to `west flash`."
        ),
    )
    flash.add_argument(
        "--target",
        choices=ttfw.VALID_TARGETS,
        default=ttfw.DEFAULT_TARGET,
        help="Firmware target: smc (default) or dmc.",
    )
    flash.add_argument(
        "extra",
        nargs=argparse.REMAINDER,
        help="Additional arguments forwarded to `west flash`.",
    )
    flash.set_defaults(func=ttfw.flash)


def main(argv: Optional[List[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        return int(args.func(args) or 0)
    except KeyboardInterrupt:
        print("\nAborted.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
