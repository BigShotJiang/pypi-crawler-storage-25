# apostolu

A tiny personal CLI by `aapostolu`.

## Install

```bash
pip install apostolu
```

## Workflow

```bash
pip install apostolu

apostolu ttfw setup
apostolu ttfw build <board_name>
apostolu ttfw flash
```

Each command can be run from a normal shell — you do **not** need to
activate a virtual environment. Internally, `apostolu` uses the workspace
venv at `~/tt-system-firmware-work/.venv` by invoking its binaries
directly (their shebangs point at the venv's Python).

## Commands

### `apostolu ttfw setup`

One-time bootstrap of a complete [Tenstorrent System Firmware](https://github.com/tenstorrent/tt-system-firmware)
workspace at `~/tt-system-firmware-work`. Equivalent to:

```bash
python3.12 -m venv ~/tt-system-firmware-work/.venv
source ~/tt-system-firmware-work/.venv/bin/activate
pip install west
west init -m https://github.com/tenstorrent/tt-system-firmware ~/tt-system-firmware-work
cd ~/tt-system-firmware-work
west update
west packages pip --install
west sdk install
west blobs fetch tt-system-firmware
```

[`uv`](https://docs.astral.sh/uv/) is auto-installed (via `pip install uv`)
if it isn't already on `PATH`, and is used to install Python 3.12. Every
step is idempotent, so re-running `apostolu ttfw setup` is safe.

Options:

- `--python X.Y[.Z]` — install a different Python version (default `3.12`).
- `--force` — recreate `~/tt-system-firmware-work/.venv` if it already exists.

### `apostolu ttfw build <board>`

Build SMC (default) or DMC firmware for a TT Blackhole board revision.
The short revision is expanded into the canonical Zephyr board spec from
the [TT docs](https://docs.tenstorrent.com/tt-system-firmware/develop/getting_started/index.html).

```bash
apostolu ttfw build p300c
# → west build --sysbuild -p -b tt_blackhole@p300c/tt_blackhole/smc \
#       app/smc -- -DCONFIG_SHELL=y

apostolu ttfw build p100a --target dmc
# → west build -b tt_blackhole@p100a/tt_blackhole/dmc app/dmc
```

Supported revisions: `p100a`, `p150a`, `p150b`, `p150c`, `p300a`, `p300b`,
`p300c`. You can also pass a full spec (e.g.
`tt_blackhole@p300c/tt_blackhole/smc`) and it'll be used verbatim.

Extra arguments forward to `west build` (for SMC, they land after
`-- -DCONFIG_SHELL=y` as additional CMake args):

```bash
apostolu ttfw build p300c -DCONFIG_FOO=y
```

### `apostolu ttfw flash`

Flash firmware to the board. Default flow is the TT-recommended SMC
flash:

```bash
apostolu ttfw flash
# → west flash -r tt_flash --force

apostolu ttfw flash --target dmc
# → west flash
```

Extra arguments are forwarded to `west flash`.

### `apostolu --version`

Prints the installed package version.

## How "invisible" activation works

A Python virtual environment doesn't strictly require `source activate`
to be used. That command only modifies your interactive shell's
environment variables. The venv's own binaries
(`~/tt-system-firmware-work/.venv/bin/python`,
`~/tt-system-firmware-work/.venv/bin/west`, etc.) each have a shebang
pointing at the venv's `python`, so when `apostolu` invokes them via
`subprocess.run(...)`, they automatically run in the venv's context —
the user's shell stays untouched.

## Development

```bash
git clone https://github.com/aapostolu/apostolu
cd apostolu
pip install -e .
apostolu --help
```

To build a distribution:

```bash
pip install build
python -m build
```

## License

MIT
