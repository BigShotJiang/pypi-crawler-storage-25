import asyncio
import base64
import logging
from contextlib import suppress

from rtvoice.audio.session import AudioSession
from rtvoice.events import EventBus
from rtvoice.events.views import (
    AgentSessionConnectedEvent,
    AgentStoppedEvent,
    AudioPlaybackCompletedEvent,
)
from rtvoice.realtime.schemas import (
    InputAudioBufferAppendEvent,
    InputAudioBufferSpeechStartedEvent,
    ResponseDoneEvent,
    ResponseOutputAudioDeltaEvent,
)
from rtvoice.realtime.websocket import RealtimeWebSocket

logger = logging.getLogger(__name__)


class AudioHandler:
    def __init__(
        self,
        event_bus: EventBus,
        audio_session: AudioSession,
        websocket: RealtimeWebSocket,
    ):
        self._event_bus = event_bus
        self._audio_session = audio_session
        self._websocket = websocket
        self._streaming_task: asyncio.Task | None = None

        self._event_bus.subscribe(
            AgentSessionConnectedEvent, self._audio_session_connected
        )
        self._event_bus.subscribe(AgentStoppedEvent, self._on_agent_stopped)
        self._event_bus.subscribe(ResponseOutputAudioDeltaEvent, self._on_audio_delta)
        self._event_bus.subscribe(
            InputAudioBufferSpeechStartedEvent, self._on_user_started_speaking
        )
        self._event_bus.subscribe(ResponseDoneEvent, self._on_response_done)
        self._event_bus.subscribe(
            InputAudioBufferAppendEvent, self._on_input_audio_buffer_append
        )

    async def _audio_session_connected(self, _: AgentSessionConnectedEvent) -> None:
        await self._audio_session.start()
        self._streaming_task = asyncio.create_task(self._stream_audio())
        logger.info("Audio started")

    async def _on_agent_stopped(self, _: AgentStoppedEvent) -> None:
        if self._streaming_task:
            self._streaming_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._streaming_task
            self._streaming_task = None

        await self._audio_session.stop()
        logger.info("Audio stopped")

    async def _stream_audio(self) -> None:
        try:
            async for chunk in self._audio_session.stream_input_chunks():
                base64_audio = base64.b64encode(chunk).decode("utf-8")
                await self._event_bus.dispatch(
                    InputAudioBufferAppendEvent(audio=base64_audio)
                )
        except asyncio.CancelledError:
            pass

    async def _on_audio_delta(self, event: ResponseOutputAudioDeltaEvent) -> None:
        audio_bytes = base64.b64decode(event.delta)
        await self._audio_session.play_chunk(audio_bytes)

    async def _on_user_started_speaking(
        self, _: InputAudioBufferSpeechStartedEvent
    ) -> None:
        await self._audio_session.clear_output_buffer()

    async def _on_response_done(self, _: ResponseDoneEvent) -> None:
        asyncio.create_task(self._wait_for_playback_completion())

    async def _wait_for_playback_completion(self) -> None:
        while self._audio_session.is_playing:
            await asyncio.sleep(0.05)
        await self._event_bus.dispatch(AudioPlaybackCompletedEvent())

    async def _on_input_audio_buffer_append(
        self, event: InputAudioBufferAppendEvent
    ) -> None:
        if not self._websocket.is_connected:
            logger.warning("Cannot send audio - WebSocket not connected")
            return
        await self._websocket.send(event)
