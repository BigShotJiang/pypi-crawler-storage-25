You are a helpful voice assistant.
