"""
Central Request Modul to CMK 2.x
"""
import multiprocessing
import requests
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn, MofNCompleteColumn
#from requests.exceptions import ConnectionError
from application import app
from application.modules.plugin import Plugin
from application.helpers.plugins import register_cli_group

cli_cmk = register_cli_group(app, 'checkmk', 'checkmk', "Checkmk commands")

class CmkException(Exception):
    """Cmk Errors"""

class CMK2(Plugin):
    """
    Get Data from CMK
    """

    @staticmethod
    def _compact_host_data(host):
        """
        Keep only the host fields consumers of `checkmk_hosts` actually
        read later.

        The CheckMK API returns large host documents. Retaining only the
        required fields reduces memory usage noticeably during big sync
        runs. `effective_attributes` is carried through when the caller
        requested `?effective_attributes=true` (the Inventorize flow
        depends on it).
        """
        extensions = host.get('extensions', {})
        compacted = {
            'attributes': extensions.get('attributes', {}),
            'folder': extensions.get('folder', '/'),
            'is_cluster': extensions.get('is_cluster', False),
            'cluster_nodes': extensions.get('cluster_nodes', []),
        }
        if 'effective_attributes' in extensions:
            compacted['effective_attributes'] = extensions['effective_attributes']
        return {'extensions': compacted}


    def __init__(self, account=False):
        """
        Check for Version
        """
        super().__init__(account)
        # Reopen the save_log gate while we do the version probe — if
        # Checkmk is unreachable, this raises and we do NOT want a
        # ghost atexit log entry for a never-actually-started run.
        self._init_complete = False

        # Per-instance runtime caches. Keeping these on the instance (not the
        # class) ensures each Checkmk account / repeated run starts with a
        # clean slate and does not inherit stale version info, hosts or
        # folder attributes from a previous instance in the same process.
        self.checkmk_version = False
        self.checkmk_hosts = {}
        self.existing_folders = []
        self.existing_folders_attributes = {}
        self.custom_folder_attributes = {}

        if self.config and not self.checkmk_version:
            self.checkmk_version = self._probe_checkmk_version()

        self._init_complete = True


    def _probe_checkmk_version(self):
        """
        Ask Checkmk for its version and return the bare version string.

        Works for both 2.4 and 2.5+. Checkmk 2.5 appended the edition suffix
        (e.g. ``2.5.0.pro``) where 2.4 used patch-level strings like
        ``2.4.0p25.cce``. ``.startswith('2.x')`` checks elsewhere keep
        working unchanged for both formats — we just need to fail loudly
        instead of with KeyError when the probe returns nothing.
        """
        data, _headers = self.request('/version')
        try:
            return data['versions']['checkmk']
        except (KeyError, TypeError) as exc:
            raise CmkException(
                f"Could not read Checkmk version from {self.config.get('address')!r}. "
                "The /version endpoint returned no usable payload — "
                "verify the account address (it should end in /<site>, "
                "not /<site>/check_mk) and that the credentials are valid."
            ) from exc


    def request(self, url, method='GET', data=None,  # pylint: disable=too-many-arguments,too-many-positional-arguments,too-many-locals,too-many-branches
                params=None, additional_header=None, api_version="api/1.0/"):
        """
        Handle Request to CMK
        """
        address = self.config['address']
        username = self.config['username']
        password = self.config['password']
        if url.startswith('/'):
            url = url[1:]

        url = f'{address}/check_mk/{api_version}{url}'
        headers = {
            'Authorization': f'Bearer {username} {password}',
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        response = False
        if additional_header:
            headers.update(additional_header)

        if method.lower() in ['post', 'put', 'delete']:
            headers['Content-Type'] = 'application/json'


        try:
            response = self.inner_request(method, url, json=data, headers=headers, params=params)

            try:
                response_json = response.json()
            except requests.exceptions.JSONDecodeError:
                response_json = {}

            resp_header = response.headers

            error_whitelist = [
                #'Path already exists',
                'Not Found',
                'The operation has failed.',
                'Mismatch between endpoint and internal data format. ',
                'Precondition required If-Match header required '
                'for this operation. See documentation.',
            ]
            if response.status_code == 204: # No Content
                return {}, {'status_code': response.status_code}
            if response.status_code == 404:
                return {}, {"error": "Object not found"}
            if response.status_code != 200:
                if  response_json.get('title') not in error_whitelist:
                    title = response_json.get('title')
                    detail = response_json.get('detail')
                    fields = response_json.get('fields')
                    if title is None and detail is None and fields is None:
                        # Non-JSON error body (HTML error page, auth
                        # redirect, legacy endpoint disabled, …) — surface
                        # status + URL + a body snippet so the failure is
                        # debuggable instead of a useless "None NoneNone".
                        body = (response.text or '').strip().replace('\n', ' ')
                        if len(body) > 300:
                            body = body[:300] + '…'
                        raise CmkException(
                            f"HTTP {response.status_code} {method.upper()} "
                            f"{url}: {body or '<empty response body>'}"
                        )
                    raise CmkException(f"{title} {detail}{fields}")
                return {}, {'status_code': response.status_code}
            resp_header['status_code'] = response.status_code

            return response_json, resp_header
        except (ConnectionResetError, requests.exceptions.ProxyError):
            if response:
                return {}, {'status_code': response.status_code}
            return {}, {"error": "Checkmk Connections broken"}
        except ConnectionError as exc:
            raise CmkException("Can't connect to Checkmk") from exc

    def fetch_checkmk_folders(self):
        """
        Fetch list of Folders in Checkmk
        """
        url = "domain-types/folder_config/collections/all"
        url += "?parent=/&recursive=true&show_hosts=false"
        with Progress(SpinnerColumn(),
                      MofNCompleteColumn(),
                      *Progress.get_default_columns(),
                      TimeElapsedColumn()) as progress:
            task1 = progress.add_task("Fetching Current Folders", start=False)
            api_folders = self.request(url, method="GET")
            if not api_folders[0]:
                raise CmkException("Cant connect or auth with CMK")
            progress.update(task1, total=len(api_folders[0]['value']), start=True)
            for folder in api_folders[0]['value']:
                progress.update(task1, advance=1)
                path = folder['extensions']['path']
                attributes = folder['extensions']['attributes']
                self.existing_folders_attributes[path] = attributes
                self.existing_folders_attributes[path].update({'title': folder['title']})
                self.existing_folders.append(path)

    def fetch_all_checkmk_hosts(self, extra_params=""):
        """
        Classic full Fetch
        """
        url = f"domain-types/host_config/collections/all{extra_params}"
        with Progress(SpinnerColumn(),
                      MofNCompleteColumn(),
                      *Progress.get_default_columns(),
                      TimeElapsedColumn()) as progress:
            task1 = progress.add_task("Fetching Hosts", start=False)
            progress.console.print("Waiting for Checkmk Response")
            api_hosts = self.request(url, method="GET")
            progress.update(task1, total=len(api_hosts[0]['value']), start=True)
            for host in api_hosts[0]['value']:
                self.checkmk_hosts[host['id']] = self._compact_host_data(host)
                progress.update(task1, advance=1)


    def get_hosts_of_folder(self, folder, extra_params):
        """Get hosts of the given folder as a plain dict."""
        folder_url = folder.replace('/','~')
        url = f"objects/folder_config/{folder_url}/collections/hosts{extra_params}"
        api_hosts = self.request(url, method="GET")
        return_dict = {}
        for host in api_hosts[0]['value']:
            return_dict[host['id']] = self._compact_host_data(host)
        return return_dict

    def _fetch_checkmk_host_by_folder(self, extra_params=""):
        """
        Check the folder Structure and get hosts
        whit multiple request
        """
        with Progress(SpinnerColumn(),
                      MofNCompleteColumn(),
                      *Progress.get_default_columns(),
                      TimeElapsedColumn()) as progress:
            num_folders = len(self.existing_folders)

            task1 = progress.add_task("Fetching Hosts folder by folder", total=num_folders)
            with multiprocessing.Pool() as pool:
                tasks = []
                for folder in self.existing_folders:
                    task = pool.apply_async(self.get_hosts_of_folder, args=(folder, extra_params,))
                    tasks.append(task)

                for task in tasks:
                    self.checkmk_hosts.update(task.get())
                    progress.advance(task1)
                pool.close()
                pool.join()
