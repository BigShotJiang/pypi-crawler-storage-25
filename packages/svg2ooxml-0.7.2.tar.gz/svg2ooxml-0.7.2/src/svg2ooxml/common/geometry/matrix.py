"""Lightweight 2D matrix utilities and SVG transform parsing."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from math import cos, radians, sin, tan

from svg2ooxml.ir.geometry import Point


@dataclass(slots=True)
class Matrix2D:
    """Simple 3x3 matrix representation for 2D transforms."""

    a: float = 1.0
    b: float = 0.0
    c: float = 0.0
    d: float = 1.0
    e: float = 0.0
    f: float = 0.0

    # ------------------------------------------------------------------ #
    # Constructors                                                        #
    # ------------------------------------------------------------------ #

    @classmethod
    def from_values(
        cls,
        a: float,
        b: float,
        c: float,
        d: float,
        e: float,
        f: float,
    ) -> Matrix2D:
        return cls(a, b, c, d, e, f)

    def multiply(self, other: Matrix2D) -> Matrix2D:
        return Matrix2D(
            a=self.a * other.a + self.c * other.b,
            b=self.b * other.a + self.d * other.b,
            c=self.a * other.c + self.c * other.d,
            d=self.b * other.c + self.d * other.d,
            e=self.a * other.e + self.c * other.f + self.e,
            f=self.b * other.e + self.d * other.f + self.f,
        )

    def __matmul__(self, other: Matrix2D) -> Matrix2D:
        return self.multiply(other)

    def determinant(self) -> float:
        return self.a * self.d - self.b * self.c

    def inverse(self) -> Matrix2D:
        det = self.determinant()
        if abs(det) < 1e-12:
            raise ValueError("Matrix is not invertible")
        inv_det = 1.0 / det
        a = self.d * inv_det
        b = -self.b * inv_det
        c = -self.c * inv_det
        d = self.a * inv_det
        e = -(a * self.e + c * self.f)
        f = -(b * self.e + d * self.f)
        return Matrix2D(a, b, c, d, e, f)

    # ------------------------------------------------------------------ #
    # Geometry helpers                                                   #
    # ------------------------------------------------------------------ #

    def transform_xy(self, x: float, y: float) -> tuple[float, float]:
        return (
            x * self.a + y * self.c + self.e,
            x * self.b + y * self.d + self.f,
        )

    def transform_point(self, point: Point) -> Point:
        """Apply the matrix to an IR point."""
        x, y = self.transform_xy(point.x, point.y)
        return Point(x, y)

    def transform_points(self, points: Iterable[Point | tuple[float, float]]) -> list[Point]:
        """Apply the matrix to an iterable of points."""
        transformed: list[Point] = []
        for item in points:
            if isinstance(item, Point):
                source = item
            else:
                source = Point(float(item[0]), float(item[1]))
            transformed.append(self.transform_point(source))
        return transformed

    def is_identity(self, *, tolerance: float = 1e-9) -> bool:
        """Return True if the matrix is effectively an identity matrix."""
        return (
            abs(self.a - 1.0) <= tolerance
            and abs(self.d - 1.0) <= tolerance
            and abs(self.b) <= tolerance
            and abs(self.c) <= tolerance
            and abs(self.e) <= tolerance
            and abs(self.f) <= tolerance
        )

    @classmethod
    def identity(cls) -> Matrix2D:
        return cls()

    @classmethod
    def translation(cls, tx: float, ty: float) -> Matrix2D:
        return cls(e=tx, f=ty)

    @classmethod
    def translate(cls, tx: float, ty: float = 0.0) -> Matrix2D:
        return cls.translation(tx, ty)

    @classmethod
    def scale(cls, sx: float, sy: float | None = None) -> Matrix2D:
        return cls(a=sx, d=sy if sy is not None else sx)

    @classmethod
    def rotation(cls, angle_deg: float, cx: float = 0.0, cy: float = 0.0) -> Matrix2D:
        angle = radians(angle_deg)
        cos_a = cos(angle)
        sin_a = sin(angle)
        return cls(
            a=cos_a,
            b=sin_a,
            c=-sin_a,
            d=cos_a,
            e=cx - cx * cos_a + cy * sin_a,
            f=cy - cx * sin_a - cy * cos_a,
        )

    @classmethod
    def skew_x(cls, angle_deg: float) -> Matrix2D:
        return cls(c=tan(radians(angle_deg)))

    @classmethod
    def skew_y(cls, angle_deg: float) -> Matrix2D:
        return cls(b=tan(radians(angle_deg)))

    @classmethod
    def from_transform(cls, name: str, values: Iterable[float]) -> Matrix2D:
        name = name.strip()
        lower_name = name.lower()
        vals = list(values)
        if lower_name == "matrix" and len(vals) >= 6:
            return cls(*vals[:6])
        if lower_name == "translate":
            tx = vals[0] if vals else 0.0
            ty = vals[1] if len(vals) > 1 else 0.0
            return cls(e=tx, f=ty)
        if lower_name == "scale":
            sx = vals[0] if vals else 1.0
            sy = vals[1] if len(vals) > 1 else sx
            return cls(a=sx, d=sy)
        if lower_name == "rotate":
            angle = radians(vals[0]) if vals else 0.0
            cos_a = cos(angle)
            sin_a = sin(angle)
            if len(vals) > 2:
                cx, cy = vals[1:3]
                return cls(
                    a=cos_a,
                    b=sin_a,
                    c=-sin_a,
                    d=cos_a,
                    e=cx - cx * cos_a + cy * sin_a,
                    f=cy - cx * sin_a - cy * cos_a,
                )
            return cls(a=cos_a, b=sin_a, c=-sin_a, d=cos_a)
        if lower_name == "skewx" and vals:
            angle = radians(vals[0])
            return cls(c=tan(angle))
        if lower_name == "skewy" and vals:
            angle = radians(vals[0])
            return cls(b=tan(angle))
        return cls.identity()

    @classmethod
    def rotate(cls, angle_deg: float, cx: float = 0.0, cy: float = 0.0) -> Matrix2D:
        return cls.rotation(angle_deg, cx, cy)

    def as_tuple(self) -> tuple[float, float, float, float, float, float]:
        return self.a, self.b, self.c, self.d, self.e, self.f


def parse_transform_list(transform: str | None) -> Matrix2D:
    if not transform:
        return Matrix2D.identity()

    current = Matrix2D.identity()
    for name, values in _tokenize_transforms(transform):
        matrix = Matrix2D.from_transform(name, values)
        current = current.multiply(matrix)
    return current


def _tokenize_transforms(transform: str) -> list[tuple[str, list[float]]]:
    tokens: list[tuple[str, list[float]]] = []
    name = ""
    args = ""
    depth = 0
    for char in transform:
        if char.isalpha() or char in {"-", "_"}:
            if depth == 0:
                name += char
            else:
                args += char
        elif char == "(":
            depth += 1
            if depth == 1:
                continue
            args += char
        elif char == ")":
            depth -= 1
            if depth == 0:
                tokens.append((name.strip(), _parse_floats(args)))
                name = ""
                args = ""
            else:
                args += char
        else:
            args += char
    return tokens


def _parse_floats(text: str) -> list[float]:
    from svg2ooxml.common.conversions.transforms import parse_numeric_list

    return parse_numeric_list(text)


__all__ = ["Matrix2D", "parse_transform_list"]
