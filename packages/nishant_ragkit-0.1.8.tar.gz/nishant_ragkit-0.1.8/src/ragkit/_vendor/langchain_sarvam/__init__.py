import sys
from .chat_models import ChatSarvam
from .version import __version__

__all__ = ["ChatSarvam", "__version__"]

# Provide a fallback alias for users who rely on the direct import
if "langchain_sarvam" not in sys.modules:
    sys.modules["langchain_sarvam"] = sys.modules[__name__]
