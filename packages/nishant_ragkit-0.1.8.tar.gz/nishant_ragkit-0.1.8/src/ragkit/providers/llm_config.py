from langchain_sarvam import ChatSarvam
import os
from dotenv import load_dotenv
load_dotenv()

def get_llm():
   return ChatSarvam(
        model_name="sarvam-m",
        api_key=os.getenv("SARVAM_API_KEY"),
        temperature=0.2,
        reasoning_effort="low",
    )
