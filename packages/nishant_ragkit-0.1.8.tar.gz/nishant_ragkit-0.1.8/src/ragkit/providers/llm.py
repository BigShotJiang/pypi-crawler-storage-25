from __future__ import annotations

import os
from typing import Any

from dotenv import load_dotenv

load_dotenv()


class LLMProviderError(ValueError):
    pass


def get_llm(
    provider: str = "sarvam",
    model: str | None = None,
    temperature: float = 0.2,
    **kwargs: Any,
):
    provider = provider.strip().lower()

    if provider == "sarvam":
        return _build_sarvam_llm(
            model=model or "sarvam-m",
            temperature=temperature,
            **kwargs,
        )

    if provider == "openai":
        return _build_openai_llm(
            model=model or "gpt-4o-mini",
            temperature=temperature,
            **kwargs,
        )

    if provider in {"anthropic", "claude"}:
        return _build_anthropic_llm(
            model=model or "claude-3-5-haiku-latest",
            temperature=temperature,
            **kwargs,
        )

    raise LLMProviderError(
        f"Unsupported llm provider: {provider}. "
        f"Supported providers: sarvam, openai, anthropic, claude"
    )


def _build_sarvam_llm(model: str, temperature: float, **kwargs: Any):
    api_key = os.getenv("SARVAM_API_KEY")
    if not api_key:
        raise LLMProviderError("SARVAM_API_KEY not found in environment.")

    # 1) Try installed package
    try:
        from langchain_sarvam import ChatSarvam

        try:
            return ChatSarvam(
                model=model,
                temperature=temperature,
                api_key=api_key,
                **kwargs,
            )
        except TypeError:
            return ChatSarvam(
                model_name=model,
                temperature=temperature,
                api_key=api_key,
                **kwargs,
            )
    except Exception:
        pass

    # 2) Try vendored package
    try:
        from ragkit._vendor.langchain_sarvam import ChatSarvam

        try:
            return ChatSarvam(
                model=model,
                temperature=temperature,
                api_key=api_key,
                **kwargs,
            )
        except TypeError:
            return ChatSarvam(
                model_name=model,
                temperature=temperature,
                api_key=api_key,
                **kwargs,
            )
    except Exception as exc:
        raise LLMProviderError(
            "Sarvam provider selected, but no working Sarvam integration was found.\n"
            "To fix this:\n"
            "1. install a working `langchain_sarvam` package, or\n"
            "2. vendor it correctly inside `src/ragkit/_vendor/langchain_sarvam`, or\n"
            "3. use `llm_provider='openai'` / `llm_provider='claude'`, or\n"
            "4. pass a custom `llm=` object.\n"
        ) from exc

        
def _build_openai_llm(model: str, temperature: float, **kwargs: Any):
    try:
        from langchain_openai import ChatOpenAI
    except ImportError as exc:
        raise LLMProviderError(
            "OpenAI support is not installed. Install with: pip install 'rag-kit[openai]'"
        ) from exc

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise LLMProviderError("OPENAI_API_KEY not found in environment.")

    return ChatOpenAI(
        model=model,
        temperature=temperature,
        api_key=api_key,
        **kwargs,
    )


def _build_anthropic_llm(model: str, temperature: float, **kwargs: Any):
    try:
        from langchain_anthropic import ChatAnthropic
    except ImportError as exc:
        raise LLMProviderError(
            "Anthropic support is not installed. Install with: pip install 'rag-kit[anthropic]'"
        ) from exc

    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise LLMProviderError("ANTHROPIC_API_KEY not found in environment.")

    return ChatAnthropic(
        model=model,
        temperature=temperature,
        api_key=api_key,
        **kwargs,
    )