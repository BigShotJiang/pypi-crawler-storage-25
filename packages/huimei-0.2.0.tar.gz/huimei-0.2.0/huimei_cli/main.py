"""慧媒引擎CLI客户端 - 主入口"""

import typer
from rich.console import Console

from huimei_cli import __version__
from huimei_cli.commands import auth_cmd, account_cmd, publish_cmd

console = Console()

app = typer.Typer(
    name="huimei",
    help="慧媒引擎CLI - 本地自动化执行器",
    no_args_is_help=True,
)

# Register sub-commands
app.add_typer(auth_cmd.app, name="auth", help="登录/登出/状态")
app.add_typer(account_cmd.app, name="account", help="平台账号管理")
app.add_typer(publish_cmd.app, name="publish", help="内容发布")


# Top-level convenience commands
@app.command()
def login(
    password_mode: bool = typer.Option(
        False, "--password", "-p", help="使用用户名密码登录（非浏览器）"
    ),
    server: str = typer.Option(None, help="服务器地址"),
):
    """登录慧媒引擎账号 (快捷方式)"""
    from huimei_cli.auth import do_login, do_browser_login, get_current_user
    from huimei_cli.config import get_server_url

    if password_mode:
        username = typer.prompt("用户名")
        password = typer.prompt("密码", hide_input=True)
        with console.status("正在登录..."):
            ok = do_login(username, password, server)
        if ok:
            user = get_current_user()
            name = user.get("username", username) if user else username
            console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
        else:
            console.print("[red]✗[/red] 登录失败")
            raise typer.Exit(1)
    else:
        target = server or get_server_url()
        console.print(f"[cyan]正在打开浏览器登录...[/cyan]")
        console.print(f"[dim]服务器: {target}[/dim]")
        console.print("[dim]请在浏览器中完成登录，登录成功后将自动获取凭证[/dim]")
        ok = do_browser_login(server)
        if ok:
            user = get_current_user()
            name = user.get("username", "用户") if user else "用户"
            console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
        else:
            console.print("[red]✗[/red] 登录失败或超时")
            raise typer.Exit(1)


@app.command()
def status():
    """查看当前状态 (快捷方式)"""
    auth_cmd.status()


@app.command()
def platforms():
    """列出支持的平台"""
    from huimei_cli.auth import is_logged_in
    from huimei_cli.config import get_config, get_server_url
    from huimei_cli.api_client import ApiClient, ApiError
    from rich.table import Table

    table = Table(title="支持的平台")
    table.add_column("平台ID", style="cyan")
    table.add_column("名称")
    table.add_column("视频", justify="center")
    table.add_column("图文", justify="center")

    # 优先从后端API获取
    if is_logged_in():
        try:
            cfg = get_config()
            client = ApiClient(get_server_url(), cfg.get("token"))
            plats = client.get_platforms()
            if plats:
                for p in plats:
                    table.add_row(
                        p.get("id", "?"),
                        p.get("name", "?"),
                        "✅" if p.get("supports_video") else "❌",
                        "✅" if p.get("supports_image") else "❌",
                    )
                console.print(table)
                return
        except Exception:
            console.print("[dim]后端查询失败，显示本地已知平台[/dim]")

    # 降级：本地registry（排除sample和_开头）
    console.print("[yellow]未登录[/yellow]，显示本地已知平台")
    import importlib, os
    registry_dir = os.path.join(
        os.path.dirname(__file__), "platforms", "registry"
    )
    if os.path.isdir(registry_dir):
        for f in sorted(os.listdir(registry_dir)):
            if f.endswith(".py") and not f.startswith("_") and f != "sample.py":
                pid = f[:-3]
                try:
                    mod = importlib.import_module(
                        f"huimei_cli.platforms.registry.{pid}"
                    )
                    cfg = getattr(mod, "PLATFORM_CONFIG", {})
                    table.add_row(
                        pid,
                        cfg.get("name", pid),
                        "✅" if cfg.get("support_video") else "❌",
                        "✅" if cfg.get("support_image") else "❌",
                    )
                except Exception:
                    table.add_row(pid, "加载失败", "?", "?")

    console.print(table)


@app.command()
def version():
    """显示版本信息"""
    console.print(f"慧媒引擎CLI v{__version__}")


if __name__ == "__main__":
    app()
