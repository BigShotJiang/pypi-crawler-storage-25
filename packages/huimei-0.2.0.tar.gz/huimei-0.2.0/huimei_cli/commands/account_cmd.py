"""Account commands: add, list, check."""

import typer
from rich.console import Console
from rich.table import Table

from huimei_cli.auth import is_logged_in
from huimei_cli.config import get_config, get_server_url
from huimei_cli.api_client import ApiClient, ApiError

console = Console()
app = typer.Typer(help="平台账号管理")


def _require_login():
    if not is_logged_in():
        console.print("[red]✗[/red] 请先登录: huimei login")
        raise typer.Exit(1)


def _get_client() -> ApiClient:
    cfg = get_config()
    return ApiClient(get_server_url(), cfg.get("token"))


@app.command(name="list")
def list_accounts():
    """列出已绑定的平台账号"""
    _require_login()
    try:
        client = _get_client()
        accounts = client.get_accounts()
        if not accounts:
            console.print("[dim]暂无绑定账号，使用 huimei account add <平台> 添加[/dim]")
            return
        table = Table(title="已绑定账号")
        table.add_column("平台", style="cyan")
        table.add_column("账号名")
        table.add_column("状态")
        for acc in accounts:
            # account_status: 1=正常(在线), 0=离线, 2=失效
            ast = acc.get("account_status")
            if ast == 1:
                status_str = "[green]在线[/green]"
            elif ast == 2:
                status_str = "[red]失效[/red]"
            else:
                status_str = "[yellow]离线[/yellow]"
            table.add_row(
                acc.get("platform_name", acc.get("platform", acc.get("platform_id", "?"))),
                acc.get("account_name", acc.get("name", "未知")),
                status_str,
            )
        console.print(table)
    except ApiError as e:
        console.print(f"[red]✗[/red] 获取账号列表失败: {e.message}")


@app.command()
def add(platform: str = typer.Argument(..., help="平台ID，如 douyin, xhs")):
    """添加平台账号（打开本地浏览器登录）"""
    _require_login()
    console.print(f"[cyan]即将打开浏览器，请在浏览器中登录 {platform} 账号...[/cyan]")
    console.print("[dim]登录成功后浏览器会自动关闭，Cookie将安全保存在本地[/dim]")

    import asyncio
    try:
        asyncio.run(_do_add_account(platform))
    except KeyboardInterrupt:
        console.print("\n[yellow]已取消[/yellow]")
    except Exception as e:
        console.print(f"[red]✗[/red] 添加账号失败: {e}")


async def _do_add_account(platform: str):
    """Execute the account add flow with Playwright."""
    from huimei_cli.engine.session import CliSession
    from huimei_cli.engine.browser import create_browser_session

    session = CliSession(platform_id=platform, session_type="login")
    manager, context, page = await create_browser_session(headless=False)

    try:
        session.playwright_browser = manager.browser
        session.playwright_context = context
        session.playwright_page = page
        session.page = page
        session.context_obj = context
        session.browser = manager.browser

        # Load the platform's login orchestrator
        from huimei_cli.engine.router import get_login_orchestrator
        orchestrator = get_login_orchestrator(platform)
        if not orchestrator:
            console.print(f"[red]✗[/red] 平台 {platform} 暂不支持")
            return

        result = await orchestrator.execute_login(session)
        if result:
            console.print(f"[green]✓[/green] {platform} 账号添加成功: {result.get('account_name', '')}")
        else:
            console.print(f"[red]✗[/red] {platform} 登录失败或超时")
    finally:
        await manager.close()


@app.command()
def check(platform: str = typer.Argument(..., help="平台ID")):
    """检查平台账号Cookie是否有效"""
    _require_login()
    console.print(f"[dim]检查 {platform} 账号状态...[/dim]")
    # TODO: implement cookie validation
    console.print("[yellow]Cookie验证功能开发中[/yellow]")
