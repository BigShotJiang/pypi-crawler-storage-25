"""慧媒引擎 MCP Server — AI Agent 社媒自动化工具集

启动方式: huimei-mcp-server (stdio模式)
配置方式: 在 Claude Code / Hermes 的 MCP config 中添加 command: huimei-mcp-server
"""

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "huimei",
    instructions=(
        "慧媒引擎 — 多平台社媒自动化发布工具。"
        "支持抖音/快手/B站/小红书/微博等11个平台的账号管理和内容发布。"
        "使用前请先调用 huimei_login 登录。"
    ),
)


def _get_client():
    """获取已认证的 ApiClient，未登录则返回 None。"""
    from huimei_cli.config import get_server_url, get_token
    from huimei_cli.api_client import ApiClient
    token = get_token()
    if not token:
        return None
    return ApiClient(server_url=get_server_url(), token=token)


@mcp.tool()
def huimei_login(username: str, password: str, server_url: str = "") -> str:
    """登录慧媒引擎（用户名密码方式）。首次使用必须调用。"""
    from huimei_cli.auth import do_login, get_current_user
    url = server_url or None
    ok = do_login(username, password, url)
    if not ok:
        return "❌ 登录失败，请检查用户名密码"
    user = get_current_user()
    name = user.get("username", username) if user else username
    return f"✅ 登录成功，欢迎 {name}"


@mcp.tool()
def huimei_status() -> str:
    """查看当前登录状态、用户信息和订阅情况"""
    from huimei_cli.auth import is_logged_in, get_current_user
    from huimei_cli.config import get_server_url
    if not is_logged_in():
        return "未登录。请先调用 huimei_login"
    user = get_current_user()
    lines = [
        f"用户: {user.get('username', '?')}",
        f"服务器: {get_server_url()}",
    ]
    client = _get_client()
    if client:
        try:
            sub = client.get_subscription_info()
            if sub:
                lines.append(f"订阅: {sub.get('plan_name', '?')} (到期: {sub.get('expire_date', '?')})")
        except Exception:
            lines.append("订阅: 查询失败")
    return "\n".join(lines)


@mcp.tool()
def huimei_logout() -> str:
    """登出当前账号"""
    from huimei_cli.auth import logout
    logout()
    return "✅ 已登出"


@mcp.tool()
def huimei_platforms() -> str:
    """列出所有支持的社媒平台及其能力（视频/图文）"""
    # 优先从后端API获取
    client = _get_client()
    if client:
        try:
            plats = client.get_platforms()
            if plats:
                lines = ["平台ID | 名称 | 视频 | 图文"]
                for p in plats:
                    v = "✅" if p.get("supports_video") else "❌"
                    i = "✅" if p.get("supports_image") else "❌"
                    lines.append(
                        f"{p.get('id','?')} | {p.get('name','?')} | {v} | {i}"
                    )
                return "\n".join(lines)
        except Exception:
            pass
    return "未登录或查询失败，请先调用 huimei_login"


@mcp.tool()
def huimei_accounts() -> str:
    """列出所有已绑定的社媒平台账号"""
    client = _get_client()
    if not client:
        return "未登录。请先调用 huimei_login"
    try:
        accounts = client.get_accounts()
    except Exception as e:
        return f"查询失败: {e}"
    if not accounts:
        return "暂无绑定账号"
    lines = []
    for a in accounts:
        ast = a.get("account_status")
        if ast == 1:
            status = "🟢"
        elif ast == 2:
            status = "🔴"
        else:
            status = "🟡"
        name = a.get("account_name", a.get("name", "?"))
        plat = a.get("platform_name", a.get("platform", "?"))
        lines.append(f"{status} {plat} | {name} | ID:{a.get('id','?')}")
    return f"共 {len(accounts)} 个账号:\n" + "\n".join(lines)


@mcp.tool()
def huimei_publish(
    account_id: int,
    title: str = "",
    content: str = "",
    video_path: str = "",
    tags: str = "",
) -> str:
    """创建发布任务。account_id 从 huimei_accounts 获取。tags 逗号分隔。"""
    client = _get_client()
    if not client:
        return "未登录。请先调用 huimei_login"
    task_data = {"account_id": account_id}
    if title:
        task_data["title"] = title
    if content:
        task_data["content"] = content
    if video_path:
        task_data["video_path"] = video_path
    if tags:
        task_data["tags"] = [t.strip() for t in tags.split(",")]
    try:
        result = client.create_task(task_data)
        return f"✅ 任务已创建: {result}"
    except Exception as e:
        return f"❌ 创建失败: {e}"


def main():
    """MCP Server 入口 (stdio 模式)"""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
