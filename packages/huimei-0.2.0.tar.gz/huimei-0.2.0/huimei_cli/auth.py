"""Authentication management for huimei-cli."""

import json
import base64
import asyncio

from huimei_cli.config import get_config, save_config, get_server_url, save_token
from huimei_cli.api_client import ApiClient, ApiError


def do_login(username: str, password: str, server_url: str = None) -> bool:
    """Login via username/password API call."""
    url = server_url or get_server_url()
    client = ApiClient(server_url=url)
    try:
        data = client.login(username, password)
        token = data.get("token") if isinstance(data, dict) else None
        if not token:
            return False
        save_token(token)
        if server_url:
            cfg = get_config()
            cfg["server_url"] = server_url
            save_config(cfg)
        return True
    except (ApiError, Exception):
        return False


def do_browser_login(server_url: str = None) -> bool:
    """Open browser to login page, wait for token in localStorage."""
    url = server_url or get_server_url()
    login_url = url.rstrip("/") + "/login"
    try:
        return asyncio.run(_browser_login_flow(login_url, url))
    except Exception:
        return False


async def _browser_login_flow(login_url: str, server_url: str) -> bool:
    """Playwright flow: open login page, poll for token."""
    from playwright.async_api import async_playwright

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()
        await page.goto(login_url, wait_until="domcontentloaded")

        # Poll localStorage for token (max 5 minutes)
        token = None
        for _ in range(300):
            await asyncio.sleep(1)
            try:
                token = await page.evaluate(
                    "localStorage.getItem('token')"
                )
                if token:
                    break
            except Exception:
                if page.is_closed():
                    break
        await browser.close()

    if token:
        save_token(token)
        if server_url != get_server_url():
            cfg = get_config()
            cfg["server_url"] = server_url
            save_config(cfg)
        return True
    return False


def is_logged_in() -> bool:
    """Check whether a valid token exists in config."""
    cfg = get_config()
    return bool(cfg.get("token"))


def get_current_user() -> dict | None:
    """Decode the JWT token payload to get current user info.

    Decodes without verification — only reads the payload claims.

    Returns:
        Dict of user claims from token, or None if not logged in.
    """
    cfg = get_config()
    token = cfg.get("token")
    if not token:
        return None
    try:
        payload_b64 = token.split(".")[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        return json.loads(payload_bytes)
    except (IndexError, ValueError, json.JSONDecodeError):
        return None


def logout() -> None:
    """Clear authentication token from config."""
    cfg = get_config()
    cfg.pop("token", None)
    save_config(cfg)
