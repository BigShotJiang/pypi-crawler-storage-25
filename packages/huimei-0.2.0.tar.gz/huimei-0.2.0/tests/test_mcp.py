"""Tests for MCP Server tools."""
import pytest


def test_mcp_server_imports():
    """MCP server module can be imported."""
    from huimei_cli.mcp_server import mcp, main
    assert mcp is not None
    assert callable(main)


def test_mcp_tools_registered():
    """All 6 tools are registered."""
    from huimei_cli.mcp_server import mcp
    tools = {t.name for t in mcp._tool_manager._tools.values()}
    expected = {
        "huimei_login", "huimei_status", "huimei_logout",
        "huimei_platforms", "huimei_accounts", "huimei_publish",
    }
    assert expected == tools


def test_huimei_platforms_tool():
    """Platforms tool returns platform list text."""
    from huimei_cli.mcp_server import huimei_platforms
    result = huimei_platforms()
    assert ("douyin" in result.lower() or "抖音" in result
            or "未登录" in result)


def test_huimei_status_returns_string():
    """Status tool returns a non-empty string."""
    from huimei_cli.mcp_server import huimei_status
    result = huimei_status()
    assert isinstance(result, str) and len(result) > 0


def test_huimei_accounts_returns_string():
    """Accounts tool returns a non-empty string."""
    from huimei_cli.mcp_server import huimei_accounts
    result = huimei_accounts()
    assert isinstance(result, str) and len(result) > 0
