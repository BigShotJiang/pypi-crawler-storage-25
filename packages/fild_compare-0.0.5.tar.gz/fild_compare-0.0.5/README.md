> **DEPRECATED** — This package is no longer maintained.
> Migrate to [surety-diff](https://github.com/elenakulgavaya/surety-diff):
> `pip install surety-diff`
>
> Replace `from fild_compare import compare` with `from surety.diff import compare`.
> Replace `from fild_compare.rules import ...` with `from surety.diff.rules import ...`.

# fild-compare v 0.0.5

![Downloads](https://img.shields.io/pypi/dm/fild-compare.svg?style=flat)
![Python Versions](https://img.shields.io/pypi/pyversions/fild-compare.svg?style=flat)
![License](https://img.shields.io/pypi/l/fild-compare.svg?version=latest)
[![Build Status](https://github.com/elenakulgavaya/fild-compare/workflows/Tests/badge.svg)](https://github.com/elenakulgavaya/fild-compare/actions)


