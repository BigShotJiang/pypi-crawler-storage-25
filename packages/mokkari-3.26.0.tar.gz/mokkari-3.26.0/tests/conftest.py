"""Conftest module.

This module contains pytest fixtures.
"""

import os

import pytest
from pyrate_limiter import Duration, InMemoryBucket, Rate

from mokkari import api
from mokkari.session import Session

_HIGH_RATE = [Rate(10_000, Duration.MINUTE)]


@pytest.fixture(scope="session")
def dummy_username() -> str:
    """Username fixture."""
    return os.getenv("METRON_USERNAME", "username")


@pytest.fixture(scope="session")
def dummy_password() -> str:
    """Password fixture."""
    return os.getenv("METRON_PASSWD", "passwd")


@pytest.fixture(scope="session")
def talker(dummy_username: str, dummy_password: str) -> Session:
    """Mokkari api fixture."""
    return api(
        username=dummy_username,
        passwd=dummy_password,
        bucket=InMemoryBucket(_HIGH_RATE),
    )
