def listpublic(API, lastEvaluatedKey=None) -> dict:
    """
    Fetches the list of public posts from the API.

    Args:
        lastEvaluatedKey (dict, optional): Key to start fetching posts from.
        Returns:
            dict: The list of public posts.
    """
    post_list = API.make_request("GET", "content", f"post/public", authenticate=True, query_params=lastEvaluatedKey)
    return post_list