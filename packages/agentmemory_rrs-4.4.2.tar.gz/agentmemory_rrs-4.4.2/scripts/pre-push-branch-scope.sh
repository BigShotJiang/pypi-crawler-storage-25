#!/usr/bin/env bash
# pre-push-branch-scope.sh
#
# Enforce issue-scoped branch naming and basic push scope hygiene.
#
# Install: agentmemory setup (auto-installs managed pre-push block),
# or add this script to your .git/hooks/pre-push manually.

set -euo pipefail

BRANCH="$(git symbolic-ref --quiet --short HEAD 2>/dev/null || true)"

# Enforce: type/gh-<number>-<slug>
BRANCH_RE='^(fix|feat|chore|docs|refactor|test|perf|hotfix|release)/gh-([0-9]+)-[a-z0-9._-]+$'
RELEASE_BRANCH_RE='^release/gh-([0-9]+)-[a-z0-9._-]+$'

if [[ -z "$BRANCH" ]]; then
  echo "[branch-scope] BLOCKED: detached HEAD is not allowed for pushes."
  echo "Use an issue branch: fix/gh-123-short-slug"
  exit 1
fi

# main/master always allowed — release merges land here
if [[ "$BRANCH" == "main" || "$BRANCH" == "master" ]]; then
  exit 0
fi

if [[ ! "$BRANCH" =~ $BRANCH_RE ]]; then
  echo "[branch-scope] BLOCKED: branch '$BRANCH' does not match required format."
  echo "Required: <type>/gh-<issue>-<slug>"
  echo "Example: fix/gh-51-mcp-merge"
  exit 1
fi

BRANCH_ISSUE="${BASH_REMATCH[2]}"

if [[ "$BRANCH" =~ $RELEASE_BRANCH_RE ]]; then
  # Release branches intentionally aggregate already-merged issue work.
  # They still require an owning GH issue, but commit subjects may reference
  # multiple issues that were previously merged into main.
  exit 0
fi

# Optional scope guard: commits being pushed should not reference different issues.
# Read refs from stdin per git pre-push hook contract:
# <local ref> <local sha1> <remote ref> <remote sha1>
MISMATCH=0
while read -r LOCAL_REF LOCAL_SHA REMOTE_REF REMOTE_SHA; do
  [[ -z "${LOCAL_SHA:-}" ]] && continue
  [[ "$LOCAL_SHA" =~ ^0+$ ]] && continue

  RANGE="$LOCAL_SHA"
  if [[ -n "${REMOTE_SHA:-}" && ! "$REMOTE_SHA" =~ ^0+$ ]]; then
    RANGE="${REMOTE_SHA}..${LOCAL_SHA}"
  fi

  while IFS= read -r SUBJECT; do
    [[ -z "$SUBJECT" ]] && continue
    if [[ "$SUBJECT" =~ [Gg][Hh]-([0-9]+) ]]; then
      ISSUE="${BASH_REMATCH[1]}"
      if [[ "$ISSUE" != "$BRANCH_ISSUE" ]]; then
        MISMATCH=1
        echo "[branch-scope] Commit issue mismatch: branch gh-${BRANCH_ISSUE}, commit subject: '$SUBJECT'"
      fi
    elif [[ "$SUBJECT" =~ \#([0-9]+) ]]; then
      ISSUE="${BASH_REMATCH[1]}"
      if [[ "$ISSUE" != "$BRANCH_ISSUE" ]]; then
        MISMATCH=1
        echo "[branch-scope] Commit issue mismatch: branch gh-${BRANCH_ISSUE}, commit subject: '$SUBJECT'"
      fi
    fi
  done < <(git log --format=%s "$RANGE")
done

if [[ "$MISMATCH" -ne 0 ]]; then
  echo "[branch-scope] BLOCKED: pushed commits reference issue IDs that do not match this branch."
  echo "Branch must stay scoped to gh-${BRANCH_ISSUE}."
  exit 1
fi

exit 0
