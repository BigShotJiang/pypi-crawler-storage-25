#!/usr/bin/env python3
"""Enforce conventional commit message prefixes and append LLM authorship."""

from __future__ import annotations

import os
import re
import sys

PREFIXES: list[str] = [
    "feat",
    "fix",
    "docs",
    "test",
    "refactor",
    "perf",
    "chore",
    "experiment",
    "benchmark",
    "style",
    "ci",
    "build",
    "revert",
    "hotfix",
]

PATTERN: str = r"^(" + "|".join(PREFIXES) + r")(\(.+\))?!?: .+"


def _append_llm_attribution(msg_file: str) -> None:
    """Append ', authored by <model> <effort>' to the subject line if env vars are set.

    Reads AGENTMEMORY_LLM_MODEL and AGENTMEMORY_LLM_EFFORT from the environment.
    Skips if already present. Writes back to the commit-msg file in place.
    """
    model: str = os.environ.get("AGENTMEMORY_LLM_MODEL", "").strip()
    if not model:
        return

    effort: str = os.environ.get("AGENTMEMORY_LLM_EFFORT", "").strip()
    attribution: str = f", authored by {model}" + (f" {effort}" if effort else "")

    with open(msg_file, encoding="utf-8") as f:
        lines: list[str] = f.readlines()

    if not lines:
        return

    subject: str = lines[0].rstrip("\n")

    # Idempotent: skip if attribution already in subject
    if "authored by" in subject.lower():
        return

    lines[0] = subject + attribution + "\n"
    with open(msg_file, "w", encoding="utf-8") as f:
        f.writelines(lines)


def main() -> None:
    msg_file: str = sys.argv[1]
    msg: str = open(msg_file).read().strip()

    # Allow merge commits
    if msg.startswith("Merge "):
        sys.exit(0)

    if not re.match(PATTERN, msg):
        print(f"Bad commit message: {msg!r}")
        print(f"Must start with one of: {', '.join(PREFIXES)}")
        print("Example: feat: add batch ingestion")
        print("Example: fix(scoring): correct decay half-life")
        sys.exit(1)

    # Append LLM attribution when running as an AI agent
    _append_llm_attribution(msg_file)


if __name__ == "__main__":
    main()
