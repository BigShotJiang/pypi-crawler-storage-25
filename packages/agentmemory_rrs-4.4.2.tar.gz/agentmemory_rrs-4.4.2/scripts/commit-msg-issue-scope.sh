#!/usr/bin/env bash
# commit-msg-issue-scope.sh
#
# Keep commit subjects aligned with issue-scoped branch names.
#
# Behavior on issue branches:
# - append " (GH-<n>)" when the subject has no issue reference
# - block commits whose subject references a different GH issue / #number
# - leave release branches unchanged because they intentionally aggregate issues

set -euo pipefail

MSG_FILE="${1:-}"
if [[ -z "$MSG_FILE" || ! -f "$MSG_FILE" ]]; then
  exit 0
fi

BRANCH="$(git symbolic-ref --quiet --short HEAD 2>/dev/null || true)"
BRANCH_RE='^(fix|feat|chore|docs|refactor|test|perf|hotfix|release)/gh-([0-9]+)-[a-z0-9._-]+$'
RELEASE_BRANCH_RE='^release/gh-([0-9]+)-[a-z0-9._-]+$'

if [[ -z "$BRANCH" || ! "$BRANCH" =~ $BRANCH_RE ]]; then
  exit 0
fi

BRANCH_ISSUE="${BASH_REMATCH[2]}"

if [[ "$BRANCH" =~ $RELEASE_BRANCH_RE ]]; then
  exit 0
fi

SUBJECT="$(head -n 1 "$MSG_FILE")"

if [[ "$SUBJECT" =~ [Gg][Hh]-([0-9]+) ]]; then
  ISSUE="${BASH_REMATCH[1]}"
  if [[ "$ISSUE" != "$BRANCH_ISSUE" ]]; then
    echo "[issue-scope] BLOCKED: branch gh-${BRANCH_ISSUE}, commit subject references GH-${ISSUE}." >&2
    echo "[issue-scope] Use the matching issue ID or move the change to the correct branch." >&2
    exit 1
  fi
  exit 0
fi

if [[ "$SUBJECT" =~ \#([0-9]+) ]]; then
  ISSUE="${BASH_REMATCH[1]}"
  if [[ "$ISSUE" != "$BRANCH_ISSUE" ]]; then
    echo "[issue-scope] BLOCKED: branch gh-${BRANCH_ISSUE}, commit subject references #${ISSUE}." >&2
    echo "[issue-scope] Use the matching issue ID or move the change to the correct branch." >&2
    exit 1
  fi
  exit 0
fi

python3 - "$MSG_FILE" "$BRANCH_ISSUE" <<'PY'
from __future__ import annotations

from pathlib import Path
import sys

msg_path = Path(sys.argv[1])
issue = sys.argv[2]
lines = msg_path.read_text(encoding="utf-8").splitlines()
if not lines:
    raise SystemExit(0)
lines[0] = f"{lines[0]} (GH-{issue})"
msg_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
PY

exit 0
