#!/usr/bin/env bash
# agentmemory-gh-pii-guard.sh — PreToolUse hook: scan gh posting commands for sensitive content
#
# Intercepts Bash tool calls that post content to GitHub (gh issue create,
# gh issue comment, gh pr create, gh pr comment, gh pr edit, gh issue edit,
# gh release create) and blocks them if the content contains configured
# sensitive patterns.
#
# Pattern sources (evaluated in order, all patterns merged):
#   1. ~/.agentmemory/pii-patterns.txt   -- user-level patterns (one regex per line)
#   2. .agentmemory-pii-patterns          -- project-level patterns (one regex per line)
#
# Both files support # comments and blank lines.
#
# Pattern format: ERE (extended regular expression), same as grep -E.
#
# Claude Code hook protocol:
#   - Reads JSON from stdin: {"tool_name": "Bash", "tool_input": {"command": "..."}}
#   - Exit 0: allow
#   - Exit 2 + JSON stdout {"decision": "block", "reason": "..."}: block
#
# Install: agentmemory setup (wires this into ~/.claude/settings.json automatically)
# Add patterns: agentmemory add-pii-pattern '<regex>'
# List patterns: agentmemory list-pii-patterns

set -euo pipefail

INPUT=$(cat)

# Extract command from JSON using Python (no jq dependency)
CMD=$(echo "$INPUT" | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
    print(d.get('tool_input', {}).get('command', ''))
except Exception:
    pass
" 2>/dev/null || true)

# Only intercept gh commands that write/post content to GitHub.
# Read-only commands (issue list, issue view, pr list, pr view, etc.) pass through.
if ! echo "$CMD" | grep -qE \
    '^\s*gh\s+(issue\s+(create|edit|comment)|pr\s+(create|edit|comment)|release\s+create)'; then
    exit 0
fi

# Collect patterns from user-level and project-level config files
USER_PATTERNS_FILE="${HOME}/.agentmemory/pii-patterns.txt"
PROJECT_PATTERNS_FILE=".agentmemory-pii-patterns"

PATTERNS=()

_load_patterns() {
    local file="$1"
    if [ ! -f "$file" ]; then
        return
    fi
    while IFS= read -r line; do
        # Skip blank lines and comments
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue
        PATTERNS+=("$line")
    done < "$file"
}

_load_patterns "$USER_PATTERNS_FILE"
_load_patterns "$PROJECT_PATTERNS_FILE"

# If no patterns configured, nothing to check -- pass through
if [ ${#PATTERNS[@]} -eq 0 ]; then
    exit 0
fi

# Scan the command against each pattern
MATCHED_PATTERN=""
for PATTERN in "${PATTERNS[@]}"; do
    if echo "$CMD" | grep -qE "$PATTERN"; then
        MATCHED_PATTERN="$PATTERN"
        break
    fi
done

if [ -n "$MATCHED_PATTERN" ]; then
    # Escape for JSON string embedding
    SAFE_PATTERN=$(echo "$MATCHED_PATTERN" | python3 -c "import json,sys; print(json.dumps(sys.stdin.read().rstrip()))")
    python3 - <<PYEOF
import json
pattern = $SAFE_PATTERN
reason = (
    "Sensitive content pattern detected in gh command before posting to public GitHub. "
    f"Matched pattern: {pattern!r}. "
    "Remove sensitive content before posting, or edit ~/.agentmemory/pii-patterns.txt "
    "to update your configured patterns."
)
print(json.dumps({"decision": "block", "reason": reason}))
PYEOF
    exit 2
fi

exit 0
