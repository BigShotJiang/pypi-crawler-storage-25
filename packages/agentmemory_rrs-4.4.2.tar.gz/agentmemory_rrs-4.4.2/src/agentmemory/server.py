"""MCP server for agentmemory, exposing memory tools via FastMCP.

Provides search, remember, correct, observe, status, get_locked, and resume_state
tools. Uses a single lazily-initialized MemoryStore backed by
~/.agentmemory/memory.db.
"""

from __future__ import annotations

import argparse
import atexit
from collections import Counter
from contextlib import contextmanager, redirect_stdout
import json
import io
import os
import re
import signal
import sqlite3
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, cast

from fastmcp import FastMCP

from agentmemory.classification import (
    BATCH_SIZE,
    ClassifiedSentence,
    classify_sentences_offline,
    classify_with_llm,
    get_source_adjusted_prior,
)
from agentmemory.compression import compress_belief, estimate_tokens
from agentmemory.hook_search import (
    analyze_prompt_structure,
    evaluate_activation_conditions,
    StructuralAnalysis,
)
from agentmemory.ingest import (
    ExtractedTurn,
    IngestResult,
    create_beliefs_from_classified,
    extract_turn,
    ingest_turn,
)
from agentmemory.scanner import ScanResult, scan_project
from agentmemory.models import (
    BSRC_USER_CORRECTED,
    BSRC_USER_STATED,
    BELIEF_FACTUAL,
    BELIEF_CORRECTION,
    LAYER_EXPLICIT,
    LAYER_IMPLICIT,
    OBS_TYPE_USER_STATEMENT,
    OUTCOME_CONFIRMED,
    OUTCOME_HARMFUL,
    OUTCOME_IGNORED,
    OUTCOME_USED,
    OUTCOME_WEAK,
    VALENCE_MAP,
    CONFIRM_WEIGHT,
    Belief,
    Observation,
    Session,
    TestResult,
)
from agentmemory.relationship_detector import detect_relationships
from agentmemory.retrieval import RetrievalResult, retrieve
from agentmemory.store import MemoryStore, row_to_belief

# ---------------------------------------------------------------------------
# Input limits
# ---------------------------------------------------------------------------

MAX_TEXT_LENGTH: int = 50_000  # 50KB per input field
MAX_BULK_ITEMS: int = 500  # max beliefs in create_beliefs / bulk_delete
MAX_LOCKED_OUTPUT_CHARS: int = 3000
MAX_RESUME_OUTPUT_CHARS: int = 2000
DEFAULT_SEARCH_TIMEOUT_SEC: float = 15.0


def _check_length(text: str, field: str = "text") -> str | None:
    """Return error string if text exceeds limit, else None."""
    if len(text) > MAX_TEXT_LENGTH:
        return f"Error: {field} exceeds {MAX_TEXT_LENGTH} character limit ({len(text)} chars)."
    return None


class _SearchTimeoutError(RuntimeError):
    """Raised when a search call exceeds the allowed runtime."""


def _search_timeout_seconds() -> float:
    """Return bounded search timeout from env (seconds)."""
    raw: str = os.environ.get("AGENTMEMORY_SEARCH_TIMEOUT_SEC", "").strip()
    if not raw:
        return DEFAULT_SEARCH_TIMEOUT_SEC
    try:
        value: float = float(raw)
    except ValueError:
        return DEFAULT_SEARCH_TIMEOUT_SEC
    return max(0.1, min(value, 120.0))


@contextmanager
def _search_timeout_guard(seconds: float) -> Iterator[None]:
    """Best-effort wall clock timeout for search on POSIX main thread."""
    if (
        seconds <= 0
        or not hasattr(signal, "SIGALRM")
        or threading.current_thread() is not threading.main_thread()
    ):
        yield
        return

    def _alarm_handler(_signum: int, _frame: object) -> None:
        raise _SearchTimeoutError()

    old_handler = signal.getsignal(signal.SIGALRM)
    try:
        signal.signal(signal.SIGALRM, _alarm_handler)
        signal.setitimer(signal.ITIMER_REAL, seconds)
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old_handler)


# ---------------------------------------------------------------------------
# Store singleton + session tracking
# ---------------------------------------------------------------------------

_store: MemoryStore | None = None
_session_id: str | None = None

# Retrieval tracking: maps session_id -> list of (belief_id, timestamp) tuples.
# Populated by search(), consumed by feedback() and auto-feedback.
_retrieval_buffer: dict[str, list[tuple[str, str]]] = {}
_MAX_RETRIEVAL_SESSIONS: int = 10  # prune oldest sessions beyond this

# Signal buffer: text from agent actions since the last auto-feedback processing.
# Populated by search() queries, remember/correct/observe text, and ingest().
# Consumed by _process_auto_feedback() for key-term matching.
_signal_buffer: list[str] = []
_MAX_SIGNAL_BUFFER: int = 1000  # drop oldest entries beyond this

# Belief IDs that already received explicit feedback this session.
# Auto-feedback skips these (explicit always wins).
_explicit_feedback_ids: set[str] = set()
_MAX_EXPLICIT_IDS: int = 5000  # cap to prevent unbounded growth

# TB-13: Count locked belief accesses for audit trail.
_locked_access_count: int = 0

# Store ownership diagnostics. When another live agentmemory process already
# owns the DB marker, search keeps working but skips write-side bookkeeping.
_store_db_path: Path | None = None
_store_ownership_warning: str | None = None


def _prune_buffers() -> None:
    """Prevent unbounded growth of module-level buffers."""
    global _signal_buffer
    # Retrieval buffer: keep only the most recent sessions
    if len(_retrieval_buffer) > _MAX_RETRIEVAL_SESSIONS:
        # Sort by most recent entry timestamp, drop oldest
        sorted_sids: list[str] = sorted(
            _retrieval_buffer,
            key=lambda s: _retrieval_buffer[s][-1][1] if _retrieval_buffer[s] else "",
        )
        for sid in sorted_sids[: len(sorted_sids) - _MAX_RETRIEVAL_SESSIONS]:
            del _retrieval_buffer[sid]

    # Signal buffer: trim to max size
    if len(_signal_buffer) > _MAX_SIGNAL_BUFFER:
        _signal_buffer = _signal_buffer[-_MAX_SIGNAL_BUFFER:]

    # Explicit feedback IDs: if over limit, clear (session-scoped anyway)
    if len(_explicit_feedback_ids) > _MAX_EXPLICIT_IDS:
        _explicit_feedback_ids.clear()


def _store_owner_marker_path(db_path: Path) -> Path:
    """Return the sidecar file used to record the active DB owner."""
    return db_path.with_name(f"{db_path.name}.owner.json")


def _pid_is_alive(pid: int) -> bool:
    """Return True when pid appears to still be running."""
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _read_store_owner_warning(db_path: Path) -> str | None:
    """Return a diagnostic string if another live process owns this DB."""
    marker_path: Path = _store_owner_marker_path(db_path)
    if not marker_path.exists():
        return None
    try:
        payload: object = json.loads(marker_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    data: dict[str, Any] = cast(dict[str, Any], payload)
    pid_obj: Any = data.get("pid")
    pid_text: str = "" if pid_obj is None else str(pid_obj)
    try:
        owner_pid: int = int(pid_text)
    except (TypeError, ValueError):
        return None
    current_pid: int = os.getpid()
    if owner_pid == current_pid:
        return None
    if not _pid_is_alive(owner_pid):
        return None

    started_at: str = str(data.get("started_at", "unknown"))
    command: str = str(data.get("command", "agentmemory"))
    return (
        "Another live agentmemory server is already using this DB "
        f"(pid {owner_pid}, started {started_at}, command: {command}). "
        "Search results will stay read-only, but write-side bookkeeping may be skipped."
    )


def _write_store_owner_marker(db_path: Path) -> None:
    """Record the current process as the active DB owner."""
    marker_path: Path = _store_owner_marker_path(db_path)
    payload: dict[str, object] = {
        "pid": os.getpid(),
        "started_at": datetime.now(timezone.utc).isoformat(),
        "command": " ".join(sys.argv).strip(),
        "db_path": str(db_path),
    }
    tmp_path: Path = marker_path.with_name(f"{marker_path.name}.{os.getpid()}.tmp")
    try:
        tmp_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        tmp_path.replace(marker_path)
    except OSError:
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except OSError:
            pass


def _refresh_store_ownership_warning(db_path: Path) -> str | None:
    """Refresh and cache the current ownership warning for this DB."""
    global _store_ownership_warning
    warning: str | None = _read_store_owner_warning(db_path)
    _store_ownership_warning = warning
    return warning


# ---------------------------------------------------------------------------
# Auto-feedback: key-term extraction and matching
# ---------------------------------------------------------------------------

_STOPWORDS: frozenset[str] = frozenset(
    {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "shall",
        "should",
        "may",
        "might",
        "must",
        "can",
        "could",
        "of",
        "in",
        "to",
        "for",
        "with",
        "on",
        "at",
        "by",
        "from",
        "as",
        "into",
        "through",
        "that",
        "this",
        "these",
        "those",
        "it",
        "its",
        "not",
        "no",
        "all",
        "and",
        "or",
        "but",
        "if",
        "then",
        "than",
        "when",
        "where",
        "how",
        "what",
        "which",
        "who",
        "whom",
        "use",
        "using",
        "used",
    }
)

# Minimum unique term matches to infer "used". From validation experiments:
# min_unique=2 gives 100% precision, 75% recall on realistic scenarios.
_AUTO_FEEDBACK_MIN_MATCHES: int = 2


def _extract_key_terms(text: str) -> list[str]:
    """Extract meaningful terms from text, filtering stopwords."""
    words: list[str] = re.findall(r"[a-zA-Z0-9_]+", text.lower())
    return [w for w in words if w not in _STOPWORDS and len(w) >= 2]


def _process_auto_feedback(session_id: str) -> int:
    """Process the previous retrieval batch: infer used/ignored from agent signals.

    Signal sources: search queries, remember/correct/observe text, ingest text.
    Returns the number of auto-feedback events recorded.
    """
    global _signal_buffer

    buffer: list[tuple[str, str]] | None = _retrieval_buffer.pop(session_id, None)
    if not buffer:
        # Clear signal buffer even when no retrieval batch exists,
        # so stale signals don't leak into the next batch.
        _signal_buffer = []
        return 0

    # Combine all signal text since the retrieval
    combined_signal: str = " ".join(_signal_buffer).lower()
    _signal_buffer = []

    if not combined_signal.strip():
        # No signal text -- everything is "ignored"
        store: MemoryStore = _get_store()
        count: int = 0
        for belief_id, _ts in buffer:
            if belief_id in _explicit_feedback_ids:
                continue
            store.record_test_result(
                belief_id=belief_id,
                session_id=session_id,
                outcome=OUTCOME_IGNORED,
                detection_layer=LAYER_IMPLICIT,
                outcome_detail="auto: no ingested text since retrieval",
            )
            count += 1
        if count > 0:
            store.increment_session_metrics(session_id, feedback_given=count)
        store.clear_pending_feedback(session_id)
        return count

    store = _get_store()
    count = 0
    for belief_id, _ts in buffer:
        if belief_id in _explicit_feedback_ids:
            continue

        belief: Belief | None = store.get_belief(belief_id)
        if belief is None:
            continue

        # Key-term overlap check with gradient scoring
        terms: list[str] = _extract_key_terms(belief.content)
        if not terms:
            continue

        unique_terms: set[str] = set(terms)
        unique_matches: int = sum(1 for t in unique_terms if t in combined_signal)

        # Gradient valence: overlap ratio instead of binary threshold
        overlap_ratio: float = unique_matches / max(len(unique_terms), 1)
        valence_score: float = min(1.0, overlap_ratio)

        # Legacy outcome for backward compat in tests table
        outcome: str = (
            OUTCOME_USED
            if unique_matches >= _AUTO_FEEDBACK_MIN_MATCHES
            else OUTCOME_IGNORED
        )
        detail: str = (
            f"auto: {unique_matches}/{len(unique_terms)} key terms matched "
            f"(valence: {valence_score:+.2f})"
        )

        store.record_test_result(
            belief_id=belief_id,
            session_id=session_id,
            outcome=outcome,
            detection_layer=LAYER_IMPLICIT,
            outcome_detail=detail,
            valence=valence_score if valence_score > 0 else None,
        )

        # Propagate feedback to edges that led to this belief.
        traversed: list[tuple[int, int]] | None = getattr(
            store,
            "_last_traversed_edges",
            {},
        ).get(belief_id)
        if traversed:
            store.propagate_feedback_to_edges(belief_id, outcome, traversed)

        count += 1

    if count > 0:
        store.increment_session_metrics(session_id, feedback_given=count)
    store.clear_pending_feedback(session_id)
    return count


def _flush_feedback_on_exit() -> None:
    """Flush the last retrieval batch's auto-feedback when the server exits.

    Without this, the final search()'s retrieved beliefs never get feedback
    because no subsequent search() or ingest() triggers processing.
    """
    if _session_id is not None:
        _process_auto_feedback(_session_id)


atexit.register(_flush_feedback_on_exit)


def _sigterm_handler(signum: int, frame: object) -> None:
    """Handle SIGTERM by flushing feedback before exit.

    MCP servers inside Claude Code receive SIGTERM when the session ends.
    atexit handlers don't always run on signal-based termination, so we
    explicitly flush here.
    """
    _flush_feedback_on_exit()
    raise SystemExit(0)


signal.signal(signal.SIGTERM, _sigterm_handler)


def _resolve_server_db() -> Path:
    """Resolve DB path for the MCP server: AGENTMEMORY_DB env > cwd-based isolation."""
    import hashlib
    import os

    env_db: str | None = os.environ.get("AGENTMEMORY_DB")
    if env_db:
        p: Path = Path(env_db)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p
    # Per-project: hash of cwd
    home: Path = Path.home() / ".agentmemory"
    abs_path: str = str(Path.cwd().resolve())
    path_hash: str = hashlib.sha256(abs_path.encode()).hexdigest()[:12]
    db_dir: Path = home / "projects" / path_hash
    db_dir.mkdir(parents=True, exist_ok=True)
    meta_path: Path = db_dir / "project.txt"
    if not meta_path.exists():
        meta_path.write_text(abs_path + "\n", encoding="utf-8")
    return db_dir / "memory.db"


def _get_store() -> MemoryStore:
    """Return the module-level store, creating it on first call.

    If obsidian.vault_path is configured, returns a VaultStore (vault-first
    with SQLite index). Otherwise returns a plain MemoryStore (v1 behavior).
    VaultStore delegates all reads via __getattr__ to its MemoryStore index,
    so it is a drop-in replacement anywhere MemoryStore is expected.
    """
    global _store, _store_db_path
    if _store is None:
        db_path: Path = _resolve_server_db()
        _store_db_path = db_path
        _refresh_store_ownership_warning(db_path)
        from agentmemory.config import get_str_setting

        vault_str: str = get_str_setting("obsidian", "vault_path")
        if vault_str:
            vault_path: Path = Path(vault_str)
            if vault_path.exists():
                from agentmemory.vault_store import VaultStore

                vs: VaultStore = VaultStore(vault_path, db_path)
                _store = vs  # type: ignore[assignment]
                _write_store_owner_marker(db_path)
                return vs  # type: ignore[return-value]
        _store = MemoryStore(db_path)
        _write_store_owner_marker(db_path)
    return _store


def _resolve_project_db(project_path: str) -> Path | None:
    """Resolve the DB path for an arbitrary project directory.

    Returns the memory.db path if the project has been onboarded,
    or None if no database exists for that project.
    """
    import hashlib

    abs_path: str = str(Path(project_path).expanduser().resolve())
    path_hash: str = hashlib.sha256(abs_path.encode()).hexdigest()[:12]
    db_path: Path = Path.home() / ".agentmemory" / "projects" / path_hash / "memory.db"
    if db_path.exists():
        return db_path
    return None


_FOREIGN_ID_ERROR: str = (
    "This belief ID is from a cross-project search (contains ':'). "
    "Mutation operations (feedback, lock, delete) are not allowed on "
    "foreign project beliefs to prevent feedback loop interference."
)


def _is_foreign_id(belief_id: str) -> bool:
    """Return True if belief_id was prefixed by cross-project search."""
    return ":" in belief_id


def _set_store(store: MemoryStore) -> None:  # pyright: ignore[reportUnusedFunction]
    """Override the module-level store. Used by tests."""
    global _store, _session_id, _signal_buffer, _store_db_path, _store_ownership_warning
    _store = store
    _session_id = None
    _retrieval_buffer.clear()
    _signal_buffer = []
    _explicit_feedback_ids.clear()
    _store_db_path = None
    _store_ownership_warning = None


def _emit_telemetry(store: MemoryStore, session_id: str) -> None:
    """Write a telemetry snapshot for a completed session (if enabled)."""
    try:
        from agentmemory.config import get_bool_setting

        if not get_bool_setting("telemetry", "enabled"):
            return
        from agentmemory.telemetry import collect_snapshot, write_snapshot

        snapshot = collect_snapshot(store, session_id)
        write_snapshot(snapshot)
    except Exception:
        pass  # telemetry must never break the session


def _resolve_stale_pending_feedback(store: MemoryStore, session_id: str) -> int:
    """Resolve pending feedback from prior sessions that were never processed.

    When the MCP server is killed (SIGKILL, crash, or unhandled termination),
    retrieved beliefs stored in pending_feedback never get scored. This runs
    at session start and marks all stale entries as "ignored" -- the beliefs
    were retrieved but never confirmed as used.
    """
    pending: list[dict[str, str]] = store.get_pending_feedback()
    if not pending:
        return 0

    count: int = 0
    for entry in pending:
        belief_id: str = entry["belief_id"]
        prev_session: str = entry.get("session_id", "")
        # Only resolve entries from prior sessions
        if prev_session == session_id:
            continue
        # GH-47/GH-40: belief may have been deleted since retrieval.
        # Skip orphaned entries to avoid FK constraint failure on tests table.
        if store.get_belief(belief_id) is None:
            count += 1
            continue
        store.record_test_result(
            belief_id=belief_id,
            session_id=prev_session or session_id,
            outcome=OUTCOME_IGNORED,
            detection_layer=LAYER_IMPLICIT,
            outcome_detail="stale: pending from prior session, never matched",
        )
        count += 1

    if count > 0:
        store.clear_pending_feedback()
    return count


def _ensure_session() -> str:
    """Return the current session ID, creating a new session if needed."""
    global _session_id
    if _session_id is None:
        store: MemoryStore = _get_store()
        # Complete previous session and emit telemetry if one exists
        incomplete: list[Session] = store.find_incomplete_sessions()
        for prev in incomplete:
            store.complete_session(prev.id)
            _emit_telemetry(store, prev.id)
        session: Session = store.create_session()
        _session_id = session.id
        # Resolve stale pending feedback from prior sessions
        resolved: int = _resolve_stale_pending_feedback(store, _session_id)
        if resolved > 0:
            store.increment_session_metrics(_session_id, feedback_given=resolved)
    return _session_id


# ---------------------------------------------------------------------------
# FastMCP server
# ---------------------------------------------------------------------------

mcp: FastMCP = FastMCP(name="agentmemory")


def _format_belief(belief: Belief, score: float | None = None) -> str:
    """Format a single belief for display."""
    score_part: str = f", score: {score:.3f}" if score is not None else ""
    return (
        f"[{belief.confidence:.0%}] {belief.content} "
        f"(ID: {belief.id}, type: {belief.belief_type}{score_part})"
    )


def _truncate_text(text: str, max_len: int) -> str:
    """Truncate text to max_len with ellipsis."""
    if len(text) <= max_len:
        return text
    if max_len <= 3:
        return text[:max_len]
    return text[: max_len - 3] + "..."


def _cap_output(text: str, max_chars: int) -> str:
    """Cap output text to max_chars with truncation marker."""
    if max_chars <= 0:
        return ""
    if len(text) <= max_chars:
        return text
    marker: str = "\n...[truncated]"
    if max_chars <= len(marker):
        return marker[:max_chars]
    return text[: max_chars - len(marker)] + marker


def _budget_exhaustion_message(
    store: MemoryStore,
    query: str,
    budget: int,
    *,
    project_path: str = "",
) -> str | None:
    """Explain when raw matches exist but none fit within the token budget."""
    raw_matches: list[Belief] = store.search(
        query,
        top_k=5,
        record_last_retrieved=False,
    )
    if not raw_matches:
        return None

    min_tokens: int = min(estimate_tokens(compress_belief(b)) for b in raw_matches)
    location: str = f" in {project_path}" if project_path else ""
    return (
        f"No beliefs fit within the current token budget{location}. "
        f"Raw search found {len(raw_matches)} matching candidate(s), but the "
        f"smallest compressed result is ~{min_tokens} tokens and your budget "
        f"is {budget}. Retry with a larger budget (>= {min_tokens}, typically "
        "500-2000 for compound queries)."
    )


def _search_bookkeeping_warning(store: MemoryStore) -> str | None:
    """Return the current ownership warning, refreshing from disk if possible."""
    db_path: Path | None = _store_db_path
    if db_path is None:
        raw_db_path: object = getattr(store, "_db_path", None)
        if isinstance(raw_db_path, Path):
            db_path = raw_db_path
    if db_path is None:
        return _store_ownership_warning
    return _refresh_store_ownership_warning(db_path)


_THEME_STOPWORDS: frozenset[str] = frozenset(
    {
        "the",
        "and",
        "for",
        "with",
        "from",
        "that",
        "this",
        "have",
        "has",
        "will",
        "into",
        "your",
        "project",
        "code",
        "using",
        "used",
        "user",
        "agent",
        "should",
        "would",
        "could",
        "about",
        "after",
        "before",
        "there",
        "their",
        "them",
        "they",
        "where",
        "when",
        "what",
        "which",
        "also",
        "each",
        "than",
        "then",
    }
)


def _extract_theme_terms(text: str) -> set[str]:
    """Extract candidate topic terms from a belief sentence."""
    terms: set[str] = set()
    for token in re.findall(r"[a-zA-Z][a-zA-Z0-9_-]{3,}", text.lower()):
        if token in _THEME_STOPWORDS:
            continue
        terms.add(token)
    return terms


def _build_onboard_themed_summary(
    belief_contents: list[str], *, max_themes: int = 6, examples_per_theme: int = 3
) -> list[str]:
    """Build compact post-onboard theme groups for first-run UX."""
    if not belief_contents:
        return []

    terms_by_belief: list[set[str]] = [
        _extract_theme_terms(content) for content in belief_contents
    ]
    term_counts: Counter[str] = Counter()
    for terms in terms_by_belief:
        term_counts.update(terms)

    candidate_terms: list[str] = [
        term for term, count in term_counts.most_common(max_themes * 8) if count >= 2
    ]
    if not candidate_terms:
        return []

    lines: list[str] = ["Here's what I learned about your project:"]
    used_belief_indexes: set[int] = set()
    themes_added: int = 0

    for term in candidate_terms:
        matches: list[int] = [
            idx
            for idx, terms in enumerate(terms_by_belief)
            if term in terms and idx not in used_belief_indexes
        ]
        if len(matches) < 2:
            continue
        picks: list[int] = matches[:examples_per_theme]
        lines.append(f"- {term.replace('_', ' ')}:")
        for idx in picks:
            lines.append(f"  - {_truncate_text(belief_contents[idx], 140)}")
            used_belief_indexes.add(idx)
        themes_added += 1
        if themes_added >= max_themes:
            break

    if themes_added == 0:
        return []
    return lines


@mcp.tool
def search(
    query: str,
    budget: int = 2000,
    temporal_sort: bool = False,
    project_path: str = "",
) -> str:
    """Search for beliefs relevant to the query.

    Returns formatted text of matching beliefs with confidence scores.
    Uses the retrieval pipeline (FTS5 + scoring + packing).

    If temporal_sort is True, results are re-sorted newest-first after
    relevance-based selection. Useful for state-tracking queries where
    the most recent information should appear first.

    If project_path is provided, searches that project's memory database
    instead of the current session's database. Useful when working on a
    task in project A but needing context from project B. The target
    project must have been previously onboarded. Read-only: no feedback
    or session metrics are recorded for cross-project queries.
    """
    timeout_sec: float = _search_timeout_seconds()
    try:
        with _search_timeout_guard(timeout_sec):
            # Cross-project search: open a temporary read-only store
            if project_path:
                target_db: Path | None = _resolve_project_db(project_path)
                if target_db is None:
                    return (
                        f"No memory database found for project: {project_path}. "
                        f"The project must be onboarded first (use onboard())."
                    )
                cross_store: MemoryStore = MemoryStore(target_db, readonly=True)
                try:
                    result: RetrievalResult = retrieve(
                        cross_store,
                        query,
                        budget=budget,
                        temporal_sort=temporal_sort,
                        adaptive_expansion=True,
                    )
                    budget_msg: str | None = None
                    if not result.beliefs:
                        budget_msg = _budget_exhaustion_message(
                            cross_store,
                            query,
                            budget,
                            project_path=project_path,
                        )
                finally:
                    cross_store.close()
                if not result.beliefs:
                    if budget_msg is not None:
                        return budget_msg
                    return f"No beliefs found in {project_path} matching your query."
                # Prefix belief IDs with project hash so they are visually foreign
                # and rejected by mutation tools (feedback, lock, delete).
                project_hash: str = target_db.parent.name
                lines: list[str] = [
                    f"Found {len(result.beliefs)} belief(s) from {project_path} "
                    f"({result.total_tokens} tokens, {result.budget_remaining} remaining):",
                    "NOTE: These are read-only cross-project results. "
                    "Do not pass these IDs to feedback(), lock(), or delete().",
                ]
                for belief in result.beliefs:
                    score: float | None = result.scores.get(belief.id)
                    foreign_id: str = f"{project_hash}:{belief.id}"
                    score_part: str = (
                        f", score: {score:.3f}" if score is not None else ""
                    )
                    lines.append(
                        f"[{belief.confidence:.0%}] {belief.content} "
                        f"(ID: {foreign_id}, type: {belief.belief_type}{score_part})"
                    )
                return "\n".join(lines)

            store: MemoryStore = _get_store()
            result = retrieve(
                store,
                query,
                budget=budget,
                temporal_sort=temporal_sort,
                adaptive_expansion=True,
            )

            # Layer 0: check for beliefs with matching activation_condition.
            # These are prospective beliefs that fire on specific prompt patterns.
            retrieved_ids: set[str] = {b.id for b in result.beliefs}
            analysis: StructuralAnalysis = analyze_prompt_structure(query)
            prompt_words_set: set[str] = {
                w.lower() for w in re.findall(r"\b\w+\b", query.lower())
            }
            activated_rows = evaluate_activation_conditions(
                store.connection,
                analysis,
                prompt_words_set,
            )
            for row in activated_rows:
                if row["id"] not in retrieved_ids:
                    activated_belief: Belief = row_to_belief(row)
                    result.beliefs.insert(0, activated_belief)
                    retrieved_ids.add(row["id"])

            if not result.beliefs:
                budget_msg = _budget_exhaustion_message(store, query, budget)
                if budget_msg is not None:
                    return budget_msg
                return (
                    "No beliefs found matching your query. "
                    "This may be a knowledge gap. Consider asking the user for context, "
                    "or use observe() to record new information."
                )

            lines: list[str] = [
                f"Found {len(result.beliefs)} belief(s) ({result.total_tokens} tokens, "
                f"{result.budget_remaining} remaining):"
            ]
            for belief in result.beliefs:
                score: float | None = result.scores.get(belief.id)
                lines.append(_format_belief(belief, score))

            # Append contradiction warnings if any (REQ-002)
            if result.contradiction_warnings:
                lines.append("")
                for warning in result.contradiction_warnings:
                    lines.append(f"WARNING: {warning}")

            response: str = "\n".join(lines)

            # Bookkeeping is best-effort and must not block the answer.
            if _search_bookkeeping_warning(store) is not None:
                return response

            try:
                session_id = _ensure_session()
                _signal_buffer.append(query)
                _process_auto_feedback(session_id)
                _prune_buffers()
                store.increment_session_metrics(
                    session_id,
                    retrieval_tokens=result.total_tokens,
                    searches_performed=1,
                )

                returned_ids: list[str] = [b.id for b in result.beliefs]
                if returned_ids:
                    now: str = datetime.now(timezone.utc).isoformat()
                    ph: str = ",".join("?" for _ in returned_ids)
                    store.connection.execute(
                        f"UPDATE beliefs SET last_retrieved_at = ? WHERE id IN ({ph})",
                        [now, *returned_ids],
                    )
                    store.connection.commit()

                ts: str = datetime.now(timezone.utc).isoformat()
                if session_id not in _retrieval_buffer:
                    _retrieval_buffer[session_id] = []
                for belief in result.beliefs:
                    _retrieval_buffer[session_id].append((belief.id, ts))
                    store.insert_pending_feedback(
                        belief_id=belief.id,
                        belief_content=belief.content,
                        session_id=session_id,
                    )
            except sqlite3.OperationalError:
                pass

            return response
    except _SearchTimeoutError:
        return (
            f"Search timed out after {timeout_sec:.1f}s. "
            "This may indicate a transient lock or cold-start hang. "
            "Retry with a smaller budget, or retry once."
        )


@mcp.tool
def remember(text: str) -> str:
    """Create a high-confidence belief from a user statement.

    Sets source_type='user_stated', alpha=9.0, beta_param=0.5, locked=False.
    The belief is NOT locked until the user explicitly confirms via lock().
    Returns belief ID and prompts for user confirmation before locking.
    """
    err: str | None = _check_length(text)
    if err is not None:
        return err
    _signal_buffer.append(text)
    store: MemoryStore = _get_store()
    session_id: str = _ensure_session()
    belief: Belief = store.insert_belief(
        content=text,
        belief_type=BELIEF_FACTUAL,
        source_type=BSRC_USER_STATED,
        alpha=9.0,
        beta_param=0.5,
        locked=False,
        classified_by="user",
        session_id=session_id,
    )
    detect_relationships(store, belief)
    store.checkpoint(session_id, "remember", belief.content, [belief.id])
    store.increment_session_metrics(session_id, beliefs_created=1)
    return (
        f"Remembered (ID: {belief.id}): {belief.content} "
        f"[confidence: {belief.confidence:.0%}, locked: False] "
        f"Ask the user: 'Lock this as a permanent belief? "
        f"lock({belief.id})'"
    )


@mcp.tool
def correct(text: str, replaces: str | None = None) -> str:
    """Record a user correction as a high-confidence belief.

    Creates a high-confidence belief with source_type='user_corrected'.
    The belief is NOT locked until the user explicitly confirms via lock().
    If replaces is provided (a search query), finds the best matching
    existing belief and supersedes it.
    """
    err: str | None = _check_length(text)
    if err is not None:
        return err
    _signal_buffer.append(text)
    store: MemoryStore = _get_store()
    session_id: str = _ensure_session()
    belief: Belief = store.insert_belief(
        content=text,
        belief_type=BELIEF_CORRECTION,
        source_type=BSRC_USER_CORRECTED,
        alpha=9.0,
        beta_param=0.5,
        locked=False,
        classified_by="user",
        session_id=session_id,
    )
    detect_relationships(store, belief)

    superseded_msg: str = ""
    if replaces is not None and replaces.strip():
        candidates: list[Belief] = store.search(replaces.strip(), top_k=5)
        for candidate in candidates:
            if candidate.id == belief.id:
                continue
            if candidate.valid_to is not None:
                continue
            if candidate.superseded_by is not None:
                continue
            store.supersede_belief(
                old_id=candidate.id,
                new_id=belief.id,
                reason="user_corrected",
            )
            superseded_msg = f" Superseded belief ID: {candidate.id}."
            break

    store.checkpoint(session_id, "correct", belief.content, [belief.id])
    store.increment_session_metrics(
        session_id,
        beliefs_created=1,
        corrections_detected=1,
    )
    return (
        f"Correction recorded (ID: {belief.id}): {belief.content} "
        f"[confidence: {belief.confidence:.0%}, locked: False]."
        f"{superseded_msg} "
        f"Ask the user: 'Lock this as a permanent correction? "
        f"lock({belief.id})'"
    )


@mcp.tool
def lock(belief_id: str) -> str:
    """Lock a belief as a permanent constraint.

    Only call this AFTER the user has explicitly confirmed they want the
    belief locked. Locked beliefs persist across all sessions, cannot have
    their confidence reduced, and are injected into every session context.

    Returns confirmation or error if belief not found.
    """
    if _is_foreign_id(belief_id):
        return _FOREIGN_ID_ERROR
    store: MemoryStore = _get_store()
    session_id: str = _ensure_session()
    belief: Belief | None = store.get_belief(belief_id)
    if belief is None:
        return f"Error: no belief found with ID {belief_id}"
    if belief.locked:
        return (
            f"Already locked (ID: {belief.id}): {belief.content} "
            f"[confidence: {belief.confidence:.0%}]"
        )
    store.lock_belief(belief_id)
    store.checkpoint(session_id, "lock", belief.content, [belief.id])
    return (
        f"Locked (ID: {belief.id}): {belief.content} "
        f"[confidence: {belief.confidence:.0%}, locked: True]"
    )


@mcp.tool
def observe(text: str, source: str = "user") -> str:
    """Record a raw observation without creating a belief.

    Returns the observation ID.
    """
    err: str | None = _check_length(text)
    if err is not None:
        return err
    _signal_buffer.append(text)
    store: MemoryStore = _get_store()
    session_id: str = _ensure_session()
    obs: Observation = store.insert_observation(
        content=text,
        observation_type=OBS_TYPE_USER_STATEMENT,
        source_type=source,
        source_id=source,
        session_id=session_id,
    )
    return f"Observation recorded (ID: {obs.id}): {obs.content}"


@mcp.tool
def status() -> str:
    """Return memory system status.

    Reports inventory (counts by type/source/locked), retrieval pipeline
    status, activity metrics, and actionable maintenance items.
    """
    store: MemoryStore = _get_store()
    report: dict[str, object] = store.get_status_report()
    inv: dict[str, object] = report["inventory"]  # type: ignore[assignment]
    ret: dict[str, object] = report["retrieval"]  # type: ignore[assignment]
    act: dict[str, object] = report["activity"]  # type: ignore[assignment]
    maint: dict[str, object] = report["maintenance"]  # type: ignore[assignment]

    lines: list[str] = []

    # --- Inventory ---
    lines.append("Inventory:")
    lines.append(f"  {inv['active']} active beliefs ({inv['superseded']} superseded)")
    by_type: dict[str, int] = inv["by_type"]  # type: ignore[assignment]
    if by_type:
        type_parts: list[str] = [f"{c} {t}" for t, c in by_type.items()]
        lines.append(f"  By type: {', '.join(type_parts)}")
    by_source: dict[str, int] = inv["by_source"]  # type: ignore[assignment]
    if by_source:
        active_total: int = int(inv["active"])  # type: ignore[arg-type]
        src_parts: list[str] = []
        for src, cnt in by_source.items():
            pct: float = cnt / active_total * 100 if active_total > 0 else 0.0
            src_parts.append(f"{cnt} {src} ({pct:.0f}%)")
        lines.append(f"  By source: {', '.join(src_parts)}")
    locked_by_type: dict[str, int] = inv["locked_by_type"]  # type: ignore[assignment]
    if locked_by_type:
        lock_parts: list[str] = [f"{c} {t}" for t, c in locked_by_type.items()]
        lines.append(f"  Locked: {inv['locked']} ({', '.join(lock_parts)})")
    elif int(inv["locked"]) > 0:  # type: ignore[arg-type]
        lines.append(f"  Locked: {inv['locked']}")

    # --- Retrieval ---
    lines.append("Retrieval:")
    total_active: int = int(ret["total_active"])  # type: ignore[arg-type]
    retrieved: int = int(ret["retrieved_once"])  # type: ignore[arg-type]
    ret_pct: float = retrieved / total_active * 100 if total_active > 0 else 0.0
    lines.append(
        f"  {ret_pct:.0f}% retrieved at least once ({retrieved}/{total_active})"
    )
    features: list[str] = ret["scoring_features"]  # type: ignore[assignment]
    lines.append(f"  Scoring: {' + '.join(features)}")
    pending: int = int(ret["pending_feedback"])  # type: ignore[arg-type]
    if pending > 0:
        lines.append(f"  Pending feedback: {pending}")

    # --- Current session ---
    if _session_id is not None:
        session: Session | None = store.get_session(_session_id)
        if session is not None:
            lines.append("Session:")
            lines.append(
                f"  beliefs: {session.beliefs_created}, "
                f"corrections: {session.corrections_detected}, "
                f"searches: {session.searches_performed}"
            )

    # --- Activity ---
    lines.append("Activity:")
    lines.append(f"  {act['sessions']} sessions, {act['observations']} observations")
    age_dist: dict[str, int] = act["age_distribution"]  # type: ignore[assignment]
    if age_dist:
        age_parts: list[str] = [f"{c} {bucket}" for bucket, c in age_dist.items()]
        lines.append(f"  Age: {', '.join(age_parts)}")
    last_velocity: Session | None = store.get_last_completed_session()
    if last_velocity is not None and last_velocity.velocity_tier is not None:
        lines.append(
            f"  Last session: {last_velocity.velocity_tier} "
            f"({last_velocity.velocity_items_per_hour:.1f} items/hr)"
        )

    owner_warning: str | None = _search_bookkeeping_warning(store)
    if owner_warning is not None:
        lines.append("Ownership:")
        lines.append(f"  {owner_warning}")

    # --- Rigor (REQ-026: calibrated status reporting) ---
    rigor_dist: dict[str, int] = store.get_rigor_distribution()
    if rigor_dist:
        active_total_r: int = sum(rigor_dist.values())
        lines.append("Rigor:")
        rigor_parts: list[str] = [
            f"{cnt} {tier} ({cnt / active_total_r * 100:.0f}%)"
            for tier, cnt in rigor_dist.items()
        ]
        lines.append(f"  {', '.join(rigor_parts)}")
        # Confidence caveat when most findings are below "validated" tier
        validated_count: int = rigor_dist.get("validated", 0)
        empirical_count: int = rigor_dist.get("empirically_tested", 0)
        strong_count: int = validated_count + empirical_count
        strong_pct: float = (
            strong_count / active_total_r * 100 if active_total_r > 0 else 0.0
        )
        if strong_pct < 20.0:
            lines.append(
                f"  Caveat: {strong_pct:.0f}% of beliefs are empirically tested or validated. "
                "Most findings are hypothesis-tier; treat with appropriate skepticism."
            )
        elif strong_pct < 50.0:
            lines.append(
                f"  Note: {strong_pct:.0f}% of beliefs are empirically tested or validated."
            )

    # --- Maintenance (actionable) ---
    stale: int = int(maint["stale_count"])  # type: ignore[arg-type]
    orphan: int = int(maint["orphan_count"])  # type: ignore[arg-type]
    credal: int = int(maint["credal_gap_count"])  # type: ignore[arg-type]
    if stale > 0 or orphan > 0 or credal > 0:
        lines.append("Maintenance:")
        if stale > 0:
            lines.append(f"  Stale (>30d unretrieved): {stale}")
        if orphan > 0:
            lines.append(f"  Orphans (no edges): {orphan} ({maint['orphan_pct']}%)")
        if credal > 0:
            lines.append(
                f"  Never updated (at type prior): {credal} ({maint['credal_gap_pct']}%)"
            )

    return "\n".join(lines)


@mcp.tool
def get_locked(max_chars: int = MAX_LOCKED_OUTPUT_CHARS) -> str:
    """Return all locked beliefs formatted for context injection.

    This is what the SessionStart hook calls to load persistent beliefs
    into the agent's active context.
    """
    global _locked_access_count
    _locked_access_count += 1

    store: MemoryStore = _get_store()
    beliefs: list[Belief] = store.get_locked_beliefs()

    if not beliefs:
        return "No locked beliefs found."

    effective_max: int = min(max_chars, MAX_LOCKED_OUTPUT_CHARS)
    lines: list[str] = [f"Locked beliefs ({len(beliefs)}):"]
    for belief in beliefs:
        lines.append(_format_belief(belief))
    return _cap_output("\n".join(lines), max_chars=effective_max)


@mcp.tool
def resume_state(max_chars: int = MAX_RESUME_OUTPUT_CHARS) -> str:
    """Return a bounded continuity artifact for resume-after-clear flows.

    This compact payload is designed for SessionStart/recovery paths where
    context budget must be tightly bounded.
    """
    store: MemoryStore = _get_store()
    lines: list[str] = ["RESUME STATE (bounded):"]

    # Highest priority: unresolved forward directives.
    todo_rows: list[sqlite3.Row] = store.query(
        """SELECT content FROM beliefs
           WHERE valid_to IS NULL
             AND belief_type = 'todo'
             AND source_type = 'user_stated'
             AND temporal_direction = 'forward'
           ORDER BY created_at DESC
           LIMIT 5"""
    )
    if todo_rows:
        lines.append("UNRESOLVED DIRECTIVES:")
        for row in todo_rows:
            content: str = str(row["content"] or "")
            lines.append(f"- {_truncate_text(content, 180)}")

    # Next: active constraints (locked beliefs), capped count and per-item length.
    locked: list[Belief] = store.get_locked_beliefs()[:8]
    if locked:
        lines.append("ACTIVE CONSTRAINTS:")
        for belief in locked:
            lines.append(f"- {_truncate_text(belief.content, 180)}")

    # Continuity anchors from recent high-signal beliefs.
    anchor_rows: list[sqlite3.Row] = store.query(
        """SELECT content, belief_type
           FROM beliefs
           WHERE valid_to IS NULL
             AND superseded_by IS NULL
             AND belief_type IN ('requirement', 'correction', 'preference', 'factual')
           ORDER BY created_at DESC
           LIMIT 8"""
    )
    if anchor_rows:
        lines.append("RECENT ANCHORS:")
        for row in anchor_rows:
            btype: str = str(row["belief_type"] or "factual")
            content = _truncate_text(str(row["content"] or ""), 180)
            lines.append(f"- [{btype}] {content}")

    last_session: Session | None = store.get_last_completed_session()
    if last_session is not None:
        session_parts: list[str] = []
        if last_session.velocity_tier:
            session_parts.append(f"last velocity={last_session.velocity_tier}")
        if session_parts:
            lines.append("SESSION SNAPSHOT:")
            lines.append("- " + ", ".join(session_parts))

    effective_max: int = min(max_chars, MAX_RESUME_OUTPUT_CHARS)
    return _cap_output("\n".join(lines), max_chars=effective_max)


@mcp.tool
def onboard(project_path: str, use_llm: bool = False) -> str:
    """Onboard a project: scan, classify, create beliefs. End-to-end.

    One command does everything:
    1. Scans the project directory for git history, code, docs, directives
    2. Creates observations from extracted content
    3. Stores structural edges for the graph
    4. Classifies sentences (LLM if use_llm=True, offline otherwise)
    5. Creates beliefs from classified sentences
    6. Returns a summary

    No LLM orchestration required. The agent calls onboard() and gets
    back a completion summary.

    Args:
        project_path: Directory to scan.
        use_llm: If True, uses Haiku LLM for 99% classification accuracy
                 (~$0.005/session). Falls back to offline if API unavailable.
                 If False (default), uses offline classification (36% accuracy).
    """
    path: Path = Path(project_path).expanduser().resolve()
    if not path.is_dir():
        return f"Not a directory: {path}"

    # Detect cross-project onboard for provenance tagging
    current_project: Path = Path.cwd().resolve()
    is_foreign: bool = path != current_project
    _source_project_tag: str = str(path) if is_foreign else ""

    # Check for incremental onboarding: use last onboard commit if available
    store_pre: MemoryStore = _get_store()
    last_run: dict[str, str] | None = store_pre.get_last_onboarding(str(path))
    since_commit: str | None = None
    if last_run is not None and last_run.get("commit_hash"):
        since_commit = last_run["commit_hash"]

    # Step 1: Scan the project
    scan: ScanResult = scan_project(path, since_commit=since_commit)

    # Step 2: Extract observations and collect sentences
    store: MemoryStore = _get_store()
    observations_created: int = 0
    raw_sentences: list[tuple[str, str]] = []
    sentence_metadata: list[dict[str, str]] = []

    for node in scan.nodes:
        if node.node_type == "file":
            continue

        source: str = "document"
        if node.node_type == "commit_belief":
            source = "git"
        elif node.node_type == "behavioral_belief":
            source = "directive"
        elif node.node_type == "callable":
            source = "code"

        extracted: ExtractedTurn = extract_turn(
            store=store,
            text=node.content,
            source=source,
            session_id=None,
            created_at=node.date,
            source_path=node.file or "",
        )
        observations_created += 1

        for text, src in extracted.sentences:
            raw_sentences.append((text, src))
            sentence_metadata.append(
                {
                    "observation_id": extracted.observation.id,
                    "created_at": node.date or "",
                    "source_path": node.file or "",
                }
            )

    # Step 3: Store structural edges
    edge_batch: list[tuple[str, str, str, float, str]] = [
        (edge.src, edge.tgt, edge.edge_type, edge.weight, "scanner")
        for edge in scan.edges
    ]
    store.batch_insert_graph_edges(edge_batch)

    # Step 4: Classify sentences offline (zero-LLM)
    # Step 4: Classify sentences
    if use_llm:
        classified: list[ClassifiedSentence] = classify_with_llm(
            raw_sentences,
            for_onboard=True,
        )
        classifier_used: str = "llm (Haiku)"
    else:
        classified: list[ClassifiedSentence] = classify_sentences_offline(raw_sentences)  # type: ignore[no-redef]
        classifier_used: str = "offline"

    # Step 5: Create beliefs from classified sentences
    beliefs_created: int = 0
    beliefs_filtered: int = 0
    type_counts: dict[str, int] = {}
    created_belief_contents: list[str] = []

    for i, cs in enumerate(classified):
        if not cs.persist:
            beliefs_filtered += 1
            continue

        belief_source: str
        if cs.sentence_type == "CORRECTION":
            belief_source = "user_corrected"
        elif cs.source == "user":
            belief_source = "user_stated"
        else:
            belief_source = "agent_inferred"

        _type_to_belief: dict[str, str] = {
            "REQUIREMENT": "requirement",
            "CORRECTION": "correction",
            "PREFERENCE": "preference",
            "FACT": "factual",
            "ASSUMPTION": "factual",
            "DECISION": "factual",
            "ANALYSIS": "factual",
            "TODO": "todo",
        }
        belief_type: str = _type_to_belief.get(cs.sentence_type, "factual")

        meta: dict[str, str] = (
            sentence_metadata[i] if i < len(sentence_metadata) else {}
        )

        store.insert_belief(
            content=cs.text,
            belief_type=belief_type,
            source_type=belief_source,
            alpha=cs.alpha,
            beta_param=cs.beta_param,
            locked=False,
            observation_id=meta.get("observation_id"),
            created_at=meta.get("created_at") or None,
            classified_by="offline",
            data_source=meta.get("source_path", ""),
        )
        beliefs_created += 1
        type_counts[belief_type] = type_counts.get(belief_type, 0) + 1
        created_belief_contents.append(cs.text)

    # Step 6: Record onboarding provenance
    import subprocess

    commit_hash: str | None = None
    try:
        commit_hash = (
            subprocess.check_output(
                ["git", "rev-parse", "HEAD"],
                cwd=str(path),
                stderr=subprocess.DEVNULL,
            )
            .decode()
            .strip()
        )
    except Exception:
        pass
    store.record_onboarding_run(
        project_path=str(path),
        commit_hash=commit_hash,
        nodes_extracted=len(scan.nodes),
        edges_extracted=len(scan.edges),
        beliefs_created=beliefs_created,
        observations_created=observations_created,
    )

    # Build summary
    node_types: dict[str, int] = {}
    for n in scan.nodes:
        node_types[n.node_type] = node_types.get(n.node_type, 0) + 1

    edge_type_counts: dict[str, int] = {}
    for e in scan.edges:
        edge_type_counts[e.edge_type] = edge_type_counts.get(e.edge_type, 0) + 1

    mode: str = f"incremental (since {since_commit[:12]})" if since_commit else "full"
    lines: list[str] = [
        f"Onboarded project: {scan.manifest.name} [{mode}]",
        f"  Signals: git={scan.manifest.has_git}, "
        f"docs={scan.manifest.doc_count}, "
        f"languages={scan.manifest.languages}",
        f"  Nodes extracted: {len(scan.nodes)}",
    ]
    if len(scan.nodes) > 0:
        density: float = beliefs_created / len(scan.nodes)
        lines.append(
            "  Volume context: "
            f"{beliefs_created} beliefs from {len(scan.nodes)} extracted nodes "
            f"({density:.1f} beliefs/node)"
        )
        if beliefs_created >= 500:
            lines.append(
                "  Note: high belief counts are normal for larger codebases and rich docs."
            )
    for ntype, count in sorted(node_types.items()):
        lines.append(f"    {ntype}: {count}")
    lines.append(f"  Edges extracted: {len(scan.edges)}")
    for etype, count in sorted(edge_type_counts.items()):
        lines.append(f"    {etype}: {count}")
    lines.append(f"  Observations: {observations_created}")
    lines.append(f"  Classifier: {classifier_used}")
    lines.append(f"  Sentences classified: {len(classified)}")
    lines.append(f"  Beliefs created: {beliefs_created}")
    for bt, bc in sorted(type_counts.items()):
        lines.append(f"    {bt}: {bc}")
    lines.append(f"  Filtered (ephemeral): {beliefs_filtered}")

    timing_parts: list[str] = [f"{k}={v:.2f}s" for k, v in scan.timings.items()]
    lines.append(f"  Timing: {', '.join(timing_parts)}")
    if commit_hash:
        lines.append(f"  Git HEAD: {commit_hash[:12]}")
    if scan.manifest.has_git:
        lines.append(
            "  Git temporal context: commit history is indexed for evolution tracking."
        )
    if not use_llm:
        lines.append(
            "  Offline quality note: classifier may create fragment beliefs; "
            "re-run with --llm for higher-quality sentence classification."
        )

    themed_summary: list[str] = _build_onboard_themed_summary(
        created_belief_contents,
        max_themes=6,
        examples_per_theme=3,
    )
    if themed_summary:
        lines.append("")
        lines.extend(themed_summary)

    return "\n".join(lines)


@mcp.tool
def create_beliefs(classified_json: str) -> str:
    """Create beliefs from LLM-classified sentences.

    Accepts a JSON string: [{"text": "...", "source": "user", "observation_id": "...",
    "type": "REQUIREMENT", "persist": "PERSIST", "created_at": "", "is_correction": "False",
    "full_text": "..."}]

    This is the second phase of the onboard pipeline:
    1. onboard() extracts observations and returns sentences
    2. The calling agent classifies via Haiku subagents
    3. create_beliefs() stores the results with correct types and priors

    Each item must have at minimum: text, source, observation_id, type, persist.
    Optional: author (USER/AGENT/UNKNOWN) -- agent-authored content gets lower priors.
    CORRECTION type is remapped to FACT (corrections are a live-conversation concept).
    """
    import json as _json

    err: str | None = _check_length(classified_json, "classified_json")
    if err is not None:
        return err
    store: MemoryStore = _get_store()
    try:
        items: list[dict[str, str]] = _json.loads(classified_json)
    except (ValueError, _json.JSONDecodeError) as exc:
        return f"Error: invalid JSON in classified_json: {exc}"
    if len(items) > MAX_BULK_ITEMS:
        return f"Error: too many items ({len(items)}). Maximum is {MAX_BULK_ITEMS}."

    total_created: int = 0
    total_skipped: int = 0

    # Group by observation_id for efficient processing
    by_obs: dict[str, list[dict[str, str]]] = {}
    for item in items:
        obs_id: str = item.get("observation_id", "")
        if obs_id not in by_obs:
            by_obs[obs_id] = []
        by_obs[obs_id].append(item)

    for obs_id, obs_items in by_obs.items():
        obs = store.get_observation(obs_id) if obs_id else None
        if obs is None:
            total_skipped += len(obs_items)
            continue

        classified: list[ClassifiedSentence] = []
        source: str = obs_items[0].get("source", "document")
        full_text: str = obs_items[0].get("full_text", "")
        created_at: str | None = obs_items[0].get("created_at") or None

        for item in obs_items:
            sentence_type: str = item.get("type", "FACT").upper()
            persist_label: str = item.get("persist", "PERSIST").upper()
            author: str = item.get("author", "UNKNOWN").upper()

            # Remap CORRECTION to FACT for onboard path
            if sentence_type == "CORRECTION":
                sentence_type = "FACT"

            _source_for_prior: str = "assistant" if author == "AGENT" else "user"
            prior: tuple[float, float] | None = get_source_adjusted_prior(
                sentence_type,
                _source_for_prior,
            )
            should_persist: bool = persist_label == "PERSIST" and prior is not None

            alpha: float = 0.5
            beta_val: float = 0.5
            if prior is not None:
                alpha, beta_val = prior

            classified.append(
                ClassifiedSentence(
                    text=item.get("text", ""),
                    source=item.get("source", "document"),
                    persist=should_persist,
                    sentence_type=sentence_type,
                    alpha=alpha,
                    beta_param=beta_val,
                    author=author,
                )
            )

        # Thread cross-project provenance if present
        source_project: str = obs_items[0].get("source_project", "")
        provenance: str = f"onboard:{source_project}" if source_project else ""

        result: IngestResult = create_beliefs_from_classified(
            store=store,
            observation=obs,
            classified=classified,
            source=source,
            full_text_is_correction=False,
            full_text=full_text,
            created_at=created_at,
            classified_by="llm",
            data_source=provenance,
            bulk=True,
        )
        total_created += result.beliefs_created

    return (
        f"Created {total_created} belief(s) from {len(items)} classified sentence(s).\n"
        f"Skipped: {total_skipped} (missing observation)"
    )


@mcp.tool
def get_unclassified(limit: int = 200) -> str:
    """Return beliefs that were classified offline and may benefit from LLM reclassification.

    Returns belief IDs, content, current type, and source for beliefs created
    by the offline classifier. These can be batched and sent to Haiku subagents
    using build_classification_prompt(), then fed back via reclassify().

    The caller (a Claude Code skill) should:
    1. Call get_unclassified() to get the batch
    2. Group sentences into batches of 20
    3. Spawn Haiku subagents with the classification prompt for each batch
    4. Call reclassify() with the results
    """
    store: MemoryStore = _get_store()
    rows: list[dict[str, str]] = store.get_reclassifiable(limit)

    if not rows:
        return "No beliefs available for reclassification."

    lines: list[str] = [
        f"Found {len(rows)} belief(s) for reclassification.",
        f"Batch size: {BATCH_SIZE} sentences per subagent.",
        "",
    ]
    for r in rows:
        lines.append(f"[{r['id']}] ({r['type']}) {r['content']}")

    return "\n".join(lines)


@mcp.tool
def reclassify(mappings: str) -> str:
    """Apply LLM classification results to existing beliefs.

    Accepts a JSON string: [{"id": "belief_id", "type": "REQUIREMENT", "persist": "PERSIST"}, ...]

    For each mapping:
    - Updates belief_type based on the LLM classification
    - Updates alpha/beta priors from TYPE_PRIORS
    - Beliefs classified as EPHEMERAL (persist=false) are soft-deleted (valid_to set)

    This is the receiving end of subagent-based classification. The calling agent
    spawns Haiku subagents to classify batches, then feeds results here.
    """
    import json as _json

    err: str | None = _check_length(mappings, "mappings")
    if err is not None:
        return err
    store: MemoryStore = _get_store()
    try:
        items: list[dict[str, str]] = _json.loads(mappings)
    except (ValueError, _json.JSONDecodeError) as exc:
        return f"Error: invalid JSON in mappings: {exc}"
    if len(items) > MAX_BULK_ITEMS:
        return f"Error: too many items ({len(items)}). Maximum is {MAX_BULK_ITEMS}."

    # Map from classification type to belief_type
    type_to_belief: dict[str, str] = {
        "REQUIREMENT": "requirement",
        "CORRECTION": "correction",
        "PREFERENCE": "preference",
        "FACT": "factual",
        "ASSUMPTION": "factual",
        "DECISION": "factual",
        "ANALYSIS": "factual",
        "TODO": "todo",
        "COORDINATION": "factual",
        "QUESTION": "factual",
        "META": "factual",
    }

    updated: int = 0
    soft_deleted: int = 0
    skipped: int = 0

    for item in items:
        belief_id: str = item.get("id", "")
        sentence_type: str = item.get("type", "FACT").upper()
        persist_label: str = item.get("persist", "PERSIST").upper()

        belief: Belief | None = store.get_belief(belief_id)
        if belief is None:
            skipped += 1
            continue

        # Skip locked beliefs
        if belief.locked:
            skipped += 1
            continue

        # Reclassified beliefs use agent-inferred source for prior adjustment
        prior: tuple[float, float] | None = get_source_adjusted_prior(
            sentence_type,
            "assistant",
        )
        should_persist: bool = persist_label == "PERSIST" and prior is not None

        if not should_persist:
            store.soft_delete_belief(belief_id)
            soft_deleted += 1
        else:
            new_type: str = type_to_belief.get(sentence_type, "factual")
            alpha: float
            beta_val: float
            assert prior is not None  # guarded by should_persist check
            alpha, beta_val = prior
            store.update_belief_classification(
                belief_id,
                new_type,
                alpha,
                beta_val,
            )
            updated += 1

    return (
        f"Reclassification complete:\n"
        f"  Updated: {updated}\n"
        f"  Soft-deleted (EPHEMERAL): {soft_deleted}\n"
        f"  Skipped (locked/missing): {skipped}"
    )


@mcp.tool
def ingest(text: str, source: str = "user") -> str:
    """Ingest a conversation turn through the full pipeline.

    Extracts sentences, detects corrections, classifies content types,
    and creates observations + beliefs with appropriate Bayesian priors.
    Corrections become locked beliefs automatically.

    Use source='user' for user messages, source='assistant' for agent messages.
    """
    err: str | None = _check_length(text)
    if err is not None:
        return err
    store: MemoryStore = _get_store()
    session_id: str = _ensure_session()
    result: IngestResult = ingest_turn(store, text, source, session_id=session_id)

    # Feed ingested text into the signal buffer, then process.
    # Processing after append ensures the ingested text (agent's response to
    # previous search results) is included in the key-term matching.
    _signal_buffer.append(text)
    auto_fb: int = _process_auto_feedback(session_id)

    store.increment_session_metrics(
        session_id,
        classification_tokens=0,
        beliefs_created=result.beliefs_created,
        corrections_detected=result.corrections_detected,
    )

    fb_msg: str = (
        f"\n  Auto-feedback: {auto_fb} belief(s) scored" if auto_fb > 0 else ""
    )
    reclass_msg: str = ""
    if result.beliefs_created > 0:
        reclass_msg = (
            f"\n  NOTE: {result.beliefs_created} belief(s) classified offline (36% accuracy). "
            f"Call get_unclassified() + reclassify() for LLM accuracy."
        )
    return (
        f"Ingested {source} turn (offline classifier):\n"
        f"  Observations: {result.observations_created}\n"
        f"  Beliefs: {result.beliefs_created}\n"
        f"  Corrections: {result.corrections_detected}\n"
        f"  Sentences: {result.sentences_extracted} extracted, "
        f"{result.sentences_persisted} persisted{fb_msg}{reclass_msg}"
    )


@mcp.tool
def timeline(
    topic: str | None = None,
    start: str | None = None,
    end: str | None = None,
    session_id: str | None = None,
    limit: int = 50,
) -> str:
    """Return beliefs ordered by time, filtered by topic and/or time range.

    Use cases:
      timeline(topic="deployment") -- all deployment beliefs chronologically
      timeline(start="-7d") -- everything from the last 7 days
      timeline(session_id="abc123") -- replay session abc123
      timeline(topic="capital", start="2026-03-25", end="2026-03-28")

    start/end accept ISO 8601 timestamps or relative offsets: "-7d", "-24h", "-30m".
    """
    store: MemoryStore = _get_store()
    resolved_start: str | None = _resolve_relative_time(start) if start else None
    resolved_end: str | None = _resolve_relative_time(end) if end else None
    beliefs: list[Belief] = store.timeline(
        topic=topic,
        start=resolved_start,
        end=resolved_end,
        session_id=session_id,
        limit=limit,
    )
    if not beliefs:
        return "No beliefs found for the given time/topic filter."
    lines: list[str] = [f"Timeline: {len(beliefs)} belief(s)"]
    for b in beliefs:
        status: str = " [SUPERSEDED]" if b.valid_to else ""
        lock: str = " [LOCKED]" if b.locked else ""
        lines.append(
            f"  [{b.created_at}] ({b.belief_type}){lock}{status} {b.content[:200]}"
        )
    return "\n".join(lines)


@mcp.tool
def evolution(
    belief_id: str | None = None,
    topic: str | None = None,
) -> str:
    """Trace how a belief or topic evolved over time.

    Two modes:
    1. belief_id: follow the SUPERSEDES chain in both directions.
       Shows: original -> correction 1 -> correction 2 -> current.
    2. topic: FTS5 search + time ordering. Shows all beliefs about
       the topic chronologically, marking which ones superseded others.

    Use cases:
      evolution(belief_id="a1b2c3d4e5f6") -- full chain for this belief
      evolution(topic="dispatch gate") -- how dispatch gate policy evolved
    """
    if not belief_id and not topic:
        return "Error: provide either belief_id or topic."
    store: MemoryStore = _get_store()
    beliefs: list[Belief] = store.evolution(belief_id=belief_id, topic=topic)
    if not beliefs:
        return "No evolution chain found."
    lines: list[str] = [f"Evolution: {len(beliefs)} belief(s)"]
    for i, b in enumerate(beliefs):
        marker: str = "->" if i > 0 else "  "
        status: str = " [SUPERSEDED]" if b.valid_to else " [CURRENT]"
        lock: str = " [LOCKED]" if b.locked else ""
        lines.append(
            f"  {marker} [{b.created_at}] (ID: {b.id}){lock}{status} {b.content[:200]}"
        )
    return "\n".join(lines)


@mcp.tool
def diff(
    since: str | None = None,
    until: str | None = None,
) -> str:
    """Show what changed in the belief store over a time period.

    Returns three sections: ADDED, REMOVED, EVOLVED.
    Accepts ISO 8601 timestamps or relative offsets: "-7d", "-24h", "-1h".

    Use cases:
      diff(since="-24h") -- what changed in the last 24 hours
      diff(since="-7d") -- weekly diff
      diff(since="2026-04-11T00:00:00") -- since a specific time
    """
    if not since:
        return "Error: 'since' is required."
    store: MemoryStore = _get_store()
    resolved_since: str = _resolve_relative_time(since)
    resolved_until: str | None = _resolve_relative_time(until) if until else None
    changes: dict[str, list[Belief]] = store.diff(
        since=resolved_since,
        until=resolved_until,
    )
    added: list[Belief] = changes["added"]
    removed: list[Belief] = changes["removed"]
    evolved: list[Belief] = changes["evolved"]

    lines: list[str] = [f"Diff since {resolved_since}:"]
    lines.append(f"\nADDED ({len(added)}):")
    for b in added[:20]:
        lines.append(f"  + [{b.belief_type}] {b.content[:150]}")
    if len(added) > 20:
        lines.append(f"  ... and {len(added) - 20} more")

    lines.append(f"\nREMOVED ({len(removed)}):")
    for b in removed[:20]:
        lines.append(f"  - [{b.belief_type}] {b.content[:150]}")
    if len(removed) > 20:
        lines.append(f"  ... and {len(removed) - 20} more")

    lines.append(f"\nEVOLVED ({len(evolved)}):")
    for b in evolved[:20]:
        lines.append(f"  ~ [{b.belief_type}] {b.content[:150]}")
    if len(evolved) > 20:
        lines.append(f"  ... and {len(evolved) - 20} more")

    return "\n".join(lines)


def _resolve_relative_time(time_str: str) -> str:
    """Resolve relative time strings like '-7d', '-24h', '-30m' to ISO 8601."""
    import re as _re
    from datetime import datetime as _dt, timedelta as _td, timezone as _tz

    match: _re.Match[str] | None = _re.match(r"^-(\d+)([dhm])$", time_str)
    if match:
        value: int = int(match.group(1))
        unit: str = match.group(2)
        delta: _td
        if unit == "d":
            delta = _td(days=value)
        elif unit == "h":
            delta = _td(hours=value)
        else:
            delta = _td(minutes=value)
        return (_dt.now(_tz.utc) - delta).isoformat()
    return time_str


@mcp.tool
def delete(belief_id: str) -> str:
    """Soft-delete a belief by setting valid_to = now.

    The belief is not hard-deleted -- it remains in the database but is
    excluded from all searches, retrieval, and locked belief injection.
    Use this to clean up duplicate, stale, or incorrect beliefs.

    Args:
        belief_id: The belief ID to delete (e.g. "a1b2c3d4e5f6").
    """
    if _is_foreign_id(belief_id):
        return _FOREIGN_ID_ERROR
    store: MemoryStore = _get_store()
    belief: Belief | None = store.get_belief(belief_id)
    if belief is None:
        return f"Error: no belief found with ID {belief_id}"
    if belief.valid_to is not None:
        return f"Already deleted (ID: {belief.id}): {belief.content}"
    if belief.locked:
        return (
            f"Refused: belief {belief_id} is locked. "
            "Unlock it first with unlock(), or supersede it with correct()."
        )
    store.delete_belief(belief_id)
    return (
        f"Deleted (ID: {belief.id}): {belief.content} "
        f"[was: {belief.belief_type}, confidence: {belief.confidence:.0%}]"
    )


@mcp.tool
def bulk_delete(belief_ids: list[str]) -> str:
    """Soft-delete multiple beliefs at once.

    Use this for cleanup operations (e.g. removing duplicates identified
    by an audit). Each belief gets valid_to set to now.

    Args:
        belief_ids: List of belief IDs to delete.
    """
    foreign: list[str] = [bid for bid in belief_ids if _is_foreign_id(bid)]
    if foreign:
        return (
            f"Rejected: {len(foreign)} foreign ID(s) detected (contain ':'). "
            f"{_FOREIGN_ID_ERROR}"
        )
    store: MemoryStore = _get_store()
    locked_ids: list[str] = []
    deletable_ids: list[str] = []
    for bid in belief_ids:
        b: Belief | None = store.get_belief(bid)
        if b is not None and b.locked:
            locked_ids.append(bid)
        else:
            deletable_ids.append(bid)
    deleted: int = store.bulk_delete_beliefs(deletable_ids)
    skipped: int = len(deletable_ids) - deleted
    result: str = f"Deleted {deleted} of {len(belief_ids)} beliefs."
    if locked_ids:
        result += f" {len(locked_ids)} locked belief(s) refused (unlock first)."
    if skipped > 0:
        result += f" {skipped} were already deleted or not found."
    return result


_VALID_OUTCOMES: frozenset[str] = frozenset(
    {
        OUTCOME_USED,
        OUTCOME_IGNORED,
        OUTCOME_HARMFUL,
        OUTCOME_CONFIRMED,
        OUTCOME_WEAK,
    }
)


@mcp.tool
def snapshot(
    at_time: str | None = None,
    topic: str | None = None,
    belief_type: str | None = None,
    limit: int = 50,
) -> str:
    """Return a snapshot of the belief state at a point in time.

    Shows what the agent believed at a given moment, grouped by type.
    If no at_time is given, returns the current belief state.
    If topic is given, filters by FTS5 keyword search.

    Args:
        at_time: ISO timestamp or relative ("-7d", "-24h"). Default: now.
        topic: Optional keyword filter (FTS5 search).
        belief_type: Optional type filter (factual, correction, requirement, preference).
        limit: Maximum beliefs to return (default 50).
    """
    store: MemoryStore = _get_store()

    resolved_time: str | None = None
    if at_time is not None:
        resolved_time = _resolve_relative_time(at_time)

    beliefs: list[Belief]
    if topic is not None:
        effective_time: str = (
            resolved_time
            if resolved_time is not None
            else datetime.now(timezone.utc).isoformat()
        )
        beliefs = store.search_at_time(topic, effective_time, top_k=limit)
        if belief_type is not None:
            beliefs = [b for b in beliefs if b.belief_type == belief_type]
    else:
        beliefs = store.get_snapshot(
            at_time=resolved_time,
            belief_type=belief_type,
            limit=limit,
        )

    if not beliefs:
        return "No beliefs found for the given criteria."

    # Group by type
    by_type: dict[str, list[Belief]] = {}
    for b in beliefs:
        by_type.setdefault(b.belief_type, []).append(b)

    total: int = len(beliefs)
    locked_count: int = sum(1 for b in beliefs if b.locked)
    avg_conf: float = sum(b.confidence for b in beliefs) / total

    lines: list[str] = [
        f"Belief snapshot ({total} beliefs, {locked_count} locked, avg_conf={avg_conf:.3f}):",
    ]
    if resolved_time is not None:
        lines[0] = (
            f"Belief snapshot at {resolved_time} ({total} beliefs, {locked_count} locked, avg_conf={avg_conf:.3f}):"
        )

    for bt, bt_beliefs in sorted(by_type.items(), key=lambda x: -len(x[1])):
        bt_locked: int = sum(1 for b in bt_beliefs if b.locked)
        bt_avg: float = sum(b.confidence for b in bt_beliefs) / len(bt_beliefs)
        lines.append(
            f"\n  {bt} ({len(bt_beliefs)}, {bt_locked} locked, avg={bt_avg:.3f}):"
        )
        for b in bt_beliefs[:10]:
            lock_tag: str = " [LOCKED]" if b.locked else ""
            snippet: str = b.content[:80].replace("\n", " ")
            lines.append(f"    [{b.confidence:.0%}{lock_tag}] {snippet}")
        if len(bt_beliefs) > 10:
            lines.append(f"    ... and {len(bt_beliefs) - 10} more")

    return "\n".join(lines)


@mcp.tool
def feedback(belief_id: str, outcome: str, detail: str = "") -> str:
    """Record whether a retrieved belief was useful, ignored, or harmful.

    Call this after using (or deciding not to use) a belief from search results.
    This closes the feedback loop: beliefs that help get stronger, beliefs that
    hurt get weaker (unless locked). Valence propagates through edges to
    connected beliefs.

    Args:
        belief_id: The belief ID from search results (e.g. "a1b2c3d4e5f6").
        outcome: One of "confirmed", "used", "ignored", "weak", or "harmful".
        detail: Optional context about why (e.g. "contradicted by user correction").
    """
    if _is_foreign_id(belief_id):
        return _FOREIGN_ID_ERROR
    if outcome not in _VALID_OUTCOMES:
        return f"Invalid outcome '{outcome}'. Must be one of: {', '.join(sorted(_VALID_OUTCOMES))}"

    store: MemoryStore = _get_store()
    session_id: str = _ensure_session()

    belief: Belief | None = store.get_belief(belief_id)
    if belief is None:
        return f"Belief {belief_id} not found."

    # Map string outcome to continuous valence
    valence_score: float = VALENCE_MAP.get(outcome, 0.0)

    test: TestResult = store.record_test_result(
        belief_id=belief_id,
        session_id=session_id,
        outcome=outcome,
        detection_layer=LAYER_EXPLICIT,
        outcome_detail=detail or None,
        valence=valence_score,
    )

    # Mark as explicitly rated so auto-feedback skips it
    _explicit_feedback_ids.add(belief_id)
    store.increment_session_metrics(session_id, feedback_given=1)

    # Propagate to edges (explicit feedback is strongest signal)
    traversed: list[tuple[int, int]] | None = getattr(
        store,
        "_last_traversed_edges",
        {},
    ).get(belief_id)
    store.propagate_feedback_to_edges(belief_id, outcome, traversed)

    # Propagate valence through the graph (multi-hop, edge-type modulated)
    propagated: int = 0
    if valence_score != 0.0:
        propagated = store.propagate_valence(belief_id, valence_score)

    # Re-read to get updated confidence
    updated: Belief | None = store.get_belief(belief_id)
    if updated is None:
        return f"Feedback recorded (test #{test.id}) but belief disappeared."

    lock_note: str = (
        " (locked, beta unchanged)"
        if updated.locked and outcome == OUTCOME_HARMFUL
        else ""
    )
    drop_warn: str = ""
    if belief.confidence >= 0.5 and updated.confidence < 0.5:
        snippet: str = updated.content[:80].replace("\n", " ")
        drop_warn = (
            f'\n  WARNING: Belief dropped below 50% confidence. Review: "{snippet}"'
        )
    prop_note: str = (
        f"\n  Valence {valence_score:+.1f} propagated to {propagated} connected beliefs"
        if propagated > 0
        else ""
    )
    return (
        f"Feedback recorded for {belief_id}: {outcome}{lock_note}\n"
        f"  confidence: {belief.confidence:.3f} -> {updated.confidence:.3f}\n"
        f"  alpha: {belief.alpha} -> {updated.alpha}, "
        f"beta: {belief.beta_param} -> {updated.beta_param}{drop_warn}{prop_note}"
    )


@mcp.tool
def confirm(belief_id: str, detail: str = "") -> str:
    """Confirm a belief is correct and valuable. Positive counterpart to correct().

    Use when the user explicitly validates a belief ("yes, exactly right",
    "beautiful", etc.) or when a response built on a belief receives strong
    positive feedback.

    Does NOT create a new belief (unlike correct()). Reinforces the existing
    graph structure around this belief via valence propagation.

    Args:
        belief_id: The belief ID to confirm (e.g. "a1b2c3d4e5f6").
        detail: Optional context (e.g. "user said 'beautiful' about this").
    """
    if _is_foreign_id(belief_id):
        return _FOREIGN_ID_ERROR

    store: MemoryStore = _get_store()
    session_id: str = _ensure_session()

    belief: Belief | None = store.get_belief(belief_id)
    if belief is None:
        return f"Belief {belief_id} not found."

    test: TestResult = store.record_test_result(
        belief_id=belief_id,
        session_id=session_id,
        outcome=OUTCOME_CONFIRMED,
        detection_layer=LAYER_EXPLICIT,
        outcome_detail=detail or "explicit confirmation",
        evidence_weight=CONFIRM_WEIGHT,
        valence=1.0,
    )

    _explicit_feedback_ids.add(belief_id)
    store.increment_session_metrics(session_id, feedback_given=1)

    # Propagate positive valence through the graph
    propagated: int = store.propagate_valence(belief_id, 1.0)

    updated: Belief | None = store.get_belief(belief_id)
    if updated is None:
        return f"Confirmed (test #{test.id}) but belief disappeared."

    prop_note: str = (
        f"\n  Valence +1.0 propagated to {propagated} connected beliefs"
        if propagated > 0
        else ""
    )
    return (
        f"Confirmed {belief_id}:{prop_note}\n"
        f"  confidence: {belief.confidence:.3f} -> {updated.confidence:.3f}\n"
        f"  alpha: {belief.alpha} -> {updated.alpha}, "
        f"beta: {belief.beta_param} -> {updated.beta_param}"
    )


@mcp.tool
def session_quality(score: float, detail: str = "") -> str:
    """Rate the overall quality of this session's memory contributions.

    Propagates valence through the retrieval subgraph of this session.
    Hub beliefs (high connectivity within the session) receive more weight.
    Peripheral beliefs receive attenuated valence via edge propagation.

    Args:
        score: -1.0 (memory was counterproductive) to +1.0 (memory was essential).
        detail: Optional context about the rating.
    """
    import math

    if score < -1.0 or score > 1.0:
        return "Score must be between -1.0 and +1.0"

    store: MemoryStore = _get_store()
    session_id: str = _ensure_session()

    belief_ids, edges, centrality = store.get_session_retrieval_subgraph(session_id)
    if not belief_ids:
        return "No beliefs were retrieved during this session."

    store.set_session_quality(session_id, score)

    # Hub-weighted valence distribution
    max_degree: int = max(centrality.values()) if centrality else 1
    total_updated: int = 0

    for bid in belief_ids:
        degree: int = centrality.get(bid, 0)
        # Hub boost: beliefs with higher degree get proportionally more weight
        hub_factor: float = 1.0 + (degree / max(max_degree, 1))
        # Base weight diluted by sqrt(n), then scaled by hub factor
        per_belief_valence: float = score * hub_factor / math.sqrt(len(belief_ids))

        if abs(per_belief_valence) < 0.01:
            continue

        belief: Belief | None = store.get_belief(bid)
        if belief is None:
            continue

        store.record_test_result(
            belief_id=bid,
            session_id=session_id,
            outcome=OUTCOME_USED if score > 0 else OUTCOME_IGNORED,
            detection_layer=LAYER_IMPLICIT,
            outcome_detail=f"session_quality: {score:+.2f}, hub_factor: {hub_factor:.2f}",
            valence=per_belief_valence,
        )
        total_updated += 1

    # Propagate from hub beliefs only (top 20% by degree)
    propagated: int = 0
    if centrality:
        degree_threshold: int = max(1, int(max_degree * 0.8))
        hub_ids: list[str] = [
            bid for bid, deg in centrality.items() if deg >= degree_threshold
        ]
        for hub_id in hub_ids[:10]:  # cap to avoid runaway
            propagated += store.propagate_valence(hub_id, score)

    return (
        f"Session quality {score:+.2f} applied:\n"
        f"  {total_updated} beliefs updated directly\n"
        f"  {propagated} additional beliefs reached via hub propagation\n"
        f"  {len(edges)} edges in retrieval subgraph\n"
        f"  Hub beliefs: {sum(1 for d in centrality.values() if d >= max(1, int(max_degree * 0.8)))}"
    )


@mcp.tool
def sync_obsidian(
    vault_path: str | None = None,
    full: bool = False,
    tier: str = "full",
    max_beliefs: int | None = None,
) -> str:
    """Sync beliefs to an Obsidian vault as markdown files.

    Each belief becomes a .md file with YAML frontmatter and wikilinked
    edges. Incremental by default (only writes changed beliefs).

    Open the vault in Obsidian to get graph view, backlinks, search, and
    Dataview queries over your entire belief network.

    Args:
        vault_path: Path to Obsidian vault root. Uses config if omitted.
        full: If True, rewrite all files unconditionally.
        tier: Filter tier: "core" (~2000 important beliefs), "connected"
              (non-orphans only), or "full" (all beliefs, default).
        max_beliefs: If set, export only this many beliefs by priority
                     (locked first, then user-sourced, then by edge count).
                     Overrides tier.
    """
    from agentmemory.obsidian import (
        ObsidianConfig,
        SyncResult,
        load_obsidian_config,
        sync_vault,
    )

    store: MemoryStore = _get_store()
    config: ObsidianConfig | None = load_obsidian_config(vault_path)
    if config is None:
        return (
            "Error: no vault path configured. Pass vault_path argument or set "
            "obsidian.vault_path in ~/.agentmemory/config.json"
        )
    if not config.vault_path.exists():
        return "Error: configured vault path does not exist. Check obsidian.vault_path in settings."

    result: SyncResult = sync_vault(
        store,
        config,
        full=full,
        tier=tier,
        max_beliefs=max_beliefs,
    )
    return (
        f"Obsidian sync complete ({result.elapsed_seconds}s):\n"
        f"  Written: {result.beliefs_written}\n"
        f"  Unchanged: {result.beliefs_unchanged}\n"
        f"  Archived: {result.beliefs_archived}\n"
        f"  Index notes: {result.index_notes_written}\n"
        f"  Vault: {config.vault_path}"
    )


@mcp.tool
def import_obsidian(
    vault_path: str | None = None,
    dry_run: bool = True,
) -> str:
    """Import changes made in Obsidian back into agentmemory.

    Detects belief files that were edited, created, or deleted in Obsidian
    since the last sync, and applies those changes to the database.

    Args:
        vault_path: Path to Obsidian vault root. Uses config if omitted.
        dry_run: If True (default), report changes without applying them.
    """
    from agentmemory.obsidian import (
        ImportResult,
        ObsidianConfig,
        VaultChange,
        detect_vault_changes,
        import_vault_changes,
        load_obsidian_config,
    )

    store: MemoryStore = _get_store()
    config: ObsidianConfig | None = load_obsidian_config(vault_path)
    if config is None:
        return (
            "Error: no vault path configured. Pass vault_path argument or set "
            "obsidian.vault_path in ~/.agentmemory/config.json"
        )
    if not config.vault_path.exists():
        return "Error: configured vault path does not exist. Check obsidian.vault_path in settings."

    changes: list[VaultChange] = detect_vault_changes(config)
    if not changes:
        return "No changes detected in vault since last sync."

    if dry_run:
        lines: list[str] = [f"Detected {len(changes)} change(s) (dry run):"]
        for c in changes:
            preview: str = (c.new_text or "")[:60]
            lines.append(f"  [{c.change_type}] {c.belief_id}: {preview}")
        lines.append("\nRe-run with dry_run=False to apply.")
        return "\n".join(lines)

    result: ImportResult = import_vault_changes(store, changes)
    error_lines: str = ""
    if result.errors:
        error_lines = "\n  Errors:\n" + "\n".join(f"    - {e}" for e in result.errors)
    return (
        f"Import complete:\n"
        f"  Modified: {result.modified}\n"
        f"  New: {result.new_beliefs}\n"
        f"  Deleted: {result.deleted}"
        f"{error_lines}"
    )


@mcp.tool
def graph_metrics(top_n: int = 20) -> str:
    """Compute structural importance of beliefs using PageRank and degree.

    Returns the top N structurally important beliefs -- the hub nodes
    that connect the most knowledge in the belief graph.

    Args:
        top_n: Number of top beliefs to return (default 20).
    """
    from agentmemory.graph_metrics import compute_structural_importance

    store: MemoryStore = _get_store()
    importance: dict[str, float] = compute_structural_importance(store)

    if not importance:
        return "No edges in belief graph. Graph metrics require connected beliefs."

    top: list[tuple[str, float]] = sorted(
        importance.items(), key=lambda x: x[1], reverse=True
    )[:top_n]

    lines: list[str] = [f"Top {len(top)} structurally important beliefs:"]
    for bid, score in top:
        belief: Belief | None = store.get_belief(bid)
        preview: str = belief.content[:70] if belief else "(not found)"
        locked: str = " [LOCKED]" if belief and belief.locked else ""
        lines.append(f"  {score:.3f}{locked} [{bid}] {preview}")

    total: int = len(importance)
    lines.append(f"\n{total} beliefs with edges in graph.")
    return "\n".join(lines)


@mcp.tool
def link_docs(
    project_path: str | None = None,
    vault_path: str | None = None,
) -> str:
    """Export project documents to Obsidian vault with cross-reference links.

    Scans the project for markdown documents (research reports, experiments,
    case studies, etc.), extracts REQ-###, CS-###, Exp ## references, finds
    beliefs that mention each document, and exports everything as linked
    vault notes.

    Args:
        project_path: Project directory to scan. Uses cwd if omitted.
        vault_path: Obsidian vault root. Uses config if omitted.
    """
    from agentmemory.doc_linker import LinkResult, link_documents
    from agentmemory.obsidian import ObsidianConfig, load_obsidian_config

    store: MemoryStore = _get_store()
    config: ObsidianConfig | None = load_obsidian_config(vault_path)
    if config is None:
        return (
            "Error: no vault path configured. Pass vault_path argument or set "
            "obsidian.vault_path in ~/.agentmemory/config.json"
        )
    proj: Path = Path(project_path) if project_path else Path.cwd()
    if not proj.exists():
        return "Error: specified project path does not exist."

    result: LinkResult = link_documents(store, proj, config.vault_path)
    return (
        f"Document linking complete ({result.elapsed_seconds}s):\n"
        f"  Documents exported: {result.docs_exported}\n"
        f"  Cross-references linked: {result.refs_linked}\n"
        f"  Belief connections: {result.belief_refs_added}\n"
        f"  Vault: {config.vault_path}/_docs/"
    )


@mcp.tool
def recalibrate(
    deflation_factor: float = 0.2,
) -> str:
    """Recalibrate inflated Bayesian scores on agent-inferred beliefs.

    Agent-inferred beliefs inserted with inflated alpha priors get
    deflated: new_alpha = alpha * deflation_factor. User-sourced
    beliefs (user_corrected, user_stated) and locked beliefs are
    NOT touched.

    Run this after bulk onboarding or when the confidence distribution
    is compressed (most beliefs at 90%+, Thompson sampling unable to
    discriminate).

    Args:
        deflation_factor: Multiplier for alpha deflation (default 0.2).
            Lower = more aggressive deflation.
    """
    store: MemoryStore = _get_store()
    count: int = store.recalibrate_scores(deflation_factor)
    return (
        f"Recalibrated {count} agent-inferred beliefs "
        f"(deflation_factor={deflation_factor}).\n"
        f"User-sourced and locked beliefs were not touched."
    )


# ---------------------------------------------------------------------------
# Exploratory wonder tools
# ---------------------------------------------------------------------------


@mcp.tool
def wonder(
    query: str,
    agent_count: int = 4,
    budget: int = 2000,
    depth: int = 2,
) -> str:
    """Explore a topic: analyze gaps in the belief graph and generate research axes.

    Performs internal search + gap analysis, then returns structured output
    describing what the graph knows, what it doesn't, and research directions
    for parallel subagents to investigate.

    The skill layer (/mem:wonder) uses this output to spawn subagents. Each
    subagent writes a research document, which is then ingested via
    wonder_ingest to create speculative beliefs.

    Args:
        query: The topic, hypothesis, or question to explore.
        agent_count: Number of subagents to generate research axes for (default 4).
            User can say "quick 2-agent wonder" or "deep 6-agent wonder" to override.
        budget: Token budget for internal belief retrieval.
        depth: Graph expansion depth for BFS from seed beliefs.

    Returns:
        JSON with: known beliefs, gaps, coverage score, research axes, and
        speculative anchor belief IDs.
    """
    import json as _json

    from agentmemory.wonder import wonder as _wonder
    from agentmemory.wonder import wonder_result_to_dict

    store: MemoryStore = _get_store()
    result = _wonder(store, query, agent_count=agent_count, budget=budget, depth=depth)
    return _json.dumps(wonder_result_to_dict(result), indent=2)


@mcp.tool
def reason(
    query: str,
    budget: int = 2000,
    depth: int = 2,
) -> str:
    """Run consequence-path reasoning and return the CLI-equivalent report."""
    from agentmemory import cli as cli_mod

    output = io.StringIO()
    args = argparse.Namespace(query=query.split(), budget=budget, depth=depth)
    with redirect_stdout(output):
        cli_mod.cmd_reason(args)
    return output.getvalue().strip()


@mcp.tool
def wonder_ingest(
    research_documents: str,
    anchor_belief_ids: str = "",
) -> str:
    """Ingest subagent research documents as speculative beliefs.

    Each research document is run through the standard ingest pipeline, then
    all resulting beliefs are retagged as speculative (source_type=wonder_generated,
    belief_type=speculative) with low confidence priors (alpha=0.3, beta=1.0).

    Subagents should write freely -- there are no size limits on research
    documents. A 500-word document typically produces 50-100 speculative beliefs.
    Longer documents produce more.

    All speculative beliefs are subject to GC: if not accessed or confirmed
    within 14 days, they are soft-deleted.

    Args:
        research_documents: JSON array of objects, each with:
            - "text": the research document content (string, no size limit)
            - "axis_id": which research axis produced this (int)
            Example: [{"text": "research content...", "axis_id": 1}, ...]
        anchor_belief_ids: Comma-separated belief IDs to create RELATES_TO
            edges from new speculative beliefs. Usually the speculative_ids
            from the wonder() call.
    """
    import json as _json

    from agentmemory.wonder import wonder_ingest as _wonder_ingest

    # Parse research documents
    try:
        docs_parsed: list[dict[str, object]] = _json.loads(research_documents)
    except (_json.JSONDecodeError, TypeError, ValueError) as e:
        return f"Error: invalid JSON for research_documents: {e}"

    docs: list[tuple[str, int]] = []
    for d in docs_parsed:
        text: str = str(d.get("text", ""))
        axis_val: object = d.get("axis_id", 0)
        axis_id: int = int(axis_val) if isinstance(axis_val, (int, float, str)) else 0
        if text.strip():
            docs.append((text, axis_id))

    if not docs:
        return "No non-empty research documents to ingest."

    # Parse anchor IDs
    anchors: list[str] | None = None
    if anchor_belief_ids.strip():
        anchors = [aid.strip() for aid in anchor_belief_ids.split(",") if aid.strip()]

    store: MemoryStore = _get_store()
    result = _wonder_ingest(store, docs, anchor_belief_ids=anchors)

    return (
        f"Wonder ingest complete.\n"
        f"Documents processed: {result.documents_processed}\n"
        f"Beliefs created: {result.beliefs_created}\n"
        f"Beliefs tagged speculative: {result.beliefs_tagged}\n"
        f"Anchor edges created: {result.anchor_edges_created}\n"
        f"All speculative beliefs start at ~23% confidence (Beta(0.3, 1.0)) "
        f"and will be GC'd after 14 days if not accessed or confirmed."
    )


@mcp.tool
def wonder_gc(
    ttl_days: int = 14,
    dry_run: bool = True,
) -> str:
    """Garbage-collect stale speculative beliefs.

    Removes speculative beliefs that are older than ttl_days and have not
    been accessed, confirmed, or connected to evidence. Beliefs that have
    RESOLVES edges or updated confidence are preserved.

    Defaults to dry_run=True to show what would be deleted without acting.

    Args:
        ttl_days: Days before unaccessed speculative beliefs expire (default 14).
        dry_run: If True, report what would be deleted without deleting.
    """
    from agentmemory.wonder import wonder_gc as _wonder_gc

    store: MemoryStore = _get_store()
    result = _wonder_gc(store, ttl_days=ttl_days, dry_run=dry_run)

    mode: str = "DRY RUN" if dry_run else "EXECUTED"
    return (
        f"Wonder GC ({mode}):\n"
        f"Scanned: {result.scanned} speculative beliefs older than {ttl_days} days\n"
        f"{'Would delete' if dry_run else 'Deleted'}: {result.deleted}\n"
        f"Surviving: {result.surviving}\n"
        f"{'Set dry_run=False to execute.' if dry_run else 'Soft-deleted (valid_to set).'}"
    )


# ---------------------------------------------------------------------------
# Cross-project shared scopes (Exp 97/98)
# ---------------------------------------------------------------------------


@mcp.tool
def share_belief(
    belief_id: str,
    scope: str = "infra",
) -> str:
    """Share a belief to a cross-project scope.

    Copies the belief into a shared scope database so it can be retrieved
    from other projects that subscribe to the same scope. The original
    belief remains in the project database unchanged.

    Args:
        belief_id: ID of the belief to share.
        scope: Name of the shared scope (e.g., "infra", "deploy", "tooling").
    """
    if _is_foreign_id(belief_id):
        return _FOREIGN_ID_ERROR

    store: MemoryStore = _get_store()
    belief: Belief | None = store.get_belief(belief_id)
    if belief is None:
        return f"Belief {belief_id} not found."

    from agentmemory.shared_scopes import share_belief as _share_belief

    import os

    project_path: str = os.getcwd()
    shared_id: str = _share_belief(
        scope_name=scope,
        belief_id=belief.id,
        content=belief.content,
        belief_type=belief.belief_type,
        source_type=belief.source_type,
        alpha=belief.alpha,
        beta_param=belief.beta_param,
        locked=belief.locked,
        origin_project=project_path,
    )
    return (
        f"Shared belief to scope '{scope}': {belief.content[:80]}...\n"
        f"Shared ID: {shared_id}"
    )


@mcp.tool
def manage_scopes(
    action: str = "list",
    scope: str = "",
    project_path: str = "",
) -> str:
    """Manage cross-project shared scopes.

    Actions:
      - list: Show all scopes and their subscribers
      - subscribe: Add current project (or project_path) to a scope
      - unsubscribe: Remove current project from a scope
      - create: Create a new empty scope

    Args:
        action: One of "list", "subscribe", "unsubscribe", "create".
        scope: Scope name (required for subscribe/unsubscribe/create).
        project_path: Optional project path (defaults to cwd).
    """
    from agentmemory.shared_scopes import (
        ensure_scope_db,
        get_scopes_config,
        list_scopes,
        subscribe_project,
        unsubscribe_project,
    )
    import os

    resolved_path: str = project_path or os.getcwd()

    if action == "list":
        scopes: list[str] = list_scopes()
        if not scopes:
            return "No shared scopes exist yet. Use action='create' to create one."
        config: dict[str, list[str]] = get_scopes_config()
        lines: list[str] = ["Shared scopes:"]
        for s in scopes:
            subscribers: list[str] = config.get(s, [])
            sub_str: str = ", ".join(subscribers) if subscribers else "(no subscribers)"
            lines.append(f"  {s}: {sub_str}")
        return "\n".join(lines)

    if not scope:
        return "Error: 'scope' parameter required for this action."

    if action == "create":
        ensure_scope_db(scope)
        return f"Created shared scope '{scope}'."

    if action == "subscribe":
        ensure_scope_db(scope)
        subscribe_project(scope, resolved_path)
        return f"Subscribed '{resolved_path}' to scope '{scope}'."

    if action == "unsubscribe":
        unsubscribe_project(scope, resolved_path)
        return f"Unsubscribed '{resolved_path}' from scope '{scope}'."

    return f"Unknown action: {action}. Use list/subscribe/unsubscribe/create."


if __name__ == "__main__":
    mcp.run()
