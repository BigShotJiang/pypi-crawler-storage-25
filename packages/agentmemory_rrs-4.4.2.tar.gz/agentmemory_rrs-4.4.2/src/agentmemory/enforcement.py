"""Enforcement triad: directive detection, compliance audit, selective injection.

Closes the knowing-doing gap between injected beliefs and verified compliance.
See experiments/enforcement_triad_hypotheses.md for design rationale.
"""

from __future__ import annotations

import json
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from agentmemory.models import Belief
from agentmemory.store import MemoryStore
from agentmemory.supersession import extract_terms, jaccard_similarity

# ---------------------------------------------------------------------------
# H1: Directive Detection
# ---------------------------------------------------------------------------

# Imperative verb patterns that signal a user directive
_IMPERATIVE_VERBS: frozenset[str] = frozenset(
    {
        "fix",
        "enable",
        "disable",
        "add",
        "remove",
        "install",
        "wire",
        "turn",
        "make",
        "set",
        "configure",
        "update",
        "change",
        "ensure",
        "verify",
        "check",
        "run",
        "deploy",
        "push",
        "commit",
        "create",
        "delete",
        "implement",
        "build",
        "test",
        "move",
        "rename",
        "merge",
        "revert",
        "upgrade",
        "downgrade",
    }
)

_QUESTION_PATTERN: re.Pattern[str] = re.compile(r"\?\s*$")
_HEDGING_PATTERN: re.Pattern[str] = re.compile(
    r"^(i think|maybe|perhaps|could we|should we|what if|how about)",
    re.IGNORECASE,
)


def detect_directive(text: str) -> dict[str, Any]:
    """Detect whether user text is an imperative directive.

    Returns dict with is_directive bool and extracted verb/object if detected.
    """
    text_stripped: str = text.strip()

    # Questions are not directives
    if _QUESTION_PATTERN.search(text_stripped):
        return {"is_directive": False, "reason": "question"}

    # Hedging language reduces confidence
    if _HEDGING_PATTERN.match(text_stripped):
        return {"is_directive": False, "reason": "hedging"}

    # Check first meaningful word for imperative verb
    words: list[str] = text_stripped.lower().split()
    if not words:
        return {"is_directive": False, "reason": "empty"}

    first_verb: str | None = None
    for word in words[:4]:  # Check first 4 words for verb
        cleaned: str = re.sub(r"[^a-z]", "", word)
        if cleaned in _IMPERATIVE_VERBS:
            first_verb = cleaned
            break

    if first_verb is not None:
        return {
            "is_directive": True,
            "verb": first_verb,
            "content": text_stripped,
        }

    return {"is_directive": False, "reason": "no_imperative_verb"}


def process_directive(store: MemoryStore, text: str) -> Belief | None:
    """Create a TODO belief from a detected directive.

    Returns the created belief or None if text is not a directive.
    """
    detection: dict[str, Any] = detect_directive(text)
    if not detection["is_directive"]:
        return None

    belief: Belief = store.insert_belief(
        content=text,
        belief_type="todo",
        source_type="user_stated",
        alpha=4.0,
        beta_param=1.0,
    )
    # Mark as forward-looking
    store.set_temporal_direction(belief.id, "forward")
    belief.temporal_direction = "forward"
    return belief


def detect_repetition(
    store: MemoryStore, text: str, threshold: float = 0.5
) -> tuple[bool, int]:
    """Check if this directive repeats an existing unresolved TODO.

    Returns (is_repeat, count_of_similar_todos).
    """
    new_terms: set[str] = extract_terms(text)
    if len(new_terms) < 2:
        return False, 0

    # Search for existing TODO beliefs
    candidates: list[Belief] = store.search(text, top_k=20)
    count: int = 0
    for candidate in candidates:
        if candidate.belief_type != "todo":
            continue
        if candidate.valid_to is not None:
            continue
        candidate_terms: set[str] = extract_terms(candidate.content)
        if jaccard_similarity(new_terms, candidate_terms) >= threshold:
            count += 1

    return count > 0, count


def check_escalation(store: MemoryStore, threshold: int = 3) -> list[dict[str, Any]]:
    """Find TODO directives that have been repeated >= threshold times.

    Returns list of escalation records with content and count.
    """
    # Get all active TODO beliefs via direct query
    active_todos: list[Belief] = store.get_beliefs_by_type("todo")

    # Group by topic (Jaccard clusters)
    clusters: list[list[Belief]] = []
    assigned: set[str] = set()

    for todo in active_todos:
        if todo.id in assigned:
            continue
        cluster: list[Belief] = [todo]
        assigned.add(todo.id)
        todo_terms: set[str] = extract_terms(todo.content)

        for other in active_todos:
            if other.id in assigned:
                continue
            other_terms: set[str] = extract_terms(other.content)
            if jaccard_similarity(todo_terms, other_terms) >= 0.4:
                cluster.append(other)
                assigned.add(other.id)

        clusters.append(cluster)

    escalations: list[dict[str, Any]] = []
    for cluster in clusters:
        if len(cluster) >= threshold:
            escalations.append(
                {
                    "content": cluster[0].content,
                    "count": len(cluster),
                    "belief_ids": [b.id for b in cluster],
                }
            )

    return escalations


# ---------------------------------------------------------------------------
# H2: Compliance Audit
# ---------------------------------------------------------------------------


@dataclass
class ComplianceResult:
    """Result of a single compliance check."""

    belief_id: str
    belief_content: str
    check: str
    outcome: str  # "compliant" or "violated"
    detail: str = ""


def _eval_file_contains(check_args: str) -> bool:
    """Evaluate file_contains:path:content predicate."""
    parts: list[str] = check_args.split(":", 1)
    if len(parts) < 2:
        return False
    file_path: str = parts[0]
    expected: str = parts[1]
    try:
        content: str = Path(file_path).read_text()
        return expected in content
    except (OSError, ValueError):
        return False


def _eval_config_value(check_args: str) -> bool:
    """Evaluate config_value:path:dotted.key:expected predicate."""
    parts: list[str] = check_args.split(":", 2)
    if len(parts) < 3:
        return False
    file_path: str = parts[0]
    key_path: str = parts[1]
    expected: str = parts[2]

    try:
        data: Any = json.loads(Path(file_path).read_text())
        for key in key_path.split("."):
            data = data[key]
        return str(data).lower() == expected.lower()
    except (OSError, ValueError, KeyError, TypeError):
        return False


def _eval_command_succeeds(check_args: str) -> bool:
    """Evaluate command_succeeds:command predicate."""
    try:
        result = subprocess.run(
            check_args,
            shell=True,
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


_PREDICATE_EVALUATORS: dict[str, Any] = {
    "file_contains": _eval_file_contains,
    "config_value": _eval_config_value,
    "command_succeeds": _eval_command_succeeds,
}


def check_compliance(store: MemoryStore) -> list[dict[str, Any]]:
    """Run compliance audit on all locked beliefs with compliance_check set.

    Returns list of result dicts with outcome and metadata.
    """
    beliefs: list[Belief] = store.get_locked_beliefs()
    results: list[dict[str, Any]] = []

    for belief in beliefs:
        check: str | None = store.get_compliance_check(belief.id)
        if not check:
            continue

        # Parse predicate type and args
        parts: list[str] = check.split(":", 1)
        if len(parts) < 2:
            continue
        predicate_type: str = parts[0]
        predicate_args: str = parts[1]

        evaluator: Any | None = _PREDICATE_EVALUATORS.get(predicate_type)
        if evaluator is None:
            continue

        is_compliant: bool = evaluator(predicate_args)
        results.append(
            {
                "belief_id": belief.id,
                "belief_content": belief.content,
                "check": check,
                "outcome": "compliant" if is_compliant else "violated",
            }
        )

    return results


def record_violations(
    store: MemoryStore,
    violations: list[dict[str, Any]],
    session_id: str = "__compliance_audit__",
) -> None:
    """Record compliance violations in the tests/feedback system."""
    for violation in violations:
        store.record_test_result(
            belief_id=violation["belief_id"],
            session_id=session_id,
            outcome="violated",
            detection_layer="compliance_audit",
        )


# ---------------------------------------------------------------------------
# H3: Selective Injection
# ---------------------------------------------------------------------------


def select_relevant_constraints(
    store: MemoryStore, prompt: str, max_k: int = 5
) -> list[Belief]:
    """Select the most relevant locked beliefs for a given prompt.

    Uses activation_condition matching and FTS5 relevance scoring.
    Returns at most max_k beliefs.
    """
    locked: list[Belief] = store.get_locked_beliefs()
    if not locked:
        return []

    prompt_terms: set[str] = extract_terms(prompt)
    scored: list[tuple[float, Belief]] = []

    for belief in locked:
        score: float = 0.0

        # Score by term overlap
        belief_terms: set[str] = extract_terms(belief.content)
        if belief_terms:
            score += jaccard_similarity(prompt_terms, belief_terms)

        # Score by activation_condition keyword match
        if belief.activation_condition:
            condition: str = belief.activation_condition
            if "keyword_any:" in condition:
                keywords_str: str = condition.split("keyword_any:")[1].split("+")[0]
                keywords: list[str] = keywords_str.split(",")
                prompt_lower: str = prompt.lower()
                matches: int = sum(1 for kw in keywords if kw.strip() in prompt_lower)
                if matches > 0:
                    score += 0.5 * (matches / len(keywords))

        scored.append((score, belief))

    # Sort by score descending, return top max_k with score > 0
    scored.sort(key=lambda x: x[0], reverse=True)
    return [b for s, b in scored[:max_k] if s > 0]


def format_selective_injection(store: MemoryStore, prompt: str) -> str:
    """Format selected constraints as imperative injection text."""
    selected: list[Belief] = select_relevant_constraints(store, prompt)
    if not selected:
        return ""

    lines: list[str] = ["BEFORE PROCEEDING -- VERIFY these constraints apply:"]
    for i, belief in enumerate(selected, 1):
        lines.append(f"  {i}. VERIFY: {belief.content}")

    return "\n".join(lines)
