"""Natural language sentiment feedback detector.

Detects positive and negative user sentiment in conversation turns and
maps it back to recently retrieved beliefs. This closes the feedback
loop using the user's natural language rather than requiring explicit
feedback tool calls.

"ok good", "nice", "yes" after a belief-informed response = positive signal.
"no thats wrong", "fix it", "i told you" = negative signal.
Neutral/ambiguous = no signal (avoid noise).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Final

# ---------------------------------------------------------------------------
# Sentiment patterns (compiled for speed -- runs on every user prompt)
# ---------------------------------------------------------------------------

# Positive: user confirms, approves, or expresses satisfaction.
# These must appear at/near the start of a short message to count.
_POSITIVE_PATTERNS: Final[list[re.Pattern[str]]] = [
    re.compile(r"^(ok\s+)?good", re.IGNORECASE),
    re.compile(r"^(ok\s+)?great", re.IGNORECASE),
    re.compile(r"^nice\b", re.IGNORECASE),
    re.compile(r"^perfect\b", re.IGNORECASE),
    re.compile(r"^exactly\b", re.IGNORECASE),
    re.compile(r"^(yes|yeah|yep|yup)\b", re.IGNORECASE),
    re.compile(r"^(ok|okay)\s*(,|\.|!|$)", re.IGNORECASE),
    re.compile(r"^i like (that|this|it)", re.IGNORECASE),
    re.compile(r"^(that|this) is (good|great|correct|right|cool)", re.IGNORECASE),
    re.compile(r"^cool\b", re.IGNORECASE),
    re.compile(r"^thats? (good|great|correct|right|cool|amazing)", re.IGNORECASE),
    re.compile(r"^lets? (do|go|proceed|continue)", re.IGNORECASE),
    re.compile(r"^(go|proceed|continue)\b", re.IGNORECASE),
]

# Negative: user corrects, rejects, or expresses dissatisfaction.
_NEGATIVE_PATTERNS: Final[list[re.Pattern[str]]] = [
    re.compile(r"^no[\s,.]", re.IGNORECASE),
    re.compile(r"^nah\b", re.IGNORECASE),
    re.compile(r"^(thats?|that is) (not right|wrong|incorrect|broken)", re.IGNORECASE),
    re.compile(r"^not (right|correct|what i)", re.IGNORECASE),
    re.compile(r"^wrong\b", re.IGNORECASE),
    re.compile(r"^stop\b", re.IGNORECASE),
    re.compile(r"^fix (it|this|that)", re.IGNORECASE),
    re.compile(r"i told you", re.IGNORECASE),
    re.compile(r"still (broken|wrong|not|doesn't|doesnt)", re.IGNORECASE),
    re.compile(r"thats? still (not|wrong|broken)", re.IGNORECASE),
    re.compile(r"you (didnt|didn't|forgot|ignored)", re.IGNORECASE),
    re.compile(r"doesn't work|doesnt work|not working", re.IGNORECASE),
]

# Amplifiers: strong positive/negative (larger valence)
_STRONG_POSITIVE: Final[list[re.Pattern[str]]] = [
    re.compile(r"^perfect\b", re.IGNORECASE),
    re.compile(r"^exactly\b", re.IGNORECASE),
    re.compile(r"amazing|excellent", re.IGNORECASE),
]

_STRONG_NEGATIVE: Final[list[re.Pattern[str]]] = [
    re.compile(r"i told you", re.IGNORECASE),
    re.compile(r"you (didnt|didn't|forgot|ignored)", re.IGNORECASE),
    re.compile(r"how many times", re.IGNORECASE),
]

# Maximum message length to analyze for sentiment.
# Longer messages are task content, not feedback.
_MAX_SENTIMENT_LENGTH: Final[int] = 200


@dataclass
class SentimentSignal:
    """Detected sentiment from a user message."""

    sentiment: str  # "positive", "negative", or "neutral"
    valence: float  # -1.0 to 1.0 (0.0 = neutral)
    confidence: float  # 0.0 to 1.0 (how confident in the detection)
    pattern: str  # Which pattern matched


def detect_sentiment(text: str) -> SentimentSignal:
    """Detect user sentiment from a conversation turn.

    Only analyzes short messages (< 200 chars) since longer messages
    are task content, not feedback. Returns neutral for ambiguous cases.
    """
    stripped: str = text.strip()

    # Long messages are task content, not sentiment
    if len(stripped) > _MAX_SENTIMENT_LENGTH:
        return SentimentSignal("neutral", 0.0, 0.0, "too_long")

    # Skip system content (XML tags, task notifications)
    if stripped.startswith("<") or stripped.startswith("{"):
        return SentimentSignal("neutral", 0.0, 0.0, "system_content")

    # Check negative first (corrections are more important than praise)
    for pattern in _STRONG_NEGATIVE:
        match: re.Match[str] | None = pattern.search(stripped)
        if match:
            return SentimentSignal("negative", -0.8, 0.9, match.group())

    for pattern in _NEGATIVE_PATTERNS:
        match = pattern.search(stripped)
        if match:
            return SentimentSignal("negative", -0.4, 0.7, match.group())

    # Check strong positive
    for pattern in _STRONG_POSITIVE:
        match = pattern.search(stripped)
        if match:
            return SentimentSignal("positive", 0.6, 0.9, match.group())

    # Check regular positive
    for pattern in _POSITIVE_PATTERNS:
        match = pattern.search(stripped)
        if match:
            return SentimentSignal("positive", 0.3, 0.7, match.group())

    return SentimentSignal("neutral", 0.0, 0.0, "no_match")


def apply_sentiment_to_pending(
    sentiment: SentimentSignal,
    pending_beliefs: list[tuple[str, str]],
) -> list[tuple[str, float]]:
    """Map a sentiment signal to pending beliefs from the previous retrieval.

    Returns list of (belief_id, valence) pairs to feed into the confidence
    update system. Only non-neutral sentiments produce updates.

    The valence is distributed across all pending beliefs since we can't
    know which specific belief the user is responding to.
    """
    if sentiment.sentiment == "neutral" or not pending_beliefs:
        return []

    # Distribute valence across pending beliefs, weighted by confidence
    per_belief_valence: float = (
        sentiment.valence * sentiment.confidence / len(pending_beliefs)
    )

    return [(bid, per_belief_valence) for bid, _content in pending_beliefs]


def detect_correction_frequency(
    recent_sentiments: list[SentimentSignal],
    window: int = 5,
) -> float:
    """Detect negative signal from correction frequency.

    If the user has issued multiple negative/correction signals in a
    short window, that's a stronger negative signal than any single
    message -- it means the system is persistently wrong.

    Returns a frequency-based negative valence (0.0 = no pattern,
    -1.0 = every recent message was a correction).
    """
    if len(recent_sentiments) < 2:
        return 0.0

    window_slice: list[SentimentSignal] = recent_sentiments[-window:]
    negative_count: int = sum(1 for s in window_slice if s.sentiment == "negative")
    ratio: float = negative_count / len(window_slice)

    # Only fire if >= 40% of recent messages are negative
    if ratio < 0.4:
        return 0.0

    return -ratio  # -0.4 to -1.0
