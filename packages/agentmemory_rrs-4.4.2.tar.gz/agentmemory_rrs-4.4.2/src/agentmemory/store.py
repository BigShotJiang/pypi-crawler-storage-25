"""MemoryStore: SQLite-backed persistent memory for AI coding agents.

WAL mode, FTS5 full-text search, Bayesian belief confidence, session recovery.
All writes are synchronous and durable before return.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import random
import sqlite3
import threading
import uuid
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Final

from agentmemory.models import (
    Belief,
    Checkpoint,
    Edge,
    Evidence,
    Observation,
    Session,
    TestResult,
)

_SCHEMA: Final[str] = """
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    model TEXT,
    project_context TEXT,
    summary TEXT,
    retrieval_tokens INTEGER NOT NULL DEFAULT 0,
    classification_tokens INTEGER NOT NULL DEFAULT 0,
    beliefs_created INTEGER NOT NULL DEFAULT 0,
    corrections_detected INTEGER NOT NULL DEFAULT 0,
    searches_performed INTEGER NOT NULL DEFAULT 0,
    feedback_given INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS observations (
    id TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    content TEXT NOT NULL,
    observation_type TEXT NOT NULL,
    source_type TEXT NOT NULL,
    source_id TEXT NOT NULL DEFAULT '',
    source_path TEXT NOT NULL DEFAULT '',
    session_id TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS beliefs (
    id TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    content TEXT NOT NULL,
    belief_type TEXT NOT NULL,
    alpha REAL NOT NULL DEFAULT 0.5,
    beta_param REAL NOT NULL DEFAULT 0.5,
    confidence REAL GENERATED ALWAYS AS (alpha / (alpha + beta_param)) STORED,
    source_type TEXT NOT NULL,
    locked INTEGER NOT NULL DEFAULT 0,
    valid_from TEXT,
    valid_to TEXT,
    superseded_by TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (superseded_by) REFERENCES beliefs(id)
);

CREATE TABLE IF NOT EXISTS evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    belief_id TEXT NOT NULL,
    observation_id TEXT NOT NULL,
    source_weight REAL NOT NULL DEFAULT 1.0,
    relationship TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (belief_id) REFERENCES beliefs(id),
    FOREIGN KEY (observation_id) REFERENCES observations(id)
);

CREATE TABLE IF NOT EXISTS edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_id TEXT NOT NULL,
    to_id TEXT NOT NULL,
    edge_type TEXT NOT NULL,
    weight REAL NOT NULL DEFAULT 1.0,
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (from_id) REFERENCES beliefs(id),
    FOREIGN KEY (to_id) REFERENCES beliefs(id)
);

CREATE TABLE IF NOT EXISTS checkpoints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    checkpoint_type TEXT NOT NULL,
    content TEXT NOT NULL,
    "references" TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS tests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    belief_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    retrieval_context TEXT,
    outcome TEXT NOT NULL,
    outcome_detail TEXT,
    detection_layer TEXT NOT NULL,
    evidence_weight REAL NOT NULL DEFAULT 1.0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (belief_id) REFERENCES beliefs(id),
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    operation TEXT NOT NULL,
    target_table TEXT NOT NULL,
    target_id TEXT NOT NULL,
    agent_id TEXT,
    reason TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS graph_edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_id TEXT NOT NULL,
    to_id TEXT NOT NULL,
    edge_type TEXT NOT NULL,
    weight REAL NOT NULL DEFAULT 1.0,
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS confidence_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    belief_id TEXT NOT NULL,
    alpha REAL NOT NULL,
    beta_param REAL NOT NULL,
    event_type TEXT NOT NULL,
    event_detail TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (belief_id) REFERENCES beliefs(id)
);

CREATE INDEX IF NOT EXISTS idx_confhist_belief ON confidence_history(belief_id);
CREATE INDEX IF NOT EXISTS idx_confhist_time ON confidence_history(created_at);

CREATE TABLE IF NOT EXISTS onboarding_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path TEXT NOT NULL,
    commit_hash TEXT,
    nodes_extracted INTEGER NOT NULL DEFAULT 0,
    edges_extracted INTEGER NOT NULL DEFAULT 0,
    beliefs_created INTEGER NOT NULL DEFAULT 0,
    observations_created INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_graph_edges_from ON graph_edges(from_id);
CREATE INDEX IF NOT EXISTS idx_graph_edges_to ON graph_edges(to_id);
CREATE INDEX IF NOT EXISTS idx_graph_edges_type ON graph_edges(edge_type);

CREATE VIRTUAL TABLE IF NOT EXISTS search_index USING fts5(
    id,
    content,
    type,
    tokenize='porter'
);

CREATE INDEX IF NOT EXISTS idx_beliefs_content_hash ON beliefs(content_hash);
CREATE INDEX IF NOT EXISTS idx_observations_content_hash ON observations(content_hash);
CREATE INDEX IF NOT EXISTS idx_beliefs_valid_to ON beliefs(valid_to);
CREATE INDEX IF NOT EXISTS idx_beliefs_locked ON beliefs(locked);
CREATE INDEX IF NOT EXISTS idx_beliefs_created_at ON beliefs(created_at);
CREATE INDEX IF NOT EXISTS idx_beliefs_temporal ON beliefs(created_at, valid_to);
CREATE INDEX IF NOT EXISTS idx_checkpoints_session ON checkpoints(session_id);
CREATE INDEX IF NOT EXISTS idx_evidence_belief ON evidence(belief_id);
CREATE INDEX IF NOT EXISTS idx_edges_from ON edges(from_id);
CREATE INDEX IF NOT EXISTS idx_edges_to ON edges(to_id);

CREATE TABLE IF NOT EXISTS pending_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    belief_id TEXT NOT NULL,
    belief_content TEXT NOT NULL,
    session_id TEXT,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_pending_feedback_session ON pending_feedback(session_id);

CREATE TABLE IF NOT EXISTS hrr_neighbors (
    belief_id TEXT NOT NULL,
    neighbor_id TEXT NOT NULL,
    similarity REAL NOT NULL,
    edge_type TEXT NOT NULL,
    direction TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (belief_id, neighbor_id, edge_type, direction)
);

CREATE INDEX IF NOT EXISTS idx_hrr_neighbors_belief ON hrr_neighbors(belief_id);
CREATE INDEX IF NOT EXISTS idx_hrr_neighbors_neighbor ON hrr_neighbors(neighbor_id);

CREATE TABLE IF NOT EXISTS belief_clusters (
    belief_id TEXT PRIMARY KEY,
    cluster_id INTEGER NOT NULL,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_belief_clusters_cluster ON belief_clusters(cluster_id);
"""


def _new_id() -> str:
    """Generate a short readable ID: 12-char UUID hex."""
    return uuid.uuid4().hex[:12]


def _content_hash(content: str) -> str:
    """SHA-256 of content, truncated to 12 hex chars for dedup key."""
    return hashlib.sha256(content.encode()).hexdigest()[:12]


def _now() -> str:
    """Current UTC timestamp in ISO 8601 format."""
    return datetime.now(timezone.utc).isoformat()


def _timestamp_gap_seconds(ts_a: str, ts_b: str) -> float:
    """Compute the absolute time gap in seconds between two ISO timestamps.

    Tolerant of various ISO 8601 formats (with/without timezone, T separator).
    Returns float('inf') if either timestamp cannot be parsed.
    """
    try:
        dt_a: datetime = datetime.fromisoformat(ts_a)
        dt_b: datetime = datetime.fromisoformat(ts_b)
        # Normalize to UTC if timezone-aware
        if dt_a.tzinfo is None:
            dt_a = dt_a.replace(tzinfo=timezone.utc)
        if dt_b.tzinfo is None:
            dt_b = dt_b.replace(tzinfo=timezone.utc)
        return abs((dt_b - dt_a).total_seconds())
    except (ValueError, TypeError):
        return float("inf")


def _row_to_observation(row: sqlite3.Row) -> Observation:
    keys: list[str] = list(row.keys())
    return Observation(
        id=row["id"],
        content_hash=row["content_hash"],
        content=row["content"],
        observation_type=row["observation_type"],
        source_type=row["source_type"],
        source_id=row["source_id"],
        source_path=row["source_path"] if "source_path" in keys else "",
        session_id=row["session_id"],
        created_at=row["created_at"],
    )


def row_to_belief(row: sqlite3.Row) -> Belief:
    keys: list[str] = list(row.keys())
    return Belief(
        id=row["id"],
        content_hash=row["content_hash"],
        content=row["content"],
        belief_type=row["belief_type"],
        alpha=row["alpha"],
        beta_param=row["beta_param"],
        confidence=row["confidence"],
        source_type=row["source_type"],
        locked=bool(row["locked"]),
        valid_from=row["valid_from"],
        valid_to=row["valid_to"],
        superseded_by=row["superseded_by"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        event_time=row["event_time"] if "event_time" in keys else None,
        session_id=row["session_id"] if "session_id" in keys else None,
        classified_by=row["classified_by"] if "classified_by" in keys else "offline",
        rigor_tier=row["rigor_tier"] if "rigor_tier" in keys else "hypothesis",
        method=row["method"] if "method" in keys else None,
        sample_size=row["sample_size"] if "sample_size" in keys else None,
        last_retrieved_at=row["last_retrieved_at"]
        if "last_retrieved_at" in keys
        else None,
        data_source=row["data_source"] if "data_source" in keys else "",
        independently_validated=bool(row["independently_validated"])
        if "independently_validated" in keys
        else False,
        temporal_direction=row["temporal_direction"]
        if "temporal_direction" in keys
        else "backward",
        uncertainty_vector=row["uncertainty_vector"]
        if "uncertainty_vector" in keys
        else None,
        hibernation_score=float(row["hibernation_score"])
        if "hibernation_score" in keys and row["hibernation_score"] is not None
        else None,
        activation_condition=row["activation_condition"]
        if "activation_condition" in keys
        else None,
        scope=str(row["scope"])
        if "scope" in keys and row["scope"] is not None
        else "project",
        lock_level=str(row["lock_level"])
        if "lock_level" in keys and row["lock_level"] is not None
        else ("user" if row["locked"] else "none"),
        doc_class=str(row["doc_class"])
        if "doc_class" in keys and row["doc_class"] is not None
        else "",
    )


def _row_to_session(row: sqlite3.Row) -> Session:
    keys: list[str] = list(row.keys())
    return Session(
        id=row["id"],
        started_at=row["started_at"],
        completed_at=row["completed_at"],
        model=row["model"],
        project_context=row["project_context"],
        summary=row["summary"],
        retrieval_tokens=int(row["retrieval_tokens"])
        if "retrieval_tokens" in keys
        else 0,
        classification_tokens=int(row["classification_tokens"])
        if "classification_tokens" in keys
        else 0,
        beliefs_created=int(row["beliefs_created"]) if "beliefs_created" in keys else 0,
        corrections_detected=int(row["corrections_detected"])
        if "corrections_detected" in keys
        else 0,
        searches_performed=int(row["searches_performed"])
        if "searches_performed" in keys
        else 0,
        feedback_given=int(row["feedback_given"]) if "feedback_given" in keys else 0,
        velocity_items_per_hour=float(row["velocity_items_per_hour"])
        if "velocity_items_per_hour" in keys
        and row["velocity_items_per_hour"] is not None
        else None,
        velocity_tier=row["velocity_tier"] if "velocity_tier" in keys else None,
        topics_json=row["topics_json"] if "topics_json" in keys else None,
    )


def _row_to_checkpoint(row: sqlite3.Row) -> Checkpoint:
    return Checkpoint(
        id=row["id"],
        session_id=row["session_id"],
        checkpoint_type=row["checkpoint_type"],
        content=row["content"],
        references=row["references"],
        created_at=row["created_at"],
    )


# GH-17: Type-dependent demotion thresholds for user-locked beliefs.
# Cumulative harmful evidence weight (since last reaffirmation) to demote
# user -> promoted. Stronger evidence contributes more toward demotion.
# Factual state is easier to demote than procedural constraints.
_USER_LOCK_DEMOTION_THRESHOLDS: dict[str, float] = {
    "factual": 9.0,  # e.g. 3 signals at weight=3.0
    "relational": 9.0,
    "causal": 12.0,
    "correction": 15.0,
    "procedural": 15.0,
    "preference": 15.0,
    "requirement": 15.0,
    "todo": 9.0,
}


class MemoryStore:
    """SQLite-backed memory store with FTS5 search and Bayesian belief tracking."""

    def __init__(self, db_path: str | Path, readonly: bool = False) -> None:
        """Open or create the database. Enable WAL mode. Create tables if needed.

        When readonly=True, opens the database in read-only mode (no schema
        init, no WAL). Used for cross-project queries where writes must be
        prevented.
        """
        self._db_path: Path = Path(db_path)
        self.readonly: bool = readonly
        self._write_lock: threading.Lock = threading.Lock()
        if readonly:
            uri: str = f"file:{self._db_path}?mode=ro"
            self._conn: sqlite3.Connection = sqlite3.connect(
                uri,
                uri=True,
                check_same_thread=False,
            )
            self._conn.execute("PRAGMA busy_timeout=5000")
        else:
            self._conn = sqlite3.connect(
                str(self._db_path),
                check_same_thread=False,
                timeout=10.0,
            )
        self._conn.row_factory = sqlite3.Row
        if not readonly:
            # Restrict database file to owner-only access (0600)
            if self._db_path.exists():
                self._db_path.chmod(0o600)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.execute("PRAGMA busy_timeout=10000")
        self._last_traversed_edges: dict[str, list[tuple[int, int]]] = {}
        self._in_transaction: bool = False
        if not readonly:
            self._init_schema()

    @property
    def connection(self) -> sqlite3.Connection:
        """Public read-only access to the underlying SQLite connection."""
        return self._conn

    @contextlib.contextmanager
    def transaction(self) -> Iterator[None]:
        """Context manager for batching writes in a single transaction.

        Defers commits until the block exits. Rolls back on exception.
        Interior _maybe_commit() calls become no-ops while active.
        """
        # Flush any pending implicit transaction before starting explicit one
        try:
            self._conn.commit()
        except Exception:
            pass
        self._conn.execute("BEGIN IMMEDIATE")
        self._in_transaction = True
        try:
            yield
            self._conn.commit()
        except BaseException:
            self._conn.rollback()
            raise
        finally:
            self._in_transaction = False

    def _maybe_commit(self) -> None:
        """Commit unless we are inside a transaction() block."""
        if not self._in_transaction:
            self._conn.commit()

    def _init_schema(self) -> None:
        """Create all tables and FTS5 index if they don't exist."""
        self._conn.executescript(_SCHEMA)
        self._conn.commit()
        self._migrate_sessions()
        self._migrate_beliefs()
        self._migrate_edges()
        self._migrate_tests()

    def _migrate_beliefs(self) -> None:
        """Run belief-table migrations."""
        # NOTE: backfill_lock_corrections() was removed. The system must not
        # auto-lock beliefs. Only explicit user confirmation via lock() is
        # allowed to set locked=True.
        cols: list[sqlite3.Row] = self._conn.execute(
            "PRAGMA table_info(beliefs)"
        ).fetchall()
        col_names: set[str] = {row["name"] for row in cols}
        # Wave 1B: bitemporal event_time (when fact occurred vs when ingested)
        if "event_time" not in col_names:
            self._conn.execute("ALTER TABLE beliefs ADD COLUMN event_time TEXT")
        # Wave 1B: session_id for session replay queries
        if "session_id" not in col_names:
            self._conn.execute("ALTER TABLE beliefs ADD COLUMN session_id TEXT")
        # Track which classifier produced this belief ("offline" or "llm").
        if "classified_by" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN classified_by TEXT NOT NULL DEFAULT 'offline'"
            )
        # REQ-025: rigor tier (hypothesis/simulated/empirically_tested/validated)
        if "rigor_tier" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN rigor_tier TEXT NOT NULL DEFAULT 'hypothesis'"
            )
        # REQ-023: provenance metadata
        if "method" not in col_names:
            self._conn.execute("ALTER TABLE beliefs ADD COLUMN method TEXT")
        if "sample_size" not in col_names:
            self._conn.execute("ALTER TABLE beliefs ADD COLUMN sample_size INTEGER")
        # Belief scope: "project" (default), "global", "end_user_facing", "developer_internal"
        if "scope" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN scope TEXT NOT NULL DEFAULT 'project'"
            )
        # Track when a belief was last retrieved
        if "last_retrieved_at" not in col_names:
            self._conn.execute("ALTER TABLE beliefs ADD COLUMN last_retrieved_at TEXT")
        # REQ-023: remaining provenance fields
        if "data_source" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN data_source TEXT NOT NULL DEFAULT ''"
            )
        if "independently_validated" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN independently_validated INTEGER NOT NULL DEFAULT 0"
            )
        # Speculative beliefs: forward-looking temporal direction
        if "temporal_direction" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN temporal_direction TEXT NOT NULL DEFAULT 'backward'"
            )
        # Multi-dimensional uncertainty vector (JSON array of [alpha, beta] pairs)
        if "uncertainty_vector" not in col_names:
            self._conn.execute("ALTER TABLE beliefs ADD COLUMN uncertainty_vector TEXT")
        # Hibernation score for soft-closing speculative branches
        if "hibernation_score" not in col_names:
            self._conn.execute("ALTER TABLE beliefs ADD COLUMN hibernation_score REAL")
        # Event-based activation condition for prospective beliefs
        if "activation_condition" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN activation_condition TEXT"
            )
        # 3-tier lock level: none / promoted / user
        if "lock_level" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN lock_level TEXT DEFAULT 'none'"
            )
            # Backfill: existing locked=1 -> 'user', locked=0 -> 'none'
            self._conn.execute(
                "UPDATE beliefs SET lock_level = 'user' WHERE locked = 1"
            )
        # Reclassification flag for beliefs with changed evidence
        if "needs_reclassification" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN needs_reclassification INTEGER NOT NULL DEFAULT 0"
            )
        # GH-22: freeform document class tag (api_docs, tax_filing, etc.)
        if "doc_class" not in col_names:
            self._conn.execute(
                "ALTER TABLE beliefs ADD COLUMN doc_class TEXT NOT NULL DEFAULT ''"
            )
        self._conn.commit()
        # Create index on session_id (safe to run even if already exists)
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_beliefs_session_id ON beliefs(session_id)"
        )
        self._conn.commit()
        self._migrate_observations()

    def _migrate_observations(self) -> None:
        """Add source_path column to observations if missing (existing DBs)."""
        cols: list[sqlite3.Row] = self._conn.execute(
            "PRAGMA table_info(observations)"
        ).fetchall()
        col_names: set[str] = {row["name"] for row in cols}
        if "source_path" not in col_names:
            self._conn.execute(
                "ALTER TABLE observations ADD COLUMN source_path TEXT NOT NULL DEFAULT ''"
            )
            self._conn.commit()

    def backfill_lock_corrections(self) -> int:
        """Lock all correction-type beliefs that are currently unlocked.
        Returns the number of beliefs locked."""
        cursor: sqlite3.Cursor = self._conn.execute(
            "UPDATE beliefs SET locked = 1 WHERE belief_type = 'correction' AND locked = 0"
        )
        self._conn.commit()
        return cursor.rowcount

    def _migrate_sessions(self) -> None:
        """Add token tracking and velocity columns to sessions if missing."""
        cols: list[sqlite3.Row] = self._conn.execute(
            "PRAGMA table_info(sessions)"
        ).fetchall()
        col_names: set[str] = {row["name"] for row in cols}
        new_cols: list[str] = [
            "retrieval_tokens",
            "classification_tokens",
            "beliefs_created",
            "corrections_detected",
            "searches_performed",
            "feedback_given",
        ]
        for col in new_cols:
            if col not in col_names:
                self._conn.execute(
                    f"ALTER TABLE sessions ADD COLUMN {col} INTEGER NOT NULL DEFAULT 0"
                )
        # Velocity tracking columns (Wave 1D)
        if "velocity_items_per_hour" not in col_names:
            self._conn.execute(
                "ALTER TABLE sessions ADD COLUMN velocity_items_per_hour REAL"
            )
        if "velocity_tier" not in col_names:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN velocity_tier TEXT")
        if "topics_json" not in col_names:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN topics_json TEXT")
        if "quality_score" not in col_names:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN quality_score REAL")
        self._conn.commit()

    def _migrate_edges(self) -> None:
        """Add Bayesian scoring and traversal tracking columns to edges."""
        cols: list[sqlite3.Row] = self._conn.execute(
            "PRAGMA table_info(edges)"
        ).fetchall()
        col_names: set[str] = {row["name"] for row in cols}
        if "alpha" not in col_names:
            self._conn.execute(
                "ALTER TABLE edges ADD COLUMN alpha REAL NOT NULL DEFAULT 1.0"
            )
        if "beta_param" not in col_names:
            self._conn.execute(
                "ALTER TABLE edges ADD COLUMN beta_param REAL NOT NULL DEFAULT 1.0"
            )
        if "traversal_count" not in col_names:
            self._conn.execute(
                "ALTER TABLE edges ADD COLUMN traversal_count INTEGER NOT NULL DEFAULT 0"
            )
        if "last_traversed_at" not in col_names:
            self._conn.execute("ALTER TABLE edges ADD COLUMN last_traversed_at TEXT")
        if "pruned_at" not in col_names:
            self._conn.execute("ALTER TABLE edges ADD COLUMN pruned_at TEXT")
        self._conn.commit()

    def _migrate_tests(self) -> None:
        """Add valence column to tests table if missing."""
        cols: list[sqlite3.Row] = self._conn.execute(
            "PRAGMA table_info(tests)"
        ).fetchall()
        col_names: set[str] = {row["name"] for row in cols}
        if "valence" not in col_names:
            self._conn.execute("ALTER TABLE tests ADD COLUMN valence REAL")
        self._conn.commit()

    # --- Observations (immutable) ---

    def insert_observation(
        self,
        content: str,
        observation_type: str,
        source_type: str,
        source_id: str = "",
        source_path: str = "",
        session_id: str | None = None,
    ) -> Observation:
        """Insert an observation. Content-hash dedup: if same hash exists, return existing.

        Args:
            source_id: Unique identifier for the source -- a file path, commit SHA,
                turn ID, or document hash. Must NOT be the source type string
                (use source_type for that). Empty string means unknown provenance.
        """
        ch: str = _content_hash(content)
        existing: sqlite3.Row | None = self._conn.execute(
            "SELECT * FROM observations WHERE content_hash = ?", (ch,)
        ).fetchone()
        if existing is not None:
            return _row_to_observation(existing)

        obs_id: str = _new_id()
        ts: str = _now()
        self._conn.execute(
            """INSERT INTO observations
               (id, content_hash, content, observation_type, source_type, source_id, source_path, session_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                obs_id,
                ch,
                content,
                observation_type,
                source_type,
                source_id,
                source_path,
                session_id,
                ts,
            ),
        )
        self._conn.execute(
            "INSERT INTO search_index(id, content, type) VALUES (?, ?, ?)",
            (obs_id, content, "observation"),
        )
        self._maybe_commit()
        return Observation(
            id=obs_id,
            content_hash=ch,
            content=content,
            observation_type=observation_type,
            source_type=source_type,
            source_id=source_id,
            source_path=source_path,
            session_id=session_id,
            created_at=ts,
        )

    # --- Beliefs ---

    def insert_belief(
        self,
        content: str,
        belief_type: str,
        source_type: str,
        alpha: float = 0.5,
        beta_param: float = 0.5,
        locked: bool = False,
        observation_id: str | None = None,
        created_at: str | None = None,
        event_time: str | None = None,
        session_id: str | None = None,
        classified_by: str = "offline",
        rigor_tier: str = "hypothesis",
        method: str | None = None,
        sample_size: int | None = None,
        data_source: str = "",
        independently_validated: bool = False,
        scope: str = "project",
        lock_level: str = "none",
        doc_class: str = "",
    ) -> Belief:
        """Insert a belief with optional evidence link. Content-hash dedup.

        Also inserts into FTS5 search_index. If the same content hash already
        exists, returns the existing belief without modification.

        If created_at is provided, uses that timestamp instead of now().
        This enables source-truth dating (e.g., git commit dates).

        event_time is the bitemporal "when the fact occurred" timestamp,
        distinct from created_at (when the system ingested it).
        session_id links the belief to the session that created it.
        """
        ch: str = _content_hash(content)
        with self._write_lock:
            existing: sqlite3.Row | None = self._conn.execute(
                "SELECT * FROM beliefs WHERE content_hash = ?", (ch,)
            ).fetchone()
            if existing is not None:
                return row_to_belief(existing)

            belief_id: str = _new_id()
            ts: str = created_at if created_at is not None else _now()
            confidence: float = alpha / (alpha + beta_param)
            locked_int: int = 1 if locked else 0
            # Derive lock_level from locked flag if caller used legacy API
            effective_lock_level: str = lock_level
            if locked and lock_level == "none":
                effective_lock_level = "user"

            self._conn.execute(
                """INSERT INTO beliefs
                   (id, content_hash, content, belief_type, alpha, beta_param,
                    source_type, locked, valid_from, valid_to, superseded_by,
                    created_at, updated_at, event_time, session_id, classified_by,
                    rigor_tier, method, sample_size, data_source,
                    independently_validated, scope, lock_level, doc_class)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    belief_id,
                    ch,
                    content,
                    belief_type,
                    alpha,
                    beta_param,
                    source_type,
                    locked_int,
                    ts,
                    ts,
                    event_time,
                    session_id,
                    classified_by,
                    rigor_tier,
                    method,
                    sample_size,
                    data_source,
                    1 if independently_validated else 0,
                    scope,
                    effective_lock_level,
                    doc_class,
                ),
            )
            self._conn.execute(
                "INSERT INTO search_index(id, content, type) VALUES (?, ?, ?)",
                (belief_id, content, "belief"),
            )

            if observation_id is not None:
                ev_ts: str = _now()
                # Determine source_weight from source_type
                weight: float = (
                    1.0 if source_type in ("user_stated", "user_corrected") else 0.5
                )
                self._conn.execute(
                    """INSERT INTO evidence
                       (belief_id, observation_id, source_weight, relationship, created_at)
                       VALUES (?, ?, ?, 'supports', ?)""",
                    (belief_id, observation_id, weight, ev_ts),
                )

            self._maybe_commit()
        return Belief(
            id=belief_id,
            content_hash=ch,
            content=content,
            belief_type=belief_type,
            alpha=alpha,
            beta_param=beta_param,
            confidence=confidence,
            source_type=source_type,
            locked=locked,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=ts,
            updated_at=ts,
            event_time=event_time,
            session_id=session_id,
            classified_by=classified_by,
            rigor_tier=rigor_tier,
            method=method,
            sample_size=sample_size,
            data_source=data_source,
            independently_validated=independently_validated,
            scope=scope,
            doc_class=doc_class,
        )

    def lock_belief(self, belief_id: str) -> None:
        """Mark a belief as user-locked (highest tier).

        User-locked beliefs are non-negotiable: only explicit user action
        can unlock them. They resist all automated confidence changes.
        """
        ts: str = _now()
        self._conn.execute(
            "UPDATE beliefs SET locked = 1, lock_level = 'user', updated_at = ? WHERE id = ?",
            (ts, belief_id),
        )
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT alpha, beta_param FROM beliefs WHERE id = ?", (belief_id,)
        ).fetchone()
        if row is not None:
            self._record_confidence(
                belief_id, row["alpha"], row["beta_param"], "locked"
            )
        self._conn.commit()

    def unlock_belief(self, belief_id: str) -> bool:
        """Remove the lock from a belief, allowing normal confidence updates.

        Returns True if the belief was unlocked, False if not found.
        """
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            "UPDATE beliefs SET locked = 0, lock_level = 'none', updated_at = ? "
            "WHERE id = ? AND locked = 1",
            (ts, belief_id),
        )
        if cursor.rowcount > 0:
            row: sqlite3.Row | None = self._conn.execute(
                "SELECT alpha, beta_param FROM beliefs WHERE id = ?", (belief_id,)
            ).fetchone()
            if row is not None:
                self._record_confidence(
                    belief_id, row["alpha"], row["beta_param"], "unlocked"
                )
        self._conn.commit()
        return cursor.rowcount > 0

    def promote_belief(self, belief_id: str) -> bool:
        """Promote a belief to 'promoted' lock level.

        Promoted beliefs resist noise (single ignores) but can be demoted
        by 2+ independent counter-signals. They are NOT user-locked.

        Returns True if promoted, False if not found or already user-locked.
        """
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            "UPDATE beliefs SET locked = 1, lock_level = 'promoted', updated_at = ? "
            "WHERE id = ? AND lock_level = 'none'",
            (ts, belief_id),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def demote_belief(self, belief_id: str) -> bool:
        """Demote a 'promoted' belief back to 'none'.

        Only demotes promoted beliefs, not user-locked ones.
        Returns True if demoted, False if not found or user-locked.
        """
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            "UPDATE beliefs SET locked = 0, lock_level = 'none', updated_at = ? "
            "WHERE id = ? AND lock_level = 'promoted'",
            (ts, belief_id),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def delete_belief(self, belief_id: str) -> bool:
        """Soft-delete a belief by setting valid_to = now.

        Returns True if the belief existed and was deleted, False if not found
        or already deleted.
        """
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            "UPDATE beliefs SET valid_to = ?, updated_at = ? "
            "WHERE id = ? AND valid_to IS NULL",
            (ts, ts, belief_id),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def bulk_delete_beliefs(self, belief_ids: list[str]) -> int:
        """Soft-delete multiple beliefs. Returns number actually deleted."""
        ts: str = _now()
        deleted: int = 0
        for belief_id in belief_ids:
            cursor: sqlite3.Cursor = self._conn.execute(
                "UPDATE beliefs SET valid_to = ?, updated_at = ? "
                "WHERE id = ? AND valid_to IS NULL",
                (ts, ts, belief_id),
            )
            deleted += cursor.rowcount
        self._conn.commit()
        return deleted

    def supersede_belief(self, old_id: str, new_id: str, reason: str) -> None:
        """Mark old belief as superseded. Sets valid_to, creates a SUPERSEDES edge.

        Locked beliefs CAN be superseded when evidence is sufficient.
        The lock is preserved on the old belief for audit trail, but
        valid_to is set so it no longer appears in active queries.
        """
        with self._write_lock:
            old_row: sqlite3.Row | None = self._conn.execute(
                "SELECT locked FROM beliefs WHERE id = ?", (old_id,)
            ).fetchone()
            if old_row is None:
                return

            ts: str = _now()
            self._conn.execute(
                "UPDATE beliefs SET valid_to = ?, superseded_by = ?, updated_at = ? WHERE id = ?",
                (ts, new_id, ts, old_id),
            )
            self._conn.execute(
                """INSERT INTO edges (from_id, to_id, edge_type, weight, reason, created_at)
                   VALUES (?, ?, 'SUPERSEDES', 1.0, ?, ?)""",
                (new_id, old_id, reason, ts),
            )
            row: sqlite3.Row | None = self._conn.execute(
                "SELECT alpha, beta_param FROM beliefs WHERE id = ?", (old_id,)
            ).fetchone()
            if row is not None:
                self._record_confidence(
                    old_id, row["alpha"], row["beta_param"], "superseded", new_id
                )
            self._conn.commit()

    def _record_confidence(
        self,
        belief_id: str,
        alpha: float,
        beta_param: float,
        event_type: str,
        event_detail: str = "",
    ) -> None:
        """Append a snapshot to confidence_history for trajectory analysis."""
        ts: str = _now()
        self._conn.execute(
            """INSERT INTO confidence_history
               (belief_id, alpha, beta_param, event_type, event_detail, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (belief_id, alpha, beta_param, event_type, event_detail, ts),
        )

    # Minimum evidence weight required to reduce confidence on locked beliefs.
    # Casual noise (weight=1.0) is filtered; strong evidence (weight>=3.0) gets through.
    LOCKED_EVIDENCE_THRESHOLD: float = 3.0

    def update_confidence(
        self,
        belief_id: str,
        outcome: str,
        weight: float = 1.0,
        valence: float | None = None,
    ) -> bool:
        """Bayesian update via outcome string or continuous valence.

        If valence is provided, it overrides the outcome-based logic:
          valence > 0: alpha += abs(valence) * weight
          valence < 0: beta  += abs(valence) * weight
          valence == 0: no change

        If valence is None, falls back to legacy outcome-based updates:
          'used'/'confirmed': alpha += weight
          'harmful': beta += weight (locked beliefs require stronger evidence)
          'ignored'/'contradicted'/'weak': no change (weak uses valence path)

        Locked beliefs require stronger evidence (weight >= LOCKED_EVIDENCE_THRESHOLD)
        to have beta_param increased. They are NOT immune to evidence, just resistant
        to casual noise.
        Returns True if the belief dropped below 0.5 confidence (TB-15 warning).
        """
        with self._write_lock:
            row: sqlite3.Row | None = self._conn.execute(
                "SELECT alpha, beta_param, locked, belief_type, lock_level FROM beliefs WHERE id = ?",
                (belief_id,),
            ).fetchone()
            if row is None:
                return False

            old_alpha: float = row["alpha"]
            old_beta: float = row["beta_param"]
            alpha: float = old_alpha
            beta: float = old_beta
            is_locked: bool = bool(row["locked"])
            belief_type: str = str(row["belief_type"] or "factual")
            # Read lock_level with fallback for pre-migration DBs
            lock_level: str = "none"
            if "lock_level" in row.keys():
                lock_level = str(row["lock_level"] or "none")
            elif is_locked:
                lock_level = "user"
            is_user_locked: bool = lock_level in ("user", "freeze")
            ts: str = _now()

            # Fix 3: First-signal amplification (FSRS-inspired).
            # The first feedback event applies 3x weight to create meaningful
            # separation from the prior. Skip for user-locked beliefs to avoid
            # breaching the LOCKED_EVIDENCE_THRESHOLD on casual feedback.
            if not is_user_locked:
                prior_feedback: int = self._conn.execute(
                    "SELECT COUNT(*) FROM tests WHERE belief_id = ?",
                    (belief_id,),
                ).fetchone()[0]
                if prior_feedback == 0:
                    weight = weight * 3.0

            if valence is not None:
                # Continuous valence path
                if valence > 0:
                    alpha += abs(valence) * weight
                elif valence < 0:
                    if is_user_locked:
                        if abs(valence) * weight >= self.LOCKED_EVIDENCE_THRESHOLD:
                            beta += abs(valence) * weight
                    else:
                        beta += abs(valence) * weight
            else:
                # Legacy discrete outcome path
                if outcome in ("used", "confirmed"):
                    alpha += weight
                elif outcome == "harmful":
                    if is_user_locked:
                        if weight >= self.LOCKED_EVIDENCE_THRESHOLD:
                            beta += weight
                    else:
                        beta += weight
                elif outcome == "ignored" and not is_user_locked:
                    # Weak evidence of irrelevance: retrieved but not acted on.
                    # 0.1 weight means ~10 ignores = 1 "used" signal.
                    # User-locked beliefs are exempt. Promoted beliefs DO receive
                    # this update -- they resist noise through their higher alpha,
                    # not through immunity.
                    beta += 0.1 * weight

            self._conn.execute(
                "UPDATE beliefs SET alpha = ?, beta_param = ?, updated_at = ? WHERE id = ?",
                (alpha, beta, ts, belief_id),
            )
            self._record_confidence(belief_id, alpha, beta, f"feedback_{outcome}")

            # Auto-demotion: promoted beliefs with 2+ counter-signals get demoted
            if lock_level == "promoted" and beta >= old_beta + 2.0:
                self._conn.execute(
                    "UPDATE beliefs SET locked = 0, lock_level = 'none', updated_at = ? "
                    "WHERE id = ? AND lock_level = 'promoted'",
                    (ts, belief_id),
                )
                self._record_confidence(belief_id, alpha, beta, "auto_demoted")

            # GH-17: User-locked demotion under accumulated evidence.
            # User-locked beliefs are strong but NOT immune. When cumulative
            # harmful evidence weight (since last reaffirmation) exceeds a
            # type-dependent threshold, demote user -> promoted (not none).
            # Stronger evidence contributes more toward demotion.
            if is_user_locked and outcome == "harmful":
                demotion_threshold: float = _USER_LOCK_DEMOTION_THRESHOLDS.get(
                    belief_type, 15.0
                )
                # Cumulative harmful weight = current beta - beta at baseline.
                # Baseline resets on reaffirmation ("used" feedback).
                # If never reaffirmed, baseline is the beta recorded at the
                # first confidence_history entry (belief creation).
                last_used_row: sqlite3.Row | None = self._conn.execute(
                    "SELECT beta_param FROM confidence_history "
                    "WHERE belief_id = ? AND event_type = 'feedback_used' "
                    "ORDER BY created_at DESC LIMIT 1",
                    (belief_id,),
                ).fetchone()
                if last_used_row:
                    beta_baseline: float = float(last_used_row["beta_param"])
                else:
                    # Never reaffirmed: baseline is beta before any feedback.
                    # old_beta before this call minus all accumulated harmful
                    # = the original beta_param at belief creation.
                    # We approximate by subtracting all harmful history from
                    # current beta, but simpler: just use old_beta before
                    # the first harmful signal ever applied.
                    first_harmful: sqlite3.Row | None = self._conn.execute(
                        "SELECT beta_param FROM confidence_history "
                        "WHERE belief_id = ? AND event_type = 'feedback_harmful' "
                        "ORDER BY created_at ASC LIMIT 1",
                        (belief_id,),
                    ).fetchone()
                    if first_harmful:
                        # Beta recorded AFTER first harmful = original + first weight.
                        # We need the beta BEFORE that, which we can get from
                        # the locked event or estimate as initial prior.
                        locked_row: sqlite3.Row | None = self._conn.execute(
                            "SELECT beta_param FROM confidence_history "
                            "WHERE belief_id = ? AND event_type = 'locked' "
                            "ORDER BY created_at DESC LIMIT 1",
                            (belief_id,),
                        ).fetchone()
                        beta_baseline = (
                            float(locked_row["beta_param"]) if locked_row else 0.5
                        )
                    else:
                        beta_baseline = old_beta  # No harmful history yet
                cumulative_harmful: float = beta - beta_baseline
                if cumulative_harmful >= demotion_threshold:
                    self._conn.execute(
                        "UPDATE beliefs SET lock_level = 'promoted', updated_at = ? "
                        "WHERE id = ? AND lock_level = 'user'",
                        (ts, belief_id),
                    )
                    self._record_confidence(
                        belief_id, alpha, beta, "user_demoted_to_promoted"
                    )

            self._conn.commit()

        # Propagate feedback to edges that led to this belief
        traversed: list[tuple[int, int]] | None = self._last_traversed_edges.get(
            belief_id
        )
        if traversed:
            self.propagate_feedback_to_edges(belief_id, outcome, traversed)

        # TB-15: detect significant confidence drop
        old_conf: float = (
            old_alpha / (old_alpha + old_beta) if (old_alpha + old_beta) > 0 else 0.5
        )
        new_conf: float = alpha / (alpha + beta) if (alpha + beta) > 0 else 0.5
        crossed_below: bool = old_conf >= 0.5 and new_conf < 0.5
        if crossed_below and not is_locked:
            self.flag_for_reclassification(belief_id, reason="confidence_drop")
        return crossed_below

    def get_reclassifiable(self, limit: int = 200) -> list[dict[str, str]]:
        """Return unlocked, offline-classified beliefs eligible for LLM reclassification."""
        rows: list[dict[str, str]] = []
        cursor = self._conn.execute(
            """SELECT id, content, belief_type, source_type
               FROM beliefs
               WHERE locked = 0
                 AND superseded_by IS NULL
                 AND valid_to IS NULL
                 AND classified_by = 'offline'
               ORDER BY created_at DESC
               LIMIT ?""",
            (limit,),
        )
        for row in cursor:
            rows.append(
                {
                    "id": row["id"],
                    "content": row["content"],
                    "type": row["belief_type"],
                    "source": row["source_type"],
                }
            )
        return rows

    def update_belief_classification(
        self,
        belief_id: str,
        belief_type: str,
        alpha: float,
        beta_param: float,
    ) -> None:
        """Update a belief's type and priors (for reclassification).

        Also sets classified_by='llm' to mark the belief as LLM-classified.
        """
        ts: str = _now()
        self._conn.execute(
            """UPDATE beliefs SET belief_type = ?, alpha = ?, beta_param = ?,
               classified_by = 'llm', updated_at = ? WHERE id = ?""",
            (belief_type, alpha, beta_param, ts, belief_id),
        )
        self._conn.commit()

    def soft_delete_belief(self, belief_id: str) -> None:
        """Soft-delete a belief by setting valid_to."""
        ts: str = _now()
        self._conn.execute(
            "UPDATE beliefs SET valid_to = ?, updated_at = ? WHERE id = ?",
            (ts, ts, belief_id),
        )
        self._conn.commit()

    def update_belief_content(
        self,
        belief_id: str,
        new_content: str,
        new_content_hash: str,
    ) -> None:
        """Update a belief's content and content_hash (for Obsidian import)."""
        ts: str = _now()
        self._conn.execute(
            """UPDATE beliefs
               SET content = ?, content_hash = ?, updated_at = ?
               WHERE id = ?""",
            (new_content, new_content_hash, ts, belief_id),
        )
        # Update FTS5 index
        self._conn.execute("DELETE FROM search_index WHERE id = ?", (belief_id,))
        belief: Belief | None = self.get_belief(belief_id)
        if belief is not None:
            self._conn.execute(
                "INSERT INTO search_index (id, content, type) VALUES (?, ?, ?)",
                (belief_id, new_content, belief.belief_type),
            )
        self._conn.commit()

    # --- Edges ---

    def insert_edge(
        self,
        from_id: str,
        to_id: str,
        edge_type: str,
        weight: float = 1.0,
        reason: str = "",
        alpha: float = 1.0,
        beta_param: float = 1.0,
    ) -> int:
        """Insert a directed edge between two beliefs. Returns the new edge row ID."""
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            """INSERT INTO edges (from_id, to_id, edge_type, weight, reason,
               created_at, alpha, beta_param)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (from_id, to_id, edge_type, weight, reason, ts, alpha, beta_param),
        )
        self._maybe_commit()
        row_id: int | None = cursor.lastrowid
        if row_id is None:
            raise RuntimeError("Edge insert did not return a rowid")
        return row_id

    def build_temporal_backbone(
        self,
        gap_minutes: float = 30.0,
    ) -> int:
        """Create TEMPORAL_NEXT edges between consecutive beliefs per inferred session.

        Infers sessions from timestamp gaps: a gap > gap_minutes between
        consecutive beliefs (sorted by created_at) marks a session boundary.
        Within each inferred session, creates a TEMPORAL_NEXT edge from each
        belief to the next.

        Idempotent: skips pairs that already have a TEMPORAL_NEXT edge.

        Returns the number of new edges created.
        """
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT id, created_at FROM beliefs "
            "WHERE valid_to IS NULL AND superseded_by IS NULL "
            "ORDER BY created_at ASC"
        ).fetchall()

        if len(rows) < 2:
            return 0

        # Parse timestamps and infer session boundaries
        created: int = 0
        prev_id: str = rows[0]["id"]
        prev_ts: str = rows[0]["created_at"]

        for i in range(1, len(rows)):
            curr_id: str = rows[i]["id"]
            curr_ts: str = rows[i]["created_at"]

            # Check gap between consecutive beliefs
            gap_sec: float = _timestamp_gap_seconds(prev_ts, curr_ts)
            if gap_sec <= gap_minutes * 60:
                # Same session -- create temporal edge if not exists
                exists: sqlite3.Row | None = self._conn.execute(
                    "SELECT 1 FROM edges WHERE from_id = ? AND to_id = ? "
                    "AND edge_type = 'TEMPORAL_NEXT'",
                    (prev_id, curr_id),
                ).fetchone()
                if exists is None:
                    self._conn.execute(
                        "INSERT INTO edges "
                        "(from_id, to_id, edge_type, weight, reason, "
                        "created_at, alpha, beta_param) "
                        "VALUES (?, ?, 'TEMPORAL_NEXT', 0.8, "
                        "'temporal_sequence', ?, 1.0, 1.0)",
                        (prev_id, curr_id, _now()),
                    )
                    created += 1

            prev_id = curr_id
            prev_ts = curr_ts

        if created > 0:
            self._conn.commit()
        return created

    def link_temporal(self, belief_id: str, session_id: str | None) -> int:
        """Link a new belief to its temporal predecessor in the same session.

        Finds the most recent belief with the same session_id (or within
        30min if session_id is None) and creates a TEMPORAL_NEXT edge.

        Returns 1 if an edge was created, 0 otherwise.
        """
        if session_id:
            # Find the most recent belief in this session before this one
            prev_row: sqlite3.Row | None = self._conn.execute(
                "SELECT id FROM beliefs "
                "WHERE session_id = ? AND id != ? "
                "AND valid_to IS NULL "
                "ORDER BY created_at DESC LIMIT 1",
                (session_id, belief_id),
            ).fetchone()
        else:
            # Fallback: find the most recent belief within 30min
            curr_row: sqlite3.Row | None = self._conn.execute(
                "SELECT created_at FROM beliefs WHERE id = ?",
                (belief_id,),
            ).fetchone()
            if curr_row is None:
                return 0
            prev_row = self._conn.execute(
                "SELECT id, created_at FROM beliefs "
                "WHERE id != ? AND valid_to IS NULL "
                "ORDER BY created_at DESC LIMIT 1",
                (belief_id,),
            ).fetchone()
            if prev_row is not None:
                gap: float = _timestamp_gap_seconds(
                    prev_row["created_at"], curr_row["created_at"]
                )
                if gap > 30.0 * 60:
                    return 0

        if prev_row is None:
            return 0

        # Check not already linked
        exists: sqlite3.Row | None = self._conn.execute(
            "SELECT 1 FROM edges WHERE from_id = ? AND to_id = ? "
            "AND edge_type = 'TEMPORAL_NEXT'",
            (prev_row["id"], belief_id),
        ).fetchone()
        if exists is not None:
            return 0

        self._conn.execute(
            "INSERT INTO edges "
            "(from_id, to_id, edge_type, weight, reason, "
            "created_at, alpha, beta_param) "
            "VALUES (?, ?, 'TEMPORAL_NEXT', 0.8, "
            "'temporal_sequence', ?, 1.0, 1.0)",
            (prev_row["id"], belief_id, _now()),
        )
        self._conn.commit()
        return 1

    def edge_exists(self, id_a: str, id_b: str) -> bool:
        """Check if any edge exists between two beliefs (either direction)."""
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT 1 FROM edges WHERE "
            "(from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)",
            (id_a, id_b, id_b, id_a),
        ).fetchone()
        return row is not None

    def get_neighbors(
        self,
        belief_id: str,
        edge_types: list[str] | None = None,
        direction: str = "both",
    ) -> list[tuple[Belief, Edge]]:
        """Get beliefs connected to belief_id via edges.

        Args:
            belief_id: The belief to find neighbors of.
            edge_types: If provided, only return edges of these types.
            direction: "outgoing" (from_id=belief_id), "incoming" (to_id=belief_id),
                       or "both".

        Returns list of (neighbor_belief, connecting_edge) pairs.
        Excludes superseded beliefs (valid_to IS NOT NULL).
        """
        results: list[tuple[Belief, Edge]] = []
        directions: list[tuple[str, str]] = []
        if direction in ("outgoing", "both"):
            directions.append(("from_id", "to_id"))
        if direction in ("incoming", "both"):
            directions.append(("to_id", "from_id"))

        for match_col, neighbor_col in directions:
            sql: str = (
                f"SELECT e.id AS eid, e.from_id, e.to_id, e.edge_type, "
                f"e.weight, e.reason, e.created_at AS ecreated, "
                f"e.alpha AS ealpha, e.beta_param AS ebeta, "
                f"e.traversal_count AS etrav, e.last_traversed_at AS elast, "
                f"e.pruned_at AS epruned, "
                f"b.* FROM edges e "
                f"JOIN beliefs b ON b.id = e.{neighbor_col} "
                f"WHERE e.{match_col} = ? AND b.valid_to IS NULL "
                f"AND e.pruned_at IS NULL"
            )
            params: list[object] = [belief_id]
            if edge_types:
                placeholders: str = ", ".join("?" for _ in edge_types)
                sql += f" AND e.edge_type IN ({placeholders})"
                params.extend(edge_types)
            sql += " ORDER BY e.weight DESC, e.created_at ASC"

            rows: list[sqlite3.Row] = self._conn.execute(sql, tuple(params)).fetchall()
            for row in rows:
                belief: Belief = row_to_belief(row)
                edge: Edge = Edge(
                    id=row["eid"],
                    from_id=row["from_id"],
                    to_id=row["to_id"],
                    edge_type=row["edge_type"],
                    weight=row["weight"],
                    reason=row["reason"],
                    created_at=row["ecreated"],
                    alpha=float(str(row["ealpha"]))
                    if row["ealpha"] is not None
                    else 1.0,
                    beta_param=float(str(row["ebeta"]))
                    if row["ebeta"] is not None
                    else 1.0,
                    traversal_count=int(str(row["etrav"]))
                    if row["etrav"] is not None
                    else 0,
                    last_traversed_at=str(row["elast"]) if row["elast"] else None,
                    pruned_at=str(row["epruned"]) if row["epruned"] else None,
                )
                results.append((belief, edge))

        return results

    # Edge-type traversal weights for BFS expansion. Semantic edges are
    # preferred over structural edges during graph traversal. The stored
    # edge.weight is multiplied by this type weight to produce the
    # effective priority. Default for unlisted types is 0.5.
    _EDGE_TYPE_WEIGHTS: dict[str, float] = {
        # Semantic edges (high priority)
        "CONTRADICTS": 2.0,
        "SUPPORTS": 1.8,
        "IMPLEMENTS": 1.5,
        "TESTS": 1.5,
        "CALLS": 1.3,
        "CITES": 1.3,
        # Structural edges (lower priority)
        "CO_CHANGED": 0.8,
        "TEMPORAL_NEXT": 0.6,
        "COMMIT_TOUCHES": 0.4,
        "CONTAINS": 0.3,
        "SENTENCE_IN_FILE": 0.2,
        "WITHIN_SECTION": 0.2,
    }

    def expand_graph(
        self,
        seed_ids: list[str],
        depth: int = 2,
        edge_types: list[str] | None = None,
        max_nodes: int = 50,
    ) -> dict[str, list[tuple[Belief, str, int]]]:
        """BFS expansion from seed beliefs along edges.

        Args:
            seed_ids: Starting belief IDs.
            depth: Maximum number of hops (1, 2, or 3).
            edge_types: If provided, only traverse these edge types.
                        SUPERSEDES edges are always excluded.
            max_nodes: Cap on total expanded nodes to prevent blowup.

        Returns dict mapping belief_id to list of
        (neighbor_belief, edge_type, hop_distance) tuples.

        Side effects: records edge traversals (traversal_count, last_traversed_at)
        and stores traversal log in _last_traversed_edges for feedback propagation.
        """
        from collections import deque

        # Exclude SUPERSEDES edges (point to dead beliefs)
        excluded: frozenset[str] = frozenset({"SUPERSEDES"})
        effective_types: list[str] | None = None
        if edge_types is not None:
            effective_types = [t for t in edge_types if t not in excluded]

        visited: set[str] = set(seed_ids)
        result: dict[str, list[tuple[Belief, str, int]]] = {}
        queue: deque[tuple[str, int]] = deque()
        # Track which edges led to which beliefs for feedback propagation
        traversal_log: dict[str, list[tuple[int, int]]] = {}

        for sid in seed_ids:
            queue.append((sid, 0))

        total_expanded: int = 0

        while queue and total_expanded < max_nodes:
            current_id, current_depth = queue.popleft()
            if current_depth >= depth:
                continue

            neighbors: list[tuple[Belief, Edge]] = self.get_neighbors(
                current_id,
                edge_types=effective_types,
                direction="both",
            )

            # Thompson Sampling: sample from Beta(alpha, beta) per edge.
            # Edges at default prior (1,1) have high variance = exploration.
            # Well-scored edges have low variance = exploitation.
            # This naturally balances explore/exploit without a tuning parameter.
            def _edge_priority(pair: tuple[Belief, Edge]) -> tuple[float, str]:
                _, e = pair
                type_w: float = self._EDGE_TYPE_WEIGHTS.get(e.edge_type, 0.5)
                sample: float = random.betavariate(e.alpha, e.beta_param)
                return (-sample * type_w, e.created_at)

            neighbors.sort(key=_edge_priority)

            for neighbor_belief, edge in neighbors:
                if edge_types is None and edge.edge_type in excluded:
                    continue

                if neighbor_belief.id in visited:
                    continue
                if total_expanded >= max_nodes:
                    break

                visited.add(neighbor_belief.id)
                hop: int = current_depth + 1

                # Record traversal
                self.record_edge_traversal(edge.id)

                # Log edge for feedback propagation
                if neighbor_belief.id not in traversal_log:
                    traversal_log[neighbor_belief.id] = []
                traversal_log[neighbor_belief.id].append((edge.id, hop))

                if neighbor_belief.id not in result:
                    result[neighbor_belief.id] = []
                result[neighbor_belief.id].append(
                    (neighbor_belief, edge.edge_type, hop)
                )

                queue.append((neighbor_belief.id, hop))
                total_expanded += 1

        # Commit traversal updates
        if total_expanded > 0 and not self.readonly:
            self._conn.commit()

        # Store traversal log for feedback propagation
        self._last_traversed_edges = traversal_log

        return result

    # --- Consequence path extraction (for /mem:reason) ---

    # Edge types that represent consequence/support relationships.
    # CONTRADICTS creates forks (branching paths).
    _CONSEQUENCE_EDGE_TYPES: frozenset[str] = frozenset(
        {
            "SUPPORTS",
            "IMPLEMENTS",
            "TESTS",
            "CITES",
            "CONTRADICTS",
            "RELATES_TO",
            "CALLS",
        }
    )

    def find_consequence_paths(
        self,
        root_ids: list[str],
        max_depth: int = 3,
        confidence_floor: float = 0.3,
        max_branches: int = 20,
    ) -> list[list[tuple[Belief, str, float]]]:
        """Walk typed edges as consequence paths with compound confidence decay.

        Each returned path is a list of (belief, edge_type, compound_confidence)
        tuples. The first entry in each path is the root belief with compound
        confidence equal to its own confidence.

        Stops expanding when compound confidence drops below confidence_floor.
        Forks into separate paths at CONTRADICTS edges.

        Args:
            root_ids: Starting belief IDs (the "what if" anchors).
            max_depth: Maximum hops per path.
            confidence_floor: Prune branches below this compound confidence.
            max_branches: Cap on total paths to bound output size.

        Returns list of paths. Each path is ordered root-to-leaf.
        """
        paths: list[list[tuple[Belief, str, float]]] = []

        # Load root beliefs
        root_beliefs: dict[str, Belief] = {}
        for rid in root_ids:
            rows: list[sqlite3.Row] = self._conn.execute(
                "SELECT * FROM beliefs WHERE id = ? AND valid_to IS NULL",
                (rid,),
            ).fetchall()
            if rows:
                root_beliefs[rid] = row_to_belief(rows[0])

        if not root_beliefs:
            return paths

        # DFS with path tracking
        # Stack entries: (current_belief, edge_type_to_here, compound_conf, path_so_far, visited)
        stack: list[
            tuple[Belief, str, float, list[tuple[Belief, str, float]], set[str]]
        ] = []

        for rid, rb in root_beliefs.items():
            root_conf: float = rb.confidence
            initial_path: list[tuple[Belief, str, float]] = [(rb, "ROOT", root_conf)]
            stack.append((rb, "ROOT", root_conf, initial_path, {rid}))

        while stack and len(paths) < max_branches:
            current, _etype, compound_conf, path_so_far, visited = stack.pop()

            if len(path_so_far) > max_depth:
                # Reached depth limit -- emit path as-is
                if len(path_so_far) > 1:
                    paths.append(list(path_so_far))
                continue

            neighbors: list[tuple[Belief, Edge]] = self.get_neighbors(
                current.id,
                edge_types=list(self._CONSEQUENCE_EDGE_TYPES),
                direction="both",
            )

            # Filter to unvisited, non-superseded neighbors
            valid_neighbors: list[tuple[Belief, Edge]] = [
                (nb, e)
                for nb, e in neighbors
                if nb.id not in visited and nb.valid_to is None
            ]

            if not valid_neighbors:
                # Leaf node -- emit path
                if len(path_so_far) > 1:
                    paths.append(list(path_so_far))
                continue

            # Sort: CONTRADICTS first (create forks), then by edge confidence
            def _sort_key(pair: tuple[Belief, Edge]) -> tuple[int, float]:
                _, e = pair
                is_contradict: int = 0 if e.edge_type == "CONTRADICTS" else 1
                type_w: float = self._EDGE_TYPE_WEIGHTS.get(e.edge_type, 0.5)
                e_conf: float = e.alpha / (e.alpha + e.beta_param)
                return (is_contradict, -(e_conf * type_w))

            valid_neighbors.sort(key=_sort_key)

            expanded_any: bool = False
            for nb, edge in valid_neighbors:
                if len(paths) >= max_branches:
                    break

                # Compound confidence = parent * child belief confidence * edge confidence
                edge_conf: float = edge.alpha / (edge.alpha + edge.beta_param)
                child_conf: float = compound_conf * nb.confidence * edge_conf
                child_conf = min(child_conf, 1.0)

                if child_conf < confidence_floor:
                    continue  # Pruned -- speculation becomes noise

                new_visited: set[str] = visited | {nb.id}
                new_step: tuple[Belief, str, float] = (nb, edge.edge_type, child_conf)

                if edge.edge_type == "CONTRADICTS":
                    # Fork: start a new branch from the root up to current,
                    # then diverge to the contradicting belief
                    fork_path: list[tuple[Belief, str, float]] = list(path_so_far) + [
                        new_step
                    ]
                    stack.append(
                        (nb, edge.edge_type, child_conf, fork_path, new_visited)
                    )
                else:
                    # Continue the current path
                    continued_path: list[tuple[Belief, str, float]] = list(
                        path_so_far
                    ) + [new_step]
                    stack.append(
                        (nb, edge.edge_type, child_conf, continued_path, new_visited)
                    )

                expanded_any = True

            if not expanded_any and len(path_so_far) > 1:
                # All children pruned -- emit current path
                paths.append(list(path_so_far))

        # Sort paths: longest first, then by leaf compound confidence desc
        paths.sort(key=lambda p: (-len(p), -p[-1][2] if p else 0.0))

        return paths

    @dataclass
    class Impasse:
        """A reasoning impasse detected in the belief graph."""

        impasse_type: str  # "tie", "gap", "constraint_failure", "no_change"
        description: str
        beliefs: list[str]  # Belief IDs involved
        severity: float  # 0.0 to 1.0

    def detect_impasses(
        self,
        beliefs: dict[str, Belief],
        paths: list[list[tuple[Belief, str, float]]],
        locked_beliefs: list[Belief] | None = None,
    ) -> list[Impasse]:
        """Detect reasoning impasses in retrieved evidence.

        Identifies four impasse types:
        - tie: Two contradicting beliefs with similar confidence (no clear winner)
        - gap: Path ends at a dead-end where connections would be expected
        - constraint_failure: Retrieved evidence conflicts with a locked belief
        - no_change: All retrieved beliefs have low confidence (no actionable evidence)

        Args:
            beliefs: All retrieved beliefs keyed by ID.
            paths: Consequence paths from find_consequence_paths().
            locked_beliefs: Locked beliefs to check for constraint failures.

        Returns list of Impasse objects sorted by severity desc.
        """
        from agentmemory.scoring import uncertainty_score

        impasses: list[MemoryStore.Impasse] = []

        # 1. Tie impasses: contradicting beliefs with similar confidence
        checked_pairs: set[tuple[str, str]] = set()
        for bid in beliefs:
            neighbors: list[tuple[Belief, Edge]] = self.get_neighbors(
                bid,
                edge_types=["CONTRADICTS"],
                direction="both",
            )
            for nb, _edge in neighbors:
                if nb.id not in beliefs:
                    continue
                pair_key: tuple[str, str] = (min(bid, nb.id), max(bid, nb.id))
                if pair_key in checked_pairs:
                    continue
                checked_pairs.add(pair_key)

                b1: Belief = beliefs[bid]
                b2: Belief = nb
                conf_diff: float = abs(b1.confidence - b2.confidence)
                if conf_diff < 0.2:
                    # Similar confidence -- genuine tie
                    severity: float = 1.0 - conf_diff  # closer = more severe
                    impasses.append(
                        MemoryStore.Impasse(
                            impasse_type="tie",
                            description=(
                                f"Contradicting beliefs with similar confidence "
                                f"({b1.confidence:.0%} vs {b2.confidence:.0%}): "
                                f'"{b1.content[:60]}..." vs "{b2.content[:60]}..."'
                            ),
                            beliefs=[bid, nb.id],
                            severity=severity,
                        )
                    )

        # 2. Gap impasses: paths that terminate with high uncertainty at the leaf
        for path in paths:
            if not path:
                continue
            leaf_belief, _etype, compound_conf = path[-1]
            leaf_unc: float = uncertainty_score(
                leaf_belief.alpha, leaf_belief.beta_param
            )
            if leaf_unc > 0.7 and len(path) >= 2:
                impasses.append(
                    MemoryStore.Impasse(
                        impasse_type="gap",
                        description=(
                            f"Path ends at high-uncertainty belief "
                            f"(uncertainty={leaf_unc:.2f}, compound_conf={compound_conf:.2f}): "
                            f'"{leaf_belief.content[:80]}..."'
                        ),
                        beliefs=[leaf_belief.id],
                        severity=leaf_unc,
                    )
                )

        # 3. Constraint failures: evidence contradicts a locked belief
        if locked_beliefs:
            locked_ids: set[str] = {lb.id for lb in locked_beliefs}
            for bid in beliefs:
                neighbors = self.get_neighbors(
                    bid,
                    edge_types=["CONTRADICTS"],
                    direction="both",
                )
                for nb, _edge in neighbors:
                    if nb.id in locked_ids:
                        impasses.append(
                            MemoryStore.Impasse(
                                impasse_type="constraint_failure",
                                description=(
                                    f"Evidence contradicts LOCKED belief: "
                                    f'"{beliefs[bid].content[:60]}..." '
                                    f'CONTRADICTS locked "{nb.content[:60]}..."'
                                ),
                                beliefs=[bid, nb.id],
                                severity=1.0,  # Always high -- locked beliefs are constraints
                            )
                        )

        # 4. No-change impasses: all beliefs have low confidence
        if beliefs:
            avg_conf: float = sum(b.confidence for b in beliefs.values()) / len(beliefs)
            high_conf_count: int = sum(
                1 for b in beliefs.values() if b.confidence > 0.7
            )
            if avg_conf < 0.5 and high_conf_count == 0:
                impasses.append(
                    MemoryStore.Impasse(
                        impasse_type="no_change",
                        description=(
                            f"No high-confidence evidence found. "
                            f"Average confidence: {avg_conf:.0%}, "
                            f"beliefs with >70% confidence: 0/{len(beliefs)}"
                        ),
                        beliefs=list(beliefs.keys())[:5],
                        severity=0.8,
                    )
                )

        # Sort by severity descending
        impasses.sort(key=lambda imp: -imp.severity)
        return impasses

    # --- HRR graph ---

    def insert_graph_edge(
        self,
        from_id: str,
        to_id: str,
        edge_type: str,
        weight: float = 1.0,
        reason: str = "",
    ) -> int:
        """Insert a structural graph edge (no FK constraints). For scanner/HRR use."""
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            """INSERT INTO graph_edges (from_id, to_id, edge_type, weight, reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (from_id, to_id, edge_type, weight, reason, ts),
        )
        self._maybe_commit()
        row_id: int | None = cursor.lastrowid
        if row_id is None:
            raise RuntimeError("graph_edge insert did not return a rowid")
        return row_id

    def batch_insert_graph_edges(
        self,
        edges: list[tuple[str, str, str, float, str]],
    ) -> int:
        """Bulk-insert structural graph edges in a single transaction.

        Each tuple is (from_id, to_id, edge_type, weight, reason).
        Returns the number of edges inserted.
        """
        if not edges:
            return 0
        ts: str = _now()
        rows = [(f, t, et, w, r, ts) for f, t, et, w, r in edges]
        self._conn.executemany(
            """INSERT INTO graph_edges (from_id, to_id, edge_type, weight, reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            rows,
        )
        self._conn.commit()
        return len(rows)

    def get_all_edge_triples(self) -> list[tuple[str, str, str]]:
        """Return all edges (belief + graph) as triples for HRR encoding."""
        triples: list[tuple[str, str, str]] = []
        # Belief edges (SUPERSEDES, etc.)
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT from_id, to_id, edge_type FROM edges"
        ).fetchall()
        triples.extend(
            (str(r["from_id"]), str(r["to_id"]), str(r["edge_type"])) for r in rows
        )
        # Graph edges (CITES, CALLS, CONTAINS, etc.)
        g_rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT from_id, to_id, edge_type FROM graph_edges"
        ).fetchall()
        triples.extend(
            (str(r["from_id"]), str(r["to_id"]), str(r["edge_type"])) for r in g_rows
        )
        return triples

    # --- Search ---

    @staticmethod
    def _sanitize_fts5_query(query: str) -> str:
        """Sanitize a query for FTS5 MATCH.

        FTS5 treats hyphens as NOT, quotes as phrase delimiters, etc.
        Split into words, quote each term, join with OR for broad matching.
        """
        import re

        # Strip FTS5 operators and punctuation, keep alphanumeric and spaces
        words: list[str] = re.findall(r"[a-zA-Z0-9]+", query)
        if not words:
            return '""'
        # Quote each term and join with OR for broad matching
        quoted: list[str] = [f'"{w}"' for w in words]
        return " OR ".join(quoted)

    def search(
        self,
        query: str,
        top_k: int = 30,
        record_last_retrieved: bool = True,
    ) -> list[Belief]:
        """FTS5 BM25 search on beliefs. Excludes superseded (valid_to IS NOT NULL).

        When record_last_retrieved is False, the search stays read-only and
        skips the last_retrieved_at update/commit bookkeeping.
        """
        safe_query: str = self._sanitize_fts5_query(query)
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT id, content, type, bm25(search_index) AS score
               FROM search_index
               WHERE search_index MATCH ? AND type = 'belief'
               ORDER BY bm25(search_index)
               LIMIT ?""",
            (safe_query, top_k),
        ).fetchall()

        if not rows:
            return []

        # Batch lookup: single query instead of N+1 individual fetches.
        ids: list[str] = [r["id"] for r in rows]
        placeholders: str = ",".join("?" for _ in ids)
        belief_rows: list[sqlite3.Row] = self._conn.execute(
            f"SELECT * FROM beliefs WHERE id IN ({placeholders}) AND valid_to IS NULL",
            ids,
        ).fetchall()

        # Preserve FTS5 BM25 rank order.
        by_id: dict[str, sqlite3.Row] = {r["id"]: r for r in belief_rows}
        beliefs: list[Belief] = []
        for r in rows:
            row: sqlite3.Row | None = by_id.get(r["id"])
            if row is not None:
                beliefs.append(row_to_belief(row))

        # Update last_retrieved_at for all returned beliefs (skip in readonly mode
        # or when callers need a read-only retrieval path).
        if beliefs and not self.readonly and record_last_retrieved:
            now: str = _now()
            returned_ids: list[str] = [b.id for b in beliefs]
            ph: str = ",".join("?" for _ in returned_ids)
            self._conn.execute(
                f"UPDATE beliefs SET last_retrieved_at = ? WHERE id IN ({ph})",
                [now, *returned_ids],
            )
            self._conn.commit()

        return beliefs

    def search_observations(self, query: str, top_k: int = 15) -> list[Observation]:
        """FTS5 BM25 search on observations."""
        safe_query: str = self._sanitize_fts5_query(query)
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT id, content, type, bm25(search_index) AS score
               FROM search_index
               WHERE search_index MATCH ? AND type = 'observation'
               ORDER BY bm25(search_index)
               LIMIT ?""",
            (safe_query, top_k),
        ).fetchall()

        observations: list[Observation] = []
        for r in rows:
            obs: sqlite3.Row | None = self._conn.execute(
                "SELECT * FROM observations WHERE id = ?",
                (r["id"],),
            ).fetchone()
            if obs is not None:
                observations.append(_row_to_observation(obs))
        return observations

    def get_observation(self, observation_id: str) -> Observation | None:
        """Get a single observation by ID."""
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT * FROM observations WHERE id = ?", (observation_id,)
        ).fetchone()
        if row is None:
            return None
        return _row_to_observation(row)

    def get_locked_beliefs(self) -> list[Belief]:
        """Return all locked beliefs (for L0 context injection).

        Populates demotion_pressure with CONTRADICTS edge count per belief
        so callers can surface stale locks for user review (GH-17).
        """
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT * FROM beliefs WHERE locked = 1 AND valid_to IS NULL"
        ).fetchall()
        beliefs: list[Belief] = [row_to_belief(r) for r in rows]
        if not beliefs:
            return beliefs
        # Batch-query CONTRADICTS edge counts
        ids: list[str] = [b.id for b in beliefs]
        ph: str = ",".join("?" for _ in ids)
        contra_rows: list[sqlite3.Row] = self._conn.execute(
            f"SELECT to_id, COUNT(*) as cnt FROM edges "
            f"WHERE edge_type = 'CONTRADICTS' AND to_id IN ({ph}) "
            f"AND pruned_at IS NULL GROUP BY to_id",
            ids,
        ).fetchall()
        contra_map: dict[str, int] = {
            str(r["to_id"]): int(r["cnt"]) for r in contra_rows
        }
        for b in beliefs:
            b.demotion_pressure = contra_map.get(b.id, 0)
        return beliefs

    def set_compliance_check(self, belief_id: str, check: str) -> None:
        """Set a compliance_check predicate on a belief.

        The check is stored in the activation_condition field with a
        'compliance:' prefix to distinguish from activation conditions.
        """
        self._conn.execute(
            """UPDATE beliefs SET activation_condition =
               CASE
                 WHEN activation_condition IS NULL THEN ?
                 ELSE activation_condition || '|' || ?
               END
               WHERE id = ?""",
            (f"compliance:{check}", f"compliance:{check}", belief_id),
        )
        self._conn.commit()

    def get_compliance_check(self, belief_id: str) -> str | None:
        """Get the compliance_check predicate for a belief, if any."""
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT activation_condition FROM beliefs WHERE id = ?",
            (belief_id,),
        ).fetchone()
        if row is None or row[0] is None:
            return None
        ac: str = row[0]
        # Extract compliance prefix
        for part in ac.split("|"):
            if part.startswith("compliance:"):
                return part[len("compliance:") :]
        return None

    def get_test_results(self, belief_id: str) -> list[dict[str, Any]]:
        """Get all test results for a belief."""
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT * FROM tests WHERE belief_id = ? ORDER BY created_at",
            (belief_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_beliefs_by_type(self, belief_type: str) -> list[Belief]:
        """Return all active beliefs of a given type."""
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT * FROM beliefs WHERE belief_type = ? AND valid_to IS NULL",
            (belief_type,),
        ).fetchall()
        return [row_to_belief(r) for r in rows]

    def set_temporal_direction(self, belief_id: str, direction: str) -> None:
        """Set temporal_direction on a belief."""
        self._conn.execute(
            "UPDATE beliefs SET temporal_direction = ? WHERE id = ?",
            (direction, belief_id),
        )
        self._conn.commit()

    def flag_for_reclassification(self, belief_id: str, reason: str) -> None:
        """Flag a belief for reclassification. Skips locked beliefs."""
        self._conn.execute(
            "UPDATE beliefs SET needs_reclassification = 1 WHERE id = ? AND locked = 0",
            (belief_id,),
        )
        self._conn.commit()

    def clear_reclassification_flag(self, belief_id: str) -> None:
        """Clear the reclassification flag after processing."""
        self._conn.execute(
            "UPDATE beliefs SET needs_reclassification = 0 WHERE id = ?",
            (belief_id,),
        )
        self._conn.commit()

    def get_beliefs_needing_reclassification(self) -> list[str]:
        """Return IDs of beliefs flagged for reclassification."""
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT id FROM beliefs "
            "WHERE needs_reclassification = 1 AND valid_to IS NULL"
        ).fetchall()
        return [str(r["id"]) for r in rows]

    def get_behavioral_beliefs(self, limit: int = 10) -> list[Belief]:
        """Return high-confidence unlocked behavioral beliefs (L1 layer).

        Behavioral beliefs are procedural constraints that should be in context
        regardless of query. Identified by: source_type='directive', OR
        high-confidence requirement/procedural beliefs with behavioral keywords.
        Locked beliefs are already in L0; this returns unlocked ones.
        """
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT * FROM beliefs
               WHERE locked = 0
                 AND valid_to IS NULL
                 AND superseded_by IS NULL
                 AND (
                   source_type = 'directive'
                   OR (
                     belief_type IN ('requirement', 'procedural')
                     AND confidence >= 0.8
                     AND (
                       content LIKE '%never %'
                       OR content LIKE '%always %'
                       OR content LIKE '%must not%'
                       OR content LIKE '%do not%'
                       OR content LIKE '%must %'
                     )
                   )
                 )
               ORDER BY confidence DESC
               LIMIT ?""",
            (limit,),
        ).fetchall()
        return [row_to_belief(r) for r in rows]

    def get_belief(self, belief_id: str) -> Belief | None:
        """Get a single belief by ID."""
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT * FROM beliefs WHERE id = ?", (belief_id,)
        ).fetchone()
        if row is None:
            return None
        return row_to_belief(row)

    def get_belief_by_hash(self, content_hash: str) -> Belief | None:
        """Get a belief by content hash. Used to bridge scanner node IDs to belief IDs."""
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT * FROM beliefs WHERE content_hash = ?", (content_hash,)
        ).fetchone()
        if row is None:
            return None
        return row_to_belief(row)

    # --- Sessions ---

    def create_session(
        self,
        model: str | None = None,
        project_context: str | None = None,
    ) -> Session:
        """Create a new session. Incomplete predecessors are left for manual recovery."""
        session_id: str = _new_id()
        ts: str = _now()
        self._conn.execute(
            """INSERT INTO sessions (id, started_at, completed_at, model, project_context, summary)
               VALUES (?, ?, NULL, ?, ?, NULL)""",
            (session_id, ts, model, project_context),
        )
        self._conn.commit()
        return Session(
            id=session_id,
            started_at=ts,
            completed_at=None,
            model=model,
            project_context=project_context,
            summary=None,
        )

    def ensure_session(self, session_id: str) -> None:
        """Create a session row if it does not already exist (idempotent).

        Used by ingest_jsonl to satisfy FK constraints when replaying
        archived conversation logs that reference sessions not yet in the DB.
        """
        existing: sqlite3.Row | None = self._conn.execute(
            "SELECT 1 FROM sessions WHERE id = ?", (session_id,)
        ).fetchone()
        if existing is None:
            ts: str = _now()
            self._conn.execute(
                """INSERT INTO sessions (id, started_at, completed_at, model, project_context, summary)
                   VALUES (?, ?, NULL, NULL, 'jsonl-import', NULL)""",
                (session_id, ts),
            )
            self._conn.commit()

    def checkpoint(
        self,
        session_id: str,
        checkpoint_type: str,
        content: str,
        references: list[str] | None = None,
    ) -> Checkpoint:
        """Write a session checkpoint. Synchronous: committed before return."""
        refs_json: str = json.dumps(references if references is not None else [])
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            """INSERT INTO checkpoints (session_id, checkpoint_type, content, "references", created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (session_id, checkpoint_type, content, refs_json, ts),
        )
        self._conn.commit()
        row_id: int | None = cursor.lastrowid
        if row_id is None:
            raise RuntimeError("Checkpoint insert did not return a rowid")
        return Checkpoint(
            id=row_id,
            session_id=session_id,
            checkpoint_type=checkpoint_type,
            content=content,
            references=refs_json,
            created_at=ts,
        )

    def complete_session(self, session_id: str, summary: str = "") -> None:
        """Mark session as complete with velocity computation."""
        ts: str = _now()
        # Compute velocity from session metrics
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT started_at, beliefs_created, corrections_detected FROM sessions WHERE id = ?",
            (session_id,),
        ).fetchone()
        velocity: float | None = None
        tier: str | None = None
        if row is not None:
            started: str = row["started_at"]
            items: int = int(row["beliefs_created"]) + int(row["corrections_detected"])
            try:
                from datetime import datetime as _dt

                t0: _dt = _dt.fromisoformat(started)
                t1: _dt = _dt.fromisoformat(ts)
                hours: float = max(0.5, (t1 - t0).total_seconds() / 3600.0)
                velocity = items / hours
                if velocity > 10.0:
                    tier = "sprint"
                elif velocity >= 5.0:
                    tier = "moderate"
                elif velocity >= 2.0:
                    tier = "steady"
                else:
                    tier = "deep"
            except (ValueError, TypeError):
                pass
        self._conn.execute(
            """UPDATE sessions SET completed_at = ?, summary = ?,
               velocity_items_per_hour = ?, velocity_tier = ?
               WHERE id = ?""",
            (ts, summary if summary else None, velocity, tier, session_id),
        )
        self._conn.commit()

    def increment_session_metrics(
        self,
        session_id: str,
        retrieval_tokens: int = 0,
        classification_tokens: int = 0,
        beliefs_created: int = 0,
        corrections_detected: int = 0,
        searches_performed: int = 0,
        feedback_given: int = 0,
    ) -> None:
        """Atomically increment session token/correction counters."""
        self._conn.execute(
            """UPDATE sessions SET
                retrieval_tokens = retrieval_tokens + ?,
                classification_tokens = classification_tokens + ?,
                beliefs_created = beliefs_created + ?,
                corrections_detected = corrections_detected + ?,
                searches_performed = searches_performed + ?,
                feedback_given = feedback_given + ?
               WHERE id = ?""",
            (
                retrieval_tokens,
                classification_tokens,
                beliefs_created,
                corrections_detected,
                searches_performed,
                feedback_given,
                session_id,
            ),
        )
        self._conn.commit()

    def get_session(self, session_id: str) -> Session | None:
        """Get a session by ID."""
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT * FROM sessions WHERE id = ?", (session_id,)
        ).fetchone()
        return _row_to_session(row) if row is not None else None

    def find_incomplete_sessions(self) -> list[Session]:
        """Find sessions where completed_at IS NULL (crashed or interrupted)."""
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT * FROM sessions WHERE completed_at IS NULL ORDER BY started_at DESC"
        ).fetchall()
        return [_row_to_session(r) for r in rows]

    def get_session_checkpoints(self, session_id: str) -> list[Checkpoint]:
        """Get all checkpoints for a session ordered by creation time."""
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT * FROM checkpoints WHERE session_id = ? ORDER BY created_at ASC",
            (session_id,),
        ).fetchall()
        return [_row_to_checkpoint(r) for r in rows]

    # --- Temporal queries (Wave 2) ---

    def timeline(
        self,
        topic: str | None = None,
        start: str | None = None,
        end: str | None = None,
        session_id: str | None = None,
        limit: int = 50,
    ) -> list[Belief]:
        """Return beliefs ordered by time, optionally filtered by topic/time/session.

        Uses FTS5 for topic filtering when provided, otherwise pure SQL.
        """
        if topic:
            # FTS5 search with temporal filtering
            safe_topic: str = self._sanitize_fts5_query(topic)
            sql: str = """
                SELECT b.* FROM search_index si
                JOIN beliefs b ON b.id = si.id
                WHERE search_index MATCH ?
                  AND b.valid_to IS NULL
            """
            params: list[object] = [safe_topic]
            if start:
                sql += " AND b.created_at >= ?"
                params.append(start)
            if end:
                sql += " AND b.created_at <= ?"
                params.append(end)
            if session_id:
                sql += (
                    " AND (b.session_id = ?"
                    " OR b.id IN ("
                    "   SELECT e.belief_id FROM evidence e"
                    "   JOIN observations o ON e.observation_id = o.id"
                    "   WHERE o.session_id = ?))"
                )
                params.extend([session_id, session_id])
            sql += " ORDER BY b.created_at ASC LIMIT ?"
            params.append(limit)
        else:
            sql = "SELECT * FROM beliefs WHERE valid_to IS NULL"
            params = []
            if start:
                sql += " AND created_at >= ?"
                params.append(start)
            if end:
                sql += " AND created_at <= ?"
                params.append(end)
            if session_id:
                sql += (
                    " AND (session_id = ?"
                    " OR id IN ("
                    "   SELECT e.belief_id FROM evidence e"
                    "   JOIN observations o ON e.observation_id = o.id"
                    "   WHERE o.session_id = ?))"
                )
                params.extend([session_id, session_id])
            sql += " ORDER BY created_at ASC LIMIT ?"
            params.append(limit)

        rows: list[sqlite3.Row] = self._conn.execute(sql, params).fetchall()
        return [row_to_belief(r) for r in rows]

    def evolution(
        self,
        belief_id: str | None = None,
        topic: str | None = None,
        limit: int = 50,
    ) -> list[Belief]:
        """Trace belief evolution over time.

        If belief_id: follow SUPERSEDES chain in both directions.
        If topic: all beliefs about topic chronologically, marking superseded ones.
        """
        if belief_id:
            # Walk backward to find the root
            chain: list[Belief] = []
            visited: set[str] = set()
            # Walk backward (find what this belief superseded)
            current_id: str | None = belief_id
            backward: list[Belief] = []
            while current_id and current_id not in visited:
                visited.add(current_id)
                row: sqlite3.Row | None = self._conn.execute(
                    "SELECT * FROM beliefs WHERE id = ?", (current_id,)
                ).fetchone()
                if row is None:
                    break
                backward.append(row_to_belief(row))
                # Find what this belief superseded (old belief with superseded_by = current)
                prev: sqlite3.Row | None = self._conn.execute(
                    "SELECT * FROM beliefs WHERE superseded_by = ?", (current_id,)
                ).fetchone()
                current_id = prev["id"] if prev is not None else None
            backward.reverse()
            chain.extend(backward)

            # Walk forward from original belief_id (find what supersedes it)
            current_id = belief_id
            while current_id and current_id not in visited:
                visited.add(current_id)
                row = self._conn.execute(
                    "SELECT * FROM beliefs WHERE id = ?", (current_id,)
                ).fetchone()
                if row is None:
                    break
                b: Belief = row_to_belief(row)
                chain.append(b)
                current_id = b.superseded_by

            return chain[:limit]

        if topic:
            safe_topic: str = self._sanitize_fts5_query(topic)
            rows: list[sqlite3.Row] = self._conn.execute(
                """SELECT b.* FROM search_index si
                   JOIN beliefs b ON b.id = si.id
                   WHERE search_index MATCH ?
                   ORDER BY b.created_at ASC LIMIT ?""",
                (safe_topic, limit),
            ).fetchall()
            return [row_to_belief(r) for r in rows]

        return []

    def diff(
        self,
        since: str,
        until: str | None = None,
    ) -> dict[str, list[Belief]]:
        """Show what changed in the belief store between two timestamps.

        Returns dict with keys: added, removed, evolved.
        """
        end: str = until if until else _now()

        added_rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT * FROM beliefs WHERE created_at >= ? AND created_at <= ? ORDER BY created_at",
            (since, end),
        ).fetchall()

        removed_rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT * FROM beliefs WHERE valid_to >= ? AND valid_to <= ? ORDER BY valid_to",
            (since, end),
        ).fetchall()

        evolved_rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT new.* FROM beliefs old
               JOIN beliefs new ON old.superseded_by = new.id
               WHERE old.valid_to >= ? AND old.valid_to <= ?
               ORDER BY new.created_at""",
            (since, end),
        ).fetchall()

        return {
            "added": [row_to_belief(r) for r in added_rows],
            "removed": [row_to_belief(r) for r in removed_rows],
            "evolved": [row_to_belief(r) for r in evolved_rows],
        }

    def search_at_time(
        self,
        query: str,
        at_time: str,
        top_k: int = 10,
    ) -> list[Belief]:
        """Search for beliefs that were active at a specific point in time.

        Returns beliefs created before at_time that had not been superseded by then.
        """
        safe_query: str = self._sanitize_fts5_query(query)
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT b.* FROM search_index si
               JOIN beliefs b ON b.id = si.id
               WHERE search_index MATCH ?
                 AND b.created_at <= ?
                 AND (b.valid_to IS NULL OR b.valid_to > ?)
               ORDER BY rank
               LIMIT ?""",
            (safe_query, at_time, at_time, top_k),
        ).fetchall()
        return [row_to_belief(r) for r in rows]

    # --- Stats ---

    def status(self) -> dict[str, int]:
        """Return counts: observations, beliefs, locked, superseded, edges, sessions."""

        def count(sql: str) -> int:
            row: sqlite3.Row = self._conn.execute(sql).fetchone()
            val: object = row[0]
            if not isinstance(val, int):
                return 0
            return val

        return {
            "observations": count("SELECT COUNT(*) FROM observations"),
            "beliefs": count("SELECT COUNT(*) FROM beliefs"),
            "locked": count("SELECT COUNT(*) FROM beliefs WHERE locked = 1"),
            "superseded": count(
                "SELECT COUNT(*) FROM beliefs WHERE valid_to IS NOT NULL"
            ),
            "edges": count("SELECT COUNT(*) FROM edges"),
            "sessions": count("SELECT COUNT(*) FROM sessions"),
        }

    def get_status_report(self) -> dict[str, object]:
        """Return a structured status report with four sections.

        Sections:
          inventory -- counts by type, source, locked status
          retrieval -- coverage, scoring features, pending feedback
          activity  -- sessions, observations, age distribution
          maintenance -- stale, orphans, credal gap (actionable items)
        """

        def count(sql: str, params: tuple[object, ...] = ()) -> int:
            row: sqlite3.Row = self._conn.execute(sql, params).fetchone()
            val: object = row[0]
            return val if isinstance(val, int) else 0

        active: int = count("SELECT COUNT(*) FROM beliefs WHERE valid_to IS NULL")
        superseded: int = count(
            "SELECT COUNT(*) FROM beliefs WHERE valid_to IS NOT NULL"
        )
        locked: int = count(
            "SELECT COUNT(*) FROM beliefs WHERE locked = 1 AND valid_to IS NULL"
        )

        # Type distribution
        by_type: dict[str, int] = {}
        for row in self._conn.execute(
            "SELECT belief_type, COUNT(*) FROM beliefs "
            "WHERE valid_to IS NULL GROUP BY belief_type ORDER BY COUNT(*) DESC"
        ).fetchall():
            by_type[str(row[0])] = int(row[1])

        # Source distribution
        by_source: dict[str, int] = {}
        for row in self._conn.execute(
            "SELECT source_type, COUNT(*) FROM beliefs "
            "WHERE valid_to IS NULL GROUP BY source_type ORDER BY COUNT(*) DESC"
        ).fetchall():
            by_source[str(row[0])] = int(row[1])

        # Locked breakdown by type
        locked_by_type: dict[str, int] = {}
        for row in self._conn.execute(
            "SELECT belief_type, COUNT(*) FROM beliefs "
            "WHERE locked = 1 AND valid_to IS NULL "
            "GROUP BY belief_type ORDER BY COUNT(*) DESC"
        ).fetchall():
            locked_by_type[str(row[0])] = int(row[1])

        inventory: dict[str, object] = {
            "active": active,
            "superseded": superseded,
            "locked": locked,
            "by_type": by_type,
            "by_source": by_source,
            "locked_by_type": locked_by_type,
        }

        # --- Retrieval ---
        retrieved_once: int = count(
            "SELECT COUNT(*) FROM beliefs "
            "WHERE valid_to IS NULL AND last_retrieved_at IS NOT NULL"
        )
        pending_fb: int = count("SELECT COUNT(*) FROM pending_feedback")

        scoring_features: list[str] = [
            "temporal_decay",
            "recency_boost",
            "velocity_scaling",
            "thompson_sampling",
            "type_weights",
            "source_weights",
        ]

        retrieval: dict[str, object] = {
            "retrieved_once": retrieved_once,
            "total_active": active,
            "pending_feedback": pending_fb,
            "scoring_features": scoring_features,
        }

        # --- Activity ---
        sessions: int = count("SELECT COUNT(*) FROM sessions")
        observations: int = count("SELECT COUNT(*) FROM observations")

        age_buckets: dict[str, int] = {}
        for row in self._conn.execute(
            """SELECT
                 CASE
                   WHEN julianday('now') - julianday(created_at) < 1 THEN '<1d'
                   WHEN julianday('now') - julianday(created_at) < 3 THEN '1-3d'
                   WHEN julianday('now') - julianday(created_at) < 7 THEN '3-7d'
                   WHEN julianday('now') - julianday(created_at) < 30 THEN '7-30d'
                   ELSE '>30d'
                 END AS age_bucket,
                 COUNT(*)
               FROM beliefs WHERE valid_to IS NULL
               GROUP BY age_bucket"""
        ).fetchall():
            age_buckets[str(row[0])] = int(row[1])

        activity: dict[str, object] = {
            "sessions": sessions,
            "observations": observations,
            "age_distribution": age_buckets,
        }

        # --- Maintenance (actionable items) ---
        stale: int = self.count_stale_beliefs(days_threshold=30)

        orphan: int = count(
            """SELECT COUNT(*) FROM beliefs b
               WHERE b.valid_to IS NULL
                 AND b.id NOT IN (SELECT from_id FROM edges)
                 AND b.id NOT IN (SELECT to_id FROM edges)"""
        )
        orphan_pct: float = round(orphan / active * 100, 1) if active > 0 else 0.0

        # Credal gap: beliefs at type prior (never received feedback)
        type_prior_rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT belief_type,
                      ROUND(alpha, 1) AS a, ROUND(beta_param, 1) AS b,
                      COUNT(*) AS cnt
               FROM beliefs WHERE valid_to IS NULL
               GROUP BY belief_type, a, b
               ORDER BY belief_type, cnt DESC"""
        ).fetchall()
        type_priors: dict[str, tuple[float, float]] = {}
        for row in type_prior_rows:
            bt: str = str(row["belief_type"])
            if bt not in type_priors:
                type_priors[bt] = (float(str(row["a"])), float(str(row["b"])))

        at_prior: int = 0
        epsilon: float = 0.15
        belief_rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT belief_type, alpha, beta_param FROM beliefs WHERE valid_to IS NULL"
        ).fetchall()
        for row in belief_rows:
            bt = str(row["belief_type"])
            prior = type_priors.get(bt)
            if prior is None:
                continue
            if (
                abs(float(str(row["alpha"])) - prior[0]) < epsilon
                and abs(float(str(row["beta_param"])) - prior[1]) < epsilon
            ):
                at_prior += 1

        credal_pct: float = round(at_prior / active * 100, 1) if active > 0 else 0.0

        maintenance: dict[str, object] = {
            "stale_count": stale,
            "orphan_count": orphan,
            "orphan_pct": orphan_pct,
            "credal_gap_count": at_prior,
            "credal_gap_pct": credal_pct,
        }

        return {
            "inventory": inventory,
            "retrieval": retrieval,
            "activity": activity,
            "maintenance": maintenance,
        }

    def get_health_metrics(self) -> dict[str, object]:
        """Return diagnostic health metrics for the memory system.

        Includes credal gap (beliefs at type prior), orphan count,
        edge type breakdown, feedback coverage, and stale sessions.
        """

        def count(sql: str) -> int:
            row: sqlite3.Row = self._conn.execute(sql).fetchone()
            val: object = row[0]
            if not isinstance(val, int):
                return 0
            return val

        def count_float(sql: str) -> float:
            row: sqlite3.Row = self._conn.execute(sql).fetchone()
            val: object = row[0]
            if val is None:
                return 0.0
            return float(str(val))

        active: int = count("SELECT COUNT(*) FROM beliefs WHERE valid_to IS NULL")

        # Credal gap: beliefs whose (alpha, beta_param) match the most
        # common prior for their type (within epsilon). These have never
        # received feedback.
        # Detect type priors by most common (alpha, beta_param) per type.
        type_prior_rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT belief_type,
                      ROUND(alpha, 1) AS a, ROUND(beta_param, 1) AS b,
                      COUNT(*) AS cnt
               FROM beliefs WHERE valid_to IS NULL
               GROUP BY belief_type, a, b
               ORDER BY belief_type, cnt DESC"""
        ).fetchall()

        # Pick the most common (alpha, beta) per type
        type_priors: dict[str, tuple[float, float]] = {}
        for row in type_prior_rows:
            bt: str = str(row["belief_type"])
            if bt not in type_priors:
                type_priors[bt] = (float(str(row["a"])), float(str(row["b"])))

        # Count beliefs at their type prior
        at_prior: int = 0
        epsilon: float = 0.15
        belief_rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT belief_type, alpha, beta_param FROM beliefs WHERE valid_to IS NULL"
        ).fetchall()
        for row in belief_rows:
            bt = str(row["belief_type"])
            prior = type_priors.get(bt)
            if prior is None:
                continue
            if (
                abs(float(str(row["alpha"])) - prior[0]) < epsilon
                and abs(float(str(row["beta_param"])) - prior[1]) < epsilon
            ):
                at_prior += 1

        # Orphans: beliefs with no edges at all
        orphan: int = count(
            """SELECT COUNT(*) FROM beliefs b
               WHERE b.valid_to IS NULL
                 AND b.id NOT IN (SELECT from_id FROM edges)
                 AND b.id NOT IN (SELECT to_id FROM edges)"""
        )

        # Edge type breakdown
        contradicts: int = count(
            "SELECT COUNT(*) FROM edges WHERE edge_type = 'CONTRADICTS'"
        )
        supports: int = count("SELECT COUNT(*) FROM edges WHERE edge_type = 'SUPPORTS'")
        supersedes: int = count(
            "SELECT COUNT(*) FROM edges WHERE edge_type = 'SUPERSEDES'"
        )

        # Feedback coverage: beliefs with at least one test result
        with_feedback: int = count("""SELECT COUNT(DISTINCT belief_id) FROM tests""")

        # Average confidence
        avg_conf: float = count_float(
            "SELECT AVG(confidence) FROM beliefs WHERE valid_to IS NULL"
        )

        # Stale sessions
        stale: int = count("SELECT COUNT(*) FROM sessions WHERE completed_at IS NULL")

        credal_gap_pct: float = (at_prior / active * 100) if active > 0 else 0.0
        orphan_pct: float = (orphan / active * 100) if active > 0 else 0.0
        feedback_pct: float = (with_feedback / active * 100) if active > 0 else 0.0

        return {
            "active_beliefs": active,
            "credal_gap_count": at_prior,
            "credal_gap_pct": round(credal_gap_pct, 1),
            "orphan_count": orphan,
            "orphan_pct": round(orphan_pct, 1),
            "contradicts_edges": contradicts,
            "supports_edges": supports,
            "supersedes_edges": supersedes,
            "feedback_coverage_count": with_feedback,
            "feedback_coverage_pct": round(feedback_pct, 1),
            "avg_confidence": round(avg_conf, 3),
            "stale_sessions": stale,
            "type_priors": type_priors,
        }

    # --- Bulk maintenance ---

    def get_active_belief_ids(self) -> list[str]:
        """Return all active (non-superseded) belief IDs, ordered by creation."""
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT id FROM beliefs WHERE valid_to IS NULL ORDER BY created_at"
        ).fetchall()
        return [str(r["id"]) for r in rows]

    def get_edges_by_belief_ids(
        self,
        belief_ids: list[str],
    ) -> dict[str, list[Edge]]:
        """Get all edges connected to any of the given belief IDs.

        Returns a dict mapping belief_id -> list of Edge objects where
        that belief is either from_id or to_id. Single query, no N+1.
        """
        if not belief_ids:
            return {}
        # Use a temp table for large IN-clause efficiency
        self._conn.execute(
            "CREATE TEMP TABLE IF NOT EXISTS _bulk_ids (id TEXT PRIMARY KEY)"
        )
        self._conn.execute("DELETE FROM _bulk_ids")
        self._conn.executemany(
            "INSERT OR IGNORE INTO _bulk_ids (id) VALUES (?)",
            [(bid,) for bid in belief_ids],
        )
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT e.* FROM edges e
               JOIN _bulk_ids b ON (e.from_id = b.id OR e.to_id = b.id)
               WHERE e.pruned_at IS NULL"""
        ).fetchall()
        result: dict[str, list[Edge]] = {}
        for row in rows:
            edge: Edge = Edge(
                id=int(row["id"]),
                from_id=str(row["from_id"]),
                to_id=str(row["to_id"]),
                edge_type=str(row["edge_type"]),
                weight=float(row["weight"]),
                reason=str(row["reason"]),
                created_at=str(row["created_at"]),
                alpha=float(row["alpha"]) if row["alpha"] is not None else 1.0,
                beta_param=float(row["beta_param"])
                if row["beta_param"] is not None
                else 1.0,
                traversal_count=int(row["traversal_count"])
                if row["traversal_count"] is not None
                else 0,
                last_traversed_at=str(row["last_traversed_at"])
                if row["last_traversed_at"]
                else None,
                pruned_at=str(row["pruned_at"]) if row["pruned_at"] else None,
            )
            fid: str = edge.from_id
            tid: str = edge.to_id
            if fid in belief_ids or fid in result:
                result.setdefault(fid, []).append(edge)
            if tid != fid and (tid in belief_ids or tid in result):
                result.setdefault(tid, []).append(edge)
        self._conn.execute("DELETE FROM _bulk_ids")
        return result

    def count_edges_for(self, belief_id: str) -> int:
        """Count SUPPORTS + CONTRADICTS edges connected to a belief."""
        row: sqlite3.Row = self._conn.execute(
            """SELECT COUNT(*) FROM edges
               WHERE (from_id = ? OR to_id = ?)
                 AND edge_type IN ('SUPPORTS', 'CONTRADICTS')""",
            (belief_id, belief_id),
        ).fetchone()
        val: object = row[0]
        return int(val) if isinstance(val, int) else 0

    def bulk_update_confidence(
        self,
        belief_ids: list[str],
        outcome: str,
        weight: float = 0.5,
    ) -> int:
        """Apply a Bayesian update to multiple beliefs. Returns count updated."""
        if not belief_ids:
            return 0

        ts: str = _now()
        updated: int = 0
        for belief_id in belief_ids:
            row: sqlite3.Row | None = self._conn.execute(
                "SELECT alpha, beta_param, locked FROM beliefs WHERE id = ?",
                (belief_id,),
            ).fetchone()
            if row is None:
                continue

            alpha: float = float(str(row["alpha"]))
            beta: float = float(str(row["beta_param"]))
            is_locked: bool = bool(row["locked"])

            if outcome == "used":
                alpha += weight
            elif outcome == "harmful":
                if not is_locked:
                    beta += weight
            else:
                continue

            self._conn.execute(
                "UPDATE beliefs SET alpha = ?, beta_param = ?, updated_at = ? WHERE id = ?",
                (alpha, beta, ts, belief_id),
            )
            updated += 1

        self._conn.commit()
        return updated

    # --- Edge dynamics ---

    def record_edge_traversal(self, edge_id: int) -> None:
        """Record that an edge was traversed during retrieval."""
        if self.readonly:
            return
        ts: str = _now()
        self._conn.execute(
            """UPDATE edges SET traversal_count = traversal_count + 1,
               last_traversed_at = ? WHERE id = ?""",
            (ts, edge_id),
        )
        # No commit here -- caller batches multiple traversals.

    def update_edge_confidence(
        self,
        edge_id: int,
        outcome: str,
        weight: float = 1.0,
    ) -> None:
        """Bayesian update on an edge after traversal feedback.

        'used': alpha += weight (edge led to useful belief).
        'ignored': beta += weight * 0.5 (mild penalty).
        'harmful': beta += weight * 2.0 (strong penalty).
        """
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT alpha, beta_param FROM edges WHERE id = ?",
            (edge_id,),
        ).fetchone()
        if row is None:
            return

        alpha: float = float(str(row["alpha"]))
        beta: float = float(str(row["beta_param"]))

        if outcome == "used":
            alpha += weight
        elif outcome == "ignored":
            beta += weight * 0.5
        elif outcome == "harmful":
            beta += weight * 2.0

        self._conn.execute(
            "UPDATE edges SET alpha = ?, beta_param = ? WHERE id = ?",
            (alpha, beta, edge_id),
        )
        # No commit -- caller batches.

    def propagate_feedback_to_edges(
        self,
        belief_id: str,
        outcome: str,
        traversed_edges: list[tuple[int, int]] | None = None,
    ) -> int:
        """Propagate belief feedback to edges that led to this belief.

        Args:
            belief_id: The belief that received feedback.
            outcome: 'used', 'ignored', or 'harmful'.
            traversed_edges: List of (edge_id, hop_distance) pairs recorded
                during the retrieval that surfaced this belief.
                If None, updates all edges connected to the belief (weaker signal).

        Returns count of edges updated.
        """
        updated: int = 0
        if traversed_edges:
            for edge_id, hop in traversed_edges:
                # Discount by hop distance: hop 1 = 1.0, hop 2 = 0.5, hop 3 = 0.25
                discount: float = 0.5 ** (hop - 1)
                self.update_edge_confidence(edge_id, outcome, weight=discount)
                updated += 1
        else:
            # Fallback: update all connected edges with mild weight
            rows: list[sqlite3.Row] = self._conn.execute(
                "SELECT id FROM edges WHERE (from_id = ? OR to_id = ?) "
                "AND pruned_at IS NULL",
                (belief_id, belief_id),
            ).fetchall()
            for row in rows:
                self.update_edge_confidence(int(str(row["id"])), outcome, weight=0.3)
                updated += 1

        if updated > 0:
            self._conn.commit()
        return updated

    def propagate_valence(
        self,
        belief_id: str,
        valence: float,
        decay: float = 0.5,
        max_hops: int = 3,
        min_threshold: float = 0.05,
    ) -> int:
        """Propagate valence through the belief graph via edge-type modulation.

        Positive valence strengthens connected beliefs (alpha boost).
        Negative valence weakens them (beta boost).
        CONTRADICTS edges invert the sign -- confirming A weakens A's contradictions.

        Returns the number of beliefs updated by propagation.
        """
        from agentmemory.models import EDGE_VALENCE

        updated: int = 0
        visited: set[str] = {belief_id}
        # BFS frontier: (belief_id, current_valence_magnitude)
        frontier: list[tuple[str, float]] = [(belief_id, valence)]

        for _hop in range(max_hops):
            next_frontier: list[tuple[str, float]] = []
            for current_id, current_valence in frontier:
                # Find all edges from/to this belief
                rows: list[sqlite3.Row] = self._conn.execute(
                    """SELECT id, from_id, to_id, edge_type
                       FROM edges
                       WHERE (from_id = ? OR to_id = ?) AND pruned_at IS NULL""",
                    (current_id, current_id),
                ).fetchall()

                # Setr fix: attenuate by broker (current node) confidence.
                # Low-confidence intermediaries pass less signal -- their structural
                # connections reflect historical accumulation, not current authority.
                # A 0.2-confidence broker passes 20% of what a 0.9-confidence broker passes.
                _conf_row: sqlite3.Row | None = self._conn.execute(
                    "SELECT alpha, beta_param FROM beliefs WHERE id = ?",
                    (current_id,),
                ).fetchone()
                _broker_confidence: float = 1.0
                if _conf_row is not None:
                    _a: float = float(_conf_row["alpha"])
                    _b: float = float(_conf_row["beta_param"])
                    if _a + _b > 0.0:
                        _broker_confidence = _a / (_a + _b)

                for row in rows:
                    neighbor_id: str = (
                        str(row["to_id"])
                        if str(row["from_id"]) == current_id
                        else str(row["from_id"])
                    )
                    if neighbor_id in visited:
                        continue

                    edge_type: str = str(row["edge_type"])
                    multiplier: float = EDGE_VALENCE.get(edge_type, 0.0)
                    if multiplier == 0.0:
                        continue

                    # Apply decay, edge-type modulation, and broker confidence attenuation.
                    # Negative multiplier (CONTRADICTS) inverts the valence sign.
                    propagated: float = (
                        current_valence * decay * multiplier * _broker_confidence
                    )

                    if abs(propagated) < min_threshold:
                        continue

                    visited.add(neighbor_id)

                    # Apply the propagated valence to this neighbor's confidence
                    if propagated > 0:
                        self._apply_valence_update(neighbor_id, alpha_delta=propagated)
                    else:
                        self._apply_valence_update(
                            neighbor_id, beta_delta=abs(propagated)
                        )

                    # Also update the edge's own confidence
                    edge_id: int = int(str(row["id"]))
                    if propagated > 0:
                        self.update_edge_confidence(
                            edge_id, "used", weight=abs(propagated)
                        )
                    else:
                        self.update_edge_confidence(
                            edge_id, "harmful", weight=abs(propagated)
                        )

                    updated += 1
                    next_frontier.append((neighbor_id, propagated))

            frontier = next_frontier
            if not frontier:
                break

        if updated > 0:
            self._conn.commit()
        return updated

    def _apply_valence_update(
        self,
        belief_id: str,
        alpha_delta: float = 0.0,
        beta_delta: float = 0.0,
    ) -> None:
        """Apply a raw alpha/beta adjustment to a belief. No locking check.

        Used by propagate_valence for indirect updates where the locked
        evidence threshold does not apply (the originating signal already
        passed the threshold check on the seed belief).
        """
        row: sqlite3.Row | None = self._conn.execute(
            "SELECT alpha, beta_param, locked FROM beliefs WHERE id = ?",
            (belief_id,),
        ).fetchone()
        if row is None:
            return
        alpha: float = row["alpha"] + alpha_delta
        beta: float = row["beta_param"] + beta_delta
        is_locked: bool = bool(row["locked"])
        # Locked beliefs require stronger indirect negative signals.
        # Small negative propagation (< 0.5) is filtered as noise;
        # stronger signals get through at reduced weight.
        if is_locked and beta_delta > 0:
            if beta_delta < 0.5:
                return
            beta_delta *= 0.5  # attenuate, don't block
        ts: str = _now()
        self._conn.execute(
            "UPDATE beliefs SET alpha = ?, beta_param = ?, updated_at = ? WHERE id = ?",
            (alpha, beta, ts, belief_id),
        )
        self._record_confidence(belief_id, alpha, beta, "valence_propagation")

    def get_session_retrieval_subgraph(
        self,
        session_id: str,
    ) -> tuple[list[str], list[tuple[str, str, str, int]], dict[str, int]]:
        """Build the induced subgraph of beliefs retrieved during a session.

        Returns:
            belief_ids: list of unique belief IDs retrieved in the session
            edges: list of (from_id, to_id, edge_type, edge_id) for edges
                   where both endpoints are in the retrieved set
            centrality: dict mapping belief_id -> degree in the subgraph
        """
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT DISTINCT belief_id FROM tests WHERE session_id = ?",
            (session_id,),
        ).fetchall()
        belief_ids: list[str] = [str(r["belief_id"]) for r in rows]
        if not belief_ids:
            return [], [], {}

        id_set: set[str] = set(belief_ids)
        placeholders: str = ",".join("?" for _ in belief_ids)

        edge_rows: list[sqlite3.Row] = self._conn.execute(
            f"""SELECT id, from_id, to_id, edge_type FROM edges
                WHERE from_id IN ({placeholders})
                AND to_id IN ({placeholders})
                AND pruned_at IS NULL""",
            belief_ids + belief_ids,
        ).fetchall()

        edges: list[tuple[str, str, str, int]] = []
        centrality: dict[str, int] = {bid: 0 for bid in belief_ids}
        for row in edge_rows:
            fid: str = str(row["from_id"])
            tid: str = str(row["to_id"])
            if fid in id_set and tid in id_set:
                edges.append((fid, tid, str(row["edge_type"]), int(str(row["id"]))))
                centrality[fid] = centrality.get(fid, 0) + 1
                centrality[tid] = centrality.get(tid, 0) + 1

        return belief_ids, edges, centrality

    def set_session_quality(self, session_id: str, score: float) -> None:
        """Record the quality score for a session."""
        self._conn.execute(
            "UPDATE sessions SET quality_score = ? WHERE id = ?",
            (score, session_id),
        )
        self._conn.commit()

    def get_edge_health(self) -> dict[str, object]:
        """Edge-specific health metrics."""

        def count(sql: str) -> int:
            row: sqlite3.Row = self._conn.execute(sql).fetchone()
            val: object = row[0]
            return int(val) if isinstance(val, int) else 0

        def avg(sql: str) -> float:
            row: sqlite3.Row = self._conn.execute(sql).fetchone()
            val: object = row[0]
            return float(str(val)) if val is not None else 0.0

        active: int = count("SELECT COUNT(*) FROM edges WHERE pruned_at IS NULL")
        pruned: int = count("SELECT COUNT(*) FROM edges WHERE pruned_at IS NOT NULL")
        traversed: int = count(
            "SELECT COUNT(*) FROM edges WHERE traversal_count > 0 AND pruned_at IS NULL"
        )
        never_traversed: int = active - traversed

        avg_conf: float = avg(
            "SELECT AVG(alpha / (alpha + beta_param)) FROM edges WHERE pruned_at IS NULL"
        )
        avg_traversals: float = avg(
            "SELECT AVG(traversal_count) FROM edges WHERE pruned_at IS NULL"
        )

        # Edge credal gap: edges still at default prior (1.0, 1.0)
        at_prior: int = count(
            "SELECT COUNT(*) FROM edges WHERE pruned_at IS NULL "
            "AND ABS(alpha - 1.0) < 0.01 AND ABS(beta_param - 1.0) < 0.01"
        )

        return {
            "active_edges": active,
            "pruned_edges": pruned,
            "traversed_edges": traversed,
            "never_traversed_edges": never_traversed,
            "avg_edge_confidence": round(avg_conf, 3),
            "avg_traversal_count": round(avg_traversals, 1),
            "edge_credal_gap": at_prior,
            "edge_credal_gap_pct": round(at_prior / active * 100, 1)
            if active > 0
            else 0.0,
        }

    # --- Onboarding provenance ---

    def record_onboarding_run(
        self,
        project_path: str,
        commit_hash: str | None,
        nodes_extracted: int,
        edges_extracted: int,
        beliefs_created: int,
        observations_created: int,
    ) -> int:
        """Record an onboarding run for provenance tracking."""
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            """INSERT INTO onboarding_runs
               (project_path, commit_hash, nodes_extracted, edges_extracted,
                beliefs_created, observations_created, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                project_path,
                commit_hash,
                nodes_extracted,
                edges_extracted,
                beliefs_created,
                observations_created,
                ts,
            ),
        )
        self._conn.commit()
        row_id: int | None = cursor.lastrowid
        return row_id if row_id is not None else 0

    def get_last_onboarding(
        self, project_path: str | None = None
    ) -> dict[str, str] | None:
        """Return the most recent onboarding run, optionally filtered by project."""
        if project_path:
            row: sqlite3.Row | None = self._conn.execute(
                """SELECT * FROM onboarding_runs
                   WHERE project_path = ?
                   ORDER BY created_at DESC LIMIT 1""",
                (project_path,),
            ).fetchone()
        else:
            row = self._conn.execute(
                "SELECT * FROM onboarding_runs ORDER BY created_at DESC LIMIT 1"
            ).fetchone()
        if row is None:
            return None
        return {k: str(row[k]) for k in row.keys()}

    def get_rigor_distribution(self) -> dict[str, int]:
        """Return count of active beliefs per rigor_tier."""
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT rigor_tier, COUNT(*) as cnt FROM beliefs
               WHERE valid_to IS NULL
               GROUP BY rigor_tier ORDER BY cnt DESC"""
        ).fetchall()
        return {str(r["rigor_tier"]): int(r["cnt"]) for r in rows}

    def get_last_completed_session(self) -> Session | None:
        """Return the most recently completed session (for velocity reporting)."""
        row: sqlite3.Row | None = self._conn.execute(
            """SELECT * FROM sessions
               WHERE completed_at IS NOT NULL
               ORDER BY completed_at DESC LIMIT 1"""
        ).fetchone()
        if row is None:
            return None
        return _row_to_session(row)

    def get_snapshot(
        self,
        at_time: str | None = None,
        belief_type: str | None = None,
        limit: int = 200,
    ) -> list[Belief]:
        """Return beliefs that were active at a specific point in time.

        If at_time is None, returns currently active beliefs.
        Excludes superseded beliefs (valid_to <= at_time).
        """
        if at_time is None:
            at_time = _now()

        sql: str = """SELECT * FROM beliefs
                      WHERE created_at <= ?
                        AND (valid_to IS NULL OR valid_to > ?)"""
        params: list[object] = [at_time, at_time]

        if belief_type is not None:
            sql += " AND belief_type = ?"
            params.append(belief_type)

        sql += " ORDER BY confidence DESC LIMIT ?"
        params.append(limit)

        rows: list[sqlite3.Row] = self._conn.execute(sql, tuple(params)).fetchall()
        return [row_to_belief(r) for r in rows]

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()

    def query(self, sql: str, params: tuple[object, ...] = ()) -> list[sqlite3.Row]:
        """Execute a read-only SQL query and return all rows.

        Intended for tests and diagnostic tooling. Not for production write paths.
        """
        return self._conn.execute(sql, params).fetchall()  # type: ignore[return-value]

    # --- Evidence (direct access) ---

    def insert_evidence(
        self,
        belief_id: str,
        observation_id: str,
        source_weight: float = 1.0,
        relationship: str = "supports",
    ) -> Evidence:
        """Insert an evidence link from an observation to a belief."""
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            """INSERT INTO evidence (belief_id, observation_id, source_weight, relationship, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (belief_id, observation_id, source_weight, relationship, ts),
        )
        self._conn.commit()
        row_id: int | None = cursor.lastrowid
        if row_id is None:
            raise RuntimeError("Evidence insert did not return a rowid")
        return Evidence(
            id=row_id,
            belief_id=belief_id,
            observation_id=observation_id,
            source_weight=source_weight,
            relationship=relationship,
            created_at=ts,
        )

    # --- Document tracing ---

    def get_source_documents(self, belief_ids: list[str]) -> list[str]:
        """Trace beliefs back to source file paths via evidence -> observations.

        Returns deduplicated list of source_path values for the given beliefs.
        """
        if not belief_ids:
            return []
        placeholders: str = ",".join("?" * len(belief_ids))
        rows: list[sqlite3.Row] = self._conn.execute(
            f"""SELECT DISTINCT o.source_path
                FROM evidence e
                JOIN observations o ON o.id = e.observation_id
                WHERE e.belief_id IN ({placeholders})
                  AND o.source_path != ''""",
            belief_ids,
        ).fetchall()
        return [row["source_path"] for row in rows]

    # --- Retrieval stats (Tier 3) ---

    def get_retrieval_stats(self, belief_id: str) -> dict[str, int]:
        """Return retrieval count and use rate for a belief.

        Queries the tests table for outcome history. Returns zeros if no
        retrieval data exists yet (Tier 3 activates once beliefs are tested).
        """
        row: sqlite3.Row | None = self._conn.execute(
            """SELECT
                COUNT(*) as total,
                SUM(CASE WHEN outcome = 'used' THEN 1 ELSE 0 END) as used,
                SUM(CASE WHEN outcome = 'ignored' THEN 1 ELSE 0 END) as ignored,
                SUM(CASE WHEN outcome = 'harmful' THEN 1 ELSE 0 END) as harmful
            FROM tests WHERE belief_id = ?""",
            (belief_id,),
        ).fetchone()
        if row is None or row["total"] == 0:
            return {"retrieval_count": 0, "used": 0, "ignored": 0, "harmful": 0}
        return {
            "retrieval_count": int(str(row["total"])),
            "used": int(str(row["used"])),
            "ignored": int(str(row["ignored"])),
            "harmful": int(str(row["harmful"])),
        }

    def get_retrieval_stats_batch(
        self, belief_ids: list[str]
    ) -> dict[str, dict[str, int]]:
        """Batch retrieval stats for multiple beliefs.

        Returns {belief_id: {retrieval_count, used, ignored, harmful}}.
        Beliefs with no test data are omitted from the result.
        """
        if not belief_ids:
            return {}
        placeholders: str = ",".join("?" for _ in belief_ids)
        rows: list[sqlite3.Row] = self._conn.execute(
            f"""SELECT
                belief_id,
                COUNT(*) as total,
                SUM(CASE WHEN outcome = 'used' THEN 1 ELSE 0 END) as used,
                SUM(CASE WHEN outcome = 'ignored' THEN 1 ELSE 0 END) as ignored,
                SUM(CASE WHEN outcome = 'harmful' THEN 1 ELSE 0 END) as harmful
            FROM tests
            WHERE belief_id IN ({placeholders})
            GROUP BY belief_id""",
            belief_ids,
        ).fetchall()
        result: dict[str, dict[str, int]] = {}
        for row in rows:
            result[row["belief_id"]] = {
                "retrieval_count": int(str(row["total"])),
                "used": int(str(row["used"])),
                "ignored": int(str(row["ignored"])),
                "harmful": int(str(row["harmful"])),
            }
        return result

    # --- Stale belief detection ---

    def get_stale_beliefs(
        self, days_threshold: int = 30, limit: int = 50
    ) -> list[Belief]:
        """Return beliefs not retrieved in the last N days.

        Excludes locked beliefs (always relevant) and beliefs created
        within the threshold period (too new to be stale).
        Returns at most ``limit`` beliefs, ordered by staleness (oldest first).
        """
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT * FROM beliefs
               WHERE valid_to IS NULL
                 AND locked = 0
                 AND created_at < datetime('now', ? || ' days')
                 AND (last_retrieved_at IS NULL
                      OR last_retrieved_at < datetime('now', ? || ' days'))
               ORDER BY COALESCE(last_retrieved_at, created_at) ASC
               LIMIT ?""",
            (f"-{days_threshold}", f"-{days_threshold}", limit),
        ).fetchall()
        return [row_to_belief(r) for r in rows]

    def count_stale_beliefs(self, days_threshold: int = 30) -> int:
        """Count beliefs not retrieved in the last N days (excludes locked and new)."""
        row: sqlite3.Row = self._conn.execute(
            """SELECT COUNT(*) FROM beliefs
               WHERE valid_to IS NULL
                 AND locked = 0
                 AND created_at < datetime('now', ? || ' days')
                 AND (last_retrieved_at IS NULL
                      OR last_retrieved_at < datetime('now', ? || ' days'))""",
            (f"-{days_threshold}", f"-{days_threshold}"),
        ).fetchone()
        val: object = row[0]
        if not isinstance(val, int):
            return 0
        return val

    def count_active_beliefs(self) -> int:
        """Count non-superseded beliefs."""
        row: sqlite3.Row = self._conn.execute(
            "SELECT COUNT(*) FROM beliefs WHERE valid_to IS NULL",
        ).fetchone()
        val: object = row[0]
        if not isinstance(val, int):
            return 0
        return val

    def get_all_active_beliefs(self, limit: int = 50000) -> list[Belief]:
        """Get all non-superseded beliefs (for entity index building)."""
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT * FROM beliefs WHERE valid_to IS NULL LIMIT ?",
            (limit,),
        ).fetchall()
        return [row_to_belief(r) for r in rows]

    def recalibrate_scores(self, deflation_factor: float = 0.2) -> int:
        """Reset agent-inferred beliefs to correct type-specific priors.

        Uses the same priors as classification.get_source_adjusted_prior()
        to ensure beliefs match what new insertions would produce.
        User-sourced beliefs and locked beliefs are NOT touched.

        Returns the number of beliefs recalibrated.
        """
        # Type-specific deflated priors for agent-inferred content.
        # Must match classification.py get_source_adjusted_prior().
        type_priors: dict[str, tuple[float, float]] = {
            "factual": (0.6, 1.0),  # 37.5%
            "requirement": (1.8, 0.5),  # 78.3%
            "correction": (1.8, 0.5),  # 78.3%
            "preference": (1.4, 1.0),  # 58.3%
            "assumption": (0.5, 1.0),  # 33.3%
            "decision": (1.0, 1.0),  # 50.0%
            "analysis": (0.5, 1.0),  # 33.3%
            "speculative": (0.5, 1.0),  # 33.3%
        }

        ts: str = datetime.now(timezone.utc).isoformat()
        total: int = 0

        for belief_type, (target_alpha, target_beta) in type_priors.items():
            # Only recalibrate agent-inferred beliefs with alpha above the
            # target (i.e., still inflated from a previous calibration).
            # Preserve any feedback-driven adjustments by keeping beliefs
            # that have already been deflated below the target.
            cursor: sqlite3.Cursor = self._conn.execute(
                """UPDATE beliefs
                   SET alpha = ?,
                       beta_param = ?,
                       updated_at = ?
                   WHERE superseded_by IS NULL
                     AND locked = 0
                     AND source_type = 'agent_inferred'
                     AND belief_type = ?
                     AND alpha > ?""",
                (target_alpha, target_beta, ts, belief_type, target_alpha),
            )
            total += cursor.rowcount

        self._conn.commit()
        return total

    # --- Speculative beliefs ---

    def get_speculative_beliefs(self, limit: int = 50) -> list[Belief]:
        """Get all active forward-looking beliefs, ordered by creation time."""
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT * FROM beliefs
               WHERE valid_to IS NULL AND temporal_direction = 'forward'
               ORDER BY created_at DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        return [row_to_belief(r) for r in rows]

    def get_highest_entropy_beliefs(self, limit: int = 10) -> list[Belief]:
        """Get speculative beliefs with the most uncertainty (highest joint entropy).

        Returns beliefs that have uncertainty_vector set, sorted by
        mean variance (proxy for entropy, avoids computing digamma in SQL).
        The caller should compute exact entropy from the returned vectors.
        """
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT * FROM beliefs
               WHERE valid_to IS NULL
                 AND temporal_direction = 'forward'
                 AND uncertainty_vector IS NOT NULL
               ORDER BY created_at DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        return [row_to_belief(r) for r in rows]

    def get_hibernated_beliefs(
        self, threshold: float = 0.2, limit: int = 20
    ) -> list[Belief]:
        """Get speculative beliefs below the hibernation threshold."""
        rows: list[sqlite3.Row] = self._conn.execute(
            """SELECT * FROM beliefs
               WHERE valid_to IS NULL
                 AND temporal_direction = 'forward'
                 AND hibernation_score IS NOT NULL
                 AND hibernation_score < ?
               ORDER BY hibernation_score ASC LIMIT ?""",
            (threshold, limit),
        ).fetchall()
        return [row_to_belief(r) for r in rows]

    def insert_speculative_belief(
        self,
        content: str,
        uncertainty_vector_json: str,
        source_belief_id: str | None = None,
        activation_condition: str | None = None,
        session_id: str | None = None,
    ) -> Belief:
        """Create a forward-looking speculative belief with uncertainty vector.

        Optionally links to the source belief via a SPECULATES edge.
        """
        belief: Belief = self.insert_belief(
            content=content,
            belief_type="speculative",
            source_type="agent_inferred",
            alpha=1.0,
            beta_param=1.0,
            session_id=session_id,
        )
        # Set speculative fields
        self._conn.execute(
            """UPDATE beliefs SET temporal_direction = 'forward',
               uncertainty_vector = ?, activation_condition = ?
               WHERE id = ?""",
            (uncertainty_vector_json, activation_condition, belief.id),
        )
        self._conn.commit()

        # Create SPECULATES edge from source belief
        if source_belief_id is not None:
            self.insert_edge(
                source_belief_id,
                belief.id,
                "SPECULATES",
                1.0,
                "wonder",
            )

        # Re-read to get updated fields
        updated: Belief | None = self.get_belief(belief.id)
        return updated if updated is not None else belief

    def update_uncertainty(
        self,
        belief_id: str,
        uncertainty_vector_json: str,
        hibernation_score: float | None = None,
    ) -> bool:
        """Update the uncertainty vector and hibernation score on a speculative belief."""
        cursor: sqlite3.Cursor = self._conn.execute(
            """UPDATE beliefs SET uncertainty_vector = ?, hibernation_score = ?,
               updated_at = ? WHERE id = ? AND valid_to IS NULL""",
            (uncertainty_vector_json, hibernation_score, _now(), belief_id),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    # --- Test results ---

    def record_test_result(
        self,
        belief_id: str,
        session_id: str,
        outcome: str,
        detection_layer: str,
        retrieval_context: str | None = None,
        outcome_detail: str | None = None,
        evidence_weight: float = 1.0,
        valence: float | None = None,
    ) -> TestResult:
        """Record the outcome of a belief retrieval. Also updates belief confidence."""
        ts: str = _now()
        cursor: sqlite3.Cursor = self._conn.execute(
            """INSERT INTO tests
               (belief_id, session_id, retrieval_context, outcome, outcome_detail,
                detection_layer, evidence_weight, valence, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                belief_id,
                session_id,
                retrieval_context,
                outcome,
                outcome_detail,
                detection_layer,
                evidence_weight,
                valence,
                ts,
            ),
        )
        self._conn.commit()
        row_id: int | None = cursor.lastrowid
        if row_id is None:
            raise RuntimeError("TestResult insert did not return a rowid")
        self.update_confidence(belief_id, outcome, evidence_weight, valence=valence)
        return TestResult(
            id=row_id,
            belief_id=belief_id,
            session_id=session_id,
            retrieval_context=retrieval_context,
            outcome=outcome,
            outcome_detail=outcome_detail,
            detection_layer=detection_layer,
            evidence_weight=evidence_weight,
            created_at=ts,
        )

    # --- Pending feedback ---

    def insert_pending_feedback(
        self,
        belief_id: str,
        belief_content: str,
        session_id: str | None = None,
    ) -> None:
        """Store a retrieved belief for later feedback matching."""
        ts: str = _now()
        self._conn.execute(
            """INSERT INTO pending_feedback
               (belief_id, belief_content, session_id, created_at)
               VALUES (?, ?, ?, ?)""",
            (belief_id, belief_content, session_id, ts),
        )
        self._conn.commit()

    def get_pending_feedback(
        self,
        session_id: str | None = None,
    ) -> list[dict[str, str]]:
        """Get pending feedback entries, optionally filtered by session."""
        if session_id is not None:
            rows: list[sqlite3.Row] = self._conn.execute(
                "SELECT belief_id, belief_content, session_id, created_at "
                "FROM pending_feedback WHERE session_id = ? ORDER BY created_at",
                (session_id,),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT belief_id, belief_content, session_id, created_at "
                "FROM pending_feedback ORDER BY created_at",
            ).fetchall()
        return [
            {
                "belief_id": row["belief_id"],
                "belief_content": row["belief_content"],
                "session_id": row["session_id"] if row["session_id"] else "",
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def clear_pending_feedback(
        self,
        session_id: str | None = None,
    ) -> int:
        """Remove pending feedback entries after processing. Returns count removed."""
        if session_id is not None:
            cursor: sqlite3.Cursor = self._conn.execute(
                "DELETE FROM pending_feedback WHERE session_id = ?",
                (session_id,),
            )
        else:
            cursor = self._conn.execute("DELETE FROM pending_feedback")
        self._maybe_commit()
        return cursor.rowcount

    def get_session_observation_texts(
        self,
        session_id: str,
        limit: int = 200,
    ) -> list[str]:
        """Return observation content strings for a given session, most recent first."""
        rows: list[sqlite3.Row] = self._conn.execute(
            "SELECT content FROM observations WHERE session_id = ? "
            "ORDER BY created_at DESC LIMIT ?",
            (session_id, limit),
        ).fetchall()
        return [row["content"] for row in rows]
