# Knowledge Graph Model

Reference for all node types, edge types, and constants in the agentmemory knowledge graph.

## Node Types (Beliefs)

### Belief Types (`belief_type`)

| Constant | Value | Decay Half-Life | Demotion Threshold |
|---|---|---|---|
| `BELIEF_FACTUAL` | `"factual"` | 14 days | 9.0 |
| `BELIEF_PREFERENCE` | `"preference"` | 12 weeks | 15.0 |
| `BELIEF_RELATIONAL` | `"relational"` | 14 days | 9.0 |
| `BELIEF_PROCEDURAL` | `"procedural"` | 21 days | 15.0 |
| `BELIEF_CAUSAL` | `"causal"` | 30 days | 12.0 |
| `BELIEF_CORRECTION` | `"correction"` | 8 weeks | 15.0 |
| `BELIEF_REQUIREMENT` | `"requirement"` | 24 weeks | 15.0 |
| `BELIEF_TODO` | `"todo"` | 4 weeks | 9.0 |

Defined in `src/agentmemory/models.py:26-33`.

### Source Types (`source_type`)

| Constant | Value | Decay Modifier | Scoring Weight |
|---|---|---|---|
| `BSRC_USER_STATED` | `"user_stated"` | 1.5x slower | 1.3 |
| `BSRC_USER_CORRECTED` | `"user_corrected"` | 2.0x slower | 1.5 |
| `BSRC_DOCUMENT_RECENT` | `"document_recent"` | 1.0x | 1.0 |
| `BSRC_DOCUMENT_OLD` | `"document_old"` | 1.0x | 0.8 |
| `BSRC_AGENT_INFERRED` | `"agent_inferred"` | 0.5x faster | 1.0 |
| (special) | `"wonder_generated"` | -- | -- |

Defined in `src/agentmemory/models.py:36-40`.

### Lock Levels (`lock_level`)

| Constant | Value | Evidence Behavior | Demotion |
|---|---|---|---|
| `LOCK_NONE` | `"none"` | Full Bayesian updates | N/A |
| `LOCK_PROMOTED` | `"promoted"` | Resist noise, evidence can demote | Auto-demote to none on beta += 2.0 |
| `LOCK_USER` | `"user"` | Require weight >= 3.0 for harmful | Demote to promoted on cumulative harmful >= threshold |

Defined in `src/agentmemory/models.py:92-96`.

### Temporal Direction

| Constant | Value | Meaning |
|---|---|---|
| `TEMPORAL_BACKWARD` | `"backward"` | Factual, refers to past |
| `TEMPORAL_FORWARD` | `"forward"` | Speculative, forward-looking |

### Observation Types

| Constant | Value |
|---|---|
| `OBS_TYPE_CONVERSATION` | `"conversation"` |
| `OBS_TYPE_FILE_CHANGE` | `"file_change"` |
| `OBS_TYPE_ERROR` | `"error"` |
| `OBS_TYPE_DECISION` | `"decision"` |
| `OBS_TYPE_USER_STATEMENT` | `"user_statement"` |
| `OBS_TYPE_DOCUMENT` | `"document"` |

---

## Edge Types

### Semantic Edges (belief-to-belief, `edges` table)

| Constant | Value | Valence | Weight | Purpose |
|---|---|---|---|---|
| `EDGE_SUPPORTS` | `"SUPPORTS"` | +1.0 | 1.8 | Provides evidence for |
| `EDGE_CONTRADICTS` | `"CONTRADICTS"` | -0.5 | 2.0 | Contradicts or negates |
| `EDGE_RELATES_TO` | `"RELATES_TO"` | +0.3 | -- | Topically related |
| `EDGE_CITES` | `"CITES"` | +0.5 | 1.3 | References or cites |
| `EDGE_SUPERSEDES` | `"SUPERSEDES"` | 0.0 | -- | Replaces (historical) |
| `EDGE_DERIVED_FROM` | `"DERIVED_FROM"` | +0.6 | -- | Created while A was in context |
| `EDGE_TEMPORAL_NEXT` | `"TEMPORAL_NEXT"` | 0.0 | 0.6 | Sequential temporal order |

### Speculative Edges (belief-to-belief)

| Constant | Value | Valence | Purpose |
|---|---|---|---|
| `EDGE_SPECULATES` | `"SPECULATES"` | +0.3 | Current state to possible future |
| `EDGE_DEPENDS_ON` | `"DEPENDS_ON"` | +0.8 | Speculative outcome requires condition |
| `EDGE_RESOLVES` | `"RESOLVES"` | +0.5 | Evidence resolves speculation |
| `EDGE_HIBERNATED` | `"HIBERNATED"` | 0.0 | Soft-closed speculative branch |

### Structural Edges (project graph, `graph_edges` table)

| Value | Weight | Source -> Target | Purpose |
|---|---|---|---|
| `"COMMIT_TOUCHES"` | 0.4 | commit -> file | File modified in commit |
| `"CO_CHANGED"` | 0.8 | file -> file | Files changed together (min 3 co-occurrences) |
| `"CONTAINS"` | 0.3 | directory -> file | Directory contains file |
| `"SENTENCE_IN_FILE"` | 0.2 | sentence -> file | Sentence extracted from file |
| `"WITHIN_SECTION"` | 0.2 | sentence -> sentence | Sequential in document section |
| `"CALLS"` | 1.3 | file -> function | Function call relationship |
| `"TESTS"` | 1.5 | test_file -> code_file | Test coverage |
| `"IMPLEMENTS"` | 1.5 | code_file -> requirement | Implements requirement/case study |

---

## Valence Propagation

When feedback is applied to a belief, confidence changes propagate through edges.

| Parameter | Value |
|---|---|
| `VALENCE_DECAY` | 0.5 (50% attenuation per hop) |
| `VALENCE_MAX_HOPS` | 3 |
| `VALENCE_MIN_THRESHOLD` | 0.05 |

Propagation multiplier per edge type is defined in `EDGE_VALENCE` (models.py:68-82).

---

## Feedback Outcomes

| Outcome | Valence | Effect |
|---|---|---|
| `"confirmed"` | +1.0 | Strong positive, alpha += weight |
| `"used"` | +0.5 | Moderate positive, alpha += weight |
| `"ignored"` | -0.1 | Weak negative, beta += 0.1 * weight (not for user-locked) |
| `"contradicted"` | 0.0 | No change |
| `"weak"` | -0.6 | Moderate negative |
| `"harmful"` | -2.0 | Strong negative, beta += weight (user-locked requires weight >= 3.0) |

---

## Ingestion Architecture

### What Gets Ingested

| Artifact Type | Ingested? | Source Type | Edge Types Created |
|---|---|---|---|
| User conversation turns | Yes | `user` / `agent` | TEMPORAL_NEXT, SUPPORTS/CONTRADICTS |
| Git commit messages | Yes | `git` | COMMIT_TOUCHES, CO_CHANGED, TEMPORAL_NEXT |
| Markdown docs (README, ARCHITECTURE, etc.) | Yes | `document` | SENTENCE_IN_FILE, WITHIN_SECTION |
| Experiment files (.md) | Yes | `document` | SENTENCE_IN_FILE, WITHIN_SECTION, CITES |
| Python source (AST) | Yes | `code` | CALLS |
| Test files | Yes (edges only) | -- | TESTS |
| Obsidian vault notes | Yes (bidirectional) | `user_stated` | -- |
| Directive files (CLAUDE.md) | Partial | `directive` | -- |

### What Is NOT Ingested (Gaps)

| Artifact Type | Impact | Notes |
|---|---|---|
| Config files (pyproject.toml, Dockerfile) | Medium | Dependencies/build config invisible |
| Docstrings in source code | Medium | Function docs ignored by AST extractor |
| Code comments / TODO/FIXME | Low | Would require regex mining |
| Type annotations (.pyi) | Low | Typing intent not captured |
| CI/CD workflows (.github/workflows) | Low | Pipeline config invisible |
| API specs (OpenAPI, GraphQL) | Low | Not detected or parsed |
| Test function bodies | Medium | Only edges exist, not assertion content |

### Ingestion Pipeline Flow

```
Scanner (scanner.py)
  discover()        -> detect project signals (git, docs, languages)
  extract_file_tree()         -> file nodes + CONTAINS edges
  extract_git_history()       -> commit nodes + COMMIT_TOUCHES/CO_CHANGED
  extract_document_sentences() -> heading/sentence nodes + SENTENCE_IN_FILE
  extract_ast_calls()         -> callable nodes + CALLS edges
  extract_test_edges()        -> TESTS edges
  extract_citations()         -> CITES edges
  extract_implements_edges()  -> IMPLEMENTS edges
  extract_directives()        -> behavioral_belief nodes
      |
      v
  scan_project() -> ScanResult(nodes[], edges[])
      |
      v
  cmd_onboard() (cli.py)
    for each node: ingest_turn() -> observations + beliefs
    batch_insert_graph_edges()  -> structural edges
    build_temporal_backbone()   -> TEMPORAL_NEXT edges
```

---

## Database Schema (Key Tables)

**`beliefs`**: Node table -- one row per belief with type, source, confidence, lock level.

**`edges`**: Semantic edges between beliefs (SUPPORTS, CONTRADICTS, etc.).

**`graph_edges`**: Structural edges from project scanning (CALLS, TESTS, CONTAINS, etc.).

**`observations`**: Raw immutable conversation turns before classification.

**`confidence_history`**: Audit trail of all confidence changes (event_type, alpha, beta).

**`sessions`**: Session lifecycle tracking (started_at, completed_at, metrics).

**`hook_injections`**: Dev-only telemetry for hook injection stats.

---

*Defined in `src/agentmemory/models.py`. Weights in `src/agentmemory/scoring.py` and `src/agentmemory/store.py`.*
