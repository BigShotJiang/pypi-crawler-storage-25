<sub>[← Chapter 4 - Obsidian Integration](OBSIDIAN.md) · [Contents](README.md) · Next: [Chapter 6 - Privacy and Security →](PRIVACY.md)</sub>

# Chapter 5. Architecture

![agentmemory system architecture: ingestion, retrieval, and feedback pipeline](pipeline-architecture.svg)

Conversations become scored beliefs. Beliefs get stronger when they help, weaker when they hurt. The system learns what matters over time.

- **Bayesian confidence.** Beta-Bernoulli model with Thompson sampling. Beliefs that help get stronger; beliefs that hurt get weaker.
- **9-layer retrieval pipeline (~45ms on 17K beliefs).** L0: structural prompt analysis + activation-condition matching. L1: FTS5 keyword search (BM25). L1.5: HRR vocabulary expansion via precomputed neighbors. L1.7: intention-cluster expansion. L2: entity-aware search (corrections/user statements). L3: action-context search. L4: cluster + supersession graph traversal (single UNION ALL query). L5: recent observations (unclassified, last 24h). L6: cross-project shared scope (federated FTS5 via ATTACH). Relevance-gated type/source weights prevent irrelevant corrections from drowning results. Compressed to fit a token budget.
- **Graph-backed knowledge.** 17 edge types: 12 core (SUPERSEDES, CONTRADICTS, SUPPORTS, CALLS, CITES, TESTS, IMPLEMENTS, RELATES_TO, TEMPORAL_NEXT, CO_CHANGED, CONTAINS, COMMIT_TOUCHES) + 5 speculative/causal (SPECULATES, DEPENDS_ON, RESOLVES, HIBERNATED, DERIVED_FROM). Multi-hop traversal, contradiction detection, and consequence-path reasoning.
- **Correction detection.** 92% accuracy on tested corpus (Exp 1 V2, zero-LLM). Corrections auto-create high-confidence beliefs.
- **LLM classification.** Haiku classifies belief type/persistence at 99% accuracy (Exp 47/50), estimated ~$0.005/session.
- **Project onboarding.** 8 extractors pull structure from git history, AST, docs, citations, tests, implementations, and directives.
- **Temporal decay.** Content-aware half-lives (facts 14 days, corrections 8 weeks, requirements 24 weeks). Session velocity scaling.
- **Per-project isolation.** Each project gets its own SQLite database at `~/.agentmemory/projects/<hash>/`.
- **Natural language sentiment feedback.** User approval ("ok good", "nice") and correction ("no that's wrong", "fix it") automatically update belief confidence. No explicit feedback commands needed. Correction frequency detection amplifies repeated negative signals.
- **Enforcement triad.** Three mechanisms close the knowing-doing gap: (1) directive detection captures imperative user statements as TODO beliefs, (2) compliance audit checks locked beliefs against system state at session end, (3) selective injection presents task-relevant constraints as imperatives instead of passive context.
- **Auto-reclassification.** Beliefs flagged when confidence drops below 0.5 or CONTRADICTS edge is created. Locked beliefs exempt.
- **35 production modules.** 31 MCP tools. 1131 tests with 30s timeout enforced.

For deeper architecture notes see [V2_ARCHITECTURE.md](internal/V2_ARCHITECTURE.md).

---

<sub>[← Chapter 4 - Obsidian Integration](OBSIDIAN.md) · [Contents](README.md) · Next: [Chapter 6 - Privacy and Security →](PRIVACY.md)</sub>
