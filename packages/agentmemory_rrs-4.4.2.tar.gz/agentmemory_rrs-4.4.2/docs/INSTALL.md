<sub>[Contents](README.md) · Next: [Chapter 2 - Workflow →](WORKFLOW.md)</sub>

# Chapter 1. Installation

## Before you install

agentmemory is designed for one core moment: you return to a project later and need instant "where were we?" continuity.

It runs passively after setup. You do not need to manually issue remember commands for normal use.

Terminology:
- A **belief** is one memory unit (typically one sentence) extracted from code, docs, git, and conversations.

## Prerequisites

**[uv](https://docs.astral.sh/uv/)** (Python package manager). uv handles Python installation automatically, you do not need Python installed separately.

```bash
# Install uv if you do not have it
curl -LsSf https://astral.sh/uv/install.sh | sh
```

**[Claude Code](https://docs.anthropic.com/en/docs/claude-code)** (or any MCP-compatible agent CLI). agentmemory runs as an MCP server inside the agent.

**[Obsidian](https://obsidian.md)** (optional). For browsing and visualizing the belief graph. Not required for core functionality. See [OBSIDIAN.md](OBSIDIAN.md).

## Step 1: Install agentmemory

```bash
pipx install agentmemory-rrs
```

macOS/Homebrew note: `pip3 install agentmemory-rrs` may fail with
`error: externally-managed-environment` (PEP 668). Use `pipx` instead.

Alternative (install latest from source):

```bash
uv tool install git+https://github.com/robotrocketscience/agentmemory.git
```

Or just give Claude or Codex the link to this repo and ask it to install
agentmemory for you.

Verify it installed:

```bash
agentmemory --help
```

If you get `command not found`, try installing as a tool instead:

```bash
uv tool install git+https://github.com/robotrocketscience/agentmemory.git
```

## Step 2: Run setup

```bash
agentmemory setup
```

This does three things:
1. Writes `/mem:*` slash commands to `~/.claude/commands/mem/`
2. Registers the MCP server in your project's `.mcp.json`
3. Adds PreToolUse hooks to `~/.claude/settings.json` (commit tracking, directive gate)
4. Installs a managed `.git/hooks/pre-push` branch-scope guard for this repo (`type/gh-<issue>-<slug>` for normal work, `release/gh-<issue>-<slug>` for release branches)

## Step 3: Restart Claude Code

Close and reopen Claude Code. The MCP server starts automatically on launch.

## Step 4: Verify it works

In Claude Code, run:

```
/mem:status
```

You should see a status report with belief counts, session info, and system health. If you see an error, check Troubleshooting below.

## Step 5: Onboard your project

```
/mem:onboard .
```

This scans your project directory and ingests structure from git history, code, docs, and configuration. Typically completes in under a minute; larger projects with deep git history may take longer.

What to expect from onboarding output:
- Contextual volume framing (project size -> memory volume), not just a raw count.
- A type breakdown so large numbers are interpretable.
- A brief themed summary: `Here's what I learned about your project:`
- If git is present, temporal context is included from commit history.
- Without `--llm`, onboarding uses the offline classifier (faster, coarser). The output warns when re-running with `--llm` is recommended for higher-quality classification.

That is it. agentmemory will automatically capture decisions, corrections, and context from your conversations.

## Codex (OpenAI) Setup

agentmemory works with any MCP-compatible agent. For Codex on macOS, Linux, or Windows/WSL:

### Install

```bash
# Use --cache-dir if the default uv cache is on a read-only filesystem (common in Codex sandbox)
uv tool install --cache-dir /tmp/uv-cache git+https://github.com/robotrocketscience/agentmemory.git
```

### Register as MCP server

Do NOT run `agentmemory setup` (it writes Claude-specific Claude config). Use the Codex-specific path instead:

```bash
agentmemory setup-codex
```

Verify: `codex mcp list` should show agentmemory as enabled.

If you want to turn on Codex's under-development hooks feature flag for local experimentation:

```bash
agentmemory setup-codex --enable-hooks-feature
```

This only enables Codex's experimental `codex_hooks` feature. It does **not** yet install Claude-equivalent hook behavior, because the public Codex hook schema/path is still under development.

### Integration model

For Codex, the intended architecture is:
- MCP is the primary integration surface
- `.codex/AGENTS.md` is additive fallback guidance
- hooks remain optional and experimental
- parity should center on `search`, `wonder`, and `reason`

### Install Codex fallback automation (agentmemory-aligned)

These commands mirror useful automation patterns while preserving agentmemory's design:
- local-first defaults
- additive/non-destructive config writes
- explicit experimental boundaries for hooks

```bash
# 1) Add managed Codex config defaults in .codex/config.toml
agentmemory sync-codex-config

# 2) Add Codex fallback policy block in .codex/AGENTS.md
agentmemory install-codex-fallback

# 3) Install experimental hook adapter files in .codex/hooks*
agentmemory install-codex-hook-adapter
```

What these commands do:
- `sync-codex-config` adds a managed block for `mcp_servers.agentmemory` and fallback `persistent_instructions` only when not already defined by user config.
- `install-codex-fallback` adds policy guidance for MCP-first memory usage, no-telemetry defaults, and when to use `search`, `wonder`, and `reason`.
- `install-codex-hook-adapter` writes a best-effort adapter that:
  - logs raw hook payloads to `.codex/logs/agentmemory-hook-events.jsonl`
  - writes normalized conversation turns to `.codex/conversation-logs/turns.jsonl` (Claude-compatible JSONL shape)
  - triggers `agentmemory session-complete --log .codex/conversation-logs/turns.jsonl` on stop-like events (best-effort, non-blocking)

To probe the current Codex build for observable hook file loading behavior:

```bash
agentmemory probe-codex-hooks
agentmemory probe-codex-hooks --include-home
agentmemory probe-codex-hooks --surface exec --include-home
```

As of the 2026-04-21 macOS validation, the obvious candidate paths (`.codex/hooks.json`, repo-root `hooks.json`, and `~/.codex/hooks.json`) showed no observable effect on `codex debug prompt-input`, even with `codex_hooks` enabled.

### Onboard

For large repos on WSL-mounted Windows filesystems, onboarding may stall due to slow cross-filesystem I/O. Use a clean clone on native Linux storage:

```bash
# 1. Clone to a Linux-native path
git clone /mnt/c/path/to/your/repo /tmp/onboard-clone

# 2. Force the DB to the real project's hash so it resolves from the real cwd later
AGENTMEMORY_DB=$(python3 -c "
import hashlib; from pathlib import Path
p = str(Path('/mnt/c/path/to/your/repo').resolve())
h = hashlib.sha256(p.encode()).hexdigest()[:12]
print(str(Path.home() / '.agentmemory' / 'projects' / h / 'memory.db'))
") agentmemory onboard /tmp/onboard-clone

# 3. Verify from the real project directory
cd /mnt/c/path/to/your/repo
agentmemory stats
```

### Known WSL friction

- `uv` cache errors (`Read-only file system`): use `--cache-dir /tmp/uv-cache`
- Cross-filesystem hardlink warnings: cosmetic, install still succeeds
- Large repos with many untracked dirs: scanner now uses `git ls-files` (v4.0.2+) which respects `.gitignore`

### Current Codex behavior

- MCP portability works: Codex can attach to the same local `agentmemory` install and project database used by Claude.
- Recommended tool surface in Codex today: `search` for retrieval, `wonder` for research/gap analysis, `reason` for decision support and hypothesis testing.
- Automatic context injection and behavioral hooks are still Claude-first. In Codex today, use MCP tools directly unless you are explicitly experimenting with the `codex_hooks` feature flag and diagnostic adapter.
- Conversation log parity:
  - Claude default: `~/.claude/conversation-logs/turns.jsonl`
  - Codex adapter default: `.codex/conversation-logs/turns.jsonl`
  - Both use the same JSONL turn shape (`event`, `text`, `timestamp`, `session_id`) so `agentmemory ingest <turns.jsonl>` and `agentmemory session-complete --log <turns.jsonl>` work across both CLIs.

## Per-project isolation

Each project gets its own database at `~/.agentmemory/projects/<hash>/memory.db`. The hash is derived from the project's absolute path. The CLI auto-detects the project from cwd.

Override with `--project /path/to/project` or `AGENTMEMORY_DB=/path/to/db.sqlite`.

## Disabling

```bash
# In session:     /mem:disable       (stops tool calls for this session)
# Permanently:    agentmemory uninstall   (removes commands, keeps data)
# Nuclear:        rm -rf ~/.agentmemory/  (deletes all data)
```

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `agentmemory: command not found` | Run `uv tool install git+https://github.com/robotrocketscience/agentmemory.git` or check that `~/.local/bin` is in your PATH |
| `error: externally-managed-environment` on macOS | Use `pipx install agentmemory-rrs` instead of `pip3 install ...` (PEP 668 on Homebrew Python) |
| `/mem:status` returns an error | Restart Claude Code. The MCP server needs a fresh start after setup |
| Slash commands not showing up | Run `agentmemory setup` again, then restart Claude Code |
| MCP tools not responding | Check `.mcp.json` exists in your project root. If not, run `agentmemory setup` from the project directory |
| SQLite lock errors | Run `agentmemory health` to diagnose, or manually clear the WAL: `python3 -c "import sqlite3; sqlite3.connect('~/.agentmemory/projects/<hash>/memory.db').execute('PRAGMA wal_checkpoint(TRUNCATE)')"` |

---

<sub>[Contents](README.md) · Next: [Chapter 2 - Workflow →](WORKFLOW.md)</sub>
