# Plan: Setr Propagation Fix + Lock/Freeze Tier

**Branch:** feat/setr-propagation-lock-tiers
**Date:** 2026-04-21
**Protocol:** FRAME -> RESEARCH -> HYPOTHESIZE -> TEST -> BUILD -> VALIDATE

---

## Context

Two improvements identified through the Wolfeian cosmology gap analysis and validated
by Experiments 109-111:

1. **Gap 7 (Setr):** Low-confidence intermediary nodes broker disproportionate graph
   influence because `propagate_valence` applies flat `VALENCE_DECAY=0.5` per hop
   regardless of the broker's confidence. Exp 109 found 1,626 impostor candidates;
   Exp 111 confirmed edge_count vs confidence is a nonlinear functional relationship
   (xi=0.43).

2. **Gap 5 partial / Exp 110:** The Lock/Freeze distinction -- locked beliefs that have
   never been updated (axiomatic) vs locked beliefs that have been updated (high-inertia)
   -- is empirically grounded. A `LOCK_FREEZE` tier gives the system a named level for
   "high inertia, evidence-changeable" distinct from the future possibility of a truly
   immutable `LOCK_HARD` level.

---

## Item 1: Setr Confidence-Attenuated Propagation

### Hypothesis

H1: A low-confidence node brokering valence propagation should attenuate the signal
proportionally to its confidence. A 0.2-confidence intermediary should pass 20% of the
signal a 0.9-confidence intermediary would pass.

H2: Attenuation is applied at the BROKER (current_id), not the receiver. The rationale:
the broker's confidence determines how much weight its structural connections should carry.
A 0.2-confidence node that accumulated 1,112 edges should not broker 1,112 full-strength
propagation paths.

H3: Hop 1 (seed -> neighbor) also applies broker attenuation. If a low-confidence belief
receives "used" feedback, its downstream propagation should be proportionally weaker. The
seed's confidence IS a measure of how meaningful the signal is to the graph.

### Testable Predictions

Before fix (current behavior):
- Chain A(conf=0.9) -> B(conf=0.2) -> C produces same C_delta as A -> B(conf=0.9) -> C

After fix:
- Chain through B(conf=0.2) produces ~22% of the delta of chain through B(conf=0.9)
- Ratio: C_delta_low / C_delta_high ~= B_low_conf / B_high_conf = 0.2/0.9 = 0.22
- min_threshold still terminates propagation (no change to that behavior)
- Negative propagation (CONTRADICTS) is also attenuated

### Implementation

File: `src/agentmemory/store.py`
Location: `propagate_valence`, inner loop at line ~3106

Current:
```python
propagated: float = current_valence * decay * multiplier
```

After:
```python
# Setr fix: attenuate by broker confidence.
# Low-confidence intermediaries pass less signal -- their structural
# connections reflect historical accumulation, not current authority.
current_conf_row = self._conn.execute(
    "SELECT alpha, beta_param FROM beliefs WHERE id = ?",
    (current_id,),
).fetchone()
broker_confidence: float = 1.0
if current_conf_row is not None:
    a = float(current_conf_row["alpha"])
    b = float(current_conf_row["beta_param"])
    if a + b > 0.0:
        broker_confidence = a / (a + b)
propagated: float = current_valence * decay * multiplier * broker_confidence
```

### Risk Assessment

- Performance: one extra SELECT per frontier item per hop. BFS is bounded by
  max_hops=3 and min_threshold=0.05, so frontier is small. Low risk.
- Correctness: does not affect hop 1 seed's OWN confidence update (that happens in
  `update_confidence`, not here). Only affects propagation to neighbors.
- Regression risk: existing tests assert specific alpha/beta values after propagation.
  Those values will change -- need to update test expectations or use relative assertions.

---

## Item 2: LOCK_FREEZE Tier

### Hypothesis

H4: The current `user` lock level conflates two semantically distinct cases:
  - Truly axiomatic beliefs (identity, physical constants) -- should resist all evidence
  - High-inertia beliefs (strong preferences, validated requirements) -- should resist
    casual noise but yield to multiple independent signals

H5: Adding `LOCK_FREEZE = "freeze"` as a named tier (with identical behavior to current
`user`) creates the semantic label for future differentiation without breaking anything.
Existing `user` locks are unaffected. New beliefs can be created at `freeze` level.

H6: The `freeze` level must behave identically to `user` in all update paths:
  - `update_confidence`: applies LOCKED_EVIDENCE_THRESHOLD check
  - `_apply_valence_update`: blocks propagated beta < 0.5, halves larger
  - Auto-demotion threshold: same as `user` (factual=9.0, etc.)

### Testable Predictions

- A belief created with `lock_level="freeze"` has `locked=True` and `lock_level="freeze"`
- Applying negative valence < threshold to a `freeze` belief leaves confidence unchanged
- Applying sufficient cumulative harmful evidence to a `freeze` belief demotes it
- Existing `user`-locked beliefs behave identically (no regression)
- `propagate_valence` attenuation treats `freeze` same as `user` (locked=True check)

### Implementation

File: `src/agentmemory/models.py`
- Add `LOCK_FREEZE: Final[str] = "freeze"`
- Update docstring on `lock_level` field in Belief to document all 4 values

File: `src/agentmemory/store.py`
- `_apply_valence_update`: treat `freeze` same as `user` (check `lock_level in ("user", "freeze")`)
- `update_confidence`: treat `freeze` same as `user` for threshold checks and demotion
- `freeze_belief()`: new method (or extend `lock_belief()` with `level` param)
- DB migration: no data changes needed; `freeze` is additive

### Risk Assessment

- Breaking change risk: NONE -- `freeze` is additive. All existing `user` paths unchanged.
- The `is_user_locked` variable in `update_confidence` must be renamed/expanded to cover
  both `user` and `freeze` or a new `is_high_inertia` boolean introduced.
- MCP server: `lock()` tool may need to expose the `level` parameter.

---

## Execution Order

1. Write failing tests (both items)
2. Run tests -- confirm they fail
3. Implement Item 1 (Setr) -- simpler, one function
4. Run Item 1 tests -- confirm green
5. Implement Item 2 (freeze tier) -- models + store
6. Run Item 2 tests -- confirm green
7. Run full regression suite
8. Commit each item atomically
