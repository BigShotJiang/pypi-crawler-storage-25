# Codex macOS validation: existing agentmemory install reused across clients

Date: 2026-04-21
Status: validated
Scope: local macOS dev build, existing onboarded project, existing local `agentmemory` install

## Summary

This validation tested whether an existing `agentmemory` installation that was already in active use with Claude could be reused by ChatGPT Codex without rebuilding the knowledge graph or changing the database location.

Result: **yes for MCP portability and graph continuity; not yet yes for automatic hook parity.**

Codex successfully attached to the same local `agentmemory` executable and the same existing project database after MCP registration and a Codex session restart. The existing knowledge graph remained intact and queryable. Claude-specific hook behavior did not transfer automatically because that hook layer was installed in Claude's config, not Codex's.

## What was validated

1. `agentmemory` was already installed locally and functional before the Codex session began.
2. The same local executable was registered with Codex as an MCP server.
3. After restart, Codex could call the live `agentmemory` MCP server.
4. The onboarded project database was reused rather than recreated.
5. The existing knowledge graph was readable from Codex with no migration step.

## Evidence observed

- Codex MCP registration succeeded against the already-installed local binary.
- After restart, the `agentmemory` MCP server was visible to the session and responded to `status`.
- The project database resolved to the existing hashed project DB, not a fresh empty store.
- Returned inventory showed a populated graph with pre-existing beliefs, edges, sessions, and observations.

## What did not transfer

Claude-side automatic behavior did not carry over automatically:

- session-start injection
- per-prompt auto-retrieval
- Claude PreToolUse guard commands
- Claude conversation logging hooks

This was not a database or MCP failure. It was a client integration difference: the installed Claude hooks live in Claude config, while Codex currently only had MCP registration.

## Current interpretation

`agentmemory` already demonstrates **cross-client continuity at the MCP and database layer** on macOS. That is the hard portability claim: one local install, one graph, multiple agent clients.

The remaining gap is **behavioral automation parity**. Claude has a mature hook path in this project. Codex exposes an under-development `codex_hooks` feature flag, but stable public hook wiring is not yet documented or validated here. Today, Codex can use the same graph immediately, but proactive memory injection remains experimental rather than production-ready.

## Practical conclusion

This validation supports the claim that `agentmemory` is not tied to a single chat client's native memory system. A user can move from Claude to ChatGPT Codex on the same machine and reconnect to the same persistent graph with minimal interruption.

The claim that still requires further work is stronger: matching Claude's automatic hook-driven experience inside Codex. That should be treated as a separate experimental track.
