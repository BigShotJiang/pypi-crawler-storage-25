# Citations

## Primary Research Sources

```bibtex
@misc{lin_agentic_memory_2026,
  author       = {Leonard Lin},
  title        = {agentic-memory: Agentic Memory Research Collection (Summaries and Analyses)},
  year         = {2026},
  howpublished = {GitHub repository},
  url          = {https://github.com/lhl/agentic-memory},
}
```

## Related Work (Independent, Concurrent)

The following work was discovered after independent development of agentmemory's
belief graph architecture. The convergence on similar design decisions from
independent starting points suggests these are natural design choices for
Bayesian belief graph systems.

```bibtex
@misc{nikooroo_belief_graphs_2025,
  author       = {Saleh Nikooroo and Thomas Engel},
  title        = {Belief Graphs with Reasoning Zones: Structure, Dynamics, and Epistemic Activation},
  year         = {2025},
  eprint       = {2510.10042},
  archivePrefix = {arXiv},
  primaryClass = {cs.AI},
  url          = {https://arxiv.org/abs/2510.10042},
  note         = {Discovered 2026-04-20 after independent development of agentmemory. Shared concepts: directed signed weighted belief graphs, contractive confidence propagation, structurally balanced reasoning zones, typed SUPPORTS/CONTRADICTS edges. See experiments/exp\_099\_arxiv\_mapping.py for detailed comparison.},
}
```
