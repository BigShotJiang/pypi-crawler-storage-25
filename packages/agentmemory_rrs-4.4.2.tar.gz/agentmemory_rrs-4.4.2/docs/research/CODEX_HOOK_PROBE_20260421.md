# Codex hook probe hypotheses and results

Date: 2026-04-21
Build: Codex CLI 0.122.0 on macOS

## Hypotheses

1. Codex experimental hooks are gated by the `codex_hooks` feature flag, not by the installer transport (`npm`, `npx`, Homebrew).
2. If a candidate `hooks.json` path is active, replacing it with malformed JSON should change observable behavior in `codex debug prompt-input`.
3. The most likely initial candidate paths are:
   - project `.codex/hooks.json`
   - project `hooks.json`
   - user `~/.codex/hooks.json`

## Test method

- Capture a baseline from `codex debug prompt-input --enable codex_hooks`.
- For each candidate path, temporarily write malformed JSON.
- Re-run the same debug command.
- Compare exit code, stdout, and stderr against baseline.

This probe is now codified as:

```bash
agentmemory probe-codex-hooks
agentmemory probe-codex-hooks --include-home
```

## Results

Observed result on this build:

- project `.codex/hooks.json`: no effect detected
- project `hooks.json`: no effect detected
- user `~/.codex/hooks.json`: no effect detected

## Interpretation

The negative result does **not** prove Codex hooks are non-functional. It narrows the space:

- the active path may be different
- the debug surface may not apply hooks
- the runtime may require a valid schema before hook loading is observable
- the current build may expose the feature flag before the full hook lifecycle is active

## Consequence for agentmemory

`agentmemory` should treat Codex hook support as experimental and probe-driven, not assume Claude-style path parity. The stable path today is:

- use MCP for cross-client graph reuse
- expose `setup-codex` for Codex MCP registration
- expose `probe-codex-hooks` for empirical validation on each Codex build
