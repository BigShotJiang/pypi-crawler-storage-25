# Changelog

## [Unreleased]

## [4.4.2] - 2026-04-22

### Fixed
- Wheel packaging now includes the four public hook scripts required by `agentmemory setup` and related hook-install paths: `check-commit-msg.py`, `agentmemory-gh-pii-guard.sh`, `pre-push-branch-scope.sh`, and `commit-msg-issue-scope.sh`.
- Hatch build config now excludes local virtualenv/build directories from source distributions, preventing sdists from accidentally capturing `venv/` or `.venv/` contents during release builds.

## [4.4.1] - 2026-04-22

### Added
- `check-commit-msg.py` appends `, authored by <model> <effort>` to commit subjects when `AGENTMEMORY_LLM_MODEL` is set — works for Claude and Codex (GH-71).
- `commit-msg-issue-scope.sh` installed by `agentmemory setup`: appends `(GH-N)` to unscoped subjects on issue branches, blocks cross-issue commits (GH-75).
- GitHub repo hardening: branch protection on main, CODEOWNERS, structured issue templates, `pr-validation.yml` CI rejects PRs missing closing issue ref or non-conforming branch names (GH-27).
- DB ownership marker sidecar file detects when two agentmemory processes share the same project DB (partial GH-84).

### Changed
- Hook injections now enforce a 3,000-char total budget with priority packing; individual beliefs truncated at 200 chars. SessionStart reduced from ~7K to ~2.5K chars (GH-72).
- Removed `LENGTH(content) > 100` scoring bonus that rewarded verbose beliefs (GH-72).
- Retrieval `adaptive_expansion` mode skips HRR/BFS cold-start on broad prompts with strong FTS results (partial GH-83).
- Codex search path is now read-only (no write-side bookkeeping during Codex retrieval).

### Fixed
- Publish script hardened with comprehensive preflight checks: branch, clean tree, version match, CHANGELOG, tests, pyright, PII scan. Reports all issues at once (GH-72).

## [4.4.0] - 2026-04-22

### Added
- Default post-onboard themed summary in MCP `onboard()` output ("Here's what I learned about your project"), with grouped topic bullets (GH-61).
- Onboarding summary now includes git temporal-context messaging when git history is present (GH-60).

### Changed
- Setup completion output now states passive behavior explicitly: agentmemory learns automatically, no manual remember commands required (GH-56).
- Setup completion output now includes a user-facing glossary line defining "belief" as a memory unit (GH-54).
- Onboarding summary adds volume framing (beliefs vs extracted nodes) to contextualize large counts (GH-55).
- Offline onboard path now emits an explicit quality caveat and `--llm` recommendation in MCP output (GH-58).
- `--llm` flag guidance remains explicit in CLI help/output and install docs (GH-57).

### Fixed
- `/clear` resume continuity hardening: bounded `resume_state` output and strict max chars to prevent large context spikes on recovery flows (GH-63).
- `agentmemory setup` now normalizes legacy Claude `PreToolUse` shapes into valid `matcher + hooks[]` schema (GH-64).
- `agentmemory setup` now merges/repairs existing `.mcp.json` instead of failing when file already exists (GH-51).
- Setup smoke test now degrades gracefully when `uv` is missing or not executable (GH-52).

## [4.3.0] - 2026-04-21

### Added
- PreToolUse agent gate hook for agentmemory-first enforcement (GH-30).
  Reminds agents to search agentmemory before spawning exploration subagents.
- `agentmemory setup` now registers the agent gate hook automatically (GH-31).
- Root conftest for test isolation and auto-marking (GH-25).
- pytest-xdist support and test category marks (GH-25).
- Hook search latency benchmarks (GH-21).

### Fixed
- `lock_level` missing from `update_confidence` query (GH-34).
- Test fixture content leaking into conversation ingestion (GH-24).
- Correction classifier false positives: threshold raised from 1 to 2 signals (GH-17).

### Performance
- Search pipeline optimization: 194ms -> 45ms avg on 17K beliefs (GH-26).
  Top-level imports, HRR IN-clause reduced from 20 to 5, FTS5 LIMIT 50->20,
  cluster+supersession merged into single UNION ALL query, entity search
  skip when FTS5 covers user_corrected hits.

### Docs
- Architecture: corrected retrieval pipeline description to 9 layers (was 7).
- README: updated test count (1250+), accurate latency claims.
- Cleaned up GitHub issue comments referencing private repo branches (GH-29).

## [4.2.0] - 2026-04-21

### Added
- Two-axis document taxonomy: `doc_class` field on beliefs, source types
  `authoritative_reference`, `academic`, `codebase` with tuned decay/weight (GH-22).
- AST extraction: docstrings, function signatures, class definitions, and
  module-level constants extracted from Python code. New edge types DOCUMENTS
  and DEFINES link code structure to beliefs (GH-19).
- `data_source` traceability through ingest pipeline: beliefs carry provenance
  tag (python_ast, git_log, markdown, directive) (GH-19).
- Selective constraint injection: Zone 2 filters locked beliefs by prompt
  relevance with VERIFY framing instead of flat list (GH-17 CS-028).
- Cross-session correction retention test (GH-17).
- Telemetry report script (`scripts/telemetry-report.py`) with structured
  metrics for belief lifecycle, feedback loop, correction retention, hook
  latency, session productivity, and token efficiency.
- Pre-release protocol, design protocol, and glossary (internal docs).

### Fixed
- Session creation gap: `ingest_jsonl` was passing `session_id=None` instead
  of wiring through the parsed value. Added `ensure_session` for FK safety (GH-16).
- CLI ingest database locked: batched `ingest_jsonl` in a single transaction,
  added exponential backoff retry in CLI command (GH-18).
- Correction-search during bulk ingest unguarded by `bulk` flag, causing O(n^2)
  timeout on large conversation replays.
- Multimetric voting created edges TO locked beliefs (regression).
- `todo` missing from known belief types in obsidian validation test.
- Evidence-based demotion uses weighted evidence sum, not event count (GH-17).

## [4.1.0] - 2026-04-21

### Added
- Enforcement triad: directive detection, compliance audit, selective injection.
  Closes the knowing-doing gap between injected beliefs and verified compliance.
  26 tests for H1/H2/H3 hypotheses.
- Natural language sentiment feedback: "ok good" strengthens retrieved beliefs,
  "no that's wrong" weakens them. Runs automatically on every user prompt via
  the UserPromptSubmit hook. No explicit feedback commands needed.
- Correction frequency detection: multiple negative signals in a window produce
  a stronger negative signal than any single message.
- Compliance audit in session-end hook: checks locked beliefs with
  machine-verifiable predicates (file_contains, config_value, command_succeeds).
  Violations recorded in tests table, surfaced at next SessionStart.
- Directive detection in UserPromptSubmit hook: imperative user language
  auto-creates TODO beliefs, escalates after repeated unresolved directives.
- `DERIVED_FROM` edge type for causal belief provenance chains.
- `scope` field on beliefs: project, global, end_user_facing, developer_internal.
- Auto-reclassification flag: beliefs flagged when confidence drops below 0.5
  or CONTRADICTS edge is created. Locked beliefs exempt.
- Belief age warnings in SessionStart injection for locked beliefs > 14 days old.
- Injection-time contradiction scan: pairwise check of locked beliefs before
  injection, surfaces conflicts as LOCKED BELIEF CONTRADICTIONS.
- Unresolved directive surfacing at SessionStart.
- Threshold tuning tests: generalizable validation of Jaccard, sentiment,
  reclassification, and compliance thresholds across arbitrary projects.
- pytest-timeout (30s default) for fail-fast test execution.

### Changed
- Relationship detector: locked beliefs now participate in contradiction
  detection with higher threshold (0.5 Jaccard, 3 votes multimetric).
  Previously hard-skipped entirely.
- Locked beliefs no longer block indirect valence propagation. Signals
  below 0.5 filtered as noise; stronger signals attenuated by 50%.
- Belief `confidence` field now auto-computed via `__post_init__` with
  default value, preventing crashes on manual construction.
- Jaccard threshold constants made public (MIN_JACCARD, MIN_JACCARD_LOCKED).

### Fixed
- Sentiment feedback timing: runs before pending_feedback is cleared,
  not after (was functionally dead).
- `__directive__` markers in pending_feedback no longer cause FK violations
  in the feedback processing loop.
- CI: directive gate file tests skip gracefully when scripts/ is excluded
  from the public repo.

## [4.0.3] - 2026-04-20

### Changed
- Supersession: locked beliefs are no longer immune. Time is the ultimate
  arbiter -- newer belief wins if Jaccard >= 0.5 (locked) or >= 0.4 (unlocked).
  No source-type gating. Fixes stale-locked-belief accumulation bug.
- Publish script: added `--yes` flag and non-interactive auto-confirm for
  agent/CI use. Non-TTY stdin auto-confirms without prompting.

## [4.0.2] - 2026-04-20

### Added
- `todo` belief type: forward-looking intentions ("need to add X", "plan to
  fix Y") are now first-class beliefs. 4-week half-life, dedicated "OPEN TODOs"
  zone in hook search injection. Lifecycle: open -> done (valid_to) -> dropped
  (superseded_by). Classified by keyword heuristics and LLM pipeline.
- TB-07: retrieval failure notice. When hook search finds no beliefs, injects
  "No beliefs found" instead of silently proceeding.
- TB-09: contradiction surfacing. When retrieved beliefs have CONTRADICTS edges,
  they appear as "CONTRADICTIONS (resolve before proceeding)" in the injection.
- Codex + Windows/WSL installation instructions in docs/INSTALL.md and README.
- Hook injection telemetry: SessionStart and UserPromptSubmit hooks record
  chars injected, belief count, contradictions, and latency per invocation.

### Fixed
- Scanner: git worktrees now detected (`.git` file, not just directory).
- Scanner: uses `git ls-files` for file discovery in git repos, respecting
  `.gitignore` and avoiding recursive walks over untracked directories.
- `test_scanner.py` session-scoped fixture: 13.7s -> 1.7s.
- CLAUDE.md: replaced overclaimed "All 15 TBs implemented" with accurate
  breakdown (8 hook-enforced, 4 self-enforced, 3 deferred).
- README: replaced "7-layer search" with "multi-layer search" (actual count
  is 8 with layers 1.5 and 1.7).

## [4.0.1] - 2026-04-20

### Fixed
- CLI commands that only read (wonder, search, stats, health, core, locked,
  stale, timeline, evolution, diff) now open the database in readonly mode.
  Prevents "database is locked" errors when the MCP server holds a write
  transaction.
- Added busy_timeout (5s) to readonly connections for resilience during WAL
  checkpoints.
- `record_edge_traversal` and `expand_graph` commit now skip in readonly mode.

## [4.0.0] - 2026-04-20

Graph topology overhaul. Beliefs are now linked chronologically within sessions,
traversal uses explore/exploit sampling, and relationship detection uses
multi-metric voting instead of single-threshold matching. Production graph went
from 5,396 orphans to 966, median degree 3 to 5, with 60K+ edges across 5 typed
relationships.

### Added
- `build_temporal_backbone()` + `link_temporal()` in store.py: chronological
  belief linking within sessions. Creates TEMPORAL_NEXT edges ordered by
  event_time, with gap-based weight decay for session boundaries.
- `detect_relationships_multimetric()` in relationship_detector.py: 3-metric
  voting (Dice, overlap coefficient, cosine TF) with majority-rule edge
  creation. Replaces single-metric threshold approach.
- Thompson Sampling in `expand_graph()`: Beta(alpha, beta) sampling per edge
  for explore/exploit traversal. High-variance priors explore unknown edges;
  well-scored edges exploit. No tuning parameter needed.
- `rebuild-temporal` CLI command: rebuild all TEMPORAL_NEXT edges from scratch.
- `rebuild-semantic` CLI command: rebuild RELATES_TO edges via multi-metric
  voting across all beliefs.
- Temporal linking on ingest: new beliefs auto-linked to session predecessor.
- Temporal backbone built after onboarding bulk imports.
- 20 new tests: 12 for temporal backbone, 8 for multi-metric voting.
- 14 experiments (85-108): semantic edge validation, composite scoring, metric
  geometry, HRR correlation, topology metrics, arxiv mapping, sub-clusters,
  credal gap, multi-metric voting, temporal locality, A* exploration (ruled
  out), connectivity mapping, temporal backbone.
- docs/research/CITATIONS.md: concurrent independent work citation (arxiv
  2510.10042).

### Changed
- Publish script rewritten for reliable filtered push with hard-reset
  restoration.
- Docs reorganized: benchmarks/, internal/ subdirectories under docs/.
- workers/ moved under src/.
- README: added "You Need This If" use case table.

### Fixed
- authlib bumped 1.6.9 to 1.7.0 (security fix).
- Case study narrative accuracy corrections.
- PHILOSOPHY.md overclaim removed.

### Security
- authlib 1.7.0 (CVE fix in upstream).

## [3.0.2] - 2026-04-20

### Changed
- README: universal opener, emphasis/formatting pass, "Problem Is Bigger Than You Think" section, Bayesian inference link, user-facing language for technical details.
- Repo reorganization: research/ to docs/research/, website-content/ to docs/website/, CLAIMS-AUDIT files to docs/audits/.
- New docs: PHILOSOPHY.md (high-context analogy, "Why Files Aren't Enough"), RELEASE.md (runbook), expanded CONTRIBUTING.md.
- CLAUDE.md: added contributor disclaimer separating user vs contributor concerns.
- Removed all em dashes from documentation.

## [3.0.1] - 2026-04-20

### Changed
- Complete README rewrite: visceral opening, install at line 10, github-push example moved above fold, killed generic before/after table, added compatibility section, added /mem:stats visibility block.
- PyPI description updated to match new positioning.

## [3.0.0] - 2026-04-20

Cross-project shared scopes and automatic update notifications. Beliefs can now
flow between projects without data duplication, and users get notified when a
newer version is available.

### Added
- `shared_scopes.py`: cross-project belief sharing via SQLite ATTACH federation. Separate DB per scope under `~/.agentmemory/shared/{scope}/`. Content-hash dedup prevents duplicates.
- 2 new MCP tools: `share_belief` (copy belief to a shared scope), `manage_scopes` (list/subscribe/unsubscribe/create scopes)
- Hook search Layer 6: automatically queries subscribed shared scopes with budget 3 per scope (Exp 98 Config B)
- `update_check.py`: PyPI version check with 24-hour file cache, 2-second timeout, silent on failure
- SessionStart hook integration: shows "Update available: vX.Y.Z -> vA.B.C" when outdated
- README "Under the Hood" section: real example of 7-layer search pipeline and 4-zone context injection
- Exp 97: cross-project retrieval via ATTACH (100% recall, 0% top-5 contamination, 1.06x latency)
- Exp 98: scope-aware scoring comparison (4 configs; Config B 12/3 wins)
- 19 new tests in test_shared_scopes.py

### Fixed
- README benchmark table: added missing LoCoMo (50.8%) entry
- README layer count: corrected "6-layer" to "7-layer" after Layer 6 addition

## [2.5.0] - 2026-04-20

Retrieval quality overhaul: beliefs that answer the question now outrank beliefs
that just match keywords. Three new retrieval layers, two new modules, zero
breaking changes.

### Added
- `intention.py`: intention-space clustering for vocabulary-gap bridging (Exp 94b: 98% of same-cluster pairs share <10% vocab). Hook search Layer 1.7 expands FTS5 results by pulling same-cluster beliefs.
- `multimodel.py`: archaeology-style Bayesian model selection (SIGNAL/NOISE/STALE/CONTESTED) from Wikipedia Bayesian inference framework. Applied as 0.6-1.3x multiplier on beliefs with feedback; neutral on beliefs without.
- Precomputed HRR neighbors: `hrr_neighbors` table populated during graph build. Hook search Layer 1.5 now does SQL JOIN (0.03ms) instead of skipping HRR entirely.
- `belief_clusters` table for intention cluster assignments, rebuilt on graph changes.
- `HRRGraph.node_ids()` and `HRRGraph.has_node()` public API methods.
- Exploration sampling: 3 random never-feedback beliefs added to pending_feedback per search for long-tail coverage.
- Exp 92: Lagrangian factorial sweep (2 kinetic x 3 potential energy definitions)
- Exp 93/93b/93c: multi-model Bayesian scoring experiments
- Exp 94: HRR performance profiling (bottleneck identified: cleanup memory cosine, not FFT)
- Exp 94b: intention-space clustering (97.9% vocab gap in same-cluster pairs)
- Exp 95: entity layer scoring calibration (relevance-gated weights)
- Exp 96: hierarchical clustering (k=40 drops mega-cluster from 81% to 29%)
- 34 new tests across test_hrr_hook_path.py, test_intention.py, test_multimodel.py

### Fixed
- Relevance-gated type/source weights: correction (2.0) * user_corrected (1.5) compound boost now interpolated by query term overlap. Irrelevant corrections no longer dominate results. Entity scores dropped from 43x to 14-22x.
- O(n^2) intention cluster self-join rewritten as subquery (16.7s -> 150ms per query).
- Intention cluster count increased from k=8 to k=40 (Exp 96: largest cluster 81% -> 29%).
- `score_belief()` extended with `ignored_count` and `harmful_count` params (backwards compatible, default 0).

### Changed
- Hook search Layer 1.5 upgraded from edge-only traversal to precomputed HRR neighbors with edge fallback.
- PyPI package renamed to `agentmemory-rrs` with `tool.hatch.build.targets.wheel` config.

## [2.4.1] - 2026-04-19

### Added
- Exp 90: Jacobian + Hamiltonian scoring dynamics analysis
- Exp 90 post-fix validation (Gini 0.026 -> 0.148, 5.7x improvement)

### Fixed
- CI lint: ruff format entire codebase, resolve pyright strict errors in hrr.py
- Exclude benchmarks/ and scripts/ from pyright strict (not production code)

## [2.4.0] - 2026-04-19

### Added
- Exploratory wonder: 3 new MCP tools (wonder, wonder_ingest, wonder_gc)
- Gap analysis, parallel subagent research, speculative belief ingestion
- TTL-based garbage collection for unvalidated speculative beliefs
- UCB exploration bonus for under-retrieved beliefs (Fix 4)

### Fixed
- Confidence differentiation (Fixes 2-5):
  - Fix 2: Source-type decay modifiers (agent-inferred 0.5x, user-corrected 2.0x half-life)
  - Fix 3: First-signal amplification (3x weight on first feedback event)
  - Fix 4: UCB exploration bonus (under-retrieved beliefs surface for feedback)
  - Fix 5: Asymmetric feedback weights (harmful=-2.0, weak=-0.6, ignored=-0.1)

## [2.3.2] - 2026-04-19

### Added
- onboard: `use_llm` parameter to opt into LLM classification during bulk ingest (default False keeps zero-LLM path)

### Maintenance
- Documentation: refresh stale counts (tests, MCP tools, modules) and URLs across CLAUDE.md, TODO.md, INSTALL.md

## [2.3.1] - 2026-04-19

### Fixed
- onboard end-to-end: scan, classify, and create beliefs in a single pipeline (previously stopped after scan)
- workers: PII leaked through diff-based guard path; guard now operates on full tracked content
- PII sanitization: complete case-insensitive pass across tracked files; pre-push guard enhanced to block remaining variants

## [2.3.0] - 2026-04-19

### Fixed
- Bayesian score inflation: deflate insertion priors for agent-inferred content
- Complete case-insensitive PII sanitization for public release
- Remove diff-based guard check, fix workers PII
- Sanitize filesystem paths in error messages

### Added
- `recalibrate_scores()` with 13 diagnostic tests for score inflation
- 3-tier `lock_level` schema (none/promoted/user)
- `--tier` and `--max-beliefs` filters for Obsidian sync
- 27 acceptance tests for case studies CS-012 through CS-035
- 25 acceptance tests for REQ-003/023/024/025/026/027
- 181 tests for scoring, correction_detection, classification
- 19 validation tests for open design questions
- REQ-015/016 claims audit (20 claims, zero unverified) + LIMITATIONS.md

### Changed
- Wire `recalibrate` into CLI and MCP server
- Close all open research questions (R2/R3/D1/D2/D3/F4/F5/C1)
- Set `ingest.use_llm` default to False
- Add ruff to dev dependencies for pre-commit hooks

### Security
- Full PII sanitization sweep across tracked files ahead of public release

## [2.2.2] - 2026-04-19

### Fixed
- vault_store: rebuild_index() now runs in a single transaction (crash mid-rebuild rolls back instead of corrupting index)
- server: global buffers (_retrieval_buffer, _signal_buffer, _explicit_feedback_ids) now bounded to prevent unbounded memory growth
- store: clear_pending_feedback() respects transaction context (was committing prematurely)
- store: flush implicit transaction before BEGIN IMMEDIATE in transaction()

### Security
- Database files now set to 0600 permissions on open (was 644)

## [2.2.1] - 2026-04-18

### Fixed
- Hook feedback now records outcomes to test_results table. The hook-based search was updating alpha/beta directly but not recording outcomes, making "used" detection invisible to trend measurement (0% used rate since Apr 15 despite active hook usage).

### Maintenance
- Deleted 26 stale branches fully merged into main

## [2.2.0] - 2026-04-18

### Added
- Structural prompt analysis (Layer 0) in hook_search -- detects 6 task types (planning, deployment, debugging, implementation, validation, research) and subagent suitability from prompt structure (90.5% accuracy, 3.4x over keyword baseline)
- activation_condition evaluation -- previously dead schema field now has live predicate logic (task_type, keyword_any/all, structural, subagent predicates with AND/OR operators)
- Edge-based vocabulary expansion (Layer 1.5) in hook_search -- traverses graph edges from FTS5 hits to bridge directive vocabulary gaps without numpy overhead
- L1 behavioral beliefs injected at SessionStart -- high-confidence unlocked procedural beliefs now surface alongside locked (L0) beliefs
- 23 new integration tests for structural analysis and activation_condition

### Performance
- Onboard: batch graph edge inserts (single transaction vs 21k individual commits)
- Onboard: skip FTS5 relationship checks during bulk ingest, defer commits
- Onboard: eliminate double markdown render and atomic temp files during vault sync
- Structural analysis latency: 0.02-0.10ms (effectively free)
- Full hook pipeline: 45-82ms against 15K beliefs (within 100ms budget)

### Added (Infrastructure)
- Project isolation verification tests (CS-030)
- End-to-end timing breakdown in onboard output

## [2.1.0] - 2026-04-18

### Fixed
- Add CLI `ingest` subcommand -- PostCompact hook called `agentmemory ingest` but the command did not exist, blocking all conversation-to-belief ingestion from daily usage
- Clear pending_feedback entries after auto-feedback processing -- rows accumulated indefinitely (1,436+ stale entries) because processed feedback was never deleted

### Verified (not broken)
- VaultStore write-through is functional -- beliefs created via MCP server are written to Obsidian vault .md files automatically
- Bayesian confidence updates are wired -- record_test_result() calls update_confidence() which updates alpha/beta
- Edge creation during daily usage is wired -- detect_relationships() runs for every belief created via ingest_turn()

## [2.0.0] - 2026-04-18

### Added
- Obsidian vault integration (VaultStore, sync, import, export)
- Uncertainty module with multi-dimensional confidence vectors
- Graph metrics and visualization
- Telemetry (opt-in, local-only)
- Hook search for SessionStart/UserPromptSubmit context injection
- Deduplication engine
- Document linker for cross-referencing project docs
- Email ingest worker (Cloudflare)
- Wonder/Reason deep research pipelines
- CITATION.cff for academic citation

### Changed
- Architecture: vault-first with SQLite as derived index
- Version bump from 1.x to 2.0.0

## [0.1.0] - 2026-04-14

### Added
- SQLite-backed persistent memory with WAL mode and crash recovery
- Bayesian confidence tracking (Beta-Bernoulli model with Thompson sampling)
- FTS5 full-text search with BM25 ranking
- HRR (Holographic Reduced Representations) vocabulary bridge for structural retrieval
- BFS multi-hop graph traversal with edge-type weighting
- 7 edge types: SUPERSEDES, CONTRADICTS, SUPPORTS, CALLS, CITES, TESTS, IMPLEMENTS
- Locked beliefs (non-negotiable constraints) with L0 auto-loading
- Correction detection (92% accuracy, zero-LLM)
- LLM classification via Anthropic Haiku (99% accuracy, $0.005/session)
- Type-aware compression (55% token savings)
- Content-aware temporal decay with velocity scaling
- Project onboarding scanner (9 extractors)
- MCP server (19 tools) for Claude Code integration
- CLI with 23 commands
- Per-project database isolation
- 285 tests passing, pyright strict mode
