"""GH-34: Locked beliefs must be changeable by evidence.

Locked beliefs should have a HIGHER threshold for updating (resist casual
noise), but must NOT be immune to evidence. The robotrocketscience case
study proved that immunity causes real failures.

Pass criteria:
- Harmful feedback with sufficient weight updates locked belief confidence
- Harmful feedback below threshold does NOT update locked belief confidence
- Accumulated harmful evidence can demote a user-locked belief
- "used" feedback reaffirms locked beliefs (resets demotion baseline)
"""

from __future__ import annotations

from pathlib import Path

from agentmemory.store import MemoryStore

import pytest


@pytest.fixture()
def store(tmp_path: Path) -> MemoryStore:
    db_path = tmp_path / "test.db"
    s = MemoryStore(str(db_path))
    s.ensure_session("test-session")
    return s


def _insert_locked(
    store: MemoryStore,
    content: str,
    lock_level: str = "user",
    alpha: float = 19.0,
    beta_param: float = 1.0,
    source_type: str = "user_corrected",
) -> str:
    """Insert a locked belief and return its ID."""
    belief = store.insert_belief(
        content=content,
        belief_type="factual",
        source_type=source_type,
        alpha=alpha,
        beta_param=beta_param,
        locked=True,
        lock_level=lock_level,
        session_id="test-session",
    )
    return belief.id


class TestLockedEvidenceThreshold:
    """Evidence above threshold must change locked beliefs."""

    def test_harmful_above_threshold_updates_beta(self, store: MemoryStore) -> None:
        bid = _insert_locked(store, "Test locked belief")
        old = store.get_belief(bid)
        assert old is not None
        old_beta = old.beta_param

        store.update_confidence(bid, "harmful", weight=3.0)

        updated = store.get_belief(bid)
        assert updated is not None
        assert updated.beta_param > old_beta, (
            "Harmful feedback above threshold must increase beta for locked beliefs"
        )

    def test_harmful_below_threshold_does_not_update(self, store: MemoryStore) -> None:
        bid = _insert_locked(store, "Test locked belief low weight")
        old = store.get_belief(bid)
        assert old is not None
        old_beta = old.beta_param

        store.update_confidence(bid, "harmful", weight=1.0)

        updated = store.get_belief(bid)
        assert updated is not None
        assert updated.beta_param == old_beta, (
            "Harmful feedback below threshold must NOT update locked beliefs"
        )

    def test_used_feedback_reaffirms(self, store: MemoryStore) -> None:
        bid = _insert_locked(store, "Test locked reaffirmation")
        old = store.get_belief(bid)
        assert old is not None
        old_alpha = old.alpha

        store.update_confidence(bid, "used", weight=1.0)

        updated = store.get_belief(bid)
        assert updated is not None
        assert updated.alpha >= old_alpha, (
            "Used feedback must reaffirm locked beliefs (alpha non-decreasing)"
        )


class TestLockedDemotion:
    """Accumulated evidence must be able to demote locked beliefs."""

    def test_accumulated_harmful_demotes_user_locked(self, store: MemoryStore) -> None:
        bid = _insert_locked(store, "Test demotion under evidence")

        # Apply repeated harmful feedback above threshold to exceed demotion threshold.
        # Default factual demotion threshold is 15.0 (from _USER_LOCK_DEMOTION_THRESHOLDS).
        for _ in range(6):
            store.update_confidence(bid, "harmful", weight=3.0)

        updated = store.get_belief(bid)
        assert updated is not None
        assert updated.lock_level != "user", (
            "Accumulated harmful evidence must demote user-locked to promoted"
        )

    def test_promoted_locked_not_immune_to_ignored(self, store: MemoryStore) -> None:
        bid = _insert_locked(
            store,
            "Test promoted receives ignored feedback",
            lock_level="promoted",
            alpha=5.67,
            source_type="agent_inferred",
        )
        old = store.get_belief(bid)
        assert old is not None
        old_beta = old.beta_param

        store.update_confidence(bid, "ignored", weight=1.0)

        updated = store.get_belief(bid)
        assert updated is not None
        assert updated.beta_param > old_beta, (
            "Promoted-locked beliefs must receive 'ignored' feedback updates"
        )
