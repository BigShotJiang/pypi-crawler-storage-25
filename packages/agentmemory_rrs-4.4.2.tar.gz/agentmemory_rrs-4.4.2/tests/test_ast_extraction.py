"""TDD tests for AST extraction of docstrings, signatures, classes, constants (GH-19).

These tests verify that extract_ast_calls() produces the expected node types
and edge types for code-structure queries.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from agentmemory.scanner import Edge, Node, extract_ast_calls


@pytest.fixture()
def py_project(tmp_path: Path) -> Path:
    """Create a minimal Python project with docstrings, classes, constants."""
    src: Path = tmp_path / "src"
    src.mkdir()

    (src / "models.py").write_text(
        '"""Model definitions for the data layer."""\n'
        '\n'
        'from __future__ import annotations\n'
        '\n'
        'MAX_RETRIES: int = 3\n'
        'DEFAULT_TIMEOUT: float = 30.0\n'
        '_private_var: str = "not a constant"\n'
        '\n'
        '\n'
        'class BaseModel:\n'
        '    """Abstract base for all domain models."""\n'
        '\n'
        '    def validate(self) -> bool:\n'
        '        """Check invariants before persistence."""\n'
        '        return True\n'
        '\n'
        '\n'
        'class User(BaseModel):\n'
        '    """A user in the system with role-based access."""\n'
        '\n'
        '    def __init__(self, name: str, role: str = "viewer") -> None:\n'
        '        self.name = name\n'
        '        self.role = role\n'
        '\n'
        '\n'
        'def create_user(name: str, role: str = "viewer") -> User:\n'
        '    """Factory function for creating validated users."""\n'
        '    user = User(name, role)\n'
        '    user.validate()\n'
        '    return user\n',
        encoding="utf-8",
    )

    return tmp_path


# ---------------------------------------------------------------------------
# Node type tests
# ---------------------------------------------------------------------------


class TestDocstringExtraction:
    """Docstrings should be extracted as 'docstring' nodes."""

    def test_module_docstring_extracted(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        docstring_nodes: list[Node] = [n for n in nodes if n.node_type == "docstring"]
        module_docs: list[Node] = [
            n for n in docstring_nodes if "module" in n.id or "models" in n.id
        ]
        # Module docstring: "Model definitions for the data layer."
        assert any(
            "Model definitions" in n.content for n in module_docs
        ), f"Module docstring not found. Docstring nodes: {[n.content for n in docstring_nodes]}"

    def test_class_docstring_extracted(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        docstring_nodes: list[Node] = [n for n in nodes if n.node_type == "docstring"]
        assert any(
            "Abstract base" in n.content for n in docstring_nodes
        ), f"Class docstring not found. Got: {[n.content for n in docstring_nodes]}"

    def test_function_docstring_extracted(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        docstring_nodes: list[Node] = [n for n in nodes if n.node_type == "docstring"]
        assert any(
            "Factory function" in n.content for n in docstring_nodes
        ), f"Function docstring not found. Got: {[n.content for n in docstring_nodes]}"


class TestSignatureExtraction:
    """Function signatures should be extracted as 'function_signature' nodes."""

    def test_signature_with_params_extracted(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        sig_nodes: list[Node] = [n for n in nodes if n.node_type == "function_signature"]
        assert any(
            "name" in n.content and "role" in n.content for n in sig_nodes
        ), f"create_user signature not found. Got: {[n.content for n in sig_nodes]}"

    def test_signature_includes_return_type(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        sig_nodes: list[Node] = [n for n in nodes if n.node_type == "function_signature"]
        # create_user returns User
        assert any(
            "User" in n.content for n in sig_nodes
        ), f"Return type annotation not found. Got: {[n.content for n in sig_nodes]}"


class TestClassDefExtraction:
    """Class definitions should be extracted as 'class_def' nodes."""

    def test_class_def_extracted(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        class_nodes: list[Node] = [n for n in nodes if n.node_type == "class_def"]
        names: list[str] = [n.content for n in class_nodes]
        assert any("BaseModel" in c for c in names), f"BaseModel not found. Got: {names}"
        assert any("User" in c for c in names), f"User not found. Got: {names}"

    def test_class_def_has_file_and_line(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        class_nodes: list[Node] = [n for n in nodes if n.node_type == "class_def"]
        for cn in class_nodes:
            assert cn.file is not None, f"Class node {cn.id} missing file"
            assert cn.line is not None, f"Class node {cn.id} missing line number"


class TestConstantExtraction:
    """Module-level UPPER_CASE constants should be extracted."""

    def test_uppercase_constants_extracted(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        const_nodes: list[Node] = [n for n in nodes if n.node_type == "constant"]
        contents: list[str] = [n.content for n in const_nodes]
        assert any("MAX_RETRIES" in c for c in contents), f"MAX_RETRIES not found. Got: {contents}"
        assert any("DEFAULT_TIMEOUT" in c for c in contents), f"DEFAULT_TIMEOUT not found. Got: {contents}"

    def test_private_vars_not_extracted(self, py_project: Path) -> None:
        nodes, _edges = extract_ast_calls(py_project, ["python"])
        const_nodes: list[Node] = [n for n in nodes if n.node_type == "constant"]
        assert not any(
            "_private_var" in n.content for n in const_nodes
        ), "Private variables should not be extracted as constants"


# ---------------------------------------------------------------------------
# Edge type tests
# ---------------------------------------------------------------------------


class TestDocumentsEdges:
    """DOCUMENTS edges should link docstrings to their parent nodes."""

    def test_documents_edge_for_function_docstring(self, py_project: Path) -> None:
        _nodes, edges = extract_ast_calls(py_project, ["python"])
        doc_edges: list[Edge] = [e for e in edges if e.edge_type == "DOCUMENTS"]
        assert len(doc_edges) > 0, "No DOCUMENTS edges found"

    def test_documents_edge_links_docstring_to_function(self, py_project: Path) -> None:
        _nodes, edges = extract_ast_calls(py_project, ["python"])
        doc_edges: list[Edge] = [e for e in edges if e.edge_type == "DOCUMENTS"]
        # At least one should link a doc node to a func/class node
        assert any(
            "doc:" in e.src and ("func:" in e.tgt or "class:" in e.tgt)
            for e in doc_edges
        ), f"No docstring-to-definition DOCUMENTS edge. Got: {[(e.src, e.tgt) for e in doc_edges]}"


class TestDefinesEdges:
    """DEFINES edges should link functions to signatures and modules to constants."""

    def test_defines_edge_for_signature(self, py_project: Path) -> None:
        _nodes, edges = extract_ast_calls(py_project, ["python"])
        def_edges: list[Edge] = [e for e in edges if e.edge_type == "DEFINES"]
        assert any(
            "func:" in e.src and "sig:" in e.tgt for e in def_edges
        ), f"No function-to-signature DEFINES edge. Got: {[(e.src, e.tgt) for e in def_edges]}"
