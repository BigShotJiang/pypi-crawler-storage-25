"""Tests for evidence-based demotion of user-locked beliefs (GH-17, CS-036).

These tests define the DESIRED behavior, not the current behavior.
They will fail until the demotion mechanism is implemented.

Design principle: user-locked beliefs are strong but NOT immune.
Accumulated contradicting evidence should trigger demotion to promoted,
not straight to none. The user gets a say via reaffirmation.
"""

from __future__ import annotations

from collections.abc import Generator
from pathlib import Path

import pytest

from agentmemory.models import (
    BELIEF_FACTUAL,
    BELIEF_PROCEDURAL,
    BSRC_AGENT_INFERRED,
    BSRC_USER_STATED,
    EDGE_CONTRADICTS,
    LOCK_NONE,
    LOCK_PROMOTED,
    LOCK_USER,
    Belief,
)
from agentmemory.store import MemoryStore


@pytest.fixture()
def store(tmp_path: Path) -> Generator[MemoryStore, None, None]:
    """Fresh MemoryStore backed by a temp database."""
    s: MemoryStore = MemoryStore(tmp_path / "demotion_test.db")
    yield s
    s.close()


def _insert_user_locked(
    store: MemoryStore,
    content: str,
    belief_type: str = BELIEF_FACTUAL,
    alpha: float = 9.0,
    beta_param: float = 0.5,
) -> Belief:
    """Insert a user-locked belief."""
    b: Belief = store.insert_belief(
        content=content,
        belief_type=belief_type,
        source_type=BSRC_USER_STATED,
        alpha=alpha,
        beta_param=beta_param,
        locked=True,
        lock_level=LOCK_USER,
    )
    return b


# ---------------------------------------------------------------------------
# H1: User-locked beliefs demote to promoted after N harmful feedbacks
# ---------------------------------------------------------------------------


class TestUserLockedDemotionOnHarmfulFeedback:
    """Accumulated harmful feedback should demote user -> promoted."""

    def test_single_harmful_does_not_demote(self, store: MemoryStore) -> None:
        """One harmful signal is noise -- user-lock should hold."""
        b = _insert_user_locked(store, "no telemetry allowed")
        store.update_confidence(b.id, "harmful", weight=3.0)
        refreshed: Belief | None = store.get_belief(b.id)
        assert refreshed is not None
        assert refreshed.lock_level == LOCK_USER

    def test_five_harmful_signals_fully_demote(
        self, store: MemoryStore
    ) -> None:
        """5 independent harmful signals exceed the factual threshold (15.0).

        After user -> promoted demotion, the promoted belief receives the
        same harmful signal which triggers auto-demotion (promoted with
        beta >= old_beta + 2.0 -> none). This cascading demotion is correct:
        sufficient evidence should fully unlock a belief.
        """
        b = _insert_user_locked(store, "no telemetry allowed")
        for _ in range(5):
            store.update_confidence(b.id, "harmful", weight=3.0)
        refreshed: Belief | None = store.get_belief(b.id)
        assert refreshed is not None
        assert refreshed.lock_level == LOCK_NONE, (
            f"Expected full demotion after 5 harmful signals, "
            f"got lock_level={refreshed.lock_level}"
        )

    def test_two_harmful_signals_still_user_locked(self, store: MemoryStore) -> None:
        """2 signals (cumulative ~6.5) below factual threshold (9.0) -- holds."""
        b = _insert_user_locked(store, "no telemetry allowed")
        for _ in range(2):
            store.update_confidence(b.id, "harmful", weight=3.0)
        refreshed: Belief | None = store.get_belief(b.id)
        assert refreshed is not None
        assert refreshed.lock_level == LOCK_USER

    def test_demotion_recorded_in_confidence_history(
        self, store: MemoryStore
    ) -> None:
        """Demotion event should appear in confidence_history."""
        b = _insert_user_locked(store, "no telemetry allowed")
        for _ in range(5):
            store.update_confidence(b.id, "harmful", weight=3.0)
        history: list[dict[str, str]] = store._conn.execute(  # pyright: ignore[reportPrivateUsage]
            "SELECT event_type FROM confidence_history "
            "WHERE belief_id = ? ORDER BY created_at",
            (b.id,),
        ).fetchall()
        event_types: list[str] = [r["event_type"] for r in history]
        assert "user_demoted_to_promoted" in event_types, (
            f"Expected demotion event in history, got: {event_types}"
        )


# ---------------------------------------------------------------------------
# H2: CONTRADICTS edges count toward demotion pressure
# ---------------------------------------------------------------------------


class TestContradictionPressure:
    """CONTRADICTS edges from other beliefs should contribute demotion pressure."""

    def test_contradicts_edges_counted_for_locked(
        self, store: MemoryStore
    ) -> None:
        """get_locked_beliefs should include contradiction count."""
        b = _insert_user_locked(store, "project uses PostgreSQL")
        # Create 3 contradicting beliefs
        for i in range(3):
            contra = store.insert_belief(
                content=f"project migrated to MySQL (evidence {i})",
                belief_type=BELIEF_FACTUAL,
                source_type=BSRC_AGENT_INFERRED,
                alpha=3.0,
                beta_param=1.0,
            )
            store.insert_edge(contra.id, b.id, EDGE_CONTRADICTS)

        locked: list[Belief] = store.get_locked_beliefs()
        target: list[Belief] = [lb for lb in locked if lb.id == b.id]
        assert len(target) == 1
        # The belief should expose contradiction count
        assert hasattr(target[0], "contradiction_count") or hasattr(
            target[0], "demotion_pressure"
        ), "Locked beliefs should expose contradiction/demotion pressure metadata"


# ---------------------------------------------------------------------------
# H3: Demoted user-lock still resists casual noise at promoted level
# ---------------------------------------------------------------------------


class TestDemotedStillResistsNoise:
    """After user -> promoted demotion, promoted-level resistance applies."""

    def test_single_weak_signal_on_promoted_holds(
        self, store: MemoryStore
    ) -> None:
        """A promoted-level belief should resist a single weak signal.

        Note: first-signal amplification (3x) fires for non-user-locked
        beliefs on first update_confidence call (checks tests table which
        is only populated by record_test_result). Use weight=0.5 so that
        even with 3x amp (effective 1.5), beta increase < 2.0 (the
        auto-demotion threshold).
        """
        b = store.insert_belief(
            content="promoted belief resists noise",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=10.0,
            beta_param=1.0,
            locked=True,
            lock_level="promoted",
            session_id="test-session",
        )
        # weight=0.5 * 3x first-signal amp = 1.5 effective.
        # beta: 1.0 + 1.5 = 2.5. old_beta + 2.0 = 3.0. 2.5 < 3.0 -- holds.
        store.update_confidence(b.id, "harmful", weight=0.5)
        refreshed: Belief | None = store.get_belief(b.id)
        assert refreshed is not None
        assert refreshed.lock_level == LOCK_PROMOTED, (
            "Single weak signal should not demote promoted -> none"
        )


# ---------------------------------------------------------------------------
# H4: User reaffirmation resets demotion pressure
# ---------------------------------------------------------------------------


class TestReaffirmationResetsPressure:
    """A 'used' signal from the user should reset accumulated demotion pressure."""

    def test_used_feedback_resets_harmful_accumulation(
        self, store: MemoryStore
    ) -> None:
        """4 harmful signals + 1 used + 4 more harmful should NOT trigger
        demotion (the used signal resets the counter)."""
        b = _insert_user_locked(
            store,
            "always use TDD for bug fixes",
            belief_type=BELIEF_PROCEDURAL,  # threshold=5
        )
        # 4 harmful (below procedural threshold of 5)
        for _ in range(4):
            store.update_confidence(b.id, "harmful", weight=3.0)
        # User reaffirms
        store.update_confidence(b.id, "used", weight=1.0)
        # 4 more harmful (would be 8 total without reset, but only 4 since reset)
        for _ in range(4):
            store.update_confidence(b.id, "harmful", weight=3.0)

        refreshed: Belief | None = store.get_belief(b.id)
        assert refreshed is not None
        assert refreshed.lock_level == LOCK_USER, (
            "Reaffirmation should reset demotion pressure -- "
            f"got lock_level={refreshed.lock_level}"
        )


# ---------------------------------------------------------------------------
# H5: Factual beliefs have lower demotion threshold than procedural
# ---------------------------------------------------------------------------


class TestBeliefTypeDemotionThreshold:
    """Factual state beliefs should be easier to demote than procedural constraints."""

    def test_factual_demotes_at_3_signals(self, store: MemoryStore) -> None:
        """Factual state (e.g. version number) should demote after 3 harmful signals."""
        b = _insert_user_locked(
            store,
            "project is at version 2.4.0",
            belief_type=BELIEF_FACTUAL,
        )
        for _ in range(3):
            store.update_confidence(b.id, "harmful", weight=3.0)
        refreshed: Belief | None = store.get_belief(b.id)
        assert refreshed is not None
        assert refreshed.lock_level == LOCK_PROMOTED, (
            f"Factual belief should demote at 3 signals, "
            f"got lock_level={refreshed.lock_level}"
        )

    def test_procedural_holds_at_3_signals(self, store: MemoryStore) -> None:
        """Procedural constraint should NOT demote at only 3 harmful signals."""
        b = _insert_user_locked(
            store,
            "always use TDD for bug fixes",
            belief_type=BELIEF_PROCEDURAL,
        )
        for _ in range(3):
            store.update_confidence(b.id, "harmful", weight=3.0)
        refreshed: Belief | None = store.get_belief(b.id)
        assert refreshed is not None
        assert refreshed.lock_level == LOCK_USER, (
            f"Procedural belief should hold at 3 signals, "
            f"got lock_level={refreshed.lock_level}"
        )

    def test_procedural_demotes_at_5_signals(self, store: MemoryStore) -> None:
        """Procedural constraint should demote at 5 harmful signals (higher bar)."""
        b = _insert_user_locked(
            store,
            "always use TDD for bug fixes",
            belief_type=BELIEF_PROCEDURAL,
        )
        for _ in range(5):
            store.update_confidence(b.id, "harmful", weight=3.0)
        refreshed: Belief | None = store.get_belief(b.id)
        assert refreshed is not None
        assert refreshed.lock_level == LOCK_PROMOTED, (
            f"Procedural belief should demote at 5 signals, "
            f"got lock_level={refreshed.lock_level}"
        )
