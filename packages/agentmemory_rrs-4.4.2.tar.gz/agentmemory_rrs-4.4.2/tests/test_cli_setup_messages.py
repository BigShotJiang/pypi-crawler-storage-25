"""Tests for user-facing setup completion messaging (onboarding UX)."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import pytest


def test_cmd_setup_prints_passive_and_belief_explainer(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory import cli

    def _noop_kwargs(**_kwargs: Any) -> None:
        return

    def _noop_bin(_bin: str | None) -> None:
        return

    def _fake_which(_name: str) -> str:
        return "/usr/local/bin/agentmemory"

    class _FakeStore:
        def status(self) -> dict[str, int]:
            return {"beliefs": 3, "locked": 1}

        def close(self) -> None:
            return

    # Keep setup local to tmp_path and stub side effects.
    monkeypatch.setattr(cli, "_COMMANDS_DIR", tmp_path / "commands")
    monkeypatch.setattr(cli, "_ensure_project_mcp_config", _noop_kwargs)
    monkeypatch.setattr(cli, "_get_store", lambda: _FakeStore())
    monkeypatch.setattr(cli, "_resolve_db_path", lambda: tmp_path / "memory.db")
    monkeypatch.setattr(cli, "_install_commit_hook", _noop_bin)
    monkeypatch.setattr(cli, "_install_directive_gate", lambda: None)
    monkeypatch.setattr(cli, "_install_agent_gate", lambda: None)
    monkeypatch.setattr(cli, "_install_branch_scope_pre_push_hook", lambda: None)
    monkeypatch.setattr(cli, "_install_issue_scope_commit_msg_hook", lambda: None)
    monkeypatch.setattr(cli, "_run_setup_smoke_test", lambda: None)
    monkeypatch.setattr(cli, "_setup_obsidian_vault", lambda: None)
    monkeypatch.setattr(cli, "_setup_telemetry", lambda: None)
    monkeypatch.setattr(cli.shutil, "which", _fake_which)
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".git").mkdir()

    cli.cmd_setup(argparse.Namespace())

    out: str = capsys.readouterr().out
    assert "agentmemory is now active and learns automatically" in out
    assert "No manual remember commands are required" in out
    assert "Terminology: a belief is one memory unit" in out
    assert "Git repository detected: commit history will be indexed" in out
