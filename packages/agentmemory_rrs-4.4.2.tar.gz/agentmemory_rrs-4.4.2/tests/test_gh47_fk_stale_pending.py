# pyright: reportPrivateUsage=false, reportUnusedFunction=false
"""GH-47 / GH-40: FK constraint failure when resolving stale pending feedback.

_resolve_stale_pending_feedback calls record_test_result with belief_ids
from pending_feedback. If the belief no longer exists in the beliefs table,
the INSERT into tests violates FOREIGN KEY (belief_id) REFERENCES beliefs(id).

This test proves the bug by inserting pending_feedback entries with orphaned
belief_ids and then calling _resolve_stale_pending_feedback.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Generator
from pathlib import Path

import pytest

from agentmemory.models import BELIEF_FACTUAL, BSRC_AGENT_INFERRED, Belief
from agentmemory.store import MemoryStore

import agentmemory.server as server_mod


@pytest.fixture()
def store(tmp_path: Path) -> Generator[MemoryStore, None, None]:
    s: MemoryStore = MemoryStore(tmp_path / "test_gh47.db")
    yield s
    s.close()


@pytest.fixture(autouse=True)
def _reset_server_globals() -> Generator[None, None, None]:
    old_store: MemoryStore | None = server_mod._store
    old_session: str | None = server_mod._session_id
    yield
    server_mod._store = old_store
    server_mod._session_id = old_session


def test_stale_pending_with_orphaned_belief_does_not_crash(
    store: MemoryStore,
) -> None:
    """Resolving stale pending feedback with a deleted belief must not FK-fail."""
    # Create a prior session with pending feedback
    prior_session = store.create_session(model="test-model")

    # Insert a real belief, then add pending feedback referencing it
    belief: Belief = store.insert_belief(
        content="This belief will be orphaned",
        belief_type=BELIEF_FACTUAL,
        source_type=BSRC_AGENT_INFERRED,
    )
    store._conn.commit()
    store.insert_pending_feedback(belief.id, belief.content, prior_session.id)

    # Hard-delete the belief to simulate orphaned reference
    store._conn.execute("DELETE FROM beliefs WHERE id = ?", (belief.id,))
    # Also remove from search index to avoid other FK issues
    store._conn.execute("DELETE FROM search_index WHERE id = ?", (belief.id,))
    store._conn.commit()

    # Also insert a pending entry with a completely fake belief_id
    store.insert_pending_feedback(
        "nonexistent-belief-id", "ghost belief", prior_session.id
    )

    # Complete the prior session so it looks like a stale session
    store.complete_session(prior_session.id)

    # Create a new session (this is what _ensure_session does)
    new_session = store.create_session(model="test-model")

    # This should NOT raise sqlite3.IntegrityError: FOREIGN KEY constraint failed
    resolved: int = server_mod._resolve_stale_pending_feedback(
        store, new_session.id
    )

    # Both orphaned entries should be resolved (skipped, not crashed)
    assert resolved >= 0

    # Pending feedback should be cleared regardless
    remaining = store.get_pending_feedback()
    # Only entries for the new session (if any) should remain
    stale = [e for e in remaining if e["session_id"] != new_session.id]
    assert len(stale) == 0, f"Stale pending entries not cleared: {stale}"


def test_stale_pending_with_valid_belief_still_records(
    store: MemoryStore,
) -> None:
    """Resolving stale pending feedback with a valid belief still records test."""
    prior_session = store.create_session(model="test-model")

    belief: Belief = store.insert_belief(
        content="This belief persists",
        belief_type=BELIEF_FACTUAL,
        source_type=BSRC_AGENT_INFERRED,
    )
    store._conn.commit()
    store.insert_pending_feedback(belief.id, belief.content, prior_session.id)
    store.complete_session(prior_session.id)

    new_session = store.create_session(model="test-model")

    resolved: int = server_mod._resolve_stale_pending_feedback(
        store, new_session.id
    )

    assert resolved == 1

    # Verify the test result was actually recorded
    rows: list[sqlite3.Row] = store._conn.execute(
        "SELECT * FROM tests WHERE belief_id = ?", (belief.id,)
    ).fetchall()
    assert len(rows) == 1
    assert rows[0]["outcome"] == "ignored"
