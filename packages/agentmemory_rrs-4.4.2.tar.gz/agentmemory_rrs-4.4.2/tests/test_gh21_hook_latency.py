"""GH-21: Hook injection latency tests.

Establishes performance baseline for search_for_prompt() and verifies
the telemetry measurement is accurate (not an artifact of orphaned
processes running past the hook timeout).
"""

from __future__ import annotations

import sqlite3
import time

import pytest

from agentmemory.hook_search import search_for_prompt
from agentmemory.store import MemoryStore


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def hook_db(tmp_path: object) -> sqlite3.Connection:
    """Create a populated DB via MemoryStore, then return raw connection."""
    import pathlib

    db_path: str = str(pathlib.Path(str(tmp_path)) / "memory.db")
    store: MemoryStore = MemoryStore(db_path)

    # Populate with realistic data: 100 beliefs across types
    for i in range(50):
        store.insert_belief(
            content=f"The retrieval system uses FTS5 for keyword search variant {i}",
            belief_type="factual",
            source_type="agent_inferred",
        )
    for i in range(20):
        store.insert_belief(
            content=f"Always use type hints in production code rule {i}",
            belief_type="correction",
            source_type="user_corrected",
            locked=True,
        )
    for i in range(20):
        store.insert_belief(
            content=f"The system must validate all user input requirement {i}",
            belief_type="requirement",
            source_type="user_stated",
        )
    for i in range(10):
        store.insert_belief(
            content=f"User prefers SQLite over PostgreSQL preference {i}",
            belief_type="preference",
            source_type="user_stated",
        )

    store.close()

    db: sqlite3.Connection = sqlite3.connect(db_path)
    db.row_factory = sqlite3.Row
    return db


# ---------------------------------------------------------------------------
# Latency tests
# ---------------------------------------------------------------------------


class TestHookSearchLatency:
    """Verify search_for_prompt completes within the hook timeout budget."""

    def test_search_completes_under_5s(self, hook_db: sqlite3.Connection) -> None:
        """The hook timeout is 5s. Search must complete well within that."""
        t0: float = time.monotonic()
        _result = search_for_prompt(hook_db, "How does retrieval work?")
        elapsed_ms: float = (time.monotonic() - t0) * 1000

        assert elapsed_ms < 5000, (
            f"search_for_prompt took {elapsed_ms:.0f}ms, exceeds 5s hook timeout"
        )

    def test_search_completes_under_500ms(self, hook_db: sqlite3.Connection) -> None:
        """Target latency is 500ms per GH-21."""
        t0: float = time.monotonic()
        _result = search_for_prompt(hook_db, "type hints in production code")
        elapsed_ms: float = (time.monotonic() - t0) * 1000

        assert elapsed_ms < 500, (
            f"search_for_prompt took {elapsed_ms:.0f}ms, exceeds 500ms target"
        )

    def test_cold_vs_warm_latency(self, hook_db: sqlite3.Connection) -> None:
        """Second call should be faster than first (SQLite page cache warm)."""
        # Cold call
        t0: float = time.monotonic()
        _result1 = search_for_prompt(hook_db, "FTS5 keyword search")
        cold_ms: float = (time.monotonic() - t0) * 1000

        # Warm call
        t1: float = time.monotonic()
        _result2 = search_for_prompt(hook_db, "type hints validation")
        warm_ms: float = (time.monotonic() - t1) * 1000

        # Warm should be at most 2x cold (generous bound)
        assert warm_ms < cold_ms * 2 + 50, (
            f"Warm call ({warm_ms:.0f}ms) unexpectedly slower than cold ({cold_ms:.0f}ms)"
        )

    def test_empty_prompt_returns_immediately(self, hook_db: sqlite3.Connection) -> None:
        """Non-prompts should short-circuit with negligible latency."""
        t0: float = time.monotonic()
        result = search_for_prompt(hook_db, "")
        elapsed_ms: float = (time.monotonic() - t0) * 1000

        assert elapsed_ms < 10, f"Empty prompt took {elapsed_ms:.0f}ms"
        assert len(result.beliefs) == 0

    def test_xml_prompt_skipped(self, hook_db: sqlite3.Connection) -> None:
        """XML/task-notification prompts should be pre-filtered."""
        t0: float = time.monotonic()
        result = search_for_prompt(
            hook_db,
            "<task-notification><task-id>abc</task-id></task-notification>",
        )
        elapsed_ms: float = (time.monotonic() - t0) * 1000

        assert elapsed_ms < 10, f"XML prompt took {elapsed_ms:.0f}ms"
        assert len(result.beliefs) == 0


class TestHookTelemetryAccuracy:
    """Verify that measured latency reflects actual execution time."""

    def test_measured_latency_matches_wallclock(
        self, hook_db: sqlite3.Connection
    ) -> None:
        """The latency recorded by telemetry should match wallclock time."""
        t0: float = time.monotonic()
        _result = search_for_prompt(hook_db, "retrieval architecture")
        wallclock_ms: float = (time.monotonic() - t0) * 1000

        # The measured time should be within 50ms of wallclock
        # (accounting for Python overhead between timer reads)
        assert wallclock_ms < 5000, (
            f"Wallclock {wallclock_ms:.0f}ms -- if this exceeds 5s, the hook "
            f"timeout would kill the process and telemetry would record a "
            f"post-timeout orphan measurement (the GH-21 artifact)"
        )
