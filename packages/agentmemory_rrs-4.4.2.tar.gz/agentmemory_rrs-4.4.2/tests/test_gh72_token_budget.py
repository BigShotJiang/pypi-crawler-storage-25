# pyright: reportPrivateUsage=false
"""Tests for GH-72: Hook injection token budget enforcement.

Validates that hook injections respect character budgets and truncate
belief content to prevent excessive context window consumption.
"""

from __future__ import annotations

import random

import pytest

from agentmemory.hook_search import (
    ScoredBelief,
    SearchResult,
    format_ba_injection,
)


@pytest.fixture(autouse=True)
def _seed_random() -> None:  # pyright: ignore[reportUnusedFunction]
    random.seed(42)


def _make_belief(
    content: str,
    *,
    locked: bool = False,
    belief_type: str = "factual",
    source_type: str = "agent_inferred",
    age_days: float | None = 0.5,
    confidence: float = 0.8,
    score: float = 1.0,
    via: str = "fts5",
) -> ScoredBelief:
    return ScoredBelief(
        id="test" + content[:8],
        content=content,
        belief_type=belief_type,
        source_type=source_type,
        locked=locked,
        confidence=confidence,
        score=score,
        age_days=age_days,
        via=via,
    )


class TestFormatBaInjectionBudget:
    """format_ba_injection must respect a character budget."""

    def test_output_under_budget_default(self) -> None:
        """Injection output must not exceed the default budget."""
        beliefs: list[ScoredBelief] = [
            _make_belief("A" * 300, locked=True) for _ in range(20)
        ]
        result = SearchResult(beliefs=beliefs, contradictions=[], source_docs=[])
        output: str = format_ba_injection(result, max_chars=3000)
        assert len(output) <= 3000, (
            f"Output {len(output)} chars exceeds 3000 char budget"
        )

    def test_long_beliefs_truncated(self) -> None:
        """Individual belief content must be truncated in output."""
        long_content: str = "X" * 500
        beliefs: list[ScoredBelief] = [
            _make_belief(long_content, locked=True),
        ]
        result = SearchResult(beliefs=beliefs, contradictions=[], source_docs=[])
        output: str = format_ba_injection(result, max_chars=3000)
        # The full 500-char content should not appear verbatim
        assert long_content not in output, (
            "500-char belief content should be truncated in injection output"
        )

    def test_locked_beliefs_prioritized_over_background(self) -> None:
        """When budget is tight, locked beliefs survive, background gets cut."""
        locked: list[ScoredBelief] = [
            _make_belief(f"LOCKED RULE {i}", locked=True)
            for i in range(3)
        ]
        background: list[ScoredBelief] = [
            _make_belief(f"background info {i}" * 20)
            for i in range(10)
        ]
        result = SearchResult(
            beliefs=locked + background, contradictions=[], source_docs=[]
        )
        output: str = format_ba_injection(result, max_chars=800)
        for i in range(3):
            assert f"LOCKED RULE {i}" in output, (
                f"Locked belief {i} should survive budget cuts"
            )

    def test_zero_beliefs_returns_empty(self) -> None:
        """No beliefs should produce empty output."""
        result = SearchResult(beliefs=[], contradictions=[], source_docs=[])
        output: str = format_ba_injection(result, max_chars=3000)
        assert output == ""

    def test_contradictions_truncated(self) -> None:
        """Contradiction content is truncated in output."""
        long_a: ScoredBelief = _make_belief("Y" * 500, locked=True)
        long_b: ScoredBelief = _make_belief("Z" * 500, locked=True)
        result = SearchResult(
            beliefs=[long_a, long_b],
            contradictions=[(long_a, long_b)],
            source_docs=[],
        )
        output: str = format_ba_injection(result, max_chars=3000)
        # Full 500-char strings should not appear anywhere
        assert "Y" * 500 not in output
        assert "Z" * 500 not in output


class TestSessionStartBudget:
    """SessionStart injection script budget behavior.

    These tests validate the budget constants and packing logic
    that will be added to agentmemory-inject.sh.
    """

    def test_belief_content_max_length(self) -> None:
        """No single belief in injection should exceed 200 chars."""
        # This tests the truncation helper
        from agentmemory.hook_search import truncate_belief

        long: str = "A" * 500
        result: str = truncate_belief(long, max_len=200)
        assert len(result) <= 200
        assert result.endswith("...")

    def test_truncate_preserves_short_content(self) -> None:
        """Content under the limit should not be modified."""
        from agentmemory.hook_search import truncate_belief

        short: str = "This is fine"
        result: str = truncate_belief(short, max_len=200)
        assert result == short

    def test_truncate_word_boundary(self) -> None:
        """Truncation should break at word boundaries when possible."""
        from agentmemory.hook_search import truncate_belief

        text: str = "The quick brown fox jumps over the lazy dog " * 10
        result: str = truncate_belief(text, max_len=50)
        assert len(result) <= 50
        assert result.endswith("...")
        # Should end at a complete word -- no partial word before "..."
        prefix: str = result[:-3].rstrip()
        # Last char of prefix should be end of a word (not mid-word)
        assert not prefix[-1].isalpha() or prefix.endswith("dog") or prefix.endswith("fox") or prefix.endswith("the") or prefix.endswith("lazy") or prefix.endswith("over") or prefix.endswith("jumps") or prefix.endswith("brown") or prefix.endswith("quick"), (
            f"Should break at word boundary, got: {result!r}"
        )
