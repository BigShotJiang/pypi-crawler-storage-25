"""GH-17: Tests proving correction classifier false positives on factual text.

These tests document the negation-pattern misclassification bug. Each test
case is a real-world factual statement that the current detector incorrectly
flags as a correction due to single-signal matching on common English words.

The fix: require >= 2 corroborating signals for correction classification.
Single-signal matches should return is_correction=False.
"""

from __future__ import annotations

from agentmemory.correction_detection import detect_correction


# ---------------------------------------------------------------------------
# Factual statements that should NOT be corrections (currently misclassified)
# ---------------------------------------------------------------------------


class TestGH17SingleSignalFalsePositives:
    """Factual text with a single signal should not be flagged as a correction.

    Each test targets a specific signal that over-triggers on common English.
    """

    def test_negation_in_factual_statement(self) -> None:
        """'not' in factual context is not a correction."""
        is_corr, signals, _ = detect_correction(
            "The system does not use embeddings for retrieval"
        )
        assert not is_corr, f"Factual negation misclassified (signals={signals})"

    def test_no_in_factual_statement(self) -> None:
        """'no ' in factual context is not a correction."""
        is_corr, signals, _ = detect_correction("no changes needed")
        assert not is_corr, f"'no changes needed' misclassified (signals={signals})"

    def test_declarative_is_the(self) -> None:
        """'is the' pattern in description is not a correction."""
        is_corr, signals, _ = detect_correction(
            "SQLite is the default database backend"
        )
        assert not is_corr, f"Factual declarative misclassified (signals={signals})"

    def test_must_in_documentation(self) -> None:
        """'must' in technical description is not a correction."""
        is_corr, signals, _ = detect_correction(
            "The connection must be closed after use"
        )
        assert not is_corr, f"Technical 'must' misclassified (signals={signals})"

    def test_already_in_status_update(self) -> None:
        """'already' in progress update is not a correction."""
        is_corr, signals, _ = detect_correction(
            "The migration has already been applied to production"
        )
        assert not is_corr, f"Status 'already' misclassified (signals={signals})"

    def test_imperative_verb_in_task_description(self) -> None:
        """Imperative verb starting a task name is not a correction."""
        is_corr, signals, _ = detect_correction(
            "Add bitemporal columns to beliefs table"
        )
        assert not is_corr, f"Task description misclassified (signals={signals})"

    def test_exclamation_in_positive_context(self) -> None:
        """Exclamation mark in positive feedback is not a correction."""
        is_corr, signals, _ = detect_correction("That works great!")
        assert not is_corr, f"Positive exclamation misclassified (signals={signals})"

    def test_period_in_technical_prose(self) -> None:
        """Common technical prose with 'is a' pattern."""
        is_corr, signals, _ = detect_correction(
            "This is a join between beliefs and session tracking"
        )
        assert not is_corr, f"Technical prose misclassified (signals={signals})"


class TestGH17MultiSignalStillDetected:
    """Real corrections with 2+ signals must still be detected."""

    def test_negation_plus_prior_ref(self) -> None:
        is_corr, signals, _ = detect_correction(
            "we agreed to use SQLite, not Postgres"
        )
        assert is_corr
        assert len(signals) >= 2

    def test_imperative_plus_always(self) -> None:
        is_corr, signals, _ = detect_correction(
            "always run the linter before committing"
        )
        assert is_corr
        assert len(signals) >= 2

    def test_negation_plus_emphasis(self) -> None:
        is_corr, signals, _ = detect_correction("do not do that ever again")
        assert is_corr
        assert len(signals) >= 2

    def test_stop_imperative_plus_negation_plus_emphasis(self) -> None:
        is_corr, signals, _ = detect_correction("stop committing large files")
        assert is_corr
        assert len(signals) >= 2

    def test_frustration_with_prior_ref(self) -> None:
        is_corr, signals, _ = detect_correction("I told you to use pytest!")
        assert is_corr
        assert len(signals) >= 2


class TestGH17MinimumSignalThreshold:
    """The detector should require >= 2 signals for is_correction=True."""

    def test_single_signal_returns_false(self) -> None:
        """Any text matching exactly 1 signal should not be a correction."""
        # "use ruff" matches only imperative (1 signal)
        is_corr, signals, _ = detect_correction("use ruff")
        assert len(signals) == 1, f"Expected 1 signal, got {signals}"
        assert not is_corr, "Single-signal match should not be a correction"

    def test_two_signals_returns_true(self) -> None:
        """Text matching 2+ signals should be a correction."""
        # "always lint" matches imperative + always_never (2 signals)
        is_corr, signals, _ = detect_correction("always lint")
        assert len(signals) >= 2, f"Expected 2+ signals, got {signals}"
        assert is_corr, "Multi-signal match should be a correction"
