"""GH-30: Agent tool must search agentmemory before spawning Explore agents.

Tests the PreToolUse gate that reminds/warns when Agent is called without
prior agentmemory search. The gate injects a reminder into the tool context.

Pass criteria:
- Gate script exists and is executable
- Agent calls with Explore/investigation prompts trigger the reminder
- Agent calls for non-exploration tasks (e.g., code fixes) pass through
- The reminder is a valid JSON object with decision and reason fields
"""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

REPO_ROOT: Path = Path(__file__).resolve().parents[1]
GATE_SCRIPT: Path = REPO_ROOT / "scripts" / "agentmemory-agent-gate.sh"


# ---------------------------------------------------------------------------
# Core matching logic (mirrors the gate script for unit testing)
# ---------------------------------------------------------------------------

# Keywords that suggest the Agent call is doing exploration/investigation
# that agentmemory could answer first
_EXPLORATION_SIGNALS: list[str] = [
    "investigate",
    "diagnose",
    "explore",
    "find",
    "search",
    "look for",
    "examine",
    "trace",
    "check",
    "audit",
    "understand",
    "how does",
    "what is",
    "where is",
    "root cause",
]


def _is_exploration_prompt(prompt: str) -> bool:
    """Return True if the Agent prompt looks like exploration work."""
    prompt_lower = prompt.lower()
    matches = sum(1 for sig in _EXPLORATION_SIGNALS if sig in prompt_lower)
    return matches >= 2


def _build_reminder() -> dict[str, str]:
    """Build the reminder payload."""
    return {
        "decision": "allow",
        "reason": (
            "REMINDER: Search agentmemory first (mcp__agentmemory__search) "
            "before spawning exploration agents. Agentmemory is ~42x cheaper "
            "than Explore agents. Only use agents for gaps agentmemory can't fill."
        ),
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


_GATE_MISSING: bool = not GATE_SCRIPT.exists()


@pytest.mark.skipif(_GATE_MISSING, reason="scripts/ excluded from public repo")
class TestGateScriptExists:
    """Gate script must exist and be executable."""

    def test_script_exists(self) -> None:
        assert GATE_SCRIPT.exists(), f"Gate script not found at {GATE_SCRIPT}"

    def test_script_is_executable(self) -> None:
        mode = os.stat(GATE_SCRIPT).st_mode
        assert mode & stat.S_IXUSR, "Gate script must be executable"


class TestExplorationDetection:
    """Exploration prompts should trigger reminder."""

    def test_explore_codebase_triggers(self) -> None:
        prompt = "Investigate the SQLite WAL handling and examine connection management"
        assert _is_exploration_prompt(prompt)

    def test_diagnose_bug_triggers(self) -> None:
        prompt = "Diagnose a possible race condition. Find where the lock is acquired"
        assert _is_exploration_prompt(prompt)

    def test_trace_code_path_triggers(self) -> None:
        prompt = "Trace the full ingestion path. Examine what happens during ingest"
        assert _is_exploration_prompt(prompt)

    def test_root_cause_investigation_triggers(self) -> None:
        prompt = "Find the root cause of the search failure. Check the scoring code"
        assert _is_exploration_prompt(prompt)

    def test_how_does_question_triggers(self) -> None:
        prompt = "How does the MCP server open its connection? What is the lifecycle?"
        assert _is_exploration_prompt(prompt)

    def test_single_keyword_does_not_trigger(self) -> None:
        prompt = "Find the file"
        assert not _is_exploration_prompt(prompt)

    def test_code_fix_does_not_trigger(self) -> None:
        prompt = "Apply the fix to store.py line 42: change timeout from 5 to 10"
        assert not _is_exploration_prompt(prompt)

    def test_write_code_does_not_trigger(self) -> None:
        prompt = "Create a new test file for the compression module"
        assert not _is_exploration_prompt(prompt)

    def test_run_tests_does_not_trigger(self) -> None:
        prompt = "Run the test suite and report results"
        assert not _is_exploration_prompt(prompt)

    def test_empty_prompt_does_not_trigger(self) -> None:
        assert not _is_exploration_prompt("")


class TestReminderPayload:
    """Reminder must be well-formed."""

    def test_reminder_has_decision_allow(self) -> None:
        reminder = _build_reminder()
        assert reminder["decision"] == "allow"

    def test_reminder_has_reason(self) -> None:
        reminder = _build_reminder()
        assert "agentmemory" in reminder["reason"].lower()

    def test_reminder_is_valid_json(self) -> None:
        reminder = _build_reminder()
        dumped = json.dumps(reminder)
        parsed = json.loads(dumped)
        assert parsed == reminder

    def test_reminder_mentions_cost(self) -> None:
        reminder = _build_reminder()
        assert "42x" in reminder["reason"]
