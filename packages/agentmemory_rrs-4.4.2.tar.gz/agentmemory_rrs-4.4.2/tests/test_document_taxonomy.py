"""Tests for two-axis document taxonomy: source_type x doc_class (GH-22).

These tests validate that the architecture provides retrieval signal --
different source types should produce different scoring behavior, and
doc_class should enable filtered retrieval.
"""

from __future__ import annotations

from collections.abc import Generator
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from agentmemory.models import (
    BELIEF_FACTUAL,
    BSRC_AGENT_INFERRED,
    BSRC_USER_CORRECTED,
    BSRC_USER_STATED,
    Belief,
)
from agentmemory.scoring import decay_factor, score_belief
from agentmemory.store import MemoryStore


@pytest.fixture()
def store(tmp_path: Path) -> Generator[MemoryStore, None, None]:
    s: MemoryStore = MemoryStore(tmp_path / "taxonomy_test.db")
    yield s
    s.close()


# ---------------------------------------------------------------------------
# Source type differentiation: different sources decay at different rates
# ---------------------------------------------------------------------------


class TestSourceTypeDecayDifferentiation:
    """Authoritative references should decay slower than agent-inferred."""

    def test_authoritative_decays_slower_than_agent_inferred(self) -> None:
        """An authoritative_reference belief at 30 days should have higher
        decay factor than an agent_inferred belief at the same age."""
        now = datetime.now(timezone.utc)
        created = (now - timedelta(days=30)).isoformat()

        authoritative = Belief(
            id="aabbccddee01",
            content_hash="hash12345678",
            content="git rebase --onto applies commits from one branch onto another",
            belief_type=BELIEF_FACTUAL,
            alpha=5.0,
            beta_param=1.0,
            source_type="authoritative_reference",
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=created,
            updated_at=created,
        )
        inferred = Belief(
            id="aabbccddee02",
            content_hash="hash12345679",
            content="git rebase is probably the right approach here",
            belief_type=BELIEF_FACTUAL,
            alpha=5.0,
            beta_param=1.0,
            source_type=BSRC_AGENT_INFERRED,
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=created,
            updated_at=created,
        )
        auth_decay = decay_factor(authoritative, now)
        inf_decay = decay_factor(inferred, now)
        assert auth_decay > inf_decay, (
            f"Authoritative should decay slower: auth={auth_decay:.4f} vs "
            f"inferred={inf_decay:.4f}"
        )

    def test_academic_decays_slower_than_agent_inferred(self) -> None:
        """Academic source at 60 days should still have meaningful signal."""
        now = datetime.now(timezone.utc)
        created = (now - timedelta(days=60)).isoformat()

        academic = Belief(
            id="aabbccddee03",
            content_hash="hash12345680",
            content="Beta-Bernoulli model converges with O(sqrt(n)) regret",
            belief_type=BELIEF_FACTUAL,
            alpha=5.0,
            beta_param=1.0,
            source_type="academic",
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=created,
            updated_at=created,
        )
        academic_decay = decay_factor(academic, now)
        # At 60 days, academic should still retain >30% signal
        assert academic_decay > 0.3, (
            f"Academic belief at 60 days should retain signal: {academic_decay:.4f}"
        )

    def test_codebase_decays_faster_than_user_stated(self) -> None:
        """Codebase beliefs should decay faster since code changes frequently."""
        now = datetime.now(timezone.utc)
        created = (now - timedelta(days=14)).isoformat()

        codebase = Belief(
            id="aabbccddee04",
            content_hash="hash12345681",
            content="def score_belief takes query, current_time, retrieval_count",
            belief_type=BELIEF_FACTUAL,
            alpha=5.0,
            beta_param=1.0,
            source_type="codebase",
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=created,
            updated_at=created,
        )
        user = Belief(
            id="aabbccddee05",
            content_hash="hash12345682",
            content="always use uv for Python package management",
            belief_type=BELIEF_FACTUAL,
            alpha=5.0,
            beta_param=1.0,
            source_type=BSRC_USER_STATED,
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=created,
            updated_at=created,
        )
        code_decay = decay_factor(codebase, now)
        user_decay = decay_factor(user, now)
        assert code_decay < user_decay, (
            f"Codebase should decay faster: code={code_decay:.4f} vs "
            f"user={user_decay:.4f}"
        )


# ---------------------------------------------------------------------------
# Scoring: authoritative reference should score higher than agent-inferred
# ---------------------------------------------------------------------------


class TestSourceTypeScoringWeight:
    """Different source types should produce different score ranges."""

    def test_authoritative_scores_higher_than_inferred_on_average(self) -> None:
        """Authoritative reference on same content should outscore agent-inferred."""
        now = datetime.now(timezone.utc)

        auth = Belief(
            id="aabbccddee06",
            content_hash="hash12345683",
            content="git stash applies working directory changes to a stack",
            belief_type=BELIEF_FACTUAL,
            alpha=5.0,
            beta_param=1.0,
            source_type="authoritative_reference",
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=now.isoformat(),
            updated_at=now.isoformat(),
        )
        inf = Belief(
            id="aabbccddee07",
            content_hash="hash12345684",
            content="git stash applies working directory changes to a stack",
            belief_type=BELIEF_FACTUAL,
            alpha=5.0,
            beta_param=1.0,
            source_type=BSRC_AGENT_INFERRED,
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=now.isoformat(),
            updated_at=now.isoformat(),
        )
        auth_scores = [score_belief(auth, "git stash", now) for _ in range(200)]
        inf_scores = [score_belief(inf, "git stash", now) for _ in range(200)]
        avg_auth = sum(auth_scores) / len(auth_scores)
        avg_inf = sum(inf_scores) / len(inf_scores)
        assert avg_auth > avg_inf, (
            f"Authoritative should score higher: auth={avg_auth:.3f} vs "
            f"inf={avg_inf:.3f}"
        )


# ---------------------------------------------------------------------------
# User correction beats authoritative reference on conflict
# ---------------------------------------------------------------------------


class TestUserCorrectionOverridesReference:
    """User corrections should outrank authoritative references on same topic."""

    def test_user_correction_beats_authoritative(self) -> None:
        """When user says 'we do Y' and docs say 'X', user wins."""
        now = datetime.now(timezone.utc)

        auth = Belief(
            id="aabbccddee08",
            content_hash="hash12345685",
            content="use git merge for integrating feature branches",
            belief_type=BELIEF_FACTUAL,
            alpha=5.0,
            beta_param=1.0,
            source_type="authoritative_reference",
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=now.isoformat(),
            updated_at=now.isoformat(),
        )
        correction = Belief(
            id="aabbccddee09",
            content_hash="hash12345686",
            content="use git rebase for integrating feature branches, not merge",
            belief_type="correction",
            alpha=9.0,
            beta_param=0.5,
            source_type=BSRC_USER_CORRECTED,
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=now.isoformat(),
            updated_at=now.isoformat(),
        )
        auth_scores = [
            score_belief(auth, "git feature branch", now) for _ in range(200)
        ]
        corr_scores = [
            score_belief(correction, "git feature branch", now) for _ in range(200)
        ]
        avg_auth = sum(auth_scores) / len(auth_scores)
        avg_corr = sum(corr_scores) / len(corr_scores)
        assert avg_corr > avg_auth, (
            f"User correction should beat authoritative: corr={avg_corr:.3f} vs "
            f"auth={avg_auth:.3f}"
        )


# ---------------------------------------------------------------------------
# doc_class field: schema and filtering
# ---------------------------------------------------------------------------


class TestDocClassField:
    """The doc_class field should exist on Belief and support filtering."""

    def test_belief_has_doc_class_field(self) -> None:
        """Belief dataclass should have a doc_class field."""
        b = Belief(
            id="aabbccddee10",
            content_hash="hash12345687",
            content="test belief",
            belief_type=BELIEF_FACTUAL,
            alpha=0.5,
            beta_param=0.5,
            source_type=BSRC_AGENT_INFERRED,
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=datetime.now(timezone.utc).isoformat(),
            updated_at=datetime.now(timezone.utc).isoformat(),
        )
        assert hasattr(b, "doc_class"), "Belief should have a doc_class field"

    def test_doc_class_defaults_to_empty(self) -> None:
        """doc_class should default to empty string."""
        b = Belief(
            id="aabbccddee11",
            content_hash="hash12345688",
            content="test belief",
            belief_type=BELIEF_FACTUAL,
            alpha=0.5,
            beta_param=0.5,
            source_type=BSRC_AGENT_INFERRED,
            locked=False,
            valid_from=None,
            valid_to=None,
            superseded_by=None,
            created_at=datetime.now(timezone.utc).isoformat(),
            updated_at=datetime.now(timezone.utc).isoformat(),
        )
        assert b.doc_class == "", f"Expected empty default, got '{b.doc_class}'"  # pyright: ignore[reportAttributeAccessIssue,reportUnknownMemberType]

    def test_store_persists_doc_class(self, store: MemoryStore) -> None:
        """Inserting a belief with doc_class should persist and retrieve it."""
        b: Belief = store.insert_belief(
            content="Anthropic SDK: use client.messages.create() for completions",
            belief_type=BELIEF_FACTUAL,
            source_type="authoritative_reference",
            alpha=5.0,
            beta_param=1.0,
        )
        # doc_class would need to be set post-insert or via new parameter
        # For now, verify the field exists on retrieved beliefs
        retrieved: Belief | None = store.get_belief(b.id)
        assert retrieved is not None
        assert hasattr(retrieved, "doc_class")
