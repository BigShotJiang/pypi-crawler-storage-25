"""Tests for onboard --llm behavior (GH-57)."""

from __future__ import annotations

import argparse
from pathlib import Path

import pytest


def test_cmd_onboard_llm_delegates_to_server_onboard(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory import cli

    called: dict[str, object] = {}

    def _fake_onboard(project_path: str, use_llm: bool = False) -> str:
        called["project_path"] = project_path
        called["use_llm"] = use_llm
        return "onboard summary"

    # Ensure local scan path is NOT used for --llm branch.
    def _fail_scan(*_args: object, **_kwargs: object) -> object:
        raise AssertionError("scan_project should not be called when --llm is set")

    monkeypatch.setattr("agentmemory.server.onboard", _fake_onboard)
    monkeypatch.setattr(cli, "scan_project", _fail_scan)

    cli.cmd_onboard(argparse.Namespace(path=str(tmp_path), llm=True, link=False))

    out: str = capsys.readouterr().out
    assert "Using LLM-assisted onboarding (--llm)" in out
    assert "onboard summary" in out
    assert called["project_path"] == str(tmp_path.resolve())
    assert called["use_llm"] is True


def test_onboard_help_mentions_llm_flag() -> None:
    from agentmemory import cli

    import sys

    old_argv: list[str] = sys.argv[:]
    try:
        sys.argv = ["agentmemory", "onboard", "--help"]
        with pytest.raises(SystemExit) as exc:
            cli.main()
        assert exc.value.code == 0
    finally:
        sys.argv = old_argv
