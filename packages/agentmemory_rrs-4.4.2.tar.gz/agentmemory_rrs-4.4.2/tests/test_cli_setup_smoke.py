"""Tests for setup smoke-test behavior (GH-52)."""

from __future__ import annotations

from typing import Any

import pytest


def test_run_setup_smoke_skips_when_uv_missing(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory.cli import _run_setup_smoke_test  # pyright: ignore[reportPrivateUsage]

    def _missing(_name: str) -> None:
        return None

    monkeypatch.setattr("agentmemory.cli.shutil.which", _missing)
    _run_setup_smoke_test()

    out: str = capsys.readouterr().out
    assert "Skipping smoke test: uv not found on PATH." in out
    assert "https://docs.astral.sh/uv/" in out


def test_run_setup_smoke_handles_uv_launch_error(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory.cli import _run_setup_smoke_test  # pyright: ignore[reportPrivateUsage]

    def _present(_name: str) -> str:
        return "/usr/bin/uv"

    monkeypatch.setattr("agentmemory.cli.shutil.which", _present)

    def _raise(*_args: Any, **_kwargs: Any) -> Any:
        raise FileNotFoundError("uv executable missing")

    monkeypatch.setattr("subprocess.run", _raise)
    _run_setup_smoke_test()

    err: str = capsys.readouterr().err
    assert "Skipping smoke test: could not run uv" in err
