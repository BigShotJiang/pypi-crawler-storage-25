"""Tests for temporal backbone: build_temporal_backbone and link_temporal."""

from __future__ import annotations

from collections.abc import Generator
from pathlib import Path

import pytest

from agentmemory.store import MemoryStore


@pytest.fixture()
def store(tmp_path: Path) -> Generator[MemoryStore, None, None]:
    s: MemoryStore = MemoryStore(tmp_path / "test.db")
    yield s
    s.close()


def _insert_belief(store: MemoryStore, content: str, created_at: str) -> str:
    """Insert a minimal belief and return its ID."""
    belief = store.insert_belief(
        content=content,
        belief_type="factual",
        source_type="agent_inferred",
        created_at=created_at,
    )
    return belief.id


# ---------------------------------------------------------------------------
# build_temporal_backbone
# ---------------------------------------------------------------------------


class TestBuildTemporalBackbone:
    """Tests for store.build_temporal_backbone()."""

    def test_creates_edges_between_consecutive_beliefs(
        self, store: MemoryStore
    ) -> None:
        """Consecutive beliefs within gap threshold get TEMPORAL_NEXT edges."""
        id1 = _insert_belief(store, "First belief", "2026-04-20T10:00:00+00:00")
        id2 = _insert_belief(store, "Second belief", "2026-04-20T10:05:00+00:00")
        id3 = _insert_belief(store, "Third belief", "2026-04-20T10:10:00+00:00")

        created = store.build_temporal_backbone(gap_minutes=30.0)

        assert created == 2
        # Check edges exist in correct direction
        rows = store.query(
            "SELECT from_id, to_id FROM edges WHERE edge_type = 'TEMPORAL_NEXT' "
            "ORDER BY created_at"
        )
        assert len(rows) == 2
        assert rows[0]["from_id"] == id1
        assert rows[0]["to_id"] == id2
        assert rows[1]["from_id"] == id2
        assert rows[1]["to_id"] == id3

    def test_respects_session_gap(self, store: MemoryStore) -> None:
        """No edge created across a gap > gap_minutes."""
        _insert_belief(store, "Before gap", "2026-04-20T10:00:00+00:00")
        _insert_belief(store, "After gap", "2026-04-20T11:00:00+00:00")  # 60min gap

        created = store.build_temporal_backbone(gap_minutes=30.0)

        assert created == 0

    def test_idempotent(self, store: MemoryStore) -> None:
        """Running twice does not duplicate edges."""
        _insert_belief(store, "A", "2026-04-20T10:00:00+00:00")
        _insert_belief(store, "B", "2026-04-20T10:05:00+00:00")

        first = store.build_temporal_backbone(gap_minutes=30.0)
        second = store.build_temporal_backbone(gap_minutes=30.0)

        assert first == 1
        assert second == 0

    def test_skips_superseded_beliefs(self, store: MemoryStore) -> None:
        """Only active beliefs get temporal edges."""
        id1 = _insert_belief(store, "Active", "2026-04-20T10:00:00+00:00")
        id2 = _insert_belief(store, "Will be superseded", "2026-04-20T10:05:00+00:00")
        id3 = _insert_belief(store, "Also active", "2026-04-20T10:10:00+00:00")

        # Supersede id2
        store.supersede_belief(id2, id3, "test")

        created = store.build_temporal_backbone(gap_minutes=30.0)

        # id1->id3 (id2 is superseded, skipped)
        assert created == 1
        row = store.query(
            "SELECT from_id, to_id FROM edges WHERE edge_type = 'TEMPORAL_NEXT'"
        )[0]
        assert row["from_id"] == id1
        assert row["to_id"] == id3

    def test_custom_gap(self, store: MemoryStore) -> None:
        """Custom gap_minutes parameter works."""
        _insert_belief(store, "A", "2026-04-20T10:00:00+00:00")
        _insert_belief(store, "B", "2026-04-20T10:20:00+00:00")  # 20min gap

        # 15min gap -- should NOT connect
        assert store.build_temporal_backbone(gap_minutes=15.0) == 0

    def test_empty_database(self, store: MemoryStore) -> None:
        """No crash on empty or single-belief database."""
        assert store.build_temporal_backbone() == 0

        _insert_belief(store, "Solo", "2026-04-20T10:00:00+00:00")
        assert store.build_temporal_backbone() == 0

    def test_edge_weight_and_type(self, store: MemoryStore) -> None:
        """Temporal edges have correct weight and reason."""
        _insert_belief(store, "A", "2026-04-20T10:00:00+00:00")
        _insert_belief(store, "B", "2026-04-20T10:05:00+00:00")

        store.build_temporal_backbone()

        row = store.query(
            "SELECT weight, reason, edge_type FROM edges WHERE edge_type = 'TEMPORAL_NEXT'"
        )[0]
        assert row["weight"] == 0.8
        assert row["reason"] == "temporal_sequence"
        assert row["edge_type"] == "TEMPORAL_NEXT"


# ---------------------------------------------------------------------------
# link_temporal
# ---------------------------------------------------------------------------


class TestLinkTemporal:
    """Tests for store.link_temporal()."""

    def test_links_to_previous_in_session(self, store: MemoryStore) -> None:
        """Links new belief to most recent belief with same session_id."""
        id1 = store.insert_belief(
            content="First in session",
            belief_type="factual",
            source_type="agent_inferred",
            created_at="2026-04-20T10:00:00+00:00",
            session_id="sess-001",
        ).id
        id2 = store.insert_belief(
            content="Second in session",
            belief_type="factual",
            source_type="agent_inferred",
            created_at="2026-04-20T10:05:00+00:00",
            session_id="sess-001",
        ).id

        result = store.link_temporal(id2, "sess-001")

        assert result == 1
        row = store.query(
            "SELECT from_id, to_id FROM edges WHERE edge_type = 'TEMPORAL_NEXT'"
        )[0]
        assert row["from_id"] == id1
        assert row["to_id"] == id2

    def test_no_link_across_sessions(self, store: MemoryStore) -> None:
        """Does not link across different session_ids."""
        store.insert_belief(
            content="Session A",
            belief_type="factual",
            source_type="agent_inferred",
            created_at="2026-04-20T10:00:00+00:00",
            session_id="sess-A",
        )
        id2 = store.insert_belief(
            content="Session B",
            belief_type="factual",
            source_type="agent_inferred",
            created_at="2026-04-20T10:05:00+00:00",
            session_id="sess-B",
        ).id

        result = store.link_temporal(id2, "sess-B")

        assert result == 0

    def test_idempotent(self, store: MemoryStore) -> None:
        """Calling twice does not create duplicate edge."""
        store.insert_belief(
            content="A",
            belief_type="factual",
            source_type="agent_inferred",
            created_at="2026-04-20T10:00:00+00:00",
            session_id="s1",
        )
        id2 = store.insert_belief(
            content="B",
            belief_type="factual",
            source_type="agent_inferred",
            created_at="2026-04-20T10:05:00+00:00",
            session_id="s1",
        ).id

        assert store.link_temporal(id2, "s1") == 1
        assert store.link_temporal(id2, "s1") == 0

    def test_fallback_without_session_id(self, store: MemoryStore) -> None:
        """With session_id=None, links to most recent belief within 30min."""
        _insert_belief(store, "Recent", "2026-04-20T10:00:00+00:00")
        id2 = _insert_belief(store, "Also recent", "2026-04-20T10:05:00+00:00")

        result = store.link_temporal(id2, None)

        assert result == 1

    def test_no_link_if_gap_too_large(self, store: MemoryStore) -> None:
        """With session_id=None, no link if gap > 30min."""
        _insert_belief(store, "Old", "2026-04-20T09:00:00+00:00")
        id2 = _insert_belief(store, "New", "2026-04-20T10:00:00+00:00")  # 60min gap

        result = store.link_temporal(id2, None)

        assert result == 0
