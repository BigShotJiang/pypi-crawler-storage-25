"""TDD tests for data_source traceability through ingest pipeline (GH-19).

Verifies that beliefs created via ingest_turn carry the data_source field
so code-derived beliefs are traceable to their extraction method.
"""

from __future__ import annotations

from collections.abc import Generator
from pathlib import Path

import pytest

from agentmemory.ingest import IngestResult, ingest_turn
from agentmemory.store import MemoryStore


@pytest.fixture()
def store(tmp_path: Path) -> Generator[MemoryStore, None, None]:
    s: MemoryStore = MemoryStore(tmp_path / "test.db")
    yield s
    s.close()


def test_ingest_turn_passes_data_source(store: MemoryStore) -> None:
    """ingest_turn must pass data_source through to created beliefs (GH-19)."""
    result: IngestResult = ingest_turn(
        store=store,
        text="def extract_ast_calls takes project_root and languages parameters",
        source="code",
        data_source="python_ast",
    )
    assert result.beliefs_created > 0

    rows = store.query(
        "SELECT data_source FROM beliefs WHERE data_source = 'python_ast'"
    )
    assert len(rows) > 0, "Beliefs should have data_source='python_ast'"


def test_ingest_turn_data_source_defaults_empty(store: MemoryStore) -> None:
    """Without data_source param, beliefs get empty string (backward compat)."""
    result: IngestResult = ingest_turn(
        store=store,
        text="The deployment target is Ubuntu 22.04 with Python 3.12",
        source="user",
    )
    assert result.beliefs_created > 0

    rows = store.query("SELECT data_source FROM beliefs WHERE data_source = ''")
    assert len(rows) == result.beliefs_created
