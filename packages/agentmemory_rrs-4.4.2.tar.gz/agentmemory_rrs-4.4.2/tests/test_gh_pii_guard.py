"""Tests for agentmemory-gh-pii-guard.sh hook script.

Architecture: the generic hook (scripts/agentmemory-gh-pii-guard.sh) loads patterns
from ~/.agentmemory/pii-patterns.txt and .agentmemory-pii-patterns. Tests use
temporary files and env overrides so they never depend on personal user config.

Each test is atomic, deterministic, and fail-fast.
Run: uv run pytest tests/test_gh_pii_guard.py -v --timeout=10
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path


GENERIC_HOOK = Path(__file__).parent.parent / "scripts" / "agentmemory-gh-pii-guard.sh"


def _run_hook(
    command: str,
    user_patterns: str = "",
    project_patterns: str = "",
) -> subprocess.CompletedProcess[str]:
    """Feed a bash command to the generic hook with controlled pattern files."""
    payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": command}})

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)

        # Write temp user patterns file at $HOME/.agentmemory/pii-patterns.txt
        agentmemory_dir = tmp / ".agentmemory"
        agentmemory_dir.mkdir()
        user_file = agentmemory_dir / "pii-patterns.txt"
        user_file.write_text(user_patterns)

        # Write temp project patterns file (found via CWD)
        project_file = tmp / ".agentmemory-pii-patterns"
        project_file.write_text(project_patterns)

        # Patch HOME so ~/.agentmemory resolves to our temp dir,
        # and set CWD to tmpdir so project-level file is found.
        env = {**os.environ, "HOME": str(tmp)}

        return subprocess.run(
            ["bash", str(GENERIC_HOOK)],
            input=payload,
            capture_output=True,
            text=True,
            timeout=10,
            cwd=str(tmp),
            env=env,
        )


# ---------------------------------------------------------------------------
# Hook exists and is executable
# ---------------------------------------------------------------------------


def test_hook_script_exists() -> None:
    assert GENERIC_HOOK.exists(), f"Hook not found: {GENERIC_HOOK}"


def test_hook_script_is_executable() -> None:
    assert os.access(GENERIC_HOOK, os.X_OK), f"Hook not executable: {GENERIC_HOOK}"


# ---------------------------------------------------------------------------
# Pass cases: non-posting commands or no patterns configured
# ---------------------------------------------------------------------------


def test_non_gh_command_passes_no_patterns() -> None:
    """Non-gh commands always pass, even with patterns configured."""
    result = _run_hook("ls -la", user_patterns="secret-corp\\.com\n")
    assert result.returncode == 0


def test_gh_issue_list_passes() -> None:
    """gh issue list is read-only -- never intercepted."""
    result = _run_hook(
        "gh issue list --repo example/repo",
        user_patterns="sensitive\\.com\n",
    )
    assert result.returncode == 0


def test_gh_issue_view_passes() -> None:
    """gh issue view is read-only -- never intercepted."""
    result = _run_hook(
        "gh issue view 44 --repo example/repo",
        user_patterns="sensitive\\.com\n",
    )
    assert result.returncode == 0


def test_gh_pr_view_passes() -> None:
    """gh pr view is read-only -- never intercepted."""
    result = _run_hook(
        "gh pr view 12 --repo example/repo",
        user_patterns="private-host\n",
    )
    assert result.returncode == 0


def test_no_patterns_configured_passes_all() -> None:
    """When no patterns file exists, hook passes all gh commands through."""
    result = _run_hook(
        'gh issue create --title "test" --body "anything at all"',
        user_patterns="",
        project_patterns="",
    )
    assert result.returncode == 0


def test_clean_content_passes_with_patterns() -> None:
    """gh issue create with content that doesn't match any pattern passes."""
    result = _run_hook(
        'gh issue create --title "bug: scoring off" --body "Steps: run status. Expected: count matches."',
        user_patterns=r"secret-corp\.com" + "\n" + r"\binternal-host\b" + "\n",
    )
    assert result.returncode == 0


def test_clean_pr_create_passes() -> None:
    """gh pr create with no matching content passes."""
    result = _run_hook(
        'gh pr create --title "fix: scoring" --body "Fixes belief score. Tests pass."',
        user_patterns=r"\bprivate\b" + "\n",
    )
    assert result.returncode == 0


def test_comments_and_blanks_in_patterns_file_ignored() -> None:
    """Comment lines and blank lines in patterns file are not treated as patterns."""
    patterns = "# this is a comment\n\n# another comment\n"
    result = _run_hook(
        'gh issue create --title "test" --body "this is a comment"',
        user_patterns=patterns,
    )
    assert result.returncode == 0


# ---------------------------------------------------------------------------
# Block cases: user-level patterns
# ---------------------------------------------------------------------------


def test_blocks_user_pattern_in_body() -> None:
    """Blocks when body matches a user-level pattern."""
    result = _run_hook(
        'gh issue create --title "bug" --body "contact admin@secret-corp.com for details"',
        user_patterns=r"admin@secret-corp\.com" + "\n",
    )
    assert result.returncode == 2


def test_blocks_user_pattern_hostname() -> None:
    """Blocks when body contains a configured internal hostname."""
    result = _run_hook(
        'gh issue create --title "debug" --body "repros on internal-host server"',
        user_patterns=r"\binternal-host\b" + "\n",
    )
    assert result.returncode == 2


def test_blocks_user_pattern_in_title() -> None:
    """Blocks when title (anywhere in the command) matches a pattern."""
    result = _run_hook(
        'gh issue create --title "bug on internal-host" --body "see above"',
        user_patterns=r"\binternal-host\b" + "\n",
    )
    assert result.returncode == 2


def test_blocks_user_pattern_pr_create() -> None:
    """Blocks gh pr create when body matches pattern."""
    result = _run_hook(
        'gh pr create --title "fix" --body "tested on internal-host cluster"',
        user_patterns=r"\binternal-host\b" + "\n",
    )
    assert result.returncode == 2


def test_blocks_user_pattern_issue_comment() -> None:
    """Blocks gh issue comment when content matches pattern."""
    result = _run_hook(
        'gh issue comment 10 --body "config at /home/devuser/secret.conf"',
        user_patterns=r"/home/devuser/" + "\n",
    )
    assert result.returncode == 2


def test_blocks_user_pattern_pr_comment() -> None:
    """Blocks gh pr comment when content matches pattern."""
    result = _run_hook(
        'gh pr comment 5 --body "merge to internal-host branch"',
        user_patterns=r"\binternal-host\b" + "\n",
    )
    assert result.returncode == 2


def test_blocks_user_pattern_release_create() -> None:
    """Blocks gh release create when body matches pattern."""
    result = _run_hook(
        'gh release create v1.0 --notes "built on internal-host"',
        user_patterns=r"\binternal-host\b" + "\n",
    )
    assert result.returncode == 2


def test_blocks_private_filename_prefix() -> None:
    """Blocks gh commands referencing PRIVATE_ files."""
    result = _run_hook(
        'gh issue create --title "bug" --body "see PRIVATE_design.md for context"',
        user_patterns=r"PRIVATE_" + "\n",
    )
    assert result.returncode == 2


def test_first_matching_pattern_blocks() -> None:
    """When multiple patterns configured, first match blocks the command."""
    result = _run_hook(
        'gh issue create --title "test" --body "alpha-project internal-host details"',
        user_patterns=r"\balpha-project\b" + "\n" + r"\binternal-host\b" + "\n",
    )
    assert result.returncode == 2


# ---------------------------------------------------------------------------
# Block cases: project-level patterns
# ---------------------------------------------------------------------------


def test_blocks_project_level_pattern() -> None:
    """Project-level patterns file is also checked."""
    result = _run_hook(
        'gh issue create --title "bug" --body "see project-secret for details"',
        user_patterns="",
        project_patterns=r"\bproject-secret\b" + "\n",
    )
    assert result.returncode == 2


def test_user_and_project_patterns_merged() -> None:
    """Patterns from both files are merged -- either can block."""
    # user pattern doesn't match, project pattern does
    result = _run_hook(
        'gh issue create --title "bug" --body "see project-secret"',
        user_patterns=r"\bother-pattern\b" + "\n",
        project_patterns=r"\bproject-secret\b" + "\n",
    )
    assert result.returncode == 2


# ---------------------------------------------------------------------------
# Block output format (Claude Code hook protocol)
# ---------------------------------------------------------------------------


def test_block_output_is_valid_json() -> None:
    """Block output must be valid JSON per Claude Code hook protocol."""
    result = _run_hook(
        'gh issue create --title "test" --body "contact admin@secret-corp.com"',
        user_patterns=r"admin@secret-corp\.com" + "\n",
    )
    assert result.returncode == 2
    data = json.loads(result.stdout)
    assert data.get("decision") == "block"
    assert "reason" in data
    assert len(data["reason"]) > 10


def test_block_reason_mentions_sensitive_content() -> None:
    """Block reason mentions sensitive/PII to help user understand what to fix."""
    result = _run_hook(
        'gh issue create --title "test" --body "host: internal-host"',
        user_patterns=r"\binternal-host\b" + "\n",
    )
    data = json.loads(result.stdout)
    reason_lower = data["reason"].lower()
    assert any(
        word in reason_lower for word in ["sensitive", "pii", "pattern", "private"]
    )


def test_block_reason_includes_matched_pattern() -> None:
    """Block reason includes identifiable text from the matched pattern."""
    result = _run_hook(
        'gh issue create --title "test" --body "internal-host server"',
        user_patterns=r"\binternal-host\b" + "\n",
    )
    data = json.loads(result.stdout)
    # Pattern may have backslashes encoded differently; check core text is present
    assert "internal-host" in data["reason"]
