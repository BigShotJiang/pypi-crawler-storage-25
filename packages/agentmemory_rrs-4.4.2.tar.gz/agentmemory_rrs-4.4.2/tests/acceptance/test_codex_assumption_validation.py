"""Assumption-validation contracts for Codex integration design.

These tests intentionally encode the desired architecture before implementation:

- Codex parity should rely on MCP + AGENTS.md guidance, with hooks optional.
- Core user-visible features should line up across Claude slash commands and
  Codex guidance.
- Codex hook config must follow the documented hooks.json schema rather than a
  bespoke adapter format.
- MCP parity must include reason(), not just search() and wonder().
"""

from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path
from typing import Generator, cast

import pytest

import agentmemory.server as server_mod
from agentmemory import cli
from agentmemory.server import search as mcp_search
from agentmemory.server import wonder as mcp_wonder


@pytest.fixture(autouse=True)
def _reset_server_store() -> Generator[None, None, None]:  # pyright: ignore[reportUnusedFunction]
    server_mod._set_store(None)  # type: ignore[arg-type]  # pyright: ignore[reportPrivateUsage]
    yield
    server_mod._set_store(None)  # type: ignore[arg-type]  # pyright: ignore[reportPrivateUsage]


def _install_codex_baseline(tmp_path: Path) -> Path:
    cli.cmd_sync_codex_config(
        argparse.Namespace(project=str(tmp_path), codex_dir=None, agentmemory_bin=None)
    )
    cli.cmd_install_codex_fallback(
        argparse.Namespace(project=str(tmp_path), codex_dir=None)
    )
    return tmp_path / ".codex"


def _mcp_tool_names() -> set[str]:
    tools = asyncio.run(server_mod.mcp.list_tools())
    return {tool.name for tool in tools}


def _combined_codex_guidance(codex_dir: Path) -> str:
    parts: list[str] = []
    for name in ("config.toml", "AGENTS.md"):
        path: Path = codex_dir / name
        if path.exists():
            parts.append(path.read_text(encoding="utf-8"))
    return "\n".join(parts)


def test_codex_runtime_contract_advertises_supported_surfaces(tmp_path: Path) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)

    config_text: str = (codex_dir / "config.toml").read_text(encoding="utf-8")
    assert "[mcp_servers.agentmemory]" in config_text
    assert "persistent_instructions" in config_text
    assert (codex_dir / "AGENTS.md").exists()
    assert not (codex_dir / "hooks.json").exists(), "Hooks should remain optional"


def test_codex_runtime_contract_does_not_claim_hook_mcp_interception(
    tmp_path: Path,
) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)
    cli.cmd_install_codex_hook_adapter(
        argparse.Namespace(project=str(tmp_path), codex_dir=None)
    )

    combined: str = _combined_codex_guidance(codex_dir).lower()
    hooks_text: str = (codex_dir / "hooks.json").read_text(encoding="utf-8").lower()
    script_text: str = (
        codex_dir / "hooks" / "agentmemory-hook-adapter.sh"
    ).read_text(encoding="utf-8").lower()

    for text in (combined, hooks_text, script_text):
        assert "intercept mcp" not in text
        assert "mcp tool interception" not in text


def test_codex_instruction_pack_mentions_search_wonder_and_reason(
    tmp_path: Path,
) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)

    guidance: str = _combined_codex_guidance(codex_dir).lower()
    assert "search" in guidance
    assert "wonder" in guidance
    assert "reason" in guidance


def test_codex_instruction_pack_defines_when_to_use_each_tool(tmp_path: Path) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)
    agents_text: str = (codex_dir / "AGENTS.md").read_text(encoding="utf-8").lower()

    assert "search" in agents_text and "memory operations" in agents_text
    assert "wonder" in agents_text and "research" in agents_text
    assert "reason" in agents_text and (
        "decision" in agents_text or "hypothesis" in agents_text
    )


def test_codex_instruction_pack_does_not_claim_hook_based_correctness(
    tmp_path: Path,
) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)
    guidance: str = _combined_codex_guidance(codex_dir).lower()

    assert "automatic hook-based correctness" not in guidance
    assert "rely on hooks for correctness" not in guidance


def test_codex_instruction_pack_remains_concise_and_additive(tmp_path: Path) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)
    agents_text: str = (codex_dir / "AGENTS.md").read_text(encoding="utf-8")

    assert len(agents_text) < 2000
    assert "additive" in agents_text.lower()


def test_claude_and_codex_share_same_core_memory_features(tmp_path: Path) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)
    guidance: str = _combined_codex_guidance(codex_dir).lower()

    claude_core: set[str] = {"search", "wonder", "reason"}
    for feature in claude_core:
        assert feature in cli._COMMAND_DEFS  # pyright: ignore[reportPrivateUsage]
        assert feature in guidance


def test_codex_hook_adapter_uses_documented_hooks_object_shape(tmp_path: Path) -> None:
    cli.cmd_install_codex_hook_adapter(
        argparse.Namespace(project=str(tmp_path), codex_dir=None)
    )

    hooks_path: Path = tmp_path / ".codex" / "hooks.json"
    payload: dict[str, object] = json.loads(hooks_path.read_text(encoding="utf-8"))

    assert set(payload) == {"hooks"}
    assert isinstance(payload["hooks"], dict)


def test_codex_hook_adapter_uses_only_documented_events(tmp_path: Path) -> None:
    cli.cmd_install_codex_hook_adapter(
        argparse.Namespace(project=str(tmp_path), codex_dir=None)
    )

    hooks_path: Path = tmp_path / ".codex" / "hooks.json"
    payload: dict[str, object] = json.loads(hooks_path.read_text(encoding="utf-8"))

    documented: set[str] = {
        "SessionStart",
        "PreToolUse",
        "PermissionRequest",
        "PostToolUse",
        "UserPromptSubmit",
        "Stop",
    }

    actual: set[str]
    if "hooks" in payload and isinstance(payload["hooks"], dict):
        actual = set(payload["hooks"].keys())  # type: ignore[union-attr]
    else:
        events: object = payload.get("events", [])
        actual = set(cast(list[str], events)) if isinstance(events, list) else set()

    assert actual <= documented


def test_codex_hook_adapter_resolves_repo_local_commands_from_git_root(
    tmp_path: Path,
) -> None:
    cli.cmd_install_codex_hook_adapter(
        argparse.Namespace(project=str(tmp_path), codex_dir=None)
    )

    hooks_text: str = (tmp_path / ".codex" / "hooks.json").read_text(encoding="utf-8")
    assert "git rev-parse --show-toplevel" in hooks_text


def test_codex_hook_adapter_explicitly_mentions_windows_gating(
    tmp_path: Path,
) -> None:
    cli.cmd_install_codex_hook_adapter(
        argparse.Namespace(project=str(tmp_path), codex_dir=None)
    )

    combined: str = (
        (tmp_path / ".codex" / "hooks.json").read_text(encoding="utf-8")
        + "\n"
        + (tmp_path / ".codex" / "hooks" / "agentmemory-hook-adapter.sh").read_text(
            encoding="utf-8"
        )
    ).lower()
    assert "windows" in combined and "disabled" in combined


def test_search_cli_and_mcp_return_equivalent_hits(
    capsys: object,
) -> None:
    cli.cmd_remember(argparse.Namespace(text=["Use", "uv", "for", "package", "management"]))
    capsys.readouterr()  # type: ignore[attr-defined]

    cli.cmd_search(argparse.Namespace(query=["uv", "package", "management"], budget=2000))
    cli_out: str = str(capsys.readouterr().out)  # type: ignore[attr-defined]
    mcp_out: str = mcp_search("uv package management")

    expected: str = "Use uv for package management"
    assert expected in cli_out
    assert expected in mcp_out
    assert "Found" in cli_out
    assert "Found" in mcp_out


def test_wonder_cli_and_mcp_expose_equivalent_structure(
    capsys: object,
) -> None:
    cli.cmd_remember(
        argparse.Namespace(
            text=["The", "deployment", "pipeline", "uses", "Canary", "releases"]
        )
    )
    capsys.readouterr()  # type: ignore[attr-defined]

    cli.cmd_wonder(
        argparse.Namespace(query=["deployment", "pipeline"], depth=2, budget=2000)
    )
    cli_out: str = str(capsys.readouterr().out)  # type: ignore[attr-defined]
    mcp_payload: dict[str, object] = json.loads(mcp_wonder("deployment pipeline"))
    cli_out_lower: str = cli_out.lower()

    assert "coverage_score" in mcp_payload
    assert "research_axes" in mcp_payload
    assert "coverage score" in cli_out_lower
    assert "research axes" in cli_out_lower


def test_reason_requires_mcp_surface_for_cli_parity() -> None:
    assert "reason" in cli._COMMAND_DEFS  # pyright: ignore[reportPrivateUsage]
    assert "reason" in _mcp_tool_names()


def test_codex_no_hook_mode_keeps_search_available(tmp_path: Path) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)

    cli.cmd_remember(argparse.Namespace(text=["Search-only", "baseline", "belief"]))
    result: str = mcp_search("search-only baseline")

    assert not (codex_dir / "hooks.json").exists()
    assert "Search-only baseline belief" in result


def test_codex_no_hook_mode_keeps_wonder_available_without_hooks(
    tmp_path: Path,
) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)
    guidance: str = _combined_codex_guidance(codex_dir).lower()

    assert not (codex_dir / "hooks.json").exists()
    assert "wonder" in guidance
    assert "wonder" in _mcp_tool_names()


def test_codex_no_hook_mode_keeps_reason_available_without_hooks(
    tmp_path: Path,
) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)
    guidance: str = _combined_codex_guidance(codex_dir).lower()

    assert not (codex_dir / "hooks.json").exists()
    assert "reason" in guidance
    assert "reason" in _mcp_tool_names()


def test_codex_setup_path_does_not_mark_hooks_required(tmp_path: Path) -> None:
    codex_dir: Path = _install_codex_baseline(tmp_path)
    guidance: str = _combined_codex_guidance(codex_dir).lower()

    assert "required hook" not in guidance
    assert "hooks required" not in guidance
