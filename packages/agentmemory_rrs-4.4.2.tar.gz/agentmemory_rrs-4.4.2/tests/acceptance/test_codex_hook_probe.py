"""Acceptance tests for Codex hook probing workflow.

Hypotheses under test:
- Codex hook-path probing should test project-local candidates explicitly.
- If a candidate path produces identical prompt-input output, report no effect.
- If a candidate path changes prompt-input behavior, report it as active.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pytest


def _fake_which(_name: str) -> str:
    return "/usr/local/bin/codex"


def test_codex_probe_function_exists() -> None:
    from agentmemory.cli import cmd_probe_codex_hooks  # type: ignore[attr-defined]

    assert callable(cmd_probe_codex_hooks)


def test_codex_probe_checks_project_candidates(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory import cli

    calls: list[list[str]] = []

    def fake_prompt_probe(
        codex_bin: str, project_dir: Path, prompt: str
    ) -> tuple[int, str, str]:
        calls.append([codex_bin, str(project_dir), prompt])
        return (0, "same", "")

    monkeypatch.setattr(cli, "_run_codex_prompt_probe", fake_prompt_probe)
    monkeypatch.setattr(cli.shutil, "which", _fake_which)

    cli.cmd_probe_codex_hooks(
        argparse.Namespace(prompt="probe", include_home=False, project=str(tmp_path))
    )

    out: str = capsys.readouterr().out
    assert "hooks.json" in out
    assert ".codex/hooks.json" in out
    assert len(calls) == 3, "Expected baseline plus two project candidate probes"


def test_codex_probe_reports_no_effect_when_output_matches(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory import cli

    def fake_prompt_probe(
        codex_bin: str, project_dir: Path, prompt: str
    ) -> tuple[int, str, str]:
        return (0, "baseline", "")

    monkeypatch.setattr(cli, "_run_codex_prompt_probe", fake_prompt_probe)
    monkeypatch.setattr(cli.shutil, "which", _fake_which)

    cli.cmd_probe_codex_hooks(
        argparse.Namespace(prompt="probe", include_home=False, project=str(tmp_path))
    )

    out: str = capsys.readouterr().out
    assert "no effect detected" in out


def test_codex_probe_reports_changed_behavior(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory import cli

    counter: dict[str, int] = {"n": 0}

    def fake_prompt_probe(
        codex_bin: str, project_dir: Path, prompt: str
    ) -> tuple[int, str, str]:
        counter["n"] += 1
        if counter["n"] == 1:
            return (0, "baseline", "")
        if counter["n"] == 2:
            return (1, "", "parse error")
        return (0, "baseline", "")

    monkeypatch.setattr(cli, "_run_codex_prompt_probe", fake_prompt_probe)
    monkeypatch.setattr(cli.shutil, "which", _fake_which)

    cli.cmd_probe_codex_hooks(
        argparse.Namespace(prompt="probe", include_home=False, project=str(tmp_path))
    )

    out: str = capsys.readouterr().out
    assert "changed behavior" in out or "error" in out


def test_codex_probe_supports_exec_surface(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory import cli

    calls: list[tuple[str, str, str]] = []

    def fake_exec_probe(
        codex_bin: str, project_dir: Path, prompt: str
    ) -> tuple[int, str, str]:
        calls.append((codex_bin, str(project_dir), prompt))
        return (0, "baseline", "")

    monkeypatch.setattr(cli, "_run_codex_exec_probe", fake_exec_probe)
    monkeypatch.setattr(cli.shutil, "which", _fake_which)

    cli.cmd_probe_codex_hooks(
        argparse.Namespace(
            prompt="probe",
            include_home=False,
            project=str(tmp_path),
            surface="exec",
        )
    )

    out: str = capsys.readouterr().out
    assert "codex exec" in out
    assert len(calls) == 3, "Expected baseline plus two project candidate probes"


def test_codex_probe_skips_unwritable_candidate(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory import cli

    def fake_prompt_probe(
        codex_bin: str, project_dir: Path, prompt: str
    ) -> tuple[int, str, str]:
        return (0, "baseline", "")

    original_write_text = Path.write_text

    def fake_write_text(
        self: Path, data: str, encoding: str | None = None, errors: str | None = None
    ) -> int:
        if str(self).endswith(".codex/hooks.json"):
            raise PermissionError("simulated permission denied")
        return original_write_text(self, data, encoding=encoding, errors=errors)

    monkeypatch.setattr(cli, "_run_codex_prompt_probe", fake_prompt_probe)
    monkeypatch.setattr(cli.shutil, "which", _fake_which)
    monkeypatch.setattr(Path, "write_text", fake_write_text)

    cli.cmd_probe_codex_hooks(
        argparse.Namespace(prompt="probe", include_home=False, project=str(tmp_path))
    )

    out: str = capsys.readouterr().out
    assert "skipped (permission denied)" in out


def test_codex_probe_exec_ignores_volatile_session_fields(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory import cli

    counter: dict[str, int] = {"n": 0}

    def fake_exec_probe(
        codex_bin: str, project_dir: Path, prompt: str
    ) -> tuple[int, str, str]:
        counter["n"] += 1
        stderr: str = (
            "OpenAI Codex v0.122.0\n"
            f"session id: session-{counter['n']}\n"
            "tokens used\n"
            f"{1000 + counter['n']}\n"
        )
        return (0, "OK", stderr)

    monkeypatch.setattr(cli, "_run_codex_exec_probe", fake_exec_probe)
    monkeypatch.setattr(cli.shutil, "which", _fake_which)

    cli.cmd_probe_codex_hooks(
        argparse.Namespace(
            prompt="probe",
            include_home=False,
            project=str(tmp_path),
            surface="exec",
        )
    )

    out: str = capsys.readouterr().out
    assert "no effect detected" in out
