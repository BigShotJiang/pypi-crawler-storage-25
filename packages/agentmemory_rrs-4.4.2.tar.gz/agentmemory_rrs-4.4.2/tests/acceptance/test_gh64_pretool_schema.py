"""GH-64: setup should always write valid Claude PreToolUse hook shape."""

# pyright: reportPrivateUsage=false

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

import pytest


def _assert_valid_pretool_shape(settings_file: Path) -> list[dict[str, Any]]:
    settings: dict[str, Any] = json.loads(settings_file.read_text(encoding="utf-8"))
    hooks: dict[str, Any] = cast(dict[str, Any], settings.get("hooks", {}))
    pre_tool: list[dict[str, Any]] = cast(
        list[dict[str, Any]], hooks.get("PreToolUse", [])
    )
    assert isinstance(pre_tool, list)
    for entry in pre_tool:
        assert isinstance(entry.get("matcher"), str) and bool(entry.get("matcher"))
        entry_hooks: Any = entry.get("hooks")
        assert isinstance(entry_hooks, list)
        hooks_list: list[dict[str, Any]] = cast(list[dict[str, Any]], entry_hooks)
        assert len(hooks_list) >= 1
        for hook in hooks_list:
            assert isinstance(hook, dict)
            assert isinstance(hook.get("command"), str) and bool(hook.get("command"))
    return pre_tool


def test_gh64_normalizer_wraps_legacy_entries() -> None:
    from agentmemory.cli import (  # pyright: ignore[reportPrivateUsage]
        _normalize_pre_tool_use_entries,
    )

    entries: list[Any] = [
        {"type": "command", "command": "agentmemory commit-check"},
        {"matcher": "Agent", "hooks": [{"type": "command", "command": "bash gate.sh"}]},
        {"matcher": "Bash"},  # invalid -> dropped
    ]
    normalized, changed = _normalize_pre_tool_use_entries(entries)  # pyright: ignore[reportPrivateUsage]

    assert changed is True
    assert len(normalized) == 2
    assert normalized[0]["matcher"] == ".*"
    assert normalized[0]["hooks"][0]["command"] == "agentmemory commit-check"
    assert normalized[1]["matcher"] == "Agent"
    assert normalized[1]["hooks"][0]["command"] == "bash gate.sh"


def test_gh64_commit_install_repairs_invalid_pretool_shape(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    settings_file: Path = tmp_path / "settings.json"
    settings_file.write_text(
        json.dumps({"hooks": {"PreToolUse": [{"matcher": "Bash"}]}}),
        encoding="utf-8",
    )
    monkeypatch.setattr("agentmemory.cli._SETTINGS_PATH", settings_file)

    from agentmemory.cli import _install_commit_hook  # pyright: ignore[reportPrivateUsage]

    _install_commit_hook(agentmemory_bin="/usr/local/bin/agentmemory")

    pre_tool: list[dict[str, Any]] = _assert_valid_pretool_shape(settings_file)
    assert any(
        "agentmemory commit-check" in str(hook.get("command", ""))
        for entry in pre_tool
        for hook in cast(list[dict[str, Any]], entry.get("hooks", []))
    )
