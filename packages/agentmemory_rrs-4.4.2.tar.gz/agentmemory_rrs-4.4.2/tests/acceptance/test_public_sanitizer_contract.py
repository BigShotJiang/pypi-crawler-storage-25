"""Regression-contract tests for a privacy-safe public artifact sanitizer.

Note: sanitize-for-public.sh is excluded from the public GitHub repo because it
contains hard-coded private PII patterns (internal IPs, hostnames, usernames).
These tests are skipped in CI and only run locally where the script is present.
"""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

import pytest


SANITIZER = Path(__file__).parent.parent.parent / "scripts" / "sanitize-for-public.sh"
_SANITIZER_MISSING = not SANITIZER.exists()

SYNTHETIC_GITEA_FIXTURE = """\
{"timestamp":"2026-04-20T11:00:00Z","event":"user","tool_name":"Bash","text":"Check repo /Users/thelorax/projects/private-repo on http://10.24.8.9:3000/gitea/jso/private-repo"}
{"timestamp":"2026-04-20T11:00:02Z","event":"assistant","tool_name":"mcp__agentmemory__search","text":"Searching for deploy runbook from mintaka.internal by thelorax <thelorax@example.com>"}
{"timestamp":"2026-04-20T11:00:05Z","event":"tool_error","tool_name":"Bash","text":"git ls-remote ssh://gitea.internal/jso/private-repo failed with exit status 128"}
"""


def _run_sanitizer(raw_text: str) -> str:
    assert SANITIZER.exists(), f"Missing sanitizer script: {SANITIZER}"

    with tempfile.TemporaryDirectory() as tmpdir:
        fixture_path = Path(tmpdir) / "raw-fixture.jsonl"
        fixture_path.write_text(raw_text, encoding="utf-8")

        result = subprocess.run(
            ["bash", str(SANITIZER), "--apply", str(fixture_path)],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0, result.stderr or result.stdout
        return fixture_path.read_text(encoding="utf-8")


@pytest.mark.skipif(_SANITIZER_MISSING, reason="sanitize-for-public.sh excluded from public repo")
def test_public_sanitizer_redacts_private_identifiers() -> None:
    sanitized: str = _run_sanitizer(SYNTHETIC_GITEA_FIXTURE)

    forbidden = [
        "10.24.8.9",
        "http://10.24.8.9:3000",
        "gitea.internal",
        "mintaka.internal",
        "thelorax@example.com",
        "/Users/thelorax/projects/private-repo",
        "private-repo",
        "thelorax",
        "jso/",
    ]
    for token in forbidden:
        assert token not in sanitized


@pytest.mark.skipif(_SANITIZER_MISSING, reason="sanitize-for-public.sh excluded from public repo")
def test_public_sanitizer_preserves_event_order_tool_names_and_failure_semantics() -> None:
    sanitized: str = _run_sanitizer(SYNTHETIC_GITEA_FIXTURE)
    lines: list[str] = sanitized.strip().splitlines()

    assert len(lines) == 3
    assert '"timestamp":"2026-04-20T11:00:00Z"' in lines[0]
    assert '"timestamp":"2026-04-20T11:00:02Z"' in lines[1]
    assert '"timestamp":"2026-04-20T11:00:05Z"' in lines[2]
    assert '"tool_name":"Bash"' in sanitized
    assert '"tool_name":"mcp__agentmemory__search"' in sanitized
    assert '"event":"tool_error"' in sanitized
    assert "exit status 128" in sanitized


@pytest.mark.skipif(_SANITIZER_MISSING, reason="sanitize-for-public.sh excluded from public repo")
def test_public_sanitizer_output_passes_basic_pii_guard_patterns() -> None:
    sanitized: str = _run_sanitizer(SYNTHETIC_GITEA_FIXTURE)

    blocked_patterns = [
        "10.24.8.9",
        "@example.com",
        "gitea.internal",
        "mintaka.internal",
        "/Users/",
    ]
    for pattern in blocked_patterns:
        assert pattern not in sanitized
