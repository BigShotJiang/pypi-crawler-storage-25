"""Acceptance tests for Codex fallback automation commands."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess

import pytest


def test_codex_fallback_commands_exist() -> None:
    from agentmemory.cli import (  # type: ignore[attr-defined]
        cmd_install_codex_fallback,
        cmd_install_codex_hook_adapter,
        cmd_sync_codex_config,
    )

    assert callable(cmd_sync_codex_config)
    assert callable(cmd_install_codex_fallback)
    assert callable(cmd_install_codex_hook_adapter)


def test_sync_codex_config_creates_managed_block(tmp_path: Path) -> None:
    from agentmemory import cli

    cli.cmd_sync_codex_config(
        argparse.Namespace(project=str(tmp_path), codex_dir=None, agentmemory_bin=None)
    )

    config_path: Path = tmp_path / ".codex" / "config.toml"
    text: str = config_path.read_text(encoding="utf-8")
    assert "[mcp_servers.agentmemory]" in text
    assert 'args = ["mcp"]' in text
    assert "persistent_instructions" in text
    assert "AGENTMEMORY MANAGED BLOCK: CODEX CONFIG" in text


def test_sync_codex_config_idempotent(tmp_path: Path) -> None:
    from agentmemory import cli

    args = argparse.Namespace(project=str(tmp_path), codex_dir=None, agentmemory_bin=None)
    cli.cmd_sync_codex_config(args)
    cli.cmd_sync_codex_config(args)

    config_path: Path = tmp_path / ".codex" / "config.toml"
    text: str = config_path.read_text(encoding="utf-8")
    assert text.count("AGENTMEMORY MANAGED BLOCK: CODEX CONFIG") == 2
    assert text.count("[mcp_servers.agentmemory]") == 1


def test_install_codex_fallback_preserves_existing_content(tmp_path: Path) -> None:
    from agentmemory import cli

    codex_dir: Path = tmp_path / ".codex"
    codex_dir.mkdir(parents=True, exist_ok=True)
    agents_path: Path = codex_dir / "AGENTS.md"
    agents_path.write_text("# Custom Header\n", encoding="utf-8")

    cli.cmd_install_codex_fallback(
        argparse.Namespace(project=str(tmp_path), codex_dir=None)
    )

    text: str = agents_path.read_text(encoding="utf-8")
    assert "# Custom Header" in text
    assert "AGENTMEMORY MANAGED BLOCK: CODEX FALLBACK POLICY" in text
    assert "Use agentmemory MCP tools" in text


def test_install_codex_hook_adapter_writes_script_and_hooks_file(tmp_path: Path) -> None:
    from agentmemory import cli

    cli.cmd_install_codex_hook_adapter(
        argparse.Namespace(project=str(tmp_path), codex_dir=None)
    )

    codex_dir: Path = tmp_path / ".codex"
    script_path: Path = codex_dir / "hooks" / "agentmemory-hook-adapter.sh"
    hooks_path: Path = codex_dir / "hooks.json"

    assert script_path.exists()
    assert hooks_path.exists()
    assert os.access(script_path, os.X_OK), "Adapter script should be executable"

    hooks_text: str = hooks_path.read_text(encoding="utf-8")
    assert "AGENTMEMORY MANAGED BLOCK: CODEX HOOK ADAPTER" in hooks_text
    assert "agentmemory-hook-adapter.sh" in hooks_text
    assert "UserPromptSubmit" in hooks_text
    assert "PostCompact" in hooks_text
    assert "SubagentStop" in hooks_text

    script_text: str = script_path.read_text(encoding="utf-8")
    assert "conversation-logs" in script_text
    assert "turns.jsonl" in script_text
    assert "session-complete --log" in script_text


def test_setup_codex_installs_recommended_baseline(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory import cli

    def fake_which(name: str) -> str | None:
        if name == "codex":
            return "/usr/local/bin/codex"
        if name == "agentmemory":
            return "/usr/local/bin/agentmemory"
        return None

    def fake_run(
        args: list[str], capture_output: bool, text: bool
    ) -> subprocess.CompletedProcess[str]:
        assert capture_output is True
        assert text is True
        if args[:4] == ["/usr/local/bin/codex", "mcp", "get", "agentmemory"]:
            return subprocess.CompletedProcess(args, 1, "", "not found")
        if args[:4] == ["/usr/local/bin/codex", "mcp", "add", "agentmemory"]:
            return subprocess.CompletedProcess(args, 0, "added", "")
        raise AssertionError(f"Unexpected subprocess call: {args}")

    monkeypatch.setattr(cli.shutil, "which", fake_which)
    monkeypatch.setattr(subprocess, "run", fake_run)

    cli.cmd_setup_codex(
        argparse.Namespace(
            enable_hooks_feature=False,
            project=str(tmp_path),
            codex_dir=None,
        )
    )

    codex_dir: Path = tmp_path / ".codex"
    config_text: str = (codex_dir / "config.toml").read_text(encoding="utf-8")
    agents_text: str = (codex_dir / "AGENTS.md").read_text(encoding="utf-8")

    assert "[mcp_servers.agentmemory]" in config_text
    assert "persistent_instructions" in config_text
    assert "AGENTMEMORY MANAGED BLOCK: CODEX FALLBACK POLICY" in agents_text
    assert "wonder" in agents_text
    assert "reason" in agents_text


def test_setup_codex_is_idempotent_for_local_guidance(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory import cli

    get_calls: dict[str, int] = {"n": 0}

    def fake_which(name: str) -> str | None:
        if name == "codex":
            return "/usr/local/bin/codex"
        if name == "agentmemory":
            return "/usr/local/bin/agentmemory"
        return None

    def fake_run(
        args: list[str], capture_output: bool, text: bool
    ) -> subprocess.CompletedProcess[str]:
        assert capture_output is True
        assert text is True
        if args[:4] == ["/usr/local/bin/codex", "mcp", "get", "agentmemory"]:
            get_calls["n"] += 1
            if get_calls["n"] == 1:
                return subprocess.CompletedProcess(args, 1, "", "not found")
            return subprocess.CompletedProcess(args, 0, "configured", "")
        if args[:4] == ["/usr/local/bin/codex", "mcp", "add", "agentmemory"]:
            return subprocess.CompletedProcess(args, 0, "added", "")
        raise AssertionError(f"Unexpected subprocess call: {args}")

    monkeypatch.setattr(cli.shutil, "which", fake_which)
    monkeypatch.setattr(subprocess, "run", fake_run)

    args = argparse.Namespace(
        enable_hooks_feature=False,
        project=str(tmp_path),
        codex_dir=None,
    )
    cli.cmd_setup_codex(args)
    cli.cmd_setup_codex(args)

    codex_dir: Path = tmp_path / ".codex"
    config_text: str = (codex_dir / "config.toml").read_text(encoding="utf-8")
    agents_text: str = (codex_dir / "AGENTS.md").read_text(encoding="utf-8")

    assert config_text.count("[mcp_servers.agentmemory]") == 1
    assert (
        agents_text.count("AGENTMEMORY MANAGED BLOCK: CODEX FALLBACK POLICY") == 2
    )
