"""GH-31: agentmemory setup must register the agent-gate hook.

Pass criteria:
- The agent gate script exists and is executable.
- _install_agent_gate is importable and callable.
- _install_agent_gate is idempotent (calling twice does not duplicate the hook).
- The hook entry uses matcher "Agent" and references agentmemory-agent-gate.
"""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from typing import Any, cast

import pytest

REPO_ROOT: Path = Path(__file__).resolve().parents[2]
GATE_SCRIPT: Path = REPO_ROOT / "scripts" / "agentmemory-agent-gate.sh"

_GATE_MISSING: bool = not GATE_SCRIPT.exists()


def _extract_agent_gate_hooks(settings_file: Path) -> list[dict[str, str]]:
    """Parse settings.json and return PreToolUse entries matching agent-gate."""
    settings: dict[str, Any] = json.loads(settings_file.read_text())
    hooks_dict: dict[str, Any] = cast(dict[str, Any], settings.get("hooks", {}))
    pre_tool: list[dict[str, Any]] = cast(
        list[dict[str, Any]], hooks_dict.get("PreToolUse", [])
    )
    matches: list[dict[str, str]] = []
    for entry in pre_tool:
        entry_hooks: list[dict[str, str]] = cast(
            list[dict[str, str]], entry.get("hooks", [])
        )
        if any("agent-gate" in h.get("command", "") for h in entry_hooks):
            matches.append(cast(dict[str, str], entry))
    return matches


@pytest.mark.skipif(_GATE_MISSING, reason="scripts/ excluded from public repo")
def test_gh31_gate_script_exists() -> None:
    """The agent gate shell script exists at the expected path."""
    assert GATE_SCRIPT.exists(), f"Agent gate script not found at {GATE_SCRIPT}"


@pytest.mark.skipif(_GATE_MISSING, reason="scripts/ excluded from public repo")
def test_gh31_gate_script_is_executable() -> None:
    """The agent gate shell script has the executable bit set."""
    mode: int = os.stat(GATE_SCRIPT).st_mode
    assert mode & stat.S_IXUSR, f"Agent gate script not user-executable (mode={oct(mode)})"


def test_gh31_install_function_exists() -> None:
    """_install_agent_gate is importable from the cli module."""
    from agentmemory.cli import _install_agent_gate  # type: ignore[attr-access]

    assert callable(_install_agent_gate)


@pytest.mark.skipif(_GATE_MISSING, reason="scripts/ excluded from public repo")
def test_gh31_install_idempotent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Calling _install_agent_gate twice does not duplicate the hook entry."""
    settings_file: Path = tmp_path / "settings.json"
    settings_file.write_text("{}")
    monkeypatch.setattr("agentmemory.cli._SETTINGS_PATH", settings_file)

    from agentmemory.cli import _install_agent_gate  # type: ignore[attr-access]

    _install_agent_gate()
    _install_agent_gate()

    agent_hooks: list[dict[str, str]] = _extract_agent_gate_hooks(settings_file)
    assert len(agent_hooks) == 1, f"Expected 1 agent gate hook, found {len(agent_hooks)}"


@pytest.mark.skipif(_GATE_MISSING, reason="scripts/ excluded from public repo")
def test_gh31_hook_uses_agent_matcher(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """The installed hook entry uses matcher 'Agent'."""
    settings_file: Path = tmp_path / "settings.json"
    settings_file.write_text("{}")
    monkeypatch.setattr("agentmemory.cli._SETTINGS_PATH", settings_file)

    from agentmemory.cli import _install_agent_gate  # type: ignore[attr-access]

    _install_agent_gate()

    agent_hooks: list[dict[str, str]] = _extract_agent_gate_hooks(settings_file)
    assert len(agent_hooks) == 1
    assert agent_hooks[0].get("matcher") == "Agent"


def test_gh31_setup_calls_agent_gate() -> None:
    """The setup function's source references _install_agent_gate."""
    import inspect

    from agentmemory.cli import cmd_setup

    source: str = inspect.getsource(cmd_setup)
    assert "_install_agent_gate" in source, "setup() must call _install_agent_gate()"
