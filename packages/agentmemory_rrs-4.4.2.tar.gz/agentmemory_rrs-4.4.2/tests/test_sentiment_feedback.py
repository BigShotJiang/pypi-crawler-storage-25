"""Tests for natural language sentiment feedback detection."""

from __future__ import annotations

import pytest

from agentmemory.sentiment_feedback import (
    SentimentSignal,
    apply_sentiment_to_pending,
    detect_correction_frequency,
    detect_sentiment,
)


# ---------------------------------------------------------------------------
# Positive sentiment detection
# ---------------------------------------------------------------------------


class TestPositiveSentiment:
    """User approval/confirmation patterns."""

    @pytest.mark.parametrize(
        "text",
        [
            "ok good",
            "yes",
            "yeah",
            "yep",
            "nice",
            "perfect",
            "exactly",
            "cool",
            "great",
            "ok",
            "yes lets do that",
            "good lets proceed",
            "i like that",
            "thats correct",
            "lets go",
            "proceed",
            "continue",
            "ok good now lets do this",
            "yeah this is cool",
        ],
    )
    def test_positive_detected(self, text: str) -> None:
        result: SentimentSignal = detect_sentiment(text)
        assert result.sentiment == "positive", f"Expected positive for: {text!r}, got {result}"
        assert result.valence > 0

    @pytest.mark.parametrize(
        "text",
        [
            "perfect",
            "exactly",
            "yes write it up verbatim thats amazing",
        ],
    )
    def test_strong_positive(self, text: str) -> None:
        result: SentimentSignal = detect_sentiment(text)
        assert result.sentiment == "positive"
        assert result.valence >= 0.5


# ---------------------------------------------------------------------------
# Negative sentiment detection
# ---------------------------------------------------------------------------


class TestNegativeSentiment:
    """User correction/rejection patterns."""

    @pytest.mark.parametrize(
        "text",
        [
            "no thats not right",
            "nah",
            "wrong",
            "thats wrong",
            "thats broken",
            "stop it",
            "fix it",
            "not right",
            "still broken",
            "doesnt work",
            "not working",
            "no, do it the other way",
        ],
    )
    def test_negative_detected(self, text: str) -> None:
        result: SentimentSignal = detect_sentiment(text)
        assert result.sentiment == "negative", f"Expected negative for: {text!r}, got {result}"
        assert result.valence < 0

    @pytest.mark.parametrize(
        "text",
        [
            "i told you to fix it and you didnt",
            "you forgot about it",
            "you ignored my instruction",
            "i told you already",
        ],
    )
    def test_strong_negative(self, text: str) -> None:
        result: SentimentSignal = detect_sentiment(text)
        assert result.sentiment == "negative"
        assert result.valence <= -0.6


# ---------------------------------------------------------------------------
# Neutral / no signal
# ---------------------------------------------------------------------------


class TestNeutralSentiment:
    """Messages that should NOT trigger sentiment updates."""

    @pytest.mark.parametrize(
        "text",
        [
            "what is the current status of the project?",
            "can you read the file at src/main.py",
            "run the tests",
            "show me the git log",
            # Long task content should be ignored
            "x" * 250,
            # System content
            "<task-notification>some xml</task-notification>",
            '{"json": "content"}',
        ],
    )
    def test_neutral(self, text: str) -> None:
        result: SentimentSignal = detect_sentiment(text)
        assert result.sentiment == "neutral", f"Expected neutral for: {text!r}, got {result}"


# ---------------------------------------------------------------------------
# Sentiment -> belief valence mapping
# ---------------------------------------------------------------------------


class TestSentimentApplication:
    """Map sentiment signals to pending beliefs."""

    def test_positive_distributes_valence(self) -> None:
        signal: SentimentSignal = SentimentSignal("positive", 0.3, 0.7, "ok good")
        pending: list[tuple[str, str]] = [
            ("belief1", "content1"),
            ("belief2", "content2"),
        ]
        updates: list[tuple[str, float]] = apply_sentiment_to_pending(signal, pending)
        assert len(updates) == 2
        assert all(v > 0 for _, v in updates)

    def test_negative_distributes_negative_valence(self) -> None:
        signal: SentimentSignal = SentimentSignal("negative", -0.4, 0.7, "no")
        pending: list[tuple[str, str]] = [("belief1", "c1")]
        updates = apply_sentiment_to_pending(signal, pending)
        assert len(updates) == 1
        assert updates[0][1] < 0

    def test_neutral_produces_no_updates(self) -> None:
        signal: SentimentSignal = SentimentSignal("neutral", 0.0, 0.0, "none")
        pending: list[tuple[str, str]] = [("belief1", "c1")]
        updates = apply_sentiment_to_pending(signal, pending)
        assert len(updates) == 0

    def test_empty_pending_produces_no_updates(self) -> None:
        signal: SentimentSignal = SentimentSignal("positive", 0.3, 0.7, "yes")
        updates = apply_sentiment_to_pending(signal, [])
        assert len(updates) == 0


# ---------------------------------------------------------------------------
# Correction frequency detection
# ---------------------------------------------------------------------------


class TestCorrectionFrequency:
    """Detect negative patterns from correction frequency."""

    def test_high_correction_rate(self) -> None:
        signals: list[SentimentSignal] = [
            SentimentSignal("negative", -0.4, 0.7, "no"),
            SentimentSignal("negative", -0.4, 0.7, "wrong"),
            SentimentSignal("negative", -0.4, 0.7, "fix it"),
            SentimentSignal("positive", 0.3, 0.7, "ok"),
            SentimentSignal("negative", -0.4, 0.7, "still wrong"),
        ]
        freq: float = detect_correction_frequency(signals, window=5)
        assert freq < -0.5  # 4/5 = 80% negative

    def test_low_correction_rate_no_signal(self) -> None:
        signals: list[SentimentSignal] = [
            SentimentSignal("positive", 0.3, 0.7, "yes"),
            SentimentSignal("positive", 0.3, 0.7, "good"),
            SentimentSignal("neutral", 0.0, 0.0, "none"),
            SentimentSignal("positive", 0.3, 0.7, "ok"),
            SentimentSignal("negative", -0.4, 0.7, "no"),
        ]
        freq = detect_correction_frequency(signals, window=5)
        assert freq == 0.0  # Only 1/5 = 20%, below 40% threshold

    def test_single_message_no_signal(self) -> None:
        signals: list[SentimentSignal] = [
            SentimentSignal("negative", -0.4, 0.7, "no"),
        ]
        freq = detect_correction_frequency(signals, window=5)
        assert freq == 0.0
