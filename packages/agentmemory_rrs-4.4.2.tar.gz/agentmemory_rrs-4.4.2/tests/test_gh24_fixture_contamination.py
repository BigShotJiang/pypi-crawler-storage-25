"""GH-24: Test fixture text must not contaminate the knowledge graph.

The conversation logger captures all content including tool output (pytest
results, file reads of test fixtures). When this content is ingested via
PostCompact -> agentmemory ingest, synthetic test strings could be stored
as real beliefs.

Pass criteria:
- Known test fixture patterns are detected and skipped during ingestion
- Real conversation content passes through unaffected
- The filter is applied in ingest_turn when data_source indicates tool output
- Content from tests/ file paths is flagged
"""

from __future__ import annotations

import pytest

# ---------------------------------------------------------------------------
# Test fixture patterns that should be filtered
# ---------------------------------------------------------------------------

# These are representative strings found in test fixtures that could
# be misclassified as real corrections or beliefs if ingested.
FIXTURE_CORRECTIONS: list[str] = [
    "No, we already decided not to use PostgreSQL for storage",
    "Don't do that, always run tests before committing",
    "That's wrong, the half-life for factual beliefs is 14 days not 7",
    "Stop using async, we agreed on sync-only architecture",
    "Never use mocks for database tests",
]

# Real conversation content that should NOT be filtered
REAL_CONTENT: list[str] = [
    "The search pipeline uses FTS5 with BM25 scoring",
    "We decided to use SQLite with WAL mode for persistence",
    "I think the correction classifier threshold should be 2 not 1",
    "Can you check if the test suite passes?",
]

# Patterns that indicate tool output containing test content
TOOL_OUTPUT_MARKERS: list[str] = [
    "PASSED",
    "FAILED",
    "AssertionError:",
    "tests/",
    "test_",
    "pytest",
    "fixture",
    "CORRECTIONS =",
    "FIXTURE_",
]


# ---------------------------------------------------------------------------
# Import production filter from ingest module
# ---------------------------------------------------------------------------

from agentmemory.ingest import looks_like_test_file_content as _looks_like_test_file_content
from agentmemory.ingest import looks_like_test_output as _looks_like_test_output


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestFixtureDetection:
    """Synthetic test fixture strings should be detected."""

    def test_correction_fixture_in_pytest_output(self) -> None:
        text = (
            'FAILED tests/test_correction.py::test_negation - '
            'AssertionError: Expected CORRECTION for: '
            '"No, we already decided not to use PostgreSQL"'
        )
        assert _looks_like_test_output(text)

    def test_passing_test_output(self) -> None:
        text = "tests/test_store.py::test_insert_belief PASSED"
        assert _looks_like_test_output(text)

    def test_fixture_assignment_block(self) -> None:
        text = (
            'FIXTURE_CORRECTIONS = [\n'
            '    "No, use SQLite not PostgreSQL",\n'
            '    "Don\'t do that, always run tests",\n'
            ']'
        )
        assert _looks_like_test_file_content(text)

    def test_test_function_definition(self) -> None:
        text = (
            "def test_correction_detection():\n"
            '    assert classify("No, use X not Y") == "correction"'
        )
        assert _looks_like_test_file_content(text)


class TestRealContentPassthrough:
    """Real conversation content should NOT be filtered."""

    @pytest.mark.parametrize("text", REAL_CONTENT)
    def test_real_content_not_flagged_as_test_output(self, text: str) -> None:
        assert not _looks_like_test_output(text)

    @pytest.mark.parametrize("text", REAL_CONTENT)
    def test_real_content_not_flagged_as_test_file(self, text: str) -> None:
        assert not _looks_like_test_file_content(text)

    def test_user_mentioning_tests_not_flagged(self) -> None:
        text = "Can you run the test suite and check if it passes?"
        assert not _looks_like_test_output(text)


class TestEdgeCases:
    """Boundary conditions."""

    def test_empty_string(self) -> None:
        assert not _looks_like_test_output("")
        assert not _looks_like_test_file_content("")

    def test_single_marker_insufficient(self) -> None:
        text = "The tests/ directory has 100 files"
        assert not _looks_like_test_output(text)

    def test_mixed_real_and_test_content(self) -> None:
        """If a turn contains pytest output mixed with discussion, flag it."""
        text = (
            "Here are the results:\n"
            "tests/test_store.py::test_insert PASSED\n"
            "tests/test_store.py::test_delete FAILED\n"
        )
        assert _looks_like_test_output(text)
