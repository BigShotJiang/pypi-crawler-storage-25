"""Tests for multi-metric voting relationship detector."""

from __future__ import annotations

from collections.abc import Generator
from pathlib import Path

import pytest

from agentmemory.relationship_detector import (
    RelationshipResult,
    detect_relationships_multimetric,
)
from agentmemory.store import MemoryStore


@pytest.fixture()
def store(tmp_path: Path) -> Generator[MemoryStore, None, None]:
    s: MemoryStore = MemoryStore(tmp_path / "test.db")
    yield s
    s.close()


def _insert(store: MemoryStore, content: str, belief_type: str = "factual") -> str:
    """Insert a belief and return its ID."""
    return store.insert_belief(
        content=content,
        belief_type=belief_type,
        source_type="agent_inferred",
    ).id


class TestMultimetricVoting:
    """Tests for detect_relationships_multimetric()."""

    def test_creates_edge_when_two_metrics_pass(self, store: MemoryStore) -> None:
        """Edge created when >= 2 of 5 metrics exceed thresholds."""
        # These share enough terms to pass multiple metrics
        _insert(store, "The Bayesian confidence scoring system updates alpha and beta")
        belief = store.insert_belief(
            content="Bayesian scoring updates the alpha parameter based on confidence",
            belief_type="factual",
            source_type="agent_inferred",
        )

        result: RelationshipResult = detect_relationships_multimetric(store, belief)

        assert result.edges_created >= 1
        assert result.checked is True

    def test_no_edge_when_below_two_votes(self, store: MemoryStore) -> None:
        """No edge created when < 2 metrics pass."""
        _insert(store, "The graph topology uses spectral analysis for communities")
        belief = store.insert_belief(
            content="Python package management with uv is fast and reliable",
            belief_type="factual",
            source_type="agent_inferred",
        )

        result = detect_relationships_multimetric(store, belief)

        assert result.edges_created == 0

    def test_max_three_edges_per_belief(self, store: MemoryStore) -> None:
        """Respects _MAX_EDGES_PER_BELIEF = 3."""
        # Create many similar beliefs
        for i in range(10):
            _insert(
                store,
                f"Thompson sampling explores edge {i} with beta distribution variance",
            )

        belief = store.insert_belief(
            content="Thompson sampling explores edges using beta distribution variance",
            belief_type="factual",
            source_type="agent_inferred",
        )

        result = detect_relationships_multimetric(store, belief)

        assert result.edges_created <= 3

    def test_skips_short_beliefs(self, store: MemoryStore) -> None:
        """Beliefs with < 3 terms are skipped."""
        _insert(store, "yes")
        belief = store.insert_belief(
            content="ok",
            belief_type="factual",
            source_type="agent_inferred",
        )

        result = detect_relationships_multimetric(store, belief)

        assert result.edges_created == 0
        assert "too short" in result.details[0]

    def test_skips_locked_candidates(self, store: MemoryStore) -> None:
        """Locked beliefs are not linked as candidates."""
        locked_id = _insert(
            store, "The retrieval architecture uses FTS5 for keyword search"
        )
        store.query("UPDATE beliefs SET locked = 1 WHERE id = ?", (locked_id,))

        belief = store.insert_belief(
            content="FTS5 keyword search powers the retrieval architecture",
            belief_type="factual",
            source_type="agent_inferred",
        )

        detect_relationships_multimetric(store, belief)

        # Should not create edge TO locked belief
        edges_to_locked = store.query(
            "SELECT * FROM edges WHERE to_id = ? AND edge_type != 'TEMPORAL_NEXT'",
            (locked_id,),
        )
        assert len(edges_to_locked) == 0

    def test_idempotent(self, store: MemoryStore) -> None:
        """Running twice does not create duplicate edges."""
        _insert(store, "Temporal backbone connects beliefs in chronological order")
        belief = store.insert_belief(
            content="Beliefs connected chronologically via temporal backbone edges",
            belief_type="factual",
            source_type="agent_inferred",
        )

        first = detect_relationships_multimetric(store, belief)
        second = detect_relationships_multimetric(store, belief)

        assert first.edges_created >= 1
        assert second.edges_created == 0

    def test_detects_contradictions(self, store: MemoryStore) -> None:
        """Negation divergence produces CONTRADICTS edges."""
        _insert(store, "The graph edges are never pruned in production")
        belief = store.insert_belief(
            content="The graph edges are always pruned in production regularly",
            belief_type="factual",
            source_type="agent_inferred",
        )

        result = detect_relationships_multimetric(store, belief)

        # The function should run without error regardless of contradiction detection
        assert result.checked is True

    def test_edge_metadata_correct(self, store: MemoryStore) -> None:
        """Created edges have correct weight and reason format."""
        _insert(store, "Multi-metric voting uses five similarity metrics for edges")
        belief = store.insert_belief(
            content="Five similarity metrics determine edge creation via voting",
            belief_type="factual",
            source_type="agent_inferred",
        )

        detect_relationships_multimetric(store, belief)

        edges = store.query(
            "SELECT weight, reason, edge_type FROM edges WHERE from_id = ? "
            "AND edge_type != 'TEMPORAL_NEXT'",
            (belief.id,),
        )
        if edges:
            edge = edges[0]
            assert edge["weight"] > 0.0
            assert "multimetric" in edge["reason"]
            assert "votes" in edge["reason"]
            assert edge["edge_type"] in ("RELATES_TO", "SUPPORTS", "CONTRADICTS")
