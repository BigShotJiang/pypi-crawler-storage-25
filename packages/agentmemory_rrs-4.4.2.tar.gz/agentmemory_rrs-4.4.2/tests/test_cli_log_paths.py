"""Tests for Claude/Codex conversation log path resolution."""

from __future__ import annotations

from pathlib import Path

import pytest


def test_conversation_log_dirs_include_claude_and_codex(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory.cli import _conversation_log_dirs  # pyright: ignore[reportPrivateUsage]

    def _fake_home() -> Path:
        return tmp_path

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("pathlib.Path.home", _fake_home)

    dirs: list[Path] = _conversation_log_dirs()
    assert tmp_path / ".claude" / "conversation-logs" in dirs
    assert tmp_path / ".codex" / "conversation-logs" in dirs


def test_default_turns_log_path_prefers_existing_codex_log(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory.cli import _default_turns_log_path  # pyright: ignore[reportPrivateUsage]

    def _fake_home() -> Path:
        return tmp_path

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("pathlib.Path.home", _fake_home)

    codex_turns: Path = tmp_path / ".codex" / "conversation-logs" / "turns.jsonl"
    codex_turns.parent.mkdir(parents=True, exist_ok=True)
    codex_turns.write_text('{"event":"user","text":"hi"}\n', encoding="utf-8")

    resolved: Path = _default_turns_log_path()
    assert resolved == codex_turns


def test_default_turns_log_path_falls_back_to_claude_when_none_exist(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory.cli import _default_turns_log_path  # pyright: ignore[reportPrivateUsage]

    def _fake_home() -> Path:
        return tmp_path

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("pathlib.Path.home", _fake_home)

    resolved: Path = _default_turns_log_path()
    assert resolved == tmp_path / ".claude" / "conversation-logs" / "turns.jsonl"
