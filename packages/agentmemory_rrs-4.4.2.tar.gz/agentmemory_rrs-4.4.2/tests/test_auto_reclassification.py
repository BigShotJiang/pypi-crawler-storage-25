"""Tests for automatic belief reclassification on evidence change.

When a belief's confidence drops below threshold or a CONTRADICTS edge
is created, the belief should be flagged for reclassification.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from agentmemory.models import Belief
from agentmemory.store import MemoryStore


@pytest.fixture()
def store(tmp_path: Path) -> MemoryStore:
    s: MemoryStore = MemoryStore(tmp_path / "test_reclass.db")
    s.create_session()
    return s


class TestReclassificationFlag:
    """Beliefs get flagged when evidence undermines them."""

    def test_confidence_drop_flags_belief(self, store: MemoryStore) -> None:
        """Belief flagged when confidence drops below 0.5."""
        belief: Belief = store.insert_belief(
            content="The project uses PostgreSQL for storage.",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=3.0,
            beta_param=1.0,  # confidence = 0.75
        )

        # Simulate negative evidence driving confidence below 0.5
        store.update_confidence(belief.id, outcome="harmful", weight=4.0)

        flagged: list[str] = store.get_beliefs_needing_reclassification()
        assert belief.id in flagged

    def test_high_confidence_not_flagged(self, store: MemoryStore) -> None:
        """Belief NOT flagged when confidence stays high."""
        belief: Belief = store.insert_belief(
            content="Always use uv for Python package management.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,  # confidence = 0.947
        )

        # Mild negative evidence, still above 0.5
        store.update_confidence(belief.id, outcome="harmful", weight=1.0)

        flagged = store.get_beliefs_needing_reclassification()
        assert belief.id not in flagged

    def test_contradiction_edge_flags_belief(self, store: MemoryStore) -> None:
        """Belief flagged when CONTRADICTS edge is created against it."""
        old: Belief = store.insert_belief(
            content="The API uses REST for all communication.",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=5.0,
            beta_param=1.0,
        )
        new: Belief = store.insert_belief(
            content="The API uses GraphQL, not REST.",
            belief_type="factual",
            source_type="user_corrected",
            alpha=5.0,
            beta_param=1.0,
        )

        store.insert_edge(
            from_id=new.id,
            to_id=old.id,
            edge_type="CONTRADICTS",
        )
        store.flag_for_reclassification(old.id, reason="contradiction")

        flagged = store.get_beliefs_needing_reclassification()
        assert old.id in flagged

    def test_flagged_belief_cleared_after_processing(
        self, store: MemoryStore
    ) -> None:
        """Flag is cleared after reclassification is processed."""
        belief: Belief = store.insert_belief(
            content="The database schema uses version 3.",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=2.0,
            beta_param=3.0,  # confidence = 0.4, below threshold
        )
        store.flag_for_reclassification(belief.id, reason="low_confidence")

        flagged = store.get_beliefs_needing_reclassification()
        assert belief.id in flagged

        store.clear_reclassification_flag(belief.id)

        flagged_after = store.get_beliefs_needing_reclassification()
        assert belief.id not in flagged_after

    def test_locked_beliefs_not_flagged(self, store: MemoryStore) -> None:
        """Locked beliefs should not be flagged for reclassification."""
        belief: Belief = store.insert_belief(
            content="Never push to github directly.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )

        # Even with contradiction edge, locked beliefs keep their type
        store.flag_for_reclassification(belief.id, reason="contradiction")

        flagged = store.get_beliefs_needing_reclassification()
        assert belief.id not in flagged
