# pyright: reportPrivateUsage=false, reportUnknownMemberType=false
"""Tests for Setr confidence-attenuated valence propagation (Gap 7).

Hypothesis: Low-confidence intermediary nodes should attenuate valence propagation
proportionally to their confidence. A 0.2-confidence broker should pass ~22% of
the signal a 0.9-confidence broker would pass.

TDD: these tests are written BEFORE the implementation. They must fail on current
code and pass after the Setr fix is applied to propagate_valence in store.py.

Cosmology ref: Setr/Garsecg -- a low-confidence node that accumulated structural
edges it was never entitled to. The fix: confidence-attenuated propagation.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from agentmemory.models import (
    BELIEF_FACTUAL,
    BSRC_AGENT_INFERRED,
    EDGE_SUPPORTS,
)
from agentmemory.store import MemoryStore


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_store(tmp_path: Path, name: str = "setr.db") -> MemoryStore:
    return MemoryStore(tmp_path / name)


def set_confidence(store: MemoryStore, belief_id: str, conf: float) -> None:
    """Force a belief to a specific confidence via direct alpha/beta manipulation."""
    # alpha/(alpha+beta) = conf  =>  alpha = conf, beta = 1-conf (at sum=1)
    # Use sum=10 to make the belief reasonably stable
    alpha = conf * 10.0
    beta = (1.0 - conf) * 10.0
    store._conn.execute(
        "UPDATE beliefs SET alpha = ?, beta_param = ?, updated_at = datetime('now') WHERE id = ?",
        (alpha, beta, belief_id),
    )
    store._conn.commit()


def get_alpha_beta(store: MemoryStore, belief_id: str) -> tuple[float, float]:
    row = store._conn.execute(
        "SELECT alpha, beta_param FROM beliefs WHERE id = ?", (belief_id,)
    ).fetchone()
    assert row is not None
    return float(row["alpha"]), float(row["beta_param"])


# ---------------------------------------------------------------------------
# Test 1: Low-confidence broker attenuates propagation
#
# Chain: seed -SUPPORTS-> broker(low) -SUPPORTS-> target
# Prediction: target receives less alpha boost through low-confidence broker
# than through a high-confidence broker with everything else equal.
# ---------------------------------------------------------------------------


def test_setr_low_conf_broker_attenuates(tmp_path: Path) -> None:
    """Low-confidence broker should attenuate propagation proportionally.

    This test will FAIL before the Setr fix is applied.
    After fix: target alpha boost through broker(0.2) < boost through broker(0.9).
    """
    store = make_store(tmp_path, "setr_attenuation.db")

    # Build chain: seed -> broker_low -> target_low
    seed = store.insert_belief("seed belief", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    broker_low = store.insert_belief("low confidence broker", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    target_low = store.insert_belief("target via low broker", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)

    set_confidence(store, seed.id, 0.9)
    set_confidence(store, broker_low.id, 0.2)
    set_confidence(store, target_low.id, 0.7)

    store.insert_edge(seed.id, broker_low.id, EDGE_SUPPORTS)
    store.insert_edge(broker_low.id, target_low.id, EDGE_SUPPORTS)

    alpha_before, _ = get_alpha_beta(store, target_low.id)
    store.propagate_valence(seed.id, valence=1.0)
    alpha_after_low, _ = get_alpha_beta(store, target_low.id)
    delta_low = alpha_after_low - alpha_before

    # Build parallel chain: seed2 -> broker_high -> target_high
    store2 = make_store(tmp_path, "setr_attenuation_high.db")
    seed2 = store2.insert_belief("seed belief", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    broker_high = store2.insert_belief("high confidence broker", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    target_high = store2.insert_belief("target via high broker", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)

    set_confidence(store2, seed2.id, 0.9)
    set_confidence(store2, broker_high.id, 0.9)
    set_confidence(store2, target_high.id, 0.7)

    store2.insert_edge(seed2.id, broker_high.id, EDGE_SUPPORTS)
    store2.insert_edge(broker_high.id, target_high.id, EDGE_SUPPORTS)

    alpha_before2, _ = get_alpha_beta(store2, target_high.id)
    store2.propagate_valence(seed2.id, valence=1.0)
    alpha_after_high, _ = get_alpha_beta(store2, target_high.id)
    delta_high = alpha_after_high - alpha_before2

    store.close()
    store2.close()

    # After fix: low-conf broker produces much less delta than high-conf broker
    # The ratio should be approximately broker_low_conf / broker_high_conf = 0.2/0.9 ~ 0.22
    # We just assert that low < high with meaningful margin (not just floating point)
    assert delta_low < delta_high, (
        f"Low-confidence broker should attenuate propagation. "
        f"delta_low={delta_low:.6f}, delta_high={delta_high:.6f}. "
        f"This test should FAIL before the Setr fix is applied."
    )
    # The ratio should be within a factor of 2 of the expected 0.22
    if delta_high > 0:
        ratio = delta_low / delta_high
        assert ratio < 0.5, (
            f"Attenuation ratio should be ~0.22, got {ratio:.3f}. "
            f"Low-conf broker is not attenuating enough."
        )


# ---------------------------------------------------------------------------
# Test 2: High-confidence broker passes signal through normally
#
# Sanity check: a 0.95-confidence broker should pass nearly full signal.
# delta through broker(0.95) ~= 0.95 * delta through broker(1.0)
# ---------------------------------------------------------------------------


def test_setr_high_conf_broker_passes_normally(tmp_path: Path) -> None:
    """High-confidence broker should pass signal with minimal attenuation.

    After fix: delta through broker(0.95) is close to unattenuated (within 10%).
    """
    store = make_store(tmp_path, "setr_high.db")

    seed = store.insert_belief("seed", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    broker = store.insert_belief("high-conf broker", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    target = store.insert_belief("target", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)

    set_confidence(store, seed.id, 0.9)
    set_confidence(store, broker.id, 0.95)
    set_confidence(store, target.id, 0.7)

    store.insert_edge(seed.id, broker.id, EDGE_SUPPORTS)
    store.insert_edge(broker.id, target.id, EDGE_SUPPORTS)

    alpha_before, _ = get_alpha_beta(store, target.id)
    store.propagate_valence(seed.id, valence=1.0)
    alpha_after, _ = get_alpha_beta(store, target.id)
    delta = alpha_after - alpha_before

    store.close()

    # After fix: delta should be positive (signal got through)
    assert delta > 0, "High-confidence broker should still propagate positive valence"
    # And it should be at least 80% of what a perfect broker would pass
    # Perfect broker passes: valence * decay * EDGE_SUPPORTS_multiplier * seed_conf * broker_conf
    # We just assert it's meaningful (> 0.05 which is min_threshold)
    assert delta > 0.05, f"High-confidence broker passed insufficient signal: delta={delta:.6f}"


# ---------------------------------------------------------------------------
# Test 3: Attenuation is proportional to broker confidence
#
# ratio of deltas through two brokers should approximate ratio of their confidences.
# broker_low=0.3, broker_high=0.9: expected ratio ~= 0.3/0.9 = 0.333
# ---------------------------------------------------------------------------


def test_setr_attenuation_proportional_to_confidence(tmp_path: Path) -> None:
    """Delta ratio through two brokers should approximate their confidence ratio.

    This test will FAIL before the Setr fix is applied (current code produces ratio ~1.0).
    After fix: ratio should be approximately broker_low_conf / broker_high_conf.
    """
    BROKER_LOW_CONF = 0.3
    BROKER_HIGH_CONF = 0.9
    EXPECTED_RATIO = BROKER_LOW_CONF / BROKER_HIGH_CONF  # ~0.333

    # Path 1: through low broker
    store_low = make_store(tmp_path, "ratio_low.db")
    seed_l = store_low.insert_belief("seed", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    broker_l = store_low.insert_belief("broker", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    target_l = store_low.insert_belief("target", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    set_confidence(store_low, seed_l.id, 0.9)
    set_confidence(store_low, broker_l.id, BROKER_LOW_CONF)
    set_confidence(store_low, target_l.id, 0.7)
    store_low.insert_edge(seed_l.id, broker_l.id, EDGE_SUPPORTS)
    store_low.insert_edge(broker_l.id, target_l.id, EDGE_SUPPORTS)
    a_before_l, _ = get_alpha_beta(store_low, target_l.id)
    store_low.propagate_valence(seed_l.id, valence=1.0)
    a_after_l, _ = get_alpha_beta(store_low, target_l.id)
    delta_low = a_after_l - a_before_l
    store_low.close()

    # Path 2: through high broker
    store_high = make_store(tmp_path, "ratio_high.db")
    seed_h = store_high.insert_belief("seed", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    broker_h = store_high.insert_belief("broker", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    target_h = store_high.insert_belief("target", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    set_confidence(store_high, seed_h.id, 0.9)
    set_confidence(store_high, broker_h.id, BROKER_HIGH_CONF)
    set_confidence(store_high, target_h.id, 0.7)
    store_high.insert_edge(seed_h.id, broker_h.id, EDGE_SUPPORTS)
    store_high.insert_edge(broker_h.id, target_h.id, EDGE_SUPPORTS)
    a_before_h, _ = get_alpha_beta(store_high, target_h.id)
    store_high.propagate_valence(seed_h.id, valence=1.0)
    a_after_h, _ = get_alpha_beta(store_high, target_h.id)
    delta_high = a_after_h - a_before_h
    store_high.close()

    assert delta_high > 0, "High broker should propagate"

    if delta_low == 0.0 and delta_high > 0:
        # Signal was completely killed by low broker -- means min_threshold was hit.
        # This is valid: 0.3 * 0.5 * multiplier may fall below 0.05.
        # Accept this as a pass (more aggressive attenuation than expected is fine).
        return

    actual_ratio = delta_low / delta_high
    # Allow 40% tolerance around expected ratio (graph topology introduces variance)
    assert abs(actual_ratio - EXPECTED_RATIO) < 0.4, (
        f"Expected delta ratio ~{EXPECTED_RATIO:.3f} (= {BROKER_LOW_CONF}/{BROKER_HIGH_CONF}), "
        f"got {actual_ratio:.3f}. Before fix this will be ~1.0."
    )


# ---------------------------------------------------------------------------
# Test 4: Min-threshold still terminates propagation
#
# Attenuation must not break the min_threshold termination. If attenuation
# drives the signal below min_threshold, propagation stops (correct behavior).
# ---------------------------------------------------------------------------


def test_setr_min_threshold_still_applies(tmp_path: Path) -> None:
    """Confidence attenuation + decay may drop below min_threshold: that's correct.

    A very low confidence broker (0.05) + standard decay may kill the signal.
    The min_threshold guard must still work -- no infinite loops, no negative updates.
    """
    store = make_store(tmp_path, "setr_threshold.db")

    seed = store.insert_belief("seed", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    broker = store.insert_belief("near-zero broker", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)
    target = store.insert_belief("target", BELIEF_FACTUAL, BSRC_AGENT_INFERRED)

    set_confidence(store, seed.id, 0.9)
    set_confidence(store, broker.id, 0.05)  # Near-zero confidence broker
    set_confidence(store, target.id, 0.7)

    store.insert_edge(seed.id, broker.id, EDGE_SUPPORTS)
    store.insert_edge(broker.id, target.id, EDGE_SUPPORTS)

    alpha_before, beta_before = get_alpha_beta(store, target.id)
    # Must not hang or throw
    updated = store.propagate_valence(seed.id, valence=1.0)
    alpha_after, beta_after = get_alpha_beta(store, target.id)

    store.close()

    # Either signal was killed (target unchanged) or passed through at tiny level
    # Either is correct. The important thing: no exception, deterministic result.
    assert alpha_after >= alpha_before, "Alpha must not decrease from positive valence"
    assert beta_after == pytest.approx(beta_before), "Beta must not change from positive valence"
    # updated count may be 0 (signal killed by attenuation+threshold) or small positive
    assert isinstance(updated, int)
    assert updated >= 0
