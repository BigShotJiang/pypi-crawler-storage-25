"""Root conftest: test isolation, auto-marking, and shared fixtures.

GH-25: Ensures all tests use isolated temp databases (never production
~/.agentmemory/), applies pytest marks based on directory structure,
and provides common fixtures.
"""

from __future__ import annotations

from collections.abc import Generator
from pathlib import Path

import pytest

from agentmemory.store import MemoryStore


# ---------------------------------------------------------------------------
# GH-25: Force all tests to use isolated temp databases
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolate_agentmemory_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:  # pyright: ignore[reportUnusedFunction]
    """Redirect AGENTMEMORY_DB to a temp directory for every test.

    This prevents tests from reading or writing to the production
    ~/.agentmemory/ directory. The env var is checked by both the MCP
    server (_resolve_server_db) and the SessionStart hook.
    """
    test_db: Path = tmp_path / "agentmemory_test.db"
    monkeypatch.setenv("AGENTMEMORY_DB", str(test_db))


# ---------------------------------------------------------------------------
# GH-25: Auto-apply marks based on test directory
# ---------------------------------------------------------------------------

def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Auto-apply marks based on test file location.

    - tests/acceptance/ -> integration (they use SQLite)
    - tests/integration/ -> integration
    - tests/validation/ -> e2e
    - tests/ (root level) -> integration (most use SQLite via store fixture)

    Individual tests can override with explicit @pytest.mark decorators.
    """
    for item in items:
        # Skip items that already have a category mark
        existing: set[str] = {m.name for m in item.iter_markers()}
        if existing & {"unit", "integration", "e2e", "benchmark"}:
            continue

        rel_path: str = str(item.fspath)
        if "/acceptance/" in rel_path:
            item.add_marker(pytest.mark.integration)
        elif "/integration/" in rel_path:
            item.add_marker(pytest.mark.integration)
        elif "/validation/" in rel_path:
            item.add_marker(pytest.mark.e2e)
        elif "/benchmarks/" in rel_path:
            item.add_marker(pytest.mark.benchmark)
        else:
            # Root-level tests: default to integration (most use SQLite)
            item.add_marker(pytest.mark.integration)


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def store(tmp_path: Path) -> Generator[MemoryStore, None, None]:
    """Fresh MemoryStore backed by a temp database. Closed after test."""
    s: MemoryStore = MemoryStore(tmp_path / "test.db")
    yield s
    s.close()
