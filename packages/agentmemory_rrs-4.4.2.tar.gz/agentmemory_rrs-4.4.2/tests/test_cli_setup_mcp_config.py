"""Tests for setup MCP config create/merge behavior (GH-51)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

import pytest


def _read_json(path: Path) -> dict[str, Any]:
    return cast(dict[str, Any], json.loads(path.read_text(encoding="utf-8")))


def test_ensure_project_mcp_config_creates_file_when_missing(tmp_path: Path) -> None:
    from agentmemory.cli import _ensure_project_mcp_config  # pyright: ignore[reportPrivateUsage]

    mcp_path: Path = tmp_path / ".mcp.json"
    _ensure_project_mcp_config(mcp_json_path=mcp_path, am_project_dir="/tmp/am")

    data: dict[str, Any] = _read_json(mcp_path)
    assert "mcpServers" in data
    servers: dict[str, Any] = cast(dict[str, Any], data["mcpServers"])
    assert "agentmemory" in servers
    agent_cfg: dict[str, Any] = cast(dict[str, Any], servers["agentmemory"])
    assert agent_cfg["command"] == "uv"
    assert agent_cfg["args"][2] == "/tmp/am"


def test_ensure_project_mcp_config_merges_into_existing_file(tmp_path: Path) -> None:
    from agentmemory.cli import _ensure_project_mcp_config  # pyright: ignore[reportPrivateUsage]

    mcp_path: Path = tmp_path / ".mcp.json"
    existing: dict[str, Any] = {
        "mcpServers": {
            "other": {
                "type": "stdio",
                "command": "node",
                "args": ["server.js"],
                "env": {},
            }
        }
    }
    mcp_path.write_text(json.dumps(existing), encoding="utf-8")

    _ensure_project_mcp_config(mcp_json_path=mcp_path, am_project_dir="/tmp/am")

    data: dict[str, Any] = _read_json(mcp_path)
    servers: dict[str, Any] = cast(dict[str, Any], data["mcpServers"])
    assert "other" in servers
    assert "agentmemory" in servers


def test_ensure_project_mcp_config_repairs_non_dict_mcpservers(tmp_path: Path) -> None:
    from agentmemory.cli import _ensure_project_mcp_config  # pyright: ignore[reportPrivateUsage]

    mcp_path: Path = tmp_path / ".mcp.json"
    mcp_path.write_text(json.dumps({"mcpServers": []}), encoding="utf-8")

    _ensure_project_mcp_config(mcp_json_path=mcp_path, am_project_dir="/tmp/am")

    data: dict[str, Any] = _read_json(mcp_path)
    servers: Any = data.get("mcpServers")
    assert isinstance(servers, dict)
    assert "agentmemory" in servers


def test_ensure_project_mcp_config_warns_and_skips_invalid_json(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    from agentmemory.cli import _ensure_project_mcp_config  # pyright: ignore[reportPrivateUsage]

    mcp_path: Path = tmp_path / ".mcp.json"
    mcp_path.write_text("{invalid", encoding="utf-8")

    _ensure_project_mcp_config(mcp_json_path=mcp_path, am_project_dir="/tmp/am")

    err: str = capsys.readouterr().err
    assert "could not parse" in err
    assert "re-run `agentmemory setup`" in err
