"""Tests for branch-scope pre-push hook installation."""

# pyright: reportPrivateUsage=false

from __future__ import annotations

from pathlib import Path
import subprocess

import pytest


def test_install_branch_scope_pre_push_hook_writes_managed_block(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory.cli import (  # pyright: ignore[reportPrivateUsage]
        _install_branch_scope_pre_push_hook,
    )

    def _fake_hooks_dir(_p: Path) -> Path:
        return hooks_dir

    repo: Path = tmp_path / "repo"
    scripts_dir: Path = repo / "scripts"
    hooks_dir: Path = repo / ".git" / "hooks"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    hooks_dir.mkdir(parents=True, exist_ok=True)

    script_path: Path = scripts_dir / "pre-push-branch-scope.sh"
    script_path.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    script_path.chmod(0o755)

    monkeypatch.chdir(repo)
    monkeypatch.setattr("agentmemory.cli._resolve_git_hooks_dir", _fake_hooks_dir)

    _install_branch_scope_pre_push_hook()  # pyright: ignore[reportPrivateUsage]

    pre_push: Path = hooks_dir / "pre-push"
    assert pre_push.exists()
    text: str = pre_push.read_text(encoding="utf-8")
    assert "AGENTMEMORY MANAGED BLOCK: BRANCH SCOPE PRE-PUSH" in text
    assert str(script_path) in text
    assert text.startswith("#!/usr/bin/env bash")


def test_install_branch_scope_pre_push_hook_idempotent(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory.cli import (  # pyright: ignore[reportPrivateUsage]
        _install_branch_scope_pre_push_hook,
    )

    def _fake_hooks_dir(_p: Path) -> Path:
        return hooks_dir

    repo: Path = tmp_path / "repo"
    scripts_dir: Path = repo / "scripts"
    hooks_dir: Path = repo / ".git" / "hooks"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    hooks_dir.mkdir(parents=True, exist_ok=True)

    script_path: Path = scripts_dir / "pre-push-branch-scope.sh"
    script_path.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    script_path.chmod(0o755)

    monkeypatch.chdir(repo)
    monkeypatch.setattr("agentmemory.cli._resolve_git_hooks_dir", _fake_hooks_dir)

    _install_branch_scope_pre_push_hook()  # pyright: ignore[reportPrivateUsage]
    _install_branch_scope_pre_push_hook()  # pyright: ignore[reportPrivateUsage]

    text: str = (hooks_dir / "pre-push").read_text(encoding="utf-8")
    marker: str = "AGENTMEMORY MANAGED BLOCK: BRANCH SCOPE PRE-PUSH"
    assert text.count(marker) == 2  # begin + end only once each


def test_install_issue_scope_commit_msg_hook_writes_managed_block(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory.cli import (  # pyright: ignore[reportPrivateUsage]
        _install_issue_scope_commit_msg_hook,
    )

    def _fake_hooks_dir(_p: Path) -> Path:
        return hooks_dir

    repo: Path = tmp_path / "repo"
    scripts_dir: Path = repo / "scripts"
    hooks_dir: Path = repo / ".git" / "hooks"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    hooks_dir.mkdir(parents=True, exist_ok=True)

    script_path: Path = scripts_dir / "commit-msg-issue-scope.sh"
    script_path.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    script_path.chmod(0o755)

    monkeypatch.chdir(repo)
    monkeypatch.setattr("agentmemory.cli._resolve_git_hooks_dir", _fake_hooks_dir)

    _install_issue_scope_commit_msg_hook()  # pyright: ignore[reportPrivateUsage]

    commit_msg: Path = hooks_dir / "commit-msg"
    assert commit_msg.exists()
    text: str = commit_msg.read_text(encoding="utf-8")
    assert "AGENTMEMORY MANAGED BLOCK: ISSUE SCOPE COMMIT-MSG" in text
    assert str(script_path) in text
    assert text.startswith("#!/usr/bin/env bash")


def test_install_issue_scope_commit_msg_hook_idempotent(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentmemory.cli import (  # pyright: ignore[reportPrivateUsage]
        _install_issue_scope_commit_msg_hook,
    )

    def _fake_hooks_dir(_p: Path) -> Path:
        return hooks_dir

    repo: Path = tmp_path / "repo"
    scripts_dir: Path = repo / "scripts"
    hooks_dir: Path = repo / ".git" / "hooks"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    hooks_dir.mkdir(parents=True, exist_ok=True)

    script_path: Path = scripts_dir / "commit-msg-issue-scope.sh"
    script_path.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    script_path.chmod(0o755)

    monkeypatch.chdir(repo)
    monkeypatch.setattr("agentmemory.cli._resolve_git_hooks_dir", _fake_hooks_dir)

    _install_issue_scope_commit_msg_hook()  # pyright: ignore[reportPrivateUsage]
    _install_issue_scope_commit_msg_hook()  # pyright: ignore[reportPrivateUsage]

    text: str = (hooks_dir / "commit-msg").read_text(encoding="utf-8")
    marker: str = "AGENTMEMORY MANAGED BLOCK: ISSUE SCOPE COMMIT-MSG"
    assert text.count(marker) == 2  # begin + end only once each


def _run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=repo,
        check=True,
        text=True,
        capture_output=True,
    )


def _init_repo_with_branch_scope_script(tmp_path: Path) -> tuple[Path, Path]:
    repo: Path = tmp_path / "repo"
    repo.mkdir()
    _run_git(repo, "init")
    _run_git(repo, "config", "user.name", "Test User")
    _run_git(repo, "config", "user.email", "test@example.com")

    script_src: Path = (
        Path(__file__).resolve().parents[1] / "scripts" / "pre-push-branch-scope.sh"
    )
    script_path: Path = repo / "pre-push-branch-scope.sh"
    script_path.write_text(script_src.read_text(encoding="utf-8"), encoding="utf-8")
    script_path.chmod(0o755)

    (repo / "README.md").write_text("seed\n", encoding="utf-8")
    _run_git(repo, "add", "README.md")
    _run_git(repo, "commit", "-m", "chore: seed repo")
    return repo, script_path


def _commit_file(repo: Path, filename: str, contents: str, message: str) -> None:
    (repo / filename).write_text(contents, encoding="utf-8")
    _run_git(repo, "add", filename)
    _run_git(repo, "commit", "-m", message)


def _push_stdin(branch: str, sha: str) -> str:
    return f"refs/heads/{branch} {sha} refs/heads/main 0000000000000000000000000000000000000000\n"


def test_issue_branch_blocks_mixed_issue_history(tmp_path: Path) -> None:
    repo, script_path = _init_repo_with_branch_scope_script(tmp_path)

    _run_git(repo, "switch", "-c", "fix/gh-21-branch-scope")
    _commit_file(
        repo,
        "one.txt",
        "one\n",
        "fix: branch-scope regression guard (GH-21)",
    )
    _commit_file(
        repo,
        "two.txt",
        "two\n",
        "docs: unrelated issue mention (GH-44)",
    )

    head_sha: str = _run_git(repo, "rev-parse", "HEAD").stdout.strip()
    result = subprocess.run(
        [str(script_path)],
        cwd=repo,
        text=True,
        input=_push_stdin("fix/gh-21-branch-scope", head_sha),
        capture_output=True,
    )

    assert result.returncode == 1
    assert "Commit issue mismatch" in result.stdout
    assert "Branch must stay scoped to gh-21" in result.stdout


def test_release_branch_allows_mixed_issue_history(tmp_path: Path) -> None:
    repo, script_path = _init_repo_with_branch_scope_script(tmp_path)

    _run_git(repo, "switch", "-c", "release/gh-71-v4-4-0")
    _commit_file(repo, "one.txt", "one\n", "fix: branch-scope regression guard (GH-21)")
    _commit_file(repo, "two.txt", "two\n", "docs: release notes update (GH-44)")

    head_sha: str = _run_git(repo, "rev-parse", "HEAD").stdout.strip()
    result = subprocess.run(
        [str(script_path)],
        cwd=repo,
        text=True,
        input=_push_stdin("release/gh-71-v4-4-0", head_sha),
        capture_output=True,
    )

    assert result.returncode == 0, result.stdout + result.stderr


def test_commit_msg_hook_appends_branch_issue_when_missing(tmp_path: Path) -> None:
    repo, _script_path = _init_repo_with_branch_scope_script(tmp_path)
    hook_src: Path = (
        Path(__file__).resolve().parents[1] / "scripts" / "commit-msg-issue-scope.sh"
    )
    hook_path: Path = repo / "commit-msg-issue-scope.sh"
    hook_path.write_text(hook_src.read_text(encoding="utf-8"), encoding="utf-8")
    hook_path.chmod(0o755)

    _run_git(repo, "switch", "-c", "fix/gh-75-issue-workflow")
    msg_path: Path = repo / "COMMIT_EDITMSG"
    msg_path.write_text(
        "docs: tighten issue workflow\n\nBody stays intact.\n", encoding="utf-8"
    )

    result = subprocess.run(
        [str(hook_path), str(msg_path)],
        cwd=repo,
        text=True,
        capture_output=True,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    text: str = msg_path.read_text(encoding="utf-8")
    assert text.startswith("docs: tighten issue workflow (GH-75)\n")
    assert "Body stays intact." in text


def test_commit_msg_hook_blocks_conflicting_issue_reference(tmp_path: Path) -> None:
    repo, _script_path = _init_repo_with_branch_scope_script(tmp_path)
    hook_src: Path = (
        Path(__file__).resolve().parents[1] / "scripts" / "commit-msg-issue-scope.sh"
    )
    hook_path: Path = repo / "commit-msg-issue-scope.sh"
    hook_path.write_text(hook_src.read_text(encoding="utf-8"), encoding="utf-8")
    hook_path.chmod(0o755)

    _run_git(repo, "switch", "-c", "fix/gh-75-issue-workflow")
    msg_path: Path = repo / "COMMIT_EDITMSG"
    msg_path.write_text("docs: tighten issue workflow (GH-77)\n", encoding="utf-8")

    result = subprocess.run(
        [str(hook_path), str(msg_path)],
        cwd=repo,
        text=True,
        capture_output=True,
    )

    assert result.returncode == 1
    assert "branch gh-75" in result.stderr
    assert "GH-77" in result.stderr
