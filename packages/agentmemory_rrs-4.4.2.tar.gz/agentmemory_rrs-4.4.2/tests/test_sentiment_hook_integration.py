"""Integration test: sentiment feedback applies to pending beliefs.

Verifies that when a user says "ok good" after a retrieval, the
pending beliefs from the previous turn get a positive valence update.
This is the fix for issue #11 (sentiment reads after pending cleared).
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from agentmemory.store import MemoryStore


@pytest.fixture()
def store(tmp_path: Path) -> MemoryStore:
    s: MemoryStore = MemoryStore(tmp_path / "test_sentiment_hook.db")
    s.create_session()  # FK constraint needs a session
    return s


def test_positive_sentiment_boosts_pending_belief(store: MemoryStore) -> None:
    """'ok good' after retrieval should increase alpha on pending beliefs."""
    from agentmemory.hook_search import search_for_prompt

    # Insert a belief that will be retrieved
    belief = store.insert_belief(
        content="Always use the publish script for GitHub releases.",
        belief_type="requirement",
        source_type="user_stated",
        alpha=5.0,
        beta_param=1.0,
    )
    original_alpha: float = belief.alpha

    db: sqlite3.Connection = store.connection

    # First search: retrieves the belief and creates pending_feedback
    search_for_prompt(db, "push the release to github")

    # Verify pending_feedback was created
    pending = db.execute(
        "SELECT COUNT(*) FROM pending_feedback WHERE belief_id = ?",
        (belief.id,),
    ).fetchone()
    assert pending[0] >= 1, "Belief should be in pending_feedback after retrieval"

    # Second prompt: user says "ok good" -- sentiment should boost pending beliefs
    search_for_prompt(db, "ok good")

    # Check alpha increased
    updated = store.get_belief(belief.id)
    assert updated is not None
    assert updated.alpha > original_alpha, (
        f"Alpha should increase after positive sentiment: "
        f"was {original_alpha}, now {updated.alpha}"
    )


def test_negative_sentiment_weakens_pending_belief(store: MemoryStore) -> None:
    """'no thats wrong' after retrieval should increase beta on pending beliefs."""
    from agentmemory.hook_search import search_for_prompt

    belief = store.insert_belief(
        content="The project uses PostgreSQL for all database operations.",
        belief_type="factual",
        source_type="agent_inferred",
        alpha=5.0,
        beta_param=1.0,
    )
    original_beta: float = belief.beta_param

    db = store.connection

    # First search: retrieves the belief
    search_for_prompt(db, "what database does the project use")

    # Second prompt: user corrects
    search_for_prompt(db, "no thats wrong")

    updated = store.get_belief(belief.id)
    assert updated is not None
    assert updated.beta_param > original_beta, (
        f"Beta should increase after negative sentiment: "
        f"was {original_beta}, now {updated.beta_param}"
    )


def test_neutral_prompt_no_sentiment_change(store: MemoryStore) -> None:
    """A neutral follow-up should not change alpha or beta via sentiment."""
    from agentmemory.hook_search import search_for_prompt

    belief = store.insert_belief(
        content="The API uses REST endpoints for all external communication.",
        belief_type="factual",
        source_type="agent_inferred",
        alpha=5.0,
        beta_param=1.0,
    )

    db = store.connection

    # First search: retrieves the belief
    search_for_prompt(db, "how does the API communicate externally")

    # Record state before neutral prompt
    pre = store.get_belief(belief.id)
    assert pre is not None
    pre_alpha: float = pre.alpha

    # Neutral follow-up (long task content, not sentiment)
    search_for_prompt(db, "can you read the file at src/api/routes.py and show me the endpoint definitions")

    post = store.get_belief(belief.id)
    assert post is not None
    # Sentiment should not have changed alpha/beta. Term-overlap feedback
    # from _process_pending_feedback may add up to 0.3 per used match,
    # but sentiment valence (0.3 * valence * confidence) would add more.
    # A neutral message produces zero sentiment change, so any alpha
    # movement is purely from term-overlap (capped at 0.3 per belief).
    alpha_delta: float = abs(post.alpha - pre_alpha)
    assert alpha_delta < 0.7, (
        f"Alpha changed by {alpha_delta} -- too large for term-overlap alone, "
        "suggests sentiment fired on a neutral message"
    )
