# pyright: reportPrivateUsage=false, reportUnknownMemberType=false
"""Tests for LOCK_FREEZE tier (Exp 110 three-tier immutability model).

Hypothesis: Adding LOCK_FREEZE as a named tier with same behavior as current
LOCK_USER gives semantic clarity for "high inertia, evidence-changeable" beliefs
without breaking any existing behavior.

TDD: written BEFORE implementation. Tests for LOCK_FREEZE will fail until the
constant is added to models.py and the store handles "freeze" level.

Cosmology ref: The freeze tier sits between LOCK_NONE (full Bayesian) and a future
LOCK_HARD (truly immutable). It maps to the "high-inertia" beliefs that resist
casual noise but yield to accumulated evidence -- like Overcyns in Skai who are
powerful but not immortal. Giants of Winter (concept drift) can still reach them.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from agentmemory.models import (
    BELIEF_FACTUAL,
    BSRC_USER_STATED,
)
from agentmemory.store import MemoryStore


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_store(tmp_path: Path, name: str = "freeze.db") -> MemoryStore:
    return MemoryStore(tmp_path / name)


def get_belief_state(store: MemoryStore, belief_id: str) -> dict[str, object]:
    row = store._conn.execute(
        "SELECT alpha, beta_param, locked, lock_level FROM beliefs WHERE id = ?",
        (belief_id,),
    ).fetchone()
    assert row is not None
    return {
        "alpha": float(row["alpha"]),
        "beta": float(row["beta_param"]),
        "locked": bool(row["locked"]),
        "lock_level": str(row["lock_level"]),
    }


# ---------------------------------------------------------------------------
# Test 1: LOCK_FREEZE constant exists in models
#
# Fails before: ImportError -- LOCK_FREEZE not defined yet
# Passes after: constant exists with value "freeze"
# ---------------------------------------------------------------------------


def test_lock_freeze_constant_exists() -> None:
    """LOCK_FREEZE must be importable from agentmemory.models with value 'freeze'."""
    from agentmemory.models import LOCK_FREEZE  # type: ignore[attr-defined]
    assert LOCK_FREEZE == "freeze", f"Expected 'freeze', got {LOCK_FREEZE!r}"


# ---------------------------------------------------------------------------
# Test 2: Belief can be created with lock_level='freeze'
#
# Fails before: store does not recognize 'freeze' level
# Passes after: belief has locked=True, lock_level='freeze'
# ---------------------------------------------------------------------------


def test_freeze_belief_can_be_created(tmp_path: Path) -> None:
    """A belief created with lock_level='freeze' should be locked with freeze level."""
    store = make_store(tmp_path)

    b = store.insert_belief(
        "This is a frozen belief",
        BELIEF_FACTUAL,
        BSRC_USER_STATED,
        locked=True,
        lock_level="freeze",
    )
    state = get_belief_state(store, b.id)
    store.close()

    assert state["locked"] is True, "freeze belief must have locked=True"
    assert state["lock_level"] == "freeze", (
        f"Expected lock_level='freeze', got {state['lock_level']!r}"
    )


# ---------------------------------------------------------------------------
# Test 3: Freeze-level belief resists weak negative evidence
#
# Same behavior as current user-locked: weak evidence below threshold is blocked.
# Fails before: freeze level not handled in update_confidence
# Passes after: beta unchanged for weak signal
# ---------------------------------------------------------------------------


def test_freeze_resists_weak_negative_evidence(tmp_path: Path) -> None:
    """Freeze belief should block weak negative valence (below LOCKED_EVIDENCE_THRESHOLD).

    LOCKED_EVIDENCE_THRESHOLD = 3.0. Signal = abs(valence) * weight.
    A valence=-0.5 at default weight=1.0 gives signal=0.5 < 3.0 -> blocked.
    """
    store = make_store(tmp_path, "freeze_weak.db")

    b = store.insert_belief(
        "freeze-level belief",
        BELIEF_FACTUAL,
        BSRC_USER_STATED,
        alpha=9.0,
        beta_param=0.5,
        locked=True,
        lock_level="freeze",
    )

    store.update_confidence(b.id, "harmful", valence=-0.5)
    state = get_belief_state(store, b.id)
    store.close()

    assert state["beta"] == pytest.approx(0.5), (  # type: ignore[reportUnknownMemberType]
        f"Freeze belief should block weak evidence. beta changed to {state['beta']:.4f}"
    )


# ---------------------------------------------------------------------------
# Test 4: Freeze-level belief yields to strong evidence
#
# The whole point of freeze vs hard-lock: evidence CAN change it.
# Fails before: freeze level not handled in update_confidence
# Passes after: beta increases when signal >= LOCKED_EVIDENCE_THRESHOLD
# ---------------------------------------------------------------------------


def test_freeze_yields_to_strong_evidence(tmp_path: Path) -> None:
    """Freeze belief should accept negative valence that exceeds LOCKED_EVIDENCE_THRESHOLD.

    Signal = abs(valence) * weight >= 3.0 should update beta.
    valence=-5.0, weight=1.0 -> signal=5.0 >= 3.0 -> beta increases.
    """
    store = make_store(tmp_path, "freeze_strong.db")

    b = store.insert_belief(
        "freeze-level belief",
        BELIEF_FACTUAL,
        BSRC_USER_STATED,
        alpha=9.0,
        beta_param=0.5,
        locked=True,
        lock_level="freeze",
    )

    beta_before = 0.5
    store.update_confidence(b.id, "harmful", valence=-5.0)
    state = get_belief_state(store, b.id)
    store.close()

    assert state["beta"] > beta_before, (  # type: ignore[operator]
        f"Freeze belief should yield to strong evidence. "
        f"beta_before={beta_before}, beta_after={state['beta']}"
    )


# ---------------------------------------------------------------------------
# Test 5: Existing user-locked beliefs are unaffected (regression)
#
# Adding freeze must not break any existing user-lock behavior.
# ---------------------------------------------------------------------------


def test_existing_user_lock_unaffected(tmp_path: Path) -> None:
    """Existing user-locked beliefs must behave identically after freeze tier is added."""
    store = make_store(tmp_path, "user_regression.db")

    b = store.insert_belief(
        "user-locked belief",
        BELIEF_FACTUAL,
        BSRC_USER_STATED,
        alpha=9.0,
        beta_param=0.5,
        locked=True,
    )
    # Verify it was created as user-locked
    state_before = get_belief_state(store, b.id)
    assert state_before["locked"] is True
    assert state_before["lock_level"] == "user"

    # Weak evidence should be blocked (same as before)
    store.update_confidence(b.id, "harmful", valence=-0.5)
    state_after = get_belief_state(store, b.id)
    store.close()

    assert state_after["beta"] == pytest.approx(0.5), (  # type: ignore[reportUnknownMemberType]
        f"user-locked regression: beta changed unexpectedly to {state_after['beta']:.4f}"
    )
