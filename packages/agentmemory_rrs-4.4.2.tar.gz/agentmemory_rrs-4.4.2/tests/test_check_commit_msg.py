"""Tests for scripts/check-commit-msg.py — prefix enforcement and LLM attribution."""

from __future__ import annotations

import importlib.util
import sys
import types
from pathlib import Path

import pytest

_SCRIPT = Path(__file__).parents[1] / "scripts" / "check-commit-msg.py"


def _load_module() -> types.ModuleType:
    spec = importlib.util.spec_from_file_location("check_commit_msg", _SCRIPT)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


@pytest.fixture()
def msg_file(tmp_path: Path) -> Path:
    return tmp_path / "COMMIT_EDITMSG"


@pytest.fixture()
def mod() -> types.ModuleType:
    return _load_module()


class TestPrefixEnforcement:
    def test_valid_prefix_passes(self, mod: types.ModuleType, msg_file: Path) -> None:
        msg_file.write_text("fix: correct scoring decay\n", encoding="utf-8")
        sys.argv = ["check-commit-msg.py", str(msg_file)]
        mod.main()  # must not raise SystemExit

    def test_invalid_prefix_exits(self, mod: types.ModuleType, msg_file: Path) -> None:
        msg_file.write_text("bugfix: something\n", encoding="utf-8")
        sys.argv = ["check-commit-msg.py", str(msg_file)]
        with pytest.raises(SystemExit):
            mod.main()

    def test_merge_commit_bypasses_check(
        self, mod: types.ModuleType, msg_file: Path
    ) -> None:
        msg_file.write_text("Merge branch 'main' into fix/gh-72\n", encoding="utf-8")
        sys.argv = ["check-commit-msg.py", str(msg_file)]
        try:
            mod.main()
        except SystemExit as exc:
            assert exc.code in (0, None), f"Expected clean exit, got {exc.code}"


class TestLLMAttribution:
    def test_appends_model_and_effort(
        self,
        mod: types.ModuleType,
        msg_file: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("AGENTMEMORY_LLM_MODEL", "gpt-5.4")
        monkeypatch.setenv("AGENTMEMORY_LLM_EFFORT", "medium")
        msg_file.write_text("fix: resolve db lock contention\n", encoding="utf-8")
        sys.argv = ["check-commit-msg.py", str(msg_file)]
        mod.main()
        result = msg_file.read_text(encoding="utf-8").splitlines()[0]
        assert result == "fix: resolve db lock contention, authored by gpt-5.4 medium"

    def test_appends_model_without_effort(
        self,
        mod: types.ModuleType,
        msg_file: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("AGENTMEMORY_LLM_MODEL", "claude-sonnet-4-6")
        monkeypatch.delenv("AGENTMEMORY_LLM_EFFORT", raising=False)
        msg_file.write_text("feat: add wonder tool\n", encoding="utf-8")
        sys.argv = ["check-commit-msg.py", str(msg_file)]
        mod.main()
        result = msg_file.read_text(encoding="utf-8").splitlines()[0]
        assert result == "feat: add wonder tool, authored by claude-sonnet-4-6"

    def test_idempotent_when_attribution_present(
        self,
        mod: types.ModuleType,
        msg_file: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("AGENTMEMORY_LLM_MODEL", "gpt-5.4")
        monkeypatch.setenv("AGENTMEMORY_LLM_EFFORT", "medium")
        msg_file.write_text(
            "fix: resolve lock, authored by gpt-5.4 medium\n", encoding="utf-8"
        )
        sys.argv = ["check-commit-msg.py", str(msg_file)]
        mod.main()
        result = msg_file.read_text(encoding="utf-8").splitlines()[0]
        assert result.count("authored by") == 1

    def test_no_attribution_without_model_env(
        self,
        mod: types.ModuleType,
        msg_file: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.delenv("AGENTMEMORY_LLM_MODEL", raising=False)
        monkeypatch.delenv("AGENTMEMORY_LLM_EFFORT", raising=False)
        msg_file.write_text("chore: bump version\n", encoding="utf-8")
        sys.argv = ["check-commit-msg.py", str(msg_file)]
        mod.main()
        result = msg_file.read_text(encoding="utf-8")
        assert "authored by" not in result

    def test_multiline_message_only_modifies_subject(
        self,
        mod: types.ModuleType,
        msg_file: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("AGENTMEMORY_LLM_MODEL", "gpt-5.4")
        monkeypatch.setenv("AGENTMEMORY_LLM_EFFORT", "high")
        msg_file.write_text(
            "fix: correct decay\n\nSome longer description here.\n", encoding="utf-8"
        )
        sys.argv = ["check-commit-msg.py", str(msg_file)]
        mod.main()
        lines = msg_file.read_text(encoding="utf-8").splitlines()
        assert lines[0] == "fix: correct decay, authored by gpt-5.4 high"
        assert lines[1] == ""
        assert lines[2] == "Some longer description here."
