"""Tests for the enforcement triad: directive detection, compliance audit, selective injection.

Validates hypotheses H1, H2, H3 from experiments/enforcement_triad_hypotheses.md.
Each test is atomic, fast (< 5s), and deterministic.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from agentmemory.models import Belief
from agentmemory.store import MemoryStore


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def store(tmp_path: Path) -> MemoryStore:
    db_path: Path = tmp_path / "test_enforcement.db"
    return MemoryStore(db_path)


@pytest.fixture()
def config_file(tmp_path: Path) -> Path:
    """Create a test config file."""
    cfg = tmp_path / "config.json"
    cfg.write_text('{"telemetry": {"enabled": false}}')
    return cfg


@pytest.fixture()
def config_file_enabled(tmp_path: Path) -> Path:
    """Create a test config file with telemetry enabled."""
    cfg = tmp_path / "config.json"
    cfg.write_text('{"telemetry": {"enabled": true}}')
    return cfg


# ---------------------------------------------------------------------------
# H1: Directive Detection
# ---------------------------------------------------------------------------


class TestDirectiveDetection:
    """H1: Imperative user statements are reliably detected."""

    @pytest.mark.parametrize(
        "text",
        [
            "fix the hanging tests",
            "enable telemetry",
            "wire up the metrics",
            "make sure the publish script works",
            "turn on token tracking",
            "add pytest-timeout to dev deps",
            "install the hook and verify it runs",
        ],
    )
    def test_imperative_detected(self, text: str) -> None:
        """H1: imperative patterns classified as directives."""
        from agentmemory.enforcement import detect_directive

        result: dict[str, Any] = detect_directive(text)
        assert result["is_directive"] is True, f"Failed to detect: {text}"

    @pytest.mark.parametrize(
        "text",
        [
            "what is telemetry?",
            "the tests passed",
            "metrics look good today",
            "i think we should consider options",
            "how does the publish script work?",
            "interesting approach",
        ],
    )
    def test_non_imperative_not_detected(self, text: str) -> None:
        """H1: non-imperative statements not classified as directives."""
        from agentmemory.enforcement import detect_directive

        result: dict[str, Any] = detect_directive(text)
        assert result["is_directive"] is False, f"False positive: {text}"

    def test_directive_creates_todo(self, store: MemoryStore) -> None:
        """H1a: detected directive creates a TODO belief."""
        from agentmemory.enforcement import process_directive

        belief: Belief | None = process_directive(
            store, "enable telemetry tracking"
        )
        assert belief is not None
        assert belief.belief_type == "todo"
        assert belief.temporal_direction == "forward"
        assert "telemetry" in belief.content.lower()

    def test_repetition_detection(self, store: MemoryStore) -> None:
        """H1b: repeated directive detected via Jaccard similarity."""
        from agentmemory.enforcement import detect_repetition, process_directive

        process_directive(store, "enable telemetry tracking for token usage")
        is_repeat, count = detect_repetition(
            store, "enable the telemetry tracking system for usage"
        )
        assert is_repeat is True
        assert count >= 1

    def test_no_repetition_different_topic(self, store: MemoryStore) -> None:
        """H1b: unrelated directive not flagged as repetition."""
        from agentmemory.enforcement import detect_repetition, process_directive

        process_directive(store, "enable telemetry tracking")
        is_repeat, _count = detect_repetition(
            store, "fix the database migration script"
        )
        assert is_repeat is False

    def test_escalation_after_threshold(self, store: MemoryStore) -> None:
        """H1b: escalation flag set after 3 repetitions."""
        from agentmemory.enforcement import (
            check_escalation,
            process_directive,
        )

        process_directive(store, "enable telemetry tracking for internal metrics")
        process_directive(store, "enable the telemetry tracking for session metrics")
        process_directive(store, "enable telemetry tracking and internal session metrics")

        escalations: list[dict[str, Any]] = check_escalation(store, threshold=3)
        assert len(escalations) >= 1
        assert "telemetry" in escalations[0]["content"].lower()


# ---------------------------------------------------------------------------
# H2: Compliance Audit
# ---------------------------------------------------------------------------


class TestComplianceAudit:
    """H2: Session-end audit detects violated locked beliefs."""

    def test_file_contains_violation(
        self, store: MemoryStore, config_file: Path
    ) -> None:
        """H2: file_contains check detects missing content."""
        from agentmemory.enforcement import check_compliance

        belief: Belief = store.insert_belief(
            content="Telemetry must be enabled for internal tracking.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )
        store.set_compliance_check(
            belief.id, f"file_contains:{config_file}:enabled: true"
        )

        results: list[dict[str, Any]] = check_compliance(store)
        violations = [r for r in results if r["outcome"] == "violated"]
        assert len(violations) == 1
        assert violations[0]["belief_id"] == belief.id

    def test_file_contains_compliant(
        self, store: MemoryStore, config_file_enabled: Path
    ) -> None:
        """H2: file_contains check passes when content present."""
        from agentmemory.enforcement import check_compliance

        belief: Belief = store.insert_belief(
            content="Telemetry must be enabled.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )
        store.set_compliance_check(
            belief.id, f'file_contains:{config_file_enabled}:"enabled": true'
        )

        results: list[dict[str, Any]] = check_compliance(store)
        violations = [r for r in results if r["outcome"] == "violated"]
        assert len(violations) == 0

    def test_config_value_violation(
        self, store: MemoryStore, config_file: Path
    ) -> None:
        """H2a: config_value predicate detects wrong value."""
        from agentmemory.enforcement import check_compliance

        belief: Belief = store.insert_belief(
            content="Telemetry config must be enabled.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )
        store.set_compliance_check(
            belief.id,
            f"config_value:{config_file}:telemetry.enabled:true",
        )

        results: list[dict[str, Any]] = check_compliance(store)
        violations = [r for r in results if r["outcome"] == "violated"]
        assert len(violations) == 1

    def test_command_succeeds_compliant(self, store: MemoryStore) -> None:
        """H2a: command_succeeds passes when command exits 0."""
        from agentmemory.enforcement import check_compliance

        belief: Belief = store.insert_belief(
            content="Python must be available.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )
        store.set_compliance_check(belief.id, "command_succeeds:python3 --version")

        results: list[dict[str, Any]] = check_compliance(store)
        violations = [r for r in results if r["outcome"] == "violated"]
        assert len(violations) == 0

    def test_command_succeeds_violation(self, store: MemoryStore) -> None:
        """H2a: command_succeeds fails when command exits non-zero."""
        from agentmemory.enforcement import check_compliance

        belief: Belief = store.insert_belief(
            content="Nonexistent tool must be installed.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )
        store.set_compliance_check(
            belief.id, "command_succeeds:nonexistent_tool_xyz123 --version"
        )

        results: list[dict[str, Any]] = check_compliance(store)
        violations = [r for r in results if r["outcome"] == "violated"]
        assert len(violations) == 1

    def test_violation_recorded_in_tests_table(
        self, store: MemoryStore, config_file: Path
    ) -> None:
        """H2b: violations create test records with correct metadata."""
        from agentmemory.enforcement import check_compliance, record_violations

        # Create a session so FK constraint is satisfied
        from agentmemory.models import Session

        session: Session = store.create_session()

        belief: Belief = store.insert_belief(
            content="Telemetry must be enabled.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )
        store.set_compliance_check(
            belief.id, f"file_contains:{config_file}:enabled: true"
        )

        results = check_compliance(store)
        violations = [r for r in results if r["outcome"] == "violated"]
        record_violations(store, violations, session_id=session.id)

        # Verify test record exists
        tests = store.get_test_results(belief.id)
        assert len(tests) >= 1
        assert tests[-1]["outcome"] == "violated"
        assert tests[-1]["detection_layer"] == "compliance_audit"


# ---------------------------------------------------------------------------
# H3: Selective Injection
# ---------------------------------------------------------------------------


def _insert_with_activation(
    store: MemoryStore, content: str, activation_condition: str
) -> Belief:
    """Helper to insert a locked requirement with activation_condition."""
    belief: Belief = store.insert_belief(
        content=content,
        belief_type="requirement",
        source_type="user_stated",
        alpha=9.0,
        beta_param=0.5,
        locked=True,
    )
    # Set activation_condition via public connection property
    import sqlite3

    conn: sqlite3.Connection = store.connection
    conn.execute(
        "UPDATE beliefs SET activation_condition = ? WHERE id = ?",
        (activation_condition, belief.id),
    )
    conn.commit()
    belief.activation_condition = activation_condition
    return belief


class TestSelectiveInjection:
    """H3: Task-relevant constraint selection improves over blanket injection."""

    def test_relevance_selection(self, store: MemoryStore) -> None:
        """H3a: relevant beliefs selected, irrelevant excluded."""
        from agentmemory.enforcement import select_relevant_constraints

        # Git workflow constraint
        _insert_with_activation(
            store,
            "Never push to github directly. Use publish script.",
            "keyword_any:push,github,deploy,release",
        )

        # Test philosophy constraint
        _insert_with_activation(
            store,
            "Tests must be atomic and fail-fast with timeouts.",
            "keyword_any:test,pytest,testing",
        )

        # Query about deployment
        selected = select_relevant_constraints(
            store, "push the release to github"
        )

        contents = [b.content for b in selected]
        assert any("publish script" in c for c in contents)
        # Test constraint should NOT be selected for a deploy prompt
        assert not any("fail-fast" in c for c in contents)

    def test_token_reduction(self, store: MemoryStore) -> None:
        """H3b: selective injection reduces token count by >= 70%."""
        from agentmemory.enforcement import select_relevant_constraints

        # Create 9 locked beliefs (~700 chars each)
        for i in range(9):
            _insert_with_activation(
                store,
                f"Locked requirement {i}: " + "x" * 700,
                f"keyword_any:topic{i}",
            )

        # Only topic0 is relevant
        selected = select_relevant_constraints(store, "topic0 work", max_k=5)

        all_chars = 9 * 720  # approximate total
        selected_chars = sum(len(b.content) for b in selected)
        reduction = 1.0 - (selected_chars / all_chars)
        assert reduction >= 0.7, f"Reduction was only {reduction:.1%}"

    def test_imperative_format_output(self, store: MemoryStore) -> None:
        """H3c: selected constraints rendered as imperatives with trigger/action."""
        from agentmemory.enforcement import format_selective_injection

        _insert_with_activation(
            store,
            "Never push to github directly. Use publish script.",
            "keyword_any:push,github",
        )

        output: str = format_selective_injection(
            store, "push the release to github"
        )

        # Should be imperative, not declarative
        assert "BEFORE PROCEEDING" in output or "VERIFY" in output
        assert "publish" in output.lower()
