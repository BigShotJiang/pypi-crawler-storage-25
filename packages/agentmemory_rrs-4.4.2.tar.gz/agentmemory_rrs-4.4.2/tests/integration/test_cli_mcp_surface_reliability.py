"""Cross-surface reliability tests for CLI writes and MCP reads."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Generator

import pytest

import agentmemory.server as server_mod
from agentmemory import cli
from agentmemory.store import MemoryStore


@pytest.fixture(autouse=True)
def _reset_server_store() -> Generator[None, None, None]:  # pyright: ignore[reportUnusedFunction]
    server_mod._set_store(None)  # type: ignore[arg-type]  # pyright: ignore[reportPrivateUsage]
    yield
    server_mod._set_store(None)  # type: ignore[arg-type]  # pyright: ignore[reportPrivateUsage]


def test_cli_lock_then_mcp_search_is_stable(capsys: object) -> None:
    server_store: MemoryStore = server_mod._get_store()  # pyright: ignore[reportPrivateUsage]
    assert server_store is not None

    cli.cmd_lock(argparse.Namespace(text=["Never", "deploy", "with", "FTP"]))
    capsys.readouterr()  # type: ignore[attr-defined]

    result: str = server_mod.search("deploy FTP")
    assert "Never deploy with FTP" in result
    assert "timed out" not in result.lower()


def test_cli_write_then_mcp_status_then_search_is_stable(capsys: object) -> None:
    cli.cmd_remember(
        argparse.Namespace(text=["Use", "structured", "logging", "for", "workers"])
    )
    capsys.readouterr()  # type: ignore[attr-defined]

    status_text: str = server_mod.status()
    search_text: str = server_mod.search("structured logging workers")

    assert "Inventory:" in status_text
    assert "Use structured logging for workers" in search_text


def test_repeated_mcp_search_calls_after_cli_write_remain_stable(
    capsys: object,
) -> None:
    cli.cmd_remember(
        argparse.Namespace(text=["Immediate", "post-write", "read", "stability", "check"])
    )
    capsys.readouterr()  # type: ignore[attr-defined]

    first: str = server_mod.search("post-write read stability")
    second: str = server_mod.search("post-write read stability")
    third: str = server_mod.search("post-write read stability")

    expected: str = "Immediate post-write read stability check"
    assert expected in first
    assert expected in second
    assert expected in third


def test_read_only_project_path_search_remains_isolated(
    monkeypatch: object,
) -> None:
    primary_db: Path = Path(os.environ["AGENTMEMORY_DB"])
    foreign_db: Path = primary_db.parent / "foreign.db"

    foreign_store: MemoryStore = MemoryStore(foreign_db)
    foreign_store.insert_belief(
        content="Foreign project deployment runbook",
        belief_type="factual",
        source_type="user_stated",
        alpha=9.0,
        beta_param=0.5,
    )
    foreign_store.close()

    monkeypatch.setattr(server_mod, "_resolve_project_db", lambda _path: foreign_db)  # type: ignore[attr-defined]

    before_store: MemoryStore = MemoryStore(primary_db)
    pending_before: int = len(before_store.get_pending_feedback())
    before_store.close()

    result: str = server_mod.search("deployment runbook", project_path="/tmp/foreign")
    assert "read-only cross-project results" in result.lower()
    assert "Foreign project deployment runbook" in result

    after_store: MemoryStore = MemoryStore(primary_db)
    pending_after: int = len(after_store.get_pending_feedback())
    after_store.close()

    assert pending_after == pending_before


def test_read_only_project_path_search_reports_budget_exhaustion(
    monkeypatch: object,
) -> None:
    primary_db: Path = Path(os.environ["AGENTMEMORY_DB"])
    foreign_db: Path = primary_db.parent / "foreign_budget.db"

    foreign_store: MemoryStore = MemoryStore(foreign_db)
    foreign_store.insert_belief(
        content=(
            "Setr temporal backbone analysis is still relevant to retrieval "
            "architecture experiments."
        ),
        belief_type="factual",
        source_type="user_stated",
        alpha=9.0,
        beta_param=0.5,
    )
    foreign_store.close()

    monkeypatch.setattr(server_mod, "_resolve_project_db", lambda _path: foreign_db)  # type: ignore[attr-defined]

    result: str = server_mod.search(
        "Setr temporal backbone",
        budget=5,
        project_path="/tmp/foreign-budget",
    )

    assert "No beliefs fit within the current token budget" in result
    assert "No beliefs found in /tmp/foreign-budget matching your query." not in result
