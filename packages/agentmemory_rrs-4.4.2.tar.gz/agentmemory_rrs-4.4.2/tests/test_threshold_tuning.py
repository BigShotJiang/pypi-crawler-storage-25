"""Threshold tuning validation tests.

These tests validate that agentmemory's configurable thresholds produce
reasonable behavior across arbitrary projects, not just this one. They
use synthetic belief populations to test edge cases and boundary conditions.

Each test documents the threshold it validates, the expected behavior,
and what going wrong would look like (false positives vs false negatives).
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from agentmemory.models import Belief
from agentmemory.store import MemoryStore
from agentmemory.supersession import (
    check_temporal_supersession,
    extract_terms,
    jaccard_similarity,
)

# Access thresholds via module attribute (avoids private import lint)
import agentmemory.supersession as _ss

MIN_JACCARD: float = _ss.MIN_JACCARD
MIN_JACCARD_LOCKED: float = _ss.MIN_JACCARD_LOCKED


@pytest.fixture()
def store(tmp_path: Path) -> MemoryStore:
    return MemoryStore(tmp_path / "test_thresholds.db")


def _hours_ago(hours: float) -> str:
    return (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()


# ---------------------------------------------------------------------------
# Supersession thresholds
# ---------------------------------------------------------------------------


class TestSupersessionThresholds:
    """Validate MIN_JACCARD (0.4) and MIN_JACCARD_LOCKED (0.5)."""

    def test_threshold_values_documented(self) -> None:
        """Thresholds exist and are within valid range."""
        assert 0.0 < MIN_JACCARD < 1.0
        assert 0.0 < MIN_JACCARD_LOCKED < 1.0
        assert MIN_JACCARD_LOCKED >= MIN_JACCARD

    def test_same_topic_different_numbers_supersedes(
        self, store: MemoryStore
    ) -> None:
        """Status updates where only quantities change should supersede.

        This is the most common supersession case: "29 modules" -> "35 modules".
        Tests that the unlocked threshold (0.4) catches this pattern.
        """
        store.insert_belief(
            content="The project has twenty-nine production modules and thirty-one tools for building.",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=5.0,
            beta_param=1.0,
            created_at=_hours_ago(72),
        )
        new: Belief = store.insert_belief(
            content="The project has thirty-five production modules and thirty-one tools for building.",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=5.0,
            beta_param=1.0,
        )
        result = check_temporal_supersession(store, new)
        assert result.superseded_id != ""

    def test_different_topics_no_false_positive(
        self, store: MemoryStore
    ) -> None:
        """Beliefs about different topics should never supersede each other.

        False positive here means unrelated beliefs being replaced.
        """
        store.insert_belief(
            content="The database uses PostgreSQL with WAL mode enabled.",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=5.0,
            beta_param=1.0,
            created_at=_hours_ago(48),
        )
        new: Belief = store.insert_belief(
            content="The frontend uses React with TypeScript strict mode.",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=5.0,
            beta_param=1.0,
        )
        result = check_temporal_supersession(store, new)
        assert result.superseded_id == ""

    def test_locked_requires_higher_overlap(self, store: MemoryStore) -> None:
        """Locked beliefs need Jaccard >= 0.5, unlocked need >= 0.4.

        A pair with Jaccard between 0.4 and 0.5 should supersede unlocked
        but NOT locked.
        """
        # Create content pairs that produce ~0.45 Jaccard
        content_a: str = (
            "Deploy to production using the CI pipeline and automated tests."
        )
        content_b: str = (
            "Deploy to staging using the CI pipeline and manual review."
        )
        jaccard: float = jaccard_similarity(
            extract_terms(content_a), extract_terms(content_b)
        )
        # Verify Jaccard is in the gap between thresholds
        assert 0.35 <= jaccard <= 0.55, f"Test content Jaccard={jaccard:.3f}, need 0.35-0.55"

        if jaccard >= MIN_JACCARD and jaccard < MIN_JACCARD_LOCKED:
            # Unlocked: should supersede
            store.insert_belief(
                content=content_a,
                belief_type="factual",
                source_type="agent_inferred",
                alpha=5.0,
                beta_param=1.0,
                created_at=_hours_ago(48),
            )
            new_unlocked: Belief = store.insert_belief(
                content=content_b,
                belief_type="factual",
                source_type="agent_inferred",
                alpha=5.0,
                beta_param=1.0,
            )
            result_unlocked = check_temporal_supersession(store, new_unlocked)
            assert result_unlocked.superseded_id != ""


# ---------------------------------------------------------------------------
# Sentiment thresholds
# ---------------------------------------------------------------------------


class TestSentimentThresholds:
    """Validate sentiment detection boundary conditions."""

    def test_short_affirmatives_are_positive(self) -> None:
        """Single-word or two-word approvals must detect as positive.

        These are the most common user feedback patterns. Missing them
        means the feedback loop is deaf to the most frequent signals.
        """
        from agentmemory.sentiment_feedback import detect_sentiment

        for phrase in ["yes", "ok", "good", "nice", "yeah", "yep", "cool"]:
            result = detect_sentiment(phrase)
            assert result.sentiment == "positive", f"Missed positive: {phrase!r}"

    def test_long_messages_are_neutral(self) -> None:
        """Messages > 200 chars should be neutral (task content, not feedback).

        False positive here means task descriptions getting treated as
        approval/rejection, polluting belief confidence.
        """
        from agentmemory.sentiment_feedback import detect_sentiment

        long_msg: str = "yes " + "please implement the following changes to the API: " * 5
        assert len(long_msg) > 200
        result = detect_sentiment(long_msg)
        assert result.sentiment == "neutral"

    def test_questions_are_neutral(self) -> None:
        """Questions should never be sentiment signals.

        "ok good?" is a question, not approval.
        """
        from agentmemory.sentiment_feedback import detect_sentiment

        for q in ["is that good?", "ok?", "does that work?"]:
            result = detect_sentiment(q)
            # Questions might match positive patterns but should be filtered
            # Note: current implementation doesn't filter questions from positive
            # This test documents the expected behavior for future improvement
            assert result.sentiment in ("positive", "neutral"), f"Unexpected negative for question: {q!r}"

    def test_correction_frequency_requires_multiple_signals(self) -> None:
        """A single negative message should not trigger frequency alarm.

        False positive: one "no" tanks all pending beliefs' confidence.
        """
        from agentmemory.sentiment_feedback import (
            SentimentSignal,
            detect_correction_frequency,
        )

        single: list[SentimentSignal] = [
            SentimentSignal("negative", -0.4, 0.7, "no"),
        ]
        assert detect_correction_frequency(single) == 0.0


# ---------------------------------------------------------------------------
# Reclassification thresholds
# ---------------------------------------------------------------------------


class TestReclassificationThresholds:
    """Validate the 0.5 confidence threshold for reclassification flagging."""

    def test_gradual_decline_flags_at_threshold(
        self, store: MemoryStore
    ) -> None:
        """Multiple small negative signals should eventually flag.

        Simulates gradual evidence accumulation against a belief.
        """
        store.create_session()
        belief: Belief = store.insert_belief(
            content="The cache invalidation uses TTL-based expiry.",
            belief_type="factual",
            source_type="agent_inferred",
            alpha=3.0,
            beta_param=1.0,  # starts at 0.75
        )

        # Apply small negative signals
        for _ in range(5):
            store.update_confidence(belief.id, outcome="harmful", weight=0.5)

        updated: Belief | None = store.get_belief(belief.id)
        assert updated is not None

        if updated.confidence < 0.5:
            flagged = store.get_beliefs_needing_reclassification()
            assert belief.id in flagged
        else:
            # Not enough evidence yet -- that's ok, threshold is protective
            flagged = store.get_beliefs_needing_reclassification()
            assert belief.id not in flagged

    def test_strong_belief_resists_noise(self, store: MemoryStore) -> None:
        """High-confidence beliefs should not be flagged by casual noise.

        A belief with alpha=9.0 should require substantial counter-evidence
        to drop below 0.5.
        """
        store.create_session()
        belief: Belief = store.insert_belief(
            content="All API responses use JSON format.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=20.0,
            beta_param=1.0,  # confidence = 0.952, needs heavy evidence to drop
        )

        # 3 mild negative signals should not flag a strong belief
        for _ in range(3):
            store.update_confidence(belief.id, outcome="harmful", weight=1.0)

        updated = store.get_belief(belief.id)
        assert updated is not None
        assert updated.confidence > 0.5  # still above threshold

        flagged = store.get_beliefs_needing_reclassification()
        assert belief.id not in flagged


# ---------------------------------------------------------------------------
# Compliance check thresholds
# ---------------------------------------------------------------------------


class TestComplianceThresholds:
    """Validate compliance predicates work across project types."""

    def test_file_contains_works_with_any_content(
        self, store: MemoryStore, tmp_path: Path
    ) -> None:
        """file_contains check should work with arbitrary file content.

        Not tied to agentmemory-specific config format.
        """
        from agentmemory.enforcement import check_compliance

        # Create a generic config file
        cfg: Path = tmp_path / "settings.yaml"
        cfg.write_text("debug: true\nlog_level: INFO\n")

        belief: Belief = store.insert_belief(
            content="Debug mode must be enabled in development.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )
        store.set_compliance_check(
            belief.id, f"file_contains:{cfg}:debug: true"
        )

        results = check_compliance(store)
        compliant = [r for r in results if r["outcome"] == "compliant"]
        assert len(compliant) == 1

    def test_command_succeeds_works_with_any_command(
        self, store: MemoryStore
    ) -> None:
        """command_succeeds should work with arbitrary shell commands."""
        from agentmemory.enforcement import check_compliance

        belief: Belief = store.insert_belief(
            content="Python 3 must be available.",
            belief_type="requirement",
            source_type="user_stated",
            alpha=9.0,
            beta_param=0.5,
            locked=True,
        )
        store.set_compliance_check(
            belief.id, "command_succeeds:python3 -c 'print(1)'"
        )

        results = check_compliance(store)
        assert results[0]["outcome"] == "compliant"
