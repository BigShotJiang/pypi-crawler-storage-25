<!--
CONTRIBUTOR NOTICE
- This repo has no bounty program. PRs that claim to fix issues with trivial
  or unrelated changes (comment additions, whitespace, placeholder text) will
  be closed immediately and the account blocked.
- All PRs must correspond to an open issue filed BEFORE the PR.
- Branch naming: <type>/gh-<issue>-<slug> (e.g. fix/gh-72-token-budget).
-->

## Summary

<!-- What does this PR do? -->

## Related issue

<!-- Required: must link to an existing open issue.
     Use a closing keyword: Closes #72 / Fixes #72 / Resolves #72 -->

## Test plan

- [ ] `uv run pytest tests/ -x -q` passes
- [ ] `uv run pyright` passes (strict mode)
- [ ] `uv run ruff check .` passes

## Checklist

- [ ] Commits follow conventional prefix format (feat/fix/docs/test/chore)
- [ ] Branch name follows `<type>/gh-<issue>-<slug>` or approved release branch format
- [ ] PR body links the owning issue with `Closes #<issue>` / `Fixes #<issue>` / `Resolves #<issue>`
- [ ] No large data files or results committed
- [ ] No PII or secrets in tracked files
