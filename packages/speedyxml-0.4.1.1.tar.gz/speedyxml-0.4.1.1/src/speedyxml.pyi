from typing import TypeAlias, Union

XML: TypeAlias = tuple[
    str,
    dict[str, str] | None,
    list[Union['XML', str]] | None,
]

__all__ = [
    'parse',
    'XMLParseException',
    'FLAG_EXPANDEMPTY',
    'FLAG_IGNOREENTITIES',
    'FLAG_RETURNCOMMENTS',
    'FLAG_RETURNPI',
    'FLAG_RETURNPOSITIONS',
    'TAG_COMMENT',
    'TAG_PI',
]

def parse(xml: str, flags: int = 0) -> XML: ...

class XMLParseException(Exception): ...

FLAG_EXPANDEMPTY: int
FLAG_IGNOREENTITIES: int
FLAG_RETURNCOMMENTS: int
FLAG_RETURNPI: int
FLAG_RETURNPOSITIONS: int
TAG_COMMENT: str
TAG_PI: str
