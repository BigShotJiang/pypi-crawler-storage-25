"""
Rich-based premium terminal UI for django-ai-translator.

Production-grade CLI experience by Happy-Cyber:
  - ASCII art logo with boot animation
  - API key status matrix
  - Interactive provider & model menus
  - Real-time progress bars
  - Final summary report with credits
"""

import time

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.prompt import IntPrompt, Prompt
from rich.table import Table
from rich.text import Text

console = Console()

# ── Package info ─────────────────────────────────────────────────────

VERSION = "2.0.4"
AUTHOR = "Happy-Cyber"
GITHUB = "https://github.com/Happy-cyber"

# ── ASCII Art Logos ──────────────────────────────────────────────────

LOGO_MAIN = r"""
  ╔╦╗ ╦╔═╗ ╔╗╔ ╔═╗ ╔═╗        ╔═╗ ╦
   ║║ ║╠═╣ ║║║ ║ ╦ ║ ║  ──────  ╠═╣ ║
  ═╩╝╚╝╩ ╩ ╝╚╝ ╚═╝ ╚═╝        ╩ ╩ ╩
  ╔╦╗ ╦═╗ ╔═╗ ╔╗╔ ╔═╗ ╦  ╔═╗ ╔╦╗ ╔═╗ ╦═╗
   ║  ╠╦╝ ╠═╣ ║║║ ╚═╗ ║  ╠═╣  ║  ║ ║ ╠╦╝
   ╩  ╩╚═ ╩ ╩ ╝╚╝ ╚═╝ ╩═╝╩ ╩  ╩  ╚═╝ ╩╚═
"""

LOGO_AUTHOR = r"""
  ╦ ╦ ╔═╗ ╔═╗ ╔═╗ ╦ ╦         ╔═╗ ╦ ╦ ╔╗  ╔═╗ ╦═╗
  ╠═╣ ╠═╣ ╠═╝ ╠═╝ ╚╦╝  ─────  ║   ╚╦╝ ╠╩╗ ║╣  ╠╦╝
  ╩ ╩ ╩ ╩ ╩   ╩    ╩          ╚═╝  ╩  ╚═╝ ╚═╝ ╩╚═
"""


# ── Typing animation ─────────────────────────────────────────────────


def _type_effect(text: str, style: str = "green", delay: float = 0.02):
    from rich.live import Live

    styled = Text(style=style)
    with Live(styled, console=console, refresh_per_second=60, transient=True):
        for char in text:
            styled.append(char)
            time.sleep(delay)
    console.print(styled)


# ── Boot sequence ─────────────────────────────────────────────────────


def show_boot_sequence():
    console.print()

    # Main logo
    console.print(
        Panel(
            f"[bold bright_green]{LOGO_MAIN}[/]\n"
            f"[bold bright_cyan]  AI-Powered Translation Engine[/]\n"
            f"[dim green]  v{VERSION} — by {AUTHOR}[/]",
            border_style="bright_green",
            box=box.DOUBLE_EDGE,
            padding=(0, 2),
        )
    )
    console.print()

    steps = [
        ("[ SYS.INIT ] Booting translation core...", 0.25),
        ("[ SYS.LOAD ] Loading AI translation backends...", 0.2),
        ("[ SYS.SCAN ] Scanning environment variables...", 0.2),
        ("[ SYS.LANG ] Injecting language matrix...", 0.2),
        ("[ SYS.READY] Calibrating neural translation pathways...", 0.15),
    ]

    for msg, delay in steps:
        _type_effect(msg, style="dim cyan", delay=0.010)
        time.sleep(delay)

    console.print()
    console.print("[bold green]  ● [/] [green]System Boot Complete[/]")
    console.print("[bold green]  ● [/] [green]Environment Loaded[/]")
    console.print("[bold green]  ● [/] [green]Translation Engine Online[/]")
    console.print()
    console.rule(style="bright_green")
    console.print()


# ── API Key status matrix ─────────────────────────────────────────────


def show_env_key_status(key_status: dict[str, str | None], labels: dict[str, str]):
    table = Table(
        title="[bold bright_cyan]⚡ API Key Status Matrix[/]",
        box=box.HEAVY_HEAD,
        border_style="cyan",
        show_lines=False,
        padding=(0, 1),
        title_justify="center",
    )
    table.add_column("Provider", style="bold white", min_width=28)
    table.add_column("Env Variable", style="dim cyan")
    table.add_column("Status", justify="center", min_width=20)

    for key, label in labels.items():
        val = key_status.get(key)
        if val:
            masked = val[:4] + "•" * 8 + val[-4:] if len(val) > 12 else "••••••••"
            status = f"[bold green]● ACTIVE[/]  [dim]{masked}[/]"
        else:
            status = "[dim red]○ NOT SET[/]"
        table.add_row(f"  {label}", f"[dim]{key}[/]", status)

    console.print(table)
    console.print()


# ── Provider selection menu ───────────────────────────────────────────

PROVIDER_MENU = [
    {"key": "claude", "label": "Claude (Anthropic)", "tag": "Recommended", "icon": "⚡", "color": "bright_cyan"},
    {"key": "openai", "label": "OpenAI GPT", "tag": "Powerful", "icon": "🧠", "color": "bright_green"},
    {"key": "openrouter", "label": "OpenRouter", "tag": "100+ Models", "icon": "🔥", "color": "bright_yellow"},
    {"key": "gemini", "label": "Google Gemini", "tag": "Ultra Fast", "icon": "✦", "color": "yellow"},
    {"key": "mistral", "label": "Mistral AI", "tag": "EU Languages", "icon": "🇪🇺", "color": "bright_magenta"},
    {"key": "skip", "label": "Skip Translation", "tag": "msgid only", "icon": "⏭", "color": "dim"},
]


def show_model_selection(no_input: bool = False, provider: str | None = None) -> str:
    if provider:
        valid = {p["key"] for p in PROVIDER_MENU}
        if provider in valid:
            console.print(f"[bold cyan]  ⚙ Provider:[/] [bold]{provider}[/] (from --provider flag)")
            return provider
        console.print(f"[bold red]  ✗ Unknown provider:[/] {provider}")
        raise SystemExit(1)

    if no_input:
        console.print("[bold cyan]  ⚙ Provider:[/] [bold]skip[/] (--no-input mode)")
        return "skip"

    console.print(
        Panel(
            "[bold bright_cyan]SELECT TRANSLATION ENGINE[/]",
            border_style="cyan",
            box=box.HEAVY,
            padding=(0, 2),
        )
    )
    console.print()

    for idx, p in enumerate(PROVIDER_MENU, 1):
        console.print(
            f"  [bold white][{idx}][/]  {p['icon']}  "
            f"[bold {p['color']}]{p['label']}[/]  "
            f"[{p['color']}]· {p['tag']}[/]"
        )

    console.print()

    while True:
        choice = IntPrompt.ask(
            "[bold yellow]  → Enter your choice[/]",
            choices=[str(i) for i in range(1, len(PROVIDER_MENU) + 1)],
        )
        selected = PROVIDER_MENU[choice - 1]
        console.print(f"\n  [bold green]●[/] Selected: [bold]{selected['label']}[/]\n")
        return selected["key"]


# ── OpenRouter model submenu ──────────────────────────────────────────


def show_openrouter_model_selection(
    models: list[dict], no_input: bool = False, model_flag: str | None = None
) -> str:
    if model_flag:
        console.print(f"[bold cyan]  ⚙ Model:[/] [bold]{model_flag}[/] (from --model flag)")
        return model_flag

    if no_input:
        default = models[0]["id"]
        console.print(f"[bold cyan]  ⚙ Model:[/] [bold]{default}[/] (default)")
        return default

    console.print(
        Panel(
            "[bold bright_yellow]SELECT OPENROUTER MODEL[/]",
            border_style="yellow",
            box=box.HEAVY,
            padding=(0, 2),
        )
    )
    console.print()

    for idx, m in enumerate(models, 1):
        console.print(
            f"  [bold white][{idx:2d}][/]  "
            f"[bold {m['color']}]{m['name']}[/]  "
            f"[{m['color']}]· {m['tag']}[/]"
        )
        console.print(f"       [dim]{m['id']}[/]")

    console.print()

    while True:
        choice = IntPrompt.ask(
            "[bold yellow]  → Select model[/]",
            choices=[str(i) for i in range(1, len(models) + 1)],
        )
        selected = models[choice - 1]
        console.print(
            f"\n  [bold green]●[/] Model: [bold]{selected['name']}[/] "
            f"[dim]({selected['id']})[/]\n"
        )
        return selected["id"]


# ── API Key prompt ────────────────────────────────────────────────────


def prompt_api_key(provider_name: str, env_var: str) -> str:
    console.print(
        Panel(
            f"[bold yellow]⚠ {env_var} not found in .env[/]\n\n"
            f"  A valid API key is required for [bold]{provider_name}[/].\n"
            f"  [dim]The key will be saved to .env automatically.[/]",
            border_style="yellow",
            box=box.ROUNDED,
            padding=(1, 2),
        )
    )
    while True:
        key = Prompt.ask(f"[bold cyan]  → Enter your {provider_name} API key[/]")
        key = key.strip()
        if key:
            return key
        console.print("[red]    Key cannot be empty. Try again.[/]")


# ── Status helpers ────────────────────────────────────────────────────


def show_success(msg: str):
    console.print(f"  [bold green]●[/] {msg}")


def show_warning(msg: str):
    console.print(f"  [bold yellow]▲[/] {msg}")


def show_error(msg: str):
    console.print(f"  [bold red]✗[/] {msg}")


def show_info(msg: str):
    console.print(f"  [bold cyan]ℹ[/] {msg}")


def show_step(step_num: int, title: str):
    console.print()
    console.rule(f"[bold bright_cyan] STEP {step_num} ┃ {title} [/]", style="cyan")
    console.print()


def show_auth_failure(provider_name: str):
    console.print()
    console.print(
        Panel(
            f"[bold red]╳ AUTHENTICATION FAILURE[/]\n\n"
            f"  Invalid API Key detected for [bold]{provider_name}[/].\n"
            f"  Please verify your key and try again.\n\n"
            f"  [dim]💡 Check if the key is expired or has wrong permissions.[/]\n"
            f"  [dim red]→ Execution halted.[/]",
            border_style="red",
            box=box.DOUBLE_EDGE,
            padding=(1, 2),
        )
    )


def show_dry_run_banner():
    console.print(
        Panel(
            "[bold yellow]  ◆ DRY RUN MODE — No files will be modified  [/]",
            border_style="yellow",
            box=box.HEAVY,
        )
    )
    console.print()


# ── Scan results ──────────────────────────────────────────────────────


def show_scan_results(
    files_scanned: int, total_messages: int, new_messages: int, skipped_dynamic: int
):
    table = Table(
        box=box.SIMPLE,
        show_header=False,
        padding=(0, 2),
        show_edge=False,
    )
    table.add_column("Label", style="white")
    table.add_column("Value", style="bold cyan", justify="right")

    table.add_row("  [green]●[/] Files scanned", str(files_scanned))
    table.add_row("  [green]●[/] Messages found", str(total_messages))
    table.add_row("  [green]●[/] New messages", f"[bold bright_cyan]{new_messages}[/]")
    if skipped_dynamic:
        table.add_row("  [yellow]▲[/] Skipped (dynamic)", str(skipped_dynamic))

    console.print(table)


def show_languages(target_languages: dict[str, str]):
    langs = "  ".join(
        f"[bold]{name}[/][dim]({code})[/]"
        for code, name in target_languages.items()
    )
    console.print(f"  [green]●[/] Languages:  {langs}")


# ── Progress bar ──────────────────────────────────────────────────────


def create_translation_progress() -> Progress:
    return Progress(
        SpinnerColumn("dots", style="bright_cyan"),
        TextColumn("[bold cyan]{task.description}[/]"),
        BarColumn(
            bar_width=40,
            style="dim cyan",
            complete_style="bold bright_green",
            finished_style="bold green",
        ),
        TaskProgressColumn(),
        TextColumn("[dim]•[/]"),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    )


# ── .po update results ───────────────────────────────────────────────


def show_po_update_results(stats: dict[str, int]):
    for lang_code, count in sorted(stats.items()):
        if count > 0:
            console.print(
                f"  [bold green]●[/] Updated: [bold]{lang_code}[/]  "
                f"→  [cyan]{count}[/] entries"
            )
        else:
            console.print(f"  [dim]  ○ {lang_code}: no changes[/]")


# ── Dry-run message list ──────────────────────────────────────────────


def show_dry_run_messages(messages: list[str], lang_count: int):
    console.print(
        Panel(
            "[bold yellow]Messages that would be translated[/]",
            border_style="yellow",
            box=box.ROUNDED,
        )
    )
    for msg in messages[:50]:
        console.print(f"    [dim cyan]→[/] {msg}")
    if len(messages) > 50:
        console.print(f"    [dim]... and {len(messages) - 50} more[/]")
    console.print()
    console.print(
        f"  [bold yellow]▲[/] Would add/update entries in "
        f"[bold]{lang_count}[/] language files."
    )


# ── Final summary report ─────────────────────────────────────────────


def show_final_report(
    files_scanned: int,
    total_messages: int,
    new_messages: int,
    translated: int,
    skipped: int,
    languages: int,
    elapsed: float,
    provider: str,
    success: bool,
    project_path: str = "",
):
    console.print()
    console.rule("[bold bright_green] TRANSLATION REPORT [/]", style="green")
    console.print()

    table = Table(
        show_header=False,
        box=box.SIMPLE_HEAVY,
        padding=(0, 3),
        show_edge=False,
        border_style="dim green",
    )
    table.add_column("Metric", style="bold white", min_width=32)
    table.add_column("Value", style="bold bright_cyan", justify="right", min_width=20)

    table.add_row("  Files scanned", str(files_scanned))
    table.add_row("  Messages found", str(total_messages))
    table.add_row("  New messages added", str(new_messages))
    table.add_row("  Successfully translated", str(translated))
    table.add_row("  Skipped (dynamic/logs)", str(skipped))
    table.add_row("  Languages processed", str(languages))
    table.add_row("  Translation engine", provider)
    table.add_row("  Execution time", f"{elapsed:.1f}s")

    console.print(table)
    console.print()

    if success and translated > 0:
        total_entries = translated * languages
        console.print(
            Panel(
                f"[bold bright_green]✅  MISSION COMPLETE[/]\n\n"
                f"[green]  Your app now speaks [bold]{languages}[/green][green] languages.[/]\n"
                f"[green]  [bold]{total_entries:,}[/bold] translation entries generated & deployed.[/]\n"
                f"[green]  All .po files updated → .mo compiled → Ready to serve.[/]",
                border_style="bright_green",
                box=box.DOUBLE_EDGE,
                padding=(1, 3),
            )
        )
    elif success:
        console.print(
            Panel(
                "[bold bright_green]✅  SUCCESS[/]\n\n"
                "[green]  All message IDs registered in .po files.[/]\n"
                "[dim]  Run again with a translation provider to fill msgstr values.[/]",
                border_style="green",
                box=box.DOUBLE_EDGE,
                padding=(1, 3),
            )
        )
    else:
        console.print(
            Panel(
                "[bold yellow]▲  COMPLETED WITH WARNINGS[/]\n\n"
                "[yellow]  Some translations may have failed. Check logs above.[/]\n"
                "[dim]  💡 Try reducing --batch-size or switching provider.[/]",
                border_style="yellow",
                box=box.DOUBLE_EDGE,
                padding=(1, 3),
            )
        )

    # ── Credits & Thank You ───────────────────────────────────────────
    _show_credits()


def _show_credits():
    """Show author credits and thank you message."""
    console.print()
    console.print(
        Panel(
            f"[bold bright_cyan]{LOGO_AUTHOR}[/]\n"
            f"[bold white]  Thank you for using django-ai-translator![/]\n\n"
            f"[dim]  Built with ❤ by [bold bright_cyan]{AUTHOR}[/bold bright_cyan][/dim]\n"
            f"[dim]  {GITHUB}[/]\n\n"
            f"[dim]  If this tool saved you time, consider giving it a ⭐ on GitHub.[/]\n"
            f"[dim]  No strings left behind. Zero manual effort. Pure automation.[/]",
            border_style="dim cyan",
            box=box.ROUNDED,
            padding=(0, 2),
        )
    )
    console.print()


# ── Project auto-detection ────────────────────────────────────────────


def show_project_detected(project_path: str, locale_path: str, lang_count: int):
    console.print(
        Panel(
            f"[bold cyan]  ◆ Project Auto-Detected[/]\n\n"
            f"  [white]Project:[/]    [bold]{project_path}[/]\n"
            f"  [white]Locale:[/]     [bold]{locale_path}[/]\n"
            f"  [white]Languages:[/]  [bold]{lang_count}[/] configured",
            border_style="cyan",
            box=box.ROUNDED,
            padding=(0, 2),
        )
    )
    console.print()
