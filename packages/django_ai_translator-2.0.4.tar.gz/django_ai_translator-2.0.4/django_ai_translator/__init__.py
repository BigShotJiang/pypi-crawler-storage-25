"""
django-ai-translator — AI-powered translation for Django .po files.

Setup:
    1. pip install django-ai-translator
    2. Add 'django_ai_translator' to INSTALLED_APPS
    3. Run: python manage.py auto_translate
"""

__version__ = "2.0.4"
__author__ = "Happy Cyber"
__license__ = "MIT"

default_app_config = "django_ai_translator.apps.DjangoAiTranslatorConfig"
