<p align="center">
  <h1 align="center">django-ai-translator</h1>
  <p align="center">
    <strong>AI-powered automatic translation for Django <code>.po</code> files.</strong><br>
    One command. Zero manual effort. Production-grade.
  </p>
  <p align="center">
    <a href="https://pypi.org/project/django-ai-translator/"><img src="https://img.shields.io/pypi/v/django-ai-translator.svg?style=flat-square&color=blue" alt="PyPI"></a>
    <a href="https://pypi.org/project/django-ai-translator/"><img src="https://img.shields.io/pypi/pyversions/django-ai-translator.svg?style=flat-square" alt="Python"></a>
    <a href="https://pypi.org/project/django-ai-translator/"><img src="https://img.shields.io/pypi/djversions/django-ai-translator.svg?style=flat-square&color=0C4B33&label=django" alt="Django"></a>
    <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-yellow.svg?style=flat-square" alt="License"></a>
    <a href="#testing"><img src="https://img.shields.io/badge/tests-236%20passed-brightgreen.svg?style=flat-square" alt="Tests"></a>
    <a href="#testing"><img src="https://img.shields.io/badge/coverage-94%25-brightgreen.svg?style=flat-square" alt="Coverage"></a>
  </p>
</p>

---

## Why django-ai-translator?

Translating Django apps is tedious. You extract strings, create `.po` files, then manually translate hundreds of messages across multiple languages. **django-ai-translator eliminates all of that.**

```bash
python manage.py auto_translate
```

It scans your codebase, finds every translatable string, detects what's missing per language, translates via AI, writes `.po` files, and compiles `.mo` — all in one command.

---

## Key Features

| Feature | Description |
|---|---|
| **5 AI Providers** | Claude, OpenAI, OpenRouter (100+ models), Gemini, Mistral |
| **AST-based Extraction** | Finds `_()`, `gettext_lazy()`, `ValidationError()`, f-strings |
| **Smart Diffing** | Only translates what's actually missing per language |
| **Never Overwrites** | Existing translations are always preserved |
| **Atomic Writes** | `.po` files can't be corrupted mid-write |
| **Auto-detection** | Finds `BASE_DIR`, `LANGUAGES`, `LOCALE_PATHS`, `.env` automatically |
| **Batch + Retry** | Configurable batch size with exponential backoff |
| **Rich Terminal UI** | Interactive menus, progress bars, ASCII art, summary reports |
| **CI/CD Ready** | `--no-input` and `--provider skip` for pipelines |
| **Battle-tested** | 236 tests, 94% coverage, zero-panic error handling |

---

## Installation

```bash
pip install django-ai-translator
```

With a specific AI provider:

```bash
pip install django-ai-translator[claude]      # Anthropic Claude
pip install django-ai-translator[openai]      # OpenAI GPT
pip install django-ai-translator[gemini]      # Google Gemini
pip install django-ai-translator[mistral]     # Mistral AI
pip install django-ai-translator[all]         # All providers
```

For development:

```bash
pip install django-ai-translator[dev]         # pytest + ruff
```

---

## Quick Start

### Step 1 — Add to your Django project

```python
# settings.py

INSTALLED_APPS = [
    ...
    'django_ai_translator',
]

LANGUAGES = [
    ('en', 'English'),
    ('es', 'Spanish'),
    ('fr', 'French'),
    ('de', 'German'),
    ('ja', 'Japanese'),
]
```

### Step 2 — Verify setup

```bash
python manage.py check_translate_setup
```

### Step 3 — Translate

```bash
python manage.py auto_translate
```

That's it. The package auto-detects your project structure, locale paths, and `.env` location.

---

## Usage

```bash
# Interactive mode — shows provider selection menu
python manage.py auto_translate

# Direct provider
python manage.py auto_translate --provider claude
python manage.py auto_translate --provider openai
python manage.py auto_translate --provider mistral
python manage.py auto_translate --provider gemini

# OpenRouter — access 100+ models
python manage.py auto_translate --provider openrouter
python manage.py auto_translate --provider openrouter --model deepseek/deepseek-chat-v3-0324

# Preview changes without writing files
python manage.py auto_translate --dry-run

# Add msgid entries only — no API calls
python manage.py auto_translate --provider skip

# CI/CD — non-interactive, no prompts
python manage.py auto_translate --no-input --provider mistral

# Custom batch size
python manage.py auto_translate --batch-size 10

# Debug logging
python manage.py auto_translate --debug
```

---

## Supported AI Providers

| Provider | Env Variable | Install Extra | Best For |
|---|---|---|---|
| **Claude** (Anthropic) | `ANTHROPIC_API_KEY` | `[claude]` | Highest quality |
| **OpenAI** GPT | `OPENAI_API_KEY` | `[openai]` | General purpose |
| **OpenRouter** (100+ models) | `OPENROUTER_API_KEY` | `[openrouter]` | Model variety |
| **Google Gemini** | `GOOGLE_GEMINI_KEY` | `[gemini]` | Speed |
| **Mistral AI** | `MISTRAL_API_KEY` | `[mistral]` | European languages |

API keys are stored in your `.env` file — never in code. If a key is missing, the CLI prompts you and saves it automatically.

---

## How It Works

```
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│  Source   │────▶│   AST    │────▶│   .po    │────▶│    AI    │────▶│   .po    │
│  Code    │     │ Scanner  │     │  Differ  │     │Translator│     │  Writer  │
└──────────┘     └──────────┘     └──────────┘     └──────────┘     └──────────┘
                                                                          │
                                                                          ▼
                                                                    ┌──────────┐
                                                                    │   .mo    │
                                                                    │ Compiler │
                                                                    └──────────┘
```

1. **Scan** — AST-parses every `.py` file for `_("...")`, `gettext_lazy("...")`, `ValidationError("...")`, etc.
2. **Diff** — Compares extracted messages against existing `.po` files per language
3. **Translate** — Sends only missing messages to your chosen AI provider (batched, with retry)
4. **Write** — Appends new entries to `.po` files via atomic writes (never overwrites existing translations)
5. **Compile** — Runs `compilemessages` to generate production-ready `.mo` files

---

## Example Output

```
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   ╔╦╗ ╦╔═╗ ╔╗╔ ╔═╗ ╔═╗        ╔═╗ ╦                          ║
║    ║║ ║╠═╣ ║║║ ║ ╦ ║ ║  ──────  ╠═╣ ║                         ║
║   ═╩╝╚╝╩ ╩ ╝╚╝ ╚═╝ ╚═╝        ╩ ╩ ╩                          ║
║   ╔╦╗ ╦═╗ ╔═╗ ╔╗╔ ╔═╗ ╦  ╔═╗ ╔╦╗ ╔═╗ ╦═╗                    ║
║    ║  ╠╦╝ ╠═╣ ║║║ ╚═╗ ║  ╠═╣  ║  ║ ║ ╠╦╝                    ║
║    ╩  ╩╚═ ╩ ╩ ╝╚╝ ╚═╝ ╩═╝╩ ╩  ╩  ╚═╝ ╩╚═                    ║
║                                                               ║
║   AI-Powered Translation Engine                               ║
║   v2.0.4 — by Happy-Cyber                                     ║
╚═══════════════════════════════════════════════════════════════╝

[ SYS.INIT ] Booting translation core...
[ SYS.LOAD ] Loading AI translation backends...

  ● Files scanned      288
  ● Messages found     954
  ● New messages       420

Translating…  ━━━━━━━━━━━━━━━━━━━━━━━━━  100%  • 0:00:42

  ● Updated: es  →  420 entries
  ● Updated: fr  →  420 entries
  ● Updated: de  →  420 entries
  ● Updated: ja  →  420 entries

═══════════════════  TRANSLATION REPORT  ═════════════════════════

  Files scanned                                         288
  Messages found                                        954
  New messages added                                    420
  Successfully translated                               420
  Languages processed                                     4
  Translation engine                      Claude (Anthropic)
  Execution time                                      42.1s

╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   MISSION COMPLETE                                            ║
║                                                               ║
║   Your app now speaks 4 languages.                            ║
║   1,680 translation entries generated & deployed.             ║
║   All .po files updated → .mo compiled → Ready to serve.     ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝

╭───────────────────────────────────────────────────────────────╮
│                                                               │
│   ╦ ╦ ╔═╗ ╔═╗ ╔═╗ ╦ ╦         ╔═╗ ╦ ╦ ╔╗  ╔═╗ ╦═╗          │
│   ╠═╣ ╠═╣ ╠═╝ ╠═╝ ╚╦╝  ─────  ║   ╚╦╝ ╠╩╗ ║╣  ╠╦╝          │
│   ╩ ╩ ╩ ╩ ╩   ╩    ╩          ╚═╝  ╩  ╚═╝ ╚═╝ ╩╚═          │
│                                                               │
│   Thank you for using django-ai-translator!                  │
│   Built with love by Happy-Cyber                              │
│                                                               │
│   If this tool saved you time, consider giving it a star      │
│   No strings left behind. Zero manual effort.                 │
╰───────────────────────────────────────────────────────────────╯
```

---

## Safety & Resilience

| Guarantee | Description |
|---|---|
| **Never overwrites** | Existing non-empty `msgstr` values are never touched |
| **Atomic writes** | Uses temp file + rename — `.po` files can't be corrupted |
| **No duplicates** | Safe to run multiple times — no duplicate `msgid` entries |
| **Orphans preserved** | Strings removed from source code stay in `.po` files |
| **Keys in `.env` only** | API keys are never hardcoded — auto-scaffolded if missing |
| **Dry-run mode** | Preview everything with `--dry-run` before making changes |
| **Retry with backoff** | Failed API calls retry automatically (3 attempts) |
| **Ctrl+C safe** | Graceful shutdown — saves partial translations before exit |
| **Concurrent-run lock** | Lock file prevents two processes from corrupting files |
| **Auto-repair corrupt .po** | Backs up corrupt file, salvages entries, rebuilds clean |
| **Encoding resilience** | Auto-fixes non-UTF-8 `.po` files (Latin-1, CP1252, etc.) |
| **Disk full protection** | Catches ENOSPC, shows friendly message, no partial writes |
| **Permission handling** | Catches PermissionError with `chown` fix suggestion |

---

## Edge Case Handling

Every error shows a **friendly message with a fix** — users never see raw tracebacks.

| Scenario | What Happens |
|---|---|
| `locale/` folder missing | Auto-created |
| `.po` files don't exist | Auto-created with proper metadata |
| `.env` file missing | Auto-created with all API key placeholders |
| `LOCALE_PATHS` not in settings | Falls back to `BASE_DIR/locale` |
| `LANGUAGES` not in settings | Falls back to English only |
| API key missing (interactive) | Prompts user, saves to `.env` |
| API key missing (`--no-input`) | Clear error with fix instructions |
| API key invalid | Auth failure message, clean exit |
| Provider SDK not installed | Shows exact `pip install` command |
| Empty project (no strings) | Shows code example for `_()` usage |
| gettext/msgfmt not installed | Shows OS-specific install command |
| Corrupt `.po` file | Auto-backup + salvage + rebuild |
| Non-UTF-8 `.po` file | Auto-detects encoding, converts to UTF-8 |
| Ctrl+C during translation | Saves completed batches, writes partial results |
| Two terminals running at once | Lock file prevents collision |
| Disk full | Friendly error, no corrupted files |
| Permission denied | Shows `chown` fix command |
| Syntax error in `.py` file | Silently skips, continues scanning |
| All messages already translated | "Nothing to do" — clean exit |
| API returns bad JSON | Retries, continues with empty result |

---

## Architecture

```
django_ai_translator/
├── pyproject.toml                      # Package config (single source of truth)
├── LICENSE                             # MIT
├── README.md
├── django_ai_translator/              # Package source
│   ├── __init__.py                     # v2.0.4
│   ├── apps.py                         # Django app config
│   ├── conf.py                         # Central settings gateway
│   ├── cli/
│   │   └── ui.py                       # Rich terminal UI
│   ├── services/
│   │   ├── extractor.py                # AST-based string scanner
│   │   ├── po_manager.py               # .po file reader/writer (atomic)
│   │   ├── env_manager.py              # .env auto-detect & key management
│   │   └── translators/
│   │       ├── __init__.py             # Provider registry & factory
│   │       ├── base.py                 # ABC, prompt builder, retry logic
│   │       ├── claude.py               # Anthropic Claude
│   │       ├── openai.py               # OpenAI GPT
│   │       ├── openrouter.py           # OpenRouter (100+ models)
│   │       ├── gemini.py               # Google Gemini
│   │       └── mistral.py              # Mistral AI
│   └── management/commands/
│       ├── auto_translate.py           # Main orchestrator command
│       └── check_translate_setup.py    # Setup validation command
├── tests/                              # 236 tests, 94% coverage
│   ├── unit/                           # Core module tests
│   ├── integration/                    # Full pipeline + management commands
│   ├── cli/                            # UI function tests
│   ├── performance/                    # Large project stress tests
│   └── regression/                     # Safety invariant + concurrency tests
└── docs/                               # Full documentation
```

---

## Testing

```bash
# Install test dependencies
pip install django-ai-translator[dev]

# Run full test suite
pytest tests/ -v --cov=django_ai_translator --cov-fail-under=90
```

### Test Coverage Breakdown

| Category | Tests | What It Covers |
|---|---:|---|
| **Unit** | 120 | Extractor, translators, PO manager, conf, env manager |
| **Integration** | 23 | Full pipeline, management commands, all edge cases |
| **CLI** | 33 | UI rendering, model selection, API key prompts |
| **Performance** | 4 | 1000+ messages, 100 files, large strings |
| **Regression** | 8 | Never-overwrite guarantee, orphan preservation |
| **Concurrency** | 6 | Parallel writes, no duplicates, file integrity |
| **Edge Cases** | 42 | Corrupt files, encoding, permissions, Ctrl+C, lock |
| **Total** | **236** | **94% code coverage** |

All tests are deterministic — no external API calls, no flaky tests, fully mocked.

---

## Documentation

Full documentation available in the `docs/` folder:

| Document | Description |
|---|---|
| [INSTALLATION.md](docs/INSTALLATION.md) | Setup, dependencies, Django integration |
| [USAGE.md](docs/USAGE.md) | Step-by-step flow, first run, subsequent runs |
| [CONFIGURATION.md](docs/CONFIGURATION.md) | .env setup, environment variables, defaults |
| [CLI_GUIDE.md](docs/CLI_GUIDE.md) | All flags, modes, combining options |
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | Code structure, data flow, module responsibilities |
| [ERROR_HANDLING.md](docs/ERROR_HANDLING.md) | Every error scenario, messages, auto-recovery |
| [TESTING.md](docs/TESTING.md) | Test suite, coverage, running tests |
| [DEPLOYMENT.md](docs/DEPLOYMENT.md) | Production deploy, CI/CD pipelines, Docker |
| [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) | Common issues and fix steps |

---

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Run tests (`pytest tests/ -v`)
4. Commit your changes
5. Push to the branch
6. Open a Pull Request

---

## Author

**Happy Cyber**

- GitHub: [github.com/Happy-cyber](https://github.com/Happy-cyber)
- Email: [dhamasaniyahappy3931@gmail.com](mailto:dhamasaniyahappy3931@gmail.com)

---

## License

MIT License - Copyright (c) 2026 Happy Cyber

See [LICENSE](LICENSE) for details.

---

<p align="center">
  <sub>Built with purpose. No strings left behind.</sub>
</p>
