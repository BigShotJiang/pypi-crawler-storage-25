from __future__ import annotations

from model_manager_tool.server import main


if __name__ == "__main__":
    main()
