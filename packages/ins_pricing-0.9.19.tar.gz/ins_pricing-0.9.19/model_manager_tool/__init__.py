"""Standalone model management tool for ins_pricing projects."""

from model_manager_tool.manager import ModelManagerService

__all__ = ["ModelManagerService"]

