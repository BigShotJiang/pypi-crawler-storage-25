__version__ = "0.10.6"
__version_tuple__ = (0, 10, 6)
