from setuptools import setup, find_packages

setup(
    name="phenotype-skills",
    version="0.1.0",
    author="Phenotype Team",
    author_email="team@phenotype.dev",
    description="Python bindings for the Phenotype Skills system",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/phenotype/skills",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.9",
    install_requires=[
        # No external dependencies for core functionality
    ],
    extras_require={
        "dev": ["pytest", "pytest-asyncio", "black", "mypy"],
    },
)