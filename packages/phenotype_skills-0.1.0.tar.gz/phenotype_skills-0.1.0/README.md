# phenotype-skills-python

> Python bindings for the phenotype-skills Rust library

## Installation

```bash
pip install phenotype-skills
```

## Usage

```python
from phenotype_skills import SkillRegistry, Skill, SkillManifest, Runtime

# Create a skill registry
registry = SkillRegistry()

# Register a skill
manifest = SkillManifest(
    name="my-skill",
    version="1.0.0",
    runtime=Runtime.WASM,
    entry_point="main.wasm"
)
skill = Skill.from_manifest(manifest)
registry.register(skill)

# Execute the skill
from phenotype_skills.runtime import SkillRuntime
runtime = SkillRuntime()
result = runtime.execute(skill, {"input": "data"})
```

## Building

Requires Rust toolchain and Python 3.9+.

```bash
cd bindings/python
pip install maturin
maturin develop
```
