"""
### Tribulnation Mercado
> An SDK to connect Mercado with the Tribulnation ecosystem.

- Details
"""