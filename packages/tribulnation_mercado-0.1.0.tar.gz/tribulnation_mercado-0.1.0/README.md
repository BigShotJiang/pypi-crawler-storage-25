# Tribulnation Mercado SDK

> An SDK to connect Mercado with the Tribulnation ecosystem.

🚧 Under construction.