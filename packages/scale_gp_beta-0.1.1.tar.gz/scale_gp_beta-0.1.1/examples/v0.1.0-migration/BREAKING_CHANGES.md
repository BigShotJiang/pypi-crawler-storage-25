# Breaking Changes: v0.1.0

**Date:** April 2026
**Package:** `scale-gp-beta`
**Previous versions:** v0.1.0-alpha.1 through v0.1.0-alpha.52

This document covers all breaking changes introduced in v0.1.0. If you are upgrading from any alpha version, review each section below.

---

## Quick Reference

| Category | Old (alpha) | New (v0.1.0) |
|----------|-------------|--------------|
| **Evaluations create** | `client.evaluations.create(name=..., data=..., ...)` | `client.evaluations.create(evaluation={...})` |
| **Evaluations update** | `client.evaluations.update(id, name=..., tags=...)` | `client.evaluations.update(id, evaluation={...})` |
| **Models create** | `client.models.create(name=..., vendor_configuration=...)` | `client.models.create(model={...})` |
| **Models update** | `client.models.update(id, model_metadata=...)` | `client.models.update(id, model={...})` |
| **Questions create** | `client.questions.create(name=..., prompt=..., configuration=...)` | `client.questions.create(question={...})` |
| **Rubrics update** | `client.rubrics.update(id, title=..., tags=...)` | `client.rubrics.update(id, rubric={...})` |
| **Datasets update** | `client.datasets.update(id, name=..., tags=...)` | `client.datasets.update(id, dataset={...})` |
| **Questions delete** | `client.questions.delete(id)` | `client.questions.archive(id)` |
| **Rubrics delete** | `client.rubrics.delete(id)` | `client.rubrics.archive(id)` |
| **Datasets delete** | `client.datasets.delete(id)` | `client.datasets.archive(id)` |
| **Dataset items delete** | `client.dataset_items.delete(id)` | `client.dataset_items.archive(id)` |
| **Evaluations delete** | `client.evaluations.delete(id)` | `client.evaluations.archive(id)` |
| **Eval groups delete** | `client.evaluation_groups.delete(id)` | `client.evaluation_groups.archive(id)` |
| **Eval dashboards delete** | `client.evaluation_dashboards.delete(id)` | `client.evaluation_dashboards.archive(id)` |
| **Dashboard widgets delete** | `client.evaluation_dashboards.widgets.delete(id, ...)` | `client.evaluation_dashboards.widgets.remove(id, ...)` |
| **Criteria add** | `client.rubrics.criteria.add(rubric_id, ...)` | `client.rubrics.criteria.create(rubric_id, ...)` |
| **Build types** | `BuildCreateResponse`, `BuildRetrieveResponse`, `BuildListResponse` | `AgentexCloudBuild` |
| **Deploy types** | `DeployCreateResponse`, `DeployRetrieveResponse`, `DeployListResponse` | `AgentexCloudDeploy` |
| **Rubric types** | `RubricCreateResponse`, `RubricRetrieveResponse`, etc. | `RubricResponse` |
| **Rubric delete type** | `RubricDeleteResponse` | `RubricArchiveResponse` |
| **Dataset delete type** | `DatasetDeleteResponse` | `DatasetArchiveResponse` |
| **Dataset item delete type** | `DatasetItemDeleteResponse` | `DatasetItemArchiveResponse` |
| **Span batch type** | `SpanBatchResponse` | `APIListSpan` |
| **Span upsert batch type** | `SpanUpsertBatchResponse` | `APIListSpan` |
| **Vector retrieve type** | `VectorRetrieveResponse` | `VectorDocument` |
| **Vector list type** | `VectorListResponse` | `SyncCursorPageVectors[VectorDocument]` |
| **Criteria types** | `CriterionCreateResponse`, `CriterionUpdateResponse` | `RubricCriteriaResponse` |
| **File type** | `File` | `SGPFile` |
| **Response type** | `Response` | Removed |
| **Sort order** | `Literal["asc", "desc"]` | `SortOrder` |
| **Evaluation views** | `List[Literal["tasks"]]` | `List[EvaluationViews]` |
| **Eval group views** | `List[Literal["members", "row_identifiers"]]` | `List[EvaluationGroupViews]` |
| **Widget type** | `Literal["bar", "histogram", ...]` | `EvaluationWidgetTypeEnum` |
| **Export format** | `Literal["json", "jsonl", "csv"]` | `ExportFormat` |
| **Export method** | `Literal["signed_url", "direct"]` | `ExportMethod` |
| **Span batch items** | `span_batch_params.Item` | `SpanCreateParam` |
| **Vector store list pagination** | `cursor=` | `starting_after=` (preferred; `cursor` deprecated) |

---

## 1. Method Signatures: Nested Object Parameters

The most significant change in v0.1.0. Methods that previously accepted flat keyword arguments with multiple `@overload` variants now take a single nested dictionary parameter. This applies to `create()` and `update()` methods across several resources.

### Evaluations

**`create()`** — The `evaluation` param replaces all flat kwargs. It accepts a Union of three request types depending on your use case.

```python
# BEFORE (alpha)
client.evaluations.create(
    name="my-eval",
    data=[{"input": "hello", "expected": "world"}],
    tags=["v1"],
    tasks=[{"type": "human", "name": "review"}],
)

# AFTER (v0.1.0)
client.evaluations.create(
    evaluation={
        "name": "my-eval",
        "data": [{"input": "hello", "expected": "world"}],
        "tags": ["v1"],
        "tasks": [{"type": "human", "name": "review"}],
    }
)
```

Creating from an existing dataset:

```python
# BEFORE (alpha)
client.evaluations.create(
    name="my-eval",
    dataset_id="ds_123",
)

# AFTER (v0.1.0)
client.evaluations.create(
    evaluation={
        "name": "my-eval",
        "dataset_id": "ds_123",
    }
)
```

**`update()`** — Same pattern. Restore is now part of the union type.

```python
# BEFORE (alpha)
client.evaluations.update("eval_123", name="new-name", tags=["v2"])
client.evaluations.update("eval_123", restore=True)

# AFTER (v0.1.0)
client.evaluations.update("eval_123", evaluation={"name": "new-name", "tags": ["v2"]})
client.evaluations.update("eval_123", evaluation={"restore": True})
```

### Models

**`create()`** — The `model` param replaces flat kwargs including `name`, `vendor_configuration`, `model_type`, `model_vendor`, and `on_conflict`.

```python
# BEFORE (alpha)
client.models.create(
    name="my-model",
    vendor_configuration={"model_image": {...}, "model_infra": {...}},
    model_vendor="launch",
)

# AFTER (v0.1.0)
client.models.create(
    model={
        "name": "my-model",
        "vendor_configuration": {"model_image": {...}, "model_infra": {...}},
        "model_vendor": "launch",
    }
)
```

**`update()`** — The `model` param replaces the three overload variants (metadata update, vendor config update, name swap).

```python
# BEFORE (alpha)
client.models.update("model_123", model_metadata={"key": "value"})
client.models.update("model_123", vendor_configuration={...})
client.models.update("model_123", name="new-name", on_conflict="swap")

# AFTER (v0.1.0)
client.models.update("model_123", model={"model_metadata": {"key": "value"}})
client.models.update("model_123", model={"vendor_configuration": {...}})
client.models.update("model_123", model={"name": "new-name", "on_conflict": "swap"})
```

### Questions

**`create()`** — The `question` param replaces per-question-type overloads. The dict shape matches the question type you're creating.

```python
# BEFORE (alpha)
client.questions.create(
    name="quality",
    prompt="Rate the quality",
    question_type="categorical",
    configuration={"choices": ["good", "bad"], "multi": False},
)

# AFTER (v0.1.0)
client.questions.create(
    question={
        "name": "quality",
        "prompt": "Rate the quality",
        "question_type": "categorical",
        "configuration": {"choices": ["good", "bad"], "multi": False},
    }
)
```

> **Note:** `questions.update()` is unchanged — it still takes flat `name: str` as a keyword argument.

### Rubrics

**`update()`** — The `rubric` param replaces flat kwargs. Restore is part of the union type.

```python
# BEFORE (alpha)
client.rubrics.update("r_123", title="Updated Title", tags=["new-tag"])
client.rubrics.update("r_123", restore=True)

# AFTER (v0.1.0)
client.rubrics.update("r_123", rubric={"title": "Updated Title", "tags": ["new-tag"]})
client.rubrics.update("r_123", rubric={"restore": True})
```

Additionally, the `criteria` parameter type on `rubrics.create()` changed:

```python
# BEFORE (alpha)
from scale_gp_beta.types import rubric_create_params
criteria: list[rubric_create_params.Criterion] = [{"title": "Accuracy", "weight": 1.0}]

# AFTER (v0.1.0)
from scale_gp_beta.types.rubrics import RubricCriteriaInputParam
criteria: list[RubricCriteriaInputParam] = [{"title": "Accuracy", "weight": 1.0}]
```

### Datasets

**`update()`** — Same nested pattern.

```python
# BEFORE (alpha)
client.datasets.update("ds_123", name="new-name", tags=["v2"])
client.datasets.update("ds_123", restore=True)

# AFTER (v0.1.0)
client.datasets.update("ds_123", dataset={"name": "new-name", "tags": ["v2"]})
client.datasets.update("ds_123", dataset={"restore": True})
```

---

## 2. Method Renames

### `questions.delete()` -> `questions.archive()`

```python
# BEFORE (alpha)
client.questions.delete("q_123")

# AFTER (v0.1.0)
client.questions.archive("q_123")
```

### `rubrics.delete()` -> `rubrics.archive()`

Return type also changed from `RubricDeleteResponse` to `RubricArchiveResponse`.

```python
# BEFORE (alpha)
result = client.rubrics.delete("r_123")  # -> RubricDeleteResponse

# AFTER (v0.1.0)
result = client.rubrics.archive("r_123")  # -> RubricArchiveResponse
```

### `datasets.delete()` -> `datasets.archive()`

Return type changed from `DatasetDeleteResponse` to `DatasetArchiveResponse`.

```python
# BEFORE (alpha)
result = client.datasets.delete("ds_123")  # -> DatasetDeleteResponse

# AFTER (v0.1.0)
result = client.datasets.archive("ds_123")  # -> DatasetArchiveResponse
```

### `dataset_items.delete()` -> `dataset_items.archive()`

Return type changed from `DatasetItemDeleteResponse` to `DatasetItemArchiveResponse`.

```python
# BEFORE (alpha)
result = client.dataset_items.delete("di_123")  # -> DatasetItemDeleteResponse

# AFTER (v0.1.0)
result = client.dataset_items.archive("di_123")  # -> DatasetItemArchiveResponse
```

### `evaluations.delete()` -> `evaluations.archive()`

```python
# BEFORE (alpha)
client.evaluations.delete("eval_123")

# AFTER (v0.1.0)
client.evaluations.archive("eval_123")
```

### `evaluation_groups.delete()` -> `evaluation_groups.archive()`

```python
# BEFORE (alpha)
client.evaluation_groups.delete("grp_123")

# AFTER (v0.1.0)
client.evaluation_groups.archive("grp_123")
```

### `evaluation_dashboards.delete()` -> `evaluation_dashboards.archive()`

```python
# BEFORE (alpha)
client.evaluation_dashboards.delete("dash_123")

# AFTER (v0.1.0)
client.evaluation_dashboards.archive("dash_123")
```

### `evaluation_dashboards.widgets.delete()` -> `evaluation_dashboards.widgets.remove()`

Note: widgets use `remove()` instead of `archive()`.

```python
# BEFORE (alpha)
client.evaluation_dashboards.widgets.delete("w_123", dashboard_id="dash_123")

# AFTER (v0.1.0)
client.evaluation_dashboards.widgets.remove("w_123", dashboard_id="dash_123")
```

### `rubrics.criteria.add()` -> `rubrics.criteria.create()`

```python
# BEFORE (alpha)
client.rubrics.criteria.add("r_123", title="Criterion A", weight=1.0)

# AFTER (v0.1.0)
client.rubrics.criteria.create("r_123", title="Criterion A", weight=1.0)
```

---

## 3. Response Type Consolidation

Per-method response types have been consolidated into single resource types. If your code imports or type-annotates with any of the old types, update the imports.

### Build

| Old Type | New Type |
|----------|----------|
| `BuildCreateResponse` | `AgentexCloudBuild` |
| `BuildRetrieveResponse` | `AgentexCloudBuild` |
| `BuildListResponse` | `AgentexCloudBuild` |
| `build.cancel()` return (`object`) | `AgentexCloudBuild` |

```python
# BEFORE (alpha)
from scale_gp_beta.types import BuildCreateResponse, BuildRetrieveResponse, BuildListResponse

# AFTER (v0.1.0)
from scale_gp_beta.types import AgentexCloudBuild
```

### Deploy

| Old Type | New Type |
|----------|----------|
| `DeployCreateResponse` | `AgentexCloudDeploy` |
| `DeployRetrieveResponse` | `AgentexCloudDeploy` |
| `DeployListResponse` | `AgentexCloudDeploy` |

```python
# BEFORE (alpha)
from scale_gp_beta.types import DeployCreateResponse, DeployRetrieveResponse, DeployListResponse

# AFTER (v0.1.0)
from scale_gp_beta.types import AgentexCloudDeploy
```

### Rubrics

| Old Type | New Type |
|----------|----------|
| `RubricCreateResponse` | `RubricResponse` |
| `RubricRetrieveResponse` | `RubricResponse` |
| `RubricUpdateResponse` | `RubricResponse` |
| `RubricListResponse` | `RubricResponse` |
| `RubricDeleteResponse` | `RubricArchiveResponse` |

```python
# BEFORE (alpha)
from scale_gp_beta.types import (
    RubricCreateResponse, RubricRetrieveResponse,
    RubricUpdateResponse, RubricListResponse, RubricDeleteResponse,
)

# AFTER (v0.1.0)
from scale_gp_beta.types import RubricResponse, RubricArchiveResponse
```

### Rubric Criteria

| Old Type | New Type |
|----------|----------|
| `CriterionCreateResponse` | `RubricCriteriaResponse` |
| `CriterionUpdateResponse` | `RubricCriteriaResponse` |

```python
# BEFORE (alpha)
from scale_gp_beta.types.rubrics import CriterionCreateResponse, CriterionUpdateResponse

# AFTER (v0.1.0)
from scale_gp_beta.types.rubrics import RubricCriteriaResponse
```

### Datasets

| Old Type | New Type |
|----------|----------|
| `DatasetDeleteResponse` | `DatasetArchiveResponse` |
| `DatasetItemDeleteResponse` | `DatasetItemArchiveResponse` |

```python
# BEFORE (alpha)
from scale_gp_beta.types import DatasetDeleteResponse, DatasetItemDeleteResponse

# AFTER (v0.1.0)
from scale_gp_beta.types import DatasetArchiveResponse, DatasetItemArchiveResponse
```

### Spans

| Old Type | New Type |
|----------|----------|
| `SpanBatchResponse` | `APIListSpan` |
| `SpanUpsertBatchResponse` | `APIListSpan` |

Both `spans.batch()` and `spans.upsert_batch()` now return `APIListSpan`. The `items` parameter type for both methods also changed from `span_batch_params.Item` / `span_upsert_batch_params.Item` to `SpanCreateParam`.

```python
# BEFORE (alpha)
from scale_gp_beta.types import SpanBatchResponse, SpanUpsertBatchResponse

# AFTER (v0.1.0)
from scale_gp_beta.types import APIListSpan
from scale_gp_beta.types import SpanCreateParam  # for items parameter type
```

### Vector Stores

| Old Type | New Type |
|----------|----------|
| `VectorRetrieveResponse` | `VectorDocument` |
| `VectorListResponse` | `SyncCursorPageVectors[VectorDocument]` |

`vectors.retrieve()` now returns `VectorDocument` instead of `VectorRetrieveResponse`. `vectors.list()` changed from returning a flat `VectorListResponse` to a paginated `SyncCursorPageVectors[VectorDocument]` — this changes how you iterate results (see Section 6).

```python
# BEFORE (alpha)
from scale_gp_beta.types.vector_stores import VectorRetrieveResponse, VectorListResponse

# AFTER (v0.1.0)
from scale_gp_beta.types.vector_stores import VectorDocument
from scale_gp_beta.pagination import SyncCursorPageVectors  # for type annotations
```

---

## 4. Type Renames

### `File` -> `SGPFile`

The `File` type has been renamed to `SGPFile` to avoid conflicts with Python's built-in `file`.

```python
# BEFORE (alpha)
from scale_gp_beta.types import File

# AFTER (v0.1.0)
from scale_gp_beta.types import SGPFile
```

All file resource methods (`files.create()`, `files.retrieve()`, `files.update()`, `files.list()`) now return `SGPFile` instead of `File`.

### `Response` type removed

The `Response` type is no longer exported from `scale_gp_beta.types`. If you were using it for type annotations, use `ResponseCreateResponse` for the return type of `client.responses.create()`.

```python
# BEFORE (alpha)
from scale_gp_beta.types import Response

# AFTER (v0.1.0)
from scale_gp_beta.types import ResponseCreateResponse  # for responses.create() return type
```

---

## 5. Literal → Enum Type Changes

Several parameters that previously used `Literal[...]` type annotations now use dedicated enum types. The runtime string values are the same in all cases — these only affect type annotations in your code.

### Sort Order

All `.list()` methods now use `SortOrder` instead of `Literal["asc", "desc"]`.

**Affected methods:** `evaluations.list()`, `models.list()`, `questions.list()`, `rubrics.list()`, `datasets.list()`, `files.list()`, `builds.list()`, `deploys.list()`, `credentials.list()`, `dataset_items.list()`, `evaluation_groups.list()`, `spans.list()`, `evaluation_dashboards.list()`, `evaluation_items.list()`

```python
# BEFORE (alpha)
from typing import Literal
sort_order: Literal["asc", "desc"] = "asc"

# AFTER (v0.1.0)
from scale_gp_beta.types.chat import SortOrder
sort_order: SortOrder = "asc"
```

### Evaluation Views

```python
# BEFORE (alpha)
from typing import List, Literal
views: List[Literal["tasks"]] = ["tasks"]

# AFTER (v0.1.0)
from scale_gp_beta.types import EvaluationViews
views: list[EvaluationViews] = ["tasks"]
```

### Evaluation Group Views

```python
# BEFORE (alpha)
from typing import List, Literal
views: List[Literal["members", "row_identifiers"]] = ["members"]

# AFTER (v0.1.0)
from scale_gp_beta.types import EvaluationGroupViews
views: list[EvaluationGroupViews] = ["members"]
```

### Widget Type

```python
# BEFORE (alpha)
from typing import Literal
widget_type: Literal["bar", "histogram", "donut", "scatter", "metric", "table", "markdown", "heading", "timeseries"]

# AFTER (v0.1.0)
from scale_gp_beta.types.evaluation_dashboards import EvaluationWidgetTypeEnum
widget_type: EvaluationWidgetTypeEnum
```

### Export Format and Export Method

```python
# BEFORE (alpha)
from typing import Literal
export_format: Literal["json", "jsonl", "csv"] = "json"
export_method: Literal["signed_url", "direct"] = "signed_url"

# AFTER (v0.1.0)
from scale_gp_beta.types import ExportFormat, ExportMethod
export_format: ExportFormat = "json"
export_method: ExportMethod = "signed_url"
```

> **Note:** Passing string values (e.g. `"asc"`, `"tasks"`, `"json"`) still works at runtime for all of the above.

---

## 6. Vector Store Pagination

The vector store list endpoint has been standardized to match all other V5 paginated endpoints. This is a significant change — `vectors.list()` now returns a paginated cursor page instead of a flat response object.

### Return type change

`vectors.list()` previously returned a `VectorListResponse` (a flat model with a `vectors` list and `next_cursor` string). It now returns `SyncCursorPageVectors[VectorDocument]` / `AsyncCursorPageVectors[VectorDocument]` — a paginated cursor page that supports automatic iteration.

```python
# BEFORE (alpha)
response = client.vector_stores.vectors.list("my-store")
for doc in response.vectors:
    print(doc.id)
# Manual pagination with response.next_cursor

# AFTER (v0.1.0) — automatic pagination
page = client.vector_stores.vectors.list("my-store")
for doc in page.items:
    print(doc.id)
```

### Response field: `items` (preferred) vs `vectors` (deprecated)

The list response now supports **`items`** (the standard field used by every other paginated endpoint). The old `vectors` field is still present as a backward-compatible alias but **will be removed in a future release**.

```python
# PREFERRED — use `items`
page = client.vector_stores.vectors.list("my-store")
for doc in page.items:
    print(doc.id)

# DEPRECATED — `vectors` still works but will be removed
# for doc in page.vectors:
#     print(doc.id)
```

### Pagination parameter: `starting_after` (preferred) vs `cursor` (deprecated)

Use **`starting_after`** for cursor-based pagination. The `cursor` parameter is accepted as a backward-compatible alias on the vector store list endpoint only, but **will be removed in a future release**.

```python
# PREFERRED — use `starting_after`
page = client.vector_stores.vectors.list("my-store", starting_after="doc_abc", limit=100)

# DEPRECATED — `cursor` still works but will be removed
# page = client.vector_stores.vectors.list("my-store", cursor="doc_abc", limit=100)
```

> **Note:** Passing both `cursor` and `starting_after` in the same request raises a `400 InvalidRequestParameters` error.

### Pagination classes

- `SyncCursorPageVectors` / `AsyncCursorPageVectors` — for vector store results
- `SyncCursorPageByName` / `AsyncCursorPageByName` — for name-based cursor pagination

Import from `scale_gp_beta.pagination`.
