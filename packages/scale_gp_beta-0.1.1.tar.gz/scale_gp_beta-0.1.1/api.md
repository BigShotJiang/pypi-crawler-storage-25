# Shared Types

```python
from scale_gp_beta.types import Identity
```

# Responses

Types:

```python
from scale_gp_beta.types import (
    CodeInterpreter,
    ComparisonFilter,
    ComputerTool,
    CustomTool,
    EasyInputMessage,
    FileSearchTool,
    FunctionTool,
    ImageGeneration,
    IncompleteDetails,
    LocalShell,
    Mcp,
    OpenAIResponse,
    OpenAIResponseCodeInterpreterToolCall,
    OpenAIResponseComputerToolCall,
    OpenAIResponseCustomToolCall,
    OpenAIResponseCustomToolCallOutput,
    OpenAIResponseError,
    OpenAIResponseFileSearchToolCall,
    OpenAIResponseFunctionToolCall,
    OpenAIResponseFunctionWebSearch,
    OpenAIResponseInputFile,
    OpenAIResponseInputFileParam,
    OpenAIResponseInputImage,
    OpenAIResponseInputImageParam,
    OpenAIResponseInputText,
    OpenAIResponseInputTextParam,
    OpenAIResponseOutputMessage,
    OpenAIResponseOutputRefusal,
    OpenAIResponseOutputText,
    OpenAIResponsePrompt,
    OpenAIResponseReasoningItem,
    OpenAIResponseTextConfig,
    OpenAIResponseUsage,
    OpenAITypesResponsesResponseInputItemComputerCallOutput,
    OpenAITypesResponsesResponseInputItemFunctionCallOutput,
    OpenAITypesResponsesResponseInputItemImageGenerationCall,
    OpenAITypesResponsesResponseInputItemItemReference,
    OpenAITypesResponsesResponseInputItemLocalShellCall,
    OpenAITypesResponsesResponseInputItemLocalShellCallOutput,
    OpenAITypesResponsesResponseInputItemMcpApprovalRequest,
    OpenAITypesResponsesResponseInputItemMcpApprovalResponse,
    OpenAITypesResponsesResponseInputItemMcpCall,
    OpenAITypesResponsesResponseInputItemMcpListTools,
    OpenAITypesResponsesResponseInputItemMessage,
    OpenAITypesResponsesResponseOutputItemImageGenerationCall,
    OpenAITypesResponsesResponseOutputItemLocalShellCall,
    OpenAITypesResponsesResponseOutputItemMcpApprovalRequest,
    OpenAITypesResponsesResponseOutputItemMcpCall,
    OpenAITypesResponsesResponseOutputItemMcpListTools,
    Part,
    Reasoning,
    ToolChoiceAllowed,
    ToolChoiceCustom,
    ToolChoiceFunction,
    ToolChoiceMcp,
    ToolChoiceTypes,
    WebSearchTool,
    ResponseCreateResponse,
)
```

Methods:

- <code title="post /v5/responses">client.responses.<a href="./src/scale_gp_beta/resources/responses.py">create</a>(\*\*<a href="src/scale_gp_beta/types/response_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/response_create_response.py">ResponseCreateResponse</a></code>

# Completions

Types:

```python
from scale_gp_beta.types import Completion, CompletionUsage
```

Methods:

- <code title="post /v5/completions">client.completions.<a href="./src/scale_gp_beta/resources/completions.py">create</a>(\*\*<a href="src/scale_gp_beta/types/completion_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/completion.py">Completion</a></code>

# Chat

## Completions

Types:

```python
from scale_gp_beta.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    ChatCompletionTokenLogprob,
    ChoiceLogprobs,
    ModelDefinition,
    SortOrder,
    CompletionCreateResponse,
    CompletionModelsResponse,
)
```

Methods:

- <code title="post /v5/chat/completions">client.chat.completions.<a href="./src/scale_gp_beta/resources/chat/completions.py">create</a>(\*\*<a href="src/scale_gp_beta/types/chat/completion_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/chat/completion_create_response.py">CompletionCreateResponse</a></code>
- <code title="get /v5/chat/completions/models">client.chat.completions.<a href="./src/scale_gp_beta/resources/chat/completions.py">models</a>(\*\*<a href="src/scale_gp_beta/types/chat/completion_models_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/chat/completion_models_response.py">CompletionModelsResponse</a></code>

# Inference

Types:

```python
from scale_gp_beta.types import (
    InferenceResponse,
    InferenceResponseChunk,
    LaunchInferenceConfiguration,
    InferenceCreateResponse,
)
```

Methods:

- <code title="post /v5/inference">client.inference.<a href="./src/scale_gp_beta/resources/inference.py">create</a>(\*\*<a href="src/scale_gp_beta/types/inference_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/inference_create_response.py">InferenceCreateResponse</a></code>

# Questions

Types:

```python
from scale_gp_beta.types import (
    CategoricalQuestion,
    CategoricalQuestionConfiguration,
    FormQuestion,
    FormQuestionConfiguration,
    FreeTextQuestion,
    FreeTextQuestionConfiguration,
    NumberQuestion,
    NumberQuestionConfiguration,
    Question,
    RatingQuestion,
    RatingQuestionConfiguration,
    TimestampQuestion,
    TimestampQuestionConfiguration,
)
```

Methods:

- <code title="post /v5/questions">client.questions.<a href="./src/scale_gp_beta/resources/questions.py">create</a>(\*\*<a href="src/scale_gp_beta/types/question_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/question.py">Question</a></code>
- <code title="get /v5/questions/{question_id}">client.questions.<a href="./src/scale_gp_beta/resources/questions.py">retrieve</a>(question_id) -> <a href="./src/scale_gp_beta/types/question.py">Question</a></code>
- <code title="patch /v5/questions/{question_id}">client.questions.<a href="./src/scale_gp_beta/resources/questions.py">update</a>(question_id, \*\*<a href="src/scale_gp_beta/types/question_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/question.py">Question</a></code>
- <code title="get /v5/questions">client.questions.<a href="./src/scale_gp_beta/resources/questions.py">list</a>(\*\*<a href="src/scale_gp_beta/types/question_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/question.py">SyncCursorPage[Question]</a></code>
- <code title="delete /v5/questions/{question_id}">client.questions.<a href="./src/scale_gp_beta/resources/questions.py">archive</a>(question_id) -> <a href="./src/scale_gp_beta/types/question.py">Question</a></code>
- <code title="post /v5/questions/{question_id}/restore">client.questions.<a href="./src/scale_gp_beta/resources/questions.py">restore</a>(question_id) -> <a href="./src/scale_gp_beta/types/question.py">Question</a></code>

# Files

Types:

```python
from scale_gp_beta.types import SGPFile, FileDeleteResponse, FileImportFromCloudResponse
```

Methods:

- <code title="post /v5/files">client.files.<a href="./src/scale_gp_beta/resources/files/files.py">create</a>(\*\*<a href="src/scale_gp_beta/types/file_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/sgp_file.py">SGPFile</a></code>
- <code title="get /v5/files/{file_id}">client.files.<a href="./src/scale_gp_beta/resources/files/files.py">retrieve</a>(file_id) -> <a href="./src/scale_gp_beta/types/sgp_file.py">SGPFile</a></code>
- <code title="patch /v5/files/{file_id}">client.files.<a href="./src/scale_gp_beta/resources/files/files.py">update</a>(file_id, \*\*<a href="src/scale_gp_beta/types/file_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/sgp_file.py">SGPFile</a></code>
- <code title="get /v5/files">client.files.<a href="./src/scale_gp_beta/resources/files/files.py">list</a>(\*\*<a href="src/scale_gp_beta/types/file_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/sgp_file.py">SyncCursorPage[SGPFile]</a></code>
- <code title="delete /v5/files/{file_id}">client.files.<a href="./src/scale_gp_beta/resources/files/files.py">delete</a>(file_id) -> <a href="./src/scale_gp_beta/types/file_delete_response.py">FileDeleteResponse</a></code>
- <code title="post /v5/files/cloud_imports">client.files.<a href="./src/scale_gp_beta/resources/files/files.py">import_from_cloud</a>(\*\*<a href="src/scale_gp_beta/types/file_import_from_cloud_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/file_import_from_cloud_response.py">FileImportFromCloudResponse</a></code>

## Content

Methods:

- <code title="get /v5/files/{file_id}/content">client.files.content.<a href="./src/scale_gp_beta/resources/files/content.py">retrieve</a>(file_id) -> object</code>

# Models

Types:

```python
from scale_gp_beta.types import (
    InferenceModel,
    LaunchVendorConfiguration,
    LlmEngineVendorConfiguration,
    ModelDeleteResponse,
)
```

Methods:

- <code title="post /v5/models">client.models.<a href="./src/scale_gp_beta/resources/models.py">create</a>(\*\*<a href="src/scale_gp_beta/types/model_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/inference_model.py">InferenceModel</a></code>
- <code title="get /v5/models/{model_id}">client.models.<a href="./src/scale_gp_beta/resources/models.py">retrieve</a>(model_id) -> <a href="./src/scale_gp_beta/types/inference_model.py">InferenceModel</a></code>
- <code title="patch /v5/models/{model_id}">client.models.<a href="./src/scale_gp_beta/resources/models.py">update</a>(model_id, \*\*<a href="src/scale_gp_beta/types/model_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/inference_model.py">InferenceModel</a></code>
- <code title="get /v5/models">client.models.<a href="./src/scale_gp_beta/resources/models.py">list</a>(\*\*<a href="src/scale_gp_beta/types/model_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/inference_model.py">SyncCursorPage[InferenceModel]</a></code>
- <code title="delete /v5/models/{model_id}">client.models.<a href="./src/scale_gp_beta/resources/models.py">delete</a>(model_id) -> <a href="./src/scale_gp_beta/types/model_delete_response.py">ModelDeleteResponse</a></code>

# Datasets

Types:

```python
from scale_gp_beta.types import Dataset, DatasetArchiveResponse
```

Methods:

- <code title="post /v5/datasets">client.datasets.<a href="./src/scale_gp_beta/resources/datasets.py">create</a>(\*\*<a href="src/scale_gp_beta/types/dataset_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/dataset.py">Dataset</a></code>
- <code title="get /v5/datasets/{dataset_id}">client.datasets.<a href="./src/scale_gp_beta/resources/datasets.py">retrieve</a>(dataset_id, \*\*<a href="src/scale_gp_beta/types/dataset_retrieve_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/dataset.py">Dataset</a></code>
- <code title="patch /v5/datasets/{dataset_id}">client.datasets.<a href="./src/scale_gp_beta/resources/datasets.py">update</a>(dataset_id, \*\*<a href="src/scale_gp_beta/types/dataset_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/dataset.py">Dataset</a></code>
- <code title="get /v5/datasets">client.datasets.<a href="./src/scale_gp_beta/resources/datasets.py">list</a>(\*\*<a href="src/scale_gp_beta/types/dataset_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/dataset.py">SyncCursorPage[Dataset]</a></code>
- <code title="delete /v5/datasets/{dataset_id}">client.datasets.<a href="./src/scale_gp_beta/resources/datasets.py">archive</a>(dataset_id) -> <a href="./src/scale_gp_beta/types/dataset_archive_response.py">DatasetArchiveResponse</a></code>

# DatasetItems

Types:

```python
from scale_gp_beta.types import (
    DatasetItem,
    DatasetItemArchiveResponse,
    DatasetItemBatchCreateResponse,
)
```

Methods:

- <code title="get /v5/dataset-items/{dataset_item_id}">client.dataset_items.<a href="./src/scale_gp_beta/resources/dataset_items.py">retrieve</a>(dataset_item_id, \*\*<a href="src/scale_gp_beta/types/dataset_item_retrieve_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/dataset_item.py">DatasetItem</a></code>
- <code title="patch /v5/dataset-items/{dataset_item_id}">client.dataset_items.<a href="./src/scale_gp_beta/resources/dataset_items.py">update</a>(dataset_item_id, \*\*<a href="src/scale_gp_beta/types/dataset_item_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/dataset_item.py">DatasetItem</a></code>
- <code title="get /v5/dataset-items">client.dataset_items.<a href="./src/scale_gp_beta/resources/dataset_items.py">list</a>(\*\*<a href="src/scale_gp_beta/types/dataset_item_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/dataset_item.py">SyncCursorPage[DatasetItem]</a></code>
- <code title="delete /v5/dataset-items/{dataset_item_id}">client.dataset_items.<a href="./src/scale_gp_beta/resources/dataset_items.py">archive</a>(dataset_item_id) -> <a href="./src/scale_gp_beta/types/dataset_item_archive_response.py">DatasetItemArchiveResponse</a></code>
- <code title="post /v5/dataset-items/batch">client.dataset_items.<a href="./src/scale_gp_beta/resources/dataset_items.py">batch_create</a>(\*\*<a href="src/scale_gp_beta/types/dataset_item_batch_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/dataset_item_batch_create_response.py">DatasetItemBatchCreateResponse</a></code>

# Evaluations

Types:

```python
from scale_gp_beta.types import (
    AutoEvaluationAgentTaskRequestWithItemLocator,
    Evaluation,
    EvaluationSchemaResponse,
    EvaluationTask,
    EvaluationTasksProgressSchema,
    EvaluationViews,
    ItemLocator,
    ItemLocatorTemplate,
    PaginatedListEvaluation,
    EvaluationRetrieveTaxonomyResponse,
)
```

Methods:

- <code title="post /v5/evaluations">client.evaluations.<a href="./src/scale_gp_beta/resources/evaluations.py">create</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation.py">Evaluation</a></code>
- <code title="get /v5/evaluations/{evaluation_id}">client.evaluations.<a href="./src/scale_gp_beta/resources/evaluations.py">retrieve</a>(evaluation_id, \*\*<a href="src/scale_gp_beta/types/evaluation_retrieve_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation.py">Evaluation</a></code>
- <code title="patch /v5/evaluations/{evaluation_id}">client.evaluations.<a href="./src/scale_gp_beta/resources/evaluations.py">update</a>(evaluation_id, \*\*<a href="src/scale_gp_beta/types/evaluation_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation.py">Evaluation</a></code>
- <code title="get /v5/evaluations">client.evaluations.<a href="./src/scale_gp_beta/resources/evaluations.py">list</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation.py">SyncCursorPage[Evaluation]</a></code>
- <code title="delete /v5/evaluations/{evaluation_id}">client.evaluations.<a href="./src/scale_gp_beta/resources/evaluations.py">archive</a>(evaluation_id) -> <a href="./src/scale_gp_beta/types/evaluation.py">Evaluation</a></code>
- <code title="post /v5/evaluations/filter">client.evaluations.<a href="./src/scale_gp_beta/resources/evaluations.py">filter</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_filter_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation.py">SyncCursorPage[Evaluation]</a></code>
- <code title="get /v5/evaluations/{evaluation_id}/schema">client.evaluations.<a href="./src/scale_gp_beta/resources/evaluations.py">retrieve_schema</a>(evaluation_id, \*\*<a href="src/scale_gp_beta/types/evaluation_retrieve_schema_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_schema_response.py">EvaluationSchemaResponse</a></code>
- <code title="get /v5/evaluations/{evaluation_id}/taxonomy">client.evaluations.<a href="./src/scale_gp_beta/resources/evaluations.py">retrieve_taxonomy</a>(evaluation_id) -> <a href="./src/scale_gp_beta/types/evaluation_retrieve_taxonomy_response.py">EvaluationRetrieveTaxonomyResponse</a></code>

# EvaluationItems

Types:

```python
from scale_gp_beta.types import (
    Component,
    Container,
    EvaluationItem,
    EvaluationItemExport,
    ExportFormat,
    ExportMethod,
    TaskError,
)
```

Methods:

- <code title="get /v5/evaluation-items/{evaluation_item_id}">client.evaluation_items.<a href="./src/scale_gp_beta/resources/evaluation_items.py">retrieve</a>(evaluation_item_id, \*\*<a href="src/scale_gp_beta/types/evaluation_item_retrieve_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_item.py">EvaluationItem</a></code>
- <code title="get /v5/evaluation-items">client.evaluation_items.<a href="./src/scale_gp_beta/resources/evaluation_items.py">list</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_item_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_item.py">SyncCursorPage[EvaluationItem]</a></code>
- <code title="post /v5/evaluation-items/export">client.evaluation_items.<a href="./src/scale_gp_beta/resources/evaluation_items.py">export</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_item_export_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_item_export.py">EvaluationItemExport</a></code>

# Rubrics

Types:

```python
from scale_gp_beta.types import RestoreRequest, RubricResponse, RubricArchiveResponse
```

Methods:

- <code title="post /v5/rubrics">client.rubrics.<a href="./src/scale_gp_beta/resources/rubrics/rubrics.py">create</a>(\*\*<a href="src/scale_gp_beta/types/rubric_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/rubric_response.py">RubricResponse</a></code>
- <code title="get /v5/rubrics/{rubric_id}">client.rubrics.<a href="./src/scale_gp_beta/resources/rubrics/rubrics.py">retrieve</a>(rubric_id) -> <a href="./src/scale_gp_beta/types/rubric_response.py">RubricResponse</a></code>
- <code title="patch /v5/rubrics/{rubric_id}">client.rubrics.<a href="./src/scale_gp_beta/resources/rubrics/rubrics.py">update</a>(rubric_id, \*\*<a href="src/scale_gp_beta/types/rubric_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/rubric_response.py">RubricResponse</a></code>
- <code title="get /v5/rubrics">client.rubrics.<a href="./src/scale_gp_beta/resources/rubrics/rubrics.py">list</a>(\*\*<a href="src/scale_gp_beta/types/rubric_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/rubric_response.py">SyncCursorPage[RubricResponse]</a></code>
- <code title="delete /v5/rubrics/{rubric_id}">client.rubrics.<a href="./src/scale_gp_beta/resources/rubrics/rubrics.py">archive</a>(rubric_id) -> <a href="./src/scale_gp_beta/types/rubric_archive_response.py">RubricArchiveResponse</a></code>

## Criteria

Types:

```python
from scale_gp_beta.types.rubrics import (
    RubricCriteriaInput,
    RubricCriteriaResponse,
    RubricCriteriaSummaryResponse,
    CriterionListVersionsResponse,
)
```

Methods:

- <code title="post /v5/rubrics/{rubric_id}/criteria">client.rubrics.criteria.<a href="./src/scale_gp_beta/resources/rubrics/criteria.py">create</a>(rubric_id, \*\*<a href="src/scale_gp_beta/types/rubrics/criterion_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/rubrics/rubric_criteria_response.py">RubricCriteriaResponse</a></code>
- <code title="patch /v5/rubrics/{rubric_id}/criteria/{rubric_criteria_id}">client.rubrics.criteria.<a href="./src/scale_gp_beta/resources/rubrics/criteria.py">update</a>(rubric_criteria_id, \*, rubric_id, \*\*<a href="src/scale_gp_beta/types/rubrics/criterion_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/rubrics/rubric_criteria_response.py">RubricCriteriaResponse</a></code>
- <code title="get /v5/rubrics/{rubric_id}/criteria/{rubric_criteria_id}/versions">client.rubrics.criteria.<a href="./src/scale_gp_beta/resources/rubrics/criteria.py">list_versions</a>(rubric_criteria_id, \*, rubric_id, \*\*<a href="src/scale_gp_beta/types/rubrics/criterion_list_versions_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/rubrics/criterion_list_versions_response.py">CriterionListVersionsResponse</a></code>

# EvaluationGroups

Types:

```python
from scale_gp_beta.types import (
    EvaluationGroup,
    EvaluationGroupMember,
    EvaluationGroupRowIdentifier,
    EvaluationGroupViews,
    EvaluationGroupRetrieveSchemaResponse,
)
```

Methods:

- <code title="post /v5/evaluation-groups">client.evaluation_groups.<a href="./src/scale_gp_beta/resources/evaluation_groups.py">create</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_group_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_group.py">EvaluationGroup</a></code>
- <code title="get /v5/evaluation-groups/{group_id}">client.evaluation_groups.<a href="./src/scale_gp_beta/resources/evaluation_groups.py">retrieve</a>(group_id, \*\*<a href="src/scale_gp_beta/types/evaluation_group_retrieve_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_group.py">EvaluationGroup</a></code>
- <code title="patch /v5/evaluation-groups/{group_id}">client.evaluation_groups.<a href="./src/scale_gp_beta/resources/evaluation_groups.py">update</a>(group_id, \*\*<a href="src/scale_gp_beta/types/evaluation_group_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_group.py">EvaluationGroup</a></code>
- <code title="get /v5/evaluation-groups">client.evaluation_groups.<a href="./src/scale_gp_beta/resources/evaluation_groups.py">list</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_group_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_group.py">SyncCursorPage[EvaluationGroup]</a></code>
- <code title="delete /v5/evaluation-groups/{group_id}">client.evaluation_groups.<a href="./src/scale_gp_beta/resources/evaluation_groups.py">archive</a>(group_id) -> <a href="./src/scale_gp_beta/types/evaluation_group.py">EvaluationGroup</a></code>
- <code title="put /v5/evaluation-groups/{group_id}">client.evaluation_groups.<a href="./src/scale_gp_beta/resources/evaluation_groups.py">replace</a>(group_id, \*\*<a href="src/scale_gp_beta/types/evaluation_group_replace_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_group.py">EvaluationGroup</a></code>
- <code title="get /v5/evaluation-groups/{group_id}/schema">client.evaluation_groups.<a href="./src/scale_gp_beta/resources/evaluation_groups.py">retrieve_schema</a>(group_id, \*\*<a href="src/scale_gp_beta/types/evaluation_group_retrieve_schema_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_group_retrieve_schema_response.py">EvaluationGroupRetrieveSchemaResponse</a></code>

# EvaluationDashboards

Types:

```python
from scale_gp_beta.types import EvaluationDashboard
```

Methods:

- <code title="post /v5/evaluation-dashboards">client.evaluation_dashboards.<a href="./src/scale_gp_beta/resources/evaluation_dashboards/evaluation_dashboards.py">create</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_dashboard_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_dashboard.py">EvaluationDashboard</a></code>
- <code title="get /v5/evaluation-dashboards/{dashboard_id}">client.evaluation_dashboards.<a href="./src/scale_gp_beta/resources/evaluation_dashboards/evaluation_dashboards.py">retrieve</a>(dashboard_id, \*\*<a href="src/scale_gp_beta/types/evaluation_dashboard_retrieve_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_dashboard.py">EvaluationDashboard</a></code>
- <code title="patch /v5/evaluation-dashboards/{dashboard_id}">client.evaluation_dashboards.<a href="./src/scale_gp_beta/resources/evaluation_dashboards/evaluation_dashboards.py">update</a>(dashboard_id, \*\*<a href="src/scale_gp_beta/types/evaluation_dashboard_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_dashboard.py">EvaluationDashboard</a></code>
- <code title="get /v5/evaluation-dashboards">client.evaluation_dashboards.<a href="./src/scale_gp_beta/resources/evaluation_dashboards/evaluation_dashboards.py">list</a>(\*\*<a href="src/scale_gp_beta/types/evaluation_dashboard_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_dashboard.py">SyncCursorPage[EvaluationDashboard]</a></code>
- <code title="delete /v5/evaluation-dashboards/{dashboard_id}">client.evaluation_dashboards.<a href="./src/scale_gp_beta/resources/evaluation_dashboards/evaluation_dashboards.py">archive</a>(dashboard_id) -> <a href="./src/scale_gp_beta/types/evaluation_dashboard.py">EvaluationDashboard</a></code>

## Widgets

Types:

```python
from scale_gp_beta.types.evaluation_dashboards import (
    EvaluationDashboardWidget,
    EvaluationDashboardWidgetResult,
    EvaluationDashboardWidgetResultResponse,
    EvaluationDashboardWidgetWithResult,
    EvaluationWidgetTypeEnum,
    Filter,
    MetricQuery,
    SelectItem,
    SeriesQuery,
)
```

Methods:

- <code title="post /v5/evaluation-dashboards/{dashboard_id}/widgets">client.evaluation_dashboards.widgets.<a href="./src/scale_gp_beta/resources/evaluation_dashboards/widgets.py">create</a>(dashboard_id, \*\*<a href="src/scale_gp_beta/types/evaluation_dashboards/widget_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_dashboards/evaluation_dashboard_widget_with_result.py">EvaluationDashboardWidgetWithResult</a></code>
- <code title="patch /v5/evaluation-dashboards/{dashboard_id}/widgets/{widget_id}">client.evaluation_dashboards.widgets.<a href="./src/scale_gp_beta/resources/evaluation_dashboards/widgets.py">update</a>(widget_id, \*, dashboard_id, \*\*<a href="src/scale_gp_beta/types/evaluation_dashboards/widget_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/evaluation_dashboards/evaluation_dashboard_widget_with_result.py">EvaluationDashboardWidgetWithResult</a></code>
- <code title="delete /v5/evaluation-dashboards/{dashboard_id}/widgets/{widget_id}">client.evaluation_dashboards.widgets.<a href="./src/scale_gp_beta/resources/evaluation_dashboards/widgets.py">remove</a>(widget_id, \*, dashboard_id) -> None</code>

# Spans

Types:

```python
from scale_gp_beta.types import APIListSpan, Span, SpanBatchCreate, SpanCreate, SpanStatus, SpanType
```

Methods:

- <code title="post /v5/spans">client.spans.<a href="./src/scale_gp_beta/resources/spans.py">create</a>(\*\*<a href="src/scale_gp_beta/types/span_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/span.py">Span</a></code>
- <code title="get /v5/spans/{span_id}">client.spans.<a href="./src/scale_gp_beta/resources/spans.py">retrieve</a>(span_id) -> <a href="./src/scale_gp_beta/types/span.py">Span</a></code>
- <code title="patch /v5/spans/{span_id}">client.spans.<a href="./src/scale_gp_beta/resources/spans.py">update</a>(span_id, \*\*<a href="src/scale_gp_beta/types/span_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/span.py">Span</a></code>
- <code title="post /v5/spans/batch">client.spans.<a href="./src/scale_gp_beta/resources/spans.py">batch</a>(\*\*<a href="src/scale_gp_beta/types/span_batch_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/api_list_span.py">APIListSpan</a></code>
- <code title="post /v5/spans/search">client.spans.<a href="./src/scale_gp_beta/resources/spans.py">search</a>(\*\*<a href="src/scale_gp_beta/types/span_search_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/span.py">SyncCursorPage[Span]</a></code>
- <code title="put /v5/spans/batch">client.spans.<a href="./src/scale_gp_beta/resources/spans.py">upsert_batch</a>(\*\*<a href="src/scale_gp_beta/types/span_upsert_batch_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/api_list_span.py">APIListSpan</a></code>

# SpanAssessments

Types:

```python
from scale_gp_beta.types import (
    ApprovalStatus,
    AssessmentType,
    SpanAssessment,
    SpanAssessmentDeleteResponse,
)
```

Methods:

- <code title="post /v5/span-assessments">client.span_assessments.<a href="./src/scale_gp_beta/resources/span_assessments.py">create</a>(\*\*<a href="src/scale_gp_beta/types/span_assessment_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/span_assessment.py">SpanAssessment</a></code>
- <code title="get /v5/span-assessments/{span_assessment_id}">client.span_assessments.<a href="./src/scale_gp_beta/resources/span_assessments.py">retrieve</a>(span_assessment_id) -> <a href="./src/scale_gp_beta/types/span_assessment.py">SpanAssessment</a></code>
- <code title="patch /v5/span-assessments/{span_assessment_id}">client.span_assessments.<a href="./src/scale_gp_beta/resources/span_assessments.py">update</a>(span_assessment_id, \*\*<a href="src/scale_gp_beta/types/span_assessment_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/span_assessment.py">SpanAssessment</a></code>
- <code title="get /v5/span-assessments">client.span_assessments.<a href="./src/scale_gp_beta/resources/span_assessments.py">list</a>(\*\*<a href="src/scale_gp_beta/types/span_assessment_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/span_assessment.py">SyncAPIListPage[SpanAssessment]</a></code>
- <code title="delete /v5/span-assessments/{span_assessment_id}">client.span_assessments.<a href="./src/scale_gp_beta/resources/span_assessments.py">delete</a>(span_assessment_id) -> <a href="./src/scale_gp_beta/types/span_assessment_delete_response.py">SpanAssessmentDeleteResponse</a></code>

# Credentials

Types:

```python
from scale_gp_beta.types import Credential, CredentialSecret, CredentialDeleteResponse
```

Methods:

- <code title="post /v5/credentials">client.credentials.<a href="./src/scale_gp_beta/resources/credentials.py">create</a>(\*\*<a href="src/scale_gp_beta/types/credential_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/credential.py">Credential</a></code>
- <code title="get /v5/credentials/{credential_id}">client.credentials.<a href="./src/scale_gp_beta/resources/credentials.py">retrieve</a>(credential_id) -> <a href="./src/scale_gp_beta/types/credential.py">Credential</a></code>
- <code title="patch /v5/credentials/{credential_id}">client.credentials.<a href="./src/scale_gp_beta/resources/credentials.py">update</a>(credential_id, \*\*<a href="src/scale_gp_beta/types/credential_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/credential.py">Credential</a></code>
- <code title="get /v5/credentials">client.credentials.<a href="./src/scale_gp_beta/resources/credentials.py">list</a>(\*\*<a href="src/scale_gp_beta/types/credential_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/credential.py">SyncCursorPage[Credential]</a></code>
- <code title="delete /v5/credentials/{credential_id}">client.credentials.<a href="./src/scale_gp_beta/resources/credentials.py">delete</a>(credential_id) -> <a href="./src/scale_gp_beta/types/credential_delete_response.py">CredentialDeleteResponse</a></code>
- <code title="post /v5/credentials/{credential_id}/secret">client.credentials.<a href="./src/scale_gp_beta/resources/credentials.py">decrypt</a>(credential_id) -> <a href="./src/scale_gp_beta/types/credential_secret.py">CredentialSecret</a></code>
- <code title="post /v5/credentials/name/{credential_name}/secret">client.credentials.<a href="./src/scale_gp_beta/resources/credentials.py">decrypt_by_name</a>(credential_name) -> <a href="./src/scale_gp_beta/types/credential_secret.py">CredentialSecret</a></code>
- <code title="get /v5/credentials/name/{credential_name}">client.credentials.<a href="./src/scale_gp_beta/resources/credentials.py">retrieve_by_name</a>(credential_name) -> <a href="./src/scale_gp_beta/types/credential.py">Credential</a></code>

# Build

Types:

```python
from scale_gp_beta.types import AgentexCloudBuild, StreamChunk, BuildListUndeployedResponse
```

Methods:

- <code title="post /v5/builds">client.build.<a href="./src/scale_gp_beta/resources/build.py">create</a>(\*\*<a href="src/scale_gp_beta/types/build_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/agentex_cloud_build.py">AgentexCloudBuild</a></code>
- <code title="get /v5/builds/{build_id}">client.build.<a href="./src/scale_gp_beta/resources/build.py">retrieve</a>(build_id) -> <a href="./src/scale_gp_beta/types/agentex_cloud_build.py">AgentexCloudBuild</a></code>
- <code title="get /v5/builds">client.build.<a href="./src/scale_gp_beta/resources/build.py">list</a>(\*\*<a href="src/scale_gp_beta/types/build_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/agentex_cloud_build.py">SyncCursorPage[AgentexCloudBuild]</a></code>
- <code title="post /v5/builds/{build_id}/cancel">client.build.<a href="./src/scale_gp_beta/resources/build.py">cancel</a>(build_id) -> <a href="./src/scale_gp_beta/types/agentex_cloud_build.py">AgentexCloudBuild</a></code>
- <code title="get /v5/builds/undeployed">client.build.<a href="./src/scale_gp_beta/resources/build.py">list_undeployed</a>() -> <a href="./src/scale_gp_beta/types/build_list_undeployed_response.py">BuildListUndeployedResponse</a></code>
- <code title="get /v5/builds/{build_id}/logs">client.build.<a href="./src/scale_gp_beta/resources/build.py">logs</a>(build_id) -> <a href="./src/scale_gp_beta/types/stream_chunk.py">StreamChunk</a></code>

# Deploy

Types:

```python
from scale_gp_beta.types import AgentexCloudDeploy, AgentexCloudDeployEvent, DeployLogsResponse
```

Methods:

- <code title="post /v5/agentex/deployments">client.deploy.<a href="./src/scale_gp_beta/resources/deploy.py">create</a>(\*\*<a href="src/scale_gp_beta/types/deploy_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/agentex_cloud_deploy.py">AgentexCloudDeploy</a></code>
- <code title="get /v5/agentex/deployments/{deployment_id}">client.deploy.<a href="./src/scale_gp_beta/resources/deploy.py">retrieve</a>(deployment_id) -> <a href="./src/scale_gp_beta/types/agentex_cloud_deploy.py">AgentexCloudDeploy</a></code>
- <code title="get /v5/agentex/deployments">client.deploy.<a href="./src/scale_gp_beta/resources/deploy.py">list</a>(\*\*<a href="src/scale_gp_beta/types/deploy_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/agentex_cloud_deploy.py">SyncCursorPage[AgentexCloudDeploy]</a></code>
- <code title="get /v5/agentex/deployments/{deployment_id}/logs">client.deploy.<a href="./src/scale_gp_beta/resources/deploy.py">logs</a>(deployment_id, \*\*<a href="src/scale_gp_beta/types/deploy_logs_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/deploy_logs_response.py">DeployLogsResponse</a></code>

# Secrets

Types:

```python
from scale_gp_beta.types import (
    SecretCreateResponse,
    SecretRetrieveResponse,
    SecretUpdateResponse,
    SecretListResponse,
)
```

Methods:

- <code title="post /v5/sgp/secrets">client.secrets.<a href="./src/scale_gp_beta/resources/secrets.py">create</a>(\*\*<a href="src/scale_gp_beta/types/secret_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/secret_create_response.py">SecretCreateResponse</a></code>
- <code title="get /v5/sgp/secrets/{secret_id}">client.secrets.<a href="./src/scale_gp_beta/resources/secrets.py">retrieve</a>(secret_id) -> <a href="./src/scale_gp_beta/types/secret_retrieve_response.py">SecretRetrieveResponse</a></code>
- <code title="patch /v5/sgp/secrets/{secret_id}">client.secrets.<a href="./src/scale_gp_beta/resources/secrets.py">update</a>(secret_id, \*\*<a href="src/scale_gp_beta/types/secret_update_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/secret_update_response.py">SecretUpdateResponse</a></code>
- <code title="get /v5/sgp/secrets">client.secrets.<a href="./src/scale_gp_beta/resources/secrets.py">list</a>(\*\*<a href="src/scale_gp_beta/types/secret_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/secret_list_response.py">SyncCursorPage[SecretListResponse]</a></code>
- <code title="delete /v5/sgp/secrets/{secret_id}">client.secrets.<a href="./src/scale_gp_beta/resources/secrets.py">delete</a>(secret_id) -> None</code>

# VectorStores

Types:

```python
from scale_gp_beta.types import (
    EmbeddingConfig,
    EmbeddingConfigBase,
    EmbeddingConfigModelsAPI,
    EmbeddingModelName,
    TextContent,
    VectorStore,
    VectorStoreDeleteResponse,
    VectorStoreCountResponse,
    VectorStoreDropResponse,
    VectorStoreQueryResponse,
    VectorStoreUpsertResponse,
)
```

Methods:

- <code title="post /v5/vector-stores/create">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">create</a>(\*\*<a href="src/scale_gp_beta/types/vector_store_create_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_store.py">VectorStore</a></code>
- <code title="get /v5/vector-stores/{vector_store_name}">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">retrieve</a>(vector_store_name) -> <a href="./src/scale_gp_beta/types/vector_store.py">VectorStore</a></code>
- <code title="get /v5/vector-stores">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">list</a>(\*\*<a href="src/scale_gp_beta/types/vector_store_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_store.py">SyncCursorPageByName[VectorStore]</a></code>
- <code title="post /v5/vector-stores/{vector_store_name}/delete">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">delete</a>(vector_store_name, \*\*<a href="src/scale_gp_beta/types/vector_store_delete_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_store_delete_response.py">VectorStoreDeleteResponse</a></code>
- <code title="post /v5/vector-stores/{vector_store_name}/configure">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">configure</a>(vector_store_name, \*\*<a href="src/scale_gp_beta/types/vector_store_configure_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_store.py">VectorStore</a></code>
- <code title="post /v5/vector-stores/{vector_store_name}/count">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">count</a>(vector_store_name, \*\*<a href="src/scale_gp_beta/types/vector_store_count_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_store_count_response.py">VectorStoreCountResponse</a></code>
- <code title="post /v5/vector-stores/{vector_store_name}/drop">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">drop</a>(vector_store_name) -> <a href="./src/scale_gp_beta/types/vector_store_drop_response.py">VectorStoreDropResponse</a></code>
- <code title="post /v5/vector-stores/{vector_store_name}/query">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">query</a>(vector_store_name, \*\*<a href="src/scale_gp_beta/types/vector_store_query_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_store_query_response.py">VectorStoreQueryResponse</a></code>
- <code title="post /v5/vector-stores/{vector_store_name}/upsert">client.vector_stores.<a href="./src/scale_gp_beta/resources/vector_stores/vector_stores.py">upsert</a>(vector_store_name, \*\*<a href="src/scale_gp_beta/types/vector_store_upsert_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_store_upsert_response.py">VectorStoreUpsertResponse</a></code>

## Vectors

Types:

```python
from scale_gp_beta.types.vector_stores import VectorDocument
```

Methods:

- <code title="get /v5/vector-stores/{vector_store_name}/vectors/{vector_id}">client.vector_stores.vectors.<a href="./src/scale_gp_beta/resources/vector_stores/vectors.py">retrieve</a>(vector_id, \*, vector_store_name, \*\*<a href="src/scale_gp_beta/types/vector_stores/vector_retrieve_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_stores/vector_document.py">VectorDocument</a></code>
- <code title="get /v5/vector-stores/{vector_store_name}/vectors">client.vector_stores.vectors.<a href="./src/scale_gp_beta/resources/vector_stores/vectors.py">list</a>(vector_store_name, \*\*<a href="src/scale_gp_beta/types/vector_stores/vector_list_params.py">params</a>) -> <a href="./src/scale_gp_beta/types/vector_stores/vector_document.py">SyncCursorPageVectors[VectorDocument]</a></code>
