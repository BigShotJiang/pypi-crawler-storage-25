---
title: JobSubmitDescription
---

::: pyslurm.JobSubmitDescription
