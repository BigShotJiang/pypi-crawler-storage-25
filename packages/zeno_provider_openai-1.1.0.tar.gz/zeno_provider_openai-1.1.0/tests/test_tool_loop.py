"""Tool-loop mechanics for `OpenAIProvider`.

Covers iteration bounds, error-result envelopes for bad tool JSON and tool
exceptions (KD10 — the loop continues so the model can self-correct), and
sequential vs parallel dispatch mode.
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import Callable

import httpx
import pytest
from zeno.agent import Agent
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx, bind_ctx
from zeno.exceptions import ProviderError
from zeno.memory.handles import MemoryView
from zeno.providers.openai import OpenAIProvider
from zeno.testing import InMemoryConversationStore
from zeno.tool import tool


@tool
async def echo(ctx: Ctx, text: str) -> str:
    return f"echoed:{text}"


@tool
async def boom(ctx: Ctx) -> str:
    raise ValueError("boom")


@tool
async def slow(ctx: Ctx, ms: int) -> str:
    await asyncio.sleep(ms / 1000)
    return f"slept:{ms}"


def _tool_call_body(
    sse_lines: Callable[..., bytes],
    tool_calls: list[tuple[str, str, str]],
) -> bytes:
    call_entries = [
        {
            "index": i,
            "id": call_id,
            "type": "function",
            "function": {"name": name, "arguments": arguments},
        }
        for i, (call_id, name, arguments) in enumerate(tool_calls)
    ]
    chunks = [
        json.dumps({"choices": [{"delta": {"tool_calls": call_entries}, "finish_reason": None}]}),
        json.dumps({"choices": [{"delta": {}, "finish_reason": "tool_calls"}]}),
        "[DONE]",
    ]
    return sse_lines(*chunks)


def _text_body(sse_lines: Callable[..., bytes], text: str) -> bytes:
    chunks = [
        json.dumps({"choices": [{"delta": {"content": text}, "finish_reason": None}]}),
        json.dumps({"choices": [{"delta": {}, "finish_reason": "stop"}]}),
        "[DONE]",
    ]
    return sse_lines(*chunks)


def _sse(body: bytes) -> httpx.Response:
    return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})


def _provider(**overrides: object) -> OpenAIProvider:
    kwargs: dict[str, object] = {"api_key": "sk-xxx", "model": "gpt-4o"}
    kwargs.update(overrides)
    return OpenAIProvider(**kwargs)  # type: ignore[arg-type]


async def test_max_tool_iterations_exceeded_raises_provider_error(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        return _sse(_tool_call_body(sse_lines, [("c1", "echo", '{"text":"hi"}')]))

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view())
        provider = _provider(max_tool_iterations=3)
        with pytest.raises(ProviderError) as excinfo, bind_ctx(ctx):
            await provider.run_turn(
                agent=Agent(name="t", instructions="i", tools=[echo]),
                ctx=ctx,
                msg=make_msg("hi"),
            )
    assert "max_tool_iterations" in str(excinfo.value)


async def test_malformed_tool_arguments_produce_error_tool_result_and_continue(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    store = InMemoryConversationStore()
    call_count = {"n": 0}

    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["messages"][-1]["role"] == "tool":
            return _sse(_text_body(sse_lines, "done"))
        call_count["n"] += 1
        return _sse(_tool_call_body(sse_lines, [("c1", "echo", '{"bad')]))

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view(conversation_store=store))
        with bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i", tools=[echo]),
                ctx=ctx,
                msg=make_msg("hi"),
            )

    stored = await store.load(user_id="u1", thread_key="t1")
    tool_msg = next(m for m in stored if m.role == "tool")
    assert tool_msg.content is not None
    assert tool_msg.content.startswith("Error: could not parse arguments")
    assert call_count["n"] == 1


async def test_tool_exception_is_wrapped_and_loop_continues(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    store = InMemoryConversationStore()

    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["messages"][-1]["role"] == "tool":
            return _sse(_text_body(sse_lines, "done"))
        return _sse(_tool_call_body(sse_lines, [("c1", "boom", "{}")]))

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view(conversation_store=store))
        with bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i", tools=[boom]),
                ctx=ctx,
                msg=make_msg("hi"),
            )

    stored = await store.load(user_id="u1", thread_key="t1")
    tool_msg = next(m for m in stored if m.role == "tool")
    assert tool_msg.content == "Error: boom"


async def test_unknown_tool_name_returns_error_envelope(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    store = InMemoryConversationStore()

    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["messages"][-1]["role"] == "tool":
            return _sse(_text_body(sse_lines, "done"))
        return _sse(_tool_call_body(sse_lines, [("c1", "nope", "{}")]))

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view(conversation_store=store))
        with bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i", tools=[echo]),
                ctx=ctx,
                msg=make_msg("hi"),
            )

    stored = await store.load(user_id="u1", thread_key="t1")
    tool_msg = next(m for m in stored if m.role == "tool")
    assert tool_msg.content is not None
    assert tool_msg.content.startswith("Error: unknown tool")


async def test_parallel_tool_calls_run_concurrently(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    store = InMemoryConversationStore()

    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["messages"][-1]["role"] == "tool":
            return _sse(_text_body(sse_lines, "done"))
        return _sse(
            _tool_call_body(
                sse_lines,
                [
                    ("c1", "slow", '{"ms": 60}'),
                    ("c2", "slow", '{"ms": 60}'),
                ],
            )
        )

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view(conversation_store=store))
        provider = _provider(parallel_tool_calls=True)
        loop = asyncio.get_event_loop()
        start = loop.time()
        with bind_ctx(ctx):
            await provider.run_turn(
                agent=Agent(name="t", instructions="i", tools=[slow]),
                ctx=ctx,
                msg=make_msg("hi"),
            )
        elapsed = loop.time() - start

    assert elapsed < 0.1

    stored = await store.load(user_id="u1", thread_key="t1")
    tool_msgs = [m for m in stored if m.role == "tool"]
    assert [m.content for m in tool_msgs] == ["slept:60", "slept:60"]


async def test_sequential_tool_calls_dispatch_in_order(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    store = InMemoryConversationStore()

    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["messages"][-1]["role"] == "tool":
            return _sse(_text_body(sse_lines, "done"))
        return _sse(
            _tool_call_body(
                sse_lines,
                [
                    ("c1", "echo", '{"text": "a"}'),
                    ("c2", "echo", '{"text": "b"}'),
                ],
            )
        )

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view(conversation_store=store))
        with bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i", tools=[echo]),
                ctx=ctx,
                msg=make_msg("hi"),
            )

    stored = await store.load(user_id="u1", thread_key="t1")
    tool_msgs = [m for m in stored if m.role == "tool"]
    assert [m.content for m in tool_msgs] == ["echoed:a", "echoed:b"]
