"""Vendor quirk coverage — Ollama, vLLM, and credential redaction.

IU5 calls out three quirk scenarios explicitly:

- ``disable_stream_with_tools=True`` drives the Ollama non-streaming fallback
  when tools are present. The outbound request must carry ``stream: false``
  and the body is parsed as a single JSON response, not SSE.
- vLLM #16340: the first tool-call streaming delta may omit ``type``. The
  aggregator defaults it to ``"function"`` so downstream dispatch is
  unambiguous. This is unit-tested in test_streaming; here we pin the
  integration path.
- Credential redaction: API keys and query-string secrets must not appear in
  the `ProviderError` message surfaced to `on_turn_error`.
"""

from __future__ import annotations

import json
from collections.abc import Callable

import httpx
import pytest
from zeno.agent import Agent
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx, bind_ctx
from zeno.exceptions import ProviderError
from zeno.memory.handles import MemoryView
from zeno.providers.openai import OpenAIProvider
from zeno.providers.openai.provider import _safe_error_message
from zeno.testing import InMemoryConversationStore
from zeno.tool import tool


@tool
async def echo(ctx: Ctx, text: str) -> str:
    return f"echoed:{text}"


def _provider(**overrides: object) -> OpenAIProvider:
    kwargs: dict[str, object] = {"api_key": "sk-xxx", "model": "gpt-4o"}
    kwargs.update(overrides)
    return OpenAIProvider(**kwargs)  # type: ignore[arg-type]


def _sse_response(body: bytes) -> httpx.Response:
    return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})


async def test_ollama_disable_stream_with_tools_switches_to_non_streaming(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
) -> None:
    bodies: list[dict[str, object]] = []

    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        bodies.append(body)
        if body["messages"][-1]["role"] == "tool":
            return httpx.Response(
                200,
                json={
                    "choices": [
                        {
                            "message": {"role": "assistant", "content": "done"},
                            "finish_reason": "stop",
                        }
                    ]
                },
            )
        return httpx.Response(
            200,
            json={
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": None,
                            "tool_calls": [
                                {
                                    "id": "c1",
                                    "type": "function",
                                    "function": {
                                        "name": "echo",
                                        "arguments": '{"text":"hi"}',
                                    },
                                }
                            ],
                        },
                        "finish_reason": "tool_calls",
                    }
                ]
            },
        )

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view())
        provider = _provider(disable_stream_with_tools=True)
        with bind_ctx(ctx):
            await provider.run_turn(
                agent=Agent(name="t", instructions="i", tools=[echo]),
                ctx=ctx,
                msg=make_msg("hi"),
            )

    assert all(b["stream"] is False for b in bodies)


async def test_vllm_missing_type_first_chunk_still_dispatches_tool(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["messages"][-1]["role"] == "tool":
            return _sse_response(
                sse_lines(
                    json.dumps({"choices": [{"delta": {"content": "ok"}, "finish_reason": None}]}),
                    json.dumps({"choices": [{"delta": {}, "finish_reason": "stop"}]}),
                    "[DONE]",
                )
            )
        # First tool-call delta without `type`, rest of arguments in later chunk.
        chunks = [
            json.dumps(
                {
                    "choices": [
                        {
                            "delta": {
                                "tool_calls": [
                                    {
                                        "index": 0,
                                        "id": "c1",
                                        "function": {
                                            "name": "echo",
                                            "arguments": '{"text',
                                        },
                                    }
                                ]
                            },
                            "finish_reason": None,
                        }
                    ]
                }
            ),
            json.dumps(
                {
                    "choices": [
                        {
                            "delta": {
                                "tool_calls": [
                                    {
                                        "index": 0,
                                        "function": {"arguments": '":"hi"}'},
                                    }
                                ]
                            },
                            "finish_reason": None,
                        }
                    ]
                }
            ),
            json.dumps({"choices": [{"delta": {}, "finish_reason": "tool_calls"}]}),
            "[DONE]",
        ]
        return _sse_response(sse_lines(*chunks))

    store = InMemoryConversationStore()
    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view(conversation_store=store))
        with bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i", tools=[echo]),
                ctx=ctx,
                msg=make_msg("hi"),
            )

    stored = await store.load(user_id="u1", thread_key="t1")
    tool_msg = next(m for m in stored if m.role == "tool")
    assert tool_msg.content == "echoed:hi"


def test_safe_error_message_strips_authorization_bearer() -> None:
    exc = RuntimeError("401 with Authorization: Bearer sk-abcdef123")
    redacted = _safe_error_message(exc)
    assert "sk-abcdef123" not in redacted
    assert "<redacted>" in redacted


def test_safe_error_message_redacts_api_key_query_string() -> None:
    exc = RuntimeError("request to https://proxy/v1/chat?api-key=SECRET failed")
    redacted = _safe_error_message(exc)
    assert "SECRET" not in redacted
    assert "api-key=<redacted>" in redacted


def test_safe_error_message_caps_body_length() -> None:
    long = "x" * 5000
    exc = RuntimeError(long)
    redacted = _safe_error_message(exc, max_body=200)
    assert len(redacted) <= 250


def test_safe_error_message_sanitises_http_status_error() -> None:
    request = httpx.Request(
        "POST",
        "https://proxy.example/v1/chat/completions?api-key=SECRET",
        headers={"Authorization": "Bearer sk-xxx"},
    )
    response = httpx.Response(500, text="server exploded: sk-xxx", request=request)
    exc = httpx.HTTPStatusError("500", request=request, response=response)
    redacted = _safe_error_message(exc)
    assert "SECRET" not in redacted
    assert "/v1/chat/completions" not in redacted
    assert "proxy.example" in redacted


async def test_provider_error_wraps_http_status_with_redaction(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
) -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, text="bad key: sk-abc")

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view())
        with pytest.raises(ProviderError) as excinfo, bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i"),
                ctx=ctx,
                msg=make_msg("hi"),
            )
    assert "Authorization: Bearer" not in str(excinfo.value)
