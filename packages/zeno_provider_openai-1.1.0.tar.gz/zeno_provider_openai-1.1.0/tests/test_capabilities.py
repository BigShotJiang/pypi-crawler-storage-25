"""Capability declarations and `ZenoApp.start()` integration for `OpenAIProvider`.

Locks the capability set and pins the pair (OpenAIProvider, Agent) through
the same capability-check path IU4's tests exercise against FakeProvider.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import cast

import pytest
from zeno.agent import Agent, SubAgent
from zeno.app import ZenoApp
from zeno.exceptions import ProviderCapabilityError
from zeno.memory.handles import MemoryView
from zeno.protocols.memory import MemoryViewProtocol
from zeno.providers.openai import OpenAIProvider


def _provider() -> OpenAIProvider:
    return OpenAIProvider(api_key="sk-xxx", model="gpt-4o")


def _app(agent: Agent, memory: MemoryView) -> ZenoApp:
    return ZenoApp(
        agent=agent,
        memory=cast(MemoryViewProtocol, memory),
        channels=[],
        provider=_provider(),
    )


def test_declared_capabilities_are_all_false_except_streaming() -> None:
    caps = _provider().capabilities
    assert caps.supports_sub_agents is False
    assert caps.supports_built_in_tools is False
    assert caps.supports_permission_mode is False
    assert caps.supports_streaming is True


async def test_app_start_raises_when_agent_declares_built_in_tools(
    make_memory_view: Callable[..., MemoryView],
) -> None:
    agent = Agent(name="t", instructions="i", built_in_tools=["WebSearch"])
    app = _app(agent, make_memory_view())
    with pytest.raises(ProviderCapabilityError) as excinfo:
        await app.start()
    assert "built_in_tools" in str(excinfo.value) or "WebSearch" in str(excinfo.value)


async def test_app_start_raises_when_agent_declares_sub_agents(
    make_memory_view: Callable[..., MemoryView],
) -> None:
    agent = Agent(
        name="t",
        instructions="i",
        sub_agents=[SubAgent(name="helper", instructions="help")],
    )
    with pytest.raises(ProviderCapabilityError):
        await _app(agent, make_memory_view()).start()


async def test_app_start_raises_when_agent_declares_permission_mode(
    make_memory_view: Callable[..., MemoryView],
) -> None:
    agent = Agent(name="t", instructions="i", permission_mode="acceptEdits")
    with pytest.raises(ProviderCapabilityError):
        await _app(agent, make_memory_view()).start()


async def test_app_start_succeeds_for_plain_agent(
    make_memory_view: Callable[..., MemoryView],
) -> None:
    agent = Agent(name="t", instructions="i")
    await _app(agent, make_memory_view()).start()  # no raise
