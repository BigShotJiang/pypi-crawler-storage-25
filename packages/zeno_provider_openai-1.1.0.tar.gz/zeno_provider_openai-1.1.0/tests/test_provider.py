"""End-to-end happy-path tests for `OpenAIProvider.run_turn`.

These tests drive the provider against an `httpx.MockTransport` so every SSE
body, request header, and outbound request body is asserted inline.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import httpx
import pytest
from zeno.agent import Agent
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx, bind_ctx
from zeno.memory.handles import MemoryView
from zeno.observability.events import (
    ToolCallCompleted,
    ToolCallStarted,
    TurnCompleted,
    TurnStarted,
)
from zeno.providers.openai import OpenAIProvider
from zeno.testing import InMemoryConversationStore
from zeno.tool import tool


@tool
async def echo(ctx: Ctx, text: str) -> str:
    """Echo `text` back. Used as a dispatchable tool in tool-loop tests."""
    return f"echoed:{text}"


def _provider(**overrides: object) -> OpenAIProvider:
    kwargs: dict[str, object] = {"api_key": "sk-xxx", "model": "gpt-4o"}
    kwargs.update(overrides)
    return OpenAIProvider(**kwargs)  # type: ignore[arg-type]


def _text_body(sse_lines: Callable[..., bytes], *text_chunks: str) -> bytes:
    chunks = [
        json.dumps({"choices": [{"delta": {"content": t}, "finish_reason": None}]})
        for t in text_chunks
    ]
    chunks.append(json.dumps({"choices": [{"delta": {}, "finish_reason": "stop"}]}))
    chunks.append("[DONE]")
    return sse_lines(*chunks)


def _tool_body(sse_lines: Callable[..., bytes], call_id: str, name: str, arguments: str) -> bytes:
    chunks = [
        json.dumps(
            {
                "choices": [
                    {
                        "delta": {
                            "tool_calls": [
                                {
                                    "index": 0,
                                    "id": call_id,
                                    "type": "function",
                                    "function": {"name": name, "arguments": arguments},
                                }
                            ]
                        },
                        "finish_reason": None,
                    }
                ]
            }
        ),
        json.dumps({"choices": [{"delta": {}, "finish_reason": "tool_calls"}]}),
        "[DONE]",
    ]
    return sse_lines(*chunks)


def _sse_response(body: bytes) -> httpx.Response:
    return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})


async def test_happy_path_text_completion_streams_chunks_in_order(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    requests: list[httpx.Request] = []

    def handle(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return _sse_response(_text_body(sse_lines, "he", "ll", "o"))

    stream_sink: list[str] = []
    finalize_sink: list[int] = []
    async with transport_client(handle) as http:
        ctx = make_ctx(
            http=http,
            memory=make_memory_view(),
            stream_sink=stream_sink,
            finalize_sink=finalize_sink,
        )
        provider = _provider()
        with bind_ctx(ctx):
            await provider.run_turn(
                agent=Agent(name="t", instructions="i"), ctx=ctx, msg=make_msg("hi")
            )

    assert stream_sink == ["he", "ll", "o"]
    assert finalize_sink == [1]
    assert len(requests) == 1
    req = requests[0]
    assert req.method == "POST"
    assert str(req.url).endswith("/chat/completions")
    body = json.loads(req.content)
    assert body["model"] == "gpt-4o"
    assert body["stream"] is True
    assert body["messages"][-1] == {"role": "user", "content": "hi"}
    assert req.headers["Authorization"] == "Bearer sk-xxx"


async def test_composed_system_prompt_is_injected_when_set(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    captured: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return _sse_response(_text_body(sse_lines, "ok"))

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view(), composed_prompt="YOU ARE ZENO")
        with bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i"), ctx=ctx, msg=make_msg("hi")
            )

    body = captured["body"]
    assert isinstance(body, dict)
    messages = body["messages"]
    assert messages[0] == {"role": "system", "content": "YOU ARE ZENO"}


async def test_extra_headers_propagate_openrouter_surface(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    captured: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _sse_response(_text_body(sse_lines, "ok"))

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view())
        provider = _provider(
            base_url="https://openrouter.ai/api/v1",
            extra_headers={"HTTP-Referer": "https://app", "X-Title": "Zeno"},
        )
        with bind_ctx(ctx):
            await provider.run_turn(
                agent=Agent(name="t", instructions="i"), ctx=ctx, msg=make_msg("hi")
            )

    headers = captured["headers"]
    assert isinstance(headers, dict)
    assert headers["http-referer"] == "https://app"
    assert headers["x-title"] == "Zeno"


async def test_single_tool_call_dispatches_then_responds_with_text(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    call_seq: list[str] = []

    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        last_role = body["messages"][-1]["role"]
        if last_role == "tool":
            call_seq.append("second")
            return _sse_response(_text_body(sse_lines, "done"))
        call_seq.append("first")
        return _sse_response(_tool_body(sse_lines, "call_1", "echo", '{"text":"hi"}'))

    store = InMemoryConversationStore()
    stream_sink: list[str] = []
    async with transport_client(handle) as http:
        ctx = make_ctx(
            http=http,
            memory=make_memory_view(conversation_store=store),
            stream_sink=stream_sink,
        )
        agent = Agent(name="t", instructions="i", tools=[echo])
        with bind_ctx(ctx):
            await _provider().run_turn(agent=agent, ctx=ctx, msg=make_msg("say hi"))

    assert call_seq == ["first", "second"]
    assert stream_sink == ["done"]

    stored = await store.load(user_id="u1", thread_key="t1")
    roles = [m.role for m in stored]
    assert roles == ["user", "assistant", "tool", "assistant"]
    assert stored[1].tool_calls == [
        {
            "id": "call_1",
            "type": "function",
            "function": {"name": "echo", "arguments": '{"text":"hi"}'},
        }
    ]
    assert stored[2].tool_call_id == "call_1"
    assert stored[2].content == "echoed:hi"


async def test_conversation_store_round_trip_across_two_turns(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    store = InMemoryConversationStore()

    def handle(request: httpx.Request) -> httpx.Response:
        return _sse_response(_text_body(sse_lines, "ok"))

    async with transport_client(handle) as http:
        ctx1 = make_ctx(http=http, memory=make_memory_view(conversation_store=store))
        with bind_ctx(ctx1):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i"),
                ctx=ctx1,
                msg=make_msg("turn 1"),
            )

    captured: dict[str, object] = {}

    def handle2(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return _sse_response(_text_body(sse_lines, "ok2"))

    async with transport_client(handle2) as http2:
        ctx2 = make_ctx(http=http2, memory=make_memory_view(conversation_store=store))
        with bind_ctx(ctx2):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i"),
                ctx=ctx2,
                msg=make_msg("turn 2"),
            )

    body = captured["body"]
    assert isinstance(body, dict)
    roles = [m["role"] for m in body["messages"]]
    assert roles == ["user", "assistant", "user"]
    assert body["messages"][0]["content"] == "turn 1"
    assert body["messages"][1]["content"] == "ok"
    assert body["messages"][2]["content"] == "turn 2"


async def test_tracer_receives_turn_and_tool_events_in_order(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
    tracer: Any,
) -> None:
    def handle(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        if body["messages"][-1]["role"] == "tool":
            return _sse_response(_text_body(sse_lines, "done"))
        return _sse_response(_tool_body(sse_lines, "call_1", "echo", '{"text":"hi"}'))

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view(), tracer=tracer)
        agent = Agent(name="t", instructions="i", tools=[echo])
        with bind_ctx(ctx):
            await _provider().run_turn(agent=agent, ctx=ctx, msg=make_msg("hi"))

    events = tracer.events
    kinds = [type(e).__name__ for e in events]
    assert kinds[0] == TurnStarted.__name__
    assert kinds[-1] == TurnCompleted.__name__
    assert ToolCallStarted.__name__ in kinds
    assert ToolCallCompleted.__name__ in kinds
    started_idx = kinds.index(ToolCallStarted.__name__)
    completed_idx = kinds.index(ToolCallCompleted.__name__)
    assert started_idx < completed_idx


async def test_tools_are_serialised_into_request_body(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
    sse_lines: Callable[..., bytes],
) -> None:
    captured: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return _sse_response(_text_body(sse_lines, "ok"))

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view())
        with bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i", tools=[echo]),
                ctx=ctx,
                msg=make_msg("hi"),
            )

    body = captured["body"]
    assert isinstance(body, dict)
    assert "tools" in body
    names = [t["function"]["name"] for t in body["tools"]]
    assert "echo" in names


async def test_http_401_is_wrapped_in_provider_error(
    make_ctx: Callable[..., Ctx],
    make_memory_view: Callable[..., MemoryView],
    make_msg: Callable[..., IncomingMessage],
    transport_client: Callable[..., httpx.AsyncClient],
) -> None:
    from zeno.exceptions import ProviderError

    def handle(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": "invalid key"})

    async with transport_client(handle) as http:
        ctx = make_ctx(http=http, memory=make_memory_view())
        with pytest.raises(ProviderError), bind_ctx(ctx):
            await _provider().run_turn(
                agent=Agent(name="t", instructions="i"),
                ctx=ctx,
                msg=make_msg("hi"),
            )
