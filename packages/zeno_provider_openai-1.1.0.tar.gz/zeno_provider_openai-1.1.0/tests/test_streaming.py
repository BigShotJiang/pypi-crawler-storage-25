"""Unit tests for `StreamAggregator` and `aggregate_non_streaming`.

Covers text delta concatenation, tool-call aggregation by ``index``, the vLLM
missing-``type`` quirk (#16340), and the non-streaming response shape that
Ollama returns when tools are present with streaming disabled.
"""

from __future__ import annotations

import json

from zeno.providers.openai._streaming import (
    StreamAggregator,
    aggregate_non_streaming,
)


def _delta_chunk(**delta: object) -> str:
    return json.dumps({"choices": [{"delta": delta, "finish_reason": None}]})


def _finish_chunk(reason: str, **delta: object) -> str:
    return json.dumps({"choices": [{"delta": delta, "finish_reason": reason}]})


def test_text_deltas_are_concatenated_and_yielded_in_order() -> None:
    agg = StreamAggregator()
    out = [agg.feed_chunk(_delta_chunk(content=s)) for s in ("he", "l", "lo")]
    assert out == ["he", "l", "lo"]
    assert agg.response.text == "hello"


def test_terminal_chunk_updates_finish_reason() -> None:
    agg = StreamAggregator()
    agg.feed_chunk(_delta_chunk(content="hi"))
    agg.feed_chunk(_finish_chunk("stop"))
    assert agg.response.finish_reason == "stop"


def test_done_and_empty_data_are_no_ops() -> None:
    agg = StreamAggregator()
    assert agg.feed_chunk("") is None
    assert agg.feed_chunk("[DONE]") is None
    assert agg.response.text == ""
    assert agg.response.finish_reason is None


def test_tool_call_arguments_are_concatenated_across_chunks() -> None:
    agg = StreamAggregator()
    agg.feed_chunk(
        _delta_chunk(
            tool_calls=[
                {
                    "index": 0,
                    "id": "call_1",
                    "type": "function",
                    "function": {"name": "search", "arguments": '{"q'},
                }
            ]
        )
    )
    agg.feed_chunk(_delta_chunk(tool_calls=[{"index": 0, "function": {"arguments": '":"'}}]))
    agg.feed_chunk(_delta_chunk(tool_calls=[{"index": 0, "function": {"arguments": "how"}}]))
    agg.feed_chunk(_delta_chunk(tool_calls=[{"index": 0, "function": {"arguments": '"}'}}]))
    agg.feed_chunk(_finish_chunk("tool_calls"))

    assert len(agg.response.tool_calls) == 1
    tc = agg.response.tool_calls[0]
    assert tc.id == "call_1"
    assert tc.name == "search"
    assert tc.arguments == '{"q":"how"}'
    assert json.loads(tc.arguments) == {"q": "how"}


def test_missing_type_on_first_tool_call_defaults_to_function_vllm_16340() -> None:
    agg = StreamAggregator()
    agg.feed_chunk(
        _delta_chunk(
            tool_calls=[
                {
                    "index": 0,
                    "id": "call_1",
                    "function": {"name": "search", "arguments": "{}"},
                }
            ]
        )
    )
    agg.feed_chunk(_finish_chunk("tool_calls"))
    tc = agg.response.tool_calls[0]
    assert tc.type == "function"


def test_tool_call_message_entries_emit_canonical_wire_shape() -> None:
    agg = StreamAggregator()
    agg.feed_chunk(
        _delta_chunk(
            tool_calls=[
                {
                    "index": 0,
                    "id": "call_1",
                    "type": "function",
                    "function": {"name": "search", "arguments": '{"q":"a"}'},
                }
            ]
        )
    )
    entries = agg.response.tool_call_message_entries()
    assert entries == [
        {
            "id": "call_1",
            "type": "function",
            "function": {"name": "search", "arguments": '{"q":"a"}'},
        }
    ]


def test_multiple_tool_calls_by_index_are_preserved_in_order() -> None:
    agg = StreamAggregator()
    agg.feed_chunk(
        _delta_chunk(
            tool_calls=[
                {
                    "index": 0,
                    "id": "c1",
                    "type": "function",
                    "function": {"name": "a", "arguments": "{}"},
                },
                {
                    "index": 1,
                    "id": "c2",
                    "type": "function",
                    "function": {"name": "b", "arguments": "{}"},
                },
            ]
        )
    )
    agg.feed_chunk(_finish_chunk("tool_calls"))
    names = [tc.name for tc in agg.response.tool_calls]
    assert names == ["a", "b"]


def test_aggregate_non_streaming_parses_single_json_response() -> None:
    body = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "hi",
                    "tool_calls": [
                        {
                            "id": "c1",
                            "type": "function",
                            "function": {"name": "search", "arguments": '{"q":"a"}'},
                        }
                    ],
                },
                "finish_reason": "tool_calls",
            }
        ]
    }
    response = aggregate_non_streaming(body)
    assert response.text == "hi"
    assert response.finish_reason == "tool_calls"
    assert len(response.tool_calls) == 1
    tc = response.tool_calls[0]
    assert tc.id == "c1"
    assert tc.name == "search"
    assert tc.arguments == '{"q":"a"}'


def test_aggregate_non_streaming_defaults_tool_call_type_when_missing() -> None:
    body = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [
                        {
                            "id": "c1",
                            "function": {"name": "search", "arguments": "{}"},
                        }
                    ],
                },
                "finish_reason": "tool_calls",
            }
        ]
    }
    response = aggregate_non_streaming(body)
    assert response.tool_calls[0].type == "function"


def test_aggregate_non_streaming_handles_empty_choices() -> None:
    response = aggregate_non_streaming({"choices": []})
    assert response.text == ""
    assert response.tool_calls == []
