"""Public entry point for the OpenAI-compatible Zeno provider."""

from zeno.providers.openai.provider import OpenAIProvider

__all__ = ["OpenAIProvider"]
