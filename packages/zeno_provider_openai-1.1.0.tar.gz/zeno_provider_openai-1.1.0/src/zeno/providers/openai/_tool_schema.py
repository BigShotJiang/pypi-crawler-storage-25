"""Translate `ToolSpec` into the OpenAI Chat Completions ``tools[]`` shape."""

from __future__ import annotations

from typing import Any

from zeno.tool import ToolSpec


def to_openai_tool(spec: ToolSpec) -> dict[str, Any]:
    """Return the ``{"type": "function", "function": {...}}`` entry for `spec`."""
    return {
        "type": "function",
        "function": {
            "name": spec.name,
            "description": spec.description,
            "parameters": spec.schema,
        },
    }
