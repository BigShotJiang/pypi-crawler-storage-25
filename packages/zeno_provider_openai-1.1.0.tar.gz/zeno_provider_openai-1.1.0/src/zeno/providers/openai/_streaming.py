"""SSE delta aggregation for OpenAI Chat Completions `stream=true`.

The upstream contract:

- Each SSE ``data:`` line is a JSON object with shape
  ``{choices: [{delta: {...}, finish_reason: "stop" | "tool_calls" | None}]}``.
- Text content arrives as incremental ``delta.content`` strings.
- Tool calls arrive as incremental ``delta.tool_calls[i]`` entries where each
  one carries an ``index`` and some subset of ``{id, type, function.name,
  function.arguments}``. The ``arguments`` string is fragmented across many
  chunks and must be concatenated.
- vLLM quirk (#16340): the very first tool-call delta may omit ``type``. We
  default to ``"function"`` so downstream dispatch is unambiguous.
- The final chunk ``[DONE]`` is terminal — `httpx-sse` surfaces it as an event
  with ``data == "[DONE]"``.

Non-streaming (Ollama quirk): a single JSON object of shape
``{choices: [{message: {content, tool_calls, ...}, finish_reason}]}`` — use
:func:`aggregate_non_streaming` for that.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class AggregatedToolCall:
    id: str | None = None
    type: str = "function"
    name: str = ""
    arguments: str = ""

    def to_message_entry(self) -> dict[str, Any]:
        return {
            "id": self.id or "",
            "type": self.type,
            "function": {"name": self.name, "arguments": self.arguments},
        }


@dataclass
class AggregatedResponse:
    text: str = ""
    finish_reason: str | None = None
    tool_calls: list[AggregatedToolCall] = field(default_factory=list)

    def tool_call_message_entries(self) -> list[dict[str, Any]]:
        return [tc.to_message_entry() for tc in self.tool_calls]


class StreamAggregator:
    """Consume OpenAI SSE chunks and expose a single assistant response.

    Callers feed raw SSE ``data`` strings via :meth:`feed_chunk`. Text deltas
    are surfaced through the ``on_text`` callback so the provider can stream
    them to the channel. Tool-call deltas are buffered by ``index`` and
    concatenated. The terminal ``[DONE]`` frame (or an empty ``data`` line) is
    ignored by the caller.
    """

    def __init__(self) -> None:
        self.response = AggregatedResponse()
        self._by_index: dict[int, AggregatedToolCall] = {}

    def feed_chunk(self, data: str) -> str | None:
        """Process one SSE chunk. Return any newly arrived text delta or ``None``."""
        if not data or data == "[DONE]":
            return None
        payload = json.loads(data)
        choices = payload.get("choices") or []
        if not choices:
            return None
        choice = choices[0]
        delta = choice.get("delta") or {}

        new_text: str | None = None
        content = delta.get("content")
        if content:
            self.response.text += content
            new_text = content

        for tc_delta in delta.get("tool_calls") or []:
            self._apply_tool_call_delta(tc_delta)

        finish_reason = choice.get("finish_reason")
        if finish_reason is not None:
            self.response.finish_reason = finish_reason

        return new_text

    def _apply_tool_call_delta(self, delta: dict[str, Any]) -> None:
        idx = delta.get("index")
        if idx is None:
            return
        entry = self._by_index.get(idx)
        if entry is None:
            entry = AggregatedToolCall()
            self._by_index[idx] = entry
            # Insertion order matches index; subsequent deltas for the same
            # index mutate the existing entry.
            self.response.tool_calls.append(entry)
        if "id" in delta and delta["id"]:
            entry.id = delta["id"]
        if "type" in delta and delta["type"]:
            entry.type = delta["type"]
        fn = delta.get("function") or {}
        if "name" in fn and fn["name"]:
            entry.name += fn["name"]
        if "arguments" in fn and fn["arguments"] is not None:
            entry.arguments += fn["arguments"]


def aggregate_non_streaming(body: dict[str, Any]) -> AggregatedResponse:
    """Parse a non-streaming Chat Completions response into an `AggregatedResponse`."""
    choices = body.get("choices") or []
    if not choices:
        return AggregatedResponse()
    choice = choices[0]
    message = choice.get("message") or {}
    response = AggregatedResponse(
        text=message.get("content") or "",
        finish_reason=choice.get("finish_reason"),
    )
    for tc in message.get("tool_calls") or []:
        fn = tc.get("function") or {}
        response.tool_calls.append(
            AggregatedToolCall(
                id=tc.get("id"),
                type=tc.get("type") or "function",
                name=fn.get("name") or "",
                arguments=fn.get("arguments") or "",
            )
        )
    return response
