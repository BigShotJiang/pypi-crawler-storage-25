"""`OpenAIProvider` — single adapter for every OpenAI-compatible REST surface.

One provider covers OpenAI, OpenRouter, LiteLLM, Azure (v1 surface), Ollama, and
vLLM. Vendor drift is absorbed as two narrow escape hatches rather than a
plugin tree:

- ``disable_stream_with_tools=True`` — falls back to a single non-streaming
  request when tools are present (the Ollama tool-stream gap).
- ``parallel_tool_calls=True`` — runs the turn's tool calls concurrently via
  ``asyncio.gather``. The wire protocol already allows multiple tool calls per
  response; this flag toggles *how* Zeno dispatches them, not whether we send
  ``parallel_tool_calls=true`` to the server.

The provider deliberately does *not* implement retries, circuit breakers, or
response caching — those are cross-cutting concerns that belong in a
higher-level policy layer (out of scope for v0.3.0).

**Capability set**

``Capabilities(supports_sub_agents=False, supports_built_in_tools=False,
supports_permission_mode=False, supports_streaming=True)``. Any agent that
declares ``built_in_tools``, ``sub_agents``, or ``permission_mode`` trips
``ZenoApp.start()`` with a ``ProviderCapabilityError``.

**Credential redaction**

Every ``ProviderError`` raised from ``run_turn`` is routed through
``_safe_error_message`` before surfacing to ``ctx.on_turn_error``. The redactor
strips ``Authorization:`` header echoes, replaces ``api-key=/key=/token=``
query-string values with ``<redacted>``, truncates bodies to 200 characters,
and drops URL paths beyond the host. Operators see actionable errors without
leaking secrets into logs.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
import uuid
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

import httpx
from httpx_sse import aconnect_sse
from zeno.exceptions import ProviderError
from zeno.memory.protocols import ConversationMessage
from zeno.observability.events import (
    ToolCallCompleted,
    ToolCallStarted,
    TurnCompleted,
    TurnStarted,
    _Envelope,
)
from zeno.providers.openai._conversation import (
    assistant_text_message,
    assistant_tool_call_message,
    build_request_messages,
    tool_result_message,
    user_conversation_message,
)
from zeno.providers.openai._streaming import (
    AggregatedResponse,
    StreamAggregator,
    aggregate_non_streaming,
)
from zeno.providers.openai._tool_schema import to_openai_tool
from zeno.providers.protocol import Capabilities
from zeno.tool import ToolSpec

if TYPE_CHECKING:
    from zeno.agent import Agent
    from zeno.channels.messages import IncomingMessage
    from zeno.context import Ctx

logger = logging.getLogger("zeno.providers.openai")


_CAPABILITIES = Capabilities(
    supports_sub_agents=False,
    supports_built_in_tools=False,
    supports_permission_mode=False,
    supports_streaming=True,
)


class OpenAIProvider:
    """Chat Completions provider. See module docstring for scope and compatibility."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        model: str,
        extra_headers: Mapping[str, str] | None = None,
        max_tool_iterations: int = 10,
        parallel_tool_calls: bool = False,
        disable_stream_with_tools: bool = False,
        request_timeout: float = 60.0,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._extra_headers = dict(extra_headers or {})
        self._max_tool_iterations = max_tool_iterations
        self._parallel_tool_calls = parallel_tool_calls
        self._disable_stream_with_tools = disable_stream_with_tools
        self._request_timeout = request_timeout

    @property
    def capabilities(self) -> Capabilities:
        return _CAPABILITIES

    async def start(self) -> None:  # pragma: no cover — no warmup in v0.3.0
        return None

    async def stop(self) -> None:  # pragma: no cover — no persistent resources
        return None

    async def run_turn(self, *, agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        turn_id = uuid.uuid4().hex
        sequence = 0

        def _emit(event: Any) -> None:
            if ctx.tracer is not None:
                try:
                    ctx.tracer.on_event(event)
                except Exception:  # noqa: BLE001
                    logger.exception("tracer raised during OpenAIProvider emit")

        def _env() -> _Envelope:
            nonlocal sequence
            sequence += 1
            return _Envelope(
                turn_id=turn_id,
                sequence=sequence,
                user_id=ctx.user_id,
                session_id=ctx.session_id,
            )

        _emit(TurnStarted(envelope=_env(), channel=ctx.channel, thread_key=msg.thread_key))
        turn_start = time.perf_counter()
        try:
            await self._run_turn_inner(agent=agent, ctx=ctx, msg=msg, emit=_emit, env=_env)
        finally:
            _emit(
                TurnCompleted(
                    envelope=_env(),
                    duration_ms=int((time.perf_counter() - turn_start) * 1000),
                )
            )

    async def _run_turn_inner(
        self,
        *,
        agent: Agent,
        ctx: Ctx,
        msg: IncomingMessage,
        emit: Any,
        env: Any,
    ) -> None:
        specs = agent._tool_specs()
        specs_by_name = {s.name: s for s in specs}
        tools_payload: list[dict[str, Any]] = [to_openai_tool(s) for s in specs]

        composed_prompt = ctx.state.get("composed_prompt")
        prior = await ctx.memory.conversation.load()
        messages = build_request_messages(
            prior=prior, composed_prompt=composed_prompt, user_text=msg.text
        )

        new_messages: list[ConversationMessage] = [user_conversation_message(msg.text)]

        stream_default = not (tools_payload and self._disable_stream_with_tools)
        http = ctx.http

        try:
            for _iteration in range(self._max_tool_iterations):
                response = await self._one_call(
                    http=http,
                    messages=messages,
                    tools=tools_payload,
                    stream=stream_default,
                    ctx=ctx,
                )
                if not response.tool_calls:
                    if response.text:
                        new_messages.append(assistant_text_message(response.text))
                    break

                tool_calls_payload = response.tool_call_message_entries()
                assistant_msg = assistant_tool_call_message(
                    text=response.text or None, tool_calls=tool_calls_payload
                )
                new_messages.append(assistant_msg)
                messages.append(
                    {
                        "role": "assistant",
                        "content": response.text or None,
                        "tool_calls": tool_calls_payload,
                    }
                )

                tool_results = await self._dispatch_tool_calls(
                    response, specs_by_name, ctx=ctx, emit=emit, env=env
                )
                for tool_call_id, content in tool_results:
                    messages.append(
                        {"role": "tool", "tool_call_id": tool_call_id, "content": content}
                    )
                    new_messages.append(tool_result_message(tool_call_id, content))
            else:
                raise ProviderError(f"max_tool_iterations ({self._max_tool_iterations}) reached")
        except ProviderError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ProviderError(_safe_error_message(exc)) from exc
        finally:
            await ctx.finalize()

        await ctx.memory.conversation.append(new_messages)

    async def _one_call(
        self,
        *,
        http: httpx.AsyncClient,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        stream: bool,
        ctx: Ctx,
    ) -> AggregatedResponse:
        body: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "stream": stream,
        }
        if tools:
            body["tools"] = tools
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            **self._extra_headers,
        }
        url = f"{self._base_url}/chat/completions"
        if stream:
            return await self._stream_call(http=http, url=url, headers=headers, body=body, ctx=ctx)
        return await self._non_stream_call(http=http, url=url, headers=headers, body=body)

    async def _stream_call(
        self,
        *,
        http: httpx.AsyncClient,
        url: str,
        headers: dict[str, str],
        body: dict[str, Any],
        ctx: Ctx,
    ) -> AggregatedResponse:
        agg = StreamAggregator()
        async with aconnect_sse(
            http, "POST", url, json=body, headers=headers, timeout=self._request_timeout
        ) as event_source:
            event_source.response.raise_for_status()
            async for sse in event_source.aiter_sse():
                new_text = agg.feed_chunk(sse.data)
                if new_text:
                    await ctx.stream(new_text)
        return agg.response

    async def _non_stream_call(
        self,
        *,
        http: httpx.AsyncClient,
        url: str,
        headers: dict[str, str],
        body: dict[str, Any],
    ) -> AggregatedResponse:
        resp = await http.post(url, json=body, headers=headers, timeout=self._request_timeout)
        resp.raise_for_status()
        return aggregate_non_streaming(resp.json())

    async def _dispatch_tool_calls(
        self,
        response: AggregatedResponse,
        specs_by_name: dict[str, ToolSpec],
        *,
        ctx: Ctx,
        emit: Any,
        env: Any,
    ) -> list[tuple[str, str]]:
        async def _one(tc_index: int) -> tuple[str, str]:
            tc = response.tool_calls[tc_index]
            tool_call_id = tc.id or ""
            started = time.perf_counter()
            emit(ToolCallStarted(envelope=env(), tool_name=tc.name, tool_use_id=tool_call_id))
            try:
                args = _parse_arguments(tc.arguments)
            except ValueError as exc:
                emit(
                    ToolCallCompleted(
                        envelope=env(),
                        tool_name=tc.name,
                        tool_use_id=tool_call_id,
                        duration_ms=int((time.perf_counter() - started) * 1000),
                        error=True,
                    )
                )
                return tool_call_id, f"Error: could not parse arguments: {exc}"

            spec = specs_by_name.get(tc.name)
            if spec is None:
                emit(
                    ToolCallCompleted(
                        envelope=env(),
                        tool_name=tc.name,
                        tool_use_id=tool_call_id,
                        duration_ms=int((time.perf_counter() - started) * 1000),
                        error=True,
                    )
                )
                return tool_call_id, f"Error: unknown tool {tc.name!r}"

            try:
                result = await spec.handler(ctx, **args)
                emit(
                    ToolCallCompleted(
                        envelope=env(),
                        tool_name=tc.name,
                        tool_use_id=tool_call_id,
                        duration_ms=int((time.perf_counter() - started) * 1000),
                        error=False,
                    )
                )
                return tool_call_id, _stringify_tool_result(result)
            except Exception as exc:  # noqa: BLE001 — every tool error wraps (KD10)
                emit(
                    ToolCallCompleted(
                        envelope=env(),
                        tool_name=tc.name,
                        tool_use_id=tool_call_id,
                        duration_ms=int((time.perf_counter() - started) * 1000),
                        error=True,
                    )
                )
                return tool_call_id, f"Error: {exc}"

        indices = list(range(len(response.tool_calls)))
        if self._parallel_tool_calls:
            return list(await asyncio.gather(*(_one(i) for i in indices)))
        results: list[tuple[str, str]] = []
        for i in indices:
            results.append(await _one(i))
        return results


def _parse_arguments(raw: str) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(str(exc)) from exc
    if not isinstance(parsed, dict):
        raise ValueError(f"expected JSON object, got {type(parsed).__name__}")
    return parsed


def _stringify_tool_result(result: Any) -> str:
    if isinstance(result, str):
        return result
    try:
        return json.dumps(result, default=str)
    except (TypeError, ValueError):
        return str(result)


_API_KEY_QS_PATTERN = re.compile(r"(?i)(api[-_]?key|key|token)=([^&\s]+)")
_AUTH_HEADER_PATTERN = re.compile(r"(?i)authorization\s*[:=]\s*(?:bearer\s+)?[A-Za-z0-9._\-]+")


def _safe_error_message(exc: BaseException, *, max_body: int = 200) -> str:
    """Return a redacted one-line error message safe for logs and tracers."""
    message = str(exc)
    request_url: str | None = None
    response_excerpt: str | None = None
    if isinstance(exc, httpx.HTTPStatusError):
        request_url = str(exc.request.url) if exc.request else None
        try:
            body = exc.response.text
        except Exception:  # noqa: BLE001
            body = ""
        response_excerpt = body[:max_body] if body else None

    redacted_message = _AUTH_HEADER_PATTERN.sub("Authorization: <redacted>", message)
    redacted_message = _API_KEY_QS_PATTERN.sub(r"\1=<redacted>", redacted_message)

    parts: list[str] = [_shorten(redacted_message, max_body)]
    if request_url is not None:
        parts.append(f"url={_sanitize_url(request_url)}")
    if response_excerpt:
        parts.append(f"body={_API_KEY_QS_PATTERN.sub(r'\1=<redacted>', response_excerpt)}")
    return "; ".join(parts)


def _sanitize_url(url: str) -> str:
    try:
        parsed = httpx.URL(url)
    except Exception:  # noqa: BLE001
        return "<redacted-url>"
    host = parsed.host or "<unknown>"
    scheme = parsed.scheme or "https"
    return f"{scheme}://{host}"


def _shorten(text: str, cap: int) -> str:
    if len(text) <= cap:
        return text
    return text[: cap - 1] + "…"
