"""Conversation store helpers: protocol messages <-> OpenAI `messages[]`.

The OpenAI Chat Completions request body carries an array of messages shaped:

    {"role": "system" | "user" | "assistant" | "tool",
     "content": str | null,
     "tool_calls": [{"id": str, "type": "function",
                     "function": {"name": str, "arguments": str}}]?,
     "tool_call_id": str?}

Zeno's `ConversationMessage` mirrors that shape. These helpers convert in
both directions and build the per-turn messages array, including the
composed system prompt (if any) and the current inbound user message.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, cast

from zeno.memory.protocols import ConversationMessage


def to_openai_message(msg: ConversationMessage) -> dict[str, Any]:
    """Serialize a `ConversationMessage` into an OpenAI messages[] entry."""
    entry: dict[str, Any] = {"role": msg.role, "content": msg.content}
    if msg.tool_calls:
        entry["tool_calls"] = list(msg.tool_calls)
    if msg.tool_call_id:
        entry["tool_call_id"] = msg.tool_call_id
    return entry


def build_request_messages(
    *,
    prior: list[ConversationMessage],
    composed_prompt: str | None,
    user_text: str,
) -> list[dict[str, Any]]:
    """Assemble the `messages[]` array for a Chat Completions request."""
    out: list[dict[str, Any]] = []
    if composed_prompt:
        out.append({"role": "system", "content": composed_prompt})
    out.extend(to_openai_message(m) for m in prior)
    out.append({"role": "user", "content": user_text})
    return out


def user_conversation_message(text: str) -> ConversationMessage:
    return ConversationMessage(
        role="user",
        content=text,
        tool_calls=None,
        tool_call_id=None,
        created_at=_now(),
    )


def assistant_text_message(text: str) -> ConversationMessage:
    return ConversationMessage(
        role="assistant",
        content=text,
        tool_calls=None,
        tool_call_id=None,
        created_at=_now(),
    )


def assistant_tool_call_message(
    text: str | None, tool_calls: list[dict[str, Any]]
) -> ConversationMessage:
    return ConversationMessage(
        role="assistant",
        content=text,
        tool_calls=tool_calls,
        tool_call_id=None,
        created_at=_now(),
    )


def tool_result_message(tool_call_id: str, content: str) -> ConversationMessage:
    return ConversationMessage(
        role="tool",
        content=content,
        tool_calls=None,
        tool_call_id=tool_call_id,
        created_at=_now(),
    )


def _now() -> datetime:
    return datetime.now(UTC)


def cast_tool_calls(value: Any) -> list[dict[str, Any]]:
    """Narrow a potentially-Any tool_calls list for typed downstream access."""
    return cast(list[dict[str, Any]], list(value))
