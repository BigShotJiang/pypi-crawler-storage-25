"""
Tests for `devtorch setup` — the one-command Claude Code onboarding flow.

Covers:
- Fresh project: all 4 steps run (including AGENTS.md for Antigravity)
- Idempotency: running setup twice doesn't duplicate entries
- --skip-claude-md flag
- --skip-agents-md flag
- Partial state: already-initialized .GCC/ doesn't re-init
- MCP entry merged without clobbering existing settings.json keys
- CLAUDE.md appended to (not overwritten) when it already exists
- CLAUDE.md not written when marker already present
- AGENTS.md created / appended / not duplicated
- Return code 0 on success, 1 on init failure
"""

from __future__ import annotations

import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

from devtorch_cli.main import cmd_setup


def _args(
    path: str,
    skip_claude_md: bool = False,
    skip_agents_md: bool = False,
) -> types.SimpleNamespace:
    return types.SimpleNamespace(
        path=path,
        skip_claude_md=skip_claude_md,
        skip_agents_md=skip_agents_md,
    )


def _make_initialized_gcc(root: Path) -> None:
    """Simulate an already-initialized .GCC/ so is_initialized() returns True."""
    gcc = root / ".GCC"
    gcc.mkdir(parents=True, exist_ok=True)
    (gcc / "VERSION").write_text("gcc-v0", encoding="utf-8")
    (gcc / "events.log.jsonl").write_text("", encoding="utf-8")


class TestSetupFreshProject(unittest.TestCase):
    """All 5 steps run on a clean directory (including AGENTS.md)."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _run(self, skip_claude_md=False, skip_agents_md=False):
        with patch("devtorch_core.hooks.installer.install_git_commit_hook",
                   return_value=(False, "no .git found")):
            return cmd_setup(_args(str(self.root), skip_claude_md=skip_claude_md,
                                   skip_agents_md=skip_agents_md))

    def test_returns_zero_on_success(self):
        self.assertEqual(self._run(), 0)

    def test_gcc_dir_created(self):
        self._run()
        self.assertTrue((self.root / ".GCC").exists())

    def test_hooks_json_created(self):
        self._run()
        self.assertTrue((self.root / ".claude" / "hooks.json").exists())

    def test_hooks_json_has_posttooluse(self):
        self._run()
        data = json.loads((self.root / ".claude" / "hooks.json").read_text())
        self.assertIn("PostToolUse", data["hooks"])

    def test_settings_json_created(self):
        self._run()
        self.assertTrue((self.root / ".claude" / "settings.json").exists())

    def test_settings_json_has_mcp_entry(self):
        self._run()
        data = json.loads((self.root / ".claude" / "settings.json").read_text())
        self.assertIn("devtorch", data["mcpServers"])

    def test_settings_mcp_command_is_devtorch(self):
        self._run()
        data = json.loads((self.root / ".claude" / "settings.json").read_text())
        self.assertEqual(data["mcpServers"]["devtorch"]["command"], "devtorch")

    def test_settings_mcp_args(self):
        self._run()
        data = json.loads((self.root / ".claude" / "settings.json").read_text())
        self.assertEqual(data["mcpServers"]["devtorch"]["args"], ["mcp-server"])

    def test_claude_md_created(self):
        self._run()
        self.assertTrue((self.root / "CLAUDE.md").exists())

    def test_claude_md_contains_devtorch_section(self):
        self._run()
        content = (self.root / "CLAUDE.md").read_text(encoding="utf-8")
        self.assertIn("## DevTorch", content)

    def test_claude_md_contains_commit_instruction(self):
        self._run()
        content = (self.root / "CLAUDE.md").read_text(encoding="utf-8")
        self.assertIn("devtorch_commit", content)

    def test_skip_claude_md_flag(self):
        self._run(skip_claude_md=True)
        # CLAUDE.md should NOT be created (or at minimum not contain the marker)
        claude_md = self.root / "CLAUDE.md"
        if claude_md.exists():
            self.assertNotIn("## DevTorch", claude_md.read_text(encoding="utf-8"))
        else:
            self.assertFalse(claude_md.exists())


class TestSetupIdempotency(unittest.TestCase):
    """Running setup twice produces the same state, no duplicates."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _run(self):
        with patch("devtorch_core.hooks.installer.install_git_commit_hook",
                   return_value=(False, "no .git found")):
            return cmd_setup(_args(str(self.root)))

    def test_second_run_returns_zero(self):
        self._run()
        self.assertEqual(self._run(), 0)

    def test_mcp_entry_not_duplicated(self):
        self._run()
        self._run()
        data = json.loads((self.root / ".claude" / "settings.json").read_text())
        # There should be exactly one devtorch key, not two
        self.assertEqual(list(data["mcpServers"].keys()).count("devtorch"), 1)

    def test_hooks_not_duplicated(self):
        self._run()
        self._run()
        data = json.loads((self.root / ".claude" / "hooks.json").read_text())
        # PostToolUse list should have exactly one devtorch entry
        post = data["hooks"]["PostToolUse"]
        all_cmds = [
            h["command"]
            for entry in post
            for h in entry.get("hooks", [])
        ]
        devtorch_cmds = [c for c in all_cmds if "devtorch" in c]
        self.assertEqual(len(devtorch_cmds), 1)

    def test_claude_md_section_not_duplicated(self):
        self._run()
        self._run()
        content = (self.root / "CLAUDE.md").read_text(encoding="utf-8")
        self.assertEqual(content.count("## DevTorch"), 1)


class TestSetupPartialState(unittest.TestCase):
    """Setup handles projects that are already partially configured."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _run(self, **kwargs):
        with patch("devtorch_core.hooks.installer.install_git_commit_hook",
                   return_value=(False, "no .git found")):
            return cmd_setup(_args(str(self.root), **kwargs))

    def test_already_initialized_gcc_skipped(self):
        _make_initialized_gcc(self.root)
        # Should not raise even though .GCC/ exists
        rc = self._run()
        self.assertEqual(rc, 0)

    def test_existing_settings_json_keys_preserved(self):
        """setup must not clobber existing settings.json keys."""
        claude_dir = self.root / ".claude"
        claude_dir.mkdir()
        settings = {"theme": "dark", "mcpServers": {"other-tool": {"command": "other"}}}
        (claude_dir / "settings.json").write_text(json.dumps(settings), encoding="utf-8")

        self._run()

        data = json.loads((claude_dir / "settings.json").read_text())
        self.assertEqual(data.get("theme"), "dark")
        self.assertIn("other-tool", data["mcpServers"])
        self.assertIn("devtorch", data["mcpServers"])

    def test_existing_claude_md_gets_section_appended(self):
        """setup appends to existing CLAUDE.md without overwriting it."""
        existing_content = "# My Project\n\nSome existing instructions.\n"
        (self.root / "CLAUDE.md").write_text(existing_content, encoding="utf-8")

        self._run()

        content = (self.root / "CLAUDE.md").read_text(encoding="utf-8")
        self.assertIn("# My Project", content)
        self.assertIn("Some existing instructions.", content)
        self.assertIn("## DevTorch", content)

    def test_existing_claude_md_with_marker_not_appended(self):
        """If CLAUDE.md already has ## DevTorch, setup does not append again."""
        existing = "# My Project\n\n## DevTorch\n\nAlready configured.\n"
        (self.root / "CLAUDE.md").write_text(existing, encoding="utf-8")

        self._run()

        content = (self.root / "CLAUDE.md").read_text(encoding="utf-8")
        self.assertEqual(content.count("## DevTorch"), 1)
        self.assertIn("Already configured.", content)


class TestSetupAgentsMd(unittest.TestCase):
    """Tests for AGENTS.md creation (Google Antigravity support)."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _run(self, skip_agents_md=False, skip_claude_md=False):
        with patch("devtorch_core.hooks.installer.install_git_commit_hook",
                   return_value=(False, "no .git found")):
            return cmd_setup(_args(str(self.root), skip_claude_md=skip_claude_md,
                                   skip_agents_md=skip_agents_md))

    def test_agents_md_created(self):
        """AGENTS.md exists after setup."""
        self._run()
        self.assertTrue((self.root / "AGENTS.md").exists())

    def test_agents_md_contains_devtorch_section(self):
        """AGENTS.md contains the ## DevTorch marker."""
        self._run()
        content = (self.root / "AGENTS.md").read_text(encoding="utf-8")
        self.assertIn("## DevTorch", content)

    def test_agents_md_section_not_duplicated(self):
        """Running setup twice doesn't duplicate the ## DevTorch section."""
        self._run()
        self._run()
        content = (self.root / "AGENTS.md").read_text(encoding="utf-8")
        self.assertEqual(content.count("## DevTorch"), 1)

    def test_skip_agents_md_flag(self):
        """--skip-agents-md prevents writing AGENTS.md."""
        self._run(skip_agents_md=True)
        agents_md = self.root / "AGENTS.md"
        if agents_md.exists():
            self.assertNotIn("## DevTorch", agents_md.read_text(encoding="utf-8"))
        else:
            self.assertFalse(agents_md.exists())

    def test_existing_agents_md_appended(self):
        """Existing AGENTS.md content is preserved when DevTorch section is added."""
        existing_content = "# My Project Agents\n\nSome existing agent instructions.\n"
        (self.root / "AGENTS.md").write_text(existing_content, encoding="utf-8")

        self._run()

        content = (self.root / "AGENTS.md").read_text(encoding="utf-8")
        self.assertIn("# My Project Agents", content)
        self.assertIn("Some existing agent instructions.", content)
        self.assertIn("## DevTorch", content)


class TestSetupCLIWiring(unittest.TestCase):
    """Verify the setup subcommand is registered in build_parser()."""

    def test_setup_subcommand_exists(self):
        from devtorch_cli.main import build_parser
        parser = build_parser()
        # Should not raise — setup is a valid subcommand
        args = parser.parse_args(["setup"])
        self.assertEqual(args.command, "setup")

    def test_setup_skip_claude_md_flag(self):
        from devtorch_cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args(["setup", "--skip-claude-md"])
        self.assertTrue(args.skip_claude_md)

    def test_setup_skip_claude_md_default_false(self):
        from devtorch_cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args(["setup"])
        self.assertFalse(args.skip_claude_md)

    def test_setup_skip_agents_md_flag(self):
        from devtorch_cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args(["setup", "--skip-agents-md"])
        self.assertTrue(args.skip_agents_md)

    def test_setup_skip_agents_md_default_false(self):
        from devtorch_cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args(["setup"])
        self.assertFalse(args.skip_agents_md)
