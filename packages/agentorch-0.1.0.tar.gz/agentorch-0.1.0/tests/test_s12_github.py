"""
Sprint 12 — GitHub App + CI/CD integration tests.

Coverage:
  - TestParsePRBody       (10 tests)
  - TestBuildPRComment    (10 tests)
  - TestWebhookApp        (6 tests)
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
from unittest.mock import patch

import pytest

from devtorch_core.github import (
    GovernanceSummary,
    PRMetadata,
    build_pr_comment,
    parse_pr_body,
)
from devtorch_core.github.pr_parser import parse_pr_body as _parse_pr_body


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_summary(**kwargs) -> GovernanceSummary:
    defaults = dict(
        branch="feature/auth",
        node_state="ACTIVE",
        top_concepts=[("auth_flow", 0.91), ("rbac", 0.75)],
        sensitivity_count=3,
        high_disclosure_count=0,
        mcs_score=0.87,
        invariants_ok=True,
        lock_status="unlocked",
    )
    defaults.update(kwargs)
    return GovernanceSummary(**defaults)


# ─────────────────────────────────────────────────────────────────────────────
# TestParsePRBody
# ─────────────────────────────────────────────────────────────────────────────

class TestParsePRBody:
    def test_empty_body_returns_defaults(self):
        meta = parse_pr_body("")
        assert meta.branch == ""
        assert meta.commit_ids == []
        assert meta.sensitivity_refs == []
        assert meta.concept_refs == []
        assert meta.mcs_score is None
        assert meta.has_devtorch_section is False

    def test_none_like_empty_string(self):
        # Ensure robustness — falsy body
        meta = parse_pr_body("")
        assert isinstance(meta, PRMetadata)

    def test_devtorch_h2_heading_detected(self):
        body = "Some intro\n\n## DevTorch\n\nSome content"
        meta = parse_pr_body(body)
        assert meta.has_devtorch_section is True

    def test_devtorch_h3_heading_detected(self):
        body = "Some intro\n\n### DevTorch Governance\n\nSome content"
        meta = parse_pr_body(body)
        assert meta.has_devtorch_section is True

    def test_no_devtorch_heading(self):
        body = "This PR fixes a bug.\n\nSee the description."
        meta = parse_pr_body(body)
        assert meta.has_devtorch_section is False

    def test_commit_ids_extracted(self):
        sha = "a" * 40
        body = f"This commit {sha} is included."
        meta = parse_pr_body(body)
        assert sha in meta.commit_ids

    def test_multiple_commit_ids(self):
        sha1 = "a" * 40
        sha2 = "b" * 40
        body = f"Commits: {sha1} and {sha2}"
        meta = parse_pr_body(body)
        assert sha1 in meta.commit_ids
        assert sha2 in meta.commit_ids

    def test_sensitivity_ref_extracted(self):
        uid = "550e8400-e29b-41d4-a716-446655440000"
        body = f"Sensitivity: [SENSITIVITY:{uid}]"
        meta = parse_pr_body(body)
        assert uid in meta.sensitivity_refs

    def test_multiple_sensitivity_refs(self):
        uid1 = "550e8400-e29b-41d4-a716-446655440001"
        uid2 = "550e8400-e29b-41d4-a716-446655440002"
        body = f"[SENSITIVITY:{uid1}] and [SENSITIVITY:{uid2}]"
        meta = parse_pr_body(body)
        assert uid1 in meta.sensitivity_refs
        assert uid2 in meta.sensitivity_refs
        assert len(meta.sensitivity_refs) == 2

    def test_concept_ref_extracted(self):
        body = "This touches [CONCEPT:auth_flow] and [CONCEPT:rbac]."
        meta = parse_pr_body(body)
        assert "auth_flow" in meta.concept_refs
        assert "rbac" in meta.concept_refs

    def test_mcs_score_extracted(self):
        body = "## DevTorch\n\nMCS: 0.87\n"
        meta = parse_pr_body(body)
        assert meta.mcs_score == pytest.approx(0.87)

    def test_invalid_mcs_text_returns_none(self):
        # Non-numeric after MCS: should not crash; no valid float → None
        body = "MCS: great"
        meta = parse_pr_body(body)
        assert meta.mcs_score is None

    def test_branch_extracted_from_backtick_pattern(self):
        body = "Branch: `feature/auth-overhaul`\n\nSome details."
        meta = parse_pr_body(body)
        assert meta.branch == "feature/auth-overhaul"

    def test_branch_empty_when_missing(self):
        body = "No branch info here."
        meta = parse_pr_body(body)
        assert meta.branch == ""

    def test_mixed_content_pr_body(self):
        sha = "c" * 40
        uid = "550e8400-e29b-41d4-a716-446655440003"
        body = (
            f"Branch: `feature/payments`\n\n"
            f"## DevTorch\n\n"
            f"MCS: 0.72\n\n"
            f"Commit: {sha}\n\n"
            f"[SENSITIVITY:{uid}]\n"
            f"[CONCEPT:payment_flow]\n"
        )
        meta = parse_pr_body(body)
        assert meta.branch == "feature/payments"
        assert meta.has_devtorch_section is True
        assert meta.mcs_score == pytest.approx(0.72)
        assert sha in meta.commit_ids
        assert uid in meta.sensitivity_refs
        assert "payment_flow" in meta.concept_refs


# ─────────────────────────────────────────────────────────────────────────────
# TestBuildPRComment
# ─────────────────────────────────────────────────────────────────────────────

class TestBuildPRComment:
    def test_returns_nonempty_string(self):
        comment = build_pr_comment(_make_summary())
        assert isinstance(comment, str)
        assert len(comment) > 0

    def test_contains_governance_report_header(self):
        comment = build_pr_comment(_make_summary())
        assert "DevTorch Governance Report" in comment

    def test_contains_branch_name(self):
        comment = build_pr_comment(_make_summary(branch="feature/auth"))
        assert "feature/auth" in comment

    def test_contains_node_state(self):
        comment = build_pr_comment(_make_summary(node_state="QUORUM"))
        assert "QUORUM" in comment

    def test_contains_mcs_score_when_provided(self):
        comment = build_pr_comment(_make_summary(mcs_score=0.93))
        assert "0.93" in comment

    def test_mcs_na_when_none(self):
        comment = build_pr_comment(_make_summary(mcs_score=None))
        assert "N/A" in comment

    def test_warning_block_when_invariants_fail(self):
        comment = build_pr_comment(_make_summary(invariants_ok=False))
        assert "Invariant check failed" in comment or "⚠️" in comment

    def test_no_warning_when_invariants_ok(self):
        comment = build_pr_comment(_make_summary(invariants_ok=True))
        assert "Invariant check failed" not in comment

    def test_high_disclosure_note_when_count_positive(self):
        comment = build_pr_comment(_make_summary(high_disclosure_count=3))
        assert "🔒" in comment or "high-disclosure" in comment

    def test_no_high_disclosure_note_when_zero(self):
        comment = build_pr_comment(_make_summary(high_disclosure_count=0))
        assert "high-disclosure" not in comment

    def test_top_concepts_appear_in_output(self):
        concepts = [("auth_flow", 0.91), ("rbac", 0.75)]
        comment = build_pr_comment(_make_summary(top_concepts=concepts))
        assert "auth_flow" in comment
        assert "rbac" in comment

    def test_lock_note_when_locked(self):
        comment = build_pr_comment(_make_summary(lock_status="locked"))
        assert "lock" in comment.lower()

    def test_footer_present(self):
        comment = build_pr_comment(_make_summary())
        assert "Generated by DevTorch" in comment

    def test_footer_contains_docs_link(self):
        comment = build_pr_comment(_make_summary())
        assert "https://github.com/flotorch-ai/devtorch" in comment

    def test_pr_metadata_section_included_when_has_devtorch(self):
        meta = parse_pr_body(
            "Branch: `feature/x`\n## DevTorch\n[CONCEPT:auth_flow]\nMCS: 0.80\n"
        )
        comment = build_pr_comment(_make_summary(), pr_metadata=meta)
        assert "DevTorch PR Metadata" in comment

    def test_pr_metadata_section_omitted_when_no_devtorch(self):
        meta = parse_pr_body("No special content here.")
        comment = build_pr_comment(_make_summary(), pr_metadata=meta)
        assert "DevTorch PR Metadata" not in comment


# ─────────────────────────────────────────────────────────────────────────────
# TestWebhookApp
# ─────────────────────────────────────────────────────────────────────────────

# We import FastAPI/starlette test client only if available.
try:
    from starlette.testclient import TestClient
    from devtorch_core.github.app import HAS_FASTAPI, _build_app

    _FASTAPI_AVAILABLE = HAS_FASTAPI
except ImportError:
    _FASTAPI_AVAILABLE = False


def _make_signature(secret: str, payload: bytes) -> str:
    return "sha256=" + hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()


def _pr_event_payload(action: str = "opened") -> bytes:
    event = {
        "action": action,
        "pull_request": {
            "number": 42,
            "body": (
                "Branch: `feature/test`\n\n"
                "## DevTorch\n\n"
                "MCS: 0.88\n"
            ),
        },
    }
    return json.dumps(event).encode()


@pytest.mark.skipif(not _FASTAPI_AVAILABLE, reason="FastAPI not installed")
class TestWebhookApp:
    """Integration tests for the FastAPI webhook receiver."""

    @pytest.fixture()
    def client(self):
        app = _build_app()
        return TestClient(app, raise_server_exceptions=True)

    def test_missing_secret_returns_webhook_not_configured(self, client):
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("DEVTORCH_GITHUB_WEBHOOK_SECRET", None)
            payload = b"{}"
            resp = client.post(
                "/webhook/github",
                content=payload,
                headers={"X-GitHub-Event": "pull_request"},
            )
        assert resp.status_code == 200
        assert resp.json()["status"] == "webhook_secret_not_configured"

    def test_invalid_signature_returns_401(self, client):
        secret = "test-secret-abc"
        with patch.dict(os.environ, {"DEVTORCH_GITHUB_WEBHOOK_SECRET": secret}):
            payload = b'{"action":"opened"}'
            resp = client.post(
                "/webhook/github",
                content=payload,
                headers={
                    "X-GitHub-Event": "pull_request",
                    "X-Hub-Signature-256": "sha256=badhash",
                },
            )
        assert resp.status_code == 401

    def test_non_pr_event_returns_ignored(self, client):
        secret = "test-secret-abc"
        payload = b'{"action":"created"}'
        sig = _make_signature(secret, payload)
        with patch.dict(os.environ, {"DEVTORCH_GITHUB_WEBHOOK_SECRET": secret}):
            resp = client.post(
                "/webhook/github",
                content=payload,
                headers={
                    "X-GitHub-Event": "push",
                    "X-Hub-Signature-256": sig,
                },
            )
        assert resp.status_code == 200
        assert resp.json()["status"] == "ignored"

    def test_pr_opened_returns_ok(self, client):
        secret = "test-secret-abc"
        payload = _pr_event_payload("opened")
        sig = _make_signature(secret, payload)
        with patch.dict(os.environ, {"DEVTORCH_GITHUB_WEBHOOK_SECRET": secret}):
            resp = client.post(
                "/webhook/github",
                content=payload,
                headers={
                    "X-GitHub-Event": "pull_request",
                    "X-Hub-Signature-256": sig,
                },
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "metadata" in data
        assert data["metadata"]["branch"] == "feature/test"
        assert data["metadata"]["mcs_score"] == pytest.approx(0.88)

    def test_pr_synchronize_returns_ok(self, client):
        secret = "test-secret-abc"
        payload = _pr_event_payload("synchronize")
        sig = _make_signature(secret, payload)
        with patch.dict(os.environ, {"DEVTORCH_GITHUB_WEBHOOK_SECRET": secret}):
            resp = client.post(
                "/webhook/github",
                content=payload,
                headers={
                    "X-GitHub-Event": "pull_request",
                    "X-Hub-Signature-256": sig,
                },
            )
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"

    def test_pr_closed_returns_ignored(self, client):
        secret = "test-secret-abc"
        payload = _pr_event_payload("closed")
        sig = _make_signature(secret, payload)
        with patch.dict(os.environ, {"DEVTORCH_GITHUB_WEBHOOK_SECRET": secret}):
            resp = client.post(
                "/webhook/github",
                content=payload,
                headers={
                    "X-GitHub-Event": "pull_request",
                    "X-Hub-Signature-256": sig,
                },
            )
        assert resp.status_code == 200
        assert resp.json()["status"] == "ignored"
