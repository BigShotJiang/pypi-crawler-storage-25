"""
Sprint 17b — Observability and Enterprise Reporting tests.

Covers:
  TestObservabilityReport  (5 tests)  — build_report, report_to_dict
  TestFormatMarkdown       (8 tests)  — format_report_markdown
  TestFormatJSON           (3 tests)  — format_report_json
  TestWebhookConfig        (5 tests)  — load_webhook_config, build_webhook_payload
  TestSendWebhook          (5 tests)  — send_webhook (mocked urllib)
  TestSendMetricsIfConfigured (4 tests) — end-to-end convenience helper
"""

from __future__ import annotations

import dataclasses
import json
import os
import unittest.mock as mock
from pathlib import Path
from typing import Any
import urllib.error

import pytest

from devtorch_core.observability import (
    ObservabilityReport,
    ReportTimeRange,
    build_report,
    report_to_dict,
    format_report_markdown,
    format_report_json,
    WebhookConfig,
    WebhookPayload,
    WebhookResult,
    load_webhook_config,
    build_webhook_payload,
    send_webhook,
    send_metrics_if_configured,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_gcc_repo(tmp_path: Path):
    """Initialise a real GCCRepository at tmp_path."""
    from devtorch_core.gcc import GCCRepository
    repo = GCCRepository(tmp_path)
    repo.init()
    return repo


def _make_minimal_report(**overrides) -> ObservabilityReport:
    """Return a minimal valid ObservabilityReport with optional overrides."""
    defaults = dict(
        generated_at="2026-04-18T12:00:00+00:00",
        gcc_version="gcc-v0",
        node_state="idle",
        branch="main",
        commit_count=42,
        sensitivity_event_count=18,
        high_disclosure_count=3,
        theta_top_concepts=[
            {"concept": "auth_token", "mean_confidence": 0.95},
            {"concept": "pii_email", "mean_confidence": 0.88},
        ],
        capability_state={"textual_mode_allowed": True, "lipschitz_bound": 1.5},
        variance_state={"f_max": 2, "alert_count": 1, "deterministic_mode": False},
        rdp_budget={"epsilon_used": 0.3, "epsilon_max": 1.0, "read_only": False},
        branch_count=4,
        sis_quarantine_count=2,
        period=None,
    )
    defaults.update(overrides)
    return ObservabilityReport(**defaults)


def _make_webhook_config(**overrides) -> WebhookConfig:
    defaults = dict(
        endpoint_url="https://metrics.example.com/devtorch",
        org_id="org-test-123",
        api_key="secret-key",
        timeout_seconds=5,
    )
    defaults.update(overrides)
    return WebhookConfig(**defaults)


# ---------------------------------------------------------------------------
# TestObservabilityReport
# ---------------------------------------------------------------------------

class TestObservabilityReport:
    def test_build_report_returns_observability_report(self, tmp_path: Path) -> None:
        """build_report returns an ObservabilityReport instance."""
        repo = _make_gcc_repo(tmp_path)
        report = build_report(repo)
        assert isinstance(report, ObservabilityReport)

    def test_generated_at_is_nonempty_string(self, tmp_path: Path) -> None:
        """generated_at is a non-empty ISO timestamp string."""
        repo = _make_gcc_repo(tmp_path)
        report = build_report(repo)
        assert isinstance(report.generated_at, str)
        assert len(report.generated_at) > 0

    def test_build_report_never_raises_on_broken_repo(self) -> None:
        """build_report never raises even when all gcc_repo calls raise."""

        class BrokenRepo:
            """Mock gcc_repo where every attribute access raises."""
            def __getattr__(self, name: str) -> Any:
                raise RuntimeError(f"Broken repo: cannot access {name!r}")

        # Should not raise — the BrokenRepo will trigger exceptions when
        # the report builder tries to access gcc_repo.gcc_dir.  We wrap
        # gcc_dir as a broken Path-like object.
        class BrokenPath:
            def __truediv__(self, _: Any) -> "BrokenPath":
                return self

            def exists(self) -> bool:
                raise OSError("disk failure")

            def iterdir(self):
                raise OSError("disk failure")

            def open(self, *_a, **_kw):
                raise OSError("disk failure")

            def read_text(self, *_a, **_kw) -> str:
                raise OSError("disk failure")

            def glob(self, *_a):
                raise OSError("disk failure")

            def is_file(self) -> bool:
                raise OSError("disk failure")

        class SafeBrokenRepo:
            gcc_dir = BrokenPath()

        report = build_report(SafeBrokenRepo())
        assert isinstance(report, ObservabilityReport)

    def test_report_to_dict_returns_dict(self, tmp_path: Path) -> None:
        """report_to_dict returns a plain dict."""
        repo = _make_gcc_repo(tmp_path)
        report = build_report(repo)
        d = report_to_dict(report)
        assert isinstance(d, dict)

    def test_report_to_dict_is_json_serializable(self, tmp_path: Path) -> None:
        """report_to_dict result can be serialised with json.dumps without error."""
        repo = _make_gcc_repo(tmp_path)
        report = build_report(repo)
        d = report_to_dict(report)
        serialized = json.dumps(d)
        assert isinstance(serialized, str)
        # Round-trip check
        parsed = json.loads(serialized)
        assert isinstance(parsed, dict)


# ---------------------------------------------------------------------------
# TestFormatMarkdown
# ---------------------------------------------------------------------------

class TestFormatMarkdown:
    def test_returns_nonempty_string(self) -> None:
        """format_report_markdown returns a non-empty string."""
        report = _make_minimal_report()
        result = format_report_markdown(report)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_contains_devtorch_governance_report(self) -> None:
        """Output contains the top-level heading."""
        report = _make_minimal_report()
        result = format_report_markdown(report)
        assert "DevTorch Governance Report" in result

    def test_contains_branch_name(self) -> None:
        """Output contains the branch name from the report."""
        report = _make_minimal_report(branch="feature/auth-refactor")
        result = format_report_markdown(report)
        assert "feature/auth-refactor" in result

    def test_contains_commit_count(self) -> None:
        """Output contains the commit count value."""
        report = _make_minimal_report(commit_count=99)
        result = format_report_markdown(report)
        assert "99" in result

    def test_contains_sensitivity_event_count(self) -> None:
        """Output contains the sensitivity event count."""
        report = _make_minimal_report(sensitivity_event_count=77)
        result = format_report_markdown(report)
        assert "77" in result

    def test_contains_top_concept_name(self) -> None:
        """Output contains the name of the top theta concept."""
        report = _make_minimal_report(
            theta_top_concepts=[{"concept": "pii_ssn", "mean_confidence": 0.99}]
        )
        result = format_report_markdown(report)
        assert "pii_ssn" in result

    def test_contains_rdp_epsilon_section(self) -> None:
        """Output contains epsilon (RDP) usage information."""
        report = _make_minimal_report(
            rdp_budget={"epsilon_used": 0.42, "epsilon_max": 1.0, "read_only": False}
        )
        result = format_report_markdown(report)
        # The formatter emits "ε used: ..." or similar
        assert "0.4200" in result or "0.42" in result

    def test_contains_summary_heading(self) -> None:
        """Output contains the ## Summary section heading."""
        report = _make_minimal_report()
        result = format_report_markdown(report)
        assert "## Summary" in result


# ---------------------------------------------------------------------------
# TestFormatJSON
# ---------------------------------------------------------------------------

class TestFormatJSON:
    def test_returns_valid_json_string(self) -> None:
        """format_report_json returns a string that parses as JSON."""
        report = _make_minimal_report()
        result = format_report_json(report)
        assert isinstance(result, str)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)

    def test_parsed_result_has_commit_count_key(self) -> None:
        """Parsed JSON result has commit_count key."""
        report = _make_minimal_report(commit_count=55)
        parsed = json.loads(format_report_json(report))
        assert "commit_count" in parsed
        assert parsed["commit_count"] == 55

    def test_parsed_result_has_generated_at_key(self) -> None:
        """Parsed JSON result has generated_at key."""
        report = _make_minimal_report(generated_at="2026-04-18T10:00:00Z")
        parsed = json.loads(format_report_json(report))
        assert "generated_at" in parsed
        assert parsed["generated_at"] == "2026-04-18T10:00:00Z"


# ---------------------------------------------------------------------------
# TestWebhookConfig
# ---------------------------------------------------------------------------

class TestWebhookConfig:
    def test_load_webhook_config_returns_none_when_env_not_set(self, monkeypatch) -> None:
        """load_webhook_config returns None when DEVTORCH_METRICS_WEBHOOK_URL is absent."""
        monkeypatch.delenv("DEVTORCH_METRICS_WEBHOOK_URL", raising=False)
        result = load_webhook_config()
        assert result is None

    def test_load_webhook_config_returns_config_when_env_set(self, monkeypatch) -> None:
        """load_webhook_config returns a WebhookConfig when env vars are set."""
        monkeypatch.setenv("DEVTORCH_METRICS_WEBHOOK_URL", "https://example.com/metrics")
        monkeypatch.setenv("DEVTORCH_ORG_ID", "org-abc")
        monkeypatch.setenv("DEVTORCH_METRICS_API_KEY", "key-xyz")
        result = load_webhook_config()
        assert isinstance(result, WebhookConfig)
        assert result.endpoint_url == "https://example.com/metrics"
        assert result.org_id == "org-abc"
        assert result.api_key == "key-xyz"

    def test_build_webhook_payload_returns_webhook_payload(self) -> None:
        """build_webhook_payload returns a WebhookPayload instance."""
        report = _make_minimal_report()
        payload = build_webhook_payload(report, org_id="org-test")
        assert isinstance(payload, WebhookPayload)

    def test_build_webhook_payload_never_includes_prompt_or_code_fields(self) -> None:
        """build_webhook_payload output has only approved metric fields."""
        report = _make_minimal_report()
        payload = build_webhook_payload(report, org_id="org-test")
        payload_fields = {f.name for f in dataclasses.fields(payload)}
        # These field names must NOT appear
        forbidden = {
            "prompt", "code", "message", "reasoning", "response",
            "signal_text", "counterfactuals", "content",
        }
        assert payload_fields.isdisjoint(forbidden), (
            f"Forbidden fields found: {payload_fields & forbidden}"
        )

    def test_webhook_payload_to_dict_has_only_approved_metric_keys(self) -> None:
        """dataclasses.asdict(payload) contains only approved metric keys."""
        from devtorch_core.observability.webhook import _PAYLOAD_KEYS
        report = _make_minimal_report()
        payload = build_webhook_payload(report, org_id="org-test")
        d = dataclasses.asdict(payload)
        assert set(d.keys()) == _PAYLOAD_KEYS, (
            f"Extra keys: {set(d.keys()) - _PAYLOAD_KEYS}; "
            f"Missing keys: {_PAYLOAD_KEYS - set(d.keys())}"
        )


# ---------------------------------------------------------------------------
# TestSendWebhook
# ---------------------------------------------------------------------------

class TestSendWebhook:
    def _make_payload(self) -> WebhookPayload:
        report = _make_minimal_report()
        return build_webhook_payload(report, org_id="org-test")

    def test_returns_webhook_result(self) -> None:
        """send_webhook always returns a WebhookResult."""
        payload = self._make_payload()
        config = _make_webhook_config()
        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = lambda s: mock_resp
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp
            result = send_webhook(payload, config)
        assert isinstance(result, WebhookResult)

    def test_success_true_when_urllib_returns_200(self) -> None:
        """success=True when urllib responds with HTTP 200."""
        payload = self._make_payload()
        config = _make_webhook_config()
        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = lambda s: mock_resp
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp
            result = send_webhook(payload, config)
        assert result.success is True
        assert result.status_code == 200

    def test_success_false_when_urllib_raises(self) -> None:
        """success=False when urllib raises URLError."""
        payload = self._make_payload()
        config = _make_webhook_config()
        with mock.patch("urllib.request.urlopen", side_effect=urllib.error.URLError("connection refused")):
            result = send_webhook(payload, config)
        assert result.success is False

    def test_send_webhook_never_raises(self) -> None:
        """send_webhook never propagates exceptions."""
        payload = self._make_payload()
        config = _make_webhook_config()
        with mock.patch("urllib.request.urlopen", side_effect=Exception("unexpected boom")):
            # Must not raise
            result = send_webhook(payload, config)
        assert isinstance(result, WebhookResult)
        assert result.success is False

    def test_status_code_propagated_on_http_error(self) -> None:
        """status_code from HTTPError is propagated to WebhookResult."""
        payload = self._make_payload()
        config = _make_webhook_config()
        http_error = urllib.error.HTTPError(
            url="https://example.com",
            code=403,
            msg="Forbidden",
            hdrs=None,  # type: ignore[arg-type]
            fp=None,
        )
        with mock.patch("urllib.request.urlopen", side_effect=http_error):
            result = send_webhook(payload, config)
        assert result.success is False
        assert result.status_code == 403


# ---------------------------------------------------------------------------
# TestSendMetricsIfConfigured
# ---------------------------------------------------------------------------

class TestSendMetricsIfConfigured:
    def test_returns_none_when_not_configured(self, monkeypatch) -> None:
        """send_metrics_if_configured returns None when env is not set."""
        monkeypatch.delenv("DEVTORCH_METRICS_WEBHOOK_URL", raising=False)
        report = _make_minimal_report()
        result = send_metrics_if_configured(report)
        assert result is None

    def test_returns_webhook_result_when_configured(self, monkeypatch) -> None:
        """send_metrics_if_configured returns WebhookResult when configured."""
        monkeypatch.setenv("DEVTORCH_METRICS_WEBHOOK_URL", "https://example.com/metrics")
        monkeypatch.setenv("DEVTORCH_ORG_ID", "org-abc")
        monkeypatch.setenv("DEVTORCH_METRICS_API_KEY", "key-xyz")
        report = _make_minimal_report()
        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = lambda s: mock_resp
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp
            result = send_metrics_if_configured(report)
        assert isinstance(result, WebhookResult)

    def test_never_raises(self, monkeypatch) -> None:
        """send_metrics_if_configured never raises even when the network call fails."""
        monkeypatch.setenv("DEVTORCH_METRICS_WEBHOOK_URL", "https://example.com/metrics")
        monkeypatch.setenv("DEVTORCH_ORG_ID", "org-abc")
        monkeypatch.setenv("DEVTORCH_METRICS_API_KEY", "key-xyz")
        report = _make_minimal_report()
        with mock.patch("urllib.request.urlopen", side_effect=Exception("total meltdown")):
            # Must not raise
            result = send_metrics_if_configured(report)
        # Returns None (caught by top-level try/except) or WebhookResult with success=False
        assert result is None or isinstance(result, WebhookResult)

    def test_payload_excludes_sensitive_content(self, monkeypatch) -> None:
        """Verifies the payload captured by the mock contains only metric fields."""
        monkeypatch.setenv("DEVTORCH_METRICS_WEBHOOK_URL", "https://example.com/metrics")
        monkeypatch.setenv("DEVTORCH_ORG_ID", "org-test")
        monkeypatch.setenv("DEVTORCH_METRICS_API_KEY", "secret")
        report = _make_minimal_report()

        captured_body: list[dict] = []

        def fake_urlopen(req, timeout=None):
            body = json.loads(req.data.decode("utf-8"))
            captured_body.append(body)
            mock_resp = mock.MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = lambda s: mock_resp
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            return mock_resp

        with mock.patch("urllib.request.urlopen", side_effect=fake_urlopen):
            send_metrics_if_configured(report)

        assert len(captured_body) == 1
        body = captured_body[0]
        forbidden = {"prompt", "code", "message", "reasoning", "response", "signal_text", "counterfactuals"}
        for key in forbidden:
            assert key not in body, f"Sensitive key {key!r} found in webhook body"
        # Must have the core metric keys
        assert "commit_count" in body
        assert "sensitivity_count" in body
        assert "generated_at" in body
