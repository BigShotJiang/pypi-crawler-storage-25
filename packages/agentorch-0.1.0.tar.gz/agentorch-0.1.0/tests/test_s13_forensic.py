"""
S13 Tests — Forensic Replay, Collision Detail, Sprint Review.

Tests use a temporary .GCC/ directory and the FastAPI TestClient.
All endpoints return 200 with empty/default data when .GCC/ is missing
or has no data — never 500.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any, Dict

import pytest

# Skip entire module if starlette TestClient is unavailable
starlette_testclient = pytest.importorskip("starlette.testclient")
TestClient = starlette_testclient.TestClient

from devtorch_core.dashboard_api import create_app


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _init_gcc(root: Path) -> None:
    """Create a minimal .GCC/ layout sufficient for the API to recognise as initialised."""
    gcc = root / ".GCC"
    gcc.mkdir()
    (gcc / "VERSION").write_text("gcc-v0\n", encoding="utf-8")
    refs = gcc / "refs"
    refs.mkdir()
    branches = refs / "branches"
    branches.mkdir()
    (refs / "HEAD").write_text("main\n", encoding="utf-8")
    (branches / "main").write_text("", encoding="utf-8")
    (gcc / "commits").mkdir()
    (gcc / "sensitivities").mkdir()
    theta = {"version": 1, "updated_at": None, "coordination_vector": {}}
    (gcc / "theta.json").write_text(json.dumps(theta), encoding="utf-8")
    (gcc / "COMMIT_INDEX").write_text("", encoding="utf-8")


def _write_events(root: Path, events: list) -> None:
    """Append events to .GCC/events.log.jsonl."""
    log = root / ".GCC" / "events.log.jsonl"
    with log.open("a", encoding="utf-8") as fh:
        for ev in events:
            fh.write(json.dumps(ev) + "\n")


def _write_commit(root: Path, commit_id: str, data: Dict[str, Any], branch: str = "main") -> None:
    """Write a commit JSON file and update COMMIT_INDEX + branch ref."""
    commits_dir = root / ".GCC" / "commits"
    (commits_dir / f"{commit_id}.json").write_text(json.dumps(data), encoding="utf-8")
    index = root / ".GCC" / "COMMIT_INDEX"
    with index.open("a", encoding="utf-8") as fh:
        fh.write(commit_id + "\n")
    branch_ref = root / ".GCC" / "refs" / "branches" / branch
    branch_ref.write_text(commit_id, encoding="utf-8")


# ---------------------------------------------------------------------------
# GET /api/v1/forensic/timeline
# ---------------------------------------------------------------------------

class TestForensicTimeline:
    def test_returns_events_list(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "COMMIT", "ts": "2025-01-01T00:00:00Z", "branch": "main", "commit_id": "abc123"},
                {"event_type": "VARIANCE_ALERT", "ts": "2025-01-02T00:00:00Z", "concept": "auth"},
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/timeline")
            assert resp.status_code == 200
            data = resp.json()
            assert "events" in data
            assert len(data["events"]) == 2

    def test_event_has_required_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "COMMIT", "ts": "2025-01-01T00:00:00Z", "message": "first commit"},
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/timeline")
            assert resp.status_code == 200
            ev = resp.json()["events"][0]
            for field in ("ts", "type", "detail", "raw"):
                assert field in ev, f"Missing field: {field}"

    def test_empty_when_no_events(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            # events.log.jsonl not created → empty list
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/timeline")
            assert resp.status_code == 200
            assert resp.json()["events"] == []

    def test_event_type_filter(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "COMMIT", "ts": "2025-01-01T00:00:00Z"},
                {"event_type": "VARIANCE_ALERT", "ts": "2025-01-02T00:00:00Z"},
                {"event_type": "COMMIT", "ts": "2025-01-03T00:00:00Z"},
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/timeline?event_types=COMMIT")
            assert resp.status_code == 200
            events = resp.json()["events"]
            assert len(events) == 2
            assert all(e["type"] == "COMMIT" for e in events)

    def test_limit_param(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "COMMIT", "ts": f"2025-01-{i+1:02d}T00:00:00Z"}
                for i in range(10)
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/timeline?limit=3")
            assert resp.status_code == 200
            assert len(resp.json()["events"]) == 3

    def test_uninitialized_repo_still_returns_200(self):
        with tempfile.TemporaryDirectory() as tmp:
            # No .GCC/VERSION → uninitialised, but endpoint should not 500
            app = create_app(gcc_repo=Path(tmp))
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/timeline")
            assert resp.status_code == 200
            assert resp.json()["events"] == []


# ---------------------------------------------------------------------------
# GET /api/v1/forensic/trace/{commit_id}
# ---------------------------------------------------------------------------

class TestForensicTrace:
    def test_returns_commit_and_parents(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            parent_data = {
                "commit_id": "parent001",
                "branch": "main",
                "message": "parent commit",
                "parent": "",
                "created_at": "2025-01-01T00:00:00Z",
            }
            child_data = {
                "commit_id": "child001",
                "branch": "main",
                "message": "child commit",
                "parent": "parent001",
                "created_at": "2025-01-02T00:00:00Z",
            }
            _write_commit(root, "parent001", parent_data)
            _write_commit(root, "child001", child_data)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/trace/child001")
            assert resp.status_code == 200
            data = resp.json()
            assert "commit" in data
            assert "parents" in data
            assert "sensitivities" in data
            assert "invariant_violations" in data
            assert data["commit"]["commit_id"] == "child001"
            assert len(data["parents"]) >= 1
            assert data["parents"][0]["commit_id"] == "parent001"

    def test_missing_commit_returns_empty_structure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/trace/nonexistent")
            assert resp.status_code == 200
            data = resp.json()
            assert data["commit"] == {}
            assert data["parents"] == []

    def test_sensitivities_included(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            commit_data = {
                "commit_id": "c001",
                "branch": "main",
                "message": "test",
                "parent": "",
                "created_at": "2025-06-01T12:00:00Z",
            }
            _write_commit(root, "c001", commit_data)
            # Write a sensitivity event within the time window
            sens_event = {
                "event_id": "s001",
                "target_concept": "auth",
                "disclosure_level": "PRIVATE",
                "created_at": "2025-06-01T11:30:00Z",
            }
            sens_file = root / ".GCC" / "sensitivities" / "events.jsonl"
            sens_file.write_text(json.dumps(sens_event) + "\n", encoding="utf-8")
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/forensic/trace/c001")
            assert resp.status_code == 200


# ---------------------------------------------------------------------------
# GET /api/v1/collisions
# ---------------------------------------------------------------------------

class TestCollisions:
    def test_returns_empty_list_when_no_theta(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/collisions")
            assert resp.status_code == 200
            assert resp.json() == []

    def test_returns_collision_when_high_std_dev(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            theta = {
                "version": 1,
                "coordination_vector": {
                    "auth_security": {
                        "mean_confidence": 0.5,
                        "event_count": 2,
                        "source_nodes": [
                            {"agent_id": "agent-A", "confidence": 0.9, "message": "High confidence"},
                            {"agent_id": "agent-B", "confidence": 0.1, "message": "Low confidence"},
                        ],
                    }
                },
            }
            (root / ".GCC" / "theta.json").write_text(json.dumps(theta), encoding="utf-8")
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/collisions")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data) == 1
            collision = data[0]
            assert collision["concept"] == "auth_security"
            assert collision["severity"] in ("HIGH", "MEDIUM", "LOW")
            assert len(collision["agents"]) == 2

    def test_no_collision_when_low_std_dev(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            theta = {
                "version": 1,
                "coordination_vector": {
                    "stable_concept": {
                        "mean_confidence": 0.8,
                        "event_count": 2,
                        "source_nodes": [
                            {"agent_id": "agent-A", "confidence": 0.81, "message": "agreed"},
                            {"agent_id": "agent-B", "confidence": 0.79, "message": "agreed too"},
                        ],
                    }
                },
            }
            (root / ".GCC" / "theta.json").write_text(json.dumps(theta), encoding="utf-8")
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/collisions")
            assert resp.status_code == 200
            assert resp.json() == []

    def test_high_severity_threshold(self):
        """std_dev > 0.4 → severity HIGH."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            theta = {
                "version": 1,
                "coordination_vector": {
                    "split_concept": {
                        "mean_confidence": 0.5,
                        "event_count": 2,
                        "source_nodes": [
                            {"agent_id": "a", "confidence": 1.0, "message": ""},
                            {"agent_id": "b", "confidence": 0.0, "message": ""},
                        ],
                    }
                },
            }
            (root / ".GCC" / "theta.json").write_text(json.dumps(theta), encoding="utf-8")
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/collisions")
            assert resp.status_code == 200
            data = resp.json()
            assert data[0]["severity"] == "HIGH"

    def test_uninitialized_repo_returns_empty_list(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(gcc_repo=Path(tmp))
            client = TestClient(app)
            resp = client.get("/api/v1/collisions")
            assert resp.status_code == 200
            assert resp.json() == []


# ---------------------------------------------------------------------------
# GET /api/v1/sprint/summary
# ---------------------------------------------------------------------------

class TestSprintSummary:
    def test_returns_expected_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/sprint/summary")
            assert resp.status_code == 200
            data = resp.json()
            for field in (
                "total_commits",
                "commits_per_branch",
                "i3_violations",
                "collisions_detected",
                "top_concepts",
                "mcs_note",
            ):
                assert field in data, f"Missing field: {field}"

    def test_total_commits_counts_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_commit(root, "aaa001", {"commit_id": "aaa001", "branch": "main", "parent": "", "created_at": "2025-01-01T00:00:00Z"})
            _write_commit(root, "bbb002", {"commit_id": "bbb002", "branch": "main", "parent": "aaa001", "created_at": "2025-01-02T00:00:00Z"})
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/sprint/summary")
            assert resp.status_code == 200
            assert resp.json()["total_commits"] == 2

    def test_mcs_note_present(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/sprint/summary")
            assert resp.status_code == 200
            assert "calibration" in resp.json()["mcs_note"].lower()

    def test_collisions_detected_from_events(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "VARIANCE_ALERT", "ts": "2025-01-01T00:00:00Z"},
                {"event_type": "VARIANCE_ALERT", "ts": "2025-01-02T00:00:00Z"},
                {"event_type": "COMMIT", "ts": "2025-01-03T00:00:00Z"},
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/sprint/summary")
            assert resp.status_code == 200
            assert resp.json()["collisions_detected"] == 2

    def test_commits_per_branch_breakdown(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            # Create feature branch ref
            (root / ".GCC" / "refs" / "branches" / "feature-x").write_text("", encoding="utf-8")
            _write_commit(root, "m001", {"commit_id": "m001", "branch": "main", "parent": "", "created_at": "2025-01-01T00:00:00Z"}, branch="main")
            _write_commit(root, "f001", {"commit_id": "f001", "branch": "feature-x", "parent": "", "created_at": "2025-01-02T00:00:00Z"}, branch="feature-x")
            _write_commit(root, "f002", {"commit_id": "f002", "branch": "feature-x", "parent": "f001", "created_at": "2025-01-03T00:00:00Z"}, branch="feature-x")
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/sprint/summary")
            assert resp.status_code == 200
            cpb = resp.json()["commits_per_branch"]
            assert cpb.get("main", 0) == 1
            assert cpb.get("feature-x", 0) == 2
