"""
Sprint 3 tests – Sensitivity schema, Θ store, Ωᵢ gating, PST runner.

Real-world scenarios used throughout:
  * Schema-migration sensitivity: a database migration creates sensitivities
    in the payment-service that ripple into the coordination vector Θ.
  * Multi-level disclosure: some schema details are PUBLIC, PII-adjacent
    columns are PROTECTED, and encryption keys are PRIVATE.
  * PST gating: an agent with a high Lipschitz bound or failed PST must not
    participate in Textual Mode; the repo emits CAPABILITY_DEGRADED.
"""

from __future__ import annotations

import dataclasses
import datetime
import json
import hashlib
from pathlib import Path

import pytest

from devtorch_core import (
    GCCRepository,
    GCC_DIR_NAME,
    SENSITIVITIES_DIR_NAME,
    PST_REPORTS_DIR_NAME,
    SensitivityEvent,
    SensitivityStore,
    DISCLOSURE_LEVELS,
    RulesBasedAggPhi,
    ThetaStore,
    OmegaCapability,
    CapabilityStore,
    CapabilityValidationResult,
    PSTRunner,
    PSTReport,
    L_MAX_DEFAULT,
    PST_SCORE_THRESHOLD,
    PST_STATUS_PASSED,
    PST_STATUS_FAILED,
    PST_STATUS_NOT_RUN,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _today_iso() -> str:
    return datetime.date.today().isoformat()


def _past_date(days: int) -> str:
    return (datetime.date.today() - datetime.timedelta(days=days)).isoformat()


def _fake_hash(seed: str = "test-corpus") -> str:
    return hashlib.sha256(seed.encode()).hexdigest()


def _make_valid_cap(
    agent_id: str = "agent-alpha",
    l_hat: float = 1.2,
    pst_status: str = PST_STATUS_PASSED,
    pst_score: float = 0.90,
    calibration_date: str | None = None,
    expiry_days: int = 90,
) -> OmegaCapability:
    return OmegaCapability(
        agent_id=agent_id,
        lipschitz_bound=l_hat,
        calibration_dataset_hash=_fake_hash(),
        embedding_model="text-embedding-3-small",
        calibration_date=calibration_date or _today_iso(),
        temperature_used=0.0,
        pst_status=pst_status,
        pst_score=pst_score,
        pst_n_prompts=5,
        pst_n_repetitions=3,
        expiry_days=expiry_days,
    )


# ---------------------------------------------------------------------------
# 1. SensitivityEvent – schema validation
# ---------------------------------------------------------------------------

class TestSensitivityEventSchema:
    def test_valid_public_event(self) -> None:
        ev = SensitivityEvent(
            source_node="node-payments",
            target_concept="transaction_log_schema",
            counterfactuals="What if the schema version changes?",
            confidence=0.85,
            disclosure_level="PUBLIC",
        )
        assert ev.disclosure_level == "PUBLIC"
        assert ev.event_id  # non-empty UUID

    def test_valid_protected_event_with_numerical(self) -> None:
        ev = SensitivityEvent(
            source_node="node-billing",
            target_concept="pii_column_count",
            counterfactuals="How many PII columns are affected?",
            confidence=0.70,
            disclosure_level="PROTECTED",
            numerical_value=7.0,
            uncertainty=1.5,
        )
        assert ev.numerical_value == 7.0
        assert ev.uncertainty == 1.5

    def test_valid_private_event(self) -> None:
        ev = SensitivityEvent(
            source_node="node-security",
            target_concept="encryption_key_rotation",
            counterfactuals="What happens when the encryption key changes?",
            confidence=0.95,
            disclosure_level="PRIVATE",
        )
        assert ev.disclosure_level == "PRIVATE"

    def test_invalid_disclosure_level_raises(self) -> None:
        with pytest.raises(ValueError, match="disclosure_level"):
            SensitivityEvent(
                source_node="node-payments",
                target_concept="schema",
                counterfactuals="",
                confidence=0.5,
                disclosure_level="INTERNAL",  # invalid
            )

    def test_confidence_out_of_range_raises(self) -> None:
        with pytest.raises(ValueError, match="confidence"):
            SensitivityEvent(
                source_node="n",
                target_concept="c",
                counterfactuals="",
                confidence=1.5,  # > 1.0
                disclosure_level="PUBLIC",
            )

    def test_empty_source_node_raises(self) -> None:
        with pytest.raises(ValueError, match="source_node"):
            SensitivityEvent(
                source_node="   ",
                target_concept="concept",
                counterfactuals="",
                confidence=0.5,
                disclosure_level="PUBLIC",
            )

    def test_empty_concept_raises(self) -> None:
        with pytest.raises(ValueError, match="target_concept"):
            SensitivityEvent(
                source_node="node",
                target_concept="",
                counterfactuals="",
                confidence=0.5,
                disclosure_level="PUBLIC",
            )

    def test_roundtrip_serialisation(self) -> None:
        ev = SensitivityEvent(
            source_node="node-payments",
            target_concept="transaction_log_schema",
            counterfactuals="Schema version change impact.",
            confidence=0.85,
            disclosure_level="PROTECTED",
            numerical_value=3.2,
            uncertainty=0.5,
            message="ORM migration sensitivity.",
        )
        d = ev.to_dict()
        ev2 = SensitivityEvent.from_dict(d)
        assert ev2.source_node == ev.source_node
        assert ev2.numerical_value == ev.numerical_value
        assert ev2.event_id == ev.event_id


# ---------------------------------------------------------------------------
# 2. SensitivityStore – storage, indexing, filtering
# ---------------------------------------------------------------------------

class TestSensitivityStore:
    def test_add_and_list_all(self, tmp_path: Path) -> None:
        store = SensitivityStore(tmp_path / "sens")
        ev1 = SensitivityEvent("n1", "schema_version", "Impact of version bump", 0.8, "PUBLIC")
        ev2 = SensitivityEvent("n2", "pii_fields", "PII exposure on migration", 0.6, "PROTECTED")
        store.add(ev1)
        store.add(ev2)
        all_events = store.list_all()
        assert len(all_events) == 2
        assert all_events[0].target_concept == "schema_version"
        assert all_events[1].target_concept == "pii_fields"

    def test_index_built_correctly(self, tmp_path: Path) -> None:
        store = SensitivityStore(tmp_path / "sens")
        store.add(SensitivityEvent("n1", "schema_version", "", 0.9, "PUBLIC"))
        store.add(SensitivityEvent("n2", "schema_version", "", 0.7, "PROTECTED"))
        store.add(SensitivityEvent("n3", "pii_fields", "", 0.6, "PRIVATE"))
        index = json.loads((tmp_path / "sens" / "index.json").read_text())
        assert len(index["schema_version"]) == 2
        assert len(index["pii_fields"]) == 1

    def test_filter_by_concept(self, tmp_path: Path) -> None:
        store = SensitivityStore(tmp_path / "sens")
        store.add(SensitivityEvent("n1", "schema_version", "", 0.9, "PUBLIC"))
        store.add(SensitivityEvent("n2", "latency_p99", "", 0.7, "PUBLIC"))
        filtered = store.filter(concept="schema_version")
        assert len(filtered) == 1
        assert filtered[0].target_concept == "schema_version"

    def test_filter_by_disclosure_level(self, tmp_path: Path) -> None:
        store = SensitivityStore(tmp_path / "sens")
        store.add(SensitivityEvent("n1", "c1", "", 0.9, "PUBLIC"))
        store.add(SensitivityEvent("n2", "c2", "", 0.8, "PROTECTED"))
        store.add(SensitivityEvent("n3", "c3", "", 0.7, "PRIVATE"))
        private = store.filter(disclosure_level="PRIVATE")
        assert len(private) == 1
        assert private[0].disclosure_level == "PRIVATE"

    def test_filter_by_source_node(self, tmp_path: Path) -> None:
        store = SensitivityStore(tmp_path / "sens")
        store.add(SensitivityEvent("billing-svc", "revenue", "", 0.9, "PROTECTED"))
        store.add(SensitivityEvent("payments-svc", "revenue", "", 0.8, "PROTECTED"))
        billing = store.filter(source_node="billing-svc")
        assert len(billing) == 1
        assert billing[0].source_node == "billing-svc"

    def test_filter_combined_criteria(self, tmp_path: Path) -> None:
        store = SensitivityStore(tmp_path / "sens")
        store.add(SensitivityEvent("n1", "schema", "", 0.9, "PUBLIC"))
        store.add(SensitivityEvent("n1", "schema", "", 0.7, "PROTECTED"))
        store.add(SensitivityEvent("n2", "schema", "", 0.8, "PUBLIC"))
        result = store.filter(concept="schema", disclosure_level="PUBLIC", source_node="n1")
        assert len(result) == 1
        assert result[0].source_node == "n1"
        assert result[0].disclosure_level == "PUBLIC"

    def test_concepts_list(self, tmp_path: Path) -> None:
        store = SensitivityStore(tmp_path / "sens")
        store.add(SensitivityEvent("n1", "schema_version", "", 0.9, "PUBLIC"))
        store.add(SensitivityEvent("n2", "pii_fields", "", 0.8, "PROTECTED"))
        assert sorted(store.concepts()) == ["pii_fields", "schema_version"]

    def test_empty_store_returns_empty_list(self, tmp_path: Path) -> None:
        store = SensitivityStore(tmp_path / "sens")
        assert store.list_all() == []
        assert store.filter(concept="anything") == []


# ---------------------------------------------------------------------------
# 3. RulesBasedAggPhi – determinism and disclosure escalation
# ---------------------------------------------------------------------------

class TestRulesBasedAggPhi:
    def _ev(self, concept: str, conf: float, level: str, ts: str = "2025-01-01T00:00:00+00:00") -> dict:
        return {
            "target_concept": concept,
            "confidence": conf,
            "disclosure_level": level,
            "created_at": ts,
        }

    def test_single_event_aggregation(self) -> None:
        agg = RulesBasedAggPhi()
        result = agg.aggregate([self._ev("schema", 0.8, "PUBLIC")])
        assert result["schema"]["mean_confidence"] == 0.8
        assert result["schema"]["disclosure_level"] == "PUBLIC"
        assert result["schema"]["event_count"] == 1

    def test_disclosure_escalates_to_max(self) -> None:
        agg = RulesBasedAggPhi()
        events = [
            self._ev("schema", 0.8, "PUBLIC", "2025-01-01T00:00:00+00:00"),
            self._ev("schema", 0.7, "PROTECTED", "2025-01-02T00:00:00+00:00"),
            self._ev("schema", 0.6, "PRIVATE", "2025-01-03T00:00:00+00:00"),
        ]
        result = agg.aggregate(events)
        assert result["schema"]["disclosure_level"] == "PRIVATE"

    def test_recency_weighting_boosts_newest(self) -> None:
        agg = RulesBasedAggPhi()
        events = [
            self._ev("schema", 0.0, "PUBLIC", "2025-01-01T00:00:00+00:00"),  # older
            self._ev("schema", 1.0, "PUBLIC", "2025-01-02T00:00:00+00:00"),  # newest → weight 2
        ]
        result = agg.aggregate(events)
        # weighted mean: (2*1.0 + 1*0.0) / 3 = 0.666...
        assert abs(result["schema"]["mean_confidence"] - 2 / 3) < 1e-5

    def test_multi_concept_independence(self) -> None:
        agg = RulesBasedAggPhi()
        events = [
            self._ev("schema", 0.9, "PUBLIC"),
            self._ev("latency", 0.4, "PROTECTED"),
        ]
        result = agg.aggregate(events)
        assert "schema" in result
        assert "latency" in result
        assert result["schema"]["disclosure_level"] == "PUBLIC"
        assert result["latency"]["disclosure_level"] == "PROTECTED"

    def test_determinism_same_inputs(self) -> None:
        """Same inputs must produce identical output (no randomness)."""
        agg = RulesBasedAggPhi()
        events = [
            self._ev("schema", 0.8, "PUBLIC", "2025-01-01T10:00:00+00:00"),
            self._ev("schema", 0.6, "PROTECTED", "2025-01-01T09:00:00+00:00"),
        ]
        r1 = agg.aggregate(events)
        r2 = agg.aggregate(events)
        assert r1 == r2


# ---------------------------------------------------------------------------
# 4. ThetaStore – ripple propagation and persistence
# ---------------------------------------------------------------------------

class TestThetaStore:
    def _ev(self, concept: str, conf: float, level: str) -> dict:
        return {
            "target_concept": concept,
            "confidence": conf,
            "disclosure_level": level,
            "created_at": "2025-01-01T00:00:00+00:00",
        }

    def test_ripple_creates_theta_file(self, tmp_path: Path) -> None:
        ts = ThetaStore(tmp_path)
        ts.ripple([self._ev("schema", 0.9, "PUBLIC")])
        assert (tmp_path / "theta.json").exists()

    def test_ripple_populates_coordination_vector(self, tmp_path: Path) -> None:
        ts = ThetaStore(tmp_path)
        ts.ripple([self._ev("schema", 0.9, "PUBLIC")])
        theta = ts.load()
        assert "schema" in theta["coordination_vector"]

    def test_cumulative_ripple_merges_counts(self, tmp_path: Path) -> None:
        ts = ThetaStore(tmp_path)
        ts.ripple([self._ev("schema", 0.8, "PUBLIC")])
        ts.ripple([self._ev("schema", 0.6, "PROTECTED")])
        theta = ts.load()
        entry = theta["coordination_vector"]["schema"]
        assert entry["event_count"] == 2
        # Disclosure should have escalated to PROTECTED
        assert entry["disclosure_level"] == "PROTECTED"

    def test_confidence_blending(self, tmp_path: Path) -> None:
        ts = ThetaStore(tmp_path)
        # First batch: 1 event at 1.0 confidence
        ts.ripple([self._ev("schema", 1.0, "PUBLIC")])
        # Second batch: 1 event at 0.0 confidence
        ts.ripple([self._ev("schema", 0.0, "PUBLIC")])
        theta = ts.load()
        mean_conf = theta["coordination_vector"]["schema"]["mean_confidence"]
        # Weighted blend: existing count=1 old_conf=1.0, new count=1 new_conf=0.0 → 0.5
        assert abs(mean_conf - 0.5) < 1e-5

    def test_theta_determinism(self, tmp_path: Path) -> None:
        """Same sequence of ripples must produce identical Θ."""
        path_a = tmp_path / "a"
        path_b = tmp_path / "b"
        events = [
            self._ev("schema", 0.8, "PUBLIC"),
            self._ev("pii", 0.6, "PROTECTED"),
            self._ev("schema", 0.9, "PRIVATE"),
        ]
        ts_a = ThetaStore(path_a)
        ts_b = ThetaStore(path_b)
        for ev in events:
            ts_a.ripple([ev])
        for ev in events:
            ts_b.ripple([ev])

        cv_a = ts_a.load()["coordination_vector"]
        cv_b = ts_b.load()["coordination_vector"]
        assert cv_a.keys() == cv_b.keys()
        for k in cv_a:
            assert cv_a[k]["mean_confidence"] == cv_b[k]["mean_confidence"]
            assert cv_a[k]["disclosure_level"] == cv_b[k]["disclosure_level"]
            assert cv_a[k]["event_count"] == cv_b[k]["event_count"]

    def test_pluggable_aggregator_is_used(self, tmp_path: Path) -> None:
        """A custom Aggφ implementation replaces the default."""
        from devtorch_core import AggPhi

        class ConstantAgg(AggPhi):
            def aggregate(self, events):
                return {
                    e["target_concept"]: {
                        "mean_confidence": 0.42,
                        "disclosure_level": "PRIVATE",
                        "event_count": len(events),
                    }
                    for e in events
                }

        ts = ThetaStore(tmp_path, aggregator=ConstantAgg())
        ts.ripple([self._ev("schema", 0.9, "PUBLIC")])
        theta = ts.load()
        assert theta["coordination_vector"]["schema"]["mean_confidence"] == 0.42
        assert theta["coordination_vector"]["schema"]["disclosure_level"] == "PRIVATE"


# ---------------------------------------------------------------------------
# 5. OmegaCapability – validation and expiry
# ---------------------------------------------------------------------------

class TestOmegaCapability:
    def test_valid_capability_allows_textual_mode(self) -> None:
        cap = _make_valid_cap()
        allowed, reasons = cap.textual_mode_allowed(l_max=L_MAX_DEFAULT)
        assert allowed is True
        assert reasons == []

    def test_expired_calibration_blocks_textual_mode(self) -> None:
        cap = _make_valid_cap(calibration_date=_past_date(91), expiry_days=90)
        allowed, reasons = cap.textual_mode_allowed()
        assert allowed is False
        assert any("expired" in r.lower() for r in reasons)

    def test_high_lipschitz_blocks_textual_mode(self) -> None:
        cap = _make_valid_cap(l_hat=3.0)
        allowed, reasons = cap.textual_mode_allowed(l_max=2.0)
        assert allowed is False
        assert any("L" in r for r in reasons)

    def test_pst_failed_blocks_textual_mode(self) -> None:
        cap = _make_valid_cap(pst_status=PST_STATUS_FAILED, pst_score=0.65)
        allowed, reasons = cap.textual_mode_allowed()
        assert allowed is False
        assert any("PST" in r for r in reasons)

    def test_pst_not_run_blocks_textual_mode(self) -> None:
        cap = _make_valid_cap(pst_status=PST_STATUS_NOT_RUN, pst_score=None)
        allowed, reasons = cap.textual_mode_allowed()
        assert allowed is False
        assert any("PST" in r for r in reasons)

    def test_multiple_failures_reported(self) -> None:
        cap = _make_valid_cap(
            l_hat=5.0,
            pst_status=PST_STATUS_FAILED,
            calibration_date=_past_date(200),
        )
        allowed, reasons = cap.textual_mode_allowed()
        assert allowed is False
        # Should report all three violations
        assert len(reasons) == 3

    def test_invalid_pst_status_raises(self) -> None:
        with pytest.raises(ValueError, match="pst_status"):
            OmegaCapability(
                agent_id="agent",
                lipschitz_bound=1.0,
                calibration_dataset_hash=_fake_hash(),
                embedding_model="model",
                calibration_date=_today_iso(),
                temperature_used=0.0,
                pst_status="unknown",
            )

    def test_negative_lipschitz_raises(self) -> None:
        with pytest.raises(ValueError, match="lipschitz_bound"):
            OmegaCapability(
                agent_id="agent",
                lipschitz_bound=-0.5,
                calibration_dataset_hash=_fake_hash(),
                embedding_model="model",
                calibration_date=_today_iso(),
                temperature_used=0.0,
            )

    def test_temperature_out_of_range_raises(self) -> None:
        with pytest.raises(ValueError, match="temperature_used"):
            OmegaCapability(
                agent_id="agent",
                lipschitz_bound=1.0,
                calibration_dataset_hash=_fake_hash(),
                embedding_model="model",
                calibration_date=_today_iso(),
                temperature_used=2.5,
            )

    def test_roundtrip_serialisation(self) -> None:
        cap = _make_valid_cap()
        d = cap.to_dict()
        cap2 = OmegaCapability.from_dict(d)
        assert cap2.agent_id == cap.agent_id
        assert cap2.lipschitz_bound == cap.lipschitz_bound
        assert cap2.pst_status == cap.pst_status


# ---------------------------------------------------------------------------
# 6. CapabilityStore – persistence and legacy stub detection
# ---------------------------------------------------------------------------

class TestCapabilityStore:
    def test_save_and_load_roundtrip(self, tmp_path: Path) -> None:
        store = CapabilityStore(tmp_path)
        cap = _make_valid_cap()
        store.save(cap)
        loaded = store.load()
        assert loaded is not None
        assert loaded.agent_id == cap.agent_id
        assert loaded.lipschitz_bound == cap.lipschitz_bound

    def test_load_legacy_stub_returns_none(self, tmp_path: Path) -> None:
        (tmp_path / "omega.json").write_text(
            json.dumps({"version": 0, "schema": "omega-stub-v0", "note": "stub"}) + "\n"
        )
        store = CapabilityStore(tmp_path)
        assert store.load() is None

    def test_validate_no_capability_returns_invalid(self, tmp_path: Path) -> None:
        store = CapabilityStore(tmp_path)
        result = store.validate()
        assert result.valid is False
        assert result.textual_mode_allowed is False
        assert result.agent_id == "<none>"
        assert result.is_expired is True

    def test_validate_valid_capability(self, tmp_path: Path) -> None:
        store = CapabilityStore(tmp_path)
        store.save(_make_valid_cap())
        result = store.validate()
        assert result.valid is True
        assert result.textual_mode_allowed is True
        assert result.reasons == []

    def test_validate_expired_capability(self, tmp_path: Path) -> None:
        store = CapabilityStore(tmp_path)
        store.save(_make_valid_cap(calibration_date=_past_date(100), expiry_days=90))
        result = store.validate()
        assert result.valid is False
        assert result.is_expired is True

    def test_validate_custom_l_max(self, tmp_path: Path) -> None:
        store = CapabilityStore(tmp_path)
        store.save(_make_valid_cap(l_hat=1.5))
        # With a tighter L_max of 1.0, this should fail
        result = store.validate(l_max=1.0)
        assert result.valid is False
        assert any("L" in r for r in result.reasons)


# ---------------------------------------------------------------------------
# 7. PSTRunner
# ---------------------------------------------------------------------------

class TestPSTRunner:
    def _always_same(self, prompt: str, rep: int) -> str:
        return "deterministic answer"

    def _always_different(self, prompt: str, rep: int) -> str:
        return f"answer-{rep}"

    def _half_and_half(self, prompt: str, rep: int) -> str:
        return "A" if rep % 2 == 0 else "B"

    def test_deterministic_agent_scores_1(self) -> None:
        runner = PSTRunner("agent-1", self._always_same, n_prompts=3, n_repetitions=4)
        report = runner.run()
        assert report.pst_score == 1.0
        assert report.status == PST_STATUS_PASSED

    def test_fully_random_agent_scores_low(self) -> None:
        runner = PSTRunner(
            "agent-random",
            self._always_different,
            n_prompts=2,
            n_repetitions=5,
        )
        report = runner.run()
        # Each run produces unique output → stability = 1/5 = 0.2 per prompt
        assert report.pst_score < PST_SCORE_THRESHOLD
        assert report.status == PST_STATUS_FAILED

    def test_threshold_boundary(self) -> None:
        # half_and_half: 2 unique outputs from N_rep repetitions
        # stability = ceil(N_rep/2) / N_rep
        # With 4 reps: 2/4 = 0.5 → below default threshold 0.8
        runner = PSTRunner("agent-half", self._half_and_half, n_prompts=1, n_repetitions=4)
        report = runner.run()
        assert report.status == PST_STATUS_FAILED

    def test_custom_prompts(self) -> None:
        custom = ["Is 2+2=4?", "What is the capital of France?"]
        runner = PSTRunner(
            "agent-custom",
            self._always_same,
            n_prompts=2,
            prompts=custom,
        )
        report = runner.run()
        assert report.n_prompts == 2
        assert len(report.per_prompt_scores) == 2

    def test_per_prompt_scores_length_matches_n_prompts(self) -> None:
        runner = PSTRunner("agent-1", self._always_same, n_prompts=5, n_repetitions=3)
        report = runner.run()
        assert len(report.per_prompt_scores) == 5

    def test_report_fields_populated(self) -> None:
        runner = PSTRunner("agent-1", self._always_same, n_prompts=3, n_repetitions=3)
        report = runner.run()
        assert report.agent_id == "agent-1"
        assert report.n_prompts == 3
        assert report.n_repetitions == 3
        assert report.threshold == PST_SCORE_THRESHOLD
        assert report.run_at  # non-empty ISO timestamp


# ---------------------------------------------------------------------------
# 8. GCCRepository Sprint 3 integration
# ---------------------------------------------------------------------------

class TestGCCRepositoryS3Integration:
    def test_init_creates_s3_dirs(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        gcc = tmp_path / GCC_DIR_NAME
        assert (gcc / SENSITIVITIES_DIR_NAME).is_dir()
        assert (gcc / PST_REPORTS_DIR_NAME).is_dir()
        assert (gcc / "theta.json").exists()

    def test_add_sensitivity_creates_event(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        ev = SensitivityEvent("n1", "schema_version", "Impact", 0.85, "PUBLIC")
        event_id = repo.add_sensitivity(ev)
        assert event_id
        events = repo.list_sensitivities()
        assert len(events) == 1
        assert events[0]["target_concept"] == "schema_version"

    def test_add_sensitivity_ripples_into_theta(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.add_sensitivity(
            SensitivityEvent("n1", "transaction_schema", "Impact", 0.9, "PROTECTED")
        )
        theta = repo.get_theta()
        assert "transaction_schema" in theta["coordination_vector"]

    def test_list_sensitivities_filters_work(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.add_sensitivity(SensitivityEvent("n1", "schema", "", 0.9, "PUBLIC"))
        repo.add_sensitivity(SensitivityEvent("n2", "pii", "", 0.7, "PRIVATE"))
        private = repo.list_sensitivities(disclosure_level="PRIVATE")
        assert len(private) == 1
        assert private[0]["disclosure_level"] == "PRIVATE"

    def test_set_and_get_capability(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        cap = _make_valid_cap()
        repo.set_capability(cap)
        loaded = repo.get_capability()
        assert loaded is not None
        assert loaded["agent_id"] == cap.agent_id

    def test_validate_capability_allowed(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.set_capability(_make_valid_cap())
        result = repo.validate_capability()
        assert result["textual_mode_allowed"] is True

    def test_validate_capability_emits_degraded_event(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        # High L̂ → should block Textual Mode
        repo.set_capability(_make_valid_cap(l_hat=5.0))
        result = repo.validate_capability(l_max=2.0)
        assert result["textual_mode_allowed"] is False
        # Verify CAPABILITY_DEGRADED event in the log
        import json
        log = (tmp_path / GCC_DIR_NAME / "events.log.jsonl").read_text()
        events = [json.loads(l) for l in log.splitlines() if l.strip()]
        degraded = [e for e in events if e["event_type"] == "CAPABILITY_DEGRADED"]
        assert len(degraded) == 1

    def test_validate_no_capability_returns_blocked(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        result = repo.validate_capability()
        assert result["textual_mode_allowed"] is False
        assert result["agent_id"] == "<none>"

    def test_run_pst_persists_report_and_updates_capability(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.set_capability(_make_valid_cap(pst_status=PST_STATUS_NOT_RUN, pst_score=None))

        report = repo.run_pst(
            agent_id="agent-alpha",
            run_fn=lambda p, r: "consistent answer",
            n_prompts=3,
            n_repetitions=2,
        )
        assert report["status"] == PST_STATUS_PASSED
        assert report["pst_score"] == 1.0

        # Report persisted on disk
        pst_files = list((tmp_path / GCC_DIR_NAME / PST_REPORTS_DIR_NAME).glob("*.json"))
        assert len(pst_files) == 1

        # Capability updated
        cap = repo.get_capability()
        assert cap is not None
        assert cap["pst_status"] == PST_STATUS_PASSED
        assert cap["pst_score"] == 1.0

    def test_run_pst_emits_audit_event(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.run_pst("agent-alpha", lambda p, r: "same", n_prompts=2, n_repetitions=2)
        log = (tmp_path / GCC_DIR_NAME / "events.log.jsonl").read_text()
        events = [json.loads(l) for l in log.splitlines() if l.strip()]
        pst_events = [e for e in events if e["event_type"] == "PST_RUN"]
        assert len(pst_events) == 1
        assert pst_events[0]["payload"]["agent_id"] == "agent-alpha"

    def test_sensitivity_added_audit_event_recorded(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.add_sensitivity(
            SensitivityEvent("n1", "schema_version", "Impact", 0.9, "PUBLIC")
        )
        log = (tmp_path / GCC_DIR_NAME / "events.log.jsonl").read_text()
        events = [json.loads(l) for l in log.splitlines() if l.strip()]
        sens_events = [e for e in events if e["event_type"] == "SENSITIVITY_ADDED"]
        assert len(sens_events) == 1
        assert sens_events[0]["payload"]["target_concept"] == "schema_version"

    def test_doctor_still_passes_after_s3_init(self, tmp_path: Path) -> None:
        repo = GCCRepository.at(tmp_path)
        repo.init()
        issues = repo.doctor()
        assert issues == [], f"Unexpected doctor issues: {issues}"


# ---------------------------------------------------------------------------
# 9. CLI smoke tests (Sprint 3 commands)
# ---------------------------------------------------------------------------

class TestCLIS3Commands:
    def test_sensitivity_add_cli(self, tmp_path: Path) -> None:
        from devtorch_cli.main import main as devtorch_main

        repo = GCCRepository.at(tmp_path)
        repo.init()
        exit_code = devtorch_main([
            "-C", str(tmp_path), "sensitivity", "add",
            "--source", "node-payments",
            "--concept", "transaction_schema",
            "--confidence", "0.85",
            "--disclosure", "PROTECTED",
            "--counterfactuals", "Schema version bump impact.",
            "-m", "ORM migration risk.",
        ])
        assert exit_code == 0

    def test_sensitivity_list_cli(self, tmp_path: Path) -> None:
        from devtorch_cli.main import main as devtorch_main

        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.add_sensitivity(SensitivityEvent("n1", "schema", "", 0.9, "PUBLIC"))
        exit_code = devtorch_main(["-C", str(tmp_path), "sensitivity", "list"])
        assert exit_code == 0

    def test_sensitivity_filter_cli(self, tmp_path: Path) -> None:
        from devtorch_cli.main import main as devtorch_main

        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.add_sensitivity(SensitivityEvent("n1", "schema", "", 0.9, "PUBLIC"))
        exit_code = devtorch_main([
            "-C", str(tmp_path), "sensitivity", "filter",
            "--disclosure", "PUBLIC",
        ])
        assert exit_code == 0

    def test_capability_set_and_show_cli(self, tmp_path: Path) -> None:
        from devtorch_cli.main import main as devtorch_main

        repo = GCCRepository.at(tmp_path)
        repo.init()
        exit_code = devtorch_main([
            "-C", str(tmp_path), "capability", "set",
            "--agent-id", "agent-alpha",
            "--lipschitz-bound", "1.2",
            "--calibration-hash", _fake_hash(),
            "--embedding-model", "text-embedding-3-small",
            "--calibration-date", _today_iso(),
            "--temperature", "0.0",
        ])
        assert exit_code == 0

        show_code = devtorch_main(["-C", str(tmp_path), "capability", "show"])
        assert show_code == 0

    def test_capability_validate_allowed_cli(self, tmp_path: Path) -> None:
        from devtorch_cli.main import main as devtorch_main

        repo = GCCRepository.at(tmp_path)
        repo.init()
        repo.set_capability(_make_valid_cap())
        exit_code = devtorch_main(["-C", str(tmp_path), "capability", "validate"])
        assert exit_code == 0

    def test_capability_validate_blocked_cli(self, tmp_path: Path) -> None:
        from devtorch_cli.main import main as devtorch_main

        repo = GCCRepository.at(tmp_path)
        repo.init()
        # Expired calibration → should be blocked
        repo.set_capability(_make_valid_cap(calibration_date=_past_date(100)))
        exit_code = devtorch_main(["-C", str(tmp_path), "capability", "validate"])
        assert exit_code == 1  # blocked → non-zero exit

    def test_capability_validate_no_cap_cli(self, tmp_path: Path) -> None:
        from devtorch_cli.main import main as devtorch_main

        repo = GCCRepository.at(tmp_path)
        repo.init()
        exit_code = devtorch_main(["-C", str(tmp_path), "capability", "validate"])
        assert exit_code == 1


# ---------------------------------------------------------------------------
# 10. Real-world scenario: schema-migration sensitivity ripple
# ---------------------------------------------------------------------------

def test_schema_migration_sensitivity_ripple(tmp_path: Path) -> None:
    """
    Real-world narrative: an engineering team is coordinating an ORM migration
    across payment-service, billing-service, and audit-service.  Each service
    emits sensitivity events documenting how the schema change affects them.
    DevTorch accumulates those into a coordination vector Θ that an agent can
    inspect to understand cross-module risk.

    After the ripple:
    - 'transaction_log_schema' has escalated to PRIVATE because audit-service
      flagged an encryption-related sensitivity.
    - The mean confidence for 'pii_column_count' reflects the weighted average
      of the two services that measured it.
    """
    repo = GCCRepository.at(tmp_path)
    repo.init()

    print("\n[scenario] Payment-service emits migration sensitivity (PUBLIC).")
    repo.add_sensitivity(SensitivityEvent(
        source_node="payment-svc",
        target_concept="transaction_log_schema",
        counterfactuals="If schema version changes from v3 to v4, payment rows are misread.",
        confidence=0.90,
        disclosure_level="PUBLIC",
        message="ORM migration: schema_version field rename.",
    ))

    print("[scenario] Billing-service emits PII column sensitivity (PROTECTED).")
    repo.add_sensitivity(SensitivityEvent(
        source_node="billing-svc",
        target_concept="pii_column_count",
        counterfactuals="An additional PII column requires GDPR re-certification.",
        confidence=0.75,
        disclosure_level="PROTECTED",
        numerical_value=3.0,
        uncertainty=1.0,
    ))

    print("[scenario] Audit-service emits encryption key sensitivity (PRIVATE).")
    repo.add_sensitivity(SensitivityEvent(
        source_node="audit-svc",
        target_concept="transaction_log_schema",
        counterfactuals="If schema changes, encrypted audit trail becomes unverifiable.",
        confidence=0.95,
        disclosure_level="PRIVATE",
        message="Encryption integrity risk.",
    ))

    print("[scenario] Payments adds a second PII measurement (PROTECTED).")
    repo.add_sensitivity(SensitivityEvent(
        source_node="payment-svc",
        target_concept="pii_column_count",
        counterfactuals="We count 5 PII columns after migration, not 3.",
        confidence=0.80,
        disclosure_level="PROTECTED",
        numerical_value=5.0,
    ))

    theta = repo.get_theta()
    cv = theta["coordination_vector"]

    # transaction_log_schema: escalated to PRIVATE (audit-svc), 2 events
    assert "transaction_log_schema" in cv
    assert cv["transaction_log_schema"]["disclosure_level"] == "PRIVATE"
    assert cv["transaction_log_schema"]["event_count"] == 2

    # pii_column_count: PROTECTED, 2 events
    assert "pii_column_count" in cv
    assert cv["pii_column_count"]["disclosure_level"] == "PROTECTED"
    assert cv["pii_column_count"]["event_count"] == 2

    # Verify mean confidence for schema is between 0.90 and 0.95 (recency weighted)
    schema_conf = cv["transaction_log_schema"]["mean_confidence"]
    assert 0.85 < schema_conf <= 1.0, f"Expected high confidence, got {schema_conf}"

    # All 4 sensitivities are stored and filterable
    all_events = repo.list_sensitivities()
    assert len(all_events) == 4
    private_events = repo.list_sensitivities(disclosure_level="PRIVATE")
    assert len(private_events) == 1
    assert private_events[0]["source_node"] == "audit-svc"

    print("[scenario] Running PST to certify agent for Textual Mode.")
    repo.set_capability(_make_valid_cap(pst_status=PST_STATUS_NOT_RUN, pst_score=None))
    report = repo.run_pst(
        agent_id="agent-alpha",
        run_fn=lambda p, r: "consistent reasoning output",
        n_prompts=5,
        n_repetitions=3,
    )
    assert report["status"] == PST_STATUS_PASSED

    result = repo.validate_capability()
    assert result["textual_mode_allowed"] is True, \
        f"Expected Textual Mode allowed, reasons: {result['reasons']}"

    print("[scenario] Doctor check still passes.")
    issues = repo.doctor()
    assert issues == [], f"Unexpected doctor issues: {issues}"


def test_pst_gating_blocks_textual_mode(tmp_path: Path) -> None:
    """
    Real-world narrative: a new agent deployment skips PST certification.
    Any attempt to use Textual Mode should be rejected and logged.
    """
    repo = GCCRepository.at(tmp_path)
    repo.init()

    print("\n[scenario] Agent deployed without PST. Textual Mode should be blocked.")
    repo.set_capability(_make_valid_cap(pst_status=PST_STATUS_NOT_RUN, pst_score=None))
    result = repo.validate_capability()
    assert result["textual_mode_allowed"] is False
    assert any("PST" in r for r in result["reasons"])

    # CAPABILITY_DEGRADED must appear in the event log
    log = (tmp_path / GCC_DIR_NAME / "events.log.jsonl").read_text()
    events = [json.loads(l) for l in log.splitlines() if l.strip()]
    degraded = [e for e in events if e["event_type"] == "CAPABILITY_DEGRADED"]
    assert degraded, "Expected CAPABILITY_DEGRADED event in log."
    assert degraded[0]["payload"]["pst_status"] == PST_STATUS_NOT_RUN

    print("[scenario] Running PST fixes the issue.")
    report = repo.run_pst(
        agent_id="agent-alpha",
        run_fn=lambda p, r: "stable answer",
        n_prompts=5,
        n_repetitions=3,
    )
    assert report["status"] == PST_STATUS_PASSED
    result2 = repo.validate_capability()
    assert result2["textual_mode_allowed"] is True


def test_multi_agent_capability_lifecycle(tmp_path: Path) -> None:
    """
    Real-world narrative: two agents, one with a stale calibration and one
    freshly calibrated.  Only the fresh one should pass the A1 gate.
    """
    repo_a = GCCRepository.at(tmp_path / "agent-a")
    repo_b = GCCRepository.at(tmp_path / "agent-b")
    repo_a.init()
    repo_b.init()

    print("\n[scenario] Agent-A: calibrated 100 days ago (expired).")
    repo_a.set_capability(_make_valid_cap(
        agent_id="agent-a",
        calibration_date=_past_date(100),
        expiry_days=90,
    ))
    result_a = repo_a.validate_capability()
    assert result_a["textual_mode_allowed"] is False
    assert result_a["is_expired"] is True

    print("[scenario] Agent-B: freshly calibrated today.")
    repo_b.set_capability(_make_valid_cap(agent_id="agent-b"))
    result_b = repo_b.validate_capability()
    assert result_b["textual_mode_allowed"] is True
    assert result_b["is_expired"] is False
