"""
Sprint 16 — Alert delivery tests.
All network calls are mocked; no real HTTP requests are made.
"""
import os
import unittest
from io import BytesIO
from unittest.mock import MagicMock, patch

from devtorch_core.alerts.base import (
    AlertChannel,
    AlertEnvelope,
    AlertSeverity,
    DeliveryResult,
    event_to_severity,
)
from devtorch_core.alerts.config import AlertConfig, is_channel_configured, load_config
from devtorch_core.alerts.dispatcher import (
    build_channels,
    dispatch_alert,
    dispatch_from_event,
)
from devtorch_core.alerts.jira import JiraChannel
from devtorch_core.alerts.pagerduty import PagerDutyChannel
from devtorch_core.alerts.slack import SlackChannel


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_envelope(
    event_type: str = "VARIANCE_ALERT",
    severity: AlertSeverity = AlertSeverity.WARNING,
    title: str = "Test Alert",
    body: str = "Something happened.",
    branch: str = "main",
    commit_id: str = "abc123",
    metadata: dict | None = None,
) -> AlertEnvelope:
    return AlertEnvelope(
        event_type=event_type,
        severity=severity,
        title=title,
        body=body,
        branch=branch,
        commit_id=commit_id,
        metadata=metadata or {},
    )


def _mock_urlopen_200():
    """Return a context-manager mock that simulates HTTP 200."""
    resp = MagicMock()
    resp.status = 200
    resp.__enter__ = lambda s: s
    resp.__exit__ = MagicMock(return_value=False)
    return resp


# ---------------------------------------------------------------------------
# TestAlertEnvelope (5 tests)
# ---------------------------------------------------------------------------

class TestAlertEnvelope(unittest.TestCase):
    def test_dataclass_fields_present(self):
        env = _make_envelope()
        self.assertEqual(env.event_type, "VARIANCE_ALERT")
        self.assertEqual(env.severity, AlertSeverity.WARNING)
        self.assertEqual(env.title, "Test Alert")
        self.assertEqual(env.body, "Something happened.")
        self.assertEqual(env.branch, "main")
        self.assertEqual(env.commit_id, "abc123")

    def test_metadata_defaults_to_empty_dict(self):
        env = AlertEnvelope(
            event_type="VARIANCE_ALERT",
            severity=AlertSeverity.WARNING,
            title="T",
            body="B",
            branch="main",
            commit_id="x",
        )
        self.assertIsInstance(env.metadata, dict)
        self.assertEqual(env.metadata, {})

    def test_metadata_independent_between_instances(self):
        e1 = AlertEnvelope("A", AlertSeverity.INFO, "T", "B", "main", "x")
        e2 = AlertEnvelope("A", AlertSeverity.INFO, "T", "B", "main", "x")
        e1.metadata["key"] = "val"
        self.assertNotIn("key", e2.metadata)

    def test_alert_severity_enum_values(self):
        self.assertEqual(AlertSeverity.INFO.value, "info")
        self.assertEqual(AlertSeverity.WARNING.value, "warning")
        self.assertEqual(AlertSeverity.CRITICAL.value, "critical")

    def test_delivery_result_fields(self):
        dr = DeliveryResult(channel="slack", success=True, response_code=200)
        self.assertEqual(dr.channel, "slack")
        self.assertTrue(dr.success)
        self.assertEqual(dr.response_code, 200)
        self.assertEqual(dr.error, "")


# ---------------------------------------------------------------------------
# TestEventToSeverity (6 tests)
# ---------------------------------------------------------------------------

class TestEventToSeverity(unittest.TestCase):
    def test_privacy_budget_exhausted_is_critical(self):
        self.assertEqual(event_to_severity("PRIVACY_BUDGET_EXHAUSTED"), AlertSeverity.CRITICAL)

    def test_capability_degraded_is_critical(self):
        self.assertEqual(event_to_severity("CAPABILITY_DEGRADED"), AlertSeverity.CRITICAL)

    def test_variance_alert_is_warning(self):
        self.assertEqual(event_to_severity("VARIANCE_ALERT"), AlertSeverity.WARNING)

    def test_consensus_locked_is_warning(self):
        self.assertEqual(event_to_severity("CONSENSUS_LOCKED"), AlertSeverity.WARNING)

    def test_unknown_event_is_info(self):
        self.assertEqual(event_to_severity("SOME_UNKNOWN_EVENT"), AlertSeverity.INFO)

    def test_case_sensitivity_exact_match(self):
        # Lower-cased variants should NOT map to CRITICAL/WARNING
        self.assertEqual(event_to_severity("variance_alert"), AlertSeverity.INFO)
        self.assertEqual(event_to_severity("privacy_budget_exhausted"), AlertSeverity.INFO)


# ---------------------------------------------------------------------------
# TestAlertConfig (5 tests)
# ---------------------------------------------------------------------------

class TestAlertConfig(unittest.TestCase):
    def test_load_config_reads_slack_webhook_url(self):
        with patch.dict(os.environ, {"DEVTORCH_SLACK_WEBHOOK_URL": "https://hooks.slack.com/test"}):
            cfg = load_config()
        self.assertEqual(cfg.slack_webhook_url, "https://hooks.slack.com/test")

    def test_load_config_reads_pagerduty_routing_key(self):
        with patch.dict(os.environ, {"DEVTORCH_PAGERDUTY_ROUTING_KEY": "pd-key-123"}):
            cfg = load_config()
        self.assertEqual(cfg.pagerduty_routing_key, "pd-key-123")

    def test_load_config_returns_defaults_when_env_not_set(self):
        # Ensure none of our env vars are set
        keys = [
            "DEVTORCH_SLACK_WEBHOOK_URL",
            "DEVTORCH_JIRA_URL",
            "DEVTORCH_JIRA_PROJECT_KEY",
            "DEVTORCH_JIRA_API_TOKEN",
            "DEVTORCH_JIRA_EMAIL",
            "DEVTORCH_PAGERDUTY_ROUTING_KEY",
            "DEVTORCH_ALERT_MIN_SEVERITY",
        ]
        env_patch = {k: "" for k in keys}
        # Remove these keys from env entirely
        with patch.dict(os.environ, {}, clear=False):
            for k in keys:
                os.environ.pop(k, None)
            cfg = load_config()
        self.assertEqual(cfg.slack_webhook_url, "")
        self.assertEqual(cfg.jira_url, "")
        self.assertEqual(cfg.min_severity, AlertSeverity.WARNING)

    def test_is_channel_configured_slack_requires_webhook_url(self):
        cfg_with = AlertConfig(slack_webhook_url="https://hooks.slack.com/x")
        cfg_without = AlertConfig(slack_webhook_url="")
        self.assertTrue(is_channel_configured(cfg_with, "slack"))
        self.assertFalse(is_channel_configured(cfg_without, "slack"))

    def test_is_channel_configured_jira_requires_all_three_fields(self):
        full = AlertConfig(
            jira_url="https://myorg.atlassian.net",
            jira_project_key="DEV",
            jira_api_token="token123",
            jira_email="user@example.com",
        )
        missing_token = AlertConfig(
            jira_url="https://myorg.atlassian.net",
            jira_project_key="DEV",
            jira_api_token="",
        )
        self.assertTrue(is_channel_configured(full, "jira"))
        self.assertFalse(is_channel_configured(missing_token, "jira"))


# ---------------------------------------------------------------------------
# TestSlackChannel (6 tests)
# ---------------------------------------------------------------------------

class TestSlackChannel(unittest.TestCase):
    def setUp(self):
        self.channel = SlackChannel(webhook_url="https://hooks.slack.com/fake")
        self.critical_env = _make_envelope(
            event_type="CAPABILITY_DEGRADED",
            severity=AlertSeverity.CRITICAL,
        )
        self.warning_env = _make_envelope()

    def test_build_payload_returns_dict_with_blocks_key(self):
        payload = self.channel._build_payload(self.warning_env)
        self.assertIsInstance(payload, dict)
        self.assertIn("blocks", payload)

    def test_build_payload_includes_severity_emoji_for_critical(self):
        payload = self.channel._build_payload(self.critical_env)
        header_block = payload["blocks"][0]
        text = header_block["text"]["text"]
        self.assertIn("🔴", text)

    def test_build_payload_includes_branch_in_context_block(self):
        env = _make_envelope(branch="feature-x")
        payload = self.channel._build_payload(env)
        context_block = payload["blocks"][-1]
        context_text = context_block["elements"][0]["text"]
        self.assertIn("feature-x", context_text)

    def test_deliver_returns_delivery_result(self):
        mock_resp = _mock_urlopen_200()
        with patch("urllib.request.urlopen", return_value=mock_resp):
            result = self.channel.deliver(self.warning_env)
        self.assertIsInstance(result, DeliveryResult)
        self.assertEqual(result.channel, "slack")

    def test_deliver_success_false_on_bad_url(self):
        import urllib.error
        with patch("urllib.request.urlopen", side_effect=urllib.error.URLError("connection refused")):
            result = self.channel.deliver(self.warning_env)
        self.assertFalse(result.success)
        self.assertIn("connection refused", result.error)

    def test_deliver_never_raises(self):
        with patch("urllib.request.urlopen", side_effect=RuntimeError("unexpected")):
            try:
                result = self.channel.deliver(self.warning_env)
            except Exception:
                self.fail("deliver() raised an exception")
        self.assertFalse(result.success)


# ---------------------------------------------------------------------------
# TestJiraChannel (4 tests)
# ---------------------------------------------------------------------------

class TestJiraChannel(unittest.TestCase):
    def setUp(self):
        self.channel = JiraChannel(
            url="https://myorg.atlassian.net",
            project_key="DEV",
            api_token="token123",
            email="user@example.com",
        )
        self.critical_env = _make_envelope(
            event_type="PRIVACY_BUDGET_EXHAUSTED",
            severity=AlertSeverity.CRITICAL,
            title="Budget gone",
        )
        self.warning_env = _make_envelope()

    def test_build_issue_body_returns_dict_with_fields_key(self):
        body = self.channel._build_issue_body(self.warning_env)
        self.assertIsInstance(body, dict)
        self.assertIn("fields", body)

    def test_build_issue_body_uses_bug_issuetype_for_critical(self):
        body = self.channel._build_issue_body(self.critical_env)
        issue_type = body["fields"]["issuetype"]["name"]
        self.assertEqual(issue_type, "Bug")

    def test_build_issue_body_includes_devtorch_in_summary(self):
        body = self.channel._build_issue_body(self.critical_env)
        summary = body["fields"]["summary"]
        self.assertIn("[DevTorch]", summary)

    def test_deliver_never_raises(self):
        with patch("urllib.request.urlopen", side_effect=RuntimeError("network gone")):
            try:
                result = self.channel.deliver(self.warning_env)
            except Exception:
                self.fail("deliver() raised an exception")
        self.assertFalse(result.success)


# ---------------------------------------------------------------------------
# TestPagerDutyChannel (4 tests)
# ---------------------------------------------------------------------------

class TestPagerDutyChannel(unittest.TestCase):
    def setUp(self):
        self.channel = PagerDutyChannel(routing_key="pd-routing-key-abc")
        self.critical_env = _make_envelope(
            event_type="CAPABILITY_DEGRADED",
            severity=AlertSeverity.CRITICAL,
        )
        self.info_env = _make_envelope(
            event_type="SOME_EVENT",
            severity=AlertSeverity.INFO,
        )
        self.warning_env = _make_envelope()

    def test_build_payload_has_routing_key(self):
        payload = self.channel._build_payload(self.critical_env)
        self.assertEqual(payload["routing_key"], "pd-routing-key-abc")

    def test_build_payload_event_action_trigger_for_critical(self):
        payload = self.channel._build_payload(self.critical_env)
        self.assertEqual(payload["event_action"], "trigger")

    def test_build_payload_severity_maps_correctly(self):
        critical_payload = self.channel._build_payload(self.critical_env)
        self.assertEqual(critical_payload["payload"]["severity"], "critical")

        warning_payload = self.channel._build_payload(self.warning_env)
        self.assertEqual(warning_payload["payload"]["severity"], "warning")

        info_payload = self.channel._build_payload(self.info_env)
        self.assertEqual(info_payload["payload"]["severity"], "info")

    def test_deliver_never_raises(self):
        with patch("urllib.request.urlopen", side_effect=RuntimeError("timeout")):
            try:
                result = self.channel.deliver(self.critical_env)
            except Exception:
                self.fail("deliver() raised an exception")
        self.assertFalse(result.success)


# ---------------------------------------------------------------------------
# TestDispatcher (5 tests)
# ---------------------------------------------------------------------------

class TestDispatcher(unittest.TestCase):
    def test_build_channels_returns_empty_list_when_no_config(self):
        cfg = AlertConfig()  # all defaults, no URLs set
        channels = build_channels(cfg)
        self.assertEqual(channels, [])

    def test_build_channels_returns_slack_channel_when_slack_configured(self):
        cfg = AlertConfig(slack_webhook_url="https://hooks.slack.com/x")
        channels = build_channels(cfg)
        self.assertEqual(len(channels), 1)
        self.assertIsInstance(channels[0], SlackChannel)

    def test_dispatch_alert_returns_empty_list_when_no_channels(self):
        cfg = AlertConfig()  # no channels configured
        env = _make_envelope()
        results = dispatch_alert(env, config=cfg)
        self.assertEqual(results, [])

    def test_dispatch_alert_filters_by_min_severity(self):
        """An INFO alert should NOT be delivered when min_severity=WARNING."""
        cfg = AlertConfig(
            slack_webhook_url="https://hooks.slack.com/x",
            min_severity=AlertSeverity.WARNING,
        )
        info_env = _make_envelope(severity=AlertSeverity.INFO)
        mock_resp = _mock_urlopen_200()
        with patch("urllib.request.urlopen", return_value=mock_resp):
            results = dispatch_alert(info_env, config=cfg)
        # Should be filtered out — no results
        self.assertEqual(results, [])

    def test_dispatch_from_event_returns_list_never_raises(self):
        cfg = AlertConfig()  # no channels — returns []
        try:
            results = dispatch_from_event(
                event_type="VARIANCE_ALERT",
                branch="main",
                commit_id="abc123",
                metadata={"delta": 0.05},
                config=cfg,
            )
        except Exception:
            self.fail("dispatch_from_event() raised an exception")
        self.assertIsInstance(results, list)


if __name__ == "__main__":
    unittest.main()
