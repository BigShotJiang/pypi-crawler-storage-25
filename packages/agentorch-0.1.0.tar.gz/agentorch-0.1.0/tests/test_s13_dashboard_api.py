"""
Sprint 13 – Dashboard API tests.

Tests the FastAPI REST service that reads `.GCC/` state and serves
governance data to the browser dashboard. All tests are local-only;
no real network calls are made (FastAPI TestClient).

Coverage:
 - GET /api/v1/health      (2 tests)
 - GET /api/v1/dashboard   (5 tests)
 - GET /api/v1/branches    (4 tests)
 - GET /api/v1/sensitivities (5 tests)
 - data model correctness  (3 tests)
 - edge cases / empty repo (3 tests)

Total: 22 tests (>= 15 required)
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Guard: skip entire module if proxy / dashboard deps not installed
# ---------------------------------------------------------------------------

pytest.importorskip("fastapi", reason="fastapi not installed — run: pip install devtorch[proxy]")
pytest.importorskip("httpx", reason="httpx not installed — run: pip install devtorch[proxy]")

from fastapi.testclient import TestClient

from devtorch_core.dashboard_api import (
    create_app,
    _read_gcc_status,
    _read_theta,
    _read_sensitivities,
    _read_branches,
    _disclosure_str_to_int,
)
from devtorch_core.gcc import GCCRepository


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def repo(tmp_path: Path) -> GCCRepository:
    """Initialized GCCRepository with one commit."""
    r = GCCRepository.at(tmp_path)
    r.init()
    r.commit("initial commit")
    return r


@pytest.fixture()
def client(repo: GCCRepository) -> TestClient:
    app = create_app(gcc_repo=repo.root)
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture()
def empty_client(tmp_path: Path) -> TestClient:
    """Client pointing at an *uninitialized* directory."""
    app = create_app(gcc_repo=tmp_path)
    return TestClient(app, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Helper: write a sensitivity event directly into the repo
# ---------------------------------------------------------------------------


def _write_sensitivity(
    gcc_dir: Path,
    concept: str = "test_concept",
    disclosure: str = "PUBLIC",
    message: str = "test signal",
) -> str:
    event_id = str(uuid.uuid4())
    sens_dir = gcc_dir / ".GCC" / "sensitivities"
    sens_dir.mkdir(parents=True, exist_ok=True)
    event = {
        "event_id": event_id,
        "source_node": "agent_test",
        "target_concept": concept,
        "counterfactuals": message,
        "confidence": 0.75,
        "disclosure_level": disclosure,
        "created_at": "2026-04-18T10:00:00+00:00",
    }
    events_file = sens_dir / "events.jsonl"
    with events_file.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(event) + "\n")
    return event_id


def _write_theta(gcc_dir: Path, coordination_vector: dict) -> None:
    theta = {
        "version": 1,
        "updated_at": "2026-04-18T10:00:00+00:00",
        "coordination_vector": coordination_vector,
    }
    (gcc_dir / ".GCC" / "theta.json").write_text(
        json.dumps(theta, indent=2), encoding="utf-8"
    )


# ===========================================================================
# 1. Health endpoint
# ===========================================================================


def test_health_initialized(client: TestClient) -> None:
    resp = client.get("/api/v1/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert body["initialized"] is True


def test_health_uninitialized(empty_client: TestClient) -> None:
    resp = empty_client.get("/api/v1/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "degraded"
    assert body["initialized"] is False


# ===========================================================================
# 2. Dashboard endpoint
# ===========================================================================


def test_dashboard_returns_200(client: TestClient) -> None:
    resp = client.get("/api/v1/dashboard")
    assert resp.status_code == 200


def test_dashboard_shape(client: TestClient) -> None:
    body = client.get("/api/v1/dashboard").json()
    assert "status" in body
    assert "theta" in body
    assert "recentSensitivities" in body
    assert "branches" in body
    assert "lastUpdated" in body


def test_dashboard_status_fields(client: TestClient) -> None:
    status = client.get("/api/v1/dashboard").json()["status"]
    assert "branch" in status
    assert "nodeState" in status
    assert "lastCommitId" in status
    assert "locked" in status
    assert isinstance(status["locked"], bool)


def test_dashboard_uninitialized_returns_503(empty_client: TestClient) -> None:
    resp = empty_client.get("/api/v1/dashboard")
    assert resp.status_code == 503


def test_dashboard_includes_theta_when_present(repo: GCCRepository) -> None:
    _write_theta(
        repo.root,
        {
            "security": {
                "mean_confidence": 0.92,
                "disclosure_level": "PUBLIC",
                "event_count": 3,
            }
        },
    )
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    body = c.get("/api/v1/dashboard").json()
    theta = body["theta"]
    assert len(theta) == 1
    assert theta[0]["concept"] == "security"
    assert abs(theta[0]["meanConfidence"] - 0.92) < 1e-6
    assert theta[0]["eventCount"] == 3


# ===========================================================================
# 3. Branches endpoint
# ===========================================================================


def test_branches_returns_200(client: TestClient) -> None:
    resp = client.get("/api/v1/branches")
    assert resp.status_code == 200


def test_branches_returns_list(client: TestClient) -> None:
    body = client.get("/api/v1/branches").json()
    assert isinstance(body, list)


def test_branches_contains_main(client: TestClient) -> None:
    body = client.get("/api/v1/branches").json()
    names = [b["name"] for b in body]
    assert "main" in names


def test_branches_has_required_fields(client: TestClient) -> None:
    body = client.get("/api/v1/branches").json()
    assert len(body) >= 1
    branch = body[0]
    assert "name" in branch
    assert "tipCommitId" in branch
    assert "commitCount" in branch
    # mcsScore may be None in S13
    assert "mcsScore" in branch


def test_branches_uninitialized_returns_503(empty_client: TestClient) -> None:
    resp = empty_client.get("/api/v1/branches")
    assert resp.status_code == 503


def test_branches_multiple(repo: GCCRepository) -> None:
    repo.create_branch("feature-x")
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    body = c.get("/api/v1/branches").json()
    names = {b["name"] for b in body}
    assert "main" in names
    assert "feature-x" in names


# ===========================================================================
# 4. Sensitivities endpoint
# ===========================================================================


def test_sensitivities_returns_200(client: TestClient) -> None:
    resp = client.get("/api/v1/sensitivities")
    assert resp.status_code == 200


def test_sensitivities_empty_initially(client: TestClient) -> None:
    body = client.get("/api/v1/sensitivities").json()
    assert isinstance(body, list)
    assert body == []


def test_sensitivities_returns_event(repo: GCCRepository) -> None:
    event_id = _write_sensitivity(repo.root, concept="auth", message="auth bypass risk")
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    body = c.get("/api/v1/sensitivities").json()
    assert len(body) == 1
    ev = body[0]
    assert ev["id"] == event_id
    assert ev["concept"] == "auth"
    assert "auth bypass risk" in ev["signal"]


def test_sensitivities_limit_param(repo: GCCRepository) -> None:
    for i in range(10):
        _write_sensitivity(repo.root, concept=f"concept_{i}", message=f"signal {i}")
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    body = c.get("/api/v1/sensitivities?limit=3").json()
    assert len(body) == 3


def test_sensitivities_disclosure_level_mapped(repo: GCCRepository) -> None:
    _write_sensitivity(repo.root, concept="pii", disclosure="PRIVATE", message="pii signal")
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    body = c.get("/api/v1/sensitivities").json()
    assert len(body) == 1
    # PRIVATE maps to int 2
    assert body[0]["disclosureLevel"] == 2


def test_sensitivities_uninitialized_returns_503(empty_client: TestClient) -> None:
    resp = empty_client.get("/api/v1/sensitivities")
    assert resp.status_code == 503


def test_sensitivities_newest_first(repo: GCCRepository) -> None:
    """Events should be returned newest first (reversed insertion order)."""
    _write_sensitivity(repo.root, concept="old_concept", message="old signal")
    _write_sensitivity(repo.root, concept="new_concept", message="new signal")
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    body = c.get("/api/v1/sensitivities").json()
    assert len(body) == 2
    assert body[0]["concept"] == "new_concept"
    assert body[1]["concept"] == "old_concept"


# ===========================================================================
# 5. Data model / helper correctness
# ===========================================================================


def test_disclosure_str_to_int_public() -> None:
    assert _disclosure_str_to_int("PUBLIC") == 0


def test_disclosure_str_to_int_protected() -> None:
    assert _disclosure_str_to_int("PROTECTED") == 1


def test_disclosure_str_to_int_private() -> None:
    assert _disclosure_str_to_int("PRIVATE") == 2


def test_disclosure_str_to_int_passthrough_int() -> None:
    assert _disclosure_str_to_int(3) == 3  # type: ignore[arg-type]


def test_disclosure_str_to_int_unknown() -> None:
    assert _disclosure_str_to_int("UNKNOWN") == 0


def test_read_theta_returns_sorted_by_confidence(repo: GCCRepository) -> None:
    _write_theta(
        repo.root,
        {
            "low_concept": {
                "mean_confidence": 0.3,
                "disclosure_level": "PUBLIC",
                "event_count": 1,
            },
            "high_concept": {
                "mean_confidence": 0.9,
                "disclosure_level": "PUBLIC",
                "event_count": 2,
            },
        },
    )
    entries = _read_theta(repo.root)
    assert len(entries) == 2
    assert entries[0].concept == "high_concept"
    assert entries[1].concept == "low_concept"


def test_read_gcc_status_after_lock(repo: GCCRepository) -> None:
    repo.lock(reason="sprint review")
    status = _read_gcc_status(repo.root)
    assert status.locked is True
    assert status.lockReason == "sprint review"


def test_gcc_status_unlocked_by_default(repo: GCCRepository) -> None:
    status = _read_gcc_status(repo.root)
    assert status.locked is False
    assert status.lockReason is None


def test_commit_count_in_branches(repo: GCCRepository) -> None:
    repo.commit("second commit")
    repo.commit("third commit")
    branches = _read_branches(repo.root)
    main_branch = next((b for b in branches if b.name == "main"), None)
    assert main_branch is not None
    # init() calls commit internally; we added 3 more commits (fixture + 2 here)
    assert main_branch.commitCount >= 3


# ===========================================================================
# 6. Edge cases
# ===========================================================================


def test_dashboard_no_theta_returns_empty_list(repo: GCCRepository) -> None:
    # Theta file doesn't exist yet (or is empty coordination_vector)
    theta_file = repo.root / ".GCC" / "theta.json"
    theta_file.write_text(
        json.dumps({"version": 1, "updated_at": None, "coordination_vector": {}}),
        encoding="utf-8",
    )
    body = TestClient(create_app(gcc_repo=repo.root)).get("/api/v1/dashboard").json()
    assert body["theta"] == []


def test_dashboard_corrupted_theta_returns_empty(repo: GCCRepository) -> None:
    (repo.root / ".GCC" / "theta.json").write_text("NOT_JSON", encoding="utf-8")
    body = TestClient(create_app(gcc_repo=repo.root)).get("/api/v1/dashboard").json()
    assert body["theta"] == []


def test_sensitivities_limit_default_max_500(repo: GCCRepository) -> None:
    # limit=501 should return 422 (FastAPI validation)
    resp = TestClient(create_app(gcc_repo=repo.root)).get("/api/v1/sensitivities?limit=501")
    assert resp.status_code == 422
