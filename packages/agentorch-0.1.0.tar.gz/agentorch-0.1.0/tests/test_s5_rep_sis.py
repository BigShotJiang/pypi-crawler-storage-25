"""Sprint 5 – REP envelope/ledger and SIS-TC corpus/eval, quarantine decision tree."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from devtorch_core import (
    GCCRepository,
    GCC_DIR_NAME,
    REPEnvelope,
    REPLedger,
    create_envelope,
    load_sis_tc_corpus,
    run_sis_tc_eval,
    SISTCCorpusEntry,
    QuarantineDecision,
    quarantine_decision_tree,
    QuarantineEventStore,
)


def test_rep_envelope_create_and_serialize() -> None:
    env = create_envelope("agent1", 1, {"concept": "auth", "confidence": 0.9})
    assert env.agent_id == "agent1"
    assert env.round_id == 1
    assert len(env.payload_hash) == 64
    d = env.to_dict()
    assert d["version"] == "rep-v1"
    back = REPEnvelope.from_dict(d)
    assert back.payload_hash == env.payload_hash


def test_rep_ledger_append_and_replay_checksum(tmp_path: Path) -> None:
    gcc = tmp_path / GCC_DIR_NAME
    gcc.mkdir()
    ledger = REPLedger(gcc)
    env = create_envelope("a1", 1, {})
    seq1 = ledger.append(env, "2026-01-01T00:00:00Z")
    assert seq1 == 1
    seq2 = ledger.append(env, "2026-01-01T00:00:01Z")
    assert seq2 == 2
    records = ledger.read_all()
    assert len(records) == 2
    cs = ledger.replay_checksum()
    assert len(cs) == 64
    # Same content -> same checksum
    cs2 = ledger.replay_checksum()
    assert cs == cs2


def test_sis_tc_corpus_load_and_eval(tmp_path: Path) -> None:
    corpus_path = tmp_path / "corpus.jsonl"
    corpus_path.write_text(
        '{"prompt_id": "1", "prompt_text": "safe prompt", "label_safe": true}\n'
        '{"prompt_id": "2", "prompt_text": "unsafe prompt", "label_safe": false}\n',
        encoding="utf-8",
    )
    entries = load_sis_tc_corpus(corpus_path)
    assert len(entries) == 2
    report = run_sis_tc_eval(entries, classifier_fn=None, threshold=0.5)
    assert report.n_total == 2
    assert report.tp == 1 and report.tn == 1
    assert report.fp == 0 and report.fn == 0
    assert report.fpr == 0.0 and report.fnr == 0.0


def test_quarantine_decision_tree_abstain() -> None:
    d = quarantine_decision_tree(
        "agent1", payload_quarantined=False, valid_peer_count=2, min_peers_required=3,
        agent_consecutive_quarantines=0,
    )
    assert d.outcome == "abstain"


def test_quarantine_decision_tree_exclude() -> None:
    d = quarantine_decision_tree(
        "agent1", payload_quarantined=True, valid_peer_count=5, min_peers_required=3,
        agent_consecutive_quarantines=3, exclude_after_n_consecutive=3,
    )
    assert d.outcome == "exclude"


def test_quarantine_decision_tree_rep_penalty() -> None:
    d = quarantine_decision_tree(
        "agent1", payload_quarantined=True, valid_peer_count=5, min_peers_required=3,
        agent_consecutive_quarantines=0,
    )
    assert d.outcome == "rep_penalty"


def test_quarantine_event_store(tmp_path: Path) -> None:
    gcc = tmp_path / GCC_DIR_NAME
    gcc.mkdir()
    store = QuarantineEventStore(gcc)
    d = QuarantineDecision("rep_penalty", "test", agent_id="a1")
    store.append(d, "2026-01-01T00:00:00Z", round_id=1)
    assert store.log_path.exists()


def test_gcc_rep_append_and_checksum(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    seq = repo.rep_append("agent1", 1, {"concept": "auth"})
    assert seq == 1
    cs = repo.rep_replay_checksum()
    assert len(cs) == 64


def test_gcc_sis_tc_run_empty_corpus(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    report = repo.sis_tc_run()
    assert report.n_total == 0
