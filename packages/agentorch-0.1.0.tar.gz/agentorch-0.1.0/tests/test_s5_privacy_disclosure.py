"""Sprint 5 – Prompt artifact, Δf, RDP accountant, disclosure [PRIVATE] suppression."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from devtorch_core import (
    GCCRepository,
    GCC_DIR_NAME,
    PromptArtifactStore,
    DeltaFReport,
    DeltaFStore,
    run_deltaf_estimation,
    RDPAccountant,
    RDPState,
    PRIVACY_BUDGET_EXHAUSTED_EVENT,
    DisclosurePolicy,
    apply_disclosure_policy,
    receiver_mandate_private_count,
)


def test_prompt_artifact_set_get(tmp_path: Path) -> None:
    gcc = tmp_path / GCC_DIR_NAME
    gcc.mkdir()
    store = PromptArtifactStore(gcc)
    store.set_prompt("You are RACP v2.1.", version="v2.1")
    assert store.get_prompt() == "You are RACP v2.1."
    assert store.reference_for_textual_mode() is not None


def test_deltaf_report_and_store(tmp_path: Path) -> None:
    gcc = tmp_path / GCC_DIR_NAME
    gcc.mkdir()
    report = run_deltaf_estimation([{"numerical_value": 0.5}, {"numerical_value": 1.2}])
    assert report.delta_f >= 1.0
    DeltaFStore(gcc).save_report(report, "2026-01-01T00:00:00Z", expiry_days=90)
    loaded = DeltaFStore(gcc).load_report()
    assert loaded is not None
    assert loaded.delta_f == report.delta_f


def test_rdp_spend_and_exhaustion(tmp_path: Path) -> None:
    gcc = tmp_path / GCC_DIR_NAME
    gcc.mkdir()
    acc = RDPAccountant(gcc)
    allowed, event = acc.spend(1, 0.3)
    assert allowed is True
    assert event == ""
    allowed2, event2 = acc.spend(2, 0.8)  # 0.3 + 0.8 = 1.1 > 1.0 budget
    assert allowed2 is False
    assert event2 == PRIVACY_BUDGET_EXHAUSTED_EVENT
    assert acc.is_read_only() is True


def test_disclosure_redact_private() -> None:
    text = "Hello [PRIVATE] secret data [PRIVATE] more"
    out = apply_disclosure_policy(text, DisclosurePolicy(padding_length=4))
    assert "[PRIVATE]" not in out
    assert "secret" not in out
    assert "█" in out
    assert receiver_mandate_private_count(text) == 2


def test_gcc_prompt_set_get(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.prompt_set("RACP v2.1 prompt.")
    assert repo.prompt_get() == "RACP v2.1 prompt."


def test_gcc_deltaf_run(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    report = repo.deltaf_run(expiry_days=30)
    assert report.delta_f >= 0


def test_gcc_rdp_spend_emits_event(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.rdp_spend(1, 2.0)  # exhaust default 1.0 budget
    events = []
    log_path = tmp_path / GCC_DIR_NAME / "events.log.jsonl"
    for line in log_path.read_text().splitlines():
        if line.strip():
            events.append(json.loads(line))
    assert any(e.get("event_type") == PRIVACY_BUDGET_EXHAUSTED_EVENT for e in events)


def test_gcc_disclosure_redact(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    out = repo.disclosure_redact("Say [PRIVATE] hidden", padding_length=5)
    assert "[PRIVATE]" not in out
    assert "hidden" not in out
