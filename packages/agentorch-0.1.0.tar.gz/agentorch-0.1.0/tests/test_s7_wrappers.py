"""
tests/test_s7_wrappers.py
=========================
Unit tests for the S7 LLM SDK wrapper layer.

All tests use unittest.mock — no real API calls are made.
"""
from __future__ import annotations

import os
import sys
import time
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch, call

# ---------------------------------------------------------------------------
# Ensure the Implementation directory is on sys.path
# ---------------------------------------------------------------------------

IMPL_DIR = Path(__file__).parent.parent
if str(IMPL_DIR) not in sys.path:
    sys.path.insert(0, str(IMPL_DIR))


# ---------------------------------------------------------------------------
# Helper: build a realistic mock GCCRepository
# ---------------------------------------------------------------------------

def _make_mock_repo(
    theta_vector: dict | None = None,
    racp_prompt: str | None = None,
    bundle_artifacts: list | None = None,
) -> MagicMock:
    repo = MagicMock()
    repo.is_initialized.return_value = True

    if theta_vector is None:
        theta_vector = {
            "concept_a": {"mean_confidence": 0.95},
            "concept_b": {"mean_confidence": 0.80},
        }
    repo.get_theta.return_value = {"coordination_vector": theta_vector}
    repo.prompt_get.return_value = racp_prompt or "You are a DevTorch-aware agent."
    repo.context_bundle.return_value = {
        "artifacts": bundle_artifacts or [
            {"path": "main.md", "reason": "pinned header"},
            {"path": "commits/00000001.json", "reason": "latest commit"},
        ],
        "approx_tokens_used": 500,
    }
    repo.commit.return_value = None
    repo.add_sensitivity.return_value = "evt-uuid-1234"
    return repo


# ===========================================================================
# 1.  RACPInjector — builds prefix
# ===========================================================================


class TestRACPInjectorBuildsPrefix(unittest.TestCase):
    """Verify that build_system_prefix() returns a prefix containing Θ info."""

    def setUp(self) -> None:
        from devtorch_core.wrapper.base import RACPInjector

        self.repo = _make_mock_repo(
            theta_vector={
                "schema_version": {"mean_confidence": 0.99},
                "auth_flow": {"mean_confidence": 0.87},
            },
            racp_prompt="RACP system prompt here",
        )
        self.injector = RACPInjector(self.repo)

    def test_prefix_contains_racp_prompt(self) -> None:
        prefix = self.injector.build_system_prefix()
        self.assertIn("RACP system prompt here", prefix)

    def test_prefix_contains_theta_concept(self) -> None:
        prefix = self.injector.build_system_prefix()
        self.assertIn("schema_version", prefix)

    def test_prefix_contains_theta_confidence(self) -> None:
        prefix = self.injector.build_system_prefix()
        # mean_confidence should be formatted and present
        self.assertIn("0.990", prefix)

    def test_prefix_contains_artifact_name(self) -> None:
        prefix = self.injector.build_system_prefix()
        self.assertIn("main.md", prefix)

    def test_prefix_is_string(self) -> None:
        prefix = self.injector.build_system_prefix()
        self.assertIsInstance(prefix, str)

    def test_empty_theta_returns_partial_prefix(self) -> None:
        """Even with no Θ entries the RACP prompt and artifacts still appear."""
        from devtorch_core.wrapper.base import RACPInjector

        repo = _make_mock_repo(theta_vector={}, racp_prompt="RACP system prompt here")
        injector = RACPInjector(repo)
        prefix = injector.build_system_prefix()
        self.assertIn("RACP system prompt here", prefix)

    def test_top10_theta_only(self) -> None:
        """Only the top-10 concepts by confidence should appear in the summary."""
        from devtorch_core.wrapper.base import RACPInjector

        theta = {f"concept_{i}": {"mean_confidence": i / 20.0} for i in range(20)}
        repo = _make_mock_repo(theta_vector=theta)
        injector = RACPInjector(repo)
        prefix = injector.build_system_prefix()
        # concept_19 is highest confidence (19/20); concept_0 is lowest
        self.assertIn("concept_19", prefix)
        self.assertNotIn("concept_0", prefix)


# ===========================================================================
# 2.  RACPInjector — context bundle cache
# ===========================================================================


class TestRACPInjectorCache(unittest.TestCase):
    """Verify that context_bundle is cached for CONTEXT_CACHE_TTL_SECS."""

    def test_context_bundle_called_only_once_within_ttl(self) -> None:
        from devtorch_core.wrapper.base import RACPInjector

        repo = _make_mock_repo()
        injector = RACPInjector(repo)

        # Call build_system_prefix twice in quick succession
        injector.build_system_prefix()
        injector.build_system_prefix()

        # context_bundle should have been called only once
        self.assertEqual(repo.context_bundle.call_count, 1)

    def test_context_bundle_refreshed_after_ttl(self) -> None:
        from devtorch_core.wrapper.base import RACPInjector, CONTEXT_CACHE_TTL_SECS

        repo = _make_mock_repo()
        injector = RACPInjector(repo)

        injector.build_system_prefix()
        # Simulate cache expiry by backdating the timestamp
        injector._cache["ts"] = time.monotonic() - CONTEXT_CACHE_TTL_SECS - 1
        injector.build_system_prefix()

        self.assertEqual(repo.context_bundle.call_count, 2)


# ===========================================================================
# 3.  CaptureOrchestrator — RACP blocks present
# ===========================================================================


class TestCaptureOrchestratorWithRACPBlocks(unittest.TestCase):
    """Verify commit and sensitivity_add are called when RACP blocks are found."""

    _RESPONSE_WITH_BLOCKS = (
        'The schema migration is safe.\n'
        '<devtorch:commit message="Schema migration validated" confidence="0.92"/>\n'
        '<devtorch:sensitivity concept="schema_version" signal="migration risk" '
        'confidence="0.88" disclosure="PROTECTED"/>'
    )

    def setUp(self) -> None:
        from devtorch_core.wrapper.base import CaptureOrchestrator

        self.repo = _make_mock_repo()
        self.orch = CaptureOrchestrator(self.repo)

    def test_commit_called(self) -> None:
        self.orch.capture(self._RESPONSE_WITH_BLOCKS, [], "sess1")
        self.repo.commit.assert_called()

    def test_commit_message_contains_block_message(self) -> None:
        self.orch.capture(self._RESPONSE_WITH_BLOCKS, [], "sess1")
        all_msgs = [str(c) for c in self.repo.commit.call_args_list]
        self.assertTrue(
            any("Schema migration validated" in m for m in all_msgs),
            f"Expected commit message not found in: {all_msgs}",
        )

    def test_sensitivity_add_called(self) -> None:
        self.orch.capture(self._RESPONSE_WITH_BLOCKS, [], "sess1")
        self.repo.add_sensitivity.assert_called()

    def test_sensitivity_event_has_correct_concept(self) -> None:
        from devtorch_core.sensitivity import SensitivityEvent

        self.orch.capture(self._RESPONSE_WITH_BLOCKS, [], "sess1")
        call_args = self.repo.add_sensitivity.call_args
        ev = call_args[0][0]
        self.assertEqual(ev.target_concept, "schema_version")

    def test_sensitivity_event_confidence(self) -> None:
        self.orch.capture(self._RESPONSE_WITH_BLOCKS, [], "sess1")
        call_args = self.repo.add_sensitivity.call_args
        ev = call_args[0][0]
        self.assertAlmostEqual(ev.confidence, 0.88, places=2)


# ===========================================================================
# 4.  CaptureOrchestrator — fallback path (no blocks)
# ===========================================================================


class TestCaptureOrchestratorFallback(unittest.TestCase):
    """When no RACP/thinking blocks are found, use infer_sensitivity fallback."""

    _PLAIN_TEXT = "The deployment looks fine. No issues detected."

    def setUp(self) -> None:
        from devtorch_core.wrapper.base import CaptureOrchestrator

        self.repo = _make_mock_repo()
        self.orch = CaptureOrchestrator(self.repo)

    def test_commit_called_in_fallback(self) -> None:
        self.orch.capture(self._PLAIN_TEXT, [], "sess2")
        self.repo.commit.assert_called()

    def test_commit_message_contains_conf05_marker(self) -> None:
        self.orch.capture(self._PLAIN_TEXT, [], "sess2")
        call_args_list = self.repo.commit.call_args_list
        messages = [str(c) for c in call_args_list]
        self.assertTrue(
            any("conf=0.5" in m for m in messages),
            f"Expected conf=0.5 marker not found in: {messages}",
        )

    def test_infer_sensitivity_called_when_available(self) -> None:
        """If devtorch_core.parser.inference is importable, infer_sensitivity is used."""
        # Build a fake inference module
        fake_inference = types.ModuleType("devtorch_core.parser.inference")
        mock_infer = MagicMock(return_value=[])
        mock_summary = MagicMock(return_value="deployment looks fine")
        fake_inference.infer_sensitivity = mock_infer
        fake_inference.extract_decision_summary = mock_summary

        with patch.dict(
            sys.modules,
            {
                "devtorch_core.parser.inference": fake_inference,
            },
        ):
            from devtorch_core.wrapper.base import CaptureOrchestrator

            repo = _make_mock_repo()
            orch = CaptureOrchestrator(repo)
            orch.capture(self._PLAIN_TEXT, [], "sess2b")

        mock_infer.assert_called_once_with(self._PLAIN_TEXT)
        mock_summary.assert_called_once_with(self._PLAIN_TEXT)

    def test_empty_text_does_not_commit(self) -> None:
        """Empty response text → nothing to capture → commit not called."""
        self.orch.capture("", [], "sess3")
        self.repo.commit.assert_not_called()


# ===========================================================================
# 5.  CaptureOrchestrator — never raises even if repo.commit raises
# ===========================================================================


class TestCaptureOrchestratorNeverRaises(unittest.TestCase):

    def test_commit_exception_does_not_propagate(self) -> None:
        from devtorch_core.wrapper.base import CaptureOrchestrator

        repo = _make_mock_repo()
        repo.commit.side_effect = RuntimeError("disk full")
        orch = CaptureOrchestrator(repo)
        # Should not raise
        orch.capture("Some response text", [], "sessX")

    def test_add_sensitivity_exception_does_not_propagate(self) -> None:
        from devtorch_core.wrapper.base import CaptureOrchestrator

        repo = _make_mock_repo()
        repo.add_sensitivity.side_effect = OSError("permission denied")
        orch = CaptureOrchestrator(repo)
        text = (
            '<devtorch:sensitivity concept="foo" signal="bar" '
            'confidence="0.8" disclosure="PUBLIC"/>'
        )
        orch.capture(text, [], "sessY")

    def test_get_theta_exception_in_injector_does_not_propagate(self) -> None:
        from devtorch_core.wrapper.base import RACPInjector

        repo = _make_mock_repo()
        repo.get_theta.side_effect = RuntimeError("theta store corrupt")
        injector = RACPInjector(repo)
        # Should not raise; prefix should still be partially built
        prefix = injector.build_system_prefix()
        self.assertIsInstance(prefix, str)

    def test_capture_wrapper_exception_does_not_propagate(self) -> None:
        """Even if the entire _do_capture raises, capture() swallows it."""
        from devtorch_core.wrapper.base import CaptureOrchestrator

        repo = _make_mock_repo()
        orch = CaptureOrchestrator(repo)
        # Monkeypatch _do_capture to always raise
        orch._do_capture = MagicMock(side_effect=RuntimeError("unexpected"))
        orch.capture("text", [], "sessZ")


# ===========================================================================
# 6.  DevTorchAnthropic — injects system prompt
# ===========================================================================


class TestDevTorchAnthropicInjectsSystem(unittest.TestCase):
    """Verify that the injected system prompt contains the RACP prefix."""

    def _build_fake_anthropic(self) -> types.ModuleType:
        """Return a fake ``anthropic`` module with a mock Anthropic client."""
        fake = types.ModuleType("anthropic")

        # Fake response
        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = "Hello from the LLM."

        fake_response = MagicMock()
        fake_response.content = [text_block]
        fake_response.model_dump.return_value = {
            "content": [{"type": "text", "text": "Hello from the LLM."}]
        }

        # Fake messages.create
        fake_messages = MagicMock()
        fake_messages.create.return_value = fake_response

        # Fake Anthropic client
        fake_client = MagicMock()
        fake_client.messages = fake_messages

        class FakeAnthropic:
            def __new__(cls, *a, **kw):
                return fake_client

        fake.Anthropic = FakeAnthropic
        return fake, fake_client

    def setUp(self) -> None:
        self.fake_anthropic, self.fake_client = self._build_fake_anthropic()
        self.repo = _make_mock_repo(racp_prompt="[RACP_PROMPT] You are DevTorch-aware.")

    def test_system_prompt_injected(self) -> None:
        with patch.dict(sys.modules, {"anthropic": self.fake_anthropic}):
            # Re-import to pick up the patched module
            if "devtorch_core.wrapper.anthropic" in sys.modules:
                del sys.modules["devtorch_core.wrapper.anthropic"]

            from devtorch_core.wrapper.anthropic import DevTorchAnthropic

            client = DevTorchAnthropic(gcc_repo=self.repo)
            client.messages.create(
                messages=[{"role": "user", "content": "Hello"}],
                system="Original system prompt",
                model="claude-opus-4-5",
                max_tokens=100,
            )

        # Verify that the real messages.create was called
        self.fake_client.messages.create.assert_called_once()
        call_kwargs = self.fake_client.messages.create.call_args[1]
        injected = call_kwargs.get("system", "")
        self.assertIn("[RACP_PROMPT]", injected)
        self.assertIn("Original system prompt", injected)

    def test_original_system_preserved_in_injected(self) -> None:
        with patch.dict(sys.modules, {"anthropic": self.fake_anthropic}):
            if "devtorch_core.wrapper.anthropic" in sys.modules:
                del sys.modules["devtorch_core.wrapper.anthropic"]

            from devtorch_core.wrapper.anthropic import DevTorchAnthropic

            client = DevTorchAnthropic(gcc_repo=self.repo)
            client.messages.create(
                messages=[{"role": "user", "content": "Hello"}],
                system="Do something specific",
                model="claude-opus-4-5",
                max_tokens=100,
            )

        call_kwargs = self.fake_client.messages.create.call_args[1]
        self.assertIn("Do something specific", call_kwargs["system"])


# ===========================================================================
# 7.  DevTorchAnthropic — strips RACP blocks from returned text
# ===========================================================================


class TestDevTorchAnthropicStripsBlocks(unittest.TestCase):
    """Verify that RACP tags are stripped from the returned content."""

    def _build_fake_anthropic_with_blocks(
        self, raw_text: str
    ) -> tuple[types.ModuleType, MagicMock]:
        fake = types.ModuleType("anthropic")

        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = raw_text

        fake_response = MagicMock()
        fake_response.content = [text_block]
        fake_response.model_dump.return_value = {
            "content": [{"type": "text", "text": raw_text}]
        }

        fake_messages = MagicMock()
        fake_messages.create.return_value = fake_response

        fake_client = MagicMock()
        fake_client.messages = fake_messages

        class FakeAnthropic:
            def __new__(cls, *a, **kw):
                return fake_client

        fake.Anthropic = FakeAnthropic
        return fake, text_block

    def test_racp_blocks_stripped_from_response(self) -> None:
        raw = (
            "Here is the answer.\n"
            '<devtorch:commit message="Answered user query" confidence="0.9"/>\n'
            "End of answer."
        )
        fake_mod, text_block = self._build_fake_anthropic_with_blocks(raw)
        repo = _make_mock_repo()

        with patch.dict(sys.modules, {"anthropic": fake_mod}):
            if "devtorch_core.wrapper.anthropic" in sys.modules:
                del sys.modules["devtorch_core.wrapper.anthropic"]

            from devtorch_core.wrapper.anthropic import DevTorchAnthropic

            client = DevTorchAnthropic(gcc_repo=repo)
            response = client.messages.create(
                messages=[{"role": "user", "content": "Tell me something"}],
                model="claude-opus-4-5",
                max_tokens=100,
            )

        # The text block should have been stripped in-place
        self.assertNotIn("<devtorch:commit", text_block.text)
        self.assertIn("Here is the answer.", text_block.text)

    def test_clean_text_unchanged(self) -> None:
        raw = "This is a perfectly clean answer with no devtorch tags."
        fake_mod, text_block = self._build_fake_anthropic_with_blocks(raw)
        repo = _make_mock_repo()

        with patch.dict(sys.modules, {"anthropic": fake_mod}):
            if "devtorch_core.wrapper.anthropic" in sys.modules:
                del sys.modules["devtorch_core.wrapper.anthropic"]

            from devtorch_core.wrapper.anthropic import DevTorchAnthropic

            client = DevTorchAnthropic(gcc_repo=repo)
            client.messages.create(
                messages=[{"role": "user", "content": "Question"}],
                model="claude-opus-4-5",
                max_tokens=100,
            )

        self.assertEqual(text_block.text, raw)


# ===========================================================================
# 8.  DEVTORCH_DISABLE env var — no capture happens
# ===========================================================================


class TestDisabledEnvVar(unittest.TestCase):

    def setUp(self) -> None:
        self.repo = _make_mock_repo()

    def _capture_orch(self):
        from devtorch_core.wrapper.base import CaptureOrchestrator
        return CaptureOrchestrator(self.repo)

    def _injector(self):
        from devtorch_core.wrapper.base import RACPInjector
        return RACPInjector(self.repo)

    def test_is_disabled_true_when_env_set_to_1(self) -> None:
        from devtorch_core.wrapper.base import is_disabled

        with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}):
            self.assertTrue(is_disabled())

    def test_is_disabled_true_when_env_set_to_true(self) -> None:
        from devtorch_core.wrapper.base import is_disabled

        with patch.dict(os.environ, {"DEVTORCH_DISABLE": "true"}):
            self.assertTrue(is_disabled())

    def test_is_disabled_false_by_default(self) -> None:
        from devtorch_core.wrapper.base import is_disabled

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            self.assertFalse(is_disabled())

    def test_anthropic_no_capture_when_disabled(self) -> None:
        """When DEVTORCH_DISABLE=1, commit() and add_sensitivity() must not be called."""
        fake = types.ModuleType("anthropic")

        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = (
            "Answer "
            '<devtorch:commit message="some commit" confidence="0.9"/>'
        )

        fake_response = MagicMock()
        fake_response.content = [text_block]
        fake_response.model_dump.return_value = {
            "content": [{"type": "text", "text": text_block.text}]
        }

        fake_messages = MagicMock()
        fake_messages.create.return_value = fake_response

        fake_client = MagicMock()
        fake_client.messages = fake_messages

        class FakeAnthropic:
            def __new__(cls, *a, **kw):
                return fake_client

        fake.Anthropic = FakeAnthropic

        with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}):
            with patch.dict(sys.modules, {"anthropic": fake}):
                if "devtorch_core.wrapper.anthropic" in sys.modules:
                    del sys.modules["devtorch_core.wrapper.anthropic"]

                from devtorch_core.wrapper.anthropic import DevTorchAnthropic

                repo = _make_mock_repo()
                client = DevTorchAnthropic(gcc_repo=repo)
                client.messages.create(
                    messages=[{"role": "user", "content": "Hi"}],
                    model="claude-opus-4-5",
                    max_tokens=100,
                )

        repo.commit.assert_not_called()
        repo.add_sensitivity.assert_not_called()

    def test_anthropic_no_injection_when_disabled(self) -> None:
        """When DEVTORCH_DISABLE=1, the system prompt must NOT be modified."""
        fake = types.ModuleType("anthropic")

        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = "Clean answer."

        fake_response = MagicMock()
        fake_response.content = [text_block]
        fake_response.model_dump.return_value = {
            "content": [{"type": "text", "text": "Clean answer."}]
        }

        fake_messages = MagicMock()
        fake_messages.create.return_value = fake_response

        fake_client = MagicMock()
        fake_client.messages = fake_messages

        class FakeAnthropic:
            def __new__(cls, *a, **kw):
                return fake_client

        fake.Anthropic = FakeAnthropic

        original_system = "Do something."

        with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}):
            with patch.dict(sys.modules, {"anthropic": fake}):
                if "devtorch_core.wrapper.anthropic" in sys.modules:
                    del sys.modules["devtorch_core.wrapper.anthropic"]

                from devtorch_core.wrapper.anthropic import DevTorchAnthropic

                repo = _make_mock_repo(racp_prompt="[RACP] Should not appear")
                client = DevTorchAnthropic(gcc_repo=repo)
                client.messages.create(
                    messages=[{"role": "user", "content": "Hi"}],
                    system=original_system,
                    model="claude-opus-4-5",
                    max_tokens=100,
                )

        call_kwargs = fake_client.messages.create.call_args[1]
        self.assertEqual(call_kwargs["system"], original_system)
        self.assertNotIn("[RACP]", call_kwargs["system"])


# ===========================================================================
# 9.  Thinking blocks → commit with conf=1.0 message
# ===========================================================================


class TestThinkingBlocksCapture(unittest.TestCase):

    def test_thinking_block_triggers_commit(self) -> None:
        from devtorch_core.wrapper.base import CaptureOrchestrator
        from devtorch_core.parser.thinking import ThinkingBlock

        repo = _make_mock_repo()
        orch = CaptureOrchestrator(repo)
        blocks = [ThinkingBlock(text="I thought carefully about this.", confidence=1.0)]
        orch.capture("The final answer.", blocks, "sessT")

        repo.commit.assert_called()
        commit_msg = str(repo.commit.call_args_list[0])
        self.assertIn("auto:", commit_msg)

    def test_thinking_and_racp_both_captured(self) -> None:
        from devtorch_core.wrapper.base import CaptureOrchestrator
        from devtorch_core.parser.thinking import ThinkingBlock

        repo = _make_mock_repo()
        orch = CaptureOrchestrator(repo)
        blocks = [ThinkingBlock(text="Thinking...", confidence=1.0)]
        text = (
            "The answer.\n"
            '<devtorch:commit message="Extra commit" confidence="0.9"/>'
        )
        orch.capture(text, blocks, "sessT2")

        # Both the thinking commit and the RACP commit should be called
        self.assertGreaterEqual(repo.commit.call_count, 2)


# ===========================================================================
# 10. find_gcc_repo — walks up the directory tree
# ===========================================================================


class TestFindGCCRepo(unittest.TestCase):
    """
    find_gcc_repo() imports GCCRepository lazily inside its body, so we patch
    via sys.modules rather than via the wrapper module's namespace.
    """

    def _make_fake_devtorch_core(self, is_init: bool) -> tuple:
        """Return (fake_devtorch_core_module, mock_repo)."""
        mock_repo = MagicMock()
        mock_repo.is_initialized.return_value = is_init

        MockGCC = MagicMock()
        MockGCC.at.return_value = mock_repo

        fake_core = MagicMock()
        fake_core.GCCRepository = MockGCC
        return fake_core, mock_repo, MockGCC

    def test_returns_none_when_no_gcc(self) -> None:
        from devtorch_core.wrapper.base import find_gcc_repo

        fake_core, mock_repo, MockGCC = self._make_fake_devtorch_core(is_init=False)

        with patch.dict(sys.modules, {"devtorch_core": fake_core}):
            result = find_gcc_repo()

        self.assertIsNone(result)

    def test_returns_repo_when_gcc_found(self) -> None:
        from devtorch_core.wrapper.base import find_gcc_repo

        fake_core, mock_repo, MockGCC = self._make_fake_devtorch_core(is_init=True)

        with patch.dict(sys.modules, {"devtorch_core": fake_core}):
            result = find_gcc_repo()

        self.assertIsNotNone(result)
        self.assertIs(result, mock_repo)


# ===========================================================================
# 11. OpenAI wrapper — basic smoke test
# ===========================================================================


class TestDevTorchOpenAISmoke(unittest.TestCase):

    def _build_fake_openai(self, response_text: str) -> tuple:
        fake = types.ModuleType("openai")

        msg = MagicMock()
        msg.content = response_text
        msg.reasoning_content = None

        choice = MagicMock()
        choice.message = msg

        fake_response = MagicMock()
        fake_response.choices = [choice]
        fake_response.model_dump.return_value = {"choices": []}

        completions = MagicMock()
        completions.create.return_value = fake_response

        chat = MagicMock()
        chat.completions = completions

        fake_client = MagicMock()
        fake_client.chat = chat

        class FakeOpenAI:
            def __new__(cls, *a, **kw):
                return fake_client

        fake.OpenAI = FakeOpenAI
        return fake, fake_client, completions

    def test_system_message_prepended(self) -> None:
        fake, fake_client, completions = self._build_fake_openai("Hello!")
        repo = _make_mock_repo(racp_prompt="[RACP_OPENAI] prefix")

        with patch.dict(sys.modules, {"openai": fake}):
            if "devtorch_core.wrapper.openai" in sys.modules:
                del sys.modules["devtorch_core.wrapper.openai"]

            from devtorch_core.wrapper.openai import DevTorchOpenAI

            client = DevTorchOpenAI(gcc_repo=repo)
            client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Test"}],
            )

        call_kwargs = completions.create.call_args[1]
        messages_sent = call_kwargs["messages"]
        self.assertEqual(messages_sent[0]["role"], "system")
        self.assertIn("[RACP_OPENAI]", messages_sent[0]["content"])

    def test_user_messages_preserved(self) -> None:
        fake, fake_client, completions = self._build_fake_openai("Hello!")
        repo = _make_mock_repo()

        with patch.dict(sys.modules, {"openai": fake}):
            if "devtorch_core.wrapper.openai" in sys.modules:
                del sys.modules["devtorch_core.wrapper.openai"]

            from devtorch_core.wrapper.openai import DevTorchOpenAI

            client = DevTorchOpenAI(gcc_repo=repo)
            client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "User message"}],
            )

        call_kwargs = completions.create.call_args[1]
        messages_sent = call_kwargs["messages"]
        user_msgs = [m for m in messages_sent if m["role"] == "user"]
        self.assertEqual(len(user_msgs), 1)
        self.assertEqual(user_msgs[0]["content"], "User message")


# ===========================================================================
# 12. Bedrock wrapper — basic smoke test
# ===========================================================================


class TestDevTorchBedrockSmoke(unittest.TestCase):

    def _build_fake_boto3(self, response_body: dict) -> tuple:
        import io
        import json

        raw = json.dumps(response_body).encode()
        body_stream = MagicMock()
        body_stream.read.return_value = raw

        fake_response = {"body": body_stream, "ResponseMetadata": {}}

        fake_client = MagicMock()
        fake_client.invoke_model.return_value = fake_response

        fake_boto3 = types.ModuleType("boto3")
        fake_boto3.client = MagicMock(return_value=fake_client)

        return fake_boto3, fake_client

    def test_anthropic_bedrock_system_injected(self) -> None:
        response_body = {
            "content": [{"type": "text", "text": "Bedrock answer."}],
            "stop_reason": "end_turn",
        }
        fake_boto3, fake_client = self._build_fake_boto3(response_body)
        repo = _make_mock_repo(racp_prompt="[RACP_BEDROCK]")

        import json

        with patch.dict(sys.modules, {"boto3": fake_boto3}):
            if "devtorch_core.wrapper.bedrock" in sys.modules:
                del sys.modules["devtorch_core.wrapper.bedrock"]

            from devtorch_core.wrapper.bedrock import DevTorchBedrock

            client = DevTorchBedrock(gcc_repo=repo)
            client.invoke_model(
                modelId="anthropic.claude-opus-4-5-20240229-v1:0",
                body=json.dumps({
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 100,
                    "messages": [{"role": "user", "content": "Hello"}],
                }),
                contentType="application/json",
                accept="application/json",
            )

        call_kwargs = fake_client.invoke_model.call_args[1]
        sent_body = json.loads(call_kwargs["body"])
        self.assertIn("[RACP_BEDROCK]", sent_body.get("system", ""))

    def test_non_anthropic_model_passes_through(self) -> None:
        response_body = {"results": [{"outputText": "Titan answer."}]}
        fake_boto3, fake_client = self._build_fake_boto3(response_body)
        repo = _make_mock_repo()

        import json

        with patch.dict(sys.modules, {"boto3": fake_boto3}):
            if "devtorch_core.wrapper.bedrock" in sys.modules:
                del sys.modules["devtorch_core.wrapper.bedrock"]

            from devtorch_core.wrapper.bedrock import DevTorchBedrock

            client = DevTorchBedrock(gcc_repo=repo)
            original_body = json.dumps({"inputText": "Hello Titan"})
            client.invoke_model(
                modelId="amazon.titan-text-lite-v1",
                body=original_body,
                contentType="application/json",
                accept="application/json",
            )

        # Body should pass through unchanged for non-Anthropic models
        call_kwargs = fake_client.invoke_model.call_args[1]
        self.assertEqual(call_kwargs["body"], original_body)


# ===========================================================================
# 13. __init__ exports
# ===========================================================================


class TestWrapperInitExports(unittest.TestCase):

    def test_all_exports_importable(self) -> None:
        # Build minimal fakes for all SDKs so the imports don't fail
        for mod_name in ("anthropic", "openai", "boto3"):
            if mod_name not in sys.modules:
                sys.modules[mod_name] = types.ModuleType(mod_name)

        # google.generativeai
        if "google" not in sys.modules:
            google_mod = types.ModuleType("google")
            sys.modules["google"] = google_mod
        if "google.generativeai" not in sys.modules:
            sys.modules["google.generativeai"] = types.ModuleType("google.generativeai")

        # Clear cached wrapper modules so they re-import with our stubs
        for mod in list(sys.modules.keys()):
            if mod.startswith("devtorch_core.wrapper"):
                del sys.modules[mod]

        # Set up minimal stubs
        fake_anthropic = sys.modules["anthropic"]
        fake_anthropic.Anthropic = MagicMock

        fake_openai = sys.modules["openai"]
        fake_openai.OpenAI = MagicMock

        fake_boto3 = sys.modules["boto3"]
        fake_boto3.client = MagicMock

        fake_genai = sys.modules["google.generativeai"]
        fake_genai.GenerativeModel = MagicMock

        from devtorch_core.wrapper import (
            DevTorchAnthropic,
            DevTorchOpenAI,
            DevTorchGemini,
            DevTorchBedrock,
            RACPInjector,
            CaptureOrchestrator,
            find_gcc_repo,
            is_disabled,
        )

        for symbol in (
            DevTorchAnthropic,
            DevTorchOpenAI,
            DevTorchGemini,
            DevTorchBedrock,
            RACPInjector,
            CaptureOrchestrator,
            find_gcc_repo,
            is_disabled,
        ):
            self.assertIsNotNone(symbol)


if __name__ == "__main__":
    unittest.main(verbosity=2)
