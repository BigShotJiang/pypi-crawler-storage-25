"""
Sprint 8 — Textual Mode Aggφ: confidence weighting, I3 near-duplicate detection,
optional LLM path (mocked / disabled in CI).
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from devtorch_core import GCCRepository, SensitivityEvent
from devtorch_core.aggphi_textual import (
    ConfidenceWeightedAggPhi,
    TextualModeAggPhi,
    merge_i3_records,
    near_duplicate_pairs,
)
from devtorch_core.theta import RulesBasedAggPhi, ThetaStore, make_theta_store


def _ev(
    concept: str,
    conf: float,
    level: str = "PUBLIC",
    ts: str = "2025-01-01T12:00:00+00:00",
) -> dict:
    return {
        "target_concept": concept,
        "confidence": conf,
        "disclosure_level": level,
        "created_at": ts,
        "source_node": "n1",
    }


class TestNearDuplicatePairs:
    def test_finds_similar_names(self) -> None:
        pairs = near_duplicate_pairs(
            ["schema_version", "schema_verson", "latency"],
            threshold=0.82,
        )
        assert pairs, "expected typo pair detected"
        assert any(
            {p["concept_a"], p["concept_b"]} == {"schema_version", "schema_verson"}
            for p in pairs
        )

    def test_no_pairs_when_all_distinct(self) -> None:
        assert near_duplicate_pairs(["a", "b", "c"], threshold=0.95) == []

    def test_merge_i3_records_dedupes(self) -> None:
        a = [
            {"concept_a": "x", "concept_b": "y", "similarity": 0.9, "requires_i3_handshake": True},
        ]
        b = [
            {"concept_a": "x", "concept_b": "y", "similarity": 0.95, "requires_i3_handshake": True},
        ]
        m = merge_i3_records(a, b)
        assert len(m) == 1
        assert m[0]["similarity"] == 0.95


class TestConfidenceWeightedAggPhi:
    def test_downweights_low_confidence_vs_rules(self) -> None:
        """Same two events: weighted path should differ from rules-only path."""
        events = [
            _ev("c", 0.9, "PUBLIC", "2025-01-02T00:00:00+00:00"),
            _ev("c", 0.5, "PUBLIC", "2025-01-01T00:00:00+00:00"),
        ]
        rules = RulesBasedAggPhi().aggregate(events)
        cw = ConfidenceWeightedAggPhi().aggregate(events)
        assert rules["c"]["mean_confidence"] != cw["c"]["mean_confidence"]

    def test_epsilon_floor_for_very_low_confidence(self) -> None:
        """max(ε, conf) prevents zero-weight groups when confidence is 0."""
        events = [
            _ev("z", 0.0, "PUBLIC", "2025-01-02T00:00:00+00:00"),
            _ev("z", 0.0, "PUBLIC", "2025-01-01T00:00:00+00:00"),
        ]
        out = ConfidenceWeightedAggPhi(epsilon=0.05).aggregate(events)
        assert out["z"]["mean_confidence"] == 0.0
        assert out["z"]["event_count"] == 2

    def test_determinism(self) -> None:
        events = [_ev("x", 0.7, "PROTECTED"), _ev("x", 0.6, "PUBLIC")]
        a = ConfidenceWeightedAggPhi().aggregate(events)
        b = ConfidenceWeightedAggPhi().aggregate(events)
        assert a == b


class TestTextualModeAggPhi:
    def test_falls_back_to_weighted_without_llm(self) -> None:
        events = [_ev("k", 0.8, "PUBLIC")]
        t = TextualModeAggPhi(use_llm=False)
        w = ConfidenceWeightedAggPhi().aggregate(events)
        assert t.aggregate(events) == w

    def test_falls_back_to_weighted_when_llm_returns_none(self) -> None:
        events = [_ev("k", 0.75, "PROTECTED")]
        weighted = ConfidenceWeightedAggPhi().aggregate(events)
        with patch(
            "devtorch_core.aggphi_textual._try_llm_synthesize_delta",
            return_value=None,
        ):
            t = TextualModeAggPhi(use_llm=True)
            assert t.aggregate(events) == weighted

    def test_devtorch_disable_skips_llm_and_matches_weighted(self) -> None:
        events = [_ev("k", 0.66, "PUBLIC")]
        weighted = ConfidenceWeightedAggPhi().aggregate(events)
        with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}, clear=False):
            t = TextualModeAggPhi(use_llm=True)
            assert t.aggregate(events) == weighted

    def test_llm_branch_uses_response_when_valid(self) -> None:
        events = [_ev("only", 0.5, "PUBLIC")]
        fake_json = json.dumps(
            {
                "only": {
                    "mean_confidence": 0.99,
                    "disclosure_level": "PRIVATE",
                    "event_count": 1,
                }
            }
        )
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "test-key"}, clear=False):
            with patch(
                "devtorch_core.aggphi_textual._try_llm_synthesize_delta",
                return_value=json.loads(fake_json),
            ):
                t = TextualModeAggPhi(use_llm=True)
                out = t.aggregate(events)
        assert out["only"]["mean_confidence"] == 0.99
        assert out["only"]["disclosure_level"] == "PRIVATE"


class TestMakeThetaStore:
    def test_default_is_rules(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        monkeypatch.delenv("DEVTORCH_AGGPHI", raising=False)
        ts = make_theta_store(tmp_path)
        assert isinstance(ts.aggregator, RulesBasedAggPhi)

    def test_textual_mode(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        monkeypatch.setenv("DEVTORCH_AGGPHI", "textual")
        ts = make_theta_store(tmp_path)
        assert isinstance(ts.aggregator, TextualModeAggPhi)

    @pytest.mark.parametrize("mode", ("s8", "text", "TEXTUAL"))
    def test_textual_aliases(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path, mode: str) -> None:
        monkeypatch.setenv("DEVTORCH_AGGPHI", mode)
        ts = make_theta_store(tmp_path)
        assert isinstance(ts.aggregator, TextualModeAggPhi)


class TestThetaStoreRippleI3:
    def test_pending_merges_populated(self, tmp_path: Path) -> None:
        ts = ThetaStore(tmp_path, aggregator=TextualModeAggPhi())
        ts.ripple([_ev("schema_version", 0.9, "PUBLIC")])
        ts.ripple([_ev("schema_verson", 0.8, "PUBLIC")])
        theta = ts.load()
        pending = theta.get("pending_i3_merges", [])
        assert isinstance(pending, list)
        assert len(pending) >= 1
        assert pending[0].get("requires_i3_handshake") is True

    def test_rules_aggregator_does_not_populate_pending_i3(self, tmp_path: Path) -> None:
        ts = ThetaStore(tmp_path, aggregator=RulesBasedAggPhi())
        ts.ripple([_ev("schema_version", 0.9, "PUBLIC")])
        ts.ripple([_ev("schema_verson", 0.8, "PUBLIC")])
        theta = ts.load()
        assert "pending_i3_merges" not in theta

    def test_ripple_returns_fresh_load_including_i3(self, tmp_path: Path) -> None:
        ts = ThetaStore(tmp_path, aggregator=TextualModeAggPhi())
        ts.ripple([_ev("schema_version", 0.9, "PUBLIC")])
        returned = ts.ripple([_ev("schema_verson", 0.8, "PUBLIC")])
        assert returned.get("pending_i3_merges")
        assert returned == ts.load()


class TestEndToEndGCC:
    def test_repo_respects_textual_env(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        monkeypatch.setenv("DEVTORCH_AGGPHI", "textual")
        root = tmp_path / "proj"
        repo = GCCRepository.at(root)
        repo.init()
        e1 = SensitivityEvent(
            "a1",
            "auth_token",
            "cf",
            0.9,
            "PUBLIC",
        )
        e2 = SensitivityEvent(
            "a2",
            "auth_tokens",
            "cf",
            0.7,
            "PROTECTED",
        )
        repo.add_sensitivity(e1)
        repo.add_sensitivity(e2)
        theta = repo.get_theta()
        assert "pending_i3_merges" in theta
        assert isinstance(theta["pending_i3_merges"], list)
