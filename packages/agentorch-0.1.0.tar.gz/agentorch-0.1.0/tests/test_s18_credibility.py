"""
S18 — Metric Credibility Infrastructure tests.

Tests for MetricTier, Citation, DesignChoice, MetricMetadata, METRIC_REGISTRY,
and all helper functions in devtorch_core.metrics.credibility.
"""

from __future__ import annotations

import pytest

from devtorch_core.metrics.credibility import (
    Citation,
    DesignChoice,
    MetricMetadata,
    MetricTier,
    METRIC_REGISTRY,
    format_citation,
    get_metric_metadata,
    list_uncalibrated_metrics,
    metric_metadata_to_dict,
)


# ---------------------------------------------------------------------------
# TestMetricTier
# ---------------------------------------------------------------------------


class TestMetricTier:
    def test_measured_value(self):
        assert MetricTier.MEASURED.value == "measured"

    def test_calibrated_value(self):
        assert MetricTier.CALIBRATED.value == "calibrated"

    def test_unavailable_value(self):
        assert MetricTier.UNAVAILABLE.value == "unavailable"


# ---------------------------------------------------------------------------
# TestCitation
# ---------------------------------------------------------------------------


class TestCitation:
    def _sample(self) -> Citation:
        return Citation(
            title="A Study on Context Switching",
            authors="Smith, J.",
            year=2020,
            doi_or_url="https://doi.org/10.1234/test",
            claim="30 min recovery time",
            scope="Office workers only",
        )

    def test_dataclass_fields_present(self):
        c = self._sample()
        assert c.title == "A Study on Context Switching"
        assert c.authors == "Smith, J."
        assert c.year == 2020
        assert c.doi_or_url == "https://doi.org/10.1234/test"
        assert c.claim == "30 min recovery time"
        assert c.scope == "Office workers only"

    def test_format_citation_returns_non_empty(self):
        c = self._sample()
        result = format_citation(c)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_format_citation_contains_author(self):
        c = self._sample()
        result = format_citation(c)
        assert "Smith, J." in result

    def test_format_citation_contains_doi_url(self):
        c = self._sample()
        result = format_citation(c)
        assert "https://doi.org/10.1234/test" in result


# ---------------------------------------------------------------------------
# TestDesignChoice
# ---------------------------------------------------------------------------


class TestDesignChoice:
    def _sample(self) -> DesignChoice:
        return DesignChoice(
            name="test_weight",
            value=0.5,
            description="A balanced default weight.",
            calibration_instruction="Measure with your team data.",
        )

    def test_dataclass_fields_present(self):
        d = self._sample()
        assert d.name == "test_weight"
        assert d.value == 0.5
        assert d.description == "A balanced default weight."
        assert d.calibration_instruction == "Measure with your team data."

    def test_value_field_accepts_any_type(self):
        # value should accept str, int, float, None, list, etc.
        dc_str = DesignChoice(name="a", value="hello", description="d", calibration_instruction="i")
        dc_none = DesignChoice(name="b", value=None, description="d", calibration_instruction="i")
        dc_list = DesignChoice(name="c", value=[1, 2, 3], description="d", calibration_instruction="i")
        assert dc_str.value == "hello"
        assert dc_none.value is None
        assert dc_list.value == [1, 2, 3]

    def test_calibration_instruction_is_string(self):
        d = self._sample()
        assert isinstance(d.calibration_instruction, str)


# ---------------------------------------------------------------------------
# TestMetricMetadata
# ---------------------------------------------------------------------------


class TestMetricMetadata:
    def test_citations_defaults_to_empty_list(self):
        m = MetricMetadata(metric_name="foo", tier=MetricTier.MEASURED)
        assert m.citations == []

    def test_design_choices_defaults_to_empty_list(self):
        m = MetricMetadata(metric_name="foo", tier=MetricTier.MEASURED)
        assert m.design_choices == []

    def test_unavailable_reason_defaults_to_empty_string(self):
        m = MetricMetadata(metric_name="foo", tier=MetricTier.MEASURED)
        assert m.unavailable_reason == ""

    def test_calibration_required_defaults_to_empty_list(self):
        m = MetricMetadata(metric_name="foo", tier=MetricTier.MEASURED)
        assert m.calibration_required == []

    def test_tier_field_is_metric_tier_instance(self):
        m = MetricMetadata(metric_name="foo", tier=MetricTier.CALIBRATED)
        assert isinstance(m.tier, MetricTier)


# ---------------------------------------------------------------------------
# TestMetricRegistry
# ---------------------------------------------------------------------------


class TestMetricRegistry:
    def test_metric_registry_is_dict(self):
        assert isinstance(METRIC_REGISTRY, dict)

    def test_commit_count_is_measured(self):
        assert METRIC_REGISTRY["commit_count"].tier == MetricTier.MEASURED

    def test_context_switch_minutes_is_calibrated(self):
        assert METRIC_REGISTRY["context_switch_minutes"].tier == MetricTier.CALIBRATED

    def test_rework_minutes_per_collision_is_unavailable(self):
        assert METRIC_REGISTRY["rework_minutes_per_collision"].tier == MetricTier.UNAVAILABLE

    def test_mcs_score_is_calibrated(self):
        assert METRIC_REGISTRY["mcs_score"].tier == MetricTier.CALIBRATED

    def test_dhs_score_is_calibrated(self):
        assert METRIC_REGISTRY["dhs_score"].tier == MetricTier.CALIBRATED

    def test_context_switch_minutes_has_at_least_one_citation(self):
        meta = METRIC_REGISTRY["context_switch_minutes"]
        assert len(meta.citations) >= 1

    def test_auditor_hourly_rate_citation_contains_bls_url(self):
        meta = METRIC_REGISTRY["auditor_hourly_rate"]
        assert len(meta.citations) >= 1
        urls = [c.doi_or_url for c in meta.citations]
        assert any("bls.gov" in url for url in urls)


# ---------------------------------------------------------------------------
# TestHelperFunctions
# ---------------------------------------------------------------------------


class TestHelperFunctions:
    def test_get_metric_metadata_returns_metadata_for_known_metric(self):
        result = get_metric_metadata("commit_count")
        assert isinstance(result, MetricMetadata)
        assert result.metric_name == "commit_count"

    def test_get_metric_metadata_returns_none_for_unknown_metric(self):
        result = get_metric_metadata("nonexistent_metric_xyz")
        assert result is None

    def test_list_uncalibrated_metrics_empty_dict_contains_developer_hourly_rate(self):
        uncalibrated = list_uncalibrated_metrics({})
        assert "developer_hourly_rate" in uncalibrated

    def test_list_uncalibrated_metrics_with_rate_set_excludes_developer_hourly_rate(self):
        uncalibrated = list_uncalibrated_metrics({"developer_hourly_rate": 60.0})
        assert "developer_hourly_rate" not in uncalibrated

    def test_metric_metadata_to_dict_returns_dict_with_tier_key(self):
        meta = get_metric_metadata("commit_count")
        result = metric_metadata_to_dict(meta)
        assert isinstance(result, dict)
        assert "tier" in result
        assert result["tier"] == "measured"
