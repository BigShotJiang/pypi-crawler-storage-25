"""
S11 — Tests for devtorch_core.hooks.installer
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from devtorch_core.hooks.installer import (
    CLAUDE_HOOKS_CONFIG,
    HookInstallResult,
    install_claude_hooks,
    install_git_commit_hook,
    install_all_hooks,
    get_hooks_status,
)


# ---------------------------------------------------------------------------
# CLAUDE_HOOKS_CONFIG structure tests
# ---------------------------------------------------------------------------


def test_claude_hooks_config_has_hooks_key():
    """CLAUDE_HOOKS_CONFIG must have a top-level 'hooks' key."""
    assert "hooks" in CLAUDE_HOOKS_CONFIG


def test_claude_hooks_config_has_pre_tool_use():
    """CLAUDE_HOOKS_CONFIG['hooks'] must have 'PreToolUse' key."""
    assert "PreToolUse" in CLAUDE_HOOKS_CONFIG["hooks"]


def test_claude_hooks_config_has_post_tool_use():
    """CLAUDE_HOOKS_CONFIG['hooks'] must have 'PostToolUse' key."""
    assert "PostToolUse" in CLAUDE_HOOKS_CONFIG["hooks"]


def test_claude_hooks_config_has_stop():
    """CLAUDE_HOOKS_CONFIG['hooks'] must have 'Stop' key."""
    assert "Stop" in CLAUDE_HOOKS_CONFIG["hooks"]


def test_claude_hooks_config_pre_tool_use_matcher():
    """PreToolUse entry must have matcher='*'."""
    entries = CLAUDE_HOOKS_CONFIG["hooks"]["PreToolUse"]
    assert any(e.get("matcher") == "*" for e in entries)


def test_claude_hooks_config_post_tool_use_matcher():
    """PostToolUse entry must have matcher='*'."""
    entries = CLAUDE_HOOKS_CONFIG["hooks"]["PostToolUse"]
    assert any(e.get("matcher") == "*" for e in entries)


def test_claude_hooks_config_pre_tool_use_command_contains_devtorch():
    """PreToolUse command must contain 'devtorch hooks run'."""
    entries = CLAUDE_HOOKS_CONFIG["hooks"]["PreToolUse"]
    commands = [
        hook["command"]
        for e in entries
        for hook in e.get("hooks", [])
        if "command" in hook
    ]
    assert any("devtorch hooks run" in cmd for cmd in commands)


def test_claude_hooks_config_post_tool_use_command_contains_devtorch():
    """PostToolUse command must contain 'devtorch hooks run'."""
    entries = CLAUDE_HOOKS_CONFIG["hooks"]["PostToolUse"]
    commands = [
        hook["command"]
        for e in entries
        for hook in e.get("hooks", [])
        if "command" in hook
    ]
    assert any("devtorch hooks run" in cmd for cmd in commands)


def test_claude_hooks_config_stop_command_contains_devtorch():
    """Stop command must contain 'devtorch hooks run'."""
    entries = CLAUDE_HOOKS_CONFIG["hooks"]["Stop"]
    commands = [
        hook["command"]
        for e in entries
        for hook in e.get("hooks", [])
        if "command" in hook
    ]
    assert any("devtorch hooks run" in cmd for cmd in commands)


# ---------------------------------------------------------------------------
# HookInstallResult dataclass tests
# ---------------------------------------------------------------------------


def test_hook_install_result_fields():
    """HookInstallResult must have the expected fields."""
    result = HookInstallResult()
    assert hasattr(result, "claude_hooks_written")
    assert hasattr(result, "claude_hooks_path")
    assert hasattr(result, "git_hook_written")
    assert hasattr(result, "git_hook_path")
    assert hasattr(result, "errors")


def test_hook_install_result_defaults():
    """HookInstallResult default values are sensible."""
    result = HookInstallResult()
    assert result.claude_hooks_written is False
    assert result.claude_hooks_path == ""
    assert result.git_hook_written is False
    assert result.git_hook_path == ""
    assert result.errors == []


# ---------------------------------------------------------------------------
# install_claude_hooks tests
# ---------------------------------------------------------------------------


def test_install_claude_hooks_creates_claude_dir():
    """install_claude_hooks creates .claude/ directory if missing."""
    with tempfile.TemporaryDirectory() as tmp:
        install_claude_hooks(tmp)
        assert (Path(tmp) / ".claude").is_dir()


def test_install_claude_hooks_writes_valid_json():
    """install_claude_hooks writes a file parseable as JSON."""
    with tempfile.TemporaryDirectory() as tmp:
        install_claude_hooks(tmp)
        hooks_path = Path(tmp) / ".claude" / "hooks.json"
        content = json.loads(hooks_path.read_text())
        assert isinstance(content, dict)


def test_install_claude_hooks_written_json_has_hooks_key():
    """Written hooks.json must have 'hooks' key."""
    with tempfile.TemporaryDirectory() as tmp:
        install_claude_hooks(tmp)
        hooks_path = Path(tmp) / ".claude" / "hooks.json"
        content = json.loads(hooks_path.read_text())
        assert "hooks" in content


def test_install_claude_hooks_returns_true_on_success():
    """install_claude_hooks returns True as first element on success."""
    with tempfile.TemporaryDirectory() as tmp:
        ok, _ = install_claude_hooks(tmp)
        assert ok is True


def test_install_claude_hooks_returns_path_ending_in_hooks_json():
    """install_claude_hooks returns a path ending in 'hooks.json'."""
    with tempfile.TemporaryDirectory() as tmp:
        _, path = install_claude_hooks(tmp)
        assert path.endswith("hooks.json")


def test_install_claude_hooks_merge_keeps_existing_keys():
    """install_claude_hooks does NOT remove pre-existing keys from hooks.json."""
    with tempfile.TemporaryDirectory() as tmp:
        claude_dir = Path(tmp) / ".claude"
        claude_dir.mkdir()
        existing = {"my_custom_key": "my_value", "hooks": {"CustomEvent": [{"hooks": [{"type": "command", "command": "custom cmd"}]}]}}
        (claude_dir / "hooks.json").write_text(json.dumps(existing))

        install_claude_hooks(tmp)

        merged = json.loads((claude_dir / "hooks.json").read_text())
        assert merged.get("my_custom_key") == "my_value"


def test_install_claude_hooks_merge_adds_devtorch_keys():
    """install_claude_hooks adds DevTorch hook keys to existing hooks.json."""
    with tempfile.TemporaryDirectory() as tmp:
        claude_dir = Path(tmp) / ".claude"
        claude_dir.mkdir()
        existing = {"hooks": {"CustomEvent": [{"hooks": [{"type": "command", "command": "custom cmd"}]}]}}
        (claude_dir / "hooks.json").write_text(json.dumps(existing))

        install_claude_hooks(tmp)

        merged = json.loads((claude_dir / "hooks.json").read_text())
        hooks = merged.get("hooks", {})
        assert "PreToolUse" in hooks
        assert "PostToolUse" in hooks
        assert "Stop" in hooks


def test_install_claude_hooks_merge_does_not_overwrite_existing_event():
    """Merge keeps both DevTorch and pre-existing hook entries."""
    with tempfile.TemporaryDirectory() as tmp:
        claude_dir = Path(tmp) / ".claude"
        claude_dir.mkdir()
        existing = {
            "hooks": {
                "PreToolUse": [
                    {"matcher": "Write", "hooks": [{"type": "command", "command": "my-existing-hook"}]}
                ]
            }
        }
        (claude_dir / "hooks.json").write_text(json.dumps(existing))

        install_claude_hooks(tmp)

        merged = json.loads((claude_dir / "hooks.json").read_text())
        pre_tool_entries = merged["hooks"]["PreToolUse"]
        all_commands = [
            hook["command"]
            for entry in pre_tool_entries
            for hook in entry.get("hooks", [])
        ]
        # Both commands must be present
        assert "my-existing-hook" in all_commands
        assert any("devtorch hooks run" in cmd for cmd in all_commands)


# ---------------------------------------------------------------------------
# install_git_commit_hook tests
# ---------------------------------------------------------------------------


def test_install_git_commit_hook_returns_false_no_git():
    """install_git_commit_hook returns (False, msg) when no .git found."""
    with tempfile.TemporaryDirectory() as tmp:
        ok, msg = install_git_commit_hook(tmp)
        assert ok is False
        assert "no .git found" in msg


def test_install_git_commit_hook_returns_true_when_git_exists():
    """install_git_commit_hook returns (True, path) when .git/hooks/ exists."""
    with tempfile.TemporaryDirectory() as tmp:
        # Create a minimal .git/hooks/ directory
        hooks_dir = Path(tmp) / ".git" / "hooks"
        hooks_dir.mkdir(parents=True)

        # install_hook is imported inside the function body, so we patch the source
        with patch("devtorch_core.hooks.git_commit.install_hook") as mock_install:
            mock_install.return_value = None
            ok, path = install_git_commit_hook(tmp)

        assert ok is True
        assert "commit-msg" in path


# ---------------------------------------------------------------------------
# install_all_hooks tests
# ---------------------------------------------------------------------------


def test_install_all_hooks_returns_hook_install_result():
    """install_all_hooks returns a HookInstallResult instance."""
    with tempfile.TemporaryDirectory() as tmp:
        result = install_all_hooks(tmp)
        assert isinstance(result, HookInstallResult)


def test_install_all_hooks_never_raises_on_permission_error():
    """install_all_hooks catches exceptions and never raises."""
    with tempfile.TemporaryDirectory() as tmp:
        with patch(
            "devtorch_core.hooks.installer.install_claude_hooks",
            side_effect=PermissionError("no write"),
        ):
            result = install_all_hooks(tmp)
        # Must not raise; errors must be captured
        assert isinstance(result, HookInstallResult)


def test_install_all_hooks_captures_errors_in_list():
    """install_all_hooks captures errors in result.errors when installs fail."""
    with tempfile.TemporaryDirectory() as tmp:
        with patch(
            "devtorch_core.hooks.installer.install_claude_hooks",
            side_effect=RuntimeError("boom"),
        ):
            result = install_all_hooks(tmp)
        assert len(result.errors) >= 1


def test_install_all_hooks_git_hook_false_when_no_git():
    """install_all_hooks reports git_hook_written=False when no .git found."""
    with tempfile.TemporaryDirectory() as tmp:
        result = install_all_hooks(tmp)
        assert result.git_hook_written is False


def test_install_all_hooks_claude_hooks_true_on_clean_dir():
    """install_all_hooks writes Claude hooks successfully in a clean directory."""
    with tempfile.TemporaryDirectory() as tmp:
        result = install_all_hooks(tmp)
        assert result.claude_hooks_written is True
        assert result.claude_hooks_path.endswith("hooks.json")


# ---------------------------------------------------------------------------
# get_hooks_status tests
# ---------------------------------------------------------------------------


def test_get_hooks_status_returns_dict():
    """get_hooks_status returns a dict."""
    with tempfile.TemporaryDirectory() as tmp:
        status = get_hooks_status(tmp)
        assert isinstance(status, dict)


def test_get_hooks_status_has_expected_keys():
    """get_hooks_status dict has all required keys."""
    with tempfile.TemporaryDirectory() as tmp:
        status = get_hooks_status(tmp)
        assert "claude_hooks" in status
        assert "claude_hooks_path" in status
        assert "git_hook" in status
        assert "git_hook_path" in status


def test_get_hooks_status_claude_hooks_false_when_file_missing():
    """get_hooks_status returns claude_hooks=False when file doesn't exist."""
    with tempfile.TemporaryDirectory() as tmp:
        status = get_hooks_status(tmp)
        assert status["claude_hooks"] is False


def test_get_hooks_status_claude_hooks_true_when_file_exists():
    """get_hooks_status returns claude_hooks=True when hooks.json exists."""
    with tempfile.TemporaryDirectory() as tmp:
        claude_dir = Path(tmp) / ".claude"
        claude_dir.mkdir()
        (claude_dir / "hooks.json").write_text("{}")
        status = get_hooks_status(tmp)
        assert status["claude_hooks"] is True


def test_get_hooks_status_is_read_only():
    """get_hooks_status does not create any files (pure read)."""
    with tempfile.TemporaryDirectory() as tmp:
        before = set(Path(tmp).rglob("*"))
        get_hooks_status(tmp)
        after = set(Path(tmp).rglob("*"))
        # No new files or directories created
        assert after == before
