"""
Sprint 8 — Textual Mode AggPhi: LLM-powered Θ synthesis tests.

Tests cover:
- ThetaSynthesisConfig defaults
- ThetaSynthesisResult defaults
- build_synthesis_prompt behaviour
- synthesise_theta skip paths (DEVTORCH_DISABLE, empty theta, missing anthropic, API error)
- synthesise_theta happy path (mock Anthropic client)
- run_synthesis_if_eligible gate logic
"""

from __future__ import annotations

import os
import sys
import unittest
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Module under test
# ---------------------------------------------------------------------------
from devtorch_core.theta_synthesis import (
    ThetaSynthesisConfig,
    ThetaSynthesisResult,
    build_synthesis_prompt,
    run_synthesis_if_eligible,
    synthesise_theta,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_theta_vector(n: int = 5) -> dict:
    """Return a simple coordination_vector dict with n concepts."""
    return {
        f"concept_{i}": {
            "mean_confidence": round(0.5 + i * 0.05, 3),
            "disclosure_level": "PROTECTED",
            "event_count": i + 1,
        }
        for i in range(n)
    }


def _make_repo(coordination_vector: dict | None = None) -> MagicMock:
    """Return a mock gcc_repo with get_theta() and update_theta_field() wired up."""
    repo = MagicMock()
    cv = coordination_vector if coordination_vector is not None else _make_theta_vector()
    repo.get_theta.return_value = {"coordination_vector": cv}
    repo.update_theta_field.return_value = None
    return repo


def _make_anthropic_response(text: str = "Test summary.", input_tokens: int = 50, output_tokens: int = 30) -> MagicMock:
    """Build a mock Anthropic messages.create response."""
    content_block = MagicMock()
    content_block.text = text

    usage = MagicMock()
    usage.input_tokens = input_tokens
    usage.output_tokens = output_tokens

    response = MagicMock()
    response.content = [content_block]
    response.usage = usage
    return response


# ===========================================================================
# 1. Config defaults
# ===========================================================================

class TestThetaSynthesisConfig(unittest.TestCase):

    def test_default_max_concepts(self):
        cfg = ThetaSynthesisConfig()
        self.assertEqual(cfg.max_concepts, 10)

    def test_default_max_summary_chars(self):
        cfg = ThetaSynthesisConfig()
        self.assertEqual(cfg.max_summary_chars, 500)

    def test_default_model(self):
        cfg = ThetaSynthesisConfig()
        self.assertEqual(cfg.model, "claude-haiku-4-5-20251001")

    def test_default_temperature(self):
        cfg = ThetaSynthesisConfig()
        self.assertAlmostEqual(cfg.temperature, 0.3)

    def test_custom_values(self):
        cfg = ThetaSynthesisConfig(max_concepts=5, max_summary_chars=200, model="claude-opus", temperature=0.7)
        self.assertEqual(cfg.max_concepts, 5)
        self.assertEqual(cfg.max_summary_chars, 200)
        self.assertEqual(cfg.model, "claude-opus")
        self.assertAlmostEqual(cfg.temperature, 0.7)


# ===========================================================================
# 2. Result defaults
# ===========================================================================

class TestThetaSynthesisResult(unittest.TestCase):

    def test_skipped_default_is_false(self):
        result = ThetaSynthesisResult(summary="x", concepts_used=[], model="m", tokens_used=0)
        self.assertFalse(result.skipped)

    def test_skip_reason_default_is_empty(self):
        result = ThetaSynthesisResult(summary="x", concepts_used=[], model="m", tokens_used=0)
        self.assertEqual(result.skip_reason, "")

    def test_explicit_skipped(self):
        result = ThetaSynthesisResult(summary="", concepts_used=[], model="m", tokens_used=0, skipped=True, skip_reason="reason")
        self.assertTrue(result.skipped)
        self.assertEqual(result.skip_reason, "reason")


# ===========================================================================
# 3. build_synthesis_prompt
# ===========================================================================

class TestBuildSynthesisPrompt(unittest.TestCase):

    def test_returns_string(self):
        theta = _make_theta_vector(3)
        result = build_synthesis_prompt(theta)
        self.assertIsInstance(result, str)

    def test_contains_concept_names(self):
        theta = {"alpha": {"mean_confidence": 0.9}, "beta": {"mean_confidence": 0.7}}
        prompt = build_synthesis_prompt(theta)
        self.assertIn("alpha", prompt)
        self.assertIn("beta", prompt)

    def test_contains_confidence_scores(self):
        theta = {"my_concept": {"mean_confidence": 0.85}}
        prompt = build_synthesis_prompt(theta)
        self.assertIn("0.850", prompt)

    def test_respects_max_concepts_limit(self):
        # 20 concepts, but max_concepts=3 → only 3 appear as concept entries
        theta = {f"concept_{i}": {"mean_confidence": i * 0.05} for i in range(20)}
        prompt = build_synthesis_prompt(theta, max_concepts=3)
        # Match exact entry lines like "  - concept_19:" to avoid prefix collisions
        import re
        present = [k for k in theta if re.search(rf"- {re.escape(k)}:", prompt)]
        self.assertLessEqual(len(present), 3)

    def test_selects_top_concepts_by_confidence(self):
        theta = {
            "low_conf": {"mean_confidence": 0.1},
            "high_conf": {"mean_confidence": 0.95},
            "mid_conf": {"mean_confidence": 0.5},
        }
        prompt = build_synthesis_prompt(theta, max_concepts=1)
        self.assertIn("high_conf", prompt)
        self.assertNotIn("low_conf", prompt)

    def test_empty_theta_returns_non_empty_string(self):
        prompt = build_synthesis_prompt({})
        self.assertIsInstance(prompt, str)
        self.assertGreater(len(prompt), 0)

    def test_prompt_mentions_summary_intent(self):
        theta = {"concept_a": {"mean_confidence": 0.8}}
        prompt = build_synthesis_prompt(theta)
        # Should mention summarising or synthesis intent
        lower = prompt.lower()
        self.assertTrue("summar" in lower or "synthes" in lower or "learned" in lower)


# ===========================================================================
# 4. synthesise_theta — skip paths
# ===========================================================================

class TestSynthesiseThetaSkipPaths(unittest.TestCase):

    def setUp(self):
        # Ensure DEVTORCH_DISABLE is not set unless the test sets it
        os.environ.pop("DEVTORCH_DISABLE", None)

    def tearDown(self):
        os.environ.pop("DEVTORCH_DISABLE", None)

    def test_skipped_when_devtorch_disable_set(self):
        os.environ["DEVTORCH_DISABLE"] = "1"
        repo = _make_repo()
        result = synthesise_theta(repo)
        self.assertTrue(result.skipped)
        self.assertIn("DEVTORCH_DISABLE", result.skip_reason)
        repo.get_theta.assert_not_called()

    def test_skipped_when_devtorch_disable_truthy_string(self):
        os.environ["DEVTORCH_DISABLE"] = "true"
        repo = _make_repo()
        result = synthesise_theta(repo)
        self.assertTrue(result.skipped)

    def test_skipped_when_theta_is_empty(self):
        repo = MagicMock()
        repo.get_theta.return_value = {"coordination_vector": {}}
        result = synthesise_theta(repo)
        self.assertTrue(result.skipped)
        self.assertEqual(result.skip_reason, "empty theta")

    def test_skipped_when_theta_has_no_coordination_vector_key(self):
        repo = MagicMock()
        repo.get_theta.return_value = {}
        result = synthesise_theta(repo)
        self.assertTrue(result.skipped)
        self.assertEqual(result.skip_reason, "empty theta")

    def test_skipped_when_anthropic_not_importable(self):
        repo = _make_repo()
        # Simulate anthropic not being installed by blocking the import
        with patch.dict(sys.modules, {"anthropic": None}):
            result = synthesise_theta(repo)
        self.assertTrue(result.skipped)
        self.assertIn("anthropic", result.skip_reason.lower())

    def test_skipped_on_api_exception(self):
        repo = _make_repo()
        mock_client = MagicMock()
        mock_client.messages.create.side_effect = RuntimeError("connection refused")
        mock_anthropic_module = MagicMock()
        mock_anthropic_module.Anthropic.return_value = mock_client

        with patch.dict(sys.modules, {"anthropic": mock_anthropic_module}):
            result = synthesise_theta(repo)

        self.assertTrue(result.skipped)
        self.assertIn("connection refused", result.skip_reason)

    def test_never_raises_on_api_exception(self):
        repo = _make_repo()
        mock_client = MagicMock()
        mock_client.messages.create.side_effect = Exception("kaboom")
        mock_anthropic_module = MagicMock()
        mock_anthropic_module.Anthropic.return_value = mock_client

        with patch.dict(sys.modules, {"anthropic": mock_anthropic_module}):
            # Must not raise — returns skipped result
            result = synthesise_theta(repo)
        self.assertIsInstance(result, ThetaSynthesisResult)
        self.assertTrue(result.skipped)


# ===========================================================================
# 5. synthesise_theta — happy path
# ===========================================================================

class TestSynthesiseThetaHappyPath(unittest.TestCase):

    def setUp(self):
        os.environ.pop("DEVTORCH_DISABLE", None)

    def _run_with_mock(self, repo=None, config=None, response_text="The team knows security.", input_tokens=40, output_tokens=20):
        if repo is None:
            repo = _make_repo()
        mock_response = _make_anthropic_response(response_text, input_tokens, output_tokens)
        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_response
        mock_anthropic_module = MagicMock()
        mock_anthropic_module.Anthropic.return_value = mock_client

        with patch.dict(sys.modules, {"anthropic": mock_anthropic_module}):
            result = synthesise_theta(repo, config)
        return result, mock_client

    def test_happy_path_skipped_is_false(self):
        result, _ = self._run_with_mock()
        self.assertFalse(result.skipped)

    def test_happy_path_summary_in_result(self):
        result, _ = self._run_with_mock(response_text="Team learned about data privacy.")
        self.assertEqual(result.summary, "Team learned about data privacy.")

    def test_happy_path_concepts_used_populated(self):
        result, _ = self._run_with_mock()
        self.assertIsInstance(result.concepts_used, list)
        self.assertGreater(len(result.concepts_used), 0)

    def test_happy_path_tokens_used_positive(self):
        result, _ = self._run_with_mock(input_tokens=50, output_tokens=30)
        self.assertEqual(result.tokens_used, 80)

    def test_happy_path_model_in_result(self):
        cfg = ThetaSynthesisConfig(model="claude-haiku-4-5-20251001")
        result, _ = self._run_with_mock(config=cfg)
        self.assertEqual(result.model, "claude-haiku-4-5-20251001")

    def test_summary_truncated_to_max_summary_chars(self):
        long_text = "A" * 1000
        cfg = ThetaSynthesisConfig(max_summary_chars=100)
        result, _ = self._run_with_mock(config=cfg, response_text=long_text)
        self.assertEqual(len(result.summary), 100)
        self.assertEqual(result.summary, "A" * 100)

    def test_summary_not_truncated_when_within_limit(self):
        short_text = "Short."
        cfg = ThetaSynthesisConfig(max_summary_chars=500)
        result, _ = self._run_with_mock(config=cfg, response_text=short_text)
        self.assertEqual(result.summary, "Short.")

    def test_calls_update_theta_field(self):
        repo = _make_repo()
        result, _ = self._run_with_mock(repo=repo, response_text="Summary text.")
        repo.update_theta_field.assert_called_once_with("textual_summary", "Summary text.")

    def test_update_theta_field_receives_truncated_summary(self):
        long_text = "B" * 1000
        cfg = ThetaSynthesisConfig(max_summary_chars=50)
        repo = _make_repo()
        self._run_with_mock(repo=repo, config=cfg, response_text=long_text)
        repo.update_theta_field.assert_called_once_with("textual_summary", "B" * 50)

    def test_concepts_used_capped_by_max_concepts(self):
        cv = {f"concept_{i}": {"mean_confidence": i * 0.05} for i in range(20)}
        repo = _make_repo(coordination_vector=cv)
        cfg = ThetaSynthesisConfig(max_concepts=3)
        result, _ = self._run_with_mock(repo=repo, config=cfg)
        self.assertLessEqual(len(result.concepts_used), 3)

    def test_api_called_with_correct_model(self):
        cfg = ThetaSynthesisConfig(model="claude-haiku-4-5-20251001")
        result, mock_client = self._run_with_mock(config=cfg)
        call_kwargs = mock_client.messages.create.call_args
        self.assertEqual(call_kwargs.kwargs.get("model") or call_kwargs[1].get("model"), "claude-haiku-4-5-20251001")

    def test_api_called_with_correct_temperature(self):
        cfg = ThetaSynthesisConfig(temperature=0.1)
        result, mock_client = self._run_with_mock(config=cfg)
        call_kwargs = mock_client.messages.create.call_args
        kwargs = call_kwargs.kwargs if call_kwargs.kwargs else call_kwargs[1]
        self.assertAlmostEqual(kwargs.get("temperature"), 0.1)


# ===========================================================================
# 6. run_synthesis_if_eligible
# ===========================================================================

class TestRunSynthesisIfEligible(unittest.TestCase):

    def setUp(self):
        os.environ.pop("DEVTORCH_DISABLE", None)

    def _run_eligible_with_mock(self, repo=None, omega_capability=None, response_text="Eligible summary."):
        if repo is None:
            repo = _make_repo()
        mock_response = _make_anthropic_response(response_text)
        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_response
        mock_anthropic_module = MagicMock()
        mock_anthropic_module.Anthropic.return_value = mock_client

        with patch.dict(sys.modules, {"anthropic": mock_anthropic_module}):
            result = run_synthesis_if_eligible(repo, omega_capability)
        return result

    def test_passes_through_to_synthesise_theta_when_no_capability(self):
        result = self._run_eligible_with_mock(omega_capability=None, response_text="No gate result.")
        self.assertFalse(result.skipped)
        self.assertEqual(result.summary, "No gate result.")

    def test_skips_when_omega_capability_textual_mode_allowed_is_false(self):
        cap = MagicMock()
        cap.textual_mode_allowed = False
        repo = _make_repo()
        result = run_synthesis_if_eligible(repo, cap)
        self.assertTrue(result.skipped)
        self.assertIn("A1 gate", result.skip_reason)

    def test_skip_reason_contains_textual_mode_not_allowed(self):
        cap = MagicMock()
        cap.textual_mode_allowed = False
        repo = _make_repo()
        result = run_synthesis_if_eligible(repo, cap)
        self.assertIn("textual mode not allowed", result.skip_reason)

    def test_runs_when_omega_capability_textual_mode_allowed_is_true(self):
        cap = MagicMock()
        cap.textual_mode_allowed = True
        result = self._run_eligible_with_mock(omega_capability=cap, response_text="Gate passed.")
        self.assertFalse(result.skipped)
        self.assertEqual(result.summary, "Gate passed.")

    def test_runs_when_textual_mode_allowed_is_callable_returning_true(self):
        cap = MagicMock()
        cap.textual_mode_allowed = MagicMock(return_value=(True, []))
        result = self._run_eligible_with_mock(omega_capability=cap, response_text="Callable gate passed.")
        self.assertFalse(result.skipped)

    def test_skips_when_textual_mode_allowed_is_callable_returning_false(self):
        cap = MagicMock()
        cap.textual_mode_allowed = MagicMock(return_value=(False, ["expired"]))
        repo = _make_repo()
        result = run_synthesis_if_eligible(repo, cap)
        self.assertTrue(result.skipped)
        self.assertIn("A1 gate", result.skip_reason)

    def test_returns_theta_synthesis_result_type(self):
        result = self._run_eligible_with_mock(omega_capability=None)
        self.assertIsInstance(result, ThetaSynthesisResult)

    def test_skipped_result_has_empty_summary(self):
        cap = MagicMock()
        cap.textual_mode_allowed = False
        repo = _make_repo()
        result = run_synthesis_if_eligible(repo, cap)
        self.assertEqual(result.summary, "")

    def test_skipped_result_tokens_used_is_zero(self):
        cap = MagicMock()
        cap.textual_mode_allowed = False
        repo = _make_repo()
        result = run_synthesis_if_eligible(repo, cap)
        self.assertEqual(result.tokens_used, 0)


if __name__ == "__main__":
    unittest.main()
