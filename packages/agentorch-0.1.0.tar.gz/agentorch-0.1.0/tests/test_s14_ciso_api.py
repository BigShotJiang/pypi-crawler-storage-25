"""
Sprint 14 – CISO API endpoint tests.

Tests the GET /api/v1/ciso endpoint added to dashboard_api.py.
The endpoint is intentionally resilient: it returns safe defaults for
uninitialized or partially-initialized repos rather than raising 503.

Coverage:
 - Basic 200 response (2 tests: initialized + uninitialized)
 - Top-level keys present (3 tests)
 - rdp_budget field types (4 tests)
 - conformance key presence and types (3 tests)
 - sensitivity_summary structure (3 tests)
 - Counts and misc fields (5 tests)
 - Data-backed reads (3 tests)

Total: >= 15 tests required
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Guard: skip entire module if proxy / dashboard deps not installed
# ---------------------------------------------------------------------------

pytest.importorskip("fastapi", reason="fastapi not installed — run: pip install devtorch[proxy]")
pytest.importorskip("httpx", reason="httpx not installed — run: pip install devtorch[proxy]")

from fastapi.testclient import TestClient

from devtorch_core.dashboard_api import create_app
from devtorch_core.gcc import GCCRepository

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

CONFORMANCE_KEYS = {
    "I1_commit_backed",
    "I3_semantic_grounding",
    "A1_capability_gate",
    "A2_variance_control",
    "A3_sis_quarantine",
    "A4_deltaf_bound",
}


@pytest.fixture()
def repo(tmp_path: Path) -> GCCRepository:
    """Initialized GCCRepository with one commit."""
    r = GCCRepository.at(tmp_path)
    r.init()
    r.commit("initial commit")
    return r


@pytest.fixture()
def client(repo: GCCRepository) -> TestClient:
    app = create_app(gcc_repo=repo.root)
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture()
def empty_client(tmp_path: Path) -> TestClient:
    """Client pointing at an *uninitialized* directory."""
    app = create_app(gcc_repo=tmp_path)
    return TestClient(app, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Helper: write mock data files
# ---------------------------------------------------------------------------


def _write_rdp_state(gcc_dir: Path, epsilon_used: float, epsilon_max: float, read_only: bool) -> None:
    rdp_dir = gcc_dir / ".GCC" / "rdp"
    rdp_dir.mkdir(parents=True, exist_ok=True)
    (rdp_dir / "rdp_state.json").write_text(
        json.dumps({
            "epsilon_used": epsilon_used,
            "epsilon_max": epsilon_max,
            "read_only": read_only,
            "exhausted": read_only,
        }),
        encoding="utf-8",
    )


def _write_sensitivity_events(gcc_dir: Path, events: list[dict]) -> None:
    sens_dir = gcc_dir / ".GCC" / "sensitivities"
    sens_dir.mkdir(parents=True, exist_ok=True)
    events_file = sens_dir / "events.jsonl"
    with events_file.open("a", encoding="utf-8") as fh:
        for ev in events:
            fh.write(json.dumps(ev) + "\n")


def _write_sis_report(gcc_dir: Path, quarantine_count: int) -> None:
    sis_dir = gcc_dir / ".GCC" / "sis"
    sis_dir.mkdir(parents=True, exist_ok=True)
    (sis_dir / "sis_tc_report.json").write_text(
        json.dumps({"quarantine_count": quarantine_count, "passed": quarantine_count == 0}),
        encoding="utf-8",
    )


def _write_variance_alert(gcc_dir: Path) -> None:
    """Append a VARIANCE_ALERT event to the main event log."""
    events_log = gcc_dir / ".GCC" / "events.log.jsonl"
    event = {
        "event_id": str(uuid.uuid4()),
        "event_type": "VARIANCE_ALERT",
        "timestamp": "2026-04-18T10:00:00+00:00",
        "message": "variance threshold exceeded",
    }
    with events_log.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(event) + "\n")


def _write_pst_report(gcc_dir: Path, passed: bool) -> None:
    pst_dir = gcc_dir / ".GCC" / "pst_reports"
    pst_dir.mkdir(parents=True, exist_ok=True)
    (pst_dir / "2026-04-18T10-00-00_pst.json").write_text(
        json.dumps({"passed": passed, "score": 0.95 if passed else 0.3}),
        encoding="utf-8",
    )


# ===========================================================================
# 1. Basic response
# ===========================================================================


def test_ciso_returns_200_initialized(client: TestClient) -> None:
    """CISO endpoint returns 200 for an initialized repo."""
    resp = client.get("/api/v1/ciso")
    assert resp.status_code == 200


def test_ciso_returns_200_uninitialized(empty_client: TestClient) -> None:
    """CISO endpoint returns 200 (not 503) even for an uninitialized repo."""
    resp = empty_client.get("/api/v1/ciso")
    assert resp.status_code == 200


# ===========================================================================
# 2. Top-level keys
# ===========================================================================


def test_ciso_has_rdp_budget_key(client: TestClient) -> None:
    body = client.get("/api/v1/ciso").json()
    assert "rdp_budget" in body


def test_ciso_has_conformance_key(client: TestClient) -> None:
    body = client.get("/api/v1/ciso").json()
    assert "conformance" in body


def test_ciso_has_sensitivity_summary_key(client: TestClient) -> None:
    body = client.get("/api/v1/ciso").json()
    assert "sensitivity_summary" in body


def test_ciso_has_last_updated_key(client: TestClient) -> None:
    body = client.get("/api/v1/ciso").json()
    assert "last_updated" in body
    assert isinstance(body["last_updated"], str)
    assert len(body["last_updated"]) > 0


# ===========================================================================
# 3. rdp_budget field types
# ===========================================================================


def test_rdp_budget_epsilon_used_is_float(client: TestClient) -> None:
    rdp = client.get("/api/v1/ciso").json()["rdp_budget"]
    assert isinstance(rdp["epsilon_used"], float)


def test_rdp_budget_epsilon_max_is_float(client: TestClient) -> None:
    rdp = client.get("/api/v1/ciso").json()["rdp_budget"]
    assert isinstance(rdp["epsilon_max"], float)


def test_rdp_budget_read_only_is_bool(client: TestClient) -> None:
    rdp = client.get("/api/v1/ciso").json()["rdp_budget"]
    assert isinstance(rdp["read_only"], bool)


def test_rdp_budget_exhausted_is_bool(client: TestClient) -> None:
    rdp = client.get("/api/v1/ciso").json()["rdp_budget"]
    assert isinstance(rdp["exhausted"], bool)


# ===========================================================================
# 4. conformance keys and types
# ===========================================================================


def test_conformance_has_all_six_invariants(client: TestClient) -> None:
    conformance = client.get("/api/v1/ciso").json()["conformance"]
    assert CONFORMANCE_KEYS == set(conformance.keys())


def test_conformance_values_are_bools(client: TestClient) -> None:
    conformance = client.get("/api/v1/ciso").json()["conformance"]
    for key, val in conformance.items():
        assert isinstance(val, bool), f"{key} should be bool, got {type(val)}"


def test_conformance_uninitialized_all_false(empty_client: TestClient) -> None:
    """An uninitialized repo should yield all-false conformance (not an error)."""
    conformance = empty_client.get("/api/v1/ciso").json()["conformance"]
    # All should be False when nothing is set up
    for key in CONFORMANCE_KEYS:
        assert conformance[key] is False, f"{key} expected False for empty repo"


# ===========================================================================
# 5. sensitivity_summary structure
# ===========================================================================


def test_sensitivity_summary_total_is_int(client: TestClient) -> None:
    summary = client.get("/api/v1/ciso").json()["sensitivity_summary"]
    assert isinstance(summary["total"], int)


def test_sensitivity_summary_by_disclosure_has_five_keys(client: TestClient) -> None:
    by_level = client.get("/api/v1/ciso").json()["sensitivity_summary"]["by_disclosure_level"]
    assert set(by_level.keys()) == {"1", "2", "3", "4", "5"}


def test_sensitivity_summary_high_disclosure_count_nonneg(client: TestClient) -> None:
    summary = client.get("/api/v1/ciso").json()["sensitivity_summary"]
    assert summary["high_disclosure_count"] >= 0


# ===========================================================================
# 6. Counts and misc fields
# ===========================================================================


def test_sis_quarantine_count_is_int(client: TestClient) -> None:
    body = client.get("/api/v1/ciso").json()
    assert isinstance(body["sis_quarantine_count"], int)


def test_variance_alert_count_is_int(client: TestClient) -> None:
    body = client.get("/api/v1/ciso").json()
    assert isinstance(body["variance_alert_count"], int)


def test_last_pst_passed_is_bool_or_null(client: TestClient) -> None:
    val = client.get("/api/v1/ciso").json()["last_pst_passed"]
    assert val is None or isinstance(val, bool)


# ===========================================================================
# 7. Data-backed reads
# ===========================================================================


def test_rdp_budget_reflects_written_state(repo: GCCRepository) -> None:
    _write_rdp_state(repo.root, epsilon_used=0.75, epsilon_max=1.0, read_only=False)
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    rdp = c.get("/api/v1/ciso").json()["rdp_budget"]
    assert abs(rdp["epsilon_used"] - 0.75) < 1e-6
    assert abs(rdp["epsilon_max"] - 1.0) < 1e-6


def test_sis_quarantine_count_from_report(repo: GCCRepository) -> None:
    _write_sis_report(repo.root, quarantine_count=3)
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    assert c.get("/api/v1/ciso").json()["sis_quarantine_count"] == 3


def test_variance_alert_count_from_event_log(repo: GCCRepository) -> None:
    _write_variance_alert(repo.root)
    _write_variance_alert(repo.root)
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    count = c.get("/api/v1/ciso").json()["variance_alert_count"]
    assert count >= 2


def test_last_pst_passed_true(repo: GCCRepository) -> None:
    _write_pst_report(repo.root, passed=True)
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    assert c.get("/api/v1/ciso").json()["last_pst_passed"] is True


def test_last_pst_passed_false(repo: GCCRepository) -> None:
    _write_pst_report(repo.root, passed=False)
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    assert c.get("/api/v1/ciso").json()["last_pst_passed"] is False


def test_sensitivity_summary_total_counts_events(repo: GCCRepository) -> None:
    events = [
        {"event_id": str(uuid.uuid4()), "target_concept": "pii", "disclosure_level": 5,
         "created_at": "2026-04-18T10:00:00+00:00", "counterfactuals": "sig"},
        {"event_id": str(uuid.uuid4()), "target_concept": "auth", "disclosure_level": 1,
         "created_at": "2026-04-18T10:01:00+00:00", "counterfactuals": "sig"},
    ]
    _write_sensitivity_events(repo.root, events)
    app = create_app(gcc_repo=repo.root)
    c = TestClient(app)
    summary = c.get("/api/v1/ciso").json()["sensitivity_summary"]
    assert summary["total"] == 2
    assert summary["by_disclosure_level"]["5"] == 1
    assert summary["by_disclosure_level"]["1"] == 1
    assert summary["high_disclosure_count"] >= 1
