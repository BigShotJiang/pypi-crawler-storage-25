from __future__ import annotations

from pathlib import Path

from devtorch_core import GCCRepository, GCC_DIR_NAME, MAIN_MD_NAME


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_context_bundle_under_token_budget_for_payment_incident(tmp_path: Path) -> None:
    """
    Real-world style scenario: incident post-mortem for a payment outage.

    We simulate a series of commits that document:
    - Baseline payment behavior.
    - Discovery of a breaking ORM change.
    - Coordination steps between database and billing services.
    Then we ask DevTorch for a small K-token context bundle we could hand to
    an agent debugging the incident.
    """
    repo = GCCRepository.at(tmp_path)
    repo.init()

    print("\n[scenario] Recording payment outage investigation steps.")
    repo.commit("Baseline payment-service behavior documented.")
    repo.commit("Incident: ORM migration broke billing due to transaction log schema mismatch.")
    repo.commit("Mitigation: roll back migration and capture shared schema contract.")

    # Tight token budget that should not include every commit message verbatim.
    bundle = repo.context_bundle(k_tokens=50, policy={"sensitivity_policy": "default"}, explain=True)

    assert bundle["k_tokens"] == 50
    assert 0 < bundle["approx_tokens_used"] <= 50
    assert bundle["branch"] == "main"
    assert bundle["included_commits"], "Expected at least one commit in the bundle."

    # main.md header should always be pinned as a roadmap artifact.
    gcc_dir = tmp_path / GCC_DIR_NAME
    main_md = _read(gcc_dir / MAIN_MD_NAME)
    assert "DevTorch reasoning roadmap (main)" in main_md
    pinned_paths = [a["path"] for a in bundle["artifacts"]]
    assert MAIN_MD_NAME in pinned_paths


def test_context_cli_output_for_payment_agent(tmp_path: Path) -> None:
    """
    High-level CLI smoke test for `devtorch context` as an agent-facing tool.

    We simulate an engineer using the CLI to build a context bundle for an AI
    agent debugging a payment incident, and verify the output mentions the
    selected artifacts and token budget.
    """
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("Baseline payment-service behavior documented.")
    repo.commit("Incident: payment authorization timeouts observed in EU region.")

    from devtorch_cli.main import main as devtorch_main

    print("\n[scenario] Calling `devtorch context` for an agent debugging a payment incident.")
    # Run the CLI wired against our tmp repo via -C.
    exit_code = devtorch_main(
        [
            "-C",
            str(tmp_path),
            "context",
            "-k",
            "60",
            "--policy",
            "default",
            "--explain",
        ]
    )
    assert exit_code == 0

