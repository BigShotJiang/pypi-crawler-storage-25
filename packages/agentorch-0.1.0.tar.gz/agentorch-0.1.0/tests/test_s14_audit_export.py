"""
S14 Tests — Audit Export (JSON and plain-text).

All endpoints must:
  - Return 200 with data (never 500)
  - Set Content-Disposition header for downloads
  - Support `since` date filter on JSON export
  - Include required metadata fields
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any, Dict

import pytest

starlette_testclient = pytest.importorskip("starlette.testclient")
TestClient = starlette_testclient.TestClient

from devtorch_core.dashboard_api import create_app


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _init_gcc(root: Path) -> None:
    gcc = root / ".GCC"
    gcc.mkdir()
    (gcc / "VERSION").write_text("gcc-v0\n", encoding="utf-8")
    refs = gcc / "refs"
    refs.mkdir()
    branches = refs / "branches"
    branches.mkdir()
    (refs / "HEAD").write_text("main\n", encoding="utf-8")
    (branches / "main").write_text("", encoding="utf-8")
    (gcc / "commits").mkdir()
    (gcc / "sensitivities").mkdir()
    theta = {"version": 1, "updated_at": None, "coordination_vector": {}}
    (gcc / "theta.json").write_text(json.dumps(theta), encoding="utf-8")
    (gcc / "COMMIT_INDEX").write_text("", encoding="utf-8")


def _write_events(root: Path, events: list) -> None:
    log = root / ".GCC" / "events.log.jsonl"
    with log.open("a", encoding="utf-8") as fh:
        for ev in events:
            fh.write(json.dumps(ev) + "\n")


# ---------------------------------------------------------------------------
# GET /api/v1/audit/export.json
# ---------------------------------------------------------------------------

class TestAuditExportJson:
    def test_returns_200_with_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.json")
            assert resp.status_code == 200
            data = resp.json()
            assert "exported_at" in data
            assert "gcc_version" in data
            assert "event_count" in data
            assert "events" in data

    def test_events_array_populated(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "COMMIT", "ts": "2025-03-01T10:00:00Z", "branch": "main"},
                {"event_type": "VARIANCE_ALERT", "ts": "2025-03-02T10:00:00Z"},
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.json")
            assert resp.status_code == 200
            data = resp.json()
            assert data["event_count"] == 2
            assert len(data["events"]) == 2

    def test_content_disposition_header_set(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.json")
            assert resp.status_code == 200
            disposition = resp.headers.get("content-disposition", "")
            assert "attachment" in disposition
            assert "devtorch-audit" in disposition
            assert ".json" in disposition

    def test_gcc_version_in_response(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.json")
            assert resp.status_code == 200
            assert resp.json()["gcc_version"] == "gcc-v0"

    def test_since_filter_excludes_old_events(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "COMMIT", "ts": "2024-06-01T10:00:00Z"},
                {"event_type": "COMMIT", "ts": "2025-01-15T10:00:00Z"},
                {"event_type": "COMMIT", "ts": "2025-03-01T10:00:00Z"},
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.json?since=2025-01-01")
            assert resp.status_code == 200
            data = resp.json()
            # Only the two 2025 events should appear
            assert data["event_count"] == 2
            assert len(data["events"]) == 2

    def test_since_filter_with_no_matching_events(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "COMMIT", "ts": "2024-01-01T00:00:00Z"},
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.json?since=2030-01-01")
            assert resp.status_code == 200
            data = resp.json()
            assert data["event_count"] == 0
            assert data["events"] == []

    def test_empty_events_log(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.json")
            assert resp.status_code == 200
            data = resp.json()
            assert data["event_count"] == 0
            assert isinstance(data["events"], list)

    def test_uninitialized_repo_returns_200(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(gcc_repo=Path(tmp))
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.json")
            assert resp.status_code == 200
            data = resp.json()
            assert data["event_count"] == 0


# ---------------------------------------------------------------------------
# GET /api/v1/audit/export.txt
# ---------------------------------------------------------------------------

class TestAuditExportTxt:
    def test_returns_200_plain_text(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert resp.status_code == 200
            ct = resp.headers.get("content-type", "")
            assert "text" in ct

    def test_content_disposition_header_set(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert resp.status_code == 200
            disposition = resp.headers.get("content-disposition", "")
            assert "attachment" in disposition
            assert "devtorch-audit" in disposition
            assert ".txt" in disposition

    def test_contains_header_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert resp.status_code == 200
            text = resp.text
            assert "DEVTORCH AUDIT REPORT" in text

    def test_contains_repository_info_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert "REPOSITORY INFO" in resp.text

    def test_contains_event_summary_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert "EVENT SUMMARY" in resp.text

    def test_contains_sensitivity_events_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert "SENSITIVITY EVENTS" in resp.text

    def test_contains_commit_history_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert "COMMIT HISTORY" in resp.text

    def test_contains_invariant_status_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert "INVARIANT STATUS" in resp.text

    def test_contains_disclaimer(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert "DevTorch OSS" in resp.text
            assert "calibration" in resp.text.lower()

    def test_events_appear_in_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            _write_events(root, [
                {"event_type": "COMMIT", "ts": "2025-01-01T00:00:00Z"},
                {"event_type": "COMMIT", "ts": "2025-01-02T00:00:00Z"},
            ])
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert resp.status_code == 200
            # Should mention 2 events
            assert "2" in resp.text

    def test_since_filter_accepted(self):
        """Ensure the since param does not cause a 500 on the txt endpoint."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _init_gcc(root)
            app = create_app(gcc_repo=root)
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt?since=2025-01-01")
            assert resp.status_code == 200

    def test_uninitialized_repo_returns_200(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(gcc_repo=Path(tmp))
            client = TestClient(app)
            resp = client.get("/api/v1/audit/export.txt")
            assert resp.status_code == 200
