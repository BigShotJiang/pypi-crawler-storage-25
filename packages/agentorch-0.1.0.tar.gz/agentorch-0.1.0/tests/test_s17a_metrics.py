"""
Sprint 17a — Metrics Calibration Infrastructure tests.

Covers: CalibrationDefaults, CalibrationStore, compute_mcs, mcs_to_label,
        compute_dhs, dhs_to_label, estimate_context_switch_savings,
        estimate_rework_savings.
"""

from __future__ import annotations

import json
from dataclasses import fields
from pathlib import Path

import pytest

from devtorch_core.metrics import (
    CalibrationDefaults,
    CalibrationStore,
    load_calibration,
    CollisionEvent,
    compute_mcs,
    mcs_to_label,
    DHSComponents,
    compute_dhs,
    dhs_to_label,
    ROIEstimate,
    estimate_context_switch_savings,
    estimate_rework_savings,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_store(tmp_path: Path, overrides: dict | None = None) -> CalibrationStore:
    gcc_root = tmp_path / ".GCC"
    gcc_root.mkdir(parents=True, exist_ok=True)
    store = CalibrationStore(str(gcc_root))
    if overrides:
        for k, v in overrides.items():
            store.set(k, v)
    return store


def _collision(severity: float = 0.5, resolution_minutes: float = 0.0) -> CollisionEvent:
    return CollisionEvent(
        timestamp="2026-01-01T00:00:00Z",
        branch_a="agent/a",
        branch_b="agent/b",
        concept="auth",
        severity=severity,
        resolution_minutes=resolution_minutes,
    )


# ---------------------------------------------------------------------------
# TestCalibrationDefaults (5 tests)
# ---------------------------------------------------------------------------

class TestCalibrationDefaults:
    def test_context_switch_minutes_default(self) -> None:
        """context_switch_minutes defaults to 15.0 per Parnin & Rugaber (2011)."""
        d = CalibrationDefaults()
        assert d.context_switch_minutes == 15.0

    def test_developer_hourly_rate_default_is_zero(self) -> None:
        """developer_hourly_rate is 0.0 by design to force explicit calibration."""
        d = CalibrationDefaults()
        assert d.developer_hourly_rate == 0.0

    def test_mcs_weights_sum_to_one(self) -> None:
        """MCS component weights must sum to 1.0."""
        d = CalibrationDefaults()
        total = d.mcs_weight_frequency + d.mcs_weight_severity + d.mcs_weight_resolution_time
        assert abs(total - 1.0) < 1e-9

    def test_dhs_weights_sum_to_one(self) -> None:
        """DHS component weights must sum to 1.0."""
        d = CalibrationDefaults()
        total = (
            d.dhs_weight_commit_health
            + d.dhs_weight_sensitivity_health
            + d.dhs_weight_capability_health
            + d.dhs_weight_variance_health
        )
        assert abs(total - 1.0) < 1e-9

    def test_all_weights_are_floats(self) -> None:
        """Every weight field is a float."""
        d = CalibrationDefaults()
        weight_fields = [f.name for f in fields(d) if "weight" in f.name]
        assert weight_fields, "No weight fields found"
        for name in weight_fields:
            assert isinstance(getattr(d, name), float), f"{name} is not a float"


# ---------------------------------------------------------------------------
# TestCalibrationStore (8 tests)
# ---------------------------------------------------------------------------

class TestCalibrationStore:
    def test_get_returns_default_when_not_overridden(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        assert store.get("context_switch_minutes") == 15.0

    def test_set_persists_override(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        store.set("developer_hourly_rate", 75.0)
        # Reload from disk
        store2 = CalibrationStore(str(tmp_path / ".GCC"))
        assert store2.get("developer_hourly_rate") == 75.0

    def test_get_all_merges_defaults_and_overrides(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        store.set("developer_hourly_rate", 60.0)
        all_vals = store.get_all()
        assert all_vals["developer_hourly_rate"] == 60.0
        assert all_vals["context_switch_minutes"] == 15.0

    def test_reset_removes_override(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        store.set("developer_hourly_rate", 80.0)
        store.reset("developer_hourly_rate")
        # Should fall back to default (0.0)
        assert store.get("developer_hourly_rate") == 0.0

    def test_load_returns_empty_dict_on_missing_file(self, tmp_path: Path) -> None:
        gcc_root = tmp_path / ".GCC"
        gcc_root.mkdir(parents=True, exist_ok=True)
        store = CalibrationStore(str(gcc_root))
        # No file written — load should return {}
        result = store.load()
        assert result == {}

    def test_load_returns_empty_dict_on_corrupt_json(self, tmp_path: Path) -> None:
        gcc_root = tmp_path / ".GCC"
        gcc_root.mkdir(parents=True, exist_ok=True)
        cal_file = gcc_root / "calibration.json"
        cal_file.write_text("{{not valid json{{", encoding="utf-8")
        store = CalibrationStore(str(gcc_root))
        assert store.load() == {}

    def test_save_writes_valid_json(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        store.save({"developer_hourly_rate": 55.0})
        cal_file = tmp_path / ".GCC" / "calibration.json"
        data = json.loads(cal_file.read_text(encoding="utf-8"))
        assert data["developer_hourly_rate"] == 55.0

    def test_get_uses_override_over_default(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        store.set("context_switch_minutes", 20.0)
        # Override should take precedence over the 15.0 default
        assert store.get("context_switch_minutes") == 20.0


# ---------------------------------------------------------------------------
# TestComputeMCS (8 tests)
# ---------------------------------------------------------------------------

class TestComputeMCS:
    def test_empty_events_returns_zero(self) -> None:
        assert compute_mcs([]) == 0.0

    def test_single_event_severity_one_is_nonzero(self) -> None:
        events = [_collision(severity=1.0)]
        score = compute_mcs(events)
        assert score > 0.0

    def test_frequency_score_capped_at_one(self) -> None:
        """More than 10 events should not push score above 1.0."""
        events = [_collision(severity=1.0, resolution_minutes=60.0) for _ in range(20)]
        score = compute_mcs(events)
        assert score <= 1.0

    def test_result_in_range(self) -> None:
        events = [_collision(0.3, 15.0), _collision(0.7, 45.0)]
        score = compute_mcs(events)
        assert 0.0 <= score <= 1.0

    def test_custom_weights_via_calibration(self, tmp_path: Path) -> None:
        """Custom weights change the result compared to defaults."""
        events = [_collision(severity=0.8, resolution_minutes=30.0)]
        store_default = _make_store(tmp_path / "d1")
        score_default = compute_mcs(events, calibration=store_default)

        store_custom = _make_store(
            tmp_path / "d2",
            overrides={
                "mcs_weight_frequency": 0.1,
                "mcs_weight_severity": 0.8,
                "mcs_weight_resolution_time": 0.1,
            },
        )
        score_custom = compute_mcs(events, calibration=store_custom)
        # With more weight on severity, custom score should differ
        assert abs(score_default - score_custom) > 1e-9

    def test_mcs_to_label_low(self) -> None:
        assert mcs_to_label(0.1) == "LOW"

    def test_mcs_to_label_moderate(self) -> None:
        assert mcs_to_label(0.35) == "MODERATE"

    def test_mcs_to_label_critical(self) -> None:
        assert mcs_to_label(0.9) == "CRITICAL"


# ---------------------------------------------------------------------------
# TestComputeDHS (8 tests)
# ---------------------------------------------------------------------------

class TestComputeDHS:
    def test_all_ones_gives_score_one(self) -> None:
        comp = DHSComponents(
            commit_health=1.0,
            sensitivity_health=1.0,
            capability_health=1.0,
            variance_health=1.0,
        )
        assert compute_dhs(comp) == pytest.approx(1.0)

    def test_all_zeros_gives_score_zero(self) -> None:
        comp = DHSComponents(
            commit_health=0.0,
            sensitivity_health=0.0,
            capability_health=0.0,
            variance_health=0.0,
        )
        assert compute_dhs(comp) == pytest.approx(0.0)

    def test_result_in_range(self) -> None:
        comp = DHSComponents(
            commit_health=0.6,
            sensitivity_health=0.8,
            capability_health=0.5,
            variance_health=0.9,
        )
        score = compute_dhs(comp)
        assert 0.0 <= score <= 1.0

    def test_dhs_to_label_healthy(self) -> None:
        assert dhs_to_label(0.9) == "HEALTHY"

    def test_dhs_to_label_fair(self) -> None:
        assert dhs_to_label(0.7) == "FAIR"

    def test_dhs_to_label_degraded(self) -> None:
        assert dhs_to_label(0.5) == "DEGRADED"

    def test_dhs_to_label_critical(self) -> None:
        assert dhs_to_label(0.2) == "CRITICAL"

    def test_default_weights_sum_to_one(self) -> None:
        """Default DHS weights in CalibrationDefaults sum to 1.0."""
        d = CalibrationDefaults()
        total = (
            d.dhs_weight_commit_health
            + d.dhs_weight_sensitivity_health
            + d.dhs_weight_capability_health
            + d.dhs_weight_variance_health
        )
        assert abs(total - 1.0) < 1e-9


# ---------------------------------------------------------------------------
# TestROIEstimate (6 tests)
# ---------------------------------------------------------------------------

class TestROIEstimate:
    def test_context_switch_savings_returns_roi_estimate(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        result = estimate_context_switch_savings(5, store)
        assert isinstance(result, ROIEstimate)

    def test_cost_saved_none_when_rate_zero(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)  # developer_hourly_rate defaults to 0.0
        result = estimate_context_switch_savings(10, store)
        assert result.cost_saved_dollars is None

    def test_is_calibrated_false_when_rate_zero(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        result = estimate_context_switch_savings(3, store)
        assert result.is_calibrated is False

    def test_calibration_warnings_nonempty_when_uncalibrated(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        result = estimate_context_switch_savings(3, store)
        assert len(result.calibration_warnings) > 0

    def test_rework_savings_returns_roi_estimate(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        result = estimate_rework_savings(4, store)
        assert isinstance(result, ROIEstimate)

    def test_cost_saved_is_float_when_rate_set(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path, overrides={"developer_hourly_rate": 60.0})
        result = estimate_rework_savings(2, store)
        assert isinstance(result.cost_saved_dollars, float)
        # 2 collisions * 30 min each = 60 min = 1 hr * $60 = $60
        assert result.cost_saved_dollars == pytest.approx(60.0)


# ---------------------------------------------------------------------------
# S17a: New CalibrationStore (calibrate.py) tests
# ---------------------------------------------------------------------------

def _make_gcc_dir(tmp_path: Path) -> Path:
    gcc_dir = tmp_path / ".GCC"
    gcc_dir.mkdir(parents=True, exist_ok=True)
    return gcc_dir


class TestS17aCalibrationStore:
    def test_load_empty_when_file_missing(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        store = NewStore(gcc_dir)
        assert store.load() == {}

    def test_save_and_load_roundtrip(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        store = NewStore(gcc_dir)
        data = {"developer_hourly_rate": 120.0, "sprint_length_days": 14}
        store.save(data)
        loaded = store.load()
        assert loaded["developer_hourly_rate"] == 120.0
        assert loaded["sprint_length_days"] == 14

    def test_save_creates_metrics_dir(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        store = NewStore(gcc_dir)
        assert not (gcc_dir / "metrics").exists()
        store.save({"x": 1})
        assert (gcc_dir / "metrics").exists()
        assert (gcc_dir / "metrics" / "calibration.json").exists()

    def test_set_value(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        store = NewStore(gcc_dir)
        store.set_value("developer_hourly_rate", 95.0)
        assert store.get_value("developer_hourly_rate") == 95.0

    def test_get_value_with_default(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        store = NewStore(gcc_dir)
        assert store.get_value("nonexistent_key", "fallback") == "fallback"

    def test_get_value_existing(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        store = NewStore(gcc_dir)
        store.set_value("cold_start_min", 12.5)
        assert store.get_value("cold_start_min") == 12.5

    def test_load_returns_empty_on_corrupt_json(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        metrics_dir = gcc_dir / "metrics"
        metrics_dir.mkdir()
        (metrics_dir / "calibration.json").write_text("NOT_JSON", encoding="utf-8")
        store = NewStore(gcc_dir)
        assert store.load() == {}

    def test_calibration_path_attribute(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        store = NewStore(gcc_dir)
        assert store.calibration_path == gcc_dir / "metrics" / "calibration.json"


# ---------------------------------------------------------------------------
# S17a: run_calibrate_wizard tests
# ---------------------------------------------------------------------------

class TestS17aRunCalibrateWizard:
    def test_noninteractive_writes_calibration(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import run_calibrate_wizard, CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        values = {
            "developer_hourly_rate": 120.0,
            "cold_start_min": 10.0,
            "avg_rework_hours": 3.0,
            "token_cost_usd_per_1k": 0.005,
            "auditor_hourly_rate": 45.0,
            "sprint_length_days": 7,
        }
        result = run_calibrate_wizard(gcc_dir, values=values)
        assert result["developer_hourly_rate"] == 120.0
        assert result["sprint_length_days"] == 7

        store = NewStore(gcc_dir)
        on_disk = store.load()
        assert on_disk["developer_hourly_rate"] == 120.0

    def test_noninteractive_defaults_for_missing_optional_keys(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import run_calibrate_wizard
        gcc_dir = _make_gcc_dir(tmp_path)
        result = run_calibrate_wizard(gcc_dir, values={"developer_hourly_rate": 60.0})
        assert result["avg_rework_hours"] == 2.0
        assert result["token_cost_usd_per_1k"] == 0.003
        assert result["auditor_hourly_rate"] == 39.0
        assert result["sprint_length_days"] == 14


# ---------------------------------------------------------------------------
# S17a: session_writer tests
# ---------------------------------------------------------------------------

class TestS17aSessionWriter:
    def test_write_and_read_roundtrip(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.session_writer import write_session_metrics, read_session_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        data = {
            "tokens_used": 5000,
            "tokens_saved": 1500,
            "coverage": 0.85,
            "confidence_distribution": {"high": 10, "medium": 5},
            "cold_start_ms": 300.0,
        }
        path = write_session_metrics(gcc_dir, "session-001", data)
        assert path.exists()
        loaded = read_session_metrics(gcc_dir, "session-001")
        assert loaded is not None
        assert loaded["tokens_used"] == 5000
        assert loaded["coverage"] == 0.85

    def test_tokens_saved_auto_estimated(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.session_writer import write_session_metrics, read_session_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        write_session_metrics(gcc_dir, "session-002", {"tokens_used": 1000})
        loaded = read_session_metrics(gcc_dir, "session-002")
        assert loaded["tokens_saved"] == 300  # 1000 * 0.3

    def test_creates_session_dir(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.session_writer import write_session_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        assert not (gcc_dir / "metrics" / "session").exists()
        write_session_metrics(gcc_dir, "s1", {"tokens_used": 100})
        assert (gcc_dir / "metrics" / "session").exists()

    def test_read_returns_none_for_missing(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.session_writer import read_session_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        assert read_session_metrics(gcc_dir, "nonexistent") is None


# ---------------------------------------------------------------------------
# S17a: sprint_writer tests
# ---------------------------------------------------------------------------

class TestS17aSprintWriter:
    def test_write_and_read_roundtrip(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.sprint_writer import write_sprint_metrics, read_sprint_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        data = {
            "mcs_score": 0.25,
            "i3_violations": 2,
            "collisions_prevented": 5,
            "override_rate": 0.1,
            "acceptance_rate": 0.9,
            "branch_count": 3,
            "commit_count": 42,
        }
        path = write_sprint_metrics(gcc_dir, "sprint-1", data)
        assert path.exists()
        loaded = read_sprint_metrics(gcc_dir, "sprint-1")
        assert loaded is not None
        assert loaded["mcs_score"] == 0.25
        assert loaded["sprint_id"] == "sprint-1"

    def test_mcs_score_auto_computed_when_missing(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.sprint_writer import write_sprint_metrics, read_sprint_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        write_sprint_metrics(gcc_dir, "sprint-2", {"commit_count": 10})
        loaded = read_sprint_metrics(gcc_dir, "sprint-2")
        assert loaded["mcs_score"] == 0.0

    def test_creates_sprint_dir(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.sprint_writer import write_sprint_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        assert not (gcc_dir / "metrics" / "sprint").exists()
        write_sprint_metrics(gcc_dir, "s1", {})
        assert (gcc_dir / "metrics" / "sprint").exists()

    def test_read_returns_none_for_missing(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.sprint_writer import read_sprint_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        assert read_sprint_metrics(gcc_dir, "nonexistent") is None


# ---------------------------------------------------------------------------
# S17a: detect_shadow_ai tests
# ---------------------------------------------------------------------------

class TestS17aDetectShadowAI:
    def test_safe_defaults_no_git_repo(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.shadow_ai import detect_shadow_ai
        result = detect_shadow_ai(tmp_path)
        assert result["git_commits"] == 0
        assert result["gcc_commits"] == 0
        assert result["unregistered"] == 0
        assert result["shadow_ratio"] == 0.0
        assert result["flagged"] is False

    def test_returns_dict_with_all_keys(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.shadow_ai import detect_shadow_ai
        result = detect_shadow_ai(tmp_path)
        for key in ("git_commits", "gcc_commits", "unregistered", "shadow_ratio", "flagged"):
            assert key in result

    def test_flagged_logic_threshold(self) -> None:
        """Unit-test the flagging logic: flagged when unregistered > 3 and ratio > 0.3."""
        def _flagged(unregistered: int, git_commits: int) -> bool:
            shadow_ratio = unregistered / git_commits if git_commits > 0 else 0.0
            return unregistered > 3 and shadow_ratio > 0.3

        assert _flagged(5, 10) is True    # ratio 0.5, count 5 → flagged
        assert _flagged(3, 10) is False   # count <= 3 → not flagged
        assert _flagged(4, 40) is False   # ratio 0.1 → not flagged
        assert _flagged(4, 12) is True    # ratio ~0.33, count 4 → flagged

    def test_gcc_commit_count_with_events(self, tmp_path: Path) -> None:
        from datetime import datetime, timezone
        from devtorch_core.metrics.shadow_ai import _gcc_commit_count

        gcc_dir = tmp_path / ".GCC"
        gcc_dir.mkdir()
        now_str = datetime.now(tz=timezone.utc).isoformat()
        events = [
            {"event_type": "COMMIT", "timestamp": now_str, "payload": {}},
            {"event_type": "COMMIT", "timestamp": now_str, "payload": {}},
            {"event_type": "INIT", "timestamp": now_str, "payload": {}},
        ]
        with (gcc_dir / "events.log.jsonl").open("w") as f:
            for e in events:
                f.write(json.dumps(e) + "\n")

        count = _gcc_commit_count(gcc_dir)
        assert count == 2

    def test_safe_defaults_when_no_gcc_dir(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.shadow_ai import detect_shadow_ai
        # No .GCC directory at all
        result = detect_shadow_ai(tmp_path)
        assert result["flagged"] is False
        assert isinstance(result["shadow_ratio"], float)


# ---------------------------------------------------------------------------
# S17a: CLI tests
# ---------------------------------------------------------------------------

class TestS17aCLI:
    def _run(self, args: list) -> tuple:
        import io
        from unittest.mock import patch
        from devtorch_cli.main import main

        captured_out = io.StringIO()
        with patch("sys.stdout", captured_out):
            try:
                rc = main(args)
            except SystemExit as e:
                rc = int(e.code) if e.code is not None else 0
        return rc, captured_out.getvalue()

    def test_calibrate_set_developer_hourly_rate(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.calibrate import CalibrationStore as NewStore
        gcc_dir = _make_gcc_dir(tmp_path)
        rc, out = self._run(["-C", str(tmp_path), "calibrate", "--set", "developer_hourly_rate=120"])
        assert rc == 0
        assert "developer_hourly_rate" in out
        assert "120" in out
        store = NewStore(gcc_dir)
        assert store.get_value("developer_hourly_rate") == 120.0

    def test_metrics_runs_without_error(self, tmp_path: Path) -> None:
        _make_gcc_dir(tmp_path)
        rc, out = self._run(["-C", str(tmp_path), "metrics"])
        assert rc == 0
        assert "DevTorch Metrics Summary" in out
        assert "Developer" in out
        assert "Tech Lead" in out
        assert "CISO" in out
        assert "DevTorch design choices" in out

    def test_metrics_json_flag(self, tmp_path: Path) -> None:
        _make_gcc_dir(tmp_path)
        rc, out = self._run(["-C", str(tmp_path), "metrics", "--json"])
        assert rc == 0
        data = json.loads(out)
        assert "developer" in data
        assert "tech_lead" in data
        assert "ciso" in data
        assert "disclosure" in data

    def test_metrics_period_flag(self, tmp_path: Path) -> None:
        _make_gcc_dir(tmp_path)
        rc, out = self._run(["-C", str(tmp_path), "metrics", "--period", "7d", "--json"])
        assert rc == 0
        data = json.loads(out)
        assert data["period_days"] == 7

    def test_metrics_tier_labels_in_json(self, tmp_path: Path) -> None:
        _make_gcc_dir(tmp_path)
        rc, out = self._run(["-C", str(tmp_path), "metrics", "--json"])
        assert rc == 0
        data = json.loads(out)
        assert data["developer"]["tokens_used"]["tier"] == "MEASURED"
        assert data["developer"]["tokens_saved"]["tier"] == "CALIBRATED"
        assert data["ciso"]["dhs_score"]["tier"] == "CALIBRATED"

    def test_metrics_reads_session_data(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.session_writer import write_session_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        write_session_metrics(gcc_dir, "s1", {"tokens_used": 1234, "tokens_saved": 400})
        rc, out = self._run(["-C", str(tmp_path), "metrics", "--json"])
        assert rc == 0
        data = json.loads(out)
        assert data["developer"]["tokens_used"]["value"] == 1234
        assert data["developer"]["tokens_saved"]["value"] == 400

    def test_metrics_reads_sprint_data(self, tmp_path: Path) -> None:
        from devtorch_core.metrics.sprint_writer import write_sprint_metrics
        gcc_dir = _make_gcc_dir(tmp_path)
        write_sprint_metrics(gcc_dir, "sp1", {"mcs_score": 0.42, "i3_violations": 3})
        rc, out = self._run(["-C", str(tmp_path), "metrics", "--json"])
        assert rc == 0
        data = json.loads(out)
        assert data["tech_lead"]["mcs_trend"]["value"] == pytest.approx(0.42, abs=1e-4)
        assert data["tech_lead"]["i3_violations"]["value"] == 3
