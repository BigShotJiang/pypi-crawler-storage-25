"""Sprint 4 – Variance calibration (f_max, report), consensus lock/unlock."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from devtorch_core import (
    GCCRepository,
    GCC_DIR_NAME,
    f_max,
    VarianceReport,
    variance_calibrate,
    VarianceStore,
    run_variance_monitor,
    variance_deterministic_mode_forced,
    reputation_with_variance_penalty,
)


def test_f_max_formula() -> None:
    """f_max(n, σ²_obs) = floor(n * (1 - 2*σ²_obs) / 3)."""
    assert f_max(0, 0.1) == 0
    assert f_max(3, 0) == 1
    assert f_max(3, 0.1) == 0  # 3 * 0.8 / 3 = 0.8 -> 0
    assert f_max(4, 0) == 1
    assert f_max(6, 0.1) == 1  # 6 * 0.8 / 3 = 1.6 -> 1
    assert f_max(9, 0.1) == 2
    assert f_max(9, 0.5) == 0  # σ²_obs >= 0.5 -> 0


def test_variance_calibrate() -> None:
    """Calibration produces sigma_sq_obs and f_max from per-agent variances."""
    agent_variances = {"a1": 0.1, "a2": 0.2, "a3": 0.15}
    report = variance_calibrate(agent_variances)
    assert report.n == 3
    assert abs(report.sigma_sq_obs - 0.15) < 1e-6
    assert report.f_max == f_max(3, report.sigma_sq_obs)
    assert report.sigma_sq_per_agent == agent_variances


def test_variance_report_roundtrip() -> None:
    """VarianceReport to_dict/from_dict round-trip."""
    report = VarianceReport(
        sigma_sq_per_agent={"x": 0.1},
        sigma_sq_obs=0.1,
        n=1,
        f_max=0,
    )
    d = report.to_dict()
    back = VarianceReport.from_dict(d)
    assert back.sigma_sq_obs == report.sigma_sq_obs
    assert back.f_max == report.f_max
    assert back.sigma_sq_per_agent == report.sigma_sq_per_agent


def test_variance_store_save_load(tmp_path: Path) -> None:
    """VarianceStore persists and loads calibration report."""
    gcc_dir = tmp_path / GCC_DIR_NAME
    gcc_dir.mkdir()
    store = VarianceStore(gcc_dir)
    report = VarianceReport(
        sigma_sq_per_agent={"a": 0.1},
        sigma_sq_obs=0.1,
        n=1,
        f_max=0,
    )
    store.save_report(report)
    loaded = store.load_report()
    assert loaded is not None
    assert loaded.sigma_sq_obs == report.sigma_sq_obs
    assert loaded.f_max == report.f_max


def test_reputation_with_variance_penalty() -> None:
    """High variance reduces reputation; above sigma_sq_max -> 0."""
    r = reputation_with_variance_penalty(1.0, 0.0, sigma_sq_max=0.3)
    assert r > 0
    r_low = reputation_with_variance_penalty(1.0, 0.3, sigma_sq_max=0.3)
    assert r_low == 0.0
    r_mid = reputation_with_variance_penalty(0.8, 0.15, sigma_sq_max=0.3, alpha=0.5)
    assert 0 < r_mid < 0.8


def test_lock_unlock_events_and_state(tmp_path: Path) -> None:
    """lock() / unlock() update state file and append LOCK/UNLOCK events."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("base")

    assert not repo.is_locked()
    repo.lock(reason="release freeze")
    assert repo.is_locked()
    lock_path = repo._lock_path()
    data = json.loads(lock_path.read_text(encoding="utf-8"))
    assert data.get("locked") is True
    assert "release freeze" in data.get("reason", "")

    event_log = tmp_path / GCC_DIR_NAME / "events.log.jsonl"
    events = [json.loads(l) for l in event_log.read_text().strip().split("\n") if l.strip()]
    assert any(e.get("event_type") == "LOCK" for e in events)

    repo.unlock()
    assert not repo.is_locked()
    data2 = json.loads(lock_path.read_text(encoding="utf-8"))
    assert data2.get("locked") is False
    events2 = [json.loads(l) for l in event_log.read_text().strip().split("\n") if l.strip()]
    assert any(e.get("event_type") == "UNLOCK" for e in events2)


def test_lock_raises_when_already_locked(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.lock(reason="one")
    with pytest.raises(RuntimeError) as exc_info:
        repo.lock(reason="two")
    assert "already locked" in str(exc_info.value).lower()


def test_unlock_checks_i1(tmp_path: Path) -> None:
    """unlock() runs I1; if branch tip not commit-backed, unlock raises."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("one")
    repo.lock(reason="test")
    # Corrupt tip so it's not in event log (e.g. manually set ref to fake id)
    (tmp_path / GCC_DIR_NAME / "refs" / "branches" / "main").write_text("fake_commit_id", encoding="utf-8")
    with pytest.raises(RuntimeError) as exc_info:
        repo.unlock()
    assert "invariant" in str(exc_info.value).lower() or "I1" in str(exc_info.value)


def test_variance_calibrate_persists_report(tmp_path: Path) -> None:
    """repo.variance_calibrate() persists report under .GCC/variance/."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    report = repo.variance_calibrate({"alice": 0.1, "bob": 0.2})
    assert report.n == 2
    variance_dir = tmp_path / GCC_DIR_NAME / "variance"
    assert (variance_dir / "calibration_report.json").exists()
    loaded = repo.get_variance_report()
    assert loaded is not None
    assert loaded.sigma_sq_obs == report.sigma_sq_obs
    assert loaded.f_max == report.f_max


def test_run_variance_monitor_f_max_zero(tmp_path: Path) -> None:
    """When f_max_live=0, monitor sets deterministic_mode_forced and alert_emitted."""
    gcc_dir = tmp_path / GCC_DIR_NAME
    gcc_dir.mkdir(parents=True)
    # High variances -> f_max=0 (e.g. 3 agents, sigma_sq_obs >= 0.5)
    result = run_variance_monitor(gcc_dir, {"a1": 0.5, "a2": 0.5, "a3": 0.5})
    assert result.f_max_live == 0
    assert result.deterministic_mode_forced is True
    assert result.alert_emitted is True
    assert variance_deterministic_mode_forced(gcc_dir) is True


def test_run_variance_monitor_emits_alert_when_f_max_drops(tmp_path: Path) -> None:
    """Monitor emits alert when f_max drops from previous value."""
    gcc_dir = tmp_path / GCC_DIR_NAME
    gcc_dir.mkdir(parents=True)
    # First run: 4 agents, low variance -> f_max(4, 0.05)=1
    r1 = run_variance_monitor(gcc_dir, {"a1": 0.05, "a2": 0.05, "a3": 0.05, "a4": 0.05})
    assert r1.f_max_live == 1
    assert r1.alert_emitted is False  # no previous
    assert r1.deterministic_mode_forced is False
    # Second run: higher variance -> f_max(4, 0.4)=0
    r2 = run_variance_monitor(gcc_dir, {"a1": 0.4, "a2": 0.4, "a3": 0.4, "a4": 0.4})
    assert r2.f_max_live == 0
    assert r2.previous_f_max == 1
    assert r2.alert_emitted is True
    assert r2.deterministic_mode_forced is True


def test_repo_variance_monitor_run_emits_variance_alert(tmp_path: Path) -> None:
    """repo.variance_monitor_run() emits VARIANCE_ALERT event when f_max drops or is 0."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    # Run monitor with no prior report -> f_max=0, alert emitted
    result = repo.variance_monitor_run()
    assert result["f_max_live"] == 0
    assert result["alert_emitted"] is True
    event_log = tmp_path / GCC_DIR_NAME / "events.log.jsonl"
    events = [json.loads(l) for l in event_log.read_text().strip().split("\n") if l.strip()]
    assert any(e.get("event_type") == "VARIANCE_ALERT" for e in events)


def test_variance_deterministic_mode_forced_after_monitor(tmp_path: Path) -> None:
    """variance_deterministic_mode_forced() True after monitor run with f_max=0."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    assert repo.variance_deterministic_mode_forced() is False
    repo.variance_monitor_run({"a1": 0.5, "a2": 0.5})  # n=2, high var -> f_max=0
    assert repo.variance_deterministic_mode_forced() is True


def test_validate_capability_respects_variance_deterministic_mode(tmp_path: Path) -> None:
    """When variance forces deterministic mode, validate_capability returns textual_mode_allowed=False."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    # No capability set; run monitor so f_max=0 and deterministic_mode_forced=True
    repo.variance_monitor_run({"x": 0.6})
    result = repo.validate_capability()
    assert result["textual_mode_allowed"] is False
    assert any("A2" in r or "f_max" in r for r in result.get("reasons", []))
