"""
S7 Tests — MCP server and Claude Code hooks.

Tests:
  test_extract_sensitivity_long_message   — > 50 words → conf=0.75
  test_extract_sensitivity_short_message  — 3 words    → conf=0.40
  test_extract_sensitivity_empty          — returns None
  test_post_tool_use_write_tool_commits   — Write tool  → repo.commit called
  test_post_tool_use_read_tool_no_commit  — Read tool   → repo.commit NOT called
  test_hook_always_approves_on_exception  — even if repo raises, hook approves
  test_mcp_tools_list                     — 4 tools are listed via raw JSON-RPC
  test_mcp_devtorch_context_tool          — devtorch_context returns formatted string
"""

from __future__ import annotations

import json
import sys
import io
from pathlib import Path
from unittest import mock
from unittest.mock import MagicMock, patch, call
import unittest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _Capturing:
    """Context manager that captures stdout."""

    def __init__(self):
        self._old_stdout = None
        self.value = ""

    def __enter__(self):
        self._buf = io.StringIO()
        self._old_stdout = sys.stdout
        sys.stdout = self._buf
        return self

    def __exit__(self, *args):
        sys.stdout = self._old_stdout
        self.value = self._buf.getvalue()


def _fake_stdin(data: dict):
    """Return a StringIO that yields the JSON-encoded data."""
    return io.StringIO(json.dumps(data))


# ---------------------------------------------------------------------------
# extract_sensitivity_from_commit tests
# ---------------------------------------------------------------------------

from devtorch_core.hooks.git_commit import extract_sensitivity_from_commit


class TestExtractSensitivity(unittest.TestCase):

    def test_extract_sensitivity_long_message(self):
        """More than 50 words → confidence 0.75."""
        words = " ".join(["word"] * 51)  # 51 words
        result = extract_sensitivity_from_commit(words)
        self.assertIsNotNone(result)
        self.assertEqual(result["confidence"], 0.75)
        self.assertIn("signal", result)
        self.assertIn("concept", result)

    def test_extract_sensitivity_medium_message(self):
        """21 words → confidence 0.70."""
        words = " ".join(["word"] * 21)
        result = extract_sensitivity_from_commit(words)
        self.assertIsNotNone(result)
        self.assertEqual(result["confidence"], 0.70)

    def test_extract_sensitivity_brief_message(self):
        """10 words → confidence 0.50."""
        words = " ".join(["word"] * 10)
        result = extract_sensitivity_from_commit(words)
        self.assertIsNotNone(result)
        self.assertEqual(result["confidence"], 0.50)

    def test_extract_sensitivity_short_message(self):
        """3 words → confidence 0.40."""
        result = extract_sensitivity_from_commit("fix the bug")
        self.assertIsNotNone(result)
        self.assertEqual(result["confidence"], 0.40)

    def test_extract_sensitivity_empty(self):
        """Empty message → None."""
        self.assertIsNone(extract_sensitivity_from_commit(""))
        self.assertIsNone(extract_sensitivity_from_commit("   "))

    def test_extract_sensitivity_concept_auth(self):
        """Auth keyword → concept 'auth'."""
        result = extract_sensitivity_from_commit("Update auth token validation logic")
        self.assertIsNotNone(result)
        self.assertEqual(result["concept"], "auth")

    def test_extract_sensitivity_concept_security(self):
        """Security keyword → concept 'security'."""
        result = extract_sensitivity_from_commit("Fix security vulnerability in input sanitize")
        self.assertIsNotNone(result)
        self.assertEqual(result["concept"], "security")

    def test_extract_sensitivity_unknown_concept(self):
        """No known keyword → concept 'general'."""
        result = extract_sensitivity_from_commit("random words here")
        self.assertIsNotNone(result)
        self.assertEqual(result["concept"], "general")


# ---------------------------------------------------------------------------
# PostToolUse hook tests
# ---------------------------------------------------------------------------

class TestPostToolUseHook(unittest.TestCase):

    def _run_post_tool_use(self, event: dict, mock_repo):
        """Helper: patch stdin, stdout, repo lookup, run handle_post_tool_use, return stdout."""
        from devtorch_core.hooks import claude_code as cc_mod

        with patch.object(sys, "stdin", _fake_stdin(event)):
            with patch.object(cc_mod, "_find_gcc_repo", return_value=mock_repo):
                with patch.object(cc_mod, "_gcc_root", return_value=None):
                    with _Capturing() as cap:
                        cc_mod.handle_post_tool_use()
        return cap.value

    def test_post_tool_use_write_tool_commits(self):
        """Write tool event → repo.commit is called once."""
        mock_repo = MagicMock()
        event = {
            "hook_event_name": "PostToolUse",
            "tool_name": "Write",
            "tool_input": {"file_path": "/path/to/file.py"},
            "session_id": "sess-abc",
        }
        output = self._run_post_tool_use(event, mock_repo)
        mock_repo.commit.assert_called_once()
        call_args = mock_repo.commit.call_args
        assert "Write" in call_args.kwargs.get("message", "")
        resp = json.loads(output)
        self.assertEqual(resp["decision"], "approve")

    def test_post_tool_use_edit_tool_commits(self):
        """Edit tool event → repo.commit is called."""
        mock_repo = MagicMock()
        event = {
            "hook_event_name": "PostToolUse",
            "tool_name": "Edit",
            "tool_input": {"file_path": "/some/file.js"},
            "session_id": "sess-xyz",
        }
        self._run_post_tool_use(event, mock_repo)
        mock_repo.commit.assert_called_once()

    def test_post_tool_use_bash_tool_commits(self):
        """Bash tool event → repo.commit is called with command summary."""
        mock_repo = MagicMock()
        event = {
            "hook_event_name": "PostToolUse",
            "tool_name": "Bash",
            "tool_input": {"command": "pytest tests/ -v"},
            "session_id": "sess-bash",
        }
        output = self._run_post_tool_use(event, mock_repo)
        mock_repo.commit.assert_called_once()
        msg = mock_repo.commit.call_args.kwargs["message"]
        self.assertIn("pytest", msg)
        resp = json.loads(output)
        self.assertEqual(resp["decision"], "approve")

    def test_post_tool_use_read_tool_no_commit(self):
        """Read tool event → repo.commit is NOT called."""
        mock_repo = MagicMock()
        event = {
            "hook_event_name": "PostToolUse",
            "tool_name": "Read",
            "tool_input": {"file_path": "/some/file.py"},
            "session_id": "sess-read",
        }
        output = self._run_post_tool_use(event, mock_repo)
        mock_repo.commit.assert_not_called()
        resp = json.loads(output)
        self.assertEqual(resp["decision"], "approve")

    def test_post_tool_use_glob_tool_no_commit(self):
        """Glob tool event → repo.commit is NOT called."""
        mock_repo = MagicMock()
        event = {
            "hook_event_name": "PostToolUse",
            "tool_name": "Glob",
            "tool_input": {"pattern": "**/*.py"},
            "session_id": "sess-glob",
        }
        output = self._run_post_tool_use(event, mock_repo)
        mock_repo.commit.assert_not_called()
        resp = json.loads(output)
        self.assertEqual(resp["decision"], "approve")

    def test_post_tool_use_grep_tool_no_commit(self):
        """Grep tool event → repo.commit is NOT called."""
        mock_repo = MagicMock()
        event = {
            "hook_event_name": "PostToolUse",
            "tool_name": "Grep",
            "tool_input": {"pattern": "def main"},
            "session_id": "sess-grep",
        }
        output = self._run_post_tool_use(event, mock_repo)
        mock_repo.commit.assert_not_called()
        resp = json.loads(output)
        self.assertEqual(resp["decision"], "approve")

    def test_hook_always_approves_on_exception(self):
        """Even if repo.commit raises, the hook writes {"decision": "approve"}."""
        mock_repo = MagicMock()
        mock_repo.commit.side_effect = RuntimeError("GCC exploded")
        event = {
            "hook_event_name": "PostToolUse",
            "tool_name": "Write",
            "tool_input": {"file_path": "/crash.py"},
            "session_id": "sess-boom",
        }
        output = self._run_post_tool_use(event, mock_repo)
        resp = json.loads(output)
        self.assertEqual(resp["decision"], "approve")

    def test_hook_always_approves_on_find_repo_exception(self):
        """If finding the repo raises, hook still approves."""
        from devtorch_core.hooks import claude_code as cc_mod

        def _boom():
            raise OSError("disk failure")

        event = {
            "hook_event_name": "PostToolUse",
            "tool_name": "Write",
            "tool_input": {"file_path": "/boom.py"},
            "session_id": "sess-diskfail",
        }
        with patch.object(sys, "stdin", _fake_stdin(event)):
            with patch.object(cc_mod, "_find_gcc_repo", side_effect=_boom):
                with patch.object(cc_mod, "_gcc_root", return_value=None):
                    with _Capturing() as cap:
                        cc_mod.handle_post_tool_use()
        resp = json.loads(cap.value)
        self.assertEqual(resp["decision"], "approve")


# ---------------------------------------------------------------------------
# MCP server JSON-RPC tests (using raw fallback)
# ---------------------------------------------------------------------------

class TestMCPServer(unittest.TestCase):

    def _call_jsonrpc(self, repo_mock, *requests) -> list[dict]:
        """
        Feed JSON-RPC requests into _run_raw_stdio (one line per request),
        capture stdout responses, return parsed list.
        """
        from devtorch_core.mcp.server import _run_raw_stdio

        lines = "\n".join(json.dumps(r) for r in requests) + "\n"
        responses = []

        with patch.object(sys, "stdin", io.StringIO(lines)):
            with _Capturing() as cap:
                _run_raw_stdio(repo_mock)

        for line in cap.value.splitlines():
            line = line.strip()
            if line:
                responses.append(json.loads(line))
        return responses

    def test_mcp_tools_list(self):
        """tools/list must return exactly 4 tools."""
        mock_repo = MagicMock()
        req = {"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}}
        responses = self._call_jsonrpc(mock_repo, req)

        self.assertEqual(len(responses), 1)
        resp = responses[0]
        self.assertIn("result", resp)
        tools = resp["result"]["tools"]
        self.assertEqual(len(tools), 4)
        names = {t["name"] for t in tools}
        self.assertIn("devtorch_commit", names)
        self.assertIn("devtorch_sensitivity_add", names)
        self.assertIn("devtorch_context", names)
        self.assertIn("devtorch_theta_read", names)

    def test_mcp_devtorch_context_tool(self):
        """devtorch_context tool should return a formatted string response."""
        mock_repo = MagicMock()
        mock_repo.context_bundle.return_value = {
            "k_tokens": 8000,
            "approx_tokens_used": 150,
            "branch": "main",
            "artifacts": [
                {"name": "main.md", "reason": "pinned header", "tokens": 50},
                {"name": "commits/001.json", "reason": "recent commit", "tokens": 100},
            ],
        }

        req = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {"name": "devtorch_context", "arguments": {"k": 8000}},
        }
        responses = self._call_jsonrpc(mock_repo, req)

        self.assertEqual(len(responses), 1)
        resp = responses[0]
        self.assertIn("result", resp)
        content = resp["result"]["content"]
        self.assertTrue(len(content) > 0)
        text = content[0]["text"]
        self.assertIn("main.md", text)
        self.assertIn("8000", text)

    def test_mcp_devtorch_commit_tool(self):
        """devtorch_commit calls repo.commit and returns confirmation."""
        mock_repo = MagicMock()
        req = {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "devtorch_commit",
                "arguments": {"message": "reasoning milestone reached"},
            },
        }
        responses = self._call_jsonrpc(mock_repo, req)
        mock_repo.commit.assert_called_once_with(message="reasoning milestone reached")
        text = responses[0]["result"]["content"][0]["text"]
        self.assertIn(".GCC/", text)

    def test_mcp_devtorch_theta_read_tool(self):
        """devtorch_theta_read returns JSON of theta entries."""
        mock_repo = MagicMock()
        mock_repo.get_theta.return_value = {
            "coordination_vector": {
                "auth": {"mean_confidence": 0.8},
                "api": {"mean_confidence": 0.65},
            }
        }
        req = {
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {"name": "devtorch_theta_read", "arguments": {}},
        }
        responses = self._call_jsonrpc(mock_repo, req)
        text = responses[0]["result"]["content"][0]["text"]
        parsed = json.loads(text)
        self.assertIn("auth", parsed)
        self.assertIn("api", parsed)

    def test_mcp_devtorch_theta_read_filtered(self):
        """devtorch_theta_read with concepts filter returns only requested entries."""
        mock_repo = MagicMock()
        mock_repo.get_theta.return_value = {
            "coordination_vector": {
                "auth": {"mean_confidence": 0.8},
                "api": {"mean_confidence": 0.65},
                "schema": {"mean_confidence": 0.5},
            }
        }
        req = {
            "jsonrpc": "2.0",
            "id": 5,
            "method": "tools/call",
            "params": {
                "name": "devtorch_theta_read",
                "arguments": {"concepts": ["auth", "schema"]},
            },
        }
        responses = self._call_jsonrpc(mock_repo, req)
        text = responses[0]["result"]["content"][0]["text"]
        parsed = json.loads(text)
        self.assertIn("auth", parsed)
        self.assertIn("schema", parsed)
        self.assertNotIn("api", parsed)

    def test_mcp_sensitivity_add_tool(self):
        """devtorch_sensitivity_add creates a SensitivityEvent and calls repo.add_sensitivity."""
        mock_repo = MagicMock()
        mock_repo.add_sensitivity.return_value = "ev-001"
        req = {
            "jsonrpc": "2.0",
            "id": 6,
            "method": "tools/call",
            "params": {
                "name": "devtorch_sensitivity_add",
                "arguments": {
                    "concept": "auth",
                    "signal": "Token expiry depends on session lifetime",
                    "confidence": 0.8,
                    "disclosure": "PROTECTED",
                },
            },
        }
        responses = self._call_jsonrpc(mock_repo, req)
        mock_repo.add_sensitivity.assert_called_once()
        text = responses[0]["result"]["content"][0]["text"]
        self.assertIn("auth", text)
        self.assertIn("0.8", text)

    def test_mcp_initialize(self):
        """initialize handshake returns server info."""
        mock_repo = MagicMock()
        req = {
            "jsonrpc": "2.0",
            "id": 0,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "clientInfo": {"name": "claude-code", "version": "1.0"},
            },
        }
        responses = self._call_jsonrpc(mock_repo, req)
        self.assertEqual(len(responses), 1)
        result = responses[0]["result"]
        self.assertIn("serverInfo", result)
        self.assertEqual(result["serverInfo"]["name"], "devtorch")

    def test_mcp_unknown_method(self):
        """Unknown method returns error -32601."""
        mock_repo = MagicMock()
        req = {"jsonrpc": "2.0", "id": 99, "method": "unknownMethod", "params": {}}
        responses = self._call_jsonrpc(mock_repo, req)
        self.assertEqual(len(responses), 1)
        self.assertIn("error", responses[0])
        self.assertEqual(responses[0]["error"]["code"], -32601)

    def test_mcp_unknown_tool_returns_error_content(self):
        """Unknown tool name in tools/call returns isError=True."""
        mock_repo = MagicMock()
        req = {
            "jsonrpc": "2.0",
            "id": 7,
            "method": "tools/call",
            "params": {"name": "nonexistent_tool", "arguments": {}},
        }
        responses = self._call_jsonrpc(mock_repo, req)
        result = responses[0]["result"]
        self.assertTrue(result["isError"])

    def test_mcp_handles_malformed_json(self):
        """Malformed JSON line triggers parse error response."""
        from devtorch_core.mcp.server import _run_raw_stdio

        mock_repo = MagicMock()
        bad_input = "this is not json\n"
        with patch.object(sys, "stdin", io.StringIO(bad_input)):
            with _Capturing() as cap:
                _run_raw_stdio(mock_repo)

        lines = [l.strip() for l in cap.value.splitlines() if l.strip()]
        self.assertTrue(len(lines) >= 1)
        resp = json.loads(lines[0])
        self.assertIn("error", resp)
        self.assertEqual(resp["error"]["code"], -32700)

    def test_mcp_notification_no_response(self):
        """Notification (no id) should not produce a response line."""
        from devtorch_core.mcp.server import _run_raw_stdio

        mock_repo = MagicMock()
        notif = {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}
        lines_input = json.dumps(notif) + "\n"
        with patch.object(sys, "stdin", io.StringIO(lines_input)):
            with _Capturing() as cap:
                _run_raw_stdio(mock_repo)

        lines = [l.strip() for l in cap.value.splitlines() if l.strip()]
        self.assertEqual(len(lines), 0)


# ---------------------------------------------------------------------------
# PreToolUse hook tests
# ---------------------------------------------------------------------------

class TestPreToolUseHook(unittest.TestCase):

    def test_pre_tool_use_always_approves(self):
        """PreToolUse hook always approves."""
        from devtorch_core.hooks import claude_code as cc_mod

        event = {
            "hook_event_name": "PreToolUse",
            "tool_name": "Write",
            "tool_input": {"file_path": "/some/file.py"},
            "session_id": "sess-pre",
        }
        with patch.object(sys, "stdin", _fake_stdin(event)):
            with patch.object(cc_mod, "_gcc_root", return_value=None):
                with _Capturing() as cap:
                    cc_mod.handle_pre_tool_use()

        resp = json.loads(cap.value)
        self.assertEqual(resp["decision"], "approve")

    def test_pre_tool_use_approves_on_exception(self):
        """PreToolUse hook approves even if internal ops raise."""
        from devtorch_core.hooks import claude_code as cc_mod

        event = {"hook_event_name": "PreToolUse", "tool_name": "Bash", "session_id": "boom"}
        with patch.object(sys, "stdin", _fake_stdin(event)):
            with patch.object(cc_mod, "_gcc_root", side_effect=RuntimeError("fail")):
                with _Capturing() as cap:
                    cc_mod.handle_pre_tool_use()

        resp = json.loads(cap.value)
        self.assertEqual(resp["decision"], "approve")


# ---------------------------------------------------------------------------
# Stop (session end) hook tests
# ---------------------------------------------------------------------------

class TestSessionEndHook(unittest.TestCase):

    def test_session_end_always_approves(self):
        """Stop hook always approves."""
        from devtorch_core.hooks import claude_code as cc_mod

        event = {"hook_event_name": "Stop", "session_id": "sess-stop"}
        with patch.object(sys, "stdin", _fake_stdin(event)):
            with patch.object(cc_mod, "_gcc_root", return_value=None):
                with _Capturing() as cap:
                    cc_mod.handle_session_end()

        resp = json.loads(cap.value)
        self.assertEqual(resp["decision"], "approve")


# ---------------------------------------------------------------------------
# git_commit hook tests
# ---------------------------------------------------------------------------

class TestGitCommitHook(unittest.TestCase):

    def test_handle_commit_msg_no_gcc(self, tmp_path=None):
        """handle_commit_msg is silent when no .GCC/ repo found."""
        import tempfile
        from devtorch_core.hooks.git_commit import handle_commit_msg

        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("fix auth token bug")
            fname = f.name

        with patch(
            "devtorch_core.hooks.git_commit._find_gcc_repo", return_value=None
        ):
            # Should not raise
            handle_commit_msg(fname)

        Path(fname).unlink(missing_ok=True)

    def test_handle_commit_msg_calls_sensitivity_and_commit(self):
        """handle_commit_msg records sensitivity and mirrors commit."""
        import tempfile
        from devtorch_core.hooks.git_commit import handle_commit_msg

        mock_repo = MagicMock()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("refactor auth middleware to support OAuth2 flows")
            fname = f.name

        with patch(
            "devtorch_core.hooks.git_commit._find_gcc_repo", return_value=mock_repo
        ):
            handle_commit_msg(fname)

        mock_repo.add_sensitivity.assert_called_once()
        mock_repo.commit.assert_called_once()

        Path(fname).unlink(missing_ok=True)

    def test_install_hook_creates_file(self):
        """install_hook writes an executable shell script."""
        import tempfile
        import stat
        from devtorch_core.hooks.git_commit import install_hook

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            (tmp / ".git" / "hooks").mkdir(parents=True)
            install_hook(tmp)
            hook_file = tmp / ".git" / "hooks" / "commit-msg"
            self.assertTrue(hook_file.exists())
            content = hook_file.read_text()
            self.assertIn("devtorch hooks git-commit", content)
            mode = hook_file.stat().st_mode
            self.assertTrue(mode & stat.S_IXUSR)

    def test_install_hook_no_git_dir_raises(self):
        """install_hook raises FileNotFoundError if no .git/hooks/ exists."""
        import tempfile
        from devtorch_core.hooks.git_commit import install_hook

        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(FileNotFoundError):
                install_hook(Path(tmpdir))


if __name__ == "__main__":
    unittest.main()
