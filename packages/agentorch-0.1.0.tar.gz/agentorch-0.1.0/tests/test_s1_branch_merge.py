from __future__ import annotations

from pathlib import Path

from devtorch_core import GCCRepository, GCC_DIR_NAME


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_commit_ids_are_deterministic_and_monotonic(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()

    repo.commit("c1")
    repo.commit("c2")

    gcc_dir = tmp_path / GCC_DIR_NAME
    commits_dir = gcc_dir / "commits"

    # Expect two commits with deterministic, hex-encoded IDs starting from 1
    files = sorted(p.name for p in commits_dir.glob("*.json"))
    assert files == ["00000001.json", "00000002.json"]

    # Re-open repo and commit once more: ID should continue monotonically
    repo2 = GCCRepository.at(tmp_path)
    repo2.commit("c3")
    files = sorted(p.name for p in commits_dir.glob("*.json"))
    assert files == ["00000001.json", "00000002.json", "00000003.json"]


def test_branch_and_history(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("base")

    # Create feature branch from current tip
    repo.create_branch("feature")
    repo.commit("on-main-after-branch")

    # Switch to feature by directly writing HEAD then committing on that branch
    head = tmp_path / GCC_DIR_NAME / "refs" / "HEAD"
    head.write_text("feature\n", encoding="utf-8")
    repo.commit("feature-work")

    main_history = repo.history("main")
    feature_history = repo.history("feature")

    assert [c["message"] for c in main_history][:2] == ["on-main-after-branch", "base"]
    assert [c["message"] for c in feature_history][:2] == ["feature-work", "base"]


def test_fast_forward_merge_preserves_capabilities(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("base")
    repo.create_branch("feature")

    # Commit on feature
    head = tmp_path / GCC_DIR_NAME / "refs" / "HEAD"
    head.write_text("feature\n", encoding="utf-8")
    repo.commit("feature-change")

    # Ensure omega stub exists before merge
    omega = tmp_path / GCC_DIR_NAME / "capabilities" / "omega.json"
    before = _read_text(omega)

    # Fast-forward merge feature -> main; this is a safe structural update,
    # and should not touch capability declarations like Ωᵢ.
    repo.merge_fast_forward("feature", "main")

    after = _read_text(omega)
    assert before == after, "Capabilities artifact should be preserved across merge."


def test_realistic_feature_branch_workflow_for_payment_refactor(tmp_path: Path) -> None:
    """
    Real-world style example in line with the DevTorch product narrative.

    - `main` represents the current baseline payment-service behavior.
    - `orm-migration` is a feature branch where an engineer uses DevTorch to
      coordinate an ORM migration while respecting the billing service's
      dependency on a legacy transaction log format.
    - A fast-forward merge incorporates the migration work into `main` while
      preserving a fully reconstructible history of reasoning steps.
    """
    repo = GCCRepository.at(tmp_path)
    repo.init()

    # Baseline: document existing payment-service behavior before touching anything.
    print("\n[scenario] Documenting baseline payment-service behavior on main.")
    repo.commit("Baseline payment-service behavior documented.")

    # Create migration branch from baseline and then switch HEAD to it.
    print("[scenario] Creating `orm-migration` feature branch from baseline.")
    repo.create_branch("orm-migration")
    head = tmp_path / GCC_DIR_NAME / "refs" / "HEAD"
    head.write_text("orm-migration\n", encoding="utf-8")

    # Perform migration-related commits on feature branch, explicitly capturing
    # the constraints that come from the billing service.
    print("[scenario] Designing ORM migration plan on `orm-migration` branch.")
    repo.commit("Design ORM migration plan for transaction logs.")
    print("[scenario] Aligning migration plan with billing's hard-coded transaction log format.")
    repo.commit("Align migration with billing service's hard-coded log format.")

    # Histories before merge
    main_history = repo.history("main")
    feature_history = repo.history("orm-migration")

    assert [c["message"] for c in main_history][:1] == [
        "Baseline payment-service behavior documented.",
    ]
    assert [c["message"] for c in feature_history][:3] == [
        "Align migration with billing service's hard-coded log format.",
        "Design ORM migration plan for transaction logs.",
        "Baseline payment-service behavior documented.",
    ]

    # Merge migration back into main (fast-forward only in Sprint 1).
    print("[scenario] Fast-forward merging `orm-migration` back into `main`.")
    repo.merge_fast_forward("orm-migration", "main")

    merged_main_history = repo.history("main")
    messages = [c["message"] for c in merged_main_history]
    # After fast-forward, main should reflect the feature branch tip history
    assert "Align migration with billing service's hard-coded log format." in messages
    assert "Design ORM migration plan for transaction logs." in messages

