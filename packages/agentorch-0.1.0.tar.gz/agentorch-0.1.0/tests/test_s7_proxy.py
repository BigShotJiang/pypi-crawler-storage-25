"""
S7 proxy tests.

Uses FastAPI TestClient and unittest.mock — no real HTTP calls made.
"""
from __future__ import annotations

import json
import os
import platform
import sys
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Guard: skip entire module if proxy deps not installed
# ---------------------------------------------------------------------------

pytest.importorskip("fastapi", reason="fastapi not installed — run: pip install devtorch[proxy]")
pytest.importorskip("httpx", reason="httpx not installed — run: pip install devtorch[proxy]")
pytest.importorskip("uvicorn", reason="uvicorn not installed — run: pip install devtorch[proxy]")

from fastapi.testclient import TestClient
from devtorch_core.proxy.server import create_app, DEFAULT_PORT, DEFAULT_HOST


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_gcc_repo(initialized: bool = True) -> MagicMock:
    """Return a mock GCCRepository."""
    repo = MagicMock()
    repo.is_initialized.return_value = initialized
    repo.prompt_get.return_value = "# RACP System Prompt v2.1\nYou are a reasoning agent."
    repo.get_theta.return_value = {
        "coordination_vector": {
            "security": {"mean_confidence": 0.9},
            "performance": {"mean_confidence": 0.7},
        }
    }
    repo.context_bundle.return_value = {
        "artifacts": [
            {"path": "src/main.py", "reason": "entry point"},
        ]
    }
    return repo


@pytest.fixture
def gcc_repo():
    return _make_gcc_repo(initialized=True)


@pytest.fixture
def app(gcc_repo):
    return create_app(gcc_repo)


@pytest.fixture
def client(app):
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture
def app_no_gcc():
    repo = _make_gcc_repo(initialized=False)
    return create_app(repo)


@pytest.fixture
def client_no_gcc(app_no_gcc):
    return TestClient(app_no_gcc, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Test 1: Health endpoint
# ---------------------------------------------------------------------------

class TestHealthEndpoint:
    def test_health_endpoint_returns_200(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200

    def test_health_endpoint_status_ok(self, client):
        data = client.get("/health").json()
        assert data["status"] == "ok"

    def test_health_endpoint_gcc_initialized_true(self, client):
        data = client.get("/health").json()
        assert data["gcc_initialized"] is True

    def test_health_endpoint_gcc_initialized_false(self, client_no_gcc):
        data = client_no_gcc.get("/health").json()
        assert data["gcc_initialized"] is False


# ---------------------------------------------------------------------------
# Test 2: Route registration — Anthropic
# ---------------------------------------------------------------------------

class TestAnthropicRouteRegistered:
    def test_anthropic_route_registered(self, app):
        """Verify /anthropic/v1/messages route exists in the app."""
        routes = [str(r.path) for r in app.routes]  # type: ignore[attr-defined]
        assert any("/anthropic/" in r for r in routes), (
            f"No /anthropic/ route found in: {routes}"
        )

    def test_anthropic_not_404_when_mocked(self, client):
        """Route is registered — it returns something other than 404."""
        with patch(
            "devtorch_core.proxy.routes.anthropic.proxy_anthropic",
            new_callable=AsyncMock,
        ) as mock_handler:
            from fastapi.responses import JSONResponse
            mock_handler.return_value = JSONResponse({"mocked": True})
            resp = client.post("/anthropic/v1/messages", json={"model": "claude-3-5-sonnet-20241022"})
            # If route wasn't registered we'd get 404; any other status means it exists
            assert resp.status_code != 404


# ---------------------------------------------------------------------------
# Test 3: Route registration — OpenAI
# ---------------------------------------------------------------------------

class TestOpenAIRouteRegistered:
    def test_openai_route_registered(self, app):
        routes = [str(r.path) for r in app.routes]  # type: ignore[attr-defined]
        assert any("/openai/" in r for r in routes), (
            f"No /openai/ route found in: {routes}"
        )

    def test_openai_not_404_when_mocked(self, client):
        with patch(
            "devtorch_core.proxy.routes.openai.proxy_openai",
            new_callable=AsyncMock,
        ) as mock_handler:
            from fastapi.responses import JSONResponse
            mock_handler.return_value = JSONResponse({"mocked": True})
            resp = client.post(
                "/openai/v1/chat/completions",
                json={"model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}]},
            )
            assert resp.status_code != 404


# ---------------------------------------------------------------------------
# Test 4: RACP system injection — Anthropic
# ---------------------------------------------------------------------------

class TestSystemInjection:
    def _make_httpx_response(self, body: dict) -> MagicMock:
        """Return a mock httpx.Response."""
        content = json.dumps(body).encode()
        resp = MagicMock()
        resp.status_code = 200
        resp.content = content
        resp.text = json.dumps(body)
        resp.json.return_value = body
        resp.headers = {"content-type": "application/json"}
        return resp

    def test_racp_prefix_injected_into_system(self, gcc_repo):
        """Verify RACP prefix appears in the forwarded body's system field."""
        captured_bodies: list[dict] = []

        async def fake_request(method, url, headers, content):
            body = json.loads(content)
            captured_bodies.append(body)
            return self._make_httpx_response({"id": "msg_1", "content": []})

        mock_client = MagicMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.request = AsyncMock(side_effect=fake_request)

        with patch("httpx.AsyncClient", return_value=mock_client):
            app = create_app(gcc_repo)
            client = TestClient(app, raise_server_exceptions=False)
            resp = client.post(
                "/anthropic/v1/messages",
                json={
                    "model": "claude-3-5-sonnet-20241022",
                    "max_tokens": 100,
                    "messages": [{"role": "user", "content": "Hello"}],
                    "system": "You are helpful.",
                },
                headers={"x-api-key": "sk-ant-test-key"},
            )

        assert captured_bodies, "No request was forwarded to upstream"
        forwarded = captured_bodies[0]
        system_field = forwarded.get("system", "")
        assert "RACP" in system_field or "reasoning agent" in system_field, (
            f"RACP prefix not found in system field: {system_field!r}"
        )
        # Original system content should still be present
        assert "You are helpful." in system_field

    def test_racp_prefix_merges_with_existing_system(self, gcc_repo):
        """Existing system content is preserved and comes after the RACP prefix."""
        captured_bodies: list[dict] = []

        async def fake_request(method, url, headers, content):
            body = json.loads(content)
            captured_bodies.append(body)
            resp = MagicMock()
            resp.status_code = 200
            resp.content = b"{}"
            resp.text = "{}"
            resp.json.return_value = {}
            resp.headers = {"content-type": "application/json"}
            return resp

        mock_client = MagicMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.request = AsyncMock(side_effect=fake_request)

        with patch("httpx.AsyncClient", return_value=mock_client):
            app = create_app(gcc_repo)
            client = TestClient(app, raise_server_exceptions=False)
            client.post(
                "/anthropic/v1/messages",
                json={"model": "claude-3-5-sonnet-20241022", "system": "Original system."},
                headers={"x-api-key": "sk-ant-test"},
            )

        if captured_bodies:
            system = captured_bodies[0].get("system", "")
            # RACP prefix should appear before original content
            racp_pos = system.find("RACP")
            orig_pos = system.find("Original system.")
            if racp_pos != -1 and orig_pos != -1:
                assert racp_pos < orig_pos, "RACP prefix should precede original system content"


# ---------------------------------------------------------------------------
# Test 5: Header pass-through — x-api-key
# ---------------------------------------------------------------------------

class TestHeaderPassthrough:
    def test_api_key_forwarded_unchanged(self, gcc_repo):
        """x-api-key header value is forwarded unchanged to upstream."""
        captured_headers: list[dict] = []

        async def fake_request(method, url, headers, content):
            captured_headers.append(dict(headers))
            resp = MagicMock()
            resp.status_code = 200
            resp.content = b"{}"
            resp.text = "{}"
            resp.json.return_value = {}
            resp.headers = {"content-type": "application/json"}
            return resp

        mock_client = MagicMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.request = AsyncMock(side_effect=fake_request)

        with patch("httpx.AsyncClient", return_value=mock_client):
            app = create_app(gcc_repo)
            client = TestClient(app, raise_server_exceptions=False)
            client.post(
                "/anthropic/v1/messages",
                json={"model": "claude-3-5-sonnet-20241022"},
                headers={"x-api-key": "sk-ant-mykey-12345"},
            )

        assert captured_headers, "No headers were captured from forwarded request"
        forwarded = captured_headers[0]
        assert forwarded.get("x-api-key") == "sk-ant-mykey-12345", (
            f"x-api-key not forwarded correctly. Got: {forwarded}"
        )

    def test_host_header_replaced(self, gcc_repo):
        """Host header is replaced with upstream host, not the original."""
        captured_headers: list[dict] = []

        async def fake_request(method, url, headers, content):
            captured_headers.append(dict(headers))
            resp = MagicMock()
            resp.status_code = 200
            resp.content = b"{}"
            resp.text = "{}"
            resp.json.return_value = {}
            resp.headers = {"content-type": "application/json"}
            return resp

        mock_client = MagicMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.request = AsyncMock(side_effect=fake_request)

        with patch("httpx.AsyncClient", return_value=mock_client):
            app = create_app(gcc_repo)
            client = TestClient(app, raise_server_exceptions=False)
            client.post(
                "/anthropic/v1/messages",
                json={"model": "claude-3-5-sonnet-20241022"},
                headers={"x-api-key": "sk-ant-test"},
            )

        if captured_headers:
            host = captured_headers[0].get("host", "")
            assert "api.anthropic.com" in host, (
                f"Host header not replaced with upstream host. Got: {host!r}"
            )


# ---------------------------------------------------------------------------
# Test 6: No GCC → no injection, request forwarded as-is
# ---------------------------------------------------------------------------

class TestNoGccNoInjection:
    def test_no_gcc_request_forwarded_without_injection(self):
        """If gcc not initialized, system field should not be modified."""
        captured_bodies: list[dict] = []

        async def fake_request(method, url, headers, content):
            body = json.loads(content) if content else {}
            captured_bodies.append(body)
            resp = MagicMock()
            resp.status_code = 200
            resp.content = b"{}"
            resp.text = "{}"
            resp.json.return_value = {}
            resp.headers = {"content-type": "application/json"}
            return resp

        mock_client = MagicMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.request = AsyncMock(side_effect=fake_request)

        repo = _make_gcc_repo(initialized=False)

        with patch("httpx.AsyncClient", return_value=mock_client):
            app = create_app(repo)
            client = TestClient(app, raise_server_exceptions=False)
            client.post(
                "/anthropic/v1/messages",
                json={
                    "model": "claude-3-5-sonnet-20241022",
                    "system": "My original system.",
                },
                headers={"x-api-key": "sk-ant-test"},
            )

        if captured_bodies:
            system = captured_bodies[0].get("system", "")
            assert system == "My original system.", (
                f"System field was modified despite no initialized GCC. Got: {system!r}"
            )

    def test_no_gcc_repo_at_all(self):
        """None gcc_repo: request forwarded without injection."""
        captured_bodies: list[dict] = []

        async def fake_request(method, url, headers, content):
            body = json.loads(content) if content else {}
            captured_bodies.append(body)
            resp = MagicMock()
            resp.status_code = 200
            resp.content = b"{}"
            resp.text = "{}"
            resp.json.return_value = {}
            resp.headers = {"content-type": "application/json"}
            return resp

        mock_client = MagicMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.request = AsyncMock(side_effect=fake_request)

        with patch("httpx.AsyncClient", return_value=mock_client):
            app = create_app(gcc_repo=None)
            client = TestClient(app, raise_server_exceptions=False)
            client.post(
                "/anthropic/v1/messages",
                json={"model": "claude-3-5-sonnet-20241022", "system": "Clean system."},
                headers={"x-api-key": "sk-ant-test"},
            )

        if captured_bodies:
            system = captured_bodies[0].get("system", "")
            assert system == "Clean system."


# ---------------------------------------------------------------------------
# Test 7: macOS LaunchAgent installer
# ---------------------------------------------------------------------------

class TestInstallLaunchagentDarwin:
    def test_plist_file_written(self):
        """On Darwin, _install_launchagent writes the plist file."""
        from devtorch_core.proxy.server import _install_launchagent

        with tempfile.TemporaryDirectory() as tmpdir:
            fake_home = Path(tmpdir)
            plist_dir = fake_home / "Library" / "LaunchAgents"

            with (
                patch("devtorch_core.proxy.server.Path.home", return_value=fake_home),
                patch("shutil.which", return_value="/usr/local/bin/devtorch"),
            ):
                _install_launchagent()

            plist_path = plist_dir / "ai.devtorch.proxy.plist"
            assert plist_path.exists(), f"Plist not written at {plist_path}"
            content = plist_path.read_text()
            assert "ai.devtorch.proxy" in content
            assert "/usr/local/bin/devtorch" in content
            assert "<key>RunAtLoad</key>" in content
            assert "<true/>" in content

    def test_plist_content_has_keepalive(self):
        """Plist includes KeepAlive key."""
        from devtorch_core.proxy.server import _install_launchagent

        with tempfile.TemporaryDirectory() as tmpdir:
            fake_home = Path(tmpdir)

            with (
                patch("devtorch_core.proxy.server.Path.home", return_value=fake_home),
                patch("shutil.which", return_value="/usr/bin/devtorch"),
            ):
                _install_launchagent()

            plist_path = fake_home / "Library" / "LaunchAgents" / "ai.devtorch.proxy.plist"
            content = plist_path.read_text()
            assert "<key>KeepAlive</key>" in content

    def test_install_service_calls_launchagent_on_darwin(self):
        """install_service() dispatches to _install_launchagent on Darwin."""
        from devtorch_core.proxy import server as proxy_server

        with (
            patch("platform.system", return_value="Darwin"),
            patch.object(proxy_server, "_install_launchagent") as mock_la,
        ):
            proxy_server.install_service()
            mock_la.assert_called_once()


# ---------------------------------------------------------------------------
# Test 8: Linux systemd installer
# ---------------------------------------------------------------------------

class TestInstallSystemdLinux:
    def test_service_file_written(self):
        """On Linux, _install_systemd writes the service file."""
        from devtorch_core.proxy.server import _install_systemd

        with tempfile.TemporaryDirectory() as tmpdir:
            fake_home = Path(tmpdir)
            service_dir = fake_home / ".config" / "systemd" / "user"

            with (
                patch("devtorch_core.proxy.server.Path.home", return_value=fake_home),
                patch("shutil.which", return_value="/usr/local/bin/devtorch"),
            ):
                _install_systemd()

            service_path = service_dir / "devtorch-proxy.service"
            assert service_path.exists(), f"Service file not written at {service_path}"
            content = service_path.read_text()
            assert "/usr/local/bin/devtorch" in content
            assert "proxy start" in content
            assert "[Service]" in content
            assert "[Install]" in content

    def test_service_content_has_restart_policy(self):
        """systemd service includes Restart=on-failure."""
        from devtorch_core.proxy.server import _install_systemd

        with tempfile.TemporaryDirectory() as tmpdir:
            fake_home = Path(tmpdir)

            with (
                patch("devtorch_core.proxy.server.Path.home", return_value=fake_home),
                patch("shutil.which", return_value="/usr/bin/devtorch"),
            ):
                _install_systemd()

            service_path = (
                fake_home / ".config" / "systemd" / "user" / "devtorch-proxy.service"
            )
            content = service_path.read_text()
            assert "Restart=on-failure" in content

    def test_install_service_calls_systemd_on_linux(self):
        """install_service() dispatches to _install_systemd on Linux."""
        from devtorch_core.proxy import server as proxy_server

        with (
            patch("platform.system", return_value="Linux"),
            patch.object(proxy_server, "_install_systemd") as mock_sd,
        ):
            proxy_server.install_service()
            mock_sd.assert_called_once()


# ---------------------------------------------------------------------------
# Additional: defaults and constants
# ---------------------------------------------------------------------------

class TestProxyConstants:
    def test_default_port(self):
        assert DEFAULT_PORT == 8765

    def test_default_host(self):
        assert DEFAULT_HOST == "127.0.0.1"

    def test_default_host_is_localhost_only(self):
        """Ensure the proxy never binds to 0.0.0.0 by default."""
        assert DEFAULT_HOST != "0.0.0.0"
        assert DEFAULT_HOST != "::"


# ---------------------------------------------------------------------------
# Additional: OpenAI injection
# ---------------------------------------------------------------------------

class TestOpenAIInjection:
    def test_racp_injected_as_system_message(self, gcc_repo):
        """RACP prefix is prepended as system message in OpenAI messages array."""
        from devtorch_core.proxy.routes.openai import _build_racp_prefix

        prefix = _build_racp_prefix(gcc_repo)
        assert prefix, "Expected non-empty RACP prefix from initialized repo"
        assert "RACP" in prefix or "reasoning agent" in prefix

    def test_openai_system_message_merge(self, gcc_repo):
        """Existing system message content is preserved after injection."""
        from devtorch_core.proxy.routes.openai import _build_racp_prefix

        prefix = _build_racp_prefix(gcc_repo)
        messages = [
            {"role": "system", "content": "Existing system."},
            {"role": "user", "content": "Hello"},
        ]
        # Simulate merge logic
        if messages and messages[0].get("role") == "system":
            existing = messages[0]["content"]
            messages[0] = {"role": "system", "content": prefix + "\n\n" + existing}

        merged_content = messages[0]["content"]
        assert "Existing system." in merged_content
        assert prefix in merged_content


# ---------------------------------------------------------------------------
# Additional: Gemini injection helpers
# ---------------------------------------------------------------------------

class TestGeminiInjection:
    def test_inject_into_first_user_part(self):
        """RACP prefix prepended to first user content part text."""
        from devtorch_core.proxy.routes.gemini import _inject_racp_into_contents

        body = {
            "contents": [
                {"role": "user", "parts": [{"text": "What is 2+2?"}]},
            ]
        }
        result = _inject_racp_into_contents(body, "RACP PREFIX")
        first_text = result["contents"][0]["parts"][0]["text"]
        assert first_text.startswith("RACP PREFIX")
        assert "What is 2+2?" in first_text

    def test_inject_into_system_instruction_when_present(self):
        """If systemInstruction exists, inject there instead."""
        from devtorch_core.proxy.routes.gemini import _inject_racp_into_contents

        body = {
            "systemInstruction": {"parts": [{"text": "Be helpful."}]},
            "contents": [{"role": "user", "parts": [{"text": "Hi"}]}],
        }
        result = _inject_racp_into_contents(body, "RACP PREFIX")
        si_text = result["systemInstruction"]["parts"][0]["text"]
        assert "RACP PREFIX" in si_text
        assert "Be helpful." in si_text
        # User content should be unchanged
        assert result["contents"][0]["parts"][0]["text"] == "Hi"
