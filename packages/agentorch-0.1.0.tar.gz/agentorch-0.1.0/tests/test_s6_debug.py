"""Sprint 6 – Debug views and CLI smoke tests (init → commit → branch → context → debug)."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

from devtorch_core import GCCRepository, GCC_DIR_NAME


def test_debug_timeline_empty_filter(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    events = repo.debug_timeline(filter_types=["COMMIT"])
    assert events == []
    all_events = repo.debug_timeline()
    assert len(all_events) >= 1  # INIT
    assert any(e.get("event_type") == "INIT" for e in all_events)


def test_debug_timeline_after_commit(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("first")
    events = repo.debug_timeline(filter_types=["COMMIT"])
    assert len(events) == 1
    assert events[0].get("payload", {}).get("message") == "first"


def test_debug_branch_compare(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("base")
    repo.create_branch("feature")
    head_ref = tmp_path / GCC_DIR_NAME / "refs" / "HEAD"
    head_ref.write_text("feature\n", encoding="utf-8")
    repo.commit("on feature")
    data = repo.debug_branch_compare("main", "feature")
    assert "branch1" in data and "branch2" in data
    assert len(data["branch1"]) >= 1
    assert len(data["branch2"]) >= 2
    assert "theta" in data


def test_debug_invariant_trace_clear(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("one")
    traces = repo.debug_invariant_trace()
    assert traces == []


def test_debug_invariant_trace_failure(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("one")
    # Corrupt main tip so I1 fails
    (tmp_path / GCC_DIR_NAME / "refs" / "branches" / "main").write_text("fake_tip", encoding="utf-8")
    traces = repo.debug_invariant_trace()
    assert len(traces) >= 1
    assert traces[0]["invariant_id"] == "I1"
    assert "actionable_fix" in traces[0]


def test_cli_debug_timeline_smoke(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("smoke")
    result = subprocess.run(
        [sys.executable, "-m", "devtorch_cli.main", "-C", str(tmp_path), "debug", "timeline"],
        capture_output=True,
        text=True,
        cwd=str(Path(__file__).resolve().parents[1]),
    )
    assert result.returncode == 0
    assert "INIT" in result.stdout or "COMMIT" in result.stdout


def test_cli_debug_branch_compare_smoke(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("base")
    repo.create_branch("b1")
    result = subprocess.run(
        [sys.executable, "-m", "devtorch_cli.main", "-C", str(tmp_path), "debug", "branch-compare", "main", "b1"],
        capture_output=True,
        text=True,
        cwd=str(Path(__file__).resolve().parents[1]),
    )
    assert result.returncode == 0
    assert "main" in result.stdout and "b1" in result.stdout


def test_cli_debug_invariant_trace_smoke(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("one")
    result = subprocess.run(
        [sys.executable, "-m", "devtorch_cli.main", "-C", str(tmp_path), "debug", "invariant-trace"],
        capture_output=True,
        text=True,
        cwd=str(Path(__file__).resolve().parents[1]),
    )
    assert result.returncode == 0
    assert "trace clear" in result.stdout.lower() or "no invariant" in result.stdout.lower()
