"""
tests/test_s7ent_gateway.py
============================
S7-ENT: Enterprise org gateway test suite.

Tests cover:
- PolicyEngine (request blocking, token limit, permissive defaults)
- SSOValidator (none provider, invalid tokens)
- MetricsWebhook (disabled guard, privacy payload audit)
- GatewayServer (health endpoint, policy enforcement, central API key substitution)

All network calls are mocked — tests run fully offline.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
import urllib.request
from unittest.mock import MagicMock, patch

import pytest

# Ensure the Implementation directory is on sys.path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from devtorch_core.gateway.policy import GovernancePolicy, PolicyEngine
from devtorch_core.gateway.sso import SSOValidator
from devtorch_core.gateway.metrics_webhook import MetricsWebhook
from devtorch_core.gateway.server import GatewayServer


# ===========================================================================
# PolicyEngine tests
# ===========================================================================

class TestPolicyEngine:

    def _engine(self, **kwargs) -> PolicyEngine:
        policy = GovernancePolicy(**kwargs)
        return PolicyEngine(policy)

    # -----------------------------------------------------------------------
    # check_request
    # -----------------------------------------------------------------------

    def test_policy_engine_blocks_disallowed_model(self):
        """Model not in allowed_models must be blocked with a descriptive reason."""
        engine = self._engine(allowed_models=["claude-opus-4-7", "gpt-4o"])
        allowed, reason = engine.check_request(
            model="gpt-3.5-turbo",
            messages=[],
            session_tokens_used=0,
        )
        assert allowed is False
        assert reason
        assert "gpt-3.5-turbo" in reason

    def test_policy_engine_allows_permitted_model(self):
        """Model in allowed_models must be allowed."""
        engine = self._engine(allowed_models=["claude-sonnet-4-6", "gpt-4o"])
        allowed, reason = engine.check_request(
            model="claude-sonnet-4-6",
            messages=[],
            session_tokens_used=0,
        )
        assert allowed is True
        assert reason == ""

    def test_policy_engine_blocks_over_token_limit(self):
        """Session at or above max_tokens_per_session must be blocked."""
        engine = self._engine(max_tokens_per_session=1000)
        allowed, reason = engine.check_request(
            model="claude-sonnet-4-6",
            messages=[],
            session_tokens_used=1000,
        )
        assert allowed is False
        assert "1000" in reason

    def test_policy_engine_blocks_exactly_at_limit(self):
        """Exactly at the limit (>=) should still block."""
        engine = self._engine(max_tokens_per_session=500)
        allowed, reason = engine.check_request(
            model="any-model",
            messages=[],
            session_tokens_used=500,
        )
        assert allowed is False

    def test_policy_engine_allows_below_token_limit(self):
        """Below the limit must be permitted."""
        engine = self._engine(max_tokens_per_session=500)
        allowed, reason = engine.check_request(
            model="any-model",
            messages=[],
            session_tokens_used=499,
        )
        assert allowed is True

    def test_policy_default_is_permissive(self):
        """GovernancePolicy.default() should allow any model and any token count."""
        policy = GovernancePolicy.default()
        engine = PolicyEngine(policy)

        allowed, reason = engine.check_request(
            model="totally-made-up-model-9000",
            messages=[{"role": "user", "content": "hello"}],
            session_tokens_used=999_999,
        )
        assert allowed is True
        assert reason == ""

    def test_policy_empty_allowed_models_permits_all(self):
        """Empty allowed_models list (default) means all models permitted."""
        engine = self._engine(allowed_models=[])
        allowed, _ = engine.check_request("any-model", [], 0)
        assert allowed is True

    # -----------------------------------------------------------------------
    # check_response
    # -----------------------------------------------------------------------

    def test_check_response_warns_when_racp_required_and_missing(self):
        """RACP compliance required + no RACP blocks → (True, non-empty warning)."""
        engine = self._engine(racp_compliance_required=True)
        allowed, warning = engine.check_response(
            response_body={"content": []},
            has_racp_blocks=False,
        )
        assert allowed is True  # Must not block
        assert warning  # Must have a warning string

    def test_check_response_ok_when_racp_present(self):
        """RACP compliance required + RACP blocks present → (True, '')."""
        engine = self._engine(racp_compliance_required=True)
        allowed, warning = engine.check_response(
            response_body={},
            has_racp_blocks=True,
        )
        assert allowed is True
        assert warning == ""

    def test_check_response_ok_when_compliance_not_required(self):
        """Compliance not required → no warning regardless of RACP presence."""
        engine = self._engine(racp_compliance_required=False)
        allowed, warning = engine.check_response(
            response_body={},
            has_racp_blocks=False,
        )
        assert allowed is True
        assert warning == ""

    # -----------------------------------------------------------------------
    # load_from_file
    # -----------------------------------------------------------------------

    def test_load_from_file_roundtrip(self):
        """Policy loaded from JSON must match what was written."""
        policy_data = {
            "allowed_models": ["gpt-4o", "claude-opus-4-7"],
            "max_tokens_per_session": 50000,
            "racp_compliance_required": True,
            "racp_compliance_threshold": 0.8,
            "require_devtorch_commit": True,
            "blocked_concepts": ["credentials", "pii"],
        }
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False
        ) as fh:
            json.dump(policy_data, fh)
            fh_path = fh.name

        try:
            policy = GovernancePolicy.load_from_file(fh_path)
            assert policy.allowed_models == ["gpt-4o", "claude-opus-4-7"]
            assert policy.max_tokens_per_session == 50000
            assert policy.racp_compliance_required is True
            assert policy.blocked_concepts == ["credentials", "pii"]
        finally:
            os.unlink(fh_path)


# ===========================================================================
# SSOValidator tests
# ===========================================================================

class TestSSOValidator:

    def test_sso_none_returns_anonymous(self):
        """Provider 'none' must return an anonymous identity dict."""
        sso = SSOValidator(provider="none")
        claims = sso.validate_token("any-token-or-empty")
        assert claims is not None
        assert claims["sub"] == "anonymous"
        assert "email" in claims

    def test_sso_none_extract_identity(self):
        """extract_identity on anonymous claims must return normalised dict."""
        sso = SSOValidator(provider="none")
        claims = sso.validate_token("")
        identity = sso.extract_identity(claims)
        assert "user_id" in identity
        assert "email" in identity
        assert "display_name" in identity

    def test_sso_invalid_token_returns_none(self):
        """A garbage token for a real provider must return None."""
        sso = SSOValidator(provider="okta")
        result = sso.validate_token("THIS.IS.GARBAGE!!!not-a-jwt")
        assert result is None

    def test_sso_empty_token_returns_none_for_real_provider(self):
        """Empty token string for a real provider must return None."""
        sso = SSOValidator(provider="azure-ad")
        result = sso.validate_token("")
        assert result is None

    def test_sso_unknown_provider_treated_as_none(self):
        """Unknown provider string must fall back to 'none' (anonymous)."""
        sso = SSOValidator(provider="mystery-sso-vendor")
        claims = sso.validate_token("any")
        assert claims is not None
        assert claims["sub"] == "anonymous"

    def test_extract_identity_standard_claims(self):
        """extract_identity must pull sub, email, name from standard JWT claims."""
        sso = SSOValidator(provider="none")
        claims = {
            "sub": "user-abc-123",
            "email": "dev@example.com",
            "name": "Dev User",
        }
        identity = sso.extract_identity(claims)
        assert identity["user_id"] == "user-abc-123"
        assert identity["email"] == "dev@example.com"
        assert identity["display_name"] == "Dev User"


# ===========================================================================
# MetricsWebhook tests
# ===========================================================================

class TestMetricsWebhook:

    def test_metrics_webhook_disabled_returns_false(self):
        """push() when enabled=False must return False without making any request."""
        wh = MetricsWebhook(webhook_url="https://example.com/hook", enabled=False)
        result = wh.push({"ts": "2026-04-18T00:00:00Z", "session_count": 1})
        assert result is False

    def test_metrics_webhook_no_url_returns_false(self):
        """push() with no webhook_url must return False even if enabled."""
        wh = MetricsWebhook(webhook_url="", enabled=True)
        result = wh.push({"session_count": 3})
        assert result is False

    def test_metrics_webhook_never_includes_prompts(self):
        """
        build_payload must not include prompt, content, messages, or reasoning
        keys in the output — privacy firewall verification.
        """
        sessions = [
            {
                "user_id": "alice",
                "tokens_used": 300,
                "mcs_score": 0.7,
                "dhs_score": 0.85,
                "collision_count": 2,
                # These should be stripped by privacy guard if included
                "prompt": "SECRET system prompt",
                "messages": [{"role": "user", "content": "my code"}],
                "content": "raw reasoning text",
            }
        ]

        wh = MetricsWebhook(enabled=False)
        payload = wh.build_payload(sessions)

        # Flatten the entire payload to check for forbidden keys
        payload_str = json.dumps(payload).lower()

        # The privacy guard must strip prompt/content/messages from sessions
        # before they reach the payload — but build_payload itself builds from
        # known safe fields only, so the payload should never contain them.
        assert "prompt" not in payload
        assert "content" not in payload
        assert "messages" not in payload
        assert "reasoning" not in payload

        # Verify it has only the expected schema keys
        assert "ts" in payload
        assert "gateway_version" in payload
        assert "token_counts" in payload
        assert "mcs_score" in payload
        assert "dhs_score" in payload
        assert "collision_count" in payload
        assert "session_count" in payload

    def test_build_payload_aggregates_correctly(self):
        """build_payload must aggregate tokens and scores across sessions."""
        sessions = [
            {"user_id": "alice", "tokens_used": 100, "mcs_score": 0.5, "dhs_score": 0.6, "collision_count": 1},
            {"user_id": "bob", "tokens_used": 200, "mcs_score": 0.7, "dhs_score": 0.8, "collision_count": 2},
        ]
        wh = MetricsWebhook(enabled=False)
        payload = wh.build_payload(sessions)

        assert payload["token_counts"]["total"] == 300
        assert payload["token_counts"]["by_session"]["alice"] == 100
        assert payload["token_counts"]["by_session"]["bob"] == 200
        assert payload["session_count"] == 2
        assert payload["collision_count"] == 3
        assert abs(payload["mcs_score"] - 0.6) < 0.001
        assert abs(payload["dhs_score"] - 0.7) < 0.001

    def test_metrics_webhook_push_success(self):
        """push() with a mock successful upstream must return True."""
        wh = MetricsWebhook(webhook_url="https://example.com/hook", enabled=True)

        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_response):
            result = wh.push({"session_count": 1, "ts": "2026-01-01"})

        assert result is True

    def test_metrics_webhook_push_failure_returns_false(self):
        """push() on network error must return False, not raise."""
        wh = MetricsWebhook(webhook_url="https://example.com/hook", enabled=True)

        with patch("urllib.request.urlopen", side_effect=Exception("connection refused")):
            result = wh.push({"session_count": 1})

        assert result is False


# ===========================================================================
# GatewayServer integration tests
# ===========================================================================

def _find_free_port() -> int:
    """Find a free TCP port on localhost."""
    import socket
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _start_gateway(port: int, **kwargs) -> GatewayServer:
    """Start a GatewayServer on *port* in a background thread."""
    gw = GatewayServer(port=port, **kwargs)
    gw.start(blocking=False)
    # Give the server a moment to bind.
    time.sleep(0.15)
    return gw


class TestGatewayServer:

    def test_gateway_server_health_endpoint(self):
        """GET /health must return 200 with JSON containing 'status': 'ok'."""
        port = _find_free_port()
        gw = _start_gateway(port)
        try:
            resp = urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=5)
            assert resp.status == 200
            body = json.loads(resp.read())
            assert body["status"] == "ok"
            assert "sessions" in body
            assert "policy" in body
        finally:
            gw.stop()

    def test_gateway_server_health_contains_policy_summary(self):
        """Health endpoint must include the policy summary."""
        port = _find_free_port()
        policy = GovernancePolicy(
            allowed_models=["gpt-4o"],
            max_tokens_per_session=99999,
        )
        gw = _start_gateway(port, policy=policy)
        try:
            resp = urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=5)
            body = json.loads(resp.read())
            assert "policy" in body
            assert body["policy"]["max_tokens_per_session"] == 99999
        finally:
            gw.stop()

    def test_gateway_server_policy_enforced(self):
        """Request with a blocked model must receive a 403 response."""
        port = _find_free_port()
        policy = GovernancePolicy(allowed_models=["gpt-4o"])
        gw = _start_gateway(port, policy=policy)
        try:
            request_body = json.dumps({
                "model": "forbidden-model-xyz",
                "messages": [{"role": "user", "content": "hello"}],
            }).encode("utf-8")

            req = urllib.request.Request(
                f"http://127.0.0.1:{port}/v1/chat/completions",
                data=request_body,
                method="POST",
                headers={"Content-Type": "application/json"},
            )

            try:
                urllib.request.urlopen(req, timeout=5)
                pytest.fail("Expected HTTP 403 but got success")
            except urllib.error.HTTPError as exc:
                assert exc.code == 403
                body = json.loads(exc.read())
                assert "error" in body
                assert "forbidden-model-xyz" in body["error"]
        finally:
            gw.stop()

    def test_gateway_server_sso_rejects_missing_token(self):
        """
        When SSO provider is set to a real provider, a missing token must
        receive a 401 response.
        """
        port = _find_free_port()
        sso = SSOValidator(provider="okta")
        gw = _start_gateway(port, sso=sso)
        try:
            request_body = json.dumps({
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "hello"}],
            }).encode("utf-8")

            req = urllib.request.Request(
                f"http://127.0.0.1:{port}/v1/chat/completions",
                data=request_body,
                method="POST",
                headers={"Content-Type": "application/json"},
                # No Authorization header
            )

            try:
                urllib.request.urlopen(req, timeout=5)
                pytest.fail("Expected HTTP 401 but got success")
            except urllib.error.HTTPError as exc:
                assert exc.code == 401
        finally:
            gw.stop()

    def test_central_api_key_substitution(self):
        """
        Verify that the gateway substitutes the org API key for the developer key
        on outgoing requests to the upstream.

        Strategy: stand up a tiny mock upstream that records the Authorization
        header it received, then assert it matches the org key not the dev key.
        """
        from http.server import BaseHTTPRequestHandler, HTTPServer

        received_headers: dict = {}

        class _MockUpstream(BaseHTTPRequestHandler):
            def do_POST(self):
                received_headers["authorization"] = self.headers.get("Authorization", "")
                received_headers["x-api-key"] = self.headers.get("x-api-key", "")
                body = json.dumps({
                    "choices": [{"message": {"role": "assistant", "content": "hi"}}],
                    "usage": {"total_tokens": 10},
                }).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        # Start mock upstream
        mock_port = _find_free_port()
        mock_server = HTTPServer(("127.0.0.1", mock_port), _MockUpstream)
        mock_thread = threading.Thread(target=mock_server.serve_forever, daemon=True)
        mock_thread.start()

        # Start gateway pointing to mock upstream
        gw_port = _find_free_port()
        ORG_OPENAI_KEY = "sk-org-secret-key-12345"
        DEV_KEY = "sk-dev-personal-key-99999"

        gw = _start_gateway(
            gw_port,
            upstream_openai=f"http://127.0.0.1:{mock_port}",
            openai_api_key=ORG_OPENAI_KEY,
        )

        try:
            request_body = json.dumps({
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "hello"}],
            }).encode("utf-8")

            req = urllib.request.Request(
                f"http://127.0.0.1:{gw_port}/v1/chat/completions",
                data=request_body,
                method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {DEV_KEY}",
                },
            )

            try:
                urllib.request.urlopen(req, timeout=5)
            except Exception:
                pass  # We only care about what the mock upstream received

            # The mock upstream must have received the ORG key, not the dev key.
            assert ORG_OPENAI_KEY in received_headers.get("authorization", ""), (
                f"Expected org key in Authorization, got: {received_headers}"
            )
            assert DEV_KEY not in received_headers.get("authorization", ""), (
                "Developer key must NOT be forwarded when org key is configured"
            )

        finally:
            gw.stop()
            mock_server.shutdown()

    def test_gateway_unknown_path_returns_404(self):
        """GET to an unknown path must return 404."""
        port = _find_free_port()
        gw = _start_gateway(port)
        try:
            try:
                urllib.request.urlopen(
                    f"http://127.0.0.1:{port}/nonexistent-path", timeout=5
                )
                pytest.fail("Expected 404")
            except urllib.error.HTTPError as exc:
                assert exc.code == 404
        finally:
            gw.stop()

    def test_gateway_session_count_increments_on_health(self):
        """Health endpoint must reflect the current session count (0 on fresh start)."""
        port = _find_free_port()
        gw = _start_gateway(port)
        try:
            resp = urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=5)
            body = json.loads(resp.read())
            assert body["sessions"] == 0
        finally:
            gw.stop()
