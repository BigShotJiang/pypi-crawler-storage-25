"""
Sprint 15 – REP Network: multi-node ledger synchronization tests.

Coverage:
  - TestNodeIdentity        (5 tests)
  - TestPeerRegistry        (5 tests)
  - TestSyncResult          (3 tests)
  - TestPushToPeer          (6 tests)
  - TestPullFromPeer        (6 tests)
  - TestREPServer           (7 tests, skipped if FastAPI absent)
  - TestSyncAllPeers        (5 tests)
"""

from __future__ import annotations

import json
import tempfile
import unittest
import uuid
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

from devtorch_core.rep import REPEnvelope, REPLedger, create_envelope
from devtorch_core.rep_network import (
    NodeIdentity,
    NodeRegistry,
    PeerEntry,
    SyncResult,
    pull_from_peer,
    push_to_peer,
    sync_all_peers,
    sync_with_peer,
)
from devtorch_core.rep_network.server import HAS_FASTAPI

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_gcc(tmp: str) -> Path:
    """Return a .GCC path inside tmp."""
    gcc = Path(tmp) / ".GCC"
    gcc.mkdir(parents=True, exist_ok=True)
    return gcc


def _make_ledger(gcc: Path) -> REPLedger:
    return REPLedger(gcc)


def _make_envelope(agent_id: str = "agent-1", round_id: int = 1) -> REPEnvelope:
    return create_envelope(agent_id=agent_id, round_id=round_id, payload={"x": 1})


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _fake_urlopen_factory(response_body: dict):
    """Return a mock urlopen context manager that yields response_body as JSON."""
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(response_body).encode("utf-8")
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    mock_urlopen = MagicMock(return_value=mock_resp)
    return mock_urlopen


# ===========================================================================
# TestNodeIdentity
# ===========================================================================

class TestNodeIdentity(unittest.TestCase):
    """5 tests for NodeRegistry identity management."""

    def test_get_or_create_creates_node_id_file(self):
        """get_or_create_identity should create .GCC/rep/node_id on first call."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            registry = NodeRegistry(str(gcc))
            identity = registry.get_or_create_identity()
            node_id_path = gcc / "rep" / "node_id"
            self.assertTrue(node_id_path.exists())
            self.assertEqual(node_id_path.read_text().strip(), identity.node_id)

    def test_get_or_create_returns_same_uuid_on_second_call(self):
        """Calling get_or_create_identity twice should return the same node_id."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            registry = NodeRegistry(str(gcc))
            id1 = registry.get_or_create_identity()
            id2 = registry.get_or_create_identity()
            self.assertEqual(id1.node_id, id2.node_id)

    def test_node_id_is_valid_uuid(self):
        """The generated node_id must be a valid UUID-4 string."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            registry = NodeRegistry(str(gcc))
            identity = registry.get_or_create_identity()
            parsed = uuid.UUID(identity.node_id)  # raises ValueError if invalid
            self.assertIsNotNone(parsed)

    def test_list_peers_returns_empty_list_when_file_missing(self):
        """list_peers should return [] when peers.json does not exist."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            registry = NodeRegistry(str(gcc))
            self.assertEqual(registry.list_peers(), [])

    def test_add_peer_persists_to_peers_json(self):
        """add_peer should write the peer to peers.json."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            registry = NodeRegistry(str(gcc))
            peer = PeerEntry(
                node_id="peer-abc",
                name="node-b",
                url="http://localhost:9000",
            )
            registry.add_peer(peer)
            peers = registry.list_peers()
            self.assertEqual(len(peers), 1)
            self.assertEqual(peers[0].node_id, "peer-abc")
            self.assertEqual(peers[0].url, "http://localhost:9000")


# ===========================================================================
# TestPeerRegistry
# ===========================================================================

class TestPeerRegistry(unittest.TestCase):
    """5 tests for full peer registry CRUD."""

    def _registry_with_peers(self, tmp: str, count: int = 2) -> NodeRegistry:
        gcc = _make_gcc(tmp)
        registry = NodeRegistry(str(gcc))
        for i in range(count):
            registry.add_peer(PeerEntry(
                node_id=f"peer-{i}",
                name=f"node-{i}",
                url=f"http://localhost:{9000 + i}",
            ))
        return registry

    def test_add_peer_deduplicates_by_node_id(self):
        """Adding a peer with an existing node_id should replace it."""
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry_with_peers(tmp, count=1)
            registry.add_peer(PeerEntry(
                node_id="peer-0",
                name="node-0-updated",
                url="http://localhost:9999",
            ))
            peers = registry.list_peers()
            self.assertEqual(len(peers), 1)
            self.assertEqual(peers[0].url, "http://localhost:9999")
            self.assertEqual(peers[0].name, "node-0-updated")

    def test_remove_peer_removes_correct_entry(self):
        """remove_peer should only remove the matching peer."""
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry_with_peers(tmp, count=3)
            registry.remove_peer("peer-1")
            peers = registry.list_peers()
            ids = [p.node_id for p in peers]
            self.assertNotIn("peer-1", ids)
            self.assertIn("peer-0", ids)
            self.assertIn("peer-2", ids)
            self.assertEqual(len(peers), 2)

    def test_update_peer_last_seen_updates_timestamp(self):
        """update_peer_last_seen should set a non-empty last_seen on the peer."""
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry_with_peers(tmp, count=2)
            registry.update_peer_last_seen("peer-0")
            peers = {p.node_id: p for p in registry.list_peers()}
            self.assertNotEqual(peers["peer-0"].last_seen, "")
            # Peer 1 should remain unchanged (still empty)
            self.assertEqual(peers["peer-1"].last_seen, "")

    def test_list_peers_returns_all_peers(self):
        """list_peers should return all stored peers."""
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry_with_peers(tmp, count=5)
            peers = registry.list_peers()
            self.assertEqual(len(peers), 5)

    def test_handles_corrupt_peers_json_gracefully(self):
        """list_peers should return [] if peers.json contains invalid JSON."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            rep_dir = gcc / "rep"
            rep_dir.mkdir(parents=True, exist_ok=True)
            (rep_dir / "peers.json").write_text("NOT VALID JSON {{{", encoding="utf-8")
            registry = NodeRegistry(str(gcc))
            self.assertEqual(registry.list_peers(), [])


# ===========================================================================
# TestSyncResult
# ===========================================================================

class TestSyncResult(unittest.TestCase):
    """3 tests for SyncResult dataclass."""

    def test_syncresult_fields_present(self):
        """SyncResult should expose all required fields."""
        r = SyncResult(peer_node_id="n1", peer_url="http://x")
        self.assertEqual(r.peer_node_id, "n1")
        self.assertEqual(r.peer_url, "http://x")
        self.assertEqual(r.pushed_count, 0)
        self.assertEqual(r.pulled_count, 0)

    def test_errors_defaults_to_empty_list(self):
        """errors field should default to an empty list."""
        r = SyncResult(peer_node_id="n1", peer_url="http://x")
        self.assertIsInstance(r.errors, list)
        self.assertEqual(len(r.errors), 0)

    def test_success_field_present_and_defaults_true(self):
        """success should be True by default."""
        r = SyncResult(peer_node_id="n1", peer_url="http://x")
        self.assertTrue(r.success)


# ===========================================================================
# TestPushToPeer
# ===========================================================================

class TestPushToPeer(unittest.TestCase):
    """6 tests for push_to_peer."""

    def _peer(self) -> PeerEntry:
        return PeerEntry(
            node_id="remote-1",
            name="remote",
            url="http://localhost:8767",
        )

    def test_returns_sync_result(self):
        """push_to_peer must return a SyncResult instance."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            ledger.append(_make_envelope(), _now())
            peer = self._peer()
            mock_urlopen = _fake_urlopen_factory({"accepted": 1, "duplicate": 0})
            with patch("urllib.request.urlopen", mock_urlopen):
                result = push_to_peer(ledger, peer)
            self.assertIsInstance(result, SyncResult)

    def test_pushed_count_equals_entries_sent(self):
        """pushed_count must reflect the number of entries sent."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            for i in range(3):
                ledger.append(_make_envelope(round_id=i + 1), _now())
            peer = self._peer()
            mock_urlopen = _fake_urlopen_factory({"accepted": 3, "duplicate": 0})
            with patch("urllib.request.urlopen", mock_urlopen):
                result = push_to_peer(ledger, peer)
            self.assertEqual(result.pushed_count, 3)

    def test_never_raises_on_connection_error(self):
        """push_to_peer must not propagate exceptions when peer is unreachable."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            ledger.append(_make_envelope(), _now())
            peer = self._peer()
            with patch("urllib.request.urlopen", side_effect=ConnectionError("refused")):
                result = push_to_peer(ledger, peer)  # must not raise
            self.assertIsNotNone(result)

    def test_success_false_on_connection_error(self):
        """success must be False when the peer is unreachable."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            ledger.append(_make_envelope(), _now())
            peer = self._peer()
            with patch("urllib.request.urlopen", side_effect=ConnectionError("refused")):
                result = push_to_peer(ledger, peer)
            self.assertFalse(result.success)

    def test_errors_list_non_empty_on_failure(self):
        """errors list must contain at least one message on failure."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            ledger.append(_make_envelope(), _now())
            peer = self._peer()
            with patch("urllib.request.urlopen", side_effect=OSError("timeout")):
                result = push_to_peer(ledger, peer)
            self.assertTrue(len(result.errors) > 0)

    def test_pushed_count_zero_when_ledger_empty(self):
        """pushed_count must be 0 when ledger has no entries."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            peer = self._peer()
            # urlopen should never be called for an empty ledger
            with patch("urllib.request.urlopen") as mock_urlopen:
                result = push_to_peer(ledger, peer)
            self.assertEqual(result.pushed_count, 0)
            mock_urlopen.assert_not_called()


# ===========================================================================
# TestPullFromPeer
# ===========================================================================

class TestPullFromPeer(unittest.TestCase):
    """6 tests for pull_from_peer."""

    def _peer(self) -> PeerEntry:
        return PeerEntry(
            node_id="remote-2",
            name="remote",
            url="http://localhost:8767",
        )

    def _envelope_dict(self, agent_id: str = "a1", round_id: int = 1) -> dict:
        env = _make_envelope(agent_id=agent_id, round_id=round_id)
        d = env.to_dict()
        d["envelope_id"] = f"{agent_id}-r{round_id}"
        return d

    def test_returns_sync_result(self):
        """pull_from_peer must return a SyncResult."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            peer = self._peer()
            mock_urlopen = _fake_urlopen_factory({
                "node_id": "remote-2",
                "entries": [self._envelope_dict()],
                "count": 1,
            })
            with patch("urllib.request.urlopen", mock_urlopen):
                result = pull_from_peer(ledger, peer)
            self.assertIsInstance(result, SyncResult)

    def test_pulled_count_matches_entries_received(self):
        """pulled_count must equal the number of new entries added."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            peer = self._peer()
            entries = [self._envelope_dict(round_id=i + 1) for i in range(4)]
            mock_urlopen = _fake_urlopen_factory({
                "node_id": "remote-2",
                "entries": entries,
                "count": 4,
            })
            with patch("urllib.request.urlopen", mock_urlopen):
                result = pull_from_peer(ledger, peer)
            self.assertEqual(result.pulled_count, 4)

    def test_never_raises_on_connection_error(self):
        """pull_from_peer must not propagate exceptions when peer is unreachable."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            peer = self._peer()
            with patch("urllib.request.urlopen", side_effect=ConnectionError("down")):
                result = pull_from_peer(ledger, peer)  # must not raise
            self.assertIsNotNone(result)

    def test_handles_empty_entry_list_from_peer(self):
        """pulled_count should be 0 when peer returns empty entries list."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            peer = self._peer()
            mock_urlopen = _fake_urlopen_factory({
                "node_id": "remote-2",
                "entries": [],
                "count": 0,
            })
            with patch("urllib.request.urlopen", mock_urlopen):
                result = pull_from_peer(ledger, peer)
            self.assertEqual(result.pulled_count, 0)
            self.assertTrue(result.success)

    def test_skips_duplicate_entries_by_envelope_id(self):
        """Entries with an envelope_id already in the ledger must be skipped."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            peer = self._peer()

            # First pull — receives 3 entries
            entries = [self._envelope_dict(round_id=i + 1) for i in range(3)]
            mock_urlopen = _fake_urlopen_factory({
                "node_id": "remote-2",
                "entries": entries,
                "count": 3,
            })
            with patch("urllib.request.urlopen", mock_urlopen):
                r1 = pull_from_peer(ledger, peer)

            # Second pull — same 3 entries; all should be skipped
            mock_urlopen2 = _fake_urlopen_factory({
                "node_id": "remote-2",
                "entries": entries,
                "count": 3,
            })
            with patch("urllib.request.urlopen", mock_urlopen2):
                r2 = pull_from_peer(ledger, peer)

            self.assertEqual(r1.pulled_count, 3)
            self.assertEqual(r2.pulled_count, 0)

    def test_pulled_count_correctly_excludes_duplicates(self):
        """pulled_count should only count genuinely new entries, not all received."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            peer = self._peer()

            old_entries = [self._envelope_dict(round_id=i + 1) for i in range(2)]
            new_entries = [self._envelope_dict(agent_id="a2", round_id=i + 1) for i in range(3)]

            # Pre-populate ledger with old_entries by pulling first
            mock1 = _fake_urlopen_factory({
                "node_id": "remote-2",
                "entries": old_entries,
                "count": 2,
            })
            with patch("urllib.request.urlopen", mock1):
                pull_from_peer(ledger, peer)

            # Now pull old + new; only new should count
            mock2 = _fake_urlopen_factory({
                "node_id": "remote-2",
                "entries": old_entries + new_entries,
                "count": 5,
            })
            with patch("urllib.request.urlopen", mock2):
                result = pull_from_peer(ledger, peer)

            self.assertEqual(result.pulled_count, 3)


# ===========================================================================
# TestREPServer
# ===========================================================================

@unittest.skipUnless(HAS_FASTAPI, "FastAPI not installed — skipping server tests")
class TestREPServer(unittest.TestCase):
    """7 tests for the FastAPI REP server app."""

    def setUp(self):
        from fastapi.testclient import TestClient
        from devtorch_core.rep_network.server import create_rep_server_app

        self.tmp = tempfile.TemporaryDirectory()
        self.gcc = _make_gcc(self.tmp.name)
        self.ledger = _make_ledger(self.gcc)
        self.registry = NodeRegistry(str(self.gcc))
        self.app = create_rep_server_app(self.ledger, self.registry)
        self.client = TestClient(self.app)

    def tearDown(self):
        self.tmp.cleanup()

    def _add_entries(self, count: int) -> None:
        for i in range(count):
            self.ledger.append(_make_envelope(round_id=i + 1), _now())

    def test_get_entries_returns_200_with_entries_list(self):
        """GET /rep/entries should return 200 and an entries list."""
        self._add_entries(3)
        resp = self.client.get("/rep/entries")
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertIn("entries", body)
        self.assertEqual(len(body["entries"]), 3)

    def test_get_entries_since_returns_subset(self):
        """GET /rep/entries?since=2 should return only entries after index 2."""
        self._add_entries(5)
        resp = self.client.get("/rep/entries?since=3")
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["count"], 2)

    def test_post_entries_adds_entry_to_ledger(self):
        """POST /rep/entries should add new entries to the ledger."""
        env = _make_envelope()
        entry_dict = env.to_dict()
        entry_dict["envelope_id"] = "test-eid-1"
        resp = self.client.post("/rep/entries", json={"entries": [entry_dict], "sender_id": ""})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["accepted"], 1)
        self.assertEqual(len(self.ledger.read_all()), 1)

    def test_post_entries_reports_duplicate_count(self):
        """POST /rep/entries should report duplicate entries correctly."""
        env = _make_envelope()
        entry_dict = env.to_dict()
        entry_dict["envelope_id"] = "dup-eid-1"
        # First post
        self.client.post("/rep/entries", json={"entries": [entry_dict], "sender_id": ""})
        # Second post — same entry
        resp = self.client.post("/rep/entries", json={"entries": [entry_dict], "sender_id": ""})
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["duplicate"], 1)
        self.assertEqual(body["accepted"], 0)

    def test_get_peers_returns_peer_list(self):
        """GET /rep/peers should return the list of known peers."""
        self.registry.add_peer(PeerEntry(node_id="p1", name="peer1", url="http://p1"))
        resp = self.client.get("/rep/peers")
        self.assertEqual(resp.status_code, 200)
        peers = resp.json()
        self.assertEqual(len(peers), 1)
        self.assertEqual(peers[0]["node_id"], "p1")

    def test_post_peers_adds_peer(self):
        """POST /rep/peers should add a new peer to the registry."""
        payload = {"node_id": "new-peer", "name": "np", "url": "http://np", "last_seen": ""}
        resp = self.client.post("/rep/peers", json=payload)
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["status"], "ok")
        peers = self.registry.list_peers()
        self.assertEqual(len(peers), 1)
        self.assertEqual(peers[0].node_id, "new-peer")

    def test_health_returns_node_id(self):
        """GET /health should return status ok and a node_id."""
        resp = self.client.get("/health")
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["status"], "ok")
        self.assertIn("node_id", body)
        self.assertIsInstance(body["node_id"], str)


# ===========================================================================
# TestSyncAllPeers
# ===========================================================================

class TestSyncAllPeers(unittest.TestCase):
    """5 tests for sync_all_peers."""

    def _peer(self, idx: int) -> PeerEntry:
        return PeerEntry(
            node_id=f"peer-{idx}",
            name=f"node-{idx}",
            url=f"http://localhost:{9000 + idx}",
        )

    def test_returns_list_of_sync_result(self):
        """sync_all_peers should return a list of SyncResult objects."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            registry = NodeRegistry(str(gcc))
            registry.add_peer(self._peer(0))
            mock_urlopen = _fake_urlopen_factory({"accepted": 0, "duplicate": 0,
                                                   "node_id": "peer-0", "entries": []})
            with patch("urllib.request.urlopen", mock_urlopen):
                results = sync_all_peers(ledger, registry)
            self.assertIsInstance(results, list)
            self.assertTrue(all(isinstance(r, SyncResult) for r in results))

    def test_empty_peers_returns_empty_list(self):
        """sync_all_peers should return [] when no peers are registered."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            registry = NodeRegistry(str(gcc))
            results = sync_all_peers(ledger, registry)
            self.assertEqual(results, [])

    def test_failure_of_one_peer_does_not_prevent_others(self):
        """If peer-0 fails, peer-1 should still be synced."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            registry = NodeRegistry(str(gcc))
            registry.add_peer(self._peer(0))
            registry.add_peer(self._peer(1))

            call_count = [0]

            def side_effect(*args, **kwargs):
                call_count[0] += 1
                if call_count[0] == 1:
                    raise ConnectionError("peer-0 down")
                mock_resp = MagicMock()
                mock_resp.read.return_value = json.dumps(
                    {"accepted": 0, "duplicate": 0, "node_id": "peer-1", "entries": []}
                ).encode("utf-8")
                mock_resp.__enter__ = lambda s: s
                mock_resp.__exit__ = MagicMock(return_value=False)
                return mock_resp

            with patch("urllib.request.urlopen", side_effect=side_effect):
                results = sync_all_peers(ledger, registry)

            self.assertEqual(len(results), 2)

    def test_never_raises(self):
        """sync_all_peers must not propagate any exception."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            registry = NodeRegistry(str(gcc))
            registry.add_peer(self._peer(0))

            with patch("urllib.request.urlopen", side_effect=RuntimeError("fatal")):
                try:
                    results = sync_all_peers(ledger, registry)
                except Exception as exc:
                    self.fail(f"sync_all_peers raised unexpectedly: {exc}")

    def test_calls_sync_with_peer_for_each_peer(self):
        """sync_all_peers should produce one SyncResult per registered peer."""
        with tempfile.TemporaryDirectory() as tmp:
            gcc = _make_gcc(tmp)
            ledger = _make_ledger(gcc)
            registry = NodeRegistry(str(gcc))
            for i in range(4):
                registry.add_peer(self._peer(i))

            mock_urlopen = _fake_urlopen_factory(
                {"accepted": 0, "duplicate": 0, "node_id": "x", "entries": []}
            )
            with patch("urllib.request.urlopen", mock_urlopen):
                results = sync_all_peers(ledger, registry)

            self.assertEqual(len(results), 4)


if __name__ == "__main__":
    unittest.main()
