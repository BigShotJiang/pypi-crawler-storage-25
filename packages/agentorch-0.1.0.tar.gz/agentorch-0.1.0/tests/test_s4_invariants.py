"""Sprint 4 – Invariant engine (I1, I3), concept store, merge/lock-release gating."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from devtorch_core import (
    GCCRepository,
    GCC_DIR_NAME,
    InvariantFailure,
    InvariantEngine,
    InvariantContext,
    ConceptStore,
    check_i1_commit_backed,
    make_i3_semantic_handshake,
)


def test_i1_failure_when_tip_not_in_commits(tmp_path: Path) -> None:
    """I1 fails when a branch tip has no commit object under .GCC/commits/."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("only")
    # Point main to a fake tip that does not exist in commits/
    refs = tmp_path / GCC_DIR_NAME / "refs" / "branches"
    (refs / "main").write_text("nonexistent_commit_id", encoding="utf-8")

    context = InvariantContext(
        operation="merge",
        branch_tips={"main": "nonexistent_commit_id", "feature": "00000001"},
    )
    engine = InvariantEngine()
    engine.register("I1", check_i1_commit_backed)
    failures = engine.evaluate(repo, context)
    assert len(failures) >= 1
    assert any(f.invariant_id == "I1" and "no commit object" in f.message for f in failures)
    assert all(isinstance(f, InvariantFailure) and f.actionable_fix for f in failures)


def test_i1_pass_when_tips_committed_and_in_event_log(tmp_path: Path) -> None:
    """I1 passes when branch tips exist in commits/ and have COMMIT events."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("first")
    tip = repo._read_branch_tip("main")
    context = InvariantContext(
        operation="merge",
        branch_tips={"main": tip or ""},
        concepts_used=[],
    )
    engine = InvariantEngine()
    engine.register("I1", check_i1_commit_backed)
    failures = engine.evaluate(repo, context)
    assert failures == []


def test_i3_failure_when_concept_missing(tmp_path: Path) -> None:
    """I3 fails when an operation uses a concept that has no definition."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    store = ConceptStore(repo.gcc_dir)
    store.ensure_dir()
    # No concept "payment" added
    context = InvariantContext(
        operation="merge",
        branch_tips={},
        concepts_used=["payment", "balance"],
    )
    engine = InvariantEngine()
    engine.register("I3", make_i3_semantic_handshake(store))
    failures = engine.evaluate(repo, context)
    assert len(failures) >= 1
    assert any(f.invariant_id == "I3" for f in failures)


def test_i3_pass_when_all_concepts_defined(tmp_path: Path) -> None:
    """I3 passes when every concept_used has a definition in ConceptStore."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    store = ConceptStore(repo.gcc_dir)
    store.add("payment", "A transfer of value between accounts.")
    store.add("balance", "Current ledger balance for an account.")
    context = InvariantContext(
        operation="merge",
        branch_tips={},
        concepts_used=["payment", "balance"],
    )
    engine = InvariantEngine()
    engine.register("I3", make_i3_semantic_handshake(store))
    failures = engine.evaluate(repo, context)
    assert failures == []


def test_concept_store_hash_stability(tmp_path: Path) -> None:
    """Concept definition hash is stable (SHA-256 of definition)."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    store = ConceptStore(repo.gcc_dir)
    h1 = store.add("foo", "same text")
    h2 = store.hash_for("foo")
    assert h1 == h2
    assert len(h1) == 64 and all(c in "0123456789abcdef" for c in h1)
    # Re-add same definition: hash unchanged
    h_again = store.add("foo", "same text")
    assert h_again == h1


def test_merge_blocked_when_i1_fails(tmp_path: Path) -> None:
    """merge_fast_forward raises when I1 fails (e.g. missing commit for source tip)."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("base")
    repo.create_branch("feature")
    head_ref = tmp_path / GCC_DIR_NAME / "refs" / "HEAD"
    head_ref.write_text("feature\n", encoding="utf-8")
    repo.commit("on feature")
    # Corrupt feature tip to point to non-existent commit
    (tmp_path / GCC_DIR_NAME / "refs" / "branches" / "feature").write_text("bad_tip", encoding="utf-8")

    with pytest.raises(RuntimeError) as exc_info:
        repo.merge_fast_forward("feature", "main")
    assert "Invariant" in str(exc_info.value) or "I1" in str(exc_info.value)


def test_invariant_check_cli_path(tmp_path: Path) -> None:
    """invariant_check returns failures list; empty when all pass."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit("one")
    failures = repo.invariant_check(operation="merge")
    assert failures == []


def test_concept_add_and_list(tmp_path: Path) -> None:
    """concept_add and concept_list round-trip."""
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.concept_add("ledger", "A record of debits and credits.")
    names = repo.concept_list()
    assert "ledger" in names
