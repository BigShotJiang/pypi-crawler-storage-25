"""
Sprint 9 gap tests — A1 round cap (check_round_cap / RoundCapResult).
"""
from __future__ import annotations

import pytest

from devtorch_core import (
    check_round_cap,
    RoundCapResult,
    T_MAX_MULTIPLIER,
    CONVERGENCE_TIMEOUT_ROUNDS,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_t_max_multiplier(self):
        assert T_MAX_MULTIPLIER == 2.0

    def test_convergence_timeout_rounds(self):
        assert CONVERGENCE_TIMEOUT_ROUNDS == 20


# ---------------------------------------------------------------------------
# check_round_cap — basic allowed cases
# ---------------------------------------------------------------------------

class TestCheckRoundCapAllowed:
    def test_round_zero_allowed(self):
        result = check_round_cap(current_round=0, t_txt=5)
        assert isinstance(result, RoundCapResult)
        assert result.allowed is True
        assert result.reason == "ok"

    def test_round_at_t_max_allowed(self):
        # t_max = floor(2.0 * 5) = 10; round 10 should be allowed
        result = check_round_cap(current_round=10, t_txt=5)
        assert result.allowed is True
        assert result.t_max == 10

    def test_round_below_t_max_allowed(self):
        result = check_round_cap(current_round=3, t_txt=5)
        assert result.allowed is True
        assert result.current_round == 3

    def test_t_txt_zero_t_max_is_zero(self):
        # floor(2.0 * 0) = 0; round 0 is allowed (0 <= 0)
        result = check_round_cap(current_round=0, t_txt=0)
        assert result.allowed is True
        assert result.t_max == 0

    def test_t_txt_zero_round_one_blocked(self):
        result = check_round_cap(current_round=1, t_txt=0)
        assert result.allowed is False


# ---------------------------------------------------------------------------
# check_round_cap — blocked cases
# ---------------------------------------------------------------------------

class TestCheckRoundCapBlocked:
    def test_round_exceeds_t_max(self):
        # t_max = floor(2.0 * 5) = 10; round 11 should be blocked
        result = check_round_cap(current_round=11, t_txt=5)
        assert result.allowed is False
        assert result.t_max == 10
        assert "CONVERGENCE_TIMEOUT" in result.reason
        assert "11" in result.reason
        assert "10" in result.reason

    def test_reason_contains_t_txt(self):
        result = check_round_cap(current_round=15, t_txt=7)
        assert "7" in result.reason  # T_txt value

    def test_reason_contains_cap(self):
        result = check_round_cap(current_round=25, t_txt=5)
        # t_max capped at 20; reason should mention cap
        assert "cap=20" in result.reason

    def test_current_round_stored(self):
        result = check_round_cap(current_round=99, t_txt=10)
        assert result.current_round == 99


# ---------------------------------------------------------------------------
# check_round_cap — absolute cap enforcement
# ---------------------------------------------------------------------------

class TestCheckRoundCapAbsoluteCap:
    def test_absolute_cap_limits_t_max(self):
        # t_max = floor(2.0 * 50) = 100, but absolute_cap=20 → t_max=20
        result = check_round_cap(current_round=21, t_txt=50)
        assert result.t_max == 20
        assert result.allowed is False

    def test_round_at_absolute_cap_allowed(self):
        result = check_round_cap(current_round=20, t_txt=50)
        assert result.t_max == 20
        assert result.allowed is True

    def test_custom_absolute_cap(self):
        result = check_round_cap(current_round=6, t_txt=5, absolute_cap=5)
        # t_max = min(floor(2.0*5)=10, 5) = 5; round 6 > 5 → blocked
        assert result.allowed is False
        assert result.t_max == 5

    def test_custom_absolute_cap_within(self):
        result = check_round_cap(current_round=5, t_txt=5, absolute_cap=5)
        assert result.allowed is True


# ---------------------------------------------------------------------------
# check_round_cap — custom multiplier
# ---------------------------------------------------------------------------

class TestCheckRoundCapCustomMultiplier:
    def test_custom_multiplier_1x(self):
        # t_max = floor(1.0 * 10) = 10; round 11 blocked
        result = check_round_cap(current_round=11, t_txt=10, t_max_multiplier=1.0)
        assert result.allowed is False
        assert result.t_max == 10

    def test_custom_multiplier_3x(self):
        # t_max = floor(3.0 * 5) = 15; round 15 allowed
        result = check_round_cap(current_round=15, t_txt=5, t_max_multiplier=3.0, absolute_cap=100)
        assert result.allowed is True
        assert result.t_max == 15

    def test_multiplier_fraction(self):
        # t_max = floor(0.5 * 10) = 5; round 6 blocked
        result = check_round_cap(current_round=6, t_txt=10, t_max_multiplier=0.5)
        assert result.allowed is False
        assert result.t_max == 5


# ---------------------------------------------------------------------------
# RoundCapResult dataclass
# ---------------------------------------------------------------------------

class TestRoundCapResult:
    def test_fields_present_allowed(self):
        result = check_round_cap(current_round=1, t_txt=5)
        assert hasattr(result, "allowed")
        assert hasattr(result, "current_round")
        assert hasattr(result, "t_max")
        assert hasattr(result, "reason")

    def test_fields_present_blocked(self):
        result = check_round_cap(current_round=99, t_txt=5)
        assert result.allowed is False
        assert result.current_round == 99
        assert isinstance(result.t_max, int)
        assert isinstance(result.reason, str)

    def test_t_max_is_int(self):
        result = check_round_cap(current_round=1, t_txt=7)
        assert isinstance(result.t_max, int)
