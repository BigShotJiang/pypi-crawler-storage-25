"""
tests/test_s11_codex.py
=======================
Sprint 11 — OpenAI Codex CLI proxy tests.

Tests:
  test_pre_execute_injects_prefix        — with .GCC/ initialised, pre_execute adds system message
  test_pre_execute_passthrough_disabled  — DEVTORCH_DISABLE=1 → unchanged request body
  test_pre_execute_passthrough_no_gcc    — no .GCC/ → unchanged request body
  test_post_execute_silent_on_error      — broken response body → no exception
  test_install_codex_hook_creates_config — install_codex_hook writes .codex/config.json
  test_install_codex_hook_idempotent     — second call doesn't overwrite
  test_get_codex_hook_status_not_installed — returns codex_config=False when missing
  test_proxy_start_stop                  — starts proxy on random port, GET /health → 200
  test_proxy_forwards_request            — mock upstream, proxy forwards POST /v1/chat/completions
"""
from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _free_port() -> int:
    """Return a free local TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_port(port: int, timeout: float = 5.0) -> bool:
    """Poll until port is accepting connections or timeout expires."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return True
        except OSError:
            time.sleep(0.05)
    return False


def _make_mock_gcc_repo(prefix: str = "[DevTorch prefix]") -> MagicMock:
    """Return a mock GCCRepository that returns a simple RACP prefix."""
    repo = MagicMock()
    repo.is_initialized.return_value = True
    repo.prompt_get.return_value = prefix
    repo.get_theta.return_value = {"coordination_vector": {}}
    repo.context_bundle.return_value = {"artifacts": []}
    repo.commit.return_value = None
    repo.gcc_dir = "/fake/.GCC"
    return repo


# ---------------------------------------------------------------------------
# test_pre_execute_injects_prefix
# ---------------------------------------------------------------------------

def test_pre_execute_injects_prefix():
    """pre_execute should prepend a system message when .GCC/ is found."""
    from devtorch_core.codex.capture import CodexCaptureHandler

    handler = CodexCaptureHandler()
    mock_repo = _make_mock_gcc_repo("RACP context here")

    request_body = {
        "model": "gpt-4o",
        "messages": [
            {"role": "user", "content": "Hello"},
        ],
    }

    with patch.object(handler, "find_gcc_repo", return_value=mock_repo):
        result = handler.pre_execute(request_body, session_id="sess-001")

    messages = result.get("messages", [])
    assert len(messages) == 2, "Expected system message + user message"
    assert messages[0]["role"] == "system"
    assert "RACP context here" in messages[0]["content"]
    assert messages[1]["role"] == "user"


def test_pre_execute_prepends_to_existing_system_message():
    """pre_execute should merge prefix into an existing system message."""
    from devtorch_core.codex.capture import CodexCaptureHandler

    handler = CodexCaptureHandler()
    mock_repo = _make_mock_gcc_repo("RACP prefix")

    request_body = {
        "model": "gpt-4o",
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Hi"},
        ],
    }

    with patch.object(handler, "find_gcc_repo", return_value=mock_repo):
        result = handler.pre_execute(request_body, session_id="sess-002")

    messages = result.get("messages", [])
    # Still only one system message, content now has prefix prepended
    system_msgs = [m for m in messages if m["role"] == "system"]
    assert len(system_msgs) == 1
    assert "RACP prefix" in system_msgs[0]["content"]
    assert "You are a helpful assistant." in system_msgs[0]["content"]


# ---------------------------------------------------------------------------
# test_pre_execute_passthrough_disabled
# ---------------------------------------------------------------------------

def test_pre_execute_passthrough_when_disabled():
    """DEVTORCH_DISABLE=1 → pre_execute returns original body unchanged."""
    from devtorch_core.codex.capture import CodexCaptureHandler

    handler = CodexCaptureHandler()
    request_body = {
        "model": "gpt-4o",
        "messages": [{"role": "user", "content": "Hi"}],
    }

    with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}):
        result = handler.pre_execute(request_body, session_id="sess-003")

    assert result is request_body  # exact same object returned


# ---------------------------------------------------------------------------
# test_pre_execute_passthrough_no_gcc
# ---------------------------------------------------------------------------

def test_pre_execute_passthrough_when_no_gcc():
    """No .GCC/ → pre_execute returns original body unchanged."""
    from devtorch_core.codex.capture import CodexCaptureHandler

    handler = CodexCaptureHandler()
    request_body = {
        "model": "gpt-4o",
        "messages": [{"role": "user", "content": "Hello"}],
    }

    with patch.object(handler, "find_gcc_repo", return_value=None):
        result = handler.pre_execute(request_body, session_id="sess-004")

    assert result is request_body


# ---------------------------------------------------------------------------
# test_post_execute_silent_on_error
# ---------------------------------------------------------------------------

def test_post_execute_silent_on_error():
    """post_execute with a broken/empty response body must not raise."""
    from devtorch_core.codex.capture import CodexCaptureHandler

    handler = CodexCaptureHandler()

    # Repo that raises on commit to force an error path
    mock_repo = _make_mock_gcc_repo()
    mock_repo.commit.side_effect = RuntimeError("disk full")

    broken_response = {"choices": None}  # type: ignore — intentionally bad

    with patch.object(handler, "find_gcc_repo", return_value=mock_repo):
        # Must not raise
        handler.post_execute(
            request_body={"model": "gpt-4o", "messages": []},
            response_body=broken_response,
            session_id="sess-005",
        )


def test_post_execute_silent_when_disabled():
    """DEVTORCH_DISABLE=1 → post_execute returns immediately, no errors."""
    from devtorch_core.codex.capture import CodexCaptureHandler

    handler = CodexCaptureHandler()

    with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}):
        # Must not raise
        handler.post_execute(
            request_body={},
            response_body={},
            session_id="sess-006",
        )


# ---------------------------------------------------------------------------
# test_install_codex_hook_creates_config
# ---------------------------------------------------------------------------

def test_install_codex_hook_creates_config():
    """`install_codex_hook` writes .codex/config.json with correct content."""
    from devtorch_core.codex.proxy import install_codex_hook

    with tempfile.TemporaryDirectory() as tmpdir:
        ok, path = install_codex_hook(tmpdir)

        assert ok is True
        config_path = Path(path)
        assert config_path.exists()
        assert config_path.name == "config.json"

        config = json.loads(config_path.read_text())
        assert "apiBase" in config
        assert "localhost" in config["apiBase"]
        assert config["provider"] == "openai"


# ---------------------------------------------------------------------------
# test_install_codex_hook_idempotent
# ---------------------------------------------------------------------------

def test_install_codex_hook_idempotent():
    """Second call to install_codex_hook does NOT overwrite existing config."""
    from devtorch_core.codex.proxy import install_codex_hook

    with tempfile.TemporaryDirectory() as tmpdir:
        ok1, path1 = install_codex_hook(tmpdir)
        assert ok1

        # Write custom content
        custom = {"apiBase": "http://custom:9999/v1", "provider": "openai"}
        Path(path1).write_text(json.dumps(custom), encoding="utf-8")

        # Second install — should not overwrite
        ok2, path2 = install_codex_hook(tmpdir)
        assert ok2
        assert path1 == path2

        loaded = json.loads(Path(path2).read_text())
        assert loaded["apiBase"] == "http://custom:9999/v1"  # still custom


# ---------------------------------------------------------------------------
# test_get_codex_hook_status_not_installed
# ---------------------------------------------------------------------------

def test_get_codex_hook_status_not_installed():
    """`get_codex_hook_status` returns codex_config=False when not installed."""
    from devtorch_core.codex.proxy import get_codex_hook_status

    with tempfile.TemporaryDirectory() as tmpdir:
        status = get_codex_hook_status(tmpdir)

    assert status["codex_config"] is False
    assert "codex_config_path" in status
    assert "proxy_running" in status
    # proxy_running should be False (nothing listening on 8766 in tests)
    assert isinstance(status["proxy_running"], bool)


# ---------------------------------------------------------------------------
# test_proxy_start_stop
# ---------------------------------------------------------------------------

def test_proxy_start_stop():
    """Start proxy on a random port, GET /health → 200, then stop()."""
    from devtorch_core.codex.proxy import CodexProxy

    port = _free_port()
    proxy = CodexProxy(port=port)
    proxy.start_background()

    try:
        assert _wait_for_port(port), f"Proxy did not start on port {port}"

        req = urllib.request.Request(f"http://127.0.0.1:{port}/health")
        with urllib.request.urlopen(req, timeout=5) as resp:
            assert resp.status == 200
            body = json.loads(resp.read())
            assert body.get("status") == "ok"
    finally:
        proxy.stop()


# ---------------------------------------------------------------------------
# test_proxy_forwards_request
# ---------------------------------------------------------------------------

def test_proxy_forwards_request():
    """
    Proxy should forward POST /v1/chat/completions to the mock upstream and
    relay the response back.
    """
    from devtorch_core.codex.proxy import CodexProxy

    # ----------------------------------------------------------------
    # 1. Start a mock upstream server
    # ----------------------------------------------------------------
    upstream_port = _free_port()
    upstream_received: list = []

    class _MockUpstreamHandler(BaseHTTPRequestHandler):
        def log_message(self, *a) -> None:
            pass

        def do_POST(self) -> None:
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            upstream_received.append({"path": self.path, "body": body})

            resp_payload = json.dumps({
                "id": "chatcmpl-test",
                "object": "chat.completion",
                "choices": [
                    {
                        "message": {"role": "assistant", "content": "Hello!"},
                        "finish_reason": "stop",
                        "index": 0,
                    }
                ],
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(resp_payload)))
            self.end_headers()
            self.wfile.write(resp_payload)

    upstream_server = HTTPServer(("127.0.0.1", upstream_port), _MockUpstreamHandler)
    upstream_thread = threading.Thread(
        target=upstream_server.serve_forever, daemon=True
    )
    upstream_thread.start()
    assert _wait_for_port(upstream_port), "Mock upstream did not start"

    # ----------------------------------------------------------------
    # 2. Start the DevTorch Codex proxy pointing at the mock upstream
    # ----------------------------------------------------------------
    proxy_port = _free_port()
    proxy = CodexProxy(
        port=proxy_port,
        upstream=f"http://127.0.0.1:{upstream_port}",
    )
    proxy.start_background()

    try:
        assert _wait_for_port(proxy_port), "Proxy did not start"

        # ----------------------------------------------------------------
        # 3. Send POST /v1/chat/completions through the proxy
        # ----------------------------------------------------------------
        request_payload = json.dumps({
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "Say hello"}],
        }).encode("utf-8")

        req = urllib.request.Request(
            f"http://127.0.0.1:{proxy_port}/v1/chat/completions",
            data=request_payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": "Bearer test-key",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            assert resp.status == 200
            resp_body = json.loads(resp.read())

        # ----------------------------------------------------------------
        # 4. Verify
        # ----------------------------------------------------------------
        assert resp_body.get("id") == "chatcmpl-test"
        assert len(upstream_received) >= 1
        fwd = upstream_received[0]
        assert fwd["path"] == "/v1/chat/completions"
        fwd_body = json.loads(fwd["body"])
        assert fwd_body.get("model") == "gpt-4o"

    finally:
        proxy.stop()
        upstream_server.shutdown()
        upstream_server.server_close()
