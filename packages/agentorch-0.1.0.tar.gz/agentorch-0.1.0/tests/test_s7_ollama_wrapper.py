"""
tests/test_s7_ollama_wrapper.py
================================
Unit tests for the S7 Ollama LLM wrapper (DevTorchOllama).

All tests use unittest.mock — no real Ollama instance is required.
"""
from __future__ import annotations

import io
import json
import os
import sys
import types
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import MagicMock, patch, call

# ---------------------------------------------------------------------------
# Ensure the Implementation directory is on sys.path
# ---------------------------------------------------------------------------

IMPL_DIR = Path(__file__).parent.parent
if str(IMPL_DIR) not in sys.path:
    sys.path.insert(0, str(IMPL_DIR))


# ---------------------------------------------------------------------------
# Helper: build a realistic mock GCCRepository
# ---------------------------------------------------------------------------

def _make_mock_repo(
    racp_prompt: str = "You are a DevTorch-aware Ollama agent.",
    theta_vector: dict | None = None,
) -> MagicMock:
    repo = MagicMock()
    repo.is_initialized.return_value = True
    repo.get_theta.return_value = {
        "coordination_vector": theta_vector or {"test_concept": {"mean_confidence": 0.75}}
    }
    repo.prompt_get.return_value = racp_prompt
    repo.context_bundle.return_value = {
        "artifacts": [{"path": "main.md", "reason": "pinned header"}],
        "approx_tokens_used": 200,
    }
    repo.commit.return_value = None
    repo.add_sensitivity.return_value = "evt-1234"
    return repo


# ---------------------------------------------------------------------------
# Helper: build a minimal non-streaming OpenAI-compatible response dict
# ---------------------------------------------------------------------------

def _make_response(content: str = "Hello from Ollama!") -> dict:
    return {
        "id": "chatcmpl-test",
        "object": "chat.completion",
        "model": "llama3.2",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }


# ---------------------------------------------------------------------------
# Helper: build streaming chunk lines (SSE format)
# ---------------------------------------------------------------------------

def _make_stream_chunks(tokens: list[str]) -> list[bytes]:
    """Return SSE-encoded bytes lines for a streaming response."""
    lines: list[bytes] = []
    for token in tokens:
        chunk = {
            "choices": [
                {"delta": {"content": token}, "finish_reason": None}
            ]
        }
        lines.append(f"data: {json.dumps(chunk)}\n".encode())
    lines.append(b"data: [DONE]\n")
    return lines


# ===========================================================================
# 1. DEVTORCH_DISABLE — skips injection entirely
# ===========================================================================


class TestDevtorchDisableSkipsInjection(unittest.TestCase):
    """When DEVTORCH_DISABLE=1, messages must be passed through unchanged."""

    def _make_client(self) -> "DevTorchOllama":
        from devtorch_core.wrapper.ollama import DevTorchOllama

        repo = _make_mock_repo(racp_prompt="[SHOULD_NOT_APPEAR]")
        # Clear cached module so find_gcc_repo is tested through our repo
        client = DevTorchOllama.__new__(DevTorchOllama)
        client.model = "llama3.2"
        client.base_url = "http://localhost:11434"
        client._gcc_repo_path = None
        client._racp_prompt = None
        from devtorch_core.wrapper.base import RACPInjector, CaptureOrchestrator
        client._gcc = repo
        client._injector = RACPInjector(repo)
        client._capture = CaptureOrchestrator(repo)
        return client

    def test_messages_unchanged_when_disabled(self) -> None:
        from devtorch_core.wrapper.ollama import DevTorchOllama

        client = self._make_client()
        original = [{"role": "user", "content": "Hi there"}]

        with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}):
            result = client._inject(list(original))

        self.assertEqual(result, original)
        self.assertFalse(any(m.get("role") == "system" for m in result))

    def test_no_system_message_prepended_when_disabled(self) -> None:
        from devtorch_core.wrapper.ollama import DevTorchOllama

        client = self._make_client()
        messages = [{"role": "user", "content": "Query"}]

        with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}):
            injected = client._inject(messages)

        self.assertEqual(len(injected), 1)
        self.assertEqual(injected[0]["role"], "user")


# ===========================================================================
# 2. RACP prefix injected when enabled
# ===========================================================================


class TestRACPPrefixInjected(unittest.TestCase):
    """When DEVTORCH_DISABLE is not set, a system message should be prepended."""

    def _make_client_with_repo(self, repo: MagicMock) -> "DevTorchOllama":
        from devtorch_core.wrapper.ollama import DevTorchOllama
        from devtorch_core.wrapper.base import RACPInjector, CaptureOrchestrator

        client = DevTorchOllama.__new__(DevTorchOllama)
        client.model = "llama3.2"
        client.base_url = "http://localhost:11434"
        client._gcc_repo_path = None
        client._racp_prompt = None
        client._gcc = repo
        client._injector = RACPInjector(repo)
        client._capture = CaptureOrchestrator(repo)
        return client

    def test_system_message_prepended(self) -> None:
        repo = _make_mock_repo(racp_prompt="[RACP_OLLAMA] You are DevTorch-aware.")
        client = self._make_client_with_repo(repo)

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            injected = client._inject([{"role": "user", "content": "Hello"}])

        self.assertEqual(injected[0]["role"], "system")
        self.assertIn("[RACP_OLLAMA]", injected[0]["content"])

    def test_user_messages_preserved_after_injection(self) -> None:
        repo = _make_mock_repo(racp_prompt="RACP prefix")
        client = self._make_client_with_repo(repo)

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            injected = client._inject([{"role": "user", "content": "My query"}])

        user_msgs = [m for m in injected if m["role"] == "user"]
        self.assertEqual(len(user_msgs), 1)
        self.assertEqual(user_msgs[0]["content"], "My query")

    def test_full_chat_call_injects_and_returns_response(self) -> None:
        repo = _make_mock_repo(racp_prompt="[RACP_OLLAMA]")
        client = self._make_client_with_repo(repo)

        mock_response = _make_response("Ollama says hi!")
        posted_payloads: list[dict] = []

        def fake_post(url: str, payload: dict) -> dict:
            posted_payloads.append(payload)
            return mock_response

        client._post = fake_post  # type: ignore[method-assign]

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            result = client.chat([{"role": "user", "content": "Hello"}])

        self.assertEqual(result["choices"][0]["message"]["content"], "Ollama says hi!")
        messages_sent = posted_payloads[0]["messages"]
        self.assertEqual(messages_sent[0]["role"], "system")
        self.assertIn("[RACP_OLLAMA]", messages_sent[0]["content"])


# ===========================================================================
# 3. chat() returns safely when Ollama is down (ConnectionError)
# ===========================================================================


class TestChatReturnsSafelyWhenOllamaDown(unittest.TestCase):
    """ConnectionError must be caught; caller must never see an exception."""

    def _make_client(self) -> "DevTorchOllama":
        from devtorch_core.wrapper.ollama import DevTorchOllama
        from devtorch_core.wrapper.base import RACPInjector, CaptureOrchestrator

        repo = _make_mock_repo()
        client = DevTorchOllama.__new__(DevTorchOllama)
        client.model = "llama3.2"
        client.base_url = "http://localhost:11434"
        client._gcc_repo_path = None
        client._racp_prompt = None
        client._gcc = repo
        client._injector = RACPInjector(repo)
        client._capture = CaptureOrchestrator(repo)
        return client

    def test_returns_error_dict_not_exception(self) -> None:
        client = self._make_client()

        def raise_connection(*args, **kwargs):
            raise ConnectionError("Connection refused")

        client._post = raise_connection  # type: ignore[method-assign]

        result = client.chat([{"role": "user", "content": "Hello"}])

        self.assertIsInstance(result, dict)
        self.assertIn("error", result)
        self.assertIsInstance(result["error"], str)
        self.assertIn("choices", result)
        self.assertEqual(result["choices"], [])

    def test_error_message_is_informative(self) -> None:
        client = self._make_client()

        def raise_connection(*args, **kwargs):
            raise ConnectionError("Connection refused — Ollama not running")

        client._post = raise_connection  # type: ignore[method-assign]

        result = client.chat([{"role": "user", "content": "Hello"}])
        self.assertIn("Connection refused", result["error"])

    def test_no_exception_raised_to_caller(self) -> None:
        """Ensures the call does not propagate any exception."""
        client = self._make_client()

        def raise_connection(*args, **kwargs):
            raise ConnectionError("refused")

        client._post = raise_connection  # type: ignore[method-assign]

        try:
            client.chat([{"role": "user", "content": "Test"}])
        except Exception as exc:
            self.fail(f"chat() raised unexpectedly: {exc}")


# ===========================================================================
# 4. Streaming — yields chunks
# ===========================================================================


class TestStreamingYieldsChunks(unittest.TestCase):
    """Mock streaming, verify chunks are yielded with delta content."""

    def _make_client(self) -> "DevTorchOllama":
        from devtorch_core.wrapper.ollama import DevTorchOllama
        from devtorch_core.wrapper.base import RACPInjector, CaptureOrchestrator

        repo = _make_mock_repo()
        client = DevTorchOllama.__new__(DevTorchOllama)
        client.model = "llama3.2"
        client.base_url = "http://localhost:11434"
        client._gcc_repo_path = None
        client._racp_prompt = None
        client._gcc = repo
        client._injector = RACPInjector(repo)
        client._capture = CaptureOrchestrator(repo)
        return client

    def _fake_stream_post(
        self, tokens: list[str], accumulated: list[str]
    ):
        """Yield fake stream chunks and append to accumulated."""
        for token in tokens:
            accumulated.append(token)
            yield {
                "choices": [{"delta": {"content": token}, "finish_reason": None}]
            }

    def test_yields_expected_chunks(self) -> None:
        client = self._make_client()
        tokens = ["Hello", " from", " Ollama", "!"]

        def fake_stream_post(url, payload, accumulated):
            return self._fake_stream_post(tokens, accumulated)

        client._stream_post = fake_stream_post  # type: ignore[method-assign]

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            result_iter = client.chat(
                [{"role": "user", "content": "Hi"}], stream=True
            )
            chunks = list(result_iter)

        self.assertEqual(len(chunks), len(tokens))
        for chunk, token in zip(chunks, tokens):
            self.assertEqual(chunk["choices"][0]["delta"]["content"], token)

    def test_streaming_accumulates_text(self) -> None:
        """The accumulated text from all chunks should be complete."""
        client = self._make_client()
        tokens = ["Part1", " Part2", " Part3"]
        seen_accumulated: list[list[str]] = []

        def fake_stream_post(url, payload, accumulated):
            for token in tokens:
                accumulated.append(token)
                yield {"choices": [{"delta": {"content": token}}]}
            seen_accumulated.append(list(accumulated))

        client._stream_post = fake_stream_post  # type: ignore[method-assign]

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            list(client.chat([{"role": "user", "content": "Go"}], stream=True))

        # All tokens should have been accumulated
        self.assertTrue(any(len(acc) == len(tokens) for acc in seen_accumulated))

    def test_streaming_connection_error_yields_error_chunk(self) -> None:
        """When streaming raises ConnectionError, an error chunk is yielded."""
        client = self._make_client()

        def raise_stream(url, payload, accumulated):
            raise ConnectionError("refused")
            yield  # make it a generator

        client._stream_post = raise_stream  # type: ignore[method-assign]

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            chunks = list(
                client.chat([{"role": "user", "content": "Hi"}], stream=True)
            )

        self.assertTrue(len(chunks) >= 1)
        error_chunks = [c for c in chunks if "error" in c]
        self.assertTrue(len(error_chunks) >= 1)


# ===========================================================================
# 5. list_models() returns [] on error
# ===========================================================================


class TestListModelsReturnsEmptyOnError(unittest.TestCase):

    def _make_client(self) -> "DevTorchOllama":
        from devtorch_core.wrapper.ollama import DevTorchOllama
        from devtorch_core.wrapper.base import RACPInjector, CaptureOrchestrator

        repo = _make_mock_repo()
        client = DevTorchOllama.__new__(DevTorchOllama)
        client.model = "llama3.2"
        client.base_url = "http://localhost:11434"
        client._gcc_repo_path = None
        client._racp_prompt = None
        client._gcc = repo
        client._injector = RACPInjector(repo)
        client._capture = CaptureOrchestrator(repo)
        return client

    def test_returns_empty_list_on_connection_error(self) -> None:
        client = self._make_client()

        def raise_connection(url):
            raise ConnectionError("refused")

        client._get = raise_connection  # type: ignore[method-assign]
        result = client.list_models()
        self.assertEqual(result, [])

    def test_returns_empty_list_on_unexpected_error(self) -> None:
        client = self._make_client()

        def raise_runtime(url):
            raise RuntimeError("unexpected")

        client._get = raise_runtime  # type: ignore[method-assign]
        result = client.list_models()
        self.assertEqual(result, [])

    def test_returns_model_names_on_success(self) -> None:
        client = self._make_client()

        def fake_get(url):
            return {
                "models": [
                    {"name": "llama3.2"},
                    {"name": "mistral"},
                    {"name": "codellama"},
                ]
            }

        client._get = fake_get  # type: ignore[method-assign]
        result = client.list_models()
        self.assertEqual(result, ["llama3.2", "mistral", "codellama"])

    def test_returns_empty_list_on_no_exception_raised(self) -> None:
        """Verify the method signature itself never raises."""
        client = self._make_client()

        def raise_any(url):
            raise ValueError("bad json or whatever")

        client._get = raise_any  # type: ignore[method-assign]
        try:
            result = client.list_models()
        except Exception as exc:
            self.fail(f"list_models() raised unexpectedly: {exc}")
        self.assertEqual(result, [])


# ===========================================================================
# 6. CaptureOrchestrator.capture() fires after non-streaming response
# ===========================================================================


class TestCaptureFiresAfterResponse(unittest.TestCase):
    """Verify that CaptureOrchestrator.capture() is called with response content."""

    def _make_client_with_mock_capture(self) -> tuple:
        from devtorch_core.wrapper.ollama import DevTorchOllama
        from devtorch_core.wrapper.base import RACPInjector

        repo = _make_mock_repo()
        mock_capture = MagicMock()

        client = DevTorchOllama.__new__(DevTorchOllama)
        client.model = "llama3.2"
        client.base_url = "http://localhost:11434"
        client._gcc_repo_path = None
        client._racp_prompt = None
        client._gcc = repo
        client._injector = RACPInjector(repo)
        client._capture = mock_capture
        return client, mock_capture

    def test_capture_called_with_response_content(self) -> None:
        client, mock_capture = self._make_client_with_mock_capture()
        response_text = "Detailed Ollama answer here."
        mock_response = _make_response(response_text)

        client._post = lambda url, payload: mock_response  # type: ignore[method-assign]

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            client.chat([{"role": "user", "content": "Explain"}])

        mock_capture.capture.assert_called_once()
        args = mock_capture.capture.call_args[0]
        # First arg is the response text
        self.assertEqual(args[0], response_text)

    def test_capture_receives_empty_thinking_blocks(self) -> None:
        """Ollama wrapper always passes [] as thinking_blocks (inference path)."""
        client, mock_capture = self._make_client_with_mock_capture()
        client._post = lambda url, payload: _make_response("Answer")  # type: ignore[method-assign]

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            client.chat([{"role": "user", "content": "Q"}])

        args = mock_capture.capture.call_args[0]
        # Second arg is thinking_blocks — must be empty list
        self.assertEqual(args[1], [])

    def test_capture_not_called_when_disabled(self) -> None:
        client, mock_capture = self._make_client_with_mock_capture()
        client._post = lambda url, payload: _make_response("Answer")  # type: ignore[method-assign]

        with patch.dict(os.environ, {"DEVTORCH_DISABLE": "1"}):
            client.chat([{"role": "user", "content": "Q"}])

        mock_capture.capture.assert_not_called()

    def test_capture_not_called_on_error_response(self) -> None:
        """When HTTP call raises, capture should not be invoked."""
        client, mock_capture = self._make_client_with_mock_capture()

        def raise_conn(url, payload):
            raise ConnectionError("refused")

        client._post = raise_conn  # type: ignore[method-assign]

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            client.chat([{"role": "user", "content": "Q"}])

        mock_capture.capture.assert_not_called()


# ===========================================================================
# 7. Inference confidence tier ≤ 0.6
# ===========================================================================


class TestInferenceConfidenceTier(unittest.TestCase):
    """
    CaptureOrchestrator fallback path uses conf=0.5 (inference tier).
    Verify the commit message emitted through the real orchestrator
    contains the conf=0.5 marker.
    """

    def test_commit_message_contains_conf05_marker(self) -> None:
        from devtorch_core.wrapper.base import CaptureOrchestrator

        repo = _make_mock_repo()
        orch = CaptureOrchestrator(repo)
        # Plain text — no RACP blocks, triggers fallback path
        orch.capture("This is a plain Ollama response with no RACP tags.", [], "sess-oll-1")

        call_args_list = repo.commit.call_args_list
        messages = [str(c) for c in call_args_list]
        self.assertTrue(
            any("conf=0.5" in m for m in messages),
            f"Expected conf=0.5 marker in commit messages, got: {messages}",
        )

    def test_captured_confidence_is_at_most_06(self) -> None:
        """
        The inference fallback path must use confidence ≤ 0.6.
        We check this by examining what conf value appears in the commit
        message string (conf=0.5 is the value used by CaptureOrchestrator).
        """
        from devtorch_core.wrapper.base import CaptureOrchestrator

        repo = _make_mock_repo()
        orch = CaptureOrchestrator(repo)
        orch.capture("Ollama plain response text.", [], "sess-oll-2")

        call_args_list = repo.commit.call_args_list
        messages = " ".join(str(c) for c in call_args_list)

        # conf=0.5 is at most 0.6 — verify it's present and not a higher value
        self.assertIn("conf=0.5", messages)
        self.assertNotIn("conf=1.0", messages)
        self.assertNotIn("conf=0.9", messages)

    def test_ollama_wrapper_uses_empty_thinking_blocks(self) -> None:
        """
        DevTorchOllama must always pass empty thinking_blocks to capture()
        because Ollama models don't emit thinking tokens.
        """
        from devtorch_core.wrapper.ollama import DevTorchOllama
        from devtorch_core.wrapper.base import RACPInjector

        repo = _make_mock_repo()
        mock_capture = MagicMock()

        client = DevTorchOllama.__new__(DevTorchOllama)
        client.model = "llama3.2"
        client.base_url = "http://localhost:11434"
        client._gcc_repo_path = None
        client._racp_prompt = None
        client._gcc = repo
        client._injector = RACPInjector(repo)
        client._capture = mock_capture

        client._post = lambda url, p: _make_response("Response!")  # type: ignore[method-assign]

        env = {k: v for k, v in os.environ.items() if k != "DEVTORCH_DISABLE"}
        with patch.dict(os.environ, env, clear=True):
            client.chat([{"role": "user", "content": "Tell me"}])

        args = mock_capture.capture.call_args[0]
        thinking_blocks = args[1]
        # Must be empty — Ollama has no thinking tokens
        self.assertEqual(thinking_blocks, [])
        # Confidence tier must be inference (captured via empty thinking)
        # — just verify empty blocks were passed (conf=0.5 fallback will trigger)
        self.assertIsInstance(thinking_blocks, list)


# ===========================================================================
# 8. urllib.request fallback — verify _post/_get work without httpx
# ===========================================================================


class TestUrllibFallback(unittest.TestCase):
    """Verify that the urllib.request code path is used when HAS_HTTPX=False."""

    def _make_client(self) -> "DevTorchOllama":
        from devtorch_core.wrapper.ollama import DevTorchOllama
        from devtorch_core.wrapper.base import RACPInjector, CaptureOrchestrator

        repo = _make_mock_repo()
        client = DevTorchOllama.__new__(DevTorchOllama)
        client.model = "llama3.2"
        client.base_url = "http://localhost:11434"
        client._gcc_repo_path = None
        client._racp_prompt = None
        client._gcc = repo
        client._injector = RACPInjector(repo)
        client._capture = CaptureOrchestrator(repo)
        return client

    def test_post_urllib_raises_connection_error_on_url_error(self) -> None:
        """_post should convert URLError to ConnectionError (urllib path)."""
        import devtorch_core.wrapper.ollama as ollama_mod

        client = self._make_client()

        # Patch out httpx so urllib path is used
        with patch.object(ollama_mod, "HAS_HTTPX", False):
            with patch(
                "urllib.request.urlopen",
                side_effect=urllib.error.URLError("Connection refused"),
            ):
                with self.assertRaises(ConnectionError):
                    client._post("http://localhost:11434/v1/chat/completions", {})

    def test_get_urllib_raises_connection_error_on_url_error(self) -> None:
        import devtorch_core.wrapper.ollama as ollama_mod

        client = self._make_client()

        with patch.object(ollama_mod, "HAS_HTTPX", False):
            with patch(
                "urllib.request.urlopen",
                side_effect=urllib.error.URLError("Connection refused"),
            ):
                with self.assertRaises(ConnectionError):
                    client._get("http://localhost:11434/api/tags")

    def test_post_urllib_parses_response_json(self) -> None:
        import devtorch_core.wrapper.ollama as ollama_mod

        client = self._make_client()
        expected = _make_response("urllib answer")

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(expected).encode("utf-8")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch.object(ollama_mod, "HAS_HTTPX", False):
            with patch("urllib.request.urlopen", return_value=mock_resp):
                result = client._post(
                    "http://localhost:11434/v1/chat/completions", {}
                )

        self.assertEqual(
            result["choices"][0]["message"]["content"], "urllib answer"
        )


# ===========================================================================
# 9. _parse_sse_line helper
# ===========================================================================


class TestParseSSELine(unittest.TestCase):

    def test_parses_data_prefix(self) -> None:
        from devtorch_core.wrapper.ollama import _parse_sse_line

        token = "hello"
        chunk = {"choices": [{"delta": {"content": token}}]}
        line = f"data: {json.dumps(chunk)}"
        acc: list[str] = []
        result = _parse_sse_line(line, acc)
        self.assertIsNotNone(result)
        self.assertEqual(acc, [token])

    def test_skips_done_sentinel(self) -> None:
        from devtorch_core.wrapper.ollama import _parse_sse_line

        acc: list[str] = []
        result = _parse_sse_line("data: [DONE]", acc)
        self.assertIsNone(result)
        self.assertEqual(acc, [])

    def test_skips_empty_line(self) -> None:
        from devtorch_core.wrapper.ollama import _parse_sse_line

        result = _parse_sse_line("", [])
        self.assertIsNone(result)

    def test_skips_invalid_json(self) -> None:
        from devtorch_core.wrapper.ollama import _parse_sse_line

        result = _parse_sse_line("data: not-valid-json", [])
        self.assertIsNone(result)

    def test_parses_raw_json_without_data_prefix(self) -> None:
        """Also handles raw JSON lines (no 'data: ' prefix)."""
        from devtorch_core.wrapper.ollama import _parse_sse_line

        token = "world"
        chunk = {"choices": [{"delta": {"content": token}}]}
        acc: list[str] = []
        result = _parse_sse_line(json.dumps(chunk), acc)
        self.assertIsNotNone(result)
        self.assertEqual(acc, [token])


# ===========================================================================
# 10. _extract_text helper
# ===========================================================================


class TestExtractText(unittest.TestCase):

    def test_extracts_content_from_choices(self) -> None:
        from devtorch_core.wrapper.ollama import _extract_text

        response = _make_response("The answer is 42.")
        self.assertEqual(_extract_text(response), "The answer is 42.")

    def test_returns_empty_string_for_empty_choices(self) -> None:
        from devtorch_core.wrapper.ollama import _extract_text

        self.assertEqual(_extract_text({"choices": []}), "")

    def test_returns_empty_string_for_missing_choices(self) -> None:
        from devtorch_core.wrapper.ollama import _extract_text

        self.assertEqual(_extract_text({}), "")

    def test_handles_none_content_gracefully(self) -> None:
        from devtorch_core.wrapper.ollama import _extract_text

        response = {"choices": [{"message": {"content": None}}]}
        self.assertEqual(_extract_text(response), "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
