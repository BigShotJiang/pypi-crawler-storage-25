"""
tests/test_s7_parser.py
=======================
Tests for the S7 parser layer (devtorch_core.parser).

Coverage
--------
* extract_racp_blocks  — both block types, only commits, only sensitivities,
                         malformed XML, no blocks, attribute-order variation
* strip_racp_blocks    — blocks removed, surrounding text preserved,
                         paired tags, mixed content
* extract_thinking_blocks — Anthropic format, OpenAI format, empty / missing
* thinking_to_commit_message — normal, empty, long text, whitespace collapse
* infer_sensitivity    — schema keywords, auth keywords, empty text,
                         max_concepts limit, multi-match
* extract_decision_summary — normal sentence, markdown-heavy, very long,
                              empty, code-fence stripping
"""
from __future__ import annotations

import pytest

from devtorch_core.parser import (
    CommitBlock,
    InferredSensitivity,
    SensitivityBlock,
    ThinkingBlock,
    extract_decision_summary,
    extract_racp_blocks,
    extract_thinking_blocks,
    infer_sensitivity,
    strip_racp_blocks,
    thinking_to_commit_message,
)


# ===========================================================================
# extract_racp_blocks
# ===========================================================================

class TestExtractRacpBlocks:

    def test_both_block_types(self):
        text = (
            'Some reasoning here.\n'
            '<devtorch:commit message="migrate schema to v3" confidence="0.9"/>\n'
            'More text.\n'
            '<devtorch:sensitivity concept="schema_version" '
            'signal="migration collapses if format changes" '
            'confidence="0.91" disclosure="PROTECTED"/>\n'
            'End.'
        )
        commits, sensitivities = extract_racp_blocks(text)

        assert len(commits) == 1
        assert commits[0].message == "migrate schema to v3"
        assert commits[0].confidence == pytest.approx(0.9)

        assert len(sensitivities) == 1
        assert sensitivities[0].concept == "schema_version"
        assert sensitivities[0].signal == "migration collapses if format changes"
        assert sensitivities[0].confidence == pytest.approx(0.91)
        assert sensitivities[0].disclosure == "PROTECTED"

    def test_only_commit_blocks(self):
        text = (
            'Analysis done.\n'
            '<devtorch:commit message="add user auth" confidence="0.85"/>\n'
            '<devtorch:commit message="update tests" confidence="0.75"/>\n'
        )
        commits, sensitivities = extract_racp_blocks(text)

        assert len(commits) == 2
        assert commits[0].message == "add user auth"
        assert commits[0].confidence == pytest.approx(0.85)
        assert commits[1].message == "update tests"
        assert commits[1].confidence == pytest.approx(0.75)
        assert sensitivities == []

    def test_only_sensitivity_blocks(self):
        text = (
            'Considerations:\n'
            '<devtorch:sensitivity concept="auth_flow" signal="JWT expiry affects session" '
            'confidence="0.8" disclosure="SENSITIVE"/>\n'
        )
        commits, sensitivities = extract_racp_blocks(text)

        assert commits == []
        assert len(sensitivities) == 1
        assert sensitivities[0].concept == "auth_flow"
        assert sensitivities[0].disclosure == "SENSITIVE"

    def test_no_blocks(self):
        text = "This is a normal response with no RACP blocks."
        commits, sensitivities = extract_racp_blocks(text)
        assert commits == []
        assert sensitivities == []

    def test_empty_string(self):
        commits, sensitivities = extract_racp_blocks("")
        assert commits == []
        assert sensitivities == []

    def test_malformed_tag_skipped_gracefully(self):
        """Malformed XML must not raise; valid blocks in same text are still extracted."""
        text = (
            # malformed: unquoted attribute value
            '<devtorch:commit message=not-quoted confidence="0.9"/>\n'
            # valid block follows
            '<devtorch:commit message="valid block" confidence="0.8"/>\n'
        )
        # Should not raise
        commits, sensitivities = extract_racp_blocks(text)
        # The valid block should be parsed
        valid = [c for c in commits if c.message == "valid block"]
        assert len(valid) == 1

    def test_attribute_order_variation(self):
        """Attribute order should not matter."""
        text = (
            '<devtorch:sensitivity confidence="0.7" disclosure="PUBLIC" '
            'concept="api_contract" signal="endpoint shape drives clients"/>\n'
        )
        commits, sensitivities = extract_racp_blocks(text)
        assert len(sensitivities) == 1
        assert sensitivities[0].concept == "api_contract"
        assert sensitivities[0].confidence == pytest.approx(0.7)
        assert sensitivities[0].disclosure == "PUBLIC"

    def test_default_disclosure_is_protected(self):
        """When disclosure is omitted the default should be PROTECTED."""
        text = (
            '<devtorch:sensitivity concept="db_schema" '
            'signal="table layout changes break queries" confidence="0.88"/>\n'
        )
        _, sensitivities = extract_racp_blocks(text)
        assert sensitivities[0].disclosure == "PROTECTED"

    def test_default_confidence_commit(self):
        """When confidence is omitted the default should be 0.9."""
        text = '<devtorch:commit message="no confidence attr"/>\n'
        commits, _ = extract_racp_blocks(text)
        assert len(commits) == 1
        assert commits[0].confidence == pytest.approx(0.9)

    def test_multiple_blocks_mixed(self):
        text = (
            'Step 1.\n'
            '<devtorch:commit message="step one" confidence="0.9"/>\n'
            'Step 2.\n'
            '<devtorch:sensitivity concept="perf" signal="cache invalidation" confidence="0.6"/>\n'
            'Step 3.\n'
            '<devtorch:commit message="step three" confidence="0.95"/>\n'
        )
        commits, sensitivities = extract_racp_blocks(text)
        assert len(commits) == 2
        assert len(sensitivities) == 1
        assert commits[0].message == "step one"
        assert commits[1].message == "step three"


# ===========================================================================
# strip_racp_blocks
# ===========================================================================

class TestStripRacpBlocks:

    def test_self_closing_commit_removed(self):
        text = (
            'Before text.\n'
            '<devtorch:commit message="some commit" confidence="0.9"/>\n'
            'After text.'
        )
        result = strip_racp_blocks(text)
        assert '<devtorch:commit' not in result
        assert 'Before text.' in result
        assert 'After text.' in result

    def test_self_closing_sensitivity_removed(self):
        text = (
            'Preamble.\n'
            '<devtorch:sensitivity concept="x" signal="y" confidence="0.8"/>\n'
            'Postamble.'
        )
        result = strip_racp_blocks(text)
        assert '<devtorch:sensitivity' not in result
        assert 'Preamble.' in result
        assert 'Postamble.' in result

    def test_paired_tags_removed(self):
        text = (
            'Intro.\n'
            '<devtorch:context>Some internal context here.</devtorch:context>\n'
            'Conclusion.'
        )
        result = strip_racp_blocks(text)
        assert '<devtorch:context>' not in result
        assert 'Some internal context here.' not in result
        assert 'Intro.' in result
        assert 'Conclusion.' in result

    def test_surrounding_text_preserved(self):
        text = (
            'The answer is 42.\n'
            '<devtorch:commit message="answer" confidence="1.0"/>\n'
            'This is important information for the user.'
        )
        result = strip_racp_blocks(text)
        assert 'The answer is 42.' in result
        assert 'This is important information for the user.' in result

    def test_no_blocks_unchanged(self):
        text = "Plain response with no blocks at all."
        result = strip_racp_blocks(text)
        assert result == text

    def test_only_blocks_returns_empty_or_minimal(self):
        text = '<devtorch:commit message="only block" confidence="0.9"/>'
        result = strip_racp_blocks(text)
        assert '<devtorch:commit' not in result
        assert result.strip() == ""

    def test_mixed_self_closing_and_paired(self):
        text = (
            'Header.\n'
            '<devtorch:commit message="m" confidence="0.9"/>\n'
            '<devtorch:reasoning>internal chain of thought</devtorch:reasoning>\n'
            'Footer.'
        )
        result = strip_racp_blocks(text)
        assert 'devtorch' not in result
        assert 'Header.' in result
        assert 'Footer.' in result
        assert 'internal chain of thought' not in result


# ===========================================================================
# extract_thinking_blocks
# ===========================================================================

class TestExtractThinkingBlocks:

    def test_anthropic_format_single_thinking_block(self):
        response = {
            "content": [
                {"type": "thinking", "thinking": "I should consider the edge cases first."},
                {"type": "text", "text": "Here is my answer."},
            ]
        }
        blocks = extract_thinking_blocks(response)
        assert len(blocks) == 1
        assert blocks[0].text == "I should consider the edge cases first."
        assert blocks[0].confidence == 1.0
        assert blocks[0].source == "thinking_content"

    def test_anthropic_format_multiple_thinking_blocks(self):
        response = {
            "content": [
                {"type": "thinking", "thinking": "First thought."},
                {"type": "thinking", "thinking": "Second thought."},
                {"type": "text", "text": "Answer."},
            ]
        }
        blocks = extract_thinking_blocks(response)
        assert len(blocks) == 2
        assert blocks[0].text == "First thought."
        assert blocks[1].text == "Second thought."

    def test_anthropic_format_no_thinking_blocks(self):
        response = {
            "content": [
                {"type": "text", "text": "Direct answer, no thinking."},
            ]
        }
        blocks = extract_thinking_blocks(response)
        assert blocks == []

    def test_openai_o1_format(self):
        response = {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "The answer is X.",
                        "reasoning_content": "Let me think about this step by step...",
                    }
                }
            ]
        }
        blocks = extract_thinking_blocks(response)
        assert len(blocks) == 1
        assert blocks[0].text == "Let me think about this step by step..."
        assert blocks[0].source == "reasoning_content"

    def test_openai_format_no_reasoning_content(self):
        response = {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "Standard answer.",
                    }
                }
            ]
        }
        blocks = extract_thinking_blocks(response)
        assert blocks == []

    def test_empty_response(self):
        blocks = extract_thinking_blocks({})
        assert blocks == []

    def test_anthropic_thinking_block_empty_text_skipped(self):
        response = {
            "content": [
                {"type": "thinking", "thinking": ""},
                {"type": "thinking", "thinking": "Non-empty thought."},
            ]
        }
        blocks = extract_thinking_blocks(response)
        # Empty thinking text should be skipped
        assert len(blocks) == 1
        assert blocks[0].text == "Non-empty thought."

    def test_standard_model_no_thinking(self):
        """Standard non-reasoning model response — no special keys present."""
        response = {
            "id": "chatcmpl-abc123",
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "Hello!",
                    },
                    "finish_reason": "stop",
                }
            ],
        }
        blocks = extract_thinking_blocks(response)
        assert blocks == []


# ===========================================================================
# thinking_to_commit_message
# ===========================================================================

class TestThinkingToCommitMessage:

    def test_normal_block(self):
        blocks = [ThinkingBlock(text="I need to refactor the database layer.")]
        result = thinking_to_commit_message(blocks)
        assert result == "auto: I need to refactor the database layer."

    def test_empty_blocks(self):
        result = thinking_to_commit_message([])
        assert result == "auto: (no thinking content)"

    def test_truncation_at_max_chars(self):
        long_text = "word " * 100  # 500 chars
        blocks = [ThinkingBlock(text=long_text)]
        result = thinking_to_commit_message(blocks, max_chars=50)
        # "auto: " is 6 chars, the rest is <= 50 chars of content
        content = result[len("auto: "):]
        assert len(content) <= 50

    def test_newlines_collapsed(self):
        blocks = [ThinkingBlock(text="Line one.\nLine two.\nLine three.")]
        result = thinking_to_commit_message(blocks)
        assert "\n" not in result
        assert "Line one." in result
        assert "Line two." in result

    def test_only_first_block_used(self):
        blocks = [
            ThinkingBlock(text="First block thinking."),
            ThinkingBlock(text="Second block thinking."),
        ]
        result = thinking_to_commit_message(blocks)
        assert "First block thinking." in result
        assert "Second block thinking." not in result

    def test_prefix_always_present(self):
        blocks = [ThinkingBlock(text="anything")]
        result = thinking_to_commit_message(blocks)
        assert result.startswith("auto: ")


# ===========================================================================
# infer_sensitivity
# ===========================================================================

class TestInferSensitivity:

    def test_schema_keywords(self):
        text = "We need to run the database migration before deploying."
        results = infer_sensitivity(text)
        concepts = [r.concept for r in results]
        assert "data_schema" in concepts

    def test_auth_keywords(self):
        text = "The JWT token must be validated before granting access."
        results = infer_sensitivity(text)
        concepts = [r.concept for r in results]
        assert "authentication" in concepts

    def test_deployment_keywords(self):
        text = "The release pipeline will roll out the changes gradually."
        results = infer_sensitivity(text)
        concepts = [r.concept for r in results]
        assert "deployment" in concepts

    def test_security_keywords(self):
        text = "This patch fixes a SQL injection vulnerability in the login form."
        results = infer_sensitivity(text)
        concepts = [r.concept for r in results]
        assert "security" in concepts

    def test_performance_keywords(self):
        text = "We must reduce latency by adding a cache layer."
        results = infer_sensitivity(text)
        concepts = [r.concept for r in results]
        assert "performance" in concepts

    def test_configuration_keywords(self):
        text = "Update the environment configuration to point to the new endpoint."
        results = infer_sensitivity(text)
        concepts = [r.concept for r in results]
        # Should match at least one of 'configuration' or 'api_interface'
        assert any(c in concepts for c in ("configuration", "api_interface"))

    def test_empty_text(self):
        results = infer_sensitivity("")
        assert results == []

    def test_whitespace_only_text(self):
        results = infer_sensitivity("   \n\t  ")
        assert results == []

    def test_no_keyword_matches(self):
        text = "The sky is blue and the weather is pleasant today."
        results = infer_sensitivity(text)
        assert results == []

    def test_max_concepts_limit(self):
        # This text deliberately contains keywords for multiple concepts.
        text = (
            "The database migration affects the JWT auth token and the "
            "deploy pipeline and the cache layer."
        )
        results = infer_sensitivity(text, max_concepts=2)
        assert len(results) <= 2

    def test_confidence_always_0_5(self):
        text = "Run the database migration and update the auth token."
        results = infer_sensitivity(text)
        for r in results:
            assert r.confidence == pytest.approx(0.5)

    def test_source_is_heuristic(self):
        text = "schema migration needed"
        results = infer_sensitivity(text)
        assert all(r.source == "inference_heuristic" for r in results)

    def test_signal_truncated_to_120_chars(self):
        # Very long sentence to force truncation.
        long_sentence = "schema " + "x" * 200
        results = infer_sensitivity(long_sentence)
        assert len(results) >= 1
        assert len(results[0].signal) <= 120


# ===========================================================================
# extract_decision_summary
# ===========================================================================

class TestExtractDecisionSummary:

    def test_normal_sentence(self):
        text = "We decided to use PostgreSQL for the primary datastore."
        result = extract_decision_summary(text)
        assert result.startswith("auto: ")
        assert "PostgreSQL" in result

    def test_markdown_heavy_text(self):
        text = (
            "## Decision\n"
            "**We chose** to _refactor_ the `auth` module.\n"
            "This improves security."
        )
        result = extract_decision_summary(text)
        assert result.startswith("auto: ")
        # Markdown markers should be stripped
        assert "##" not in result
        assert "**" not in result
        assert "_" not in result

    def test_code_fence_stripped(self):
        text = (
            "```python\nprint('hello')\n```\n"
            "The above code prints hello."
        )
        result = extract_decision_summary(text)
        # Python syntax from inside the fence must be gone
        assert "print('hello')" not in result
        # The plain-English sentence following the fence should be captured
        assert "prints hello" in result or result.startswith("auto: ")

    def test_very_long_text_truncated(self):
        text = "word " * 200
        result = extract_decision_summary(text, max_chars=50)
        content = result[len("auto: "):]
        assert len(content) <= 50

    def test_empty_text(self):
        result = extract_decision_summary("")
        assert result == "auto: (no content)"

    def test_whitespace_only(self):
        result = extract_decision_summary("   \n\n  ")
        assert result == "auto: (no content)"

    def test_prefix_always_present(self):
        result = extract_decision_summary("Any text here.")
        assert result.startswith("auto: ")

    def test_bullet_list_stripped(self):
        text = (
            "- First option: refactor\n"
            "- Second option: rewrite\n"
            "We chose the first option."
        )
        result = extract_decision_summary(text)
        # Bullet markers should not appear
        assert "- " not in result

    def test_numbered_list_stripped(self):
        text = (
            "1. Analyse the problem\n"
            "2. Implement the solution\n"
            "Conclusion: implemented successfully."
        )
        result = extract_decision_summary(text)
        assert "1." not in result

    def test_multiline_paragraph_collapses(self):
        text = "This is\na sentence\nspread over lines."
        result = extract_decision_summary(text)
        assert result.startswith("auto: ")
        # Should contain the content (collapsed)
        assert "\n" not in result
