"""
Sprint 5 – A4: Δf (sensitivity) estimation runner, report artifact, expiry.

Publish Δf in Ωᵢ (capability) or separate store; used for privacy accounting.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

DELTAF_DIR_NAME = "deltaf"
DELTAF_REPORT_NAME = "deltaf_report.json"
DELTAF_EXPIRY_DAYS_DEFAULT = 90


@dataclass
class DeltaFReport:
    """Δf estimation report (global or per-concept)."""
    delta_f: float
    concept: Optional[str] = None
    expiry_date: Optional[str] = None  # ISO date
    computed_at: Optional[str] = None  # ISO timestamp

    def to_dict(self) -> dict:
        d = {"delta_f": self.delta_f}
        if self.concept is not None:
            d["concept"] = self.concept
        if self.expiry_date is not None:
            d["expiry_date"] = self.expiry_date
        if self.computed_at is not None:
            d["computed_at"] = self.computed_at
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "DeltaFReport":
        return cls(
            delta_f=float(d["delta_f"]),
            concept=d.get("concept"),
            expiry_date=d.get("expiry_date"),
            computed_at=d.get("computed_at"),
        )


def run_deltaf_estimation(
    sensitivities: list,
    concept: Optional[str] = None,
) -> DeltaFReport:
    """
    Placeholder Δf estimation: derive from sensitivity numerical values or use default.
    In production would use proper sensitivity analysis (e.g. global L2 sensitivity).
    """
    delta_f = 1.0  # placeholder
    for s in sensitivities:
        if isinstance(s, dict) and "numerical_value" in s and s["numerical_value"] is not None:
            delta_f = max(delta_f, abs(float(s["numerical_value"])))
    return DeltaFReport(delta_f=delta_f, concept=concept)


class DeltaFStore:
    """Persist Δf report and optionally publish to Ωᵢ."""
    def __init__(self, gcc_dir: Path) -> None:
        self.deltaf_dir = gcc_dir / DELTAF_DIR_NAME
        self.report_path = self.deltaf_dir / DELTAF_REPORT_NAME

    def ensure_dir(self) -> None:
        self.deltaf_dir.mkdir(parents=True, exist_ok=True)

    def save_report(self, report: DeltaFReport, computed_at: str, expiry_days: int = DELTAF_EXPIRY_DAYS_DEFAULT) -> None:
        """Save report with computed_at and expiry_date."""
        import datetime as _dt
        report.computed_at = computed_at
        try:
            d = _dt.datetime.fromisoformat(computed_at.replace("Z", "+00:00"))
            report.expiry_date = (d + _dt.timedelta(days=expiry_days)).date().isoformat()
        except Exception:
            report.expiry_date = None
        self.ensure_dir()
        self.report_path.write_text(json.dumps(report.to_dict(), indent=2) + "\n", encoding="utf-8")

    def load_report(self) -> Optional[DeltaFReport]:
        if not self.report_path.exists():
            return None
        return DeltaFReport.from_dict(json.loads(self.report_path.read_text(encoding="utf-8")))

    def is_expired(self) -> bool:
        """True if report exists and expiry_date is in the past."""
        r = self.load_report()
        if r is None or r.expiry_date is None:
            return False
        import datetime as _dt
        try:
            return _dt.date.fromisoformat(r.expiry_date) < _dt.date.today()
        except Exception:
            return False
