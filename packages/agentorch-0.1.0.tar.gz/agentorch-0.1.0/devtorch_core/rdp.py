"""
Sprint 5 – A4: RDP (Rényi Differential Privacy) accountant.

Per-round spend checks; PRIVACY_BUDGET_EXHAUSTED when budget exceeded; read-only mode.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

RDP_DIR_NAME = "rdp"
RDP_STATE_NAME = "rdp_state.json"
PRIVACY_BUDGET_EXHAUSTED_EVENT = "PRIVACY_BUDGET_EXHAUSTED"

# Default epsilon budget (total)
DEFAULT_EPSILON_BUDGET = 1.0
DEFAULT_ALPHA = 1.5  # Rényi order for composition


@dataclass
class RDPState:
    """RDP accountant state: remaining budget and spend history."""
    epsilon_budget: float
    epsilon_spent: float
    alpha: float
    round_ids: list  # rounds that consumed budget
    read_only: bool  # True after PRIVACY_BUDGET_EXHAUSTED

    def remaining(self) -> float:
        return max(0.0, self.epsilon_budget - self.epsilon_spent)

    def to_dict(self) -> dict:
        return {
            "epsilon_budget": self.epsilon_budget,
            "epsilon_spent": self.epsilon_spent,
            "alpha": self.alpha,
            "round_ids": list(self.round_ids),
            "read_only": self.read_only,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "RDPState":
        return cls(
            epsilon_budget=float(d.get("epsilon_budget", DEFAULT_EPSILON_BUDGET)),
            epsilon_spent=float(d.get("epsilon_spent", 0)),
            alpha=float(d.get("alpha", DEFAULT_ALPHA)),
            round_ids=list(d.get("round_ids", [])),
            read_only=bool(d.get("read_only", False)),
        )


def rdp_compose(epsilon_per_round: float, alpha: float, k_rounds: int) -> float:
    """Simple RDP composition: k rounds of (epsilon_per_round, alpha) -> total epsilon (approx)."""
    # RDP composition: (alpha, eps) * k -> (alpha, k*eps) for same alpha
    return k_rounds * epsilon_per_round


class RDPAccountant:
    """Persist RDP state and enforce per-round spend."""
    def __init__(self, gcc_dir: Path) -> None:
        self.rdp_dir = gcc_dir / RDP_DIR_NAME
        self.state_path = self.rdp_dir / RDP_STATE_NAME

    def ensure_dir(self) -> None:
        self.rdp_dir.mkdir(parents=True, exist_ok=True)

    def load_state(self) -> RDPState:
        if not self.state_path.exists():
            return RDPState(
                epsilon_budget=DEFAULT_EPSILON_BUDGET,
                epsilon_spent=0.0,
                alpha=DEFAULT_ALPHA,
                round_ids=[],
                read_only=False,
            )
        return RDPState.from_dict(json.loads(self.state_path.read_text(encoding="utf-8")))

    def save_state(self, state: RDPState) -> None:
        self.ensure_dir()
        self.state_path.write_text(json.dumps(state.to_dict(), indent=2) + "\n", encoding="utf-8")

    def spend(self, round_id: int, epsilon_cost: float) -> Tuple[bool, str]:
        """
        Attempt to spend epsilon_cost for round_id. Returns (allowed, event_or_empty).
        If allowed: state updated, return (True, "").
        If budget exceeded: state set read_only, return (False, PRIVACY_BUDGET_EXHAUSTED_EVENT).
        """
        state = self.load_state()
        if state.read_only:
            return False, PRIVACY_BUDGET_EXHAUSTED_EVENT
        if state.remaining() < epsilon_cost:
            state.read_only = True
            state.epsilon_spent = state.epsilon_budget
            self.save_state(state)
            return False, PRIVACY_BUDGET_EXHAUSTED_EVENT
        state.epsilon_spent += epsilon_cost
        state.round_ids.append(round_id)
        self.save_state(state)
        return True, ""

    def is_read_only(self) -> bool:
        return self.load_state().read_only
