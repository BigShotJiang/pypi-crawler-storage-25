"""
FastAPI server exposing REP ledger to peers.
Runs on a different port from the proxy (default 8767).
"""

from __future__ import annotations

from typing import Any, Dict, List

from devtorch_core.rep import REPEnvelope, REPLedger
from devtorch_core.rep_network.node import NodeRegistry, PeerEntry

try:
    from fastapi import Body, FastAPI
    from pydantic import BaseModel

    HAS_FASTAPI = True

    class PushEntriesRequest(BaseModel):
        entries: List[Dict[str, Any]]
        sender_id: str = ""

    class PeerEntryModel(BaseModel):
        node_id: str
        name: str = ""
        url: str = ""
        last_seen: str = ""

except ImportError:
    HAS_FASTAPI = False


def create_rep_server_app(ledger: REPLedger, registry: NodeRegistry) -> "FastAPI":
    """Build and return a FastAPI application exposing the REP ledger.

    Raises RuntimeError if FastAPI is not installed.
    """
    if not HAS_FASTAPI:
        raise RuntimeError("FastAPI is not installed; cannot create REP server app.")

    app = FastAPI(title="DevTorch REP Network Node", version="0.1.0")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    from devtorch_core.rep_network.sync import _envelope_ids_in_ledger, _persist_pulled_id

    def _existing_envelope_ids() -> set:
        return _envelope_ids_in_ledger(ledger)

    def _get_node_id() -> str:
        try:
            identity = registry.get_or_create_identity()
            return identity.node_id
        except Exception:  # noqa: BLE001
            return ""

    # ------------------------------------------------------------------
    # Routes
    # ------------------------------------------------------------------

    @app.get("/rep/entries")
    def get_entries(since: int = 0) -> Dict[str, Any]:
        """Return ledger entries with sequence_id > since."""
        all_records = ledger.read_all()
        filtered = [r for r in all_records if r.get("sequence_id", 0) > since]
        entries = [r.get("envelope", {}) for r in filtered]
        return {
            "node_id": _get_node_id(),
            "entries": entries,
            "count": len(entries),
        }

    @app.post("/rep/entries")
    def post_entries(request: PushEntriesRequest = Body(...)) -> Dict[str, Any]:
        """Accept pushed entries; skip duplicates by envelope_id."""
        existing_ids = _existing_envelope_ids()
        accepted = 0
        duplicate = 0
        import datetime as _dt

        for entry_dict in request.entries:
            eid = entry_dict.get("envelope_id")
            if eid and eid in existing_ids:
                duplicate += 1
                continue
            try:
                envelope = REPEnvelope.from_dict(entry_dict)
            except Exception:  # noqa: BLE001
                continue
            ts = entry_dict.get("timestamp", _dt.datetime.now(_dt.timezone.utc).isoformat())
            ledger.append(envelope, timestamp=ts)
            if eid:
                existing_ids.add(eid)
                _persist_pulled_id(ledger, eid)
            accepted += 1

        # Update last_seen for sender
        if request.sender_id:
            try:
                registry.update_peer_last_seen(request.sender_id)
            except Exception:  # noqa: BLE001
                pass

        return {"accepted": accepted, "duplicate": duplicate}

    @app.get("/rep/peers")
    def get_peers() -> List[Dict[str, Any]]:
        peers = registry.list_peers()
        return [
            {
                "node_id": p.node_id,
                "name": p.name,
                "url": p.url,
                "last_seen": p.last_seen,
            }
            for p in peers
        ]

    @app.post("/rep/peers")
    def post_peer(body: PeerEntryModel = Body(...)) -> Dict[str, str]:
        peer = PeerEntry(
            node_id=body.node_id,
            name=body.name,
            url=body.url,
            last_seen=body.last_seen,
        )
        registry.add_peer(peer)
        return {"status": "ok"}

    @app.get("/health")
    def health() -> Dict[str, Any]:
        return {
            "status": "ok",
            "node_id": _get_node_id(),
            "entry_count": len(ledger.read_all()),
        }

    return app
