"""
REP ledger push/pull synchronization.

Protocol:
  PUSH: POST /rep/entries  body: {entries: [...REPEnvelope dicts...], sender_id: str}
  PULL: GET  /rep/entries?since=<index_or_0>  → {entries: [...], node_id: str}

Sync is one-directional per call (push OR pull). Full sync = push then pull.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List

from devtorch_core.rep import REPEnvelope, REPLedger
from devtorch_core.rep_network.node import NodeRegistry, PeerEntry


@dataclass
class SyncResult:
    """Result of a push/pull sync operation with a single peer."""
    peer_node_id: str
    peer_url: str
    pushed_count: int = 0
    pulled_count: int = 0
    errors: List[str] = field(default_factory=list)
    success: bool = True


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read_entries_from(ledger: REPLedger, since_index: int) -> List[dict]:
    """Return ledger records (as dicts) with sequence_id > since_index."""
    all_records = ledger.read_all()
    return [r for r in all_records if r.get("sequence_id", 0) > since_index]


def _pulled_ids_path(ledger: REPLedger):
    return ledger.rep_dir / "pulled_ids.json"


def _envelope_ids_in_ledger(ledger: REPLedger) -> set:
    """Return set of envelope_ids already pulled (persisted sidecar + ledger records)."""
    ids: set = set()
    # Read from sidecar file (persists across calls)
    p = _pulled_ids_path(ledger)
    if p.exists():
        try:
            ids = set(json.loads(p.read_text(encoding="utf-8")))
        except Exception:
            pass
    # Also check envelope.payload_hash in stored records for additional dedup
    for record in ledger.read_all():
        env = record.get("envelope", {})
        eid = env.get("envelope_id")
        if eid:
            ids.add(eid)
    return ids


def _persist_pulled_id(ledger: REPLedger, eid: str) -> None:
    """Persist an envelope_id to the sidecar so future pulls skip it."""
    p = _pulled_ids_path(ledger)
    try:
        existing: set = set(json.loads(p.read_text(encoding="utf-8"))) if p.exists() else set()
        existing.add(eid)
        p.write_text(json.dumps(list(existing)), encoding="utf-8")
    except Exception:
        pass


def _post_json(url: str, payload: dict, timeout: int = 10) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        return json.loads(resp.read().decode("utf-8"))


def _get_json(url: str, timeout: int = 10) -> dict:
    req = urllib.request.Request(url, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        return json.loads(resp.read().decode("utf-8"))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def push_to_peer(
    ledger: REPLedger,
    peer: PeerEntry,
    since_index: int = 0,
) -> SyncResult:
    """POST entries from ledger to peer.  Never raises."""
    result = SyncResult(peer_node_id=peer.node_id, peer_url=peer.url)
    try:
        records = _read_entries_from(ledger, since_index)
        entries = [r.get("envelope", {}) for r in records]
        if not entries:
            result.pushed_count = 0
            return result

        identity_path = ledger.rep_dir / "node_id"
        sender_id = identity_path.read_text().strip() if identity_path.exists() else ""

        url = f"{peer.url.rstrip('/')}/rep/entries"
        _post_json(url, {"entries": entries, "sender_id": sender_id})
        result.pushed_count = len(entries)
    except Exception as exc:  # noqa: BLE001
        result.success = False
        result.errors.append(str(exc))
    return result


def pull_from_peer(
    ledger: REPLedger,
    peer: PeerEntry,
    since_index: int = 0,
) -> SyncResult:
    """GET entries from peer and append new ones to ledger.  Never raises."""
    result = SyncResult(peer_node_id=peer.node_id, peer_url=peer.url)
    try:
        url = f"{peer.url.rstrip('/')}/rep/entries?since={since_index}"
        response = _get_json(url)
        entries = response.get("entries", [])
        if not entries:
            return result

        existing_ids = _envelope_ids_in_ledger(ledger)
        pulled = 0
        for entry_dict in entries:
            eid = entry_dict.get("envelope_id")
            if eid and eid in existing_ids:
                continue
            # Build envelope from the dict; tolerate extra keys
            try:
                envelope = REPEnvelope.from_dict(entry_dict)
            except Exception:  # noqa: BLE001
                continue
            ts = entry_dict.get("timestamp", _timestamp())
            ledger.append(envelope, timestamp=ts)
            if eid:
                existing_ids.add(eid)
                _persist_pulled_id(ledger, eid)
            pulled += 1

        result.pulled_count = pulled
    except Exception as exc:  # noqa: BLE001
        result.success = False
        result.errors.append(str(exc))
    return result


def sync_with_peer(ledger: REPLedger, peer: PeerEntry) -> SyncResult:
    """Push then pull with a single peer; merge into one SyncResult."""
    push_result = push_to_peer(ledger, peer)
    pull_result = pull_from_peer(ledger, peer)

    merged = SyncResult(
        peer_node_id=peer.node_id,
        peer_url=peer.url,
        pushed_count=push_result.pushed_count,
        pulled_count=pull_result.pulled_count,
        errors=push_result.errors + pull_result.errors,
        success=push_result.success and pull_result.success,
    )
    return merged


def sync_all_peers(
    ledger: REPLedger,
    registry: NodeRegistry,
) -> List[SyncResult]:
    """Sync with every peer in registry.  Never raises."""
    results: List[SyncResult] = []
    try:
        peers = registry.list_peers()
    except Exception:  # noqa: BLE001
        return results

    for peer in peers:
        try:
            results.append(sync_with_peer(ledger, peer))
        except Exception as exc:  # noqa: BLE001
            results.append(SyncResult(
                peer_node_id=peer.node_id,
                peer_url=peer.url,
                success=False,
                errors=[str(exc)],
            ))
    return results
