"""
REP network node identity and peer discovery.

Nodes are identified by a UUID generated once and stored in .GCC/rep/node_id.
Peer discovery is file-based (no mDNS/DNS-SD in S15): peers are listed in
.GCC/rep/peers.json as [{id: str, url: str, name: str}].
"""

from __future__ import annotations

import json
import socket
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List


@dataclass
class NodeIdentity:
    """Identity of this node."""
    node_id: str
    name: str
    url: str


@dataclass
class PeerEntry:
    """A known remote peer."""
    node_id: str
    name: str
    url: str
    last_seen: str = ""


class NodeRegistry:
    """Manages node identity and peer list backed by .GCC/rep/ files."""

    def __init__(self, gcc_root: str) -> None:
        self._rep_dir = Path(gcc_root) / "rep"

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    def get_or_create_identity(self, url: str = "") -> NodeIdentity:
        """Read .GCC/rep/node_id; create and persist one if missing."""
        self._rep_dir.mkdir(parents=True, exist_ok=True)
        node_id_path = self._rep_dir / "node_id"
        if node_id_path.exists():
            try:
                node_id = node_id_path.read_text(encoding="utf-8").strip()
            except OSError:
                node_id = str(uuid.uuid4())
                node_id_path.write_text(node_id, encoding="utf-8")
        else:
            node_id = str(uuid.uuid4())
            node_id_path.write_text(node_id, encoding="utf-8")

        name = socket.gethostname()
        return NodeIdentity(node_id=node_id, name=name, url=url)

    # ------------------------------------------------------------------
    # Peers
    # ------------------------------------------------------------------

    def _peers_path(self) -> Path:
        return self._rep_dir / "peers.json"

    def list_peers(self) -> List[PeerEntry]:
        """Read .GCC/rep/peers.json; return empty list if missing or corrupt."""
        path = self._peers_path()
        if not path.exists():
            return []
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                return []
            peers = []
            for item in raw:
                if not isinstance(item, dict):
                    continue
                try:
                    peers.append(PeerEntry(
                        node_id=str(item["node_id"]),
                        name=str(item.get("name", "")),
                        url=str(item.get("url", "")),
                        last_seen=str(item.get("last_seen", "")),
                    ))
                except (KeyError, TypeError):
                    continue
            return peers
        except (json.JSONDecodeError, OSError):
            return []

    def _save_peers(self, peers: List[PeerEntry]) -> None:
        self._rep_dir.mkdir(parents=True, exist_ok=True)
        data = [
            {
                "node_id": p.node_id,
                "name": p.name,
                "url": p.url,
                "last_seen": p.last_seen,
            }
            for p in peers
        ]
        self._peers_path().write_text(json.dumps(data, indent=2), encoding="utf-8")

    def add_peer(self, peer: PeerEntry) -> None:
        """Append peer; replace existing entry with the same node_id."""
        peers = self.list_peers()
        peers = [p for p in peers if p.node_id != peer.node_id]
        peers.append(peer)
        self._save_peers(peers)

    def remove_peer(self, node_id: str) -> None:
        """Remove peer by node_id; no-op if not found."""
        peers = [p for p in self.list_peers() if p.node_id != node_id]
        self._save_peers(peers)

    def update_peer_last_seen(self, node_id: str) -> None:
        """Set last_seen to current UTC ISO timestamp for the given peer."""
        peers = self.list_peers()
        ts = datetime.now(timezone.utc).isoformat()
        updated = []
        for p in peers:
            if p.node_id == node_id:
                updated.append(PeerEntry(
                    node_id=p.node_id,
                    name=p.name,
                    url=p.url,
                    last_seen=ts,
                ))
            else:
                updated.append(p)
        self._save_peers(updated)
