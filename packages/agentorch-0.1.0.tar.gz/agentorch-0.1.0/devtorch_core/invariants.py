"""
Sprint 4 – Invariant engine (I1 Information Persistence, I3 Semantic Grounding).

InvariantEngine registers check functions and evaluates them against a context,
returning actionable InvariantFailure results. ConceptStore persists concept
definitions with hashes for I3 semantic handshake.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

CONCEPTS_DIR_NAME = "concepts"


@dataclass
class InvariantFailure:
    """A single invariant violation with an actionable fix hint."""
    invariant_id: str
    message: str
    actionable_fix: str


@dataclass
class InvariantContext:
    """Context passed to invariant check functions (e.g. for merge or lock-release)."""
    operation: str  # "merge", "lock_release", "finalize"
    branch_tips: Optional[Dict[str, str]] = None  # branch -> commit_id
    concepts_used: Optional[List[str]] = None


def _content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class ConceptStore:
    """
    Persist concept definitions under .GCC/concepts/<name>.json with content hash.
    I3 semantic grounding requires handshake: operations touching a concept
    must have a matching definition hash.
    """
    def __init__(self, gcc_dir: Path) -> None:
        self.concepts_dir = gcc_dir / CONCEPTS_DIR_NAME

    def ensure_dir(self) -> None:
        self.concepts_dir.mkdir(parents=True, exist_ok=True)

    def add(self, name: str, definition: str) -> str:
        """Store concept definition; return its content hash."""
        self.ensure_dir()
        h = _content_hash(definition)
        path = self.concepts_dir / f"{name}.json"
        path.write_text(
            json.dumps({"name": name, "definition": definition, "hash": h}, indent=2) + "\n",
            encoding="utf-8",
        )
        return h

    def get(self, name: str) -> Optional[dict]:
        """Return {"name", "definition", "hash"} or None."""
        path = self.concepts_dir / f"{name}.json"
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def hash_for(self, name: str) -> Optional[str]:
        """Return stored content hash for concept or None."""
        obj = self.get(name)
        return obj.get("hash") if obj else None

    def list_concepts(self) -> List[str]:
        """Return all concept names."""
        self.ensure_dir()
        return [p.stem for p in self.concepts_dir.glob("*.json")]


class InvariantEngine:
    """
    Register and evaluate invariants. Each invariant is a function
    (repo, context) -> list[InvariantFailure].
    """
    def __init__(self) -> None:
        self._checkers: List[tuple[str, Callable]] = []

    def register(self, invariant_id: str, check_fn: Callable) -> None:
        self._checkers.append((invariant_id, check_fn))

    def evaluate(self, repo, context: InvariantContext) -> List[InvariantFailure]:
        failures: List[InvariantFailure] = []
        for inv_id, check_fn in self._checkers:
            try:
                result = check_fn(repo, context)
                if result:
                    failures.extend(result)
            except Exception as e:
                failures.append(
                    InvariantFailure(
                        inv_id,
                        str(e),
                        "Fix the underlying error and re-run the operation.",
                    )
                )
        return failures


# --- I1: Information Persistence -------------------------------------------------
# Decision-finalizing operations must be backed by committed history: the branch
# tip must exist as a commit object and the decision must be reflected in the event log.

def check_i1_commit_backed(repo, context: InvariantContext) -> List[InvariantFailure]:
    """
    I1: Every branch tip in context must exist in commits/ and have a COMMIT event.
    """
    if not context.branch_tips:
        return []
    failures: List[InvariantFailure] = []
    commits_dir = repo.gcc_dir / "commits"
    event_log = repo.gcc_dir / "events.log.jsonl"
    commit_ids_in_log = set()
    if event_log.exists():
        for line in event_log.open("r", encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if obj.get("event_type") == "COMMIT":
                    cid = (obj.get("payload") or {}).get("commit_id")
                    if cid:
                        commit_ids_in_log.add(cid)
            except json.JSONDecodeError:
                continue
    for branch, tip in context.branch_tips.items():
        if not tip:
            continue
        commit_path = commits_dir / f"{tip}.json"
        if not commit_path.exists():
            failures.append(
                InvariantFailure(
                    "I1",
                    f"Branch '{branch}' tip {tip} has no commit object in .GCC/commits/.",
                    "Ensure the branch has at least one devtorch commit before merge or lock-release.",
                )
            )
        elif tip not in commit_ids_in_log:
            failures.append(
                InvariantFailure(
                    "I1",
                    f"Commit {tip} is not recorded in the event log (no COMMIT event).",
                    "Do not modify .GCC/commits/ or refs manually; use devtorch commit.",
                )
            )
    return failures


# --- I3: Semantic Grounding ------------------------------------------------------
# Operations that touch defined concepts require a handshake: the concept must exist
# in ConceptStore with a matching hash.

def make_i3_semantic_handshake(concept_store: ConceptStore) -> Callable:
    """Return a checker that requires all concepts_used to be defined and hash-matched."""

    def check_i3(repo, context: InvariantContext) -> List[InvariantFailure]:
        if not context.concepts_used:
            return []
        failures: List[InvariantFailure] = []
        for name in context.concepts_used:
            if concept_store.get(name) is None:
                failures.append(
                    InvariantFailure(
                        "I3",
                        f"Concept '{name}' has no definition in .GCC/concepts/.",
                        f"Run: devtorch concept add {name} '<definition>'",
                    )
                )
        return failures

    return check_i3
