"""
Sprint 5 – A3: Canonical system prompt artifact RACP_SYSTEM_PROMPT_v2.1.

Stored under .GCC/ and referenced by Textual Mode runs.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

PROMPTS_DIR_NAME = "prompts"
RACP_SYSTEM_PROMPT_NAME = "RACP_SYSTEM_PROMPT_v2.1.md"
RACP_SYSTEM_PROMPT_META = "RACP_SYSTEM_PROMPT_v2.1_meta.json"

DEFAULT_PROMPT_CONTENT = """# RACP System Prompt v2.1

You are a reasoning agent operating under the RACP (Reasoning and Coordination Protocol) v2.1.

- Emit only structured sensitivities with disclosed levels (PUBLIC, PROTECTED, PRIVATE).
- Respect coordination vector Θ and invariant constraints (I1, I3).
- When in Textual Mode, stay within the calibrated Lipschitz bound and pass PST.
- Do not leak [PRIVATE] content; apply receiver mandates for downstream reasoning.
"""


class PromptArtifactStore:
    """Store and retrieve the canonical RACP_SYSTEM_PROMPT_v2.1 artifact."""
    def __init__(self, gcc_dir: Path) -> None:
        self.prompts_dir = gcc_dir / PROMPTS_DIR_NAME
        self.prompt_path = self.prompts_dir / RACP_SYSTEM_PROMPT_NAME
        self.meta_path = self.prompts_dir / RACP_SYSTEM_PROMPT_META

    def ensure_dir(self) -> None:
        self.prompts_dir.mkdir(parents=True, exist_ok=True)

    def set_prompt(self, content: str, version: str = "v2.1") -> None:
        """Store prompt text and metadata."""
        self.ensure_dir()
        self.prompt_path.write_text(content, encoding="utf-8")
        meta = {"version": version, "artifact": RACP_SYSTEM_PROMPT_NAME}
        self.meta_path.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")

    def get_prompt(self) -> Optional[str]:
        """Return prompt content or None if not set."""
        if not self.prompt_path.exists():
            return None
        return self.prompt_path.read_text(encoding="utf-8")

    def get_meta(self) -> Optional[dict]:
        """Return metadata dict or None."""
        if not self.meta_path.exists():
            return None
        return json.loads(self.meta_path.read_text(encoding="utf-8"))

    def reference_for_textual_mode(self) -> Optional[str]:
        """Return path reference for Textual Mode runs (relative to .GCC)."""
        if not self.prompt_path.exists():
            return None
        return f"{PROMPTS_DIR_NAME}/{RACP_SYSTEM_PROMPT_NAME}"
