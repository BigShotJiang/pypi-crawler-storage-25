"""
Sprint 3 – Coordination vector Θ and pluggable Aggφ aggregation.

ThetaStore persists Θ (a concept → summary mapping) at `.GCC/theta.json`.
AggPhi is an abstract interface; RulesBasedAggPhi is the default implementation
that averages confidence with recency weighting and escalates disclosure levels.

Callers invoke `ThetaStore.ripple(events)` to merge a batch of sensitivity
event dicts into the stored Θ, using the configured AggPhi.
"""

from __future__ import annotations

import abc
import datetime as _dt
import json
import os
from pathlib import Path
from typing import Dict, List, Optional


THETA_FILE = "theta.json"

# Ordered disclosure level ranks (higher index = more restrictive)
_LEVEL_RANK: Dict[str, int] = {"PUBLIC": 0, "PROTECTED": 1, "PRIVATE": 2}
_RANK_LEVEL: Dict[int, str] = {0: "PUBLIC", 1: "PROTECTED", 2: "PRIVATE"}


class AggPhi(abc.ABC):
    """
    Pluggable aggregation interface (Aggφ).

    Implementations receive a list of raw sensitivity event dicts and return a
    *partial theta delta*: a mapping of concept → aggregated entry containing
    at minimum:
        mean_confidence  : float
        disclosure_level : str  ("PUBLIC" | "PROTECTED" | "PRIVATE")
        event_count      : int
    """

    @abc.abstractmethod
    def aggregate(self, events: List[dict]) -> Dict[str, dict]:
        """Aggregate *events* into a per-concept summary delta."""


class RulesBasedAggPhi(AggPhi):
    """
    Default rules-based Aggφ.

    Aggregation rules:
    1. Group events by `target_concept`.
    2. Within each group, sort by `created_at` descending (newest first).
    3. Apply recency weighting: the newest event has weight 2.0; all others 1.0.
    4. Compute weighted mean confidence.
    5. Escalate disclosure level to the maximum seen in the group.
    """

    def aggregate(self, events: List[dict]) -> Dict[str, dict]:
        grouped: Dict[str, List[dict]] = {}
        for ev in events:
            concept = ev.get("target_concept", "unknown")
            grouped.setdefault(concept, []).append(ev)

        result: Dict[str, dict] = {}
        for concept, group in grouped.items():
            sorted_group = sorted(
                group,
                key=lambda e: e.get("created_at", ""),
                reverse=True,
            )
            total_weight = 0.0
            weighted_conf = 0.0
            max_rank = 0

            for i, ev in enumerate(sorted_group):
                weight = 2.0 if i == 0 else 1.0
                conf = float(ev.get("confidence", 0.5))
                weighted_conf += weight * conf
                total_weight += weight

                rank = _LEVEL_RANK.get(ev.get("disclosure_level", "PUBLIC"), 0)
                if rank > max_rank:
                    max_rank = rank

            mean_conf = weighted_conf / total_weight if total_weight else 0.0
            result[concept] = {
                "mean_confidence": round(mean_conf, 6),
                "disclosure_level": _RANK_LEVEL[max_rank],
                "event_count": len(group),
            }
        return result


class ThetaStore:
    """
    Persistence layer for the coordination vector Θ.

    The on-disk format is a single JSON object at `.GCC/theta.json`:
    {
      "version": 1,
      "updated_at": "<ISO UTC>",
      "coordination_vector": {
        "<concept>": {
          "mean_confidence": 0.85,
          "disclosure_level": "PROTECTED",
          "event_count": 5,
          "last_updated": "<ISO UTC>"
        }
      }
    }
    """

    def __init__(self, gcc_dir: Path, aggregator: Optional[AggPhi] = None) -> None:
        self.gcc_dir = gcc_dir
        self.theta_path = gcc_dir / THETA_FILE
        self.aggregator: AggPhi = aggregator if aggregator is not None else RulesBasedAggPhi()

    # ------------------------------------------------------------------
    # Load / save
    # ------------------------------------------------------------------

    def load(self) -> dict:
        """Load the current Θ from disk; return a fresh structure if absent."""
        if not self.theta_path.exists():
            return {"version": 1, "updated_at": None, "coordination_vector": {}}
        try:
            return json.loads(self.theta_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {"version": 1, "updated_at": None, "coordination_vector": {}}

    def save(self, theta: dict) -> None:
        self.gcc_dir.mkdir(parents=True, exist_ok=True)
        self.theta_path.write_text(
            json.dumps(theta, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

    # ------------------------------------------------------------------
    # Ripple propagation
    # ------------------------------------------------------------------

    def ripple(self, events: List[dict]) -> dict:
        """
        Aggregate *events* via Aggφ and merge the delta into the stored Θ.

        Merge rules per concept:
        - confidence: weighted blend of existing + new (weighted by event counts).
        - disclosure_level: escalate to the maximum of existing and incoming.
        - event_count: cumulative sum.

        Returns the updated Θ dict.
        """
        delta = self.aggregator.aggregate(events)
        theta = self.load()
        cv: dict = theta.setdefault("coordination_vector", {})
        now = _dt.datetime.now(tz=_dt.timezone.utc).isoformat()

        for concept, entry in delta.items():
            existing = cv.get(concept, {})
            old_count = int(existing.get("event_count", 0))
            new_count = int(entry["event_count"])
            total = old_count + new_count

            if total:
                old_conf = float(existing.get("mean_confidence", entry["mean_confidence"]))
                new_conf = float(entry["mean_confidence"])
                blended = (old_conf * old_count + new_conf * new_count) / total
            else:
                blended = float(entry["mean_confidence"])

            existing_rank = _LEVEL_RANK.get(existing.get("disclosure_level", "PUBLIC"), 0)
            new_rank = _LEVEL_RANK.get(entry["disclosure_level"], 0)
            merged_level = _RANK_LEVEL[max(existing_rank, new_rank)]

            cv[concept] = {
                "mean_confidence": round(blended, 6),
                "disclosure_level": merged_level,
                "event_count": total,
                "last_updated": now,
            }

        theta["updated_at"] = now
        self.save(theta)

        # S8: near-duplicate concept pairs for I3 handshake (Textual Mode Aggφ only)
        if getattr(self.aggregator, "records_i3_merge_candidates", False):
            try:
                from .aggphi_textual import merge_i3_records, near_duplicate_pairs

                thr = float(getattr(self.aggregator, "similarity_threshold", 0.82))
                theta = self.load()
                cv_keys = list(theta.setdefault("coordination_vector", {}).keys())
                pairs = near_duplicate_pairs(cv_keys, threshold=thr)
                if pairs:
                    prev = theta.get("pending_i3_merges")
                    if not isinstance(prev, list):
                        prev = []
                    theta["pending_i3_merges"] = merge_i3_records(prev, pairs)
                    self.save(theta)
            except Exception:
                pass

        return self.load()


def make_theta_store(gcc_dir: Path) -> ThetaStore:
    """
    Construct a :class:`ThetaStore` for *gcc_dir*, respecting ``DEVTORCH_AGGPHI``:

    - ``rules`` (default): :class:`RulesBasedAggPhi`
    - ``textual`` / ``s8`` / ``text``: :class:`TextualModeAggPhi` (Sprint 8)
    """
    mode = os.environ.get("DEVTORCH_AGGPHI", "rules").strip().lower()
    if mode in ("textual", "s8", "text"):
        try:
            from .aggphi_textual import TextualModeAggPhi

            return ThetaStore(gcc_dir, aggregator=TextualModeAggPhi())
        except Exception:
            return ThetaStore(gcc_dir)
    return ThetaStore(gcc_dir)
