"""
Markdown and JSON rendering for ObservabilityReport.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from .report import ObservabilityReport, report_to_dict

if TYPE_CHECKING:
    pass


def format_report_markdown(report: ObservabilityReport) -> str:
    """
    Render an ObservabilityReport as a Markdown string.

    Sections:
      # DevTorch Governance Report
      ## Summary
      ## Coordination Vector (Top 5 Θ)
      ## Capability & Variance
      ## Privacy Budget (RDP)
    """
    lines: list[str] = []

    # ---------- Header ----------
    lines.append("# DevTorch Governance Report")
    lines.append(
        f"Generated: {report.generated_at} | "
        f"Branch: {report.branch} | "
        f"State: {report.node_state.upper()}"
    )
    lines.append("")

    # ---------- Summary table ----------
    lines.append("## Summary")
    lines.append("")
    lines.append("| Metric | Value |")
    lines.append("|--------|-------|")
    lines.append(f"| Commits | {report.commit_count} |")
    lines.append(f"| Sensitivity Events | {report.sensitivity_event_count} |")
    lines.append(f"| High Disclosure | {report.high_disclosure_count} |")
    lines.append(f"| Branches | {report.branch_count} |")
    lines.append(f"| SIS Quarantines | {report.sis_quarantine_count} |")
    lines.append(f"| GCC Version | {report.gcc_version} |")
    lines.append("")

    # ---------- Period ----------
    if report.period is not None:
        lines.append(f"**Period:** {report.period.period_label}")
        if report.period.start:
            lines.append(f"  From: {report.period.start}")
        if report.period.end:
            lines.append(f"  To: {report.period.end}")
        lines.append("")

    # ---------- Theta (Coordination Vector) ----------
    lines.append("## Coordination Vector (Top 5 Θ)")
    lines.append("")
    if report.theta_top_concepts:
        lines.append("| Concept | Confidence |")
        lines.append("|---------|------------|")
        for entry in report.theta_top_concepts:
            concept = entry.get("concept", "")
            conf = entry.get("mean_confidence", 0.0)
            lines.append(f"| {concept} | {conf:.4f} |")
    else:
        lines.append("_No coordination vector data available._")
    lines.append("")

    # ---------- Capability & Variance ----------
    lines.append("## Capability & Variance")
    lines.append("")

    cap = report.capability_state
    textual_allowed = cap.get("textual_mode_allowed", False)
    lipschitz = cap.get("lipschitz_bound")
    lipschitz_str = f"{lipschitz:.4f}" if lipschitz is not None else "N/A"
    lines.append(f"- **Textual Mode Allowed:** {'Yes' if textual_allowed else 'No'}")
    lines.append(f"- **Lipschitz Bound (L̂):** {lipschitz_str}")
    lines.append("")

    var = report.variance_state
    f_max_val = var.get("f_max")
    f_max_str = str(f_max_val) if f_max_val is not None else "N/A"
    det_mode = var.get("deterministic_mode", False)
    alert_count = var.get("alert_count", 0)
    lines.append(f"- **f_max:** {f_max_str}")
    lines.append(f"- **Variance Alert Count:** {alert_count}")
    lines.append(f"- **Deterministic Mode:** {'Yes' if det_mode else 'No'}")
    lines.append("")

    # ---------- Privacy Budget (RDP) ----------
    lines.append("## Privacy Budget (RDP)")
    lines.append("")
    rdp = report.rdp_budget
    eps_used = float(rdp.get("epsilon_used", 0.0))
    eps_max = float(rdp.get("epsilon_max", 1.0))
    read_only = bool(rdp.get("read_only", False))

    if eps_max > 0:
        pct = (eps_used / eps_max) * 100.0
        pct_str = f"{pct:.1f}%"
    else:
        pct_str = "N/A"

    lines.append(f"ε used: {eps_used:.4f} / {eps_max:.4f} ({pct_str})")
    lines.append(f"- **Read-only mode:** {'Yes' if read_only else 'No'}")
    lines.append("")

    return "\n".join(lines)


def format_report_json(report: ObservabilityReport) -> str:
    """Render an ObservabilityReport as a formatted JSON string."""
    return json.dumps(report_to_dict(report), indent=2)
