"""
Structured observability report builder.

Reads all .GCC/ state and produces a machine-readable + human-readable
governance snapshot. Never reads prompts, code content, or raw LLM responses.
Only reads governance metadata: commits, sensitivities (counts), theta,
capabilities, variance state, RDP budget, branch refs.
"""

from __future__ import annotations

import dataclasses
import datetime as _dt
import json
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class ReportTimeRange:
    """Optional time window for filtering report data."""
    start: str  # ISO timestamp or ""
    end: str    # ISO timestamp or ""
    period_label: str  # e.g. "last 7 days"


@dataclasses.dataclass
class ObservabilityReport:
    """Full governance snapshot built from .GCC/ metadata only."""
    generated_at: str
    gcc_version: str
    node_state: str
    branch: str
    commit_count: int
    sensitivity_event_count: int
    high_disclosure_count: int
    theta_top_concepts: List[Dict[str, Any]]  # [{concept: str, mean_confidence: float}]
    capability_state: Dict[str, Any]          # {textual_mode_allowed: bool, lipschitz_bound: float | None}
    variance_state: Dict[str, Any]            # {f_max: float | None, alert_count: int, deterministic_mode: bool}
    rdp_budget: Dict[str, Any]               # {epsilon_used: float, epsilon_max: float, read_only: bool}
    branch_count: int
    sis_quarantine_count: int
    period: Optional[ReportTimeRange] = None


# ---------------------------------------------------------------------------
# Report builder
# ---------------------------------------------------------------------------

def build_report(gcc_repo: Any, period: Optional[ReportTimeRange] = None) -> ObservabilityReport:
    """
    Build an ObservabilityReport from a GCCRepository instance.

    Each section is guarded by try/except so a broken or missing sub-store
    never prevents the rest of the report from being generated.

    Never reads: prompt content, commit message bodies, code, sensitivity
    signal text, or any raw LLM response content.
    """
    generated_at = _dt.datetime.now(tz=_dt.timezone.utc).isoformat()

    # --- gcc_version ---
    try:
        version_path = gcc_repo.gcc_dir / "VERSION"
        gcc_version = version_path.read_text(encoding="utf-8").strip() if version_path.exists() else ""
    except Exception:
        gcc_version = ""

    # --- node_state ---
    try:
        ns_path = gcc_repo.gcc_dir / "NODE_STATE"
        if ns_path.exists():
            ns_data = json.loads(ns_path.read_text(encoding="utf-8"))
            node_state = str(ns_data.get("mode", "unknown"))
        else:
            node_state = "unknown"
    except Exception:
        node_state = "unknown"

    # --- current branch ---
    try:
        head_path = gcc_repo.gcc_dir / "refs" / "HEAD"
        branch = head_path.read_text(encoding="utf-8").strip() if head_path.exists() else "unknown"
    except Exception:
        branch = "unknown"

    # --- commit_count ---
    try:
        commits_dir = gcc_repo.gcc_dir / "commits"
        if commits_dir.exists():
            commit_count = len(list(commits_dir.glob("*.json")))
        else:
            commit_count = 0
    except Exception:
        commit_count = 0

    # --- sensitivity counts (metadata only — no signal text) ---
    sensitivity_event_count = 0
    high_disclosure_count = 0
    try:
        sens_path = gcc_repo.gcc_dir / "sensitivities" / "events.jsonl"
        if sens_path.exists():
            with sens_path.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        ev = json.loads(line)
                        sensitivity_event_count += 1
                        if ev.get("disclosure_level") == "PRIVATE":
                            high_disclosure_count += 1
                    except (json.JSONDecodeError, KeyError):
                        continue
    except Exception:
        pass

    # --- theta top concepts (metadata only — no content) ---
    theta_top_concepts: List[Dict[str, Any]] = []
    try:
        theta_path = gcc_repo.gcc_dir / "theta.json"
        if theta_path.exists():
            theta_data = json.loads(theta_path.read_text(encoding="utf-8"))
            cv: dict = theta_data.get("coordination_vector", {})
            # Sort by mean_confidence descending, take top 5
            sorted_concepts = sorted(
                cv.items(),
                key=lambda kv: float(kv[1].get("mean_confidence", 0.0)),
                reverse=True,
            )
            for concept, entry in sorted_concepts[:5]:
                theta_top_concepts.append({
                    "concept": str(concept),
                    "mean_confidence": float(entry.get("mean_confidence", 0.0)),
                })
    except Exception:
        pass

    # --- capability_state (A1 gate metadata — no calibration data body) ---
    capability_state: Dict[str, Any] = {"textual_mode_allowed": False, "lipschitz_bound": None}
    try:
        omega_path = gcc_repo.gcc_dir / "capabilities" / "omega.json"
        if omega_path.exists():
            omega_data = json.loads(omega_path.read_text(encoding="utf-8"))
            schema = omega_data.get("schema", "")
            if schema == "omega-v2.1":
                capability_state = {
                    "textual_mode_allowed": bool(omega_data.get("pst_status") == "passed"),
                    "lipschitz_bound": omega_data.get("lipschitz_bound"),
                }
            # else: stub format — leave defaults
    except Exception:
        pass

    # --- variance_state ---
    variance_state: Dict[str, Any] = {"f_max": None, "alert_count": 0, "deterministic_mode": False}
    try:
        live_path = gcc_repo.gcc_dir / "variance" / "live_state.json"
        if live_path.exists():
            live_data = json.loads(live_path.read_text(encoding="utf-8"))
            variance_state = {
                "f_max": live_data.get("last_f_max"),
                "alert_count": _count_events_of_type(gcc_repo.gcc_dir, "VARIANCE_ALERT"),
                "deterministic_mode": bool(live_data.get("deterministic_mode_forced", False)),
            }
        else:
            variance_state["alert_count"] = _count_events_of_type(gcc_repo.gcc_dir, "VARIANCE_ALERT")
    except Exception:
        pass

    # --- rdp_budget ---
    rdp_budget: Dict[str, Any] = {"epsilon_used": 0.0, "epsilon_max": 1.0, "read_only": False}
    try:
        rdp_path = gcc_repo.gcc_dir / "rdp" / "rdp_state.json"
        if rdp_path.exists():
            rdp_data = json.loads(rdp_path.read_text(encoding="utf-8"))
            rdp_budget = {
                "epsilon_used": float(rdp_data.get("epsilon_spent", 0.0)),
                "epsilon_max": float(rdp_data.get("epsilon_budget", 1.0)),
                "read_only": bool(rdp_data.get("read_only", False)),
            }
    except Exception:
        pass

    # --- branch_count ---
    try:
        branches_dir = gcc_repo.gcc_dir / "refs" / "branches"
        if branches_dir.exists():
            branch_count = len([f for f in branches_dir.iterdir() if f.is_file()])
        else:
            branch_count = 0
    except Exception:
        branch_count = 0

    # --- sis_quarantine_count ---
    sis_quarantine_count = 0
    try:
        q_path = gcc_repo.gcc_dir / "sis" / "quarantine_events.jsonl"
        if q_path.exists():
            with q_path.open("r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        sis_quarantine_count += 1
    except Exception:
        pass

    return ObservabilityReport(
        generated_at=generated_at,
        gcc_version=gcc_version,
        node_state=node_state,
        branch=branch,
        commit_count=commit_count,
        sensitivity_event_count=sensitivity_event_count,
        high_disclosure_count=high_disclosure_count,
        theta_top_concepts=theta_top_concepts,
        capability_state=capability_state,
        variance_state=variance_state,
        rdp_budget=rdp_budget,
        branch_count=branch_count,
        sis_quarantine_count=sis_quarantine_count,
        period=period,
    )


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------

def report_to_dict(report: ObservabilityReport) -> dict:
    """Convert ObservabilityReport to a JSON-serializable dict."""
    d = dataclasses.asdict(report)
    # period is a nested dataclass — already handled by asdict; may be None
    return d


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _count_events_of_type(gcc_dir: Path, event_type: str) -> int:
    """Count events of a specific type in the event log. Metadata only."""
    count = 0
    try:
        event_log = gcc_dir / "events.log.jsonl"
        if not event_log.exists():
            return 0
        with event_log.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if obj.get("event_type") == event_type:
                        count += 1
                except json.JSONDecodeError:
                    continue
    except Exception:
        pass
    return count
