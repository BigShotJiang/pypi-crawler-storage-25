"""
Enterprise metrics webhook sender.

Sends a METRICS-ONLY payload to a configured endpoint.
NEVER includes: prompts, code, reasoning tokens, commit message bodies,
sensitivity signal text, or any LLM response content.

Only sends: counts, scores, timestamps, branch names, node state.
"""

from __future__ import annotations

import dataclasses
import json
import os
import urllib.request
import urllib.error
from typing import Optional

from .report import ObservabilityReport


# ---------------------------------------------------------------------------
# Approved metric keys sent in the webhook payload (explicit allowlist)
# ---------------------------------------------------------------------------

_PAYLOAD_KEYS = frozenset({
    "org_id",
    "node_state",
    "branch",
    "commit_count",
    "sensitivity_count",
    "high_disclosure_count",
    "dhs_score",
    "mcs_score",
    "rdp_epsilon_used",
    "rdp_exhausted",
    "variance_alert_count",
    "generated_at",
})


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class WebhookConfig:
    """Configuration for the enterprise metrics webhook."""
    endpoint_url: str   # DEVTORCH_METRICS_WEBHOOK_URL
    org_id: str         # DEVTORCH_ORG_ID
    api_key: str        # DEVTORCH_METRICS_API_KEY
    timeout_seconds: int = 10


@dataclasses.dataclass
class WebhookPayload:
    """
    Metrics-only payload sent to the webhook endpoint.

    Explicit field list — every field is named here, nothing else.
    Contains: counts, scores, timestamps, branch name, node state only.
    """
    org_id: str
    node_state: str
    branch: str
    commit_count: int
    sensitivity_count: int
    high_disclosure_count: int
    dhs_score: Optional[float]
    mcs_score: Optional[float]
    rdp_epsilon_used: float
    rdp_exhausted: bool
    variance_alert_count: int
    generated_at: str


@dataclasses.dataclass
class WebhookResult:
    """Result of a webhook POST attempt."""
    success: bool
    status_code: int
    error: str


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------

def load_webhook_config() -> Optional[WebhookConfig]:
    """
    Load webhook configuration from environment variables.

    Returns None if DEVTORCH_METRICS_WEBHOOK_URL is not set.
    Never raises.
    """
    try:
        endpoint_url = os.environ.get("DEVTORCH_METRICS_WEBHOOK_URL", "").strip()
        if not endpoint_url:
            return None
        org_id = os.environ.get("DEVTORCH_ORG_ID", "").strip()
        api_key = os.environ.get("DEVTORCH_METRICS_API_KEY", "").strip()
        timeout_str = os.environ.get("DEVTORCH_METRICS_TIMEOUT_SECONDS", "10").strip()
        try:
            timeout_seconds = int(timeout_str)
        except (ValueError, TypeError):
            timeout_seconds = 10
        return WebhookConfig(
            endpoint_url=endpoint_url,
            org_id=org_id,
            api_key=api_key,
            timeout_seconds=timeout_seconds,
        )
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Payload builder
# ---------------------------------------------------------------------------

def build_webhook_payload(report: ObservabilityReport, org_id: str) -> WebhookPayload:
    """
    Map ObservabilityReport fields to a WebhookPayload.

    Explicit field mapping: every included field is named here, nothing else.
    Intentionally omits: prompts, commit messages, sensitivity signal text,
    theta concept names beyond counts, code, or any LLM output.
    """
    rdp = report.rdp_budget
    rdp_epsilon_used = float(rdp.get("epsilon_used", 0.0))
    rdp_epsilon_max = float(rdp.get("epsilon_max", 1.0))
    rdp_exhausted = bool(rdp.get("read_only", False))

    variance = report.variance_state
    variance_alert_count = int(variance.get("alert_count", 0))

    return WebhookPayload(
        org_id=org_id,
        node_state=report.node_state,
        branch=report.branch,
        commit_count=report.commit_count,
        sensitivity_count=report.sensitivity_event_count,
        high_disclosure_count=report.high_disclosure_count,
        dhs_score=None,   # not computed here; callers may populate via separate DHS call
        mcs_score=None,   # not computed here; callers may populate via separate MCS call
        rdp_epsilon_used=rdp_epsilon_used,
        rdp_exhausted=rdp_exhausted,
        variance_alert_count=variance_alert_count,
        generated_at=report.generated_at,
    )


# ---------------------------------------------------------------------------
# Webhook sender
# ---------------------------------------------------------------------------

def send_webhook(payload: WebhookPayload, config: WebhookConfig) -> WebhookResult:
    """
    POST the metrics payload to config.endpoint_url.

    Uses urllib.request — no external dependencies.
    Never raises — returns WebhookResult with success=False on any error.

    Headers sent:
      Authorization: Bearer {api_key}
      Content-Type: application/json
      X-DevTorch-Org: {org_id}
    """
    try:
        body_dict = {
            "org_id": payload.org_id,
            "node_state": payload.node_state,
            "branch": payload.branch,
            "commit_count": payload.commit_count,
            "sensitivity_count": payload.sensitivity_count,
            "high_disclosure_count": payload.high_disclosure_count,
            "dhs_score": payload.dhs_score,
            "mcs_score": payload.mcs_score,
            "rdp_epsilon_used": payload.rdp_epsilon_used,
            "rdp_exhausted": payload.rdp_exhausted,
            "variance_alert_count": payload.variance_alert_count,
            "generated_at": payload.generated_at,
        }
        body_bytes = json.dumps(body_dict).encode("utf-8")

        req = urllib.request.Request(
            url=config.endpoint_url,
            data=body_bytes,
            method="POST",
            headers={
                "Authorization": f"Bearer {config.api_key}",
                "Content-Type": "application/json",
                "X-DevTorch-Org": config.org_id,
            },
        )

        with urllib.request.urlopen(req, timeout=config.timeout_seconds) as resp:
            status_code = resp.status
            return WebhookResult(success=True, status_code=status_code, error="")

    except urllib.error.HTTPError as exc:
        return WebhookResult(success=False, status_code=exc.code, error=str(exc))
    except urllib.error.URLError as exc:
        return WebhookResult(success=False, status_code=0, error=str(exc))
    except Exception as exc:
        return WebhookResult(success=False, status_code=0, error=str(exc))


# ---------------------------------------------------------------------------
# Convenience helper
# ---------------------------------------------------------------------------

def send_metrics_if_configured(report: ObservabilityReport) -> Optional[WebhookResult]:
    """
    Load config from environment; if not configured return None.
    Otherwise build payload, send webhook, and return WebhookResult.
    Never raises.
    """
    try:
        config = load_webhook_config()
        if config is None:
            return None
        payload = build_webhook_payload(report, org_id=config.org_id)
        return send_webhook(payload, config)
    except Exception:
        return None
