"""
devtorch_core.observability — Structured governance reporting and enterprise metrics.

Public API:
  - ObservabilityReport, build_report        (report.py)
  - format_report_markdown, format_report_json  (formatter.py)
  - WebhookPayload, send_webhook, send_metrics_if_configured  (webhook.py)
"""

from .report import (
    ObservabilityReport,
    ReportTimeRange,
    build_report,
    report_to_dict,
)
from .formatter import (
    format_report_markdown,
    format_report_json,
)
from .webhook import (
    WebhookConfig,
    WebhookPayload,
    WebhookResult,
    load_webhook_config,
    build_webhook_payload,
    send_webhook,
    send_metrics_if_configured,
)

__all__ = [
    # report
    "ObservabilityReport",
    "ReportTimeRange",
    "build_report",
    "report_to_dict",
    # formatter
    "format_report_markdown",
    "format_report_json",
    # webhook
    "WebhookConfig",
    "WebhookPayload",
    "WebhookResult",
    "load_webhook_config",
    "build_webhook_payload",
    "send_webhook",
    "send_metrics_if_configured",
]
