"""
Sprint 5 – REP (Reasoning Exchange Protocol) envelope schema and local transport.

Message envelope: agent_id, round, trust, payload hashes. Optional signatures.
Local transport: file-based ledger with deterministic ordering for record/replay.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

REP_VERSION = "rep-v1"
REP_LEDGER_NAME = "rep_ledger.jsonl"
REP_DIR_NAME = "rep"


def _hash_payload(payload: Any) -> str:
    """SHA-256 hex digest of JSON-serialized payload."""
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()


@dataclass
class REPEnvelope:
    """REP message envelope for sensitivity exchange."""
    agent_id: str
    round_id: int
    trust: float  # [0, 1] optional trust score
    payload_hash: str
    payload_type: str = "sensitivity"  # sensitivity | control | ack
    payload_ref: Optional[str] = None  # optional pointer to full payload
    signature: Optional[str] = None  # optional crypto signature

    def to_dict(self) -> dict:
        d = {
            "version": REP_VERSION,
            "agent_id": self.agent_id,
            "round_id": self.round_id,
            "trust": self.trust,
            "payload_hash": self.payload_hash,
            "payload_type": self.payload_type,
        }
        if self.payload_ref is not None:
            d["payload_ref"] = self.payload_ref
        if self.signature is not None:
            d["signature"] = self.signature
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "REPEnvelope":
        return cls(
            agent_id=str(d["agent_id"]),
            round_id=int(d["round_id"]),
            trust=float(d.get("trust", 0.5)),
            payload_hash=str(d["payload_hash"]),
            payload_type=str(d.get("payload_type", "sensitivity")),
            payload_ref=d.get("payload_ref"),
            signature=d.get("signature"),
        )


class REPLedger:
    """
    Append-only REP ledger for local transport. Deterministic ordering by
    sequence id and timestamp for record/replay.
    """
    def __init__(self, gcc_dir: Path) -> None:
        self.rep_dir = gcc_dir / REP_DIR_NAME
        self.ledger_path = self.rep_dir / REP_LEDGER_NAME

    def ensure_dir(self) -> None:
        self.rep_dir.mkdir(parents=True, exist_ok=True)

    def append(self, envelope: REPEnvelope, timestamp: str, sequence_id: Optional[int] = None) -> int:
        """Append envelope to ledger; return sequence id (1-based)."""
        self.ensure_dir()
        if sequence_id is None:
            sequence_id = self._next_sequence_id()
        record = {
            "sequence_id": sequence_id,
            "timestamp": timestamp,
            "envelope": envelope.to_dict(),
        }
        with self.ledger_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, sort_keys=True) + "\n")
        return sequence_id

    def _next_sequence_id(self) -> int:
        if not self.ledger_path.exists():
            return 1
        last = 0
        with self.ledger_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    last = max(last, rec.get("sequence_id", 0))
                except json.JSONDecodeError:
                    continue
        return last + 1

    def read_all(self) -> List[dict]:
        """Read all records in deterministic order (sequence_id, timestamp)."""
        if not self.ledger_path.exists():
            return []
        records = []
        with self.ledger_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        records.sort(key=lambda r: (r.get("sequence_id", 0), r.get("timestamp", "")))
        return records

    def replay_checksum(self) -> str:
        """Deterministic checksum of ledger for replay verification."""
        records = self.read_all()
        content = json.dumps(records, sort_keys=True)
        return hashlib.sha256(content.encode("utf-8")).hexdigest()


def create_envelope(agent_id: str, round_id: int, payload: Any, trust: float = 0.5) -> REPEnvelope:
    """Build REP envelope from payload (hash stored; payload not stored in envelope)."""
    payload_hash = _hash_payload(payload)
    return REPEnvelope(agent_id=agent_id, round_id=round_id, trust=trust, payload_hash=payload_hash)
