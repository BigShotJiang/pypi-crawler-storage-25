import base64
import json
import urllib.request
import urllib.error

from .base import AlertChannel, AlertEnvelope, AlertSeverity, DeliveryResult


class JiraChannel(AlertChannel):
    channel_name = "jira"

    def __init__(self, url: str, project_key: str, api_token: str, email: str) -> None:
        self.url = url.rstrip("/")
        self.project_key = project_key
        self.api_token = api_token
        self.email = email

    def _build_issue_body(self, envelope: AlertEnvelope) -> dict:
        """Build Jira issue creation request body."""
        issue_type = "Bug" if envelope.severity == AlertSeverity.CRITICAL else "Task"
        summary = f"[DevTorch] {envelope.title}"

        # ADF (Atlassian Document Format) — plain text wrapped in doc node
        description_adf = {
            "version": 1,
            "type": "doc",
            "content": [
                {
                    "type": "paragraph",
                    "content": [
                        {
                            "type": "text",
                            "text": envelope.body,
                        }
                    ],
                },
                {
                    "type": "paragraph",
                    "content": [
                        {
                            "type": "text",
                            "text": f"Branch: {envelope.branch} | Commit: {envelope.commit_id} | Event: {envelope.event_type}",
                        }
                    ],
                },
            ],
        }

        return {
            "fields": {
                "project": {"key": self.project_key},
                "summary": summary,
                "description": description_adf,
                "issuetype": {"name": issue_type},
            }
        }

    def deliver(self, envelope: AlertEnvelope) -> DeliveryResult:
        """POST to Jira REST API v3. Basic auth with email:token."""
        try:
            body = self._build_issue_body(envelope)
            data = json.dumps(body).encode("utf-8")

            credentials = f"{self.email}:{self.api_token}"
            encoded = base64.b64encode(credentials.encode("utf-8")).decode("utf-8")

            api_url = f"{self.url}/rest/api/3/issue"
            req = urllib.request.Request(
                api_url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Basic {encoded}",
                    "Accept": "application/json",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return DeliveryResult(
                    channel=self.channel_name,
                    success=True,
                    response_code=resp.status,
                )
        except urllib.error.HTTPError as exc:
            return DeliveryResult(
                channel=self.channel_name,
                success=False,
                error=f"HTTP {exc.code}: {exc.reason}",
                response_code=exc.code,
            )
        except Exception as exc:
            return DeliveryResult(
                channel=self.channel_name,
                success=False,
                error=str(exc),
            )
