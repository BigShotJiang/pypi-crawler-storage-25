import json
import urllib.request
import urllib.error

from .base import AlertChannel, AlertEnvelope, AlertSeverity, DeliveryResult

_PD_SEVERITY_MAP = {
    AlertSeverity.CRITICAL: "critical",
    AlertSeverity.WARNING: "warning",
    AlertSeverity.INFO: "info",
}


class PagerDutyChannel(AlertChannel):
    channel_name = "pagerduty"
    EVENTS_API_URL = "https://events.pagerduty.com/v2/enqueue"

    def __init__(self, routing_key: str) -> None:
        self.routing_key = routing_key

    def _build_payload(self, envelope: AlertEnvelope) -> dict:
        """Build PagerDuty Events API v2 payload."""
        event_action = "trigger" if envelope.severity == AlertSeverity.CRITICAL else "acknowledge"
        pd_severity = _PD_SEVERITY_MAP.get(envelope.severity, "info")

        return {
            "routing_key": self.routing_key,
            "event_action": event_action,
            "payload": {
                "summary": envelope.title,
                "severity": pd_severity,
                "source": "devtorch",
                "custom_details": envelope.metadata,
            },
        }

    def deliver(self, envelope: AlertEnvelope) -> DeliveryResult:
        """POST to PagerDuty Events API. Never raises."""
        try:
            payload = self._build_payload(envelope)
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                self.EVENTS_API_URL,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return DeliveryResult(
                    channel=self.channel_name,
                    success=True,
                    response_code=resp.status,
                )
        except urllib.error.HTTPError as exc:
            return DeliveryResult(
                channel=self.channel_name,
                success=False,
                error=f"HTTP {exc.code}: {exc.reason}",
                response_code=exc.code,
            )
        except Exception as exc:
            return DeliveryResult(
                channel=self.channel_name,
                success=False,
                error=str(exc),
            )
