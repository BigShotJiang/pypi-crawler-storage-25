import json
import urllib.request
import urllib.error
from typing import Any

from .base import AlertChannel, AlertEnvelope, AlertSeverity, DeliveryResult

_SEVERITY_EMOJI = {
    AlertSeverity.CRITICAL: "🔴",
    AlertSeverity.WARNING: "🟡",
    AlertSeverity.INFO: "🔵",
}


class SlackChannel(AlertChannel):
    channel_name = "slack"

    def __init__(self, webhook_url: str) -> None:
        self.webhook_url = webhook_url

    def _build_payload(self, envelope: AlertEnvelope) -> dict:
        """Build Slack Block Kit payload."""
        emoji = _SEVERITY_EMOJI.get(envelope.severity, "🔵")
        blocks: list[dict[str, Any]] = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"{emoji} {envelope.severity.value.upper()}: {envelope.event_type}",
                    "emoji": True,
                },
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*{envelope.title}*\n{envelope.body}",
                },
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"Branch: `{envelope.branch}` | Commit: `{envelope.commit_id}`",
                    }
                ],
            },
        ]
        return {"blocks": blocks}

    def deliver(self, envelope: AlertEnvelope) -> DeliveryResult:
        """POST to Slack webhook. Uses urllib (no requests dependency)."""
        try:
            payload = self._build_payload(envelope)
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return DeliveryResult(
                    channel=self.channel_name,
                    success=True,
                    response_code=resp.status,
                )
        except urllib.error.HTTPError as exc:
            return DeliveryResult(
                channel=self.channel_name,
                success=False,
                error=f"HTTP {exc.code}: {exc.reason}",
                response_code=exc.code,
            )
        except Exception as exc:
            return DeliveryResult(
                channel=self.channel_name,
                success=False,
                error=str(exc),
            )
