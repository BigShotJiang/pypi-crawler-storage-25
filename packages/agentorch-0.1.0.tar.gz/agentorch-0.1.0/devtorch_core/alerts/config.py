import os
from dataclasses import dataclass

from .base import AlertSeverity


@dataclass
class AlertConfig:
    slack_webhook_url: str = ""         # DEVTORCH_SLACK_WEBHOOK_URL
    jira_url: str = ""                  # DEVTORCH_JIRA_URL
    jira_project_key: str = ""          # DEVTORCH_JIRA_PROJECT_KEY
    jira_api_token: str = ""            # DEVTORCH_JIRA_API_TOKEN
    jira_email: str = ""                # DEVTORCH_JIRA_EMAIL
    pagerduty_routing_key: str = ""     # DEVTORCH_PAGERDUTY_ROUTING_KEY
    min_severity: AlertSeverity = AlertSeverity.WARNING  # DEVTORCH_ALERT_MIN_SEVERITY


def load_config() -> AlertConfig:
    """Load from environment variables. Never raises."""
    try:
        raw_severity = os.environ.get("DEVTORCH_ALERT_MIN_SEVERITY", "warning").lower()
        severity_map = {
            "info": AlertSeverity.INFO,
            "warning": AlertSeverity.WARNING,
            "critical": AlertSeverity.CRITICAL,
        }
        min_severity = severity_map.get(raw_severity, AlertSeverity.WARNING)

        return AlertConfig(
            slack_webhook_url=os.environ.get("DEVTORCH_SLACK_WEBHOOK_URL", ""),
            jira_url=os.environ.get("DEVTORCH_JIRA_URL", ""),
            jira_project_key=os.environ.get("DEVTORCH_JIRA_PROJECT_KEY", ""),
            jira_api_token=os.environ.get("DEVTORCH_JIRA_API_TOKEN", ""),
            jira_email=os.environ.get("DEVTORCH_JIRA_EMAIL", ""),
            pagerduty_routing_key=os.environ.get("DEVTORCH_PAGERDUTY_ROUTING_KEY", ""),
            min_severity=min_severity,
        )
    except Exception:
        return AlertConfig()


def is_channel_configured(config: AlertConfig, channel: str) -> bool:
    """Returns True if the channel has enough config to attempt delivery."""
    if channel == "slack":
        return bool(config.slack_webhook_url)
    if channel == "jira":
        return bool(config.jira_url and config.jira_project_key and config.jira_api_token)
    if channel == "pagerduty":
        return bool(config.pagerduty_routing_key)
    return False
