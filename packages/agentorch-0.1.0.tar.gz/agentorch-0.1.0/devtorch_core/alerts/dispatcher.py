from __future__ import annotations

from .base import AlertChannel, AlertEnvelope, AlertSeverity, DeliveryResult, event_to_severity
from .config import AlertConfig, load_config
from .jira import JiraChannel
from .pagerduty import PagerDutyChannel
from .slack import SlackChannel

# Severity ordering for threshold filtering
_SEVERITY_ORDER = {
    AlertSeverity.INFO: 0,
    AlertSeverity.WARNING: 1,
    AlertSeverity.CRITICAL: 2,
}


def build_channels(config: AlertConfig) -> list[AlertChannel]:
    """Build the list of configured channels from config."""
    channels: list[AlertChannel] = []
    if config.slack_webhook_url:
        channels.append(SlackChannel(config.slack_webhook_url))
    if config.jira_url and config.jira_project_key and config.jira_api_token:
        channels.append(
            JiraChannel(
                url=config.jira_url,
                project_key=config.jira_project_key,
                api_token=config.jira_api_token,
                email=config.jira_email,
            )
        )
    if config.pagerduty_routing_key:
        channels.append(PagerDutyChannel(config.pagerduty_routing_key))
    return channels


def dispatch_alert(
    envelope: AlertEnvelope,
    config: AlertConfig | None = None,
) -> list[DeliveryResult]:
    """
    Route an alert envelope to all configured channels.
    Filters by min_severity. Returns delivery results for all channels.
    Never raises.
    """
    try:
        if config is None:
            config = load_config()

        # Filter: skip if envelope severity is below the configured minimum
        if _SEVERITY_ORDER.get(envelope.severity, 0) < _SEVERITY_ORDER.get(config.min_severity, 0):
            return []

        channels = build_channels(config)
        results: list[DeliveryResult] = []
        for channel in channels:
            try:
                result = channel.deliver(envelope)
                results.append(result)
            except Exception as exc:
                results.append(
                    DeliveryResult(
                        channel=channel.channel_name,
                        success=False,
                        error=str(exc),
                    )
                )
        return results
    except Exception:
        return []


def dispatch_from_event(
    event_type: str,
    branch: str,
    commit_id: str,
    metadata: dict | None = None,
    config: AlertConfig | None = None,
) -> list[DeliveryResult]:
    """
    Convenience function: build an AlertEnvelope from a GCC event type
    and dispatch to all channels. Returns [] if no channels configured.
    """
    try:
        if config is None:
            config = load_config()

        severity = event_to_severity(event_type)
        title = f"{event_type} on {branch}"
        body = (
            f"DevTorch governance event `{event_type}` was triggered on branch `{branch}` "
            f"at commit `{commit_id}`."
        )
        envelope = AlertEnvelope(
            event_type=event_type,
            severity=severity,
            title=title,
            body=body,
            branch=branch,
            commit_id=commit_id,
            metadata=metadata or {},
        )
        return dispatch_alert(envelope, config=config)
    except Exception:
        return []
