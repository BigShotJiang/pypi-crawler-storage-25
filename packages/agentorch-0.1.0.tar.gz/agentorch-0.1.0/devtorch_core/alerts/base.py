from dataclasses import dataclass, field
from enum import Enum


class AlertSeverity(Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class AlertEnvelope:
    event_type: str          # e.g. "VARIANCE_ALERT"
    severity: AlertSeverity
    title: str
    body: str                # markdown-safe text
    branch: str
    commit_id: str
    metadata: dict = field(default_factory=dict)


@dataclass
class DeliveryResult:
    channel: str             # "slack", "jira", "pagerduty"
    success: bool
    error: str = ""
    response_code: int = 0


class AlertChannel:
    """Base class for alert channels."""
    channel_name: str = "base"

    def deliver(self, envelope: AlertEnvelope) -> DeliveryResult:
        raise NotImplementedError


def event_to_severity(event_type: str) -> AlertSeverity:
    """Map GCC event types to alert severity."""
    critical = {"PRIVACY_BUDGET_EXHAUSTED", "CAPABILITY_DEGRADED"}
    warning = {"VARIANCE_ALERT", "CONSENSUS_LOCKED"}
    if event_type in critical:
        return AlertSeverity.CRITICAL
    elif event_type in warning:
        return AlertSeverity.WARNING
    return AlertSeverity.INFO
