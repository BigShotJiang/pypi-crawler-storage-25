"""
Sprint 5 – SIS (Sensitivity Inference Safety) A3: corpus format, evaluation harness, quarantine decision tree.

SIS-TC: Test corpus format (prompt, label_safe), loader, ROC/FPR/FNR evaluation.
Quarantine: deterministic decision tree (drop, log, rep_penalty, abstain, exclude after 3 consecutive).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional

SIS_TC_CORPUS_NAME = "sis_tc_corpus.jsonl"
SIS_TC_REPORT_NAME = "sis_tc_report.json"
SIS_QUARANTINE_LOG_NAME = "quarantine_events.jsonl"
SIS_DIR_NAME = "sis"
QUARANTINE_EVENT_TYPE = "QUARANTINE"

# Decision outcomes
OUTCOME_DROP = "drop"
OUTCOME_LOG = "log"
OUTCOME_REP_PENALTY = "rep_penalty"
OUTCOME_ABSTAIN = "abstain"  # insufficient valid peers
OUTCOME_EXCLUDE = "exclude"  # 3 consecutive quarantines for same agent


@dataclass
class SISTCCorpusEntry:
    """Single SIS-TC corpus entry."""
    prompt_id: str
    prompt_text: str
    label_safe: bool  # True = safe, False = unsafe
    metadata: Optional[dict] = None

    def to_dict(self) -> dict:
        d = {"prompt_id": self.prompt_id, "prompt_text": self.prompt_text, "label_safe": self.label_safe}
        if self.metadata:
            d["metadata"] = self.metadata
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "SISTCCorpusEntry":
        return cls(
            prompt_id=str(d["prompt_id"]),
            prompt_text=str(d["prompt_text"]),
            label_safe=bool(d["label_safe"]),
            metadata=d.get("metadata"),
        )


def load_sis_tc_corpus(path: Path) -> List[SISTCCorpusEntry]:
    """Load SIS-TC corpus from JSONL (one JSON object per line)."""
    if not path.exists():
        return []
    entries = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(SISTCCorpusEntry.from_dict(json.loads(line)))
            except (json.JSONDecodeError, KeyError):
                continue
    return entries


@dataclass
class SISTCReport:
    """SIS-TC evaluation report: counts, FPR, FNR, chosen threshold."""
    n_total: int
    n_safe: int
    n_unsafe: int
    tp: int
    tn: int
    fp: int
    fn: int
    fpr: float
    fnr: float
    threshold_used: float
    operating_point: Optional[dict] = None  # e.g. {"fpr_target": 0.01, "fnr_target": 0.05}

    def to_dict(self) -> dict:
        return {
            "n_total": self.n_total,
            "n_safe": self.n_safe,
            "n_unsafe": self.n_unsafe,
            "tp": self.tp, "tn": self.tn, "fp": self.fp, "fn": self.fn,
            "fpr": self.fpr, "fnr": self.fnr,
            "threshold_used": self.threshold_used,
            "operating_point": self.operating_point,
        }


def run_sis_tc_eval(
    corpus: List[SISTCCorpusEntry],
    classifier_fn: Optional[Callable[[str], float]] = None,
    threshold: float = 0.5,
) -> SISTCReport:
    """
    Run SIS-TC evaluation. classifier_fn(prompt_text) -> float score in [0,1] (higher = safer).
    If classifier_fn is None, use placeholder: label_safe -> 1.0, else 0.0 (perfect prediction).
    """
    n_safe = sum(1 for e in corpus if e.label_safe)
    n_unsafe = len(corpus) - n_safe
    if classifier_fn is None:
        scores = [1.0 if e.label_safe else 0.0 for e in corpus]  # placeholder: perfect prediction
    else:
        scores = [classifier_fn(e.prompt_text) for e in corpus]
    tp = tn = fp = fn = 0
    for e, s in zip(corpus, scores):
        pred_safe = s >= threshold
        if e.label_safe and pred_safe:
            tp += 1
        elif e.label_safe and not pred_safe:
            fn += 1
        elif not e.label_safe and pred_safe:
            fp += 1
        else:
            tn += 1
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    return SISTCReport(
        n_total=len(corpus),
        n_safe=n_safe,
        n_unsafe=n_unsafe,
        tp=tp, tn=tn, fp=fp, fn=fn,
        fpr=fpr, fnr=fnr,
        threshold_used=threshold,
    )


@dataclass
class QuarantineDecision:
    """Result of quarantine decision tree."""
    outcome: str  # drop, log, rep_penalty, abstain, exclude
    reason: str
    agent_id: Optional[str] = None
    consecutive_count: Optional[int] = None


def quarantine_decision_tree(
    agent_id: str,
    payload_quarantined: bool,
    valid_peer_count: int,
    min_peers_required: int,
    agent_consecutive_quarantines: int,
    exclude_after_n_consecutive: int = 3,
) -> QuarantineDecision:
    """
    Deterministic SIS quarantine decision tree.
    - If insufficient valid peers -> abstain.
    - If agent has >= exclude_after_n_consecutive consecutive quarantines -> exclude.
    - Else if payload quarantined -> rep_penalty (and log). Otherwise no quarantine (drop = do not forward; log = log only).
    """
    if valid_peer_count < min_peers_required:
        return QuarantineDecision(OUTCOME_ABSTAIN, "Insufficient valid peers", agent_id=agent_id)
    if agent_consecutive_quarantines >= exclude_after_n_consecutive:
        return QuarantineDecision(
            OUTCOME_EXCLUDE,
            f"Agent {agent_id} exceeded {exclude_after_n_consecutive} consecutive quarantines",
            agent_id=agent_id,
            consecutive_count=agent_consecutive_quarantines,
        )
    if payload_quarantined:
        return QuarantineDecision(
            OUTCOME_REP_PENALTY,
            "Payload quarantined by classifier",
            agent_id=agent_id,
        )
    return QuarantineDecision(OUTCOME_LOG, "Logged only", agent_id=agent_id)


class QuarantineEventStore:
    """Persist QUARANTINE events for audit (append-only JSONL)."""
    def __init__(self, gcc_dir: Path) -> None:
        self.sis_dir = gcc_dir / SIS_DIR_NAME
        self.log_path = self.sis_dir / SIS_QUARANTINE_LOG_NAME

    def ensure_dir(self) -> None:
        self.sis_dir.mkdir(parents=True, exist_ok=True)

    def append(self, decision: QuarantineDecision, timestamp: str, round_id: Optional[int] = None) -> None:
        record = {
            "event_type": QUARANTINE_EVENT_TYPE,
            "timestamp": timestamp,
            "outcome": decision.outcome,
            "reason": decision.reason,
            "agent_id": decision.agent_id,
            "consecutive_count": decision.consecutive_count,
            "round_id": round_id,
        }
        self.ensure_dir()
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, sort_keys=True) + "\n")
