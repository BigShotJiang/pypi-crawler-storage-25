"""
Claude Code hook runner — `devtorch hooks run {pre-tool-use,post-tool-use,session-end}`.

Claude Code passes a JSON payload on stdin. The hook must always exit 0
(approve); non-zero blocks Claude. All errors are swallowed.

Event types written to .GCC/events.log.jsonl:
  PRE_TOOL_USE   — before every tool call
  POST_TOOL_USE  — after every tool call
  SESSION_END    — when Claude Code stops
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# .GCC/ repo discovery
# ---------------------------------------------------------------------------


def _find_repo() -> Optional[object]:
    """Walk upward from cwd to find an initialised .GCC/ repo."""
    from devtorch_core import GCCRepository

    for parent in [Path.cwd()] + list(Path.cwd().parents):
        r = GCCRepository.at(parent)
        if r.is_initialized():
            return r
    return None


# ---------------------------------------------------------------------------
# Stdin reader
# ---------------------------------------------------------------------------


def _read_stdin_json() -> dict:
    try:
        raw = sys.stdin.read()
        if raw.strip():
            return json.loads(raw)
    except Exception:
        pass
    return {}


# ---------------------------------------------------------------------------
# Event appenders
# ---------------------------------------------------------------------------


def _append_event(repo, event_type: str, payload: dict) -> None:
    """Append a raw event to the repo's event log."""
    try:
        repo._append_event(event_type, payload)
    except Exception:
        # _append_event may not be public on all versions; fall back to
        # writing directly to events.log.jsonl
        try:
            import hashlib
            import time

            log_path = Path(repo.gcc_dir) / "events.log.jsonl"
            prev_hash = "0" * 64
            if log_path.exists():
                lines = log_path.read_text(encoding="utf-8").strip().splitlines()
                if lines:
                    last = json.loads(lines[-1])
                    prev_hash = last.get("hash", prev_hash)

            entry = {
                "type": event_type,
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                **payload,
            }
            entry_str = json.dumps(entry, sort_keys=True)
            entry["hash"] = hashlib.sha256(
                (prev_hash + entry_str).encode()
            ).hexdigest()

            with log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Hook handlers
# ---------------------------------------------------------------------------


def handle_pre_tool_use(payload: dict) -> None:
    repo = _find_repo()
    if repo is None:
        return
    _append_event(repo, "PRE_TOOL_USE", {
        "tool_name": payload.get("tool_name", "unknown"),
        "session_id": payload.get("session_id", ""),
    })


def handle_post_tool_use(payload: dict) -> None:
    repo = _find_repo()
    if repo is None:
        return

    tool_name = payload.get("tool_name", "unknown")
    tool_input = payload.get("tool_input", {})

    event_payload: dict = {
        "tool_name": tool_name,
        "session_id": payload.get("session_id", ""),
    }

    # For file-writing tools, capture which file was touched
    if tool_name in ("Write", "Edit", "NotebookEdit"):
        file_path = tool_input.get("file_path", tool_input.get("notebook_path", ""))
        if file_path:
            event_payload["file_path"] = file_path

    # For Bash, capture the command (truncated)
    if tool_name == "Bash":
        cmd = tool_input.get("command", "")
        event_payload["command"] = cmd[:200]

    _append_event(repo, "POST_TOOL_USE", event_payload)


def handle_session_end(payload: dict) -> None:
    repo = _find_repo()
    if repo is None:
        return
    _append_event(repo, "SESSION_END", {
        "session_id": payload.get("session_id", ""),
        "stop_hook_active": payload.get("stop_hook_active", False),
    })


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

_HANDLERS = {
    "pre-tool-use": handle_pre_tool_use,
    "post-tool-use": handle_post_tool_use,
    "session-end": handle_session_end,
}


def run(hook_name: str) -> None:
    """
    Entry point called by `devtorch hooks run <hook_name>`.

    Reads JSON from stdin, dispatches to the right handler, always exits 0.
    """
    if os.environ.get("DEVTORCH_DISABLE"):
        return

    payload = _read_stdin_json()

    handler = _HANDLERS.get(hook_name)
    if handler:
        try:
            handler(payload)
        except Exception:
            pass  # never interfere with Claude Code
