"""
DevTorch hooks package.

Provides Claude Code hook handlers and git commit-msg hook integration.
"""

from .claude_code import handle_pre_tool_use, handle_post_tool_use, handle_session_end
from .git_commit import handle_commit_msg, install_hook, extract_sensitivity_from_commit

__all__ = [
    "handle_pre_tool_use",
    "handle_post_tool_use",
    "handle_session_end",
    "handle_commit_msg",
    "install_hook",
    "extract_sensitivity_from_commit",
]
