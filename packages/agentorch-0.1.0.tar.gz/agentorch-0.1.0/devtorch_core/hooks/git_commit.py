"""
S7 git commit-msg hook — human developer capture.

Intercepts git commits to record sensitivity signals and mirror the commit
into .GCC/ so the reasoning audit trail stays in sync with the git history.

Entry point: devtorch hooks git-commit <commit_msg_file>
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Keyword → concept mapping
# ---------------------------------------------------------------------------

_CONCEPT_KEYWORDS: dict[str, list[str]] = {
    "auth": ["auth", "login", "token", "oauth", "jwt", "session", "credential"],
    "schema": ["schema", "migration", "alter", "column", "table", "model"],
    "api": ["api", "endpoint", "route", "rest", "graphql", "grpc", "http"],
    "deploy": ["deploy", "release", "publish", "rollout", "pipeline", "ci", "cd"],
    "security": ["security", "vuln", "cve", "exploit", "xss", "sql", "injection", "sanitize"],
    "performance": ["perf", "performance", "latency", "throughput", "cache", "index", "optimize"],
    "config": ["config", "env", "setting", "feature-flag", "flag", "yaml", "toml"],
}


def _infer_concept(message: str) -> str:
    """Return the best matching concept keyword for a commit message."""
    # Strip DevTorch auto-capture prefix "[session=<UUID>] auto(conf=...):"
    # and standard git trailers before keyword matching to avoid false positives
    # ("auth" matching "Co-Authored-By", "session" matching "[session=UUID]").
    cleaned = re.sub(r"^\[session=[^\]]+\]\s*auto\([^)]*\):[^\n]*\n?", "", message)
    trailer_re = re.compile(
        r"^(co-authored-by|signed-off-by|reviewed-by|acked-by|reported-by):.*$",
        re.IGNORECASE | re.MULTILINE,
    )
    cleaned = trailer_re.sub("", cleaned)
    lower = cleaned.lower()
    for concept, keywords in _CONCEPT_KEYWORDS.items():
        for kw in keywords:
            if re.search(r"\b" + re.escape(kw) + r"\b", lower):
                return concept
    return "general"


def _word_count(text: str) -> int:
    return len(text.split())


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_sensitivity_from_commit(message: str) -> Optional[dict]:
    """
    Infer sensitivity signal from a git commit message.

    Confidence tiers by message quality:
    - > 50 words: 0.75 (substantive reasoning)
    - > 20 words: 0.70 (reasonable explanation)
    - >  5 words: 0.50 (brief note)
    - <= 5 words: 0.40 (minimal — "fix bug", "wip")

    Returns {"concept": str, "signal": str, "confidence": float}
    or None if message is empty.
    """
    stripped = message.strip()
    if not stripped:
        return None

    n_words = _word_count(stripped)
    if n_words > 50:
        confidence = 0.75
    elif n_words > 20:
        confidence = 0.70
    elif n_words > 5:
        confidence = 0.50
    else:
        confidence = 0.40

    concept = _infer_concept(stripped)

    return {
        "concept": concept,
        "signal": stripped,
        "confidence": confidence,
    }


def _find_gcc_repo() -> Optional[object]:
    """Walk upward from cwd to find an initialised .GCC/ repository."""
    from devtorch_core import GCCRepository

    for parent in [Path.cwd()] + list(Path.cwd().parents):
        r = GCCRepository.at(parent)
        if r.is_initialized():
            return r
    return None


def handle_commit_msg(commit_msg_file: str) -> None:
    """
    Git commit-msg hook entry point.

    Reads commit message from commit_msg_file.
    Finds .GCC/ by walking up from cwd.
    Creates SensitivityEvent and calls repo.add_sensitivity().
    Also calls repo.commit(message=git_message).
    All errors are silent — never interfere with git commit.
    """
    try:
        git_message = Path(commit_msg_file).read_text(encoding="utf-8").strip()
        if not git_message:
            return

        sensitivity_data = extract_sensitivity_from_commit(git_message)
        if sensitivity_data is None:
            return

        repo = _find_gcc_repo()
        if repo is None:
            return

        from devtorch_core.sensitivity import SensitivityEvent

        ev = SensitivityEvent(
            source_node="git-commit-hook",
            target_concept=sensitivity_data["concept"],
            counterfactuals=sensitivity_data["signal"],
            confidence=sensitivity_data["confidence"],
            disclosure_level="PROTECTED",
            message=git_message,
        )
        repo.add_sensitivity(ev)
        repo.commit(message=git_message)

    except Exception:
        # Never interfere with git commit
        pass


def install_hook(repo_path: Optional[Path] = None) -> None:
    """
    Install the git commit-msg hook in .git/hooks/commit-msg.

    Creates a shell script that calls: devtorch hooks git-commit "$1"
    Makes it executable.
    """
    if repo_path is None:
        repo_path = Path.cwd()

    hooks_dir = repo_path / ".git" / "hooks"
    if not hooks_dir.is_dir():
        raise FileNotFoundError(
            f"No .git/hooks/ directory found at {repo_path}. "
            "Are you inside a git repository?"
        )

    hook_file = hooks_dir / "commit-msg"
    hook_script = "#!/bin/sh\ndevtorch hooks git-commit \"$1\"\n"
    hook_file.write_text(hook_script, encoding="utf-8")
    hook_file.chmod(0o755)


def main() -> None:
    """Entry point: devtorch hooks git-commit <commit_msg_file>"""
    if len(sys.argv) < 2:
        sys.stderr.write(
            "Usage: devtorch hooks git-commit <commit_msg_file>\n"
        )
        sys.exit(1)

    commit_msg_file = sys.argv[1]
    handle_commit_msg(commit_msg_file)
