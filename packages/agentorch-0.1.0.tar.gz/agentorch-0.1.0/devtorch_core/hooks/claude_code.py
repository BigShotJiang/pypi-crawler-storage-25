"""
S7 Claude Code hooks — intercept Claude Code tool-use events.

Claude Code hooks are shell commands that receive JSON on stdin and write
JSON to stdout.  This module implements three hook handlers:

  handle_pre_tool_use()   — PreToolUse event; records session start; always approves
  handle_post_tool_use()  — PostToolUse event; auto-commits for write tools
  handle_session_end()    — Stop event; finalises session metrics

Dispatch is done by main() based on argv[1]:
  pre-tool-use | post-tool-use | session-end
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

# Tools whose use we want to capture as GCC commits.
_WRITE_TOOLS = frozenset({"Write", "Edit", "MultiEdit", "Bash"})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_event() -> dict:
    """Read the JSON event from stdin."""
    return json.loads(sys.stdin.read())


def _write_response(payload: dict) -> None:
    """Write JSON response to stdout."""
    sys.stdout.write(json.dumps(payload) + "\n")
    sys.stdout.flush()


def _find_gcc_repo() -> Optional[Any]:
    """Walk upward from cwd to find an initialised .GCC/ repository."""
    from devtorch_core import GCCRepository

    for parent in [Path.cwd()] + list(Path.cwd().parents):
        r = GCCRepository.at(parent)
        if r.is_initialized():
            return r
    return None


def _gcc_root() -> Optional[Path]:
    """Return the root path containing .GCC/ or None."""
    from devtorch_core.gcc import GCC_DIR_NAME

    for parent in [Path.cwd()] + list(Path.cwd().parents):
        if (parent / GCC_DIR_NAME).is_dir():
            return parent
    return None


def _metrics_path(gcc_root: Path, session_id: str) -> Path:
    metrics_dir = gcc_root / ".GCC" / "metrics" / "session"
    metrics_dir.mkdir(parents=True, exist_ok=True)
    return metrics_dir / f"{session_id}.json"


def _load_session_metrics(path: Path) -> dict:
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            pass
    return {}


def _save_session_metrics(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2))


def _tool_summary(tool_name: str, tool_input: dict) -> str:
    """Extract a one-line summary from tool_input for commit messages."""
    if tool_name in ("Write", "Edit", "MultiEdit"):
        return tool_input.get("file_path", tool_input.get("path", "unknown"))
    elif tool_name == "Bash":
        cmd = tool_input.get("command", "")
        # Truncate long commands
        return cmd[:80] if len(cmd) > 80 else cmd
    return str(tool_input)[:80]


# ---------------------------------------------------------------------------
# Hook handlers
# ---------------------------------------------------------------------------


def handle_pre_tool_use() -> None:
    """
    PreToolUse hook handler.

    - Records session start timestamp to .GCC/metrics/session/<session_id>.json
      if a .GCC/ repo is found.
    - Always approves.
    """
    try:
        event = _read_event()
        session_id = event.get("session_id", "unknown")

        gcc_root = _gcc_root()
        if gcc_root:
            path = _metrics_path(gcc_root, session_id)
            metrics = _load_session_metrics(path)
            if "start_ts" not in metrics:
                # First tool call this session — record start
                metrics = {
                    "session_id": session_id,
                    "start_ts": time.time(),
                    "tool_calls": 0,
                    "commits": 0,
                }
            metrics["tool_calls"] = metrics.get("tool_calls", 0) + 1
            try:
                _save_session_metrics(path, metrics)
            except Exception:
                pass  # never fail
    except Exception:
        pass  # never fail the hook

    _write_response({"decision": "approve"})


def handle_post_tool_use() -> None:
    """
    PostToolUse hook handler.

    Captures write tools (Write, Edit, MultiEdit, Bash) and auto-commits
    them to .GCC/.  Read-only tools (Read, Glob, Grep, etc.) are ignored.
    Always approves.
    """
    try:
        event = _read_event()
        tool_name = event.get("tool_name", "")
        tool_input = event.get("tool_input") or {}
        session_id = event.get("session_id", "unknown")

        if tool_name in _WRITE_TOOLS:
            repo = _find_gcc_repo()
            if repo is not None:
                summary = _tool_summary(tool_name, tool_input)
                commit_msg = f"auto: {tool_name} {summary}"
                try:
                    repo.commit(message=commit_msg)

                    # Update session metrics
                    gcc_root = _gcc_root()
                    if gcc_root:
                        path = _metrics_path(gcc_root, session_id)
                        metrics = _load_session_metrics(path)
                        metrics["commits"] = metrics.get("commits", 0) + 1
                        _save_session_metrics(path, metrics)
                except Exception:
                    pass  # never fail the hook
    except Exception:
        pass  # never fail the hook

    _write_response({"decision": "approve"})


def handle_session_end() -> None:
    """
    Stop hook handler.

    Reads session start timestamp from .GCC/metrics/session/<session_id>.json,
    computes session duration, and writes final session metrics.
    Always approves.
    """
    try:
        event = _read_event()
        session_id = event.get("session_id", "unknown")

        gcc_root = _gcc_root()
        if gcc_root:
            path = _metrics_path(gcc_root, session_id)
            metrics = _load_session_metrics(path)
            if metrics:
                metrics["end_ts"] = time.time()
                try:
                    _save_session_metrics(path, metrics)
                except Exception:
                    pass
    except Exception:
        pass  # never fail the hook

    _write_response({"decision": "approve"})


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """
    Dispatcher for Claude Code hooks.

    Usage:
      devtorch hooks pre-tool-use
      devtorch hooks post-tool-use
      devtorch hooks session-end
    """
    if len(sys.argv) < 2:
        # Fallback: attempt to read event and determine hook type
        _write_response({"decision": "approve"})
        return

    hook_type = sys.argv[1]

    if hook_type == "pre-tool-use":
        handle_pre_tool_use()
    elif hook_type == "post-tool-use":
        handle_post_tool_use()
    elif hook_type == "session-end":
        handle_session_end()
    else:
        # Unknown hook — always approve
        _write_response({"decision": "approve"})
