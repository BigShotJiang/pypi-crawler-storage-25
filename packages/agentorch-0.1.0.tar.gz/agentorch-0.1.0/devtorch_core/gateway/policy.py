"""
devtorch_core.gateway.policy
=============================
Governance policy dataclass and enforcement engine for the enterprise gateway.

GovernancePolicy defines what is allowed for an organisation.
PolicyEngine enforces it on every request and response.

Design decisions:
- check_request returns (False, reason) to let the caller decide HTTP status.
- check_response only *warns* on missing RACP blocks — it does not block
  responses so that developer flow is never interrupted by compliance issues.
- load_from_file accepts a JSON file whose top-level keys map 1:1 to the
  dataclass fields, making policy files human-editable without a schema editor.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import ClassVar

logger = logging.getLogger("devtorch.gateway.policy")


# ---------------------------------------------------------------------------
# Dataclass
# ---------------------------------------------------------------------------

@dataclass
class GovernancePolicy:
    """
    Org-level governance policy.

    All fields have permissive defaults so that a gateway started with
    ``GovernancePolicy.default()`` never blocks any legitimate request.
    """

    # Which LLM models are permitted. Empty list = all permitted.
    allowed_models: list[str] = field(default_factory=list)

    # Maximum cumulative tokens consumed by one (user, date) session.
    max_tokens_per_session: int = 1_000_000

    # Whether RACP compliance is mandatory. If True, a missing RACP block
    # triggers a WARNING log (but does NOT block the response).
    racp_compliance_required: bool = False

    # Minimum ratio (0.0–1.0) of responses that must contain RACP blocks.
    # Informational for now; used by the metrics webhook payload.
    racp_compliance_threshold: float = 0.0

    # If True, a warning is emitted when the agent skips devtorch_commit.
    require_devtorch_commit: bool = False

    # Concepts that trigger an alert when found in a response (informational).
    blocked_concepts: list[str] = field(default_factory=list)

    # ---------------------------------------------------------------------------
    # Class methods
    # ---------------------------------------------------------------------------

    @classmethod
    def default(cls) -> "GovernancePolicy":
        """Return a maximally permissive policy suitable for development."""
        return cls(
            allowed_models=[],           # empty = all models allowed
            max_tokens_per_session=1_000_000,
            racp_compliance_required=False,
            racp_compliance_threshold=0.0,
            require_devtorch_commit=False,
            blocked_concepts=[],
        )

    @classmethod
    def load_from_file(cls, path: str) -> "GovernancePolicy":
        """
        Load a GovernancePolicy from a JSON file.

        The JSON must have top-level keys matching the dataclass field names.
        Unknown keys are ignored. Missing keys fall back to the default.
        """
        with open(path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)

        defaults = cls.default()
        return cls(
            allowed_models=raw.get("allowed_models", defaults.allowed_models),
            max_tokens_per_session=int(
                raw.get("max_tokens_per_session", defaults.max_tokens_per_session)
            ),
            racp_compliance_required=bool(
                raw.get("racp_compliance_required", defaults.racp_compliance_required)
            ),
            racp_compliance_threshold=float(
                raw.get("racp_compliance_threshold", defaults.racp_compliance_threshold)
            ),
            require_devtorch_commit=bool(
                raw.get("require_devtorch_commit", defaults.require_devtorch_commit)
            ),
            blocked_concepts=raw.get("blocked_concepts", defaults.blocked_concepts),
        )

    def to_summary(self) -> dict:
        """Return a JSON-safe summary for the /health endpoint (no secrets)."""
        return {
            "allowed_models": self.allowed_models or ["*"],
            "max_tokens_per_session": self.max_tokens_per_session,
            "racp_compliance_required": self.racp_compliance_required,
            "racp_compliance_threshold": self.racp_compliance_threshold,
            "require_devtorch_commit": self.require_devtorch_commit,
            "blocked_concepts_count": len(self.blocked_concepts),
        }


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class PolicyEngine:
    """
    Enforce a GovernancePolicy on individual requests and responses.

    Thread-safe: all state is read-only after construction.
    """

    def __init__(self, policy: GovernancePolicy) -> None:
        self._policy = policy

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check_request(
        self,
        model: str,
        messages: list,
        session_tokens_used: int,
    ) -> tuple[bool, str]:
        """
        Validate an outgoing request against the current policy.

        Returns:
            (True, "")            — request is permitted
            (False, reason_str)   — request should be blocked with 403
        """
        p = self._policy

        # 1. Model allowlist (empty list = all models permitted)
        if p.allowed_models and model not in p.allowed_models:
            reason = (
                f"Model '{model}' is not in the org allowed_models list. "
                f"Permitted: {p.allowed_models}"
            )
            logger.warning("Gateway BLOCKED request: %s", reason)
            return False, reason

        # 2. Token quota
        if session_tokens_used >= p.max_tokens_per_session:
            reason = (
                f"Session token limit reached: {session_tokens_used} >= "
                f"{p.max_tokens_per_session}. Start a new session."
            )
            logger.warning("Gateway BLOCKED request: %s", reason)
            return False, reason

        return True, ""

    def check_response(
        self,
        response_body: dict,
        has_racp_blocks: bool,
    ) -> tuple[bool, str]:
        """
        Validate a response from the upstream LLM.

        This method currently only *warns* — it never blocks a response —
        so the return value is always (True, warning_or_empty).

        Returns:
            (True, "")            — response is clean
            (True, warning_str)   — response has compliance issue but is allowed
        """
        p = self._policy

        if p.racp_compliance_required and not has_racp_blocks:
            warning = (
                "RACP compliance required but this response contains no RACP blocks. "
                "Ensure the agent is using devtorch_commit / RACP annotations."
            )
            logger.warning("Gateway compliance warning: %s", warning)
            return True, warning

        return True, ""

    @property
    def policy(self) -> GovernancePolicy:
        return self._policy
