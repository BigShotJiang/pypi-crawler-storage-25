"""
devtorch_core.gateway
=====================
Enterprise org gateway — multi-tenant proxy with SSO, governance policy
enforcement, central API key management, and metrics webhooks.

This is the enterprise counterpart to the local proxy (devtorch_core/proxy/).
It runs in the company's own cloud and handles multiple developers simultaneously.

Exports:
    GovernancePolicy  — policy dataclass
    PolicyEngine      — request/response enforcement
    SSOValidator      — JWT / SSO token validation
    MetricsWebhook    — push aggregate metrics to external webhook
    GatewayServer     — multi-tenant org proxy server
"""
from __future__ import annotations

from .policy import GovernancePolicy, PolicyEngine
from .sso import SSOValidator
from .metrics_webhook import MetricsWebhook
from .server import GatewayServer

__all__ = [
    "GovernancePolicy",
    "PolicyEngine",
    "SSOValidator",
    "MetricsWebhook",
    "GatewayServer",
]
