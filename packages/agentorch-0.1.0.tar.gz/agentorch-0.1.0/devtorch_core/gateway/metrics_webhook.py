"""
devtorch_core.gateway.metrics_webhook
=======================================
Push aggregate gateway metrics to an external webhook endpoint.

PRIVACY GUARANTEE:
    The payload NEVER includes prompt text, code, reasoning blocks, or any
    developer-authored content.  Only counts and aggregate scores are sent.

Payload schema:
    {
        "ts":              ISO-8601 timestamp (UTC),
        "gateway_version": str,
        "token_counts": {
            "total":      int,              # sum across all sessions
            "by_session": {user_id: int}    # per-user totals (user IDs only)
        },
        "mcs_score":       float | null,
        "dhs_score":       float | null,
        "collision_count": int,
        "session_count":   int
    }

Design decisions:
- Uses stdlib urllib.request so no new dependencies are introduced.
- All errors are caught silently and push() returns False — the gateway
  must never crash because a webhook is unreachable.
- enabled=False is the safe default so metrics are opt-in.
"""
from __future__ import annotations

import json
import logging
import urllib.request
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("devtorch.gateway.metrics_webhook")

GATEWAY_VERSION = "0.7.0"

# Keys that must NEVER appear in the webhook payload (privacy guard)
_FORBIDDEN_KEYS = frozenset(
    {"prompt", "prompts", "content", "messages", "reasoning", "text", "code"}
)


class MetricsWebhook:
    """
    Push aggregate metrics to an external HTTP webhook.

    Parameters
    ----------
    webhook_url:
        Full URL to POST metrics to (e.g. "https://analytics.example.com/devtorch").
    enabled:
        Set True to activate. Defaults to False so metrics are opt-in.
    """

    def __init__(self, webhook_url: str = "", enabled: bool = False) -> None:
        self._url = webhook_url.strip()
        self._enabled = enabled

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def push(self, payload: dict) -> bool:
        """
        POST *payload* as JSON to the configured webhook URL.

        Returns True on HTTP 200, False on any error or if disabled.
        NEVER raises — all exceptions are caught silently.
        """
        if not self._enabled or not self._url:
            return False

        # Privacy guard: strip any forbidden keys recursively.
        safe_payload = _strip_forbidden(payload)

        try:
            body = json.dumps(safe_payload, default=str).encode("utf-8")
            req = urllib.request.Request(
                self._url,
                data=body,
                method="POST",
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": f"DevTorch-Gateway/{GATEWAY_VERSION}",
                },
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status == 200
        except Exception as exc:
            logger.debug("MetricsWebhook.push failed: %s", exc)
            return False

    def build_payload(self, sessions: list[dict]) -> dict:
        """
        Build a privacy-safe webhook payload from session data.

        Parameters
        ----------
        sessions:
            List of session dicts.  Each dict may contain:
                - user_id: str
                - tokens_used: int
                - mcs_score: float | None
                - dhs_score: float | None
                - collision_count: int

        Returns a dict matching the payload schema.  No prompt/content fields
        will ever appear.
        """
        total_tokens = 0
        by_session: dict[str, int] = {}
        mcs_scores: list[float] = []
        dhs_scores: list[float] = []
        total_collisions = 0

        for sess in sessions:
            uid = str(sess.get("user_id", "unknown"))
            tokens = int(sess.get("tokens_used", 0))
            total_tokens += tokens
            by_session[uid] = by_session.get(uid, 0) + tokens

            mcs = sess.get("mcs_score")
            if mcs is not None:
                try:
                    mcs_scores.append(float(mcs))
                except (TypeError, ValueError):
                    pass

            dhs = sess.get("dhs_score")
            if dhs is not None:
                try:
                    dhs_scores.append(float(dhs))
                except (TypeError, ValueError):
                    pass

            total_collisions += int(sess.get("collision_count", 0))

        return {
            "ts": datetime.now(tz=timezone.utc).isoformat(),
            "gateway_version": GATEWAY_VERSION,
            "token_counts": {
                "total": total_tokens,
                "by_session": by_session,
            },
            "mcs_score": (sum(mcs_scores) / len(mcs_scores)) if mcs_scores else None,
            "dhs_score": (sum(dhs_scores) / len(dhs_scores)) if dhs_scores else None,
            "collision_count": total_collisions,
            "session_count": len(sessions),
        }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _strip_forbidden(obj: object) -> object:
    """
    Recursively remove any dict keys in _FORBIDDEN_KEYS.

    This is the privacy firewall between internal session data and the
    outgoing webhook payload.
    """
    if isinstance(obj, dict):
        return {
            k: _strip_forbidden(v)
            for k, v in obj.items()
            if k.lower() not in _FORBIDDEN_KEYS
        }
    if isinstance(obj, list):
        return [_strip_forbidden(item) for item in obj]
    return obj
