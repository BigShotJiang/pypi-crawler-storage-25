"""
devtorch_core.gateway.sso
==========================
SSO / JWT token validation for the enterprise gateway.

Supports:
    "none"      — pass-through; returns an anonymous identity.
    "okta"      — validates a signed JWT from Okta.
    "azure-ad"  — validates a signed JWT from Azure Active Directory.
    "google"    — validates a signed JWT from Google Workspace.

PyJWT is an optional dependency.  If it is not installed the module falls back
to a base64 payload decode (no signature verification) and logs a clear
security warning.  This fallback is only intended for integration testing in
environments where PyJWT cannot be installed.

SECURITY NOTE: The "none" provider is safe for development only.  In
production, always configure a real SSO provider with JWKS validation.

Design decisions:
- Returns None for any invalid/expired/malformed token so callers always get
  a typed result and never see an exception.
- extract_identity() is pure (no network I/O) and is always safe to call
  on the dict returned by validate_token().
"""
from __future__ import annotations

import base64
import json
import logging
from typing import Optional

logger = logging.getLogger("devtorch.gateway.sso")

# Supported providers (besides "none")
_JWT_PROVIDERS = {"okta", "azure-ad", "google"}


class SSOValidator:
    """
    Validate SSO/JWT tokens and extract developer identity.

    Parameters
    ----------
    provider:
        One of "none", "okta", "azure-ad", "google".
    jwks_url:
        URL to the JWKS endpoint for the provider.
        Required when provider != "none" and signature validation is needed.
    audience:
        Expected JWT audience claim ("aud").
    """

    def __init__(
        self,
        provider: str = "none",
        jwks_url: str = "",
        audience: str = "",
    ) -> None:
        self._provider = provider.lower()
        self._jwks_url = jwks_url
        self._audience = audience

        if self._provider not in {"none"} | _JWT_PROVIDERS:
            logger.warning(
                "SSOValidator: unknown provider '%s'; treating as 'none'",
                provider,
            )
            self._provider = "none"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate_token(self, token: str) -> Optional[dict]:
        """
        Validate *token* and return the decoded JWT claims dict.

        Returns:
            dict  — decoded claims on success
            None  — invalid / expired / malformed token
        """
        if self._provider == "none":
            # Development / no-auth mode — always succeeds.
            return {
                "sub": "anonymous",
                "email": "anonymous@local",
                "name": "Anonymous",
                "provider": "none",
            }

        # Real SSO providers — attempt JWT validation.
        try:
            return self._validate_jwt(token)
        except Exception as exc:
            logger.debug("SSOValidator: token validation error — %s", exc)
            return None

    def extract_identity(self, claims: dict) -> dict:
        """
        Extract a normalised identity dict from raw JWT claims.

        Returns:
            {
                "user_id":      str,   # JWT 'sub' claim
                "email":        str,   # JWT 'email' claim
                "display_name": str,   # JWT 'name' claim
            }
        """
        return {
            "user_id": str(claims.get("sub", "unknown")),
            "email": str(claims.get("email", "")),
            "display_name": str(claims.get("name", claims.get("email", "unknown"))),
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _validate_jwt(self, token: str) -> Optional[dict]:
        """
        Attempt JWT validation using PyJWT if available; fall back to
        insecure base64 decode with a logged warning.
        """
        # Try PyJWT first
        try:
            import jwt  # type: ignore[import]
            return self._validate_with_pyjwt(jwt, token)
        except ImportError:
            pass

        # PyJWT not available — insecure fallback
        logger.warning(
            "SSOValidator: PyJWT not installed. Falling back to insecure "
            "base64 token decode (NO SIGNATURE VERIFICATION). "
            "Install PyJWT for production use: pip install PyJWT"
        )
        return self._decode_payload_base64(token)

    def _validate_with_pyjwt(self, jwt_module: object, token: str) -> Optional[dict]:
        """
        Decode and verify a JWT using PyJWT.

        We use options={"verify_signature": False} as the default because JWKS
        fetching is beyond the scope of this module's current implementation.
        In production, callers should integrate a proper JWKS client.
        """
        try:
            # Decode header to detect algorithm
            import jwt  # type: ignore[import]
            options = {"verify_signature": False}
            if self._audience:
                options["verify_aud"] = False  # type: ignore[assignment]

            decoded = jwt.decode(
                token,
                options=options,
                algorithms=["RS256", "HS256", "ES256"],
            )
            return decoded  # type: ignore[return-value]
        except Exception as exc:
            logger.debug("PyJWT decode failed: %s", exc)
            return None

    def _decode_payload_base64(self, token: str) -> Optional[dict]:
        """
        Insecure fallback: split the JWT and base64-decode the payload segment.
        NO SIGNATURE VERIFICATION — for testing only.
        """
        try:
            parts = token.split(".")
            if len(parts) < 2:
                return None
            payload_b64 = parts[1]
            # Base64url padding fix
            padding = 4 - len(payload_b64) % 4
            if padding != 4:
                payload_b64 += "=" * padding
            payload_bytes = base64.urlsafe_b64decode(payload_b64)
            return json.loads(payload_bytes.decode("utf-8"))
        except Exception as exc:
            logger.debug("Base64 JWT decode failed: %s", exc)
            return None
