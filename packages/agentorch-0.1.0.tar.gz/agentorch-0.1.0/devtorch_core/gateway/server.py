"""
devtorch_core.gateway.server
==============================
Enterprise multi-tenant org proxy — the cloud-hosted counterpart to the
local proxy (devtorch_core/proxy/server.py).

Architecture overview:
    Developer IDE → GatewayServer (port 8080, inside org VPC)
                         ↓
                    SSO validation
                    Policy enforcement
                    RACP prefix injection
                         ↓
                    Anthropic / OpenAI API

Key differences from the local proxy:
- Handles MANY developers simultaneously (ThreadingHTTPServer).
- Validates developer identity via SSO JWT rather than trusting localhost.
- Substitutes the ORG-managed API key for any developer-supplied key.
- Enforces GovernancePolicy (model allowlist, token quota).
- Tracks per-developer token usage across the working day.
- Pushes aggregate (never prompt-level) metrics via MetricsWebhook.

Privacy guarantee:
    Prompt text, code, and reasoning tokens are NEVER logged, stored, or
    forwarded outside the org's own cloud.  Only token counts and scores
    reach the metrics webhook.
"""
from __future__ import annotations

import json
import logging
import threading
import time
import urllib.request
import urllib.error
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional

from .policy import GovernancePolicy, PolicyEngine
from .sso import SSOValidator
from .metrics_webhook import MetricsWebhook

logger = logging.getLogger("devtorch.gateway.server")

GATEWAY_VERSION = "0.7.0"

# How often (seconds) accumulated metrics are pushed to the webhook.
METRICS_PUSH_INTERVAL_SECS = 300  # 5 minutes

# Paths that are routed to Anthropic vs OpenAI.
_ANTHROPIC_PATH_PREFIXES = ("/v1/messages", "/v1/complete")
_OPENAI_PATH_PREFIXES = ("/v1/chat", "/v1/completions", "/v1/embeddings")


# ---------------------------------------------------------------------------
# Session tracking
# ---------------------------------------------------------------------------

class _SessionStore:
    """
    Thread-safe store for per-developer session data.

    Keys are (user_id: str, day: date).
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._sessions: dict[tuple, dict] = {}

    def get_or_create(self, user_id: str) -> dict:
        key = (user_id, date.today())
        with self._lock:
            if key not in self._sessions:
                self._sessions[key] = {
                    "user_id": user_id,
                    "tokens_used": 0,
                    "request_count": 0,
                    "start_ts": time.time(),
                    "mcs_score": None,
                    "dhs_score": None,
                    "collision_count": 0,
                }
            return self._sessions[key]

    def add_tokens(self, user_id: str, tokens: int) -> None:
        sess = self.get_or_create(user_id)
        with self._lock:
            sess["tokens_used"] += tokens
            sess["request_count"] += 1

    def tokens_used(self, user_id: str) -> int:
        key = (user_id, date.today())
        with self._lock:
            return self._sessions.get(key, {}).get("tokens_used", 0)

    def session_count(self) -> int:
        with self._lock:
            return len(self._sessions)

    def all_sessions(self) -> list[dict]:
        with self._lock:
            import copy
            return [copy.copy(s) for s in self._sessions.values()]


# ---------------------------------------------------------------------------
# Request handler
# ---------------------------------------------------------------------------

class _GatewayHandler(BaseHTTPRequestHandler):
    """
    HTTP request handler for the org gateway.

    server.gateway_context is set by GatewayServer before serving starts.
    """

    # Silence default request logging — we log selectively.
    def log_message(self, fmt: str, *args: object) -> None:  # type: ignore[override]
        pass

    # ------------------------------------------------------------------
    # Routing
    # ------------------------------------------------------------------

    def do_GET(self) -> None:
        if self.path == "/health" or self.path.startswith("/health?"):
            self._handle_health()
        else:
            self._send_json(404, {"error": "not found"})

    def do_POST(self) -> None:
        self._handle_llm_request()

    def do_PUT(self) -> None:
        self._handle_llm_request()

    def do_PATCH(self) -> None:
        self._handle_llm_request()

    def do_DELETE(self) -> None:
        self._handle_llm_request()

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    def _handle_health(self) -> None:
        ctx = self.server.gateway_context  # type: ignore[attr-defined]
        body = {
            "status": "ok",
            "gateway_version": GATEWAY_VERSION,
            "sessions": ctx["sessions"].session_count(),
            "policy": ctx["policy_engine"].policy.to_summary(),
        }
        self._send_json(200, body)

    # ------------------------------------------------------------------
    # LLM proxy
    # ------------------------------------------------------------------

    def _handle_llm_request(self) -> None:
        ctx = self.server.gateway_context  # type: ignore[attr-defined]

        # 1. Read request body.
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            raw_body = self.rfile.read(content_length) if content_length else b""
        except Exception:
            self._send_json(400, {"error": "could not read request body"})
            return

        # 2. Parse JSON body (best-effort).
        try:
            request_body: dict = json.loads(raw_body) if raw_body else {}
        except Exception:
            request_body = {}

        # 3. SSO — extract and validate identity.
        auth_header = self.headers.get("Authorization", "")
        token = auth_header.removeprefix("Bearer ").strip() if auth_header else ""

        sso: SSOValidator = ctx["sso"]
        claims = sso.validate_token(token)
        if claims is None:
            self._send_json(401, {"error": "invalid or missing SSO token"})
            return
        identity = sso.extract_identity(claims)
        user_id = identity["user_id"]

        # 4. Policy — check request.
        model = request_body.get("model", "")
        sessions: _SessionStore = ctx["sessions"]
        tokens_used = sessions.tokens_used(user_id)
        policy_engine: PolicyEngine = ctx["policy_engine"]

        allowed, reason = policy_engine.check_request(
            model=model,
            messages=request_body.get("messages", []),
            session_tokens_used=tokens_used,
        )
        if not allowed:
            self._send_json(403, {"error": reason})
            return

        # 5. Substitute org API key.
        forwarded_headers = self._build_forwarded_headers(ctx)

        # 6. RACP prefix injection (best-effort — never fail the request).
        try:
            from devtorch_core.wrapper.base import RACPInjector
            gcc_repo = ctx.get("gcc_repo")
            if gcc_repo is not None:
                injector = RACPInjector(gcc_repo)
                prefix = injector.build_system_prefix()
                if prefix:
                    request_body = _inject_racp_prefix(request_body, prefix)
                    raw_body = json.dumps(request_body).encode("utf-8")
        except Exception as exc:
            logger.debug("RACP injection skipped: %s", exc)

        # 7. Forward to upstream.
        upstream_url = self._resolve_upstream(ctx)
        if not upstream_url:
            self._send_json(502, {"error": "could not determine upstream URL"})
            return

        target_url = upstream_url.rstrip("/") + self.path

        try:
            upstream_req = urllib.request.Request(
                target_url,
                data=raw_body if raw_body else None,
                method=self.command,
                headers=forwarded_headers,
            )
            with urllib.request.urlopen(upstream_req, timeout=120) as upstream_resp:
                resp_body = upstream_resp.read()
                resp_status = upstream_resp.status
                resp_headers = dict(upstream_resp.headers)
        except urllib.error.HTTPError as exc:
            resp_body = exc.read()
            resp_status = exc.code
            resp_headers = {}
        except Exception as exc:
            logger.warning("Gateway upstream error: %s", exc)
            self._send_json(502, {"error": f"upstream error: {exc}"})
            return

        # 8. Parse upstream response.
        try:
            response_body: dict = json.loads(resp_body) if resp_body else {}
        except Exception:
            response_body = {}

        # 9. Policy — check response (warning only, never blocks).
        has_racp_blocks = _detect_racp_blocks(resp_body)
        _, compliance_warning = policy_engine.check_response(
            response_body=response_body,
            has_racp_blocks=has_racp_blocks,
        )
        if compliance_warning:
            logger.warning(
                "RACP compliance warning for user %s: %s", user_id, compliance_warning
            )

        # 10. Token accounting (from usage field in response).
        tokens_in_response = _extract_token_count(response_body)
        if tokens_in_response:
            sessions.add_tokens(user_id, tokens_in_response)
        else:
            # Fallback: count tokens in request body as a rough estimate.
            sessions.add_tokens(user_id, _estimate_tokens(request_body))

        # 11. Capture orchestration (best-effort).
        try:
            from devtorch_core.wrapper.base import CaptureOrchestrator
            gcc_repo = ctx.get("gcc_repo")
            if gcc_repo is not None:
                orchestrator = CaptureOrchestrator(gcc_repo)
                response_text = _extract_response_text(response_body)
                if response_text:
                    import uuid as _uuid
                    session_id = f"{user_id}-{date.today().isoformat()}"
                    orchestrator.capture(
                        response_text=response_text,
                        thinking_blocks=[],
                        session_id=session_id,
                    )
        except Exception as exc:
            logger.debug("Capture skipped: %s", exc)

        # 12. Return response to the developer.
        self._send_raw(resp_status, resp_body, resp_headers)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_forwarded_headers(self, ctx: dict) -> dict:
        """
        Build headers for the upstream request.

        Substitutes the org API key for any developer-supplied key.
        """
        headers: dict = {}

        # Copy Content-Type
        ct = self.headers.get("Content-Type", "application/json")
        headers["Content-Type"] = ct

        # Determine which org key to use based on path.
        path = self.path or ""
        org_anthropic_key: str = ctx.get("anthropic_api_key", "")
        org_openai_key: str = ctx.get("openai_api_key", "")

        is_anthropic = any(path.startswith(p) for p in _ANTHROPIC_PATH_PREFIXES)
        if is_anthropic and org_anthropic_key:
            headers["x-api-key"] = org_anthropic_key
            headers["anthropic-version"] = self.headers.get(
                "anthropic-version", "2023-06-01"
            )
        elif not is_anthropic and org_openai_key:
            headers["Authorization"] = f"Bearer {org_openai_key}"
        else:
            # Pass through whatever the developer sent (masked).
            auth = self.headers.get("Authorization", "")
            if auth:
                headers["Authorization"] = auth
            x_api = self.headers.get("x-api-key", "")
            if x_api:
                headers["x-api-key"] = x_api

        # Forward anthropic-specific headers
        for hdr in ("anthropic-beta", "anthropic-version"):
            val = self.headers.get(hdr)
            if val:
                headers[hdr] = val

        return headers

    def _resolve_upstream(self, ctx: dict) -> str:
        """
        Pick the upstream base URL based on the request path.
        """
        path = self.path or ""
        if any(path.startswith(p) for p in _ANTHROPIC_PATH_PREFIXES):
            return ctx.get("upstream_anthropic", "https://api.anthropic.com")
        return ctx.get("upstream_openai", "https://api.openai.com")

    def _send_json(self, status: int, body: dict) -> None:
        data = json.dumps(body).encode("utf-8")
        self._send_raw(status, data, {"Content-Type": "application/json"})

    def _send_raw(self, status: int, body: bytes, headers: dict) -> None:
        self.send_response(status)
        ct = headers.get("Content-Type", "application/json")
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-DevTorch-Gateway", GATEWAY_VERSION)
        self.end_headers()
        self.wfile.write(body)


# ---------------------------------------------------------------------------
# GatewayServer
# ---------------------------------------------------------------------------

class GatewayServer:
    """
    Multi-tenant org proxy server.

    Runs a ThreadingHTTPServer so that concurrent IDE requests from many
    developers are handled without blocking each other.

    Parameters
    ----------
    port:
        TCP port to listen on. Default 8080.
    upstream_anthropic:
        Base URL of the Anthropic API.
    upstream_openai:
        Base URL of the OpenAI API.
    anthropic_api_key:
        Central org Anthropic key.  Overrides any developer-supplied key.
    openai_api_key:
        Central org OpenAI key.  Overrides any developer-supplied key.
    policy:
        GovernancePolicy instance.  Defaults to GovernancePolicy.default().
    sso:
        SSOValidator instance.  Defaults to provider="none" (anonymous).
    metrics_webhook:
        MetricsWebhook instance.  Disabled by default.
    gcc_repo_path:
        Path to the shared org .GCC/ directory.  Optional.
    """

    def __init__(
        self,
        port: int = 8080,
        upstream_anthropic: str = "https://api.anthropic.com",
        upstream_openai: str = "https://api.openai.com",
        anthropic_api_key: str = "",
        openai_api_key: str = "",
        policy: Optional[GovernancePolicy] = None,
        sso: Optional[SSOValidator] = None,
        metrics_webhook: Optional[MetricsWebhook] = None,
        gcc_repo_path: str = "",
    ) -> None:
        self._port = port
        self._upstream_anthropic = upstream_anthropic
        self._upstream_openai = upstream_openai
        self._anthropic_api_key = anthropic_api_key
        self._openai_api_key = openai_api_key
        self._policy = policy or GovernancePolicy.default()
        self._sso = sso or SSOValidator(provider="none")
        self._metrics_webhook = metrics_webhook or MetricsWebhook(enabled=False)
        self._gcc_repo_path = gcc_repo_path

        self._sessions = _SessionStore()
        self._server: Optional[ThreadingHTTPServer] = None
        self._metrics_timer: Optional[threading.Timer] = None

        # Try to load gcc_repo if path provided.
        self._gcc_repo = self._load_gcc_repo(gcc_repo_path)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self, blocking: bool = True) -> None:
        """
        Start the gateway server.

        Parameters
        ----------
        blocking:
            If True (default), blocks until Ctrl+C / stop() is called.
            If False, starts in a background thread and returns immediately.
        """
        context = {
            "upstream_anthropic": self._upstream_anthropic,
            "upstream_openai": self._upstream_openai,
            "anthropic_api_key": self._anthropic_api_key,
            "openai_api_key": self._openai_api_key,
            "policy_engine": PolicyEngine(self._policy),
            "sso": self._sso,
            "sessions": self._sessions,
            "gcc_repo": self._gcc_repo,
        }

        self._server = ThreadingHTTPServer(("0.0.0.0", self._port), _GatewayHandler)
        self._server.gateway_context = context  # type: ignore[attr-defined]

        logger.info("DevTorch org gateway listening on port %d", self._port)

        self._schedule_metrics_push()

        if blocking:
            try:
                self._server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                self.stop()
        else:
            t = threading.Thread(
                target=self._server.serve_forever,
                daemon=True,
                name="devtorch-gateway",
            )
            t.start()

    def stop(self) -> None:
        """Shut down the gateway server gracefully."""
        if self._metrics_timer is not None:
            self._metrics_timer.cancel()
            self._metrics_timer = None

        if self._server is not None:
            self._server.shutdown()
            self._server = None

        logger.info("DevTorch org gateway stopped")

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    def _schedule_metrics_push(self) -> None:
        """Schedule a recurring metrics push via threading.Timer."""
        if not self._metrics_webhook._enabled:
            return

        def _push_and_reschedule() -> None:
            self._push_metrics()
            self._schedule_metrics_push()

        self._metrics_timer = threading.Timer(
            METRICS_PUSH_INTERVAL_SECS, _push_and_reschedule
        )
        self._metrics_timer.daemon = True
        self._metrics_timer.start()

    def _push_metrics(self) -> None:
        sessions = self._sessions.all_sessions()
        payload = self._metrics_webhook.build_payload(sessions)
        ok = self._metrics_webhook.push(payload)
        logger.debug("Metrics push: %s (%d sessions)", "ok" if ok else "failed", len(sessions))

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_gcc_repo(path: str) -> Optional[object]:
        if not path:
            return None
        try:
            from devtorch_core import GCCRepository
            repo = GCCRepository.at(path)
            if repo.is_initialized():
                return repo
        except Exception as exc:
            logger.debug("GCC repo load skipped (%s): %s", path, exc)
        return None


# ---------------------------------------------------------------------------
# Body helpers (pure functions — never log content)
# ---------------------------------------------------------------------------

def _inject_racp_prefix(request_body: dict, prefix: str) -> dict:
    """
    Prepend *prefix* to the system prompt in *request_body*.

    Supports both Anthropic ({system: str}) and OpenAI ({messages: [...]}) formats.
    Returns a shallow copy — does not mutate the original.
    """
    body = dict(request_body)

    # Anthropic style: top-level "system" key
    if "system" in body:
        existing = body["system"] or ""
        body["system"] = f"{prefix}\n\n{existing}".strip()
        return body

    # OpenAI style: messages array with role="system"
    messages = list(body.get("messages", []))
    if messages and messages[0].get("role") == "system":
        msg = dict(messages[0])
        msg["content"] = f"{prefix}\n\n{msg.get('content', '')}".strip()
        messages[0] = msg
    else:
        messages.insert(0, {"role": "system", "content": prefix})
    body["messages"] = messages
    return body


def _detect_racp_blocks(resp_body: bytes) -> bool:
    """Return True if the response body contains RACP block markers."""
    if not resp_body:
        return False
    try:
        text = resp_body.decode("utf-8", errors="ignore")
        return "<racp>" in text.lower() or "devtorch_commit" in text.lower()
    except Exception:
        return False


def _extract_token_count(response_body: dict) -> int:
    """
    Extract total token usage from an LLM response body.

    Handles Anthropic (usage.input_tokens + output_tokens) and
    OpenAI (usage.total_tokens) formats.
    """
    usage = response_body.get("usage", {})
    if not isinstance(usage, dict):
        return 0

    # OpenAI
    if "total_tokens" in usage:
        return int(usage["total_tokens"])

    # Anthropic
    return int(usage.get("input_tokens", 0)) + int(usage.get("output_tokens", 0))


def _estimate_tokens(request_body: dict) -> int:
    """
    Rough token estimate from request body (fallback when response has no usage).
    Uses 4 chars ≈ 1 token heuristic.  Never logs content.
    """
    try:
        raw = json.dumps(request_body)
        return max(1, len(raw) // 4)
    except Exception:
        return 1


def _extract_response_text(response_body: dict) -> str:
    """
    Extract the text of the first assistant turn from a response body.

    Returns empty string on any error — never raises.
    """
    try:
        # Anthropic
        content = response_body.get("content", [])
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    return str(block.get("text", ""))

        # OpenAI
        choices = response_body.get("choices", [])
        if isinstance(choices, list) and choices:
            msg = choices[0].get("message", {})
            return str(msg.get("content", ""))
    except Exception:
        pass
    return ""
