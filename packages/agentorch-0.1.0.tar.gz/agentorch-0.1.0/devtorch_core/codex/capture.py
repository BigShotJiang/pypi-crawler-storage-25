"""
devtorch_core.codex.capture
===========================
Handles RACP prefix injection and reasoning capture for the Codex CLI proxy.

CodexCaptureHandler:
- pre_execute  — injects RACP system prefix into the request body before
                 forwarding to OpenAI.
- post_execute — fires CaptureOrchestrator and appends a POST_TOOL_USE event
                 to .GCC/ after the response arrives.
- find_gcc_repo — walks cwd upward to find an initialised .GCC/ directory.

All methods degrade silently; never raises.
"""
from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Any

from devtorch_core.wrapper.base import (
    CaptureOrchestrator,
    RACPInjector,
    is_disabled,
)

logger = logging.getLogger("devtorch.codex.capture")


class CodexCaptureHandler:
    """Injects RACP context into Codex CLI requests and captures reasoning."""

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def pre_execute(self, request_body: dict, session_id: str) -> dict:
        """
        Inject the RACP system prefix into *request_body* before forwarding.

        Returns the modified request_body with a system message prepended, or
        the original request_body unchanged if:
          - DEVTORCH_DISABLE is set, or
          - no initialised .GCC/ repo is found, or
          - any error occurs.
        """
        if is_disabled():
            return request_body

        try:
            repo = self.find_gcc_repo()
            if repo is None:
                return request_body

            injector = RACPInjector(repo)
            prefix = injector.build_system_prefix()
            if not prefix:
                return request_body

            import copy
            modified = copy.deepcopy(request_body)
            messages = modified.get("messages", [])

            # Prepend a system message with the RACP prefix
            racp_msg = {"role": "system", "content": prefix}
            # If the first message is already a system message, prepend our
            # prefix to its content rather than inserting a second system msg
            if messages and messages[0].get("role") == "system":
                existing_content = messages[0].get("content", "")
                messages[0]["content"] = prefix + "\n\n" + existing_content
            else:
                messages.insert(0, racp_msg)

            modified["messages"] = messages
            return modified

        except Exception as exc:
            logger.warning("devtorch codex pre_execute error — %s", exc)
            return request_body

    def post_execute(
        self,
        request_body: dict,
        response_body: dict,
        session_id: str,
    ) -> None:
        """
        Capture reasoning from the response into .GCC/ and append a
        POST_TOOL_USE event to the event log.

        Silent on all errors — never raises.
        """
        if is_disabled():
            return

        try:
            repo = self.find_gcc_repo()
            if repo is None:
                return

            # Extract response text from OpenAI chat completion format
            response_text = _extract_response_text(response_body)
            thinking_blocks: list = []

            # Fire CaptureOrchestrator
            orchestrator = CaptureOrchestrator(repo)
            orchestrator.capture(response_text, thinking_blocks, session_id)

            # Append POST_TOOL_USE event
            _append_post_tool_use_event(repo, session_id, request_body)

        except Exception as exc:
            logger.warning("devtorch codex post_execute error — %s", exc)

    def find_gcc_repo(self) -> Any | None:
        """
        Walk cwd upward looking for an initialised .GCC/ directory.
        Returns a GCCRepository instance or None if not found.
        """
        try:
            from devtorch_core import GCCRepository
        except ImportError:
            logger.warning("devtorch: devtorch_core not importable — codex wrapper disabled")
            return None

        for parent in [Path.cwd()] + list(Path.cwd().parents):
            try:
                candidate = GCCRepository.at(parent)
                if candidate.is_initialized():
                    return candidate
            except Exception:
                continue
        return None


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def _extract_response_text(response_body: dict) -> str:
    """
    Extract text content from an OpenAI chat completion response body.
    Returns empty string on any error.
    """
    try:
        choices = response_body.get("choices", [])
        if not choices:
            return ""
        first_choice = choices[0]
        message = first_choice.get("message", {})
        content = message.get("content", "")
        return content or ""
    except Exception:
        return ""


def _append_post_tool_use_event(repo: Any, session_id: str, request_body: dict) -> None:
    """
    Append a POST_TOOL_USE event to the repo's event log.
    Mirrors the pattern in devtorch_core.hooks.runner.handle_post_tool_use.
    """
    try:
        import json
        import hashlib
        import time
        from pathlib import Path as _Path

        payload = {
            "tool_name": "codex_cli",
            "session_id": session_id,
            "model": request_body.get("model", "unknown"),
        }

        # Try the public _append_event method first
        try:
            repo._append_event("POST_TOOL_USE", payload)
            return
        except Exception:
            pass

        # Fallback: write directly to events.log.jsonl
        log_path = _Path(repo.gcc_dir) / "events.log.jsonl"
        prev_hash = "0" * 64
        if log_path.exists():
            lines = log_path.read_text(encoding="utf-8").strip().splitlines()
            if lines:
                try:
                    last = json.loads(lines[-1])
                    prev_hash = last.get("hash", prev_hash)
                except Exception:
                    pass

        entry = {
            "type": "POST_TOOL_USE",
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            **payload,
        }
        entry_str = json.dumps(entry, sort_keys=True)
        entry["hash"] = hashlib.sha256(
            (prev_hash + entry_str).encode()
        ).hexdigest()

        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    except Exception as exc:
        logger.warning("devtorch codex append_event failed — %s", exc)
