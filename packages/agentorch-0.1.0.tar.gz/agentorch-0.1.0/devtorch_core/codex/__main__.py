"""
Entry point for: python -m devtorch_core.codex

Usage:
    python -m devtorch_core.codex start   [--port PORT]
    python -m devtorch_core.codex install [--project PATH]
    python -m devtorch_core.codex status  [--project PATH]
"""
from __future__ import annotations

import argparse
import json
import sys


def _cmd_start(args: argparse.Namespace) -> None:
    from devtorch_core.codex.proxy import CodexProxy

    port: int = args.port
    print(f"DevTorch Codex proxy running on http://localhost:{port}")
    print(f"Configure Codex CLI: set OPENAI_BASE_URL=http://localhost:{port}/v1")

    proxy = CodexProxy(port=port)
    proxy.start()  # blocks


def _cmd_install(args: argparse.Namespace) -> None:
    import os
    from devtorch_core.codex.proxy import install_codex_hook

    project = args.project or os.getcwd()
    ok, result = install_codex_hook(project)
    if ok:
        print(f"Codex config installed: {result}")
    else:
        print(f"Install failed: {result}", file=sys.stderr)
        sys.exit(1)


def _cmd_status(args: argparse.Namespace) -> None:
    import os
    from devtorch_core.codex.proxy import get_codex_hook_status

    project = args.project or os.getcwd()
    status = get_codex_hook_status(project)
    print(json.dumps(status, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="python -m devtorch_core.codex",
        description="DevTorch OpenAI Codex CLI proxy",
    )
    sub = parser.add_subparsers(dest="command")

    # start
    start_p = sub.add_parser("start", help="Start the Codex proxy (blocking)")
    start_p.add_argument(
        "--port",
        type=int,
        default=8766,
        help="Port to listen on (default: 8766)",
    )

    # install
    install_p = sub.add_parser(
        "install", help="Install .codex/config.json for the current project"
    )
    install_p.add_argument(
        "--project",
        default=None,
        help="Project root directory (default: cwd)",
    )

    # status
    status_p = sub.add_parser("status", help="Show proxy and hook install status")
    status_p.add_argument(
        "--project",
        default=None,
        help="Project root directory (default: cwd)",
    )

    args = parser.parse_args()

    if args.command == "start":
        _cmd_start(args)
    elif args.command == "install":
        _cmd_install(args)
    elif args.command == "status":
        _cmd_status(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
