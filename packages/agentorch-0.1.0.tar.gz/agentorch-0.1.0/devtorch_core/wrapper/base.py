"""
devtorch_core.wrapper.base
==========================
Core infrastructure shared by all LLM SDK wrappers:

- RACPInjector  — builds the RACP system-prompt prefix for every LLM call.
- CaptureOrchestrator — fires devtorch commit / sensitivity primitives after
  an LLM response is received.
- Helpers: is_disabled(), find_gcc_repo().

All code must degrade gracefully.  If .GCC/ is missing, if devtorch_core
methods fail, or if parser imports fail, a warning is logged and the caller
never sees an exception.
"""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any

logger = logging.getLogger("devtorch.wrapper")

DEVTORCH_DISABLE_ENV = "DEVTORCH_DISABLE"
CONTEXT_CACHE_TTL_SECS = 60


# ---------------------------------------------------------------------------
# RACP prefix builder
# ---------------------------------------------------------------------------

class RACPInjector:
    """Builds the injected prefix for every LLM call."""

    def __init__(self, gcc_repo: Any) -> None:
        self._repo = gcc_repo
        self._cache: dict = {}   # keys: "bundle" (dict), "ts" (float)

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def build_system_prefix(self) -> str:
        """
        Return a string to prepend to the system prompt composed of:
          1. RACP system prompt from .GCC/prompts/ (if set).
          2. Θ summary — top-10 concepts by mean_confidence.
          3. Context bundle summary — artifact names and reasons.

        Returns an empty string on any error so callers can safely
        concatenate without conditional checks.
        """
        parts: list[str] = []

        # 1. RACP system prompt artifact
        try:
            racp_prompt = self._repo.prompt_get()
            if racp_prompt:
                parts.append(racp_prompt.strip())
        except Exception as exc:
            logger.warning("devtorch: prompt_get failed — %s", exc)

        # 2. Θ summary
        try:
            theta_text = self._theta_summary()
            if theta_text:
                parts.append(theta_text)
        except Exception as exc:
            logger.warning("devtorch: theta_summary failed — %s", exc)

        # 3. Context bundle summary
        try:
            bundle = self._get_context_bundle()
            artifacts = bundle.get("artifacts", [])
            if artifacts:
                lines = ["[DevTorch context bundle]"]
                for art in artifacts:
                    path = art.get("path", "?")
                    reason = art.get("reason", "")
                    lines.append(f"  - {path}: {reason}" if reason else f"  - {path}")
                parts.append("\n".join(lines))
        except Exception as exc:
            logger.warning("devtorch: context_bundle summary failed — %s", exc)

        return "\n\n".join(parts)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _get_context_bundle(self) -> dict:
        """Return cached context bundle (CONTEXT_CACHE_TTL_SECS TTL)."""
        now = time.monotonic()
        if self._cache and (now - self._cache.get("ts", 0)) < CONTEXT_CACHE_TTL_SECS:
            return self._cache["bundle"]

        bundle = self._repo.context_bundle(
            k_tokens=8000,
            policy={"sensitivity_policy": "default"},
        )
        self._cache = {"bundle": bundle, "ts": now}
        return bundle

    def _theta_summary(self) -> str:
        """Format top-10 Θ entries as compact text (sorted by mean_confidence desc)."""
        theta = self._repo.get_theta()
        cv = theta.get("coordination_vector", {})
        if not cv:
            return ""

        # Sort by mean_confidence descending; take top 10
        def _mean_conf(entry: Any) -> float:
            if isinstance(entry, dict):
                return float(entry.get("mean_confidence", 0.0))
            return 0.0

        top = sorted(cv.items(), key=lambda kv: _mean_conf(kv[1]), reverse=True)[:10]
        if not top:
            return ""

        lines = ["[DevTorch Θ — top concepts]"]
        for concept, data in top:
            conf = _mean_conf(data)
            lines.append(f"  {concept}: mean_confidence={conf:.3f}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Capture orchestrator
# ---------------------------------------------------------------------------

class CaptureOrchestrator:
    """Fires devtorch primitives after an LLM response is received."""

    def __init__(self, gcc_repo: Any) -> None:
        self._repo = gcc_repo

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def capture(
        self,
        response_text: str,
        thinking_blocks: list,
        session_id: str,
    ) -> None:
        """
        Parse *response_text* and fire devtorch primitives:

        1. If thinking blocks present → commit with conf=1.0.
        2. Extract RACP blocks from text → commit + sensitivity_add per block.
        3. If nothing found → infer_sensitivity + extract_decision_summary
           → commit with conf=0.5.

        All errors are caught and logged — never raised.
        """
        try:
            self._do_capture(response_text, thinking_blocks, session_id)
        except Exception as exc:
            logger.warning("devtorch: capture error (session=%s) — %s", session_id, exc)

    # ------------------------------------------------------------------
    # Internal capture pipeline
    # ------------------------------------------------------------------

    def _do_capture(
        self,
        response_text: str,
        thinking_blocks: list,
        session_id: str,
    ) -> None:
        captured_something = False

        # --- 1. Thinking blocks → commit ---
        if thinking_blocks:
            try:
                from devtorch_core.parser.thinking import thinking_to_commit_message
                msg = thinking_to_commit_message(thinking_blocks)
                self._do_commit(f"[session={session_id}] {msg}")
                captured_something = True
            except Exception as exc:
                logger.warning("devtorch: thinking capture failed — %s", exc)

        # --- 2. RACP blocks in response text ---
        commits: list = []
        sensitivities: list = []
        try:
            from devtorch_core.parser.blocks import extract_racp_blocks
            commits, sensitivities = extract_racp_blocks(response_text)
        except Exception as exc:
            logger.warning("devtorch: extract_racp_blocks failed — %s", exc)

        for cb in commits:
            self._do_commit(cb.message)
            captured_something = True

        for sb in sensitivities:
            self._do_sensitivity(
                concept=sb.concept,
                signal=sb.signal,
                confidence=sb.confidence,
                disclosure=sb.disclosure,
            )
            captured_something = True

        # --- 3. Fallback: infer + decision summary ---
        if not captured_something and response_text:
            summary = ""
            try:
                from devtorch_core.parser.inference import extract_decision_summary
                summary = extract_decision_summary(response_text)
            except Exception:
                # inference module may not exist yet
                summary = response_text[:200]

            try:
                from devtorch_core.parser.inference import infer_sensitivity
                inferred = infer_sensitivity(response_text)
                for item in inferred:
                    concept = getattr(item, "concept", str(item))
                    signal = getattr(item, "signal", "inferred")
                    confidence = float(getattr(item, "confidence", 0.5))
                    disclosure = getattr(item, "disclosure", "PROTECTED")
                    self._do_sensitivity(concept, signal, confidence, disclosure)
            except Exception as exc:
                logger.warning("devtorch: infer_sensitivity failed — %s", exc)

            commit_msg = (
                f"[session={session_id}] auto(conf=0.5): {summary[:180]}"
                if summary
                else f"[session={session_id}] auto(conf=0.5): response captured"
            )
            self._do_commit(commit_msg)

    # ------------------------------------------------------------------
    # Primitives — each catches its own errors
    # ------------------------------------------------------------------

    def _do_commit(self, message: str) -> None:
        try:
            self._repo.commit(message=message)
        except Exception as exc:
            logger.warning("devtorch commit failed: %s", exc)

    def _do_sensitivity(
        self,
        concept: str,
        signal: str,
        confidence: float,
        disclosure: str = "PROTECTED",
    ) -> None:
        try:
            from devtorch_core.sensitivity import SensitivityEvent

            ev = SensitivityEvent(
                source_node="llm_wrapper",
                target_concept=concept,
                counterfactuals="",
                confidence=confidence,
                disclosure_level=disclosure,
                message=signal[:200],
            )
            self._repo.add_sensitivity(ev)
        except Exception as exc:
            logger.warning("devtorch sensitivity add failed: %s", exc)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def is_disabled() -> bool:
    """Return True if the DEVTORCH_DISABLE env var is set to a truthy value."""
    return os.environ.get(DEVTORCH_DISABLE_ENV, "").strip().lower() in (
        "1", "true", "yes"
    )


def find_gcc_repo() -> Any | None:
    """
    Walk up from cwd looking for an initialised .GCC/ directory.
    Returns a GCCRepository instance or None if none found or if
    devtorch_core is not importable.
    """
    try:
        from devtorch_core import GCCRepository
    except ImportError:
        logger.warning("devtorch: devtorch_core not importable — wrapper disabled")
        return None

    for parent in [Path.cwd()] + list(Path.cwd().parents):
        try:
            candidate = GCCRepository.at(parent)
            if candidate.is_initialized():
                return candidate
        except Exception:
            continue
    return None
