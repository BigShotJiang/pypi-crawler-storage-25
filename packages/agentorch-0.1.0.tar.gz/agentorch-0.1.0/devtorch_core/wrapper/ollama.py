"""
devtorch_core.wrapper.ollama
=============================
Drop-in Ollama client wrapper that:

1. Injects the RACP system-prompt prefix as the first system message in every
   ``chat()`` call.
2. Captures RACP blocks / inferred sensitivity from the response to the .GCC/
   store.
3. Degrades gracefully — if Ollama is not running, returns an error dict
   without raising.
4. Uses the OpenAI-compatible endpoint (``/v1/chat/completions``) so the same
   parsing pipeline works as with DevTorchOpenAI.

Usage
-----
::

    from devtorch_core.wrapper.ollama import DevTorchOllama

    client = DevTorchOllama(model="llama3.2")
    response = client.chat([{"role": "user", "content": "Hello"}])
    # response = {"choices": [{"message": {"content": "Hi there!"}}], ...}

    # Streaming
    for chunk in client.chat([{"role": "user", "content": "Hello"}], stream=True):
        print(chunk["choices"][0]["delta"]["content"], end="", flush=True)

Environment variables
---------------------
DEVTORCH_DISABLE=1   Disable all injection and capture (pass-through mode).
"""
from __future__ import annotations

import json
import logging
import uuid
from typing import Any, Iterator

from .base import CaptureOrchestrator, RACPInjector, find_gcc_repo, is_disabled

logger = logging.getLogger("devtorch.wrapper.ollama")

# ---------------------------------------------------------------------------
# Optional httpx — fall back to urllib.request if not available
# ---------------------------------------------------------------------------

try:
    import httpx as _httpx

    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False
    _httpx = None  # type: ignore[assignment]

import urllib.request
import urllib.error


# ---------------------------------------------------------------------------
# Wrapper
# ---------------------------------------------------------------------------


class DevTorchOllama:
    """
    Ollama LLM wrapper with RACP injection and .GCC/ capture.

    Uses the OpenAI-compatible endpoint at ``{base_url}/v1/chat/completions``
    so the same response parsing pipeline as DevTorchOpenAI applies.

    All errors are caught internally — never raised to the caller.
    Ollama models are treated as inference-fallback (confidence tier ≤ 0.5)
    because they do not emit thinking tokens or RACP blocks in practice.
    """

    def __init__(
        self,
        model: str = "llama3.2",
        base_url: str = "http://localhost:11434",
        gcc_repo_path: str | None = None,
        racp_prompt: str | None = None,
    ) -> None:
        self.model = model
        self.base_url = base_url.rstrip("/")
        self._gcc_repo_path = gcc_repo_path
        self._racp_prompt = racp_prompt

        # Resolve GCC repo
        self._gcc = find_gcc_repo()
        self._injector = RACPInjector(self._gcc) if self._gcc else None
        self._capture = CaptureOrchestrator(self._gcc) if self._gcc else None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def chat(
        self,
        messages: list[dict],
        stream: bool = False,
        **kwargs: Any,
    ) -> dict | Iterator[dict]:
        """
        Send a chat request to Ollama.

        Parameters
        ----------
        messages:
            List of message dicts in OpenAI format
            (e.g. ``[{"role": "user", "content": "Hello"}]``).
        stream:
            If True, yields response chunks as dicts; otherwise returns a
            single response dict.
        **kwargs:
            Extra fields forwarded to the request body (e.g. ``temperature``).

        Returns
        -------
        dict
            OpenAI-style response dict on success.  On error, returns
            ``{"error": "<message>", "choices": []}``.
        Iterator[dict]
            When ``stream=True``, yields dicts with
            ``choices[0]["delta"]["content"]`` populated.
        """
        session_id = str(uuid.uuid4())[:8]
        injected_messages = self._inject(list(messages))

        if stream:
            return self._stream_chat(injected_messages, session_id, **kwargs)

        return self._non_stream_chat(injected_messages, session_id, **kwargs)

    def list_models(self) -> list[str]:
        """
        Return a list of model names available in the local Ollama instance.

        Returns an empty list on any error (e.g. Ollama not running).
        """
        url = f"{self.base_url}/api/tags"
        try:
            data = self._get(url)
            models = data.get("models", [])
            return [m.get("name", "") for m in models if m.get("name")]
        except Exception as exc:
            logger.warning("devtorch.ollama: list_models failed — %s", exc)
            return []

    # ------------------------------------------------------------------
    # Internal: non-streaming
    # ------------------------------------------------------------------

    def _non_stream_chat(
        self,
        messages: list[dict],
        session_id: str,
        **kwargs: Any,
    ) -> dict:
        url = f"{self.base_url}/v1/chat/completions"
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            **kwargs,
        }
        try:
            response = self._post(url, payload)
        except Exception as exc:
            logger.warning("devtorch.ollama: chat failed — %s", exc)
            return {"error": str(exc), "choices": []}

        # Capture after successful response
        self._capture_response(response, session_id)
        return response

    # ------------------------------------------------------------------
    # Internal: streaming
    # ------------------------------------------------------------------

    def _stream_chat(
        self,
        messages: list[dict],
        session_id: str,
        **kwargs: Any,
    ) -> Iterator[dict]:
        """
        Yield response chunks from Ollama's streaming endpoint.

        Each yielded dict has the OpenAI-chunk shape:
        ``{"choices": [{"delta": {"content": "..."}}]}``.

        After the stream ends, fires CaptureOrchestrator.capture().
        """
        url = f"{self.base_url}/v1/chat/completions"
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            **kwargs,
        }
        accumulated: list[str] = []
        try:
            yield from self._stream_post(url, payload, accumulated)
        except Exception as exc:
            logger.warning("devtorch.ollama: stream_chat failed — %s", exc)
            yield {"error": str(exc), "choices": []}
            return

        # Fire capture with whatever we accumulated
        full_text = "".join(accumulated)
        if full_text and self._capture and not is_disabled():
            try:
                self._capture.capture(full_text, [], session_id)
            except Exception as exc:
                logger.warning("devtorch.ollama: stream capture failed — %s", exc)

    # ------------------------------------------------------------------
    # Injection
    # ------------------------------------------------------------------

    def _inject(self, messages: list[dict]) -> list[dict]:
        """Prepend the RACP system prefix as a system message (if enabled)."""
        if is_disabled() or not self._injector:
            return messages
        try:
            prefix = self._injector.build_system_prefix()
            if prefix:
                system_msg = {"role": "system", "content": prefix}
                return [system_msg] + messages
        except Exception as exc:
            logger.warning("devtorch.ollama: RACP injection failed — %s", exc)
        return messages

    # ------------------------------------------------------------------
    # Capture
    # ------------------------------------------------------------------

    def _capture_response(self, response: dict, session_id: str) -> None:
        """Extract text from response dict and fire CaptureOrchestrator."""
        if not self._capture or is_disabled():
            return
        try:
            text = _extract_text(response)
            self._capture.capture(text, [], session_id)
        except Exception as exc:
            logger.warning("devtorch.ollama: _capture_response failed — %s", exc)

    # ------------------------------------------------------------------
    # HTTP helpers — prefer httpx, fall back to urllib.request
    # ------------------------------------------------------------------

    def _post(self, url: str, payload: dict) -> dict:
        """POST *payload* as JSON to *url*, return parsed response dict."""
        body = json.dumps(payload).encode("utf-8")

        if HAS_HTTPX:
            try:
                with _httpx.Client(timeout=120.0) as client:  # type: ignore[union-attr]
                    resp = client.post(
                        url,
                        content=body,
                        headers={"Content-Type": "application/json"},
                    )
                    resp.raise_for_status()
                    return resp.json()
            except _httpx.ConnectError as exc:  # type: ignore[union-attr]
                raise ConnectionError(f"Ollama not reachable at {self.base_url}: {exc}") from exc

        # --- urllib.request fallback ---
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as exc:
            raise ConnectionError(f"Ollama not reachable at {self.base_url}: {exc}") from exc

    def _get(self, url: str) -> dict:
        """GET *url*, return parsed JSON dict."""
        if HAS_HTTPX:
            try:
                with _httpx.Client(timeout=30.0) as client:  # type: ignore[union-attr]
                    resp = client.get(url)
                    resp.raise_for_status()
                    return resp.json()
            except _httpx.ConnectError as exc:  # type: ignore[union-attr]
                raise ConnectionError(f"Ollama not reachable at {self.base_url}: {exc}") from exc

        req = urllib.request.Request(url, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as exc:
            raise ConnectionError(f"Ollama not reachable at {self.base_url}: {exc}") from exc

    def _stream_post(
        self,
        url: str,
        payload: dict,
        accumulated: list[str],
    ) -> Iterator[dict]:
        """
        POST *payload* with streaming enabled; yield parsed chunk dicts.
        Appends content strings to *accumulated* for post-stream capture.
        """
        body = json.dumps(payload).encode("utf-8")

        if HAS_HTTPX:
            yield from self._stream_post_httpx(url, body, accumulated)
        else:
            yield from self._stream_post_urllib(url, body, accumulated)

    def _stream_post_httpx(
        self,
        url: str,
        body: bytes,
        accumulated: list[str],
    ) -> Iterator[dict]:
        try:
            with _httpx.Client(timeout=120.0) as client:  # type: ignore[union-attr]
                with client.stream(
                    "POST",
                    url,
                    content=body,
                    headers={"Content-Type": "application/json"},
                ) as resp:
                    resp.raise_for_status()
                    for line in resp.iter_lines():
                        chunk = _parse_sse_line(line, accumulated)
                        if chunk is not None:
                            yield chunk
        except _httpx.ConnectError as exc:  # type: ignore[union-attr]
            raise ConnectionError(
                f"Ollama not reachable at {self.base_url}: {exc}"
            ) from exc

    def _stream_post_urllib(
        self,
        url: str,
        body: bytes,
        accumulated: list[str],
    ) -> Iterator[dict]:
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8").rstrip("\n\r")
                    chunk = _parse_sse_line(line, accumulated)
                    if chunk is not None:
                        yield chunk
        except urllib.error.URLError as exc:
            raise ConnectionError(
                f"Ollama not reachable at {self.base_url}: {exc}"
            ) from exc


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _extract_text(response: dict) -> str:
    """Extract plain text content from an OpenAI-style response dict."""
    try:
        choices = response.get("choices", [])
        if choices:
            msg = choices[0].get("message", {})
            return msg.get("content", "") or ""
    except Exception:
        pass
    return ""


def _parse_sse_line(line: str, accumulated: list[str]) -> dict | None:
    """
    Parse a single Server-Sent Events line from the streaming response.

    OpenAI-compatible stream format: ``data: <json>`` or ``data: [DONE]``.
    Returns a chunk dict or None if the line should be skipped.
    Appends delta content to *accumulated*.
    """
    line = line.strip()
    if not line:
        return None

    # Strip SSE "data: " prefix if present
    if line.startswith("data:"):
        line = line[5:].strip()

    if line == "[DONE]":
        return None

    try:
        chunk = json.loads(line)
    except json.JSONDecodeError:
        return None

    # Accumulate content from delta
    try:
        choices = chunk.get("choices", [])
        if choices:
            delta = choices[0].get("delta", {})
            content = delta.get("content")
            if content:
                accumulated.append(content)
    except Exception:
        pass

    return chunk
