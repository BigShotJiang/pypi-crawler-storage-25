"""
devtorch_core.wrapper.bedrock
==============================
Stub wrapper around the AWS Bedrock ``boto3`` client.

Intercepts ``invoke_model`` for Anthropic Claude models served via Bedrock
(body format: ``{"anthropic_version": ..., "messages": [...], "system": ...}``).

Other model families (Titan, Llama, Mistral, etc.) pass through unchanged
with a debug log.

Usage
-----
::

    from devtorch_core.wrapper.bedrock import DevTorchBedrock

    client = DevTorchBedrock(region_name="us-east-1")
    response = client.invoke_model(
        modelId="anthropic.claude-opus-4-5-20240229-v1:0",
        body=json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": "Hello"}],
        }),
        contentType="application/json",
        accept="application/json",
    )
"""
from __future__ import annotations

import json
import logging
import uuid
from typing import Any

from .base import CaptureOrchestrator, RACPInjector, find_gcc_repo, is_disabled

logger = logging.getLogger("devtorch.wrapper.bedrock")

# ---------------------------------------------------------------------------
# Optional import
# ---------------------------------------------------------------------------

try:
    import boto3 as _boto3  # type: ignore[import]

    HAS_BOTO3 = True
except ImportError:
    HAS_BOTO3 = False
    _boto3 = None  # type: ignore[assignment]

# Model ID prefixes that use the Anthropic Claude Bedrock body format
_ANTHROPIC_BEDROCK_PREFIXES = (
    "anthropic.claude",
    "us.anthropic.claude",
    "eu.anthropic.claude",
)


# ---------------------------------------------------------------------------
# Wrapper
# ---------------------------------------------------------------------------


class DevTorchBedrock:
    """
    Wrapper around a ``boto3`` Bedrock runtime client.

    Intercepts ``invoke_model`` for Anthropic Claude models to inject RACP
    context and capture reasoning.  All other calls are passed through
    unchanged.  Degrades gracefully if boto3 is not installed or .GCC/ is
    missing.
    """

    def __init__(
        self,
        *args: Any,
        gcc_repo: Any = None,
        service_name: str = "bedrock-runtime",
        **kwargs: Any,
    ) -> None:
        if not HAS_BOTO3:
            raise ImportError(
                "boto3 package not installed. "
                "pip install devtorch[wrapper]"
            )
        self._client = _boto3.client(service_name, *args, **kwargs)  # type: ignore[union-attr]
        self._gcc = gcc_repo or find_gcc_repo()
        self._injector = RACPInjector(self._gcc) if self._gcc else None
        self._capture = CaptureOrchestrator(self._gcc) if self._gcc else None

    # ------------------------------------------------------------------
    # Intercepted method
    # ------------------------------------------------------------------

    def invoke_model(self, *, modelId: str, body: Any, **kwargs: Any) -> Any:
        """
        Intercept invoke_model for Claude-via-Bedrock calls.

        1. Decode body JSON.
        2. If Anthropic Claude model: inject RACP into ``system`` field.
        3. Call real client.
        4. Decode response body and capture.
        5. Return raw boto3 response (stream-compatible).
        """
        session_id = str(uuid.uuid4())[:8]
        is_anthropic = any(
            modelId.startswith(pfx) for pfx in _ANTHROPIC_BEDROCK_PREFIXES
        )

        if is_anthropic and not is_disabled():
            body = self._inject_anthropic(body)
        elif not is_anthropic:
            logger.debug(
                "devtorch: Bedrock model %s is not Anthropic Claude — "
                "passing through without RACP injection",
                modelId,
            )

        # Call the real Bedrock client
        try:
            response = self._client.invoke_model(modelId=modelId, body=body, **kwargs)
        except Exception:
            raise

        # Capture response for Anthropic models
        if is_anthropic:
            self._capture_response(response, session_id)

        return response

    # ------------------------------------------------------------------
    # Injection
    # ------------------------------------------------------------------

    def _inject_anthropic(self, body: Any) -> str:
        """Inject RACP prefix into the ``system`` field of an Anthropic body."""
        if not self._injector:
            return body if isinstance(body, str) else json.dumps(body)

        try:
            if isinstance(body, (bytes, bytearray)):
                body_dict = json.loads(body.decode("utf-8"))
            elif isinstance(body, str):
                body_dict = json.loads(body)
            elif isinstance(body, dict):
                body_dict = dict(body)
            else:
                return body  # type: ignore[return-value]

            prefix = self._injector.build_system_prefix()
            if prefix:
                existing_system = body_dict.get("system", "")
                body_dict["system"] = (
                    (prefix + "\n\n" + existing_system).strip()
                    if existing_system
                    else prefix
                )

            return json.dumps(body_dict)
        except Exception as exc:
            logger.warning("devtorch: Bedrock RACP injection failed — %s", exc)
            return body if isinstance(body, str) else json.dumps(body)

    # ------------------------------------------------------------------
    # Capture
    # ------------------------------------------------------------------

    def _capture_response(self, response: Any, session_id: str) -> None:
        if not self._capture or is_disabled():
            return
        try:
            # Read and re-inject body stream
            body_stream = response.get("body")
            if body_stream is None:
                return
            raw = body_stream.read()
            response_dict = json.loads(raw.decode("utf-8"))

            # Extract text from Anthropic Bedrock response format
            text = ""
            for block in response_dict.get("content", []):
                if isinstance(block, dict) and block.get("type") == "text":
                    text += block.get("text", "")

            # Extract thinking blocks
            thinking: list = []
            try:
                from devtorch_core.parser.thinking import extract_thinking_blocks

                thinking = extract_thinking_blocks(response_dict)
            except Exception:
                pass

            self._capture.capture(text, thinking, session_id)

            # Wrap body bytes back into a StreamingBody-compatible object
            # so the caller can still read the response
            import io

            response["body"] = _BytesBodyWrapper(raw)
        except Exception as exc:
            logger.warning("devtorch: Bedrock _capture_response failed — %s", exc)

    # ------------------------------------------------------------------
    # Proxy everything else to the underlying boto3 client
    # ------------------------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


# ---------------------------------------------------------------------------
# Helper: re-wrap consumed body bytes
# ---------------------------------------------------------------------------


class _BytesBodyWrapper:
    """
    Minimal wrapper that restores a boto3-style StreamingBody after we've
    read all bytes for capture.
    """

    def __init__(self, data: bytes) -> None:
        import io

        self._stream = io.BytesIO(data)

    def read(self, amt: int = -1) -> bytes:  # type: ignore[override]
        return self._stream.read() if amt == -1 else self._stream.read(amt)

    def __iter__(self) -> Any:
        return iter(self._stream)
