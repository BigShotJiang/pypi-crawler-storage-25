"""
devtorch_core.wrapper.anthropic
================================
Drop-in replacement for ``anthropic.Anthropic`` that:

1. Injects the RACP system-prompt prefix into every ``messages.create`` call.
2. Captures reasoning / RACP blocks from the response to the .GCC/ store.
3. Returns clean (block-stripped) text to callers.
4. Degrades gracefully if anthropic is not installed or .GCC/ is missing.

Usage
-----
::

    from devtorch_core.wrapper.anthropic import DevTorchAnthropic as Anthropic

    client = Anthropic()           # same constructor signature as anthropic.Anthropic
    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello"}],
    )
"""
from __future__ import annotations

import logging
import uuid
from typing import Any, Iterator

from .base import CaptureOrchestrator, RACPInjector, find_gcc_repo, is_disabled

logger = logging.getLogger("devtorch.wrapper.anthropic")

# ---------------------------------------------------------------------------
# Optional import — degrade gracefully if anthropic is not installed
# ---------------------------------------------------------------------------

try:
    import anthropic as _anthropic

    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False
    _anthropic = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Wrapper
# ---------------------------------------------------------------------------


class DevTorchAnthropic:
    """
    Drop-in replacement for ``anthropic.Anthropic``.

    Adds RACP injection and .GCC/ capture without altering the public API
    visible to callers.  All DevTorch errors degrade to warnings.
    """

    def __init__(self, *args: Any, gcc_repo: Any = None, **kwargs: Any) -> None:
        if not HAS_ANTHROPIC:
            raise ImportError(
                "anthropic package not installed. "
                "pip install devtorch[wrapper]"
            )
        self._client = _anthropic.Anthropic(*args, **kwargs)  # type: ignore[union-attr]
        self._gcc = gcc_repo or find_gcc_repo()
        self._injector = RACPInjector(self._gcc) if self._gcc else None
        self._capture = CaptureOrchestrator(self._gcc) if self._gcc else None
        self.messages = self._Messages(self)

    # Proxy attribute access to the underlying client for anything we
    # don't explicitly intercept (e.g. .beta, .models, etc.)
    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)

    # ------------------------------------------------------------------
    # Inner class mirrors anthropic.Anthropic.messages
    # ------------------------------------------------------------------

    class _Messages:
        def __init__(self, parent: "DevTorchAnthropic") -> None:
            self._p = parent

        # --------------------------------------------------------------
        # create — main intercept point
        # --------------------------------------------------------------

        def create(
            self,
            *,
            messages: list,
            system: str = "",
            stream: bool = False,
            **kwargs: Any,
        ) -> Any:
            """
            Inject RACP prefix into *system*, call the real API, capture
            response.

            If ``stream=True`` returns a streaming wrapper that passes chunks
            through transparently and captures the accumulated response after
            the stream closes.

            DevTorch errors never propagate to the caller.
            """
            session_id = str(uuid.uuid4())[:8]
            injected_system = self._inject(system)

            if stream:
                return self._stream_create(
                    messages=messages,
                    system=injected_system,
                    session_id=session_id,
                    **kwargs,
                )

            # Non-streaming path
            try:
                response = self._p._client.messages.create(
                    messages=messages,
                    system=injected_system,
                    stream=False,
                    **kwargs,
                )
            except Exception:
                # Re-raise API errors — they are not DevTorch errors
                raise

            self._capture_response(response, session_id)

            # Strip RACP blocks from the visible text in each content block
            try:
                response = self._strip_response(response)
            except Exception as exc:
                logger.warning("devtorch: strip_response failed — %s", exc)

            return response

        # --------------------------------------------------------------
        # Streaming helper
        # --------------------------------------------------------------

        def _stream_create(
            self,
            *,
            messages: list,
            system: str,
            session_id: str,
            **kwargs: Any,
        ) -> "_StreamingWrapper":
            raw_stream = self._p._client.messages.create(
                messages=messages,
                system=system,
                stream=True,
                **kwargs,
            )
            return _StreamingWrapper(raw_stream, self, session_id)

        # --------------------------------------------------------------
        # Injection helpers
        # --------------------------------------------------------------

        def _inject(self, system: str) -> str:
            if self._p._injector and not is_disabled():
                try:
                    prefix = self._p._injector.build_system_prefix()
                    if prefix:
                        return (prefix + "\n\n" + system).strip()
                except Exception as exc:
                    logger.warning("devtorch: RACP injection failed — %s", exc)
            return system

        # --------------------------------------------------------------
        # Capture helpers
        # --------------------------------------------------------------

        def _capture_response(self, response: Any, session_id: str) -> None:
            if not self._p._capture or is_disabled():
                return
            try:
                # Build a plain dict for the parsers
                if hasattr(response, "model_dump"):
                    response_dict = response.model_dump()
                elif isinstance(response, dict):
                    response_dict = response
                else:
                    response_dict = {}

                # Extract visible text
                text = _extract_text(response)

                # Extract thinking blocks
                thinking: list = []
                try:
                    from devtorch_core.parser.thinking import extract_thinking_blocks

                    thinking = extract_thinking_blocks(response_dict)
                except Exception:
                    pass

                self._p._capture.capture(text, thinking, session_id)
            except Exception as exc:
                logger.warning("devtorch: _capture_response failed — %s", exc)

        # --------------------------------------------------------------
        # Strip RACP markup from the response object
        # --------------------------------------------------------------

        def _strip_response(self, response: Any) -> Any:
            """
            Return response with RACP blocks stripped from text content blocks.
            Modifies in-place where possible; falls back to returning original.
            """
            from devtorch_core.parser.blocks import strip_racp_blocks

            content = getattr(response, "content", None)
            if content is None:
                return response

            for block in content:
                if hasattr(block, "text") and isinstance(block.text, str):
                    try:
                        block.text = strip_racp_blocks(block.text)
                    except Exception:
                        pass

            return response


# ---------------------------------------------------------------------------
# Streaming wrapper
# ---------------------------------------------------------------------------


class _StreamingWrapper:
    """
    Thin wrapper around the raw Anthropic streaming response.

    Passes chunks through transparently while accumulating the full text
    in a shadow buffer.  Fires capture when the stream closes.
    """

    def __init__(
        self,
        raw_stream: Any,
        messages_obj: "DevTorchAnthropic._Messages",
        session_id: str,
    ) -> None:
        self._raw = raw_stream
        self._msgs = messages_obj
        self._session_id = session_id
        self._accumulated_text = ""

    def __iter__(self) -> Iterator[Any]:
        try:
            for chunk in self._raw:
                # Accumulate text from delta events
                try:
                    delta = getattr(chunk, "delta", None)
                    if delta is not None and hasattr(delta, "text"):
                        self._accumulated_text += delta.text or ""
                    elif isinstance(chunk, dict):
                        delta_d = chunk.get("delta", {})
                        self._accumulated_text += delta_d.get("text", "")
                except Exception:
                    pass
                yield chunk
        finally:
            self._on_close()

    def __enter__(self) -> "_StreamingWrapper":
        if hasattr(self._raw, "__enter__"):
            self._raw.__enter__()
        return self

    def __exit__(self, *args: Any) -> None:
        try:
            if hasattr(self._raw, "__exit__"):
                self._raw.__exit__(*args)
        finally:
            self._on_close()

    def _on_close(self) -> None:
        if self._accumulated_text:
            try:
                self._msgs._p._capture.capture(
                    self._accumulated_text, [], self._session_id
                )
            except Exception as exc:
                logger.warning("devtorch: stream capture failed — %s", exc)

    # Proxy everything else to the raw stream
    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _extract_text(response: Any) -> str:
    """Pull plain text from an Anthropic response object or dict."""
    text = ""
    content = getattr(response, "content", None) or (
        response.get("content") if isinstance(response, dict) else None
    )
    if not content:
        return text
    for block in content:
        if isinstance(block, dict):
            if block.get("type") == "text":
                text += block.get("text", "")
        elif hasattr(block, "text"):
            text += block.text or ""
    return text
