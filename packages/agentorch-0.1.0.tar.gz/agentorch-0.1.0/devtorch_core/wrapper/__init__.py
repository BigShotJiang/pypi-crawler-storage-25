"""
devtorch_core.wrapper
=====================
LLM SDK wrapper layer (S7).

Provides drop-in replacements for popular LLM SDK clients that transparently:

1. Inject RACP context (system prompt + Θ coordination vector + context bundle)
   into every LLM call.
2. Capture reasoning (thinking blocks, RACP-tagged blocks) to the local .GCC/
   reasoning store.
3. Return clean, block-stripped responses to the caller.
4. Degrade gracefully — if .GCC/ is missing or any DevTorch primitive fails,
   a warning is logged and the LLM response is returned as-is.

Quick start
-----------
::

    # Anthropic
    from devtorch_core.wrapper.anthropic import DevTorchAnthropic as Anthropic

    # OpenAI
    from devtorch_core.wrapper.openai import DevTorchOpenAI as OpenAI

    # Google Gemini
    from devtorch_core.wrapper.gemini import DevTorchGemini

    # AWS Bedrock (Anthropic Claude)
    from devtorch_core.wrapper.bedrock import DevTorchBedrock

Environment variables
---------------------
DEVTORCH_DISABLE=1   Disable all injection and capture (pass-through mode).
"""

from .anthropic import DevTorchAnthropic
from .openai import DevTorchOpenAI
from .gemini import DevTorchGemini
from .bedrock import DevTorchBedrock
from .base import RACPInjector, CaptureOrchestrator, find_gcc_repo, is_disabled

__all__ = [
    "DevTorchAnthropic",
    "DevTorchOpenAI",
    "DevTorchGemini",
    "DevTorchBedrock",
    "RACPInjector",
    "CaptureOrchestrator",
    "find_gcc_repo",
    "is_disabled",
]
