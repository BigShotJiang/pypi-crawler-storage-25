"""
devtorch_core.wrapper.openai
=============================
Drop-in replacement for ``openai.OpenAI`` that:

1. Injects the RACP system-prompt prefix as the first message in every
   ``chat.completions.create`` call.
2. Captures reasoning / RACP blocks from the response to the .GCC/ store.
3. Returns clean (block-stripped) content to callers.
4. Degrades gracefully if openai is not installed or .GCC/ is missing.

Usage
-----
::

    from devtorch_core.wrapper.openai import DevTorchOpenAI as OpenAI

    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}],
    )
"""
from __future__ import annotations

import logging
import uuid
from typing import Any, Iterator

from .base import CaptureOrchestrator, RACPInjector, find_gcc_repo, is_disabled

logger = logging.getLogger("devtorch.wrapper.openai")

# ---------------------------------------------------------------------------
# Optional import
# ---------------------------------------------------------------------------

try:
    import openai as _openai

    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False
    _openai = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Wrapper
# ---------------------------------------------------------------------------


class DevTorchOpenAI:
    """
    Drop-in replacement for ``openai.OpenAI``.

    Intercepts ``client.chat.completions.create`` to inject RACP context
    and capture LLM reasoning.  All other attribute access is proxied to
    the underlying ``openai.OpenAI`` client transparently.
    """

    def __init__(self, *args: Any, gcc_repo: Any = None, **kwargs: Any) -> None:
        if not HAS_OPENAI:
            raise ImportError(
                "openai package not installed. "
                "pip install devtorch[wrapper]"
            )
        self._client = _openai.OpenAI(*args, **kwargs)  # type: ignore[union-attr]
        self._gcc = gcc_repo or find_gcc_repo()
        self._injector = RACPInjector(self._gcc) if self._gcc else None
        self._capture = CaptureOrchestrator(self._gcc) if self._gcc else None
        self.chat = self._Chat(self)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)

    # ------------------------------------------------------------------
    # Inner classes mirroring openai.OpenAI.chat.completions
    # ------------------------------------------------------------------

    class _Chat:
        def __init__(self, parent: "DevTorchOpenAI") -> None:
            self._p = parent
            self.completions = DevTorchOpenAI._Completions(parent)

    class _Completions:
        def __init__(self, parent: "DevTorchOpenAI") -> None:
            self._p = parent

        def create(
            self,
            *,
            messages: list,
            stream: bool = False,
            **kwargs: Any,
        ) -> Any:
            """
            Inject RACP prefix as the first system message, call real API,
            capture response.

            For streaming responses returns a wrapper that passes chunks
            through and captures the accumulated text on completion.
            """
            session_id = str(uuid.uuid4())[:8]
            injected_messages = self._inject(list(messages))

            if stream:
                return self._stream_create(
                    messages=injected_messages,
                    session_id=session_id,
                    **kwargs,
                )

            # Non-streaming
            try:
                response = self._p._client.chat.completions.create(
                    messages=injected_messages,
                    stream=False,
                    **kwargs,
                )
            except Exception:
                raise

            self._capture_response(response, session_id)

            # Strip RACP blocks from the choice message content
            try:
                response = self._strip_response(response)
            except Exception as exc:
                logger.warning("devtorch: strip_response failed — %s", exc)

            return response

        # --------------------------------------------------------------
        # Streaming helper
        # --------------------------------------------------------------

        def _stream_create(
            self,
            *,
            messages: list,
            session_id: str,
            **kwargs: Any,
        ) -> "_OpenAIStreamingWrapper":
            raw_stream = self._p._client.chat.completions.create(
                messages=messages,
                stream=True,
                **kwargs,
            )
            return _OpenAIStreamingWrapper(raw_stream, self, session_id)

        # --------------------------------------------------------------
        # Injection
        # --------------------------------------------------------------

        def _inject(self, messages: list) -> list:
            if self._p._injector and not is_disabled():
                try:
                    prefix = self._p._injector.build_system_prefix()
                    if prefix:
                        system_msg = {"role": "system", "content": prefix}
                        return [system_msg] + messages
                except Exception as exc:
                    logger.warning("devtorch: RACP injection failed — %s", exc)
            return messages

        # --------------------------------------------------------------
        # Capture
        # --------------------------------------------------------------

        def _capture_response(self, response: Any, session_id: str) -> None:
            if not self._p._capture or is_disabled():
                return
            try:
                text = _extract_text(response)

                # Thinking blocks — build a response dict for the parser
                thinking: list = []
                try:
                    from devtorch_core.parser.thinking import extract_thinking_blocks

                    if hasattr(response, "model_dump"):
                        response_dict = response.model_dump()
                    elif isinstance(response, dict):
                        response_dict = response
                    else:
                        response_dict = {}
                    thinking = extract_thinking_blocks(response_dict)
                except Exception:
                    pass

                self._p._capture.capture(text, thinking, session_id)
            except Exception as exc:
                logger.warning("devtorch: _capture_response failed — %s", exc)

        # --------------------------------------------------------------
        # Strip
        # --------------------------------------------------------------

        def _strip_response(self, response: Any) -> Any:
            from devtorch_core.parser.blocks import strip_racp_blocks

            try:
                choices = getattr(response, "choices", None)
                if choices:
                    for choice in choices:
                        msg = getattr(choice, "message", None)
                        if msg and isinstance(getattr(msg, "content", None), str):
                            msg.content = strip_racp_blocks(msg.content)
            except Exception as exc:
                logger.warning("devtorch: strip_response failed — %s", exc)
            return response


# ---------------------------------------------------------------------------
# Streaming wrapper
# ---------------------------------------------------------------------------


class _OpenAIStreamingWrapper:
    """
    Thin wrapper around the raw OpenAI streaming response.
    Accumulates text while yielding chunks, then fires capture on close.
    """

    def __init__(
        self,
        raw_stream: Any,
        completions_obj: "DevTorchOpenAI._Completions",
        session_id: str,
    ) -> None:
        self._raw = raw_stream
        self._comps = completions_obj
        self._session_id = session_id
        self._accumulated_text = ""

    def __iter__(self) -> Iterator[Any]:
        try:
            for chunk in self._raw:
                try:
                    delta = chunk.choices[0].delta if chunk.choices else None
                    if delta and hasattr(delta, "content") and delta.content:
                        self._accumulated_text += delta.content
                except Exception:
                    pass
                yield chunk
        finally:
            self._on_close()

    def __enter__(self) -> "_OpenAIStreamingWrapper":
        if hasattr(self._raw, "__enter__"):
            self._raw.__enter__()
        return self

    def __exit__(self, *args: Any) -> None:
        try:
            if hasattr(self._raw, "__exit__"):
                self._raw.__exit__(*args)
        finally:
            self._on_close()

    def _on_close(self) -> None:
        if self._accumulated_text:
            try:
                self._comps._p._capture.capture(
                    self._accumulated_text, [], self._session_id
                )
            except Exception as exc:
                logger.warning("devtorch: stream capture failed — %s", exc)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _extract_text(response: Any) -> str:
    """Pull plain text from an OpenAI chat completion response."""
    text = ""
    try:
        choices = getattr(response, "choices", None)
        if choices:
            msg = choices[0].message
            if isinstance(getattr(msg, "content", None), str):
                text += msg.content
            # o1/o3 reasoning_content
            reasoning = getattr(msg, "reasoning_content", None)
            if isinstance(reasoning, str):
                text += "\n" + reasoning
    except Exception:
        pass
    return text
