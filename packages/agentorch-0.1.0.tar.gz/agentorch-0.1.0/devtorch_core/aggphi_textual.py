"""
Sprint 8 — Textual Mode Aggφ (LLM-assisted + confidence-weighted aggregation).

Provides:
- :class:`ConfidenceWeightedAggPhi` — deterministic aggregation: recency weighting
  multiplied by a confidence signal weight (low-confidence events contribute less).
- :class:`TextualModeAggPhi` — uses confidence-weighted aggregation; optionally
  refines the per-concept delta via Anthropic when ``DEVTORCH_AGGPHI_LLM=1`` and
  credentials are available; otherwise identical to the weighted path.
- :func:`near_duplicate_pairs` — detects near-duplicate concept names for I3
  handshake (does not merge keys automatically).

Environment
---------
DEVTORCH_AGGPHI       — ``rules`` (default) | ``textual`` — select aggregator in
                        :func:`devtorch_core.theta.make_theta_store`.
DEVTORCH_AGGPHI_LLM   — ``1``/``true`` to enable optional LLM refinement inside
                        :class:`TextualModeAggPhi` (falls back on any error).
DEVTORCH_DISABLE      — if set, LLM refinement is skipped.
"""

from __future__ import annotations

import json
import logging
import os
import re
from difflib import SequenceMatcher
from typing import Dict, List, Optional

from .theta import AggPhi

logger = logging.getLogger("devtorch.aggphi_textual")

_LEVEL_RANK: Dict[str, int] = {"PUBLIC": 0, "PROTECTED": 1, "PRIVATE": 2}
_RANK_LEVEL: Dict[int, str] = {0: "PUBLIC", 1: "PROTECTED", 2: "PRIVATE"}

# ---------------------------------------------------------------------------
# Near-duplicate detection (I3 handshake candidates)
# ---------------------------------------------------------------------------


def near_duplicate_pairs(
    concepts: List[str],
    *,
    threshold: float = 0.82,
) -> List[dict]:
    """
    Return pairs of concept names whose normalised string similarity is >=
    *threshold* (SequenceMatcher ratio on lowercased names).

    Each item:
        ``concept_a``, ``concept_b`` (lexicographic order), ``similarity``,
        ``requires_i3_handshake``: True
    """
    unique = sorted({c for c in concepts if c and str(c).strip()})
    out: List[dict] = []
    seen: set[tuple[str, str]] = set()
    for i, a in enumerate(unique):
        for b in unique[i + 1 :]:
            if a == b:
                continue
            ratio = SequenceMatcher(None, a.lower(), b.lower()).ratio()
            if ratio < threshold:
                continue
            key = (a, b) if a < b else (b, a)
            if key in seen:
                continue
            seen.add(key)
            ca, cb = key
            out.append(
                {
                    "concept_a": ca,
                    "concept_b": cb,
                    "similarity": round(ratio, 4),
                    "requires_i3_handshake": True,
                }
            )
    return out


def merge_i3_records(existing: List[dict], incoming: List[dict]) -> List[dict]:
    """Union by unordered pair (concept_a, concept_b); keep highest similarity."""
    by_pair: dict[tuple[str, str], dict] = {}
    for row in existing + incoming:
        a = row.get("concept_a", "")
        b = row.get("concept_b", "")
        if not a or not b:
            continue
        key = tuple(sorted((a, b)))
        prev = by_pair.get(key)
        if prev is None or float(row.get("similarity", 0)) > float(
            prev.get("similarity", 0)
        ):
            by_pair[key] = row
    return sorted(by_pair.values(), key=lambda r: (-r.get("similarity", 0), r["concept_a"]))


# ---------------------------------------------------------------------------
# Confidence-weighted Aggφ (deterministic)
# ---------------------------------------------------------------------------


class ConfidenceWeightedAggPhi(AggPhi):
    """
    Like the rules-based aggregator (group by concept, recency 2×/1×), but each
    event's contribution is also scaled by ``max(ε, confidence)**exponent`` so
    inferred/low-confidence signals move Θ less than explicit high-confidence ones.
    """

    def __init__(self, confidence_exponent: float = 1.5, epsilon: float = 0.05) -> None:
        self.confidence_exponent = confidence_exponent
        self.epsilon = epsilon

    def aggregate(self, events: List[dict]) -> Dict[str, dict]:
        grouped: Dict[str, List[dict]] = {}
        for ev in events:
            concept = ev.get("target_concept", "unknown")
            grouped.setdefault(concept, []).append(ev)

        result: Dict[str, dict] = {}
        for concept, group in grouped.items():
            sorted_group = sorted(
                group,
                key=lambda e: e.get("created_at", ""),
                reverse=True,
            )
            total_w = 0.0
            weighted_conf_sum = 0.0
            max_rank = 0

            for i, ev in enumerate(sorted_group):
                recency_w = 2.0 if i == 0 else 1.0
                conf = float(ev.get("confidence", 0.5))
                sig = max(self.epsilon, conf) ** self.confidence_exponent
                w = recency_w * sig
                weighted_conf_sum += conf * w
                total_w += w

                rank = _LEVEL_RANK.get(ev.get("disclosure_level", "PUBLIC"), 0)
                if rank > max_rank:
                    max_rank = rank

            mean_conf = weighted_conf_sum / total_w if total_w else 0.0
            result[concept] = {
                "mean_confidence": round(mean_conf, 6),
                "disclosure_level": _RANK_LEVEL[max_rank],
                "event_count": len(group),
            }
        return result


# ---------------------------------------------------------------------------
# Optional LLM refinement (structured JSON)
# ---------------------------------------------------------------------------

_LLM_JSON_RE = re.compile(r"\{[\s\S]*\}")


def _try_llm_synthesize_delta(events: List[dict]) -> Optional[Dict[str, dict]]:
    """
    Ask the model to emit a JSON object mapping concept -> {mean_confidence,
    disclosure_level, event_count}. Returns None if unavailable or invalid.
    """
    if os.environ.get("DEVTORCH_DISABLE", "").strip().lower() in ("1", "true", "yes"):
        return None
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return None
    try:
        import anthropic  # noqa: PLC0415
    except ImportError:
        return None

    payload = json.dumps(events, indent=2, sort_keys=True)[:12000]
    prompt = (
        "You are a governance engine aggregating sensitivity events into a "
        "coordination vector Θ. Given the JSON list of events below, output "
        "**only** a single JSON object (no markdown) whose keys are "
        "target_concept strings and values are objects with:\n"
        '  "mean_confidence": float in [0,1],\n'
        '  "disclosure_level": one of PUBLIC, PROTECTED, PRIVATE,\n'
        '  "event_count": positive integer (count of events merged into that concept).\n'
        "Aggregate semantically: same meaning under different wording should map "
        "to one concept key when obvious; otherwise keep distinct keys.\n\n"
        f"EVENTS:\n{payload}"
    )

    try:
        client = anthropic.Anthropic()
        resp = client.messages.create(
            model=os.environ.get("DEVTORCH_AGGPHI_MODEL", "claude-3-5-haiku-20241022"),
            max_tokens=4096,
            temperature=0.0,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = resp.content[0].text
    except Exception as exc:
        logger.warning("devtorch Aggφ LLM call failed — %s", exc)
        return None

    m = _LLM_JSON_RE.search(raw)
    if not m:
        logger.warning("devtorch Aggφ LLM: no JSON object in response")
        return None
    try:
        obj = json.loads(m.group(0))
    except json.JSONDecodeError as exc:
        logger.warning("devtorch Aggφ LLM: JSON parse error — %s", exc)
        return None

    if not isinstance(obj, dict):
        return None

    out: Dict[str, dict] = {}
    for concept, entry in obj.items():
        if not isinstance(concept, str) or not isinstance(entry, dict):
            continue
        try:
            mc = float(entry.get("mean_confidence", 0.0))
            dl = str(entry.get("disclosure_level", "PUBLIC")).upper()
            ec = int(entry.get("event_count", 1))
        except (TypeError, ValueError):
            continue
        if dl not in _LEVEL_RANK:
            dl = "PUBLIC"
        mc = max(0.0, min(1.0, mc))
        ec = max(1, ec)
        out[concept] = {
            "mean_confidence": round(mc, 6),
            "disclosure_level": dl,
            "event_count": ec,
        }

    return out if out else None


# ---------------------------------------------------------------------------
# Textual Mode Aggφ (S8 facade)
# ---------------------------------------------------------------------------


class TextualModeAggPhi(AggPhi):
    """
    Sprint 8 default: confidence-weighted aggregation, optional LLM refinement,
    and I3 near-duplicate tracking (via :class:`ThetaStore` when this class is used
    as the aggregator).
    """

    records_i3_merge_candidates = True
    similarity_threshold = 0.82

    def __init__(
        self,
        *,
        inner: Optional[ConfidenceWeightedAggPhi] = None,
        use_llm: Optional[bool] = None,
    ) -> None:
        self._inner = inner if inner is not None else ConfidenceWeightedAggPhi()
        self._use_llm = use_llm

    def aggregate(self, events: List[dict]) -> Dict[str, dict]:
        use_llm = self._use_llm
        if use_llm is None:
            use_llm = os.environ.get("DEVTORCH_AGGPHI_LLM", "").strip().lower() in (
                "1",
                "true",
                "yes",
            )

        if use_llm:
            llm_delta = _try_llm_synthesize_delta(events)
            if llm_delta is not None:
                return llm_delta

        return self._inner.aggregate(events)
