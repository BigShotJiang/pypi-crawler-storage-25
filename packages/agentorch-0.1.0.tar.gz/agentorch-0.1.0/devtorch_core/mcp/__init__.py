"""
DevTorch MCP server package.

Exposes DevTorch primitives as Model Context Protocol tools that
Claude Code can call natively.
"""

from .server import main, find_gcc_repo

__all__ = ["main", "find_gcc_repo"]
