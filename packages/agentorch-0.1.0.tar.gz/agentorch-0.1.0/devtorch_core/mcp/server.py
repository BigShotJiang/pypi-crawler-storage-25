"""
S7 MCP Server — DevTorch primitives exposed via JSON-RPC 2.0 / MCP protocol.

Supports two transports:
- If the `mcp` SDK is installed: uses mcp.server.Server + stdio_server
- Fallback: raw JSON-RPC 2.0 line-by-line stdio loop

Tools exposed:
  devtorch_commit          — Commit a reasoning milestone to .GCC/
  devtorch_sensitivity_add — Record a sensitivity signal
  devtorch_context         — Retrieve bounded context bundle
  devtorch_theta_read      — Read coordination vector Θ
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Tool definitions (shared between MCP-SDK path and fallback path)
# ---------------------------------------------------------------------------

TOOLS: List[Dict[str, Any]] = [
    {
        "name": "devtorch_commit",
        "description": "Commit a reasoning milestone to the .GCC/ store",
        "inputSchema": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "Commit message"},
                "branch": {
                    "type": "string",
                    "description": "Branch name (optional)",
                },
            },
            "required": ["message"],
        },
    },
    {
        "name": "devtorch_sensitivity_add",
        "description": "Record what this decision depends on (sensitivity signal)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "concept": {"type": "string", "description": "Target concept"},
                "signal": {
                    "type": "string",
                    "description": "Signal / counterfactual text",
                },
                "confidence": {
                    "type": "number",
                    "description": "Confidence in [0, 1]",
                },
                "disclosure": {
                    "type": "string",
                    "description": "Disclosure level: PUBLIC, PROTECTED (default), or PRIVATE",
                },
            },
            "required": ["concept", "signal", "confidence"],
        },
    },
    {
        "name": "devtorch_context",
        "description": "Retrieve bounded context bundle from .GCC/ (use this at session start)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "k": {
                    "type": "integer",
                    "description": "Token budget (default 8000)",
                },
            },
        },
    },
    {
        "name": "devtorch_theta_read",
        "description": "Read current coordination vector Θ (shared sensitivity state)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "concepts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter to specific concepts (optional)",
                },
            },
        },
    },
]

# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------


def _tool_devtorch_commit(repo: Any, args: dict) -> str:
    message = args.get("message", "")
    repo.commit(message=message)
    return "Committed to .GCC/"


def _tool_devtorch_sensitivity_add(repo: Any, args: dict) -> str:
    from devtorch_core.sensitivity import SensitivityEvent

    concept = args["concept"]
    signal = args["signal"]
    confidence = float(args["confidence"])
    disclosure = args.get("disclosure", "PROTECTED").upper()
    if disclosure not in ("PUBLIC", "PROTECTED", "PRIVATE"):
        disclosure = "PROTECTED"

    ev = SensitivityEvent(
        source_node="mcp-client",
        target_concept=concept,
        counterfactuals=signal,
        confidence=confidence,
        disclosure_level=disclosure,
        message=signal,
    )
    repo.add_sensitivity(ev)
    return f"Sensitivity recorded: {concept} @ {confidence}"


def _tool_devtorch_context(repo: Any, args: dict) -> str:
    k = int(args.get("k", 8000))
    bundle = repo.context_bundle(
        k_tokens=k, policy={"sensitivity_policy": "default"}
    )
    # bundle is a dict; format it as a readable string
    artifacts = bundle.get("artifacts", [])
    if not artifacts:
        return f"Context bundle (budget={k} tokens): no artifacts found."

    lines = [f"Context bundle (budget={k} tokens, {len(artifacts)} artifacts):"]
    for art in artifacts:
        # Support both "name" (test mock) and "path" (real GCCRepository output)
        name = art.get("name", art.get("path", art.get("id", "unknown")))
        reason = art.get("reason", "")
        # Support both "tokens" (test mock) and "approx_tokens" (real GCCRepository output)
        tokens = art.get("tokens", art.get("approx_tokens", "?"))
        lines.append(f"  - {name} ({tokens} tokens): {reason}")
    return "\n".join(lines)


def _tool_devtorch_theta_read(repo: Any, args: dict) -> str:
    theta = repo.get_theta().get("coordination_vector", {})
    concepts = args.get("concepts")
    if concepts:
        theta = {k: v for k, v in theta.items() if k in concepts}
    return json.dumps(theta, indent=2)


def _dispatch_tool(repo: Any, name: str, args: dict) -> str:
    if name == "devtorch_commit":
        return _tool_devtorch_commit(repo, args)
    elif name == "devtorch_sensitivity_add":
        return _tool_devtorch_sensitivity_add(repo, args)
    elif name == "devtorch_context":
        return _tool_devtorch_context(repo, args)
    elif name == "devtorch_theta_read":
        return _tool_devtorch_theta_read(repo, args)
    else:
        raise ValueError(f"Unknown tool: {name}")


# ---------------------------------------------------------------------------
# MCP SDK path
# ---------------------------------------------------------------------------


def _run_with_sdk(repo: Any) -> None:
    """Run using the official mcp Python SDK."""
    import asyncio
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    import mcp.types as types

    server = Server("devtorch")

    @server.list_tools()  # type: ignore[misc]
    async def list_tools() -> List[types.Tool]:
        result = []
        for t in TOOLS:
            result.append(
                types.Tool(
                    name=t["name"],
                    description=t["description"],
                    inputSchema=t["inputSchema"],
                )
            )
        return result

    @server.call_tool()  # type: ignore[misc]
    async def call_tool(
        name: str, arguments: dict
    ) -> List[types.TextContent]:
        try:
            text = _dispatch_tool(repo, name, arguments or {})
        except Exception as exc:
            text = f"Error: {exc}"
        return [types.TextContent(type="text", text=text)]

    async def _run() -> None:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# Minimal JSON-RPC 2.0 fallback
# ---------------------------------------------------------------------------

_JSONRPC_VERSION = "2.0"


def _make_response(id: Any, result: Any) -> dict:
    return {"jsonrpc": _JSONRPC_VERSION, "id": id, "result": result}


def _make_error(id: Any, code: int, message: str) -> dict:
    return {
        "jsonrpc": _JSONRPC_VERSION,
        "id": id,
        "error": {"code": code, "message": message},
    }


def _handle_request(repo: Any, req: dict) -> Optional[dict]:
    """Dispatch a single JSON-RPC request and return the response dict (or None for notifications)."""
    req_id = req.get("id")
    method = req.get("method", "")
    params = req.get("params") or {}

    # Notifications (no id) — process but no response
    is_notification = "id" not in req

    if method == "initialize":
        result = {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "devtorch", "version": "0.7.0"},
        }
        if is_notification:
            return None
        return _make_response(req_id, result)

    elif method == "notifications/initialized":
        return None  # no response for notifications

    elif method == "tools/list":
        result = {"tools": TOOLS}
        if is_notification:
            return None
        return _make_response(req_id, result)

    elif method == "tools/call":
        name = params.get("name", "")
        arguments = params.get("arguments") or {}
        try:
            text = _dispatch_tool(repo, name, arguments)
            result = {
                "content": [{"type": "text", "text": text}],
                "isError": False,
            }
        except Exception as exc:
            result = {
                "content": [{"type": "text", "text": f"Error: {exc}"}],
                "isError": True,
            }
        if is_notification:
            return None
        return _make_response(req_id, result)

    elif method == "ping":
        if is_notification:
            return None
        return _make_response(req_id, {})

    else:
        if is_notification:
            return None
        return _make_error(req_id, -32601, f"Method not found: {method}")


def _run_raw_stdio(repo: Any) -> None:
    """Minimal JSON-RPC 2.0 stdio loop (fallback when mcp SDK not installed)."""
    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        try:
            req = json.loads(raw_line)
        except json.JSONDecodeError as exc:
            resp = _make_error(None, -32700, f"Parse error: {exc}")
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
            continue

        try:
            resp = _handle_request(repo, req)
        except Exception as exc:
            resp = _make_error(req.get("id"), -32603, f"Internal error: {exc}")

        if resp is not None:
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()


# ---------------------------------------------------------------------------
# Server entry points
# ---------------------------------------------------------------------------


def run_server(repo: Any) -> None:
    """Run the MCP server using the best available transport."""
    try:
        import mcp  # noqa: F401
        _run_with_sdk(repo)
    except ImportError:
        _run_raw_stdio(repo)


def find_gcc_repo() -> Optional[Any]:
    """
    Find an initialised .GCC/ repository.

    Search order:
    1. DEVTORCH_GCC_PATH env var — explicit project root (used by IDE MCP configs)
    2. Walk upward from cwd
    """
    import os
    from devtorch_core import GCCRepository

    explicit = os.environ.get("DEVTORCH_GCC_PATH", "").strip()
    if explicit:
        r = GCCRepository.at(Path(explicit))
        if r.is_initialized():
            return r

    for parent in [Path.cwd()] + list(Path.cwd().parents):
        r = GCCRepository.at(parent)
        if r.is_initialized():
            return r
    return None


def main() -> None:
    """Entry point: devtorch mcp-server"""
    gcc = find_gcc_repo()
    if gcc is None:
        print(
            "error: no .GCC/ found in current directory or parents. "
            "Set DEVTORCH_GCC_PATH=/path/to/project to point to your project root.",
            file=sys.stderr,
        )
        sys.exit(1)
    run_server(gcc)
