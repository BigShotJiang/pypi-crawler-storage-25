"""
devtorch_core.parser.inference
================================
Heuristic inference of sensitivity signals and decision summaries from raw LLM
response text.

This is the *fallback* path used when the LLM did not emit explicit RACP
``<devtorch:sensitivity>`` or ``<devtorch:commit>`` blocks.  All inferred
results carry ``confidence=0.5`` to distinguish them from LLM-asserted values.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------

@dataclass
class InferredSensitivity:
    concept: str
    signal: str
    confidence: float = 0.5
    source: str = "inference_heuristic"


# ---------------------------------------------------------------------------
# Keyword → concept mapping
# ---------------------------------------------------------------------------

# Each entry is (compiled_pattern, concept_label).
_SENSITIVITY_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r'\b(schema|migration|database)\b', re.IGNORECASE), 'data_schema'),
    (re.compile(r'\b(auth|authentication|token|jwt|session)\b', re.IGNORECASE), 'authentication'),
    (re.compile(r'\b(api|endpoint|route|url)\b', re.IGNORECASE), 'api_interface'),
    (re.compile(r'\b(deploy|release|rollout|pipeline)\b', re.IGNORECASE), 'deployment'),
    (re.compile(r'\b(security|vulnerability|cve|injection)\b', re.IGNORECASE), 'security'),
    (re.compile(r'\b(performance|latency|throughput|cache)\b', re.IGNORECASE), 'performance'),
    (re.compile(r'\b(config|configuration|environment|env)\b', re.IGNORECASE), 'configuration'),
]

# Sentence boundary: split on . ! ? followed by whitespace or end-of-string.
_RE_SENTENCE_SPLIT = re.compile(r'(?<=[.!?])\s+')


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sentences(text: str) -> list[str]:
    """Split text into rough sentences."""
    return [s.strip() for s in _RE_SENTENCE_SPLIT.split(text) if s.strip()]


def _find_surrounding_sentence(text: str, match: re.Match[str]) -> str:
    """
    Return the sentence that contains the regex match, truncated to 120 chars.
    Falls back to the matched substring itself if no sentence boundary is found.
    """
    start = match.start()
    # Walk backwards to the previous sentence boundary (. ! ? or start of text).
    before = text[:start]
    sentence_start = max(
        before.rfind("."),
        before.rfind("!"),
        before.rfind("?"),
    )
    sentence_start = sentence_start + 1 if sentence_start != -1 else 0

    # Walk forwards to the next sentence boundary.
    after = text[start:]
    ends = [after.find(c) for c in ".!?" if after.find(c) != -1]
    sentence_end = start + min(ends) + 1 if ends else len(text)

    sentence = text[sentence_start:sentence_end].strip()
    return sentence[:120]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def infer_sensitivity(text: str, max_concepts: int = 2) -> list[InferredSensitivity]:
    """
    Heuristically infer sensitivity signals from response text.

    Scans *text* for keyword patterns defined in ``_SENSITIVITY_PATTERNS``.
    Returns up to *max_concepts* :class:`InferredSensitivity` objects.

    All results have ``confidence=0.5`` — this is the fallback path only.
    Signal text is the first 120 characters of the surrounding sentence.
    """
    if not text or not text.strip():
        return []

    results: list[InferredSensitivity] = []
    seen_concepts: set[str] = set()

    for pattern, concept in _SENSITIVITY_PATTERNS:
        if len(results) >= max_concepts:
            break
        if concept in seen_concepts:
            continue
        match = pattern.search(text)
        if match:
            signal = _find_surrounding_sentence(text, match)
            results.append(
                InferredSensitivity(
                    concept=concept,
                    signal=signal,
                )
            )
            seen_concepts.add(concept)

    return results


def extract_decision_summary(text: str, max_chars: int = 150) -> str:
    """
    Extract a short decision summary from the first meaningful sentence of text.

    Processing steps:

    1. Strip markdown formatting (headings, bold, italic, code fences,
       inline code, bullet markers).
    2. Find the first non-empty sentence.
    3. Truncate to *max_chars*.
    4. Prefix with ``"auto: "``.

    Returns ``"auto: (no content)"`` if *text* is empty or blank.
    """
    if not text or not text.strip():
        return "auto: (no content)"

    # Remove fenced code blocks.
    cleaned = re.sub(r"```[\s\S]*?```", " ", text)
    # Remove inline code.
    cleaned = re.sub(r"`[^`]*`", " ", cleaned)
    # Remove markdown headings.
    cleaned = re.sub(r"^#{1,6}\s+", "", cleaned, flags=re.MULTILINE)
    # Remove bold/italic markers (**text**, __text__, *text*, _text_).
    cleaned = re.sub(r"\*{1,3}([^*]+)\*{1,3}", r"\1", cleaned)
    cleaned = re.sub(r"_{1,3}([^_]+)_{1,3}", r"\1", cleaned)
    # Remove bullet / list markers.
    cleaned = re.sub(r"^\s*[-*+]\s+", "", cleaned, flags=re.MULTILINE)
    cleaned = re.sub(r"^\s*\d+\.\s+", "", cleaned, flags=re.MULTILINE)
    # Collapse whitespace.
    cleaned = " ".join(cleaned.split())

    # Extract first meaningful sentence.
    sentences = _RE_SENTENCE_SPLIT.split(cleaned)
    first = next((s.strip() for s in sentences if s.strip()), "")

    if not first:
        return "auto: (no content)"

    truncated = first[:max_chars].rstrip()
    return f"auto: {truncated}"
