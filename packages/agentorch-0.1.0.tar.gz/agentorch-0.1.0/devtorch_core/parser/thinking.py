"""
devtorch_core.parser.thinking
==============================
Normalise extended-thinking / reasoning content blocks returned by LLM APIs.

Supported formats
-----------------
Anthropic extended thinking
    ``response["content"]`` is a list of content blocks.  Blocks whose
    ``"type"`` equals ``"thinking"`` carry the reasoning text in
    ``block["thinking"]``.

OpenAI o1 / o3 reasoning
    ``response["choices"][0]["message"]["reasoning_content"]`` is a string
    containing the chain-of-thought the model produced before answering.

Standard models
    Neither format is present.  An empty list is returned.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------

@dataclass
class ThinkingBlock:
    text: str
    confidence: float = 1.0    # thinking tokens always conf=1.0
    source: str = "thinking_content"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_thinking_blocks(response: dict) -> list[ThinkingBlock]:
    """
    Extract thinking / reasoning content from an LLM API response dict.

    Anthropic format
        ``response["content"]`` is a list; items with ``type == "thinking"``
        have a ``"thinking"`` key with the text.

    OpenAI o1/o3 format
        ``response["choices"][0]["message"]["reasoning_content"]`` is a string.

    Returns a list of :class:`ThinkingBlock` objects (may be empty for
    standard non-reasoning models).
    """
    blocks: list[ThinkingBlock] = []

    # --- Anthropic format ---
    content = response.get("content")
    if isinstance(content, list):
        for item in content:
            if not isinstance(item, dict):
                continue
            if item.get("type") == "thinking":
                text = item.get("thinking", "")
                if text:
                    blocks.append(ThinkingBlock(text=str(text)))
        # If we found Anthropic-style blocks, return early — no need to also
        # scan OpenAI format.
        if blocks:
            return blocks

    # --- OpenAI o1/o3 format ---
    try:
        choices = response.get("choices")
        if isinstance(choices, list) and choices:
            message = choices[0].get("message", {})
            reasoning = message.get("reasoning_content")
            if reasoning and isinstance(reasoning, str):
                blocks.append(
                    ThinkingBlock(
                        text=reasoning,
                        source="reasoning_content",
                    )
                )
    except (AttributeError, IndexError, KeyError) as exc:
        logger.warning("devtorch parser: error reading OpenAI reasoning_content — %s", exc)

    return blocks


def thinking_to_commit_message(
    blocks: list[ThinkingBlock],
    max_chars: int = 200,
) -> str:
    """
    Summarise thinking blocks into a short commit message.

    Takes the first *max_chars* characters of the first block's text (newlines
    stripped/collapsed).  Returns a string prefixed with ``"auto: "``.

    If *blocks* is empty, returns ``"auto: (no thinking content)"``.
    """
    if not blocks:
        return "auto: (no thinking content)"

    text = blocks[0].text
    # Collapse whitespace and newlines into single spaces.
    text = " ".join(text.split())
    truncated = text[:max_chars].rstrip()
    return f"auto: {truncated}"
