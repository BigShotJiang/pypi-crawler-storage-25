"""
devtorch_core.parser.blocks
===========================
Extract and strip RACP-structured XML blocks emitted by LLMs that have been
instructed with the DevTorch system prompt.

LLM output formats handled
---------------------------
Self-closing tags::

    <devtorch:commit message="migrate schema to v3" confidence="0.9"/>
    <devtorch:sensitivity concept="schema_version"
                          signal="migration collapses if format changes"
                          confidence="0.91"
                          disclosure="PROTECTED"/>

Strategy
--------
1. Regex locates the raw tag strings in the text (tolerates attribute-order
   variation and minor whitespace differences).
2. ``xml.etree.ElementTree`` parses each located string for attribute values.
3. Malformed tags are logged and skipped — never raised to the caller.
"""
from __future__ import annotations

import logging
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class CommitBlock:
    message: str
    confidence: float = 0.9


@dataclass
class SensitivityBlock:
    concept: str
    signal: str
    confidence: float = 0.9
    disclosure: str = "PROTECTED"


# ---------------------------------------------------------------------------
# Internal regex patterns
# ---------------------------------------------------------------------------

# Matches self-closing <devtorch:commit ... /> tags.
_RE_COMMIT = re.compile(
    r"<devtorch:commit\b([^>]*?)/>",
    re.DOTALL | re.IGNORECASE,
)

# Matches self-closing <devtorch:sensitivity ... /> tags.
_RE_SENSITIVITY = re.compile(
    r"<devtorch:sensitivity\b([^>]*?)/>",
    re.DOTALL | re.IGNORECASE,
)

# Matches any paired <devtorch:*>...</devtorch:*> tags (for strip).
_RE_PAIRED = re.compile(
    r"<devtorch:[^>]+>.*?</devtorch:[^>]+>",
    re.DOTALL | re.IGNORECASE,
)

# Matches all self-closing devtorch tags (for strip).
_RE_SELF_CLOSING = re.compile(
    r"<devtorch:\w[\w:.-]*\b[^>]*?/>",
    re.DOTALL | re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_tag(raw: str) -> ET.Element | None:
    """
    Parse a raw XML tag string via ElementTree.

    The tag may use namespace prefixes (``devtorch:commit``) which are not
    valid bare XML without a namespace declaration.  We normalise the prefix
    to a plain element name so ElementTree can handle it.

    Returns the parsed Element, or None on error.
    """
    # Normalise namespace prefix: devtorch:foo -> devtorch_foo
    normalised = re.sub(r"<(/?)\s*devtorch:", r"<\1devtorch_", raw)
    try:
        return ET.fromstring(normalised)
    except ET.ParseError as exc:
        logger.warning("devtorch parser: malformed tag skipped — %s | raw=%r", exc, raw)
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_racp_blocks(
    text: str,
) -> tuple[list[CommitBlock], list[SensitivityBlock]]:
    """
    Extract all ``<devtorch:commit>`` and ``<devtorch:sensitivity>`` blocks
    from *text*.

    Uses regex to locate tag boundaries, then ``xml.etree.ElementTree`` to
    parse attribute values.  Attribute order variations and minor whitespace
    are handled gracefully.  Malformed tags are logged and skipped.

    Returns
    -------
    (commit_blocks, sensitivity_blocks)
    """
    commits: list[CommitBlock] = []
    sensitivities: list[SensitivityBlock] = []

    # --- commit blocks ---
    for match in _RE_COMMIT.finditer(text):
        raw_tag = match.group(0)
        elem = _parse_tag(raw_tag)
        if elem is None:
            continue
        message = elem.get("message")
        if not message:
            logger.warning("devtorch parser: <devtorch:commit> missing 'message' attribute — skipped | raw=%r", raw_tag)
            continue
        try:
            confidence = float(elem.get("confidence", 0.9))
        except (ValueError, TypeError):
            logger.warning("devtorch parser: invalid confidence value in commit block — defaulting to 0.9")
            confidence = 0.9
        commits.append(CommitBlock(message=message, confidence=confidence))

    # --- sensitivity blocks ---
    for match in _RE_SENSITIVITY.finditer(text):
        raw_tag = match.group(0)
        elem = _parse_tag(raw_tag)
        if elem is None:
            continue
        concept = elem.get("concept")
        signal = elem.get("signal")
        if not concept or not signal:
            logger.warning(
                "devtorch parser: <devtorch:sensitivity> missing required attributes — skipped | raw=%r",
                raw_tag,
            )
            continue
        try:
            confidence = float(elem.get("confidence", 0.9))
        except (ValueError, TypeError):
            logger.warning("devtorch parser: invalid confidence value in sensitivity block — defaulting to 0.9")
            confidence = 0.9
        disclosure = elem.get("disclosure", "PROTECTED")
        sensitivities.append(
            SensitivityBlock(
                concept=concept,
                signal=signal,
                confidence=confidence,
                disclosure=disclosure,
            )
        )

    return commits, sensitivities


def strip_racp_blocks(text: str) -> str:
    """
    Remove all ``<devtorch:commit .../>``, ``<devtorch:sensitivity .../>``,
    and any ``<devtorch:*>...</devtorch:*>`` paired tags from *text*.

    Returns clean text suitable for presentation to the user/caller.
    Surrounding whitespace is collapsed but the overall structure is preserved.
    """
    # Remove paired tags first (they span more characters).
    cleaned = _RE_PAIRED.sub("", text)
    # Remove self-closing tags.
    cleaned = _RE_SELF_CLOSING.sub("", cleaned)
    # Collapse runs of blank lines that may have been left behind.
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()
