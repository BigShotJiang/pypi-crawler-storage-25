"""
devtorch_core.parser
====================
Shared parser foundation for the S7 LLM Wrapper layer.

Extracts structured data from LLM responses:

* **blocks** — RACP XML blocks (``<devtorch:commit>``, ``<devtorch:sensitivity>``)
* **thinking** — extended-thinking / reasoning content blocks
* **inference** — heuristic fallback when no explicit RACP blocks were emitted
"""
from .blocks import extract_racp_blocks, strip_racp_blocks, CommitBlock, SensitivityBlock
from .thinking import extract_thinking_blocks, thinking_to_commit_message, ThinkingBlock
from .inference import infer_sensitivity, extract_decision_summary, InferredSensitivity

__all__ = [
    # blocks
    "extract_racp_blocks",
    "strip_racp_blocks",
    "CommitBlock",
    "SensitivityBlock",
    # thinking
    "extract_thinking_blocks",
    "thinking_to_commit_message",
    "ThinkingBlock",
    # inference
    "infer_sensitivity",
    "extract_decision_summary",
    "InferredSensitivity",
]
