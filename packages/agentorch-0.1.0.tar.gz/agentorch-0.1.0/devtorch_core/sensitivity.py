"""
Sprint 3 – Sensitivity schema and storage.

SensitivityEvent captures a single sensitivity observation emitted by a
reasoning node, including an optional numerical value, confidence, and a
disclosure level (PUBLIC / PROTECTED / PRIVATE).

SensitivityStore persists events as an append-only JSONL file under
`.GCC/sensitivities/events.jsonl` and maintains a concept-keyed index at
`.GCC/sensitivities/index.json` so callers can filter without full scans.
"""

from __future__ import annotations

import dataclasses
import datetime as _dt
import json
import uuid
from pathlib import Path
from typing import List, Optional


DISCLOSURE_LEVELS = ("PUBLIC", "PROTECTED", "PRIVATE")


@dataclasses.dataclass
class SensitivityEvent:
    """
    A single sensitivity observation.

    Fields
    ------
    source_node       : Identifier of the reasoning node that emitted this event.
    target_concept    : The concept/variable whose sensitivity is being reported.
    counterfactuals   : Free-text description of the counterfactual question.
    confidence        : Confidence in the sensitivity estimate; float in [0, 1].
    disclosure_level  : One of PUBLIC, PROTECTED, PRIVATE.
    numerical_value   : Optional point-estimate of the sensitivity magnitude.
    uncertainty       : Optional ±uncertainty for numerical_value.
    message           : Human-readable annotation.
    event_id          : UUID assigned on creation.
    created_at        : ISO-8601 UTC timestamp.
    """

    source_node: str
    target_concept: str
    counterfactuals: str
    confidence: float
    disclosure_level: str
    numerical_value: Optional[float] = None
    uncertainty: Optional[float] = None
    message: str = ""
    event_id: str = dataclasses.field(
        default_factory=lambda: str(uuid.uuid4())
    )
    created_at: str = dataclasses.field(
        default_factory=lambda: _dt.datetime.now(tz=_dt.timezone.utc).isoformat()
    )

    def __post_init__(self) -> None:
        if self.disclosure_level not in DISCLOSURE_LEVELS:
            raise ValueError(
                f"disclosure_level must be one of {DISCLOSURE_LEVELS}, "
                f"got '{self.disclosure_level}'"
            )
        if not (0.0 <= self.confidence <= 1.0):
            raise ValueError(
                f"confidence must be in [0, 1], got {self.confidence}"
            )
        if not self.source_node.strip():
            raise ValueError("source_node must not be empty.")
        if not self.target_concept.strip():
            raise ValueError("target_concept must not be empty.")

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "SensitivityEvent":
        known = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in known})


class SensitivityStore:
    """
    Append-only storage for SensitivityEvent objects.

    Layout (relative to the `.GCC/sensitivities/` directory):
      events.jsonl  – one JSON object per line, ordered by insertion.
      index.json    – concept_name → [event_id, …], rebuilt on every write.
    """

    EVENTS_FILE = "events.jsonl"
    INDEX_FILE = "index.json"

    def __init__(self, sensitivities_dir: Path) -> None:
        self.dir = sensitivities_dir

    def _ensure_dir(self) -> None:
        self.dir.mkdir(parents=True, exist_ok=True)

    @property
    def events_path(self) -> Path:
        return self.dir / self.EVENTS_FILE

    @property
    def index_path(self) -> Path:
        return self.dir / self.INDEX_FILE

    # ------------------------------------------------------------------
    # Internal index helpers
    # ------------------------------------------------------------------

    def _load_index(self) -> dict:
        if not self.index_path.exists():
            return {}
        try:
            return json.loads(self.index_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def _save_index(self, index: dict) -> None:
        self.index_path.write_text(
            json.dumps(index, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add(self, event: SensitivityEvent) -> str:
        """Persist *event* and update the concept index. Returns event_id."""
        self._ensure_dir()
        with self.events_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(event.to_dict(), sort_keys=True) + "\n")

        index = self._load_index()
        index.setdefault(event.target_concept, []).append(event.event_id)
        self._save_index(index)
        return event.event_id

    def list_all(self) -> List[SensitivityEvent]:
        """Return all stored events in insertion order."""
        if not self.events_path.exists():
            return []
        events: List[SensitivityEvent] = []
        with self.events_path.open("r", encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line:
                    continue
                try:
                    events.append(SensitivityEvent.from_dict(json.loads(line)))
                except (json.JSONDecodeError, TypeError, ValueError):
                    pass
        return events

    def filter(
        self,
        concept: Optional[str] = None,
        disclosure_level: Optional[str] = None,
        source_node: Optional[str] = None,
    ) -> List[SensitivityEvent]:
        """
        Return events that match *all* provided filter criteria.
        Any criterion that is None is treated as a wildcard.
        """
        events = self.list_all()
        if concept is not None:
            events = [e for e in events if e.target_concept == concept]
        if disclosure_level is not None:
            events = [e for e in events if e.disclosure_level == disclosure_level]
        if source_node is not None:
            events = [e for e in events if e.source_node == source_node]
        return events

    def concepts(self) -> List[str]:
        """Return all distinct concept names seen so far."""
        return sorted(self._load_index().keys())
