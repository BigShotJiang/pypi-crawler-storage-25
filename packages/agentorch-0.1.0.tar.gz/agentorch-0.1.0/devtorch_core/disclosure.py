"""
Sprint 5 – A4: Textual disclosure policy, [PRIVATE] suppression, fixed-length padding, receiver mandate.

[PRIVATE] marker rules (category/count suppression); fixed-length padding; receiver non-zero constraint.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

PRIVATE_MARKER = "[PRIVATE]"
DEFAULT_PADDING_LENGTH = 32
DEFAULT_PADDING_CHAR = "█"


@dataclass
class DisclosurePolicy:
    """Configuration for disclosure and padding."""
    suppress_private: bool = True
    padding_length: int = DEFAULT_PADDING_LENGTH
    padding_char: str = DEFAULT_PADDING_CHAR
    receiver_mandate_nonzero: bool = True  # [PRIVATE] must be treated as non-zero in downstream metadata

    def redact_private(self, text: str) -> str:
        """Replace [PRIVATE] spans with fixed-length padding."""
        if not self.suppress_private:
            return text
        # Replace each [PRIVATE] ... (until next [PRIVATE] or end) or bare [PRIVATE] with padding
        placeholder = self.padding_char * self.padding_length
        # Match [PRIVATE] optionally followed by content until next [PRIVATE] or end of string
        pattern = r"\[PRIVATE\](?:\s*[^\[]*?)?(?=\[PRIVATE\]|$)"
        return re.sub(pattern, placeholder, text, flags=re.DOTALL)

    def count_private_markers(self, text: str) -> int:
        """Count occurrences of [PRIVATE] for receiver mandate (non-zero constraint)."""
        return len(re.findall(re.escape(PRIVATE_MARKER), text))


def apply_disclosure_policy(text: str, policy: Optional[DisclosurePolicy] = None) -> str:
    """Apply disclosure policy: suppress [PRIVATE] with padding."""
    if policy is None:
        policy = DisclosurePolicy()
    return policy.redact_private(text)


def receiver_mandate_private_count(text: str) -> int:
    """Return count of [PRIVATE] markers; downstream must treat as non-zero (do not ignore)."""
    return len(re.findall(re.escape(PRIVATE_MARKER), text))
