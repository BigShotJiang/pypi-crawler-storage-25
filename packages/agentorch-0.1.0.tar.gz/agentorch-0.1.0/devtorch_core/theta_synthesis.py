"""
Textual Mode AggPhi — LLM-powered Θ synthesis.

Generates a human-readable summary of the top Θ concepts and writes
it to theta.json as `textual_summary`. This is gated by A1 (capability
check) and can be disabled via DEVTORCH_DISABLE env var.
"""

from __future__ import annotations

import dataclasses
import os
from typing import Optional


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class ThetaSynthesisConfig:
    """Configuration for the Textual Mode AggPhi synthesis step."""

    max_concepts: int = 10
    max_summary_chars: int = 500
    model: str = "claude-haiku-4-5-20251001"
    temperature: float = 0.3


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class ThetaSynthesisResult:
    """Result returned by synthesise_theta and run_synthesis_if_eligible."""

    summary: str
    concepts_used: list
    model: str
    tokens_used: int
    skipped: bool = False
    skip_reason: str = ""


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def build_synthesis_prompt(theta_vector: dict, max_concepts: int = 10) -> str:
    """
    Build an LLM prompt that asks for a 2–3 sentence synthesis of the top Θ
    concepts.

    Args:
        theta_vector: Mapping of concept → {mean_confidence, ...}
        max_concepts: Maximum number of top concepts to include.

    Returns:
        A prompt string ready to send to an LLM.
    """
    # Extract and sort concepts by mean_confidence descending
    def _conf(entry: object) -> float:
        if isinstance(entry, dict):
            return float(entry.get("mean_confidence", 0.0))
        return 0.0

    sorted_concepts = sorted(
        theta_vector.items(),
        key=lambda kv: _conf(kv[1]),
        reverse=True,
    )[:max_concepts]

    if not sorted_concepts:
        return (
            "The coordination vector Θ is currently empty. "
            "Please write 2-3 sentences summarising that no concepts have been "
            "learned yet and that the agent team should proceed with caution."
        )

    concept_lines = "\n".join(
        f"  - {concept}: mean_confidence={_conf(data):.3f}"
        for concept, data in sorted_concepts
    )

    prompt = (
        "You are a governance analyst reviewing an AI agent team's coordination "
        "vector Θ. The following concepts have been learned by the team, ranked "
        "by confidence:\n\n"
        f"{concept_lines}\n\n"
        "Please write 2-3 concise sentences that:\n"
        "1. Summarise what the agent team has learned so far.\n"
        "2. Highlight any sensitive or high-confidence concepts to be careful about.\n"
        "3. Note any concerns the team should keep in mind going forward.\n\n"
        "Be direct and precise. Do not repeat the concept names verbatim — "
        "synthesise the meaning."
    )
    return prompt


# ---------------------------------------------------------------------------
# Core synthesis function
# ---------------------------------------------------------------------------

def synthesise_theta(
    gcc_repo,
    config: Optional[ThetaSynthesisConfig] = None,
) -> ThetaSynthesisResult:
    """
    Run LLM-powered Θ synthesis against the given GCCRepository.

    Never raises — all errors produce a skipped result with a reason string.

    Args:
        gcc_repo: A GCCRepository instance (or compatible duck-type).
        config:   Optional ThetaSynthesisConfig; defaults are used if None.

    Returns:
        ThetaSynthesisResult with skipped=False on success, skipped=True otherwise.
    """
    if config is None:
        config = ThetaSynthesisConfig()

    # 1. Check DEVTORCH_DISABLE env var
    if os.environ.get("DEVTORCH_DISABLE"):
        return ThetaSynthesisResult(
            summary="",
            concepts_used=[],
            model=config.model,
            tokens_used=0,
            skipped=True,
            skip_reason="DEVTORCH_DISABLE is set",
        )

    # 2. Load current theta vector
    try:
        theta = gcc_repo.get_theta()
    except Exception as exc:
        return ThetaSynthesisResult(
            summary="",
            concepts_used=[],
            model=config.model,
            tokens_used=0,
            skipped=True,
            skip_reason=f"get_theta failed: {exc}",
        )

    coordination_vector: dict = theta.get("coordination_vector", {}) if isinstance(theta, dict) else {}

    if not coordination_vector:
        return ThetaSynthesisResult(
            summary="",
            concepts_used=[],
            model=config.model,
            tokens_used=0,
            skipped=True,
            skip_reason="empty theta",
        )

    # 3. Try to import anthropic (lazy / gated)
    try:
        import anthropic  # noqa: PLC0415
    except ImportError:
        return ThetaSynthesisResult(
            summary="",
            concepts_used=[],
            model=config.model,
            tokens_used=0,
            skipped=True,
            skip_reason="anthropic not installed",
        )

    # 4. Build prompt and select top concepts
    def _conf(entry: object) -> float:
        if isinstance(entry, dict):
            return float(entry.get("mean_confidence", 0.0))
        return 0.0

    top_concepts = sorted(
        coordination_vector.items(),
        key=lambda kv: _conf(kv[1]),
        reverse=True,
    )[: config.max_concepts]

    concepts_used = [c for c, _ in top_concepts]
    prompt = build_synthesis_prompt(coordination_vector, max_concepts=config.max_concepts)

    # 5. Call the Anthropic API
    try:
        client = anthropic.Anthropic()
        response = client.messages.create(
            model=config.model,
            max_tokens=256,
            temperature=config.temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        raw_summary: str = response.content[0].text
        tokens_used: int = response.usage.input_tokens + response.usage.output_tokens

        # Truncate to max_summary_chars
        summary = raw_summary[: config.max_summary_chars]

        # 6. Write textual_summary back to the repo
        gcc_repo.update_theta_field("textual_summary", summary)

        return ThetaSynthesisResult(
            summary=summary,
            concepts_used=concepts_used,
            model=config.model,
            tokens_used=tokens_used,
            skipped=False,
            skip_reason="",
        )

    except Exception as exc:
        return ThetaSynthesisResult(
            summary="",
            concepts_used=[],
            model=config.model,
            tokens_used=0,
            skipped=True,
            skip_reason=str(exc),
        )


# ---------------------------------------------------------------------------
# Eligibility gate
# ---------------------------------------------------------------------------

def run_synthesis_if_eligible(
    gcc_repo,
    omega_capability=None,
) -> ThetaSynthesisResult:
    """
    Run synthesis only when the A1 capability gate passes.

    Args:
        gcc_repo:          A GCCRepository instance.
        omega_capability:  An OmegaCapability instance (or None to skip gate).
                           If provided, its `textual_mode_allowed` attribute or
                           method is checked before running synthesis.

    Returns:
        ThetaSynthesisResult — skipped if the gate fails.
    """
    # Import for side-effects / availability check (not used directly here)
    from devtorch_core.capability import check_round_cap  # noqa: F401, PLC0415

    if omega_capability is not None:
        tma = omega_capability.textual_mode_allowed
        # textual_mode_allowed may be a method (returns (bool, reasons)) or a
        # plain boolean attribute (e.g. on a MagicMock / CapabilityValidationResult)
        if callable(tma):
            allowed, _ = tma()
        else:
            allowed = bool(tma)

        if not allowed:
            return ThetaSynthesisResult(
                summary="",
                concepts_used=[],
                model=ThetaSynthesisConfig().model,
                tokens_used=0,
                skipped=True,
                skip_reason="A1 gate: textual mode not allowed",
            )

    return synthesise_theta(gcc_repo)
