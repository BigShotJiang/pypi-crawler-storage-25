"""
DevTorch local HTTP proxy (S7).

Runs on localhost:8765. Routes:
  /anthropic/*  → https://api.anthropic.com/*
  /openai/*     → https://api.openai.com/*
  /gemini/*     → https://generativelanguage.googleapis.com/*

Usage:
  devtorch proxy start          # foreground, Ctrl+C to stop
  devtorch proxy install        # install as OS service

Traffic never routes through DevTorch servers — this is a local-only tool
that binds to 127.0.0.1 only. Developer API keys are passed through
unchanged to the upstream provider.
"""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

try:
    from fastapi import FastAPI, Request, Response
    from fastapi.responses import StreamingResponse
    import httpx
    import uvicorn
    HAS_PROXY_DEPS = True
except ImportError:
    HAS_PROXY_DEPS = False

DEFAULT_PORT = 8765
DEFAULT_HOST = "127.0.0.1"


# ---------------------------------------------------------------------------
# GCC repo discovery
# ---------------------------------------------------------------------------

def find_gcc_repo() -> Optional[Any]:
    """
    Walk up from cwd looking for an initialised .GCC/ directory.
    Returns a GCCRepository instance or None if none found.
    """
    try:
        from devtorch_core import GCCRepository
        for parent in [Path.cwd()] + list(Path.cwd().parents):
            try:
                r = GCCRepository.at(parent)
                if r.is_initialized():
                    return r
            except Exception:
                continue
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app(gcc_repo: Optional[Any] = None) -> "FastAPI":
    """
    Create the FastAPI proxy application.

    Parameters
    ----------
    gcc_repo:
        An initialised GCCRepository used for RACP injection and capture.
        If None, requests are forwarded unmodified.
    """
    if not HAS_PROXY_DEPS:
        raise ImportError(
            "Proxy dependencies not installed. Run: pip install devtorch[proxy]"
        )

    app = FastAPI(
        title="DevTorch Local Proxy",
        version="0.1.0",
        description=(
            "Local HTTP proxy that intercepts LLM traffic, injects RACP context, "
            "captures reasoning to .GCC/, then forwards to the real LLM API. "
            "Binds to 127.0.0.1 only — never exposed to the network."
        ),
    )

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    @app.get("/health")
    async def health() -> dict:
        initialized = False
        try:
            initialized = gcc_repo is not None and gcc_repo.is_initialized()
        except Exception:
            pass
        return {"status": "ok", "gcc_initialized": initialized}

    # ------------------------------------------------------------------
    # Anthropic proxy
    # ------------------------------------------------------------------

    @app.api_route(
        "/anthropic/{path:path}",
        methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    )
    async def anthropic_proxy(path: str, request: Request) -> Response:
        from .routes.anthropic import proxy_anthropic
        return await proxy_anthropic(path, request, gcc_repo)

    # ------------------------------------------------------------------
    # OpenAI proxy
    # ------------------------------------------------------------------

    @app.api_route(
        "/openai/{path:path}",
        methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    )
    async def openai_proxy(path: str, request: Request) -> Response:
        from .routes.openai import proxy_openai
        return await proxy_openai(path, request, gcc_repo)

    # ------------------------------------------------------------------
    # Gemini proxy
    # ------------------------------------------------------------------

    @app.api_route(
        "/gemini/{path:path}",
        methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    )
    async def gemini_proxy(path: str, request: Request) -> Response:
        from .routes.gemini import proxy_gemini
        return await proxy_gemini(path, request, gcc_repo)

    return app


# ---------------------------------------------------------------------------
# Proxy runner
# ---------------------------------------------------------------------------

def run_proxy(
    port: int = DEFAULT_PORT,
    host: str = DEFAULT_HOST,
    gcc_repo: Optional[Any] = None,
) -> None:
    """
    Start the proxy server.  Blocks until Ctrl+C.

    Binds to 127.0.0.1 by default — never exposed to the network.
    """
    if not HAS_PROXY_DEPS:
        raise ImportError(
            "Proxy dependencies not installed. Run: pip install devtorch[proxy]"
        )

    repo = gcc_repo or find_gcc_repo()
    app = create_app(repo)

    print(f"DevTorch proxy listening on http://{host}:{port}")
    if repo is not None:
        try:
            initialized = repo.is_initialized()
            print(f"  .GCC/ found: {'yes' if initialized else 'no'}")
        except Exception:
            pass
    else:
        print("  No .GCC/ found — forwarding without RACP injection")

    uvicorn.run(app, host=host, port=port, log_level="warning")


# ---------------------------------------------------------------------------
# OS service installer
# ---------------------------------------------------------------------------

def install_service() -> None:
    """Install devtorch proxy as an OS auto-start service."""
    import platform
    system = platform.system()
    if system == "Darwin":
        _install_launchagent()
    elif system == "Linux":
        _install_systemd()
    elif system == "Windows":
        _install_windows_service()
    else:
        print(
            f"Auto-install not supported on {system}. "
            "Run `devtorch proxy start` manually."
        )


# ---------------------------------------------------------------------------
# macOS LaunchAgent
# ---------------------------------------------------------------------------

def _install_launchagent() -> None:
    """Write ~/Library/LaunchAgents/ai.devtorch.proxy.plist"""
    import shutil

    devtorch_bin = shutil.which("devtorch")
    if devtorch_bin is None:
        print(
            "Could not locate devtorch executable on PATH. "
            "Install devtorch first (`pip install devtorch[proxy]`), "
            "then re-run `devtorch proxy install`."
        )
        return

    plist_dir = Path.home() / "Library" / "LaunchAgents"
    plist_dir.mkdir(parents=True, exist_ok=True)
    plist_path = plist_dir / "ai.devtorch.proxy.plist"

    plist_content = f"""\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>ai.devtorch.proxy</string>
  <key>ProgramArguments</key>
  <array>
    <string>{devtorch_bin}</string>
    <string>proxy</string>
    <string>start</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>/tmp/devtorch-proxy.log</string>
  <key>StandardErrorPath</key>
  <string>/tmp/devtorch-proxy.err</string>
</dict>
</plist>
"""

    plist_path.write_text(plist_content, encoding="utf-8")
    print(f"Installed LaunchAgent at {plist_path}")
    print(
        f"Run: launchctl load {plist_path}\n"
        "To unload: launchctl unload "
        "~/Library/LaunchAgents/ai.devtorch.proxy.plist"
    )


# ---------------------------------------------------------------------------
# Linux systemd user service
# ---------------------------------------------------------------------------

def _install_systemd() -> None:
    """Write ~/.config/systemd/user/devtorch-proxy.service"""
    import shutil

    devtorch_bin = shutil.which("devtorch")
    if devtorch_bin is None:
        print(
            "Could not locate devtorch executable on PATH. "
            "Install devtorch first, then re-run `devtorch proxy install`."
        )
        return

    service_dir = Path.home() / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)
    service_path = service_dir / "devtorch-proxy.service"

    service_content = f"""\
[Unit]
Description=DevTorch Local Proxy
After=network.target

[Service]
Type=simple
ExecStart={devtorch_bin} proxy start
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=default.target
"""

    service_path.write_text(service_content, encoding="utf-8")
    print(f"Installed systemd user service at {service_path}")
    print("Run: systemctl --user enable --now devtorch-proxy")
    print("To check status: systemctl --user status devtorch-proxy")


# ---------------------------------------------------------------------------
# Windows Task Scheduler instructions
# ---------------------------------------------------------------------------

def _install_windows_service() -> None:
    """Print instructions for Windows Task Scheduler."""
    import shutil
    devtorch_bin = shutil.which("devtorch") or "devtorch"

    print("Windows auto-start setup (Task Scheduler):")
    print("  1. Open Task Scheduler (taskschd.msc)")
    print("  2. Create a new basic task:")
    print(f"     Action: Start a program → {devtorch_bin} proxy start")
    print("     Trigger: At log on")
    print("  3. Or run from PowerShell:")
    print(
        f'     $action = New-ScheduledTaskAction -Execute "{devtorch_bin}" '
        '-Argument "proxy start"'
    )
    print(
        '     $trigger = New-ScheduledTaskTrigger -AtLogOn\n'
        '     Register-ScheduledTask -TaskName "DevTorch Proxy" '
        '-Action $action -Trigger $trigger -RunLevel Highest'
    )
