"""
DevTorch proxy route: OpenAI

/openai/{path} → https://api.openai.com/{path}

RACP is injected as a system message at position 0 in body["messages"].
Streaming SSE format (data: {...}\\n\\n) is handled transparently.
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

logger = logging.getLogger("devtorch.proxy.openai")

UPSTREAM = "https://api.openai.com"


# ---------------------------------------------------------------------------
# Lightweight RACP prefix builder (mirrors anthropic.py to avoid circulars)
# ---------------------------------------------------------------------------

def _build_racp_prefix(gcc_repo: Any) -> str:
    if gcc_repo is None:
        return ""

    parts: list[str] = []

    try:
        racp_prompt = gcc_repo.prompt_get()
        if racp_prompt:
            parts.append(racp_prompt.strip())
    except Exception as exc:
        logger.debug("devtorch proxy[openai]: prompt_get failed — %s", exc)

    try:
        theta = gcc_repo.get_theta()
        cv = theta.get("coordination_vector", {})
        if cv:
            def _mean_conf(entry: Any) -> float:
                if isinstance(entry, dict):
                    return float(entry.get("mean_confidence", 0.0))
                return 0.0

            top = sorted(cv.items(), key=lambda kv: _mean_conf(kv[1]), reverse=True)[:10]
            if top:
                lines = ["[DevTorch Θ — top concepts]"]
                for concept, data in top:
                    conf = _mean_conf(data)
                    lines.append(f"  {concept}: mean_confidence={conf:.3f}")
                parts.append("\n".join(lines))
    except Exception as exc:
        logger.debug("devtorch proxy[openai]: theta_summary failed — %s", exc)

    try:
        bundle = gcc_repo.context_bundle(
            k_tokens=8000,
            policy={"sensitivity_policy": "default"},
        )
        artifacts = bundle.get("artifacts", [])
        if artifacts:
            lines = ["[DevTorch context bundle]"]
            for art in artifacts:
                path = art.get("path", "?")
                reason = art.get("reason", "")
                lines.append(f"  - {path}: {reason}" if reason else f"  - {path}")
            parts.append("\n".join(lines))
    except Exception as exc:
        logger.debug("devtorch proxy[openai]: context_bundle failed — %s", exc)

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Capture helper
# ---------------------------------------------------------------------------

def _schedule_capture(gcc_repo: Any, response_text: str, session_id: str) -> None:
    async def _do_capture() -> None:
        try:
            from devtorch_core.wrapper.base import CaptureOrchestrator
            orchestrator = CaptureOrchestrator(gcc_repo)
            orchestrator.capture(
                response_text=response_text,
                thinking_blocks=[],
                session_id=session_id,
            )
        except Exception as exc:
            logger.warning("devtorch proxy[openai]: capture failed — %s", exc)

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(_do_capture())
        else:
            loop.run_until_complete(_do_capture())
    except Exception as exc:
        logger.warning("devtorch proxy[openai]: could not schedule capture — %s", exc)


# ---------------------------------------------------------------------------
# SSE accumulator: extract assistant text from streamed chunks
# ---------------------------------------------------------------------------

def _extract_text_from_sse(raw: str) -> str:
    """
    Parse SSE stream and concatenate content delta text for capture.
    Handles OpenAI's `data: {...}` format.
    """
    parts: list[str] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        data_str = line[5:].strip()
        if data_str == "[DONE]":
            break
        try:
            obj = json.loads(data_str)
            for choice in obj.get("choices", []):
                delta = choice.get("delta", {})
                content = delta.get("content", "")
                if content:
                    parts.append(content)
        except Exception:
            pass
    return "".join(parts)


# ---------------------------------------------------------------------------
# Route handler
# ---------------------------------------------------------------------------

async def proxy_openai(path: str, request: "Any", gcc_repo: Any) -> "Any":
    """
    Proxy /openai/{path} → https://api.openai.com/{path}
    """
    try:
        from fastapi import Response
        from fastapi.responses import StreamingResponse
        import httpx
    except ImportError:
        raise RuntimeError("proxy deps not installed: pip install devtorch[proxy]")

    # -----------------------------------------------------------------------
    # 1. Read request body
    # -----------------------------------------------------------------------
    try:
        body_bytes = await request.body()
        body: dict = json.loads(body_bytes) if body_bytes else {}
    except Exception:
        body = {}
        body_bytes = b""

    # -----------------------------------------------------------------------
    # 2. Inject RACP as system message at position 0
    # -----------------------------------------------------------------------
    modified_body = body
    try:
        if gcc_repo is not None and gcc_repo.is_initialized():
            prefix = _build_racp_prefix(gcc_repo)
            if prefix:
                messages = list(body.get("messages", []))
                racp_msg = {"role": "system", "content": prefix}
                # Merge with existing system message if present, else prepend
                if messages and messages[0].get("role") == "system":
                    existing_content = messages[0].get("content", "")
                    messages[0] = {
                        "role": "system",
                        "content": prefix + "\n\n" + existing_content,
                    }
                else:
                    messages.insert(0, racp_msg)
                modified_body = {**body, "messages": messages}
    except Exception as exc:
        logger.warning("devtorch proxy[openai]: RACP injection failed — %s", exc)
        modified_body = body

    send_body = json.dumps(modified_body).encode() if modified_body else body_bytes

    # -----------------------------------------------------------------------
    # 3. Build forwarding headers
    # -----------------------------------------------------------------------
    forward_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in ("host", "content-length", "transfer-encoding")
    }
    forward_headers["host"] = "api.openai.com"
    if send_body:
        forward_headers["content-length"] = str(len(send_body))

    upstream_url = f"{UPSTREAM}/{path}"
    if request.url.query:
        upstream_url = f"{upstream_url}?{request.url.query}"

    session_id = str(uuid.uuid4())[:8]
    is_streaming = bool(modified_body.get("stream", False))

    # -----------------------------------------------------------------------
    # 4 & 5. Stream or buffer
    # -----------------------------------------------------------------------
    if is_streaming:
        async def _stream_generator():
            buffer_parts: list[bytes] = []
            try:
                async with httpx.AsyncClient(timeout=300.0) as client:
                    async with client.stream(
                        method=request.method,
                        url=upstream_url,
                        headers=forward_headers,
                        content=send_body,
                    ) as upstream_resp:
                        async for chunk in upstream_resp.aiter_bytes():
                            buffer_parts.append(chunk)
                            yield chunk
            except Exception as exc:
                logger.warning("devtorch proxy[openai]: streaming error — %s", exc)

            raw_text = b"".join(buffer_parts).decode("utf-8", errors="replace")
            extracted = _extract_text_from_sse(raw_text)
            _schedule_capture(gcc_repo, extracted or raw_text, session_id)

        return StreamingResponse(
            _stream_generator(),
            media_type="text/event-stream",
        )
    else:
        try:
            async with httpx.AsyncClient(timeout=300.0) as client:
                upstream_resp = await client.request(
                    method=request.method,
                    url=upstream_url,
                    headers=forward_headers,
                    content=send_body,
                )

            # Extract assistant text for capture
            try:
                resp_json = upstream_resp.json()
                text_parts: list[str] = []
                for choice in resp_json.get("choices", []):
                    msg = choice.get("message", {})
                    content = msg.get("content", "")
                    if content:
                        text_parts.append(content)
                resp_text = "\n".join(text_parts) or upstream_resp.text
            except Exception:
                resp_text = upstream_resp.text

            _schedule_capture(gcc_repo, resp_text, session_id)

            excluded = {"transfer-encoding", "content-encoding", "content-length"}
            resp_headers = {
                k: v for k, v in upstream_resp.headers.items()
                if k.lower() not in excluded
            }
            return Response(
                content=upstream_resp.content,
                status_code=upstream_resp.status_code,
                headers=resp_headers,
                media_type=upstream_resp.headers.get("content-type", "application/json"),
            )
        except Exception as exc:
            logger.warning("devtorch proxy[openai]: upstream request failed — %s", exc)
            try:
                async with httpx.AsyncClient(timeout=300.0) as client:
                    fallback_resp = await client.request(
                        method=request.method,
                        url=upstream_url,
                        headers=forward_headers,
                        content=body_bytes,
                    )
                return Response(
                    content=fallback_resp.content,
                    status_code=fallback_resp.status_code,
                    media_type=fallback_resp.headers.get("content-type", "application/json"),
                )
            except Exception as exc2:
                logger.error("devtorch proxy[openai]: fallback also failed — %s", exc2)
                return Response(
                    content=json.dumps({"error": "proxy error", "detail": str(exc2)}).encode(),
                    status_code=502,
                    media_type="application/json",
                )
