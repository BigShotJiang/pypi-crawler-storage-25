"""
DevTorch proxy route: Google Gemini

/gemini/{path} → https://generativelanguage.googleapis.com/{path}

RACP is injected into the first user content part (body["contents"]).
Gemini uses "contents" instead of "messages".
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

logger = logging.getLogger("devtorch.proxy.gemini")

UPSTREAM = "https://generativelanguage.googleapis.com"


# ---------------------------------------------------------------------------
# Lightweight RACP prefix builder
# ---------------------------------------------------------------------------

def _build_racp_prefix(gcc_repo: Any) -> str:
    if gcc_repo is None:
        return ""

    parts: list[str] = []

    try:
        racp_prompt = gcc_repo.prompt_get()
        if racp_prompt:
            parts.append(racp_prompt.strip())
    except Exception as exc:
        logger.debug("devtorch proxy[gemini]: prompt_get failed — %s", exc)

    try:
        theta = gcc_repo.get_theta()
        cv = theta.get("coordination_vector", {})
        if cv:
            def _mean_conf(entry: Any) -> float:
                if isinstance(entry, dict):
                    return float(entry.get("mean_confidence", 0.0))
                return 0.0

            top = sorted(cv.items(), key=lambda kv: _mean_conf(kv[1]), reverse=True)[:10]
            if top:
                lines = ["[DevTorch Θ — top concepts]"]
                for concept, data in top:
                    conf = _mean_conf(data)
                    lines.append(f"  {concept}: mean_confidence={conf:.3f}")
                parts.append("\n".join(lines))
    except Exception as exc:
        logger.debug("devtorch proxy[gemini]: theta_summary failed — %s", exc)

    try:
        bundle = gcc_repo.context_bundle(
            k_tokens=8000,
            policy={"sensitivity_policy": "default"},
        )
        artifacts = bundle.get("artifacts", [])
        if artifacts:
            lines = ["[DevTorch context bundle]"]
            for art in artifacts:
                path = art.get("path", "?")
                reason = art.get("reason", "")
                lines.append(f"  - {path}: {reason}" if reason else f"  - {path}")
            parts.append("\n".join(lines))
    except Exception as exc:
        logger.debug("devtorch proxy[gemini]: context_bundle failed — %s", exc)

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Capture helper
# ---------------------------------------------------------------------------

def _schedule_capture(gcc_repo: Any, response_text: str, session_id: str) -> None:
    async def _do_capture() -> None:
        try:
            from devtorch_core.wrapper.base import CaptureOrchestrator
            orchestrator = CaptureOrchestrator(gcc_repo)
            orchestrator.capture(
                response_text=response_text,
                thinking_blocks=[],
                session_id=session_id,
            )
        except Exception as exc:
            logger.warning("devtorch proxy[gemini]: capture failed — %s", exc)

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(_do_capture())
        else:
            loop.run_until_complete(_do_capture())
    except Exception as exc:
        logger.warning("devtorch proxy[gemini]: could not schedule capture — %s", exc)


# ---------------------------------------------------------------------------
# Gemini body injection
# ---------------------------------------------------------------------------

def _inject_racp_into_contents(body: dict, prefix: str) -> dict:
    """
    Inject RACP prefix into the first user content part's text.
    Gemini body structure:
      {
        "contents": [
          {"role": "user", "parts": [{"text": "..."}]},
          ...
        ],
        "systemInstruction": {"parts": [{"text": "..."}]}   # optional
      }

    Strategy:
    - If body has "systemInstruction", prepend prefix there.
    - Otherwise inject into the first user content text part.
    """
    modified = dict(body)

    if "systemInstruction" in modified:
        si = dict(modified["systemInstruction"])
        parts = list(si.get("parts", []))
        if parts and isinstance(parts[0], dict) and "text" in parts[0]:
            existing = parts[0]["text"]
            parts[0] = {"text": prefix + "\n\n" + existing}
        else:
            parts.insert(0, {"text": prefix})
        si["parts"] = parts
        modified["systemInstruction"] = si
        return modified

    # Fall back to first user content part
    contents = list(modified.get("contents", []))
    if not contents:
        return modified

    # Find first user turn
    for i, content in enumerate(contents):
        if content.get("role", "user") == "user":
            content = dict(content)
            parts = list(content.get("parts", []))
            if parts and isinstance(parts[0], dict) and "text" in parts[0]:
                existing = parts[0]["text"]
                parts[0] = {"text": prefix + "\n\n" + existing}
            else:
                parts.insert(0, {"text": prefix})
            content["parts"] = parts
            contents[i] = content
            break

    modified["contents"] = contents
    return modified


# ---------------------------------------------------------------------------
# Response text extraction for capture
# ---------------------------------------------------------------------------

def _extract_text_from_response(resp_json: Any) -> str:
    """Extract generated text from a Gemini API response dict."""
    try:
        parts: list[str] = []
        for candidate in resp_json.get("candidates", []):
            content = candidate.get("content", {})
            for part in content.get("parts", []):
                text = part.get("text", "")
                if text:
                    parts.append(text)
        return "\n".join(parts)
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Route handler
# ---------------------------------------------------------------------------

async def proxy_gemini(path: str, request: "Any", gcc_repo: Any) -> "Any":
    """
    Proxy /gemini/{path} → https://generativelanguage.googleapis.com/{path}
    """
    try:
        from fastapi import Response
        from fastapi.responses import StreamingResponse
        import httpx
    except ImportError:
        raise RuntimeError("proxy deps not installed: pip install devtorch[proxy]")

    # -----------------------------------------------------------------------
    # 1. Read request body
    # -----------------------------------------------------------------------
    try:
        body_bytes = await request.body()
        body: dict = json.loads(body_bytes) if body_bytes else {}
    except Exception:
        body = {}
        body_bytes = b""

    # -----------------------------------------------------------------------
    # 2. Inject RACP into first user content part
    # -----------------------------------------------------------------------
    modified_body = body
    try:
        if gcc_repo is not None and gcc_repo.is_initialized():
            prefix = _build_racp_prefix(gcc_repo)
            if prefix:
                modified_body = _inject_racp_into_contents(body, prefix)
    except Exception as exc:
        logger.warning("devtorch proxy[gemini]: RACP injection failed — %s", exc)
        modified_body = body

    send_body = json.dumps(modified_body).encode() if modified_body else body_bytes

    # -----------------------------------------------------------------------
    # 3. Build forwarding headers
    # -----------------------------------------------------------------------
    forward_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in ("host", "content-length", "transfer-encoding")
    }
    forward_headers["host"] = "generativelanguage.googleapis.com"
    if send_body:
        forward_headers["content-length"] = str(len(send_body))

    upstream_url = f"{UPSTREAM}/{path}"
    if request.url.query:
        upstream_url = f"{upstream_url}?{request.url.query}"

    session_id = str(uuid.uuid4())[:8]

    # Gemini uses ?alt=sse for streaming; check both stream flag and path
    is_streaming = bool(
        modified_body.get("stream", False)
        or "streamGenerateContent" in path
    )

    # -----------------------------------------------------------------------
    # 4 & 5. Stream or buffer
    # -----------------------------------------------------------------------
    if is_streaming:
        async def _stream_generator():
            buffer_parts: list[bytes] = []
            try:
                async with httpx.AsyncClient(timeout=300.0) as client:
                    async with client.stream(
                        method=request.method,
                        url=upstream_url,
                        headers=forward_headers,
                        content=send_body,
                    ) as upstream_resp:
                        async for chunk in upstream_resp.aiter_bytes():
                            buffer_parts.append(chunk)
                            yield chunk
            except Exception as exc:
                logger.warning("devtorch proxy[gemini]: streaming error — %s", exc)

            raw_text = b"".join(buffer_parts).decode("utf-8", errors="replace")
            # Try to parse as JSON array (Gemini streams JSON objects)
            try:
                combined = json.loads(raw_text)
                if isinstance(combined, list):
                    extracted = "\n".join(
                        _extract_text_from_response(item) for item in combined
                    )
                else:
                    extracted = _extract_text_from_response(combined)
            except Exception:
                extracted = raw_text
            _schedule_capture(gcc_repo, extracted or raw_text, session_id)

        return StreamingResponse(
            _stream_generator(),
            media_type="application/json",
        )
    else:
        try:
            async with httpx.AsyncClient(timeout=300.0) as client:
                upstream_resp = await client.request(
                    method=request.method,
                    url=upstream_url,
                    headers=forward_headers,
                    content=send_body,
                )

            try:
                resp_json = upstream_resp.json()
                resp_text = _extract_text_from_response(resp_json) or upstream_resp.text
            except Exception:
                resp_text = upstream_resp.text

            _schedule_capture(gcc_repo, resp_text, session_id)

            excluded = {"transfer-encoding", "content-encoding", "content-length"}
            resp_headers = {
                k: v for k, v in upstream_resp.headers.items()
                if k.lower() not in excluded
            }
            return Response(
                content=upstream_resp.content,
                status_code=upstream_resp.status_code,
                headers=resp_headers,
                media_type=upstream_resp.headers.get("content-type", "application/json"),
            )
        except Exception as exc:
            logger.warning("devtorch proxy[gemini]: upstream request failed — %s", exc)
            try:
                async with httpx.AsyncClient(timeout=300.0) as client:
                    fallback_resp = await client.request(
                        method=request.method,
                        url=upstream_url,
                        headers=forward_headers,
                        content=body_bytes,
                    )
                return Response(
                    content=fallback_resp.content,
                    status_code=fallback_resp.status_code,
                    media_type=fallback_resp.headers.get("content-type", "application/json"),
                )
            except Exception as exc2:
                logger.error("devtorch proxy[gemini]: fallback also failed — %s", exc2)
                return Response(
                    content=json.dumps({"error": "proxy error", "detail": str(exc2)}).encode(),
                    status_code=502,
                    media_type="application/json",
                )
