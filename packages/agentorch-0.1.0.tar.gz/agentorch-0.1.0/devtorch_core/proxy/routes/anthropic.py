"""
DevTorch proxy route: Anthropic

/anthropic/{path} → https://api.anthropic.com/{path}

Request pipeline:
  1. Parse body as JSON.
  2. Inject RACP system prefix into body["system"].
  3. Forward to api.anthropic.com with original headers (x-api-key passed through).
  4. Stream chunks back while buffering.
  5. After stream closes, schedule .GCC/ capture as non-blocking asyncio task.

All errors degrade gracefully — the original LLM response is always returned.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from typing import Any

logger = logging.getLogger("devtorch.proxy.anthropic")

UPSTREAM = "https://api.anthropic.com"


# ---------------------------------------------------------------------------
# Lightweight RACP prefix builder (no import from wrapper.base to avoid circulars)
# ---------------------------------------------------------------------------

def _build_racp_prefix(gcc_repo: Any) -> str:
    """
    Build the RACP system prefix from a GCCRepository instance.
    Returns empty string on any error so callers can safely concatenate.
    """
    if gcc_repo is None:
        return ""

    parts: list[str] = []

    # 1. RACP canonical system prompt
    try:
        racp_prompt = gcc_repo.prompt_get()
        if racp_prompt:
            parts.append(racp_prompt.strip())
    except Exception as exc:
        logger.debug("devtorch proxy: prompt_get failed — %s", exc)

    # 2. Θ top-10 concepts by mean_confidence
    try:
        theta = gcc_repo.get_theta()
        cv = theta.get("coordination_vector", {})
        if cv:
            def _mean_conf(entry: Any) -> float:
                if isinstance(entry, dict):
                    return float(entry.get("mean_confidence", 0.0))
                return 0.0

            top = sorted(cv.items(), key=lambda kv: _mean_conf(kv[1]), reverse=True)[:10]
            if top:
                lines = ["[DevTorch Θ — top concepts]"]
                for concept, data in top:
                    conf = _mean_conf(data)
                    lines.append(f"  {concept}: mean_confidence={conf:.3f}")
                parts.append("\n".join(lines))
    except Exception as exc:
        logger.debug("devtorch proxy: theta_summary failed — %s", exc)

    # 3. Context bundle summary
    try:
        bundle = gcc_repo.context_bundle(
            k_tokens=8000,
            policy={"sensitivity_policy": "default"},
        )
        artifacts = bundle.get("artifacts", [])
        if artifacts:
            lines = ["[DevTorch context bundle]"]
            for art in artifacts:
                path = art.get("path", "?")
                reason = art.get("reason", "")
                lines.append(f"  - {path}: {reason}" if reason else f"  - {path}")
            parts.append("\n".join(lines))
    except Exception as exc:
        logger.debug("devtorch proxy: context_bundle failed — %s", exc)

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Capture helper
# ---------------------------------------------------------------------------

def _schedule_capture(gcc_repo: Any, response_text: str, session_id: str) -> None:
    """Schedule .GCC/ capture as a fire-and-forget asyncio task."""
    async def _do_capture() -> None:
        try:
            from devtorch_core.wrapper.base import CaptureOrchestrator
            orchestrator = CaptureOrchestrator(gcc_repo)
            orchestrator.capture(
                response_text=response_text,
                thinking_blocks=[],
                session_id=session_id,
            )
        except Exception as exc:
            logger.warning("devtorch proxy: capture failed — %s", exc)

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(_do_capture())
        else:
            loop.run_until_complete(_do_capture())
    except Exception as exc:
        logger.warning("devtorch proxy: could not schedule capture — %s", exc)


# ---------------------------------------------------------------------------
# Route handler
# ---------------------------------------------------------------------------

async def proxy_anthropic(path: str, request: "Any", gcc_repo: Any) -> "Any":
    """
    Proxy /anthropic/{path} → https://api.anthropic.com/{path}
    """
    try:
        from fastapi import Response
        from fastapi.responses import StreamingResponse
        import httpx
    except ImportError:
        raise RuntimeError("proxy deps not installed: pip install devtorch[proxy]")

    # -----------------------------------------------------------------------
    # 1. Read request body
    # -----------------------------------------------------------------------
    try:
        body_bytes = await request.body()
        body: dict = json.loads(body_bytes) if body_bytes else {}
    except Exception:
        body = {}
        body_bytes = b""

    # -----------------------------------------------------------------------
    # 2. Inject RACP prefix into body["system"]
    # -----------------------------------------------------------------------
    modified_body = body
    injection_failed = False
    try:
        if gcc_repo is not None and gcc_repo.is_initialized():
            prefix = _build_racp_prefix(gcc_repo)
            if prefix:
                existing = body.get("system", "")
                separator = "\n\n" if existing else ""
                modified_body = {**body, "system": prefix + separator + existing}
    except Exception as exc:
        logger.warning("devtorch proxy: RACP injection failed — %s", exc)
        injection_failed = True
        modified_body = body

    send_body = json.dumps(modified_body).encode() if modified_body else body_bytes

    # -----------------------------------------------------------------------
    # 3. Build forwarding headers (replace host, keep everything else)
    # -----------------------------------------------------------------------
    forward_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in ("host", "content-length", "transfer-encoding")
    }
    forward_headers["host"] = "api.anthropic.com"
    if send_body:
        forward_headers["content-length"] = str(len(send_body))

    upstream_url = f"{UPSTREAM}/{path}"
    if request.url.query:
        upstream_url = f"{upstream_url}?{request.url.query}"

    session_id = str(uuid.uuid4())[:8]
    is_streaming = bool(modified_body.get("stream", False))

    # -----------------------------------------------------------------------
    # 4 & 5. Stream or buffer response; schedule capture after completion
    # -----------------------------------------------------------------------
    if is_streaming:
        async def _stream_generator():
            buffer_parts: list[bytes] = []
            try:
                async with httpx.AsyncClient(timeout=300.0) as client:
                    async with client.stream(
                        method=request.method,
                        url=upstream_url,
                        headers=forward_headers,
                        content=send_body,
                    ) as upstream_resp:
                        async for chunk in upstream_resp.aiter_bytes():
                            buffer_parts.append(chunk)
                            yield chunk
            except Exception as exc:
                logger.warning("devtorch proxy: streaming error — %s", exc)

            # After stream done, fire capture
            full_text = b"".join(buffer_parts).decode("utf-8", errors="replace")
            _schedule_capture(gcc_repo, full_text, session_id)

        response_headers = {}
        # We can't get upstream status before streaming; return 200 with streamed content
        return StreamingResponse(
            _stream_generator(),
            media_type="text/event-stream",
            headers=response_headers,
        )
    else:
        # Non-streaming: buffer the full response
        try:
            async with httpx.AsyncClient(timeout=300.0) as client:
                upstream_resp = await client.request(
                    method=request.method,
                    url=upstream_url,
                    headers=forward_headers,
                    content=send_body,
                )

            # Schedule capture after receiving full response
            try:
                resp_text = upstream_resp.text
                _schedule_capture(gcc_repo, resp_text, session_id)
            except Exception:
                pass

            # Filter hop-by-hop headers
            excluded = {"transfer-encoding", "content-encoding", "content-length"}
            resp_headers = {
                k: v for k, v in upstream_resp.headers.items()
                if k.lower() not in excluded
            }
            return Response(
                content=upstream_resp.content,
                status_code=upstream_resp.status_code,
                headers=resp_headers,
                media_type=upstream_resp.headers.get("content-type", "application/json"),
            )
        except Exception as exc:
            logger.warning("devtorch proxy: upstream request failed — %s", exc)
            # Forward original unmodified request as fallback
            try:
                async with httpx.AsyncClient(timeout=300.0) as client:
                    fallback_resp = await client.request(
                        method=request.method,
                        url=upstream_url,
                        headers=forward_headers,
                        content=body_bytes,
                    )
                return Response(
                    content=fallback_resp.content,
                    status_code=fallback_resp.status_code,
                    media_type=fallback_resp.headers.get("content-type", "application/json"),
                )
            except Exception as exc2:
                logger.error("devtorch proxy: fallback also failed — %s", exc2)
                return Response(
                    content=json.dumps({"error": "proxy error", "detail": str(exc2)}).encode(),
                    status_code=502,
                    media_type="application/json",
                )
