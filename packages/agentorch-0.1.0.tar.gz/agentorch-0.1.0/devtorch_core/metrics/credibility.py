"""
Metric credibility infrastructure.

Every computed metric in DevTorch is tagged with:
  - TIER: MEASURED | CALIBRATED | UNAVAILABLE
  - CITATIONS: references to the data sources behind any assumptions
  - DISCLOSURE: explicit statement of design choices vs. validated benchmarks

MEASURED  — derived exactly from .GCC/ events with no external assumptions.
            Example: commit count, sensitivity event count, branch count.

CALIBRATED — requires at least one team-specific input to be meaningful.
             The formula is exact but one input must be provided by the team.
             Example: DHS (formula exact, weights are design choices),
                      ROI cost (exact formula, team must set developer_hourly_rate).

UNAVAILABLE — requires longitudinal data or external integration not yet built.
              Returns None and explains what's needed.
              Example: per-collision rework time (no peer-reviewed benchmark exists).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Tier enum
# ---------------------------------------------------------------------------


class MetricTier(str, Enum):
    """Credibility tier assigned to each DevTorch metric."""

    MEASURED = "measured"
    CALIBRATED = "calibrated"
    UNAVAILABLE = "unavailable"


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class Citation:
    """A single academic or authoritative reference backing a metric assumption."""

    title: str
    authors: str
    year: int
    doi_or_url: str
    claim: str  # The specific claim being cited (e.g. "15 min task resumption time")
    scope: str  # Scope / caveat (e.g. "programming tasks only, not general work")


@dataclass
class DesignChoice:
    """A parameter that is a deliberate design decision, not an external benchmark."""

    name: str
    value: Any  # The current default value
    description: str  # Why this value was chosen
    calibration_instruction: str  # How the team should calibrate it


@dataclass
class MetricMetadata:
    """Full credibility metadata for one named metric."""

    metric_name: str
    tier: MetricTier
    citations: list[Citation] = field(default_factory=list)
    design_choices: list[DesignChoice] = field(default_factory=list)
    unavailable_reason: str = ""  # Why it is unavailable (if tier == UNAVAILABLE)
    calibration_required: list[str] = field(
        default_factory=list
    )  # Field names the team must set


# ---------------------------------------------------------------------------
# Metric registry
# ---------------------------------------------------------------------------

METRIC_REGISTRY: dict[str, MetricMetadata] = {
    "commit_count": MetricMetadata(
        metric_name="commit_count",
        tier=MetricTier.MEASURED,
        citations=[],
        design_choices=[],
    ),
    "sensitivity_event_count": MetricMetadata(
        metric_name="sensitivity_event_count",
        tier=MetricTier.MEASURED,
    ),
    "high_disclosure_count": MetricMetadata(
        metric_name="high_disclosure_count",
        tier=MetricTier.MEASURED,
    ),
    "context_switch_minutes": MetricMetadata(
        metric_name="context_switch_minutes",
        tier=MetricTier.CALIBRATED,
        citations=[
            Citation(
                title="Software exploratory works in the context of sustained attention",
                authors="Parnin, C. & Rugaber, S.",
                year=2011,
                doi_or_url="https://doi.org/10.1007/s11219-010-9104-9",
                claim="15 minutes average to resume a programming task after interruption",
                scope="Programming tasks only. Not validated for general knowledge work or AI agent context switches.",
            )
        ],
        design_choices=[
            DesignChoice(
                name="context_switch_minutes",
                value=15.0,
                description="Default from Parnin & Rugaber (2011). Measured for programming tasks.",
                calibration_instruction="Time your team's actual context switch cost with a simple stopwatch study over 1 week.",
            )
        ],
        calibration_required=[],
    ),
    "developer_hourly_rate": MetricMetadata(
        metric_name="developer_hourly_rate",
        tier=MetricTier.CALIBRATED,
        citations=[],
        design_choices=[
            DesignChoice(
                name="developer_hourly_rate",
                value=0.0,
                description="No universal default. Teams must set this explicitly. BLS SOC 15-1252 (2023) gives $55-65/hr median for software developers.",
                calibration_instruction="Use your team's actual loaded cost (salary + benefits + overhead). Set via devtorch calibrate --set developer_hourly_rate=<value>.",
            )
        ],
        calibration_required=["developer_hourly_rate"],
    ),
    "rework_minutes_per_collision": MetricMetadata(
        metric_name="rework_minutes_per_collision",
        tier=MetricTier.UNAVAILABLE,
        unavailable_reason="No peer-reviewed benchmark exists for per-collision rework time in AI multi-agent systems. Requires longitudinal team data. Set developer_hourly_rate and track actual rework time in your team's retrospectives.",
    ),
    "mcs_score": MetricMetadata(
        metric_name="mcs_score",
        tier=MetricTier.CALIBRATED,
        citations=[],
        design_choices=[
            DesignChoice(
                name="mcs_weight_frequency",
                value=0.4,
                description="Weight for collision frequency. Design choice — no external benchmark.",
                calibration_instruction="Adjust based on whether frequency or severity matters more for your team.",
            ),
            DesignChoice(
                name="mcs_weight_severity",
                value=0.4,
                description="Weight for collision severity. Design choice — no external benchmark.",
                calibration_instruction="Increase if severe but rare collisions are your main concern.",
            ),
            DesignChoice(
                name="mcs_weight_resolution_time",
                value=0.2,
                description="Weight for resolution time. Design choice — no external benchmark.",
                calibration_instruction="Increase if slow resolution times are your main concern.",
            ),
        ],
        calibration_required=[],
    ),
    "dhs_score": MetricMetadata(
        metric_name="dhs_score",
        tier=MetricTier.CALIBRATED,
        citations=[],
        design_choices=[
            DesignChoice(
                name="dhs_weight_commit_health",
                value=0.3,
                description="Weight for commit-backed decision ratio. Design choice.",
                calibration_instruction="Increase if commit discipline is your primary concern.",
            ),
            DesignChoice(
                name="dhs_weight_sensitivity_health",
                value=0.25,
                description="Weight for sensitivity event health. Design choice.",
                calibration_instruction="Increase for compliance-heavy teams.",
            ),
            DesignChoice(
                name="dhs_weight_capability_health",
                value=0.25,
                description="Weight for A1 capability gate health. Design choice.",
                calibration_instruction="Decrease if your team rarely uses textual mode.",
            ),
            DesignChoice(
                name="dhs_weight_variance_health",
                value=0.2,
                description="Weight for variance alert rate. Design choice.",
                calibration_instruction="Increase if variance stability is critical for your use case.",
            ),
        ],
        calibration_required=[],
    ),
    "auditor_hourly_rate": MetricMetadata(
        metric_name="auditor_hourly_rate",
        tier=MetricTier.CALIBRATED,
        citations=[
            Citation(
                title="Occupational Employment and Wages, Accountants and Auditors",
                authors="U.S. Bureau of Labor Statistics",
                year=2023,
                doi_or_url="https://www.bls.gov/oes/2023/may/oes132011.htm",
                claim="$39-40/hr median wage for employed accountants and auditors (SOC 13-2011)",
                scope="Employed staff auditors only. External billing rates ($75-400/hr) not reflected here.",
            )
        ],
        design_choices=[
            DesignChoice(
                name="auditor_hourly_rate",
                value=0.0,
                description="No universal default. BLS gives $39-40/hr for employed staff auditors (SOC 13-2011). External rates are $75-400/hr.",
                calibration_instruction="Use your actual auditor rate. Set via devtorch calibrate --set auditor_hourly_rate=<value>.",
            )
        ],
        calibration_required=["auditor_hourly_rate"],
    ),
}


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def get_metric_metadata(metric_name: str) -> Optional[MetricMetadata]:
    """Return the MetricMetadata for the named metric, or None if not in registry."""
    return METRIC_REGISTRY.get(metric_name)


def list_uncalibrated_metrics(calibration_dict: dict) -> list[str]:
    """
    Given a dict of currently-set calibration values, return metric names that
    require calibration but are missing from calibration_dict.

    Only checks the ``calibration_required`` field of each MetricMetadata entry.
    """
    uncalibrated: list[str] = []
    for metric_name, meta in METRIC_REGISTRY.items():
        if meta.calibration_required:
            missing = any(
                key not in calibration_dict for key in meta.calibration_required
            )
            if missing:
                uncalibrated.append(metric_name)
    return uncalibrated


def format_citation(citation: Citation) -> str:
    """Return a formatted citation string: '{authors} ({year}). {title}. {doi_or_url}'"""
    return f"{citation.authors} ({citation.year}). {citation.title}. {citation.doi_or_url}"


def metric_metadata_to_dict(meta: MetricMetadata) -> dict:
    """Return a JSON-serializable dict representation of MetricMetadata."""
    return {
        "metric_name": meta.metric_name,
        "tier": meta.tier.value,
        "citations": [
            {
                "title": c.title,
                "authors": c.authors,
                "year": c.year,
                "doi_or_url": c.doi_or_url,
                "claim": c.claim,
                "scope": c.scope,
            }
            for c in meta.citations
        ],
        "design_choices": [
            {
                "name": d.name,
                "value": d.value,
                "description": d.description,
                "calibration_instruction": d.calibration_instruction,
            }
            for d in meta.design_choices
        ],
        "unavailable_reason": meta.unavailable_reason,
        "calibration_required": list(meta.calibration_required),
    }
