"""
devtorch_core.metrics — Metrics calibration and scoring for DevTorch.

Provides:
  - CalibrationDefaults / CalibrationStore / load_calibration  (calibration.py)
  - CollisionEvent / compute_mcs / mcs_to_label                (mcs.py)
  - DHSComponents / compute_dhs / dhs_to_label                 (dhs.py)
  - ROIEstimate / estimate_context_switch_savings / estimate_rework_savings  (roi.py)
"""

from .calibration import CalibrationDefaults, CalibrationStore, load_calibration
from .mcs import CollisionEvent, compute_mcs, mcs_to_label, estimate_rework_cost
from .dhs import DHSComponents, compute_dhs, dhs_to_label, compute_dhs_from_gcc
from .roi import ROIEstimate, estimate_context_switch_savings, estimate_rework_savings

__all__ = [
    # calibration
    "CalibrationDefaults",
    "CalibrationStore",
    "load_calibration",
    # MCS
    "CollisionEvent",
    "compute_mcs",
    "mcs_to_label",
    "estimate_rework_cost",
    # DHS
    "DHSComponents",
    "compute_dhs",
    "dhs_to_label",
    "compute_dhs_from_gcc",
    # ROI
    "ROIEstimate",
    "estimate_context_switch_savings",
    "estimate_rework_savings",
]
