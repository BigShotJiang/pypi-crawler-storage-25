"""
Sprint metrics writer/reader for DevTorch.

Sprint metrics capture per-sprint governance signals.
Stored at .GCC/metrics/sprint/<sprint_id>.json.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional


_SPRINT_DIR = "metrics/sprint"


def write_sprint_metrics(gcc_dir: Path, sprint_id: str, data: dict) -> Path:
    """
    Write sprint metrics to .GCC/metrics/sprint/<sprint_id>.json.

    Expected data fields:
      mcs_score              — float [0,1]; computed via compute_mcs if not provided
      i3_violations          — int, count of I3 invariant failures this sprint
      collisions_prevented   — int, estimated collisions prevented by GCC
      override_rate          — float [0,1], fraction of AI suggestions overridden
      acceptance_rate        — float [0,1], fraction of AI suggestions accepted
      branch_count           — int, number of branches active this sprint
      commit_count           — int, number of commits this sprint

    If mcs_score is not provided, attempts to compute it from an empty event list
    (returns 0.0). Returns the path written.
    """
    gcc_dir = Path(gcc_dir)
    sprint_dir = gcc_dir / _SPRINT_DIR
    sprint_dir.mkdir(parents=True, exist_ok=True)

    if "mcs_score" not in data:
        try:
            from devtorch_core.metrics.mcs import compute_mcs
            mcs_score = compute_mcs([])
        except Exception:
            mcs_score = 0.0
    else:
        mcs_score = float(data["mcs_score"])

    record = {
        "sprint_id": sprint_id,
        "mcs_score": mcs_score,
        "i3_violations": int(data.get("i3_violations", 0)),
        "collisions_prevented": int(data.get("collisions_prevented", 0)),
        "override_rate": float(data.get("override_rate", 0.0)),
        "acceptance_rate": float(data.get("acceptance_rate", 0.0)),
        "branch_count": int(data.get("branch_count", 0)),
        "commit_count": int(data.get("commit_count", 0)),
    }

    out_path = sprint_dir / f"{sprint_id}.json"
    out_path.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
    return out_path


def read_sprint_metrics(gcc_dir: Path, sprint_id: str) -> Optional[dict]:
    """
    Read sprint metrics for *sprint_id*.

    Returns the dict if found, None if missing or unreadable.
    """
    gcc_dir = Path(gcc_dir)
    path = gcc_dir / _SPRINT_DIR / f"{sprint_id}.json"
    if not path.exists():
        return None
    try:
        text = path.read_text(encoding="utf-8")
        data = json.loads(text)
        if not isinstance(data, dict):
            return None
        return data
    except (json.JSONDecodeError, OSError):
        return None
