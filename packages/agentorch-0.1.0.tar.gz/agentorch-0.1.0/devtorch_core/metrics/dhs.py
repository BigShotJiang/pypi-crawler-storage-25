"""
DevTorch Health Score (DHS).

DHS measures overall governance health of the repository.
Range: 0.0 (unhealthy) to 1.0 (healthy).

IMPORTANT: DHS weights are design choices, not validated benchmarks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple, TYPE_CHECKING

from .calibration import CalibrationStore

if TYPE_CHECKING:
    from devtorch_core.gcc import GCCRepository


@dataclass
class DHSComponents:
    """Component scores feeding into the DHS composite."""

    commit_health: float  # 0–1: fraction of decisions that are commit-backed
    sensitivity_health: float  # 0–1: 1 - fraction of high-disclosure events
    capability_health: float  # 0–1: 1 if A1 gate passing, else 0
    variance_health: float  # 0–1: 1 - variance_alert_rate


def compute_dhs(
    components: DHSComponents,
    calibration: Optional[CalibrationStore] = None,
) -> float:
    """
    Compute DHS as a weighted sum of component scores.

    Result is clamped to [0.0, 1.0].
    """
    if calibration is not None:
        w_commit = float(calibration.get("dhs_weight_commit_health", 0.3))
        w_sens = float(calibration.get("dhs_weight_sensitivity_health", 0.25))
        w_cap = float(calibration.get("dhs_weight_capability_health", 0.25))
        w_var = float(calibration.get("dhs_weight_variance_health", 0.2))
    else:
        w_commit, w_sens, w_cap, w_var = 0.3, 0.25, 0.25, 0.2

    raw = (
        w_commit * components.commit_health
        + w_sens * components.sensitivity_health
        + w_cap * components.capability_health
        + w_var * components.variance_health
    )
    return max(0.0, min(1.0, raw))


def dhs_to_label(dhs: float) -> str:
    """Return a human-readable health label for a DHS value."""
    if dhs >= 0.8:
        return "HEALTHY"
    if dhs >= 0.6:
        return "FAIR"
    if dhs >= 0.4:
        return "DEGRADED"
    return "CRITICAL"


def compute_dhs_from_gcc(gcc_repo: "GCCRepository") -> Tuple[float, DHSComponents]:
    """
    Derive DHS components directly from a GCCRepository and compute the score.

    Component derivation:
      - commit_health: fraction of commits that are commit-backed (non-zero
        commit count → 1.0; no commits → 0.0).
      - sensitivity_health: 1 - (high-disclosure event fraction). HIGH and
        CRITICAL disclosure levels are counted as high-disclosure.
      - capability_health: 1.0 if the A1 gate passes, else 0.0.
      - variance_health: 1.0 if no variance alert has been fired (f_max > 0
        or no calibration report exists), else 0.0.

    Returns (dhs_score, components).
    """
    # --- commit_health ---
    try:
        history = gcc_repo.history()
        commit_health = 1.0 if history else 0.0
    except Exception:
        commit_health = 0.0

    # --- sensitivity_health ---
    try:
        all_events = gcc_repo.list_sensitivities()
        if all_events:
            high_levels = {"HIGH", "CRITICAL"}
            high_count = sum(
                1 for e in all_events
                if getattr(e, "disclosure_level", "").upper() in high_levels
            )
            sensitivity_health = 1.0 - (high_count / len(all_events))
        else:
            sensitivity_health = 1.0
    except Exception:
        sensitivity_health = 1.0

    # --- capability_health ---
    try:
        result = gcc_repo.validate_capability()
        capability_health = 1.0 if result.get("passed", False) else 0.0
    except Exception:
        capability_health = 0.0

    # --- variance_health ---
    try:
        forced = gcc_repo.variance_deterministic_mode_forced()
        variance_health = 0.0 if forced else 1.0
    except Exception:
        variance_health = 1.0

    components = DHSComponents(
        commit_health=commit_health,
        sensitivity_health=sensitivity_health,
        capability_health=capability_health,
        variance_health=variance_health,
    )
    dhs_score = compute_dhs(components)
    return dhs_score, components
