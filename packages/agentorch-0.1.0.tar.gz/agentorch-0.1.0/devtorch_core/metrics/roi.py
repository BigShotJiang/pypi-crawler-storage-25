"""
ROI and cost estimates.

IMPORTANT: All estimates require calibration with real team data.
Default values are starting points only — treat as uncalibrated until
your team sets developer_hourly_rate and validates rework assumptions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from .calibration import CalibrationStore


@dataclass
class ROIEstimate:
    """Result of an ROI/cost-saving estimate."""

    time_saved_minutes: float
    cost_saved_dollars: Optional[float]  # None when developer_hourly_rate not set
    is_calibrated: bool  # False when using unset defaults
    calibration_warnings: List[str] = field(default_factory=list)


def estimate_context_switch_savings(
    avoided_switches: int,
    calibration: CalibrationStore,
) -> ROIEstimate:
    """
    Estimate time and cost saved by avoiding context switches.

    Uses context_switch_minutes and developer_hourly_rate from calibration.
    is_calibrated is False when developer_hourly_rate has not been set (== 0).
    """
    switch_minutes = float(calibration.get("context_switch_minutes", 15.0))
    rate = float(calibration.get("developer_hourly_rate", 0.0))

    time_saved = avoided_switches * switch_minutes
    is_calibrated = rate > 0.0

    warnings: List[str] = []
    if not is_calibrated:
        warnings.append("Set developer_hourly_rate for cost estimates")

    cost_saved: Optional[float] = None
    if is_calibrated:
        cost_saved = (time_saved / 60.0) * rate

    return ROIEstimate(
        time_saved_minutes=time_saved,
        cost_saved_dollars=cost_saved,
        is_calibrated=is_calibrated,
        calibration_warnings=warnings,
    )


def estimate_rework_savings(
    avoided_collisions: int,
    calibration: CalibrationStore,
) -> ROIEstimate:
    """
    Estimate time and cost saved by avoiding rework from collisions.

    Uses rework_minutes_per_collision and developer_hourly_rate from calibration.
    is_calibrated is False when developer_hourly_rate has not been set (== 0).
    """
    rework_minutes = float(calibration.get("rework_minutes_per_collision", 30.0))
    rate = float(calibration.get("developer_hourly_rate", 0.0))

    time_saved = avoided_collisions * rework_minutes
    is_calibrated = rate > 0.0

    warnings: List[str] = []
    if not is_calibrated:
        warnings.append("Set developer_hourly_rate for cost estimates")

    cost_saved: Optional[float] = None
    if is_calibrated:
        cost_saved = (time_saved / 60.0) * rate

    return ROIEstimate(
        time_saved_minutes=time_saved,
        cost_saved_dollars=cost_saved,
        is_calibrated=is_calibrated,
        calibration_warnings=warnings,
    )
