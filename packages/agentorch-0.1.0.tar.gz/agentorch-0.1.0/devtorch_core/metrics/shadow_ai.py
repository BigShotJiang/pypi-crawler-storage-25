"""
Shadow AI detector for DevTorch.

Compares git commit count to GCC COMMIT event count over the last 30 days.
A high unregistered commit ratio suggests developers are bypassing GCC — a
"shadow AI" pattern where AI-assisted commits skip governance logging.
"""

from __future__ import annotations

import json
import subprocess
from datetime import datetime, timezone, timedelta
from pathlib import Path


_EVENT_LOG = "events.log.jsonl"
_THIRTY_DAYS_SECONDS = 30 * 24 * 3600


def _utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)


def _git_commit_count(repo_root: Path) -> int:
    """Count git commits in the last 30 days. Returns 0 on any error."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_root), "log", "--oneline", "--since=30.days.ago"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return 0
        lines = [l for l in result.stdout.splitlines() if l.strip()]
        return len(lines)
    except Exception:
        return 0


def _gcc_commit_count(gcc_dir: Path) -> int:
    """Count COMMIT events in events.log.jsonl in the last 30 days. Returns 0 on any error."""
    event_log = gcc_dir / _EVENT_LOG
    if not event_log.exists():
        return 0
    cutoff = _utcnow() - timedelta(seconds=_THIRTY_DAYS_SECONDS)
    count = 0
    try:
        with event_log.open(encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if event.get("event_type") != "COMMIT":
                    continue
                ts_str = event.get("timestamp", "")
                try:
                    # Parse ISO 8601 timestamp
                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                    if ts.tzinfo is None:
                        ts = ts.replace(tzinfo=timezone.utc)
                    if ts >= cutoff:
                        count += 1
                except (ValueError, AttributeError):
                    # If we can't parse timestamp, include the event conservatively
                    count += 1
    except OSError:
        return 0
    return count


def detect_shadow_ai(repo_root: Path) -> dict:
    """
    Compare git commit count to GCC COMMIT event count over the last 30 days.

    Returns:
      {
        "git_commits":   int   — total git commits in last 30 days
        "gcc_commits":   int   — GCC COMMIT events in last 30 days
        "unregistered":  int   — git_commits - gcc_commits (floor 0)
        "shadow_ratio":  float — unregistered / git_commits (0.0 if no git commits)
        "flagged":       bool  — True when unregistered > 3 and shadow_ratio > 0.3
      }

    All errors return safe defaults (0 counts, flagged=False).
    """
    try:
        repo_root = Path(repo_root)
        gcc_dir = repo_root / ".GCC"

        git_commits = _git_commit_count(repo_root)
        gcc_commits = _gcc_commit_count(gcc_dir)

        unregistered = max(0, git_commits - gcc_commits)
        shadow_ratio = unregistered / git_commits if git_commits > 0 else 0.0
        flagged = unregistered > 3 and shadow_ratio > 0.3

        return {
            "git_commits": git_commits,
            "gcc_commits": gcc_commits,
            "unregistered": unregistered,
            "shadow_ratio": shadow_ratio,
            "flagged": flagged,
        }
    except Exception:
        return {
            "git_commits": 0,
            "gcc_commits": 0,
            "unregistered": 0,
            "shadow_ratio": 0.0,
            "flagged": False,
        }
