"""
Metrics calibration store.

Calibration values are team-specific. The DEFAULTS below are reasonable
starting points but MUST be adjusted with real team data for meaningful
numbers. Do not treat defaults as validated benchmarks.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any, Optional

CALIBRATION_FILE_NAME = "calibration.json"


@dataclass
class CalibrationDefaults:
    """
    Default calibration values for DevTorch metrics.

    Each field is annotated with its source citation or "design choice,
    calibrate with team data" for values with no external benchmark.
    """

    # === Context switching cost ===
    # Source: Parnin & Rugaber (2011) Software Quality Journal
    # DOI: 10.1007/s11219-010-9104-9
    # Measured: 15 min for programming tasks (not general work)
    context_switch_minutes: float = 15.0

    # === Developer hourly rate ===
    # No universal default — teams must provide this.
    # BLS SOC 15-1252 (2023): $55-65/hr median for software developers
    # Set to 0 to force explicit calibration.
    developer_hourly_rate: float = 0.0

    # === Rework time per collision ===
    # No peer-reviewed benchmark. Design choice. Calibrate with team data.
    rework_minutes_per_collision: float = 30.0

    # === MCS weights ===
    # Design choices. No external benchmark. Calibrate with team data.
    mcs_weight_frequency: float = 0.4
    mcs_weight_severity: float = 0.4
    mcs_weight_resolution_time: float = 0.2

    # === DHS weights ===
    # Design choices. No external benchmark. Calibrate with team data.
    dhs_weight_commit_health: float = 0.3
    dhs_weight_sensitivity_health: float = 0.25
    dhs_weight_capability_health: float = 0.25
    dhs_weight_variance_health: float = 0.2


_DEFAULTS = CalibrationDefaults()
_DEFAULTS_DICT: dict[str, Any] = {f.name: getattr(_DEFAULTS, f.name) for f in fields(_DEFAULTS)}


class CalibrationStore:
    """
    Calibration value store backed by `.GCC/calibration.json`.

    Overrides in the JSON file take precedence over CalibrationDefaults.
    """

    def __init__(self, gcc_root: str) -> None:
        self._gcc_root = Path(gcc_root)
        self._path = self._gcc_root / CALIBRATION_FILE_NAME
        self._overrides: dict[str, Any] = self.load()

    def load(self) -> dict:
        """Read calibration JSON; return empty dict on missing or corrupt file."""
        if not self._path.exists():
            return {}
        try:
            text = self._path.read_text(encoding="utf-8")
            data = json.loads(text)
            if not isinstance(data, dict):
                return {}
            return data
        except (json.JSONDecodeError, OSError):
            return {}

    def save(self, values: dict) -> None:
        """Write the given values dict to .GCC/calibration.json."""
        self._gcc_root.mkdir(parents=True, exist_ok=True)
        self._path.write_text(
            json.dumps(values, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    def get(self, key: str, default: Any = None) -> Any:
        """Return the calibration value for key (overrides > defaults > default arg)."""
        if key in self._overrides:
            return self._overrides[key]
        if key in _DEFAULTS_DICT:
            return _DEFAULTS_DICT[key]
        return default

    def get_all(self) -> dict:
        """Return the full merged dict: defaults overridden by any stored values."""
        merged = dict(_DEFAULTS_DICT)
        merged.update(self._overrides)
        return merged

    def set(self, key: str, value: Any) -> None:
        """Set an override value and persist it to disk."""
        self._overrides[key] = value
        self.save(self._overrides)

    def reset(self, key: str) -> None:
        """Remove an override, falling back to the default value."""
        if key in self._overrides:
            del self._overrides[key]
            self.save(self._overrides)


def load_calibration(gcc_root: Optional[str] = None) -> CalibrationStore:
    """Convenience factory. If gcc_root is None, uses '.GCC' in the current directory."""
    if gcc_root is None:
        gcc_root = ".GCC"
    return CalibrationStore(gcc_root)
