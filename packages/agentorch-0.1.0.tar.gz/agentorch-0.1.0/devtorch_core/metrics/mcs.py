"""
Multi-agent Collision Score (MCS).

MCS measures how often agent outputs conflict with each other.
Range: 0.0 (no collisions) to 1.0 (maximum collision severity).

IMPORTANT: MCS weights are design choices, not validated benchmarks.
Calibrate mcs_weight_* values with your team's historical data.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from .calibration import CalibrationStore


@dataclass
class CollisionEvent:
    """A single multi-agent collision event."""

    timestamp: str
    branch_a: str
    branch_b: str
    concept: str
    severity: float  # 0.0–1.0
    resolution_minutes: float = 0.0


def compute_mcs(
    events: List[CollisionEvent],
    calibration: Optional[CalibrationStore] = None,
) -> float:
    """
    Compute MCS from a list of CollisionEvents.

    Returns 0.0 for an empty list. Result is clamped to [0.0, 1.0].

    Normalisations:
      - frequency_score: number of events / 10 (capped at 1.0)
      - severity_score: mean severity across events
      - resolution_score: mean resolution minutes / 60 (capped at 1.0)
    """
    if not events:
        return 0.0

    # Retrieve weights from calibration or use defaults
    if calibration is not None:
        w_freq = float(calibration.get("mcs_weight_frequency", 0.4))
        w_sev = float(calibration.get("mcs_weight_severity", 0.4))
        w_res = float(calibration.get("mcs_weight_resolution_time", 0.2))
    else:
        w_freq, w_sev, w_res = 0.4, 0.4, 0.2

    n = len(events)
    frequency_score = min(n / 10.0, 1.0)
    severity_score = sum(e.severity for e in events) / n
    resolution_score = min(
        sum(e.resolution_minutes for e in events) / n / 60.0,
        1.0,
    )

    raw = w_freq * frequency_score + w_sev * severity_score + w_res * resolution_score
    return max(0.0, min(1.0, raw))


def mcs_to_label(mcs: float) -> str:
    """Return a human-readable severity label for an MCS value."""
    if mcs >= 0.8:
        return "CRITICAL"
    if mcs >= 0.5:
        return "HIGH"
    if mcs >= 0.2:
        return "MODERATE"
    return "LOW"


def estimate_rework_cost(
    events: List[CollisionEvent],
    calibration: CalibrationStore,
) -> Optional[float]:
    """
    Estimate total rework cost in dollars.

    Returns None if developer_hourly_rate is 0 (explicitly uncalibrated).
    Raises ValueError if the rate is 0 and the caller expects a numeric result.
    """
    rate = float(calibration.get("developer_hourly_rate", 0.0))
    if rate == 0.0:
        return None

    rework_minutes = float(calibration.get("rework_minutes_per_collision", 30.0))
    total_minutes = len(events) * rework_minutes
    total_hours = total_minutes / 60.0
    return total_hours * rate
