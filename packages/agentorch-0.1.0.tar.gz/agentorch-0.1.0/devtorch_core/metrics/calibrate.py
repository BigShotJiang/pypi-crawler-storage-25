"""
Calibration store and onboarding wizard for DevTorch metrics.

CalibrationStore: persists team-specific calibration values to .GCC/metrics/calibration.json.
run_calibrate_wizard: interactive (or non-interactive for tests) onboarding flow.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any, Optional, Union


_CALIBRATION_SUBDIR = "metrics"
_CALIBRATION_FILE = "calibration.json"


class CalibrationStore:
    """
    Persists calibration values to .GCC/metrics/calibration.json.

    This is distinct from devtorch_core/metrics/calibration.py's CalibrationStore,
    which lives at .GCC/calibration.json and holds DHS/MCS weights.
    This one lives at .GCC/metrics/calibration.json and holds onboarding baselines.
    """

    def __init__(self, gcc_dir: Path) -> None:
        self._gcc_dir = Path(gcc_dir)
        self.calibration_path = self._gcc_dir / _CALIBRATION_SUBDIR / _CALIBRATION_FILE

    def load(self) -> dict:
        """Read calibration.json; return {} if missing or corrupt."""
        if not self.calibration_path.exists():
            return {}
        try:
            text = self.calibration_path.read_text(encoding="utf-8")
            data = json.loads(text)
            if not isinstance(data, dict):
                return {}
            return data
        except (json.JSONDecodeError, OSError):
            return {}

    def save(self, data: dict) -> None:
        """Write data to .GCC/metrics/calibration.json, creating dirs if needed."""
        self.calibration_path.parent.mkdir(parents=True, exist_ok=True)
        self.calibration_path.write_text(
            json.dumps(data, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    def set_value(self, key: str, value: Union[float, str]) -> None:
        """Set a single calibration key and persist."""
        data = self.load()
        data[key] = value
        self.save(data)

    def get_value(self, key: str, default: Any = None) -> Any:
        """Get a single calibration key, returning default if not set."""
        data = self.load()
        return data.get(key, default)


def _estimate_cold_start_min(repo_root: Path) -> float:
    """
    Estimate cold_start_min from git history.

    Counts commits in the last 30 days and computes the average inter-commit
    interval as a rough proxy for context switch / cold-start time.
    Falls back to 15.0 minutes if git is unavailable or the repo has no history.
    """
    default = 15.0
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_root), "log", "--format=%ct", "--since=30.days.ago"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return default
        timestamps = [int(t.strip()) for t in result.stdout.splitlines() if t.strip()]
        if len(timestamps) < 2:
            return default
        # timestamps are newest-first; sort ascending
        timestamps.sort()
        intervals_seconds = [
            timestamps[i + 1] - timestamps[i]
            for i in range(len(timestamps) - 1)
        ]
        avg_seconds = sum(intervals_seconds) / len(intervals_seconds)
        avg_minutes = avg_seconds / 60.0
        # Clamp to a sane range [1, 120]
        return max(1.0, min(120.0, avg_minutes))
    except Exception:
        return default


def run_calibrate_wizard(
    gcc_dir: Path,
    values: Optional[dict] = None,
) -> dict:
    """
    Run the calibration onboarding wizard.

    If *values* is provided, the wizard runs non-interactively using those values
    (useful for tests and automation). Missing keys fall back to defaults.

    If *values* is None, the wizard prompts the user interactively.

    Returns the calibration dict that was saved.

    Fields:
      cold_start_min            — estimated from git history (or prompted)
      avg_rework_hours          — default 2.0
      token_cost_usd_per_1k     — default 0.003
      developer_hourly_rate     — required, no default
      auditor_hourly_rate       — default 39.0
      sprint_length_days        — default 14
    """
    repo_root = gcc_dir.parent if gcc_dir.name == ".GCC" else gcc_dir

    git_estimate = _estimate_cold_start_min(repo_root)

    if values is not None:
        # Non-interactive mode
        calibration = {
            "cold_start_min": float(values.get("cold_start_min", git_estimate)),
            "avg_rework_hours": float(values.get("avg_rework_hours", 2.0)),
            "token_cost_usd_per_1k": float(values.get("token_cost_usd_per_1k", 0.003)),
            "developer_hourly_rate": float(values["developer_hourly_rate"]),
            "auditor_hourly_rate": float(values.get("auditor_hourly_rate", 39.0)),
            "sprint_length_days": int(values.get("sprint_length_days", 14)),
        }
    else:
        # Interactive mode
        print("DevTorch Metrics Calibration Wizard")
        print("=====================================")
        print("Press Enter to accept defaults shown in [brackets].\n")

        def _prompt_float(prompt: str, default: Optional[float]) -> float:
            default_str = f" [{default}]" if default is not None else ""
            while True:
                raw = input(f"{prompt}{default_str}: ").strip()
                if not raw and default is not None:
                    return default
                try:
                    return float(raw)
                except ValueError:
                    print("  Please enter a numeric value.")

        def _prompt_int(prompt: str, default: int) -> int:
            while True:
                raw = input(f"{prompt} [{default}]: ").strip()
                if not raw:
                    return default
                try:
                    return int(raw)
                except ValueError:
                    print("  Please enter an integer value.")

        cold_start_min = _prompt_float(
            f"Cold-start time (minutes, estimated from git: {git_estimate:.1f})",
            git_estimate,
        )
        avg_rework_hours = _prompt_float("Average rework hours per collision", 2.0)
        token_cost_usd_per_1k = _prompt_float("Token cost (USD per 1k tokens)", 0.003)
        developer_hourly_rate = _prompt_float("Developer hourly rate (USD, required)", None)
        auditor_hourly_rate = _prompt_float("Auditor hourly rate (USD)", 39.0)
        sprint_length_days = _prompt_int("Sprint length (days)", 14)

        calibration = {
            "cold_start_min": cold_start_min,
            "avg_rework_hours": avg_rework_hours,
            "token_cost_usd_per_1k": token_cost_usd_per_1k,
            "developer_hourly_rate": developer_hourly_rate,
            "auditor_hourly_rate": auditor_hourly_rate,
            "sprint_length_days": sprint_length_days,
        }

    store = CalibrationStore(gcc_dir)
    store.save(calibration)
    return calibration
