"""
Session metrics writer/reader for DevTorch.

Session metrics capture per-session LLM usage signals.
Stored at .GCC/metrics/session/<session_id>.json.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional


_SESSION_DIR = "metrics/session"


def write_session_metrics(gcc_dir: Path, session_id: str, data: dict) -> Path:
    """
    Write session metrics to .GCC/metrics/session/<session_id>.json.

    Expected data fields:
      tokens_used            — int, total tokens consumed this session
      tokens_saved           — int, estimated savings (default: tokens_used × 0.3)
      coverage               — float, ratio of committed decisions to total tool calls
      confidence_distribution — dict mapping tier name → count
      cold_start_ms          — float, cold-start latency in milliseconds

    Missing optional fields are computed or defaulted. Returns the path written.
    """
    gcc_dir = Path(gcc_dir)
    session_dir = gcc_dir / _SESSION_DIR
    session_dir.mkdir(parents=True, exist_ok=True)

    tokens_used = data.get("tokens_used", 0)
    tokens_saved = data.get("tokens_saved", int(tokens_used * 0.3))

    record = {
        "session_id": session_id,
        "tokens_used": tokens_used,
        "tokens_saved": tokens_saved,
        "coverage": data.get("coverage", 0.0),
        "confidence_distribution": data.get("confidence_distribution", {}),
        "cold_start_ms": data.get("cold_start_ms", 0.0),
    }

    out_path = session_dir / f"{session_id}.json"
    out_path.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
    return out_path


def read_session_metrics(gcc_dir: Path, session_id: str) -> Optional[dict]:
    """
    Read session metrics for *session_id*.

    Returns the dict if found, None if missing or unreadable.
    """
    gcc_dir = Path(gcc_dir)
    path = gcc_dir / _SESSION_DIR / f"{session_id}.json"
    if not path.exists():
        return None
    try:
        text = path.read_text(encoding="utf-8")
        data = json.loads(text)
        if not isinstance(data, dict):
            return None
        return data
    except (json.JSONDecodeError, OSError):
        return None
