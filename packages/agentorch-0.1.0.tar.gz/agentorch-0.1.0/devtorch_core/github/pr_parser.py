"""
Parses GitHub PR bodies for DevTorch governance metadata.
Extracts structured data without requiring a .GCC/ directory.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class PRMetadata:
    """Structured DevTorch governance metadata extracted from a PR body."""

    branch: str = ""
    commit_ids: List[str] = field(default_factory=list)
    sensitivity_refs: List[str] = field(default_factory=list)
    concept_refs: List[str] = field(default_factory=list)
    mcs_score: Optional[float] = None
    has_devtorch_section: bool = False


# Patterns
_BRANCH_PATTERN = re.compile(r"Branch:\s*`([^`]+)`")
_COMMIT_PATTERN = re.compile(r"\b([0-9a-f]{40})\b", re.IGNORECASE)
_SENSITIVITY_PATTERN = re.compile(r"\[SENSITIVITY:([^\]]+)\]")
_CONCEPT_PATTERN = re.compile(r"\[CONCEPT:([^\]]+)\]")
_MCS_PATTERN = re.compile(r"MCS:\s*([\d]+\.[\d]+)")
_DEVTORCH_HEADING_PATTERN = re.compile(r"^#{2,3}\s+DevTorch\b", re.MULTILINE)


def parse_pr_body(body: str) -> PRMetadata:
    """
    Parse a GitHub PR body string and extract DevTorch governance metadata.

    Args:
        body: The full text of the PR description/body.

    Returns:
        A PRMetadata instance populated from whatever was found in the body.
        Fields default to empty lists, None, or False when not found.
    """
    if not body:
        return PRMetadata()

    # Branch
    branch = ""
    branch_match = _BRANCH_PATTERN.search(body)
    if branch_match:
        branch = branch_match.group(1)

    # Commit IDs (40-char lowercase hex strings)
    commit_ids = list(dict.fromkeys(m.lower() for m in _COMMIT_PATTERN.findall(body)))

    # Sensitivity refs
    sensitivity_refs = list(dict.fromkeys(_SENSITIVITY_PATTERN.findall(body)))

    # Concept refs
    concept_refs = list(dict.fromkeys(_CONCEPT_PATTERN.findall(body)))

    # MCS score
    mcs_score: Optional[float] = None
    mcs_match = _MCS_PATTERN.search(body)
    if mcs_match:
        try:
            mcs_score = float(mcs_match.group(1))
        except ValueError:
            mcs_score = None

    # DevTorch section heading
    has_devtorch_section = bool(_DEVTORCH_HEADING_PATTERN.search(body))

    return PRMetadata(
        branch=branch,
        commit_ids=commit_ids,
        sensitivity_refs=sensitivity_refs,
        concept_refs=concept_refs,
        mcs_score=mcs_score,
        has_devtorch_section=has_devtorch_section,
    )
