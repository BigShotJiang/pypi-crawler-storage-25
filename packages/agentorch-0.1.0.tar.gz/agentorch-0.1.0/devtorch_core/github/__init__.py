"""
devtorch_core.github — GitHub App + CI/CD integration (Sprint 12).

Public API:
    parse_pr_body     — parse a PR body string into PRMetadata
    PRMetadata        — dataclass holding extracted governance metadata
    build_pr_comment  — render a GovernanceSummary as a GitHub PR comment
    GovernanceSummary — dataclass holding governance state for comment rendering
"""

from .pr_parser import PRMetadata, parse_pr_body
from .comment_builder import GovernanceSummary, build_pr_comment

__all__ = [
    "parse_pr_body",
    "PRMetadata",
    "build_pr_comment",
    "GovernanceSummary",
]
