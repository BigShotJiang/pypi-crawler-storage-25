"""
GitHub App webhook receiver for DevTorch.

Receives GitHub webhook events, validates HMAC signatures, and extracts
DevTorch governance metadata from PR bodies.

FastAPI is optional — the module degrades gracefully when it is not installed.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
from typing import Any, Dict

from .pr_parser import parse_pr_body

logger = logging.getLogger(__name__)

# ── Optional FastAPI import ───────────────────────────────────────────────────
try:
    from fastapi import FastAPI, Request, Response

    HAS_FASTAPI = True
except ImportError:  # pragma: no cover
    HAS_FASTAPI = False

_WEBHOOK_SECRET_ENV = "DEVTORCH_GITHUB_WEBHOOK_SECRET"


def _verify_signature(payload: bytes, signature_header: str, secret: str) -> bool:
    """Validate the X-Hub-Signature-256 HMAC header."""
    if not signature_header or not signature_header.startswith("sha256="):
        return False
    expected = (
        "sha256="
        + hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    )
    return hmac.compare_digest(expected, signature_header)


def _build_app() -> "FastAPI":  # type: ignore[name-defined]
    """Construct and return the FastAPI application instance."""
    if not HAS_FASTAPI:
        raise RuntimeError(
            "FastAPI is not installed. Install it with: pip install fastapi uvicorn"
        )

    app = FastAPI(title="DevTorch GitHub Webhook Receiver")

    @app.post("/webhook/github")
    async def github_webhook(request: Request) -> Dict[str, Any]:
        secret = os.environ.get(_WEBHOOK_SECRET_ENV, "")
        if not secret:
            logger.warning("DEVTORCH_GITHUB_WEBHOOK_SECRET is not set; ignoring event.")
            return {"status": "webhook_secret_not_configured"}

        payload = await request.body()
        sig_header = request.headers.get("X-Hub-Signature-256", "")

        if not _verify_signature(payload, sig_header, secret):
            logger.warning("Invalid webhook signature received.")
            return Response(content='{"error":"invalid signature"}', status_code=401, media_type="application/json")  # type: ignore[return-value]

        event_type = request.headers.get("X-GitHub-Event", "")

        if event_type != "pull_request":
            logger.debug("Ignoring non-PR event: %s", event_type)
            return {"status": "ignored"}

        import json as _json

        event: Dict[str, Any] = _json.loads(payload)
        action = event.get("action", "")

        if action not in ("opened", "synchronize"):
            logger.debug("Ignoring PR action: %s", action)
            return {"status": "ignored"}

        pr = event.get("pull_request", {})
        body = pr.get("body") or ""
        metadata = parse_pr_body(body)

        logger.info(
            "PR #%s (%s) DevTorch metadata: branch=%r commits=%d sensitivities=%d concepts=%d mcs=%s",
            pr.get("number", "?"),
            action,
            metadata.branch,
            len(metadata.commit_ids),
            len(metadata.sensitivity_refs),
            len(metadata.concept_refs),
            metadata.mcs_score,
        )

        return {
            "status": "ok",
            "metadata": {
                "branch": metadata.branch,
                "commit_ids": metadata.commit_ids,
                "sensitivity_refs": metadata.sensitivity_refs,
                "concept_refs": metadata.concept_refs,
                "mcs_score": metadata.mcs_score,
                "has_devtorch_section": metadata.has_devtorch_section,
            },
        }

    return app


# Module-level app instance — only created when FastAPI is available.
if HAS_FASTAPI:
    app = _build_app()
