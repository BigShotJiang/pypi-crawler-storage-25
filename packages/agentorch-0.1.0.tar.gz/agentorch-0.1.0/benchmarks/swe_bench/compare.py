"""
SWE-Bench Benchmark — Statistical comparison of baseline vs DevTorch.

Reads results/baseline.json and results/devtorch.json, computes:
  - pass@1 for each condition
  - absolute and relative improvement
  - two-proportion z-test (p-value, 95% CI on the delta)
  - token overhead from DevTorch context injection
  - per-task comparison table

Usage:
    python benchmarks/swe_bench/compare.py
    python benchmarks/swe_bench/compare.py --baseline results/baseline.json --devtorch results/devtorch.json
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

RESULTS_DIR = Path(__file__).parent / "results"


# ---------------------------------------------------------------------------
# Statistical test
# ---------------------------------------------------------------------------

def two_proportion_z_test(p1: float, n1: int, p2: float, n2: int) -> tuple[float, float, tuple[float, float]]:
    """
    Two-proportion z-test: H0: p1 == p2, H1: p2 > p1.

    Returns:
        z_stat   — z statistic
        p_value  — one-tailed p-value (P(Z > z_stat))
        ci_95    — (lower, upper) 95% confidence interval on (p2 - p1)
    """
    if n1 == 0 or n2 == 0:
        return 0.0, 1.0, (0.0, 0.0)

    p_pool = (p1 * n1 + p2 * n2) / (n1 + n2)
    se_pool = math.sqrt(p_pool * (1 - p_pool) * (1 / n1 + 1 / n2))

    if se_pool == 0:
        return 0.0, 0.5, (0.0, 0.0)

    z = (p2 - p1) / se_pool

    # One-tailed p-value from standard normal
    # Using approximation: erfc(z/sqrt(2)) / 2
    p_value = _normal_sf(z)

    # 95% CI on the difference (p2 - p1) — unpooled SE
    se_diff = math.sqrt(p1 * (1 - p1) / n1 + p2 * (1 - p2) / n2)
    delta = p2 - p1
    ci = (round(delta - 1.96 * se_diff, 4), round(delta + 1.96 * se_diff, 4))

    return round(z, 3), round(p_value, 4), ci


def _normal_sf(z: float) -> float:
    """Survival function of standard normal (1 - CDF) using math.erfc."""
    return 0.5 * math.erfc(z / math.sqrt(2))


# ---------------------------------------------------------------------------
# Load and summarise
# ---------------------------------------------------------------------------

def load_results(path: Path) -> dict:
    """Load results JSON, return summary dict."""
    if not path.exists():
        return {"path": str(path), "found": False}

    records = json.loads(path.read_text())
    total = len(records)
    resolved = [r for r in records if r.get("resolved") is True]
    not_resolved = [r for r in records if r.get("resolved") is False]
    unknown = [r for r in records if r.get("resolved") is None]

    pass_at_1 = len(resolved) / total if total else 0.0

    avg_input = sum(r.get("input_tokens", 0) for r in records) / total if total else 0
    avg_output = sum(r.get("output_tokens", 0) for r in records) / total if total else 0
    avg_context = sum(r.get("context_tokens_injected", 0) for r in records) / total if total else 0
    avg_time = sum(r.get("elapsed_s", 0) for r in records) / total if total else 0

    return {
        "path": str(path),
        "found": True,
        "total": total,
        "resolved": len(resolved),
        "not_resolved": len(not_resolved),
        "unknown": len(unknown),
        "pass_at_1": round(pass_at_1, 4),
        "avg_input_tokens": round(avg_input),
        "avg_output_tokens": round(avg_output),
        "avg_context_tokens": round(avg_context),
        "avg_total_tokens": round(avg_input + avg_output),
        "avg_elapsed_s": round(avg_time, 2),
        "records": records,
    }


def per_task_comparison(baseline_records: list, devtorch_records: list) -> list[dict]:
    """Return per-task diff: instance_id, baseline_resolved, devtorch_resolved."""
    b_map = {r["instance_id"]: r for r in baseline_records}
    d_map = {r["instance_id"]: r for r in devtorch_records}
    all_ids = sorted(set(b_map) | set(d_map))

    rows = []
    for iid in all_ids:
        b = b_map.get(iid, {})
        d = d_map.get(iid, {})
        rows.append({
            "instance_id": iid,
            "baseline_resolved": b.get("resolved"),
            "devtorch_resolved": d.get("resolved"),
            "baseline_tokens": b.get("total_tokens"),
            "devtorch_tokens": d.get("total_tokens"),
            "devtorch_context_tokens": d.get("context_tokens_injected", 0),
            "delta": (
                (1 if d.get("resolved") else 0) - (1 if b.get("resolved") else 0)
                if b.get("resolved") is not None and d.get("resolved") is not None
                else None
            ),
        })
    return rows


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="SWE-Bench results comparison + significance test")
    parser.add_argument("--baseline", default=str(RESULTS_DIR / "baseline.json"))
    parser.add_argument("--devtorch", default=str(RESULTS_DIR / "devtorch.json"))
    parser.add_argument("--per-task", action="store_true", help="Print per-task comparison table")
    args = parser.parse_args()

    b = load_results(Path(args.baseline))
    d = load_results(Path(args.devtorch))

    print(f"\n{'═' * 72}")
    print(f"  SWE-Bench Lite — DevTorch vs Baseline Comparison")
    print(f"{'═' * 72}")

    if not b["found"] or not d["found"]:
        if not b["found"]:
            print(f"  ✗ Baseline results not found: {args.baseline}")
            print(f"    Run: python run_baseline.py --tasks <swebench_lite.json> --output results/baseline.json")
        if not d["found"]:
            print(f"  ✗ DevTorch results not found: {args.devtorch}")
            print(f"    Run: python run_devtorch.py --tasks <swebench_lite.json> --repos <repos_dir> --output results/devtorch.json")
        return

    # Summary table
    print(f"\n  {'Metric':<35} {'Baseline':>12} {'DevTorch':>12}")
    print(f"  {'─' * 33} {'─' * 12} {'─' * 12}")
    print(f"  {'Tasks evaluated':<35} {b['total']:>12} {d['total']:>12}")
    print(f"  {'Tasks resolved':<35} {b['resolved']:>12} {d['resolved']:>12}")
    print(f"  {'pass@1':<35} {b['pass_at_1']:>12.4f} {d['pass_at_1']:>12.4f}")
    print(f"  {'Avg input tokens/task':<35} {b['avg_input_tokens']:>12,} {d['avg_input_tokens']:>12,}")
    print(f"  {'Avg context tokens injected':<35} {b['avg_context_tokens']:>12,} {d['avg_context_tokens']:>12,}")
    print(f"  {'Avg total tokens/task':<35} {b['avg_total_tokens']:>12,} {d['avg_total_tokens']:>12,}")
    print(f"  {'Avg wall-clock time/task (s)':<35} {b['avg_elapsed_s']:>12.2f} {d['avg_elapsed_s']:>12.2f}")

    # Delta
    delta = d["pass_at_1"] - b["pass_at_1"]
    pct = (d["pass_at_1"] / b["pass_at_1"] - 1) * 100 if b["pass_at_1"] > 0 else float("inf")
    token_overhead = (
        (d["avg_total_tokens"] / b["avg_total_tokens"] - 1) * 100
        if b["avg_total_tokens"] > 0 else 0
    )

    print(f"\n  {'─' * 59}")
    print(f"  pass@1 delta              : {delta:+.4f}")
    print(f"  Relative improvement      : {pct:+.1f}%")
    print(f"  Token overhead            : {token_overhead:+.1f}%")

    # Statistical significance
    z, p, ci = two_proportion_z_test(
        b["pass_at_1"], b["total"],
        d["pass_at_1"], d["total"],
    )
    significant = p < 0.05
    sig_str = f"YES (p={p})" if significant else f"NO (p={p})"
    print(f"\n  Two-proportion z-test:")
    print(f"    z-statistic             : {z}")
    print(f"    p-value (one-tailed)    : {p}")
    print(f"    95% CI on delta         : [{ci[0]}, {ci[1]}]")
    print(f"    Significant (p < 0.05)? : {sig_str}")

    # Token efficiency
    if d["avg_context_tokens"] > 0 and delta > 0:
        tasks_won = d["resolved"] - b["resolved"]
        context_total = d["avg_context_tokens"] * d["total"]
        tokens_per_win = context_total / tasks_won if tasks_won > 0 else float("inf")
        print(f"\n  Context efficiency:")
        print(f"    Additional tasks resolved : {tasks_won}")
        print(f"    Total context tokens used : {context_total:,}")
        print(f"    Context tokens per win    : {tokens_per_win:,.0f}")

    print(f"\n{'═' * 72}")

    # Per-task table
    if args.per_task:
        rows = per_task_comparison(b.get("records", []), d.get("records", []))
        print(f"\n  Per-task comparison ({len(rows)} tasks):")
        print(f"  {'Instance ID':<45} {'Baseline':>8} {'DevTorch':>8} {'Delta':>6}")
        print(f"  {'─' * 43} {'─' * 8} {'─' * 8} {'─' * 6}")
        for row in rows:
            b_str = "✓" if row["baseline_resolved"] else ("?" if row["baseline_resolved"] is None else "✗")
            d_str = "✓" if row["devtorch_resolved"] else ("?" if row["devtorch_resolved"] is None else "✗")
            delta_str = f"{row['delta']:+d}" if row["delta"] is not None else "  ?"
            print(f"  {row['instance_id']:<45} {b_str:>8} {d_str:>8} {delta_str:>6}")

    # Save comparison JSON
    comparison_path = RESULTS_DIR / "comparison.json"
    comparison = {
        "baseline": {k: v for k, v in b.items() if k != "records"},
        "devtorch": {k: v for k, v in d.items() if k != "records"},
        "delta_pass_at_1": delta,
        "relative_improvement_pct": round(pct, 2),
        "token_overhead_pct": round(token_overhead, 2),
        "significance": {
            "z_stat": z,
            "p_value": p,
            "ci_95": ci,
            "significant_at_0_05": significant,
        },
    }
    comparison_path.write_text(json.dumps(comparison, indent=2))
    print(f"\n  Full comparison saved to: {comparison_path}")


if __name__ == "__main__":
    main()
