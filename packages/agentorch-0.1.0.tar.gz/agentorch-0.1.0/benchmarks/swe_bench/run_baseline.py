"""
SWE-Bench Benchmark — Baseline runner (model only, no DevTorch context).

Runs SWE-Bench Lite tasks using the Anthropic API with no DevTorch context
injection. Records pass@1 result, tokens used, and wall-clock time per task.

Prerequisites:
  - SWE-Bench Lite dataset downloaded (see setup.sh)
  - ANTHROPIC_API_KEY set in environment
  - pip install devtorch[wrapper] anthropic swebench

Usage:
    python benchmarks/swe_bench/run_baseline.py --tasks swebench_lite.json --output results/baseline.json
    python benchmarks/swe_bench/run_baseline.py --tasks swebench_lite.json --limit 10 --output results/baseline_10.json
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

SYSTEM_PROMPT = """You are an expert software engineer. You will be given a GitHub issue
and the relevant source files. Your task is to produce a patch that fixes the issue.

Output your patch in unified diff format between <patch> and </patch> tags.
Only output the patch — no explanations."""


def _load_tasks(tasks_path: Path, limit: int | None = None) -> list[dict]:
    with open(tasks_path) as f:
        tasks = json.load(f)
    if limit:
        tasks = tasks[:limit]
    return tasks


def _call_model(client, system: str, user: str, model: str) -> dict:
    """Call the model and return {text, input_tokens, output_tokens, elapsed_s}."""
    t0 = time.monotonic()
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    elapsed = time.monotonic() - t0

    text = ""
    for block in response.content:
        if hasattr(block, "text"):
            text += block.text

    return {
        "text": text,
        "input_tokens": response.usage.input_tokens,
        "output_tokens": response.usage.output_tokens,
        "elapsed_s": round(elapsed, 2),
    }


def _extract_patch(text: str) -> str:
    """Extract unified diff from between <patch>...</patch> tags."""
    import re
    m = re.search(r"<patch>(.*?)</patch>", text, re.DOTALL)
    return m.group(1).strip() if m else ""


def _evaluate_patch(task: dict, patch: str) -> bool:
    """
    Evaluate whether the patch resolves the SWE-Bench task.

    In a full SWE-Bench setup this runs the test suite inside Docker.
    This stub returns False — replace with the real evaluator from
    the swebench package: `from swebench.harness.run_evaluation import ...`
    """
    # STUB: real evaluation requires Docker + swebench harness
    # See: https://github.com/princeton-nlp/SWE-bench
    # from swebench.harness.run_evaluation import evaluate_predictions
    # result = evaluate_predictions(task["instance_id"], patch, ...)
    # return result["resolved"]
    raise NotImplementedError(
        "Real SWE-Bench evaluation requires Docker and the swebench package.\n"
        "Install: pip install swebench\n"
        "Run: python -m swebench.harness.run_evaluation ..."
    )


def run_baseline(tasks_path: Path, output_path: Path, model: str, limit: int | None = None) -> None:
    try:
        import anthropic
    except ImportError:
        print("Error: anthropic package required. pip install devtorch[wrapper]", file=sys.stderr)
        sys.exit(1)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY not set", file=sys.stderr)
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)
    tasks = _load_tasks(tasks_path, limit)

    results = []
    passed = 0
    print(f"Baseline run — {len(tasks)} tasks, model={model}")

    for i, task in enumerate(tasks):
        instance_id = task["instance_id"]
        problem_statement = task.get("problem_statement", "")
        # In SWE-Bench, 'hints_text' or relevant source files are typically provided
        hints = task.get("hints_text", "")
        user_content = f"Issue: {problem_statement}\n\nHints: {hints}"

        print(f"  [{i+1}/{len(tasks)}] {instance_id} ...", end=" ", flush=True)

        try:
            result = _call_model(client, SYSTEM_PROMPT, user_content, model)
            patch = _extract_patch(result["text"])

            try:
                resolved = _evaluate_patch(task, patch)
            except NotImplementedError:
                resolved = None  # evaluation not available

            record = {
                "instance_id": instance_id,
                "condition": "baseline",
                "model": model,
                "resolved": resolved,
                "patch_length": len(patch),
                "input_tokens": result["input_tokens"],
                "output_tokens": result["output_tokens"],
                "total_tokens": result["input_tokens"] + result["output_tokens"],
                "elapsed_s": result["elapsed_s"],
            }
            results.append(record)

            if resolved:
                passed += 1
                print("✓ resolved")
            elif resolved is None:
                print("? (evaluation stub — needs Docker)")
            else:
                print("✗ not resolved")

        except Exception as exc:
            print(f"ERROR: {exc}")
            results.append({
                "instance_id": instance_id,
                "condition": "baseline",
                "model": model,
                "resolved": False,
                "error": str(exc),
            })

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(results, indent=2))

    total = len(results)
    pass_at_1 = passed / total if total else 0.0
    print(f"\nBaseline: {passed}/{total} resolved — pass@1 = {pass_at_1:.3f}")
    print(f"Results written to: {output_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="SWE-Bench baseline runner (model only)")
    parser.add_argument("--tasks", required=True, help="Path to swebench_lite.json task file")
    parser.add_argument("--output", default="results/baseline.json", help="Output JSON path")
    parser.add_argument("--model", default="claude-sonnet-4-6", help="Anthropic model ID")
    parser.add_argument("--limit", type=int, help="Limit to first N tasks (for smoke test)")
    args = parser.parse_args()

    run_baseline(
        tasks_path=Path(args.tasks),
        output_path=Path(args.output),
        model=args.model,
        limit=args.limit,
    )


if __name__ == "__main__":
    main()
