"""
SWE-Bench Benchmark — Seed .GCC/ from git history.

For each SWE-Bench task, the target repository is a real open-source Python
project at a specific git commit. This script seeds a temporary .GCC/ store
by running `devtorch commit` for the 50 most recent git commits, giving
DevTorch's context bundle meaningful content about the repo's prior decisions.

Usage:
    python benchmarks/swe_bench/seed_gcc.py --repo /path/to/cloned/repo --gcc /path/to/.GCC/parent
    python benchmarks/swe_bench/seed_gcc.py --repo /tmp/django --gcc /tmp/django --commits 30
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))


def _git_log(repo_path: Path, n: int) -> list[dict]:
    """Return the last n git commits as list of {sha, message, files_changed}."""
    result = subprocess.run(
        ["git", "log", f"-{n}", "--format=%H\t%s", "--name-only"],
        capture_output=True, text=True, cwd=repo_path,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git log failed: {result.stderr}")

    commits = []
    current: dict | None = None
    for line in result.stdout.splitlines():
        if "\t" in line and len(line.split("\t")[0]) == 40:
            if current:
                commits.append(current)
            sha, subject = line.split("\t", 1)
            current = {"sha": sha, "subject": subject, "files": []}
        elif line.strip() and current is not None:
            current["files"].append(line.strip())
    if current:
        commits.append(current)
    return commits


def _infer_concept(files: list[str]) -> str:
    """Map changed file paths to a DevTorch concept."""
    joined = " ".join(files).lower()
    if any(x in joined for x in ["auth", "login", "token", "session"]):
        return "auth"
    if any(x in joined for x in ["migration", "schema", "model"]):
        return "schema"
    if any(x in joined for x in ["test", "spec"]):
        return "testing"
    if any(x in joined for x in ["api", "view", "endpoint", "route"]):
        return "api"
    if any(x in joined for x in ["config", "setting", "env"]):
        return "config"
    if any(x in joined for x in ["deploy", "docker", "ci", "workflow"]):
        return "deploy"
    return "general"


def seed_gcc(repo_path: Path, gcc_parent: Path, n_commits: int = 50) -> int:
    """
    Seed a .GCC/ store at gcc_parent from repo_path's git history.

    Returns the number of commits seeded.
    """
    from devtorch_core import GCCRepository
    from devtorch_core.sensitivity import SensitivityEvent

    repo = GCCRepository.at(gcc_parent)
    if not repo.is_initialized():
        repo.init()

    commits = _git_log(repo_path, n_commits)
    seeded = 0

    for commit in reversed(commits):  # oldest first
        message = commit["subject"]
        if not message.strip():
            continue

        # Commit to GCC
        repo.commit(message=f"[git:{commit['sha'][:7]}] {message}")

        # Add sensitivity event from file paths
        concept = _infer_concept(commit["files"])
        if concept != "general" or commit["files"]:
            ev = SensitivityEvent(
                source_node="git_history_seed",
                target_concept=concept,
                counterfactuals=f"Files changed: {', '.join(commit['files'][:5])}",
                confidence=0.6,  # seeded from history, lower confidence than live capture
                disclosure_level="PUBLIC",
                message=message[:200],
            )
            repo.add_sensitivity(ev)

        seeded += 1

    return seeded


def main() -> None:
    parser = argparse.ArgumentParser(description="Seed .GCC/ from git history for SWE-Bench")
    parser.add_argument("--repo", required=True, help="Path to the cloned git repository")
    parser.add_argument("--gcc", required=True, help="Path to the directory that will contain .GCC/")
    parser.add_argument("--commits", type=int, default=50, help="Number of recent commits to seed (default: 50)")
    args = parser.parse_args()

    repo_path = Path(args.repo).resolve()
    gcc_path = Path(args.gcc).resolve()

    if not (repo_path / ".git").exists():
        print(f"Error: {repo_path} is not a git repository", file=sys.stderr)
        sys.exit(1)

    print(f"Seeding .GCC/ from {repo_path} (last {args.commits} commits)...")
    n = seed_gcc(repo_path, gcc_path, args.commits)
    print(f"Seeded {n} commits → .GCC/ at {gcc_path / '.GCC'}")


if __name__ == "__main__":
    main()
