"""
SWE-Bench Benchmark — DevTorch runner (with context injection).

For each SWE-Bench task:
  1. Seeds a temporary .GCC/ store from the target repo's git history.
  2. Calls devtorch context --k 4000 to build a context bundle.
  3. Prepends the bundle to the system prompt via RACPInjector.
  4. Calls the model with the augmented prompt.
  5. Records pass@1, tokens (including context overhead), and wall-clock time.

Prerequisites:
  - S7 LLM Wrapper complete (devtorch_core.wrapper.anthropic)
  - SWE-Bench Lite dataset downloaded (see setup.sh)
  - ANTHROPIC_API_KEY set in environment
  - pip install devtorch[wrapper] anthropic swebench

Usage:
    python benchmarks/swe_bench/run_devtorch.py --tasks swebench_lite.json --repos /tmp/swe_repos --output results/devtorch.json
    python benchmarks/swe_bench/run_devtorch.py --tasks swebench_lite.json --repos /tmp/swe_repos --limit 10 --output results/devtorch_10.json
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

BASE_SYSTEM_PROMPT = """You are an expert software engineer. You will be given a GitHub issue
and the relevant source files. Your task is to produce a patch that fixes the issue.

Output your patch in unified diff format between <patch> and </patch> tags.
Only output the patch — no explanations."""


def _build_devtorch_prefix(gcc_parent: Path, k_tokens: int = 4000) -> str:
    """
    Build the DevTorch context prefix for system prompt injection.
    Returns empty string if .GCC/ is not found or context is empty.
    """
    try:
        from devtorch_core import GCCRepository
        from devtorch_core.wrapper.base import RACPInjector

        repo = GCCRepository.at(gcc_parent)
        if not repo.is_initialized():
            return ""

        injector = RACPInjector(repo)
        # Override k_tokens for the bundle
        repo._context_k_override = k_tokens
        prefix = injector.build_system_prefix()
        return prefix
    except Exception as exc:
        print(f"    [devtorch] context build failed — {exc}", file=sys.stderr)
        return ""


def _call_model(client, system: str, user: str, model: str) -> dict:
    t0 = time.monotonic()
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    elapsed = time.monotonic() - t0

    text = ""
    for block in response.content:
        if hasattr(block, "text"):
            text += block.text

    return {
        "text": text,
        "input_tokens": response.usage.input_tokens,
        "output_tokens": response.usage.output_tokens,
        "elapsed_s": round(elapsed, 2),
    }


def _extract_patch(text: str) -> str:
    m = re.search(r"<patch>(.*?)</patch>", text, re.DOTALL)
    return m.group(1).strip() if m else ""


def _evaluate_patch(task: dict, patch: str) -> bool:
    # STUB — see run_baseline.py for instructions on real evaluation
    raise NotImplementedError(
        "Real SWE-Bench evaluation requires Docker and the swebench package."
    )


def _get_repo_path(repos_dir: Path, task: dict) -> Path | None:
    """Return the cloned repo path for this task, or None if not found."""
    repo_name = task.get("repo", "").replace("/", "__")
    base_commit = task.get("base_commit", "")[:7]

    # Try common naming patterns used by SWE-Bench tooling
    for name in [
        f"{repo_name}__{base_commit}",
        repo_name,
        task.get("instance_id", ""),
    ]:
        candidate = repos_dir / name
        if (candidate / ".git").exists():
            return candidate
    return None


def run_devtorch(
    tasks_path: Path,
    repos_dir: Path,
    output_path: Path,
    model: str,
    k_tokens: int = 4000,
    limit: int | None = None,
) -> None:
    try:
        import anthropic
    except ImportError:
        print("Error: anthropic package required. pip install devtorch[wrapper]", file=sys.stderr)
        sys.exit(1)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY not set", file=sys.stderr)
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)

    with open(tasks_path) as f:
        tasks = json.load(f)
    if limit:
        tasks = tasks[:limit]

    results = []
    passed = 0
    print(f"DevTorch run — {len(tasks)} tasks, model={model}, context_k={k_tokens}")

    for i, task in enumerate(tasks):
        instance_id = task["instance_id"]
        problem_statement = task.get("problem_statement", "")
        hints = task.get("hints_text", "")
        user_content = f"Issue: {problem_statement}\n\nHints: {hints}"

        print(f"  [{i+1}/{len(tasks)}] {instance_id} ...", end=" ", flush=True)

        context_tokens = 0
        context_used = False

        try:
            # --- Seed .GCC/ from git history ---
            with tempfile.TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                repo_path = _get_repo_path(repos_dir, task)

                from seed_gcc import seed_gcc  # type: ignore[import]
                if repo_path:
                    seeded = seed_gcc(repo_path, tmp_path, n_commits=50)
                    print(f"(seeded {seeded} commits)", end=" ", flush=True)
                else:
                    print("(no repo — no context)", end=" ", flush=True)

                # --- Build DevTorch context prefix ---
                prefix = _build_devtorch_prefix(tmp_path, k_tokens=k_tokens)
                if prefix:
                    system = (prefix + "\n\n" + BASE_SYSTEM_PROMPT).strip()
                    # Estimate prefix tokens (rough: 1 token ≈ 4 chars)
                    context_tokens = len(prefix) // 4
                    context_used = True
                else:
                    system = BASE_SYSTEM_PROMPT

                # --- Call model ---
                result = _call_model(client, system, user_content, model)
                patch = _extract_patch(result["text"])

                try:
                    resolved = _evaluate_patch(task, patch)
                except NotImplementedError:
                    resolved = None

                record = {
                    "instance_id": instance_id,
                    "condition": "devtorch",
                    "model": model,
                    "resolved": resolved,
                    "patch_length": len(patch),
                    "input_tokens": result["input_tokens"],
                    "output_tokens": result["output_tokens"],
                    "total_tokens": result["input_tokens"] + result["output_tokens"],
                    "context_tokens_injected": context_tokens,
                    "context_used": context_used,
                    "elapsed_s": result["elapsed_s"],
                }
                results.append(record)

                if resolved:
                    passed += 1
                    print("✓ resolved")
                elif resolved is None:
                    print("? (evaluation stub — needs Docker)")
                else:
                    print("✗ not resolved")

        except Exception as exc:
            print(f"ERROR: {exc}")
            results.append({
                "instance_id": instance_id,
                "condition": "devtorch",
                "model": model,
                "resolved": False,
                "error": str(exc),
            })

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(results, indent=2))

    total = len(results)
    pass_at_1 = passed / total if total else 0.0
    print(f"\nDevTorch: {passed}/{total} resolved — pass@1 = {pass_at_1:.3f}")
    print(f"Results written to: {output_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="SWE-Bench DevTorch runner (with context injection)")
    parser.add_argument("--tasks", required=True, help="Path to swebench_lite.json task file")
    parser.add_argument("--repos", required=True, help="Directory containing cloned repos (one per task)")
    parser.add_argument("--output", default="results/devtorch.json", help="Output JSON path")
    parser.add_argument("--model", default="claude-sonnet-4-6", help="Anthropic model ID")
    parser.add_argument("--context-k", type=int, default=4000, help="Token budget for context bundle (default: 4000)")
    parser.add_argument("--limit", type=int, help="Limit to first N tasks (for smoke test)")
    args = parser.parse_args()

    run_devtorch(
        tasks_path=Path(args.tasks),
        repos_dir=Path(args.repos),
        output_path=Path(args.output),
        model=args.model,
        k_tokens=args.context_k,
        limit=args.limit,
    )


if __name__ == "__main__":
    main()
