"""
Hidden Profile Benchmark — Baseline runner (no DevTorch coordination).

Each agent receives only its own private_info. No theta reads, no sensitivity
sharing. Agents produce decisions in isolation. Results written to
results/baseline/<scenario_id>/<agent_id>.json.

Usage:
    python benchmarks/hidden_profile/run_baseline.py
    python benchmarks/hidden_profile/run_baseline.py --scenario banking_api
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

PROBLEMS_DIR = Path(__file__).parent / "problems"
RESULTS_DIR = Path(__file__).parent / "results" / "baseline"


# ---------------------------------------------------------------------------
# Deterministic agent — makes decisions from private_info only
# ---------------------------------------------------------------------------

def agent_decide(agent: dict, scenario: dict, shared_theta: dict | None = None) -> dict:
    """
    Deterministic decision function.

    In the baseline, shared_theta is always None — agents have no visibility
    into what other agents know.

    Returns a decision dict:
      {
        "agent_id": str,
        "constraints_included": [constraint_id, ...],
        "decision_text": str,
        "used_theta": bool,
      }
    """
    constraints_included = [c["constraint_id"] for c in agent["private_info"]]

    if shared_theta:
        # DevTorch path: extend decisions based on theta signals
        for concept, data in shared_theta.items():
            if data.get("mean_confidence", 0) >= 0.6:
                # A peer flagged something relevant — include it if it maps
                # to a constraint in the scenario we haven't already covered
                for req in scenario["required_constraints"]:
                    if req not in constraints_included:
                        # Check if the theta concept overlaps with this constraint's concept
                        for a in scenario["agents"]:
                            for pi in a["private_info"]:
                                if (pi["constraint_id"] == req and
                                        concept in pi.get("affects", [])):
                                    constraints_included.append(req)

    decision_text_parts = [f"Agent: {agent['id']} ({agent['role']})"]
    for c in agent["private_info"]:
        decision_text_parts.append(f"  Constraint enforced: {c['constraint_id']}")
        decision_text_parts.append(f"    {c['description'][:120]}...")

    if shared_theta:
        decision_text_parts.append(f"  Theta signals read: {list(shared_theta.keys())}")

    return {
        "agent_id": agent["id"],
        "constraints_included": constraints_included,
        "decision_text": "\n".join(decision_text_parts),
        "used_theta": shared_theta is not None,
    }


# ---------------------------------------------------------------------------
# Run one scenario
# ---------------------------------------------------------------------------

def run_scenario(scenario_path: Path) -> dict:
    """Run all agents in isolation. Returns per-agent decision dicts."""
    with open(scenario_path) as f:
        scenario = yaml.safe_load(f)

    scenario_id = scenario["id"]
    out_dir = RESULTS_DIR / scenario_id
    out_dir.mkdir(parents=True, exist_ok=True)

    decisions = []
    for agent in scenario["agents"]:
        decision = agent_decide(agent, scenario, shared_theta=None)
        decisions.append(decision)

        out_file = out_dir / f"{agent['id']}.json"
        out_file.write_text(json.dumps(decision, indent=2))

    # Write scenario manifest
    manifest = {
        "scenario_id": scenario_id,
        "condition": "baseline",
        "agent_ids": [a["id"] for a in scenario["agents"]],
        "required_constraints": scenario["required_constraints"],
    }
    (out_dir / "_manifest.json").write_text(json.dumps(manifest, indent=2))

    print(f"  [baseline] {scenario_id}: {len(decisions)} agents wrote decisions")
    return {"scenario_id": scenario_id, "decisions": decisions, "scenario": scenario}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Hidden Profile baseline runner")
    parser.add_argument("--scenario", help="Run only this scenario ID (default: all)")
    args = parser.parse_args()

    problem_files = sorted(PROBLEMS_DIR.glob("*.yaml"))
    if not problem_files:
        print(f"No scenario files found in {PROBLEMS_DIR}", file=sys.stderr)
        sys.exit(1)

    if args.scenario:
        problem_files = [p for p in problem_files if args.scenario in p.stem]
        if not problem_files:
            print(f"No scenario matching '{args.scenario}' found", file=sys.stderr)
            sys.exit(1)

    print(f"Running baseline (no coordination) — {len(problem_files)} scenario(s)")
    for path in problem_files:
        run_scenario(path)

    print(f"\nBaseline results written to: {RESULTS_DIR}")


if __name__ == "__main__":
    main()
