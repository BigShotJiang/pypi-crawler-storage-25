"""
Hidden Profile Benchmark — DevTorch runner (with coordination).

Each agent writes sensitivity events to a shared .GCC/ store after its first
decision pass. The theta coordination vector is then read by all agents before
their final decision. Agents that see a theta signal for a concept they don't
hold privately can include the signalled constraint in their output.

Results written to results/devtorch/<scenario_id>/<agent_id>.json.

Usage:
    python benchmarks/hidden_profile/run_devtorch.py
    python benchmarks/hidden_profile/run_devtorch.py --scenario banking_api
"""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

import yaml

# Insert repo root so devtorch_core is importable without install
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

PROBLEMS_DIR = Path(__file__).parent / "problems"
RESULTS_DIR = Path(__file__).parent / "results" / "devtorch"

# Re-use the deterministic agent decision function from the baseline runner
from run_baseline import agent_decide  # type: ignore[import]


# ---------------------------------------------------------------------------
# DevTorch coordination round
# ---------------------------------------------------------------------------

def _init_gcc(tmp_dir: Path):
    """Initialise a fresh .GCC/ repo in tmp_dir for one benchmark run."""
    from devtorch_core import GCCRepository
    repo = GCCRepository.at(tmp_dir)
    repo.init()
    return repo


def _write_sensitivity(repo, agent: dict) -> None:
    """Each agent writes its private constraints as sensitivity events."""
    from devtorch_core.sensitivity import SensitivityEvent

    for constraint in agent["private_info"]:
        ev = SensitivityEvent(
            source_node=agent["id"],
            target_concept=constraint["affects"][0] if constraint["affects"] else "general",
            counterfactuals=constraint["description"][:200],
            confidence=0.9,
            disclosure_level="PUBLIC",
            message=f"{constraint['constraint_id']}: {constraint['description'][:100]}",
        )
        repo.add_sensitivity(ev)
        repo.commit(message=f"[{agent['id']}] constraint: {constraint['constraint_id']}")


def _read_theta(repo) -> dict:
    """Return the current coordination vector from .GCC/theta.json."""
    theta = repo.get_theta()
    return theta.get("coordination_vector", {})


# ---------------------------------------------------------------------------
# Run one scenario with DevTorch coordination
# ---------------------------------------------------------------------------

def run_scenario(scenario_path: Path) -> dict:
    """
    Two-round coordination:
      Round 1 — each agent writes its private constraints to theta (sensitivity events).
      Round 2 — each agent reads theta and makes a final decision incorporating
                 any signals from peers.
    """
    with open(scenario_path) as f:
        scenario = yaml.safe_load(f)

    scenario_id = scenario["id"]
    out_dir = RESULTS_DIR / scenario_id
    out_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        repo = _init_gcc(tmp_path)

        # --- Round 1: each agent publishes its private constraints ---
        for agent in scenario["agents"]:
            _write_sensitivity(repo, agent)

        # --- Theta is now populated with signals from all agents ---
        shared_theta = _read_theta(repo)

        # --- Round 2: each agent makes final decision with theta visibility ---
        decisions = []
        for agent in scenario["agents"]:
            decision = agent_decide(agent, scenario, shared_theta=shared_theta)
            decisions.append(decision)

            out_file = out_dir / f"{agent['id']}.json"
            out_file.write_text(json.dumps(decision, indent=2))

        # Write theta snapshot
        (out_dir / "_theta_snapshot.json").write_text(json.dumps(shared_theta, indent=2))

        # Write scenario manifest
        manifest = {
            "scenario_id": scenario_id,
            "condition": "devtorch",
            "agent_ids": [a["id"] for a in scenario["agents"]],
            "required_constraints": scenario["required_constraints"],
            "theta_concepts": list(shared_theta.keys()),
        }
        (out_dir / "_manifest.json").write_text(json.dumps(manifest, indent=2))

    print(f"  [devtorch] {scenario_id}: {len(decisions)} agents, theta={list(shared_theta.keys())}")
    return {"scenario_id": scenario_id, "decisions": decisions, "scenario": scenario}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Hidden Profile DevTorch runner")
    parser.add_argument("--scenario", help="Run only this scenario ID (default: all)")
    args = parser.parse_args()

    problem_files = sorted(PROBLEMS_DIR.glob("*.yaml"))
    if not problem_files:
        print(f"No scenario files found in {PROBLEMS_DIR}", file=sys.stderr)
        sys.exit(1)

    if args.scenario:
        problem_files = [p for p in problem_files if args.scenario in p.stem]
        if not problem_files:
            print(f"No scenario matching '{args.scenario}' found", file=sys.stderr)
            sys.exit(1)

    print(f"Running DevTorch coordination — {len(problem_files)} scenario(s)")
    for path in problem_files:
        run_scenario(path)

    print(f"\nDevTorch results written to: {RESULTS_DIR}")


if __name__ == "__main__":
    main()
