"""
Hidden Profile Benchmark — Scoring function.

Reads agent decision files from results/<condition>/<scenario_id>/ and
computes an accuracy score (0.0–1.0) per scenario.

Scoring rules:
  1.0  — all required_constraints surfaced across collective agent decisions;
          no contradictions between agents.
  0.5–0.9 — some constraints surfaced; partial credit for partial pooling.
  0.0  — contradictions present (two agents proposed incompatible choices),
          or fewer than half of required_constraints were surfaced.

Usage:
    python benchmarks/hidden_profile/score.py
    python benchmarks/hidden_profile/score.py --condition baseline
    python benchmarks/hidden_profile/score.py --condition devtorch
    python benchmarks/hidden_profile/score.py --compare   # both conditions side-by-side
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import NamedTuple

import yaml

PROBLEMS_DIR = Path(__file__).parent / "problems"
RESULTS_BASE = Path(__file__).parent / "results"


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

class ScenarioScore(NamedTuple):
    scenario_id: str
    condition: str
    constraints_required: list[str]
    constraints_found: list[str]
    constraints_missing: list[str]
    contradictions_detected: list[str]
    score: float
    verdict: str


# ---------------------------------------------------------------------------
# Score one scenario / condition pair
# ---------------------------------------------------------------------------

def score_scenario(scenario_path: Path, condition: str) -> ScenarioScore | None:
    with open(scenario_path) as f:
        scenario = yaml.safe_load(f)

    scenario_id = scenario["id"]
    results_dir = RESULTS_BASE / condition / scenario_id

    if not results_dir.exists():
        return None

    # --- Load all agent decisions ---
    agent_decisions: dict[str, dict] = {}
    for agent in scenario["agents"]:
        agent_file = results_dir / f"{agent['id']}.json"
        if agent_file.exists():
            agent_decisions[agent["id"]] = json.loads(agent_file.read_text())

    if not agent_decisions:
        return None

    # --- Collect all constraints surfaced across all agents ---
    all_constraints_found: set[str] = set()
    for decision in agent_decisions.values():
        all_constraints_found.update(decision.get("constraints_included", []))

    required = set(scenario["required_constraints"])
    found = required & all_constraints_found
    missing = required - all_constraints_found

    # --- Check for contradictions ---
    contradictions_detected: list[str] = []
    for contradiction in scenario.get("contradictions", []):
        agents_involved = contradiction["agents"]
        condition_desc = contradiction["condition"]

        # A contradiction is "detected" if the agents involved each included
        # only their own constraint and did NOT include the other's constraint
        # (meaning they didn't coordinate and will produce incompatible outputs)
        decisions_for = [
            agent_decisions[a] for a in agents_involved if a in agent_decisions
        ]
        if len(decisions_for) == len(agents_involved):
            agent_constraint_sets = [
                set(d.get("constraints_included", [])) for d in decisions_for
            ]
            # Contradiction fires if the agents' constraint sets are disjoint
            # (neither agent knows about the other's constraint)
            if len(agents_involved) == 2:
                union = agent_constraint_sets[0] | agent_constraint_sets[1]
                intersection = agent_constraint_sets[0] & agent_constraint_sets[1]
                # If intersection is empty and both agents only have their own constraint
                # from the contradiction pair, they didn't coordinate
                a0_unique = agent_constraint_sets[0] - agent_constraint_sets[1]
                a1_unique = agent_constraint_sets[1] - agent_constraint_sets[0]
                if a0_unique and a1_unique:
                    contradictions_detected.append(f"{agents_involved[0]} ⟷ {agents_involved[1]}: {condition_desc[:80]}")

    # --- Compute score ---
    n_required = len(required)
    n_found = len(found)
    n_missing = len(missing)
    n_contradictions = len(contradictions_detected)

    if n_contradictions > 0:
        # Contradictions cap the score at 0.3 regardless of constraints found
        base = (n_found / n_required) * 0.3
        score = round(base, 2)
        verdict = f"CONTRADICTIONS ({n_contradictions}) — coordination failure"
    elif n_missing == 0:
        score = 1.0
        verdict = "ALL CONSTRAINTS POOLED — full coordination"
    elif n_found >= n_required * 0.75:
        score = round(0.5 + 0.4 * (n_found / n_required), 2)
        verdict = f"PARTIAL ({n_found}/{n_required} constraints) — some pooling"
    elif n_found >= n_required * 0.5:
        score = round(0.3 + 0.2 * (n_found / n_required), 2)
        verdict = f"LOW ({n_found}/{n_required} constraints) — minimal pooling"
    else:
        score = round(0.1 * (n_found / n_required), 2)
        verdict = f"FAILED ({n_found}/{n_required} constraints) — information siloed"

    return ScenarioScore(
        scenario_id=scenario_id,
        condition=condition,
        constraints_required=list(required),
        constraints_found=list(found),
        constraints_missing=list(missing),
        contradictions_detected=contradictions_detected,
        score=score,
        verdict=verdict,
    )


# ---------------------------------------------------------------------------
# Print results table
# ---------------------------------------------------------------------------

def print_scores(scores: list[ScenarioScore], title: str) -> float:
    if not scores:
        print(f"\n{title}: no results found")
        return 0.0

    print(f"\n{'─' * 72}")
    print(f"  {title}")
    print(f"{'─' * 72}")
    print(f"  {'Scenario':<28} {'Score':>6}  {'Verdict'}")
    print(f"  {'─' * 26} {'─' * 6}  {'─' * 35}")

    total = 0.0
    for s in scores:
        total += s.score
        score_str = f"{s.score:.2f}"
        color = ""
        if s.score >= 0.9:
            color = "✓"
        elif s.score >= 0.5:
            color = "~"
        else:
            color = "✗"
        print(f"  {color} {s.scenario_id:<26} {score_str:>6}  {s.verdict}")
        if s.constraints_missing:
            print(f"      Missing: {', '.join(s.constraints_missing)}")
        if s.contradictions_detected:
            print(f"      Contradictions: {len(s.contradictions_detected)}")

    avg = total / len(scores)
    print(f"{'─' * 72}")
    print(f"  {'AGGREGATE':<28} {avg:.2f}")
    print(f"{'─' * 72}")
    return avg


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Hidden Profile benchmark scorer")
    parser.add_argument("--condition", choices=["baseline", "devtorch"],
                        help="Score only this condition (default: both)")
    parser.add_argument("--compare", action="store_true",
                        help="Print side-by-side comparison table")
    args = parser.parse_args()

    problem_files = sorted(PROBLEMS_DIR.glob("*.yaml"))
    if not problem_files:
        print(f"No scenario files found in {PROBLEMS_DIR}")
        return

    conditions = [args.condition] if args.condition else ["baseline", "devtorch"]

    all_scores: dict[str, list[ScenarioScore]] = {}
    for condition in conditions:
        scores = []
        for path in problem_files:
            s = score_scenario(path, condition)
            if s:
                scores.append(s)
        all_scores[condition] = scores

    if args.compare or len(conditions) == 2:
        # Side-by-side comparison
        baseline_scores = {s.scenario_id: s for s in all_scores.get("baseline", [])}
        devtorch_scores = {s.scenario_id: s for s in all_scores.get("devtorch", [])}
        all_ids = sorted(set(baseline_scores) | set(devtorch_scores))

        print(f"\n{'═' * 80}")
        print(f"  Hidden Profile Benchmark — Coordination Accuracy Comparison")
        print(f"{'═' * 80}")
        print(f"  {'Scenario':<28} {'Baseline':>9} {'DevTorch':>9} {'Delta':>7}")
        print(f"  {'─' * 26} {'─' * 9} {'─' * 9} {'─' * 7}")

        baseline_total = devtorch_total = 0.0
        count = 0
        for sid in all_ids:
            b = baseline_scores.get(sid)
            d = devtorch_scores.get(sid)
            bs = b.score if b else None
            ds = d.score if d else None
            delta = (ds - bs) if (bs is not None and ds is not None) else None

            bs_str = f"{bs:.2f}" if bs is not None else "  —  "
            ds_str = f"{ds:.2f}" if ds is not None else "  —  "
            delta_str = f"+{delta:.2f}" if delta and delta > 0 else (f"{delta:.2f}" if delta is not None else "  —  ")

            print(f"  {sid:<28} {bs_str:>9} {ds_str:>9} {delta_str:>7}")
            if bs is not None:
                baseline_total += bs
            if ds is not None:
                devtorch_total += ds
            count += 1

        if count:
            b_avg = baseline_total / count
            d_avg = devtorch_total / count
            d_delta = d_avg - b_avg
            d_delta_str = f"+{d_delta:.2f}" if d_delta > 0 else f"{d_delta:.2f}"
            print(f"  {'─' * 26} {'─' * 9} {'─' * 9} {'─' * 7}")
            print(f"  {'AGGREGATE':<28} {b_avg:>9.2f} {d_avg:>9.2f} {d_delta_str:>7}")
            pct = (d_avg / b_avg - 1) * 100 if b_avg > 0 else 0
            print(f"\n  Improvement: {pct:+.1f}% (DevTorch vs baseline)")
        print(f"{'═' * 80}")
    else:
        for condition, scores in all_scores.items():
            print_scores(scores, f"Condition: {condition}")


if __name__ == "__main__":
    main()
