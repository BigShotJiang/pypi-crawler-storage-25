"""Configuration for Veritas package - self-contained."""

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv


VERITAS_HOME = Path.home() / ".veritas"
VECTOR_STORE_DIR = str(VERITAS_HOME / "vector_store")
CONFIG_FILE = VERITAS_HOME / "config.json"
PACKAGE_ROOT = Path(__file__).resolve().parent
REPO_ROOT = PACKAGE_ROOT.parent.parent
DEFAULTS_FILE = PACKAGE_ROOT / "defaults.json"
ENV_FILE = PACKAGE_ROOT / ".env"
ROOT_ENV_FILE = REPO_ROOT / ".env"

# Load provider/model API keys from repo/.env and veritas/.env
load_dotenv(dotenv_path=ROOT_ENV_FILE, override=False)
load_dotenv(dotenv_path=ENV_FILE, override=False)

COLLECTION_LAWS = "ai_ethics_laws"
COLLECTION_ALGORITHMS = "aif360_algorithms"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
TOP_K = 5


def _load_defaults() -> dict:
    """Load defaults.json from package root."""
    if DEFAULTS_FILE.exists():
        try:
            with open(DEFAULTS_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    raise RuntimeError(
        f"defaults.json not found or invalid at {DEFAULTS_FILE}. "
        "Package installation may be corrupted."
    )


@dataclass
class Config:
    """Configuration for Veritas components - self-contained."""

    # Paths
    veritas_home: Path = field(default_factory=lambda: VERITAS_HOME)
    vector_store_dir: str = field(default_factory=lambda: VECTOR_STORE_DIR)
    collection_laws: str = COLLECTION_LAWS
    collection_algorithms: str = COLLECTION_ALGORITHMS

    # Embedding settings
    embedding_model: str = EMBEDDING_MODEL
    top_k: int = TOP_K

    # LLM provider settings (from env or config file)
    llm_provider_override: Optional[str] = None
    llm_model_override: Optional[str] = None

    def _load_defaults_cached(self) -> dict:
        """Load defaults.json (cached)."""
        if not hasattr(self, "_defaults_cache"):
            self._defaults_cache = _load_defaults()
        return self._defaults_cache

    @property
    def llm_provider(self) -> str:
        """Get LLM provider from override, env, or defaults.json only."""
        return (
            self.llm_provider_override
            or os.getenv("LLM_PROVIDER")
            or self._load_defaults_cached().get("provider")
        )

    @property
    def llm_model(self) -> str:
        """Get LLM model from override, env, or defaults.json only."""
        return (
            self.llm_model_override
            or os.getenv("LLM_MODEL")
            or self._load_defaults_cached().get("llm")
        )

    @property
    def ollama_base_url(self) -> str:
        return (
            os.getenv("OLLAMA_BASE_URL")
            or self._from_config("ollama_base_url")
            or "http://localhost:11434"
        )

    @property
    def ollama_model(self) -> str:
        return (
            os.getenv("OLLAMA_MODEL")
            or self._from_config("ollama_model")
        )

    @property
    def openrouter_base_url(self) -> str:
        return (
            os.getenv("OPENROUTER_BASE_URL")
            or self._from_config("openrouter_base_url")
            or "https://openrouter.ai/api/v1"
        )

    @property
    def openrouter_api_key(self) -> Optional[str]:
        return (
            os.getenv("OPENROUTER_API_KEY")
            or self._from_config("openrouter_api_key")
        )

    @property
    def openrouter_model(self) -> str:
        return (
            os.getenv("OPENROUTER_MODEL")
            or self._from_config("openrouter_model")
        )

    @property
    def groq_base_url(self) -> Optional[str]:
        return (
            os.getenv("GROQ_BASE_URL")
            or self._from_config("groq_base_url")
        )

    @property
    def groq_api_key(self) -> Optional[str]:
        return (
            os.getenv("GROQ_API_KEY")
            or self._from_config("groq_api_key")
        )

    @property
    def groq_model(self) -> str:
        return (
            os.getenv("GROQ_MODEL")
            or self._from_config("groq_model")
        )

    def _from_config(self, key: str) -> Optional[str]:
        """Read value from ~/.veritas/config.json if it exists."""
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
                return config.get(key)
            except (json.JSONDecodeError, IOError):
                pass
        return None

    def save_config(self, **kwargs) -> None:
        """Save configuration to ~/.veritas/config.json."""
        self.veritas_home.mkdir(parents=True, exist_ok=True)
        config = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE) as f:
                config = json.load(f)
        config.update(kwargs)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)


# Global config instance
config = Config()
