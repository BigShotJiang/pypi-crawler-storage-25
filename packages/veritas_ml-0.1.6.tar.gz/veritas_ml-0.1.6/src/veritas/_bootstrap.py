"""
Auto-initialization logic for Veritas.

Checks ~/.veritas/vector_store/ exists on import.
If not, ingests bundled PDF into Chroma DB.
"""

import os
import sys
from pathlib import Path
from typing import Optional

# Set environment variables to avoid issues
os.environ["ANONYMIZED_TELEMETRY"] = "False"
os.environ["CHROMADB_TELEMETRY"] = "False"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# Paths
VERITAS_HOME = Path.home() / ".veritas"
VECTOR_STORE_PATH = VERITAS_HOME / "vector_store"
COLLECTION_NAME = "ai_ethics_laws"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 150

# Bundled PDF path (in package)
_PACKAGE_DIR = Path(__file__).parent
BUNDLED_PDF = _PACKAGE_DIR / "knowledge" / "ai_ethics_knowledge_base.pdf"


def _get_pdf_path() -> Optional[Path]:
    """Return path to bundled PDF, or None if not found."""
    if BUNDLED_PDF.exists():
        return BUNDLED_PDF
    # Fallback: check original location
    original = Path("knowledge/ai_ethics_knowledge_base.pdf")
    if original.exists():
        return original
    return None


def _ingest_knowledge_base(vector_store_path: Path) -> None:
    """Ingest PDF into Chroma vector store."""
    from langchain_community.document_loaders import PyPDFLoader
    try:
        # Newer LangChain split package
        from langchain_text_splitters import RecursiveCharacterTextSplitter
    except ImportError:
        # Backward compatibility with older monolithic LangChain
        from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain_huggingface import HuggingFaceEmbeddings
    from langchain_chroma import Chroma

    pdf_path = _get_pdf_path()
    if not pdf_path:
        raise FileNotFoundError(
            "AI ethics knowledge base PDF not found. "
            f"Expected at: {BUNDLED_PDF}"
        )

    print(f"[veritas] Initializing knowledge base (first run)...")
    print(f"[veritas] Loading PDF: {pdf_path.name}")

    # Load PDF
    loader = PyPDFLoader(str(pdf_path))
    pages = loader.load()
    print(f"[veritas]   → {len(pages)} pages loaded")

    # Chunk
    print(f"[veritas] Splitting into chunks...")
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        add_start_index=True,
    )
    docs = splitter.split_documents(pages)
    print(f"[veritas]   → {len(docs)} chunks created")

    # Embed
    print(f"[veritas] Loading embeddings: {EMBEDDING_MODEL}")
    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )

    # Build Chroma
    print(f"[veritas] Building vector store → {vector_store_path}")
    vector_store_path.mkdir(parents=True, exist_ok=True)

    # Use client_settings to avoid locking issues
    import chromadb
    client_settings = chromadb.Settings(
        anonymized_telemetry=False,
        is_persistent=True,
        persist_directory=str(vector_store_path),
    )

    vectordb = Chroma.from_documents(
        documents=docs,
        embedding=embeddings,
        persist_directory=str(vector_store_path),
        collection_name=COLLECTION_NAME,
        client_settings=client_settings,
    )
    count = vectordb._collection.count()
    print(f"[veritas]   → {count} vectors stored")
    print(f"[veritas] Initialization complete!")


def _ensure_initialized() -> None:
    """
    Check and initialize vector store if needed.
    Called on every import of veritas package.
    """
    # Skip if already initialized
    if VECTOR_STORE_PATH.exists():
        return

    # Create directory and ingest
    try:
        VERITAS_HOME.mkdir(parents=True, exist_ok=True)
        _ingest_knowledge_base(VECTOR_STORE_PATH)
    except Exception as e:
        print(f"[veritas] Warning: Failed to initialize knowledge base: {e}", file=sys.stderr)
        # Don't raise - let user continue without RAG if needed
