"""sklearn-compatible wrappers with built-in bias detection."""

from .wrappers import VeritasClassifier

__all__ = ["VeritasClassifier"]
