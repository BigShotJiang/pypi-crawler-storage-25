"""sklearn-compatible wrappers with built-in bias detection, mitigation, and compliance."""

import json
from inspect import signature
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

from aif360.algorithms.inprocessing import PrejudiceRemover
from aif360.algorithms.postprocessing import (
    CalibratedEqOddsPostprocessing,
    EqOddsPostprocessing,
    RejectOptionClassification,
)
from aif360.algorithms.preprocessing import Reweighing
from aif360.datasets import StandardDataset

from ..config import Config
from ..core.tracing import json_dumps_safe, trace_block, traceable
from ..detector import BiasDetector
from ..knowledge.ingest import knowledge_base
from ..tools import search_ai_ethics_laws, search_aif360_algorithms, select_mitigation_algorithm
from ..utils.report import build_report_messages, derive_ethics_concerns, format_bias_report


def _as_dataframe(X: Union[pd.DataFrame, np.ndarray]) -> pd.DataFrame:
    """Return feature matrix as a DataFrame to preserve column names consistently."""
    if isinstance(X, pd.DataFrame):
        return X.reset_index(drop=True).copy()
    return pd.DataFrame(X, columns=[f"feature_{i}" for i in range(np.asarray(X).shape[1])])


def _as_series(y: Union[pd.Series, np.ndarray], name: str = "label") -> pd.Series:
    """Return labels as a 1D Series."""
    if isinstance(y, pd.Series):
        return y.reset_index(drop=True).copy()
    arr = np.asarray(y).ravel()
    return pd.Series(arr, name=name)


def _as_sensitive_frame(
    sensitive_features: Union[pd.Series, np.ndarray, pd.DataFrame],
    protected_attributes: List[str],
) -> pd.DataFrame:
    """Normalize sensitive features to a DataFrame."""
    if isinstance(sensitive_features, pd.DataFrame):
        frame = sensitive_features.reset_index(drop=True).copy()
    elif isinstance(sensitive_features, pd.Series):
        frame = sensitive_features.to_frame(name=protected_attributes[0]).reset_index(drop=True)
    else:
        arr = np.asarray(sensitive_features)
        if arr.ndim == 1:
            frame = pd.DataFrame({protected_attributes[0]: arr})
        else:
            columns = protected_attributes[: arr.shape[1]]
            frame = pd.DataFrame(arr, columns=columns)
    return frame


def _supports_sample_weight(estimator: BaseEstimator) -> bool:
    """Check whether estimator.fit accepts sample weights."""
    try:
        return "sample_weight" in signature(estimator.fit).parameters
    except (TypeError, ValueError):
        return False


def _build_standard_dataset(
    X: pd.DataFrame,
    y: pd.Series,
    sensitive: Union[pd.Series, np.ndarray],
    protected_attr: str,
    privileged_val: int,
) -> StandardDataset:
    """Build an AIF360 StandardDataset with a single protected attribute."""
    df = X.reset_index(drop=True).copy()
    df["label"] = np.asarray(y).ravel()
    sensitive_series = pd.Series(np.asarray(sensitive).ravel())
    df[protected_attr] = pd.to_numeric(sensitive_series, errors="coerce").fillna(0).astype(int)
    return StandardDataset(
        df=df,
        label_name="label",
        favorable_classes=[1],
        protected_attribute_names=[protected_attr],
        privileged_classes=[[int(privileged_val)]],
    )


def _build_prediction_dataset(
    X: pd.DataFrame,
    predictions: np.ndarray,
    scores: np.ndarray,
    sensitive: Union[pd.Series, np.ndarray],
    protected_attr: str,
    privileged_val: int,
) -> StandardDataset:
    """Build an AIF360 dataset for prediction outputs."""
    df = X.reset_index(drop=True).copy()
    df["label"] = np.asarray(predictions).ravel()
    sensitive_series = pd.Series(np.asarray(sensitive).ravel())
    df[protected_attr] = pd.to_numeric(sensitive_series, errors="coerce").fillna(0).astype(int)
    dataset = StandardDataset(
        df=df,
        label_name="label",
        favorable_classes=[1],
        protected_attribute_names=[protected_attr],
        privileged_classes=[[int(privileged_val)]],
    )
    dataset.scores = np.asarray(scores).reshape(-1, 1)
    return dataset


def _predict_with_optional_sensitive(
    estimator: Any,
    X: Union[pd.DataFrame, np.ndarray],
    sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
) -> np.ndarray:
    """Predict with estimators that may optionally require sensitive features."""
    try:
        return np.asarray(estimator.predict(_as_dataframe(X), sensitive_features=sensitive_features)).astype(int)
    except TypeError:
        return np.asarray(estimator.predict(_as_dataframe(X))).astype(int)


def _report_columns(
    X: pd.DataFrame,
    sensitive_columns: List[str],
    extra_columns: List[str],
) -> List[str]:
    """Pick a compact, readable set of columns for report evidence tables."""
    preferred = [
        "age",
        "education-num",
        "hours-per-week",
        "capital-gain",
        "capital-loss",
        "fnlwgt",
    ]
    feature_columns = [col for col in preferred if col in X.columns]
    if not feature_columns:
        feature_columns = list(X.columns[:6])

    ordered = feature_columns[:]
    for column in sensitive_columns + extra_columns:
        if column not in ordered:
            ordered.append(column)
    return ordered


def _normalise_example_value(value: Any) -> Any:
    """Convert numpy and pandas scalar values into compact report-safe values."""
    if pd.isna(value):
        return None
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return round(float(value), 4)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def _frame_to_records(
    frame: pd.DataFrame,
    columns: List[str],
    limit: int,
) -> List[Dict[str, Any]]:
    """Convert a dataframe slice into JSON-serialisable report rows."""
    records: List[Dict[str, Any]] = []
    for _, row in frame.head(limit).iterrows():
        record = {column: _normalise_example_value(row[column]) for column in columns if column in row.index}
        records.append(record)
    return records


def _build_metric_code_snippet(
    pre_report: Optional[Dict[str, Any]],
    post_report: Optional[Dict[str, Any]],
) -> List[Dict[str, str]]:
    """Build concise code snippets that highlight metric changes."""
    relevant_metrics = {
        "pre_mitigation": {
            "dataset_metrics": (pre_report or {}).get("dataset_metrics", {}),
            "classification_metrics": (pre_report or {}).get("classification_metrics", {}),
            "bias_issues": (pre_report or {}).get("bias_issues", []),
        },
        "post_mitigation": {
            "dataset_metrics": (post_report or {}).get("dataset_metrics", {}),
            "classification_metrics": (post_report or {}).get("classification_metrics", {}),
            "bias_issues": (post_report or {}).get("bias_issues", []),
        },
    }
    code = (
        "fairness_snapshot = "
        + json_dumps_safe(relevant_metrics, indent=2)
    )
    return [{
        "title": "Fairness Metrics Snapshot",
        "language": "python",
        "code": code,
    }]


class _AIF360EstimatorAdapter:
    """Adapter exposing AIF360 dataset-based estimators through sklearn-like predict APIs."""

    def __init__(self, model: Any, protected_attr: str, privileged_val: int):
        self.model = model
        self.protected_attr = protected_attr
        self.privileged_val = int(privileged_val)

    def _to_dataset(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Union[pd.Series, np.ndarray, pd.DataFrame],
    ) -> StandardDataset:
        X_df = _as_dataframe(X)
        if isinstance(sensitive_features, pd.DataFrame):
            sensitive = sensitive_features.iloc[:, 0]
        elif isinstance(sensitive_features, pd.Series):
            sensitive = sensitive_features
        else:
            sensitive = np.asarray(sensitive_features).ravel()
        dummy_y = pd.Series(np.zeros(len(X_df), dtype=int), name="label")
        return _build_standard_dataset(X_df, dummy_y, sensitive, self.protected_attr, self.privileged_val)

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> np.ndarray:
        if sensitive_features is None:
            raise ValueError("Mitigated estimator requires sensitive_features for prediction.")
        dataset = self._to_dataset(X, sensitive_features)
        return self.model.predict(dataset).labels.ravel().astype(int)

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> np.ndarray:
        if sensitive_features is None:
            raise ValueError("Mitigated estimator requires sensitive_features for prediction.")
        dataset = self._to_dataset(X, sensitive_features)
        scores = np.asarray(self.model.predict(dataset).scores).ravel()
        scores = np.clip(scores, 0.0, 1.0)
        return np.column_stack([1.0 - scores, scores])


class _PostprocessedEstimatorAdapter:
    """Adapter applying an AIF360 postprocessor on top of a base estimator."""

    def __init__(
        self,
        base_estimator: BaseEstimator,
        postprocessor: Any,
        protected_attr: str,
        privileged_val: int,
    ):
        self.base_estimator = base_estimator
        self.postprocessor = postprocessor
        self.protected_attr = protected_attr
        self.privileged_val = int(privileged_val)

    def _base_predictions(
        self,
        X: Union[pd.DataFrame, np.ndarray],
    ) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
        X_df = _as_dataframe(X)
        predictions = self.base_estimator.predict(X_df).astype(int)
        if hasattr(self.base_estimator, "predict_proba"):
            scores = self.base_estimator.predict_proba(X_df)[:, 1]
        elif hasattr(self.base_estimator, "decision_function"):
            decision = self.base_estimator.decision_function(X_df)
            scores = 1.0 / (1.0 + np.exp(-np.asarray(decision)))
        else:
            scores = predictions.astype(float)
        return X_df, predictions, np.asarray(scores).ravel()

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> np.ndarray:
        if sensitive_features is None:
            raise ValueError("Postprocessed estimator requires sensitive_features for prediction.")
        if isinstance(sensitive_features, pd.DataFrame):
            sensitive = sensitive_features.iloc[:, 0]
        elif isinstance(sensitive_features, pd.Series):
            sensitive = sensitive_features
        else:
            sensitive = np.asarray(sensitive_features).ravel()

        X_df, base_predictions, base_scores = self._base_predictions(X)
        pred_dataset = _build_prediction_dataset(
            X_df,
            base_predictions,
            base_scores,
            sensitive,
            self.protected_attr,
            self.privileged_val,
        )
        return self.postprocessor.predict(pred_dataset).labels.ravel().astype(int)

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> np.ndarray:
        X_df, _, base_scores = self._base_predictions(X)
        scores = np.clip(base_scores, 0.0, 1.0)
        if sensitive_features is not None:
            adjusted = self.predict(X_df, sensitive_features=sensitive_features).astype(float)
            scores = 0.5 * scores + 0.5 * adjusted
        return np.column_stack([1.0 - scores, scores])


class VeritasClassifier(BaseEstimator, ClassifierMixin):
    """sklearn-compatible classifier wrapper with automatic bias auditing and mitigation."""

    _SUPPORTED_TECHNIQUES = {
        "reweighing",
        "prejudice_remover",
        "reject_option",
        "eqodds",
        "calibrated_eqodds",
        "disparate_impact_remover",
        "learning_fair_representations",
        "meta_fair_classifier",
    }

    def __init__(
        self,
        base_estimator: Optional[BaseEstimator] = None,
        protected_attributes: List[str] = None,
        privileged_groups: Optional[Dict[str, List]] = None,
        unprivileged_groups: Optional[Dict[str, List]] = None,
        run_audit: bool = True,
        apply_mitigation: bool = True,
        generate_report: bool = True,
        llm_provider: Optional[str] = None,
        mitigation_technique: str = "auto",
        dataset_name: str = "dataset",
        report_sample_count: int = 6,
    ):
        self.base_estimator = base_estimator if base_estimator is not None else LogisticRegression(max_iter=500)
        self.protected_attributes = protected_attributes or ["sex"]
        self.privileged_groups = privileged_groups
        self.unprivileged_groups = unprivileged_groups
        self.run_audit = run_audit
        self.apply_mitigation = apply_mitigation
        self.generate_report = generate_report
        self.llm_provider = llm_provider
        self.mitigation_technique = mitigation_technique
        self.dataset_name = dataset_name
        self.report_sample_count = report_sample_count

        self.estimator_: Optional[BaseEstimator] = None
        self.mitigated_estimator_: Optional[BaseEstimator] = None
        self.bias_report_: Optional[Dict[str, Any]] = None
        self.bias_report_pre_mitigation_: Optional[Dict[str, Any]] = None
        self.bias_report_post_mitigation_: Optional[Dict[str, Any]] = None
        self.compliance_report_: Optional[str] = None
        self.classes_: Optional[np.ndarray] = None
        self._mitigation_applied: bool = False
        self._detected_groups_: Optional[Dict[str, Dict[str, List[int]]]] = None
        self._mitigation_result: Optional[Dict[str, Any]] = None
        self._report_context_: Dict[str, Any] = {}

    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
        sensitive_train: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> "VeritasClassifier":
        with trace_block(
            "veritas_classifier_fit",
            run_type="chain",
            inputs={
                "dataset_name": self.dataset_name,
                "protected_attributes": self.protected_attributes,
                "apply_mitigation": self.apply_mitigation,
                "generate_report": self.generate_report,
            },
            tags=["veritas", "classifier", "fit"],
        ):
            sf = sensitive_train if sensitive_train is not None else sensitive_features

            X_df = _as_dataframe(X)
            y_series = _as_series(y)
            self.classes_ = np.sort(y_series.unique())

            self.estimator_ = clone(self.base_estimator)
            self.estimator_.fit(X_df, y_series)

            if self.run_audit and sf is not None:
                self._run_full_pipeline(X_df, y_series, sf)

            return self

    def _run_full_pipeline(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        sensitive_features: Union[pd.Series, np.ndarray, pd.DataFrame],
    ) -> None:
        with trace_block(
            "veritas_full_pipeline",
            run_type="chain",
            inputs={
                "dataset_name": self.dataset_name,
                "row_count": len(X),
                "protected_attributes": self.protected_attributes,
            },
            tags=["veritas", "pipeline"],
        ):
            sensitive_df = _as_sensitive_frame(sensitive_features, self.protected_attributes)
            primary_attr = self.protected_attributes[0]
            indices = np.arange(len(X))
            fit_cal_idx, eval_idx = train_test_split(
                indices, test_size=0.30, random_state=42, stratify=y
            )
            fit_idx, cal_idx = train_test_split(
                fit_cal_idx,
                test_size=0.25,
                random_state=42,
                stratify=y.iloc[fit_cal_idx],
            )

            X_fit = X.iloc[fit_idx].reset_index(drop=True)
            y_fit = y.iloc[fit_idx].reset_index(drop=True)
            s_fit = sensitive_df.iloc[fit_idx].reset_index(drop=True)

            X_cal = X.iloc[cal_idx].reset_index(drop=True)
            y_cal = y.iloc[cal_idx].reset_index(drop=True)
            s_cal = sensitive_df.iloc[cal_idx].reset_index(drop=True)

            X_eval = X.iloc[eval_idx].reset_index(drop=True)
            y_eval = y.iloc[eval_idx].reset_index(drop=True)
            s_eval = sensitive_df.iloc[eval_idx].reset_index(drop=True)

            self._report_context_ = {
                "dataset_name": self.dataset_name,
                "model_name": type(self.base_estimator).__name__,
                "protected_attribute": primary_attr,
                "protected_attributes": list(sensitive_df.columns),
                "data_shape": {
                    "rows": int(len(X)),
                    "features": int(X.shape[1]),
                },
                "pipeline_steps": [
                    f"Loaded `{self.dataset_name}` with {len(X)} rows and {X.shape[1]} model feature columns.",
                    f"Normalized the protected-attribute context {list(sensitive_df.columns)} and selected `{primary_attr}` as the primary audit attribute for mitigation.",
                    f"Split the data into fit ({len(X_fit)} rows), calibration ({len(X_cal)} rows), and evaluation ({len(X_eval)} rows) partitions with stratified sampling.",
                    f"Trained `{type(self.base_estimator).__name__}` on the fit partition.",
                    "Ran AIF360 fairness metrics on the evaluation partition before mitigation.",
                ],
            }

            self.estimator_ = clone(self.base_estimator)
            self.estimator_.fit(X_fit, y_fit)

            detector = BiasDetector(
                protected_attributes=self.protected_attributes,
                privileged_groups=self.privileged_groups,
                unprivileged_groups=self.unprivileged_groups,
            )
            self.bias_report_pre_mitigation_ = detector.audit(
                model=self.estimator_,
                X_test=X_eval,
                y_test=y_eval,
                sensitive_features=s_eval,
            )

            groups = self.bias_report_pre_mitigation_.get("protected_groups", {})
            self._detected_groups_ = {
                "privileged": groups.get("privileged", {}),
                "unprivileged": groups.get("unprivileged", {}),
                "base_rates": groups.get("base_rates", {}),
            }
            self.bias_report_ = self.bias_report_pre_mitigation_
            predictions_before = _predict_with_optional_sensitive(
                self.estimator_,
                X_eval,
                sensitive_features=s_eval,
            )
            self._report_context_["bias_examples"] = self._build_bias_example_rows(
                X_eval=X_eval,
                y_eval=y_eval,
                s_eval=s_eval,
                protected_attr=primary_attr,
                predictions_before=predictions_before,
            )
            self._report_context_["predictions_before"] = predictions_before.tolist()
            self._report_context_["code_snippets"] = _build_metric_code_snippet(
                self.bias_report_pre_mitigation_,
                self.bias_report_pre_mitigation_,
            )

            if self._has_bias_report(self.bias_report_pre_mitigation_) and self.apply_mitigation:
                self._apply_mitigation(
                    X_fit=X_fit,
                    y_fit=y_fit,
                    s_fit=s_fit,
                    X_cal=X_cal,
                    y_cal=y_cal,
                    s_cal=s_cal,
                    X_eval=X_eval,
                    y_eval=y_eval,
                    s_eval=s_eval,
                    protected_attr=primary_attr,
                )
            else:
                self._report_context_["pipeline_steps"].append(
                    "Skipped mitigation because no actionable bias threshold breach was detected or mitigation was disabled."
                )

            if self.generate_report:
                self._generate_compliance_report()

    def _get_group_values(self, protected_attr: str) -> Tuple[int, int]:
        groups = self._detected_groups_ or {}
        privileged = groups.get("privileged", {}).get(protected_attr)
        unprivileged = groups.get("unprivileged", {}).get(protected_attr)
        privileged_val = int((privileged or [1])[0])
        unprivileged_val = int((unprivileged or [0])[0])
        return privileged_val, unprivileged_val

    def _build_bias_example_rows(
        self,
        X_eval: pd.DataFrame,
        y_eval: pd.Series,
        s_eval: pd.DataFrame,
        protected_attr: str,
        predictions_before: np.ndarray,
    ) -> List[Dict[str, Any]]:
        """Capture representative rows that show where bias is visible before mitigation."""
        privileged_val, unprivileged_val = self._get_group_values(protected_attr)
        frame = X_eval.reset_index(drop=True).copy()
        for column in s_eval.columns:
            frame[column] = s_eval[column].reset_index(drop=True)
        frame["actual_label"] = y_eval.reset_index(drop=True)
        frame["prediction_before"] = predictions_before
        frame["group_role"] = np.where(
            frame[protected_attr].astype(int) == privileged_val,
            "privileged",
            "unprivileged",
        )

        unprivileged_denials = frame[
            (frame[protected_attr].astype(int) == unprivileged_val)
            & ((frame["prediction_before"] == 0) | (frame["actual_label"] == 1))
        ]
        privileged_approvals = frame[
            (frame[protected_attr].astype(int) == privileged_val)
            & (frame["prediction_before"] == 1)
        ]

        target = max(1, self.report_sample_count // 2)
        combined = pd.concat(
            [
                unprivileged_denials.head(target),
                privileged_approvals.head(self.report_sample_count - target),
            ],
            ignore_index=True,
        ).drop_duplicates()
        if combined.empty:
            combined = frame.head(self.report_sample_count)

        columns = _report_columns(
            X_eval,
            list(s_eval.columns),
            ["group_role", "actual_label", "prediction_before"],
        )
        return _frame_to_records(combined, columns, self.report_sample_count)

    def _build_mitigation_example_rows(
        self,
        X_eval: pd.DataFrame,
        y_eval: pd.Series,
        s_eval: pd.DataFrame,
        protected_attr: str,
        predictions_before: np.ndarray,
        predictions_after: np.ndarray,
    ) -> List[Dict[str, Any]]:
        """Capture representative rows that show how outcomes changed after mitigation."""
        privileged_val, unprivileged_val = self._get_group_values(protected_attr)
        frame = X_eval.reset_index(drop=True).copy()
        for column in s_eval.columns:
            frame[column] = s_eval[column].reset_index(drop=True)
        frame["actual_label"] = y_eval.reset_index(drop=True)
        frame["prediction_before"] = predictions_before
        frame["prediction_after"] = predictions_after
        frame["prediction_changed"] = frame["prediction_before"] != frame["prediction_after"]
        frame["prediction_impact"] = np.select(
            [
                (frame["prediction_before"] == 0) & (frame["prediction_after"] == 1),
                (frame["prediction_before"] == 1) & (frame["prediction_after"] == 0),
            ],
            [
                "changed from denied to approved",
                "changed from approved to denied",
            ],
            default="unchanged prediction",
        )
        frame["group_role"] = np.where(
            frame[protected_attr].astype(int) == privileged_val,
            "privileged",
            "unprivileged",
        )

        changed = frame[frame["prediction_changed"]]
        prioritized = pd.concat(
            [
                changed,
                frame[frame[protected_attr].astype(int) == unprivileged_val],
                frame[frame[protected_attr].astype(int) == privileged_val],
            ],
            ignore_index=True,
        ).drop_duplicates()
        if prioritized.empty:
            prioritized = frame.head(self.report_sample_count)

        columns = _report_columns(
            X_eval,
            list(s_eval.columns),
            [
                "group_role",
                "actual_label",
                "prediction_before",
                "prediction_after",
                "prediction_changed",
                "prediction_impact",
            ],
        )
        return _frame_to_records(prioritized, columns, self.report_sample_count)

    def _build_mitigation_summary(self) -> str:
        """Summarise mitigation execution and the main fairness deltas."""
        result = self._mitigation_result or {}
        technique = result.get("technique", "none")
        status = result.get("status", "not_run")
        summary_parts = [f"Technique `{technique}` finished with status `{status}`."]

        if result.get("sample_weight_summary"):
            weights = result["sample_weight_summary"]
            summary_parts.append(
                "Sample weights ranged from "
                f"{weights.get('min')} to {weights.get('max')} across "
                f"{weights.get('unique_count')} distinct values."
            )

        pre = self.bias_report_pre_mitigation_ or {}
        post = self.bias_report_post_mitigation_ or {}
        for metric, section in [
            ("disparate_impact", "dataset_metrics"),
            ("statistical_parity_difference", "dataset_metrics"),
            ("equal_opportunity_difference", "classification_metrics"),
            ("average_odds_difference", "classification_metrics"),
        ]:
            before = pre.get(section, {}).get(metric)
            after = post.get(section, {}).get(metric)
            if before is None or after is None:
                continue
            summary_parts.append(f"`{metric}` changed from {before} to {after}.")

        if result.get("fallback_reason"):
            summary_parts.append(f"Mitigation note: {result['fallback_reason']}")
        return " ".join(summary_parts)

    def _retrieve_rag_context(
        self,
        pre_report: Dict[str, Any],
        mitigation: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Retrieve law and algorithm evidence through the bundled RAG tools."""
        with trace_block(
            "veritas_rag_retrieval",
            run_type="chain",
            inputs={
                "issue_count": pre_report.get("issue_count", 0),
                "mitigation_technique": mitigation.get("technique"),
            },
            tags=["veritas", "rag"],
        ):
            rag_context: Dict[str, Any] = {
                "knowledge_base_status": {},
                "law_matches": [],
                "algorithm_matches": None,
                "algorithm_recommendation": None,
            }

            try:
                rag_context["knowledge_base_status"] = knowledge_base.status()
            except Exception as exc:
                rag_context["knowledge_base_error"] = str(exc)

            issues = pre_report.get("bias_issues", [])
            for issue in issues:
                metric = issue.get("metric", "fairness issue")
                law_query = (
                    f"{metric} {issue.get('explanation', '')} "
                    "employment discrimination fairness law EU AI Act OECD UNESCO"
                )
                law_results = search_ai_ethics_laws.invoke({"query": law_query, "k": 3})
                rag_context["law_matches"].append({
                    "metric": metric,
                    "query": law_query,
                    "results": law_results,
                })

            primary_metric = str(issues[0].get("metric", "disparate impact")) if issues else "disparate impact"
            metric_lower = primary_metric.lower()
            if "parity" in metric_lower or "impact" in metric_lower:
                constraint_type = "demographic_parity"
            elif "opportunity" in metric_lower:
                constraint_type = "equal_opportunity"
            else:
                constraint_type = "equalized_odds"

            algorithm_query = (
                f"{primary_metric} fairness mitigation "
                f"{mitigation.get('technique', 'reweighing')} "
                f"{constraint_type} AIF360"
            )
            rag_context["algorithm_matches"] = search_aif360_algorithms.invoke(
                {"query": algorithm_query, "k": 3}
            )
            rag_context["algorithm_recommendation"] = select_mitigation_algorithm.invoke({
                "bias_issue": primary_metric,
                "constraint_type": constraint_type,
                "can_retrain": True,
            })
            return rag_context

    def _select_mitigation_technique(self) -> Tuple[Optional[str], Optional[str]]:
        requested = (self.mitigation_technique or "auto").lower()
        if requested != "auto":
            if requested not in self._SUPPORTED_TECHNIQUES:
                return None, f"Unsupported mitigation technique: {requested}"
            if requested == "disparate_impact_remover":
                try:
                    import BlackBoxAuditing  # noqa: F401
                except ImportError:
                    return None, "disparate_impact_remover requires the BlackBoxAuditing dependency."
            if requested == "meta_fair_classifier":
                return None, "meta_fair_classifier is unstable in the current environment and is disabled by default."
            return requested, None

        if _supports_sample_weight(self.base_estimator):
            return "reweighing", None
        if hasattr(self.base_estimator, "predict_proba"):
            return "reject_option", None
        return "eqodds", None

    def _apply_mitigation(
        self,
        X_fit: pd.DataFrame,
        y_fit: pd.Series,
        s_fit: pd.DataFrame,
        X_cal: pd.DataFrame,
        y_cal: pd.Series,
        s_cal: pd.DataFrame,
        X_eval: pd.DataFrame,
        y_eval: pd.Series,
        s_eval: pd.DataFrame,
        protected_attr: str,
    ) -> None:
        privileged_val, unprivileged_val = self._get_group_values(protected_attr)
        privileged_groups = [{protected_attr: privileged_val}]
        unprivileged_groups = [{protected_attr: unprivileged_val}]
        technique, fallback_reason = self._select_mitigation_technique()
        predictions_before = np.asarray(
            self._report_context_.get("predictions_before", [])
            or _predict_with_optional_sensitive(self.estimator_, X_eval, sensitive_features=s_eval)
        ).astype(int)

        result: Dict[str, Any] = {
            "technique": technique or self.mitigation_technique,
            "status": "failed",
            "applied": False,
            "fallback_reason": fallback_reason,
            "before_metrics": self.bias_report_pre_mitigation_,
            "after_metrics": None,
        }

        if technique is None:
            self._mitigation_result = result
            self.bias_report_post_mitigation_ = self.bias_report_pre_mitigation_
            self._report_context_.setdefault("pipeline_steps", []).append(
                f"Mitigation could not run because `{self.mitigation_technique}` was unavailable: {fallback_reason}"
            )
            return

        try:
            self._report_context_.setdefault("pipeline_steps", []).append(
                f"Selected mitigation technique `{technique}` based on the detected fairness issues and estimator capabilities."
            )
            if technique == "reweighing":
                dataset_fit = _build_standard_dataset(
                    X_fit, y_fit, s_fit[protected_attr], protected_attr, privileged_val
                )
                reweighing = Reweighing(
                    unprivileged_groups=unprivileged_groups,
                    privileged_groups=privileged_groups,
                )
                reweighing.fit(dataset_fit)
                sample_weights = reweighing.transform(dataset_fit).instance_weights

                mitigated = clone(self.base_estimator)
                mitigated.fit(X_fit, y_fit, sample_weight=sample_weights)
                self.mitigated_estimator_ = mitigated
                self.estimator_ = mitigated
                result.update({
                    "type": "preprocessing",
                    "status": "success",
                    "applied": True,
                    "sample_weight_summary": {
                        "min": float(np.min(sample_weights)),
                        "max": float(np.max(sample_weights)),
                        "unique_count": int(np.unique(np.round(sample_weights, 8)).size),
                    },
                })
                self._report_context_["pipeline_steps"].append(
                    "Applied reweighing on the training partition and retrained the base estimator with fairness-aware sample weights."
                )

            elif technique == "prejudice_remover":
                dataset_fit = _build_standard_dataset(
                    X_fit, y_fit, s_fit[protected_attr], protected_attr, privileged_val
                )
                model = PrejudiceRemover(eta=1.0, sensitive_attr=protected_attr, class_attr="label")
                model.fit(dataset_fit)
                adapted = _AIF360EstimatorAdapter(model, protected_attr, privileged_val)
                self.mitigated_estimator_ = adapted
                self.estimator_ = adapted
                result.update({
                    "type": "inprocessing",
                    "status": "success",
                    "applied": True,
                })
                self._report_context_["pipeline_steps"].append(
                    "Applied the PrejudiceRemover in-processing algorithm and swapped the estimator with the fairness-regularized model."
                )

            elif technique in {"reject_option", "eqodds", "calibrated_eqodds"}:
                calibration_model = clone(self.base_estimator)
                calibration_model.fit(X_fit, y_fit)
                cal_predictions = calibration_model.predict(X_cal).astype(int)
                cal_scores = calibration_model.predict_proba(X_cal)[:, 1] if hasattr(
                    calibration_model, "predict_proba"
                ) else cal_predictions.astype(float)

                truth_dataset = _build_standard_dataset(
                    X_cal, y_cal, s_cal[protected_attr], protected_attr, privileged_val
                )
                pred_dataset = _build_prediction_dataset(
                    X_cal,
                    cal_predictions,
                    cal_scores,
                    s_cal[protected_attr],
                    protected_attr,
                    privileged_val,
                )

                if technique == "reject_option":
                    postprocessor = RejectOptionClassification(
                        unprivileged_groups=unprivileged_groups,
                        privileged_groups=privileged_groups,
                        metric_name="Statistical parity difference",
                        metric_lb=-0.05,
                        metric_ub=0.05,
                    )
                elif technique == "eqodds":
                    postprocessor = EqOddsPostprocessing(
                        unprivileged_groups=unprivileged_groups,
                        privileged_groups=privileged_groups,
                    )
                else:
                    postprocessor = CalibratedEqOddsPostprocessing(
                        unprivileged_groups=unprivileged_groups,
                        privileged_groups=privileged_groups,
                    )

                postprocessor.fit(truth_dataset, pred_dataset)
                adapted = _PostprocessedEstimatorAdapter(
                    calibration_model, postprocessor, protected_attr, privileged_val
                )
                self.mitigated_estimator_ = adapted
                self.estimator_ = adapted
                result.update({
                    "type": "postprocessing",
                    "status": "success",
                    "applied": True,
                })
                self._report_context_["pipeline_steps"].append(
                    f"Fitted `{technique}` on the calibration partition and wrapped the base estimator with a post-processing adapter."
                )

            else:
                raise ValueError(f"Technique {technique} is not executable in this wrapper.")

        except Exception as exc:
            result["fallback_reason"] = str(exc)
            self._report_context_.setdefault("pipeline_steps", []).append(
                f"Mitigation attempt with `{technique}` failed: {exc}"
            )

        detector = BiasDetector(
            protected_attributes=self.protected_attributes,
            privileged_groups=self._detected_groups_.get("privileged") if self._detected_groups_ else self.privileged_groups,
            unprivileged_groups=self._detected_groups_.get("unprivileged") if self._detected_groups_ else self.unprivileged_groups,
        )
        self.bias_report_post_mitigation_ = detector.audit(
            model=self.estimator_,
            X_test=X_eval,
            y_test=y_eval,
            sensitive_features=s_eval,
        )
        self.bias_report_ = self.bias_report_post_mitigation_
        self._mitigation_applied = bool(result.get("applied"))
        result["after_metrics"] = self.bias_report_post_mitigation_
        self._mitigation_result = result
        predictions_after = _predict_with_optional_sensitive(
            self.estimator_,
            X_eval,
            sensitive_features=s_eval,
        )
        self._report_context_["mitigation_examples"] = self._build_mitigation_example_rows(
            X_eval=X_eval,
            y_eval=y_eval,
            s_eval=s_eval,
            protected_attr=protected_attr,
            predictions_before=predictions_before,
            predictions_after=predictions_after,
        )
        self._report_context_["predictions_after"] = predictions_after.tolist()
        self._report_context_["code_snippets"] = _build_metric_code_snippet(
            self.bias_report_pre_mitigation_,
            self.bias_report_post_mitigation_,
        )
        self._report_context_.setdefault("pipeline_steps", []).append(
            "Re-ran the fairness audit after mitigation and captured before/after evidence for the final report."
        )

    def _generate_compliance_report(self) -> None:
        from ..core.llm import LLM

        with trace_block(
            "veritas_generate_compliance_report",
            run_type="chain",
            inputs={"dataset_name": self.dataset_name},
            tags=["veritas", "report"],
        ):
            pre_report = self.bias_report_pre_mitigation_ or self.bias_report_ or {}
            post_report = self.bias_report_post_mitigation_ or self.bias_report_ or pre_report
            groups_info = self._detected_groups_ or {"privileged": {}, "unprivileged": {}}
            mitigation = self._mitigation_result or {}
            protected_attr = self.protected_attributes[0]
            protected_attrs = list(self.protected_attributes)
            ethics_concerns = derive_ethics_concerns(
                pre_report.get("bias_issues", []),
                mitigation.get("technique"),
            )
            rag_context = self._retrieve_rag_context(pre_report, mitigation)
            for concern, law_match in zip(ethics_concerns, rag_context.get("law_matches", [])):
                concern["rag_law_context"] = law_match.get("results")
            if ethics_concerns:
                ethics_concerns[0]["rag_algorithm_context"] = rag_context.get("algorithm_matches")
                ethics_concerns[0]["rag_algorithm_recommendation"] = rag_context.get("algorithm_recommendation")

            mitigation_summary = self._build_mitigation_summary() if mitigation else "No mitigation summary available."
            if rag_context.get("algorithm_recommendation"):
                mitigation_summary = (
                    f"{mitigation_summary} RAG recommendation: {rag_context['algorithm_recommendation']}"
                )

            pipeline_steps = self._report_context_.get("pipeline_steps", [])
            pipeline_steps = list(pipeline_steps) + [
                "Queried the AI ethics law knowledge base for each detected issue.",
                "Queried the mitigation-algorithm knowledge base and selected a matching AIF360 strategy recommendation.",
            ]

            report_context = {
                "dataset_name": self.dataset_name,
                "model_name": type(self.base_estimator).__name__,
                "protected_attribute": protected_attr,
                "protected_attributes": protected_attrs,
                "protected_groups": groups_info,
                "pre_mitigation_report": pre_report,
                "post_mitigation_report": post_report,
                "mitigation_applied": self._mitigation_applied,
                "mitigation_result": mitigation,
                "mitigation_summary": mitigation_summary,
                "bias_examples": self._report_context_.get("bias_examples", []),
                "mitigation_examples": self._report_context_.get("mitigation_examples", []),
                "code_snippets": self._report_context_.get("code_snippets", []),
                "pipeline_steps": pipeline_steps,
                "ethics_concerns": ethics_concerns,
                "rag_retrieval": rag_context,
            }
            self._report_context_.update(report_context)

            required_sections = [
                "Executive Summary",
                "Pipeline Summary",
                "Bias Found",
                "Mitigation Applied",
                "Compliance Status",
            ]

            candidate_report: Optional[str] = None
            try:
                llm_client = LLM(Config(llm_provider_override=self.llm_provider))
                candidate_report = llm_client.invoke(build_report_messages(report_context))
            except Exception:
                candidate_report = None

            if candidate_report and all(section in candidate_report for section in required_sections):
                self.compliance_report_ = candidate_report
                return

            self.compliance_report_ = format_bias_report(
                bias_report=pre_report,
                privileged_groups=groups_info.get("privileged", {}),
                unprivileged_groups=groups_info.get("unprivileged", {}),
                mitigation_applied=self._mitigation_applied,
                mitigation_technique=mitigation.get("technique"),
                pre_mitigation_metrics=pre_report,
                post_mitigation_metrics=post_report,
                dataset_name=self.dataset_name,
                model_name=type(self.base_estimator).__name__,
                protected_attribute=protected_attr,
                protected_attributes=protected_attrs,
                ethics_concerns=ethics_concerns,
                bias_examples=self._report_context_.get("bias_examples", []),
                mitigation_examples=self._report_context_.get("mitigation_examples", []),
                code_snippets=self._report_context_.get("code_snippets", []),
                pipeline_steps=pipeline_steps,
                mitigation_summary=mitigation_summary,
                rag_context=rag_context,
            )

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> np.ndarray:
        if self.estimator_ is None:
            raise ValueError("Classifier not fitted. Call fit() first.")
        try:
            return self.estimator_.predict(_as_dataframe(X), sensitive_features=sensitive_features)
        except TypeError:
            return self.estimator_.predict(_as_dataframe(X))

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Optional[Union[pd.Series, np.ndarray, pd.DataFrame]] = None,
    ) -> np.ndarray:
        if self.estimator_ is None:
            raise ValueError("Classifier not fitted. Call fit() first.")
        if not hasattr(self.estimator_, "predict_proba"):
            raise AttributeError("Underlying estimator does not support predict_proba.")
        try:
            return self.estimator_.predict_proba(_as_dataframe(X), sensitive_features=sensitive_features)
        except TypeError:
            return self.estimator_.predict_proba(_as_dataframe(X))

    def get_bias_report(self) -> Optional[Dict[str, Any]]:
        return self.bias_report_

    def get_bias_report_pre_mitigation(self) -> Optional[Dict[str, Any]]:
        return self.bias_report_pre_mitigation_

    def get_bias_report_post_mitigation(self) -> Optional[Dict[str, Any]]:
        return self.bias_report_post_mitigation_

    def get_mitigation_result(self) -> Optional[Dict[str, Any]]:
        return self._mitigation_result

    def get_compliance_report(self) -> Optional[str]:
        return self.compliance_report_

    def get_report_context(self) -> Dict[str, Any]:
        return self._report_context_

    def get_protected_groups(self) -> Optional[Dict[str, Dict[str, List[int]]]]:
        return self._detected_groups_

    def has_bias(self) -> bool:
        return self._has_bias_report(self.bias_report_)

    def mitigation_applied(self) -> bool:
        return self._mitigation_applied

    def get_bias_summary(self) -> str:
        if self.bias_report_ is None:
            return "No bias report available."

        issues = self.bias_report_.get("bias_issues", [])
        lines = [
            f"Detected {len(issues)} bias issue(s).",
            f"Mitigation applied: {self._mitigation_applied}",
        ]

        if self._detected_groups_:
            lines.append(f"Privileged groups: {self._detected_groups_.get('privileged', {})}")
            lines.append(f"Unprivileged groups: {self._detected_groups_.get('unprivileged', {})}")

        if self._mitigation_result:
            lines.append(f"Technique: {self._mitigation_result.get('technique')}")
            if self._mitigation_result.get("fallback_reason"):
                lines.append(f"Mitigation note: {self._mitigation_result.get('fallback_reason')}")

        comparison = self._build_metric_comparison()
        if comparison:
            lines.append("Before/after metrics:")
            lines.extend(comparison)

        return "\n".join(lines)

    def _build_metric_comparison(self) -> List[str]:
        pre = self.bias_report_pre_mitigation_
        post = self.bias_report_post_mitigation_
        if not pre or not post:
            return []

        comparisons = []
        metric_locations = {
            "disparate_impact": "dataset_metrics",
            "statistical_parity_difference": "dataset_metrics",
            "equal_opportunity_difference": "classification_metrics",
            "average_odds_difference": "classification_metrics",
            "theil_index": "classification_metrics",
            "accuracy_overall": "classification_metrics",
        }
        for metric, section in metric_locations.items():
            before = pre.get(section, {}).get(metric)
            after = post.get(section, {}).get(metric)
            if before is None or after is None:
                continue
            comparisons.append(f"- {metric}: {before} -> {after}")
        return comparisons

    @staticmethod
    def _has_bias_report(report: Optional[Dict[str, Any]]) -> bool:
        if not report:
            return False
        if "detected" in report:
            return bool(report["detected"])
        return len(report.get("bias_issues", [])) > 0
