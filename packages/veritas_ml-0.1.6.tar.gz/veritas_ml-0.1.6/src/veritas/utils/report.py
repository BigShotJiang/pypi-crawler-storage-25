"""Report generation utilities for Veritas."""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core.tracing import json_dumps_safe, make_json_safe


REPORT_SYSTEM_PROMPT = """You are Veritas, an AI ethics compliance auditor.

Generate a rigorous markdown final report for the completed bias-audit pipeline.

Requirements:
- State what bias was found and cite the exact fairness metrics that triggered concern.
- Use the provided sample data rows and code snippets as concrete evidence.
- Explain where the bias is visible before mitigation and how it changes after mitigation.
- Include a dedicated section for potentially implicated AI ethics and regulatory concerns.
- Pair every flagged issue with a mitigation strategy and discuss whether the strategy reduced risk.
- Include before/after mitigation data examples whenever they are available.
- Include a full end-to-end summary of the pipeline steps that were followed.
- Treat legal statements as potential compliance concerns grounded in the supplied evidence, not formal legal advice.
- Keep the tone professional, specific, and evidence-based.
"""


def derive_ethics_concerns(
    bias_issues: List[Dict[str, Any]],
    mitigation_technique: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Map detected fairness issues to potential AI ethics and regulatory concerns."""
    technique = mitigation_technique or "documented mitigation workflow"
    concerns: List[Dict[str, Any]] = []

    for issue in bias_issues or []:
        metric = str(issue.get("metric", "Unknown metric"))
        metric_key = metric.lower()
        value = issue.get("value", "N/A")
        threshold = issue.get("threshold", "N/A")
        explanation = issue.get("explanation", "")
        protected_attribute = issue.get("protected_attribute")

        frameworks = [
            "Council of Europe Framework Convention on AI: equality, non-discrimination, and accountability across the AI lifecycle.",
            "OECD AI Principles (2024): human rights, fairness, transparency, and accountability.",
            "UNESCO Recommendation on the Ethics of AI: do-no-harm, inclusiveness, and proportionality.",
        ]
        primary_concern = "Observed fairness disparities may conflict with non-discrimination and accountability expectations."
        mitigation = (
            f"Use `{technique}` to reduce the disparity, then re-audit the model and document the residual trade-offs."
        )

        if "disparate impact" in metric_key:
            primary_concern = (
                "The measured disparate impact suggests a potential adverse-impact concern, including the common 80% screening rule used in employment discrimination review."
            )
            frameworks = [
                "Adverse impact / 80% rule screening: a disparate impact below 0.80 is a common discrimination risk signal.",
                "Council of Europe Framework Convention on AI: equality and non-discrimination duties apply across the AI lifecycle.",
                "EU AI Act: in high-risk domains such as employment, deployers must assess fundamental-rights impacts and manage discriminatory outcomes.",
            ]
            mitigation = (
                f"Use `{technique}` to rebalance training influence or decision thresholds, then compare disparate impact and selection-rate gaps before and after mitigation."
            )
        elif "statistical parity" in metric_key:
            primary_concern = (
                "Different positive-decision rates across groups indicate a demographic-parity concern that can undermine equal treatment."
            )
            frameworks = [
                "Council of Europe Framework Convention on AI: equality and non-discrimination.",
                "OECD AI Principles (2024): human rights, fairness, and accountability.",
                "UNESCO Recommendation on the Ethics of AI: inclusiveness and do-no-harm.",
            ]
            mitigation = (
                f"Use `{technique}` to reduce group-level selection-rate gaps and document why the revised operating point is more equitable."
            )
        elif "equal opportunity" in metric_key:
            primary_concern = (
                "Unequal true-positive rates indicate that qualified individuals do not receive comparable access to beneficial outcomes."
            )
            frameworks = [
                "OECD AI Principles (2024): fairness, robustness, and accountability.",
                "UNESCO Recommendation on the Ethics of AI: do-no-harm and inclusiveness.",
                "EU AI Act: outcome disparities in high-risk systems should be surfaced during fundamental-rights assessment.",
            ]
            mitigation = (
                f"Use `{technique}` to close true-positive-rate gaps, then validate that improved fairness does not introduce an unacceptable accuracy loss."
            )
        elif "average odds" in metric_key:
            primary_concern = (
                "Differences in both false-positive and true-positive behavior indicate uneven error burdens across protected groups."
            )
            frameworks = [
                "Council of Europe Framework Convention on AI: equality, accountability, and safe innovation.",
                "OECD AI Principles (2024): fairness, transparency, and accountability.",
                "UNESCO Recommendation on the Ethics of AI: do-no-harm and proportionality.",
            ]
            mitigation = (
                f"Use `{technique}` to reduce both false-positive and true-positive disparities, and monitor whether the remaining error profile is acceptable."
            )
        elif "accuracy gap" in metric_key:
            primary_concern = (
                "A material accuracy gap means one group receives less reliable model performance, which raises fairness and accountability concerns."
            )
            frameworks = [
                "OECD AI Principles (2024): fairness and accountability.",
                "UNESCO Recommendation on the Ethics of AI: inclusiveness and proportionality.",
                "Council of Europe Framework Convention on AI: equality and non-discrimination.",
            ]
            mitigation = (
                f"Use `{technique}` and targeted error analysis to reduce uneven predictive reliability between protected groups."
            )

        concerns.append({
            "issue": metric,
            "protected_attribute": protected_attribute,
            "severity": issue.get("severity", "UNKNOWN"),
            "metric_value": value,
            "threshold": threshold,
            "evidence": explanation,
            "primary_concern": primary_concern,
            "frameworks": frameworks,
            "mitigation_strategy": mitigation,
        })

    return concerns


def build_report_messages(report_context: Dict[str, Any]) -> List[Dict[str, str]]:
    """Create the LLM messages used for report generation."""
    safe_context = make_json_safe(report_context)
    prompt = (
        "Create the final AI ethics compliance report from the structured context below.\n\n"
        "Required sections:\n"
        "1. Executive Summary\n"
        "2. Pipeline Summary\n"
        "3. Protected Groups Analysis\n"
        "4. Bias Found\n"
        "5. Potential AI Ethics and Regulatory Concerns\n"
        "6. Mitigation Applied\n"
        "7. Before/After Evidence\n"
        "8. Compliance Status\n"
        "9. Recommendations\n\n"
        "Structured context:\n"
        f"{json_dumps_safe(safe_context, indent=2)}"
    )
    return [
        {"role": "system", "content": REPORT_SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]


def _render_table(rows: List[Dict[str, Any]]) -> List[str]:
    """Render rows as a markdown table."""
    if not rows:
        return ["No tabular evidence available."]

    columns = list(rows[0].keys())
    header = "| " + " | ".join(columns) + " |"
    divider = "| " + " | ".join(["---"] * len(columns)) + " |"
    lines = [header, divider]
    for row in rows:
        values = []
        for col in columns:
            value = row.get(col, "")
            if isinstance(value, float):
                values.append(f"{value:.4f}")
            else:
                values.append(str(value))
        lines.append("| " + " | ".join(values) + " |")
    return lines


def _normalise_markdown_text(value: Any) -> str:
    """Collapse extracted PDF/RAG whitespace so markdown does not wrap by word."""
    text = str(value)
    return re.sub(r"\s+", " ", text).strip()


def _normalise_rag_value(value: Any) -> Any:
    """Normalize nested RAG outputs while preserving their structure."""
    if isinstance(value, dict):
        return {key: _normalise_rag_value(val) for key, val in value.items()}
    if isinstance(value, list):
        return [_normalise_rag_value(item) for item in value]
    if isinstance(value, str):
        return _normalise_markdown_text(value)
    return value


def _format_rag_value(value: Any) -> List[str]:
    """Render RAG output as readable markdown without PDF line-break noise."""
    if value in (None, "", [], {}):
        return ["No retrieved evidence available."]

    normalised = _normalise_rag_value(make_json_safe(value))
    if isinstance(normalised, str):
        return [normalised]

    return [
        "```json",
        json.dumps(normalised, indent=2, ensure_ascii=False, default=str),
        "```",
    ]


def _format_metric_table(
    pre_mitigation_metrics: Optional[Dict[str, Any]],
    post_mitigation_metrics: Optional[Dict[str, Any]],
) -> List[str]:
    """Render a before/after metric comparison table."""
    if not pre_mitigation_metrics or not post_mitigation_metrics:
        return ["No before/after metric comparison available."]

    metric_locations = {
        "disparate_impact": "dataset_metrics",
        "statistical_parity_difference": "dataset_metrics",
        "equal_opportunity_difference": "classification_metrics",
        "average_odds_difference": "classification_metrics",
        "theil_index": "classification_metrics",
        "accuracy_overall": "classification_metrics",
    }

    lines = [
        "| Metric | Before | After | Direction |",
        "| --- | --- | --- | --- |",
    ]
    for metric, section in metric_locations.items():
        before = pre_mitigation_metrics.get(section, {}).get(metric)
        after = post_mitigation_metrics.get(section, {}).get(metric)
        if before is None or after is None:
            continue

        target = 0.85 if metric == "disparate_impact" else 0.0
        before_distance = abs(float(before) - target)
        after_distance = abs(float(after) - target)
        direction = "improved" if after_distance < before_distance else "mixed"
        lines.append(f"| {metric} | {before} | {after} | {direction} |")

    return lines if len(lines) > 2 else ["No comparable fairness metrics available."]


def _format_attribute_metric_tables(
    pre_mitigation_metrics: Optional[Dict[str, Any]],
    post_mitigation_metrics: Optional[Dict[str, Any]],
) -> List[str]:
    """Render before/after metrics for every audited protected attribute."""
    pre_reports = (pre_mitigation_metrics or {}).get("reports_by_attribute", {})
    post_reports = (post_mitigation_metrics or {}).get("reports_by_attribute", {})
    if not pre_reports and not post_reports:
        return _format_metric_table(pre_mitigation_metrics, post_mitigation_metrics)

    attributes = list(dict.fromkeys([*pre_reports.keys(), *post_reports.keys()]))
    lines: List[str] = []
    for attr in attributes:
        lines.extend([
            f"### `{attr}`",
            "",
        ])
        lines.extend(_format_metric_table(
            pre_reports.get(attr, {}),
            post_reports.get(attr, {}),
        ))
        lines.append("")
    return lines[:-1] if lines else ["No comparable fairness metrics available."]


def _format_code_snippets(code_snippets: Optional[List[Dict[str, str]]]) -> List[str]:
    """Render code snippets as fenced markdown blocks."""
    if not code_snippets:
        return ["No code snippets were captured for this run."]

    lines: List[str] = []
    for snippet in code_snippets:
        title = snippet.get("title", "Code Snippet")
        language = snippet.get("language", "text")
        code = snippet.get("code", "")
        lines.extend([
            f"### {title}",
            "",
            f"```{language}",
            code.rstrip(),
            "```",
            "",
        ])
    return lines[:-1] if lines else lines


def format_bias_report(
    bias_report: Dict[str, Any],
    privileged_groups: Optional[Dict[str, List]] = None,
    unprivileged_groups: Optional[Dict[str, List]] = None,
    mitigation_applied: bool = False,
    mitigation_technique: Optional[str] = None,
    pre_mitigation_metrics: Optional[Dict[str, Any]] = None,
    post_mitigation_metrics: Optional[Dict[str, Any]] = None,
    dataset_name: str = "dataset",
    model_name: Optional[str] = None,
    protected_attribute: Optional[str] = None,
    protected_attributes: Optional[List[str]] = None,
    ethics_concerns: Optional[List[Dict[str, Any]]] = None,
    bias_examples: Optional[List[Dict[str, Any]]] = None,
    mitigation_examples: Optional[List[Dict[str, Any]]] = None,
    code_snippets: Optional[List[Dict[str, str]]] = None,
    pipeline_steps: Optional[List[str]] = None,
    mitigation_summary: Optional[str] = None,
    rag_context: Optional[Dict[str, Any]] = None,
    report_note: Optional[str] = None,
) -> str:
    """
    Format a detailed AI ethics compliance report in markdown.

    The deterministic formatter is used directly when no LLM is configured and
    also serves as the fallback if the LLM path fails.
    """
    baseline_report = bias_report or post_mitigation_metrics or {}
    final_report = post_mitigation_metrics or baseline_report
    groups = baseline_report.get("protected_groups", {}) or final_report.get("protected_groups", {})
    privileged_groups = privileged_groups or groups.get("privileged", {})
    unprivileged_groups = unprivileged_groups or groups.get("unprivileged", {})
    protected_attribute = protected_attribute or baseline_report.get("protected_attribute") or final_report.get("protected_attribute") or "protected"
    protected_attributes = (
        protected_attributes
        or baseline_report.get("protected_attributes")
        or final_report.get("protected_attributes")
        or ([protected_attribute] if protected_attribute else ["protected"])
    )
    issue_count = baseline_report.get("issue_count", 0)
    detected = baseline_report.get("detected", issue_count > 0)
    issues = baseline_report.get("bias_issues", [])
    ethics_concerns = ethics_concerns or derive_ethics_concerns(issues, mitigation_technique)
    rag_context = rag_context or {}

    lines = [
        "# AI Ethics Compliance Report",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Dataset: {dataset_name}",
        f"Model: {model_name or 'unspecified model'}",
        f"Audited protected attributes: {', '.join(f'`{attr}`' for attr in protected_attributes)}",
        "",
        "## 1. Executive Summary",
        "",
    ]

    if detected:
        lines.append(
            f"Bias was detected across {len(protected_attributes)} protected attribute(s): "
            f"{', '.join(f'`{attr}`' for attr in protected_attributes)}. "
            f"The audit flagged {issue_count} fairness issue(s)."
        )
    else:
        lines.append(
            f"No significant fairness threshold breach was detected for "
            f"{', '.join(f'`{attr}`' for attr in protected_attributes)} in the final audited model."
        )

    if mitigation_applied:
        lines.append(
            f"Mitigation was applied using `{mitigation_technique or 'unspecified technique'}`."
        )
    else:
        lines.append("No mitigation step was applied during this run.")

    if mitigation_summary:
        lines.extend(["", _normalise_markdown_text(mitigation_summary)])

    lines.extend([
        "",
        "## 2. Pipeline Summary",
        "",
    ])
    if pipeline_steps:
        for idx, step in enumerate(pipeline_steps, start=1):
            lines.append(f"{idx}. {step}")
    else:
        lines.append("Pipeline steps were not captured for this run.")

    lines.extend([
        "",
        "## 3. Protected Groups Analysis",
        "",
        f"Primary mitigation attribute: `{protected_attribute}`",
        f"All protected attributes audited: {', '.join(f'`{attr}`' for attr in protected_attributes)}",
        "",
        "Privileged groups:",
    ])
    if privileged_groups:
        for attr, values in privileged_groups.items():
            lines.append(f"- {attr}: {values}")
    else:
        lines.append("- Not captured")

    lines.extend(["", "Unprivileged groups:"])
    if unprivileged_groups:
        for attr, values in unprivileged_groups.items():
            lines.append(f"- {attr}: {values}")
    else:
        lines.append("- Not captured")

    lines.extend([
        "",
        "## 4. Bias Found",
        "",
    ])
    if issues:
        for issue in issues:
            issue_attr = issue.get("protected_attribute", protected_attribute)
            lines.extend([
                f"### {issue.get('metric', 'Unknown metric')} (`{issue_attr}`)",
                "",
                f"- Protected attribute: `{issue_attr}`",
                f"- Severity: {issue.get('severity', 'UNKNOWN')}",
                f"- Value: {issue.get('value', 'N/A')}",
                f"- Threshold: {issue.get('threshold', 'N/A')}",
                f"- Explanation: {issue.get('explanation', 'No explanation provided.')}",
                "",
            ])
    else:
        lines.append("No fairness issues were listed in the final report object.")

    lines.extend([
        "### Metric Evidence",
        "",
    ])
    lines.extend(_format_attribute_metric_tables(
        pre_mitigation_metrics or bias_report,
        post_mitigation_metrics or final_report,
    ))

    lines.extend([
        "",
        "### Before-Mitigation Example Rows",
        "",
    ])
    lines.extend(_render_table(bias_examples or []))

    lines.extend([
        "",
        "### Code Evidence",
        "",
    ])
    lines.extend(_format_code_snippets(code_snippets))

    lines.extend([
        "",
        "## 5. Potential AI Ethics and Regulatory Concerns",
        "",
    ])
    if ethics_concerns:
        for concern in ethics_concerns:
            concern_attr = concern.get("protected_attribute")
            concern_title = concern.get("issue", "Unnamed issue")
            if concern_attr:
                concern_title = f"{concern_title} (`{concern_attr}`)"
            lines.extend([
                f"### {concern_title}",
                "",
                f"- Protected attribute: `{concern_attr}`" if concern_attr else "- Protected attribute: not specified",
                f"- Severity: {concern.get('severity', 'UNKNOWN')}",
                f"- Trigger: {concern.get('metric_value', 'N/A')} against threshold {concern.get('threshold', 'N/A')}",
                f"- Why this matters: {concern.get('primary_concern', '')}",
                f"- Evidence: {concern.get('evidence', '')}",
                f"- Mitigation strategy: {concern.get('mitigation_strategy', '')}",
                "- Potentially implicated frameworks:",
            ])
            for framework in concern.get("frameworks", []):
                lines.append(f"  - {framework}")
            if concern.get("rag_law_context"):
                lines.append("- Retrieved law evidence:")
                lines.extend(_format_rag_value(concern.get("rag_law_context")))
            if concern.get("rag_algorithm_context"):
                lines.append("- Retrieved algorithm evidence:")
                lines.extend(_format_rag_value(concern.get("rag_algorithm_context")))
            if concern.get("rag_algorithm_recommendation"):
                lines.append("- Retrieved algorithm recommendation:")
                lines.extend(_format_rag_value(concern.get("rag_algorithm_recommendation")))
            lines.append("")
    else:
        lines.append("No potential AI ethics or regulatory concerns were derived from the provided issues.")

    lines.extend([
        "## 6. Mitigation Applied",
        "",
    ])
    if mitigation_applied:
        lines.append(f"Technique: `{mitigation_technique or 'unspecified technique'}`")
        if mitigation_summary:
            lines.append(f"Summary: {_normalise_markdown_text(mitigation_summary)}")
    else:
        lines.append("No mitigation output was available.")
    if rag_context.get("algorithm_matches"):
        lines.extend([
            "",
            "### Retrieved Algorithm Guidance",
            "",
        ])
        lines.extend(_format_rag_value(rag_context.get("algorithm_matches")))
    if rag_context.get("algorithm_recommendation"):
        lines.extend([
            "",
            "### Selected Algorithm Recommendation",
            "",
        ])
        lines.extend(_format_rag_value(rag_context.get("algorithm_recommendation")))

    lines.extend([
        "",
        "### After-Mitigation Example Rows",
        "",
    ])
    lines.extend(_render_table(mitigation_examples or []))

    lines.extend([
        "",
        "## 7. Before/After Evidence",
        "",
    ])
    lines.extend(_format_attribute_metric_tables(
        pre_mitigation_metrics or bias_report,
        post_mitigation_metrics or final_report,
    ))
    lines.extend([
        "",
        "### Changed Prediction Snapshot",
        "",
    ])
    changed_examples = [
        row for row in (mitigation_examples or [])
        if row.get("prediction_changed") is True
    ]
    lines.extend(_render_table(changed_examples or mitigation_examples or []))

    lines.extend([
        "",
        "## 8. Compliance Status",
        "",
    ])
    has_critical = any(issue.get("severity") == "CRITICAL" for issue in issues)
    if detected and has_critical:
        lines.append("FAIL: critical fairness concerns remain and should be reviewed before deployment.")
    elif detected:
        lines.append("NEEDS ATTENTION: fairness concerns were found and should be reviewed alongside mitigation results.")
    else:
        lines.append("PASS: no material fairness threshold breach was found in the final audited state.")

    lines.extend([
        "",
        "## 9. Recommendations",
        "",
        "1. Re-run the bias audit whenever the data distribution or model objective changes.",
        "2. Record which protected attributes were audited and which ones were out of scope.",
        "3. Review the remaining fairness-performance trade-offs with domain stakeholders.",
        "4. Treat the law and ethics section as a compliance triage aid, then escalate to formal legal review when deployment stakes are high.",
    ])

    lines.extend([
        "",
        "*Report generated by Veritas*",
    ])
    return "\n".join(lines)


def format_short_summary(bias_report: Dict[str, Any]) -> str:
    """Generate a concise one-line summary."""
    issues = bias_report.get("bias_issues", [])
    if not issues:
        return "No bias detected"

    critical = sum(1 for issue in issues if issue.get("severity") == "CRITICAL")
    high = sum(1 for issue in issues if issue.get("severity") == "HIGH")

    parts = []
    if critical > 0:
        parts.append(f"{critical} critical")
    if high > 0:
        parts.append(f"{high} high")

    summary = ", ".join(parts) if parts else f"{len(issues)} issue(s)"
    return f"Bias detected: {summary}"


def save_markdown_report(report: str, path: Path) -> None:
    """Save report to markdown file."""
    Path(path).write_text(report, encoding="utf-8")
