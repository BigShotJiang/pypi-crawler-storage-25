"""
Veritas - AI Bias Detection and Ethics Compliance Agent.

A Python package for detecting bias in ML models, applying AIF360 mitigation,
and checking compliance with AI ethics laws using dual RAG databases.

Example:
    from veritas import VeritasClassifier, VeritasOrchestrator

    # Use the classifier wrapper
    clf = VeritasClassifier(
        protected_attributes=["sex", "race"],
        apply_mitigation=True
    )
    clf.fit(X_train, y_train, sensitive_features=sensitive_train)
    print(clf.get_bias_summary())

    # Or use the orchestrator directly
    from veritas.agent import VeritasOrchestrator
    orchestrator = VeritasOrchestrator()
    result = orchestrator.run(
        X_test=X_test, y_test=y_test,
        sensitive_features=sensitive_features,
        protected_attribute_names=["sex"]
    )
"""

# Set environment variables before any imports
import os
os.environ["ANONYMIZED_TELEMETRY"] = "False"
os.environ["CHROMADB_TELEMETRY"] = "False"
os.environ["GRPC_VERBOSITY"] = "ERROR"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from .core.tracing import configure_langsmith

configure_langsmith("veritas")

# Public API
from .detector import BiasDetector
from .agent import VeritasOrchestrator, ComplianceAgent
from .models import VeritasClassifier

__all__ = [
    "BiasDetector",
    "VeritasOrchestrator",
    "ComplianceAgent",  # Legacy alias
    "VeritasClassifier",
]
__version__ = "0.1.6"
