"""Knowledge base ingestion for Veritas - dual RAG system."""

import re
from pathlib import Path
from typing import List, Optional

try:
    from langchain_core.documents import Document
except ImportError:
    from langchain.schema import Document
try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_chroma import Chroma

from ..config import config
from ..core.tracing import trace_block
from ..core.db import get_embeddings


class KnowledgeBase:
    """
    Manages dual vector stores:
    - ai_ethics_laws: From PDF, smaller chunks for precise retrieval
    - aif360_algorithms: From TXT, larger semantic chunks
    """

    # Optimized chunk sizes
    LAWS_CHUNK_SIZE = 500
    LAWS_CHUNK_OVERLAP = 50
    ALGORITHMS_CHUNK_SIZE = 2000
    ALGORITHMS_CHUNK_OVERLAP = 200
    DEFAULT_LAWS_PDF = Path(__file__).resolve().parent / "ai_ethics_knowledge_base.pdf"
    DEFAULT_ALGORITHMS_TXT = Path(__file__).resolve().parent / "aif360_algorithms_documentation.txt"

    def __init__(self):
        self._embeddings = None

    def _get_embeddings(self):
        """Lazily construct the embeddings client."""
        if self._embeddings is None:
            self._embeddings = get_embeddings()
        return self._embeddings

    def ingest_laws(self, pdf_path: str, force: bool = False) -> dict:
        """
        Ingest AI ethics laws PDF into Chroma.

        Args:
            pdf_path: Path to PDF file
            force: If True, delete existing collection first

        Returns:
            Dict with collection name and document count
        """
        with trace_block(
            "veritas_ingest_laws",
            run_type="indexing",
            inputs={"pdf_path": str(pdf_path), "force": force},
            tags=["veritas", "rag", "laws"],
        ):
            pdf_path = Path(pdf_path)
            if not pdf_path.exists():
                raise FileNotFoundError(f"PDF not found: {pdf_path}")

            vector_store_path = Path(config.vector_store_dir)
            vector_store_path.mkdir(parents=True, exist_ok=True)

            loader = PyPDFLoader(str(pdf_path))
            pages = loader.load()

            splitter = RecursiveCharacterTextSplitter(
                chunk_size=self.LAWS_CHUNK_SIZE,
                chunk_overlap=self.LAWS_CHUNK_OVERLAP,
                add_start_index=True,
                separators=["\n\n", "\n", ". ", " ", ""],
            )
            docs = splitter.split_documents(pages)

            for doc in docs:
                doc.metadata["source"] = pdf_path.name
                if "page" in doc.metadata:
                    doc.metadata["page"] = int(doc.metadata["page"])

            import chromadb
            client_settings = chromadb.Settings(
                anonymized_telemetry=False,
                is_persistent=True,
                persist_directory=str(vector_store_path),
            )

            vectordb = Chroma.from_documents(
                documents=docs,
                embedding=self._get_embeddings(),
                persist_directory=str(vector_store_path),
                collection_name=config.collection_laws,
                client_settings=client_settings,
            )

            count = vectordb._collection.count()
            return {
                "collection": config.collection_laws,
                "source": str(pdf_path),
                "pages": len(pages),
                "chunks": len(docs),
                "vectors": count,
            }

    def ingest_algorithms(self, txt_path: str, force: bool = False) -> dict:
        """
        Ingest AIF360 algorithms documentation into Chroma.

        Args:
            txt_path: Path to TXT file
            force: If True, delete existing collection first

        Returns:
            Dict with collection name and document count
        """
        with trace_block(
            "veritas_ingest_algorithms",
            run_type="indexing",
            inputs={"txt_path": str(txt_path), "force": force},
            tags=["veritas", "rag", "algorithms"],
        ):
            txt_path = Path(txt_path)
            if not txt_path.exists():
                raise FileNotFoundError(f"Text file not found: {txt_path}")

            vector_store_path = Path(config.vector_store_dir)
            vector_store_path.mkdir(parents=True, exist_ok=True)

            loader = TextLoader(str(txt_path), encoding="utf-8")
            documents = loader.load()
            docs = self._split_by_sections(documents[0].page_content, txt_path.name)

            import chromadb
            client_settings = chromadb.Settings(
                anonymized_telemetry=False,
                is_persistent=True,
                persist_directory=str(vector_store_path),
            )

            vectordb = Chroma.from_documents(
                documents=docs,
                embedding=self._get_embeddings(),
                persist_directory=str(vector_store_path),
                collection_name=config.collection_algorithms,
                client_settings=client_settings,
            )

            count = vectordb._collection.count()
            return {
                "collection": config.collection_algorithms,
                "source": str(txt_path),
                "sections": len(docs),
                "vectors": count,
            }

    def _split_by_sections(self, text: str, source: str) -> List[Document]:
        """
        Split algorithm documentation by section headers.
        Creates larger chunks that preserve algorithm context.
        """
        # Split on markdown headers (## or ====)
        section_pattern = r'(?:\n##+ [^\n]+|\n={3,})'
        sections = re.split(section_pattern, text)

        docs = []
        current_pos = 0

        for i, section in enumerate(sections):
            section = section.strip()
            if len(section) < 100:  # Skip tiny fragments
                continue

            # Extract section title from previous context
            title_match = re.search(r'\n?([^\n]+)', text[max(0, current_pos-200):current_pos])
            section_title = title_match.group(1).strip() if title_match else f"Section {i}"

            # Create overlapping chunks for large sections
            if len(section) > self.ALGORITHMS_CHUNK_SIZE:
                # Split large sections
                words = section.split()
                chunks = []
                current_chunk = []
                current_len = 0

                for word in words:
                    current_chunk.append(word)
                    current_len += len(word) + 1
                    if current_len >= self.ALGORITHMS_CHUNK_SIZE:
                        chunks.append(" ".join(current_chunk))
                        # Keep overlap
                        overlap_words = current_chunk[-self.ALGORITHMS_CHUNK_OVERLAP//10:]
                        current_chunk = overlap_words
                        current_len = sum(len(w) + 1 for w in current_chunk)

                if current_chunk:
                    chunks.append(" ".join(current_chunk))
            else:
                chunks = [section]

            for j, chunk in enumerate(chunks):
                doc = Document(
                    page_content=chunk,
                    metadata={
                        "source": source,
                        "section": section_title[:100],
                        "chunk_index": j,
                    }
                )
                docs.append(doc)

            current_pos += len(section) + 50  # Approximate header length

        return docs

    def init_all(
        self,
        laws_pdf: Optional[str] = None,
        algorithms_txt: Optional[str] = None,
        force: bool = False,
    ) -> dict:
        """
        Initialize both knowledge bases.

        Args:
            laws_pdf: Path to AI ethics PDF
            algorithms_txt: Path to AIF360 algorithms TXT
            force: If True, recreate collections

        Returns:
            Dict with results for each collection
        """
        results = {}

        if laws_pdf:
            results["laws"] = self.ingest_laws(laws_pdf, force=force)

        if algorithms_txt:
            results["algorithms"] = self.ingest_algorithms(algorithms_txt, force=force)

        return results

    def ensure_default_knowledge_bases(self, force: bool = False) -> dict:
        """Ensure the bundled law and algorithm knowledge bases are available."""
        from ..core.db import check_vector_store

        with trace_block(
            "veritas_ensure_default_knowledge_bases",
            run_type="indexing",
            inputs={"force": force},
            tags=["veritas", "rag", "bootstrap"],
        ):
            results = self.status()
            if force or not check_vector_store(config.collection_laws):
                results["laws"] = self.ingest_laws(str(self.DEFAULT_LAWS_PDF), force=force)
            if force or not check_vector_store(config.collection_algorithms):
                results["algorithms"] = self.ingest_algorithms(str(self.DEFAULT_ALGORITHMS_TXT), force=force)
            return results

    def status(self) -> dict:
        """Check status of both knowledge bases."""
        from ..core.db import check_vector_store

        return {
            "laws": {
                "ready": check_vector_store(config.collection_laws),
                "collection": config.collection_laws,
            },
            "algorithms": {
                "ready": check_vector_store(config.collection_algorithms),
                "collection": config.collection_algorithms,
            },
        }


# Global instance
knowledge_base = KnowledgeBase()
