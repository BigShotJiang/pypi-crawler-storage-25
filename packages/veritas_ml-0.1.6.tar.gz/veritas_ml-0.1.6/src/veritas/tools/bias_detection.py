"""Bias detection tool for Veritas - AIF360 as LangChain tool."""

import json
import warnings
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from langchain_core.tools import tool
from sklearn.base import BaseEstimator

warnings.filterwarnings("ignore", category=FutureWarning)

from ..core.tracing import traceable


def _determine_privileged_groups(
    y: np.ndarray, sensitive: np.ndarray, protected_attr: str
) -> tuple:
    """
    Determine privileged/unprivileged groups based on base rates.
    Group with higher favorable outcome rate is considered privileged.

    Returns:
        (privileged_groups_dict, unprivileged_groups_dict)
    """
    from aif360.datasets import StandardDataset
    from aif360.metrics import BinaryLabelDatasetMetric

    df = pd.DataFrame({
        protected_attr: sensitive,
        "label": y
    })

    # Determine favorable class (usually 1)
    favorable_label = 1 if np.any(y == 1) else (0 if np.any(y == 0) else y[0])

    dataset = StandardDataset(
        df=df,
        label_name="label",
        favorable_classes=[favorable_label],
        protected_attribute_names=[protected_attr],
        privileged_classes=[[1]],  # Temporary
    )

    unique_values = np.unique(sensitive)
    base_rates = {}

    for val in unique_values:
        mask = sensitive == val
        rate = np.mean(y[mask] == favorable_label)
        key = int(val) if isinstance(val, (np.integer, int)) else str(val)
        base_rates[key] = float(rate)

    # Higher base rate = privileged
    if base_rates:
        privileged_val = int(max(base_rates, key=base_rates.get))
        unprivileged_val = int(min(base_rates, key=base_rates.get))
    else:
        privileged_val = int(unique_values[0]) if len(unique_values) > 0 else 1
        unprivileged_val = int(unique_values[-1]) if len(unique_values) > 1 else 0

    privileged_groups = {protected_attr: [privileged_val]}
    unprivileged_groups = {protected_attr: [unprivileged_val]}

    return privileged_groups, unprivileged_groups, base_rates


@tool
@traceable(name="detect_bias", run_type="tool", tags=["veritas", "bias", "tool"])
def detect_bias(
    X_test: List[List[float]],
    y_test: List[int],
    sensitive_features: List[int],
    protected_attribute_names: List[str],
    model_predictions: Optional[List[int]] = None,
    model_scores: Optional[List[float]] = None,
    favorable_class: int = 1,
) -> str:
    """
    Detect bias in ML model predictions using AIF360.

    This tool analyzes model predictions for fairness violations by computing
    AIF360 metrics like disparate impact, statistical parity difference,
    equal opportunity difference, and average odds difference.

    It automatically identifies privileged and unprivileged groups based on
    base rates (outcome frequencies) in the data.

    Args:
        X_test: Test features as list of lists
        y_test: True test labels as list of integers
        sensitive_features: Protected attribute values as list (e.g., [0, 1, 1, 0])
                          Use 0/1 encoding (0=unprivileged, 1=privileged) or
                          will be auto-detected based on base rates.
        protected_attribute_names: List of protected attribute names
                                   (e.g., ["sex"], ["sex", "race"])
        model_predictions: Model predictions as list of integers (optional)
                          If None, assumes perfect predictions (y_test)
        model_scores: Model scores/probabilities as list of floats (optional)
        favorable_class: The favorable outcome class (default: 1)

    Returns:
        JSON string containing:
        - detected: bool (whether bias was detected)
        - bias_issues: List of detected issues with severity, metric, value
        - dataset_metrics: disparate_impact, statistical_parity_difference, etc.
        - classification_metrics: equal_opportunity_difference, average_odds_difference, etc.
        - protected_groups: {
            "privileged": {attr: [values]},
            "unprivileged": {attr: [values]},
            "base_rates": {group_value: rate}
          }

    Example:
        detect_bias(
            X_test=[[1, 2], [3, 4], [5, 6]],
            y_test=[0, 1, 1],
            sensitive_features=[0, 1, 1],
            protected_attribute_names=["sex"],
            model_predictions=[0, 1, 0]
        )
    """
    try:
        from aif360.datasets import StandardDataset
        from aif360.metrics import BinaryLabelDatasetMetric, ClassificationMetric
    except ImportError:
        return json.dumps({
            "error": "AIF360 not installed. Install with: pip install aif360"
        }, indent=2)

    try:
        # Convert inputs
        X_test_arr = np.array(X_test)
        y_test_arr = np.array(y_test)
        sensitive_arr = np.array(sensitive_features)

        if model_predictions is None:
            y_pred_arr = y_test_arr.copy()
        else:
            y_pred_arr = np.array(model_predictions)

        protected_attr = protected_attribute_names[0] if protected_attribute_names else "protected"

        # Determine privileged/unprivileged groups
        privileged_groups, unprivileged_groups, base_rates = _determine_privileged_groups(
            y_test_arr, sensitive_arr, protected_attr
        )

        # Build dataset
        df = pd.DataFrame(X_test_arr, columns=[f"feature_{i}" for i in range(X_test_arr.shape[1])])
        df["label"] = y_test_arr
        df[protected_attr] = sensitive_arr

        # Ensure protected attribute is numeric
        df[protected_attr] = pd.to_numeric(df[protected_attr], errors="coerce").fillna(0).astype(int)

        dataset = StandardDataset(
            df=df,
            label_name="label",
            favorable_classes=[favorable_class],
            protected_attribute_names=[protected_attr],
            privileged_classes=[privileged_groups[protected_attr]],
        )

        # Create prediction dataset
        pred_dataset = dataset.copy()
        pred_dataset.labels = y_pred_arr.reshape(-1, 1)

        # Compute metrics
        dm = BinaryLabelDatasetMetric(
            dataset,
            unprivileged_groups=[{protected_attr: unprivileged_groups[protected_attr][0]}],
            privileged_groups=[{protected_attr: privileged_groups[protected_attr][0]}],
        )

        cm = ClassificationMetric(
            dataset,
            pred_dataset,
            unprivileged_groups=[{protected_attr: unprivileged_groups[protected_attr][0]}],
            privileged_groups=[{protected_attr: privileged_groups[protected_attr][0]}],
        )

        # Collect dataset metrics
        dataset_metrics = {
            "disparate_impact": round(float(dm.disparate_impact()), 4),
            "statistical_parity_difference": round(float(dm.statistical_parity_difference()), 4),
            "base_rate_privileged": round(float(dm.base_rate(privileged=True)), 4),
            "base_rate_unprivileged": round(float(dm.base_rate(privileged=False)), 4),
        }

        # Collect classification metrics
        classification_metrics = {
            "accuracy_overall": round(float(cm.accuracy()), 4),
            "accuracy_privileged": round(float(cm.accuracy(privileged=True)), 4),
            "accuracy_unprivileged": round(float(cm.accuracy(privileged=False)), 4),
            "equal_opportunity_difference": round(float(cm.equal_opportunity_difference()), 4),
            "average_odds_difference": round(float(cm.average_odds_difference()), 4),
            "theil_index": round(float(cm.theil_index()), 4),
            "false_positive_rate_privileged": round(float(cm.false_positive_rate(privileged=True)), 4),
            "false_positive_rate_unprivileged": round(float(cm.false_positive_rate(privileged=False)), 4),
            "false_negative_rate_privileged": round(float(cm.false_negative_rate(privileged=True)), 4),
            "false_negative_rate_unprivileged": round(float(cm.false_negative_rate(privileged=False)), 4),
        }

        # Assess bias issues
        bias_issues = []

        di = dataset_metrics["disparate_impact"]
        if di < 0.80:
            bias_issues.append({
                "severity": "CRITICAL",
                "metric": "Disparate Impact",
                "value": di,
                "threshold": "< 0.80",
                "explanation": f"The positive-outcome rate for unprivileged group ({unprivileged_groups}) is less than 80% of privileged group ({privileged_groups})."
            })
        elif di < 0.90:
            bias_issues.append({
                "severity": "MODERATE",
                "metric": "Disparate Impact",
                "value": di,
                "threshold": "0.80-0.90",
                "explanation": "Disparate impact approaching legally problematic levels."
            })

        spd = dataset_metrics["statistical_parity_difference"]
        if abs(spd) > 0.10:
            bias_issues.append({
                "severity": "HIGH",
                "metric": "Statistical Parity Difference",
                "value": spd,
                "threshold": "|SPD| > 0.10",
                "explanation": "Unprivileged group receives significantly fewer positive predictions."
            })

        eod = classification_metrics["equal_opportunity_difference"]
        if abs(eod) > 0.10:
            bias_issues.append({
                "severity": "HIGH",
                "metric": "Equal Opportunity Difference",
                "value": eod,
                "threshold": "|EOD| > 0.10",
                "explanation": "True positive rates differ substantially across groups."
            })

        aod = classification_metrics["average_odds_difference"]
        if abs(aod) > 0.10:
            bias_issues.append({
                "severity": "HIGH",
                "metric": "Average Odds Difference",
                "value": aod,
                "threshold": "|AOD| > 0.10",
                "explanation": "Both TPR and FPR differ between groups."
            })

        ti = classification_metrics["theil_index"]
        if ti > 0.10:
            bias_issues.append({
                "severity": "MODERATE",
                "metric": "Theil Index",
                "value": ti,
                "threshold": "> 0.10",
                "explanation": "Inequality in distribution of positive predictions."
            })

        acc_gap = abs(
            classification_metrics["accuracy_privileged"] -
            classification_metrics["accuracy_unprivileged"]
        )
        if acc_gap > 0.03:
            bias_issues.append({
                "severity": "MODERATE",
                "metric": "Accuracy Gap",
                "value": round(acc_gap, 4),
                "threshold": "> 3%",
                "explanation": "Model accuracy noticeably higher for privileged group."
            })

        # Build result
        result = {
            "detected": len(bias_issues) > 0,
            "issue_count": len(bias_issues),
            "bias_issues": bias_issues,
            "dataset_metrics": dataset_metrics,
            "classification_metrics": classification_metrics,
            "protected_groups": {
                "privileged": privileged_groups,
                "unprivileged": unprivileged_groups,
                "base_rates": {str(k): float(round(v, 4)) for k, v in base_rates.items()},
            },
            "protected_attribute": protected_attr,
            "thresholds": {
                "disparate_impact_min": 0.80,
                "statistical_parity_max": 0.10,
                "equal_opportunity_max": 0.10,
                "average_odds_max": 0.10,
                "theil_index_max": 0.10,
                "accuracy_gap_max": 0.03,
            }
        }

        return json.dumps(result, indent=2)

    except Exception as e:
        return json.dumps({
            "error": f"Bias detection failed: {str(e)}"
        }, indent=2)


@tool
@traceable(name="get_bias_summary", run_type="tool", tags=["veritas", "bias", "summary"])
def get_bias_summary(bias_report_json: str) -> str:
    """
    Get human-readable summary from bias detection report.

    Args:
        bias_report_json: JSON string from detect_bias tool

    Returns:
        Formatted summary with key findings and group information.
    """
    try:
        report = json.loads(bias_report_json)
    except json.JSONDecodeError:
        return f"Invalid JSON report: {bias_report_json[:200]}"

    if "error" in report:
        return f"Error in bias report: {report['error']}"

    lines = [
        "## Bias Detection Summary",
        "",
        f"**Protected Attribute:** {report.get('protected_attribute', 'N/A')}",
        "",
        "### Protected Groups Identified",
    ]

    groups = report.get("protected_groups", {})
    privileged = groups.get("privileged", {})
    unprivileged = groups.get("unprivileged", {})
    base_rates = groups.get("base_rates", {})

    for attr, vals in privileged.items():
        lines.append(f"- **Privileged ({attr}):** {vals}")
    for attr, vals in unprivileged.items():
        lines.append(f"- **Unprivileged ({attr}):** {vals}")

    lines.extend([
        "",
        "**Base Rates (Favorable Outcome):**",
    ])
    for val, rate in base_rates.items():
        group_type = "privileged" if privileged and str(val) == str(list(privileged.values())[0][0]) else "unknown"
        lines.append(f"- Value {val}: {rate*100:.1f}% ({group_type})")

    lines.extend(["", f"### Issues Found: {report.get('issue_count', 0)}", ""])

    issues = report.get("bias_issues", [])
    if not issues:
        lines.append("✅ No significant bias detected.")
    else:
        for issue in issues:
            severity = issue.get("severity", "UNKNOWN")
            metric = issue.get("metric", "Unknown")
            value = issue.get("value", "N/A")
            explanation = issue.get("explanation", "")
            lines.append(f"- **[{severity}]** {metric}: {value}")
            if explanation:
                lines.append(f"  → {explanation}")

    lines.extend(["", "### Key Metrics", ""])
    dm = report.get("dataset_metrics", {})
    cm = report.get("classification_metrics", {})

    lines.extend([
        f"- Disparate Impact: {dm.get('disparate_impact', 'N/A')}",
        f"- Statistical Parity Difference: {dm.get('statistical_parity_difference', 'N/A')}",
        f"- Equal Opportunity Difference: {cm.get('equal_opportunity_difference', 'N/A')}",
        f"- Average Odds Difference: {cm.get('average_odds_difference', 'N/A')}",
    ])

    return "\n".join(lines)
