"""RAG search tools for Veritas - dual database system."""

import re
from pathlib import Path
from typing import List

try:
    from langchain_core.documents import Document
except ImportError:
    from langchain.schema import Document
from langchain_core.tools import tool
from pypdf import PdfReader

from ..config import config
from ..core.db import check_vector_store, get_vector_store
from ..core.tracing import traceable
from ..knowledge.ingest import knowledge_base

KNOWLEDGE_DIR = Path(__file__).resolve().parent.parent / "knowledge"
DEFAULT_LAWS_PDF = KNOWLEDGE_DIR / "ai_ethics_knowledge_base.pdf"
DEFAULT_ALGORITHMS_TXT = KNOWLEDGE_DIR / "aif360_algorithms_documentation.txt"


def _tokenize(text: str) -> set[str]:
    """Tokenize a query or text chunk for fallback lexical search."""
    return {
        token for token in re.findall(r"[a-zA-Z0-9_]+", text.lower())
        if len(token) > 2
    }


def _score_text(query: str, text: str) -> int:
    """Simple lexical overlap score for offline fallback retrieval."""
    query_tokens = _tokenize(query)
    text_tokens = _tokenize(text)
    return len(query_tokens & text_tokens)


def _fallback_pdf_search(query: str, k: int) -> str:
    """Search the bundled law PDF without embeddings."""
    if not DEFAULT_LAWS_PDF.exists():
        return "No relevant documents found in ai_ethics_laws."

    reader = PdfReader(str(DEFAULT_LAWS_PDF))
    scored_pages = []
    for page_index, page in enumerate(reader.pages):
        content = (page.extract_text() or "").strip()
        if not content:
            continue
        score = _score_text(query, content)
        if score > 0:
            excerpt = " ".join(content.split())[:900]
            scored_pages.append((score, page_index + 1, excerpt))

    if not scored_pages:
        return "No relevant documents found in ai_ethics_laws."

    scored_pages.sort(key=lambda item: item[0], reverse=True)
    results = []
    for rank, (_, page_number, excerpt) in enumerate(scored_pages[:k], start=1):
        results.append(
            f"[{rank}] Source: {DEFAULT_LAWS_PDF.name} (Page {page_number})\n{excerpt}"
        )
    return "\n\n---\n\n".join(results)


def _fallback_algorithm_search(query: str, k: int) -> str:
    """Search the bundled algorithm documentation without embeddings."""
    if not DEFAULT_ALGORITHMS_TXT.exists():
        return "No relevant documents found in aif360_algorithms."

    content = DEFAULT_ALGORITHMS_TXT.read_text(encoding="utf-8")
    sections = re.split(r"\n={3,}\n|\n##+ ", content)
    scored_sections = []
    for index, section in enumerate(sections, start=1):
        section = section.strip()
        if len(section) < 120:
            continue
        score = _score_text(query, section)
        if score > 0:
            excerpt = " ".join(section.split())[:1000]
            title = excerpt.split(".")[0][:100] or f"Section {index}"
            scored_sections.append((score, title, excerpt))

    if not scored_sections:
        return "No relevant documents found in aif360_algorithms."

    scored_sections.sort(key=lambda item: item[0], reverse=True)
    results = []
    for rank, (_, title, excerpt) in enumerate(scored_sections[:k], start=1):
        results.append(
            f"[{rank}] Source: {DEFAULT_ALGORITHMS_TXT.name} | Section: {title}\n{excerpt}"
        )
    return "\n\n---\n\n".join(results)


def _format_results(docs: List[Document], collection: str) -> str:
    """Format search results with citations."""
    if not docs:
        return f"No relevant documents found in {collection}."

    results = []
    for i, doc in enumerate(docs, 1):
        source = doc.metadata.get("source", "Unknown")
        page = doc.metadata.get("page", "N/A")
        section = doc.metadata.get("section", "")
        content = doc.page_content.strip()

        if section and section != "N/A":
            header = f"[{i}] Source: {source} | Section: {section}"
        elif page != "N/A":
            header = f"[{i}] Source: {source} (Page {page})"
        else:
            header = f"[{i}] Source: {source}"

        results.append(f"{header}\n{content}")

    return "\n\n---\n\n".join(results)


@tool
@traceable(name="search_ai_ethics_laws", run_type="retriever", tags=["veritas", "rag", "laws"])
def search_ai_ethics_laws(query: str, k: int = 5) -> str:
    """
    Search the AI ethics laws and regulations knowledge base.

    Use this tool to look up specific AI ethics laws, regulations, and guidelines
    that relate to detected bias issues in your model.

    Args:
        query: Natural language query about AI ethics laws
               (e.g., "gender discrimination in hiring algorithms",
                      "EU AI Act prohibited practices",
                      "fairness metrics legal requirements")
        k: Number of results to return (default: 5)

    Returns:
        Relevant law excerpts with source citations (page numbers if available).
    """
    try:
        if not check_vector_store(config.collection_laws):
            return _fallback_pdf_search(query, k)
        vectordb = get_vector_store(config.collection_laws)
        docs: List[Document] = vectordb.similarity_search(query, k=k)
        return _format_results(docs, config.collection_laws)
    except Exception:
        return _fallback_pdf_search(query, k)


@tool
@traceable(name="search_aif360_algorithms", run_type="retriever", tags=["veritas", "rag", "algorithms"])
def search_aif360_algorithms(query: str, k: int = 5) -> str:
    """
    Search the AIF360 algorithms knowledge base for bias mitigation techniques.

    Use this tool to find the appropriate preprocessing, inprocessing, or
    postprocessing algorithm for mitigating detected bias.

    Args:
        query: Natural language query about AIF360 algorithms
               (e.g., "preprocessing for disparate impact",
                      "inprocessing algorithm for demographic parity",
                      "postprocessing equalized odds")
        k: Number of results to return (default: 5)

    Returns:
        Algorithm documentation with usage instructions and source citations.
    """
    try:
        if not check_vector_store(config.collection_algorithms):
            return _fallback_algorithm_search(query, k)
        vectordb = get_vector_store(config.collection_algorithms)
        docs: List[Document] = vectordb.similarity_search(query, k=k)
        return _format_results(docs, config.collection_algorithms)
    except Exception:
        return _fallback_algorithm_search(query, k)


@tool
@traceable(name="select_mitigation_algorithm", run_type="tool", tags=["veritas", "rag", "algorithms"])
def select_mitigation_algorithm(
    bias_issue: str,
    constraint_type: str,
    can_retrain: bool = True,
) -> str:
    """
    Query the AIF360 algorithms database to recommend the best mitigation
    technique based on the detected bias and constraints.

    Args:
        bias_issue: Type of bias detected
                    (e.g., "disparate_impact", "statistical_parity_difference")
        constraint_type: Desired fairness constraint
                         (e.g., "demographic_parity", "equalized_odds",
                                "equal_opportunity")
        can_retrain: Whether model can be retrained (default: True)
                     If False, only postprocessing algorithms are viable.

    Returns:
        Recommended algorithm(s) with justification from documentation.
    """
    # Build contextual query
    query_parts = [bias_issue, constraint_type]
    if can_retrain:
        query_parts.append("preprocessing or inprocessing")
    else:
        query_parts.append("postprocessing")

    query = f"best algorithm for {' '.join(query_parts)}"

    try:
        if not check_vector_store(config.collection_algorithms):
            raise RuntimeError("Algorithm vector store not initialized.")
        vectordb = get_vector_store(config.collection_algorithms)
        docs: List[Document] = vectordb.similarity_search(query, k=3)

        if not docs:
            return "No algorithm recommendations found."

        results = ["## Recommended Mitigation Algorithm(s)\n"]

        for i, doc in enumerate(docs, 1):
            section = doc.metadata.get("section", f"Algorithm {i}")
            content = doc.page_content.strip()[:800]  # Truncate for brevity
            results.append(f"### {i}. {section}\n{content}\n")

        results.append("\n**Usage:** Import from aif360.algorithms or aif360.sklearn modules.")
        return "\n".join(results)

    except Exception:
        fallback_results = _fallback_algorithm_search(query, 3)
        if fallback_results.startswith("No relevant documents found"):
            return "No algorithm recommendations found."
        return "## Recommended Mitigation Algorithm(s)\n\n" + fallback_results + "\n\n**Usage:** Import from aif360.algorithms or aif360.sklearn modules."
