"""Tools for Veritas agent - bias detection, mitigation, and RAG."""

from .bias_detection import detect_bias, get_bias_summary
from .bias_mitigation import mitigate_bias, get_mitigation_recommendation
from .rag_tools import search_ai_ethics_laws, search_aif360_algorithms, select_mitigation_algorithm

__all__ = [
    # Bias detection
    "detect_bias",
    "get_bias_summary",
    # Bias mitigation
    "mitigate_bias",
    "get_mitigation_recommendation",
    # RAG tools
    "search_ai_ethics_laws",
    "search_aif360_algorithms",
    "select_mitigation_algorithm",
]
