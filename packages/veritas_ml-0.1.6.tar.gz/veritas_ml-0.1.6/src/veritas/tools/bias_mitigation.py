"""Bias mitigation tool for Veritas - executable AIF360 techniques."""

import json
import warnings
from typing import Any, Dict, List, Literal, Optional

import numpy as np
import pandas as pd
from langchain_core.tools import tool
from sklearn.linear_model import LogisticRegression

warnings.filterwarnings("ignore", category=FutureWarning)

from ..core.tracing import traceable


def _result(
    technique: str,
    status: str,
    message: str,
    **extra: Any,
) -> str:
    payload = {
        "technique": technique,
        "status": status,
        "message": message,
    }
    payload.update(extra)
    return json.dumps(payload, indent=2)


def _to_standard_dataset(
    X: np.ndarray,
    y: np.ndarray,
    sensitive: np.ndarray,
    protected_attr: str,
    privileged_val: int,
):
    from aif360.datasets import StandardDataset

    df = pd.DataFrame(X, columns=[f"feature_{i}" for i in range(X.shape[1])])
    df["label"] = y
    df[protected_attr] = pd.to_numeric(pd.Series(sensitive), errors="coerce").fillna(0).astype(int)
    return StandardDataset(
        df=df,
        label_name="label",
        favorable_classes=[1],
        protected_attribute_names=[protected_attr],
        privileged_classes=[[privileged_val]],
    )


def _to_prediction_dataset(
    X: np.ndarray,
    predictions: np.ndarray,
    scores: np.ndarray,
    sensitive: np.ndarray,
    protected_attr: str,
    privileged_val: int,
):
    dataset = _to_standard_dataset(X, predictions, sensitive, protected_attr, privileged_val)
    dataset.scores = np.asarray(scores).reshape(-1, 1)
    return dataset


def _compute_group_values(sensitive: np.ndarray) -> tuple[int, int]:
    unique = np.unique(sensitive.astype(int))
    if len(unique) < 2:
        return 1, 0
    return int(unique.max()), int(unique.min())


def _compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    sensitive: np.ndarray,
    X: np.ndarray,
    protected_attr: str,
    privileged_val: int,
    unprivileged_val: int,
) -> Dict[str, Any]:
    from aif360.metrics import BinaryLabelDatasetMetric, ClassificationMetric

    truth_dataset = _to_standard_dataset(X, y_true, sensitive, protected_attr, privileged_val)
    pred_dataset = truth_dataset.copy()
    pred_dataset.labels = y_pred.reshape(-1, 1)

    dm = BinaryLabelDatasetMetric(
        truth_dataset,
        privileged_groups=[{protected_attr: privileged_val}],
        unprivileged_groups=[{protected_attr: unprivileged_val}],
    )
    cm = ClassificationMetric(
        truth_dataset,
        pred_dataset,
        privileged_groups=[{protected_attr: privileged_val}],
        unprivileged_groups=[{protected_attr: unprivileged_val}],
    )
    return {
        "dataset_metrics": {
            "disparate_impact": round(float(dm.disparate_impact()), 4),
            "statistical_parity_difference": round(float(dm.statistical_parity_difference()), 4),
        },
        "classification_metrics": {
            "accuracy_overall": round(float(cm.accuracy()), 4),
            "equal_opportunity_difference": round(float(cm.equal_opportunity_difference()), 4),
            "average_odds_difference": round(float(cm.average_odds_difference()), 4),
            "theil_index": round(float(cm.theil_index()), 4),
        },
    }


@tool
@traceable(name="mitigate_bias", run_type="tool", tags=["veritas", "mitigation", "tool"])
def mitigate_bias(
    X_train: List[List[float]],
    y_train: List[int],
    sensitive_train: List[int],
    X_test: List[List[float]],
    technique: Literal[
        "reweighing",
        "disparate_impact_remover",
        "learning_fair_representations",
        "prejudice_remover",
        "meta_fair_classifier",
        "calibrated_eqodds",
        "eqodds",
        "reject_option",
    ],
    protected_attribute: str = "protected",
    favorable_class: int = 1,
    repair_level: float = 1.0,
    reweighing_apply_to: Literal["train", "both"] = "train",
    y_test: Optional[List[int]] = None,
    sensitive_test: Optional[List[int]] = None,
    model_predictions: Optional[List[int]] = None,
    model_scores: Optional[List[float]] = None,
) -> str:
    """
    Apply executable AIF360 mitigation techniques and return transformed outputs plus metrics.

    Postprocessing techniques require `y_test`, `sensitive_test`, and either model predictions
    or probabilities. Inprocessing techniques use an internal logistic regression baseline.
    """
    del favorable_class, reweighing_apply_to

    try:
        from aif360.algorithms.inprocessing import PrejudiceRemover
        from aif360.algorithms.postprocessing import (
            CalibratedEqOddsPostprocessing,
            EqOddsPostprocessing,
            RejectOptionClassification,
        )
        from aif360.algorithms.preprocessing import Reweighing
    except ImportError:
        return _result(technique, "error", "AIF360 is not installed. Install with: pip install aif360")

    try:
        X_train_arr = np.asarray(X_train, dtype=float)
        y_train_arr = np.asarray(y_train, dtype=int)
        sensitive_train_arr = np.asarray(sensitive_train, dtype=int)
        X_test_arr = np.asarray(X_test, dtype=float) if X_test else np.empty((0, X_train_arr.shape[1]))
        privileged_val, unprivileged_val = _compute_group_values(sensitive_train_arr)

        if technique == "reweighing":
            train_dataset = _to_standard_dataset(
                X_train_arr, y_train_arr, sensitive_train_arr, protected_attribute, privileged_val
            )
            rw = Reweighing(
                privileged_groups=[{protected_attribute: privileged_val}],
                unprivileged_groups=[{protected_attribute: unprivileged_val}],
            )
            rw.fit(train_dataset)
            transformed = rw.transform(train_dataset)
            sample_weights = transformed.instance_weights.tolist()

            model = LogisticRegression(max_iter=500)
            model.fit(X_train_arr, y_train_arr, sample_weight=np.asarray(sample_weights))
            predictions = model.predict(X_test_arr).tolist() if len(X_test_arr) else []

            extra: Dict[str, Any] = {
                "type": "preprocessing",
                "applied": True,
                "transformed_data": {
                    "X_train": X_train_arr.tolist(),
                    "y_train": y_train_arr.tolist(),
                    "sample_weights": sample_weights,
                },
                "predictions": predictions,
            }
            if y_test is not None and sensitive_test is not None and len(X_test_arr):
                extra["after_metrics"] = _compute_metrics(
                    np.asarray(y_test, dtype=int),
                    np.asarray(predictions, dtype=int),
                    np.asarray(sensitive_test, dtype=int),
                    X_test_arr,
                    protected_attribute,
                    privileged_val,
                    unprivileged_val,
                )
            return _result(technique, "success", "Applied reweighing and refit a logistic baseline.", **extra)

        if technique == "prejudice_remover":
            train_dataset = _to_standard_dataset(
                X_train_arr, y_train_arr, sensitive_train_arr, protected_attribute, privileged_val
            )
            model = PrejudiceRemover(eta=1.0, sensitive_attr=protected_attribute, class_attr="label")
            model.fit(train_dataset)

            output: Dict[str, Any] = {
                "type": "inprocessing",
                "applied": True,
            }
            if y_test is not None and sensitive_test is not None and len(X_test_arr):
                test_dataset = _to_standard_dataset(
                    X_test_arr,
                    np.asarray(y_test, dtype=int),
                    np.asarray(sensitive_test, dtype=int),
                    protected_attribute,
                    privileged_val,
                )
                predicted = model.predict(test_dataset)
                output["predictions"] = predicted.labels.ravel().astype(int).tolist()
                output["after_metrics"] = _compute_metrics(
                    np.asarray(y_test, dtype=int),
                    predicted.labels.ravel().astype(int),
                    np.asarray(sensitive_test, dtype=int),
                    X_test_arr,
                    protected_attribute,
                    privileged_val,
                    unprivileged_val,
                )
            return _result(technique, "success", "Applied PrejudiceRemover.", **output)

        if technique == "disparate_impact_remover":
            try:
                from aif360.algorithms.preprocessing import DisparateImpactRemover
            except ImportError as exc:
                return _result(technique, "dependency_missing", str(exc), applied=False)

            try:
                import BlackBoxAuditing  # noqa: F401
            except ImportError:
                return _result(
                    technique,
                    "dependency_missing",
                    "disparate_impact_remover requires BlackBoxAuditing.",
                    applied=False,
                )

            train_dataset = _to_standard_dataset(
                X_train_arr, y_train_arr, sensitive_train_arr, protected_attribute, privileged_val
            )
            remover = DisparateImpactRemover(
                repair_level=repair_level,
                sensitive_attribute=protected_attribute,
            )
            transformed = remover.fit_transform(train_dataset)
            transformed_df, _ = transformed.convert_to_dataframe()
            feature_cols = [c for c in transformed_df.columns if c not in [protected_attribute, "label"]]
            return _result(
                technique,
                "success",
                "Applied disparate impact remover.",
                type="preprocessing",
                applied=True,
                transformed_data={
                    "X_train": transformed_df[feature_cols].values.tolist(),
                    "y_train": y_train_arr.tolist(),
                },
            )

        if technique in {"meta_fair_classifier", "learning_fair_representations"}:
            return _result(
                technique,
                "unsupported",
                f"{technique} is not enabled in this environment.",
                applied=False,
            )

        if y_test is None or sensitive_test is None:
            return _result(
                technique,
                "error",
                "Postprocessing requires y_test and sensitive_test.",
                applied=False,
            )
        if model_predictions is None:
            return _result(
                technique,
                "error",
                "Postprocessing requires model_predictions.",
                applied=False,
            )

        y_test_arr = np.asarray(y_test, dtype=int)
        sensitive_test_arr = np.asarray(sensitive_test, dtype=int)
        predictions_arr = np.asarray(model_predictions, dtype=int)
        scores_arr = np.asarray(model_scores, dtype=float) if model_scores is not None else predictions_arr.astype(float)

        truth_dataset = _to_standard_dataset(
            X_test_arr, y_test_arr, sensitive_test_arr, protected_attribute, privileged_val
        )
        pred_dataset = _to_prediction_dataset(
            X_test_arr, predictions_arr, scores_arr, sensitive_test_arr, protected_attribute, privileged_val
        )

        if technique == "reject_option":
            postprocessor = RejectOptionClassification(
                privileged_groups=[{protected_attribute: privileged_val}],
                unprivileged_groups=[{protected_attribute: unprivileged_val}],
                metric_name="Statistical parity difference",
                metric_lb=-0.05,
                metric_ub=0.05,
            )
        elif technique == "eqodds":
            postprocessor = EqOddsPostprocessing(
                privileged_groups=[{protected_attribute: privileged_val}],
                unprivileged_groups=[{protected_attribute: unprivileged_val}],
            )
        elif technique == "calibrated_eqodds":
            postprocessor = CalibratedEqOddsPostprocessing(
                privileged_groups=[{protected_attribute: privileged_val}],
                unprivileged_groups=[{protected_attribute: unprivileged_val}],
            )
        else:
            return _result(technique, "error", f"Unknown technique: {technique}", applied=False)

        before_metrics = _compute_metrics(
            y_test_arr,
            predictions_arr,
            sensitive_test_arr,
            X_test_arr,
            protected_attribute,
            privileged_val,
            unprivileged_val,
        )
        postprocessor.fit(truth_dataset, pred_dataset)
        mitigated = postprocessor.predict(pred_dataset)
        mitigated_predictions = mitigated.labels.ravel().astype(int)
        after_metrics = _compute_metrics(
            y_test_arr,
            mitigated_predictions,
            sensitive_test_arr,
            X_test_arr,
            protected_attribute,
            privileged_val,
            unprivileged_val,
        )

        return _result(
            technique,
            "success",
            f"Applied {technique} postprocessing.",
            type="postprocessing",
            applied=True,
            before_metrics=before_metrics,
            after_metrics=after_metrics,
            predictions=mitigated_predictions.tolist(),
        )

    except Exception as exc:
        return _result(technique, "error", f"Mitigation failed: {exc}", applied=False)


@tool
@traceable(name="get_mitigation_recommendation", run_type="tool", tags=["veritas", "mitigation", "recommendation"])
def get_mitigation_recommendation(
    bias_issue: str,
    can_retrain: bool = True,
    can_modify_features: bool = True,
) -> str:
    """
    Get recommended mitigation technique based on bias type and constraints.

    Args:
        bias_issue: Type of bias detected
                    (e.g., "disparate_impact", "statistical_parity_difference",
                           "equal_opportunity_difference", "average_odds_difference")
        can_retrain: Whether model can be retrained (default: True)
        can_modify_features: Whether features can be modified (default: True)

    Returns:
        Recommended mitigation technique with explanation.
    """
    recommendations = {
        "disparate_impact": {
            "preprocessing": ["disparate_impact_remover", "reweighing", "learning_fair_representations"],
            "inprocessing": ["prejudice_remover", "meta_fair_classifier"],
            "postprocessing": ["reject_option", "eqodds"],
        },
        "statistical_parity_difference": {
            "preprocessing": ["reweighing", "disparate_impact_remover"],
            "inprocessing": ["prejudice_remover"],
            "postprocessing": ["reject_option"],
        },
        "equal_opportunity_difference": {
            "preprocessing": ["reweighing"],
            "inprocessing": ["meta_fair_classifier"],
            "postprocessing": ["eqodds", "calibrated_eqodds"],
        },
        "average_odds_difference": {
            "preprocessing": ["reweighing"],
            "inprocessing": ["prejudice_remover"],
            "postprocessing": ["eqodds", "calibrated_eqodds"],
        },
    }

    issue_lower = bias_issue.lower().replace(" ", "_")
    recs = recommendations.get(issue_lower, recommendations["disparate_impact"])

    lines = [
        f"## Mitigation Recommendations for: {bias_issue}",
        "",
    ]

    if can_retrain:
        if can_modify_features:
            lines.extend([
                "### Preprocessing (Recommended - Most Effective)",
                "These modify training data before model training:",
                "",
            ])
            for tech in recs["preprocessing"]:
                lines.append(f"- **{tech}**")
            lines.append("")

        lines.extend([
            "### Inprocessing",
            "These modify the training procedure:",
            "",
        ])
        for tech in recs["inprocessing"]:
            lines.append(f"- **{tech}**")
        lines.append("")

    lines.extend([
        "### Postprocessing (Use if model cannot be retrained)",
        "These modify predictions after training:",
        "",
    ])
    for tech in recs["postprocessing"]:
        lines.append(f"- **{tech}**")

    lines.extend([
        "",
        "### Selection Guide",
        "",
        "| Technique | When to Use |",
        "|-----------|-------------|",
        "| reweighing | Simplest option. Works with any classifier that supports sample_weight. |",
        "| disparate_impact_remover | When rank-ordering within groups must be preserved (credit scoring). |",
        "| learning_fair_representations | When you need transferable fair representations. |",
        "| prejudice_remover | Lightest inprocessing option. Adds fairness regularization. |",
        "| meta_fair_classifier | When specific fairness metric must be directly optimized. |",
        "| eqodds | When equalized odds (equal TPR+FPR) is required. |",
        "| calibrated_eqodds | When you need equalized odds AND calibrated scores. |",
        "| reject_option | When you want to favor unprivileged in uncertain predictions. |",
    ])

    return "\n".join(lines)
