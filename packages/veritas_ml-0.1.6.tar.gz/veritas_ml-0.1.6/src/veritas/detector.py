"""Bias detection using IBM AIF360 toolkit with privileged/unprivileged group detection."""

import json
import warnings
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator
from aif360.datasets import StandardDataset
from aif360.metrics import BinaryLabelDatasetMetric, ClassificationMetric
from .core.tracing import traceable

warnings.filterwarnings("ignore", category=FutureWarning)


def _determine_groups_by_base_rate(
    y: np.ndarray, sensitive: np.ndarray, favorable_class: int = 1
) -> Tuple[Dict, Dict, Dict]:
    """
    Determine privileged/unprivileged groups based on base rates.
    Group with higher favorable outcome rate is privileged.

    Returns:
        (privileged_groups_dict, unprivileged_groups_dict, base_rates_dict)
    """
    unique_vals = np.unique(sensitive)
    base_rates = {}

    for val in unique_vals:
        mask = sensitive == val
        key = int(val) if isinstance(val, (np.integer, int)) else str(val)
        if mask.sum() == 0:
            base_rates[key] = 0.0
        else:
            rate = np.mean(y[mask] == favorable_class)
            base_rates[key] = float(rate)

    if not base_rates:
        return {0: [1]}, {0: [0]}, {}

    # Higher base rate = privileged
    privileged_val = int(max(base_rates, key=base_rates.get))
    unprivileged_val = int(min(base_rates, key=base_rates.get))

    # Single attribute assumption for auto-detection
    privileged_groups = {0: [int(privileged_val)]}
    unprivileged_groups = {0: [int(unprivileged_val)]}

    return privileged_groups, unprivileged_groups, base_rates


class BiasDetector:
    """
    Detects bias in ML models using IBM AIF360 toolkit.

    Automatically identifies privileged and unprivileged groups based on
    base rates (outcome frequencies) in the data.

    Supports multiple protected attributes.

    Works with any sklearn-compatible model.

    Example:
        detector = BiasDetector(
            protected_attributes=["sex", "race"],
            privileged_groups={"sex": ["Male"], "race": ["White"]}
        )
        report = detector.audit(model, X_test, y_test, sensitive_features)
    """

    def __init__(
        self,
        protected_attributes: List[str] = None,
        privileged_groups: Optional[Dict[str, List]] = None,
        unprivileged_groups: Optional[Dict[str, List]] = None,
        favorable_classes: Optional[List] = None,
        categorical_features: Optional[List[str]] = None,
    ):
        """
        Initialize bias detector.

        Args:
            protected_attributes: List of protected attribute column names (e.g., ["sex", "race"]).
            privileged_groups: Dict mapping attribute names to privileged values.
                e.g., {"sex": ["Male"], "race": ["White"]}
                If None, auto-detected from data using base rates.
            unprivileged_groups: Dict mapping attribute names to unprivileged values.
                Auto-detected if None.
            favorable_classes: List of favorable label values.
            categorical_features: List of categorical feature names.
        """
        self.protected_attributes = protected_attributes or ["sex"]
        self.privileged_groups = privileged_groups
        self.unprivileged_groups = unprivileged_groups
        self.favorable_classes = favorable_classes or [1, "1", "yes", "Yes", True]
        self.categorical_features = categorical_features or []
        self._detected_groups: Optional[Dict[str, Dict]] = None

    @traceable(name="veritas_bias_audit", run_type="chain", tags=["veritas", "bias", "audit"])
    def audit(
        self,
        model: BaseEstimator,
        X_test: Union[pd.DataFrame, np.ndarray],
        y_test: Union[pd.DataFrame, np.ndarray],
        sensitive_features: Union[pd.Series, np.ndarray, pd.DataFrame],
        label_name: str = "label",
    ) -> Dict[str, Any]:
        """
        Run bias audit on trained model.

        Args:
            model: Trained sklearn-compatible model.
            X_test: Test features.
            y_test: True test labels.
            sensitive_features: Values of protected attribute(s).
                For single attribute: array/Series of values.
                For multiple: DataFrame with columns matching protected_attributes.
            label_name: Name for label column.

        Returns:
            Bias report dictionary with AIF360 metrics including:
            - privileged_groups: Detected or provided privileged group values
            - unprivileged_groups: Detected or provided unprivileged group values
            - base_rates: Outcome rates per group
        """
        # Convert to DataFrame/arrays
        if isinstance(X_test, np.ndarray):
            X_test = pd.DataFrame(X_test, columns=[f"feature_{i}" for i in range(X_test.shape[1])])
        if isinstance(y_test, np.ndarray):
            y_test = pd.Series(y_test.ravel(), name=label_name)

        # Handle sensitive features
        if isinstance(sensitive_features, pd.DataFrame):
            sensitive_frame = sensitive_features.reset_index(drop=True).copy()
        else:
            sensitive_frame = pd.DataFrame(
                {self.protected_attributes[0]: np.array(sensitive_features).ravel()}
            )

        for attr in self.protected_attributes:
            if attr not in sensitive_frame.columns:
                raise ValueError(
                    f"Protected attribute `{attr}` was requested but was not present "
                    "in sensitive_features."
                )

        # Determine favorable class from data
        y_values = np.array(y_test)
        favorable_class = 1 if np.any(y_values == 1) else (0 if np.any(y_values == 0) else y_values[0])

        # Get predictions. Some mitigated estimators require protected attributes at inference time.
        try:
            y_pred = model.predict(X_test, sensitive_features=sensitive_features)
        except TypeError:
            y_pred = model.predict(X_test)
        y_pred = np.asarray(y_pred).reshape(-1)

        reports_by_attribute: Dict[str, Dict[str, Any]] = {}
        all_privileged_groups: Dict[str, List] = {}
        all_unprivileged_groups: Dict[str, List] = {}
        all_base_rates: Dict[str, Dict] = {}
        all_issues: List[Tuple] = []

        for protected_attr in self.protected_attributes:
            sensitive_array = pd.to_numeric(
                sensitive_frame[protected_attr], errors="coerce"
            ).fillna(0).astype(int).values

            # Determine groups if not provided for this attribute.
            if (
                self.privileged_groups is None
                or self.unprivileged_groups is None
                or protected_attr not in self.privileged_groups
                or protected_attr not in self.unprivileged_groups
            ):
                priv_dict, unpriv_dict, base_rates = _determine_groups_by_base_rate(
                    y_values, sensitive_array, favorable_class
                )
                privileged_vals = priv_dict[0]
                unprivileged_vals = unpriv_dict[0]
            else:
                privileged_vals = self.privileged_groups.get(protected_attr, [1])
                unprivileged_vals = self.unprivileged_groups.get(protected_attr, [0])
                base_rates = {}

            all_privileged_groups[protected_attr] = privileged_vals
            all_unprivileged_groups[protected_attr] = unprivileged_vals
            all_base_rates[protected_attr] = base_rates

            # Build dataset with the current protected attribute.
            df = X_test.copy()
            df[label_name] = y_test.values if hasattr(y_test, "values") else y_test
            df[protected_attr] = sensitive_array

            dataset = StandardDataset(
                df=df,
                label_name=label_name,
                favorable_classes=[favorable_class],
                protected_attribute_names=[protected_attr],
                privileged_classes=[privileged_vals],
                categorical_features=self.categorical_features,
            )

            pred_dataset = dataset.copy()
            pred_dataset.labels = y_pred.reshape(-1, 1)

            metrics = self._compute_metrics(
                dataset, pred_dataset, protected_attr, unprivileged_vals, privileged_vals
            )
            issues = self._assess_bias(metrics)
            reports_by_attribute[protected_attr] = {
                **metrics,
                "detected": len(issues) > 0,
                "issue_count": len(issues),
                "protected_groups": {
                    "privileged": {protected_attr: privileged_vals},
                    "unprivileged": {protected_attr: unprivileged_vals},
                    "base_rates": {protected_attr: base_rates},
                },
                "bias_issues": [
                    {
                        "severity": s,
                        "metric": m,
                        "protected_attribute": protected_attr,
                        "value": v,
                        "threshold": t,
                        "explanation": e,
                    }
                    for s, m, v, t, e in issues
                ],
            }
            all_issues.extend(
                (s, m, protected_attr, v, t, e) for s, m, v, t, e in issues
            )

        primary_attr = self.protected_attributes[0]
        primary_report = reports_by_attribute[primary_attr]
        self._detected_groups = {
            "privileged": all_privileged_groups,
            "unprivileged": all_unprivileged_groups,
            "base_rates": all_base_rates,
        }

        report = {
            **primary_report,
            "detected": len(all_issues) > 0,
            "issue_count": len(all_issues),
            "protected_attribute": primary_report.get("protected_attribute"),
            "protected_attributes": list(self.protected_attributes),
            "protected_groups": self._detected_groups,
            "reports_by_attribute": reports_by_attribute,
            "bias_issues": [
                {
                    "severity": s,
                    "metric": m,
                    "protected_attribute": attr,
                    "value": v,
                    "threshold": t,
                    "explanation": e,
                }
                for s, m, attr, v, t, e in all_issues
            ],
        }

        return report

    def _compute_metrics(
        self,
        dataset,
        pred_dataset,
        protected_attr: str,
        unprivileged_vals: List,
        privileged_vals: List,
    ) -> Dict[str, Any]:
        """Compute AIF360 fairness metrics."""
        unprivileged = [{protected_attr: v} for v in unprivileged_vals]
        privileged = [{protected_attr: v} for v in privileged_vals]

        dm = BinaryLabelDatasetMetric(
            dataset,
            unprivileged_groups=unprivileged,
            privileged_groups=privileged,
        )
        cm = ClassificationMetric(
            dataset,
            pred_dataset,
            unprivileged_groups=unprivileged,
            privileged_groups=privileged,
        )

        return {
            "timestamp": datetime.now().isoformat(),
            "dataset": "custom",
            "model": "sklearn_model",
            "protected_attribute": f"{protected_attr} (privileged = {privileged_vals[0]})",
            "dataset_metrics": {
                "disparate_impact": round(float(dm.disparate_impact()), 4),
                "statistical_parity_difference": round(float(dm.statistical_parity_difference()), 4),
                "base_rate_privileged": round(float(dm.base_rate(privileged=True)), 4),
                "base_rate_unprivileged": round(float(dm.base_rate(privileged=False)), 4),
            },
            "classification_metrics": {
                "accuracy_overall": round(float(cm.accuracy()), 4),
                "accuracy_privileged": round(float(cm.accuracy(privileged=True)), 4),
                "accuracy_unprivileged": round(float(cm.accuracy(privileged=False)), 4),
                "equal_opportunity_difference": round(float(cm.equal_opportunity_difference()), 4),
                "average_odds_difference": round(float(cm.average_odds_difference()), 4),
                "theil_index": round(float(cm.theil_index()), 4),
                "false_positive_rate_privileged": round(float(cm.false_positive_rate(privileged=True)), 4),
                "false_positive_rate_unprivileged": round(float(cm.false_positive_rate(privileged=False)), 4),
                "false_negative_rate_privileged": round(float(cm.false_negative_rate(privileged=True)), 4),
                "false_negative_rate_unprivileged": round(float(cm.false_negative_rate(privileged=False)), 4),
            },
        }

    def _assess_bias(self, metrics: Dict) -> List[Tuple]:
        """Assess severity of bias issues."""
        dm = metrics["dataset_metrics"]
        cm = metrics["classification_metrics"]
        issues = []

        di = dm["disparate_impact"]
        if di < 0.80:
            issues.append((
                "CRITICAL", "Disparate Impact", f"{di:.4f}",
                "< 0.80 (80% rule violated)",
                "The positive-outcome rate for unprivileged group is less than 80% of privileged group.",
            ))
        elif di < 0.90:
            issues.append((
                "MODERATE", "Disparate Impact", f"{di:.4f}",
                "0.80–0.90 (approaching 80% rule)",
                "Disparate impact approaching legally problematic levels.",
            ))

        spd = dm["statistical_parity_difference"]
        if abs(spd) > 0.10:
            issues.append((
                "HIGH", "Statistical Parity Difference", f"{spd:.4f}",
                "|SPD| > 0.10",
                "Unprivileged group receives significantly fewer positive predictions.",
            ))

        eod = cm["equal_opportunity_difference"]
        if abs(eod) > 0.10:
            issues.append((
                "HIGH", "Equal Opportunity Difference", f"{eod:.4f}",
                "|EOD| > 0.10",
                "True positive rates differ substantially across groups.",
            ))

        aod = cm["average_odds_difference"]
        if abs(aod) > 0.10:
            issues.append((
                "HIGH", "Average Odds Difference", f"{aod:.4f}",
                "|AOD| > 0.10",
                "Both TPR and FPR differ between groups.",
            ))

        ti = cm["theil_index"]
        if ti > 0.10:
            issues.append((
                "MODERATE", "Theil Index", f"{ti:.4f}",
                "> 0.10",
                "Inequality in distribution of positive predictions.",
            ))

        acc_gap = abs(cm["accuracy_privileged"] - cm["accuracy_unprivileged"])
        if acc_gap > 0.03:
            issues.append((
                "MODERATE", "Accuracy Gap", f"{acc_gap:.4f}",
                "> 3% gap",
                "Model accuracy noticeably higher for privileged group.",
            ))

        return issues

    def get_detected_groups(self) -> Optional[Dict[str, Dict]]:
        """Return detected privileged and unprivileged groups."""
        return self._detected_groups
