"""LangGraph ReAct agent for Veritas - orchestrated bias detection, analysis, mitigation."""

import json
from typing import Annotated, Any, Dict, List, Optional, TypedDict

from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages

from .config import Config
from .core.llm import LLM
from .core.tracing import json_dumps_safe, trace_block
from .tools import (
    detect_bias,
    get_bias_summary,
    get_mitigation_recommendation,
    mitigate_bias,
    search_ai_ethics_laws,
    search_aif360_algorithms,
    select_mitigation_algorithm,
)
from .utils.report import build_report_messages, derive_ethics_concerns, format_bias_report


class VeritasState(TypedDict):
    """State for the Veritas orchestration graph."""

    # Input
    X_test: Optional[List[List[float]]]
    y_test: Optional[List[int]]
    X_train: Optional[List[List[float]]]
    y_train: Optional[List[int]]
    sensitive_features: Optional[List[int]]
    sensitive_train: Optional[List[int]]
    protected_attribute_names: List[str]
    model_predictions: Optional[List[int]]
    can_retrain: bool

    # Detection results
    bias_detected: bool
    bias_report: Optional[Dict[str, Any]]
    privileged_groups: Optional[Dict[str, List]]
    unprivileged_groups: Optional[Dict[str, List]]

    # Analysis results
    violated_laws: Optional[List[Dict]]
    recommended_technique: Optional[str]

    # Mitigation results
    mitigation_applied: bool
    mitigation_result: Optional[Dict[str, Any]]
    mitigated_predictions: Optional[List[int]]

    # Output
    final_report: Optional[str]
    messages: Annotated[list, add_messages]


class VeritasOrchestrator:
    """
    LangGraph orchestrator for end-to-end bias detection and mitigation.

    Pipeline:
        detect_node -> analyze_node -> mitigate_node -> report_node -> END

    Each node uses appropriate tools (bias_detection, rag_tools, mitigation).
    """

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.graph = self._build_graph()
        self._tools = [
            detect_bias,
            get_bias_summary,
            get_mitigation_recommendation,
            mitigate_bias,
            search_ai_ethics_laws,
            search_aif360_algorithms,
            select_mitigation_algorithm,
        ]

    def _detect_node(self, state: VeritasState) -> VeritasState:
        """Run bias detection using the detect_bias tool."""
        if not state.get("X_test") or not state.get("y_test"):
            return {
                **state,
                "bias_detected": False,
                "bias_report": None,
                "messages": state.get("messages", [])
                + [{"role": "system", "content": "No test data provided for bias detection."}],
            }

        # Call detection tool
        result_json = detect_bias.invoke({
            "X_test": state["X_test"],
            "y_test": state["y_test"],
            "sensitive_features": state.get("sensitive_features", []),
            "protected_attribute_names": state.get("protected_attribute_names", ["protected"]),
            "model_predictions": state.get("model_predictions"),
            "favorable_class": 1,
        })

        try:
            bias_report = json.loads(result_json)
        except json.JSONDecodeError:
            bias_report = {"error": "Failed to parse detection result", "raw": result_json}

        # Extract group information
        groups = bias_report.get("protected_groups", {})
        privileged = groups.get("privileged", {})
        unprivileged = groups.get("unprivileged", {})
        detected = bias_report.get("detected", False)

        # Build summary message
        summary = get_bias_summary.invoke({"bias_report_json": result_json})

        messages = state.get("messages", [])
        messages.append({
            "role": "assistant",
            "content": f"**Bias Detection Complete**\n\n{summary}",
        })

        return {
            **state,
            "bias_detected": detected,
            "bias_report": bias_report,
            "privileged_groups": privileged,
            "unprivileged_groups": unprivileged,
            "messages": messages,
        }

    def _analyze_node(self, state: VeritasState) -> VeritasState:
        """Analyze bias against AI ethics laws and select mitigation technique."""
        if not state.get("bias_detected"):
            return {**state, "violated_laws": [], "recommended_technique": None}

        bias_report = state.get("bias_report", {})
        issues = bias_report.get("bias_issues", [])

        # Search for relevant laws for each issue
        violated_laws = []
        for issue in issues:
            metric = issue.get("metric", "")
            explanation = issue.get("explanation", "")

            query = f"{metric} {explanation} AI ethics regulations legal requirements"
            law_results = search_ai_ethics_laws.invoke({"query": query, "k": 3})

            violated_laws.append({
                "issue": metric,
                "severity": issue.get("severity", "UNKNOWN"),
                "value": issue.get("value", "N/A"),
                "relevant_laws": law_results,
            })

        # Get mitigation recommendation based on primary issue
        primary_issue = issues[0] if issues else {"metric": "disparate_impact"}
        can_retrain = state.get("can_retrain", True)

        rec_json = get_mitigation_recommendation.invoke({
            "bias_issue": primary_issue.get("metric", "disparate_impact"),
            "can_retrain": can_retrain,
        })

        # Also query algorithm DB for specific recommendation
        algo_recommendation = select_mitigation_algorithm.invoke({
            "bias_issue": primary_issue.get("metric", "disparate_impact"),
            "constraint_type": "demographic_parity" if "statistical_parity" in primary_issue.get("metric", "").lower() else "equalized_odds",
            "can_retrain": can_retrain,
        })

        messages = state.get("messages", [])
        messages.append({
            "role": "assistant",
            "content": f"**Analysis Complete**\n\nFound {len(violated_laws)} potential legal issues.\n\n**Mitigation Strategy:**\n{rec_json}\n\n**Algorithm Recommendation:**\n{algo_recommendation}",
        })

        # Extract recommended technique
        recommended = self._extract_technique_from_recommendation(rec_json)

        return {
            **state,
            "violated_laws": violated_laws,
            "recommended_technique": recommended,
            "messages": messages,
        }

    def _extract_technique_from_recommendation(self, rec_text: str) -> str:
        """Extract technique name from recommendation text."""
        techniques = [
            "reweighing",
            "disparate_impact_remover",
            "learning_fair_representations",
            "prejudice_remover",
            "meta_fair_classifier",
            "calibrated_eqodds",
            "eqodds",
            "reject_option",
        ]
        rec_lower = rec_text.lower()
        for tech in techniques:
            if tech in rec_lower:
                return tech
        return "reweighing"  # Default fallback

    def _mitigate_node(self, state: VeritasState) -> VeritasState:
        """Apply selected mitigation technique."""
        if not state.get("bias_detected"):
            return {**state, "mitigation_applied": False, "mitigation_result": None}

        technique = state.get("recommended_technique", "reweighing")
        protected_attr = state.get("protected_attribute_names", ["protected"])[0]

        # Prepare training data if available
        X_train = state.get("X_train") or state.get("X_test")  # Fallback
        y_train = state.get("y_train") or state.get("y_test")
        sensitive_train = state.get("sensitive_train") or state.get("sensitive_features")

        # Call mitigation tool
        result_json = mitigate_bias.invoke({
            "X_train": X_train,
            "y_train": y_train,
            "sensitive_train": sensitive_train or [],
            "X_test": state.get("X_test", []),
            "technique": technique,
            "protected_attribute": protected_attr,
            "favorable_class": 1,
        })

        try:
            mitigation_result = json.loads(result_json)
        except json.JSONDecodeError:
            mitigation_result = {"error": "Failed to parse mitigation result", "raw": result_json}

        applied = mitigation_result.get("status") == "success"

        messages = state.get("messages", [])
        if applied:
            messages.append({
                "role": "assistant",
                "content": f"**Mitigation Applied: {technique}**\n\n{mitigation_result.get('message', '')}",
            })
        else:
            messages.append({
                "role": "assistant",
                "content": f"**Mitigation Not Applied**\n\n{mitigation_result.get('message', mitigation_result.get('error', 'Unknown error'))}",
            })

        return {
            **state,
            "mitigation_applied": applied,
            "mitigation_result": mitigation_result,
            "messages": messages,
        }

    def _report_node(self, state: VeritasState) -> VeritasState:
        """Compile final compliance report."""
        pre_report = state.get("bias_report", {}) or {}
        post_report = (
            state.get("mitigation_result", {}).get("after_metrics")
            or pre_report
        )
        privileged = state.get("privileged_groups", {})
        unprivileged = state.get("unprivileged_groups", {})
        mitigation = state.get("mitigation_result") or {}
        ethics_concerns = derive_ethics_concerns(
            pre_report.get("bias_issues", []),
            mitigation.get("technique"),
        )

        violated_laws = state.get("violated_laws") or []
        if violated_laws:
            for concern, law_entry in zip(ethics_concerns, violated_laws):
                concern["rag_law_context"] = law_entry.get("relevant_laws")

        report_context = {
            "dataset_name": "orchestrator_input",
            "model_name": "external_model_predictions" if state.get("model_predictions") else "model",
            "protected_attribute": (state.get("protected_attribute_names") or ["protected"])[0],
            "protected_groups": {
                "privileged": privileged,
                "unprivileged": unprivileged,
            },
            "pre_mitigation_report": pre_report,
            "post_mitigation_report": post_report,
            "mitigation_applied": state.get("mitigation_applied", False),
            "mitigation_result": mitigation,
            "mitigation_summary": mitigation.get("message", "No mitigation summary available."),
            "pipeline_steps": [
                "Detected bias on the provided evaluation split.",
                "Mapped the detected issues to potential AI ethics and regulatory concerns.",
                "Selected and attempted mitigation when retraining was allowed.",
                "Generated the final report from the full pipeline state.",
            ],
            "ethics_concerns": ethics_concerns,
            "bias_examples": [],
            "mitigation_examples": [],
            "code_snippets": [{
                "title": "Orchestrator Metrics Snapshot",
                "language": "python",
                "code": "pipeline_state = " + json_dumps_safe({
                    "pre_mitigation": {
                        "dataset_metrics": pre_report.get("dataset_metrics", {}),
                        "classification_metrics": pre_report.get("classification_metrics", {}),
                    },
                    "post_mitigation": {
                        "dataset_metrics": post_report.get("dataset_metrics", {}),
                        "classification_metrics": post_report.get("classification_metrics", {}),
                    },
                }, indent=2),
            }],
        }

        report_note = None
        try:
            llm_client = LLM(self.config)
            final_report = llm_client.invoke(build_report_messages(report_context))
            required_sections = [
                "Executive Summary",
                "Pipeline Summary",
                "Bias Found",
                "Mitigation Applied",
                "Compliance Status",
            ]
            if not all(section in final_report for section in required_sections):
                report_note = "The LLM response omitted one or more required sections, so Veritas generated a deterministic report instead."
                final_report = format_bias_report(
                    bias_report=pre_report,
                    privileged_groups=privileged,
                    unprivileged_groups=unprivileged,
                    mitigation_applied=state.get("mitigation_applied", False),
                    mitigation_technique=mitigation.get("technique"),
                    pre_mitigation_metrics=pre_report,
                    post_mitigation_metrics=post_report,
                    dataset_name="orchestrator_input",
                    model_name=report_context["model_name"],
                    protected_attribute=report_context["protected_attribute"],
                    ethics_concerns=ethics_concerns,
                    code_snippets=report_context["code_snippets"],
                    pipeline_steps=report_context["pipeline_steps"],
                    mitigation_summary=report_context["mitigation_summary"],
                    report_note=report_note,
                )
        except Exception as exc:
            report_note = f"LLM report generation was unavailable; using the deterministic Veritas formatter instead. Details: {exc}"
            final_report = format_bias_report(
                bias_report=pre_report,
                privileged_groups=privileged,
                unprivileged_groups=unprivileged,
                mitigation_applied=state.get("mitigation_applied", False),
                mitigation_technique=mitigation.get("technique"),
                pre_mitigation_metrics=pre_report,
                post_mitigation_metrics=post_report,
                dataset_name="orchestrator_input",
                model_name=report_context["model_name"],
                protected_attribute=report_context["protected_attribute"],
                ethics_concerns=ethics_concerns,
                code_snippets=report_context["code_snippets"],
                pipeline_steps=report_context["pipeline_steps"],
                mitigation_summary=report_context["mitigation_summary"],
                report_note=report_note,
            )

        return {
            **state,
            "final_report": final_report,
            "messages": state.get("messages", []) + [{"role": "assistant", "content": final_report}],
        }

    def _should_mitigate(self, state: VeritasState) -> str:
        """Decide whether to proceed to mitigation."""
        if state.get("bias_detected") and state.get("can_retrain", True):
            return "mitigate"
        return "report"

    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow."""
        g = StateGraph(VeritasState)

        # Add nodes
        g.add_node("detect", self._detect_node)
        g.add_node("analyze", self._analyze_node)
        g.add_node("mitigate", self._mitigate_node)
        g.add_node("report", self._report_node)

        # Define flow
        g.add_edge(START, "detect")
        g.add_edge("detect", "analyze")
        g.add_conditional_edges(
            "analyze",
            self._should_mitigate,
            {
                "mitigate": "mitigate",
                "report": "report",
            },
        )
        g.add_edge("mitigate", "report")
        g.add_edge("report", END)

        return g.compile()

    def run(
        self,
        X_test: List[List[float]],
        y_test: List[int],
        sensitive_features: List[int],
        protected_attribute_names: List[str] = None,
        X_train: List[List[float]] = None,
        y_train: List[int] = None,
        sensitive_train: List[int] = None,
        model_predictions: List[int] = None,
        can_retrain: bool = True,
    ) -> Dict[str, Any]:
        """
        Run the full Veritas pipeline.

        Args:
            X_test: Test features
            y_test: True test labels
            sensitive_features: Protected attribute values for test set
            protected_attribute_names: Names of protected attributes (e.g., ["sex"])
            X_train: Training features (for mitigation)
            y_train: Training labels
            sensitive_train: Protected attribute values for training set
            model_predictions: Model predictions (if None, uses y_test)
            can_retrain: Whether model can be retrained

        Returns:
            Final state with bias_report, mitigation_result, and final_report
        """
        initial_state = VeritasState(
            X_test=X_test,
            y_test=y_test,
            X_train=X_train,
            y_train=y_train,
            sensitive_features=sensitive_features,
            sensitive_train=sensitive_train,
            protected_attribute_names=protected_attribute_names or ["protected"],
            model_predictions=model_predictions,
            can_retrain=can_retrain,
            bias_detected=False,
            bias_report=None,
            privileged_groups=None,
            unprivileged_groups=None,
            violated_laws=None,
            recommended_technique=None,
            mitigation_applied=False,
            mitigation_result=None,
            mitigated_predictions=None,
            final_report=None,
            messages=[],
        )

        final_state = self.graph.invoke(initial_state)
        return {
            "bias_detected": final_state["bias_detected"],
            "bias_report": final_state["bias_report"],
            "privileged_groups": final_state["privileged_groups"],
            "unprivileged_groups": final_state["unprivileged_groups"],
            "mitigation_applied": final_state["mitigation_applied"],
            "mitigation_result": final_state["mitigation_result"],
            "final_report": final_state["final_report"],
        }


# Backwards compatibility - old ComplianceAgent interface
class ComplianceAgent(VeritasOrchestrator):
    """Legacy interface - delegates to VeritasOrchestrator."""

    def analyze(self, bias_report: Dict[str, Any]) -> str:
        """Legacy analyze method - requires manual data extraction."""
        # This is a simplified version for backwards compatibility
        # Full pipeline requires calling run() with actual data

        llm_client = LLM(self.config)

        # Generate mitigation recommendations based on report
        issues = bias_report.get("bias_issues", [])
        metrics = {
            **bias_report.get("dataset_metrics", {}),
            **bias_report.get("classification_metrics", {}),
        }

        prompt = f"""Generate a mitigation report for this bias analysis:

Issues: {json.dumps(issues, indent=2)}
Metrics: {json.dumps(metrics, indent=2)}

Include:
1. Summary of bias issues
2. Violated fairness metrics
3. General mitigation recommendations
4. Compliance status
"""

        return llm_client.invoke([
            {"role": "system", "content": "You are an AI Ethics Compliance Auditor."},
            {"role": "user", "content": prompt},
        ])
