"""LLM router for Veritas - strictly uses defaults.json configuration."""

import os
from typing import Optional

from langchain_core.language_models import BaseChatModel
from langchain_ollama import ChatOllama
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq

from ..config import Config
from .tracing import traceable


class LLM:
    """Router for multiple LLM providers - strictly uses defaults.json."""

    def __init__(self, config: Config):
        self.config = config
        self._llm: Optional[BaseChatModel] = None
        self._init_llm()

    def _init_llm(self) -> None:
        """Initialize the LLM client based on provider from defaults.json."""
        provider = self.config.llm_provider
        model = self.config.llm_model

        if not provider:
            raise ValueError(
                "No LLM provider configured. Set 'provider' in defaults.json "
                "or LLM_PROVIDER environment variable."
            )

        if provider == "ollama":
            if not model:
                raise ValueError(
                    "No Ollama model configured. Set 'llm' in defaults.json "
                    "or LLM_MODEL environment variable."
                )
            self._llm = ChatOllama(
                model=model,
                base_url=self.config.ollama_base_url,
                temperature=0.1,
            )

        elif provider == "openrouter":
            api_key = self.config.openrouter_api_key
            if not api_key:
                raise ValueError(
                    "OpenRouter API key not found. "
                    "Set OPENROUTER_API_KEY environment variable."
                )
            if not model:
                raise ValueError(
                    "No OpenRouter model configured. Set 'llm' in defaults.json "
                    "or LLM_MODEL environment variable."
                )
            # OpenRouter uses OpenAI-compatible API
            os.environ.setdefault("OPENAI_API_KEY", api_key)
            self._llm = ChatOpenAI(
                model=model,
                api_key=api_key,
                base_url=self.config.openrouter_base_url,
                temperature=0.1,
            )

        elif provider == "groq":
            api_key = self.config.groq_api_key
            if not api_key:
                raise ValueError(
                    "Groq API key not found. "
                    "Set GROQ_API_KEY environment variable."
                )
            if not model:
                raise ValueError(
                    "No Groq model configured. Set 'llm' in defaults.json "
                    "or LLM_MODEL environment variable."
                )
            kwargs = {
                "model": model,
                "groq_api_key": api_key,
                "temperature": 0.1,
            }
            if self.config.groq_base_url:
                kwargs["groq_api_base"] = self.config.groq_base_url
            self._llm = ChatGroq(**kwargs)

        else:
            raise ValueError(
                f"Unknown LLM provider: {provider}. "
                "Supported providers: openrouter, ollama, groq. "
                "Configure 'provider' in defaults.json."
            )

    @property
    def llm(self) -> BaseChatModel:
        """Get the underlying LLM client."""
        return self._llm

    @traceable(name="veritas_llm_invoke", run_type="llm", tags=["veritas", "llm"])
    def invoke(self, messages: list) -> str:
        """Invoke LLM with messages."""
        response = self._llm.invoke(messages)
        return response.content if hasattr(response, "content") else str(response)

    def __call__(self, messages: list) -> str:
        """Alias for invoke."""
        return self.invoke(messages)
