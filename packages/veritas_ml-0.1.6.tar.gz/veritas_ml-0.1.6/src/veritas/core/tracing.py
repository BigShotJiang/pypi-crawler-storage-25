"""Tracing helpers for Veritas."""

import json
import os
from contextlib import nullcontext
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv


PACKAGE_ROOT = Path(__file__).resolve().parent.parent
REPO_ROOT = PACKAGE_ROOT.parent.parent
PACKAGE_ENV_FILE = PACKAGE_ROOT / ".env"
ROOT_ENV_FILE = REPO_ROOT / ".env"

load_dotenv(dotenv_path=ROOT_ENV_FILE, override=False)
load_dotenv(dotenv_path=PACKAGE_ENV_FILE, override=False)


def _env_truthy(name: str) -> bool:
    """Return True when an environment flag is explicitly enabled."""
    return os.getenv(name, "").strip().lower() in {"1", "true", "yes", "on"}


def configure_langsmith(default_project: str = "veritas") -> bool:
    """Enable LangSmith tracing only when explicitly requested.

    Having a LangSmith API key in a local .env file should not be enough to
    start background network uploads. A stale or unauthorized key otherwise
    causes noisy 403 errors after successful pipeline runs.
    """
    tracing_requested = _env_truthy("LANGSMITH_TRACING")
    if not tracing_requested:
        os.environ["LANGSMITH_TRACING"] = "false"
        os.environ["LANGSMITH_TRACING_V2"] = "false"
        os.environ["LANGCHAIN_TRACING_V2"] = "false"
        return False

    api_key = os.getenv("LANGSMITH_API_KEY")
    if not api_key:
        os.environ["LANGSMITH_TRACING"] = "false"
        os.environ["LANGSMITH_TRACING_V2"] = "false"
        os.environ["LANGCHAIN_TRACING_V2"] = "false"
        return False

    project = (
        os.getenv("LANGSMITH_PROJECT")
        or os.getenv("LANGCHAIN_PROJECT")
        or default_project
    )
    os.environ["LANGSMITH_TRACING"] = "true"
    os.environ["LANGSMITH_TRACING_V2"] = "true"
    os.environ["LANGCHAIN_TRACING_V2"] = "true"
    os.environ.setdefault("LANGSMITH_PROJECT", project)
    os.environ.setdefault("LANGCHAIN_PROJECT", project)
    return True


configure_langsmith()

try:
    from langsmith import trace as _trace
    from langsmith import traceable as _traceable
except ImportError:  # pragma: no cover - tracing is optional at runtime
    _trace = None
    _traceable = None


def traceable(*args: Any, **kwargs: Any) -> Callable:
    """Return a LangSmith traceable decorator when available."""
    if _traceable is None or not configure_langsmith():
        def passthrough(func: Callable) -> Callable:
            return func
        return passthrough
    return _traceable(*args, **kwargs)


def trace_block(
    name: str,
    run_type: str = "chain",
    inputs: dict | None = None,
    tags: list[str] | None = None,
    metadata: dict | None = None,
):
    """Create a LangSmith tracing context when available."""
    if _trace is None or not configure_langsmith():
        return nullcontext()
    return _trace(
        name=name,
        run_type=run_type,
        inputs=inputs,
        tags=tags,
        metadata=metadata,
    )


def make_json_safe(value: Any) -> Any:
    """Recursively convert objects into JSON-safe structures."""
    if isinstance(value, dict):
        return {str(key): make_json_safe(val) for key, val in value.items()}
    if isinstance(value, list):
        return [make_json_safe(item) for item in value]
    if isinstance(value, tuple):
        return [make_json_safe(item) for item in value]
    if isinstance(value, set):
        return [make_json_safe(item) for item in sorted(value, key=str)]
    if hasattr(value, "tolist"):
        try:
            return make_json_safe(value.tolist())
        except Exception:
            return str(value)
    return value


def json_dumps_safe(value: Any, **kwargs: Any) -> str:
    """Serialize data to JSON after normalising keys and values."""
    return json.dumps(make_json_safe(value), default=str, **kwargs)
