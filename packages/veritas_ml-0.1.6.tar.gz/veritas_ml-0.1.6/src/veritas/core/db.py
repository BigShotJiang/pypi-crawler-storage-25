"""Vector database management for Veritas - multi-collection support."""

import os
from functools import lru_cache
from pathlib import Path

from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

from ..config import config

# Disable ChromaDB telemetry
os.environ["ANONYMIZED_TELEMETRY"] = "False"


@lru_cache(maxsize=1)
def get_embeddings() -> HuggingFaceEmbeddings:
    """Get cached HuggingFace embeddings instance."""
    return HuggingFaceEmbeddings(
        model_name=config.embedding_model,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def get_vector_store(collection_name: str = None) -> Chroma:
    """
    Get or create Chroma vector store for specified collection.

    Args:
        collection_name: Name of collection. If None, uses config.collection_laws.

    Returns:
        Chroma: Initialized Chroma vector store.

    Raises:
        RuntimeError: If vector store not initialized.
    """
    vector_store_path = Path(config.vector_store_dir)

    if not vector_store_path.exists():
        raise RuntimeError(
            f"Vector store not found at {vector_store_path}. "
            "Run veritas initialization first."
        )

    embeddings = get_embeddings()
    collection = collection_name or config.collection_laws

    # Use client_settings to avoid locking issues
    import chromadb
    client_settings = chromadb.Settings(
        anonymized_telemetry=False,
        is_persistent=True,
        persist_directory=str(vector_store_path),
    )

    return Chroma(
        persist_directory=str(vector_store_path),
        embedding_function=embeddings,
        collection_name=collection,
        client_settings=client_settings,
    )


def check_vector_store(collection_name: str = None) -> bool:
    """Check if vector store is initialized for given collection."""
    vector_store_path = Path(config.vector_store_dir)
    if not vector_store_path.exists():
        return False

    try:
        import chromadb
        client_settings = chromadb.Settings(
            anonymized_telemetry=False,
            is_persistent=True,
            persist_directory=str(vector_store_path),
        )
        client = chromadb.PersistentClient(
            path=str(vector_store_path),
            settings=client_settings,
        )
        collection = collection_name or config.collection_laws
        try:
            client.get_collection(collection)
            return True
        except Exception:
            return False
    except Exception:
        return False


def list_collections() -> list:
    """List all collections in vector store."""
    vector_store_path = Path(config.vector_store_dir)
    if not vector_store_path.exists():
        return []

    try:
        import chromadb
        client_settings = chromadb.Settings(
            anonymized_telemetry=False,
            is_persistent=True,
            persist_directory=str(vector_store_path),
        )
        client = chromadb.PersistentClient(
            path=str(vector_store_path),
            settings=client_settings,
        )
        return [c.name for c in client.list_collections()]
    except Exception:
        return []
