"""Tests for ComplianceChecker."""

import unittest
import numpy as np
from sklearn.linear_model import LogisticRegression

from veritas import ComplianceChecker, BiasDetector


class TestComplianceChecker(unittest.TestCase):
    """Test cases for ComplianceChecker."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        self.X_train = np.random.randn(100, 5)
        self.y_train = np.random.randint(0, 2, 100)
        self.X_test = np.random.randn(30, 5)
        self.y_test = np.random.randint(0, 2, 30)
        self.sensitive_train = np.random.choice(["M", "F"], 100)
        self.sensitive_test = np.random.choice(["M", "F"], 30)

    def test_initialization(self):
        """Test checker can be initialized."""
        checker = ComplianceChecker()
        self.assertIsNotNone(checker)

    def test_initialization_with_provider(self):
        """Test checker can be initialized with provider."""
        checker = ComplianceChecker(llm_provider="openrouter")
        self.assertIsNotNone(checker)

    def test_check_requires_report(self):
        """Test check requires a valid report."""
        checker = ComplianceChecker()

        # Empty report should handle gracefully
        empty_report = {
            "dataset_metrics": {},
            "classification_metrics": {},
            "bias_issues": []
        }

        # This will fail without LLM credentials, but shouldn't crash
        try:
            result = checker.check(empty_report)
            self.assertIsInstance(result, str)
        except Exception:
            # Expected without API keys
            pass

    def test_full_audit_structure(self):
        """Test full_audit returns correct structure."""
        checker = ComplianceChecker()

        try:
            result = checker.full_audit(
                X_train=self.X_train,
                y_train=self.y_train,
                X_test=self.X_test,
                y_test=self.y_test,
                sensitive_train=self.sensitive_train,
                sensitive_test=self.sensitive_test,
                protected_attribute="sex",
                privileged_classes=[["M"]]
            )

            self.assertIn("bias_report", result)
            self.assertIn("compliance_report", result)
            self.assertIn("model", result)

        except Exception as e:
            # Expected if LLM not configured
            self.assertIn("API key", str(e) or "LLM" in str(e))


if __name__ == "__main__":
    unittest.main()
