"""Tests for sklearn-compatible wrappers."""

import unittest
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from veritas import VeritasClassifier


class TestVeritasClassifier(unittest.TestCase):
    """Test cases for VeritasClassifier."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        self.X = np.random.randn(200, 5)
        self.y = np.random.randint(0, 2, 200)
        self.sensitive = np.random.choice(["A", "B"], 200)

    def test_initialization(self):
        """Test classifier can be initialized."""
        clf = VeritasClassifier(
            base_estimator=LogisticRegression(),
            protected_attribute="attr",
            run_audit=False
        )
        self.assertIsNotNone(clf.base_estimator)
        self.assertEqual(clf.protected_attribute, "attr")

    def test_fit_without_audit(self):
        """Test fitting without audit works."""
        clf = VeritasClassifier(
            base_estimator=LogisticRegression(max_iter=500),
            run_audit=False
        )
        clf.fit(self.X, self.y)
        self.assertIsNotNone(clf.estimator_)

    def test_predict_after_fit(self):
        """Test prediction works after fitting."""
        clf = VeritasClassifier(
            base_estimator=LogisticRegression(max_iter=500),
            run_audit=False
        )
        clf.fit(self.X, self.y)
        predictions = clf.predict(self.X[:10])
        self.assertEqual(len(predictions), 10)

    def test_has_bias_before_fit(self):
        """Test has_bias returns False before fitting."""
        clf = VeritasClassifier()
        self.assertFalse(clf.has_bias())

    def test_get_bias_report_before_fit(self):
        """Test get_bias_report returns None before fitting."""
        clf = VeritasClassifier()
        self.assertIsNone(clf.get_bias_report())

    def test_with_different_estimators(self):
        """Test works with different base estimators."""
        for estimator in [LogisticRegression(max_iter=500), RandomForestClassifier(n_estimators=10)]:
            clf = VeritasClassifier(
                base_estimator=estimator,
                run_audit=False
            )
            clf.fit(self.X, self.y)
            score = clf.score(self.X, self.y)
            self.assertGreaterEqual(score, 0)
            self.assertLessEqual(score, 1)


if __name__ == "__main__":
    unittest.main()
