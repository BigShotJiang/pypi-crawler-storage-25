
class OrthogonalAdapterException(Exception):
    pass
