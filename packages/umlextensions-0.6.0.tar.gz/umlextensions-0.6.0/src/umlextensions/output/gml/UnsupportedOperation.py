
class UnsupportedOperation(Exception):
    pass
