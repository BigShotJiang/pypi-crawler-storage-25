"""Portfolio Concentration view - portfolio-level concentration metrics."""

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.widgets import Static


class PortfolioConcentrationView(VerticalScroll):
    DEFAULT_CSS = """
    PortfolioConcentrationView {
        height: 1fr;
        min-height: 1fr;
        padding: 1 2;
    }
    """

    def compose(self) -> ComposeResult:
        yield Static("Portfolio Concentration — Connect IBKR to view", id="pconc-content")

    def load_data(self) -> None:
        self.query_one("#pconc-content", Static).update("")
        self.loading = True
        self.run_worker(self._load(), exclusive=True)

    async def _load(self) -> None:
        from asyncio import to_thread

        from etfray.data.ibkr_service import get_ibkr_service
        from etfray.data.source_resolver import resolve_holdings
        from etfray.domain.portfolio_analytics import calculate_lookthrough

        svc = get_ibkr_service()
        content = self.query_one("#pconc-content", Static)

        if not svc.is_connected or not svc.positions:
            self.loading = False
            content.update("Portfolio Concentration — IBKR not connected")
            return

        total_value = sum(abs(p.market_value) for p in svc.positions)
        if total_value == 0:
            self.loading = False
            return

        positions = [{"symbol": p.symbol, "weight": abs(p.market_value) / total_value * 100} for p in svc.positions]

        # ETF-level concentration
        sorted_pos = sorted(positions, key=lambda x: x["weight"], reverse=True)
        top5_etf = sum(p["weight"] for p in sorted_pos[:5])

        # Lookthrough concentration
        holdings_cache = {}
        preference = getattr(self.app, "_data_source", "auto")
        for pos in positions:
            df, _ = await to_thread(resolve_holdings, pos["symbol"], preference)
            holdings_cache[pos["symbol"]] = df

        lookthrough, unresolved = calculate_lookthrough(positions, holdings_cache)

        top10_lt = sum(h.total_weight for h in lookthrough[:10])
        effective_n = 0
        if lookthrough:
            total_lt = sum(h.total_weight for h in lookthrough)
            if total_lt > 0:
                hhi = sum((h.total_weight / total_lt) ** 2 for h in lookthrough)
                effective_n = 1 / hhi if hhi > 0 else len(lookthrough)

        # Overlap detection
        etf_holdings: dict[str, set] = {}
        for pos in positions:
            df = holdings_cache.get(pos["symbol"])
            if df is not None and not df.empty and "ticker" in df.columns:
                tickers = df["ticker"].dropna().astype(str).str.upper()
                # Normalize ticker format: strip spaces and slash separators so that
                # "BRK B" and "BRK/B" both compare as "BRKB".
                # Note: this is a best-effort heuristic and may over-merge distinct
                # share classes that happen to share the same stem after stripping.
                tickers = tickers.str.replace(r"[\s/]", "", regex=True)
                etf_holdings[pos["symbol"]] = set(tickers)

        overlap_score = "Low"
        if len(etf_holdings) >= 2:
            symbols = list(etf_holdings.keys())
            overlaps = []
            for i in range(len(symbols)):
                for j in range(i + 1, len(symbols)):
                    s1, s2 = etf_holdings[symbols[i]], etf_holdings[symbols[j]]
                    union = len(s1 | s2)
                    if union:
                        overlaps.append(len(s1 & s2) / union)
            avg_overlap = sum(overlaps) / len(overlaps) if overlaps else 0
            overlap_score = "High" if avg_overlap > 0.5 else "Medium" if avg_overlap > 0.2 else "Low"

        lines = [
            "[bold]Portfolio Concentration[/bold]",
            "",
            "── ETF Position Level ──",
            f"  Largest ETF:           {sorted_pos[0]['symbol']} ({sorted_pos[0]['weight']:.1f}%)"
            if sorted_pos
            else "",
            f"  Top 5 ETF positions:   {top5_etf:.1f}%",
            f"  Number of ETFs:        {len(positions)}",
            "",
            "── Lookthrough Level ──",
            f"  Top 10 effective:      {top10_lt:.2f}%",
            f"  Largest underlying:    {lookthrough[0].ticker} ({lookthrough[0].total_weight:.3f}%)"
            if lookthrough
            else "",
            f"  Effective holdings:    {effective_n:.0f}",
            f"  ETF overlap:           {overlap_score}",
            "",
            f"  Unresolved exposure:   {sum(u.portfolio_weight for u in unresolved):.1f}%",
        ]
        self.loading = False
        content.update("\n".join(lines))
