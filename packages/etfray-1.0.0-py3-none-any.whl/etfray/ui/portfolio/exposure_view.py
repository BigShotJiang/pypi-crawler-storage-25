"""Portfolio Exposure view - aggregated exposure across all positions."""

from textual.app import ComposeResult
from textual.containers import Horizontal, VerticalScroll
from textual.widgets import DataTable, Static


class PortfolioExposureView(VerticalScroll):
    DEFAULT_CSS = """
    PortfolioExposureView {
        height: 1fr;
        min-height: 1fr;
        padding: 1 2;
    }
    PortfolioExposureView Horizontal {
        height: auto;
    }
    PortfolioExposureView .exp-table {
        height: auto;
        width: 1fr;
    }
    """

    def compose(self) -> ComposeResult:
        yield Static("Portfolio Exposure — Connect IBKR to view", id="pexp-title")
        with Horizontal():
            yield DataTable(id="pexp-sector", classes="exp-table")
            yield DataTable(id="pexp-country", classes="exp-table")

    def on_mount(self) -> None:
        self.query_one("#pexp-sector", DataTable).add_columns("Sector", "Weight %")
        self.query_one("#pexp-country", DataTable).add_columns("Country", "Weight %")

    def load_data(self) -> None:
        sector_table = self.query_one("#pexp-sector", DataTable)
        country_table = self.query_one("#pexp-country", DataTable)
        sector_table.clear()
        country_table.clear()
        self.loading = True
        self.run_worker(self._load(), exclusive=True)

    async def _load(self) -> None:
        from asyncio import to_thread

        from etfray.data.ibkr_service import get_ibkr_service
        from etfray.data.sector_service import get_sectors_bulk
        from etfray.data.source_resolver import resolve_holdings
        from etfray.domain.portfolio_analytics import calculate_lookthrough, calculate_portfolio_exposure

        svc = get_ibkr_service()
        title = self.query_one("#pexp-title", Static)

        if not svc.is_connected or not svc.positions:
            title.update("Portfolio Exposure — IBKR not connected")
            self.loading = False
            return

        total_value = sum(abs(p.market_value) for p in svc.positions)
        if total_value == 0:
            self.loading = False
            return

        positions = [{"symbol": p.symbol, "weight": abs(p.market_value) / total_value * 100} for p in svc.positions]

        holdings_cache = {}
        preference = getattr(self.app, "_data_source", "auto")
        for pos in positions:
            df, _ = await to_thread(resolve_holdings, pos["symbol"], preference)
            holdings_cache[pos["symbol"]] = df

        lookthrough, _ = calculate_lookthrough(positions, holdings_cache)

        # Populate sector for all lookthrough holdings
        tickers = [h.ticker for h in lookthrough if h.ticker]
        sector_map = await to_thread(get_sectors_bulk, tickers)
        for h in lookthrough:
            if h.ticker and h.ticker in sector_map:
                h.sector = sector_map[h.ticker]

        title.update("Portfolio Exposure")

        # Sector
        sector_table = self.query_one("#pexp-sector", DataTable)
        sector_table.clear()
        for cat, wt in calculate_portfolio_exposure(lookthrough, "sector"):
            sector_table.add_row(cat or "Unclassified", f"{wt:.2f}%")

        # Country
        country_table = self.query_one("#pexp-country", DataTable)
        country_table.clear()
        for cat, wt in calculate_portfolio_exposure(lookthrough, "country"):
            country_table.add_row(cat or "Unclassified", f"{wt:.2f}%")
        self.loading = False
