# Tribulnation Btcbox SDK

> An SDK to connect Btcbox with the Tribulnation ecosystem.

🚧 Under construction.