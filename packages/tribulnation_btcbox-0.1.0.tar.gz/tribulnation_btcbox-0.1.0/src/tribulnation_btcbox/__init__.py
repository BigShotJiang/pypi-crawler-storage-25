"""
### Tribulnation Btcbox
> An SDK to connect Btcbox with the Tribulnation ecosystem.

- Details
"""