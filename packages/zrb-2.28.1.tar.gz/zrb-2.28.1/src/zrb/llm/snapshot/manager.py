"""Shadow-git snapshot manager for LLM rewind functionality.

Each snapshot is a git commit in an isolated shadow repository located at
``<snapshot_dir>/<safe_session_name>/``.  The shadow repo is completely
separate from the project's own git history.

Snapshot flow:
    1. Copy workdir → shadow dir (excluding .git trees)
    2. ``git add -A && git commit`` in shadow dir

Restore flow:
    1. ``git reset --hard <sha>`` in shadow dir
    2. Copy shadow dir → workdir (with deletion of files absent from snapshot)
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import subprocess
from typing import NamedTuple

logger = logging.getLogger(__name__)


class Snapshot(NamedTuple):
    sha: str
    timestamp: str
    label: str
    message_count: int | None = None


class SnapshotManager:
    """Manages filesystem snapshots using a shadow git repository."""

    # Directories that are large, regenerable, and almost never contain
    # hand-edited content. Skipping them turns a multi-second copy on big
    # projects into a sub-second one. Applied symmetrically to backup and
    # restore — entries here are never copied, never deleted by restore.
    DEFAULT_IGNORE_DIRS: frozenset[str] = frozenset(
        {
            # Python
            ".venv",
            "venv",
            "__pycache__",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            ".tox",
            ".eggs",
            # Node / JS
            "node_modules",
            ".next",
            ".nuxt",
            ".turbo",
            ".parcel-cache",
            # Generic caches
            ".cache",
        }
    )

    def __init__(
        self,
        snapshot_dir: str,
        session_name: str,
        workdir: str,
        ignore_dirs: "frozenset[str] | set[str] | None" = None,
    ):
        self._workdir = os.path.abspath(workdir)
        self._shadow_dir = os.path.join(snapshot_dir, _safe_name(session_name))
        self._initialized = False
        self._ignore_dirs: frozenset[str] = (
            self.DEFAULT_IGNORE_DIRS if ignore_dirs is None else frozenset(ignore_dirs)
        )

    async def take_snapshot(
        self, label: str, message_count: int | None = None
    ) -> str | None:
        """Sync workdir → shadow dir and commit.  Returns commit SHA or None on error.

        Args:
            label: Human-readable label (typically the user message).
            message_count: Number of conversation messages at this point.  When
                provided it is embedded in the commit message so that restore can
                also rewind the conversation history to a consistent state.
        """
        try:
            self._ensure_initialized()
            await asyncio.to_thread(
                _sync_dirs,
                self._workdir,
                self._shadow_dir,
                True,
                True,
                self._ignore_dirs,
                True,  # incremental: workdir → shadow, dst-newer means unchanged
            )
            commit_msg = _build_commit_message(label, message_count)
            # Force an empty commit when message_count advanced but files didn't
            # change (e.g. after a rewind followed by turns that don't touch the FS).
            # Without this, the stale mc from the previous HEAD would be used on
            # restore, truncating conversation history to the wrong point.
            force_empty = (
                message_count is not None
                and _head_mc(self._shadow_dir) != message_count
            )
            return await asyncio.to_thread(self._commit, commit_msg, force_empty)
        except Exception as e:
            logger.warning(f"Snapshot failed: {e}")
            return None

    async def take_init_snapshot(self) -> str | None:
        """Take an empty baseline snapshot at session start.

        Always creates a commit (even if workdir is empty) so that
        list_snapshots() always has at least one entry to rewind to.
        """
        try:
            self._ensure_initialized()
            # Only create init snapshot if the repo has no commits yet
            existing_sha = _head_sha(self._shadow_dir)
            if existing_sha is not None:
                return existing_sha
            await asyncio.to_thread(
                _sync_dirs,
                self._workdir,
                self._shadow_dir,
                True,
                True,
                self._ignore_dirs,
                True,  # incremental: workdir → shadow
            )
            commit_msg = _build_commit_message("init", message_count=0)
            return await asyncio.to_thread(
                self._commit, commit_msg, True  # allow_empty
            )
        except Exception as e:
            logger.warning(f"Init snapshot failed: {e}")
            return None

    def list_snapshots(self) -> list[Snapshot]:
        """Return snapshots in reverse chronological order (newest first)."""
        try:
            self._ensure_initialized()
            result = subprocess.run(
                ["git", "log", "--format=%H|%ai|%s", "--no-merges"],
                cwd=self._shadow_dir,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                return []
            snapshots: list[Snapshot] = []
            for line in result.stdout.strip().splitlines():
                if not line.strip():
                    continue
                parts = line.split("|", 2)
                if len(parts) == 3:
                    raw_label = parts[2]
                    label, message_count = _parse_commit_message(raw_label)
                    snapshots.append(
                        Snapshot(
                            sha=parts[0],
                            timestamp=parts[1],
                            label=label,
                            message_count=message_count,
                        )
                    )
            return snapshots
        except Exception as e:
            logger.warning(f"list_snapshots failed: {e}")
            return []

    async def restore_snapshot(self, sha: str) -> bool:
        """Restore workdir to the state captured at the given snapshot SHA."""
        try:
            self._ensure_initialized()
            await asyncio.to_thread(_git, self._shadow_dir, ["reset", "--hard", sha])
            await asyncio.to_thread(
                _sync_dirs,
                self._shadow_dir,
                self._workdir,
                True,
                True,
                self._ignore_dirs,
            )
            return True
        except Exception as e:
            logger.warning(f"restore_snapshot failed: {e}")
            return False

    def _ensure_initialized(self):
        if self._initialized:
            return
        os.makedirs(self._shadow_dir, exist_ok=True)
        if not os.path.isdir(os.path.join(self._shadow_dir, ".git")):
            _git(self._shadow_dir, ["init"])
            _git(self._shadow_dir, ["config", "user.email", "zrb-snapshot@local"])
            _git(self._shadow_dir, ["config", "user.name", "zrb-snapshot"])
        self._initialized = True

    def _commit(self, commit_msg: str, allow_empty: bool = False) -> str | None:
        _git(self._shadow_dir, ["add", "-A"])
        result = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=self._shadow_dir,
            capture_output=True,
        )
        if result.returncode == 0:
            if allow_empty:
                _git(
                    self._shadow_dir,
                    ["commit", "--allow-empty", "-m", commit_msg],
                )
                return _head_sha(self._shadow_dir)
            # Nothing new to commit — return current HEAD sha if any
            return _head_sha(self._shadow_dir)
        _git(self._shadow_dir, ["commit", "-m", commit_msg])
        return _head_sha(self._shadow_dir)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_MC_TAG = "[mc:"  # message-count tag embedded in commit messages


def _build_commit_message(label: str, message_count: int | None) -> str:
    if message_count is None:
        return label
    return f"{label} {_MC_TAG}{message_count}]"


def _parse_commit_message(raw: str) -> tuple[str, int | None]:
    """Return (human_label, message_count).  message_count is None if not present."""

    m = re.search(r"\[mc:(\d+)\]$", raw)
    if m:
        return raw[: m.start()].rstrip(), int(m.group(1))
    return raw, None


def _safe_name(name: str) -> str:
    """Convert an arbitrary session name to a filesystem-safe directory name."""
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in name)


def _head_mc(git_dir: str) -> int | None:
    """Return the message_count embedded in the HEAD commit message, or None."""
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--format=%s"],
            cwd=git_dir,
            capture_output=True,
            text=True,
            check=True,
        )
        _, mc = _parse_commit_message(result.stdout.strip())
        return mc
    except Exception:
        return None


def _head_sha(git_dir: str) -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=git_dir,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except Exception:
        return None


def _git(cwd: str, args: list[str]):
    subprocess.run(["git"] + args, cwd=cwd, check=True, capture_output=True)


def _prune_walk(dirs: list[str], exclude_git: bool, ignored: frozenset[str]) -> None:
    """Remove ``.git`` and ignored directories from an ``os.walk`` *dirs* list in-place."""
    if exclude_git and ".git" in dirs:
        dirs.remove(".git")
    if ignored:
        dirs[:] = [d for d in dirs if d not in ignored]


def _copy_files(
    src: str,
    dst: str,
    exclude_git: bool,
    ignored: frozenset[str],
    src_rel_paths: set[str],
    incremental: bool = False,
) -> None:
    """Copy all non-ignored files from *src* to *dst*, recording relative paths.

    When *incremental* is True and the destination file already matches the
    source by size and mtime, ``shutil.copy2`` is skipped. ``copy2`` preserves
    source mtime, so the comparison is stable across runs. This is only sound
    when copying from a canonical source to a cache (snapshot direction). On
    the restore path, *incremental* MUST be False — dst-newer there means the
    user edited a file after the snapshot, and the restore is exactly the
    operation that must undo those edits.
    """
    for root, dirs, files in os.walk(src):
        _prune_walk(dirs, exclude_git, ignored)
        rel_root = os.path.relpath(root, src)
        for fname in files:
            src_path = os.path.join(root, fname)
            try:
                src_stat = os.stat(src_path)
            except OSError:
                continue
            if not _stat_is_file(src_stat):
                continue
            rel_path = fname if rel_root == "." else os.path.join(rel_root, fname)
            dst_path = os.path.join(dst, rel_path)
            src_rel_paths.add(rel_path)
            if incremental and _dst_is_up_to_date(dst_path, src_stat):
                continue
            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
            shutil.copy2(src_path, dst_path)


def _stat_is_file(st: os.stat_result) -> bool:
    import stat as _stat

    return _stat.S_ISREG(st.st_mode)


def _dst_is_up_to_date(dst_path: str, src_stat: os.stat_result) -> bool:
    """Return True when *dst_path* exists and is at least as new as *src_stat*.

    Same-size + mtime≥src guards against the common case (file unchanged) and
    against editors that touch mtime without changing content. A pessimistic
    miss just means we copy when we didn't have to — never the wrong content.
    """
    try:
        dst_stat = os.stat(dst_path)
    except OSError:
        return False
    if dst_stat.st_size != src_stat.st_size:
        return False
    return dst_stat.st_mtime >= src_stat.st_mtime


def _collect_pruned_rel_paths(
    root_dir: str, exclude_git: bool, ignored: frozenset[str]
) -> set[str]:
    """Walk *root_dir* (skipping .git and ignored dirs) and return relative file paths."""
    paths: set[str] = set()
    for root, dirs, files in os.walk(root_dir):
        _prune_walk(dirs, exclude_git, ignored)
        rel_root = os.path.relpath(root, root_dir)
        for fname in files:
            rel_path = fname if rel_root == "." else os.path.join(rel_root, fname)
            paths.add(rel_path)
    return paths


def _remove_stale_files(dst: str, stale_paths: set[str]) -> None:
    """Remove files in *stale_paths* from *dst* (silently ignoring OSError)."""
    for rel_path in stale_paths:
        try:
            os.remove(os.path.join(dst, rel_path))
        except OSError:
            pass


def _remove_empty_dirs(
    root_dir: str, exclude_git: bool, ignored: frozenset[str]
) -> None:
    """Remove empty directories bottom-up, skipping .git and ignored trees."""
    for root, dirs, files in os.walk(root_dir, topdown=False):
        if root == root_dir:
            continue
        rel = os.path.relpath(root, root_dir)
        rel_parts = rel.split(os.sep)
        if exclude_git and ".git" in rel_parts:
            continue
        if ignored and any(part in ignored for part in rel_parts):
            continue
        try:
            if not os.listdir(root):
                os.rmdir(root)
        except OSError:
            pass


def _sync_dirs(
    src: str,
    dst: str,
    exclude_git: bool = True,
    delete: bool = False,
    ignore_dirs: "frozenset[str] | None" = None,
    incremental: bool = False,
) -> None:
    """Recursively copy *src* into *dst*, optionally deleting stale dst files.

    Args:
        src: Source directory path.
        dst: Destination directory path.
        exclude_git: When True, ``.git`` subtrees are skipped in both directions.
        delete: When True, files present in *dst* but absent from *src* are removed.
        ignore_dirs: Directory basenames to skip in both walks. Entries are
            never copied from src and never deleted from dst — keeping
            regenerable trees like ``node_modules`` out of the snapshot
            without restore wiping them from the user's workdir.
        incremental: When True, skip per-file copies whose dst already matches
            the src by size and mtime. Only safe in the **workdir → shadow**
            direction (take_snapshot): there, dst-newer-than-src means shadow
            already has the current version. In the **shadow → workdir**
            direction (restore_snapshot), dst-newer means the user modified
            after the snapshot — that file *must* be overwritten — so this
            flag must remain False on restore.
    """
    os.makedirs(dst, exist_ok=True)
    ignored: frozenset[str] = ignore_dirs or frozenset()
    src_rel_paths: set[str] = set()

    _copy_files(src, dst, exclude_git, ignored, src_rel_paths, incremental)

    if not delete:
        return

    dst_rel_paths = _collect_pruned_rel_paths(dst, exclude_git, ignored)
    _remove_stale_files(dst, dst_rel_paths - src_rel_paths)
    _remove_empty_dirs(dst, exclude_git, ignored)
