"""Helpers for the sanctioned local AlloyDB Auth Proxy lane."""

from __future__ import annotations

import os
import shutil
import socket
import subprocess
import time
from pathlib import Path

from infra.settings import Settings


def _default_proxy_binary() -> str | None:
    """Return the preferred AlloyDB Auth Proxy binary path if available."""

    on_path = shutil.which("alloydb-auth-proxy")
    if on_path:
        return on_path
    local_bin = Path.home() / ".local" / "bin" / "alloydb-auth-proxy"
    if local_bin.is_file():
        return str(local_bin)
    return None


def proxy_is_listening(*, host: str, port: int) -> bool:
    """Return True when a TCP listener is already present on the proxy endpoint."""

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.25)
        return sock.connect_ex((host, port)) == 0


def ensure_alloydb_auth_proxy(
    *,
    settings: Settings,
    target_service_account: str,
) -> None:
    """Start the sanctioned AlloyDB Auth Proxy if it is not already running.

    The engineer DB lane should use one explicit transport path across CLI,
    `psql`, and desktop tools. If the proxy is already listening, leave it
    alone. Otherwise start it in the background and wait briefly for the port
    to come up.
    """

    if not settings.effective_use_alloydb_auth_proxy:
        return

    host = settings.alloydb_auth_proxy_host
    port = settings.effective_alloydb_auth_proxy_port
    if proxy_is_listening(host=host, port=port):
        return

    proxy_binary = _default_proxy_binary()
    if proxy_binary is None:
        raise RuntimeError(
            "alloydb-auth-proxy is not installed. Re-run ./scripts/setup/setup.py to provision "
            "the canonical local DB transport."
        )

    if not settings.alloydb_instance_uri:
        raise RuntimeError(
            "AlloyDB instance URI is not configured, so the local Auth Proxy cannot start."
        )

    command = [
        proxy_binary,
        settings.alloydb_instance_uri,
        "--address",
        host,
        "--port",
        str(port),
        "--auto-iam-authn",
        f"--impersonate-service-account={target_service_account}",
        "--disable-built-in-telemetry",
    ]
    if not settings.use_private_ip:
        command.append("--public-ip")

    subprocess.Popen(
        command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        env=os.environ.copy(),
    )

    deadline = time.monotonic() + 10.0
    while time.monotonic() < deadline:
        if proxy_is_listening(host=host, port=port):
            return
        time.sleep(0.25)

    raise RuntimeError(
        f"Timed out waiting for alloydb-auth-proxy on {host}:{port}. "
        "Run `uv run buildai dev db info` to inspect the expected proxy recipe."
    )
