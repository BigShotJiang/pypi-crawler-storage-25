"""Direct SQL query command for the simplified DB surface."""

from __future__ import annotations

import asyncio
import re

import typer
from infra.settings import Settings
from typing_extensions import Annotated

from cli.console import console, dim, error, show_sql, warning
from cli.context import get_inspection_connection
from cli.output import Format, format_option, output

QUERY_HINTS = {
    "public._migrations": "Tip: Use 'buildai db migrate' to inspect migration state.",
    "core.clips": None,
}


def _show_query_hints(sql: str) -> None:
    """Show the remaining high-signal hints when queries touch known tables."""

    sql_lower = sql.lower()
    shown = set()

    for table_pattern, hint in QUERY_HINTS.items():
        if hint and table_pattern.lower() in sql_lower and hint not in shown:
            dim(f"\n{hint}")
            shown.add(hint)


def _normalize_sql(sql: str) -> str:
    """Normalize SQL for light-weight statement analysis."""

    normalized = re.sub(r"--.*$", "", sql, flags=re.MULTILINE)
    normalized = re.sub(r"/\*.*?\*/", "", normalized, flags=re.DOTALL)
    return " ".join(normalized.split()).upper()


def _is_write_query(sql: str) -> bool:
    """Return whether the SQL mutates database state."""

    import sqlparse

    write_types = {
        "INSERT",
        "UPDATE",
        "DELETE",
        "DROP",
        "CREATE",
        "ALTER",
        "TRUNCATE",
        "GRANT",
        "REVOKE",
    }

    statements = sqlparse.parse(sql)
    for stmt in statements:
        stmt_type = stmt.get_type()
        if stmt_type and stmt_type.upper() in write_types:
            return True

    normalized = _normalize_sql(sql)
    for keyword in ("VACUUM", "REASSIGN"):
        if normalized.startswith(keyword + " ") or normalized == keyword:
            return True
    return False


def _is_ddl_query(sql: str) -> bool:
    """Return whether the SQL changes schema or ownership state."""

    import sqlparse

    ddl_types = {
        "DROP",
        "CREATE",
        "ALTER",
        "TRUNCATE",
        "GRANT",
        "REVOKE",
    }

    statements = sqlparse.parse(sql)
    for stmt in statements:
        stmt_type = stmt.get_type()
        if stmt_type and stmt_type.upper() in ddl_types:
            return True

    normalized = _normalize_sql(sql)
    return normalized.startswith("REASSIGN ") or normalized == "REASSIGN"


def _is_select_query(sql: str) -> bool:
    """Return whether the SQL is a row-returning query."""

    normalized = _normalize_sql(sql)
    if normalized.startswith("SELECT "):
        return True
    if normalized.startswith("WITH "):
        for keyword in ("INSERT", "UPDATE", "DELETE"):
            if f" {keyword} " in normalized:
                return False
        return True
    return any(normalized.startswith(keyword) for keyword in ("SHOW ", "EXPLAIN ", "TABLE "))


def query(
    ctx: typer.Context,
    sql: Annotated[str, typer.Argument(help="SQL query to execute")],
    format: Format = format_option(),
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation for write queries"),
    ] = False,
    write: Annotated[
        bool,
        typer.Option("--write", help="Allow write queries (requires internal_admin profile)"),
    ] = False,
) -> None:
    """Execute SQL against the selected database lane in inspection mode."""

    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        is_write = _is_write_query(sql)
        is_ddl = _is_ddl_query(sql)
        cli_profile = (ctx.obj or {}).get("cli_profile", "internal_viewer")

        if is_write and not write:
            error("Write query blocked. Re-run with --write and an internal_admin profile.")
            raise typer.Exit(1)

        if is_write and cli_profile != "internal_admin":
            error("Write query requires --profile internal_admin.")
            raise typer.Exit(1)

        if settings.is_production and is_ddl:
            error(
                "Production DDL is blocked in 'buildai db query'. "
                "Use 'buildai db migrate ...' or dedicated ops tooling."
            )
            raise typer.Exit(1)

        if settings.is_production and is_write and not yes:
            warning("WRITE operation to PRODUCTION database")
            console.print(f"  Database: [bold red]{settings.db_name}[/bold red]")
            preview = sql[:100] + ("..." if len(sql) > 100 else "")
            console.print(f"  Query: [dim]{preview}[/dim]")
            console.print()
            if not typer.confirm("Execute this write query?", default=False):
                console.print("[dim]Aborted.[/dim]")
                raise typer.Exit(0)
            console.print()

        show_sql(sql)

        async with get_inspection_connection(settings) as conn:
            try:
                if _is_select_query(sql):
                    result = await conn.fetch(sql)
                    rows = [dict(row) for row in result]
                    columns = list(result[0].keys()) if result else []
                    output(rows, format=format, columns=columns)
                else:
                    status = await conn.execute(sql)
                    console.print(f"[green]✓[/green] {status}")

                _show_query_hints(sql)
            except Exception as exc:
                error(f"Query failed: {exc}")
                err_str = str(exc).lower()
                if "permission denied" in err_str:
                    console.print(
                        "[dim]Hint: You may need GRANT <role> TO your_user to perform this action[/dim]"
                    )
                elif "does not exist" in err_str:
                    console.print(
                        "[dim]Hint: Check if the object or role name is correct and quoted properly[/dim]"
                    )
                elif "cannot be dropped" in err_str:
                    console.print(
                        '[dim]Hint: Use DROP OWNED BY "user" CASCADE first to remove dependencies[/dim]'
                    )
                raise typer.Exit(1)

    asyncio.run(run())
