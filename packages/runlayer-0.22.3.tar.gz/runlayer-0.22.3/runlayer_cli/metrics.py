from __future__ import annotations

from typing import Literal, Protocol, TypedDict

import anyio.to_thread
import httpx
import structlog

logger = structlog.get_logger(__name__)


class InstallationAnalyticsEvent(TypedDict):
    resource_type: Literal["plugin", "skill"]
    resource_id: str
    client_name: str
    install_scope: Literal["project", "global"]
    install_mode: str | None


class InstallationMetricsClient(Protocol):
    def track_installation_events(
        self, events: list[InstallationAnalyticsEvent]
    ) -> object: ...


def build_plugin_install_event(
    *,
    resource_id: str,
    client_name: str,
    install_scope: Literal["project", "global"],
    install_mode: str | None,
) -> InstallationAnalyticsEvent:
    return {
        "resource_type": "plugin",
        "resource_id": resource_id,
        "client_name": client_name,
        "install_scope": install_scope,
        "install_mode": install_mode,
    }


def build_skill_install_event(
    *,
    resource_id: str,
    client_name: str,
    install_scope: Literal["project", "global"],
    install_mode: str | None = "native",
) -> InstallationAnalyticsEvent:
    return {
        "resource_type": "skill",
        "resource_id": resource_id,
        "client_name": client_name,
        "install_scope": install_scope,
        "install_mode": install_mode,
    }


async def flush_installation_events(
    *,
    client: InstallationMetricsClient,
    events: list[InstallationAnalyticsEvent],
) -> None:
    if not events:
        return

    try:
        await anyio.to_thread.run_sync(client.track_installation_events, events)
    except httpx.HTTPError:
        logger.warning(
            "install_metrics_flush_failed",
            installed=len(events),
            exc_info=True,
        )
