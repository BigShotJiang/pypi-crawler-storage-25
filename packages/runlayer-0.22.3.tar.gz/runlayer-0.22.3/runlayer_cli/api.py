import datetime
import time
from typing import Any

import httpx
from pydantic import BaseModel
import typer

from runlayer_cli.metrics import InstallationAnalyticsEvent
from runlayer_cli.symbols import FAIL

from runlayer_cli.models import (
    ServerDetails,
    LocalCapabilities,
    PreRequest,
    PostRequest,
)

USER_AGENT = "Runlayer CLI"
API_KEY_HEADER_NAME = "x-runlayer-api-key"
_SKILL_API_TIMEOUT = 30.0
_PLUGIN_API_TIMEOUT = 30.0
_PLUGIN_READ_RETRIES = 1
_PLUGIN_READ_RETRY_SLEEP_SECONDS = 0.25
_AUDIT_LOG_TIMEOUT = 30.0


class ServerListItem(BaseModel):
    """Minimal server info for listing."""

    id: str
    name: str
    description: str | None = None
    status: str
    icon_url: str | None = None
    is_official: bool = False
    deployment_mode: str | None = None


class PluginListItem(BaseModel):
    """Minimal plugin info for listing."""

    id: str
    name: str
    path: str | None = None
    description: str | None = None
    is_public: bool = False
    namespace: str | None = None
    is_owned_by_me: bool = False
    server_count: int = 0
    tool_count: int = 0
    skill_count: int = 0


class PluginServerRef(BaseModel):
    server_id: str
    tool_names: list[str] = []


class ServerToolItem(BaseModel):
    name: str
    description: str | None = None


class PluginSkillRef(BaseModel):
    id: str
    name: str
    description: str | None = None
    is_public: bool = False
    file_count: int = 0


class PluginDetail(PluginListItem):
    use_dynamic_tools: bool = False
    identifier: str | None = None
    can_edit: bool = False
    skills: list[PluginSkillRef] = []
    servers: list[dict[str, Any]] = []
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class DeploymentPublic(BaseModel):
    """Public deployment model matching backend schema."""

    id: str
    name: str
    configuration: dict[str, Any]
    deployment_outputs: dict[str, Any] | None = None
    created_at: datetime.datetime
    updated_at: datetime.datetime
    template_yaml: str | None = None  # Always present for new deployments
    deletion_status: str | None = None  # "deleted", "deleting", or None (active)
    connected_servers: list[dict[str, Any]] = []  # List of connected MCP servers


class ValidateYAMLResponse(BaseModel):
    """Response from YAML validation endpoint."""

    valid: bool
    error: str | None = None
    parsed_config: dict[str, Any] | None = None


class ECRCredentials(BaseModel):
    """ECR credentials response."""

    username: str
    password: str
    registry_url: str
    repository_url: str
    expires_at: datetime.datetime


class DeploymentTriggerResponse(BaseModel):
    """Deployment trigger response."""

    deployment_id: str
    request_id: str
    status: str
    history_id: str


class RunlayerClient:
    def __init__(self, hostname: str, secret: str):
        self.headers = {
            "User-Agent": USER_AGENT,
            API_KEY_HEADER_NAME: secret,
        }
        self.base_url = hostname

    def _handle_deployment_response(self, response: httpx.Response) -> None:
        """
        Handle deployment API response and provide user-friendly error messages.

        Args:
            response: HTTP response from deployment endpoint

        Raises:
            typer.Exit: If deployment feature is not available (404)
            httpx.HTTPStatusError: For other HTTP errors
        """
        if response.status_code == 404:
            try:
                error_data = response.json()
                if "Deployment feature not available" in error_data.get("detail", ""):
                    typer.secho(
                        f"\n{FAIL} Deployment feature is not enabled on this Runlayer instance.",
                        fg=typer.colors.RED,
                        bold=True,
                        err=True,
                    )
                    typer.echo(
                        "Please contact your administrator to enable deployment support.",
                        err=True,
                    )
                    raise typer.Exit(1)
            except (ValueError, KeyError):
                pass

        response.raise_for_status()

    def get_server_details(self, server_id: str) -> ServerDetails:
        with httpx.Client(headers=self.headers) as client:
            response = client.get(f"{self.base_url}/api/v1/local/{server_id}")
            response.raise_for_status()
            return ServerDetails.model_validate(response.json())

    def _get_with_retries(
        self,
        client: httpx.Client,
        url: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> httpx.Response:
        attempts = _PLUGIN_READ_RETRIES + 1
        last_error: httpx.RequestError | None = None
        for attempt in range(attempts):
            try:
                return client.get(url, params=params)
            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                last_error = exc
                if attempt == attempts - 1:
                    raise
                time.sleep(_PLUGIN_READ_RETRY_SLEEP_SECONDS)
        assert last_error is not None
        raise last_error

    def update_capabilities(self, server_id: str, capabilities: LocalCapabilities):
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/local/{server_id}/capabilities",
                json=capabilities.model_dump(mode="json"),
            )
            return response

    def pre(self, server_id: str, request: PreRequest) -> httpx.Response:
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/local/{server_id}/pre",
                json=request.model_dump(),
            )
            return response

    def post(self, server_id: str, request: PostRequest) -> httpx.Response:
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/local/{server_id}/post",
                json=request.model_dump(),
            )
            return response

    def get_deployment(self, deployment_id: str) -> DeploymentPublic:
        """Get a deployment by ID."""
        with httpx.Client(headers=self.headers) as client:
            response = client.get(
                f"{self.base_url}/api/v1/deployments/{deployment_id}",
            )
            self._handle_deployment_response(response)
            return DeploymentPublic.model_validate(response.json())

    def create_deployment(self, name: str) -> DeploymentPublic:
        """
        Create a new deployment with just a name.

        The backend always generates and returns a default template YAML.

        Args:
            name: Deployment name

        Returns:
            DeploymentPublic with template_yaml field
        """
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/deployments/",
                json={"name": name},
            )
            self._handle_deployment_response(response)
            return DeploymentPublic.model_validate(response.json())

    def update_deployment(
        self,
        deployment_id: str,
        configuration: dict[str, Any] | None = None,
        yaml_content: str | None = None,
        docker_image: str | None = None,
    ) -> DeploymentPublic:
        """
        Update deployment configuration.

        Args:
            deployment_id: UUID of deployment
            configuration: Legacy configuration dict (deprecated, use yaml_content)
            yaml_content: Raw YAML string to send to backend for validation
            docker_image: Docker image URI (passed separately, not in YAML)

        Returns:
            Updated deployment

        Note: If yaml_content is provided, it takes precedence over configuration.
        """
        payload: dict[str, Any] = {}

        if configuration is not None:
            payload["configuration"] = configuration

        # Send yaml_content and docker_image in request body
        if yaml_content is not None:
            payload["yaml_content"] = yaml_content
        if docker_image is not None:
            payload["docker_image"] = docker_image

        with httpx.Client(headers=self.headers) as client:
            response = client.put(
                f"{self.base_url}/api/v1/deployments/{deployment_id}",
                json=payload,
            )
            self._handle_deployment_response(response)
            return DeploymentPublic.model_validate(response.json())

    def get_ecr_credentials(self) -> ECRCredentials:
        """Get temporary ECR credentials for pushing images."""
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/deployments/ecr-credentials",
            )
            self._handle_deployment_response(response)
            return ECRCredentials.model_validate(response.json())

    def trigger_deployment(self, deployment_id: str) -> DeploymentTriggerResponse:
        """Trigger a deployment."""
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/deployments/{deployment_id}/trigger",
            )
            self._handle_deployment_response(response)
            return DeploymentTriggerResponse.model_validate(response.json())

    def validate_yaml(self, yaml_content: str) -> ValidateYAMLResponse:
        """
        Validate YAML configuration without creating a deployment.

        This calls the backend validation endpoint to check the YAML structure.
        No local validation is performed - this is a pure pass-through to backend.

        Args:
            yaml_content: Raw YAML string to validate

        Returns:
            Validation result with any errors from backend
        """
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/deployments/validate-yaml",
                json={"yaml_content": yaml_content},
            )
            self._handle_deployment_response(response)
            return ValidateYAMLResponse.model_validate(response.json())

    def get_deployment_status(self, deployment_id: str) -> dict[str, Any]:
        """Get deployment status."""
        with httpx.Client(headers=self.headers) as client:
            response = client.get(
                f"{self.base_url}/api/v1/deployments/{deployment_id}/status",
            )
            self._handle_deployment_response(response)
            return response.json()

    def get_deployment_logs(self, history_id: str) -> str | None:
        """
        Get deployment logs for a specific history entry.

        Args:
            history_id: UUID of the deployment history entry

        Returns:
            Logs string or None if no logs available
        """
        with httpx.Client(headers=self.headers) as client:
            response = client.get(
                f"{self.base_url}/api/v1/deployments/history/{history_id}/logs",
            )
            self._handle_deployment_response(response)
            data = response.json()
            return data.get("logs")

    def get_deployment_history(
        self, deployment_id: str, limit: int = 100
    ) -> dict[str, Any]:
        """
        Get deployment history for a deployment.

        Args:
            deployment_id: UUID of the deployment
            limit: Maximum number of history entries to return

        Returns:
            Dictionary with 'data' (list of history entries) and 'count'
        """
        with httpx.Client(headers=self.headers) as client:
            response = client.get(
                f"{self.base_url}/api/v1/deployments/{deployment_id}/history",
                params={"limit": limit},
            )
            self._handle_deployment_response(response)
            return response.json()

    def delete_deployment(self, deployment_id: str) -> None:
        """
        Delete a deployment and trigger infrastructure destruction.

        Args:
            deployment_id: UUID of the deployment to delete

        Raises:
            typer.Exit: If deployment feature is not available or deletion fails
            httpx.HTTPStatusError: For other HTTP errors
        """
        with httpx.Client(headers=self.headers) as client:
            response = client.delete(
                f"{self.base_url}/api/v1/deployments/{deployment_id}",
            )
            self._handle_deployment_response(response)

    def export_deployment_yaml(self, deployment_id: str) -> str:
        """
        Export deployment configuration as YAML string.

        Args:
            deployment_id: UUID of the deployment to export

        Returns:
            YAML configuration string

        Raises:
            typer.Exit: If deployment feature is not available or export fails
            httpx.HTTPStatusError: For other HTTP errors
            ValueError: If the response is missing or contains empty yaml_content
        """
        with httpx.Client(headers=self.headers) as client:
            response = client.get(
                f"{self.base_url}/api/v1/deployments/{deployment_id}/export-yaml",
            )
            self._handle_deployment_response(response)
            data = response.json()
            yaml_content = data.get("yaml_content", "")
            if not yaml_content or not yaml_content.strip():
                raise ValueError(
                    "Server returned empty YAML content. "
                    "This may indicate an API response issue or schema mismatch."
                )
            return yaml_content

    def submit_mcp_watch_scan(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Submit MCP Watch scan results to the backend.

        Tries /api/v1/ai-watch/scan first, falls back to the legacy
        /api/v1/mcp-watch/scan path if the server hasn't been updated yet.
        Returns {"unsupported": True} only if both paths 404.
        """
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/ai-watch/scan",
                json=payload,
            )
            if response.status_code == 404:
                response = client.post(
                    f"{self.base_url}/api/v1/mcp-watch/scan",
                    json=payload,
                )
            if response.status_code == 404:
                return {"unsupported": True}
            response.raise_for_status()
            return response.json()

    def submit_skill_fingerprint(
        self,
        identifier: str,
        artifact_type: str,
        oversized: bool = False,
    ) -> dict[str, Any]:
        """Check if a skill fingerprint is already known by the backend.

        Tries /api/v1/ai-watch/ first, falls back to /api/v1/mcp-watch/.
        """
        body = {
            "identifier": identifier,
            "artifact_type": artifact_type,
            "oversized": oversized,
        }
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/ai-watch/skills/lookup",
                json=body,
            )
            if response.status_code == 404:
                response = client.post(
                    f"{self.base_url}/api/v1/mcp-watch/skills/lookup",
                    json=body,
                )
            if response.status_code == 404:
                return {"known": False, "unsupported": True}
            response.raise_for_status()
            return response.json()

    def submit_skill(self, skill_payload: dict[str, Any]) -> dict[str, Any]:
        """Submit a full skill for ingestion and scanning.

        Tries /api/v1/ai-watch/ first, falls back to /api/v1/mcp-watch/.
        """
        with httpx.Client(headers=self.headers, timeout=120) as client:
            response = client.post(
                f"{self.base_url}/api/v1/ai-watch/skills/submit",
                json=skill_payload,
            )
            if response.status_code == 404:
                response = client.post(
                    f"{self.base_url}/api/v1/mcp-watch/skills/submit",
                    json=skill_payload,
                )
            if response.status_code == 404:
                return {"skill_id": None, "created": False}
            response.raise_for_status()
            return response.json()

    def submit_plugin_fingerprint(
        self,
        identifier: str,
    ) -> dict[str, Any]:
        """Check if a plugin fingerprint is already known."""
        body = {
            "identifier": identifier,
        }
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/ai-watch/plugins/lookup",
                json=body,
            )
            if response.status_code == 404:
                response = client.post(
                    f"{self.base_url}/api/v1/mcp-watch/plugins/lookup",
                    json=body,
                )
            if response.status_code == 404:
                return {"known": False, "unsupported": True}
            response.raise_for_status()
            return response.json()

    def submit_plugin(self, plugin_payload: dict[str, Any]) -> dict[str, Any]:
        """Submit a full plugin for ingestion."""
        with httpx.Client(headers=self.headers, timeout=120) as client:
            response = client.post(
                f"{self.base_url}/api/v1/ai-watch/plugins/submit",
                json=plugin_payload,
            )
            if response.status_code == 404:
                response = client.post(
                    f"{self.base_url}/api/v1/mcp-watch/plugins/submit",
                    json=plugin_payload,
                )
            if response.status_code == 404:
                return {"plugin_id": None, "created": False}
            response.raise_for_status()
            return response.json()

    def list_servers(
        self,
        scope: str = "accessible",
        limit: int = 100,
    ) -> list[ServerListItem]:
        """
        List MCP servers the user has access to.

        Args:
            scope: "accessible" (default), "accessible_and_mine", "all", or "accessible_and_auto_sync"
            limit: Maximum number of servers to return

        Returns:
            List of ServerListItem objects

        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        params: dict[str, str | int] = {"scope": scope, "limit": limit}
        with httpx.Client(headers=self.headers) as client:
            response = client.get(
                f"{self.base_url}/api/v1/servers",
                params=params,
            )
            response.raise_for_status()
            data = response.json()
            return [ServerListItem.model_validate(s) for s in data.get("data", [])]

    def list_plugins(self, limit: int = 100) -> list[PluginListItem]:
        """
        List plugins the user has access to.

        Args:
            limit: Maximum number of plugins to return

        Returns:
            List of PluginListItem objects

        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        with httpx.Client(headers=self.headers, timeout=_PLUGIN_API_TIMEOUT) as client:
            response = self._get_with_retries(
                client,
                f"{self.base_url}/api/v1/plugins",
                params={"limit": limit},
            )
            response.raise_for_status()
            data = response.json()
            return [PluginListItem.model_validate(p) for p in data.get("data", [])]

    def _list_plugins_paginated(
        self, *, namespace: str | None, mine_only: bool
    ) -> list["PluginDetail"]:
        all_plugins: list[PluginDetail] = []
        skip = 0
        with httpx.Client(headers=self.headers, timeout=_PLUGIN_API_TIMEOUT) as client:
            while True:
                params: dict[str, str | int | bool] = {
                    "mine_only": mine_only,
                    "limit": 100,
                    "skip": skip,
                }
                if namespace is not None:
                    params["namespace"] = namespace
                response = self._get_with_retries(
                    client,
                    f"{self.base_url}/api/v1/plugins",
                    params=params,
                )
                response.raise_for_status()
                page = [
                    PluginDetail.model_validate(p)
                    for p in response.json().get("data", [])
                ]
                all_plugins.extend(page)
                if len(page) < 100:
                    break
                skip += len(page)
        return all_plugins

    def list_all_plugins(self, *, mine_only: bool = False) -> list["PluginDetail"]:
        return self._list_plugins_paginated(namespace=None, mine_only=mine_only)

    def list_plugins_by_namespace(self, namespace: str) -> list["PluginDetail"]:
        return self._list_plugins_paginated(namespace=namespace, mine_only=True)

    def create_plugin(
        self,
        name: str,
        namespace: str,
        path: str,
        description: str | None,
        is_public: bool,
        use_dynamic_tools: bool,
        servers: list[PluginServerRef],
        skill_ids: list[str],
        identifier: str | None = None,
    ) -> "PluginDetail":
        payload: dict[str, Any] = {
            "name": name,
            "namespace": namespace,
            "path": path,
            "is_public": is_public,
            "use_dynamic_tools": use_dynamic_tools,
            "servers": [server.model_dump() for server in servers],
            "skill_ids": skill_ids,
        }
        if description is not None:
            payload["description"] = description
        if identifier is not None:
            payload["identifier"] = identifier
        with httpx.Client(headers=self.headers, timeout=_PLUGIN_API_TIMEOUT) as client:
            response = client.post(f"{self.base_url}/api/v1/plugins", json=payload)
            response.raise_for_status()
            return PluginDetail.model_validate(response.json())

    def update_plugin(
        self,
        plugin_id: str,
        name: str,
        namespace: str,
        path: str,
        description: str | None,
        is_public: bool,
        use_dynamic_tools: bool,
        servers: list[PluginServerRef],
        skill_ids: list[str],
        identifier: str | None = None,
    ) -> "PluginDetail":
        payload: dict[str, Any] = {
            "name": name,
            "namespace": namespace,
            "path": path,
            "description": description,
            "is_public": is_public,
            "use_dynamic_tools": use_dynamic_tools,
            "servers": [server.model_dump() for server in servers],
            "skill_ids": skill_ids,
        }
        if identifier is not None:
            payload["identifier"] = identifier
        with httpx.Client(headers=self.headers, timeout=_PLUGIN_API_TIMEOUT) as client:
            response = client.put(
                f"{self.base_url}/api/v1/plugins/{plugin_id}",
                json=payload,
            )
            response.raise_for_status()
            return PluginDetail.model_validate(response.json())

    def get_plugin(self, plugin_id: str) -> "PluginDetail":
        with httpx.Client(headers=self.headers, timeout=_PLUGIN_API_TIMEOUT) as client:
            response = client.get(f"{self.base_url}/api/v1/plugins/{plugin_id}")
            response.raise_for_status()
            return PluginDetail.model_validate(response.json())

    def delete_plugin(self, plugin_id: str) -> None:
        with httpx.Client(headers=self.headers, timeout=_PLUGIN_API_TIMEOUT) as client:
            response = client.delete(f"{self.base_url}/api/v1/plugins/{plugin_id}")
            response.raise_for_status()

    def list_servers_for_resolution(self) -> list[ServerListItem]:
        all_servers: list[ServerListItem] = []
        skip = 0
        with httpx.Client(headers=self.headers, timeout=_PLUGIN_API_TIMEOUT) as client:
            while True:
                response = self._get_with_retries(
                    client,
                    f"{self.base_url}/api/v1/servers",
                    params={
                        "scope": "accessible",
                        "limit": 100,
                        "skip": skip,
                    },
                )
                response.raise_for_status()
                page = [
                    ServerListItem.model_validate(s)
                    for s in response.json().get("data", [])
                ]
                all_servers.extend(page)
                if len(page) < 100:
                    break
                skip += len(page)
        return all_servers

    def list_server_tools(self, server_id: str) -> list[ServerToolItem]:
        with httpx.Client(headers=self.headers, timeout=_PLUGIN_API_TIMEOUT) as client:
            response = self._get_with_retries(
                client,
                f"{self.base_url}/api/v1/proxy/{server_id}/tools",
            )
            response.raise_for_status()
            return [ServerToolItem.model_validate(tool) for tool in response.json()]

    def list_skills(
        self,
        namespace: str,
        mine_only: bool = True,
    ) -> list["SkillDetail"]:
        return self._list_skills_paginated(namespace=namespace, mine_only=mine_only)

    def list_all_skills(
        self,
        mine_only: bool = False,
    ) -> list["SkillDetail"]:
        return self._list_skills_paginated(namespace=None, mine_only=mine_only)

    def _list_skills_paginated(
        self,
        namespace: str | None,
        mine_only: bool,
    ) -> list["SkillDetail"]:
        all_skills: list[SkillDetail] = []
        skip = 0
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            while True:
                params: dict[str, str | int | bool] = {
                    "mine_only": mine_only,
                    "limit": 100,
                    "skip": skip,
                }
                if namespace is not None:
                    params["namespace"] = namespace
                response = client.get(f"{self.base_url}/api/v1/skills", params=params)
                response.raise_for_status()
                page = [
                    SkillDetail.model_validate(s)
                    for s in response.json().get("data", [])
                ]
                all_skills.extend(page)
                if len(page) < 100:
                    break
                skip += len(page)
        return all_skills

    def create_skill(
        self,
        name: str,
        description: str | None = None,
        is_public: bool = False,
        namespace: str | None = None,
        path: str | None = None,
    ) -> "SkillDetail":
        payload: dict[str, Any] = {"name": name, "is_public": is_public}
        if description is not None:
            payload["description"] = description
        if namespace is not None:
            payload["namespace"] = namespace
        if path is not None:
            payload["path"] = path
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.post(f"{self.base_url}/api/v1/skills", json=payload)
            response.raise_for_status()
            return SkillDetail.model_validate(response.json())

    def score_skill(
        self,
        skill_name: str,
        files: list[dict[str, str]],
    ) -> "SkillScanResponse":
        payload = {
            "skill_name": skill_name,
            "files": files,
        }
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.post(
                f"{self.base_url}/api/v1/security/score/skill",
                json=payload,
            )
            response.raise_for_status()
            return SkillScanResponse.model_validate(response.json())

    def get_skill(self, skill_id: str) -> "SkillDetail":
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.get(f"{self.base_url}/api/v1/skills/{skill_id}")
            response.raise_for_status()
            return SkillDetail.model_validate(response.json())

    def update_skill(
        self,
        skill_id: str,
        name: str,
        description: str | None,
        is_public: bool | None = None,
    ) -> "SkillDetail":
        payload: dict[str, Any] = {"name": name, "description": description}
        if is_public is not None:
            payload["is_public"] = is_public
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.put(
                f"{self.base_url}/api/v1/skills/{skill_id}", json=payload
            )
            response.raise_for_status()
            return SkillDetail.model_validate(response.json())

    def create_skill_file(
        self,
        skill_id: str,
        title: str,
        content: str,
        description: str | None = None,
    ) -> "SkillFileDetail":
        payload: dict[str, Any] = {"title": title, "content": content}
        if description is not None:
            payload["description"] = description
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.post(
                f"{self.base_url}/api/v1/skills/{skill_id}/files", json=payload
            )
            response.raise_for_status()
            return SkillFileDetail.model_validate(response.json())

    def get_skill_file(self, skill_id: str, file_id: str) -> "SkillFileDetail":
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.get(
                f"{self.base_url}/api/v1/skills/{skill_id}/files/{file_id}"
            )
            response.raise_for_status()
            return SkillFileDetail.model_validate(response.json())

    def update_skill_file(
        self,
        skill_id: str,
        file_id: str,
        title: str | None = None,
        content: str | None = None,
        description: str | None = None,
    ) -> "SkillFileDetail":
        payload: dict[str, Any] = {}
        if title is not None:
            payload["title"] = title
        if content is not None:
            payload["content"] = content
        if description is not None:
            payload["description"] = description
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.put(
                f"{self.base_url}/api/v1/skills/{skill_id}/files/{file_id}",
                json=payload,
            )
            response.raise_for_status()
            return SkillFileDetail.model_validate(response.json())

    def delete_skill(self, skill_id: str) -> None:
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.delete(f"{self.base_url}/api/v1/skills/{skill_id}")
            response.raise_for_status()

    def delete_skill_file(self, skill_id: str, file_id: str) -> None:
        with httpx.Client(headers=self.headers, timeout=_SKILL_API_TIMEOUT) as client:
            response = client.delete(
                f"{self.base_url}/api/v1/skills/{skill_id}/files/{file_id}"
            )
            response.raise_for_status()

    def get_current_user(self) -> dict[str, Any]:
        with httpx.Client(headers=self.headers) as client:
            response = client.get(f"{self.base_url}/api/v1/users/me")
            response.raise_for_status()
            return response.json()

    def get_audit_logs(
        self,
        *,
        action_type: str | None = None,
        server_id: str | None = None,
        agent_id: str | None = None,
        actor_id: str | None = None,
        client_name: str | None = None,
        user_id: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        params: dict[str, str | int] = {"limit": limit}
        if action_type:
            params["action_type"] = action_type
        if server_id:
            params["server_id"] = server_id
        if agent_id:
            params["agent_id"] = agent_id
        if actor_id:
            params["actor_id"] = actor_id
        if client_name:
            params["client_name"] = client_name
        if user_id:
            params["user_id"] = user_id
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        with httpx.Client(headers=self.headers, timeout=_AUDIT_LOG_TIMEOUT) as client:
            response = client.get(f"{self.base_url}/api/v1/auditlogs", params=params)
            response.raise_for_status()
            return response.json()

    def track_installation_events(
        self, events: list[InstallationAnalyticsEvent]
    ) -> dict[str, Any]:
        with httpx.Client(headers=self.headers) as client:
            response = client.post(
                f"{self.base_url}/api/v1/metrics/cli-install-events",
                json={"events": events},
            )
            if response.status_code == 404:
                return {"unsupported": True}
            response.raise_for_status()
            return response.json()


class SkillFileMetadata(BaseModel):
    id: str
    skill_id: str
    title: str
    description: str | None = None
    updated_at: datetime.datetime


class SkillDetail(BaseModel):
    id: str
    name: str
    path: str | None = None
    description: str | None = None
    is_public: bool = False
    namespace: str | None = None
    identifier: str | None = None
    file_count: int = 0
    files: list[SkillFileMetadata] = []
    updated_at: datetime.datetime | None = None


class SkillFileDetail(BaseModel):
    id: str
    skill_id: str
    title: str
    description: str | None = None
    content: str


class SkillScanFileScore(BaseModel):
    name: str
    score: float
    risk_level: str
    reasons: list[str] = []


class SkillScanResponse(BaseModel):
    skill_score: float
    skill_risk_level: str
    classification: str
    files: list[SkillScanFileScore]
