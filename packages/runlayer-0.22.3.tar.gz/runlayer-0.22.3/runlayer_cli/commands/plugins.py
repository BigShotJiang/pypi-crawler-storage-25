from pathlib import Path

import anyio
import structlog
import typer

from runlayer_cli.api import RunlayerClient
from runlayer_cli.console import print_error
from runlayer_cli.config import resolve_credentials, set_credentials_in_context
from runlayer_cli.logging import setup_logging
from runlayer_cli.plugins.discovery import discover_plugins
from runlayer_cli.plugins.installer import (
    NATIVE_PLUGIN_CLIENTS,
    PluginInstallResult,
    PluginLockEntry,
    PluginUpdateResult,
    install_plugins,
    read_plugin_lockfile,
    resolve_plugin_dirs,
    uninstall_plugin,
    update_plugins,
)
from runlayer_cli.plugins.sync_engine import (
    PluginSyncResult,
    sync_discovered_plugins,
)

logger = structlog.get_logger(__name__)

app = typer.Typer(help="Manage plugins")


@app.callback(invoke_without_command=True)
def plugins_callback(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


# All clients supported for plugin install (native + MCP fallback)
_SUPPORTED_CLIENTS = NATIVE_PLUGIN_CLIENTS | {
    "windsurf",
    "goose",
    "zed",
    "opencode",
}


def _resolve_client(client_name: str | None) -> str:
    if client_name:
        if client_name not in _SUPPORTED_CLIENTS:
            typer.secho(
                f"Unsupported client: {client_name}. "
                f"Supported: {', '.join(sorted(_SUPPORTED_CLIENTS))}",
                fg=typer.colors.RED,
                err=True,
            )
            raise typer.Exit(1)
        return client_name
    return "claude_code"


def _scope_name(global_install: bool) -> str:
    return "global" if global_install else "project"


def _group_plugins(entries: list[PluginLockEntry]) -> list[tuple[str, str, list[str]]]:
    grouped: dict[str, tuple[str, str, list[str]]] = {}

    for entry in entries:
        row = grouped.get(entry.id)
        if row is None:
            grouped[entry.id] = (entry.name, entry.namespace or "", [entry.client])
            continue

        name, namespace, clients = row
        if entry.client not in clients:
            clients.append(entry.client)
        if not namespace and entry.namespace:
            grouped[entry.id] = (name, entry.namespace, clients)

    rows = [
        (name, namespace, sorted(dict.fromkeys(clients)))
        for name, namespace, clients in grouped.values()
    ]
    rows.sort(key=lambda row: (row[0], row[1], ",".join(row[2])))
    return rows


@app.command()
def push(
    ctx: typer.Context,
    path: str = typer.Argument(".", help="Root directory"),
    namespace: str = typer.Option(
        ..., "--namespace", "-N", help="Namespace for matching plugins on the server"
    ),
    public: bool = typer.Option(False, "--public"),
    dynamic_tools: bool = typer.Option(False, "--dynamic-tools"),
    secret: str | None = typer.Option(
        None, "--secret", "-s", envvar="RUNLAYER_API_KEY"
    ),
    host: str | None = typer.Option(None, "--host", "-H", envvar="RUNLAYER_HOST"),
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    prune: bool = typer.Option(False, "--prune"),
) -> None:
    """Push plugins to Runlayer API."""
    root = Path(path).resolve()
    log_file_path = setup_logging(command="plugins-push", quiet_console=False)

    set_credentials_in_context(ctx, secret, host)
    credentials = resolve_credentials(ctx, require_auth=True)

    try:
        client = RunlayerClient(
            hostname=credentials["host"], secret=credentials["secret"]
        )

        discovered = discover_plugins(root)
        n_plugins = len(discovered)
        n_skills = sum(len(p.skills) for p in discovered)
        typer.echo(f"Found {n_plugins} plugins, {n_skills} skills")

        pushing_printed = False

        def _ensure_pushing_header() -> None:
            nonlocal pushing_printed
            if not pushing_printed:
                typer.echo("\nPushing...")
                pushing_printed = True

        def on_skill_progress(skill_path: str, status: str) -> None:
            if status not in ("unchanged",):
                _ensure_pushing_header()
                typer.echo(f"  {skill_path}: {status}")

        def on_plugin_progress(plugin_path: str, status: str) -> None:
            if status not in ("unchanged",):
                _ensure_pushing_header()
                typer.echo(f"  {plugin_path}: {status}")

        async def _run() -> PluginSyncResult:
            return await sync_discovered_plugins(
                discovered,
                client,
                namespace=namespace,
                is_public=public,
                use_dynamic_tools=dynamic_tools,
                dry_run=dry_run,
                prune=prune,
                on_skill_progress=on_skill_progress,
                on_plugin_progress=on_plugin_progress,
            )

        result = anyio.run(_run)
        sr = result.skill_result

        if dry_run:
            typer.secho("[dry run] ", fg=typer.colors.YELLOW, nl=False)

        # Build summary parts: skills first, then plugins (only if any changed)
        parts: list[str] = []
        if sr.created:
            parts.append(f"{sr.created} skills created")
        if sr.updated:
            parts.append(f"{sr.updated} skills updated")
        if sr.deleted:
            parts.append(f"{sr.deleted} skills deleted")

        if result.created:
            parts.append(f"{result.created} plugins created")
        if result.updated:
            parts.append(f"{result.updated} plugins updated")
        if result.deleted:
            parts.append(f"{result.deleted} plugins deleted")

        if parts:
            unchanged = sr.unchanged + result.unchanged
            summary = ", ".join(parts)
            if unchanged:
                typer.echo(f"Done, {summary} ({unchanged} unchanged)")
            else:
                typer.echo(f"Done, {summary}")
        else:
            typer.echo("Done, everything up to date")

        for warning in result.warnings:
            typer.secho(f"  Warning: {warning}", fg=typer.colors.YELLOW, err=True)
        if result.errors:
            for err in result.errors:
                typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        logger.error("plugins_push_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)


@app.command(
    name="list",
    help=(
        "List installed plugins in the selected scope.\n\n"
        "By default, lists project plugins for all clients.\n"
        "Use --global to list global plugins instead.\n"
        "Use --client to filter to one client."
    ),
)
def list_plugins(
    client_name: str | None = typer.Option(
        None, "--client", "-c", help="Filter to one client"
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g", help="List global plugins instead of project plugins"
    ),
) -> None:
    """List installed plugins in the selected scope."""
    log_file_path = setup_logging(command="plugins-list", quiet_console=False)
    resolved_client = _resolve_client(client_name) if client_name else "claude_code"
    _, _, lockfile = resolve_plugin_dirs(resolved_client, global_install, Path.cwd())
    try:
        entries = read_plugin_lockfile(lockfile)
        if client_name:
            entries = [e for e in entries if e.client == resolved_client]
        grouped_entries = _group_plugins(entries)

        if not grouped_entries:
            typer.echo(f"No plugins installed in {_scope_name(global_install)} scope.")
            raise typer.Exit(0)

        for name, namespace, clients in grouped_entries:
            line = f"  {name}"
            if namespace:
                line += f"  ({namespace})"
            line += f"  [{', '.join(clients)}]"
            typer.echo(line)

        typer.echo(f"\n{len(grouped_entries)} plugin(s) installed")
    except typer.Exit:
        raise
    except Exception as e:
        logger.error("list_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)


@app.command()
def add(
    ctx: typer.Context,
    source: str | None = typer.Argument(
        None, help="Plugin UUID or namespace (e.g. Org/Repo)"
    ),
    install_all: bool = typer.Option(
        False, "--all", help="Install all accessible plugins across namespaces"
    ),
    plugin: str | None = typer.Option(
        None, "--plugin", help="Filter by plugin name within namespace"
    ),
    client_name: str | None = typer.Option(
        None, "--client", "-c", help="Target editor client"
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g", help="Install globally"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    secret: str | None = typer.Option(
        None, "--secret", "-s", envvar="RUNLAYER_API_KEY"
    ),
    host: str | None = typer.Option(None, "--host", "-H", envvar="RUNLAYER_HOST"),
) -> None:
    """Add plugins from Runlayer API."""
    if install_all and source is not None:
        typer.secho(
            "Pass either SOURCE or --all, not both.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)
    if not install_all and source is None:
        typer.secho(
            "Missing argument 'SOURCE'. Use SOURCE or --all.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)

    log_file_path = setup_logging(command="plugins-add", quiet_console=False)

    set_credentials_in_context(ctx, secret, host)
    credentials = resolve_credentials(ctx, require_auth=not dry_run)

    resolved_client = _resolve_client(client_name)
    canonical, editor, lockfile = resolve_plugin_dirs(
        resolved_client, global_install, Path.cwd()
    )

    try:
        api = RunlayerClient(hostname=credentials["host"], secret=credentials["secret"])

        def on_progress(name: str, status: str) -> None:
            typer.echo(f"  {name}: {status}")

        async def _run() -> PluginInstallResult:
            return await install_plugins(
                client=api,
                source=source,
                install_all=install_all,
                plugin_name=plugin,
                canonical_dir=canonical,
                editor_dir=editor,
                lockfile_path=lockfile,
                client_name=resolved_client,
                host=credentials["host"],
                install_scope="global" if global_install else "project",
                dry_run=dry_run,
                on_progress=on_progress,
            )

        result = anyio.run(_run)

        if dry_run:
            typer.secho("[dry run] ", fg=typer.colors.YELLOW, nl=False)

        scope = _scope_name(global_install)
        parts = []
        if result.installed:
            parts.append(f"{len(result.installed)} installed")
        if result.skipped:
            parts.append(f"{len(result.skipped)} skipped")
        typer.echo(
            f"Done: {', '.join(parts) if parts else 'nothing to do'} "
            f"for {resolved_client} in {scope} scope"
        )

        if result.errors:
            for err in result.errors:
                typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        logger.error("add_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)


@app.command()
def remove(
    plugin_ref: str | None = typer.Argument(None, help="Plugin name or UUID to remove"),
    remove_all: bool = typer.Option(
        False, "--all", help="Remove all installed plugins"
    ),
    yes: bool = typer.Option(False, "--yes", help="Skip confirmation prompt"),
    client_name: str | None = typer.Option(
        None, "--client", "-c", help="Target editor client"
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g", help="Uninstall from global plugins"
    ),
) -> None:
    """Remove an installed plugin."""
    log_file_path = setup_logging(command="plugins-remove", quiet_console=False)
    if remove_all and plugin_ref is not None:
        typer.secho(
            "Pass either PLUGIN_REF or --all, not both.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)
    if not remove_all and plugin_ref is None:
        typer.secho(
            "Missing argument 'PLUGIN_REF'. Use PLUGIN_REF or --all.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)

    try:
        resolved_client = _resolve_client(client_name)
        canonical, editor, lockfile = resolve_plugin_dirs(
            resolved_client, global_install, Path.cwd()
        )

        if remove_all:
            entries = [
                e for e in read_plugin_lockfile(lockfile) if e.client == resolved_client
            ]
            if not entries:
                typer.echo("No plugins installed.")
                raise typer.Exit(0)

            names = list(dict.fromkeys(e.name for e in entries))
            if not yes:
                scope = "global" if global_install else "project"
                confirmed = typer.confirm(
                    f"Remove {len(names)} plugin(s) from {scope} install?",
                    default=False,
                )
                if not confirmed:
                    typer.echo("Aborted.")
                    raise typer.Exit(0)

            async def _run_all() -> list[str]:
                errors: list[str] = []
                for target_name in names:
                    try:
                        await uninstall_plugin(
                            target_name,
                            canonical,
                            editor,
                            lockfile,
                            resolved_client,
                        )
                    except Exception as e:
                        errors.append(f"{target_name}: {e}")
                return errors

            errors = anyio.run(_run_all)
            removed_count = len(names) - len(errors)
            typer.echo(f"Done: {removed_count} removed")
            if errors:
                for err in errors:
                    typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
                raise typer.Exit(1)
            return

        if plugin_ref is None:
            typer.secho(
                "Missing argument 'PLUGIN_REF'. Use PLUGIN_REF or --all.",
                fg=typer.colors.RED,
                err=True,
            )
            raise typer.Exit(1)

        async def _run() -> str:
            return await uninstall_plugin(
                plugin_ref, canonical, editor, lockfile, resolved_client
            )

        removed_name = anyio.run(_run)
        typer.echo(f"Removed: {removed_name}")

    except typer.Exit:
        raise
    except ValueError as e:
        if remove_all:
            logger.error("remove_failed", error=str(e), exc_info=True)
            print_error(str(e), str(log_file_path))
            raise typer.Exit(1)
        typer.secho(str(e), fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    except Exception as e:
        logger.error("remove_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)


@app.command()
def update(
    ctx: typer.Context,
    plugin: str | None = typer.Option(
        None, "--plugin", help="Update specific plugin only"
    ),
    client_name: str | None = typer.Option(
        None, "--client", "-c", help="Target editor client"
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g", help="Update global plugins"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    secret: str | None = typer.Option(
        None, "--secret", "-s", envvar="RUNLAYER_API_KEY"
    ),
    host: str | None = typer.Option(None, "--host", "-H", envvar="RUNLAYER_HOST"),
) -> None:
    """Update installed plugins from Runlayer API."""
    log_file_path = setup_logging(command="plugins-update", quiet_console=False)

    set_credentials_in_context(ctx, secret, host)
    credentials = resolve_credentials(ctx, require_auth=not dry_run)

    resolved_client = _resolve_client(client_name)
    canonical, editor, lockfile = resolve_plugin_dirs(
        resolved_client, global_install, Path.cwd()
    )

    try:
        api = RunlayerClient(hostname=credentials["host"], secret=credentials["secret"])

        def on_progress(name: str, status: str) -> None:
            typer.echo(f"  {name}: {status}")

        async def _run() -> PluginUpdateResult:
            return await update_plugins(
                client=api,
                plugin_name=plugin,
                canonical_dir=canonical,
                editor_dir=editor,
                lockfile_path=lockfile,
                client_name=resolved_client,
                host=credentials["host"],
                dry_run=dry_run,
                on_progress=on_progress,
            )

        result = anyio.run(_run)

        if dry_run:
            typer.secho("[dry run] ", fg=typer.colors.YELLOW, nl=False)

        parts = []
        if result.updated:
            parts.append(f"{len(result.updated)} updated")
        if result.up_to_date:
            parts.append(f"{len(result.up_to_date)} up to date")
        if result.removed:
            parts.append(f"{len(result.removed)} removed")
        typer.echo(f"Done: {', '.join(parts) if parts else 'nothing to do'}")

        if result.errors:
            for err in result.errors:
                typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        logger.error("update_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)
