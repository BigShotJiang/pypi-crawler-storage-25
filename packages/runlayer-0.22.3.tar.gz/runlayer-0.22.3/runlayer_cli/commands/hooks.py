"""Hidden hook relay command for use by runlayer-hook.sh."""

import json
import sys
import time
from pathlib import Path

import httpx
import typer

from runlayer_cli.api import API_KEY_HEADER_NAME, USER_AGENT
from runlayer_cli.config import load_config

app = typer.Typer(hidden=True)

_TARGETS: dict[str, tuple[str, int]] = {
    "enforce": ("/api/v1/hooks/cursor", 30),
    "event": ("/api/v1/hooks/events", 5),
}

_DEBUG_DIR = Path("/tmp")


def _write_debug(
    target: str, url: str, request_body: str, resp: httpx.Response | None
) -> None:
    ts = int(time.time())
    data = {
        "timestamp": ts,
        "url": url,
        "request_body": request_body,
        "response_status": resp.status_code if resp else None,
        "response_body": resp.text if resp else None,
    }
    path = _DEBUG_DIR / f"runlayer-relay-{target}-{ts}.json"
    path.write_text(json.dumps(data, indent=2))


@app.command()
def relay(
    target: str = typer.Argument(help="Relay target: 'enforce' or 'event'"),
    timeout: int | None = typer.Option(None, help="Override default timeout (seconds)"),
    debug: bool = typer.Option(False, "--debug", hidden=True),
) -> None:
    """Read JSON from stdin, resolve credentials, POST to the hooks endpoint."""
    if target not in _TARGETS:
        typer.echo(f"Unknown target: {target}. Use 'enforce' or 'event'.", err=True)
        raise typer.Exit(1)
    endpoint, default_timeout = _TARGETS[target]
    effective_timeout = timeout if timeout is not None else default_timeout

    config = load_config()
    host = config.default_host
    if not host:
        raise typer.Exit(1)
    secret = config.get_secret_for_host(host)
    if not secret:
        raise typer.Exit(1)

    url = f"{host}{endpoint}"
    payload = sys.stdin.read()
    try:
        with httpx.Client() as client:
            resp = client.post(
                url,
                content=payload,
                headers={
                    "Content-Type": "application/json",
                    API_KEY_HEADER_NAME: secret,
                    "User-Agent": USER_AGENT,
                },
                timeout=effective_timeout,
            )
        if debug:
            try:
                _write_debug(target, url, payload, resp)
            except Exception:
                pass
        sys.stdout.write(resp.text)
        raise typer.Exit(0 if resp.is_success else 2)
    except (httpx.HTTPError, OSError):
        if debug:
            try:
                _write_debug(target, url, payload, None)
            except Exception:
                pass
        raise typer.Exit(2)
