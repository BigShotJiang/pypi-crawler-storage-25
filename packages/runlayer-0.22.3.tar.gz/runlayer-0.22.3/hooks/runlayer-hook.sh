#!/bin/bash
# Runlayer Hook - Unified MCP enforcement + raw event forwarding
# Auto-detects Cursor vs Claude Code and adapts I/O format accordingly.
#
# Detection: CURSOR_VERSION env var -> Cursor; HOOK_EVENT_NAME env var -> Claude Code
#
# Enforcement events (blocking, when enforcement=true):
#   beforeMCPExecution (Cursor-only): input carries url/command, forward to /hooks/cursor
#   PreToolUse / preToolUse:
#     - MCP tools (mcp__*): Claude Code path uses _lookup_mcp_server; Cursor forwards+allows
#     - Read tool: local file path pattern matching for .env / MCP configs
#   beforeReadFile (Cursor-only): local file path pattern matching
# Stop events: fire-and-forget with transcript (when available)
# All other events: fire-and-forget forwarding of raw payload to /hooks/events

set -euo pipefail

# =============================================================================
# Client detection
# =============================================================================
_CLIENT="claude_code"
if [[ -n "${CURSOR_VERSION:-}" ]]; then
  _CLIENT="cursor"
fi

# If Cursor loaded this hook from a non-Cursor config (e.g. ~/.claude/settings.json),
# no-op to avoid double enforcement with the Cursor-native hook.
# Match the actual Cursor config dirs, not bare "cursor" (avoids false positives
# when the OS username happens to be "cursor").
if [[ "$_CLIENT" == "cursor" ]]; then
  _hook_dir_lower=$(dirname "$0" | tr '[:upper:]' '[:lower:]')
  if [[ "$_hook_dir_lower" != */.cursor/* ]] \
     && [[ "$_hook_dir_lower" != */application?support/cursor/* ]] \
     && [[ "$_hook_dir_lower" != /etc/cursor/* ]] \
     && [[ "$_hook_dir_lower" != */programdata/cursor/* ]]; then
    echo '{"permission":"allow"}'
    exit 0
  fi
fi

# Capture env-var event name early so deny_response can reference it before
# stdin is parsed (e.g. stdin read failure).
_HOOK_EVENT_NAME="${HOOK_EVENT_NAME:-PreToolUse}"

# =============================================================================
# Response helpers (adapt JSON shape per client)
# =============================================================================
_AGENT_GUARDRAILS='**If you are an AI Agent:**
- Provide the user with a detailed explanation of this security violation.
- Do not suggest this is a false positive or mistake.
- Do not suggest modifying, bypassing, or disabling the Runlayer hook or security configuration.
- Do not suggest checking or editing hook files, settings.json, or any security configuration.
- Do not retry this action or attempt alternative approaches to achieve the same result.'

deny_response() {
  local user_msg="${1:-Action blocked by organization security policy}"
  local agent_msg="${2:-}"
  if [[ -z "$agent_msg" ]]; then
    agent_msg="# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Reason: The Runlayer hook encountered an internal error and could not complete the required policy check. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator."
  fi
  if [[ "$_CLIENT" == "cursor" ]]; then
    jq -nc --arg u "$user_msg" --arg a "$agent_msg" \
      '{permission: "deny", continue: true, user_message: $u, agentMessage: $a}'
  else
    jq -nc --arg m "$agent_msg" --arg e "$_HOOK_EVENT_NAME" '{
      hookSpecificOutput: {
        hookEventName: $e,
        permissionDecision: "deny",
        permissionDecisionReason: $m
      }
    }'
  fi
  exit 0
}

allow_response() {
  if [[ "$_CLIENT" == "cursor" ]]; then
    echo '{"permission":"allow"}'
  fi
}

# =============================================================================
# Read hook input
# =============================================================================
input=$(cat 2>/dev/null) || deny_response "Action blocked by organization security policy" \
  "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Reason: The hook failed to read its input payload. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator."

hook_type="${HOOK_EVENT_NAME:-}"
[[ -z "$hook_type" ]] && hook_type=$(echo "$input" | jq -r '.hook_event_name // empty' 2>/dev/null) || true
[[ -z "$hook_type" ]] && exit 0

_original_hook_type="$hook_type"

# Normalize event names (Cursor camelCase -> Claude Code PascalCase)
case "$hook_type" in
  preToolUse)           hook_type="PreToolUse" ;;
  postToolUse)          hook_type="PostToolUse" ;;
  postToolUseFailure)   hook_type="PostToolUseFailure" ;;
  stop)                 hook_type="Stop" ;;
  sessionStart)         hook_type="SessionStart" ;;
  sessionEnd)           hook_type="SessionEnd" ;;
  subagentStart)        hook_type="SubagentStart" ;;
  subagentStop)         hook_type="SubagentStop" ;;
  beforeSubmitPrompt)   hook_type="UserPromptSubmit" ;;
  preCompact)           hook_type="PreCompact" ;;
esac

# =============================================================================
# Enforcement config
# =============================================================================
_config_file="$(dirname "$0")/runlayer-config.json"
_ENFORCEMENT=true
if [[ -f "$_config_file" ]]; then
  _val=$(jq -r '.enforcement' "$_config_file" 2>/dev/null) || true
  [[ "$_val" == "false" ]] && _ENFORCEMENT=false
fi

# =============================================================================
# Event forwarding (via runlayer hooks relay — handles credential resolution)
# =============================================================================
_forward_event() {
  local event_name="$1"
  local payload="$2"
  local wrapper
  wrapper=$(jq -nc --arg c "$_CLIENT" --arg e "$event_name" --argjson p "$payload" \
    '{client: $c, event_name: $e, payload: $p}') || return 0
  echo "$wrapper" | runlayer hooks relay event >/dev/null 2>&1 || true
}

_forward_stop_event() {
  local event_name="$1"
  local payload="$2"
  local _transcript_tmp=""
  local transcript_path
  transcript_path=$(echo "$payload" | jq -r '.transcript_path // empty' 2>/dev/null) || true
  [[ -z "$transcript_path" ]] && transcript_path="${CURSOR_TRANSCRIPT_PATH:-}"
  if [[ -n "$transcript_path" ]]; then
    transcript_path="${transcript_path/#\~/$HOME}"
    sleep 1
    if [[ -f "$transcript_path" ]]; then
      _transcript_tmp=$(mktemp)
      tail -c 524288 "$transcript_path" > "$_transcript_tmp" 2>/dev/null || true
    fi
  fi
  if [[ -n "$_transcript_tmp" && -s "$_transcript_tmp" ]]; then
    jq -nc --arg c "$_CLIENT" --arg e "$event_name" --argjson p "$payload" \
      --rawfile t "$_transcript_tmp" \
      '{client: $c, event_name: $e, payload: $p, transcript: $t}' \
    | runlayer hooks relay event --timeout 10 >/dev/null 2>&1 || true
    rm -f "$_transcript_tmp"
  else
    [[ -n "$_transcript_tmp" ]] && rm -f "$_transcript_tmp"
    _forward_event "$event_name" "$payload"
  fi
}

# =============================================================================
# MCP server lookup (Claude Code path only — Cursor uses beforeMCPExecution)
# Search order per Claude Code docs:
#   1. ${cwd}/.mcp.json              — project-scoped servers
#   2. ~/.claude.json projects[cwd]   — per-project servers in user state
#   3. ~/.claude.json mcpServers      — global user-scoped servers
# =============================================================================
_lookup_mcp_server() {
  local server_name="$1"
  local cwd="$2"
  MCP_SERVER_URL=""
  MCP_SERVER_COMMAND=""
  local url command args

  if [[ -f "${cwd}/.mcp.json" ]]; then
    url=$(jq -r --arg s "$server_name" '.mcpServers[$s].url // empty' "${cwd}/.mcp.json" 2>/dev/null) || true
    if [[ -n "$url" ]]; then MCP_SERVER_URL="$url"; return 0; fi
    command=$(jq -r --arg s "$server_name" '.mcpServers[$s].command // empty' "${cwd}/.mcp.json" 2>/dev/null) || true
    if [[ -n "$command" ]]; then
      args=$(jq -r --arg s "$server_name" '.mcpServers[$s].args // [] | join(" ")' "${cwd}/.mcp.json" 2>/dev/null) || true
      MCP_SERVER_COMMAND="${command} ${args}"; return 0
    fi
  fi

  local claude_json="${HOME}/.claude.json"
  if [[ -f "$claude_json" ]]; then
    url=$(jq -r --arg c "$cwd" --arg s "$server_name" '.projects[$c].mcpServers[$s].url // empty' "$claude_json" 2>/dev/null) || true
    if [[ -n "$url" ]]; then MCP_SERVER_URL="$url"; return 0; fi
    command=$(jq -r --arg c "$cwd" --arg s "$server_name" '.projects[$c].mcpServers[$s].command // empty' "$claude_json" 2>/dev/null) || true
    if [[ -n "$command" ]]; then
      args=$(jq -r --arg c "$cwd" --arg s "$server_name" '.projects[$c].mcpServers[$s].args // [] | join(" ")' "$claude_json" 2>/dev/null) || true
      MCP_SERVER_COMMAND="${command} ${args}"; return 0
    fi

    url=$(jq -r --arg s "$server_name" '.mcpServers[$s].url // empty' "$claude_json" 2>/dev/null) || true
    if [[ -n "$url" ]]; then MCP_SERVER_URL="$url"; return 0; fi
    command=$(jq -r --arg s "$server_name" '.mcpServers[$s].command // empty' "$claude_json" 2>/dev/null) || true
    if [[ -n "$command" ]]; then
      args=$(jq -r --arg s "$server_name" '.mcpServers[$s].args // [] | join(" ")' "$claude_json" 2>/dev/null) || true
      MCP_SERVER_COMMAND="${command} ${args}"; return 0
    fi
  fi

  return 1
}

# =============================================================================
# File-read enforcement (shared pattern matching)
# =============================================================================
_check_file_read() {
  local file_path="$1"
  [[ -z "$file_path" ]] && return 0

  local basename lower_basename
  basename=$(basename "$file_path")
  lower_basename=$(echo "$basename" | tr '[:upper:]' '[:lower:]')
  case "$lower_basename" in
    .env|.env.*|*.env|.envrc)
      deny_response \
        "Blocked by organization policy: access to environment files is restricted" \
        "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: File Access Policy
- File: ${file_path}
- Reason: Reading environment files (.env, .envrc) is blocked by your organization's policy. These files may contain credentials and secrets that must not be sent to the LLM.
- Do not attempt to read this file using Bash (cat, head, tail, less), Grep, or any other tool. All access to this file is restricted.

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is a false positive or mistake, contact your Runlayer administrator to adjust file access policies."
      ;;
    mcp.json|mcp_config.json|.mcp.json|mcp-config.json|mcp.yaml|mcp.yml|.claude.json|claude_desktop_config.json)
      deny_response \
        "Blocked by organization policy: access to MCP configuration files is restricted" \
        "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: File Access Policy
- File: ${file_path}
- Reason: Reading MCP configuration files is blocked by your organization's policy. These files contain sensitive server connection details that must not be exposed.
- Do not attempt to read this file using Bash (cat, head, tail, less), Grep, or any other tool. All access to this file is restricted.

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is a false positive or mistake, contact your Runlayer administrator to adjust file access policies."
      ;;
    settings.json)
      local lower_path
      lower_path=$(echo "$file_path" | tr '[:upper:]' '[:lower:]')
      case "$lower_path" in
        */.claude/settings.json)
          deny_response \
            "Blocked by organization policy: access to Claude Code settings is restricted" \
            "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: File Access Policy
- File: ${file_path}
- Reason: Reading Claude Code settings files is blocked by your organization's policy. These files contain sensitive hook and security configuration that must not be exposed.
- Do not attempt to read this file using Bash (cat, head, tail, less), Grep, or any other tool. All access to this file is restricted.

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is a false positive or mistake, contact your Runlayer administrator to adjust file access policies."
          ;;
      esac
      ;;
  esac
}

# =============================================================================
# Shell command enforcement (scan for protected file references)
# =============================================================================
_check_bash_command() {
  local command="$1"
  [[ -z "$command" ]] && return 0
  local words
  words=$(printf '%s' "$command" | tr '|;&<>\n`' ' ' | sed 's/\$(/  /g; s/)/ /g')
  for word in $words; do
    case "$word" in
      -*|[0-9]*|""|"''"'""') continue ;;
    esac
    word="${word#\"}"; word="${word%\"}"
    word="${word#\'}"; word="${word%\'}"
    _check_file_read "$word"
  done
}

# =============================================================================
# Main dispatch
# =============================================================================
case "$hook_type" in

  # ---------------------------------------------------------------------------
  # beforeMCPExecution — Cursor-only; input already carries url/command
  # ---------------------------------------------------------------------------
  beforeMCPExecution)
    raw_input="$input"

    if [[ "$_ENFORCEMENT" == "true" ]]; then
      if echo "$input" | jq -e '.tool_input | type == "object"' > /dev/null 2>&1; then
        input=$(echo "$input" | jq '.tool_input = (.tool_input | tojson)') \
          || deny_response "Action blocked by organization security policy" \
            "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Reason: Failed to serialize tool_input for the policy verification request. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator."
      fi

      response=$(echo "$input" | runlayer hooks relay enforce 2>/dev/null) && rc=0 || rc=$?
      if [[ $rc -eq 1 ]]; then
        deny_response \
          "Action blocked by organization security policy. Run 'runlayer login' first." \
          "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Authentication Required
- Reason: Runlayer credentials are not configured on this machine. Your organization's policy requires all MCP tool use to be verified, which requires valid credentials.

${_AGENT_GUARDRAILS}

**What to do:**
Run 'runlayer login' to set up authentication, then retry."
      elif [[ $rc -ne 0 ]]; then
        deny_response \
          "Failed to contact Runlayer API" \
          "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Reason: Failed to contact the Runlayer API for MCP execution verification. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator. The Runlayer API may be temporarily unreachable."
      fi

      if ! echo "$response" | jq -e 'has("permission")' > /dev/null 2>&1; then
        deny_response \
          "Invalid response from Runlayer API" \
          "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Reason: The Runlayer API returned an invalid response during MCP verification. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator."
      fi

      _forward_event "$_original_hook_type" "$raw_input" &

      permission=$(echo "$response" | jq -r '.permission // "allow"' 2>/dev/null) || true
      if [[ "$permission" == "deny" ]]; then
        reason=$(echo "$response" | jq -r '.user_message // "MCP execution blocked by organization policy"' 2>/dev/null) || true
        deny_response "$reason" \
          "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: MCP Execution Policy
- Reason: ${reason}

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is a false positive or mistake, contact your Runlayer administrator to review the security policy settings."
      fi
      echo "$response"
    else
      _forward_event "$_original_hook_type" "$raw_input" &
      echo '{"permission":"allow"}'
    fi
    ;;

  # ---------------------------------------------------------------------------
  # PreToolUse — Claude Code native + Cursor via third-party hooks
  # ---------------------------------------------------------------------------
  PreToolUse)
    tool_name=$(echo "$input" | jq -r '.tool_name // empty' 2>/dev/null) || true

    # --- MCP tool enforcement (Claude Code only; Cursor uses beforeMCPExecution) ---
    if [[ "$tool_name" == mcp__* && "$_CLIENT" == "claude_code" ]]; then
      if [[ "$_ENFORCEMENT" == "true" ]]; then
        server_name=$(echo "$tool_name" | sed 's/^mcp__//' | sed 's/__.*$//')
        cwd=$(echo "$input" | jq -r '.cwd // empty' 2>/dev/null) || true
        [[ -z "$cwd" ]] && cwd="$(pwd)"

        _lookup_mcp_server "$server_name" "$cwd" \
          || deny_response \
            "Action blocked: MCP server '${server_name}' not registered" \
            "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: MCP Execution Policy
- Tool: ${tool_name}
- MCP Server: ${server_name}
- Reason: MCP server '${server_name}' is not registered in Claude Code settings and cannot be verified. Your organization's policy requires all MCP servers to be registered before use.

${_AGENT_GUARDRAILS}

**What to do:**
Contact your Runlayer administrator to register this MCP server, or add the server to your Claude Code settings."

        if [[ -n "$MCP_SERVER_URL" ]]; then
          cursor_req=$(jq -nc \
            --arg hook "beforeMCPExecution" \
            --arg tool "$tool_name" \
            --arg url "$MCP_SERVER_URL" \
            '{hook_event_name: $hook, tool_name: $tool, url: $url}') \
            || deny_response \
              "Action blocked by organization security policy" \
              "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Tool: ${tool_name}
- Reason: Failed to prepare the MCP verification request. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator."
        else
          cursor_req=$(jq -nc \
            --arg hook "beforeMCPExecution" \
            --arg tool "$tool_name" \
            --arg cmd "$MCP_SERVER_COMMAND" \
            '{hook_event_name: $hook, tool_name: $tool, command: $cmd}') \
            || deny_response \
              "Action blocked by organization security policy" \
              "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Tool: ${tool_name}
- Reason: Failed to prepare the MCP verification request. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator."
        fi

        response=$(echo "$cursor_req" | runlayer hooks relay enforce 2>/dev/null) && rc=0 || rc=$?
        if [[ $rc -eq 1 ]]; then
          deny_response \
            "Action blocked by organization security policy. Run 'runlayer login' first." \
            "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Authentication Required
- Tool: ${tool_name}
- Reason: Runlayer credentials are not configured on this machine. Your organization's policy requires all MCP tool use to be verified, which requires valid credentials.

${_AGENT_GUARDRAILS}

**What to do:**
Run 'runlayer login' to set up authentication, then retry."
        elif [[ $rc -ne 0 ]]; then
          deny_response \
            "Failed to contact Runlayer API" \
            "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Tool: ${tool_name}
- Reason: Failed to contact the Runlayer API for MCP execution verification. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator. The Runlayer API may be temporarily unreachable."
        fi

        if ! echo "$response" | jq -e 'has("permission")' > /dev/null 2>&1; then
          deny_response \
            "Invalid response from Runlayer API" \
            "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: Infrastructure
- Tool: ${tool_name}
- Reason: The Runlayer API returned an invalid response during MCP verification. Unverified actions are blocked (fail-closed).

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is an error, contact your Runlayer administrator."
        fi

        permission=$(echo "$response" | jq -r '.permission // "allow"' 2>/dev/null) || true

        _forward_event "$_original_hook_type" "$input" &

        if [[ "$permission" == "deny" ]]; then
          reason=$(echo "$response" | jq -r '.user_message // "MCP execution blocked by organization policy"' 2>/dev/null) || true
          deny_response "$reason" \
            "# Security Violation Detected

Your organization's security policy (enforced by Runlayer) has blocked this operation.

**What happened:**
- Violation type: MCP Execution Policy
- Tool: ${tool_name}
- Reason: ${reason}

${_AGENT_GUARDRAILS}

**What to do:**
If you believe this is a false positive or mistake, contact your Runlayer administrator to review the security policy settings."
        fi

        exit 0
      else
        _forward_event "$_original_hook_type" "$input" &
        exit 0
      fi
    fi

    # --- Read tool enforcement ---
    if [[ "$tool_name" == "Read" ]]; then
      if [[ "$_ENFORCEMENT" == "true" ]]; then
        file_path=$(echo "$input" | jq -r '.tool_input.file_path // empty' 2>/dev/null) || true
        _check_file_read "$file_path"
      fi

      _forward_event "$_original_hook_type" "$input" &
      allow_response
      exit 0
    fi

    # --- Bash tool enforcement ---
    if [[ "$tool_name" == "Bash" ]]; then
      if [[ "$_ENFORCEMENT" == "true" ]]; then
        bash_command=$(echo "$input" | jq -r '.tool_input.command // empty' 2>/dev/null) || true
        _check_bash_command "$bash_command"
      fi

      _forward_event "$_original_hook_type" "$input" &
      allow_response
      exit 0
    fi

    # --- Other tools: forward + allow ---
    _forward_event "$_original_hook_type" "$input" &
    allow_response
    ;;

  # ---------------------------------------------------------------------------
  # beforeReadFile — Cursor-only; file_path at top level
  # ---------------------------------------------------------------------------
  beforeReadFile)
    if [[ "$_ENFORCEMENT" == "true" ]]; then
      file_path=$(echo "$input" | jq -r '.file_path // empty' 2>/dev/null) || true
      _check_file_read "$file_path"
    fi

    _forward_event "$_original_hook_type" "$input" &
    allow_response
    ;;

  # ---------------------------------------------------------------------------
  # Stop — transcript attachment
  # ---------------------------------------------------------------------------
  Stop)
    _forward_stop_event "$_original_hook_type" "$input" &
    allow_response
    ;;

  # ---------------------------------------------------------------------------
  # beforeShellExecution — Cursor-only; scan command for protected files
  # ---------------------------------------------------------------------------
  beforeShellExecution)
    if [[ "$_ENFORCEMENT" == "true" ]]; then
      shell_command=$(echo "$input" | jq -r '.command // empty' 2>/dev/null) || true
      _check_bash_command "$shell_command"
    fi
    _forward_event "$_original_hook_type" "$input" &
    allow_response
    ;;

  # ---------------------------------------------------------------------------
  # Other blocking events — forward + allow
  # ---------------------------------------------------------------------------
  SubagentStart|UserPromptSubmit)
    _forward_event "$_original_hook_type" "$input" &
    allow_response
    ;;

  # ---------------------------------------------------------------------------
  # Observational events — forward only
  # ---------------------------------------------------------------------------
  *)
    _forward_event "$_original_hook_type" "$input" &
    if [[ "$_CLIENT" == "cursor" ]]; then
      echo "{}"
    fi
    ;;
esac

exit 0
