Reference material for root skill bundling.
