print("triage helper")
