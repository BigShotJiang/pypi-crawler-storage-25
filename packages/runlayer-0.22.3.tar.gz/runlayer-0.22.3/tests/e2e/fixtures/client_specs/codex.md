# Codex MCP Client Spec

- **Marketplace path (project):** `$REPO_ROOT/.agents/plugins/marketplace.json`
- **Marketplace path (global):** `~/.agents/plugins/marketplace.json`
- **Format:** JSON
- **Plugin cache:** `~/.codex/plugins/cache/<marketplace>/<plugin>/<version>/`
- **Plugin state:** `~/.codex/config.toml`
- **Transport:** bundled plugin MCP config or direct MCP connectors
- **Last verified:** 2026-03-27

## Editor docs

- **Plugins:** https://developers.openai.com/codex/plugins
- **Config:** https://developers.openai.com/codex/config-reference
- **MCP:** https://developers.openai.com/codex/mcp

## Runlayer support

### Skills: supported separately
- Native skill install is tracked outside this plugin flow.

### Plugins: marketplace-native
- Canonical: `.agents/plugins/<normalized-name>/`
- Manifest: `.agents/plugins/<normalized-name>/.codex-plugin/plugin.json`
- MCP config: `.agents/plugins/<normalized-name>/.mcp.json` with `"mcpServers"` key
- Skills: `.agents/plugins/<normalized-name>/skills/<normalized-skill-name>/`
- Normalization: kebab-case for Codex-facing plugin and skill names
- Display name: plugin manifest may preserve the original title via `interface.displayName`
- Marketplace entry:
  - project: `.agents/plugins/marketplace.json`
  - global: `~/.agents/plugins/marketplace.json`
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: native_codex_marketplace`)
- Runlayer CLI does **not** write Codex cache or `config.toml`; user finishes install in Codex via `/plugins`
