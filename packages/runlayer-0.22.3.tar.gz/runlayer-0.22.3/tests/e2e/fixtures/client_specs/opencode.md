# OpenCode MCP Client Spec

- **Config path:** `~/.config/opencode/opencode.json` (all platforms)
- **Config path (alt):** `~/.config/opencode/opencode.jsonc`
- **Format:** JSON / JSONC
- **Servers key:** `mcp`
- **Project config:** `opencode.json` in project root (servers key: `mcp`)
- **Transport:** local, remote
- **Last verified:** 2026-03-23

## Editor docs

- **Skills:** https://opencode.ai/docs/skills/
- **Plugins:** https://opencode.ai/docs/plugins/
- **MCP:** https://opencode.ai/docs/mcp-servers/

## Runlayer support

### Skills: native
- Canonical: `.agents/skills/<name>/`
- Symlink: `.agents/skills/<name>` (same path, no separate editor dir)
- Lockfile: `.runlayer/skill-lock.yml`

### Plugins: mcp_fallback
OpenCode has native plugins but Runlayer uses MCP fallback. Writes HTTP proxy entry to client config under `"mcp"`.
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: mcp_fallback`)

### MCP connectors (servers)
- Config: `~/.config/opencode/opencode.json` or `opencode.json`
- Local entry (uses `command` array, not string):
  ```json
  {"enabled": true, "type": "local", "command": ["uvx", "runlayer", "run", "<server-id>", "--host", "<host>"]}
  ```
- Remote entry:
  ```json
  {"enabled": true, "type": "remote", "url": "<proxy-url>"}
  ```
