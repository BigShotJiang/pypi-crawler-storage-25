from runlayer_cli.main import app


def test_version_flag(runner):
    """runlayer --version"""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "runlayer version" in result.output
