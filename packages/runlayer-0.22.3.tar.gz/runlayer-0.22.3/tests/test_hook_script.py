"""Tests for the runlayer-hook.sh bash script behaviour.

Exercises the hook script via subprocess with a fake ``runlayer`` binary that
captures payloads piped to ``hooks relay``.  Focuses on areas not covered by
test_setup_hooks.py: relay payload shape, event forwarding, event-name
normalization, HOOK_EVENT_NAME env-var dispatch, expanded file-read patterns,
stop-event transcript handling, and edge cases.
"""

import json
import os
import subprocess
import tempfile
import time
from pathlib import Path

HOOK_SRC = Path(__file__).resolve().parent.parent / "hooks" / "runlayer-hook.sh"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_fake_runlayer(
    bin_dir: Path,
    *,
    response: str = '{"permission":"allow"}',
    exit_code: int = 0,
    capture_dir: Path | None = None,
) -> None:
    """Create a fake ``runlayer`` that responds to ``hooks relay`` and optionally
    captures stdin to *capture_dir*/{enforce,event}.jsonl."""
    bin_dir.mkdir(exist_ok=True)
    capture_block = ""
    if capture_dir is not None:
        capture_block = (
            '  if [[ -n "${RUNLAYER_CAPTURE_DIR:-}" ]]; then\n'
            '    echo "$_input" | jq -c . >> "${RUNLAYER_CAPTURE_DIR}/${target}.jsonl" 2>/dev/null || echo "$_input" >> "${RUNLAYER_CAPTURE_DIR}/${target}.jsonl"\n'
            "  fi\n"
        )
    fake = bin_dir / "runlayer"
    fake.write_text(
        "#!/bin/bash\n"
        'if [[ "$1" == "hooks" && "$2" == "relay" ]]; then\n'
        '  target="$3"\n'
        "  _input=$(cat)\n"
        f"{capture_block}"
        f"  echo '{response}'\n"
        f"  exit {exit_code}\n"
        "fi\n"
        "exit 1\n"
    )
    fake.chmod(0o755)


def _setup_hook(
    temp_dir: str,
    *,
    client: str,
    enforcement: bool = True,
) -> Path:
    """Install the hook script into *temp_dir* for *client* ('cursor' | 'claude_code').

    Returns the path to the copied hook script.
    """
    if client == "cursor":
        hook_dir = Path(temp_dir) / ".cursor" / "hooks"
    else:
        hook_dir = Path(temp_dir) / "hooks"
    hook_dir.mkdir(parents=True, exist_ok=True)
    hook_copy = hook_dir / "runlayer-hook.sh"
    hook_copy.write_text(HOOK_SRC.read_text())
    hook_copy.chmod(0o755)
    (hook_dir / "runlayer-config.json").write_text(
        json.dumps({"enforcement": enforcement})
    )
    return hook_copy


def _run_hook(
    hook_path: Path,
    input_json: str,
    home_dir: str,
    *,
    capture_dir: Path | None = None,
    response: str = '{"permission":"allow"}',
    exit_code: int = 0,
    extra_env: dict[str, str] | None = None,
) -> tuple[subprocess.CompletedProcess, dict[str, list[dict]]]:
    """Run the hook script and return (result, captured_payloads).

    *captured_payloads* maps relay target name (``"enforce"`` / ``"event"``)
    to a list of parsed JSON objects that were piped to the fake runlayer.
    """
    bin_dir = Path(home_dir) / "bin"
    _write_fake_runlayer(
        bin_dir,
        response=response,
        exit_code=exit_code,
        capture_dir=capture_dir,
    )

    env: dict[str, str] = {
        **os.environ,
        "HOME": home_dir,
        "PATH": f"{bin_dir}:{os.environ['PATH']}",
    }
    if capture_dir is not None:
        env["RUNLAYER_CAPTURE_DIR"] = str(capture_dir)
    if extra_env:
        env.update(extra_env)

    result = subprocess.run(
        ["bash", str(hook_path)],
        input=input_json,
        capture_output=True,
        text=True,
        env=env,
    )

    captured: dict[str, list[dict]] = {}
    if capture_dir is not None:
        time.sleep(0.15)
        for target in ("enforce", "event"):
            path = capture_dir / f"{target}.jsonl"
            if path.exists():
                lines = [
                    ln.strip() for ln in path.read_text().splitlines() if ln.strip()
                ]
                captured[target] = [json.loads(ln) for ln in lines]
    return result, captured


# =========================================================================
# A. Relay payload verification — enforce path
# =========================================================================


class TestRelayPayloadEnforce:
    """Verify the JSON shape piped to ``runlayer hooks relay enforce``."""

    def test_cursor_before_mcp_execution_stringifies_tool_input(self):
        """Cursor: tool_input object should be serialised to a JSON string."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=True)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps(
                {
                    "hook_event_name": "beforeMCPExecution",
                    "tool_name": "test_tool",
                    "tool_input": {"key": "value"},
                    "url": "https://mcp.example.com",
                }
            )

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                response='{"permission":"allow"}',
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            assert "enforce" in captured
            payload = captured["enforce"][0]
            assert payload["tool_name"] == "test_tool"
            assert payload["url"] == "https://mcp.example.com"
            assert isinstance(payload["tool_input"], str)
            assert json.loads(payload["tool_input"]) == {"key": "value"}

    def test_cursor_before_mcp_execution_string_tool_input_unchanged(self):
        """Cursor: tool_input that is already a string stays as-is."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=True)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps(
                {
                    "hook_event_name": "beforeMCPExecution",
                    "tool_name": "test_tool",
                    "tool_input": '{"already":"string"}',
                    "url": "https://mcp.example.com",
                }
            )

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            payload = captured["enforce"][0]
            assert payload["tool_input"] == '{"already":"string"}'

    def test_claude_code_mcp_builds_synthetic_enforce_with_url(self):
        """Claude Code: MCP tool with URL server builds beforeMCPExecution payload."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)
            capture = Path(td) / "cap"
            capture.mkdir()

            (Path(td) / ".mcp.json").write_text(
                json.dumps(
                    {"mcpServers": {"myserver": {"url": "https://mcp.example.com/sse"}}}
                )
            )

            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "mcp__myserver__do_stuff",
                    "tool_input": {},
                    "cwd": td,
                }
            )

            result, captured = _run_hook(hook, hook_input, td, capture_dir=capture)

            assert result.returncode == 0
            assert "enforce" in captured
            payload = captured["enforce"][0]
            assert payload["hook_event_name"] == "beforeMCPExecution"
            assert payload["tool_name"] == "mcp__myserver__do_stuff"
            assert payload["url"] == "https://mcp.example.com/sse"
            assert "command" not in payload

    def test_claude_code_mcp_builds_synthetic_enforce_with_command(self):
        """Claude Code: MCP tool with command server builds payload with 'command'."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)
            capture = Path(td) / "cap"
            capture.mkdir()

            (Path(td) / ".mcp.json").write_text(
                json.dumps(
                    {
                        "mcpServers": {
                            "myserver": {
                                "command": "npx",
                                "args": ["-y", "my-mcp-server"],
                            }
                        }
                    }
                )
            )

            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "mcp__myserver__do_stuff",
                    "tool_input": {},
                    "cwd": td,
                }
            )

            result, captured = _run_hook(hook, hook_input, td, capture_dir=capture)

            assert result.returncode == 0
            payload = captured["enforce"][0]
            assert payload["hook_event_name"] == "beforeMCPExecution"
            assert payload["command"] == "npx -y my-mcp-server"
            assert "url" not in payload


# =========================================================================
# B. Cursor MCP deny-from-API
# =========================================================================


class TestCursorMCPDeny:
    def test_cursor_mcp_deny_from_api(self):
        """API returns deny — hook outputs Cursor-format deny with agentMessage."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=True)

            hook_input = json.dumps(
                {
                    "hook_event_name": "beforeMCPExecution",
                    "tool_name": "test_tool",
                    "tool_input": "{}",
                    "url": "https://blocked.example.com",
                }
            )

            result, _ = _run_hook(
                hook,
                hook_input,
                td,
                response='{"permission":"deny","user_message":"blocked by policy"}',
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"
            assert output["continue"] is True
            assert "blocked by policy" in output["user_message"]
            assert "Security Violation Detected" in output["agentMessage"]
            assert "MCP Execution Policy" in output["agentMessage"]
            assert "Do not suggest modifying" in output["agentMessage"]


# =========================================================================
# C. Event forwarding payload verification
# =========================================================================


class TestEventForwarding:
    """Verify _forward_event sends the correct envelope to ``relay event``."""

    def test_cursor_mcp_forwards_raw_input(self):
        """Cursor beforeMCPExecution forwards the raw input (not transformed)."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=True)
            capture = Path(td) / "cap"
            capture.mkdir()

            original_input = {
                "hook_event_name": "beforeMCPExecution",
                "tool_name": "test_tool",
                "tool_input": {"key": "value"},
                "url": "https://mcp.example.com",
            }

            result, captured = _run_hook(
                hook,
                json.dumps(original_input),
                td,
                capture_dir=capture,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            assert "event" in captured
            envelope = captured["event"][0]
            assert envelope["client"] == "cursor"
            assert envelope["event_name"] == "beforeMCPExecution"
            assert envelope["payload"]["tool_name"] == "test_tool"
            assert envelope["payload"]["tool_input"] == {"key": "value"}

    def test_claude_code_read_forwards_with_correct_client(self):
        """Claude Code PreToolUse/Read forwards with client=claude_code."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "Read",
                    "tool_input": {"file_path": "/project/main.py"},
                }
            )

            result, captured = _run_hook(hook, hook_input, td, capture_dir=capture)

            assert result.returncode == 0
            assert "event" in captured
            envelope = captured["event"][0]
            assert envelope["client"] == "claude_code"
            assert envelope["event_name"] == "PreToolUse"
            assert envelope["payload"]["tool_name"] == "Read"

    def test_cursor_session_start_forwards(self):
        """Cursor sessionStart event is forwarded with client=cursor."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=False)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps(
                {
                    "hook_event_name": "sessionStart",
                    "session_id": "abc-123",
                }
            )

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            assert "event" in captured
            envelope = captured["event"][0]
            assert envelope["client"] == "cursor"
            assert envelope["event_name"] == "sessionStart"

    def test_claude_code_mcp_forwards_original_event_name(self):
        """Claude Code MCP enforcement forwards using original event name."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)
            capture = Path(td) / "cap"
            capture.mkdir()

            (Path(td) / ".mcp.json").write_text(
                json.dumps(
                    {"mcpServers": {"myserver": {"url": "https://mcp.example.com"}}}
                )
            )

            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "mcp__myserver__do_stuff",
                    "tool_input": {},
                    "cwd": td,
                }
            )

            result, captured = _run_hook(hook, hook_input, td, capture_dir=capture)

            assert result.returncode == 0
            assert "event" in captured
            envelope = captured["event"][0]
            assert envelope["event_name"] == "PreToolUse"


# =========================================================================
# D. Event name normalization
# =========================================================================


class TestEventNameNormalization:
    """Cursor camelCase events dispatch to the correct handler and forward
    with the *original* (un-normalized) event name."""

    def test_pre_tool_use_normalises_to_enforcement(self):
        """preToolUse dispatches to PreToolUse branch (Read enforcement works)."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=True)

            hook_input = json.dumps(
                {
                    "hook_event_name": "preToolUse",
                    "tool_name": "Read",
                    "tool_input": {"file_path": "/project/.env"},
                }
            )

            result, _ = _run_hook(
                hook,
                hook_input,
                td,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_pre_tool_use_forwards_original_name(self):
        """preToolUse forwards as 'preToolUse' (not 'PreToolUse')."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=True)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps(
                {
                    "hook_event_name": "preToolUse",
                    "tool_name": "Write",
                    "tool_input": {},
                }
            )

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            assert "event" in captured
            assert captured["event"][0]["event_name"] == "preToolUse"

    def test_stop_normalises_and_forwards_original(self):
        """Cursor 'stop' dispatches to Stop handler, forwards as 'stop'."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=False)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps({"hook_event_name": "stop", "session_id": "s1"})

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            assert "event" in captured
            assert captured["event"][0]["event_name"] == "stop"

    def test_before_submit_prompt_normalises(self):
        """Cursor beforeSubmitPrompt normalises and forwards original name."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=False)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps(
                {"hook_event_name": "beforeSubmitPrompt", "prompt": "hi"}
            )

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["permission"] == "allow"
            assert "event" in captured
            assert captured["event"][0]["event_name"] == "beforeSubmitPrompt"

    def test_session_start_normalises(self):
        """Cursor sessionStart normalises and is handled by the * branch."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=False)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps(
                {"hook_event_name": "sessionStart", "session_id": "s1"}
            )

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            assert "event" in captured
            assert captured["event"][0]["event_name"] == "sessionStart"


# =========================================================================
# E. HOOK_EVENT_NAME env var
# =========================================================================


class TestHookEventNameEnvVar:
    """Claude Code passes the event name via HOOK_EVENT_NAME env var."""

    def test_env_var_dispatches_pretooluse(self):
        """HOOK_EVENT_NAME=PreToolUse dispatches to enforcement (Read .env denied)."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)

            hook_input = json.dumps(
                {
                    "tool_name": "Read",
                    "tool_input": {"file_path": "/project/.env"},
                }
            )

            result, _ = _run_hook(
                hook,
                hook_input,
                td,
                extra_env={"HOOK_EVENT_NAME": "PreToolUse"},
            )

            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_env_var_dispatches_stop(self):
        """HOOK_EVENT_NAME=Stop dispatches to the Stop handler."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=False)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps({"session_id": "s1"})

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                extra_env={"HOOK_EVENT_NAME": "Stop"},
            )

            assert result.returncode == 0
            assert "event" in captured
            assert captured["event"][0]["event_name"] == "Stop"

    def test_env_var_takes_precedence_over_json(self):
        """HOOK_EVENT_NAME env var takes precedence over JSON body."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)

            hook_input = json.dumps(
                {
                    "hook_event_name": "PostToolUse",
                    "tool_name": "Read",
                    "tool_input": {"file_path": "/project/.env"},
                }
            )

            result, _ = _run_hook(
                hook,
                hook_input,
                td,
                extra_env={"HOOK_EVENT_NAME": "PreToolUse"},
            )

            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["hookSpecificOutput"]["permissionDecision"] == "deny"


# =========================================================================
# F. Cursor beforeReadFile — expanded file patterns
# =========================================================================


class TestCursorBeforeReadFileExpanded:
    """Cursor beforeReadFile enforcement for MCP config files and settings.json."""

    def _run_cursor_read(
        self, temp_dir: str, file_path: str, *, enforcement: bool = True
    ) -> subprocess.CompletedProcess:
        hook = _setup_hook(temp_dir, client="cursor", enforcement=enforcement)

        hook_input = json.dumps(
            {"hook_event_name": "beforeReadFile", "file_path": file_path}
        )

        result, _ = _run_hook(
            hook,
            hook_input,
            temp_dir,
            extra_env={"CURSOR_VERSION": "1.0.0"},
        )
        return result

    def test_blocks_mcp_json(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/mcp.json")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"
            assert "MCP configuration" in output["agentMessage"]

    def test_blocks_dot_mcp_json(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/.mcp.json")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_blocks_mcp_config_json(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/mcp_config.json")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_blocks_mcp_dash_config_json(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/mcp-config.json")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_blocks_mcp_yaml(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/mcp.yaml")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_blocks_mcp_yml(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/mcp.yml")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_blocks_claude_json(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, f"{td}/.claude.json")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_blocks_claude_desktop_config(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(
                td,
                f"{td}/Library/Application Support/Claude/claude_desktop_config.json",
            )
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_blocks_claude_settings_json(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, f"{td}/.claude/settings.json")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"
            assert "Claude Code settings" in output["agentMessage"]

    def test_blocks_claude_settings_json_case_insensitive(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, f"{td}/.Claude/settings.json")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"
            assert "Claude Code settings" in output["agentMessage"]

    def test_allows_vscode_settings_json(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/.vscode/settings.json")
            output = json.loads(result.stdout)
            assert output["permission"] == "allow"

    def test_allows_normal_file(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/src/main.py")
            output = json.loads(result.stdout)
            assert output["permission"] == "allow"

    def test_blocks_envrc(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/.envrc")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_blocks_env_production(self):
        with tempfile.TemporaryDirectory() as td:
            result = self._run_cursor_read(td, "/project/.env.production")
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"


# =========================================================================
# G. Stop event with transcript
# =========================================================================


class TestStopEventTranscript:
    def test_stop_includes_transcript_content(self):
        """Stop event reads transcript file and includes content in forwarded payload."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=False)
            capture = Path(td) / "cap"
            capture.mkdir()

            transcript_path = Path(td) / "transcript.jsonl"
            transcript_content = '{"type":"message","text":"hello world"}\n'
            transcript_path.write_text(transcript_content)

            hook_input = json.dumps(
                {
                    "hook_event_name": "Stop",
                    "session_id": "s1",
                    "transcript_path": str(transcript_path),
                }
            )

            result, captured = _run_hook(hook, hook_input, td, capture_dir=capture)

            assert result.returncode == 0
            assert "event" in captured
            envelope = captured["event"][0]
            assert envelope["event_name"] == "Stop"
            assert "transcript" in envelope
            assert "hello world" in envelope["transcript"]

    def test_cursor_stop_uses_env_transcript_path(self):
        """Cursor stop event uses CURSOR_TRANSCRIPT_PATH env var."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=False)
            capture = Path(td) / "cap"
            capture.mkdir()

            transcript_path = Path(td) / "cursor_transcript.jsonl"
            transcript_path.write_text('{"cursor":"data"}\n')

            hook_input = json.dumps({"hook_event_name": "stop", "session_id": "s1"})

            result, captured = _run_hook(
                hook,
                hook_input,
                td,
                capture_dir=capture,
                extra_env={
                    "CURSOR_VERSION": "1.0.0",
                    "CURSOR_TRANSCRIPT_PATH": str(transcript_path),
                },
            )

            assert result.returncode == 0
            assert "event" in captured
            envelope = captured["event"][0]
            assert "transcript" in envelope
            assert "cursor" in envelope["transcript"]

    def test_stop_without_transcript_still_forwards(self):
        """Stop event without transcript_path still forwards the event."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=False)
            capture = Path(td) / "cap"
            capture.mkdir()

            hook_input = json.dumps({"hook_event_name": "Stop", "session_id": "s1"})

            result, captured = _run_hook(hook, hook_input, td, capture_dir=capture)

            assert result.returncode == 0
            assert "event" in captured
            envelope = captured["event"][0]
            assert envelope["event_name"] == "Stop"
            assert "transcript" not in envelope


# =========================================================================
# H. Edge cases
# =========================================================================


class TestEdgeCases:
    def test_empty_tool_name_pretooluse_allows(self):
        """PreToolUse with empty tool_name forwards and allows (no crash)."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)

            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "",
                    "tool_input": {},
                }
            )

            result, _ = _run_hook(hook, hook_input, td)

            assert result.returncode == 0
            assert "deny" not in result.stdout

    def test_cursor_observational_event_outputs_empty_object(self):
        """Cursor observational events (default branch) output '{}'."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=False)

            hook_input = json.dumps(
                {
                    "hook_event_name": "afterAgentResponse",
                    "data": "test",
                }
            )

            result, _ = _run_hook(
                hook,
                hook_input,
                td,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            assert result.stdout.strip() == "{}"

    def test_claude_code_observational_event_no_stdout(self):
        """Claude Code observational events (default branch) produce no stdout."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=False)

            hook_input = json.dumps(
                {
                    "hook_event_name": "PostToolUse",
                    "tool_name": "Write",
                    "tool_input": {},
                }
            )

            result, _ = _run_hook(hook, hook_input, td)

            assert result.returncode == 0
            assert result.stdout.strip() == ""

    def test_missing_hook_event_name_exits_silently(self):
        """No hook_event_name in input or env → silent exit 0."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)

            hook_input = json.dumps({"tool_name": "Read", "tool_input": {}})

            result, _ = _run_hook(hook, hook_input, td)

            assert result.returncode == 0
            assert result.stdout.strip() == ""

    def test_cursor_allow_response_shape(self):
        """Cursor allow events produce {"permission":"allow"}."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=True)

            hook_input = json.dumps(
                {
                    "hook_event_name": "beforeReadFile",
                    "file_path": "/project/README.md",
                }
            )

            result, _ = _run_hook(
                hook,
                hook_input,
                td,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output == {"permission": "allow"}

    def test_claude_code_deny_response_shape(self):
        """Claude Code deny produces hookSpecificOutput with correct structure."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="claude_code", enforcement=True)

            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "Read",
                    "tool_input": {"file_path": "/project/.env"},
                }
            )

            result, _ = _run_hook(hook, hook_input, td)

            assert result.returncode == 0
            output = json.loads(result.stdout)
            hso = output["hookSpecificOutput"]
            assert hso["hookEventName"] == "PreToolUse"
            assert hso["permissionDecision"] == "deny"
            assert "environment files" in hso["permissionDecisionReason"]

    def test_cursor_deny_response_has_continue_true(self):
        """Cursor deny responses include continue: true."""
        with tempfile.TemporaryDirectory() as td:
            hook = _setup_hook(td, client="cursor", enforcement=True)

            hook_input = json.dumps(
                {
                    "hook_event_name": "beforeReadFile",
                    "file_path": "/project/.env",
                }
            )

            result, _ = _run_hook(
                hook,
                hook_input,
                td,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"
            assert output["continue"] is True
            assert "user_message" in output
            assert "agentMessage" in output

    def test_cursor_username_does_not_false_positive_as_native(self):
        """Hook at /Users/cursor/.claude/hooks/ must no-op, not enforce.

        The old glob *cursor* matched the username; only .cursor/ dir should count.
        """
        with tempfile.TemporaryDirectory() as td:
            hook_dir = Path(td) / "Users" / "cursor" / ".claude" / "hooks"
            hook_dir.mkdir(parents=True)
            hook_copy = hook_dir / "runlayer-hook.sh"
            hook_copy.write_text(HOOK_SRC.read_text())
            hook_copy.chmod(0o755)
            (hook_dir / "runlayer-config.json").write_text(
                json.dumps({"enforcement": True})
            )

            hook_input = json.dumps(
                {
                    "hook_event_name": "beforeReadFile",
                    "file_path": "/project/.env",
                }
            )

            result, _ = _run_hook(
                hook_copy,
                hook_input,
                td,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )

            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output == {"permission": "allow"}


# =========================================================================
# Quoted filename bypass in Bash/shell command scanning
# =========================================================================


class TestBashCommandQuotedFilenameBypass:
    """_check_bash_command must strip quotes so `cat ".env"` is still blocked."""

    def test_claude_bash_double_quoted_env_denied(self):
        with tempfile.TemporaryDirectory() as td:
            hook_path = _setup_hook(td, client="claude_code", enforcement=True)
            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "Bash",
                    "tool_input": {"command": 'cat ".env"'},
                }
            )
            result, _ = _run_hook(
                hook_path,
                hook_input,
                td,
                extra_env={"HOOK_EVENT_NAME": "PreToolUse"},
            )
            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_claude_bash_single_quoted_env_denied(self):
        with tempfile.TemporaryDirectory() as td:
            hook_path = _setup_hook(td, client="claude_code", enforcement=True)
            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "Bash",
                    "tool_input": {"command": "cat '.env'"},
                }
            )
            result, _ = _run_hook(
                hook_path,
                hook_input,
                td,
                extra_env={"HOOK_EVENT_NAME": "PreToolUse"},
            )
            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_claude_bash_quoted_mcp_json_denied(self):
        with tempfile.TemporaryDirectory() as td:
            hook_path = _setup_hook(td, client="claude_code", enforcement=True)
            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "Bash",
                    "tool_input": {"command": "cat '.mcp.json'"},
                }
            )
            result, _ = _run_hook(
                hook_path,
                hook_input,
                td,
                extra_env={"HOOK_EVENT_NAME": "PreToolUse"},
            )
            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_claude_bash_quoted_env_production_denied(self):
        with tempfile.TemporaryDirectory() as td:
            hook_path = _setup_hook(td, client="claude_code", enforcement=True)
            hook_input = json.dumps(
                {
                    "hook_event_name": "PreToolUse",
                    "tool_name": "Bash",
                    "tool_input": {"command": 'head -n 10 ".env.production"'},
                }
            )
            result, _ = _run_hook(
                hook_path,
                hook_input,
                td,
                extra_env={"HOOK_EVENT_NAME": "PreToolUse"},
            )
            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_cursor_shell_double_quoted_env_denied(self):
        with tempfile.TemporaryDirectory() as td:
            hook_path = _setup_hook(td, client="cursor", enforcement=True)
            hook_input = json.dumps(
                {
                    "hook_event_name": "beforeShellExecution",
                    "command": 'cat ".env"',
                }
            )
            result, _ = _run_hook(
                hook_path,
                hook_input,
                td,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )
            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"

    def test_cursor_shell_single_quoted_env_denied(self):
        with tempfile.TemporaryDirectory() as td:
            hook_path = _setup_hook(td, client="cursor", enforcement=True)
            hook_input = json.dumps(
                {
                    "hook_event_name": "beforeShellExecution",
                    "command": "cat '.env'",
                }
            )
            result, _ = _run_hook(
                hook_path,
                hook_input,
                td,
                extra_env={"CURSOR_VERSION": "1.0.0"},
            )
            assert result.returncode == 0
            output = json.loads(result.stdout)
            assert output["permission"] == "deny"
