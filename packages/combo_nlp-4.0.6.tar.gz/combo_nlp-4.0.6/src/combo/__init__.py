"""COMBO — Universal Dependencies parser with composable NLP pipelines."""

__version__ = "4.0.6"

from .api import COMBO
from .data.conllu_reader import Document, Sentence, Token
from .languages import Language, SplitLevel
from .pipeline import Pipeline
from .segmenters import Segmenter

__all__ = [
    "COMBO",
    "Language",
    "SplitLevel",
    "Segmenter",
    "Pipeline",
    "Document",
    "Sentence",
    "Token",
]
