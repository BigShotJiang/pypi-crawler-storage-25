"""Text segmentation components for the COMBO pipeline."""

from enum import Enum

from .base import BaseSegmenter

__all__ = [
    "BaseSegmenter",
    "Segmenter",
    "make_segmenter",
]


class Segmenter(str, Enum):
    """Registered segmenter implementations."""

    LAMBO = "lambo"
    COMBO_SEG = "combo-seg"


def make_segmenter(segmenter: "Segmenter | str", language, **kwargs) -> BaseSegmenter:
    """Construct a segmenter for the given language."""
    kind = Segmenter(segmenter) if isinstance(segmenter, str) else segmenter
    if kind is Segmenter.LAMBO:
        from .lambo import LamboSegmenter
        return LamboSegmenter(language, **kwargs)
    if kind is Segmenter.COMBO_SEG:
        from .combo_seg import ComboSegSegmenter
        return ComboSegSegmenter(language, **kwargs)
    raise ValueError(f"Unknown segmenter: {segmenter!r}.")


# Lazy import for optional dependency
def __getattr__(name: str):
    if name == "LamboSegmenter":
        from .lambo import LamboSegmenter
        return LamboSegmenter
    if name == "ComboSegSegmenter":
        from .combo_seg import ComboSegSegmenter
        return ComboSegSegmenter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
