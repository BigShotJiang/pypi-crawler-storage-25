"""COMBO-Seg segmenter integration.

COMBO-Seg is a character-level XLM-RoBERTa-based segmenter. Install it with::

    pip install combo-seg

Usage::

    from combo import COMBO, Segmenter
    nlp = COMBO.from_pretrained(
        "clarin-pl/combo-nlp-xlm-roberta-base-english-ewt-ud2.17",
        segmenter=Segmenter.COMBO_SEG,
    )
"""

from ..data.conllu_reader import Document, Sentence, Token
from ..languages import SplitLevel
from .base import BaseSegmenter


class ComboSegSegmenter(BaseSegmenter):
    """Segmenter using the combo-seg library.

    Args:
        language: Language enum member or language name string. Used only
            when ``model_name`` is None — combo-seg then picks a default
            model for the language from its own HuggingFace registry.
        device: Torch device for the segmenter model.
        model_name: HuggingFace repo ID of a combo-seg model
            (e.g. ``"clarin-pl/combo-seg-xlm-roberta-base-english-ewt-ud2.17"``).
            When provided, this is loaded via ``ComboSeg.from_pretrained``.
        batch_size: Inference batch size for combo-seg.
        default_split_level: Default split level for segmentation.
            ``"SENTENCE"`` (default) splits turns into sentences.
            ``"TURN"`` treats each turn as a single sentence.
        default_split_multiwords: Default for multi-word token splitting.
            When ``True`` (default), MWTs are split into subwords
            (e.g. "can't" → "ca", "n't"). When ``False``, MWTs are kept
            as single tokens.
    """

    def __init__(
        self,
        language: "str | Language" = "Polish",
        device: str | None = None,
        model_name: str | None = None,
        batch_size: int = 8,
        default_split_level: "SplitLevel | str" = SplitLevel.SENTENCE,
        default_split_multiwords: bool = True,
    ):
        from ..languages import resolve_language

        lang = resolve_language(language)

        try:
            from combo_seg import ComboSeg
        except ImportError:
            raise ImportError(
                "combo-seg is not installed. Install it with:\n"
                "  pip install combo-seg\n"
                "Or use segmenter=Segmenter.LAMBO (default)."
            )

        if model_name is not None:
            print(f"  [combo-seg] loading model: {model_name!r}")
            self._seg = ComboSeg.from_pretrained(
                model_name, device=device, batch_size=batch_size
            )
        else:
            print(f"  [combo-seg] loading default model for language: {lang.value!r}")
            self._seg = ComboSeg(lang.value, device=device, batch_size=batch_size)

        self.language = lang
        self._model_name = model_name
        self._default_split_level = (
            default_split_level.upper()
            if isinstance(default_split_level, str)
            else default_split_level.value
        )
        self._default_split_multiwords = default_split_multiwords

    def __call__(
        self,
        doc: Document,
        split_level: "SplitLevel | str | None" = None,
        split_multiwords: bool | None = None,
    ) -> Document:
        """Segment text using combo-seg.

        Args:
            doc: Document with .text set.
            split_level: ``"SENTENCE"`` (default) splits turns into
                sentences. ``"TURN"`` treats each turn as a single sentence.
            split_multiwords: Whether to split multi-word tokens into
                subwords.

        Returns:
            Document with sentences and tokens from combo-seg segmentation.
        """
        if doc.sentences:
            return doc

        text = doc.text.strip()
        if not text:
            return Document(sentences=[], text=doc.text)

        level = (
            split_level.upper() if split_level is not None else self._default_split_level
        )
        multiwords = (
            split_multiwords if split_multiwords is not None
            else self._default_split_multiwords
        )

        # combo-seg accepts SplitLevel via string too.
        seg_doc = self._seg(text, split_level=level)

        sentences: list[Sentence] = []
        sent_idx = 0

        for turn in seg_doc.turns:
            if level == "TURN":
                all_tokens = []
                for sent in turn.sentences:
                    all_tokens.extend(sent.tokens)
                if all_tokens:
                    sent_idx += 1
                    tokens = self._convert_tokens(all_tokens, multiwords)
                    if tokens:
                        sentences.append(
                            Sentence(
                                tokens=tokens,
                                sent_id=f"s{sent_idx}",
                                text=turn.text,
                            )
                        )
            else:
                for sent in turn.sentences:
                    sent_idx += 1
                    tokens = self._convert_tokens(sent.tokens, multiwords)
                    if tokens:
                        sentences.append(
                            Sentence(
                                tokens=tokens,
                                sent_id=f"s{sent_idx}",
                                text=sent.text,
                            )
                        )

        return Document(sentences=sentences, text=doc.text)

    @staticmethod
    def _convert_tokens(seg_tokens: list, split_multiwords: bool) -> list[Token]:
        """Convert combo-seg tokens to COMBO Token objects.

        combo-seg tokens carry ``space_after`` directly, so we map that to
        CoNLL-U's ``SpaceAfter=No`` without re-scanning the source text.
        """
        tokens: list[Token] = []
        token_idx = 0

        for st in seg_tokens:
            misc = "_" if st.space_after else "SpaceAfter=No"
            if st.is_multi_word and st.subwords:
                if split_multiwords:
                    start_idx = token_idx + 1
                    end_idx = start_idx + len(st.subwords) - 1
                    mwt_info = (st.text, (start_idx, end_idx))
                    for i, subword in enumerate(st.subwords):
                        token_idx += 1
                        subword_misc = misc if i == len(st.subwords) - 1 else "_"
                        tokens.append(
                            Token(
                                id=str(token_idx),
                                form=subword,
                                multiword=mwt_info,
                                misc=subword_misc,
                            )
                        )
                else:
                    token_idx += 1
                    tokens.append(
                        Token(id=str(token_idx), form=st.text, misc=misc)
                    )
            else:
                token_idx += 1
                tokens.append(
                    Token(id=str(token_idx), form=st.text, misc=misc)
                )

        return tokens

    def __repr__(self) -> str:
        target = self._model_name or self.language.value
        return f"ComboSegSegmenter({target!r})"
