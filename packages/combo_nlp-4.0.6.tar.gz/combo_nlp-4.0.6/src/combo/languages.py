"""Supported languages for COMBO and LAMBO.

Usage::

    from combo import COMBO, Language

    nlp = COMBO(Language.POLISH)
    nlp = COMBO("Polish")  # string also works

    Language.POLISH.code  # "pl"
"""

from enum import Enum


class SplitLevel(str, Enum):
    """Controls sentence splitting granularity when using LAMBO segmenter.

    Usage::

        from combo import COMBO, SplitLevel

        nlp = COMBO("Polish")
        doc = nlp(text, split_level=SplitLevel.TURN)
    """

    SENTENCE = "SENTENCE"
    TURN = "TURN"


class Language(str, Enum):
    """Supported languages.

    Each member has a value (language name) and an ISO code accessible via .code.
    """

    def __new__(cls, name: str, code: str):
        obj = str.__new__(cls, name)
        obj._value_ = name
        obj.code = code
        return obj

    AFRIKAANS = ("Afrikaans", "af")
    ANCIENT_GREEK = ("Ancient_Greek", "grc")
    ANCIENT_HEBREW = ("Ancient_Hebrew", "he")
    ARABIC = ("Arabic", "ar")
    ARMENIAN = ("Armenian", "hy")
    BASQUE = ("Basque", "eu")
    BELARUSIAN = ("Belarusian", "be")
    BORORO = ("Bororo", "bor")
    BULGARIAN = ("Bulgarian", "bg")
    CATALAN = ("Catalan", "ca")
    CHINESE = ("Chinese", "zh")
    CLASSICAL_ARMENIAN = ("Classical_Armenian", "xcl")
    CLASSICAL_CHINESE = ("Classical_Chinese", "lzh")
    COPTIC = ("Coptic", "cop")
    CROATIAN = ("Croatian", "hr")
    CZECH = ("Czech", "cs")
    DANISH = ("Danish", "da")
    DUTCH = ("Dutch", "nl")
    ENGLISH = ("English", "en")
    ESTONIAN = ("Estonian", "et")
    FAROESE = ("Faroese", "fo")
    FINNISH = ("Finnish", "fi")
    FRENCH = ("French", "fr")
    GALICIAN = ("Galician", "gl")
    GERMAN = ("German", "de")
    GOTHIC = ("Gothic", "got")
    GREEK = ("Greek", "el")
    HAITIAN_CREOLE = ("Haitian_Creole", "ht")
    HEBREW = ("Hebrew", "he")
    HINDI = ("Hindi", "hi")
    HUNGARIAN = ("Hungarian", "hu")
    ICELANDIC = ("Icelandic", "is")
    INDONESIAN = ("Indonesian", "id")
    IRISH = ("Irish", "ga")
    ITALIAN = ("Italian", "it")
    JAPANESE = ("Japanese", "ja")
    KOREAN = ("Korean", "ko")
    LATIN = ("Latin", "la")
    LATVIAN = ("Latvian", "lv")
    LITHUANIAN = ("Lithuanian", "lt")
    MAGHREBI_ARABIC_FRENCH = ("Maghrebi_Arabic_French", "qaf")
    MALTESE = ("Maltese", "mt")
    MARATHI = ("Marathi", "mr")
    MIDDLE_FRENCH = ("Middle_French", "frm")
    NAIJA = ("Naija", "pcm")
    NORWEGIAN = ("Norwegian", "no")
    OLD_CHURCH_SLAVONIC = ("Old_Church_Slavonic", "cu")
    OLD_EAST_SLAVIC = ("Old_East_Slavic", "orv")
    OLD_FRENCH = ("Old_French", "fro")
    PERSIAN = ("Persian", "fa")
    POLISH = ("Polish", "pl")
    POMAK = ("Pomak", "pom")
    PORTUGUESE = ("Portuguese", "pt")
    ROMANIAN = ("Romanian", "ro")
    RUSSIAN = ("Russian", "ru")
    SANSKRIT = ("Sanskrit", "sa")
    SCOTTISH_GAELIC = ("Scottish_Gaelic", "gd")
    SERBIAN = ("Serbian", "sr")
    SINDHI = ("Sindhi", "sd")
    SLOVAK = ("Slovak", "sk")
    SLOVENIAN = ("Slovenian", "sl")
    SPANISH = ("Spanish", "es")
    SWEDISH = ("Swedish", "sv")
    TAMIL = ("Tamil", "ta")
    TELUGU = ("Telugu", "te")
    THAI = ("Thai", "th")
    TURKISH = ("Turkish", "tr")
    UKRAINIAN = ("Ukrainian", "uk")
    URDU = ("Urdu", "ur")
    UYGHUR = ("Uyghur", "ug")
    VIETNAMESE = ("Vietnamese", "vi")
    WELSH = ("Welsh", "cy")
    WESTERN_ARMENIAN = ("Western_Armenian", "hyw")
    WOLOF = ("Wolof", "wo")


# Example sentences for model cards ("The quick brown fox jumps over the lazy dog.")
EXAMPLE_SENTENCES: dict[Language, str] = {
    Language.AFRIKAANS: "Die vinnige bruin jakkals spring oor die lui hond.",
    Language.ANCIENT_GREEK: "\u1f29 \u03c4\u03b1\u03c7\u03b5\u1fd6\u03b1 \u03c6\u03b1\u03b9\u1f70 \u1f00\u03bb\u03ce\u03c0\u03b7\u03be \u1f51\u03c0\u1f72\u03c1 \u03c4\u03bf\u1fe6 \u1f00\u03c1\u03b3\u03bf\u1fe6 \u03ba\u03c5\u03bd\u1f78\u03c2 \u03c0\u03b7\u03b4\u1fb7.",
    Language.ANCIENT_HEBREW: "\u05d4\u05e9\u05d5\u05e2\u05dc \u05d4\u05d7\u05d5\u05dd \u05d4\u05de\u05d4\u05d9\u05e8 \u05e7\u05d5\u05e4\u05e5 \u05de\u05e2\u05dc \u05d4\u05db\u05dc\u05d1 \u05d4\u05e2\u05e6\u05dc\u05df.",
    Language.ARABIC: "\u0627\u0644\u062b\u0639\u0644\u0628 \u0627\u0644\u0628\u0646\u064a \u0627\u0644\u0633\u0631\u064a\u0639 \u064a\u0642\u0641\u0632 \u0641\u0648\u0642 \u0627\u0644\u0643\u0644\u0628 \u0627\u0644\u0643\u0633\u0648\u0644.",
    Language.ARMENIAN: "Արագ շագանակագույն աղվեսը թսկնում է ծույլ շան հատուկին.",
    Language.BASQUE: "Azeri marroi bizkorra txakur alferraren gainetik salto egiten du.",
    Language.BELARUSIAN: "\u0425\u0443\u0442\u043a\u0430\u044f \u0431\u0443\u0440\u0430\u044f \u043b\u0456\u0441\u0456\u0446\u0430 \u043f\u0435\u0440\u0430\u0441\u043a\u043e\u043a\u0432\u0430\u0435 \u0446\u0435\u0440\u0430\u0437 \u043b\u044f\u043d\u0456\u0432\u0430\u0433\u0430 \u0441\u0430\u0431\u0430\u043a\u0443.",
    Language.BULGARIAN: "\u0411\u044a\u0440\u0437\u0430\u0442\u0430 \u043a\u0430\u0444\u044f\u0432\u0430 \u043b\u0438\u0441\u0438\u0446\u0430 \u043f\u0440\u0435\u0441\u043a\u0430\u0447\u0430 \u043c\u044a\u0440\u0437\u0435\u043b\u0438\u0432\u043e\u0442\u043e \u043a\u0443\u0447\u0435.",
    Language.CATALAN: "La r\u00e0pida guineu marr\u00f3 salta per sobre el gos mandr\u00f3s.",
    Language.CHINESE: "\u654f\u6377\u7684\u68d5\u8272\u72d0\u72f8\u8df3\u8fc7\u4e86\u61d2\u72d7\u3002",
    Language.CLASSICAL_ARMENIAN: "Արագընթաց շագանակագոյն աղուէս ծոյլ շան վերայ ցատկէ։",
    Language.CLASSICAL_CHINESE: "\u8fc5\u8910\u72d0\u8e8d\u61f6\u72ac\u4e0a\u3002",
    Language.COPTIC: "Ⲁⲅⲧⲉⲓ ⲙⲁⲍⲣⲉ ⲟⲓⲁⲙⲟⲅⲥⲉ.",
    Language.CROATIAN: "Brza sme\u0111a lisica preska\u010de lijenog psa.",
    Language.CZECH: "Rychl\u00e1 hn\u011bd\u00e1 li\u0161ka sk\u00e1\u010de p\u0159es l\u00edn\u00e9ho psa.",
    Language.DANISH: "Den hurtige brune r\u00e6v springer over den dovne hund.",
    Language.DUTCH: "De snelle bruine vos springt over de luie hond.",
    Language.ENGLISH: "The quick brown fox jumps over the lazy dog.",
    Language.ESTONIAN: "Kiire pruun rebane h\u00fcppab \u00fcle laisa koera.",
    Language.FAROESE: "Sn\u00f8gga br\u00fana revin hoppar yvir dan d\u00f3vna hundin.",
    Language.FINNISH: "Nopea ruskea kettu hypp\u00e4\u00e4 laiskan koiran yli.",
    Language.FRENCH: "Le renard brun rapide saute par-dessus le chien paresseux.",
    Language.GALICIAN: "A r\u00e1pida raposa marr\u00f3n salta por riba do can preguiceiro.",
    Language.GERMAN: "Der schnelle braune Fuchs springt \u00fcber den faulen Hund.",
    Language.GOTHIC: "\ud800\udf43\ud800\udf30 \ud800\udf43\ud800\udf45\ud800\udf39\ud800\udf3d\ud800\udf38\ud800\udf30 \ud800\udf46\ud800\udf30\ud800\udf3f\ud800\udf37\ud800\udf43 \ud800\udf3f\ud800\udf43\ud800\udf37\ud800\udf3b\ud800\udf30\ud800\udf3f\ud800\udf40\ud800\udf39\ud800\udf38 \ud800\udf3f\ud800\udf46\ud800\udf30\ud800\udf42 \ud800\udf38\ud800\udf30\ud800\udf3d\ud800\udf30 \ud800\udf3b\ud800\udf30\ud800\udf44\ud800\udf30\ud800\udf3d\ud800\udf30 \ud800\udf37\ud800\udf3f\ud800\udf3d\ud800\udf33.",
    Language.GREEK: "\u0397 \u03b3\u03c1\u03ae\u03b3\u03bf\u03c1\u03b7 \u03ba\u03b1\u03c6\u03b5\u03c4\u03b9\u03ac \u03b1\u03bb\u03b5\u03c0\u03bf\u03cd \u03c0\u03b7\u03b4\u03ac\u03b5\u03b9 \u03c0\u03ac\u03bd\u03c9 \u03b1\u03c0\u03cc \u03c4\u03bf\u03bd \u03c4\u03b5\u03bc\u03c0\u03ad\u03bb\u03b7 \u03c3\u03ba\u03cd\u03bb\u03bf.",
    Language.HAITIAN_CREOLE: "Rena mawon rapid la sote sou chen parese a.",
    Language.HEBREW: "\u05d4\u05e9\u05d5\u05e2\u05dc \u05d4\u05d7\u05d5\u05dd \u05d4\u05de\u05d4\u05d9\u05e8 \u05e7\u05d5\u05e4\u05e5 \u05de\u05e2\u05dc \u05d4\u05db\u05dc\u05d1 \u05d4\u05e2\u05e6\u05dc\u05df.",
    Language.HINDI: "\u0924\u0947\u0937\u093c \u092d\u0942\u0930\u0940 \u0932\u094b\u092e\u0921\u093c\u0940 \u0906\u0932\u0938\u0940 \u0915\u0941\u0924\u094d\u0924\u0947 \u0915\u0947 \u090a\u092a\u0930 \u0915\u0942\u0926\u0924\u0940 \u0939\u0948\u0964",
    Language.HUNGARIAN: "A gyors barna r\u00f3ka \u00e1tugrik a lusta kutya felett.",
    Language.ICELANDIC: "Flj\u00f3ti br\u00fani refurinn hleypur yfir lata hundinn.",
    Language.INDONESIAN: "Rubah cokelat yang cepat melompati anjing yang malas.",
    Language.IRISH: "L\u00e9imeann an sionnach donn tapaidh thar an madra leisci\u00fail.",
    Language.ITALIAN: "La veloce volpe marrone salta sopra il cane pigro.",
    Language.JAPANESE: "\u7d20\u65e9\u3044\u8336\u8272\u306e\u72d0\u304c\u6020\u60f0\u306a\u72ac\u3092\u98db\u3073\u8d8a\u3048\u308b\u3002",
    Language.KOREAN: "\ube60\ub978 \uac08\uc0c9 \uc5ec\uc6b0\uac00 \uac8c\uc73c\ub978 \uac1c\ub97c \ub6f0\uc5b4\ub118\ub294\ub2e4.",
    Language.LATIN: "Vulpes brunnea velox super canem pigrum salit.",
    Language.LATVIAN: "\u0100tr\u0101 br\u016bn\u0101 lapsa lec p\u0101ri slinkajam sunim.",
    Language.LITHUANIAN: "Greita ruda lap\u0117 \u0161oka per tingin\u012f \u0161un\u012f.",
    Language.MAGHREBI_ARABIC_FRENCH: "\u0627\u0644\u062b\u0639\u0644\u0628 \u0627\u0644\u0628\u0646\u064a \u0627\u0644\u0633\u0631\u064a\u0639 \u064a\u0642\u0641\u0632 \u0641\u0648\u0642 \u0627\u0644\u0643\u0644\u0628 \u0627\u0644\u0643\u0633\u0648\u0644.",
    Language.MALTESE: "Il-volpi kannella \u0127afifa taqbe\u017c fuq il-kelb g\u0127a\u017c\u017cien.",
    Language.MARATHI: "\u091c\u0932\u0926 \u0924\u092a\u0915\u093f\u0930\u0940 \u0915\u094b\u0932\u094d\u0939\u093e \u0906\u0933\u0936\u0940 \u0915\u0941\u0924\u094d\u0930\u094d\u092f\u093e\u0935\u0930\u0942\u0928 \u0909\u0921\u0940 \u092e\u093e\u0930\u0924\u094b.",
    Language.MIDDLE_FRENCH: "Li goupil brun et viste saute par desus le chien paresseus.",
    Language.NAIJA: "Di fast brown fox jump pass di lazy dog.",
    Language.NORWEGIAN: "Den raske brune reven hopper over den late hunden.",
    Language.OLD_CHURCH_SLAVONIC: "\u0411\u0440\u044a\u0437\u0430 \u043b\u0438\u0441\u0438\u0446\u0430 \u043f\u0440\u0463\u0441\u043a\u0430\u0447\u0435\u0442\u044a \u0447\u0440\u0463\u0437\u044a \u043b\u0463\u043d\u0438\u0432\u0430\u0433\u043e \u043f\u044c\u0441\u0430.",
    Language.OLD_EAST_SLAVIC: "\u0411\u044a\u0440\u0437\u0430\u044f \u043b\u0438\u0441\u0438\u0446\u0430 \u043f\u0440\u0463\u0441\u043a\u0430\u0447\u0435\u0442\u044a \u0447\u0440\u0463\u0437\u044a \u043b\u0463\u043d\u0438\u0432\u0430\u0433\u043e \u043f\u044c\u0441\u0430.",
    Language.OLD_FRENCH: "Le goupil brun et viste saute par desus le chien paresseus.",
    Language.PERSIAN: "روباه قهوه‌ای چابک از روی سگ تنبل می‌پرد.",
    Language.POLISH: "Szybki br\u0105zowy lis przeskakuje nad leniwym psem.",
    Language.POMAK: "\u0411\u044a\u0440\u0437\u0430\u0442\u0430 \u043a\u0430\u0444\u044f\u0432\u0430 \u043b\u0438\u0441\u0438\u0446\u0430 \u043f\u0440\u0435\u0441\u043a\u0430\u0447\u0430 \u043c\u044a\u0440\u0437\u0435\u043b\u0438\u0432\u043e\u0442\u043e \u043a\u0443\u0447\u0435.",
    Language.PORTUGUESE: "A r\u00e1pida raposa marrom pula sobre o c\u00e3o pregui\u00e7oso.",
    Language.ROMANIAN: "Vulpea brun\u0103 \u0219i rapid\u0103 sare peste c\u00e2inele lene\u0219.",
    Language.RUSSIAN: "\u0411\u044b\u0441\u0442\u0440\u0430\u044f \u043a\u043e\u0440\u0438\u0447\u043d\u0435\u0432\u0430\u044f \u043b\u0438\u0441\u0430 \u043f\u0435\u0440\u0435\u043f\u0440\u044b\u0433\u0438\u0432\u0430\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u043b\u0435\u043d\u0438\u0432\u0443\u044e \u0441\u043e\u0431\u0430\u043a\u0443.",
    Language.SANSKRIT: "चपलः पिङ्गलवर्णः लोमशः आलस्यं श्वानम् अतिलङ्घयति।",
    Language.SCOTTISH_GAELIC: "Leum an sionnach donn luath thairis air a' ch\u00f9 leisg.",
    Language.SERBIAN: "\u0411\u0440\u0437\u0430 \u0441\u043c\u0435\u0452\u0430 \u043b\u0438\u0441\u0438\u0446\u0430 \u043f\u0440\u0435\u0441\u043a\u0430\u0447\u0435 \u043b\u0435\u045a\u043e\u0433 \u043f\u0441\u0430.",
    Language.SLOVAK: "R\u00fdchla hned\u00e1 l\u00ed\u0161ka sk\u00e1\u010de cez leniv\u00e9ho psa.",
    Language.SLOVENIAN: "Hitra rjava lisica sko\u010di \u010dez lenega psa.",
    Language.SPANISH: "El r\u00e1pido zorro marr\u00f3n salta sobre el perro perezoso.",
    Language.SWEDISH: "Den snabba bruna r\u00e4ven hoppar \u00f6ver den lata hunden.",
    Language.TAMIL: "வேகமான பழுப்பு நரி சோம்பேறி நாயின் மீது குதிக்கிறது.",
    Language.TELUGU: "వేగవంతమైన గోధుమ రంగు నక్క సోమరి కుక్క మీదుగా దూకుతుంది.",
    Language.THAI: "\u0e2a\u0e38\u0e19\u0e31\u0e02\u0e08\u0e34\u0e49\u0e07\u0e08\u0e2d\u0e01\u0e2a\u0e35\u0e19\u0e49\u0e33\u0e15\u0e32\u0e25\u0e17\u0e35\u0e48\u0e27\u0e48\u0e2d\u0e07\u0e44\u0e27\u0e01\u0e23\u0e30\u0e42\u0e14\u0e14\u0e02\u0e49\u0e32\u0e21\u0e2a\u0e38\u0e19\u0e31\u0e02\u0e02\u0e35\u0e49\u0e40\u0e01\u0e35\u0e22\u0e08",
    Language.TURKISH: "\u00c7evik kahverengi tilki tembel k\u00f6pe\u011fin \u00fczerinden atlar.",
    Language.UKRAINIAN: "\u0428\u0432\u0438\u0434\u043a\u0430 \u0440\u0443\u0434\u0430 \u043b\u0438\u0441\u0438\u0446\u044f \u043f\u0435\u0440\u0435\u0441\u0442\u0440\u0438\u0431\u0443\u0454 \u0447\u0435\u0440\u0435\u0437 \u043b\u0456\u043d\u0438\u0432\u043e\u0433\u043e \u043f\u0441\u0430.",
    Language.URDU: "تیز بھوری لومڑی سست کتّے کے اوپر کودتی ہے۔",
    Language.UYGHUR: "چاققان قوڭۇر تۈلكە ھۈرسەن ئىتنىڭ ئۈستىدىن سەكرەيدۇ.",
    Language.VIETNAMESE: "Con c\u00e1o n\u00e2u nhanh nh\u1eb9n nh\u1ea3y qua con ch\u00f3 l\u01b0\u1eddi.",
    Language.WELSH: "Mae'r llwynog brown cyflym yn neidio dros y ci diog.",
    Language.WESTERN_ARMENIAN: "Արագ շագանակագույն աղուեսը կը թսկէ ծույլ շունըն հատուկին.",
    Language.WOLOF: "Mbotaay bu xonk bu gaaw bi dox ci kaw mbam bu nekk ci suuf.",
}


class UnsupportedLanguageError(ValueError):
    """Raised when a language string is not recognized."""
    pass


class LanguageNotTrainedError(ValueError):
    """Raised when a language is recognized but has no trained COMBO model."""
    pass


def resolve_language(language: "str | Language") -> Language:
    """Resolve a language string or Language enum to a Language member.

    Args:
        language: Language enum member or name string (e.g. "Polish").

    Returns:
        Language enum member.

    Raises:
        UnsupportedLanguageError: If the language is not recognized.
    """
    if isinstance(language, Language):
        return language

    try:
        return Language(language)
    except ValueError:
        pass

    available = sorted(m.value for m in Language)
    raise UnsupportedLanguageError(
        f"Unknown language: {language!r}. "
        f"Available languages: {', '.join(available)}."
    )
