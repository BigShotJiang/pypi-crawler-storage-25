"""
simp_agent.client — The single class any agent needs to join SIMP.

Design principle: one class, zero statefulness questions.
Agents call methods, get responses. No background threads, no surprises.
"""

import json
import time
import logging
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from urllib.parse import urlparse
from enum import Enum

try:
    import requests
except ImportError:
    requests = None  # type: ignore

logger = logging.getLogger("simp_agent")


# ── Errors ──────────────────────────────────────────────────────────────────

class SimpAgentError(Exception):
    """Base error for all simp-agent operations."""
    pass


class RegistrationError(SimpAgentError):
    """Agent failed to register with the SIMP broker."""
    pass


class DiscoveryError(SimpAgentError):
    """Discovery query failed."""
    pass


class RoutingError(SimpAgentError):
    """Intent routing failed (network, auth, or remote error)."""
    pass


class PaymentError(SimpAgentError):
    """Payment operation failed."""
    pass


# ── Data Types ──────────────────────────────────────────────────────────────

@dataclass
class AgentInfo:
    """Information about a peer agent discovered on SIMP."""
    agent_id: str
    endpoint: str
    capabilities: List[str] = field(default_factory=list)
    trust_score: float = 5.0
    latency_ms: float = 0.0
    last_seen: str = ""
    wallet: str = ""


@dataclass
class RoutingResult:
    """Result of routing an intent to another agent."""
    success: bool
    status: str = ""
    response: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    latency_ms: float = 0.0
    remote_agent_id: str = ""


@dataclass
class WalletInfo:
    """Agent's SIMP Pay wallet state."""
    balance_simp: float = 0.0
    balance_micro: int = 0
    total_intents: int = 0
    total_fees_paid: int = 0


# ── SimpAgent ───────────────────────────────────────────────────────────────

class SimpAgent:
    """
    The single class any agent needs to join, discover, and transact on SIMP.
    
    Minimal interface:
        agent = SimpAgent(agent_id, private_key, endpoint, capabilities)
        agent.register()
        peers = agent.discover("code_review")
        result = agent.route_intent("simp://peer/inference", {"prompt": "..."})
    
    All HTTP to the SIMP broker. Zero statefulness. Zero threads.
    """

    def __init__(
        self,
        agent_id: str,
        private_key: str = "",
        endpoint: str = "",
        capabilities: Optional[List[str]] = None,
        broker_url: str = "https://simp.sh",
        auto_register: bool = False,
        timeout: float = 30.0,
    ):
        """
        Args:
            agent_id: Unique identifier for this agent (used as identity on SIMP).
            private_key: Ed25519 private key in hex. If empty, generates one.
            endpoint: Public URL where this agent receives intents.
            capabilities: List of capabilities this agent provides.
            broker_url: SIMP broker URL (default: https://simp.sh).
            auto_register: If True, calls register() on init.
            timeout: HTTP request timeout in seconds.
        """
        self.agent_id = agent_id
        self._private_key = private_key or self._generate_key()
        self._public_key = self._derive_public_key(self._private_key) if private_key else ""
        self.endpoint = endpoint
        self.capabilities = capabilities or []
        self.broker_url = broker_url.rstrip("/")
        self.timeout = timeout
        
        # Cached state
        self._wallet: Optional[WalletInfo] = None
        self._last_heartbeat: float = 0.0
        self._heartbeat_interval: float = 60.0  # seconds
        self._discovery_cache: Dict[str, List[AgentInfo]] = {}
        self._discovery_cache_ttl: float = 30.0  # seconds
        self._discovery_cache_time: float = 0.0

        if auto_register:
            self.register()

    # ── Public API ──────────────────────────────────────────────────────────

    def register(self) -> Dict[str, Any]:
        """
        Register this agent with the SIMP broker.
        
        POST /v1/agents/register
        
        Creates a SIMP Pay wallet with $1 starter credit.
        Returns the broker's response (includes wallet, agent_id, status).
        
        Raises:
            RegistrationError: If registration fails.
        """
        self._require_requests()
        
        payload = {
            "agent_id": self.agent_id,
            "public_key": self._public_key,
            "endpoint": self.endpoint,
            "capabilities": self.capabilities,
        }
        
        url = f"{self.broker_url}/v1/agents/register"
        
        try:
            resp = requests.post(url, json=payload, timeout=self.timeout)
        except requests.ConnectionError as e:
            raise RegistrationError(f"Cannot reach SIMP broker at {url}: {e}")
        except requests.Timeout:
            raise RegistrationError(f"Registration timed out after {self.timeout}s")
        
        if resp.status_code not in (200, 201):
            raise RegistrationError(
                f"Registration failed (HTTP {resp.status_code}): {resp.text[:500]}"
            )
        
        data = resp.json()
        logger.info("Agent %s registered with SIMP", self.agent_id)
        
        if "wallet" in data:
            w = data["wallet"]
            self._wallet = WalletInfo(
                balance_simp=w.get("balance", 0) / 1_000_000,
                balance_micro=w.get("balance", 0),
                total_intents=w.get("total_intents", 0),
                total_fees_paid=w.get("total_fees_paid", 0),
            )
        
        self._last_heartbeat = time.time()
        return data

    def discover(
        self,
        capability: str,
        min_trust: float = 0.0,
        max_results: int = 10,
        use_cache: bool = True,
    ) -> List[AgentInfo]:
        """
        Discover agents on SIMP by capability.
        
        POST /v1/agents/discover
        
        Returns trust-sorted list of agents that provide the requested capability.
        Results are cached for 30 seconds by default.
        
        Args:
            capability: Capability to search for (e.g., "code_review", "inference").
            min_trust: Minimum trust score (0.0 - 10.0).
            max_results: Maximum number of results to return.
            use_cache: If True, returns cached results within TTL.
        
        Raises:
            DiscoveryError: If the query fails.
        """
        self._require_requests()
        
        # Check cache
        cache_key = f"{capability}:{min_trust}"
        if use_cache and cache_key in self._discovery_cache:
            if time.time() - self._discovery_cache_time < self._discovery_cache_ttl:
                cached = self._discovery_cache[cache_key]
                return cached[:max_results]
        
        payload = {
            "capability": capability,
            "min_trust": min_trust,
            "max_results": max_results,
        }
        
        url = f"{self.broker_url}/v1/agents/discover"
        
        try:
            resp = requests.post(url, json=payload, timeout=self.timeout)
        except requests.ConnectionError as e:
            raise DiscoveryError(f"Cannot reach SIMP broker at {url}: {e}")
        except requests.Timeout:
            raise DiscoveryError(f"Discovery timed out after {self.timeout}s")
        
        if resp.status_code != 200:
            raise DiscoveryError(
                f"Discovery failed (HTTP {resp.status_code}): {resp.text[:500]}"
            )
        
        data = resp.json()
        agents = []
        for raw in data.get("agents", []):
            agents.append(AgentInfo(
                agent_id=raw.get("agent_id", ""),
                endpoint=raw.get("endpoint", ""),
                capabilities=raw.get("capabilities", []),
                trust_score=raw.get("trust_score", 5.0),
                latency_ms=raw.get("latency_ms", 0.0),
                last_seen=raw.get("last_seen", ""),
                wallet=raw.get("wallet", ""),
            ))
        
        # Cache results
        self._discovery_cache[cache_key] = agents
        self._discovery_cache_time = time.time()
        
        return agents[:max_results]

    def route_intent(
        self,
        target: str,
        payload: Dict[str, Any],
        mode: str = "sync",
        max_fee_simp: float = 0.01,
    ) -> RoutingResult:
        """
        Route an intent to a target agent on SIMP.
        
        If target is a simp:// URI, resolves it first.
        If target is an HTTP URL, sends directly.
        
        The SIMP broker handles discovery, routing, and micropayment.
        
        Args:
            target: simp:// URI or HTTP URL of the target agent.
            payload: Intent payload (JSON-serializable dict).
            mode: Invocation mode ("sync", "async", "stream", "batch", "fan", "chain").
            max_fee_simp: Maximum fee willing to pay in SIMP (default: $0.01).
        
        Returns:
            RoutingResult with response data and latency.
        
        Raises:
            RoutingError: If routing fails.
        """
        self._require_requests()
        
        start = time.time()
        resolved_endpoint = self._resolve_target(target)
        
        # Build the intent envelope per SIMP Agentic HTTPS spec
        intent_envelope = {
            "intent_id": f"{self.agent_id}:{int(time.time() * 1000)}:{hash(json.dumps(payload, sort_keys=True)) % 10**6}",
            "source_agent_id": self.agent_id,
            "target_agent_id": self._extract_agent_id(target),
            "capability": self._extract_capability(target),
            "payload": payload,
            "mode": mode,
            "max_fee_simp": max_fee_simp,
            "timestamp": time.time(),
        }
        
        try:
            resp = requests.post(
                resolved_endpoint,
                json=intent_envelope,
                headers={
                    "Content-Type": "application/json",
                    "X-SIMP-Agent": self.agent_id,
                    "X-SIMP-Protocol": "agentic-https-v1",
                },
                timeout=self.timeout,
            )
        except OSError as e:
            raise RoutingError(f"Cannot reach {resolved_endpoint}: {e}")
        except requests.Timeout:
            raise RoutingError(f"Intent routing timed out after {self.timeout}s to {resolved_endpoint}")
        except Exception as e:
            raise RoutingError(f"Network error connecting to {resolved_endpoint}: {e}")
        except Exception as e:
            raise RoutingError(f"Unexpected error routing to {resolved_endpoint}: {e}")
        
        elapsed_ms = (time.time() - start) * 1000
        
        if resp.status_code >= 500:
            return RoutingResult(
                success=False,
                status="error",
                error=f"Remote error (HTTP {resp.status_code}): {resp.text[:500]}",
                latency_ms=elapsed_ms,
            )
        
        try:
            data = resp.json()
        except json.JSONDecodeError:
            data = {"raw": resp.text[:1000]}
        
        return RoutingResult(
            success=200 <= resp.status_code < 300,
            status=str(resp.status_code),
            response=data,
            latency_ms=elapsed_ms,
            remote_agent_id=self._extract_agent_id(target),
        )

    def heartbeat(self) -> bool:
        """
        Send a heartbeat to the SIMP broker to stay registered.
        
        Returns True if the broker acknowledges the heartbeat.
        Agents should call this every 30-60 seconds.
        """
        self._require_requests()
        
        url = f"{self.broker_url}/v1/agents/{self.agent_id}/heartbeat"
        
        try:
            resp = requests.post(url, timeout=self.timeout)
        except (requests.ConnectionError, requests.Timeout):
            logger.warning("Heartbeat failed for %s", self.agent_id)
            return False
        
        if resp.status_code == 200:
            self._last_heartbeat = time.time()
            return True
        return False

    def get_wallet(self) -> WalletInfo:
        """
        Get this agent's SIMP Pay wallet info.
        
        Returns cached wallet data if available, otherwise fetches from broker.
        """
        self._require_requests()
        
        if self._wallet is not None:
            return self._wallet
        
        url = f"{self.broker_url}/v1/agents/{self.agent_id}/wallet"
        
        try:
            resp = requests.get(url, timeout=self.timeout)
        except (requests.ConnectionError, requests.Timeout):
            return WalletInfo()
        
        if resp.status_code != 200:
            return WalletInfo()
        
        data = resp.json()
        w = data.get("wallet", {})
        self._wallet = WalletInfo(
            balance_simp=w.get("balance", 0) / 1_000_000,
            balance_micro=w.get("balance", 0),
            total_intents=w.get("total_intents", 0),
            total_fees_paid=w.get("total_fees_paid", 0),
        )
        return self._wallet

    def register_capability(self, capability: str) -> Dict[str, Any]:
        """
        Add a new capability to this agent's registration.
        
        POST /v1/agents/{agent_id}/capabilities
        """
        self._require_requests()
        
        url = f"{self.broker_url}/v1/agents/{self.agent_id}/capabilities"
        
        resp = requests.post(url, json={"capability": capability}, timeout=self.timeout)
        
        if resp.status_code == 200:
            if capability not in self.capabilities:
                self.capabilities.append(capability)
        
        return resp.json() if resp.status_code == 200 else {"error": resp.text[:200]}

    def resolve_uri(self, uri: str) -> str:
        """
        Resolve a simp:// URI to an HTTP endpoint.
        
        This is a client-side resolution via the SIMP broker's resolver.
        """
        self._require_requests()
        
        if not uri.startswith("simp://"):
            return uri  # Already an HTTP URL
        
        url = f"{self.broker_url}/v1/resolve"
        
        resp = requests.post(url, json={"uri": uri}, timeout=self.timeout)
        
        if resp.status_code != 200:
            raise RoutingError(f"Cannot resolve {uri}: {resp.text[:200]}")
        
        data = resp.json()
        return data.get("endpoint", uri)

    # ── Internal helpers ────────────────────────────────────────────────────

    def _require_requests(self) -> None:
        if requests is None:
            raise SimpAgentError(
                "The `requests` library is required. Install with: pip install simp-agent[full]"
            )

    def _generate_key(self) -> str:
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
            key = Ed25519PrivateKey.generate()
            return key.private_bytes_raw().hex()
        except ImportError:
            logger.warning("cryptography not available, using ephemeral key")
            import os
            return os.urandom(32).hex()

    def _derive_public_key(self, private_key_hex: str) -> str:
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
            key = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(private_key_hex))
            return key.public_key().public_bytes_raw().hex()
        except ImportError:
            return ""

    def _resolve_target(self, target: str) -> str:
        if target.startswith("simp://"):
            return self.resolve_uri(target)
        return target

    def _extract_agent_id(self, target: str) -> str:
        """Extract agent ID from a simp:// URI or HTTP URL."""
        if target.startswith("simp://"):
            parts = target[7:].split("/")
            return parts[0] if parts else ""
        # HTTP URL — extract from hostname
        parsed = urlparse(target)
        return parsed.hostname or parsed.netloc or ""

    def _extract_capability(self, target: str) -> str:
        """Extract capability from a simp:// URI path."""
        if target.startswith("simp://"):
            parts = target[7:].split("/")
            return parts[1] if len(parts) > 1 else ""
        return ""


# ── Quick agent factory ─────────────────────────────────────────────────────

def create_agent(
    agent_id: str,
    endpoint: str,
    capabilities: List[str],
    broker_url: str = "https://simp.sh",
    auto_register: bool = True,
) -> SimpAgent:
    """
    Create and optionally register a SIMP agent in one call.
    
    Example:
        agent = create_agent(
            agent_id="my-code-reviewer",
            endpoint="https://my-server.com/simp",
            capabilities=["code_review", "security_audit"],
        )
        peers = agent.discover("code_review")
    """
    return SimpAgent(
        agent_id=agent_id,
        endpoint=endpoint,
        capabilities=capabilities,
        broker_url=broker_url,
        auto_register=auto_register,
    )
