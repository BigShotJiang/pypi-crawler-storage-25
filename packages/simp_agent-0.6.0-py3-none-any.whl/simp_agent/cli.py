"""
simp-agent CLI — Quick agent operations from the command line.

Usage:
    simp-agent register --id my-agent --endpoint https://...
    simp-agent discover cap=inference
    simp-agent route --target simp://peer/inference --prompt "hello"
    simp-agent wallet
"""

import sys
import json
import argparse
from typing import Dict, Any

from . import SimpAgent


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="simp-agent",
        description="Join, discover, and transact on SIMP Agentic HTTPS",
    )
    
    # Global options
    parser.add_argument("--broker", default="https://simp.sh", help="SIMP broker URL")
    parser.add_argument("--id", default="cli-agent", help="Agent ID")
    parser.add_argument("--key", default="", help="Ed25519 private key (hex)")
    parser.add_argument("--endpoint", default="", help="Agent's public endpoint")
    parser.add_argument("--cap", nargs="+", default=[], help="Capabilities")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    subparsers = parser.add_subparsers(dest="command")
    
    # register
    subparsers.add_parser("register", help="Register agent with SIMP broker")
    
    # discover
    discover_parser = subparsers.add_parser("discover", help="Discover agents by capability")
    discover_parser.add_argument("capability", nargs="?", default="inference", help="Capability to search for")
    discover_parser.add_argument("--min-trust", type=float, default=0.0, help="Minimum trust score")
    discover_parser.add_argument("--max", type=int, default=10, help="Max results")
    
    # route
    route_parser = subparsers.add_parser("route", help="Route an intent to another agent")
    route_parser.add_argument("--target", required=True, help="simp:// URI or HTTP URL")
    route_parser.add_argument("--prompt", default="Hello from CLI!", help="Intent payload")
    route_parser.add_argument("--mode", default="sync", help="Invocation mode")
    route_parser.add_argument("--max-fee", type=float, default=0.01, help="Max fee in SIMP")
    
    # wallet
    subparsers.add_parser("wallet", help="Check wallet balance")
    
    # heartbeat
    subparsers.add_parser("heartbeat", help="Send heartbeat")
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(1)
    
    agent = SimpAgent(
        agent_id=args.id,
        private_key=args.key,
        endpoint=args.endpoint,
        capabilities=args.cap,
        broker_url=args.broker,
    )
    
    try:
        if args.command == "register":
            result = agent.register()
            _print(result, args.json)
        
        elif args.command == "discover":
            cap = getattr(args, "capability", "inference")
            agents = agent.discover(cap, min_trust=args.min_trust, max_results=args.max)
            if args.json:
                print(json.dumps([a.__dict__ for a in agents], indent=2))
            else:
                print(f"Found {len(agents)} agent(s) for '{cap}':")
                for a in agents:
                    print(f"  {a.agent_id:30s} trust={a.trust_score:4.1f}  {a.capabilities[:3]}")
        
        elif args.command == "route":
            result = agent.route_intent(
                target=args.target,
                payload={"prompt": args.prompt},
                mode=args.mode,
                max_fee_simp=args.max_fee,
            )
            _print(result.__dict__, args.json)
        
        elif args.command == "wallet":
            wallet = agent.get_wallet()
            if args.json:
                print(json.dumps(wallet.__dict__, indent=2))
            else:
                print(f"Wallet: ${wallet.balance_simp:.6f} SIMP")
                print(f"Intents routed: {wallet.total_intents}")
                print(f"Fees paid: {wallet.total_fees_paid} micro-SIMP")
        
        elif args.command == "heartbeat":
            ok = agent.heartbeat()
            print(f"✅ Heartbeat OK" if ok else "❌ Heartbeat failed")
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def _print(data: Dict[str, Any], use_json: bool) -> None:
    if use_json:
        print(json.dumps(data, indent=2, default=str))
    else:
        for k, v in data.items():
            print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
