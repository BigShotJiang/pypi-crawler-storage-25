"""
simp-agent — Lightweight Python SDK for SIMP Agentic HTTPS.

The public API any agent needs to join, discover, and transact on SIMP.

Install:
    pip install simp-agent

Usage:
    from simp_agent import SimpAgent
    
    agent = SimpAgent(
        agent_id="my-agent-007",
        private_key="<ed25519_hex>",
        endpoint="https://my-agent.example.com/simp",
        capabilities=["code_review", "security_audit"],
    )
    agent.register()                    # POST /v1/agents/register
    peers = agent.discover("code_review")  # POST /v1/agents/discover
    result = agent.route_intent(
        target="simp://trusted-peer/inference",
        payload={"prompt": "Review this code"},
    )
"""

from .client import SimpAgent, SimpAgentError, RegistrationError, DiscoveryError, RoutingError

__version__ = "0.6.0"
__all__ = ["SimpAgent", "SimpAgentError", "RegistrationError", "DiscoveryError", "RoutingError"]
