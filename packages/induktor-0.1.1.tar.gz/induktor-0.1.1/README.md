# Induktor

Lightweight toolkit around PyTorch AOTInductor focusing on distribution and kernels compatibility
