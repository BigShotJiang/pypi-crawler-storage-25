from __future__ import annotations

import json
import warnings
from typing import Any, Callable, Iterable, Mapping, Optional, SupportsIndex, overload

import numpy as np
import numpy.typing as npt


def _normalize_byteorder(order: str) -> str:
    """Normalize a byte order string to a numpy dtype prefix.

    Accepts both human-readable strings ('big', 'little', 'native') and
    numpy dtype prefixes ('>', '<', '=').

    Args:
        order: Byte order specification.

    Returns:
        A single-character numpy dtype prefix: '>', '<', or '='.

    Raises:
        ValueError: If order is not a recognized byte order string.

    Examples:
        >>> _normalize_byteorder("big")
        '>'
        >>> _normalize_byteorder("<")
        '<'
        >>> _normalize_byteorder("native")
        '='
    """
    mapping = {"big": ">", "little": "<", "native": "="}
    if order in mapping:
        return mapping[order]
    if order in (">", "<", "="):
        return order
    msg = f"Invalid byte order: {order!r}. Use 'big'/'little'/'native' or '>'/'<'/'='."
    raise ValueError(msg)


def _word_size_to_machine_size(size: int) -> int:
    """Find the smallest machine size that contains the input size.

    Determine the machine word size (8, 16, 32, 64, 128) appropriate for an
    arbitrary input word size.

    Args:
        size: Word size in bits. Must be a positive integer <= 64.

    Returns:
        The smallest standard machine word size (8, 16, 32, or 64) that can
        contain the input size.

    Raises:
        ValueError: If size is <= 0 or > 64.

    Examples:
        >>> _word_size_to_machine_size(10)
        16
        >>> _word_size_to_machine_size(5)
        8
    """
    if size <= 0:
        msg = f"bit size {size!r} cannot be negative"
        raise ValueError(msg)
    elif size <= 8:  # noqa: PLR2004
        return 8
    elif size <= 16:  # noqa: PLR2004
        return 16
    elif size <= 32:  # noqa: PLR2004
        return 32
    elif size <= 64:  # noqa: PLR2004
        return 64
    msg = f"bit size {size!r} must be <= 64"
    raise ValueError(msg)


def _word_size_to_dtype(size: int) -> str:
    """Get numpy dtype string for a given word size.

    Converts a word size in bits to the corresponding numpy unsigned integer
    dtype string (e.g., 'u1', 'u2', 'u4', 'u8').

    Args:
        size: Word size in bits.

    Returns:
        A numpy dtype string in the format 'uN' where N is the number of bytes
        needed to store the word size.

    Examples:
        >>> _word_size_to_dtype(10)
        'u2'
        >>> _word_size_to_dtype(5)
        'u1'
    """
    return f"u{_word_size_to_machine_size(size) // 8}"


# ufuncs that can introduce bits beyond word_size
_ufuncs_that_need_masking = (
    np.invert,
    np.bitwise_invert,
    np.bitwise_xor,
    np.left_shift,
    np.add,
    np.subtract,
    np.multiply,
)


def _common_word_size(arrays: list[Any]) -> Optional[int]:
    """Return the shared word_size if all arrays are VarUIntArrays, else None.

    Args:
        arrays: List of arrays to check.

    Returns:
        The common word_size, or None if any array is not a VarUIntArray.

    Raises:
        ValueError: If all arrays are VarUIntArrays but have different word sizes.
    """
    if not all(isinstance(a, VarUIntArray) for a in arrays):
        return None
    word_sizes = {a.word_size for a in arrays}
    if len(word_sizes) > 1:
        msg = (
            f"Cannot combine VarUIntArrays with different "
            f"word sizes: {sorted(word_sizes)}"
        )
        raise ValueError(msg)
    return word_sizes.pop()


class VarUIntArray(np.ndarray):
    """Variable-length Unsigned Integer Array.

    This subclass of `np.ndarray` is intended to make it easier to use numpy ufuncs
    on an ndarray while respecting bits per word values that do not fit neatly into
    standard machine sizes (8, 16, 32, etc.). In other words, this ensures some
    ufuncs handle pad bits correctly.

    Attributes:
        input_array: The input array data.
        word_size: Number of significant bits per word (excludes padding bits).

    Examples:
        >>> arr = VarUIntArray([1, 2, 3], word_size=10)
        >>> arr.word_size
        10
    """

    input_array: npt.ArrayLike
    word_size: int

    def __new__(
        cls,
        input_array: npt.ArrayLike,
        word_size: int,
        byteorder: str = "native",
    ):
        """Create a new VarUIntArray instance.

        Args:
            input_array: Array-like data to be converted.
            word_size: Number of significant bits per word.
            byteorder: Byte order for the underlying dtype. Accepts
                'big', 'little', 'native' or '>', '<', '='.
                Defaults to 'native' (machine byte order).

        Returns:
            A new VarUIntArray instance.

        Raises:
            TypeError: If input_array has a non-numeric dtype
                (e.g. boolean, complex, string).
            ValueError: If byteorder is not a recognized byte order string.
        """
        # Reject non-numeric types that have no meaningful interpretation
        # as unsigned integers. We allow 'u' (unsigned int), 'i' (signed
        # int — the default for Python int lists), and 'f' (float — numpy
        # infers float64 for Python ints exceeding int64 range). The cast
        # to the target uint dtype below will catch actual invalid values.
        arr = np.asarray(input_array)
        if arr.dtype.kind not in ("u", "i", "f"):
            msg = (
                f"VarUIntArray requires unsigned integer data, "
                f"got dtype {arr.dtype!r} (kind='{arr.dtype.kind}'). "
                f"Convert to an unsigned integer array first."
            )
            raise TypeError(msg)

        prefix = _normalize_byteorder(byteorder)
        dtype = prefix + _word_size_to_dtype(word_size)

        obj = np.asarray(input_array, dtype=dtype).view(cls)

        obj.word_size = word_size
        obj.byteorder = prefix

        return obj

    def __array_finalize__(self, obj):
        """Finalize the array after creation.

        This method is called whenever the system allocates a new array from obj.
        Used to ensure word_size attribute is properly propagated.

        Args:
            obj: The object from which the array is being finalized.
        """
        # see InfoArray.__array_finalize__ for comments
        if obj is None:
            return
        self.word_size = getattr(obj, "word_size", 0)
        self.byteorder = getattr(obj, "byteorder", "=")

    @overload
    def __getitem__(self, key: SupportsIndex | tuple[SupportsIndex, ...], /) -> Any: ...
    @overload
    def __getitem__(self, key: Any, /) -> VarUIntArray: ...
    def __getitem__(self, key: Any, /) -> Any:  # type: ignore[override]
        return super().__getitem__(key)

    def __eq__(self, other):
        """Element-wise equality, requiring matching word_size for VarUIntArrays.

        Args:
            other: The object to compare against.

        Returns:
            A boolean ndarray of element-wise comparisons.

        Raises:
            ValueError: If other is a VarUIntArray with a different word_size.
        """
        if isinstance(other, VarUIntArray) and self.word_size != other.word_size:
            msg = (
                f"Cannot compare VarUIntArrays with different word sizes: "
                f"{self.word_size} vs {other.word_size}"
            )
            raise ValueError(msg)
        return super().__eq__(other)

    def __repr__(self) -> str:
        """Return a string representation of the VarUIntArray.

        Returns:
            A string representation that includes the word_size attribute.
        """
        base = super().__repr__()

        if hasattr(self, "word_size"):
            return base[:-1] + f", word_size={self.word_size})"
        return base

    def __array_wrap__(self, obj, context=None, return_scalar=False, /):
        """Wrap the result of a ufunc operation.

        Special handling for operations that can set padding bits to ensure
        they are correctly masked.

        Boolean results (from comparison ufuncs like ``==``, ``!=``, ``<``,
        etc.) are returned as plain ``np.ndarray`` rather than VarUIntArray,
        since boolean arrays have no meaningful word_size or padding bits.
        This ensures they work correctly as boolean masks for indexing.

        Args:
            obj: The result object from the ufunc.
            context: The ufunc context (function, arguments, output index).
            return_scalar: Whether to return a scalar.

        Returns:
            The wrapped result, with proper handling of pad bits for
            operations that can overflow or set bits beyond word_size.

        Notes:
            The following ufuncs can introduce bits beyond word_size and are
            automatically masked:
            - Bitwise: invert, bitwise_not, bitwise_or, bitwise_xor, left_shift
            - Arithmetic: add, subtract, multiply
        """
        if obj is self:  # for in-place operations
            result = obj
        else:
            result = obj.view(type(self))

        result = super().__array_wrap__(obj, context, return_scalar)

        # Boolean results (from comparisons like ==, !=, <, >, etc.) should
        # be plain ndarrays, not VarUIntArray. Boolean arrays have no
        # meaningful word_size, and wrapping them as VarUIntArray causes
        # downstream failures: e.g. ~bool_mask goes through the masking path
        # and converts to uint8, breaking boolean indexing.
        if result.dtype == np.bool_:
            return np.asarray(result)

        if context is not None:
            func, args, out_i = context

            # Check for mismatched word_size between VarUIntArray operands
            word_sizes = {a.word_size for a in args if isinstance(a, VarUIntArray)}
            if len(word_sizes) > 1:
                msg = (
                    f"Cannot apply {func.__name__} to VarUIntArrays with "
                    f"different word sizes: {sorted(word_sizes)}"
                )
                raise ValueError(msg)

            if func is np.subtract:
                # Detect underflow: if any result value has bits set
                # beyond word_size, the subtraction wrapped around.
                mask = 2**self.word_size - 1
                raw = result.view(np.ndarray)
                if np.any(raw != np.bitwise_and(raw, mask)):
                    msg = (
                        f"Subtraction resulted in unsigned integer underflow "
                        f"for word_size={self.word_size}. Use the plain "
                        f"ndarray view if you want wrapping semantics."
                    )
                    raise OverflowError(msg)

            if func in _ufuncs_that_need_masking:
                # Ensure ufuncs don't erroneously activate pad bits
                mask = 2**self.word_size - 1
                result = np.bitwise_and(result.view(np.ndarray), mask)
                return self.__class__(
                    result, word_size=self.word_size, byteorder=self.byteorder
                )

        return result

    def __array_function__(
        self,
        func: Callable[..., Any],
        types: Iterable[type],
        args: Iterable[Any],
        kwargs: Mapping[str, Any],
    ) -> Any:
        """Handle numpy array function protocol.

        Provides custom implementations for np.unpackbits, np.concatenate,
        and np.append to preserve VarUIntArray type when all inputs share
        the same word_size.

        Args:
            func: The numpy function being called.
            types: The types involved in the function call.
            args: Positional arguments to the function.
            kwargs: Keyword arguments to the function.

        Returns:
            The result of the function call.

        Raises:
            TypeError: If np.unpackbits is called with an axis argument.
            ValueError: If np.concatenate or np.append is called with
                VarUIntArrays that have different word sizes.
        """
        if func is np.unpackbits:
            array, *_ = args
            if "axis" in kwargs:
                msg = "axis keyword argument not valid when using np.unpackbits() on a VarUIntArray"
                raise TypeError(msg)
            return unpackbits(array)

        # For np.concatenate and np.append: if all inputs are VarUIntArrays
        # with the same word_size, perform the operation on plain ndarrays
        # and rewrap the result to preserve the VarUIntArray type.
        # If any input is not a VarUIntArray, fall through to default numpy
        # behavior (which will lose the word_size metadata).

        if func is np.concatenate:
            # np.concatenate takes a sequence of arrays as its first arg
            arrays, *_ = args
            arrays = list(arrays)
            word_size = _common_word_size(arrays)
            if word_size is not None:
                result = np.concatenate([np.asarray(a) for a in arrays], **kwargs)
                return VarUIntArray(
                    result, word_size=word_size, byteorder=self.byteorder
                )
            return super().__array_function__(func, types, args, kwargs)

        if func is np.append:
            # np.append takes two separate array arguments
            arr, values, *_ = args
            word_size = _common_word_size([arr, values])
            if word_size is not None:
                result = np.append(np.asarray(arr), np.asarray(values), **kwargs)
                return VarUIntArray(
                    result, word_size=word_size, byteorder=self.byteorder
                )
            return super().__array_function__(func, types, args, kwargs)

        if func is np.copy:
            array, *_ = args
            result = np.copy(np.asarray(array), **kwargs)
            return VarUIntArray(
                result, word_size=self.word_size, byteorder=self.byteorder
            )

        if func in (np.where, np.block):
            warnings.warn(
                f"{func.__name__}() does not preserve VarUIntArray type; "
                f"the result will be a plain ndarray (word_size lost). "
                f"Wrap the result with VarUIntArray(..., word_size=N) if needed.",
                stacklevel=2,
            )

        return super().__array_function__(func, types, args, kwargs)

    def append(self, value: int) -> "VarUIntArray":
        """Append a single value, returning a new VarUIntArray.

        Args:
            value: The unsigned integer value to append.

        Returns:
            A new VarUIntArray with the value appended.
        """
        return self.extend(value)

    def extend(self, values: npt.ArrayLike) -> "VarUIntArray":
        """Extend with multiple values, returning a new VarUIntArray.

        Args:
            values: Array-like of unsigned integer values to append.

        Returns:
            A new VarUIntArray with the values appended.
        """
        return VarUIntArray(
            np.append(np.asarray(self), values),
            word_size=self.word_size,
            byteorder=self.byteorder,
        )

    def invert(self) -> np.ndarray:
        """Invert the bits in the array, respecting word_size.

        Returns:
            A new array with all bits inverted, excluding pad bits.
        """
        return np.invert(self)

    def reversebits(self) -> "VarUIntArray":
        """Reverse the order of bits in each word, respecting word_size.

        Returns:
            A new VarUIntArray with the bit order of each word reversed.

        Examples:
            >>> arr = VarUIntArray([5, 3], word_size=3)
            >>> arr.reversebits()
            VarUIntArray([5, 6], dtype=uint8, word_size=3)
        """
        bits = self.unpackbits()
        return type(self).packbits(bits[..., ::-1], byteorder=self.byteorder)

    def unpackbits(self) -> np.ndarray:
        """Unpack the bits in each word, respecting word_size.

        Returns:
            An array with unpacked bits, excluding pad bits. The result has
            one additional dimension compared to the input.
        """
        return unpackbits(self)

    @classmethod
    def packbits(cls, data: np.ndarray, byteorder: str = "native") -> "VarUIntArray":
        """Pack an np.ndarray into a VarUIntArray.

        Args:
            data: Array to pack. The last dimension contains bits for each word.
            byteorder: Byte order for the result. Accepts
                'big', 'little', 'native' or '>', '<', '='.
                Defaults to 'native' (machine byte order).

        Returns:
            A VarUIntArray with packed bits.
        """
        return packbits(data, byteorder=byteorder)

    def to_dict(self) -> dict:
        """Serialize this VarUIntArray to a dictionary.

        Converts the VarUIntArray to a JSON-serializable dictionary format.

        Returns:
            A dictionary containing 'word_size' and 'values' keys.

        Examples:
            >>> arr = VarUIntArray([1, 2, 3], word_size=10)
            >>> arr.to_dict()
            {'word_size': 10, 'values': [1, 2, 3]}
        """
        return _serialize(self)

    @classmethod
    def from_dict(cls, data: dict) -> "VarUIntArray":
        """Validate and convert data to a VarUIntArray.

        Args:
            data: Either a VarUIntArray instance or a dictionary containing
                'values' and 'word_size' keys.

        Returns:
            A validated VarUIntArray instance.

        Raises:
            TypeError: If data cannot be converted to a VarUIntArray.

        Examples:
            >>> VarUIntArray.from_dict({"values": [1, 2, 3], "word_size": 10})
            VarUIntArray([1, 2, 3], dtype='>u2', word_size=10)
        """
        return _validate(data)

    def to_json(self) -> str:
        """Serialize this VarUIntArray to a JSON string.

        Returns:
            A JSON string representation of the VarUIntArray.

        Examples:
            >>> arr = VarUIntArray([1, 2, 3], word_size=10)
            >>> arr.to_json()
            '{"word_size": 10, "values": [1, 2, 3]}'
        """
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, string: str) -> "VarUIntArray":
        """Deserialize a VarUIntArray from a JSON string.

        Args:
            string: A JSON string containing 'word_size' and 'values' keys.

        Returns:
            A VarUIntArray instance created from the JSON data.

        Raises:
            json.JSONDecodeError: If the string is not valid JSON.
            TypeError: If the JSON data cannot be converted to a VarUIntArray.

        Examples:
            >>> json_str = '{"word_size": 10, "values": [1, 2, 3]}'
            >>> arr = VarUIntArray.from_json(json_str)
            >>> arr
            VarUIntArray([1, 2, 3], dtype='>u2', word_size=10)
        """
        return cls.from_dict(json.loads(string))


def _validate(data) -> VarUIntArray:
    """Validate and convert data to a VarUIntArray.

    Args:
        data: Either a VarUIntArray instance or a dictionary containing
            'values' and 'word_size' keys.

    Returns:
        A validated VarUIntArray instance.

    Raises:
        TypeError: If data cannot be converted to a VarUIntArray.

    Examples:
        >>> arr = VarUIntArray([1, 2, 3], word_size=10)
        >>> _validate(arr) is arr
        True
        >>> _validate({"values": [1, 2, 3], "word_size": 10})
        VarUIntArray([1, 2, 3], dtype='>u2', word_size=10)
    """
    if isinstance(data, VarUIntArray):
        return data

    if isinstance(data, dict):
        array = data["values"]
        word_size = data["word_size"]
        byteorder = data.get("byteorder", "native")
        return VarUIntArray(array, word_size=word_size, byteorder=byteorder)

    msg = f"Cannot convert {data!r} to VarUIntArray"
    raise TypeError(msg)


def _serialize(data: VarUIntArray) -> dict[str, Any]:
    """Serialize a VarUIntArray to a dictionary.

    Converts a VarUIntArray to a JSON-serializable dictionary format.

    Args:
        data: The VarUIntArray to serialize.

    Returns:
        A dictionary containing 'word_size' and 'values' keys.

    Examples:
        >>> arr = VarUIntArray([1, 2, 3], word_size=10)
        >>> _serialize(arr)
        {'word_size': 10, 'values': [1, 2, 3]}
    """
    # Map numpy prefix back to human-readable name for serialization
    prefix_to_name = {">": "big", "<": "little", "=": "native"}
    return {
        "word_size": data.word_size,
        "byteorder": prefix_to_name.get(data.byteorder, "native"),
        "values": data.tolist(),
    }


def unpackbits(array: VarUIntArray) -> np.ndarray:
    """Unpack the bits in the array, respecting word_size.

    Works like `np.unpackbits`, but uses word_size to exclude padding bits.

    The resulting `np.ndarray` will have one additional dimension. The new
    (innermost) dimension will have size equal to array.word_size.

    Args:
        array: The VarUIntArray to unpack.

    Returns:
        An ndarray with unpacked bits. The result has one additional dimension
        compared to the input, where the innermost dimension contains the
        unpacked bits (size = array.word_size).

    Notes:
        This replicates the functionality of `np.unpackbits` but uses the
        word_size attribute to omit the pad bits used in the underlying
        numpy dtype.

        Additionally, using the innermost dimension removes ambiguity about
        the VarUIntArray word_size.

    Examples:
        >>> arr = VarUIntArray([5], word_size=3)
        >>> unpackbits(arr)
        array([[1, 0, 1]], dtype=uint8)
    """
    shape = array.shape
    result = array.view(np.ndarray)

    # np.unpackbits expects bytes in big-endian (MSB-first) order.
    # If the data is not big-endian, convert before unpacking.
    if result.dtype.byteorder not in (">", "|"):
        result = result.astype(result.dtype.newbyteorder(">"))

    # Add a dimension such that each word is indexed in the innermost dimension
    result = result.reshape(*shape, 1)

    # Convert to a regular ndarray with 8-bit words
    # this preps it for np.unpackbits
    result = result.view("u1")

    # Unpack bits in each word
    result = np.unpackbits(result, axis=result.ndim - 1)

    # Slice the array keeping everything except the pad bits in the deepest index level
    # e.g. for a 10-bit word packed into a uint16, return the lower 10 bits
    # The implementation here is an N-dimensional generalization of, e.g.
    # 1-d array [:, -array.word_size:]
    # 2-d array [:, :, -array.word_size:]
    slices = (slice(None),) * (result.ndim - 1) + (slice(-array.word_size, None),)
    result = result[slices]

    return result


def packbits(array: np.ndarray, byteorder: str = "native") -> VarUIntArray:
    """Pack an np.ndarray into a VarUIntArray.

    This works for N-dimensional arrays, but the last (innermost) dimension
    must contain the bits within each word. The word_size attribute is
    determined by the size of the last dimension (i.e. array.shape[-1]).

    The resulting `VarUIntArray` will have ndim one less than the input array.

    Args:
        array: The array containing bits to pack. Must have dtype np.uint8
            and contain only zeros and ones. The last dimension contains
            the bits for each word.
        byteorder: Byte order for the result. Accepts
            'big', 'little', 'native' or '>', '<', '='.
            Defaults to 'native' (machine byte order).

    Returns:
        A VarUIntArray with packed bits. The result has one fewer dimension
        than the input, with word_size set to the size of the input's last
        dimension.

    Examples:
        >>> bits = np.array([[1, 0, 1], [0, 1, 1]], dtype=np.uint8)
        >>> packbits(bits)
        VarUIntArray([5, 3], dtype=uint8, word_size=3)
    """
    prefix = _normalize_byteorder(byteorder)

    shape = array.shape
    ndim = array.ndim
    word_size = shape[-1]

    # Determine appropriate number of pad bits
    pad = _word_size_to_machine_size(word_size) - word_size

    # Dynamically create pad tuples
    # 1. Pad 0 before, 0 after for each dimension except the last
    # 2. Pad N before, 0 after for the last dimension to get to necessary machine word size
    pad = ((0, 0),) * (ndim - 1) + ((pad, 0),)
    result = np.pad(array, pad, mode="constant")

    # Pack padded bits back into words
    result = np.packbits(result, axis=-1)

    # np.packbits produces bytes in MSB-first order, which corresponds
    # to big-endian byte layout. View as big-endian first, then convert
    # to the target byte order if needed.
    be_dtype = ">" + _word_size_to_dtype(word_size)
    result = result.view(be_dtype)

    if prefix != ">":
        target_dtype = prefix + _word_size_to_dtype(word_size)
        result = result.astype(target_dtype)

    # Drop innermost dimension
    result = result.squeeze(axis=-1)

    return VarUIntArray(result, word_size=word_size, byteorder=prefix)
