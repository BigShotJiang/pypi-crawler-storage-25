def main():
    print("Hello from nuki!")


if __name__ == "__main__":
    main()
