# Changelog

## [0.2.0] — 2026-05-03

### Changed
- Package renamed `portmap-mcp` → `portmap`
- HTTP REST API (`:7848`) est maintenant l'interface principale, pas le MCP
- `portmap daemon` démarre le daemon HTTP en foreground ; MCP SSE en thread optionnel
- MCP server déplacé en extra : `pip install portmap[mcp]`
- `portmap-mcp` retourne une erreur explicite si l'extra MCP n'est pas installé
- `portmap setup` : configuration MCP conditionnelle selon l'installation

### Added
- Dépendance `filelock` pour la sécurité cross-process sur `~/.portmap/state.json`
- `_try_start_mcp()` : démarrage MCP non-bloquant avec `ImportError` silencieux

### Fixed
- `portmap setup` ne plante plus si aucun agent MCP n'est détecté

---

## [0.1.0] — 2026-05-03

### Added
- Daemon de gestion de ports : ledger persistant dans `~/.portmap/state.json`
- Scanner système (psutil) : détection des ports actifs toutes les 5s
- Résolveur de 200+ services connus vers ports par défaut
- Patch de `docker-compose.yml` : détection et résolution des conflits
- HTTP REST API : `/health`, `/snapshot`, `/claim`, `/release`, `/allocate`, `/status`, `/audit`
- MCP server SSE + stdio : interface pour agents IA (Claude Code, Cursor, Windsurf)
- CLI : `portmap setup|daemon|status|audit|snapshot`
- Reporting Archipel : heartbeat optionnel via variables d'environnement
