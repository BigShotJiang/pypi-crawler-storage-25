# portmap — Port authority for developers and AI agents

One daemon. All your projects share the same truth about ports. Never get `address already in use` again.

## What it does

Portmap runs as a background service on your machine. It tracks every port in use, remembers allocations across sessions, and hands out conflict-free ports on demand — to you, your scripts, or your AI agents.

```
Claude Code (project A) ──┐
Script CI (project B) ─────┤──→ portmap daemon :7848 ──→ machine ports
Cursor (project C) ────────┘        (one instance, one truth)
```

## Install

```bash
pip install portauthority
portmap setup
portmap daemon
```

With AI agent integration (Claude Code, Cursor, Windsurf):

```bash
pip install portauthority[mcp]
portmap setup   # auto-configures MCP in detected agents
portmap daemon
```

## Deployment

### On the host (recommended)

The simplest and most complete setup. portmap sees all machine ports.

```bash
pip install portauthority
portmap daemon          # REST API on http://localhost:7848
```

### Inside Docker — Linux

On a Linux host, use `network_mode: host` so portmap sees the real machine ports:

```yaml
services:
  myapp:
    image: myapp
    network_mode: host
```

### Inside Docker — Windows / Mac

`network_mode: host` is not supported on Docker Desktop.
Run portmap on the host instead, then query it from your containers via `host.docker.internal`:

```bash
# On your Windows/Mac host
pip install portauthority
portmap daemon
```

```yaml
# docker-compose.yml
services:
  myapp:
    image: myapp
    extra_hosts:
      - "host.docker.internal:host-gateway"
```

Your app queries portmap at `http://host.docker.internal:7848`.

### Scope visibility

| Setup | Sees host ports | Process info |
|-------|----------------|--------------|
| Host (any OS) | ✅ | ✅ |
| Docker + `network_mode: host` (Linux) | ✅ | ✅ |
| Docker Desktop — Windows/Mac, no host daemon | ❌ | ❌ |
| Docker Desktop — Windows/Mac + host daemon | ✅ via HTTP | ✅ |

## Usage

### REST API (`:7848`)

```bash
# Current machine state
curl http://localhost:7848/snapshot

# Claim a port for a project
curl -X POST http://localhost:7848/claim \
  -H "Content-Type: application/json" \
  -d '{"port": 8080, "service": "fastapi", "project": "myapp"}'

# Allocate conflict-free ports
curl -X POST http://localhost:7848/allocate \
  -H "Content-Type: application/json" \
  -d '{"services": ["postgres", "fastapi", "react"], "project": "myapp"}'

# Release all ports for a project
curl -X POST http://localhost:7848/release \
  -H "Content-Type: application/json" \
  -d '{"project": "myapp"}'
```

### CLI

```bash
portmap setup       # Scan machine, configure MCP agents if portmap[mcp] installed
portmap daemon      # Start daemon (REST API on :7848, MCP SSE on :7847 if [mcp])
portmap snapshot    # Current machine state as JSON
portmap status      # All projects and their ports
portmap audit       # Find problems (ghosts, squatters, expiring reservations)
```

### MCP tool (requires `portmap[mcp]`)

Agents call the `portmap` MCP tool automatically before generating any code that opens a port:

| Intent | What it does |
|--------|-------------|
| `snapshot` | Current port state — what's free, what's busy |
| `allocate` | Get conflict-free ports for a list of services |
| `check_compose` | Analyze and patch a `docker-compose.yml` |
| `release` | Free ports when a project is done |
| `claim` | Adopt an unmanaged port into the ledger |
| `status` | All projects and their ports |
| `audit` | Find ghosts, squatters, expiring reservations |
| `history` | Past allocations for a project |

## Key features

- **Single daemon** — one HTTP server on `:7848`, all callers share the same state
- **Memory** — remembers allocations even when services stop (10-day TTL by default)
- **200+ known services** — postgres=5432, redis=6379, ollama=11434, and more
- **Docker-aware** — patches compose files, touches only host ports
- **MCP optional** — core works with zero AI tooling; add `portmap[mcp]` for agent integration

## Configuration

Works zero-config. Customize in `~/.portmap/config.yaml`:

```yaml
ranges:
  database:  [10000, 10199]
  api:       [10200, 10399]
  frontend:  [10400, 10599]

ttl_days: 10
reserved_ports: [9090, 4200]
```

## Archipel integration

Portmap can report port state to an [Archipel](https://github.com/nic01asFr/Archipel) node coordinator:

```bash
ARCHIPEL_URL=https://archipel.example.com \
PORTMAP_NODE_ID=my-machine \
portmap daemon
```

## License

MIT
