"""portmap setup — scan machine state and optionally configure MCP agents."""

from __future__ import annotations
import json
import subprocess
import shutil
from pathlib import Path

from .daemon import Daemon, PORTMAP_DIR, CONFIG_FILE

AGENTS = {
    "Claude Code": {
        "detect": [Path.home() / ".claude"],
        "config": Path.home() / ".claude" / "mcp.json",
        "setup_method": "cli",
    },
    "Cursor": {
        "detect": [Path.home() / ".cursor"],
        "config": Path.home() / ".cursor" / "mcp.json",
        "setup_method": "json",
    },
    "Windsurf": {
        "detect": [Path.home() / ".codeium" / "windsurf"],
        "config": Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
        "setup_method": "json",
    },
}


def setup():
    print("\n  portmap setup\n")

    PORTMAP_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text("# portmap configuration\n# See docs for options\n")
        print("  Created ~/.portmap/config.yaml")
    else:
        print("  Config exists")

    print("\n  Scanning machine state...")
    daemon = Daemon()
    daemon.reconcile()
    leased = sum(1 for e in daemon.ledger.values() if e.status.value == "leased")
    squatters = sum(1 for e in daemon.ledger.values() if e.status.value == "squatter")
    print(f"    {len(daemon.ledger)} ports detected, {leased} active, {squatters} unmanaged")

    _generate_agents_md(daemon)
    print("    Generated ~/.portmap/AGENTS.md")

    # MCP agent config — only if portmap[mcp] is installed
    try:
        import mcp  # noqa: F401
        _configure_mcp_agents()
    except ImportError:
        print("\n  MCP agent integration skipped (install portmap[mcp] to enable)")

    print(f"\n  Done. Run 'portmap daemon' to start the REST API on :7848.\n")


def _configure_mcp_agents():
    print("\n  Configuring MCP agents...")
    for name, info in AGENTS.items():
        if not any(p.exists() for p in info["detect"]):
            continue
        try:
            if info["setup_method"] == "cli" and name == "Claude Code":
                _setup_claude_code()
            else:
                _setup_json_config(info["config"])
            print(f"    + {name}: configured")
        except Exception as e:
            print(f"    ! {name}: failed ({e})")


def _setup_claude_code():
    if shutil.which("claude"):
        try:
            subprocess.run(
                ["claude", "mcp", "add", "portmap", "--", "portmap-mcp"],
                capture_output=True, timeout=10,
            )
            return
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
    _setup_json_config(AGENTS["Claude Code"]["config"])


def _setup_json_config(config_path: Path):
    config_path.parent.mkdir(parents=True, exist_ok=True)
    existing = {}
    if config_path.exists():
        try:
            existing = json.loads(config_path.read_text())
        except json.JSONDecodeError:
            existing = {}
    if "mcpServers" not in existing:
        existing["mcpServers"] = {}
    existing["mcpServers"]["portmap"] = {"command": "portmap-mcp", "args": []}
    config_path.write_text(json.dumps(existing, indent=2) + "\n")


def _generate_agents_md(daemon: Daemon):
    lines = [
        "# portmap — current port state",
        "<!-- Auto-generated. Do not edit. -->",
        "",
        "## Occupied ports — do not use in new projects",
        "",
        "| Port | Service | Project | Status |",
        "|------|---------|---------|--------|",
    ]
    for port, entry in sorted(daemon.ledger.items()):
        proj = entry.project or "-"
        lines.append(f"| {port} | {entry.service} | {proj} | {entry.status.value} |")

    lines.extend([
        "",
        "## Usage",
        "- HTTP API: POST http://localhost:7848/claim — claim a port",
        "- CLI: portmap snapshot — full state as JSON",
        "",
    ])
    (PORTMAP_DIR / "AGENTS.md").write_text("\n".join(lines) + "\n")
