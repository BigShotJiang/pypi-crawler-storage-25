"""Resolve service names to category and default port.

Loads the built-in known_services.yaml and optional user custom services.
Handles aliases ("pg" → postgres, "chroma" → chromadb, etc.)
"""

from __future__ import annotations
import yaml
from pathlib import Path
from dataclasses import dataclass

KNOWN_SERVICES_PATH = Path(__file__).parent / "data" / "known_services.yaml"
USER_SERVICES_PATH = Path.home() / ".portmap" / "services.yaml"


@dataclass(frozen=True)
class ServiceInfo:
    name: str
    category: str
    default_port: int


class Resolver:
    def __init__(self):
        self._by_name: dict[str, ServiceInfo] = {}
        self._load_known()
        self._load_user()

    def _load_known(self):
        with open(KNOWN_SERVICES_PATH) as f:
            data = yaml.safe_load(f)
        for category, services in data.items():
            for name, info in services.items():
                si = ServiceInfo(name=name, category=category, default_port=info["port"])
                self._by_name[name] = si
                for alias in info.get("aliases", []):
                    self._by_name[alias] = si

    def _load_user(self):
        if not USER_SERVICES_PATH.exists():
            return
        with open(USER_SERVICES_PATH) as f:
            data = yaml.safe_load(f) or {}
        for name, info in data.get("custom_services", {}).items():
            si = ServiceInfo(
                name=name,
                category=info.get("category", "general"),
                default_port=info.get("default_port", 0),
            )
            self._by_name[name] = si
            for alias in info.get("aliases", []):
                self._by_name[alias] = si

    def resolve(self, name: str) -> ServiceInfo:
        """Resolve a service name (or alias) to ServiceInfo.
        Returns a generic entry if unknown."""
        key = name.lower().strip()
        if key in self._by_name:
            return self._by_name[key]
        return ServiceInfo(name=key, category="general", default_port=0)

    def all_known_ports(self) -> set[int]:
        """Return all default ports from the known services DB."""
        return {si.default_port for si in self._by_name.values() if si.default_port > 0}
