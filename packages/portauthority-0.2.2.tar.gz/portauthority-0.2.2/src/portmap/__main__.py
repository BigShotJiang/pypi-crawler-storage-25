"""portmap CLI — entry point for all commands.

Usage:
    portmap setup        Auto-detect agents, configure MCP, initial scan
    portmap daemon       Start the daemon (foreground)
    portmap status       Quick status check (connects to daemon or runs standalone)
    portmap audit        Run audit report
    portmap snapshot     Print current snapshot as JSON
"""

from __future__ import annotations
import sys
import json
import logging


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [portmap] %(message)s",
        datefmt="%H:%M:%S",
    )

    if len(sys.argv) < 2:
        _print_usage()
        return

    cmd = sys.argv[1]

    if cmd == "setup":
        from .setup_cmd import setup
        setup()

    elif cmd == "daemon":
        _run_daemon()

    elif cmd == "status":
        _run_quick("status")

    elif cmd == "audit":
        _run_quick("audit")

    elif cmd == "snapshot":
        _run_quick("snapshot")

    elif cmd in ("-h", "--help", "help"):
        _print_usage()

    else:
        print(f"Unknown command: {cmd}")
        _print_usage()


def _run_daemon():
    """Start the daemon: REST HTTP API (core) + MCP SSE if portmap[mcp] is installed."""
    import time
    from .daemon import Daemon

    daemon = Daemon()
    daemon.reconcile()

    http_port = daemon.config.http_port
    mcp_port = daemon.config.port

    _start_http_api(daemon, http_port)
    mcp_started = _try_start_mcp(daemon, mcp_port)

    print(f"\n  portmap daemon running")
    print(f"    REST API    → http://127.0.0.1:{http_port}")
    if mcp_started:
        print(f"    MCP SSE     → http://127.0.0.1:{mcp_port}")
    print(f"    {daemon._summary()}")
    print(f"  Press Ctrl+C to stop.\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n  Daemon stopped.")


def _try_start_mcp(daemon, port: int) -> bool:
    try:
        import threading
        from .server import create_mcp_server
        mcp = create_mcp_server(daemon)
        t = threading.Thread(
            target=lambda: mcp.run(transport="sse", host="127.0.0.1", port=port),
            name="portmap-mcp",
            daemon=True,
        )
        t.start()
        return True
    except Exception:
        return False


def _start_http_api(daemon, port: int) -> None:
    """Start the REST HTTP API in a background thread."""
    import threading

    import uvicorn

    from .http_api import create_app

    import os
    app = create_app(daemon)
    bind_host = os.getenv("PORTMAP_BIND_HOST", "0.0.0.0")
    config = uvicorn.Config(app, host=bind_host, port=port, log_level="warning")
    server = uvicorn.Server(config)

    t = threading.Thread(target=server.run, name="portmap-http", daemon=True)
    t.start()


def _run_quick(intent: str):
    """Run a quick query without starting a full daemon."""
    from .daemon import Daemon

    daemon = Daemon()
    daemon.reconcile()

    if intent == "status":
        result = daemon.status()
    elif intent == "audit":
        result = daemon.audit()
    elif intent == "snapshot":
        result = daemon.snapshot()
    else:
        result = {"error": f"Unknown intent: {intent}"}

    print(json.dumps(result, indent=2))


def _print_usage():
    print("""
  portmap — Port authority for developers and AI agents

  Usage:
    portmap setup       Scan machine and write initial state
    portmap daemon      Start the shared daemon (REST API on :7848)
    portmap status      Show current port state
    portmap audit       Find problems (ghosts, squatters, conflicts)
    portmap snapshot    Full machine snapshot as JSON

  Optional (requires pip install portmap[mcp]):
    portmap-mcp         Stdio MCP server for AI agent integration
""")


if __name__ == "__main__":
    main()
