"""HTTP REST API for Portmap.

Used by inter-service communication on the local machine:
  - ResourceManager calls /claim and /release on container start/stop
  - MachineAgent (or any local tool) calls /snapshot to read live state

This API is intentionally local-only. It runs alongside the MCP server
on the same daemon instance, sharing the same Daemon object (and lock).

Endpoints:
  POST /claim    body: {port, service, project, category}
  POST /release  body: {port}
  GET  /snapshot
  GET  /health

Default bind: 127.0.0.1:7848 (next to MCP at 7847).
"""

from __future__ import annotations

import logging

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .daemon import Daemon

log = logging.getLogger("portmap.http")


class ClaimRequest(BaseModel):
    port: int = Field(ge=1, le=65535)
    service: str
    project: str = "unassigned"
    category: str = "general"


class ReleaseRequest(BaseModel):
    port: int = Field(ge=1, le=65535)


def create_app(daemon: Daemon) -> FastAPI:
    """Build the FastAPI app bound to a specific daemon instance."""
    app = FastAPI(title="Portmap HTTP API", version="0.1.0", docs_url="/docs")

    @app.get("/health", tags=["system"])
    def health() -> dict:
        return {"status": "ok"}

    @app.get("/snapshot", tags=["query"])
    def snapshot() -> dict:
        return daemon.snapshot()

    @app.post("/claim", tags=["allocation"])
    def claim(req: ClaimRequest) -> dict:
        """Adopt an active port into managed state.

        If the port is currently a SQUATTER, claims it. If it's not yet in
        the ledger (ResourceManager started a service Portmap hasn't scanned
        yet), this triggers a reconcile first then retries.
        """
        result = daemon.claim(req.port, req.service, req.project)
        if "error" in result:
            daemon.reconcile()
            result = daemon.claim(req.port, req.service, req.project)
        if "error" in result:
            raise HTTPException(status_code=409, detail=result["error"])
        return result

    @app.post("/release", tags=["allocation"])
    def release(req: ReleaseRequest) -> dict:
        released = daemon.release(port=req.port)
        return {"released": released}

    return app
