"""ASGI entry point for Docker / uvicorn.

Starts the daemon + scanner, then exposes only the HTTP REST API.
The MCP SSE server (port 7847) is intentionally NOT started here —
it's for local Claude/Cursor connections, not inter-service use.

Usage:
    uvicorn portmap.app:app --host 0.0.0.0 --port 7848
"""

from __future__ import annotations

from .daemon import Daemon
from .http_api import create_app

_daemon = Daemon()
_daemon.reconcile()

app = create_app(_daemon)
