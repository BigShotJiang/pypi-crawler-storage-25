"""Portmap daemon — the single source of truth.

One instance per machine. Maintains port state in memory.
Scans continuously. All agents connect to this daemon.
"""

from __future__ import annotations
import os
import threading
import json
import urllib.error
import urllib.request
import yaml
import logging
from pathlib import Path
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, field, asdict
from enum import Enum

from filelock import FileLock

from .scanner import scan_system_ports, PortProcess
from .resolver import Resolver, ServiceInfo

log = logging.getLogger("portmap")

# Archipel reporting (fire-and-forget heartbeat). Configured via env vars; all
# three must be present to enable reporting. Otherwise report_to_archipel() is
# a silent no-op.
ARCHIPEL_URL = os.getenv("ARCHIPEL_URL", "").rstrip("/")
ARCHIPEL_KEY = os.getenv("ARCHIPEL_API_KEY", "")
NODE_ID = os.getenv("PORTMAP_NODE_ID", "")

PORTMAP_DIR = Path.home() / ".portmap"
STATE_FILE = PORTMAP_DIR / "state.json"
STATE_LOCK = PORTMAP_DIR / "state.lock"
CONFIG_FILE = PORTMAP_DIR / "config.yaml"


class PortStatus(str, Enum):
    FREE = "free"
    LEASED = "leased"
    RESERVED = "reserved"
    SYSTEM = "system"
    SQUATTER = "squatter"


@dataclass
class PortEntry:
    port: int
    service: str
    project: str | None
    category: str
    status: PortStatus
    pid: int | None = None
    container: str | None = None
    compose_project: str | None = None
    cwd: str | None = None
    allocated_at: str | None = None
    last_seen_up: str | None = None
    last_seen_down: str | None = None
    reserve_until: str | None = None

    def to_dict(self) -> dict:
        d = asdict(self)
        d["status"] = self.status.value
        return d


@dataclass
class HistoryEntry:
    port: int
    service: str
    project: str | None
    allocated_at: str
    freed_at: str
    reason: str


@dataclass
class Config:
    ranges: dict[str, list[int]] = field(default_factory=lambda: {
        "database":  [10000, 10199],
        "api":       [10200, 10399],
        "frontend":  [10400, 10599],
        "vectordb":  [10600, 10799],
        "mcp":       [10800, 10999],
        "inference":  [11000, 11199],
        "broker":    [11200, 11399],
        "monitoring": [11400, 11599],
        "auth":      [11600, 11799],
        "storage":   [11800, 11999],
        "ephemeral": [12000, 13999],
        "general":   [14000, 15999],
    })
    ttl_days: int = 10
    ttl_ephemeral_hours: int = 24
    port: int = 7847        # MCP SSE server
    http_port: int = 7848   # REST HTTP API (claim/release/snapshot)
    reserved_ports: list[int] = field(default_factory=list)

    @classmethod
    def load(cls) -> Config:
        c = cls()
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE) as f:
                data = yaml.safe_load(f) or {}
            if "ranges" in data:
                c.ranges.update(data["ranges"])
            c.ttl_days = data.get("ttl_days", c.ttl_days)
            c.ttl_ephemeral_hours = data.get("ttl_ephemeral_hours", c.ttl_ephemeral_hours)
            c.port = data.get("port", c.port)
            c.http_port = data.get("http_port", c.http_port)
            c.reserved_ports = data.get("reserved_ports", c.reserved_ports)
        return c


class Daemon:
    """The portmap daemon. One per machine. All state lives here."""

    def __init__(self):
        PORTMAP_DIR.mkdir(parents=True, exist_ok=True)
        self.config = Config.load()
        self.resolver = Resolver()
        self.lock = threading.RLock()
        self.ledger: dict[int, PortEntry] = {}
        self.history: list[HistoryEntry] = []
        self._load_state()

    # ── State persistence ──────────────────────────────────

    def _load_state(self):
        if not STATE_FILE.exists():
            return
        try:
            with FileLock(STATE_LOCK), open(STATE_FILE) as f:
                data = json.load(f)
            for entry in data.get("ledger", []):
                pe = PortEntry(
                    port=entry["port"], service=entry["service"],
                    project=entry.get("project"), category=entry.get("category", "general"),
                    status=PortStatus(entry["status"]),
                    pid=entry.get("pid"), container=entry.get("container"),
                    compose_project=entry.get("compose_project"),
                    cwd=entry.get("cwd"),
                    allocated_at=entry.get("allocated_at"),
                    last_seen_up=entry.get("last_seen_up"),
                    last_seen_down=entry.get("last_seen_down"),
                    reserve_until=entry.get("reserve_until"),
                )
                self.ledger[pe.port] = pe
            for h in data.get("history", []):
                self.history.append(HistoryEntry(**h))
        except (json.JSONDecodeError, KeyError) as e:
            log.warning(f"Failed to load state: {e}")

    def _save_state(self):
        data = {
            "saved_at": _now_iso(),
            "ledger": [e.to_dict() for e in self.ledger.values()],
            "history": [asdict(h) for h in self.history[-500:]],
        }
        tmp = STATE_FILE.with_suffix(".tmp")
        with FileLock(STATE_LOCK):
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
            tmp.replace(STATE_FILE)

    def reconcile(self):
        """Compare declared state vs real ports. Update ledger."""
        real_ports = scan_system_ports()
        now = _now_iso()

        with self.lock:
            # 1. Check declared ports against reality
            for port, entry in list(self.ledger.items()):
                is_open = port in real_ports

                if entry.status == PortStatus.LEASED and not is_open:
                    entry.status = PortStatus.RESERVED
                    entry.last_seen_down = now
                    entry.pid = None
                    ttl = timedelta(days=self.config.ttl_days)
                    entry.reserve_until = _iso_add(now, ttl)
                    log.info(f"Port {port} ({entry.service}) → reserved (service stopped)")

                elif entry.status == PortStatus.RESERVED and is_open:
                    rp = real_ports[port]
                    entry.status = PortStatus.LEASED
                    entry.last_seen_up = now
                    entry.pid = rp.pid
                    entry.container = rp.container
                    entry.reserve_until = None
                    log.info(f"Port {port} ({entry.service}) → leased (service restored)")

                elif entry.status == PortStatus.LEASED and is_open:
                    rp = real_ports[port]
                    entry.last_seen_up = now
                    entry.pid = rp.pid
                    entry.container = rp.container
                    if rp.compose_project:
                        entry.compose_project = rp.compose_project
                    if rp.cwd:
                        entry.cwd = rp.cwd

                elif entry.status == PortStatus.RESERVED:
                    if entry.reserve_until and now > entry.reserve_until:
                        self.history.append(HistoryEntry(
                            port=port, service=entry.service,
                            project=entry.project,
                            allocated_at=entry.allocated_at or "",
                            freed_at=now, reason="ttl_expired",
                        ))
                        del self.ledger[port]
                        log.info(f"Port {port} ({entry.service}) → freed (TTL expired)")

            # 2. Detect squatters (open ports not in ledger)
            # Skip ephemeral/OS ports (>= 20000 unless it's a known service port)
            declared = set(self.ledger.keys())
            known_ports = self.resolver.all_known_ports()
            for port, rp in real_ports.items():
                if port not in declared and port > 1023 and (port < 20000 or port in known_ports):
                    existing_squatter = self.ledger.get(port)
                    if not existing_squatter:
                        # Derive project name: compose project > cwd folder name
                        inferred_project = rp.compose_project
                        if not inferred_project and rp.cwd:
                            from pathlib import PurePath
                            folder = PurePath(rp.cwd).name
                            # Skip generic system folders
                            if folder.lower() not in ("system32", "windows", "system", ""):
                                inferred_project = folder

                        self.ledger[port] = PortEntry(
                            port=port, service=rp.process_name,
                            project=inferred_project, category="unknown",
                            status=PortStatus.SQUATTER,
                            pid=rp.pid, container=rp.container,
                            compose_project=rp.compose_project,
                            cwd=rp.cwd,
                            last_seen_up=now,
                        )

            # 3. Clean up squatters that disappeared
            for port, entry in list(self.ledger.items()):
                if entry.status == PortStatus.SQUATTER and port not in real_ports:
                    del self.ledger[port]

            self._save_state()

        self.report_to_archipel()

    # ── Archipel reporting ─────────────────────────────────

    def report_to_archipel(self) -> None:
        """Fire-and-forget heartbeat: push current snapshot to Archipel.

        Spawned in a daemon thread to keep reconcile() non-blocking. If
        ARCHIPEL_URL/PORTMAP_NODE_ID are not set, this is a silent no-op.
        Network errors are swallowed — Archipel may not be reachable.
        """
        if not ARCHIPEL_URL or not NODE_ID:
            return

        snap = self.snapshot()
        payload = json.dumps({
            "node_id": NODE_ID,
            "ports": snap["ports"],
            "timestamp": snap["as_of"],
        }).encode("utf-8")

        url = f"{ARCHIPEL_URL}/nodes/{NODE_ID}/portmap"
        headers = {"Content-Type": "application/json"}
        if ARCHIPEL_KEY:
            headers["X-Archipel-Key"] = ARCHIPEL_KEY

        def _send():
            try:
                req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
                with urllib.request.urlopen(req, timeout=5):
                    pass
            except (urllib.error.URLError, urllib.error.HTTPError, OSError):
                pass

        threading.Thread(target=_send, name="portmap-archipel-report", daemon=True).start()

    # ── Allocation ─────────────────────────────────────────

    def allocate(self, services: list[str], project: str,
                 ephemeral: bool = False, prefer_previous: bool = True) -> list[dict]:
        """Allocate ports for a list of services. Atomic."""
        with self.lock:
            self.reconcile()
            results = []
            occupied = self._all_occupied_ports()

            for svc_name in services:
                info = self.resolver.resolve(svc_name)

                # Check if project already has this service allocated
                existing = self._find_existing(svc_name, project)
                if existing:
                    results.append({
                        "service": svc_name, "port": existing.port,
                        "source": "existing", "category": info.category,
                    })
                    continue

                # Try to reuse from history
                port = None
                if prefer_previous:
                    port = self._find_in_history(svc_name, project, occupied)

                # Try default port
                if port is None and info.default_port > 0:
                    if info.default_port not in occupied:
                        port = info.default_port
                        source = "default"

                # Allocate from range
                if port is None:
                    port = self._find_in_range(info.category, occupied)
                    source = "allocated"
                else:
                    source = source if port == info.default_port else "previous"

                if port is None:
                    results.append({
                        "service": svc_name, "port": None,
                        "error": "No free port available",
                        "category": info.category,
                    })
                    continue

                # Register
                now = _now_iso()
                ttl = None
                if ephemeral:
                    ttl = _iso_add(now, timedelta(hours=self.config.ttl_ephemeral_hours))

                self.ledger[port] = PortEntry(
                    port=port, service=svc_name, project=project,
                    category=info.category, status=PortStatus.LEASED,
                    allocated_at=now, last_seen_up=now,
                    reserve_until=ttl,
                )
                occupied.add(port)

                note = None
                if source == "allocated" and info.default_port > 0:
                    owner = self.ledger.get(info.default_port)
                    if owner:
                        note = f"default {info.default_port} used by {owner.project} ({owner.service})"

                results.append({
                    "service": svc_name, "port": port,
                    "source": source, "category": info.category,
                    "note": note,
                })

            self._save_state()
            return results

    def release(self, project: str | None = None, port: int | None = None) -> list[dict]:
        """Release ports by project or specific port."""
        with self.lock:
            released = []
            now = _now_iso()
            for p, entry in list(self.ledger.items()):
                if entry.status in (PortStatus.SYSTEM, PortStatus.SQUATTER):
                    continue
                match = False
                if project and entry.project == project:
                    match = True
                if port is not None and p == port:
                    match = True
                if match:
                    self.history.append(HistoryEntry(
                        port=p, service=entry.service, project=entry.project,
                        allocated_at=entry.allocated_at or "", freed_at=now,
                        reason="explicit_release",
                    ))
                    released.append({"port": p, "service": entry.service})
                    del self.ledger[p]
            self._save_state()
            return released

    def claim(self, port: int, service: str, project: str) -> dict:
        """Adopt a squatter port into managed state."""
        with self.lock:
            entry = self.ledger.get(port)
            if not entry:
                return {"error": f"Port {port} not found in ledger"}
            if entry.status != PortStatus.SQUATTER:
                return {"error": f"Port {port} is {entry.status.value}, not a squatter"}
            info = self.resolver.resolve(service)
            entry.service = service
            entry.project = project
            entry.category = info.category
            entry.status = PortStatus.LEASED
            entry.allocated_at = _now_iso()
            self._save_state()
            return {"port": port, "service": service, "project": project, "status": "claimed"}

    # ── Queries ────────────────────────────────────────────

    def snapshot(self) -> dict:
        """Full machine state — what agents read at session start."""
        with self.lock:
            occupied = sorted(
                p for p, e in self.ledger.items()
                if e.status in (PortStatus.LEASED, PortStatus.RESERVED, PortStatus.SYSTEM)
            )
            ports = []
            for p, e in sorted(self.ledger.items()):
                d = {"port": p, "service": e.service, "status": e.status.value}
                if e.project:
                    d["project"] = e.project
                if e.status == PortStatus.RESERVED and e.reserve_until:
                    d["ttl"] = e.reserve_until
                if e.container:
                    d["container"] = e.container
                if e.compose_project:
                    d["compose_project"] = e.compose_project
                if e.cwd:
                    d["cwd"] = e.cwd
                ports.append(d)

            next_free = {}
            all_occupied = self._all_occupied_ports()
            for cat, (lo, hi) in self.config.ranges.items():
                for p in range(lo, hi + 1):
                    if p not in all_occupied:
                        next_free[cat] = p
                        break

            return {
                "as_of": _now_iso(),
                "DO_NOT_USE": occupied,
                "ports": ports,
                "next_free": next_free,
                "summary": self._summary(),
            }

    def status(self) -> dict:
        """Status grouped by project."""
        with self.lock:
            projects: dict[str, dict] = {}
            squatters = []
            for p, e in sorted(self.ledger.items()):
                if e.status == PortStatus.SQUATTER:
                    squatters.append({
                        "port": p, "process": e.service,
                        "pid": e.pid, "since": e.last_seen_up,
                    })
                    continue
                proj = e.project or "__system__"
                if proj not in projects:
                    projects[proj] = {"status": "unknown", "ports": []}
                pd = {"port": p, "service": e.service, "status": e.status.value}
                if e.container:
                    pd["container"] = e.container
                projects[proj]["ports"].append(pd)
                if e.status == PortStatus.LEASED:
                    projects[proj]["status"] = "running"
                elif projects[proj]["status"] != "running":
                    projects[proj]["status"] = "stopped"

            return {
                "projects": projects,
                "squatters": squatters,
                "summary": self._summary(),
            }

    def audit(self) -> dict:
        """Find problems: ghosts, squatters, TTL warnings."""
        with self.lock:
            real = scan_system_ports()
            ghosts, squatters, expiring = [], [], []
            now = _now_iso()
            warn_threshold = _iso_add(now, timedelta(days=2))

            for p, e in self.ledger.items():
                if e.status == PortStatus.LEASED and p not in real:
                    ghosts.append({"port": p, "service": e.service,
                                   "project": e.project, "expected": "leased"})
                if e.status == PortStatus.SQUATTER:
                    squatters.append({"port": p, "process": e.service,
                                      "pid": e.pid, "since": e.last_seen_up})
                if e.status == PortStatus.RESERVED and e.reserve_until:
                    if e.reserve_until < warn_threshold:
                        expiring.append({"port": p, "service": e.service,
                                         "project": e.project, "expires": e.reserve_until})

            return {
                "ghosts": ghosts, "squatters": squatters,
                "expiring_soon": expiring,
                "health": self._summary(),
            }

    def get_history(self, project: str | None = None) -> list[dict]:
        """Past allocations, optionally filtered by project."""
        with self.lock:
            entries = self.history
            if project:
                entries = [h for h in entries if h.project == project]
            return [asdict(h) for h in entries[-100:]]

    # ── Internal helpers ───────────────────────────────────

    def _all_occupied_ports(self) -> set[int]:
        """All ports that cannot be allocated (includes squatters)."""
        occupied = set(self.config.reserved_ports)
        for p, e in self.ledger.items():
            if e.status in (PortStatus.LEASED, PortStatus.RESERVED, PortStatus.SYSTEM, PortStatus.SQUATTER):
                occupied.add(p)
        return occupied

    def _find_existing(self, service: str, project: str) -> PortEntry | None:
        for e in self.ledger.values():
            if e.service == service and e.project == project:
                return e
        return None

    def _find_in_history(self, service: str, project: str,
                         occupied: set[int]) -> int | None:
        for h in reversed(self.history):
            if h.service == service and h.project == project:
                if h.port not in occupied:
                    return h.port
        return None

    def _find_in_range(self, category: str, occupied: set[int]) -> int | None:
        """Find first free port in the category's range, then general."""
        for cat in [category, "general"]:
            r = self.config.ranges.get(cat)
            if not r:
                continue
            lo, hi = r
            for port in range(lo, hi + 1):
                if port not in occupied:
                    return port
        return None

    def _summary(self) -> str:
        leased = sum(1 for e in self.ledger.values() if e.status == PortStatus.LEASED)
        reserved = sum(1 for e in self.ledger.values() if e.status == PortStatus.RESERVED)
        squatters = sum(1 for e in self.ledger.values() if e.status == PortStatus.SQUATTER)
        projects = len({e.project for e in self.ledger.values() if e.project})
        return f"{projects} projects, {leased} active, {reserved} reserved, {squatters} squatters"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _iso_add(iso: str, delta: timedelta) -> str:
    dt = datetime.fromisoformat(iso)
    return (dt + delta).isoformat()
