"""Docker-compose parser and patcher.

Reads a docker-compose.yml, extracts host port mappings,
detects conflicts, and returns a patched version.
NEVER modifies container ports or inter-service references.
"""

from __future__ import annotations
import re
import yaml


def check_compose(compose_content: str, daemon) -> dict:
    """Analyze a docker-compose.yml for port conflicts.
    
    Returns analysis + patched YAML if conflicts found.
    """
    try:
        compose = yaml.safe_load(compose_content)
    except yaml.YAMLError as e:
        return {"error": f"Invalid YAML: {e}"}

    if not compose or "services" not in compose:
        return {"error": "No services found in compose file"}

    services = compose["services"]

    # Detect reverse proxy → recommend skip
    if _has_reverse_proxy(services):
        host_ports = _count_host_ports(services)
        if host_ports <= 2:
            return {
                "recommendation": "skip",
                "reason": "Reverse proxy detected with hostname routing. Port management not needed.",
                "host_ports_count": host_ports,
            }

    # Analyze each service's port mappings
    analysis = []
    internal_services = []
    needs_patch = False
    occupied = daemon._all_occupied_ports()

    for svc_name, svc_config in services.items():
        ports_config = svc_config.get("ports", [])
        expose_config = svc_config.get("expose", [])

        if not ports_config and expose_config:
            internal_services.append(svc_name)
            continue

        if not ports_config:
            internal_services.append(svc_name)
            continue

        for port_mapping in ports_config:
            parsed = _parse_port_mapping(str(port_mapping))
            if not parsed:
                continue

            host_port, container_port, interface = parsed
            if host_port is None:
                # Dynamic port assignment (docker chooses)
                continue

            entry = {
                "service": svc_name,
                "mapping": f"{host_port}:{container_port}",
                "host_port": host_port,
                "container_port": container_port,
                "interface": interface,
            }

            if host_port in occupied:
                conflict = daemon.ledger.get(host_port)
                conflict_info = None
                if conflict:
                    conflict_info = {
                        "project": conflict.project,
                        "service": conflict.service,
                        "status": conflict.status.value,
                    }

                # Find a free alternative
                new_port = _find_alternative_host_port(host_port, occupied)
                if new_port:
                    occupied.add(new_port)
                    entry["status"] = "conflict"
                    entry["conflict_with"] = conflict_info
                    entry["resolved_to"] = f"{new_port}:{container_port}"
                    entry["new_host_port"] = new_port
                    needs_patch = True
                else:
                    entry["status"] = "conflict_unresolved"
                    entry["conflict_with"] = conflict_info
            else:
                entry["status"] = "ok"

            analysis.append(entry)

    result = {
        "recommendation": "patch" if needs_patch else "ok",
        "host_ports_analysis": analysis,
        "internal_services": internal_services,
    }

    if needs_patch:
        patched = _patch_compose(compose_content, analysis)
        result["patched_compose"] = patched
        result["env_updates"] = _build_env_updates(analysis)

    return result


def _parse_port_mapping(mapping: str) -> tuple[int | None, int, str] | None:
    """Parse a Docker port mapping string.
    
    Returns (host_port, container_port, interface) or None.
    Handles: "8000:8000", "127.0.0.1:8000:8000", "8000" (dynamic), "8000-8010:8000-8010"
    """
    mapping = mapping.strip().strip("'\"")

    # Range mapping (e.g., "8000-8010:8000-8010")
    if "-" in mapping.split(":")[0] if ":" in mapping else False:
        return None  # Skip ranges for now

    parts = mapping.split(":")
    if len(parts) == 1:
        # Just container port, dynamic host port
        return None
    elif len(parts) == 2:
        try:
            return int(parts[0]), int(parts[1]), "0.0.0.0"
        except ValueError:
            return None
    elif len(parts) == 3:
        try:
            return int(parts[1]), int(parts[2]), parts[0]
        except ValueError:
            return None
    return None


def _find_alternative_host_port(original: int, occupied: set[int]) -> int | None:
    """Find the nearest free port to the original."""
    # Try incrementing from original
    for offset in range(1, 100):
        candidate = original + offset
        if candidate not in occupied and candidate < 65535:
            return candidate
    return None


def _patch_compose(original_yaml: str, analysis: list[dict]) -> str:
    """Patch the compose YAML, replacing only conflicting host ports.
    
    Uses string replacement to preserve formatting and comments.
    """
    patched = original_yaml
    for entry in analysis:
        if entry.get("status") != "conflict" or "new_host_port" not in entry:
            continue
        old_host = entry["host_port"]
        new_host = entry["new_host_port"]
        container = entry["container_port"]
        iface = entry["interface"]

        # Replace the port mapping string
        if iface != "0.0.0.0":
            old_pattern = f"{iface}:{old_host}:{container}"
            new_pattern = f"{iface}:{new_host}:{container}"
        else:
            old_pattern = f"{old_host}:{container}"
            new_pattern = f"{new_host}:{container}"

        # Only replace in ports: context (not in environment or elsewhere)
        patched = _safe_replace_port(patched, old_pattern, new_pattern)

    return patched


def _safe_replace_port(yaml_str: str, old: str, new: str) -> str:
    """Replace a port mapping only in ports: sections, not in env vars."""
    lines = yaml_str.split("\n")
    in_ports = False
    result = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("ports:"):
            in_ports = True
        elif in_ports and stripped and not stripped.startswith("-") and not stripped.startswith("#"):
            if not stripped.startswith("'") and not stripped.startswith('"'):
                in_ports = False

        if in_ports and old in line:
            line = line.replace(old, new, 1)

        result.append(line)
    return "\n".join(result)


def _build_env_updates(analysis: list[dict]) -> dict:
    """Build a dict of environment variable changes for the user."""
    updates = {}
    for entry in analysis:
        if entry.get("status") != "conflict":
            continue
        svc = entry["service"].upper().replace("-", "_")
        port_var = f"{svc}_HOST_PORT"
        updates[port_var] = {
            "old": str(entry["host_port"]),
            "new": str(entry["new_host_port"]),
            "note": "Only for host access. Internal Docker connections unchanged.",
        }
    return updates


def _has_reverse_proxy(services: dict) -> bool:
    """Detect if a reverse proxy with hostname routing is present."""
    proxy_images = ["traefik", "caddy", "nginx-proxy", "jwilder/nginx-proxy"]
    for svc_name, svc_config in services.items():
        image = str(svc_config.get("image", "")).lower()
        if any(p in image for p in proxy_images):
            return True
        labels = svc_config.get("labels", [])
        label_str = str(labels).lower()
        if "traefik.http.routers" in label_str or "virtual_host" in label_str:
            return True
    return False


def _count_host_ports(services: dict) -> int:
    """Count total number of explicit host port mappings."""
    count = 0
    for svc_config in services.values():
        for p in svc_config.get("ports", []):
            parsed = _parse_port_mapping(str(p))
            if parsed and parsed[0] is not None:
                count += 1
    return count
