"""Scan the machine for actually open ports.

Uses `ss` (Linux) or `netstat` (macOS/fallback) + `docker inspect`.
Returns a dict of port → process info for all listening TCP ports.
"""

from __future__ import annotations
import subprocess
import json
import re
import shutil
from dataclasses import dataclass


@dataclass
class PortProcess:
    port: int
    pid: int | None
    process_name: str
    interface: str  # "0.0.0.0", "127.0.0.1", "::", etc.
    container: str | None = None
    compose_project: str | None = None  # Docker Compose project name
    cwd: str | None = None  # Process working directory (native processes)


def scan_system_ports() -> dict[int, PortProcess]:
    """Scan all listening TCP ports on the host.

    On Windows, always uses psutil (ss/netstat flags differ).
    On Linux, prefers ss > netstat > psutil.
    On macOS, prefers lsof > netstat > psutil.
    """
    import sys as _sys
    ports: dict[int, PortProcess] = {}

    if _sys.platform == "win32":
        # Windows netstat has different flags; psutil is reliable and fast
        ports.update(_scan_psutil())
    elif shutil.which("ss"):
        ports.update(_scan_ss())
    elif shutil.which("netstat"):
        ports.update(_scan_netstat())
    else:
        ports.update(_scan_psutil())

    docker_ports = _scan_docker()
    for port, pp in docker_ports.items():
        if port in ports:
            # Enrich with container info; on Windows the process is
            # com.docker.backend.exe for all containers, so prefer
            # the docker-derived name and clear the misleading cwd.
            ports[port].container = pp.container
            ports[port].compose_project = pp.compose_project
            if pp.container and ports[port].process_name in (
                "com.docker.backend.exe", "com.docker.backend", "docker-proxy"
            ):
                ports[port].process_name = f"docker:{pp.container}"
                ports[port].cwd = None  # system32 is misleading for Docker
        else:
            ports[port] = pp

    return ports


def _scan_ss() -> dict[int, PortProcess]:
    """Parse `ss -tlnp` output."""
    ports = {}
    try:
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True, text=True, timeout=5
        )
        for line in result.stdout.strip().split("\n")[1:]:
            parts = line.split()
            if len(parts) < 5:
                continue
            local = parts[3]
            match = re.search(r":(\d+)$", local)
            if not match:
                continue
            port = int(match.group(1))
            interface = local[:match.start()]

            pid, pname = None, "unknown"
            pid_match = re.search(r'pid=(\d+)', line)
            name_match = re.search(r'"([^"]+)"', line)
            if pid_match:
                pid = int(pid_match.group(1))
            if name_match:
                pname = name_match.group(1)

            ports[port] = PortProcess(
                port=port, pid=pid, process_name=pname, interface=interface
            )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return ports


def _scan_netstat() -> dict[int, PortProcess]:
    """Parse `netstat -tlnp` or `lsof -iTCP -sTCP:LISTEN -nP` on macOS."""
    ports = {}
    try:
        if shutil.which("lsof"):
            result = subprocess.run(
                ["lsof", "-iTCP", "-sTCP:LISTEN", "-nP", "-F", "pcn"],
                capture_output=True, text=True, timeout=5
            )
            pid, pname = None, "unknown"
            for line in result.stdout.strip().split("\n"):
                if line.startswith("p"):
                    pid = int(line[1:])
                elif line.startswith("c"):
                    pname = line[1:]
                elif line.startswith("n"):
                    match = re.search(r":(\d+)$", line)
                    if match:
                        port = int(match.group(1))
                        iface = line[1:match.start()]
                        ports[port] = PortProcess(
                            port=port, pid=pid, process_name=pname, interface=iface
                        )
        else:
            result = subprocess.run(
                ["netstat", "-tlnp"],
                capture_output=True, text=True, timeout=5
            )
            for line in result.stdout.strip().split("\n"):
                match = re.search(r":(\d+)\s+.*LISTEN\s+(\d+)/(\S+)", line)
                if match:
                    port = int(match.group(1))
                    ports[port] = PortProcess(
                        port=port, pid=int(match.group(2)),
                        process_name=match.group(3), interface="0.0.0.0"
                    )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return ports


def _scan_psutil() -> dict[int, PortProcess]:
    """Fallback using psutil if ss/netstat unavailable."""
    ports = {}
    try:
        import psutil
        for conn in psutil.net_connections(kind="tcp"):
            if conn.status == "LISTEN" and conn.laddr:
                port = conn.laddr.port
                pname = "unknown"
                cwd = None
                try:
                    if conn.pid:
                        proc = psutil.Process(conn.pid)
                        pname = proc.name()
                        try:
                            cwd = proc.cwd()
                        except (psutil.AccessDenied, OSError):
                            pass
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                ports[port] = PortProcess(
                    port=port, pid=conn.pid, process_name=pname,
                    interface=conn.laddr.ip, cwd=cwd,
                )
    except ImportError:
        pass
    return ports


def _scan_docker() -> dict[int, PortProcess]:
    """Scan Docker containers for exposed host ports.

    Uses `docker inspect` to get compose project labels and port mappings.
    """
    ports = {}
    if not shutil.which("docker"):
        return ports
    try:
        # Get full container info via docker inspect
        ps_result = subprocess.run(
            ["docker", "ps", "-q"],
            capture_output=True, text=True, timeout=10,
        )
        if ps_result.returncode != 0 or not ps_result.stdout.strip():
            return ports

        container_ids = ps_result.stdout.strip().split("\n")
        inspect_result = subprocess.run(
            ["docker", "inspect"] + container_ids,
            capture_output=True, text=True, timeout=10,
        )
        if inspect_result.returncode != 0:
            return ports

        containers = json.loads(inspect_result.stdout)
        for cinfo in containers:
            name = cinfo.get("Name", "").lstrip("/")
            labels = cinfo.get("Config", {}).get("Labels", {})
            compose_project = labels.get("com.docker.compose.project")

            # Extract host port bindings
            net_settings = cinfo.get("NetworkSettings", {})
            port_bindings = net_settings.get("Ports", {})
            for container_port_proto, bindings in (port_bindings or {}).items():
                if not bindings:
                    continue
                for binding in bindings:
                    host_ip = binding.get("HostIp", "0.0.0.0")
                    host_port_str = binding.get("HostPort", "")
                    if not host_port_str:
                        continue
                    host_port = int(host_port_str)
                    ports[host_port] = PortProcess(
                        port=host_port, pid=None,
                        process_name=f"docker:{name}",
                        interface=host_ip or "0.0.0.0",
                        container=name,
                        compose_project=compose_project,
                    )

    except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
        pass
    return ports
