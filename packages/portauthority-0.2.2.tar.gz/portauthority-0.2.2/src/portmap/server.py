"""MCP server for portmap.

Exposes one tool: `portmap` with multiple intents.
Runs as an SSE server on localhost — all agents share this instance.
"""

from __future__ import annotations
import json
import logging
from mcp.server.fastmcp import FastMCP

from .daemon import Daemon
from .compose import check_compose

log = logging.getLogger("portmap")

TOOL_DESCRIPTION = """Port authority for this machine. I track every port in use, every service running, and every project's history in real time.

ALWAYS call me BEFORE writing any code that opens a network port:
- docker-compose.yml (ports: section)
- Dockerfile (EXPOSE)
- server.listen(port), app.run(port=...), bind()
- Any PORT= in .env files

I return guaranteed conflict-free ports. Call with intent='snapshot' to see the current port landscape.
You can also send me a full docker-compose.yml via intent='check_compose' and I'll return a patched version with no conflicts."""


def create_mcp_server(daemon: Daemon) -> FastMCP:
    mcp = FastMCP("portmap", instructions=TOOL_DESCRIPTION)

    @mcp.tool()
    def portmap(
        intent: str,
        services: list[str] | None = None,
        project: str | None = None,
        compose_content: str | None = None,
        port: int | None = None,
        service: str | None = None,
        ephemeral: bool = False,
        prefer_previous: bool = True,
    ) -> str:
        """Port authority for this machine. Manages ports across all projects.

        Args:
            intent: Action to perform. One of:
                - snapshot: Current port state (call at session start)
                - allocate: Get conflict-free ports for services
                - check_compose: Analyze/patch a docker-compose.yml
                - release: Free ports (by project or specific port)
                - claim: Adopt a squatter port into managed state
                - status: All projects and their ports
                - audit: Find problems (ghosts, squatters, expiring)
                - history: Past allocations for a project
            services: Service names for allocate (e.g. ["postgres", "fastapi", "react"])
            project: Project name for grouping/lifecycle
            compose_content: Full docker-compose.yml for check_compose
            port: Specific port for claim/release
            service: Service name for claim
            ephemeral: If true, ports auto-release after 24h
            prefer_previous: Try to reuse ports from project history (default true)
        """
        try:
            return json.dumps(_handle(
                daemon, intent, services, project, compose_content,
                port, service, ephemeral, prefer_previous
            ), indent=2)
        except Exception as e:
            log.error(f"Error handling {intent}: {e}")
            return json.dumps({"error": str(e)})

    return mcp


def _handle(daemon, intent, services, project, compose_content,
            port, service, ephemeral, prefer_previous) -> dict:

    if intent == "snapshot":
        return daemon.snapshot()

    elif intent == "allocate":
        if not services:
            return {"error": "services list required for allocate"}
        if not project:
            return {"error": "project name required for allocate"}
        results = daemon.allocate(
            services, project,
            ephemeral=ephemeral, prefer_previous=prefer_previous
        )
        return {"intent": "allocate", "project": project, "allocations": results}

    elif intent == "check_compose":
        if not compose_content:
            return {"error": "compose_content required for check_compose"}
        return check_compose(compose_content, daemon)

    elif intent == "release":
        if not project and port is None:
            return {"error": "project or port required for release"}
        released = daemon.release(project=project, port=port)
        return {"intent": "release", "released": released}

    elif intent == "claim":
        if port is None or not service:
            return {"error": "port and service required for claim"}
        return daemon.claim(port, service, project or "unassigned")

    elif intent == "status":
        return daemon.status()

    elif intent == "audit":
        return daemon.audit()

    elif intent == "history":
        entries = daemon.get_history(project=project)
        return {"intent": "history", "project": project, "entries": entries}

    else:
        return {"error": f"Unknown intent: {intent}. Use: snapshot, allocate, check_compose, release, claim, status, audit, history"}
