"""Stdio MCP proxy for portmap.

For agents that only support stdio transport (like Claude Code),
this thin wrapper starts an MCP stdio server that proxies to the 
portmap daemon running on localhost.

If the daemon isn't running, it starts one in the same process
as a fallback (single-agent mode).
"""

from __future__ import annotations
import sys
import json
import urllib.request
import urllib.error


def check_daemon_running(port: int = 7847) -> bool:
    """Check if the portmap daemon is reachable."""
    try:
        req = urllib.request.Request(f"http://localhost:{port}/health")
        with urllib.request.urlopen(req, timeout=1) as resp:
            return resp.status == 200
    except (urllib.error.URLError, ConnectionRefusedError, OSError):
        return False


def main():
    """Entry point for portmap-mcp stdio command."""
    try:
        from .server import create_mcp_server
    except ImportError:
        print(
            "portmap-mcp requires the MCP extra.\n"
            "Install with: pip install portmap[mcp]",
            file=__import__("sys").stderr,
        )
        raise SystemExit(1)

    from .daemon import Daemon, Config

    config = Config.load()

    if check_daemon_running(config.port):
        # Daemon is running — but MCP stdio doesn't proxy HTTP easily.
        # We create a local daemon instance that shares the same state file.
        # The file lock in _save_state prevents corruption.
        # This is "good enough" for the MVP — the state file is the sync point.
        pass

    # Start a local daemon + MCP server in stdio mode
    daemon = Daemon()
    daemon.reconcile()

    mcp = create_mcp_server(daemon)
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
