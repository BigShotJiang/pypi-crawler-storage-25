"""Shared test fixtures for portmap tests."""
import pytest


@pytest.fixture(autouse=True)
def isolate_portmap_home(tmp_path, monkeypatch):
    """Redirect ~/.portmap to a temp dir so tests never touch real state."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.chdir(tmp_path)
