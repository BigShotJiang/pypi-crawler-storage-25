"""Tests for Portmap HTTP REST API (T00)."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from portmap.daemon import Daemon, PortEntry, PortStatus
from portmap.http_api import create_app


@pytest.fixture
def daemon(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.chdir(tmp_path)
    d = Daemon()
    return d


@pytest.fixture
def client(daemon):
    app = create_app(daemon)
    return TestClient(app)


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


def test_snapshot_empty(client):
    resp = client.get("/snapshot")
    assert resp.status_code == 200
    data = resp.json()
    assert "ports" in data
    assert "as_of" in data


def test_claim_squatter(client, daemon):
    daemon.ledger[10500] = PortEntry(
        port=10500,
        service="some-process",
        project=None,
        category="unknown",
        status=PortStatus.SQUATTER,
        pid=12345,
        last_seen_up="2026-05-03T00:00:00+00:00",
    )

    resp = client.post("/claim", json={
        "port": 10500,
        "service": "myapp",
        "project": "myproject",
        "category": "api",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["port"] == 10500
    assert data["service"] == "myapp"
    assert daemon.ledger[10500].status == PortStatus.LEASED


def test_claim_unknown_port_reconciles(client, daemon):
    resp = client.post("/claim", json={
        "port": 9999,
        "service": "ghost",
        "project": "test",
    })
    assert resp.status_code in (200, 409)


def test_release_leased_port(client, daemon):
    from portmap.daemon import _now_iso
    daemon.ledger[10200] = PortEntry(
        port=10200,
        service="fastapi",
        project="myproject",
        category="api",
        status=PortStatus.LEASED,
        allocated_at=_now_iso(),
        last_seen_up=_now_iso(),
    )

    resp = client.post("/release", json={"port": 10200})
    assert resp.status_code == 200
    data = resp.json()
    assert any(r["port"] == 10200 for r in data["released"])
    assert 10200 not in daemon.ledger


def test_release_nonexistent_port(client):
    resp = client.post("/release", json={"port": 19999})
    assert resp.status_code == 200
    assert resp.json()["released"] == []
