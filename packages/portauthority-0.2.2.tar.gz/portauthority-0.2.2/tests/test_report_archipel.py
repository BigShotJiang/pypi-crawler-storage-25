"""Tests for Portmap → Archipel reporting (T02)."""

from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from portmap.daemon import Daemon


@pytest.fixture
def daemon(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.chdir(tmp_path)
    return Daemon()


def test_report_noop_when_no_env(daemon, monkeypatch):
    monkeypatch.delenv("ARCHIPEL_URL", raising=False)
    monkeypatch.delenv("PORTMAP_NODE_ID", raising=False)
    import portmap.daemon as dm
    dm.ARCHIPEL_URL = ""
    dm.NODE_ID = ""
    daemon.report_to_archipel()


def test_report_sends_to_archipel(daemon, monkeypatch, tmp_path):
    """Start a tiny local HTTP server, configure Portmap to report to it,
    call report_to_archipel(), verify the payload arrives."""
    received: list[dict] = []

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            received.append(json.loads(body))
            self.send_response(200)
            self.end_headers()

        def log_message(self, *args):
            pass

    server = HTTPServer(("127.0.0.1", 0), Handler)
    port = server.server_address[1]
    t = threading.Thread(target=server.handle_request, daemon=True)
    t.start()

    import portmap.daemon as dm
    original_url = dm.ARCHIPEL_URL
    original_nid = dm.NODE_ID
    try:
        dm.ARCHIPEL_URL = f"http://127.0.0.1:{port}"
        dm.NODE_ID = "test-node"
        daemon.report_to_archipel()
        t.join(timeout=3)
    finally:
        dm.ARCHIPEL_URL = original_url
        dm.NODE_ID = original_nid
        server.server_close()

    assert len(received) == 1
    payload = received[0]
    assert payload["node_id"] == "test-node"
    assert "ports" in payload
    assert "timestamp" in payload
