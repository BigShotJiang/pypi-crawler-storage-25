"""Command-line interface for docpull."""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

# Check if --doctor flag is present before checking dependencies
if "--doctor" in sys.argv:
    from .doctor import run_doctor

    output_dir = None
    if "--output-dir" in sys.argv or "-o" in sys.argv:
        try:
            flag_idx = sys.argv.index("--output-dir") if "--output-dir" in sys.argv else sys.argv.index("-o")
            if flag_idx + 1 < len(sys.argv):
                output_dir = Path(sys.argv[flag_idx + 1])
        except (ValueError, IndexError):
            pass
    sys.exit(run_doctor(output_dir=output_dir))

# Verify core dependencies
try:
    import aiohttp  # noqa: F401
    import bs4  # noqa: F401
    import defusedxml  # noqa: F401
    import html2text  # noqa: F401
    import rich  # noqa: F401
except ImportError as e:
    print(f"\nERROR: Missing required dependency: {e.name}", file=sys.stderr)
    print("\nDocpull requires all core dependencies to be installed.", file=sys.stderr)
    print("\nRecommended fixes:", file=sys.stderr)
    print("  1. For pipx users: pipx reinstall docpull --force", file=sys.stderr)
    print("  2. For pip users: pip install --upgrade --force-reinstall docpull", file=sys.stderr)
    print("  3. For development: pip install -e .[dev]", file=sys.stderr)
    print("\nTo diagnose issues, run: docpull --doctor", file=sys.stderr)
    sys.exit(1)

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from . import __version__
from .core.fetcher import Fetcher
from .models.config import DocpullConfig, ProfileName
from .models.events import EventType, SkipReason


def create_parser() -> argparse.ArgumentParser:
    """Create argument parser for CLI."""
    parser = argparse.ArgumentParser(
        prog="docpull",
        description="Fetch and convert documentation from any URL to markdown",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Fetch with default settings (RAG profile)
  docpull https://docs.example.com

  # Use a specific profile
  docpull https://docs.example.com --profile mirror

  # Control crawl behavior
  docpull https://example.com --max-pages 100 --max-depth 3

  # Filter paths
  docpull https://example.com --include-paths "/api/*" --exclude-paths "/changelog/*"
        """,
    )

    parser.add_argument(
        "url",
        nargs="?",
        help="URL to fetch documentation from",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    parser.add_argument(
        "--doctor",
        action="store_true",
        help="Run diagnostic checks",
    )

    # Profile
    parser.add_argument(
        "--profile",
        "-p",
        choices=["rag", "mirror", "quick", "llm"],
        default="rag",
        help="Preset profile (default: rag). 'llm' bundles chunking + NDJSON + rich metadata.",
    )

    parser.add_argument(
        "--single",
        action="store_true",
        help="Fetch the given URL only (no discovery/crawl). Fast path for agents.",
    )

    parser.add_argument(
        "--skill",
        type=str,
        metavar="NAME",
        help=(
            "Generate a Claude Code skill directory. Output goes to "
            "<output-dir>/<NAME>/ with hierarchical naming and a "
            "SKILL.md manifest derived from the first page's metadata."
        ),
    )
    parser.add_argument(
        "--skill-description",
        type=str,
        metavar="TEXT",
        help="Override the auto-derived `description` in SKILL.md.",
    )

    # Output
    parser.add_argument(
        "--output-dir",
        "-o",
        type=Path,
        default=None,
        help="Output directory (default: ./docs)",
    )
    parser.add_argument(
        "--format",
        "-f",
        choices=["markdown", "json", "ndjson", "sqlite"],
        default=None,
        help="Output format (default: markdown; 'ndjson' streams one record per line)",
    )
    parser.add_argument(
        "--naming-strategy",
        choices=["full", "hierarchical", "flat", "short"],
        default=None,
        help=(
            "URL-to-filename strategy. 'full' flattens with underscores; "
            "'hierarchical' preserves the URL path as nested directories. "
            "Mirror profile defaults to hierarchical."
        ),
    )
    parser.add_argument(
        "--stream",
        action="store_true",
        help="Stream NDJSON records to stdout as each page completes (implies --format ndjson)",
    )

    # Crawl settings
    crawl_group = parser.add_argument_group("crawl settings")
    crawl_group.add_argument(
        "--max-pages",
        type=int,
        default=None,
        help="Maximum pages to fetch",
    )
    crawl_group.add_argument(
        "--max-depth",
        type=int,
        default=None,
        help="Maximum crawl depth",
    )
    crawl_group.add_argument(
        "--max-concurrent",
        type=int,
        default=None,
        help="Maximum concurrent requests",
    )
    crawl_group.add_argument(
        "--rate-limit",
        "-r",
        type=float,
        default=None,
        help="Seconds between requests",
    )
    crawl_group.add_argument(
        "--include-paths",
        nargs="+",
        metavar="PATTERN",
        help="Only crawl URLs matching these patterns",
    )
    crawl_group.add_argument(
        "--exclude-paths",
        nargs="+",
        metavar="PATTERN",
        help="Skip URLs matching these patterns",
    )
    crawl_group.add_argument(
        "--adaptive-rate-limit",
        action="store_true",
        help="Automatically adjust rate limits based on server responses",
    )
    crawl_group.add_argument(
        "--no-streaming-discovery",
        action="store_true",
        help=(
            "Fall back to discover-all-then-fetch instead of piping URLs "
            "through a worker pool as discovery yields them. Backstop for "
            "queue-backpressure regressions."
        ),
    )

    # Content filtering
    filter_group = parser.add_argument_group("content filtering")
    filter_group.add_argument(
        "--streaming-dedup",
        action="store_true",
        help="Enable real-time deduplication",
    )
    filter_group.add_argument(
        "--extractor",
        choices=["default", "trafilatura"],
        default=None,
        help="Content extractor (trafilatura requires: pip install docpull[trafilatura])",
    )
    filter_group.add_argument(
        "--no-special-cases",
        action="store_true",
        help="Disable framework-specific fast extractors (Next.js, OpenAPI, etc.)",
    )
    filter_group.add_argument(
        "--strict-js-required",
        action="store_true",
        help="Fail loud on pages that appear to require JavaScript (instead of silently skipping)",
    )

    # LLM / chunking
    llm_group = parser.add_argument_group("LLM / chunking")
    llm_group.add_argument(
        "--max-tokens-per-file",
        type=int,
        default=None,
        metavar="N",
        help="Split each page into chunks of at most N tokens (requires tiktoken for exact counts)",
    )
    llm_group.add_argument(
        "--tokenizer",
        type=str,
        default=None,
        metavar="NAME",
        help="tiktoken encoding for chunking (default: cl100k_base)",
    )
    llm_group.add_argument(
        "--emit-chunks",
        action="store_true",
        help="Write one file/record per chunk instead of per page",
    )

    # Network settings
    network_group = parser.add_argument_group("network settings")
    network_group.add_argument(
        "--proxy",
        type=str,
        metavar="URL",
        help="Proxy URL",
    )
    network_group.add_argument(
        "--user-agent",
        type=str,
        help="Custom User-Agent string",
    )
    network_group.add_argument(
        "--insecure-tls",
        action="store_true",
        help="Disable TLS certificate verification (unsafe)",
    )
    network_group.add_argument(
        "--max-retries",
        type=int,
        default=None,
        help="Maximum retry attempts",
    )
    network_group.add_argument(
        "--require-pinned-dns",
        action="store_true",
        help=(
            "Refuse configurations that delegate DNS to a proxy. With this "
            "flag, --proxy is rejected so the SSRF posture cannot silently "
            "weaken in agent-driven crawls."
        ),
    )

    # Authentication settings
    auth_group = parser.add_argument_group("authentication")
    auth_group.add_argument(
        "--auth-bearer",
        type=str,
        metavar="TOKEN",
        help="Bearer token for authentication",
    )
    auth_group.add_argument(
        "--auth-basic",
        type=str,
        metavar="USER:PASS",
        help="Basic auth credentials (username:password)",
    )
    auth_group.add_argument(
        "--auth-cookie",
        type=str,
        metavar="COOKIE",
        help="Cookie string for authentication",
    )
    auth_group.add_argument(
        "--auth-header",
        nargs=2,
        metavar=("NAME", "VALUE"),
        help="Custom auth header (name value)",
    )

    # Cache settings
    cache_group = parser.add_argument_group("cache settings")
    cache_group.add_argument(
        "--cache",
        action="store_true",
        help="Enable caching for incremental updates",
    )
    cache_group.add_argument(
        "--cache-dir",
        type=Path,
        default=None,
        metavar="DIR",
        help="Cache directory (default: .docpull-cache)",
    )
    cache_group.add_argument(
        "--cache-ttl",
        type=int,
        default=None,
        metavar="DAYS",
        help="Days before cache entries expire (default: 30)",
    )
    cache_group.add_argument(
        "--no-skip-unchanged",
        action="store_true",
        help="Re-fetch pages even if unchanged",
    )
    cache_group.add_argument(
        "--resume",
        action="store_true",
        help="Resume from previous interrupted run (requires --cache)",
    )

    # Output control
    output_group = parser.add_argument_group("output control")
    output_group.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be fetched without downloading",
    )
    output_group.add_argument(
        "--preview-urls",
        action="store_true",
        help="List discovered URLs without fetching",
    )
    output_group.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Verbose output",
    )
    output_group.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Suppress output",
    )

    return parser


def run_fetcher(args: argparse.Namespace) -> int:
    """Run the fetcher with given arguments."""
    console = Console()

    if not args.url:
        console.print("[red]Error:[/red] Please provide a URL to fetch")
        return 1

    # Map profile
    profile_map = {
        "rag": ProfileName.RAG,
        "mirror": ProfileName.MIRROR,
        "quick": ProfileName.QUICK,
        "llm": ProfileName.LLM,
    }
    profile = profile_map.get(args.profile, ProfileName.RAG)

    # Build config
    config_kwargs: dict = {
        "profile": profile,
        "url": args.url,
        "dry_run": args.dry_run,
    }

    # Output settings
    output_kwargs: dict = {}
    if args.skill:
        # Skill mode: nest under <output-dir>/<skill>/, force hierarchical
        # naming, and stamp the manifest fields. Default --output-dir to
        # `.claude/skills` for the common drop-in use case.
        base = args.output_dir or Path(".claude/skills")
        output_kwargs["directory"] = base / args.skill
        output_kwargs["naming_strategy"] = "hierarchical"
        output_kwargs["skill_name"] = args.skill
        if args.skill_description:
            output_kwargs["skill_description"] = args.skill_description
    elif args.output_dir:
        output_kwargs["directory"] = args.output_dir
    if args.naming_strategy and "naming_strategy" not in output_kwargs:
        output_kwargs["naming_strategy"] = args.naming_strategy
    if args.stream:
        output_kwargs["format"] = "ndjson"
        output_kwargs["ndjson_filename"] = "-"
    elif args.format:
        output_kwargs["format"] = args.format
    if args.max_tokens_per_file is not None:
        output_kwargs["max_tokens_per_file"] = args.max_tokens_per_file
    if args.tokenizer:
        output_kwargs["tokenizer"] = args.tokenizer
    if args.emit_chunks:
        output_kwargs["emit_chunks"] = True
    if output_kwargs:
        config_kwargs["output"] = output_kwargs

    # Crawl settings
    crawl_kwargs: dict = {}
    if args.max_pages is not None:
        crawl_kwargs["max_pages"] = args.max_pages
    if args.max_depth is not None:
        crawl_kwargs["max_depth"] = args.max_depth
    if args.max_concurrent is not None:
        crawl_kwargs["max_concurrent"] = args.max_concurrent
    if args.rate_limit is not None:
        crawl_kwargs["rate_limit"] = args.rate_limit
    if args.adaptive_rate_limit:
        crawl_kwargs["adaptive_rate_limit"] = True
    if args.no_streaming_discovery:
        crawl_kwargs["streaming_discovery"] = False
    if args.include_paths:
        crawl_kwargs["include_paths"] = args.include_paths
    if args.exclude_paths:
        crawl_kwargs["exclude_paths"] = args.exclude_paths
    if crawl_kwargs:
        config_kwargs["crawl"] = crawl_kwargs

    # Content filter settings
    filter_kwargs: dict = {}
    if args.streaming_dedup:
        filter_kwargs["streaming_dedup"] = True
    if args.extractor:
        filter_kwargs["extractor"] = args.extractor
    if args.no_special_cases:
        filter_kwargs["enable_special_cases"] = False
    if args.strict_js_required:
        filter_kwargs["strict_js_required"] = True
    if filter_kwargs:
        config_kwargs["content_filter"] = filter_kwargs

    # Network settings
    network_kwargs: dict = {}
    if args.proxy:
        network_kwargs["proxy"] = args.proxy
    if args.user_agent:
        network_kwargs["user_agent"] = args.user_agent
    if args.insecure_tls:
        console.print(
            "[red]Configuration error:[/red] --insecure-tls is no longer supported; "
            "docpull always verifies TLS certificates"
        )
        return 1
    if args.max_retries is not None:
        network_kwargs["max_retries"] = args.max_retries
    if args.require_pinned_dns:
        network_kwargs["require_pinned_dns"] = True
    if network_kwargs:
        config_kwargs["network"] = network_kwargs

    # Authentication settings
    auth_kwargs: dict = {}
    if args.auth_bearer:
        auth_kwargs["type"] = "bearer"
        auth_kwargs["token"] = args.auth_bearer
    elif args.auth_basic:
        auth_kwargs["type"] = "basic"
        if ":" in args.auth_basic:
            username, password = args.auth_basic.split(":", 1)
            auth_kwargs["username"] = username
            auth_kwargs["password"] = password
        else:
            console.print("[red]Error:[/red] --auth-basic requires format username:password")
            return 1
    elif args.auth_cookie:
        auth_kwargs["type"] = "cookie"
        auth_kwargs["cookie"] = args.auth_cookie
    elif args.auth_header:
        auth_kwargs["type"] = "header"
        auth_kwargs["header_name"] = args.auth_header[0]
        auth_kwargs["header_value"] = args.auth_header[1]
    if auth_kwargs:
        config_kwargs["auth"] = auth_kwargs

    # Cache settings
    cache_kwargs: dict = {}
    if args.cache or args.resume:
        cache_kwargs["enabled"] = True
    if args.cache_dir:
        cache_kwargs["directory"] = args.cache_dir
    if args.cache_ttl is not None:
        cache_kwargs["ttl_days"] = args.cache_ttl
    if args.no_skip_unchanged:
        cache_kwargs["skip_unchanged"] = False
    if args.resume:
        cache_kwargs["resume"] = True
    if cache_kwargs:
        config_kwargs["cache"] = cache_kwargs

    # Log level
    if args.verbose:
        config_kwargs["log_level"] = "DEBUG"
    elif args.quiet:
        config_kwargs["log_level"] = "ERROR"

    try:
        config = DocpullConfig(**config_kwargs)
    except Exception as e:
        console.print(f"[red]Configuration error:[/red] {e}")
        return 1

    async def run() -> int:
        if not args.quiet:
            console.print(f"[bold blue]docpull[/bold blue] v{__version__}")
            console.print(f"Profile: {profile.value}")
            console.print(f"Target: {config.url}")
            console.print()

        try:
            async with Fetcher(config) as fetcher:
                # Handle --preview-urls mode
                if args.preview_urls:
                    urls = await fetcher.discover()
                    console.print(f"[bold]Discovered {len(urls)} URLs:[/bold]")
                    for url in urls:
                        console.print(f"  {url}")
                    return 0

                # --single fast path: fetch just this URL, no discovery
                if args.single:
                    if config.url is None:
                        console.print("[red]Error:[/red] --single requires a URL")
                        return 1
                    ctx = await fetcher.fetch_one(config.url)
                    if ctx.error:
                        console.print(f"[red]Failed:[/red] {ctx.error}")
                        return 1
                    if ctx.should_skip:
                        console.print(f"[yellow]Skipped:[/yellow] {ctx.skip_reason}")
                        return 0
                    if not args.quiet:
                        n_chunks = len(ctx.chunks) if ctx.chunks else 0
                        extra = f" ({n_chunks} chunks)" if n_chunks else ""
                        console.print(
                            f"[green]Saved:[/green] {ctx.output_path} "
                            f"[{ctx.source_type or 'generic'}]{extra}"
                        )
                    return 0

                # Track skip reasons for summary
                from collections import defaultdict

                skip_counts: dict[SkipReason, int] = defaultdict(int)

                if args.quiet:
                    async for event in fetcher.run():
                        if event.type == EventType.FETCH_SKIPPED and event.skip_reason:
                            skip_counts[event.skip_reason] += 1
                else:
                    with Progress(
                        SpinnerColumn(),
                        TextColumn("[progress.description]{task.description}"),
                        console=console,
                        transient=True,
                    ) as progress:
                        task = progress.add_task("Starting...", total=None)

                        async for event in fetcher.run():
                            if event.type == EventType.STARTED:
                                progress.update(task, description=f"[cyan]{event.message}")
                            elif event.type == EventType.RESUMED:
                                progress.update(
                                    task, description=f"[yellow]Resuming with {event.total} pending URLs"
                                )
                            elif event.type == EventType.DISCOVERY_STARTED:
                                progress.update(task, description="[cyan]Discovering URLs...")
                            elif event.type == EventType.DISCOVERY_COMPLETE:
                                progress.update(task, description=f"[green]Found {event.total} URLs")
                            elif event.type == EventType.FETCH_PROGRESS:
                                progress.update(
                                    task,
                                    description=f"[cyan]Fetching {event.current}/{event.total}: {event.url}",
                                )
                            elif event.type == EventType.FETCH_SKIPPED:
                                if event.skip_reason:
                                    skip_counts[event.skip_reason] += 1
                                if args.verbose:
                                    reason = event.skip_reason.value if event.skip_reason else "unknown"
                                    console.print(f"[dim]Skipped: {event.url} ({reason})[/dim]")
                            elif event.type == EventType.FETCH_FAILED:
                                console.print(f"[red]Failed:[/red] {event.url} - {event.error}")
                            elif event.type == EventType.COMPLETED:
                                progress.update(task, description=f"[green]{event.message}")

                # Print stats
                stats = fetcher.stats
                if not args.quiet:
                    console.print()
                    console.print("[bold]Results:[/bold]")
                    console.print(f"  URLs discovered: {stats.urls_discovered}")
                    console.print(f"  Pages fetched: {stats.pages_fetched}")
                    console.print(f"  Pages skipped: {stats.pages_skipped}")
                    console.print(f"  Pages failed: {stats.pages_failed}")
                    console.print(f"  Duration: {stats.duration_seconds:.1f}s")

                    # Print skip reason summary if there were skips
                    if skip_counts:
                        console.print()
                        console.print("[bold]Skip Summary:[/bold]")
                        for reason, count in sorted(skip_counts.items(), key=lambda x: -x[1]):
                            console.print(f"  {reason.value}: {count}")

                return 0 if stats.pages_failed == 0 else 1

        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            if args.verbose:
                import traceback

                traceback.print_exc()
            return 1

    return asyncio.run(run())


def main(argv: list[str] | None = None) -> int:
    """Main entry point."""
    raw_argv = list(argv) if argv is not None else sys.argv[1:]
    if raw_argv and raw_argv[0] == "mcp":
        from .mcp.server import run_mcp_server

        return run_mcp_server(raw_argv[1:])

    parser = create_parser()
    args = parser.parse_args(raw_argv)

    if args.doctor:
        from .doctor import run_doctor

        return run_doctor(output_dir=args.output_dir)

    return run_fetcher(args)


if __name__ == "__main__":
    sys.exit(main())
