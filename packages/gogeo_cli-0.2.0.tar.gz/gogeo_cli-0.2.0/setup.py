import os
from setuptools import setup, find_namespace_packages

# Read long description from README if available
readme_path = os.path.join(os.path.dirname(__file__), "gogeo", "common_task", "README.md")
long_description = open(readme_path, encoding="utf-8").read() if os.path.exists(readme_path) else ""

setup(
    name="gogeo-cli",
    version="0.2.0",
    description="GoGeo CLI - unified CLI for common-task pipeline & property/asset management APIs",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="gogeo",
    license="MIT",
    url="https://gogeo.topprismdata.com",
    packages=find_namespace_packages(
        include=["gogeo.*"],
        exclude=["gogeo.common_task.tests", "gogeo.common_task.tests.*"],
    ),
    py_modules=["gogeo.gogeo_cli"],
    python_requires=">=3.8",
    install_requires=[
        "click>=8.0",
        "pyyaml>=6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "gogeo-cli=gogeo.gogeo_cli:cli",
        ],
    },
    package_data={
        "gogeo.common_task": ["skills/*.md"],
        "gogeo.property": ["skills/*.md"],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Utilities",
    ],
)
