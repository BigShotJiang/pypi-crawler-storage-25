"""property CLI - 资产管理命令组。

资产管理CLI，包含12个核心接口：
- 目录管理: tree, create, empty-create, remove, rename
- 资产数据: detail
- 数据记录: list, detail, delete, batch-modify
- 数据导入: url-download
- 字段配置: simple

配置项:
- api_base_url: 接口地址 (默认: https://gogeo.topprismdata.com/prod-gogeo-api)
- open_api_code: 用户授权码 (必须配置)

配置读取优先级:
1. 配置文件 ~/.gogeo-cli.yaml
2. 环境变量 gogeoOpenApiCode
3. 命令行参数 --open-api-code

使用方式:
    gogeo-cli property 子模块-动作
"""

import json
import os
from pathlib import Path
from typing import Any, Callable

import click

from gogeo.property.client import PropertyClient

CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}

GATEWAY_PREFIX = "/promap-property"
API_PREFIX = "/api/v3/property/"

ENV_OPEN_API_CODE = "gogeoOpenApiCode"


def load_simple_config() -> dict:
    """加载简化配置。

    优先级：
    1. 配置文件 ~/.gogeo-cli.yaml
    2. 环境变量 gogeoOpenApiCode
    """
    cfg = {
        "api_base_url": "https://gogeo.topprismdata.com/prod-gogeo-api",
        "open_api_code": "",
    }

    config_file = Path.home() / ".gogeo-cli.yaml"
    if config_file.exists():
        try:
            import yaml
            with open(config_file) as f:
                file_cfg = yaml.safe_load(f) or {}
            cfg["api_base_url"] = file_cfg.get("api_base_url", cfg["api_base_url"])
            cfg["open_api_code"] = file_cfg.get("open_api_code", "")
        except Exception:
            pass

    if not cfg["open_api_code"]:
        env_code = os.environ.get(ENV_OPEN_API_CODE, "")
        if env_code:
            cfg["open_api_code"] = env_code

    return cfg


def check_config(ctx: click.Context) -> bool:
    """检查配置是否完整。"""
    obj = ctx.obj
    if not obj.get("open_api_code"):
        click.echo(click.style("错误: 未配置用户授权码 (openApiCode)", fg="red"))
        click.echo()
        click.echo("请先运行配置命令:")
        click.echo("  gogeo-cli config init")
        click.echo("  gogeo-cli config save --open-api-code YOUR_CODE")
        click.echo()
        click.echo("或设置环境变量:")
        click.echo(f"  export {ENV_OPEN_API_CODE}=YOUR_CODE")
        return False
    return True


def make_client(ctx: click.Context) -> PropertyClient:
    """Create API client from context."""
    obj = ctx.obj
    return PropertyClient(
        api_base_url=obj["api_base_url"],
        open_api_code=obj["open_api_code"],
    )


def output(data, as_json: bool) -> None:
    """Output data in JSON or human-readable format."""
    if as_json:
        click.echo(json.dumps(data, indent=2, default=str, ensure_ascii=False))
    elif isinstance(data, dict):
        for k, v in data.items():
            click.echo(f"{k}: {v}")
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                click.echo(json.dumps(item, default=str, ensure_ascii=False))
            else:
                click.echo(str(item))
    else:
        click.echo(str(data))


def output_error(message: str) -> None:
    """Display error message to user."""
    click.echo(click.style(f"错误: {message}", fg="red"))


def call_api(ctx: click.Context, api_call: Callable[[], Any], error_prefix: str = "") -> Any:
    """Execute API call with error handling."""
    try:
        return api_call()
    except RuntimeError as e:
        error_msg = str(e)
        if error_prefix:
            error_msg = f"{error_prefix}: {error_msg}"
        output_error(error_msg)
        return None


# ---------------------------------------------------------------------------
# Root group: property
# ---------------------------------------------------------------------------

@click.group(context_settings=CONTEXT_SETTINGS)
@click.option("--api-base-url", default=None,
              help=f"接口地址 (默认: https://gogeo.topprismdata.com/prod-gogeo-api)")
@click.option("--open-api-code", default=None,
              help="用户授权码 (优先从配置文件读取)")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="JSON格式输出")
@click.pass_context
def property_cli(ctx: click.Context, api_base_url, open_api_code, as_json):
    """property - 资产管理命令组

    资产相关命令，包含：资产目录管理、资产数据管理、资产元数据管理。

    \b
    配置说明:
        配置项仅两项:
          - api_base_url: 接口地址 (默认已设置)
          - open_api_code: 用户授权码 (必须配置)

        配置读取优先级:
          1. 配置文件 ~/.gogeo-cli.yaml
          2. 环境变量 gogeoOpenApiCode
          3. 命令行参数 --open-api-code

        如未配置授权码，请先运行:
          gogeo-cli config init

    \b
    命令格式:
        gogeo-cli property 子模块-动作

    \b
    子模块:
        directory   目录管理 (tree, create, empty-create, remove, rename)
        data        资产数据
        datarecord  数据记录
        import      数据导入
        field       字段配置

    \b
    示例:
        gogeo-cli property directory-tree
        gogeo-cli property data-detail --directory-code DIR001
        gogeo-cli property field-simple --directory-code DIR001
    """
    ctx.ensure_object(dict)

    cfg = load_simple_config()

    ctx.obj["api_base_url"] = api_base_url or cfg["api_base_url"]
    ctx.obj["open_api_code"] = open_api_code or cfg["open_api_code"]
    ctx.obj["as_json"] = as_json
    ctx.obj["gateway_prefix"] = GATEWAY_PREFIX
    ctx.obj["api_prefix"] = API_PREFIX


# ---------------------------------------------------------------------------
# directory commands (目录管理) - 5个命令
# ---------------------------------------------------------------------------

@property_cli.command("directory-tree")
@click.option("--include-data/--no-include-data", default=True,
              help="是否包含数据节点 (默认: 是)")
@click.option("--include-virtual/--no-include-virtual", default=False,
              help="是否包含虚拟资产 (默认: 否)")
@click.option("--type", "directory_type", default=None, type=int,
              help="资产类型: 1-个人目录 2-企业目录")
@click.option("--keyword", default=None, help="关键词，用于模糊目录名称匹配")
@click.option("--directory-code", default=None,
              help="资产目录编码，填写后仅查询该文件夹下的资产")
@click.pass_context
def directory_tree(ctx: click.Context, include_data, include_virtual, directory_type, keyword, directory_code):
    """获取资产目录的树形结构。

    \b
    示例:
        gogeo-cli property directory-tree
        gogeo-cli property directory-tree --type 1 --keyword "测试"
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    params = {
        "includeData": include_data,
        "includeVirtual": include_virtual,
    }
    if directory_type is not None:
        params["type"] = directory_type
    if keyword:
        params["keyword"] = keyword
    if directory_code:
        params["directoryCode"] = directory_code

    result = call_api(ctx, lambda: client.get("/directory/tree", params=params))
    if result is not None:
        output(result, ctx.obj["as_json"])


@property_cli.command("directory-create")
@click.option("--parent-code", required=True,
              help="父目录编码，只能是文件夹类型的资产")
@click.option("--name", "directory_name", required=True,
              help="目录名称 (最大256字符)")
@click.option("--type", "node_type", default=1, type=int,
              help="节点类型: 1-文件夹 2-数据文件 (默认: 1)")
@click.pass_context
def directory_create(ctx: click.Context, parent_code, directory_name, node_type):
    """创建资产目录。

    \b
    示例:
        gogeo-cli property directory-create --parent-code ROOT --name "新建文件夹"
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    request = {
        "parentCode": parent_code,
        "directoryName": directory_name,
        "nodeType": node_type,
    }
    result = call_api(ctx, lambda: client.post("/directory", json_body=request))
    if result is not None:
        output(result, ctx.obj["as_json"])


@property_cli.command("directory-empty-create")
@click.option("--parent-code", required=True, help="父目录编码")
@click.option("--name", "directory_name", required=True, help="目录名称 (最大256字符)")
@click.option("--data-format", default=0, type=int,
              help="数据类型: 0-点 1-线 2-面 (默认: 0)")
@click.option("--import-path", default=1, type=int,
              help="导入路径: 1-我的地图新增数据 2-资产管理添加数据 (默认: 1)")
@click.option("--biz-name", default=None, help="地图模块添加时传入地图名称 (可选)")
@click.option("--biz-type", default=None, type=int, help="业务类型 (可选)")
@click.option("--data-source", default=None, type=int, help="数据来源 (可选)")
@click.option("--storage-location", default=None, type=int,
              help="存储位置: 1-ES&pg 2-mongo 3-pg (可选)")
@click.option("--gen-ename/--no-gen-ename", default=True,
              help="是否生成字段英文名称 (默认: 是)")
@click.option("--fields", default=None, help="字段属性信息，JSON格式 (可选)")
@click.option("--auto-rename/--no-auto-rename", default=False,
              help="名称重复时自动重命名 (默认: 否)")
@click.option("--address-field", default=None, help="地址字段名称 (可选)")
@click.option("--busi-key", default=None, help="业务key (可选)")
@click.option("--sort", default=None, type=int, help="排序顺序 (可选)")
@click.pass_context
def directory_empty_create(ctx: click.Context, parent_code, directory_name, data_format,
                           import_path, biz_name, biz_type, data_source, storage_location,
                           gen_ename, fields, auto_rename, address_field, busi_key, sort):
    """创建空资产。

    \b
    示例:
        gogeo-cli property directory-empty-create --parent-code ROOT --name "点数据"
        gogeo-cli property directory-empty-create --parent-code ROOT --name "面数据" --data-format 2
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    request = {
        "parentCode": parent_code,
        "directoryName": directory_name,
        "dataFormat": data_format,
        "importPath": import_path,
        "genEname": gen_ename,
        "autoRename": auto_rename,
    }
    if biz_name is not None:
        request["busiName"] = biz_name
    if biz_type is not None:
        request["bizType"] = biz_type
    if data_source is not None:
        request["dataSource"] = data_source
    if storage_location is not None:
        request["storageLocation"] = storage_location
    if fields is not None:
        request["filedList"] = json.loads(fields)
    if address_field is not None:
        request["addressField"] = address_field
    if busi_key is not None:
        request["busiKey"] = busi_key
    if sort is not None:
        request["sort"] = sort

    result = call_api(ctx, lambda: client.post("/directory/addEmptyDir/v2", json_body=request))
    if result is not None:
        output({"directory_code": result}, ctx.obj["as_json"])


@property_cli.command("directory-remove")
@click.option("--directory-code", required=True, help="目录编码")
@click.pass_context
def directory_remove(ctx: click.Context, directory_code):
    """根据资产编码删除资产。

    \b
    示例:
        gogeo-cli property directory-remove --directory-code DIR001
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    result = call_api(ctx, lambda: client.post("/directory/deleteByCode", params={"directoryCode": directory_code}))
    if result is not None:
        output({"removed": result}, ctx.obj["as_json"])


@property_cli.command("directory-rename")
@click.option("--directory-code", required=True, help="目录编码")
@click.option("--name", "directory_name", required=True, help="目录名称")
@click.pass_context
def directory_rename(ctx: click.Context, directory_code, directory_name):
    """资产重命名。

    \b
    示例:
        gogeo-cli property directory-rename --directory-code DIR001 --name "新名称"
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    request = {
        "directoryCode": directory_code,
        "directoryName": directory_name,
    }
    result = call_api(ctx, lambda: client.put("/directory/rename", json_body=request))
    if result is not None:
        output({"renamed": result}, ctx.obj["as_json"])


# ---------------------------------------------------------------------------
# data commands (资产数据) - 1个命令
# ---------------------------------------------------------------------------

@property_cli.command("data-detail")
@click.option("--directory-code", required=True, help="资产目录编码")
@click.pass_context
def data_detail(ctx: click.Context, directory_code):
    """获取资产详情。

    \b
    示例:
        gogeo-cli property data-detail --directory-code DIR001
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    result = call_api(ctx, lambda: client.get("/data/detail", params={"directoryCode": directory_code}))
    if result is not None:
        output(result, ctx.obj["as_json"])


# ---------------------------------------------------------------------------
# datarecord commands (数据记录) - 4个命令
# ---------------------------------------------------------------------------

@property_cli.command("datarecord-list")
@click.option("--directory-code", required=True, help="资产目录编码")
@click.option("--page-num", default=1, type=int, help="页码 (默认: 1)")
@click.option("--page-size", default=10, type=int, help="每页数量 (默认: 10)")
@click.option("--return-id/--no-return-id", default=False,
              help="是否返回id字段 (默认: 否)")
@click.option("--filter-hidden/--no-filter-hidden", default=True,
              help="过滤隐藏字段 (默认: 是)")
@click.pass_context
def datarecord_list(ctx: click.Context, directory_code, page_num, page_size, return_id, filter_hidden):
    """数据列表分页查询。

    \b
    示例:
        gogeo-cli property datarecord-list --directory-code DIR001
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    request = {
        "directoryCode": directory_code,
        "pageNum": page_num,
        "pageSize": page_size,
        "returnId": return_id,
        "filterHiddenField": filter_hidden,
    }
    result = call_api(ctx, lambda: client.post("/datarec/list", json_body=request))
    if result is not None:
        output(result, ctx.obj["as_json"])


@property_cli.command("datarecord-detail")
@click.option("--directory-code", required=True, help="目录编码")
@click.option("--record-id", required=True, help="记录编码")
@click.pass_context
def datarecord_detail(ctx: click.Context, directory_code, record_id):
    """获取数据详情。

    \b
    示例:
        gogeo-cli property datarecord-detail --directory-code DIR001 --record-id 123
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    request = {
        "directoryCode": directory_code,
        "recCode": record_id,
    }
    result = call_api(ctx, lambda: client.post("/datarec/detail", json_body=request))
    if result is not None:
        output(result, ctx.obj["as_json"])


@property_cli.command("datarecord-delete")
@click.option("--directory-code", required=True, help="目录编码")
@click.option("--ids", required=True, help="数据记录编码集合 (逗号分隔)")
@click.pass_context
def datarecord_delete(ctx: click.Context, directory_code, ids):
    """删除数据记录。

    \b
    示例:
        gogeo-cli property datarecord-delete --directory-code DIR001 --ids 1,2,3
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    request = {
        "directoryCode": directory_code,
        "recCodes": ids.split(","),
    }
    result = call_api(ctx, lambda: client.post("/datarec/remove", json_body=request))
    if result is not None:
        output({"removed": result}, ctx.obj["as_json"])


@property_cli.command("datarecord-batch-modify")
@click.option("--directory-code", required=True, help="目录编码")
@click.option("--records", required=True,
              help="数据记录JSON (JSON字符串或@文件路径)")
@click.option("--scene", default=2, type=int,
              help="场景类型: 1-数据列表 2-地图 3-后台调用")
@click.pass_context
def datarecord_batch_modify(ctx: click.Context, directory_code, records, scene):
    """批量修改或新增数据。

    \b
    示例:
        gogeo-cli property datarecord-batch-modify --directory-code DIR001 --records '[{"name":"test"}]'
        gogeo-cli property datarecord-batch-modify --directory-code DIR001 --records @data.json
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)

    if records.startswith("@"):
        file_path = records[1:]
        with open(file_path) as f:
            records_data = json.load(f)
    else:
        records_data = json.loads(records)

    request = {
        "directoryCode": directory_code,
        "records": records_data,
        "scene": scene,
    }

    result = call_api(ctx, lambda: client.post("/datarec/batchModify", json_body=request))
    if result is not None:
        output({"success": result}, ctx.obj["as_json"])


# ---------------------------------------------------------------------------
# import commands (数据导入) - 1个命令
# ---------------------------------------------------------------------------

@property_cli.command("import-url-download")
@click.option("--urls", required=True,
              help="文件URL列表 (逗号分隔，最大支持10个文件)")
@click.pass_context
def import_url_download(ctx: click.Context, urls):
    """通过文件地址导入数据，生成资产。

    \b
    示例:
        gogeo-cli property import-url-download --urls "http://example.com/data.csv"
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    file_list = []
    for url in urls.split(","):
        url = url.strip()
        if url:
            file_name = url.split("/")[-1] if "/" in url else url
            file_list.append({
                "fileUrl": url,
                "fileName": file_name,
            })
    request = {
        "fileList": file_list,
    }
    result = call_api(ctx, lambda: client.post("/asset/data/file/down_load_create_property", json_body=request))
    if result is not None:
        output(result, ctx.obj["as_json"])


# ---------------------------------------------------------------------------
# field commands (字段配置) - 1个命令
# ---------------------------------------------------------------------------

@property_cli.command("field-simple")
@click.option("--directory-code", required=True, help="目录编码")
@click.pass_context
def field_simple(ctx: click.Context, directory_code):
    """获取资产的字段概要信息。

    \b
    示例:
        gogeo-cli property field-simple --directory-code DIR001
    """
    if not check_config(ctx):
        return

    client = make_client(ctx)
    result = call_api(ctx, lambda: client.get("/field_setting/getFieldSimpleData", params={"catalogueCode": directory_code}))
    if result is not None:
        output(result, ctx.obj["as_json"])
