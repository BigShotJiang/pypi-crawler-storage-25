"""Backend client for GoGeo Property REST API.

配置简化：
- api_base_url: 接口地址，如 https://gogeo.topprismdata.com/prod-gogeo-api
- open_api_code: 用户授权码

固定参数（内置在CLI中）：
- gateway_prefix: /promap-property
- api_prefix: /api/v3/property/

Header要求：
- accessType: GOGEO_SERVICE_API (固定值)
- openApiCode: 用户授权码

URL结构:
{api_base_url}/{gateway_prefix}/{api_prefix}/{endpoint}
"""

import json
import urllib.request
import urllib.error
from typing import Optional, Dict, Any


class PropertyClient:
    """HTTP client for GoGeo Property REST API."""

    GATEWAY_PREFIX = "/promap-property"
    API_PREFIX = "/api/v3/property/"

    def __init__(
        self,
        api_base_url: str = "https://gogeo.topprismdata.com/prod-gogeo-api",
        open_api_code: str = "",
        timeout: int = 30,
    ):
        self.api_base_url = api_base_url.rstrip("/")
        self.open_api_code = open_api_code
        self.timeout = timeout
        self.base_url = f"{self.api_base_url}{self.GATEWAY_PREFIX}{self.API_PREFIX}"

    def _build_url(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> str:
        url = self.base_url.rstrip("/") + "/" + endpoint.lstrip("/")
        if params:
            query_parts = []
            for key, value in params.items():
                if value is not None:
                    if isinstance(value, bool):
                        value = str(value).lower()
                    elif isinstance(value, list):
                        value = ",".join(str(v) for v in value)
                    query_parts.append(f"{key}={value}")
            if query_parts:
                url += "?" + "&".join(query_parts)
        return url

    def _get_headers(self) -> Dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "accessType": "GOGEO_SERVICE_API",
        }
        if self.open_api_code:
            headers["openApiCode"] = self.open_api_code
        return headers

    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        body: Optional[Dict[str, Any]] = None,
    ) -> Any:
        url = self._build_url(endpoint, params)
        headers = self._get_headers()
        data = None
        if body:
            data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                response_body = response.read().decode("utf-8")
                result = json.loads(response_body)
                if isinstance(result, dict):
                    if result.get("code") not in (200, 0):
                        error_msg = result.get("msg", "Unknown error")
                        raise RuntimeError(f"API error: {error_msg}")
                    return result.get("data", result)
                return result
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8") if e.fp else ""
            try:
                error_json = json.loads(error_body)
                error_msg = error_json.get("msg", error_body)
            except json.JSONDecodeError:
                error_msg = error_body or str(e)
            raise RuntimeError(f"HTTP {e.code}: {error_msg}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"Connection error: {e.reason}")

    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._make_request("GET", endpoint, params=params)

    def post(self, endpoint: str, json_body: Optional[Dict[str, Any]] = None, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._make_request("POST", endpoint, params=params, body=json_body)

    def put(self, endpoint: str, json_body: Optional[Dict[str, Any]] = None, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._make_request("PUT", endpoint, params=params, body=json_body)

    def delete(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._make_request("DELETE", endpoint, params=params)

    def test_connection(self) -> Dict[str, Any]:
        try:
            result = self.get("/directory/tree", params={"includeData": False})
            return {
                "connected": True,
                "api_base_url": self.api_base_url,
                "message": "连接成功",
            }
        except RuntimeError as e:
            return {
                "connected": False,
                "api_base_url": self.api_base_url,
                "error": str(e),
                "message": f"连接失败: {e}",
            }
