"""GoGeo Property CLI module - Asset management commands."""

from gogeo.property.cli import property_cli

__all__ = ["property_cli"]
