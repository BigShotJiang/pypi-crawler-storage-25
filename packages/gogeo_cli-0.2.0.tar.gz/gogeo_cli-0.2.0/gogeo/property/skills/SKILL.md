---
name: "gogeo-property"
description: "GoGeo Property CLI - 资产管理命令，用于目录管理、数据记录、数据导入等操作"
---

# gogeo-property

GoGeo Property CLI 是一个命令行接口，用于管理地理数据资产。支持资产目录管理、数据记录操作、数据导入等功能。

## 安装

```bash
pip install gogeo-cli
```

## 前置条件

- GoGeo Property API服务可访问
- Python 3.8+
- 有效的用户授权码 (open_api_code)

## 配置

配置读取优先级：

1. 配置文件: `~/.gogeo-cli.yaml`
2. 环境变量: `gogeoOpenApiCode`
3. 命令行参数: `--open-api-code`

```bash
# 交互式配置
gogeo-cli config init

# 直接保存配置
gogeo-cli config save --open-api-code YOUR_CODE

# 查看当前配置
gogeo-cli config show

# 测试连接
gogeo-cli config test
```

## 命令结构

```
gogeo-cli property
├── directory-tree          获取目录树
├── directory-create        创建目录
├── directory-empty-create  创建空资产
├── directory-remove        删除资产
├── directory-rename        重命名资产
├── data-detail             获取资产详情
├── datarecord-list         分页查询数据
├── datarecord-detail       获取数据详情
├── datarecord-delete       删除数据记录
├── datarecord-batch-modify 批量新增/修改数据
├── import-url-download     URL导入创建资产
└── field-simple            获取字段信息
```

## 使用示例

### 目录管理

```bash
# 获取目录树
gogeo-cli property directory-tree

# 按类型过滤
gogeo-cli property directory-tree --type 1    # 个人目录
gogeo-cli property directory-tree --type 2    # 企业目录

# 搜索关键词
gogeo-cli property directory-tree --keyword "测试"

# 创建文件夹
gogeo-cli property directory-create --parent-code ROOT --name "新建文件夹"

# 创建数据节点
gogeo-cli property directory-create --parent-code ROOT --name "数据节点" --type 2

# 创建空资产
gogeo-cli property directory-empty-create --parent-code ROOT --name "点数据" --data-format 0
gogeo-cli property directory-empty-create --parent-code ROOT --name "线数据" --data-format 1
gogeo-cli property directory-empty-create --parent-code ROOT --name "面数据" --data-format 2

# 重命名资产
gogeo-cli property directory-rename --directory-code DIR001 --name "新名称"

# 删除资产
gogeo-cli property directory-remove --directory-code DIR001
```

### 资产数据

```bash
# 获取资产详情
gogeo-cli property data-detail --directory-code DIR001

# JSON格式输出
gogeo-cli property --json data-detail --directory-code DIR001
```

### 数据记录

```bash
# 分页查询数据列表
gogeo-cli property datarecord-list --directory-code DIR001

# 自定义分页
gogeo-cli property datarecord-list --directory-code DIR001 --page-num 1 --page-size 20

# 返回记录ID
gogeo-cli property datarecord-list --directory-code DIR001 --return-id

# 获取单条数据详情
gogeo-cli property datarecord-detail --directory-code DIR001 --record-id 123

# 删除数据记录
gogeo-cli property datarecord-delete --directory-code DIR001 --ids 1,2,3

# 批量新增数据
gogeo-cli property datarecord-batch-modify --directory-code DIR001 --records '[{"name":"test"}]'

# 从文件导入数据
gogeo-cli property datarecord-batch-modify --directory-code DIR001 --records @data.json
```

### 数据导入

```bash
# 单文件导入
gogeo-cli property import-url-download --urls "http://example.com/data.csv"

# 多文件批量导入
gogeo-cli property import-url-download --urls "url1.csv,url2.xlsx,url3.geojson"
```

### 字段配置

```bash
# 获取字段信息
gogeo-cli property field-simple --directory-code DIR001
```

## JSON输出

所有命令支持 `--json` 参数，输出机器可读格式：

```bash
gogeo-cli property --json directory-tree
gogeo-cli property --json data-detail --directory-code DIR001
```

输出示例：
```json
{
  "directoryCode": "DIR001",
  "directoryName": "测试数据",
  "dataFormat": 0,
  "dataNumber": 1000,
  "dataStatus": 3
}
```

## 数据格式类型

| 类型 | 编码 | 说明 |
|------|------|------|
| 点数据 | 0 | 坐标点集合 (如POI) |
| 线数据 | 1 | 线/路径 (如道路) |
| 面数据 | 2 | 多边形/区域 (如行政区划) |

## 目录类型

| 类型 | 编码 | 说明 |
|------|------|------|
| 个人目录 | 1 | 用户个人数据 |
| 企业目录 | 2 | 企业数据 |
| 共享目录 | 3 | 企业共享目录 |

## 节点类型

| 类型 | 编码 | 说明 |
|------|------|------|
| 文件夹 | 1 | 仅用于组织结构 |
| 数据文件 | 2 | 存储资产数据 |

## 字段类型

| 类型 | 编码 | 说明 |
|------|------|------|
| 数值 | 1 | 数字类型 |
| 文本 | 2 | 字符串类型 |
| 选择 | 3 | 选择类型 |
| 日期 | 4 | 日期类型 |

## 场景类型

| 类型 | 编码 | 说明 |
|------|------|------|
| 数据列表 | 1 | 我的资产-数据列表 |
| 地图 | 2 | 地图场景 |
| 后台调用 | 3 | 后台服务调用 |

## 错误处理

API错误返回标准格式：
```json
{
  "code": 400,
  "msg": "gogeo.directory.not.exists",
  "data": null
}
```

CLI在错误时返回非零退出码。错误信息输出到stderr。

## 使用技巧

1. 使用 `--json` 参数便于自动化处理
2. 执行操作前先测试连接: `gogeo-cli config test`
3. 先获取目录树了解结构: `gogeo-cli property directory-tree`
4. 使用目录编码进行所有数据操作
5. 批量操作时使用 `@文件路径` 方式传入数据
