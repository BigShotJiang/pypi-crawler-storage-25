#!/usr/bin/env python3
"""
gogeo-cli - Unified CLI for all GoGeo business API projects.

Each project is a subcommand group:
    gogeo-cli common-task ...    Common-task pipeline APIs (184 endpoints)
    gogeo-cli property ...       Property/Asset management APIs (12 endpoints)
"""

import click

from gogeo.common_task.common_task_cli import cli as common_task_cli
from gogeo.property.cli import property_cli


@click.group(invoke_without_command=True)
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
@click.pass_context
def cli(ctx, json_mode):
    """gogeo-cli - Unified CLI for GoGeo business APIs.

    \b
    模块:
        common-task   任务管道API (空间分析、数据处理、模型计算等)
        property      资产管理API (目录管理、数据记录、数据导入等)

    \b
    配置:
        配置文件: ~/.gogeo-cli.yaml
        环境变量: gogeoOpenApiCode

    \b
    示例:
        gogeo-cli common-task spatial analysis point-cluster --data '...'
        gogeo-cli property directory-tree
        gogeo-cli property data-detail --directory-code DIR001
    """
    ctx.ensure_object(dict)
    ctx.obj["json"] = json_mode
    if ctx.invoked_subcommand is None:
        click.echo(cli.__doc__.strip())


# Register project subcommand groups
cli.add_command(common_task_cli, name="common-task")
cli.add_command(property_cli, name="property")


if __name__ == "__main__":
    cli()
