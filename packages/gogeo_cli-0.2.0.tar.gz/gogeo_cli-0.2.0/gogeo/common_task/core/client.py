"""HTTP client for interacting with the common-task REST API."""

import json
from typing import Optional
from urllib.parse import urljoin

import urllib.request
import urllib.error
import urllib.parse


ACCESS_TYPE = "GOGEO_SERVICE_API"


class TaskAPIClient:
    """Minimal HTTP client using only stdlib (urllib)."""

    def __init__(self, api_url: str, open_api_code: Optional[str] = None, timeout: int = 300, service_prefix: str = "/common-task"):
        self.api_url = api_url.rstrip("/")
        self.open_api_code = open_api_code
        self.timeout = timeout
        self.service_prefix = service_prefix

    def _build_url(self, path: str) -> str:
        if not path.startswith("/"):
            path = f"/{path}"
        return f"{self.api_url}{self.service_prefix}{path}"

    def _build_headers(self, extra_headers: Optional[dict] = None) -> dict:
        headers = {
            "Content-Type": "application/json",
            "accessType": ACCESS_TYPE,
        }
        if self.open_api_code:
            headers["openApiCode"] = self.open_api_code
        if extra_headers:
            headers.update(extra_headers)
        return headers

    def request(
        self,
        method: str,
        path: str,
        data: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict:
        url = self._build_url(path)
        if params:
            query = urllib.parse.urlencode(params)
            url = f"{url}?{query}"

        headers = self._build_headers()
        body = json.dumps(data).encode("utf-8") if data else None

        req = urllib.request.Request(url, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                return result
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")
            return {"error": True, "status": e.code, "message": error_body}
        except urllib.error.URLError as e:
            return {"error": True, "message": str(e.reason)}

    def get(self, path: str, params: Optional[dict] = None) -> dict:
        return self.request("GET", path, params=params)

    def post(self, path: str, data: Optional[dict] = None) -> dict:
        return self.request("POST", path, data=data)

    def put(self, path: str, data: Optional[dict] = None) -> dict:
        return self.request("PUT", path, data=data)

    def delete(self, path: str) -> dict:
        return self.request("DELETE", path)
