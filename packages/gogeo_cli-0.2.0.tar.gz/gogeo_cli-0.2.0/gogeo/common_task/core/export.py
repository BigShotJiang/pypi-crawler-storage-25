"""Export functionality for task results."""

import json
import csv
import io
from pathlib import Path
from typing import Any, Optional


def export_json(data: Any, output_path: str) -> str:
    """Export data as JSON."""
    path = Path(output_path)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str))
    return str(path)


def export_csv(data: list, output_path: str, flatten: bool = True) -> str:
    """Export list of dicts as CSV."""
    if not data:
        Path(output_path).write_text("")
        return output_path

    if flatten:
        rows = [_flatten_dict(d) for d in data]
    else:
        rows = data

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
    Path(output_path).write_text(output.getvalue())
    return output_path


def _flatten_dict(d: dict, parent_key: str = "", sep: str = ".") -> dict:
    """Flatten nested dict."""
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(_flatten_dict(v, new_key, sep=sep).items())
        elif isinstance(v, list):
            items.append((new_key, json.dumps(v, ensure_ascii=False, default=str)))
        else:
            items.append((new_key, v))
    return dict(items)


def export_table(data: list, output_path: str, format: str = "csv") -> str:
    """Export data in specified format."""
    if format == "json":
        return export_json(data, output_path)
    elif format == "csv":
        return export_csv(data, output_path)
    else:
        raise ValueError(f"Unsupported format: {format}")
