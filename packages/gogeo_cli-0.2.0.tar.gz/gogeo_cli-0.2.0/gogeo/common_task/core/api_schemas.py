"""
Parameter schema documentation for all common-task API endpoints.

Uses Chinese descriptions from Java DTO @Schema annotations.
Nested object fields are fully expanded with parent references.
Each schema includes a complete JSON request example.
Enum fields include all valid values in their description.
"""

import json











# Common field definitions (reused across many endpoints)

_POINT_DATA_FIELD = {
    "name": "pointData",
    "type": "Array<Object>",
    "required": True,
    "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f",
    "example": "[{\"code\": \"s1\", \"point\": \"POINT(108.95 34.27)\"}]",
}

_FENCE_DATA_FIELD = {
    "name": "fenceData",
    "type": "Array<Object>",
    "required": True,
    "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f",
    "example": "[{\"code\": \"f1\", \"fence\": \"POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))\"}]",
}

_LINE_DATA_FIELD = {
    "name": "lineData",
    "type": "Array<Object>",
    "required": True,
    "description": "\u7ebf\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c line \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cline \u683c\u5f0f wkt \u683c\u5f0f",
    "example": "[{\"code\": \"l1\", \"line\": \"LINESTRING(108.9 34.2, 109.0 34.3)\"}]",
}

_AGGREGATION_FIELDS = {
    "name": "aggregationFields",
    "type": "Array<AggregationField>",
    "required": False,
    "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u914d\u7f6e\u5217\u8868",
    "example": "[{\"field\": \"num\", \"aggregationType\": \"Sum\"}]",
}

_CUSTOMIZE_FENCE_DATA = {
    "name": "customizeFenceData",
    "type": "Array<Object>",
    "required": False,
    "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e",
    "example": "[{\"code\": \"cf1\", \"fence\": \"POLYGON((...))\"}]",
}

_EFFECTIVE_SCOPE = {
    "name": "effectiveScope",
    "type": "Array<Array<String>>",
    "required": False,
    "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4",
    "example": "[[\"\u5e7f\u4e1c\u7701\", \"\u6df1\u5733\u5e02\"], [\"\u5e7f\u4e1c\u7701\", \"\u5e7f\u5dde\u5e02\"]]",
}

_TRANSLATION_FIELDS = {
    "name": "translationFields",
    "type": "Array<String>",
    "required": False,
    "description": "\u7ed3\u679c\u5197\u4f59\u5b57\u6bb5/\u62fc\u63a5\u5b57\u6bb5",
    "example": "[\"name\", \"address\"]",
}

# Async response structure (Result<ApiTaskPipeLineResponse>)
_ASYNC_RESPONSE = [
    {"name": "code", "type": "String", "description": "\u8fd4\u56de\u7801\uff0c200\u8868\u793a\u6210\u529f"},
    {"name": "message", "type": "String", "description": "\u63d0\u793a\u4fe1\u606f"},
    {"name": "data.pipelineCode", "type": "String", "description": "\u8f93\u51fa\u6a21\u578b\u7f16\u7801"},
    {"name": "data.outPropertyCode", "type": "String", "description": "\u8f93\u51fa\u8d44\u4ea7\u7f16\u7801"},
    {"name": "data.taskStatus", "type": "Integer", "description": "\u6d41\u6c34\u7ebf\u72b6\u6001: 0\u5f85\u542f\u52a8, 1\u5f85\u6267\u884c, 2\u6267\u884c\u4e2d, 3\u6267\u884c\u5b8c\u6210, 4\u6267\u884c\u5931\u8d25, 5\u624b\u52a8\u505c\u6b62, 6\u4e3b\u52a8\u505c\u6b62"},
    {"name": "data.errorMsg", "type": "String", "description": "\u9519\u8bef\u4fe1\u606f\uff08\u4ec5\u5f53\u72b6\u6001\u4e3a\u5931\u8d25\u65f6\u8fd4\u56de\uff09"},
    {"name": "data.filedList[].filedName", "type": "String", "description": "\u5b57\u6bb5\u540d\u79f0"},
    {"name": "data.filedList[].isModelFiled", "type": "Boolean", "description": "\u662f\u5426\u6a21\u578b\u5b57\u6bb5\uff0c\u9ed8\u8ba4false"},
]

# Realtime response structure (Result<TaskPipeRealTimeResponse>)
_REALTIME_RESPONSE = [
    {"name": "code", "type": "String", "description": "\u8fd4\u56de\u7801\uff0c200\u8868\u793a\u6210\u529f"},
    {"name": "message", "type": "String", "description": "\u63d0\u793a\u4fe1\u606f"},
    {"name": "data.dataList", "type": "Array<Map<String,Object>>", "description": "\u6a21\u578b\u6570\u636e\u96c6\u5408"},
    {"name": "data.fieldInfoList", "type": "Array<FieldInfo>", "description": "\u6a21\u578b\u8fd4\u56de\u5b57\u6bb5\u7684\u96c6\u5408"},
    {"name": "data.fieldInfoList[].filedCode", "type": "String", "description": "\u5b57\u6bb5\u7f16\u7801"},
    {"name": "data.fieldInfoList[].filedName", "type": "String", "description": "\u5b57\u6bb5\u63cf\u8ff0"},
]


def _fmt_help(schema):
    """Format a schema dict into help text with Chinese descriptions."""
    lines = []
    lines.append("\b")
    ctrl = schema.get("_controller", "")
    method = schema.get("_method", "")
    http = schema.get("_http", "POST")
    if ctrl and method:
        lines.append(f"\u63a5\u53e3: {ctrl}/{method}")
        lines.append(f"\u8bf7\u6c42\u65b9\u5f0f: {http}")
    lines.append("\u63a5\u53e3\u63cf\u8ff0: " + schema.get("_summary", schema.get("name", "")))
    desc = schema.get("_desc", "")
    if desc:
        lines.append("\u8be6\u7ec6\u63cf\u8ff0: " + desc)
    resp = schema.get("_response", [])
    if resp:
        lines.append("")
        lines.append("\b")
        lines.append("\u8fd4\u56de\u53c2\u6570:")
        for f in resp:
            lines.append(f"  - {f['name']} [{f['type']}]")
            lines.append(f"    \u5b57\u6bb5\u63cf\u8ff0: {f['description']}")
    if schema.get("fields"):
        lines.append("")
        lines.append("\b")
        lines.append("\u53c2\u6570:")
        for f in schema.get("fields", []):
            req = "\u5fc5\u586b" if f["required"] else "\u53ef\u9009"
            lines.append(f"  - {f['name']} [{f['type']}] [{req}]")
            lines.append(f"    \u5b57\u6bb5\u63cf\u8ff0: {f['description']}")
            if "example" in f:
                lines.append(f"    \u793a\u4f8b: {f['example']}")
    if "example" in schema:
        lines.append("")
        lines.append("\b")
        lines.append("\u63a5\u53e3\u8bf7\u6c42\u793a\u4f8b:")
        lines.append("  " + schema["example"])
    return "\n".join(lines)


# ============================================================================
# SCHEMA REGISTRY
# ============================================================================



# SCHEMA REGISTRY


# SCHEMA REGISTRY


# SCHEMA REGISTRY


# SCHEMA REGISTRY


# SCHEMA REGISTRY


# SCHEMA REGISTRY


# SCHEMA REGISTRY


# SCHEMA REGISTRY


# SCHEMA REGISTRY


# SCHEMA REGISTRY
SCHEMAS = {
    "data.text-handling": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "text_handling",
        "_http": "POST",
        "_summary": "\u6587\u672c\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "textData", "type": "TextData", "required": True, "description": "\u5904\u7406\u6570\u636e", "example": "[{\"code\":\"text_001\",\"text\":\"\u6d4b\u8bd5\u6587\u672c\u5185\u5bb9\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "text_001", "parent": "TextData"},
            {"name": "textStr", "type": "String (inner)", "required": True, "description": "\u5f85\u5904\u7406\u7684\u5b57\u6bb5\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "example": "address", "parent": "TextData"},
            {"name": "textHandlingStrategy", "type": "List<TextHandlingStrategy>", "required": True, "description": "\u5904\u7406\u7684\u7b56\u7565"},
            {"name": "policyCode", "type": "PolicyCode (inner)", "required": True, "description": "\u5904\u7406\u7b56\u7565\u53d6\u503c\u679a\u4e3e\uff08\u8f93\u5165\u6c49\u5b57\u65f6\u9700\u6839\u636e\u6c49\u5b57\u5185\u5bb9\u6620\u5c04\u4e3a\u7f16\u7801\uff09\u3002\u53ef\u9009\u503c: 10001=\u5254\u9664-\u62ec\u53f7\u5185\u5bb9; 10002=\u63d0\u53d6-\u62ec\u53f7\u5185\u5bb9; 10003=\u63d0\u53d6-\u8fde\u7eed\u6570\u5b57; 10004=\u5254\u9664-\u8fde\u7eed\u6570\u5b57; 10005=\u63d0\u53d6-\u8fde\u7eed\u6570\u5b57\u5b57\u6bcd; 10006=\u5254\u9664-\u8fde\u7eed\u6570\u5b57\u5b57\u6bcd; 10010=\u5254\u9664-\u7279\u6b8a\u5b57\u7b26-\u5168\u6587; 10013=\u5254\u9664-\u524d\u7f00; 10014=\u5254\u9664-\u540e\u7f00; 10017=\u5305\u542b-\u524d\u7f00; 10018=\u5305\u542b-\u540e\u7f00; 10019=\u901a\u914d\u7b26-\u63d0\u53d6\u5185\u5bb9; 10021=\u63d0\u53d6-\u8fde\u7eed\u5b57\u6bcd; 10022=\u5254\u9664-\u8fde\u7eed\u5b57\u6bcd; 10025=\u63d0\u53d6-\u591a\u8fde\u7eed\u6570\u5b57; 10026=\u63d0\u53d6-\u591a\u8fde\u7eed\u6570\u5b57\u5b57\u6bcd; 10027=\u63d0\u53d6-\u591a\u8fde\u7eed\u5b57\u6bcd; 10029=\u5254\u9664-\u7a7a\u683c", "parent": "TextHandlingStrategy"},
            {"name": "policyConfig", "type": "String (inner)", "required": True, "description": "\u5904\u7406\u65b9\u5f0f\uff1a\u6ca1\u6709\u5219\u8f93\u5165 '\u65e0'; \u63d0\u53d6\u3001\u5254\u9664\u8fde\u7eed\u6570\u5b57\u7c7b\u8f93\u5165\uff1a>X (X\u662f\u5927\u4e8e0\u7684\u6570\u5b57)\uff0c\u5254\u9664\u7279\u6b8a\u5b57\u7b26\u8f93\u5165\u8981\u5254\u9664\u7684\u7279\u6b8a\u5b57\u7b26\uff1a\u4f8b\u5982 $%(\uff08,#,*\uff09) \u7b49\uff0c\u7528\u82f1\u6587\u9017\u53f7\u9694\u5f00\u3002", "parent": "TextHandlingStrategy"}
        ],
        "example": "{\n    \"textData\": {\n        \"propertyCode\": \"text_001\",\n        \"textStr\": \"fieldName\"\n    },\n    \"textHandlingStrategy\": [\n        {\n            \"policyCode\": \"10002\",\n            \"policyConfig\": \"\u65e0\"\n        }\n    ]\n}",
    },
    "data.poi-match": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "poi_matchHandling",
        "_http": "POST",
        "_summary": "poi\u5339\u914d",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u6570\u636e", "example": "{\"propertyCode\":\"customer_001\",\"name\":\"XX\u95e8\u5e97\",\"address\":\"\u5730\u5740\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u4ee3\u8868\u540d\u79f0\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "address", "type": "String (inner)", "required": False, "description": "\u5730\u5740\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u4ee3\u8868\u5730\u5740\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "policyCode", "type": "PolicyCode", "required": True, "description": "\u5904\u7406\u7b56\u7565\u53d6\u503c\u679a\u4e3e\uff08\u8f93\u5165\u6c49\u5b57\u65f6\u9700\u6839\u636e\u6c49\u5b57\u5185\u5bb9\u6620\u5c04\u4e3a\u7f16\u7801\uff09\u3002\u53ef\u9009\u503c: 30003=\u540d\u79f0-\u5305\u542b\u7c7b\u76ee; 30004=\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0-\u5254\u9664\u7c7b\u76ee; 30006=\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee", "example": "30003"},
            {"name": "policyConfig", "type": "List<Category>", "required": False, "description": "\u7c7b\u76ee\u9009\u62e9\uff0c\u4f8b\u5982\u683c\u5f0f [{\"name\": \"\u7f8e\u98df\", \"subCategories\": [\"\u897f\u9910\", \"\u5df4\u897f\u83dc\"]}]"},
            {"name": "name", "type": "String (inner)", "required": False, "description": "\u7c7b\u76ee\u540d\u79f0\uff0c\u975e\u5fc5\u586b", "example": "\u6d4b\u8bd5\u540d\u79f0", "parent": "Category"},
            {"name": "subCategories", "type": "List<String> (inner)", "required": False, "description": "\u5b50\u7c7b\u76ee\u5217\u8868", "example": "[\"subcategories\"]", "parent": "Category"}
        ],
        "example": "{\n    \"customerData\": {\n        \"propertyCode\": \"customer_001\",\n        \"name\": \"name\",\n        \"address\": \"address\"\n    },\n    \"policyCode\": \"30003\",\n    \"policyConfig\": []\n}",
    },
    "data.ka-match": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "ka_matchHandling",
        "_http": "POST",
        "_summary": "ka\u5339\u914d\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u6570\u636e", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "kaData", "type": "KaData", "required": True, "description": "ka\u6570\u636e", "example": "{\"propertyCode\":\"ka_001\",\"keyword\":\"\u80af\u5fb7\u57fa\",\"trademarkName\":\"KFC\",\"screen\":\"\u5916\u5356\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "Ka\u8d44\u4ea7\u7f16\u7801", "example": "ka_001", "parent": "KaData"},
            {"name": "keyword", "type": "String (inner)", "required": True, "description": "\u5173\u952e\u8bcd\uff1aka\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "\u80af\u5fb7\u57fa", "parent": "KaData"},
            {"name": "trademarkName", "type": "String (inner)", "required": True, "description": "\u54c1\u724c\u540d\uff1aka\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "KFC", "parent": "KaData"},
            {"name": "screen", "type": "String (inner)", "required": False, "description": "\u5c4f\u853d\u8bcd\uff1aka\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "\u5c4f\u853d\u8bcd", "parent": "KaData"}
        ],
        "example": "{\n    \"customerData\": {\n        \"propertyCode\": \"customer_001\",\n        \"name\": \"name\"\n    },\n    \"kaData\": {\n        \"propertyCode\": \"ka_001\",\n        \"keyword\": \"\u5173\u952e\u8bcd\",\n        \"trademarkName\": \"\u54c1\u724c\u540d\",\n        \"screen\": \"\u5c4f\u853d\u8bcd\"\n    }\n}",
    },
    "data.duplicate-marking": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "duplicate_marking",
        "_http": "POST",
        "_summary": "\u91cd\u590d\u6807\u8bb0",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "groupField1", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb51\uff1a\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name"},
            {"name": "groupField2", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb52\uff1a\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "city"},
            {"name": "groupField3", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb53\uff1a\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "province"},
            {"name": "groupField4", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb54\uff1a\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address"},
            {"name": "groupField5", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb55\uff1a\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "phone"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"groupField1\": \"name\",\n    \"groupField2\": \"city\",\n    \"groupField3\": \"province\",\n    \"groupField4\": \"district\",\n    \"groupField5\": \"groupField5\"\n}",
    },
    "data.text-concat": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "text_concatenation",
        "_http": "POST",
        "_summary": "\u6587\u672c\u62fc\u63a5",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "concatFields", "type": "List<String>", "required": True, "description": "\u62fc\u63a5\u5b57\u6bb5\uff1a\u8d44\u4ea7\u7684\u5b57\u6bb5 \u4f8b\u5982['\u7701','\u5e02','\u533a','\u5730\u5740']", "example": "[\"concatfields\"]"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"concatFields\": [\n        \"concatFields\"\n    ]\n}",
    },
    "data.exact-match": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "exact_match",
        "_http": "POST",
        "_summary": "\u5b8c\u5168\u5339\u914d",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u6570\u636e", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "txData", "type": "TxData", "required": True, "description": "\u817e\u8baf\u6570\u636e", "example": "{\"data\":[{\"code\":\"tx_001\",\"name\":\"\u817e\u8baf\u76ee\u6807\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "tx_001", "parent": "TxData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "poi_name", "parent": "TxData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u5b57\u6bb5", "example": "poi_address", "parent": "TxData"}
        ],
        "example": "{\n    \"customerData\": {\n        \"propertyCode\": \"asset_001\",\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"txData\": {\n        \"propertyCode\": \"asset_001\",\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    }\n}",
    },
    "data.similarity": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "similarity_processing",
        "_http": "POST",
        "_summary": "\u76f8\u4f3c\u5ea6\u5904\u7406\u8bf7\u6c42\u7c7b",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u6570\u636e", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "txData", "type": "TxData", "required": True, "description": "\u76ee\u6807\u6570\u636e", "example": "{\"data\":[{\"code\":\"tx_001\",\"name\":\"\u817e\u8baf\u76ee\u6807\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "tx_001", "parent": "TxData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "poi_name", "parent": "TxData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u5b57\u6bb5", "example": "poi_address", "parent": "TxData"},
            {"name": "policyCode", "type": "PolicyCode", "required": True, "description": "\u76f8\u4f3c\u5ea6\u65b9\u5f0f\u3002POI\u5339\u914d\u5904\u7406\u65b9\u5f0f\u3002\u53ef\u9009\u503c: 30003=\u540d\u79f0-\u5305\u542b\u7c7b\u76ee; 30004=\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0-\u5254\u9664\u7c7b\u76ee; 30006=\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee"},
            {"name": "similarity", "type": "Double", "required": True, "description": "\u76f8\u4f3c\u5ea6 \u6570\u503c\u7c7b\u578b\uff0c\u503c 0~1 \u6700\u5927\u503c\u4e0d\u80fd\u8d85\u8fc71", "example": "0.85"},
            {"name": "step", "type": "Integer", "required": True, "description": "\u6b65\u957f \u5355\u4f4d:(\u7c73); isLng \u662ftrue \u662f\u5fc5\u586b  \u6570\u503c\u7c7b\u578b", "example": "100"},
            {"name": "distance", "type": "Double", "required": False, "description": "\u8ddd\u79bb \u5355\u4f4d:(\u7c73); isLng \u662ftrue \u662f\u5fc5\u586b  \u6570\u503c\u7c7b\u578b", "example": "500"}
        ],
        "example": "{\n    \"customerData\": {\n        \"propertyCode\": \"asset_001\",\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"txData\": {\n        \"propertyCode\": \"asset_001\",\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"policyCode\": \"30003\",\n    \"similarity\": 1,\n    \"step\": 1,\n    \"distance\": 1\n}",
    },
    "data.address-parse": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "address_parsing",
        "_http": "POST",
        "_summary": "\u5730\u5740\u89e3\u6790\u8bf7\u6c42\u7c7b",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "address", "type": "String", "required": True, "description": "\u5730\u5740\u5b57\u6bb5", "example": "address"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"address\": \"\u5317\u4eac\u5e02\u671d\u9633\u533a\"\n}",
    },
    "data.reverse-address-parse": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "reverse_address_parsing",
        "_http": "POST",
        "_summary": "\u9006\u5730\u5740\u89e3\u6790",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u552e\u70b9\u6570\u636e", "example": "point_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\"\n}",
    },
    "data.batch-status": {
        "_controller": "TaskPipelineDataApiController",
        "_method": "batch_query_task_status",
        "_http": "POST",
        "_summary": "\u6279\u91cf\u67e5\u8be2\u4efb\u52a1\u72b6\u6001",
        "_desc": "\u6839\u636e\u6d41\u6c34\u7ebf\u7f16\u7801\u6279\u91cf\u67e5\u8be2\u4efb\u52a1\u4fe1\u606f",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pipelineCodes", "type": "List<String>", "required": True, "description": "\u6d41\u6c34\u7ebf\u7f16\u7801\u5217\u8868", "example": "[\"pipelineCode1\", \"pipelineCode2\"]"}
        ],
        "example": "{\n    \"pipelineCodes\": [\n        \"pipelineCodes\"\n    ]\n}",
    },
    "spatial.analysis.projection-area": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "projection_area_calculation",
        "_http": "POST",
        "_summary": "\u6295\u5f71\u9762\u79ef\u8ba1\u7b97\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u9762\u8d44\u4ea7\u7f16\u7801", "example": "fence_property_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\"\n}",
    },
    "spatial.analysis.fence-buffer": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "fence_broad_buffer",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5916\u6269\u7f13\u51b2\u533a",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u552e\u70b9\u6570\u636e", "example": "fence_001"},
            {"name": "bufferArea", "type": "String", "required": True, "description": "\u5916\u6269\u8303\u56f4\uff08\u7c73\uff09", "example": "1000"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"bufferArea\": \"bufferArea\"\n}",
    },
    "spatial.analysis.point-cluster": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "point_cluster_analysis",
        "_http": "POST",
        "_summary": "\u70b9\u805a\u7c7b\u5206\u6790\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_property_001"},
            {"name": "partitionNum", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf", "example": "10"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"partitionNum\": 10\n}",
    },
    "spatial.analysis.fence-cluster": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "fence_cluster_analysis",
        "_http": "POST",
        "_summary": "\u9762\u805a\u7c7b\u5206\u6790\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_property_001"},
            {"name": "partitionNum", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf", "example": "10"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"partitionNum\": 10\n}",
    },
    "spatial.analysis.belonging-area-v2": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "belonging_area_generate_v2",
        "_http": "POST",
        "_summary": "\u5f52\u5c5e\u533a\u57df\u751f\u6210 V2 \u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointData", "type": "PointData", "required": True, "description": "\u70b9\u6570\u636e", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff0c\u5fc5\u586b", "example": "point_001", "parent": "PointData"},
            {"name": "groupCode", "type": "String (inner)", "required": True, "description": "\u5206\u7ec4\u7f16\u7801\uff0c\u975e\u5fc5\u586b", "example": "group_001", "parent": "PointData"},
            {"name": "num", "type": "String (inner)", "required": False, "description": "\u6f5c\u529b\u5b57\u6bb5\uff0c\u975e\u5fc5\u586b", "example": "potentialValue", "parent": "PointData"},
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u56f4\u680f\u6570\u636e\u8d44\u4ea7\u7f16\u7801"},
            {"name": "customizeFencePropertyCode", "type": "String", "required": False, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e\u8d44\u4ea7\u7f16\u7801"},
            {"name": "connectType", "type": "ConnectType", "required": True, "description": "\u5212\u5206\u7c7b\u578b\uff1a1-\u7f51\u683c\uff0c2-\u8702\u7a9d\u3002\u8fde\u63a5/\u7f51\u683c\u7c7b\u578b(V2)\u3002\u53ef\u9009\u503c: 1=\u7f51\u683c; 2=\u8702\u7a9d", "example": "1"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\uff1acity-\u57ce\u5e02\uff0cdistrict-\u533a\u53bf\uff0cprovince-\u7701\u4efd\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4", "example": "[\"effectivescope\"]"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": {\n        \"propertyCode\": \"asset_001\",\n        \"groupCode\": \"group_001\",\n        \"num\": \"potentialValue\"\n    },\n    \"fencePropertyCode\": \"fence_asset\",\n    \"customizeFencePropertyCode\": \"customizeFencePropertyCode\",\n    \"connectType\": \"1\",\n    \"boundaryLevel\": \"province\",\n    \"effectiveScope\": [\n        \"effectiveScope\"\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.analysis.affiliation-area-v1": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "affiliation_area_generate_v1_custom_polygon",
        "_http": "POST",
        "_summary": "\u5f52\u5c5e\u533a\u57df\u751f\u6210 V1-\u81ea\u5b9a\u4e49\u9762\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointDataPropertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "fenceDataPropertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "name", "type": "String", "required": True, "description": "\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5\uff0c\u5fc5\u586b", "example": "areaName"},
            {"name": "num", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u6f5c\u529b\u5b57\u6bb5", "example": "potentialValue"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "potentialValue"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointDataPropertyCode\": \"pointDataPropertyCode\",\n    \"fenceDataPropertyCode\": \"fenceDataPropertyCode\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"num\": \"potentialValue\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.analysis.cluster-center": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "cluster_center",
        "_http": "POST",
        "_summary": "\u70b9\u805a\u7c7b\u4e2d\u5fc3\u70b9\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "partitionNum", "type": "Integer", "required": False, "description": ""},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"partitionNum\": 10,\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.analysis.equal-value-split": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "equal_value_split_v2",
        "_http": "POST",
        "_summary": "\u7b49\u6f5c\u529b\u5212\u5206V2-\u9762\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "num", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5", "example": "sales_volume"},
            {"name": "splitCount", "type": "Integer", "required": False, "description": ""},
            {"name": "balanceValue", "type": "Integer", "required": False, "description": ""},
            {"name": "compareValue", "type": "Integer", "required": False, "description": ""},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"num\": \"potentialValue\",\n    \"splitCount\": 5,\n    \"balanceValue\": 1,\n    \"compareValue\": 1,\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.analysis.area-split": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "area_split_plan",
        "_http": "POST",
        "_summary": "\u7b49\u9762\u79ef\u5212\u5206\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "splitCount", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf", "example": "5"},
            {"name": "balance", "type": "Integer", "required": True, "description": "\u5e73\u8861\u503c", "example": "50"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[...]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"splitCount\": 5,\n    \"balance\": 50,\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.analysis.potential-split": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "potential_area_split_plan",
        "_http": "POST",
        "_summary": "\u7b49\u6f5c\u529b\u5212\u5206\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u7b49\u6f5c\u529b\u5212\u5206\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "num", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5", "example": "sales_volume"},
            {"name": "splitCount", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf", "example": "5"},
            {"name": "balance", "type": "Integer", "required": True, "description": "\u5e73\u8861\u503c", "example": "50"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[...]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"num\": \"potentialValue\",\n    \"splitCount\": 5,\n    \"balance\": 50,\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.analysis.fence-crossing": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "fence_crossing",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u4e0d\u76f8\u4ea4\u7684\u533a\u57df\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "sourcePropertyCode", "type": "String", "required": False, "description": ""},
            {"name": "targetPropertyCode", "type": "String", "required": False, "description": ""}
        ],
        "example": "{\n    \"sourcePropertyCode\": \"source_asset\",\n    \"targetPropertyCode\": \"target_asset\"\n}",
    },
    "spatial.analysis.line-buffer": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "line_buffer",
        "_http": "POST",
        "_summary": "\u7ebf\u5916\u6269\u7f13\u51b2\u533a\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "linePropertyCode", "type": "String", "required": False, "description": ""},
            {"name": "buffer", "type": "Integer", "required": False, "description": ""},
            {"name": "endCapStyle", "type": "BufferStyle", "required": False, "description": "\u7ebf\u7f13\u51b2\u7aef\u70b9\u6837\u5f0f\uff0c\u53ef\u9009\u503c: 1=\u534a\u5706; 2=\u5e73\u9762; 3=\u65b9\u5f62"},
            {"name": "quadrantSegments", "type": "Integer", "required": False, "description": ""}
        ],
        "example": "{\n    \"linePropertyCode\": \"line_asset\",\n    \"buffer\": 500,\n    \"endCapStyle\": \"1\",\n    \"quadrantSegments\": 8\n}",
    },
    "spatial.analysis.hexagon-split": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "hexagon_fence_split_polygon",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5185\u751f\u6210\u8702\u7a9d\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": False, "description": ""},
            {"name": "sideLength", "type": "Integer", "required": False, "description": ""},
            {"name": "splitMode", "type": "SplitMode", "required": False, "description": "\u56f4\u680f\u5206\u88c2\u6a21\u5f0f\u3002\u53ef\u9009\u503c: 1=\u76f8\u4ea4\u4fdd\u7559; 2=\u76f8\u4ea4\u88c1\u526a; 3=\u5305\u542b\u4fdd\u7559; 4=\u4e2d\u5fc3\u5728\u56f4\u680f\u5185\u4fdd\u7559"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"sideLength\": 100,\n    \"splitMode\": \"1\"\n}",
    },
    "spatial.analysis.grid-split": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "grid_fence_split_polygon",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5185\u751f\u6210\u7f51\u683c\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": False, "description": ""},
            {"name": "sideLength", "type": "Integer", "required": False, "description": ""},
            {"name": "splitMode", "type": "SplitMode", "required": False, "description": "\u56f4\u680f\u5206\u88c2\u6a21\u5f0f\u3002\u53ef\u9009\u503c: 1=\u76f8\u4ea4\u4fdd\u7559; 2=\u76f8\u4ea4\u88c1\u526a; 3=\u5305\u542b\u4fdd\u7559; 4=\u4e2d\u5fc3\u5728\u56f4\u680f\u5185\u4fdd\u7559"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"sideLength\": 100,\n    \"splitMode\": \"1\"\n}",
    },
    "spatial.analysis.kmeans": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "point_kmeans",
        "_http": "POST",
        "_summary": "KMeans \u7b97\u6cd5\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801"},
            {"name": "clusterType", "type": "String", "required": True, "description": "\u805a\u7c7b\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u9762; 2=\u70b9\u8f6c\u9762"},
            {"name": "clusterAlgorithm", "type": "ClusterAlgorithm", "required": True, "description": "\u805a\u7c7b\u7b97\u6cd5\u3002\u53ef\u9009\u503c: 0=Kmeans"},
            {"name": "gridType", "type": "GridType", "required": False, "description": "\u7f51\u683c\u7c7b\u578b\u3002KMeans\u7f51\u683c/\u8702\u7a9d\u7c7b\u578b\u3002\u53ef\u9009\u503c: GD_r1000=R1000\u7f51\u683c; GD_r2000=R2000\u7f51\u683c; GD_r500=R500\u7f51\u683c; HD_r1000=R1000\u8702\u7a9d; HD_r2000=R2000\u8702\u7a9d; HD_r500=R500\u8702\u7a9d; RD_four=4\u7ea7\u8def\u7f51"},
            {"name": "amount", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"clusterType\": \"1\",\n    \"clusterAlgorithm\": \"0\",\n    \"gridType\": \"GD_r1000\",\n    \"amount\": 5\n}",
    },
    "spatial.analysis.random-sample": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "fence_random_sample",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5185\u968f\u673a\u53d6\u6837\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "count", "type": "Integer", "required": True, "description": "\u53d6\u6837\u6570\uff08\u4e2a\uff09", "example": "100"}
        ],
        "example": "{\n    \"pointPropertyCode\": \"point_asset\",\n    \"fencePropertyCode\": \"fence_asset\",\n    \"count\": 100\n}",
    },
    "spatial.analysis.potential-classification": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "potential_classification_v2_point",
        "_http": "POST",
        "_summary": "\u7b49\u6f5c\u529b\u5212\u5206 V2-\u70b9\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointData", "type": "PointData", "required": True, "description": "\u70b9\u6570\u636e", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff0c\u5fc5\u586b", "example": "point_001", "parent": "PointData"},
            {"name": "groupCode", "type": "String (inner)", "required": True, "description": "\u5206\u7ec4\u7f16\u7801\uff0c\u975e\u5fc5\u586b", "example": "group_001", "parent": "PointData"},
            {"name": "num", "type": "String (inner)", "required": False, "description": "\u6f5c\u529b\u5b57\u6bb5\uff0c\u975e\u5fc5\u586b", "example": "potentialValue", "parent": "PointData"},
            {"name": "customizeFencePropertyCode", "type": "String", "required": True, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e\u8d44\u4ea7\u7f16\u7801"},
            {"name": "connectType", "type": "ConnectType", "required": False, "description": "\u8fde\u63a5/\u7f51\u683c\u7c7b\u578b(V2)\u3002\u53ef\u9009\u503c: 1=\u7f51\u683c; 2=\u8702\u7a9d"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": False, "description": "\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4\uff08\u591a\u9009\uff09"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": {\n        \"propertyCode\": \"asset_001\",\n        \"groupCode\": \"group_001\",\n        \"num\": \"potentialValue\"\n    },\n    \"customizeFencePropertyCode\": \"customizeFencePropertyCode\",\n    \"connectType\": \"1\",\n    \"boundaryLevel\": \"province\",\n    \"effectiveScope\": [\n        \"effectiveScope\"\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.analysis.random-points": {
        "_controller": "TaskPipelineSpatialAnalysisController",
        "_method": "point_random_create",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5185\u521b\u5efa\u968f\u673a\u70b9",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u552e\u70b9\u6570\u636e", "example": "point_001"},
            {"name": "randomNum", "type": "String", "required": True, "description": "\u968f\u673a\u70b9\u4e2a\u6570", "example": "randomnum"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "\u7ed3\u679c\u62fc\u63a5", "example": "[\"translationfields\"]"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"randomNum\": \"randomNum\",\n    \"translationFields\": [\n        \"translationFields\"\n    ]\n}",
    },
    "spatial.calculation.point-outside-fence": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "point_outside_fence",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5916\u7684\u70b9\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "buffer", "type": "Integer", "required": True, "description": "\u5916\u6269\u8303\u56f4\uff08\u7c73\uff09", "example": "100"},
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u9762\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"}
        ],
        "example": "{\n    \"buffer\": 500,\n    \"pointPropertyCode\": \"point_asset\",\n    \"fencePropertyCode\": \"fence_asset\"\n}",
    },
    "spatial.calculation.scatter-fence": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "scatter_points_build_fence",
        "_http": "POST",
        "_summary": "\u6563\u70b9\u6784\u5efa\u9762\u6570\u636e\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"},
            {"name": "propertyCode", "type": "String", "required": False, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "groupField", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "example": "region"},
            {"name": "fenceType", "type": "FenceType", "required": False, "description": "\u56f4\u680f\u7c7b\u578b\u3002\u6563\u70b9\u6784\u56f4\u680f\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u51f8\u5305; 2=\u51f9\u5305; 3=\u5916\u5207\u77e9\u5f62", "example": "1"}
        ],
        "example": "{\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ],\n    \"propertyCode\": \"asset_001\",\n    \"groupField\": \"groupField\",\n    \"fenceType\": \"1\"\n}",
    },
    "spatial.calculation.point-in-fence": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "point_inside_fence",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u91cc\u7684\u70b9\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u9762\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "buffer", "type": "Integer", "required": False, "description": "\u5916\u6269\u8303\u56f4\uff08\u7c73\uff09", "example": "100"},
            {"name": "oneToOneFlag", "type": "Boolean", "required": True, "description": "\u5224\u5b9a\u65b9\u5f0f\uff1atrue-\u5355\u56f4\u680f\uff0cfalse-\u591a\u56f4\u680f", "example": "true"},
            {"name": "isAll", "type": "Boolean", "required": True, "description": "\u662f\u5426\u5168\u91cf\uff1atrue-\u662f\uff0cfalse-\u5426", "example": "true"},
            {"name": "translationFields", "type": "List<String>", "required": False, "description": "\u62fc\u63a5\u5b57\u6bb5 (\u56f4\u680f\u6570\u636e\u7684\u5b57\u6bb5)", "example": "[\"name\",\"type\"]"}
        ],
        "example": "{\n    \"pointPropertyCode\": \"point_asset\",\n    \"fencePropertyCode\": \"fence_asset\",\n    \"buffer\": 100,\n    \"oneToOneFlag\": true,\n    \"isAll\": true,\n    \"translationFields\": [\n        \"name\",\n        \"type\"\n    ]\n}",
    },
    "spatial.calculation.fence-of-point": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "fence_of_point",
        "_http": "POST",
        "_summary": "\u70b9\u6240\u5728\u56f4\u680f\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "buffer", "type": "Integer", "required": False, "description": "\u5916\u6269\u8303\u56f4\uff08\u7c73\uff09", "example": "100"},
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u9762\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u7ed3\u679c\u805a\u5408\u914d\u7f6e\u5217\u8868", "example": "[{\"field\":\"fieldName\",\"aggregationType\":\"Avg\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"buffer\": 500,\n    \"pointPropertyCode\": \"point_asset\",\n    \"fencePropertyCode\": \"fence_asset\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.calculation.fence-without-point": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "fence_without_point",
        "_http": "POST",
        "_summary": "\u4e0d\u5305\u542b\u70b9\u7684\u56f4\u680f\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "buffer", "type": "Integer", "required": True, "description": "\u5916\u6269\u8303\u56f4\uff08\u7c73\uff09", "example": "100"},
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u9762\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"}
        ],
        "example": "{\n    \"buffer\": 500,\n    \"pointPropertyCode\": \"point_asset\",\n    \"fencePropertyCode\": \"fence_asset\"\n}",
    },
    "spatial.calculation.fence-intersection-area": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "fence_intersection_area",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u76f8\u4ea4\u7684\u533a\u57df\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "mainPropertyCode", "type": "String", "required": True, "description": "\u4e3b\u6570\u636e\u9762\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "auxiliaryPropertyCode", "type": "String", "required": True, "description": "\u8f85\u6570\u636e\u9762\u8d44\u4ea7\u7f16\u7801", "example": "fence_002"}
        ],
        "example": "{\n    \"mainPropertyCode\": \"mainPropertyCode\",\n    \"auxiliaryPropertyCode\": \"auxiliaryPropertyCode\"\n}",
    },
    "spatial.calculation.belonging-area-v1": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "belonging_area_generate_v1",
        "_http": "POST",
        "_summary": "\u5f52\u5c5e\u533a\u57df\u751f\u6210 V1 \u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "name", "type": "String", "required": True, "description": "\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5", "example": "areaName"},
            {"name": "num", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u6f5c\u529b\u5b57\u6bb5", "example": "potentialValue"},
            {"name": "connectType", "type": "ConnectType", "required": True, "description": "\u8fde\u63a5\u65b9\u5f0f\uff1a1-\u76f4\u7ebf\uff0c2-\u7f51\u683c\uff0c3-\u8702\u7a9d\u3002\u8fde\u63a5/\u7f51\u683c\u7c7b\u578b(V2)\u3002\u53ef\u9009\u503c: 1=\u7f51\u683c; 2=\u8702\u7a9d", "example": "1"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": False, "description": "\u8fb9\u754c\u7b49\u7ea7\uff0c\u8fde\u63a5\u65b9\u5f0f\u4e3a 2 \u6216 3 \u65f6\u5fc5\u586b\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"num\": \"potentialValue\",\n    \"connectType\": \"1\",\n    \"boundaryLevel\": \"province\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.calculation.voronoi": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "voronoi_diagram",
        "_http": "POST",
        "_summary": "\u6cf0\u68ee\u591a\u8fb9\u5f62\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": False, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "bufferProportion", "type": "Integer", "required": False, "description": "\u7f13\u51b2\u6bd4\u4f8b (%)", "example": "1.0"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"bufferProportion\": 1\n}",
    },
    "spatial.calculation.scu-h3": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "scu_generate_by_h3",
        "_http": "POST",
        "_summary": "SCU-H3\u6807\u51c6\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4", "example": "[\"effectivescope\"]"},
            {"name": "pointPropertyCode", "type": "String", "required": False, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "potential", "type": "String", "required": False, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "example": "potential_value"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": False, "description": "\u751f\u6210\u65b9\u5411\u3002\u5c42\u7ea7\u7f51\u683c\u5206\u88c2/\u5408\u5e76\u751f\u6210\u65b9\u5411\u3002\u53ef\u9009\u503c: bigToSmall=\u4ece\u5927\u5230\u5c0f; smallToBig=\u4ece\u5c0f\u5230\u5927"},
            {"name": "splitValue", "type": "Integer", "required": False, "description": "\u5212\u5206\u503c"},
            {"name": "zoomStart", "type": "Integer", "required": False, "description": "H3 \u5f00\u59cb\u7ea7\u522b"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": False, "description": "\u8fb9\u754c\u7b49\u7ea7\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf"},
            {"name": "customizeFencePropertyCode", "type": "String", "required": False, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u8d44\u4ea7\u7f16\u7801"}
        ],
        "example": "{\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ],\n    \"effectiveScope\": [\n        \"effectiveScope\"\n    ],\n    \"pointPropertyCode\": \"point_asset\",\n    \"potential\": \"potential\",\n    \"generateDirection\": \"bigToSmall\",\n    \"splitValue\": 1,\n    \"zoomStart\": 5,\n    \"boundaryLevel\": \"province\",\n    \"customizeFencePropertyCode\": \"customizeFencePropertyCode\"\n}",
    },
    "spatial.calculation.scu-geohash": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "scu_geohash_generate",
        "_http": "POST",
        "_summary": "SCU-GEOHASH \u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointData", "type": "PointData", "required": True, "description": "\u70b9\u6570\u636e", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff0c\u5fc5\u586b", "example": "point_001", "parent": "PointData"},
            {"name": "groupCode", "type": "String (inner)", "required": True, "description": "\u5206\u7ec4\u7f16\u7801\uff0c\u975e\u5fc5\u586b", "example": "group_001", "parent": "PointData"},
            {"name": "num", "type": "String (inner)", "required": False, "description": "\u6f5c\u529b\u5b57\u6bb5\uff0c\u975e\u5fc5\u586b", "example": "potentialValue", "parent": "PointData"},
            {"name": "centerPoint", "type": "CenterPoint", "required": True, "description": "\u805a\u7c7b\u6570\u636e"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "center_001", "parent": "CenterPoint"},
            {"name": "center", "type": "String (inner)", "required": True, "description": "\u4e2d\u5fc3\u70b9", "example": "center_A", "parent": "CenterPoint"},
            {"name": "customizeFenceDataPropertyCode", "type": "String", "required": True, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e"},
            {"name": "paramJson", "type": "ParamJson", "required": True, "description": "\u57fa\u672c\u53c2\u6570"},
            {"name": "zoomStart", "type": "Integer (inner)", "required": False, "description": "\u5f00\u59cb\u7ea7\u522b", "example": "5", "parent": "ParamJson"},
            {"name": "minValue", "type": "Integer (inner)", "required": True, "description": "\u6f5c\u529b\u533a\u95f4\u6700\u5c0f\u503c", "example": "0", "parent": "ParamJson"},
            {"name": "maxValue", "type": "Integer (inner)", "required": True, "description": "\u6f5c\u529b\u533a\u95f4\u6700\u5927\u503c", "example": "1000", "parent": "ParamJson"},
            {"name": "boundaryLevel", "type": "BoundaryLevel (inner)", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city", "parent": "ParamJson"},
            {"name": "effectiveScope", "type": "List<List<String>> (inner)", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4", "example": "[\"effectivescope\"]", "parent": "ParamJson"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": {\n        \"propertyCode\": \"asset_001\",\n        \"groupCode\": \"group_001\",\n        \"num\": \"potentialValue\"\n    },\n    \"centerPoint\": {\n        \"propertyCode\": \"asset_001\",\n        \"center\": \"center\"\n    },\n    \"customizeFenceDataPropertyCode\": \"customizeFenceDataPropertyCode\",\n    \"paramJson\": {\n        \"zoomStart\": 5,\n        \"minValue\": 0,\n        \"maxValue\": 100,\n        \"boundaryLevel\": \"province\",\n        \"effectiveScope\": [\n            \"effectiveScope\"\n        ]\n    },\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.calculation.scu-h3-merge": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "scu_h3_merge",
        "_http": "POST",
        "_summary": "SCU-H3 \u5408\u5e76\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u56f4\u680f\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "potential", "type": "String", "required": True, "description": "\u6f5c\u529b\u503c\u5b57\u6bb5", "example": "potentialValue"},
            {"name": "minValue", "type": "Integer", "required": True, "description": "\u6f5c\u529b\u533a\u95f4\u6700\u5c0f\u503c", "example": "0"},
            {"name": "maxValue", "type": "Integer", "required": True, "description": "\u6f5c\u529b\u533a\u95f4\u6700\u5927\u503c", "example": "9999999"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"potential\": \"potential\",\n    \"minValue\": 0,\n    \"maxValue\": 100\n}",
    },
    "spatial.calculation.scu-s2": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "scu_s2_standard_generate",
        "_http": "POST",
        "_summary": "SCU-S2 \u6807\u51c6\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": True, "description": "\u751f\u6210\u65b9\u5411\u3002\u5c42\u7ea7\u7f51\u683c\u5206\u88c2/\u5408\u5e76\u751f\u6210\u65b9\u5411\u3002\u53ef\u9009\u503c: bigToSmall=\u4ece\u5927\u5230\u5c0f; smallToBig=\u4ece\u5c0f\u5230\u5927", "example": "bigToSmall"},
            {"name": "potential", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5", "example": "bigToSmall"},
            {"name": "splitValue", "type": "Integer", "required": True, "description": "\u5212\u5206\u503c"},
            {"name": "zoomStart", "type": "Integer", "required": True, "description": "S2 \u5f00\u59cb\u7ea7\u522b"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"},
            {"name": "customizeFenceData", "type": "CustomizeFenceData", "required": True, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e", "example": "[{\"code\":\"fence_002\",\"fence\":\"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff0c\u5fc5\u586b", "example": "customize_fence_001", "parent": "CustomizeFenceData"},
            {"name": "customizeFenceData", "type": "String (inner)", "required": True, "description": "\u81ea\u5b9a\u4e49\u8303\u56f4\u56f4\u680f\uff0c\u5fc5\u586b", "example": "[{\"code\":\"fence_002\",\"fence\":\"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))\"}]", "parent": "CustomizeFenceData"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4"}
        ],
        "example": "{\n    \"pointPropertyCode\": \"point_asset\",\n    \"generateDirection\": \"bigToSmall\",\n    \"potential\": \"potential\",\n    \"splitValue\": 1,\n    \"zoomStart\": 5,\n    \"boundaryLevel\": \"province\",\n    \"customizeFenceData\": {\n        \"propertyCode\": \"asset_001\",\n        \"customizeFenceData\": \"customizeFenceData\"\n    },\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ],\n    \"effectiveScope\": [\n        \"effectiveScope\"\n    ]\n}",
    },
    "spatial.calculation.scu-admin": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "scu_admin_division_generate",
        "_http": "POST",
        "_summary": "SCU-\u884c\u653f\u533a\u5212\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": True, "description": "\u751f\u6210\u65b9\u5411\u3002\u5c42\u7ea7\u7f51\u683c\u5206\u88c2/\u5408\u5e76\u751f\u6210\u65b9\u5411\u3002\u53ef\u9009\u503c: bigToSmall=\u4ece\u5927\u5230\u5c0f; smallToBig=\u4ece\u5c0f\u5230\u5927", "example": "bigToSmall"},
            {"name": "potential", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5", "example": "bigToSmall"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"}
        ],
        "example": "{\n    \"pointPropertyCode\": \"point_asset\",\n    \"generateDirection\": \"bigToSmall\",\n    \"potential\": \"potential\",\n    \"boundaryLevel\": \"province\"\n}",
    },
    "spatial.calculation.fence-contain": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "fence_contain_fence",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5305\u542b\u56f4\u680f\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "mainPropertyCode", "type": "String", "required": True, "description": "\u4e3b\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_main_001"},
            {"name": "auxiliaryPropertyCode", "type": "String", "required": True, "description": "\u8f85\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_aux_001"},
            {"name": "translationFields", "type": "List<String>", "required": False, "description": "\u7ed3\u679c\u5bb9\u6613\u5b57\u6bb5 (\u8f85\u6570\u636e\u8d44\u4ea7\u7684\u5b57\u6bb5)\uff0c\u975e\u5fc5\u586b", "example": "true"}
        ],
        "example": "{\n    \"mainPropertyCode\": \"mainPropertyCode\",\n    \"auxiliaryPropertyCode\": \"auxiliaryPropertyCode\",\n    \"translationFields\": [\n        \"translationFields\"\n    ]\n}",
    },
    "spatial.calculation.fence-merge": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "fence_merge_area",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5408\u5e76\u540e\u7684\u533a\u57df\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_property_001"},
            {"name": "mergeField", "type": "String", "required": True, "description": "\u5408\u5e76\u5b57\u6bb5\uff08\u9762\u8d44\u4ea7\u7684\u5b57\u6bb5\uff09", "example": "regionType"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"mergeField\": \"mergeField\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.calculation.line-intersection": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "line_intersection_point",
        "_http": "POST",
        "_summary": "\u7ebf\u76f8\u4ea4\u53d6\u4ea4\u70b9\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u7ebf\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "line_property_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\"\n}",
    },
    "spatial.calculation.h3-split-merge": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "h3SplitMergeGenerate",
        "_http": "POST",
        "_summary": "H3 \u62c6\u5408\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "customizeFencePropertyCode", "type": "String", "required": True, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e", "example": "fence_001"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": True, "description": "\u751f\u6210\u65b9\u5411\uff1abigToSmall-\u4ece\u5927\u5230\u5c0f\uff0csmallToBig-\u4ece\u5c0f\u5230\u5927\u3002\u5c42\u7ea7\u7f51\u683c\u5206\u88c2/\u5408\u5e76\u751f\u6210\u65b9\u5411\u3002\u53ef\u9009\u503c: bigToSmall=\u4ece\u5927\u5230\u5c0f; smallToBig=\u4ece\u5c0f\u5230\u5927", "example": "bigToSmall"},
            {"name": "potential", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5", "example": "potentialValue"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\uff1acity-\u57ce\u5e02\uff0cdistrict-\u533a\u53bf\uff0cprovince-\u7701\u4efd\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u914d\u7f6e\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointPropertyCode\": \"point_asset\",\n    \"customizeFencePropertyCode\": \"customizeFencePropertyCode\",\n    \"generateDirection\": \"bigToSmall\",\n    \"potential\": \"potential\",\n    \"boundaryLevel\": \"province\",\n    \"effectiveScope\": [\n        \"effectiveScope\"\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.calculation.center-point": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "center_point_compute",
        "_http": "POST",
        "_summary": "\u5185\u5916\u5fc3\u8ba1\u7b97",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u56f4\u680f\u6570\u636e", "example": "fence_001"},
            {"name": "computeType", "type": "ComputeType", "required": True, "description": "\u8ba1\u7b97\u65b9\u5f0f\u3002\u4e2d\u5fc3\u70b9\u8ba1\u7b97\u65b9\u5f0f\u3002\u53ef\u9009\u503c: 1=\u5185\u5fc3; 2=\u5916\u5fc3", "example": "1"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"computeType\": \"1\"\n}",
    },
    "spatial.calculation.fence-contain-relation": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "fence_contain_relation",
        "_http": "POST",
        "_summary": "\u5355\u56f4\u680f\u5305\u542b\u5173\u7cfb",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u9762\u6570\u636e", "example": "fence_001"},
            {"name": "field1", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5 1", "example": "city"},
            {"name": "field2", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 2", "example": "district"},
            {"name": "field3", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 3", "example": "province"},
            {"name": "field4", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 4", "example": "region"},
            {"name": "field5", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 5", "example": "zone"},
            {"name": "oneToOneFlag", "type": "Boolean", "required": True, "description": "\u5305\u542b\u7c7b\u578b\uff08true: \u5355\u56f4\u680f\uff0cfalse: \u591a\u56f4\u680f\uff09", "example": "true"},
            {"name": "isGroup", "type": "Boolean", "required": True, "description": "\u662f\u5426\u5206\u7ec4\uff08true: \u662f\uff0cfalse: \u5426\uff09", "example": "true"},
            {"name": "containRatio", "type": "String", "required": True, "description": "\u5305\u542b\u6bd4\u4f8b", "example": "100"},
            {"name": "isAll", "type": "Boolean", "required": True, "description": "\u662f\u5426\u9700\u8981\u5168\u91cf\u6570\u636e\uff08true: \u662f\uff0cfalse: \u5426\uff09", "example": "false"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"field1\": \"field1\",\n    \"field2\": \"field2\",\n    \"field3\": \"field3\",\n    \"field4\": \"field4\",\n    \"field5\": \"field5\",\n    \"oneToOneFlag\": true,\n    \"isGroup\": true,\n    \"containRatio\": \"containRatio\",\n    \"isAll\": true\n}",
    },
    "spatial.calculation.point-centroid": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "point_centroid",
        "_http": "POST",
        "_summary": "\u70b9\u8d28\u5fc3\u8ba1\u7b97",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u70b9\u6570\u636e", "example": "point_001"},
            {"name": "partitionType", "type": "PartitionType", "required": True, "description": "\u5212\u5206\u7c7b\u578b\u3002\u7a7a\u95f4\u5212\u5206\u7c7b\u578b\u3002\u53ef\u9009\u503c: hexagon=\u8702\u7a9d; square=\u65b9\u5757", "example": "hexagon"},
            {"name": "sideLength", "type": "Integer", "required": True, "description": "\u8fb9\u957f\uff08\u6700\u5c0f\u503c 100\uff0c\u6700\u5927\u503c 100000\uff09", "example": "1000"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u7edf\u8ba1", "example": "1000"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"partitionType\": \"hexagon\",\n    \"sideLength\": 100,\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "spatial.calculation.line-split-fence": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "line_split_fence",
        "_http": "POST",
        "_summary": "\u7ebf\u5206\u5272\u56f4\u680f\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "linePropertyCode", "type": "String", "required": False, "description": ""},
            {"name": "fencePropertyCode", "type": "String", "required": False, "description": ""}
        ],
        "example": "{\n    \"linePropertyCode\": \"line_asset\",\n    \"fencePropertyCode\": \"fence_asset\"\n}",
    },
    "spatial.calculation.fence-equalization": {
        "_controller": "TaskPipelineSpatialCalculationController",
        "_method": "fence_equalization",
        "_http": "POST",
        "_summary": "\u7247\u533a\u6247\u5f62\u5207\u5206\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "point", "type": "String", "required": True, "description": "\u8d77\u59cb\u7ecf\u7eac\u5ea6\u5b57\u6bb5", "example": "center_point"},
            {"name": "equalNumber", "type": "Integer", "required": True, "description": "\u7b49\u5206\u6570\u91cf", "example": "4"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"point\": \"point\",\n    \"equalNumber\": 4\n}",
    },
    "operation.filter": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "filter",
        "_http": "POST",
        "_summary": "\u7b5b\u9009\u5668\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "fields", "type": "List<Field>", "required": True, "description": "\u7b5b\u9009\u6761\u4ef6\u5217\u8868", "example": "point_001"},
            {"name": "fieldName", "type": "String (inner)", "required": True, "description": "\u5b57\u6bb5\u540d\u79f0", "example": "field4", "parent": "Field"},
            {"name": "operationType", "type": "OperationType (inner)", "required": True, "description": "\u64cd\u4f5c\u7c7b\u578b\u3002\u8fc7\u6ee4/\u7b5b\u9009\u64cd\u4f5c\u7b26\u3002\u53ef\u9009\u503c: eq=\u7b49\u4e8e; neq=\u4e0d\u7b49\u4e8e; include=\u5305\u542b; not_include=\u4e0d\u5305\u542b; gt=\u5927\u4e8e; lt=\u5c0f\u4e8e; gte=\u5927\u4e8e\u7b49\u4e8e; lte=\u5c0f\u4e8e\u7b49\u4e8e; isnull=\u4e3a\u7a7a; not_null=\u4e0d\u4e3a\u7a7a", "example": "eq", "parent": "Field"},
            {"name": "content", "type": "Object (inner)", "required": False, "description": "\u8fc7\u6ee4/\u7b5b\u9009\u64cd\u4f5c\u7b26\uff0c\u53ef\u9009\u503c: eq=\u7b49\u4e8e; neq=\u4e0d\u7b49\u4e8e; include=\u5305\u542b; not_include=\u4e0d\u5305\u542b; gt=\u5927\u4e8e; lt=\u5c0f\u4e8e; gte=\u5927\u4e8e\u7b49\u4e8e; lte=\u5c0f\u4e8e\u7b49\u4e8e; isnull=\u4e3a\u7a7a; not_null=\u4e0d\u4e3a\u7a7a", "parent": "Field"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"fields\": [\n        {\n            \"fieldName\": \"fieldName\",\n            \"operationType\": \"eq\",\n            \"content\": \"eq\"\n        }\n    ]\n}",
    },
    "operation.duplicate-mark": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "duplicate_mark",
        "_http": "POST",
        "_summary": "\u91cd\u590d\u6807\u8bb0\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "data_001"},
            {"name": "groupField1", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5 1", "example": "field1"},
            {"name": "groupField2", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 2", "example": "field2"},
            {"name": "groupField3", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 3", "example": "field3"},
            {"name": "groupField4", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 4", "example": "field4"},
            {"name": "groupField5", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 5", "example": "field5"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"groupField1\": \"name\",\n    \"groupField2\": \"city\",\n    \"groupField3\": \"province\",\n    \"groupField4\": \"district\",\n    \"groupField5\": \"groupField5\"\n}",
    },
    "operation.text-concat": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "text_concat",
        "_http": "POST",
        "_summary": "\u6587\u672c\u62fc\u63a5\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "text_001"},
            {"name": "concatFields", "type": "List<String>", "required": True, "description": "\u62fc\u63a5\u5b57\u6bb5\uff1a\u591a\u9009\uff0c\u4f8b\u5982['\u7701','\u5e02','\u533a','\u5730\u5740']", "example": "text_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"concatFields\": [\n        \"concatFields\"\n    ]\n}",
    },
    "operation.data-flow": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "data_flow",
        "_http": "POST",
        "_summary": "\u6570\u636e\u5e73\u79fb\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u9009\u62e9\u9700\u8981\u6267\u884c\u7684\u5750\u6807\u6570\u636e", "example": "point_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\"\n}",
    },
    "operation.group": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "group_data",
        "_http": "POST",
        "_summary": "\u5206\u7ec4\u7edf\u8ba1",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u6570\u636e\u5217\u8868", "example": "data_001"},
            {"name": "countType", "type": "CountType", "required": True, "description": "\u7edf\u8ba1\u7c7b\u578b\u3002\u7edf\u8ba1\u805a\u5408\u7c7b\u578b\u3002\u53ef\u9009\u503c: Max=\u6700\u5927\u503c; Min=\u6700\u5c0f\u503c; Count=\u603b\u6570; Sum=\u6c42\u548c; Avg=\u5e73\u5747\u503c", "example": "Max"},
            {"name": "filed", "type": "String", "required": True, "description": "\u805a\u5408\u5b57\u6bb5"},
            {"name": "groupFiled", "type": "List<String>", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"countType\": \"Max\",\n    \"filed\": \"fieldName\",\n    \"groupFiled\": [\n        \"groupFiled\"\n    ]\n}",
    },
    "operation.intersect": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "intersect_compute",
        "_http": "POST",
        "_summary": "\u4ea4\u53c9\u5173\u8054",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "oneDataPropertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u6570\u636e 1", "example": "data_001"},
            {"name": "twoDataPropertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u6570\u636e 2", "example": "data_002"},
            {"name": "oneMatchingField", "type": "String", "required": True, "description": "\u6570\u636e 1 \u7684\u5173\u8054\u5b57\u6bb5", "example": "id"},
            {"name": "twoMatchingField", "type": "String", "required": True, "description": "\u6570\u636e 2 \u7684\u5173\u8054\u5b57\u6bb5", "example": "id"},
            {"name": "resultField", "type": "List<String>", "required": True, "description": "\u9700\u8981\u5173\u8054\u7684\u5b57\u6bb5\uff08\u9009\u62e9\u7ed3\u679c\u62fc\u63a5\u7684\u5b57\u6bb5\uff0c\u4e0d\u9009\u62e9\u9ed8\u8ba4\u5168\u90e8\u62fc\u63a5\uff09", "example": "[\"resultField\"]"}
        ],
        "example": "{\n    \"oneDataPropertyCode\": \"oneDataPropertyCode\",\n    \"twoDataPropertyCode\": \"twoDataPropertyCode\",\n    \"oneMatchingField\": \"id\",\n    \"twoMatchingField\": \"id\",\n    \"resultField\": [\n        \"resultField\"\n    ]\n}",
    },
    "operation.ka-handling": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "ka_handling",
        "_http": "POST",
        "_summary": "KA\u8bc6\u522b\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerPropertyCode", "type": "String", "required": True, "description": "\u552e\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "customer_001"},
            {"name": "textStr", "type": "String", "required": True, "description": "\u540d\u79f0\u5b57\u6bb5", "example": "name"},
            {"name": "kaPropertyCode", "type": "String", "required": True, "description": "KA\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "ka_001"},
            {"name": "name", "type": "String", "required": True, "description": "\u5173\u952e\u8bcd\u5b57\u6bb5", "example": "keyword"},
            {"name": "tagName", "type": "String", "required": True, "description": "\u54c1\u724c\u540d\u5b57\u6bb5", "example": "brandName"},
            {"name": "sort", "type": "String", "required": False, "description": "\u6392\u5e8f\u5b57\u6bb5", "example": "sort_order"},
            {"name": "policyCode", "type": "PolicyCode", "required": True, "description": "\u8bc6\u522b\u89c4\u5219\u3002\u53ef\u9009\u503c: 20002=KA \u540d\u79f0\u63d0\u53d6 - \u957f\u8bcd; 20006=ka \u540d\u79f0\u8f6c\u62fc\u97f3 - \u957f\u8bcd; 20012=KA \u540d\u79f0\u5220\u9664 - \u957f\u8bcd; 20018=KA \u540d\u79f0\u63d0\u53d6 - \u6392\u5e8f; 20022=Ka \u540d\u79f0\u8f6c\u62fc\u97f3 - \u6392\u5e8f; 20026=ka \u540d\u79f0\u5220\u9664 - \u6392\u5e8f; 20032=\u591a\u54c1\u724c\u8bc6\u522b - \u6392\u5e8f; 20038=\u591a\u54c1\u724c\u5220\u9664 - \u6392\u5e8f - \u5206\u5272"}
        ],
        "example": "{\n    \"customerPropertyCode\": \"customer_asset\",\n    \"textStr\": \"fieldName\",\n    \"kaPropertyCode\": \"ka_asset\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"tagName\": \"tagName\",\n    \"sort\": \"sort\",\n    \"policyCode\": \"20002\"\n}",
    },
    "operation.subsection-mark": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "subsection_mark",
        "_http": "POST",
        "_summary": "\u5206\u6bb5\u6807\u8bb0\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": False, "description": ""},
            {"name": "subsectionGroupFields", "type": "List<String>", "required": True, "description": "\u5206\u6bb5\u5206\u7ec4\u5b57\u6bb5\u6570\u7ec4", "example": "[\"subsectiongroupfields\"]"},
            {"name": "param", "type": "List<SubsectionCondition>", "required": True, "description": "\u5206\u6bb5\u6761\u4ef6\u5217\u8868", "example": "[...]"},
            {"name": "subsectionFields", "type": "List<String> (inner)", "required": True, "description": "\u5206\u6bb5\u5b57\u6bb5\u6570\u7ec4", "example": "[\"subsectionfields\"]", "parent": "SubsectionCondition"},
            {"name": "subsectionType", "type": "SubsectionType (inner)", "required": True, "description": "\u5206\u6bb5\u7c7b\u578b\uff1a1-\u5360\u6bd4\uff0c2-\u6570\u503c\u3002\u5206\u6bb5\u6807\u8bb0\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u5360\u6bd4; 2=\u6570\u503c", "parent": "SubsectionCondition"},
            {"name": "operType", "type": "OperType (inner)", "required": True, "description": "\u64cd\u4f5c\u7c7b\u578b\uff1a1-\u7b49\u4e8e\uff0c2-\u4e0d\u7b49\u4e8e\uff0c3-\u5927\u4e8e\uff0c4-\u5927\u4e8e\u7b49\u4e8e\uff0c5-\u5c0f\u4e8e\uff0c6-\u5c0f\u4e8e\u7b49\u4e8e\uff0c7-\u6700\u5927\u503c\uff0c8-\u6700\u5c0f\u503c\u3002\u5206\u6bb5\u6bd4\u8f83\u64cd\u4f5c\u7b26\u3002\u53ef\u9009\u503c: 1=\u7b49\u4e8e; 2=\u4e0d\u7b49\u4e8e; 3=\u5927\u4e8e; 4=\u5927\u4e8e\u7b49\u4e8e; 5=\u5c0f\u4e8e; 6=\u5c0f\u4e8e\u7b49\u4e8e; 7=\u6700\u5927\u503c; 8=\u6700\u5c0f\u503c", "parent": "SubsectionCondition"},
            {"name": "compareValue", "type": "Integer (inner)", "required": False, "description": "\u6bd4\u8f83\u503c", "example": "100", "parent": "SubsectionCondition"},
            {"name": "groupField", "type": "String (inner)", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\uff08\u64cd\u4f5c\u7c7b\u578b\u4e3a 7 \u6216 8 \u65f6\u5fc5\u586b\uff09", "example": "groupField", "parent": "SubsectionCondition"},
            {"name": "markValue", "type": "String (inner)", "required": True, "description": "\u6807\u8bb0\u503c", "example": "high_value", "parent": "SubsectionCondition"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"subsectionGroupFields\": [\n        \"subsectionGroupFields\"\n    ],\n    \"param\": []\n}",
    },
    "operation.normalized-expr": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "normalized_expr",
        "_http": "POST",
        "_summary": "\u5f52\u4e00\u503c\u8ba1\u7b97\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u5f52\u4e00\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "normalizedExpr", "type": "String", "required": True, "description": "\u5f52\u4e00\u503c\u8ba1\u7b97\u8868\u8fbe\u5f0f", "example": "(a+b)/c"},
            {"name": "compute", "type": "List<ComputeField>", "required": True, "description": "\u8ba1\u7b97\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "(a+b)/c"},
            {"name": "computeFiled", "type": "String (inner)", "required": True, "description": "\u8ba1\u7b97\u5b57\u6bb5:\u9009\u62e9\u9700\u8981\u8ba1\u7b97\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "ComputeField"},
            {"name": "aliasName", "type": "String (inner)", "required": True, "description": "\u522b\u540d:\u88ab\u7528\u4e8e\u5199\u8868\u8fbe\u5f0f\u7684\u5b57\u6bb5 \u4f8b\u5982\uff1aa", "example": "alias", "parent": "ComputeField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"normalizedExpr\": \"normalizedExpr\",\n    \"compute\": [\n        {\n            \"computeFiled\": \"computeFiled\",\n            \"aliasName\": \"aliasName\"\n        }\n    ]\n}",
    },
    "operation.one-id": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "one_id_compute",
        "_http": "POST",
        "_summary": "ONE_ID \u5173\u8054\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "firstPropertyCode", "type": "String", "required": True, "description": "\u6570\u636e\u4e00\u8d44\u4ea7\u7f16\u7801", "example": "data1_001"},
            {"name": "oneMatchingField", "type": "String", "required": True, "description": "\u6570\u636e\u4e00\u5173\u8054\u5b57\u6bb5", "example": "id_card"},
            {"name": "secondPropertyCode", "type": "String", "required": True, "description": "\u6570\u636e\u4e8c\u8d44\u4ea7\u7f16\u7801", "example": "data2_001"},
            {"name": "twoMatchingField", "type": "String", "required": True, "description": "\u6570\u636e\u4e8c\u5173\u8054\u5b57\u6bb5", "example": "mobile"},
            {"name": "resultField", "type": "String", "required": True, "description": "\u9700\u5173\u8054\u5b57\u6bb5", "example": "name,phone"}
        ],
        "example": "{\n    \"firstPropertyCode\": \"firstPropertyCode\",\n    \"oneMatchingField\": \"id\",\n    \"secondPropertyCode\": \"secondPropertyCode\",\n    \"twoMatchingField\": \"id\",\n    \"resultField\": \"resultField\"\n}",
    },
    "operation.data-merge": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "data_merge",
        "_http": "POST",
        "_summary": "\u6570\u636e\u5408\u5e76\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "sourcePropertyCode", "type": "String", "required": False, "description": ""},
            {"name": "targetPropertyCode", "type": "String", "required": False, "description": ""},
            {"name": "targetPropertyCode2", "type": "String", "required": False, "description": ""},
            {"name": "targetPropertyCode3", "type": "String", "required": False, "description": ""},
            {"name": "targetPropertyCode4", "type": "String", "required": False, "description": ""}
        ],
        "example": "{\n    \"sourcePropertyCode\": \"source_asset\",\n    \"targetPropertyCode\": \"target_asset\",\n    \"targetPropertyCode2\": \"targetPropertyCode2\",\n    \"targetPropertyCode3\": \"targetPropertyCode3\",\n    \"targetPropertyCode4\": \"targetPropertyCode4\"\n}",
    },
    "operation.text-similarity": {
        "_controller": "TaskPipelineOperationToolController",
        "_method": "text_similarity",
        "_http": "POST",
        "_summary": "\u76f8\u4f3c\u5ea6\u8ba1\u7b97\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u76f8\u4f3c\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "data_001"},
            {"name": "sourceText", "type": "String", "required": True, "description": "\u6e90\u6587\u672c\u5b57\u6bb5", "example": "source_name"},
            {"name": "targetText", "type": "String", "required": True, "description": "\u76ee\u6807\u6587\u672c\u5b57\u6bb5", "example": "target_name"},
            {"name": "algorithm", "type": "SimilarityAlgorithm", "required": False, "description": ""}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"sourceText\": \"source_name\",\n    \"targetText\": \"target_name\",\n    \"algorithm\": \"0\"\n}",
    },
    "model.reachable-range": {
        "_controller": "TaskPipelineModelCalculationController",
        "_method": "reachable_range",
        "_http": "POST",
        "_summary": "\u53ef\u8fbe\u5708\u5206\u6790\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "directionType", "type": "DirectionType", "required": True, "description": "\u51fa\u884c\u653f\u7b56\u3002\u53ef\u8fbe\u8303\u56f4\u51fa\u884c\u65b9\u5f0f\u3002\u53ef\u9009\u503c: driving=\u9a7e\u8f66; bicycling=\u9a91\u884c; walking=\u6b65\u884c", "example": "driving"},
            {"name": "travelTime", "type": "Integer", "required": True, "description": "\u51fa\u884c\u65f6\u957f\uff0c\u5355\u4f4d\uff1a\u5206\u949f", "example": "30"}
        ],
        "example": "{\n    \"pointPropertyCode\": \"point_asset\",\n    \"directionType\": \"driving\",\n    \"travelTime\": 30\n}",
    },
    "model.scu-specify": {
        "_controller": "TaskPipelineModelCalculationController",
        "_method": "scu_specify_generate",
        "_http": "POST",
        "_summary": "SCU-\u6307\u5b9a\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointPropertyCode", "type": "String", "required": False, "description": "\u70b9\u6570\u636e", "example": "fence_001"},
            {"name": "unitType", "type": "UnitType", "required": True, "description": "SCU \u7c7b\u578b\u3002\u7a7a\u95f4\u7f51\u683c\u5355\u5143\u7c7b\u578b\u3002\u53ef\u9009\u503c: road=\u8def\u7f51; area=\u533a\u5212; hive=\u8702\u7a9d; grid=\u7f51\u683c; h3=H3; s2=S2; geoHash=GeoHash", "example": "road"},
            {"name": "areaTree", "type": "List<List<String>>", "required": True, "description": "\u7701\u5e02\u533a\u8303\u56f4"},
            {"name": "roadType", "type": "String", "required": False, "description": "\u8def\u7f51\u7c7b\u578b\uff0c\u5f53 unitType \u4e3a road \u65f6\u5fc5\u586b", "example": "district_physic_block_normal"},
            {"name": "divideType", "type": "String", "required": False, "description": "\u533a\u5212\u7c7b\u578b\uff0c\u5f53 unitType \u4e3a area \u65f6\u5fc5\u586b", "example": "city"},
            {"name": "fieldName", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5", "example": "salesAmount"},
            {"name": "radius", "type": "Integer", "required": False, "description": "\u534a\u5f84\uff08\u7c73\uff09\uff0c\u5f53 unitType \u4e3a hive \u6216 grid \u65f6\u5b58\u5728\uff0c\u9ed8\u8ba4\u503c 1000\uff0c\u6700\u5c0f\u503c 0\uff0c\u6700\u5927\u503c 5000", "example": "1000"},
            {"name": "s2Level", "type": "Integer", "required": False, "description": "s2 \u7ea7\u522b\uff0c\u5f53 unitType \u4e3a s2 \u65f6\u5b58\u5728\uff0c\u9ed8\u8ba4\u503c 1\uff0c\u6700\u5c0f\u503c 1\uff0c\u6700\u5927\u503c 15", "example": "1"},
            {"name": "h3Level", "type": "Integer", "required": False, "description": "h3 \u7ea7\u522b\uff0c\u5f53 unitType \u4e3a h3 \u65f6\u5b58\u5728\uff0c\u9ed8\u8ba4\u503c 0\uff0c\u6700\u5c0f\u503c 0\uff0c\u6700\u5927\u503c 10", "example": "0"},
            {"name": "geoHashLevel", "type": "Integer", "required": False, "description": "geoHash \u7ea7\u522b\uff0c\u5f53 unitType \u4e3a geoHash \u65f6\u5b58\u5728\uff0c\u9ed8\u8ba4\u503c 1\uff0c\u6700\u5c0f\u503c 1\uff0c\u6700\u5927\u503c 8", "example": "1"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[...]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointPropertyCode\": \"point_asset\",\n    \"unitType\": \"grid\",\n    \"areaTree\": [\n        [\n            \"310000\",\n            \"310100\"\n        ]\n    ],\n    \"roadType\": \"district_physic_block_normal\",\n    \"divideType\": \"city\",\n    \"fieldName\": \"salesAmount\",\n    \"radius\": 1000,\n    \"s2Level\": 1,\n    \"h3Level\": 0,\n    \"geoHashLevel\": 1,\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"aggregationType\": \"Sum\"\n        }\n    ]\n}",
    },
    "model.solitary-screen": {
        "_controller": "TaskPipelineModelCalculationController",
        "_method": "solitary_screen_data",
        "_http": "POST",
        "_summary": "\u5b64\u70b9\u6807\u8bb0\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u5b64\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801"},
            {"name": "fields", "type": "List<Field>", "required": True, "description": "\u6807\u8bb0\u6761\u4ef6\u5217\u8868", "example": "[...]"},
            {"name": "fieldName", "type": "String (inner)", "required": True, "description": "\u5b57\u6bb5\u540d\u79f0", "example": "field4", "parent": "Field"},
            {"name": "operationType", "type": "OperationType (inner)", "required": True, "description": "\u64cd\u4f5c\u7c7b\u578b\u3002\u8fc7\u6ee4/\u7b5b\u9009\u64cd\u4f5c\u7b26\u3002\u53ef\u9009\u503c: eq=\u7b49\u4e8e; neq=\u4e0d\u7b49\u4e8e; include=\u5305\u542b; not_include=\u4e0d\u5305\u542b; gt=\u5927\u4e8e; lt=\u5c0f\u4e8e; gte=\u5927\u4e8e\u7b49\u4e8e; lte=\u5c0f\u4e8e\u7b49\u4e8e; isnull=\u4e3a\u7a7a; not_null=\u4e0d\u4e3a\u7a7a", "example": "eq", "parent": "Field"},
            {"name": "content", "type": "Object (inner)", "required": False, "description": "\u8fc7\u6ee4/\u7b5b\u9009\u64cd\u4f5c\u7b26\uff0c\u53ef\u9009\u503c: eq=\u7b49\u4e8e; neq=\u4e0d\u7b49\u4e8e; include=\u5305\u542b; not_include=\u4e0d\u5305\u542b; gt=\u5927\u4e8e; lt=\u5c0f\u4e8e; gte=\u5927\u4e8e\u7b49\u4e8e; lte=\u5c0f\u4e8e\u7b49\u4e8e; isnull=\u4e3a\u7a7a; not_null=\u4e0d\u4e3a\u7a7a", "parent": "Field"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"fields\": [\n        {\n            \"fieldName\": \"fieldName\",\n            \"operationType\": \"eq\",\n            \"content\": \"eq\"\n        }\n    ]\n}",
    },
    "model.industry-cluster": {
        "_controller": "TaskPipelineModelCalculationController",
        "_method": "industry_cluster",
        "_http": "POST",
        "_summary": "\u884c\u4e1a\u805a\u96c6\u7fa4\u4e0e\u5206\u6790",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e", "example": "point_001"},
            {"name": "paramJson", "type": "ParamJson", "required": True, "description": "\u57fa\u7840\u53c2\u6570", "example": "{...}"},
            {"name": "fenceDistance", "type": "Double (inner)", "required": True, "description": "\u56f4\u680f\u8ddd\u79bb\uff08M\uff09", "example": "500", "parent": "ParamJson"},
            {"name": "distance", "type": "Double (inner)", "required": True, "description": "\u70b9\u8ddd\u79bb\uff08M\uff09", "example": "100", "parent": "ParamJson"},
            {"name": "buffer", "type": "Double (inner)", "required": True, "description": "\u6269\u5c55\u8ddd\u79bb\uff08M\uff09", "example": "200", "parent": "ParamJson"},
            {"name": "groupSize", "type": "Integer (inner)", "required": True, "description": "\u96c6\u7fa4\u9608\u503c\uff08\u4e2a\uff09", "example": "10", "parent": "ParamJson"},
            {"name": "ifConvex", "type": "IfConvex (inner)", "required": True, "description": "\u56f4\u680f\u7c7b\u578b\u3002\u53ef\u9009\u503c: 0=\u591a\u8fb9\u5f62; 1=\u51f8\u5305", "example": "0", "parent": "ParamJson"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5", "example": "[...]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"point_001\",\n    \"paramJson\": {\n        \"fenceDistance\": 500,\n        \"distance\": 100,\n        \"buffer\": 50,\n        \"groupSize\": 10,\n        \"ifConvex\": \"0\"\n    },\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"aggregationType\": \"Count\"\n        }\n    ]\n}",
    },
    "model.radiate-circle": {
        "_controller": "TaskPipelineModelCalculationController",
        "_method": "business_radiate_circle",
        "_http": "POST",
        "_summary": "\u5546\u4e1a\u4f53\u8f90\u5c04\u5546\u5708\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointPropertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "radius", "type": "Double", "required": True, "description": "\u8f90\u5c04\u534a\u5f84\uff08KM\uff09", "example": "5.0"},
            {"name": "unionDistance", "type": "Double", "required": True, "description": "\u5408\u5e76\u8ddd\u79bb\uff08KM\uff09", "example": "1.0"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[...]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointPropertyCode\": \"point_asset\",\n    \"fencePropertyCode\": \"fence_asset\",\n    \"radius\": 1000,\n    \"unionDistance\": 1,\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "model.belonging-area": {
        "_controller": "TaskPipelineModelCalculationController",
        "_method": "belong_area_generate",
        "_http": "POST",
        "_summary": "\u5f52\u5c5e\u533a\u57df - \u653e\u5c04\u7ebf\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "name", "type": "String", "required": True, "description": "\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5", "example": "area_name"},
            {"name": "connectType", "type": "ConnectType", "required": True, "description": "\u8fde\u7ebf\u65b9\u5f0f\u679a\u4e3e\u3002\u53ef\u9009\u503c: 4=\u653e\u5c04\u7ebf", "example": "4"}
        ],
        "example": "{\n    \"propertyCode\": \"point_001\",\n    \"name\": \"area_name\",\n    \"connectType\": \"4\"\n}",
    },
    "resource.logistics-planning-v1": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "logistics_planning_v1",
        "_http": "POST",
        "_summary": "\u7269\u6d41\u7ebf\u8def\u89c4\u5212",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u4fe1\u606f", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "orderData", "type": "OrderData", "required": True, "description": "\u8ba2\u5355\u4fe1\u606f"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8ba2\u5355\u4fe1\u606f", "example": "order_001", "parent": "OrderData"},
            {"name": "depotCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "depot_001", "parent": "OrderData"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u7f16\u7801", "example": "cust_001", "parent": "OrderData"},
            {"name": "demand", "type": "String (inner)", "required": True, "description": "\u91cd\u91cf", "example": "100", "parent": "OrderData"},
            {"name": "volume", "type": "String (inner)", "required": True, "description": "\u4f53\u79ef", "example": "volume", "parent": "OrderData"},
            {"name": "box", "type": "String (inner)", "required": True, "description": "\u6807\u7bb1", "example": "box", "parent": "OrderData"},
            {"name": "depotData", "type": "DepotData", "required": True, "description": "\u4ed3\u5e93\u4fe1\u606f"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u4fe1\u606f", "example": "depot_001", "parent": "DepotData"},
            {"name": "readyTime", "type": "String (inner)", "required": True, "description": "\u5f00\u95e8\u65f6\u95f4", "example": "06:00:00", "parent": "DepotData"},
            {"name": "dueTime", "type": "String (inner)", "required": True, "description": "\u5173\u95e8\u65f6\u95f4", "example": "20:00:00", "parent": "DepotData"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "code_001", "parent": "DepotData"},
            {"name": "travelTimeFactor", "type": "String (inner)", "required": True, "description": "\u884c\u9a76\u65f6\u95f4\u7cfb\u6570", "example": "2024-01-01", "parent": "DepotData"},
            {"name": "loadingTimeFactor", "type": "String (inner)", "required": False, "description": "\u51c6\u5907\u65f6\u95f4\u7cfb\u6570", "example": "2024-01-01", "parent": "DepotData"},
            {"name": "serviceTimeFactor", "type": "String (inner)", "required": False, "description": "\u670d\u52a1\u65f6\u95f4\u7cfb\u6570", "example": "2024-01-01", "parent": "DepotData"},
            {"name": "startTime", "type": "String (inner)", "required": True, "description": "\u51fa\u8f66\u65f6\u95f4", "example": "07:00:00", "parent": "DepotData"},
            {"name": "loadingTime", "type": "String (inner)", "required": True, "description": "\u88c5\u8f66\u65f6\u95f4", "example": "2024-01-01", "parent": "DepotData"},
            {"name": "costLabourPerDay", "type": "String (inner)", "required": True, "description": "\u56fa\u5b9a\u4eba\u5de5\u6210\u672c", "example": "costlabourperday", "parent": "DepotData"},
            {"name": "costPerBox", "type": "String (inner)", "required": True, "description": "\u6bcf\u6807\u7bb1\u4eba\u5de5\u6210\u672c", "example": "costperbox", "parent": "DepotData"},
            {"name": "maxCustomer", "type": "String (inner)", "required": True, "description": "\u6bcf\u8def\u7ebf\u6700\u5927\u5ba2\u6237\u6570", "example": "maxcustomer", "parent": "DepotData"},
            {"name": "maxTime", "type": "String (inner)", "required": False, "description": "\u6bcf\u8def\u7ebf\u6700\u5927\u65f6\u95f4", "example": "480", "parent": "DepotData"},
            {"name": "maxDistanceCustomer", "type": "String (inner)", "required": False, "description": "\u5ba2\u6237\u95f4\u6700\u5927\u8ddd\u79bb", "example": "maxdistancecustomer", "parent": "DepotData"},
            {"name": "capacityConstraint", "type": "String (inner)", "required": False, "description": "\u8fd0\u529b\u9650\u5236", "example": "1000", "parent": "DepotData"},
            {"name": "multipleTrip", "type": "String (inner)", "required": True, "description": "\u662f\u5426\u591a\u6b21\u5f80\u8fd4", "example": "multipletrip", "parent": "DepotData"},
            {"name": "bigOrder", "type": "String (inner)", "required": True, "description": "\u662f\u5426\u4f18\u5148\u5927\u8ba2\u5355", "example": "bigorder", "parent": "DepotData"},
            {"name": "mulArea", "type": "String (inner)", "required": False, "description": "\u662f\u5426\u8003\u8651\u533a\u57df", "example": "mularea", "parent": "DepotData"},
            {"name": "smallVehicle", "type": "String (inner)", "required": False, "description": "\u662f\u5426\u4f18\u5148\u4f7f\u7528\u5c0f\u8f66", "example": "smallvehicle", "parent": "DepotData"},
            {"name": "capacityFactor", "type": "String (inner)", "required": False, "description": "\u8fd0\u529b\u7cfb\u6570", "example": "capacityfactor", "parent": "DepotData"},
            {"name": "vehicleData", "type": "VehicleData", "required": True, "description": "\u8f66\u8f86\u4fe1\u606f"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8f66\u8f86\u4fe1\u606f", "example": "vehicle_001", "parent": "VehicleData"},
            {"name": "depotCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "depot_001", "parent": "VehicleData"},
            {"name": "carNumbers", "type": "String (inner)", "required": True, "description": "\u8f66\u724c\u53f7", "example": "\u4eacA12345", "parent": "VehicleData"},
            {"name": "box", "type": "String (inner)", "required": True, "description": "\u6807\u7bb1", "example": "box", "parent": "VehicleData"},
            {"name": "capacity", "type": "String (inner)", "required": True, "description": "\u8fd0\u529b", "example": "500", "parent": "VehicleData"},
            {"name": "volume", "type": "String (inner)", "required": True, "description": "\u4f53\u79ef", "example": "100", "parent": "VehicleData"},
            {"name": "cost", "type": "String (inner)", "required": True, "description": "\u56fa\u5b9a\u6210\u672c", "example": "500", "parent": "VehicleData"},
            {"name": "costPerKm", "type": "String (inner)", "required": True, "description": "\u6bcf\u516c\u91cc\u6210\u672c", "example": "costperkm", "parent": "VehicleData"},
            {"name": "canGoAreaCode", "type": "String (inner)", "required": True, "description": "\u53ef\u8fbe\u533a\u57df", "example": "area_001", "parent": "VehicleData"},
            {"name": "cantGoAreaCode", "type": "String (inner)", "required": False, "description": "\u4e0d\u53ef\u8fbe\u533a\u57df", "example": "area_002", "parent": "VehicleData"},
            {"name": "isBreak", "type": "String", "required": False, "description": "\u662f\u5426\u5141\u8bb8\u7834\u7ea6\u675f\u3002\u53ef\u9009\u503c: true=\u5141\u8bb8\u7a81\u7834\u7ea6\u675f; false=\u4e0d\u5141\u8bb8\u7a81\u7834\u7ea6\u675f"}
        ],
        "example": "{\n    \"customerData\": {\n        \"propertyCode\": \"asset_001\",\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"orderData\": {\n        \"propertyCode\": \"asset_001\",\n        \"depotCode\": \"depot_001\",\n        \"customerCode\": \"customer_001\",\n        \"demand\": \"demand\",\n        \"volume\": \"volume\",\n        \"box\": \"box\"\n    },\n    \"depotData\": {\n        \"propertyCode\": \"asset_001\",\n        \"readyTime\": \"readyTime\",\n        \"dueTime\": \"dueTime\",\n        \"code\": \"code\",\n        \"travelTimeFactor\": \"travelTimeFactor\",\n        \"loadingTimeFactor\": \"loadingTimeFactor\",\n        \"serviceTimeFactor\": \"serviceTimeFactor\",\n        \"startTime\": \"startTime\",\n        \"loadingTime\": \"loadingTime\",\n        \"costLabourPerDay\": \"costLabourPerDay\",\n        \"costPerBox\": \"costPerBox\",\n        \"maxCustomer\": \"maxCustomer\",\n        \"maxTime\": \"maxTime\",\n        \"maxDistanceCustomer\": \"maxDistanceCustomer\",\n        \"capacityConstraint\": \"capacityConstraint\",\n        \"multipleTrip\": \"multipleTrip\",\n        \"bigOrder\": \"bigOrder\",\n        \"mulArea\": \"mulArea\",\n        \"smallVehicle\": \"smallVehicle\",\n        \"capacityFactor\": \"capacityFactor\"\n    },\n    \"vehicleData\": {\n        \"propertyCode\": \"asset_001\",\n        \"depotCode\": \"depot_001\",\n        \"carNumbers\": \"carNumbers\",\n        \"box\": \"box\",\n        \"capacity\": \"capacity\",\n        \"volume\": \"volume\",\n        \"cost\": \"cost\",\n        \"costPerKm\": \"costPerKm\",\n        \"canGoAreaCode\": \"canGoAreaCode\",\n        \"cantGoAreaCode\": \"cantGoAreaCode\"\n    },\n    \"isBreak\": \"true\"\n}",
    },
    "resource.sale-group-planning": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "sale_group_planning",
        "_http": "POST",
        "_summary": "\u9500\u552e\u5206\u7ec4\u89c4\u5212",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "baseResource", "type": "BaseResource", "required": True, "description": "\u9500\u552e\u6570\u636e", "example": "{\"propertyCode\":\"base_001\",\"skills\":\"skill_A\",\"code\":\"base_code\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "sales_001", "parent": "BaseResource"},
            {"name": "skills", "type": "String (inner)", "required": True, "description": "\u6240\u9700\u6280\u80fd", "example": "skill_A", "parent": "BaseResource"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u9500\u552e\u7f16\u7801", "example": "S001", "parent": "BaseResource"},
            {"name": "outletsList", "type": "OutletsList", "required": True, "description": "\u95e8\u5e97\u6570\u636e"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "outlets_001", "parent": "OutletsList"},
            {"name": "potential", "type": "String (inner)", "required": True, "description": "\u6f5c\u529b", "example": "high", "parent": "OutletsList"},
            {"name": "serviceTime", "type": "String (inner)", "required": True, "description": "\u670d\u52a1\u65f6\u957f", "example": "2024-01-01", "parent": "OutletsList"},
            {"name": "priority", "type": "String (inner)", "required": True, "description": "\u62dc\u8bbf\u4f18\u5148\u7ea7", "example": "priority", "parent": "OutletsList"},
            {"name": "visitFrequency", "type": "Integer (inner)", "required": True, "description": "\u62dc\u8bbf\u9891\u6b21", "example": "3", "parent": "OutletsList"},
            {"name": "needSkills", "type": "String (inner)", "required": True, "description": "\u6240\u9700\u6280\u80fd", "example": "skill_A", "parent": "OutletsList"},
            {"name": "resourceCode", "type": "String (inner)", "required": False, "description": "\u6240\u5c5e\u9500\u552e", "example": "S001", "parent": "OutletsList"},
            {"name": "taskSettingVO", "type": "TaskSettingVO", "required": True, "description": "\u4efb\u52a1\u914d\u7f6e\u53c2\u6570"},
            {"name": "planTerritory", "type": "PlanTerritory", "required": True, "description": "\u89c4\u5212\u533a\u57df\u53c2\u6570"},
            {"name": "planWeeks", "type": "Integer (inner)", "required": True, "description": "\u89c4\u5212\u5468\u6570", "example": "4", "parent": "PlanTerritory"},
            {"name": "saturation", "type": "Double (inner)", "required": True, "description": "\u9971\u548c\u5ea6", "example": "0.8", "parent": "PlanTerritory"},
            {"name": "workdayTime", "type": "Double (inner)", "required": True, "description": "\u6bcf\u5929\u5de5\u4f5c\u65f6\u957f", "example": "8.0", "parent": "PlanTerritory"},
            {"name": "weekWorkdays", "type": "Integer (inner)", "required": True, "description": "\u6bcf\u5468\u5de5\u4f5c\u5929\u6570", "example": "5", "parent": "PlanTerritory"},
            {"name": "maxOutletsPerTour", "type": "Integer (inner)", "required": True, "description": "\u6700\u5927\u8bbf\u95ee\u95e8\u5e97\u6570", "example": "20", "parent": "PlanTerritory"},
            {"name": "maximumDistance", "type": "Double (inner)", "required": True, "description": "\u4e24\u70b9\u4e4b\u95f4\u6700\u5927\u8ddd\u79bb", "example": "50.0", "parent": "PlanTerritory"},
            {"name": "ifRelationActive", "type": "Boolean (inner)", "required": True, "description": "\u5df2\u6709\u95e8\u5e97\u5173\u7cfb\u662f\u5426\u751f\u6548", "example": "true", "parent": "PlanTerritory"}
        ],
        "example": "{\n    \"baseResource\": {\n        \"propertyCode\": \"asset_001\",\n        \"skills\": \"skill_A\",\n        \"code\": \"code\"\n    },\n    \"outletsList\": {\n        \"propertyCode\": \"asset_001\",\n        \"potential\": \"potential\",\n        \"serviceTime\": \"serviceTime\",\n        \"priority\": \"priority\",\n        \"visitFrequency\": 3,\n        \"needSkills\": \"needSkills\",\n        \"resourceCode\": \"resourceCode\"\n    },\n    \"taskSettingVO\": {},\n    \"planTerritory\": {\n        \"planWeeks\": 4,\n        \"saturation\": 1,\n        \"workdayTime\": 1,\n        \"weekWorkdays\": 5,\n        \"maxOutletsPerTour\": 20,\n        \"maximumDistance\": 1,\n        \"ifRelationActive\": true\n    }\n}",
    },
    "resource.sale-visit-planning": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "sale_visit_planning",
        "_http": "POST",
        "_summary": "\u9500\u552e\u62dc\u8bbf\u89c4\u5212",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "baseResource", "type": "BaseResource", "required": True, "description": "\u70b9\u6570\u636e\uff08\u9500\u552e\u8d44\u6e90\uff09", "example": "{\"propertyCode\":\"base_001\",\"skills\":\"skill_A\",\"code\":\"base_code\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "sales_001", "parent": "BaseResource"},
            {"name": "skills", "type": "String (inner)", "required": True, "description": "\u6240\u9700\u6280\u80fd", "example": "skill_A", "parent": "BaseResource"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u9500\u552e\u7f16\u7801", "example": "S001", "parent": "BaseResource"},
            {"name": "outletsList", "type": "OutletsList", "required": True, "description": "\u95e8\u5e97\u4fe1\u606f"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "outlets_001", "parent": "OutletsList"},
            {"name": "potential", "type": "String (inner)", "required": True, "description": "\u6f5c\u529b", "example": "high", "parent": "OutletsList"},
            {"name": "serviceTime", "type": "String (inner)", "required": True, "description": "\u670d\u52a1\u65f6\u957f", "example": "2024-01-01", "parent": "OutletsList"},
            {"name": "priority", "type": "String (inner)", "required": True, "description": "\u62dc\u8bbf\u4f18\u5148\u7ea7", "example": "priority", "parent": "OutletsList"},
            {"name": "visitFrequency", "type": "Integer (inner)", "required": True, "description": "\u62dc\u8bbf\u9891\u6b21", "example": "3", "parent": "OutletsList"},
            {"name": "needSkills", "type": "String (inner)", "required": True, "description": "\u6240\u9700\u6280\u80fd", "example": "skill_A", "parent": "OutletsList"},
            {"name": "resourceCode", "type": "String (inner)", "required": False, "description": "\u6240\u5c5e\u9500\u552e", "example": "S001", "parent": "OutletsList"},
            {"name": "taskSetting", "type": "TaskSetting", "required": True, "description": "\u4efb\u52a1\u914d\u7f6e\u53c2\u6570"},
            {"name": "planVisitTourSetting", "type": "PlanVisitTourSetting", "required": True, "description": "\u5de1\u9632\u8bbe\u7f6e\u53c2\u6570"},
            {"name": "startDate", "type": "String (inner)", "required": True, "description": "\u5f00\u59cb\u65f6\u95f4", "example": "2026-04-01", "parent": "PlanVisitTourSetting"},
            {"name": "planWeeks", "type": "Integer (inner)", "required": True, "description": "\u89c4\u5212\u5468\u6570", "example": "4", "parent": "PlanVisitTourSetting"},
            {"name": "weekWorkdays", "type": "Integer (inner)", "required": True, "description": "\u6bcf\u5468\u5de5\u4f5c\u5929\u6570", "example": "5", "parent": "PlanVisitTourSetting"},
            {"name": "workdayTime", "type": "Double (inner)", "required": True, "description": "\u6bcf\u5929\u5de5\u4f5c\u65f6\u957f", "example": "8.0", "parent": "PlanVisitTourSetting"}
        ],
        "example": "{\n    \"baseResource\": {\n        \"propertyCode\": \"asset_001\",\n        \"skills\": \"skill_A\",\n        \"code\": \"code\"\n    },\n    \"outletsList\": {\n        \"propertyCode\": \"asset_001\",\n        \"potential\": \"potential\",\n        \"serviceTime\": \"serviceTime\",\n        \"priority\": \"priority\",\n        \"visitFrequency\": 3,\n        \"needSkills\": \"needSkills\",\n        \"resourceCode\": \"resourceCode\"\n    },\n    \"taskSetting\": {},\n    \"planVisitTourSetting\": {\n        \"startDate\": \"startDate\",\n        \"planWeeks\": 4,\n        \"weekWorkdays\": 5,\n        \"workdayTime\": 1\n    }\n}",
    },
    "resource.logistics-planning": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "logistics_planning",
        "_http": "POST",
        "_summary": "\u7269\u6d41-\u5355\u7a0b\u89c4\u5212",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerList", "type": "CustomerList", "required": True, "description": "\u5ba2\u6237\u6570\u636e", "example": "{\"propertyCode\":\"customer_001\",\"customerCode\":\"C001\",\"customerName\":\"\u6d4b\u8bd5\u5ba2\u6237\",\"areaCode\":\"area_001\",\"depotCode\":\"depot_001\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerList"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u7f16\u7801", "example": "cust_001", "parent": "CustomerList"},
            {"name": "customerName", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u540d\u79f0", "example": "XX\u5ba2\u6237", "parent": "CustomerList"},
            {"name": "areaCode", "type": "String (inner)", "required": True, "description": "\u56f4\u680f\u7f16\u7801", "example": "fence_001", "parent": "CustomerList"},
            {"name": "depotCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "depot_001", "parent": "CustomerList"},
            {"name": "readyTime", "type": "String (inner)", "required": True, "description": "\u8d77\u59cb\u65f6\u95f4", "example": "08:00:00", "parent": "CustomerList"},
            {"name": "dueTime", "type": "String (inner)", "required": True, "description": "\u622a\u6b62\u65f6\u95f4", "example": "18:00:00", "parent": "CustomerList"},
            {"name": "orderList", "type": "OrderList", "required": True, "description": "\u8ba2\u5355\u6570\u636e", "example": "{\"propertyCode\":\"order_001\",\"orderCode\":\"order_id\",\"skuNum\":10,\"boxNum\":50}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "order_001", "parent": "OrderList"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u7f16\u7801", "example": "cust_001", "parent": "OrderList"},
            {"name": "orderNo", "type": "String (inner)", "required": True, "description": "\u8ba2\u5355\u7f16\u53f7", "example": "ORD20260001", "parent": "OrderList"},
            {"name": "skuNum", "type": "Integer (inner)", "required": True, "description": "\u8ba2\u5355\u6570", "example": "10", "parent": "OrderList"},
            {"name": "boxNum", "type": "Integer (inner)", "required": True, "description": "\u8fd0\u9001\u91cf", "example": "50", "parent": "OrderList"},
            {"name": "vehicleType", "type": "String (inner)", "required": True, "description": "\u8f66\u578b", "example": "small", "parent": "OrderList"},
            {"name": "firstOrder", "type": "Boolean (inner)", "required": True, "description": "\u662f\u5426\u9996\u53d1", "example": "false", "parent": "OrderList"},
            {"name": "depotList", "type": "DepotList", "required": True, "description": "\u4ed3\u5e93\u6570\u636e", "example": "[{\"code\":\"depot_001\",\"name\":\"\u6d4b\u8bd5\u4ed3\u5e93\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "depot_001", "parent": "DepotList"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "D001", "parent": "DepotList"},
            {"name": "readyTime", "type": "String (inner)", "required": True, "description": "\u5f00\u95e8\u65f6\u95f4", "example": "06:00:00", "parent": "DepotList"},
            {"name": "dueTime", "type": "String (inner)", "required": True, "description": "\u5173\u95e8\u65f6\u95f4", "example": "20:00:00", "parent": "DepotList"},
            {"name": "baseTime", "type": "Double (inner)", "required": True, "description": "\u57fa\u7840\u65f6\u95f4", "example": "30", "parent": "DepotList"},
            {"name": "unloadTime", "type": "Double (inner)", "required": True, "description": "\u5378\u8d27\u65f6\u95f4", "example": "15.5", "parent": "DepotList"},
            {"name": "areaVehicle", "type": "AreaVehicle", "required": True, "description": "\u533a\u57df\u6570\u636e"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801 (\u9762\u6570\u636e)", "example": "fence_001", "parent": "AreaVehicle"},
            {"name": "areaCode", "type": "String (inner)", "required": True, "description": "\u533a\u57df\u7f16\u7801", "example": "area_001", "parent": "AreaVehicle"},
            {"name": "cantGoAreaCode", "type": "String (inner)", "required": False, "description": "\u4e0d\u53ef\u8fbe\u8f66\u578b", "example": "large", "parent": "AreaVehicle"},
            {"name": "isBreak", "type": "IsBreak", "required": True, "description": "\u662f\u5426\u53ef\u7a81\u7834\u3002\u662f\u5426\u5141\u8bb8\u7834\u7ea6\u675f\u3002\u53ef\u9009\u503c: true=\u5141\u8bb8\u7a81\u7834\u7ea6\u675f; false=\u4e0d\u5141\u8bb8\u7a81\u7834\u7ea6\u675f", "example": "false"},
            {"name": "vehicleList", "type": "List<VehicleList>", "required": True, "description": "\u8f66\u8f86\u5217\u8868", "example": "[{\"vehicleCode\":\"\u4eacA00001\",\"vehicleName\":\"\u6d4b\u8bd5\u8f66\u8f86\",\"volume\":50,\"box\":10}]"},
            {"name": "vehicleType", "type": "String (inner)", "required": True, "description": "\u8f66\u578b", "example": "small", "parent": "VehicleList"},
            {"name": "depotCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "depot_001", "parent": "VehicleList"},
            {"name": "number", "type": "Integer (inner)", "required": True, "description": "\u6570\u91cf", "example": "5", "parent": "VehicleList"},
            {"name": "box", "type": "Integer (inner)", "required": True, "description": "\u8f7d\u88c5\u91cf", "example": "100", "parent": "VehicleList"},
            {"name": "cost", "type": "Double (inner)", "required": True, "description": "\u56fa\u5b9a\u6210\u672c", "example": "500.0", "parent": "VehicleList"},
            {"name": "costPerKm", "type": "Double (inner)", "required": True, "description": "\u6bcf\u516c\u91cc\u6210\u672c", "example": "5.0", "parent": "VehicleList"},
            {"name": "costPerMinutes", "type": "Double (inner)", "required": True, "description": "\u6bcf\u5206\u949f\u6210\u672c", "example": "0.5", "parent": "VehicleList"}
        ],
        "example": "{\n    \"customerList\": {\n        \"propertyCode\": \"asset_001\",\n        \"customerCode\": \"customer_001\",\n        \"customerName\": \"\u5ba2\u6237\u540d\u79f0\",\n        \"areaCode\": \"area_001\",\n        \"depotCode\": \"depot_001\",\n        \"readyTime\": \"readyTime\",\n        \"dueTime\": \"dueTime\"\n    },\n    \"orderList\": {\n        \"propertyCode\": \"asset_001\",\n        \"customerCode\": \"customer_001\",\n        \"orderNo\": \"orderNo\",\n        \"skuNum\": 10,\n        \"boxNum\": 50,\n        \"vehicleType\": \"\u5c0f\u578b\u8d27\u8f66\",\n        \"firstOrder\": true\n    },\n    \"depotList\": {\n        \"propertyCode\": \"asset_001\",\n        \"code\": \"code\",\n        \"readyTime\": \"readyTime\",\n        \"dueTime\": \"dueTime\",\n        \"baseTime\": 30,\n        \"unloadTime\": 1\n    },\n    \"areaVehicle\": {\n        \"propertyCode\": \"asset_001\",\n        \"areaCode\": \"area_001\",\n        \"cantGoAreaCode\": \"cantGoAreaCode\"\n    },\n    \"isBreak\": \"true\",\n    \"vehicleList\": [\n        {\n            \"vehicleType\": \"\u5c0f\u578b\u8d27\u8f66\",\n            \"depotCode\": \"depot_001\",\n            \"number\": 5,\n            \"box\": 10,\n            \"cost\": 1,\n            \"costPerKm\": 5,\n            \"costPerMinutes\": 1\n        }\n    ]\n}",
    },
    "resource.logistics-total-planning": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "logistics_total_planning",
        "_http": "POST",
        "_summary": "\u7269\u6d41-\u603b\u7a0b\u89c4\u5212",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerList", "type": "CustomerList", "required": True, "description": "\u5ba2\u6237\u6570\u636e", "example": "{\"propertyCode\":\"customer_001\",\"customerCode\":\"C001\",\"customerName\":\"\u6d4b\u8bd5\u5ba2\u6237\",\"areaCode\":\"area_001\",\"depotCode\":\"depot_001\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerList"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u7f16\u7801", "example": "cust_001", "parent": "CustomerList"},
            {"name": "customerName", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u540d\u79f0", "example": "XX\u5ba2\u6237", "parent": "CustomerList"},
            {"name": "areaCode", "type": "String (inner)", "required": True, "description": "\u56f4\u680f\u7f16\u7801", "example": "fence_001", "parent": "CustomerList"},
            {"name": "depotCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "depot_001", "parent": "CustomerList"},
            {"name": "readyTime", "type": "String (inner)", "required": True, "description": "\u8d77\u59cb\u65f6\u95f4", "example": "08:00:00", "parent": "CustomerList"},
            {"name": "dueTime", "type": "String (inner)", "required": True, "description": "\u622a\u6b62\u65f6\u95f4", "example": "18:00:00", "parent": "CustomerList"},
            {"name": "orderList", "type": "OrderList", "required": True, "description": "\u8ba2\u5355\u6570\u636e", "example": "{\"propertyCode\":\"order_001\",\"orderCode\":\"order_id\",\"skuNum\":10,\"boxNum\":50}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "order_001", "parent": "OrderList"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u7f16\u7801", "example": "cust_001", "parent": "OrderList"},
            {"name": "orderNo", "type": "String (inner)", "required": True, "description": "\u8ba2\u5355\u7f16\u53f7", "example": "ORD20260001", "parent": "OrderList"},
            {"name": "skuNum", "type": "Integer (inner)", "required": True, "description": "\u8ba2\u5355\u6570", "example": "10", "parent": "OrderList"},
            {"name": "boxNum", "type": "Integer (inner)", "required": True, "description": "\u8fd0\u9001\u91cf", "example": "50", "parent": "OrderList"},
            {"name": "vehicleType", "type": "String (inner)", "required": True, "description": "\u8f66\u578b", "example": "small", "parent": "OrderList"},
            {"name": "firstOrder", "type": "Boolean (inner)", "required": True, "description": "\u662f\u5426\u9996\u53d1", "example": "false", "parent": "OrderList"},
            {"name": "depotList", "type": "DepotList", "required": True, "description": "\u4ed3\u5e93\u6570\u636e", "example": "[{\"code\":\"depot_001\",\"name\":\"\u6d4b\u8bd5\u4ed3\u5e93\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "depot_001", "parent": "DepotList"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "D001", "parent": "DepotList"},
            {"name": "readyTime", "type": "String (inner)", "required": True, "description": "\u5f00\u95e8\u65f6\u95f4", "example": "06:00:00", "parent": "DepotList"},
            {"name": "dueTime", "type": "String (inner)", "required": True, "description": "\u5173\u95e8\u65f6\u95f4", "example": "20:00:00", "parent": "DepotList"},
            {"name": "baseTime", "type": "Double (inner)", "required": True, "description": "\u57fa\u7840\u65f6\u95f4", "example": "30", "parent": "DepotList"},
            {"name": "unloadTime", "type": "Double (inner)", "required": True, "description": "\u5378\u8d27\u65f6\u95f4", "example": "15.5", "parent": "DepotList"},
            {"name": "areaVehicle", "type": "AreaVehicle", "required": True, "description": "\u533a\u57df\u6570\u636e"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801 (\u9762\u6570\u636e)", "example": "fence_001", "parent": "AreaVehicle"},
            {"name": "areaCode", "type": "String (inner)", "required": True, "description": "\u533a\u57df\u7f16\u7801", "example": "area_001", "parent": "AreaVehicle"},
            {"name": "cantGoAreaCode", "type": "String (inner)", "required": False, "description": "\u4e0d\u53ef\u8fbe\u8f66\u578b", "example": "large", "parent": "AreaVehicle"},
            {"name": "isBreak", "type": "IsBreak", "required": True, "description": "\u662f\u5426\u53ef\u7a81\u7834\u3002\u662f\u5426\u5141\u8bb8\u7834\u7ea6\u675f\u3002\u53ef\u9009\u503c: true=\u5141\u8bb8\u7a81\u7834\u7ea6\u675f; false=\u4e0d\u5141\u8bb8\u7a81\u7834\u7ea6\u675f", "example": "false"},
            {"name": "vehicleList", "type": "List<VehicleList>", "required": True, "description": "\u8f66\u8f86\u5217\u8868", "example": "[{\"vehicleCode\":\"\u4eacA00001\",\"vehicleName\":\"\u6d4b\u8bd5\u8f66\u8f86\",\"volume\":50,\"box\":10}]"},
            {"name": "vehicleType", "type": "String (inner)", "required": True, "description": "\u8f66\u578b", "example": "small", "parent": "VehicleList"},
            {"name": "depotCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "depot_001", "parent": "VehicleList"},
            {"name": "number", "type": "Integer (inner)", "required": True, "description": "\u6570\u91cf", "example": "5", "parent": "VehicleList"},
            {"name": "box", "type": "Integer (inner)", "required": True, "description": "\u8f7d\u88c5\u91cf", "example": "100", "parent": "VehicleList"},
            {"name": "cost", "type": "Double (inner)", "required": True, "description": "\u56fa\u5b9a\u6210\u672c", "example": "500.0", "parent": "VehicleList"},
            {"name": "costPerKm", "type": "Double (inner)", "required": True, "description": "\u6bcf\u516c\u91cc\u6210\u672c", "example": "5.0", "parent": "VehicleList"},
            {"name": "costPerMinutes", "type": "Double (inner)", "required": True, "description": "\u6bcf\u5206\u949f\u6210\u672c", "example": "0.5", "parent": "VehicleList"}
        ],
        "example": "{\n    \"customerList\": {\n        \"propertyCode\": \"asset_001\",\n        \"customerCode\": \"customer_001\",\n        \"customerName\": \"\u5ba2\u6237\u540d\u79f0\",\n        \"areaCode\": \"area_001\",\n        \"depotCode\": \"depot_001\",\n        \"readyTime\": \"readyTime\",\n        \"dueTime\": \"dueTime\"\n    },\n    \"orderList\": {\n        \"propertyCode\": \"asset_001\",\n        \"customerCode\": \"customer_001\",\n        \"orderNo\": \"orderNo\",\n        \"skuNum\": 10,\n        \"boxNum\": 50,\n        \"vehicleType\": \"\u5c0f\u578b\u8d27\u8f66\",\n        \"firstOrder\": true\n    },\n    \"depotList\": {\n        \"propertyCode\": \"asset_001\",\n        \"code\": \"code\",\n        \"readyTime\": \"readyTime\",\n        \"dueTime\": \"dueTime\",\n        \"baseTime\": 30,\n        \"unloadTime\": 1\n    },\n    \"areaVehicle\": {\n        \"propertyCode\": \"asset_001\",\n        \"areaCode\": \"area_001\",\n        \"cantGoAreaCode\": \"cantGoAreaCode\"\n    },\n    \"isBreak\": \"true\",\n    \"vehicleList\": [\n        {\n            \"vehicleType\": \"\u5c0f\u578b\u8d27\u8f66\",\n            \"depotCode\": \"depot_001\",\n            \"number\": 5,\n            \"box\": 10,\n            \"cost\": 1,\n            \"costPerKm\": 5,\n            \"costPerMinutes\": 1\n        }\n    ]\n}",
    },
    "resource.auto-area-planning": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "auto_area_planning",
        "_http": "POST",
        "_summary": "\u7269\u6d41-\u914d\u9001\u533a\u57df",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerList", "type": "CustomerList", "required": True, "description": "\u5ba2\u6237\u6570\u636e", "example": "{\"propertyCode\":\"customer_001\",\"customerCode\":\"C001\",\"customerName\":\"\u6d4b\u8bd5\u5ba2\u6237\",\"areaCode\":\"area_001\",\"depotCode\":\"depot_001\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerList"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u7f16\u7801", "example": "cust_001", "parent": "CustomerList"},
            {"name": "customerName", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u540d\u79f0", "example": "XX\u5ba2\u6237", "parent": "CustomerList"},
            {"name": "areaCode", "type": "String (inner)", "required": True, "description": "\u56f4\u680f\u7f16\u7801", "example": "fence_001", "parent": "CustomerList"},
            {"name": "depotCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "depot_001", "parent": "CustomerList"},
            {"name": "readyTime", "type": "String (inner)", "required": True, "description": "\u8d77\u59cb\u65f6\u95f4", "example": "08:00:00", "parent": "CustomerList"},
            {"name": "dueTime", "type": "String (inner)", "required": True, "description": "\u622a\u6b62\u65f6\u95f4", "example": "18:00:00", "parent": "CustomerList"},
            {"name": "orderList", "type": "OrderList", "required": True, "description": "\u8ba2\u5355\u6570\u636e", "example": "{\"propertyCode\":\"order_001\",\"orderCode\":\"order_id\",\"skuNum\":10,\"boxNum\":50}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "order_001", "parent": "OrderList"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u6237\u7f16\u7801", "example": "cust_001", "parent": "OrderList"},
            {"name": "orderNo", "type": "String (inner)", "required": True, "description": "\u8ba2\u5355\u7f16\u53f7", "example": "ORD20260001", "parent": "OrderList"},
            {"name": "skuNum", "type": "Integer (inner)", "required": True, "description": "\u8ba2\u5355\u6570", "example": "10", "parent": "OrderList"},
            {"name": "boxNum", "type": "Integer (inner)", "required": True, "description": "\u8fd0\u9001\u91cf", "example": "50", "parent": "OrderList"},
            {"name": "vehicleType", "type": "String (inner)", "required": True, "description": "\u8f66\u578b", "example": "small", "parent": "OrderList"},
            {"name": "firstOrder", "type": "Boolean (inner)", "required": True, "description": "\u662f\u5426\u9996\u53d1", "example": "false", "parent": "OrderList"},
            {"name": "depotList", "type": "DepotList", "required": True, "description": "\u4ed3\u5e93\u6570\u636e", "example": "[{\"code\":\"depot_001\",\"name\":\"\u6d4b\u8bd5\u4ed3\u5e93\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "depot_001", "parent": "DepotList"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "D001", "parent": "DepotList"},
            {"name": "readyTime", "type": "String (inner)", "required": True, "description": "\u5f00\u95e8\u65f6\u95f4", "example": "06:00:00", "parent": "DepotList"},
            {"name": "dueTime", "type": "String (inner)", "required": True, "description": "\u5173\u95e8\u65f6\u95f4", "example": "20:00:00", "parent": "DepotList"},
            {"name": "baseTime", "type": "Double (inner)", "required": True, "description": "\u57fa\u7840\u65f6\u95f4", "example": "30", "parent": "DepotList"},
            {"name": "unloadTime", "type": "Double (inner)", "required": True, "description": "\u5378\u8d27\u65f6\u95f4", "example": "15.5", "parent": "DepotList"},
            {"name": "areaVehicle", "type": "AreaVehicle", "required": True, "description": "\u533a\u57df\u6570\u636e"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801 (\u9762\u6570\u636e)", "example": "fence_001", "parent": "AreaVehicle"},
            {"name": "areaCode", "type": "String (inner)", "required": True, "description": "\u533a\u57df\u7f16\u7801", "example": "area_001", "parent": "AreaVehicle"},
            {"name": "cantGoAreaCode", "type": "String (inner)", "required": False, "description": "\u4e0d\u53ef\u8fbe\u8f66\u578b", "example": "large", "parent": "AreaVehicle"},
            {"name": "isBreak", "type": "IsBreak", "required": True, "description": "\u662f\u5426\u53ef\u7a81\u7834\u3002\u662f\u5426\u5141\u8bb8\u7834\u7ea6\u675f\u3002\u53ef\u9009\u503c: true=\u5141\u8bb8\u7a81\u7834\u7ea6\u675f; false=\u4e0d\u5141\u8bb8\u7a81\u7834\u7ea6\u675f", "example": "false"},
            {"name": "vehicleList", "type": "List<VehicleList>", "required": True, "description": "\u8f66\u8f86\u5217\u8868", "example": "[{\"vehicleCode\":\"\u4eacA00001\",\"vehicleName\":\"\u6d4b\u8bd5\u8f66\u8f86\",\"volume\":50,\"box\":10}]"},
            {"name": "vehicleType", "type": "String (inner)", "required": True, "description": "\u8f66\u578b", "example": "small", "parent": "VehicleList"},
            {"name": "depotCode", "type": "String (inner)", "required": True, "description": "\u4ed3\u5e93\u7f16\u7801", "example": "depot_001", "parent": "VehicleList"},
            {"name": "number", "type": "Integer (inner)", "required": True, "description": "\u6570\u91cf", "example": "5", "parent": "VehicleList"},
            {"name": "box", "type": "Integer (inner)", "required": True, "description": "\u8f7d\u88c5\u91cf", "example": "100", "parent": "VehicleList"},
            {"name": "cost", "type": "Double (inner)", "required": True, "description": "\u56fa\u5b9a\u6210\u672c", "example": "500.0", "parent": "VehicleList"},
            {"name": "costPerKm", "type": "Double (inner)", "required": True, "description": "\u6bcf\u516c\u91cc\u6210\u672c", "example": "5.0", "parent": "VehicleList"},
            {"name": "costPerMinutes", "type": "Double (inner)", "required": True, "description": "\u6bcf\u5206\u949f\u6210\u672c", "example": "0.5", "parent": "VehicleList"}
        ],
        "example": "{\n    \"customerList\": {\n        \"propertyCode\": \"asset_001\",\n        \"customerCode\": \"customer_001\",\n        \"customerName\": \"\u5ba2\u6237\u540d\u79f0\",\n        \"areaCode\": \"area_001\",\n        \"depotCode\": \"depot_001\",\n        \"readyTime\": \"readyTime\",\n        \"dueTime\": \"dueTime\"\n    },\n    \"orderList\": {\n        \"propertyCode\": \"asset_001\",\n        \"customerCode\": \"customer_001\",\n        \"orderNo\": \"orderNo\",\n        \"skuNum\": 10,\n        \"boxNum\": 50,\n        \"vehicleType\": \"\u5c0f\u578b\u8d27\u8f66\",\n        \"firstOrder\": true\n    },\n    \"depotList\": {\n        \"propertyCode\": \"asset_001\",\n        \"code\": \"code\",\n        \"readyTime\": \"readyTime\",\n        \"dueTime\": \"dueTime\",\n        \"baseTime\": 30,\n        \"unloadTime\": 1\n    },\n    \"areaVehicle\": {\n        \"propertyCode\": \"asset_001\",\n        \"areaCode\": \"area_001\",\n        \"cantGoAreaCode\": \"cantGoAreaCode\"\n    },\n    \"isBreak\": \"true\",\n    \"vehicleList\": [\n        {\n            \"vehicleType\": \"\u5c0f\u578b\u8d27\u8f66\",\n            \"depotCode\": \"depot_001\",\n            \"number\": 5,\n            \"box\": 10,\n            \"cost\": 1,\n            \"costPerKm\": 5,\n            \"costPerMinutes\": 1\n        }\n    ]\n}",
    },
    "resource.service-day-week-division": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "serviceDayWeekDivision",
        "_http": "POST",
        "_summary": "\u670d\u52a1\u65e5-\u5468\u5212\u5206",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u4fe1\u606f", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "salesData", "type": "SalesData", "required": True, "description": "\u9500\u552e\u4fe1\u606f", "example": "{\"propertyCode\":\"sales_001\",\"skills\":\"skill_A\",\"code\":\"sales_code\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "sales_asset_001", "parent": "SalesData"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u9500\u552e\u7f16\u7801\uff08\u9500\u552e\u4fe1\u606f - \u9500\u552e\u7f16\u7801\uff09", "example": "S001", "parent": "SalesData"},
            {"name": "maxDistance", "type": "String (inner)", "required": True, "description": "\u6700\u5927\u552e\u70b9\u8ddd\u79bb\uff0c\u5355\u4f4d\uff1akm", "example": "maxdistance", "parent": "SalesData"},
            {"name": "maxVisitNum", "type": "String (inner)", "required": False, "description": "\u6bcf\u65e5\u6700\u5927\u670d\u52a1\u5ba2\u6237\u6570", "example": "maxvisitnum", "parent": "SalesData"},
            {"name": "minVisitNum", "type": "String (inner)", "required": False, "description": "\u6bcf\u65e5\u6700\u5c0f\u670d\u52a1\u5ba2\u6237\u6570", "example": "minvisitnum", "parent": "SalesData"},
            {"name": "historyData", "type": "HistoryData", "required": True, "description": "\u5386\u53f2\u62dc\u8bbf\u6570\u636e\u5217\u8868", "example": "{\"propertyCode\":\"history_001\",\"customerCode\":\"C001\",\"visitDate\":\"2024-01-01\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "history_001", "parent": "HistoryData"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u7f16\u7801\uff08\u5386\u53f2\u62dc\u8bbf\u6570\u636e\uff09", "example": "cust_001", "parent": "HistoryData"},
            {"name": "visitDate", "type": "String (inner)", "required": True, "description": "\u5b9e\u9645\u62dc\u8bbf\u65e5\u671f\uff08\u5386\u53f2\u62dc\u8bbf\u6570\u636e\uff09", "example": "2026-04-01", "parent": "HistoryData"},
            {"name": "salesCode", "type": "String (inner)", "required": True, "description": "\u9500\u552e\u7f16\u7801\uff08\u5386\u53f2\u62dc\u8bbf\u6570\u636e\uff09", "example": "S001", "parent": "HistoryData"},
            {"name": "scuPropertyCode", "type": "String", "required": False, "description": "\u56f4\u680f\u6570\u636e\uff08\u53ea\u5305\u542b\u8d44\u4ea7\u7f16\u7801\uff09"},
            {"name": "divideType", "type": "DivideType", "required": True, "description": "\u5212\u5206\u7c7b\u578b\u3002\u65f6\u95f4\u5212\u5206\u7c92\u5ea6\u3002\u53ef\u9009\u503c: week=\u5468; day=\u65e5", "example": "week"},
            {"name": "balanceField", "type": "String", "required": True, "description": "\u5747\u8861\u5b57\u6bb5\uff08\u5ba2\u8d44\u4fe1\u606f - \u7528\u4e8e\u5747\u8861\u5206\u914d\u5ba2\u6237\uff09", "example": "potentialValue"},
            {"name": "group1", "type": "String", "required": True, "description": "\u62dc\u8bbf\u5468\uff08divideType \u4e3a week \u65f6\u5fc5\u586b\uff0c\u5ba2\u6237\u4fe1\u606f - \u670d\u52a1\u65e5\u3001\u670d\u52a1\u5468\u5212\u5206\u6807\u8bc6\uff0c\u5982\u679c\u7b2c\u4e8c\u6b21\u89c4\u5212\u60f3\u57fa\u4e8e\u7b2c\u4e00\u6b21\u7684\u57fa\u7840\u8fdb\u884c\u5219\u9700\u8981\u9009\u62e9\uff09", "example": "potentialValue"},
            {"name": "group2", "type": "String", "required": False, "description": "\u62dc\u8bbf\u65e5"},
            {"name": "workDay", "type": "String", "required": False, "description": "\u5de5\u4f5c\u65e5\uff08divideType \u4e3a day \u65f6\u5fc5\u586b\uff09"},
            {"name": "startEndDate", "type": "List<String>", "required": True, "description": "\u5f00\u59cb\u7ed3\u675f\u65e5\u671f\u5217\u8868", "example": "[\"2024-01-01\"]"}
        ],
        "example": "{\n    \"customerData\": {\n        \"propertyCode\": \"asset_001\",\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"salesData\": {\n        \"propertyCode\": \"asset_001\",\n        \"code\": \"code\",\n        \"maxDistance\": \"maxDistance\",\n        \"maxVisitNum\": \"maxVisitNum\",\n        \"minVisitNum\": \"minVisitNum\"\n    },\n    \"historyData\": {\n        \"propertyCode\": \"asset_001\",\n        \"customerCode\": \"customer_001\",\n        \"visitDate\": \"visitDate\",\n        \"salesCode\": \"salesCode\"\n    },\n    \"scuPropertyCode\": \"scuPropertyCode\",\n    \"divideType\": \"week\",\n    \"balanceField\": \"balanceField\",\n    \"group1\": \"route_group1\",\n    \"group2\": \"route_group2\",\n    \"workDay\": \"\u5468\u4e00\",\n    \"startEndDate\": [\n        \"startEndDate\"\n    ]\n}",
    },
    "resource.service-route-planning": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "serviceRoutePlanning",
        "_http": "POST",
        "_summary": "\u670d\u52a1\u8def\u7ebf\u89c4\u5212",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u4fe1\u606f", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "salesData", "type": "SalesData", "required": True, "description": "\u9500\u552e\u4fe1\u606f", "example": "{\"propertyCode\":\"sales_001\",\"skills\":\"skill_A\",\"code\":\"sales_code\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "sales_asset_001", "parent": "SalesData"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u9500\u552e\u7f16\u7801\uff08\u9500\u552e\u4fe1\u606f - \u9500\u552e\u7f16\u7801\uff09", "example": "S001", "parent": "SalesData"},
            {"name": "maxDistance", "type": "String (inner)", "required": True, "description": "\u6700\u5927\u552e\u70b9\u8ddd\u79bb\uff0c\u5355\u4f4d\uff1akm", "example": "maxdistance", "parent": "SalesData"},
            {"name": "maxVisitNum", "type": "String (inner)", "required": False, "description": "\u6bcf\u65e5\u6700\u5927\u670d\u52a1\u5ba2\u6237\u6570", "example": "maxvisitnum", "parent": "SalesData"},
            {"name": "minVisitNum", "type": "String (inner)", "required": False, "description": "\u6bcf\u65e5\u6700\u5c0f\u670d\u52a1\u5ba2\u6237\u6570", "example": "minvisitnum", "parent": "SalesData"},
            {"name": "group1", "type": "String", "required": True, "description": "\u62dc\u8bbf\u5468"},
            {"name": "group2", "type": "String", "required": True, "description": "\u62dc\u8bbf\u65e5"},
            {"name": "startEndDate", "type": "List<String>", "required": True, "description": "\u5f00\u59cb\u7ed3\u675f\u65f6\u95f4\u6bb5\uff0c\u683c\u5f0f\uff1ayyyy-MM-dd HH:mm:ss"}
        ],
        "example": "{\n    \"customerData\": {\n        \"propertyCode\": \"asset_001\",\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"salesData\": {\n        \"propertyCode\": \"asset_001\",\n        \"code\": \"code\",\n        \"maxDistance\": \"maxDistance\",\n        \"maxVisitNum\": \"maxVisitNum\",\n        \"minVisitNum\": \"minVisitNum\"\n    },\n    \"group1\": \"route_group1\",\n    \"group2\": \"route_group2\",\n    \"startEndDate\": [\n        \"startEndDate\"\n    ]\n}",
    },
    "resource.vehicle-sales-planning": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "vehicleSalesPlanning",
        "_http": "POST",
        "_summary": "\u8f66\u9500\u89c4\u5212",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u4fe1\u606f", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "salesData", "type": "SalesData", "required": True, "description": "\u9500\u552e\u4fe1\u606f", "example": "{\"propertyCode\":\"sales_001\",\"skills\":\"skill_A\",\"code\":\"sales_code\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "sales_asset_001", "parent": "SalesData"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u9500\u552e\u7f16\u7801\uff08\u9500\u552e\u4fe1\u606f - \u9500\u552e\u7f16\u7801\uff09", "example": "S001", "parent": "SalesData"},
            {"name": "maxDistance", "type": "String (inner)", "required": True, "description": "\u6700\u5927\u552e\u70b9\u8ddd\u79bb\uff0c\u5355\u4f4d\uff1akm", "example": "maxdistance", "parent": "SalesData"},
            {"name": "maxVisitNum", "type": "String (inner)", "required": False, "description": "\u6bcf\u65e5\u6700\u5927\u670d\u52a1\u5ba2\u6237\u6570", "example": "maxvisitnum", "parent": "SalesData"},
            {"name": "minVisitNum", "type": "String (inner)", "required": False, "description": "\u6bcf\u65e5\u6700\u5c0f\u670d\u52a1\u5ba2\u6237\u6570", "example": "minvisitnum", "parent": "SalesData"},
            {"name": "balanceField", "type": "String", "required": True, "description": "\u5747\u8861\u5b57\u6bb5"},
            {"name": "workDay", "type": "String", "required": True, "description": "\u5de5\u4f5c\u5929\u6570"}
        ],
        "example": "{\n    \"customerData\": {\n        \"propertyCode\": \"asset_001\",\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"salesData\": {\n        \"propertyCode\": \"asset_001\",\n        \"code\": \"code\",\n        \"maxDistance\": \"maxDistance\",\n        \"maxVisitNum\": \"maxVisitNum\",\n        \"minVisitNum\": \"minVisitNum\"\n    },\n    \"balanceField\": \"balanceField\",\n    \"workDay\": \"\u5468\u4e00\"\n}",
    },
    "resource.route-replay": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "route_replay",
        "_http": "POST",
        "_summary": "\u7269\u6d41 - \u7ebf\u8def\u91cd\u6392",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "groupId", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e00", "example": "salesman_id"},
            {"name": "round", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e8c", "example": "route_seq"},
            {"name": "startLocation", "type": "String", "required": True, "description": "\u8d77\u59cb\u4f4d\u7f6e", "example": "warehouse_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"groupId\": \"groupId\",\n    \"round\": \"round\",\n    \"startLocation\": \"startLocation\"\n}",
    },
    "resource.generate-navigation-route-v1": {
        "_controller": "TaskPipelineResourcePlanningController",
        "_method": "generate_navigation_route_v1",
        "_http": "POST",
        "_summary": "\u7269\u6d41 - \u8def\u5f84\u89c4\u5212",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "group1", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e00", "example": "route_group"},
            {"name": "group2", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e8c", "example": "route_group"},
            {"name": "group3", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e09"},
            {"name": "group4", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\u56db"},
            {"name": "group5", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e94"},
            {"name": "arrivalOrder", "type": "String", "required": True, "description": "\u5230\u8fbe\u987a\u5e8f"},
            {"name": "startLocation", "type": "String", "required": False, "description": "\u8d77\u59cb\u4f4d\u7f6e"},
            {"name": "trackType", "type": "TrackType", "required": True, "description": "\u751f\u6210\u65b9\u5f0f\u3002\u8f68\u8ff9/\u8def\u7ebf\u751f\u6210\u65b9\u5f0f\u3002\u53ef\u9009\u503c: bicycling=\u9a91\u884c; driving=\u9a7e\u8f66; straightLine=\u76f4\u7ebf; walking=\u6b65\u884c"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"group1\": \"route_group1\",\n    \"group2\": \"route_group2\",\n    \"group3\": \"route_group3\",\n    \"group4\": \"route_group4\",\n    \"group5\": \"group5\",\n    \"arrivalOrder\": \"arrivalOrder\",\n    \"startLocation\": \"startLocation\",\n    \"trackType\": \"driving\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "base.point-square": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "point_generate_square",
        "_http": "POST",
        "_summary": "\u70b9\u751f\u6210\u65b9\u5757",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u552e\u70b9\u6570\u636e", "example": "point_001"},
            {"name": "radius", "type": "Double", "required": True, "description": "\u534a\u5f84\uff08\u7c73\uff09", "example": "1000"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"radius\": 1000\n}",
    },
    "base.point-hexagon": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "point_generate_hexagon",
        "_http": "POST",
        "_summary": "\u70b9\u751f\u6210\u8702\u7a9d",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u552e\u70b9\u6570\u636e", "example": "point_001"},
            {"name": "radius", "type": "Double", "required": True, "description": "\u534a\u5f84\uff08\u7c73\uff09", "example": "1000"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"radius\": 1000\n}",
    },
    "base.point-circle": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "point_generate_circle",
        "_http": "POST",
        "_summary": "\u70b9\u751f\u6210\u5706\u5f62",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u552e\u70b9\u6570\u636e", "example": "point_001"},
            {"name": "radius", "type": "Double", "required": True, "description": "\u534a\u5f84\uff08\u7c73\uff09", "example": "1000"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"radius\": 1000\n}",
    },
    "base.fence-extract": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "fence_coordinate_extraction",
        "_http": "POST",
        "_summary": "\u9762\u5750\u6807\u70b9\u63d0\u53d6\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u9009\u62e9\u9700\u8981\u6267\u884c\u7684\u9762\u6570\u636e", "example": "fence_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\"\n}",
    },
    "base.line-extract": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "line_coordinate_extraction",
        "_http": "POST",
        "_summary": "\u7ebf\u5750\u6807\u70b9\u63d0\u53d6\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u9009\u62e9\u9700\u8981\u6267\u884c\u7684\u7ebf\u6570\u636e", "example": "line_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\"\n}",
    },
    "base.coord-convert": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "coordinate_convert",
        "_http": "POST",
        "_summary": "\u70b9\u5750\u6807\u8f6c\u6362",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u552e\u70b9\u6570\u636e", "example": "point_001"},
            {"name": "sourceType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "WGS84"},
            {"name": "targetType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "GCJ02"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"sourceType\": \"WGS84\",\n    \"targetType\": \"WGS84\"\n}",
    },
    "base.line-coord-convert": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "line_coordinate_convert",
        "_http": "POST",
        "_summary": "\u7ebf\u5750\u6807\u8f6c\u6362",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u7ebf\u6570\u636e", "example": "line_001"},
            {"name": "sourceType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "WGS84"},
            {"name": "targetType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "GCJ02"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"sourceType\": \"WGS84\",\n    \"targetType\": \"WGS84\"\n}",
    },
    "base.fence-coord-convert": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "fence_coordinate_convert",
        "_http": "POST",
        "_summary": "\u9762\u5750\u6807\u8f6c\u6362",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u9762\u6570\u636e", "example": "fence_001"},
            {"name": "sourceType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "WGS84"},
            {"name": "targetType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "GCJ02"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"sourceType\": \"WGS84\",\n    \"targetType\": \"WGS84\"\n}",
    },
    "base.line-thin": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "line_coordinate_thinning",
        "_http": "POST",
        "_summary": "\u7ebf\u62bd\u7a00",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u7ebf\u6570\u636e", "example": "line_001"},
            {"name": "maxValue", "type": "String", "required": True, "description": "\u62bd\u7a00\u503c\uff08\u7c73\uff09", "example": "maxvalue"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"maxValue\": \"maxValue\"\n}",
    },
    "base.fence-thin": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "fence_coordinate_thinning",
        "_http": "POST",
        "_summary": "\u9762\u62bd\u7a00",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u9762\u6570\u636e", "example": "fence_001"},
            {"name": "maxValue", "type": "String", "required": True, "description": "\u62bd\u7a00\u503c\uff08\u7c73\uff09", "example": "maxvalue"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"maxValue\": \"maxValue\"\n}",
    },
    "base.track-generate": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "track_generate",
        "_http": "POST",
        "_summary": "\u8f68\u8ff9\u751f\u6210",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "track_001"},
            {"name": "orderBy", "type": "String", "required": True, "description": "\u987a\u5e8f", "example": "timestamp"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"orderBy\": \"orderBy\"\n}",
    },
    "base.point-rarefy": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "point_rarefy",
        "_http": "POST",
        "_summary": "\u70b9\u62bd\u7a00\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "dilutionLevel", "type": "Integer", "required": True, "description": "\u62bd\u7a00\u7ea7\u522b", "example": "8"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"dilutionLevel\": 8\n}",
    },
    "base.fence-boundary": {
        "_controller": "TaskPipelineBaseServiceApiController",
        "_method": "fence_boundary",
        "_http": "POST",
        "_summary": "\u591a\u8fb9\u5f62\u8f6c\u7ebf\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\"\n}",
    },
    "thirdparty.retailer-access": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "retailer_model_access",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7\u96f6\u552e\u51c6\u5165\u6a21\u578b\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "extra", "type": "String", "required": True, "description": "\u9644\u52a0\u5206\u503c", "example": "point_001"},
            {"name": "tag", "type": "String", "required": True, "description": "\u5206\u7ec4\u540d\u79f0", "example": "retail_group_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"extra\": \"extra\",\n    \"tag\": \"tag\"\n}",
    },
    "thirdparty.retailer-scoring": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "retailer_model_scoring",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7\u96f6\u552e\u8bc4\u4ef7\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "extra", "type": "String", "required": True, "description": "\u9644\u52a0\u5206\u9879", "example": "point_001"},
            {"name": "name", "type": "String", "required": True, "description": "\u96f6\u552e\u5546\u540d\u79f0", "example": "XX\u4fbf\u5229\u5e97"},
            {"name": "tag", "type": "String", "required": True, "description": "\u7ec4\u540d", "example": "scoring_group_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"extra\": \"extra\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"tag\": \"tag\"\n}",
    },
    "thirdparty.capacity-estimation": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "market_capacity_estimation",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7-\u5bb9\u91cf\u9884\u4f30\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u533a\u5757\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "block_001"},
            {"name": "name", "type": "String", "required": True, "description": "\u533a\u5757\u540d\u79f0", "example": "\u671d\u9633\u533a"},
            {"name": "tag", "type": "String", "required": True, "description": "\u5206\u7ec4\u6807\u8bc6", "example": "group_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"tag\": \"tag\"\n}",
    },
    "thirdparty.spacing-recommend": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "market_spacing_recommendation",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7-\u95f4\u8ddd\u63a8\u8350\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u533a\u5757\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "block_001"},
            {"name": "name", "type": "String", "required": True, "description": "\u533a\u5757\u540d\u79f0", "example": "\u671d\u9633\u533a"},
            {"name": "tag", "type": "String", "required": True, "description": "\u5206\u7ec4\u6807\u8bc6", "example": "group_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"tag\": \"tag\"\n}",
    },
    "thirdparty.retail-merchant-upload": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "retail_commercial_upload",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7\u96f6\u552e\u5546\u6237\u540c\u6b65\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "gdId", "type": "String", "required": True, "description": "\u96f6\u552e\u6237 ID", "example": "gd_12345"},
            {"name": "name", "type": "String", "required": False, "description": "\u96f6\u552e\u5546\u6237\u540d\u79f0", "example": "XX\u4fbf\u5229\u5e97"},
            {"name": "operation", "type": "String", "required": True, "description": "\u540c\u6b65\u7c7b\u578b", "example": "add"},
            {"name": "license", "type": "String", "required": True, "description": "\u96f6\u552e\u5546\u6237\u8bb8\u53ef\u8bc1", "example": "LIC-001"},
            {"name": "bizNet", "type": "String", "required": True, "description": "\u96f6\u552e\u6237\u4e1a\u6001", "example": "\u4fbf\u5229\u5e97"},
            {"name": "bizType", "type": "String", "required": False, "description": "\u96f6\u552e\u6237\u7c7b\u578b", "example": "normal"},
            {"name": "bizLevel", "type": "String", "required": False, "description": "\u96f6\u552e\u6237\u7ea7\u522b", "example": "A"},
            {"name": "tag", "type": "String", "required": True, "description": "\u96f6\u552e\u6237\u5206\u7ec4\u6807\u8bc6", "example": "retail_group_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"gdId\": \"gdId\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"operation\": \"operation\",\n    \"license\": \"license\",\n    \"bizNet\": \"bizNet\",\n    \"bizType\": \"bizType\",\n    \"bizLevel\": \"bizLevel\",\n    \"tag\": \"tag\"\n}",
    },
    "thirdparty.retail-merchant-info": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "retail_commercial_info",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7\u96f6\u552e\u5546\u6237\u5217\u8868\u67e5\u8be2\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "gdId", "type": "String", "required": True, "description": "\u96f6\u552e\u6237ID", "example": "gd_12345"},
            {"name": "name", "type": "String", "required": True, "description": "\u96f6\u552e\u5546\u6237\u540d\u79f0", "example": "XX\u4fbf\u5229\u5e97"},
            {"name": "tag", "type": "String", "required": True, "description": "\u96f6\u552e\u5546\u6237\u5206\u7ec4", "example": "retail_group_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"gdId\": \"gdId\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"tag\": \"tag\"\n}",
    },
    "thirdparty.duty-grid-upload": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "duty_grid_upload",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7\u8d23\u4efb\u7f51\u683c\u540c\u6b65\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u533a\u5757\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "block_001"},
            {"name": "gdId", "type": "String", "required": True, "description": "\u7f51\u683cID", "example": "grid_12345"},
            {"name": "name", "type": "String", "required": False, "description": "\u7f51\u683c\u540d\u79f0", "example": "XX\u7f51\u683c"},
            {"name": "operation", "type": "String", "required": True, "description": "\u64cd\u4f5c\u7b26", "example": "add"},
            {"name": "capacity", "type": "String", "required": True, "description": "\u6700\u5927\u51c6\u5165\u5bb9\u91cf", "example": "1000"},
            {"name": "preFactor", "type": "String", "required": False, "description": "\u4f18\u5f85\u7cfb\u6570", "example": "1.5"},
            {"name": "spacing", "type": "String", "required": False, "description": "\u6700\u5c0f\u51c6\u5165\u95f4\u8ddd", "example": "500"},
            {"name": "adcode", "type": "String", "required": False, "description": "\u533a\u57df\u7f16\u7801", "example": "110105"},
            {"name": "tag", "type": "String", "required": True, "description": "\u7f51\u683c\u5206\u7ec4\u540d\u79f0", "example": "grid_group_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"gdId\": \"gdId\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"operation\": \"operation\",\n    \"capacity\": \"capacity\",\n    \"preFactor\": \"preFactor\",\n    \"spacing\": \"spacing\",\n    \"adcode\": \"adcode\",\n    \"tag\": \"tag\"\n}",
    },
    "thirdparty.duty-grid-info": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "duty_grid_info",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7\u8d23\u4efb\u7f51\u683c\u5217\u8868\u67e5\u8be2\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u533a\u5757\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "block_001"},
            {"name": "gdId", "type": "String", "required": True, "description": "\u9ad8\u5fb7\u7f51\u683c ID", "example": "grid_12345"},
            {"name": "name", "type": "String", "required": True, "description": "\u9ad8\u5fb7\u7f51\u683c\u540d\u79f0", "example": "XX\u7f51\u683c"},
            {"name": "tag", "type": "String", "required": True, "description": "\u7f51\u683c\u5206\u7ec4", "example": "grid_group_001"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"gdId\": \"gdId\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"tag\": \"tag\"\n}",
    },
    "thirdparty.odm-gd-match": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "odm_gd_match",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7-POI\u5173\u8054",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u552e\u70b9\u6570\u636e", "example": "point_001"},
            {"name": "pointName", "type": "String", "required": True, "description": "\u552e\u70b9\u540d\u79f0", "example": "XX\u4fbf\u5229\u5e97"},
            {"name": "address", "type": "String", "required": True, "description": "\u5730\u5740", "example": "\u5317\u4eac\u5e02\u671d\u9633\u533aXX\u8defXX\u53f7"},
            {"name": "point", "type": "String", "required": True, "description": "\u7ecf\u7eac\u5ea6", "example": "116.404,39.915"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"pointName\": \"pointName\",\n    \"address\": \"\u5317\u4eac\u5e02\u671d\u9633\u533a\",\n    \"point\": \"point\"\n}",
    },
    "thirdparty.tx-poi-match-v2": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "tx_poi_match_v2",
        "_http": "POST",
        "_summary": "\u817e\u8baf POI \u5339\u914d V2",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u5ba2\u8d44\u6570\u636e", "example": "customer_001"},
            {"name": "policyCode", "type": "PolicyCode", "required": True, "description": "\u5173\u8054\u65b9\u5f0f\u679a\u4e3e\uff1a\u53ef\u9009\u503c: 30003=\u540d\u79f0+\u5730\u5740-\u5305\u542b\u7c7b\u76ee; 30004=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0+\u5730\u5740-\u5254\u9664\u7c7b\u76ee; 30006=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee", "example": "30003"},
            {"name": "mode", "type": "Mode", "required": False, "description": "\u5173\u8054\u6a21\u5f0f\u3002POI\u5339\u914d\u7b97\u6cd5\u6a21\u5f0f\u3002\u53ef\u9009\u503c: cluster=cluster\u6a21\u5f0f(\u7cbe\u786e\u5ea6\u66f4\u9ad8); link=link\u6a21\u5f0f(\u53ec\u56de\u7387\u66f4\u9ad8)", "example": "cluster"},
            {"name": "policyConfig", "type": "String", "required": False, "description": "\u7c7b\u76ee\u9009\u62e9"},
            {"name": "name", "type": "String", "required": True, "description": "\u540d\u79f0", "example": "XX\u95e8\u5e97"},
            {"name": "province", "type": "String", "required": True, "description": "\u7701", "example": "\u5317\u4eac\u5e02"},
            {"name": "city", "type": "String", "required": False, "description": "\u5e02", "example": "\u5317\u4eac\u5e02"},
            {"name": "district", "type": "String", "required": False, "description": "\u533a", "example": "\u671d\u9633\u533a"},
            {"name": "address", "type": "String", "required": False, "description": "\u5730\u5740\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30003,30005,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "\u5317\u4eac\u5e02\u671d\u9633\u533aXX\u8defXX\u53f7"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"policyCode\": \"30003\",\n    \"mode\": \"cluster\",\n    \"policyConfig\": \"\u65e0\",\n    \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n    \"province\": \"\u5e7f\u4e1c\u7701\",\n    \"city\": \"\u5317\u4eac\u5e02\",\n    \"district\": \"\u671d\u9633\u533a\",\n    \"address\": \"\u5317\u4eac\u5e02\u671d\u9633\u533a\"\n}",
    },
    "thirdparty.tx-poi-multi-v2": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "tx_poi_mutil_policy_match_v2",
        "_http": "POST",
        "_summary": "\u591a\u7ec4 - \u817e\u8baf POI \u5173\u8054",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u5ba2\u8d44\u6570\u636e"},
            {"name": "matchStrategyList", "type": "List<MatchStrategy>", "required": True, "description": "\u5339\u914d\u7b56\u7565"},
            {"name": "policyCode", "type": "PolicyCode (inner)", "required": True, "description": "\u5173\u8054\u65b9\u5f0f\u679a\u4e3e\uff1a\u53ef\u9009\u503c: 30003=\u540d\u79f0+\u5730\u5740-\u5305\u542b\u7c7b\u76ee; 30004=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0+\u5730\u5740-\u5254\u9664\u7c7b\u76ee; 30006=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee", "example": "30003", "parent": "MatchStrategy"},
            {"name": "policyConfig", "type": "String (inner)", "required": False, "description": "\u7c7b\u76ee\u9009\u62e9", "parent": "MatchStrategy"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0", "example": "XX\u95e8\u5e97", "parent": "MatchStrategy"},
            {"name": "mode", "type": "Mode (inner)", "required": False, "description": "\u5173\u8054\u6a21\u5f0f\u3002POI\u5339\u914d\u7b97\u6cd5\u6a21\u5f0f\u3002\u53ef\u9009\u503c: cluster=cluster\u6a21\u5f0f(\u7cbe\u786e\u5ea6\u66f4\u9ad8); link=link\u6a21\u5f0f(\u53ec\u56de\u7387\u66f4\u9ad8)", "example": "cluster", "parent": "MatchStrategy"},
            {"name": "address", "type": "String (inner)", "required": True, "description": "\u5730\u5740\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30003,30005,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "\u5317\u4eac\u5e02\u671d\u9633\u533aXX\u8defXX\u53f7", "parent": "MatchStrategy"},
            {"name": "poiPoint", "type": "String (inner)", "required": False, "description": "\u7ecf\u7eac\u5ea6\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30004,30006,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "116.397,39.908", "parent": "MatchStrategy"},
            {"name": "province", "type": "String (inner)", "required": False, "description": "\u7701", "example": "\u5317\u4eac\u5e02", "parent": "MatchStrategy"},
            {"name": "city", "type": "String (inner)", "required": False, "description": "\u5e02", "example": "\u5317\u4eac\u5e02", "parent": "MatchStrategy"},
            {"name": "district", "type": "String (inner)", "required": False, "description": "\u533a", "example": "\u671d\u9633\u533a", "parent": "MatchStrategy"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"matchStrategyList\": [\n        {\n            \"policyCode\": \"30003\",\n            \"policyConfig\": \"\u65e0\",\n            \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n            \"mode\": \"cluster\",\n            \"address\": \"\u5317\u4eac\u5e02\u671d\u9633\u533a\",\n            \"poiPoint\": \"poiPoint\",\n            \"province\": \"\u5e7f\u4e1c\u7701\",\n            \"city\": \"\u5317\u4eac\u5e02\",\n            \"district\": \"\u671d\u9633\u533a\"\n        }\n    ]\n}",
    },
    "thirdparty.tx-poi-multi": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "tx_poi_mutil_policy_match",
        "_http": "POST",
        "_summary": "\u591a\u7ec4-\u817e\u8bafPOI\u5173\u8054",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff1a\u5ba2\u8d44\u6570\u636e"},
            {"name": "matchStrategyList", "type": "List<MatchStrategy>", "required": True, "description": "\u5339\u914d\u7b56\u7565"},
            {"name": "policyCode", "type": "PolicyCode (inner)", "required": True, "description": "\u5173\u8054\u65b9\u5f0f\u679a\u4e3e\uff1a\u53ef\u9009\u503c: 30003=\u540d\u79f0+\u5730\u5740-\u5305\u542b\u7c7b\u76ee; 30004=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0+\u5730\u5740-\u5254\u9664\u7c7b\u76ee; 30006=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee", "example": "30003", "parent": "MatchStrategy"},
            {"name": "policyConfig", "type": "String (inner)", "required": False, "description": "\u7c7b\u76ee\u9009\u62e9", "parent": "MatchStrategy"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0", "example": "XX\u95e8\u5e97", "parent": "MatchStrategy"},
            {"name": "address", "type": "String (inner)", "required": True, "description": "\u5730\u5740\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30003,30005,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "\u5317\u4eac\u5e02\u671d\u9633\u533aXX\u8defXX\u53f7", "parent": "MatchStrategy"},
            {"name": "poiPoint", "type": "String (inner)", "required": False, "description": "\u7ecf\u7eac\u5ea6\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30004,30006,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "116.397,39.908", "parent": "MatchStrategy"},
            {"name": "province", "type": "String (inner)", "required": False, "description": "\u7701", "example": "\u5317\u4eac\u5e02", "parent": "MatchStrategy"},
            {"name": "city", "type": "String (inner)", "required": False, "description": "\u5e02", "example": "\u5317\u4eac\u5e02", "parent": "MatchStrategy"},
            {"name": "district", "type": "String (inner)", "required": False, "description": "\u533a", "example": "\u671d\u9633\u533a", "parent": "MatchStrategy"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"matchStrategyList\": [\n        {\n            \"policyCode\": \"30003\",\n            \"policyConfig\": \"\u65e0\",\n            \"name\": \"\u6d4b\u8bd5\u540d\u79f0\",\n            \"address\": \"\u5317\u4eac\u5e02\u671d\u9633\u533a\",\n            \"poiPoint\": \"poiPoint\",\n            \"province\": \"\u5e7f\u4e1c\u7701\",\n            \"city\": \"\u5317\u4eac\u5e02\",\n            \"district\": \"\u671d\u9633\u533a\"\n        }\n    ]\n}",
    },
    "thirdparty.odm-uncontrolled": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "odm_gd_uncontrolled",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7\u672a\u63a7\u552e\u70b9\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "point_001"},
            {"name": "adCode", "type": "String", "required": True, "description": "\u7701\u5e02\u533a adcode", "example": "110105"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"adCode\": \"adCode\"\n}",
    },
    "thirdparty.potential-area-split": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "potential_area_split_plan",
        "_http": "POST",
        "_summary": "��Ǳ���������ݴ�������",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "propertyCode", "type": "String", "required": True, "description": "��Ǳ�������������ʲ�����", "example": "fence_001"},
            {"name": "num", "type": "String", "required": True, "description": "Ǳ���ֶ�", "example": "sales_volume"},
            {"name": "splitCount", "type": "Integer", "required": True, "description": "��������", "example": "5"},
            {"name": "balance", "type": "Integer", "required": True, "description": "ƽ��ֵ", "example": "50"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "�ۺ��ֶ������б�", "example": "[...]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "�ۺ��ֶΣ������ݵ��ֶ�", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "�ۺ����͡��ۺϺ������͡���ѡֵ: Avg=ƽ��ֵ; Min=��Сֵ; Max=���ֵ; Sum=���; Count=����", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"propertyCode\": \"asset_001\",\n    \"num\": \"potentialValue\",\n    \"splitCount\": 5,\n    \"balance\": 50,\n    \"aggregationFields\": [\n        {\n            \"field\": \"fieldName\",\n            \"aggregationType\": \"Avg\"\n        }\n    ]\n}",
    },
    "thirdparty.customer-flow-items": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "customerFlowServiceItems",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u670d\u52a1\u9879\u76ee\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "remark", "type": "String", "required": False, "description": "\u4efb\u52a1\u5907\u6ce8", "example": "\u670d\u52a1\u9879\u76ee\u5206\u6790\u4efb\u52a1"}
        ],
        "example": "{\n    \"remark\": \"remark\"\n}",
    },
    "thirdparty.customer-flow-competitors": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "customerFlowCompetitorStores",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u7ade\u54c1\u95e8\u5e97\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u56f4\u680f\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "mallFieldCode", "type": "String", "required": True, "description": "\u5546\u573a\u5b57\u6bb5\u7f16\u7801", "example": "mall_code"}
        ],
        "example": "{\n    \"fencePropertyCode\": \"fence_asset\",\n    \"mallFieldCode\": \"mall_id\"\n}",
    },
    "thirdparty.customer-flow-report": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "customerFlowDataReports",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u6570\u636e\u62a5\u8868\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u56f4\u680f\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "mallFieldCode", "type": "String", "required": True, "description": "\u5546\u573a\u5b57\u6bb5\u7f16\u7801\uff08mallId\uff09", "example": "mall_code"},
            {"name": "dataReportInterApiParams", "type": "List<DataReportInterApiParams>", "required": True, "description": "\u6570\u636e\u62a5\u8868\u63a5\u53e3\u53c2\u6570\u914d\u7f6e\u5217\u8868", "example": "[...]"},
            {"name": "dateList", "type": "List<String> (inner)", "required": True, "description": "\u65e5\u671f\u5217\u8868", "example": "[\"2024-01-01\"]", "parent": "DataReportInterApiParams"},
            {"name": "interfaceCode", "type": "InterfaceCode (inner)", "required": True, "description": "\u63a5\u53e3\u7f16\u7801\u3002\u7b2c\u4e09\u65b9\u63a5\u53e3\u6807\u8bc6\u3002\u53ef\u9009\u503c: GETGRIDBUSSINESSCIRCLE=\u6805\u683c\u5ba2\u6d41/\u4eba\u53e3\u6570\u67e5\u8be2; GETAOIDEPRESSIONRANK=\u5ba2\u6d41\u6d3c\u5730\u6392\u540d\u67e5\u8be2; GETAOICOMMUNTIYSIZERANK=\u6765\u6e90\u5730\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETLOWPASSENGERFLOW=\u4f4e\u5ba2\u6d41\u533a\u57df\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETGRIDDEPRESSIONDATA=\u6805\u683c\u6e17\u900f\u7387\u67e5\u8be2; GETAOIPASSENGERFLOWRANK=\u5ba2\u6d41\u6765\u6e90\u6392\u540d\u67e5\u8be2; GETMALLFLOWANDNUMDATABYMALLID=\u5ba2\u6d41\u7edf\u8ba1; GETGRIDPERAGEPORTRAITS=\u5ba2\u6d41\u6d3b\u8dc3\u65f6\u6bb5; GETLENGTHSOFSTAYDATA=\u5ba2\u6d41\u505c\u7559\u65f6\u957f; GETGRIDPERAGEPORTRAITBYMALLIDS=\u5ba2\u6d41\u5230\u8bbf\u9891\u6b21 \u7b4919\u4e2a\u503c", "example": "getmallflowandnumdatabymallId", "parent": "DataReportInterApiParams"},
            {"name": "pType", "type": "String (inner)", "required": False, "description": "\u8bbf\u6b21\u6570\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a getgridperageportraitbymallIdS \u65f6\u6709\u6548\uff09", "example": "visitCount", "parent": "DataReportInterApiParams"}
        ],
        "example": "{\n    \"fencePropertyCode\": \"fence_asset\",\n    \"mallFieldCode\": \"mall_id\",\n    \"dataReportInterApiParams\": [\n        {\n            \"dateList\": [\n                \"dateList\"\n            ],\n            \"interfaceCode\": \"GETGRIDBUSSINESSCIRCLE\",\n            \"pType\": \"pType\"\n        }\n    ]\n}",
    },
    "thirdparty.customer-flow-pedestrian": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "customer_flow_business_district_pedestrian_flow_analysis",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u5546\u5708\u5ba2\u6d41\u5206\u6790\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "fencePropertyCode", "type": "String", "required": True, "description": "\u56f4\u680f\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "fence_001"},
            {"name": "mallFieldCode", "type": "String", "required": True, "description": "\u5546\u573a ID\uff08mallId\uff09", "example": "mall_001"},
            {"name": "apiParams", "type": "List<ApiParams>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "mall_001"},
            {"name": "interfaceCode", "type": "InterfaceCode (inner)", "required": True, "description": "\u63a5\u53e3\u7f16\u7801\u3002\u7b2c\u4e09\u65b9\u63a5\u53e3\u6807\u8bc6\u3002\u53ef\u9009\u503c: GETGRIDBUSSINESSCIRCLE=\u6805\u683c\u5ba2\u6d41/\u4eba\u53e3\u6570\u67e5\u8be2; GETAOIDEPRESSIONRANK=\u5ba2\u6d41\u6d3c\u5730\u6392\u540d\u67e5\u8be2; GETAOICOMMUNTIYSIZERANK=\u6765\u6e90\u5730\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETLOWPASSENGERFLOW=\u4f4e\u5ba2\u6d41\u533a\u57df\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETGRIDDEPRESSIONDATA=\u6805\u683c\u6e17\u900f\u7387\u67e5\u8be2; GETAOIPASSENGERFLOWRANK=\u5ba2\u6d41\u6765\u6e90\u6392\u540d\u67e5\u8be2; GETMALLFLOWANDNUMDATABYMALLID=\u5ba2\u6d41\u7edf\u8ba1; GETGRIDPERAGEPORTRAITS=\u5ba2\u6d41\u6d3b\u8dc3\u65f6\u6bb5; GETLENGTHSOFSTAYDATA=\u5ba2\u6d41\u505c\u7559\u65f6\u957f; GETGRIDPERAGEPORTRAITBYMALLIDS=\u5ba2\u6d41\u5230\u8bbf\u9891\u6b21 \u7b4919\u4e2a\u503c", "parent": "ApiParams"},
            {"name": "date", "type": "String (inner)", "required": True, "description": "\u65e5\u671f", "example": "2024-01-01", "parent": "ApiParams"},
            {"name": "type", "type": "List<Type> (inner)", "required": True, "description": "\u5ba2\u6d41\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a getaoipassengerflowrank\u3001getaoicommuntiysizerank\u3001getaoidepressionrank\u3001getlowpassengerflow \u65f6\u6709\u6548\uff09\u3002\u5ba2\u6d41\u7c7b\u578b\u5206\u7c7b\u3002\u53ef\u9009\u503c: 1=\u5c45\u4f4f; 2=\u5de5\u4f5c; 3=\u8def\u8fc7", "example": "2024-01-01", "parent": "ApiParams"},
            {"name": "property", "type": "List<Property> (inner)", "required": False, "description": "\u7f51\u683c\u4eba\u7fa4\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a getgridbussinesscircle \u65f6\u6709\u6548\uff09\u3002\u5ba2\u6d41\u6307\u6807\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u5ba2\u6d41\u6570\u91cf; 2=\u4eba\u53e3\u6570\u91cf", "parent": "ApiParams"}
        ],
        "example": "{\n    \"fencePropertyCode\": \"fence_asset\",\n    \"mallFieldCode\": \"mall_id\",\n    \"apiParams\": [\n        {\n            \"interfaceCode\": \"GETGRIDBUSSINESSCIRCLE\",\n            \"date\": \"2024-01-01\",\n            \"type\": [],\n            \"property\": []\n        }\n    ]\n}",
    },
    "thirdparty.customer-flow-competition": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "customer_flow_business_district_competition_intensity_analysis",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u5546\u5708\u7ade\u4e89\u70c8\u5ea6\u5206\u6790\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "fenceData", "type": "FenceData", "required": True, "description": "\u670d\u52a1\u533a\u7ade\u4e89\u70c8\u5ea6\u6570\u636e", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801\uff0c\u5fc5\u586b", "example": "point_001", "parent": "FenceData"},
            {"name": "mallIdFieldCode", "type": "String (inner)", "required": True, "description": "\u4e3b\u573a\u670d\u52a1\u533a ID \u5b57\u6bb5", "example": "mall_id", "parent": "FenceData"},
            {"name": "competitorMallIdFieldCode", "type": "String (inner)", "required": True, "description": "\u7ade\u54c1\u670d\u52a1\u533a ID \u5b57\u6bb5", "example": "n_mall_id", "parent": "FenceData"},
            {"name": "date", "type": "String", "required": True, "description": "\u65e5\u671f", "example": "2024-01-01"},
            {"name": "type", "type": "CompetitionType", "required": True, "description": "\u7ade\u4e89\u7c7b\u578b\u3002\u5ba2\u6d41\u7c7b\u578b\u5206\u7c7b\u3002\u53ef\u9009\u503c: 1=\u5c45\u4f4f; 2=\u5de5\u4f5c; 3=\u8def\u8fc7"}
        ],
        "example": "{\n    \"fenceData\": {\n        \"propertyCode\": \"asset_001\",\n        \"mallIdFieldCode\": \"mall_id\",\n        \"competitorMallIdFieldCode\": \"competitorMallIdFieldCode\"\n    },\n    \"date\": \"2024-01-01\",\n    \"type\": \"1\"\n}",
    },
    "thirdparty.lbs-passenger-point": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "lbs_passenger_portrait_point",
        "_http": "POST",
        "_summary": "LBS \u5ba2\u6d41\u753b\u50cf\u70b9\u6570\u636e\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "lbsPropertyCode", "type": "String", "required": True, "description": "LBS \u6570\u636e\u70b9\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "lbs_001"},
            {"name": "radius", "type": "String", "required": True, "description": "\u534a\u5f84 (\u7c73)", "example": "1000"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "\u7ed3\u679c\u5197\u4f59\u5b57\u6bb5", "example": "[\"translationfields\"]"},
            {"name": "lbsInterApiParams", "type": "List<LbsInterApiParams>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[...]"},
            {"name": "interfaceCode", "type": "InterfaceCode (inner)", "required": True, "description": "\u63a5\u53e3\u7c7b\u578b\u3002\u7b2c\u4e09\u65b9\u63a5\u53e3\u6807\u8bc6\u3002\u53ef\u9009\u503c: GETGRIDBUSSINESSCIRCLE=\u6805\u683c\u5ba2\u6d41/\u4eba\u53e3\u6570\u67e5\u8be2; GETAOIDEPRESSIONRANK=\u5ba2\u6d41\u6d3c\u5730\u6392\u540d\u67e5\u8be2; GETAOICOMMUNTIYSIZERANK=\u6765\u6e90\u5730\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETLOWPASSENGERFLOW=\u4f4e\u5ba2\u6d41\u533a\u57df\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETGRIDDEPRESSIONDATA=\u6805\u683c\u6e17\u900f\u7387\u67e5\u8be2; GETAOIPASSENGERFLOWRANK=\u5ba2\u6d41\u6765\u6e90\u6392\u540d\u67e5\u8be2; GETMALLFLOWANDNUMDATABYMALLID=\u5ba2\u6d41\u7edf\u8ba1; GETGRIDPERAGEPORTRAITS=\u5ba2\u6d41\u6d3b\u8dc3\u65f6\u6bb5; GETLENGTHSOFSTAYDATA=\u5ba2\u6d41\u505c\u7559\u65f6\u957f; GETGRIDPERAGEPORTRAITBYMALLIDS=\u5ba2\u6d41\u5230\u8bbf\u9891\u6b21 \u7b4919\u4e2a\u503c", "example": "residentnum", "parent": "LbsInterApiParams"},
            {"name": "monthAverage", "type": "MonthAverage (inner)", "required": False, "description": "\u56de\u6eaf\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentnum\u3001flownum \u65f6\u6709\u6548\uff09\u3002\u6708\u4efd\u5e73\u5747\u5468\u671f\u3002\u53ef\u9009\u503c: 1=\u5f53\u6708; 3=3\u4e2a\u6708; 6=6\u4e2a\u6708; 12=12\u4e2a\u6708", "example": "1", "parent": "LbsInterApiParams"},
            {"name": "adCode", "type": "String (inner)", "required": True, "description": "\u884c\u653f\u533a\u5212\u7f16\u7801", "example": "110000", "parent": "LbsInterApiParams"},
            {"name": "month", "type": "List<String> (inner)", "required": True, "description": "\u5f53\u524d\u6708\uff08\u591a\u9009\uff09", "example": "[\"month\"]", "parent": "LbsInterApiParams"},
            {"name": "peopleType", "type": "List<PeopleType> (inner)", "required": False, "description": "\u5e38\u9a7b\u4eba\u53e3\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentnum\u3001residentuserprofile \u65f6\u6709\u6548\uff09\u3002\u4eba\u53e3\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u5de5\u4f5c\u4eba\u53e3; 2=\u5c45\u4f4f\u4eba\u53e3; 3=\u5de5\u4f5c\u6216\u5c45\u4f4f", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "label", "type": "List<Label> (inner)", "required": False, "description": "\u6807\u7b7e\u5217\u8868\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentuserprofile\u3001flowuserprofile \u65f6\u6709\u6548\uff09\u3002\u7528\u6237\u753b\u50cf\u6807\u7b7e\u7f16\u7801\u3002\u53ef\u9009\u503c: 101010=\u6027\u522b; 101012=\u5e74\u9f84(\u5206\u6bb5); 101015=\u5b66\u5386; 101112=\u5a5a\u5426v2; 1041=\u5b50\u5973\u5e74\u9f84v2; 1052=\u5a5a\u80b2\u72b6\u6001; 1013=\u4eba\u751f\u9636\u6bb5; 1037=\u804c\u4e1a\u7ec6\u5206; 1038=\u6240\u5728\u884c\u4e1a; 990043=\u804c\u4f4f\u8ddd\u79bb(\u5206\u6bb5) \u7b4935\u4e2a\u503c", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "dateType", "type": "List<DateType> (inner)", "required": False, "description": "\u65e5\u671f\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a flownum\u3001flowuserprofile \u65f6\u6709\u6548\uff09\u3002\u65e5\u671f\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u6708\u65e5\u5e73\u5747; 2=\u5de5\u4f5c\u65e5\u5e73\u5747; 3=\u8282\u5047\u65e5\u5e73\u5747; workday=\u5de5\u4f5c\u65e5; weekend=\u5468\u672b; holiday=\u8282\u5047\u65e5", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "heatType", "type": "List<HeatType> (inner)", "required": False, "description": "\u70ed\u529b\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a locationpoint \u65f6\u6709\u6548\uff09\u3002\u70ed\u529b\u56fe\u7c7b\u578b\u3002\u53ef\u9009\u503c: flow_workday=\u5de5\u4f5c\u65e5\u5ba2\u6d41; flow_holiday=\u8282\u5047\u65e5\u5ba2\u6d41; resident_home=\u5c45\u4f4f; resident_work=\u5de5\u4f5c; people_flow=\u4eba\u6d41\u70ed\u529b; vehicle_flow=\u8f66\u6d41\u70ed\u529b", "example": "[...]", "parent": "LbsInterApiParams"}
        ],
        "example": "{\n    \"lbsPropertyCode\": \"lbs_asset\",\n    \"radius\": \"radius\",\n    \"translationFields\": [\n        \"translationFields\"\n    ],\n    \"lbsInterApiParams\": [\n        {\n            \"interfaceCode\": \"GETGRIDBUSSINESSCIRCLE\",\n            \"monthAverage\": \"1\",\n            \"adCode\": \"adCode\",\n            \"month\": [\n                \"month\"\n            ],\n            \"peopleType\": [],\n            \"label\": [],\n            \"dateType\": [],\n            \"heatType\": []\n        }\n    ]\n}",
    },
    "thirdparty.lbs-passenger-area": {
        "_controller": "TaskPipelineThirdPartyServiceController",
        "_method": "lbs_passenger_portrait_area",
        "_http": "POST",
        "_summary": "LBS \u5ba2\u6d41\u753b\u50cf\u9762\u6570\u636e\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "lbsPropertyCode", "type": "String", "required": True, "description": "LBS \u6570\u636e\u9762\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "lbs_area_001"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "\u7ed3\u679c\u5197\u4f59\u5b57\u6bb5", "example": "[\"translationfields\"]"},
            {"name": "lbsInterApiParams", "type": "List<LbsInterApiParams>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[...]"},
            {"name": "interfaceCode", "type": "InterfaceCode (inner)", "required": True, "description": "\u63a5\u53e3\u7c7b\u578b\u3002\u7b2c\u4e09\u65b9\u63a5\u53e3\u6807\u8bc6\u3002\u53ef\u9009\u503c: GETGRIDBUSSINESSCIRCLE=\u6805\u683c\u5ba2\u6d41/\u4eba\u53e3\u6570\u67e5\u8be2; GETAOIDEPRESSIONRANK=\u5ba2\u6d41\u6d3c\u5730\u6392\u540d\u67e5\u8be2; GETAOICOMMUNTIYSIZERANK=\u6765\u6e90\u5730\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETLOWPASSENGERFLOW=\u4f4e\u5ba2\u6d41\u533a\u57df\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETGRIDDEPRESSIONDATA=\u6805\u683c\u6e17\u900f\u7387\u67e5\u8be2; GETAOIPASSENGERFLOWRANK=\u5ba2\u6d41\u6765\u6e90\u6392\u540d\u67e5\u8be2; GETMALLFLOWANDNUMDATABYMALLID=\u5ba2\u6d41\u7edf\u8ba1; GETGRIDPERAGEPORTRAITS=\u5ba2\u6d41\u6d3b\u8dc3\u65f6\u6bb5; GETLENGTHSOFSTAYDATA=\u5ba2\u6d41\u505c\u7559\u65f6\u957f; GETGRIDPERAGEPORTRAITBYMALLIDS=\u5ba2\u6d41\u5230\u8bbf\u9891\u6b21 \u7b4919\u4e2a\u503c", "example": "residentnum", "parent": "LbsInterApiParams"},
            {"name": "monthAverage", "type": "MonthAverage (inner)", "required": False, "description": "\u56de\u6eaf\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentnum\u3001flownum \u65f6\u6709\u6548\uff09\u3002\u6708\u4efd\u5e73\u5747\u5468\u671f\u3002\u53ef\u9009\u503c: 1=\u5f53\u6708; 3=3\u4e2a\u6708; 6=6\u4e2a\u6708; 12=12\u4e2a\u6708", "example": "1", "parent": "LbsInterApiParams"},
            {"name": "adCode", "type": "String (inner)", "required": True, "description": "\u884c\u653f\u533a\u5212\u7f16\u7801", "example": "110000", "parent": "LbsInterApiParams"},
            {"name": "month", "type": "List<String> (inner)", "required": True, "description": "\u5f53\u524d\u6708\uff08\u591a\u9009\uff09", "example": "[\"month\"]", "parent": "LbsInterApiParams"},
            {"name": "peopleType", "type": "List<PeopleType> (inner)", "required": False, "description": "\u5e38\u9a7b\u4eba\u53e3\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentnum\u3001residentuserprofile \u65f6\u6709\u6548\uff09\u3002\u4eba\u53e3\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u5de5\u4f5c\u4eba\u53e3; 2=\u5c45\u4f4f\u4eba\u53e3; 3=\u5de5\u4f5c\u6216\u5c45\u4f4f", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "label", "type": "List<Label> (inner)", "required": False, "description": "\u6807\u7b7e\u5217\u8868\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentuserprofile\u3001flowuserprofile \u65f6\u6709\u6548\uff09\u3002\u7528\u6237\u753b\u50cf\u6807\u7b7e\u7f16\u7801\u3002\u53ef\u9009\u503c: 101010=\u6027\u522b; 101012=\u5e74\u9f84(\u5206\u6bb5); 101015=\u5b66\u5386; 101112=\u5a5a\u5426v2; 1041=\u5b50\u5973\u5e74\u9f84v2; 1052=\u5a5a\u80b2\u72b6\u6001; 1013=\u4eba\u751f\u9636\u6bb5; 1037=\u804c\u4e1a\u7ec6\u5206; 1038=\u6240\u5728\u884c\u4e1a; 990043=\u804c\u4f4f\u8ddd\u79bb(\u5206\u6bb5) \u7b4935\u4e2a\u503c", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "dateType", "type": "List<DateType> (inner)", "required": False, "description": "\u65e5\u671f\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a flownum\u3001flowuserprofile \u65f6\u6709\u6548\uff09\u3002\u65e5\u671f\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u6708\u65e5\u5e73\u5747; 2=\u5de5\u4f5c\u65e5\u5e73\u5747; 3=\u8282\u5047\u65e5\u5e73\u5747; workday=\u5de5\u4f5c\u65e5; weekend=\u5468\u672b; holiday=\u8282\u5047\u65e5", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "heatType", "type": "List<HeatType> (inner)", "required": False, "description": "\u70ed\u529b\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a locationpoint \u65f6\u6709\u6548\uff09\u3002\u70ed\u529b\u56fe\u7c7b\u578b\u3002\u53ef\u9009\u503c: flow_workday=\u5de5\u4f5c\u65e5\u5ba2\u6d41; flow_holiday=\u8282\u5047\u65e5\u5ba2\u6d41; resident_home=\u5c45\u4f4f; resident_work=\u5de5\u4f5c; people_flow=\u4eba\u6d41\u70ed\u529b; vehicle_flow=\u8f66\u6d41\u70ed\u529b", "example": "[...]", "parent": "LbsInterApiParams"}
        ],
        "example": "{\n    \"lbsPropertyCode\": \"lbs_asset\",\n    \"translationFields\": [\n        \"translationFields\"\n    ],\n    \"lbsInterApiParams\": [\n        {\n            \"interfaceCode\": \"GETGRIDBUSSINESSCIRCLE\",\n            \"monthAverage\": \"1\",\n            \"adCode\": \"adCode\",\n            \"month\": [\n                \"month\"\n            ],\n            \"peopleType\": [],\n            \"label\": [],\n            \"dateType\": [],\n            \"heatType\": []\n        }\n    ]\n}",
    },
    "realtime.spatial.analysis.projection-area": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_projection_area_calculation",
        "_http": "POST",
        "_summary": "\u6295\u5f71\u9762\u79ef\u8ba1\u7b97\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"f1\",\n            \"name\": \"\u6d4b\u8bd5\u56f4\u680f\",\n            \"fence\": \"POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))\"\n        }\n    ]\n}",
    },
    "realtime.spatial.analysis.address-parse": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_address_parsing",
        "_http": "POST",
        "_summary": "\u5730\u5740\u89e3\u6790\u8bf7\u6c42\u7c7b",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c address \u5730\u5740\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728", "example": "[{\"code\":\"001\",\"address\":\"\u5317\u4eac\u5e02\u671d\u9633\u533aXX\u8defXX\u53f7\"}]"},
            {"name": "address", "type": "String", "required": True, "description": "\u5730\u5740\u5b57\u6bb5\u540d", "example": "address"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"001\",\n            \"address\": \"\u5317\u4eac\u5e02\u671d\u9633\u533aXX\u8defXX\u53f7\"\n        }\n    ],\n    \"address\": \"address\"\n}",
    },
    "realtime.spatial.analysis.reverse-address-parse": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_reverse_address_parsing",
        "_http": "POST",
        "_summary": "\u9006\u5730\u5740\u89e3\u6790",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2dcode \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728,point\u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ]\n}",
    },
    "realtime.spatial.analysis.point-cluster": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_point_cluster_analysis",
        "_http": "POST",
        "_summary": "\u70b9\u805a\u7c7b\u5206\u6790\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "partitionNum", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf", "example": "10"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"partitionNum\": 10\n}",
    },
    "realtime.spatial.analysis.fence-cluster": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_fence_cluster_analysis",
        "_http": "POST",
        "_summary": "\u9762\u805a\u7c7b\u5206\u6790\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "partitionNum", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf", "example": "10"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"partitionNum\": 10\n}",
    },
    "realtime.spatial.analysis.affiliation-area-v1": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_affiliation_area_generate_v1_custom_polygon",
        "_http": "POST",
        "_summary": "\u5f52\u5c5e\u533a\u57df\u751f\u6210 V1-\u81ea\u5b9a\u4e49\u9762\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d\u5fc5\u987b\u5305\u542b code\u3001point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u548c\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"point\":\"POINT(116.3 39.9)\",\"areaName\":\"\u671d\u9633\u533a\"}]"},
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e \u5176\u4e2d\u5fc5\u987b\u5305\u542b code \u548c fence \u5b57\u6bb5\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "name", "type": "String", "required": True, "description": "\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5\uff0c\u5fc5\u586b", "example": "areaName"},
            {"name": "num", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u6f5c\u529b\u5b57\u6bb5", "example": "potentialValue"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"field\":\"sales\",\"aggregationType\":\"Sum\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"point\": \"POINT(116.3 39.9)\",\n            \"areaName\": \"\u671d\u9633\u533a\"\n        }\n    ],\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"name\": \"areaName\",\n    \"num\": \"potentialValue\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"sales\",\n            \"aggregationType\": \"Sum\"\n        }\n    ],\n    \"field\": \"salesAmount\"\n}",
    },
    "realtime.spatial.analysis.potential-classification": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_potential_classification_v2_point",
        "_http": "POST",
        "_summary": "\u7b49\u6f5c\u529b\u5212\u5206 V2-\u70b9\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e", "example": "[{\"code\":\"point_001\",\"point\":\"POINT(116.3 39.9)\",\"potential\":100}]"},
            {"name": "customizeFenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e", "example": "[{\"code\":\"fence_001\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "connectType", "type": "ConnectType", "required": True, "description": "\u8fde\u7ebf\u65b9\u5f0f\u3002\u8fde\u63a5/\u7f51\u683c\u7c7b\u578b(V2)\u3002\u53ef\u9009\u503c: 1=\u7f51\u683c; 2=\u8702\u7a9d", "example": "grid"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": True, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4\uff08\u591a\u9009\uff09", "example": "[[\"340000\"],[\"820000\"]]"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"field\":\"sales\",\"aggregationType\":\"Sum\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"},
            {"name": "numField", "type": "String", "required": False, "description": "\u6f5c\u529b\u5b57\u6bb5\u540d", "example": "potentialValue"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"point\": \"POINT(116.3 39.9)\",\n            \"potential\": 100\n        }\n    ],\n    \"customizeFenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"effectiveScope\": [\n        [\n            \"340000\"\n        ],\n        [\n            \"820000\"\n        ]\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"sales\",\n            \"aggregationType\": \"Sum\"\n        }\n    ],\n    \"numField\": \"potentialValue\"\n}",
    },
    "realtime.spatial.analysis.belonging-area-v2": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_belonging_area_gen_v2",
        "_http": "POST",
        "_summary": "\u5f52\u5c5e\u533a\u57df\u751f\u6210 V2 \u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e\u5217\u8868", "example": "[{\"code\":\"fence_001\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "customizeFenceData", "type": "List<Map<String, Object>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e\u5217\u8868", "example": "[{\"code\":\"fence_002\",\"fence\":\"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))\"}]"},
            {"name": "connectType", "type": "ConnectType", "required": True, "description": "\u5212\u5206\u7c7b\u578b\uff1a1-\u7f51\u683c\uff0c2-\u8702\u7a9d\u3002\u8fde\u63a5/\u7f51\u683c\u7c7b\u578b(V2)\u3002\u53ef\u9009\u503c: 1=\u7f51\u683c; 2=\u8702\u7a9d", "example": "1"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\uff1acity-\u57ce\u5e02\uff0cdistrict-\u533a\u53bf\uff0cprovince-\u7701\u4efd\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4", "example": "[[\"340000\"],[\"820000\"]]"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"field\":\"sales\",\"aggregationType\":\"Sum\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"customizeFenceData\": [\n        {\n            \"code\": \"fence_002\",\n            \"fence\": \"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))\"\n        }\n    ],\n    \"effectiveScope\": [\n        [\n            \"340000\"\n        ],\n        [\n            \"820000\"\n        ]\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"sales\",\n            \"aggregationType\": \"Sum\"\n        }\n    ],\n    \"field\": \"salesAmount\"\n}",
    },
    "realtime.spatial.analysis.random-sample": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_fence_random_sample",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5185\u968f\u673a\u53d6\u6837\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u5b57\u6bb5\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f\u4e3a WKT \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "count", "type": "Integer", "required": True, "description": "\u53d6\u6837\u6570\uff08\u4e2a\uff09", "example": "100"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"count\": 10\n}",
    },
    "realtime.spatial.analysis.kmeans": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_point_kmeans",
        "_http": "POST",
        "_summary": "KMeans \u7b97\u6cd5\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u5b57\u6bb5\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f\u4e3a WKT \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "clusterType", "type": "String", "required": True, "description": "\u805a\u7c7b\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u9762; 2=\u70b9\u8f6c\u9762", "example": "1"},
            {"name": "clusterAlgorithm", "type": "ClusterAlgorithm", "required": True, "description": "\u805a\u7c7b\u7b97\u6cd5\u3002\u53ef\u9009\u503c: 0=Kmeans", "example": "0"},
            {"name": "gridType", "type": "GridType", "required": False, "description": "\u7f51\u683c\u7c7b\u578b\u3002KMeans\u7f51\u683c/\u8702\u7a9d\u7c7b\u578b\u3002\u53ef\u9009\u503c: GD_r1000=R1000\u7f51\u683c; GD_r2000=R2000\u7f51\u683c; GD_r500=R500\u7f51\u683c; HD_r1000=R1000\u8702\u7a9d; HD_r2000=R2000\u8702\u7a9d; HD_r500=R500\u8702\u7a9d; RD_four=4\u7ea7\u8def\u7f51", "example": "GD_r1000"},
            {"name": "amount", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf", "example": "5"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"clusterType\": \"1\",\n    \"clusterAlgorithm\": \"0\",\n    \"amount\": 5\n}",
    },
    "realtime.spatial.analysis.fence-crossing": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_fence_crossing",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u4e0d\u76f8\u4ea4\u7684\u533a\u57df\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "sourceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u4e3b\u6570\u636e\u9762\u6570\u636e\u5217\u8868(\u5fc5\u987b\u5305\u542bcode\u548cfence\u5b57\u6bb5,fence\u4e3aWKT\u683c\u5f0f)", "example": "[{\"code\":\"001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "targetData", "type": "List<Map<String, Object>>", "required": True, "description": "\u5bf9\u6bd4\u9762\u6570\u636e\u5217\u8868(\u5fc5\u987b\u5305\u542bcode\u548cfence\u5b57\u6bb5,fence\u4e3aWKT\u683c\u5f0f)", "example": "[{\"code\":\"101\",\"name\":\"\u969c\u788d\u533a1\",\"fence\":\"POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))\"}]"}
        ],
        "example": "{\n    \"sourceData\": [\n        {\n            \"code\": \"001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"targetData\": [\n        {\n            \"code\": \"101\",\n            \"name\": \"\u969c\u788d\u533a1\",\n            \"fence\": \"POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))\"\n        }\n    ]\n}",
    },
    "realtime.spatial.analysis.line-buffer": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_line_buffer",
        "_http": "POST",
        "_summary": "\u7ebf\u5916\u6269\u7f13\u51b2\u533a\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "lineData", "type": "List<Map<String, Object>>", "required": True, "description": "\u7ebf\u6570\u636e\u5217\u8868(\u5fc5\u987b\u5305\u542bcode\u548cline\u5b57\u6bb5,line\u4e3aWKT\u683c\u5f0f)", "example": "[{\"code\":\"line_001\",\"name\":\"\u9053\u8def1\",\"line\":\"LINESTRING(116.3 39.9, 116.4 40.0, 116.5 40.1)\"}]"},
            {"name": "buffer", "type": "Integer", "required": True, "description": "\u7f13\u51b2\u8ddd\u79bb\uff08\u7c73\uff09", "example": "100"},
            {"name": "endCapStyle", "type": "BufferStyle", "required": True, "description": "\u7aef\u70b9\u6837\u5f0f\u3002\u7ebf\u7f13\u51b2\u7aef\u70b9\u6837\u5f0f\uff0c\u53ef\u9009\u503c: 1=\u534a\u5706; 2=\u5e73\u9762; 3=\u65b9\u5f62", "example": "1"},
            {"name": "quadrantSegments", "type": "Integer", "required": False, "description": "\u5706\u5f27\u7ebf\u6bb5\u6570", "example": "8"}
        ],
        "example": "{\n    \"lineData\": [\n        {\n            \"code\": \"line_001\",\n            \"name\": \"\u9053\u8def1\",\n            \"line\": \"LINESTRING(116.3 39.9, 116.4 40.0, 116.5 40.1)\"\n        }\n    ],\n    \"buffer\": 100\n}",
    },
    "realtime.spatial.analysis.area-split": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_area_split_plan",
        "_http": "POST",
        "_summary": "\u7b49\u9762\u79ef\u5212\u5206\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": False, "description": "", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "splitCount", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf\uff1a\u9700\u8981\u5c06\u9762\u6570\u636e\u5212\u5206\u6210\u7684\u533a\u57df\u6570\u91cf", "example": "5"},
            {"name": "balance", "type": "Integer", "required": True, "description": "\u5e73\u8861\u503c\uff1a\u63a7\u5236\u5212\u5206\u7ed3\u679c\u7684\u5747\u8861\u7a0b\u5ea6\uff0c\u503c\u8d8a\u5927\u8d8a\u5747\u8861", "example": "50"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868\uff0c\u7528\u4e8e\u5bf9\u5212\u5206\u7ed3\u679c\u8fdb\u884c\u7edf\u8ba1\u5206\u6790", "example": "[{\"field\":\"salesAmount\",\"type\":\"Count\",\"alias\":\"totalSales\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"splitCount\": 5,\n    \"balance\": 50,\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"type\": \"Count\",\n            \"alias\": \"totalSales\"\n        }\n    ],\n    \"field\": \"salesAmount\",\n    \"type\": \"Count\",\n    \"alias\": \"totalSales\"\n}",
    },
    "realtime.spatial.analysis.potential-split": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_potential_area_split_plan",
        "_http": "POST",
        "_summary": "\u7b49\u6f5c\u529b\u5212\u5206\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": False, "description": "", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "num", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u7528\u4e8e\u5212\u5206\u8ba1\u7b97\u7684\u5b57\u6bb5\u540d\u79f0", "example": "population"},
            {"name": "splitCount", "type": "Integer", "required": True, "description": "\u5212\u5206\u6570\u91cf\uff1a\u9700\u8981\u5c06\u9762\u6570\u636e\u5212\u5206\u6210\u7684\u533a\u57df\u6570\u91cf", "example": "5"},
            {"name": "balance", "type": "Integer", "required": True, "description": "\u5e73\u8861\u503c\uff1a\u63a7\u5236\u5212\u5206\u7ed3\u679c\u7684\u5747\u8861\u7a0b\u5ea6\uff0c\u503c\u8d8a\u5927\u8d8a\u5747\u8861", "example": "50"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868\uff0c\u7528\u4e8e\u5bf9\u5212\u5206\u7ed3\u679c\u8fdb\u884c\u7edf\u8ba1\u5206\u6790", "example": "[...]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"f1\",\n            \"name\": \"\u6d4b\u8bd5\u56f4\u680f\",\n            \"fence\": \"POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))\"\n        }\n    ],\n    \"num\": \"potentialValue\",\n    \"splitCount\": 5,\n    \"balance\": 50,\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"aggregationType\": \"Sum\"\n        }\n    ]\n}",
    },
    "realtime.spatial.analysis.equal-value-split": {
        "_controller": "TaskPipelineRealtimeSpatialAnalysisController",
        "_method": "realtime_equal_value_split_v2",
        "_http": "POST",
        "_summary": "\u7b49\u6f5c\u529b\u5212\u5206V2-\u9762\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u7528\u4e8e\u7b49\u6f5c\u529b\u5212\u5206V2\u7684\u6e90\u6570\u636e", "example": "[{\"code\":\"F001\",\"fence\":\"POLYGON((...))\"}]"},
            {"name": "num", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u7528\u4e8e\u5212\u5206\u8ba1\u7b97\u7684\u5b57\u6bb5\u540d\u79f0", "example": "potentialValue"},
            {"name": "splitCount", "type": "Integer", "required": False, "description": ""},
            {"name": "balanceValue", "type": "Integer", "required": False, "description": ""},
            {"name": "compareValue", "type": "Integer", "required": False, "description": ""},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868\uff0c\u7528\u4e8e\u5bf9\u5212\u5206\u7ed3\u679c\u8fdb\u884c\u7edf\u8ba1\u5206\u6790", "example": "[{\"field\":\"salesAmount\",\"type\":\"Count\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"F001\",\n            \"fence\": \"POLYGON((...))\"\n        }\n    ],\n    \"num\": \"potentialValue\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"type\": \"Count\"\n        }\n    ],\n    \"field\": \"salesAmount\",\n    \"type\": \"Count\",\n    \"alias\": \"totalSales\"\n}",
    },
    "realtime.spatial.calculation.point-outside-fence": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_point_outside_fence",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5916\u7684\u70b9\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "buffer", "type": "Integer", "required": True, "description": "\u5916\u6269\u8303\u56f4\uff08\u7c73\uff09", "example": "100"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "\u62fc\u63a5\u5b57\u6bb5 (\u56f4\u680f\u6570\u636e\u7684\u5b57\u6bb5)", "example": "[\"name\",\"type\"]"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"buffer\": 100,\n    \"translationFields\": [\n        \"name\",\n        \"type\"\n    ]\n}",
    },
    "realtime.spatial.calculation.scatter-fence": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_scatter_points_build_fence",
        "_http": "POST",
        "_summary": "\u6563\u70b9\u6784\u5efa\u9762\u6570\u636e\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "", "example": "[{\"field\": \"salesAmount\", \"aggregationType\": \"Sum\"}, {\"field\": \"storeCount\", \"aggregationType\": \"Count\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"},
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": False, "description": "", "example": "[{\"code\": \"P001\", \"point\": \"POINT(116.404 39.915)\"}, {\"code\": \"P002\", \"point\": \"POINT(116.405 39.916)\"}]"},
            {"name": "groupField", "type": "String", "required": False, "description": "", "example": "region_code"},
            {"name": "fenceType", "type": "FenceType", "required": False, "description": "\u6563\u70b9\u6784\u56f4\u680f\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u51f8\u5305; 2=\u51f9\u5305; 3=\u5916\u5207\u77e9\u5f62"}
        ],
        "example": "{\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"aggregationType\": \"Sum\"\n        },\n        {\n            \"field\": \"storeCount\",\n            \"aggregationType\": \"Count\"\n        }\n    ],\n    \"pointData\": [\n        {\n            \"code\": \"P001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        },\n        {\n            \"code\": \"P002\",\n            \"point\": \"POINT(116.405 39.916)\"\n        }\n    ],\n    \"groupField\": \"region_code\"\n}",
    },
    "realtime.spatial.calculation.point-in-fence": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_point_inside_fence",
        "_http": "POST",
        "_summary": "Χ����ĵ�����",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "������ ����code �� point ��γ���ֶ����ݱ������,point��ʽ wkt ��ʽ", "example": "[{\"code\":\"point_001\",\"name\":\"���Ե�\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "Χ������ ���� code �� fence Χ���ֶ����ݱ�����ڣ�fence ��ʽ wkt ��ʽ", "example": "[{\"code\":\"fence_001\",\"name\":\"����A\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "buffer", "type": "Integer", "required": False, "description": "������Χ���ף�", "example": "100"},
            {"name": "oneToOneFlag", "type": "Boolean", "required": True, "description": "�ж���ʽ��true-��Χ����false-��Χ��", "example": "true"},
            {"name": "isAll", "type": "Boolean", "required": True, "description": "�Ƿ�ȫ����true-�ǣ�false-��", "example": "true"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "ƴ���ֶ� (Χ�����ݵ��ֶ�)", "example": "[\"name\",\"type\"]"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"���Ե�\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"����A\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"buffer\": 100,\n    \"oneToOneFlag\": true,\n    \"isAll\": true,\n    \"translationFields\": [\n        \"name\",\n        \"type\"\n    ]\n}",
    },
    "realtime.spatial.calculation.belonging-area-v1": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_belonging_area_generate_v1",
        "_http": "POST",
        "_summary": "\u5f52\u5c5e\u533a\u57df\u751f\u6210 V1 \u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d\u5fc5\u987b\u5305\u542b code\u3001point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u548c\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "name", "type": "String", "required": True, "description": "\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u5f52\u5c5e\u533a\u57df\u5b57\u6bb5", "example": "areaName"},
            {"name": "num", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u6f5c\u529b\u5b57\u6bb5", "example": "potentialValue"},
            {"name": "connectType", "type": "ConnectType", "required": True, "description": "\u8fde\u63a5\u65b9\u5f0f\uff1a1-\u76f4\u7ebf\uff0c2-\u7f51\u683c\uff0c3-\u8702\u7a9d\u3002\u8fde\u63a5/\u7f51\u683c\u7c7b\u578b(V2)\u3002\u53ef\u9009\u503c: 1=\u7f51\u683c; 2=\u8702\u7a9d", "example": "1"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": False, "description": "\u8fb9\u754c\u7b49\u7ea7\uff0c\u8fde\u63a5\u65b9\u5f0f\u4e3a 2 \u6216 3 \u65f6\u5fc5\u586b\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"point\": \"POINT(116.3 39.9)\",\n            \"areaName\": \"\u671d\u9633\u533a\"\n        }\n    ],\n    \"name\": \"areaName\",\n    \"num\": \"potentialValue\",\n    \"aggregationFields\": []\n}",
    },
    "realtime.spatial.calculation.fence-without-point": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_fence_without_point",
        "_http": "POST",
        "_summary": "\u4e0d\u5305\u542b\u70b9\u7684\u56f4\u680f\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "buffer", "type": "Integer", "required": True, "description": "\u5916\u6269\u8303\u56f4\uff08\u7c73\uff09", "example": "100"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "\u62fc\u63a5\u5b57\u6bb5 (\u70b9\u6570\u636e\u7684\u5b57\u6bb5)", "example": "[\"name\",\"type\"]"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"buffer\": 100,\n    \"translationFields\": [\n        \"name\",\n        \"type\"\n    ]\n}",
    },
    "realtime.spatial.calculation.fence-intersection-area": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_fence_intersection_area",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u76f8\u4ea4\u7684\u533a\u57df\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "mainFenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u4e3b\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "auxiliaryFenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u8f85\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_002\",\"name\":\"\u533a\u57dfB\",\"fence\":\"POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))\"}]"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "\u62fc\u63a5\u5b57\u6bb5 (\u4e3b\u56f4\u680f\u6570\u636e\u7684\u5b57\u6bb5)", "example": "[\"name\",\"regionType\"]"}
        ],
        "example": "{\n    \"mainFenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"auxiliaryFenceData\": [\n        {\n            \"code\": \"fence_002\",\n            \"name\": \"\u533a\u57dfB\",\n            \"fence\": \"POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))\"\n        }\n    ],\n    \"translationFields\": [\n        \"name\",\n        \"regionType\"\n    ]\n}",
    },
    "realtime.spatial.calculation.fence-contain": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_fence_contain_fence",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5305\u542b\u56f4\u680f\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "mainData", "type": "List<Map<String, Object>>", "required": True, "description": "\u4e3b\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"main_001\",\"name\":\"\u4e3b\u6570\u636e\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "auxiliaryData", "type": "List<Map<String, Object>>", "required": True, "description": "\u8f85\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"aux_001\",\"name\":\"\u8f85\u52a9\u6570\u636e\",\"fence\":\"POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))\"}]"},
            {"name": "translationFields", "type": "List<String>", "required": False, "description": "\u7ed3\u679c\u5bb9\u6613\u5b57\u6bb5 (\u8f85\u6570\u636e\u8d44\u4ea7\u7684\u5b57\u6bb5)\uff0c\u975e\u5fc5\u586b", "example": "[\"field1\",\"field2\"]"}
        ],
        "example": "{\n    \"mainData\": \"mainData\",\n    \"auxiliaryData\": \"auxiliaryData\",\n    \"translationFields\": [\n        \"field1\",\n        \"field2\"\n    ]\n}",
    },
    "realtime.spatial.calculation.fence-merge": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_fence_merge_area",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5408\u5e76\u540e\u7684\u533a\u57df\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\",\"regionType\":\"A\"}]"},
            {"name": "mergeField", "type": "String", "required": True, "description": "\u5408\u5e76\u5b57\u6bb5\uff08\u9762\u8d44\u4ea7\u7684\u5b57\u6bb5\uff09", "example": "regionType"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u5217\u8868", "example": "[{\"field\":\"population\",\"type\":\"Sum\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\",\n            \"regionType\": \"A\"\n        }\n    ],\n    \"mergeField\": \"regionType\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"population\",\n            \"type\": \"Sum\"\n        }\n    ]\n}",
    },
    "realtime.spatial.calculation.line-intersection": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_line_intersection_point",
        "_http": "POST",
        "_summary": "\u7ebf\u76f8\u4ea4\u53d6\u4ea4\u70b9\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "lineData", "type": "List<Map<String, Object>>", "required": True, "description": "\u7ebf\u6570\u636e \u5176\u4e2d code \u548c line \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cline \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"line_001\",\"name\":\"\u6d4b\u8bd5\u7ebf\",\"line\":\"LINESTRING(116.3 39.9, 116.4 40.0)\"}]"}
        ],
        "example": "{\n    \"lineData\": [\n        {\n            \"code\": \"l1\",\n            \"name\": \"\u6d4b\u8bd5\u7ebf\",\n            \"line\": \"LINESTRING(108.9 34.2, 109.0 34.3)\"\n        }\n    ]\n}",
    },
    "realtime.spatial.calculation.line-split-fence": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_line_split_fence",
        "_http": "POST",
        "_summary": "\u7ebf\u5206\u5272\u56f4\u680f\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "lineData", "type": "List<Map<String, Object>>", "required": True, "description": "\u7ebf\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c line \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cline \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"line_001\",\"name\":\"\u6d4b\u8bd5\u7ebf\",\"line\":\"LINESTRING(116.3 39.9, 116.4 40.0)\"}]"},
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"}
        ],
        "example": "{\n    \"lineData\": [\n        {\n            \"code\": \"l1\",\n            \"name\": \"\u6d4b\u8bd5\u7ebf\",\n            \"line\": \"LINESTRING(108.9 34.2, 109.0 34.3)\"\n        }\n    ],\n    \"fenceData\": [\n        {\n            \"code\": \"f1\",\n            \"name\": \"\u6d4b\u8bd5\u56f4\u680f\",\n            \"fence\": \"POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))\"\n        }\n    ]\n}",
    },
    "realtime.spatial.calculation.scu-h3-merge": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_scu_h3_merge",
        "_http": "POST",
        "_summary": "SCU-H3 \u5408\u5e76\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c fence \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "potential", "type": "String", "required": True, "description": "\u6f5c\u529b\u503c\u5b57\u6bb5", "example": "potentialValue"},
            {"name": "minValue", "type": "Integer", "required": True, "description": "\u6f5c\u529b\u533a\u95f4\u6700\u5c0f\u503c", "example": "0"},
            {"name": "maxValue", "type": "Integer", "required": True, "description": "\u6f5c\u529b\u533a\u95f4\u6700\u5927\u503c", "example": "9999999"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\",\n            \"potential\": 100\n        }\n    ],\n    \"customizeFenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"potential\": \"potentialValue\",\n    \"effectiveScope\": [\n        [\n            \"340000\"\n        ],\n        [\n            \"820000\"\n        ]\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"sales\",\n            \"aggregationType\": \"Sum\"\n        }\n    ],\n    \"field\": \"salesAmount\"\n}",
    },
    "realtime.spatial.calculation.scu-s2": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_scu_s2_standard_generate",
        "_http": "POST",
        "_summary": "SCU-S2 \u6807\u51c6\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": True, "description": "\u751f\u6210\u65b9\u5411\u3002\u5c42\u7ea7\u7f51\u683c\u5206\u88c2/\u5408\u5e76\u751f\u6210\u65b9\u5411\u3002\u53ef\u9009\u503c: bigToSmall=\u4ece\u5927\u5230\u5c0f; smallToBig=\u4ece\u5c0f\u5230\u5927", "example": "bigToSmall"},
            {"name": "potential", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "example": "bigToSmall"},
            {"name": "splitValue", "type": "Integer", "required": True, "description": "\u5212\u5206\u503c"},
            {"name": "zoomStart", "type": "Integer", "required": True, "description": "S2 \u5f00\u59cb\u7ea7\u522b"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"},
            {"name": "customizeFenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_002\",\"fence\":\"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))\"}]"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4"}
        ],
        "example": "{\n    \"pointData\": \"pointData\",\n    \"generateDirection\": \"bigToSmall\",\n    \"boundaryLevel\": \"city\",\n    \"customizeFenceData\": \"customizeFenceData\",\n    \"aggregationFields\": [],\n    \"effectiveScope\": \"effectiveScope\",\n    \"field\": \"field\",\n    \"aggregationType\": {}\n}",
    },
    "realtime.spatial.calculation.h3-split-merge": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_h3_split_merge_generate",
        "_http": "POST",
        "_summary": "H3 \u62c6\u5408\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\",\"potential\":100}]"},
            {"name": "customizeFenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e", "example": "[{\"code\":\"fence_001\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": True, "description": "\u751f\u6210\u65b9\u5411\uff1abigToSmall-\u4ece\u5927\u5230\u5c0f\uff0csmallToBig-\u4ece\u5c0f\u5230\u5927\u3002\u5c42\u7ea7\u7f51\u683c\u5206\u88c2/\u5408\u5e76\u751f\u6210\u65b9\u5411\u3002\u53ef\u9009\u503c: bigToSmall=\u4ece\u5927\u5230\u5c0f; smallToBig=\u4ece\u5c0f\u5230\u5927", "example": "bigToSmall"},
            {"name": "potential", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5", "example": "potentialValue"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\uff1acity-\u57ce\u5e02\uff0cdistrict-\u533a\u53bf\uff0cprovince-\u7701\u4efd\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4", "example": "[[\"340000\"],[\"820000\"]]"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"field\":\"sales\",\"aggregationType\":\"Sum\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\",\n            \"potential\": 100\n        }\n    ],\n    \"customizeFenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"potential\": \"potentialValue\",\n    \"effectiveScope\": [\n        [\n            \"340000\"\n        ],\n        [\n            \"820000\"\n        ]\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"sales\",\n            \"aggregationType\": \"Sum\"\n        }\n    ],\n    \"field\": \"salesAmount\"\n}",
    },
    "realtime.spatial.calculation.scu-admin": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_scu_admin_division_generate",
        "_http": "POST",
        "_summary": "SCU-\u884c\u653f\u533a\u5212\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\",\"potential\":100}]"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": True, "description": "\u751f\u6210\u65b9\u5411\u3002\u5c42\u7ea7\u7f51\u683c\u5206\u88c2/\u5408\u5e76\u751f\u6210\u65b9\u5411\u3002\u53ef\u9009\u503c: bigToSmall=\u4ece\u5927\u5230\u5c0f; smallToBig=\u4ece\u5c0f\u5230\u5927", "example": "bigToSmall"},
            {"name": "potential", "type": "String", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5", "example": "potential"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u7edf\u8ba1", "example": "[{\"field\":\"sales\",\"aggregationType\":\"Sum\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\",\n            \"potential\": 100\n        }\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"sales\",\n            \"aggregationType\": \"Sum\"\n        }\n    ],\n    \"field\": \"sales\"\n}",
    },
    "realtime.spatial.calculation.fence-buffer": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_fence_broad_buffer",
        "_http": "POST",
        "_summary": "\u56f4\u680f\u5916\u6269\u7f13\u51b2\u533a",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "bufferArea", "type": "String", "required": True, "description": "\u5916\u6269\u8303\u56f4\uff08\u7c73\uff09", "example": "1000"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"bufferArea\": 1000\n}",
    },
    "realtime.spatial.calculation.point-centroid": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_point_centroid",
        "_http": "POST",
        "_summary": "\u70b9\u8d28\u5fc3\u8ba1\u7b97",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "partitionType", "type": "PartitionType", "required": True, "description": "\u5212\u5206\u7c7b\u578b\u3002\u7a7a\u95f4\u5212\u5206\u7c7b\u578b\u3002\u53ef\u9009\u503c: hexagon=\u8702\u7a9d; square=\u65b9\u5757", "example": "hexagon"},
            {"name": "sideLength", "type": "Integer", "required": True, "description": "\u8fb9\u957f\uff08\u6700\u5c0f\u503c 100\uff0c\u6700\u5927\u503c 100000\uff09", "example": "1000"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u7edf\u8ba1", "example": "[{\"field\":\"sales\",\"aggregationType\":\"Avg\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"sideLength\": 1000,\n    \"aggregationFields\": [\n        {\n            \"field\": \"sales\",\n            \"aggregationType\": \"Avg\"\n        }\n    ],\n    \"field\": \"sales\"\n}",
    },
    "realtime.spatial.calculation.fence-contain-relation": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_fence_contain_relation",
        "_http": "POST",
        "_summary": "\u5355\u56f4\u680f\u5305\u542b\u5173\u7cfb",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "field1", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5 1", "example": "field1"},
            {"name": "field2", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 2"},
            {"name": "field3", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 3"},
            {"name": "field4", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 4"},
            {"name": "field5", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 5"},
            {"name": "oneToOneFlag", "type": "Boolean", "required": True, "description": "\u5305\u542b\u7c7b\u578b\uff08true: \u5355\u56f4\u680f\uff0cfalse: \u591a\u56f4\u680f\uff09", "example": "true"},
            {"name": "isGroup", "type": "Boolean", "required": True, "description": "\u662f\u5426\u5206\u7ec4\uff08true: \u662f\uff0cfalse: \u5426\uff09", "example": "true"},
            {"name": "containRatio", "type": "String", "required": True, "description": "\u5305\u542b\u6bd4\u4f8b", "example": "100"},
            {"name": "isAll", "type": "Boolean", "required": True, "description": "\u662f\u5426\u9700\u8981\u5168\u91cf\u6570\u636e\uff08true: \u662f\uff0cfalse: \u5426\uff09", "example": "false"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"field1\": \"field1\",\n    \"field2\": \"field2\",\n    \"field3\": \"field3\",\n    \"field4\": \"field4\",\n    \"field5\": \"field5\",\n    \"containRatio\": 100\n}",
    },
    "realtime.spatial.calculation.center-point": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_center_point_compute",
        "_http": "POST",
        "_summary": "\u5185\u5916\u5fc3\u8ba1\u7b97",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"F001\",\"fence\":\"POLYGON((...))\"}]"},
            {"name": "computeType", "type": "ComputeType", "required": True, "description": "\u8ba1\u7b97\u65b9\u5f0f\u3002\u4e2d\u5fc3\u70b9\u8ba1\u7b97\u65b9\u5f0f\u3002\u53ef\u9009\u503c: 1=\u5185\u5fc3; 2=\u5916\u5fc3", "example": "1"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"F001\",\n            \"fence\": \"POLYGON((...))\"\n        }\n    ]\n}",
    },
    "realtime.spatial.calculation.fence-equalization": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_fence_equalization",
        "_http": "POST",
        "_summary": "\u7247\u533a\u6247\u5f62\u5207\u5206\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"F001\",\"fence\":\"POLYGON((...))\"}]"},
            {"name": "point", "type": "String", "required": True, "description": "\u8d77\u59cb\u7ecf\u7eac\u5ea6\u5b57\u6bb5", "example": "POINT(116.404 39.915)"},
            {"name": "equalNumber", "type": "Integer", "required": True, "description": "\u7b49\u5206\u6570\u91cf", "example": "4"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"F001\",\n            \"fence\": \"POLYGON((...))\"\n        }\n    ],\n    \"point\": \"POINT(116.404 39.915)\",\n    \"equalNumber\": 4\n}",
    },
    "realtime.spatial.calculation.scu-h3": {
        "_controller": "TaskPipelineRealtimeSpatialCalculationController",
        "_method": "realtime_scu_generate_by_h3",
        "_http": "POST",
        "_summary": "SCU-H3\u6807\u51c6\u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\uff0c\u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f\u4e3a WKT \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\",\"potential\":100}]"},
            {"name": "customizeFenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e\uff0c\u7528\u4e8e\u9650\u5236\u751f\u6210\u8303\u56f4", "example": "[{\"code\":\"fence_001\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u914d\u7f6e\u5217\u8868\uff0c\u652f\u6301\u5bf9\u7ed3\u679c\u6570\u636e\u8fdb\u884c\u7edf\u8ba1\u5206\u6790", "example": "[{\"field\":\"potential\",\"type\":\"Sum\",\"alias\":\"totalPotential\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4\uff0c\u6307\u5b9a\u884c\u653f\u533a\u5212\u4ee3\u7801\u5217\u8868\uff0c\u4f8b\u5982\uff1a[[\\", "example": "[[\"340000\"],[\"820000\"],[\"110000\"]]"},
            {"name": "potential", "type": "String", "required": False, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u7684\u5b57\u6bb5\u540d\u79f0\uff0c\u7528\u4e8e\u5212\u5206\u8ba1\u7b97\u7684\u4f9d\u636e", "example": "potential"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": True, "description": "\u751f\u6210\u65b9\u5411\uff1abigToSmall-\u4ece\u5927\u5230\u5c0f\uff0csmallToBig-\u4ece\u5c0f\u5230\u5927\u3002\u5c42\u7ea7\u7f51\u683c\u5206\u88c2/\u5408\u5e76\u751f\u6210\u65b9\u5411\u3002\u53ef\u9009\u503c: bigToSmall=\u4ece\u5927\u5230\u5c0f; smallToBig=\u4ece\u5c0f\u5230\u5927", "example": "bigToSmall"},
            {"name": "splitValue", "type": "Integer", "required": False, "description": "\u5212\u5206\u503c\uff1a\u6bcf\u4e2a\u5355\u5143\u7684\u76ee\u6807\u6f5c\u529b\u503c", "example": "100"},
            {"name": "zoomStart", "type": "Integer", "required": False, "description": "H3 \u5f00\u59cb\u7ea7\u522b\uff1aH3\u7f51\u683c\u7684\u8d77\u59cb\u5c42\u7ea7\uff0c\u8303\u56f40-11\uff0c\u6570\u503c\u8d8a\u5927\u7f51\u683c\u8d8a\u7cbe\u7ec6", "example": "5"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\uff1aprovince-\u7701\u4efd\uff0ccity-\u57ce\u5e02\uff0cdistrict-\u533a\u53bf\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\",\n            \"potential\": 100\n        }\n    ],\n    \"customizeFenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"aggregationFields\": [\n        {\n            \"field\": \"potential\",\n            \"type\": \"Sum\",\n            \"alias\": \"totalPotential\"\n        }\n    ],\n    \"effectiveScope\": [\n        [\n            \"340000\"\n        ],\n        [\n            \"820000\"\n        ],\n        [\n            \"110000\"\n        ]\n    ],\n    \"field\": \"sales\",\n    \"type\": \"Sum\",\n    \"alias\": \"totalSales\"\n}",
    },
    "realtime.model.scu-geohash": {
        "_controller": "TaskPipelineRealtimeModelCalculationController",
        "_method": "realtime_scu_geohash_generate",
        "_http": "POST",
        "_summary": "SCU-GEOHASH��������",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "�����ݣ����� code �� point ��γ���ֶ����ݱ�����ڣ�point ��ʽΪ WKT ��ʽ", "example": "[{\"code\":\"point_001\",\"name\":\"���Ե�\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "customizeFenceData", "type": "List<Map<String, Object>>", "required": True, "description": "�Զ���Χ�����ݣ������������ɷ�Χ", "example": "[{\"code\":\"fence_001\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "�ۺ�ͳ���ֶ������б���֧�ֶԽ�����ݽ���ͳ�Ʒ���", "example": "[{\"field\":\"potential\",\"type\":\"Sum\",\"alias\":\"totalPotential\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "�ۺ��ֶΣ������ݵ��ֶ�", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "�ۺ����͡��ۺϺ������͡���ѡֵ: Avg=ƽ��ֵ; Min=��Сֵ; Max=���ֵ; Sum=���; Count=����", "example": "Sum", "parent": "AggregationField"},
            {"name": "effectiveScope", "type": "List<List<String>>", "required": False, "description": "�Զ�����Ч��Χ��ָ���������������б�", "example": "[[\"340000\"],[\"820000\"],[\"110000\"]]"},
            {"name": "potential", "type": "String", "required": False, "description": "Ǳ���ֶΣ��ʲ������е��ֶ����ƣ����ڻ��ּ��������", "example": "potential"},
            {"name": "generateDirection", "type": "GenerateDirection", "required": True, "description": "���ɷ���bigToSmall-�Ӵ�С��smallToBig-��С����", "example": "bigToSmall"},
            {"name": "splitValue", "type": "Integer", "required": False, "description": "����ֵ��ÿ����Ԫ��Ŀ��Ǳ��ֵ", "example": "100"},
            {"name": "zoomStart", "type": "Integer", "required": False, "description": "GEOHASH ��ʼ���ȵȼ�", "example": "5"},
            {"name": "boundaryLevel", "type": "BoundaryLevel", "required": True, "description": "�߽�ȼ���province-ʡ�ݣ�city-���У�district-����", "example": "city"}
        ],
        "example": "{\n    \"pointData\": [{\"code\": \"point_001\", \"name\": \"���Ե�\", \"point\": \"POINT(116.3 39.9)\", \"potential\": 100}]\n}",
    },
    "realtime.base.point-square": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_point_generate_square",
        "_http": "POST",
        "_summary": "\u70b9\u751f\u6210\u65b9\u5757",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "radius", "type": "Double", "required": True, "description": "\u534a\u5f84\uff08\u7c73\uff09", "example": "1000"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"radius\": 1000\n}",
    },
    "realtime.base.point-circle": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_point_generate_circle",
        "_http": "POST",
        "_summary": "\u70b9\u751f\u6210\u5706\u5f62",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "radius", "type": "Double", "required": True, "description": "\u534a\u5f84\uff08\u7c73\uff09", "example": "1000"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"radius\": 1000\n}",
    },
    "realtime.base.point-hexagon": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_point_generate_hexagon",
        "_http": "POST",
        "_summary": "\u70b9\u751f\u6210\u8702\u7a9d",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "radius", "type": "Double", "required": True, "description": "\u534a\u5f84\uff08\u7c73\uff09", "example": "1000"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"radius\": 1000\n}",
    },
    "realtime.base.point-coord-convert": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_point_coordinate_convert",
        "_http": "POST",
        "_summary": "\u70b9\u5750\u6807\u8f6c\u6362",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "point", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2dcode \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728,point\u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "sourceType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "WGS84"},
            {"name": "targetType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "GCJ02"}
        ],
        "example": "{\n    \"point\": [\n        {\n            \"code\": \"point_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ]\n}",
    },
    "realtime.base.line-coord-convert": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_line_coordinate_convert",
        "_http": "POST",
        "_summary": "\u7ebf\u5750\u6807\u8f6c\u6362",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "line", "type": "List<Map<String, Object>>", "required": True, "description": "\u7ebf\u6570\u636e \u5176\u4e2d code \u548c line \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cline \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"line_001\",\"name\":\"\u6d4b\u8bd5\u7ebf\",\"line\":\"LINESTRING(116.3 39.9, 116.4 40.0)\"}]"},
            {"name": "sourceType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "WGS84"},
            {"name": "targetType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "GCJ02"}
        ],
        "example": "{\n    \"line\": [\n        {\n            \"code\": \"line_001\",\n            \"name\": \"\u6d4b\u8bd5\u7ebf\",\n            \"line\": \"LINESTRING(116.3 39.9, 116.4 40.0)\"\n        }\n    ]\n}",
    },
    "realtime.base.fence-coord-convert": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_fence_coordinate_convert",
        "_http": "POST",
        "_summary": "\u9762\u5750\u6807\u8f6c\u6362",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fence", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "sourceType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "WGS84"},
            {"name": "targetType", "type": "CoordinateType", "required": True, "description": "\u5750\u6807\u7cfb\u7c7b\u578b\u3002\u5750\u6807\u7cfb\u7c7b\u578b\uff0c\u53ef\u9009\u503c: WGS84=WGS84\u5750\u6807\u7cfb; GCJ02=\u56fd\u6d4b\u5c40\u5750\u6807\u7cfb; BD09=\u767e\u5ea6\u5750\u6807\u7cfb", "example": "GCJ02"}
        ],
        "example": "{\n    \"fence\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ]\n}",
    },
    "realtime.base.line-thin": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_line_coordinate_thinning",
        "_http": "POST",
        "_summary": "\u7ebf\u62bd\u7a00",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "line", "type": "List<Map<String, Object>>", "required": True, "description": "\u7ebf\u6570\u636e \u5176\u4e2d code \u548c line \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cline \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"line_001\",\"name\":\"\u6d4b\u8bd5\u7ebf\",\"line\":\"LINESTRING(116.3 39.9, 116.4 40.0)\"}]"},
            {"name": "maxValue", "type": "String", "required": True, "description": "\u62bd\u7a00\u503c\uff08\u7c73\uff09", "example": "maxvalue"}
        ],
        "example": "{\n    \"line\": [\n        {\n            \"code\": \"line_001\",\n            \"name\": \"\u6d4b\u8bd5\u7ebf\",\n            \"line\": \"LINESTRING(116.3 39.9, 116.4 40.0)\"\n        }\n    ],\n    \"maxValue\": 10\n}",
    },
    "realtime.base.fence-thin": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_fence_coordinate_thinning",
        "_http": "POST",
        "_summary": "\u9762\u62bd\u7a00",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fence", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "maxValue", "type": "String", "required": True, "description": "\u62bd\u7a00\u503c\uff08\u7c73\uff09", "example": "maxvalue"}
        ],
        "example": "{\n    \"fence\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u533a\u57dfA\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"maxValue\": 10\n}",
    },
    "realtime.base.point-rarefy": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_point_rarefy",
        "_http": "POST",
        "_summary": "\u70b9\u62bd\u7a00\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": False, "description": "", "example": "[{\"code\": \"P001\", \"point\": \"POINT(116.404 39.915)\"}, {\"code\": \"P002\", \"point\": \"POINT(116.405 39.916)\"}]"},
            {"name": "dilutionLevel", "type": "Integer", "required": False, "description": ""}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"P001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        },\n        {\n            \"code\": \"P002\",\n            \"point\": \"POINT(116.405 39.916)\"\n        }\n    ]\n}",
    },
    "realtime.base.fence-boundary": {
        "_controller": "TaskPipelineRealtimeBaseServiceController",
        "_method": "realtime_fence_boundary",
        "_http": "POST",
        "_summary": "\u591a\u8fb9\u5f62\u8f6c\u7ebf\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": False, "description": "", "example": "[{\"code\": \"F001\", \"fence\": \"POLYGON((116.404 39.915, 116.405 39.915, 116.405 39.916, 116.404 39.916, 116.404 39.915))\"}]"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"F001\",\n            \"fence\": \"POLYGON((116.404 39.915, 116.405 39.915, 116.405 39.916, 116.404 39.916, 116.404 39.915))\"\n        }\n    ]\n}",
    },
    "realtime.resource.realtime-route-replay": {
        "_controller": "TaskPipelineRealtimeResourcePlanningController",
        "_method": "realtime_route_replay",
        "_http": "POST",
        "_summary": "\u7269\u6d41 - \u7ebf\u8def\u91cd\u6392 (\u5b9e\u65f6)",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u5b57\u6bb5\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f\u4e3a WKT \u683c\u5f0f", "example": "[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "groupId", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e00", "example": "route_group"},
            {"name": "round", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e8c", "example": "round_1"},
            {"name": "startLocation", "type": "String", "required": True, "description": "\u8d77\u59cb\u4f4d\u7f6e", "example": "POINT(116.404 39.915)"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"groupId\": \"route_group\",\n    \"round\": \"round_1\",\n    \"startLocation\": \"POINT(116.404 39.915)\"\n}",
    },
    "realtime.resource.realtime-service-day-week-division": {
        "_controller": "TaskPipelineRealtimeResourcePlanningController",
        "_method": "realtime_service_day_week_division",
        "_http": "POST",
        "_summary": "服务日-周划分 (实时)",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u4fe1\u606f", "example": "{\"data\":[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}],\"salesCode\":\"salesCode\",\"visitCycle\":\"visitCycle\",\"visitNum\":\"visitNum\",\"codeField\":\"code\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "salesData", "type": "SalesData", "required": True, "description": "\u9500\u552e\u4fe1\u606f", "example": "{\"data\":[{\"code\":\"S001\",\"point\":\"POINT(116.404 39.915)\"}],\"codeField\":\"code\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "sales_asset_001", "parent": "SalesData"},
            {"name": "code", "type": "String (inner)", "required": True, "description": "\u9500\u552e\u7f16\u7801\uff08\u9500\u552e\u4fe1\u606f - \u9500\u552e\u7f16\u7801\uff09", "example": "S001", "parent": "SalesData"},
            {"name": "maxDistance", "type": "String (inner)", "required": True, "description": "\u6700\u5927\u552e\u70b9\u8ddd\u79bb\uff0c\u5355\u4f4d\uff1akm", "example": "maxdistance", "parent": "SalesData"},
            {"name": "maxVisitNum", "type": "String (inner)", "required": False, "description": "\u6bcf\u65e5\u6700\u5927\u670d\u52a1\u5ba2\u6237\u6570", "example": "maxvisitnum", "parent": "SalesData"},
            {"name": "minVisitNum", "type": "String (inner)", "required": False, "description": "\u6bcf\u65e5\u6700\u5c0f\u670d\u52a1\u5ba2\u6237\u6570", "example": "minvisitnum", "parent": "SalesData"},
            {"name": "historyData", "type": "HistoryData", "required": True, "description": "\u5386\u53f2\u62dc\u8bbf\u6570\u636e", "example": "{\"data\":[{\"customerCode\":\"C001\",\"visitDate\":\"2024-01-01\",\"salesCode\":\"S001\"}],\"propertyCodeField\":\"propertyCode\",\"customerCodeField\":\"customerCode\",\"visitDateField\":\"visitDate\",\"salesCodeField\":\"salesCode\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u8d44\u4ea7\u7f16\u7801", "example": "history_001", "parent": "HistoryData"},
            {"name": "customerCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u7f16\u7801\uff08\u5386\u53f2\u62dc\u8bbf\u6570\u636e\uff09", "example": "cust_001", "parent": "HistoryData"},
            {"name": "visitDate", "type": "String (inner)", "required": True, "description": "\u5b9e\u9645\u62dc\u8bbf\u65e5\u671f\uff08\u5386\u53f2\u62dc\u8bbf\u6570\u636e\uff09", "example": "2026-04-01", "parent": "HistoryData"},
            {"name": "salesCode", "type": "String (inner)", "required": True, "description": "\u9500\u552e\u7f16\u7801\uff08\u5386\u53f2\u62dc\u8bbf\u6570\u636e\uff09", "example": "salesCode", "parent": "HistoryData"},
            {"name": "scuData", "type": "List<Map<String, Object>>", "required": False, "description": "\u56f4\u680f\u6570\u636e\uff0c\u5305\u542b\u8d44\u4ea7\u7f16\u7801\u53ca\u7ecf\u7eac\u5ea6\u7b49\u4fe1\u606f\u7684\u5217\u8868", "example": "[{\"code\":\"SCU001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "divideType", "type": "DivideType", "required": True, "description": "\u5212\u5206\u7c7b\u578b\u3002\u65f6\u95f4\u5212\u5206\u7c92\u5ea6\u3002\u53ef\u9009\u503c: week=\u5468; day=\u65e5", "example": "week"},
            {"name": "balanceField", "type": "String", "required": True, "description": "\u5747\u8861\u5b57\u6bb5\uff08\u5ba2\u8d44\u4fe1\u606f - \u7528\u4e8e\u5747\u8861\u5206\u914d\u5ba2\u6237\uff09", "example": "potentialValue"},
            {"name": "group1", "type": "String", "required": True, "description": "\u62dc\u8bbf\u5468\uff08divideType \u4e3a week \u65f6\u5fc5\u586b\uff0c\u5ba2\u6237\u4fe1\u606f - \u670d\u52a1\u65e5\u3001\u670d\u52a1\u5468\u5212\u5206\u6807\u8bc6\uff0c\u5982\u679c\u7b2c\u4e8c\u6b21\u89c4\u5212\u60f3\u57fa\u4e8e\u7b2c\u4e00\u6b21\u7684\u57fa\u7840\u8fdb\u884c\u5219\u9700\u8981\u9009\u62e9\uff09", "example": "route_group1"},
            {"name": "group2", "type": "String", "required": False, "description": "\u62dc\u8bbf\u65e5", "example": "route_group2"},
            {"name": "workDay", "type": "String", "required": False, "description": "\u5de5\u4f5c\u65e5\uff08divideType \u4e3a day \u65f6\u5fc5\u586b\uff09", "example": "1,2,3,4,5"},
            {"name": "startEndDate", "type": "List<String>", "required": True, "description": "\u5f00\u59cb\u7ed3\u675f\u65e5\u671f\u5217\u8868", "example": "[\"2024-01-01\",\"2024-01-31\"]"}
        ],
        "example": "{\n    \"customerData\": {\n        \"data\": [\n            {\n                \"code\": \"001\",\n                \"point\": \"POINT(116.404 39.915)\"\n            }\n        ],\n        \"salesCode\": \"salesCode\",\n        \"visitCycle\": \"visitCycle\",\n        \"visitNum\": \"visitNum\",\n        \"codeField\": \"code\"\n    },\n    \"salesData\": {\n        \"data\": [\n            {\n                \"code\": \"S001\",\n                \"point\": \"POINT(116.404 39.915)\"\n            }\n        ],\n        \"codeField\": \"code\"\n    },\n    \"historyData\": {\n        \"data\": [\n            {\n                \"customerCode\": \"C001\",\n                \"visitDate\": \"2024-01-01\",\n                \"salesCode\": \"S001\"\n            }\n        ],\n        \"propertyCodeField\": \"propertyCode\",\n        \"customerCodeField\": \"customerCode\",\n        \"visitDateField\": \"visitDate\",\n        \"salesCodeField\": \"salesCode\"\n    },\n    \"scuData\": [\n        {\n            \"code\": \"SCU001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"balanceField\": \"potentialValue\",\n    \"group1\": \"W1\",\n    \"group2\": \"D1\",\n    \"workDay\": \"1,2,3,4,5\",\n    \"startEndDate\": [\n        \"2024-01-01\",\n        \"2024-01-31\"\n    ],\n    \"data\": [\n        {\n            \"code\": \"S001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"salesCode\": \"salesCode\",\n    \"visitCycle\": \"visitCycle\",\n    \"visitNum\": \"visitNum\",\n    \"codeField\": \"code\",\n    \"propertyCodeField\": \"propertyCode\",\n    \"customerCodeField\": \"customerCode\",\n    \"visitDateField\": \"visitDate\",\n    \"salesCodeField\": \"salesCode\",\n    \"maxDistanceField\": \"maxDistance\",\n    \"maxVisitNumField\": \"maxVisitNum\",\n    \"minVisitNumField\": \"minVisitNum\"\n}",
    },
    "realtime.resource.realtime-service-route-planning": {
        "_controller": "TaskPipelineRealtimeResourcePlanningController",
        "_method": "realtime_service_route_planning",
        "_http": "POST",
        "_summary": "线路排序规划 (实时)",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "customerData", "type": "List<Map<String, Object>>", "required": True, "description": "\u5ba2\u8d44\u4fe1\u606f", "example": "[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "salesData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9500\u552e\u4fe1\u606f", "example": "[{\"code\":\"S001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "group1", "type": "String", "required": True, "description": "\u62dc\u8bbf\u5468", "example": "route_group1"},
            {"name": "group2", "type": "String", "required": True, "description": "\u62dc\u8bbf\u65e5", "example": "route_group2"},
            {"name": "startEndDate", "type": "List<String>", "required": True, "description": "\u5f00\u59cb\u7ed3\u675f\u65f6\u95f4\u6bb5\uff0c\u683c\u5f0f\uff1ayyyy-MM-dd HH:mm:ss", "example": "[\"2024-01-01 08:00:00\",\"2024-01-01 18:00:00\"]"},
            {"name": "salesCodeField", "type": "String", "required": True, "description": "\u9500\u552e\u7f16\u7801\u5b57\u6bb5\u540d", "example": "salesCode"},
            {"name": "isFirstOrderField", "type": "String", "required": True, "description": "\u662f\u5426\u7b2c\u4e00\u5bb6\u5e97\u5b57\u6bb5\u540d", "example": "isFirstOrder"},
            {"name": "visitDurationField", "type": "String", "required": False, "description": "\u670d\u52a1\u65f6\u957f\u5b57\u6bb5\u540d", "example": "visitDuration"},
            {"name": "visitOrderField", "type": "String", "required": False, "description": "\u62dc\u8bbf\u987a\u5e8f\u5b57\u6bb5\u540d", "example": "visitOrder"},
            {"name": "customerCodeField", "type": "String", "required": True, "description": "\u5ba2\u8d44\u7f16\u7801\u5b57\u6bb5\u540d", "example": "code"},
            {"name": "visitCycleField", "type": "String", "required": True, "description": "\u670d\u52a1\u5468\u671f\u5b57\u6bb5\u540d", "example": "visitCycle"},
            {"name": "visitNumField", "type": "String", "required": True, "description": "\u670d\u52a1\u6b21\u6570\u5b57\u6bb5\u540d", "example": "visitNum"},
            {"name": "startTimeField", "type": "String", "required": True, "description": "\u5f00\u59cb\u65f6\u95f4\u5b57\u6bb5\u540d", "example": "startTime"},
            {"name": "endTimeField", "type": "String", "required": False, "description": "\u7ed3\u675f\u65f6\u95f4\u5b57\u6bb5\u540d", "example": "endTime"},
            {"name": "salesDataCodeField", "type": "String", "required": True, "description": "\u9500\u552e\u7f16\u7801\u5b57\u6bb5\u540d(\u9500\u552e\u6570\u636e)", "example": "code"},
            {"name": "salesStartTimeField", "type": "String", "required": True, "description": "\u4e0a\u73ed\u65f6\u95f4\u5b57\u6bb5\u540d", "example": "startTime"},
            {"name": "salesEndTimeField", "type": "String", "required": False, "description": "\u4e0b\u73ed\u65f6\u95f4\u5b57\u6bb5\u540d", "example": "endTime"},
            {"name": "officeWaitTimeField", "type": "String", "required": False, "description": "\u529e\u516c\u5ba4\u7b49\u5f85\u65f6\u957f\u5b57\u6bb5\u540d", "example": "officeWaitTime"},
            {"name": "startingPointField", "type": "String", "required": False, "description": "\u51fa\u53d1\u5730\u70b9\u5b57\u6bb5\u540d", "example": "startingPoint"},
            {"name": "amEndTimeField", "type": "String", "required": False, "description": "\u5348\u996d\u6700\u65e9\u5f00\u59cb\u65f6\u95f4\u5b57\u6bb5\u540d", "example": "amEndTime"},
            {"name": "pmStartTimeField", "type": "String", "required": False, "description": "\u5348\u996d\u6700\u665a\u7ed3\u675f\u65f6\u95f4\u5b57\u6bb5\u540d", "example": "pmStartTime"},
            {"name": "travelMode", "type": "String", "required": True, "description": "\u51fa\u884c\u65b9\u5f0f", "example": "driving"},
            {"name": "travelSpeed", "type": "Integer", "required": True, "description": "\u51fa\u884c\u901f\u5ea6", "example": "60"},
            {"name": "officePoint", "type": "String", "required": False, "description": "\u529e\u516c\u5ba4\u5750\u6807", "example": "POINT(116.404 39.915)"},
            {"name": "holidayStr", "type": "String", "required": False, "description": "\u8282\u5047\u65e5\uff0c\u683c\u5f0f\uff1ayyyy-MM-dd,yyyy-MM-dd", "example": "2024-01-01,2024-01-02"}
        ],
        "example": "{\n    \"customerData\": [\n        {\n            \"code\": \"001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"salesData\": [\n        {\n            \"code\": \"S001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"group1\": \"W1\",\n    \"group2\": \"D1\",\n    \"startEndDate\": [\n        \"2024-01-01 08:00:00\",\n        \"2024-01-01 18:00:00\"\n    ],\n    \"salesCodeField\": \"salesCode\",\n    \"isFirstOrderField\": \"isFirstOrder\",\n    \"visitDurationField\": \"visitDuration\",\n    \"visitOrderField\": \"visitOrder\",\n    \"customerCodeField\": \"code\",\n    \"visitCycleField\": \"visitCycle\",\n    \"visitNumField\": \"visitNum\",\n    \"startTimeField\": \"startTime\",\n    \"endTimeField\": \"endTime\",\n    \"salesDataCodeField\": \"code\",\n    \"salesStartTimeField\": \"startTime\",\n    \"salesEndTimeField\": \"endTime\",\n    \"officeWaitTimeField\": \"officeWaitTime\",\n    \"startingPointField\": \"startingPoint\",\n    \"amEndTimeField\": \"amEndTime\",\n    \"pmStartTimeField\": \"pmStartTime\",\n    \"travelMode\": \"driving\",\n    \"travelSpeed\": 60,\n    \"officePoint\": \"POINT(116.404 39.915)\",\n    \"holidayStr\": \"2024-01-01,2024-01-02\"\n}",
    },
    "realtime.resource.realtime-logistics-route-planning": {
        "_controller": "TaskPipelineRealtimeResourcePlanningController",
        "_method": "realtime_logistics_route_planning",
        "_http": "POST",
        "_summary": "\u7269\u6d41-\u8def\u5f84\u89c4\u5212 (\u5b9e\u65f6)",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code\u3001point\uff08\u7ecf\u7eac\u5ea6\uff09\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "group1", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e00", "example": "group_field_1"},
            {"name": "group2", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e8c", "example": "group_field_2"},
            {"name": "group3", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e09", "example": "group_field_3"},
            {"name": "group4", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\u56db", "example": "group_field_4"},
            {"name": "group5", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\u4e94", "example": "group_field_5"},
            {"name": "arrivalOrder", "type": "String", "required": True, "description": "\u5230\u8fbe\u987a\u5e8f \u6570\u5b57\u7c7b\u578b\u7684\u503c", "example": "order"},
            {"name": "startLocation", "type": "String", "required": False, "description": "\u8d77\u59cb\u4f4d\u7f6e", "example": "start"},
            {"name": "trackType", "type": "TrackType", "required": True, "description": "���з�ʽ�����ɷ�ʽ����ѡֵ: bicycling=����; driving=�ݳ�; straightLine=ֱ��; walking=����", "example": "driving"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"field\":\"salesAmount\",\"aggregationType\":\"Count\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"group1\": \"group_field_1\",\n    \"group2\": \"group_field_2\",\n    \"group3\": \"group_field_3\",\n    \"group4\": \"group_field_4\",\n    \"group5\": \"group_field_5\",\n    \"arrivalOrder\": \"order\",\n    \"startLocation\": \"start\",\n    \"trackType\": \"driving\",\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"aggregationType\": \"Count\"\n        }\n    ]\n}",
    },
    "realtime.operation.text-handling": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_text_handling",
        "_http": "POST",
        "_summary": "\u6587\u672c\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "textData", "type": "TextData", "required": True, "description": "\u5904\u7406\u6570\u636e", "example": "[{\"code\":\"text_001\",\"text\":\"\u6d4b\u8bd5\u6587\u672c\u5185\u5bb9\"}]"},
            {"name": "data", "type": "List<Map<String, Object>> (inner)", "required": True, "description": "\u6587\u672c\u6570\u636e\u5217\u8868 code \u5fc5\u987b\u8981\u6709\u503c", "example": "[{\"code\": \"001\", \"address\": \"\u6d4b\u8bd5\u5730\u5740\"}]", "parent": "TextData"},
            {"name": "textStr", "type": "String (inner)", "required": True, "description": "\u5f85\u5904\u7406\u7684\u5b57\u6bb5\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "example": "address", "parent": "TextData"},
            {"name": "textHandlingStrategy", "type": "List<TextHandlingStrategy>", "required": True, "description": "\u5904\u7406\u7684\u7b56\u7565"},
            {"name": "policyCode", "type": "PolicyCode (inner)", "required": True, "description": "\u5904\u7406\u7b56\u7565\u53d6\u503c\u679a\u4e3e\uff08\u8f93\u5165\u6c49\u5b57\u65f6\u9700\u6839\u636e\u6c49\u5b57\u5185\u5bb9\u6620\u5c04\u4e3a\u7f16\u7801\uff09\u3002\u53ef\u9009\u503c: 10001=\u5254\u9664-\u62ec\u53f7\u5185\u5bb9; 10002=\u63d0\u53d6-\u62ec\u53f7\u5185\u5bb9; 10003=\u63d0\u53d6-\u8fde\u7eed\u6570\u5b57; 10004=\u5254\u9664-\u8fde\u7eed\u6570\u5b57; 10005=\u63d0\u53d6-\u8fde\u7eed\u6570\u5b57\u5b57\u6bcd; 10006=\u5254\u9664-\u8fde\u7eed\u6570\u5b57\u5b57\u6bcd; 10010=\u5254\u9664-\u7279\u6b8a\u5b57\u7b26-\u5168\u6587; 10013=\u5254\u9664-\u524d\u7f00; 10014=\u5254\u9664-\u540e\u7f00; 10017=\u5305\u542b-\u524d\u7f00; 10018=\u5305\u542b-\u540e\u7f00; 10019=\u901a\u914d\u7b26-\u63d0\u53d6\u5185\u5bb9; 10021=\u63d0\u53d6-\u8fde\u7eed\u5b57\u6bcd; 10022=\u5254\u9664-\u8fde\u7eed\u5b57\u6bcd; 10025=\u63d0\u53d6-\u591a\u8fde\u7eed\u6570\u5b57; 10026=\u63d0\u53d6-\u591a\u8fde\u7eed\u6570\u5b57\u5b57\u6bcd; 10027=\u63d0\u53d6-\u591a\u8fde\u7eed\u5b57\u6bcd; 10029=\u5254\u9664-\u7a7a\u683c", "parent": "TextHandlingStrategy"},
            {"name": "policyConfig", "type": "String (inner)", "required": True, "description": "\u5904\u7406\u65b9\u5f0f\uff1a\u6ca1\u6709\u5219\u8f93\u5165 '\u65e0'; \u63d0\u53d6\u3001\u5254\u9664\u8fde\u7eed\u6570\u5b57\u7c7b\u8f93\u5165\uff1a>X (X\u662f\u5927\u4e8e0\u7684\u6570\u5b57)\uff0c\u5254\u9664\u7279\u6b8a\u5b57\u7b26\u8f93\u5165\u8981\u5254\u9664\u7684\u7279\u6b8a\u5b57\u7b26\uff1a\u4f8b\u5982 $%(\uff08,#,*\uff09) \u7b49\uff0c\u7528\u82f1\u6587\u9017\u53f7\u9694\u5f00\u3002", "parent": "TextHandlingStrategy"}
        ],
        "example": "{\n    \"textData\": {\n        \"data\": [\n            {\n                \"code\": \"001\",\n                \"address\": \"\u5317\u4eac\u5e02\u671d\u9633\u533aXX\u8def\"\n            }\n        ],\n        \"textStr\": \"address\"\n    },\n    \"textHandlingStrategy\": [\n        {\n            \"policyCode\": \"10002\",\n            \"policyConfig\": \"\u65e0\"\n        }\n    ]\n}",
    },
    "realtime.operation.exact-match": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_exact_match",
        "_http": "POST",
        "_summary": "\u5b8c\u5168\u5339\u914d",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u6570\u636e", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5ba2\u8d44\u8d44\u4ea7\u7f16\u7801", "example": "customer_001", "parent": "CustomerData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5ba2\u8d44\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "address", "parent": "CustomerData"},
            {"name": "txData", "type": "TxData", "required": True, "description": "\u817e\u8baf\u6570\u636e", "example": "{\"data\":[{\"code\":\"tx_001\",\"name\":\"\u817e\u8baf\u76ee\u6807\"}],\"textStr1\":\"name\",\"textStr2\":\"address\"}"},
            {"name": "propertyCode", "type": "String (inner)", "required": True, "description": "\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u7f16\u7801", "example": "tx_001", "parent": "TxData"},
            {"name": "textStr1", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb51\uff1a\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "poi_name", "parent": "TxData"},
            {"name": "textStr2", "type": "String (inner)", "required": True, "description": "\u6587\u672c\u5b57\u6bb52\uff1a\u5bf9\u6bd4\u6570\u636e\u8d44\u4ea7\u5b57\u6bb5", "example": "address", "parent": "TxData"}
        ],
        "example": "{\n    \"customerData\": {\n        \"data\": [\n            {\n                \"code\": \"001\",\n                \"name\": \"XX\u95e8\u5e97\"\n            }\n        ],\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"txData\": {\n        \"data\": [\n            {\n                \"code\": \"tx_001\",\n                \"name\": \"\u817e\u8baf\u76ee\u6807\"\n            }\n        ],\n        \"textStr1\": \"name\",\n        \"textStr2\": \"address\"\n    },\n    \"data\": [\n        {\n            \"code\": \"tx_001\",\n            \"name\": \"\u817e\u8baf\u76ee\u6807\"\n        }\n    ],\n    \"textStr1\": \"name\",\n    \"textStr2\": \"address\"\n}",
    },
    "realtime.operation.similarity": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_similarity_processing",
        "_http": "POST",
        "_summary": "\u76f8\u4f3c\u5ea6\u5904\u7406\u8bf7\u6c42\u7c7b",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u6570\u636e", "example": "{\"data\": [{\"code\": \"001\", \"name\": \"�ŵ�\"}], \"name\": \"name\"}"},
            {"name": "data", "type": "List<Map<String, Object>> (inner)", "required": True, "description": "\u5ba2\u8d44\u6570\u636e\uff0c\u5176\u4e2dcode\u5fc5\u987b\u5b58\u5728\uff0c\u5982\u679c\u9009\u4e86\u89c4\u5219\u7ecf\u7eac\u5ea6point\u9700\u8981\u4f20point\u4e3awkt\u683c\u5f0f", "example": "[{\"code\": \"001\", \"name\": \"�ŵ�\", \"point\": \"POINT(116.3 39.9)\"}]", "parent": "CustomerData"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0\uff1a\u5ba2\u8d44\u6570\u636e\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "txData", "type": "TxData", "required": True, "description": "\u76ee\u6807\u6570\u636e", "example": "{\"data\": [{\"code\": \"tx_001\", \"name\": \"��ѶĿ��\"}], \"name\": \"name\"}"},
            {"name": "data", "type": "List<Map<String, Object>> (inner)", "required": True, "description": "\u76ee\u6807\u6570\u636e\uff0c\u5176\u4e2dcode\u5fc5\u987b\u5b58\u5728\uff0c\u5982\u679c\u9009\u4e86\u89c4\u5219\u7ecf\u7eac\u5ea6point\u9700\u8981\u4f20point\u4e3awkt\u683c\u5f0f", "example": "[{\"code\": \"tx_001\", \"name\": \"��ѶĿ��\", \"point\": \"POINT(116.4 39.9)\"}]", "parent": "TxData"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0\uff1a\u76ee\u6807\u6570\u636e\u8d44\u4ea7\u7684\u5b57\u6bb5", "example": "name", "parent": "TxData"},
            {"name": "policyCode", "type": "PolicyCode", "required": True, "description": "\u76f8\u4f3c\u5ea6\u65b9\u5f0f\u3002\u5904\u7406\u65b9\u5f0f\u3002\u53ef\u9009\u503c: 30010=\u901a\u7528; 30009=\u8fde\u7eed", "example": "30010"},
            {"name": "similarity", "type": "Double", "required": True, "description": "\u76f8\u4f3c\u5ea6 \u6570\u503c\u7c7b\u578b\uff0c\u503c 0~1 \u6700\u5927\u503c\u4e0d\u80fd\u8d85\u8fc7 1", "example": "0.8"},
            {"name": "isLng", "type": "Boolean", "required": True, "description": "\u662f\u5426\u5f00\u542f\u7ecf\u7eac\u5ea6\uff0c\u5f00\u542f\u7ecf\u7eac\u5ea6\u540e\uff0c\u9700\u8981\u586b\u5199\u6b65\u957f\u548c\u8ddd\u79bb\u3002\u9ed8\u8ba4false", "example": "false"},
            {"name": "step", "type": "Integer", "required": False, "description": "\u6b65\u957f \u5355\u4f4d:(\u7c73); isLng\u662ftrue\u65f6\u5fc5\u586b \u6570\u503c\u7c7b\u578b", "example": "100"},
            {"name": "distance", "type": "Double", "required": False, "description": "\u8ddd\u79bb \u5355\u4f4d:(\u7c73); isLng\u662ftrue\u65f6\u5fc5\u586b \u6570\u503c\u7c7b\u578b", "example": "500.0"}
        ],
        "example": "{\n    \"customerData\": {\n        \"data\": [\n            {\n                \"code\": \"001\",\n                \"name\": \"XX�ŵ�\",\n                \"point\": \"POINT(116.3 39.9)\"\n            }\n        ],\n        \"name\": \"name\"\n    },\n    \"txData\": {\n        \"data\": [\n            {\n                \"code\": \"tx_001\",\n                \"name\": \"��ѶĿ��\",\n                \"point\": \"POINT(116.4 39.9)\"\n            }\n        ],\n        \"name\": \"name\"\n    },\n    \"policyCode\": \"30010\",\n    \"similarity\": 0.8,\n    \"isLng\": true,\n    \"step\": 100,\n    \"distance\": 500.0\n}",
    },
    "realtime.operation.ka-match": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_ka_match_handling_v2",
        "_http": "POST",
        "_summary": "ka\u5339\u914d\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "\u5ba2\u8d44\u6570\u636e", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}],\"name\":\"name\"}"},
            {"name": "data", "type": "List<Map<String, Object>> (inner)", "required": True, "description": "\u5ba2\u8d44\u6570\u636e\u5217\u8868", "example": "[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\"}]", "parent": "CustomerData"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0\uff1a\u5ba2\u8d44\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "example": "name", "parent": "CustomerData"},
            {"name": "kaData", "type": "KaData", "required": True, "description": "KA \u6570\u636e", "example": "{\"data\":[{\"code\":\"K001\",\"keyword\":\"\u80af\u5fb7\u57fa\",\"trademarkName\":\"KFC\"}],\"keyword\":\"keyword\",\"trademarkName\":\"trademarkName\",\"screen\":\"\u5c4f\u853d\u8bcd\"}"},
            {"name": "data", "type": "List<Map<String, Object>> (inner)", "required": True, "description": "KA\u6570\u636e\u5217\u8868", "example": "[{\"code\":\"K001\",\"keyword\":\"\u80af\u5fb7\u57fa\",\"trademarkName\":\"KFC\"}]", "parent": "KaData"},
            {"name": "keyword", "type": "String (inner)", "required": True, "description": "\u5173\u952e\u8bcd\uff1aKA\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "example": "keyword", "parent": "KaData"},
            {"name": "trademarkName", "type": "String (inner)", "required": True, "description": "\u54c1\u724c\u540d\uff1aKA\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "example": "trademarkName", "parent": "KaData"},
            {"name": "screen", "type": "String (inner)", "required": False, "description": "\u5c4f\u853d\u8bcd\uff1aKA\u6570\u636e\u4e2d\u7684\u5b57\u6bb5\uff0c\u591a\u4e2a\u7528\u9017\u53f7\u9694\u5f00", "example": "\u5c4f\u853d\u8bcd1,\u5c4f\u853d\u8bcd2", "parent": "KaData"}
        ],
        "example": "{\n    \"customerData\": {\n        \"data\": [{\"code\": \"001\", \"name\": \"XX\u95e8\u5e97\"}],\n        \"name\": \"name\"\n    },\n    \"kaData\": {\n        \"data\": [{\"code\": \"K001\", \"keyword\": \"\u80af\u5fb7\u57fa\", \"trademarkName\": \"KFC\"}],\n        \"keyword\": \"keyword\",\n        \"trademarkName\": \"trademarkName\",\n        \"screen\": \"\u5c4f\u853d\u8bcd\"\n    }\n}",
    },
    "realtime.operation.duplicate-mark": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_duplicate_mark",
        "_http": "POST",
        "_summary": "\u91cd\u590d\u6807\u8bb0\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "groupData", "type": "List<Map<String, Object>>", "required": True, "description": "\u5206\u7ec4\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"data_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "groupField1", "type": "String", "required": True, "description": "\u5206\u7ec4\u5b57\u6bb5 1", "example": "field1"},
            {"name": "groupField2", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 2", "example": "field2"},
            {"name": "groupField3", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 3", "example": "field3"},
            {"name": "groupField4", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 4", "example": "field4"},
            {"name": "groupField5", "type": "String", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5 5", "example": "field5"}
        ],
        "example": "{\n    \"groupData\": [\n        {\n            \"code\": \"data_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"groupField1\": \"field1\",\n    \"groupField2\": \"field2\",\n    \"groupField3\": \"field3\",\n    \"groupField4\": \"field4\",\n    \"groupField5\": \"field5\"\n}",
    },
    "realtime.operation.text-concat": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_text_concat",
        "_http": "POST",
        "_summary": "\u6587\u672c\u62fc\u63a5\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "textData", "type": "List<Map<String, Object>>", "required": True, "description": "\u6587\u672c\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "concatFields", "type": "List<String>", "required": True, "description": "\u62fc\u63a5\u5b57\u6bb5\uff1a\u591a\u9009\uff0c\u4f8b\u5982['\u7701','\u5e02','\u533a','\u5730\u5740']", "example": "[\"province\",\"city\",\"district\",\"address\"]"}
        ],
        "example": "{\n    \"textData\": [\n        {\n            \"code\": \"001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"concatFields\": [\n        \"province\",\n        \"city\",\n        \"district\",\n        \"address\"\n    ]\n}",
    },
    "realtime.operation.subsection-mark": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_subsection_mark",
        "_http": "POST",
        "_summary": "\u5206\u6bb5\u6807\u8bb0\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "data", "type": "List<Map<String, Object>>", "required": True, "description": "\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u5b57\u6bb5\u5fc5\u987b\u5b58\u5728", "example": "[{\"code\":\"001\",\"field1\":\"value1\"}]"},
            {"name": "subsectionGroupFields", "type": "List<String>", "required": True, "description": "\u5206\u6bb5\u5206\u7ec4\u5b57\u6bb5\u6570\u7ec4", "example": "[\"group1\"]"},
            {"name": "param", "type": "List<SubsectionCondition>", "required": True, "description": "\u5206\u6bb5\u6761\u4ef6\u5217\u8868", "example": "[{\"subsectionFields\":[\"field1\"],\"subsectionType\":\"1\",\"operType\":\"1\",\"compareValue\":100,\"markValue\":\"A\"}]"},
            {"name": "subsectionFields", "type": "List<String> (inner)", "required": True, "description": "\u5206\u6bb5\u5b57\u6bb5\u6570\u7ec4", "example": "[\"field1\",\"field2\"]", "parent": "SubsectionCondition"},
            {"name": "subsectionType", "type": "SubsectionType (inner)", "required": True, "description": "\u5206\u6bb5\u7c7b\u578b\uff1a1-\u5360\u6bd4\uff0c2-\u6570\u503c\u3002\u5206\u6bb5\u6807\u8bb0\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u5360\u6bd4; 2=\u6570\u503c", "parent": "SubsectionCondition"},
            {"name": "operType", "type": "OperType (inner)", "required": True, "description": "\u64cd\u4f5c\u7c7b\u578b\uff1a1-\u7b49\u4e8e\uff0c2-\u4e0d\u7b49\u4e8e\uff0c3-\u5927\u4e8e\uff0c4-\u5927\u4e8e\u7b49\u4e8e\uff0c5-\u5c0f\u4e8e\uff0c6-\u5c0f\u4e8e\u7b49\u4e8e\uff0c7-\u6700\u5927\u503c\uff0c8-\u6700\u5c0f\u503c\u3002\u5206\u6bb5\u6bd4\u8f83\u64cd\u4f5c\u7b26\u3002\u53ef\u9009\u503c: 1=\u7b49\u4e8e; 2=\u4e0d\u7b49\u4e8e; 3=\u5927\u4e8e; 4=\u5927\u4e8e\u7b49\u4e8e; 5=\u5c0f\u4e8e; 6=\u5c0f\u4e8e\u7b49\u4e8e; 7=\u6700\u5927\u503c; 8=\u6700\u5c0f\u503c", "parent": "SubsectionCondition"},
            {"name": "compareValue", "type": "Integer (inner)", "required": False, "description": "\u6bd4\u8f83\u503c", "example": "100", "parent": "SubsectionCondition"},
            {"name": "groupField", "type": "String (inner)", "required": False, "description": "\u5206\u7ec4\u5b57\u6bb5\uff08\u64cd\u4f5c\u7c7b\u578b\u4e3a 7 \u6216 8 \u65f6\u5fc5\u586b\uff09", "example": "groupField", "parent": "SubsectionCondition"},
            {"name": "markValue", "type": "String (inner)", "required": True, "description": "\u6807\u8bb0\u503c", "example": "high_value", "parent": "SubsectionCondition"}
        ],
        "example": "{\n    \"data\": [\n        {\n            \"code\": \"001\",\n            \"field1\": \"value1\"\n        }\n    ],\n    \"subsectionGroupFields\": [\n        \"group1\"\n    ],\n    \"param\": [\n        {\n            \"subsectionFields\": [\n                \"field1\"\n            ],\n            \"subsectionType\": \"1\",\n            \"operType\": \"1\",\n            \"compareValue\": 100,\n            \"markValue\": \"A\"\n        }\n    ],\n    \"subsectionFields\": [\n        \"field1\",\n        \"field2\"\n    ],\n    \"compareValue\": 100,\n    \"groupField\": \"groupField\",\n    \"markValue\": \"A\"\n}",
    },
    "realtime.operation.normalized-expr": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_normalized_expr",
        "_http": "POST",
        "_summary": "\u5f52\u4e00\u503c\u8ba1\u7b97\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "normalizedData", "type": "List<Map<String, Object>>", "required": True, "description": "\u5f52\u4e00\u6570\u636e\u5217\u8868\uff0c\u5305\u542b\u9700\u8981\u8ba1\u7b97\u7684\u6570\u636e(\u5fc5\u987b\u5305\u542bcode\u5b57\u6bb5)", "example": "[{\"code\":\"001\",\"salesAmount\":1000},{\"code\":\"002\",\"salesAmount\":1500}]"},
            {"name": "normalizedExpr", "type": "String", "required": True, "description": "\u5f52\u4e00\u503c\u8ba1\u7b97\u8868\u8fbe\u5f0f", "example": "(a + b) / c"},
            {"name": "compute", "type": "List<ComputeField>", "required": False, "description": "\u8ba1\u7b97\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"computeFiled\":\"salesAmount\",\"aliasName\":\"a\"}]"},
            {"name": "computeFiled", "type": "String (inner)", "required": True, "description": "\u8ba1\u7b97\u5b57\u6bb5:\u9009\u62e9\u9700\u8981\u8ba1\u7b97\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "ComputeField"},
            {"name": "aliasName", "type": "String (inner)", "required": True, "description": "\u522b\u540d:\u88ab\u7528\u4e8e\u5199\u8868\u8fbe\u5f0f\u7684\u5b57\u6bb5 \u4f8b\u5982\uff1aa", "example": "alias", "parent": "ComputeField"}
        ],
        "example": "{\n    \"normalizedData\": [\n        {\n            \"code\": \"001\",\n            \"salesAmount\": 1000\n        },\n        {\n            \"code\": \"002\",\n            \"salesAmount\": 1500\n        }\n    ],\n    \"normalizedExpr\": \"(a + b) / c\",\n    \"compute\": [\n        {\n            \"computeFiled\": \"salesAmount\",\n            \"aliasName\": \"a\"\n        }\n    ],\n    \"computeFiled\": \"salesAmount\",\n    \"aliasName\": \"a\"\n}",
    },
    "realtime.operation.text-similarity": {
        "_controller": "TaskPipelineRealtimeOperationToolController",
        "_method": "realtime_text_similarity",
        "_http": "POST",
        "_summary": "\u76f8\u4f3c\u5ea6\u8ba1\u7b97\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "textData", "type": "List<Map<String, Object>>", "required": True, "description": "\u6587\u672c\u6570\u636e\u5217\u8868(\u5fc5\u987b\u5305\u542bcode\u5b57\u6bb5)", "example": "[{\"code\":\"001\",\"sourceContent\":\"\u6587\u672c1\",\"targetContent\":\"\u6587\u672c2\"}]"},
            {"name": "sourceText", "type": "String", "required": True, "description": "\u6e90\u6587\u672c\u5b57\u6bb5", "example": "sourceContent"},
            {"name": "targetText", "type": "String", "required": True, "description": "\u76ee\u6807\u6587\u672c\u5b57\u6bb5", "example": "targetContent"},
            {"name": "algorithm", "type": "SimilarityAlgorithm", "required": True, "description": "\u76f8\u4f3c\u7b97\u6cd5", "example": "0"}
        ],
        "example": "{\n    \"textData\": [\n        {\n            \"code\": \"001\",\n            \"sourceContent\": \"\u6587\u672c1\",\n            \"targetContent\": \"\u6587\u672c2\"\n        }\n    ],\n    \"sourceText\": \"sourceContent\",\n    \"targetText\": \"targetContent\"\n}",
    },
    "realtime.model.industry-cluster": {
        "_controller": "TaskPipelineRealtimeModelCalculationController",
        "_method": "realtime_industry_cluster",
        "_http": "POST",
        "_summary": "\u884c\u4e1a\u805a\u96c6\u7fa4\u4e0e\u5206\u6790",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u5b57\u6bb5\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f\u4e3a WKT \u683c\u5f0f", "example": "[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "paramJson", "type": "ParamJson", "required": True, "description": "\u57fa\u7840\u53c2\u6570", "example": "{\"fenceDistance\":500,\"distance\":100,\"buffer\":50,\"groupSize\":10,\"ifConvex\":\"0\"}"},
            {"name": "fenceDistance", "type": "Double (inner)", "required": True, "description": "\u56f4\u680f\u8ddd\u79bb\uff08M\uff09", "example": "500", "parent": "ParamJson"},
            {"name": "distance", "type": "Double (inner)", "required": True, "description": "\u70b9\u8ddd\u79bb\uff08M\uff09", "example": "100", "parent": "ParamJson"},
            {"name": "buffer", "type": "Double (inner)", "required": True, "description": "\u6269\u5c55\u8ddd\u79bb\uff08M\uff09", "example": "200", "parent": "ParamJson"},
            {"name": "groupSize", "type": "Integer (inner)", "required": True, "description": "\u96c6\u7fa4\u9608\u503c\uff08\u4e2a\uff09", "example": "10", "parent": "ParamJson"},
            {"name": "ifConvex", "type": "IfConvex (inner)", "required": True, "description": "\u56f4\u680f\u7c7b\u578b\u3002\u53ef\u9009\u503c: 0=\u591a\u8fb9\u5f62; 1=\u51f8\u5305", "example": "0", "parent": "ParamJson"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": True, "description": "\u805a\u5408\u7edf\u8ba1\u5b57\u6bb5\u5217\u8868", "example": "[{\"field\":\"salesAmount\",\"aggregationType\":\"Count\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"paramJson\": {\n        \"fenceDistance\": 500,\n        \"distance\": 100,\n        \"buffer\": 50,\n        \"groupSize\": 10,\n        \"ifConvex\": \"0\"\n    },\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"aggregationType\": \"Count\"\n        }\n    ]\n}",
    },
    "realtime.model.scu-geohash": {
        "_controller": "TaskPipelineRealtimeModelCalculationController",
        "_method": "realtime_scu_geohash_generate",
        "_http": "POST",
        "_summary": "SCU-GEOHASH \u751f\u6210\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "PointData", "required": True, "description": "\u70b9\u6570\u636e", "example": "{...}"},
            {"name": "data", "type": "List<Map<String, Object>> (inner)", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868 \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "parent": "PointData"},
            {"name": "potential", "type": "String (inner)", "required": True, "description": "\u6f5c\u529b\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u4e2d\u7684\u6f5c\u529b\u5b57\u6bb5", "parent": "PointData"},
            {"name": "field_pd", "type": "String (inner)", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u8d44\u4ea7\u6570\u636e\u4e2d\u7684\u5b57\u6bb5", "parent": "PointData"},
            {"name": "centerPoint", "type": "CenterPoint", "required": True, "description": "\u805a\u7c7b\u6570\u636e", "example": "{...}"},
            {"name": "data_cp", "type": "List<Map<String, Object>> (inner)", "required": True, "description": "\u4e2d\u5fc3\u70b9\u6570\u636e\u5217\u8868 \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "parent": "CenterPoint"},
            {"name": "center", "type": "String (inner)", "required": True, "description": "\u4e2d\u5fc3\u70b9", "parent": "CenterPoint"},
            {"name": "customizeFenceData", "type": "List<Map<String, Object>>", "required": False, "description": "\u81ea\u5b9a\u4e49\u56f4\u680f\u6570\u636e"},
            {"name": "paramJson", "type": "ParamJson", "required": False, "description": "\u57fa\u672c\u53c2\u6570"},
            {"name": "zoomStart", "type": "Integer (inner)", "required": False, "description": "\u5f00\u59cb\u7ea7\u522b", "example": "5", "parent": "ParamJson"},
            {"name": "minValue", "type": "Integer (inner)", "required": True, "description": "\u6f5c\u529b\u533a\u95f4\u6700\u5c0f\u503c", "example": "0", "parent": "ParamJson"},
            {"name": "maxValue", "type": "Integer (inner)", "required": True, "description": "\u6f5c\u529b\u533a\u95f4\u6700\u5927\u503c", "example": "1000", "parent": "ParamJson"},
            {"name": "boundaryLevel", "type": "BoundaryLevel (inner)", "required": True, "description": "\u8fb9\u754c\u7b49\u7ea7\u3002\u884c\u653f\u8fb9\u754c\u7ea7\u522b\u3002\u53ef\u9009\u503c: province=\u7701\u4efd; city=\u57ce\u5e02; district=\u533a\u53bf", "example": "city", "parent": "ParamJson"},
            {"name": "effectiveScope", "type": "List<List<String>> (inner)", "required": False, "description": "\u81ea\u5b9a\u4e49\u751f\u6548\u8303\u56f4", "example": "[\"effectivescope\"]", "parent": "ParamJson"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u7edf\u8ba1"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": {\n        \"data\": [\n            {\"code\": \"001\", \"point\": \"POINT(116.404 39.915)\"}\n        ],\n        \"potential\": \"potentialValue\",\n        \"field\": \"salesAmount\"\n    },\n    \"centerPoint\": {\n        \"data\": [\n            {\"code\": \"c001\", \"point\": \"POINT(116.404 39.915)\"}\n        ],\n        \"center\": \"center\"\n    },\n    \"customizeFenceData\": [\n        {\n            \"code\": \"f1\",\n            \"name\": \"\u6d4b\u8bd5\u56f4\u680f\",\n            \"fence\": \"POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))\"\n        }\n    ],\n    \"paramJson\": {\n        \"zoomStart\": 5,\n        \"minValue\": 0,\n        \"maxValue\": 100,\n        \"boundaryLevel\": \"city\",\n        \"effectiveScope\": [\n            [\"\u5317\u4eac\u5e02\"]\n        ]\n    },\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"aggregationType\": \"Sum\"\n        }\n    ]\n}",
    },
    "realtime.model.radiate-circle": {
        "_controller": "TaskPipelineRealtimeModelCalculationController",
        "_method": "realtime_business_radiate_circle",
        "_http": "POST",
        "_summary": "\u5546\u4e1a\u4f53\u8f90\u5c04\u5546\u5708\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u5b57\u6bb5\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f\u4e3a WKT \u683c\u5f0f", "example": "[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u9762\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c fence \u56f4\u680f\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cfence \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"F001\",\"fence\":\"POLYGON((...))\"}]"},
            {"name": "radius", "type": "Double", "required": True, "description": "\u8f90\u5c04\u534a\u5f84\uff08KM\uff09", "example": "5.0"},
            {"name": "unionDistance", "type": "Double", "required": True, "description": "\u5408\u5e76\u8ddd\u79bb\uff08KM\uff09", "example": "1.0"},
            {"name": "aggregationFields", "type": "List<AggregationField>", "required": False, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"field\":\"salesAmount\",\"aggregationType\":\"Count\"}]"},
            {"name": "field", "type": "String (inner)", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\uff1a\u70b9\u6570\u636e\u7684\u5b57\u6bb5", "example": "salesAmount", "parent": "AggregationField"},
            {"name": "aggregationType", "type": "AggregationType (inner)", "required": True, "description": "\u805a\u5408\u7c7b\u578b\u3002\u805a\u5408\u51fd\u6570\u7c7b\u578b\u3002\u53ef\u9009\u503c: Avg=\u5e73\u5747\u503c; Min=\u6700\u5c0f\u503c; Max=\u6700\u5927\u503c; Sum=\u6c42\u548c; Count=\u8ba1\u6570", "example": "Sum", "parent": "AggregationField"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"fenceData\": [\n        {\n            \"code\": \"F001\",\n            \"fence\": \"POLYGON((...))\"\n        }\n    ],\n    \"radius\": 5.0,\n    \"unionDistance\": 1.0,\n    \"aggregationFields\": [\n        {\n            \"field\": \"salesAmount\",\n            \"aggregationType\": \"Count\"\n        }\n    ]\n}",
    },
    "realtime.model.reachable-range": {
        "_controller": "TaskPipelineRealtimeModelCalculationController",
        "_method": "realtime_reachable_range",
        "_http": "POST",
        "_summary": "\u53ef\u8fbe\u5708\u5206\u6790\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e \u5176\u4e2d code \u548c point \u7ecf\u7eac\u5ea6\u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "directionType", "type": "DirectionType", "required": True, "description": "\u51fa\u884c\u653f\u7b56\u3002\u53ef\u8fbe\u8303\u56f4\u51fa\u884c\u65b9\u5f0f\u3002\u53ef\u9009\u503c: driving=\u9a7e\u8f66; bicycling=\u9a91\u884c; walking=\u6b65\u884c", "example": "driving"},
            {"name": "travelTime", "type": "Integer", "required": True, "description": "\u51fa\u884c\u65f6\u957f\uff0c\u5355\u4f4d\uff1a\u5206\u949f", "example": "30"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"directionType\": \"driving\",\n    \"travelTime\": 30\n}",
    },
    "realtime.model.solitary-screen": {
        "_controller": "TaskPipelineRealtimeModelCalculationController",
        "_method": "realtime_solitary_screen_data",
        "_http": "POST",
        "_summary": "\u5b64\u70b9\u6807\u8bb0\u6570\u636e\u5904\u7406\u8bf7\u6c42",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.dataList', 'type': 'Array<Map<String,Object>>', 'description': '模型数据集合'}, {'name': 'data.fieldInfoList', 'type': 'Array<FieldInfo>', 'description': '模型返回字段的集合'}, {'name': 'data.fieldInfoList[].filedCode', 'type': 'String', 'description': '字段编码'}, {'name': 'data.fieldInfoList[].filedName', 'type': 'String', 'description': '字段描述'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u70b9\u6570\u636e\u5217\u8868\uff0c\u7528\u4e8e\u5b64\u70b9\u6807\u8bb0\u7684\u6e90\u6570\u636e", "example": "[{\"code\":\"001\",\"point\":\"POINT(116.404 39.915)\"}]"},
            {"name": "fields", "type": "List<Field>", "required": True, "description": "\u6807\u8bb0\u6761\u4ef6\u5217\u8868\uff0c\u652f\u6301\u591a\u4e2a\u5b57\u6bb5\u6761\u4ef6\u7684\u7ec4\u5408\u6807\u8bb0", "example": "[{\"fieldName\":\"field4\",\"operationType\":\"eq\"}]"},
            {"name": "fieldName", "type": "String (inner)", "required": True, "description": "\u5b57\u6bb5\u540d\u79f0\uff1a\u9700\u8981\u6807\u8bb0\u7684\u76ee\u6807\u5b57\u6bb5", "example": "field4", "parent": "Field"},
            {"name": "operationType", "type": "OperationType (inner)", "required": True, "description": "\u64cd\u4f5c\u7c7b\u578b\uff1a\u5b9a\u4e49\u7b5b\u9009\u7684\u64cd\u4f5c\u65b9\u5f0f", "example": "eq", "parent": "Field"},
            {"name": "content", "type": "Object (inner)", "required": False, "description": "\u8fc7\u6ee4/\u7b5b\u9009\u64cd\u4f5c\u7b26\uff0c\u53ef\u9009\u503c: eq=\u7b49\u4e8e; neq=\u4e0d\u7b49\u4e8e; include=\u5305\u542b; not_include=\u4e0d\u5305\u542b; gt=\u5927\u4e8e; lt=\u5c0f\u4e8e; gte=\u5927\u4e8e\u7b49\u4e8e; lte=\u5c0f\u4e8e\u7b49\u4e8e; isnull=\u4e3a\u7a7a; not_null=\u4e0d\u4e3a\u7a7a", "parent": "Field"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"001\",\n            \"point\": \"POINT(116.404 39.915)\"\n        }\n    ],\n    \"fields\": [\n        {\n            \"fieldName\": \"field4\",\n            \"operationType\": \"eq\"\n        }\n    ]\n}",
    },
    "realtime.thirdparty.poi-match": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_poi_match_handling",
        "_http": "POST",
        "_summary": "poi\u5339\u914d",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "CustomerData", "required": True, "description": "��������", "example": "{\"data\":[{\"code\":\"001\",\"name\":\"XX�ŵ�\"}],\"name\":\"name\",\"address\":\"address\"}"},
            {"name": "data", "type": "List<Map<String, Object>> (inner)", "required": True, "description": "�������ݣ����� code ������ڣ����ѡ�˹���γ�� point ��Ҫ�� point Ϊ wkt ��ʽ", "example": "[{\"code\":\"001\",\"name\":\"XX�ŵ�\"}]", "parent": "CustomerData"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "���ƣ��ʲ������д������Ƶ��ֶ�", "example": "name", "parent": "CustomerData"},
            {"name": "address", "type": "String (inner)", "required": False, "description": "��ַ���ʲ������д�����ַ���ֶ�", "example": "address", "parent": "CustomerData"},
            {"name": "policyCode", "type": "PolicyCode", "required": True, "description": "\u5904\u7406\u7b56\u7565\u53d6\u503c\u679a\u4e3e\uff08\u8f93\u5165\u6c49\u5b57\u65f6\u9700\u6839\u636e\u6c49\u5b57\u5185\u5bb9\u6620\u5c04\u4e3a\u7f16\u7801\uff09\u3002\u53ef\u9009\u503c: 30003=\u540d\u79f0-\u5305\u542b\u7c7b\u76ee; 30004=\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0-\u5254\u9664\u7c7b\u76ee; 30006=\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee", "example": "30003"},
            {"name": "policyConfig", "type": "List<Category>", "required": False, "description": "��Ŀѡ�������ʽ [{\"name\": \"��ʳ\", \"subCategories\": [\"����\", \"������\"]}]", "example": "[{\"name\":\"��ʳ\",\"subCategories\":[\"����\",\"������\"]}]"},
            {"name": "name", "type": "String (inner)", "required": False, "description": "��Ŀ���ƣ��Ǳ���", "example": "��ʳ", "parent": "Category"},
            {"name": "subCategories", "type": "List<String> (inner)", "required": False, "description": "����Ŀ�б�", "example": "[\"����\",\"������\"]", "parent": "Category"}
        ],
        "example": "{\n    \"customerData\": {\n        \"data\": [\n            {\n                \"code\": \"001\",\n                \"name\": \"XX�ŵ�\"\n            }\n        ],\n        \"name\": \"name\",\n        \"address\": \"address\"\n    },\n    \"policyCode\": \"30003\",\n    \"policyConfig\": [\n        {\n            \"name\": \"��ʳ\",\n            \"subCategories\": [\n                \"����\",\n                \"������\"\n            ]\n        }\n    ]\n}",
    },
    "realtime.thirdparty.customer-flow-items": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_customer_flow_service_items",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u670d\u52a1\u9879\u76ee\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "remark", "type": "String", "required": False, "description": "\u4efb\u52a1\u5907\u6ce8", "example": "\u670d\u52a1\u9879\u76ee\u5206\u6790\u4efb\u52a1"}
        ],
        "example": "{\n    \"remark\": \"\u670d\u52a1\u9879\u76ee\u5206\u6790\u4efb\u52a1\"\n}",
    },
    "realtime.thirdparty.customer-flow-competitors": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_customer_flow_competitor_stores",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u7ade\u54c1\u95e8\u5e97\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c polygon \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpolygon \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "mallFieldCode", "type": "String", "required": True, "description": "\u5546\u573a\u5b57\u6bb5\u7f16\u7801", "example": "mall_code"}
        ],
        "example": "{\n    \"fenceData\": \"fenceData\",\n    \"mallFieldCode\": \"mall_code\"\n}",
    },
    "realtime.thirdparty.customer-flow-report": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_customer_flow_data_reports",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u6570\u636e\u62a5\u8868\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c polygon \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpolygon \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u533a\u57dfA\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "mallFieldCode", "type": "String", "required": True, "description": "\u5546\u573a\u5b57\u6bb5\u7f16\u7801\uff08mallId\uff09", "example": "mall_code"},
            {"name": "dataReportInterApiParams", "type": "List<DataReportInterApiParams>", "required": True, "description": "\u6570\u636e\u62a5\u8868\u63a5\u53e3\u53c2\u6570\u914d\u7f6e\u5217\u8868", "example": "mall_code"},
            {"name": "dateList", "type": "List<String> (inner)", "required": True, "description": "\u65e5\u671f\u5217\u8868", "example": "[\"2024-01-01\", \"2024-01-02\"]", "parent": "DataReportInterApiParams"},
            {"name": "interfaceCode", "type": "InterfaceCode (inner)", "required": True, "description": "\u63a5\u53e3\u7f16\u7801\u3002\u7b2c\u4e09\u65b9\u63a5\u53e3\u6807\u8bc6\u3002\u53ef\u9009\u503c: GETGRIDBUSSINESSCIRCLE=\u6805\u683c\u5ba2\u6d41/\u4eba\u53e3\u6570\u67e5\u8be2; GETAOIDEPRESSIONRANK=\u5ba2\u6d41\u6d3c\u5730\u6392\u540d\u67e5\u8be2; GETAOICOMMUNTIYSIZERANK=\u6765\u6e90\u5730\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETLOWPASSENGERFLOW=\u4f4e\u5ba2\u6d41\u533a\u57df\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETGRIDDEPRESSIONDATA=\u6805\u683c\u6e17\u900f\u7387\u67e5\u8be2; GETAOIPASSENGERFLOWRANK=\u5ba2\u6d41\u6765\u6e90\u6392\u540d\u67e5\u8be2; GETMALLFLOWANDNUMDATABYMALLID=\u5ba2\u6d41\u7edf\u8ba1; GETGRIDPERAGEPORTRAITS=\u5ba2\u6d41\u6d3b\u8dc3\u65f6\u6bb5; GETLENGTHSOFSTAYDATA=\u5ba2\u6d41\u505c\u7559\u65f6\u957f; GETGRIDPERAGEPORTRAITBYMALLIDS=\u5ba2\u6d41\u5230\u8bbf\u9891\u6b21 \u7b4919\u4e2a\u503c", "example": "getmallflowandnumdatabymallId", "parent": "DataReportInterApiParams"},
            {"name": "pType", "type": "String (inner)", "required": False, "description": "\u8bbf\u6b21\u6570\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a getgridperageportraitbymallIdS \u65f6\u6709\u6548\uff09", "example": "visitCount", "parent": "DataReportInterApiParams"}
        ],
        "example": "{\n    \"fenceData\": \"fenceData\",\n    \"mallFieldCode\": \"mall_code\",\n    \"dataReportInterApiParams\": {\n        \"dateList\": [\n            \"2024-01-01\",\n            \"2024-01-02\"\n        ],\n        \"pType\": \"visitCount\"\n    },\n    \"dateList\": [\n        \"2024-01-01\",\n        \"2024-01-02\"\n    ],\n    \"pType\": \"visitCount\"\n}",
    },
    "realtime.thirdparty.customer-flow-pedestrian": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_customer_flow_business_district_pedestrian_flow_analysis",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u5546\u5708\u5ba2\u6d41\u5206\u6790\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c polygon \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpolygon \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u5546\u573aA\",\"polygon\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "mallFieldCode", "type": "String", "required": True, "description": "\u5546\u573a ID\uff08mallId\uff09", "example": "mall_001"},
            {"name": "apiParams", "type": "List<ApiParams>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"interfaceCode\":\"getgridbussinesscircle\",\"date\":\"2024-01-01\",\"type\":[\"1\"],\"property\":[\"1\"]}]"},
            {"name": "interfaceCode", "type": "InterfaceCode (inner)", "required": True, "description": "\u63a5\u53e3\u7f16\u7801\u3002\u7b2c\u4e09\u65b9\u63a5\u53e3\u6807\u8bc6\u3002\u53ef\u9009\u503c: GETGRIDBUSSINESSCIRCLE=\u6805\u683c\u5ba2\u6d41/\u4eba\u53e3\u6570\u67e5\u8be2; GETAOIDEPRESSIONRANK=\u5ba2\u6d41\u6d3c\u5730\u6392\u540d\u67e5\u8be2; GETAOICOMMUNTIYSIZERANK=\u6765\u6e90\u5730\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETLOWPASSENGERFLOW=\u4f4e\u5ba2\u6d41\u533a\u57df\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETGRIDDEPRESSIONDATA=\u6805\u683c\u6e17\u900f\u7387\u67e5\u8be2; GETAOIPASSENGERFLOWRANK=\u5ba2\u6d41\u6765\u6e90\u6392\u540d\u67e5\u8be2; GETMALLFLOWANDNUMDATABYMALLID=\u5ba2\u6d41\u7edf\u8ba1; GETGRIDPERAGEPORTRAITS=\u5ba2\u6d41\u6d3b\u8dc3\u65f6\u6bb5; GETLENGTHSOFSTAYDATA=\u5ba2\u6d41\u505c\u7559\u65f6\u957f; GETGRIDPERAGEPORTRAITBYMALLIDS=\u5ba2\u6d41\u5230\u8bbf\u9891\u6b21 \u7b4919\u4e2a\u503c", "example": "getgridbussinesscircle", "parent": "ApiParams"},
            {"name": "date", "type": "String (inner)", "required": True, "description": "\u65e5\u671f", "example": "2024-01-01", "parent": "ApiParams"},
            {"name": "type", "type": "List<Type> (inner)", "required": True, "description": "\u5ba2\u6d41\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a getaoipassengerflowrank\u3001getaoicommuntiysizerank\u3001getaoidepressionrank\u3001getlowpassengerflow \u65f6\u6709\u6548\uff09\u3002\u5ba2\u6d41\u7c7b\u578b\u5206\u7c7b\u3002\u53ef\u9009\u503c: 1=\u5c45\u4f4f; 2=\u5de5\u4f5c; 3=\u8def\u8fc7", "example": "2024-01-01", "parent": "ApiParams"},
            {"name": "property", "type": "List<Property> (inner)", "required": False, "description": "\u7f51\u683c\u4eba\u7fa4\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a getgridbussinesscircle \u65f6\u6709\u6548\uff09\u3002\u5ba2\u6d41\u6307\u6807\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u5ba2\u6d41\u6570\u91cf; 2=\u4eba\u53e3\u6570\u91cf", "parent": "ApiParams"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u5546\u573aA\",\n            \"polygon\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"mallFieldCode\": \"mall_001\",\n    \"apiParams\": [\n        {\n            \"interfaceCode\": \"getgridbussinesscircle\",\n            \"date\": \"2024-01-01\",\n            \"type\": [\n                \"1\"\n            ],\n            \"property\": [\n                \"1\"\n            ]\n        }\n    ],\n    \"interfaceCode\": \"getgridbussinesscircle\",\n    \"date\": \"2024-01-01\",\n    \"type\": [\n        \"1\"\n    ],\n    \"property\": [\n        \"1\"\n    ]\n}",
    },
    "realtime.thirdparty.customer-flow-competition": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_customer_flow_business_district_competition_intensity_analysis",
        "_http": "POST",
        "_summary": "\u5ba2\u6d41\u901a - \u5546\u5708\u7ade\u4e89\u70c8\u5ea6\u5206\u6790\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "fenceData", "type": "List<Map<String, Object>>", "required": True, "description": "\u56f4\u680f\u6570\u636e \u5176\u4e2d code \u548c polygon \u5b57\u6bb5\u5185\u5bb9\u5fc5\u987b\u5b58\u5728\uff0cpolygon \u683c\u5f0f wkt \u683c\u5f0f", "example": "[{\"code\":\"fence_001\",\"name\":\"\u4e3b\u573aA\",\"polygon\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\",\"n_mall_id\":\"comp_001\"}]"},
            {"name": "mallIdFieldCode", "type": "String", "required": True, "description": "\u4e3b\u573a\u670d\u52a1\u533a ID \u5b57\u6bb5", "example": "mall_id"},
            {"name": "competitorMallIdFieldCode", "type": "String", "required": True, "description": "\u7ade\u54c1\u670d\u52a1\u533a ID \u5b57\u6bb5", "example": "n_mall_id"},
            {"name": "date", "type": "String", "required": True, "description": "\u65e5\u671f", "example": "2024-01-01"},
            {"name": "type", "type": "CompetitionType", "required": True, "description": "\u7ade\u4e89\u7c7b\u578b\u3002\u5ba2\u6d41\u7c7b\u578b\u5206\u7c7b\u3002\u53ef\u9009\u503c: 1=\u5c45\u4f4f; 2=\u5de5\u4f5c; 3=\u8def\u8fc7", "example": "1"}
        ],
        "example": "{\n    \"fenceData\": [\n        {\n            \"code\": \"fence_001\",\n            \"name\": \"\u4e3b\u573aA\",\n            \"polygon\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\",\n            \"n_mall_id\": \"comp_001\"\n        }\n    ],\n    \"mallIdFieldCode\": \"mall_id\",\n    \"date\": \"2024-01-01\"\n}",
    },
    "realtime.thirdparty.lbs-passenger-point": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_lbs_passenger_portrait_point",
        "_http": "POST",
        "_summary": "LBS \u5ba2\u6d41\u753b\u50cf\u70b9\u6570\u636e\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "lbsData", "type": "List<Map<String, Object>>", "required": True, "description": "LBS \u6570\u636e\u70b9\u6570\u636e\u5217\u8868", "example": "[{\"code\":\"lbs_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "radius", "type": "String", "required": True, "description": "\u534a\u5f84 (\u7c73)", "example": "1000"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "\u7ed3\u679c\u5197\u4f59\u5b57\u6bb5", "example": "[\"field1\", \"field2\"]"},
            {"name": "lbsInterApiParams", "type": "List<LbsInterApiParams>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"interfaceCode\":\"residentnum\",\"monthAverage\":\"1\",\"adCode\":\"110000\",\"month\":[\"2024-01\"],\"peopleType\":[\"1\"],\"label\":[\"gender\"],\"dateType\":[\"workday\"],\"heatType\":[\"people_flow\"]}]"},
            {"name": "interfaceCode", "type": "InterfaceCode (inner)", "required": True, "description": "\u63a5\u53e3\u7c7b\u578b\u3002\u7b2c\u4e09\u65b9\u63a5\u53e3\u6807\u8bc6\u3002\u53ef\u9009\u503c: GETGRIDBUSSINESSCIRCLE=\u6805\u683c\u5ba2\u6d41/\u4eba\u53e3\u6570\u67e5\u8be2; GETAOIDEPRESSIONRANK=\u5ba2\u6d41\u6d3c\u5730\u6392\u540d\u67e5\u8be2; GETAOICOMMUNTIYSIZERANK=\u6765\u6e90\u5730\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETLOWPASSENGERFLOW=\u4f4e\u5ba2\u6d41\u533a\u57df\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETGRIDDEPRESSIONDATA=\u6805\u683c\u6e17\u900f\u7387\u67e5\u8be2; GETAOIPASSENGERFLOWRANK=\u5ba2\u6d41\u6765\u6e90\u6392\u540d\u67e5\u8be2; GETMALLFLOWANDNUMDATABYMALLID=\u5ba2\u6d41\u7edf\u8ba1; GETGRIDPERAGEPORTRAITS=\u5ba2\u6d41\u6d3b\u8dc3\u65f6\u6bb5; GETLENGTHSOFSTAYDATA=\u5ba2\u6d41\u505c\u7559\u65f6\u957f; GETGRIDPERAGEPORTRAITBYMALLIDS=\u5ba2\u6d41\u5230\u8bbf\u9891\u6b21 \u7b4919\u4e2a\u503c", "example": "residentnum", "parent": "LbsInterApiParams"},
            {"name": "monthAverage", "type": "MonthAverage (inner)", "required": False, "description": "\u56de\u6eaf\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentnum\u3001flownum \u65f6\u6709\u6548\uff09\u3002\u6708\u4efd\u5e73\u5747\u5468\u671f\u3002\u53ef\u9009\u503c: 1=\u5f53\u6708; 3=3\u4e2a\u6708; 6=6\u4e2a\u6708; 12=12\u4e2a\u6708", "example": "1", "parent": "LbsInterApiParams"},
            {"name": "adCode", "type": "String (inner)", "required": True, "description": "\u884c\u653f\u533a\u5212\u7f16\u7801", "example": "110000", "parent": "LbsInterApiParams"},
            {"name": "month", "type": "List<String> (inner)", "required": True, "description": "\u5f53\u524d\u6708\uff08\u591a\u9009\uff09", "example": "[\"2024-01\", \"2024-02\"]", "parent": "LbsInterApiParams"},
            {"name": "peopleType", "type": "List<PeopleType> (inner)", "required": False, "description": "\u5e38\u9a7b\u4eba\u53e3\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentnum\u3001residentuserprofile \u65f6\u6709\u6548\uff09\u3002\u4eba\u53e3\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u5de5\u4f5c\u4eba\u53e3; 2=\u5c45\u4f4f\u4eba\u53e3; 3=\u5de5\u4f5c\u6216\u5c45\u4f4f", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "label", "type": "List<Label> (inner)", "required": False, "description": "\u6807\u7b7e\u5217\u8868\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentuserprofile\u3001flowuserprofile \u65f6\u6709\u6548\uff09\u3002\u7528\u6237\u753b\u50cf\u6807\u7b7e\u7f16\u7801\u3002\u53ef\u9009\u503c: 101010=\u6027\u522b; 101012=\u5e74\u9f84(\u5206\u6bb5); 101015=\u5b66\u5386; 101112=\u5a5a\u5426v2; 1041=\u5b50\u5973\u5e74\u9f84v2; 1052=\u5a5a\u80b2\u72b6\u6001; 1013=\u4eba\u751f\u9636\u6bb5; 1037=\u804c\u4e1a\u7ec6\u5206; 1038=\u6240\u5728\u884c\u4e1a; 990043=\u804c\u4f4f\u8ddd\u79bb(\u5206\u6bb5) \u7b4935\u4e2a\u503c", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "dateType", "type": "List<DateType> (inner)", "required": False, "description": "\u65e5\u671f\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a flownum\u3001flowuserprofile \u65f6\u6709\u6548\uff09\u3002\u65e5\u671f\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u6708\u65e5\u5e73\u5747; 2=\u5de5\u4f5c\u65e5\u5e73\u5747; 3=\u8282\u5047\u65e5\u5e73\u5747; workday=\u5de5\u4f5c\u65e5; weekend=\u5468\u672b; holiday=\u8282\u5047\u65e5", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "heatType", "type": "List<HeatType> (inner)", "required": False, "description": "\u70ed\u529b\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a locationpoint \u65f6\u6709\u6548\uff09\u3002\u70ed\u529b\u56fe\u7c7b\u578b\u3002\u53ef\u9009\u503c: flow_workday=\u5de5\u4f5c\u65e5\u5ba2\u6d41; flow_holiday=\u8282\u5047\u65e5\u5ba2\u6d41; resident_home=\u5c45\u4f4f; resident_work=\u5de5\u4f5c; people_flow=\u4eba\u6d41\u70ed\u529b; vehicle_flow=\u8f66\u6d41\u70ed\u529b", "example": "[...]", "parent": "LbsInterApiParams"}
        ],
        "example": "{\n    \"lbsData\": [\n        {\n            \"code\": \"lbs_001\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"radius\": 1000,\n    \"translationFields\": [\n        \"field1\",\n        \"field2\"\n    ],\n    \"lbsInterApiParams\": [\n        {\n            \"interfaceCode\": \"residentnum\",\n            \"monthAverage\": \"1\",\n            \"adCode\": \"110000\",\n            \"month\": [\n                \"2024-01\"\n            ],\n            \"peopleType\": [\n                \"1\"\n            ],\n            \"label\": [\n                \"gender\"\n            ],\n            \"dateType\": [\n                \"workday\"\n            ],\n            \"heatType\": [\n                \"people_flow\"\n            ]\n        }\n    ],\n    \"adCode\": 110000,\n    \"month\": [\n        \"2024-01\",\n        \"2024-02\"\n    ]\n}",
    },
    "realtime.thirdparty.lbs-passenger-area": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_lbs_passenger_portrait_area",
        "_http": "POST",
        "_summary": "LBS \u5ba2\u6d41\u753b\u50cf\u9762\u6570\u636e\u8bf7\u6c42\u53c2\u6570",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "lbsData", "type": "List<Map<String, Object>>", "required": True, "description": "LBS \u6570\u636e\u9762\u6570\u636e\u5217\u8868", "example": "[{\"code\":\"lbs_001\",\"name\":\"\u6d4b\u8bd5\u533a\u57df\",\"fence\":\"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"}]"},
            {"name": "translationFields", "type": "List<String>", "required": True, "description": "\u7ed3\u679c\u5197\u4f59\u5b57\u6bb5", "example": "[\"field1\", \"field2\"]"},
            {"name": "lbsInterApiParams", "type": "List<LbsInterApiParams>", "required": True, "description": "\u805a\u5408\u5b57\u6bb5\u914d\u7f6e\u5217\u8868", "example": "[{\"interfaceCode\":\"residentnum\",\"monthAverage\":\"1\",\"adCode\":\"110000\",\"month\":[\"2024-01\"],\"peopleType\":[\"1\"],\"label\":[\"gender\"],\"dateType\":[\"workday\"],\"heatType\":[\"people_flow\"]}]"},
            {"name": "interfaceCode", "type": "InterfaceCode (inner)", "required": True, "description": "\u63a5\u53e3\u7c7b\u578b\u3002\u7b2c\u4e09\u65b9\u63a5\u53e3\u6807\u8bc6\u3002\u53ef\u9009\u503c: GETGRIDBUSSINESSCIRCLE=\u6805\u683c\u5ba2\u6d41/\u4eba\u53e3\u6570\u67e5\u8be2; GETAOIDEPRESSIONRANK=\u5ba2\u6d41\u6d3c\u5730\u6392\u540d\u67e5\u8be2; GETAOICOMMUNTIYSIZERANK=\u6765\u6e90\u5730\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETLOWPASSENGERFLOW=\u4f4e\u5ba2\u6d41\u533a\u57df\u4eba\u53e3\u6392\u540d\u67e5\u8be2; GETGRIDDEPRESSIONDATA=\u6805\u683c\u6e17\u900f\u7387\u67e5\u8be2; GETAOIPASSENGERFLOWRANK=\u5ba2\u6d41\u6765\u6e90\u6392\u540d\u67e5\u8be2; GETMALLFLOWANDNUMDATABYMALLID=\u5ba2\u6d41\u7edf\u8ba1; GETGRIDPERAGEPORTRAITS=\u5ba2\u6d41\u6d3b\u8dc3\u65f6\u6bb5; GETLENGTHSOFSTAYDATA=\u5ba2\u6d41\u505c\u7559\u65f6\u957f; GETGRIDPERAGEPORTRAITBYMALLIDS=\u5ba2\u6d41\u5230\u8bbf\u9891\u6b21 \u7b4919\u4e2a\u503c", "example": "residentnum", "parent": "LbsInterApiParams"},
            {"name": "monthAverage", "type": "MonthAverage (inner)", "required": False, "description": "\u56de\u6eaf\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentnum\u3001flownum \u65f6\u6709\u6548\uff09\u3002\u6708\u4efd\u5e73\u5747\u5468\u671f\u3002\u53ef\u9009\u503c: 1=\u5f53\u6708; 3=3\u4e2a\u6708; 6=6\u4e2a\u6708; 12=12\u4e2a\u6708", "example": "1", "parent": "LbsInterApiParams"},
            {"name": "adCode", "type": "String (inner)", "required": True, "description": "\u884c\u653f\u533a\u5212\u7f16\u7801", "example": "110000", "parent": "LbsInterApiParams"},
            {"name": "month", "type": "List<String> (inner)", "required": True, "description": "\u5f53\u524d\u6708\uff08\u591a\u9009\uff09", "example": "[\"2024-01\", \"2024-02\"]", "parent": "LbsInterApiParams"},
            {"name": "peopleType", "type": "List<PeopleType> (inner)", "required": False, "description": "\u5e38\u9a7b\u4eba\u53e3\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentnum\u3001residentuserprofile \u65f6\u6709\u6548\uff09\u3002\u4eba\u53e3\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u5de5\u4f5c\u4eba\u53e3; 2=\u5c45\u4f4f\u4eba\u53e3; 3=\u5de5\u4f5c\u6216\u5c45\u4f4f", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "label", "type": "List<Label> (inner)", "required": False, "description": "\u6807\u7b7e\u5217\u8868\uff08\u4ec5\u5f53 interfaceCode \u4e3a residentuserprofile\u3001flowuserprofile \u65f6\u6709\u6548\uff09\u3002\u7528\u6237\u753b\u50cf\u6807\u7b7e\u7f16\u7801\u3002\u53ef\u9009\u503c: 101010=\u6027\u522b; 101012=\u5e74\u9f84(\u5206\u6bb5); 101015=\u5b66\u5386; 101112=\u5a5a\u5426v2; 1041=\u5b50\u5973\u5e74\u9f84v2; 1052=\u5a5a\u80b2\u72b6\u6001; 1013=\u4eba\u751f\u9636\u6bb5; 1037=\u804c\u4e1a\u7ec6\u5206; 1038=\u6240\u5728\u884c\u4e1a; 990043=\u804c\u4f4f\u8ddd\u79bb(\u5206\u6bb5) \u7b4935\u4e2a\u503c", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "dateType", "type": "List<DateType> (inner)", "required": False, "description": "\u65e5\u671f\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a flownum\u3001flowuserprofile \u65f6\u6709\u6548\uff09\u3002\u65e5\u671f\u7c7b\u578b\u3002\u53ef\u9009\u503c: 1=\u6708\u65e5\u5e73\u5747; 2=\u5de5\u4f5c\u65e5\u5e73\u5747; 3=\u8282\u5047\u65e5\u5e73\u5747; workday=\u5de5\u4f5c\u65e5; weekend=\u5468\u672b; holiday=\u8282\u5047\u65e5", "example": "[...]", "parent": "LbsInterApiParams"},
            {"name": "heatType", "type": "List<HeatType> (inner)", "required": False, "description": "\u70ed\u529b\u7c7b\u578b\uff08\u4ec5\u5f53 interfaceCode \u4e3a locationpoint \u65f6\u6709\u6548\uff09\u3002\u70ed\u529b\u56fe\u7c7b\u578b\u3002\u53ef\u9009\u503c: flow_workday=\u5de5\u4f5c\u65e5\u5ba2\u6d41; flow_holiday=\u8282\u5047\u65e5\u5ba2\u6d41; resident_home=\u5c45\u4f4f; resident_work=\u5de5\u4f5c; people_flow=\u4eba\u6d41\u70ed\u529b; vehicle_flow=\u8f66\u6d41\u70ed\u529b", "example": "[...]", "parent": "LbsInterApiParams"}
        ],
        "example": "{\n    \"lbsData\": [\n        {\n            \"code\": \"lbs_001\",\n            \"name\": \"\u6d4b\u8bd5\u533a\u57df\",\n            \"fence\": \"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))\"\n        }\n    ],\n    \"translationFields\": [\n        \"field1\",\n        \"field2\"\n    ],\n    \"lbsInterApiParams\": [\n        {\n            \"interfaceCode\": \"residentnum\",\n            \"monthAverage\": \"1\",\n            \"adCode\": \"110000\",\n            \"month\": [\n                \"2024-01\"\n            ],\n            \"peopleType\": [\n                \"1\"\n            ],\n            \"label\": [\n                \"gender\"\n            ],\n            \"dateType\": [\n                \"workday\"\n            ],\n            \"heatType\": [\n                \"people_flow\"\n            ]\n        }\n    ],\n    \"adCode\": 110000,\n    \"month\": [\n        \"2024-01\",\n        \"2024-02\"\n    ]\n}",
    },
    "realtime.thirdparty.tx-poi-match-v2": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_tx_poi_match_v2",
        "_http": "POST",
        "_summary": "\u817e\u8baf POI \u5339\u914d V2",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "List<Map<String, Object>>", "required": True, "description": "\u5ba2\u6237\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c name/province/city/district/address/poiPoint \u5b57\u6bb5\u6839\u636e\u5173\u8054\u65b9\u5f0f\u5fc5\u586b", "example": "[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\",\"province\":\"\u5317\u4eac\u5e02\",\"city\":\"\u5317\u4eac\u5e02\",\"district\":\"\u671d\u9633\u533a\",\"address\":\"XX\u8defXX\u53f7\"}]"},
            {"name": "policyCode", "type": "PolicyCode", "required": True, "description": "\u5173\u8054\u65b9\u5f0f\u679a\u4e3e\uff1a\u53ef\u9009\u503c: 30003=\u540d\u79f0+\u5730\u5740-\u5305\u542b\u7c7b\u76ee; 30004=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0+\u5730\u5740-\u5254\u9664\u7c7b\u76ee; 30006=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee", "example": "30003"},
            {"name": "mode", "type": "Mode", "required": False, "description": "\u5173\u8054\u6a21\u5f0f\u3002POI\u5339\u914d\u7b97\u6cd5\u6a21\u5f0f\u3002\u53ef\u9009\u503c: cluster=cluster\u6a21\u5f0f(\u7cbe\u786e\u5ea6\u66f4\u9ad8); link=link\u6a21\u5f0f(\u53ec\u56de\u7387\u66f4\u9ad8)", "example": "cluster"},
            {"name": "policyConfig", "type": "String", "required": False, "description": "\u7c7b\u76ee\u9009\u62e9", "example": "\u65e0"},
            {"name": "name", "type": "String", "required": True, "description": "\u540d\u79f0\u5b57\u6bb5", "example": "name"},
            {"name": "province", "type": "String", "required": False, "description": "\u7701\u5b57\u6bb5", "example": "province"},
            {"name": "city", "type": "String", "required": False, "description": "\u5e02\u5b57\u6bb5", "example": "city"},
            {"name": "district", "type": "String", "required": False, "description": "\u533a\u5b57\u6bb5", "example": "district"},
            {"name": "address", "type": "String", "required": False, "description": "\u5730\u5740\u5b57\u6bb5\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30003,30005,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "address"},
            {"name": "poiPoint", "type": "String", "required": False, "description": "\u7ecf\u7eac\u5ea6\u5b57\u6bb5", "example": "poiPoint"}
        ],
        "example": "{\n    \"customerData\": [\n        {\n            \"code\": \"001\",\n            \"name\": \"XX�ŵ�\",\n            \"province\": \"������\",\n            \"city\": \"������\",\n            \"district\": \"������\",\n            \"address\": \"XX·XX��\"\n        }\n    ],\n    \"policyCode\": \"30003\",\n    \"policyConfig\": \"��ʳ\",\n    \"name\": \"name\",\n    \"province\": \"province\",\n    \"city\": \"city\",\n    \"district\": \"district\",\n    \"address\": \"address\",\n    \"poiPoint\": \"poiPoint\"\n}",
    },
    "realtime.thirdparty.tx-poi-multi-v2": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_tx_poi_mutil_match_v2",
        "_http": "POST",
        "_summary": "\u591a\u7ec4 - \u817e\u8baf POI \u5173\u8054",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "List<Map<String, Object>>", "required": True, "description": "\u5ba2\u6237\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c name/province/city/district/address/poiPoint \u5b57\u6bb5\u6839\u636e\u5173\u8054\u65b9\u5f0f\u5fc5\u586b", "example": "[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\",\"province\":\"\u5317\u4eac\u5e02\",\"city\":\"\u5317\u4eac\u5e02\",\"district\":\"\u671d\u9633\u533a\",\"address\":\"XX\u8defXX\u53f7\"}]"},
            {"name": "matchStrategyList", "type": "List<MatchStrategy>", "required": True, "description": "\u5339\u914d\u7b56\u7565\u5217\u8868", "example": "[{\"policyCode\":\"30003\",\"policyConfig\":\"\u7f8e\u98df\",\"name\":\"name\",\"mode\":\"cluster\",\"address\":\"address\",\"poiPoint\":\"point\",\"province\":\"province\",\"city\":\"city\",\"district\":\"district\"}]"},
            {"name": "policyCode", "type": "PolicyCode (inner)", "required": True, "description": "\u5173\u8054\u65b9\u5f0f\u679a\u4e3e\uff1a\u53ef\u9009\u503c: 30003=\u540d\u79f0+\u5730\u5740-\u5305\u542b\u7c7b\u76ee; 30004=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0+\u5730\u5740-\u5254\u9664\u7c7b\u76ee; 30006=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee", "example": "30003", "parent": "MatchStrategy"},
            {"name": "policyConfig", "type": "String (inner)", "required": False, "description": "\u7c7b\u76ee\u9009\u62e9", "parent": "MatchStrategy"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0", "example": "XX\u95e8\u5e97", "parent": "MatchStrategy"},
            {"name": "mode", "type": "Mode (inner)", "required": False, "description": "����ģʽ��POIƥ���㷨ģʽ����ѡֵ: cluster=clusterģʽ(��ȷ�ȸ���); link=linkģʽ(�ٻ��ʸ���)", "example": "cluster", "parent": "MatchStrategy"},
            {"name": "address", "type": "String (inner)", "required": True, "description": "\u5730\u5740\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30003,30005,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "address", "parent": "MatchStrategy"},
            {"name": "poiPoint", "type": "String (inner)", "required": False, "description": "\u7ecf\u7eac\u5ea6\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30004,30006,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "116.397,39.908", "parent": "MatchStrategy"},
            {"name": "province", "type": "String (inner)", "required": False, "description": "\u7701", "example": "province", "parent": "MatchStrategy"},
            {"name": "city", "type": "String (inner)", "required": False, "description": "\u5e02", "example": "\u5317\u4eac\u5e02", "parent": "MatchStrategy"},
            {"name": "district", "type": "String (inner)", "required": False, "description": "\u533a", "example": "district", "parent": "MatchStrategy"}
        ],
        "example": "{\n    \"customerData\": [\n        {\n            \"code\": \"001\",\n            \"name\": \"XX\u95e8\u5e97\",\n            \"province\": \"\u5317\u4eac\u5e02\",\n            \"city\": \"\u5317\u4eac\u5e02\",\n            \"district\": \"\u671d\u9633\u533a\",\n            \"address\": \"XX\u8defXX\u53f7\"\n        }\n    ],\n    \"matchStrategyList\": [\n        {\n            \"policyCode\": \"30003\",\n            \"policyConfig\": \"\u7f8e\u98df\",\n            \"name\": \"name\",\n            \"mode\": \"cluster\",\n            \"address\": \"address\",\n            \"poiPoint\": \"point\",\n            \"province\": \"province\",\n            \"city\": \"city\",\n            \"district\": \"district\"\n        }\n    ],\n    \"policyConfig\": \"\u7f8e\u98df\",\n    \"name\": \"name\",\n    \"address\": \"address\",\n    \"poiPoint\": \"point\",\n    \"province\": \"province\",\n    \"city\": \"city\",\n    \"district\": \"district\"\n}",
    },
    "realtime.thirdparty.tx-poi-multi": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_tx_poi_mutil_match",
        "_http": "POST",
        "_summary": "\u591a\u7ec4-\u817e\u8bafPOI\u5173\u8054",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "customerData", "type": "List<Map<String, Object>>", "required": True, "description": "\u5ba2\u6237\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c name/province/city/district/address/poiPoint \u5b57\u6bb5\u6839\u636e\u5173\u8054\u65b9\u5f0f\u5fc5\u586b", "example": "[{\"code\":\"001\",\"name\":\"XX\u95e8\u5e97\",\"province\":\"\u5317\u4eac\u5e02\",\"city\":\"\u5317\u4eac\u5e02\",\"district\":\"\u671d\u9633\u533a\",\"address\":\"XX\u8defXX\u53f7\"}]"},
            {"name": "matchStrategyList", "type": "List<MatchStrategy>", "required": True, "description": "\u5339\u914d\u7b56\u7565\u5217\u8868", "example": "[{\"policyCode\":\"30003\",\"policyConfig\":\"\u7f8e\u98df\",\"name\":\"name\",\"address\":\"address\",\"poiPoint\":\"point\",\"province\":\"province\",\"city\":\"city\",\"district\":\"district\"}]"},
            {"name": "policyCode", "type": "PolicyCode (inner)", "required": True, "description": "\u5173\u8054\u65b9\u5f0f\u679a\u4e3e\uff1a\u53ef\u9009\u503c: 30003=\u540d\u79f0+\u5730\u5740-\u5305\u542b\u7c7b\u76ee; 30004=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30004_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5305\u542b\u7c7b\u76ee; 30005=\u540d\u79f0+\u5730\u5740-\u5254\u9664\u7c7b\u76ee; 30006=\u540d\u79f0+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee; 30006_1=\u540d\u79f0+\u5730\u5740+\u7ecf\u7eac\u5ea6-\u5254\u9664\u7c7b\u76ee", "example": "30003", "parent": "MatchStrategy"},
            {"name": "policyConfig", "type": "String (inner)", "required": False, "description": "\u7c7b\u76ee\u9009\u62e9", "parent": "MatchStrategy"},
            {"name": "name", "type": "String (inner)", "required": True, "description": "\u540d\u79f0", "example": "XX\u95e8\u5e97", "parent": "MatchStrategy"},
            {"name": "address", "type": "String (inner)", "required": True, "description": "\u5730\u5740\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30003,30005,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "address", "parent": "MatchStrategy"},
            {"name": "poiPoint", "type": "String (inner)", "required": False, "description": "\u7ecf\u7eac\u5ea6\uff08\u5173\u8054\u65b9\u5f0f\u4e3a 30004,30006,30004_1,30006_1 \u65f6\u5fc5\u586b\uff09", "example": "116.397,39.908", "parent": "MatchStrategy"},
            {"name": "province", "type": "String (inner)", "required": False, "description": "\u7701", "example": "province", "parent": "MatchStrategy"},
            {"name": "city", "type": "String (inner)", "required": False, "description": "\u5e02", "example": "\u5317\u4eac\u5e02", "parent": "MatchStrategy"},
            {"name": "district", "type": "String (inner)", "required": False, "description": "\u533a", "example": "district", "parent": "MatchStrategy"}
        ],
        "example": "{\n    \"customerData\": [\n        {\n            \"code\": \"001\",\n            \"name\": \"XX\u95e8\u5e97\",\n            \"province\": \"\u5317\u4eac\u5e02\",\n            \"city\": \"\u5317\u4eac\u5e02\",\n            \"district\": \"\u671d\u9633\u533a\",\n            \"address\": \"XX\u8defXX\u53f7\"\n        }\n    ],\n    \"matchStrategyList\": [\n        {\n            \"policyCode\": \"30003\",\n            \"policyConfig\": \"\u7f8e\u98df\",\n            \"name\": \"name\",\n            \"address\": \"address\",\n            \"poiPoint\": \"point\",\n            \"province\": \"province\",\n            \"city\": \"city\",\n            \"district\": \"district\"\n        }\n    ],\n    \"policyConfig\": \"\u7f8e\u98df\",\n    \"name\": \"name\",\n    \"address\": \"address\",\n    \"poiPoint\": \"point\",\n    \"province\": \"province\",\n    \"city\": \"city\",\n    \"district\": \"district\"\n}",
    },
    "realtime.thirdparty.odm-gd-match": {
        "_controller": "TaskPipelineRealTimeThirdPartyServiceController",
        "_method": "realtime_odm_gd_match",
        "_http": "POST",
        "_summary": "\u9ad8\u5fb7-POI\u5173\u8054",
        "_response": [{'name': 'code', 'type': 'String', 'description': '返回码，200表示成功'}, {'name': 'message', 'type': 'String', 'description': '提示信息'}, {'name': 'data.pipelineCode', 'type': 'String', 'description': '输出模型编码'}, {'name': 'data.outPropertyCode', 'type': 'String', 'description': '输出资产编码'}, {'name': 'data.taskStatus', 'type': 'Integer', 'description': '流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止'}, {'name': 'data.errorMsg', 'type': 'String', 'description': '错误信息（仅当状态为失败时返回）'}, {'name': 'data.filedList[].filedName', 'type': 'String', 'description': '字段名称'}, {'name': 'data.filedList[].isModelFiled', 'type': 'Boolean', 'description': '是否模型字段，默认false'}],
        "fields": [
            {"name": "pointData", "type": "List<Map<String, Object>>", "required": True, "description": "\u552e\u70b9\u6570\u636e\u5217\u8868\uff0c\u5176\u4e2d code \u548c point \u5b57\u6bb5\u5fc5\u987b\u5b58\u5728\uff0cpoint \u683c\u5f0f\u4e3a WKT \u683c\u5f0f", "example": "[{\"code\":\"point_001\",\"name\":\"\u6d4b\u8bd5\u70b9\",\"point\":\"POINT(116.3 39.9)\"}]"},
            {"name": "pointName", "type": "String", "required": True, "description": "\u552e\u70b9\u540d\u79f0\u5b57\u6bb5", "example": "name"},
            {"name": "address", "type": "String", "required": True, "description": "\u5730\u5740\u5b57\u6bb5", "example": "address"},
            {"name": "point", "type": "String", "required": True, "description": "\u7ecf\u7eac\u5ea6\u5b57\u6bb5", "example": "point"}
        ],
        "example": "{\n    \"pointData\": [\n        {\n            \"code\": \"p1\",\n            \"name\": \"\u6d4b\u8bd5\u70b9\",\n            \"point\": \"POINT(116.3 39.9)\"\n        }\n    ],\n    \"pointName\": \"pointName\",\n    \"address\": \"\u5317\u4eac\u5e02\u671d\u9633\u533a\",\n    \"point\": \"point\"\n}",
    },
}


def _fmt_help(schema):
    """Format a schema dict into help text with Chinese descriptions."""
    lines = []
    lines.append("\b")
    ctrl = schema.get("_controller", "")
    method = schema.get("_method", "")
    http = schema.get("_http", "POST")
    if ctrl and method:
        lines.append(f"\u63a5\u53e3: {ctrl}/{method}")
        lines.append(f"\u8bf7\u6c42\u65b9\u5f0f: {http}")
    lines.append("\u63a5\u53e3\u63cf\u8ff0: " + schema.get("_summary", schema.get("name", "")))
    desc = schema.get("_desc", "")
    if desc:
        lines.append("\u8be6\u7ec6\u63cf\u8ff0: " + desc)
    resp = schema.get("_response", [])
    if resp:
        lines.append("")
        lines.append("\b")
        lines.append("\u8fd4\u56de\u53c2\u6570:")
        for f in resp:
            lines.append(f"  - {f['name']} [{f['type']}]")
            lines.append(f"    \u5b57\u6bb5\u63cf\u8ff0: {f['description']}")
    if schema.get("fields"):
        lines.append("")
        lines.append("\b")
        lines.append("\u53c2\u6570:")
        for f in schema.get("fields", []):
            req = "\u5fc5\u586b" if f["required"] else "\u53ef\u9009"
            lines.append(f"  - {f['name']} [{f['type']}] [{req}]")
            lines.append(f"    \u5b57\u6bb5\u63cf\u8ff0: {f['description']}")
            if "example" in f:
                lines.append(f"    \u793a\u4f8b: {f['example']}")
    if "example" in schema:
        lines.append("")
        lines.append("\b")
        lines.append("\u63a5\u53e3\u8bf7\u6c42\u793a\u4f8b:")
        lines.append("  " + schema["example"])
    return "\n".join(lines)
