"""Session management for tracking API calls and task states."""

import json
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional
from uuid import uuid4

from gogeo.common_task.core.project import get_project

SESSION_DIR = Path.home() / ".gogeo-cli" / "common-task" / "sessions"
SESSION_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class TaskRecord:
    """Tracks a single task execution."""
    task_id: str
    action: str
    endpoint: str
    status: str = "pending"
    result: Optional[dict] = None
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = time.strftime("%Y-%m-%d %H:%M:%S")
            self.updated_at = self.created_at


@dataclass
class Session:
    """A session tracks multiple task records."""
    session_id: str = ""
    name: str = ""
    created_at: str = ""
    tasks: list = field(default_factory=list)

    def __post_init__(self):
        if not self.session_id:
            self.session_id = str(uuid4())[:8]
        if not self.created_at:
            self.created_at = time.strftime("%Y-%m-%d %H:%M:%S")
        if not self.name:
            self.name = f"session-{self.session_id}"

    def add_task(self, action: str, endpoint: str) -> TaskRecord:
        record = TaskRecord(task_id=str(uuid4())[:8], action=action, endpoint=endpoint)
        self.tasks.append(asdict(record))
        return record

    def update_task(self, task_id: str, status: str, result: Optional[dict] = None):
        for t in self.tasks:
            if t["task_id"] == task_id:
                t["status"] = status
                t["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
                if result is not None:
                    t["result"] = result
                break

    def to_dict(self) -> dict:
        return asdict(self)


def _session_path(session_id: str) -> Path:
    return SESSION_DIR / f"{session_id}.json"


def create_session(name: str = "") -> Session:
    session = Session(name=name)
    _session_path(session.session_id).write_text(json.dumps(session.to_dict(), indent=2))
    return session


def load_session(session_id: str) -> Optional[Session]:
    path = _session_path(session_id)
    if path.exists():
        data = json.loads(path.read_text())
        s = Session(**data)
        return s
    return None


def save_session(session: Session) -> None:
    _session_path(session.session_id).write_text(json.dumps(session.to_dict(), indent=2))


def list_sessions() -> list:
    sessions = []
    for f in SESSION_DIR.glob("*.json"):
        try:
            data = json.loads(f.read_text())
            sessions.append({"session_id": data["session_id"], "name": data["name"], "created_at": data["created_at"], "task_count": len(data.get("tasks", []))})
        except Exception:
            pass
    return sessions


def get_active_session() -> Optional[Session]:
    marker = SESSION_DIR / "active"
    if marker.exists():
        session_id = marker.read_text().strip()
        return load_session(session_id)
    return None


def set_active_session(session_id: str) -> Optional[Session]:
    session = load_session(session_id)
    if session:
        (SESSION_DIR / "active").write_text(session_id)
    return session


def clear_active_session() -> None:
    marker = SESSION_DIR / "active"
    if marker.exists():
        marker.unlink()
