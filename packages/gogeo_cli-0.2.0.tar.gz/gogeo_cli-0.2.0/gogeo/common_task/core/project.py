"""Project management for common-task CLI."""

import json
import os
import time
import click
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


CONFIG_DIR = Path.home() / ".gogeo-cli" / "common-task"
CONFIG_FILE = CONFIG_DIR / "project.json"

DEFAULT_API_URL = "https://gogeo.topprismdata.com/prod-gogeo-api"
ENV_API_CODE = "gogeoOpenApiCode"


@dataclass
class ProjectConfig:
    """Holds connection settings."""
    apiUrl: str = DEFAULT_API_URL
    openApiCode: Optional[str] = None
    last_updated: str = ""

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data = asdict(self)
        data["last_updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
        CONFIG_FILE.write_text(json.dumps(data, indent=2))

    @classmethod
    def load(cls) -> "ProjectConfig":
        if CONFIG_FILE.exists():
            data = json.loads(CONFIG_FILE.read_text())
            return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
        return cls()


def get_project() -> ProjectConfig:
    return ProjectConfig.load()


def init_project(api_url: str, open_api_code: Optional[str] = None) -> ProjectConfig:
    config = ProjectConfig(apiUrl=api_url, openApiCode=open_api_code)
    config.save()
    return config


def update_project(**kwargs) -> ProjectConfig:
    config = ProjectConfig.load()
    for key, value in kwargs.items():
        if key in config.__dataclass_fields__:
            setattr(config, key, value)
    config.save()
    return config


def resolve_open_api_code() -> str:
    """
    Resolve openApiCode with priority:
    1. Config file
    2. Environment variable gogeoOpenApiCode
    3. Prompt user and save to config
    """
    config = get_project()
    if config.openApiCode:
        return config.openApiCode

    env_code = os.environ.get(ENV_API_CODE)
    if env_code:
        return env_code

    # Prompt user
    code = click.prompt("openApiCode not found in config or environment. Please enter your openApiCode", type=str)
    if code:
        config.openApiCode = code
        config.save()
    return code
