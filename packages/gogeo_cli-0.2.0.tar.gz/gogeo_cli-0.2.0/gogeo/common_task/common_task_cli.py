#!/usr/bin/env python3
"""
gogeo-cli - CLI for common-task business APIs.

Config: apiUrl (default: https://gogeo.topprismdata.com/prod-gogeo-api) + openApiCode
Headers: accessType=GOGEO_SERVICE_API (fixed), openApiCode (from config/env)
Base path: /api/v3/task

Command Groups:
    project   - Connection configuration
    data      - Text/POI/duplicate-marking APIs
    spatial   - Spatial analysis & calculation APIs
    operation - Data operation tool APIs
    model     - Model calculation APIs
    resource  - Resource planning APIs
    base      - Base GIS service APIs
    thirdparty - Third-party integrations (Amap, Tencent)
    realtime  - Synchronous variants of all above
    export    - Export results (JSON/CSV)
    repl      - Interactive REPL mode
"""

import cmd
import json
import os
import sys
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from gogeo.common_task.core.project import get_project, init_project, update_project, resolve_open_api_code
from gogeo.common_task.core.client import TaskAPIClient
from gogeo.common_task.core.export import export_json, export_csv
from gogeo.common_task.utils.formatter import format_output
from gogeo.common_task.core.api_schemas import SCHEMAS, _fmt_help


def get_client() -> TaskAPIClient:
    config = get_project()
    api_code = resolve_open_api_code()
    return TaskAPIClient(
        api_url=config.apiUrl,
        open_api_code=api_code,
        timeout=config.default_timeout if hasattr(config, 'default_timeout') else 300,
    )


# ============================================================================
# CLI Entry
# ============================================================================

import click


@click.group(invoke_without_command=True)
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
@click.pass_context
def cli(ctx, json_mode):
    """CLI for common-task business APIs (/api/v3/task/api/ and /realtime/)."""
    ctx.ensure_object(dict)
    ctx.obj["json"] = json_mode
    if ctx.invoked_subcommand is None:
        click.echo(cli.__doc__.strip())


# ============================================================================
# Project
# ============================================================================

@cli.group()
def project():
    """Connection configuration."""
    pass


@project.command("init")
@click.argument("api_url", required=False)
@click.option("--open-api-code", help="User authorization code")
@click.option("--json", "json_mode", is_flag=True)
def project_init(api_url, open_api_code, json_mode):
    """Initialize connection to server."""
    url = api_url or "https://gogeo.topprismdata.com/prod-gogeo-api"
    config = init_project(url, open_api_code)
    click.echo(format_output({
        "status": "initialized",
        "apiUrl": config.apiUrl,
        "openApiCode_set": bool(open_api_code),
    }, json_mode))


@project.command("config")
@click.option("--api-url", help="Update API URL")
@click.option("--open-api-code", help="Update authorization code")
@click.option("--json", "json_mode", is_flag=True)
def project_config(api_url, open_api_code, json_mode):
    """View or update connection config."""
    kwargs = {}
    if api_url:
        kwargs["apiUrl"] = api_url
    if open_api_code:
        kwargs["openApiCode"] = open_api_code
    config = update_project(**kwargs) if kwargs else get_project()
    click.echo(format_output({
        "apiUrl": config.apiUrl,
        "openApiCode_set": bool(config.openApiCode),
    }, json_mode))


# ============================================================================
# Helper: call API with --data JSON
# ============================================================================

def _api_call(endpoint: str, data_str: str, json_mode: bool) -> None:
    client = get_client()
    result = client.post(endpoint, data=json.loads(data_str))
    click.echo(format_output(result, json_mode))


def _h(key: str) -> str:
    """Generate help text from schema, fallback to generic description."""
    if key in SCHEMAS:
        return _fmt_help(SCHEMAS[key])
    return "Request body as JSON string."


# ============================================================================
# Data API  (/api/v3/task/api/)
# ============================================================================

@cli.group()
def data():
    """Text processing, POI matching, duplicate marking APIs."""
    pass


@data.command("text-handling", help=_h("data.text-handling"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_text_handling(data, json_mode):
    """Text processing."""
    _api_call("/api/v3/task/api/text_handling", data, json_mode)


@data.command("poi-match", help=_h("data.poi-match"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_poi_match(data, json_mode):
    """POI Tencent matching."""
    _api_call("/api/v3/task/api/poi_matchHandling", data, json_mode)


@data.command("ka-match", help=_h("data.ka-match"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_ka_match(data, json_mode):
    """KA recognition matching."""
    _api_call("/api/v3/task/api/ka_matchHandling", data, json_mode)


@data.command("duplicate-marking", help=_h("data.duplicate-marking"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_duplicate_marking(data, json_mode):
    """Duplicate marking."""
    _api_call("/api/v3/task/api/duplicate_marking", data, json_mode)


@data.command("text-concat", help=_h("data.text-concat"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_text_concat(data, json_mode):
    """Text concatenation."""
    _api_call("/api/v3/task/api/text_concatenation", data, json_mode)


@data.command("exact-match", help=_h("data.exact-match"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_exact_match(data, json_mode):
    """Exact matching."""
    _api_call("/api/v3/task/api/exact_match", data, json_mode)


@data.command("similarity", help=_h("data.similarity"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_similarity(data, json_mode):
    """Similarity processing."""
    _api_call("/api/v3/task/api/similarity_processing", data, json_mode)


@data.command("address-parse", help=_h("data.address-parse"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_address_parse(data, json_mode):
    """Address parsing."""
    _api_call("/api/v3/task/api/address_parsing", data, json_mode)


@data.command("reverse-address-parse", help=_h("data.reverse-address-parse"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_reverse_address_parse(data, json_mode):
    """Reverse address parsing."""
    _api_call("/api/v3/task/api/reverse_address_parsing", data, json_mode)


@data.command("batch-status", help=_h("data.batch-status"))
@click.option("--data", required=True, help="Request body as JSON string")
@click.option("--json", "json_mode", is_flag=True, help="Output in JSON format")
def data_batch_status(data, json_mode):
    """Batch query task status."""
    _api_call("/api/v3/task/api/batch_query_task_status", data, json_mode)


# ============================================================================
# Spatial API
# ============================================================================

@cli.group()
def spatial():
    """Spatial analysis & calculation APIs."""
    pass


@spatial.group()
def analysis():
    """Spatial analysis operations."""
    pass


@analysis.command("projection-area", help=_h("spatial.analysis.projection-area"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_projection_area(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/projection_area_calculation", data, json_mode)


@analysis.command("fence-buffer", help=_h("spatial.analysis.fence-buffer"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_fence_buffer(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/fence_broad_buffer", data, json_mode)


@analysis.command("point-cluster", help=_h("spatial.analysis.point-cluster"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_point_cluster(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/point_cluster_analysis", data, json_mode)


@analysis.command("fence-cluster", help=_h("spatial.analysis.fence-cluster"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_fence_cluster(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/fence_cluster_analysis", data, json_mode)


@analysis.command("belonging-area-v2", help=_h("spatial.analysis.belonging-area-v2"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_belonging_area_v2(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/belonging_area_generate_v2", data, json_mode)


@analysis.command("affiliation-area-v1", help=_h("spatial.analysis.affiliation-area-v1"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_affiliation_area_v1(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/affiliation_area_generate_v1_custom_polygon", data, json_mode)


@analysis.command("cluster-center", help=_h("spatial.analysis.cluster-center"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_cluster_center(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/cluster_center", data, json_mode)


@analysis.command("equal-value-split", help=_h("spatial.analysis.equal-value-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_equal_value_split(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/equal_value_split_v2", data, json_mode)


@analysis.command("area-split", help=_h("spatial.analysis.area-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_area_split(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/area_split_plan", data, json_mode)


@analysis.command("potential-split", help=_h("spatial.analysis.potential-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_potential_split(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/potential_area_split_plan", data, json_mode)


@analysis.command("fence-crossing", help=_h("spatial.analysis.fence-crossing"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_fence_crossing(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/fence_crossing", data, json_mode)


@analysis.command("line-buffer", help=_h("spatial.analysis.line-buffer"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_line_buffer(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/line_buffer", data, json_mode)


@analysis.command("hexagon-split", help=_h("spatial.analysis.hexagon-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_hexagon_split(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/hexagon_fence_split_polygon", data, json_mode)


@analysis.command("grid-split", help=_h("spatial.analysis.grid-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_grid_split(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/grid_fence_split_polygon", data, json_mode)


@analysis.command("kmeans", help=_h("spatial.analysis.kmeans"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_kmeans(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/point_kmeans", data, json_mode)


@analysis.command("random-sample", help=_h("spatial.analysis.random-sample"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_random_sample(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/fence_random_sample", data, json_mode)


@analysis.command("random-points", help=_h("spatial.analysis.random-points"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_random_points(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/point_random_create", data, json_mode)


@analysis.command("potential-classification", help=_h("spatial.analysis.potential-classification"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sa_potential_classification(data, json_mode):
    _api_call("/api/v3/task/api/spatialAnalysis/potential_classification_v2_point", data, json_mode)


# ---- Spatial Calculation ----

@spatial.group()
def calculation():
    """Spatial calculation operations."""
    pass


@calculation.command("point-outside-fence", help=_h("spatial.calculation.point-outside-fence"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_point_outside_fence(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/point_outside_fence", data, json_mode)


@calculation.command("scatter-fence", help=_h("spatial.calculation.scatter-fence"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_scatter_fence(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/scatter_points_build_fence", data, json_mode)


@calculation.command("point-in-fence", help=_h("spatial.calculation.point-in-fence"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_point_in_fence(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/point_inside_fence", data, json_mode)


@calculation.command("fence-of-point", help=_h("spatial.calculation.fence-of-point"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_fence_of_point(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/fence_of_point", data, json_mode)


@calculation.command("fence-without-point", help=_h("spatial.calculation.fence-without-point"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_fence_without_point(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/fence_without_point", data, json_mode)


@calculation.command("fence-intersection-area", help=_h("spatial.calculation.fence-intersection-area"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_fence_intersection_area(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/fence_intersection_area", data, json_mode)


@calculation.command("belonging-area-v1", help=_h("spatial.calculation.belonging-area-v1"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_belonging_area_v1(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/belonging_area_generate_v1", data, json_mode)


@calculation.command("voronoi", help=_h("spatial.calculation.voronoi"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_voronoi(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/voronoi_diagram", data, json_mode)


@calculation.command("scu-h3", help=_h("spatial.calculation.scu-h3"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_scu_h3(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/scu_generate_by_h3", data, json_mode)


@calculation.command("scu-geohash", help=_h("spatial.calculation.scu-geohash"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_scu_geohash(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/scu_geohash_generate", data, json_mode)


@calculation.command("scu-h3-merge", help=_h("spatial.calculation.scu-h3-merge"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_scu_h3_merge(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/scu_h3_merge", data, json_mode)


@calculation.command("scu-s2", help=_h("spatial.calculation.scu-s2"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_scu_s2(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/scu_s2_standard_generate", data, json_mode)


@calculation.command("scu-admin", help=_h("spatial.calculation.scu-admin"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_scu_admin(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/scu_admin_division_generate", data, json_mode)


@calculation.command("fence-contain", help=_h("spatial.calculation.fence-contain"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_fence_contain(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/fence_contain_fence", data, json_mode)


@calculation.command("fence-merge", help=_h("spatial.calculation.fence-merge"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_fence_merge(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/fence_merge_area", data, json_mode)


@calculation.command("line-intersection", help=_h("spatial.calculation.line-intersection"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_line_intersection(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/line_intersection_point", data, json_mode)


@calculation.command("h3-split-merge", help=_h("spatial.calculation.h3-split-merge"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_h3_split_merge(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/h3SplitMergeGenerate", data, json_mode)


@calculation.command("center-point", help=_h("spatial.calculation.center-point"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_center_point(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/center_point_compute", data, json_mode)


@calculation.command("fence-contain-relation", help=_h("spatial.calculation.fence-contain-relation"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_fence_contain_relation(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/fence_contain_relation", data, json_mode)


@calculation.command("point-centroid", help=_h("spatial.calculation.point-centroid"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_point_centroid(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/point_centroid", data, json_mode)


@calculation.command("line-split-fence", help=_h("spatial.calculation.line-split-fence"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_line_split_fence(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/line_split_fence", data, json_mode)


@calculation.command("fence-equalization", help=_h("spatial.calculation.fence-equalization"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def sc_fence_equalization(data, json_mode):
    _api_call("/api/v3/task/api/spatialCalculation/fence_equalization", data, json_mode)


# ============================================================================
# Operation API
# ============================================================================

@cli.group()
def operation():
    """Data operation tool APIs."""
    pass


@operation.command("filter", help=_h("operation.filter"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_filter(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/filter", data, json_mode)


@operation.command("duplicate-mark", help=_h("operation.duplicate-mark"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_duplicate_mark(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/duplicate_mark", data, json_mode)


@operation.command("text-concat", help=_h("operation.text-concat"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_text_concat(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/text_concat", data, json_mode)


@operation.command("data-flow", help=_h("operation.data-flow"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_data_flow(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/data_flow", data, json_mode)


@operation.command("group", help=_h("operation.group"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_group(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/group_data", data, json_mode)


@operation.command("intersect", help=_h("operation.intersect"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_intersect(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/intersect_compute", data, json_mode)


@operation.command("ka-handling", help=_h("operation.ka-handling"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_ka_handling(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/ka_handling", data, json_mode)


@operation.command("subsection-mark", help=_h("operation.subsection-mark"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_subsection_mark(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/subsection_mark", data, json_mode)


@operation.command("normalized-expr", help=_h("operation.normalized-expr"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_normalized_expr(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/normalized_expr", data, json_mode)


@operation.command("one-id", help=_h("operation.one-id"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_one_id(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/one_id_compute", data, json_mode)


@operation.command("data-merge", help=_h("operation.data-merge"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_data_merge(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/data_merge", data, json_mode)


@operation.command("text-similarity", help=_h("operation.text-similarity"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def op_text_similarity(data, json_mode):
    _api_call("/api/v3/task/api/operationTool/text_similarity", data, json_mode)


# ============================================================================
# Model API
# ============================================================================

@cli.group()
def model():
    """Model calculation APIs."""
    pass


@model.command("reachable-range", help=_h("model.reachable-range"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def m_reachable_range(data, json_mode):
    _api_call("/api/v3/task/api/modelCalculation/reachableRange", data, json_mode)


@model.command("scu-specify", help=_h("model.scu-specify"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def m_scu_specify(data, json_mode):
    _api_call("/api/v3/task/api/modelCalculation/scu_specify_generate", data, json_mode)


@model.command("solitary-screen", help=_h("model.solitary-screen"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def m_solitary_screen(data, json_mode):
    _api_call("/api/v3/task/api/modelCalculation/solitary_screen_data", data, json_mode)


@model.command("industry-cluster", help=_h("model.industry-cluster"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def m_industry_cluster(data, json_mode):
    _api_call("/api/v3/task/api/modelCalculation/industry_cluster", data, json_mode)


@model.command("radiate-circle", help=_h("model.radiate-circle"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def m_radiate_circle(data, json_mode):
    _api_call("/api/v3/task/api/modelCalculation/business_radiate_circle", data, json_mode)


@model.command("belonging-area", help=_h("model.belonging-area"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def m_belonging_area(data, json_mode):
    _api_call("/api/v3/task/api/modelCalculation/belong_area_generate", data, json_mode)


# ============================================================================
# Resource API
# ============================================================================

@cli.group()
def resource():
    """Resource planning APIs."""
    pass


@resource.command("logistics-planning-v1", help=_h("resource.logistics-planning-v1"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_logistics_v1(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/logistics_planning_v1", data, json_mode)


@resource.command("sale-group-planning", help=_h("resource.sale-group-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_sales_group(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/sale_group_planning", data, json_mode)


@resource.command("sale-visit-planning", help=_h("resource.sale-visit-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_visit_planning(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/sale_visit_planning", data, json_mode)


@resource.command("logistics-planning", help=_h("resource.logistics-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_logistics(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/logistics_planning", data, json_mode)


@resource.command("logistics-total-planning", help=_h("resource.logistics-total-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_logistics_total(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/logistics_total_planning", data, json_mode)


@resource.command("auto-area-planning", help=_h("resource.auto-area-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_area_planning(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/auto_area_planning", data, json_mode)


@resource.command("service-day-week-division", help=_h("resource.service-day-week-division"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_service_day_week(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/serviceDayWeekDivision", data, json_mode)


@resource.command("service-route-planning", help=_h("resource.service-route-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_service_route(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/serviceRoutePlanning", data, json_mode)


@resource.command("vehicle-sales-planning", help=_h("resource.vehicle-sales-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_vehicle_sales(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/vehicleSalesPlanning", data, json_mode)


@resource.command("route-replay", help=_h("resource.route-replay"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_route_replay(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/route_replay", data, json_mode)


@resource.command("generate-navigation-route-v1", help=_h("resource.generate-navigation-route-v1"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def r_navigation_route(data, json_mode):
    _api_call("/api/v3/task/api/resourcePlanning/generate_navigation_route_v1", data, json_mode)


# ============================================================================
# Base API
# ============================================================================

@cli.group()
def base():
    """Base GIS service APIs."""
    pass


@base.command("point-square", help=_h("base.point-square"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_point_square(data, json_mode):
    _api_call("/api/v3/task/api/baseService/point_generate_square", data, json_mode)


@base.command("point-hexagon", help=_h("base.point-hexagon"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_point_hexagon(data, json_mode):
    _api_call("/api/v3/task/api/baseService/point_generate_hexagon", data, json_mode)


@base.command("point-circle", help=_h("base.point-circle"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_point_circle(data, json_mode):
    _api_call("/api/v3/task/api/baseService/point_generate_circle", data, json_mode)


@base.command("fence-extract", help=_h("base.fence-extract"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_fence_extract(data, json_mode):
    _api_call("/api/v3/task/api/baseService/fence_coordinate_extraction", data, json_mode)


@base.command("line-extract", help=_h("base.line-extract"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_line_extract(data, json_mode):
    _api_call("/api/v3/task/api/baseService/line_coordinate_extraction", data, json_mode)


@base.command("coord-convert", help=_h("base.coord-convert"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_coord_convert(data, json_mode):
    _api_call("/api/v3/task/api/baseService/coordinate_convert", data, json_mode)


@base.command("line-coord-convert", help=_h("base.line-coord-convert"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_line_coord_convert(data, json_mode):
    _api_call("/api/v3/task/api/baseService/line_coordinate_convert", data, json_mode)


@base.command("fence-coord-convert", help=_h("base.fence-coord-convert"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_fence_coord_convert(data, json_mode):
    _api_call("/api/v3/task/api/baseService/fence_coordinate_convert", data, json_mode)


@base.command("line-thin", help=_h("base.line-thin"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_line_thin(data, json_mode):
    _api_call("/api/v3/task/api/baseService/line_coordinate_thinning", data, json_mode)


@base.command("fence-thin", help=_h("base.fence-thin"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_fence_thin(data, json_mode):
    _api_call("/api/v3/task/api/baseService/fence_coordinate_thinning", data, json_mode)


@base.command("track-generate", help=_h("base.track-generate"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_track_generate(data, json_mode):
    _api_call("/api/v3/task/api/baseService/track_generate", data, json_mode)


@base.command("point-rarefy", help=_h("base.point-rarefy"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_point_rarefy(data, json_mode):
    _api_call("/api/v3/task/api/baseService/point_rarefy", data, json_mode)


@base.command("fence-boundary", help=_h("base.fence-boundary"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def b_fence_boundary(data, json_mode):
    _api_call("/api/v3/task/api/baseService/fence_boundary", data, json_mode)


# ============================================================================
# Third-Party API
# ============================================================================

@cli.group()
def thirdparty():
    """Third-party integrations (Amap, Tencent)."""
    pass


@thirdparty.command("retailer-access", help=_h("thirdparty.retailer-access"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_retailer_access(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/retailer_model_access", data, json_mode)


@thirdparty.command("retailer-scoring", help=_h("thirdparty.retailer-scoring"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_retailer_scoring(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/retailer_model_scoring", data, json_mode)


@thirdparty.command("capacity-estimation", help=_h("thirdparty.capacity-estimation"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_capacity_estimation(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/market_capacity_estimation", data, json_mode)


@thirdparty.command("spacing-recommend", help=_h("thirdparty.spacing-recommend"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_spacing_recommend(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/market_spacing_recommendation", data, json_mode)


@thirdparty.command("retail-merchant-upload", help=_h("thirdparty.retail-merchant-upload"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_retail_merchant_upload(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/retail_commercial_upload", data, json_mode)


@thirdparty.command("retail-merchant-info", help=_h("thirdparty.retail-merchant-info"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_retail_merchant_info(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/retail_commercial_info", data, json_mode)


@thirdparty.command("duty-grid-upload", help=_h("thirdparty.duty-grid-upload"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_duty_grid_upload(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/duty_grid_upload", data, json_mode)


@thirdparty.command("duty-grid-info", help=_h("thirdparty.duty-grid-info"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_duty_grid_info(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/duty_grid_info", data, json_mode)


@thirdparty.command("odm-gd-match", help=_h("thirdparty.odm-gd-match"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_odm_gd_match(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/odm_gd_match", data, json_mode)


@thirdparty.command("tx-poi-match-v2", help=_h("thirdparty.tx-poi-match-v2"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_tx_poi_match_v2(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/tx_poi_match_v2", data, json_mode)


@thirdparty.command("tx-poi-multi-v2", help=_h("thirdparty.tx-poi-multi-v2"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_tx_poi_multi_v2(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/tx_poi_mutil_policy_match_v2", data, json_mode)


@thirdparty.command("tx-poi-multi", help=_h("thirdparty.tx-poi-multi"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_tx_poi_multi(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/tx_poi_mutil_policy_match", data, json_mode)


@thirdparty.command("odm-uncontrolled", help=_h("thirdparty.odm-uncontrolled"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_odm_uncontrolled(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/odm_gd_uncontrolled", data, json_mode)


@thirdparty.command("potential-area-split", help=_h("thirdparty.potential-area-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_potential_area_split(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/potential_area_split_plan", data, json_mode)


@thirdparty.command("customer-flow-items", help=_h("thirdparty.customer-flow-items"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_cf_items(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/customerFlowServiceItems", data, json_mode)


@thirdparty.command("customer-flow-competitors", help=_h("thirdparty.customer-flow-competitors"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_cf_competitors(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/customerFlowCompetitorStores", data, json_mode)


@thirdparty.command("customer-flow-report", help=_h("thirdparty.customer-flow-report"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_cf_report(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/customerFlowDataReports", data, json_mode)


@thirdparty.command("customer-flow-pedestrian", help=_h("thirdparty.customer-flow-pedestrian"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_cf_pedestrian(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/customer_flow_business_district_pedestrian_flow_analysis", data, json_mode)


@thirdparty.command("customer-flow-competition", help=_h("thirdparty.customer-flow-competition"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_cf_competition(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/customer_flow_business_district_competition_intensity_analysis", data, json_mode)


@thirdparty.command("lbs-passenger-point", help=_h("thirdparty.lbs-passenger-point"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_lbs_passenger_point(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/lbs_passenger_portrait_point", data, json_mode)


@thirdparty.command("lbs-passenger-area", help=_h("thirdparty.lbs-passenger-area"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def tp_lbs_passenger_area(data, json_mode):
    _api_call("/api/v3/task/api/thirdPartyService/lbs_passenger_portrait_area", data, json_mode)


# ============================================================================
# Realtime API
# ============================================================================

@cli.group()
def realtime():
    """Synchronous (real-time) variants of all API groups."""
    pass


# -- realtime spatial analysis --
@realtime.group()
def spatial():
    """Realtime spatial operations."""
    pass


@spatial.group()
def analysis():
    """Realtime spatial analysis."""
    pass


_RT_SA_PREFIX = "/api/v3/task/api/realtime/spatialAnalysis"


def _rt_sa(endpoint_suffix: str, data: str, json_mode: bool):
    _api_call(f"{_RT_SA_PREFIX}/{endpoint_suffix}", data, json_mode)


@analysis.command("projection-area", help=_h("realtime.spatial.analysis.projection-area"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_projection_area(data, json_mode):
    _rt_sa("realtime_projection_area_calculation", data, json_mode)


@analysis.command("address-parse", help=_h("realtime.spatial.analysis.address-parse"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_address_parse(data, json_mode):
    _rt_sa("realtime_address_parsing", data, json_mode)


@analysis.command("reverse-address-parse", help=_h("realtime.spatial.analysis.reverse-address-parse"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_reverse_address(data, json_mode):
    _rt_sa("realtime_reverse_address_parsing", data, json_mode)


@analysis.command("point-cluster", help=_h("realtime.spatial.analysis.point-cluster"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_point_cluster(data, json_mode):
    _rt_sa("realtime_point_cluster_analysis", data, json_mode)


@analysis.command("fence-cluster", help=_h("realtime.spatial.analysis.fence-cluster"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_fence_cluster(data, json_mode):
    _rt_sa("realtime_fence_cluster_analysis", data, json_mode)


@analysis.command("affiliation-area-v1", help=_h("realtime.spatial.analysis.affiliation-area-v1"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_affiliation_v1(data, json_mode):
    _rt_sa("realtime_affiliation_area_generate_v1_custom_polygon", data, json_mode)


@analysis.command("potential-classification", help=_h("realtime.spatial.analysis.potential-classification"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_potential_classification(data, json_mode):
    _rt_sa("realtime_potential_classification_v2_point", data, json_mode)


@analysis.command("belonging-area-v2", help=_h("realtime.spatial.analysis.belonging-area-v2"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_belonging_v2(data, json_mode):
    _rt_sa("realtime_belonging_area_gen_v2", data, json_mode)


@analysis.command("random-sample", help=_h("realtime.spatial.analysis.random-sample"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_random_sample(data, json_mode):
    _rt_sa("realtime_fence_random_sample", data, json_mode)


@analysis.command("kmeans", help=_h("realtime.spatial.analysis.kmeans"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_kmeans(data, json_mode):
    _rt_sa("realtime_point_kmeans", data, json_mode)


@analysis.command("fence-crossing", help=_h("realtime.spatial.analysis.fence-crossing"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_fence_crossing(data, json_mode):
    _rt_sa("realtime_fence_crossing", data, json_mode)


@analysis.command("line-buffer", help=_h("realtime.spatial.analysis.line-buffer"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_line_buffer(data, json_mode):
    _rt_sa("realtime_line_buffer", data, json_mode)


@analysis.command("area-split", help=_h("realtime.spatial.analysis.area-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_area_split(data, json_mode):
    _rt_sa("realtime_area_split_plan", data, json_mode)


@analysis.command("potential-split", help=_h("realtime.spatial.analysis.potential-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_potential_split(data, json_mode):
    _rt_sa("realtime_potential_area_split_plan", data, json_mode)


@analysis.command("equal-value-split", help=_h("realtime.spatial.analysis.equal-value-split"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sa_equal_value_split(data, json_mode):
    _rt_sa("realtime_equal_value_split_v2", data, json_mode)


# -- realtime spatial calculation --
@spatial.group()
def calculation():
    """Realtime spatial calculation."""
    pass


_RT_SC_PREFIX = "/api/v3/task/api/realtime/spatialCalculation"


def _rt_sc(suffix: str, data: str, json_mode: bool):
    _api_call(f"{_RT_SC_PREFIX}/{suffix}", data, json_mode)


@calculation.command("point-outside-fence", help=_h("realtime.spatial.calculation.point-outside-fence"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_point_outside(data, json_mode):
    _rt_sc("realtime_point_outside_fence", data, json_mode)


@calculation.command("scatter-fence", help=_h("realtime.spatial.calculation.scatter-fence"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_scatter_fence(data, json_mode):
    _rt_sc("realtime_scatter_points_build_fence", data, json_mode)


@calculation.command("point-in-fence", help=_h("realtime.spatial.calculation.point-in-fence"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_point_in_fence(data, json_mode):
    _rt_sc("realtime_point_inside_fence", data, json_mode)


@calculation.command("fence-of-point", help=_h("realtime.spatial.calculation.fence-of-point"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_fence_of_point(data, json_mode):
    _rt_sc("realtime_fence_of_point", data, json_mode)


@calculation.command("belonging-area-v1", help=_h("realtime.spatial.calculation.belonging-area-v1"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_belonging_v1(data, json_mode):
    _rt_sc("realtime_belonging_area_generate_v1", data, json_mode)


@calculation.command("fence-without-point", help=_h("realtime.spatial.calculation.fence-without-point"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_fence_without_point(data, json_mode):
    _rt_sc("realtime_fence_without_point", data, json_mode)


@calculation.command("fence-intersection-area", help=_h("realtime.spatial.calculation.fence-intersection-area"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_fence_intersection_area(data, json_mode):
    _rt_sc("realtime_fence_intersection_area", data, json_mode)


@calculation.command("fence-contain", help=_h("realtime.spatial.calculation.fence-contain"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_fence_contain(data, json_mode):
    _rt_sc("realtime_fence_contain_fence", data, json_mode)


@calculation.command("fence-merge", help=_h("realtime.spatial.calculation.fence-merge"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_fence_merge(data, json_mode):
    _rt_sc("realtime_fence_merge_area", data, json_mode)


@calculation.command("line-intersection", help=_h("realtime.spatial.calculation.line-intersection"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_line_intersection(data, json_mode):
    _rt_sc("realtime_line_intersection_point", data, json_mode)


@calculation.command("line-split-fence", help=_h("realtime.spatial.calculation.line-split-fence"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_line_split_fence(data, json_mode):
    _rt_sc("realtime_line_split_fence", data, json_mode)


@calculation.command("scu-h3-merge", help=_h("realtime.spatial.calculation.scu-h3-merge"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_scu_h3_merge(data, json_mode):
    _rt_sc("realtime_scu_h3_merge", data, json_mode)


@calculation.command("scu-s2", help=_h("realtime.spatial.calculation.scu-s2"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_scu_s2(data, json_mode):
    _rt_sc("realtime_scu_s2_standard_generate", data, json_mode)


@calculation.command("h3-split-merge", help=_h("realtime.spatial.calculation.h3-split-merge"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_h3_split_merge(data, json_mode):
    _rt_sc("realtime_h3_split_merge_generate", data, json_mode)


@calculation.command("scu-admin", help=_h("realtime.spatial.calculation.scu-admin"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_scu_admin(data, json_mode):
    _rt_sc("realtime_scu_admin_division_generate", data, json_mode)


@calculation.command("fence-buffer", help=_h("realtime.spatial.calculation.fence-buffer"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_fence_buffer(data, json_mode):
    _rt_sc("realtime_fence_broad_buffer", data, json_mode)


@calculation.command("point-centroid", help=_h("realtime.spatial.calculation.point-centroid"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_point_centroid(data, json_mode):
    _rt_sc("realtime_point_centroid", data, json_mode)


@calculation.command("fence-contain-relation", help=_h("realtime.spatial.calculation.fence-contain-relation"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_fence_contain_relation(data, json_mode):
    _rt_sc("realtime_fence_contain_relation", data, json_mode)


@calculation.command("center-point", help=_h("realtime.spatial.calculation.center-point"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_center_point(data, json_mode):
    _rt_sc("realtime_center_point_compute", data, json_mode)


@calculation.command("fence-equalization", help=_h("realtime.spatial.calculation.fence-equalization"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_fence_equalization(data, json_mode):
    _rt_sc("realtime_fence_equalization", data, json_mode)


@calculation.command("scu-h3", help=_h("realtime.spatial.calculation.scu-h3"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_sc_scu_h3(data, json_mode):
    _rt_sc("realtime_scu_generate_by_h3", data, json_mode)


# -- realtime base --
@realtime.group()
def base():
    """Realtime base services."""
    pass


_RT_BASE_PREFIX = "/api/v3/task/api/realtime/baseService"


def _rt_base(suffix: str, data: str, json_mode: bool):
    _api_call(f"{_RT_BASE_PREFIX}/{suffix}", data, json_mode)


@base.command("point-square", help=_h("realtime.base.point-square"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_square(data, json_mode):
    _rt_base("realtime_point_generate_square", data, json_mode)


@base.command("point-circle", help=_h("realtime.base.point-circle"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_circle(data, json_mode):
    _rt_base("realtime_point_generate_circle", data, json_mode)


@base.command("point-hexagon", help=_h("realtime.base.point-hexagon"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_hexagon(data, json_mode):
    _rt_base("realtime_point_generate_hexagon", data, json_mode)


@base.command("point-coord-convert", help=_h("realtime.base.point-coord-convert"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_point_convert(data, json_mode):
    _rt_base("realtime_point_coordinate_convert", data, json_mode)


@base.command("line-coord-convert", help=_h("realtime.base.line-coord-convert"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_line_convert(data, json_mode):
    _rt_base("realtime_line_coordinate_convert", data, json_mode)


@base.command("fence-coord-convert", help=_h("realtime.base.fence-coord-convert"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_fence_convert(data, json_mode):
    _rt_base("realtime_fence_coordinate_convert", data, json_mode)


@base.command("line-thin", help=_h("realtime.base.line-thin"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_line_thin(data, json_mode):
    _rt_base("realtime_line_coordinate_thinning", data, json_mode)


@base.command("fence-thin", help=_h("realtime.base.fence-thin"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_fence_thin(data, json_mode):
    _rt_base("realtime_fence_coordinate_thinning", data, json_mode)


@base.command("point-rarefy", help=_h("realtime.base.point-rarefy"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_point_rarefy(data, json_mode):
    _rt_base("realtime_point_rarefy", data, json_mode)


@base.command("fence-boundary", help=_h("realtime.base.fence-boundary"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_base_fence_boundary(data, json_mode):
    _rt_base("realtime_fence_boundary", data, json_mode)


# -- realtime resource --
@realtime.group()
def resource():
    """Realtime resource planning."""
    pass


_RT_RES_PREFIX = "/api/v3/task/api/realtime/resourcePlanning"


def _rt_res(suffix: str, data: str, json_mode: bool):
    _api_call(f"{_RT_RES_PREFIX}/{suffix}", data, json_mode)


@resource.command("realtime-route-replay", help=_h("realtime.resource.realtime-route-replay"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_res_route_replay(data, json_mode):
    _rt_res("realtime_route_replay", data, json_mode)


@resource.command("realtime-service-day-week-division", help=_h("realtime.resource.realtime-service-day-week-division"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_res_day_week(data, json_mode):
    _rt_res("realtime_service_day_week_division", data, json_mode)


@resource.command("realtime-service-route-planning", help=_h("realtime.resource.realtime-service-route-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_res_service_route(data, json_mode):
    _rt_res("realtime_service_route_planning", data, json_mode)


@resource.command("realtime-logistics-route-planning", help=_h("realtime.resource.realtime-logistics-route-planning"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_res_logistics(data, json_mode):
    _rt_res("realtime_logistics_route_planning", data, json_mode)


# -- realtime operation --
@realtime.group()
def operation():
    """Realtime operation tools."""
    pass


_RT_OP_PREFIX = "/api/v3/task/api/realtime/operationTool"


def _rt_op(suffix: str, data: str, json_mode: bool):
    _api_call(f"{_RT_OP_PREFIX}/{suffix}", data, json_mode)


@operation.command("text-handling", help=_h("realtime.operation.text-handling"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_text_handling(data, json_mode):
    _rt_op("realtime_text_handling", data, json_mode)


@operation.command("exact-match", help=_h("realtime.operation.exact-match"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_exact_match(data, json_mode):
    _rt_op("realtime_exact_match", data, json_mode)


@operation.command("similarity", help=_h("realtime.operation.similarity"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_similarity(data, json_mode):
    _rt_op("realtime_similarity_processing", data, json_mode)


@operation.command("ka-match", help=_h("realtime.operation.ka-match"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_ka_match(data, json_mode):
    _rt_op("realtime_ka_match_handling_v2", data, json_mode)


@operation.command("duplicate-mark", help=_h("realtime.operation.duplicate-mark"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_duplicate_mark(data, json_mode):
    _rt_op("realtime_duplicate_mark", data, json_mode)


@operation.command("text-concat", help=_h("realtime.operation.text-concat"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_text_concat(data, json_mode):
    _rt_op("realtime_text_concat", data, json_mode)


@operation.command("subsection-mark", help=_h("realtime.operation.subsection-mark"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_subsection_mark(data, json_mode):
    _rt_op("realtime_subsection_mark", data, json_mode)


@operation.command("normalized-expr", help=_h("realtime.operation.normalized-expr"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_normalized(data, json_mode):
    _rt_op("realtime_normalized_expr", data, json_mode)


@operation.command("text-similarity", help=_h("realtime.operation.text-similarity"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_op_text_similarity(data, json_mode):
    _rt_op("realtime_text_similarity", data, json_mode)


# -- realtime model --
@realtime.group()
def model():
    """Realtime model calculation."""
    pass


_RT_MODEL_PREFIX = "/api/v3/task/api/realtime/modelCalculation"


def _rt_model(suffix: str, data: str, json_mode: bool):
    _api_call(f"{_RT_MODEL_PREFIX}/{suffix}", data, json_mode)


@model.command("industry-cluster", help=_h("realtime.model.industry-cluster"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_m_industry_cluster(data, json_mode):
    _rt_model("realtime_industry_cluster", data, json_mode)


@model.command("scu-geohash", help=_h("realtime.model.scu-geohash"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_m_scu_geohash(data, json_mode):
    _rt_model("realtime_scu_geohash_generate", data, json_mode)


@model.command("radiate-circle", help=_h("realtime.model.radiate-circle"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_m_radiate_circle(data, json_mode):
    _rt_model("realtime_business_radiate_circle", data, json_mode)


@model.command("reachable-range", help=_h("realtime.model.reachable-range"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_m_reachable_range(data, json_mode):
    _rt_model("realtime_reachable_range", data, json_mode)


@model.command("solitary-screen", help=_h("realtime.model.solitary-screen"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_m_solitary_screen(data, json_mode):
    _rt_model("realtime_solitary_screen_data", data, json_mode)


# -- realtime thirdparty --
@realtime.group()
def thirdparty():
    """Realtime third-party services."""
    pass


_RT_TP_PREFIX = "/api/v3/task/api/realtime/thirdPartyService"


def _rt_tp(suffix: str, data: str, json_mode: bool):
    _api_call(f"{_RT_TP_PREFIX}/{suffix}", data, json_mode)


@thirdparty.command("poi-match", help=_h("realtime.thirdparty.poi-match"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_poi_match(data, json_mode):
    _rt_tp("realtime_poi_match_handling", data, json_mode)


@thirdparty.command("customer-flow-items", help=_h("realtime.thirdparty.customer-flow-items"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_cf_items(data, json_mode):
    _rt_tp("realtime_customer_flow_service_items", data, json_mode)


@thirdparty.command("customer-flow-competitors", help=_h("realtime.thirdparty.customer-flow-competitors"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_cf_competitors(data, json_mode):
    _rt_tp("realtime_customer_flow_competitor_stores", data, json_mode)


@thirdparty.command("customer-flow-report", help=_h("realtime.thirdparty.customer-flow-report"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_cf_report(data, json_mode):
    _rt_tp("realtime_customer_flow_data_reports", data, json_mode)


@thirdparty.command("customer-flow-pedestrian", help=_h("realtime.thirdparty.customer-flow-pedestrian"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_cf_pedestrian(data, json_mode):
    _rt_tp("realtime_customer_flow_business_district_pedestrian_flow_analysis", data, json_mode)


@thirdparty.command("customer-flow-competition", help=_h("realtime.thirdparty.customer-flow-competition"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_cf_competition(data, json_mode):
    _rt_tp("realtime_customer_flow_business_district_competition_intensity_analysis", data, json_mode)


@thirdparty.command("lbs-passenger-point", help=_h("realtime.thirdparty.lbs-passenger-point"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_lbs_point(data, json_mode):
    _rt_tp("realtime_lbs_passenger_portrait_point", data, json_mode)


@thirdparty.command("lbs-passenger-area", help=_h("realtime.thirdparty.lbs-passenger-area"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_lbs_area(data, json_mode):
    _rt_tp("realtime_lbs_passenger_portrait_area", data, json_mode)


@thirdparty.command("tx-poi-match-v2", help=_h("realtime.thirdparty.tx-poi-match-v2"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_tx_poi_v2(data, json_mode):
    _rt_tp("realtime_tx_poi_match_v2", data, json_mode)


@thirdparty.command("tx-poi-multi-v2", help=_h("realtime.thirdparty.tx-poi-multi-v2"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_tx_multi_v2(data, json_mode):
    _rt_tp("realtime_tx_poi_mutil_match_v2", data, json_mode)


@thirdparty.command("tx-poi-multi", help=_h("realtime.thirdparty.tx-poi-multi"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_tx_multi(data, json_mode):
    _rt_tp("realtime_tx_poi_mutil_match", data, json_mode)


@thirdparty.command("odm-gd-match", help=_h("realtime.thirdparty.odm-gd-match"))
@click.option("--data", required=True)
@click.option("--json", "json_mode", is_flag=True)
def rt_tp_odm_match(data, json_mode):
    _rt_tp("realtime_odm_gd_match", data, json_mode)


# ============================================================================
# Export
# ============================================================================

@cli.group()
def export():
    """Export task results."""
    pass


@export.command("json")
@click.argument("input_file")
@click.argument("output_file")
def export_json_cmd(input_file, output_file):
    """Export data as JSON."""
    data = json.loads(open(input_file).read())
    path = export_json(data, output_file)
    click.echo(f"Exported to {path}")


@export.command("csv")
@click.argument("input_file")
@click.argument("output_file")
@click.option("--no-flatten", is_flag=True, help="Don't flatten nested structures")
def export_csv_cmd(input_file, output_file, no_flatten):
    """Export data as CSV."""
    data = json.loads(open(input_file).read())
    path = export_csv(data, output_file, flatten=not no_flatten)
    click.echo(f"Exported to {path}")


# ============================================================================
# REPL
# ============================================================================

class TaskPipelineREPL(cmd.Cmd):
    """Interactive REPL for common-task APIs."""

    intro = "common-task API REPL. Type 'help' for commands.\n"
    prompt = "gogeo-cli> "

    def __init__(self):
        super().__init__()
        self.client = None
        self.json_mode = False

    def _get_client(self) -> TaskAPIClient:
        if not self.client:
            config = get_project()
            api_code = resolve_open_api_code()
            self.client = TaskAPIClient(
                api_url=config.apiUrl,
                open_api_code=api_code,
                timeout=config.default_timeout if hasattr(config, 'default_timeout') else 300,
            )
        return self.client

    def do_connect(self, arg):
        """connect [api_url] [--open-api-code CODE]"""
        parts = arg.split()
        if parts:
            api_url = parts[0]
        else:
            api_url = "https://gogeo.topprismdata.com/prod-gogeo-api"
        open_api_code = None
        if "--open-api-code" in parts:
            idx = parts.index("--open-api-code")
            if idx + 1 < len(parts):
                open_api_code = parts[idx + 1]
        init_project(api_url, open_api_code)
        self.client = None
        print(f"Connected to {api_url}")

    def do_json(self, arg):
        """json [on|off]"""
        if arg.lower() == "on":
            self.json_mode = True
        elif arg.lower() == "off":
            self.json_mode = False
        print(f"JSON mode: {'ON' if self.json_mode else 'OFF'}")

    def do_api(self, arg):
        """api <method> <endpoint> [json_body] - Make raw API call"""
        parts = arg.split(None, 2)
        if len(parts) < 2:
            print("Usage: api <POST|GET> <endpoint> [json_body]")
            return
        method, endpoint = parts[0], parts[1]
        body = json.loads(parts[2]) if len(parts) > 2 else None
        client = self._get_client()
        if method.upper() == "POST":
            result = client.post(endpoint, data=body)
        else:
            result = client.get(endpoint)
        print(format_output(result, self.json_mode))

    def do_exit(self, arg):
        """Exit REPL."""
        print("Goodbye!")
        return True

    def do_EOF(self, arg):
        print()
        return True


@cli.command("repl")
def cli_repl():
    """Launch interactive REPL mode."""
    TaskPipelineREPL().cmdloop()


if __name__ == "__main__":
    cli()
