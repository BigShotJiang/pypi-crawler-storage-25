"""Output formatting utilities for CLI display."""

import json
from typing import Any


def format_output(data: Any, json_mode: bool = False) -> str:
    """Format data for display. In json_mode, always return pretty JSON."""
    if json_mode:
        return json.dumps(data, indent=2, ensure_ascii=False, default=str)

    if isinstance(data, dict):
        if data.get("error"):
            return f"Error: {data.get('message', 'Unknown error')}"
        return _format_dict(data)
    elif isinstance(data, list):
        if not data:
            return "(empty)"
        return _format_list(data)
    elif isinstance(data, str):
        return data
    return str(data)


def _format_dict(d: dict, indent: int = 0) -> str:
    lines = []
    prefix = "  " * indent
    for key, value in d.items():
        if isinstance(value, dict):
            lines.append(f"{prefix}{key}:")
            lines.append(_format_dict(value, indent + 1))
        elif isinstance(value, list):
            lines.append(f"{prefix}{key}:")
            for item in value:
                if isinstance(item, dict):
                    lines.append(_format_dict(item, indent + 1))
                else:
                    lines.append(f"{prefix}  - {item}")
        else:
            lines.append(f"{prefix}{key}: {value}")
    return "\n".join(lines)


def _format_list(lst: list, indent: int = 0) -> str:
    lines = []
    prefix = "  " * indent
    for i, item in enumerate(lst):
        lines.append(f"{prefix}[{i}]")
        if isinstance(item, dict):
            lines.append(_format_dict(item, indent + 1))
        else:
            lines.append(f"{prefix}  {item}")
    return "\n".join(lines)
