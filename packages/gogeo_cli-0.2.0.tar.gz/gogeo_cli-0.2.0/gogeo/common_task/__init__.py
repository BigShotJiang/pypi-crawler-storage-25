# common-task CLI harness
# A production-ready CLI for the common-task task pipeline management platform
# Geospatial data processing, spatial analysis, model calculation, and AI multimodal recognition
