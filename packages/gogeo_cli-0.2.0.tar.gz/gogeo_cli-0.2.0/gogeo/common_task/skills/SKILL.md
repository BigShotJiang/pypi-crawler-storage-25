---
name: gogeo-cli
description: CLI for GoGeo business APIs. 184 endpoints: 112 async (/api/v3/task/api/) + 72 sync (/api/v3/task/api/realtime/). Covers data, spatial analysis, spatial calculation, operation, model, resource, base, thirdparty, and all realtime sub-groups.
version: 0.3.1
---

# GoGeo CLI - common-task Project

All commands invoked as: `gogeo-cli common-task <command-group> <subcommand> ...`

## Prerequisites

- Python 3.8+
- Install: `pip install gogeo-cli`
- Verify: `gogeo-cli --help` — if command not found, run `pip install gogeo-cli` first

## Agent Usage

1. **Verify installation**: Run `gogeo-cli --help`. If not found, `pip install gogeo-cli`.
2. **Initialize project**: `gogeo-cli common-task project init <base_url> [--open-api-code CODE]` — must be done before calling APIs.
3. **Async vs Realtime**:
   - `gogeo-cli common-task data/spatial/operation/model/resource/base/thirdparty` — async APIs, return `taskStatus` and `pipelineCode`
   - `gogeo-cli common-task realtime ...` — sync APIs, return results directly in `data.dataList`
4. **Use `--json` flag** for programmatic output when parsing responses.
5. **Response handling**:
   - Success: `code == 200`
   - Error: `code != 200` — check `message` field for details
   - Async tasks: poll with `gogeo-cli common-task data batch-status --data '{"pipelineCodes": ["..."]}'`
6. **Parameter format**: Every API command requires `--data JSON`. All examples below show the exact JSON structure.
7. **Error format**: `{"code": "xxx", "message": "error details"}`

## Non-realtime (async) API groups

## base

### coord-convert — 点坐标转换
```bash
gogeo-cli common-task coord-convert --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/coordinate_convert
请求方式: POST
接口描述: 点坐标转换


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：售点数据
    示例: point_001
  - sourceType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: WGS84
  - targetType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: GCJ02


接口请求示例:
  {
    "propertyCode": "asset_001",
    "sourceType": "WGS84",
    "targetType": "WGS84"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "sourceType": "WGS84",
    "targetType": "WGS84"
}
```

### fence-boundary — 多边形转线数据处理请求
```bash
gogeo-cli common-task fence-boundary --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/fence_boundary
请求方式: POST
接口描述: 多边形转线数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_001


接口请求示例:
  {
    "propertyCode": "asset_001"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001"
}
```

### fence-coord-convert — 面坐标转换
```bash
gogeo-cli common-task fence-coord-convert --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/fence_coordinate_convert
请求方式: POST
接口描述: 面坐标转换


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：面数据
    示例: fence_001
  - sourceType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: WGS84
  - targetType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: GCJ02


接口请求示例:
  {
    "propertyCode": "asset_001",
    "sourceType": "WGS84",
    "targetType": "WGS84"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "sourceType": "WGS84",
    "targetType": "WGS84"
}
```

### fence-extract — 面坐标点提取数据处理请求
```bash
gogeo-cli common-task fence-extract --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/fence_coordinate_extraction
请求方式: POST
接口描述: 面坐标点提取数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：选择需要执行的面数据
    示例: fence_001


接口请求示例:
  {
    "propertyCode": "asset_001"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001"
}
```

### fence-thin — 面抽稀
```bash
gogeo-cli common-task fence-thin --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/fence_coordinate_thinning
请求方式: POST
接口描述: 面抽稀


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：面数据
    示例: fence_001
  - maxValue [String] [必填]
    字段描述: 抽稀值（米）
    示例: maxvalue


接口请求示例:
  {
    "propertyCode": "asset_001",
    "maxValue": "maxValue"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "maxValue": "maxValue"
}
```

### line-coord-convert — 线坐标转换
```bash
gogeo-cli common-task line-coord-convert --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/line_coordinate_convert
请求方式: POST
接口描述: 线坐标转换


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：线数据
    示例: line_001
  - sourceType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: WGS84
  - targetType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: GCJ02


接口请求示例:
  {
    "propertyCode": "asset_001",
    "sourceType": "WGS84",
    "targetType": "WGS84"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "sourceType": "WGS84",
    "targetType": "WGS84"
}
```

### line-extract — 线坐标点提取数据处理请求
```bash
gogeo-cli common-task line-extract --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/line_coordinate_extraction
请求方式: POST
接口描述: 线坐标点提取数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：选择需要执行的线数据
    示例: line_001


接口请求示例:
  {
    "propertyCode": "asset_001"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001"
}
```

### line-thin — 线抽稀
```bash
gogeo-cli common-task line-thin --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/line_coordinate_thinning
请求方式: POST
接口描述: 线抽稀


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：线数据
    示例: line_001
  - maxValue [String] [必填]
    字段描述: 抽稀值（米）
    示例: maxvalue


接口请求示例:
  {
    "propertyCode": "asset_001",
    "maxValue": "maxValue"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "maxValue": "maxValue"
}
```

### point-circle — 点生成圆形
```bash
gogeo-cli common-task point-circle --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/point_generate_circle
请求方式: POST
接口描述: 点生成圆形


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：售点数据
    示例: point_001
  - radius [Double] [必填]
    字段描述: 半径（米）
    示例: 1000


接口请求示例:
  {
    "propertyCode": "asset_001",
    "radius": 1000
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "radius": 1000
}
```

### point-hexagon — 点生成蜂窝
```bash
gogeo-cli common-task point-hexagon --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/point_generate_hexagon
请求方式: POST
接口描述: 点生成蜂窝


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：售点数据
    示例: point_001
  - radius [Double] [必填]
    字段描述: 半径（米）
    示例: 1000


接口请求示例:
  {
    "propertyCode": "asset_001",
    "radius": 1000
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "radius": 1000
}
```

### point-rarefy — 点抽稀数据处理请求
```bash
gogeo-cli common-task point-rarefy --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/point_rarefy
请求方式: POST
接口描述: 点抽稀数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - dilutionLevel [Integer] [必填]
    字段描述: 抽稀级别
    示例: 8


接口请求示例:
  {
    "propertyCode": "asset_001",
    "dilutionLevel": 8
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "dilutionLevel": 8
}
```

### point-square — 点生成方块
```bash
gogeo-cli common-task point-square --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/point_generate_square
请求方式: POST
接口描述: 点生成方块


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：售点数据
    示例: point_001
  - radius [Double] [必填]
    字段描述: 半径（米）
    示例: 1000


接口请求示例:
  {
    "propertyCode": "asset_001",
    "radius": 1000
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "radius": 1000
}
```

### track-generate — 轨迹生成
```bash
gogeo-cli common-task track-generate --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineBaseServiceApiController/track_generate
请求方式: POST
接口描述: 轨迹生成


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: track_001
  - orderBy [String] [必填]
    字段描述: 顺序
    示例: timestamp


接口请求示例:
  {
    "propertyCode": "asset_001",
    "orderBy": "orderBy"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "orderBy": "orderBy"
}
```

## data

### address-parse — 地址解析请求类
```bash
gogeo-cli common-task address-parse --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/address_parsing
请求方式: POST
接口描述: 地址解析请求类


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: point_001
  - address [String] [必填]
    字段描述: 地址字段
    示例: address


接口请求示例:
  {
    "propertyCode": "asset_001",
    "address": "北京市朝阳区"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "address": "北京市朝阳区"
}
```

### batch-status — 批量查询任务状态
```bash
gogeo-cli common-task batch-status --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/batch_query_task_status
请求方式: POST
接口描述: 批量查询任务状态
详细描述: 根据流水线编码批量查询任务信息


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data[] [Array<TaskPipelineStatusVo>]
    字段描述: 任务状态列表
  - data[].pipelineCode [String]
    字段描述: 流水线编码
  - data[].taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data[].errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）


参数:
  - pipelineCodes [List<String>] [必填]
    字段描述: 流水线编码列表
    示例: ["pipelineCode1", "pipelineCode2"]


接口请求示例:
  {
    "pipelineCodes": [
        "pipelineCodes"
    ]
}
```
**示例:**
```json
{
    "pipelineCodes": [
        "pipelineCodes"
    ]
}
```

### duplicate-marking — 重复标记
```bash
gogeo-cli common-task duplicate-marking --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/duplicate_marking
请求方式: POST
接口描述: 重复标记


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: point_001
  - groupField1 [String] [必填]
    字段描述: 分组字段1：资产的字段
    示例: name
  - groupField2 [String] [必填]
    字段描述: 分组字段2：资产的字段
    示例: city
  - groupField3 [String] [必填]
    字段描述: 分组字段3：资产的字段
    示例: province
  - groupField4 [String] [可选]
    字段描述: 分组字段4：资产的字段
    示例: address
  - groupField5 [String] [可选]
    字段描述: 分组字段5：资产的字段
    示例: phone


接口请求示例:
  {
    "propertyCode": "asset_001",
    "groupField1": "name",
    "groupField2": "city",
    "groupField3": "province",
    "groupField4": "district",
    "groupField5": "groupField5"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "groupField1": "name",
    "groupField2": "city",
    "groupField3": "province",
    "groupField4": "district",
    "groupField5": "groupField5"
}
```

### exact-match — 完全匹配
```bash
gogeo-cli common-task exact-match --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/exact_match
请求方式: POST
接口描述: 完全匹配


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资数据
    示例: {"propertyCode":"customer_001","name":"XX门店","address":"地址"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - name [String (inner)] [必填]
    字段描述: 名称：资产数据中代表名称的字段
    示例: name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：客资资产的字段
    示例: address
  - txData [TxData] [必填]
    字段描述: 腾讯数据
    示例: {"data":[{"code":"tx_001","name":"腾讯目标"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 对比数据资产编码
    示例: tx_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：对比数据资产的字段
    示例: poi_name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：对比数据资产字段
    示例: poi_address


接口请求示例:
  {
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "txData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    }
}
```
**示例:**
```json
{
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "txData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    }
}
```

### ka-match — ka匹配请求
```bash
gogeo-cli common-task ka-match --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/ka_matchHandling
请求方式: POST
接口描述: ka匹配请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerData [CustomerData] [必填]
    示例: {"propertyCode":"customer_001","name":"XX门店"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - name [String (inner)] [必填]
    字段描述: 名称：客资资产的字段
    示例: name
  - kaData [KaData] [必填]
    字段描述: ka数据
    示例: {"propertyCode":"ka_001","keyword":"肯德基","trademarkName":"KFC","screen":"外卖"}
  - propertyCode [String (inner)] [必填]
    字段描述: Ka资产编码
    示例: ka_001
  - keyword [String (inner)] [必填]
    字段描述: 关键词：ka资产的字段
    示例: 肯德基
  - trademarkName [String (inner)] [必填]
    字段描述: 品牌名：ka资产的字段
    示例: KFC
  - screen [String (inner)] [可选]
    字段描述: 屏蔽词：ka资产的字段
    示例: 屏蔽词


接口请求示例:
  {
    "customerData": {
        "propertyCode": "customer_001",
        "name": "name"
    },
    "kaData": {
        "propertyCode": "ka_001",
        "keyword": "关键词",
        "trademarkName": "品牌名",
        "screen": "屏蔽词"
    }
}
```
**示例:**
```json
{
    "customerData": {
        "propertyCode": "customer_001",
        "name": "name"
    },
    "kaData": {
        "propertyCode": "ka_001",
        "keyword": "关键词",
        "trademarkName": "品牌名",
        "screen": "屏蔽词"
    }
}
```

### poi-match — poi匹配
```bash
gogeo-cli common-task poi-match --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/poi_matchHandling
请求方式: POST
接口描述: poi匹配


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资数据
    示例: {"data":[{"code":"001","name":"XX门店"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：客资资产的字段
    示例: name
  - address [String (inner)] [可选]
    字段描述: 地址：资产数据中代表地址的字段
    示例: address
  - policyCode [PolicyCode] [必填]
    字段描述: 处理策略取值枚举（输入汉字时需根据汉字内容映射为编码）。可选值: 30003=名称-包含类目; 30004=经纬度-包含类目; 30005=名称-剔除类目; 30006=经纬度-剔除类目; 30004_1=名称+地址+经纬度-包含类目; 30006_1=名称+地址+经纬度-剔除类目可选值: 30003=名称-包含类目; 30004=经纬度-包含类目; 30005=名称-剔除类目; 30006=经纬度-剔除类目; 30004_1=名称+地址+经纬度-包含类目; 30006_1=名称+地址+经纬度-剔除类目
    示例: 30003
  - policyConfig [List<Category>] [可选]
    字段描述: 类目选择，例如格式 [{\
    示例: [...]
  - name [String (inner)] [可选]
    字段描述: 类目名称，非必填
    示例: 测试名称
  - subCategories [List<String> (inner)] [可选]
    字段描述: 子类目列表
    示例: ["subcategories"]


接口请求示例:
  {
    "customerData": {
        "propertyCode": "customer_001",
        "name": "XX门店",
        "address": "地址"
    },
    "policyCode": "30003",
    "policyConfig": []
}
```
**示例:**
```json
{
    "customerData": {
        "propertyCode": "customer_001",
        "name": "XX门店",
        "address": "地址"
    },
    "policyCode": "30003",
    "policyConfig": []
}
```

### reverse-address-parse — 逆地址解析
```bash
gogeo-cli common-task reverse-address-parse --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/reverse_address_parsing
请求方式: POST
接口描述: 逆地址解析


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：售点数据
    示例: point_001


接口请求示例:
  {
    "propertyCode": "asset_001"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001"
}
```

### similarity — 相似度处理请求类
```bash
gogeo-cli common-task similarity --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/similarity_processing
请求方式: POST
接口描述: 相似度处理请求类


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资数据
    示例: {"data":[{"code":"001","name":"XX门店"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：客资资产的字段
    示例: name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：客资资产的字段
    示例: address
  - txData [TxData] [必填]
    字段描述: 目标数据
    示例: {"data":[{"code":"tx_001","name":"腾讯目标"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 对比数据资产编码
    示例: tx_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：对比数据资产的字段
    示例: poi_name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：对比数据资产字段
    示例: poi_address
  - policyCode [PolicyCode] [必填]
    字段描述: 相似度方式。POI匹配处理方式。可选值: 30003=名称-包含类目; 30004=经纬度-包含类目; 30005=名称-剔除类目; 30006=经纬度-剔除类目; 30004_1=名称+地址+经纬度-包含类目; 30006_1=名称+地址+经纬度-剔除类目
  - similarity [Double] [必填]
    字段描述: 相似度 数值类型，值 0~1 最大值不能超过1
    示例: 0.85
  - step [Integer] [必填]
    字段描述: 步长 单位:(米); isLng 是true 是必填  数值类型
    示例: 100
  - distance [Double] [可选]
    字段描述: 距离 单位:(米); isLng 是true 是必填  数值类型
    示例: 500


接口请求示例:
  {
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "txData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "policyCode": "30003",
    "similarity": 1,
    "step": 1,
    "distance": 1
}
```
**示例:**
```json
{
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "txData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "policyCode": "30003",
    "similarity": 1,
    "step": 1,
    "distance": 1
}
```

### text-concat — 文本拼接
```bash
gogeo-cli common-task text-concat --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/text_concatenation
请求方式: POST
接口描述: 文本拼接


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: point_001
  - concatFields [List<String>] [必填]
    字段描述: 拼接字段：资产的字段 例如['省','市','区','地址']
    示例: ["concatfields"]


接口请求示例:
  {
    "propertyCode": "asset_001",
    "concatFields": [
        "concatFields"
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "concatFields": [
        "concatFields"
    ]
}
```

### text-handling — 文本处理请求
```bash
gogeo-cli common-task text-handling --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineDataApiController/text_handling
请求方式: POST
接口描述: 文本处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - textData [TextData] [必填]
    字段描述: 处理数据
    示例: [{"code":"text_001","text":"测试文本内容"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: text_001
  - textStr [String (inner)] [必填]
    字段描述: 待处理的字段：资产数据中的字段
    示例: address
  - textHandlingStrategy [List<TextHandlingStrategy>] [必填]
    字段描述: 处理的策略
  - policyCode [PolicyCode (inner)] [必填]
    字段描述: 处理策略取值枚举（输入汉字时需根据汉字内容映射为编码）。可选值: 10001=剔除-括号内容; 10002=提取-括号内容; 10003=提取-连续数字; 10004=剔除-连续数字; 10005=提取-连续数字字母; 10006=剔除-连续数字字母; 10010=剔除-特殊字符-全文; 10013=剔除-前缀; 10014=剔除-后缀; 10017=包含-前缀; 10018=包含-后缀; 10019=通配符-提取内容; 10021=提取-连续字母; 10022=剔除-连续字母; 10025=提取-多连续数字; 10026=提取-多连续数字字母; 10027=提取-多连续字母; 10029=剔除-空格
  - policyConfig [String (inner)] [必填]
    字段描述: 处理方式：没有则输入 '无'; 提取、剔除连续数字类输入：>X (X是大于0的数字)，剔除特殊字符输入要剔除的特殊字符：例如 $%(（,#,*）) 等，用英文逗号隔开。


接口请求示例:
  {
    "textData": {
        "propertyCode": "text_001",
        "textStr": "fieldName"
    },
    "textHandlingStrategy": [
        {
            "policyCode": "10002",
            "policyConfig": "无"
        }
    ]
}
```
**示例:**
```json
{
    "textData": {
        "propertyCode": "text_001",
        "textStr": "fieldName"
    },
    "textHandlingStrategy": [
        {
            "policyCode": "10002",
            "policyConfig": "无"
        }
    ]
}
```

## model

### belonging-area — 归属区域 - 放射线数据处理请求
```bash
gogeo-cli common-task belonging-area --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineModelCalculationController/belong_area_generate
请求方式: POST
接口描述: 归属区域 - 放射线数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - name [String] [必填]
    字段描述: 归属区域字段
    示例: area_name
  - connectType [ConnectType] [必填]
    字段描述: 连线方式。连接/网格类型(V2)。可选值: 1=网格; 2=蜂窝
    示例: 1


接口请求示例:
  {
    "propertyCode": "asset_001",
    "name": "测试名称",
    "connectType": "1"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "name": "测试名称",
    "connectType": "1"
}
```

### industry-cluster — 行业聚集群与分析
```bash
gogeo-cli common-task industry-cluster --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineModelCalculationController/industry_cluster
请求方式: POST
接口描述: 行业聚集群与分析


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点数据
    示例: point_001
  - paramJson [ParamJson] [必填]
    字段描述: 基础参数
    示例: {...}
  - zoomStart [Integer (inner)] [可选]
    字段描述: 开始级别
    示例: 5
  - minValue [Integer (inner)] [必填]
    字段描述: 潜力区间最小值
    示例: 0
  - maxValue [Integer (inner)] [必填]
    字段描述: 潜力区间最大值
    示例: 1000
  - boundaryLevel [BoundaryLevel (inner)] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>> (inner)] [可选]
    字段描述: 自定义生效范围
    示例: ["effectivescope"]
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合统计字段
    示例: [...]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "paramJson": {
        "zoomStart": 5,
        "minValue": 0,
        "maxValue": 100,
        "boundaryLevel": "province",
        "effectiveScope": [
            "effectiveScope"
        ]
    },
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "paramJson": {
        "zoomStart": 5,
        "minValue": 0,
        "maxValue": 100,
        "boundaryLevel": "province",
        "effectiveScope": [
            "effectiveScope"
        ]
    },
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### radiate-circle — 商业体辐射商圈数据处理请求
```bash
gogeo-cli common-task radiate-circle --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineModelCalculationController/business_radiate_circle
请求方式: POST
接口描述: 商业体辐射商圈数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointPropertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - fencePropertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_001
  - radius [Double] [必填]
    字段描述: 辐射半径（KM）
    示例: 5.0
  - unionDistance [Double] [必填]
    字段描述: 合并距离（KM）
    示例: 1.0
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合字段配置列表
    示例: 1.0
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset",
    "radius": 1000,
    "unionDistance": 1,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset",
    "radius": 1000,
    "unionDistance": 1,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### reachable-range — 可达圈分析请求参数
```bash
gogeo-cli common-task reachable-range --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineModelCalculationController/reachable_range
请求方式: POST
接口描述: 可达圈分析请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointPropertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - directionType [DirectionType] [必填]
    字段描述: 出行政策。可达范围出行方式。可选值: driving=驾车; bicycling=骑行; walking=步行
    示例: driving
  - travelTime [Integer] [必填]
    字段描述: 出行时长，单位：分钟
    示例: 30


接口请求示例:
  {
    "pointPropertyCode": "point_asset",
    "directionType": "driving",
    "travelTime": 30
}
```
**示例:**
```json
{
    "pointPropertyCode": "point_asset",
    "directionType": "driving",
    "travelTime": 30
}
```

### scu-specify — SCU-指定生成请求
```bash
gogeo-cli common-task scu-specify --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineModelCalculationController/scu_specify_generate
请求方式: POST
接口描述: SCU-指定生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointPropertyCode [String] [可选]
    字段描述: 点数据
    示例: fence_001
  - unitType [UnitType] [必填]
    字段描述: SCU 类型。空间网格单元类型。可选值: road=路网; area=区划; hive=蜂窝; grid=网格; h3=H3; s2=S2; geoHash=GeoHash
    示例: road
  - areaTree [List<List<String>>] [必填]
    字段描述: 省市区范围
  - roadType [String] [必填]
    字段描述: 路网类型，当 unitType 为 road 时必填
    示例: district_physic_block_normal
  - divideType [String] [可选]
    字段描述: 区划类型，当 unitType 为 area 时必填。时间划分粒度。可选值: week=周; day=日
    示例: city
  - fieldName [String] [必填]
    字段描述: 潜力字段
    示例: salesAmount
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
    示例: [...]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointPropertyCode": "point_asset",
    "unitType": "grid",
    "areaTree": [
        "areaTree"
    ],
    "roadType": "roadType",
    "divideType": "week",
    "fieldName": "fieldName",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "pointPropertyCode": "point_asset",
    "unitType": "grid",
    "areaTree": [
        "areaTree"
    ],
    "roadType": "roadType",
    "divideType": "week",
    "fieldName": "fieldName",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### solitary-screen — 孤点标记数据处理请求
```bash
gogeo-cli common-task solitary-screen --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineModelCalculationController/solitary_screen_data
请求方式: POST
接口描述: 孤点标记数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [可选]
    字段描述: 
  - fields [List<Field>] [必填]
    字段描述: 标记条件列表
    示例: [...]
  - fieldName [String (inner)] [必填]
    字段描述: 字段名称
    示例: field4
  - operationType [OperationType (inner)] [必填]
    字段描述: 操作类型。过滤/筛选操作符。可选值: eq=等于; neq=不等于; include=包含; not_include=不包含; gt=大于; lt=小于; gte=大于等于; lte=小于等于; isnull=为空; not_null=不为空
    示例: eq
  - content [Object (inner)] [可选]
    字段描述: 过滤/筛选操作符，可选值: eq=等于; neq=不等于; include=包含; not_include=不包含; gt=大于; lt=小于; gte=大于等于; lte=小于等于; isnull=为空; not_null=不为空


接口请求示例:
  {
    "propertyCode": "asset_001",
    "fields": [
        {
            "fieldName": "fieldName",
            "operationType": "eq",
            "content": "eq"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "fields": [
        {
            "fieldName": "fieldName",
            "operationType": "eq",
            "content": "eq"
        }
    ]
}
```

## operation

### data-flow — 数据平移数据处理请求
```bash
gogeo-cli common-task data-flow --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/data_flow
请求方式: POST
接口描述: 数据平移数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：选择需要执行的坐标数据
    示例: point_001


接口请求示例:
  {
    "propertyCode": "asset_001"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001"
}
```

### data-merge — 数据合并数据处理请求
```bash
gogeo-cli common-task data-merge --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/data_merge
请求方式: POST
接口描述: 数据合并数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - sourcePropertyCode [String] [可选]
    字段描述: 
  - targetPropertyCode [String] [可选]
    字段描述: 
  - targetPropertyCode2 [String] [可选]
    字段描述: 
  - targetPropertyCode3 [String] [可选]
    字段描述: 
  - targetPropertyCode4 [String] [可选]
    字段描述: 


接口请求示例:
  {
    "sourcePropertyCode": "source_asset",
    "targetPropertyCode": "target_asset",
    "targetPropertyCode2": "targetPropertyCode2",
    "targetPropertyCode3": "targetPropertyCode3",
    "targetPropertyCode4": "targetPropertyCode4"
}
```
**示例:**
```json
{
    "sourcePropertyCode": "source_asset",
    "targetPropertyCode": "target_asset",
    "targetPropertyCode2": "targetPropertyCode2",
    "targetPropertyCode3": "targetPropertyCode3",
    "targetPropertyCode4": "targetPropertyCode4"
}
```

### duplicate-mark — 重复标记请求
```bash
gogeo-cli common-task duplicate-mark --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/duplicate_mark
请求方式: POST
接口描述: 重复标记请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: data_001
  - groupField1 [String] [必填]
    字段描述: 分组字段 1
    示例: field1
  - groupField2 [String] [可选]
    字段描述: 分组字段 2
    示例: field2
  - groupField3 [String] [可选]
    字段描述: 分组字段 3
    示例: field3
  - groupField4 [String] [可选]
    字段描述: 分组字段 4
    示例: field4
  - groupField5 [String] [可选]
    字段描述: 分组字段 5
    示例: field5


接口请求示例:
  {
    "propertyCode": "asset_001",
    "groupField1": "name",
    "groupField2": "city",
    "groupField3": "province",
    "groupField4": "district",
    "groupField5": "groupField5"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "groupField1": "name",
    "groupField2": "city",
    "groupField3": "province",
    "groupField4": "district",
    "groupField5": "groupField5"
}
```

### filter — 筛选器请求
```bash
gogeo-cli common-task filter --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/filter
请求方式: POST
接口描述: 筛选器请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: point_001
  - fields [List<Field>] [必填]
    字段描述: 筛选条件列表
    示例: point_001
  - fieldName [String (inner)] [必填]
    字段描述: 字段名称
    示例: field4
  - operationType [OperationType (inner)] [必填]
    字段描述: 操作类型。过滤/筛选操作符。可选值: eq=等于; neq=不等于; include=包含; not_include=不包含; gt=大于; lt=小于; gte=大于等于; lte=小于等于; isnull=为空; not_null=不为空
    示例: eq
  - content [Object (inner)] [可选]
    字段描述: 过滤/筛选操作符，可选值: eq=等于; neq=不等于; include=包含; not_include=不包含; gt=大于; lt=小于; gte=大于等于; lte=小于等于; isnull=为空; not_null=不为空


接口请求示例:
  {
    "propertyCode": "asset_001",
    "fields": [
        {
            "fieldName": "fieldName",
            "operationType": "eq",
            "content": "eq"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "fields": [
        {
            "fieldName": "fieldName",
            "operationType": "eq",
            "content": "eq"
        }
    ]
}
```

### group — 分组统计
```bash
gogeo-cli common-task group --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/group_data
请求方式: POST
接口描述: 分组统计


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：数据列表
    示例: data_001
  - countType [CountType] [必填]
    字段描述: 统计类型。统计聚合类型。可选值: Max=最大值; Min=最小值; Count=总数; Sum=求和; Avg=平均值
    示例: Max
  - filed [String] [必填]
    字段描述: 聚合字段
  - groupFiled [List<String>] [必填]
    字段描述: 分组字段


接口请求示例:
  {
    "propertyCode": "asset_001",
    "countType": "Max",
    "filed": "fieldName",
    "groupFiled": [
        "groupFiled"
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "countType": "Max",
    "filed": "fieldName",
    "groupFiled": [
        "groupFiled"
    ]
}
```

### intersect — 交叉关联
```bash
gogeo-cli common-task intersect --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/intersect_compute
请求方式: POST
接口描述: 交叉关联


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - oneDataPropertyCode [String] [必填]
    字段描述: 资产编码：数据 1
    示例: data_001
  - twoDataPropertyCode [String] [必填]
    字段描述: 资产编码：数据 2
    示例: data_002
  - oneMatchingField [String] [必填]
    字段描述: 数据 1 的关联字段
    示例: id
  - twoMatchingField [String] [必填]
    字段描述: 数据 2 的关联字段
    示例: id
  - resultField [List<String>] [必填]
    字段描述: 需要关联的字段（选择结果拼接的字段，不选择默认全部拼接）
    示例: ["resultField"]


接口请求示例:
  {
    "oneDataPropertyCode": "oneDataPropertyCode",
    "twoDataPropertyCode": "twoDataPropertyCode",
    "oneMatchingField": "id",
    "twoMatchingField": "id",
    "resultField": [
        "resultField"
    ]
}
```
**示例:**
```json
{
    "oneDataPropertyCode": "oneDataPropertyCode",
    "twoDataPropertyCode": "twoDataPropertyCode",
    "oneMatchingField": "id",
    "twoMatchingField": "id",
    "resultField": [
        "resultField"
    ]
}
```

### ka-handling — KA识别数据处理请求
```bash
gogeo-cli common-task ka-handling --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/ka_handling
请求方式: POST
接口描述: KA识别数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerPropertyCode [String] [必填]
    字段描述: 售点数据资产编码
    示例: customer_001
  - textStr [String] [必填]
    字段描述: 名称字段
    示例: name
  - kaPropertyCode [String] [必填]
    字段描述: KA数据资产编码
    示例: ka_001
  - name [String] [必填]
    字段描述: 关键词字段
    示例: keyword
  - tagName [String] [必填]
    字段描述: 品牌名字段
    示例: brandName
  - sort [String] [可选]
    字段描述: 排序字段
    示例: sort_order
  - policyCode [PolicyCode] [必填]
    字段描述: 识别规则。可选值: 20002=KA 名称提取 - 长词; 20006=ka 名称转拼音 - 长词; 20012=KA 名称删除 - 长词; 20018=KA 名称提取 - 排序; 20022=Ka 名称转拼音 - 排序; 20026=ka 名称删除 - 排序; 20032=多品牌识别 - 排序; 20038=多品牌删除 - 排序 - 分割


接口请求示例:
  {
    "customerPropertyCode": "customer_asset",
    "textStr": "fieldName",
    "kaPropertyCode": "ka_asset",
    "name": "测试名称",
    "tagName": "tagName",
    "sort": "sort",
    "policyCode": "20002"
}
```
**示例:**
```json
{
    "customerPropertyCode": "customer_asset",
    "textStr": "fieldName",
    "kaPropertyCode": "ka_asset",
    "name": "测试名称",
    "tagName": "tagName",
    "sort": "sort",
    "policyCode": "20002"
}
```

### normalized-expr — 归一值计算数据处理请求
```bash
gogeo-cli common-task normalized-expr --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/normalized_expr
请求方式: POST
接口描述: 归一值计算数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 归一数据资产编码
    示例: point_001
  - normalizedExpr [String] [必填]
    字段描述: 归一值计算表达式
    示例: (a+b)/c
  - compute [List<ComputeField>] [必填]
    字段描述: 计算字段配置列表
    示例: (a+b)/c
  - computeFiled [String (inner)] [必填]
    字段描述: 计算字段:选择需要计算的字段
    示例: salesAmount
  - aliasName [String (inner)] [必填]
    字段描述: 别名:被用于写表达式的字段 例如：a
    示例: alias


接口请求示例:
  {
    "propertyCode": "asset_001",
    "normalizedExpr": "normalizedExpr",
    "compute": [
        {
            "computeFiled": "computeFiled",
            "aliasName": "aliasName"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "normalizedExpr": "normalizedExpr",
    "compute": [
        {
            "computeFiled": "computeFiled",
            "aliasName": "aliasName"
        }
    ]
}
```

### one-id — ONE_ID 关联数据处理请求
```bash
gogeo-cli common-task one-id --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/one_id_compute
请求方式: POST
接口描述: ONE_ID 关联数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - firstPropertyCode [String] [必填]
    字段描述: 数据一资产编码
    示例: data1_001
  - oneMatchingField [String] [必填]
    字段描述: 数据一关联字段
    示例: id_card
  - secondPropertyCode [String] [必填]
    字段描述: 数据二资产编码
    示例: data2_001
  - twoMatchingField [String] [必填]
    字段描述: 数据二关联字段
    示例: mobile
  - resultField [String] [必填]
    字段描述: 需关联字段
    示例: name,phone


接口请求示例:
  {
    "firstPropertyCode": "firstPropertyCode",
    "oneMatchingField": "id",
    "secondPropertyCode": "secondPropertyCode",
    "twoMatchingField": "id",
    "resultField": "resultField"
}
```
**示例:**
```json
{
    "firstPropertyCode": "firstPropertyCode",
    "oneMatchingField": "id",
    "secondPropertyCode": "secondPropertyCode",
    "twoMatchingField": "id",
    "resultField": "resultField"
}
```

### subsection-mark — 分段标记数据处理请求
```bash
gogeo-cli common-task subsection-mark --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/subsection_mark
请求方式: POST
接口描述: 分段标记数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [可选]
    字段描述: 
  - subsectionGroupFields [List<String>] [必填]
    字段描述: 分段分组字段数组
    示例: ["subsectiongroupfields"]
  - param [List<SubsectionCondition>] [必填]
    字段描述: 分段条件列表
    示例: [...]
  - subsectionFields [List<String> (inner)] [必填]
    字段描述: 分段字段数组
    示例: ["subsectionfields"]
  - subsectionType [SubsectionType (inner)] [必填]
    字段描述: 分段类型：1-占比，2-数值。分段标记类型。可选值: 1=占比; 2=数值
  - operType [OperType (inner)] [必填]
    字段描述: 操作类型：1-等于，2-不等于，3-大于，4-大于等于，5-小于，6-小于等于，7-最大值，8-最小值。分段比较操作符。可选值: 1=等于; 2=不等于; 3=大于; 4=大于等于; 5=小于; 6=小于等于; 7=最大值; 8=最小值
  - compareValue [Integer (inner)] [可选]
    字段描述: 比较值
    示例: 100
  - groupField [String (inner)] [可选]
    字段描述: 分组字段（操作类型为 7 或 8 时必填）
    示例: groupField
  - markValue [String (inner)] [必填]
    字段描述: 标记值
    示例: high_value


接口请求示例:
  {
    "propertyCode": "asset_001",
    "subsectionGroupFields": [
        "subsectionGroupFields"
    ],
    "param": []
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "subsectionGroupFields": [
        "subsectionGroupFields"
    ],
    "param": []
}
```

### text-concat — 文本拼接请求
```bash
gogeo-cli common-task text-concat --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/text_concat
请求方式: POST
接口描述: 文本拼接请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: text_001
  - concatFields [List<String>] [必填]
    字段描述: 拼接字段：多选，例如['省','市','区','地址']
    示例: text_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "concatFields": [
        "concatFields"
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "concatFields": [
        "concatFields"
    ]
}
```

### text-similarity — 相似度计算数据处理请求
```bash
gogeo-cli common-task text-similarity --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineOperationToolController/text_similarity
请求方式: POST
接口描述: 相似度计算数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 相似数据资产编码
    示例: data_001
  - sourceText [String] [必填]
    字段描述: 源文本字段
    示例: source_name
  - targetText [String] [必填]
    字段描述: 目标文本字段
    示例: target_name
  - algorithm [SimilarityAlgorithm] [可选]
    字段描述: 


接口请求示例:
  {
    "propertyCode": "asset_001",
    "sourceText": "source_name",
    "targetText": "target_name",
    "algorithm": "0"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "sourceText": "source_name",
    "targetText": "target_name",
    "algorithm": "0"
}
```

## resource

### auto-area-planning — 物流-配送区域
```bash
gogeo-cli common-task resource auto-area-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/auto_area_planning
请求方式: POST
接口描述: 物流-配送区域


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerList [CustomerList] [必填]
    字段描述: 客户数据
    示例: {"propertyCode":"customer_001","customerCode":"C001","customerName":"测试客户","areaCode":"area_001","depotCode":"depot_001"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: customer_001
  - customerCode [String (inner)] [必填]
    字段描述: 客户编码
    示例: cust_001
  - customerName [String (inner)] [必填]
    字段描述: 客户名称
    示例: XX客户
  - areaCode [String (inner)] [必填]
    字段描述: 围栏编码
    示例: fence_001
  - depotCode [String (inner)] [必填]
    字段描述: 仓库编码
    示例: depot_001
  - readyTime [String (inner)] [必填]
    字段描述: 起始时间
    示例: 08:00:00
  - dueTime [String (inner)] [必填]
    字段描述: 截止时间
    示例: 18:00:00
  - orderList [OrderList] [必填]
    字段描述: 订单数据
    示例: {"propertyCode":"order_001","orderCode":"order_id","skuNum":10,"boxNum":50}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: order_001
  - customerCode [String (inner)] [必填]
    字段描述: 客户编码
    示例: cust_001
  - orderNo [String (inner)] [必填]
    字段描述: 订单编号
    示例: ORD20260001
  - skuNum [Integer (inner)] [必填]
    字段描述: 订单数
    示例: 10
  - boxNum [Integer (inner)] [必填]
    字段描述: 运送量
    示例: 50
  - vehicleType [String (inner)] [必填]
    字段描述: 车型
    示例: small
  - firstOrder [Boolean (inner)] [必填]
    字段描述: 是否首发
    示例: false
  - depotList [DepotList] [必填]
    字段描述: 仓库数据
    示例: [{"code":"depot_001","name":"测试仓库","point":"POINT(116.3 39.9)"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: depot_001
  - code [String (inner)] [必填]
    字段描述: 仓库编码
    示例: D001
  - readyTime [String (inner)] [必填]
    字段描述: 开门时间
    示例: 06:00:00
  - dueTime [String (inner)] [必填]
    字段描述: 关门时间
    示例: 20:00:00
  - baseTime [Double (inner)] [必填]
    字段描述: 基础时间
    示例: 30
  - unloadTime [Double (inner)] [必填]
    字段描述: 卸货时间
    示例: 15.5
  - areaVehicle [AreaVehicle] [必填]
    字段描述: 区域数据
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码 (面数据)
    示例: fence_001
  - areaCode [String (inner)] [必填]
    字段描述: 区域编码
    示例: area_001
  - cantGoAreaCode [String (inner)] [可选]
    字段描述: 不可达车型
    示例: large
  - isBreak [IsBreak] [必填]
    字段描述: 是否可突破。是否允许破约束。可选值: true=允许突破约束; false=不允许突破约束
    示例: false
  - vehicleList [List<VehicleList>] [必填]
    字段描述: 车辆列表
    示例: [{"vehicleCode":"京A00001","vehicleName":"测试车辆","volume":50,"box":10}]
  - vehicleType [String (inner)] [必填]
    字段描述: 车型
    示例: small
  - depotCode [String (inner)] [必填]
    字段描述: 仓库编码
    示例: depot_001
  - number [Integer (inner)] [必填]
    字段描述: 数量
    示例: 5
  - box [Integer (inner)] [必填]
    字段描述: 载装量
    示例: 100
  - cost [Double (inner)] [必填]
    字段描述: 固定成本
    示例: 500.0
  - costPerKm [Double (inner)] [必填]
    字段描述: 每公里成本
    示例: 5.0
  - costPerMinutes [Double (inner)] [必填]
    字段描述: 每分钟成本
    示例: 0.5


接口请求示例:
  {
    "customerList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "customerName": "客户名称",
        "areaCode": "area_001",
        "depotCode": "depot_001",
        "readyTime": "readyTime",
        "dueTime": "dueTime"
    },
    "orderList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "orderNo": "orderNo",
        "skuNum": 10,
        "boxNum": 50,
        "vehicleType": "小型货车",
        "firstOrder": true
    },
    "depotList": {
        "propertyCode": "asset_001",
        "code": "code",
        "readyTime": "readyTime",
        "dueTime": "dueTime",
        "baseTime": 30,
        "unloadTime": 1
    },
    "areaVehicle": {
        "propertyCode": "asset_001",
        "areaCode": "area_001",
        "cantGoAreaCode": "cantGoAreaCode"
    },
    "isBreak": "true",
    "vehicleList": [
        {
            "vehicleType": "小型货车",
            "depotCode": "depot_001",
            "number": 5,
            "box": 10,
            "cost": 1,
            "costPerKm": 5,
            "costPerMinutes": 1
        }
    ]
}
```
**示例:**
```json
{
    "customerList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "customerName": "客户名称",
        "areaCode": "area_001",
        "depotCode": "depot_001",
        "readyTime": "readyTime",
        "dueTime": "dueTime"
    },
    "orderList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "orderNo": "orderNo",
        "skuNum": 10,
        "boxNum": 50,
        "vehicleType": "小型货车",
        "firstOrder": true
    },
    "depotList": {
        "propertyCode": "asset_001",
        "code": "code",
        "readyTime": "readyTime",
        "dueTime": "dueTime",
        "baseTime": 30,
        "unloadTime": 1
    },
    "areaVehicle": {
        "propertyCode": "asset_001",
        "areaCode": "area_001",
        "cantGoAreaCode": "cantGoAreaCode"
    },
    "isBreak": "true",
    "vehicleList": [
        {
            "vehicleType": "小型货车",
            "depotCode": "depot_001",
            "number": 5,
            "box": 10,
            "cost": 1,
            "costPerKm": 5,
            "costPerMinutes": 1
        }
    ]
}
```

### logistics-planning — 物流-单程规划
```bash
gogeo-cli common-task resource logistics-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/logistics_planning
请求方式: POST
接口描述: 物流-路径规划 (实时)


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerList [CustomerList] [必填]
    字段描述: 客户数据
    示例: {"propertyCode":"customer_001","customerCode":"C001","customerName":"测试客户","areaCode":"area_001","depotCode":"depot_001"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: customer_001
  - customerCode [String (inner)] [必填]
    字段描述: 客户编码
    示例: cust_001
  - customerName [String (inner)] [必填]
    字段描述: 客户名称
    示例: XX客户
  - areaCode [String (inner)] [必填]
    字段描述: 围栏编码
    示例: fence_001
  - depotCode [String (inner)] [必填]
    字段描述: 仓库编码
    示例: depot_001
  - readyTime [String (inner)] [必填]
    字段描述: 起始时间
    示例: 08:00:00
  - dueTime [String (inner)] [必填]
    字段描述: 截止时间
    示例: 18:00:00
  - orderList [OrderList] [必填]
    字段描述: 订单数据
    示例: {"propertyCode":"order_001","orderCode":"order_id","skuNum":10,"boxNum":50}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: order_001
  - customerCode [String (inner)] [必填]
    字段描述: 客户编码
    示例: cust_001
  - orderNo [String (inner)] [必填]
    字段描述: 订单编号
    示例: ORD20260001
  - skuNum [Integer (inner)] [必填]
    字段描述: 订单数
    示例: 10
  - boxNum [Integer (inner)] [必填]
    字段描述: 运送量
    示例: 50
  - vehicleType [String (inner)] [必填]
    字段描述: 车型
    示例: small
  - firstOrder [Boolean (inner)] [必填]
    字段描述: 是否首发
    示例: false
  - depotList [DepotList] [必填]
    字段描述: 仓库数据
    示例: [{"code":"depot_001","name":"测试仓库","point":"POINT(116.3 39.9)"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: depot_001
  - code [String (inner)] [必填]
    字段描述: 仓库编码
    示例: D001
  - readyTime [String (inner)] [必填]
    字段描述: 开门时间
    示例: 06:00:00
  - dueTime [String (inner)] [必填]
    字段描述: 关门时间
    示例: 20:00:00
  - baseTime [Double (inner)] [必填]
    字段描述: 基础时间
    示例: 30
  - unloadTime [Double (inner)] [必填]
    字段描述: 卸货时间
    示例: 15.5
  - areaVehicle [AreaVehicle] [必填]
    字段描述: 区域数据
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码 (面数据)
    示例: fence_001
  - areaCode [String (inner)] [必填]
    字段描述: 区域编码
    示例: area_001
  - cantGoAreaCode [String (inner)] [可选]
    字段描述: 不可达车型
    示例: large
  - isBreak [IsBreak] [必填]
    字段描述: 是否可突破。是否允许破约束。可选值: true=允许突破约束; false=不允许突破约束
    示例: false
  - vehicleList [List<VehicleList>] [必填]
    字段描述: 车辆列表
    示例: [{"vehicleCode":"京A00001","vehicleName":"测试车辆","volume":50,"box":10}]
  - vehicleType [String (inner)] [必填]
    字段描述: 车型
    示例: small
  - depotCode [String (inner)] [必填]
    字段描述: 仓库编码
    示例: depot_001
  - number [Integer (inner)] [必填]
    字段描述: 数量
    示例: 5
  - box [Integer (inner)] [必填]
    字段描述: 载装量
    示例: 100
  - cost [Double (inner)] [必填]
    字段描述: 固定成本
    示例: 500.0
  - costPerKm [Double (inner)] [必填]
    字段描述: 每公里成本
    示例: 5.0
  - costPerMinutes [Double (inner)] [必填]
    字段描述: 每分钟成本
    示例: 0.5


接口请求示例:
  {
    "customerList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "customerName": "客户名称",
        "areaCode": "area_001",
        "depotCode": "depot_001",
        "readyTime": "readyTime",
        "dueTime": "dueTime"
    },
    "orderList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "orderNo": "orderNo",
        "skuNum": 10,
        "boxNum": 50,
        "vehicleType": "小型货车",
        "firstOrder": true
    },
    "depotList": {
        "propertyCode": "asset_001",
        "code": "code",
        "readyTime": "readyTime",
        "dueTime": "dueTime",
        "baseTime": 30,
        "unloadTime": 1
    },
    "areaVehicle": {
        "propertyCode": "asset_001",
        "areaCode": "area_001",
        "cantGoAreaCode": "cantGoAreaCode"
    },
    "isBreak": "true",
    "vehicleList": [
        {
            "vehicleType": "小型货车",
            "depotCode": "depot_001",
            "number": 5,
            "box": 10,
            "cost": 1,
            "costPerKm": 5,
            "costPerMinutes": 1
        }
    ]
}
```
**示例:**
```json
{
    "customerList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "customerName": "客户名称",
        "areaCode": "area_001",
        "depotCode": "depot_001",
        "readyTime": "readyTime",
        "dueTime": "dueTime"
    },
    "orderList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "orderNo": "orderNo",
        "skuNum": 10,
        "boxNum": 50,
        "vehicleType": "小型货车",
        "firstOrder": true
    },
    "depotList": {
        "propertyCode": "asset_001",
        "code": "code",
        "readyTime": "readyTime",
        "dueTime": "dueTime",
        "baseTime": 30,
        "unloadTime": 1
    },
    "areaVehicle": {
        "propertyCode": "asset_001",
        "areaCode": "area_001",
        "cantGoAreaCode": "cantGoAreaCode"
    },
    "isBreak": "true",
    "vehicleList": [
        {
            "vehicleType": "小型货车",
            "depotCode": "depot_001",
            "number": 5,
            "box": 10,
            "cost": 1,
            "costPerKm": 5,
            "costPerMinutes": 1
        }
    ]
}
```

### logistics-total-planning — 物流-总程规划
```bash
gogeo-cli common-task resource logistics-total-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/logistics_total_planning
请求方式: POST
接口描述: 物流-总程规划


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerList [CustomerList] [必填]
    字段描述: 客户数据
    示例: {"propertyCode":"customer_001","customerCode":"C001","customerName":"测试客户","areaCode":"area_001","depotCode":"depot_001"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: customer_001
  - customerCode [String (inner)] [必填]
    字段描述: 客户编码
    示例: cust_001
  - customerName [String (inner)] [必填]
    字段描述: 客户名称
    示例: XX客户
  - areaCode [String (inner)] [必填]
    字段描述: 围栏编码
    示例: fence_001
  - depotCode [String (inner)] [必填]
    字段描述: 仓库编码
    示例: depot_001
  - readyTime [String (inner)] [必填]
    字段描述: 起始时间
    示例: 08:00:00
  - dueTime [String (inner)] [必填]
    字段描述: 截止时间
    示例: 18:00:00
  - orderList [OrderList] [必填]
    字段描述: 订单数据
    示例: {"propertyCode":"order_001","orderCode":"order_id","skuNum":10,"boxNum":50}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: order_001
  - customerCode [String (inner)] [必填]
    字段描述: 客户编码
    示例: cust_001
  - orderNo [String (inner)] [必填]
    字段描述: 订单编号
    示例: ORD20260001
  - skuNum [Integer (inner)] [必填]
    字段描述: 订单数
    示例: 10
  - boxNum [Integer (inner)] [必填]
    字段描述: 运送量
    示例: 50
  - vehicleType [String (inner)] [必填]
    字段描述: 车型
    示例: small
  - firstOrder [Boolean (inner)] [必填]
    字段描述: 是否首发
    示例: false
  - depotList [DepotList] [必填]
    字段描述: 仓库数据
    示例: [{"code":"depot_001","name":"测试仓库","point":"POINT(116.3 39.9)"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: depot_001
  - code [String (inner)] [必填]
    字段描述: 仓库编码
    示例: D001
  - readyTime [String (inner)] [必填]
    字段描述: 开门时间
    示例: 06:00:00
  - dueTime [String (inner)] [必填]
    字段描述: 关门时间
    示例: 20:00:00
  - baseTime [Double (inner)] [必填]
    字段描述: 基础时间
    示例: 30
  - unloadTime [Double (inner)] [必填]
    字段描述: 卸货时间
    示例: 15.5
  - areaVehicle [AreaVehicle] [必填]
    字段描述: 区域数据
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码 (面数据)
    示例: fence_001
  - areaCode [String (inner)] [必填]
    字段描述: 区域编码
    示例: area_001
  - cantGoAreaCode [String (inner)] [可选]
    字段描述: 不可达车型
    示例: large
  - isBreak [IsBreak] [必填]
    字段描述: 是否可突破。是否允许破约束。可选值: true=允许突破约束; false=不允许突破约束
    示例: false
  - vehicleList [List<VehicleList>] [必填]
    字段描述: 车辆列表
    示例: [{"vehicleCode":"京A00001","vehicleName":"测试车辆","volume":50,"box":10}]
  - vehicleType [String (inner)] [必填]
    字段描述: 车型
    示例: small
  - depotCode [String (inner)] [必填]
    字段描述: 仓库编码
    示例: depot_001
  - number [Integer (inner)] [必填]
    字段描述: 数量
    示例: 5
  - box [Integer (inner)] [必填]
    字段描述: 载装量
    示例: 100
  - cost [Double (inner)] [必填]
    字段描述: 固定成本
    示例: 500.0
  - costPerKm [Double (inner)] [必填]
    字段描述: 每公里成本
    示例: 5.0
  - costPerMinutes [Double (inner)] [必填]
    字段描述: 每分钟成本
    示例: 0.5


接口请求示例:
  {
    "customerList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "customerName": "客户名称",
        "areaCode": "area_001",
        "depotCode": "depot_001",
        "readyTime": "readyTime",
        "dueTime": "dueTime"
    },
    "orderList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "orderNo": "orderNo",
        "skuNum": 10,
        "boxNum": 50,
        "vehicleType": "小型货车",
        "firstOrder": true
    },
    "depotList": {
        "propertyCode": "asset_001",
        "code": "code",
        "readyTime": "readyTime",
        "dueTime": "dueTime",
        "baseTime": 30,
        "unloadTime": 1
    },
    "areaVehicle": {
        "propertyCode": "asset_001",
        "areaCode": "area_001",
        "cantGoAreaCode": "cantGoAreaCode"
    },
    "isBreak": "true",
    "vehicleList": [
        {
            "vehicleType": "小型货车",
            "depotCode": "depot_001",
            "number": 5,
            "box": 10,
            "cost": 1,
            "costPerKm": 5,
            "costPerMinutes": 1
        }
    ]
}
```
**示例:**
```json
{
    "customerList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "customerName": "客户名称",
        "areaCode": "area_001",
        "depotCode": "depot_001",
        "readyTime": "readyTime",
        "dueTime": "dueTime"
    },
    "orderList": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "orderNo": "orderNo",
        "skuNum": 10,
        "boxNum": 50,
        "vehicleType": "小型货车",
        "firstOrder": true
    },
    "depotList": {
        "propertyCode": "asset_001",
        "code": "code",
        "readyTime": "readyTime",
        "dueTime": "dueTime",
        "baseTime": 30,
        "unloadTime": 1
    },
    "areaVehicle": {
        "propertyCode": "asset_001",
        "areaCode": "area_001",
        "cantGoAreaCode": "cantGoAreaCode"
    },
    "isBreak": "true",
    "vehicleList": [
        {
            "vehicleType": "小型货车",
            "depotCode": "depot_001",
            "number": 5,
            "box": 10,
            "cost": 1,
            "costPerKm": 5,
            "costPerMinutes": 1
        }
    ]
}
```

### logistics-planning-v1 — 物流线路规划
```bash
gogeo-cli common-task resource logistics-planning-v1 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/logistics_planning_v1
请求方式: POST
接口描述: 物流线路规划


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资信息
    示例: {"data":[{"code":"001","name":"XX门店"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：客资资产的字段
    示例: name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：客资资产的字段
    示例: address
  - orderData [OrderData] [必填]
    字段描述: 订单信息
  - propertyCode [String (inner)] [必填]
    字段描述: 订单信息
    示例: order_001
  - depotCode [String (inner)] [必填]
    字段描述: 仓库编码
    示例: depot_001
  - customerCode [String (inner)] [必填]
    字段描述: 客户编码
    示例: cust_001
  - demand [String (inner)] [必填]
    字段描述: 重量
    示例: 100
  - volume [String (inner)] [必填]
    字段描述: 体积
    示例: volume
  - box [String (inner)] [必填]
    字段描述: 标箱
    示例: box
  - depotData [DepotData] [必填]
    字段描述: 仓库信息
  - propertyCode [String (inner)] [必填]
    字段描述: 仓库信息
    示例: depot_001
  - readyTime [String (inner)] [必填]
    字段描述: 开门时间
    示例: 06:00:00
  - dueTime [String (inner)] [必填]
    字段描述: 关门时间
    示例: 20:00:00
  - code [String (inner)] [必填]
    字段描述: 仓库编码
    示例: code_001
  - travelTimeFactor [String (inner)] [必填]
    字段描述: 行驶时间系数
    示例: 2024-01-01
  - loadingTimeFactor [String (inner)] [可选]
    字段描述: 准备时间系数
    示例: 2024-01-01
  - serviceTimeFactor [String (inner)] [可选]
    字段描述: 服务时间系数
    示例: 2024-01-01
  - startTime [String (inner)] [必填]
    字段描述: 出车时间
    示例: 07:00:00
  - loadingTime [String (inner)] [必填]
    字段描述: 装车时间
    示例: 2024-01-01
  - costLabourPerDay [String (inner)] [必填]
    字段描述: 固定人工成本
    示例: costlabourperday
  - costPerBox [String (inner)] [必填]
    字段描述: 每标箱人工成本
    示例: costperbox
  - maxCustomer [String (inner)] [必填]
    字段描述: 每路线最大客户数
    示例: maxcustomer
  - maxTime [String (inner)] [可选]
    字段描述: 每路线最大时间
    示例: 480
  - maxDistanceCustomer [String (inner)] [可选]
    字段描述: 客户间最大距离
    示例: maxdistancecustomer
  - capacityConstraint [String (inner)] [可选]
    字段描述: 运力限制
    示例: 1000
  - multipleTrip [String (inner)] [必填]
    字段描述: 是否多次往返
    示例: multipletrip
  - bigOrder [String (inner)] [必填]
    字段描述: 是否优先大订单
    示例: bigorder
  - mulArea [String (inner)] [可选]
    字段描述: 是否考虑区域
    示例: mularea
  - smallVehicle [String (inner)] [可选]
    字段描述: 是否优先使用小车
    示例: smallvehicle
  - capacityFactor [String (inner)] [可选]
    字段描述: 运力系数
    示例: capacityfactor
  - vehicleData [VehicleData] [必填]
    字段描述: 车辆信息
  - propertyCode [String (inner)] [必填]
    字段描述: 车辆信息
    示例: vehicle_001
  - depotCode [String (inner)] [必填]
    字段描述: 仓库编码
    示例: depot_001
  - carNumbers [String (inner)] [必填]
    字段描述: 车牌号
    示例: 京A12345
  - box [String (inner)] [必填]
    字段描述: 标箱
    示例: box
  - capacity [String (inner)] [必填]
    字段描述: 运力
    示例: 500
  - volume [String (inner)] [必填]
    字段描述: 体积
    示例: 100
  - cost [String (inner)] [必填]
    字段描述: 固定成本
    示例: 500
  - costPerKm [String (inner)] [必填]
    字段描述: 每公里成本
    示例: costperkm
  - canGoAreaCode [String (inner)] [必填]
    字段描述: 可达区域
    示例: area_001
  - cantGoAreaCode [String (inner)] [可选]
    字段描述: 不可达区域
    示例: area_002
  - isBreak [String] [可选]
    字段描述: 是否允许破约束。可选值: true=允许突破约束; false=不允许突破约束


接口请求示例:
  {
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "orderData": {
        "propertyCode": "asset_001",
        "depotCode": "depot_001",
        "customerCode": "customer_001",
        "demand": "demand",
        "volume": "volume",
        "box": "box"
    },
    "depotData": {
        "propertyCode": "asset_001",
        "readyTime": "readyTime",
        "dueTime": "dueTime",
        "code": "code",
        "travelTimeFactor": "travelTimeFactor",
        "loadingTimeFactor": "loadingTimeFactor",
        "serviceTimeFactor": "serviceTimeFactor",
        "startTime": "startTime",
        "loadingTime": "loadingTime",
        "costLabourPerDay": "costLabourPerDay",
        "costPerBox": "costPerBox",
        "maxCustomer": "maxCustomer",
        "maxTime": "maxTime",
        "maxDistanceCustomer": "maxDistanceCustomer",
        "capacityConstraint": "capacityConstraint",
        "multipleTrip": "multipleTrip",
        "bigOrder": "bigOrder",
        "mulArea": "mulArea",
        "smallVehicle": "smallVehicle",
        "capacityFactor": "capacityFactor"
    },
    "vehicleData": {
        "propertyCode": "asset_001",
        "depotCode": "depot_001",
        "carNumbers": "carNumbers",
        "box": "box",
        "capacity": "capacity",
        "volume": "volume",
        "cost": "cost",
        "costPerKm": "costPerKm",
        "canGoAreaCode": "canGoAreaCode",
        "cantGoAreaCode": "cantGoAreaCode"
    },
    "isBreak": "true"
}
```
**示例:**
```json
{
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "orderData": {
        "propertyCode": "asset_001",
        "depotCode": "depot_001",
        "customerCode": "customer_001",
        "demand": "demand",
        "volume": "volume",
        "box": "box"
    },
    "depotData": {
        "propertyCode": "asset_001",
        "readyTime": "readyTime",
        "dueTime": "dueTime",
        "code": "code",
        "travelTimeFactor": "travelTimeFactor",
        "loadingTimeFactor": "loadingTimeFactor",
        "serviceTimeFactor": "serviceTimeFactor",
        "startTime": "startTime",
        "loadingTime": "loadingTime",
        "costLabourPerDay": "costLabourPerDay",
        "costPerBox": "costPerBox",
        "maxCustomer": "maxCustomer",
        "maxTime": "maxTime",
        "maxDistanceCustomer": "maxDistanceCustomer",
        "capacityConstraint": "capacityConstraint",
        "multipleTrip": "multipleTrip",
        "bigOrder": "bigOrder",
        "mulArea": "mulArea",
        "smallVehicle": "smallVehicle",
        "capacityFactor": "capacityFactor"
    },
    "vehicleData": {
        "propertyCode": "asset_001",
        "depotCode": "depot_001",
        "carNumbers": "carNumbers",
        "box": "box",
        "capacity": "capacity",
        "volume": "volume",
        "cost": "cost",
        "costPerKm": "costPerKm",
        "canGoAreaCode": "canGoAreaCode",
        "cantGoAreaCode": "cantGoAreaCode"
    },
    "isBreak": "true"
}
```

### generate-navigation-route-v1 — 物流 - 路径规划
```bash
gogeo-cli common-task resource generate-navigation-route-v1 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/generate_navigation_route_v1
请求方式: POST
接口描述: 物流 - 路径规划


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - group1 [String] [必填]
    字段描述: 分组字段一
    示例: route_group
  - group2 [String] [必填]
    字段描述: 分组字段二
    示例: route_group
  - group3 [String] [可选]
    字段描述: 分组字段三
  - group4 [String] [可选]
    字段描述: 分组字段四
  - group5 [String] [可选]
    字段描述: 分组字段五
  - arrivalOrder [String] [必填]
    字段描述: 到达顺序
  - startLocation [String] [必填]
    字段描述: 起始位置
  - trackType [TrackType] [必填]
    字段描述: 生成方式。轨迹/路线生成方式。可选值: bicycling=骑行; driving=驾车; straightLine=直线; walking=步行
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "group1": "route_group1",
    "group2": "route_group2",
    "group3": "route_group3",
    "group4": "route_group4",
    "group5": "group5",
    "arrivalOrder": "arrivalOrder",
    "startLocation": "startLocation",
    "trackType": "driving",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "group1": "route_group1",
    "group2": "route_group2",
    "group3": "route_group3",
    "group4": "route_group4",
    "group5": "group5",
    "arrivalOrder": "arrivalOrder",
    "startLocation": "startLocation",
    "trackType": "driving",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### route-replay — 物流 - 线路重排
```bash
gogeo-cli common-task realtime resource realtime-route-replay --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/route_replay
请求方式: POST
接口描述: 物流 - 线路重排


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - groupId [String] [必填]
    字段描述: 分组字段一
    示例: salesman_id
  - round [String] [必填]
    字段描述: 分组字段二
    示例: route_seq
  - startLocation [String] [必填]
    字段描述: 起始位置
    示例: warehouse_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "groupId": "groupId",
    "round": "round",
    "startLocation": "startLocation"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "groupId": "groupId",
    "round": "round",
    "startLocation": "startLocation"
}
```

### sale-group-planning — 销售分组规划
```bash
gogeo-cli common-task resource sale-group-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/sale_group_planning
请求方式: POST
接口描述: 销售分组规划


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - baseResource [BaseResource] [必填]
    字段描述: 销售数据
    示例: {"propertyCode":"base_001","skills":"skill_A","code":"base_code"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: sales_001
  - skills [String (inner)] [必填]
    字段描述: 所需技能
    示例: skill_A
  - code [String (inner)] [必填]
    字段描述: 销售编码
    示例: S001
  - outletsList [OutletsList] [必填]
    字段描述: 门店数据
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: outlets_001
  - potential [String (inner)] [必填]
    字段描述: 潜力
    示例: high
  - serviceTime [String (inner)] [必填]
    字段描述: 服务时长
    示例: 2024-01-01
  - priority [String (inner)] [必填]
    字段描述: 拜访优先级
    示例: priority
  - visitFrequency [Integer (inner)] [必填]
    字段描述: 拜访频次
    示例: 3
  - needSkills [String (inner)] [必填]
    字段描述: 所需技能
    示例: skill_A
  - resourceCode [String (inner)] [可选]
    字段描述: 所属销售
    示例: S001
  - taskSettingVO [TaskSettingVO] [必填]
    字段描述: 任务配置参数
  - planTerritory [PlanTerritory] [必填]
    字段描述: 规划区域参数
  - planWeeks [Integer (inner)] [必填]
    字段描述: 规划周数
    示例: 4
  - saturation [Double (inner)] [必填]
    字段描述: 饱和度
    示例: 0.8
  - workdayTime [Double (inner)] [必填]
    字段描述: 每天工作时长
    示例: 8.0
  - weekWorkdays [Integer (inner)] [必填]
    字段描述: 每周工作天数
    示例: 5
  - maxOutletsPerTour [Integer (inner)] [必填]
    字段描述: 最大访问门店数
    示例: 20
  - maximumDistance [Double (inner)] [必填]
    字段描述: 两点之间最大距离
    示例: 50.0
  - ifRelationActive [Boolean (inner)] [必填]
    字段描述: 已有门店关系是否生效
    示例: true


接口请求示例:
  {
    "baseResource": {
        "propertyCode": "asset_001",
        "skills": "skill_A",
        "code": "code"
    },
    "outletsList": {
        "propertyCode": "asset_001",
        "potential": "potential",
        "serviceTime": "serviceTime",
        "priority": "priority",
        "visitFrequency": 3,
        "needSkills": "needSkills",
        "resourceCode": "resourceCode"
    },
    "taskSettingVO": {},
    "planTerritory": {
        "planWeeks": 4,
        "saturation": 1,
        "workdayTime": 1,
        "weekWorkdays": 5,
        "maxOutletsPerTour": 20,
        "maximumDistance": 1,
        "ifRelationActive": true
    }
}
```
**示例:**
```json
{
    "baseResource": {
        "propertyCode": "asset_001",
        "skills": "skill_A",
        "code": "code"
    },
    "outletsList": {
        "propertyCode": "asset_001",
        "potential": "potential",
        "serviceTime": "serviceTime",
        "priority": "priority",
        "visitFrequency": 3,
        "needSkills": "needSkills",
        "resourceCode": "resourceCode"
    },
    "taskSettingVO": {},
    "planTerritory": {
        "planWeeks": 4,
        "saturation": 1,
        "workdayTime": 1,
        "weekWorkdays": 5,
        "maxOutletsPerTour": 20,
        "maximumDistance": 1,
        "ifRelationActive": true
    }
}
```

### service-day-week-division — 服务日-周划分
```bash
gogeo-cli common-task resource service-day-week-division --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/serviceDayWeekDivision
请求方式: POST
接口描述: 服务日-周划分


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资信息
    示例: {"data":[{"code":"001","name":"XX门店"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：客资资产的字段
    示例: name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：客资资产的字段
    示例: address
  - salesData [SalesData] [必填]
    字段描述: 销售信息
    示例: {"propertyCode":"sales_001","skills":"skill_A","code":"sales_code"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: sales_asset_001
  - code [String (inner)] [必填]
    字段描述: 销售编码（销售信息 - 销售编码）
    示例: S001
  - maxDistance [String (inner)] [必填]
    字段描述: 最大售点距离，单位：km
    示例: maxdistance
  - maxVisitNum [String (inner)] [可选]
    字段描述: 每日最大服务客户数
    示例: maxvisitnum
  - minVisitNum [String (inner)] [可选]
    字段描述: 每日最小服务客户数
    示例: minvisitnum
  - historyData [HistoryData] [必填]
    字段描述: 历史拜访数据列表
    示例: {"propertyCode":"history_001","customerCode":"C001","visitDate":"2024-01-01"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: history_001
  - customerCode [String (inner)] [必填]
    字段描述: 客资编码（历史拜访数据）
    示例: cust_001
  - visitDate [String (inner)] [必填]
    字段描述: 实际拜访日期（历史拜访数据）
    示例: 2026-04-01
  - salesCode [String (inner)] [必填]
    字段描述: 销售编码（历史拜访数据）
    示例: S001
  - scuPropertyCode [String] [可选]
    字段描述: 围栏数据（只包含资产编码）
  - divideType [DivideType] [必填]
    字段描述: 划分类型。时间划分粒度。可选值: week=周; day=日
    示例: week
  - balanceField [String] [必填]
    字段描述: 均衡字段（客资信息 - 用于均衡分配客户）
    示例: potentialValue
  - group1 [String] [必填]
    字段描述: 拜访周（divideType 为 week 时必填，客户信息 - 服务日、服务周划分标识，如果第二次规划想基于第一次的基础进行则需要选择）
    示例: potentialValue
  - group2 [String] [可选]
    字段描述: 拜访日
  - workDay [String] [可选]
    字段描述: 工作日（divideType 为 day 时必填）
  - startEndDate [List<String>] [必填]
    字段描述: 开始结束日期列表
    示例: ["2024-01-01"]


接口请求示例:
  {
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "salesData": {
        "propertyCode": "asset_001",
        "code": "code",
        "maxDistance": "maxDistance",
        "maxVisitNum": "maxVisitNum",
        "minVisitNum": "minVisitNum"
    },
    "historyData": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "visitDate": "visitDate",
        "salesCode": "salesCode"
    },
    "scuPropertyCode": "scuPropertyCode",
    "divideType": "week",
    "balanceField": "balanceField",
    "group1": "route_group1",
    "group2": "route_group2",
    "workDay": "周一",
    "startEndDate": [
        "startEndDate"
    ]
}
```
**示例:**
```json
{
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "salesData": {
        "propertyCode": "asset_001",
        "code": "code",
        "maxDistance": "maxDistance",
        "maxVisitNum": "maxVisitNum",
        "minVisitNum": "minVisitNum"
    },
    "historyData": {
        "propertyCode": "asset_001",
        "customerCode": "customer_001",
        "visitDate": "visitDate",
        "salesCode": "salesCode"
    },
    "scuPropertyCode": "scuPropertyCode",
    "divideType": "week",
    "balanceField": "balanceField",
    "group1": "route_group1",
    "group2": "route_group2",
    "workDay": "周一",
    "startEndDate": [
        "startEndDate"
    ]
}
```

### service-route-planning — 服务路线规划
```bash
gogeo-cli common-task resource service-route-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/serviceRoutePlanning
请求方式: POST
接口描述: 服务路线规划


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资信息
    示例: {"data":[{"code":"001","name":"XX门店"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：客资资产的字段
    示例: name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：客资资产的字段
    示例: address
  - salesData [SalesData] [必填]
    字段描述: 销售信息
    示例: {"propertyCode":"sales_001","skills":"skill_A","code":"sales_code"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: sales_asset_001
  - code [String (inner)] [必填]
    字段描述: 销售编码（销售信息 - 销售编码）
    示例: S001
  - maxDistance [String (inner)] [必填]
    字段描述: 最大售点距离，单位：km
    示例: maxdistance
  - maxVisitNum [String (inner)] [可选]
    字段描述: 每日最大服务客户数
    示例: maxvisitnum
  - minVisitNum [String (inner)] [可选]
    字段描述: 每日最小服务客户数
    示例: minvisitnum
  - group1 [String] [必填]
    字段描述: 拜访周
  - group2 [String] [必填]
    字段描述: 拜访日
  - startEndDate [List<String>] [必填]
    字段描述: 开始结束时间段，格式：yyyy-MM-dd HH:mm:ss


接口请求示例:
  {
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "salesData": {
        "propertyCode": "asset_001",
        "code": "code",
        "maxDistance": "maxDistance",
        "maxVisitNum": "maxVisitNum",
        "minVisitNum": "minVisitNum"
    },
    "group1": "route_group1",
    "group2": "route_group2",
    "startEndDate": [
        "startEndDate"
    ]
}
```
**示例:**
```json
{
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "salesData": {
        "propertyCode": "asset_001",
        "code": "code",
        "maxDistance": "maxDistance",
        "maxVisitNum": "maxVisitNum",
        "minVisitNum": "minVisitNum"
    },
    "group1": "route_group1",
    "group2": "route_group2",
    "startEndDate": [
        "startEndDate"
    ]
}
```

### vehicle-sales-planning — 车销规划
```bash
gogeo-cli common-task resource vehicle-sales-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/vehicleSalesPlanning
请求方式: POST
接口描述: 车销规划


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资信息
    示例: {"data":[{"code":"001","name":"XX门店"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：客资资产的字段
    示例: name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：客资资产的字段
    示例: address
  - salesData [SalesData] [必填]
    字段描述: 销售信息
    示例: {"propertyCode":"sales_001","skills":"skill_A","code":"sales_code"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: sales_asset_001
  - code [String (inner)] [必填]
    字段描述: 销售编码（销售信息 - 销售编码）
    示例: S001
  - maxDistance [String (inner)] [必填]
    字段描述: 最大售点距离，单位：km
    示例: maxdistance
  - maxVisitNum [String (inner)] [可选]
    字段描述: 每日最大服务客户数
    示例: maxvisitnum
  - minVisitNum [String (inner)] [可选]
    字段描述: 每日最小服务客户数
    示例: minvisitnum
  - balanceField [String] [必填]
    字段描述: 均衡字段
  - workDay [String] [必填]
    字段描述: 工作天数


接口请求示例:
  {
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "salesData": {
        "propertyCode": "asset_001",
        "code": "code",
        "maxDistance": "maxDistance",
        "maxVisitNum": "maxVisitNum",
        "minVisitNum": "minVisitNum"
    },
    "balanceField": "balanceField",
    "workDay": "周一"
}
```
**示例:**
```json
{
    "customerData": {
        "propertyCode": "asset_001",
        "textStr1": "name",
        "textStr2": "address"
    },
    "salesData": {
        "propertyCode": "asset_001",
        "code": "code",
        "maxDistance": "maxDistance",
        "maxVisitNum": "maxVisitNum",
        "minVisitNum": "minVisitNum"
    },
    "balanceField": "balanceField",
    "workDay": "周一"
}
```

### sale-visit-planning — 销售-拜访规划
```bash
gogeo-cli common-task resource sale-visit-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineResourcePlanningController/sale_visit_planning
请求方式: POST
接口描述: 销售拜访规划


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - baseResource [BaseResource] [必填]
    字段描述: 点数据（销售资源）
    示例: {"propertyCode":"base_001","skills":"skill_A","code":"base_code"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: sales_001
  - skills [String (inner)] [必填]
    字段描述: 所需技能
    示例: skill_A
  - code [String (inner)] [必填]
    字段描述: 销售编码
    示例: S001
  - outletsList [OutletsList] [必填]
    字段描述: 门店信息
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: outlets_001
  - potential [String (inner)] [必填]
    字段描述: 潜力
    示例: high
  - serviceTime [String (inner)] [必填]
    字段描述: 服务时长
    示例: 2024-01-01
  - priority [String (inner)] [必填]
    字段描述: 拜访优先级
    示例: priority
  - visitFrequency [Integer (inner)] [必填]
    字段描述: 拜访频次
    示例: 3
  - needSkills [String (inner)] [必填]
    字段描述: 所需技能
    示例: skill_A
  - resourceCode [String (inner)] [可选]
    字段描述: 所属销售
    示例: S001
  - taskSetting [TaskSetting] [必填]
    字段描述: 任务配置参数
  - planVisitTourSetting [PlanVisitTourSetting] [必填]
    字段描述: 巡防设置参数
  - startDate [String (inner)] [必填]
    字段描述: 开始时间
    示例: 2026-04-01
  - planWeeks [Integer (inner)] [必填]
    字段描述: 规划周数
    示例: 4
  - weekWorkdays [Integer (inner)] [必填]
    字段描述: 每周工作天数
    示例: 5
  - workdayTime [Double (inner)] [必填]
    字段描述: 每天工作时长
    示例: 8.0


接口请求示例:
  {
    "baseResource": {
        "propertyCode": "asset_001",
        "skills": "skill_A",
        "code": "code"
    },
    "outletsList": {
        "propertyCode": "asset_001",
        "potential": "potential",
        "serviceTime": "serviceTime",
        "priority": "priority",
        "visitFrequency": 3,
        "needSkills": "needSkills",
        "resourceCode": "resourceCode"
    },
    "taskSetting": {},
    "planVisitTourSetting": {
        "startDate": "startDate",
        "planWeeks": 4,
        "weekWorkdays": 5,
        "workdayTime": 1
    }
}
```
**示例:**
```json
{
    "baseResource": {
        "propertyCode": "asset_001",
        "skills": "skill_A",
        "code": "code"
    },
    "outletsList": {
        "propertyCode": "asset_001",
        "potential": "potential",
        "serviceTime": "serviceTime",
        "priority": "priority",
        "visitFrequency": 3,
        "needSkills": "needSkills",
        "resourceCode": "resourceCode"
    },
    "taskSetting": {},
    "planVisitTourSetting": {
        "startDate": "startDate",
        "planWeeks": 4,
        "weekWorkdays": 5,
        "workdayTime": 1
    }
}
```

## spatial

### affiliation-area-v1 — 归属区域生成 V1-自定义面请求
```bash
gogeo-cli common-task analysis affiliation-area-v1 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/affiliation_area_generate_v1_custom_polygon
请求方式: POST
接口描述: 归属区域生成 V1-自定义面请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointDataPropertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - fenceDataPropertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_001
  - name [String] [必填]
    字段描述: 归属区域字段：点数据中的归属区域字段，必填
    示例: areaName
  - num [String] [必填]
    字段描述: 潜力字段：点数据中的潜力字段
    示例: potentialValue
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计字段配置列表
    示例: potentialValue
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointDataPropertyCode": "pointDataPropertyCode",
    "fenceDataPropertyCode": "fenceDataPropertyCode",
    "name": "测试名称",
    "num": "potentialValue",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "pointDataPropertyCode": "pointDataPropertyCode",
    "fenceDataPropertyCode": "fenceDataPropertyCode",
    "name": "测试名称",
    "num": "potentialValue",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### area-split — 等面积划分数据处理请求
```bash
gogeo-cli common-task analysis area-split --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/area_split_plan
请求方式: POST
接口描述: 等面积划分数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_001
  - splitCount [Integer] [必填]
    字段描述: 划分数量
    示例: 5
  - balance [Integer] [必填]
    字段描述: 平衡值
    示例: 50
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合字段配置列表
    示例: [...]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "splitCount": 5,
    "balance": 50,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "splitCount": 5,
    "balance": 50,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### belonging-area-v2 — 归属区域生成 V2 请求
```bash
gogeo-cli common-task analysis belonging-area-v2 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/belonging_area_generate_v2
请求方式: POST
接口描述: 归属区域生成 V2 请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointData [PointData] [必填]
    字段描述: 点数据
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码，必填
    示例: point_001
  - groupCode [String (inner)] [必填]
    字段描述: 分组编码，非必填
    示例: group_001
  - num [String (inner)] [可选]
    字段描述: 潜力字段，非必填
    示例: potentialValue
  - fencePropertyCode [String] [必填]
    字段描述: 围栏数据资产编码
  - customizeFencePropertyCode [String] [可选]
    字段描述: 自定义围栏数据资产编码
  - connectType [ConnectType] [必填]
    字段描述: 划分类型：1-网格，2-蜂窝。连接/网格类型(V2)。可选值: 1=网格; 2=蜂窝
    示例: 1
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级：city-城市，district-区县，province-省份。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围
    示例: ["effectivescope"]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": {
        "propertyCode": "asset_001",
        "groupCode": "group_001",
        "num": "potentialValue"
    },
    "fencePropertyCode": "fence_asset",
    "customizeFencePropertyCode": "customizeFencePropertyCode",
    "connectType": "1",
    "boundaryLevel": "province",
    "effectiveScope": [
        "effectiveScope"
    ],
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "pointData": {
        "propertyCode": "asset_001",
        "groupCode": "group_001",
        "num": "potentialValue"
    },
    "fencePropertyCode": "fence_asset",
    "customizeFencePropertyCode": "customizeFencePropertyCode",
    "connectType": "1",
    "boundaryLevel": "province",
    "effectiveScope": [
        "effectiveScope"
    ],
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### cluster-center — 点聚类中心点数据处理请求
```bash
gogeo-cli common-task analysis cluster-center --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/cluster_center
请求方式: POST
接口描述: 点聚类中心点数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: point_001
  - partitionNum [Integer] [可选]
    字段描述: 
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "partitionNum": 10,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "partitionNum": 10,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### equal-value-split — 等潜力划分V2-面数据处理请求
```bash
gogeo-cli common-task analysis equal-value-split --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/equal_value_split_v2
请求方式: POST
接口描述: 等潜力划分V2-面数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_001
  - num [String] [必填]
    字段描述: 潜力字段
    示例: sales_volume
  - splitCount [Integer] [可选]
    字段描述: 
  - balanceValue [Integer] [可选]
    字段描述: 
  - compareValue [Integer] [可选]
    字段描述: 
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "num": "potentialValue",
    "splitCount": 5,
    "balanceValue": 1,
    "compareValue": 1,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "num": "potentialValue",
    "splitCount": 5,
    "balanceValue": 1,
    "compareValue": 1,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### fence-buffer — 围栏外扩缓冲区
```bash
gogeo-cli common-task analysis fence-buffer --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/fence_broad_buffer
请求方式: POST
接口描述: 围栏外扩缓冲区


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：售点数据
    示例: fence_001
  - bufferArea [String] [必填]
    字段描述: 外扩范围（米）
    示例: 1000


接口请求示例:
  {
    "propertyCode": "asset_001",
    "bufferArea": "bufferArea"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "bufferArea": "bufferArea"
}
```

### fence-cluster — 面聚类分析请求
```bash
gogeo-cli common-task analysis fence-cluster --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/fence_cluster_analysis
请求方式: POST
接口描述: 面聚类分析请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_property_001
  - partitionNum [Integer] [必填]
    字段描述: 划分数量
    示例: 10


接口请求示例:
  {
    "propertyCode": "asset_001",
    "partitionNum": 10
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "partitionNum": 10
}
```

### fence-crossing — 围栏不相交的区域数据处理请求
```bash
gogeo-cli common-task analysis fence-crossing --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/fence_crossing
请求方式: POST
接口描述: 围栏不相交的区域数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - sourcePropertyCode [String] [可选]
    字段描述: 
  - targetPropertyCode [String] [可选]
    字段描述: 


接口请求示例:
  {
    "sourcePropertyCode": "source_asset",
    "targetPropertyCode": "target_asset"
}
```
**示例:**
```json
{
    "sourcePropertyCode": "source_asset",
    "targetPropertyCode": "target_asset"
}
```

### grid-split — 围栏内生成网格数据处理请求
```bash
gogeo-cli common-task analysis grid-split --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/grid_fence_split_polygon
请求方式: POST
接口描述: 围栏内生成网格数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [可选]
    字段描述: 
  - sideLength [Integer] [可选]
    字段描述: 
  - splitMode [SplitMode] [可选]
    字段描述: 围栏分裂模式。可选值: 1=相交保留; 2=相交裁剪; 3=包含保留; 4=中心在围栏内保留


接口请求示例:
  {
    "propertyCode": "asset_001",
    "sideLength": 100,
    "splitMode": "1"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "sideLength": 100,
    "splitMode": "1"
}
```

### hexagon-split — 围栏内生成蜂窝数据处理请求
```bash
gogeo-cli common-task analysis hexagon-split --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/hexagon_fence_split_polygon
请求方式: POST
接口描述: 围栏内生成蜂窝数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [可选]
    字段描述: 
  - sideLength [Integer] [可选]
    字段描述: 
  - splitMode [SplitMode] [可选]
    字段描述: 围栏分裂模式。可选值: 1=相交保留; 2=相交裁剪; 3=包含保留; 4=中心在围栏内保留


接口请求示例:
  {
    "propertyCode": "asset_001",
    "sideLength": 100,
    "splitMode": "1"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "sideLength": 100,
    "splitMode": "1"
}
```

### kmeans — KMeans 算法数据处理请求
```bash
gogeo-cli common-task analysis kmeans --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/point_kmeans
请求方式: POST
接口描述: KMeans 算法数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点数据资产编码
  - clusterType [String] [必填]
    字段描述: 聚类类型。可选值: 1=面; 2=点转面
  - clusterAlgorithm [ClusterAlgorithm] [必填]
    字段描述: 聚类算法。可选值: 0=Kmeans
  - gridType [GridType] [可选]
    字段描述: 网格类型。KMeans网格/蜂窝类型。可选值: GD_r1000=R1000网格; GD_r2000=R2000网格; GD_r500=R500网格; HD_r1000=R1000蜂窝; HD_r2000=R2000蜂窝; HD_r500=R500蜂窝; RD_four=4级路网
  - amount [Integer] [必填]
    字段描述: 划分数量


接口请求示例:
  {
    "propertyCode": "asset_001",
    "clusterType": "1",
    "clusterAlgorithm": "0",
    "gridType": "GD_r1000",
    "amount": 5
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "clusterType": "1",
    "clusterAlgorithm": "0",
    "gridType": "GD_r1000",
    "amount": 5
}
```

### line-buffer — 线外扩缓冲区数据处理请求
```bash
gogeo-cli common-task analysis line-buffer --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/line_buffer
请求方式: POST
接口描述: 线外扩缓冲区数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - linePropertyCode [String] [可选]
    字段描述: 
  - buffer [Integer] [可选]
    字段描述: 
  - endCapStyle [BufferStyle] [可选]
    字段描述: 线缓冲端点样式，可选值: 1=半圆; 2=平面; 3=方形
  - quadrantSegments [Integer] [可选]
    字段描述: 


接口请求示例:
  {
    "linePropertyCode": "line_asset",
    "buffer": 500,
    "endCapStyle": "1",
    "quadrantSegments": 8
}
```
**示例:**
```json
{
    "linePropertyCode": "line_asset",
    "buffer": 500,
    "endCapStyle": "1",
    "quadrantSegments": 8
}
```

### point-cluster — 点聚类分析请求
```bash
gogeo-cli common-task analysis point-cluster --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/point_cluster_analysis
请求方式: POST
接口描述: 点聚类分析请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_property_001
  - partitionNum [Integer] [必填]
    字段描述: 划分数量
    示例: 10


接口请求示例:
  {
    "propertyCode": "asset_001",
    "partitionNum": 10
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "partitionNum": 10
}
```

### potential-classification — 等潜力划分 V2-点数据处理请求
```bash
gogeo-cli common-task analysis potential-classification --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/potential_classification_v2_point
请求方式: POST
接口描述: 等潜力划分 V2-点数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointData [PointData] [必填]
    字段描述: 点数据
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码，必填
    示例: point_001
  - groupCode [String (inner)] [必填]
    字段描述: 分组编码，非必填
    示例: group_001
  - num [String (inner)] [可选]
    字段描述: 潜力字段，非必填
    示例: potentialValue
  - customizeFencePropertyCode [String] [必填]
    字段描述: 自定义围栏数据资产编码
  - connectType [ConnectType] [可选]
    字段描述: 连接/网格类型(V2)。可选值: 1=网格; 2=蜂窝
  - boundaryLevel [BoundaryLevel] [可选]
    字段描述: 行政边界级别。可选值: province=省份; city=城市; district=区县
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围（多选）
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": {
        "propertyCode": "asset_001",
        "groupCode": "group_001",
        "num": "potentialValue"
    },
    "customizeFencePropertyCode": "customizeFencePropertyCode",
    "connectType": "1",
    "boundaryLevel": "province",
    "effectiveScope": [
        "effectiveScope"
    ],
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "pointData": {
        "propertyCode": "asset_001",
        "groupCode": "group_001",
        "num": "potentialValue"
    },
    "customizeFencePropertyCode": "customizeFencePropertyCode",
    "connectType": "1",
    "boundaryLevel": "province",
    "effectiveScope": [
        "effectiveScope"
    ],
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### potential-split — 等潜力划分数据处理请求
```bash
gogeo-cli common-task analysis potential-split --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/potential_area_split_plan
请求方式: POST
接口描述: 等潜力划分数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 等潜力划分面数据资产编码
    示例: fence_001
  - num [String] [必填]
    字段描述: 潜力字段
    示例: sales_volume
  - splitCount [Integer] [必填]
    字段描述: 划分数量
    示例: 5
  - balance [Integer] [必填]
    字段描述: 平衡值
    示例: 50
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合字段配置列表
    示例: [...]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "num": "potentialValue",
    "splitCount": 5,
    "balance": 50,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "num": "potentialValue",
    "splitCount": 5,
    "balance": 50,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### projection-area — 投影面积计算请求
```bash
gogeo-cli common-task analysis projection-area --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/projection_area_calculation
请求方式: POST
接口描述: 投影面积计算请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 面资产编码
    示例: fence_property_001


接口请求示例:
  {
    "propertyCode": "asset_001"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001"
}
```

### random-points — 围栏内创建随机点
```bash
gogeo-cli common-task analysis random-points --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/point_random_create
请求方式: POST
接口描述: 围栏内创建随机点


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：售点数据
    示例: point_001
  - randomNum [String] [必填]
    字段描述: 随机点个数
    示例: randomnum
  - translationFields [List<String>] [必填]
    字段描述: 结果拼接
    示例: ["translationfields"]


接口请求示例:
  {
    "propertyCode": "asset_001",
    "randomNum": "randomNum",
    "translationFields": [
        "translationFields"
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "randomNum": "randomNum",
    "translationFields": [
        "translationFields"
    ]
}
```

### random-sample — 围栏内随机取样数据处理请求
```bash
gogeo-cli common-task analysis random-sample --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialAnalysisController/fence_random_sample
请求方式: POST
接口描述: 围栏内随机取样数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointPropertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - fencePropertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_001
  - count [Integer] [必填]
    字段描述: 取样数（个）
    示例: 100


接口请求示例:
  {
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset",
    "count": 100
}
```
**示例:**
```json
{
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset",
    "count": 100
}
```

### belonging-area-v1 — 归属区域生成 V1 请求
```bash
gogeo-cli common-task calculation belonging-area-v1 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/belonging_area_generate_v1
请求方式: POST
接口描述: 归属区域生成 V1 请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码
    示例: point_001
  - name [String] [必填]
    字段描述: 归属区域字段：点数据中的归属区域字段
    示例: areaName
  - num [String] [必填]
    字段描述: 潜力字段：点数据中的潜力字段
    示例: potentialValue
  - connectType [ConnectType] [必填]
    字段描述: 连接方式：1-直线，2-网格，3-蜂窝。连接/网格类型(V2)。可选值: 1=网格; 2=蜂窝
    示例: 1
  - boundaryLevel [BoundaryLevel] [可选]
    字段描述: 边界等级，连接方式为 2 或 3 时必填。行政边界级别。可选值: province=省份; city=城市; district=区县
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "name": "测试名称",
    "num": "potentialValue",
    "connectType": "1",
    "boundaryLevel": "province",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "name": "测试名称",
    "num": "potentialValue",
    "connectType": "1",
    "boundaryLevel": "province",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### center-point — 内外心计算
```bash
gogeo-cli common-task calculation center-point --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/center_point_compute
请求方式: POST
接口描述: 内外心计算


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：围栏数据
    示例: fence_001
  - computeType [ComputeType] [必填]
    字段描述: 计算方式。中心点计算方式。可选值: 1=内心; 2=外心
    示例: 1


接口请求示例:
  {
    "propertyCode": "asset_001",
    "computeType": "1"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "computeType": "1"
}
```

### fence-contain — 围栏包含围栏请求
```bash
gogeo-cli common-task calculation fence-contain --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/fence_contain_fence
请求方式: POST
接口描述: 围栏包含围栏请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - mainPropertyCode [String] [必填]
    字段描述: 主数据资产编码
    示例: fence_main_001
  - auxiliaryPropertyCode [String] [必填]
    字段描述: 辅数据资产编码
    示例: fence_aux_001
  - translationFields [List<String>] [可选]
    字段描述: 结果容易字段 (辅数据资产的字段)，非必填
    示例: true


接口请求示例:
  {
    "mainPropertyCode": "mainPropertyCode",
    "auxiliaryPropertyCode": "auxiliaryPropertyCode",
    "translationFields": [
        "translationFields"
    ]
}
```
**示例:**
```json
{
    "mainPropertyCode": "mainPropertyCode",
    "auxiliaryPropertyCode": "auxiliaryPropertyCode",
    "translationFields": [
        "translationFields"
    ]
}
```

### fence-contain-relation — 单围栏包含关系
```bash
gogeo-cli common-task calculation fence-contain-relation --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/fence_contain_relation
请求方式: POST
接口描述: 单围栏包含关系


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：面数据
    示例: fence_001
  - field1 [String] [必填]
    字段描述: 分组字段 1
    示例: city
  - field2 [String] [可选]
    字段描述: 分组字段 2
    示例: district
  - field3 [String] [可选]
    字段描述: 分组字段 3
    示例: province
  - field4 [String] [可选]
    字段描述: 分组字段 4
    示例: region
  - field5 [String] [可选]
    字段描述: 分组字段 5
    示例: zone
  - oneToOneFlag [Boolean] [必填]
    字段描述: 包含类型（true: 单围栏，false: 多围栏）
    示例: true
  - isGroup [Boolean] [必填]
    字段描述: 是否分组（true: 是，false: 否）
    示例: true
  - containRatio [String] [必填]
    字段描述: 包含比例
    示例: 100
  - isAll [Boolean] [必填]
    字段描述: 是否需要全量数据（true: 是，false: 否）
    示例: false


接口请求示例:
  {
    "propertyCode": "asset_001",
    "field1": "field1",
    "field2": "field2",
    "field3": "field3",
    "field4": "field4",
    "field5": "field5",
    "oneToOneFlag": true,
    "isGroup": true,
    "containRatio": "containRatio",
    "isAll": true
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "field1": "field1",
    "field2": "field2",
    "field3": "field3",
    "field4": "field4",
    "field5": "field5",
    "oneToOneFlag": true,
    "isGroup": true,
    "containRatio": "containRatio",
    "isAll": true
}
```

### fence-equalization — 片区扇形切分数据处理请求
```bash
gogeo-cli common-task calculation fence-equalization --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/fence_equalization
请求方式: POST
接口描述: 片区扇形切分数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_001
  - point [String] [必填]
    字段描述: 起始经纬度字段
    示例: center_point
  - equalNumber [Integer] [必填]
    字段描述: 等分数量
    示例: 4


接口请求示例:
  {
    "propertyCode": "asset_001",
    "point": "point",
    "equalNumber": 4
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "point": "point",
    "equalNumber": 4
}
```

### fence-intersection-area — 围栏相交的区域请求
```bash
gogeo-cli common-task calculation fence-intersection-area --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/fence_intersection_area
请求方式: POST
接口描述: 围栏相交的区域请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - mainPropertyCode [String] [必填]
    字段描述: 主数据面资产编码
    示例: fence_001
  - auxiliaryPropertyCode [String] [必填]
    字段描述: 辅数据面资产编码
    示例: fence_002


接口请求示例:
  {
    "mainPropertyCode": "mainPropertyCode",
    "auxiliaryPropertyCode": "auxiliaryPropertyCode"
}
```
**示例:**
```json
{
    "mainPropertyCode": "mainPropertyCode",
    "auxiliaryPropertyCode": "auxiliaryPropertyCode"
}
```

### fence-merge — 围栏合并后的区域请求
```bash
gogeo-cli common-task calculation fence-merge --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/fence_merge_area
请求方式: POST
接口描述: 围栏合并后的区域请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 面数据资产编码
    示例: fence_property_001
  - mergeField [String] [必填]
    字段描述: 合并字段（面资产的字段）
    示例: regionType
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计字段列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "mergeField": "mergeField",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "mergeField": "mergeField",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### fence-of-point — 点所在围栏请求
```bash
gogeo-cli common-task calculation fence-of-point --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/fence_of_point
请求方式: POST
接口描述: 点所在围栏请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - buffer [Integer] [可选]
    字段描述: 外扩范围（米）
    示例: 100
  - pointPropertyCode [String] [必填]
    字段描述: 点资产编码
    示例: point_001
  - fencePropertyCode [String] [必填]
    字段描述: 面资产编码
    示例: fence_001
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 结果聚合配置列表
    示例: fence_001
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "buffer": 500,
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "buffer": 500,
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset",
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### fence-without-point — 不包含点的围栏请求
```bash
gogeo-cli common-task calculation fence-without-point --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/fence_without_point
请求方式: POST
接口描述: 不包含点的围栏请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - buffer [Integer] [必填]
    字段描述: 外扩范围（米）
    示例: 100
  - pointPropertyCode [String] [必填]
    字段描述: 点资产编码
    示例: point_001
  - fencePropertyCode [String] [必填]
    字段描述: 面资产编码
    示例: fence_001


接口请求示例:
  {
    "buffer": 500,
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset"
}
```
**示例:**
```json
{
    "buffer": 500,
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset"
}
```

### h3-split-merge — H3 拆合生成请求
```bash
gogeo-cli common-task calculation h3-split-merge --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/h3SplitMergeGenerate
请求方式: POST
接口描述: H3 拆合生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointPropertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - customizeFencePropertyCode [String] [必填]
    字段描述: 自定义围栏数据
    示例: fence_001
  - generateDirection [GenerateDirection] [必填]
    字段描述: 生成方向：bigToSmall-从大到小，smallToBig-从小到大。层级网格分裂/合并生成方向。可选值: bigToSmall=从大到小; smallToBig=从小到大
    示例: bigToSmall
  - potential [String] [必填]
    字段描述: 潜力字段
    示例: potentialValue
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级：city-城市，district-区县，province-省份。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计字段配置列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointPropertyCode": "point_asset",
    "customizeFencePropertyCode": "customizeFencePropertyCode",
    "generateDirection": "bigToSmall",
    "potential": "potential",
    "boundaryLevel": "province",
    "effectiveScope": [
        "effectiveScope"
    ],
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "pointPropertyCode": "point_asset",
    "customizeFencePropertyCode": "customizeFencePropertyCode",
    "generateDirection": "bigToSmall",
    "potential": "potential",
    "boundaryLevel": "province",
    "effectiveScope": [
        "effectiveScope"
    ],
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### line-intersection — 线相交取交点请求
```bash
gogeo-cli common-task calculation line-intersection --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/line_intersection_point
请求方式: POST
接口描述: 线相交取交点请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 线数据资产编码
    示例: line_property_001


接口请求示例:
  {
    "propertyCode": "asset_001"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001"
}
```

### line-split-fence — 线分割围栏数据处理请求
```bash
gogeo-cli common-task calculation line-split-fence --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/line_split_fence
请求方式: POST
接口描述: 线分割围栏数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - linePropertyCode [String] [可选]
    字段描述: 
  - fencePropertyCode [String] [可选]
    字段描述: 


接口请求示例:
  {
    "linePropertyCode": "line_asset",
    "fencePropertyCode": "fence_asset"
}
```
**示例:**
```json
{
    "linePropertyCode": "line_asset",
    "fencePropertyCode": "fence_asset"
}
```

### point-centroid — 点质心计算
```bash
gogeo-cli common-task calculation point-centroid --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/point_centroid
请求方式: POST
接口描述: 点质心计算


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：点数据
    示例: point_001
  - partitionType [PartitionType] [必填]
    字段描述: 划分类型。空间划分类型。可选值: hexagon=蜂窝; square=方块
    示例: hexagon
  - sideLength [Integer] [必填]
    字段描述: 边长（最小值 100，最大值 100000）
    示例: 1000
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合统计
    示例: 1000
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "propertyCode": "asset_001",
    "partitionType": "hexagon",
    "sideLength": 100,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "partitionType": "hexagon",
    "sideLength": 100,
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### point-in-fence — 围栏里的点请求
```bash
gogeo-cli common-task calculation point-in-fence --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/point_inside_fence
请求方式: POST
接口描述: 围栏里的点请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointPropertyCode [String] [必填]
    字段描述: 点资产编码
    示例: point_001
  - fencePropertyCode [String] [必填]
    字段描述: 面资产编码
    示例: fence_001
  - buffer [Integer] [必填]
    字段描述: 外扩范围（米）
    示例: 100
  - translationFields [List<String>] [必填]
    字段描述: 拼接字段 (围栏数据的字段)
    示例: true


接口请求示例:
  {
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset",
    "buffer": 500,
    "translationFields": [
        "translationFields"
    ]
}
```
**示例:**
```json
{
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset",
    "buffer": 500,
    "translationFields": [
        "translationFields"
    ]
}
```

### point-outside-fence — 围栏外的点请求
```bash
gogeo-cli common-task calculation point-outside-fence --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/point_outside_fence
请求方式: POST
接口描述: 围栏外的点请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - buffer [Integer] [必填]
    字段描述: 外扩范围（米）
    示例: 100
  - pointPropertyCode [String] [必填]
    字段描述: 点资产编码
    示例: point_001
  - fencePropertyCode [String] [必填]
    字段描述: 面资产编码
    示例: fence_001


接口请求示例:
  {
    "buffer": 500,
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset"
}
```
**示例:**
```json
{
    "buffer": 500,
    "pointPropertyCode": "point_asset",
    "fencePropertyCode": "fence_asset"
}
```

### scatter-fence — 散点构建面数据请求
```bash
gogeo-cli common-task calculation scatter-fence --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/scatter_points_build_fence
请求方式: POST
接口描述: 散点构建面数据请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum
  - propertyCode [String] [可选]
    字段描述: 资产编码
    示例: point_001
  - groupField [String] [可选]
    字段描述: 分组字段：资产数据中的字段
    示例: region
  - fenceType [FenceType] [可选]
    字段描述: 围栏类型。散点构围栏类型。可选值: 1=凸包; 2=凹包; 3=外切矩形
    示例: 1


接口请求示例:
  {
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ],
    "propertyCode": "asset_001",
    "groupField": "groupField",
    "fenceType": "1"
}
```
**示例:**
```json
{
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ],
    "propertyCode": "asset_001",
    "groupField": "groupField",
    "fenceType": "1"
}
```

### scu-admin — SCU-行政区划生成请求
```bash
gogeo-cli common-task calculation scu-admin --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/scu_admin_division_generate
请求方式: POST
接口描述: SCU-行政区划生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointPropertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - generateDirection [GenerateDirection] [必填]
    字段描述: 生成方向。层级网格分裂/合并生成方向。可选值: bigToSmall=从大到小; smallToBig=从小到大
    示例: bigToSmall
  - potential [String] [必填]
    字段描述: 潜力字段
    示例: bigToSmall
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city


接口请求示例:
  {
    "pointPropertyCode": "point_asset",
    "generateDirection": "bigToSmall",
    "potential": "potential",
    "boundaryLevel": "province"
}
```
**示例:**
```json
{
    "pointPropertyCode": "point_asset",
    "generateDirection": "bigToSmall",
    "potential": "potential",
    "boundaryLevel": "province"
}
```

### scu-geohash — SCU-GEOHASH 生成请求
```bash
gogeo-cli common-task calculation scu-geohash --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/scu_geohash_generate
请求方式: POST
接口描述: SCU-GEOHASH 生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointData [PointData] [必填]
    字段描述: 点数据
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码，必填
    示例: point_001
  - groupCode [String (inner)] [必填]
    字段描述: 分组编码，非必填
    示例: group_001
  - num [String (inner)] [可选]
    字段描述: 潜力字段，非必填
    示例: potentialValue
  - centerPoint [CenterPoint] [必填]
    字段描述: 聚类数据
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: center_001
  - center [String (inner)] [必填]
    字段描述: 中心点
    示例: center_A
  - customizeFenceDataPropertyCode [String] [必填]
    字段描述: 自定义围栏数据
  - paramJson [ParamJson] [必填]
    字段描述: 基本参数
  - zoomStart [Integer (inner)] [可选]
    字段描述: 开始级别
    示例: 5
  - minValue [Integer (inner)] [必填]
    字段描述: 潜力区间最小值
    示例: 0
  - maxValue [Integer (inner)] [必填]
    字段描述: 潜力区间最大值
    示例: 1000
  - boundaryLevel [BoundaryLevel (inner)] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>> (inner)] [可选]
    字段描述: 自定义生效范围
    示例: ["effectivescope"]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": {
        "propertyCode": "asset_001",
        "groupCode": "group_001",
        "num": "potentialValue"
    },
    "centerPoint": {
        "propertyCode": "asset_001",
        "center": "center"
    },
    "customizeFenceDataPropertyCode": "customizeFenceDataPropertyCode",
    "paramJson": {
        "zoomStart": 5,
        "minValue": 0,
        "maxValue": 100,
        "boundaryLevel": "province",
        "effectiveScope": [
            "effectiveScope"
        ]
    },
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```
**示例:**
```json
{
    "pointData": {
        "propertyCode": "asset_001",
        "groupCode": "group_001",
        "num": "potentialValue"
    },
    "centerPoint": {
        "propertyCode": "asset_001",
        "center": "center"
    },
    "customizeFenceDataPropertyCode": "customizeFenceDataPropertyCode",
    "paramJson": {
        "zoomStart": 5,
        "minValue": 0,
        "maxValue": 100,
        "boundaryLevel": "province",
        "effectiveScope": [
            "effectiveScope"
        ]
    },
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ]
}
```

### scu-h3 — SCU-H3标准生成请求
```bash
gogeo-cli common-task calculation scu-h3 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/scu_generate_by_h3
请求方式: POST
接口描述: SCU-H3标准生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围
    示例: ["effectivescope"]
  - pointPropertyCode [String] [可选]
    字段描述: 点资产编码
    示例: point_001
  - potential [String] [可选]
    字段描述: 潜力字段：资产数据中的字段
    示例: potential_value
  - generateDirection [GenerateDirection] [可选]
    字段描述: 生成方向。层级网格分裂/合并生成方向。可选值: bigToSmall=从大到小; smallToBig=从小到大
  - splitValue [Integer] [可选]
    字段描述: 划分值
  - zoomStart [Integer] [可选]
    字段描述: H3 开始级别
  - boundaryLevel [BoundaryLevel] [可选]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
  - customizeFencePropertyCode [String] [可选]
    字段描述: 自定义围栏资产编码


接口请求示例:
  {
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ],
    "effectiveScope": [
        "effectiveScope"
    ],
    "pointPropertyCode": "point_asset",
    "potential": "potential",
    "generateDirection": "bigToSmall",
    "splitValue": 1,
    "zoomStart": 5,
    "boundaryLevel": "province",
    "customizeFencePropertyCode": "customizeFencePropertyCode"
}
```
**示例:**
```json
{
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ],
    "effectiveScope": [
        "effectiveScope"
    ],
    "pointPropertyCode": "point_asset",
    "potential": "potential",
    "generateDirection": "bigToSmall",
    "splitValue": 1,
    "zoomStart": 5,
    "boundaryLevel": "province",
    "customizeFencePropertyCode": "customizeFencePropertyCode"
}
```

### scu-h3-merge — SCU-H3 合并请求
```bash
gogeo-cli common-task calculation scu-h3-merge --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/scu_h3_merge
请求方式: POST
接口描述: SCU-H3 合并请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 围栏数据资产编码
    示例: fence_001
  - potential [String] [必填]
    字段描述: 潜力值字段
    示例: potentialValue
  - minValue [Integer] [必填]
    字段描述: 潜力区间最小值
    示例: 0
  - maxValue [Integer] [必填]
    字段描述: 潜力区间最大值
    示例: 9999999


接口请求示例:
  {
    "propertyCode": "asset_001",
    "potential": "potential",
    "minValue": 0,
    "maxValue": 100
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "potential": "potential",
    "minValue": 0,
    "maxValue": 100
}
```

### scu-s2 — SCU-S2 标准生成请求
```bash
gogeo-cli common-task calculation scu-s2 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/scu_s2_standard_generate
请求方式: POST
接口描述: SCU-S2 标准生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - pointPropertyCode [String] [必填]
    字段描述: 点数据资产编码
  - generateDirection [GenerateDirection] [必填]
    字段描述: 生成方向。层级网格分裂/合并生成方向。可选值: bigToSmall=从大到小; smallToBig=从小到大
    示例: bigToSmall
  - potential [String] [必填]
    字段描述: 潜力字段
    示例: bigToSmall
  - splitValue [Integer] [必填]
    字段描述: 划分值
  - zoomStart [Integer] [必填]
    字段描述: S2 开始级别
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - customizeFenceData [CustomizeFenceData] [必填]
    字段描述: 自定义围栏数据
    示例: [{"code":"fence_002","fence":"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码，必填
    示例: customize_fence_001
  - customizeFenceData [String (inner)] [必填]
    字段描述: 自定义范围围栏，必填
    示例: [{"code":"fence_002","fence":"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))"}]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围


接口请求示例:
  {
    "pointPropertyCode": "point_asset",
    "generateDirection": "bigToSmall",
    "potential": "potential",
    "splitValue": 1,
    "zoomStart": 5,
    "boundaryLevel": "province",
    "customizeFenceData": {
        "propertyCode": "asset_001",
        "customizeFenceData": "customizeFenceData"
    },
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ],
    "effectiveScope": [
        "effectiveScope"
    ]
}
```
**示例:**
```json
{
    "pointPropertyCode": "point_asset",
    "generateDirection": "bigToSmall",
    "potential": "potential",
    "splitValue": 1,
    "zoomStart": 5,
    "boundaryLevel": "province",
    "customizeFenceData": {
        "propertyCode": "asset_001",
        "customizeFenceData": "customizeFenceData"
    },
    "aggregationFields": [
        {
            "field": "fieldName",
            "aggregationType": "Avg"
        }
    ],
    "effectiveScope": [
        "effectiveScope"
    ]
}
```

### voronoi — 泰森多边形请求
```bash
gogeo-cli common-task calculation voronoi --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineSpatialCalculationController/voronoi_diagram
请求方式: POST
接口描述: 泰森多边形请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [可选]
    字段描述: 资产编码
    示例: point_001
  - bufferProportion [Integer] [可选]
    字段描述: 缓冲比例 (%)
    示例: 1.0


接口请求示例:
  {
    "propertyCode": "asset_001",
    "bufferProportion": 1
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "bufferProportion": 1
}
```

## thirdparty

### capacity-estimation — 高德-容量预估数据处理请求
```bash
gogeo-cli common-task capacity-estimation --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/market_capacity_estimation
请求方式: POST
接口描述: 高德-容量预估数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 区块数据资产编码
    示例: block_001
  - name [String] [必填]
    字段描述: 区块名称
    示例: 朝阳区
  - tag [String] [必填]
    字段描述: 分组标识
    示例: group_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "name": "测试名称",
    "tag": "tag"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "name": "测试名称",
    "tag": "tag"
}
```

### customer-flow-competition — 客流通 - 商圈竞争烈度分析请求参数
```bash
gogeo-cli common-task customer-flow-competition --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/customer_flow_business_district_competition_intensity_analysis
请求方式: POST
接口描述: 客流通 - 商圈竞争烈度分析请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - fenceData [FenceData] [必填]
    字段描述: 服务区竞争烈度数据
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码，必填
    示例: point_001
  - mallIdFieldCode [String (inner)] [必填]
    字段描述: 主场服务区 ID 字段
    示例: mall_id
  - competitorMallIdFieldCode [String (inner)] [必填]
    字段描述: 竞品服务区 ID 字段
    示例: n_mall_id
  - date [String] [必填]
    字段描述: 日期
    示例: 2024-01-01
  - type [CompetitionType] [必填]
    字段描述: 竞争类型。客流类型分类。可选值: 1=居住; 2=工作; 3=路过


接口请求示例:
  {
    "fenceData": {
        "propertyCode": "asset_001",
        "mallIdFieldCode": "mall_id",
        "competitorMallIdFieldCode": "competitorMallIdFieldCode"
    },
    "date": "2024-01-01",
    "type": "1"
}
```
**示例:**
```json
{
    "fenceData": {
        "propertyCode": "asset_001",
        "mallIdFieldCode": "mall_id",
        "competitorMallIdFieldCode": "competitorMallIdFieldCode"
    },
    "date": "2024-01-01",
    "type": "1"
}
```

### customer-flow-competitors — 客流通 - 竞品门店请求参数
```bash
gogeo-cli common-task customer-flow-competitors --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/customerFlowCompetitorStores
请求方式: POST
接口描述: 客流通 - 竞品门店请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - fencePropertyCode [String] [必填]
    字段描述: 围栏数据资产编码
    示例: fence_001
  - mallFieldCode [String] [必填]
    字段描述: 商场字段编码
    示例: mall_code


接口请求示例:
  {
    "fencePropertyCode": "fence_asset",
    "mallFieldCode": "mall_id"
}
```
**示例:**
```json
{
    "fencePropertyCode": "fence_asset",
    "mallFieldCode": "mall_id"
}
```

### customer-flow-items — 客流通 - 服务项目请求参数
```bash
gogeo-cli common-task customer-flow-items --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/customerFlowServiceItems
请求方式: POST
接口描述: 客流通 - 服务项目请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - remark [String] [可选]
    字段描述: 任务备注
    示例: 服务项目分析任务


接口请求示例:
  {
    "remark": "remark"
}
```
**示例:**
```json
{
    "remark": "remark"
}
```

### customer-flow-pedestrian — 客流通 - 商圈客流分析请求参数
```bash
gogeo-cli common-task customer-flow-pedestrian --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/customer_flow_business_district_pedestrian_flow_analysis
请求方式: POST
接口描述: 客流通 - 商圈客流分析请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - fencePropertyCode [String] [必填]
    字段描述: 围栏数据资产编码
    示例: fence_001
  - mallFieldCode [String] [必填]
    字段描述: 商场 ID（mallId）
    示例: mall_001
  - apiParams [List<ApiParams>] [必填]
    字段描述: 聚合字段配置列表
    示例: mall_001
  - interfaceCode [InterfaceCode (inner)] [必填]
    字段描述: 接口编码。第三方接口标识。可选值: GETGRIDBUSSINESSCIRCLE=栅格客流/人口数查询; GETAOIDEPRESSIONRANK=客流洼地排名查询; GETAOICOMMUNTIYSIZERANK=来源地人口排名查询; GETLOWPASSENGERFLOW=低客流区域人口排名查询; GETGRIDDEPRESSIONDATA=栅格渗透率查询; GETAOIPASSENGERFLOWRANK=客流来源排名查询; GETMALLFLOWANDNUMDATABYMALLID=客流统计; GETGRIDPERAGEPORTRAITS=客流活跃时段; GETLENGTHSOFSTAYDATA=客流停留时长; GETGRIDPERAGEPORTRAITBYMALLIDS=客流到访频次 等19个值
  - date [String (inner)] [必填]
    字段描述: 日期
    示例: 2024-01-01
  - type [List<Type> (inner)] [必填]
    字段描述: 客流类型（仅当 interfaceCode 为 getaoipassengerflowrank、getaoicommuntiysizerank、getaoidepressionrank、getlowpassengerflow 时有效）。客流类型分类。可选值: 1=居住; 2=工作; 3=路过
    示例: 2024-01-01
  - property [List<Property> (inner)] [可选]
    字段描述: 网格人群类型（仅当 interfaceCode 为 getgridbussinesscircle 时有效）。客流指标类型。可选值: 1=客流数量; 2=人口数量


接口请求示例:
  {
    "fencePropertyCode": "fence_asset",
    "mallFieldCode": "mall_id",
    "apiParams": [
        {
            "interfaceCode": "GETGRIDBUSSINESSCIRCLE",
            "date": "2024-01-01",
            "type": [],
            "property": []
        }
    ]
}
```
**示例:**
```json
{
    "fencePropertyCode": "fence_asset",
    "mallFieldCode": "mall_id",
    "apiParams": [
        {
            "interfaceCode": "GETGRIDBUSSINESSCIRCLE",
            "date": "2024-01-01",
            "type": [],
            "property": []
        }
    ]
}
```

### customer-flow-report — 客流通 - 数据报表请求参数
```bash
gogeo-cli common-task customer-flow-report --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/customerFlowDataReports
请求方式: POST
接口描述: 客流通 - 数据报表请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - fencePropertyCode [String] [必填]
    字段描述: 围栏数据资产编码
    示例: fence_001
  - mallFieldCode [String] [必填]
    字段描述: 商场字段编码（mallId）
    示例: mall_code
  - dataReportInterApiParams [List<DataReportInterApiParams>] [必填]
    字段描述: 数据报表接口参数配置列表
    示例: [...]
  - dateList [List<String> (inner)] [必填]
    字段描述: 日期列表
    示例: ["2024-01-01"]
  - interfaceCode [InterfaceCode (inner)] [必填]
    字段描述: 接口编码。第三方接口标识。可选值: GETGRIDBUSSINESSCIRCLE=栅格客流/人口数查询; GETAOIDEPRESSIONRANK=客流洼地排名查询; GETAOICOMMUNTIYSIZERANK=来源地人口排名查询; GETLOWPASSENGERFLOW=低客流区域人口排名查询; GETGRIDDEPRESSIONDATA=栅格渗透率查询; GETAOIPASSENGERFLOWRANK=客流来源排名查询; GETMALLFLOWANDNUMDATABYMALLID=客流统计; GETGRIDPERAGEPORTRAITS=客流活跃时段; GETLENGTHSOFSTAYDATA=客流停留时长; GETGRIDPERAGEPORTRAITBYMALLIDS=客流到访频次 等19个值
    示例: getmallflowandnumdatabymallId
  - pType [String (inner)] [可选]
    字段描述: 访次数类型（仅当 interfaceCode 为 getgridperageportraitbymallIdS 时有效）
    示例: visitCount


接口请求示例:
  {
    "fencePropertyCode": "fence_asset",
    "mallFieldCode": "mall_id",
    "dataReportInterApiParams": [
        {
            "dateList": [
                "dateList"
            ],
            "interfaceCode": "GETGRIDBUSSINESSCIRCLE",
            "pType": "pType"
        }
    ]
}
```
**示例:**
```json
{
    "fencePropertyCode": "fence_asset",
    "mallFieldCode": "mall_id",
    "dataReportInterApiParams": [
        {
            "dateList": [
                "dateList"
            ],
            "interfaceCode": "GETGRIDBUSSINESSCIRCLE",
            "pType": "pType"
        }
    ]
}
```

### duty-grid-info — 高德责任网格列表查询数据处理请求
```bash
gogeo-cli common-task duty-grid-info --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/duty_grid_info
请求方式: POST
接口描述: 高德责任网格列表查询数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 区块数据资产编码
    示例: block_001
  - gdId [String] [必填]
    字段描述: 高德网格 ID
    示例: grid_12345
  - name [String] [必填]
    字段描述: 高德网格名称
    示例: XX网格
  - tag [String] [必填]
    字段描述: 网格分组
    示例: grid_group_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "gdId": "gdId",
    "name": "测试名称",
    "tag": "tag"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "gdId": "gdId",
    "name": "测试名称",
    "tag": "tag"
}
```

### duty-grid-upload — 高德责任网格同步数据处理请求
```bash
gogeo-cli common-task duty-grid-upload --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/duty_grid_upload
请求方式: POST
接口描述: 高德责任网格同步数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 区块数据资产编码
    示例: block_001
  - gdId [String] [必填]
    字段描述: 网格ID
    示例: grid_12345
  - name [String] [可选]
    字段描述: 网格名称
    示例: XX网格
  - operation [String] [必填]
    字段描述: 操作符
    示例: add
  - capacity [String] [必填]
    字段描述: 最大准入容量
    示例: 1000
  - preFactor [String] [可选]
    字段描述: 优待系数
    示例: 1.5
  - spacing [String] [可选]
    字段描述: 最小准入间距
    示例: 500
  - adcode [String] [可选]
    字段描述: 区域编码
    示例: 110105
  - tag [String] [必填]
    字段描述: 网格分组名称
    示例: grid_group_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "gdId": "gdId",
    "name": "测试名称",
    "operation": "operation",
    "capacity": "capacity",
    "preFactor": "preFactor",
    "spacing": "spacing",
    "adcode": "adcode",
    "tag": "tag"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "gdId": "gdId",
    "name": "测试名称",
    "operation": "operation",
    "capacity": "capacity",
    "preFactor": "preFactor",
    "spacing": "spacing",
    "adcode": "adcode",
    "tag": "tag"
}
```

### lbs-passenger-area — LBS 客流画像面数据请求参数
```bash
gogeo-cli common-task lbs-passenger-area --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/lbs_passenger_portrait_area
请求方式: POST
接口描述: LBS 客流画像面数据请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - lbsPropertyCode [String] [必填]
    字段描述: LBS 数据面数据资产编码
    示例: lbs_area_001
  - translationFields [List<String>] [必填]
    字段描述: 结果冗余字段
    示例: ["translationfields"]
  - lbsInterApiParams [List<LbsInterApiParams>] [必填]
    字段描述: 聚合字段配置列表
    示例: [...]
  - interfaceCode [InterfaceCode (inner)] [必填]
    字段描述: 接口类型。第三方接口标识。可选值: GETGRIDBUSSINESSCIRCLE=栅格客流/人口数查询; GETAOIDEPRESSIONRANK=客流洼地排名查询; GETAOICOMMUNTIYSIZERANK=来源地人口排名查询; GETLOWPASSENGERFLOW=低客流区域人口排名查询; GETGRIDDEPRESSIONDATA=栅格渗透率查询; GETAOIPASSENGERFLOWRANK=客流来源排名查询; GETMALLFLOWANDNUMDATABYMALLID=客流统计; GETGRIDPERAGEPORTRAITS=客流活跃时段; GETLENGTHSOFSTAYDATA=客流停留时长; GETGRIDPERAGEPORTRAITBYMALLIDS=客流到访频次 等19个值
    示例: residentnum
  - monthAverage [MonthAverage (inner)] [可选]
    字段描述: 回溯类型（仅当 interfaceCode 为 residentnum、flownum 时有效）。月份平均周期。可选值: 1=当月; 3=3个月; 6=6个月; 12=12个月
    示例: 1
  - adCode [String (inner)] [必填]
    字段描述: 行政区划编码
    示例: 110000
  - month [List<String> (inner)] [必填]
    字段描述: 当前月（多选）
    示例: ["month"]
  - peopleType [List<PeopleType> (inner)] [可选]
    字段描述: 常驻人口类型（仅当 interfaceCode 为 residentnum、residentuserprofile 时有效）。人口类型。可选值: 1=工作人口; 2=居住人口; 3=工作或居住
    示例: [...]
  - label [List<Label> (inner)] [可选]
    字段描述: 标签列表（仅当 interfaceCode 为 residentuserprofile、flowuserprofile 时有效）。用户画像标签编码。可选值: 101010=性别; 101012=年龄(分段); 101015=学历; 101112=婚否v2; 1041=子女年龄v2; 1052=婚育状态; 1013=人生阶段; 1037=职业细分; 1038=所在行业; 990043=职住距离(分段) 等35个值
    示例: [...]
  - dateType [List<DateType> (inner)] [可选]
    字段描述: 日期类型（仅当 interfaceCode 为 flownum、flowuserprofile 时有效）。日期类型。可选值: 1=月日平均; 2=工作日平均; 3=节假日平均; workday=工作日; weekend=周末; holiday=节假日
    示例: [...]
  - heatType [List<HeatType> (inner)] [可选]
    字段描述: 热力类型（仅当 interfaceCode 为 locationpoint 时有效）。热力图类型。可选值: flow_workday=工作日客流; flow_holiday=节假日客流; resident_home=居住; resident_work=工作; people_flow=人流热力; vehicle_flow=车流热力
    示例: [...]


接口请求示例:
  {
    "lbsPropertyCode": "lbs_asset",
    "translationFields": [
        "translationFields"
    ],
    "lbsInterApiParams": [
        {
            "interfaceCode": "GETGRIDBUSSINESSCIRCLE",
            "monthAverage": "1",
            "adCode": "adCode",
            "month": [
                "month"
            ],
            "peopleType": [],
            "label": [],
            "dateType": [],
            "heatType": []
        }
    ]
}
```
**示例:**
```json
{
    "lbsPropertyCode": "lbs_asset",
    "translationFields": [
        "translationFields"
    ],
    "lbsInterApiParams": [
        {
            "interfaceCode": "GETGRIDBUSSINESSCIRCLE",
            "monthAverage": "1",
            "adCode": "adCode",
            "month": [
                "month"
            ],
            "peopleType": [],
            "label": [],
            "dateType": [],
            "heatType": []
        }
    ]
}
```

### lbs-passenger-point — LBS 客流画像点数据请求参数
```bash
gogeo-cli common-task lbs-passenger-point --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/lbs_passenger_portrait_point
请求方式: POST
接口描述: LBS 客流画像点数据请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - lbsPropertyCode [String] [必填]
    字段描述: LBS 数据点数据资产编码
    示例: lbs_001
  - radius [String] [必填]
    字段描述: 半径 (米)
    示例: 1000
  - translationFields [List<String>] [必填]
    字段描述: 结果冗余字段
    示例: ["translationfields"]
  - lbsInterApiParams [List<LbsInterApiParams>] [必填]
    字段描述: 聚合字段配置列表
    示例: [...]
  - interfaceCode [InterfaceCode (inner)] [必填]
    字段描述: 接口类型。第三方接口标识。可选值: GETGRIDBUSSINESSCIRCLE=栅格客流/人口数查询; GETAOIDEPRESSIONRANK=客流洼地排名查询; GETAOICOMMUNTIYSIZERANK=来源地人口排名查询; GETLOWPASSENGERFLOW=低客流区域人口排名查询; GETGRIDDEPRESSIONDATA=栅格渗透率查询; GETAOIPASSENGERFLOWRANK=客流来源排名查询; GETMALLFLOWANDNUMDATABYMALLID=客流统计; GETGRIDPERAGEPORTRAITS=客流活跃时段; GETLENGTHSOFSTAYDATA=客流停留时长; GETGRIDPERAGEPORTRAITBYMALLIDS=客流到访频次 等19个值
    示例: residentnum
  - monthAverage [MonthAverage (inner)] [可选]
    字段描述: 回溯类型（仅当 interfaceCode 为 residentnum、flownum 时有效）。月份平均周期。可选值: 1=当月; 3=3个月; 6=6个月; 12=12个月
    示例: 1
  - adCode [String (inner)] [必填]
    字段描述: 行政区划编码
    示例: 110000
  - month [List<String> (inner)] [必填]
    字段描述: 当前月（多选）
    示例: ["month"]
  - peopleType [List<PeopleType> (inner)] [可选]
    字段描述: 常驻人口类型（仅当 interfaceCode 为 residentnum、residentuserprofile 时有效）。人口类型。可选值: 1=工作人口; 2=居住人口; 3=工作或居住
    示例: [...]
  - label [List<Label> (inner)] [可选]
    字段描述: 标签列表（仅当 interfaceCode 为 residentuserprofile、flowuserprofile 时有效）。用户画像标签编码。可选值: 101010=性别; 101012=年龄(分段); 101015=学历; 101112=婚否v2; 1041=子女年龄v2; 1052=婚育状态; 1013=人生阶段; 1037=职业细分; 1038=所在行业; 990043=职住距离(分段) 等35个值
    示例: [...]
  - dateType [List<DateType> (inner)] [可选]
    字段描述: 日期类型（仅当 interfaceCode 为 flownum、flowuserprofile 时有效）。日期类型。可选值: 1=月日平均; 2=工作日平均; 3=节假日平均; workday=工作日; weekend=周末; holiday=节假日
    示例: [...]
  - heatType [List<HeatType> (inner)] [可选]
    字段描述: 热力类型（仅当 interfaceCode 为 locationpoint 时有效）。热力图类型。可选值: flow_workday=工作日客流; flow_holiday=节假日客流; resident_home=居住; resident_work=工作; people_flow=人流热力; vehicle_flow=车流热力
    示例: [...]


接口请求示例:
  {
    "lbsPropertyCode": "lbs_asset",
    "radius": "radius",
    "translationFields": [
        "translationFields"
    ],
    "lbsInterApiParams": [
        {
            "interfaceCode": "GETGRIDBUSSINESSCIRCLE",
            "monthAverage": "1",
            "adCode": "adCode",
            "month": [
                "month"
            ],
            "peopleType": [],
            "label": [],
            "dateType": [],
            "heatType": []
        }
    ]
}
```
**示例:**
```json
{
    "lbsPropertyCode": "lbs_asset",
    "radius": "radius",
    "translationFields": [
        "translationFields"
    ],
    "lbsInterApiParams": [
        {
            "interfaceCode": "GETGRIDBUSSINESSCIRCLE",
            "monthAverage": "1",
            "adCode": "adCode",
            "month": [
                "month"
            ],
            "peopleType": [],
            "label": [],
            "dateType": [],
            "heatType": []
        }
    ]
}
```

### odm-gd-match — 高德-POI关联
```bash
gogeo-cli common-task odm-gd-match --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/odm_gd_match
请求方式: POST
接口描述: 高德-POI关联


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：售点数据
    示例: point_001
  - pointName [String] [必填]
    字段描述: 售点名称
    示例: XX便利店
  - address [String] [必填]
    字段描述: 地址
    示例: 北京市朝阳区XX路XX号
  - point [String] [必填]
    字段描述: 经纬度
    示例: 116.404,39.915


接口请求示例:
  {
    "propertyCode": "asset_001",
    "pointName": "pointName",
    "address": "北京市朝阳区",
    "point": "point"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "pointName": "pointName",
    "address": "北京市朝阳区",
    "point": "point"
}
```

### odm-uncontrolled — 高德未控售点数据处理请求
```bash
gogeo-cli common-task odm-uncontrolled --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/odm_gd_uncontrolled
请求方式: POST
接口描述: 高德未控售点数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点数据资产编码
    示例: point_001
  - adCode [String] [必填]
    字段描述: 省市区 adcode
    示例: 110105


接口请求示例:
  {
    "propertyCode": "asset_001",
    "adCode": "adCode"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "adCode": "adCode"
}
```

### retail-merchant-info — 高德零售商户列表查询数据处理请求
```bash
gogeo-cli common-task retail-merchant-info --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/retail_commercial_info
请求方式: POST
接口描述: 高德零售商户列表查询数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点资产编码
    示例: point_001
  - gdId [String] [必填]
    字段描述: 零售户ID
    示例: gd_12345
  - name [String] [必填]
    字段描述: 零售商户名称
    示例: XX便利店
  - tag [String] [必填]
    字段描述: 零售商户分组
    示例: retail_group_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "gdId": "gdId",
    "name": "测试名称",
    "tag": "tag"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "gdId": "gdId",
    "name": "测试名称",
    "tag": "tag"
}
```

### retail-merchant-upload — 高德零售商户同步数据处理请求
```bash
gogeo-cli common-task retail-merchant-upload --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/retail_commercial_upload
请求方式: POST
接口描述: 高德零售商户同步数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点资产编码
    示例: point_001
  - gdId [String] [必填]
    字段描述: 零售户 ID
    示例: gd_12345
  - name [String] [可选]
    字段描述: 零售商户名称
    示例: XX便利店
  - operation [String] [必填]
    字段描述: 同步类型
    示例: add
  - license [String] [必填]
    字段描述: 零售商户许可证
    示例: LIC-001
  - bizNet [String] [必填]
    字段描述: 零售户业态
    示例: 便利店
  - bizType [String] [可选]
    字段描述: 零售户类型
    示例: normal
  - bizLevel [String] [可选]
    字段描述: 零售户级别
    示例: A
  - tag [String] [必填]
    字段描述: 零售户分组标识
    示例: retail_group_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "gdId": "gdId",
    "name": "测试名称",
    "operation": "operation",
    "license": "license",
    "bizNet": "bizNet",
    "bizType": "bizType",
    "bizLevel": "bizLevel",
    "tag": "tag"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "gdId": "gdId",
    "name": "测试名称",
    "operation": "operation",
    "license": "license",
    "bizNet": "bizNet",
    "bizType": "bizType",
    "bizLevel": "bizLevel",
    "tag": "tag"
}
```

### retailer-access — 高德零售准入模型数据处理请求
```bash
gogeo-cli common-task retailer-access --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/retailer_model_access
请求方式: POST
接口描述: 高德零售准入模型数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点资产编码
    示例: point_001
  - extra [String] [必填]
    字段描述: 附加分值
    示例: point_001
  - tag [String] [必填]
    字段描述: 分组名称
    示例: retail_group_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "extra": "extra",
    "tag": "tag"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "extra": "extra",
    "tag": "tag"
}
```

### retailer-scoring — 高德零售评价数据处理请求
```bash
gogeo-cli common-task retailer-scoring --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/retailer_model_scoring
请求方式: POST
接口描述: 高德零售评价数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 点资产编码
    示例: point_001
  - extra [String] [必填]
    字段描述: 附加分项
    示例: point_001
  - name [String] [必填]
    字段描述: 零售商名称
    示例: XX便利店
  - tag [String] [必填]
    字段描述: 组名
    示例: scoring_group_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "extra": "extra",
    "name": "测试名称",
    "tag": "tag"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "extra": "extra",
    "name": "测试名称",
    "tag": "tag"
}
```

### spacing-recommend — 高德-间距推荐数据处理请求
```bash
gogeo-cli common-task spacing-recommend --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/market_spacing_recommendation
请求方式: POST
接口描述: 高德-间距推荐数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 区块数据资产编码
    示例: block_001
  - name [String] [必填]
    字段描述: 区块名称
    示例: 朝阳区
  - tag [String] [必填]
    字段描述: 分组标识
    示例: group_001


接口请求示例:
  {
    "propertyCode": "asset_001",
    "name": "测试名称",
    "tag": "tag"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "name": "测试名称",
    "tag": "tag"
}
```

### tx-poi-match-v2 — 腾讯 POI 匹配 V2
```bash
gogeo-cli common-task tx-poi-match-v2 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/tx_poi_match_v2
请求方式: POST
接口描述: 腾讯 POI 匹配 V2


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：客资数据
    示例: customer_001
  - policyCode [PolicyCode] [必填]
    字段描述: 关联方式枚举：可选值: 30003=名称+地址-包含类目; 30004=名称+经纬度-包含类目; 30004_1=名称+地址+经纬度-包含类目; 30005=名称+地址-剔除类目; 30006=名称+经纬度-剔除类目; 30006_1=名称+地址+经纬度-剔除类目
    示例: 30003
  - mode [Mode] [可选]
    字段描述: 关联模式。POI匹配算法模式。可选值: cluster=cluster模式(精确度更高); link=link模式(召回率更高)
    示例: cluster
  - policyConfig [String] [可选]
    字段描述: 类目选择
  - name [String] [必填]
    字段描述: 名称
    示例: XX门店
  - province [String] [必填]
    字段描述: 省
    示例: 北京市
  - city [String] [可选]
    字段描述: 市
    示例: 北京市
  - district [String] [可选]
    字段描述: 区
    示例: 朝阳区
  - address [String] [可选]
    字段描述: 地址（关联方式为 30003,30005,30004_1,30006_1 时必填）
    示例: 北京市朝阳区XX路XX号


接口请求示例:
  {
    "propertyCode": "asset_001",
    "policyCode": "30003",
    "mode": "cluster",
    "policyConfig": "无",
    "name": "测试名称",
    "province": "广东省",
    "city": "北京市",
    "district": "朝阳区",
    "address": "北京市朝阳区"
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "policyCode": "30003",
    "mode": "cluster",
    "policyConfig": "无",
    "name": "测试名称",
    "province": "广东省",
    "city": "北京市",
    "district": "朝阳区",
    "address": "北京市朝阳区"
}
```

### tx-poi-multi — 多组-腾讯POI关联
```bash
gogeo-cli common-task tx-poi-multi --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/tx_poi_mutil_policy_match
请求方式: POST
接口描述: 多组-腾讯POI关联


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：客资数据
  - matchStrategyList [List<MatchStrategy>] [必填]
    字段描述: 匹配策略
  - policyCode [PolicyCode (inner)] [必填]
    字段描述: 关联方式枚举：可选值: 30003=名称+地址-包含类目; 30004=名称+经纬度-包含类目; 30004_1=名称+地址+经纬度-包含类目; 30005=名称+地址-剔除类目; 30006=名称+经纬度-剔除类目; 30006_1=名称+地址+经纬度-剔除类目
    示例: 30003
  - policyConfig [String (inner)] [可选]
    字段描述: 类目选择
  - name [String (inner)] [必填]
    字段描述: 名称
    示例: XX门店
  - mode [Mode (inner)] [可选]
    字段描述: 关联模式。POI匹配算法模式。可选值: cluster=cluster模式(精确度更高); link=link模式(召回率更高)
    示例: cluster
  - address [String (inner)] [必填]
    字段描述: 地址（关联方式为 30003,30005,30004_1,30006_1 时必填）
    示例: 北京市朝阳区XX路XX号
  - poiPoint [String (inner)] [可选]
    字段描述: 经纬度（关联方式为 30004,30006,30004_1,30006_1 时必填）
    示例: 116.397,39.908
  - province [String (inner)] [可选]
    字段描述: 省
    示例: 北京市
  - city [String (inner)] [可选]
    字段描述: 市
    示例: 北京市
  - district [String (inner)] [可选]
    字段描述: 区
    示例: 朝阳区


接口请求示例:
  {
    "propertyCode": "asset_001",
    "matchStrategyList": [
        {
            "policyCode": "30003",
            "policyConfig": "无",
            "name": "测试名称",
            "mode": "cluster",
            "address": "北京市朝阳区",
            "poiPoint": "poiPoint",
            "province": "广东省",
            "city": "北京市",
            "district": "朝阳区"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "matchStrategyList": [
        {
            "policyCode": "30003",
            "policyConfig": "无",
            "name": "测试名称",
            "mode": "cluster",
            "address": "北京市朝阳区",
            "poiPoint": "poiPoint",
            "province": "广东省",
            "city": "北京市",
            "district": "朝阳区"
        }
    ]
}
```

### tx-poi-multi-v2 — 多组 - 腾讯 POI 关联V2
```bash
gogeo-cli common-task tx-poi-multi-v2 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineThirdPartyServiceController/tx_poi_mutil_policy_match_v2
请求方式: POST
接口描述: 多组 - 腾讯 POI 关联V2


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.pipelineCode [String]
    字段描述: 输出模型编码
  - data.outPropertyCode [String]
    字段描述: 输出资产编码
  - data.taskStatus [Integer]
    字段描述: 流水线状态: 0待启动, 1待执行, 2执行中, 3执行完成, 4执行失败, 5手动停止, 6主动停止
  - data.errorMsg [String]
    字段描述: 错误信息（仅当状态为失败时返回）
  - data.filedList[].filedName [String]
    字段描述: 字段名称
  - data.filedList[].isModelFiled [Boolean]
    字段描述: 是否模型字段，默认false


参数:
  - propertyCode [String] [必填]
    字段描述: 资产编码：客资数据
  - matchStrategyList [List<MatchStrategy>] [必填]
    字段描述: 匹配策略
  - policyCode [PolicyCode (inner)] [必填]
    字段描述: 关联方式枚举：可选值: 30003=名称+地址-包含类目; 30004=名称+经纬度-包含类目; 30004_1=名称+地址+经纬度-包含类目; 30005=名称+地址-剔除类目; 30006=名称+经纬度-剔除类目; 30006_1=名称+地址+经纬度-剔除类目
    示例: 30003
  - policyConfig [String (inner)] [可选]
    字段描述: 类目选择
  - name [String (inner)] [必填]
    字段描述: 名称
    示例: XX门店
  - mode [Mode (inner)] [可选]
    字段描述: 关联模式。POI匹配算法模式。可选值: cluster=cluster模式(精确度更高); link=link模式(召回率更高)
    示例: cluster
  - address [String (inner)] [必填]
    字段描述: 地址（关联方式为 30003,30005,30004_1,30006_1 时必填）
    示例: 北京市朝阳区XX路XX号
  - poiPoint [String (inner)] [可选]
    字段描述: 经纬度（关联方式为 30004,30006,30004_1,30006_1 时必填）
    示例: 116.397,39.908
  - province [String (inner)] [可选]
    字段描述: 省
    示例: 北京市
  - city [String (inner)] [可选]
    字段描述: 市
    示例: 北京市
  - district [String (inner)] [可选]
    字段描述: 区
    示例: 朝阳区


接口请求示例:
  {
    "propertyCode": "asset_001",
    "matchStrategyList": [
        {
            "policyCode": "30003",
            "policyConfig": "无",
            "name": "测试名称",
            "mode": "cluster",
            "address": "北京市朝阳区",
            "poiPoint": "poiPoint",
            "province": "广东省",
            "city": "北京市",
            "district": "朝阳区"
        }
    ]
}
```
**示例:**
```json
{
    "propertyCode": "asset_001",
    "matchStrategyList": [
        {
            "policyCode": "30003",
            "policyConfig": "无",
            "name": "测试名称",
            "mode": "cluster",
            "address": "北京市朝阳区",
            "poiPoint": "poiPoint",
            "province": "广东省",
            "city": "北京市",
            "district": "朝阳区"
        }
    ]
}
```

## Realtime API groups

## realtime realtime

### fence-boundary — 多边形转线数据处理请求
```bash
gogeo-cli common-task base fence-boundary --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_fence_boundary
请求方式: POST
接口描述: 多边形转线数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [可选]
    字段描述: 
    示例: [{"code": "F001", "fence": "POLYGON((116.404 39.915, 116.405 39.915, 116.405 39.916, 116.404 39.916, 116.404 39.915))"}]


接口请求示例:
  {
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((116.404 39.915, 116.405 39.915, 116.405 39.916, 116.404 39.916, 116.404 39.915))"
        }
    ]
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((116.404 39.915, 116.405 39.915, 116.405 39.916, 116.404 39.916, 116.404 39.915))"
        }
    ]
}
```

### fence-coord-convert — 面坐标转换
```bash
gogeo-cli common-task base fence-coord-convert --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_fence_coordinate_convert
请求方式: POST
接口描述: 面坐标转换


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fence [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - sourceType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: WGS84
  - targetType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: GCJ02


接口请求示例:
  {
    "fence": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ]
}
```
**示例:**
```json
{
    "fence": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ]
}
```

### fence-thin — 面抽稀
```bash
gogeo-cli common-task base fence-thin --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_fence_coordinate_thinning
请求方式: POST
接口描述: 面抽稀


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fence [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - maxValue [String] [必填]
    字段描述: 抽稀值（米）
    示例: maxvalue


接口请求示例:
  {
    "fence": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "maxValue": 10
}
```
**示例:**
```json
{
    "fence": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "maxValue": 10
}
```

### line-coord-convert — 线坐标转换
```bash
gogeo-cli common-task base line-coord-convert --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_line_coordinate_convert
请求方式: POST
接口描述: 线坐标转换


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - line [List<Map<String, Object>>] [必填]
    字段描述: 线数据 其中 code 和 line 字段内容必须存在，line 格式 wkt 格式
    示例: [{"code":"line_001","name":"测试线","line":"LINESTRING(116.3 39.9, 116.4 40.0)"}]
  - sourceType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: WGS84
  - targetType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: GCJ02


接口请求示例:
  {
    "line": [
        {
            "code": "line_001",
            "name": "测试线",
            "line": "LINESTRING(116.3 39.9, 116.4 40.0)"
        }
    ]
}
```
**示例:**
```json
{
    "line": [
        {
            "code": "line_001",
            "name": "测试线",
            "line": "LINESTRING(116.3 39.9, 116.4 40.0)"
        }
    ]
}
```

### line-thin — 线抽稀
```bash
gogeo-cli common-task base line-thin --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_line_coordinate_thinning
请求方式: POST
接口描述: 线抽稀


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - line [List<Map<String, Object>>] [必填]
    字段描述: 线数据 其中 code 和 line 字段内容必须存在，line 格式 wkt 格式
    示例: [{"code":"line_001","name":"测试线","line":"LINESTRING(116.3 39.9, 116.4 40.0)"}]
  - maxValue [String] [必填]
    字段描述: 抽稀值（米）
    示例: maxvalue


接口请求示例:
  {
    "line": [
        {
            "code": "line_001",
            "name": "测试线",
            "line": "LINESTRING(116.3 39.9, 116.4 40.0)"
        }
    ],
    "maxValue": 10
}
```
**示例:**
```json
{
    "line": [
        {
            "code": "line_001",
            "name": "测试线",
            "line": "LINESTRING(116.3 39.9, 116.4 40.0)"
        }
    ],
    "maxValue": 10
}
```

### point-circle — 点生成圆形
```bash
gogeo-cli common-task base point-circle --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_point_generate_circle
请求方式: POST
接口描述: 点生成圆形


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - radius [Double] [必填]
    字段描述: 半径（米）
    示例: 1000


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "radius": 1000
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "radius": 1000
}
```

### point-coord-convert — 点坐标转换
```bash
gogeo-cli common-task base point-coord-convert --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_point_coordinate_convert
请求方式: POST
接口描述: 点坐标转换


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - point [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中code 和 point 经纬度字段内容必须存在,point格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - sourceType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: WGS84
  - targetType [CoordinateType] [必填]
    字段描述: 坐标系类型。坐标系类型，可选值: WGS84=WGS84坐标系; GCJ02=国测局坐标系; BD09=百度坐标系
    示例: GCJ02


接口请求示例:
  {
    "point": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ]
}
```
**示例:**
```json
{
    "point": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ]
}
```

### point-hexagon — 点生成蜂窝
```bash
gogeo-cli common-task base point-hexagon --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_point_generate_hexagon
请求方式: POST
接口描述: 点生成蜂窝


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - radius [Double] [必填]
    字段描述: 半径（米）
    示例: 1000


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "radius": 1000
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "radius": 1000
}
```

### point-rarefy — 点抽稀数据处理请求
```bash
gogeo-cli common-task base point-rarefy --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_point_rarefy
请求方式: POST
接口描述: 点抽稀数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [可选]
    字段描述: 
    示例: [{"code": "P001", "point": "POINT(116.404 39.915)"}, {"code": "P002", "point": "POINT(116.405 39.916)"}]
  - dilutionLevel [Integer] [可选]
    字段描述: 


接口请求示例:
  {
    "pointData": [
        {
            "code": "P001",
            "point": "POINT(116.404 39.915)"
        },
        {
            "code": "P002",
            "point": "POINT(116.405 39.916)"
        }
    ]
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "P001",
            "point": "POINT(116.404 39.915)"
        },
        {
            "code": "P002",
            "point": "POINT(116.405 39.916)"
        }
    ]
}
```

### point-square — 点生成方块
```bash
gogeo-cli common-task base point-square --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeBaseServiceController/realtime_point_generate_square
请求方式: POST
接口描述: 点生成方块


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - radius [Double] [必填]
    字段描述: 半径（米）
    示例: 1000


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "radius": 1000
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "radius": 1000
}
```

### industry-cluster — 行业聚集群与分析
```bash
gogeo-cli common-task model industry-cluster --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeModelCalculationController/realtime_industry_cluster
请求方式: POST
接口描述: 行业聚集群与分析


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 字段必须存在，point 格式为 WKT 格式
    示例: [{"code":"001","point":"POINT(116.404 39.915)"}]
  - paramJson [ParamJson] [必填]
    字段描述: 基础参数
    示例: {"fenceDistance":500,"distance":100,"buffer":50,"groupSize":10,"ifConvex":"0"}
  - zoomStart [Integer (inner)] [可选]
    字段描述: 开始级别
    示例: 5
  - minValue [Integer (inner)] [必填]
    字段描述: 潜力区间最小值
    示例: 0
  - maxValue [Integer (inner)] [必填]
    字段描述: 潜力区间最大值
    示例: 1000
  - boundaryLevel [BoundaryLevel (inner)] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>> (inner)] [可选]
    字段描述: 自定义生效范围
    示例: ["effectivescope"]
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合统计字段列表
    示例: [{"field":"salesAmount","aggregationType":"Count"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "paramJson": {
        "fenceDistance": 500,
        "distance": 100,
        "buffer": 50,
        "groupSize": 10,
        "ifConvex": "0"
    },
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Count"
        }
    ],
    "fenceDistance": 500,
    "distance": 100,
    "buffer": 50,
    "groupSize": 10,
    "field": "salesAmount"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "paramJson": {
        "fenceDistance": 500,
        "distance": 100,
        "buffer": 50,
        "groupSize": 10,
        "ifConvex": "0"
    },
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Count"
        }
    ],
    "fenceDistance": 500,
    "distance": 100,
    "buffer": 50,
    "groupSize": 10,
    "field": "salesAmount"
}
```

### radiate-circle — 商业体辐射商圈数据处理请求
```bash
gogeo-cli common-task model radiate-circle --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeModelCalculationController/realtime_business_radiate_circle
请求方式: POST
接口描述: 商业体辐射商圈数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 字段必须存在，point 格式为 WKT 格式
    示例: [{"code":"001","point":"POINT(116.404 39.915)"}]
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"F001","fence":"POLYGON((...))"}]
  - radius [Double] [必填]
    字段描述: 辐射半径（KM）
    示例: 5.0
  - unionDistance [Double] [必填]
    字段描述: 合并距离（KM）
    示例: 1.0
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合字段配置列表
    示例: [{"field":"salesAmount","aggregationType":"Count"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((...))"
        }
    ],
    "radius": 5.0,
    "unionDistance": 1.0,
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Count"
        }
    ]
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((...))"
        }
    ],
    "radius": 5.0,
    "unionDistance": 1.0,
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Count"
        }
    ]
}
```

### reachable-range — 可达圈分析请求参数
```bash
gogeo-cli common-task model reachable-range --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeModelCalculationController/realtime_reachable_range
请求方式: POST
接口描述: 可达圈分析请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"001","point":"POINT(116.404 39.915)"}]
  - directionType [DirectionType] [必填]
    字段描述: 出行政策。可达范围出行方式。可选值: driving=驾车; bicycling=骑行; walking=步行
    示例: driving
  - travelTime [Integer] [必填]
    字段描述: 出行时长，单位：分钟
    示例: 30


接口请求示例:
  {
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "directionType": "driving",
    "travelTime": 30
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "directionType": "driving",
    "travelTime": 30
}
```

### scu-geohash — SCU-GEOHASH 生成请求
```bash
gogeo-cli common-task model scu-geohash --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeModelCalculationController/realtime_scu_geohash_generate
请求方式: POST
接口描述: SCU-GEOHASH 生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [PointData] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码，必填
    示例: point_001
  - groupCode [String (inner)] [必填]
    字段描述: 分组编码，非必填
    示例: group_001
  - num [String (inner)] [可选]
    字段描述: 潜力字段，非必填
    示例: potentialValue
  - centerPoint [CenterPoint] [必填]
    字段描述: 聚类数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: center_001
  - center [String (inner)] [必填]
    字段描述: 中心点
    示例: center_A
  - customizeFenceData [List<Map<String, Object>>] [必填]
    字段描述: 自定义围栏数据
    示例: [{"code":"fence_002","fence":"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))"}]
  - paramJson [ParamJson] [可选]
    字段描述: 基本参数
  - zoomStart [Integer (inner)] [可选]
    字段描述: 开始级别
    示例: 5
  - minValue [Integer (inner)] [必填]
    字段描述: 潜力区间最小值
    示例: 0
  - maxValue [Integer (inner)] [必填]
    字段描述: 潜力区间最大值
    示例: 1000
  - boundaryLevel [BoundaryLevel (inner)] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>> (inner)] [可选]
    字段描述: 自定义生效范围
    示例: ["effectivescope"]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": {
        "propertyCode": "asset_001",
        "groupCode": "group_001",
        "num": "potentialValue"
    },
    "centerPoint": {
        "propertyCode": "asset_001",
        "center": "center"
    },
    "customizeFenceData": [
        {
            "code": "f1",
            "name": "测试围栏",
            "fence": "POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))"
        }
    ],
    "paramJson": {
        "zoomStart": 5,
        "minValue": 0,
        "maxValue": 100,
        "boundaryLevel": "province",
        "effectiveScope": [
            "示例值"
        ]
    },
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Sum"
        }
    ]
}
```
**示例:**
```json
{
    "pointData": {
        "propertyCode": "asset_001",
        "groupCode": "group_001",
        "num": "potentialValue"
    },
    "centerPoint": {
        "propertyCode": "asset_001",
        "center": "center"
    },
    "customizeFenceData": [
        {
            "code": "f1",
            "name": "测试围栏",
            "fence": "POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))"
        }
    ],
    "paramJson": {
        "zoomStart": 5,
        "minValue": 0,
        "maxValue": 100,
        "boundaryLevel": "province",
        "effectiveScope": [
            "示例值"
        ]
    },
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Sum"
        }
    ]
}
```

### solitary-screen — 孤点标记数据处理请求
```bash
gogeo-cli common-task model solitary-screen --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeModelCalculationController/realtime_solitary_screen_data
请求方式: POST
接口描述: 孤点标记数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，用于孤点标记的源数据
    示例: [{"code":"001","point":"POINT(116.404 39.915)"}]
  - fields [List<Field>] [必填]
    字段描述: 标记条件列表，支持多个字段条件的组合标记
    示例: [{"fieldName":"field4","operationType":"eq"}]
  - fieldName [String (inner)] [必填]
    字段描述: 字段名称
    示例: field4
  - operationType [OperationType (inner)] [必填]
    字段描述: 操作类型。过滤/筛选操作符。可选值: eq=等于; neq=不等于; include=包含; not_include=不包含; gt=大于; lt=小于; gte=大于等于; lte=小于等于; isnull=为空; not_null=不为空
    示例: eq
  - content [Object (inner)] [可选]
    字段描述: 过滤/筛选操作符，可选值: eq=等于; neq=不等于; include=包含; not_include=不包含; gt=大于; lt=小于; gte=大于等于; lte=小于等于; isnull=为空; not_null=不为空


接口请求示例:
  {
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "fields": [
        {
            "fieldName": "field4",
            "operationType": "eq"
        }
    ],
    "fieldName": "field4"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "fields": [
        {
            "fieldName": "field4",
            "operationType": "eq"
        }
    ],
    "fieldName": "field4"
}
```

### duplicate-mark — 重复标记请求
```bash
gogeo-cli common-task operation duplicate-mark --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_duplicate_mark
请求方式: POST
接口描述: 重复标记请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - groupData [List<Map<String, Object>>] [必填]
    字段描述: 分组数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"data_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - groupField1 [String] [必填]
    字段描述: 分组字段 1
    示例: field1
  - groupField2 [String] [可选]
    字段描述: 分组字段 2
    示例: field2
  - groupField3 [String] [可选]
    字段描述: 分组字段 3
    示例: field3
  - groupField4 [String] [可选]
    字段描述: 分组字段 4
    示例: field4
  - groupField5 [String] [可选]
    字段描述: 分组字段 5
    示例: field5


接口请求示例:
  {
    "groupData": [
        {
            "code": "data_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "groupField1": "field1",
    "groupField2": "field2",
    "groupField3": "field3",
    "groupField4": "field4",
    "groupField5": "field5"
}
```
**示例:**
```json
{
    "groupData": [
        {
            "code": "data_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "groupField1": "field1",
    "groupField2": "field2",
    "groupField3": "field3",
    "groupField4": "field4",
    "groupField5": "field5"
}
```

### exact-match — 完全匹配
```bash
gogeo-cli common-task operation exact-match --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_exact_match
请求方式: POST
接口描述: 完全匹配


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资数据
    示例: {"data":[{"code":"001","name":"XX门店"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：客资资产的字段
    示例: name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：客资资产的字段
    示例: address
  - txData [TxData] [必填]
    字段描述: 腾讯数据
    示例: {"data":[{"code":"tx_001","name":"腾讯目标"}],"textStr1":"name","textStr2":"address"}
  - propertyCode [String (inner)] [必填]
    字段描述: 对比数据资产编码
    示例: tx_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：对比数据资产的字段
    示例: poi_name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：对比数据资产字段
    示例: address


接口请求示例:
  {
    "customerData": {
        "data": [
            {
                "code": "001",
                "name": "XX门店"
            }
        ],
        "textStr1": "name",
        "textStr2": "address"
    },
    "txData": {
        "data": [
            {
                "code": "tx_001",
                "name": "腾讯目标"
            }
        ],
        "textStr1": "name",
        "textStr2": "address"
    },
    "data": [
        {
            "code": "tx_001",
            "name": "腾讯目标"
        }
    ],
    "textStr1": "name",
    "textStr2": "address"
}
```
**示例:**
```json
{
    "customerData": {
        "data": [
            {
                "code": "001",
                "name": "XX门店"
            }
        ],
        "textStr1": "name",
        "textStr2": "address"
    },
    "txData": {
        "data": [
            {
                "code": "tx_001",
                "name": "腾讯目标"
            }
        ],
        "textStr1": "name",
        "textStr2": "address"
    },
    "data": [
        {
            "code": "tx_001",
            "name": "腾讯目标"
        }
    ],
    "textStr1": "name",
    "textStr2": "address"
}
```

### ka-match — ka匹配请求
```bash
gogeo-cli common-task operation ka-match --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_ka_match_handling_v2
请求方式: POST
接口描述: ka匹配请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资数据
    示例: {"data":[{"code":"001","name":"XX门店"}],"name":"name"}
  - data [List<Map<String, Object>> (inner)] [必填]
    字段描述: 客资数据列表
    示例: [{"code":"001","name":"XX门店"}]
  - name [String (inner)] [必填]
    字段描述: 名称：客资数据中的字段
    示例: name
  - kaData [KaData] [必填]
    字段描述: KA 数据
    示例: {"data":[{"code":"K001","keyword":"肯德基","trademarkName":"KFC"}],"keyword":"keyword","trademarkName":"trademarkName","screen":"屏蔽词"}
  - data [List<Map<String, Object>> (inner)] [必填]
    字段描述: KA数据列表
    示例: [{"code":"K001","keyword":"肯德基","trademarkName":"KFC"}]
  - keyword [String (inner)] [必填]
    字段描述: 关键词：KA数据中的字段
    示例: keyword
  - trademarkName [String (inner)] [必填]
    字段描述: 品牌名：KA数据中的字段
    示例: trademarkName
  - screen [String (inner)] [可选]
    字段描述: 屏蔽词：KA数据中的字段，多个用逗号隔开
    示例: 屏蔽词1,屏蔽词2


接口请求示例:
  {
    "customerData": {
        "data": [{"code": "001", "name": "XX门店"}],
        "name": "name"
    },
    "kaData": {
        "data": [{"code": "K001", "keyword": "肯德基", "trademarkName": "KFC"}],
        "keyword": "keyword",
        "trademarkName": "trademarkName",
        "screen": "屏蔽词"
    }
}
```
**示例:**
```json
{
    "customerData": {
        "data": [
            {
                "code": "001",
                "name": "XX门店"
            }
        ],
        "name": "name"
    },
    "kaData": {
        "data": [
            {
                "code": "K001",
                "keyword": "肯德基",
                "trademarkName": "KFC"
            }
        ],
        "keyword": "keyword",
        "trademarkName": "trademarkName",
        "screen": "屏蔽词"
    }
}
```

### normalized-expr — 归一值计算数据处理请求
```bash
gogeo-cli common-task operation normalized-expr --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_normalized_expr
请求方式: POST
接口描述: 归一值计算数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - normalizedData [List<Map<String, Object>>] [必填]
    字段描述: 归一数据列表，包含需要计算的数据(必须包含code字段)
    示例: [{"code":"001","salesAmount":1000},{"code":"002","salesAmount":1500}]
  - normalizedExpr [String] [必填]
    字段描述: 归一值计算表达式
    示例: (a + b) / c
  - compute [List<ComputeField>] [可选]
    字段描述: 计算字段配置列表
    示例: [{"computeFiled":"salesAmount","aliasName":"a"}]
  - computeFiled [String (inner)] [必填]
    字段描述: 计算字段:选择需要计算的字段
    示例: salesAmount
  - aliasName [String (inner)] [必填]
    字段描述: 别名:被用于写表达式的字段 例如：a
    示例: alias


接口请求示例:
  {
    "normalizedData": [
        {
            "code": "001",
            "salesAmount": 1000
        },
        {
            "code": "002",
            "salesAmount": 1500
        }
    ],
    "normalizedExpr": "(a + b) / c",
    "compute": [
        {
            "computeFiled": "salesAmount",
            "aliasName": "a"
        }
    ],
    "computeFiled": "salesAmount",
    "aliasName": "a"
}
```
**示例:**
```json
{
    "normalizedData": [
        {
            "code": "001",
            "salesAmount": 1000
        },
        {
            "code": "002",
            "salesAmount": 1500
        }
    ],
    "normalizedExpr": "(a + b) / c",
    "compute": [
        {
            "computeFiled": "salesAmount",
            "aliasName": "a"
        }
    ],
    "computeFiled": "salesAmount",
    "aliasName": "a"
}
```

### similarity — 相似度处理请求类
```bash
gogeo-cli common-task operation similarity --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_similarity_processing
请求方式: POST
接口描述: 相似度处理请求类


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资数据
    示例: {"data": [{"code": "001", "name": "门店"}], "name": "name"}
  - data [List<Map<String, Object>> (inner)] [必填]
    字段描述: 客资数据，其中code必须存在，如果选了规则经纬度point需要传point为wkt格式
    示例: [{"code": "001", "name": "门店", "point": "POINT(116.3 39.9)"}]
  - name [String (inner)] [必填]
    字段描述: 名称：客资数据资产的字段
    示例: name
  - txData [TxData] [必填]
    字段描述: 目标数据
    示例: {"data": [{"code": "tx_001", "name": "腾讯目标"}], "name": "name"}
  - data [List<Map<String, Object>> (inner)] [必填]
    字段描述: 目标数据，其中code必须存在，如果选了规则经纬度point需要传point为wkt格式
    示例: [{"code": "tx_001", "name": "腾讯目标", "point": "POINT(116.4 39.9)"}]
  - name [String (inner)] [必填]
    字段描述: 名称：目标数据资产的字段
    示例: name
  - policyCode [PolicyCode] [必填]
    字段描述: 相似度方式。处理方式。可选值: 30010=通用; 30009=连续
    示例: 30010
  - similarity [Double] [必填]
    字段描述: 相似度 数值类型，值 0~1 最大值不能超过 1
    示例: 0.8
  - isLng [Boolean] [必填]
    字段描述: 是否开启经纬度，开启经纬度后，需要填写步长和距离。默认false
    示例: false
  - step [Integer] [可选]
    字段描述: 步长 单位:(米); isLng是true时必填 数值类型
    示例: 100
  - distance [Double] [可选]
    字段描述: 距离 单位:(米); isLng是true时必填 数值类型
    示例: 500.0


接口请求示例:
  {
    "customerData": {
        "data": [
            {
                "code": "001",
                "name": "XX门店",
                "point": "POINT(116.3 39.9)"
            }
        ],
        "name": "name"
    },
    "txData": {
        "data": [
            {
                "code": "tx_001",
                "name": "腾讯目标",
                "point": "POINT(116.4 39.9)"
            }
        ],
        "name": "name"
    },
    "policyCode": "30010",
    "similarity": 0.8,
    "isLng": true,
    "step": 100,
    "distance": 500.0
}
```
**示例:**
```json
{
    "customerData": {
        "data": [
            {
                "code": "001",
                "name": "XX门店",
                "point": "POINT(116.3 39.9)"
            }
        ],
        "name": "name"
    },
    "txData": {
        "data": [
            {
                "code": "tx_001",
                "name": "腾讯目标",
                "point": "POINT(116.4 39.9)"
            }
        ],
        "name": "name"
    },
    "policyCode": "30010",
    "similarity": 0.8,
    "isLng": true,
    "step": 100,
    "distance": 500.0
}
```

### subsection-mark — 分段标记数据处理请求
```bash
gogeo-cli common-task operation subsection-mark --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_subsection_mark
请求方式: POST
接口描述: 分段标记数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - data [List<Map<String, Object>>] [必填]
    字段描述: 数据列表，其中 code 字段必须存在
    示例: [{"code":"001","field1":"value1"}]
  - subsectionGroupFields [List<String>] [必填]
    字段描述: 分段分组字段数组
    示例: ["group1"]
  - param [List<SubsectionCondition>] [必填]
    字段描述: 分段条件列表
    示例: [{"subsectionFields":["field1"],"subsectionType":"1","operType":"1","compareValue":100,"markValue":"A"}]
  - subsectionFields [List<String> (inner)] [必填]
    字段描述: 分段字段数组
    示例: ["field1","field2"]
  - subsectionType [SubsectionType (inner)] [必填]
    字段描述: 分段类型：1-占比，2-数值。分段标记类型。可选值: 1=占比; 2=数值
  - operType [OperType (inner)] [必填]
    字段描述: 操作类型：1-等于，2-不等于，3-大于，4-大于等于，5-小于，6-小于等于，7-最大值，8-最小值。分段比较操作符。可选值: 1=等于; 2=不等于; 3=大于; 4=大于等于; 5=小于; 6=小于等于; 7=最大值; 8=最小值
  - compareValue [Integer (inner)] [可选]
    字段描述: 比较值
    示例: 100
  - groupField [String (inner)] [可选]
    字段描述: 分组字段（操作类型为 7 或 8 时必填）
    示例: groupField
  - markValue [String (inner)] [必填]
    字段描述: 标记值
    示例: high_value


接口请求示例:
  {
    "data": [
        {
            "code": "001",
            "field1": "value1"
        }
    ],
    "subsectionGroupFields": [
        "group1"
    ],
    "param": [
        {
            "subsectionFields": [
                "field1"
            ],
            "subsectionType": "1",
            "operType": "1",
            "compareValue": 100,
            "markValue": "A"
        }
    ],
    "subsectionFields": [
        "field1",
        "field2"
    ],
    "compareValue": 100,
    "groupField": "groupField",
    "markValue": "A"
}
```
**示例:**
```json
{
    "data": [
        {
            "code": "001",
            "field1": "value1"
        }
    ],
    "subsectionGroupFields": [
        "group1"
    ],
    "param": [
        {
            "subsectionFields": [
                "field1"
            ],
            "subsectionType": "1",
            "operType": "1",
            "compareValue": 100,
            "markValue": "A"
        }
    ],
    "subsectionFields": [
        "field1",
        "field2"
    ],
    "compareValue": 100,
    "groupField": "groupField",
    "markValue": "A"
}
```

### text-concat — 文本拼接请求
```bash
gogeo-cli common-task operation text-concat --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_text_concat
请求方式: POST
接口描述: 文本拼接请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - textData [List<Map<String, Object>>] [必填]
    字段描述: 文本数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - concatFields [List<String>] [必填]
    字段描述: 拼接字段：多选，例如['省','市','区','地址']
    示例: ["province","city","district","address"]


接口请求示例:
  {
    "textData": [
        {
            "code": "001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "concatFields": [
        "province",
        "city",
        "district",
        "address"
    ]
}
```
**示例:**
```json
{
    "textData": [
        {
            "code": "001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "concatFields": [
        "province",
        "city",
        "district",
        "address"
    ]
}
```

### text-handling — 文本处理请求
```bash
gogeo-cli common-task operation text-handling --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_text_handling
请求方式: POST
接口描述: 文本处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - textData [TextData] [必填]
    字段描述: 处理数据
    示例: [{"code":"text_001","text":"测试文本内容"}]
  - data [List<Map<String, Object>> (inner)] [必填]
    字段描述: 文本数据列表 code 必须要有值
    示例: [{"code": "001", "address": "测试地址"}]
  - textStr [String (inner)] [必填]
    字段描述: 待处理的字段：资产数据中的字段
    示例: address
  - textHandlingStrategy [List<TextHandlingStrategy>] [必填]
    字段描述: 处理的策略
  - policyCode [PolicyCode (inner)] [必填]
    字段描述: 处理策略取值枚举（输入汉字时需根据汉字内容映射为编码）。可选值: 10001=剔除-括号内容; 10002=提取-括号内容; 10003=提取-连续数字; 10004=剔除-连续数字; 10005=提取-连续数字字母; 10006=剔除-连续数字字母; 10010=剔除-特殊字符-全文; 10013=剔除-前缀; 10014=剔除-后缀; 10017=包含-前缀; 10018=包含-后缀; 10019=通配符-提取内容; 10021=提取-连续字母; 10022=剔除-连续字母; 10025=提取-多连续数字; 10026=提取-多连续数字字母; 10027=提取-多连续字母; 10029=剔除-空格
  - policyConfig [String (inner)] [必填]
    字段描述: 处理方式：没有则输入 '无'; 提取、剔除连续数字类输入：>X (X是大于0的数字)，剔除特殊字符输入要剔除的特殊字符：例如 $%(（,#,*）) 等，用英文逗号隔开。


接口请求示例:
  {
    "textData": {
        "data": [
            {
                "code": "001",
                "address": "北京市朝阳区XX路"
            }
        ],
        "textStr": "address"
    },
    "textHandlingStrategy": [
        {
            "policyCode": "10002",
            "policyConfig": "无"
        }
    ]
}
```
**示例:**
```json
{
    "textData": {
        "data": [
            {
                "code": "001",
                "address": "北京市朝阳区XX路"
            }
        ],
        "textStr": "address"
    },
    "textHandlingStrategy": [
        {
            "policyCode": "10002",
            "policyConfig": "无"
        }
    ]
}
```

### text-similarity — 相似度计算数据处理请求
```bash
gogeo-cli common-task operation text-similarity --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeOperationToolController/realtime_text_similarity
请求方式: POST
接口描述: 相似度计算数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - textData [List<Map<String, Object>>] [必填]
    字段描述: 文本数据列表(必须包含code字段)
    示例: [{"code":"001","sourceContent":"文本1","targetContent":"文本2"}]
  - sourceText [String] [必填]
    字段描述: 源文本字段
    示例: sourceContent
  - targetText [String] [必填]
    字段描述: 目标文本字段
    示例: targetContent
  - algorithm [SimilarityAlgorithm] [必填]
    字段描述: 相似算法
    示例: 0


接口请求示例:
  {
    "textData": [
        {
            "code": "001",
            "sourceContent": "文本1",
            "targetContent": "文本2"
        }
    ],
    "sourceText": "sourceContent",
    "targetText": "targetContent"
}
```
**示例:**
```json
{
    "textData": [
        {
            "code": "001",
            "sourceContent": "文本1",
            "targetContent": "文本2"
        }
    ],
    "sourceText": "sourceContent",
    "targetText": "targetContent"
}
```

### realtime-logistics-route-planning — 物流-路径规划 (实时)
```bash
gogeo-cli common-task realtime resource realtime-logistics-route-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeResourcePlanningController/realtime_logistics_route_planning
请求方式: POST
接口描述: 物流-路径规划 (实时)


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code、point（经纬度）字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"001","point":"POINT(116.404 39.915)"}]
  - group1 [String] [必填]
    字段描述: 分组字段一
    示例: group_field_1
  - group2 [String] [可选]
    字段描述: 分组字段二
    示例: group_field_2
  - group3 [String] [可选]
    字段描述: 分组字段三
    示例: group_field_3
  - group4 [String] [可选]
    字段描述: 分组字段四
    示例: group_field_4
  - group5 [String] [可选]
    字段描述: 分组字段五
    示例: group_field_5
  - arrivalOrder [String] [必填]
    字段描述: 到达顺序 数字类型的值
    示例: order
  - startLocation [String] [必填]
    字段描述: 起始位置
    示例: start
  - trackType [TrackType] [必填]
    字段描述: 出行方式。生成方式。可选值: bicycling=骑行; driving=驾车; straightLine=直线; walking=步行
    示例: driving
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
    示例: [{"field":"salesAmount","aggregationType":"Count"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "group1": "group_field_1",
    "group2": "group_field_2",
    "group3": "group_field_3",
    "group4": "group_field_4",
    "group5": "group_field_5",
    "arrivalOrder": "order",
    "startLocation": "start",
    "trackType": "driving",
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Count"
        }
    ]
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "group1": "group_field_1",
    "group2": "group_field_2",
    "group3": "group_field_3",
    "group4": "group_field_4",
    "group5": "group_field_5",
    "arrivalOrder": "order",
    "startLocation": "start",
    "trackType": "driving",
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Count"
        }
    ]
}
```

### realtime-route-replay — 物流 - 线路重排 (实时)
```bash
gogeo-cli common-task realtime resource realtime-route-replay --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeResourcePlanningController/realtime_route_replay
请求方式: POST
接口描述: 物流 - 线路重排 (实时)


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 字段必须存在，point 格式为 WKT 格式
    示例: [{"code":"001","point":"POINT(116.404 39.915)"}]
  - groupId [String] [必填]
    字段描述: 分组字段一
    示例: route_group
  - round [String] [必填]
    字段描述: 分组字段二
    示例: round_1
  - startLocation [String] [必填]
    字段描述: 起始位置
    示例: POINT(116.404 39.915)


接口请求示例:
  {
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "groupId": "route_group",
    "round": "round_1",
    "startLocation": "POINT(116.404 39.915)"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "groupId": "route_group",
    "round": "round_1",
    "startLocation": "POINT(116.404 39.915)"
}
```

### realtime-service-day-week-division — 服务日-周划分 (实时)
```bash
gogeo-cli common-task realtime resource realtime-service-day-week-division --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeResourcePlanningController/realtime_service_day_week_division
请求方式: POST
接口描述: 服务日-周划分 (实时)


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资信息
    示例: {"data":[{"code":"001","point":"POINT(116.404 39.915)"}],"salesCode":"salesCode","visitCycle":"visitCycle","visitNum":"visitNum","codeField":"code"}
  - propertyCode [String (inner)] [必填]
    字段描述: 客资资产编码
    示例: customer_001
  - textStr1 [String (inner)] [必填]
    字段描述: 文本字段1：客资资产的字段
    示例: name
  - textStr2 [String (inner)] [必填]
    字段描述: 文本字段2：客资资产的字段
    示例: address
  - salesData [SalesData] [必填]
    字段描述: 销售信息
    示例: {"data":[{"code":"S001","point":"POINT(116.404 39.915)"}],"codeField":"code"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: sales_asset_001
  - code [String (inner)] [必填]
    字段描述: 销售编码（销售信息 - 销售编码）
    示例: S001
  - maxDistance [String (inner)] [必填]
    字段描述: 最大售点距离，单位：km
    示例: maxdistance
  - maxVisitNum [String (inner)] [可选]
    字段描述: 每日最大服务客户数
    示例: maxvisitnum
  - minVisitNum [String (inner)] [可选]
    字段描述: 每日最小服务客户数
    示例: minvisitnum
  - historyData [HistoryData] [必填]
    字段描述: 历史拜访数据
    示例: {"data":[{"customerCode":"C001","visitDate":"2024-01-01","salesCode":"S001"}],"propertyCodeField":"propertyCode","customerCodeField":"customerCode","visitDateField":"visitDate","salesCodeField":"salesCode"}
  - propertyCode [String (inner)] [必填]
    字段描述: 资产编码
    示例: history_001
  - customerCode [String (inner)] [必填]
    字段描述: 客资编码（历史拜访数据）
    示例: cust_001
  - visitDate [String (inner)] [必填]
    字段描述: 实际拜访日期（历史拜访数据）
    示例: 2026-04-01
  - salesCode [String (inner)] [必填]
    字段描述: 销售编码（历史拜访数据）
    示例: salesCode
  - scuData [List<Map<String, Object>>] [可选]
    字段描述: 围栏数据，包含资产编码及经纬度等信息的列表
    示例: [{"code":"SCU001","point":"POINT(116.404 39.915)"}]
  - divideType [DivideType] [必填]
    字段描述: 划分类型。时间划分粒度。可选值: week=周; day=日
    示例: week
  - balanceField [String] [必填]
    字段描述: 均衡字段（客资信息 - 用于均衡分配客户）
    示例: potentialValue
  - group1 [String] [必填]
    字段描述: 拜访周（divideType 为 week 时必填，客户信息 - 服务日、服务周划分标识，如果第二次规划想基于第一次的基础进行则需要选择）
    示例: route_group1
  - group2 [String] [可选]
    字段描述: 拜访日
    示例: route_group2
  - workDay [String] [可选]
    字段描述: 工作日（divideType 为 day 时必填）
    示例: 1,2,3,4,5
  - startEndDate [List<String>] [必填]
    字段描述: 开始结束日期列表
    示例: ["2024-01-01","2024-01-31"]


接口请求示例:
  {
    "customerData": {
        "data": [
            {
                "code": "001",
                "point": "POINT(116.404 39.915)"
            }
        ],
        "salesCode": "salesCode",
        "visitCycle": "visitCycle",
        "visitNum": "visitNum",
        "codeField": "code"
    },
    "salesData": {
        "data": [
            {
                "code": "S001",
                "point": "POINT(116.404 39.915)"
            }
        ],
        "codeField": "code"
    },
    "historyData": {
        "data": [
            {
                "customerCode": "C001",
                "visitDate": "2024-01-01",
                "salesCode": "S001"
            }
        ],
        "propertyCodeField": "propertyCode",
        "customerCodeField": "customerCode",
        "visitDateField": "visitDate",
        "salesCodeField": "salesCode"
    },
    "scuData": [
        {
            "code": "SCU001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "balanceField": "potentialValue",
    "group1": "W1",
    "group2": "D1",
    "workDay": "1,2,3,4,5",
    "startEndDate": [
        "2024-01-01",
        "2024-01-31"
    ],
    "data": [
        {
            "code": "S001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "salesCode": "salesCode",
    "visitCycle": "visitCycle",
    "visitNum": "visitNum",
    "codeField": "code",
    "propertyCodeField": "propertyCode",
    "customerCodeField": "customerCode",
    "visitDateField": "visitDate",
    "salesCodeField": "salesCode",
    "maxDistanceField": "maxDistance",
    "maxVisitNumField": "maxVisitNum",
    "minVisitNumField": "minVisitNum"
}
```
**示例:**
```json
{
    "customerData": {
        "data": [
            {
                "code": "001",
                "point": "POINT(116.404 39.915)"
            }
        ],
        "salesCode": "salesCode",
        "visitCycle": "visitCycle",
        "visitNum": "visitNum",
        "codeField": "code"
    },
    "salesData": {
        "data": [
            {
                "code": "S001",
                "point": "POINT(116.404 39.915)"
            }
        ],
        "codeField": "code"
    },
    "historyData": {
        "data": [
            {
                "customerCode": "C001",
                "visitDate": "2024-01-01",
                "salesCode": "S001"
            }
        ],
        "propertyCodeField": "propertyCode",
        "customerCodeField": "customerCode",
        "visitDateField": "visitDate",
        "salesCodeField": "salesCode"
    },
    "scuData": [
        {
            "code": "SCU001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "balanceField": "potentialValue",
    "group1": "W1",
    "group2": "D1",
    "workDay": "1,2,3,4,5",
    "startEndDate": [
        "2024-01-01",
        "2024-01-31"
    ],
    "data": [
        {
            "code": "S001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "salesCode": "salesCode",
    "visitCycle": "visitCycle",
    "visitNum": "visitNum",
    "codeField": "code",
    "propertyCodeField": "propertyCode",
    "customerCodeField": "customerCode",
    "visitDateField": "visitDate",
    "salesCodeField": "salesCode",
    "maxDistanceField": "maxDistance",
    "maxVisitNumField": "maxVisitNum",
    "minVisitNumField": "minVisitNum"
}
```

### realtime-service-route-planning — 线路排序规划 (实时)
```bash
gogeo-cli common-task realtime resource realtime-service-route-planning --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeResourcePlanningController/realtime_service_route_planning
请求方式: POST
接口描述: 线路排序规划 (实时)


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - customerData [List<Map<String, Object>>] [必填]
    字段描述: 客资信息
    示例: [{"code":"001","point":"POINT(116.404 39.915)"}]
  - salesData [List<Map<String, Object>>] [必填]
    字段描述: 销售信息
    示例: [{"code":"S001","point":"POINT(116.404 39.915)"}]
  - group1 [String] [必填]
    字段描述: 拜访周
    示例: route_group1
  - group2 [String] [必填]
    字段描述: 拜访日
    示例: route_group2
  - startEndDate [List<String>] [必填]
    字段描述: 开始结束时间段，格式：yyyy-MM-dd HH:mm:ss
    示例: ["2024-01-01 08:00:00","2024-01-01 18:00:00"]
  - salesCodeField [String] [必填]
    字段描述: 销售编码字段名
    示例: salesCode
  - isFirstOrderField [String] [必填]
    字段描述: 是否第一家店字段名
    示例: isFirstOrder
  - visitDurationField [String] [可选]
    字段描述: 服务时长字段名
    示例: visitDuration
  - visitOrderField [String] [可选]
    字段描述: 拜访顺序字段名
    示例: visitOrder
  - customerCodeField [String] [必填]
    字段描述: 客资编码字段名
    示例: code
  - visitCycleField [String] [必填]
    字段描述: 服务周期字段名
    示例: visitCycle
  - visitNumField [String] [必填]
    字段描述: 服务次数字段名
    示例: visitNum
  - startTimeField [String] [必填]
    字段描述: 开始时间字段名
    示例: startTime
  - endTimeField [String] [可选]
    字段描述: 结束时间字段名
    示例: endTime
  - salesDataCodeField [String] [必填]
    字段描述: 销售编码字段名(销售数据)
    示例: code
  - salesStartTimeField [String] [必填]
    字段描述: 上班时间字段名
    示例: startTime
  - salesEndTimeField [String] [可选]
    字段描述: 下班时间字段名
    示例: endTime
  - officeWaitTimeField [String] [可选]
    字段描述: 办公室等待时长字段名
    示例: officeWaitTime
  - startingPointField [String] [可选]
    字段描述: 出发地点字段名
    示例: startingPoint
  - amEndTimeField [String] [可选]
    字段描述: 午饭最早开始时间字段名
    示例: amEndTime
  - pmStartTimeField [String] [可选]
    字段描述: 午饭最晚结束时间字段名
    示例: pmStartTime
  - travelMode [String] [必填]
    字段描述: 出行方式
    示例: driving
  - travelSpeed [Integer] [必填]
    字段描述: 出行速度
    示例: 60
  - officePoint [String] [可选]
    字段描述: 办公室坐标
    示例: POINT(116.404 39.915)
  - holidayStr [String] [可选]
    字段描述: 节假日，格式：yyyy-MM-dd,yyyy-MM-dd
    示例: 2024-01-01,2024-01-02


接口请求示例:
  {
    "customerData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "salesData": [
        {
            "code": "S001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "group1": "W1",
    "group2": "D1",
    "startEndDate": [
        "2024-01-01 08:00:00",
        "2024-01-01 18:00:00"
    ],
    "salesCodeField": "salesCode",
    "isFirstOrderField": "isFirstOrder",
    "visitDurationField": "visitDuration",
    "visitOrderField": "visitOrder",
    "customerCodeField": "code",
    "visitCycleField": "visitCycle",
    "visitNumField": "visitNum",
    "startTimeField": "startTime",
    "endTimeField": "endTime",
    "salesDataCodeField": "code",
    "salesStartTimeField": "startTime",
    "salesEndTimeField": "endTime",
    "officeWaitTimeField": "officeWaitTime",
    "startingPointField": "startingPoint",
    "amEndTimeField": "amEndTime",
    "pmStartTimeField": "pmStartTime",
    "travelMode": "driving",
    "travelSpeed": 60,
    "officePoint": "POINT(116.404 39.915)",
    "holidayStr": "2024-01-01,2024-01-02"
}
```
**示例:**
```json
{
    "customerData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "salesData": [
        {
            "code": "S001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "group1": "W1",
    "group2": "D1",
    "startEndDate": [
        "2024-01-01 08:00:00",
        "2024-01-01 18:00:00"
    ],
    "salesCodeField": "salesCode",
    "isFirstOrderField": "isFirstOrder",
    "visitDurationField": "visitDuration",
    "visitOrderField": "visitOrder",
    "customerCodeField": "code",
    "visitCycleField": "visitCycle",
    "visitNumField": "visitNum",
    "startTimeField": "startTime",
    "endTimeField": "endTime",
    "salesDataCodeField": "code",
    "salesStartTimeField": "startTime",
    "salesEndTimeField": "endTime",
    "officeWaitTimeField": "officeWaitTime",
    "startingPointField": "startingPoint",
    "amEndTimeField": "amEndTime",
    "pmStartTimeField": "pmStartTime",
    "travelMode": "driving",
    "travelSpeed": 60,
    "officePoint": "POINT(116.404 39.915)",
    "holidayStr": "2024-01-01,2024-01-02"
}
```

### address-parse — 地址解析请求类
```bash
gogeo-cli common-task spatial analysis address-parse --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_address_parsing
请求方式: POST
接口描述: 地址解析请求类


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 address 地址字段内容必须存在
    示例: [{"code":"001","address":"北京市朝阳区XX路XX号"}]
  - address [String] [必填]
    字段描述: 地址字段名
    示例: address


接口请求示例:
  {
    "pointData": [
        {
            "code": "001",
            "address": "北京市朝阳区XX路XX号"
        }
    ],
    "address": "address"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "001",
            "address": "北京市朝阳区XX路XX号"
        }
    ],
    "address": "address"
}
```

### affiliation-area-v1 — 归属区域生成 V1-自定义面请求
```bash
gogeo-cli common-task spatial analysis affiliation-area-v1 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_affiliation_area_generate_v1_custom_polygon
请求方式: POST
接口描述: 归属区域生成 V1-自定义面请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中必须包含 code、point 经纬度字段和归属区域字段，point 格式 wkt 格式
    示例: [{"code":"point_001","point":"POINT(116.3 39.9)","areaName":"朝阳区"}]
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据 其中必须包含 code 和 fence 字段，fence 格式 wkt 格式
    示例: [{"code":"fence_001","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - name [String] [必填]
    字段描述: 归属区域字段：点数据中的归属区域字段，必填
    示例: areaName
  - num [String] [必填]
    字段描述: 潜力字段：点数据中的潜力字段
    示例: potentialValue
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计字段配置列表
    示例: [{"field":"sales","aggregationType":"Sum"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "point": "POINT(116.3 39.9)",
            "areaName": "朝阳区"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "name": "areaName",
    "num": "potentialValue",
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "salesAmount"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "point": "POINT(116.3 39.9)",
            "areaName": "朝阳区"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "name": "areaName",
    "num": "potentialValue",
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "salesAmount"
}
```

### area-split — 等面积划分数据处理请求
```bash
gogeo-cli common-task spatial analysis area-split --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_area_split_plan
请求方式: POST
接口描述: 等面积划分数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [可选]
    字段描述: 
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - splitCount [Integer] [必填]
    字段描述: 划分数量：需要将面数据划分成的区域数量
    示例: 5
  - balance [Integer] [必填]
    字段描述: 平衡值：控制划分结果的均衡程度，值越大越均衡
    示例: 50
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合字段配置列表，用于对划分结果进行统计分析
    示例: [{"field":"salesAmount","type":"Count","alias":"totalSales"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "splitCount": 5,
    "balance": 50,
    "aggregationFields": [
        {
            "field": "salesAmount",
            "type": "Count",
            "alias": "totalSales"
        }
    ],
    "field": "salesAmount",
    "type": "Count",
    "alias": "totalSales"
}
```
**示例:**
```json
{
    "splitCount": 5,
    "balance": 50,
    "aggregationFields": [
        {
            "field": "salesAmount",
            "type": "Count",
            "alias": "totalSales"
        }
    ],
    "field": "salesAmount",
    "type": "Count",
    "alias": "totalSales"
}
```

### belonging-area-v2 — 归属区域生成 V2 请求
```bash
gogeo-cli common-task spatial analysis belonging-area-v2 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_belonging_area_gen_v2
请求方式: POST
接口描述: 归属区域生成 V2 请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据列表
    示例: [{"code":"fence_001","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - customizeFenceData [List<Map<String, Object>>] [可选]
    字段描述: 自定义围栏数据列表
    示例: [{"code":"fence_002","fence":"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))"}]
  - connectType [ConnectType] [必填]
    字段描述: 划分类型：1-网格，2-蜂窝。连接/网格类型(V2)。可选值: 1=网格; 2=蜂窝
    示例: 1
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级：city-城市，district-区县，province-省份。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围
    示例: [["340000"],["820000"]]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
    示例: [{"field":"sales","aggregationType":"Sum"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_002",
            "fence": "POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))"
        }
    ],
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ]
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "salesAmount"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_002",
            "fence": "POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))"
        }
    ],
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ]
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "salesAmount"
}
```

### equal-value-split — 等潜力划分V2-面数据处理请求
```bash
gogeo-cli common-task spatial analysis equal-value-split --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_equal_value_split_v2
请求方式: POST
接口描述: 等潜力划分V2-面数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，用于等潜力划分V2的源数据
    示例: [{"code":"F001","fence":"POLYGON((...))"}]
  - num [String] [必填]
    字段描述: 潜力字段：资产数据中用于划分计算的字段名称
    示例: potentialValue
  - splitCount [Integer] [可选]
    字段描述: 
  - balanceValue [Integer] [可选]
    字段描述: 
  - compareValue [Integer] [可选]
    字段描述: 
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表，用于对划分结果进行统计分析
    示例: [{"field":"salesAmount","type":"Count"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((...))"
        }
    ],
    "num": "potentialValue",
    "aggregationFields": [
        {
            "field": "salesAmount",
            "type": "Count"
        }
    ],
    "field": "salesAmount",
    "type": "Count",
    "alias": "totalSales"
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((...))"
        }
    ],
    "num": "potentialValue",
    "aggregationFields": [
        {
            "field": "salesAmount",
            "type": "Count"
        }
    ],
    "field": "salesAmount",
    "type": "Count",
    "alias": "totalSales"
}
```

### fence-cluster — 面聚类分析请求
```bash
gogeo-cli common-task spatial analysis fence-cluster --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_fence_cluster_analysis
请求方式: POST
接口描述: 面聚类分析请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - partitionNum [Integer] [必填]
    字段描述: 划分数量
    示例: 10


接口请求示例:
  {
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "partitionNum": 10
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "partitionNum": 10
}
```

### fence-crossing — 围栏不相交的区域数据处理请求
```bash
gogeo-cli common-task spatial analysis fence-crossing --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_fence_crossing
请求方式: POST
接口描述: 围栏不相交的区域数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - sourceData [List<Map<String, Object>>] [必填]
    字段描述: 主数据面数据列表(必须包含code和fence字段,fence为WKT格式)
    示例: [{"code":"001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - targetData [List<Map<String, Object>>] [必填]
    字段描述: 对比面数据列表(必须包含code和fence字段,fence为WKT格式)
    示例: [{"code":"101","name":"障碍区1","fence":"POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))"}]


接口请求示例:
  {
    "sourceData": [
        {
            "code": "001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "targetData": [
        {
            "code": "101",
            "name": "障碍区1",
            "fence": "POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))"
        }
    ]
}
```
**示例:**
```json
{
    "sourceData": [
        {
            "code": "001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "targetData": [
        {
            "code": "101",
            "name": "障碍区1",
            "fence": "POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))"
        }
    ]
}
```

### kmeans — KMeans 算法数据处理请求
```bash
gogeo-cli common-task spatial analysis kmeans --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_point_kmeans
请求方式: POST
接口描述: KMeans 算法数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 字段必须存在，point 格式为 WKT 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - clusterType [String] [必填]
    字段描述: 聚类类型。可选值: 1=面; 2=点转面
    示例: 1
  - clusterAlgorithm [ClusterAlgorithm] [必填]
    字段描述: 聚类算法。可选值: 0=Kmeans
    示例: 0
  - gridType [GridType] [可选]
    字段描述: 网格类型。KMeans网格/蜂窝类型。可选值: GD_r1000=R1000网格; GD_r2000=R2000网格; GD_r500=R500网格; HD_r1000=R1000蜂窝; HD_r2000=R2000蜂窝; HD_r500=R500蜂窝; RD_four=4级路网
    示例: GD_r1000
  - amount [Integer] [必填]
    字段描述: 划分数量
    示例: 5


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "clusterType": "1",
    "clusterAlgorithm": "0",
    "amount": 5
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "clusterType": "1",
    "clusterAlgorithm": "0",
    "amount": 5
}
```

### line-buffer — 线外扩缓冲区数据处理请求
```bash
gogeo-cli common-task spatial analysis line-buffer --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_line_buffer
请求方式: POST
接口描述: 线外扩缓冲区数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - lineData [List<Map<String, Object>>] [必填]
    字段描述: 线数据列表(必须包含code和line字段,line为WKT格式)
    示例: [{"code":"line_001","name":"道路1","line":"LINESTRING(116.3 39.9, 116.4 40.0, 116.5 40.1)"}]
  - buffer [Integer] [必填]
    字段描述: 缓冲距离（米）
    示例: 100
  - endCapStyle [BufferStyle] [必填]
    字段描述: 端点样式。线缓冲端点样式，可选值: 1=半圆; 2=平面; 3=方形
    示例: 1
  - quadrantSegments [Integer] [可选]
    字段描述: 圆弧线段数
    示例: 8


接口请求示例:
  {
    "lineData": [
        {
            "code": "line_001",
            "name": "道路1",
            "line": "LINESTRING(116.3 39.9, 116.4 40.0, 116.5 40.1)"
        }
    ],
    "buffer": 100
}
```
**示例:**
```json
{
    "lineData": [
        {
            "code": "line_001",
            "name": "道路1",
            "line": "LINESTRING(116.3 39.9, 116.4 40.0, 116.5 40.1)"
        }
    ],
    "buffer": 100
}
```

### point-cluster — 点聚类分析请求
```bash
gogeo-cli common-task spatial analysis point-cluster --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_point_cluster_analysis
请求方式: POST
接口描述: 点聚类分析请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"001","point":"POINT(116.404 39.915)"}]
  - partitionNum [Integer] [必填]
    字段描述: 划分数量
    示例: 10


接口请求示例:
  {
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "partitionNum": 10
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "001",
            "point": "POINT(116.404 39.915)"
        }
    ],
    "partitionNum": 10
}
```

### potential-classification — 等潜力划分 V2-点数据处理请求
```bash
gogeo-cli common-task spatial analysis potential-classification --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_potential_classification_v2_point
请求方式: POST
接口描述: 等潜力划分 V2-点数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据
    示例: [{"code":"point_001","point":"POINT(116.3 39.9)","potential":100}]
  - customizeFenceData [List<Map<String, Object>>] [必填]
    字段描述: 自定义围栏数据
    示例: [{"code":"fence_001","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - connectType [ConnectType] [必填]
    字段描述: 连线方式。连接/网格类型(V2)。可选值: 1=网格; 2=蜂窝
    示例: grid
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>>] [必填]
    字段描述: 自定义生效范围（多选）
    示例: [["340000"],["820000"]]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
    示例: [{"field":"sales","aggregationType":"Sum"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum
  - numField [String] [可选]
    字段描述: 潜力字段名
    示例: potentialValue


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ]
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "numField": "potentialValue"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ]
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "numField": "potentialValue"
}
```

### potential-split — 等潜力划分数据处理请求
```bash
gogeo-cli common-task spatial analysis potential-split --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_potential_area_split_plan
请求方式: POST
接口描述: 等潜力划分数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [可选]
    字段描述: 
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - num [String] [必填]
    字段描述: 潜力字段：资产数据中用于划分计算的字段名称
    示例: population
  - splitCount [Integer] [必填]
    字段描述: 划分数量：需要将面数据划分成的区域数量
    示例: 5
  - balance [Integer] [必填]
    字段描述: 平衡值：控制划分结果的均衡程度，值越大越均衡
    示例: 50
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合字段配置列表，用于对划分结果进行统计分析
    示例: [...]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "fenceData": [
        {
            "code": "f1",
            "name": "测试围栏",
            "fence": "POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))"
        }
    ],
    "num": "potentialValue",
    "splitCount": 5,
    "balance": 50,
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Sum"
        }
    ]
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "f1",
            "name": "测试围栏",
            "fence": "POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))"
        }
    ],
    "num": "potentialValue",
    "splitCount": 5,
    "balance": 50,
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Sum"
        }
    ]
}
```

### projection-area — 投影面积计算请求
```bash
gogeo-cli common-task spatial analysis projection-area --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_projection_area_calculation
请求方式: POST
接口描述: 投影面积计算请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]


接口请求示例:
  {
    "fenceData": [
        {
            "code": "f1",
            "name": "测试围栏",
            "fence": "POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))"
        }
    ]
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "f1",
            "name": "测试围栏",
            "fence": "POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))"
        }
    ]
}
```

### random-sample — 围栏内随机取样数据处理请求
```bash
gogeo-cli common-task spatial analysis random-sample --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_fence_random_sample
请求方式: POST
接口描述: 围栏内随机取样数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 字段必须存在，point 格式为 WKT 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - count [Integer] [必填]
    字段描述: 取样数（个）
    示例: 100


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "count": 10
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "count": 10
}
```

### reverse-address-parse — 逆地址解析
```bash
gogeo-cli common-task spatial analysis reverse-address-parse --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialAnalysisController/realtime_reverse_address_parsing
请求方式: POST
接口描述: 逆地址解析


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中code 和 point 经纬度字段内容必须存在,point格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ]
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ]
}
```

### belonging-area-v1 — 归属区域生成 V1 请求
```bash
gogeo-cli common-task spatial calculation belonging-area-v1 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_belonging_area_generate_v1
请求方式: POST
接口描述: 归属区域生成 V1 请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中必须包含 code、point 经纬度字段和归属区域字段，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - name [String] [必填]
    字段描述: 归属区域字段：点数据中的归属区域字段
    示例: areaName
  - num [String] [必填]
    字段描述: 潜力字段：点数据中的潜力字段
    示例: potentialValue
  - connectType [ConnectType] [必填]
    字段描述: 连接方式：1-直线，2-网格，3-蜂窝。连接/网格类型(V2)。可选值: 1=网格; 2=蜂窝
    示例: 1
  - boundaryLevel [BoundaryLevel] [可选]
    字段描述: 边界等级，连接方式为 2 或 3 时必填。行政边界级别。可选值: province=省份; city=城市; district=区县
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合字段配置列表
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "point": "POINT(116.3 39.9)",
            "areaName": "朝阳区"
        }
    ],
    "name": "areaName",
    "num": "potentialValue",
    "aggregationFields": []
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "point": "POINT(116.3 39.9)",
            "areaName": "朝阳区"
        }
    ],
    "name": "areaName",
    "num": "potentialValue",
    "aggregationFields": []
}
```

### center-point — 内外心计算
```bash
gogeo-cli common-task spatial calculation center-point --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_center_point_compute
请求方式: POST
接口描述: 内外心计算


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"F001","fence":"POLYGON((...))"}]
  - computeType [ComputeType] [必填]
    字段描述: 计算方式。中心点计算方式。可选值: 1=内心; 2=外心
    示例: 1


接口请求示例:
  {
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((...))"
        }
    ]
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((...))"
        }
    ]
}
```

### fence-buffer — 围栏外扩缓冲区
```bash
gogeo-cli common-task spatial calculation fence-buffer --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_fence_broad_buffer
请求方式: POST
接口描述: 围栏外扩缓冲区


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - bufferArea [String] [必填]
    字段描述: 外扩范围（米）
    示例: 1000


接口请求示例:
  {
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "bufferArea": 1000
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "bufferArea": 1000
}
```

### fence-contain — 围栏包含围栏请求
```bash
gogeo-cli common-task spatial calculation fence-contain --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_fence_contain_fence
请求方式: POST
接口描述: 围栏包含围栏请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - mainData [List<Map<String, Object>>] [必填]
    字段描述: 主围栏数据 其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"main_001","name":"主数据","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - auxiliaryData [List<Map<String, Object>>] [必填]
    字段描述: 辅围栏数据 其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"aux_001","name":"辅助数据","fence":"POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))"}]
  - translationFields [List<String>] [可选]
    字段描述: 结果容易字段 (辅数据资产的字段)，非必填
    示例: ["field1","field2"]


接口请求示例:
  {
    "mainData": "mainData",
    "auxiliaryData": "auxiliaryData",
    "translationFields": [
        "field1",
        "field2"
    ]
}
```
**示例:**
```json
{
    "mainData": "mainData",
    "auxiliaryData": "auxiliaryData",
    "translationFields": [
        "field1",
        "field2"
    ]
}
```

### fence-contain-relation — 单围栏包含关系
```bash
gogeo-cli common-task spatial calculation fence-contain-relation --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_fence_contain_relation
请求方式: POST
接口描述: 单围栏包含关系


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - field1 [String] [必填]
    字段描述: 分组字段 1
    示例: field1
  - field2 [String] [可选]
    字段描述: 分组字段 2
  - field3 [String] [可选]
    字段描述: 分组字段 3
  - field4 [String] [可选]
    字段描述: 分组字段 4
  - field5 [String] [可选]
    字段描述: 分组字段 5
  - oneToOneFlag [Boolean] [必填]
    字段描述: 包含类型（true: 单围栏，false: 多围栏）
    示例: true
  - isGroup [Boolean] [必填]
    字段描述: 是否分组（true: 是，false: 否）
    示例: true
  - containRatio [String] [必填]
    字段描述: 包含比例
    示例: 100
  - isAll [Boolean] [必填]
    字段描述: 是否需要全量数据（true: 是，false: 否）
    示例: false


接口请求示例:
  {
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "field1": "field1",
    "field2": "field2",
    "field3": "field3",
    "field4": "field4",
    "field5": "field5",
    "containRatio": 100
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "field1": "field1",
    "field2": "field2",
    "field3": "field3",
    "field4": "field4",
    "field5": "field5",
    "containRatio": 100
}
```

### fence-equalization — 片区扇形切分数据处理请求
```bash
gogeo-cli common-task spatial calculation fence-equalization --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_fence_equalization
请求方式: POST
接口描述: 片区扇形切分数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"F001","fence":"POLYGON((...))"}]
  - point [String] [必填]
    字段描述: 起始经纬度字段
    示例: POINT(116.404 39.915)
  - equalNumber [Integer] [必填]
    字段描述: 等分数量
    示例: 4


接口请求示例:
  {
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((...))"
        }
    ],
    "point": "POINT(116.404 39.915)",
    "equalNumber": 4
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "F001",
            "fence": "POLYGON((...))"
        }
    ],
    "point": "POINT(116.404 39.915)",
    "equalNumber": 4
}
```

### fence-intersection-area — 围栏相交的区域请求
```bash
gogeo-cli common-task spatial calculation fence-intersection-area --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_fence_intersection_area
请求方式: POST
接口描述: 围栏相交的区域请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - mainFenceData [List<Map<String, Object>>] [必填]
    字段描述: 主围栏数据 其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - auxiliaryFenceData [List<Map<String, Object>>] [必填]
    字段描述: 辅围栏数据 其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_002","name":"区域B","fence":"POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))"}]
  - translationFields [List<String>] [必填]
    字段描述: 拼接字段 (主围栏数据的字段)
    示例: ["name","regionType"]


接口请求示例:
  {
    "mainFenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "auxiliaryFenceData": [
        {
            "code": "fence_002",
            "name": "区域B",
            "fence": "POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))"
        }
    ],
    "translationFields": [
        "name",
        "regionType"
    ]
}
```
**示例:**
```json
{
    "mainFenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "auxiliaryFenceData": [
        {
            "code": "fence_002",
            "name": "区域B",
            "fence": "POLYGON((116.35 39.95, 116.45 39.95, 116.45 40.05, 116.35 40.05, 116.35 39.95))"
        }
    ],
    "translationFields": [
        "name",
        "regionType"
    ]
}
```

### fence-merge — 围栏合并后的区域请求
```bash
gogeo-cli common-task spatial calculation fence-merge --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_fence_merge_area
请求方式: POST
接口描述: 围栏合并后的区域请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))","regionType":"A"}]
  - mergeField [String] [必填]
    字段描述: 合并字段（面资产的字段）
    示例: regionType
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计字段列表
    示例: [{"field":"population","type":"Sum"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))",
            "regionType": "A"
        }
    ],
    "mergeField": "regionType",
    "aggregationFields": [
        {
            "field": "population",
            "type": "Sum"
        }
    ]
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))",
            "regionType": "A"
        }
    ],
    "mergeField": "regionType",
    "aggregationFields": [
        {
            "field": "population",
            "type": "Sum"
        }
    ]
}
```

### fence-without-point — 不包含点的围栏请求
```bash
gogeo-cli common-task spatial calculation fence-without-point --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_fence_without_point
请求方式: POST
接口描述: 不包含点的围栏请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - buffer [Integer] [必填]
    字段描述: 外扩范围（米）
    示例: 100
  - translationFields [List<String>] [必填]
    字段描述: 拼接字段 (点数据的字段)
    示例: ["name","type"]


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "buffer": 100,
    "translationFields": [
        "name",
        "type"
    ]
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "buffer": 100,
    "translationFields": [
        "name",
        "type"
    ]
}
```

### h3-split-merge — H3 拆合生成请求
```bash
gogeo-cli common-task spatial calculation h3-split-merge --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_h3_split_merge_generate
请求方式: POST
接口描述: H3 拆合生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)","potential":100}]
  - customizeFenceData [List<Map<String, Object>>] [必填]
    字段描述: 自定义围栏数据
    示例: [{"code":"fence_001","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - generateDirection [GenerateDirection] [必填]
    字段描述: 生成方向：bigToSmall-从大到小，smallToBig-从小到大。层级网格分裂/合并生成方向。可选值: bigToSmall=从大到小; smallToBig=从小到大
    示例: bigToSmall
  - potential [String] [必填]
    字段描述: 潜力字段
    示例: potentialValue
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级：city-城市，district-区县，province-省份。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围
    示例: [["340000"],["820000"]]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计字段配置列表
    示例: [{"field":"sales","aggregationType":"Sum"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "potential": "potentialValue",
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ]
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "salesAmount"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "potential": "potentialValue",
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ]
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "salesAmount"
}
```

### line-intersection — 线相交取交点请求
```bash
gogeo-cli common-task spatial calculation line-intersection --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_line_intersection_point
请求方式: POST
接口描述: 线相交取交点请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - lineData [List<Map<String, Object>>] [必填]
    字段描述: 线数据 其中 code 和 line 字段内容必须存在，line 格式 wkt 格式
    示例: [{"code":"line_001","name":"测试线","line":"LINESTRING(116.3 39.9, 116.4 40.0)"}]


接口请求示例:
  {
    "lineData": [
        {
            "code": "l1",
            "name": "测试线",
            "line": "LINESTRING(108.9 34.2, 109.0 34.3)"
        }
    ]
}
```
**示例:**
```json
{
    "lineData": [
        {
            "code": "l1",
            "name": "测试线",
            "line": "LINESTRING(108.9 34.2, 109.0 34.3)"
        }
    ]
}
```

### line-split-fence — 线分割围栏数据处理请求
```bash
gogeo-cli common-task spatial calculation line-split-fence --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_line_split_fence
请求方式: POST
接口描述: 线分割围栏数据处理请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - lineData [List<Map<String, Object>>] [必填]
    字段描述: 线数据列表，其中 code 和 line 字段内容必须存在，line 格式 wkt 格式
    示例: [{"code":"line_001","name":"测试线","line":"LINESTRING(116.3 39.9, 116.4 40.0)"}]
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 面数据列表，其中 code 和 fence 字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]


接口请求示例:
  {
    "lineData": [
        {
            "code": "l1",
            "name": "测试线",
            "line": "LINESTRING(108.9 34.2, 109.0 34.3)"
        }
    ],
    "fenceData": [
        {
            "code": "f1",
            "name": "测试围栏",
            "fence": "POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))"
        }
    ]
}
```
**示例:**
```json
{
    "lineData": [
        {
            "code": "l1",
            "name": "测试线",
            "line": "LINESTRING(108.9 34.2, 109.0 34.3)"
        }
    ],
    "fenceData": [
        {
            "code": "f1",
            "name": "测试围栏",
            "fence": "POLYGON((108.9 34.2, 109.0 34.2, 109.0 34.3, 108.9 34.3, 108.9 34.2))"
        }
    ]
}
```

### point-centroid — 点质心计算
```bash
gogeo-cli common-task spatial calculation point-centroid --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_point_centroid
请求方式: POST
接口描述: 点质心计算


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - partitionType [PartitionType] [必填]
    字段描述: 划分类型。空间划分类型。可选值: hexagon=蜂窝; square=方块
    示例: hexagon
  - sideLength [Integer] [必填]
    字段描述: 边长（最小值 100，最大值 100000）
    示例: 1000
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合统计
    示例: [{"field":"sales","aggregationType":"Avg"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "sideLength": 1000,
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Avg"
        }
    ],
    "field": "sales"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "sideLength": 1000,
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Avg"
        }
    ],
    "field": "sales"
}
```

### point-in-fence — 围栏里的点请求
```bash
gogeo-cli common-task spatial calculation point-in-fence --data '<JSON>'
```
**参数说明:**
`

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_point_inside_fence
请求方式: POST
接口描述: 围栏里的点请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中code 和 point 经纬度字段内容必须存在,point格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - buffer [Integer] [可选]
    字段描述: 外扩范围（米）
    示例: 100
  - oneToOneFlag [Boolean] [必填]
    字段描述: 判定方式。true-单围栏，false-多围栏
    示例: true
  - isAll [Boolean] [必填]
    字段描述: 是否全量。true-是，false-否
    示例: true
  - translationFields [List<String>] [必填]
    字段描述: 拼接字段 (围栏数据的字段)
    示例: ["name","type"]


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "buffer": 100,
    "oneToOneFlag": true,
    "isAll": true,
    "translationFields": [
        "name",
        "type"
    ]
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "buffer": 100,
    "oneToOneFlag": true,
    "isAll": true,
    "translationFields": [
        "name",
        "type"
    ]
}
```

### point-outside-fence — 围栏外的点请求
```bash
gogeo-cli common-task spatial calculation point-outside-fence --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_point_outside_fence
请求方式: POST
接口描述: 围栏外的点请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - buffer [Integer] [必填]
    字段描述: 外扩范围（米）
    示例: 100
  - translationFields [List<String>] [必填]
    字段描述: 拼接字段 (围栏数据的字段)
    示例: ["name","type"]


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "buffer": 100,
    "translationFields": [
        "name",
        "type"
    ]
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "fenceData": [
        {
            "code": "fence_001",
            "name": "区域A",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "buffer": 100,
    "translationFields": [
        "name",
        "type"
    ]
}
```

### scatter-fence — 散点构建面数据请求
```bash
gogeo-cli common-task spatial calculation scatter-fence --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_scatter_points_build_fence
请求方式: POST
接口描述: 散点构建面数据请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 
    示例: [{"field": "salesAmount", "aggregationType": "Sum"}, {"field": "storeCount", "aggregationType": "Count"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum
  - pointData [List<Map<String, Object>>] [可选]
    字段描述: 
    示例: [{"code": "P001", "point": "POINT(116.404 39.915)"}, {"code": "P002", "point": "POINT(116.405 39.916)"}]
  - groupField [String] [可选]
    字段描述: 
    示例: region_code
  - fenceType [FenceType] [可选]
    字段描述: 散点构围栏类型。可选值: 1=凸包; 2=凹包; 3=外切矩形


接口请求示例:
  {
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Sum"
        },
        {
            "field": "storeCount",
            "aggregationType": "Count"
        }
    ],
    "pointData": [
        {
            "code": "P001",
            "point": "POINT(116.404 39.915)"
        },
        {
            "code": "P002",
            "point": "POINT(116.405 39.916)"
        }
    ],
    "groupField": "region_code"
}
```
**示例:**
```json
{
    "aggregationFields": [
        {
            "field": "salesAmount",
            "aggregationType": "Sum"
        },
        {
            "field": "storeCount",
            "aggregationType": "Count"
        }
    ],
    "pointData": [
        {
            "code": "P001",
            "point": "POINT(116.404 39.915)"
        },
        {
            "code": "P002",
            "point": "POINT(116.405 39.916)"
        }
    ],
    "groupField": "region_code"
}
```

### scu-admin — SCU-行政区划生成请求
```bash
gogeo-cli common-task spatial calculation scu-admin --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_scu_admin_division_generate
请求方式: POST
接口描述: SCU-行政区划生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据 其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)","potential":100}]
  - generateDirection [GenerateDirection] [必填]
    字段描述: 生成方向。层级网格分裂/合并生成方向。可选值: bigToSmall=从大到小; smallToBig=从小到大
    示例: bigToSmall
  - potential [String] [必填]
    字段描述: 潜力字段
    示例: potential
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - aggregationFields [List<AggregationField>] [必填]
    字段描述: 聚合统计
    示例: [{"field":"sales","aggregationType":"Sum"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "sales"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "sales"
}
```

### scu-h3 — SCU-H3标准生成请求
```bash
gogeo-cli common-task spatial calculation scu-h3 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_scu_generate_by_h3
请求方式: POST
接口描述: SCU-H3标准生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据，其中 code 和 point 经纬度字段内容必须存在，point 格式为 WKT 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)","potential":100}]
  - customizeFenceData [List<Map<String, Object>>] [必填]
    字段描述: 自定义围栏数据，用于限制生成范围
    示例: [{"code":"fence_001","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计字段配置列表，支持对结果数据进行统计分析
    示例: [{"field":"potential","type":"Sum","alias":"totalPotential"}]
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围，指定行政区划代码列表，例如：[[\
    示例: [["340000"],["820000"],["110000"]]
  - potential [String] [可选]
    字段描述: 潜力字段：资产数据中的字段名称，用于划分计算的依据
    示例: potential
  - generateDirection [GenerateDirection] [必填]
    字段描述: 生成方向：bigToSmall-从大到小，smallToBig-从小到大。层级网格分裂/合并生成方向。可选值: bigToSmall=从大到小; smallToBig=从小到大
    示例: bigToSmall
  - splitValue [Integer] [可选]
    字段描述: 划分值：每个单元的目标潜力值
    示例: 100
  - zoomStart [Integer] [可选]
    字段描述: H3 开始级别：H3网格的起始层级，范围0-11，数值越大网格越精细
    示例: 5
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级：province-省份，city-城市，district-区县。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "aggregationFields": [
        {
            "field": "potential",
            "type": "Sum",
            "alias": "totalPotential"
        }
    ],
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ],
        [
            "110000"
        ]
    ],
    "field": "sales",
    "type": "Sum",
    "alias": "totalSales"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "aggregationFields": [
        {
            "field": "potential",
            "type": "Sum",
            "alias": "totalPotential"
        }
    ],
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ],
        [
            "110000"
        ]
    ],
    "field": "sales",
    "type": "Sum",
    "alias": "totalSales"
}
```

### scu-h3-merge — SCU-H3 合并请求
```bash
gogeo-cli common-task spatial calculation scu-h3-merge --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_scu_h3_merge
请求方式: POST
接口描述: SCU-H3 合并请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 fence 字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - potential [String] [必填]
    字段描述: 潜力值字段
    示例: potentialValue
  - minValue [Integer] [必填]
    字段描述: 潜力区间最小值
    示例: 0
  - maxValue [Integer] [必填]
    字段描述: 潜力区间最大值
    示例: 9999999


接口请求示例:
  {
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "potential": "potentialValue",
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ]
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "salesAmount"
}
```
**示例:**
```json
{
    "pointData": [
        {
            "code": "point_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)",
            "potential": 100
        }
    ],
    "customizeFenceData": [
        {
            "code": "fence_001",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "potential": "potentialValue",
    "effectiveScope": [
        [
            "340000"
        ],
        [
            "820000"
        ]
    ],
    "aggregationFields": [
        {
            "field": "sales",
            "aggregationType": "Sum"
        }
    ],
    "field": "salesAmount"
}
```

### scu-s2 — SCU-S2 标准生成请求
```bash
gogeo-cli common-task spatial calculation scu-s2 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealtimeSpatialCalculationController/realtime_scu_s2_standard_generate
请求方式: POST
接口描述: SCU-S2 标准生成请求


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - pointData [List<Map<String, Object>>] [必填]
    字段描述: 点数据列表，其中 code 和 point 经纬度字段内容必须存在，point 格式 wkt 格式
    示例: [{"code":"point_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - generateDirection [GenerateDirection] [必填]
    字段描述: 生成方向。层级网格分裂/合并生成方向。可选值: bigToSmall=从大到小; smallToBig=从小到大
    示例: bigToSmall
  - potential [String] [必填]
    字段描述: 潜力字段：点数据中的字段
    示例: bigToSmall
  - splitValue [Integer] [必填]
    字段描述: 划分值
  - zoomStart [Integer] [必填]
    字段描述: S2 开始级别
  - boundaryLevel [BoundaryLevel] [必填]
    字段描述: 边界等级。行政边界级别。可选值: province=省份; city=城市; district=区县
    示例: city
  - customizeFenceData [List<Map<String, Object>>] [必填]
    字段描述: 自定义围栏数据列表，其中 code 和 fence 围栏字段内容必须存在，fence 格式 wkt 格式
    示例: [{"code":"fence_002","fence":"POLYGON((116.5 39.8, 116.6 39.8, 116.6 39.9, 116.5 39.9, 116.5 39.8))"}]
  - aggregationFields [List<AggregationField>] [可选]
    字段描述: 聚合统计
  - field [String (inner)] [必填]
    字段描述: 聚合字段：点数据的字段
    示例: salesAmount
  - aggregationType [AggregationType (inner)] [必填]
    字段描述: 聚合类型。聚合函数类型。可选值: Avg=平均值; Min=最小值; Max=最大值; Sum=求和; Count=计数
    示例: Sum
  - effectiveScope [List<List<String>>] [可选]
    字段描述: 自定义生效范围


接口请求示例:
  {
    "pointData": "pointData",
    "generateDirection": "bigToSmall",
    "boundaryLevel": "city",
    "customizeFenceData": "customizeFenceData",
    "aggregationFields": [],
    "effectiveScope": "effectiveScope",
    "field": "field",
    "aggregationType": {}
}
```
**示例:**
```json
{
    "pointData": "pointData",
    "generateDirection": "bigToSmall",
    "boundaryLevel": "city",
    "customizeFenceData": "customizeFenceData",
    "aggregationFields": [],
    "effectiveScope": "effectiveScope",
    "field": "field",
    "aggregationType": {}
}
```

### customer-flow-competition — 客流通 - 商圈竞争烈度分析请求参数
```bash
gogeo-cli common-task thirdparty customer-flow-competition --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_customer_flow_business_district_competition_intensity_analysis
请求方式: POST
接口描述: 客流通 - 商圈竞争烈度分析请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 polygon 字段内容必须存在，polygon 格式 wkt 格式
    示例: [{"code":"fence_001","name":"主场A","polygon":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))","n_mall_id":"comp_001"}]
  - mallIdFieldCode [String] [必填]
    字段描述: 主场服务区 ID 字段
    示例: mall_id
  - competitorMallIdFieldCode [String] [必填]
    字段描述: 竞品服务区 ID 字段
    示例: n_mall_id
  - date [String] [必填]
    字段描述: 日期
    示例: 2024-01-01
  - type [CompetitionType] [必填]
    字段描述: 竞争类型。客流类型分类。可选值: 1=居住; 2=工作; 3=路过
    示例: 1


接口请求示例:
  {
    "fenceData": [
        {
            "code": "fence_001",
            "name": "主场A",
            "polygon": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))",
            "n_mall_id": "comp_001"
        }
    ],
    "mallIdFieldCode": "mall_id",
    "date": "2024-01-01"
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "fence_001",
            "name": "主场A",
            "polygon": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))",
            "n_mall_id": "comp_001"
        }
    ],
    "mallIdFieldCode": "mall_id",
    "date": "2024-01-01"
}
```

### customer-flow-competitors — 客流通 - 竞品门店请求参数
```bash
gogeo-cli common-task thirdparty customer-flow-competitors --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_customer_flow_competitor_stores
请求方式: POST
接口描述: 客流通 - 竞品门店请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 polygon 字段内容必须存在，polygon 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - mallFieldCode [String] [必填]
    字段描述: 商场字段编码
    示例: mall_code


接口请求示例:
  {
    "fenceData": "fenceData",
    "mallFieldCode": "mall_code"
}
```
**示例:**
```json
{
    "fenceData": "fenceData",
    "mallFieldCode": "mall_code"
}
```

### customer-flow-items — 客流通 - 服务项目请求参数
```bash
gogeo-cli common-task thirdparty customer-flow-items --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_customer_flow_service_items
请求方式: POST
接口描述: 客流通 - 服务项目请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - remark [String] [可选]
    字段描述: 任务备注
    示例: 服务项目分析任务


接口请求示例:
  {
    "remark": "服务项目分析任务"
}
```
**示例:**
```json
{
    "remark": "服务项目分析任务"
}
```

### customer-flow-pedestrian — 客流通 - 商圈客流分析请求参数
```bash
gogeo-cli common-task thirdparty customer-flow-pedestrian --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_customer_flow_business_district_pedestrian_flow_analysis
请求方式: POST
接口描述: 客流通 - 商圈客流分析请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 polygon 字段内容必须存在，polygon 格式 wkt 格式
    示例: [{"code":"fence_001","name":"商场A","polygon":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - mallFieldCode [String] [必填]
    字段描述: 商场 ID（mallId）
    示例: mall_001
  - apiParams [List<ApiParams>] [必填]
    字段描述: 聚合字段配置列表
    示例: [{"interfaceCode":"getgridbussinesscircle","date":"2024-01-01","type":["1"],"property":["1"]}]
  - interfaceCode [InterfaceCode (inner)] [必填]
    字段描述: 接口编码。第三方接口标识。可选值: GETGRIDBUSSINESSCIRCLE=栅格客流/人口数查询; GETAOIDEPRESSIONRANK=客流洼地排名查询; GETAOICOMMUNTIYSIZERANK=来源地人口排名查询; GETLOWPASSENGERFLOW=低客流区域人口排名查询; GETGRIDDEPRESSIONDATA=栅格渗透率查询; GETAOIPASSENGERFLOWRANK=客流来源排名查询; GETMALLFLOWANDNUMDATABYMALLID=客流统计; GETGRIDPERAGEPORTRAITS=客流活跃时段; GETLENGTHSOFSTAYDATA=客流停留时长; GETGRIDPERAGEPORTRAITBYMALLIDS=客流到访频次 等19个值
    示例: getgridbussinesscircle
  - date [String (inner)] [必填]
    字段描述: 日期
    示例: 2024-01-01
  - type [List<Type> (inner)] [必填]
    字段描述: 客流类型（仅当 interfaceCode 为 getaoipassengerflowrank、getaoicommuntiysizerank、getaoidepressionrank、getlowpassengerflow 时有效）。客流类型分类。可选值: 1=居住; 2=工作; 3=路过
    示例: 2024-01-01
  - property [List<Property> (inner)] [可选]
    字段描述: 网格人群类型（仅当 interfaceCode 为 getgridbussinesscircle 时有效）。客流指标类型。可选值: 1=客流数量; 2=人口数量


接口请求示例:
  {
    "fenceData": [
        {
            "code": "fence_001",
            "name": "商场A",
            "polygon": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "mallFieldCode": "mall_001",
    "apiParams": [
        {
            "interfaceCode": "getgridbussinesscircle",
            "date": "2024-01-01",
            "type": [
                "1"
            ],
            "property": [
                "1"
            ]
        }
    ],
    "interfaceCode": "getgridbussinesscircle",
    "date": "2024-01-01",
    "type": [
        "1"
    ],
    "property": [
        "1"
    ]
}
```
**示例:**
```json
{
    "fenceData": [
        {
            "code": "fence_001",
            "name": "商场A",
            "polygon": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "mallFieldCode": "mall_001",
    "apiParams": [
        {
            "interfaceCode": "getgridbussinesscircle",
            "date": "2024-01-01",
            "type": [
                "1"
            ],
            "property": [
                "1"
            ]
        }
    ],
    "interfaceCode": "getgridbussinesscircle",
    "date": "2024-01-01",
    "type": [
        "1"
    ],
    "property": [
        "1"
    ]
}
```

### customer-flow-report — 客流通 - 数据报表请求参数
```bash
gogeo-cli common-task thirdparty customer-flow-report --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_customer_flow_data_reports
请求方式: POST
接口描述: 客流通 - 数据报表请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - fenceData [List<Map<String, Object>>] [必填]
    字段描述: 围栏数据 其中 code 和 polygon 字段内容必须存在，polygon 格式 wkt 格式
    示例: [{"code":"fence_001","name":"区域A","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - mallFieldCode [String] [必填]
    字段描述: 商场字段编码（mallId）
    示例: mall_code
  - dataReportInterApiParams [List<DataReportInterApiParams>] [必填]
    字段描述: 数据报表接口参数配置列表
    示例: mall_code
  - dateList [List<String> (inner)] [必填]
    字段描述: 日期列表
    示例: ["2024-01-01", "2024-01-02"]
  - interfaceCode [InterfaceCode (inner)] [必填]
    字段描述: 接口编码。第三方接口标识。可选值: GETGRIDBUSSINESSCIRCLE=栅格客流/人口数查询; GETAOIDEPRESSIONRANK=客流洼地排名查询; GETAOICOMMUNTIYSIZERANK=来源地人口排名查询; GETLOWPASSENGERFLOW=低客流区域人口排名查询; GETGRIDDEPRESSIONDATA=栅格渗透率查询; GETAOIPASSENGERFLOWRANK=客流来源排名查询; GETMALLFLOWANDNUMDATABYMALLID=客流统计; GETGRIDPERAGEPORTRAITS=客流活跃时段; GETLENGTHSOFSTAYDATA=客流停留时长; GETGRIDPERAGEPORTRAITBYMALLIDS=客流到访频次 等19个值
    示例: getmallflowandnumdatabymallId
  - pType [String (inner)] [可选]
    字段描述: 访次数类型（仅当 interfaceCode 为 getgridperageportraitbymallIdS 时有效）
    示例: visitCount


接口请求示例:
  {
    "fenceData": "fenceData",
    "mallFieldCode": "mall_code",
    "dataReportInterApiParams": {
        "dateList": [
            "2024-01-01",
            "2024-01-02"
        ],
        "pType": "visitCount"
    },
    "dateList": [
        "2024-01-01",
        "2024-01-02"
    ],
    "pType": "visitCount"
}
```
**示例:**
```json
{
    "fenceData": "fenceData",
    "mallFieldCode": "mall_code",
    "dataReportInterApiParams": {
        "dateList": [
            "2024-01-01",
            "2024-01-02"
        ],
        "pType": "visitCount"
    },
    "dateList": [
        "2024-01-01",
        "2024-01-02"
    ],
    "pType": "visitCount"
}
```

### lbs-passenger-area — LBS 客流画像面数据请求参数
```bash
gogeo-cli common-task thirdparty lbs-passenger-area --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_lbs_passenger_portrait_area
请求方式: POST
接口描述: LBS 客流画像面数据请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - lbsData [List<Map<String, Object>>] [必填]
    字段描述: LBS 数据面数据列表
    示例: [{"code":"lbs_001","name":"测试区域","fence":"POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"}]
  - translationFields [List<String>] [必填]
    字段描述: 结果冗余字段
    示例: ["field1", "field2"]
  - lbsInterApiParams [List<LbsInterApiParams>] [必填]
    字段描述: 聚合字段配置列表
    示例: [{"interfaceCode":"residentnum","monthAverage":"1","adCode":"110000","month":["2024-01"],"peopleType":["1"],"label":["gender"],"dateType":["workday"],"heatType":["people_flow"]}]
  - interfaceCode [InterfaceCode (inner)] [必填]
    字段描述: 接口类型。第三方接口标识。可选值: GETGRIDBUSSINESSCIRCLE=栅格客流/人口数查询; GETAOIDEPRESSIONRANK=客流洼地排名查询; GETAOICOMMUNTIYSIZERANK=来源地人口排名查询; GETLOWPASSENGERFLOW=低客流区域人口排名查询; GETGRIDDEPRESSIONDATA=栅格渗透率查询; GETAOIPASSENGERFLOWRANK=客流来源排名查询; GETMALLFLOWANDNUMDATABYMALLID=客流统计; GETGRIDPERAGEPORTRAITS=客流活跃时段; GETLENGTHSOFSTAYDATA=客流停留时长; GETGRIDPERAGEPORTRAITBYMALLIDS=客流到访频次 等19个值
    示例: residentnum
  - monthAverage [MonthAverage (inner)] [可选]
    字段描述: 回溯类型（仅当 interfaceCode 为 residentnum、flownum 时有效）。月份平均周期。可选值: 1=当月; 3=3个月; 6=6个月; 12=12个月
    示例: 1
  - adCode [String (inner)] [必填]
    字段描述: 行政区划编码
    示例: 110000
  - month [List<String> (inner)] [必填]
    字段描述: 当前月（多选）
    示例: ["2024-01", "2024-02"]
  - peopleType [List<PeopleType> (inner)] [可选]
    字段描述: 常驻人口类型（仅当 interfaceCode 为 residentnum、residentuserprofile 时有效）。人口类型。可选值: 1=工作人口; 2=居住人口; 3=工作或居住
    示例: [...]
  - label [List<Label> (inner)] [可选]
    字段描述: 标签列表（仅当 interfaceCode 为 residentuserprofile、flowuserprofile 时有效）。用户画像标签编码。可选值: 101010=性别; 101012=年龄(分段); 101015=学历; 101112=婚否v2; 1041=子女年龄v2; 1052=婚育状态; 1013=人生阶段; 1037=职业细分; 1038=所在行业; 990043=职住距离(分段) 等35个值
    示例: [...]
  - dateType [List<DateType> (inner)] [可选]
    字段描述: 日期类型（仅当 interfaceCode 为 flownum、flowuserprofile 时有效）。日期类型。可选值: 1=月日平均; 2=工作日平均; 3=节假日平均; workday=工作日; weekend=周末; holiday=节假日
    示例: [...]
  - heatType [List<HeatType> (inner)] [可选]
    字段描述: 热力类型（仅当 interfaceCode 为 locationpoint 时有效）。热力图类型。可选值: flow_workday=工作日客流; flow_holiday=节假日客流; resident_home=居住; resident_work=工作; people_flow=人流热力; vehicle_flow=车流热力
    示例: [...]


接口请求示例:
  {
    "lbsData": [
        {
            "code": "lbs_001",
            "name": "测试区域",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "translationFields": [
        "field1",
        "field2"
    ],
    "lbsInterApiParams": [
        {
            "interfaceCode": "residentnum",
            "monthAverage": "1",
            "adCode": "110000",
            "month": [
                "2024-01"
            ],
            "peopleType": [
                "1"
            ],
            "label": [
                "gender"
            ],
            "dateType": [
                "workday"
            ],
            "heatType": [
                "people_flow"
            ]
        }
    ],
    "adCode": 110000,
    "month": [
        "2024-01",
        "2024-02"
    ]
}
```
**示例:**
```json
{
    "lbsData": [
        {
            "code": "lbs_001",
            "name": "测试区域",
            "fence": "POLYGON((116.3 39.9, 116.4 39.9, 116.4 40.0, 116.3 40.0, 116.3 39.9))"
        }
    ],
    "translationFields": [
        "field1",
        "field2"
    ],
    "lbsInterApiParams": [
        {
            "interfaceCode": "residentnum",
            "monthAverage": "1",
            "adCode": "110000",
            "month": [
                "2024-01"
            ],
            "peopleType": [
                "1"
            ],
            "label": [
                "gender"
            ],
            "dateType": [
                "workday"
            ],
            "heatType": [
                "people_flow"
            ]
        }
    ],
    "adCode": 110000,
    "month": [
        "2024-01",
        "2024-02"
    ]
}
```

### lbs-passenger-point — LBS 客流画像点数据请求参数
```bash
gogeo-cli common-task thirdparty lbs-passenger-point --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_lbs_passenger_portrait_point
请求方式: POST
接口描述: LBS 客流画像点数据请求参数


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - lbsData [List<Map<String, Object>>] [必填]
    字段描述: LBS 数据点数据列表
    示例: [{"code":"lbs_001","name":"测试点","point":"POINT(116.3 39.9)"}]
  - radius [String] [必填]
    字段描述: 半径 (米)
    示例: 1000
  - translationFields [List<String>] [必填]
    字段描述: 结果冗余字段
    示例: ["field1", "field2"]
  - lbsInterApiParams [List<LbsInterApiParams>] [必填]
    字段描述: 聚合字段配置列表
    示例: [{"interfaceCode":"residentnum","monthAverage":"1","adCode":"110000","month":["2024-01"],"peopleType":["1"],"label":["gender"],"dateType":["workday"],"heatType":["people_flow"]}]
  - interfaceCode [InterfaceCode (inner)] [必填]
    字段描述: 接口类型。第三方接口标识。可选值: GETGRIDBUSSINESSCIRCLE=栅格客流/人口数查询; GETAOIDEPRESSIONRANK=客流洼地排名查询; GETAOICOMMUNTIYSIZERANK=来源地人口排名查询; GETLOWPASSENGERFLOW=低客流区域人口排名查询; GETGRIDDEPRESSIONDATA=栅格渗透率查询; GETAOIPASSENGERFLOWRANK=客流来源排名查询; GETMALLFLOWANDNUMDATABYMALLID=客流统计; GETGRIDPERAGEPORTRAITS=客流活跃时段; GETLENGTHSOFSTAYDATA=客流停留时长; GETGRIDPERAGEPORTRAITBYMALLIDS=客流到访频次 等19个值
    示例: residentnum
  - monthAverage [MonthAverage (inner)] [可选]
    字段描述: 回溯类型（仅当 interfaceCode 为 residentnum、flownum 时有效）。月份平均周期。可选值: 1=当月; 3=3个月; 6=6个月; 12=12个月
    示例: 1
  - adCode [String (inner)] [必填]
    字段描述: 行政区划编码
    示例: 110000
  - month [List<String> (inner)] [必填]
    字段描述: 当前月（多选）
    示例: ["2024-01", "2024-02"]
  - peopleType [List<PeopleType> (inner)] [可选]
    字段描述: 常驻人口类型（仅当 interfaceCode 为 residentnum、residentuserprofile 时有效）。人口类型。可选值: 1=工作人口; 2=居住人口; 3=工作或居住
    示例: [...]
  - label [List<Label> (inner)] [可选]
    字段描述: 标签列表（仅当 interfaceCode 为 residentuserprofile、flowuserprofile 时有效）。用户画像标签编码。可选值: 101010=性别; 101012=年龄(分段); 101015=学历; 101112=婚否v2; 1041=子女年龄v2; 1052=婚育状态; 1013=人生阶段; 1037=职业细分; 1038=所在行业; 990043=职住距离(分段) 等35个值
    示例: [...]
  - dateType [List<DateType> (inner)] [可选]
    字段描述: 日期类型（仅当 interfaceCode 为 flownum、flowuserprofile 时有效）。日期类型。可选值: 1=月日平均; 2=工作日平均; 3=节假日平均; workday=工作日; weekend=周末; holiday=节假日
    示例: [...]
  - heatType [List<HeatType> (inner)] [可选]
    字段描述: 热力类型（仅当 interfaceCode 为 locationpoint 时有效）。热力图类型。可选值: flow_workday=工作日客流; flow_holiday=节假日客流; resident_home=居住; resident_work=工作; people_flow=人流热力; vehicle_flow=车流热力
    示例: [...]


接口请求示例:
  {
    "lbsData": [
        {
            "code": "lbs_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "radius": 1000,
    "translationFields": [
        "field1",
        "field2"
    ],
    "lbsInterApiParams": [
        {
            "interfaceCode": "residentnum",
            "monthAverage": "1",
            "adCode": "110000",
            "month": [
                "2024-01"
            ],
            "peopleType": [
                "1"
            ],
            "label": [
                "gender"
            ],
            "dateType": [
                "workday"
            ],
            "heatType": [
                "people_flow"
            ]
        }
    ],
    "adCode": 110000,
    "month": [
        "2024-01",
        "2024-02"
    ]
}
```
**示例:**
```json
{
    "lbsData": [
        {
            "code": "lbs_001",
            "name": "测试点",
            "point": "POINT(116.3 39.9)"
        }
    ],
    "radius": 1000,
    "translationFields": [
        "field1",
        "field2"
    ],
    "lbsInterApiParams": [
        {
            "interfaceCode": "residentnum",
            "monthAverage": "1",
            "adCode": "110000",
            "month": [
                "2024-01"
            ],
            "peopleType": [
                "1"
            ],
            "label": [
                "gender"
            ],
            "dateType": [
                "workday"
            ],
            "heatType": [
                "people_flow"
            ]
        }
    ],
    "adCode": 110000,
    "month": [
        "2024-01",
        "2024-02"
    ]
}
```

### poi-match — poi匹配
```bash
gogeo-cli common-task thirdparty poi-match --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_poi_match_handling
请求方式: POST
接口描述: poi匹配


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - customerData [CustomerData] [必填]
    字段描述: 客资数据
    示例: {"data":[{"code":"001","name":"XX门店"}],"name":"name","address":"address"}
  - data [List<Map<String, Object>> (inner)] [必填]
    字段描述: 客资数据，其中 code 必须存在，如果选了规则经纬点 point 需要传 point 为 wkt 格式
    示例: [{"code":"001","name":"XX门店"}]
  - name [String (inner)] [必填]
    字段描述: 名称：资产数据中代表名称的字段
    示例: name
  - address [String (inner)] [可选]
    字段描述: 地址：资产数据中代表地址的字段
    示例: address
  - policyCode [PolicyCode] [必填]
    字段描述: 处理策略取值枚举（输入汉字时需根据汉字内容映射为编码）。可选值: 30003=名称-包含类目; 30004=经纬度-包含类目; 30005=名称-剔除类目; 30006=经纬度-剔除类目; 30004_1=名称+地址+经纬度-包含类目; 30006_1=名称+地址+经纬度-剔除类目
    示例: 30003
  - policyConfig [List<Category>] [可选]
    字段描述: 类目选择，例如格式 [{"name": "美食", "subCategories": ["西餐", "巴西菜"]}]
    示例: [{"name":"美食","subCategories":["西餐","巴西菜"]}]
  - name [String (inner)] [可选]
    字段描述: 类目名称，非必填
    示例: 美食
  - subCategories [List<String> (inner)] [可选]
    字段描述: 子类目列表
    示例: ["西餐","巴西菜"]


接口请求示例:
  {
    "customerData": {
        "data": [
            {
                "code": "001",
                "name": "XX门店"
            }
        ],
        "name": "name",
        "address": "address"
    },
    "policyCode": "30003",
    "policyConfig": [
        {
            "name": "美食",
            "subCategories": [
                "西餐",
                "巴西菜"
            ]
        }
    ]
}
```
**示例:**
```json
{
    "customerData": {
        "data": [
            {
                "code": "001",
                "name": "XX门店"
            }
        ],
        "name": "name",
        "address": "address"
    },
    "policyCode": "30003",
    "policyConfig": [
        {
            "name": "美食",
            "subCategories": [
                "西餐",
                "巴西菜"
            ]
        }
    ]
}
```

### tx-poi-match-v2 — 腾讯 POI 匹配 V2
```bash
gogeo-cli common-task thirdparty tx-poi-match-v2 --data '<JSON>'
```
**参数说明:**
```

接口: TaskPipelineRealTimeThirdPartyServiceController/realtime_tx_poi_match_v2
请求方式: POST
接口描述: 腾讯 POI 匹配 V2


返回参数:
  - code [String]
    字段描述: 返回码，200表示成功
  - message [String]
    字段描述: 提示信息
  - data.dataList [Array<Map<String,Object>>]
    字段描述: 模型数据集合
  - data.fieldInfoList [Array<FieldInfo>]
    字段描述: 模型返回字段的集合
  - data.fieldInfoList[].filedCode [String]
    字段描述: 字段编码
  - data.fieldInfoList[].filedName [String]
    字段描述: 字段描述


参数:
  - customerData [List<Map<String, Object>>] [必填]
    字段描述: 客户数据列表，其中 code 和 name/province/city/district/address/poiPoint 字段根据关联方式必填
    示例: [{"code":"001","name":"XX门店","province":"北京市","city":"北京市","district":"朝阳区","address":"XX路XX号"}]
  - policyCode [PolicyCode] [必填]
    字段描述: 关联方式枚举：可选值: 30003=名称+地址-包含类目; 30004=名称+经纬度-包含类目; 30004_1=名称+地址+经纬度-包含类目; 30005=名称+地址-剔除类目; 30006=名称+经纬度-剔除类目; 30006_1=名称+地址+经纬度-剔除类目
    示例: 30003
  - mode [Mode] [可选]
    字段描述: 关联模式。POI匹配算法模式。可选值: cluster=cluster模式(精确度更高); link=link模式(召回率更高)
    示例: cluster
  - policyConfig [String] [可选]
    字段描述: 类目选择
    示例: 无
  - name [String] [必填]
    字段描述: 名称字段
    示例: name
  - province [String] [可选]
    字段描述: 省字段
    示例: province
  - city [String] [可选]
    字段描述: 市字段
    示例: city
  - district [String] [可选]
    字段描述: 区字段
    示例: district
  - address [String] [可选]
    字段描述: 地址字段（关联方式为 30003,30005,30004_1,30006_1 时必填）
    示例: address
  - poiPoint [String] [可选]
    字段描述: 经纬度字段
    示例: poiPoint


接口请求示例:
  {
    "customerData": [
        {
            "code": "001",
            "name": "XX门店",
            "province": "北京市",
            "city": "北京市",
            "district": "朝阳区",
            "address": "XX路XX号"
        }
    ],
    "policyCode": "30003",
    "policyConfig": "美食",
    "name": "name",
    "province": "province",
    "city": "city",
    "district": "district",
    "address": "address",
    "poiPoint": "poiPoint"
}
```
**示例:**
```json
{
    "customerData": [
        {
            "code": "001",
            "name": "XX门店",
            "province": "北京市",
            "city": "北京市",
            "district": "朝阳区",
            "address": "XX路XX号"
        }
    ],
    "policyCode": "30003",
    "policyConfig": "美食",
    "name": "name",
    "province": "province",
    "city": "city",
    "district": "district",
    "address": "address",
    "poiPoint": "poiPoint"
}
```
