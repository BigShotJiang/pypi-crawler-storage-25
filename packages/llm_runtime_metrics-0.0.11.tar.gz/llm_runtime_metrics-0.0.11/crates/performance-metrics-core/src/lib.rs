mod compaction;
mod metrics;
mod request_trace;

pub use compaction::{
    AnonymizeConfig, ParquetCompactResult, S3ParquetCompactConfig, anonymize_parquet_file,
    compact_s3_parquet_to_local, compact_s3_parquet_to_local_async,
};
pub use metrics::{MetricKind, MetricSeriesSnapshot, MetricSnapshot};
pub use request_trace::{
    FileFormat, HashBytes, RequestFeatures, RequestMetricsFactory, RequestMetricsRequest,
    RequestMetricsSnapshot, RequestMetricsTotalsSnapshot,
};

#[doc(hidden)]
pub mod __private {
    pub use crate::metrics::{
        DistributionMetricHandle, MetricLabels, PerformanceMetricsRegistry, RateMetricHandle,
        RatioMetricHandle,
    };
    pub use crate::request_trace::{
        DEFAULT_BLOCK_SIZE, DEFAULT_LOCAL_OUTPUT_DIR, DEFAULT_REQUEST_LOG_BATCH_SIZE,
        DEFAULT_REQUEST_LOG_QUEUE_CAPACITY, FileFormat, RequestLogEntry, RequestMetricsOptions,
        RequestTrace, RequestTraceFactory, RequestTraceOptions, S3SinkConfig,
    };
}
