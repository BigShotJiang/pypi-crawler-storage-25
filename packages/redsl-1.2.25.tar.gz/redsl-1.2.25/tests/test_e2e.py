"""End-to-end tests for ReDSL on real projects without mocks."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
from click.testing import CliRunner

import redsl.cli as cli_module

TEST_PROJECT = Path(__file__).parent.parent / "test_sample_project"
pytestmark = [pytest.mark.slow, pytest.mark.e2e]


@pytest.fixture
def test_project() -> Path:
    """Return path to test_sample_project."""
    if not TEST_PROJECT.exists():
        pytest.skip(f"Test project not found at {TEST_PROJECT}")
    return TEST_PROJECT


@pytest.fixture
def runner() -> CliRunner:
    """Return Click runner for CLI testing."""
    return CliRunner()


# ===========================================================================
# CLI Refactor E2E Tests
# ===========================================================================

class TestCliRefactorE2E:
    """End-to-end tests for CLI refactor on real projects."""

    def test_refactor_dry_run_on_test_project(self, runner: CliRunner, test_project: Path) -> None:
        """Test that refactor dry-run works on real project without mocks."""
        result = runner.invoke(
            cli_module.cli,
            ["refactor", str(test_project), "--max-actions", "3", "--dry-run"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        # Should contain some output about analysis
        assert "analysis" in result.output.lower() or "refactor" in result.output.lower()

    def test_refactor_plan_yaml_generation(self, runner: CliRunner, test_project: Path) -> None:
        """Test that refactor generates plan YAML in dry-run mode."""
        result = runner.invoke(
            cli_module.cli,
            ["refactor", str(test_project), "--max-actions", "3", "--dry-run"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0
        # Plan YAML should be generated in project directory
        plan_file = test_project / "refactor_plan.yaml"
        # Note: This might not exist in dry-run mode, so we just check CLI doesn't crash
        assert result.exit_code == 0

    def test_refactor_with_regix_validation(self, runner: CliRunner, test_project: Path) -> None:
        """Test that refactor with regix validation works on real project."""
        # Check if regix is available
        try:
            subprocess.run(["regix", "--help"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            pytest.skip("regix not available")

        # Initialize git repo if not present
        if not (test_project / ".git").exists():
            subprocess.run(["git", "init"], cwd=str(test_project), capture_output=True, check=True)
            subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "config", "user.name", "Test"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "add", "-A"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "commit", "-m", "initial"], cwd=str(test_project), capture_output=True)

        result = runner.invoke(
            cli_module.cli,
            ["refactor", str(test_project), "--max-actions", "2", "--validate-regix", "--dry-run"],
            catch_exceptions=False,
        )
        # Should not crash even if regix validation runs
        assert result.exit_code == 0, f"Refactor with regix failed: {result.output}"


# ===========================================================================
# CLI Awareness E2E Tests
# ===========================================================================

class TestCliAwarenessE2E:
    """End-to-end tests for CLI awareness commands on real projects."""

    def test_history_command_on_test_project(self, runner: CliRunner, test_project: Path) -> None:
        """Test that history command works on real project."""
        # Initialize git repo if not present
        if not (test_project / ".git").exists():
            subprocess.run(["git", "init"], cwd=str(test_project), capture_output=True, check=True)
            subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "config", "user.name", "Test"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "add", "-A"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "commit", "-m", "initial"], cwd=str(test_project), capture_output=True)

        result = runner.invoke(
            cli_module.cli,
            ["history", "--project", str(test_project), "--depth", "3"],
            catch_exceptions=False,
        )
        # History command should not crash (may return empty if no history)
        assert result.exit_code == 0, f"History failed: {result.output}"

    def test_ecosystem_command_on_workspace(self, runner: CliRunner) -> None:
        """Test that ecosystem command works on workspace."""
        workspace = Path(__file__).parent.parent
        result = runner.invoke(
            cli_module.cli,
            ["ecosystem", "--root", str(workspace)],
            catch_exceptions=False,
        )
        # Should not crash even if no projects found
        assert result.exit_code == 0, f"Ecosystem failed: {result.output}"


# ===========================================================================
# CLI Scan E2E Tests
# ===========================================================================

class TestCliScanE2E:
    """End-to-end tests for CLI scan command on real directories."""

    def test_scan_command_on_workspace(self, runner: CliRunner) -> None:
        """Test that scan command works on workspace."""
        workspace = Path(__file__).parent.parent
        result = runner.invoke(
            cli_module.cli,
            ["scan", str(workspace), "--quiet"],
            catch_exceptions=False,
        )
        # Should not crash
        assert result.exit_code == 0, f"Scan failed: {result.output}"


# ===========================================================================
# Batch Processing E2E Tests
# ===========================================================================

class TestBatchE2E:
    """End-to-end tests for batch processing on real projects."""

    def test_batch_pyqual_run_on_test_project(self, runner: CliRunner, test_project: Path) -> None:
        """Test that batch pyqual-run works on real project."""
        # Initialize git repo if not present
        if not (test_project / ".git").exists():
            subprocess.run(["git", "init"], cwd=str(test_project), capture_output=True, check=True)
            subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "config", "user.name", "Test"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "add", "-A"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "commit", "-m", "initial"], cwd=str(test_project), capture_output=True)

        result = runner.invoke(
            cli_module.cli,
            ["batch", "pyqual-run", str(test_project), "--dry-run"],
            catch_exceptions=False,
        )
        # Should not crash
        assert result.exit_code == 0, f"Batch pyqual-run failed: {result.output}"


# ===========================================================================
# API E2E Tests
# ===========================================================================

class TestApiE2E:
    """End-to-end tests for API endpoints."""

    def test_refactor_endpoint_post(self) -> None:
        """Test that /refactor endpoint accepts POST requests."""
        from fastapi.testclient import TestClient
        from redsl.api import create_app

        client = TestClient(create_app())
        response = client.post(
            "/refactor",
            json={"project_path": str(TEST_PROJECT), "max_actions": 2, "dry_run": True},
        )
        # Should return 200 or at least not crash
        assert response.status_code in [200, 422]  # 422 if validation fails


# ===========================================================================
# Autonomy PR Workflow E2E Tests
# ===========================================================================

class TestAutonomyPRE2E:
    """End-to-end tests for autonomy PR workflow."""

    def test_quality_gate_workflow_on_test_project(self, test_project: Path) -> None:
        """Test that quality gate workflow works on real project."""
        from redsl.autonomy.quality_gate import run_quality_gate

        # Initialize git repo if not present
        if not (test_project / ".git").exists():
            subprocess.run(["git", "init"], cwd=str(test_project), capture_output=True, check=True)
            subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "config", "user.name", "Test"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "add", "-A"], cwd=str(test_project), capture_output=True)
            subprocess.run(["git", "commit", "-m", "initial"], cwd=str(test_project), capture_output=True)

        # Run quality gate
        verdict = run_quality_gate(test_project)
        assert verdict is not None
        # Gate should pass on clean test project
        assert verdict.passed or len(verdict.violations) == 0
