<div align="center">
    <picture>
        <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/lov3b/trafikverket-client/master/assets/logo-dark.svg" />
        <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/lov3b/trafikverket-client/master/assets/logo-light.svg" />
        <img src="https://raw.githubusercontent.com/lov3b/trafikverket-client/master/assets/logo-light.svg" alt="icon" height=250 />
    </picture>
</div>

# Trafikverket Client

![GitHub top language](https://img.shields.io/github/languages/top/lov3b/trafikverket-client) 
![PyPI - Version](https://img.shields.io/pypi/v/trafikverket-client)
![GitHub License](https://img.shields.io/github/license/lov3b/trafikverket-client)

En inofficiel klient för Trafikverkets webbapi.
För närvarande stöds endast [fp.trafikverket.se](https://fp.trafikverket.se),
men jag är öppen för att lägga till fler subsidor och så vidare.

## Kom igång

Börja med att installera paketet.
Följande installerar klienten med stöd för att rendrera qr-koden till terminalen.

```bash
pip3 install "trafikverket-client[qr]"
```

Du vill förmodligen ta en kik under [exempel](/examples) för hur biblioteket kan användas.


## Beroenden

Projektet använder [pydantic](https://github.com/pydantic/pydantic) för att validera och definera data från Trafikverket och [aiohttp](https://github.com/aio-libs/aiohttp) som snabb och effektiv HTTP-klient.

## Vägkarta

- [x] Logga in med BankID
  - [x] Logga in med auto-start-token ("öppna på samma enhet")
  - [x] Logga in med QR-kod
- [x] Se tider tillgängliga för examination
- [x] Se bokade tider
- [x] Se behörighet
- [ ] Boka en examination


## Juridiskt

Detta projekt är ett inofficiellt klientbibliotek och har ingen koppling till, är inte godkänt av och sponsras inte av Trafikverket eller BankID.

"Trafikverket" och "BankID" är varumärken som tillhör sina respektive innehavare. Projektet tillhandahålls för interoperabilitet, utbildningssyften och personligt bruk.

Du ansvarar själv för att användningen av programvaran följer tillämpliga lagar, regler och eventuella användarvillkor för de tjänster som används.

Programvaran tillhandahålls i befintligt skick, utan några uttryckliga eller underförstådda garantier. Användning sker på egen risk.
