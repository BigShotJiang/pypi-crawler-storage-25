"""quartobot: citation resolution and manuscript-as-software CI for Quarto."""

from __future__ import annotations

__version__ = "0.3.0"
__all__ = ["__version__"]
