# tracine-convo

Behavioral analytics CLI for AI coding sessions.

> This is a placeholder release. The full package is coming soon.
>
> See [tracinehq/tracine-convo](https://github.com/tracinehq/tracine-convo) for details.
