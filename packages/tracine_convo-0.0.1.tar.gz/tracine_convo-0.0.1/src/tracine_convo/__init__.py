"""Behavioral analytics CLI for AI coding sessions."""

__version__ = "0.0.1"
