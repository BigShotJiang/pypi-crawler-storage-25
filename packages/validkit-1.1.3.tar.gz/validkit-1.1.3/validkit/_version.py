"""Single source of truth for the SDK version."""

__version__ = "1.1.3"
