"""Initializes the management module."""
