#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
import traceback

from aps.ai.beamline_controller.initialization.beamline_controller_configuration import BeamlineControllerConfiguration
from aps.beamline_driver.motion_management.facade import MotorsInfo
from aps.common.reflection import instance_for_name, get_class_name_and_module
from aps.common.data_structures import DictionaryWrapper
from aps.common.initializer import IniFacade

from aps.ai.beamline_controller.common.legacy_keys import Keys
from aps.beamline_driver.beam_management.beam_manager_factory import initialize_beam_manager_factory
from aps.beamline_driver.motion_management.motion_manager_factory import initialize_motion_manager_factory
from aps.ai.beamline_controller.agent.optimization.hypervolume_manager_factory import initialize_hypervolume_manager_factory
from aps.ai.beamline_controller.agent.optimization.optimizer_factory import initialize_optimizer_factory
from aps.ai.beamline_controller.agent.machine_learning.neural_networks.neural_network_manager_factory import initialize_neural_network_manager_factory

class WorkingDirectoryDecorator:
    def _inspect_working_directory(self, **kwargs):
        working_directory = kwargs.get("working_directory", None)

        if not working_directory is None:
            if os.path.exists(working_directory): os.chdir(working_directory)
            else: raise ValueError(f"working directory {working_directory} doesn't exist")

class BasicInitializerDecorator:
    def _initialize_beamline_controller(self, ini : IniFacade, optical_system_id : str):
        configuration = BeamlineControllerConfiguration(ini, optical_system_id)

        platforms          = configuration.driver_configuration.platforms
        beam_manager_types = configuration.driver_configuration.beam_manager_types

        motion_manager_instances = {}
        beam_manager_instances = {}
        available_beam_managers  = {platform: {beam_manager_type: [] for beam_manager_type in beam_manager_types} for platform in platforms}
        motion_manager_json_file  = configuration.driver_configuration.motion_manager_configuration.get("json_file",
                                                                                                        MotorsInfo.default_json_file_name(optical_system_id=optical_system_id))
        if not os.path.exists(motion_manager_json_file): raise ValueError(f"Motion manager json file {motion_manager_json_file} doesn't exist")

        for platform in platforms:
            motion_manager_args              = configuration.driver_configuration.motion_manager_configuration["arguments"].get(platform, {})
            motion_manager_args["json_file"] = motion_manager_json_file

            if platform != Keys.Platforms.DigitalTwin: # D.T. Motion Manager is inside the Beam Manager
                # MOTION MANAGER
                motion_manager_file = configuration.driver_configuration.motion_manager_configuration["initialization"].get(platform, None)

                if not motion_manager_file is None:
                    motion_manager_class, motion_manager_module = get_class_name_and_module(motion_manager_file, raise_exception=False)

                    if not motion_manager_class is None:
                        try:
                            motion_manager = instance_for_name(module_name=motion_manager_module,
                                                               class_name=motion_manager_class,
                                                               **motion_manager_args)
                            motion_manager_instances[Keys.compose_manager_key(optical_system_id=optical_system_id,
                                                                              platform=platform,
                                                                              manager_key=Keys.Managers.MotionManager)] = motion_manager
                        except Exception as e:
                            print("Failed to load Beamline motion manager: " + str(e))
                            traceback.print_exc()

            # BEAM MANAGERS & DIGITAL TWIN
            for beam_manager_type in beam_manager_types:  # Beam Profile, Wavefront Analysis, etc.
                # for each platform and type here the list of supported beam managers

                beam_manager_ids = configuration.driver_configuration.beam_manager_configuration[beam_manager_type].get("beam_manager_ids", [])

                for beam_manager_id in beam_manager_ids:  # Camera, Scan, etc..
                    beam_manager_configuration = configuration.driver_configuration.beam_manager_configuration[beam_manager_type]

                    beam_manager_file = beam_manager_configuration["initialization"][platform].get(beam_manager_id, None)

                    if not beam_manager_file is None:
                        beam_manager_args = beam_manager_configuration["arguments"][platform].get(beam_manager_id, {})
                        beam_manager_args["beam_manager_id"] = f"{beam_manager_type}-{beam_manager_id}"

                        beam_manager_class, beam_manager_module = get_class_name_and_module(beam_manager_file, raise_exception=False)

                        if not beam_manager_class is None:
                            if platform != Keys.Platforms.DigitalTwin:
                                try:
                                    beam_manager = instance_for_name(module_name=beam_manager_module,
                                                                     class_name=beam_manager_class,
                                                                     **beam_manager_args)
                                    beam_manager_instances[Keys.compose_manager_key(optical_system_id=optical_system_id,
                                                                                    platform=platform,
                                                                                    beam_manager_type=beam_manager_type,
                                                                                    beam_manager_id=beam_manager_id,
                                                                                    manager_key=Keys.Managers.BeamManager)] = beam_manager
                                    available_beam_managers[platform][beam_manager_type].append(beam_manager_id)
                                except Exception as e:
                                    print(f"Failed to load Beamline beam profile manager {beam_manager_id}: " + str(e))
                            else:
                                digital_twin_args = {}
                                digital_twin_args.update(beam_manager_args)
                                digital_twin_args.update(motion_manager_args)

                                try:
                                    digital_twin = instance_for_name(module_name=beam_manager_module,
                                                                     class_name=beam_manager_class,
                                                                     digital_twin_init_parameters=DictionaryWrapper(**digital_twin_args))
                                    motion_manager_instances[Keys.compose_manager_key(optical_system_id=optical_system_id,
                                                                                      platform=platform,
                                                                                      beam_manager_type=beam_manager_type,
                                                                                      beam_manager_id=beam_manager_id,
                                                                                      manager_key=Keys.Managers.MotionManager)] = digital_twin
                                    beam_manager_instances[Keys.compose_manager_key(optical_system_id=optical_system_id,
                                                                                    platform=platform,
                                                                                    beam_manager_type=beam_manager_type,
                                                                                    beam_manager_id=beam_manager_id,
                                                                                    manager_key=Keys.Managers.BeamManager)] = digital_twin
                                    available_beam_managers[platform][beam_manager_type].append(beam_manager_id)
                                except Exception as e:
                                    print(f"Failed to load Digital Twin beam profile manager {beam_manager_id}: " + str(e))

        # Optimization Initialization:
        optimization_configuration = configuration.ai_configuration.optimization_configuration

        optimizer_types = optimization_configuration["optimizer_types"]
        optimizer_classes = {}
        hypervolume_manager_classes = {}

        for optimizer_type in optimizer_types:
            optimizer_names = optimization_configuration[optimizer_type]["names"]

            for optimizer_name in optimizer_names:
                optimizer_class = optimization_configuration[optimizer_type][optimizer_name]["initialization"].get("optimizer", None)

                if not optimizer_class is None:
                    optimizer_classes[f"{optimizer_type}-{optimizer_name}"] = optimizer_class

                for beam_manager_type in beam_manager_types:
                    hypervolume_manager_class = optimization_configuration[optimizer_type][optimizer_name]["initialization"]["hypervolume_manager"].get(beam_manager_type, None)

                    if not hypervolume_manager_class is None:
                        hypervolume_manager_classes[f"{optimizer_type}-{optimizer_name}-{beam_manager_type}"] = hypervolume_manager_class

        # NNs Initialization
        neural_network_configuration = configuration.ai_configuration.neural_network_configuration

        neural_network_types           = neural_network_configuration["neural_network_types"]
        neural_network_manager_file    = neural_network_configuration["initialization"]["neural_network_manager"]
        neural_network_manager_classes = {f"{neural_network_type}": neural_network_manager_file for neural_network_type in neural_network_types}

        initialize_motion_manager_factory(classes={}, instances=motion_manager_instances)
        initialize_beam_manager_factory(classes={}, instances=beam_manager_instances)
        initialize_optimizer_factory(classes=optimizer_classes)
        initialize_hypervolume_manager_factory(classes=hypervolume_manager_classes)
        initialize_neural_network_manager_factory(classes=neural_network_manager_classes)

        return available_beam_managers, configuration


