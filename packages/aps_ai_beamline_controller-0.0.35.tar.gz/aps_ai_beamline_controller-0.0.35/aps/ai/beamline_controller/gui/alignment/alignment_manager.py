#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import sys

from AnyQt.QtCore import pyqtSignal

from aps.ai.beamline_controller.agent.optimization.facade import OptimizationResultItem
from aps.ai.beamline_controller.initialization.beamline_controller_configuration import BeamlineControllerConfiguration

from aps.common.initializer import get_registered_ini_instance
from aps.common.scripts.script_data import ScriptData
from aps.common.widgets.context_widget import PlottingProperties, DefaultMainWindow
from aps.common.plotter import get_registered_plotter_instance

from aps.ai.beamline_controller.execution.execution_manager import QtExecutionManager
from aps.ai.beamline_controller.gui.alignment.alignment_manager_widget import AlignmentManagerWidget
from aps.ai.beamline_controller.gui.alignment.alignement_manager_initialization_parameters import (generate_initialization_parameters_from_ini as alignement_generate_initialization_parameters_from_ini,
                                                                                                   set_ini_from_initialization_parameters as alignement_set_ini_from_initialization_parameters)

from aps.ai.beamline_controller.gui.configuration.configuration_editor import APPLICATION_NAME as CONFIGURATION_APPLICATION_NAME, SHOW_MAIN as CONFIGURATION_SHOW_MAIN
from aps.ai.beamline_controller.gui.configuration.configuration_editor_initialization_parameters import (generate_initialization_parameters_from_ini as configuration_generate_initialization_parameters_from_ini,
                                                                                                         set_ini_from_initialization_parameters as configuration_set_ini_from_initialization_parameters)
from aps.ai.beamline_controller.gui.configuration.configuration_editor_widget import ConfigurationEditorWidget

APPLICATION_NAME = "Alignement Manager"
SHOW_MAIN        = APPLICATION_NAME + ": Main"

class IAlignmentManager():
    def show_alignment_manager(self, plotting_properties=PlottingProperties(), **kwargs): raise NotImplementedError()

def create_alignment_manager(working_directory, optical_system_id, log_stream_widget=None, **kwargs):
    return _AlignmentManager(working_directory=working_directory,
                             optical_system_id=optical_system_id,
                             log_stream_widget=log_stream_widget, **kwargs)

class _AlignmentManager(QtExecutionManager, IAlignmentManager):

    def __init__(self, working_directory, optical_system_id, log_stream_widget = None, **kwargs):
        super(_AlignmentManager, self).__init__(APPLICATION_NAME, working_directory, optical_system_id, **kwargs)

        self._log_stream_widget = log_stream_widget

        self._configuration_gui_ini        = get_registered_ini_instance(application_name=CONFIGURATION_APPLICATION_NAME + "-GUI" )
        self._configuration_gui_parameters = configuration_generate_initialization_parameters_from_ini(self._configuration_gui_ini)

        self._alignment_gui_ini        = get_registered_ini_instance(application_name=self._application_name + "-GUI" )
        self._alignment_gui_parameters = alignement_generate_initialization_parameters_from_ini(self._alignment_gui_ini)

    def reload_utils(self):
        super(_AlignmentManager, self).reload_utils()

        self._configuration_plotter = get_registered_plotter_instance(application_name=CONFIGURATION_APPLICATION_NAME)
        self._alignment_plotter     = get_registered_plotter_instance(application_name=APPLICATION_NAME)

    def get_gui_parameters(self):
        return self._configuration_gui_parameters, self._alignment_gui_parameters

    def start_ai_agent(self, initialization_parameters : ScriptData = None, **kwargs):
        if self._is_ai_plan_running(): raise RuntimeError("The AI Agent is running, please wait")

        super(_AlignmentManager, self).start_ai_agent(initialization_parameters, **kwargs)

    def save_configuration(self, configuration: BeamlineControllerConfiguration, **kwargs):
        if self._is_ai_plan_running(): raise RuntimeError("The AI Agent is running, please wait")

        super(_AlignmentManager, self).save_configuration(configuration=configuration)

        self.save_motors_info(new_motors_info=kwargs.get("motors_info"), configuration=configuration)

        configuration_set_ini_from_initialization_parameters(self._configuration_gui_parameters, self._configuration_gui_ini)
        self._configuration_gui_ini.push(verbose=True, configuration="Configuration Editor runtime parameters")

        self.configuration_saved.emit()

    def show_configuration_editor(self, plotting_properties=PlottingProperties(), **kwargs):
        if self._configuration_plotter.is_active():
            add_context_label = plotting_properties.get_parameter("add_context_label", False)
            use_unique_id     = plotting_properties.get_parameter("use_unique_id", True)

            self.__unique_id = self._configuration_plotter.register_context_window(CONFIGURATION_SHOW_MAIN,
                                                  context_window=DefaultMainWindow(title=CONFIGURATION_SHOW_MAIN),
                                                  use_unique_id=use_unique_id)

            self._configuration_plotter.push_plot_on_context(CONFIGURATION_SHOW_MAIN, ConfigurationEditorWidget, unique_id=self.__unique_id,
                                                             working_directory=self._working_directory,
                                                             optical_system_id=self._optical_system_id,
                                                             available_beam_managers=self.get_available_beam_managers(),
                                                             configuration=self.get_configuration(),
                                                             gui_parameters=self._configuration_gui_parameters,
                                                             save_configuration_method=self.save_configuration,
                                                             close_method=self.close_configuration,
                                                             load_motors_info_method=self.load_motors_info,
                                                             set_current_motor_positions_as_initial_points_method=self.set_current_motor_positions_as_initial_points,
                                                             move_motors_to_initial_points_method=self.move_motors_to_initial_points,
                                                             allows_saving=False,
                                                             **kwargs)
            widget                                   = self._configuration_plotter.get_plots_of_context(CONFIGURATION_SHOW_MAIN, self.__unique_id)[0]
            reload_beam_manager_configuration_method = getattr(widget, "reload_beam_manager_configuration")

            self._connect_reload_beam_manager_configuration(reload_beam_manager_configuration_method)

            self._configuration_plotter.draw_context(CONFIGURATION_SHOW_MAIN, add_context_label=add_context_label, unique_id=self.__unique_id, **kwargs)
            self._configuration_plotter.raise_context_window(context_key=CONFIGURATION_SHOW_MAIN, unique_id=self.__unique_id, close_button=False, stay_on_top=False)
        else:
            raise ValueError("This function cannot be called without a GUI")

    def close_configuration(self):
        try:
            configuration_set_ini_from_initialization_parameters(self._configuration_gui_parameters, self._configuration_gui_ini)
            self._configuration_gui_ini.push(verbose=True, configuration="Configuration Editor runtime parameters")
        except:
            pass

        if self._configuration_plotter.is_active():
            self._configuration_plotter.close_context_window(context_key=CONFIGURATION_SHOW_MAIN, unique_id=self.__unique_id)

        self.configuration_closed.emit()

    def show_alignment_manager(self, plotting_properties=PlottingProperties(), **kwargs):
        if self._alignment_plotter.is_active():
            add_context_label = plotting_properties.get_parameter("add_context_label", False)
            use_unique_id     = plotting_properties.get_parameter("use_unique_id", False)

            self._alignment_plotter.register_context_window(SHOW_MAIN,
                                                            context_window=DefaultMainWindow(title=SHOW_MAIN),
                                                            use_unique_id=use_unique_id)

            self._alignment_plotter.push_plot_on_context(SHOW_MAIN, AlignmentManagerWidget, None,
                                                         log_stream_widget=self._log_stream_widget,
                                                         working_directory=self._working_directory,
                                                         optical_system_id=self._optical_system_id,
                                                         available_beam_managers=self.get_available_beam_managers(),
                                                         configuration=self.get_configuration(),
                                                         gui_parameters=self._alignment_gui_parameters,
                                                         start_ai_agent_method=self.start_ai_agent,
                                                         notify_pause_released_method=self.notify_agent_pause_released,
                                                         close_method=self.close,
                                                         abort_method=self.abort,
                                                         get_result_method=self.get_current_result,
                                                         get_trial_method=self.get_trial,
                                                         get_pareto_trial_number_method=self.get_pareto_trial_number,
                                                         get_optimization_history_method=self.get_optimization_history,
                                                         get_hypervolume_method=self.get_hypervolume,
                                                         finish_method=self.finish,
                                                         move_motors_to_trial_data_method=self.move_motors_to_trial_data,
                                                         reconfigure_beam_manager_with_trial_data_method=self.reconfigure_beam_manager_with_trial_data,
                                                         open_configuration_method=self.show_configuration_editor,
                                                         allows_saving=False,
                                                         **kwargs)
            widget                                   = self._alignment_plotter.get_plots_of_context(SHOW_MAIN)[0]
            optimization_completed_method            = getattr(widget, "optimization_completed")
            configuration_closed_method              = getattr(widget, "configuration_closed")
            optimization_paused_method               = getattr(widget, "optimization_paused")
            optimization_show_trial_requested_method = getattr(widget, "optimization_show_trial_requested")

            self._connect_agent_completed(optimization_completed_method)
            self._connect_agent_paused(optimization_paused_method)
            self._connect_configuration_closed(configuration_closed_method)
            self._connect_show_trial_requested(optimization_show_trial_requested_method)

            self._alignment_plotter.draw_context(SHOW_MAIN, add_context_label=add_context_label, unique_id=None, **kwargs)
            self._alignment_plotter.raise_context_window(context_key=SHOW_MAIN, close_button=False, stay_on_top=False)
        else:
            self.start_ai_agent(self.get_configuration(), is_active_gui=False)

    def reconfigure_beam_manager_with_trial_data(self, platform_key, beam_manager_type_key, beam_manager_id_key, trial_data: OptimizationResultItem):
        if self._is_ai_plan_running(): raise RuntimeError("The AI Agent is running, please wait")

        configuration = super(_AlignmentManager, self).reconfigure_beam_manager_with_trial_data(platform_key, beam_manager_type_key, beam_manager_id_key, trial_data)
        super(_AlignmentManager, self).save_configuration(configuration=configuration)

        self.reload_beam_manager_configuration.emit()
        self.configuration_saved.emit()

    def close(self):
        if self._is_ai_plan_running(): raise RuntimeError("The AI agent is running. Please interrupt it first")

        try:
            alignement_set_ini_from_initialization_parameters(self._alignment_gui_parameters, self._alignment_gui_ini)
            self._alignment_gui_ini.push(verbose=True, configuration="Alignment Manager runtime parameters")
        except:
            pass

        if self._alignment_plotter.is_active(): self._alignment_plotter.get_context_container_widget(context_key=SHOW_MAIN).parent().close()
        sys.exit(0)
