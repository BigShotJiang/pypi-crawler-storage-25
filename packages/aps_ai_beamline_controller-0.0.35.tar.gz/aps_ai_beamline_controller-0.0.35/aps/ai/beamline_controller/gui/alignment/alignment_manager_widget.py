#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import sys
from typing import Literal

import numpy as np

from aps.ai.beamline_controller.initialization.beamline_controller_configuration import BeamlineControllerConfiguration, AutoAlignmentPlan, AutoAlignmentStage
from aps.common.plot import gui
from aps.common.plot.gui import MessageDialog
from aps.common.widgets.generic_widget import GenericWidget
from aps.common.widgets.congruence import *
from aps.common.singleton import synchronized_method
from aps.common.scripts.script_data import ScriptData

from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter
import cmasher as cmm
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar

from AnyQt.QtWidgets import QHBoxLayout, QVBoxLayout, QTableWidget, QTableWidgetItem, QScrollArea
from AnyQt.QtCore import QRect, Qt
from AnyQt.QtGui import QFont, QPalette, QColor, QGuiApplication

from aps.ai.beamline_controller.common.legacy_keys import Keys
from aps.beamline_driver.motion_management.facade import MotorsInfo

IS_DEBUG = os.getenv('BC_DEBUG', "0") == "1"

class AlignmentManagerWidget(GenericWidget):
    def __init__(self, parent, application_name=None, **kwargs):
        self._log_stream_widget       = kwargs["log_stream_widget"]
        self._working_directory       = kwargs["working_directory"]
        self._optical_system_id       = kwargs["optical_system_id"]
        self._available_beam_managers = kwargs["available_beam_managers"]
        self._configuration           = kwargs["configuration"]
        self._gui_parameters          = kwargs["gui_parameters"]

        # METHODS
        self._start_ai_agent                           = kwargs["start_ai_agent_method"]
        self._close                                    = kwargs["close_method"]
        self._abort                                    = kwargs["abort_method"]
        self._get_result                               = kwargs["get_result_method"]
        self._get_pareto_trial_number                  = kwargs["get_pareto_trial_number_method"]
        self._get_trial                                = kwargs["get_trial_method"]
        self._get_optimization_history                 = kwargs["get_optimization_history_method"]
        self._get_hypervolume                          = kwargs["get_hypervolume_method"]
        self._move_motors_to_trial_data                = kwargs["move_motors_to_trial_data_method"]
        self._reconfigure_beam_manager_with_trial_data = kwargs["reconfigure_beam_manager_with_trial_data_method"]
        self._open_configuration                       = kwargs["open_configuration_method"]
        self._notify_pause_released                    = kwargs["notify_pause_released_method"]

        self.plan_description = ""

        self.total_iterations_i  = 0
        self.total_iterations_f  = 0
        self.pareto_events       = None
        self.pareto_selection  = 0
        self.selected_event      = 0
        self.use_range           = 0
        self.xrange_i            = 0.0
        self.xrange_f            = 0.0
        self.yrange_i            = 0.0
        self.yrange_f            = 0.0

        self._last_platform = None
        self._last_plan_id  = None
        self._last_stage_id = None

        self._set_values_from_initialization_parameters()

        super(AlignmentManagerWidget, self).__init__(parent=parent, application_name=application_name, **kwargs)

        self.__is_init = True

    def _set_values_from_initialization_parameters(self):
        self.working_directory = self._working_directory
        self.optical_system_id = self._optical_system_id

        configuration: BeamlineControllerConfiguration = self._configuration

        self._platforms                  = configuration.driver_configuration.platforms
        self._plaforms_combo             = configuration.driver_configuration.platforms_combo

        self._plans_platforms            = configuration.plans_configuration.get_available_platforms()
        self._plans_platform_combo_items = [self._plaforms_combo[self._platforms.index(platform)] for platform in self._plans_platforms]

        self._reload_gui_parameters()
        self._reload_configuration()

    def _reload_gui_parameters(self):
        gui_parameters: ScriptData = self._gui_parameters
        configuration              = self._configuration

        self.plans_platform = gui_parameters.get_parameter("platform", 1)
        plan_platform       = self._plans_platforms[self.plans_platform]

        self._plan_ids      = gui_parameters.get_parameter("plan_ids")
        self.plan_id        = self._plan_ids[plan_platform]

        self._plans_combo_items = configuration.plans_configuration.get_plan_names_by_platform(plan_platform)

    def _reload_configuration(self):
        pass

    def _collect_configuration_parameters(self):
        gui_parameters: ScriptData  = self._gui_parameters

        plan_platform                 = self._plans_platforms[self.plans_platform]
        self._plan_ids[plan_platform] = self.plan_id

        gui_parameters.set_parameter("plans_platform", self.plans_platform)
        gui_parameters.set_parameter("plan_ids", self._plan_ids)

    def _reload_values(self):
        self._reload_configuration()

    def _save_values(self):
        self._collect_configuration_parameters()

    def get_plot_tab_name(self): return self._optical_system_id + ": Multi-Stage AI-driven Autoalignment System"

    def build_widget(self, **kwargs):
        geom = QGuiApplication.primaryScreen().availableGeometry()

        try:    widget_width = kwargs["widget_width"]
        except: widget_width = min(1450, geom.width()*0.98)
        try:    widget_height = kwargs["widget_height"]
        except:
            if sys.platform == 'darwin' : widget_height = min(750, geom.height()*0.95)
            else:                         widget_height = min(850, geom.height()*0.95)
        self.setGeometry(QRect(10, 10, int(widget_width), int(widget_height)))
        self.setFixedWidth(int(widget_width))
        self.setFixedHeight(int(widget_height))

        layout = QHBoxLayout()
        layout.setAlignment(Qt.AlignLeft)
        self.setLayout(layout)

        main_box_width = 450

        main_box = gui.widgetBox(self, "", width=main_box_width, height=self.height() - 20)

        self._out_box     = gui.widgetBox(self, "", width=self.width() - main_box_width - 20, height=self.height() - 20, orientation="vertical")
        self._bl_box      = gui.widgetBox(self._out_box, "", width=self._out_box.width(), height=50)

        tab_box    = gui.widgetBox(self._out_box, "", width=self._out_box.width(), height=self._out_box.height() - 55, orientation="vertical")
        self._out_tab_widget = gui.tabWidget(tab_box)

        self._out_tab_0 = gui.createTabPage(self._out_tab_widget, "Log")
        self._out_tab_1 = gui.createTabPage(self._out_tab_widget, "Result")
        self._out_tab_2 = gui.createTabPage(self._out_tab_widget, "Process History")
        self._out_tab_3 = gui.createTabPage(self._out_tab_widget, "Hypervolume")

        self._log_box         = gui.widgetBox(self._out_tab_0, "Log", width=tab_box.width() - 20, height=tab_box.height() - 40)
        self._result_box      = gui.widgetBox(self._out_tab_1, "")
        self._history_box     = gui.widgetBox(self._out_tab_2, "")
        self._hypervolume_box = gui.widgetBox(self._out_tab_3, "")

        self._result_figure = Figure(figsize=[9.65, 5.9], constrained_layout=True)
        self._result_figure_canvas = FigureCanvas(self._result_figure)
        self._result_scroll = QScrollArea(self._result_box)
        self._result_scroll.setWidget(self._result_figure_canvas)
        self._result_box.layout().addWidget(NavigationToolbar(self._result_figure_canvas, self))
        self._result_box.layout().addWidget(self._result_scroll)

        self._history_figure_canvas = FigureCanvas(Figure(figsize=[14, 10], constrained_layout=True))
        self._history_scroll = QScrollArea(self._history_box)
        self._history_scroll.setWidget(self._history_figure_canvas)
        self._history_box.layout().addWidget(NavigationToolbar(self._history_figure_canvas, self))
        self._history_box.layout().addWidget(self._history_scroll)

        self._hypervolume_figure_canvas = FigureCanvas(Figure(figsize=[9.65, 5.9], constrained_layout=True))
        self._hypervolume_scroll = QScrollArea(self._hypervolume_box)
        self._hypervolume_scroll.setWidget(self._hypervolume_figure_canvas)
        self._hypervolume_box.layout().addWidget(NavigationToolbar(self._hypervolume_figure_canvas, self))
        self._hypervolume_box.layout().addWidget(self._hypervolume_scroll)

        self.le_optical_system_id = gui.lineEdit(self._bl_box, self, "optical_system_id",
                                                 label="                                                                                                                                                                                    Optical System",
                                                 labelWidth=self._out_box.width(), controlWidth=250, orientation='horizontal', valueType=str)
        self.le_optical_system_id.setReadOnly(True)
        font = QFont(self.le_optical_system_id.font())
        font.setBold(True)
        font.setItalic(False)
        font.setPixelSize(25)
        self.le_optical_system_id.setFont(font)
        self.le_optical_system_id.setAlignment(Qt.AlignRight)
        self.le_optical_system_id.setStyleSheet("QLineEdit {color : darkgreen; background : rgb(243, 240, 160); text-align : right}")

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)
        self._log_box.setLayout(layout)
        if not self._log_stream_widget is None:
            self._log_box.layout().addWidget(self._log_stream_widget.get_widget())
            self._log_stream_widget.set_widget_size(width=self._log_box.width() - 15, height=self._log_box.height() - 35)
        else:
            self._log_box.layout().addWidget(QLabel("Log on file only"))

        button_box = gui.widgetBox(main_box, "", width=main_box.width(), orientation='horizontal')
        button_box.layout().setAlignment(Qt.AlignCenter)

        self._start_ai_agent_button = gui.button(button_box, None, "Start AI Agent", callback=self._optimize_callback, width=int(0.33 * main_box.width() - 3), height=35)
        abort_button          = gui.button(button_box, None, "Interrupt", callback=self._abort_callback, width=int(0.33*main_box.width()-3), height=35)
        exit_button           = gui.button(button_box, None, "Exit GUI", callback=self._close_callback, width=int(0.34*main_box.width()-3), height=35)

        font = QFont(abort_button.font())
        font.setBold(True)
        abort_button.setFont(font)
        palette = QPalette(abort_button.palette())
        palette.setColor(QPalette.ButtonText, QColor('Red'))
        abort_button.setPalette(palette)

        font = QFont(exit_button.font())
        font.setBold(False)
        font.setItalic(True)
        exit_button.setFont(font)
        palette = QPalette(exit_button.palette())
        palette.setColor(QPalette.ButtonText, QColor('Dark Blue'))
        exit_button.setPalette(palette)

        gui.separator(main_box)

        tab_widget = gui.tabWidget(main_box)
        ai_settings_tab      = gui.createTabPage(tab_widget, "AI")
        results_analysis_tab = gui.createTabPage(tab_widget, "Result Analysis")

        labels_width = 350

        # ------------------------------------------------------------
        # AI SETTING
        ai_box_1 = gui.widgetBox(ai_settings_tab, "Plans", width=main_box.width() - 15, height=main_box.height() - 90, orientation='vertical', addSpace=False)

        self.cb_plans_platform  = gui.comboBox(ai_box_1, self, "plans_platform", label="Platform", items=self._plans_platform_combo_items, labelWidth=100, orientation="horizontal", callback=self._set_plans_platform)
        self._cb_plans = gui.comboBox(ai_box_1, self, "plan_id", label="Plan", items=self._plans_combo_items, labelWidth=100, orientation="horizontal", callback=self._set_plan)

        gui.widgetLabel(ai_box_1, "Plan Summary")

        self._summary_text_area = gui.textArea(height=ai_box_1.height()-200,
                                               width=ai_box_1.width()-20,
                                               readOnly=True)

        ai_box_1.layout().addWidget(self._summary_text_area)

        self._configuration_button = gui.button(ai_box_1, None, "Open Configuration Manager", callback=self._open_configuration_callback, width=ai_box_1.width()-20, height=35)

        # ------------------------------------------------------------
        # Result Analysis

        if sys.platform == 'darwin': result_box_1 = gui.widgetBox(results_analysis_tab, "Current Result", width=main_box.width()-15, height=475, orientation='vertical', addSpace=False)
        else:                        result_box_1 = gui.widgetBox(results_analysis_tab, "Current Result", width=main_box.width()-15, height=495, orientation='vertical', addSpace=False)

        self.le_total_iterations_i = gui.lineEdit(result_box_1, self, "total_iterations_i", "Initial trial", labelWidth=labels_width, orientation='horizontal', valueType=int)
        self.le_total_iterations_i.setReadOnly(True)
        self.le_total_iterations_i.setStyleSheet("QLineEdit {color : black; background : rgb(243, 240, 160)}")
        self.le_total_iterations_f = gui.lineEdit(result_box_1, self, "total_iterations_f", "Final trial", labelWidth=labels_width, orientation='horizontal', valueType=int)
        self.le_total_iterations_f.setReadOnly(True)
        self.le_total_iterations_f.setStyleSheet("QLineEdit {color : black; background : rgb(243, 240, 160)}")

        self._pareto_events_box = gui.widgetBox(result_box_1, "", width=result_box_1.width() - 20, height=80, orientation='vertical', addSpace=False)

        pareto_ta_box = gui.widgetBox(self._pareto_events_box, "", width=result_box_1.width()- 20, height=50, orientation='horizontal', addSpace=False)
        gui.widgetLabel(pareto_ta_box, "Pareto Frontier", labelWidth=100)
        self.ta_pareto_events = gui.textArea(height=50, width=310, noWrap=False, readOnly=True)
        pareto_ta_box.layout().addWidget(self.ta_pareto_events)

        gui.separator(result_box_1, height=4)

        self.cb_pareto_selection = gui.comboBox(self._pareto_events_box, self, "pareto_selection", label="Pareto Best Trial", items=["Nash Equilibrium", "Most Intense", "Narrowest", "Closest to Origin"], orientation="horizontal", callback=self._set_pareto_selection)

        gui.separator(result_box_1)

        box = gui.widgetBox(result_box_1, "", width=result_box_1.width()- 20, height=30, orientation='horizontal', addSpace=False)

        gui.widgetLabel(box, "Selected trial", labelWidth=labels_width)

        def minus_one_event():
            event = self.selected_event - 1

            if   event <= 0:                       event = 0
            elif event >= self.total_iterations_f: event = self.total_iterations_f

            self.selected_event = event
            self.le_selected_event.setText(str(event))

        def plus_one_event():
            event = self.selected_event + 1

            if event <= 0:                         event = 0
            elif event >= self.total_iterations_f: event = self.total_iterations_f

            self.selected_event = event
            self.le_selected_event.setText(str(event))

        gui.button(box, None, "-1", callback=minus_one_event, width=30)
        self.le_selected_event     = gui.lineEdit(box, self, "selected_event", "", controlWidth=30, orientation='horizontal', valueType=int)
        gui.button(box, None, "+1", callback=plus_one_event, width=30)

        self.cb_use_range          = gui.comboBox(result_box_1, self, "use_range", label="Plotting Range", labelWidth=300, items=["No", "Yes"], orientation="horizontal", callback=self._set_use_range)

        self.use_range_box_1 = gui.widgetBox(result_box_1, "", width=result_box_1.width(), height=60, orientation='vertical', addSpace=False)
        self.use_range_box_2 = gui.widgetBox(result_box_1, "", width=result_box_1.width(), height=60, orientation='vertical', addSpace=False)

        box = gui.widgetBox(self.use_range_box_2, "", width=result_box_1.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_xrange_i = gui.lineEdit(box, self, "xrange_i", "                    H Range from", labelWidth=170, orientation='horizontal', controlWidth=100, valueType=float)
        self.le_xrange_f = gui.lineEdit(box, self, "xrange_f", "  to", labelWidth=30, orientation='horizontal', controlWidth=100, valueType=float)

        box = gui.widgetBox(self.use_range_box_2, "", width=result_box_1.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_yrange_i = gui.lineEdit(box, self, "yrange_i", "                    V Range from", labelWidth=170, orientation='horizontal', controlWidth=100, valueType=float)
        self.le_yrange_f = gui.lineEdit(box, self, "yrange_f", "  to", labelWidth=30, orientation='horizontal', controlWidth=100, valueType=float)

        gui.separator(result_box_1, height=10)

        gui.button(result_box_1, None, "Show Trial", callback=self._show_trial, width=result_box_1.width()-20, height=35)
        gui.separator(result_box_1, height=4)
        button = gui.button(result_box_1, None, "Move Motors to Selected Trial", callback=self._move_motors_to_selected_trial, width=result_box_1.width()-20, height=35)
        font = QFont(button.font())
        font.setBold(False)
        font.setItalic(True)
        button.setFont(font)
        palette = QPalette(button.palette())
        palette.setColor(QPalette.ButtonText, QColor('Dark Blue'))
        button.setPalette(palette)
        gui.separator(result_box_1, height=4)
        button = gui.button(result_box_1, None, "Reconfigure Beam Manager with Selected Trial", callback=self._reconfigure_beam_manager_with_selected_trial, width=result_box_1.width()-20, height=35)
        font = QFont(button.font())
        font.setBold(True)
        button.setFont(font)
        palette = QPalette(button.palette())
        palette.setColor(QPalette.ButtonText, QColor('Dark Red'))
        button.setPalette(palette)

        self._set_plans_platform()
        self._set_use_range()

        self.__is_init = False

    # -------------------------------------------------------------
    # GUI Setters

    def _set_plans_platform(self):
        configuration = self._configuration
        plan_platform = self._plans_platforms[self.plans_platform]
        self.plan_id  = self._plan_ids[plan_platform]

        self._cb_plans.clear()
        self._cb_plans.addItems(configuration.plans_configuration.get_plan_names_by_platform(plan_platform))
        self._cb_plans.setCurrentIndex(int(self.plan_id))

        self._set_plan()

    def _set_plan(self):
        configuration: BeamlineControllerConfiguration = self._configuration
        plan_platform = self._plans_platforms[self.plans_platform]
        plan_ids       = configuration.plans_configuration.get_plan_ids_by_platform(plan_platform)
        plan_names     = configuration.plans_configuration.get_plan_names_by_platform(plan_platform)

        plan: AutoAlignmentPlan = configuration.plans_configuration.get_plan(plan_platform, plan_ids[self.plan_id])

        description = f"Plan {plan_names[self.plan_id]}\n"
        prog = 0
        for stage in plan.stages:
            prog += 1
            description += f"\n{prog}) {stage.stage_name}\n"
            description += f"  AI Type: {configuration.ai_configuration.ai_types_combo[stage.ai_type]}\n"

            beam_manager_type = configuration.driver_configuration.beam_manager_types[stage.beam_manager_type]
            beam_manager_id = configuration.driver_configuration.beam_manager_configuration[beam_manager_type]["beam_manager_ids"][stage.beam_manager_id]

            if stage.ai_type == 0:
                optimizer_type = configuration.ai_configuration.optimization_configuration["optimizer_types"][stage.ai_configuration["optimizer_type"]]

                optimizer_type_str    = configuration.ai_configuration.optimization_configuration["optimizer_types_combo"][stage.ai_configuration["optimizer_type"]]
                optimizer_name_str    = configuration.ai_configuration.optimization_configuration[optimizer_type]["names_combo"][stage.ai_configuration["name"]]
                optimization_type_str = configuration.ai_configuration.optimization_configuration["optimization_types_combo"][stage.ai_configuration["optimization_type"]]

                description += f"  Optimizer Type: {optimizer_type_str}\n"
                description += f"  Optimizer Name: {optimizer_name_str}\n"
                description += f"  Optimization Type: {optimization_type_str}\n"

                if optimizer_name_str == "Ax":
                    optimizer_name_key = configuration.ai_configuration.optimization_configuration[optimizer_type]["names"][stage.ai_configuration["name"]]

                    surrogate        = configuration.ai_configuration.optimization_configuration[optimizer_type][optimizer_name_key]["surrogates"][stage.ai_configuration["surrogate"]]
                    surrogate_action = configuration.ai_configuration.optimization_configuration[optimizer_type][optimizer_name_key]["surrogate_actions"][stage.ai_configuration["surrogate_action"]]

                    description += f"  Surrogate Model: {surrogate}\n"
                    description += f"  Surrogate Initialization: {surrogate_action}\n"

                motor_ids_to_optimize   = configuration.driver_configuration.get_motor_ids_to_optimize(beam_manager_type=beam_manager_type, platform=plan_platform, beam_manager_id=beam_manager_id)
                optimization_criteria = configuration.driver_configuration.beam_manager_configuration[beam_manager_type]["defaults"][plan_platform][beam_manager_id]["objectives"]

                first = True
                for motor_id in motor_ids_to_optimize:
                    if first: description += f"  Motors: {motor_id}\n"
                    else:     description += f"          {motor_id}\n"
                    first = False

                first = True
                for optimization_criterion in optimization_criteria:
                    if first: description += f"  Optimization Criteria: {optimization_criterion}\n"
                    else:     description += f"                         {optimization_criterion}\n"
                    first = False

                if stage.requires_pause_at_end:
                    description += "\n"
                    description += " *--------------------------------------------*\n"
                    description += "  IT WILL PAUSE AND PROMPT THE USER TO PROCEED\n"
                    description += " *--------------------------------------------*\n"

        self._summary_text_area.clear()
        self._summary_text_area.setFont(QFont('Courier New', 9))
        self._summary_text_area.setText(description)

        if not self.__is_init:
            self._plan_ids[plan_platform] = self.plan_id


    def _set_pareto_selection(self):
        if self._last_platform is None or self._last_plan_id is None or self._last_stage_id is None: return

        self.le_selected_event.setText(str(self._get_pareto_trial_number(pareto_selection=self.pareto_selection,
                                                                         platform=self._last_platform, plan_id=self._last_plan_id, stage_id=self._last_stage_id)))

    def _set_use_range(self):
        self.use_range_box_1.setVisible(self.use_range==0)
        self.use_range_box_2.setVisible(self.use_range==1)

    # -------------------------------------------------------------

    def _refresh_widget(self):
        self.le_total_iterations_i.setText(str(self.total_iterations_i))
        self.le_total_iterations_f.setText(str(self.total_iterations_f))
        self.le_selected_event.setText(str(self.selected_event))
        self.ta_pareto_events.setText("" if self.pareto_events is None else str(self.pareto_events))

    def _open_configuration_callback(self):
        self._configuration_button.setEnabled(False)
        self._open_configuration()

    def configuration_closed(self):
        self._configuration_button.setEnabled(True)

    def _optimize_callback(self, **kwargs):
        try:
            configuration: BeamlineControllerConfiguration = self._configuration

            self._start_ai_agent_button.setEnabled(False)

            self._out_tab_widget.setCurrentIndex(0)
            self._collect_configuration_parameters()

            self._last_platform = None
            self._last_plan_id  = None
            self._last_stage_id = None

            platform = self._plans_platforms[self.plans_platform]
            plan_id  = configuration.plans_configuration.get_plan_ids_by_platform(platform)[self.plan_id]

            self._start_ai_agent(platform, plan_id, **kwargs)
        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
            if IS_DEBUG: raise error
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)
            if IS_DEBUG: raise exception

    def _abort_callback(self):
        if ConfirmDialog.confirmed(self, "Confirm interruption of AI Agent?"):
            try:
                self._collect_configuration_parameters()
                self._abort()
            except Exception as exception:
                MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)
                if IS_DEBUG: raise exception

    def _close_callback(self):
        if ConfirmDialog.confirmed(self, "Confirm Exit?"):
            try:
                self._collect_configuration_parameters()
                self._close()
            except Exception as exception:
                MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)
                if IS_DEBUG: raise exception

    @synchronized_method
    def optimization_paused(self):
        MessageDialog.message(self, "AI autoalignment paused as request. Press click OK to proceed to the next stage...")
        self._notify_pause_released()

    @synchronized_method
    def optimization_completed(self, data):
        enable_button = True
        try:
            platform, plan_id, stage_id = data
            ai_result                   = self._get_result()
            configuration: BeamlineControllerConfiguration = self._configuration

            self._last_platform = platform
            self._last_plan_id  = plan_id
            self._last_stage_id = stage_id

            if not ai_result is None:
                plan: AutoAlignmentPlan = configuration.plans_configuration.get_plan(platform=platform, plan_id=plan_id)
                stage: AutoAlignmentStage = plan.get_stage(stage_id)

                if plan.is_last_stage(stage_id):
                    enable_button = True
                    message       = "AI Plan completed"
                else:
                    enable_button = False
                    message       = "<--- Warning: The AI agent is proceeding to the next stage"

                ai_type        = stage.ai_type
                optimizer_type = stage.ai_configuration.get("optimizer_type")

                self.cb_pareto_selection.setEnabled(False)

                if ai_type == 0:  # optimization
                    if optimizer_type == 0:  # MOBO
                       optimization_result_data, pareto_front_data, best_trial_data = ai_result

                       if not optimization_result_data is None and not optimization_result_data.is_empty():
                           self.total_iterations_i = optimization_result_data.get_trial_numbers()[0]
                           self.total_iterations_f = optimization_result_data.get_trial_numbers()[-1]
                           if not pareto_front_data is None and not pareto_front_data.is_empty():
                               self.pareto_events  = pareto_front_data.get_trial_numbers()
                               self.selected_event = best_trial_data.trial_number

                               self.cb_pareto_selection.setCurrentIndex(stage.ai_configuration.get("pareto_selection"))
                               self.cb_pareto_selection.setEnabled(True)
                           else:
                               self.pareto_events  = None
                               self.selected_event = self.total_iterations_f
                           self._plot_trial(ai_type=ai_type, stage_name=stage.stage_name, message=message)
                           self._plot_history()
                           self._plot_hypervolume()
                           self._out_tab_widget.setCurrentIndex(1)
                    elif optimizer_type in [1, 2]:  # NL / SOBO:
                        optimization_result_data, best_trial_data = ai_result

                        if not optimization_result_data is None and not optimization_result_data.is_empty():
                            self.total_iterations_i = optimization_result_data.get_trial_numbers()[0]
                            self.total_iterations_f = optimization_result_data.get_trial_numbers()[-1]
                            self.selected_event     = best_trial_data.trial_number
                            self._plot_trial(ai_type=ai_type, stage_name=stage.stage_name, message=message)
                            self._plot_history()
                            self._out_tab_widget.setCurrentIndex(1)
                elif ai_type == 1: # Neural Network
                    if not ai_result is None:
                        self.total_iterations_i = 1
                        self.total_iterations_f = 1
                        self.pareto_events = None
                        self.selected_event = self.total_iterations_f
                        self._plot_trial(ai_type=ai_type)
                        self._out_tab_widget.setCurrentIndex(1)
                else:
                    pass
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)
            if IS_DEBUG: raise exception

        self._refresh_widget()
        self._enable_buttons(enable_button)

    @synchronized_method
    def optimization_show_trial_requested(self, data):
        loss_function, beam_properties, trial_index = data

        self.__draw_trial_data(ai_type=0,
                               stage_name="",
                               message="",
                               output_data=loss_function,
                               beam_properties=beam_properties,
                               trial_index=trial_index)
        self._out_tab_widget.setCurrentIndex(1)

    @synchronized_method
    def _enable_buttons(self, enabled):
        self._start_ai_agent_button.setEnabled(enabled)

    def _show_trial(self):
        self._plot_trial(ai_type=0, stage_name="", message="")
        self._out_tab_widget.setCurrentIndex(1)

    def _move_motors_to_selected_trial(self):
        if self._last_platform is None or self._last_plan_id is None or self._last_stage_id is None: return

        trial_data, _  = self._get_trial(self.selected_event, self._last_platform, self._last_plan_id, self._last_stage_id)

        self._move_motors_to_trial_data(trial_data)

        self._out_tab_widget.setCurrentIndex(0)

    def _reconfigure_beam_manager_with_selected_trial(self):
        if self._last_platform is None or self._last_plan_id is None or self._last_stage_id is None: return

        configuration = self._configuration

        plan: AutoAlignmentPlan = configuration.plans_configuration.get_plan(self._last_platform, self._last_plan_id)
        stage = plan.get_stage(self._last_stage_id)

        beam_manager_type = configuration.driver_configuration.beam_manager_types[stage.beam_manager_type]
        beam_manager_id   = configuration.driver_configuration.beam_manager_configuration[beam_manager_type]["beam_manager_ids"][stage.beam_manager_id]

        trial_data, _  = self._get_trial(self.selected_event, self._last_platform, self._last_plan_id, self._last_stage_id)

        self._reconfigure_beam_manager_with_trial_data(platform_key=self._last_platform,
                                                       beam_manager_type_key=beam_manager_type,
                                                       beam_manager_id_key=beam_manager_id,
                                                       trial_data=trial_data)

        MessageDialog.message(self, title="Reconfiguration", message="Beam Manager has been reconfigured with selected trial data", type="info", width=500)

    def _plot_trial(self, ai_type=0, stage_name="", message=""):
        if   ai_type == 0: trial_index = self.selected_event
        elif ai_type == 1: trial_index = 1

        try:
            trial_data, beam_properties = self._get_trial(trial_index, self._last_platform, self._last_plan_id, self._last_stage_id)

            output_data = trial_data.loss_function if ai_type == 0 else trial_data.beam_properties

            self.__draw_trial_data(ai_type, stage_name, message, output_data, beam_properties, trial_index)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)
            if IS_DEBUG: raise exception

    def __draw_trial_data(self, ai_type: int, stage_name: str,  message: str, output_data, beam_properties, trial_index: int):
        mode = "image"

        if beam_properties.has_parameter("beam_histogram"):
            beam_histogram = beam_properties.get_parameter("beam_histogram")
            hh = beam_histogram.get_parameter("coordinate_h")
            vv = beam_histogram.get_parameter("coordinate_v")
            mode = "image"
        elif beam_properties.has_parameter("intensity_histogram"):
            beam_histogram = beam_properties.get_parameter("intensity_histogram")
            hh = beam_histogram.get_parameter("coordinate_h")
            vv = beam_histogram.get_parameter("coordinate_v")
            mode = "image"
        elif beam_properties.has_parameter("intensity_histogram_h"):
            beam_histogram_h = beam_properties.get_parameter("intensity_histogram_h")
            beam_histogram_v = beam_properties.get_parameter("intensity_histogram_v")
            hh = beam_properties.get_parameter("coordinate_h")
            vv = beam_properties.get_parameter("coordinate_v")
            mode = "scan"
        elif beam_properties.has_parameter("beam_histogram_h"):
            beam_histogram_h = beam_properties.get_parameter("beam_histogram_h")
            beam_histogram_v = beam_properties.get_parameter("beam_histogram_v")
            hh = beam_properties.get_parameter("coordinate_h")
            vv = beam_properties.get_parameter("coordinate_v")
            mode = "scan"
        elif beam_properties.has_parameter("speckle_data_h"):
            beam_histogram_h = beam_properties.get_parameter("speckle_data_h")
            beam_histogram_v = beam_properties.get_parameter("speckle_data_v")
            hh = beam_properties.get_parameter("coordinate_h")
            vv = beam_properties.get_parameter("coordinate_v")
            mode = "speckle"


        def custom_formatter(x, pos):
            return f'{x:.2f}'

        if self.use_range == 0:
            xrange = None
            yrange = None
        else:
            xrange = [self.xrange_i, self.xrange_f]
            yrange = [self.yrange_i, self.yrange_f]

        if mode == "image":
            data_2D = beam_histogram.get_parameter("histogram").T

            if xrange is None: xrange = [np.min(hh), np.max(hh)]
            if yrange is None: yrange = [np.min(vv), np.max(vv)]

            fig = self._result_figure
            fig.clear()

            ax_1, ax_2 = fig.subplots(1, 2, gridspec_kw={'width_ratios': [2, 1]})
            ax_2.set_axis_off()

            image = ax_1.pcolormesh(hh, vv, data_2D, cmap=cmm.sunburst_r, rasterized=True)
            ax_1.set_xlim(xrange[0], xrange[1])
            ax_1.set_ylim(yrange[0], yrange[1])
            ax_1.set_xticks(np.linspace(xrange[0], xrange[1], 11, endpoint=True))
            ax_1.set_yticks(np.linspace(yrange[0], yrange[1], 11, endpoint=True))
            ax_1.xaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_1.yaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_1.axhline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_1.axvline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_1.set_xlabel("Horizontal ($\\mu$m)")
            ax_1.set_ylabel("Vertical ($\\mu$m)")
            ax_1.set_title(stage_name)

            cbar = fig.colorbar(mappable=image, ax=ax_1, pad=0.01, aspect=30, shrink=0.6)

            ax_1.set_aspect("equal")
            ax_1.text(0.02, 0.95, str(trial_index), fontsize=10, color="blue", transform=ax_1.transAxes)

            cbar.ax.text(0.5, 1.05, "pI", transform=cbar.ax.transAxes, ha="center", va="bottom", fontsize=10, color="black")

            text = f"Alignement Criteria ({'Objective Function' if ai_type == 0 else 'Beam Properties'})\n"

            criteria = list(output_data.keys())
            criteria = [(x + (' ' * (len(max(criteria, key=len)) - len(x)))) for x in criteria]

            for criterion in criteria:
                if "negative-log" in criterion or "integral" in criterion:
                    um = ""
                else:
                    um = "$\\mu$m"
                text += "\n" + rf"{criterion:<6}  = {output_data[criterion.strip()] : 3.6f} {um}"

            ax_2.text(0.01, 0.5, text, color="black", alpha=0.9, fontsize=9, fontname="Courier", bbox=dict(facecolor="white", edgecolor="gray", alpha=0.7), transform=ax_2.transAxes)
        elif mode in ["scan", "speckle"]:
            if xrange is None: xrange = [np.min(hh), np.max(hh)]
            if yrange is None: yrange = [np.min(vv), np.max(vv)]

            fig = self._result_figure
            fig.clear()

            import matplotlib.gridspec as gridspec

            gs = gridspec.GridSpec(15, 3, width_ratios=[1.4, 1.4, 1.5], wspace=0.05)  # 3 rows (for vertical control), 3 columns

            ax_1 = fig.add_subplot(gs[1:, 0])
            ax_2 = fig.add_subplot(gs[1:, 1], sharey=ax_1)
            ax_3 = fig.add_subplot(gs[:, 2], sharey=ax_1)

            ax_3.set_axis_off()

            ax_1.set_xlim(xrange[0], xrange[1])
            ax_1.set_xticks(np.linspace(xrange[0], xrange[1], 6, endpoint=True))
            ax_1.xaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_1.axvline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_1.set_xlabel("Horizontal ($\\mu$m)")
            if mode == "scan":
                ax_1.set_ylabel("Intensity")
            else:
                ax_1.set_ylabel("Speckle Amplitude")
            ax_1.plot(hh, beam_histogram_h)
            ax_1.set_title(stage_name)

            ax_2.set_xlim(yrange[0], yrange[1])
            ax_2.set_xticks(np.linspace(yrange[0], yrange[1], 6, endpoint=True))
            ax_2.tick_params(labelleft=False)
            ax_2.xaxis.set_major_formatter(FuncFormatter(custom_formatter))
            ax_2.axvline(0, color="gray", ls="--", linewidth=1, alpha=0.7)
            ax_2.set_xlabel("Vertical ($\\mu$m)")
            ax_2.plot(vv, beam_histogram_v)

            ax_1.text(0.02, 0.95, str(trial_index), fontsize=10, color="blue", transform=ax_1.transAxes)

            text = f"Alignement Criteria ({'Objective Function' if ai_type == 0 else 'Beam Properties'})\n"

            criteria = list(output_data.keys())
            criteria = [(x + (' ' * (len(max(criteria, key=len)) - len(x)))) for x in criteria]

            for criterion in criteria:
                if "negative-log" in criterion or "integral" in criterion:
                    um = ""
                else:
                    um = "$\\mu$m"
                text += "\n" + rf"{criterion:<6}  = {output_data[criterion.strip()] : 3.6f} {um}"

            ax_3.text(0.01, 0.5, text, color="black", alpha=0.9, fontsize=9, fontname="Courier",
                      bbox=dict(facecolor="white", edgecolor="gray", alpha=0.7), transform=ax_3.transAxes)

        self._result_figure.text(0.01, 0.95, message, color="blue", alpha=0.9, fontsize=12, fontname="Courier", )
        self._result_figure_canvas.draw()

    def _plot_history(self):
        self._history_figure_canvas.figure = self._get_optimization_history()
        self._history_figure_canvas.draw()

    def _plot_hypervolume(self):
        self._hypervolume_figure_canvas.figure = self._get_hypervolume()
        self._hypervolume_figure_canvas.draw()