#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import copy
from aps.common.initializer import IniFacade
from aps.common.scripts.script_data import ScriptData

from aps.ai.beamline_controller.common.legacy_keys import Keys

def generate_initialization_parameters_from_ini(ini: IniFacade):
    optimizer_types      = [Keys.OptimizerType.MOBO, Keys.OptimizerType.SONL, Keys.OptimizerType.SOBO]
    neural_network_types = [Keys.NeuralNetworkModelType.TANDEM]
    beam_manager_types   = [Keys.BeamManagerTypes.BeamProfile, Keys.BeamManagerTypes.WavefrontAnalysis, Keys.BeamManagerTypes.SpeckleAnalysis]

    optimizer_type  = ini.get_int_from_ini("AI", "optimization, optimizer_type", default=0)
    optimizer_names = {ot : ini.get_int_from_ini("AI", f"optimization, {ot}, name", default=0) for ot in optimizer_types}
    optimization_type = ini.get_int_from_ini("AI", "optimization, optimization_type", default=0)

    neural_network_type  = ini.get_int_from_ini("AI", "neural_network, neural_network_type", default=0)
    neural_network_models_from = {nnt : ini.get_int_from_ini("AI", f"neural_network, {nnt}, neural_network_model_from", default=0) for nnt in neural_network_types}

    platform            = ini.get_int_from_ini("Driver", "platform", default=1)
    beam_manager_type   = ini.get_int_from_ini("Driver",  "beam_manager_type")
    beam_manager_ids    = {bmt : ini.get_int_from_ini("Driver",  f"beam_manager, {bmt}, beam_manager_id", default=0) for bmt in beam_manager_types}

    previous_platform            = ini.get_int_from_ini("Driver", "previous, platform", default=1)
    previous_beam_manager_type   = ini.get_int_from_ini("Driver",  "previous, beam_manager_type")
    previous_beam_manager_ids    = {bmt : ini.get_int_from_ini("Driver",  f"previous, beam_manager, {bmt}, beam_manager_id", default=0) for bmt in beam_manager_types}

    motor = ini.get_int_from_ini("Driver",  "motion_manager, motor", default=0)

    plans_platforms  = ini.get_dict_from_ini("Plans", "platforms", default={})
    plans_platform   = ini.get_int_from_ini("Plans", "platform", default=1)
    plan_ids         = {p : ini.get_int_from_ini("Plans", f"platforms, {p}, plan_id") for p in plans_platforms}

    return ScriptData(optimizer_type             = optimizer_type,
                      optimizer_names            = optimizer_names,
                      optimization_type          = optimization_type,
                      neural_network_type        = neural_network_type,
                      neural_network_models_from = neural_network_models_from,
                      platform                   = platform,
                      beam_manager_type          = beam_manager_type,
                      beam_manager_ids           = beam_manager_ids,
                      previous_platform          = previous_platform,
                      previous_beam_manager_type = previous_beam_manager_type,
                      previous_beam_manager_ids  = previous_beam_manager_ids,
                      motor                      = motor,
                      plans_platform             = plans_platform,
                      plan_ids                   = plan_ids)

def set_ini_from_initialization_parameters(initialization_parameters: ScriptData, ini: IniFacade):
    optimizer_names            = initialization_parameters.get_parameter("optimizer_names")
    neural_network_models_from = initialization_parameters.get_parameter("neural_network_models_from")
    beam_manager_ids           = initialization_parameters.get_parameter("beam_manager_ids")
    previous_beam_manager_ids  = initialization_parameters.get_parameter("previous_beam_manager_ids")
    plan_ids                   = initialization_parameters.get_parameter("plan_ids")

    ini.set_value_at_ini("AI", "optimization, optimizer_type", value=initialization_parameters.get_parameter("optimizer_type"))

    for optimizer_type in optimizer_names.keys(): ini.set_value_at_ini("AI", f"optimization, {optimizer_type}, name", value=optimizer_names[optimizer_type])

    ini.set_value_at_ini("AI", "optimization, optimization_type", value=initialization_parameters.get_parameter("optimization_type"))
    ini.set_value_at_ini("AI", "neural_network, neural_network_type", value=initialization_parameters.get_parameter("neural_network_type"))

    for neural_network_type in neural_network_models_from.keys(): ini.set_value_at_ini("AI", f"neural_network, {neural_network_type}, neural_network_model_from", value=neural_network_models_from[neural_network_type])

    ini.set_value_at_ini("Driver", "platform",          value=initialization_parameters.get_parameter("platform"))
    ini.set_value_at_ini("Driver", "beam_manager_type", value=initialization_parameters.get_parameter("beam_manager_type"))

    for beam_manager_type in beam_manager_ids.keys(): ini.set_value_at_ini("Driver", f"beam_manager, {beam_manager_type}, beam_manager_id", value=beam_manager_ids[beam_manager_type])

    ini.set_value_at_ini("Driver", "previous, platform",          value=initialization_parameters.get_parameter("previous_platform"))
    ini.set_value_at_ini("Driver", "previous, beam_manager_type", value=initialization_parameters.get_parameter("previous_beam_manager_type"))

    for beam_manager_type in previous_beam_manager_ids.keys(): ini.set_value_at_ini("Driver", f"previous, beam_manager, {beam_manager_type}, beam_manager_id", value=previous_beam_manager_ids[beam_manager_type])

    ini.set_value_at_ini("Plans", "platform", value=initialization_parameters.get_parameter("plans_platform"))

    for platform in plan_ids.keys(): ini.set_value_at_ini("Plans", f"platforms, {platform}, plan_id", value=plan_ids[platform])

