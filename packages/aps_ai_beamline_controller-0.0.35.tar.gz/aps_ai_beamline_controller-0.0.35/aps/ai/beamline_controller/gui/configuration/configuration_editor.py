#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import sys

from aps.ai.beamline_controller.initialization.beamline_controller_configuration import BeamlineControllerConfiguration
from aps.beamline_driver.common.legacy_keys import Keys
from aps.beamline_driver.facade import MethodCallingType
from aps.beamline_driver.motion_management.facade import MotorInfo
from aps.beamline_driver.motion_management.motion_manager_factory import create_motion_manager
from aps.common.widgets.context_widget import PlottingProperties, DefaultMainWindow
from aps.common.plotter import get_registered_plotter_instance
from aps.common.initializer import get_registered_ini_instance

from aps.ai.beamline_controller.execution.configuration_manager import QtConfigurationManager

from aps.ai.beamline_controller.gui.configuration.configuration_editor_initialization_parameters import generate_initialization_parameters_from_ini, set_ini_from_initialization_parameters
from aps.ai.beamline_controller.gui.configuration.configuration_editor_widget import ConfigurationEditorWidget

APPLICATION_NAME = "Configuration Editor"
SHOW_MAIN        = APPLICATION_NAME + ": Main"

class IConfigurationEditor():
    def show_configuration_editor(self, plotting_properties=PlottingProperties(), **kwargs): raise NotImplementedError()

def create_configuration_editor(working_directory, optical_system_id, **kwargs):
    return _ConfigurationEditor(working_directory=working_directory, optical_system_id=optical_system_id, **kwargs)

class _ConfigurationEditor(QtConfigurationManager, IConfigurationEditor):
    def __init__(self, working_directory, optical_system_id, **kwargs):
        super(_ConfigurationEditor, self).__init__(APPLICATION_NAME, working_directory, optical_system_id, **kwargs)

        self._gui_ini        = get_registered_ini_instance(application_name=self._application_name + "-GUI" )
        self._gui_parameters = generate_initialization_parameters_from_ini(self._gui_ini)

    def reload_utils(self):
        super(_ConfigurationEditor, self).reload_utils()

        self._plotter = get_registered_plotter_instance(application_name=APPLICATION_NAME)

    def get_gui_parameters(self):
        return self._gui_parameters

    def save_configuration(self, configuration: BeamlineControllerConfiguration, **kwargs):
        super(_ConfigurationEditor, self).save_configuration(configuration=configuration)

        self.save_motors_info(new_motors_info=kwargs.get("motors_info"), configuration=configuration)

        set_ini_from_initialization_parameters(self._gui_parameters, self._gui_ini)
        self._gui_ini.push(verbose=True, configuration="Configuration Editor runtime parameters")

    def show_configuration_editor(self, plotting_properties=PlottingProperties(), **kwargs):
        if self._plotter.is_active():
            add_context_label = plotting_properties.get_parameter("add_context_label", False)
            use_unique_id     = plotting_properties.get_parameter("use_unique_id", False)

            self._plotter.register_context_window(SHOW_MAIN,
                                                  context_window=DefaultMainWindow(title=SHOW_MAIN),
                                                  use_unique_id=use_unique_id)

            self._plotter.push_plot_on_context(SHOW_MAIN, ConfigurationEditorWidget, None,
                                               working_directory=self._working_directory,
                                               optical_system_id=self._optical_system_id,
                                               available_beam_managers=self.get_available_beam_managers(),
                                               configuration=self.get_configuration(),
                                               gui_parameters=self._gui_parameters,
                                               save_configuration_method=self.save_configuration,
                                               close_method=self.close,
                                               load_motors_info_method=self.load_motors_info,
                                               set_current_motor_positions_as_initial_points_method=self.set_current_motor_positions_as_initial_points,
                                               allows_saving=False,
                                               **kwargs)
            self._plotter.draw_context(SHOW_MAIN, add_context_label=add_context_label, unique_id=None, **kwargs)
            self._plotter.raise_context_window(context_key=SHOW_MAIN, stay_on_top=False)
        else:
            raise ValueError("This function cannot be called without a GUI")

    def close(self):
        try:
            set_ini_from_initialization_parameters(self._gui_parameters, self._gui_ini)
            self._gui_ini.push(verbose=True, configuration="Configuration Editor runtime parameters")
        except:
            pass

        if self._plotter.is_active(): self._plotter.get_context_container_widget(context_key=SHOW_MAIN).parent().close()
        sys.exit(0)

