#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
import numpy as np
import matplotlib as mpl
import matplotlib.ticker as ticker
from matplotlib.figure import Figure

import cmasher as cmm

from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import Sampling
from aps.ai.beamline_controller.agent.optimization.moo.bayesian.facade import MOBOBayesianOptimizationResult
from aps.ai.beamline_controller.agent.optimization.moo.bayesian.common.pareto import get_best_trial_number, get_allowed_selection_algorithms
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationCriteria, OptimizationDirection
from aps.ai.beamline_controller.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.agent.optimization.moo.bayesian.abstract_hypervolume_manager import SelectionAlgorithm, AbstractBayesianHypervolumeManager


def plot_optimization_history(optimization_result: MOBOBayesianOptimizationResult,
                              pareto_front_data : MOBOBayesianOptimizationResult,
                              optimization_criteria: OptimizationCriteria,
                              plot_images: bool = True,
                              save_images: bool = False,
                              output_directory = os.path.abspath(os.getcwd()),
                              file_name_prefix = "current",
                              **kwargs):
    if optimization_result is None or optimization_result.is_empty(): return
    add_pareto_front_data = not pareto_front_data is None and not pareto_front_data.is_empty()

    plt             = kwargs.get("plt", None)
    loss_null_value = kwargs.get("loss_null_value", np.nan)

    if not plt: fig = Figure(figsize=(12, 10))  # create a combined figure
    else:       fig = plt.figure(kwargs.get("fignum", 1), figsize=(12, 10))

    ranges      = kwargs.get("ranges", {})
    trial_range = kwargs.get("trial_range", [0, -1])

    for idx in range(optimization_criteria.number):
        optimization_criterion = optimization_criteria.names[idx]

        objective_mean = np.array([(loss_function[optimization_criterion] if len(loss_function) > 0 else loss_null_value) for loss_function in optimization_result.get_loss_functions().values()])
        objective_mean[np.where(objective_mean == ERROR_LOSS)] = np.nan

        fig.add_subplot(optimization_criteria.number, 1, idx + 1)
        fig.gca().scatter(optimization_result.get_trial_numbers()[trial_range[0]: trial_range[1]], objective_mean[trial_range[0]: trial_range[1]], marker='o')
        fig.gca().set_xlabel("Iteration")
        fig.gca().set_ylabel(optimization_criterion)
        fig.gca().set_title("Objective Value vs. Iteration")
        fig.gca().grid(True)

        ylim = ranges.get(optimization_criterion, None)
        if not ylim is None:  fig.gca().set_ylim(ylim[0], ylim[-1])

        # add pareto points
        if add_pareto_front_data:
            pareto_objective_mean = np.array([loss_function[optimization_criterion] for loss_function in pareto_front_data.get_loss_functions().values()])
            pareto_objective_mean[np.where(pareto_objective_mean == ERROR_LOSS)] = np.nan

            filtered_pareto_trials         = []
            filtered_pareto_objective_mean = []
            for trial, mean in zip(pareto_front_data.get_trial_numbers(), pareto_objective_mean):
                if trial_range[0] <= trial <= trial_range[1]:
                    filtered_pareto_trials.append(trial)
                    filtered_pareto_objective_mean.append(mean)

            fig.gca().scatter(pareto_front_data.get_trial_numbers(), pareto_objective_mean, marker=r"$\odot$", label="PF")
        fig.gca().legend(loc="best")

    fig.subplots_adjust(hspace=0.5)

    if save_images:
        fig.savefig(os.path.join(os.path.abspath(output_directory), f"{file_name_prefix}_optimization_history.png"))
        fig.canvas.draw_idle()
    if plot_images:
        if not plt: fig.show()
        else:       plt.show()

    return fig

def plot_pareto_front_correlations(optimization_result: MOBOBayesianOptimizationResult,
                                   pareto_front_data : MOBOBayesianOptimizationResult,
                                   optimization_criteria: OptimizationCriteria,
                                   plot_images: bool = True,
                                   save_images: bool = False,
                                   output_directory = os.path.abspath(os.getcwd()),
                                   file_name_prefix = "current",
                                   **kwargs):
    if optimization_result is None or optimization_result.is_empty(): return
    if pareto_front_data is None or pareto_front_data.is_empty(): return

    plt             = kwargs.get("plt", None)
    loss_null_value = kwargs.get("loss_null_value", np.nan)

    figs = []
    trial_numbers        = optimization_result.get_trial_numbers()
    loss_history         = optimization_result.get_loss_functions().values()
    pareto_trial_numbers = pareto_front_data.get_trial_numbers()
    pareto_loss_history  = pareto_front_data.get_loss_functions().values()

    if plt: fignum = kwargs.pop("fignum", 1)

    for obj_x, obj_y in optimization_criteria.criteria_pairs:
        # Extract data
        objx_val = np.array([(loss_function[obj_x] if len(loss_function)>0 else loss_null_value) for loss_function in loss_history])
        objy_val = np.array([(loss_function[obj_y] if len(loss_function)>0 else loss_null_value)  for loss_function in loss_history])
        pareto_obj_x = np.array([loss_function[obj_x] for loss_function in pareto_loss_history])
        pareto_obj_y = np.array([loss_function[obj_y] for loss_function in pareto_loss_history])
        # Create figure and axis

        objx_val[np.where(objx_val == ERROR_LOSS)] = np.nan
        objy_val[np.where(objy_val == ERROR_LOSS)] = np.nan
        pareto_obj_x[np.where(pareto_obj_x == ERROR_LOSS)] = np.nan
        pareto_obj_y[np.where(pareto_obj_y == ERROR_LOSS)] = np.nan

        if not plt: fig = Figure(figsize=(6, 5), constrained_layout=True)
        else:
            fig = plt.figure(fignum, figsize=(6, 5), constrained_layout=True)
            fignum += 1

        ax  = fig.subplots()
        # Plot data on ax
        sc1 = ax.scatter(objx_val, objy_val + 1e-12, c=trial_numbers, cmap=cmm.tropical_r, marker="o", alpha=0.5,
                         norm=mpl.colors.Normalize(0, len(trial_numbers)))
        _ = ax.scatter(pareto_obj_x, pareto_obj_y + 1e-12, c=pareto_trial_numbers, cmap=cmm.tropical_r, marker=r"$\odot$",
                       s=175, norm=mpl.colors.Normalize(0, len(trial_numbers)), label="PF")
        for p, pareto_point_obj_x, pareto_point_obj_y in zip(pareto_trial_numbers, pareto_obj_x, pareto_obj_y):
            ax.annotate(p, xy=(pareto_point_obj_x, pareto_point_obj_y + 1e-8), xytext=(3, 3), textcoords="offset points")

        if (objx_val > 0).all(): ax.set_xscale("log")
        if (objy_val > 0).all(): ax.set_yscale("log")
        ax.set_xlabel(f"{obj_x}", fontsize=12)
        ax.set_ylabel(f"{obj_y}", fontsize=12)
        cbar = fig.colorbar(mappable=sc1, pad=0.03, aspect=25, shrink=0.75, location="right")
        cbar.ax.text(0.5, 1.02, "Trial", transform=cbar.ax.transAxes, ha='center', va='bottom')
        ax.legend(loc="best")

        if save_images:
            fig.savefig(os.path.join(os.path.abspath(output_directory), f"{file_name_prefix}_pareto_{obj_x}_vs_{obj_y}.png"))
            fig.canvas.draw_idle()
        if plot_images:
            if not plt: fig.show()
            else:       plt.show()

        figs.append(fig)

    if not plt: return figs
    else:       return figs, fignum


def plot_hypervolume(optimization_result: MOBOBayesianOptimizationResult,
                     pareto_front_data: MOBOBayesianOptimizationResult,
                     optimization_criteria: OptimizationCriteria,
                     plot_images: bool = True,
                     save_images: bool = False,
                     output_directory=os.path.abspath(os.getcwd()),
                     file_name_prefix="current",
                     **kwargs) -> Figure:
    plt = kwargs.get("plt", None)

    if not plt:  fig = Figure(figsize=(5.25, 7), constrained_layout=True)
    else:        fig = plt.figure(figsize=kwargs.get("figsize", (5.25, 7)), constrained_layout=True)

    has_pareto = not pareto_front_data is None and not pareto_front_data.is_empty()

    hypervolume = np.array([[item.trial_number, item.hypervolume]
                            for item in optimization_result.get_optimization_items()
                            if item.sampling == Sampling.OPTIMIZED])

    if len(hypervolume) > 0:
        if has_pareto: pareto = np.where(np.isin(hypervolume[:, 0], pareto_front_data.get_trial_numbers()))

        main_ax = fig.gca()
        main_ax.plot(hypervolume[:, 0], hypervolume[:, 1], marker='o', markersize=3, linestyle='-', linewidth=2, color='#625F5F', label='Hypervolume')
        if has_pareto: main_ax.scatter(hypervolume[pareto, 0], hypervolume[pareto, 1], marker='o', s=50, facecolor='none', edgecolors="orange", label='Pareto front')
        main_ax.set_xlabel("Trial Index", fontsize=16)
        main_ax.set_ylabel("Hypervolume (a.u.)", fontsize=16)
        main_ax.tick_params(axis='both', labelsize=12)

        formatter = ticker.ScalarFormatter(useMathText=True)
        formatter.set_powerlimits((0, 0))  # Force scientific notation
        formatter.set_scientific(True)  # Show ×10ⁿ
        main_ax.yaxis.set_major_formatter(formatter)

        if has_pareto:
            colors = {"oe": ['red', 'green', 'purple', 'blue'],
                      "spie": ['saddlebrown', 'darkcyan', 'darkorange', 'blueviolet']}
            for algorithm, color_bt in zip([SelectionAlgorithm.CLOSEST_TO_CENTER,
                                            SelectionAlgorithm.NARROWEST,
                                            SelectionAlgorithm.MOST_INTENSE,
                                            SelectionAlgorithm.NASH_EQUILIBRIUM],
                                           colors["oe"]):
                try:
                    best_trial = get_best_trial_number(pareto_front_data=pareto_front_data,
                                                       optimization_result_data=optimization_result,
                                                       optimization_criteria=optimization_criteria,
                                                       optimization_criteria_weights={},
                                                       optimization_initialization={criterion: AbstractBayesianHypervolumeManager.OptimizationItem(hypervolume_reference_point=0,
                                                                                                                                                   criterion_constraint=0,
                                                                                                                                                   criterion_weight=0,
                                                                                                                                                   is_logarithmic=False,
                                                                                                                                                   optimization_direction=OptimizationDirection.MINIMIZE) for criterion in optimization_criteria.names},
                                                       algorithm=algorithm)

                    cursor = np.where(hypervolume[:, 0] == best_trial)
                    main_ax.scatter(hypervolume[cursor, 0], hypervolume[cursor, 1], marker='o', s=100, facecolor=color_bt, edgecolors=color_bt, label=f"{algorithm.replace('-', ' ').capitalize()}")
                except Exception as e:
                    print(e)

        main_ax.legend(loc='center left', bbox_to_anchor=(0.7, 0.35), fontsize=9)

        if save_images:
            fig.savefig(os.path.join(os.path.abspath(output_directory), f"{file_name_prefix}_hypervolume-improvement.png"))
            fig.canvas.draw_idle()
        if plot_images:
            if not plt: fig.show()
            else:       plt.show()

    return fig
