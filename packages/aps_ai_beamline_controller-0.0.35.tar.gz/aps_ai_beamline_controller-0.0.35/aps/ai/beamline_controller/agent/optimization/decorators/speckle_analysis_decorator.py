#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

from typing import Tuple
from aps.beamline_driver.beam_management.abstract_beam_manager import SpeckleAnalysisProperties
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationDirection
from aps.ai.beamline_controller.agent.facade import ERROR_LOSS

from aps.ai.beamline_controller.agent.optimization.decorators.abstract_hypervolume_manager_decorator import AbstractHyperVolumeManagerDecorator

class SpeckleAnalysisOptimizationCriteria():
    FWHM_H = SpeckleAnalysisProperties.FWHM_H
    FWHM_V = SpeckleAnalysisProperties.FWHM_V

    __list = [FWHM_H, FWHM_V]

    @classmethod
    def to_list(cls): return cls.__list

    @classmethod
    def get_optimization_directions(cls): return {k : OptimizationDirection.MINIMIZE for k in cls.__list}

class SpeckleAnalysisHyperVolumeManagerDecorator(AbstractHyperVolumeManagerDecorator):
    def _get_managed_optimization_criteria(self) -> Tuple[list, dict]:
        return SpeckleAnalysisOptimizationCriteria.to_list(), SpeckleAnalysisOptimizationCriteria.get_optimization_directions()

    def _is_logarithmic_criterion(self, optimization_criterion : str) -> bool:
        return False

    def _initialize_optimization_criteria_functions(self, error_loss=ERROR_LOSS):
        def fwhm_h(beam_properties):
            return self._get_value_from_beam(beam_properties, SpeckleAnalysisOptimizationCriteria.FWHM_H, error_loss=error_loss)
        def fwhm_v(beam_properties):
            return self._get_value_from_beam(beam_properties, SpeckleAnalysisOptimizationCriteria.FWHM_V, error_loss=error_loss)

        return {SpeckleAnalysisOptimizationCriteria.FWHM_H: fwhm_h,
                SpeckleAnalysisOptimizationCriteria.FWHM_V: fwhm_v}
