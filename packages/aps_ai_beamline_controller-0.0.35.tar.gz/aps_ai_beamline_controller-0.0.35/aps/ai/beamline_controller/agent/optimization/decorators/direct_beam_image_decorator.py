#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import Tuple
from aps.beamline_driver.beam_management.abstract_beam_manager import DirectBeamImageProperties
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationDirection
from aps.ai.beamline_controller.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.agent.optimization.decorators.abstract_hypervolume_manager_decorator import AbstractHyperVolumeManagerDecorator

class DirectBeamImageOptimizationCriteria():
    CENTROID_H                      = DirectBeamImageProperties.CENTROID_H
    CENTROID_V                      = DirectBeamImageProperties.CENTROID_V
    CENTROID_SPHERICAL              = DirectBeamImageProperties.CENTROID_H[:-2] + "_spherical"
    PEAK_LOCATION_H                 = DirectBeamImageProperties.PEAK_LOCATION_H
    PEAK_LOCATION_V                 = DirectBeamImageProperties.PEAK_LOCATION_V
    PEAK_LOCATION_SPHERICAL         = DirectBeamImageProperties.PEAK_LOCATION_H[:-2] + "_spherical"
    FWHM_H                          = DirectBeamImageProperties.FWHM_H
    FWHM_V                          = DirectBeamImageProperties.FWHM_V
    FWHM_SPHERICAL                  = DirectBeamImageProperties.FWHM_H[:-2] + "_spherical"
    FWHM_CONVOLUTION                = DirectBeamImageProperties.FWHM_H[:-2] + "_convolution"
    SIGMA_H                         = DirectBeamImageProperties.SIGMA_H
    SIGMA_V                         = DirectBeamImageProperties.SIGMA_V
    SIGMA_SPHERICAL                 = DirectBeamImageProperties.SIGMA_H[:-2] + "_spherical"
    SIGMA_CONVOLUTION               = DirectBeamImageProperties.SIGMA_H[:-2] + "_convolution"
    NEGATIVE_LOG_PEAK_INTENSITY     = "negative-log-" + DirectBeamImageProperties.PEAK_INTENSITY
    LOG_WEIGHTED_INTEGRAL_INTENSITY = "log-weighted-" + DirectBeamImageProperties.INTEGRAL_INTENSITY
    LIKELIHOOD_2D                   = DirectBeamImageProperties.LIKELIHOOD_2D
    LIKELIHOOD_1D_H                 = DirectBeamImageProperties.LIKELIHOOD_1D_H
    LIKELIHOOD_1D_V                 = DirectBeamImageProperties.LIKELIHOOD_1D_V

    __list = [CENTROID_H,
              CENTROID_V,
              CENTROID_SPHERICAL,
              PEAK_LOCATION_H,
              PEAK_LOCATION_V,
              PEAK_LOCATION_SPHERICAL,
              FWHM_H,
              FWHM_V,
              FWHM_SPHERICAL,
              FWHM_CONVOLUTION,
              SIGMA_H,
              SIGMA_V,
              SIGMA_SPHERICAL,
              SIGMA_CONVOLUTION,
              NEGATIVE_LOG_PEAK_INTENSITY,
              LOG_WEIGHTED_INTEGRAL_INTENSITY,
              LIKELIHOOD_2D,
              LIKELIHOOD_1D_H,
              LIKELIHOOD_1D_V,]

    @classmethod
    def to_list(cls): return cls.__list

    @classmethod
    def get_optimization_directions(cls):
        return { k : OptimizationDirection.MINIMIZE for k in cls.to_list()}

class DirectBeamImageHyperVolumeManagerDecorator(AbstractHyperVolumeManagerDecorator):
    def _get_managed_optimization_criteria(self) -> Tuple[list, dict]:
        return DirectBeamImageOptimizationCriteria.to_list(), DirectBeamImageOptimizationCriteria.get_optimization_directions()

    def _is_logarithmic_criterion(self, optimization_criterion : str) -> bool:
        return optimization_criterion in [DirectBeamImageOptimizationCriteria.NEGATIVE_LOG_PEAK_INTENSITY,
                                          DirectBeamImageOptimizationCriteria.LOG_WEIGHTED_INTEGRAL_INTENSITY]

    def _initialize_optimization_criteria_functions(self, error_loss=ERROR_LOSS):
        def centroid_h(beam_properties):
            return self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.CENTROID_H, absolute=True, error_loss=error_loss)
        def centroid_v(beam_properties):
            return self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.CENTROID_V, absolute=True, error_loss=error_loss)
        def peak_location_h(beam_properties):
            return self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.PEAK_LOCATION_H, absolute=True, error_loss=error_loss)
        def peak_location_v(beam_properties):
            return self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.PEAK_LOCATION_V, absolute=True, error_loss=error_loss)
        def fwhm_h(beam_properties):
            return self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.FWHM_H, error_loss=error_loss)
        def fwhm_v(beam_properties):
            return self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.FWHM_V, error_loss=error_loss)
        def sigma_h(beam_properties):
            return self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.SIGMA_H, error_loss=error_loss)
        def sigma_v(beam_properties):
            return self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.SIGMA_V, error_loss=error_loss)
        def negative_log_peak_intensity(beam_properties):
            return self._get_negative_log_peak_intensity(beam_properties, error_loss=error_loss)
        def log_weighted_integral_intensity(beam_properties):
            return self._get_log_weighted_integral_intensity(beam_properties, error_loss=error_loss)
        def centroid_spherical(beam_properties):
            return self._get_spherical_value(self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.CENTROID_H, error_loss=error_loss),
                                             self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.CENTROID_V, error_loss=error_loss))
        def peak_distance_spherical(beam_properties):
            return self._get_spherical_value(self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.PEAK_LOCATION_H, error_loss=error_loss),
                                             self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.PEAK_LOCATION_V, error_loss=error_loss))
        def fwhm_spherical(beam_properties):
            return self._get_spherical_value(self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.FWHM_H, error_loss=error_loss),
                                             self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.FWHM_V, error_loss=error_loss))
        def sigma_spherical(beam_properties):
            return self._get_spherical_value(self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.SIGMA_H, error_loss=error_loss),
                                             self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.SIGMA_V, error_loss=error_loss))
        def fwhm_convolution(beam_properties):
            return self._get_convolution_value(self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.FWHM_H, error_loss=error_loss),
                                               self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.FWHM_V, error_loss=error_loss))
        def sigma_convolution(beam_properties):
            return self._get_convolution_value(self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.SIGMA_H, error_loss=error_loss),
                                               self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.SIGMA_V, error_loss=error_loss))
        def likelihood_2d(beam_properties):
            return 1 - self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.LIKELIHOOD_2D, error_loss=error_loss)
        def likelihood_1d_h(beam_properties):
            return 1 - self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.LIKELIHOOD_1D_H, error_loss=error_loss)
        def likelihood_1d_v(beam_properties):
            return 1 - self._get_value_from_beam(beam_properties, DirectBeamImageOptimizationCriteria.LIKELIHOOD_1D_V, error_loss=error_loss)

        return {DirectBeamImageOptimizationCriteria.CENTROID_H                     : centroid_h,
                DirectBeamImageOptimizationCriteria.CENTROID_V                     : centroid_v,
                DirectBeamImageOptimizationCriteria.CENTROID_SPHERICAL             : centroid_spherical,
                DirectBeamImageOptimizationCriteria.PEAK_LOCATION_H                : peak_location_h,
                DirectBeamImageOptimizationCriteria.PEAK_LOCATION_V                : peak_location_v,
                DirectBeamImageOptimizationCriteria.PEAK_LOCATION_SPHERICAL        : peak_distance_spherical,
                DirectBeamImageOptimizationCriteria.FWHM_H                         : fwhm_h,
                DirectBeamImageOptimizationCriteria.FWHM_V                         : fwhm_v,
                DirectBeamImageOptimizationCriteria.FWHM_SPHERICAL                 : fwhm_spherical,
                DirectBeamImageOptimizationCriteria.FWHM_CONVOLUTION               : fwhm_convolution,
                DirectBeamImageOptimizationCriteria.SIGMA_H                        : sigma_h,
                DirectBeamImageOptimizationCriteria.SIGMA_V                        : sigma_v,
                DirectBeamImageOptimizationCriteria.SIGMA_SPHERICAL                : sigma_spherical,
                DirectBeamImageOptimizationCriteria.SIGMA_CONVOLUTION              : sigma_convolution,
                DirectBeamImageOptimizationCriteria.NEGATIVE_LOG_PEAK_INTENSITY    : negative_log_peak_intensity,
                DirectBeamImageOptimizationCriteria.LOG_WEIGHTED_INTEGRAL_INTENSITY: log_weighted_integral_intensity,
                DirectBeamImageOptimizationCriteria.LIKELIHOOD_2D                  : likelihood_2d,
                DirectBeamImageOptimizationCriteria.LIKELIHOOD_1D_H                : likelihood_1d_h,
                DirectBeamImageOptimizationCriteria.LIKELIHOOD_1D_V                : likelihood_1d_v,}