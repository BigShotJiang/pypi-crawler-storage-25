#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from ax.api.client import Client

from aps.ai.beamline_controller.agent.optimization.common.bayesian.ax.ax_optimizer_decorator import AxOptimizerDecorator
from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import BayesianOptimizationResult, OptimizationTrialStatus
from aps.beamline_driver.beam_management.facade import IBeamManager
from aps.beamline_driver.motion_management.facade import IMotionManager
from aps.ai.beamline_controller.agent.facade import IAgentListener
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationDirection, OptimizationCriteria, OptimizationInitParameters, OptimizationType, OptimizationErrorMessages
from aps.ai.beamline_controller.agent.optimization.soo.bayesian.facade import SOBOBayesianOptimizationExecutionParameters, SOBOBayesianOptimizationResult
from aps.ai.beamline_controller.agent.optimization.soo.bayesian.abstract_optimizer import SOBOAbstractBayesianOptimizer

class AxOptimizer(SOBOAbstractBayesianOptimizer, AxOptimizerDecorator):
    def __init__(self, optimization_listener : IAgentListener, **kwargs):
        super(AxOptimizer, self).__init__(optimization_listener, **kwargs)

    def initialize_driver(self,
                          beam_manager : IBeamManager,
                          motion_manager : IMotionManager):
        super(AxOptimizer, self).initialize_driver(beam_manager, motion_manager)

        if self.requires_run_engine(): setattr(self, "_run_optimization", self.__run_optimization_generator)
        else:                          setattr(self, "_run_optimization", self.__run_optimization)

    # ------------------------------------------------------------------------------
    #  AbstractBayesianOptimizer implementation
    # ------------------------------------------------------------------------------

    def _create_objectives(self,
                           execution_parameters: SOBOBayesianOptimizationExecutionParameters,
                           motor_ids_to_optimize: list[str],
                           optimization_criteria: OptimizationCriteria,
                           optimization_parameters: OptimizationInitParameters,
                           search_ranges: dict[str, list]) -> tuple[str, list[float]]:
        hypervolume_reference_points = optimization_parameters.get_parameter("hypervolume_reference_points")
        hypervolume_reference_point  = 0.0

        for optimization_criterion in optimization_criteria.names:
            optimization_direction = optimization_parameters.get_parameter("optimization_directions")[optimization_criterion]

            if optimization_direction != OptimizationDirection.MINIMIZE: raise ValueError("Optimization Criteria in SOBO can only be minimized")

            if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR and execution_parameters.use_warm_start_hypervolume_reference_points:
                warm_start_hypervolume_reference_points = self._warm_start_data.get_warm_start_hypervolume_reference_points()
                hypervolume_reference_point  += warm_start_hypervolume_reference_points.get(optimization_criterion,
                                                                                           optimization_parameters.get_parameter("hypervolume_reference_points")[optimization_criterion])
            else:
                hypervolume_reference_point += hypervolume_reference_points[optimization_criterion]

        objective_string      = "-scalar_loss"
        threshold_constraints = [f"scalar_loss <= {hypervolume_reference_point}"]

        message = ["**************************************************"]
        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
            message.append("Surrogate Model pre-fit: True (attached " + str(self._warm_start_data.get_number_of_items()) + " trials)")
        else:
            message.append("Surrogate Model pre-fit: False")
        message.append("Search Space:")
        message.extend([" - " + motor_id + ":" + str(search_ranges[motor_id]) for motor_id in motor_ids_to_optimize])
        message.append("Hypervolume reference point: " + str(hypervolume_reference_point))
        message.append("**************************************************")

        self._optimization_listener.feedback(None, None, None, None, None, message=message)

        return objective_string, threshold_constraints

    def _create_optimization_agent(self, **kwargs):
        self._create_optimization_agent_decorator(**kwargs)

    # ------------------------------------------------------------------------------

    def __run_optimization(self, **kwargs) -> (int, dict):
        ax_client                 = self._optimization_agent
        execution_parameters      = self._execution_parameters
        input_parameters          = self._input_parameters
        current_timestamps        = {}
        current_raw_data          = {}
        exit_strategy_fulfilled   = False
        current_node_name = None

        self.__failed_trials = []
        loss_functions = {}

        new_model_index, trials_to_execute = self.__manage_transfer_learning_initialization(execution_parameters, input_parameters)

        for i in range(trials_to_execute):
            if self.interrupt or exit_strategy_fulfilled: break

            suggested_motor_positions, trial_index, current_node_name = self.__get_suggested_motor_positions(ax_client=ax_client,
                                                                                                             current_node_name=current_node_name,
                                                                                                             current_timestamps=current_timestamps)
            loss_function, error_message                                      = self.__evaluate_suggested_motor_positions(suggested_motor_positions=suggested_motor_positions,
                                                                                                                          trial_index=trial_index,
                                                                                                                          current_raw_data=current_raw_data)
            loss_functions[trial_index] = loss_function
            exit_strategy_fulfilled, trials_to_execute                        = self.__process_and_complete_trial(ax_client=ax_client,
                                                                                                                  error_message=error_message,
                                                                                                                  execution_parameters=execution_parameters,
                                                                                                                  exit_strategy_fulfilled=exit_strategy_fulfilled,
                                                                                                                  loss_function=loss_function,
                                                                                                                  trial_index=trial_index,
                                                                                                                  trials_to_execute=trials_to_execute)

        self._hypervolume_manager.set_loss_function_from_optimization(loss_functions)

        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR: return trials_to_execute + new_model_index, current_timestamps, current_raw_data
        else:                                                                                   return trials_to_execute,                   current_timestamps, current_raw_data

    def __run_optimization_generator(self, **kwargs) -> (int, dict):
        ax_client               = self._optimization_agent
        execution_parameters    = self._execution_parameters
        input_parameters        = self._input_parameters
        current_timestamps      = {}
        current_raw_data        = {}
        exit_strategy_fulfilled = False
        current_node_name       = None

        self.__failed_trials = []
        loss_functions       = {}

        new_model_index, trials_to_execute = self.__manage_transfer_learning_initialization(execution_parameters, input_parameters)

        for i in range(trials_to_execute):
            if self.interrupt or exit_strategy_fulfilled: break

            suggested_motor_positions, trial_index, current_node_name = self.__get_suggested_motor_positions(ax_client=ax_client,
                                                                                                             current_node_name=current_node_name,
                                                                                                             current_timestamps=current_timestamps)
            loss_function, error_message                                      = yield from self.__evaluate_suggested_motor_positions_generator(suggested_motor_positions=suggested_motor_positions,
                                                                                                                                               trial_index=trial_index,
                                                                                                                                               current_raw_data=current_raw_data)
            loss_functions[trial_index] = loss_function
            exit_strategy_fulfilled, trials_to_execute                        = self.__process_and_complete_trial(ax_client=ax_client,
                                                                                                                  error_message=error_message,
                                                                                                                  execution_parameters=execution_parameters,
                                                                                                                  exit_strategy_fulfilled=exit_strategy_fulfilled,
                                                                                                                  loss_function=loss_function,
                                                                                                                  trial_index=trial_index,
                                                                                                                  trials_to_execute=trials_to_execute)
        self._hypervolume_manager.set_loss_function_from_optimization(loss_functions)

        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR: return trials_to_execute + new_model_index, current_timestamps, current_raw_data
        else:                                                                                   return trials_to_execute,                   current_timestamps, current_raw_data

    def _bo_optimize_end(self, **kwargs) -> BayesianOptimizationResult:
        optimization_result: SOBOBayesianOptimizationResult = super(AxOptimizer, self)._bo_optimize_end(**kwargs)

        if len(self.__failed_trials) > 0:
            for trial_number in self.__failed_trials:
                item: SOBOBayesianOptimizationResult = optimization_result.get_optimization_item(trial_number)
                item.status = OptimizationTrialStatus.FAILED

        return optimization_result


    # ------------------------------------------------------------------------------
    #  OBJECTIVE FUNCTION METHODS
    # ------------------------------------------------------------------------------

    def __manage_transfer_learning_initialization(self, execution_parameters, input_parameters):
        return self._manage_transfer_learning_initialization_decorator(execution_parameters, input_parameters)

    def __get_suggested_motor_positions(self, ax_client: Client, current_node_name, current_timestamps):
        return self._get_suggested_motor_positions_decorator(ax_client, current_node_name, current_timestamps)

    def _manage_error(self, trial_index, optimization_criteria, motors_to_optimize, suggested_motor_positions, current_motors_positions):
        error_loss = self._manager_error_decorator(trial_index,
                                                   optimization_criteria,
                                                   motors_to_optimize,
                                                   suggested_motor_positions,
                                                   current_motors_positions)
        return error_loss["scalar_loss"]

    def __evaluate_suggested_motor_positions(self, suggested_motor_positions, trial_index, current_raw_data, is_first_trial):
        return self._evaluate_suggested_motor_positions_decorator(suggested_motor_positions, trial_index, current_raw_data, is_first_trial)

    def __evaluate_suggested_motor_positions_generator(self, suggested_motor_positions, trial_index, current_raw_data, is_first_trial):
        ret = yield from self._evaluate_suggested_motor_positions_generator_decorator(suggested_motor_positions, trial_index, current_raw_data, is_first_trial)
        return ret

    def __process_and_complete_trial(self, ax_client: Client, error_message, execution_parameters, exit_strategy_fulfilled, loss_function, trial_index, trials_to_execute):
        if error_message is None:
            ax_client.complete_trial(trial_index=trial_index, raw_data={"scalar_loss" : loss_function["scalar_loss"]})

            if execution_parameters.use_exit_strategy:
                exit_loss_function = execution_parameters.exit_loss_function
                exit_strategy_fulfilled = True
                if type(exit_loss_function) == float:
                    exit_strategy_fulfilled = loss_function["scalar_loss"] < exit_loss_function
                elif type(exit_loss_function) == dict:
                    for optimization_criterion in loss_function.keys():
                        if optimization_criterion == "scalar_loss":
                            continue
                        elif loss_function[optimization_criterion] > execution_parameters.exit_loss_function[optimization_criterion]:
                            exit_strategy_fulfilled = False
                            break
                if exit_strategy_fulfilled: trials_to_execute = trial_index + 1
        else:
            self._optimization_listener.feedback(trial_index, None, None, None, None, message=error_message)

            # all the trial should be marked as completed unless there is a transient error.
            # Marking failed will make the trial ignored and the optimizer won't learn that the motor positions provided a bad spot.
            # In case of error, the error message should be analyzed.
            # If the error is coming from the beam properties the trial should be marked completed, otherwhise can be discarded
            transient_error = (OptimizationErrorMessages.UNEXPECTED_ERROR_WHILE_SETTING_MOTORS in error_message or
                               OptimizationErrorMessages.UNEXPECTED_ERROR_WHILE_ANALYZING_BEAM in error_message or
                               OptimizationErrorMessages.CHECK_MOTOR_POSITIONS in error_message or
                               OptimizationErrorMessages.BLUESKY_REQUEST_ABORT in error_message or
                               OptimizationErrorMessages.BLUESKY_RUNENGINE_CONTROL_EXCEPTION in error_message)

            if transient_error:
                ax_client.mark_trial_failed(trial_index=trial_index, failed_reason=error_message)
            else:
                ax_client.complete_trial(trial_index=trial_index, raw_data={"scalar_loss" : loss_function["scalar_loss"]})
                self.__failed_trials.append(trial_index)


            ax_client.mark_trial_failed(trial_index=trial_index, failed_reason=error_message)

            if self._beam_manager.requires_interruption_on_error(error_message=error_message):
                self.interrupt = True # force conclusion
                self._optimization_listener.feedback(None, None, None, None, None,
                                                     message="Because of the error, the Beam Manager lost consistency, optimization interrupted")


        return exit_strategy_fulfilled, trials_to_execute


    # ---------------------------------------------------------------------
    # WARM-START
    # ---------------------------------------------------------------------

    @classmethod
    def _get_pareto_file_prefix(cls) -> str: return "ax_sobo_experiment"

    @classmethod
    def _get_ml_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()

    def _manage_transfer_learning_input(self, **kwargs):
        if self._execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR: raise NotImplementedError("SOBO does not support warm start")
        else:                                                                                         self._warm_start_data = None

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------

    @classmethod
    def _get_result_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()


