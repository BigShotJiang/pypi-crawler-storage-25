#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import abc
import traceback
from typing import Tuple
import numpy as np

from aps.beamline_driver.beam_management.facade import BeamProperties
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationCriteria, IHypervolumeManager, OptimizationInitParameters
from aps.ai.beamline_controller.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.agent.optimization.soo.nonlinear.facade import NonLinearOptimizationInputParameters

class INonlinearHypervolumeManager(IHypervolumeManager):
    @abc.abstractmethod
    def get_error_loss_function(self, optimization_criteria : OptimizationCriteria) -> float: raise NotImplementedError

class AbstractNonlinearHypervolumeManager(INonlinearHypervolumeManager):
    class OptimizationItem():
        def __init__(self,
                     criterion_constraint,
                     criterion_weight,
                     is_logarithmic):
            self.__criterion_constraint = criterion_constraint
            self.__criterion_weight = criterion_weight
            self.__is_logarithmic = is_logarithmic

        @property
        def criterion_constraint(self): return self.__criterion_constraint

        @property
        def criterion_weight(self): return self.__criterion_weight

        @property
        def is_logarithmic(self): return self.__is_logarithmic

    def __init__(self,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        self._optimization_criteria_constraints = optimization_criteria_constraints
        self._optimization_criteria_weights = optimization_criteria_weights

        self._managed_optimization_criteria, self._optimization_directions = self._get_managed_optimization_criteria()

        self._optimization_criteria_reference_values = {optimization_criterion: 0.0 for optimization_criterion in self._managed_optimization_criteria}
        if not optimization_criteria_reference_values is None: self._optimization_criteria_reference_values.update(optimization_criteria_reference_values)

        self._optimization_initialization = {}

        for optimization_criterion in self._managed_optimization_criteria:
            criterion_constraint = self._get_optimization_criterion_constraint(optimization_criterion)
            criterion_weight = self._get_optimization_criterion_weight(optimization_criterion)
            is_logarithmic = self._is_logarithmic_criterion(optimization_criterion)

            optimization_item = self.OptimizationItem(criterion_constraint,
                                                      criterion_weight,
                                                      is_logarithmic)

            self._optimization_initialization[optimization_criterion] = optimization_item

        self._optimization_criteria_functions = self._initialize_optimization_criteria_functions(ERROR_LOSS)

    '''
    from IHypervolumeManager interface
    '''

    def get_optimization_parameters(self,
                                    optimization_criteria: OptimizationCriteria,
                                    input_parameters: NonLinearOptimizationInputParameters,
                                    **kwargs) -> OptimizationInitParameters:
        optimization_criteria_constraints = {}
        is_logarithmic = {}

        for optimization_criterion in optimization_criteria.names:
            optimization_item = self._optimization_initialization[optimization_criterion]

            if not optimization_item.criterion_constraint is None: optimization_criteria_constraints[optimization_criterion] = optimization_item.criterion_constraint
            is_logarithmic[optimization_criterion] = optimization_item.is_logarithmic

        return OptimizationInitParameters(optimization_criteria_constraints=optimization_criteria_constraints,
                                          has_constraints=len(optimization_criteria_constraints.keys()) > 0,
                                          is_logarithmic=is_logarithmic)

    '''
    from IHypervolumeManager interface
    '''

    def evaluate_loss_function(self,
                               beam_properties: BeamProperties,
                               optimization_criteria: OptimizationCriteria,
                               **kwargs) -> (dict, int, str):
        loss_function = {"scalar_loss" : 0.0}
        error = 0
        message = ""

        for optimization_criterion in optimization_criteria.names:
            try:
                current_loss = self._get_optimization_criterion_loss(beam_properties, optimization_criterion)

                if current_loss == ERROR_LOSS:
                    message += ("" if error == 0 else "\n") + optimization_criterion + " provided an invalid value"
                    error    = 1
                elif np.isnan(current_loss) or np.isinf(current_loss):
                    current_loss = ERROR_LOSS
                    message     += ("" if error == 0 else "\n") + optimization_criterion + " is NaN or Inf"
                    error        = 1
            except Exception as e:
                current_loss = ERROR_LOSS
                message += ("" if error == 0 else "\n") + str(traceback.format_exc())
                error = 1

            loss_function[optimization_criterion] = current_loss
            loss_function["scalar_loss"] += current_loss

        return loss_function, error, message

    '''
    abstract methods to be implemented by the subclasses that acutally know the optimization criteria (related to the beam properties)
    '''

    @abc.abstractmethod
    def _get_managed_optimization_criteria(self) -> Tuple[list, dict]:
        raise NotImplementedError

    @abc.abstractmethod
    def _get_managed_acquisition_functions(self) -> dict:
        raise NotImplementedError

    def _get_optimization_direction(self, optimization_criterion: str) -> str:
        return self._optimization_directions[optimization_criterion]

    def _get_optimization_criterion_constraint(self, optimization_criterion: str) -> float:
        return self._optimization_criteria_constraints.get(optimization_criterion, None)

    def _get_optimization_criterion_weight(self, optimization_criterion: str) -> float:
        return self._optimization_criteria_weights.get(optimization_criterion, 1.0)

    @abc.abstractmethod
    def _is_logarithmic_criterion(self, optimization_criterion: str) -> bool:
        raise NotImplementedError

    @abc.abstractmethod
    def _initialize_optimization_criteria_functions(self, error_loss=ERROR_LOSS):
        raise NotImplementedError

    def _get_optimization_criterion_loss(self, beam_properties: BeamProperties, optimization_criterion: str):
        criterion_value  = self._get_optimization_criterion_value(beam_properties, optimization_criterion)
        criterion_weight = self._optimization_initialization[optimization_criterion].criterion_weight

        return criterion_weight * criterion_value

    def _get_optimization_criterion_value(self, beam_properties: BeamProperties, optimization_criterion: str):
        if self._optimization_initialization[optimization_criterion].is_logarithmic:
            value = self._optimization_criteria_functions[optimization_criterion](beam_properties) - \
                    self._optimization_criteria_reference_values[optimization_criterion]
        else:
            value = np.abs(self._optimization_criteria_functions[optimization_criterion](beam_properties) - \
                           self._optimization_criteria_reference_values[optimization_criterion])
        return value

    '''
    from INonlinearHypervolumeManager interface
    '''
    def get_error_loss_function(self, optimization_criteria) -> float:
        error_loss = {optimization_criterion: ERROR_LOSS for optimization_criterion in optimization_criteria.names}
        error_loss["scalar_loss"] = ERROR_LOSS*optimization_criteria.number

        return error_loss