#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import Tuple

from ax.adapter import Generators
from ax.generation_strategy.generation_strategy import GenerationStrategy
from ax.generation_strategy.generation_node import GenerationNode
from ax.generation_strategy.generator_spec import GeneratorSpec
from ax.generation_strategy.center_generation_node import CenterGenerationNode
from ax.generation_strategy.transition_criterion import MinTrials

from botorch.acquisition.multi_objective import qNoisyExpectedHypervolumeImprovement, MultiObjectiveMCAcquisitionFunction

class SobolMode:
    NO_SOBOL_NO_CENTER = 0
    SOBOL_ONLY         = 1
    CENTER_AND_SOBOL   = 2
    CENTER_ONLY        = 3


class SobolModels:
    SOBOL                  = "Sobol"
    CENTER_OF_SEARCH_SPACE = "CenterOfSearchSpace"

def get_default_generation_strategy(experiment_name: str,
                                    add_sobol: int = SobolMode.NO_SOBOL_NO_CENTER,
                                    sobol_seed: int = 42,
                                    sobol_trials: int = 6,
                                    has_discrete_search_space: bool = True,
                                    acquisition_function: MultiObjectiveMCAcquisitionFunction = qNoisyExpectedHypervolumeImprovement) -> GenerationStrategy:
    return _assemble_nodes(experiment_name=experiment_name,
                           add_sobol=add_sobol,
                           sobol_seed=sobol_seed,
                           sobol_trials=sobol_trials,
                           botorch_node=_get_botorch_node(has_discrete_search_space=has_discrete_search_space,
                                                          acquisition_function=acquisition_function))

# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------

def _get_botorch_node(has_discrete_search_space: bool,
                      acquisition_function: MultiObjectiveMCAcquisitionFunction) -> GenerationNode:
    try:    name = acquisition_function.__qualname__
    except: name = acquisition_function

    return GenerationNode(
        name=f"BoTorch_{name}",
        generator_specs=[
            GeneratorSpec(
                generator_enum=Generators.BOTORCH_MODULAR,
                generator_kwargs={
                    "botorch_acqf_class": acquisition_function
                },
                generator_gen_kwargs={
                    "model_gen_options": {"optimizer_kwargs": _get_optimizer_args(has_discrete_search_space=has_discrete_search_space)}
                }
            )
        ],
    )


# ----------------------------------------------------------------------

def _get_sobol_node(sobol_trials: int, transition_to: str, seed: int = 42, add_center_node: bool = True) -> Tuple[GenerationNode | None, GenerationNode]:
    if add_center_node:
        center_node = CenterGenerationNode(next_node_name=SobolModels.SOBOL)
    else:
        center_node = None

    sobol_node = GenerationNode(
        name=SobolModels.SOBOL,
        generator_specs=[
            GeneratorSpec(
                generator_enum=Generators.SOBOL,
                generator_kwargs={"seed": seed},
            )
        ],
        transition_criteria=[
            MinTrials(
                threshold=sobol_trials,
                transition_to=transition_to,
                use_all_trials_in_exp=True,
            )
        ],
    )
    return center_node, sobol_node

# ----------------------------------------------------------------------

def _get_optimizer_args(has_discrete_search_space: bool) -> dict:
    optimizer_kwargs = {"num_restarts": 20,
                        "raw_samples": 512}
    if not has_discrete_search_space:
        discrete_search_space_args = {"sequential": False,
                                      "options": {"batch_limit": 5,
                                                  "maxiter": 200}}
        optimizer_kwargs.update(discrete_search_space_args)

    return optimizer_kwargs

# ----------------------------------------------------------------------

def _assemble_nodes(experiment_name: str,
                    add_sobol: int,
                    sobol_seed: int,
                    sobol_trials: int,
                    botorch_node: GenerationNode):
    if add_sobol == SobolMode.SOBOL_ONLY:
        _, sobol_node = _get_sobol_node(sobol_trials=sobol_trials,
                                        transition_to=botorch_node.name,
                                        seed=sobol_seed,
                                        add_center_node=False)

        generation_strategy = GenerationStrategy(name=experiment_name,
                                                 nodes=[sobol_node, botorch_node])
    elif add_sobol == SobolMode.CENTER_AND_SOBOL:
        center_node, sobol_node = _get_sobol_node(sobol_trials=sobol_trials,
                                                  transition_to=botorch_node.name,
                                                  seed=sobol_seed,
                                                  add_center_node=True)

        generation_strategy = GenerationStrategy(name=experiment_name,
                                                 nodes=[center_node, sobol_node, botorch_node])
    elif add_sobol == SobolMode.CENTER_ONLY:
        center_node = CenterGenerationNode(next_node_name=botorch_node.name)

        generation_strategy = GenerationStrategy(name=experiment_name,
                                                 nodes=[center_node, botorch_node])
    elif add_sobol == SobolMode.NO_SOBOL_NO_CENTER:
        generation_strategy = GenerationStrategy(name=experiment_name,
                                                 nodes=[botorch_node])
    else:
        raise ValueError(f"Unknown sobol mode {add_sobol}")

    return generation_strategy


