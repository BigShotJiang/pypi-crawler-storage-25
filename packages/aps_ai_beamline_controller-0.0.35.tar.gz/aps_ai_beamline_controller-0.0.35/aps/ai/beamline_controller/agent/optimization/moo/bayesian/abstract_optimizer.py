#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc
import os
from typing import List
from matplotlib.figure import Figure

from aps.beamline_driver.beam_management.facade import BeamProperties, Beam

from aps.ai.beamline_controller.agent.optimization.facade import OptimizationCriteria, OptimizationType
from aps.ai.beamline_controller.agent.facade import Format, IAgentListener
from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import BayesianOptimizationResult, BayesianOptimizationResultItem
from aps.ai.beamline_controller.agent.optimization.common.bayesian.abstract_optimizer import AbstractBayesianOptimizer, TrialNumbersFilter
from aps.ai.beamline_controller.agent.optimization.moo.bayesian.facade import SelectionAlgorithm, MOBOBayesianOptimizationExecutionParameters
from aps.ai.beamline_controller.agent.optimization.moo.bayesian.common import plot_utility

class IMOBOBayesianOptimizer:
    # ---------------------------------------------------------------------
    # POST-PROCESSING
    # ---------------------------------------------------------------------
    @abc.abstractmethod
    def get_pareto_front_data(self, **kwargs) -> BayesianOptimizationResult: raise NotImplementedError

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------
    @abc.abstractmethod
    def save_pareto_front(self, format=Format.CSV, **kwargs): raise NotImplementedError
    @abc.abstractmethod
    def plot_pareto_front(self, optimization_criteria: OptimizationCriteria = None, plot_images: bool=True, save_images: bool=False, **kwargs): raise NotImplementedError


# -------------------------------------------------------------
# ABSTRACT CLASS
# -------------------------------------------------------------

class MOBOAbstractBayesianOptimizer(AbstractBayesianOptimizer, IMOBOBayesianOptimizer):
    def __init__(self, optimization_listener: IAgentListener, **kwargs):
        AbstractBayesianOptimizer.__init__(self, optimization_listener, **kwargs)

    def _bo_optimize_end(self, **kwargs) -> BayesianOptimizationResult:
        optimization_criteria = self._optimization_criteria
        execution_parameters: MOBOBayesianOptimizationExecutionParameters = self._execution_parameters

        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:  warm_start_trial_numbers = self._warm_start_data.get_trial_numbers()
        else:                                                                                    warm_start_trial_numbers = None

        self._pareto_front_data: BayesianOptimizationResult = self._hypervolume_manager.extract_pareto_front_data(self._optimization_agent,
                                                                                                                  optimization_criteria,
                                                                                                                  trial_numbers=warm_start_trial_numbers,
                                                                                                                  trial_numbers_filter=TrialNumbersFilter.EXCLUDE)
        self._pareto_front_data.set_timestamps(self._current_timestamps)

        if   self._get_raw_data_type() == Beam: self._pareto_front_data.set_beams(self._current_raw_data)
        elif self._get_raw_data_type() == str:  self._pareto_front_data.set_beam_hex_strings(self._current_raw_data)
        else: raise ValueError("Raw data type not supported")

        optimization_result: BayesianOptimizationResult = self._hypervolume_manager.extract_optimization_result_data(self._optimization_agent,
                                                                                                                     optimization_criteria,
                                                                                                                     trial_numbers=warm_start_trial_numbers,
                                                                                                                     trial_numbers_filter=TrialNumbersFilter.EXCLUDE)

        if not (self._pareto_front_data is None or self._pareto_front_data.is_empty()): optimization_result.mark_pareto_frontier(self._pareto_front_data.get_trial_numbers())

        return optimization_result

    def _get_best_trial_data_after_optimization(self,
                                                optimization_result: BayesianOptimizationResult,
                                                execution_parameters: MOBOBayesianOptimizationExecutionParameters):
        return self.get_best_trial_data(optimization_result, execution_parameters.selection_algorithm)


    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------

    def _manage_transfer_learning_output(self, **kwargs):
        super(AbstractBayesianOptimizer, self)._manage_transfer_learning_output(**kwargs)

        execution_parameters: MOBOBayesianOptimizationExecutionParameters = self._execution_parameters

        if execution_parameters.save_warm_start_data:
            pareto_front_data           = self._pareto_front_data
            pareto_front_data_directory = execution_parameters.pareto_data_directory

            if not (pareto_front_data is None or pareto_front_data.is_empty()):
                try: pareto_front_data.to_pickle(os.path.join(pareto_front_data_directory, f"{self._get_pareto_file_prefix()}_{self._get_date_string()}_pareto.pkl"))
                except: print("Pareto front data not saved")
            else:
                print("Pareto front data are empty")


    # ---------------------------------------------------------------------
    # POST-PROCESSING
    # ---------------------------------------------------------------------

    def get_best_trial_data(self, optimization_result: BayesianOptimizationResult = None, algorithm=SelectionAlgorithm.NASH_EQUILIBRIUM, **kwargs) -> (BayesianOptimizationResultItem, BeamProperties):
        pareto_front_data = self._pareto_front_data
        if pareto_front_data is None or pareto_front_data.is_empty(): raise ValueError(f'Pareto front is empty')

        best_trial_number = self._hypervolume_manager.get_best_trial_number(self._optimization_agent, self._optimization_criteria, algorithm, pareto_front_data)
        best_trial_data   = pareto_front_data.get_optimization_item(best_trial_number)

        if kwargs.get("check_beam", False):
            kwargs["is_first_trial"] = (best_trial_number == self._optimization_result.get_trial_numbers()[0])
            beam_properties = self._get_beam_properties(best_trial_number,
                                                        best_trial_data.beam,
                                                        f"{self._get_pareto_file_prefix()}_best_beam_trial_{best_trial_number}.png",
                                                        **kwargs)
        else:
            beam_properties = None

        return best_trial_data, beam_properties

    def get_pareto_front_data(self, **kwargs) -> BayesianOptimizationResult: return self._pareto_front_data

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------

    def plot_optimization_history(self, optimization_criteria: OptimizationCriteria = None, plot_images: bool=True, save_images: bool=False, **kwargs) -> Figure:
        return plot_utility.plot_optimization_history(optimization_result=self._optimization_result,
                                                      pareto_front_data=self._pareto_front_data,
                                                      optimization_criteria=self._optimization_criteria if optimization_criteria is None else optimization_criteria,
                                                      plot_images=plot_images,
                                                      save_images=save_images,
                                                      output_directory=self._execution_parameters.experiment_output_directory,
                                                      file_name_prefix=self._get_result_file_prefix(),
                                                      **kwargs)

    def save_pareto_front(self, format=Format.PICKLE, **kwargs):
        if self._pareto_front_data is None: raise ValueError("There aren't any pareto front data to save")

        file_name = os.path.join(self._execution_parameters.experiment_output_directory,
                                 f"{self._get_pareto_file_prefix()}_pareto_front_{self._get_date_string()}")

        try:
            if   format == Format.CSV:    self._pareto_front_data.to_csv(file_name=file_name + ".csv")
            elif format == Format.PICKLE: self._pareto_front_data.to_pickle(file_name=file_name + ".pkl")
            elif format == Format.JSON:   self._pareto_front_data.to_json(file_name=file_name + ".json")
            else: raise ValueError("Format not supported")
        except Exception as e:
            print("Pareto not saved: " + str(e))

    def plot_pareto_front(self, optimization_criteria: OptimizationCriteria = None,  plot_images: bool=True, save_images: bool=False, **kwargs) -> List[Figure]:
        return plot_utility.plot_pareto_front_correlations(optimization_result=self._optimization_result,
                                                           pareto_front_data=self._pareto_front_data,
                                                           optimization_criteria=self._optimization_criteria if optimization_criteria is None else optimization_criteria,
                                                           plot_images=plot_images,
                                                           save_images=save_images,
                                                           output_directory=self._execution_parameters.experiment_output_directory,
                                                           file_name_prefix=self._get_result_file_prefix(),
                                                           **kwargs)

    def plot_hypervolume(self, optimization_criteria: OptimizationCriteria = None,  plot_images: bool=True, save_images: bool=False, **kwargs) -> Figure:
        return plot_utility.plot_hypervolume(optimization_result=self._optimization_result,
                                             pareto_front_data=self._pareto_front_data,
                                             optimization_criteria=self._optimization_criteria if optimization_criteria is None else optimization_criteria,
                                             plot_images=plot_images,
                                             save_images=save_images,
                                             output_directory=self._execution_parameters.experiment_output_directory,
                                             file_name_prefix=self._get_result_file_prefix(),
                                             **kwargs)