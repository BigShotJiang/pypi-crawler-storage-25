#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import Any

class OptimizationListenerDecorator():
    @classmethod
    def prepare_feedback(cls, trial_index: int, motors_to_optimize : list, suggested_motor_positions: dict, actual_motor_positions: dict, current_loss : list | dict | Any, **kwargs):
        text_list = []

        if not suggested_motor_positions is None: suggested_motor_positions = {motor_id: float(suggested_motor_positions[motor_id]) for motor_id in suggested_motor_positions}
        if not actual_motor_positions is None:    actual_motor_positions    = {motor_id: float(actual_motor_positions[motor_id]) for motor_id in actual_motor_positions}
        if not current_loss is None:
            if isinstance(current_loss, list):    current_loss = [float(current_loss) for current_loss in current_loss]
            elif isinstance(current_loss, dict):  current_loss = {obj : float(current_loss[obj]) for obj in current_loss}
            else:                                 current_loss = float(current_loss)

        if not trial_index is None:               text_list.append(f"Trial Number: {int(trial_index)}\n")
        if not motors_to_optimize is None:        text_list.append(f"Motors to optimize: {motors_to_optimize}\n")
        if not suggested_motor_positions is None: text_list.append(f"Suggested Motor Positions: {suggested_motor_positions}\n")
        if not actual_motor_positions is None:           text_list.append(f"Actual Motor Positions   : {actual_motor_positions}\n")
        if not current_loss is None:              text_list.append(f"Current Loss: {current_loss}\n")

        message = kwargs.get("message", None)
        if not message is None:
            if isinstance(message, str):    text_list.append(message)
            elif isinstance(message, list): text_list.extend([line for line in message])

        return text_list