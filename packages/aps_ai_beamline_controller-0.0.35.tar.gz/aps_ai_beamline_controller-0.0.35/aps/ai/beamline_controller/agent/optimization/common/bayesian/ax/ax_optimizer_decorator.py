#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import random
import traceback
import warnings

import numpy as np
from time import time

import torch
from bluesky.utils import RequestAbort, RunEngineControlException
from botorch.models import ModelList
from torch.nn import ModuleList
from ax.api.client import Client
from ax.api.configs import RangeParameterConfig, ChoiceParameterConfig

from aps.ai.beamline_controller.agent.machine_learning.surrogates.facade import SurrogateAction
from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import BayesianOptimizationExecutionParameters, BayesianOptimizationInputParameters
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationCriteria, OptimizationInitParameters, WarmStartDataType, OptimizationType, OptimizationErrorMessages
from aps.ai.beamline_controller.agent.optimization.common.bayesian.ax.generation_strategy_factory import get_default_generation_strategy, SobolMode

from aps.ai.beamline_controller.agent.machine_learning.surrogates.ax.generation_strategy_factory import get_nn_generation_strategy, get_dkl_generation_strategy, get_bnn_generation_strategy
from aps.ai.beamline_controller.agent.machine_learning.surrogates.ax.model_pretraining import load_training_data, reset_pre_training_botorch_nn, reset_pre_training_botorch_bnn, reset_pre_training_botorch_dkl

import logging
logging.getLogger("ax").setLevel(logging.CRITICAL)

class AxOptimizerDecorator(object):

    # ------------------------------------------------------------------------------
    #  AbstractBayesianOptimizer implementation
    # ------------------------------------------------------------------------------

    def _create_optimization_agent_decorator(self, **kwargs):
        warnings.filterwarnings('ignore')

        optimization_criteria: OptimizationCriteria                   = self._optimization_criteria
        execution_parameters: BayesianOptimizationExecutionParameters = self._execution_parameters
        input_parameters: BayesianOptimizationInputParameters         = self._input_parameters
        optimization_parameters: OptimizationInitParameters           = self._optimization_parameters

        motors_to_optimize        = input_parameters.motors_to_optimize
        motor_ids_to_optimize     = list(motors_to_optimize.keys())
        use_discrete_search_space = input_parameters.get_parameter("use_discrete_search_space", default=True)

        # ---------------------------------------------------------------
        # parameters list
        #
        if execution_parameters.optimization_type in [OptimizationType.FULL_START, OptimizationType.WARM_START_DIFFERENT_DETECTOR]:
            search_ranges = {motor_id: motors_to_optimize[motor_id]["search_range"] for motor_id in motor_ids_to_optimize}
            if use_discrete_search_space: search_spaces = {motor_id: motors_to_optimize[motor_id]["search_space"] for motor_id in motor_ids_to_optimize}
        elif execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
            if execution_parameters.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL:
                raise NotImplementedError("Pretrained Model are not supported by this optimizer, yet")
            else:
                if execution_parameters.use_warm_start_search_space: # in case of warm start, the beam_manager_id is embedded in the directory
                    search_ranges = self._warm_start_data.get_warm_start_search_ranges()
                    if use_discrete_search_space:
                        search_spaces = self._warm_start_data.get_warm_start_search_spaces(self._motion_manager)
                        for motor_id in motor_ids_to_optimize:
                            if len(search_spaces[motor_id]) < 2: search_spaces[motor_id] = motors_to_optimize[motor_id]["search_space"]
                else:
                    search_ranges = {motor_id : motors_to_optimize[motor_id]["search_range"] for motor_id in motor_ids_to_optimize}
                    if use_discrete_search_space: search_spaces = {motor_id : motors_to_optimize[motor_id]["search_space"] for motor_id in motor_ids_to_optimize}
        else:
            raise ValueError("Unknown optimization type")

        has_discrete_search_space = False
        if use_discrete_search_space:
            parameters_list = []
            for motor_id in motor_ids_to_optimize:
                if len(search_spaces[motor_id]) <= 1000:
                    parameters_list.append(ChoiceParameterConfig(
                        name=motor_id,
                        values=search_spaces[motor_id],
                        parameter_type='float',
                        is_ordered=True
                    ))
                    has_discrete_search_space = True
                else:
                    parameters_list.append(RangeParameterConfig(
                        name=motor_id,
                        bounds=search_ranges[motor_id],
                        parameter_type='float'
                    ))
        else:
            parameters_list = [
                RangeParameterConfig(
                    name=motor_id,
                    bounds=search_ranges[motor_id],
                    parameter_type='float') for motor_id in motor_ids_to_optimize]

        # ---------------------------------------------------------------
        # objectives

        objective_string, threshold_constraints = self._create_objectives(execution_parameters, motor_ids_to_optimize, optimization_criteria, optimization_parameters, search_ranges)

        # ---------------------------------------------------------------
        # Creation of the AxClient

        acquisition_function = optimization_parameters.get_parameter("acquisition_function") # qNoisyExpectedHypervolumeImprovement
        experiment_name      = 'Ax_MOO_experiment'
        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR: experiment_name += '_warm_start'

        add_center_node  = optimization_parameters.get_parameter("add_center_node", False)
        surrogate        = optimization_parameters.get_parameter("surrogate", "Default")
        surrogate_action = optimization_parameters.get_parameter("surrogate", SurrogateAction.NOTHING)
        verbose          = optimization_parameters.get_parameter("verbose", False)

        sobol_trials = max(input_parameters.sobol_trials, optimization_criteria.number * 3) + (1 if add_center_node else 0)
        sobol_seed = input_parameters.random_seed

        random.seed(input_parameters.random_seed)
        np.random.seed(input_parameters.random_seed)

        if add_center_node: self._optimization_listener.feedback(None, None, None, None, None, message=[f"Nr of Center+Sobol Trials: {input_parameters.sobol_trials} -> {sobol_trials} (adjusted)"])
        else:               self._optimization_listener.feedback(None, None, None, None, None, message=[f"Nr of Sobol Trials: {input_parameters.sobol_trials} -> {sobol_trials} (adjusted)"])

        torch.set_default_dtype(torch.float64)

        if surrogate_action == SurrogateAction.NOTHING:
            model_directory = None
            pre_train_X = None
            pre_train_Y = None
        else:
            model_directory = execution_parameters.ml_data_directory
            if surrogate_action == SurrogateAction.TRAIN_MODEL:
                pre_train_X, pre_train_Y = load_training_data(input_data_directory=execution_parameters.ml_data_directory,
                                                              motor_ids=motor_ids_to_optimize,
                                                              optimization_criteria=optimization_criteria,
                                                              listener=self._optimization_listener)

            else:
                pre_train_X = None
                pre_train_Y = None

        if surrogate == "Default":
            if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
                generation_strategy = get_default_generation_strategy(experiment_name=experiment_name,
                                                                      add_sobol=SobolMode.CENTER_ONLY if add_center_node else SobolMode.NO_SOBOL_NO_CENTER,
                                                                      has_discrete_search_space=has_discrete_search_space,
                                                                      acquisition_function=acquisition_function)
            else:
                generation_strategy = get_default_generation_strategy(experiment_name=experiment_name,
                                                                      add_sobol=SobolMode.CENTER_AND_SOBOL if add_center_node else SobolMode.SOBOL_ONLY,
                                                                      sobol_trials=sobol_trials,
                                                                      sobol_seed=sobol_seed,
                                                                      has_discrete_search_space=has_discrete_search_space,
                                                                      acquisition_function=acquisition_function)
        elif surrogate == "NN-Botorch":
            if surrogate_action == SurrogateAction.TRAIN_MODEL: reset_pre_training_botorch_nn(input_data_directory=execution_parameters.ml_data_directory,
                                                                                              optimization_criteria=optimization_criteria)

            if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
                generation_strategy = get_nn_generation_strategy(experiment_name=experiment_name,
                                                                 add_sobol=SobolMode.CENTER_ONLY if add_center_node else SobolMode.NO_SOBOL_NO_CENTER,
                                                                 has_discrete_search_space=has_discrete_search_space,
                                                                 action=surrogate_action,
                                                                 pre_train_X=pre_train_X,
                                                                 pre_train_Y=pre_train_Y,
                                                                 model_directory=model_directory)
            else:
                generation_strategy = get_nn_generation_strategy(experiment_name=experiment_name,
                                                                 add_sobol=SobolMode.CENTER_AND_SOBOL if add_center_node else SobolMode.SOBOL_ONLY,
                                                                 sobol_trials=sobol_trials,
                                                                 sobol_seed=sobol_seed,
                                                                 has_discrete_search_space=has_discrete_search_space,
                                                                 action=surrogate_action,
                                                                 pre_train_X=pre_train_X,
                                                                 pre_train_Y=pre_train_Y,
                                                                 model_directory=model_directory)

        elif surrogate == "DKL-Botorch":
            if surrogate_action == SurrogateAction.TRAIN_MODEL: reset_pre_training_botorch_dkl(input_data_directory=execution_parameters.ml_data_directory,
                                                                                               optimization_criteria=optimization_criteria)

            if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
                generation_strategy = get_dkl_generation_strategy(experiment_name=experiment_name,
                                                                  add_sobol=SobolMode.CENTER_ONLY if add_center_node else SobolMode.NO_SOBOL_NO_CENTER,
                                                                  has_discrete_search_space=has_discrete_search_space,
                                                                  action=surrogate_action,
                                                                  pre_train_X=pre_train_X,
                                                                  pre_train_Y=pre_train_Y,
                                                                  model_directory=model_directory)
            else:
                generation_strategy = get_dkl_generation_strategy(experiment_name=experiment_name,
                                                                  add_sobol=SobolMode.CENTER_AND_SOBOL if add_center_node else SobolMode.SOBOL_ONLY,
                                                                  sobol_trials=sobol_trials,
                                                                  sobol_seed=sobol_seed,
                                                                  has_discrete_search_space=has_discrete_search_space,
                                                                  action=surrogate_action,
                                                                  pre_train_X=pre_train_X,
                                                                  pre_train_Y=pre_train_Y,
                                                                  model_directory=model_directory)
        elif surrogate == "BNN-Botorch":
            if surrogate_action == SurrogateAction.TRAIN_MODEL: reset_pre_training_botorch_bnn(input_data_directory=execution_parameters.ml_data_directory,
                                                                                               optimization_criteria=optimization_criteria)

            if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
                generation_strategy = get_bnn_generation_strategy(experiment_name=experiment_name,
                                                                  add_sobol=SobolMode.CENTER_ONLY if add_center_node else SobolMode.NO_SOBOL_NO_CENTER,
                                                                  has_discrete_search_space=has_discrete_search_space,
                                                                  action=surrogate_action,
                                                                  pre_train_X=pre_train_X,
                                                                  pre_train_Y=pre_train_Y,
                                                                  model_directory=model_directory,
                                                                  verbose=verbose)
            else:
                generation_strategy = get_bnn_generation_strategy(experiment_name=experiment_name,
                                                                  add_sobol=SobolMode.CENTER_AND_SOBOL if add_center_node else SobolMode.SOBOL_ONLY,
                                                                  sobol_trials=sobol_trials,
                                                                  sobol_seed=sobol_seed,
                                                                  has_discrete_search_space=has_discrete_search_space,
                                                                  action=surrogate_action,
                                                                  pre_train_X=pre_train_X,
                                                                  pre_train_Y=pre_train_Y,
                                                                  model_directory=model_directory,
                                                                  verbose=verbose)
        else:
            raise ValueError("Unknown surrogate {}".format(surrogate))

        self._optimization_listener.feedback(None, None, None, None, None, message=[f"Nr of MOBO Trials: {input_parameters.bo_trials}"])

        ax_client = Client(random_seed=input_parameters.random_seed)
        ax_client.configure_experiment(name=experiment_name, parameters=parameters_list)
        ax_client.configure_optimization(objective=objective_string, outcome_constraints=threshold_constraints)
        ax_client.set_generation_strategy(generation_strategy=generation_strategy)

        return ax_client

    # ------------------------------------------------------------------------------
    #  OBJECTIVE FUNCTION METHODS
    # ------------------------------------------------------------------------------

    def _manage_transfer_learning_initialization_decorator(self, execution_parameters, input_parameters):
        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
            trials_to_execute = input_parameters.bo_trials
            new_model_index = self._warm_start_data.get_number_of_items() if not execution_parameters.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL else 0
        else:
            trials_to_execute = input_parameters.bo_trials + input_parameters.sobol_trials
            new_model_index = input_parameters.sobol_trials
        return new_model_index, trials_to_execute

    # ------------------------------------------------------------------------------

    @classmethod
    def __extract_model_from_client(cls, generator):
        try:
            if isinstance(generator.surrogate.model, ModelList):
                for _, model in enumerate(generator.surrogate.model.children()):
                    if isinstance(model, ModuleList):
                        for _, module in enumerate(model.children()):
                            surrogate_model = module.__class__.__qualname__
                            break  # first only
                    else:
                        surrogate_model = model.__class__.__qualname__
                    break  # first only
            else:
                surrogate_model = generator.surrogate.model.__class__.__qualname__
        except:
            surrogate_model = "Undetermined"

        return surrogate_model

    def _get_suggested_motor_positions_decorator(self, ax_client: Client, current_node_name, current_timestamps):
        trials = ax_client.get_next_trials(max_trials=1)
        trial_index, suggested_motor_positions = next(iter(trials.items()))
        current_timestamps[trial_index] = [time(), time()]

        node_name = ax_client._generation_strategy.current_node_name
        if node_name != current_node_name:
            acquisition_function = self._optimization_parameters.get_parameter("acquisition_function")
            message = []
            try:
                generator = ax_client._generation_strategy.adapter.generator

                if node_name == "Sobol":
                    surrogate_type = "None"
                    acquisition_function_name = "Sobol Random"
                else:
                    surrogate_type = self.__extract_model_from_client(generator=generator)
                    try:
                        acquisition_function_name = acquisition_function.__qualname__
                    except:
                        acquisition_function_name = str(acquisition_function)

                message.append("")
                message.append(f'**************************************************')
                message.append(f'BoTorch model starts at trial {trial_index}')
                message.append(f'BoTorchModel:           {generator.__class__.__qualname__.replace("Generator", "")}')
                message.append(f'BoTorch Surrogate type: {surrogate_type}')
                message.append(f'Acquisition function:   {acquisition_function_name}')
                message.append(f'**************************************************')
            except:
                message.append("")
                message.append(f'**************************************************')
                message.append(f'Center Node: sampling the center of the search space at trial {trial_index}')
                message.append(f'**************************************************')

            self._optimization_listener.feedback(None, None, None, None, None, message=message)

        current_node_name = node_name

        return suggested_motor_positions, trial_index, current_node_name

    # ------------------------------------------------------------------------------

    def _manager_error_decorator(self, trial_index, optimization_criteria, motor_ids_to_optimize, suggested_motor_positions, current_motors_positions):
        error_loss = self._hypervolume_manager.get_error_loss_function(optimization_criteria)

        self._optimization_listener.feedback(trial_index=trial_index,
                                             motors_to_optimize=motor_ids_to_optimize,
                                             suggested_motor_positions=suggested_motor_positions,
                                             actual_motor_positions=current_motors_positions,
                                             current_loss=error_loss)
        return error_loss

    # ------------------------------------------------------------------------------

    def _evaluate_suggested_motor_positions_decorator(self, suggested_motor_positions, trial_index, current_raw_data, is_first_trial):
        optimization_criteria = self._optimization_criteria
        input_parameters      = self._input_parameters
        motors_to_optimize    = input_parameters.motors_to_optimize
        motor_ids_to_optimize = list(motors_to_optimize.keys())

        current_raw_data[trial_index] = None

        try:
            previous_motors_positions = self._get_current_motors_positions()
            self._move_motors(suggested_motor_positions)
            current_motors_positions_all = self._get_current_motors_positions(read_all=True)
            current_motors_positions     = {motor_id: current_motors_positions_all[motor_id] for motor_id in motor_ids_to_optimize}

            motor_ok, error_message = self._check_motor_positions(suggested_motor_positions, current_motors_positions)

            if not motor_ok: return self._manage_error(trial_index,
                                                       optimization_criteria,
                                                       motor_ids_to_optimize,
                                                       suggested_motor_positions,
                                                       current_motors_positions), \
                                    error_message
        except Exception as e:
            traceback.print_exc()
            return self._manage_error(trial_index,
                                       optimization_criteria,
                                       motor_ids_to_optimize,
                                       suggested_motor_positions,
                                       None), \
                   OptimizationErrorMessages.UNEXPECTED_ERROR_WHILE_SETTING_MOTORS + str(e)

        try:
            beam_manager_args = {"is_first_trial": is_first_trial,
                                 "delta_positions":   {motor_id : current_motors_positions[motor_id] - previous_motors_positions[motor_id] for motor_id in motor_ids_to_optimize},
                                 "current_positions": current_motors_positions_all}
            beam              = self._beam_manager.get_beam(**beam_manager_args)
            beam_properties   = self._beam_manager.get_beam_properties(beam)

            current_raw_data[trial_index] = beam

            if beam_properties.get_parameter("is_empty_beam", False):
                return  self._manage_error(trial_index,
                                           optimization_criteria,
                                           motor_ids_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                        OptimizationErrorMessages.BEAM_IS_EMPTY

            if beam_properties.get_parameter("is_spurious_beam", False):
                return  self._manage_error(trial_index,
                                           optimization_criteria,
                                           motor_ids_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                        OptimizationErrorMessages.BEAM_IS_SPURIOUS

            loss, error, message = self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)

            if error > 0:
                return self._manage_error(trial_index,
                                          optimization_criteria,
                                          motor_ids_to_optimize,
                                          suggested_motor_positions,
                                          current_motors_positions), \
                       message if not message is None else OptimizationErrorMessages.LOSS_FUNCTION_CALCULATION
            else:
                self._optimization_listener.feedback(trial_index=trial_index,
                                                     motors_to_optimize=motor_ids_to_optimize,
                                                     suggested_motor_positions=suggested_motor_positions,
                                                     actual_motor_positions=current_motors_positions,
                                                     current_loss=loss)

                if bool(input_parameters.get_parameter("real_time_data", False)):
                    handler = input_parameters.get_parameter("send_show_trial_requested", None)
                    if handler: handler(loss, beam_properties, trial_index)

                return loss, None
        except Exception as e:
            traceback.print_exc()
            return self._manage_error(trial_index,
                                      optimization_criteria,
                                      motor_ids_to_optimize,
                                      suggested_motor_positions,
                                      current_motors_positions), \
                   OptimizationErrorMessages.UNEXPECTED_ERROR_WHILE_ANALYZING_BEAM + str(e)

    def _evaluate_suggested_motor_positions_generator_decorator(self, suggested_motor_positions, trial_index, current_raw_data, is_first_trial):
        optimization_criteria = self._optimization_criteria
        input_parameters      = self._input_parameters
        motors_to_optimize    = input_parameters.motors_to_optimize
        motor_ids_to_optimize = list(motors_to_optimize.keys())

        current_raw_data[trial_index] = None

        try:
            previous_motors_positions = yield from self._get_current_motors_positions()
            yield from self._move_motors(suggested_motor_positions)
            current_motors_positions = yield from self._get_current_motors_positions()

            motor_ok, error_message = self._check_motor_positions(suggested_motor_positions, current_motors_positions)

            if not motor_ok: return self._manage_error(trial_index,
                                                        optimization_criteria,
                                                        motor_ids_to_optimize,
                                                        suggested_motor_positions,
                                                        current_motors_positions), \
                                    error_message
        except RequestAbort:
            return self._manage_error(trial_index,
                                      optimization_criteria,
                                      motor_ids_to_optimize,
                                      suggested_motor_positions,
                                      None), \
                   OptimizationErrorMessages.BLUESKY_REQUEST_ABORT
        except RunEngineControlException as e:
            traceback.print_exc()
            return self._manage_error(trial_index,
                                      optimization_criteria,
                                      motor_ids_to_optimize,
                                      suggested_motor_positions,
                                      None), \
                OptimizationErrorMessages.BLUESKY_RUNENGINE_CONTROL_EXCEPTION + str(e)
        except Exception as e:
            traceback.print_exc()
            return self._manage_error(trial_index,
                                      optimization_criteria,
                                      motor_ids_to_optimize,
                                      suggested_motor_positions,
                                      None), \
                   OptimizationErrorMessages.UNEXPECTED_ERROR_WHILE_SETTING_MOTORS + str(e)

        try:
            beam_manager_args = {"is_first_trial": is_first_trial,
                                 "delta_positions":   {motor_id : current_motors_positions[motor_id] - previous_motors_positions[motor_id] for motor_id in motor_ids_to_optimize},
                                 "current_positions": {motor_id : float(current_motors_positions[motor_id]) for motor_id in motor_ids_to_optimize}}
            beam              = yield from self._beam_manager.get_beam(**beam_manager_args)
            beam_properties   = self._beam_manager.get_beam_properties(beam)

            current_raw_data[trial_index] = beam

            if beam_properties.get_parameter("is_empty_beam", False):
                return  self._manage_error(trial_index,
                                           optimization_criteria,
                                           motor_ids_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                        OptimizationErrorMessages.BEAM_IS_EMPTY

            if beam_properties.get_parameter("is_spurious_beam", False):
                return  self._manage_error(trial_index,
                                           optimization_criteria,
                                           motor_ids_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                        OptimizationErrorMessages.BEAM_IS_SPURIOUS

            loss, error, message = self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)

            if error > 0:
                return self._manage_error(trial_index,
                                           optimization_criteria,
                                           motor_ids_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                       message if not message is None else OptimizationErrorMessages.LOSS_FUNCTION_CALCULATION
            else:
                self._optimization_listener.feedback(trial_index=trial_index,
                                                     motors_to_optimize=motor_ids_to_optimize,
                                                     suggested_motor_positions=suggested_motor_positions,
                                                     actual_motor_positions=current_motors_positions,
                                                     current_loss=loss)

                if bool(input_parameters.get_parameter("real_time_data", False)):
                    handler = input_parameters.get_parameter("send_show_trial_requested", None)
                    if handler: handler(loss, beam_properties, trial_index)

                return loss, None
        except RequestAbort:
            return self._manage_error(trial_index,
                                      optimization_criteria,
                                      motor_ids_to_optimize,
                                      suggested_motor_positions,
                                      None), \
                OptimizationErrorMessages.BLUESKY_REQUEST_ABORT
        except RunEngineControlException as e:
            traceback.print_exc()
            return self._manage_error(trial_index,
                                      optimization_criteria,
                                      motor_ids_to_optimize,
                                      suggested_motor_positions,
                                      None), \
                OptimizationErrorMessages.BLUESKY_RUNENGINE_CONTROL_EXCEPTION + str(e)
        except Exception as e:
            traceback.print_exc()
            return self._manage_error(trial_index,
                                       optimization_criteria,
                                       motor_ids_to_optimize,
                                       suggested_motor_positions,
                                       current_motors_positions), \
                   OptimizationErrorMessages.UNEXPECTED_ERROR_WHILE_ANALYZING_BEAM + str(e)
