#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

from aps.beamline_driver.beam_management.facade import BeamProperties
from aps.ai.beamline_controller.agent.facade import IAgentListener
from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import BayesianOptimizationResult, BayesianOptimizationResultItem, BayesianOptimizationExecutionParameters
from aps.ai.beamline_controller.agent.optimization.common.bayesian.abstract_optimizer import AbstractBayesianOptimizer

# -------------------------------------------------------------
# ABSTRACT CLASS
# -------------------------------------------------------------

class SOBOAbstractBayesianOptimizer(AbstractBayesianOptimizer):
    def __init__(self,  optimization_listener : IAgentListener, **kwargs):
        AbstractBayesianOptimizer.__init__(self, optimization_listener, **kwargs)

    def _get_best_trial_data_after_optimization(self,
                                                optimization_result: BayesianOptimizationResult,
                                                execution_parameters: BayesianOptimizationExecutionParameters):
        return self.get_best_trial_data(optimization_result, **{})

    def get_best_trial_data(self,  optimization_result : BayesianOptimizationResult = None, **kwargs) -> (BayesianOptimizationResultItem, BeamProperties):
        optimization_result = self._optimization_result if optimization_result is None else optimization_result

        best_trial_data   = optimization_result.get_best_trial()
        if kwargs.get("check_beam", False): beam_properties = self._get_beam_properties(best_trial_data.trial_number,
                                                                                        best_trial_data.beam,
                                                                                        f"{self._get_result_file_prefix()}_best_beam_trial_{best_trial_data.trial_number}.png",
                                                                                        **kwargs)
        else:                               beam_properties = None

        return best_trial_data, beam_properties