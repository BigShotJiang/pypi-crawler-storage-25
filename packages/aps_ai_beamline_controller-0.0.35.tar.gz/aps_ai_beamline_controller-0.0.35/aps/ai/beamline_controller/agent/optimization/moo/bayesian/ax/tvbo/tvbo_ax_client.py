"""
Time-Variable Bayesian Optimization (TVBO) with ax.api.Client  –  Ax 1.2.4
===========================================================================

Three strategies are implemented.  All candidate generation is done MANUALLY
via ax.adapter.registry.Generators so that the correct time stamp is always
stored on every arm.  The Client is used exclusively for trial bookkeeping:

    client.configure_experiment / configure_optimization
    client.attach_trial(parameters, arm_name)   → trial_index
    client.complete_trial(trial_index, raw_data)
    client.get_best_parameterization()

This avoids the CenterOfSearchSpace / Sobol nodes ever writing a wrong "time"
value onto an arm (which would corrupt the temporal GP's training data).

  Strategy 1 – Temporal Kernel GP
    Product kernel k(x,t) = k_spatial(x) × k_temporal(t).
    Time is a regular parameter stored on every arm; the GP learns
    spatio-temporal correlations directly.

  Strategy 2 – Sliding Window
    Default SingleTaskGP but only the W most-recent arms feed the model.
    No time parameter in the search space.

  Strategy 3 – Exponential Forgetting
    Older arms receive inflated noise sigma^2*exp(age/half_life) before the
    model is re-fit, so the MLL naturally down-weights stale data.
    Time is stored on every arm so ages can be recomputed each step.

Requirements
------------
    pip install "ax-platform>=1.2.4" botorch gpytorch torch pandas
"""

from __future__ import annotations

import math
import warnings
from typing import Optional

import pandas as pd
import torch
from botorch.acquisition.logei import qLogNoisyExpectedImprovement
from botorch.models.gpytorch import GPyTorchModel
from gpytorch.distributions import MultivariateNormal
from gpytorch.kernels import MaternKernel, ProductKernel, ScaleKernel
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.means import ConstantMean
from gpytorch.models import ExactGP
from torch import Tensor

# -- Ax 1.2.4 public Client API -----------------------------------------------
from ax.api.client import Client
from ax.api.configs import RangeParameterConfig

# -- Adapter / Generator registry (replaces ax.modelbridge in 1.2.4) ----------
from ax.adapter.registry import Generators

# -- Surrogate customisation --------------------------------------------------
from ax.generators.torch.botorch_modular.surrogate import ModelConfig, SurrogateSpec

# -- Data object (still in ax.core) -------------------------------------------
from ax.core.data import Data as AxData

# Suppress the Ax/pandas 2.2 DataFrameGroupBy FutureWarning (Ax internal issue)
warnings.filterwarnings("ignore", category=FutureWarning, module="ax")


# =============================================================================
# 1.  DRIFTING OBJECTIVE
# =============================================================================

METRIC = "objective"
N_INIT = 5  # quasi-random initialisation trials


def drifting_objective(x1: float, x2: float, t: float) -> float:
    """
    2-D bowl whose optimum drifts sinusoidally with time.
    Optimum: (sin(0.3t), sin(0.3t)), maximum value 1.0.
    """
    drift = math.sin(0.3 * t)
    return -(x1 - drift) ** 2 - (x2 - drift) ** 2 + 1.0


# =============================================================================
# 2.  CUSTOM GP MODELS
# =============================================================================

class TemporalGP(ExactGP, GPyTorchModel):
    """
    GP with spatio-temporal product kernel.

    Input layout from Ax: [..., x1, x2, time]
      - spatial block:  columns 0..d-2  (Matern-5/2, ARD)
      - temporal block: column  d-1     (Matern-5/2, scalar lengthscale)
    """

    _num_outputs = 1

    def __init__(
        self,
        train_X: Tensor,
        train_Y: Tensor,
        train_Yvar: Optional[Tensor] = None,
    ) -> None:
        super().__init__(train_X, train_Y.squeeze(-1), GaussianLikelihood())
        d = train_X.shape[-1]
        n_spatial = d - 1
        self.mean_module = ConstantMean()
        self.covar_module = ScaleKernel(
            ProductKernel(
                MaternKernel(nu=2.5, ard_num_dims=n_spatial,
                             active_dims=list(range(n_spatial))),
                MaternKernel(nu=2.5, ard_num_dims=1, active_dims=[d - 1]),
            )
        )
        self.to(train_X)

    def forward(self, x: Tensor) -> MultivariateNormal:
        return MultivariateNormal(self.mean_module(x), self.covar_module(x))

    @classmethod
    def construct_inputs(cls, training_data, **kwargs):
        return {
            "train_X": training_data.X,
            "train_Y": training_data.Y,
            "train_Yvar": training_data.Yvar,
        }


class ExponentialForgettingGP(ExactGP, GPyTorchModel):
    """
    Spatial-only Matern-5/2 GP.  The time column is stripped internally;
    forgetting is encoded in the Yvar values supplied by the caller.
    Input layout: [..., x1, x2, time]
    """

    _num_outputs = 1

    def __init__(
        self,
        train_X: Tensor,
        train_Y: Tensor,
        train_Yvar: Optional[Tensor] = None,
    ) -> None:
        x_spatial = train_X[:, :-1]
        super().__init__(x_spatial, train_Y.squeeze(-1), GaussianLikelihood())
        d = x_spatial.shape[-1]
        self.mean_module = ConstantMean()
        self.covar_module = ScaleKernel(MaternKernel(nu=2.5, ard_num_dims=d))
        if train_Yvar is not None:
            self.likelihood.noise = train_Yvar.mean().clamp(min=1e-6)
        self.to(x_spatial)

    def forward(self, x: Tensor) -> MultivariateNormal:
        x_s = x[:, :-1]
        return MultivariateNormal(self.mean_module(x_s), self.covar_module(x_s))

    @classmethod
    def construct_inputs(cls, training_data, **kwargs):
        return {
            "train_X": training_data.X,
            "train_Y": training_data.Y,
            "train_Yvar": training_data.Yvar,
        }


# =============================================================================
# 3.  SURROGATE SPECS
# =============================================================================

_TEMPORAL_SPEC = SurrogateSpec(
    model_configs=[
        ModelConfig(botorch_model_class=TemporalGP, input_transform_classes=None)
    ]
)

_EXP_FORGETTING_SPEC = SurrogateSpec(
    model_configs=[
        ModelConfig(botorch_model_class=ExponentialForgettingGP,
                    input_transform_classes=None)
    ]
)


# =============================================================================
# 4.  CLIENT FACTORY
# =============================================================================

def _make_client(name: str, with_time: bool) -> Client:
    """
    Build and configure a Client.  No GenerationStrategy is set because
    candidate generation is handled manually via Generators throughout,
    so there is no CenterOfSearchSpace node to corrupt the time parameter.
    """
    client = Client()
    params: list[RangeParameterConfig] = [
        RangeParameterConfig(name="x1", parameter_type="float", bounds=(-1.5, 1.5)),
        RangeParameterConfig(name="x2", parameter_type="float", bounds=(-1.5, 1.5)),
    ]
    if with_time:
        params.append(
            RangeParameterConfig(name="time", parameter_type="float",
                                 bounds=(0.0, float(N_INIT + 30)))
        )
    client.configure_experiment(name=name, parameters=params)
    client.configure_optimization(objective=METRIC)
    return client


# =============================================================================
# 5.  SHARED HELPERS
# =============================================================================

def _attach_and_complete(
    client: Client,
    parameters: dict,
    step: int,
    arm_name: str,
) -> float:
    """
    Store one trial via the Client and return the objective value.

    Using attach_trial (not get_next_trials) guarantees that the exact
    parameters we supply -- including the correct time stamp -- are what
    gets recorded on the arm and later seen by the GP as training data.
    """
    trial_index = client.attach_trial(parameters=parameters, arm_name=arm_name)
    t = parameters.get("time", float(step))
    value = drifting_objective(parameters["x1"], parameters["x2"], t)
    client.complete_trial(
        trial_index=trial_index,
        raw_data={METRIC: (value, 0.05)},
    )
    return value


def _sobol_xy(exp, seed: int) -> dict:
    """Draw one Sobol point and return only x1/x2 (ignore any time column)."""
    adapter = Generators.SOBOL(experiment=exp, seed=seed)
    arm = adapter.gen(1).arms[0]
    p = dict(arm.parameters)
    return {"x1": p["x1"], "x2": p["x2"]}


def _windowed_data(exp, window: int) -> AxData:
    """AxData containing only the last `window` completed trials."""
    full = exp.fetch_data()
    if full.df.empty:
        return full
    keep = set(sorted(full.df["trial_index"].unique())[-window:])
    return AxData(df=full.df[full.df["trial_index"].isin(keep)].copy())


def _row(strategy: str, step: int, params: dict, value: float) -> dict:
    return {
        "strategy": strategy,
        "step": step,
        "x1": params["x1"],
        "x2": params["x2"],
        "time": params.get("time", float(step)),
        "objective": value,
    }


def _print_header(title: str) -> None:
    print(f"\n{'─' * 55}\n  {title}\n{'─' * 55}")


def _print_step(step: int, params: dict, value: float) -> None:
    t = params.get("time", step)
    print(f"  step {step:3d} | x1={params['x1']:+.3f}  x2={params['x2']:+.3f}"
          f"  t={t!s:>4}  obj={value:.4f}")


def _print_best(client: Client) -> None:
    try:
        print(f"\n  Best: {client.get_best_parameterization()}")
    except Exception as exc:
        print(f"\n  (get_best_parameterization: {exc})")


# =============================================================================
# 6.  TVBO LOOPS
# =============================================================================

def run_temporal_kernel(n_bo: int = 12) -> list[dict]:
    """
    Strategy 1 – Temporal Kernel GP.

    Every trial is attached manually so the correct step-time is always
    stored on the arm.  The TemporalGP then trains on (x1, x2, t_correct).
    """
    client = _make_client("tvbo_temporal_kernel", with_time=True)
    exp = client._experiment
    results = []
    _print_header("Strategy 1 – Temporal Kernel GP")

    for step in range(N_INIT + n_bo):
        if step < N_INIT:
            xy = _sobol_xy(exp, seed=step)
            params = {**xy, "time": float(step)}
        else:
            try:
                adapter = Generators.BOTORCH_MODULAR(
                    experiment=exp,
                    data=exp.fetch_data(),
                    surrogate_spec=_TEMPORAL_SPEC,
                    botorch_acqf_class=qLogNoisyExpectedImprovement,
                )
                raw = dict(adapter.gen(1).arms[0].parameters)
                # Pin time to the current step regardless of what the GP suggested
                params = {"x1": raw["x1"], "x2": raw["x2"], "time": float(step)}
            except Exception as exc:
                print(f"  [step {step}] fallback to Sobol ({exc})")
                params = {**_sobol_xy(exp, seed=step),
                          "time": float(step)}

        value = _attach_and_complete(client, params, step, arm_name=f"tk_{step}")
        results.append(_row("temporal_kernel", step, params, value))
        _print_step(step, params, value)

    _print_best(client)
    return results


def run_sliding_window(n_bo: int = 12, window: int = 8) -> list[dict]:
    """
    Strategy 2 – Sliding Window.

    The default SingleTaskGP is fitted on only the last `window` arms.
    No time parameter is needed.
    """
    client = _make_client("tvbo_sliding_window", with_time=False)
    exp = client._experiment
    results = []
    _print_header("Strategy 2 – Sliding Window")

    for step in range(N_INIT + n_bo):
        if step < N_INIT:
            params = _sobol_xy(exp, seed=step)
        else:
            try:
                adapter = Generators.BOTORCH_MODULAR(
                    experiment=exp,
                    data=_windowed_data(exp, window=window),
                    botorch_acqf_class=qLogNoisyExpectedImprovement,
                )
                raw = dict(adapter.gen(1).arms[0].parameters)
                params = {"x1": raw["x1"], "x2": raw["x2"]}
            except Exception as exc:
                print(f"  [step {step}] fallback to Sobol ({exc})")
                params = _sobol_xy(exp, seed=step)

        value = _attach_and_complete(client, params, step, arm_name=f"sw_{step}")
        results.append(_row("sliding_window", step, params, value))
        _print_step(step, params, value)

    _print_best(client)
    return results


def run_exp_forgetting(
    n_bo: int = 12,
    half_life: float = 8.0,
    base_noise: float = 1e-3,
) -> list[dict]:
    """
    Strategy 3 – Exponential Forgetting.

    Before each BO step we rebuild the AxData with SEM inflated by
    sqrt(base_noise * exp(age / half_life)) so older observations are
    trusted less by the MLL fit.
    """
    client = _make_client("tvbo_exp_forgetting", with_time=True)
    exp = client._experiment
    results = []
    trial_step: dict[int, int] = {}  # trial_index -> step number
    _print_header("Strategy 3 – Exponential Forgetting")

    for step in range(N_INIT + n_bo):
        if step < N_INIT:
            xy = _sobol_xy(exp, seed=step)
            params = {**xy, "time": float(step)}
            value = _attach_and_complete(client, params, step, arm_name=f"ef_{step}")
            trial_step[max(exp.trials.keys())] = step

        else:
            # Rebuild data with age-inflated SEM values
            full_df = exp.fetch_data().df.copy()
            if not full_df.empty:
                def _sem(row):
                    age = step - trial_step.get(int(row["trial_index"]), step)
                    return math.sqrt(base_noise * math.exp(age / half_life))
                full_df["sem"] = full_df.apply(_sem, axis=1)
            weighted_data = AxData(df=full_df)

            try:
                adapter = Generators.BOTORCH_MODULAR(
                    experiment=exp,
                    data=weighted_data,
                    surrogate_spec=_EXP_FORGETTING_SPEC,
                    botorch_acqf_class=qLogNoisyExpectedImprovement,
                )
                raw = dict(adapter.gen(1).arms[0].parameters)
                params = {"x1": raw["x1"], "x2": raw["x2"], "time": float(step)}
            except Exception as exc:
                print(f"  [step {step}] fallback to Sobol ({exc})")
                params = {**_sobol_xy(exp, seed=step),
                          "time": float(step)}

            value = _attach_and_complete(client, params, step, arm_name=f"ef_{step}")
            trial_step[max(exp.trials.keys())] = step

        results.append(_row("exp_forgetting", step, params, value))
        _print_step(step, params, value)

    _print_best(client)
    return results


# =============================================================================
# 7.  ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    print("=" * 55)
    print("  Time-Variable Bayesian Optimization  –  Ax 1.2.4")
    print("  Candidates via Generators, trials via Client.attach_trial")
    print("=" * 55)

    all_results: list[dict] = []
    all_results += run_temporal_kernel(n_bo=12)
    all_results += run_sliding_window(n_bo=12, window=8)
    all_results += run_exp_forgetting(n_bo=12, half_life=8.0)

    df = pd.DataFrame(all_results)
    print("\n── Summary ──────────────────────────────────────────")
    print(
        df.groupby("strategy")["objective"]
        .agg(mean="mean", best="max")
        .round(4)
        .to_string()
    )
    df["phase"] = df["step"].apply(lambda s: "init" if s < N_INIT else "bo")
    print("\n── Phase breakdown ──────────────────────────────────")
    print(
        df.groupby(["strategy", "phase"])["objective"]
        .agg(mean="mean", best="max")
        .round(4)
        .to_string()
    )
    print("\nDone.")