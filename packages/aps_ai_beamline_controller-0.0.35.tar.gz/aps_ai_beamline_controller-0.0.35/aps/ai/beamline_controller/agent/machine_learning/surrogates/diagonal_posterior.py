#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

# ----------------------------------------------------------------
# Custom posterior: implements rsample() directly.
# This is all BoTorch's MC acquisition functions actually need.
# ----------------------------------------------------------------
import torch
from torch import Tensor
from botorch.posteriors.torch import Posterior

from botorch.sampling.get_sampler import GetSampler
from botorch.sampling.base import MCSampler
from botorch.sampling.stochastic_samplers import ForkedRNGSampler

class DiagonalNormalPosterior(Posterior):
    """
    A simple Gaussian posterior with a diagonal covariance.
    Implements rsample() so MC acquisition functions like qNEHVI work
    without needing a registered MCSampler.
    """

    def __init__(self, mean: Tensor, variance: Tensor):
        super().__init__()
        self._mean     = mean      # [..., q, m]
        self._variance = variance  # [..., q, m]

    @property
    def mean(self) -> Tensor:
        return self._mean

    @property
    def variance(self) -> Tensor:
        return self._variance

    def rsample(self, sample_shape: torch.Size = torch.Size()) -> Tensor:
        """
        Draw samples via the reparameterisation trick:
            z = mean + std * eps,  eps ~ N(0, I)
        Returns shape: sample_shape + batch_shape + [q, m]
        """
        std  = self._variance.sqrt()
        eps  = torch.randn(
            *sample_shape, *self._mean.shape,
            dtype=self._mean.dtype,
            device=self._mean.device,
        )
        return self._mean + std * eps

    @property
    def device(self) -> torch.device:
        return self._mean.device

    @property
    def dtype(self) -> torch.dtype:
        return self._mean.dtype

# ----------------------------------------------------------------
# Register GetSampler for DiagonalNormalPosterior.
# ForkedRNGSampler calls posterior.rsample() directly — no base
# samples, no collapsed shape logic — exactly what we need.
# Must be registered for BOTH model classes that use this posterior.
# ----------------------------------------------------------------

@GetSampler.register(DiagonalNormalPosterior)
def _get_sampler_diagonal(
    posterior: DiagonalNormalPosterior,
    sample_shape: torch.Size,
    *,
    seed: int | None = None,
    **kwargs,
) -> MCSampler:
    return ForkedRNGSampler(sample_shape=sample_shape, seed=seed)