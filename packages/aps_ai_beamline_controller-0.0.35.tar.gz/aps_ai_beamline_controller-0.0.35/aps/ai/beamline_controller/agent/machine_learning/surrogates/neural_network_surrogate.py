#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
from pathlib import Path

import torch
import torch.nn as nn
from botorch.acquisition.objective import PosteriorTransform
from torch import Tensor
from typing import Any, Optional, List

from botorch.models.model import Model
from botorch.utils.datasets import SupervisedDataset

from aps.ai.beamline_controller.agent.machine_learning.surrogates.diagonal_posterior import DiagonalNormalPosterior
from aps.ai.beamline_controller.agent.machine_learning.surrogates.facade import SurrogateAction, apply_scalers


class NNSurrogate(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
        )
        self.mean_head   = nn.Linear(hidden_dim, 1)
        self.logvar_head = nn.Linear(hidden_dim, 1)

    def forward(self, x: Tensor):
        h = self.net(x)
        return self.mean_head(h), self.logvar_head(h)

class BotorchNNModel(Model):
    def __init__(self,
                 train_X: Tensor,
                 train_Y: Tensor,
                 objective: str,
                 hidden_dim: int = 64,
                 action: int = SurrogateAction.NOTHING,
                 pre_train_X: torch.Tensor | None = None,
                 pre_train_Y: torch.Tensor | None = None,
                 n_steps: int = 1000,
                 model_directory: str = None,
                 verbose: bool = False,
                 ):
        super().__init__()
        self._num_outputs = train_Y.shape[-1]
        self.models = nn.ModuleList([NNSurrogate(train_X.shape[-1], hidden_dim) for _ in range(self._num_outputs)])
        self.double()

        if verbose: print(f"Surrogate Model for objective {objective}")

        if not action == SurrogateAction.NOTHING:
            checkpoint = Path(os.path.join(model_directory, f"nn_surrogate_{objective}.pt"))

            if not checkpoint.exists() and action == SurrogateAction.LOAD_STATE_DICT:
                raise ValueError("State dict file not found: check path or switch to train+save mode to solve this issue")

            if action == SurrogateAction.TRAIN_MODEL:
                if not checkpoint.exists():
                    self._fit(pre_train_X.double(), pre_train_Y.double(), n_steps=n_steps)
                    torch.save(self.state_dict(), checkpoint)
                    if verbose: print(f"NN surrogate pre-trained and saved → {model_directory}")
                else:
                    self.load_state_dict(torch.load(checkpoint, weights_only=True))
                    if verbose: print("NN surrogate: loaded pre-trained weights after initial training (warm start)")
            elif action == SurrogateAction.LOAD_STATE_DICT:
                self.load_state_dict(torch.load(checkpoint, weights_only=True))
                if verbose: print("NN surrogate: loaded pre-trained weights (warm start)")

        self._fit(train_X, train_Y)
        if verbose: print("NN surrogate: model fit with new data")

    def _fit(self, train_X: Tensor, train_Y: Tensor, n_steps: int = 500):
        optimizer = torch.optim.Adam(self.parameters(), lr=1e-3)
        self.train()
        for _ in range(n_steps):
            optimizer.zero_grad()
            loss = torch.zeros(1)
            for i, m in enumerate(self.models):
                mean, logvar = m(train_X)
                var = torch.exp(logvar).clamp(min=1e-6)
                y_i = train_Y[..., i : i + 1]
                loss = loss + (0.5 * ((y_i - mean) ** 2 / var + logvar)).mean()
            loss.backward()
            optimizer.step()

    def posterior(
            self,
            X: Tensor,
            output_indices: Optional[List[int]] = None,
            observation_noise: bool = False,
            posterior_transform: Optional[PosteriorTransform] = None,
            **kwargs,
    ) -> DiagonalNormalPosterior:
        self.eval()
        means, vars_ = [], []
        for m in self.models:
            mu, lv = m(X)
            means.append(mu)
            vars_.append(torch.exp(lv).clamp(min=1e-6))

        mean = torch.cat(means, dim=-1)
        var = torch.cat(vars_, dim=-1)

        posterior = DiagonalNormalPosterior(mean=mean, variance=var)

        if posterior_transform is not None:
            posterior = posterior_transform(posterior)

        return posterior

    @property
    def num_outputs(self) -> int:
        return self._num_outputs

    @classmethod
    def construct_inputs(
            cls,
            training_data: SupervisedDataset | list[SupervisedDataset],
            hidden_dim: int = 64,
            action: int = SurrogateAction.TRAIN_MODEL,
            pre_train_X: torch.Tensor | None = None,
            pre_train_Y: torch.Tensor | None = None,
            scalers: dict = {},
            n_steps: int = 1000,
            model_directory: str = None,
            verbose: bool = False,
            **kwargs,
    ) -> dict[str, Any]:
        if isinstance(training_data, list):
            train_X = training_data[0].X
            train_Y = torch.cat([d.Y for d in training_data], dim=-1)
        else:
            train_X, train_Y = training_data.X, training_data.Y

        objective = training_data.outcome_names[0]

        return {"train_X": train_X,
                "train_Y": train_Y,
                "objective": objective,
                "hidden_dim": hidden_dim,
                "action": action,
                "pre_train_X": pre_train_X,
                "pre_train_Y": apply_scalers(scalers, pre_train_Y, objective),
                "n_steps": n_steps,
                "model_directory": model_directory,
                "verbose": verbose}

