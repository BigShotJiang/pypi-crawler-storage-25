#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
from abc import abstractmethod

import numpy as np
import torch.cuda

from aps.common.data_structures import DictionaryWrapper
from aps.beamline_driver.beam_management.facade import Beam

class NeuralNetworkParameters(DictionaryWrapper):
    def __init__(self,
                 input_data_directory: str = os.path.abspath(os.curdir),
                 output_model_directory: str = None,
                 use_cuda = torch.cuda.is_available(),
                 **kwargs):
        super(NeuralNetworkParameters, self).__init__(**kwargs)

        self.__input_data_directory   = os.path.abspath(input_data_directory)
        self.__output_model_directory = output_model_directory if not output_model_directory is None else os.path.join(self.__input_data_directory, "trained_nn")
        self.__use_cuda               = use_cuda

    @property
    def input_data_directory(self) -> str: return self.__input_data_directory
    @property
    def output_model_directory(self) -> str: return self.__output_model_directory
    @property
    def use_cuda(self) -> bool: return self.__use_cuda

from aps.ai.beamline_controller.agent.facade import Fidelity, ERROR_LOSS

class NeuralNetworkAlignementData():
    def __init__(self,
                 fidelity: int = Fidelity.LOW,
                 suggested_motor_positions :dict = {}, # {motor_id : position}
                 motor_positions: dict = {},           # {motor_id : position}
                 beam_properties: dict = {},           # {target_property : value }
                 beam: Beam = None,
                 beam_string: str = None):
        self.__fidelity                  = fidelity
        self.__suggested_motor_positions = suggested_motor_positions
        self.__motor_positions           = motor_positions
        self.__beam_properties           = beam_properties
        self.__beam_string = beam_string if beam is None else beam.serialize()

    @property
    def fidelity(self) -> int: return self.__fidelity
    @property
    def suggested_motor_positions(self) -> dict: return self.__suggested_motor_positions
    @property
    def motor_positions(self) -> dict: return self.__motor_positions
    @property
    def beam_properties(self) -> dict: return self.__beam_properties
    @property
    def beam_hex_string(self) -> str: return self.__beam_string
    @property
    def beam(self) -> Beam: return None if self.__beam_string is None else Beam.deserialize(self.__beam_string)

    @fidelity.setter
    def fidelity(self, value): self.__fidelity = value
    @beam.setter
    def beam(self, value): self.__beam_string = None if value is None else value.serialize()
    @beam_hex_string.setter
    def beam_hex_string(self, value): self.__beam_string = value

    @property
    def headers(self) -> list:
        headers = ["fidelity"]
        headers.extend([f"{key}-(SMP)" for key in self.suggested_motor_positions.keys()])
        headers.extend([f"{key}-(MP)" for key in self.motor_positions.keys()])
        headers.extend([f"{key}-(BP)" for key in self.beam_properties.keys()])
        headers.append("beam")

        return headers

    def to_dictionary(self) -> dict:
        dict = {"fidelity": self.fidelity}
        dict.update({f"{key}-(SMP)": self.suggested_motor_positions[key] for key in self.suggested_motor_positions.keys()})
        dict.update({f"{key}-(MP)": self.motor_positions[key] for key in self.motor_positions.keys()})
        dict.update({f"{key}-(BP)": (self.beam_properties[key] if not self.beam_properties[key] is None else np.nan) for key in self.beam_properties.keys()})
        dict["beam"] = self.__beam_string # hex string

        return dict

    @classmethod
    def from_dictionary(cls, dictionary: dict):
        return NeuralNetworkAlignementData(fidelity=int(dictionary.get("fidelity"), Fidelity.LOW),
                                           suggested_motor_positions={key[:-6]: float(dictionary[key]) for key in dictionary.keys() if key.endswith("-(SMP)")},
                                           motor_positions={key[:-5]: float(dictionary[key]) for key in dictionary.keys() if key.endswith("-(MP)")},
                                           beam_properties={key[:-5]: float(dictionary[key]) for key in dictionary.keys() if key.endswith("-(OF)")},
                                           beam_string=dictionary["beam"])


class INeuralNetwork:
    @abstractmethod
    def train_neural_network(self, skip_forward = False, exclusion_ranges: dict = {}): raise NotImplementedError
    @abstractmethod
    def load_trained_model(self, file_name = None): raise NotImplementedError
    @abstractmethod
    def predict_motor_positions(self, target_properties: dict) -> dict: raise NotImplementedError

class INeuralNetworkManager:
    @abstractmethod
    def requires_run_engine(self, *args, **kwargs): raise NotImplementedError
    @abstractmethod
    def requires_stage_wrapping(self, *args, **kwargs): raise NotImplementedError
    @abstractmethod
    def initialize_driver(self, *args, **kwargs): raise NotImplementedError
    @abstractmethod
    def initialize_neural_network(self, *args, **kwargs): raise NotImplementedError
    @abstractmethod
    def move_motors_to_target_properties(self, target_properties: dict, *args, **kwargs): raise NotImplementedError
    @abstractmethod
    def get_alignement_result_data(self) -> NeuralNetworkAlignementData: raise NotImplementedError
    @abstractmethod
    def save_alignment_result(self): raise NotImplementedError