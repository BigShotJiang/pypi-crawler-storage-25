#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import Any, Type

from aps.ai.beamline_controller.agent.optimization.moo.bayesian.abstract_hypervolume_manager import AbstractBayesianHypervolumeManager # This abstract class can handle all the optimization results
from aps.ai.beamline_controller.agent.optimization.decorators.abstract_hypervolume_manager_decorator import AbstractHyperVolumeManagerDecorator

from aps.beamline_driver.digital_twin.optimized_optics_manager import AbstractOptimizedOpticsManager
from aps.beamline_driver.beam_management.abstract_beam_manager import DirectBeamImageBeamManager, WavefrontAnalysisBeamManager, SpeckleAnalysisBeamManager

from aps.beamline_driver.beam_management.facade import IBeamManager
from aps.ai.beamline_controller.agent.optimization.decorators.direct_beam_image_decorator import DirectBeamImageHyperVolumeManagerDecorator
from aps.ai.beamline_controller.agent.optimization.decorators.wavefront_analysis_decorator import WavefrontAnalysisHyperVolumeManagerDecorator
from aps.ai.beamline_controller.agent.optimization.decorators.speckle_analysis_decorator import SpeckleAnalysisHyperVolumeManagerDecorator

def create_hypervolume_manager(beam_manager: IBeamManager, **hypervolume_manager_args):
    def get_dynamic_hypervolume_manager(hypervolume_manager_decorator_class: Type[AbstractHyperVolumeManagerDecorator]) -> Type:
        class NeuralNetworkHyperVolumeManager(hypervolume_manager_decorator_class, AbstractBayesianHypervolumeManager):

            def __init__(self,
                         hypervolume_reference_points: dict,
                         optimization_criteria_constraints: dict = {},
                         optimization_criteria_reference_values: dict = {},
                         optimization_criteria_weights: dict = {}):
                super(NeuralNetworkHyperVolumeManager, self).__init__(hypervolume_reference_points,
                                                                      optimization_criteria_constraints,
                                                                      optimization_criteria_reference_values,
                                                                      optimization_criteria_weights)

            def _get_managed_acquisition_functions(self) -> dict: {}
            def _initialize_loss_container(self) -> Any: return {}
            def _add_to_loss_container(self, optimization_criterion: str, loss_container: Any, current_loss: float): loss_container[optimization_criterion] = current_loss

        return NeuralNetworkHyperVolumeManager

    if issubclass(beam_manager.__class__, AbstractOptimizedOpticsManager): beam_manager_class = beam_manager._beam_manager.__class__
    else:                                                                  beam_manager_class = beam_manager.__class__

    if   issubclass(beam_manager_class, DirectBeamImageBeamManager):   hypervolume_manager_decorator_class = DirectBeamImageHyperVolumeManagerDecorator
    elif issubclass(beam_manager_class, WavefrontAnalysisBeamManager): hypervolume_manager_decorator_class = WavefrontAnalysisHyperVolumeManagerDecorator
    elif issubclass(beam_manager_class, SpeckleAnalysisBeamManager):   hypervolume_manager_decorator_class = SpeckleAnalysisHyperVolumeManagerDecorator
    else: raise ValueError("Beam manager is not a subclass of any recognized one")

    return get_dynamic_hypervolume_manager(hypervolume_manager_decorator_class)(**hypervolume_manager_args)