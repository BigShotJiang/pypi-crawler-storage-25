#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
import random
import pandas as pd
from torch import Tensor

from aps.ai.beamline_controller.agent.optimization.moo.bayesian.ax.hypervolume_manager import to_ax_objective_name
from aps.common.io.serialization import from_pickle

from aps.ai.beamline_controller.agent.facade import IAgentListener
from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import BayesianOptimizationResultItem
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationResult, OptimizationCriteria

def load_training_data(input_data_directory,
                       motor_ids: list,
                       optimization_criteria: OptimizationCriteria,
                       number_of_datasets=-1,
                       data_type_for_exclusion=None,
                       listener: IAgentListener = None):
    optimization_result_files = [os.path.join(input_data_directory, f) for f in os.listdir(input_data_directory) if f.endswith('.pkl')]

    if number_of_datasets >= len(optimization_result_files): number_of_datasets = -1

    indexes = range(len(optimization_result_files)) if number_of_datasets == -1 else \
        [random.randint(0, len(optimization_result_files) - 1) for _ in range(number_of_datasets)]

    loaded_data_dict_list = []
    n_loaded_datasets = 0
    for index in indexes:
        file_path = optimization_result_files[index]
        optimization_result: OptimizationResult = from_pickle(file_path)
        n_loaded_datasets += 1

        for item in optimization_result.get_optimization_items():
            try:
                motors_dict = {mp: item.motor_positions[mp] for mp in motor_ids}
            except KeyError as e:
                raise ValueError(f"The optimization result in {file_path} does not contain the requested motor {e}")
            try:
                optimization_criteria_dict = {oc: item.loss_function[oc] for oc in optimization_criteria.names}
            except KeyError as e:
                raise ValueError(f"The optimization result in {file_path} does not contain the requested motor {e}")

            if isinstance(item, BayesianOptimizationResultItem): skip = item.sampling == data_type_for_exclusion
            else:                                                skip = True

            data_dict = {}
            data_dict.update(motors_dict)
            data_dict.update(optimization_criteria_dict)

            if not skip: loaded_data_dict_list.append(data_dict)

    if not listener is None:
        listener.feedback(None, None, None, None, None, message="===================================================================")
        listener.feedback(None, None, None, None, None, message="               loaded data from Optimization Results")
        listener.feedback(None, None, None, None, None, message="===================================================================")
        listener.feedback(None, None, None, None, None, message=f"Total number of datasets: {n_loaded_datasets}")
        listener.feedback(None, None, None, None, None, message=f"Total number of items   : {len(loaded_data_dict_list)}")
        listener.feedback(None, None, None, None, None, message="===================================================================")

    data_frame = pd.DataFrame(loaded_data_dict_list)

    '''
    Get inputs (motor_positions), output (optimization_criteria), normalize data 
    '''
    train_X = Tensor(data_frame.loc[:, motor_ids].values).float()
    train_Y = {to_ax_objective_name(oc): Tensor(data_frame.loc[:, oc].values).float() for oc in optimization_criteria.names}

    return train_X, train_Y

def reset_pre_training_botorch_nn(input_data_directory: str, optimization_criteria: OptimizationCriteria):
    for oc in optimization_criteria.names:
        checkpoint_file = os.path.join(input_data_directory, f"nn_surrogate_{to_ax_objective_name(oc)}.pt")
        if os.path.exists(checkpoint_file): os.remove(checkpoint_file)

def reset_pre_training_botorch_bnn(input_data_directory: str, optimization_criteria: OptimizationCriteria):
    for oc in optimization_criteria.names:
        checkpoint_file = os.path.join(input_data_directory, f"bnn_surrogate_{to_ax_objective_name(oc)}.pt")
        if os.path.exists(checkpoint_file): os.remove(checkpoint_file)

def reset_pre_training_botorch_dkl(input_data_directory: str, optimization_criteria: OptimizationCriteria):
    for oc in optimization_criteria.names:
        checkpoint_file = os.path.join(input_data_directory, f"dkl_surrogate_{to_ax_objective_name(oc)}.pt")
        if os.path.exists(checkpoint_file): os.remove(checkpoint_file)
