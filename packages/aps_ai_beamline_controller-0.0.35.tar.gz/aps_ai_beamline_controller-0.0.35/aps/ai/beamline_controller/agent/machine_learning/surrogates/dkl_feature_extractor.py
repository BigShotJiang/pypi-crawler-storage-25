#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
from pathlib import Path

import torch
import torch.nn as nn
from botorch.acquisition.objective import PosteriorTransform
from botorch.posteriors import GPyTorchPosterior
from gpytorch import ExactMarginalLogLikelihood
from torch import Tensor
from typing import Any, Optional, List

import gpytorch
from gpytorch.models import ExactGP
from gpytorch.kernels import RBFKernel, ScaleKernel
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.means import ConstantMean
from botorch.models.model import Model
from botorch.utils.datasets import SupervisedDataset

from aps.ai.beamline_controller.agent.machine_learning.surrogates.facade import SurrogateAction, apply_scalers

class FeatureExtractor(nn.Module):
    def __init__(self, input_dim: int, feature_dim: int = 8):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 32),    nn.Tanh(),
            nn.Linear(32, 32), nn.Tanh(),
            nn.Linear(32, feature_dim),
        )
        self.double()
    def forward(self, x: Tensor) -> Tensor:
        return self.net(x)

class DeepKernelGP(ExactGP):
    def __init__(self, train_X, train_Y, likelihood, input_dim, feature_dim=8):
        super().__init__(train_X, train_Y, likelihood)
        self.mean_module       = ConstantMean()
        self.feature_extractor = FeatureExtractor(input_dim, feature_dim)
        self.covar_module      = ScaleKernel(RBFKernel(ard_num_dims=feature_dim))

    def forward(self, x: Tensor):
        z     = self.feature_extractor(x)
        mean  = self.mean_module(z)
        covar = self.covar_module(z)
        return gpytorch.distributions.MultivariateNormal(mean, covar)

class BotorchDKLModel(Model):
    def __init__(self,
                 train_X: Tensor,
                 train_Y: Tensor,
                 objective: str,
                 feature_dim: int = 8,
                 action: int = SurrogateAction.NOTHING,
                 pre_train_X: torch.Tensor | None = None,
                 pre_train_Y: torch.Tensor | None = None,
                 model_directory: str = None,
                 verbose: bool = False):
        nn.Module.__init__(self)

        self.objective = objective

        if not action == SurrogateAction.NOTHING:
            checkpoint = Path(os.path.join(model_directory, "dkl_surrogate.pt"))

            if action == SurrogateAction.TRAIN_MODEL:
                if not checkpoint.exists():
                    train_X = torch.cat([pre_train_X, train_X], dim=0)
                    train_Y = torch.cat([pre_train_Y.unsqueeze(1), train_Y], dim=0)
                    if verbose: print("Train model: added pre-train data to the model")

        input_dim = train_X.shape[-1]
        self.likelihood = GaussianLikelihood()

        _gp = DeepKernelGP(
            train_X, train_Y.squeeze(-1),
            self.likelihood, input_dim, feature_dim,
        )

        self.add_module("gp", _gp)
        object.__setattr__(self, "gp", _gp)

        self._num_outputs = 1
        self._train_X = train_X
        self._train_Y = train_Y.squeeze(-1)

        def load_state_dict():
            data = torch.load(checkpoint, weights_only=True)
            self.gp.load_state_dict(data["gp"])
            self.likelihood.load_state_dict(data["likelihood"])

            self.gp.eval()
            self.likelihood.eval()

        if action == SurrogateAction.LOAD_STATE_DICT:
            if not checkpoint.exists(): raise FileNotFoundError("State dict file not found: check path or switch to train+save mode to solve this issue")
            load_state_dict()
        elif action == SurrogateAction.TRAIN_MODEL and checkpoint.exists():
            load_state_dict()

    def forward(self, x: Tensor):
        """
        Delegates to the inner DeepKernelGP.
        BatchedMultiOutputGPyTorchModel requires forward() to be defined
        on the model itself — it is what GPyTorch calls internally when
        computing the marginal log likelihood and the posterior.
        """
        return self.model.forward(x)

    def posterior(
            self,
            X: Tensor,
            output_indices: Optional[List[int]] = None,
            observation_noise: bool = False,
            posterior_transform: Optional[PosteriorTransform] = None,
            **kwargs,
    ) -> GPyTorchPosterior:
        self.gp.eval()
        self.likelihood.eval()
        with gpytorch.settings.fast_pred_var():
            distribution = (
                self.likelihood(self.gp(X))
                if observation_noise
                else self.gp(X)
            )
        posterior = GPyTorchPosterior(distribution=distribution)
        if posterior_transform is not None: posterior = posterior_transform(posterior)

        return posterior

    @classmethod
    def construct_inputs(
            cls,
            training_data: SupervisedDataset | list[SupervisedDataset],
            feature_dim: int = 8,
            action: int = SurrogateAction.TRAIN_MODEL,
            pre_train_X: torch.Tensor | None = None,
            pre_train_Y: torch.Tensor | None = None,
            scalers: dict = {},
            model_directory: str = None,
            verbose: bool = False,
            **kwargs: Any,
    ) -> dict[str, Any]:
        if isinstance(training_data, list): training_data = training_data[0]

        objective = training_data.outcome_names[0]

        return {"train_X": training_data.X,
                "train_Y": training_data.Y,
                "objective": objective,
                "feature_dim":  feature_dim,
                "action": action,
                "pre_train_X": pre_train_X,
                "pre_train_Y": apply_scalers(scalers, pre_train_Y, objective),
                "model_directory": model_directory,
                "verbose": verbose}

    @property
    def num_outputs(self) -> int: return self._num_outputs


def fit_dkl(
    model: BotorchDKLModel,
    mll_class=None,
    mll_options=None,
    **kwargs,
) -> None:
    # model.gp IS an ExactGP — GPyTorch's isinstance check passes
    mll = ExactMarginalLogLikelihood(model.likelihood, model.gp)

    model.gp.train()
    model.likelihood.train()

    opts            = mll_options or {}
    action          = opts.get("action", SurrogateAction.NOTHING)
    n_steps         = opts.get("n_steps", 300)
    lr              = opts.get("lr", 1e-2)
    model_directory = opts.get("model_directory", None)
    verbose         = opts.get("verbose", False)

    optimizer = torch.optim.Adam(
        list(model.gp.parameters()) + list(model.likelihood.parameters()),
        lr=lr
    )

    for _ in range(n_steps):
        optimizer.zero_grad()
        output = model.gp(model._train_X)
        loss   = -mll(output, model._train_Y)
        loss.backward()
        optimizer.step()

    model.gp.eval()
    model.likelihood.eval()

    if action == SurrogateAction.TRAIN_MODEL:
        checkpoint = Path(os.path.join(model_directory, f"dkl_surrogate_{model.objective}.pt"))

        if not checkpoint.exists():
            torch.save(
                {
                    "gp":         model.gp.state_dict(),
                    "likelihood": model.likelihood.state_dict(),
                },
                checkpoint,
            )
            if verbose: print(f"DKL surrogate saved → {str(checkpoint)}")

