#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os

from aps.common.scripts.generic_process_manager import GenericProcessManager
from aps.common.initializer import get_registered_ini_instance
from aps.common.reflection import instance_for_name, get_class_name_and_module

from aps.beamline_driver.common.bluesky import create_run_engine

from aps.ai.beamline_controller.initialization.facade import NullBeamlineControllerInitializer
from aps.ai.beamline_controller.initialization.beamline_controller_configuration import BeamlineControllerConfiguration


class IBeamlineControllerInitializationManager(GenericProcessManager):
    def get_available_beam_managers(self): raise NotImplementedError
    def get_configuration(self): raise NotImplementedError

class BeamlineControllerInitializationManager(IBeamlineControllerInitializationManager):
    def __init__(self, application_name: str, working_directory: str, optical_system_id: str, **kwargs):

        if application_name is None:  raise ValueError("Application name not specified")
        if working_directory is None: working_directory = os.getcwd()
        if optical_system_id is None: raise ValueError("Optical System ID not specified")

        self._application_name  = application_name
        self._optical_system_id = optical_system_id
        self._working_directory = working_directory

        self.reload_utils()
        self._setup_beamline_controller_initialization(**kwargs)

    def reload_utils(self):
        self._ini = get_registered_ini_instance(application_name=self._application_name)

    def get_available_beam_managers(self): return self._available_beam_managers
    def get_configuration(self) -> BeamlineControllerConfiguration: return self._configuration

    def _create_beamline_controller_initializer(self, **kwargs):
        beamline_controller_initializer_class, beamline_controller_initializer_module = get_class_name_and_module(self._ini.get_string_from_ini(section=self._optical_system_id,
                                                                                                                                                key="AI, initializer",
                                                                                                                   default="aps.ai.beamline_controller.initialization.facade.NullBeamlineControllerInitializer"))

        arguments = {"application_name": self._application_name,
                     "optical_system_id": self._optical_system_id,
                      "ini" : self._ini}
        arguments.update(kwargs)

        try:
            beamline_controller_initializer = instance_for_name(module_name=beamline_controller_initializer_module,
                                                  class_name=beamline_controller_initializer_class,
                                                  **arguments)

        except Exception as e:
            print("Failed to load Agent Initializer: " + str(e))
            beamline_controller_initializer = NullBeamlineControllerInitializer(application_name=self._application_name,
                                                                                optical_system_id=self._optical_system_id,
                                                                                ini=self._ini)

        return beamline_controller_initializer

    def _setup_beamline_controller_initialization(self, **kwargs):
        arguments = {"working_directory" : self._working_directory}
        arguments.update(kwargs)

        self._beamline_controller_initializer = self._create_beamline_controller_initializer(**kwargs)
        self._beamline_controller_initializer.preliminary_setup(**arguments)

        self._available_beam_managers, self._configuration = self._beamline_controller_initializer.initialize_beamline_controller(**kwargs)

    def _get_run_engine(self):
        try:
            run_engine  = self._beamline_controller_initializer.run_engine
            data_broker = self._beamline_controller_initializer.data_broker
        except:
            run_engine, data_broker = create_run_engine()

        return run_engine, data_broker