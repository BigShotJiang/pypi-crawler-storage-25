use crate::output;
use clap::{Arg, ArgMatches, Command};
use colored::Colorize;
use config::{Config, Session};
use tokio::{time, time::Duration};
use tower_api::models::CreateDeviceLoginTicketResponse;
use tower_telemetry::debug;

use crate::api;

pub fn login_cmd() -> Command {
    Command::new("login")
        .arg(
            Arg::new("no-browser")
                .long("no-browser")
                .short('n')
                .help("Do not attempt to open the browser automatically")
                .action(clap::ArgAction::SetTrue),
        )
        .about("Create a session with Tower")
}

pub async fn do_login(config: Config, args: &ArgMatches) {
    output::banner();

    if std::env::var("TOWER_API_KEY").is_ok() {
        output::write(&format!(
            "{} TOWER_API_KEY is set. As long as this environment variable is present, \
             the CLI will authenticate using the API key and ignore the session \
             created by this login flow.\n",
            "Warning:".yellow(),
        ));

        eprint!("Do you want to continue? [y/N] ");
        let mut input = String::new();
        if std::io::stdin().read_line(&mut input).is_err() || !input.trim().eq_ignore_ascii_case("y")
        {
            return;
        }
    }

    // Open a browser by default, unless the --no-browser flag is set.
    let open_browser = !args.get_flag("no-browser");

    let mut spinner = output::spinner("Starting device login...");

    match api::create_device_login_ticket(&config).await {
        Ok(resp) => {
            spinner.success();
            handle_device_login(config, open_browser, resp).await;
        }
        Err(err) => {
            spinner.failure();
            output::error(&format!("Failed to create device login ticket: {}", err));
        }
    }
}

async fn handle_device_login(
    config: Config,
    open_browser: bool,
    claim: CreateDeviceLoginTicketResponse,
) {
    // Put this in the debug logs just in case something weird happens.
    debug!("Login URL: {}", claim.login_url);

    let login_instructions = format!(
        "Please open the following URL in your browser: {}\n",
        claim.login_url
    );

    // Try to open the login URL in browser
    if open_browser {
        if let Err(err) = webbrowser::open(&claim.login_url) {
            debug!("failed to open web browser: {}", err);
            output::write(&login_instructions);
        } else {
            debug!("opened browser to {}", claim.login_url);
        }
    } else {
        output::write(&login_instructions);
    }

    let mut spinner = output::spinner("Waiting for login...");

    if !poll_for_login(&config, &claim, &mut spinner).await {
        spinner.failure();
        output::error("Login request expired. Please try again.");
    }
}

async fn poll_for_login(
    config: &Config,
    claim: &CreateDeviceLoginTicketResponse,
    spinner: &mut output::Spinner,
) -> bool {
    let interval_duration = Duration::from_secs(claim.interval as u64);
    let mut ticker = time::interval(interval_duration);

    let expires_in = chrono::Duration::seconds(claim.expires_in as i64);
    let expires_at = chrono::Utc::now() + expires_in;

    while chrono::Utc::now() < expires_at {
        match api::describe_device_login_session(&config, &claim.device_code).await {
            Ok(resp) => {
                finalize_session(config, &resp, spinner);
                return true;
            }
            Err(err) => {
                if let Some(api_err) = extract_api_error(&err) {
                    if api_err.status != 404 && !api_err.is_incomplete_device_login {
                        output::error(&format!("{}", api_err.content));
                        return false;
                    }
                } else {
                    output::error(&format!("An unexpected error happened! Error: {}", err));
                    return false;
                }
            }
        }

        // Keep waiting...
        ticker.tick().await;
    }
    false
}

fn finalize_session(
    config: &Config,
    session_response: &tower_api::models::DescribeDeviceLoginSessionResponse,
    spinner: &mut output::Spinner,
) {
    let mut session = Session::from_api_session(&session_response.session);

    let mut url = config.tower_url.clone();
    let local = matches!(url.host_str(), Some("localhost" | "127.0.0.1" | "::1"));
    if url.scheme() == "http" && !local {
        let _ = url.set_scheme("https");
    }
    session.tower_url = url;

    if let Err(err) = session.save() {
        spinner.failure();
        output::error(&format!("Failed to save session: {}", err));
    } else {
        spinner.success();
        let message = format!("Hello, {}!", session_response.session.user.email.clone());
        output::success(&message);
    }
}

fn extract_api_error<T>(err: &tower_api::apis::Error<T>) -> Option<ApiErrorDetails> {
    if let tower_api::apis::Error::ResponseError(err) = err {
        if let Ok(error_model) = serde_json::from_str::<tower_api::models::ErrorModel>(&err.content)
        {
            let is_incomplete_device_login = error_model
                .errors
                .as_ref()
                .and_then(|errors| errors.first())
                .and_then(|error| error.location.as_ref())
                .map(|message| message.contains("incomplete_device_login"))
                .unwrap_or(false);

            return Some(ApiErrorDetails {
                status: u16::from(err.status),
                content: err.content.clone(),
                is_incomplete_device_login,
            });
        }
    }
    None
}

// Struct to store extracted error details
struct ApiErrorDetails {
    status: u16,
    content: String,
    is_incomplete_device_login: bool,
}
