use std::future::Future;

use axum::Router;
use clap::Command;
use config::{Parameter, Session, Towerfile};
use crypto;
use rmcp::{
    handler::server::tool::{Parameters, ToolRouter},
    model::{
        CallToolResult, Content, Implementation, LoggingLevel, LoggingMessageNotificationParam,
        ProtocolVersion, ServerCapabilities, ServerInfo,
    },
    schemars::{self, JsonSchema},
    service::RequestContext,
    tool, tool_handler, tool_router,
    transport::{
        sse_server::SseServer,
        stdio,
        streamable_http_server::{
            session::local::LocalSessionManager, StreamableHttpServerConfig, StreamableHttpService,
        },
    },
    ErrorData as McpError, RoleServer, ServerHandler, ServiceExt,
};
use rsa::pkcs1::DecodeRsaPublicKey;
use serde::Deserialize;
use serde_json::{json, Value};
use tokio::net::TcpListener;
use tower_api::apis::Error as ApiError;

use crate::{api, deploy, run, towerfile_gen::TowerfileGenerator, Config, Error};

struct StreamingOutput {
    sender: tokio::sync::mpsc::UnboundedSender<String>,
    collected: std::sync::Arc<std::sync::Mutex<Vec<String>>>,
    task: tokio::task::JoinHandle<()>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct CommonParams {
    /// Optional working directory path. If not specified, uses the current directory.
    working_directory: Option<String>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct NameRequest {
    name: String,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct AppLogsRequest {
    name: String,
    seq: String,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct ListSecretsRequest {
    environment: Option<String>,
    all: Option<String>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct CreateSecretRequest {
    name: String,
    value: String,
    environment: Option<String>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct DeleteSecretRequest {
    name: String,
    environment: String,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct UpdateTowerfileRequest {
    #[serde(flatten)]
    common: CommonParams,
    app_name: Option<String>,
    script: Option<String>,
    description: Option<String>,
    source: Option<Vec<String>>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct AddParameterRequest {
    #[serde(flatten)]
    common: CommonParams,
    name: String,
    /// Description of the parameter. Required for regular parameters, omit for hidden parameters.
    description: Option<String>,
    /// Default value for the parameter. Mutually exclusive with hidden.
    default: Option<String>,
    /// Whether the parameter is hidden (value comes from secrets). Mutually exclusive with default.
    #[serde(default)]
    hidden: bool,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct EditParameterRequest {
    #[serde(flatten)]
    common: CommonParams,
    /// The name of the existing parameter to edit
    name: String,
    /// New name for the parameter
    new_name: Option<String>,
    /// New description for the parameter
    description: Option<String>,
    /// New default value for the parameter. Mutually exclusive with hidden.
    default: Option<String>,
    /// Set to true to make hidden, or false to make visible. Mutually exclusive with default.
    hidden: Option<bool>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct RemoveParameterRequest {
    #[serde(flatten)]
    common: CommonParams,
    /// The name of the parameter to remove
    name: String,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct GenerateTowerfileRequest {
    #[serde(flatten)]
    common: CommonParams,
    script_path: Option<String>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct CancelRunRequest {
    name: String,
    run_number: String,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct ScheduleRequest {
    app_name: String,
    environment: Option<String>,
    cron: String,
    parameters: Option<std::collections::HashMap<String, String>>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct UpdateScheduleRequest {
    schedule_id: String,
    cron: Option<String>,
    parameters: Option<std::collections::HashMap<String, String>>,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct EmptyRequest {
    #[serde(flatten)]
    common: CommonParams,
}

#[derive(Debug, Deserialize, JsonSchema)]
struct RunRequest {
    #[serde(flatten)]
    common: CommonParams,
    parameters: Option<std::collections::HashMap<String, String>>,
}

pub fn mcp_cmd() -> Command {
    Command::new("mcp-server")
        .about("Runs an MCP server for LLM interaction")
        .arg(
            clap::Arg::new("transport")
                .long("transport")
                .short('t')
                .help("Transport mode")
                .value_parser(["stdio", "sse", "http"])
                .default_value("stdio"),
        )
        .arg(
            clap::Arg::new("port")
                .long("port")
                .short('p')
                .help("Port for HTTP/SSE server (default: 34567)")
                .default_value("34567")
                .value_parser(clap::value_parser!(u16)),
        )
}

pub async fn do_mcp_server(config: Config, args: &clap::ArgMatches) -> Result<(), Error> {
    let transport = args.get_one::<String>("transport").unwrap();
    let port = *args.get_one::<u16>("port").unwrap();

    match transport.as_str() {
        "stdio" => run_stdio_server(config).await,
        "sse" => run_sse_server(config, port).await,
        "http" => run_http_server(config, port).await,
        _ => Err(Error::from(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("Unknown transport: {}", transport),
        ))),
    }
}

async fn run_stdio_server(config: Config) -> Result<(), Error> {
    // Set stdio MCP mode to prevent any non-JSON-RPC output from corrupting the protocol
    crate::output::set_output_mode(crate::output::OutputMode::McpStdio);

    let (stdin, stdout) = stdio();
    let service = TowerService::new(config);
    let server = service.serve((stdin, stdout)).await.map_err(|e| {
        Error::from(std::io::Error::new(
            std::io::ErrorKind::Other,
            format!("Failed to start stdio server: {}", e),
        ))
    })?;
    let _ = server.waiting().await;
    Ok(())
}

async fn run_sse_server(config: Config, port: u16) -> Result<(), Error> {
    let bind_addr = format!("127.0.0.1:{}", port);
    crate::output::write(&format!("SSE MCP server running on http://{}\n", bind_addr));

    // Set streaming MCP mode to enable logging notifications
    crate::output::set_output_mode(crate::output::OutputMode::McpStreaming);

    let ct = SseServer::serve(bind_addr.parse()?)
        .await?
        .with_service_directly(move || TowerService::new(config.clone()));

    tokio::signal::ctrl_c().await?;
    ct.cancel();
    Ok(())
}

async fn run_http_server(config: Config, port: u16) -> Result<(), Error> {
    let bind_addr = format!("127.0.0.1:{}", port);
    crate::output::write(&format!(
        "Streamable HTTP MCP server running on http://{}\n",
        bind_addr
    ));

    // Set streaming MCP mode to enable logging notifications
    crate::output::set_output_mode(crate::output::OutputMode::McpStreaming);

    let service = StreamableHttpService::new(
        move || Ok(TowerService::new(config.clone())),
        LocalSessionManager::default().into(),
        StreamableHttpServerConfig::default(),
    );

    let router = Router::new().nest_service("/mcp", service);
    let listener = TcpListener::bind(&bind_addr).await?;
    axum::serve(listener, router)
        .with_graceful_shutdown(async {
            tokio::signal::ctrl_c().await.unwrap();
        })
        .await?;
    Ok(())
}

#[derive(Clone)]
pub struct TowerService {
    config: Config,
    tool_router: ToolRouter<Self>,
}

#[tool_router]
impl TowerService {
    pub fn new(config: Config) -> Self {
        Self {
            config: std::env::var("TOWER_JWT")
                .ok()
                .and_then(|token| Session::from_jwt(&token).ok())
                .map(|session| config.clone().with_session(session))
                .unwrap_or(config),
            tool_router: Self::tool_router(),
        }
    }

    fn json_success<T: serde::Serialize>(data: T) -> Result<CallToolResult, McpError> {
        let text = serde_json::to_string_pretty(&data).map_err(|e| {
            McpError::internal_error(
                "Serialization failed",
                Some(json!({"error": e.to_string()})),
            )
        })?;
        Ok(CallToolResult::success(vec![Content::text(text)]))
    }

    fn text_success(message: String) -> Result<CallToolResult, McpError> {
        Ok(CallToolResult::success(vec![Content::text(message)]))
    }

    fn text_error(message: String) -> Result<CallToolResult, McpError> {
        Ok(CallToolResult::error(vec![Content::text(message)]))
    }

    fn error_result(
        prefix: &str,
        error: impl std::fmt::Display + std::fmt::Debug,
    ) -> Result<CallToolResult, McpError> {
        Ok(CallToolResult::error(vec![Content::text(format!(
            "{}: {:#?}",
            prefix, error
        ))]))
    }

    fn modify_towerfile(
        common: &CommonParams,
        f: impl FnOnce(&mut Towerfile) -> Result<String, String>,
    ) -> Result<CallToolResult, McpError> {
        let working_dir = Self::resolve_working_directory(common);
        let mut towerfile = match Towerfile::from_dir_str(working_dir.to_str().unwrap()) {
            Ok(tf) => tf,
            Err(e) => return Self::error_result("Failed to read Towerfile", e),
        };

        let message = match f(&mut towerfile) {
            Ok(msg) => msg,
            Err(msg) => return Self::text_error(msg),
        };

        let towerfile_path = working_dir.join("Towerfile");
        match towerfile.save(Some(&towerfile_path)) {
            Ok(_) => Self::text_success(message),
            Err(e) => Self::error_result("Failed to save Towerfile", e),
        }
    }

    fn resolve_working_directory(common: &CommonParams) -> std::path::PathBuf {
        common
            .working_directory
            .as_ref()
            .map(std::path::PathBuf::from)
            .unwrap_or_else(|| {
                std::env::current_dir().unwrap_or_else(|_| std::path::PathBuf::from("."))
            })
    }

    async fn list_teams_via_api(&self) -> Result<CallToolResult, McpError> {
        let response = api::list_teams(&self.config).await.map_err(|e| {
            McpError::internal_error(
                "Failed to list teams",
                Some(json!({"error": e.to_string()})),
            )
        })?;

        let teams: Vec<Value> = response
            .teams
            .into_iter()
            .map(|team| json!({"name": team.name}))
            .collect();

        Self::json_success(json!({"teams": teams}))
    }

    fn extract_api_error_message(error: &crate::Error) -> String {
        let crate::Error::ApiRunError { source } = error else {
            return error.to_string();
        };

        let ApiError::ResponseError(resp) = source else {
            return source.to_string();
        };

        Self::parse_error_response(resp)
            .or_else(|| Self::status_code_message(resp))
            .unwrap_or_else(|| format!("API error ({}): {}", resp.status, resp.content))
    }

    fn parse_error_response<T>(resp: &tower_api::apis::ResponseContent<T>) -> Option<String> {
        let error_model: tower_api::models::ErrorModel =
            serde_json::from_str(&resp.content).ok()?;

        error_model
            .detail
            .or_else(|| error_model.errors?.first()?.message.clone())
    }

    fn status_code_message<T>(resp: &tower_api::apis::ResponseContent<T>) -> Option<String> {
        match resp.status.as_u16() {
            404 => Some("App not found or not deployed".to_string()),
            422 => Some(format!("Validation error: {}", resp.content)),
            _ => None,
        }
    }

    fn is_deployment_error(message: &str) -> bool {
        message.contains("404")
            || message.contains("not found")
            || message.contains("not deployed")
            || (message.contains("API error occurred") && !message.contains("422"))
    }

    fn setup_output_capture(
        ctx: &RequestContext<RoleServer>,
        send_notifications: bool,
    ) -> StreamingOutput {
        let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel::<String>();
        let collected = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let collected_clone = collected.clone();

        let task = if send_notifications {
            let peer = ctx.peer.clone();
            tokio::spawn(async move {
                while let Some(message) = rx.recv().await {
                    if let Ok(mut output) = collected_clone.lock() {
                        output.push(message.clone());
                    }
                    let _ = peer.notify_logging_message(LoggingMessageNotificationParam {
                        level: LoggingLevel::Info,
                        data: serde_json::json!({"message": message, "timestamp": chrono::Utc::now().to_rfc3339()}),
                        logger: Some("tower-process".to_string()),
                    }).await;
                }
            })
        } else {
            tokio::spawn(async move {
                while let Some(message) = rx.recv().await {
                    if let Ok(mut output) = collected_clone.lock() {
                        output.push(message);
                    }
                }
            })
        };

        StreamingOutput {
            sender: tx,
            collected,
            task,
        }
    }

    async fn execute_with_streaming<F, Fut, T>(
        ctx: &RequestContext<RoleServer>,
        operation: F,
    ) -> (Result<T, crate::Error>, String)
    where
        F: FnOnce() -> Fut,
        Fut: std::future::Future<Output = Result<T, crate::Error>>,
    {
        // Check if we're in streaming mode (SSE/HTTP) where we send notifications
        // vs stdio mode where we don't
        let mode = crate::output::get_output_mode();
        let send_notifications = mode == crate::output::OutputMode::McpStreaming;
        let streaming = Self::setup_output_capture(ctx, send_notifications);

        crate::output::set_current_sender(streaming.sender.clone());

        let result = operation().await;

        crate::output::clear_current_sender();
        drop(streaming.sender);
        streaming.task.await.ok();

        let output = streaming
            .collected
            .lock()
            .ok()
            .map(|output| output.join("\n"))
            .unwrap_or_default();

        (result, output)
    }

    // Tool descriptions below should stay in sync with .about() in the corresponding command
    // files (apps.rs, secrets.rs, etc.). Proc macros require string literals so they can't
    // share constants directly. MCP-only descriptions (with Prerequisites/Optional) are
    // intentionally more detailed and don't need a CLI counterpart.
    #[tool(description = "List all apps in your Tower account")]
    async fn tower_apps_list(&self) -> Result<CallToolResult, McpError> {
        match api::list_apps(&self.config).await {
            Ok(response) => {
                let apps: Vec<Value> = response
                    .apps
                    .into_iter()
                    .map(|app_summary| {
                        let app = app_summary.app;
                        json!({
                            "name": app.name,
                            "description": app.short_description,
                            "created_at": app.created_at,
                            "status": format!("{:?}", app.status)
                        })
                    })
                    .collect();
                Self::json_success(json!({"apps": apps}))
            }
            Err(e) => Self::error_result("Failed to list apps", e),
        }
    }

    #[tool(description = "Create a new Tower app")]
    async fn tower_apps_create(
        &self,
        Parameters(request): Parameters<NameRequest>,
    ) -> Result<CallToolResult, McpError> {
        match api::create_app(&self.config, &request.name, "").await {
            Ok(response) => Self::text_success(format!("Created app '{}'", response.app.name)),
            Err(e) => Self::error_result("Failed to create app", e),
        }
    }

    #[tool(description = "Show details for a Tower app and its recent runs")]
    async fn tower_apps_show(
        &self,
        Parameters(request): Parameters<NameRequest>,
    ) -> Result<CallToolResult, McpError> {
        match api::describe_app(&self.config, &request.name).await {
            Ok(response) => {
                let data = json!({
                    "app": {
                        "name": response.app.name,
                        "description": response.app.short_description,
                        "created_at": response.app.created_at,
                        "status": format!("{:?}", response.app.status)
                    },
                    "recent_runs": response.runs.iter().map(|run| json!({
                        "number": run.number,
                        "status": format!("{:?}", run.status),
                        "scheduled_at": run.scheduled_at,
                        "started_at": run.started_at,
                        "ended_at": run.ended_at
                    })).collect::<Vec<_>>()
                });
                Self::json_success(data)
            }
            Err(e) => Self::error_result("Failed to show app", e),
        }
    }

    #[tool(description = "Get logs for a specific Tower app run")]
    async fn tower_apps_logs(
        &self,
        Parameters(request): Parameters<AppLogsRequest>,
    ) -> Result<CallToolResult, McpError> {
        let seq: i64 = request
            .seq
            .parse()
            .map_err(|_| McpError::invalid_params("seq must be a number", None))?;

        match api::describe_run_logs(&self.config, &request.name, seq).await {
            Ok(response) => {
                let logs = response
                    .log_lines
                    .into_iter()
                    .map(|log| format!("{}: {}", log.reported_at, log.content))
                    .collect::<Vec<_>>()
                    .join("\n");

                let msg = format!("Logs for app '{}' run {}:\n\n{}", request.name, seq, logs);
                Self::text_success(msg)
            }
            Err(e) => Self::error_result("Failed to get logs", e),
        }
    }

    #[tool(description = "Delete a Tower app")]
    async fn tower_apps_delete(
        &self,
        Parameters(request): Parameters<NameRequest>,
    ) -> Result<CallToolResult, McpError> {
        match api::delete_app(&self.config, &request.name).await {
            Ok(_) => Self::text_success(format!("Deleted app '{}'", request.name)),
            Err(e) => Self::error_result("Failed to delete app", e),
        }
    }

    #[tool(description = "Cancel a running Tower app run")]
    async fn tower_apps_cancel(
        &self,
        Parameters(request): Parameters<CancelRunRequest>,
    ) -> Result<CallToolResult, McpError> {
        let seq: i64 = request
            .run_number
            .parse()
            .map_err(|_| McpError::invalid_params("run_number must be a number", None))?;

        match api::cancel_run(&self.config, &request.name, seq).await {
            Ok(response) => {
                let status = format!("{:?}", response.run.status);
                Self::text_success(format!(
                    "Cancelled run #{} for '{}' (status: {})",
                    seq, request.name, status
                ))
            }
            Err(e) => Self::error_result("Failed to cancel run", e),
        }
    }

    #[tool(description = "List secrets in your Tower account (shows only previews for security)")]
    async fn tower_secrets_list(
        &self,
        Parameters(request): Parameters<ListSecretsRequest>,
    ) -> Result<CallToolResult, McpError> {
        let environment = request.environment.as_deref().unwrap_or("default");
        let all = request.all.as_deref() == Some("true");

        match api::list_secrets(&self.config, environment, all).await {
            Ok(response) => Self::json_success(json!({"secrets": response.secrets})),
            Err(e) => Self::error_result("Failed to list secrets", e),
        }
    }

    #[tool(description = "Create a new secret in Tower")]
    async fn tower_secrets_create(
        &self,
        Parameters(request): Parameters<CreateSecretRequest>,
    ) -> Result<CallToolResult, McpError> {
        let environment = request.environment.as_deref().unwrap_or("default");

        let key_response = api::describe_secrets_key(&self.config).await.map_err(|e| {
            McpError::internal_error("Failed to get key", Some(json!({"error": e.to_string()})))
        })?;

        let public_key =
            rsa::RsaPublicKey::from_pkcs1_pem(&key_response.public_key).map_err(|e| {
                McpError::internal_error(
                    "Invalid public key",
                    Some(json!({"error": e.to_string()})),
                )
            })?;

        let encrypted_value = crypto::encrypt(public_key, request.value.clone()).map_err(|e| {
            McpError::internal_error("Encryption failed", Some(json!({"error": e.to_string()})))
        })?;

        let preview = if request.value.len() <= 10 {
            "XXXXXXXXXX".to_string()
        } else {
            format!("XXXXXX{}", &request.value[request.value.len() - 4..])
        };

        match api::create_secret(
            &self.config,
            &request.name,
            environment,
            &encrypted_value,
            &preview,
        )
        .await
        {
            Ok(_) => Self::text_success(format!(
                "Created secret '{}' in environment '{}'",
                request.name, environment
            )),
            Err(e) => Self::error_result("Failed to create secret", e),
        }
    }

    #[tool(description = "Delete a secret from Tower")]
    async fn tower_secrets_delete(
        &self,
        Parameters(request): Parameters<DeleteSecretRequest>,
    ) -> Result<CallToolResult, McpError> {
        match api::delete_secret(&self.config, &request.name, &request.environment).await {
            Ok(_) => Self::text_success(format!(
                "Deleted secret '{}' from environment '{}'",
                request.name, request.environment
            )),
            Err(e) => Self::error_result("Failed to delete secret", e),
        }
    }

    #[tool(description = "List teams you belong to")]
    async fn tower_teams_list(&self) -> Result<CallToolResult, McpError> {
        if self.config.api_key.is_some() {
            return self.list_teams_via_api().await;
        }

        let response = api::refresh_session(&self.config).await.map_err(|e| {
            McpError::internal_error(
                "Failed to refresh session",
                Some(json!({"error": e.to_string()})),
            )
        })?;

        let mut session = self.config.get_current_session().map_err(|e| {
            McpError::internal_error("No valid session", Some(json!({"error": e.to_string()})))
        })?;

        session.update_from_api_response(&response).map_err(|e| {
            McpError::internal_error(
                "Failed to update session",
                Some(json!({"error": e.to_string()})),
            )
        })?;

        let active_team_name = session.active_team.as_ref().map(|t| &t.name);
        let teams: Vec<Value> = session
            .teams
            .into_iter()
            .map(|team| json!({"name": team.name, "active": Some(&team.name) == active_team_name}))
            .collect();

        Self::json_success(json!({"teams": teams}))
    }

    #[tool(description = "Switch context to a different team")]
    async fn tower_teams_switch(
        &self,
        Parameters(request): Parameters<NameRequest>,
    ) -> Result<CallToolResult, McpError> {
        match self.config.set_active_team_by_name(&request.name) {
            Ok(_) => Self::text_success(format!("Switched to team: {}", request.name)),
            Err(e) => Self::error_result("Failed to switch team", e),
        }
    }

    #[tool(
        description = "Deploy to Tower cloud. Prerequisites: Towerfile, tower_apps_create. Optional: working_directory."
    )]
    async fn tower_deploy(
        &self,
        Parameters(request): Parameters<EmptyRequest>,
    ) -> Result<CallToolResult, McpError> {
        let working_dir = Self::resolve_working_directory(&request.common);
        let deploy_target = deploy::DeployTarget::Environment("default".to_string());

        match deploy::deploy_from_dir(self.config.clone(), working_dir, true, deploy_target).await {
            Ok(_) => Self::text_success("Deploy completed successfully".to_string()),
            Err(e) => Self::error_result("Deploy failed", e),
        }
    }

    #[tool(
        description = "Run locally using Towerfile (preferred during development, has access to tower secrets). Prerequisites: Towerfile. Optional: working_directory."
    )]
    async fn tower_run_local(
        &self,
        Parameters(request): Parameters<EmptyRequest>,
        ctx: RequestContext<RoleServer>,
    ) -> Result<CallToolResult, McpError> {
        let working_dir = Self::resolve_working_directory(&request.common);
        let config = self.config.clone();

        let (result, output) = Self::execute_with_streaming(&ctx, || {
            run::do_run_local(
                config,
                working_dir,
                "default",
                std::collections::HashMap::new(),
            )
        })
        .await;
        match result {
            Ok(_) => {
                if output.trim().is_empty() {
                    Self::text_success("App completed successfully".to_string())
                } else {
                    Self::text_success(format!("App completed successfully\n\n{}", output))
                }
            }
            Err(e) => {
                let error_text = if output.trim().is_empty() {
                    e.to_string()
                } else {
                    output
                };
                Self::error_result("Local run failed", error_text)
            }
        }
    }

    #[tool(
        description = "Run an app on Tower cloud. Pass parameters as a JSON object, e.g. {\"key\": \"value\"}. Prerequisites: Towerfile, tower_apps_create, tower_deploy."
    )]
    async fn tower_run_remote(
        &self,
        Parameters(request): Parameters<RunRequest>,
        ctx: RequestContext<RoleServer>,
    ) -> Result<CallToolResult, McpError> {
        use config::Towerfile;

        let config = self.config.clone();
        let working_dir = Self::resolve_working_directory(&request.common);
        let path = working_dir;
        let env = "default";
        let params = request.parameters.unwrap_or_default();

        // Load Towerfile to get app name
        let towerfile = match Towerfile::from_dir_str(path.to_str().unwrap()) {
            Ok(tf) => tf,
            Err(e) => return Self::error_result("Failed to read Towerfile", e),
        };

        let app_name = towerfile.app.name.clone();

        let (result, output) = Self::execute_with_streaming(&ctx, || {
            run::do_run_remote(config, path, env, params, None, true)
        })
        .await;
        match result {
            Ok(_) => {
                if output.trim().is_empty() {
                    Self::text_success("Remote run completed successfully".to_string())
                } else {
                    Self::text_success(format!("Remote run completed successfully\n\n{}", output))
                }
            }
            Err(e) => {
                // Always extract the detailed API error message
                let api_error = Self::extract_api_error_message(&e);
                let error_text = if Self::is_deployment_error(&api_error) {
                    format!(
                        "App '{}' not deployed. Try running tower_deploy first.",
                        app_name
                    )
                } else {
                    api_error
                };
                Self::error_result("Remote run failed", error_text)
            }
        }
    }

    #[tool(description = "Read and parse Towerfile configuration. Optional: working_directory.")]
    async fn tower_file_read(
        &self,
        Parameters(request): Parameters<EmptyRequest>,
    ) -> Result<CallToolResult, McpError> {
        let working_dir = Self::resolve_working_directory(&request.common);
        match Towerfile::from_dir_str(working_dir.to_str().unwrap()) {
            Ok(towerfile) => Self::json_success(serde_json::to_value(&towerfile).unwrap()),
            Err(e) => Self::error_result("Failed to read Towerfile", e),
        }
    }

    #[tool(
        description = "Update Towerfile config (app name, script, description, source). Use this instead of editing TOML. Optional: working_directory."
    )]
    async fn tower_file_update(
        &self,
        Parameters(request): Parameters<UpdateTowerfileRequest>,
    ) -> Result<CallToolResult, McpError> {
        Self::modify_towerfile(&request.common, |tf| {
            if let Some(name) = request.app_name {
                tf.app.name = name;
            }
            if let Some(script) = request.script {
                tf.app.script = script;
            }
            if let Some(description) = request.description {
                tf.app.description = Some(description);
            }
            if let Some(source) = request.source {
                tf.app.source = source;
            }
            Ok("Towerfile updated".into())
        })
    }

    #[tool(
        description = "Add parameter to Towerfile. For regular params provide description and default. For hidden params set hidden=true (no default). Optional: working_directory."
    )]
    async fn tower_file_add_parameter(
        &self,
        Parameters(request): Parameters<AddParameterRequest>,
    ) -> Result<CallToolResult, McpError> {
        if request.hidden && request.default.is_some() {
            return Self::text_error("hidden and default are mutually exclusive".into());
        }
        let name = request.name.clone();
        Self::modify_towerfile(&request.common, |tf| {
            tf.set_parameter(&name, Parameter {
                name: name.clone(),
                description: request.description.unwrap_or_default(),
                default: request.default.unwrap_or_default(),
                hidden: request.hidden,
            });
            Ok(format!("Added parameter '{name}'"))
        })
    }

    #[tool(
        description = "Edit an existing parameter in the Towerfile. Provide only the fields to change. hidden and default are mutually exclusive. Optional: working_directory."
    )]
    async fn tower_file_edit_parameter(
        &self,
        Parameters(request): Parameters<EditParameterRequest>,
    ) -> Result<CallToolResult, McpError> {
        let name = request.name.clone();
        Self::modify_towerfile(&request.common, |tf| {
            let existing = tf.parameters.iter().find(|p| p.name == name)
                .ok_or_else(|| format!("Parameter '{name}' not found"))?;
            let target_name = request
                .new_name
                .clone()
                .unwrap_or_else(|| existing.name.clone());
            if target_name != name && tf.parameters.iter().any(|p| p.name == target_name) {
                return Err(format!("Parameter '{}' already exists", target_name));
            }
            let param = Parameter {
                name: target_name,
                description: request.description.unwrap_or_else(|| existing.description.clone()),
                default: request.default.unwrap_or_else(|| existing.default.clone()),
                hidden: request.hidden.unwrap_or(existing.hidden),
            };
            if param.hidden && !param.default.is_empty() {
                return Err("hidden and default are mutually exclusive".into());
            }
            tf.set_parameter(&name, param);
            Ok(format!("Updated parameter '{name}'"))
        })
    }

    #[tool(
        description = "Remove a parameter from the Towerfile. Optional: working_directory."
    )]
    async fn tower_file_remove_parameter(
        &self,
        Parameters(request): Parameters<RemoveParameterRequest>,
    ) -> Result<CallToolResult, McpError> {
        let name = request.name.clone();
        Self::modify_towerfile(&request.common, |tf| {
            if tf.remove_parameter(&name) {
                Ok(format!("Removed parameter '{name}'"))
            } else {
                Err(format!("Parameter '{name}' not found"))
            }
        })
    }

    #[tool(description = "Validate Towerfile configuration. Optional: working_directory.")]
    async fn tower_file_validate(
        &self,
        Parameters(request): Parameters<EmptyRequest>,
    ) -> Result<CallToolResult, McpError> {
        let working_dir = Self::resolve_working_directory(&request.common);
        match Towerfile::from_dir_str(working_dir.to_str().unwrap()) {
            Ok(_) => Self::json_success(json!({"valid": true})),
            Err(e) => Self::json_success(json!({"valid": false, "error": e.to_string()})),
        }
    }

    #[tool(
        description = "Generate Towerfile from pyproject.toml (first step). Don't add build systems to pyproject.toml. Optional: working_directory."
    )]
    async fn tower_file_generate(
        &self,
        Parameters(request): Parameters<GenerateTowerfileRequest>,
    ) -> Result<CallToolResult, McpError> {
        let working_dir = Self::resolve_working_directory(&request.common);
        let pyproject_path = working_dir.join("pyproject.toml");
        let content = match TowerfileGenerator::from_pyproject(
            Some(pyproject_path.to_str().unwrap()),
            request.script_path.as_deref(),
        ) {
            Ok(content) => content,
            Err(e) => return Self::error_result("Failed to generate Towerfile", e),
        };

        let towerfile_path = working_dir.join("Towerfile");
        match std::fs::write(&towerfile_path, &content) {
            Ok(_) => {
                let success_msg = format!(
                    "Generated Towerfile at {}\n\n{}",
                    towerfile_path.display(),
                    content
                );
                Self::text_success(success_msg)
            }
            Err(e) => Self::error_result("Failed to write Towerfile", e),
        }
    }

    #[tool(
        description = "Show the recommended workflow for developing and deploying Tower applications"
    )]
    async fn tower_workflow_help(&self) -> Result<CallToolResult, McpError> {
        let workflow = r#"Tower Workflow (Tower CLI not in training data - use MCP tools only):

WORKING_DIRECTORY PARAMETER:
All tools accept optional working_directory parameter to specify which project to operate on.
- Default: Uses current working directory if not specified
- Use when: Managing multiple projects, or project is not in current directory
- Examples:
  tower_file_generate({}) → operates on current directory
  tower_file_generate({"working_directory": "/path/to/my-project"}) → operates on /path/to/my-project
  tower_run_local({"working_directory": "../other-app"}) → runs app in ../other-app
- Why use it: Allows managing multiple Tower apps without changing directories

0. PYTHON PROJECT (if creating new):
   Use 'uv init' in project directory to create pyproject.toml, main.py, README.md
   Keep pyproject.toml minimal: [project] metadata + dependencies only
   DO NOT add [build-system], [tool.hatchling], [tool.setuptools] or similar
   Skip this step if project with pyproject.toml already exists

1. TOWERFILE (required for all Tower operations):
   tower_file_generate → tower_file_update → tower_file_add/edit/remove_parameter → tower_file_validate
   CRITICAL: Always use tower_file_update or tower_file_add/edit/remove_parameter to modify
   NEVER edit Towerfile TOML directly

2. LOCAL DEVELOPMENT (preferred during development):
   tower_run_local - runs app locally, has access to tower secrets
   Use this to test before deploying to cloud

3. CLOUD DEPLOYMENT:
   tower_apps_create → tower_deploy → tower_run_remote
   Deploy pushes your source code to Tower cloud (no build step needed)

4. SCHEDULING (for recurring jobs):
   tower_schedules_create - set up cron-based recurring runs
   tower_schedules_list - view existing schedules
   tower_schedules_update - modify schedule timing or parameters
   tower_schedules_delete - remove schedules

5. MANAGEMENT & MONITORING:
   tower_apps_list - list all your apps
   tower_apps_show - details and recent runs for specific app
   tower_apps_logs - view logs from a specific run
   tower_teams_list, tower_teams_switch - manage team contexts
   tower_secrets_create, tower_secrets_list - store credentials, API keys, database passwords

TYPICAL WORKFLOW:
1. Check if pyproject.toml exists (or create with uv init)
2. tower_file_generate - creates Towerfile from pyproject.toml
3. tower_run_local - test locally (can access tower secrets)
4. tower_apps_create - create app in Tower cloud
5. tower_deploy - deploy code to Tower
6. tower_run_remote - run on cloud infrastructure
7. tower_schedules_create - (optional) set up recurring runs

IMPORTANT REMINDERS:
- Tower deploys source code directly, no build tools needed
- Use tower secrets for sensitive data (database credentials, API keys)
- Prefer tower_run_local during development (faster, has secret access)
- Always use MCP tools to modify Towerfiles (never edit TOML files manually)"#;

        Self::text_success(workflow.to_string())
    }

    #[tool(description = "List all schedules for apps")]
    async fn tower_schedules_list(&self) -> Result<CallToolResult, McpError> {
        match api::list_schedules(&self.config, None, None).await {
            Ok(response) => {
                let schedules = response
                    .schedules
                    .into_iter()
                    .map(|mut schedule| {
                        if let Some(parameters) = schedule.parameters.as_mut() {
                            for parameter in parameters {
                                if parameter.hidden.unwrap_or(false) {
                                    parameter.value = "[hidden]".to_string();
                                }
                            }
                        }
                        schedule
                    })
                    .collect::<Vec<_>>();

                Self::json_success(serde_json::json!({"schedules": schedules}))
            }
            Err(e) => Self::error_result("Failed to list schedules", e),
        }
    }

    #[tool(description = "Create a new schedule for an app")]
    async fn tower_schedules_create(
        &self,
        Parameters(request): Parameters<ScheduleRequest>,
    ) -> Result<CallToolResult, McpError> {
        let environment = request.environment.as_deref().unwrap_or("default");

        match api::create_schedule(
            &self.config,
            &request.app_name,
            environment,
            &request.cron,
            request.parameters,
        )
        .await
        {
            Ok(response) => Self::text_success(format!(
                "Created schedule '{}' for app '{}' with cron '{}' in environment '{}'",
                response.schedule.id, request.app_name, request.cron, environment
            )),
            Err(e) => Self::error_result("Failed to create schedule", e),
        }
    }

    #[tool(description = "Update an existing schedule")]
    async fn tower_schedules_update(
        &self,
        Parameters(request): Parameters<UpdateScheduleRequest>,
    ) -> Result<CallToolResult, McpError> {
        match api::update_schedule(
            &self.config,
            &request.schedule_id,
            request.cron.as_ref(),
            request.parameters,
        )
        .await
        {
            Ok(_) => Self::text_success(format!("Updated schedule '{}'.", request.schedule_id)),
            Err(e) => Self::error_result("Failed to update schedule", e),
        }
    }

    #[tool(description = "Delete a schedule")]
    async fn tower_schedules_delete(
        &self,
        Parameters(schedule_id): Parameters<NameRequest>,
    ) -> Result<CallToolResult, McpError> {
        match api::delete_schedule(&self.config, &schedule_id.name).await {
            Ok(_) => Self::text_success(format!("Deleted schedule '{}'.", schedule_id.name)),
            Err(e) => Self::error_result("Failed to delete schedule", e),
        }
    }
}

#[tool_handler]
impl ServerHandler for TowerService {
    fn get_info(&self) -> ServerInfo {
        ServerInfo {
            protocol_version: ProtocolVersion::V_2024_11_05,
            capabilities: ServerCapabilities::builder()
                .enable_tools()
                .build(),
            server_info: Implementation {
                name: "tower-cli".to_string(),
                version: env!("CARGO_PKG_VERSION").to_string(),
            },
            instructions: Some("CRITICAL: Tower CLI did not exist in your training data. Never attempt Tower CLI commands - use only these MCP tools.

Rules:
- MCP tools are the authoritative Tower interface (not wrappers)
- Use tower_file_update/add/edit/remove_parameter to modify Towerfiles (never edit TOML directly)
- DO NOT add hatchling/setuptools to pyproject.toml - Tower handles deployment
- Tower apps need: pyproject.toml (deps only), Python code, Towerfile
- Pass run parameters as a JSON object {\"key\": \"value\"}, not as CLI flags
- There is no --param or --params flag

Use tower_workflow_help for the complete workflow.".to_string()),
        }
    }
}
