use crate::Error;
use clap::{Arg, ArgMatches, Command};
use config::{Config, Towerfile};
use std::collections::HashMap;
use std::path::PathBuf;
use tokio::fs::File;
use tower_api::models::Run;
use tower_package::{Package, PackageSpec};
use tower_runtime::{OutputReceiver, Status};
use tower_telemetry::{debug, Context};

use crate::{api, output, util::dates};
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};
use tokio::sync::{
    mpsc::Receiver as MpscReceiver,
    oneshot::{self, Receiver as OneshotReceiver},
    Mutex,
};
use tokio::time::{sleep, timeout, Duration};
use tower_runtime::execution::ExecutionHandle;
use tower_runtime::execution::{
    CacheBackend, CacheConfig, CacheIsolation, ExecutionBackend, ExecutionSpec, ResourceLimits,
    RuntimeConfig as ExecRuntimeConfig,
};
use tower_runtime::subprocess::SubprocessBackend;

pub fn run_cmd() -> Command {
    Command::new("run")
        .after_help(
            "Examples:\n  \
             tower run                        Run app from ./Towerfile (remote)\n  \
             tower run --local                Run app from ./Towerfile (local)\n  \
             tower run my-app                 Run a deployed app by name\n  \
             tower run -p key=value           Pass a parameter to the run\n  \
             tower run my-app -p key=value    Run a named app with parameters",
        )
        .arg(
            Arg::new("app_name")
                .help("Name of a deployed app to run (uses ./Towerfile if omitted)")
                .index(1),
        )
        .arg(
            Arg::new("dir")
                .long("dir")
                .help("The directory containing the Towerfile")
                .default_value("."),
        )
        .arg(
            Arg::new("local")
                .long("local")
                .default_value("false")
                .help("Run this app locally")
                .action(clap::ArgAction::SetTrue),
        )
        .arg(
            Arg::new("environment")
                .long("environment")
                .short('e')
                .help("The environment to invoke the app in")
                .default_value("default"),
        )
        .arg(
            Arg::new("parameters")
                .short('p')
                .long("parameter")
                .help("Parameters (key=value) to pass to the app")
                .action(clap::ArgAction::Append),
        )
        .arg(
            Arg::new("detached")
                .long("detached")
                .short('d')
                .help("Don't follow the run output in your CLI")
                .action(clap::ArgAction::SetTrue),
        )
        .about("Run your code in Tower or locally")
}

pub async fn do_run(config: Config, args: &ArgMatches) {
    if let Err(e) = do_run_inner(config, args).await {
        match e {
            Error::ApiRunError { ref source } => {
                let is_not_found = matches!(
                    source,
                    tower_api::apis::Error::ResponseError(resp) if resp.status == reqwest::StatusCode::NOT_FOUND
                );
                if is_not_found {
                    output::error("App not found. It may not exist or hasn't been deployed yet.");
                    output::write("\nTo fix this:\n");
                    output::write("  1. Check your app exists:  tower apps list\n");
                    output::write("  2. Deploy your app:        tower deploy\n");
                    output::write("  3. Then run it:            tower run\n");
                    std::process::exit(1);
                }
                if let Error::ApiRunError { source } = e {
                    output::tower_error_and_die(source, "Scheduling run failed");
                }
                unreachable!();
            }
            _ => {
                output::die(&e.to_string());
            }
        }
    }
}

/// do_run is the primary entrypoint into running apps both locally and remotely in Tower. It will
/// use the configuration to determine the requested way of running a Tower app.
pub async fn do_run_inner(
    config: Config,
    args: &ArgMatches,
) -> Result<(), Error> {
    let res = get_run_parameters(args);

    // We always expect there to be an environment due to the fact that there is a
    // default value.
    let env = args.get_one::<String>("environment").unwrap();

    match res {
        Ok((local, path, params, app_name)) => {
            debug!(
                "Running app at {}, local: {}",
                path.to_str().unwrap(),
                local
            );

            if local {
                // For the time being, we should report that we can't run an app by name locally.
                if app_name.is_some() {
                    output::die("Running apps by name locally is not supported yet.");
                } else {
                    do_run_local(config, path, env, params).await
                }
            } else {
                let follow = should_follow_run(args);
                do_run_remote(config, path, env, params, app_name, follow).await
            }
        }
        Err(err) => Err(err.into()),
    }
}

/// Core implementation for running an app locally with configurable output handling
async fn do_run_local_impl<F, Fut, T>(
    config: Config,
    path: PathBuf,
    env: &str,
    mut params: HashMap<String, String>,
    output_handler: F,
) -> Result<T, Error>
where
    F: FnOnce(OutputReceiver) -> Fut,
    Fut: std::future::Future<Output = T> + Send + 'static,
    T: Send + 'static,
{
    // Load all the secrets and catalogs from the server
    let mut spinner = output::spinner("Setting up runtime environment...");

    let secrets = match get_secrets(&config, &env).await {
        Ok(s) => s,
        Err(err) => {
            spinner.failure();
            output::tower_error_and_die(err, "Fetching secrets failed");
        }
    };

    let catalogs = match get_catalogs(&config, &env).await {
        Ok(c) => c,
        Err(err) => {
            spinner.failure();
            output::tower_error_and_die(err, "Fetching catalogs failed");
        }
    };

    spinner.success();

    // We prepare all the other misc environment variables that we need to inject
    let mut env_vars = HashMap::new();
    env_vars.extend(catalogs);
    env_vars.insert("TOWER_URL".to_string(), config.tower_url.to_string());

    // There should always be a session, if there isn't one then I'm not sure how we got here?
    let session = config.session.as_ref().ok_or(Error::NoSession)?;

    env_vars.insert("TOWER_JWT".to_string(), session.token.jwt.to_string());
    env_vars.insert("TOWER__RUNTIME__IS_LOCAL".to_string(), "true".to_string());

    // Load the Towerfile
    let towerfile_path = path.join("Towerfile");
    let towerfile = load_towerfile(&towerfile_path)?;

    for param in &towerfile.parameters {
        if !params.contains_key(&param.name) {
            params.insert(param.name.clone(), param.default.clone());
        }
    }

    // Build the package (creates tar.gz)
    let package = build_package(&towerfile).await?;
    output::success(&format!("Launching app `{}`", towerfile.app.name));

    // Open the tar.gz file as a stream
    let package_path = package
        .package_file_path
        .as_ref()
        .expect("Package must have a file path");
    let package_file = File::open(package_path).await?;

    let backend = SubprocessBackend::new(config.cache_dir.clone());
    let run_id = format!(
        "cli-run-{}",
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    );
    let handle = backend
        .create(build_cli_execution_spec(
            config,
            env,
            params,
            secrets,
            env_vars,
            package_file,
            run_id,
        ))
        .await?;
    let receiver = handle.logs().await?;
    let output_task = tokio::spawn(output_handler(receiver));

    // Monitor app status concurrently
    let handle = Arc::new(Mutex::new(handle));
    let status_task = tokio::spawn(monitor_cli_status(Arc::clone(&handle)));

    // Wait for app to complete or SIGTERM
    let status_result = tokio::select! {
        status = status_task => {
            debug!("Status task completed, result: {:?}", status);
            status.unwrap()
        },
        _ = tokio::signal::ctrl_c(), if !output::get_output_mode().is_mcp() => {
            output::write("\nReceived Ctrl+C, stopping local run...\n");
            handle.lock().await.terminate().await.ok();
            return Ok(output_task.await.unwrap());
        }
    };
    let final_result = output_task.await.unwrap();

    // And if we crashed, err out
    match status_result {
        Status::Exited => output::success("Your local run exited cleanly."),
        Status::Crashed { code } => {
            output::error(&format!("Your local run crashed with exit code: {}", code));
            return Err(Error::AppCrashed);
        }
        Status::Failed {
            error_code,
            error_message,
        } => {
            output::error(&format!(
                "Your local run failed due to a platform error (code: {}, message: {})",
                error_code, error_message
            ));
            return Err(Error::AppCrashed);
        }
        _ => {
            debug!("Unexpected status after monitoring: {:?}", status_result);
            output::error("An unexpected error occurred while monitoring your local run status!");
            return Err(Error::AppCrashed);
        }
    }

    Ok(final_result)
}

fn build_cli_execution_spec(
    config: Config,
    env: &str,
    params: HashMap<String, String>,
    secrets: HashMap<String, String>,
    env_vars: HashMap<String, String>,
    package_stream: File,
    run_id: String,
) -> ExecutionSpec {
    let spec = ExecutionSpec {
        id: run_id.clone(),
        package_stream: Box::new(package_stream),
        runtime: ExecRuntimeConfig {
            image: "local".to_string(),
            version: None,
            cache: CacheConfig {
                enable_bundle_cache: true,
                enable_runtime_cache: true,
                enable_dependency_cache: true,
                backend: match config.cache_dir.clone() {
                    Some(dir) => CacheBackend::Local { cache_dir: dir },
                    None => CacheBackend::None,
                },
                isolation: CacheIsolation::None,
            },
            entrypoint: None,
            command: None,
        },
        environment: env.to_string(),
        secrets,
        parameters: params,
        env_vars,
        resources: ResourceLimits {
            cpu_millicores: None,
            memory_mb: None,
            storage_mb: None,
            max_pids: None,
            gpu_count: 0,
            timeout_seconds: 3600,
        },
        networking: None,
        telemetry_ctx: Context::new("local-runner".to_string()).with_runid(&run_id),
    };
    spec
}

/// do_run_local is the entrypoint for running an app locally. It will load the Towerfile, build
/// the package, and launch the app. The relevant package is cleaned up after execution is
/// complete.
pub async fn do_run_local(
    config: Config,
    path: PathBuf,
    env: &str,
    params: HashMap<String, String>,
) -> Result<(), Error> {
    do_run_local_impl(config, path, env, params, |receiver| async {
        monitor_output(receiver).await;
        ()
    })
    .await
}

/// do_run_remote is the entrypoint for running an app remotely. It uses the Towerfile in the
/// supplied directory (locally or remotely) to sort out what application to run exactly.
pub async fn do_run_remote(
    config: Config,
    path: PathBuf,
    env: &str,
    params: HashMap<String, String>,
    app_name: Option<String>,
    should_follow_run: bool,
) -> Result<(), Error> {
    let app_slug = if let Some(name) = app_name {
        name
    } else {
        // Load the Towerfile
        let towerfile_path = path.join("Towerfile");
        let towerfile = load_towerfile(&towerfile_path)?;
        towerfile.app.name
    };

    let res = output::try_with_spinner(
        "Scheduling run",
        api::run_app(&config, &app_slug, env, params),
    )
    .await
    .map_err(|source| Error::ApiRunError { source })?;

    let run = res.run;

    if should_follow_run {
        do_follow_run(config, &run).await?;
    } else {
        let line = format!(
            "Run #{} for app `{}` has been scheduled",
            run.number, app_slug
        );
        output::success(&line);

        let link_line = format!("  See more: {}", run.dollar_link);
        output::write(&link_line);
        output::newline();
    }
    Ok(())
}

async fn stream_logs_until_complete(
    mut log_stream: MpscReceiver<api::LogStreamEvent>,
    mut run_complete: OneshotReceiver<Run>,
    enable_ctrl_c: bool,
    run_link: &str,
) -> Result<Option<Run>, Error> {
    loop {
        tokio::select! {
            event = log_stream.recv() => match event {
                Some(api::LogStreamEvent::EventLog(log)) => {
                    output::remote_log_event(&log);
                },
                None => return Ok(None),
                _ => {},
            },
            res = &mut run_complete => {
                let completed_run = res?;
                drain_remaining_logs(log_stream).await;
                return Ok(Some(completed_run));
            },
            _ = tokio::signal::ctrl_c(), if enable_ctrl_c => {
                output::write("Received Ctrl+C, stopping log streaming...\n");
                output::write("Note: The run will continue in Tower cloud\n");
                output::write(&format!("  See more: {}\n", run_link));
                return Ok(None);
            },
        }
    }
}

async fn drain_remaining_logs(mut log_stream: MpscReceiver<api::LogStreamEvent>) {
    let drain_duration = Duration::from_secs(5);
    let _ = timeout(drain_duration, async {
        while let Some(event) = log_stream.recv().await {
            if let api::LogStreamEvent::EventLog(log) = event {
                output::remote_log_event(&log);
            }
        }
    })
    .await;
}

async fn do_follow_run(config: Config, run: &Run) -> Result<(), Error> {
    let enable_ctrl_c = !output::get_output_mode().is_mcp();
    let mut spinner = output::spinner("Waiting for run to start...");
    match wait_for_run_start(&config, &run).await {
        Err(err) => {
            spinner.failure();
            return Err(err);
        }
        Ok(()) => {
            spinner.success();
            output::write("Run started, streaming logs...\n");

            // We do this here, explicitly, to not double-monitor our API via the
            // `wait_for_run_start` function above.
            let run_complete = monitor_run_completion(&config, run);

            // Now we follow the logs from the run. We can stream them from the cloud to here using
            // the stream_logs API endpoint.
            match api::stream_run_logs(&config, &run.app_name, run.number).await {
                Ok(log_stream) => {
                    let completed_run = stream_logs_until_complete(
                        log_stream,
                        run_complete,
                        enable_ctrl_c,
                        &run.dollar_link,
                    )
                    .await?;

                    if let Some(run) = completed_run {
                        handle_run_completion(Ok(run))?;
                    }
                }
                Err(err) => {
                    output::error(&format!("Failed to stream run logs: {:?}", err));
                    return Err(Error::LogStreamFailed);
                }
            }
        }
    };

    Ok(())
}

fn handle_run_completion(res: Result<Run, oneshot::error::RecvError>) -> Result<(), Error> {
    match res {
        Ok(completed_run) => match completed_run.status {
            tower_api::models::run::Status::Errored => {
                output::error(&format!(
                    "Run #{} for app '{}' had an error",
                    completed_run.number, completed_run.app_name
                ));
                Err(Error::RunFailed)
            }
            tower_api::models::run::Status::Crashed => {
                output::error(&format!(
                    "Run #{} for app '{}' crashed",
                    completed_run.number, completed_run.app_name
                ));
                Err(Error::RunCrashed)
            }
            tower_api::models::run::Status::Cancelled => {
                output::error(&format!(
                    "Run #{} for app '{}' was cancelled",
                    completed_run.number, completed_run.app_name
                ));
                Err(Error::RunCancelled)
            }
            _ => {
                output::success(&format!(
                    "Run #{} for app '{}' completed successfully",
                    completed_run.number, completed_run.app_name
                ));
                Ok(())
            }
        },
        Err(err) => {
            output::error(&format!("Failed to monitor run completion: {:?}", err));
            Err(err.into())
        }
    }
}

/// Extracts the local/remote flag, Towerfile directory, parameters, and optional app name
/// from the parsed CLI args.
fn get_run_parameters(
    args: &ArgMatches,
) -> Result<(bool, PathBuf, HashMap<String, String>, Option<String>), crate::Error> {
    let local = *args.get_one::<bool>("local").unwrap();
    let path = resolve_path(args);
    let params = parse_parameters(args);
    let app_name = args.get_one::<String>("app_name").cloned();

    Ok((local, path, params, app_name))
}

fn should_follow_run(args: &ArgMatches) -> bool {
    let local = *args.get_one::<bool>("detached").unwrap();
    !local
}

/// Parses `--parameter` arguments into a HashMap of key-value pairs.
/// Handles format like "--parameter key=value"
fn parse_parameters(args: &ArgMatches) -> HashMap<String, String> {
    let mut param_map = HashMap::new();

    if let Some(parameters) = args.get_many::<String>("parameters") {
        for param in parameters {
            match param.split_once('=') {
                Some((key, value)) => {
                    if key.is_empty() {
                        output::error(&format!(
                            "Invalid parameter format: '{}'. Key cannot be empty.",
                            param
                        ));
                        continue;
                    }
                    param_map.insert(key.to_string(), value.to_string());
                }
                None => {
                    output::error(&format!(
                        "Invalid parameter format: '{}'. Expected 'key=value'.",
                        param
                    ));
                }
            }
        }
    }

    param_map
}

/// Resolves the path based on the `cmd` option.
fn resolve_path(args: &ArgMatches) -> PathBuf {
    if let Some(dir) = args.get_one::<String>("dir") {
        PathBuf::from(dir)
    } else {
        PathBuf::from(".")
    }
}

/// get_secrets_inner manages the process of getting secrets from the Tower server in a way that can be
/// used by the local runtime during local app execution. Returns API errors for spinner handling.
async fn get_secrets(
    config: &Config,
    env: &str,
) -> Result<
    HashMap<String, String>,
    tower_api::apis::Error<tower_api::apis::default_api::ExportSecretsError>,
> {
    let (private_key, public_key) = crypto::generate_key_pair();

    let res = api::export_secrets(&config, env, false, public_key).await?;
    let mut secrets = HashMap::new();

    for secret in res.secrets {
        // we will decrypt each property and inject it into the vals map.
        let decrypted_value =
            crypto::decrypt(private_key.clone(), secret.encrypted_value.to_string()).map_err(
                |_| {
                    tower_api::apis::Error::Io(std::io::Error::new(
                        std::io::ErrorKind::Other,
                        "Failed to decrypt secret",
                    ))
                },
            )?;
        secrets.insert(secret.name, decrypted_value);
    }

    Ok(secrets)
}

/// get_catalogs_inner manages the process of exporting catalogs, decrypting their properties, and
/// preparting them for injection into the environment during app execution. Returns plain Error for direct use.
async fn get_catalogs(
    config: &Config,
    env: &str,
) -> Result<
    HashMap<String, String>,
    tower_api::apis::Error<tower_api::apis::default_api::ExportCatalogsError>,
> {
    let (private_key, public_key) = crypto::generate_key_pair();

    let res = api::export_catalogs(&config, env, false, public_key)
        .await
        .map_err(|_| {
            tower_api::apis::Error::Io(std::io::Error::new(
                std::io::ErrorKind::Other,
                "Failed to export catalogs",
            ))
        })?;
    let mut vals = HashMap::new();

    for catalog in res.catalogs {
        // Decrypt each property and inject it into the vals map. The API returns
        // the correct environment_variable name for each property (including S3
        // Tables remapping, static constants, and derived URI).
        for property in catalog.properties {
            let decrypted_value =
                crypto::decrypt(private_key.clone(), property.encrypted_value.to_string())
                    .map_err(|_| {
                        tower_api::apis::Error::Io(std::io::Error::new(
                            std::io::ErrorKind::Other,
                            "Failed to decrypt catalog property",
                        ))
                    })?;
            let name = property
                .environment_variable
                .filter(|s| !s.is_empty())
                .unwrap_or_else(|| {
                    create_pyiceberg_catalog_property_name(&catalog.name, &property.name)
                });
            vals.insert(name, decrypted_value);
        }
    }

    Ok(vals)
}

/// load_towerfile manages the process of loading a Towerfile from a given path in an interactive
/// way. That means it will not return if the Towerfile can't be loaded and instead will publish an
/// error.
fn load_towerfile(path: &PathBuf) -> Result<Towerfile, Error> {
    Towerfile::from_path(path.clone()).map_err(|source| {
        debug!(
            "Failed to load Towerfile from path `{:?}`: {}",
            path, source
        );
        Error::TowerfileLoadFailed {
            path: path.display().to_string(),
            source,
        }
    })
}

/// build_package manages the process of building a package in an interactive way for local app
/// execution. If the pacakge fails to build for wahatever reason, the app will exit.
async fn build_package(towerfile: &Towerfile) -> Result<Package, Error> {
    let mut spinner = output::spinner("Building package...");
    let package_spec = PackageSpec::from_towerfile(towerfile);
    match Package::build(package_spec).await {
        Ok(package) => {
            spinner.success();
            Ok(package)
        }
        Err(err) => {
            spinner.failure();
            debug!("Failed to build package: {}", err);
            Err(err.into())
        }
    }
}

/// monitor_output is a helper function that will monitor the output of a given output channel and
/// plops it down on stdout.
async fn monitor_output(mut output: OutputReceiver) {
    loop {
        if let Some(line) = output.recv().await {
            let ts = dates::format(line.time);
            output::log_line(&ts, &line.line, output::LogLineType::Local);
        } else {
            break;
        }
    }
}

/// monitor_local_status is a helper function that will monitor the status of a given app and waits for
/// it to progress to a terminal state.
async fn monitor_cli_status(
    handle: Arc<Mutex<tower_runtime::subprocess::SubprocessHandle>>,
) -> Status {
    use tower_runtime::execution::ExecutionHandle as _;

    debug!("Starting status monitoring for CLI execution");
    let mut check_count = 0;
    let mut err_count = 0;

    loop {
        check_count += 1;

        debug!(
            "Status check #{}, attempting to get CLI handle status",
            check_count
        );

        match handle.lock().await.status().await {
            Ok(status) => {
                // We reset the error count to indicate that we can intermittently get statuses.
                err_count = 0;

                match status {
                    Status::Exited => {
                        debug!("Run exited cleanly, stopping status monitoring");
                        return status;
                    }
                    Status::Crashed { .. } => {
                        debug!("Run crashed, stopping status monitoring");
                        return status;
                    }
                    Status::Failed { .. } => {
                        debug!("Run failed at platform layer, stopping status monitoring");
                        return status;
                    }
                    _ => {
                        debug!("Handle status: other, continuing to monitor");
                        sleep(Duration::from_millis(100)).await;
                    }
                }
            }
            Err(e) => {
                debug!("Failed to get handle status: {:?}", e);
                err_count += 1;

                // If we get five errors in a row, we abandon monitoring.
                if err_count >= 5 {
                    debug!("Failed to get handle status after 5 attempts, giving up");
                    output::error("An error occured while monitoring your local run status!");
                    return Status::Crashed { code: -1 };
                }

                // Otherwise, keep on keepin' on.
                sleep(Duration::from_millis(100)).await;
            }
        }
    }
}

fn create_pyiceberg_catalog_property_name(catalog_name: &str, property_name: &str) -> String {
    let catalog_name = catalog_name
        .replace('-', "_")
        .replace('.', "_")
        .replace(':', "_")
        .to_uppercase();
    let property_name = property_name
        .replace('-', "_")
        .replace('.', "_")
        .replace(':', "_")
        .to_uppercase();

    format!("PYICEBERG_CATALOG__{}__{}", catalog_name, property_name)
}

const RUN_START_TIMEOUT: Duration = Duration::from_secs(30);

/// wait_for_run_start waits for the run to enter a "running" state. It polls the API every 500ms to see
/// if it's started yet.
async fn wait_for_run_start(config: &Config, run: &Run) -> Result<(), Error> {
    timeout(RUN_START_TIMEOUT, async {
        loop {
            let res = api::describe_run(config, &run.app_name, run.number).await?;

            if is_run_started(&res.run)? {
                return Ok(());
            }

            sleep(Duration::from_millis(500)).await;
        }
    })
    .await
    .map_err(|_| Error::RunStartTimeout)?
}

/// wait_for_run_completion waits for the run to enter an terminal state. It polls the API every
/// 500ms to see if it's started yet.
async fn wait_for_run_completion(config: &Config, run: &Run) -> Result<Run, Error> {
    loop {
        let res = api::describe_run(config, &run.app_name, run.number).await?;

        if is_run_finished(&res.run) {
            return Ok(res.run);
        } else {
            // Wait half a second to to try again.
            sleep(Duration::from_millis(500)).await;
        }
    }
}

/// is_run_started checks if the run has started by looking at its status.
fn is_run_started(run: &Run) -> Result<bool, Error> {
    match run.status {
        tower_api::models::run::Status::Scheduled => Ok(false),
        tower_api::models::run::Status::Pending => Ok(false),
        tower_api::models::run::Status::Running => Ok(true),
        _ => Err(Error::RunCompleted),
    }
}

/// is_run_finished checks if the run has finished by looking at its status.
fn is_run_finished(run: &Run) -> bool {
    match run.status {
        tower_api::models::run::Status::Scheduled => false,
        tower_api::models::run::Status::Pending => false,
        tower_api::models::run::Status::Running => false,
        _ => true,
    }
}

fn monitor_run_completion(config: &Config, run: &Run) -> oneshot::Receiver<Run> {
    // we'll use this as a way of monitoring for when the run has reached a terminal state.
    let (tx, rx) = oneshot::channel();

    // We need to spawn a task that will wait for run completion, and we need copies of these
    // objects in order for them to run elsewhere.
    let config_clone = config.clone();
    let run_clone = run.clone();

    tokio::spawn(async move {
        match wait_for_run_completion(&config_clone, &run_clone).await {
            Ok(run) => {
                let _ = tx.send(run);
            }
            Err(err) => {
                debug!("Failed to monitor run completion: {:?}", err);
                // Channel will be dropped, causing RecvError on the receiver side
            }
        }
    });

    rx
}

#[cfg(test)]
mod tests {
    use super::run_cmd;

    fn parse(args: &[&str]) -> Result<clap::ArgMatches, clap::Error> {
        let mut full = vec!["run"];
        full.extend_from_slice(args);
        run_cmd().try_get_matches_from(full)
    }

    #[test]
    fn app_name_parsed_as_positional_arg() {
        let m = parse(&["my-app"]).unwrap();
        assert_eq!(m.get_one::<String>("app_name").map(|s| s.as_str()), Some("my-app"));
    }

    #[test]
    fn no_app_name_is_fine() {
        let m = parse(&[]).unwrap();
        assert_eq!(m.get_one::<String>("app_name"), None);
    }

    #[test]
    fn unknown_flags_are_rejected() {
        let err = parse(&["--param", "x=y"]).unwrap_err();
        let msg = err.to_string();
        assert!(msg.contains("--param"), "should mention the bad flag: {msg}");
        assert!(msg.contains("--parameter"), "should suggest the correct flag: {msg}");
    }

    #[test]
    fn help_flag_is_not_swallowed_as_app_name() {
        let err = parse(&["--help"]).unwrap_err();
        assert_eq!(err.kind(), clap::error::ErrorKind::DisplayHelp);
    }

    #[test]
    fn help_after_app_name_still_shows_help() {
        let err = parse(&["my-app", "--help"]).unwrap_err();
        assert_eq!(err.kind(), clap::error::ErrorKind::DisplayHelp);
    }

    #[test]
    fn parameters_after_app_name() {
        let m = parse(&["my-app", "-p", "key=val"]).unwrap();
        assert_eq!(m.get_one::<String>("app_name").map(|s| s.as_str()), Some("my-app"));
        let params: Vec<&String> = m.get_many::<String>("parameters").unwrap().collect();
        assert_eq!(params, vec!["key=val"]);
    }

    #[test]
    fn parameters_before_app_name() {
        let m = parse(&["-p", "key=val", "my-app"]).unwrap();
        assert_eq!(m.get_one::<String>("app_name").map(|s| s.as_str()), Some("my-app"));
        let params: Vec<&String> = m.get_many::<String>("parameters").unwrap().collect();
        assert_eq!(params, vec!["key=val"]);
    }
}
