from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.session import Session


T = TypeVar("T", bound="DeleteSessionResponse")


@_attrs_define
class DeleteSessionResponse:
    """
    Attributes:
        session (Session):
        schema (str | Unset): A URL to the JSON Schema for this object. Example:
            https://api.tower.dev/v1/schemas/DeleteSessionResponse.json.
    """

    session: Session
    schema: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        session = self.session.to_dict()

        schema = self.schema

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "session": session,
            }
        )
        if schema is not UNSET:
            field_dict["$schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.session import Session

        d = dict(src_dict)
        session = Session.from_dict(d.pop("session"))

        schema = d.pop("$schema", UNSET)

        delete_session_response = cls(
            session=session,
            schema=schema,
        )

        return delete_session_response
