from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.catalog_property import CatalogProperty


T = TypeVar("T", bound="Catalog")


@_attrs_define
class Catalog:
    """
    Attributes:
        created_at (datetime.datetime):
        environment (str):
        name (str):
        properties (list[CatalogProperty]):
        type_ (str):
        slug (str | Unset): This property is deprecated. Use name instead.
    """

    created_at: datetime.datetime
    environment: str
    name: str
    properties: list[CatalogProperty]
    type_: str
    slug: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        created_at = self.created_at.isoformat()

        environment = self.environment

        name = self.name

        properties = []
        for properties_item_data in self.properties:
            properties_item = properties_item_data.to_dict()
            properties.append(properties_item)

        type_ = self.type_

        slug = self.slug

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "CreatedAt": created_at,
                "environment": environment,
                "name": name,
                "properties": properties,
                "type": type_,
            }
        )
        if slug is not UNSET:
            field_dict["slug"] = slug

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.catalog_property import CatalogProperty

        d = dict(src_dict)
        created_at = isoparse(d.pop("CreatedAt"))

        environment = d.pop("environment")

        name = d.pop("name")

        properties = []
        _properties = d.pop("properties")
        for properties_item_data in _properties:
            properties_item = CatalogProperty.from_dict(properties_item_data)

            properties.append(properties_item)

        type_ = d.pop("type")

        slug = d.pop("slug", UNSET)

        catalog = cls(
            created_at=created_at,
            environment=environment,
            name=name,
            properties=properties,
            type_=type_,
            slug=slug,
        )

        return catalog
