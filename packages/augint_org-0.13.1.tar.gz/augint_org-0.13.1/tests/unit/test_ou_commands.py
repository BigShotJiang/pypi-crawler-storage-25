"""Unit tests for OU commands."""

from unittest.mock import MagicMock, patch

import pytest

from ai_org.cli import cli


@pytest.mark.unit
class TestOUListCommand:
    """Test ou list command."""

    def test_list_tree_default(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_tree.return_value = {
                    "Id": "r-root",
                    "Name": "Root",
                    "Type": "ROOT",
                    "Children": [
                        {
                            "Id": "ou-workloads",
                            "Name": "Workloads",
                            "Type": "ORGANIZATIONAL_UNIT",
                            "Children": [],
                        }
                    ],
                }
                mock_mgr.format_ou_tree.return_value = "Root (r-root)\n  Workloads (ou-workloads)"

                result = runner.invoke(cli, ["ou", "list"])

                assert result.exit_code == 0
                mock_mgr.get_ou_tree.assert_called_once()
                mock_mgr.format_ou_tree.assert_called_once()

    def test_list_flat(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_ous.return_value = [
                    {
                        "Id": "r-root",
                        "Name": "Root",
                        "Path": "Root",
                        "Type": "ROOT",
                    },
                    {
                        "Id": "ou-workloads",
                        "Name": "Workloads",
                        "Path": "Root/Workloads",
                        "Type": "ORGANIZATIONAL_UNIT",
                    },
                ]

                result = runner.invoke(cli, ["ou", "list", "--flat"])

                assert result.exit_code == 0
                mock_mgr.list_ous.assert_called_once()

    def test_list_tree_json(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_tree.return_value = {
                    "Id": "r-root",
                    "Name": "Root",
                    "Type": "ROOT",
                    "Children": [],
                }

                result = runner.invoke(cli, ["--json", "ou", "list"])

                assert result.exit_code == 0

    def test_list_flat_json(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_ous.return_value = [
                    {
                        "Id": "ou-workloads",
                        "Name": "Workloads",
                        "Path": "Root/Workloads",
                        "Type": "ORGANIZATIONAL_UNIT",
                    },
                ]

                result = runner.invoke(cli, ["--json", "ou", "list", "--flat"])

                assert result.exit_code == 0

    def test_list_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_tree.side_effect = Exception("API Error")

                result = runner.invoke(cli, ["ou", "list"])

                assert result.exit_code != 0


@pytest.mark.unit
class TestOUGetCommand:
    """Test ou get command."""

    def test_get_ou_details(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_details.return_value = {
                    "Id": "ou-workloads",
                    "Name": "Workloads",
                    "Arn": "arn:aws:organizations::123:ou/o-org/ou-workloads",
                    "Accounts": [
                        {
                            "Id": "111111111111",
                            "Name": "Account1",
                            "Email": "a@example.com",
                            "Status": "ACTIVE",
                        }
                    ],
                    "ChildOUs": [],
                    "AccountCount": 1,
                    "ChildOUCount": 0,
                }

                result = runner.invoke(cli, ["ou", "get", "ou-workloads"])

                assert result.exit_code == 0
                mock_mgr.get_ou_details.assert_called_once_with("ou-workloads")

    def test_get_ou_with_children(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_details.return_value = {
                    "Id": "ou-parent",
                    "Name": "Parent",
                    "Arn": "arn:aws:organizations::123:ou/o-org/ou-parent",
                    "Accounts": [],
                    "ChildOUs": [
                        {"Id": "ou-child1", "Name": "Child1"},
                        {"Id": "ou-child2", "Name": "Child2"},
                    ],
                    "AccountCount": 0,
                    "ChildOUCount": 2,
                }

                result = runner.invoke(cli, ["ou", "get", "ou-parent"])

                assert result.exit_code == 0

    def test_get_ou_json(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_details.return_value = {
                    "Id": "ou-workloads",
                    "Name": "Workloads",
                    "Arn": "arn:test",
                    "Accounts": [],
                    "ChildOUs": [],
                    "AccountCount": 0,
                    "ChildOUCount": 0,
                }

                result = runner.invoke(cli, ["--json", "ou", "get", "ou-workloads"])

                assert result.exit_code == 0

    def test_get_ou_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_details.side_effect = Exception("OU not found")

                result = runner.invoke(cli, ["ou", "get", "ou-missing"])

                assert result.exit_code != 0

    def test_get_missing_argument(self, runner):
        result = runner.invoke(cli, ["ou", "get"])
        assert result.exit_code != 0


@pytest.mark.unit
class TestOUFindCommand:
    """Test ou find command."""

    def test_find_ou_success(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_by_name.return_value = "ou-workloads-123"

                result = runner.invoke(cli, ["ou", "find", "Workloads"])

                assert result.exit_code == 0
                mock_mgr.get_ou_by_name.assert_called_once_with("Workloads")

    def test_find_ou_not_found(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_by_name.return_value = None
                mock_mgr.list_ous.return_value = [
                    {
                        "Id": "ou-workloads",
                        "Name": "Workloads",
                        "Path": "Root/Workloads",
                        "Type": "ORGANIZATIONAL_UNIT",
                    },
                ]

                result = runner.invoke(cli, ["ou", "find", "Work"])

                assert result.exit_code == 0
                # Should suggest similar OUs

    def test_find_ou_not_found_no_suggestions(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_by_name.return_value = None
                mock_mgr.list_ous.return_value = [
                    {
                        "Id": "ou-security",
                        "Name": "Security",
                        "Path": "Root/Security",
                        "Type": "ORGANIZATIONAL_UNIT",
                    },
                ]

                result = runner.invoke(cli, ["ou", "find", "XYZ"])

                assert result.exit_code == 0

    def test_find_ou_json(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_by_name.return_value = "ou-workloads-123"

                result = runner.invoke(cli, ["--json", "ou", "find", "Workloads"])

                assert result.exit_code == 0

    def test_find_ou_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.ou.OUManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_ou_by_name.side_effect = Exception("API Error")

                result = runner.invoke(cli, ["ou", "find", "Workloads"])

                assert result.exit_code != 0

    def test_find_missing_argument(self, runner):
        result = runner.invoke(cli, ["ou", "find"])
        assert result.exit_code != 0


@pytest.mark.unit
class TestOUCommandHelp:
    """Test ou command help pages."""

    def test_ou_help(self, runner):
        result = runner.invoke(cli, ["ou", "--help"])
        assert result.exit_code == 0
        assert "Organizational Units" in result.output

    def test_ou_list_help(self, runner):
        result = runner.invoke(cli, ["ou", "list", "--help"])
        assert result.exit_code == 0
        assert "--tree" in result.output
        assert "--flat" in result.output

    def test_ou_get_help(self, runner):
        result = runner.invoke(cli, ["ou", "get", "--help"])
        assert result.exit_code == 0
        assert "OU-ID" in result.output

    def test_ou_find_help(self, runner):
        result = runner.invoke(cli, ["ou", "find", "--help"])
        assert result.exit_code == 0
        assert "NAME" in result.output
