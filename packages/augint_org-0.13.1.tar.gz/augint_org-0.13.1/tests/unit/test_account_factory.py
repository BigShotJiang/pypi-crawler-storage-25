"""Unit tests for the AccountFactory class."""

from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError


def _make_factory():
    """Create an AccountFactory with mocked dependencies."""
    with patch("ai_org.core.account_factory.AWSClient") as mock_aws:
        mock_aws_instance = MagicMock()
        mock_aws.return_value = mock_aws_instance

        mock_sc = MagicMock()
        mock_org = MagicMock()

        def client_factory(service, **kwargs):
            if service == "servicecatalog":
                return mock_sc
            if service == "organizations":
                return mock_org
            return MagicMock()

        mock_aws_instance.client = client_factory

        from ai_org.core.account_factory import AccountFactory

        factory = AccountFactory()
        factory.service_catalog = mock_sc
        factory.org_client = mock_org
        return factory, mock_sc, mock_org


@pytest.mark.unit
class TestAccountFactoryInit:
    """Test AccountFactory initialization."""

    def test_init_creates_clients(self):
        with patch("ai_org.core.account_factory.AWSClient") as mock_aws:
            mock_instance = MagicMock()
            mock_aws.return_value = mock_instance

            from ai_org.core.account_factory import AccountFactory

            factory = AccountFactory(profile="test", region="us-west-2")

            mock_aws.assert_called_once_with("test", "us-west-2")
            assert mock_instance.client.call_count == 2
            mock_instance.client.assert_any_call("servicecatalog")
            mock_instance.client.assert_any_call("organizations")
            assert factory._product_id is None
            assert factory._artifact_id is None


@pytest.mark.unit
class TestFindAccountFactoryProduct:
    """Test find_account_factory_product method."""

    def test_finds_product_with_active_artifact(self):
        factory, mock_sc, _ = _make_factory()

        mock_sc.search_products.return_value = {
            "ProductViewSummaries": [
                {"ProductId": "prod-12345", "Name": "AWS Control Tower Account Factory"}
            ]
        }
        mock_sc.list_provisioning_artifacts.return_value = {
            "ProvisioningArtifactDetails": [
                {"Id": "pa-inactive", "Active": False},
                {"Id": "pa-active", "Active": True},
            ]
        }

        product_id, artifact_id = factory.find_account_factory_product()

        assert product_id == "prod-12345"
        assert artifact_id == "pa-active"

    def test_uses_latest_artifact_when_no_active(self):
        factory, mock_sc, _ = _make_factory()

        mock_sc.search_products.return_value = {
            "ProductViewSummaries": [
                {"ProductId": "prod-12345", "Name": "AWS Control Tower Account Factory"}
            ]
        }
        mock_sc.list_provisioning_artifacts.return_value = {
            "ProvisioningArtifactDetails": [
                {"Id": "pa-latest", "Active": False},
            ]
        }

        product_id, artifact_id = factory.find_account_factory_product()

        assert product_id == "prod-12345"
        assert artifact_id == "pa-latest"

    def test_caches_product_ids(self):
        factory, mock_sc, _ = _make_factory()
        factory._product_id = "prod-cached"
        factory._artifact_id = "pa-cached"

        product_id, artifact_id = factory.find_account_factory_product()

        assert product_id == "prod-cached"
        assert artifact_id == "pa-cached"
        mock_sc.search_products.assert_not_called()

    def test_product_not_found(self):
        factory, mock_sc, _ = _make_factory()
        mock_sc.search_products.return_value = {"ProductViewSummaries": []}

        with pytest.raises(Exception, match="Control Tower Account Factory product not found"):
            factory.find_account_factory_product()

    def test_product_name_mismatch(self):
        factory, mock_sc, _ = _make_factory()
        mock_sc.search_products.return_value = {
            "ProductViewSummaries": [{"ProductId": "prod-wrong", "Name": "Some Other Product"}]
        }

        with pytest.raises(Exception, match="Control Tower Account Factory product not found"):
            factory.find_account_factory_product()

    def test_client_error(self):
        factory, mock_sc, _ = _make_factory()
        factory.aws = MagicMock()
        factory.aws.handle_error.return_value = "Service Catalog error"
        mock_sc.search_products.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "SearchProducts",
        )

        with pytest.raises(Exception, match="Failed to find Account Factory"):
            factory.find_account_factory_product()


@pytest.mark.unit
class TestProvisionAccount:
    """Test provision_account method."""

    def test_provision_with_wait(self):
        factory, mock_sc, _ = _make_factory()

        # Mock find_account_factory_product
        factory._product_id = "prod-123"
        factory._artifact_id = "pa-123"

        mock_sc.provision_product.return_value = {"RecordDetail": {"RecordId": "rec-123"}}

        # Mock _wait_for_provisioning
        mock_sc.describe_record.return_value = {
            "RecordDetail": {
                "Status": "SUCCEEDED",
                "ProvisionedProductName": "account-test",
                "RecordOutputs": [{"OutputKey": "AccountId", "OutputValue": "987654321098"}],
            }
        }

        result = factory.provision_account(
            name="test-account",
            email="test@example.com",
            ou_name="Workloads",
            sso_email="admin@example.com",
            sso_first_name="Admin",
            sso_last_name="User",
            wait=True,
        )

        assert result == "987654321098"
        mock_sc.provision_product.assert_called_once()

    def test_provision_without_wait(self):
        factory, mock_sc, _ = _make_factory()
        factory._product_id = "prod-123"
        factory._artifact_id = "pa-123"

        mock_sc.provision_product.return_value = {"RecordDetail": {"RecordId": "rec-456"}}

        result = factory.provision_account(
            name="test-account",
            email="test@example.com",
            ou_name="Workloads",
            sso_email="admin@example.com",
            sso_first_name="Admin",
            sso_last_name="User",
            wait=False,
        )

        assert result == "provisioning-rec-456"

    def test_provision_invalid_ou_error(self):
        factory, mock_sc, _ = _make_factory()
        factory._product_id = "prod-123"
        factory._artifact_id = "pa-123"
        factory.aws = MagicMock()
        factory.aws.handle_error.return_value = "Account Factory error"

        mock_sc.provision_product.side_effect = ClientError(
            {
                "Error": {
                    "Code": "InvalidParametersException",
                    "Message": "ManagedOrganizationalUnit invalid",
                }
            },
            "ProvisionProduct",
        )

        with pytest.raises(Exception, match="Invalid OU name"):
            factory.provision_account(
                name="test",
                email="test@example.com",
                ou_name="BadOU",
                sso_email="admin@example.com",
                sso_first_name="Admin",
                sso_last_name="User",
            )

    def test_provision_invalid_email_error(self):
        factory, mock_sc, _ = _make_factory()
        factory._product_id = "prod-123"
        factory._artifact_id = "pa-123"
        factory.aws = MagicMock()
        factory.aws.handle_error.return_value = "Account Factory error"

        mock_sc.provision_product.side_effect = ClientError(
            {
                "Error": {
                    "Code": "InvalidParametersException",
                    "Message": "Email already in use",
                }
            },
            "ProvisionProduct",
        )

        with pytest.raises(Exception, match="Invalid email format"):
            factory.provision_account(
                name="test",
                email="bad@example.com",
                ou_name="Workloads",
                sso_email="admin@example.com",
                sso_first_name="Admin",
                sso_last_name="User",
            )

    def test_provision_generic_client_error(self):
        factory, mock_sc, _ = _make_factory()
        factory._product_id = "prod-123"
        factory._artifact_id = "pa-123"
        factory.aws = MagicMock()
        factory.aws.handle_error.return_value = "Unknown error"

        mock_sc.provision_product.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "Something failed"}},
            "ProvisionProduct",
        )

        with pytest.raises(Exception, match="Failed to provision account"):
            factory.provision_account(
                name="test",
                email="test@example.com",
                ou_name="Workloads",
                sso_email="admin@example.com",
                sso_first_name="Admin",
                sso_last_name="User",
            )


@pytest.mark.unit
class TestWaitForProvisioning:
    """Test _wait_for_provisioning method."""

    def test_success_with_output(self):
        factory, mock_sc, _ = _make_factory()
        mock_sc.describe_record.return_value = {
            "RecordDetail": {
                "Status": "SUCCEEDED",
                "ProvisionedProductName": "account-test",
                "RecordOutputs": [{"OutputKey": "AccountId", "OutputValue": "111222333444"}],
            }
        }

        result = factory._wait_for_provisioning("rec-123")
        assert result == "111222333444"

    def test_success_without_output_finds_by_name(self):
        factory, mock_sc, mock_org = _make_factory()
        mock_sc.describe_record.return_value = {
            "RecordDetail": {
                "Status": "SUCCEEDED",
                "ProvisionedProductName": "account-myaccount",
                "RecordOutputs": [],
            }
        }
        mock_org.list_accounts.return_value = {
            "Accounts": [
                {"Name": "myaccount", "Id": "555666777888"},
            ]
        }

        result = factory._wait_for_provisioning("rec-123")
        assert result == "555666777888"

    def test_failure(self):
        factory, mock_sc, _ = _make_factory()
        mock_sc.describe_record.return_value = {
            "RecordDetail": {
                "Status": "FAILED",
                "RecordErrors": [{"Description": "Limit exceeded"}],
            }
        }

        with pytest.raises(Exception, match="Account provisioning failed: Limit exceeded"):
            factory._wait_for_provisioning("rec-123")

    def test_terminated(self):
        factory, mock_sc, _ = _make_factory()
        mock_sc.describe_record.return_value = {
            "RecordDetail": {
                "Status": "TERMINATED",
                "RecordErrors": [{"Description": "Terminated by user"}],
            }
        }

        with pytest.raises(Exception, match="Account provisioning failed"):
            factory._wait_for_provisioning("rec-123")

    def test_timeout(self):
        factory, mock_sc, _ = _make_factory()
        mock_sc.describe_record.return_value = {
            "RecordDetail": {
                "Status": "IN_PROGRESS",
            }
        }

        with patch("ai_org.core.account_factory.time") as mock_time:
            mock_time.time.side_effect = [0, 0, 99999]
            mock_time.sleep = MagicMock()

            with pytest.raises(Exception, match="Account provisioning timed out"):
                factory._wait_for_provisioning("rec-123", timeout=5)

    def test_retries_on_invalid_params_error(self):
        factory, mock_sc, _ = _make_factory()
        factory.aws = MagicMock()
        factory.aws.handle_error.return_value = "Status check error"

        # First call raises InvalidParametersException, second succeeds
        mock_sc.describe_record.side_effect = [
            ClientError(
                {
                    "Error": {
                        "Code": "InvalidParametersException",
                        "Message": "transient",
                    }
                },
                "DescribeRecord",
            ),
            {
                "RecordDetail": {
                    "Status": "SUCCEEDED",
                    "RecordOutputs": [{"OutputKey": "AccountId", "OutputValue": "123456789012"}],
                }
            },
        ]

        with patch("ai_org.core.account_factory.time") as mock_time:
            mock_time.time.side_effect = [0, 0, 1, 1]
            mock_time.sleep = MagicMock()

            result = factory._wait_for_provisioning("rec-123", timeout=60)
            assert result == "123456789012"


@pytest.mark.unit
class TestFindAccountByName:
    """Test _find_account_by_name method."""

    def test_find_account_success(self):
        factory, _, mock_org = _make_factory()
        mock_org.list_accounts.return_value = {
            "Accounts": [
                {"Name": "test-account", "Id": "111222333444"},
                {"Name": "other-account", "Id": "555666777888"},
            ]
        }

        result = factory._find_account_by_name("test-account")
        assert result == "111222333444"

    def test_find_account_strips_prefix(self):
        factory, _, mock_org = _make_factory()
        mock_org.list_accounts.return_value = {
            "Accounts": [
                {"Name": "myaccount", "Id": "111222333444"},
            ]
        }

        result = factory._find_account_by_name("account-myaccount")
        assert result == "111222333444"

    def test_find_account_not_found(self):
        factory, _, mock_org = _make_factory()
        mock_org.list_accounts.return_value = {
            "Accounts": [
                {"Name": "other-account", "Id": "555666777888"},
            ]
        }

        with pytest.raises(Exception, match="Account not found: missing"):
            factory._find_account_by_name("missing")

    def test_find_account_client_error(self):
        factory, _, mock_org = _make_factory()
        factory.aws = MagicMock()
        factory.aws.handle_error.return_value = "Organizations error"
        mock_org.list_accounts.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListAccounts",
        )

        with pytest.raises(Exception, match="Failed to find account"):
            factory._find_account_by_name("test")


@pytest.mark.unit
class TestGetEnrollmentStatus:
    """Test get_enrollment_status method."""

    def test_enrolled_account(self):
        factory, _, mock_org = _make_factory()
        mock_org.describe_account.return_value = {
            "Account": {
                "Id": "123456789012",
                "Name": "test-account",
                "Email": "test@example.com",
                "Status": "ACTIVE",
            }
        }
        mock_org.list_parents.return_value = {
            "Parents": [{"Id": "ou-workloads", "Type": "ORGANIZATIONAL_UNIT"}]
        }

        # Mock CloudFormation client for enrollment check
        mock_cf = MagicMock()
        mock_cf.list_stacks.return_value = {
            "StackSummaries": [
                {"StackName": "AWSControlTowerBP-BASELINE-CONFIG"},
                {"StackName": "AWSControlTowerBP-BASELINE-CLOUDTRAIL"},
            ]
        }

        factory.aws = MagicMock()
        factory.aws.client.return_value = mock_cf

        result = factory.get_enrollment_status("123456789012")

        assert result["account_id"] == "123456789012"
        assert result["enrolled"] is True
        assert result["enrollment_status"] == "Enrolled"
        assert result["control_tower_stacks"] == 2

    def test_not_enrolled_account(self):
        factory, _, mock_org = _make_factory()
        mock_org.describe_account.return_value = {
            "Account": {
                "Id": "123456789012",
                "Name": "test-account",
                "Email": "test@example.com",
                "Status": "ACTIVE",
            }
        }
        mock_org.list_parents.return_value = {
            "Parents": [{"Id": "ou-sandbox", "Type": "ORGANIZATIONAL_UNIT"}]
        }

        mock_cf = MagicMock()
        mock_cf.list_stacks.return_value = {
            "StackSummaries": [
                {"StackName": "some-other-stack"},
            ]
        }

        factory.aws = MagicMock()
        factory.aws.client.return_value = mock_cf

        result = factory.get_enrollment_status("123456789012")

        assert result["enrolled"] is False
        assert result["enrollment_status"] == "Not enrolled"

    def test_client_error_returns_error_dict(self):
        factory, _, mock_org = _make_factory()
        factory.aws = MagicMock()
        factory.aws.handle_error.return_value = "Account not found"
        mock_org.describe_account.side_effect = ClientError(
            {"Error": {"Code": "AccountNotFoundException", "Message": "not found"}},
            "DescribeAccount",
        )

        result = factory.get_enrollment_status("999999999999")

        assert result["account_id"] == "999999999999"
        assert "error" in result

    def test_cf_access_failure_leaves_unknown(self):
        factory, _, mock_org = _make_factory()
        mock_org.describe_account.return_value = {
            "Account": {
                "Id": "123456789012",
                "Name": "test-account",
                "Email": "test@example.com",
                "Status": "ACTIVE",
            }
        }
        mock_org.list_parents.return_value = {
            "Parents": [{"Id": "ou-workloads", "Type": "ORGANIZATIONAL_UNIT"}]
        }

        factory.aws = MagicMock()
        factory.aws.client.side_effect = Exception("Cannot assume role")

        result = factory.get_enrollment_status("123456789012")

        assert result["enrollment_status"] == "Unknown"
        assert result["enrolled"] is False
