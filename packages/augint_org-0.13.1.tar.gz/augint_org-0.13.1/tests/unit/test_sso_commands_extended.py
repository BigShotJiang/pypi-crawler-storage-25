"""Extended unit tests for SSO commands."""

from unittest.mock import MagicMock, patch

import pytest

from ai_org.cli import cli


@pytest.mark.unit
class TestSSOAssignCommand:
    """Test sso assign command in detail."""

    def test_assign_success_with_principal(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager") as mock_cfg_cls,
            ):
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.assign_permission.return_value = {
                    "account_id": "123456789012",
                    "principal": "user@example.com",
                    "permission_set": "AWSAdministratorAccess",
                    "status": "assigned",
                }

                result = runner.invoke(
                    cli,
                    [
                        "sso",
                        "assign",
                        "123456789012",
                        "--principal",
                        "user@example.com",
                    ],
                )

                assert result.exit_code == 0
                mock_mgr.assign_permission.assert_called_once_with(
                    account_id="123456789012",
                    principal="user@example.com",
                    permission_set="AWSAdministratorAccess",
                    principal_type=None,
                )

    def test_assign_uses_config_default_principal(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager") as mock_cfg_cls,
            ):
                mock_cfg = MagicMock()
                mock_cfg_cls.return_value = mock_cfg
                mock_cfg.get_default_sso_user.return_value = "default@example.com"

                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.assign_permission.return_value = {
                    "status": "assigned",
                }

                result = runner.invoke(cli, ["sso", "assign", "123456789012"])

                assert result.exit_code == 0
                mock_mgr.assign_permission.assert_called_once_with(
                    account_id="123456789012",
                    principal="default@example.com",
                    permission_set="AWSAdministratorAccess",
                    principal_type=None,
                )

    def test_assign_no_principal_no_config_fails(self, runner):
        with (
            patch("ai_org.core.aws_client.boto3.Session"),
            patch("ai_org.commands.sso.SSOManager"),
            patch("ai_org.commands.sso.ConfigManager") as mock_cfg_cls,
        ):
            mock_cfg = MagicMock()
            mock_cfg_cls.return_value = mock_cfg
            mock_cfg.get_default_sso_user.return_value = None

            result = runner.invoke(cli, ["sso", "assign", "123456789012"])

            assert result.exit_code != 0
            assert "No principal specified" in result.output

    def test_assign_with_custom_permission_set(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager"),
            ):
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.assign_permission.return_value = {"status": "assigned"}

                result = runner.invoke(
                    cli,
                    [
                        "sso",
                        "assign",
                        "123456789012",
                        "--principal",
                        "user@example.com",
                        "--permission-set",
                        "AWSReadOnlyAccess",
                    ],
                )

                assert result.exit_code == 0
                mock_mgr.assign_permission.assert_called_once_with(
                    account_id="123456789012",
                    principal="user@example.com",
                    permission_set="AWSReadOnlyAccess",
                    principal_type=None,
                )

    def test_assign_with_principal_type(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager"),
            ):
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.assign_permission.return_value = {"status": "assigned"}

                result = runner.invoke(
                    cli,
                    [
                        "sso",
                        "assign",
                        "123456789012",
                        "--principal",
                        "Developers",
                        "--principal-type",
                        "GROUP",
                    ],
                )

                assert result.exit_code == 0
                mock_mgr.assign_permission.assert_called_once_with(
                    account_id="123456789012",
                    principal="Developers",
                    permission_set="AWSAdministratorAccess",
                    principal_type="GROUP",
                )

    def test_assign_json_output(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager"),
            ):
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.assign_permission.return_value = {
                    "account_id": "123456789012",
                    "status": "assigned",
                }

                result = runner.invoke(
                    cli,
                    [
                        "--json",
                        "sso",
                        "assign",
                        "123456789012",
                        "--principal",
                        "user@example.com",
                    ],
                )

                assert result.exit_code == 0

    def test_assign_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager"),
            ):
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.assign_permission.side_effect = Exception("Permission denied")

                result = runner.invoke(
                    cli,
                    [
                        "sso",
                        "assign",
                        "123456789012",
                        "--principal",
                        "user@example.com",
                    ],
                )

                assert result.exit_code != 0


@pytest.mark.unit
class TestSSOListCommand:
    """Test sso list command in detail."""

    def test_list_with_assignments(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_assignments.return_value = [
                    {
                        "PrincipalType": "USER",
                        "PrincipalId": "user-123",
                        "PermissionSet": "AWSAdministratorAccess",
                        "Status": "ACTIVE",
                    }
                ]

                result = runner.invoke(cli, ["sso", "list", "123456789012"])

                assert result.exit_code == 0
                mock_mgr.list_assignments.assert_called_once_with("123456789012")

    def test_list_empty_assignments(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_assignments.return_value = []

                result = runner.invoke(cli, ["sso", "list", "123456789012"])

                assert result.exit_code == 0

    def test_list_json_output(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_assignments.return_value = [
                    {"PrincipalType": "USER", "PrincipalId": "u-1"}
                ]

                result = runner.invoke(cli, ["--json", "sso", "list", "123456789012"])

                assert result.exit_code == 0

    def test_list_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_assignments.side_effect = Exception("API Error")

                result = runner.invoke(cli, ["sso", "list", "123456789012"])

                assert result.exit_code != 0


@pytest.mark.unit
class TestSSOSyncCommand:
    """Test sso sync command."""

    def test_sync_with_principal(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager"),
            ):
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.sync_ou_assignments.return_value = [
                    {"account_id": "111", "status": "success", "message": "OK"},
                    {"account_id": "222", "status": "success", "message": "OK"},
                ]

                result = runner.invoke(cli, ["sso", "sync", "--principal", "admin@example.com"])

                assert result.exit_code == 0

    def test_sync_uses_config_principal(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager") as mock_cfg_cls,
            ):
                mock_cfg = MagicMock()
                mock_cfg_cls.return_value = mock_cfg
                mock_cfg.get_default_sso_user.return_value = "default@example.com"

                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.sync_ou_assignments.return_value = []

                result = runner.invoke(cli, ["sso", "sync"])

                assert result.exit_code == 0
                mock_mgr.sync_ou_assignments.assert_called_once()

    def test_sync_no_principal_fails(self, runner):
        with (
            patch("ai_org.core.aws_client.boto3.Session"),
            patch("ai_org.commands.sso.SSOManager"),
            patch("ai_org.commands.sso.ConfigManager") as mock_cfg_cls,
        ):
            mock_cfg = MagicMock()
            mock_cfg_cls.return_value = mock_cfg
            mock_cfg.get_default_sso_user.return_value = None

            result = runner.invoke(cli, ["sso", "sync"])

            assert result.exit_code != 0
            assert "No principal specified" in result.output

    def test_sync_with_ou(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager"),
            ):
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.sync_ou_assignments.return_value = []

                result = runner.invoke(
                    cli,
                    [
                        "sso",
                        "sync",
                        "--principal",
                        "admin@example.com",
                        "--ou",
                        "ou-workloads",
                    ],
                )

                assert result.exit_code == 0
                mock_mgr.sync_ou_assignments.assert_called_once_with(
                    principal="admin@example.com",
                    permission_set="AWSAdministratorAccess",
                    ou_id="ou-workloads",
                )

    def test_sync_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.sso.SSOManager") as mock_mgr_cls,
                patch("ai_org.commands.sso.ConfigManager"),
            ):
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.sync_ou_assignments.side_effect = Exception("Sync failed")

                result = runner.invoke(
                    cli,
                    ["sso", "sync", "--principal", "admin@example.com"],
                )

                assert result.exit_code != 0
