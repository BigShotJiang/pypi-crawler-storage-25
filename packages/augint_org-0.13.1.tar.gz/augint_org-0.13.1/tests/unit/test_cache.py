"""Unit tests for caching utilities."""

import time

import pytest

from ai_org.utils.cache import CacheManager


@pytest.mark.unit
class TestCacheManagerInit:
    def test_init_with_custom_dir(self, tmp_path):
        cache_dir = tmp_path / "cache"
        manager = CacheManager(cache_dir=cache_dir, ttl=600)
        assert manager.cache_dir == cache_dir
        assert manager.ttl == 600
        assert cache_dir.exists()

    def test_init_default_ttl(self, tmp_path):
        manager = CacheManager(cache_dir=tmp_path / "cache")
        assert manager.ttl == 3600


@pytest.mark.unit
class TestCacheGetSet:
    def test_set_and_get(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        cache.set("test", "key1", {"data": "value"})

        result = cache.get("test", "key1")
        assert result == {"data": "value"}

    def test_get_nonexistent(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        result = cache.get("test", "missing")
        assert result is None

    def test_get_expired(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache", ttl=0)
        cache.set("test", "key1", {"data": "value"})

        # Force expiry by waiting a tiny bit

        time.sleep(0.01)

        result = cache.get("test", "key1")
        assert result is None

    def test_set_overwrites(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        cache.set("test", "key1", "value1")
        cache.set("test", "key1", "value2")

        result = cache.get("test", "key1")
        assert result == "value2"

    def test_different_namespaces(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        cache.set("ns1", "key", "value1")
        cache.set("ns2", "key", "value2")

        assert cache.get("ns1", "key") == "value1"
        assert cache.get("ns2", "key") == "value2"


@pytest.mark.unit
class TestCacheClear:
    def test_clear_namespace(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        cache.set("ns1", "key1", "value1")
        cache.set("ns1", "key2", "value2")
        cache.set("ns2", "key1", "value3")

        cache.clear("ns1")

        assert cache.get("ns1", "key1") is None
        assert cache.get("ns1", "key2") is None
        assert cache.get("ns2", "key1") == "value3"

    def test_clear_all(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        cache.set("ns1", "key1", "value1")
        cache.set("ns2", "key1", "value2")

        cache.clear()

        assert cache.get("ns1", "key1") is None
        assert cache.get("ns2", "key1") is None


@pytest.mark.unit
class TestCacheGetOrCompute:
    def test_computes_when_missing(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        computed = cache.get_or_compute("test", "key1", lambda: "computed_value")
        assert computed == "computed_value"

    def test_returns_cached_when_present(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        cache.set("test", "key1", "cached_value")

        call_count = 0

        def expensive_fn():
            nonlocal call_count
            call_count += 1
            return "new_value"

        result = cache.get_or_compute("test", "key1", expensive_fn)
        assert result == "cached_value"
        assert call_count == 0

    def test_caches_computed_value(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        cache.get_or_compute("test", "key1", lambda: "computed")

        # Second call should use cache
        result = cache.get("test", "key1")
        assert result == "computed"


@pytest.mark.unit
class TestCacheKey:
    def test_deterministic(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        key1 = cache._get_cache_key("ns", "key")
        key2 = cache._get_cache_key("ns", "key")
        assert key1 == key2

    def test_different_for_different_inputs(self, tmp_path):
        cache = CacheManager(cache_dir=tmp_path / "cache")
        key1 = cache._get_cache_key("ns1", "key")
        key2 = cache._get_cache_key("ns2", "key")
        assert key1 != key2
