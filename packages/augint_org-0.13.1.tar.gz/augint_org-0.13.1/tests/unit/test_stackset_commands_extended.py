"""Extended unit tests for StackSet commands."""

from unittest.mock import MagicMock, patch

import pytest

from ai_org.cli import cli


@pytest.mark.unit
class TestStackSetStatusCommand:
    """Test stackset status command in detail."""

    def test_status_success(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_deployment_status.return_value = [
                    {
                        "StackSetName": "org-pipeline-bootstrap",
                        "Status": "CURRENT",
                        "StatusReason": "",
                    }
                ]

                result = runner.invoke(cli, ["stackset", "status", "123456789012"])

                assert result.exit_code == 0
                mock_mgr.get_deployment_status.assert_called_once()

    def test_status_with_specific_stackset(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_deployment_status.return_value = [
                    {
                        "StackSetName": "org-pipeline-bootstrap",
                        "Status": "CURRENT",
                        "StatusReason": "",
                    }
                ]

                result = runner.invoke(
                    cli,
                    [
                        "stackset",
                        "status",
                        "123456789012",
                        "--stackset",
                        "org-pipeline-bootstrap",
                    ],
                )

                assert result.exit_code == 0

    def test_status_with_wait_success(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.wait_for_deployments.return_value = True
                mock_mgr.get_deployment_status.return_value = [
                    {
                        "StackSetName": "ss1",
                        "Status": "CURRENT",
                        "StatusReason": "",
                    }
                ]

                result = runner.invoke(cli, ["stackset", "status", "123456789012", "--wait"])

                assert result.exit_code == 0
                mock_mgr.wait_for_deployments.assert_called_once()

    def test_status_with_wait_failure(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.wait_for_deployments.return_value = False
                mock_mgr.get_deployment_status.return_value = [
                    {
                        "StackSetName": "ss1",
                        "Status": "FAILED",
                        "StatusReason": "Error",
                    }
                ]

                result = runner.invoke(cli, ["stackset", "status", "123456789012", "--wait"])

                assert result.exit_code == 0

    def test_status_empty(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_deployment_status.return_value = []

                result = runner.invoke(cli, ["stackset", "status", "123456789012"])

                assert result.exit_code == 0

    def test_status_json_output(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_deployment_status.return_value = [
                    {"StackSetName": "ss1", "Status": "CURRENT"}
                ]

                result = runner.invoke(cli, ["--json", "stackset", "status", "123456789012"])

                assert result.exit_code == 0

    def test_status_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_deployment_status.side_effect = Exception("API Error")

                result = runner.invoke(cli, ["stackset", "status", "123456789012"])

                assert result.exit_code != 0


@pytest.mark.unit
class TestStackSetListCommand:
    """Test stackset list command in detail."""

    def test_list_success(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_stacksets.return_value = [
                    {
                        "StackSetName": "org-pipeline-bootstrap",
                        "Status": "ACTIVE",
                        "AutoDeployOUs": "Workloads, Sandbox",
                        "Instances": "3 accounts",
                    },
                    {
                        "StackSetName": "org-github-oidc",
                        "Status": "ACTIVE",
                        "AutoDeployOUs": "-",
                        "Instances": "1 account",
                    },
                ]

                result = runner.invoke(cli, ["stackset", "list"])

                assert result.exit_code == 0
                mock_mgr.list_stacksets.assert_called_once()

    def test_list_empty(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_stacksets.return_value = []

                result = runner.invoke(cli, ["stackset", "list"])

                assert result.exit_code == 0

    def test_list_json_output(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_stacksets.return_value = [{"StackSetName": "ss1", "Status": "ACTIVE"}]

                result = runner.invoke(cli, ["--json", "stackset", "list"])

                assert result.exit_code == 0

    def test_list_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.list_stacksets.side_effect = Exception("API Error")

                result = runner.invoke(cli, ["stackset", "list"])

                assert result.exit_code != 0


@pytest.mark.unit
class TestStackSetDeployCommand:
    """Test stackset deploy command."""

    def test_deploy_with_yes_flag(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_stackset_parameters.return_value = []
                mock_mgr.deploy_to_account.return_value = "op-123"
                mock_mgr.wait_for_deployment_operation.return_value = True
                mock_mgr.get_deployment_status.return_value = [
                    {
                        "StackSetName": "custom-stackset",
                        "Status": "CURRENT",
                        "StatusReason": "",
                    }
                ]

                result = runner.invoke(
                    cli,
                    [
                        "stackset",
                        "deploy",
                        "123456789012",
                        "--stackset",
                        "custom-stackset",
                        "--yes",
                    ],
                )

                assert result.exit_code == 0
                mock_mgr.deploy_to_account.assert_called_once()

    def test_deploy_with_params(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_stackset_parameters.return_value = []
                mock_mgr.deploy_to_account.return_value = "op-456"
                mock_mgr.wait_for_deployment_operation.return_value = True
                mock_mgr.get_deployment_status.return_value = [
                    {
                        "StackSetName": "ss1",
                        "Status": "CURRENT",
                        "StatusReason": "",
                    }
                ]

                result = runner.invoke(
                    cli,
                    [
                        "stackset",
                        "deploy",
                        "123456789012",
                        "--stackset",
                        "custom-stackset",
                        "--param",
                        "Env=prod",
                        "--param",
                        "Region=us-east-1",
                        "--yes",
                    ],
                )

                assert result.exit_code == 0
                call_kwargs = mock_mgr.deploy_to_account.call_args[1]
                assert call_kwargs["parameters"]["Env"] == "prod"
                assert call_kwargs["parameters"]["Region"] == "us-east-1"

    def test_deploy_with_regions(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_stackset_parameters.return_value = []
                mock_mgr.deploy_to_account.return_value = "op-789"
                mock_mgr.wait_for_deployment_operation.return_value = True
                mock_mgr.get_deployment_status.return_value = []

                result = runner.invoke(
                    cli,
                    [
                        "stackset",
                        "deploy",
                        "123456789012",
                        "--stackset",
                        "custom-stackset",
                        "--regions",
                        "us-west-2",
                        "--yes",
                    ],
                )

                assert result.exit_code == 0
                call_kwargs = mock_mgr.deploy_to_account.call_args[1]
                assert call_kwargs["regions"] == ["us-west-2"]

    def test_deploy_failure(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_stackset_parameters.return_value = []
                mock_mgr.deploy_to_account.return_value = "op-fail"
                mock_mgr.wait_for_deployment_operation.return_value = False
                mock_mgr.get_deployment_status.return_value = [
                    {
                        "StackSetName": "ss1",
                        "Status": "FAILED",
                        "StatusReason": "Error",
                    }
                ]

                result = runner.invoke(
                    cli,
                    [
                        "stackset",
                        "deploy",
                        "123456789012",
                        "--stackset",
                        "custom-stackset",
                        "--yes",
                    ],
                )

                assert result.exit_code == 0

    def test_deploy_invalid_param_format(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_stackset_parameters.return_value = []

                result = runner.invoke(
                    cli,
                    [
                        "stackset",
                        "deploy",
                        "123456789012",
                        "--stackset",
                        "custom-stackset",
                        "--param",
                        "bad-format",
                        "--yes",
                    ],
                )

                assert result.exit_code != 0

    def test_deploy_missing_stackset_flag(self, runner):
        result = runner.invoke(cli, ["stackset", "deploy", "123456789012"])
        assert result.exit_code != 0

    def test_deploy_acm_default_region(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_stackset_parameters.return_value = []
                mock_mgr.deploy_to_account.return_value = "op-acm"
                mock_mgr.wait_for_deployment_operation.return_value = True
                mock_mgr.get_deployment_status.return_value = []

                result = runner.invoke(
                    cli,
                    [
                        "stackset",
                        "deploy",
                        "123456789012",
                        "--stackset",
                        "org-acm-certificates",
                        "--yes",
                    ],
                )

                assert result.exit_code == 0
                call_kwargs = mock_mgr.deploy_to_account.call_args[1]
                assert call_kwargs["regions"] == ["us-east-1"]

    def test_deploy_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.get_stackset_parameters.return_value = []
                mock_mgr.deploy_to_account.side_effect = Exception("Deploy failed")

                result = runner.invoke(
                    cli,
                    [
                        "stackset",
                        "deploy",
                        "123456789012",
                        "--stackset",
                        "custom-stackset",
                        "--yes",
                    ],
                )

                assert result.exit_code != 0


@pytest.mark.unit
class TestStackSetDescribeCommand:
    """Test stackset describe command."""

    def test_describe_success(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr

                mock_mgr.cfn_client.describe_stack_set.return_value = {
                    "StackSet": {
                        "StackSetName": "org-test",
                        "Description": "Test StackSet",
                        "Status": "ACTIVE",
                        "PermissionModel": "SERVICE_MANAGED",
                        "AutoDeployment": {"Enabled": False},
                    }
                }
                mock_mgr.get_stackset_parameters.return_value = []
                mock_mgr._count_stack_instances.return_value = 0
                mock_mgr.get_stackset_operations.return_value = []

                result = runner.invoke(cli, ["stackset", "describe", "org-test"])

                assert result.exit_code == 0

    def test_describe_not_found(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr
                mock_mgr.cfn_client.describe_stack_set.side_effect = Exception(
                    "StackSetNotFoundException: not found"
                )

                result = runner.invoke(cli, ["stackset", "describe", "nonexistent"])

                # Should handle the not-found gracefully
                assert result.exit_code == 0

    def test_describe_missing_argument(self, runner):
        result = runner.invoke(cli, ["stackset", "describe"])
        assert result.exit_code != 0

    def test_describe_with_auto_deploy(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.stackset.StackSetManager") as mock_mgr_cls:
                mock_mgr = MagicMock()
                mock_mgr_cls.return_value = mock_mgr

                mock_mgr.cfn_client.describe_stack_set.return_value = {
                    "StackSet": {
                        "StackSetName": "org-test",
                        "Status": "ACTIVE",
                        "PermissionModel": "SERVICE_MANAGED",
                        "AutoDeployment": {
                            "Enabled": True,
                            "RetainStacksOnAccountRemoval": False,
                        },
                    }
                }
                mock_mgr.cfn_client.list_stack_set_auto_deployment_targets.return_value = {
                    "Summaries": [{"OrganizationalUnitId": "ou-xxxx-workloads"}]
                }
                mock_mgr.get_stackset_parameters.return_value = [
                    {
                        "name": "Env",
                        "type": "String",
                        "default": "prod",
                        "description": "Environment",
                        "current_value": "prod",
                        "allowed_values": None,
                    }
                ]
                mock_mgr._count_stack_instances.return_value = 2

                # Mock paginator for instances
                mock_paginator = MagicMock()
                mock_mgr.cfn_client.get_paginator.return_value = mock_paginator
                mock_paginator.paginate.return_value = iter(
                    [
                        {
                            "Summaries": [
                                {
                                    "Account": "111",
                                    "Region": "us-east-1",
                                    "Status": "CURRENT",
                                },
                            ]
                        }
                    ]
                )

                mock_mgr.get_stackset_operations.return_value = [
                    {
                        "Action": "CREATE",
                        "Status": "SUCCEEDED",
                        "CreationTime": "2024-01-01",
                    }
                ]

                result = runner.invoke(cli, ["stackset", "describe", "org-test"])

                assert result.exit_code == 0
