"""Unit tests for config loader utility."""

import os
from pathlib import Path
from unittest.mock import patch

import pytest

from ai_org.utils.config_loader import create_example_user_config, load_config_value


@pytest.mark.unit
class TestLoadConfigValue:
    def test_env_var_takes_precedence(self):
        with patch.dict(os.environ, {"MY_KEY": "from_env"}):
            result = load_config_value("MY_KEY", default="fallback")
            assert result == "from_env"

    def test_returns_default_when_not_found(self):
        with patch.dict(os.environ, {}, clear=False):
            # Ensure the key is not in the environment
            os.environ.pop("NONEXISTENT_KEY_12345", None)
            result = load_config_value("NONEXISTENT_KEY_12345", default="my_default")
            assert result == "my_default"

    def test_returns_none_when_no_default(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("NONEXISTENT_KEY_12345", None)
            with patch("ai_org.utils.config_loader.Path.home") as mock_home:
                mock_home.return_value = Path("/nonexistent")
                result = load_config_value("NONEXISTENT_KEY_12345")
                assert result is None

    def test_reads_from_user_config_file(self, tmp_path):
        config_dir = tmp_path / ".aillc"
        config_dir.mkdir()
        config_file = config_dir / ".env.aillc-org"
        config_file.write_text("MY_CONFIG_KEY=from_file\n")

        with (
            patch.dict(os.environ, {}, clear=False),
            patch("ai_org.utils.config_loader.Path.home", return_value=tmp_path),
        ):
            os.environ.pop("MY_CONFIG_KEY", None)
            result = load_config_value("MY_CONFIG_KEY")
            assert result == "from_file"

    def test_env_overrides_file(self, tmp_path):
        config_dir = tmp_path / ".aillc"
        config_dir.mkdir()
        config_file = config_dir / ".env.aillc-org"
        config_file.write_text("MY_KEY=from_file\n")

        with (
            patch.dict(os.environ, {"MY_KEY": "from_env"}),
            patch("ai_org.utils.config_loader.Path.home", return_value=tmp_path),
        ):
            result = load_config_value("MY_KEY")
            assert result == "from_env"


@pytest.mark.unit
class TestCreateExampleUserConfig:
    def test_creates_example_file(self, tmp_path):
        with patch("ai_org.utils.config_loader.Path.home", return_value=tmp_path):
            create_example_user_config()

            example_path = tmp_path / ".aillc" / ".env.aillc-org.example"
            assert example_path.exists()
            content = example_path.read_text()
            assert "GH_ACCOUNT" in content

    def test_does_not_overwrite_existing(self, tmp_path):
        config_dir = tmp_path / ".aillc"
        config_dir.mkdir()
        example_path = config_dir / ".env.aillc-org.example"
        example_path.write_text("existing content")

        with patch("ai_org.utils.config_loader.Path.home", return_value=tmp_path):
            create_example_user_config()

            assert example_path.read_text() == "existing content"
