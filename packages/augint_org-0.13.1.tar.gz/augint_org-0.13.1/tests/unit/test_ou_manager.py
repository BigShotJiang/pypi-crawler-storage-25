"""Unit tests for the OUManager class."""

from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError


def _make_manager():
    """Create an OUManager with mocked dependencies."""
    with patch("ai_org.core.ou_manager.AWSClient") as mock_aws:
        mock_aws_instance = MagicMock()
        mock_aws.return_value = mock_aws_instance

        mock_org = MagicMock()
        mock_aws_instance.client.return_value = mock_org

        from ai_org.core.ou_manager import OUManager

        manager = OUManager()
        manager.org_client = mock_org
        return manager, mock_org


@pytest.mark.unit
class TestOUManagerInit:
    def test_init(self):
        with patch("ai_org.core.ou_manager.AWSClient") as mock_aws:
            mock_instance = MagicMock()
            mock_aws.return_value = mock_instance

            from ai_org.core.ou_manager import OUManager

            manager = OUManager(profile="test", region="eu-west-1")
            mock_aws.assert_called_once_with("test", "eu-west-1")
            mock_instance.client.assert_called_once_with("organizations")


@pytest.mark.unit
class TestGetOUTree:
    def test_get_tree(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": [{"Id": "r-root", "Name": "Root"}]}
        mock_org.list_organizational_units_for_parent.side_effect = [
            {
                "OrganizationalUnits": [
                    {"Id": "ou-workloads", "Name": "Workloads"},
                    {"Id": "ou-sandbox", "Name": "Sandbox"},
                ]
            },
            {"OrganizationalUnits": []},  # Children of Workloads
            {"OrganizationalUnits": []},  # Children of Sandbox
        ]

        result = manager.get_ou_tree()

        assert result["Id"] == "r-root"
        assert result["Name"] == "Root"
        assert result["Type"] == "ROOT"
        assert len(result["Children"]) == 2
        assert result["Children"][0]["Name"] == "Workloads"

    def test_get_tree_no_root(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": []}

        with pytest.raises(Exception, match="No root found"):
            manager.get_ou_tree()

    def test_get_tree_client_error(self):
        manager, mock_org = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Tree error"
        mock_org.list_roots.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListRoots",
        )

        with pytest.raises(Exception, match="Tree error"):
            manager.get_ou_tree()


@pytest.mark.unit
class TestListOUs:
    def test_list_flattened(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": [{"Id": "r-root", "Name": "Root"}]}
        mock_org.list_organizational_units_for_parent.side_effect = [
            {
                "OrganizationalUnits": [
                    {"Id": "ou-sec", "Name": "Security"},
                ]
            },
            {"OrganizationalUnits": []},
        ]

        result = manager.list_ous()

        assert len(result) == 2  # Root + Security
        assert result[0]["Name"] == "Root"
        assert result[0]["Type"] == "ROOT"
        assert result[1]["Name"] == "Security"
        assert result[1]["Path"] == "Root/Security"


@pytest.mark.unit
class TestGetOUDetails:
    def test_get_details(self):
        manager, mock_org = _make_manager()
        mock_org.describe_organizational_unit.return_value = {
            "OrganizationalUnit": {
                "Id": "ou-work",
                "Name": "Workloads",
                "Arn": "arn:aws:organizations::123:ou/o-org/ou-work",
            }
        }
        mock_org.list_accounts_for_parent.return_value = {
            "Accounts": [{"Id": "111", "Name": "Acct1", "Email": "a@b.com", "Status": "ACTIVE"}]
        }
        mock_org.list_organizational_units_for_parent.return_value = {
            "OrganizationalUnits": [{"Id": "ou-child", "Name": "Child"}]
        }

        result = manager.get_ou_details("ou-work")

        assert result["Id"] == "ou-work"
        assert result["Name"] == "Workloads"
        assert result["AccountCount"] == 1
        assert result["ChildOUCount"] == 1

    def test_get_details_client_error(self):
        manager, mock_org = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "OU not found"
        mock_org.describe_organizational_unit.side_effect = ClientError(
            {"Error": {"Code": "OrganizationalUnitNotFoundException", "Message": "not found"}},
            "DescribeOU",
        )

        with pytest.raises(Exception, match="OU not found"):
            manager.get_ou_details("ou-missing")


@pytest.mark.unit
class TestGetOUByName:
    def test_find_by_name(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": [{"Id": "r-root", "Name": "Root"}]}
        mock_org.list_organizational_units_for_parent.side_effect = [
            {
                "OrganizationalUnits": [
                    {"Id": "ou-work", "Name": "Workloads"},
                ]
            },
            {"OrganizationalUnits": []},
        ]

        result = manager.get_ou_by_name("Workloads")
        assert result == "ou-work"

    def test_find_case_insensitive(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": [{"Id": "r-root", "Name": "Root"}]}
        mock_org.list_organizational_units_for_parent.side_effect = [
            {
                "OrganizationalUnits": [
                    {"Id": "ou-work", "Name": "Workloads"},
                ]
            },
            {"OrganizationalUnits": []},
        ]

        result = manager.get_ou_by_name("workloads")
        assert result == "ou-work"

    def test_not_found_returns_none(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": [{"Id": "r-root", "Name": "Root"}]}
        mock_org.list_organizational_units_for_parent.return_value = {"OrganizationalUnits": []}

        result = manager.get_ou_by_name("Nonexistent")
        assert result is None

    def test_error_returns_none(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.side_effect = Exception("fail")

        result = manager.get_ou_by_name("Workloads")
        assert result is None


@pytest.mark.unit
class TestFormatOUTree:
    def test_format_tree(self):
        manager, _ = _make_manager()
        tree = {
            "Id": "r-root",
            "Name": "Root",
            "Type": "ROOT",
            "Children": [
                {
                    "Id": "ou-work",
                    "Name": "Workloads",
                    "Type": "ORGANIZATIONAL_UNIT",
                    "Children": [],
                }
            ],
        }

        result = manager.format_ou_tree(tree)
        assert "Root" in result
        assert "Workloads" in result

    def test_format_empty_tree(self):
        manager, _ = _make_manager()
        tree = {
            "Id": "r-root",
            "Name": "Root",
            "Type": "ROOT",
            "Children": [],
        }

        result = manager.format_ou_tree(tree)
        assert "Root" in result
