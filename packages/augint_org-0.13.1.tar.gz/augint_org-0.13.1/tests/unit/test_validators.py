"""Unit tests for input validation utilities."""

import pytest

from ai_org.utils.validators import (
    parse_principal_type,
    sanitize_account_name,
    validate_account_id,
    validate_account_name,
    validate_email,
    validate_ou_id,
    validate_permission_set_name,
    validate_region,
    validate_stackset_name,
)


@pytest.mark.unit
class TestValidateEmail:
    def test_valid_emails(self):
        assert validate_email("user@example.com") is True
        assert validate_email("admin@company.co.uk") is True
        assert validate_email("test.user+tag@domain.org") is True

    def test_invalid_emails(self):
        assert validate_email("") is False
        assert validate_email("notanemail") is False
        assert validate_email("@domain.com") is False
        assert validate_email("user@") is False
        assert validate_email("user@domain") is False


@pytest.mark.unit
class TestValidateAccountId:
    def test_valid_ids(self):
        assert validate_account_id("123456789012") is True
        assert validate_account_id("000000000000") is True

    def test_invalid_ids(self):
        assert validate_account_id("") is False
        assert validate_account_id("12345") is False
        assert validate_account_id("1234567890123") is False
        assert validate_account_id("abcdefghijkl") is False
        assert validate_account_id("12345678901a") is False


@pytest.mark.unit
class TestValidateOuId:
    def test_valid_ou_ids(self):
        assert validate_ou_id("ou-abcd-12345678") is True
        assert validate_ou_id("r-abcd") is True

    def test_invalid_ou_ids(self):
        assert validate_ou_id("") is False
        assert validate_ou_id("ou-123") is False
        assert validate_ou_id("invalid") is False
        assert validate_ou_id("ou-ABCD-12345678") is False


@pytest.mark.unit
class TestValidateAccountName:
    def test_valid_names(self):
        assert validate_account_name("my-account") is True
        assert validate_account_name("Test Account 123") is True
        assert validate_account_name("prod_env") is True

    def test_invalid_names(self):
        assert validate_account_name("") is False
        assert validate_account_name("a" * 51) is False
        assert validate_account_name("invalid@name!") is False


@pytest.mark.unit
class TestValidateRegion:
    def test_valid_regions(self):
        assert validate_region("us-east-1") is True
        assert validate_region("eu-west-2") is True
        assert validate_region("ap-southeast-1") is True

    def test_invalid_regions(self):
        assert validate_region("") is False
        assert validate_region("invalid") is False
        assert validate_region("US-EAST-1") is False


@pytest.mark.unit
class TestValidateStacksetName:
    def test_valid_names(self):
        assert validate_stackset_name("org-pipeline-bootstrap") is True
        assert validate_stackset_name("MyStackSet") is True

    def test_invalid_names(self):
        assert validate_stackset_name("") is False
        assert validate_stackset_name("a" * 129) is False
        assert validate_stackset_name("1-starts-with-number") is False
        assert validate_stackset_name("-starts-with-hyphen") is False


@pytest.mark.unit
class TestValidatePermissionSetName:
    def test_valid_names(self):
        assert validate_permission_set_name("AWSAdministratorAccess") is True
        assert validate_permission_set_name("ReadOnly") is True
        assert validate_permission_set_name("custom-set_1") is True

    def test_invalid_names(self):
        assert validate_permission_set_name("") is False
        assert validate_permission_set_name("a" * 33) is False
        assert validate_permission_set_name("invalid name!") is False


@pytest.mark.unit
class TestSanitizeAccountName:
    def test_sanitize_basic(self):
        assert sanitize_account_name("my-account") == "my-account"

    def test_sanitize_special_chars(self):
        assert sanitize_account_name("my@account!here") == "my-account-here"

    def test_sanitize_multiple_spaces(self):
        assert sanitize_account_name("my   account") == "my-account"

    def test_sanitize_leading_trailing(self):
        assert sanitize_account_name("-my-account-") == "my-account"

    def test_sanitize_truncate(self):
        long_name = "a" * 60
        assert len(sanitize_account_name(long_name)) == 50


@pytest.mark.unit
class TestParsePrincipalType:
    def test_email_returns_user(self):
        assert parse_principal_type("user@example.com") == "USER"

    def test_group_name_returns_group(self):
        assert parse_principal_type("Developers") == "GROUP"
        assert parse_principal_type("admin-team") == "GROUP"
