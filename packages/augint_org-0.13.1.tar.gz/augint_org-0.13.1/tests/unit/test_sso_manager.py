"""Unit tests for the SSOManager class."""

from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError


@pytest.mark.unit
class TestSSOManagerInit:
    """Test SSOManager initialization."""

    def test_init_creates_clients(self):
        with (
            patch("ai_org.core.sso_manager.AWSClient") as mock_aws,
            patch("ai_org.core.sso_manager.ConfigManager"),
        ):
            mock_aws_instance = MagicMock()
            mock_aws.return_value = mock_aws_instance

            from ai_org.core.sso_manager import SSOManager

            manager = SSOManager(profile="test", region="us-east-1")

            mock_aws.assert_called_once_with("test", "us-east-1")
            assert mock_aws_instance.client.call_count == 2
            mock_aws_instance.client.assert_any_call("sso-admin")
            mock_aws_instance.client.assert_any_call("identitystore")
            assert manager._sso_instance_arn is None
            assert manager._identity_store_id is None


@pytest.mark.unit
class TestDiscoverSSOInstance:
    """Test SSO instance discovery."""

    def _make_manager(self):
        """Create an SSOManager with mocked dependencies."""
        with (
            patch("ai_org.core.sso_manager.AWSClient") as mock_aws,
            patch("ai_org.core.sso_manager.ConfigManager"),
        ):
            mock_aws_instance = MagicMock()
            mock_aws.return_value = mock_aws_instance

            mock_sso = MagicMock()
            mock_identity = MagicMock()

            def client_factory(service, **kwargs):
                if service == "sso-admin":
                    return mock_sso
                if service == "identitystore":
                    return mock_identity
                return MagicMock()

            mock_aws_instance.client = client_factory

            from ai_org.core.sso_manager import SSOManager

            manager = SSOManager()
            manager.sso_client = mock_sso
            manager.identity_client = mock_identity
            return manager, mock_sso, mock_identity

    def test_discover_sso_instance_success(self):
        manager, mock_sso, _ = self._make_manager()
        mock_sso.list_instances.return_value = {
            "Instances": [
                {
                    "InstanceArn": "arn:aws:sso:::instance/ins-12345",
                    "IdentityStoreId": "d-9876543210",
                }
            ]
        }

        arn = manager.sso_instance_arn
        store_id = manager.identity_store_id

        assert arn == "arn:aws:sso:::instance/ins-12345"
        assert store_id == "d-9876543210"

    def test_discover_sso_instance_no_instances(self):
        manager, mock_sso, _ = self._make_manager()
        mock_sso.list_instances.return_value = {"Instances": []}

        with pytest.raises(Exception, match="No SSO instance found"):
            _ = manager.sso_instance_arn

    def test_discover_sso_instance_client_error(self):
        manager, mock_sso, _ = self._make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Access denied"
        mock_sso.list_instances.side_effect = ClientError(
            {"Error": {"Code": "AccessDeniedException", "Message": "Access denied"}},
            "ListInstances",
        )

        with pytest.raises(Exception, match="Access denied"):
            _ = manager.sso_instance_arn

    def test_sso_instance_arn_cached(self):
        manager, mock_sso, _ = self._make_manager()
        manager._sso_instance_arn = "arn:cached"
        manager._identity_store_id = "d-cached"

        assert manager.sso_instance_arn == "arn:cached"
        mock_sso.list_instances.assert_not_called()

    def test_identity_store_id_cached(self):
        manager, mock_sso, _ = self._make_manager()
        manager._sso_instance_arn = "arn:cached"
        manager._identity_store_id = "d-cached"

        assert manager.identity_store_id == "d-cached"
        mock_sso.list_instances.assert_not_called()


def _make_sso_manager():
    """Create an SSOManager with all dependencies mocked."""
    with (
        patch("ai_org.core.sso_manager.AWSClient") as mock_aws,
        patch("ai_org.core.sso_manager.ConfigManager"),
    ):
        mock_aws_instance = MagicMock()
        mock_aws.return_value = mock_aws_instance

        mock_sso = MagicMock()
        mock_identity = MagicMock()

        def client_factory(service, **kwargs):
            if service == "sso-admin":
                return mock_sso
            if service == "identitystore":
                return mock_identity
            return MagicMock()

        mock_aws_instance.client = client_factory

        from ai_org.core.sso_manager import SSOManager

        manager = SSOManager()
        manager.sso_client = mock_sso
        manager.identity_client = mock_identity
        manager._sso_instance_arn = "arn:aws:sso:::instance/ins-12345"
        manager._identity_store_id = "d-9876543210"
        return manager, mock_sso, mock_identity


@pytest.mark.unit
class TestGetPrincipalId:
    """Test _get_principal_id method."""

    def test_get_user_by_username(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_users.return_value = {
            "Users": [{"UserId": "user-abc123", "UserName": "jdoe"}]
        }

        result = manager._get_principal_id("jdoe", "USER")
        assert result == "user-abc123"

    def test_get_user_by_email_fallback(self):
        manager, _, mock_identity = _make_sso_manager()
        # Username search returns nothing
        mock_identity.list_users.return_value = {"Users": []}

        # Paginated email search
        mock_paginator = MagicMock()
        mock_identity.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {"Users": [{"UserId": "user-found", "UserName": "john"}]}
        ]
        mock_identity.describe_user.return_value = {
            "Emails": [{"Value": "john@example.com", "Primary": True}]
        }

        result = manager._get_principal_id("john@example.com", "USER")
        assert result == "user-found"

    def test_get_user_not_found(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_users.return_value = {"Users": []}

        with pytest.raises(Exception, match="User testuser not found"):
            manager._get_principal_id("testuser", "USER")

    def test_get_user_by_email_not_found(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_users.return_value = {"Users": []}
        mock_paginator = MagicMock()
        mock_identity.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {"Users": [{"UserId": "user-other", "UserName": "other"}]}
        ]
        mock_identity.describe_user.return_value = {
            "Emails": [{"Value": "other@example.com", "Primary": True}]
        }

        with pytest.raises(Exception, match=r"User missing@example\.com not found"):
            manager._get_principal_id("missing@example.com", "USER")

    def test_get_group_by_name(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_groups.return_value = {
            "Groups": [{"GroupId": "group-abc123", "DisplayName": "Developers"}]
        }

        result = manager._get_principal_id("Developers", "GROUP")
        assert result == "group-abc123"

    def test_get_group_not_found(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_groups.return_value = {"Groups": []}

        with pytest.raises(Exception, match="Group Admins not found"):
            manager._get_principal_id("Admins", "GROUP")

    def test_auto_detect_principal_type(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_users.return_value = {
            "Users": [{"UserId": "user-auto", "UserName": "auto"}]
        }

        # When principal_type is None, should default to USER
        result = manager._get_principal_id("auto", None)
        assert result == "user-auto"

    def test_client_error_propagates(self):
        manager, _, mock_identity = _make_sso_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "API Error"
        mock_identity.list_users.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListUsers",
        )

        with pytest.raises(Exception, match="API Error"):
            manager._get_principal_id("user@test.com", "USER")


@pytest.mark.unit
class TestGetPermissionSetArn:
    """Test _get_permission_set_arn method."""

    def test_find_permission_set_by_name(self):
        manager, mock_sso, _ = _make_sso_manager()

        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {"PermissionSets": ["arn:aws:sso:::permissionSet/ins/ps-admin"]}
        ]
        mock_sso.describe_permission_set.return_value = {
            "PermissionSet": {"Name": "AWSAdministratorAccess"}
        }

        result = manager._get_permission_set_arn("AWSAdministratorAccess")
        assert result == "arn:aws:sso:::permissionSet/ins/ps-admin"

    def test_permission_set_not_found(self):
        manager, mock_sso, _ = _make_sso_manager()

        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {"PermissionSets": ["arn:aws:sso:::permissionSet/ins/ps-admin"]}
        ]
        mock_sso.describe_permission_set.return_value = {"PermissionSet": {"Name": "SomeOtherSet"}}

        with pytest.raises(Exception, match="Permission set NonExistent not found"):
            manager._get_permission_set_arn("NonExistent")

    def test_client_error_propagates(self):
        manager, mock_sso, _ = _make_sso_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "SSO error"

        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListPermissionSets",
        )

        with pytest.raises(Exception, match="SSO error"):
            manager._get_permission_set_arn("AWSAdministratorAccess")


@pytest.mark.unit
class TestAssignPermission:
    """Test assign_permission method."""

    def test_assign_user_permission_success(self):
        manager, mock_sso, mock_identity = _make_sso_manager()
        manager.aws = MagicMock()

        # Mock _get_principal_id
        mock_identity.list_users.return_value = {"Users": [{"UserId": "user-123"}]}

        # Mock _get_permission_set_arn
        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [{"PermissionSets": ["arn:ps-admin"]}]
        mock_sso.describe_permission_set.return_value = {
            "PermissionSet": {"Name": "AWSAdministratorAccess"}
        }

        # Mock create_account_assignment
        mock_sso.create_account_assignment.return_value = {
            "AccountAssignmentCreationStatus": {
                "RequestId": "req-123",
                "Status": "SUCCEEDED",
            }
        }

        # Mock _wait_for_provisioning
        mock_sso.describe_account_assignment_creation_status.return_value = {
            "AccountAssignmentCreationStatus": {"Status": "SUCCEEDED"}
        }

        result = manager.assign_permission(
            account_id="123456789012",
            principal="user@example.com",
            permission_set="AWSAdministratorAccess",
        )

        assert result["status"] == "assigned"
        assert result["account_id"] == "123456789012"

    def test_assign_conflict_returns_already_exists(self):
        manager, mock_sso, mock_identity = _make_sso_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Conflict"

        # Mock _get_principal_id and _get_permission_set_arn
        mock_identity.list_users.return_value = {"Users": [{"UserId": "user-123"}]}
        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [{"PermissionSets": ["arn:ps-admin"]}]
        mock_sso.describe_permission_set.return_value = {
            "PermissionSet": {"Name": "AWSAdministratorAccess"}
        }

        # Raise ConflictException
        mock_sso.create_account_assignment.side_effect = ClientError(
            {"Error": {"Code": "ConflictException", "Message": "Already exists"}},
            "CreateAccountAssignment",
        )

        result = manager.assign_permission(
            account_id="123456789012",
            principal="user@example.com",
            permission_set="AWSAdministratorAccess",
        )

        assert result["status"] == "already_exists"

    def test_assign_other_client_error_raises(self):
        manager, mock_sso, mock_identity = _make_sso_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Access denied"

        mock_identity.list_users.return_value = {"Users": [{"UserId": "user-123"}]}
        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [{"PermissionSets": ["arn:ps-admin"]}]
        mock_sso.describe_permission_set.return_value = {
            "PermissionSet": {"Name": "AWSAdministratorAccess"}
        }

        mock_sso.create_account_assignment.side_effect = ClientError(
            {"Error": {"Code": "AccessDeniedException", "Message": "Denied"}},
            "CreateAccountAssignment",
        )

        with pytest.raises(Exception, match="Access denied"):
            manager.assign_permission(
                account_id="123456789012",
                principal="user@example.com",
            )

    def test_assign_auto_detects_group_type(self):
        manager, mock_sso, mock_identity = _make_sso_manager()

        # GROUP detection: no @ means it defaults to USER, but explicit GROUP is tested
        mock_identity.list_groups.return_value = {"Groups": [{"GroupId": "group-123"}]}
        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [{"PermissionSets": ["arn:ps-admin"]}]
        mock_sso.describe_permission_set.return_value = {
            "PermissionSet": {"Name": "AWSAdministratorAccess"}
        }
        mock_sso.create_account_assignment.return_value = {}

        result = manager.assign_permission(
            account_id="123456789012",
            principal="Developers",
            permission_set="AWSAdministratorAccess",
            principal_type="GROUP",
        )

        assert result["status"] == "assigned"


@pytest.mark.unit
class TestWaitForProvisioning:
    """Test _wait_for_provisioning method."""

    def test_wait_success(self):
        manager, mock_sso, _ = _make_sso_manager()
        mock_sso.describe_account_assignment_creation_status.return_value = {
            "AccountAssignmentCreationStatus": {"Status": "SUCCEEDED"}
        }

        # Should not raise
        manager._wait_for_provisioning("req-123", timeout=5)

    def test_wait_failure(self):
        manager, mock_sso, _ = _make_sso_manager()
        mock_sso.describe_account_assignment_creation_status.return_value = {
            "AccountAssignmentCreationStatus": {
                "Status": "FAILED",
                "FailureReason": "Invalid principal",
            }
        }

        with pytest.raises(Exception, match="Assignment provisioning failed: Invalid principal"):
            manager._wait_for_provisioning("req-123", timeout=5)

    def test_wait_timeout(self):
        manager, mock_sso, _ = _make_sso_manager()
        mock_sso.describe_account_assignment_creation_status.return_value = {
            "AccountAssignmentCreationStatus": {"Status": "IN_PROGRESS"}
        }

        with patch("ai_org.core.sso_manager.time") as mock_time:
            # Simulate timeout: first call returns 0, second returns > timeout
            mock_time.time.side_effect = [0, 0, 100]
            mock_time.sleep = MagicMock()

            with pytest.raises(Exception, match="Assignment provisioning timed out"):
                manager._wait_for_provisioning("req-123", timeout=5)

    def test_wait_client_error(self):
        manager, mock_sso, _ = _make_sso_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Status check failed"
        mock_sso.describe_account_assignment_creation_status.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "DescribeStatus",
        )

        with patch("ai_org.core.sso_manager.time") as mock_time:
            mock_time.time.side_effect = [0, 0]

            with pytest.raises(Exception, match="Status check failed"):
                manager._wait_for_provisioning("req-123", timeout=60)


@pytest.mark.unit
class TestListAssignments:
    """Test list_assignments method."""

    def test_list_assignments_success(self):
        manager, mock_sso, mock_identity = _make_sso_manager()

        # Mock permission set paginator
        ps_paginator = MagicMock()
        assign_paginator = MagicMock()

        def get_paginator(operation):
            if operation == "list_permission_sets_provisioned_to_account":
                return ps_paginator
            if operation == "list_account_assignments":
                return assign_paginator
            return MagicMock()

        mock_sso.get_paginator = get_paginator

        ps_paginator.paginate.return_value = [{"PermissionSets": ["arn:ps-admin"]}]
        mock_sso.describe_permission_set.return_value = {
            "PermissionSet": {"Name": "AWSAdministratorAccess"}
        }
        assign_paginator.paginate.return_value = [
            {
                "AccountAssignments": [
                    {
                        "PrincipalId": "user-123",
                        "PrincipalType": "USER",
                    }
                ]
            }
        ]

        # Mock _get_principal_details
        mock_identity.describe_user.return_value = {
            "DisplayName": "Jane Doe",
            "Emails": [{"Value": "jane@example.com", "Primary": True}],
        }

        result = manager.list_assignments("123456789012")

        assert len(result) == 1
        assert result[0]["permission_set"] == "AWSAdministratorAccess"
        assert result[0]["principal_name"] == "Jane Doe"
        assert result[0]["principal_email"] == "jane@example.com"

    def test_list_assignments_empty(self):
        manager, mock_sso, _ = _make_sso_manager()

        ps_paginator = MagicMock()
        mock_sso.get_paginator.return_value = ps_paginator
        ps_paginator.paginate.return_value = [{"PermissionSets": []}]

        result = manager.list_assignments("123456789012")
        assert result == []

    def test_list_assignments_client_error(self):
        manager, mock_sso, _ = _make_sso_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "List failed"

        mock_sso.get_paginator.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "GetPaginator",
        )

        with pytest.raises(Exception, match="List failed"):
            manager.list_assignments("123456789012")


@pytest.mark.unit
class TestGetPrincipalDetails:
    """Test _get_principal_details method."""

    def test_user_details(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.describe_user.return_value = {
            "DisplayName": "John Smith",
            "Emails": [{"Value": "john@example.com", "Primary": True}],
        }

        result = manager._get_principal_details("user-123", "USER")
        assert result["name"] == "John Smith"
        assert result["email"] == "john@example.com"

    def test_user_without_primary_email(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.describe_user.return_value = {
            "DisplayName": "No Primary",
            "Emails": [{"Value": "nope@example.com", "Primary": False}],
        }

        result = manager._get_principal_details("user-456", "USER")
        assert result["name"] == "No Primary"
        assert result["email"] is None

    def test_user_fallback_to_username(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.describe_user.return_value = {
            "UserName": "jdoe",
            "Emails": [],
        }

        result = manager._get_principal_details("user-789", "USER")
        assert result["name"] == "jdoe"
        assert result["email"] is None

    def test_group_details(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.describe_group.return_value = {
            "DisplayName": "Developers",
        }

        result = manager._get_principal_details("group-123", "GROUP")
        assert result["name"] == "Developers"
        assert result["email"] is None

    def test_deleted_principal_returns_unknown(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.describe_user.side_effect = ClientError(
            {"Error": {"Code": "ResourceNotFoundException", "Message": "gone"}},
            "DescribeUser",
        )

        result = manager._get_principal_details("user-deleted", "USER")
        assert result["name"] == "Unknown"
        assert result["email"] is None


@pytest.mark.unit
class TestGetUserDetailsByUsername:
    """Test get_user_details_by_username method."""

    def test_success(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_users.return_value = {
            "Users": [{"UserId": "user-sam", "UserName": "sam"}]
        }
        mock_identity.describe_user.return_value = {
            "Emails": [{"Value": "sam@example.com", "Primary": True}],
            "Name": {"GivenName": "Sam", "FamilyName": "Doe"},
        }

        result = manager.get_user_details_by_username("sam")
        assert result["email"] == "sam@example.com"
        assert result["first_name"] == "Sam"
        assert result["last_name"] == "Doe"

    def test_no_primary_email_falls_back_to_first(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_users.return_value = {
            "Users": [{"UserId": "user-bob", "UserName": "bob"}]
        }
        mock_identity.describe_user.return_value = {
            "Emails": [{"Value": "bob@example.com", "Primary": False}],
            "Name": {"GivenName": "Bob", "FamilyName": "Smith"},
        }

        result = manager.get_user_details_by_username("bob")
        assert result["email"] == "bob@example.com"

    def test_no_name_info_uses_defaults(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_users.return_value = {
            "Users": [{"UserId": "user-anon", "UserName": "anon"}]
        }
        mock_identity.describe_user.return_value = {
            "Emails": [{"Value": "anon@example.com", "Primary": True}],
        }

        result = manager.get_user_details_by_username("anon")
        assert result["first_name"] == "Admin"
        assert result["last_name"] == "User"

    def test_user_not_found_raises(self):
        manager, _, mock_identity = _make_sso_manager()
        mock_identity.list_users.return_value = {"Users": []}

        with pytest.raises(Exception, match="Failed to get details for user"):
            manager.get_user_details_by_username("nobody")


@pytest.mark.unit
class TestSyncOUAssignments:
    """Test sync_ou_assignments method."""

    def test_sync_assigns_to_all_accounts(self):
        manager, _mock_sso, _mock_identity = _make_sso_manager()

        with patch("ai_org.core.sso_manager.AccountManager") as mock_am_cls:
            mock_am = MagicMock()
            mock_am_cls.return_value = mock_am
            mock_am.list_accounts.return_value = [
                {"Id": "111111111111", "Name": "Account1"},
                {"Id": "222222222222", "Name": "Account2"},
            ]

            # Mock assign_permission
            manager.assign_permission = MagicMock(
                return_value={"status": "assigned", "account_id": "x"}
            )

            results = manager.sync_ou_assignments(
                principal="user@example.com",
                permission_set="AWSAdministratorAccess",
                ou_id="ou-test",
            )

            assert len(results) == 2
            assert manager.assign_permission.call_count == 2

    def test_sync_handles_individual_failures(self):
        manager, _mock_sso, _mock_identity = _make_sso_manager()

        with patch("ai_org.core.sso_manager.AccountManager") as mock_am_cls:
            mock_am = MagicMock()
            mock_am_cls.return_value = mock_am
            mock_am.list_accounts.return_value = [
                {"Id": "111111111111", "Name": "Account1"},
                {"Id": "222222222222", "Name": "Account2"},
            ]

            def side_effect(account_id, principal, permission_set):
                if account_id == "222222222222":
                    raise Exception("Permission denied")
                return {"status": "assigned", "account_id": account_id}

            manager.assign_permission = MagicMock(side_effect=side_effect)

            results = manager.sync_ou_assignments(
                principal="user@example.com",
            )

            assert len(results) == 2
            assert results[1]["status"] == "failed"
            assert "Permission denied" in results[1]["error"]


@pytest.mark.unit
class TestListPermissionSets:
    """Test list_permission_sets method."""

    def test_list_returns_sorted(self):
        manager, mock_sso, _ = _make_sso_manager()

        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {"PermissionSets": ["arn:ps-readonly", "arn:ps-admin"]}
        ]

        def describe_ps(InstanceArn, PermissionSetArn):
            if PermissionSetArn == "arn:ps-admin":
                return {
                    "PermissionSet": {
                        "Name": "AWSAdministratorAccess",
                        "Description": "Full admin",
                    }
                }
            return {
                "PermissionSet": {
                    "Name": "AWSReadOnlyAccess",
                    "Description": "Read only",
                }
            }

        mock_sso.describe_permission_set = describe_ps

        result = manager.list_permission_sets()

        assert len(result) == 2
        # Should be sorted: Admin before ReadOnly
        assert result[0]["name"] == "AWSAdministratorAccess"
        assert result[1]["name"] == "AWSReadOnlyAccess"

    def test_list_empty(self):
        manager, mock_sso, _ = _make_sso_manager()

        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [{"PermissionSets": []}]

        result = manager.list_permission_sets()
        assert result == []

    def test_list_client_error(self):
        manager, mock_sso, _ = _make_sso_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "List failed"

        mock_paginator = MagicMock()
        mock_sso.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListPermissionSets",
        )

        with pytest.raises(Exception, match="List failed"):
            manager.list_permission_sets()
