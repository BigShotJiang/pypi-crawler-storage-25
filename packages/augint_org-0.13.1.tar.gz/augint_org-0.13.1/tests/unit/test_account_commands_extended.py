"""Extended unit tests for account commands."""

from unittest.mock import MagicMock, patch

import pytest

from ai_org.cli import cli


@pytest.mark.unit
class TestAccountListCommand:
    def test_list_success(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.account.AccountManager") as mock_am_cls,
                patch("ai_org.commands.account.OUManager") as mock_ou_cls,
            ):
                mock_am = MagicMock()
                mock_am_cls.return_value = mock_am
                mock_am.list_accounts_with_ou.return_value = [
                    {
                        "Id": "111111111111",
                        "Name": "Account1",
                        "Email": "a@b.com",
                        "Status": "ACTIVE",
                        "ParentType": "ORGANIZATIONAL_UNIT",
                        "ParentName": "Workloads",
                        "ParentId": "ou-work",
                    }
                ]

                mock_ou = MagicMock()
                mock_ou_cls.return_value = mock_ou
                mock_ou.get_ou_tree.return_value = {
                    "Id": "r-root",
                    "Name": "Root",
                    "Children": [],
                }
                mock_ou.format_ou_tree.return_value = "Root"

                result = runner.invoke(cli, ["account", "list"])

                assert result.exit_code == 0

    def test_list_with_no_tree(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountManager") as mock_am_cls:
                mock_am = MagicMock()
                mock_am_cls.return_value = mock_am
                mock_am.list_accounts_with_ou.return_value = []

                result = runner.invoke(cli, ["account", "list", "--no-tree"])

                assert result.exit_code == 0

    def test_list_with_ou_filter(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.account.AccountManager") as mock_am_cls,
                patch("ai_org.commands.account.OUManager") as mock_ou_cls,
            ):
                mock_am = MagicMock()
                mock_am_cls.return_value = mock_am
                mock_am.list_accounts_with_ou.return_value = []

                mock_ou = MagicMock()
                mock_ou_cls.return_value = mock_ou
                mock_ou.get_ou_tree.return_value = {
                    "Id": "r-root",
                    "Name": "Root",
                    "Children": [],
                }
                mock_ou.format_ou_tree.return_value = "Root"

                result = runner.invoke(cli, ["account", "list", "--ou", "ou-workloads"])

                assert result.exit_code == 0
                mock_am.list_accounts_with_ou.assert_called_once_with(
                    ou="ou-workloads", status="ACTIVE"
                )

    def test_list_json(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountManager") as mock_am_cls:
                mock_am = MagicMock()
                mock_am_cls.return_value = mock_am
                mock_am.list_accounts_with_ou.return_value = [{"Id": "111", "Status": "ACTIVE"}]

                result = runner.invoke(cli, ["--json", "account", "list"])

                assert result.exit_code == 0

    def test_list_root_parent(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.account.AccountManager") as mock_am_cls,
                patch("ai_org.commands.account.OUManager") as mock_ou_cls,
            ):
                mock_am = MagicMock()
                mock_am_cls.return_value = mock_am
                mock_am.list_accounts_with_ou.return_value = [
                    {
                        "Id": "111111111111",
                        "Name": "Mgmt",
                        "Email": "m@b.com",
                        "Status": "ACTIVE",
                        "ParentType": "ROOT",
                        "ParentName": "Root",
                        "ParentId": "r-root",
                    }
                ]

                mock_ou = MagicMock()
                mock_ou_cls.return_value = mock_ou
                mock_ou.get_ou_tree.side_effect = Exception("fail")

                result = runner.invoke(cli, ["account", "list"])

                assert result.exit_code == 0

    def test_list_error(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with (
                patch("ai_org.commands.account.AccountManager") as mock_am_cls,
                patch("ai_org.commands.account.OUManager") as mock_ou_cls,
            ):
                mock_am = MagicMock()
                mock_am_cls.return_value = mock_am
                mock_am.list_accounts_with_ou.side_effect = Exception("API Error")

                mock_ou = MagicMock()
                mock_ou_cls.return_value = mock_ou
                mock_ou.get_ou_tree.return_value = {
                    "Id": "r-root",
                    "Name": "Root",
                    "Children": [],
                }
                mock_ou.format_ou_tree.return_value = "Root"

                result = runner.invoke(cli, ["account", "list"])

                assert result.exit_code != 0


@pytest.mark.unit
class TestAccountGetCommand:
    def test_get_success(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountManager") as mock_am_cls:
                mock_am = MagicMock()
                mock_am_cls.return_value = mock_am
                mock_am.get_account.return_value = {
                    "Id": "123456789012",
                    "Name": "test-account",
                    "Email": "test@example.com",
                    "Status": "ACTIVE",
                }

                result = runner.invoke(cli, ["account", "get", "123456789012"])

                assert result.exit_code == 0

    def test_get_json(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountManager") as mock_am_cls:
                mock_am = MagicMock()
                mock_am_cls.return_value = mock_am
                mock_am.get_account.return_value = {
                    "Id": "123456789012",
                    "Name": "test",
                }

                result = runner.invoke(cli, ["--json", "account", "get", "123456789012"])

                assert result.exit_code == 0


@pytest.mark.unit
class TestEnrollmentStatusCommand:
    def test_enrolled(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountFactory") as mock_af_cls:
                mock_af = MagicMock()
                mock_af_cls.return_value = mock_af
                mock_af.get_enrollment_status.return_value = {
                    "account_id": "123456789012",
                    "account_name": "test",
                    "account_email": "test@example.com",
                    "account_status": "ACTIVE",
                    "parent_ou": "ou-workloads",
                    "enrolled": True,
                    "enrollment_status": "Enrolled",
                    "control_tower_stacks": 3,
                }

                result = runner.invoke(cli, ["account", "enrollment-status", "123456789012"])

                assert result.exit_code == 0

    def test_not_enrolled(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountFactory") as mock_af_cls:
                mock_af = MagicMock()
                mock_af_cls.return_value = mock_af
                mock_af.get_enrollment_status.return_value = {
                    "account_id": "123456789012",
                    "account_name": "test",
                    "account_email": "test@example.com",
                    "account_status": "ACTIVE",
                    "parent_ou": "ou-sandbox",
                    "enrolled": False,
                    "enrollment_status": "Not enrolled",
                }

                result = runner.invoke(cli, ["account", "enrollment-status", "123456789012"])

                assert result.exit_code == 0

    def test_error_status(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountFactory") as mock_af_cls:
                mock_af = MagicMock()
                mock_af_cls.return_value = mock_af
                mock_af.get_enrollment_status.return_value = {
                    "account_id": "999",
                    "error": "Account not found",
                }

                result = runner.invoke(cli, ["account", "enrollment-status", "999999999999"])

                assert result.exit_code == 0

    def test_json_output(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountFactory") as mock_af_cls:
                mock_af = MagicMock()
                mock_af_cls.return_value = mock_af
                mock_af.get_enrollment_status.return_value = {
                    "account_id": "123456789012",
                    "enrolled": True,
                }

                result = runner.invoke(
                    cli,
                    ["--json", "account", "enrollment-status", "123456789012"],
                )

                assert result.exit_code == 0

    def test_exception(self, runner):
        with patch("ai_org.core.aws_client.boto3.Session"):
            with patch("ai_org.commands.account.AccountFactory") as mock_af_cls:
                mock_af = MagicMock()
                mock_af_cls.return_value = mock_af
                mock_af.get_enrollment_status.side_effect = Exception("API Error")

                result = runner.invoke(cli, ["account", "enrollment-status", "123456789012"])

                assert result.exit_code != 0
