"""Unit tests for the AccountManager class."""

from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError


def _make_manager():
    """Create an AccountManager with mocked dependencies."""
    with (
        patch("ai_org.core.account_manager.AWSClient") as mock_aws,
        patch("ai_org.core.account_manager.ConfigManager"),
    ):
        mock_aws_instance = MagicMock()
        mock_aws.return_value = mock_aws_instance

        mock_org = MagicMock()
        mock_aws_instance.client.return_value = mock_org

        from ai_org.core.account_manager import AccountManager

        manager = AccountManager()
        manager.org_client = mock_org
        return manager, mock_org


@pytest.mark.unit
class TestListAccounts:
    def test_list_all_active(self):
        manager, _mock_org = _make_manager()
        manager.aws = MagicMock()
        manager.aws.paginate.return_value = [
            {"Id": "111", "Name": "A1", "Status": "ACTIVE"},
            {"Id": "222", "Name": "A2", "Status": "SUSPENDED"},
            {"Id": "333", "Name": "A3", "Status": "ACTIVE"},
        ]

        result = manager.list_accounts()
        assert len(result) == 2
        assert all(a["Status"] == "ACTIVE" for a in result)

    def test_list_by_ou(self):
        manager, mock_org = _make_manager()
        mock_org.list_accounts_for_parent.return_value = {
            "Accounts": [
                {"Id": "111", "Name": "A1", "Status": "ACTIVE"},
            ]
        }

        result = manager.list_accounts(ou="ou-test")
        assert len(result) == 1
        mock_org.list_accounts_for_parent.assert_called_once_with(ParentId="ou-test")

    def test_list_suspended(self):
        manager, _mock_org = _make_manager()
        manager.aws = MagicMock()
        manager.aws.paginate.return_value = [
            {"Id": "111", "Status": "ACTIVE"},
            {"Id": "222", "Status": "SUSPENDED"},
        ]

        result = manager.list_accounts(status="SUSPENDED")
        assert len(result) == 1
        assert result[0]["Id"] == "222"

    def test_list_client_error(self):
        manager, _mock_org = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "List failed"
        manager.aws.paginate.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListAccounts",
        )

        with pytest.raises(Exception, match="List failed"):
            manager.list_accounts()


@pytest.mark.unit
class TestGetAccount:
    def test_success(self):
        manager, mock_org = _make_manager()
        mock_org.describe_account.return_value = {
            "Account": {
                "Id": "123456789012",
                "Name": "test",
                "Email": "test@example.com",
                "Status": "ACTIVE",
            }
        }

        result = manager.get_account("123456789012")
        assert result["Id"] == "123456789012"
        assert result["Name"] == "test"

    def test_not_found(self):
        manager, mock_org = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Account not found"
        mock_org.describe_account.side_effect = ClientError(
            {"Error": {"Code": "AccountNotFoundException", "Message": "not found"}},
            "DescribeAccount",
        )

        with pytest.raises(Exception, match="Account not found"):
            manager.get_account("999999999999")


@pytest.mark.unit
class TestGetAccountParentOU:
    def test_ou_parent(self):
        manager, mock_org = _make_manager()
        mock_org.list_parents.return_value = {
            "Parents": [{"Id": "ou-workloads", "Type": "ORGANIZATIONAL_UNIT"}]
        }
        mock_org.describe_organizational_unit.return_value = {
            "OrganizationalUnit": {"Name": "Workloads"}
        }

        result = manager.get_account_parent_ou("123456789012")
        assert result["Id"] == "ou-workloads"
        assert result["Name"] == "Workloads"
        assert result["Type"] == "ORGANIZATIONAL_UNIT"

    def test_root_parent(self):
        manager, mock_org = _make_manager()
        mock_org.list_parents.return_value = {"Parents": [{"Id": "r-root", "Type": "ROOT"}]}
        mock_org.list_roots.return_value = {"Roots": [{"Name": "Root"}]}

        result = manager.get_account_parent_ou("123456789012")
        assert result["Id"] == "r-root"
        assert result["Name"] == "Root"

    def test_client_error_returns_unknown(self):
        manager, mock_org = _make_manager()
        mock_org.list_parents.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListParents",
        )

        result = manager.get_account_parent_ou("123456789012")
        assert result["Id"] == "unknown"
        assert result["Name"] == "Unknown"


@pytest.mark.unit
class TestListAccountsWithOU:
    def test_adds_ou_info(self):
        manager, mock_org = _make_manager()
        manager.aws = MagicMock()
        manager.aws.paginate.return_value = [
            {"Id": "111", "Name": "A1", "Status": "ACTIVE"},
        ]

        mock_org.list_parents.return_value = {
            "Parents": [{"Id": "ou-work", "Type": "ORGANIZATIONAL_UNIT"}]
        }
        mock_org.describe_organizational_unit.return_value = {
            "OrganizationalUnit": {"Name": "Workloads"}
        }

        result = manager.list_accounts_with_ou()
        assert len(result) == 1
        assert result[0]["ParentName"] == "Workloads"


@pytest.mark.unit
class TestGetRootOUId:
    def test_returns_root_id(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": [{"Id": "r-abcd"}]}

        result = manager._get_root_ou_id()
        assert result == "r-abcd"


@pytest.mark.unit
class TestGetOUName:
    def test_regular_ou(self):
        manager, mock_org = _make_manager()
        mock_org.describe_organizational_unit.return_value = {
            "OrganizationalUnit": {"Name": "Workloads"}
        }

        result = manager._get_ou_name("ou-test-12345678")
        assert result == "Workloads"

    def test_root_id(self):
        manager, _mock_org = _make_manager()

        result = manager._get_ou_name("r-root")
        assert result == "Root"

    def test_not_found(self):
        manager, mock_org = _make_manager()
        mock_org.describe_organizational_unit.side_effect = ClientError(
            {"Error": {"Code": "OrganizationalUnitNotFoundException", "Message": "not found"}},
            "DescribeOU",
        )

        result = manager._get_ou_name("ou-nonexistent")
        assert result is None


@pytest.mark.unit
class TestMoveAccountToOU:
    def test_move(self):
        manager, mock_org = _make_manager()
        mock_org.list_parents.return_value = {"Parents": [{"Id": "ou-current"}]}

        manager._move_account_to_ou("123456789012", "ou-target")

        mock_org.move_account.assert_called_once_with(
            AccountId="123456789012",
            SourceParentId="ou-current",
            DestinationParentId="ou-target",
        )


@pytest.mark.unit
class TestGetOUByName:
    def test_find_recursive(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": [{"Id": "r-root"}]}

        # Root level has Security, but not Workloads
        # Security has Workloads nested inside
        mock_org.list_organizational_units_for_parent.side_effect = [
            {
                "OrganizationalUnits": [
                    {"Id": "ou-security", "Name": "Security"},
                ]
            },
            {
                "OrganizationalUnits": [
                    {"Id": "ou-workloads", "Name": "Workloads"},
                ]
            },
        ]

        result = manager.get_ou_by_name("Workloads")
        assert result == "ou-workloads"

    def test_not_found(self):
        manager, mock_org = _make_manager()
        mock_org.list_roots.return_value = {"Roots": [{"Id": "r-root"}]}
        mock_org.list_organizational_units_for_parent.return_value = {"OrganizationalUnits": []}

        result = manager.get_ou_by_name("Nonexistent")
        assert result is None

    def test_client_error(self):
        manager, mock_org = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "OU error"
        mock_org.list_roots.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListRoots",
        )

        with pytest.raises(Exception, match="OU error"):
            manager.get_ou_by_name("Workloads")


@pytest.mark.unit
class TestWaitForAccountCreation:
    def test_success(self):
        manager, mock_org = _make_manager()
        mock_org.describe_create_account_status.return_value = {
            "CreateAccountStatus": {
                "State": "SUCCEEDED",
                "AccountId": "123456789012",
            }
        }

        result = manager._wait_for_account_creation("req-123")
        assert result == "123456789012"

    def test_failure(self):
        manager, mock_org = _make_manager()
        mock_org.describe_create_account_status.return_value = {
            "CreateAccountStatus": {
                "State": "FAILED",
                "FailureReason": "Email already used",
            }
        }

        with pytest.raises(Exception, match="Account creation failed: Email already used"):
            manager._wait_for_account_creation("req-123")

    def test_timeout(self):
        manager, mock_org = _make_manager()
        mock_org.describe_create_account_status.return_value = {
            "CreateAccountStatus": {"State": "IN_PROGRESS"}
        }

        with patch("ai_org.core.account_manager.time") as mock_time:
            mock_time.time.side_effect = [0, 0, 99999]
            mock_time.sleep = MagicMock()

            with pytest.raises(Exception, match="Account creation timed out"):
                manager._wait_for_account_creation("req-123", timeout=5)
