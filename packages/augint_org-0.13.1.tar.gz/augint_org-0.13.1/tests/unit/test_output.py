"""Unit tests for the OutputFormatter class."""

import json

import pytest

from ai_org.utils.output import OutputFormatter


@pytest.mark.unit
class TestOutputFormatterInit:
    def test_default_state(self):
        output = OutputFormatter()
        assert output.json_mode is False


@pytest.mark.unit
class TestSetJsonMode:
    def test_enable(self):
        output = OutputFormatter()
        output.set_json_mode(True)
        assert output.json_mode is True

    def test_disable(self):
        output = OutputFormatter()
        output.set_json_mode(True)
        output.set_json_mode(False)
        assert output.json_mode is False


@pytest.mark.unit
class TestJsonOutput:
    def test_outputs_json(self, capsys):
        output = OutputFormatter()
        output.json_mode = True
        output.json_output({"key": "value"})
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed["key"] == "value"

    def test_no_output_when_not_json_mode(self, capsys):
        output = OutputFormatter()
        output.json_mode = False
        output.json_output({"key": "value"})
        captured = capsys.readouterr()
        assert captured.out == ""


@pytest.mark.unit
class TestTextMethods:
    def test_info_in_non_json_mode(self):
        output = OutputFormatter()
        output.json_mode = False
        # Should not raise
        output.info("Test info message")

    def test_info_suppressed_in_json_mode(self):
        output = OutputFormatter()
        output.json_mode = True
        # Should not raise, but should not print
        output.info("Test info message")

    def test_success_in_non_json_mode(self):
        output = OutputFormatter()
        output.json_mode = False
        output.success("Success message")

    def test_success_suppressed_in_json_mode(self):
        output = OutputFormatter()
        output.json_mode = True
        output.success("Success message")

    def test_warning_in_non_json_mode(self):
        output = OutputFormatter()
        output.json_mode = False
        output.warning("Warning message")

    def test_warning_suppressed_in_json_mode(self):
        output = OutputFormatter()
        output.json_mode = True
        output.warning("Warning message")

    def test_error_in_non_json_mode(self):
        output = OutputFormatter()
        output.json_mode = False
        output.error("Error message")

    def test_error_suppressed_in_json_mode(self):
        output = OutputFormatter()
        output.json_mode = True
        output.error("Error message")

    def test_progress_in_non_json_mode(self):
        output = OutputFormatter()
        output.json_mode = False
        output.progress("Progress message")

    def test_text_in_non_json_mode(self):
        output = OutputFormatter()
        output.json_mode = False
        output.text("Plain text")


@pytest.mark.unit
class TestTable:
    def test_table_non_json(self):
        output = OutputFormatter()
        output.json_mode = False
        data = [
            {"Name": "A", "Status": "ACTIVE"},
            {"Name": "B", "Status": "SUSPENDED"},
        ]
        # Should not raise
        output.table(data, columns=["Name", "Status"], title="Test Table")

    def test_table_json_mode(self, capsys):
        output = OutputFormatter()
        output.json_mode = True
        data = [{"Name": "A"}]
        output.table(data, columns=["Name"])
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed[0]["Name"] == "A"

    def test_table_empty_data(self):
        output = OutputFormatter()
        output.json_mode = False
        output.table([], columns=["Name"])

    def test_table_with_none_values(self):
        output = OutputFormatter()
        output.json_mode = False
        data = [{"Name": "A", "Value": None}]
        output.table(data, columns=["Name", "Value"])

    def test_table_with_bool_values(self):
        output = OutputFormatter()
        output.json_mode = False
        data = [{"Name": "A", "Active": True}, {"Name": "B", "Active": False}]
        output.table(data, columns=["Name", "Active"])


@pytest.mark.unit
class TestDictDisplay:
    def test_dict_non_json(self):
        output = OutputFormatter()
        output.json_mode = False
        output.dict_display({"key": "value"}, title="Test Dict")

    def test_dict_json_mode(self, capsys):
        output = OutputFormatter()
        output.json_mode = True
        output.dict_display({"key": "value"})
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed["key"] == "value"

    def test_dict_with_nested(self):
        output = OutputFormatter()
        output.json_mode = False
        output.dict_display({"key": "value", "nested": {"sub": "item"}, "list": ["a", "b"]})
