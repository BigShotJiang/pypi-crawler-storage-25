"""Unit tests for the StackSetManager class."""

from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError


def _make_manager():
    """Create a StackSetManager with mocked dependencies."""
    with patch("ai_org.core.stackset_manager.AWSClient") as mock_aws:
        mock_aws_instance = MagicMock()
        mock_aws.return_value = mock_aws_instance
        mock_aws_instance.region = "us-east-1"

        mock_cfn = MagicMock()
        mock_aws_instance.client.return_value = mock_cfn

        from ai_org.core.stackset_manager import StackSetManager

        manager = StackSetManager()
        manager.cfn_client = mock_cfn
        return manager, mock_cfn


@pytest.mark.unit
class TestStackSetManagerInit:
    """Test StackSetManager initialization."""

    def test_init_creates_cfn_client(self):
        with patch("ai_org.core.stackset_manager.AWSClient") as mock_aws:
            mock_instance = MagicMock()
            mock_aws.return_value = mock_instance

            from ai_org.core.stackset_manager import StackSetManager

            manager = StackSetManager(profile="test", region="us-west-2")

            mock_aws.assert_called_once_with("test", "us-west-2")
            mock_instance.client.assert_called_once_with("cloudformation")


@pytest.mark.unit
class TestListAllStacksets:
    """Test _list_all_stacksets method."""

    def test_returns_names(self):
        manager, mock_cfn = _make_manager()
        mock_paginator = MagicMock()
        mock_cfn.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {
                "Summaries": [
                    {"StackSetName": "org-pipeline-bootstrap"},
                    {"StackSetName": "org-github-oidc"},
                ]
            }
        ]

        result = manager._list_all_stacksets()
        assert result == ["org-pipeline-bootstrap", "org-github-oidc"]

    def test_empty_returns_empty(self):
        manager, mock_cfn = _make_manager()
        mock_paginator = MagicMock()
        mock_cfn.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [{"Summaries": []}]

        result = manager._list_all_stacksets()
        assert result == []


@pytest.mark.unit
class TestGetDeploymentStatus:
    """Test get_deployment_status method."""

    def test_specific_stackset_status(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.describe_stack_instance.return_value = {
            "StackInstance": {
                "Status": "CURRENT",
                "StatusReason": "",
                "DriftStatus": "NOT_CHECKED",
            }
        }

        result = manager.get_deployment_status("123456789012", "test-stackset")

        assert len(result) == 1
        assert result[0]["StackSetName"] == "test-stackset"
        assert result[0]["Status"] == "CURRENT"

    def test_service_managed_stackset_uses_call_as_self(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.describe_stack_instance.return_value = {
            "StackInstance": {
                "Status": "CURRENT",
                "StatusReason": "",
                "DriftStatus": "NOT_CHECKED",
            }
        }

        manager.get_deployment_status("123456789012", "org-pipeline-bootstrap")

        call_kwargs = mock_cfn.describe_stack_instance.call_args[1]
        assert call_kwargs["CallAs"] == "SELF"

    def test_non_service_managed_no_call_as(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.describe_stack_instance.return_value = {
            "StackInstance": {
                "Status": "CURRENT",
                "StatusReason": "",
                "DriftStatus": "NOT_CHECKED",
            }
        }

        manager.get_deployment_status("123456789012", "custom-stackset")

        call_kwargs = mock_cfn.describe_stack_instance.call_args[1]
        assert "CallAs" not in call_kwargs

    def test_stack_instance_not_found(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.describe_stack_instance.side_effect = ClientError(
            {"Error": {"Code": "StackInstanceNotFoundException", "Message": "not found"}},
            "DescribeStackInstance",
        )

        result = manager.get_deployment_status("123456789012", "test-stackset")

        assert len(result) == 1
        assert result[0]["Status"] == "NOT_DEPLOYED"

    def test_all_stacksets_when_no_name_given(self):
        manager, mock_cfn = _make_manager()

        # Mock _list_all_stacksets
        mock_paginator = MagicMock()
        mock_cfn.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {"Summaries": [{"StackSetName": "ss1"}, {"StackSetName": "ss2"}]}
        ]

        mock_cfn.describe_stack_instance.return_value = {
            "StackInstance": {
                "Status": "CURRENT",
                "StatusReason": "",
                "DriftStatus": "NOT_CHECKED",
            }
        }

        result = manager.get_deployment_status("123456789012")

        assert len(result) == 2

    def test_other_client_error_raises(self):
        manager, mock_cfn = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "API Error"
        mock_cfn.describe_stack_instance.side_effect = ClientError(
            {"Error": {"Code": "AccessDeniedException", "Message": "denied"}},
            "DescribeStackInstance",
        )

        with pytest.raises(Exception, match="API Error"):
            manager.get_deployment_status("123456789012", "test-stackset")


@pytest.mark.unit
class TestWaitForDeployments:
    """Test wait_for_deployments method."""

    def test_all_current_returns_true(self):
        manager, _mock_cfn = _make_manager()

        with patch.object(manager, "get_deployment_status") as mock_status:
            mock_status.return_value = [
                {"StackSetName": "ss1", "Status": "CURRENT"},
                {"StackSetName": "ss2", "Status": "SUCCEEDED"},
            ]

            result = manager.wait_for_deployments("123456789012", timeout=5)
            assert result is True

    def test_failed_status_returns_false(self):
        manager, _mock_cfn = _make_manager()

        with patch.object(manager, "get_deployment_status") as mock_status:
            mock_status.return_value = [
                {"StackSetName": "ss1", "Status": "CURRENT"},
                {"StackSetName": "ss2", "Status": "FAILED"},
            ]

            result = manager.wait_for_deployments("123456789012", timeout=5)
            assert result is False

    def test_timeout_returns_false(self):
        manager, _mock_cfn = _make_manager()

        with (
            patch.object(manager, "get_deployment_status") as mock_status,
            patch("ai_org.core.stackset_manager.time") as mock_time,
        ):
            mock_status.return_value = [
                {"StackSetName": "ss1", "Status": "PENDING"},
            ]
            mock_time.time.side_effect = [0, 0, 1000]
            mock_time.sleep = MagicMock()

            result = manager.wait_for_deployments("123456789012", timeout=5)
            assert result is False

    def test_pending_then_completes(self):
        manager, _mock_cfn = _make_manager()

        with (
            patch.object(manager, "get_deployment_status") as mock_status,
            patch("ai_org.core.stackset_manager.time") as mock_time,
        ):
            mock_status.side_effect = [
                [{"StackSetName": "ss1", "Status": "RUNNING"}],
                [{"StackSetName": "ss1", "Status": "CURRENT"}],
            ]
            mock_time.time.side_effect = [0, 0, 1, 1]
            mock_time.sleep = MagicMock()

            result = manager.wait_for_deployments("123456789012", timeout=60)
            assert result is True


@pytest.mark.unit
class TestListStacksets:
    """Test list_stacksets method."""

    def test_list_returns_enhanced_info(self):
        manager, mock_cfn = _make_manager()

        mock_paginator = MagicMock()
        mock_cfn.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {
                "Summaries": [
                    {
                        "StackSetName": "org-pipeline-bootstrap",
                        "Status": "ACTIVE",
                    }
                ]
            }
        ]

        mock_cfn.describe_stack_set.return_value = {
            "StackSet": {
                "AutoDeployment": {"Enabled": False},
            }
        }

        # Mock _count_stack_instances
        list_instances_paginator = MagicMock()
        list_instances_paginator.paginate.return_value = [{"Summaries": [{"Account": "123"}]}]

        def paginator_factory(operation):
            if operation == "list_stack_sets":
                return mock_paginator
            if operation == "list_stack_instances":
                return list_instances_paginator
            return MagicMock()

        mock_cfn.get_paginator = paginator_factory

        result = manager.list_stacksets()

        assert len(result) == 1
        assert result[0]["StackSetName"] == "org-pipeline-bootstrap"
        assert result[0]["Status"] == "ACTIVE"

    def test_list_handles_describe_failure(self):
        manager, mock_cfn = _make_manager()

        mock_paginator = MagicMock()
        mock_paginator.paginate.return_value = [
            {
                "Summaries": [
                    {
                        "StackSetName": "failing-stackset",
                        "Status": "ACTIVE",
                        "AutoDeployment": {"Enabled": True},
                    }
                ]
            }
        ]

        mock_cfn.get_paginator.return_value = mock_paginator
        mock_cfn.describe_stack_set.side_effect = Exception("Access denied")

        result = manager.list_stacksets()

        assert len(result) == 1
        assert result[0]["StackSetName"] == "failing-stackset"

    def test_list_client_error_raises(self):
        manager, mock_cfn = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "List failed"

        mock_paginator = MagicMock()
        mock_cfn.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListStackSets",
        )

        with pytest.raises(Exception, match="List failed"):
            manager.list_stacksets()


@pytest.mark.unit
class TestGetStacksetOperations:
    """Test get_stackset_operations method."""

    def test_returns_operations(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.list_stack_set_operations.return_value = {
            "Summaries": [
                {
                    "OperationId": "op-123",
                    "Action": "CREATE",
                    "Status": "SUCCEEDED",
                    "CreationTimestamp": "2024-01-01T00:00:00Z",
                    "EndTimestamp": "2024-01-01T00:10:00Z",
                },
                {
                    "OperationId": "op-456",
                    "Action": "UPDATE",
                    "Status": "FAILED",
                },
            ]
        }

        result = manager.get_stackset_operations("test-stackset", limit=5)

        assert len(result) == 2
        assert result[0]["OperationId"] == "op-123"
        assert result[0]["Action"] == "CREATE"
        assert result[0]["Status"] == "SUCCEEDED"
        assert result[1]["Status"] == "FAILED"

    def test_empty_operations(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.list_stack_set_operations.return_value = {"Summaries": []}

        result = manager.get_stackset_operations("test-stackset")
        assert result == []

    def test_client_error_raises(self):
        manager, mock_cfn = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Operations failed"
        mock_cfn.list_stack_set_operations.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "ListStackSetOperations",
        )

        with pytest.raises(Exception, match="Operations failed"):
            manager.get_stackset_operations("test-stackset")


@pytest.mark.unit
class TestGetStacksetParameters:
    """Test get_stackset_parameters method."""

    def test_returns_json_template_params(self):
        manager, mock_cfn = _make_manager()
        import json

        template = {
            "Parameters": {
                "Env": {
                    "Type": "String",
                    "Default": "prod",
                    "Description": "Environment name",
                },
                "Region": {
                    "Type": "String",
                    "AllowedValues": ["us-east-1", "us-west-2"],
                },
            }
        }

        mock_cfn.describe_stack_set.return_value = {
            "StackSet": {
                "TemplateBody": json.dumps(template),
                "Parameters": [
                    {"ParameterKey": "Env", "ParameterValue": "staging"},
                ],
            }
        }

        result = manager.get_stackset_parameters("test-stackset")

        assert len(result) == 2
        env_param = next(p for p in result if p["name"] == "Env")
        assert env_param["default"] == "prod"
        assert env_param["current_value"] == "staging"
        assert env_param["description"] == "Environment name"

        region_param = next(p for p in result if p["name"] == "Region")
        assert region_param["allowed_values"] == ["us-east-1", "us-west-2"]

    def test_returns_yaml_template_params(self):
        manager, mock_cfn = _make_manager()

        yaml_template = """
Parameters:
  BucketName:
    Type: String
    Default: my-bucket
    Description: S3 bucket name
"""
        mock_cfn.describe_stack_set.return_value = {
            "StackSet": {
                "TemplateBody": yaml_template,
                "Parameters": [],
            }
        }

        result = manager.get_stackset_parameters("test-stackset")

        assert len(result) == 1
        assert result[0]["name"] == "BucketName"
        assert result[0]["default"] == "my-bucket"

    def test_unparseable_template_returns_current_params(self):
        manager, mock_cfn = _make_manager()

        mock_cfn.describe_stack_set.return_value = {
            "StackSet": {
                "TemplateBody": "{{invalid template content}}",
                "Parameters": [
                    {"ParameterKey": "Key1", "ParameterValue": "Value1"},
                ],
            }
        }

        result = manager.get_stackset_parameters("test-stackset")

        assert len(result) == 1
        assert result[0]["name"] == "Key1"
        assert result[0]["current_value"] == "Value1"

    def test_delegated_admin_fallback(self):
        manager, mock_cfn = _make_manager()
        import json

        template = {"Parameters": {"Key": {"Type": "String"}}}

        # First call with DELEGATED_ADMIN fails
        mock_cfn.describe_stack_set.side_effect = [
            ClientError(
                {"Error": {"Code": "ValidationError", "Message": "ValidationError"}},
                "DescribeStackSet",
            ),
            {
                "StackSet": {
                    "TemplateBody": json.dumps(template),
                    "Parameters": [],
                }
            },
        ]

        result = manager.get_stackset_parameters("test-stackset")
        assert len(result) == 1

    def test_client_error_raises(self):
        manager, mock_cfn = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Params failed"
        mock_cfn.describe_stack_set.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "DescribeStackSet",
        )

        with pytest.raises(Exception, match="Params failed"):
            manager.get_stackset_parameters("test-stackset")


@pytest.mark.unit
class TestDeployToAccount:
    """Test deploy_to_account method."""

    def test_deploy_new_service_managed(self):
        manager, mock_cfn = _make_manager()

        # Instance does not exist
        mock_cfn.describe_stack_instance.side_effect = ClientError(
            {"Error": {"Code": "StackInstanceNotFoundException", "Message": "not found"}},
            "DescribeStackInstance",
        )

        # boto3 is imported inside deploy_to_account, mock at the builtins level
        mock_org = MagicMock()
        mock_org.list_parents.return_value = {"Parents": [{"Id": "ou-test-workloads"}]}

        with patch("boto3.client", return_value=mock_org):
            mock_cfn.create_stack_instances.return_value = {"OperationId": "op-new-123"}

            result = manager.deploy_to_account(
                account_id="123456789012",
                stackset_name="org-pipeline-bootstrap",
                parameters={"Env": "prod"},
                regions=["us-east-1"],
            )

            assert result == "op-new-123"
            mock_cfn.create_stack_instances.assert_called_once()

    def test_deploy_update_existing_non_service_managed(self):
        manager, mock_cfn = _make_manager()

        # Instance exists
        mock_cfn.describe_stack_instance.return_value = {"StackInstance": {"Status": "CURRENT"}}

        mock_cfn.update_stack_instances.return_value = {"OperationId": "op-update-123"}

        result = manager.deploy_to_account(
            account_id="123456789012",
            stackset_name="custom-stackset",
            regions=["us-east-1"],
        )

        assert result == "op-update-123"
        mock_cfn.update_stack_instances.assert_called_once()

    def test_deploy_default_regions(self):
        manager, mock_cfn = _make_manager()

        mock_cfn.describe_stack_instance.side_effect = ClientError(
            {"Error": {"Code": "StackInstanceNotFoundException", "Message": "not found"}},
            "DescribeStackInstance",
        )

        mock_cfn.create_stack_instances.return_value = {"OperationId": "op-default-regions"}

        result = manager.deploy_to_account(
            account_id="123456789012",
            stackset_name="custom-stackset",
        )

        call_kwargs = mock_cfn.create_stack_instances.call_args[1]
        assert call_kwargs["Regions"] == ["us-east-1", "us-west-2"]


@pytest.mark.unit
class TestWaitForDeploymentOperation:
    """Test wait_for_deployment_operation method."""

    def test_success(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.describe_stack_set_operation.return_value = {
            "StackSetOperation": {"Status": "SUCCEEDED"}
        }

        result = manager.wait_for_deployment_operation("org-test", "op-123", timeout=5)
        assert result is True

    def test_failed(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.describe_stack_set_operation.return_value = {
            "StackSetOperation": {"Status": "FAILED"}
        }

        result = manager.wait_for_deployment_operation("org-test", "op-123", timeout=5)
        assert result is False

    def test_stopped(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.describe_stack_set_operation.return_value = {
            "StackSetOperation": {"Status": "STOPPED"}
        }

        result = manager.wait_for_deployment_operation("org-test", "op-123", timeout=5)
        assert result is False

    def test_timeout(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.describe_stack_set_operation.return_value = {
            "StackSetOperation": {"Status": "RUNNING"}
        }

        with patch("ai_org.core.stackset_manager.time") as mock_time:
            mock_time.time.side_effect = [0, 0, 1000]
            mock_time.sleep = MagicMock()

            result = manager.wait_for_deployment_operation("org-test", "op-123", timeout=5)
            assert result is False

    def test_delegated_admin_fallback(self):
        manager, mock_cfn = _make_manager()

        # First call with DELEGATED_ADMIN fails, second without succeeds
        mock_cfn.describe_stack_set_operation.side_effect = [
            ClientError(
                {
                    "Error": {
                        "Code": "ValidationError",
                        "Message": "delegated administrator",
                    }
                },
                "DescribeStackSetOperation",
            ),
            {"StackSetOperation": {"Status": "SUCCEEDED"}},
        ]

        result = manager.wait_for_deployment_operation("custom-stackset", "op-123", timeout=5)
        assert result is True

    def test_client_error_raises(self):
        manager, mock_cfn = _make_manager()
        manager.aws = MagicMock()
        manager.aws.handle_error.return_value = "Operation check failed"

        mock_cfn.describe_stack_set_operation.side_effect = ClientError(
            {"Error": {"Code": "InternalError", "Message": "fail"}},
            "DescribeStackSetOperation",
        )

        with patch("ai_org.core.stackset_manager.time") as mock_time:
            mock_time.time.side_effect = [0, 0]
            with pytest.raises(Exception, match="Operation check failed"):
                manager.wait_for_deployment_operation("org-test", "op-123", timeout=60)


@pytest.mark.unit
class TestCountStackInstances:
    """Test _count_stack_instances method."""

    def test_counts_instances(self):
        manager, mock_cfn = _make_manager()
        mock_paginator = MagicMock()
        mock_cfn.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {"Summaries": [{"Account": "111"}, {"Account": "222"}]},
            {"Summaries": [{"Account": "333"}]},
        ]

        result = manager._count_stack_instances("org-test")
        assert result == 3

    def test_returns_zero_on_error(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.get_paginator.side_effect = Exception("fail")

        result = manager._count_stack_instances("org-test")
        assert result == 0


@pytest.mark.unit
class TestGetTargetOUsNames:
    """Test _get_target_ous_names method."""

    def test_returns_friendly_names(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.list_stack_set_auto_deployment_targets.return_value = {
            "Summaries": [
                {"OrganizationalUnitId": "ou-xxxx-WORKLOADS"},
                {"OrganizationalUnitId": "ou-xxxx-SANDBOX"},
            ]
        }

        result = manager._get_target_ous_names("org-test")
        assert "Workloads" in result
        assert "Sandbox" in result

    def test_returns_empty_on_error(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.list_stack_set_auto_deployment_targets.side_effect = Exception("fail")

        result = manager._get_target_ous_names("org-test")
        assert result == ""

    def test_returns_empty_when_no_targets(self):
        manager, mock_cfn = _make_manager()
        mock_cfn.list_stack_set_auto_deployment_targets.return_value = {"Summaries": []}

        result = manager._get_target_ous_names("org-test")
        assert result == ""
