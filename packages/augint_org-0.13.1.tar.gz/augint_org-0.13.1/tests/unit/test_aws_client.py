"""Unit tests for the AWSClient class."""

from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError, ProfileNotFound

from ai_org.core.aws_client import AWSClient


@pytest.mark.unit
class TestAWSClientInit:
    def test_defaults(self):
        client = AWSClient()
        assert client.profile == "org"
        assert client.region == "us-east-1"

    def test_custom_values(self):
        client = AWSClient(profile="custom", region="eu-west-1")
        assert client.profile == "custom"
        assert client.region == "eu-west-1"


@pytest.mark.unit
class TestAWSClientSession:
    def test_session_creation(self):
        client = AWSClient(profile="test", region="us-east-1")
        with patch("ai_org.core.aws_client.boto3.Session") as mock_session:
            mock_instance = MagicMock()
            mock_session.return_value = mock_instance

            session = client.session
            mock_session.assert_called_once_with(profile_name="test", region_name="us-east-1")
            assert session == mock_instance

    def test_session_cached(self):
        client = AWSClient()
        with patch("ai_org.core.aws_client.boto3.Session") as mock_session:
            mock_instance = MagicMock()
            mock_session.return_value = mock_instance

            s1 = client.session
            s2 = client.session
            assert s1 is s2
            assert mock_session.call_count == 1

    def test_session_fallback_on_profile_not_found(self):
        client = AWSClient(profile="nonexistent")
        with patch("ai_org.core.aws_client.boto3.Session") as mock_session:
            mock_session.side_effect = [
                ProfileNotFound(profile="nonexistent"),
                MagicMock(),
            ]

            session = client.session
            assert session is not None
            assert mock_session.call_count == 2


@pytest.mark.unit
class TestAWSClientMethods:
    def test_client_method(self):
        aws = AWSClient()
        with patch("ai_org.core.aws_client.boto3.Session") as mock_session:
            mock_instance = MagicMock()
            mock_session.return_value = mock_instance
            mock_service_client = MagicMock()
            mock_instance.client.return_value = mock_service_client

            result = aws.client("organizations")
            mock_instance.client.assert_called_once_with("organizations")
            assert result == mock_service_client

    def test_get_caller_identity(self):
        aws = AWSClient()
        with patch("ai_org.core.aws_client.boto3.Session") as mock_session:
            mock_instance = MagicMock()
            mock_session.return_value = mock_instance
            mock_sts = MagicMock()
            mock_instance.client.return_value = mock_sts
            mock_sts.get_caller_identity.return_value = {
                "Account": "123456789012",
                "UserId": "AIDEXAMPLE",
                "Arn": "arn:aws:iam::123456789012:user/test",
            }

            result = aws.get_caller_identity()
            assert result["Account"] == "123456789012"

    def test_get_account_id(self):
        aws = AWSClient()
        with patch.object(aws, "get_caller_identity") as mock_identity:
            mock_identity.return_value = {"Account": "123456789012"}
            assert aws.get_account_id() == "123456789012"

    def test_account_id_property(self):
        aws = AWSClient()
        with patch.object(aws, "get_account_id") as mock_get:
            mock_get.return_value = "123456789012"
            assert aws.account_id == "123456789012"

    def test_get_region(self):
        aws = AWSClient(region="us-west-2")
        with patch("ai_org.core.aws_client.boto3.Session") as mock_session:
            mock_instance = MagicMock()
            mock_session.return_value = mock_instance
            mock_instance.region_name = "us-west-2"

            assert aws.get_region() == "us-west-2"

    def test_get_region_fallback(self):
        aws = AWSClient(region="eu-west-1")
        with patch("ai_org.core.aws_client.boto3.Session") as mock_session:
            mock_instance = MagicMock()
            mock_session.return_value = mock_instance
            mock_instance.region_name = None

            assert aws.get_region() == "eu-west-1"


@pytest.mark.unit
class TestAWSClientPaginate:
    def test_paginate(self):
        aws = AWSClient()
        mock_client = MagicMock()
        mock_paginator = MagicMock()
        mock_client.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {"Accounts": [{"Id": "111"}, {"Id": "222"}]},
            {"Accounts": [{"Id": "333"}]},
        ]

        results = aws.paginate(mock_client, "list_accounts")
        assert len(results) == 3
        assert results[0]["Id"] == "111"


@pytest.mark.unit
class TestAWSClientHandleError:
    def test_access_denied(self):
        aws = AWSClient()
        error = ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "Access denied"}},
            "SomeOperation",
        )
        result = aws.handle_error(error, "Default message")
        assert "Access denied" in result

    def test_resource_not_found(self):
        aws = AWSClient()
        error = ClientError(
            {"Error": {"Code": "ResourceNotFoundException", "Message": "Not found"}},
            "SomeOperation",
        )
        result = aws.handle_error(error, "Default message")
        assert "Resource not found" in result

    def test_validation_exception(self):
        aws = AWSClient()
        error = ClientError(
            {"Error": {"Code": "ValidationException", "Message": "Invalid input"}},
            "SomeOperation",
        )
        result = aws.handle_error(error, "Default message")
        assert "Validation failed" in result

    def test_unknown_error_uses_default(self):
        aws = AWSClient()
        error = ClientError(
            {"Error": {"Code": "UnknownCode", "Message": "Something happened"}},
            "SomeOperation",
        )
        result = aws.handle_error(error, "My default message")
        assert "My default message" in result
