"""Data models for Heiman Connect library."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional


@dataclass
class HeimanUser:
    """Heiman user model."""

    user_id: str
    email: str
    nickname: Optional[str] = None
    phone: Optional[str] = None
    avatar: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    raw_data: dict[str, Any] = field(default_factory=dict)

    def get_display_name(self) -> str | None:
        """Get user display name (prefer nickname, fallback to email).

        Returns:
            The user's nickname if available, otherwise their email address.
        """
        return self.nickname or self.email


@dataclass
class HeimanHome:
    """Heiman home model."""

    home_id: str
    home_name: str
    user_id: str
    room_count: int = 0
    device_count: int = 0
    cover_url: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    raw_data: dict[str, Any] = field(default_factory=dict)


@dataclass
class DeviceProperty:
    """Device property model."""

    identifier: str
    name: str
    value: Any = None
    unit: Optional[str] = None
    data_type: Optional[str] = None
    readable: bool = True
    writable: bool = False
    description: Optional[str] = None
    entity: Optional[str] = None

    @staticmethod
    def infer_entity_type(prop_value: Any) -> str | None:
        """Infer the appropriate entity type from a property value.

        Args:
            prop_value: The property value to analyze.

        Returns:
            The entity type string (e.g., "sensor"), or None when the value
            cannot be represented by a supported inferred platform.
        """
        if isinstance(prop_value, bool):
            # Do not infer boolean properties as sensors because the sensor
            # platform rejects bool native values. Once a binary_sensor
            # platform is added, this should return "binary_sensor".
            return None
        if isinstance(prop_value, (int, float)):
            # Numeric values are typically sensors.
            return "sensor"
        if isinstance(prop_value, str):
            # String values are valid sensor native values.
            return "sensor"
        if isinstance(prop_value, (dict, list, tuple, set)):
            # Non-scalar values cannot be represented as sensor native values.
            return None
        # Keep other scalar-like values discoverable.
        return "sensor"

    @staticmethod
    def validate_sensor_value(value: Any) -> str | int | float | None:
        """Validate and return a Home Assistant-compatible sensor value.

        Home Assistant sensor platforms only support str, int, float, or None
        as native values. This method filters out unsupported types like bool,
        dict, list, etc.

        Args:
            value: The property value to validate.

        Returns:
            The value if it's a supported sensor type, otherwise None.

        Example:
            >>> DeviceProperty.validate_sensor_value(25.5)
            25.5
            >>> DeviceProperty.validate_sensor_value(True)
            None
            >>> DeviceProperty.validate_sensor_value({"key": "value"})
            None
        """
        if value is None:
            return None
        # Bool must be checked before int because bool is a subclass of int
        if isinstance(value, bool):
            return None
        if isinstance(value, (str, int, float)):
            return value
        # Filter out unsupported types (dict, list, tuple, set, etc.)
        return None


@dataclass
class HeimanDevice:
    """Heiman device model."""

    device_id: str
    device_name: str
    product_id: str
    home_id: str
    room_id: Optional[str] = None
    device_type: Optional[str] = None
    model: Optional[str] = None
    manufacturer: str = "Heiman"
    firmware_version: Optional[str] = None
    hardware_version: Optional[str] = None
    serial_number: Optional[str] = None
    mac_address: Optional[str] = None
    ip_address: Optional[str] = None
    online: bool = False
    properties: dict[str, DeviceProperty] = field(default_factory=dict)
    capabilities: list[str] = field(default_factory=list)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    raw_data: dict[str, Any] = field(default_factory=dict)

    @property
    def device_info(self) -> dict[str, Any]:
        """Get device information for Home Assistant device registry."""
        return {
            "identifiers": {(DOMAIN, self.device_id)},
            "name": self.device_name,
            "manufacturer": self.manufacturer,
            "model": self.model or self.product_id,
            "sw_version": self.firmware_version,
            "hw_version": self.hardware_version,
            "serial_number": self.serial_number,
        }

    def update_property(self, identifier: str, value: Any) -> None:
        """Update device property value.

        Args:
            identifier: Property identifier
            value: New property value
        """
        if identifier in self.properties:
            self.properties[identifier].value = value
        else:
            self.properties[identifier] = DeviceProperty(
                identifier=identifier,
                name=identifier,
                value=value,
            )
        self.updated_at = datetime.now()

    def merge_from(self, other_device: "HeimanDevice") -> None:
        """Merge properties and state from another device instance.

        This method preserves existing property values when the new device
        has None values, ensuring that runtime-discovered properties (e.g.,
        from MQTT) are not lost during polling updates.

        Args:
            other_device: The old device instance to merge from
        """
        # Merge properties: preserve old values only when new values are None
        for prop_id, old_prop in other_device.properties.items():
            if prop_id not in self.properties:
                # Keep runtime-discovered properties (e.g. MQTT-only fields)
                # when they are not present in the next poll response.
                self.properties[prop_id] = old_prop
                continue

            # Only copy old value if new value is None
            if (
                self.properties[prop_id].value is None
                and old_prop.value is not None
            ):
                self.properties[prop_id].value = old_prop.value

        # Copy online status only when the new status is unknown
        if self.online is None and other_device.online is not None:
            self.online = other_device.online


# Import DOMAIN from const to avoid circular import
# This will be set by the main integration
DOMAIN = "heiman_home"
