"""Heiman Connect - Core library for Heiman Home Assistant integration.

This module provides the core functionality for communicating with Heiman devices
via HTTP API and MQTT protocol.
"""

from .cloud_client_wrapper import HeimanCloudClientWrapper
from .device_management import (
    AreaNameSyncManager,
    ChildDeviceManager,
    DeviceFilterManager,
    DeviceManagement,
)
from .exceptions import (
    HeimanApiError,
    HeimanAuthError,
    HeimanConnectionError,
    HeimanDeviceNotFoundError,
    HeimanException,
    HeimanInvalidCredentialsError,
    HeimanMQTTError,
    HeimanServerBusyError,
    HeimanTokenExpiredError,
)
from .http_client import HeimanCloudClient, HeimanHttpClient
from .models import (
    DeviceProperty,
    HeimanDevice,
    HeimanHome,
    HeimanUser,
)
from .mqtt_client import HeimanMqttClient
from .utils import (
    convert_dbm_to_level,
    extract_firmware_version,
    process_device_detail,
    process_device_info,
    update_device_property_from_metadata,
)

__version__ = "1.0.10"

__all__ = [
    # Version
    "__version__",
    # HTTP Client
    "HeimanHttpClient",
    "HeimanCloudClient",
    # Cloud Client Wrapper
    "HeimanCloudClientWrapper",
    # MQTT Client
    "HeimanMqttClient",
    # Models
    "HeimanDevice",
    "HeimanHome",
    "HeimanUser",
    "DeviceProperty",
    # Device Management
    "DeviceManagement",
    "DeviceFilterManager",
    "AreaNameSyncManager",
    "ChildDeviceManager",
    # Utilities
    "convert_dbm_to_level",
    "extract_firmware_version",
    "process_device_detail",
    "process_device_info",
    "update_device_property_from_metadata",
    # Exceptions
    "HeimanException",
    "HeimanAuthError",
    "HeimanConnectionError",
    "HeimanApiError",
    "HeimanMQTTError",
    "HeimanServerBusyError",
    "HeimanTokenExpiredError",
    "HeimanInvalidCredentialsError",
    "HeimanDeviceNotFoundError",
]
