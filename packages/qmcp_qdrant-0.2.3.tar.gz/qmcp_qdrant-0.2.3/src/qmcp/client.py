# Copyright 2024 Artur
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Qdrant client wrapper for qmcp."""

from typing import Any

from qdrant_client import QdrantClient, models

from .config import get_settings
from .logging_config import get_logger


class QdrantConnectionError(Exception):
    """Raised when connection to Qdrant fails."""

    pass


class QdrantClientWrapper:
    """Async wrapper for Qdrant client with convenience methods."""

    def __init__(self, url: str | None = None, api_key: str | None = None):
        """Initialize Qdrant client.

        Args:
            url: Qdrant URL (default from settings)
            api_key: Qdrant API key (optional, from settings)
        """
        settings = get_settings()
        self.logger = get_logger(f"{__name__}.QdrantClientWrapper")

        self.url = url or settings.qdrant_url
        self.api_key = api_key or settings.qdrant_api_key
        self._client: QdrantClient | None = None
        self._embedding_model = settings.embedding_model
        self._embedding_cache_dir = settings.embedding_cache_dir
        self._embedding_model_instance: Any = None

    def connect(self) -> None:
        """Establish connection to Qdrant."""
        self.logger.info(f"Connecting to Qdrant at {self.url}")
        try:
            self._client = QdrantClient(
                url=self.url,
                api_key=self.api_key,
                timeout=30,
            )
            # Test connection
            self._client.get_collections()
            self.logger.info("Successfully connected to Qdrant")
            # Validate embedding model is available
            self._load_embedding_model()
        except Exception as e:
            self.logger.error(f"Failed to connect to Qdrant: {e}")
            raise QdrantConnectionError(f"Failed to connect to Qdrant at {self.url}: {e}")

    def _load_embedding_model(self) -> None:
        """Load and cache the embedding model.

        Downloads the model if not cached, then validates it works.
        This method ensures the model is available before any indexing operations.
        """
        from fastembed import TextEmbedding

        # If model already loaded and cached, verify it's still valid
        if self._embedding_model_instance is not None:
            try:
                # Quick verification that model still works
                list(self._embedding_model_instance.query_embed("test"))
                self.logger.debug("Embedding model instance verified")
                return
            except Exception:
                # Model instance corrupted, reload
                self.logger.warning("Embedding model instance corrupted, reloading...")
                self._embedding_model_instance = None

        self.logger.info(
            f"Loading embedding model: {self._embedding_model}"
            + (f" (cache: {self._embedding_cache_dir})" if self._embedding_cache_dir else "")
        )

        try:
            # Initialize model with custom cache directory if specified
            init_kwargs: dict[str, Any] = {"model_name": self._embedding_model}
            if self._embedding_cache_dir:
                init_kwargs["cache_dir"] = self._embedding_cache_dir
                self.logger.info(f"Using custom model cache directory: {self._embedding_cache_dir}")

            self._embedding_model_instance = TextEmbedding(**init_kwargs)

            # Validate model works with a test encode
            test_result = list(self._embedding_model_instance.query_embed("validation_test"))
            if not test_result or len(test_result[0]) == 0:
                raise QdrantConnectionError(
                    f"Embedding model '{self._embedding_model}' returned empty vectors. "
                    f"Model may be corrupted or incompatible."
                )

            self.logger.info(
                f"Embedding model loaded successfully. Vector dimension: {len(test_result[0])}"
            )

        except ImportError:
            raise QdrantConnectionError(
                "fastembed is not installed. Install it with: pip install qdrant-client[fastembed]"
            )
        except OSError as e:
            # Network errors when trying to download model
            if "Could not download" in str(e) or "connection" in str(e).lower():
                cache_info = (
                    f" at '{self._embedding_cache_dir}'"
                    if self._embedding_cache_dir
                    else " (default location)"
                )
                raise QdrantConnectionError(
                    f"Failed to download embedding model '{self._embedding_model}'"
                    f"{cache_info}. Network error: {e}. "
                    f"Please check your internet connection and try again."
                )
            raise QdrantConnectionError(
                f"Failed to load embedding model '{self._embedding_model}': {e}"
            )
        except Exception as e:
            cache_info = (
                f" from cache '{self._embedding_cache_dir}'" if self._embedding_cache_dir else ""
            )
            raise QdrantConnectionError(
                f"Failed to load embedding model '{self._embedding_model}'{cache_info}: {e}. "
                f"The model may need to be re-downloaded."
            )

    @property
    def client(self) -> QdrantClient:
        """Get Qdrant client instance."""
        if self._client is None:
            self.connect()
        return self._client  # type: ignore

    @property
    def is_connected(self) -> bool:
        """Check if connected to Qdrant."""
        try:
            self._client.get_collections()
            return True
        except Exception:
            return False

    def get_collections(self) -> list[str]:
        """Get list of collection names."""
        result = self.client.get_collections()
        return [col.name for col in result.collections]

    def create_collection(
        self,
        name: str,
        vector_size: int | None = None,
        distance: models.Distance = models.Distance.COSINE,
    ) -> None:
        """Create a collection if it doesn't exist.

        Args:
            name: Collection name
            vector_size: Vector size (auto-detected from model if not provided)
            distance: Distance metric
        """
        if vector_size is None:
            vector_size = self.client.get_embedding_size(self._embedding_model)

        self.client.create_collection(
            collection_name=name,
            vectors_config=models.VectorParams(
                size=vector_size,
                distance=distance,
            ),
        )

    def delete_collection(self, name: str) -> None:
        """Delete a collection."""
        self.client.delete_collection(collection_name=name)

    def collection_exists(self, name: str) -> bool:
        """Check if collection exists."""
        return name in self.get_collections()

    def get_collection_info(self, name: str) -> dict[str, Any]:
        """Get collection information."""
        info = self.client.get_collection(collection_name=name)
        return {
            "name": name,
            "points_count": info.points_count,
            "indexed_vectors_count": info.indexed_vectors_count,
            "status": info.status.name,
            "vector_size": info.config.params.size if info.config and info.config.params else 0,
        }

    def validate_collection_vectors(self, name: str) -> dict[str, Any]:
        """Validate that collection vectors have proper dimensions.

        Returns diagnostic info about the collection vector health.
        """
        info = self.client.get_collection(collection_name=name)
        vector_size = info.config.params.size if info.config and info.config.params else 0

        return {
            "collection": name,
            "points_count": info.points_count,
            "vector_size": vector_size,
            "is_valid": vector_size > 0,
            "warning": (
                f"Vectors have zero dimensions! "
                f"This usually means fastembed failed during indexing. "
                f"Run: qdrant_reindex(collection='{name}', path='/path/to/project', mode='full')"
            )
            if vector_size == 0
            else None,
        }

    def search(
        self,
        collection: str,
        query: str,
        limit: int = 5,
        score_threshold: float = 0.7,
        chunk_type: str | None = None,
        symbol_name: str | None = None,
        language: str | None = None,
        file_path_pattern: str | None = None,
    ) -> list[dict[str, Any]]:
        """Search for similar vectors with optional structured filters.

        Args:
            collection: Collection name
            query: Query text
            limit: Max results
            score_threshold: Minimum score
            chunk_type: Filter by chunk type (e.g., "function_def", "class_def")
            symbol_name: Filter by exact symbol name match
            language: Filter by programming language (e.g., "python", "go")
            file_path_pattern: Filter by file path glob pattern (e.g., "*.py")

        Returns:
            List of search results with payload
        """
        # Build filter conditions
        filter_conditions = []

        if chunk_type:
            filter_conditions.append(
                models.FieldCondition(
                    key="type",
                    match=models.MatchValue(value=chunk_type),
                )
            )

        if symbol_name:
            filter_conditions.append(
                models.FieldCondition(
                    key="symbol_names",
                    match=models.MatchAny(any=[symbol_name]),
                )
            )

        if language:
            filter_conditions.append(
                models.FieldCondition(
                    key="language",
                    match=models.MatchValue(value=language),
                )
            )

        if file_path_pattern:
            # Convert glob pattern to Qdrant match
            filter_conditions.append(
                models.FieldCondition(
                    key="file_path",
                    match=models.MatchText(text=file_path_pattern),
                )
            )

        # Build query filter
        query_filter = None
        if filter_conditions:
            query_filter = models.Filter(must=filter_conditions)

        # Generate query embedding using cached model
        if self._embedding_model_instance is None:
            self._load_embedding_model()

        query_vectors = list(self._embedding_model_instance.query_embed(query))
        if not query_vectors or len(query_vectors[0]) == 0:
            self.logger.error("Query embedding returned empty vector")
            return []

        results = self.client.query_points(
            collection_name=collection,
            query=query_vectors[0],  # Use pre-generated vector
            limit=limit,
            score_threshold=score_threshold,
            query_filter=query_filter,
            with_payload=True,
        )

        return [
            {
                "score": hit.score,
                "file_path": hit.payload.get("file_path", ""),
                "content": hit.payload.get("content", ""),
                "type": hit.payload.get("type", "unknown"),
                "line_start": hit.payload.get("line_start"),
                "line_end": hit.payload.get("line_end"),
                # Extended metadata
                "signature": hit.payload.get("signature"),
                "symbol_names": hit.payload.get("symbol_names", []),
                "imports": hit.payload.get("imports", []),
                "language": hit.payload.get("language", "unknown"),
            }
            for hit in results.points
        ]

    def upsert(
        self,
        collection: str,
        points: list[dict[str, Any]],
        batch_size: int = 50,
    ) -> int:
        """Upsert points into collection.

        Args:
            collection: Collection name
            points: List of points to insert
            batch_size: Batch size for insertion

        Returns:
            Number of points inserted
        """
        from qdrant_client.models import PointStruct

        # Ensure embedding model is loaded
        if self._embedding_model_instance is None:
            self._load_embedding_model()

        # Generate embeddings for all points
        contents = [point["content"] for point in points]
        all_embeddings = list(self._embedding_model_instance.passage_embed(contents))

        structured_points = []
        for i, point in enumerate(points):
            embedding = all_embeddings[i]
            if len(embedding) == 0:
                self.logger.warning(f"Empty embedding for point {point['id']}, skipping")
                continue

            structured_points.append(
                PointStruct(
                    id=point["id"],
                    vector=embedding,
                    payload=point["payload"],
                )
            )

        # Insert in batches
        total = 0
        for i in range(0, len(structured_points), batch_size):
            batch = structured_points[i : i + batch_size]
            self.client.upsert(collection_name=collection, points=batch)
            total += len(batch)

        return total

    def delete_points(self, collection: str, point_ids: list[str]) -> None:
        """Delete points by IDs."""
        self.client.delete(
            collection_name=collection,
            points_selector=models.PointIdsList(points=point_ids),
        )

    def scroll(
        self,
        collection: str,
        limit: int = 100,
        offset: str | None = None,
    ) -> tuple[list[dict[str, Any]], str | None]:
        """Scroll through collection points.

        Returns:
            Tuple of (points, next_offset)
        """
        results, next_offset = self.client.scroll(
            collection_name=collection,
            limit=limit,
            offset=offset,
            with_payload=True,
        )

        points = [
            {
                "id": str(hit.id),
                "payload": hit.payload,
            }
            for hit in results
        ]

        return points, next_offset

    def get_all_points(self, collection: str) -> list[dict[str, Any]]:
        """Get all points from collection."""
        all_points = []
        offset = None

        while True:
            points, offset = self.scroll(collection, limit=1000, offset=offset)
            all_points.extend(points)
            if offset is None:
                break

        return all_points
