"use strict";(globalThis.rspackChunkesphome_frontend=globalThis.rspackChunkesphome_frontend||[]).push([[493],{4148(e,a,t){t.r(a),t.d(a,{ESPHomePageSecrets:()=>v});var o=t(5172),r=t(9165),i=t(2009),s=t(3442),l=t(261),n=t(1556),c=t(3140),d=t(1093);function p(e,a,t,o){var r,i=arguments.length,s=i<3?a:null===o?o=Object.getOwnPropertyDescriptor(a,t):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,a,t,o);else for(var l=e.length-1;l>=0;l--)(r=e[l])&&(s=(i<3?r(s):i>3?r(a,t,s):r(a,t))||s);return i>3&&s&&Object.defineProperty(a,t,s),s}t(3238),t(1062),t(2202),t(6117),t(2910),(0,d.C)({"arrow-left":r.mdiArrowLeft,"content-save":r.mdiContentSave});let h="secrets.yaml";class v extends i.WF{async connectedCallback(){super.connectedCallback();try{let e=await this._api.getConfig(h);this._yaml=e,this._savedYaml=e}catch{let e=this._localize("secrets.file_header");this._yaml=e,this._savedYaml=e}this._loaded=!0}render(){return(0,i.qy)`
      <div class="page">
        <div class="page-header">
          <div class="back" @click=${this._goBack} title=${this._localize("layout.back")}>
            <wa-icon library="mdi" name="arrow-left"></wa-icon>
          </div>
          <div class="page-title">
            <h1>${this._localize("secrets.title")}</h1>
            <p>${this._localize("secrets.desc")}</p>
          </div>
        </div>
        <wa-divider></wa-divider>
        <div class="editor-card">
          <button
            type="button"
            class="save-button"
            ?disabled=${this._saving||!this._loaded||this._yaml===this._savedYaml}
            @click=${this._save}
          >
            <wa-icon library="mdi" name="content-save"></wa-icon>
            ${this._saving?this._localize("secrets.saving"):this._localize("secrets.save")}
          </button>
          <esphome-yaml-editor
            .value=${this._yaml}
            @yaml-change=${e=>{this._yaml=e.detail.value}}
          ></esphome-yaml-editor>
        </div>
      </div>
    `}_goBack(){window.history.back()}_save(){this._savedYaml=this._yaml,l.A.success(this._localize("secrets.saved"),{richColors:!0}),this._api.updateConfig(h,this._yaml).catch(e=>{(e instanceof Error?e.message:"").includes("timed out")||l.A.error(this._localize("secrets.save_error"),{richColors:!0})})}constructor(...e){super(...e),this._localize=e=>e,this._yaml="",this._savedYaml="",this._saving=!1,this._loaded=!1}}v.styles=[c.G,(0,i.AH)`
      :host {
        display: flex;
        flex-direction: column;
        height: calc(100vh - var(--esphome-header-height));
        box-sizing: border-box;
      }

      .page {
        flex: 1;
        display: flex;
        flex-direction: column;
        padding: var(--wa-space-l);
        gap: var(--wa-space-m);
        overflow: hidden;
      }

      .page-header {
        display: flex;
        align-items: center;
        gap: var(--wa-space-m);
        flex-shrink: 0;
      }

      .page-title {
        flex: 1;
      }

      .page-title h1 {
        margin: 0 0 2px;
        font-size: var(--wa-font-size-l);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      .page-title p {
        margin: 0;
        font-size: var(--wa-font-size-s);
        color: var(--wa-color-text-quiet);
      }

      .editor-card {
        flex: 1;
        position: relative;
        background: var(--wa-color-surface-default);
        border-radius: var(--wa-border-radius-l);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        box-shadow: var(--wa-elevation-02);
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }

      .save-button {
        position: absolute;
        bottom: var(--wa-space-m);
        right: var(--wa-space-m);
        z-index: 10;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border: none;
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        padding: 8px 16px;
        border-radius: var(--wa-border-radius-m);
        cursor: pointer;
        font-size: var(--wa-font-size-xs);
        font-weight: var(--wa-font-weight-bold);
        font-family: inherit;
        box-shadow: 0 2px 8px color-mix(in srgb, var(--esphome-primary), transparent 50%);
        transition: background 0.12s, box-shadow 0.12s, transform 0.12s;
      }

      .save-button:hover:not(:disabled) {
        background: color-mix(in srgb, var(--esphome-primary), black 10%);
        box-shadow: 0 4px 14px color-mix(in srgb, var(--esphome-primary), transparent 35%);
        transform: translateY(-1px);
      }

      .save-button:active:not(:disabled) {
        transform: translateY(0);
      }

      .save-button:disabled {
        opacity: 0.4;
        cursor: not-allowed;
        box-shadow: none;
      }

      .save-button wa-icon {
        font-size: 16px;
      }

      .back {
        cursor: pointer;
      }

      .back wa-icon {
        font-size: var(--wa-font-size-l);
        color: var(--esphome-primary);
      }
    `],p([(0,o.Fg)({context:n.$F,subscribe:!0}),(0,s.wk)()],v.prototype,"_localize",void 0),p([(0,o.Fg)({context:n.Ie})],v.prototype,"_api",void 0),p([(0,s.wk)()],v.prototype,"_yaml",void 0),p([(0,s.wk)()],v.prototype,"_savedYaml",void 0),p([(0,s.wk)()],v.prototype,"_saving",void 0),p([(0,s.wk)()],v.prototype,"_loaded",void 0),v=p([(0,s.EM)("esphome-page-secrets")],v)}}]);
//# sourceMappingURL=493.977c2f290ff4d281.js.map