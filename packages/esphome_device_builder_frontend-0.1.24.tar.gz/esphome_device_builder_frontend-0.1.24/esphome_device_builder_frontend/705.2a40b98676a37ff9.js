"use strict";(globalThis.rspackChunkesphome_frontend=globalThis.rspackChunkesphome_frontend||[]).push([[705],{1424(e,t,i){i.r(t),i.d(t,{ESPHomePageDevice:()=>eY});var o=i(5172),a=i(9165),r=i(2009),n=i(3442),s=i(261),l=i(1248);class d{hostConnected(){}get deviceState(){return this._host.device?.state??l.gX.UNKNOWN}get deviceTargetPlatform(){return this._host.device?.target_platform??""}_openCommand(e,t,i){let o=this._host.commandDialog;o&&(o.configuration=e.configuration,o.name=e.friendly_name||e.name,o.open(t,i?{port:i}:void 0))}constructor(e){this.installMethodOpen=!1,this.onInstall=()=>{this._host.device&&(this.installMethodOpen=!0,this._host.requestUpdate())},this.onUpdate=()=>{let e=this._host.device;e&&this._openCommand(e,"install")},this.onInstallMethodClose=()=>{this.installMethodOpen=!1,this._host.requestUpdate()},this.onInstallMethodSelect=e=>{let t=this._host.device;if(this.installMethodOpen=!1,this._host.requestUpdate(),!t)return;let{method:i,port:o}=e.detail;"ota"===i?this._openCommand(t,"install","OTA"):"server-serial"===i?this._openCommand(t,"install",o):"web-serial"===i?this._host.firmwareDialog?.installWebSerial(t):"web-download"===i&&this._host.firmwareDialog?.installWebDownload(t)},this._host=e,e.addController(this)}}var c=i(1556),p=i(3140),h=i(3632),u=i(1529),m=i(1093);let g=(0,r.AH)`
  :host {
    display: block;
  }

  .page {
    box-sizing: border-box;
    padding: var(--wa-space-l);
    min-height: calc(100vh - var(--esphome-header-height));
  }

  .layout-grid {
    display: grid;
    grid-template-columns: minmax(230px, 1fr) minmax(0, 5fr);
    gap: var(--wa-space-l);
    height: calc(100vh - var(--esphome-header-height) - 2 * var(--wa-space-l));
    transition: grid-template-columns 0.25s ease;
  }

  .layout-grid.nav-collapsed {
    grid-template-columns: minmax(0, 5fr);
  }

  .layout-grid.nav-collapsed .desktop-nav {
    display: none;
  }

  .drawer,
  .drawer-backdrop {
    display: none;
  }

  .nav-toggle-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: none;
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 80%);
    color: var(--esphome-on-primary);
    cursor: pointer;
    padding: 4px;
    border-radius: var(--wa-border-radius-m);
    margin-right: var(--wa-space-xs);
  }

  .nav-toggle-btn wa-icon {
    font-size: 14px;
  }

  .nav-toggle-btn:hover {
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 70%);
  }

  @media (max-width: 900px) {
    /* Drop the page padding on mobile so the editor goes edge-to-edge.
       The card itself is already small at this width — wasting ~16px
       on each side to a frame just makes it harder to read; logs go
       full-screen the same way for the same reason.
       Each dvh line is paired with a vh fallback above it so
       pre-2022 browsers that don't recognise dvh still pick up the
       mobile sizing instead of dropping the declaration and falling
       through to the desktop rule (which had an extra
       2 * var(--wa-space-l) subtracted and would leave a gap). */
    .page {
      padding: 0;
      min-height: calc(100vh - var(--esphome-header-height));
      min-height: calc(100dvh - var(--esphome-header-height));
    }

    .layout-grid {
      grid-template-columns: 1fr;
      gap: 0;
      height: calc(100vh - var(--esphome-header-height));
      height: calc(100dvh - var(--esphome-header-height));
    }

    .desktop-nav {
      display: none !important;
    }

    .drawer-backdrop {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.4);
      z-index: 99;
    }

    .drawer-backdrop--open {
      display: block;
    }

    .drawer {
      display: block;
      position: fixed;
      top: 0;
      left: 0;
      bottom: 0;
      width: 300px;
      max-width: 85vw;
      z-index: 100;
      background: var(--wa-color-surface-default);
      box-shadow: var(--wa-shadow-l);
      overflow-y: auto;
      transform: translateX(-100%);
      transition: transform 0.25s ease;
      --navigator-border-radius: 0;
      --navigator-border: none;
    }

    .drawer--open {
      transform: translateX(0);
    }
  }
`;i(2202),i(5123);var f=i(9665);let v=(0,r.AH)`
  :host {
    display: contents;
  }

  /* Fullscreen mode covers the surrounding app shell (top bar,
     navigator, page padding). The card-header stays visible so the
     user keeps Save / layout / Collapse within reach — same shape as
     the logs dialog's expand mode. z-index sits above app chrome
     (which uses values up to ~50) but below modal dialogs (>=1000). */
  :host([fullscreen]) .card {
    position: fixed;
    inset: 0;
    z-index: 100;
    border: none;
    border-radius: 0;
    box-shadow: none;
  }

  .card {
    background: var(--wa-color-surface-default);
    border-radius: var(--wa-border-radius-l);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    box-shadow: var(--wa-elevation-02);
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
  }

  /* Navigator hidden + YAML-only layout = the title bar is the only
     non-editor chrome left on screen. Squeeze it so it gives the
     YAML editor back the vertical space the user already implicitly
     asked for by collapsing both panels. */
  .card-header--compact {
    padding: var(--wa-space-2xs) var(--wa-space-m);
  }

  .card-header--compact .editor-header-title {
    font-size: var(--wa-font-size-2xs);
  }

  .card-header--compact .layout-toggle wa-icon,
  .card-header--compact .diff-toggle wa-icon {
    font-size: 16px;
  }

  .editor-header-main {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
    flex: 1;
  }

  .editor-header-title {
    margin: 0;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .editor-floating-actions {
    position: absolute;
    bottom: var(--wa-space-m);
    right: var(--wa-space-m);
    z-index: 10;
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-s);
  }

  .save-button,
  .install-fab {
    display: inline-flex;
    align-items: center;
    box-sizing: border-box;
    gap: 3px;
    padding: 7px 14px;
    border: var(--wa-border-width-s) solid transparent;
    border-radius: var(--wa-border-radius-m);
    cursor: pointer;
    font-size: var(--wa-font-size-xs);
    font-weight: var(--wa-font-weight-bold);
    font-family: inherit;
    line-height: 1;
    transition:
      background 0.12s,
      border-color 0.12s,
      box-shadow 0.12s,
      transform 0.12s;
  }

  .save-button {
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
    box-shadow: 0 2px 8px color-mix(in srgb, var(--esphome-primary), transparent 50%);
  }

  .save-button:hover:not(:disabled) {
    background: color-mix(in srgb, var(--esphome-primary), black 10%);
    box-shadow: 0 4px 14px color-mix(in srgb, var(--esphome-primary), transparent 35%);
    transform: translateY(-1px);
  }

  .save-button:active:not(:disabled) {
    transform: translateY(0);
  }

  .save-button:disabled {
    opacity: 0.4;
    cursor: not-allowed;
    box-shadow: none;
    transform: none;
  }

  .install-fab {
    background: color-mix(in srgb, var(--esphome-primary), transparent 90%);
    color: var(--esphome-primary);
    border-color: color-mix(in srgb, var(--esphome-primary), transparent 70%);
  }

  .install-fab:hover:not(:disabled) {
    background: color-mix(in srgb, var(--esphome-primary), transparent 82%);
    border-color: var(--esphome-primary);
  }

  .install-fab:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }

  .save-button wa-icon,
  .install-fab wa-icon {
    font-size: 16px;
  }

  .header-actions {
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-s);
  }

  .diff-toggle {
    border: none;
    background: transparent;
    color: var(--esphome-on-primary);
    padding: 2px 4px;
    border-radius: 4px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .diff-toggle[aria-pressed="true"] {
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 85%);
  }

  .diff-toggle:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }

  .diff-toggle wa-icon {
    font-size: 18px;
  }

  .fullscreen-toggle {
    border: none;
    background: transparent;
    color: var(--esphome-on-primary);
    padding: 2px 4px;
    border-radius: 4px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .fullscreen-toggle wa-icon {
    font-size: 18px;
  }

  .fullscreen-toggle:hover {
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 85%);
  }

  .card-header--compact .fullscreen-toggle wa-icon {
    font-size: 16px;
  }

  .layout-toggle {
    display: inline-flex;
    align-items: center;
    gap: 2px;
  }

  .layout-toggle button {
    border: none;
    background: transparent;
    color: var(--esphome-on-primary);
    padding: 2px 4px;
    border-radius: 4px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .layout-toggle button[aria-pressed="true"] {
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 85%);
  }

  .layout-toggle button:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }

  .layout-toggle wa-icon {
    font-size: 18px;
  }

  .card-body {
    position: relative;
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .editor-layout {
    flex: 1;
    min-height: 0;
    display: grid;
    gap: 0;
  }

  .editor-layout--both {
    grid-template-columns: 1fr 1px 1fr;
  }

  .editor-layout--left {
    grid-template-columns: 1fr;
  }

  .editor-layout--right {
    grid-template-columns: 1fr;
  }

  .editor-pane {
    padding: var(--wa-space-m);
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-s);
    min-height: 0;
    overflow: hidden;
  }

  .editor-pane--left {
    overflow-y: auto;
  }

  .editor-pane-title {
    margin: 0;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
  }

  .editor-pane-body {
    flex: 1;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }

  .pane-divider {
    background: var(--wa-color-surface-border);
    width: 1px;
    align-self: stretch;
  }

  .editor-layout--left .editor-pane--right,
  .editor-layout--right .editor-pane--left {
    display: none;
  }

  @media (max-width: 900px) {
    .layout-toggle .split-btn {
      display: none;
    }

    /* Drop the card frame on mobile — the page wrapper already
       removes its padding so the editor occupies the full viewport.
       Border / border-radius / shadow at small widths just shave
       pixels off the editing area without adding any meaning. */
    .card {
      border: none;
      border-radius: 0;
      box-shadow: none;
    }
  }
`;function b(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}i(3238),i(2910);class w extends r.WF{render(){if(this._darkMode?this.setAttribute("dark",""):this.removeAttribute("dark"),this.oldValue===this.newValue)return(0,r.qy)`<div class="empty">${this._localize("device.diff_no_changes")}</div>`;let e=function(e,t){let i=e.split("\n"),o=t.split("\n"),a=i.length,r=o.length,n=[];for(let e=0;e<=a;e++)n.push(new Uint32Array(r+1));for(let e=1;e<=a;e++)for(let t=1;t<=r;t++)n[e][t]=i[e-1]===o[t-1]?n[e-1][t-1]+1:Math.max(n[e-1][t],n[e][t-1]);let s=[],l=a,d=r;for(;l>0||d>0;)l>0&&d>0&&i[l-1]===o[d-1]?(s.push({type:"context",oldLine:l,newLine:d,content:i[l-1]}),l--,d--):d>0&&(0===l||n[l][d-1]>=n[l-1][d])?(s.push({type:"add",newLine:d,content:o[d-1]}),d--):(s.push({type:"remove",oldLine:l,content:i[l-1]}),l--);return s.reverse()}(this.oldValue,this.newValue);return(0,r.qy)`
      <table>
        <tbody>
          ${e.map(e=>this._renderLine(e))}
        </tbody>
      </table>
    `}_renderLine(e){let t="add"===e.type?"+":"remove"===e.type?"-":" ",i="remove"===e.type?e.oldLine:e.newLine;return(0,r.qy)`
      <tr class=${e.type}>
        <td class="gutter">${i??(0,r.qy)`&nbsp;`}</td>
        <td class="marker">${t}</td>
        <td class="content">${e.content||r.s6}</td>
      </tr>
    `}constructor(...e){super(...e),this._darkMode=!1,this._localize=e=>e,this.oldValue="",this.newValue=""}}w.styles=(0,r.AH)`
    :host {
      display: block;
      flex: 1;
      min-height: 0;
      position: relative;
      overflow: auto;
      font-family: "JetBrains Mono", "Fira Code", monospace;
      font-size: 13px;
      line-height: 1.5;
      background: var(--diff-bg);
      color: var(--diff-fg);
      --diff-bg: #ffffff;
      --diff-fg: #1f2328;
      --diff-gutter-bg: #f6f8fa;
      --diff-gutter-fg: #6e7781;
      --diff-add-bg: #e6ffec;
      --diff-add-marker-bg: #abf2bc;
      --diff-add-fg: #1a7f37;
      --diff-remove-bg: #ffebe9;
      --diff-remove-marker-bg: #ffcecb;
      --diff-remove-fg: #cf222e;
      --diff-empty-fg: #8c959f;
    }

    :host([dark]) {
      --diff-bg: #0d1117;
      --diff-fg: #e6edf3;
      --diff-gutter-bg: #161b22;
      --diff-gutter-fg: #7d8590;
      --diff-add-bg: #033a16;
      --diff-add-marker-bg: #1a7f37;
      --diff-add-fg: #aff5b4;
      --diff-remove-bg: #67060c;
      --diff-remove-marker-bg: #b62324;
      --diff-remove-fg: #ffcecb;
      --diff-empty-fg: #6e7681;
    }

    .empty {
      padding: var(--wa-space-l);
      text-align: center;
      color: var(--diff-empty-fg);
      font-family: var(--wa-font-family-body);
      font-size: var(--wa-font-size-s);
    }

    table {
      border-collapse: collapse;
      width: 100%;
      table-layout: fixed;
    }

    tr {
      vertical-align: top;
    }

    .gutter {
      width: 1em;
      padding: 0 8px;
      padding-right: 14px;
      text-align: right;
      background: var(--diff-gutter-bg);
      color: var(--diff-gutter-fg);
      user-select: none;
      white-space: nowrap;
    }

    .marker {
      width: 1.5em;
      padding: 0 6px;
      text-align: center;
      user-select: none;
      font-weight: 600;
      border-right: 1px solid color-mix(in srgb, var(--diff-fg), transparent 90%);
    }

    .content {
      padding: 0 8px;
      white-space: pre-wrap;
      word-break: break-word;
      overflow-wrap: anywhere;
    }

    tr.add .marker,
    tr.add .content {
      background: var(--diff-add-bg);
      color: var(--diff-add-fg);
    }

    tr.add .marker {
      background: var(--diff-add-marker-bg);
    }

    tr.remove .marker,
    tr.remove .content {
      background: var(--diff-remove-bg);
      color: var(--diff-remove-fg);
    }

    tr.remove .marker {
      background: var(--diff-remove-marker-bg);
    }
  `,b([(0,o.Fg)({context:c.B6,subscribe:!0}),(0,n.wk)()],w.prototype,"_darkMode",void 0),b([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],w.prototype,"_localize",void 0),b([(0,n.MZ)()],w.prototype,"oldValue",void 0),b([(0,n.MZ)()],w.prototype,"newValue",void 0),w=b([(0,n.EM)("esphome-yaml-diff")],w);var y=i(6910);i(4636),i(7473);var _=i(5660);function x(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}i(3272),i(6117),(0,m.C)({close:a.mdiClose,"lightning-bolt":a.mdiLightningBolt,"target-variant":a.mdiTargetVariant,"play-circle-outline":a.mdiPlayCircleOutline});class $ extends r.WF{open(){this._targetName="",this._triggerId="",this._actionId="",this._actionFields={},this._error="",this._dialog.open=!0,0===this._triggers.length&&this._loadCatalog()}async _loadCatalog(){this._loading=!0;try{this._triggers=[{id:"on_value",name:"On Value",description:"Triggered when the value changes",applicable_to:[],fields:[]},{id:"on_press",name:"On Press",description:"Triggered when a button is pressed",applicable_to:[],fields:[]},{id:"on_turn_on",name:"On Turn On",description:"Triggered when the component turns on",applicable_to:[],fields:[]},{id:"on_turn_off",name:"On Turn Off",description:"Triggered when the component turns off",applicable_to:[],fields:[]},{id:"on_boot",name:"On Boot",description:"Triggered when the device boots up",applicable_to:[],fields:[]},{id:"on_time",name:"On Time",description:"Triggered at a specific time interval",applicable_to:[],fields:[]}],this._actions=[{id:"toggle",name:"Toggle",description:"Toggle the component state",fields:[]},{id:"turn_on",name:"Turn On",description:"Turn the component on",fields:[]},{id:"turn_off",name:"Turn Off",description:"Turn the component off",fields:[]},{id:"logger.log",name:"Log Message",description:"Log a message to the console",fields:[{key:"message",label:"Message",type:"string",required:!0,default_value:"",hidden:!1,description:"",options:null,allow_custom_value:!1,range:null,unit_options:null,help_link:null,multi_value:!1,templatable:!1,locked:!1,suggestions:null,depends_on:null,depends_on_value:null,depends_on_value_not:null,depends_on_component:null,references_component:null,pin_features:[],pin_mode:null,advanced:!1,translation_key:null,translation_params:null,config_entries:null,platform_type:null}]},{id:"delay",name:"Delay",description:"Wait for a specified duration",fields:[{key:"delay",label:"Duration (ms)",type:"integer",required:!0,default_value:"1000",hidden:!1,description:"",options:null,allow_custom_value:!1,range:null,unit_options:null,help_link:null,multi_value:!1,templatable:!1,locked:!1,suggestions:null,depends_on:null,depends_on_value:null,depends_on_value_not:null,depends_on_component:null,references_component:null,pin_features:[],pin_mode:null,advanced:!1,translation_key:null,translation_params:null,config_entries:null,platform_type:null}]}],this._triggerId=this._triggers[0].id,this._actionId=this._actions[0].id}catch(e){console.error("Failed to load automation catalog:",e)}finally{this._loading=!1}}render(){return(0,r.qy)`
      <wa-dialog
        light-dismiss
        label=${this.boardName?this._localize("device.add_automation_dialog_title",{name:this.boardName}):this._localize("device.add_automation")}
      >
        ${this._loading?(0,r.qy)`
              <div class="loading">
                <wa-spinner></wa-spinner>
                ${this._localize("device.loading_automation_catalog")}
              </div>
            `:this._renderForm()}
      </wa-dialog>
    `}_renderForm(){let e=this._actions.find(e=>e.id===this._actionId),t=this._submitting;return(0,r.qy)`
      <div class="form">
        <!-- Target section -->
        <div class="section">
          <div class="section-header">
            <div class="section-icon section-icon--target">
              <wa-icon library="mdi" name="target-variant"></wa-icon>
            </div>
            <p class="section-title">${this._localize("device.automation_target")}</p>
          </div>
          <div class="field">
            <label>
              ${this._localize("device.automation_target_name")}<span class="required">*</span>
            </label>
            <input
              type="text"
              ?disabled=${t}
              .value=${this._targetName}
              placeholder=${this._localize("device.automation_target_placeholder")}
              @input=${e=>{this._targetName=e.target.value}}
            />
          </div>
        </div>

        <!-- Trigger section -->
        <div class="section">
          <div class="section-header">
            <div class="section-icon section-icon--trigger">
              <wa-icon library="mdi" name="lightning-bolt"></wa-icon>
            </div>
            <p class="section-title">${this._localize("device.automation_trigger")}</p>
          </div>
          <div class="field">
            <label>${this._localize("device.automation_trigger_label")}</label>
            <select
              ?disabled=${t}
              @change=${e=>{this._triggerId=e.target.value}}
            >
              ${0===this._triggers.length?(0,r.qy)`<option disabled selected>No triggers available</option>`:this._triggers.map(e=>(0,r.qy)`<option value=${e.id} ?selected=${e.id===this._triggerId}>${e.name}</option>`)}
            </select>
          </div>
        </div>

        <!-- Action section -->
        <div class="section">
          <div class="section-header">
            <div class="section-icon section-icon--action">
              <wa-icon library="mdi" name="play-circle-outline"></wa-icon>
            </div>
            <p class="section-title">${this._localize("device.automation_action")}</p>
          </div>
          <div class="field">
            <label>${this._localize("device.automation_action_label")}</label>
            <select
              ?disabled=${t}
              @change=${e=>{this._actionId=e.target.value,this._actionFields={}}}
            >
              ${0===this._actions.length?(0,r.qy)`<option disabled selected>No actions available</option>`:this._actions.map(e=>(0,r.qy)`<option value=${e.id} ?selected=${e.id===this._actionId}>${e.name}</option>`)}
            </select>
          </div>
          ${e?.fields.map(e=>this._renderActionField(e,t))??r.s6}
        </div>

        ${this._error?(0,r.qy)`<p class="error">${this._error}</p>`:r.s6}

        <div class="actions">
          <button
            class="dialog-btn dialog-btn--primary"
            ?disabled=${t||!this._targetName.trim()}
            @click=${this._onSubmit}
          >
            ${this._submitting?this._localize("device.adding"):this._localize("device.add_automation")}
          </button>
        </div>
      </div>
    `}_renderActionField(e,t){let i=this._actionFields[e.key]??String(e.default_value??"");return"select"===e.type&&e.options?(0,r.qy)`
        <div class="field">
          <label>${e.label}${e.required?(0,r.qy)`<span class="required">*</span>`:r.s6}</label>
          <select
            ?disabled=${t}
            @change=${t=>this._setActionField(e.key,t.target.value)}
          >
            ${e.options.map(e=>(0,r.qy)`<option value=${e.value} ?selected=${e.value===i}>${e.label}</option>`)}
          </select>
        </div>
      `:(0,r.qy)`
      <div class="field">
        <label>${e.label}${e.required?(0,r.qy)`<span class="required">*</span>`:r.s6}</label>
        <input
          type=${"integer"===e.type||"float"===e.type?"number":"text"}
          ?disabled=${t}
          .value=${i}
          placeholder=${String(e.default_value??"")}
          @input=${t=>this._setActionField(e.key,t.target.value)}
        />
      </div>
    `}_setActionField(e,t){this._actionFields={...this._actionFields,[e]:t}}async _onSubmit(){if(this.configuration&&!this._submitting&&this._targetName.trim()){this._submitting=!0,this._error="";try{throw Error(this._localize("device.add_automation_unavailable"))}catch(e){this._error=e instanceof Error?e.message:this._localize("device.add_automation_error")}finally{this._submitting=!1}}}constructor(...e){super(...e),this._localize=e=>e,this.boardName="",this.configuration="",this._triggers=[],this._actions=[],this._loading=!0,this._targetName="",this._triggerId="",this._actionId="",this._actionFields={},this._submitting=!1,this._error=""}}$.styles=[p.G,_.z,(0,r.AH)`
      wa-dialog {
        --width: 540px;
      }

      wa-dialog::part(header) {
        background: var(--esphome-primary);
        padding: 0 var(--wa-space-m);
        height: 40px;
        box-sizing: border-box;
      }

      wa-dialog::part(title) {
        color: var(--esphome-on-primary);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      wa-dialog::part(close-button__base) {
        background: transparent;
        border: none;
        box-shadow: none;
        padding: 0;
        min-width: unset;
        min-height: unset;
        color: var(--esphome-on-primary);
        cursor: pointer;
      }

      wa-dialog::part(body) {
        padding: var(--wa-space-l);
      }

      wa-dialog::part(footer) {
        display: none;
      }

      /* ── Form ── */

      .form {
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-s);
      }

      /* ── Section blocks ── */

      .section {
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: var(--wa-space-m);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-l);
        background: var(--wa-color-surface-raised);
      }

      .section-header {
        display: flex;
        align-items: center;
        gap: var(--wa-space-s);
        margin-bottom: 2px;
      }

      .section-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border-radius: var(--wa-border-radius-s);
        flex-shrink: 0;
      }

      .section-icon wa-icon {
        font-size: 16px;
      }

      .section-icon--target {
        background: color-mix(in srgb, var(--esphome-primary), transparent 85%);
        color: var(--esphome-primary);
      }

      .section-icon--trigger {
        background: color-mix(in srgb, var(--esphome-warning), transparent 85%);
        color: var(--esphome-warning);
      }

      .section-icon--action {
        background: color-mix(in srgb, var(--esphome-success), transparent 85%);
        color: var(--esphome-success);
      }

      .section-title {
        margin: 0;
        font-size: var(--wa-font-size-xs);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      /* ── Fields ── */

      .field {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      label {
        font-size: var(--wa-font-size-2xs);
        font-weight: var(--wa-font-weight-semibold);
        color: var(--wa-color-text-quiet);
      }

      label .required {
        color: var(--esphome-error);
        margin-left: 2px;
      }

      select {
        width: 100%;
        padding: 9px 14px;
        font-size: var(--wa-font-size-s);
        font-family: inherit;
        color: var(--wa-color-text-normal);
        background: var(--wa-color-surface-raised);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-l);
        box-sizing: border-box;
        outline: none;
        transition:
          border-color 0.15s,
          box-shadow 0.15s;
      }

      select:focus {
        border-color: var(--esphome-primary);
        box-shadow: 0 0 0 3px
          color-mix(in srgb, var(--esphome-primary), transparent 80%);
      }

      select {
        appearance: auto;
      }

      /* ── Actions ── */

      .actions {
        display: flex;
        justify-content: flex-end;
        gap: var(--wa-space-s);
        padding-top: var(--wa-space-m);
        border-top: 1px solid var(--wa-color-surface-border);
      }

      .dialog-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 8px 18px;
        border-radius: var(--wa-border-radius-m);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
        font-family: inherit;
        cursor: pointer;
        border: none;
        transition:
          background 0.12s,
          opacity 0.12s;
      }

      .dialog-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .dialog-btn--primary {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
      }

      .dialog-btn--primary:hover:not(:disabled) {
        background: color-mix(in srgb, var(--esphome-primary), black 10%);
      }

      /* ── States ── */

      .error {
        color: var(--esphome-error);
        font-size: var(--wa-font-size-xs);
        background: color-mix(in srgb, var(--esphome-error), transparent 92%);
        padding: var(--wa-space-s) var(--wa-space-m);
        border-radius: var(--wa-border-radius-m);
      }

      .loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: var(--wa-space-m);
        padding: var(--wa-space-xl);
        color: var(--wa-color-text-quiet);
        font-size: var(--wa-font-size-s);
      }

      .loading wa-spinner {
        font-size: 24px;
        --indicator-color: var(--esphome-primary);
        --track-color: color-mix(
          in srgb,
          var(--esphome-primary),
          transparent 80%
        );
      }
    `],x([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],$.prototype,"_localize",void 0),x([(0,o.Fg)({context:c.Ie})],$.prototype,"_api",void 0),x([(0,n.MZ)()],$.prototype,"boardName",void 0),x([(0,n.MZ)()],$.prototype,"configuration",void 0),x([(0,n.P)("wa-dialog")],$.prototype,"_dialog",void 0),x([(0,n.wk)()],$.prototype,"_triggers",void 0),x([(0,n.wk)()],$.prototype,"_actions",void 0),x([(0,n.wk)()],$.prototype,"_loading",void 0),x([(0,n.wk)()],$.prototype,"_targetName",void 0),x([(0,n.wk)()],$.prototype,"_triggerId",void 0),x([(0,n.wk)()],$.prototype,"_actionId",void 0),x([(0,n.wk)()],$.prototype,"_actionFields",void 0),x([(0,n.wk)()],$.prototype,"_submitting",void 0),x([(0,n.wk)()],$.prototype,"_error",void 0),$=x([(0,n.EM)("esphome-add-automation-dialog")],$);let k=new Set(["esp32","esp8266","rp2040","bk72xx","rtl87xx","ln882x","nrf52","host","esphome","logger","api","ota","wifi","ethernet","mqtt","mdns","network","web_server","captive_portal","improv_serial","safe_mode","debug","preferences","update","external_components","packages","substitutions","dashboard_import","globals"]),z=new Set(["script","interval"]),C=new Set(["globals"]);function S(e){return""===e.trim()||e.startsWith("#")}function q(e){let t=e.split("\n"),i=[];for(let e=0;e<t.length;e++){let o=t[e].match(/^([a-zA-Z_][a-zA-Z0-9_]*):/);if(o){if(i.length>0){let o=i[i.length-1],a=o.fromLine-1,r=e-1;for(;r>a&&S(t[r]);)r--;o.toLine=r+1}i.push({key:o[1],fromLine:e+1,toLine:t.length})}}if(i.length>0){let e=i[i.length-1],o=e.fromLine-1,a=t.length-1;for(a>=0&&""===t[a]&&a--;a>o&&S(t[a]);)a--;e.toLine=a+1}let o=[];for(let e of i)o.push(...function(e,t){if(C.has(t.key))return[{key:t.key,fromLine:t.fromLine,toLine:t.toLine}];let i=t.fromLine-1,o=t.toLine-1,a=[];for(let t=i+1;t<=o;t++)(/^  -\s/.test(e[t])||/^  -$/.test(e[t]))&&a.push(t);if(0===a.length){let a="",r="";for(let t=i+1;t<=o;t++){let i=e[t].match(/^\s{2}name:\s*["']?(.+?)["']?\s*$/);i&&(a=i[1]);let o=e[t].match(/^\s{2}id:\s*["']?(\S+?)["']?\s*$/);o&&(r=o[1])}return[{key:t.key,fromLine:t.fromLine,toLine:t.toLine,name:a||void 0,id:r||void 0}]}let r=[];for(let i=0;i<a.length;i++){let n=a[i],s=i+1<a.length?a[i+1]-1:o,l="",d="",c="";for(let t=n;t<=s;t++){let i=e[t].match(/^\s+(?:-\s+)?name:\s*["']?(.+?)["']?\s*$/);i&&(l=i[1]);let o=e[t].match(/^\s+(?:-\s+)?id:\s*["']?(\S+?)["']?\s*$/);o&&(d=o[1]);let a=e[t].match(/^\s+(?:-\s+)?platform:\s*["']?(\S+?)["']?\s*$/);a&&(c=a[1])}r.push({key:t.key,fromLine:n+1,toLine:s+1,name:l||void 0,id:d||void 0,platform:c||void 0,parentKey:t.key})}return r}(t,e));return o}function E(e){let t=e.split("\n"),i=[];for(let e=0;e<t.length;e++){let o=t[e].match(/^(\s+)(on_[a-zA-Z_]+):/);if(!o)continue;let a=o[1].length,r=o[2],n=e+1,s=t.length;for(let i=e+1;i<t.length;i++)if(""!==t[i].trim()&&(t[i].match(/^(\s*)/)??["",""])[1].length<=a){s=i;break}let l="";for(let i=e-1;i>=0&&!t[i].match(/^[a-zA-Z]/);i--){let e=t[i].match(/^\s+name:\s*["']?(.+?)["']?\s*$/);if(e){l=e[1];break}}i.push({key:l?`${l} → ${r}`:r,fromLine:n,toLine:s})}return i}function L(e){return e.platform?e.platform.startsWith(`${e.key}.`)?e.platform:`${e.key}.${e.platform}`:e.key}function A(e,t,i){if(!e||!t)return;let o=q(e).filter(e=>L(e)===t);if(0!==o.length)return 1===o.length||void 0===i?o[0].fromLine:o.reduce((e,t)=>Math.abs(t.fromLine-i)<Math.abs(e.fromLine-i)?t:e).fromLine}var M=i(4996);function j(e,t){let i=[];for(let[o,a]of Object.entries(e))if(null!=a&&""!==a){if(Array.isArray(a)){if(0===a.length)continue;for(let e of(i.push(`${t}${o}:`),a))i.push(`${t}  - ${D(e)}`);continue}if("object"==typeof a){let e=j(a,`${t}  `);if(0===e.length)continue;i.push(`${t}${o}:`),i.push(...e);continue}i.push(`${t}${o}: ${D(a)}`)}return i}function P(e){let t=new Set;for(let i of e.split("\n")){let e=i.match(/^([a-zA-Z_][a-zA-Z0-9_]*):\s*(.*)$/);e&&t.add(e[1])}return t}function D(e){if("boolean"==typeof e||"number"==typeof e)return String(e);let t=String(e);return/[:#]/.test(t)||/^[-\s'"]/.test(t)||/\s$/.test(t)?`"${t.replace(/"/g,'\\"')}"`:t}function O(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}(0,m.C)({"arrow-collapse-all":a.mdiArrowCollapseAll,"arrow-expand-all":a.mdiArrowExpandAll,memory:a.mdiMemory,"open-in-new":a.mdiOpenInNew,"package-variant-closed":a.mdiPackageVariantClosed,plus:a.mdiPlus});class I extends r.WF{get _visibleComponents(){let e=this.yaml?P(this.yaml):new Set,t=this.yaml?function(e){let t=new Set;if(!e)return t;let i=e.split("\n"),o=null;for(let e of i){let i=e.match(/^([a-zA-Z_][a-zA-Z0-9_]*):\s*(?:#.*)?$/);if(i){o=i[1];continue}if(!o)continue;let a=e.match(/^\s+(?:-\s+)?platform:\s*["']?(\S+?)["']?\s*(?:#.*)?$/);a&&t.add(`${o}.${a[1]}`)}return t}(this.yaml):new Set,i=this.lockedCategories.length>0?new Set(this._components.map(e=>e.id)):null;return this._components.filter(o=>{if(!o.multi_conf){if(o.id.includes(".")){if(t.has(o.id))return!1}else if(e.has(o.id))return!1}return(!(i&&o.id.includes("."))||!(o.dependencies.length>0)||!!o.dependencies.every(t=>i.has(t)||e.has(t)))&&!0})}load(){let e=(this.board?.featured_components?.length??0)+(this.board?.featured_bundles?.length??0);0===this.lockedCategories.length&&this.boardId&&e>0?this._category=l._w.FEATURED:this._category===l._w.FEATURED&&(this._category="all"),this._fetchComponents()}filterByDomain(e){Object.values(l._w).includes(e)?(this._search="",this._category=e):(this._search=e,this._category="all"),this._fetchComponents()}async _fetchComponents(){this._loading=!0;try{let e=this._search.trim()||void 0,t=this.lockedCategories.length>0,i=t?this.lockedCategories:"all"!==this._category?this._category:void 0,o=!t&&this.excludeCategories.length>0?this.excludeCategories:void 0,a=this.platform||void 0,r=this.boardId||void 0,n=await this._api.getComponents({query:e,category:i,exclude_category:o,platform:a,board_id:r,limit:50});this._components=n.components,this._categories=n.categories,this._total=n.total}catch(e){console.error("Failed to load component catalog:",e)}finally{this._loading=!1,this._initialLoad=!1}}get _filteredBundles(){let e=this.board?.featured_bundles??[],t=this._search.trim().toLowerCase();return t?e.filter(e=>e.name.toLowerCase().includes(t)||e.description.toLowerCase().includes(t)||e.id.toLowerCase().includes(t)):e}render(){if(this._initialLoad&&this._loading)return(0,r.qy)`<div class="loading">${this._localize("device.loading_components")}</div>`;let e=this._buildCategories(),t=0===this.lockedCategories.length,i=this._category===l._w.FEATURED?this._filteredBundles:[];return(0,r.qy)`
      ${t?(0,r.qy)`<div class="sidebar">
            <p class="sidebar-label">${this._localize("device.component_categories")}</p>
            ${e.map(({id:e,label:t,count:i})=>(0,r.qy)`
                <button
                  class="category-btn ${this._category===e?"category-btn--active":""}"
                  type="button"
                  @click=${()=>{this._category=e,this._fetchComponents()}}
                >
                  <span class="category-btn-inner">
                    <span>${t}</span>
                    <span class="category-count">${i}</span>
                  </span>
                </button>
              `)}
          </div>`:r.s6}
      <div class="main">
        <input
          type="search"
          .value=${this._search}
          @input=${this._onSearchInput}
          placeholder=${this._localize("device.search_components_placeholder")}
        />
        ${!this._loading?(0,r.qy)`<span class="result-count">${this._visibleComponents.length+i.length} of ${this._total+i.length} components</span>`:""}
        <div class="grid-scroll">
          <div class="components-grid">
            ${this._loading?(0,r.qy)`<p class="empty">${this._localize("device.loading_components")}</p>`:this._visibleComponents.length+i.length?(0,r.qy)`
                    ${i.map(e=>this._renderBundleCard(e))}
                    ${this._visibleComponents.map(e=>this._renderCard(e,e.id===this._expandedId,this._category===l._w.FEATURED))}
                  `:(0,r.qy)`<p class="empty">${this._localize("device.no_components_found")}</p>`}
          </div>
        </div>
      </div>
    `}_renderBundleCard(e){return(0,r.qy)`
      <article class="component-card component-card--featured">
        <div class="component-card-header">
          <div class="component-image--placeholder">
            <wa-icon library="mdi" name="package-variant-closed"></wa-icon>
          </div>
          <div class="component-card-header-text">
            <h3 class="component-title">${e.name}</h3>
          </div>
          <span class="bundle-badge">
            <wa-icon library="mdi" name="package-variant-closed"></wa-icon>
            ${this._localize("device.featured_bundle_badge")}
          </span>
        </div>
        ${e.description?(0,r.qy)`<p class="component-description component-description--clamp">
              ${(0,y.G)(e.description)}
            </p>`:r.s6}
        <div class="card-footer">
          <span></span>
          <div class="select-component" @click=${()=>this._onAddBundle(e)}>
            <wa-icon library="mdi" name="plus"></wa-icon>
            ${this._localize("device.add_component_action")}
          </div>
        </div>
      </article>
    `}_buildCategories(){let e=new Set(this.excludeCategories),t=this._categories.filter(t=>!e.has(t.id)),i=t.find(e=>e.id===l._w.FEATURED),o=this.board?.featured_bundles?.length??0,a=i?i.count+o:o,r=t.filter(e=>e.id!==l._w.FEATURED),n=e.size?r.reduce((e,t)=>e+t.count,0):this._total,s=new Intl.Collator(void 0,{sensitivity:"base"}),d=r.map(e=>{let t=`device.component_category_${e.id}`,i=this._localize(t);return{id:e.id,label:i!==t?i:e.name,count:e.count}}).sort((e,t)=>s.compare(e.label,t.label)),c=[];return a>0&&c.push({id:l._w.FEATURED,label:this._localize("device.component_category_featured"),count:a}),c.push({id:"all",label:this._localize("device.component_category_all"),count:n}),c.push(...d),c}_renderCard(e,t,i=!1){let o=!!e.image_url&&!this._imageFailed.has(e.id);return(0,r.qy)`
      <article
        class="component-card ${t?"component-card--expanded":""} ${i?"component-card--featured":""}"
      >
        <div class="component-card-header">
          ${o?(0,r.qy)`<div class="component-image">
                <img
                  src=${e.image_url}
                  alt=${e.name}
                  referrerpolicy="no-referrer"
                  loading="lazy"
                  @error=${()=>this._onImageError(e.id)}
                />
              </div>`:(0,r.qy)`<div class="component-image--placeholder">
                <wa-icon library="mdi" name="memory"></wa-icon>
              </div>`}
          <div class="component-card-header-text">
            <h3 class="component-title">${e.name}</h3>
          </div>
          <button
            class="expand-button"
            type="button"
            aria-pressed=${t}
            title=${this._localize("wizard.expand_board")}
            @click=${()=>this._onToggleExpand(e)}
          >
            <wa-icon
              library="mdi"
              name=${t?"arrow-collapse-all":"arrow-expand-all"}
            ></wa-icon>
          </button>
        </div>
        <p class="component-description ${t?"":"component-description--clamp"}">
          ${(0,y.G)(e.description)}
        </p>
        <div class="card-footer">
          <a class="more-info" href=${e.docs_url} target="_blank" rel="noreferrer">
            ${this._localize("device.more_info")}
            <wa-icon library="mdi" name="open-in-new"></wa-icon>
          </a>
          <div class="select-component" @click=${()=>this._onAdd(e)}>
            <wa-icon library="mdi" name="plus"></wa-icon>
            ${this._localize("device.add_component_action")}
          </div>
        </div>
      </article>
    `}_onToggleExpand(e){this._expandedId=this._expandedId===e.id?null:e.id}_onImageError(e){if(this._imageFailed.has(e))return;let t=new Set(this._imageFailed);t.add(e),this._imageFailed=t}_onSearchInput(e){this._search=e.target.value,this._debouncedSearch()}_onAdd(e){this.dispatchEvent(new CustomEvent("add-component",{detail:{component:e},bubbles:!0,composed:!0}))}_onAddBundle(e){this.dispatchEvent(new CustomEvent("add-bundle",{detail:{bundle:e,boardId:this.boardId},bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this.platform="",this.boardId="",this.board=null,this.yaml="",this.lockedCategories=[],this.excludeCategories=[],this._components=[],this._categories=[],this._total=0,this._loading=!0,this._initialLoad=!0,this._search="",this._category="all",this._expandedId=null,this._imageFailed=new Set,this._debouncedSearch=(0,M.s)(()=>this._fetchComponents(),300)}}I.styles=[p.G,_.z,(0,r.AH)`
      :host {
        display: flex;
        height: 480px;
        gap: 0;
      }

      :host([hidden]) {
        display: none;
      }

      .sidebar {
        width: 160px;
        flex-shrink: 0;
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-2xs);
        padding-right: var(--wa-space-m);
        border-right: 1px solid var(--wa-color-surface-border);
        overflow-y: auto;
      }

      .sidebar-label {
        font-size: var(--wa-font-size-xs);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-subtle);
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin: 0 0 var(--wa-space-2xs);
        flex-shrink: 0;
      }

      .category-btn {
        border: none;
        background: none;
        cursor: pointer;
        text-align: left;
        padding: var(--wa-space-xs) var(--wa-space-s);
        border-radius: var(--wa-border-radius-m);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-semibold);
        color: var(--wa-color-text-normal);
        transition: background 0.1s;
        font-family: inherit;
        flex-shrink: 0;
      }

      .category-btn:hover {
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        color: var(--esphome-primary);
      }

      .category-btn--active {
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        color: var(--esphome-primary);
      }

      .category-btn-inner {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: var(--wa-space-xs);
      }

      .category-count {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 18px;
        height: 18px;
        padding: 0 4px;
        border-radius: 9px;
        font-size: var(--wa-font-size-xs);
        font-weight: var(--wa-font-weight-bold);
        background: var(--wa-color-surface-raised);
        color: var(--wa-color-text-subtle);
        flex-shrink: 0;
        box-sizing: border-box;
      }

      .category-btn--active .category-count {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
      }

      .main {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-m);
        padding-left: var(--wa-space-m);
        padding-top: 3px;
        padding-right: 3px;
        overflow: hidden;
      }

      input[type="search"] {
        flex-shrink: 0;
      }

      .result-count {
        font-size: var(--wa-font-size-2xs);
        color: var(--wa-color-text-quiet);
        flex-shrink: 0;
        margin-top: -6px;
      }

      .grid-scroll {
        flex: 1;
        overflow-y: auto;
        overflow-x: hidden;
        padding-right: var(--wa-space-2xs);
      }

      /* Cards have a 56px thumbnail + title + expand button + footer
         actions, so they need a fair bit of horizontal room before
         the title stops being readable. Use auto-fill + minmax so
         the grid drops from 2 → 1 column as soon as a card would
         shrink below ~340px, regardless of the dialog/sidebar
         width. Avoids hard viewport breakpoints for the card count. */
      .components-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
        gap: 8px;
        align-content: start;
      }

      /* Below ~600px (modal viewport on phones) the fixed 160px
         category sidebar + search input no longer fit alongside the
         grid. Collapse the sidebar into a horizontal scrolling chip
         row above the grid. The grid itself already collapses to a
         single column via the auto-fill rule above. */
      @media (max-width: 600px) {
        :host {
          flex-direction: column;
          height: auto;
          max-height: 70vh;
        }

        .sidebar {
          width: 100%;
          flex-direction: row;
          gap: var(--wa-space-2xs);
          padding-right: 0;
          padding-bottom: var(--wa-space-s);
          margin-bottom: var(--wa-space-s);
          overflow-x: auto;
          overflow-y: hidden;
          border-right: none;
          border-bottom: 1px solid var(--wa-color-surface-border);
        }

        .sidebar-label {
          display: none;
        }

        .category-btn {
          flex-shrink: 0;
          white-space: nowrap;
        }

        .main {
          padding-left: 0;
          padding-right: 0;
        }
      }

      .component-card {
        border-radius: var(--wa-border-radius-l);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        background: var(--wa-color-surface-default);
        padding: var(--wa-space-s) var(--wa-space-m);
        box-sizing: border-box;
        min-width: 0;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        gap: 6px;
        transition: border-color var(--wa-transition-normal) var(--wa-transition-easing);
      }

      .component-card:hover {
        border-color: var(--esphome-primary);
      }

      .component-card--expanded {
        grid-column: 1 / -1;
      }

      .expand-button {
        border: none;
        background: none;
        cursor: pointer;
        padding: 2px;
        border-radius: 4px;
        display: inline-flex;
        align-items: center;
        flex-shrink: 0;
        color: var(--esphome-primary);
        font-size: 15px;
      }

      .expand-button wa-icon {
        transition: transform var(--wa-transition-normal) var(--wa-transition-easing);
      }

      .component-card-header {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .component-image,
      .component-image--placeholder {
        width: 56px;
        height: 56px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: var(--wa-border-radius-m);
        background: var(--wa-color-surface-subtle);
        flex-shrink: 0;
        color: var(--esphome-primary);
        font-size: 28px;
        box-sizing: border-box;
      }

      .component-image {
        padding: 4px;
      }

      .component-image img {
        width: 100%;
        height: 100%;
        object-fit: contain;
      }

      /* ESPHome's monochrome line-art SVG illustrations are
         black-on-transparent — invisible against the dark surface
         in dark mode. --esphome-svg-filter is none in light mode
         and invert(1)+hue-rotate(180deg) in dark mode, defined at
         the document root in apply-theme.ts. The attribute selector
         scopes this to SVGs only — JPGs / PNGs (board photos, etc.)
         keep their original colours. */
      .component-image img[src$=".svg"] {
        filter: var(--esphome-svg-filter, none);
      }

      .component-card-header-text {
        flex: 1;
        min-width: 0;
      }

      .component-title {
        margin: 0;
        font-size: var(--wa-font-size-xs);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
        line-height: 1.3;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .component-description {
        margin: 0;
        font-size: var(--wa-font-size-2xs);
        color: var(--wa-color-text-quiet);
        line-height: 1.4;
      }

      .component-description--clamp {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }

      .card-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: var(--wa-space-xs);
        margin-top: auto;
      }

      .more-info {
        display: inline-flex;
        align-items: center;
        gap: 2px;
        font-size: var(--wa-font-size-2xs);
        color: var(--esphome-primary);
        text-decoration: none;
      }

      .more-info:hover {
        text-decoration: underline;
      }

      .more-info wa-icon {
        font-size: 11px;
      }

      .select-component {
        display: flex;
        align-items: center;
        gap: 3px;
        font-size: var(--wa-font-size-2xs);
        font-weight: var(--wa-font-weight-bold);
        color: var(--esphome-primary);
        cursor: pointer;
      }

      .empty {
        text-align: center;
        color: var(--wa-color-text-quiet);
        font-size: var(--wa-font-size-s);
        padding: var(--wa-space-xl);
        grid-column: 1 / -1;
      }

      .loading {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--wa-color-text-quiet);
        font-size: var(--wa-font-size-s);
      }

      /* Cards in the "Featured" view get a subtle primary-coloured
         border accent so they read as the curated set, distinct from
         the regular catalog. */
      .component-card--featured {
        border-color: color-mix(
          in srgb,
          var(--esphome-primary),
          transparent 70%
        );
      }

      .bundle-badge {
        display: inline-flex;
        align-items: center;
        gap: 2px;
        font-size: var(--wa-font-size-2xs);
        font-weight: var(--wa-font-weight-bold);
        color: var(--esphome-primary);
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        border-radius: var(--wa-border-radius-s);
        padding: 1px 6px;
      }

      .bundle-badge wa-icon {
        font-size: 11px;
      }
    `],O([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],I.prototype,"_localize",void 0),O([(0,o.Fg)({context:c.Ie})],I.prototype,"_api",void 0),O([(0,n.MZ)()],I.prototype,"platform",void 0),O([(0,n.MZ)({attribute:"board-id"})],I.prototype,"boardId",void 0),O([(0,n.MZ)({attribute:!1})],I.prototype,"board",void 0),O([(0,n.MZ)()],I.prototype,"yaml",void 0),O([(0,n.MZ)({attribute:!1})],I.prototype,"lockedCategories",void 0),O([(0,n.MZ)({attribute:!1})],I.prototype,"excludeCategories",void 0),O([(0,n.wk)()],I.prototype,"_components",void 0),O([(0,n.wk)()],I.prototype,"_categories",void 0),O([(0,n.wk)()],I.prototype,"_total",void 0),O([(0,n.wk)()],I.prototype,"_loading",void 0),O([(0,n.wk)()],I.prototype,"_initialLoad",void 0),O([(0,n.wk)()],I.prototype,"_search",void 0),O([(0,n.wk)()],I.prototype,"_category",void 0),O([(0,n.wk)()],I.prototype,"_expandedId",void 0),O([(0,n.wk)()],I.prototype,"_imageFailed",void 0),I=O([(0,n.EM)("esphome-component-catalog")],I);var F=i(5957);function T(e,t,i){if(0===t.length)return e;let[o,...a]=t;if(0===a.length)return{...e,[o]:i};let r=e[o],n=null===r||"object"!=typeof r||Array.isArray(r)?{}:r;return{...e,[o]:T(n,a,i)}}function R(e,t){let i=e;for(let e of t){if(null===i||"object"!=typeof i||Array.isArray(i))return;i=i[e]}return i}let N=(0,r.AH)`
  :host {
    display: block;
  }

  .form {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
  }

  .form-desc {
    margin: 0 0 var(--wa-space-m);
    font-size: var(--wa-font-size-s);
    color: var(--wa-color-text-quiet);
  }

  .field {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-xs);
  }

  label {
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-normal);
  }

  label .required {
    color: var(--esphome-error);
    margin-left: 2px;
  }

  select {
    width: 100%;
    padding: 9px 14px;
    font-size: var(--wa-font-size-s);
    font-family: inherit;
    color: var(--wa-color-text-normal);
    background: var(--wa-color-surface-raised);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-l);
    box-sizing: border-box;
    outline: none;
    transition:
      border-color 0.15s,
      box-shadow 0.15s;
  }

  select:focus {
    border-color: var(--esphome-primary);
    box-shadow: 0 0 0 3px
      color-mix(in srgb, var(--esphome-primary), transparent 80%);
  }

  select.invalid {
    border-color: var(--esphome-error);
  }

  select:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .field-error {
    color: var(--esphome-error);
    font-size: var(--wa-font-size-xs);
  }

  .array-row {
    display: flex;
    gap: var(--wa-space-xs);
  }

  .array-row input {
    flex: 1;
  }

  .array-btn {
    background: none;
    border: var(--wa-border-width-m) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
    padding: 0 var(--wa-space-s);
    cursor: pointer;
    font-family: inherit;
    color: var(--wa-color-text-normal);
  }

  .array-btn:hover:not(:disabled) {
    background: var(--wa-color-surface-lowered);
  }

  .array-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .yaml-preview {
    margin: 0;
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--wa-color-surface-lowered);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
    font-family: var(--wa-font-family-code, monospace);
    font-size: var(--wa-font-size-xs);
    white-space: pre;
    overflow-x: auto;
    color: var(--wa-color-text-normal);
  }

  .toggle-link {
    background: none;
    border: none;
    padding: 0;
    color: var(--esphome-primary);
    cursor: pointer;
    font-size: var(--wa-font-size-xs);
    text-decoration: underline;
    align-self: flex-start;
  }

  .actions {
    display: flex;
    justify-content: flex-end;
    gap: var(--wa-space-s);
    padding-top: var(--wa-space-m);
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px 18px;
    border-radius: var(--wa-border-radius-m);
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    font-family: inherit;
    cursor: pointer;
    border: none;
    transition:
      background 0.12s,
      opacity 0.12s;
  }

  .btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .btn-secondary {
    background: var(--wa-color-surface-lowered);
    color: var(--wa-color-text-normal);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
  }

  .btn-secondary:hover:not(:disabled) {
    background: var(--wa-color-surface-border);
  }

  .btn-primary {
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
  }

  .btn-primary:hover:not(:disabled) {
    background: color-mix(in srgb, var(--esphome-primary), black 10%);
  }

  .error {
    color: var(--esphome-error);
    font-size: var(--wa-font-size-s);
  }
`,Z=new Set(["name"]);function B(e,t,i){let o=[];for(let a of e)if((0,F.VP)(a,t,i.presentComponents)&&(!a.advanced||i.showAdvanced)){if(a.type===l.Hh.NESTED){let e=t[a.key],o=null===e||"object"!=typeof e||Array.isArray(e)?{}:e;if(0===B(a.config_entries??[],o,i).length)continue}else if(i.requiredOnly&&!a.required&&!Z.has(a.key))continue;o.push(a)}return o}function H(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}i(1062),i(986),i(7994),i(6135),(0,m.C)({close:a.mdiClose,magnify:a.mdiMagnify,palette:a.mdiPalette});let U=null;function Y(e){return e?e.startsWith("mdi:")?e.slice(4):e:""}class W extends r.WF{connectedCallback(){super.connectedCallback(),document.addEventListener("click",this._onDocumentClick,!0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("click",this._onDocumentClick,!0)}willUpdate(e){e.has("_open")&&this._escape.set(this._open)}async _toggle(){this.disabled||(this._open?this._close():await this._openPanel())}async _openPanel(){this._open=!0,this.setAttribute("open",""),this._loaded||(this._catalog=await (U||(U=(async()=>{let e=await Promise.resolve().then(i.bind(i,9165)),t=[];for(let[i,o]of Object.entries(e)){if(!i.startsWith("mdi")||"string"!=typeof o)continue;let e=i.slice(3);if(!e)continue;let a=e.replace(/^[A-Z]/,e=>e.toLowerCase()).replace(/([A-Z])/g,"-$1").replace(/_/g,"-").toLowerCase();t.push({name:a,path:o})}return t.sort((e,t)=>e.name.localeCompare(t.name)),t})().catch(e=>(console.error("[mdi-icon-picker] failed to load catalog:",e),U=null,[])))),this._loaded=!0),await this.updateComplete,this._searchInput?.focus()}_close(){this._open=!1,this.removeAttribute("open"),this._query=""}_select(e){let t=`mdi:${e}`;this.value=t,this.dispatchEvent(new CustomEvent("change",{detail:{value:t},bubbles:!0,composed:!0})),this._close()}_clear(e){e.stopPropagation(),this.value="",this.dispatchEvent(new CustomEvent("change",{detail:{value:""},bubbles:!0,composed:!0}))}_onSearchInput(e){this._query=e.target.value}_renderTriggerIcon(){let e=Y(this.value);if(!e)return(0,r.qy)`<span class="trigger-icon trigger-icon--empty">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path fill="currentColor" d=${a.mdiPalette}></path>
        </svg>
      </span>`;let t=this._catalog.find(t=>t.name===e);return t?(0,r.qy)`<span class="trigger-icon">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path fill="currentColor" d=${t.path}></path>
        </svg>
      </span>`:(0,r.qy)`<span class="trigger-icon">
      <wa-icon library="mdi" name=${e} style="font-size: 16px;"></wa-icon>
    </span>`}_renderPanel(){if(!this._loaded)return(0,r.qy)`<div class="panel" @click=${e=>e.stopPropagation()}>
        <div class="loading">Loading icons…</div>
      </div>`;let e=function(e,t){if(!t)return e.slice(0,400);let i=t.trim().toLowerCase().replace(/\s+/g,"-");if(!i)return e.slice(0,400);let o=[],a=[],r=[];for(let t of e)if(t.name===i?o.push(t):t.name.startsWith(i)?a.push(t):t.name.includes(i)&&r.push(t),o.length+a.length+r.length>=800)break;return[...o,...a,...r].slice(0,400)}(this._catalog,this._query),t=Y(this.value);return(0,r.qy)`
      <div class="panel" @click=${e=>e.stopPropagation()}>
        <div class="search">
          <svg class="search-icon" viewBox="0 0 24 24" aria-hidden="true">
            <path fill="currentColor" d=${a.mdiMagnify}></path>
          </svg>
          <input
            type="text"
            class="search-input"
            placeholder="Search ${this._catalog.length.toLocaleString()} icons…"
            .value=${this._query}
            @input=${this._onSearchInput}
            @keydown=${t=>{"Enter"===t.key&&e.length>0&&(t.preventDefault(),this._select(e[0].name))}}
          />
        </div>
        <div class="grid-wrap">
          ${0===e.length?(0,r.qy)`<div class="empty">
                <wa-icon library="mdi" name="magnify" style="font-size: 24px;"></wa-icon>
                No icons match “${this._query}”
              </div>`:(0,r.qy)`<div class="grid">
                ${e.map(e=>(0,r.qy)`
                    <button
                      type="button"
                      class=${e.name===t?"icon-cell icon-cell--selected":"icon-cell"}
                      title=${`mdi:${e.name}`}
                      @click=${()=>this._select(e.name)}
                    >
                      <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" d=${e.path}></path>
                      </svg>
                    </button>
                  `)}
              </div>`}
        </div>
        <div class="footer">
          <span>
            ${0===e.length?"No matches":e.length>=400?`400+ of ${this._catalog.length.toLocaleString()}`:`${e.length} of ${this._catalog.length.toLocaleString()}`}
          </span>
          ${t?(0,r.qy)`<span class="footer-name">mdi:${t}</span>`:r.s6}
        </div>
      </div>
    `}render(){let e=Y(this.value),t=`trigger${this.invalid?" invalid":""}`;return(0,r.qy)`
      <button
        type="button"
        class=${t}
        ?disabled=${this.disabled}
        @click=${this._toggle}
      >
        ${this._renderTriggerIcon()}
        <span class=${e?"trigger-label":"trigger-label placeholder"}>
          ${e?`mdi:${e}`:this.placeholder}
        </span>
        ${e&&!this.disabled?(0,r.qy)`<span
              class="trigger-clear"
              role="button"
              tabindex="-1"
              title="Clear"
              @click=${this._clear}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
                <path fill="currentColor" d=${a.mdiClose}></path>
              </svg>
            </span>`:r.s6}
        <svg class="trigger-chevron" viewBox="0 0 24 24" aria-hidden="true">
          <path fill="currentColor" d="M7,10L12,15L17,10H7Z"></path>
        </svg>
      </button>
      ${this._open?this._renderPanel():r.s6}
    `}constructor(...e){super(...e),this.value="",this.placeholder="Choose an icon…",this.invalid=!1,this.disabled=!1,this._open=!1,this._catalog=[],this._query="",this._loaded=!1,this._escape=new f.u(this,e=>{e.stopPropagation(),this._close()},{target:document}),this._onDocumentClick=e=>{!this._open||e.composedPath().includes(this)||this._close()}}}function K(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}W.styles=[_.z,(0,r.AH)`
      :host {
        display: block;
        position: relative;
      }

      /* Trigger — shaped like the project's standard input */
      .trigger {
        width: 100%;
        box-sizing: border-box;
        min-height: var(--wa-form-control-height);
        padding: 0 14px;
        font-size: var(--wa-font-size-s);
        font-family: inherit;
        line-height: var(--wa-form-control-value-line-height);
        color: var(--wa-color-text-normal);
        background: var(--wa-color-surface-raised);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-m);
        outline: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 10px;
        text-align: left;
        transition:
          border-color 0.15s,
          box-shadow 0.15s;
      }

      .trigger:focus,
      :host([open]) .trigger {
        border-color: var(--esphome-primary);
        box-shadow: 0 0 0 3px
          color-mix(in srgb, var(--esphome-primary), transparent 80%);
      }

      .trigger.invalid {
        border-color: var(--esphome-error);
      }

      .trigger.invalid:focus {
        box-shadow: 0 0 0 3px
          color-mix(in srgb, var(--esphome-error), transparent 80%);
      }

      .trigger:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .trigger-icon {
        width: 22px;
        height: 22px;
        flex: 0 0 22px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: var(--wa-border-radius-s);
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        color: var(--esphome-primary);
      }

      .trigger-icon svg {
        width: 16px;
        height: 16px;
      }

      .trigger-icon--empty {
        background: var(--wa-color-surface-lowered);
        color: var(--wa-color-text-quiet);
      }

      .trigger-label {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-family: var(--wa-font-family-code, monospace);
        font-size: var(--wa-font-size-s);
      }

      .trigger-label.placeholder {
        color: var(--wa-color-text-quiet);
        font-family: inherit;
      }

      .trigger-clear {
        background: none;
        border: none;
        padding: 4px;
        cursor: pointer;
        color: var(--wa-color-text-quiet);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: var(--wa-border-radius-s);
      }

      .trigger-clear:hover {
        background: var(--wa-color-surface-lowered);
        color: var(--wa-color-text-normal);
      }

      .trigger-chevron {
        width: 14px;
        height: 14px;
        color: var(--wa-color-text-quiet);
        flex: 0 0 14px;
        transition: transform 0.15s;
      }

      :host([open]) .trigger-chevron {
        transform: rotate(180deg);
      }

      /* Panel */
      .panel {
        position: absolute;
        top: calc(100% + 4px);
        left: 0;
        right: 0;
        z-index: 1000;
        display: flex;
        flex-direction: column;
        max-height: 380px;
        background: var(--wa-color-surface-raised);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-m);
        box-shadow:
          0 8px 24px rgba(0, 0, 0, 0.12),
          0 2px 6px rgba(0, 0, 0, 0.06);
        overflow: hidden;
        animation: panelIn 0.12s ease-out;
      }

      @keyframes panelIn {
        from {
          opacity: 0;
          transform: translateY(-4px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .search {
        position: relative;
        padding: 10px 12px;
        border-bottom: var(--wa-border-width-s) solid var(--wa-color-surface-border);
      }

      .search-icon {
        position: absolute;
        left: 22px;
        top: 50%;
        transform: translateY(-50%);
        width: 14px;
        height: 14px;
        color: var(--wa-color-text-quiet);
        pointer-events: none;
      }

      .search-input {
        width: 100%;
        box-sizing: border-box;
        padding: 7px 10px 7px 32px !important;
        min-height: 32px !important;
        font-size: var(--wa-font-size-s);
      }

      .grid-wrap {
        flex: 1;
        overflow-y: auto;
        padding: 8px;
      }

      .grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(40px, 1fr));
        gap: 4px;
      }

      .icon-cell {
        position: relative;
        aspect-ratio: 1;
        background: none;
        border: 1px solid transparent;
        border-radius: var(--wa-border-radius-s);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--wa-color-text-normal);
        padding: 0;
        transition:
          background 0.1s,
          border-color 0.1s,
          color 0.1s,
          transform 0.08s;
      }

      .icon-cell svg {
        width: 20px;
        height: 20px;
      }

      .icon-cell:hover {
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        color: var(--esphome-primary);
        border-color: color-mix(in srgb, var(--esphome-primary), transparent 70%);
        transform: scale(1.06);
      }

      .icon-cell--selected {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
      }

      .icon-cell--selected:hover {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        transform: scale(1.06);
      }

      .empty,
      .loading {
        padding: 24px 16px;
        text-align: center;
        color: var(--wa-color-text-quiet);
        font-size: var(--wa-font-size-s);
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
      }

      .footer {
        padding: 6px 12px;
        border-top: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-quiet);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .footer-name {
        font-family: var(--wa-font-family-code, monospace);
        color: var(--wa-color-text-normal);
        font-size: var(--wa-font-size-xs);
      }
    `],H([(0,n.MZ)()],W.prototype,"value",void 0),H([(0,n.MZ)()],W.prototype,"placeholder",void 0),H([(0,n.MZ)({type:Boolean})],W.prototype,"invalid",void 0),H([(0,n.MZ)({type:Boolean})],W.prototype,"disabled",void 0),H([(0,n.wk)()],W.prototype,"_open",void 0),H([(0,n.wk)()],W.prototype,"_catalog",void 0),H([(0,n.wk)()],W.prototype,"_query",void 0),H([(0,n.wk)()],W.prototype,"_loaded",void 0),H([(0,n.P)(".search-input")],W.prototype,"_searchInput",void 0),W=H([(0,n.EM)("esphome-mdi-icon-picker")],W),(0,m.C)({eye:a.mdiEye,"eye-off":a.mdiEyeOff});class V extends r.WF{render(){let e=this._localize(this._revealed?"device.password_hide":"device.password_reveal");return(0,r.qy)`
      <div class="wrap">
        <input
          type=${this._revealed?"text":"password"}
          class=${this.invalid?"invalid":""}
          .value=${this.value}
          ?disabled=${this.disabled}
          placeholder=${this.placeholder}
          autocomplete="off"
          @input=${this._onInput}
        />
        <button
          type="button"
          class="toggle"
          ?disabled=${this.disabled}
          aria-label=${e}
          title=${e}
          aria-pressed=${this._revealed}
          @click=${this._onToggle}
        >
          <wa-icon
            library="mdi"
            name=${this._revealed?"eye-off":"eye"}
          ></wa-icon>
        </button>
      </div>
    `}_onInput(e){let t=e.target.value;this.value=t,this.dispatchEvent(new CustomEvent("password-input-change",{detail:{value:t},bubbles:!1,composed:!1}))}_onToggle(){this._revealed=!this._revealed}constructor(...e){super(...e),this._localize=e=>e,this.value="",this.placeholder="",this.disabled=!1,this.invalid=!1,this._revealed=!1}}V.styles=[p.G,_.z,(0,r.AH)`
      :host {
        display: block;
      }

      .wrap {
        position: relative;
      }

      input {
        /* Make room for the toggle so long values don't slide
           underneath it. The toggle is 32px wide + 8px breathing
           room. */
        padding-right: 40px;
      }

      .toggle {
        position: absolute;
        top: 50%;
        right: 6px;
        transform: translateY(-50%);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        padding: 0;
        border: none;
        background: transparent;
        color: var(--wa-color-text-quiet);
        border-radius: var(--wa-border-radius-s);
        cursor: pointer;
        transition:
          background 0.12s,
          color 0.12s;
      }

      .toggle:hover {
        background: color-mix(
          in srgb,
          var(--wa-color-text-normal),
          transparent 92%
        );
        color: var(--wa-color-text-normal);
      }

      .toggle:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .toggle wa-icon {
        font-size: 16px;
      }
    `],K([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],V.prototype,"_localize",void 0),K([(0,n.MZ)()],V.prototype,"value",void 0),K([(0,n.MZ)()],V.prototype,"placeholder",void 0),K([(0,n.MZ)({type:Boolean})],V.prototype,"disabled",void 0),K([(0,n.MZ)({type:Boolean})],V.prototype,"invalid",void 0),K([(0,n.wk)()],V.prototype,"_revealed",void 0),V=K([(0,n.EM)("esphome-password-input")],V);let G=(0,r.AH)`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
  }

  .field {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-2xs);
  }

  .field-label {
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-normal);
    display: flex;
    align-items: center;
    gap: var(--wa-space-2xs);
  }

  .field-label .required {
    color: var(--esphome-error);
  }

  /* Indicator on featured-component fields the board has pinned to a
     fixed value. Sits next to the help-link icon. */
  .field-label .lock-icon {
    font-size: 13px;
    color: var(--wa-color-text-quiet);
  }

  .field-error {
    color: var(--esphome-error);
    font-size: var(--wa-font-size-2xs);
    margin-top: var(--wa-space-2xs);
  }

  .field-description {
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    margin: 0;
  }

  .field-description + input,
  .field-description + textarea,
  .field-description + wa-select {
    margin-top: 8px;
  }

  /* Hint shown below a string/password input when the value is a
     !secret reference — clarifies that the field points into
     secrets.yaml instead of holding a literal value. */
  .secret-note {
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-2xs);
    margin-top: var(--wa-space-2xs);
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
  }

  .secret-note wa-icon {
    font-size: 14px;
    color: var(--esphome-primary);
  }

  .secret-note code {
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
    font-size: var(--wa-font-size-2xs);
    padding: 1px 4px;
    border-radius: var(--wa-border-radius-s);
    background: var(--wa-color-surface-lowered);
    color: var(--wa-color-text-normal);
  }

  .help-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: none;
    border: none;
    padding: 0;
    cursor: pointer;
    color: var(--wa-color-text-quiet);
    font-size: 16px;
    transition: color 0.12s;
    margin-left: auto;
  }

  .help-button:hover {
    color: var(--esphome-primary);
  }

  /* ─── Nested group ──────────────────────────────────────── */
  .nested-group {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-s);
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--wa-color-surface-lowered);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
  }

  .nested-toggle {
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-2xs);
    background: none;
    border: none;
    padding: 0;
    font-family: inherit;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-normal);
    cursor: pointer;
    text-align: left;
  }

  .nested-toggle:hover {
    color: var(--esphome-primary);
  }

  .nested-toggle wa-icon {
    font-size: 18px;
  }

  .nested-title {
    flex: 1;
  }

  .nested-platform {
    font-size: var(--wa-font-size-2xs);
    font-weight: var(--wa-font-weight-normal);
    color: var(--wa-color-text-quiet);
    background: var(--wa-color-surface-default);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-s);
    padding: 1px 6px;
    margin-left: var(--wa-space-xs);
  }

  .nested-fields {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
    padding-top: var(--wa-space-xs);
  }

  /* ─── multi-value rows ──────────────────────────────────── */
  .multi-row {
    display: flex;
    align-items: center;
    gap: var(--wa-space-2xs);
  }

  .multi-row .multi-input {
    flex: 1;
    font-family: inherit;
    font-size: var(--wa-font-size-s);
    padding: 6px 12px;
    border-radius: var(--wa-border-radius-m);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-default);
    color: var(--wa-color-text-normal);
    outline: none;
    box-sizing: border-box;
    transition:
      border-color 0.12s,
      box-shadow 0.12s;
  }

  .multi-row .multi-input:focus {
    border-color: var(--esphome-primary);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--esphome-primary), transparent 80%);
  }

  .multi-row .multi-input.invalid {
    border-color: var(--esphome-error);
  }

  .multi-row .multi-input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .combobox-input {
    font-family: inherit;
    font-size: var(--wa-font-size-s);
    padding: 6px 12px;
    border-radius: var(--wa-border-radius-m);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-default);
    color: var(--wa-color-text-normal);
    outline: none;
    box-sizing: border-box;
    transition:
      border-color 0.12s,
      box-shadow 0.12s;
  }

  .combobox-input:focus {
    border-color: var(--esphome-primary);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--esphome-primary), transparent 80%);
  }

  .combobox-input.invalid {
    border-color: var(--esphome-error);
  }

  .combobox-input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .multi-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    padding: 4px 10px;
    background: transparent;
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
    color: var(--wa-color-text-quiet);
    font-family: inherit;
    font-size: var(--wa-font-size-xs);
    cursor: pointer;
    transition:
      background 0.12s,
      border-color 0.12s,
      color 0.12s;
  }

  .multi-btn:hover {
    background: var(--wa-color-surface-lowered);
    color: var(--wa-color-text-normal);
  }

  .multi-btn wa-icon {
    font-size: 14px;
  }

  .multi-add {
    align-self: flex-start;
    margin-top: var(--wa-space-2xs);
  }

  /* ─── Map (key/value) rows ──────────────────────────────── */
  .map-row {
    display: flex;
    align-items: flex-start;
    gap: var(--wa-space-2xs);
  }

  .map-row .map-key-input {
    flex: 1;
    min-width: 0;
  }

  .map-row .map-value {
    flex: 1.5;
    min-width: 0;
  }

  /* Inside a map row the value's label and description are
     redundant (the map itself has those at the top) — suppress
     them so each row stays compact. */
  .map-row .map-value > .field > label,
  .map-row .map-value > .field > p.field-description {
    display: none;
  }

  .map-row .map-value > .field {
    gap: 0;
  }

  .textarea-field {
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
    font-size: var(--wa-font-size-xs);
    padding: var(--wa-space-s);
    border-radius: var(--wa-border-radius-m);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-default);
    color: var(--wa-color-text-normal);
    resize: vertical;
    min-height: 80px;
  }

  .textarea-field.invalid {
    border-color: var(--esphome-error);
  }

  /* ─── Pin selector option layout ─────────────────────────── */
  .pin-option-stack {
    display: inline-flex;
    flex-direction: column;
    gap: 1px;
    line-height: 1.25;
  }

  .pin-option-primary {
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-normal);
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .pin-option-secondary {
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    font-style: italic;
  }

  .pin-option[disabled] .pin-option-primary,
  .pin-option[disabled] .pin-option-secondary {
    color: var(--wa-color-text-quiet);
  }

  .pin-warn-icon {
    color: var(--esphome-warning, #d97706);
    font-size: 14px;
    flex-shrink: 0;
  }

  .pin-option--warn .pin-option-secondary {
    color: var(--esphome-warning, #d97706);
    font-style: normal;
  }

  /* ─── ID reference picker option layout ──────────────────── */
  .id-option-stack {
    display: inline-flex;
    flex-direction: column;
    gap: 1px;
    line-height: 1.25;
  }

  /* Visually distinguish the "Add new …" entry at the bottom of
     the dropdown — same pattern as Home Assistant's entity
     pickers. Coloured to read as an action, not a value. */
  .id-option-add {
    border-top: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    margin-top: var(--wa-space-2xs);
  }

  .id-option-add--solo {
    border-top: none;
    margin-top: 0;
  }

  .id-option-primary-add {
    color: var(--esphome-primary);
    font-weight: var(--wa-font-weight-bold);
  }

  .id-option-primary-add wa-icon {
    font-size: 14px;
  }

  .id-option-primary {
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-normal);
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .id-option-secondary {
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    font-style: italic;
  }

  .alert-entry {
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--wa-color-surface-lowered);
    border-radius: var(--wa-border-radius-m);
    font-size: var(--wa-font-size-xs);
    color: var(--wa-color-text-quiet);
    line-height: 1.5;
  }

  .label-entry {
    font-size: var(--wa-font-size-xs);
    color: var(--wa-color-text-subtle);
    font-style: italic;
  }

  .switch-field {
    display: grid;
    grid-template-columns: 1fr auto;
    column-gap: var(--wa-space-m);
    row-gap: var(--wa-space-2xs);
    align-items: center;
  }

  .switch-field .field-info {
    grid-column: 1;
    grid-row: 1 / span 2;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .switch-field > .help-button {
    grid-column: 2;
    grid-row: 1;
    margin-left: 0;
    align-self: start;
  }

  .switch-field > wa-switch {
    grid-column: 2;
    grid-row: 2;
    justify-self: end;
  }

  .switch-field:not(:has(> .help-button)) > wa-switch {
    grid-row: 1 / span 2;
  }

  wa-select {
    width: 100%;
  }

  .float-with-unit-inputs {
    display: flex;
    align-items: center;
    gap: var(--wa-space-s);
  }

  .float-with-unit-inputs > input[type="number"] {
    flex: 1 1 auto;
    min-width: 0;
  }

  .float-with-unit-inputs > wa-select {
    flex: 0 0 auto;
    width: auto;
    min-width: 6rem;
  }

  .float-with-unit-suffix {
    flex: 0 0 auto;
    color: var(--wa-color-text-subtle);
    font-size: var(--wa-font-size-s);
  }
`;var J=i(2477),Q=i(7169);function X(e,t){return t.disabled||e.locked}(0,m.C)({"key-variant":a.mdiKeyVariant,"lock-outline":a.mdiLockOutline});let ee=/^!secret\s+(\S+)\s*$/;function et(e,t){let i=e.match(ee);return i?(0,r.qy)`<span class="secret-note">
    <wa-icon library="mdi" name="key-variant"></wa-icon>
    <span>${t.localize("device.value_from_secret")}</span>
    <code>${i[1]}</code>
  </span>`:r.s6}function ei(e,t){if(e.translation_key){let i=e.translation_params||void 0,o=t(e.translation_key,i);if(o&&o!==e.translation_key)return o}return e.label?e.label:e.key.split("_").map(e=>e?e[0].toUpperCase()+e.slice(1):e).join(" ")}function eo(e,t){return ei(e,t.localize)}function ea(e,t){return e.help_link?(0,r.qy)`<a
    class="help-button"
    href=${e.help_link}
    target="_blank"
    rel="noreferrer"
    title=${t.localize("device.docs")}
  >
    <wa-icon library="mdi" name="open-in-new"></wa-icon>
  </a>`:r.s6}function er(e,t,i={}){let{includeHelpLink:o=!0}=i;return(0,r.qy)`
    <label class="field-label">
      ${eo(e,t)}
      ${e.required?(0,r.qy)`<span class="required">*</span>`:r.s6}
      ${e.locked?(0,r.qy)`<wa-icon
            class="lock-icon"
            library="mdi"
            name="lock-outline"
            title=${t.localize("device.field_locked_by_board")}
          ></wa-icon>`:r.s6}
      ${o&&e.help_link?ea(e,t):r.s6}
    </label>
    ${e.description?(0,r.qy)`<p class="field-description">
          ${(0,y.G)(e.description)}
        </p>`:r.s6}
  `}function en(e,t){let i=t.errorAt(e);return i?(0,r.qy)`<span class="field-error">${t.localize(i.code,i.params)}</span>`:r.s6}function es(e,t,i,o){var a,n,s,d,c,p;let h,u,m,g=String(o.getAt(i)??""),f=null!==o.errorAt(i),v=String(e.default_value??""),b=X(e,o);return e.suggestions&&e.suggestions.length>0?(a=e,n=i,s=g,d=f,c=b,p=o,h=s.toLowerCase(),u=String(a.default_value??""),m=a.type===l.Hh.INTEGER||a.type===l.Hh.FLOAT,(0,r.qy)`
    <div class="field" data-field-key=${n.join(".")}>
      ${er(a,p)}
      <wa-select
        class=${d?"invalid":""}
        ?disabled=${c}
        placeholder=${u}
        @change=${e=>p.emitChange(n,(e=>{if(!m||""===e)return e;let t=a.type===l.Hh.INTEGER?parseInt(e,10):Number(e);return Number.isFinite(t)?t:e})(e.target.value))}
      >
        ${(a.suggestions??[]).map(e=>{let t=String(e);return(0,r.qy)`<wa-option
            value=${t}
            ?selected=${t.toLowerCase()===h}
            >${t}</wa-option
          >`})}
      </wa-select>
      ${en(n,p)}
    </div>
  `):"password"===t?(0,r.qy)`
      <div class="field" data-field-key=${i.join(".")}>
        ${er(e,o)}
        <esphome-password-input
          .value=${g}
          .invalid=${f}
          .disabled=${b}
          .placeholder=${v}
          @password-input-change=${e=>o.emitChange(i,e.detail.value)}
        ></esphome-password-input>
        ${et(g,o)} ${en(i,o)}
      </div>
    `:(0,r.qy)`
    <div class="field" data-field-key=${i.join(".")}>
      ${er(e,o)}
      <input
        type=${t}
        class=${f?"invalid":""}
        .value=${g}
        ?disabled=${b}
        placeholder=${v}
        @input=${e=>o.emitChange(i,e.target.value)}
      />
      ${et(g,o)} ${en(i,o)}
    </div>
  `}function el(e){let t,i;return{get(o){if(void 0!==t&&e(o,t))return i},set(e,o){t=e,i=o},clear(){t=void 0,i=void 0}}}let ed=el((e,t)=>e.yaml===t.yaml&&e.excludeFromLine===t.excludeFromLine&&e.excludeToLine===t.excludeToLine),ec=el((e,t)=>e.yaml===t.yaml&&e.domain===t.domain),ep="__esphome_add_new__";function eh(e){if("number"==typeof e&&Number.isFinite(e))return e;if("string"==typeof e){let t=e.match(/^\s*(?:GPIO)?(\d+)\s*$/i);if(t)return Number(t[1])}return null===e||"object"!=typeof e||Array.isArray(e)?null:eh(e.number)}function eu(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}(0,m.C)({"alert-circle-outline":a.mdiAlertCircleOutline,"chevron-down":a.mdiChevronDown,"chevron-up":a.mdiChevronUp,close:a.mdiClose,"open-in-new":a.mdiOpenInNew,plus:a.mdiPlus});class em extends r.WF{render(){let e=this._buildCtx(),t=this._filterRenderable(this.entries,this.values);return(0,r.qy)`${t.map(t=>this._renderEntry(t,[t.key],e))}`}willUpdate(e){e.has("entries")&&void 0!==e.get("entries")&&(this._pendingUnits.clear(),this._editingMagnitudes.clear())}updated(e){super.updated(e),this._syncSelectValues()}async _syncSelectValues(){if(this.shadowRoot)for(let e of this.shadowRoot.querySelectorAll("[data-field-key]")){let t=e.querySelector("wa-select");if(!t)continue;if(t.hasAttribute("data-no-value-sync")){await this._syncSelectedAttr(t);continue}if(t.updateComplete)try{await t.updateComplete}catch{}let i=e.getAttribute("data-field-key");if(!i)continue;let o=i.split("."),a=String(R(this.values,o)??""),r=Array.from(t.querySelectorAll("wa-option")),n=a.match(/^\s*(?:GPIO)?(\d+)\s*$/i)?.[1],s=e=>r.find(t=>t.value?.toLowerCase()===e.toLowerCase()),l=a?s(a)??(n?s(`GPIO${n}`):void 0):null,d=l?.value??a;(Array.isArray(t.value)?t.value[0]??"":t.value??"")!==d&&(t.value=d)}}async _syncSelectedAttr(e){if(e.updateComplete)try{await e.updateComplete}catch{}let t=e.querySelector("wa-option[selected]"),i=t?.value??"";i&&(Array.isArray(e.value)?e.value[0]??"":e.value??"")!==i&&(e.value=i)}_renderEntry(e,t,i){if(e.type===l.Hh.DIVIDER)return(0,r.qy)`<wa-divider></wa-divider>`;if(e.type===l.Hh.LABEL)return(0,r.qy)`<p class="label-entry">${eo(e,i)}</p>`;if(e.type===l.Hh.ALERT)return(0,r.qy)`<div class="alert-entry">${eo(e,i)}</div>`;if(e.type===l.Hh.NESTED){let o,a,n,s;return o=t.join("."),a=i.nestedOpenSections.has(o),n=i.requiredOnly?!a:a,s=i.filterRenderable(e.config_entries??[],i.scopeValues(t)),(0,r.qy)`
    <div class="nested-group" data-field-key=${t.join(".")}>
      <button
        type="button"
        class="nested-toggle"
        @click=${()=>i.toggleNested(o)}
      >
        <wa-icon
          library="mdi"
          name=${n?"chevron-up":"chevron-down"}
        ></wa-icon>
        <span class="nested-title">${eo(e,i)}</span>
        ${e.platform_type?(0,r.qy)`<span class="nested-platform">${e.platform_type}</span>`:r.s6}
      </button>
      ${n?(0,r.qy)`<div class="nested-fields">
            ${s.map(e=>i.renderEntry(e,[...t,e.key]))}
          </div>`:r.s6}
    </div>
  `}if(e.type===l.Hh.MAP){let o,a,n,s,l;return o=(e.config_entries??[])[0],n=Object.keys((a=i.getAt(t))&&"object"==typeof a&&!Array.isArray(a)?a:{}),s=X(e,i),l=()=>{let e=i.getAt(t);return e&&"object"==typeof e&&!Array.isArray(e)?{...e}:{}},(0,r.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${er(e,i)}
      ${0===n.length?(0,r.qy)`<p class="field-description">
            ${i.localize("device.map_empty")}
          </p>`:r.s6}
      ${n.map(e=>{let a;return a=[...t,e],(0,r.qy)`
      <div class="map-row">
        <input
          type="text"
          class="multi-input map-key-input"
          .value=${e}
          ?disabled=${s}
          @change=${o=>((e,o)=>{if(e===o||!o)return;let a=i.getAt(t);if(!a||"object"!=typeof a||Array.isArray(a)||o in a)return;let r={};for(let[t,i]of Object.entries(a))r[t===e?o:t]=i;i.emitChange(t,r)})(e,o.target.value)}
        />
        <div class="map-value">
          ${o?i.renderEntry(o,a):r.s6}
        </div>
        <button
          type="button"
          class="multi-btn"
          ?disabled=${s}
          aria-label=${i.localize("device.map_remove")}
          @click=${()=>{let o;e in(o=l())&&(delete o[e],i.emitChange(t,o))}}
        >
          <wa-icon library="mdi" name="close"></wa-icon>
        </button>
      </div>
    `})}
      <button
        type="button"
        class="multi-btn multi-add"
        ?disabled=${s}
        @click=${()=>{let e=l(),o=1;for(;`new_${o}`in e;)o++;e[`new_${o}`]="",i.emitChange(t,e)}}
      >
        <wa-icon library="mdi" name="plus"></wa-icon>
        ${i.localize("device.map_add")}
      </button>
      ${en(t,i)}
    </div>
  `}if(e.multi_value){let o,a,n,s;return a=Array.isArray(o=i.getAt(t))?o.map(e=>String(e)):[],n=null!==i.errorAt(t),s=X(e,i),(0,r.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${er(e,i)}
      ${0===a.length?(0,r.qy)`<p class="field-description">
            ${i.localize("device.multi_value_empty")}
          </p>`:r.s6}
      ${a.map((e,o)=>(0,r.qy)`
          <div class="multi-row">
            <input
              type="text"
              class="multi-input ${n?"invalid":""}"
              .value=${e}
              ?disabled=${s}
              @input=${e=>{var a;let r,n;return a=e.target.value,void((n=Array.isArray(r=i.getAt(t))?[...r]:[])[o]=a,i.emitChange(t,n))}}
            />
            <button
              type="button"
              class="multi-btn"
              ?disabled=${s}
              aria-label=${i.localize("device.multi_value_remove")}
              @click=${()=>{let e,a;return a=Array.isArray(e=i.getAt(t))?e:[],void i.emitChange(t,a.filter((e,t)=>t!==o))}}
            >
              <wa-icon library="mdi" name="close"></wa-icon>
            </button>
          </div>
        `)}
      <button
        type="button"
        class="multi-btn multi-add"
        ?disabled=${s}
        @click=${()=>{let e=i.getAt(t),o=Array.isArray(e)?e:[];i.emitChange(t,[...o,""])}}
      >
        <wa-icon library="mdi" name="plus"></wa-icon>
        ${i.localize("device.multi_value_add")}
      </button>
      ${en(t,i)}
    </div>
  `}if(e.references_component){let o,a,n,s,l,d,c;return o=e.references_component||"",a=function(e,t){if(!t)return[];let i={yaml:e,domain:t},o=ec.get(i);if(o)return o;let a=e.split("\n"),r=[],n=!1,s="",l="",d=()=>{s&&r.push({id:s,name:l}),s="",l=""};for(let e of a){let i=e.match(/^([a-zA-Z_][a-zA-Z0-9_]*):/);if(i){d(),n=i[1]===t;continue}if(!n)continue;/^\s*-\s/.test(e)&&d();let o=e.match(/^\s+(?:-\s+)?id:\s*["']?(\S+?)["']?\s*$/);if(o){s=o[1];continue}let a=e.match(/^\s+(?:-\s+)?name:\s*["']?(.+?)["']?\s*$/);a&&(l=a[1])}return d(),ec.set(i,r),r}(i.yaml,o),n=String(i.getAt(t)??""),s=null!==i.errorAt(t),l=0===a.length,d=e=>{let a=e.target,r=a.value;if(r===ep){a.value=n,i.requestAddComponent(o);return}i.emitChange(t,r)},c=(0,r.qy)`
    <wa-option
      class="id-option id-option-add ${l?"id-option-add--solo":""}"
      value=${ep}
    >
      <span class="id-option-stack">
        <span class="id-option-primary id-option-primary-add">
          <wa-icon library="mdi" name="plus"></wa-icon>
          ${i.localize("device.id_reference_add",{domain:o})}
        </span>
      </span>
    </wa-option>
  `,l?(0,r.qy)`
      <div class="field" data-field-key=${t.join(".")}>
        ${er(e,i)}
        <wa-select
          class=${s?"invalid":""}
          ?disabled=${X(e,i)}
          placeholder=${i.localize("device.id_reference_empty",{domain:o})}
          @change=${d}
        >
          ${c}
        </wa-select>
        ${en(t,i)}
      </div>
    `:(0,r.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${er(e,i)}
      <wa-select
        class=${s?"invalid":""}
        ?disabled=${X(e,i)}
        @change=${d}
      >
        ${a.map(e=>(0,r.qy)`<wa-option
              class="id-option"
              value=${e.id}
              .label=${e.name||e.id}
              ?selected=${e.id===n}
            >
              <span class="id-option-stack">
                <span class="id-option-primary">${e.name||e.id}</span>
                <span class="id-option-secondary"
                  >${e.name?`${e.id} \xb7 ${o}`:o}</span
                >
              </span>
            </wa-option>`)}
        ${c}
      </wa-select>
      ${en(t,i)}
    </div>
  `}if(e.options&&e.options.length>0)return function(e,t,i){let o=String(i.getAt(t)??""),a=null!==i.errorAt(t),n=X(e,i);if(e.suggestions&&e.suggestions.length>0){let s=o.toLowerCase();return(0,r.qy)`
      <div class="field" data-field-key=${t.join(".")}>
        ${er(e,i)}
        <wa-select
          class=${a?"invalid":""}
          ?disabled=${n}
          placeholder=${String(e.default_value??"")}
          @change=${e=>i.emitChange(t,e.target.value)}
        >
          ${e.suggestions.map(e=>{let t=String(e);return(0,r.qy)`<wa-option
              value=${t}
              ?selected=${t.toLowerCase()===s}
              >${t}</wa-option
            >`})}
        </wa-select>
        ${en(t,i)}
      </div>
    `}if(e.allow_custom_value&&e.options&&e.options.length>0){let s=`combobox-${t.join("-")}`;return(0,r.qy)`
      <div class="field" data-field-key=${t.join(".")}>
        ${er(e,i)}
        <input
          type="text"
          class="combobox-input ${a?"invalid":""}"
          list=${s}
          .value=${o}
          ?disabled=${n}
          placeholder=${String(e.default_value??"")}
          @input=${e=>i.emitChange(t,e.target.value)}
        />
        <datalist id=${s}>
          ${e.options.map(e=>(0,r.qy)`<option value=${e.value}>${e.label}</option>`)}
        </datalist>
        ${en(t,i)}
      </div>
    `}let s=o.toLowerCase(),l=null!=e.default_value?String(e.default_value):"",d=e.options?.find(e=>e.value.toLowerCase()===l.toLowerCase()),c=d?.label??l;return(0,r.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${er(e,i)}
      <wa-select
        class=${a?"invalid":""}
        ?disabled=${n}
        placeholder=${c}
        @change=${e=>i.emitChange(t,e.target.value)}
      >
        ${(e.options??[]).map(e=>(0,r.qy)`<wa-option
              value=${e.value}
              ?selected=${e.value.toLowerCase()===s}
              >${e.label}</wa-option
            >`)}
      </wa-select>
      ${en(t,i)}
    </div>
  `}(e,t,i);switch(e.type){case l.Hh.BOOLEAN:let o;return o=i.getAt(t),(0,r.qy)`
    <div class="switch-field" data-field-key=${t.join(".")}>
      <div class="field-info">
        ${er(e,i,{includeHelpLink:!1})}
      </div>
      ${ea(e,i)}
      <wa-switch
        ?checked=${!0===o||"true"===o}
        ?disabled=${X(e,i)}
        @change=${e=>i.emitChange(t,e.target.checked)}
      ></wa-switch>
    </div>
  `;case l.Hh.SELECT:return es(e,"text",t,i);case l.Hh.SECURE_STRING:return es(e,"password",t,i);case l.Hh.INTEGER:case l.Hh.FLOAT:return function(e,t,i){if(e.suggestions&&e.suggestions.length>0)return es(e,"number",t,i);let o=String(i.getAt(t)??""),a=null!==i.errorAt(t),n=e.range?String(e.range[0]):void 0,s=e.range?String(e.range[1]):void 0,d=X(e,i);return(0,r.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${er(e,i)}
      <input
        type="number"
        class=${a?"invalid":""}
        .value=${o}
        ?disabled=${d}
        min=${n??""}
        max=${s??""}
        step=${e.type===l.Hh.FLOAT?"any":"1"}
        placeholder=${String(e.default_value??"")}
        @input=${e=>{let o=e.target.value;i.emitChange(t,""===o?"":Number(o))}}
      />
      ${en(t,i)}
    </div>
  `}(e,t,i);case l.Hh.FLOAT_WITH_UNIT:let a,n,s,d,c,p,h,u,m,g,f,v,b;return n=(a=e.unit_options??[])[0]??"",s=i.getAt(t),d=(0,Q.Eb)(s,a),c=i.getEditingMagnitude(t)??(null===d.value?"":String(d.value)),p=(0,Q.E3)(s,e.default_value,i.getPendingUnit(t),a),h=(0,Q.x9)(e.default_value,a),u=null!==i.errorAt(t),m=X(e,i),g=p===n,f=e.range&&g?String(e.range[0]):void 0,v=e.range&&g?String(e.range[1]):void 0,b=e=>i.emitChange(t,(0,Q.BR)(e)),(0,r.qy)`
    <div class="field float-with-unit" data-field-key=${t.join(".")}>
      ${er(e,i)}
      <div class="float-with-unit-inputs">
        <input
          type="number"
          class=${u?"invalid":""}
          .value=${c}
          ?disabled=${m}
          min=${(0,J.J)(f)}
          max=${(0,J.J)(v)}
          step="any"
          placeholder=${h}
          @input=${e=>{let o=e.target.value;i.setEditingMagnitude(t,o),""===o&&i.setPendingUnit(t,p);let a=""===o?null:Number(o);b({value:Number.isFinite(a)?a:null,unit:p})}}
          @blur=${()=>i.clearEditingMagnitude(t)}
        />
        ${a.length>1?(0,r.qy)`
              <wa-select
                data-no-value-sync
                ?disabled=${m}
                @change=${e=>{let o=e.target.value;null===d.value?i.setPendingUnit(t,o):b({value:d.value,unit:o})}}
              >
                ${a.map(e=>(0,r.qy)`<wa-option
                    value=${e}
                    ?selected=${e===p}
                    >${e}</wa-option
                  >`)}
              </wa-select>
            `:(0,r.qy)`<span class="float-with-unit-suffix">${p}</span>`}
      </div>
      ${en(t,i)}
    </div>
  `;case l.Hh.PIN:return function(e,t,i){if(!i.board||0===i.board.pins.length)return es(e,"text",t,i);let o=i.getAt(t),a=eh(o),n=null!==a?`GPIO${a}`:String(o??""),s=null!==i.errorAt(t),d=e.pin_features??[],c=i.board.pins.filter(e=>d.every(t=>e.features.includes(t)));if(e.suggestions&&e.suggestions.length>0){let t=new Set(e.suggestions.map(eh).filter(e=>null!==e));if(t.size>0){let e=c.filter(e=>t.has(e.gpio));e.length>0&&(c=e)}}null!==a&&!c.some(e=>e.gpio===a)&&i.board.pins.some(e=>e.gpio===a)&&(c=[i.board.pins.find(e=>e.gpio===a),...c]);let p=function(e,t,i){let o={yaml:e,excludeFromLine:t,excludeToLine:i},a=ed.get(o);if(a)return a;let r=new Map;if(!e)return r;let n=e.split("\n"),s="";for(let e=0;e<n.length;e++){let o=n[e],a=o.match(/^([a-zA-Z_][a-zA-Z0-9_]*):/);if(a){s=a[1];continue}let l=e+1;if(void 0===t||void 0===i||!(l>=t)||!(l<=i))for(let e of o.matchAll(/GPIO(\d+)/g)){let t=parseInt(e[1],10);Number.isNaN(t)||r.has(t)||!s||r.set(t,s)}}return ed.set(o,r),r}(i.yaml,i.fromLine,function(e,t){if(void 0===t)return;let i=e.split("\n");for(let e=t;e<i.length;e++){let t=i[e];if(""!==t&&/^[a-zA-Z]/.test(t))return e}return i.length}(i.yaml,i.fromLine)),h=X(e,i);return(0,r.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${er(e,i)}
      <wa-select
        class=${s?"invalid":""}
        ?disabled=${h}
        @change=${e=>i.emitChange(t,e.target.value)}
      >
        ${c.map(t=>{let o,a,s,d,c,h,u,m,g,f,v,b,w=(o=`GPIO${t.gpio}`,a=t.label||o,s=t.occupied_by||"",d=p.get(t.gpio)||"",c=e.pin_mode===l.l3.OUTPUT||e.pin_mode===l.l3.INPUT_OUTPUT,h=t.features.includes(l.k6.INPUT_ONLY),u=c&&h,m=!1===t.available||u,g=!!(s||d),f=s?i.localize("device.pin_occupied_by",{name:s}):d?i.localize("device.pin_used_by",{name:d}):"",v=u?i.localize("device.pin_input_only"):t.notes||(!1===t.available?i.localize("device.pin_unavailable"):""),b=[],t.label&&t.label!==o&&b.push(o),f&&b.push(f),v&&b.push(v),{optValue:o,primary:a,secondary:b.join(" • "),titleText:[f,v].filter(Boolean).join(" — "),inUse:g,disabled:m});return(0,r.qy)`<wa-option
            class="pin-option ${w.inUse?"pin-option--warn":""}"
            value=${w.optValue}
            .label=${w.primary}
            ?selected=${w.optValue===n}
            ?disabled=${w.disabled}
            title=${w.titleText}
          >
            <span class="pin-option-stack">
              <span class="pin-option-primary">
                ${w.primary}
                ${w.inUse?(0,r.qy)`<wa-icon
                      class="pin-warn-icon"
                      library="mdi"
                      name="alert-circle-outline"
                    ></wa-icon>`:r.s6}
              </span>
              ${w.secondary?(0,r.qy)`<span class="pin-option-secondary">${w.secondary}</span>`:r.s6}
            </span>
          </wa-option>`})}
      </wa-select>
      ${en(t,i)}
    </div>
  `}(e,t,i);case l.Hh.COLOR:return es(e,"color",t,i);case l.Hh.MAC_ADDRESS:return es(e,"text",t,i);case l.Hh.LAMBDA:case l.Hh.JSON:let w,y;return w=String(i.getAt(t)??""),y=null!==i.errorAt(t),(0,r.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${er(e,i)}
      <textarea
        class="textarea-field ${y?"invalid":""}"
        rows="4"
        ?disabled=${X(e,i)}
        .value=${w}
        placeholder=${String(e.default_value??"")}
        @input=${e=>i.emitChange(t,e.target.value)}
      ></textarea>
      ${en(t,i)}
    </div>
  `;case l.Hh.ICON:let _,x;return _=String(i.getAt(t)??""),x=null!==i.errorAt(t),(0,r.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${er(e,i)}
      <esphome-mdi-icon-picker
        .value=${_}
        .invalid=${x}
        .disabled=${X(e,i)}
        .placeholder=${String(e.default_value??"Choose an icon…")}
        @change=${e=>i.emitChange(t,e.detail.value)}
      ></esphome-mdi-icon-picker>
      ${en(t,i)}
    </div>
  `;default:return es(e,"text",t,i)}}_buildCtx(){let e={localize:this._localize,disabled:this.disabled,yaml:this.yaml,fromLine:this.fromLine,board:this.board,requiredOnly:this.requiredOnly,nestedOpenSections:this._nestedOpenSections,getAt:e=>R(this.values,e),errorAt:e=>this.errors.get(e.join("."))??null,emitChange:(e,t)=>this._emitChange(e,t),toggleNested:e=>this._toggleNested(e),requestAddComponent:e=>this._requestAddComponent(e),scopeValues:e=>this._scopeValues(e),filterRenderable:this._filterRenderable,getPendingUnit:e=>this._pendingUnits.get(e.join(".")),setPendingUnit:(e,t)=>{this._pendingUnits.set(e.join("."),t),this.requestUpdate()},getEditingMagnitude:e=>this._editingMagnitudes.get(e.join(".")),setEditingMagnitude:(e,t)=>{this._editingMagnitudes.set(e.join("."),t)},clearEditingMagnitude:e=>{this._editingMagnitudes.delete(e.join("."))},renderEntry:()=>r.s6};return e.renderEntry=(t,i)=>this._renderEntry(t,i,e),e}_scopeValues(e){let t=R(this.values,e);return t&&"object"==typeof t&&!Array.isArray(t)?t:{}}_emitChange(e,t){this.dispatchEvent(new CustomEvent("value-change",{detail:{path:e,value:t},bubbles:!0,composed:!0}))}_toggleNested(e){let t=new Set(this._nestedOpenSections);t.has(e)?t.delete(e):t.add(e),this._nestedOpenSections=t}openNested(e){if(this.requiredOnly||this._nestedOpenSections.has(e))return;let t=new Set(this._nestedOpenSections);t.add(e),this._nestedOpenSections=t}_requestAddComponent(e){this.dispatchEvent(new CustomEvent("request-add-component",{detail:{domain:e},bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this.entries=[],this.values={},this.errors=new Map,this.board=null,this.disabled=!1,this.showAdvanced=!1,this.requiredOnly=!1,this.yaml="",this.presentComponents=new Set,this._nestedOpenSections=new Set,this._pendingUnits=new Map,this._editingMagnitudes=new Map,this._filterRenderable=(e,t)=>B(e,t,{requiredOnly:this.requiredOnly,showAdvanced:this.showAdvanced,presentComponents:this.presentComponents})}}function eg(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}em.styles=[p.G,_.z,G],eu([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],em.prototype,"_localize",void 0),eu([(0,n.MZ)({attribute:!1})],em.prototype,"entries",void 0),eu([(0,n.MZ)({attribute:!1})],em.prototype,"values",void 0),eu([(0,n.MZ)({attribute:!1})],em.prototype,"errors",void 0),eu([(0,n.MZ)({attribute:!1})],em.prototype,"board",void 0),eu([(0,n.MZ)({type:Boolean})],em.prototype,"disabled",void 0),eu([(0,n.MZ)({type:Boolean,attribute:"show-advanced"})],em.prototype,"showAdvanced",void 0),eu([(0,n.MZ)({type:Boolean,attribute:"required-only"})],em.prototype,"requiredOnly",void 0),eu([(0,n.MZ)()],em.prototype,"yaml",void 0),eu([(0,n.MZ)({type:Number,attribute:"from-line"})],em.prototype,"fromLine",void 0),eu([(0,n.MZ)({attribute:!1})],em.prototype,"presentComponents",void 0),eu([(0,n.wk)()],em.prototype,"_nestedOpenSections",void 0),em=eu([(0,n.EM)("esphome-config-entry-form")],em),(0,m.C)({"alert-circle-outline":a.mdiAlertCircleOutline});class ef extends r.WF{willUpdate(e){super.willUpdate(e),(e.has("component")||!this._initialized)&&this.component&&(this._initialized=!0,this._initValues(),this._localBlockMessage="")}_initValues(){let e=this.component.id.startsWith("featured."),t=this._seedDefaults(this.component.config_entries,e);if(this.component.config_entries.find(e=>"id"===e.key&&e.type===l.Hh.ID)&&void 0===t.id&&(t={...t,id:this._generateDefaultId()}),t=function(e,t,i,o){if(!i?.pins?.length||e.includes("."))return o;let a=o;for(let o of t){if(o.type!==l.Hh.PIN||void 0!==a[o.key])continue;let t=`${e}_${o.key.toLowerCase()}`,r=i.pins.find(e=>e.features.includes(t));r&&(a={...a,[o.key]:r.gpio})}return a}(this.component.id,this.component.config_entries,this.board,t),this.prefillReference){let e=this._findReferencePath(this.component.config_entries,this.prefillReference.domain,[]);e&&(t=T(t,e,this.prefillReference.id))}this._values=t}_findReferencePath(e,t,i){for(let o of e){if(o.type===l.Hh.NESTED){let e=this._findReferencePath(o.config_entries??[],t,[...i,o.key]);if(e)return e;continue}if(o.references_component===t)return[...i,o.key]}return null}_seedDefaults(e,t=!1){let i={};for(let o of e){if(o.type===l.Hh.NESTED){let e=this._seedDefaults(o.config_entries??[],t);Object.keys(e).length>0&&(i[o.key]=e);continue}(t||o.required)&&(null!=o.default_value?i[o.key]=o.multi_value?[String(o.default_value)]:o.default_value:o.multi_value&&o.required&&(i[o.key]=[]))}return i}_generateDefaultId(){let e=this.component.id.replace(/\./g,"_").toLowerCase(),t=this._collectExistingIds(this.yaml),i=1,o=`${e}_${i}`;for(;t.has(o);)i++,o=`${e}_${i}`;return o}_collectExistingIds(e){let t=new Set;if(!e)return t;for(let i of e.split("\n")){let e=i.match(/^\s+(?:-\s+)?id:\s*["']?(\S+?)["']?\s*$/);e&&t.add(e[1])}return t}render(){let e=this.submitting,t=P(this.yaml),i=(this.component.dependencies??[]).filter(e=>!t.has(e)),o=(0,F.JK)(this.component.config_entries,this._values,t),a=!this._hasRequiredErrors(o);return(0,r.qy)`
      <div class="form">
        <p class="form-desc">${(0,y.G)(this.component.description)}</p>
        ${i.length>0?this._renderMissingDeps(i):r.s6}
        <esphome-config-entry-form
          .entries=${this.component.config_entries}
          .values=${this._values}
          .errors=${this._errors}
          .board=${this.board}
          .yaml=${this.yaml}
          .presentComponents=${t}
          ?disabled=${e}
          ?required-only=${!0}
          @value-change=${this._onValueChange}
        ></esphome-config-entry-form>
        <button
          type="button"
          class="toggle-link"
          @click=${()=>{this._showYaml=!this._showYaml}}
        >
          ${this._showYaml?this._localize("device.yaml_preview_toggle"):this._localize("device.yaml_preview")}
        </button>
        ${this._showYaml?(0,r.qy)`<pre class="yaml-preview">${this._generateYamlPreview()}</pre>`:r.s6}
        ${this.submitError?(0,r.qy)`<p class="error">${this.submitError}</p>`:r.s6}
        ${this._localBlockMessage?(0,r.qy)`<p class="error">${this._localBlockMessage}</p>`:r.s6}
        <div class="actions">
          <button
            class="btn btn-secondary"
            ?disabled=${e}
            @click=${this._onCancel}
          >
            ${this._localize("wizard.back")}
          </button>
          <button
            class="btn btn-primary"
            ?disabled=${e||!a||i.length>0}
            @click=${this._onSubmit}
          >
            ${this.submitting?this._localize("device.adding"):this._localize("device.add_component_action")}
          </button>
        </div>
      </div>
    `}_renderMissingDeps(e){return(0,r.qy)`
      <div class="deps-warning" role="alert">
        <wa-icon library="mdi" name="alert-circle-outline"></wa-icon>
        <div class="deps-warning-body">
          <div class="deps-warning-title">
            ${this._localize("device.missing_dependencies_title",{name:this.component.name})}
          </div>
          <div>${this._localize("device.missing_dependencies_body")}</div>
          <div class="deps-warning-actions">
            ${e.map(e=>(0,r.qy)`<button
                type="button"
                class="dep-button"
                @click=${()=>this._onAddDep(e)}
              >
                ${this._localize("device.missing_dependencies_add",{domain:e})}
              </button>`)}
          </div>
        </div>
      </div>
    `}_onAddDep(e){this.dispatchEvent(new CustomEvent("navigate-to-dep",{detail:{domain:e},bubbles:!0,composed:!0}))}_hasRequiredErrors(e){for(let t of e.values())if("validation.required"===t.code)return!0;return!1}_labelForErrorKey(e){let t,i=e.split("."),o=this.component.config_entries;for(let e of i){if(!o||!(t=o.find(t=>t.key===e)))break;o=t.type===l.Hh.NESTED?t.config_entries??[]:null}return t?ei(t,this._localize):e}_anyErrorIsVisible(e,t){if(0===e.size)return!1;let i=function e(t,i,o,a=[],r=new Set){for(let n of B(t,i,o)){if(n.type===l.Hh.NESTED){let t=i[n.key],s=null===t||"object"!=typeof t||Array.isArray(t)?{}:t;e(n.config_entries??[],s,o,[...a,n.key],r),r.add([...a,n.key].join("."));continue}r.add([...a,n.key].join("."))}return r}(this.component.config_entries,this._values,{requiredOnly:!0,showAdvanced:!1,presentComponents:t});for(let t of e.keys())if(i.has(t))return!0;return!1}_onValueChange(e){let{path:t,value:i}=e.detail;this._values=T(this._values,t,i);let o=t.join(".");if(this._errors.has(o)){let e=new Map(this._errors);e.delete(o),this._errors=e}this._localBlockMessage&&(this._localBlockMessage="")}_generateYamlPreview(){let e=[`${this.component.id}:`];return e.push(...j(this._values,"  ")),e.join("\n")}_onCancel(){this.dispatchEvent(new CustomEvent("form-cancel",{bubbles:!0,composed:!0}))}_onSubmit(){this._localBlockMessage="";let e=P(this.yaml),t=(this.component.dependencies??[]).filter(t=>!e.has(t));if(t.length>0){this._localBlockMessage=`${this._localize("device.missing_dependencies_title",{name:this.component.name})} (${t.join(", ")})`;return}let i=(0,F.JK)(this.component.config_entries,this._values,e);if(i.size>0){if(this._errors=i,!this._anyErrorIsVisible(i,e)){let e=[...i.entries()].map(([e,t])=>`${this._labelForErrorKey(e)}: ${this._localize(t.code,t.params)}`).join("; ");this._localBlockMessage=`${this._localize("device.add_component_hidden_validation_error")} (${e})`}return}this._errors=new Map,this._localBlockMessage="";let o=this._coerceFields(this.component.config_entries,this._values);this.dispatchEvent(new CustomEvent("form-submit",{detail:{fields:o},bubbles:!0,composed:!0}))}_coerceFields(e,t){let i={};for(let o of e){if(o.hidden)continue;let e=t[o.key];if(o.type===l.Hh.NESTED){let t=null===e||"object"!=typeof e||Array.isArray(e)?{}:e,a=this._coerceFields(o.config_entries??[],t);Object.keys(a).length>0&&(i[o.key]=a);continue}if(void 0!==e){if(Array.isArray(e)){if(0===e.length)continue;i[o.key]=e;continue}if(""===e){o.required&&(i[o.key]=e);continue}if(o.type===l.Hh.INTEGER){let t="number"==typeof e?e:Number.parseInt(String(e),10);Number.isNaN(t)||(i[o.key]=t)}else if(o.type===l.Hh.FLOAT){let t="number"==typeof e?e:Number.parseFloat(String(e));Number.isNaN(t)||(i[o.key]=t)}else o.type===l.Hh.BOOLEAN?i[o.key]=!0===e||"true"===e:i[o.key]=e}}return i}constructor(...e){super(...e),this._localize=e=>e,this.board=null,this.yaml="",this.prefillReference=null,this.submitting=!1,this.submitError="",this._values={},this._errors=new Map,this._localBlockMessage="",this._showYaml=!1,this._initialized=!1}}function ev(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}ef.styles=[p.G,_.z,N,(0,r.AH)`
      /* Banner shown when the component has unmet dependencies
         (e.g. a gpio light needs a configured output: first). */
      .deps-warning {
        display: flex;
        gap: var(--wa-space-s);
        padding: var(--wa-space-s) var(--wa-space-m);
        background: color-mix(
          in srgb,
          var(--esphome-warning, #d97706),
          transparent 88%
        );
        border: var(--wa-border-width-s) solid
          var(--esphome-warning, #d97706);
        border-radius: var(--wa-border-radius-m);
        color: var(--wa-color-text-normal);
        font-size: var(--wa-font-size-s);
        line-height: 1.45;
      }

      .deps-warning wa-icon {
        flex-shrink: 0;
        font-size: 20px;
        color: var(--esphome-warning, #d97706);
      }

      .deps-warning-body {
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-2xs);
        flex: 1;
        min-width: 0;
      }

      .deps-warning-title {
        font-weight: var(--wa-font-weight-bold);
      }

      .deps-warning-actions {
        display: flex;
        flex-wrap: wrap;
        gap: var(--wa-space-2xs);
        margin-top: var(--wa-space-2xs);
      }

      .dep-button {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 10px;
        background: var(--esphome-warning, #d97706);
        color: var(--esphome-on-primary, white);
        border: none;
        border-radius: var(--wa-border-radius-m);
        font-family: inherit;
        font-size: var(--wa-font-size-xs);
        font-weight: var(--wa-font-weight-bold);
        cursor: pointer;
        transition: opacity 0.12s;
      }

      .dep-button:hover {
        opacity: 0.9;
      }
    `],eg([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],ef.prototype,"_localize",void 0),eg([(0,n.MZ)({attribute:!1})],ef.prototype,"component",void 0),eg([(0,n.MZ)({attribute:!1})],ef.prototype,"board",void 0),eg([(0,n.MZ)()],ef.prototype,"yaml",void 0),eg([(0,n.MZ)({attribute:!1})],ef.prototype,"prefillReference",void 0),eg([(0,n.MZ)({type:Boolean})],ef.prototype,"submitting",void 0),eg([(0,n.MZ)()],ef.prototype,"submitError",void 0),eg([(0,n.wk)()],ef.prototype,"_values",void 0),eg([(0,n.wk)()],ef.prototype,"_errors",void 0),eg([(0,n.wk)()],ef.prototype,"_localBlockMessage",void 0),eg([(0,n.wk)()],ef.prototype,"_showYaml",void 0),ef=eg([(0,n.EM)("esphome-add-component-form")],ef),(0,m.C)({close:a.mdiClose,"arrow-left":a.mdiArrowLeft,"package-variant-closed":a.mdiPackageVariantClosed});class eb extends r.WF{open(){this._resetDetourState(),this._selected=null,this._submitError="",this._submitting=!1,this._dialog.open=!0,this.updateComplete.then(()=>this._catalog?.load())}openWithSearch(e){this._resetDetourState(),this._selected=null,this._submitError="",this._submitting=!1,this._dialog.open=!0,this.updateComplete.then(()=>this._catalog?.filterByDomain(e))}_resetDetourState(){this._returnTo=null,this._depDomain=null,this._prefillReference=null,this._bundleQueue=[],this._bundleProgress=null}render(){let e=null!==this._selected,t=this.lockedCategories.length>0,i=t?this.boardName?"device.add_config_dialog_title":"device.add_config":this.boardName?"device.add_component_dialog_title":"device.add_component";return(0,r.qy)`
      <wa-dialog
        class=${e?"form-view":""}
        light-dismiss
        @add-component=${this._onComponentSelected}
        @add-bundle=${this._onBundleSelected}
        @form-cancel=${this._onBack}
        @form-submit=${this._onFormSubmit}
        @navigate-to-dep=${this._onNavigateToDep}
        @request-add-component=${this._onNavigateToDep}
      >
        <span slot="label" class="dialog-label">
          ${e?(0,r.qy)`<button class="back-button" @click=${this._onBack}>
                <wa-icon library="mdi" name="arrow-left"></wa-icon>
              </button>`:r.s6}
          ${e?this._selected.name:this.boardName?this._localize(i,{name:this.boardName}):this._localize(i)}
        </span>
        ${this._returnTo?(0,r.qy)`<div class="return-banner">
              ${this._localize("device.return_to_after_dep_prefix")}
              <strong>${this._returnTo.name}</strong>
              ${this._localize("device.return_to_after_dep_suffix")}
            </div>`:r.s6}
        ${e&&this._bundleProgress?(0,r.qy)`<div class="bundle-banner">
              <wa-icon library="mdi" name="package-variant-closed"></wa-icon>
              <span
                >${this._localize("device.bundle_step_progress",{current:this._bundleProgress.current,total:this._bundleProgress.total,name:this._bundleProgress.bundleName})}</span
              >
            </div>`:r.s6}
        <esphome-component-catalog
          ?hidden=${e}
          .platform=${this.platform}
          .boardId=${this.board?.id??""}
          .board=${this.board}
          .yaml=${this.yaml}
          .lockedCategories=${this.lockedCategories}
          .excludeCategories=${t?[]:l.bI}
        ></esphome-component-catalog>
        ${e?(0,r.qy)`<esphome-add-component-form
              .component=${this._selected}
              .board=${this.board}
              .yaml=${this.yaml}
              .prefillReference=${this._prefillReference}
              .submitting=${this._submitting}
              .submitError=${this._submitError}
            ></esphome-add-component-form>`:r.s6}
      </wa-dialog>
    `}_onComponentSelected(e){e.stopPropagation(),this._selected=e.detail.component,this._submitError=""}async _onBundleSelected(e){let t;if(e.stopPropagation(),this._submitting)return;let{bundle:i,boardId:o}=e.detail;if(!o||0===i.component_ids.length)return;let a=i.component_ids.map(e=>`featured.${o}.${e}`),[r,...n]=a;try{t=await this._api.getComponent(r,this.platform||void 0,o)}catch(e){this._submitError=e instanceof Error?e.message:this._localize("device.add_component_error");return}if(!t){this._submitError=this._localize("device.add_component_error");return}this._returnTo=null,this._depDomain=null,this._prefillReference=null,this._bundleQueue=n,this._bundleProgress={current:1,total:a.length,bundleName:i.name},this._selected=t,this._submitError=""}_onBack(){if(!this._submitting){if(this._returnTo){let e=this._returnTo;this._resetDetourState(),this._selected=e,this._submitError="";return}this._resetDetourState(),this._selected=null,this._submitError=""}}async _onNavigateToDep(e){if(e.stopPropagation(),this._submitting)return;let{domain:t}=e.detail;this._selected&&(this._returnTo=this._selected,this._depDomain=t),this._selected=null,this._submitError="",await this.updateComplete,this._catalog?.filterByDomain(t)}async _onFormSubmit(e){if(e.stopPropagation(),this._selected&&this.configuration&&!this._submitting){this._submitting=!0,this._submitError="";try{let{yaml:t}=await this._api.addComponent(this.configuration,{component_id:this._selected.id,fields:e.detail.fields});if(this.dispatchEvent(new CustomEvent("yaml-updated",{detail:{yaml:t},bubbles:!0,composed:!0})),this._returnTo){let t=this._returnTo,i=this._depDomain,o=e.detail.fields.id;i&&"string"==typeof o&&this._selected.category===i?this._prefillReference={domain:i,id:o}:this._prefillReference=null,this._returnTo=null,this._depDomain=null,this._selected=t}else if(this._bundleQueue.length>0&&this._bundleProgress){let t=this._bundleQueue[0],i=this._bundleQueue.slice(1),o=await this._api.getComponent(t,this.platform||void 0,this.board?.id??void 0);if(!o){this._submitError=this._localize("device.add_component_error");return}let a=e.detail.fields.id,r=this._selected.category;"string"==typeof a&&r?this._prefillReference={domain:r,id:a}:this._prefillReference=null,this._bundleQueue=i,this._bundleProgress={...this._bundleProgress,current:this._bundleProgress.current+1},this._selected=o}else{let i=this._selected.id,o=e.detail.fields.id,a=function(e,t,i){let o=q(e);if(!t.includes(".")){let e=o.find(e=>e.key===t&&!e.platform);if(e)return{sectionKey:e.key,fromLine:e.fromLine}}let a=o.filter(e=>L(e)===t);if(0===a.length)return null;if(1===a.length)return{sectionKey:L(a[0]),fromLine:a[0].fromLine};if(i){let t=e.split("\n"),o=RegExp(`^\\s+(?:-\\s+)?id:\\s*["']?${i}["']?\\s*$`);for(let e of a)for(let i=e.fromLine-1;i<e.toLine&&i<t.length;i++)if(o.test(t[i]))return{sectionKey:L(e),fromLine:e.fromLine}}let r=a[a.length-1];return{sectionKey:L(r),fromLine:r.fromLine}}(t,i,"string"==typeof o?o:void 0);a&&this.dispatchEvent(new CustomEvent("section-select",{detail:a,bubbles:!0,composed:!0})),this._dialog.open=!1,this._selected=null,this._resetDetourState()}}catch(e){this._submitError=e instanceof Error?e.message:this._localize("device.add_component_error")}finally{this._submitting=!1}}}constructor(...e){super(...e),this._localize=e=>e,this.boardName="",this.configuration="",this.platform="",this.board=null,this.yaml="",this.lockedCategories=[],this._selected=null,this._submitting=!1,this._submitError="",this._returnTo=null,this._depDomain=null,this._prefillReference=null,this._bundleQueue=[],this._bundleProgress=null}}function ew(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eb.styles=[p.G,(0,r.AH)`
      wa-dialog {
        --width: 900px;
      }

      wa-dialog.form-view {
        --width: 480px;
      }

      wa-dialog::part(header) {
        background: var(--esphome-primary);
        /* Right padding is 0 so the close button sits flush with the
           dialog's corner — the button is explicitly sized to a 40x40
           square below to give the X a comfortable hit target right
           where the user reaches for it. */
        padding: 0 0 0 var(--wa-space-m);
        height: 40px;
        box-sizing: border-box;
      }

      wa-dialog::part(title) {
        color: var(--esphome-on-primary);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      wa-dialog::part(close-button__base) {
        background: transparent;
        border: none;
        box-shadow: none;
        /* Square 40x40 button matching the header height so the X has a
           comfortable click/tap target instead of just the icon's
           ~14px footprint. */
        padding: 0;
        width: 40px;
        height: 40px;
        min-width: unset;
        min-height: unset;
        color: var(--esphome-on-primary);
        cursor: pointer;
      }

      wa-dialog::part(body) {
        padding: var(--wa-space-l);
      }

      wa-dialog::part(footer) {
        display: none;
      }

      .dialog-label {
        display: flex;
        align-items: center;
        gap: var(--wa-space-xs);
        color: var(--esphome-on-primary);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .back-button {
        display: inline-flex;
        align-items: center;
        border: none;
        background: none;
        padding: 2px;
        margin-right: var(--wa-space-2xs);
        color: var(--esphome-on-primary);
        cursor: pointer;
        border-radius: 4px;
        opacity: 0.85;
      }

      .back-button:hover {
        opacity: 1;
      }

      /* Breadcrumb that shows up while the user is detoured into
         "add a dependency" mid-way through adding another component.
         Tells them we'll bring them back to the original after. */
      .return-banner {
        display: flex;
        align-items: center;
        gap: var(--wa-space-2xs);
        margin-bottom: var(--wa-space-m);
        padding: var(--wa-space-2xs) var(--wa-space-s);
        background: color-mix(
          in srgb,
          var(--esphome-primary),
          transparent 92%
        );
        border-left: 3px solid var(--esphome-primary);
        border-radius: var(--wa-border-radius-s);
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-quiet);
      }

      .return-banner strong {
        color: var(--wa-color-text-normal);
        font-weight: var(--wa-font-weight-semibold);
      }

      .bundle-banner {
        display: flex;
        align-items: center;
        gap: var(--wa-space-xs);
        margin-bottom: var(--wa-space-m);
        padding: var(--wa-space-xs) var(--wa-space-s);
        background: color-mix(
          in srgb,
          var(--esphome-primary),
          transparent 92%
        );
        border-left: 3px solid var(--esphome-primary);
        border-radius: var(--wa-border-radius-s);
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-normal);
      }

      .bundle-banner wa-icon {
        font-size: 14px;
        color: var(--esphome-primary);
      }
    `],ev([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],eb.prototype,"_localize",void 0),ev([(0,o.Fg)({context:c.Ie})],eb.prototype,"_api",void 0),ev([(0,n.MZ)()],eb.prototype,"boardName",void 0),ev([(0,n.MZ)()],eb.prototype,"configuration",void 0),ev([(0,n.MZ)()],eb.prototype,"platform",void 0),ev([(0,n.MZ)({attribute:!1})],eb.prototype,"board",void 0),ev([(0,n.MZ)()],eb.prototype,"yaml",void 0),ev([(0,n.MZ)({attribute:!1})],eb.prototype,"lockedCategories",void 0),ev([(0,n.P)("wa-dialog")],eb.prototype,"_dialog",void 0),ev([(0,n.P)("esphome-component-catalog")],eb.prototype,"_catalog",void 0),ev([(0,n.wk)()],eb.prototype,"_selected",void 0),ev([(0,n.wk)()],eb.prototype,"_submitting",void 0),ev([(0,n.wk)()],eb.prototype,"_submitError",void 0),ev([(0,n.wk)()],eb.prototype,"_returnTo",void 0),ev([(0,n.wk)()],eb.prototype,"_depDomain",void 0),ev([(0,n.wk)()],eb.prototype,"_prefillReference",void 0),ev([(0,n.wk)()],eb.prototype,"_bundleQueue",void 0),ev([(0,n.wk)()],eb.prototype,"_bundleProgress",void 0),eb=ev([(0,n.EM)("esphome-add-component-dialog")],eb);class ey extends r.WF{open(){this._inner.open()}render(){return(0,r.qy)`<esphome-add-component-dialog
      .lockedCategories=${l.bI}
      .boardName=${this.boardName}
      .configuration=${this.configuration}
      .platform=${this.platform}
      .board=${this.board}
      .yaml=${this.yaml}
    ></esphome-add-component-dialog>`}constructor(...e){super(...e),this.boardName="",this.configuration="",this.platform="",this.board=null,this.yaml=""}}ew([(0,n.MZ)()],ey.prototype,"boardName",void 0),ew([(0,n.MZ)()],ey.prototype,"configuration",void 0),ew([(0,n.MZ)()],ey.prototype,"platform",void 0),ew([(0,n.MZ)({attribute:!1})],ey.prototype,"board",void 0),ew([(0,n.MZ)()],ey.prototype,"yaml",void 0),ew([(0,n.P)("esphome-add-component-dialog")],ey.prototype,"_inner",void 0),ey=ew([(0,n.EM)("esphome-add-config-dialog")],ey);let e_="[a-zA-Z_][a-zA-Z0-9_]*",ex=RegExp(`^\\s+-\\s+(${e_}):\\s*(.*)$`),e$=/^\s+-(\s|$)/,ek=e=>RegExp(`^${e}(${e_}):\\s*(.*)$`),ez=e=>RegExp(`^${e}  -\\s+(.*)$`),eC=e=>e.startsWith('"')&&e.endsWith('"')||e.startsWith("'")&&e.endsWith("'")?e.slice(1,-1):e,eS=e=>{let t=eC(e);return"true"===t||"false"!==t&&t},eq=e=>{let t=e.slice(1,-1).trim();return""===t?[]:t.split(",").map(e=>eC(e.trim()))},eE=(e,t,i,o)=>{let a=[],r=t;for(;r<e.length;r++){if(""===e[r].trim())continue;if(!e[r].startsWith(i))break;let t=e[r].match(o);if(!t)break;a.push(eC(t[1].trim()))}return{items:a,endIdx:r}};function eL(e,t,i){if(void 0!==i)return i-1;for(let i=0;i<e.length;i++)if(e[i].startsWith(`${t}:`))return i;return -1}function eA(e,t,i){let o=eL(e,t,i);if(o<0)return{start:-1,end:-1};let a=e$.test(e[o]),r=e.length;for(let t=o+1;t<e.length;t++)if(a){if(e$.test(e[t])||/^[a-zA-Z]/.test(e[t])){r=t;break}}else if(/^[a-zA-Z]/.test(e[t])){r=t;break}return{start:o,end:r}}i(8768);let eM=(0,r.AH)`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
    margin-top: var(--wa-space-m);
  }

  .section-header {
    display: flex;
    flex-direction: row;
    align-items: center;
    width: 100%;
    gap: var(--wa-space-l);
    padding-bottom: var(--wa-space-m);
    margin-bottom: var(--wa-space-m);
    border-bottom: 1px solid var(--wa-color-surface-lowered);
  }

  .section-header-info {
    display: flex;
    flex-direction: column;
    flex: 1;
    gap: var(--wa-space-s);
    min-width: 0;
  }

  .section-header-title-row {
    display: flex;
    align-items: center;
    gap: var(--wa-space-m);
    flex-wrap: wrap;
  }

  .section-image {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 140px;
    height: 100px;
    padding: var(--wa-space-s);
    background: var(--wa-color-surface-lowered);
    border-radius: var(--wa-border-radius-l);
    box-sizing: border-box;
  }

  .section-image img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }

  /* Match the catalog's dark-mode treatment for the same monochrome
     SVG illustrations — see component-catalog.ts for the rationale. */
  .section-image img[src$=".svg"] {
    filter: var(--esphome-svg-filter, none);
  }

  .section-title {
    margin: 0;
    font-size: var(--wa-font-size-l);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-normal);
  }

  .section-desc {
    margin: 0;
    font-size: var(--wa-font-size-xs);
    color: var(--wa-color-text-quiet);
    line-height: 1.5;
  }

  .docs-link {
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-2xs);
    font-size: var(--wa-font-size-xs);
    color: var(--esphome-primary);
    text-decoration: underline;
  }

  .docs-link:hover {
    text-decoration: none;
  }

  .docs-link wa-icon {
    font-size: 14px;
  }

  esphome-config-entry-form {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
  }

  /* "Show advanced settings" toggle row, shown below the form when
     the section has any advanced entries (at any depth). */
  .advanced-toggle-row {
    display: flex;
    justify-content: flex-start;
    margin-top: var(--wa-space-s);
    font-size: var(--wa-font-size-s);
  }

  .advanced-toggle-row wa-switch {
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-quiet);
  }

  .actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: var(--wa-space-s);
    padding-top: var(--wa-space-s);
  }

  /* When the delete button is hidden (e.g. esphome:), the save button
   * should still hug the right edge — :only-child gets pushed to the
   * right by the space-between layout naturally. */
  .actions > :only-child {
    margin-left: auto;
  }

  .save-button {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: none;
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
    padding: var(--wa-space-xs) var(--wa-space-m);
    border-radius: var(--wa-border-radius-m);
    cursor: pointer;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    font-family: inherit;
  }

  .save-button:hover:not(:disabled) {
    opacity: 0.9;
  }

  .save-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .save-button wa-icon {
    font-size: 16px;
  }

  .delete-button {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: transparent;
    color: var(--esphome-error);
    border: var(--wa-border-width-s) solid
      color-mix(in srgb, var(--esphome-error), transparent 70%);
    padding: var(--wa-space-xs) var(--wa-space-m);
    border-radius: var(--wa-border-radius-m);
    cursor: pointer;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    font-family: inherit;
    transition: background 0.12s, border-color 0.12s;
  }

  .delete-button:hover:not(:disabled) {
    background: color-mix(in srgb, var(--esphome-error), transparent 90%);
    border-color: var(--esphome-error);
  }

  .delete-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .delete-button wa-icon {
    font-size: 16px;
  }

  .error {
    color: var(--esphome-error);
    font-size: var(--wa-font-size-s);
  }

  .loading {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--wa-space-xl);
  }

  /* Stand-in shown when a section has no editable form fields
     (substitutions, globals, packages) — tells the user to edit
     this part via the YAML pane instead of presenting an empty
     form. Includes a "Show YAML editor" CTA when the pane is
     hidden by the current layout. */
  .yaml-only-notice {
    display: flex;
    align-items: flex-start;
    gap: var(--wa-space-s);
    padding: var(--wa-space-s) var(--wa-space-m);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-lowered);
    border-radius: var(--wa-border-radius-m);
    color: var(--wa-color-text-normal);
    font-size: var(--wa-font-size-s);
    line-height: 1.5;
  }

  .yaml-only-notice wa-icon {
    flex-shrink: 0;
    font-size: 20px;
    color: var(--esphome-primary);
  }

  .yaml-only-notice-body {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-s);
    flex: 1;
    min-width: 0;
  }

  .yaml-only-notice p {
    margin: 0;
  }

  .yaml-only-notice-cta {
    align-self: flex-start;
    padding: var(--wa-space-2xs) var(--wa-space-m);
    border: var(--wa-border-width-s) solid var(--esphome-primary);
    border-radius: var(--wa-border-radius-m);
    background: transparent;
    color: var(--esphome-primary);
    font-family: inherit;
    font-size: inherit;
    font-weight: var(--wa-font-weight-bold);
    cursor: pointer;
    transition: background 0.12s, color 0.12s;
  }

  .yaml-only-notice-cta:hover {
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
  }
`;function ej(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}(0,m.C)({"content-save":a.mdiContentSave,delete:a.mdiDelete,"information-outline":a.mdiInformationOutline,"open-in-new":a.mdiOpenInNew});let eP=new Set(["esphome"]),eD=new Set(["packages"]);class eO extends r.WF{get _showAdvanced(){return this._advancedShownSections.has(this.sectionKey)}_setShowAdvanced(e){let t=new Set(this._advancedShownSections);e?t.add(this.sectionKey):t.delete(this.sectionKey),this._advancedShownSections=t}updated(e){(e.has("sectionKey")||e.has("configuration")||e.has("fromLine"))&&this.sectionKey&&this.configuration&&this._loadConfig()}_resolveSpliceContext(e){let t=A(this.yaml,this.sectionKey,this.fromLine);return void 0===t?(this._error=this._localize(e),null):{yaml:this.yaml,fromLine:t}}reload(){!this._dirty&&this.sectionKey&&this.configuration&&this._loadConfig()}async _loadConfig(){let e=++this._loadId;this._loading=!0,this._error="",this._config=null,this._dirty=!1;try{let t=this.board?.esphome.platform,i=await this._api.getComponent(this.sectionKey,t);if(e!==this._loadId)return;if(!i){this._error=this._localize("device.unknown_section",{key:this.sectionKey}),this._loading=!1;return}let o=this.yaml;if(e!==this._loadId)return;this._config={section_key:this.sectionKey,section_type:"core",title:i.name,description:i.description,docs_url:i.docs_url,icon:"",image_url:i.image_url,entries:i.config_entries};let a=A(o,this.sectionKey,this.fromLine);this._values=function(e,t,i){let o=e.split("\n"),a=Object.create(null),r=eL(o,t,i);if(r<0)return a;let n=e$.test(o[r]),s=n?"    ":"  ",l=ek(s);if(n){let e=o[r].match(ex);if(e){let t=e[2].trim();""!==t&&(a[e[1]]=eS(t))}}let d=`${s}  - `,c=ez(s);for(let e=r+1;e<o.length;e++){let t=o[e];if(""===t.trim())continue;if(n){if(e$.test(t)||/^[a-zA-Z]/.test(t))break}else if(/^[a-zA-Z]/.test(t))break;let i=t.match(l);if(!i)continue;let r=i[1],p=i[2].trim();if(""===p){let t=e+1;for(;t<o.length&&""===o[t].trim();)t++;if(t>=o.length)continue;let i=o[t];if(i.startsWith(d)){let{items:t,endIdx:i}=eE(o,e+1,d,c);t.length>0&&(a[r]=t,e=i-1);continue}let n=`${s}  `;if(i.startsWith(n)){let t=function e(t,i,o){let a=ek(o),r=`${o}  - `,n=ez(o),s=Object.create(null),l=i;for(;l<t.length;){let i=t[l];if(""===i.trim()){l++;continue}if(!i.startsWith(o))break;let d=i.match(a);if(!d){l++;continue}let c=d[1],p=d[2].trim();if(""===p){let i=l+1;for(;i<t.length&&""===t[i].trim();)i++;if(i<t.length&&t[i].startsWith(r)){let{items:e,endIdx:i}=eE(t,l+1,r,n);s[c]=e,l=i;continue}let a=`${o}  `;if(i<t.length&&t[i].startsWith(a)){let i=e(t,l+1,a);Object.keys(i.values).length>0&&(s[c]=i.values),l=i.endIdx;continue}l++;continue}p.startsWith("[")&&p.endsWith("]")?s[c]=eq(p):s[c]=eS(p),l++}return{values:s,endIdx:l}}(o,e+1,n);Object.keys(t.values).length>0&&(a[r]=t.values),e=t.endIdx-1}continue}if(p.startsWith("[")&&p.endsWith("]")){a[r]=eq(p);continue}a[r]=eS(p)}return a}(o,this.sectionKey,a),this._resolvedFromLine=a,this._presentComponents=P(o)}catch(i){if(e!==this._loadId)return;let t=i instanceof Error?i.message:"";this._error=t.includes("timed out")?this._localize("device.load_config_error"):t||this._localize("device.load_config_error")}finally{e===this._loadId&&(this._loading=!1)}}_onImageError(e){let t=e.target,i="/assets/board/default.svg";t.src===window.location.origin+i||t.src.endsWith(i)||(t.src=i)}render(){if(this._loading)return(0,r.qy)`<div class="loading"><wa-spinner></wa-spinner></div>`;if(this._error&&!this._config)return(0,r.qy)`<p class="error">${this._error}</p>`;if(!this._config)return r.s6;let e=this._showAdvanced,t=function e(t){for(let i of t)if(i.advanced||i.type===l.Hh.NESTED&&e(i.config_entries??[]))return!0;return!1}(this._config.entries),i=eD.has(this.sectionKey)||0===this._config.entries.length,o=!eP.has(this.sectionKey);return(0,r.qy)`
      <div class="section-header">
        <div class="section-header-info">
          <div class="section-header-title-row">
            <h3 class="section-title">${this._config.title}</h3>
            ${this._config.docs_url?(0,r.qy)`<a
                  class="docs-link"
                  href=${this._config.docs_url}
                  target="_blank"
                  rel="noreferrer"
                >
                  ${this._localize("device.docs")}
                  <wa-icon library="mdi" name="open-in-new"></wa-icon>
                </a>`:r.s6}
          </div>
          <p class="section-desc">
            ${(0,y.G)(this._config.description)}
          </p>
        </div>
        <div class="section-image">
          <img
            src=${this._config.image_url||"/assets/board/default.svg"}
            alt=${this._config.title}
            referrerpolicy="no-referrer"
            @error=${this._onImageError}
          />
        </div>
      </div>
      ${i?(0,r.qy)`<div class="yaml-only-notice" role="note">
              <wa-icon library="mdi" name="information-outline"></wa-icon>
              <div class="yaml-only-notice-body">
                <p>${this._localize("device.yaml_only_section")}</p>
                ${this.yamlPaneVisible?r.s6:(0,r.qy)`<button
                      type="button"
                      class="yaml-only-notice-cta"
                      @click=${this._onShowYamlEditor}
                    >
                      ${this._localize("device.show_yaml_editor")}
                    </button>`}
              </div>
            </div>
            ${o?(0,r.qy)`<div class="actions">
                  ${this._renderDeleteButton()}
                </div>`:r.s6}`:(0,r.qy)`
            <esphome-config-entry-form
              .entries=${this._config.entries}
              .values=${this._values}
              .errors=${this._fieldErrors}
              .board=${this.board}
              .yaml=${this.yaml}
              .fromLine=${this._resolvedFromLine}
              .presentComponents=${this._presentComponents}
              ?disabled=${this._saving}
              ?show-advanced=${e}
              @value-change=${this._onValueChange}
            ></esphome-config-entry-form>
            ${t?(0,r.qy)`<div class="advanced-toggle-row">
                  <wa-switch
                    ?checked=${e}
                    @change=${e=>this._setShowAdvanced(e.target.checked)}
                  >
                    ${this._localize("device.show_advanced")}
                  </wa-switch>
                </div>`:r.s6}
            ${this._error?(0,r.qy)`<p class="error">${this._error}</p>`:r.s6}
            <div class="actions">
              ${o?this._renderDeleteButton():r.s6}
              <button
                class="save-button"
                ?disabled=${this._saving||!this._dirty}
                @click=${this._onSave}
              >
                <wa-icon library="mdi" name="content-save"></wa-icon>
                ${this._saving?this._localize("device.saving"):this._localize("device.save")}
              </button>
            </div>
          `}
      ${o?(0,r.qy)`<esphome-confirm-dialog
            heading=${this._localize("device.delete_section")}
            confirm-label=${this._localize("device.delete_section")}
            message=${this._localize("device.confirm_delete_section",{name:this._config.title})}
            destructive
            @confirm=${this._onDeleteConfirmed}
          ></esphome-confirm-dialog>`:r.s6}
    `}_renderDeleteButton(){return(0,r.qy)`<button
      class="delete-button"
      ?disabled=${this._saving||this._deleting}
      @click=${this._onDeleteClick}
    >
      <wa-icon library="mdi" name="delete"></wa-icon>
      ${this._localize("device.delete_section")}
    </button>`}_onDeleteClick(){this._confirmDialog?.open()}async _onDeleteConfirmed(){if(!this._config)return;let e=this._resolveSpliceContext("device.section_delete_error");if(!e)return;this._deleting=!0,this._error="";let t=this._config.title;try{let i=function(e,t,i){let o=e.split("\n"),{start:a,end:r}=eA(o,t,i);if(a<0)return e;let n=e$.test(o[a]);if(o.splice(a,r-a),n){let e=a-1;for(;e>=0&&!/^[a-zA-Z]/.test(o[e]);)e--;if(e>=0){let t=!1,i=o.length;for(let a=e+1;a<o.length;a++){if(/^[a-zA-Z]/.test(o[a])){i=a;break}if(""!==o[a].trim()){t=!0;break}}t||o.splice(e,i-e)}}return o.join("\n")}(e.yaml,this.sectionKey,e.fromLine);if(i===e.yaml){this._error=this._localize("device.section_delete_error");return}await this._api.updateConfig(this.configuration,i),this._dirty=!1,this.dispatchEvent(new CustomEvent("yaml-updated",{detail:{yaml:i},bubbles:!0,composed:!0})),this.dispatchEvent(new CustomEvent("section-select",{detail:{sectionKey:null},bubbles:!0,composed:!0})),s.A.success(this._localize("device.section_deleted",{name:t}),{richColors:!0})}catch(e){this._error=e instanceof Error?e.message:this._localize("device.section_delete_error")}finally{this._deleting=!1}}_onShowYamlEditor(){this.dispatchEvent(new CustomEvent("show-yaml-editor",{bubbles:!0,composed:!0}))}_onValueChange(e){let{path:t,value:i}=e.detail;this._values=T(this._values,t,i),this._dirty=!0;let o=t.join(".");if(this._fieldErrors.has(o)){let e=new Map(this._fieldErrors);e.delete(o),this._fieldErrors=e}}async _scrollFirstErrorIntoView(e){if(!this._config)return;let t=function e(t,i,o=[],a=!1){for(let r of t){let t=[...o,r.key],n=a||r.advanced;if(r.type===l.Hh.NESTED){let o=e(r.config_entries??[],i,t,n);if(o)return o;continue}if(i.has(t.join(".")))return{path:t,hasAdvancedAncestor:n}}return null}(this._config.entries,e);if(!t)return;let{path:i,hasAdvancedAncestor:o}=t;if(o&&!this._showAdvanced&&(this._setShowAdvanced(!0),await this.updateComplete),i.length>1){for(let e=1;e<i.length;e++)this._form?.openNested(i.slice(0,e).join("."));await this.updateComplete,await this._form?.updateComplete}let a=this._form?.shadowRoot;if(!a)return;let r=a.querySelector(`[data-field-key="${CSS.escape(i.join("."))}"]`);if(!r)return;r.scrollIntoView({behavior:"smooth",block:"center"});let n=r.querySelector("input, select, textarea, wa-select, wa-switch, [tabindex]");n?.focus({preventScroll:!0})}async _onSave(){if(!this._config)return;let e=(0,F.JK)(this._config.entries,this._values,this._presentComponents);if(e.size>0){this._fieldErrors=e,await this.updateComplete,this._scrollFirstErrorIntoView(e);return}this._fieldErrors=new Map;let t=this._resolveSpliceContext("device.save_error");if(t){this._saving=!0,this._error="";try{let e=function(e,t,i,o){let a=e.split("\n"),{start:r,end:n}=eA(a,t,o);if(r<0)return e;let s=e$.test(a[r]),l=i,d=a[r];if(s){let e=d.match(ex);if(e){let t=e[1];if(Object.prototype.hasOwnProperty.call(i,t)){let e=d.match(/^(\s+)-(\s+)/),o=e[1],a=`${o}-${e[2]}`;if(function(e){if(null==e)return!1;let t=typeof e;return"string"===t||"number"===t||"boolean"===t}(i[t])){d=`${a}${t}: ${D(i[t])}`;let{[t]:e,...o}=i;l=o}else d=`${o}-`}}}let c=[d,...j(l,s?"    ":"  ")];return a.splice(r,n-r,...c),a.join("\n")}(t.yaml,this.sectionKey,this._values,t.fromLine),i=this._config.title;this._api.updateConfig(this.configuration,e).catch(e=>{this._error=e instanceof Error?e.message:this._localize("device.save_error")}),this._dirty=!1,this.dispatchEvent(new CustomEvent("yaml-updated",{detail:{yaml:e},bubbles:!0,composed:!0})),s.A.success(this._localize("device.section_saved_toast",{title:i}),{richColors:!0})}catch(e){this._error=e instanceof Error?e.message:this._localize("device.save_error")}finally{this._saving=!1}}}constructor(...e){super(...e),this._localize=e=>e,this.configuration="",this.sectionKey="",this.yaml="",this.yamlPaneVisible=!0,this.board=null,this._config=null,this._values={},this._loading=!1,this._saving=!1,this._dirty=!1,this._loadId=0,this._error="",this._fieldErrors=new Map,this._advancedShownSections=new Set,this._presentComponents=new Set,this._deleting=!1}}function eI(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eO.styles=[p.G,_.z,eM],ej([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],eO.prototype,"_localize",void 0),ej([(0,o.Fg)({context:c.Ie})],eO.prototype,"_api",void 0),ej([(0,n.MZ)()],eO.prototype,"configuration",void 0),ej([(0,n.MZ)()],eO.prototype,"sectionKey",void 0),ej([(0,n.MZ)({type:Number})],eO.prototype,"fromLine",void 0),ej([(0,n.MZ)()],eO.prototype,"yaml",void 0),ej([(0,n.MZ)({type:Boolean})],eO.prototype,"yamlPaneVisible",void 0),ej([(0,n.MZ)({attribute:!1})],eO.prototype,"board",void 0),ej([(0,n.wk)()],eO.prototype,"_config",void 0),ej([(0,n.wk)()],eO.prototype,"_values",void 0),ej([(0,n.wk)()],eO.prototype,"_loading",void 0),ej([(0,n.wk)()],eO.prototype,"_saving",void 0),ej([(0,n.wk)()],eO.prototype,"_dirty",void 0),ej([(0,n.wk)()],eO.prototype,"_error",void 0),ej([(0,n.wk)()],eO.prototype,"_fieldErrors",void 0),ej([(0,n.wk)()],eO.prototype,"_advancedShownSections",void 0),ej([(0,n.wk)()],eO.prototype,"_presentComponents",void 0),ej([(0,n.wk)()],eO.prototype,"_resolvedFromLine",void 0),ej([(0,n.P)("esphome-config-entry-form")],eO.prototype,"_form",void 0),ej([(0,n.P)("esphome-confirm-dialog")],eO.prototype,"_confirmDialog",void 0),ej([(0,n.wk)()],eO.prototype,"_deleting",void 0),eO=ej([(0,n.EM)("esphome-device-section-config")],eO),(0,m.C)({"open-in-new":a.mdiOpenInNew,memory:a.mdiMemory,"arrow-decision-outline":a.mdiArrowDecisionOutline,"arrow-left":a.mdiArrowLeft,"cog-outline":a.mdiCogOutline,close:a.mdiClose,"party-popper":a.mdiPartyPopper,"plus-circle-outline":a.mdiPlusCircleOutline});class eF extends r.WF{updated(e){if(e.has("yaml")&&this.selectedSection&&this._sectionConfig){var t,i;(this._reloadTimer&&(clearTimeout(this._reloadTimer),this._reloadTimer=null),t=e.get("yaml"),i=this.yaml,t||!i)?this._reloadTimer=setTimeout(()=>this._sectionConfig?.reload(),1e3):this._sectionConfig.reload()}}connectedCallback(){super.connectedCallback(),this.addEventListener("request-add-component",this._onRequestAddComponent)}disconnectedCallback(){super.disconnectedCallback(),this._reloadTimer&&clearTimeout(this._reloadTimer),this.removeEventListener("request-add-component",this._onRequestAddComponent)}render(){let e=this.board;return(0,r.qy)`
      ${!this.selectedSection&&e?(0,r.qy)`
            <div class="board-header">
              <div class="board-info">
                <h3 class="board-name">${e.name}</h3>
                <div class="board-tags">
                  ${e.tags.map(e=>(0,r.qy)`<wa-badge variant="brand" pill>${e}</wa-badge>`)}
                  <a
                    class="board-info-link"
                    href=${e.docs_url}
                    target="_blank"
                    rel="noreferrer"
                  >
                    ${this._localize("device.more_info")}
                    <wa-icon library="mdi" name="open-in-new"></wa-icon>
                  </a>
                </div>
                <p class="board-description">
                  ${(0,y.G)(e.description)}
                </p>
              </div>
              <div class="board-image">
                <img
                  src=${this._boardImageUrl(e)}
                  alt=${e.name}
                  referrerpolicy="no-referrer"
                  @error=${this._onImageError}
                />
              </div>
            </div>
            <div class="board-separator"></div>
          `:r.s6}
      ${this.selectedSection?(0,r.qy)`
            <esphome-device-section-config
              .configuration=${this.configuration}
              .sectionKey=${this.selectedSection}
              .fromLine=${this.selectedFromLine}
              .yaml=${this.yaml}
              .board=${this.board}
              ?yamlPaneVisible=${this.yamlPaneVisible}
            ></esphome-device-section-config>
          `:(0,r.qy)`
            ${this.justCreated?this._renderWelcomeBanner():r.s6}
            ${this._renderStepSection({title:this._localize("device.step_core"),desc:this._localize("device.step_core_desc"),icon:"cog-outline",action:this._localize("device.show_core_configuration"),section:"core"})}
            ${this._renderStepSection({title:this._localize("device.step_components"),desc:this._localize("device.step_components_desc"),icon:"memory",action:this._localize("device.show_components"),section:"components"})}
            ${this._renderStepSection({title:this._localize("device.step_automations"),desc:this._localize("device.step_automations_desc"),icon:"arrow-decision-outline",action:this._localize("device.show_automations"),section:"automations"})}
          `}

      <esphome-add-config-dialog
        .boardName=${e?.name??""}
        .configuration=${this.configuration}
        .platform=${e?.esphome.platform??""}
        .board=${e}
        .yaml=${this.yaml}
      ></esphome-add-config-dialog>
      <esphome-add-component-dialog
        .boardName=${e?.name??""}
        .configuration=${this.configuration}
        .platform=${e?.esphome.platform??""}
        .board=${e}
        .yaml=${this.yaml}
      ></esphome-add-component-dialog>
      ${r.s6}
    `}_renderStepSection(e){return(0,r.qy)`
      <div class="step-section">
        <h4 class="step-title">${e.title}</h4>
        <p class="step-desc">${e.desc}</p>
        <button
          type="button"
          class="action-item"
          @click=${()=>this._onShowNavSection(e.section)}
        >
          <div>
            <wa-icon library="mdi" name=${e.icon}></wa-icon>
            <p>${e.action}</p>
          </div>
          <wa-icon library="mdi" name="arrow-left"></wa-icon>
        </button>
      </div>
    `}_onShowNavSection(e){this.dispatchEvent(new CustomEvent("nav-section-show",{detail:{section:e},bubbles:!0,composed:!0}))}_renderWelcomeBanner(){return this.board?(0,r.qy)`
      <wa-callout class="welcome-banner" variant="brand" role="status">
        <wa-icon slot="icon" library="mdi" name="party-popper"></wa-icon>
        <p class="welcome-banner-title">
          ${this._localize("device.welcome_banner_title",{name:this.board.name})}
        </p>
        <p class="welcome-banner-text">${this._localize("device.welcome_banner_body")}</p>
        <button
          type="button"
          class="welcome-banner-close"
          aria-label=${this._localize("device.welcome_banner_dismiss")}
          @click=${this._onDismissWelcome}
        >
          <wa-icon library="mdi" name="close"></wa-icon>
        </button>
      </wa-callout>
    `:r.s6}_onDismissWelcome(){this.dispatchEvent(new CustomEvent("just-created-dismiss",{bubbles:!0,composed:!0}))}_boardImageUrl(e){return e.images.length>0?e.images[0]:"/assets/board/default.svg"}_onImageError(e){let t=e.target,i="/assets/board/default.svg";t.src===window.location.origin+i||t.src.endsWith(i)||(t.src=i)}constructor(...e){super(...e),this._localize=e=>e,this.board=null,this.yaml="",this.configuration="",this.justCreated=!1,this.yamlPaneVisible=!0,this.selectedSection=null,this._reloadTimer=null,this._onRequestAddComponent=e=>{let t=e.detail;t?.domain&&(e.stopPropagation(),this._addComponentDialog?.openWithSearch(t.domain))}}}function eT(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eF.styles=[p.G,(0,r.AH)`
      :host {
        display: flex;
        flex-direction: column;
      }

      .board-header {
        display: flex;
        flex-direction: row;
        align-items: center;
        width: 100%;
        gap: var(--wa-space-l);
      }

      .board-info {
        display: flex;
        flex-direction: column;
        flex: 1;
        gap: var(--wa-space-s);
        min-width: 0;
      }

      .board-name {
        margin: 0;
      }

      .board-image {
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 140px;
        height: 100px;
        padding: var(--wa-space-s);
        background: var(--wa-color-surface-lowered);
        border-radius: var(--wa-border-radius-l);
        box-sizing: border-box;
      }

      .board-image img {
        width: 100%;
        height: 100%;
        object-fit: contain;
      }

      .board-tags {
        display: flex;
        flex-wrap: wrap;
        gap: var(--wa-space-2xs);
      }

      .board-info-link {
        display: inline-flex;
        align-items: center;
        gap: var(--wa-space-2xs);
        font-size: var(--wa-font-size-xs);
        color: var(--esphome-primary);
        text-decoration: underline;
        margin-left: 10px;
      }

      .board-info-link:hover {
        text-decoration: none;
      }

      .board-description {
        margin: 0;
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-quiet);
        line-height: 1.5;
      }

      .board-separator {
        height: 1px;
        background-color: var(--wa-color-surface-lowered);
        width: 100%;
        margin-top: var(--wa-space-m);
      }

      /* ─── Just-created welcome banner ─── */

      .welcome-banner {
        margin-top: var(--wa-space-m);
      }

      .welcome-banner-title {
        margin: var(--wa-space-xs) 0 var(--wa-space-2xs);
        font-size: var(--wa-font-size-m);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      .welcome-banner-text {
        margin: 0;
        font-size: var(--wa-font-size-s);
        color: var(--wa-color-text-normal);
        line-height: 1.5;
      }

      .welcome-banner-close {
        position: absolute;
        top: var(--wa-space-2xs);
        right: var(--wa-space-2xs);
        background: transparent;
        border: none;
        padding: 4px;
        cursor: pointer;
        color: var(--wa-color-text-quiet);
        border-radius: var(--wa-border-radius-s);
        transition:
          background 0.12s,
          color 0.12s;
      }

      .welcome-banner-close:hover {
        background: color-mix(in srgb, var(--esphome-primary), transparent 80%);
        color: var(--wa-color-text-normal);
      }

      .welcome-banner-close wa-icon {
        font-size: 18px;
        display: block;
      }

      /* ─── Step CTA ─── */

      .step-section {
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-s);
        padding-top: var(--wa-space-m);
      }

      .step-title {
        margin: 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      .step-desc {
        margin: 0;
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-quiet);
        line-height: 1.5;
      }

      .action-item {
        padding: var(--wa-space-2xs) var(--wa-space-m);
        border-radius: var(--wa-border-radius-m);
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: transparent;
        color: var(--esphome-primary);
        border: var(--wa-border-width-s) solid var(--esphome-primary);
        gap: var(--wa-space-s);
        cursor: pointer;
        user-select: none;
        font-family: inherit;
        font-size: inherit;
        transition:
          background 0.12s,
          color 0.12s;
        align-self: flex-start;
        /* Equal width across the three step CTAs so they line up
           visually no matter how long the longest label is. */
        width: 280px;
        max-width: 100%;
        margin-top: var(--wa-space-s);
      }

      .action-item:hover {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
      }

      .action-item:focus-visible {
        outline: 2px solid var(--esphome-primary);
        outline-offset: 2px;
      }

      .action-item p {
        margin: var(--wa-space-xs) 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .action-item wa-icon {
        font-size: var(--wa-font-size-l);
      }

      .action-item div {
        display: flex;
        align-items: center;
        gap: var(--wa-space-2xs);
      }
    `],eI([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],eF.prototype,"_localize",void 0),eI([(0,n.MZ)({attribute:!1})],eF.prototype,"board",void 0),eI([(0,n.MZ)()],eF.prototype,"yaml",void 0),eI([(0,n.MZ)()],eF.prototype,"configuration",void 0),eI([(0,n.MZ)({type:Boolean})],eF.prototype,"justCreated",void 0),eI([(0,n.MZ)({type:Boolean})],eF.prototype,"yamlPaneVisible",void 0),eI([(0,n.MZ)({attribute:!1})],eF.prototype,"selectedSection",void 0),eI([(0,n.MZ)({type:Number})],eF.prototype,"selectedFromLine",void 0),eI([(0,n.P)("esphome-device-section-config")],eF.prototype,"_sectionConfig",void 0),eI([(0,n.P)("esphome-add-component-dialog")],eF.prototype,"_addComponentDialog",void 0),eI([(0,n.P)("esphome-add-automation-dialog")],eF.prototype,"_addAutomationDialog",void 0),eI([(0,n.P)("esphome-add-config-dialog")],eF.prototype,"_addConfigDialog",void 0),eF=eI([(0,n.EM)("esphome-device-board-info")],eF),(0,m.C)({"arrow-collapse":a.mdiArrowCollapse,"arrow-expand":a.mdiArrowExpand,"content-save":a.mdiContentSave,"layout-left":a.mdiDockLeft,"layout-right":a.mdiDockRight,"layout-split":a.mdiViewSplitHorizontal,upload:a.mdiUpload,"vector-difference":a.mdiVectorDifference});class eR extends r.WF{connectedCallback(){super.connectedCallback(),this._isMobile=this._mql.matches,this._mql.addEventListener("change",this._onMqlChange),window.addEventListener("keydown",this._onGlobalKeyDown)}disconnectedCallback(){super.disconnectedCallback(),this._mql.removeEventListener("change",this._onMqlChange),window.removeEventListener("keydown",this._onGlobalKeyDown)}render(){let e=this._isMobile&&"both"===this.layout?"right":this.layout,t=!this._isMobile&&this.navCollapsed&&"right"===e,i=this._localize("device.editor_title_ready",{name:this.deviceTitle});return(0,r.qy)`
      <section class="card">
        <header class="card-header ${t?"card-header--compact":""}">
          <slot name="mobile-menu"></slot>
          <div class="editor-header-main">
            <h2 class="editor-header-title">${i}</h2>
          </div>
          <div class="header-actions">
            ${this._showDiffButton?(0,r.qy)`<button
                  type="button"
                  class="diff-toggle"
                  aria-pressed=${this._showDiff}
                  ?disabled=${this.yaml===this.savedYaml&&!this._showDiff}
                  @click=${this._toggleDiff}
                  title=${this._showDiff?this._localize("device.diff_view_editor"):this._localize("device.diff_view_diff")}
                >
                  <wa-icon library="mdi" name="vector-difference"></wa-icon>
                </button>`:r.s6}
            <div
              class="layout-toggle"
              aria-label=${this._localize("device.editor_layout_label")}
            >
              <button
                type="button"
                aria-pressed=${"left"===e}
                @click=${()=>this._setLayout("left")}
                title=${this._localize("device.layout_components_only")}
              >
                <wa-icon library="mdi" name="layout-left"></wa-icon>
              </button>
              <button
                class="split-btn"
                type="button"
                aria-pressed=${"both"===e}
                @click=${()=>this._setLayout("both")}
                title=${this._localize("device.layout_split")}
              >
                <wa-icon library="mdi" name="layout-split"></wa-icon>
              </button>
              <button
                type="button"
                aria-pressed=${"right"===e}
                @click=${()=>this._setLayout("right")}
                title=${this._localize("device.layout_yaml_only")}
              >
                <wa-icon library="mdi" name="layout-right"></wa-icon>
              </button>
            </div>
            ${this._isMobile?r.s6:(0,r.qy)`<button
                  type="button"
                  class="fullscreen-toggle"
                  aria-pressed=${this._fullscreen}
                  @click=${this._toggleFullscreen}
                  title=${this._localize(this._fullscreen?"device.editor_collapse":"device.editor_expand")}
                >
                  <wa-icon
                    library="mdi"
                    name=${this._fullscreen?"arrow-collapse":"arrow-expand"}
                  ></wa-icon>
                </button>`}
          </div>
        </header>
        <div class="card-body">
          <div class="editor-floating-actions">
            ${this.hasUpdateAvailable?(0,r.qy)`<button
                  type="button"
                  class="install-fab"
                  ?disabled=${this.busy}
                  @click=${this._onUpdate}
                  title=${this._localize("dashboard.update")}
                >
                  <wa-icon library="mdi" name="upload"></wa-icon>
                  ${this._localize("dashboard.update")}
                </button>`:this.hasPendingChanges?(0,r.qy)`<button
                    type="button"
                    class="install-fab"
                    ?disabled=${this.busy}
                    @click=${this._onInstall}
                    title=${this._localize("dashboard.install")}
                  >
                    <wa-icon library="mdi" name="upload"></wa-icon>
                    ${this._localize("dashboard.install")}
                  </button>`:r.s6}
            <button
              type="button"
              class="save-button"
              ?disabled=${this.yaml===this.savedYaml}
              @click=${this._onSave}
              title=${this._localize("device.save_yaml")}
            >
              <wa-icon library="mdi" name="content-save"></wa-icon>
              ${this._localize("device.save")}
            </button>
          </div>
          <div class=${`editor-layout ${"both"===e?"editor-layout--both":"left"===e?"editor-layout--left":"editor-layout--right"}`}>
            <div class="editor-pane editor-pane--left">
              <esphome-device-board-info
                .board=${this.board}
                .yaml=${this.yaml}
                .configuration=${this.configuration}
                .selectedSection=${this.selectedSection}
                .selectedFromLine=${this.selectedFromLine}
                .justCreated=${this.justCreated}
                ?yamlPaneVisible=${"left"!==e}
                @show-yaml-editor=${this._onShowYamlEditor}
              ></esphome-device-board-info>
            </div>
            ${"both"===e?(0,r.qy)`<div class="pane-divider"></div>`:r.s6}
            <div class="editor-pane editor-pane--right">
              <div class="editor-pane-body">
                ${this._showDiff?(0,r.qy)`<esphome-yaml-diff
                      .oldValue=${this.savedYaml}
                      .newValue=${this.yaml}
                    ></esphome-yaml-diff>`:(0,r.qy)`<esphome-yaml-editor
                      .value=${this.yaml}
                      .configuration=${this.configuration}
                      .highlightRange=${this.highlightRange}
                      .scrollToHighlight=${this.scrollToHighlight}
                      @yaml-change=${this._onYamlChange}
                    ></esphome-yaml-editor>`}
              </div>
            </div>
          </div>
        </div>
      </section>
    `}_onSave(){this.dispatchEvent(new CustomEvent("save-yaml",{bubbles:!0,composed:!0}))}_toggleDiff(){this._showDiff=!this._showDiff}_onInstall(){this.dispatchEvent(new CustomEvent("install-device",{bubbles:!0,composed:!0}))}_onUpdate(){this.dispatchEvent(new CustomEvent("update-device",{bubbles:!0,composed:!0}))}updated(e){if(this._showDiff&&e.has("_showDiffButton")&&!this._showDiffButton){this._showDiff=!1;return}this._showDiff&&e.has("savedYaml")&&this.yaml===this.savedYaml&&(this._showDiff=!1)}_setLayout(e){this.dispatchEvent(new CustomEvent("layout-change",{detail:e,bubbles:!0,composed:!0}))}_toggleFullscreen(){this._fullscreen=!this._fullscreen}willUpdate(e){e.has("_fullscreen")&&(this.toggleAttribute("fullscreen",this._fullscreen),this._escape.set(this._fullscreen))}_onShowYamlEditor(e){e.stopPropagation(),this._setLayout("both")}_onYamlChange(e){this.dispatchEvent(new CustomEvent("yaml-change",{detail:e.detail,bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this.yaml="",this.layout="both",this.navCollapsed=!1,this.deviceTitle="",this.board=null,this.justCreated=!1,this._isMobile=!1,this._fullscreen=!1,this._mql=window.matchMedia("(max-width: 900px)"),this._onMqlChange=e=>{this._isMobile=e.matches},this._onGlobalKeyDown=e=>{(e.metaKey||e.ctrlKey)&&!e.shiftKey&&"s"===e.key.toLowerCase()&&(e.preventDefault(),this.yaml!==this.savedYaml&&this._onSave())},this._escape=new f.u(this,e=>{e.preventDefault(),this._fullscreen=!1}),this.highlightRange=null,this.scrollToHighlight=!1,this.configuration="",this.selectedSection=null,this.savedYaml="",this.hasPendingChanges=!1,this.hasUpdateAvailable=!1,this.busy=!1,this._showDiffButton=!1,this._showDiff=!1}}function eN(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eR.styles=[p.G,v],eT([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],eR.prototype,"_localize",void 0),eT([(0,n.MZ)()],eR.prototype,"yaml",void 0),eT([(0,n.MZ)()],eR.prototype,"layout",void 0),eT([(0,n.MZ)({type:Boolean})],eR.prototype,"navCollapsed",void 0),eT([(0,n.MZ)()],eR.prototype,"deviceTitle",void 0),eT([(0,n.MZ)({attribute:!1})],eR.prototype,"board",void 0),eT([(0,n.MZ)({type:Boolean})],eR.prototype,"justCreated",void 0),eT([(0,n.wk)()],eR.prototype,"_isMobile",void 0),eT([(0,n.wk)()],eR.prototype,"_fullscreen",void 0),eT([(0,n.MZ)({attribute:!1})],eR.prototype,"highlightRange",void 0),eT([(0,n.MZ)({type:Boolean})],eR.prototype,"scrollToHighlight",void 0),eT([(0,n.MZ)()],eR.prototype,"configuration",void 0),eT([(0,n.MZ)({attribute:!1})],eR.prototype,"selectedSection",void 0),eT([(0,n.MZ)({type:Number})],eR.prototype,"selectedFromLine",void 0),eT([(0,n.MZ)({attribute:!1})],eR.prototype,"savedYaml",void 0),eT([(0,n.MZ)({type:Boolean})],eR.prototype,"hasPendingChanges",void 0),eT([(0,n.MZ)({type:Boolean})],eR.prototype,"hasUpdateAvailable",void 0),eT([(0,n.MZ)({type:Boolean})],eR.prototype,"busy",void 0),eT([(0,o.Fg)({context:c.El,subscribe:!0}),(0,n.wk)()],eR.prototype,"_showDiffButton",void 0),eT([(0,n.wk)()],eR.prototype,"_showDiff",void 0),eR=eT([(0,n.EM)("esphome-device-editor")],eR),(0,m.C)({"chevron-down":a.mdiChevronDown,"chevron-up":a.mdiChevronUp,"chevron-right":a.mdiChevronRight,cog:a.mdiCog,"arrow-decision-outline":a.mdiArrowDecisionOutline,memory:a.mdiMemory,"plus-circle-outline":a.mdiPlusCircleOutline});class eZ extends r.WF{willUpdate(e){if((e.has("selectedKey")||e.has("yaml")||e.has("selectedFromLine"))&&this.yaml){if(!this.selectedKey){this._selectedLine=null,this._selectedRange=null;return}let e=[...q(this.yaml),...E(this.yaml)],t=e=>e.platform?(e.platform.startsWith(`${e.key}.`)?e.platform:`${e.key}.${e.platform}`)===this.selectedKey:e.key===this.selectedKey,i=(void 0!==this.selectedFromLine?e.find(e=>e.fromLine===this.selectedFromLine):void 0)??e.find(t);i&&(this._selectedLine=i.fromLine,this._selectedRange={fromLine:i.fromLine,toLine:i.toLine})}}render(){let{core:e,components:t,automations:i}=function(e){let t=[],i=[],o=[];for(let a of e)k.has(a.key)?t.push(a):z.has(a.key)?o.push(a):i.push(a);return{core:t,components:i,automations:o}}(q(this.yaml)),o=[...i,...E(this.yaml)].sort((e,t)=>e.fromLine-t.fromLine),a=[{label:this._localize("device.section_core"),desc:this._localize("device.section_core_desc"),items:e,category:"core",action:{label:this._localize("device.add_config"),icon:"cog",onClick:()=>this._addConfigDialog.open()}},{label:this._localize("device.section_components"),desc:this._localize("device.section_components_desc"),items:t,category:"component",action:{label:this._localize("device.add_component"),icon:"memory",onClick:()=>this._addComponentDialog.open()}},{label:this._localize("device.section_automations"),desc:this._localize("device.section_automations_desc"),items:o,category:"automation",action:{label:this._localize("device.add_automation"),icon:"arrow-decision-outline",onClick:()=>this._addAutomationDialog.open(),disabled:!0,disabledReason:this._localize("device.add_automation_unavailable")}}];return(0,r.qy)`
      <section class="card">
        <esphome-add-config-dialog
          .boardName=${this.boardName}
          .configuration=${this.configuration}
          .platform=${this.platform}
          .board=${this.board}
          .yaml=${this.yaml}
        ></esphome-add-config-dialog>
        <esphome-add-component-dialog
          .boardName=${this.boardName}
          .configuration=${this.configuration}
          .platform=${this.platform}
          .board=${this.board}
          .yaml=${this.yaml}
        ></esphome-add-component-dialog>
        ${r.s6}
        <header class="card-header">
          <h2 class="card-title">${this._localize("device.navigator_title")}</h2>
        </header>
        <div class="card-body">
          <p class="italic">${this._localize("device.navigator_desc")}</p>
          <div class="separator"></div>
          ${a.map(({label:e,desc:t,items:i,category:o,action:a},n)=>{let s=this.openSections.has(n);return(0,r.qy)`
              <div class="nav-content" @click=${()=>this._toggleSection(n)}>
                <p>${e}</p>
                <wa-icon
                  library="mdi"
                  name=${s?"chevron-up":"chevron-down"}
                ></wa-icon>
              </div>
              ${s?(0,r.qy)`
                    <div class="separator"></div>
                    <p class="italic">${t}</p>
                    ${i.length>0?(0,r.qy)`
                          <div class="nav-items">
                            ${i.map(e=>{let{primary:t,secondary:i}=this._navItemLabels(e,o);return(0,r.qy)`
                                <div
                                  class="nav-item ${this._selectedLine===e.fromLine?"nav-item--selected":""} ${this._hoveredLine===e.fromLine?"nav-item--hovered":""}"
                                  @mouseenter=${()=>this._onItemHover(e.fromLine,e.fromLine,e.toLine)}
                                  @mouseleave=${()=>this._onItemLeave()}
                                  @click=${()=>this._onItemClick(e)}
                                >
                                  <div class="nav-item-content">
                                    <p>${t}</p>
                                    ${i?(0,r.qy)`<span class="nav-item-subtitle"
                                          >${i}</span
                                        >`:r.s6}
                                  </div>
                                  <wa-icon library="mdi" name="chevron-right"></wa-icon>
                                </div>
                              `})}
                          </div>
                        `:r.s6}
                    <div
                      class="nav-items"
                      @click=${a.disabled?void 0:()=>a.onClick()}
                    >
                      <div
                        class="action-item ${a.disabled?"action-item--disabled":""}"
                        title=${a.disabled?a.disabledReason??"":""}
                        aria-disabled=${a.disabled?"true":"false"}
                      >
                        <div>
                          <wa-icon library="mdi" name=${a.icon}></wa-icon>
                          <p>${a.label}</p>
                        </div>
                        <wa-icon library="mdi" name="plus-circle-outline"></wa-icon>
                      </div>
                    </div>
                  `:r.s6}
              <div class="separator"></div>
            `})}
        </div>
      </section>
    `}_toggleSection(e){this.dispatchEvent(new CustomEvent("section-toggle",{detail:{index:e},bubbles:!0,composed:!0}))}_navItemLabels(e,t){let i;i=e.platform?e.platform.startsWith(`${e.key}.`)?e.platform:`${e.key}.${e.platform}`:e.key;let o=e.name||e.id;return{primary:i,secondary:o&&o!==i?o:void 0}}_onItemHover(e,t,i){this._hoveredLine=e,this._emitHighlight({fromLine:t,toLine:i},!1)}_onItemLeave(){this._hoveredLine=null,this._emitHighlight(this._selectedRange,!1)}_onItemClick(e){let t,{fromLine:i,toLine:o}=e;if(e.platform){let i=e.platform;t=i.startsWith(`${e.key}.`)?i:`${e.key}.${i}`}else t=e.key;this._selectedLine===i?(this.selectedKey=null,this._selectedLine=null,this._selectedRange=null,this._emitHighlight(this._hoveredLine===i?{fromLine:i,toLine:o}:null,!1),this._emitSectionSelect(null,void 0)):(this.selectedKey=t,this._selectedLine=i,this._selectedRange={fromLine:i,toLine:o},this._emitHighlight({fromLine:i,toLine:o},!0),this._emitSectionSelect(t,i))}_emitHighlight(e,t){this.dispatchEvent(new CustomEvent("yaml-highlight",{detail:{range:e,scroll:t},bubbles:!0,composed:!0}))}_emitSectionSelect(e,t){this.dispatchEvent(new CustomEvent("section-select",{detail:{sectionKey:e,fromLine:t},bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this.openSections=new Set,this.yaml="",this.board=null,this.boardName="",this.configuration="",this.platform="",this.selectedKey=null,this._selectedLine=null,this._selectedRange=null,this._hoveredLine=null}}function eB(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eZ.styles=[p.G,(0,r.AH)`
      :host {
        display: contents;
      }

      .card {
        background: var(--wa-color-surface-default);
        border-radius: var(--navigator-border-radius, var(--wa-border-radius-l));
        border: var(--navigator-border, var(--wa-border-width-s) solid var(--wa-color-surface-border));
        box-shadow: var(--wa-elevation-02);
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }

      .card-header {
        display: flex;
        align-items: center;
        padding: var(--wa-space-s) var(--wa-space-m);
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        flex-shrink: 0;
      }

      .card-title {
        margin: 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .card-body {
        flex: 1;
        min-height: 0;
        display: flex;
        flex-direction: column;
        overflow-y: auto;
      }

      .italic {
        font-style: italic;
        font-size: var(--wa-font-size-2xs);
        padding: 0 var(--wa-space-m);
        margin: var(--wa-space-xs) 0;
        flex-shrink: 0;
      }

      .separator {
        height: 1px;
        background: var(--wa-color-surface-border);
        margin: var(--wa-space-2xs) 0;
        flex-shrink: 0;
      }

      .nav-content {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 var(--wa-space-m);
        cursor: pointer;
        user-select: none;
        flex-shrink: 0;
      }

      .nav-content:hover p {
        color: var(--esphome-primary);
      }

      .nav-content p {
        margin: var(--wa-space-xs) 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .nav-content wa-icon {
        font-size: var(--wa-font-size-xl);
        color: var(--esphome-primary);
      }

      .nav-items {
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-2xs);
        padding: var(--wa-space-xs) var(--wa-space-m);
      }

      .nav-item {
        padding: 0 var(--wa-space-2xs);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-m);
        display: flex;
        align-items: center;
        justify-content: space-between;
        cursor: pointer;
        user-select: none;
        transition:
          background 0.1s,
          border-color 0.1s;
      }

      .nav-item:hover,
      .nav-item--hovered {
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        border-color: var(--esphome-primary);
      }

      .nav-item--selected {
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        border-color: var(--esphome-primary);
      }

      .nav-item-content {
        display: flex;
        flex-direction: column;
        min-width: 0;
        padding: var(--wa-space-xs) 0;
      }

      .nav-item-content p {
        margin: 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .nav-item-subtitle {
        font-size: var(--wa-font-size-2xs);
        color: var(--wa-color-text-quiet);
        font-weight: normal;
        margin: 0;
        line-height: 1.2;
      }

      .nav-item wa-icon {
        font-size: var(--wa-font-size-xl);
        color: var(--esphome-primary);
      }

      .action-item {
        padding: 0 var(--wa-space-2xs);
        border-radius: var(--wa-border-radius-m);
        display: flex;
        align-items: center;
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        justify-content: space-between;
        cursor: pointer;
        user-select: none;
        transition:
          background 0.1s,
          border-color 0.1s;
      }

      .action-item:hover,
      .action-item--hovered {
        opacity: 0.9;
      }

      /* Disabled action: greyed out, no hover, no pointer. The wrapper
         drops its click handler so the underlying dialog is never
         opened — this is purely visual confirmation. */
      .action-item--disabled,
      .action-item--disabled:hover {
        background: var(--wa-color-surface-lowered);
        color: var(--wa-color-text-quiet);
        cursor: not-allowed;
        opacity: 0.65;
      }

      .action-item--disabled wa-icon {
        color: var(--wa-color-text-quiet);
      }

      .action-item p {
        margin: var(--wa-space-xs) 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .action-item wa-icon {
        font-size: var(--wa-font-size-l);
      }

      .action-item div {
        display: flex;
        flex-direction: wrap;
        align-items: center;
        gap: var(--wa-space-2xs);
      }
    `],eN([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],eZ.prototype,"_localize",void 0),eN([(0,n.MZ)({attribute:!1})],eZ.prototype,"openSections",void 0),eN([(0,n.MZ)({attribute:!1})],eZ.prototype,"yaml",void 0),eN([(0,n.MZ)({attribute:!1})],eZ.prototype,"board",void 0),eN([(0,n.MZ)()],eZ.prototype,"boardName",void 0),eN([(0,n.MZ)()],eZ.prototype,"configuration",void 0),eN([(0,n.MZ)()],eZ.prototype,"platform",void 0),eN([(0,n.P)("esphome-add-config-dialog")],eZ.prototype,"_addConfigDialog",void 0),eN([(0,n.P)("esphome-add-component-dialog")],eZ.prototype,"_addComponentDialog",void 0),eN([(0,n.P)("esphome-add-automation-dialog")],eZ.prototype,"_addAutomationDialog",void 0),eN([(0,n.MZ)({attribute:!1})],eZ.prototype,"selectedKey",void 0),eN([(0,n.MZ)({attribute:!1})],eZ.prototype,"selectedFromLine",void 0),eN([(0,n.wk)()],eZ.prototype,"_selectedLine",void 0),eN([(0,n.wk)()],eZ.prototype,"_selectedRange",void 0),eN([(0,n.wk)()],eZ.prototype,"_hoveredLine",void 0),eZ=eN([(0,n.EM)("esphome-device-navigator")],eZ),i(5421),i(9137),(0,m.C)({"alert-outline":a.mdiAlertOutline,"content-save":a.mdiContentSave});class eH extends r.WF{open(){this._resolved=!1,this._dialog.open=!0}close(){this._dialog.open=!1}render(){return(0,r.qy)`
      <wa-dialog light-dismiss @wa-after-hide=${this._onAfterHide}>
        <div class="body">
          <div class="icon-wrap">
            <wa-icon library="mdi" name="alert-outline"></wa-icon>
          </div>
          <div class="text">
            <h2 class="heading">${this._localize("device.unsaved_title")}</h2>
            <p class="message">${this._localize("device.unsaved_message")}</p>
          </div>
        </div>
        <div class="actions">
          <button class="btn btn--ghost" @click=${this.close}>
            ${this._localize("layout.cancel")}
          </button>
          <button class="btn btn--discard" @click=${this._onDiscard}>
            ${this._localize("device.discard_changes")}
          </button>
          <button class="btn btn--save" @click=${this._onSave}>
            <wa-icon library="mdi" name="content-save"></wa-icon>
            ${this._localize("device.save_and_leave")}
          </button>
        </div>
      </wa-dialog>
    `}_onDiscard(){this._resolved=!0,this.close(),this.dispatchEvent(new CustomEvent("discard",{bubbles:!0,composed:!0}))}_onSave(){this._resolved=!0,this.close(),this.dispatchEvent(new CustomEvent("save",{bubbles:!0,composed:!0}))}_onAfterHide(){this._resolved||this.dispatchEvent(new CustomEvent("cancel",{bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this._resolved=!1}}function eU(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eH.styles=[p.G,(0,r.AH)`
      wa-dialog {
        --width: 460px;
      }

      wa-dialog::part(header),
      wa-dialog::part(footer) {
        display: none;
      }

      wa-dialog::part(body) {
        padding: 0;
      }

      .body {
        display: flex;
        gap: var(--wa-space-m);
        padding: var(--wa-space-l) var(--wa-space-l) var(--wa-space-m);
      }

      .icon-wrap {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 44px;
        height: 44px;
        border-radius: 50%;
        flex-shrink: 0;
        background: color-mix(in srgb, var(--esphome-warning), transparent 85%);
        color: var(--esphome-warning);
      }

      .icon-wrap wa-icon {
        font-size: 24px;
      }

      .text {
        flex: 1;
        min-width: 0;
      }

      .heading {
        margin: 0 0 var(--wa-space-2xs);
        font-size: var(--wa-font-size-m);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      .message {
        margin: 0;
        font-size: var(--wa-font-size-s);
        color: var(--wa-color-text-quiet);
        line-height: 1.5;
      }

      .actions {
        display: flex;
        justify-content: flex-end;
        gap: var(--wa-space-xs);
        padding: var(--wa-space-s) var(--wa-space-m) var(--wa-space-m);
      }

      .btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border-radius: var(--wa-border-radius-m);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
        font-family: inherit;
        cursor: pointer;
        border: none;
        transition: background 0.12s, color 0.12s;
      }

      .btn--ghost {
        background: transparent;
        color: var(--wa-color-text-quiet);
      }

      .btn--ghost:hover {
        background: var(--wa-color-surface-lowered);
        color: var(--wa-color-text-normal);
      }

      .btn--discard {
        background: transparent;
        color: var(--esphome-error);
      }

      .btn--discard:hover {
        background: color-mix(in srgb, var(--esphome-error), transparent 92%);
      }

      .btn--save {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        box-shadow: 0 1px 2px color-mix(in srgb, var(--esphome-primary), transparent 70%);
      }

      .btn--save:hover {
        background: color-mix(in srgb, var(--esphome-primary), black 10%);
      }

      .btn wa-icon {
        font-size: 16px;
      }
    `],eB([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],eH.prototype,"_localize",void 0),eB([(0,n.P)("wa-dialog")],eH.prototype,"_dialog",void 0),eH=eB([(0,n.EM)("esphome-unsaved-changes-dialog")],eH),(0,m.C)({"arrow-collapse-left":a.mdiArrowCollapseLeft,"arrow-collapse-right":a.mdiArrowCollapseRight});class eY extends r.WF{get _device(){return this._devices.find(e=>e.configuration===this.id)??null}_createInstallController(){let e=this;return new d({addController:t=>e.addController(t),removeController:t=>e.removeController(t),requestUpdate:()=>e.requestUpdate(),get updateComplete(){return e.updateComplete},get device(){return e._device},get commandDialog(){return e._commandDialog??null},get firmwareDialog(){return e._firmwareDialog??null}})}get _isDirty(){return this._yaml!==this._savedYaml}_resolvePendingLeave(e){let t=this._pendingLeaveResolve;this._pendingLeaveResolve=null,t?.(e)}async connectedCallback(){super.connectedCallback(),this._loadPreferences(),(0,u.f)(this._confirmLeave),window.addEventListener("beforeunload",this._onBeforeUnload),window.addEventListener("popstate",this._onPopState,{capture:!0}),window.addEventListener("keydown",this._onKeydown)}disconnectedCallback(){super.disconnectedCallback(),(0,u.f)(null),window.removeEventListener("beforeunload",this._onBeforeUnload),window.removeEventListener("popstate",this._onPopState,{capture:!0}),window.removeEventListener("keydown",this._onKeydown),this._resolvePendingLeave(!1)}_isTextEntry(e){if(!e)return!1;let t=e.tagName;if("INPUT"===t||"TEXTAREA"===t||"SELECT"===t||e.isContentEditable)return!0;let i=e;for(;i;){if("ESPHOME-YAML-EDITOR"===i.tagName)return!0;i=i.parentElement}return!1}updated(e){e.has("id")&&this.id&&(this._justCreated=(0,h.RI)(this.id),this._loadedBoardId=null,this._board=null,this._loadYaml());let t=this._device?.board_id??null;t&&t!==this._loadedBoardId?(this._loadedBoardId=t,this._loadBoard(t)):!t&&null!==this._loadedBoardId&&this._board&&(this._loadedBoardId=null,this._board=null)}async _loadPreferences(){let e=localStorage.getItem("esphome-editor-layout");("both"===e||"left"===e||"right"===e)&&(this._layout=e);try{let e=await this._api.getPreferences();this._navCollapsed=!e.navigator_visible}catch{}}async _loadBoard(e){try{let t=await this._api.getBoard(e);this._loadedBoardId===e&&(this._board=t)}catch(e){console.error("Failed to load board:",e)}}async _loadYaml(){try{let e=await this._api.getConfig(this.id);this._yaml=e,this._savedYaml=e}catch(e){console.error("Failed to load YAML:",e)}}_saveYaml(){this._savedYaml=this._yaml,s.A.success(this._localize("device.yaml_saved"),{richColors:!0}),this._api.updateConfig(this.id,this._yaml).catch(e=>{(e instanceof Error?e.message:"").includes("timed out")||(console.error("Failed to save YAML:",e),s.A.error(this._localize("device.yaml_save_error"),{richColors:!0}))})}render(){let e=this._device?.friendly_name||this._device?.name||this.id||this._localize("dashboard.create_device");return(0,r.qy)`
      <!-- Mobile drawer -->
      <div
        class="drawer-backdrop ${this._drawerOpen?"drawer-backdrop--open":""}"
        @click=${()=>{this._drawerOpen=!1}}
      ></div>
      <div
        class="drawer ${this._drawerOpen?"drawer--open":""}"
        @section-toggle=${this._onSectionToggle}
        @section-select=${this._onSectionSelect}
        @yaml-highlight=${this._onYamlHighlight}
      >
        <esphome-device-navigator
          class="drawer-nav"
          .openSections=${this._openSections}
          .yaml=${this._yaml}
          .board=${this._board}
          .boardName=${this._board?.name??""}
          .configuration=${this.id}
          .platform=${this._board?.esphome.platform??""}
          .selectedKey=${this._selectedSection}
          .selectedFromLine=${this._selectedFromLine}
        ></esphome-device-navigator>
      </div>

      <div class="page">
        <div
          class="layout-grid ${this._navCollapsed?"nav-collapsed":""}"
          @section-toggle=${this._onSectionToggle}
          @layout-change=${this._onLayoutChange}
          @yaml-change=${this._onYamlChange}
          @yaml-highlight=${this._onYamlHighlight}
          @yaml-updated=${this._onYamlUpdated}
          @section-select=${this._onSectionSelect}
          @nav-section-show=${this._onNavSectionShow}
          @save-yaml=${this._saveYaml}
          @install-device=${this._installCtrl.onInstall}
          @update-device=${this._installCtrl.onUpdate}
        >
          <esphome-device-navigator
            class="desktop-nav"
            .openSections=${this._openSections}
            .yaml=${this._yaml}
            .board=${this._board}
            .boardName=${this._board?.name??""}
            .configuration=${this.id}
            .platform=${this._board?.esphome.platform??""}
            .selectedKey=${this._selectedSection}
            .selectedFromLine=${this._selectedFromLine}
          ></esphome-device-navigator>
          <esphome-device-editor
            .yaml=${this._yaml}
            .savedYaml=${this._savedYaml}
            .layout=${this._layout}
            ?navCollapsed=${this._navCollapsed}
            .deviceTitle=${e}
            .board=${this._board}
            .highlightRange=${this._highlightRange}
            .scrollToHighlight=${this._scrollToHighlight}
            .configuration=${this.id}
            .selectedSection=${this._selectedSection}
            .selectedFromLine=${this._selectedFromLine}
            .justCreated=${this._justCreated}
            @just-created-dismiss=${this._dismissJustCreated}
            ?hasPendingChanges=${this._device?.has_pending_changes===!0}
            ?hasUpdateAvailable=${this._device?.update_available===!0}
            ?busy=${this._activeJobs.has(this.id)}
          >
            <button slot="mobile-menu" class="nav-toggle-btn" @click=${this._onNavToggle}>
              <wa-icon library="mdi" name=${this._navToggleIcon}></wa-icon>
            </button>
          </esphome-device-editor>
        </div>
      </div>
      <esphome-unsaved-changes-dialog
        @discard=${this._onLeaveDiscard}
        @save=${this._onLeaveSave}
        @cancel=${this._onLeaveCancel}
      ></esphome-unsaved-changes-dialog>
      <esphome-command-dialog></esphome-command-dialog>
      <esphome-firmware-install-dialog></esphome-firmware-install-dialog>
      <esphome-install-method-dialog
        ?open=${this._installCtrl.installMethodOpen}
        .deviceState=${this._installCtrl.deviceState}
        .deviceTargetPlatform=${this._installCtrl.deviceTargetPlatform}
        @close=${this._installCtrl.onInstallMethodClose}
        @select-method=${this._installCtrl.onInstallMethodSelect}
      ></esphome-install-method-dialog>
    `}get _isMobile(){return window.matchMedia("(max-width: 900px)").matches}get _navToggleIcon(){return this._isMobile||this._navCollapsed?"arrow-collapse-right":"arrow-collapse-left"}_onNavToggle(){this._isMobile?this._drawerOpen=!this._drawerOpen:(this._navCollapsed=!this._navCollapsed,this._api.updatePreferences({navigator_visible:!this._navCollapsed}).catch(()=>{}))}_onSectionToggle(e){let{index:t}=e.detail,i=new Set;this._openSections.has(t)||i.add(t),this._openSections=i,this._updateUrl()}_onNavSectionShow(e){let t={core:0,components:1,automations:2}[e.detail.section];if(void 0===t)return;let i=new Set([t]);this._openSections=i,this._updateUrl(),this._drawerOpen=!0,this._navCollapsed&&(this._navCollapsed=!1,this._api.updatePreferences({navigator_visible:!0}).catch(()=>{}))}_onLayoutChange(e){this._layout=e.detail,localStorage.setItem("esphome-editor-layout",e.detail)}_onYamlChange(e){this._yaml=e.detail.value}_onYamlHighlight(e){this._highlightRange=e.detail.range,this._scrollToHighlight=e.detail.scroll}_onYamlUpdated(e){this._yaml=e.detail.yaml,this._savedYaml=e.detail.yaml}_onSectionSelect(e){this._selectedSection=e.detail.sectionKey,this._selectedFromLine=e.detail.fromLine,this._drawerOpen=!1,this._updateUrl()}_readUrlParam(e,t){return new URLSearchParams(window.location.search).get(e)??t}_readUrlLine(){let e=new URLSearchParams(window.location.search).get("line");if(!e)return;let t=Number(e);return Number.isNaN(t)?void 0:t}_readUrlSections(){let e=new URLSearchParams(window.location.search).get("open");return e?e.split(",").map(Number).filter(e=>!Number.isNaN(e)):[]}_updateUrl(){let e=new URLSearchParams(window.location.search);this._selectedSection?(e.set("section",this._selectedSection),void 0!==this._selectedFromLine?e.set("line",String(this._selectedFromLine)):e.delete("line")):(e.delete("section"),e.delete("line")),this._openSections.size>0?e.set("open",[...this._openSections].join(",")):e.delete("open");let t=e.toString(),i=`${window.location.pathname}${t?`?${t}`:""}`;window.history.replaceState(null,"",i)}constructor(...e){super(...e),this._localize=e=>e,this._devices=[],this._activeJobs=new Map,this.id="",this._justCreated=!1,this._layout="both",this._openSections=new Set(this._readUrlSections()),this._board=null,this._loadedBoardId=null,this._highlightRange=null,this._scrollToHighlight=!1,this._selectedSection=this._readUrlParam("section",null),this._selectedFromLine=this._readUrlLine(),this._drawerOpen=!1,this._navCollapsed=!1,this._yaml="",this._savedYaml="",this._installCtrl=this._createInstallController(),this._pendingLeaveResolve=null,this._allowingLeave=!1,this._confirmLeave=()=>this._isDirty?this._pendingLeaveResolve?Promise.resolve(!1):new Promise(e=>{this._pendingLeaveResolve=e,this._leaveDialog?.open()}):Promise.resolve(!0),this._onLeaveDiscard=()=>{this._allowingLeave=!0,this._resolvePendingLeave(!0)},this._onLeaveSave=()=>{this._saveYaml(),this._allowingLeave=!0,this._resolvePendingLeave(!0)},this._onLeaveCancel=()=>this._resolvePendingLeave(!1),this._onBeforeUnload=e=>{this._isDirty&&(e.preventDefault(),e.returnValue="")},this._onPopState=e=>{if(this._allowingLeave){this._allowingLeave=!1;return}this._isDirty&&(e.stopImmediatePropagation(),window.history.pushState({},"",`/device/${this.id}`),this._confirmLeave().then(e=>{e&&(this._allowingLeave=!0,window.history.back())}))},this._onKeydown=e=>{if("Escape"!==e.key||e.defaultPrevented)return;let t=e.composedPath()[0];if(!this._isTextEntry(t)){if(this._drawerOpen){e.preventDefault(),this._drawerOpen=!1;return}e.preventDefault(),window.history.back()}},this._dismissJustCreated=()=>{this._justCreated=!1}}}eY.styles=[p.G,g],eU([(0,o.Fg)({context:c.$F,subscribe:!0}),(0,n.wk)()],eY.prototype,"_localize",void 0),eU([(0,o.Fg)({context:c.xJ,subscribe:!0}),(0,n.wk)()],eY.prototype,"_devices",void 0),eU([(0,o.Fg)({context:c.Ie})],eY.prototype,"_api",void 0),eU([(0,o.Fg)({context:c.EM,subscribe:!0}),(0,n.wk)()],eY.prototype,"_activeJobs",void 0),eU([(0,n.MZ)()],eY.prototype,"id",void 0),eU([(0,n.wk)()],eY.prototype,"_justCreated",void 0),eU([(0,n.wk)()],eY.prototype,"_layout",void 0),eU([(0,n.wk)()],eY.prototype,"_openSections",void 0),eU([(0,n.wk)()],eY.prototype,"_board",void 0),eU([(0,n.wk)()],eY.prototype,"_highlightRange",void 0),eU([(0,n.wk)()],eY.prototype,"_scrollToHighlight",void 0),eU([(0,n.wk)()],eY.prototype,"_selectedSection",void 0),eU([(0,n.wk)()],eY.prototype,"_selectedFromLine",void 0),eU([(0,n.wk)()],eY.prototype,"_drawerOpen",void 0),eU([(0,n.wk)()],eY.prototype,"_navCollapsed",void 0),eU([(0,n.wk)()],eY.prototype,"_yaml",void 0),eU([(0,n.wk)()],eY.prototype,"_savedYaml",void 0),eU([(0,n.P)("esphome-unsaved-changes-dialog")],eY.prototype,"_leaveDialog",void 0),eU([(0,n.P)("esphome-command-dialog")],eY.prototype,"_commandDialog",void 0),eU([(0,n.P)("esphome-firmware-install-dialog")],eY.prototype,"_firmwareDialog",void 0),eY=eU([(0,n.EM)("esphome-page-device")],eY)}}]);
//# sourceMappingURL=705.2a40b98676a37ff9.js.map