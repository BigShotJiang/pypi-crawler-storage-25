import questionary
import typer
from rich.console import Console
from rich.table import Table

from hohu import __version__
from hohu.config.settings import CONFIG_FILE, load_config, save_config
from hohu.i18n import i18n

console = Console()
system_app = typer.Typer(help=i18n.t("system_help"))


@system_app.command("info", help=i18n.t("system_info_help"))
def show_info():
    """info"""
    config = load_config()

    table = Table(
        title="HoHu CLI System Configuration",
        show_header=False,
        title_style="bold magenta",
    )

    table.add_row("Version", f"[green]{__version__}[/green]")
    table.add_row("Language", f"[cyan]{config.get('language', 'auto')}[/cyan]")
    table.add_row("Config Path", f"[dim]{CONFIG_FILE}[/dim]")
    table.add_row("I18n Status", "[green]Loaded[/green]")

    console.print(table)


@system_app.command("lang", help=i18n.t("system_lang_help"))
def set_language():
    """lang"""
    choices = [
        questionary.Choice("简体中文", value="zh"),
        questionary.Choice("English", value="en"),
        questionary.Choice("Follow System (跟随系统)", value="auto"),
    ]

    selected_lang = questionary.select(i18n.t("select_lang"), choices=choices).ask()

    if selected_lang:
        config = load_config()
        config["language"] = selected_lang
        save_config(config)

        # 假设 i18n 实例有 refresh 方法
        i18n.refresh()
        console.print(f"[green]✔[/green] {i18n.t('lang_updated')}")
