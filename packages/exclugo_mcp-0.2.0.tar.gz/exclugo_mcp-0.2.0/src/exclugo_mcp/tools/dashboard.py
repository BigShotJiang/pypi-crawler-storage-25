from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def get_dashboard() -> dict:
        """Get the client dashboard summary: charts, alerts, monitoring counts, license expirations."""
        return await client.get("/api/client/dashboard/")

    @mcp.tool()
    async def get_client_report(report_num: str) -> dict:
        """Get a client-facing report by report number."""
        return await client.get(f"/api/client/clientreport/{report_num}/")

    @mcp.tool()
    async def update_alert(alert_type: str, alert_id: int, data: dict) -> dict:
        """Update/acknowledge a client alert. alert_type: 'exclusion', 'sexoffender', 'dmf', 'npi', 'license'.
        data: fields to update like {'acknowledged': true, 'dashboard_comments': '...'}."""
        return await client.put(f"/api/client/updatealert/{alert_type}/{alert_id}/", json=data)

    @mcp.tool()
    async def disable_monitoring(entity_type: str, entity_id: int) -> dict:
        """Disable monitoring for an entity (e.g. terminated employee).
        entity_type: 'employee', 'vendor', 'license', 'npi'."""
        return await client.put(f"/api/client/disablemonitoring/{entity_type}/{entity_id}/")

    @mcp.tool()
    async def get_client_facilities_by_product() -> list | dict:
        """Get the client's facilities grouped by monitoring product type."""
        return await client.get("/api/client/facilityproducts/")

    @mcp.tool()
    async def get_client_report_searches(report_num: str) -> list | dict:
        """Get all searches for a client-facing report by report number."""
        return await client.get(f"/api/client/clientreport/{report_num}/searches/")

    @mcp.tool()
    async def get_client_search_alerts(search_id: int) -> list | dict:
        """Get alerts for a search from the client dashboard."""
        return await client.get(f"/api/client/alerts/{search_id}/")

    @mcp.tool()
    async def get_client_dashboard_facilities() -> list | dict:
        """Get all facilities available for the client dashboard."""
        return await client.get("/api/client/getdashboardfacilities/")

    @mcp.tool()
    async def client_edit_facility(facility_id: int, data: dict) -> dict:
        """Edit a facility from the client dashboard. data: fields to update."""
        return await client.put(f"/api/client/editfacility/{facility_id}/", json=data)

    @mcp.tool()
    async def get_current_client_facility() -> dict:
        """Get the current client's facility info."""
        return await client.get("/api/client/getclientfacility/")

    @mcp.tool()
    async def get_client_ssn_trace(search_id: int) -> dict:
        """Get SSN trace info for a search from the client dashboard."""
        return await client.get(f"/api/client/ssntrace/{search_id}/")

    @mcp.tool()
    async def client_individual_order(order_type: str, data: dict) -> dict:
        """Submit an individual order from the client side.
        order_type: 'employee', 'vendorindividual', 'vendororganization', 'license', 'npi'.
        data: order payload."""
        return await client.post(f"/api/client/individualorder/{order_type}/", json=data)
