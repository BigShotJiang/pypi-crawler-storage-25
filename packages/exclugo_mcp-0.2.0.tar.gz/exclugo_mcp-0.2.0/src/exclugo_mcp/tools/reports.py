from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def list_reports(status: str = "pending") -> list | dict:
        """List reports by status. status: 'pending', 'complete', 'expiring', etc."""
        return await client.get(f"/api/reports/{status}/")

    @mcp.tool()
    async def get_report(report_num: str) -> dict:
        """Get full details for a specific report by report number."""
        return await client.get(f"/api/admin/report/{report_num}/")

    @mcp.tool()
    async def get_report_searches(report_num: str) -> list | dict:
        """Get all searches (exclusion checks, license checks, etc.) for a report."""
        return await client.get(f"/api/admin/report/{report_num}/searches/")

    @mcp.tool()
    async def get_search_detail(search_id: int) -> dict:
        """Get detailed information for a specific search by ID."""
        return await client.get(f"/api/admin/search/{search_id}/")

    @mcp.tool()
    async def get_search_alerts(search_id: int) -> list | dict:
        """Get all alerts/flags for a specific search."""
        return await client.get(f"/api/admin/alerts/{search_id}/")

    @mcp.tool()
    async def get_ssn_trace(search_id: int) -> dict:
        """Get SSN trace information for a search."""
        return await client.get(f"/api/admin/ssntrace/{search_id}/")

    @mcp.tool()
    async def get_report_history(report_num: int) -> list | dict:
        """Get processing history/notes for a report."""
        return await client.get(f"/api/admin/history/{report_num}/")

    @mcp.tool()
    async def add_report_note(entity_type: str, entity_id: int, note: str) -> dict:
        """Add a processing note to a report. entity_type: 'employee', 'vendor', 'license', 'npi'."""
        return await client.post(
            f"/api/admin/reportlevelnote/{entity_type}/{entity_id}/",
            json={"note": note},
        )

    @mcp.tool()
    async def save_report_document(search_id: int, data: dict) -> dict:
        """Save a document/file to a report search. data should include file info."""
        return await client.post(f"/api/admin/savereportdocument/{search_id}/", json=data)

    @mcp.tool()
    async def get_source_lists() -> list | dict:
        """Get all exclusion source lists (OIG, SAM, state lists, etc.) with their status."""
        return await client.get("/api/admin/sourcelists/")

    @mcp.tool()
    async def get_report_detail(type: str, pk: int) -> dict:
        """Get full report detail by entity type and ID.
        type: 'employee', 'vendor', 'license', 'npi'. pk: the entity ID."""
        return await client.get(f"/api/admin/report/{type}/{pk}/")

    @mcp.tool()
    async def delete_report(type: str, pk: int) -> dict:
        """Delete/disable monitoring for a report by entity type and ID.
        type: 'employee', 'vendor', 'license', 'npi'. pk: the entity ID."""
        return await client.delete(f"/api/admin/report/{type}/{pk}/")

    @mcp.tool()
    async def assign_user_to_search(search_id: int, data: dict) -> dict:
        """Assign a user to a search. data: {'user': user_id}."""
        return await client.put(f"/api/admin/searchassignuser/{search_id}/", json=data)

    @mcp.tool()
    async def add_ssn_comment(data: dict) -> dict:
        """Add a comment to an SSN search. data: {'search': search_id, 'comment': '...'}."""
        return await client.post("/api/admin/ssncomment/", json=data)

    @mcp.tool()
    async def search_by_report_id(report_id: str) -> list | dict:
        """Search reports by old report ID/number."""
        return await client.get(f"/api/searchresultsoldreportnumber/{report_id}/")

    @mcp.tool()
    async def add_alias(type: str, pk: int, data: dict) -> dict:
        """Add an alias (alternate name/dob/ssn/address/file) to an employee or vendor.
        type: 'employee' or 'vendor'. pk: entity ID.
        data: alias fields like {'first_name': '...', 'last_name': '...'}."""
        return await client.post(f"/api/aliasname/{type}/{pk}/", json=data)

    @mcp.tool()
    async def get_alias_names(type: str, pk: int) -> list | dict:
        """Get all alias names for an entity. type: 'employee' or 'vendor'. pk: entity ID."""
        return await client.get(f"/api/admin/getaliasname/{type}/{pk}/")

    @mcp.tool()
    async def get_alias_dob(type: str, pk: int) -> list | dict:
        """Get all alias dates of birth for an entity. type: 'employee' or 'vendor'. pk: entity ID."""
        return await client.get(f"/api/admin/getaliasdob/{type}/{pk}/")

    @mcp.tool()
    async def get_alias_ssn(type: str, pk: int) -> list | dict:
        """Get all alias SSNs for an entity. type: 'employee' or 'vendor'. pk: entity ID."""
        return await client.get(f"/api/admin/getaliasssn/{type}/{pk}/")

    @mcp.tool()
    async def get_alias_address(type: str, pk: int) -> list | dict:
        """Get all alias addresses for an entity. type: 'employee' or 'vendor'. pk: entity ID."""
        return await client.get(f"/api/admin/getaliasaddress/{type}/{pk}/")

    @mcp.tool()
    async def get_alias_file(type: str, pk: int) -> list | dict:
        """Get all alias files for an entity. type: 'employee' or 'vendor'. pk: entity ID."""
        return await client.get(f"/api/admin/getaliasfile/{type}/{pk}/")

    @mcp.tool()
    async def edit_alias_name(alias_id: int, data: dict) -> dict:
        """Edit an alias name record by ID. data: fields to update."""
        return await client.put(f"/api/admin/editaliasname/{alias_id}/", json=data)

    @mcp.tool()
    async def edit_alias_dob(alias_id: int, data: dict) -> dict:
        """Edit an alias date-of-birth record by ID. data: fields to update."""
        return await client.put(f"/api/admin/editaliasdob/{alias_id}/", json=data)

    @mcp.tool()
    async def edit_alias_ssn(alias_id: int, data: dict) -> dict:
        """Edit an alias SSN record by ID. data: fields to update."""
        return await client.put(f"/api/admin/editaliasssn/{alias_id}/", json=data)

    @mcp.tool()
    async def edit_alias_address(alias_id: int, data: dict) -> dict:
        """Edit an alias address record by ID. data: fields to update."""
        return await client.put(f"/api/admin/editaliasaddress/{alias_id}/", json=data)

    @mcp.tool()
    async def edit_alias_file(alias_id: int, data: dict) -> dict:
        """Edit an alias file record by ID. data: fields to update."""
        return await client.put(f"/api/admin/editaliasfile/{alias_id}/", json=data)
