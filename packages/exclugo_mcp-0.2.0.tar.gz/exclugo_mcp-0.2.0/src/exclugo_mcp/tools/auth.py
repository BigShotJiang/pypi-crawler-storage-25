from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def authenticate(username: str, password: str) -> dict:
        """Sign in to Exclugo and store the auth token for subsequent requests.
        Returns user info and token on success."""
        result = await client.post("/api/signin/", json={"username": username, "password": password})
        if isinstance(result, dict):
            # Django returns the token under "key" for regular users, "token" for reseller API users
            token = result.get("token") or result.get("key")
            if token:
                client.set_token(token)
        return result
