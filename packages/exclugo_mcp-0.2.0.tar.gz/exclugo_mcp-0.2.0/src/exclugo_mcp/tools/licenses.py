from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_license(
        facility: int,
        first_name: str,
        last_name: str,
        license_number: str,
        license_state: str,
        license_type: str = "",
        ssn: str = "",
        dob: str = "",
        middle_name: str = "",
        address: str = "",
        city: str = "",
        state: str = "",
        zip: str = "",
        reference: str = "",
        file_no: str = "",
    ) -> dict:
        """Create/order a new license for monitoring.
        license_state: two-letter state code (e.g. 'NY', 'CA')."""
        data = {
            "facility": facility,
            "first_name": first_name,
            "last_name": last_name,
            "license_number": license_number,
            "license_state": license_state,
            "license_type": license_type,
            "ssn": ssn,
            "dob": dob,
            "middle_name": middle_name,
            "address": address,
            "city": city,
            "state": state,
            "zip": zip,
            "reference": reference,
            "file_no": file_no,
        }
        return await client.post("/api/individualorder/license/", json=data)

    @mcp.tool()
    async def get_expiring_licenses() -> list | dict:
        """Get list of all expiring and expired licenses across facilities."""
        return await client.get("/api/licenses/expiring/")

    @mcp.tool()
    async def run_single_license_check(license_id: int) -> dict:
        """Run a license verification check for a single license by its search ID."""
        return await client.post(f"/api/licenses/check/{license_id}/")

    @mcp.tool()
    async def add_manual_license_check(data: dict) -> dict:
        """Manually add a license check result. Include fields like: search (search ID),
        name, status, exp_date, issue_date, type, comments, etc."""
        return await client.post("/api/licenses/manuallyadded/", json=data)

    @mcp.tool()
    async def get_license_files(license_id: int) -> list | dict:
        """Get all files/documents attached to a license search."""
        return await client.get(f"/api/admin/licensefiles/{license_id}/")

    @mcp.tool()
    async def generate_613a_letter(entity_type: str, entity_id: int) -> dict:
        """Generate a 613A letter for a license or employee.
        entity_type: 'license' or 'employee'. entity_id: the record ID."""
        return await client.get(f"/api/admin/generate613a/{entity_type}/{entity_id}/")

    @mcp.tool()
    async def send_613a_email(entity_type: str, entity_id: int) -> dict:
        """Send a 613A letter via email.
        entity_type: 'license' or 'employee'. entity_id: the record ID."""
        return await client.post(f"/api/admin/send613aemail/{entity_type}/{entity_id}/")

    @mcp.tool()
    async def email_license_status(license_id: int) -> dict:
        """Send an email notification about a license status update."""
        return await client.post(f"/api/licenseupdateemail/{license_id}/")

    @mcp.tool()
    async def get_license_check_image() -> dict:
        """Get the image/screenshot from a license check."""
        return await client.get("/api/licenses/getimage/")

    @mcp.tool()
    async def send_prenotification_emails() -> dict:
        """Send prenotification emails for upcoming license expirations."""
        return await client.post("/api/licenses/prenotificationemails/")

    @mcp.tool()
    async def send_monthly_prenotification_emails() -> dict:
        """Send monthly prenotification emails for license expirations."""
        return await client.post("/api/licenses/monthlyprenotificationemails/")

    @mcp.tool()
    async def send_expiring_license_email_applicant() -> dict:
        """Send expiring license notification emails to applicants."""
        return await client.post("/api/licenses/expiringnotificationapplicant/")

    @mcp.tool()
    async def change_manual_license_check(license_check_id: int, data: dict) -> dict:
        """Update a manually added license check record. data: fields to update."""
        return await client.put(f"/api/licenses/changemanuallyadded/{license_check_id}/", json=data)

    @mcp.tool()
    async def delete_license_files(license_file_id: int, search_id: int) -> dict:
        """Delete a license file by file ID and search ID."""
        return await client.delete(f"/api/admin/deletelicensefiles/{license_file_id}/{search_id}/")

    @mcp.tool()
    async def get_client_license_files(license_id: int) -> list | dict:
        """Get license files from the client's perspective."""
        return await client.get(f"/api/client/licensefiles/{license_id}/")

    @mcp.tool()
    async def acknowledge_no_records_found(type: str, entity_id: int) -> dict:
        """Client acknowledges that no records were found for a license check.
        type: entity type (e.g. 'license'). entity_id: the entity ID."""
        return await client.post(f"/api/client/norecordsfoundforlicense/{type}/{entity_id}/")

    @mcp.tool()
    async def get_email_errors() -> list | dict:
        """Get client email error logs."""
        return await client.post("/api/admin/sendclientemailerrors/")

    @mcp.tool()
    async def manually_resend_email(data: dict) -> dict:
        """Manually resend a failed email. data: email details/ID."""
        return await client.post("/api/admin/manualresend/", json=data)
