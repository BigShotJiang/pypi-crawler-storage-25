from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_npi(
        facility: int,
        first_name: str,
        last_name: str,
        npi: str,
        ssn: str = "",
        dob: str = "",
        middle_name: str = "",
        address: str = "",
        city: str = "",
        state: str = "",
        zip: str = "",
        reference: str = "",
        file_no: str = "",
    ) -> dict:
        """Create/order a new NPI (National Provider Identifier) for monitoring."""
        data = {
            "facility": facility,
            "first_name": first_name,
            "last_name": last_name,
            "npi": npi,
            "ssn": ssn,
            "dob": dob,
            "middle_name": middle_name,
            "address": address,
            "city": city,
            "state": state,
            "zip": zip,
            "reference": reference,
            "file_no": file_no,
        }
        return await client.post("/api/individualorder/npi/", json=data)

    @mcp.tool()
    async def edit_npi(npi_id: int, updates: dict) -> dict:
        """Edit an existing NPI record. Pass a dict of fields to update."""
        return await client.put(f"/api/reports/edit/npi/{npi_id}/", json=updates)

    @mcp.tool()
    async def search_npis(
        first_name: str = "",
        last_name: str = "",
        npi: str = "",
        facility_id: int = 0,
        client_id: int = 0,
        region_id: int = 0,
        status: str = "all",
        only_flagged: bool = False,
    ) -> list | dict:
        """Search NPI records by name, NPI number, facility, client, or status."""
        data = {
            "first": first_name,
            "last": last_name,
            "middle": "",
            "business": "",
            "ssn": "",
            "ein": "",
            "license": "",
            "dob": "",
            "startFrom": "",
            "endFrom": "",
            "startTo": "",
            "endTo": "",
            "number": "",
            "facilityId": facility_id,
            "clientId": client_id,
            "regionId": region_id,
            "onlyFlagged": only_flagged,
            "address": "",
            "city": "",
            "state": "",
            "zip": "",
            "npi": npi,
            "status": status,
        }
        return await client.post("/api/admin/npi/search/", json=data)
