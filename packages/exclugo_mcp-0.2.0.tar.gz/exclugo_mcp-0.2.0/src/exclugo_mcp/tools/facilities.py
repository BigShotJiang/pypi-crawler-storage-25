from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def list_facilities() -> list | dict:
        """List all facilities/clients in Exclugo."""
        return await client.get("/api/facility/")

    @mcp.tool()
    async def get_facility(facility_id: int) -> dict:
        """Get full details for a specific facility by ID."""
        return await client.get(f"/api/facility/{facility_id}/")

    @mcp.tool()
    async def create_facility(
        name: str,
        client_code: str,
        email: str = "",
        phone_number: str = "",
        address: str = "",
        city: str = "",
        state: str = "",
        zip: str = "",
        contact_name: str = "",
        contact_email: str = "",
        contact_phone: str = "",
        contact_extension: str = "",
    ) -> dict:
        """Create a new facility/client in Exclugo."""
        data = {
            "name": name,
            "client_code": client_code,
            "email": email,
            "phone_number": phone_number,
            "address": address,
            "city": city,
            "state": state,
            "zip": zip,
            "contact_name": contact_name,
            "contact_email": contact_email,
            "contact_phone": contact_phone,
            "contact_extension": contact_extension,
        }
        return await client.post("/api/facility/", json=data)

    @mcp.tool()
    async def update_facility(facility_id: int, updates: dict) -> dict:
        """Update a facility. Pass a dict of fields to change, e.g. {"name": "New Name", "email": "new@email.com"}.
        Available fields: name, client_code, email, phone_number, address, city, state, zip,
        contact_name, contact_email, contact_phone, contact_extension, send_email_complete_flags,
        send_email_30_days, send_email_60_days, send_email_7_days, and many more."""
        return await client.put(f"/api/facility/{facility_id}/", json=updates)

    @mcp.tool()
    async def delete_facility(facility_id: int) -> dict:
        """Delete a facility by ID."""
        return await client.delete(f"/api/facility/{facility_id}/")

    @mcp.tool()
    async def get_facility_products(facility_id: int) -> list | dict:
        """Get all monitoring products enabled for a facility (Exclusion, License, NPI, Vendor, etc.)."""
        return await client.get(f"/api/facility/{facility_id}/product/")

    @mcp.tool()
    async def get_facility_fees(facility_id: int) -> list | dict:
        """Get all fees configured for a facility."""
        return await client.get(f"/api/facility/{facility_id}/fee/")

    @mcp.tool()
    async def get_facility_files(facility_id: int) -> list | dict:
        """Get all files/documents associated with a facility."""
        return await client.get(f"/api/facilityfiles/{facility_id}/")

    @mcp.tool()
    async def get_facility_report(report_type: str) -> list | dict:
        """Get a facility report by type. Types: 'products', 'fees', 'files', 'users'."""
        return await client.get(f"/api/getfacilityreport/{report_type}/")

    @mcp.tool()
    async def get_facilities_by_product() -> list | dict:
        """Get facilities grouped by their active monitoring products."""
        return await client.get("/api/facilitiesbyproducts/")

    @mcp.tool()
    async def get_facility_edit_history(facility_id: int) -> list | dict:
        """Get the edit/change history for a facility."""
        return await client.get(f"/api/admin/facilityhistory/{facility_id}/")

    @mcp.tool()
    async def save_facility_file(data: dict) -> dict:
        """Save/upload a file to a facility. data: {'facility': id, 'file': ..., 'name': '...'}."""
        return await client.post("/api/savefacilityfile/", json=data)

    @mcp.tool()
    async def get_facilities_and_resellers() -> list | dict:
        """Get a combined list of all facilities and resellers."""
        return await client.get("/api/facilitiesandresellers/")
