from __future__ import annotations

import httpx

from .config import config


_token: str | None = config.api_token
# Shared cookie jar so Django session cookies set by /api/signin/ persist across requests.
# Most Exclugo endpoints authenticate via SessionAuthentication, not TokenAuthentication.
_cookies: httpx.Cookies = httpx.Cookies()


def set_token(token: str) -> None:
    global _token
    _token = token


def get_token() -> str | None:
    return _token


def _headers() -> dict[str, str]:
    h: dict[str, str] = {"Content-Type": "application/json"}
    tok = get_token()
    if tok:
        h["Authorization"] = f"Token {tok}"
    return h


def _url(path: str) -> str:
    base = config.base_url.rstrip("/")
    if not path.startswith("/"):
        path = "/" + path
    return base + path


async def get(path: str, params: dict | None = None, timeout: int = 60) -> dict | list | str:
    async with httpx.AsyncClient(timeout=timeout, cookies=_cookies) as c:
        r = await c.get(_url(path), headers=_headers(), params=params)
        r.raise_for_status()
        _cookies.update(r.cookies)
        return r.json()


async def post(path: str, json: dict | None = None) -> dict | list | str:
    async with httpx.AsyncClient(timeout=120, cookies=_cookies) as c:
        r = await c.post(_url(path), headers=_headers(), json=json)
        r.raise_for_status()
        _cookies.update(r.cookies)
        return r.json()


async def put(path: str, json: dict | None = None) -> dict | list | str:
    async with httpx.AsyncClient(timeout=60, cookies=_cookies) as c:
        r = await c.put(_url(path), headers=_headers(), json=json)
        r.raise_for_status()
        _cookies.update(r.cookies)
        return r.json()


async def delete(path: str) -> dict | list | str:
    async with httpx.AsyncClient(timeout=60, cookies=_cookies) as c:
        r = await c.delete(_url(path), headers=_headers())
        r.raise_for_status()
        _cookies.update(r.cookies)
        try:
            return r.json()
        except Exception:
            return {"status": "deleted", "code": r.status_code}


async def post_form(path: str, data: dict | None = None, files: dict | None = None) -> dict | list | str:
    headers = {}
    tok = get_token()
    if tok:
        headers["Authorization"] = f"Token {tok}"
    async with httpx.AsyncClient(timeout=120, cookies=_cookies) as c:
        r = await c.post(_url(path), headers=headers, data=data, files=files)
        r.raise_for_status()
        _cookies.update(r.cookies)
        return r.json()
