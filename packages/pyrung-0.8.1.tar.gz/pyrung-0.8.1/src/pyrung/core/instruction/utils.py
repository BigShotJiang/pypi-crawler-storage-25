"""Shared helpers for instruction execution and validation."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from functools import wraps
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from pyrung.core.context import ConditionView, ScanContext
    from pyrung.core.tag import Tag, TagType


def guard_oneshot_execution[F: Callable[..., Any]](func: F) -> F:
    """Skip execute calls when one-shot state says not to run."""

    @wraps(func)
    def wrapper(self: Any, ctx: ScanContext, enabled: bool, *args: Any, **kwargs: Any) -> Any:
        if not enabled:
            if getattr(self, "_oneshot", False):
                ctx.set_memory(f"_oneshot:{id(self)}", False)
            return None
        if getattr(self, "_oneshot", False):
            key = f"_oneshot:{id(self)}"
            if ctx.get_memory(key, False):
                return None
            ctx.set_memory(key, True)
        return func(self, ctx, enabled, *args, **kwargs)

    return cast(F, wrapper)


def to_condition(obj: Any) -> Any:
    """Normalize instruction condition input(s) to a single Condition."""
    from pyrung.core.condition import BitCondition, Condition, _normalize_and_condition
    from pyrung.core.tag import Tag as TagClass
    from pyrung.core.tag import TagType

    if obj is None:
        return None

    def _coerce(value: object) -> Condition:
        if isinstance(value, Condition):
            return value
        if isinstance(value, TagClass):
            if value.type == TagType.BOOL:
                return BitCondition(value)
            raise TypeError(
                f"Non-BOOL tag '{value.name}' cannot be used directly as condition. "
                "Use comparison operators: tag == value, tag > 0, etc."
            )
        raise TypeError(f"Expected Condition or Tag, got {type(value)}")

    return _normalize_and_condition(
        obj,
        coerce=_coerce,
        empty_error="condition requires at least one condition",
        group_empty_error="condition group cannot be empty",
    )


def instruction_condition_view(ctx: ScanContext) -> ConditionView:
    """Return the frozen condition snapshot visible to instruction helper inputs.

    Helper conditions such as ``.reset(...)`` and ``.jump(...)`` should read from
    the active rung snapshot when one exists. Direct instruction unit tests may
    execute outside a rung, so we fall back to a one-off frozen snapshot taken at
    instruction entry.
    """
    from pyrung.core.context import ConditionView

    snapshot = ctx._condition_snapshot
    if snapshot is not None:
        return snapshot
    return ConditionView(ctx)


def resolve_preset_ctx(preset: Tag | int, ctx: ScanContext) -> int:
    """Resolve preset to int value (supports Tag or literal)."""
    from pyrung.core.tag import Tag as TagClass

    if isinstance(preset, TagClass):
        return ctx.get_tag(preset.name, preset.default)
    return preset


def _allowed_type_text(allowed_types: Iterable[TagType]) -> str:
    names = [tag_type.name for tag_type in allowed_types]
    if len(names) == 1:
        return names[0]
    if len(names) == 2:
        return f"{names[0]} or {names[1]}"
    return ", ".join(names[:-1]) + f", or {names[-1]}"


def assert_tag_type(
    tag: Tag,
    allowed_types: Iterable[TagType],
    *,
    label: str,
    include_tag_name: bool = False,
) -> None:
    """Assert a single tag is one of the allowed types."""
    allowed = tuple(allowed_types)
    if tag.type in allowed:
        return
    suffix = f" at {tag.name}" if include_tag_name else ""
    raise TypeError(f"{label} must be {_allowed_type_text(allowed)}; got {tag.type.name}{suffix}")
