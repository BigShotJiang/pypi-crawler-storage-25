import sys
import os
import grpc
import aiofiles
import xml.etree.ElementTree as ET
import tempfile
import shutil

proj_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
proto_path = os.path.abspath(os.path.join(proj_dir, "protos"))
sys.path.append(proto_path)
import mjc_message_pb2
import mjc_message_pb2_grpc

import numpy as np
import scipy.linalg
from datetime import datetime

from orca_gym.log.orca_log import get_orca_logger
_logger = get_orca_logger()

from orca_gym.core.orca_gym_model import OrcaGymModel
from orca_gym.core.orca_gym_data import OrcaGymData
from orca_gym.core.orca_gym_opt_config import OrcaGymOptConfig
from orca_gym.core.orca_gym import OrcaGymBase
from orca_gym.utils.dir_utils import cleanup_zombie_locks, file_lock

import mujoco
from scipy.spatial.transform import Rotation as R


def get_qpos_size(joint_type):
    """
    获取关节在 qpos 数组中的元素数量
    
    术语说明:
        - qpos (关节位置): 关节的广义坐标，不同关节类型占用不同数量的元素
        - FREE 关节: 7个元素 (3个位置 + 4个四元数)
        - BALL 关节: 4个元素 (四元数)
        - SLIDE/HINGE 关节: 1个元素 (单个标量)
    
    使用示例:
        ```python
        # 查询关节在 qpos 中的长度
        joint_type = self._mjModel.jnt_type[joint_id]
        qpos_size = get_qpos_size(joint_type)  # 返回 1, 3, 4 或 7
        ```
    """
    if joint_type == mujoco.mjtJoint.mjJNT_FREE:
        return 7
    elif joint_type == mujoco.mjtJoint.mjJNT_BALL:
        return 4
    elif joint_type == mujoco.mjtJoint.mjJNT_SLIDE or joint_type == mujoco.mjtJoint.mjJNT_HINGE:
        return 1
    else:
        return 0

def get_dof_size(joint_type):
    """
    获取关节的自由度数量（在 qvel 数组中的元素数量）
    
    术语说明:
        - DOF (自由度): 关节允许的运动维度
        - qvel (关节速度): 关节的广义速度，对应 qpos 的导数
        - FREE 关节: 6个自由度 (3个线性 + 3个旋转)
        - BALL 关节: 3个自由度 (3个旋转)
        - SLIDE/HINGE 关节: 1个自由度 (单个标量)
    
    使用示例:
        ```python
        # 查询关节的自由度数量
        joint_type = self._mjModel.jnt_type[joint_id]
        dof_size = get_dof_size(joint_type)  # 返回 1, 3 或 6
        ```
    """
    if joint_type == mujoco.mjtJoint.mjJNT_FREE:
        return 6
    elif joint_type == mujoco.mjtJoint.mjJNT_BALL:
        return 3
    elif joint_type == mujoco.mjtJoint.mjJNT_SLIDE or joint_type == mujoco.mjtJoint.mjJNT_HINGE:
        return 1
    else:
        return 0
    
class AnchorType:
    """
    锚点类型枚举
    
    术语说明:
        - 锚点 (Anchor): 用于物体操作的虚拟连接点
        - NONE: 无锚定，释放物体
        - WELD: 焊接锚定，完全固定位置和姿态
        - BALL: 球关节锚定，固定位置但允许旋转
    
    使用示例:
        ```python
        # 使用焊接锚定抓取物体
        self.anchor_actor("object_name", AnchorType.WELD)
        
        # 使用球关节锚定
        self.anchor_actor("object_name", AnchorType.BALL)
        
        # 释放物体
        self.release_body_anchored()  # 内部使用 AnchorType.NONE
        """
    NONE = 0
    WELD = 1
    BALL = 2

class CaptureMode:
    """
    视频捕获模式枚举
    
    术语说明:
        - 同步模式 (SYNC): 每个相机帧都与仿真步进对齐，性能较低但帧对齐
        - 异步模式 (ASYNC): 相机帧独立捕获，性能较高但可能不完全对齐
    
    使用示例:
        ```python
        # 开始保存视频，使用异步模式（默认，性能更好）
        env.begin_save_video("output.mp4", CaptureMode.ASYNC)
        
        # 使用同步模式（帧对齐，但性能较低）
        env.begin_save_video("output.mp4", CaptureMode.SYNC)
        ```
    """
    ASYNC = 0
    SYNC = 1

def get_eq_type(anchor_type: AnchorType):
    """
    根据锚点类型获取对应的等式约束类型
    
    术语说明:
        - 等式约束类型: MuJoCo 中用于连接两个 body 的约束类型
        - mjEQ_WELD: 焊接约束，完全固定位置和姿态
        - mjEQ_CONNECT: 连接约束，球关节连接，固定位置但允许旋转
    
    Args:
        anchor_type (AnchorType): 锚点类型
    
    Returns:
        mujoco.mjtEq: 对应的等式约束类型
    
    使用示例:
        ```python
        # 在更新等式约束时使用
        eq_type = get_eq_type(AnchorType.WELD)  # 返回 mjEQ_WELD
        eq["eq_type"] = eq_type
        ```
    """
    if anchor_type == AnchorType.WELD:
        return mujoco.mjtEq.mjEQ_WELD
    elif anchor_type == AnchorType.BALL:
        return mujoco.mjtEq.mjEQ_CONNECT
    else:
        return mujoco.mjtEq.mjEQ_CONNECT


class OrcaGymLocal(OrcaGymBase):
    """
    OrcaGym 本地仿真接口
    
    负责与本地 MuJoCo 仿真器的交互，包括模型加载、仿真控制、状态查询等。
    这是 OrcaGymLocalEnv 的核心通信对象，通过 gRPC 与 OrcaSim 服务器通信。
    
    核心功能:
        1. 模型管理: 加载 XML 模型、初始化 MuJoCo 模型和数据
        2. 仿真控制: 步进、重置、前向计算等
        3. 状态查询: 查询 body、joint、site、sensor 等状态
        4. 物体操作: 通过 mocap body 和等式约束操作物体
        5. 文件管理: 下载和缓存模型文件、mesh 等资源
    
    架构说明:
        - 继承自 OrcaGymBase，提供基础的 gRPC 通信能力
        - 维护本地 MuJoCo 模型和数据 (_mjModel, _mjData)
        - 提供封装后的模型和数据对象 (self.model, self.data)
        - 支持控制覆盖 (override_ctrls)，允许外部控制特定执行器
    
    使用示例:
        ```python
        # 在环境初始化时创建
        self.gym = OrcaGymLocal(self.stub)
        
        # 初始化仿真
        model_xml_path = await self.gym.load_model_xml()
        await self.gym.init_simulation(model_xml_path)
        
        # 访问模型和数据
        body_names = list(self.gym.model.get_body_names())
        qpos = self.gym.data.qpos
        ```
    """
    def __init__(self, stub):
        """
        初始化 OrcaGymLocal 对象
        
        Args:
            stub: gRPC 服务存根，用于与 OrcaSim 服务器通信
        
        术语说明:
            - gRPC Stub: gRPC 客户端存根，用于调用远程服务
            - _mjModel: MuJoCo 模型对象，包含所有静态模型信息
            - _mjData: MuJoCo 数据对象，包含所有动态仿真状态
            - override_ctrls: 控制覆盖字典，允许外部覆盖特定执行器的控制值
        
        使用示例:
            ```python
            # 在环境初始化时创建
            self.stub = GrpcServiceStub(self.channel)
            self.gym = OrcaGymLocal(self.stub)
            ```
        """
        super().__init__(stub = stub)

        self._timestep = 0.001
        self._mjModel = None
        self._mjData = None
        self._override_ctrls : dict[int, float] = {}
        
        # 清理可能的僵尸锁文件
        import tempfile
        temp_dir = tempfile.gettempdir()
        cleanup_zombie_locks(temp_dir)

    async def load_model_xml(self):
        """
        从服务器加载模型 XML 文件
        
        从 OrcaSim 服务器获取模型 XML 文件，下载依赖的资源文件（mesh、hfield等），
        并返回本地文件路径。
        
        Returns:
            model_xml_path: 模型 XML 文件的本地路径
        
        使用示例:
            ```python
            # 在环境初始化时调用
            model_xml_path = await self.gym.load_model_xml()
            # 返回: "/path/to/model.xml"
            ```
        """
        model_xml_path = await self.load_local_env()

        _logger.info(f"Model XML Path: {model_xml_path}")
        await self.process_xml_file(model_xml_path)
        return model_xml_path

    async def init_simulation(self, model_xml_path):
        """
        初始化 MuJoCo 仿真
        
        从 XML 文件加载 MuJoCo 模型，创建数据对象，初始化所有模型信息容器
        （body、joint、actuator、site、sensor 等），并创建封装的 model 和 data 对象。
        
        术语说明:
            - MjModel: MuJoCo 模型对象，包含所有静态模型信息（几何、质量、约束等）
            - MjData: MuJoCo 数据对象，包含所有动态状态（位置、速度、力等）
            - 模型信息容器: OrcaGymModel 和 OrcaGymData，提供更友好的访问接口
        
        Args:
            model_xml_path: 模型 XML 文件的路径
        
        使用示例:
            ```python
            # 在环境初始化时调用
            model_xml_path = await self.gym.load_model_xml()
            await self.gym.init_simulation(model_xml_path)
            
            # 之后可以访问模型和数据
            self.model = self.gym.model
            self.data = self.gym.data
            ```
        """
        self._xml_path = model_xml_path  # 保存 XML 路径，用于后续解析 mesh 文件路径
        self._mjModel = mujoco.MjModel.from_xml_path(model_xml_path)
        self._mjData = mujoco.MjData(self._mjModel)

        size_model = mujoco.mj_sizeModel(self._mjModel)
        _logger.debug(f"size_model: {size_model}")

        # Update the timestep setting form the env parameter.
        self.set_opt_timestep(self._timestep)

        opt_config = self.query_opt_config()
        self.opt = OrcaGymOptConfig(opt_config)
        self.print_opt_config()

        model_info = self.query_model_info()
        self.model = OrcaGymModel(model_info)      # 对应 Mujoco Model
        self.print_model_info(model_info)

        eq_list = self.query_all_equality_constraints()
        self.model.init_eq_list(eq_list)
        mocap_dict = self.query_all_mocap_bodies()
        self.model.init_mocap_dict(mocap_dict)
        actuator_dict = self.query_all_actuators()
        self.model.init_actuator_dict(actuator_dict)
        body_dict = self.query_all_bodies()
        self.model.init_body_dict(body_dict)
        joint_dict = self.query_all_joints()
        self.model.init_joint_dict(joint_dict)
        geom_dict = self.query_all_geoms()
        self.model.init_geom_dict(geom_dict)
        site_dict = self.query_all_sites()
        self.model.init_site_dict(site_dict)
        sensor_dict = self.query_all_sensors()
        self.model.init_sensor_dict(sensor_dict)
        mesh_dict = self.query_all_meshes()
        self.model.init_mesh_dict(mesh_dict)

        self.data = OrcaGymData(self.model)
        self._qpos_cache = np.array(self._mjData.qpos, copy=True)
        self._qvel_cache = np.array(self._mjData.qvel, copy=True)
        self._qacc_cache = np.array(self._mjData.qacc, copy=True)
        self.update_data()

    async def render(self):
        """
        渲染当前仿真状态到 OrcaSim 服务器
        
        将当前的关节位置和仿真时间发送到服务器，用于可视化。
        同时接收服务器返回的控制覆盖值（如果用户在界面中手动控制）。
        
        使用示例:
            ```python
            # 在环境的 render 方法中调用
            await self.gym.render()
            # 服务器会更新可视化，并可能返回控制覆盖值
            ```
        """
        await self.update_local_env(self.data.qpos, self._mjData.time)

    async def update_local_env(self, qpos, time):
        """
        更新本地环境状态到服务器，并接收控制覆盖值
        
        将当前状态发送到服务器用于渲染，同时接收用户通过界面手动控制的值。
        这些覆盖值会在下次 set_ctrl 时应用。
        
        术语说明:
            - 控制覆盖 (Control Override): 外部（如用户界面）覆盖执行器的控制值
            - 用于实现手动控制、遥操作等功能
        
        Args:
            qpos: 当前关节位置数组
            time: 当前仿真时间
        
        使用示例:
            ```python
            # 在 render 中自动调用
            await self.gym.update_local_env(self.data.qpos, self._mjData.time)
            # 如果用户在界面中控制，override_ctrls 会被更新
            ```
        """
        request = mjc_message_pb2.UpdateLocalEnvRequest(qpos=qpos, time=time)
        response = await self.stub.UpdateLocalEnv(request)
        override_ctrls = response.override_ctrls
        self._override_ctrls.clear()
        if override_ctrls is not None and len(override_ctrls) > 0:
            for ctrl in override_ctrls:
                if ctrl.index < 0 or ctrl.index >= self._mjModel.nu:
                    _logger.warning(f"Invalid control index: {ctrl.index}, skipping.")
                    continue
                self._override_ctrls[ctrl.index] = ctrl.value

    async def load_content_file(self, content_file_name, remote_file_dir="", local_file_dir="", temp_file_path=None):
        """
        从服务器下载并缓存模型资源文件（mesh、hfield 等）。

        参数：
        - `content_file_name`：资源文件名（如 mesh.obj、heightfield.png）
        - `remote_file_dir`：服务器端文件目录（可选）
        - `local_file_dir`：本地存储目录（可选，默认使用 `xml_file_dir`）
        - `temp_file_path`：临时文件路径（可选，用于特殊场景）

        返回：
        - 本地文件路径（绝对路径）

        说明：
        - 使用文件锁防止多进程重复下载。
        - 采用原子写入（先写临时文件，再移动到最终位置），避免文件损坏。
        - 如果文件已存在，直接返回路径（跳过下载）。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        - 文件锁超时时间为 30 秒。
        """
        request = mjc_message_pb2.LoadContentFileRequest(file_name=content_file_name, file_dir=remote_file_dir)
        response = await self.stub.LoadContentFile(request)

        if response.status != mjc_message_pb2.LoadContentFileResponse.SUCCESS:
            raise Exception("Load content file failed.")

        content = response.content
        if content is None or len(content) == 0:
            raise Exception("Content is empty.")
        
        # 如果指定了临时文件路径，先写入临时文件
        if temp_file_path is not None:
            async with aiofiles.open(temp_file_path, 'wb') as f:
                await f.write(content)
            return temp_file_path
        
        # 否则按原来的逻辑写入最终路径
        if local_file_dir is None or len(local_file_dir) == 0:
            content_file_path = os.path.join(self.xml_file_dir, content_file_name)
        else:
            content_file_path = os.path.join(local_file_dir, content_file_name)

        _logger.debug(f"Content file path: {content_file_path}")

        # 使用文件锁防止多进程重入，设置30秒超时
        try:
            async with file_lock(content_file_path, timeout=30):
                # 再次检查文件是否存在（可能在等待锁的过程中已被其他进程创建）
                if not os.path.exists(content_file_path):
                    # 原子化保存：先写入临时文件，再移动到最终位置
                    temp_file = tempfile.NamedTemporaryFile(
                        mode='wb', 
                        dir=os.path.dirname(content_file_path), 
                        delete=False,
                        prefix=f"{content_file_name}_",
                        suffix=".tmp"
                    )
                    try:
                        temp_file.write(content)
                        temp_file.flush()
                        os.fsync(temp_file.fileno())
                        temp_file.close()
                        
                        # 原子移动文件
                        shutil.move(temp_file.name, content_file_path)
                    except Exception as e:
                        # 清理临时文件
                        try:
                            os.unlink(temp_file.name)
                        except OSError:
                            pass
                        raise e
        except TimeoutError as e:
            _logger.warning(f"警告: {e}")
            # 如果获取锁超时，检查文件是否已经存在
            if os.path.exists(content_file_path):
                _logger.info(f"文件 {content_file_path} 已存在，跳过下载")
                return content_file_path
            else:
                raise Exception(f"无法获取文件锁，且文件不存在: {content_file_path}")

        return content_file_path

    async def process_xml_node(self, node : ET.Element):
        """
        递归处理 XML 节点，下载缺失的资源文件。

        参数：
        - `node`：XML 元素节点（ElementTree.Element）

        说明：
        - 遍历 XML 树，查找 `mesh` 和 `hfield` 节点。
        - 如果节点的 `file` 属性指向的文件不存在，则调用 `load_content_file` 下载。
        - 递归处理所有子节点。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        - 该方法由 `process_xml_file` 内部调用，通常不需要直接使用。
        """
        if node.tag == 'mesh' or node.tag == 'hfield':
            content_file_name = node.get('file')
            if content_file_name is not None:
                content_file_path = os.path.join(self.xml_file_dir, content_file_name)
                # 使用文件锁防止多进程重复下载
                async with file_lock(content_file_path):
                    if not os.path.exists(content_file_path):
                        # 下载文件
                        _logger.debug(f"Load content file: {content_file_name}")
                        await self.load_content_file(content_file_name)
        else:
            for child in node:
                await self.process_xml_node(child)
        return
    
    async def begin_save_video(self, file_path, capture_mode: CaptureMode = CaptureMode.ASYNC):
        """
        开始保存视频到指定路径。

        参数：
        - `file_path`：视频文件保存路径（如 "output.mp4"）
        - `capture_mode`：捕获模式（`CaptureMode.ASYNC` 或 `CaptureMode.SYNC`，默认 ASYNC）

        说明：
        - ASYNC 模式：相机帧独立捕获，性能较高但可能不完全对齐。
        - SYNC 模式：每个相机帧都与仿真步进对齐，性能较低但帧对齐。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        - 调用 `stop_save_video()` 停止保存。
        """
        request = mjc_message_pb2.BeginSaveMp4FileRequest(file_path=file_path, capture_mode=capture_mode)
        response = await self.stub.BeginSaveMp4File(request)
        if response.status == mjc_message_pb2.BeginSaveMp4FileResponse.Status.SUCCESS:
            _logger.info(f"Video saving started at {file_path}")
        else:
            _logger.error(f"Failed to start video saving: {response.error_message}")

    async def stop_save_video(self):
        """
        停止保存视频。

        说明：
        - 停止由 `begin_save_video()` 启动的视频保存过程。
        - 视频文件会在停止时完成写入。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        """
        request =  mjc_message_pb2.StopSaveMp4FileRequest()
        await self.stub.StopSaveMp4File(request)

    async def get_current_frame(self)-> int:
        """
        获取当前相机帧索引。

        返回：
        - 当前帧索引（int）

        说明：
        - 用于查询当前渲染帧的索引，常用于视频保存时的帧对齐。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        """
        request = mjc_message_pb2.GetCurrentFrameIndexRequest()
        response = await self.stub.GetCurrentFrameIndex(request)
        return response.current_frame

    async def get_camera_time_stamp(self, last_frame) -> dict:
        """
        获取相机时间戳。

        参数：
        - `last_frame`：上次查询的帧索引

        返回：
        - 字典，键为相机名称，值为时间戳列表

        说明：
        - 用于查询各相机的时间戳信息，常用于视频保存时的帧对齐。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        """
        request = mjc_message_pb2.GetTimeStampRequest()
        request.last_frame_index = last_frame
        response = await self.stub.GetTimeStamp(request)
        if response.error_message != "":
            _logger.error(f"Get time stamp failed. error message: {response.error_message}")
        return {camera_name: time_stamp_list.time_stamps for camera_name, time_stamp_list in response.time_stamp_map.items()}

    async def get_frame_png(self, image_path):
        """
        获取相机帧的 PNG 图像及位姿信息。

        参数：
        - `image_path`：图像保存路径

        返回：
        - 字典，键为相机名称，值为包含 'pos' 和 'quat' 的字典

        说明：
        - 从服务器获取当前相机帧的 PNG 图像，并返回各相机的位姿信息。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        """
        request = mjc_message_pb2.GetCameraFramePNGRequest()
        request.image_path = image_path
        response = await self.stub.GetCameraFramePNG(request)
        result = {}
        for name_transform in response.name_transform:
            result[name_transform.name] = {
                'pos': list(name_transform.pos),
                'quat': list(name_transform.quat)
            }
        return result

    @property
    def xml_file_dir(self):
        """
        获取 XML 文件缓存目录。

        返回：
        - 本地缓存目录路径（默认 `~/.orcagym/tmp`）

        说明：
        - 用于存储从服务器下载的 XML 模型文件和资源文件（mesh、hfield 等）。
        - 目录不存在时会自动创建。
        """
        user_home = os.path.expanduser('~')  # 自动适配Windows/Linux/Mac
        save_dir = os.path.join(user_home, '.orcagym', 'tmp')
        os.makedirs(save_dir, exist_ok=True)
        return save_dir

    async def process_xml_file(self, file_path):
        """
        处理 XML 文件，下载缺失的资源文件。

        参数：
        - `file_path`：XML 文件路径

        说明：
        - 解析 XML 文件，检查所有 `mesh` 和 `hfield` 节点。
        - 如果节点引用的文件不存在，则从服务器下载。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        - 该方法由 `load_model_xml` 内部调用，通常不需要直接使用。
        """
        # 读取xml文件
        with open(file_path, 'r') as f:
            xml_content = f.read()

        # 解析xml文件，检查涉及到外部文件的节点，读取file属性，检查文件是否存在，如果不存在则下载
        root = ET.fromstring(xml_content)
        await self.process_xml_node(root)
        return

    def _build_load_local_env_error(self, status=None, error_message=""):
        parts = ["Load local env failed."]
        if status is not None:
            parts.append(f"error code: {status}")
        if error_message:
            parts.append(f"error message: {error_message}")

        parts.extend([
            "",
            "MuJoCo 场景初始化失败，当前无法加载仿真环境。",
            "这通常不是 Python 调用方式本身的问题，而是场景在服务端初始化时未成功完成。",
            "",
            "常见原因包括：",
            "1. joint、body、geom、site、actuator、sensor 等名称重复",
            "2. 模型初始姿态重叠严重，导致接触或约束异常",
            "3. 关节层级、axis、range、damping、stiffness、armature 等物理参数配置不合理",
            "4. equality / weld / connect 等约束配置异常",
            "5. mesh、纹理、XML 引用资源缺失或路径错误",
            "6. 仿真服务刚启动，MuJoCo 仍在初始化中",
            "",
            "建议排查：",
            "1. 如果是刚点击运行，请等待几秒后重试",
            "2. 检查最近修改过的 MJCF/XML 或者配置好的布局，重点排查重名、重叠、约束和关节参数",
            "3. 确认 OrcaStudio / OrcaLab 中场景本身已正常启动",
            "4. 如仍失败，请查阅 MuJoCo 官方文档：",
            "   - XML Reference: https://mujoco.readthedocs.io/en/latest/XMLreference.html",
            "   - Modeling: https://mujoco.readthedocs.io/en/latest/modeling.html",
            "   - Python: https://mujoco.readthedocs.io/en/latest/python.html",
        ])
        return "\n".join(parts)

    async def load_local_env(self):
        """
        从服务器加载本地环境 XML 文件。

        返回：
        - XML 文件的本地绝对路径

        说明：
        - 从服务器获取模型 XML 文件名和内容。
        - 使用文件锁防止多进程重复下载。
        - 采用原子写入（先写临时文件，再移动到最终位置），避免文件损坏。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        - 该方法由 `load_model_xml` 内部调用，通常不需要直接使用。
        """
        # 第一步：先获取文件名
        request = mjc_message_pb2.LoadLocalEnvRequest()
        request.req_type = mjc_message_pb2.LoadLocalEnvRequest.XML_FILE_NAME
        response = await self.stub.LoadLocalEnv(request)

        if response.status != mjc_message_pb2.LoadLocalEnvResponse.SUCCESS:
            raise Exception(self._build_load_local_env_error(response.status, response.error_message))

        # 文件存储在指定路径
        file_name = response.file_name
        file_path = os.path.join(self.xml_file_dir, file_name)
        
        # 使用文件锁防止多进程重入
        async with file_lock(file_path):
            # 检查返回的文件是否已经存在,如果文件不存在，则获取文件内容
            if not os.path.exists(file_path):
                request = mjc_message_pb2.LoadLocalEnvRequest()
                request.req_type = mjc_message_pb2.LoadLocalEnvRequest.XML_FILE_CONTENT
                response = await self.stub.LoadLocalEnv(request)

                if response.status != mjc_message_pb2.LoadLocalEnvResponse.SUCCESS:
                    raise Exception(self._build_load_local_env_error(response.status, response.error_message))
                
                # print("Load xml from remote: ", file_name)

                xml_content = response.xml_content
                
                # 原子化保存：先写入临时文件，再移动到最终位置
                temp_file = tempfile.NamedTemporaryFile(
                    mode='wb', 
                    dir=self.xml_file_dir, 
                    delete=False,
                    prefix=f"{file_name}_",
                    suffix=".tmp"
                )
                try:
                    temp_file.write(xml_content)
                    temp_file.flush()
                    os.fsync(temp_file.fileno())
                    temp_file.close()
                    
                    # 原子移动文件
                    shutil.move(temp_file.name, file_path)
                except Exception as e:
                    # 清理临时文件
                    try:
                        os.unlink(temp_file.name)
                    except OSError:
                        pass
                    raise e
        
        # 返回绝对路径
        return os.path.abspath(file_path)

    async def get_body_manipulation_anchored(self):
        """
        获取当前被锚定的 body 信息。

        返回：
        - `(body_name, anchor_type)` 元组，如果无锚定则返回 `(None, AnchorType.NONE)`

        说明：
        - 用于查询当前通过 UI 操作被锚定的 body 及其锚定类型（WELD/BALL）。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        """
        request = mjc_message_pb2.GetBodyManipulationAnchoredRequest()
        response = await self.stub.GetBodyManipulationAnchored(request)
        body_anchored = response.body_name
        anchor_type = response.anchor_type
        if body_anchored is None or len(body_anchored) == 0:
            return None, AnchorType.NONE
        else:
            return body_anchored, anchor_type

    async def get_body_manipulation_movement(self):
        """
        获取 body 操作移动增量。

        返回：
        - 字典，包含 'delta_pos' 和 'delta_quat'（位置和四元数增量）

        说明：
        - 用于查询通过 UI 操作产生的 body 移动增量，常用于物体拖拽场景。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        """
        request = mjc_message_pb2.GetBodyManipulationMovementRequest()
        response = await self.stub.GetBodyManipulationMovement(request)
        delta_pos = np.array(response.delta_pos)
        delta_quat = np.array(response.delta_quat)
        body_movement = {
            "delta_pos": delta_pos,
            "delta_quat": delta_quat
        }
        return body_movement

    def set_time_step(self, time_step):
        """
        设置仿真时间步长（本地和远程）
        
        同时更新本地 MuJoCo 模型的时间步长和远程服务器的时间步长。
        
        Args:
            time_step: 时间步长（秒），通常为 0.001-0.01
        
        使用示例:
            ```python
            # 在环境初始化时设置
            self.gym.set_time_step(0.001)  # 1000 Hz
            await self.gym.set_timestep_remote(0.001)  # 同步到服务器
            ```
        """
        self._timestep = time_step
        self.set_opt_timestep(time_step)

    def set_opt_timestep(self, timestep):
        """
        设置本地 MuJoCo 模型的时间步长
        
        术语说明:
            - opt.timestep: MuJoCo 优化选项中的时间步长参数
            - 影响: 时间步长越小，仿真越精确但计算越慢
        
        Args:
            timestep: 时间步长（秒）
        
        使用示例:
            ```python
            # 在模型加载后设置
            if self._mjModel is not None:
                self.set_opt_timestep(0.001)
            ```
        """
        if self._mjModel is not None:
            self._mjModel.opt.timestep = timestep

    async def set_timestep_remote(self, timestep):
        """
        异步设置远程服务器的时间步长
        
        将时间步长同步到 OrcaSim 服务器，确保本地和远程一致。
        
        Args:
            timestep: 时间步长（秒）
        
        Returns:
            response: gRPC 响应对象
        
        使用示例:
            ```python
            # 在设置时间步长时同步到服务器
            await self.gym.set_timestep_remote(0.001)
            ```
        """
        request = mjc_message_pb2.SetOptTimestepRequest(timestep=timestep)
        response = await self.stub.SetOptTimestep(request)
        return response

    def set_opt_config(self):
        """
        将 `self.opt` 的配置参数同步到本地 MuJoCo 模型。

        说明：
        - 将 `OrcaGymOptConfig` 对象中的所有参数写入 `_mjModel.opt`。
        - 常用于模型加载后统一配置优化参数。

        注意：
        - 该方法会覆盖 `_mjModel.opt` 的所有字段，确保与 `self.opt` 一致。
        """
        self._mjModel.opt.timestep = self.opt.timestep
        self._mjModel.opt.impratio = self.opt.impratio
        self._mjModel.opt.tolerance = self.opt.tolerance
        self._mjModel.opt.ls_tolerance = self.opt.ls_tolerance
        self._mjModel.opt.noslip_tolerance = self.opt.noslip_tolerance
        self._mjModel.opt.ccd_tolerance = self.opt.ccd_tolerance
        self._mjModel.opt.gravity = self.opt.gravity
        self._mjModel.opt.wind = self.opt.wind
        self._mjModel.opt.magnetic = self.opt.magnetic
        self._mjModel.opt.density = self.opt.density
        self._mjModel.opt.viscosity = self.opt.viscosity
        self._mjModel.opt.o_margin = self.opt.o_margin
        self._mjModel.opt.o_solref = self.opt.o_solref
        self._mjModel.opt.o_solimp = self.opt.o_solimp
        self._mjModel.opt.o_friction = self.opt.o_friction
        self._mjModel.opt.integrator = self.opt.integrator
        self._mjModel.opt.cone = self.opt.cone
        self._mjModel.opt.jacobian = self.opt.jacobian
        self._mjModel.opt.solver = self.opt.solver
        self._mjModel.opt.iterations = self.opt.iterations
        self._mjModel.opt.ls_iterations = self.opt.ls_iterations
        self._mjModel.opt.noslip_iterations = self.opt.noslip_iterations
        self._mjModel.opt.ccd_iterations = self.opt.ccd_iterations
        self._mjModel.opt.disableflags = self.opt.disableflags
        self._mjModel.opt.enableflags = self.opt.enableflags
        self._mjModel.opt.disableactuator = self.opt.disableactuator
        self._mjModel.opt.sdf_initpoints = self.opt.sdf_initpoints
        self._mjModel.opt.sdf_iterations = self.opt.sdf_iterations
        self._mjModel.opt.disableflags = self._mjModel.opt.disableflags | mujoco.mjtDisableBit.mjDSBL_FILTERPARENT if not self.opt.filterparent else self._mjModel.opt.disableflags & ~mujoco.mjtDisableBit.mjDSBL_FILTERPARENT.value


    def query_opt_config(self):
        """
        查询本地 MuJoCo 模型的优化配置。

        返回：
        - 配置字典，包含所有 MuJoCo `opt` 参数（timestep、solver、gravity 等）

        说明：
        - 从 `_mjModel.opt` 读取所有配置参数，返回字典格式。
        - 可用于构造 `OrcaGymOptConfig` 对象或打印/对比配置。

        注意：
        - 返回的字典可用于初始化 `OrcaGymOptConfig` 对象。
        """
        opt_config = {
            "timestep": self._mjModel.opt.timestep,
            "impratio": self._mjModel.opt.impratio,
            "tolerance": self._mjModel.opt.tolerance,
            "ls_tolerance": self._mjModel.opt.ls_tolerance,
            "noslip_tolerance": self._mjModel.opt.noslip_tolerance,
            "ccd_tolerance": self._mjModel.opt.ccd_tolerance,
            "gravity": list(self._mjModel.opt.gravity),
            "wind": list(self._mjModel.opt.wind),
            "magnetic": list(self._mjModel.opt.magnetic),
            "density": self._mjModel.opt.density,
            "viscosity": self._mjModel.opt.viscosity,
            "o_margin": self._mjModel.opt.o_margin,
            "o_solref": list(self._mjModel.opt.o_solref),
            "o_solimp": list(self._mjModel.opt.o_solimp),
            "o_friction": list(self._mjModel.opt.o_friction),
            "integrator": self._mjModel.opt.integrator,
            "cone": self._mjModel.opt.cone,
            "jacobian": self._mjModel.opt.jacobian,
            "solver": self._mjModel.opt.solver,
            "iterations": self._mjModel.opt.iterations,
            "ls_iterations": self._mjModel.opt.ls_iterations,
            "noslip_iterations": self._mjModel.opt.noslip_iterations,
            "ccd_iterations": self._mjModel.opt.ccd_iterations,
            "disableflags": self._mjModel.opt.disableflags,
            "enableflags": self._mjModel.opt.enableflags,
            "disableactuator": self._mjModel.opt.disableactuator,
            "sdf_initpoints": self._mjModel.opt.sdf_initpoints,
            "sdf_iterations": self._mjModel.opt.sdf_iterations,
            "filterparent": False if self._mjModel.opt.disableflags & mujoco.mjtDisableBit.mjDSBL_FILTERPARENT else True
        }
        return opt_config

    def query_model_info(self):
        """
        查询模型基本信息（维度参数）
        
        返回模型的各种维度信息，用于初始化 OrcaGymModel 对象。
        
        术语说明:
            - nq: 位置坐标数量 (generalized coordinates)
            - nv: 速度坐标数量 (degrees of freedom)
            - nu: 执行器数量 (actuators)
            - nbody: body 数量
            - njnt: 关节数量
            - ngeom: 几何体数量
            - nsite: site 数量
            - nconmax: 最大接触数量
        
        Returns:
            model_info: 包含所有维度信息的字典
        
        使用示例:
            ```python
            # 在初始化仿真时调用
            model_info = self.query_model_info()
            self.model = OrcaGymModel(model_info)
            # 之后可以通过 self.model.nq, self.model.nv 等访问维度
            ```
        """
        model_info = {
            'nq': self._mjModel.nq,
            'nv': self._mjModel.nv,
            'nu': self._mjModel.nu,
            'nbody': self._mjModel.nbody,
            'njnt': self._mjModel.njnt,
            'ngeom': self._mjModel.ngeom,
            'nsite': self._mjModel.nsite,
            'nmesh': self._mjModel.nmesh,
            'ncam': self._mjModel.ncam,
            'nlight': self._mjModel.nlight,
            'nuser_body': self._mjModel.nuser_body,
            'nuser_jnt': self._mjModel.nuser_jnt,
            'nuser_geom': self._mjModel.nuser_geom,
            'nuser_site': self._mjModel.nuser_site,
            'nuser_tendon': self._mjModel.nuser_tendon,
            'nuser_actuator': self._mjModel.nuser_actuator,
            'nuser_sensor': self._mjModel.nuser_sensor,
            'nconmax': self._mjModel.nconmax,
            # Flex 相关信息，用于可靠的 flex body 判断
            'nflex': self._mjModel.nflex,
            'nflexvert': self._mjModel.nflexvert,
            'flex_vertbodyid': list(self._mjModel.flex_vertbodyid),  # 所有 flex vertex 的 body id
            'flex_vertadr': list(self._mjModel.flex_vertadr) if self._mjModel.nflex > 0 else [],
            'flex_vertnum': list(self._mjModel.flex_vertnum) if self._mjModel.nflex > 0 else [],
            'flex_names': [mujoco.mj_id2name(self._mjModel, mujoco.mjtObj.mjOBJ_FLEX, i) for i in range(self._mjModel.nflex)] if self._mjModel.nflex > 0 else [],
        }
        return model_info
    
    def query_all_equality_constraints(self):
        """
        查询所有等式约束
        
        返回模型中所有等式约束的信息，用于物体操作等功能。
        
        术语说明:
            - 等式约束: 详见 orca_gym/core/orca_gym_model.py 中的说明
            - obj1_id, obj2_id: 被约束的两个 body 的 ID
            - eq_type: 约束类型（WELD、CONNECT 等）
            - eq_solref, eq_solimp: 约束求解器参数
        
        Returns:
            equality_constraints: 等式约束列表，每个元素包含约束的详细信息
        
        使用示例:
            ```python
            # 在初始化仿真时调用
            eq_list = self.query_all_equality_constraints()
            self.model.init_eq_list(eq_list)
            # 之后可以通过 self.model.get_eq_list() 访问
            ```
        """
        # 遍历模型中的所有等式约束
        model = self._mjModel

        equality_constraints = []
        for i in range(model.neq):
            eq_info = {
                "eq_type": model.eq_type[i],
                "obj1_id": model.eq_obj1id[i],
                "obj2_id": model.eq_obj2id[i],
                "active": model.eq_active0[i],
                "eq_solref": model.eq_solref[i],
                "eq_solimp": model.eq_solimp[i],
                "eq_data": model.eq_data[i],
            }
            equality_constraints.append(eq_info)
        
        return equality_constraints

    def query_all_mocap_bodies(self):
        """
        查询所有 mocap body。

        返回：
        - 字典，键为 body 名称，值为 mocap ID

        说明：
        - 遍历所有 body，找出 `body_mocapid != -1` 的 body（即 mocap body）。
        - 用于初始化 `OrcaGymModel` 的 mocap 字典。

        注意：
        - mocap body 的 ID 在模型加载后保持不变。
        """
        model = self._mjModel
        mocap_body_dict = {}
        for i in range(model.nbody):
            if model.body_mocapid[i] != -1:
                mocap_body_dict[model.body(i).name] = model.body_mocapid[i]

        return mocap_body_dict

    def query_all_actuators(self):
        """
        查询所有执行器信息
        
        返回所有执行器的详细信息，包括名称、关联关节、控制范围、齿轮比等。
        
        术语说明:
            - 执行器: 详见 orca_gym/core/orca_gym_model.py 中的说明
            - GearRatio: 齿轮比，执行器输出与关节输入的比例
            - CtrlRange: 控制范围，执行器可接受的最小和最大控制值
            - TrnType: 传输类型，执行器驱动的对象类型（关节、肌腱、site等）
        
        Returns:
            actuator_dict: 执行器字典，键为执行器名称，值为执行器信息
        
        使用示例:
            ```python
            # 在初始化仿真时调用
            actuator_dict = self.query_all_actuators()
            self.model.init_actuator_dict(actuator_dict)
            # 之后可以通过 self.model.get_actuator_dict() 访问
            ```
        """
        model = self._mjModel
        actuator_dict = {}
        idx = 0
        for i in range(model.nu):
            actuator = model.actuator(i)

            actuator_name = actuator.name
            if actuator_name == "":
                actuator_name = "actuator"

            if actuator_name in actuator_dict:
                actuator_name = actuator_name + f"_{idx}"
                idx += 1

            if actuator.trntype == mujoco.mjtTrn.mjTRN_JOINT:
                joint_name = model.joint(actuator.trnid[0]).name
            elif actuator.trntype == mujoco.mjtTrn.mjTRN_TENDON:
                joint_name = model.tendon(actuator.trnid[0]).name
            elif actuator.trntype == mujoco.mjtTrn.mjTRN_SITE:
                joint_name = model.site(actuator.trnid[0]).name
            else:
                joint_name = "unknown"

            actuator_dict[actuator_name] = {
                "JointName": joint_name,
                "GearRatio": actuator.gear,
                "TrnId": actuator.trnid[0],
                "CtrlLimited": bool(actuator.ctrllimited[0]),
                "ForceLimited": bool(actuator.forcelimited[0]),
                "ActLimited": bool(actuator.actlimited[0]),
                "CtrlRange": actuator.ctrlrange,
                "ForceRange": actuator.forcerange,
                "ActRange": actuator.actrange,
                "TrnType": actuator.trntype[0],
                "DynType": actuator.dyntype[0],
                "GainType": actuator.gaintype[0],
                "BiasType": actuator.biastype[0],
                "ActAdr": actuator.actadr[0],
                "ActNum": actuator.actnum[0],
                "Group": actuator.group[0],
                "DynPrm": actuator.dynprm,
                "GainPrm": actuator.gainprm,
                "BiasPrm": actuator.biasprm,
                "ActEarly": bool(model.actuator_actearly[i]),
                "Gear": actuator.gear,
                "CrankLength": actuator.cranklength[0],
                "Acc0": actuator.acc0[0],
                "Length0": actuator.length0[0],
                "LengthRange": actuator.lengthrange,
            }
        return actuator_dict
    def get_goal_bounding_box(self, goal_body_name):
        """
        计算目标物体（goal_body_name）在世界坐标系下的轴对齐包围盒。
        支持 BOX、SPHERE 类型，BOX 会考虑 geom 的旋转。
        """
        inf = float('inf')
        min_corner = np.array([ inf,  inf,  inf])
        max_corner = np.array([-inf, -inf, -inf])
        for geom_id in range(self._mjModel.ngeom):
            body_id = self._mjModel.geom(geom_id).bodyid
            body_name = self._mjModel.body(body_id).name
            if goal_body_name not in body_name:
                continue

            geom = self._mjModel.geom(geom_id)
            geom_type = geom.type
            # 世界坐标下的几何中心
            center = self._mjData.geom_xpos[geom_id]

            if geom_type == mujoco.mjtGeom.mjGEOM_BOX:
                # MuJoCo 中 size 已经是 half-extents (local frame)
                half_local = np.array(geom.size)
                # 获取世界坐标下的旋转矩阵
                xmat = self._mjData.geom_xmat[geom_id].reshape(3, 3)
                # 计算旋转后沿世界轴的半尺寸
                half_world = np.abs(xmat) @ half_local
                box_min = center - half_world
                box_max = center + half_world

            elif geom_type == mujoco.mjtGeom.mjGEOM_SPHERE:
                # 球体只需考虑半径
                r = geom.size[0]
                box_min = center - r
                box_max = center + r

            else:
                # 其他类型暂不处理
                continue

            min_corner = np.minimum(min_corner, box_min)
            max_corner = np.maximum(max_corner, box_max)

        bounding_box = {
            'min': min_corner,
            'max': max_corner,
            'size': max_corner - min_corner
        }
        return bounding_box
    def set_actuator_trnid(self, actuator_id, trnid):
        """
        设置执行器的传输目标 ID。

        参数：
        - `actuator_id`：执行器 ID
        - `trnid`：传输目标 ID（关节/肌腱/site 的 ID）

        说明：
        - 修改执行器驱动的目标对象（关节、肌腱或 site）。
        - 通常用于动态调整执行器配置。

        注意：
        - 修改后需要重新初始化模型才能生效。
        """
        model = self._mjModel
        actuator = model.actuator(actuator_id)
        actuator.trnid[0] = trnid

    def disable_actuator(self, actuator_groups: list[int]):
        """
        禁用指定组的执行器。

        参数：
        - `actuator_groups`：执行器组 ID 列表

        说明：
        - 通过设置 `opt.disableactuator` 标志位来禁用指定组的执行器。
        - 禁用的执行器不会产生力/扭矩。

        注意：
        - 组 ID 从 0 开始；每个组对应一个位标志。
        """
        model = self._mjModel
        for actuator_group in actuator_groups:
            model.opt.disableactuator |= (1 << actuator_group)

    def query_all_bodies(self):
        """
        查询所有 body 信息
        
        返回所有 body 的详细信息，包括位置、姿态、质量、惯性等。
        
        术语说明:
            - Body: 详见 orca_gym/core/orca_gym_model.py 中的说明
            - Mass: body 的质量
            - Inertia: body 的惯性张量
            - ParentID: 父 body 的 ID，形成运动链
        
        Returns:
            body_dict: body 字典，键为 body 名称，值为 body 信息
        
        使用示例:
            ```python
            # 在初始化仿真时调用
            body_dict = self.query_all_bodies()
            self.model.init_body_dict(body_dict)
            # 之后可以通过 self.model.get_body_dict() 访问
            ```
        """
        model = self._mjModel
        body_dict = {}
        for i in range(model.nbody):
            body = model.body(i)
            body_dict[body.name] = {
                "ID": body.id,
                "ParentID": body.parentid[0],
                "RootID": body.rootid[0],
                "WeldID": body.weldid[0],
                "MocapID": body.mocapid[0],
                "JntNum": body.jntnum[0],
                "JntAdr": body.jntadr[0],
                "DofNum": body.dofnum[0],
                "DofAdr": body.dofadr[0],
                "TreeID": model.body_treeid[i],
                "GeomNum": body.geomnum[0],
                "GeomAdr": body.geomadr[0],
                "Simple": body.simple[0],
                "SameFrame": body.sameframe[0],
                "Pos": body.pos,
                "Quat": body.quat,
                "IPos": body.ipos,
                "IQuat": body.iquat,
                "Mass": body.mass[0],
                "SubtreeMass": body.subtreemass[0],
                "Inertia": body.inertia,
                "InvWeight": body.invweight0,
                "GravComp": model.body_gravcomp[i],
                "Margin": model.body_margin[i],
            }
        return body_dict

    def query_all_joints(self):
        """
        查询所有关节信息
        
        返回所有关节的详细信息，包括类型、范围、位置、轴等。
        
        术语说明:
            - 关节: 详见 orca_gym/core/orca_gym_model.py 中的说明
            - Range: 关节的运动范围 [min, max]
            - Axis: 关节的旋转或滑动轴
            - Stiffness: 关节刚度
            - Damping: 关节阻尼
        
        Returns:
            joint_dict: 关节字典，键为关节名称，值为关节信息
        
        使用示例:
            ```python
            # 在初始化仿真时调用
            joint_dict = self.query_all_joints()
            self.model.init_joint_dict(joint_dict)
            # 之后可以通过 self.model.get_joint_dict() 访问
            ```
        """
        model = self._mjModel
        joint_dict = {}
        for i in range(model.njnt):
            joint = model.joint(i)
            joint_dict[joint.name] = {
                "ID": joint.id,
                "BodyID": joint.bodyid[0],
                "Type": joint.type[0],
                "Range": joint.range,
                "QposIdxStart": joint.qposadr[0],
                "QvelIdxStart": joint.dofadr[0],
                "Group": joint.group[0],
                "Limited": bool(joint.limited[0]),
                "ActfrcLimited": bool(model.jnt_actfrclimited[i]),
                "Solref": joint.solref[0],
                "Solimp": joint.solimp[0],
                "Pos": joint.pos,
                "Axis": joint.axis,
                "Stiffness": joint.stiffness[0],
                "ActfrcRange": model.jnt_actfrcrange[i],
                "Margin": joint.margin[0],
                "Frictionloss": joint.frictionloss[0],
                "Damping": joint.damping[0],
            }
            
        return joint_dict

    def query_all_geoms(self):
        """
        查询所有几何体信息
        
        返回所有几何体的详细信息，包括类型、大小、摩擦、位置等。
        
        术语说明:
            - 几何体 (Geom): 用于碰撞检测的几何形状
            - 类型: BOX、SPHERE、CAPSULE、MESH 等
            - Friction: 摩擦系数 [滑动, 扭转, 滚动]
            - Size: 几何体尺寸，不同类型有不同含义
        
        Returns:
            geom_dict: 几何体字典，键为几何体名称，值为几何体信息
        
        使用示例:
            ```python
            # 在初始化仿真时调用
            geom_dict = self.query_all_geoms()
            self.model.init_geom_dict(geom_dict)
            # 之后可以通过 self.model.get_geom_dict() 访问
            ```
        """
        model = self._mjModel
        geom_dict = {}
        for i in range(model.ngeom):
            geom = model.geom(i)
            bodyname = model.body(geom.bodyid[0]).name
            geom_dict[geom.name] = {
                "BodyName": bodyname,
                "Type": geom.type[0],
                "Contype": geom.contype[0],
                "Conaffinity": geom.conaffinity[0],
                "Condim": geom.condim[0],
                "Solmix": geom.solmix[0],
                "Solref": geom.solref,
                "Solimp": geom.solimp,
                "Size": geom.size,
                "Friction": geom.friction,
                "DataID": geom.dataid[0],
                "MatID": geom.matid[0],
                "Group": geom.group[0],
                "Priority": geom.priority[0],
                "Plugin": -1,
                "SameFrame": geom.sameframe[0],
                "Pos": geom.pos,
                "Quat": geom.quat,
                "Margin": geom.margin[0],
                "Gap": geom.gap[0],
            }

        return geom_dict
    
    def query_all_sites(self):
        """
        查询所有 site 信息
        
        返回所有 site 的详细信息，包括位置、姿态等。
        
        术语说明:
            - Site: 详见 orca_gym/core/orca_gym_model.py 中的说明
            - 用途: 标记末端执行器、目标点等关键位置
        
        Returns:
            site_dict: site 字典，键为 site 名称，值为 site 信息
        
        使用示例:
            ```python
            # 在初始化仿真时调用
            site_dict = self.query_all_sites()
            self.model.init_site_dict(site_dict)
            # 之后可以通过 self.model.get_site_dict() 访问
            ```
        """
        model = self._mjModel
        site_dict = {}
        for i in range(model.nsite):
            site = model.site(i)
            # Read user data if nuser_site > 0 (set via <size nuser_site="N"/> in MJCF).
            # user[0] encodes particleRadius for _SPH_PARTICLE_RENDER_BOUNDS sites.
            user_data = list(model.site_user[i]) if model.nuser_site > 0 else []
            site_dict[site.name] = {
                "ID": site.id,
                "BodyID": site.bodyid[0],
                "Type": site.type[0],
                "Pos": site.pos,
                "Mat": site.matid[0],
                "LocalPos": site.pos,
                "LocalQuat": site.quat,
                "Size": site.size,
                "User": user_data,
            }

        return site_dict 
    
    def query_all_sensors(self):
        """
        查询所有传感器信息
        
        返回所有传感器的详细信息，包括类型、维度、地址等。
        
        术语说明:
            - 传感器: 详见 orca_gym/core/orca_gym_model.py 中的说明
            - Type: 传感器类型（加速度计、陀螺仪、触觉等）
            - Dim: 传感器输出维度
            - Adr: 传感器数据在 sensordata 数组中的地址
        
        Returns:
            sensor_dict: 传感器字典，键为传感器名称，值为传感器信息
        
        使用示例:
            ```python
            # 在初始化仿真时调用
            sensor_dict = self.query_all_sensors()
            self.model.init_sensor_dict(sensor_dict)
            # 之后可以通过 self.model.gen_sensor_dict() 访问
            ```
        """
        model = self._mjModel
        sensor_dict = {}
        for i in range(model.nsensor):
            sensor = model.sensor(i)
            sensor_dict[sensor.name] = {
                "ID": sensor.id,
                "Type": sensor.type[0],
                "ObjID": sensor.objid[0],
                "Dim": sensor.dim[0],
                "Adr": sensor.adr[0],
                "Noise": sensor.noise[0]
            }

        return sensor_dict
    
    def query_all_meshes(self):
        """
        查询所有 mesh 信息
        
        注意：MuJoCo Python 绑定的 mesh 对象不包含原始文件路径
        需要从 XML 文件中解析获取
        """
        import xml.etree.ElementTree as ET
        import os
        
        model = self._mjModel
        mesh_dict = {}
        
        # 尝试从 XML 文件解析 mesh 文件路径和 scale
        mesh_files_from_xml = {}
        mesh_scales_from_xml = {}
        if hasattr(self, '_xml_path') and self._xml_path and os.path.exists(self._xml_path):
            try:
                tree = ET.parse(self._xml_path)
                root = tree.getroot()
                
                # 获取 XML 文件所在目录
                xml_dir = os.path.dirname(os.path.abspath(self._xml_path))
                
                # 获取 meshdir（如果有的话）
                meshdir = ""
                compiler = root.find('compiler')
                if compiler is not None:
                    meshdir = compiler.get('meshdir', '')
                
                # 查找 <asset> 标签下的所有 <mesh> 定义
                for mesh_elem in root.findall('.//asset/mesh'):
                    mesh_name = mesh_elem.get('name')
                    mesh_file = mesh_elem.get('file', '')
                    mesh_scale_str = mesh_elem.get('scale', '')
                    
                    if mesh_name and mesh_file:
                        # 构造绝对路径：xml_dir / meshdir / mesh_file
                        if meshdir:
                            full_path = os.path.join(xml_dir, meshdir, mesh_file)
                        else:
                            full_path = os.path.join(xml_dir, mesh_file)
                        
                        # 标准化路径
                        full_path = os.path.abspath(full_path)
                        mesh_files_from_xml[mesh_name] = full_path
                        
                        # 解析 scale（格式：\"0.2 0.2 0.2\"）
                        if mesh_scale_str:
                            try:
                                scale_values = [float(x) for x in mesh_scale_str.split()]
                                if len(scale_values) == 3:
                                    mesh_scales_from_xml[mesh_name] = scale_values
                                elif len(scale_values) == 1:
                                    # 如果只有一个值，复制到三个维度
                                    mesh_scales_from_xml[mesh_name] = [scale_values[0]] * 3
                            except ValueError:
                                _logger.warning(f"[query_all_meshes] Invalid scale format for mesh '{mesh_name}': '{mesh_scale_str}'")
                        
                _logger.info(f"[query_all_meshes] Parsed {len(mesh_files_from_xml)} mesh files from XML")
                _logger.info(f"[query_all_meshes] Parsed {len(mesh_scales_from_xml)} mesh scales from XML")
                _logger.info(f"[query_all_meshes] XML dir: {xml_dir}, meshdir: '{meshdir}'")
            except Exception as e:
                _logger.warning(f"[query_all_meshes] Failed to parse XML for mesh files: {e}")
        else:
            _logger.warning(f"[query_all_meshes] XML path not available, mesh File fields will be empty")
        
        # 构造 mesh_dict
        for i in range(model.nmesh):
            mesh = model.mesh(i)
            
            # 从 XML 解析结果中获取文件路径（已经是绝对路径）
            mesh_file = mesh_files_from_xml.get(mesh.name, "")
            
            # 从 XML 解析结果中获取 scale
            mesh_scale = mesh_scales_from_xml.get(mesh.name, [1.0, 1.0, 1.0])
            
            mesh_dict[mesh.name] = {
                "ID": mesh.id,
                "File": mesh_file,
                "Scale": mesh_scale,
            }
        
        return mesh_dict
    
    def update_data(self):
        """
        从 MuJoCo 数据更新到封装的 data 对象
        
        将 _mjData 中的最新状态（qpos、qvel、qacc、qfrc_bias、time）同步到
        封装的 OrcaGymData 对象中，供环境使用。
        
        术语说明:
            - 缓存: 使用 _qpos_cache 等数组作为中间缓存，避免频繁分配内存
            - qfrc_bias: 偏置力，包括重力、科里奥利力等被动力
        
        使用示例:
            ```python
            # 在仿真步进后调用，同步最新状态
            self.gym.mj_step(nstep)
            self.gym.update_data()  # 同步状态到 self.data
            
            # 之后可以安全访问
            current_qpos = self.data.qpos.copy()
            current_qvel = self.data.qvel.copy()
            ```
        """
        self._qpos_cache[:] = self._mjData.qpos
        self._qvel_cache[:] = self._mjData.qvel
        self._qacc_cache[:] = self._mjData.qacc
        qfrc_bias = self.query_qfrc_bias()        
        self.data.update_qpos_qvel_qacc(self._qpos_cache, self._qvel_cache, self._qacc_cache)        
        self.data.update_qfrc_bias(qfrc_bias)
        self.data.time = self._mjData.time
        # print("data: ", self.data.qpos, self.data.qvel, self.data.qacc, self.data.qfrc_bias, self.data.time)
        
    def update_data_external(self, qpos, qvel, qacc, qfrc_bias, time):
        """
        从外部环境更新数据（用于与外部仿真器协作）。

        参数：
        - `qpos`：`(nq,)` 广义坐标
        - `qvel`：`(nv,)` 广义速度
        - `qacc`：`(nv,)` 广义加速度
        - `qfrc_bias`：`(nv,)` 偏置力
        - `time`：仿真时间

        说明：
        - 用于与外部仿真器（如其他物理引擎）协作的场景。
        - 直接更新 `self.data`，不涉及 `_mjData` 同步。

        注意：
        - 该方法用于特殊场景，通常不需要直接使用。
        """
        self.data.update_qpos_qvel_qacc(qpos, qvel, qacc)
        self.data.update_qfrc_bias(qfrc_bias)
        self.data.time = time
        
        # print("data: ", self.data.qpos, self.data.qvel, self.data.qacc, self.data.qfrc_bias, self.data.time)
    
    
    def query_qfrc_bias(self):
        """
        查询偏置力 `qfrc_bias`。

        返回：
        - `(nv,)` 偏置力向量（包括重力、科里奥利、离心等项）

        说明：
        - 从 `_mjData.qfrc_bias` 直接读取。
        - 用于动力学计算和调试。

        注意：
        - 该值在 `mj_step` 或 `mj_forward` 后更新。
        """
        qfrc_bias = self._mjData.qfrc_bias
        return qfrc_bias
    
    def load_initial_frame(self):
        """
        重置仿真数据到初始状态
        
        将 MuJoCo 数据重置为初始状态，包括位置、速度、加速度等。
        相当于将仿真恢复到初始时刻。
        
        术语说明:
            - mj_resetData: MuJoCo 的重置函数，将所有动态数据重置为初始值
        
        使用示例:
            ```python
            # 在重置仿真时调用
            self.gym.load_initial_frame()
            self.gym.update_data()  # 同步到封装的 data 对象
            ```
        """
        mujoco.mj_resetData(self._mjModel, self._mjData)

    def query_joint_offsets(self, joint_names):
        """
        查询指定关节在 `qpos/qvel/qacc` 数组中的起始索引。

        参数：
        - `joint_names`：关节名称列表

        返回：
        - `(qpos_offsets, qvel_offsets, qacc_offsets)` 元组，每个是索引列表

        说明：
        - 用于定位指定关节在全局状态数组中的位置。
        - `qpos_offsets` 对应 `qpos` 数组，`qvel/qacc_offsets` 对应 `qvel/qacc` 数组。

        注意：
        - 索引用于从全局数组中提取特定关节的状态。
        """
        # 按顺序构建 offset 数组
        qpos_offsets = []
        qvel_offsets = []
        qacc_offsets = []

        # 将响应中每个关节的 offset 按顺序添加到数组中
        for joint_name in joint_names:
            joint_id = self._mjModel.joint(joint_name).id
            qpos_offsets.append(self._mjModel.jnt_qposadr[joint_id])
            qvel_offsets.append(self._mjModel.jnt_dofadr[joint_id])
            qacc_offsets.append(self._mjModel.jnt_dofadr[joint_id])

        return qpos_offsets, qvel_offsets, qacc_offsets    
    
    def query_joint_lengths(self, joint_names):
        """
        查询指定关节在 `qpos/qvel/qacc` 数组中的长度。

        参数：
        - `joint_names`：关节名称列表

        返回：
        - `(qpos_lengths, qvel_lengths, qacc_lengths)` 元组，每个是长度列表

        说明：
        - 不同关节类型在 `qpos` 中占用的元素数不同（FREE: 7, BALL: 4, HINGE/SLIDE: 1）。
        - 用于确定从全局数组中提取特定关节状态时需要读取的元素数。

        注意：
        - 长度与关节类型相关，见 `get_qpos_size` 和 `get_dof_size`。
        """
        qpos_lengths = []
        qvel_lengths = []
        qacc_lengths = []

        for joint_name in joint_names:
            joint_id = self._mjModel.joint(joint_name).id
            qpos_lengths.append(get_qpos_size(self._mjModel.jnt_type[joint_id]))
            qvel_lengths.append(get_dof_size(self._mjModel.jnt_type[joint_id]))
            qacc_lengths.append(get_dof_size(self._mjModel.jnt_type[joint_id]))

        return qpos_lengths, qvel_lengths, qacc_lengths
    
    def query_body_xpos_xmat_xquat(self, body_name_list):
        """
        查询 body 的位姿（位置、旋转矩阵、四元数）
        
        从 MuJoCo 数据中直接查询 body 的位姿信息。
        这是底层查询方法，被 OrcaGymLocalEnv 封装后使用。
        
        术语说明:
            - xpos: body 在世界坐标系中的位置
            - xmat: body 在世界坐标系中的旋转矩阵（3x3，按行展开为9个元素）
            - xquat: body 在世界坐标系中的四元数 [w, x, y, z]
        
        Args:
            body_name_list: body 名称列表
        
        Returns:
            body_pos_mat_quat_list: 字典，键为 body 名称，值为包含 'Pos'、'Mat'、'Quat' 的字典
        
        使用示例:
            ```python
            # 在环境的方法中调用
            body_dict = self.gym.query_body_xpos_xmat_xquat(["base_link"])
            base_pos = body_dict["base_link"]["Pos"]  # [x, y, z]
            base_mat = body_dict["base_link"]["Mat"]  # 9个元素，3x3矩阵按行展开
            base_quat = body_dict["base_link"]["Quat"]  # [w, x, y, z]
            ```
        """
        body_pos_mat_quat_list = {}
        for body_name in body_name_list:
            body_id = self._mjModel.body(body_name).id
            body_pos_mat_quat = {
                "Pos": self._mjData.xpos[body_id],
                "Mat": self._mjData.xmat[body_id],
                "Quat": self._mjData.xquat[body_id],
            }
            body_pos_mat_quat_list[body_name] = body_pos_mat_quat
            
        return body_pos_mat_quat_list
    
    def query_sensor_data(self, sensor_names):
        """
        查询传感器数据
        
        从 MuJoCo 的 sensordata 数组中读取指定传感器的当前值。
        
        术语说明:
            - sensordata: MuJoCo 中存储所有传感器数据的数组
            - Adr: 传感器数据在数组中的起始地址
            - Dim: 传感器输出维度
        
        Args:
            sensor_names: 传感器名称列表
        
        Returns:
            sensor_data_dict: 字典，键为传感器名称，值为传感器数据数组
        
        使用示例:
            ```python
            # 查询 IMU 传感器数据
            sensor_data = self.gym.query_sensor_data(["imu_accelerometer", "imu_gyro"])
            accel = sensor_data["imu_accelerometer"]  # 加速度数据
            gyro = sensor_data["imu_gyro"]  # 角速度数据
            ```
        """
        sensor_data_dict = {}
        for sensor_name in sensor_names:
            sensor_info = self.model.get_sensor(sensor_name)
            # print("Sensor Info: ", sensor_info, sensor_name)
            sensor_values = np.copy(self._mjData.sensordata[sensor_info['Adr']:sensor_info['Adr'] + sensor_info['Dim']])
            sensor_data_dict[sensor_name] = sensor_values

        # print("Sensor Data Dict: ", sensor_data_dict)

        return sensor_data_dict    
    
    def set_ctrl(self, ctrl):
        """
        设置控制输入，应用控制覆盖（如果存在）
        
        设置执行器控制值，如果存在控制覆盖（来自用户界面手动控制），
        则覆盖对应执行器的值。
        
        术语说明:
            - 控制覆盖: 外部（如用户界面）覆盖执行器的控制值，用于遥操作
        
        Args:
            ctrl: 控制输入数组，形状 (nu,)
        
        使用示例:
            ```python
            # 在仿真步进前设置控制
            self.gym.set_ctrl(action)  # action 形状: (nu,)
            # 如果用户在界面中手动控制，对应执行器的值会被覆盖
            ```
        """
        if len(self._override_ctrls) > 0:
            # 如果有 override 控制，则使用 override 控制
            for actuator_id, value in self._override_ctrls.items():
                ctrl[actuator_id] = value
        self._mjData.ctrl = ctrl.copy()

    def mj_step(self, nstep):
        """
        执行 MuJoCo 仿真步进
        
        执行 nstep 次物理仿真步进，每次步进的时间为 timestep。
        在调用前需要先设置控制输入 (set_ctrl)。
        
        术语说明:
            - mj_step: MuJoCo 的核心步进函数，执行一次完整的物理仿真
            - 包括: 前向计算、约束求解、积分等步骤
        
        Args:
            nstep: 步进次数，通常为 1 或 frame_skip
        
        使用示例:
            ```python
            # 在 do_simulation 中调用
            self.gym.set_ctrl(ctrl)
            self.gym.mj_step(nstep=5)  # 步进 5 次
            ```
        """
        mujoco.mj_step(self._mjModel, self._mjData, nstep)

    def mj_forward(self):
        """
        执行 MuJoCo 前向计算
        
        更新所有动力学相关状态，包括位置、速度、加速度、力等。
        在设置关节状态、mocap 位置等操作后需要调用，确保状态一致。
        
        术语说明:
            - 前向计算: 根据当前状态和输入计算下一时刻的状态
            - 包括: 正向运动学、动力学、约束等计算
        
        使用示例:
            ```python
            # 在设置状态后调用
            self.gym.set_joint_qpos(qpos)
            self.gym.mj_forward()  # 更新所有相关状态
            ```
        """
        mujoco.mj_forward(self._mjModel, self._mjData)

    def mj_inverse(self):
        """
        执行 MuJoCo 逆动力学计算
        
        根据给定的加速度计算所需的力和力矩。
        用于计算实现特定运动所需的控制输入。
        
        术语说明:
            - 逆动力学: 根据期望的加速度计算所需的力和力矩
            - 用途: 用于计算实现特定运动所需的控制输入
        
        使用示例:
            ```python
            # 计算实现期望加速度所需的力
            self.gym.mj_inverse()
            required_force = self._mjData.qfrc_actuator
            ```
        """
        mujoco.mj_inverse(self._mjModel, self._mjData)
        
    def mj_fullM(self):
        """
        计算完整的质量矩阵
        
        返回系统的完整质量矩阵 M，形状 (nv, nv)，用于动力学计算。
        
        术语说明:
            - 质量矩阵 (Mass Matrix): 描述系统惯性的矩阵，用于动力学方程
            - 形状: (nv, nv)，其中 nv 是系统的自由度数量
            - 用途: 用于逆动力学、力控制等算法
        
        Returns:
            mass_matrix: 质量矩阵，形状 (nv, nv)
        
        使用示例:
            ```python
            # 计算质量矩阵用于逆动力学
            M = self.gym.mj_fullM()  # 形状: (nv, nv)
            # 用于计算: tau = M @ qacc + C + G
            ```
        """
        mass_matrix = np.ndarray(shape=(self._mjModel.nv, self._mjModel.nv), dtype=np.float64, order="C")
        mujoco.mj_fullM(self._mjModel, mass_matrix, self._mjData.qM)
        mass_matrix = np.reshape(mass_matrix, (self._mjModel.nv, self._mjModel.nv))        
        return mass_matrix

    def mj_jacBody(self, jacp, jacr, body_id):
        """
        计算 body 的雅可比矩阵
        
        术语说明:
            - 雅可比矩阵: 详见 orca_gym/environment/orca_gym_local_env.py 中的说明
            - jacp: 位置雅可比，形状 (3, nv)
            - jacr: 旋转雅可比，形状 (3, nv)
        
        Args:
            jacp: 输出数组，用于存储位置雅可比，形状 (3, nv)
            jacr: 输出数组，用于存储旋转雅可比，形状 (3, nv)
            body_id: body 的 ID
        
        使用示例:
            ```python
            # 计算末端执行器的雅可比
            jacp = np.zeros((3, self.model.nv))
            jacr = np.zeros((3, self.model.nv))
            body_id = self.model.body_name2id("end_effector")
            self.gym.mj_jacBody(jacp, jacr, body_id)
            ```
        """
        mujoco.mj_jacBody(self._mjModel, self._mjData, jacp, jacr, body_id)

    def mj_jacSite(self, jacp, jacr, site_id):
        """
        计算 site 的雅可比矩阵
        
        术语说明:
            - 雅可比矩阵: 详见 orca_gym/environment/orca_gym_local_env.py 中的说明
            - Site: 标记点，详见 orca_gym/core/orca_gym_model.py 中的说明
        
        Args:
            jacp: 输出数组，用于存储位置雅可比，形状 (3, nv)
            jacr: 输出数组，用于存储旋转雅可比，形状 (3, nv)
            site_id: site 的 ID
        
        使用示例:
            ```python
            # 计算 site 的雅可比矩阵
            site_id = self._mjModel.site("end_effector").id
            jacp = np.zeros((3, self.model.nv))
            jacr = np.zeros((3, self.model.nv))
            self.gym.mj_jacSite(jacp, jacr, site_id)
            ```
        """
        mujoco.mj_jacSite(self._mjModel, self._mjData, jacp, jacr, site_id)

    def mj_apply_force_at_site(self, site_name: str, force: np.ndarray, torque: np.ndarray):
        """
        在指定 SITE 点施加力和力矩
        
        直接操作 xfrc_applied，避免 mj_applyFT 只能作用于 qfrc_applied 的限制。
        通过手动计算力产生的扭矩，将 site 点的力等效转换到 body 中心。
        
        物理原理：
        - 力 F 作用在 site 点，等效到 body 中心时：
        - 力不变：F_body = F
        - 产生附加扭矩：τ_induced = r × F，其中 r = site_pos - body_pos
        - 总扭矩：τ_total = r × F + τ_user
        
        Args:
            site_name: SITE 名称
            force: 力向量 [fx, fy, fz]（world frame，3D numpy 数组）
            torque: 力矩向量 [tx, ty, tz]（world frame，3D numpy 数组）
        """
        site_xpos = self._mjData.site(site_name).xpos
        body_id = self.model.get_site(site_name)['BodyID']
        body_xpos = self._mjData.xpos[body_id]
        
        # 计算力臂向量（从 body 中心指向 site）
        r = site_xpos - body_xpos
        
        # 力在 site 点产生的扭矩 = r × F（叉乘）
        induced_torque = np.cross(r, force)
        
        # 总扭矩 = 力产生的扭矩 + 用户指定的扭矩
        total_torque = induced_torque + torque
        
        # 直接累加到 xfrc_applied（笛卡尔空间外力，world frame）
        # 与 mj_clear_xfrc_applied_for_site 对称，都操作 xfrc_applied
        self._mjData.xfrc_applied[body_id, :3] += force
        self._mjData.xfrc_applied[body_id, 3:] += total_torque

    def mj_clear_xfrc_applied_for_site(self, site_name: str):
        """
        清零指定 SITE 所属 body 的 xfrc_applied
        
        用于实现脉冲力：每帧清零上一帧的外力，避免累积误差
        
        Args:
            site_name: SITE 名称
        """
        try:
            site_id = mujoco.mj_name2id(self._mjModel, mujoco.mjtObj.mjOBJ_SITE, site_name)
            if site_id < 0:
                return  # site 不存在，静默返回
            
            body_id = self._mjModel.site_bodyid[site_id]
            # 清零该 body 的 xfrc_applied (笛卡尔空间外力)
            self._mjData.xfrc_applied[body_id] = 0
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.warning(f"Failed to clear xfrc_applied for site '{site_name}': {e}")

    def query_joint_qpos(self, joint_names):
        """
        查询指定关节的位置（qpos）。

        参数：
        - `joint_names`：关节名称列表

        返回：
        - 字典，键为关节名称，值为该关节的 `qpos` 数组（长度取决于关节类型）

        说明：
        - 从 `_mjData.qpos` 中提取指定关节的位置。
        - 不同关节类型在 `qpos` 中占用的元素数不同（FREE: 7, BALL: 4, HINGE/SLIDE: 1）。

        注意：
        - 返回的数组是视图（view），修改会影响原始数据；如需独立副本，应使用 `copy()`。
        """
        joint_qpos_dict = {}
        for joint_name in joint_names:
            joint_id = self._mjModel.joint(joint_name).id
            joint_type = self._mjModel.jnt_type[joint_id]
            joint_qpos = self._mjData.qpos[self._mjModel.jnt_qposadr[joint_id]:self._mjModel.jnt_qposadr[joint_id] + get_qpos_size(joint_type)]
            joint_qpos_dict[joint_name] = joint_qpos
        return joint_qpos_dict
    
    def query_joint_qvel(self, joint_names):
        """
        查询指定关节的速度（qvel）。

        参数：
        - `joint_names`：关节名称列表

        返回：
        - 字典，键为关节名称，值为该关节的 `qvel` 数组（长度取决于关节类型）

        说明：
        - 从 `_mjData.qvel` 中提取指定关节的速度。
        - 不同关节类型的自由度不同（FREE: 6, BALL: 3, HINGE/SLIDE: 1）。

        注意：
        - 返回的数组是视图（view），修改会影响原始数据；如需独立副本，应使用 `copy()`。
        """
        joint_qvel_dict = {}
        for joint_name in joint_names:
            joint_id = self._mjModel.joint(joint_name).id
            joint_type = self._mjModel.jnt_type[joint_id]
            joint_qvel_dict[joint_name] = self._mjData.qvel[self._mjModel.jnt_dofadr[joint_id]:self._mjModel.jnt_dofadr[joint_id] + get_dof_size(joint_type)]
        return joint_qvel_dict
    
    def query_joint_qacc(self, joint_names):
        """
        查询指定关节的加速度（qacc）。

        参数：
        - `joint_names`：关节名称列表

        返回：
        - 字典，键为关节名称，值为该关节的 `qacc` 数组（长度取决于关节类型）

        说明：
        - 从 `_mjData.qacc` 中提取指定关节的加速度。
        - 不同关节类型的自由度不同（FREE: 6, BALL: 3, HINGE/SLIDE: 1）。

        注意：
        - 返回的数组是视图（view），修改会影响原始数据；如需独立副本，应使用 `copy()`。
        """
        joint_qacc_dict = {}
        for joint_name in joint_names:
            joint_id = self._mjModel.joint(joint_name).id
            joint_type = self._mjModel.jnt_type[joint_id]
            joint_qacc_dict[joint_name] = self._mjData.qacc[self._mjModel.jnt_dofadr[joint_id]:self._mjModel.jnt_dofadr[joint_id] + get_dof_size(joint_type)]
        return joint_qacc_dict
    
    def jnt_qposadr(self, joint_name):
        """
        查询关节在 `qpos` 数组中的起始地址。

        参数：
        - `joint_name`：关节名称

        返回：
        - `qpos` 数组中的起始索引（int）

        说明：
        - 用于定位关节在全局 `qpos` 数组中的位置。
        - 与 `query_joint_offsets` 类似，但只返回单个关节的地址。

        注意：
        - 地址在模型加载后保持不变。
        """
        joint_id = self._mjModel.joint(joint_name).id
        return self._mjModel.jnt_qposadr[joint_id]
    
    def jnt_dofadr(self, joint_name):
        """
        查询关节在 `qvel/qacc` 数组中的起始地址。

        参数：
        - `joint_name`：关节名称

        返回：
        - `qvel/qacc` 数组中的起始索引（int）

        说明：
        - 用于定位关节在全局 `qvel/qacc` 数组中的位置。
        - 与 `query_joint_offsets` 类似，但只返回单个关节的地址。

        注意：
        - 地址在模型加载后保持不变。
        """
        joint_id = self._mjModel.joint(joint_name).id
        return self._mjModel.jnt_dofadr[joint_id]
    
    def query_site_pos_and_mat(self, site_names: list[str]):
        """
        查询 site 的位置和旋转矩阵。

        参数：
        - `site_names`：site 名称列表

        返回：
        - 字典，键为 site 名称，值为包含 'xpos' 和 'xmat' 的字典

        说明：
        - `xpos`：site 在世界坐标系中的位置 `[x, y, z]`
        - `xmat`：site 在世界坐标系中的旋转矩阵（3x3，按行展开为 9 个元素）

        注意：
        - 返回的数组是视图（view），修改会影响原始数据；如需独立副本，应使用 `copy()`。
        """
        site_pos_and_mat = {}
        for site_name in site_names:
            xpos = self._mjData.site(site_name).xpos
            xmat = self._mjData.site(site_name).xmat
            site_pos_and_mat[site_name] = {"xpos": xpos, "xmat": xmat}
        return site_pos_and_mat

    def query_site_size(self, site_names: list[str]):
        """
        查询 site 的尺寸。

        参数：
        - `site_names`：site 名称列表

        返回：
        - 字典，键为 site 名称，值为尺寸数组

        说明：
        - 从模型信息中读取 site 的尺寸参数。
        - 尺寸的含义取决于 site 的类型（如球体为半径，盒子为半边长等）。

        注意：
        - 返回的数组是副本（copy），修改不会影响原始数据。
        """
        site_size_dict = {}
        for site_name in site_names:
            site_id = self._mjModel.site(site_name).id
            site_size = self._mjModel.site_size[site_id]
            site_size_dict[site_name] = site_size.copy()
        return site_size_dict

    def set_joint_qpos(self, joint_qpos):
        """
        设置指定关节的位置（qpos）。

        参数：
        - `joint_qpos`：字典，键为关节名称，值为该关节的 `qpos` 数组

        说明：
        - 直接修改 `_mjData.qpos` 中对应关节的位置。
        - 修改后通常需要调用 `mj_forward()` 更新派生量（body/site 位姿、传感器等）。

        注意：
        - 数组长度必须与关节类型匹配（FREE: 7, BALL: 4, HINGE/SLIDE: 1）。
        - 修改后建议调用 `mj_forward()` 确保状态一致。
        """
        for joint_name, qpos in joint_qpos.items():
            joint_id = self._mjModel.joint(joint_name).id
            qpos_size = get_qpos_size(self._mjModel.jnt_type[joint_id])
            self._mjData.qpos[self._mjModel.jnt_qposadr[joint_id]:self._mjModel.jnt_qposadr[joint_id] + qpos_size] = qpos.copy()

    def set_joint_qvel(self, joint_qvel):
        """
        设置指定关节的速度（qvel）。

        参数：
        - `joint_qvel`：字典，键为关节名称，值为该关节的 `qvel` 数组

        说明：
        - 直接修改 `_mjData.qvel` 中对应关节的速度。
        - 修改后通常需要调用 `mj_forward()` 更新派生量。

        注意：
        - 数组长度必须与关节类型匹配（FREE: 6, BALL: 3, HINGE/SLIDE: 1）。
        - 修改后建议调用 `mj_forward()` 确保状态一致。
        """
        for joint_name, qvel in joint_qvel.items():
            joint_id = self._mjModel.joint(joint_name).id
            dof_size = get_dof_size(self._mjModel.jnt_type[joint_id])
            self._mjData.qvel[self._mjModel.jnt_dofadr[joint_id]:self._mjModel.jnt_dofadr[joint_id] + dof_size] = qvel.copy()

    def mj_jac_site(self, site_names: list[str]):
        """
        计算多个 site 的雅可比矩阵。

        参数：
        - `site_names`：site 名称列表

        返回：
        - 字典，键为 site 名称，值为包含 'jacp' 和 'jacr' 的字典

        说明：
        - `jacp`：位置雅可比，形状 `(3, nv)`
        - `jacr`：旋转雅可比，形状 `(3, nv)`
        - 用于计算 site 位置/姿态对关节速度的敏感度。

        注意：
        - 返回的数组是新分配的，修改不会影响原始数据。
        """
        site_jacs_dict = {}
        for site_name in site_names:
            site_id = self._mjModel.site(site_name).id
            jacp = np.zeros((3, self.model.nv))
            jacr = np.zeros((3, self.model.nv))
            mujoco.mj_jacSite(self._mjModel, self._mjData, jacp, jacr, site_id)
            site_jacs_dict[site_name] = {"jacp": jacp, "jacr": jacr}
        return site_jacs_dict            
    

    def modify_equality_objects(self, old_obj1_id, old_obj2_id, new_obj1_id, new_obj2_id):
        """
        修改等式约束的目标对象
        
        将等式约束从一个 body 对转移到另一个 body 对，用于物体操作。
        
        术语说明:
            - 等式约束对象: 被约束的两个 body 的 ID
            - 用途: 在抓取物体时，将约束从锚点-虚拟体转移到锚点-真实物体
        
        Args:
            old_obj1_id, old_obj2_id: 原约束的两个 body ID
            new_obj1_id, new_obj2_id: 新约束的两个 body ID
        
        使用示例:
            ```python
            # 修改约束以连接物体
            self.gym.modify_equality_objects(
                old_obj1_id=old_obj1_id,
                old_obj2_id=old_obj2_id,
                new_obj1_id=eq["obj1_id"],
                new_obj2_id=eq["obj2_id"]
            )
            ```
        """
        for i in range(self.model.neq):
            if self._mjModel.eq_obj1id[i] == old_obj1_id and self._mjModel.eq_obj2id[i] == old_obj2_id:
                self._mjModel.eq_obj1id[i] = new_obj1_id
                self._mjModel.eq_obj2id[i] = new_obj2_id
                # print(f"Modified equality constraint {i}: {old_obj1_id}, {old_obj2_id} -> {new_obj1_id}, {new_obj2_id}")
                break

    def update_equality_constraints(self, constraint_list):
        """
        更新等式约束的参数
        
        更新约束的类型和数据，用于改变约束的刚度和行为。
        
        术语说明:
            - eq_data: 约束数据，包含约束的具体参数
            - eq_type: 约束类型（WELD、CONNECT 等）
        
        Args:
            constraint_list: 约束列表，每个元素包含 obj1_id、obj2_id、eq_data、eq_type
        
        使用示例:
            ```python
            # 更新约束列表
            eq_list = self.model.get_eq_list()
            # 修改约束参数...
            self.gym.update_equality_constraints(eq_list)
            ```
        """
        for constraint in constraint_list:
            obj1_id = constraint['obj1_id']
            obj2_id = constraint['obj2_id']
            eq_data = constraint['eq_data']
            eq_type = constraint['eq_type']
            for i in range(self.model.neq):
                if self._mjModel.eq_obj1id[i] == obj1_id and self._mjModel.eq_obj2id[i] == obj2_id:
                    self._mjModel.eq_data[i] = eq_data.copy()
                    self._mjModel.eq_type[i] = eq_type
                    break

            # print("eq_data: ", eq_data)
            # self._mjModel.eq_data[obj1_id:obj1_id + len(eq_data)] = eq_data.copy()
            # print("model.eq_data: ", self._mjModel.eq_data)
            # print("model.eq_obj1id: ", self._mjModel.eq_obj1id)
            # print("model.eq_obj2id: ", self._mjModel.eq_obj2id)
            # print("self.model.neq: ", self._mjModel.neq)
            # print("self.model.eq_type: ", self._mjModel.eq_type)


    async def _remote_set_mocap_pos_and_quat(self, mocap_data):
        """
        远程设置 mocap body 的位置和四元数（内部方法）。

        参数：
        - `mocap_data`：字典，键为 mocap body 名称，值为包含 'pos' 和 'quat' 的字典

        返回：
        - 是否成功（bool）

        说明：
        - 通过 gRPC 调用服务端，设置 mocap body 的位姿。
        - 该方法由 `set_mocap_pos_and_quat` 内部调用，通常不需要直接使用。

        注意：
        - 异步方法，需要在 `async` 函数中 `await` 调用。
        """
        request = mjc_message_pb2.SetMocapPosAndQuatRequest()
        for name, data in mocap_data.items():
            mocap_body_info = request.mocap_body_info.add()
            mocap_body_info.mocap_body_name = name
            mocap_body_info.pos.extend(data['pos'])
            mocap_body_info.quat.extend(data['quat'])

        response = await self.stub.SetMocapPosAndQuat(request)
        return response.success

    async def set_mocap_pos_and_quat(self, mocap_data, send_remote = False):
        """
        设置 mocap body 的位置和四元数
        
        设置 mocap body 的位姿，用于物体操作。如果 send_remote=True，同时同步到服务器。
        
        术语说明:
            - Mocap Body: 详见 orca_gym/core/orca_gym_model.py 中的说明
            - body_mocapid: body 对应的 mocap ID，-1 表示不是 mocap body
        
        Args:
            mocap_data: 字典，键为 mocap body 名称，值为包含 'pos' 和 'quat' 的字典
            send_remote: 是否同步到远程服务器（用于渲染）
        
        使用示例:
            ```python
            # 设置锚点位置
            await self.gym.set_mocap_pos_and_quat({
                "ActorManipulator_Anchor": {
                    "pos": np.array([0.5, 0.0, 0.8]),
                    "quat": np.array([1.0, 0.0, 0.0, 0.0])
                }
            }, send_remote=True)
            ```
        """
        for name, data in mocap_data.items():
            body_id = self._mjModel.body(name).id
            mocap_id = self._mjModel.body_mocapid[body_id]
            if mocap_id != -1:
                # print("mocap_pos: ", self._mjData.mocap_pos[mocap_id])
                # print("mocap_quat: ", self._mjData.mocap_quat[mocap_id])
                self._mjData.mocap_pos[mocap_id] = data['pos'].copy()
                self._mjData.mocap_quat[mocap_id] = data['quat'].copy()
        
        if send_remote:
            await self._remote_set_mocap_pos_and_quat(mocap_data)

    def query_contact_simple(self):
        """
        查询简单接触信息
        
        返回当前所有接触点的基本信息，包括接触的几何体对。
        
        术语说明:
            - 接触 (Contact): 两个几何体之间的碰撞或接触
            - Geom1, Geom2: 接触的两个几何体的 ID
            - Dim: 接触的维度，通常为 3（点接触）或 6（面接触）
        
        Returns:
            contacts: 接触信息列表，每个元素包含接触 ID、维度、几何体 ID 等
        
        使用示例:
            ```python
            # 查询当前所有接触
            contacts = self.gym.query_contact_simple()
            for contact in contacts:
                print(f"Contact between geom {contact['Geom1']} and {contact['Geom2']}")
            ```
        """
        contact = self._mjData.contact
        contacts = []
        for i in range(self._mjData.ncon):
            if contact.geom1[i] >= 0 and contact.geom2[i] >= 0:
                contact_info = {
                    "ID": i,
                    "Dim": contact.dim[i],
                    "Geom1": contact.geom1[i],
                    "Geom2": contact.geom2[i],
                }
                contacts.append(contact_info)
        
        return contacts            
    
    def set_geom_friction(self, geom_friction_dict):
        """
        设置几何体的摩擦系数。

        参数：
        - `geom_friction_dict`：字典，键为几何体名称，值为摩擦系数数组 `[滑动, 扭转, 滚动]`

        说明：
        - 直接修改 `_mjModel` 中几何体的摩擦系数。
        - 摩擦系数影响碰撞时的接触力计算。

        注意：
        - 修改后需要重新初始化模型才能生效（或使用动态修改接口）。
        """
        model = self._mjModel
        for name, friction in geom_friction_dict.items():
            geom = model.geom(name)
            geom.friction = friction.copy()

    def add_extra_weight(self, random_weight_dict):
        """
        为指定 body 添加额外质量。

        参数：
        - `random_weight_dict`：字典，键为 body ID，值为包含 'pos' 和 'weight' 的字典

        说明：
        - 修改 body 的质量和质心位置（`ipos`）。
        - 常用于域随机化（domain randomization）场景。

        注意：
        - 修改后需要重新初始化模型才能生效（或使用动态修改接口）。
        - `pos` 是质心位置偏移，`weight` 是额外质量（会加到原有质量上）。
        """
        # Find the body ID for target_name
        model = self._mjModel
        for body_id, weight_info in random_weight_dict.items():
            torso = model.body(body_id)

            torso.ipos = weight_info['pos']
            torso.mass = [weight_info['weight'] + torso.mass.copy()[0]]

            # print(f"Added extra weight to {body_id}, new weight: {torso.mass}, new ipos: {torso.ipos}")

    def query_contact_force(self, contact_ids):
        """
        查询接触力
        
        计算指定接触点的接触力，包括线性力和力矩。
        
        术语说明:
            - 接触力: 两个物体接触时产生的力和力矩
            - 返回值: 6维向量，前3个为线性力 [fx, fy, fz]，后3个为力矩 [mx, my, mz]
        
        Args:
            contact_ids: 接触点 ID 列表
        
        Returns:
            contact_force_dict: 字典，键为接触 ID，值为6维力向量
        
        使用示例:
            ```python
            # 查询接触力
            contact_ids = [0, 1, 2]  # 接触点 ID
            forces = self.gym.query_contact_force(contact_ids)
            force_0 = forces[0]  # [fx, fy, fz, mx, my, mz]
            ```
        """
        contact_force_dict = {}
        for contact_id in contact_ids:
            contact_force = np.zeros(6)
            mujoco.mj_contactForce(self._mjModel, self._mjData, contact_id, contact_force)
            contact_force_dict[contact_id] = contact_force
        
        return contact_force_dict
    
    def get_cfrc_ext(self):
        """
        获取外部约束力
        
        返回所有 body 受到的外部约束力，包括接触力、等式约束力等。
        
        术语说明:
            - cfrc_ext: 外部约束力，形状 (nbody, 6)，每行为 [fx, fy, fz, mx, my, mz]
            - 用途: 用于分析物体受力、计算奖励等
        
        Returns:
            cfrc_ext: 外部约束力数组，形状 (nbody, 6)
        
        使用示例:
            ```python
            # 获取所有 body 的外部约束力
            cfrc_ext = self.gym.get_cfrc_ext()
            base_force = cfrc_ext[base_body_id]  # 基座的受力
            ```
        """
        return self._mjData.cfrc_ext.copy()

    def query_actuator_torques(self, actuator_names):
        """
        查询执行器扭矩
        
        计算执行器产生的实际扭矩，考虑齿轮比等因素。
        
        术语说明:
            - 执行器扭矩: 执行器实际输出的扭矩
            - 齿轮比 (Gear Ratio): 执行器输出与关节输入的比例
            - actuator_force: MuJoCo 中执行器的原始力/扭矩值
        
        Args:
            actuator_names: 执行器名称列表
        
        Returns:
            actuator_torques: 字典，键为执行器名称，值为6维扭矩向量
        
        使用示例:
            ```python
            # 查询执行器扭矩
            torques = self.gym.query_actuator_torques(["joint1_actuator", "joint2_actuator"])
            torque_1 = torques["joint1_actuator"]  # 6维向量
            ```
        """
        actuator_torques = {}
        for actuator_name in actuator_names:
            # 获取执行器ID
            actuator_id = self._mjModel.actuator(actuator_name).id

            # 获取关联的关节信息
            joint_name = self._mjModel.actuator(actuator_name).trnid[0]  # 直接从模型获取更高效
            joint_id = self._mjModel.joint(joint_name).id
            joint_type = self._mjModel.jnt_type[joint_id]

            # 初始化6维力矩向量
            torque_vector = np.zeros(6, dtype=np.float32)

            if joint_type == mujoco.mjtJoint.mjJNT_HINGE:
                # 铰链关节处理（单自由度）
                gear = self._mjModel.actuator_gear[actuator_id][0]  # 取第一个gear值
                raw_torque = self._mjData.actuator_force[actuator_id]
                torque_vector[0] = raw_torque * gear  # 填充到力矩向量第一维
            else:
                # 其他类型关节（代码保护）
                gear = self._mjModel.actuator_gear[actuator_id][:3]  # 取前3个gear值
                raw_torque = self._mjData.actuator_force[actuator_id][:3]
                torque_vector[:3] = raw_torque * gear  # 填充前三维

            actuator_torques[actuator_name] = torque_vector

        return actuator_torques

    def query_joint_dofadrs(self, joint_names):
        """
        查询指定关节在 `qvel/qacc` 数组中的起始地址。

        参数：
        - `joint_names`：关节名称列表

        返回：
        - 字典，键为关节名称，值为 `qvel/qacc` 数组中的起始索引

        说明：
        - 用于定位关节在全局 `qvel/qacc` 数组中的位置。
        - 与 `query_joint_offsets` 类似，但只返回 DOF 地址。

        注意：
        - 地址在模型加载后保持不变。
        """
        dof_adrs = {}
        for joint_name in joint_names:
            joint_id = self._mjModel.joint(joint_name).id
            dof_adrs[joint_name] = self._mjModel.jnt_dofadr[joint_id]
        return dof_adrs

    def query_velocity_body_B(self, ee_body, base_body):
        """
        查询 body 相对于基座 body 的速度（基座坐标系）
        
        计算末端执行器相对于基座的线速度和角速度，在基座坐标系中表示。
        
        术语说明:
            - 基座坐标系: 以机器人基座为原点的局部坐标系
            - 线速度: 物体在空间中的移动速度
            - 角速度: 物体绕轴旋转的速度
        
        Args:
            ee_body: 末端执行器 body 名称
            base_body: 基座 body 名称
        
        Returns:
            combined_vel: 6维速度向量，前3个为线速度，后3个为角速度（基座坐标系）
        
        使用示例:
            ```python
            # 查询末端执行器相对于基座的速度
            vel_B = self.gym.query_velocity_body_B("end_effector", "base_link")
            linear_vel = vel_B[:3]  # 线速度
            angular_vel = vel_B[3:]  # 角速度
            ```
        """
        base_id = self._mjModel.body(base_body).id
        ee_id = self._mjModel.body(ee_body).id

        ee_vel = np.zeros(6)
        mujoco.mj_objectVelocity(self._mjModel, self._mjData, mujoco.mjtObj.mjOBJ_BODY,
                                 ee_id, ee_vel, 0)
        base_vel = np.zeros(6)
        mujoco.mj_objectVelocity(self._mjModel, self._mjData, mujoco.mjtObj.mjOBJ_BODY,
                                 base_id, base_vel, 0)

        base_pos = self._mjData.body(base_id).xpos.copy()
        base_rot = self._mjData.body(base_id).xmat.copy().reshape(3, 3)

        linear_vel_B = base_rot.T @ (ee_vel[:3] - base_vel[:3])

        angular_vel_B = base_rot.T @ (ee_vel[3:] - base_vel[3:])

        combined_vel = np.concatenate([linear_vel_B, angular_vel_B])
        return combined_vel.astype(np.float32)

    def query_position_body_B(self, ee_body, base_body):
        """
        查询 body 相对于基座 body 的位置（基座坐标系）
        
        计算末端执行器相对于基座的位置，在基座坐标系中表示。
        
        术语说明:
            - 相对位置: 相对于基座的位置，而不是世界坐标系
            - 基座坐标系: 以机器人基座为原点的局部坐标系
        
        Args:
            ee_body: 末端执行器 body 名称
            base_body: 基座 body 名称
        
        Returns:
            relative_pos: 相对位置数组 [x, y, z]（基座坐标系）
        
        使用示例:
            ```python
            # 查询末端执行器相对于基座的位置
            pos_B = self.gym.query_position_body_B("end_effector", "base_link")
            # 返回: [x, y, z]，相对于基座的位置
            ```
        """
        base_id = self._mjModel.body(base_body).id
        base_quat = self._mjData.body(base_id).xquat.copy()  # MuJoCo格式 [w,x,y,z]
        base_pos = self._mjData.body(base_id).xpos.copy()

        ee_id = self._mjModel.body(ee_body).id
        ee_pos = self._mjData.body(ee_id).xpos.copy()

        rot_base = R.from_quat([base_quat[1], base_quat[2], base_quat[3], base_quat[0]])
        rot_inv = rot_base.inv()

        relative_pos = rot_inv.apply(ee_pos - base_pos)

        return relative_pos

    def query_orientation_body_B(self, ee_body, base_body):
        """
        查询 body 相对于基座 body 的姿态（基座坐标系）
        
        计算末端执行器相对于基座的姿态（四元数），在基座坐标系中表示。
        
        术语说明:
            - 相对姿态: 相对于基座的旋转，而不是世界坐标系
            - 四元数: [x, y, z, w] 格式（SciPy 格式）
        
        Args:
            ee_body: 末端执行器 body 名称
            base_body: 基座 body 名称
        
        Returns:
            relative_quat: 相对四元数 [x, y, z, w]（基座坐标系）
        
        使用示例:
            ```python
            # 查询末端执行器相对于基座的姿态
            quat_B = self.gym.query_orientation_body_B("end_effector", "base_link")
            # 返回: [x, y, z, w]，相对于基座的姿态
            ```
        """
        base_id = self._mjModel.body(base_body).id
        base_quat = self._mjData.body(base_id).xquat.copy()  # MuJoCo格式 [w,x,y,z]

        # 转换为SciPy需要的[x,y,z,w]格式
        rot_base = R.from_quat([base_quat[1], base_quat[2], base_quat[3], base_quat[0]])

        ee_id = self._mjModel.body(ee_body).id
        ee_quat = self._mjData.body(ee_id).xquat.copy()
        rot_ee = R.from_quat([ee_quat[1], ee_quat[2], ee_quat[3], ee_quat[0]])

        relative_rot = rot_base.inv() * rot_ee

        return relative_rot.as_quat().astype(np.float32)


    def query_joint_axes_B(self, joint_names, base_body):
        """
        查询关节轴在基座坐标系中的方向。

        参数：
        - `joint_names`：关节名称列表
        - `base_body`：基座 body 名称

        返回：
        - 字典，键为关节名称，值为关节轴方向向量 `[x, y, z]`（基座坐标系）

        说明：
        - 将关节轴从世界坐标系转换到基座坐标系。
        - 用于分析关节在基座坐标系中的方向。

        注意：
        - 返回的数组是副本（copy），修改不会影响原始数据。
        """
        joint_axes = {}
        base_id = self._mjModel.body(base_body).id
        base_rot = R.from_quat(self._mjData.body(base_id).xquat[[1, 2, 3, 0]])

        for joint_name in joint_names:
            joint_id = self._mjModel.joint(joint_name).id
            jnt_axis = self._mjModel.jnt_axis[joint_id]

            body_id = self._mjModel.jnt_bodyid[joint_id]
            body_rot = R.from_quat(self._mjData.body(body_id).xquat[[1, 2, 3, 0]])

            axis_global = body_rot.apply(jnt_axis)
            axis_base = base_rot.inv().apply(axis_global)
            joint_axes[joint_name] = axis_base

        return {
            name:axis_base.astype(np.float32)
            for name, axis_base in joint_axes.items()
        }

    def query_robot_velocity_odom(self, base_body, initial_base_pos, initial_base_quat):
        """
        查询机器人在里程计坐标系中的速度
        
        计算机器人基座相对于初始位置的速度，在初始姿态的坐标系中表示。
        
        术语说明:
            - 里程计 (Odometry): 基于初始位置的相对位置和速度估计
            - 初始姿态坐标系: 以机器人初始姿态为参考的坐标系
            - 用途: 用于移动机器人的定位和导航
        
        Args:
            base_body: 基座 body 名称
            initial_base_pos: 初始基座位置 [x, y, z]
            initial_base_quat: 初始基座四元数 [w, x, y, z]
        
        Returns:
            linear_vel_odom: 线速度 [vx, vy, vz]（里程计坐标系）
            angular_vel_odom: 角速度 [wx, wy, wz]（里程计坐标系）
        
        使用示例:
            ```python
            # 查询机器人速度（相对于初始位置）
            linear, angular = self.gym.query_robot_velocity_odom(
                "base_link", initial_pos, initial_quat
            )
            ```
        """
        base_id = self._mjModel.body(base_body).id
        base_pos = self._mjData.body(base_id).xpos.copy()
        base_quat = self._mjData.body(base_id).xquat.copy()

        initial_base_rot = R.from_quat(initial_base_quat[[1, 2, 3, 0]])

        linera_vel_global = self._mjData.body(base_id).cvel[:3]
        angular_vel_global = self._mjData.body(base_id).cvel[3:]

        linera_vel_odom = initial_base_rot.inv().apply(linera_vel_global)
        angular_vel_odom = initial_base_rot.inv().apply(angular_vel_global)

        return linera_vel_odom.astype(np.float32), angular_vel_odom.astype(np.float32)

    def query_robot_position_odom(self, base_body, initial_base_pos, initial_base_quat):
        """
        查询机器人在里程计坐标系中的位置
        
        计算机器人基座相对于初始位置的位置，在初始姿态的坐标系中表示。
        
        术语说明:
            - 里程计: 详见 query_robot_velocity_odom 的说明
        
        Args:
            base_body: 基座 body 名称
            initial_base_pos: 初始基座位置 [x, y, z]
            initial_base_quat: 初始基座四元数 [w, x, y, z]
        
        Returns:
            pos_odom: 位置 [x, y, z]（里程计坐标系）
        
        使用示例:
            ```python
            # 查询机器人位置（相对于初始位置）
            pos_odom = self.gym.query_robot_position_odom(
                "base_link", initial_pos, initial_quat
            )
            ```
        """
        base_id = self._mjModel.body(base_body).id
        base_pos = self._mjData.body(base_id).xpos.copy()

        initial_base_rot = R.from_quat(initial_base_quat[[1, 2, 3, 0]])

        relative_pos = base_pos - initial_base_pos
        pos_odom = initial_base_rot.inv().apply(relative_pos)

        return pos_odom.astype(np.float32)

    def query_robot_orientation_odom(self, base_body, initial_base_pos, initial_base_quat):
        """
        查询机器人在里程计坐标系中的姿态
        
        计算机器人基座相对于初始姿态的旋转，在初始姿态的坐标系中表示。
        
        术语说明:
            - 里程计: 详见 query_robot_velocity_odom 的说明
        
        Args:
            base_body: 基座 body 名称
            initial_base_pos: 初始基座位置 [x, y, z]（未使用，为接口一致性保留）
            initial_base_quat: 初始基座四元数 [w, x, y, z]
        
        Returns:
            quat_odom: 四元数 [x, y, z, w]（里程计坐标系，SciPy 格式）
        
        使用示例:
            ```python
            # 查询机器人姿态（相对于初始姿态）
            quat_odom = self.gym.query_robot_orientation_odom(
                "base_link", initial_pos, initial_quat
            )
            ```
        """
        base_id = self._mjModel.body(base_body).id
        base_quat = self._mjData.body(base_id).xquat.copy()

        initial_base_rot = R.from_quat(initial_base_quat[[1, 2, 3, 0]])
        base_rot = R.from_quat(base_quat[[1, 2, 3, 0]])

        rot = initial_base_rot.inv() * base_rot
        quat_odom = rot.as_quat()

        return quat_odom.astype(np.float32)

