"""AniBridge shared utilities."""
