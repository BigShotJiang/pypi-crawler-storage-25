from __future__ import annotations

import httpx

from tests.conftest import make_sync_client


def test_auth_header_is_sent() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["X-Api-Key"] == "test-key"
        return httpx.Response(200, json=["USD"])

    client = make_sync_client(httpx.MockTransport(handler))
    response = client.fiat.list()

    assert response[0].value == "USD"
    client.close()
