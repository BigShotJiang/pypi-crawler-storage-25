from __future__ import annotations

import json

import httpx

from kryptoexpress.models.common import CryptoCurrency, WithdrawType
from kryptoexpress.models.wallet import (
    WithdrawalAllRequest,
    WithdrawalRequest,
    WithdrawalSingleRequest,
)
from tests.conftest import make_sync_client


def test_wallet_get_success() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"BTC": 1.5, "USDT_TRC20": 10.0})

    client = make_sync_client(httpx.MockTransport(handler))
    wallet = client.wallet.get()

    assert wallet.BTC == 1.5
    assert wallet.USDT_TRC20 == 10.0
    client.close()


def test_wallet_withdraw_success() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/wallet/withdrawal"
        return httpx.Response(
            200,
            json={
                "id": None,
                "withdrawType": "ALL",
                "paymentId": None,
                "cryptoCurrency": "BTC",
                "toAddress": "bc1dest",
                "txIdList": [],
                "receivingAmount": 1.0,
                "blockchainFeeAmount": 0.01,
                "serviceFeeAmount": 0.02,
                "onlyCalculate": True,
                "totalWithdrawalAmount": 1.03,
                "createDatetime": 1710000000,
            },
        )

    client = make_sync_client(httpx.MockTransport(handler))
    withdrawal = client.wallet.withdraw(
        WithdrawalRequest(
            withdraw_type=WithdrawType.ALL,
            crypto_currency=CryptoCurrency.BTC,
            to_address="bc1dest",
            only_calculate=True,
        )
    )

    assert withdrawal.only_calculate is True
    assert withdrawal.receiving_amount == 1.0
    client.close()


def test_wallet_dry_run_calculate_sets_only_calculate_true() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/wallet/withdrawal"
        assert json.loads(request.read())["onlyCalculate"] is True
        return httpx.Response(
            200,
            json={
                "id": None,
                "withdrawType": "SINGLE",
                "paymentId": 123,
                "cryptoCurrency": "BTC",
                "toAddress": "bc1dest",
                "txIdList": [],
                "receivingAmount": 1.0,
                "blockchainFeeAmount": 0.01,
                "serviceFeeAmount": 0.02,
                "onlyCalculate": True,
                "totalWithdrawalAmount": 1.03,
                "createDatetime": 1710000000,
            },
        )

    client = make_sync_client(httpx.MockTransport(handler))
    withdrawal = client.wallet.calculate(
        WithdrawalSingleRequest(
            payment_id=123,
            crypto_currency=CryptoCurrency.BTC,
            to_address="bc1dest",
            only_calculate=False,
        )
    )

    assert withdrawal.withdraw_type is WithdrawType.SINGLE
    assert withdrawal.only_calculate is True
    client.close()


def test_withdrawal_all_request_type_defaults() -> None:
    request = WithdrawalAllRequest(
        crypto_currency=CryptoCurrency.BTC,
        to_address="bc1dest",
        only_calculate=True,
    )
    assert request.withdraw_type is WithdrawType.ALL
    assert request.payment_id is None


def test_wallet_shortcut_methods() -> None:
    calls: list[dict[str, object]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(json.loads(request.read()))
        return httpx.Response(
            200,
            json={
                "id": 1,
                "withdrawType": calls[-1]["withdrawType"],
                "paymentId": calls[-1].get("paymentId"),
                "cryptoCurrency": "BTC",
                "toAddress": "bc1dest",
                "txIdList": [],
                "receivingAmount": 1.0,
                "blockchainFeeAmount": 0.01,
                "serviceFeeAmount": 0.02,
                "onlyCalculate": calls[-1]["onlyCalculate"],
                "totalWithdrawalAmount": 1.03,
                "createDatetime": 1710000000,
            },
        )

    client = make_sync_client(httpx.MockTransport(handler))
    client.wallet.withdraw_all(crypto_currency=CryptoCurrency.BTC, to_address="bc1dest")
    client.wallet.calculate_single(
        payment_id=123,
        crypto_currency=CryptoCurrency.BTC,
        to_address="bc1dest",
    )

    assert calls[0]["withdrawType"] == "ALL"
    assert calls[0]["onlyCalculate"] is False
    assert calls[1]["withdrawType"] == "SINGLE"
    assert calls[1]["onlyCalculate"] is True
    client.close()
