from __future__ import annotations

from kryptoexpress.webhooks import compute_callback_signature, verify_callback_signature


def test_verify_callback_signature_accepts_valid_signature() -> None:
    raw_body = '{\n  "status": "paid",\n  "hash": "abc123"\n}'
    signature = compute_callback_signature(
        raw_body=raw_body,
        callback_secret="super-secret",
    )

    assert (
        verify_callback_signature(
            raw_body=raw_body,
            callback_secret="super-secret",
            signature=signature,
        )
        is True
    )


def test_verify_callback_signature_rejects_invalid_signature() -> None:
    raw_body = '{"status":"paid","hash":"abc123"}'

    assert (
        verify_callback_signature(
            raw_body=raw_body,
            callback_secret="super-secret",
            signature="bad-signature",
        )
        is False
    )
