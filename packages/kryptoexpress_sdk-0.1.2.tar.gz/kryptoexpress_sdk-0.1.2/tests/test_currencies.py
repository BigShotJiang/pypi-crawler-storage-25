from __future__ import annotations

import httpx

from kryptoexpress.models.common import CryptoCurrency, FiatCurrency
from tests.conftest import make_sync_client


def test_currencies_list_all() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=["BTC", "ETH"])

    client = make_sync_client(httpx.MockTransport(handler))
    currencies = client.currencies.list_all()

    assert currencies == [CryptoCurrency.BTC, CryptoCurrency.ETH]
    client.close()


def test_get_prices_formats_query_params_for_multiple_currencies() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.params["cryptoCurrency"] == "BTC,ETH"
        assert request.url.params["fiatCurrency"] == "USD"
        return httpx.Response(
            200,
            json=[
                {"cryptoCurrency": "BTC", "fiatCurrency": "USD", "price": 100000.0},
                {"cryptoCurrency": "ETH", "fiatCurrency": "USD", "price": 2000.0},
            ],
        )

    client = make_sync_client(httpx.MockTransport(handler))
    prices = client.currencies.get_prices(
        crypto_currencies=[CryptoCurrency.BTC, CryptoCurrency.ETH],
        fiat_currency=FiatCurrency.USD,
    )

    assert len(prices.prices) == 2
    assert prices.prices[1].crypto_currency is CryptoCurrency.ETH
    client.close()


def test_get_prices_normalizes_single_object_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={"cryptoCurrency": "BTC", "fiatCurrency": "USD", "price": 100000.0},
        )

    client = make_sync_client(httpx.MockTransport(handler))
    prices = client.currencies.get_prices(
        crypto_currencies=[CryptoCurrency.BTC],
        fiat_currency=FiatCurrency.USD,
    )

    assert len(prices.prices) == 1
    assert prices.prices[0].price == 100000.0
    client.close()
