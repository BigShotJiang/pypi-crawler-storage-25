from __future__ import annotations

import httpx
import pytest

from kryptoexpress.client import KryptoExpressClient
from kryptoexpress.errors import AuthError, NotFoundError, RateLimitError, ValidationError
from tests.conftest import make_sync_client


def test_error_mapping_validation_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            400,
            json={
                "error": "validation_error",
                "message": "Invalid request body",
                "details": [{"field": "fiatAmount", "message": "Required"}],
            },
        )

    client = make_sync_client(httpx.MockTransport(handler))
    with pytest.raises(ValidationError) as exc_info:
        client.payments.get_by_hash("bad")

    assert exc_info.value.details[0]["field"] == "fiatAmount"
    client.close()


def test_error_mapping_not_found() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, text="Payment not found.")

    client = make_sync_client(httpx.MockTransport(handler))
    with pytest.raises(NotFoundError):
        client.payments.get_by_hash("missing")
    client.close()


def test_error_mapping_rate_limit() -> None:
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(429, json={"error": "rate_limited", "retryAfter": 1})

    http_client = httpx.Client(
        transport=httpx.MockTransport(handler),
        base_url="https://kryptoexpress.pro/api",
        headers={"X-Api-Key": "test-key"},
    )
    client = KryptoExpressClient(
        api_key="test-key",
        max_retries=1,
        http_client=http_client,
    )

    with pytest.raises(RateLimitError):
        client.fiat.list()

    assert calls["count"] == 2
    client.close()


def test_error_mapping_auth_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": "unauthorized", "message": "Bad key"})

    client = make_sync_client(httpx.MockTransport(handler))
    with pytest.raises(AuthError):
        client.wallet.get()
    client.close()
