"""Top-level SDK clients."""

from __future__ import annotations

import httpx

from kryptoexpress._http import AsyncTransport, SyncTransport
from kryptoexpress.config import ClientConfig
from kryptoexpress.policies import (
    AsyncFiatConverterLike,
    MinimumAmountPolicy,
    PaymentRequestValidator,
    SyncFiatConverterLike,
)
from kryptoexpress.resources.currencies import AsyncCurrenciesResource, CurrenciesResource
from kryptoexpress.resources.fiat import AsyncFiatResource, FiatResource
from kryptoexpress.resources.payments import AsyncPaymentsResource, PaymentsResource
from kryptoexpress.resources.wallet import AsyncWalletResource, WalletResource


class KryptoExpressClient:
    """Synchronous KryptoExpress API client."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://kryptoexpress.pro/api",
        timeout: float = 10.0,
        max_retries: int = 0,
        fiat_converter: SyncFiatConverterLike | None = None,
        minimum_amount_policy: MinimumAmountPolicy | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.config = ClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._transport = SyncTransport(self.config, client=http_client)
        self.minimum_amount_policy = minimum_amount_policy or MinimumAmountPolicy(
            sync_converter=fiat_converter
        )
        self._payment_validator = PaymentRequestValidator(
            minimum_amount_policy=self.minimum_amount_policy
        )
        self.payments = PaymentsResource(self._transport, self._payment_validator)
        self.wallet = WalletResource(self._transport)
        self.currencies = CurrenciesResource(self._transport)
        self.fiat = FiatResource(self._transport)

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> KryptoExpressClient:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()


class AsyncKryptoExpressClient:
    """Asynchronous KryptoExpress API client."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://kryptoexpress.pro/api",
        timeout: float = 10.0,
        max_retries: int = 0,
        async_fiat_converter: AsyncFiatConverterLike | None = None,
        minimum_amount_policy: MinimumAmountPolicy | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self.config = ClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._transport = AsyncTransport(self.config, client=http_client)
        self.minimum_amount_policy = minimum_amount_policy or MinimumAmountPolicy(
            async_converter=async_fiat_converter
        )
        self._payment_validator = PaymentRequestValidator(
            minimum_amount_policy=self.minimum_amount_policy
        )
        self.payments = AsyncPaymentsResource(self._transport, self._payment_validator)
        self.wallet = AsyncWalletResource(self._transport)
        self.currencies = AsyncCurrenciesResource(self._transport)
        self.fiat = AsyncFiatResource(self._transport)

    async def aclose(self) -> None:
        await self._transport.aclose()

    async def __aenter__(self) -> AsyncKryptoExpressClient:
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self.aclose()
