"""Shared models and enums used across resources."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


def to_camel(field_name: str) -> str:
    """Convert a snake_case field name to camelCase."""
    return "".join(
        word.capitalize() if index > 0 else word for index, word in enumerate(field_name.split("_"))
    )


class PaymentType(str, Enum):
    PAYMENT = "PAYMENT"
    DEPOSIT = "DEPOSIT"


class PaymentBehavior(str, Enum):
    EXACT = "EXACT"
    OVERPAYMENT = "OVERPAYMENT"
    SPLIT = "SPLIT"


class WithdrawType(str, Enum):
    ALL = "ALL"
    SINGLE = "SINGLE"


class CryptoCurrency(str, Enum):
    BTC = "BTC"
    LTC = "LTC"
    SOL = "SOL"
    TRX = "TRX"
    ETH = "ETH"
    BNB = "BNB"
    USDT_TRC20 = "USDT_TRC20"
    USDT_ERC20 = "USDT_ERC20"
    USDT_BEP20 = "USDT_BEP20"
    USDC_ERC20 = "USDC_ERC20"
    USDT_SOL = "USDT_SOL"
    USDC_SOL = "USDC_SOL"
    USDC_BEP20 = "USDC_BEP20"
    DOGE = "DOGE"


class FiatCurrency(str, Enum):
    USD = "USD"
    EUR = "EUR"
    GBP = "GBP"
    JPY = "JPY"
    CHF = "CHF"
    AUD = "AUD"
    CAD = "CAD"
    CNY = "CNY"
    HKD = "HKD"
    SGD = "SGD"
    SEK = "SEK"
    NOK = "NOK"
    DKK = "DKK"
    PLN = "PLN"
    CZK = "CZK"
    HUF = "HUF"
    TRY = "TRY"
    INR = "INR"
    KRW = "KRW"
    THB = "THB"
    IDR = "IDR"
    MYR = "MYR"
    PHP = "PHP"
    VND = "VND"
    AED = "AED"
    SAR = "SAR"
    ZAR = "ZAR"
    NGN = "NGN"
    KES = "KES"
    GHS = "GHS"
    BRL = "BRL"
    MXN = "MXN"
    ARS = "ARS"
    CLP = "CLP"
    COP = "COP"
    PEN = "PEN"
    RUB = "RUB"
    UAH = "UAH"
    ILS = "ILS"
    PKR = "PKR"
    BDT = "BDT"
    LKR = "LKR"
    TWD = "TWD"
    BHD = "BHD"
    KWD = "KWD"
    RON = "RON"
    NZD = "NZD"


class FieldError(BaseModel):
    """Validation detail returned by the API."""

    field: str
    message: str


class ApiErrorPayload(BaseModel):
    """Structured API error payload where available."""

    model_config = ConfigDict(extra="ignore")

    error: str
    message: str | None = None
    retryAfter: int | None = None
    details: list[FieldError] = Field(default_factory=list)
