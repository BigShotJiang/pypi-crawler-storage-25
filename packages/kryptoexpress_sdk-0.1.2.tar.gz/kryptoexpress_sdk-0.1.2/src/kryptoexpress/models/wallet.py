"""Wallet resource models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from kryptoexpress.models.common import CryptoCurrency, WithdrawType, to_camel


class WithdrawalRequest(BaseModel):
    """Request model for withdrawing wallet funds."""

    withdraw_type: WithdrawType
    crypto_currency: CryptoCurrency
    to_address: str
    only_calculate: bool
    payment_id: int | None = None

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=to_camel,
    )


class WithdrawalAllRequest(WithdrawalRequest):
    """Typed request for `withdrawType=ALL`."""

    withdraw_type: WithdrawType = WithdrawType.ALL
    payment_id: int | None = None


class WithdrawalSingleRequest(WithdrawalRequest):
    """Typed request for `withdrawType=SINGLE`."""

    withdraw_type: WithdrawType = WithdrawType.SINGLE
    payment_id: int


class Withdrawal(BaseModel):
    """Withdrawal entity returned by the API."""

    id: int | None = None
    withdraw_type: WithdrawType
    payment_id: int | None = None
    crypto_currency: CryptoCurrency
    to_address: str
    tx_id_list: list[str] = Field(default_factory=list)
    receiving_amount: float | None = None
    blockchain_fee_amount: float | None = None
    service_fee_amount: float | None = None
    only_calculate: bool
    total_withdrawal_amount: float | None = None
    create_datetime: int | None = None

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=to_camel,
    )


class Wallet(BaseModel):
    """Wallet balances keyed by currency code.

    The upstream schema is inconsistent with the shared currency enums, so the model allows
    additional currency keys for forward compatibility.
    """

    BTC: float | None = None
    LTC: float | None = None
    SOL: float | None = None
    TRX: float | None = None
    ETH: float | None = None
    BNB: float | None = None
    DOGE: float | None = None
    USDT_TRC20: float | None = None
    USDT_ERC20: float | None = None
    USDC_ERC20: float | None = None
    USDT_BEP20: float | None = None
    USDC_BEP20: float | None = None
    USDT_SOL: float | None = None
    USDC_SOL: float | None = None

    model_config = ConfigDict(extra="allow")
