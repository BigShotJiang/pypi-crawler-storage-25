"""Currency resource models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from kryptoexpress.models.common import CryptoCurrency, FiatCurrency, to_camel


class CryptoPrice(BaseModel):
    """A single cryptocurrency price in a given fiat currency."""

    crypto_currency: CryptoCurrency
    fiat_currency: FiatCurrency
    price: float

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=to_camel,
    )


class CryptoPricesResponse(BaseModel):
    """Normalized price response.

    The published schema describes a single object, while the query shape suggests multiple
    cryptocurrencies are supported. The SDK always normalizes to a list-like response.
    """

    prices: list[CryptoPrice]
