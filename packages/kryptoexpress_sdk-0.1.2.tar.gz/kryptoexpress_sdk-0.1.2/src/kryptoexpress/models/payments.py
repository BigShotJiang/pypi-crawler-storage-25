"""Payment resource models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from kryptoexpress.models.common import (
    CryptoCurrency,
    FiatCurrency,
    PaymentBehavior,
    PaymentType,
    to_camel,
)


class PaymentCreateRequest(BaseModel):
    """Request model for creating a payment or deposit.

    `payment_behavior` is a client-side SDK hint used for domain validation and documentation.
    It is not sent to the API.
    """

    payment_type: PaymentType
    crypto_currency: CryptoCurrency
    fiat_currency: FiatCurrency
    fiat_amount: float | None = None
    callback_url: str
    callback_secret: str | None = None
    payment_behavior: PaymentBehavior | None = Field(default=None, exclude=True)

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=to_camel,
    )

    @classmethod
    def for_payment(
        cls,
        *,
        crypto_currency: CryptoCurrency,
        fiat_currency: FiatCurrency,
        fiat_amount: float,
        callback_url: str,
        callback_secret: str | None = None,
        payment_behavior: PaymentBehavior = PaymentBehavior.EXACT,
    ) -> PaymentCreateRequest:
        """Build a `PAYMENT` request with explicit payment behavior semantics."""

        return cls(
            payment_type=PaymentType.PAYMENT,
            crypto_currency=crypto_currency,
            fiat_currency=fiat_currency,
            fiat_amount=fiat_amount,
            callback_url=callback_url,
            callback_secret=callback_secret,
            payment_behavior=payment_behavior,
        )

    @classmethod
    def for_deposit(
        cls,
        *,
        crypto_currency: CryptoCurrency,
        fiat_currency: FiatCurrency,
        callback_url: str,
        callback_secret: str | None = None,
    ) -> PaymentCreateRequest:
        """Build a `DEPOSIT` request where incoming on-chain amount is not known in advance."""

        return cls(
            payment_type=PaymentType.DEPOSIT,
            crypto_currency=crypto_currency,
            fiat_currency=fiat_currency,
            callback_url=callback_url,
            callback_secret=callback_secret,
        )


class Payment(BaseModel):
    """Payment entity returned by the API."""

    id: int
    payment_type: PaymentType
    fiat_currency: FiatCurrency
    fiat_amount: float | None = None
    crypto_amount: float | None = None
    crypto_currency: CryptoCurrency
    expire_datetime: int | None = None
    create_datetime: int | None = None
    paid_at: int | None = None
    address: str | None = None
    is_paid: bool | None = None
    is_withdrawn: bool | None = None
    hash: str | None = None
    callback_url: str

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=to_camel,
    )
