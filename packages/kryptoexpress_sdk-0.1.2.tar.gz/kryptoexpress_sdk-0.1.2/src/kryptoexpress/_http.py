"""Shared HTTP transport helpers for sync and async clients."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import httpx
from pydantic import BaseModel

from kryptoexpress._auth import build_auth_headers
from kryptoexpress.config import ClientConfig
from kryptoexpress.errors import APIError, AuthError, NotFoundError, RateLimitError, ValidationError
from kryptoexpress.models.common import ApiErrorPayload


class BaseTransport:
    """Common request/response helpers."""

    def __init__(self, config: ClientConfig) -> None:
        self._config = config

    def _build_request_kwargs(
        self,
        *,
        params: Mapping[str, Any] | None = None,
        json_data: BaseModel | dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {}
        if params is not None:
            kwargs["params"] = dict(params)
        if json_data is not None:
            if isinstance(json_data, BaseModel):
                kwargs["json"] = json_data.model_dump(
                    mode="json",
                    by_alias=True,
                    exclude_none=True,
                )
            else:
                kwargs["json"] = json_data
        return kwargs

    def _raise_for_response(self, response: httpx.Response) -> None:
        if response.is_success:
            return

        payload: ApiErrorPayload | None = None
        raw_text = response.text
        try:
            payload = ApiErrorPayload.model_validate(response.json())
        except Exception:
            payload = None

        message = (
            payload.message
            if payload and payload.message
            else raw_text
            if raw_text
            else f"HTTP {response.status_code}"
        )
        error = payload.error if payload else None
        retry_after = payload.retryAfter if payload else None
        details = [detail.model_dump() for detail in payload.details] if payload else []

        exc_cls: type[APIError]
        if response.status_code in (401, 403):
            exc_cls = AuthError
        elif response.status_code == 404:
            exc_cls = NotFoundError
        elif response.status_code == 429:
            exc_cls = RateLimitError
        elif response.status_code == 400:
            exc_cls = ValidationError
        else:
            exc_cls = APIError

        raise exc_cls(
            message=message,
            status_code=response.status_code,
            error=error,
            retry_after=retry_after,
            details=details,
            response_text=raw_text or None,
        )

    def _should_retry_response(self, response: httpx.Response, attempt: int) -> bool:
        return attempt < self._config.max_retries and response.status_code in {
            429,
            500,
            502,
            503,
            504,
        }


class SyncTransport(BaseTransport):
    """Synchronous HTTP transport."""

    def __init__(self, config: ClientConfig, client: httpx.Client | None = None) -> None:
        super().__init__(config)
        self._client = client or httpx.Client(
            base_url=config.base_url,
            timeout=config.timeout,
            headers=build_auth_headers(config.api_key),
        )
        self._owns_client = client is None

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json_data: BaseModel | dict[str, Any] | None = None,
    ) -> Any:
        response: httpx.Response | None = None
        for attempt in range(self._config.max_retries + 1):
            response = self._client.request(
                method,
                path,
                **self._build_request_kwargs(params=params, json_data=json_data),
            )
            if not self._should_retry_response(response, attempt):
                break
        assert response is not None
        self._raise_for_response(response)
        if not response.content:
            return None
        return response.json()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()


class AsyncTransport(BaseTransport):
    """Asynchronous HTTP transport."""

    def __init__(self, config: ClientConfig, client: httpx.AsyncClient | None = None) -> None:
        super().__init__(config)
        self._client = client or httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.timeout,
            headers=build_auth_headers(config.api_key),
        )
        self._owns_client = client is None

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json_data: BaseModel | dict[str, Any] | None = None,
    ) -> Any:
        response: httpx.Response | None = None
        for attempt in range(self._config.max_retries + 1):
            response = await self._client.request(
                method,
                path,
                **self._build_request_kwargs(params=params, json_data=json_data),
            )
            if not self._should_retry_response(response, attempt):
                break
        assert response is not None
        self._raise_for_response(response)
        if not response.content:
            return None
        return response.json()

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()
