"""Internal utilities."""

from __future__ import annotations

from typing import Any


def omit_none(data: dict[str, Any]) -> dict[str, Any]:
    """Drop keys whose value is None."""
    return {key: value for key, value in data.items() if value is not None}
