"""Wallet resources."""

from __future__ import annotations

from kryptoexpress._http import AsyncTransport, SyncTransport
from kryptoexpress.models.common import CryptoCurrency
from kryptoexpress.models.wallet import (
    Wallet,
    Withdrawal,
    WithdrawalAllRequest,
    WithdrawalRequest,
    WithdrawalSingleRequest,
)

WithdrawalCreateRequest = WithdrawalAllRequest | WithdrawalSingleRequest | WithdrawalRequest


class WalletResource:
    """Synchronous wallet resource methods."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def get(self) -> Wallet:
        payload = self._transport.request("GET", "/wallet")
        return Wallet.model_validate(payload)

    def withdraw(self, request: WithdrawalCreateRequest) -> Withdrawal:
        payload = self._transport.request("POST", "/wallet/withdrawal", json_data=request)
        return Withdrawal.model_validate(payload)

    def calculate(self, request: WithdrawalCreateRequest) -> Withdrawal:
        """Run a withdrawal dry-run with `onlyCalculate=true`."""

        dry_run_request = request.model_copy(update={"only_calculate": True})
        payload = self._transport.request("POST", "/wallet/withdrawal", json_data=dry_run_request)
        return Withdrawal.model_validate(payload)

    def withdraw_all(
        self,
        *,
        crypto_currency: CryptoCurrency,
        to_address: str,
        only_calculate: bool = False,
    ) -> Withdrawal:
        """Withdraw all available balance for a currency."""

        return self.withdraw(
            WithdrawalAllRequest(
                crypto_currency=crypto_currency,
                to_address=to_address,
                only_calculate=only_calculate,
            )
        )

    def withdraw_single(
        self,
        *,
        payment_id: int,
        crypto_currency: CryptoCurrency,
        to_address: str,
        only_calculate: bool = False,
    ) -> Withdrawal:
        """Withdraw funds linked to a single payment."""

        return self.withdraw(
            WithdrawalSingleRequest(
                payment_id=payment_id,
                crypto_currency=crypto_currency,
                to_address=to_address,
                only_calculate=only_calculate,
            )
        )

    def calculate_all(
        self,
        *,
        crypto_currency: CryptoCurrency,
        to_address: str,
    ) -> Withdrawal:
        """Run a dry-run calculation for `withdrawType=ALL`."""

        return self.calculate(
            WithdrawalAllRequest(
                crypto_currency=crypto_currency,
                to_address=to_address,
                only_calculate=False,
            )
        )

    def calculate_single(
        self,
        *,
        payment_id: int,
        crypto_currency: CryptoCurrency,
        to_address: str,
    ) -> Withdrawal:
        """Run a dry-run calculation for `withdrawType=SINGLE`."""

        return self.calculate(
            WithdrawalSingleRequest(
                payment_id=payment_id,
                crypto_currency=crypto_currency,
                to_address=to_address,
                only_calculate=False,
            )
        )


class AsyncWalletResource:
    """Asynchronous wallet resource methods."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def get(self) -> Wallet:
        payload = await self._transport.request("GET", "/wallet")
        return Wallet.model_validate(payload)

    async def withdraw(self, request: WithdrawalCreateRequest) -> Withdrawal:
        payload = await self._transport.request("POST", "/wallet/withdrawal", json_data=request)
        return Withdrawal.model_validate(payload)

    async def calculate(self, request: WithdrawalCreateRequest) -> Withdrawal:
        """Run a withdrawal dry-run with `onlyCalculate=true`."""

        dry_run_request = request.model_copy(update={"only_calculate": True})
        payload = await self._transport.request(
            "POST",
            "/wallet/withdrawal",
            json_data=dry_run_request,
        )
        return Withdrawal.model_validate(payload)

    async def withdraw_all(
        self,
        *,
        crypto_currency: CryptoCurrency,
        to_address: str,
        only_calculate: bool = False,
    ) -> Withdrawal:
        """Withdraw all available balance for a currency."""

        return await self.withdraw(
            WithdrawalAllRequest(
                crypto_currency=crypto_currency,
                to_address=to_address,
                only_calculate=only_calculate,
            )
        )

    async def withdraw_single(
        self,
        *,
        payment_id: int,
        crypto_currency: CryptoCurrency,
        to_address: str,
        only_calculate: bool = False,
    ) -> Withdrawal:
        """Withdraw funds linked to a single payment."""

        return await self.withdraw(
            WithdrawalSingleRequest(
                payment_id=payment_id,
                crypto_currency=crypto_currency,
                to_address=to_address,
                only_calculate=only_calculate,
            )
        )

    async def calculate_all(
        self,
        *,
        crypto_currency: CryptoCurrency,
        to_address: str,
    ) -> Withdrawal:
        """Run a dry-run calculation for `withdrawType=ALL`."""

        return await self.calculate(
            WithdrawalAllRequest(
                crypto_currency=crypto_currency,
                to_address=to_address,
                only_calculate=False,
            )
        )

    async def calculate_single(
        self,
        *,
        payment_id: int,
        crypto_currency: CryptoCurrency,
        to_address: str,
    ) -> Withdrawal:
        """Run a dry-run calculation for `withdrawType=SINGLE`."""

        return await self.calculate(
            WithdrawalSingleRequest(
                payment_id=payment_id,
                crypto_currency=crypto_currency,
                to_address=to_address,
                only_calculate=False,
            )
        )
