"""Fiat currency resources."""

from __future__ import annotations

from kryptoexpress._http import AsyncTransport, SyncTransport
from kryptoexpress.models.common import FiatCurrency


class FiatResource:
    """Synchronous fiat currency resource methods."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def list(self) -> list[FiatCurrency]:
        payload = self._transport.request("GET", "/currency")
        return [FiatCurrency(item) for item in payload]


class AsyncFiatResource:
    """Asynchronous fiat currency resource methods."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def list(self) -> list[FiatCurrency]:
        payload = await self._transport.request("GET", "/currency")
        return [FiatCurrency(item) for item in payload]
