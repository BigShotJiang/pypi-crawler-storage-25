"""Payment resources."""

from __future__ import annotations

from kryptoexpress._http import AsyncTransport, SyncTransport
from kryptoexpress.models.common import CryptoCurrency, FiatCurrency, PaymentBehavior
from kryptoexpress.models.payments import Payment, PaymentCreateRequest
from kryptoexpress.policies import PaymentRequestValidator


class PaymentsResource:
    """Synchronous payment resource methods."""

    def __init__(self, transport: SyncTransport, validator: PaymentRequestValidator) -> None:
        self._transport = transport
        self._validator = validator

    def create(self, request: PaymentCreateRequest) -> Payment:
        self._validator.validate(request)
        payload = self._transport.request("POST", "/payment", json_data=request)
        return Payment.model_validate(payload)

    def create_payment(
        self,
        *,
        crypto_currency: CryptoCurrency,
        fiat_currency: FiatCurrency,
        fiat_amount: float,
        callback_url: str,
        callback_secret: str | None = None,
        payment_behavior: PaymentBehavior = PaymentBehavior.EXACT,
    ) -> Payment:
        """Create a `PAYMENT` with explicit SDK-side payment behavior semantics."""

        return self.create(
            PaymentCreateRequest.for_payment(
                crypto_currency=crypto_currency,
                fiat_currency=fiat_currency,
                fiat_amount=fiat_amount,
                callback_url=callback_url,
                callback_secret=callback_secret,
                payment_behavior=payment_behavior,
            )
        )

    def create_deposit(
        self,
        *,
        crypto_currency: CryptoCurrency,
        fiat_currency: FiatCurrency,
        callback_url: str,
        callback_secret: str | None = None,
    ) -> Payment:
        """Create a `DEPOSIT` for cases where the incoming on-chain amount is unknown."""

        return self.create(
            PaymentCreateRequest.for_deposit(
                crypto_currency=crypto_currency,
                fiat_currency=fiat_currency,
                callback_url=callback_url,
                callback_secret=callback_secret,
            )
        )

    def get_by_hash(self, payment_hash: str) -> Payment:
        payload = self._transport.request("GET", "/payment", params={"hash": payment_hash})
        return Payment.model_validate(payload)


class AsyncPaymentsResource:
    """Asynchronous payment resource methods."""

    def __init__(self, transport: AsyncTransport, validator: PaymentRequestValidator) -> None:
        self._transport = transport
        self._validator = validator

    async def create(self, request: PaymentCreateRequest) -> Payment:
        await self._validator.avalidate(request)
        payload = await self._transport.request("POST", "/payment", json_data=request)
        return Payment.model_validate(payload)

    async def create_payment(
        self,
        *,
        crypto_currency: CryptoCurrency,
        fiat_currency: FiatCurrency,
        fiat_amount: float,
        callback_url: str,
        callback_secret: str | None = None,
        payment_behavior: PaymentBehavior = PaymentBehavior.EXACT,
    ) -> Payment:
        """Create a `PAYMENT` with explicit SDK-side payment behavior semantics."""

        return await self.create(
            PaymentCreateRequest.for_payment(
                crypto_currency=crypto_currency,
                fiat_currency=fiat_currency,
                fiat_amount=fiat_amount,
                callback_url=callback_url,
                callback_secret=callback_secret,
                payment_behavior=payment_behavior,
            )
        )

    async def create_deposit(
        self,
        *,
        crypto_currency: CryptoCurrency,
        fiat_currency: FiatCurrency,
        callback_url: str,
        callback_secret: str | None = None,
    ) -> Payment:
        """Create a `DEPOSIT` for cases where the incoming on-chain amount is unknown."""

        return await self.create(
            PaymentCreateRequest.for_deposit(
                crypto_currency=crypto_currency,
                fiat_currency=fiat_currency,
                callback_url=callback_url,
                callback_secret=callback_secret,
            )
        )

    async def get_by_hash(self, payment_hash: str) -> Payment:
        payload = await self._transport.request("GET", "/payment", params={"hash": payment_hash})
        return Payment.model_validate(payload)
