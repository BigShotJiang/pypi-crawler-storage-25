"""Cryptocurrency resources."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from kryptoexpress._http import AsyncTransport, SyncTransport
from kryptoexpress.models.common import CryptoCurrency, FiatCurrency
from kryptoexpress.models.currencies import CryptoPrice, CryptoPricesResponse


def _normalize_prices_payload(payload: Any) -> CryptoPricesResponse:
    if isinstance(payload, list):
        prices = [CryptoPrice.model_validate(item) for item in payload]
        return CryptoPricesResponse(prices=prices)
    return CryptoPricesResponse(prices=[CryptoPrice.model_validate(payload)])


class CurrenciesResource:
    """Synchronous cryptocurrency resource methods."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def list_all(self) -> list[CryptoCurrency]:
        payload = self._transport.request("GET", "/cryptocurrency/all")
        return [CryptoCurrency(item) for item in payload]

    def list_native(self) -> list[CryptoCurrency]:
        payload = self._transport.request("GET", "/cryptocurrency")
        return [CryptoCurrency(item) for item in payload]

    def list_stable(self) -> list[CryptoCurrency]:
        payload = self._transport.request("GET", "/cryptocurrency/stable")
        return [CryptoCurrency(item) for item in payload]

    def get_prices(
        self,
        *,
        crypto_currencies: Sequence[CryptoCurrency],
        fiat_currency: FiatCurrency,
    ) -> CryptoPricesResponse:
        payload = self._transport.request(
            "GET",
            "/cryptocurrency/price",
            params={
                "cryptoCurrency": ",".join(currency.value for currency in crypto_currencies),
                "fiatCurrency": fiat_currency.value,
            },
        )
        return _normalize_prices_payload(payload)


class AsyncCurrenciesResource:
    """Asynchronous cryptocurrency resource methods."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def list_all(self) -> list[CryptoCurrency]:
        payload = await self._transport.request("GET", "/cryptocurrency/all")
        return [CryptoCurrency(item) for item in payload]

    async def list_native(self) -> list[CryptoCurrency]:
        payload = await self._transport.request("GET", "/cryptocurrency")
        return [CryptoCurrency(item) for item in payload]

    async def list_stable(self) -> list[CryptoCurrency]:
        payload = await self._transport.request("GET", "/cryptocurrency/stable")
        return [CryptoCurrency(item) for item in payload]

    async def get_prices(
        self,
        *,
        crypto_currencies: Sequence[CryptoCurrency],
        fiat_currency: FiatCurrency,
    ) -> CryptoPricesResponse:
        payload = await self._transport.request(
            "GET",
            "/cryptocurrency/price",
            params={
                "cryptoCurrency": ",".join(currency.value for currency in crypto_currencies),
                "fiatCurrency": fiat_currency.value,
            },
        )
        return _normalize_prices_payload(payload)
