"""Domain policies and validation helpers for KryptoExpress business rules."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol, runtime_checkable

from kryptoexpress.errors import (
    CurrencyConversionError,
    MinimumAmountError,
    UnsupportedPaymentModeError,
    ValidationError,
)
from kryptoexpress.models.common import (
    CryptoCurrency,
    FiatCurrency,
    PaymentBehavior,
    PaymentType,
)
from kryptoexpress.models.payments import PaymentCreateRequest

STABLECOINS = frozenset(
    {
        CryptoCurrency.USDT_ERC20,
        CryptoCurrency.USDC_ERC20,
        CryptoCurrency.USDT_BEP20,
        CryptoCurrency.USDC_BEP20,
        CryptoCurrency.USDT_SOL,
        CryptoCurrency.USDC_SOL,
    }
)


@runtime_checkable
class SyncFiatConverter(Protocol):
    """Converts fiat amounts between currencies for synchronous clients."""

    def convert(
        self,
        amount: float,
        from_currency: FiatCurrency,
        to_currency: FiatCurrency,
    ) -> float: ...


@runtime_checkable
class AsyncFiatConverter(Protocol):
    """Converts fiat amounts between currencies for asynchronous clients."""

    async def aconvert(
        self,
        amount: float,
        from_currency: FiatCurrency,
        to_currency: FiatCurrency,
    ) -> float: ...


SyncFiatConverterCallable = Callable[[float, FiatCurrency, FiatCurrency], float]
AsyncFiatConverterCallable = Callable[[float, FiatCurrency, FiatCurrency], Awaitable[float]]
SyncFiatConverterLike = SyncFiatConverter | SyncFiatConverterCallable
AsyncFiatConverterLike = AsyncFiatConverter | AsyncFiatConverterCallable


class MinimumAmountPolicy:
    """Centralized minimum fiat amount validation.

    KryptoExpress charges 0.8% service fee with a minimum fee equivalent to 1 USD.
    This policy enforces the minimum threshold before sending `POST /payment`.

    The SDK validates this threshold only for USD-denominated payments. For non-USD payments,
    client-side validation is intentionally skipped unless you build a custom policy.
    """

    def __init__(
        self,
        *,
        minimum_amount_usd: float = 1.0,
        sync_converter: SyncFiatConverterLike | None = None,
        async_converter: AsyncFiatConverterLike | None = None,
    ) -> None:
        self.minimum_amount_usd = minimum_amount_usd
        self._sync_converter = sync_converter
        self._async_converter = async_converter

    def minimum_amount_for(self, fiat_currency: FiatCurrency) -> float:
        """Return the minimum required amount for a target fiat currency."""

        if fiat_currency is not FiatCurrency.USD:
            raise CurrencyConversionError(
                message=(
                    "The default minimum amount policy validates only USD payments. "
                    f"Non-USD threshold lookup is unavailable for {fiat_currency.value}."
                )
            )
        return self.minimum_amount_usd

    async def aminimum_amount_for(self, fiat_currency: FiatCurrency) -> float:
        """Return the minimum required amount for a target fiat currency asynchronously."""

        if fiat_currency is not FiatCurrency.USD:
            raise CurrencyConversionError(
                message=(
                    "The default minimum amount policy validates only USD payments. "
                    f"Non-USD threshold lookup is unavailable for {fiat_currency.value}."
                )
            )
        return self.minimum_amount_usd

    def validate(self, *, fiat_currency: FiatCurrency, fiat_amount: float) -> None:
        """Validate a payment amount against the minimum threshold."""

        if fiat_currency is not FiatCurrency.USD:
            return
        minimum_amount = self.minimum_amount_for(fiat_currency)
        if fiat_amount < minimum_amount:
            raise MinimumAmountError(
                message=(
                    f"Payment amount {fiat_amount:.2f} {fiat_currency.value} is below the minimum "
                    f"allowed amount of {minimum_amount:.2f} {fiat_currency.value} "
                    f"(equivalent to {self.minimum_amount_usd:.2f} USD)."
                )
            )

    async def avalidate(self, *, fiat_currency: FiatCurrency, fiat_amount: float) -> None:
        """Validate a payment amount against the minimum threshold asynchronously."""

        if fiat_currency is not FiatCurrency.USD:
            return
        minimum_amount = await self.aminimum_amount_for(fiat_currency)
        if fiat_amount < minimum_amount:
            raise MinimumAmountError(
                message=(
                    f"Payment amount {fiat_amount:.2f} {fiat_currency.value} is below the minimum "
                    f"allowed amount of {minimum_amount:.2f} {fiat_currency.value} "
                    f"(equivalent to {self.minimum_amount_usd:.2f} USD)."
                )
            )

    def _convert_sync(
        self,
        amount: float,
        from_currency: FiatCurrency,
        to_currency: FiatCurrency,
    ) -> float:
        if self._sync_converter is None:
            raise CurrencyConversionError(
                message=(
                    "A fiat currency converter is required for non-USD minimum amount validation. "
                    f"Cannot convert {amount:.2f} {from_currency.value} to {to_currency.value}."
                )
            )
        if callable(self._sync_converter):
            return self._sync_converter(amount, from_currency, to_currency)
        return self._sync_converter.convert(amount, from_currency, to_currency)

    async def _convert_async(
        self,
        amount: float,
        from_currency: FiatCurrency,
        to_currency: FiatCurrency,
    ) -> float:
        if self._async_converter is not None:
            if callable(self._async_converter):
                return await self._async_converter(amount, from_currency, to_currency)
            return await self._async_converter.aconvert(amount, from_currency, to_currency)
        if self._sync_converter is not None:
            return self._convert_sync(amount, from_currency, to_currency)
        raise CurrencyConversionError(
            message=(
                "A fiat currency converter is required for non-USD minimum amount validation. "
                f"Cannot convert {amount:.2f} {from_currency.value} to {to_currency.value}."
            )
        )


class PaymentRequestValidator:
    """Applies business validation rules before payment creation requests are sent."""

    def __init__(self, *, minimum_amount_policy: MinimumAmountPolicy) -> None:
        self._minimum_amount_policy = minimum_amount_policy

    def validate(self, request: PaymentCreateRequest) -> None:
        """Validate a payment request for synchronous clients."""

        self._validate_common(request)
        if request.payment_type is PaymentType.PAYMENT and request.fiat_amount is not None:
            self._minimum_amount_policy.validate(
                fiat_currency=request.fiat_currency,
                fiat_amount=request.fiat_amount,
            )

    async def avalidate(self, request: PaymentCreateRequest) -> None:
        """Validate a payment request for asynchronous clients."""

        self._validate_common(request)
        if request.payment_type is PaymentType.PAYMENT and request.fiat_amount is not None:
            await self._minimum_amount_policy.avalidate(
                fiat_currency=request.fiat_currency,
                fiat_amount=request.fiat_amount,
            )

    def _validate_common(self, request: PaymentCreateRequest) -> None:
        if request.payment_type is PaymentType.PAYMENT and request.fiat_amount is None:
            raise ValidationError(
                message=(
                    "paymentType=PAYMENT requires fiatAmount. "
                    f"Received paymentType={request.payment_type.value} "
                    f"for cryptoCurrency={request.crypto_currency.value}."
                )
            )

        if request.payment_type is PaymentType.DEPOSIT and request.fiat_amount is not None:
            raise ValidationError(
                message=(
                    "paymentType=DEPOSIT must not include fiatAmount because fiat and crypto "
                    "values "
                    "are determined after funds arrive on-chain. "
                    f"Received paymentType={request.payment_type.value} "
                    f"for cryptoCurrency={request.crypto_currency.value}."
                )
            )

        if request.crypto_currency in STABLECOINS:
            self._validate_stablecoin_rules(request)

    def _validate_stablecoin_rules(self, request: PaymentCreateRequest) -> None:
        if request.payment_type is PaymentType.DEPOSIT:
            raise UnsupportedPaymentModeError(
                message=(
                    "Stablecoins support only paymentType=PAYMENT. "
                    f"Received paymentType={request.payment_type.value} "
                    f"for cryptoCurrency={request.crypto_currency.value}."
                )
            )

        payment_behavior = request.payment_behavior or PaymentBehavior.EXACT
        if payment_behavior is not PaymentBehavior.EXACT:
            raise UnsupportedPaymentModeError(
                message=(
                    "Stablecoins support only exact payment behavior. "
                    f"Received paymentType={request.payment_type.value}, "
                    f"cryptoCurrency={request.crypto_currency.value}, "
                    f"paymentBehavior={payment_behavior.value}."
                )
            )
