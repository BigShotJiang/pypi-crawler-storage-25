"""Authentication helpers."""

from __future__ import annotations


def build_auth_headers(api_key: str) -> dict[str, str]:
    """Build headers required by the API key authentication scheme."""
    return {"X-Api-Key": api_key}
