"""SDK configuration objects."""

from __future__ import annotations

from dataclasses import dataclass

DEFAULT_BASE_URL = "https://kryptoexpress.pro/api"
DEFAULT_TIMEOUT = 10.0
DEFAULT_MAX_RETRIES = 0


@dataclass(frozen=True, slots=True)
class ClientConfig:
    """Runtime configuration for SDK clients."""

    api_key: str
    base_url: str = DEFAULT_BASE_URL
    timeout: float = DEFAULT_TIMEOUT
    max_retries: int = DEFAULT_MAX_RETRIES
