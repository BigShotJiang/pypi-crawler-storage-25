"""Utilities for verifying KryptoExpress callback signatures."""

from __future__ import annotations

import hashlib
import hmac
import json


def _compact_json(raw_body: str | bytes) -> str:
    decoded = raw_body.decode("utf-8") if isinstance(raw_body, bytes) else raw_body
    return json.dumps(json.loads(decoded), separators=(",", ":"))


def compute_callback_signature(*, raw_body: str | bytes, callback_secret: str) -> str:
    """Compute the HMAC-SHA512 signature for a callback body."""

    compact_json = _compact_json(raw_body)
    return hmac.new(
        callback_secret.encode("utf-8"),
        compact_json.encode("utf-8"),
        hashlib.sha512,
    ).hexdigest()


def verify_callback_signature(
    *,
    raw_body: str | bytes,
    callback_secret: str,
    signature: str | None,
) -> bool:
    """Verify a callback using the `X-Signature` header value."""

    if signature is None:
        return False
    expected = compute_callback_signature(raw_body=raw_body, callback_secret=callback_secret)
    return hmac.compare_digest(expected, signature)
