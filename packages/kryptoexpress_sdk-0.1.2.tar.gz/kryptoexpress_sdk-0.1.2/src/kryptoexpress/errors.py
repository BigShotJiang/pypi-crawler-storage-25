"""Typed exceptions raised by the SDK."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class SDKException(Exception):
    """Base SDK exception."""

    message: str

    def __str__(self) -> str:
        return self.message


@dataclass(slots=True)
class APIError(SDKException):
    """Base exception for HTTP/API failures."""

    status_code: int | None = None
    error: str | None = None
    retry_after: int | None = None
    details: list[dict[str, str]] = field(default_factory=list)
    response_text: str | None = None


@dataclass(slots=True)
class RateLimitError(APIError):
    """Raised when the API returns HTTP 429."""


@dataclass(slots=True)
class NotFoundError(APIError):
    """Raised when the API returns HTTP 404."""


@dataclass(slots=True)
class ValidationError(APIError):
    """Raised when the API returns HTTP 400 or validation details."""


@dataclass(slots=True)
class AuthError(APIError):
    """Raised when the API returns HTTP 401 or HTTP 403."""


@dataclass(slots=True)
class UnsupportedPaymentModeError(ValidationError):
    """Raised when the requested payment mode is not supported for a currency."""


@dataclass(slots=True)
class MinimumAmountError(ValidationError):
    """Raised when a payment amount is below the minimum allowed threshold."""


@dataclass(slots=True)
class CurrencyConversionError(SDKException):
    """Raised when fiat currency conversion is required but unavailable."""
